"""
Argument parser configuration for the data exchange agent CLI.

This module provides functions to create and configure the argument parser
and subparsers for different commands.
"""

import argparse

from data_exchange_agent.__version__ import __version__
from data_exchange_agent.constants.config_defaults import (
    DEFAULT__SERVER__HOST,
    DEFAULT__SERVER__PORT,
)


def create_main_parser() -> argparse.ArgumentParser:
    """
    Create the main argument parser with common configuration.

    Returns:
        The configured argument parser.

    """
    parser = argparse.ArgumentParser(
        description="Data Exchange Agent - Snowflake Data Migration Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  data-exchange-agent --version                       Show version
  data-exchange-agent test                            Test database connections
  data-exchange-agent test -c /path/to/config.toml    Test with custom config
  data-exchange-agent run                             Start the agent server
  data-exchange-agent run -c ./my-config.toml         Start with custom config
  data-exchange-agent -w 8 -p 5000                    Start with 8 parallel tasks on port 5000
        """,
    )

    # Add version argument
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"Data Exchange Agent v{__version__}",
    )

    return parser


def add_run_arguments(parser: argparse.ArgumentParser) -> None:
    """
    Add run command arguments to a parser.

    Args:
        parser: The parser to add arguments to.

    """
    parser.add_argument("-c", "--config", type=str, help="Path to configuration file")
    parser.add_argument(
        "--no-server",
        action="store_true",
        help="Run task handling only without starting the HTTP server (for multi-worker setups)",
    )
    parser.add_argument("-w", "--max-parallel-tasks", type=int, help="Maximum number of parallel tasks")
    parser.add_argument(
        "-i",
        "--interval",
        type=int,
        help="Interval in seconds to fetch tasks from the API",
    )
    parser.add_argument("--host", default=DEFAULT__SERVER__HOST, help="Host to bind to")
    parser.add_argument("-p", "--port", type=int, default=DEFAULT__SERVER__PORT, help="Port to bind to")
    parser.add_argument("-d", "--debug", action="store_true", help="Enable debug mode")
    parser.add_argument(
        "--local-results-directory",
        type=str,
        default=None,
        dest="local_results_directory",
        metavar="DIR",
        help=("Base directory for exported Parquet/CSV files before upload " "(overrides application.local_results_directory in config)"),
    )


def create_test_subparser(
    subparsers: argparse._SubParsersAction,
) -> argparse.ArgumentParser:
    """
    Create the test command subparser.

    Args:
        subparsers: The subparsers object from the main parser.

    Returns:
        The test command parser.

    """
    test_parser = subparsers.add_parser(
        "test",
        help="Test database connections (SELECT 1)",
        description="Verify database connectivity by executing SELECT 1 on all configured connections.",
    )
    test_parser.add_argument("-c", "--config", type=str, help="Path to configuration file")
    return test_parser


def create_run_subparser(
    subparsers: argparse._SubParsersAction,
) -> argparse.ArgumentParser:
    """
    Create the run command subparser.

    Args:
        subparsers: The subparsers object from the main parser.

    Returns:
        The run command parser.

    """
    run_parser = subparsers.add_parser(
        "run",
        help="Start the agent server",
        description="Start the data exchange agent server.",
    )
    add_run_arguments(run_parser)
    return run_parser


def create_argument_parser() -> argparse.ArgumentParser:
    """
    Create and configure the complete argument parser with all subcommands.

    Returns:
        The fully configured argument parser.

    """
    parser = create_main_parser()

    # Create subparsers
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command subparsers
    create_test_subparser(subparsers)
    create_run_subparser(subparsers)

    # Add run arguments to main parser for backwards compatibility
    # (allows running without explicit 'run' command)
    add_run_arguments(parser)

    return parser
