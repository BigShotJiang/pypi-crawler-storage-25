"""
In-memory task queue implementation using collections.deque.

This module provides the DequeTaskQueue class which implements a simple
in-memory task queue using Python's collections.deque. It's suitable for
single-process applications where task persistence is not required.
"""

import threading

from collections import deque
from typing import Any

from data_exchange_agent.interfaces.task_queue import TaskQueueInterface


class DequeTaskQueue(TaskQueueInterface):
    """
    A simple task queue implementation using collections.deque.

    This class implements the TaskQueueInterface interface using a thread-safe deque as the underlying
    data structure. It provides basic queue operations like adding and retrieving tasks.

    The implementation uses a threading.Lock to ensure thread-safety when accessing the deque.

    Note that this is a basic implementation - methods related to task completion, failure,
    retry and cleanup are not implemented.
    """

    def __init__(self):
        """Initialize an empty task queue with a thread lock."""
        self.task_queue: deque[dict[str, Any]] = deque()
        self.task_deque_lock = threading.Lock()

    def add_task(self, task: dict[str, Any]) -> None:
        """
        Add a task to the end of the queue.

        Args:
            task: Dictionary containing task data

        """
        with self.task_deque_lock:
            self.task_queue.append(task)

    def get_task(self, worker_id: str | None = None) -> dict[str, Any] | None:
        """
        Get and remove the next task from the front of the queue.

        Args:
            worker_id: Optional worker identifier (not used in this implementation)

        Returns:
            The next task dictionary if queue is not empty, None otherwise

        """
        with self.task_deque_lock:
            if self.task_queue:
                return self.task_queue.popleft()
            else:
                return None

    def complete_task(self, task_id: str) -> None:
        """
        Mark a task as completed (not implemented).

        Args:
            task_id: The ID of the task to mark as completed

        """
        pass

    def fail_task(self, task_id: str, error_message: str | None = None) -> None:
        """
        Mark a task as failed (not implemented).

        Args:
            task_id: The ID of the task to mark as failed
            error_message: Optional error message explaining the failure

        """
        pass

    def retry_task(self, task_id: str) -> None:
        """
        Add a task back to the queue for retry (not implemented).

        Args:
            task_id: The ID of the task to retry

        """
        pass

    def cleanup_stale_tasks(self, timeout_seconds: int = 300) -> int:
        """
        Remove stale tasks that have timed out (not implemented).

        Args:
            timeout_seconds: Number of seconds after which a task is considered stale

        Returns:
            Number of tasks removed

        """
        return 0

    def clear_completed_tasks(self, older_than_hours: int = 24) -> int:
        """
        Remove completed tasks older than specified hours (not implemented).

        Args:
            older_than_hours: Remove completed tasks older than this many hours

        Returns:
            Number of tasks removed

        """
        return 0

    def get_queue_size(self) -> int:
        """
        Get the current size of the queue.

        Returns:
            Number of tasks currently in the queue

        """
        with self.task_deque_lock:
            return len(self.task_queue)

    def get_processing_count(self) -> int:
        """
        Get count of tasks currently being processed (not implemented).

        Returns:
            Number of tasks currently being processed

        """
        return 0

    def get_completed_count(self) -> int:
        """
        Get count of completed tasks (not implemented).

        Returns:
            Number of completed tasks

        """
        return 0

    def get_queue_stats(self) -> dict[str, int]:
        """
        Get statistics about the queue (not implemented).

        Returns:
            Dictionary containing various queue statistics

        """
        return {}
