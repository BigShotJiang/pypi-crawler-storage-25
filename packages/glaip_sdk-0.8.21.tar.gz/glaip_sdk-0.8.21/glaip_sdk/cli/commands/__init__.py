"""CLI commands package exports."""

from __future__ import annotations

from importlib import import_module
from typing import Any

__all__ = ["agents", "configure", "mcps", "models", "tools", "transcripts", "update"]


def __getattr__(name: str) -> Any:
    """Load command subpackages lazily on first access."""
    if name in __all__:
        module = import_module(f"glaip_sdk.cli.commands.{name}")
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """Expose lazily loaded command modules to introspection."""
    return sorted({*globals(), *__all__})
