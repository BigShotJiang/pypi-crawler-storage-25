"""CLI package for AIP SDK.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from importlib import import_module
from types import ModuleType
import sys
from typing import Any

__all__ = ["main"]


class _LazyMainCommand:
    """Proxy that imports the Click command only when used."""

    def __init__(self) -> None:
        self._command: Any | None = None

    def _load(self) -> Any:
        if self._command is None:
            self._command = import_module("glaip_sdk.cli.main").main
        return self._command

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._load()(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._load(), name)

    def __repr__(self) -> str:
        if self._command is None:
            return "<lazy glaip_sdk.cli.main command>"
        return repr(self._command)


class _LazyCLIPackage(ModuleType):
    """Module type that always returns the lazy proxy for 'main' attribute access.

    This is required because Python's submodule loading bypasses PEP 562 __getattr__
    when the submodule (glaip_sdk.cli.main) is already in sys.modules. By overriding
    __getattribute__ on the module class itself, we intercept all attribute access
    regardless of submodule load order.
    """

    def __getattribute__(self, name: str) -> Any:
        if name == "main":
            return ModuleType.__getattribute__(self, "_main_proxy")
        return ModuleType.__getattribute__(self, name)


_module = sys.modules[__name__]
ModuleType.__setattr__(_module, "_main_proxy", _LazyMainCommand())
ModuleType.__setattr__(_module, "__class__", _LazyCLIPackage)


def __dir__() -> list[str]:
    """Expose the lazy CLI export in module introspection."""
    return sorted({*globals(), *__all__})
