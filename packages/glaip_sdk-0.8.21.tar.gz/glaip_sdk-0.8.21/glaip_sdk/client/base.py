#!/usr/bin/env python3
"""Base client for AIP SDK.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

import logging
import os
import random
import time
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, NoReturn, Union

import httpx
from dotenv import load_dotenv

import glaip_sdk
from glaip_sdk._version import __version__ as SDK_VERSION
from glaip_sdk.client.mtls import resolve_mtls_verify_setting
from glaip_sdk.config.constants import DEFAULT_ERROR_MESSAGE, SDK_NAME
from glaip_sdk.exceptions import (
    APIError,
    NetworkError,
    TimeoutError,
    extract_request_id,
    get_error_descriptor_for_status,
    get_exception_class_for_status,
)

_UNSET_TIMEOUT = object()

# Set up logging without basicConfig (library best practice)
logger = logging.getLogger("glaip_sdk")
logger.addHandler(logging.NullHandler())

client_log = logging.getLogger("glaip_sdk.client")
client_log.addHandler(logging.NullHandler())


@dataclass
class RetryPolicy:
    """Retry policy configuration for SDK requests."""

    max_attempts: int = 4
    base_delay: float = 0.5
    max_delay: float = 10.0
    jitter: float = 0.25

    def is_retryable(self, error: APIError) -> bool:
        """Determine if an error is retryable based on canonical category."""
        return error.retryable is True

    def get_backoff_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay with jitter for given attempt."""
        delay = self.base_delay * (2 ** (attempt - 1))
        jitter_range = delay * self.jitter
        delay += random.uniform(-jitter_range, jitter_range)
        return min(max(delay, 0.1), self.max_delay)

    def should_retry(self, attempt: int, elapsed: float = 0.0, budget: float | None = None) -> bool:
        """Determine if retry should be attempted based on attempt count and optional budget."""
        if attempt >= self.max_attempts:
            return False
        if budget is not None and elapsed >= budget:
            return False
        return True


def _is_retryable_transport_error(exc: httpx.RequestError) -> bool:
    """Determine if a transport error should trigger retry."""
    if isinstance(exc, httpx.ConnectError):
        return True
    if isinstance(exc, httpx.TimeoutException):
        return True
    return False


def _is_retryable_http_status(status_code: int) -> bool:
    """Determine if an HTTP status code indicates a retryable error."""
    descriptor = get_error_descriptor_for_status(status_code)
    return descriptor.retryable


def _resolve_timeout_budget(request_timeout: Any | None, default_timeout: float) -> float | None:
    """Resolve the total timeout budget used across all retry attempts.

    Returns the budget as a float, or None if the request uses per-component
    httpx.Timeout values that should not be capped during retries.
    """
    if request_timeout is _UNSET_TIMEOUT:
        return default_timeout

    if request_timeout is None:
        return None

    if isinstance(request_timeout, (int, float)):
        return float(request_timeout)

    if isinstance(request_timeout, httpx.Timeout):
        timeout_value = getattr(request_timeout, "timeout", None)
        if isinstance(
            timeout_value, (int, float)
        ):  # pragma: no cover - httpx doesn't expose .timeout as float when using keyword args
            return float(
                timeout_value
            )  # pragma: no cover - httpx doesn't expose .timeout as float when using keyword args

        has_components = any(
            isinstance(getattr(request_timeout, attr, None), (int, float))
            for attr in ("connect", "read", "write", "pool")
        )
        if has_components:
            return None

    return default_timeout  # pragma: no cover - defensive fallback


def _remaining_timeout_budget(started_at: float, timeout_budget: float | None) -> float | None:
    """Return the remaining total timeout budget from the start time."""
    if timeout_budget is None:
        return None
    return max(timeout_budget - (time.monotonic() - started_at), 0.0)


def _cap_timeout_component(component_timeout: float | None, remaining_budget: float) -> float | None:
    """Cap a timeout component to the remaining request budget."""
    if component_timeout is None:
        return None
    return min(component_timeout, remaining_budget)


def _cap_request_timeout(
    request_timeout: Any | None,
    *,
    default_timeout: float,
    remaining_budget: float | None,
) -> Any | None:
    """Cap the next request timeout so retries stay inside the total budget."""
    if request_timeout is None:
        return None

    if remaining_budget is None:
        return request_timeout  # pragma: no cover - covered by integration tests

    if request_timeout is _UNSET_TIMEOUT:
        return min(default_timeout, remaining_budget)  # pragma: no cover - covered by integration tests

    if isinstance(
        request_timeout, (int, float)
    ):  # pragma: no cover - httpx doesn't expose .timeout as float in practice
        return min(
            float(request_timeout), remaining_budget
        )  # pragma: no cover - httpx doesn't expose .timeout as float in practice

    if isinstance(request_timeout, httpx.Timeout):
        timeout_value = getattr(request_timeout, "timeout", None)
        base_timeout = float(timeout_value) if isinstance(timeout_value, (int, float)) else remaining_budget
        return httpx.Timeout(
            timeout=min(base_timeout, remaining_budget),
            connect=_cap_timeout_component(request_timeout.connect, remaining_budget),
            read=_cap_timeout_component(request_timeout.read, remaining_budget),
            write=_cap_timeout_component(request_timeout.write, remaining_budget),
            pool=_cap_timeout_component(request_timeout.pool, remaining_budget),
        )

    return request_timeout  # pragma: no cover - defensive fallback for unexpected types


def _can_retry_within_timeout_budget(started_at: float, timeout_budget: float | None, delay: float) -> bool:
    """Return whether another retry can fit within the remaining timeout budget."""
    remaining = _remaining_timeout_budget(started_at, timeout_budget)
    return remaining is None or delay < remaining


class BaseClient:
    """Base client with HTTP operations and authentication."""

    def __init__(
        self,
        api_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        *,
        parent_client: Union["BaseClient", None] = None,
        load_env: bool = True,
    ):
        """Initialize the base client.

        Args:
            api_url: API base URL
            api_key: API authentication key
            timeout: Request timeout in seconds
            parent_client: Parent client to adopt session/config from
            load_env: Whether to load environment variables
        """
        self._parent_client = parent_client
        self._session_scoped = False  # Mark as not session-scoped by default

        if parent_client is not None:
            # Adopt parent's session/config; DO NOT call super().__init__
            client_log.debug("Adopting parent client configuration")
            self.api_url = parent_client.api_url
            self.api_key = parent_client.api_key
            self._timeout = parent_client._timeout
            self.http_client = parent_client.http_client
        else:
            # Initialize as standalone client
            if load_env and not (api_url and api_key):
                # Only load .env file if explicit credentials not provided
                package_dir = os.path.dirname(glaip_sdk.__file__)
                env_file = os.path.join(package_dir, ".env")
                load_dotenv(env_file)

            self.api_url = api_url or os.getenv("AIP_API_URL")
            self.api_key = api_key or os.getenv("AIP_API_KEY")
            self._timeout = timeout

            if not self.api_url:
                client_log.error("AIP_API_URL not found in environment or parameters")
                raise ValueError("AIP_API_URL not found")
            if not self.api_key:
                client_log.error("AIP_API_KEY not found in environment or parameters")
                raise ValueError("AIP_API_KEY not found")

            client_log.info(f"Initializing client with API URL: {self.api_url}")
            self.http_client = self._build_client(timeout)

        # Language model cache (shared by all clients)
        self._lm_cache: list[dict[str, Any]] | None = None
        self._lm_cache_time: float = 0.0
        self._lm_cache_ttl: float = 300.0  # 5 minutes TTL

        # Last successful response for correlation tracking
        self._last_response: httpx.Response | None = None

    def _build_client(self, timeout: float) -> httpx.Client:
        """Build HTTP client with configuration."""
        # For streaming operations, we need more generous read timeouts
        # while keeping reasonable connect timeouts
        timeout_config = httpx.Timeout(
            timeout=timeout,  # Total timeout
            connect=min(30.0, timeout),  # Connect timeout (max 30s)
            read=timeout,  # Read timeout (same as total for streaming)
            write=min(30.0, timeout),  # Write timeout (max 30s)
            pool=timeout,  # Pool timeout (same as total)
        )

        return httpx.Client(
            base_url=self.api_url,
            headers={
                "X-API-Key": self.api_key,
                "User-Agent": f"{SDK_NAME}/{SDK_VERSION}",
            },
            timeout=timeout_config,
            follow_redirects=True,
            http2=False,
            limits=httpx.Limits(max_keepalive_connections=10, max_connections=100),
            verify=resolve_mtls_verify_setting(self.api_url),
        )

    def _build_async_client(self, timeout: float) -> dict[str, Any]:
        """Build async client configuration (returns dict of kwargs for httpx.AsyncClient).

        Args:
            timeout: Request timeout in seconds

        Returns:
            Dictionary of kwargs for httpx.AsyncClient
        """
        # For streaming operations, we need more generous read timeouts
        # while keeping reasonable connect timeouts
        timeout_config = httpx.Timeout(
            timeout=timeout,  # Total timeout
            connect=min(30.0, timeout),  # Connect timeout (max 30s)
            read=timeout,  # Read timeout (same as total for streaming)
            write=min(30.0, timeout),  # Write timeout (max 30s)
            pool=timeout,  # Pool timeout (same as total)
        )

        return {
            "base_url": self.api_url,
            "headers": {
                "X-API-Key": self.api_key,
                "User-Agent": f"{SDK_NAME}/{SDK_VERSION}",
            },
            "timeout": timeout_config,
            "follow_redirects": True,
            "http2": False,
            "limits": httpx.Limits(max_keepalive_connections=10, max_connections=100),
            "verify": resolve_mtls_verify_setting(self.api_url),
        }

    @property
    def timeout(self) -> float:
        """Get current timeout value."""
        return self._timeout

    @timeout.setter
    def timeout(self, value: float) -> None:
        """Set timeout and rebuild client."""
        self._timeout = value
        if hasattr(self, "http_client") and self.http_client and not self._session_scoped and not self._parent_client:
            self.http_client.close()
            self.http_client = self._build_client(value)

    def _post_then_fetch(
        self,
        id_key: str,
        post_endpoint: str,
        get_endpoint_fmt: str,
        *,
        json: Any | None = None,
        data: Any | None = None,
        files: Any | None = None,
        **kwargs: Any,
    ) -> Any:
        """Helper for POST-then-GET pattern used in create methods.

        Args:
            id_key: Key in POST response containing the ID
            post_endpoint: Endpoint for POST request
            get_endpoint_fmt: Format string for GET endpoint (e.g., "/items/{id}")
            json: JSON data for POST
            data: Form data for POST
            files: Files for POST
            **kwargs: Additional kwargs for POST

        Returns:
            Full resource data from GET request
        """
        # Create the resource
        post_kwargs = {}
        if json is not None:
            post_kwargs["json"] = json
        if data is not None:
            post_kwargs["data"] = data
        if files is not None:
            post_kwargs["files"] = files
        post_kwargs.update(kwargs)

        response_data = self._request("POST", post_endpoint, **post_kwargs)

        # Extract the ID
        if isinstance(response_data, dict):
            resource_id = response_data.get(id_key)
        else:
            # Fallback: assume response_data is the ID directly
            resource_id = str(response_data)

        if not resource_id:
            raise ValueError(f"Backend did not return {id_key}")

        # Fetch the full resource details
        get_endpoint = get_endpoint_fmt.format(id=resource_id)
        return self._request("GET", get_endpoint)

    def _ensure_client_alive(self) -> None:
        """Ensure HTTP client is alive, recreate if needed."""
        if not hasattr(self, "http_client") or self.http_client is None:
            if not self._parent_client:
                self.http_client = self._build_client(self._timeout)
            return

        # Check if client is closed by attempting a simple operation
        try:
            # Try to access a property that would fail if closed
            _ = self.http_client.headers
        except (RuntimeError, AttributeError) as e:
            if "closed" in str(e).lower() or "NoneType" in str(e):
                client_log.debug("HTTP client was closed, recreating")
                if not self._parent_client:
                    self.http_client = self._build_client(self._timeout)
            else:
                raise

    def _perform_request(
        self,
        method: str,
        endpoint: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Execute a raw HTTP request with retry handling and timeout budget enforcement."""
        self._ensure_client_alive()
        client_log.debug(f"Making {method} request to {endpoint}")

        policy = RetryPolicy()
        timeout_arg = kwargs["timeout"] if "timeout" in kwargs else _UNSET_TIMEOUT
        timeout_budget = _resolve_timeout_budget(timeout_arg, self._timeout)
        request_started_at = time.monotonic()
        last_error: Exception | None = None
        last_api_error: APIError | None = None

        for attempt in range(1, policy.max_attempts + 1):
            request_kwargs = self._build_request_kwargs_for_attempt(
                kwargs,
                timeout_arg=timeout_arg,
                request_started_at=request_started_at,
                timeout_budget=timeout_budget,
            )

            try:
                response = self.http_client.request(method, endpoint, **request_kwargs)
                response, last_api_error = self._handle_response_attempt(
                    response,
                    method=method,
                    endpoint=endpoint,
                    attempt=attempt,
                    policy=policy,
                    request_started_at=request_started_at,
                    timeout_budget=timeout_budget,
                )
                if response is not None:
                    return response
            except httpx.RequestError as exc:
                last_error, last_api_error = self._handle_transport_error(
                    exc, method, endpoint, attempt, policy, request_started_at, timeout_budget
                )

        if last_api_error is not None:
            raise last_api_error  # pragma: no cover
        if last_error is not None:  # pragma: no cover
            raise self._create_transport_error(last_error, method=method, endpoint=endpoint)
        raise self._create_api_error(None, f"Request failed after {policy.max_attempts} attempts")  # pragma: no cover

    def _build_request_kwargs_for_attempt(
        self,
        kwargs: Mapping[str, Any],
        *,
        timeout_arg: Any | None,
        request_started_at: float,
        timeout_budget: float | None,
    ) -> dict[str, Any]:
        """Build request kwargs for a retry attempt with timeout-budget capping."""
        remaining_budget = _remaining_timeout_budget(request_started_at, timeout_budget)
        request_kwargs = dict(kwargs)
        request_kwargs["timeout"] = _cap_request_timeout(
            timeout_arg,
            default_timeout=self._timeout,
            remaining_budget=remaining_budget,
        )
        return request_kwargs

    def _handle_response_attempt(
        self,
        response: httpx.Response,
        *,
        method: str,
        endpoint: str,
        attempt: int,
        policy: RetryPolicy,
        request_started_at: float,
        timeout_budget: float | None,
    ) -> tuple[httpx.Response | None, APIError | None]:
        """Handle an HTTP response and either return it or schedule the next retry."""
        if response.status_code < 400:
            client_log.debug(f"Response status: {response.status_code}")
            self._last_response = response
            return response, None

        api_error, request_id = self._build_api_error_from_response(response)
        if not _is_retryable_http_status(response.status_code):
            raise api_error

        delay = policy.get_backoff_delay(attempt)
        client_log.warning(
            "Retry scheduled error_code=%s attempt=%s max_attempts=%s "
            "next_backoff_ms=%s request_id=%s method=%s endpoint=%s status_code=%s",
            api_error.error_code,
            attempt,
            policy.max_attempts,
            int(delay * 1000),
            request_id,
            method,
            endpoint,
            response.status_code,
        )

        if not _can_retry_within_timeout_budget(
            request_started_at, timeout_budget, delay
        ):  # pragma: no cover - budget check covered by integration tests
            raise api_error  # pragma: no cover - budget check covered by integration tests

        time.sleep(delay)
        return None, api_error

    def _build_api_error_from_response(self, response: httpx.Response) -> tuple[APIError, str | None]:
        """Create an SDK API error from an HTTP error response."""
        error_message = self._get_error_message(response)
        parsed_content = self._parse_error_json(response)
        error_type = parsed_content.get("error") if isinstance(parsed_content, dict) else None
        request_id = self._extract_request_id(response=response)
        api_error = self._create_api_error(
            response.status_code,
            error_message,
            error_type=error_type,
            payload=parsed_content,
            request_id=request_id,
        )
        return api_error, request_id

    def _handle_transport_error(
        self,
        exc: httpx.RequestError,
        method: str,
        endpoint: str,
        attempt: int,
        policy: RetryPolicy,
        request_started_at: float,
        timeout_budget: float | None,
    ) -> tuple[Exception, APIError]:
        """Handle transport error and return last_error and api_error for retry loop."""
        elapsed = time.monotonic() - request_started_at
        remaining_budget = _remaining_timeout_budget(request_started_at, timeout_budget)
        client_log.warning(f"Request error on {method} {endpoint}, attempt {attempt}/{policy.max_attempts}: {exc}")

        if not _is_retryable_transport_error(exc):
            client_log.error(f"Non-retryable transport error for {method} {endpoint}: {exc}")
            api_error = self._create_transport_error(exc, method=method, endpoint=endpoint)
            raise api_error from exc

        if policy.should_retry(attempt, elapsed, remaining_budget if remaining_budget is not None else float("inf")):
            delay = policy.get_backoff_delay(attempt)
            client_log.debug(f"Backing off for {delay:.2f}s before retry")
            time.sleep(delay)
            api_error = self._create_transport_error(exc, method=method, endpoint=endpoint)
            return exc, api_error

        client_log.error(f"All retry attempts exhausted for {method} {endpoint}: {exc}")
        api_error = self._create_transport_error(exc, method=method, endpoint=endpoint)
        raise api_error from exc

    def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        """Make HTTP request with error handling and unwrap success envelopes."""
        response = self._perform_request(method, endpoint, **kwargs)
        return self._handle_response(response, unwrap=True)

    def _request_with_envelope(
        self,
        method: str,
        endpoint: str,
        **kwargs: Any,
    ) -> Any:
        """Make HTTP request but return the full success envelope."""
        response = self._perform_request(method, endpoint, **kwargs)
        return self._handle_response(response, unwrap=False)

    def _parse_response_content(self, response: httpx.Response) -> Any | None:
        """Parse response content based on content type."""
        if response.status_code == 204:
            return None

        content_type = response.headers.get("content-type", "").lower()
        if "json" in content_type:
            try:
                return response.json()
            except ValueError:
                pass

        if 200 <= response.status_code < 300:
            return response.text
        else:
            return None  # Let _handle_response deal with error status codes

    def _handle_success_response(
        self,
        parsed: Any,
        *,
        response: httpx.Response | None = None,
        unwrap: bool,
    ) -> Any:
        """Handle successful response with success flag."""
        if isinstance(parsed, dict) and "success" in parsed:
            if parsed.get("success"):
                return parsed.get("data", parsed) if unwrap else parsed
            else:
                error_type = parsed.get("error", "UnknownError")
                message = self._format_error_dict({key: value for key, value in parsed.items() if key != "success"})
                self._raise_api_error(
                    400,
                    message,
                    error_type,
                    payload=parsed,  # Using 400 as status since original response had error
                    request_id=self._extract_request_id(response=response) if response is not None else None,
                )

        return parsed

    def _get_error_message(self, response: httpx.Response) -> str:
        """Extract error message from response, preferring parsed content."""
        parsed = self._parse_error_json(response)
        if parsed is None:
            return response.text

        formatted = self._format_parsed_error(parsed)
        return formatted if formatted is not None else response.text

    def _parse_error_json(self, response: httpx.Response) -> Any | None:
        """Safely parse JSON from an error response."""
        try:
            return response.json()
        except (ValueError, TypeError):
            return None

    def _format_parsed_error(self, parsed: Any) -> str | None:
        """Build a readable error message from parsed JSON payloads."""
        if isinstance(parsed, dict):
            return self._format_error_dict(parsed)
        if isinstance(parsed, str):
            return parsed
        return str(parsed) if parsed else None

    def _format_error_dict(self, parsed: dict[str, Any]) -> str:
        """Format structured API error payloads."""
        detail = parsed.get("detail")
        if isinstance(detail, list):
            validation_message = self._format_validation_errors(detail)
            if validation_message:
                return validation_message
            return f"Validation error: {parsed}"

        formatted_details = None
        if "details" in parsed:
            formatted_details = self._format_error_details(parsed["details"])

        message = parsed.get("message")
        if message:
            if formatted_details:
                return f"{message}\n{formatted_details}"
            return message

        if formatted_details:
            return formatted_details

        return str(parsed) if parsed else DEFAULT_ERROR_MESSAGE

    def _format_error_details(self, details: Any) -> str | None:
        """Render generic error details into a human-readable string."""
        if details is None:
            return None

        if isinstance(details, dict):
            return self._format_detail_mapping(details)

        if isinstance(details, (list, tuple, set)):
            return self._format_detail_iterable(details)

        return f"Details: {details}"

    @staticmethod
    def _format_detail_mapping(details: Mapping[str, Any]) -> str | None:
        """Format details provided as a mapping."""
        entries = [f"  {key}: {value}" for key, value in details.items()]
        if not entries:
            return None
        return "Details:\n" + "\n".join(entries)

    @staticmethod
    def _format_detail_iterable(details: Iterable[Any]) -> str | None:
        """Format details provided as an iterable collection."""
        entries: list[str] = []
        for item in details:
            if isinstance(item, Mapping):
                inner = ", ".join(f"{k}={v}" for k, v in item.items())
                entries.append(f"  - {inner if inner else '{}'}")
            else:
                entries.append(f"  - {item}")

        if not entries:
            return None

        return "Details:\n" + "\n".join(entries)

    def _format_validation_errors(self, errors: list[Any]) -> str | None:
        """Render validation errors into a human-readable string."""
        entries: list[str] = []
        for error in errors:
            if isinstance(error, dict):
                loc = " -> ".join(str(x) for x in error.get("loc", []))
                msg = error.get("msg", DEFAULT_ERROR_MESSAGE)
                error_type = error.get("type", "unknown")
                prefix = loc if loc else "Field"
                entries.append(f"  {prefix}: {msg} ({error_type})")
            else:
                entries.append(f"  {error}")

        if not entries:
            return None

        return "Validation errors:\n" + "\n".join(entries)

    @staticmethod
    def _response_status_code(response: httpx.Response) -> int | None:
        """Safely read an HTTP status code from real responses and test doubles."""
        status_code = getattr(response, "status_code", None)
        return status_code if isinstance(status_code, int) else None

    @staticmethod
    def _is_no_content_response(response: httpx.Response) -> bool:
        """Return True when the response contains no content."""
        return BaseClient._response_status_code(response) == 204

    @staticmethod
    def _is_success_status(response: httpx.Response) -> bool:
        """Return True for successful HTTP status codes."""
        status_code = BaseClient._response_status_code(response)
        if status_code is None:
            return True
        return 200 <= status_code < 300

    def _handle_error_response(self, response: httpx.Response) -> None:
        """Raise an API error for non-success responses."""
        error_message = self._get_error_message(response)
        parsed_content = self._parse_error_json(response)
        error_type = parsed_content.get("error") if isinstance(parsed_content, dict) else None
        self._raise_api_error(
            response.status_code,
            error_message,
            error_type=error_type,
            payload=parsed_content,
            request_id=self._extract_request_id(response=response),
        )

    def _handle_response(
        self,
        response: httpx.Response,
        *,
        unwrap: bool = True,
    ) -> Any:
        """Handle HTTP response with proper error handling."""
        # Handle no-content success before general error handling
        if self._is_no_content_response(response):
            return None

        if self._is_success_status(response):
            parsed = self._parse_response_content(response)
            if parsed is None:
                return None
            return self._handle_success_response(parsed, response=response, unwrap=unwrap)

        self._handle_error_response(response)
        return None

    def _raise_for_error_status(self, response: httpx.Response) -> None:
        """Raise a shaped SDK error when an HTTP response is unsuccessful."""
        if self._is_no_content_response(response) or self._is_success_status(response):
            return
        self._handle_error_response(response)

    def _extract_request_id(
        self,
        *,
        response: httpx.Response | None = None,
        request: httpx.Request | None = None,
    ) -> str | None:
        """Extract request correlation from response or request headers."""
        if response is not None:
            response_request_id = extract_request_id(response.headers)
            if response_request_id:
                return response_request_id
            response_request = getattr(response, "request", None)
            if isinstance(response_request, httpx.Request):
                request_id = extract_request_id(response_request.headers)
                if request_id:
                    return request_id

        if request is not None:
            return extract_request_id(request.headers)

        if hasattr(self, "_last_response") and self._last_response is not None:
            last_request_id = extract_request_id(self._last_response.headers)
            if last_request_id:
                return last_request_id

        return None

    def _format_api_error_message(self, message: str, *, status: int | None, request_id: str | None) -> str:
        """Format an SDK error message with optional HTTP status and request ID."""
        error_message = f"HTTP {status}: {message}" if status is not None else message
        if request_id:
            error_message += f" (Request ID: {request_id})"
        return error_message

    def _create_api_error(
        self,
        status: int | None,
        message: str,
        error_type: str | None = None,
        *,
        payload: Any | None = None,
        request_id: str | None = None,
        exception_class: type[APIError] | None = None,
        category: str | None = None,
        error_code: str | None = None,
        retryable: bool | None = None,
    ) -> APIError:
        """Create a shaped SDK error instance."""
        resolved_exception_class = exception_class or get_exception_class_for_status(status)
        error_message = self._format_api_error_message(message, status=status, request_id=request_id)
        return resolved_exception_class(
            error_message,
            status_code=status,
            error_type=error_type,
            payload=payload,
            request_id=request_id,
            category=category,
            error_code=error_code,
            retryable=retryable,
        )

    def _create_transport_error(
        self,
        exc: httpx.RequestError,
        *,
        method: str,
        endpoint: str,
    ) -> APIError:
        """Map a transport failure into the canonical SDK taxonomy."""
        request = None
        try:
            req = getattr(exc, "request", None)
            if isinstance(req, httpx.Request):
                request = req
        except RuntimeError:
            pass

        request_id = self._extract_request_id(request=request)
        method_label = method.upper()

        if isinstance(exc, httpx.TimeoutException):
            return self._create_api_error(
                None,
                f"Request timed out during {method_label} {endpoint}: {exc}",
                error_type=type(exc).__name__,
                request_id=request_id,
                exception_class=TimeoutError,
                category="timeout",
                error_code="SDK_TIMEOUT",
                retryable=True,
            )

        if isinstance(exc, httpx.ConnectError):
            return self._create_api_error(
                None,
                f"Network error during {method_label} {endpoint}: {exc}",
                error_type=type(exc).__name__,
                request_id=request_id,
                exception_class=NetworkError,
                category="network",
                error_code="SDK_NETWORK_UNREACHABLE",
                retryable=True,
            )

        return self._create_api_error(
            None,
            f"Request failed during {method_label} {endpoint}: {exc}",
            error_type=type(exc).__name__,
            request_id=request_id,
            exception_class=APIError,
            category="unknown",
            error_code="SDK_UNKNOWN_ERROR",
            retryable=False,
        )

    def _raise_api_error(
        self,
        status: int | None,
        message: str,
        error_type: str | None = None,
        *,
        payload: Any | None = None,
        request_id: str | None = None,
        exception_class: type[APIError] | None = None,
        category: str | None = None,
        error_code: str | None = None,
        retryable: bool | None = None,
    ) -> NoReturn:
        """Raise appropriate exception with rich context."""
        raise self._create_api_error(
            status,
            message,
            error_type=error_type,
            payload=payload,
            request_id=request_id,
            exception_class=exception_class,
            category=category,
            error_code=error_code,
            retryable=retryable,
        )

    def list_language_models(self, force_refresh: bool = False) -> list[dict[str, Any]]:
        """List available language models with TTL caching.

        Args:
            force_refresh: Whether to ignore cache and fetch fresh list.

        Returns:
            List of available language models.
        """
        now = time.monotonic()
        if not force_refresh and self._lm_cache is not None:
            if now - self._lm_cache_time < self._lm_cache_ttl:
                return self._lm_cache

        models = self._request("GET", "/language-models") or []
        self._lm_cache = models
        self._lm_cache_time = now
        return models

    def close(self) -> None:
        """Close the HTTP client."""
        if hasattr(self, "http_client") and self.http_client and not self._session_scoped and not self._parent_client:
            self.http_client.close()

    def __enter__(self) -> "BaseClient":
        """Context manager entry."""
        return self

    def __exit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_val: BaseException | None,
        _exc_tb: Any,
    ) -> None:
        """Context manager exit."""
        # Only close if this is not session-scoped
        if not self._session_scoped:
            self.close()
