#!/usr/bin/env python3
"""mTLS policy helpers for SDK HTTP clients."""

from __future__ import annotations

import json
import os
import ssl
from functools import lru_cache
from typing import Any
from urllib.parse import SplitResult, urlsplit

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

_TRUE_VALUES = {"1", "true", "yes", "on"}
_FALSE_VALUES = {"0", "false", "no", "off", ""}


class MTLSConfigError(ValueError):
    """Raised when mTLS configuration is invalid."""


class MTLSCertificateSet(BaseModel):
    """Certificate bundle used for mTLS client authentication."""

    client_cert_path: str
    client_key_path: str
    client_key_password: str | None = None
    ca_bundle_path: str | None = None

    model_config = ConfigDict(extra="forbid")

    def validate_paths(self) -> None:
        """Validate certificate paths on disk."""
        for label, path in (
            ("client certificate", self.client_cert_path),
            ("client key", self.client_key_path),
        ):
            if not path:
                raise MTLSConfigError(f"Missing {label} path")
            if not os.path.exists(path):
                raise MTLSConfigError(f"{label} not found: {path}")
            if not os.path.isfile(path):
                raise MTLSConfigError(f"{label} path is not a file: {path}")

        if self.ca_bundle_path:
            if not os.path.exists(self.ca_bundle_path):
                raise MTLSConfigError(f"CA bundle not found: {self.ca_bundle_path}")
            if not os.path.isfile(self.ca_bundle_path):
                raise MTLSConfigError(f"CA bundle path is not a file: {self.ca_bundle_path}")


class MTLSServiceProfile(BaseModel):
    """mTLS profile for a specific target service."""

    name: str
    base_url: str
    enabled: bool = True
    verify_server_cert: bool = True
    certificate_set: MTLSCertificateSet

    model_config = ConfigDict(extra="forbid")

    @field_validator("base_url")
    @classmethod
    def normalize_base_url(cls, value: str) -> str:
        """Normalize and validate base URL used for profile matching."""
        normalized = value.strip().rstrip("/")
        if not normalized:
            raise MTLSConfigError("base_url must be a non-empty URL")

        parsed = urlsplit(normalized)
        if parsed.scheme != "https":
            raise MTLSConfigError("base_url must use https scheme")
        if not parsed.hostname:
            raise MTLSConfigError("base_url must include scheme and host")

        try:
            _ = parsed.port
        except ValueError as exc:
            raise MTLSConfigError(f"Invalid base_url port in profile URL: {normalized}") from exc
        return normalized


class MTLSPolicy(BaseModel):
    """Global mTLS policy that holds all service profiles."""

    enabled: bool = False
    default_profile: str | None = None
    profiles: list[MTLSServiceProfile] = Field(default_factory=list)

    model_config = ConfigDict(extra="forbid")

    def get_profile_for_url(self, url: str) -> MTLSServiceProfile | None:
        """Resolve profile for URL by direct prefix match or default profile."""
        if not self.enabled:
            return None

        normalized_url = url.rstrip("/")
        for profile in self.profiles:
            if not profile.enabled:
                continue
            if _url_matches_profile(normalized_url, profile.base_url):
                return profile

        if self.default_profile:
            for profile in self.profiles:
                if profile.name == self.default_profile and profile.enabled:
                    return profile
            raise MTLSConfigError(f"Default mTLS profile not found: {self.default_profile}")

        raise MTLSConfigError(f"No mTLS profile matches URL: {url}")


def _effective_port(parsed_url: SplitResult) -> int | None:
    """Resolve explicit or scheme default port for URL comparison."""
    try:
        explicit_port = parsed_url.port
    except ValueError as exc:
        raise MTLSConfigError(f"Invalid URL port: {parsed_url.geturl()}") from exc

    if explicit_port is not None:
        return explicit_port
    if parsed_url.scheme == "https":
        return 443
    if parsed_url.scheme == "http":
        return 80
    return None


def _url_matches_profile(target_url: str, profile_base_url: str) -> bool:
    """Return whether the target URL matches profile scheme/host/port/path."""
    target = urlsplit(target_url)
    profile = urlsplit(profile_base_url)

    if not target.scheme or not target.hostname:
        return False
    if not profile.scheme or not profile.hostname:
        return False

    if target.scheme != profile.scheme:
        return False
    if target.hostname.lower() != profile.hostname.lower():
        return False
    if _effective_port(target) != _effective_port(profile):
        return False

    target_path = target.path or "/"
    profile_path = profile.path or "/"
    if profile_path == "/":
        return True
    return target_path == profile_path or target_path.startswith(f"{profile_path}/")


def _parse_profiles(raw_profiles: Any) -> list[MTLSServiceProfile]:
    """Parse and validate mTLS profiles from JSON payload."""
    if raw_profiles is None:
        return []
    if not isinstance(raw_profiles, list):
        raise MTLSConfigError("MTLS profiles must be a list")
    return [MTLSServiceProfile.model_validate(profile) for profile in raw_profiles]


def _parse_mtls_enabled(raw_value: str | None) -> bool:
    """Parse AIP_MTLS_ENABLED using explicit true/false sets."""
    normalized = (raw_value or "").strip().lower()
    if normalized in _TRUE_VALUES:
        return True
    if normalized in _FALSE_VALUES:
        return False
    raise MTLSConfigError(f"Invalid AIP_MTLS_ENABLED value: {raw_value}")


@lru_cache(maxsize=1)
def load_mtls_policy_from_env() -> MTLSPolicy:
    """Load mTLS policy from environment variables."""
    enabled = _parse_mtls_enabled(os.getenv("AIP_MTLS_ENABLED", "false"))

    if not enabled:
        return MTLSPolicy(enabled=False, default_profile=None, profiles=[])

    default_profile = os.getenv("AIP_MTLS_DEFAULT_PROFILE")
    profiles_json = os.getenv("AIP_MTLS_PROFILES_JSON", "")

    profiles: list[MTLSServiceProfile] = []
    if profiles_json:
        try:
            parsed_profiles = json.loads(profiles_json)
        except json.JSONDecodeError as exc:
            raise MTLSConfigError(f"Invalid AIP_MTLS_PROFILES_JSON: {exc}") from exc
        profiles = _parse_profiles(parsed_profiles)

    policy = MTLSPolicy(enabled=enabled, default_profile=default_profile, profiles=profiles)
    if policy.enabled and not policy.profiles:
        raise MTLSConfigError("mTLS enabled but no profiles configured")
    return policy


def load_mtls_policy_safe() -> MTLSPolicy:
    """Load mTLS policy and normalize model validation errors."""
    try:
        return load_mtls_policy_from_env()
    except ValidationError as exc:
        raise MTLSConfigError(str(exc)) from exc


def reset_mtls_policy_cache() -> None:
    """Reset cached mTLS policy."""
    load_mtls_policy_from_env.cache_clear()


def validate_mtls_policy(policy: MTLSPolicy, selected_profile: MTLSServiceProfile | None = None) -> None:
    """Validate active mTLS policy and certificate path references."""
    if not policy.enabled:
        return

    if not policy.profiles:
        raise MTLSConfigError("mTLS enabled but no profiles configured")

    if selected_profile is not None:
        validate_selected_profile(selected_profile)
        return

    for profile in policy.profiles:
        if profile.enabled:
            validate_selected_profile(profile)


def validate_selected_profile(profile: MTLSServiceProfile) -> None:
    """Validate a selected profile before creating an SSL context."""
    if not profile.verify_server_cert:
        raise MTLSConfigError("mTLS profiles must verify server certificates")
    profile.certificate_set.validate_paths()


def _build_ssl_context(profile: MTLSServiceProfile) -> ssl.SSLContext:
    """Build SSL context using the selected mTLS service profile."""
    context = ssl.create_default_context()
    context.minimum_version = ssl.TLSVersion.TLSv1_2

    try:
        context.load_cert_chain(
            certfile=profile.certificate_set.client_cert_path,
            keyfile=profile.certificate_set.client_key_path,
            password=profile.certificate_set.client_key_password,
        )
    except OSError as exc:
        raise MTLSConfigError(
            "Failed loading client certificate material "
            f"for profile '{profile.name}' "
            f"(cert={profile.certificate_set.client_cert_path}, "
            f"key={profile.certificate_set.client_key_path}): {exc}"
        ) from exc

    if profile.certificate_set.ca_bundle_path:
        try:
            context.load_verify_locations(cafile=profile.certificate_set.ca_bundle_path)
        except OSError as exc:
            raise MTLSConfigError(
                "Failed loading CA bundle "
                f"for profile '{profile.name}' "
                f"(ca={profile.certificate_set.ca_bundle_path}): {exc}"
            ) from exc

    context.check_hostname = True
    context.verify_mode = ssl.CERT_REQUIRED
    return context


def resolve_mtls_verify_setting(
    base_url: str | None,
    fallback_verify: bool | str | ssl.SSLContext | None = True,
) -> bool | str | ssl.SSLContext | None:
    """Resolve the HTTPX verify setting, enabling mTLS when configured."""
    policy = load_mtls_policy_safe()
    if not policy.enabled:
        return fallback_verify

    profile = policy.get_profile_for_url(base_url or "")
    if profile is None:
        return fallback_verify

    validate_mtls_policy(policy, profile)
    return _build_ssl_context(profile)
