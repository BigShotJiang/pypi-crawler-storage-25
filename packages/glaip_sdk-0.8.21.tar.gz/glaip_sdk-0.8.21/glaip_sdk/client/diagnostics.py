"""Typed diagnostics for SDK client health and connectivity checks.

This module provides typed diagnostics results that replace bool-only health
checks with actionable transport/auth/readiness outcomes.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class DiagnosticsStatus(Enum):
    """Status outcome for diagnostics probes."""

    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    TRANSPORT_ERROR = "transport_error"
    AUTH_ERROR = "auth_error"
    READINESS_ERROR = "readiness_error"


@dataclass
class DiagnosticsResult:
    """Typed result for diagnostics probe operations.

    Attributes:
        status: The overall diagnostics status.
        error_code: Canonical error code if unhealthy, None if healthy.
        retryable: Whether the failure is retryable.
        latency_ms: Time taken for the probe in milliseconds.
        request_id: Correlation ID for the probe request.
        probe: The endpoint used for the diagnostics probe.
        message: Human-readable message describing the diagnostics outcome.
    """

    status: DiagnosticsStatus
    error_code: str | None
    retryable: bool
    latency_ms: float
    request_id: str
    probe: str = "/health-check"
    message: str = ""
