"""Guardrails package for content filtering and safety checks.

This package provides modular guardrail engines and managers for filtering
harmful content in AI agent interactions. All components support lazy loading
from aip-agents to maintain Principle VII compliance.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from enum import StrEnum
from typing import Any

from glaip_sdk.utils.aip_imports import import_aip_symbol


class ImportableName(StrEnum):
    """Names of the importable attributes."""

    GUARDRAIL_MANAGER = "GuardrailManager"
    PHRASE_MATCHER_ENGINE = "PhraseMatcherEngine"
    NEMO_GUARDRAIL_ENGINE = "NemoGuardrailEngine"
    GUARDRAIL_MODE = "GuardrailMode"


# Lazy loading support - components are only imported when actually used
_LAZY_IMPORTS = {}


def __getattr__(name: str) -> Any:
    """Lazy import to avoid eager loading of optional aip-agents dependency.

    This function is called by Python when an attribute is not found in the module.
    It performs the import from aip_agents.guardrails at runtime.

    Args:
        name: The name of the attribute to get.

    Returns:
        The attribute value from aip_agents.

    Raises:
        AttributeError: If the attribute doesn't exist.
        ImportError: If aip-agents is not installed but a component is accessed.
    """
    if name in _LAZY_IMPORTS:
        return _LAZY_IMPORTS[name]

    if name == ImportableName.GUARDRAIL_MANAGER:
        guardrail_manager = import_aip_symbol("GuardrailManager")

        _LAZY_IMPORTS[name] = guardrail_manager
        return guardrail_manager

    if name == ImportableName.PHRASE_MATCHER_ENGINE:
        phrase_matcher_engine = import_aip_symbol("PhraseMatcherEngine")

        _LAZY_IMPORTS[name] = phrase_matcher_engine
        return phrase_matcher_engine

    if name == ImportableName.NEMO_GUARDRAIL_ENGINE:
        nemo_guardrail_engine = import_aip_symbol("NemoGuardrailEngine")

        _LAZY_IMPORTS[name] = nemo_guardrail_engine
        return nemo_guardrail_engine

    if name == ImportableName.GUARDRAIL_MODE:
        guardrail_mode = import_aip_symbol("GuardrailMode")

        _LAZY_IMPORTS[name] = guardrail_mode
        return guardrail_mode

    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
