"""Helpers for loading AIP integration symbols with temporary fallbacks."""

from __future__ import annotations

import importlib
import os
from typing import Any


IMPORT_MODE_ENV_VAR = "GLAIP_SDK_AIP_IMPORT_MODE"
_VALID_IMPORT_MODES = {"auto", "integration", "legacy"}

_INTEGRATION_AGENT = "aip_agents.integration.agent"
_INTEGRATION_HITL = "aip_agents.integration.hitl"
_INTEGRATION_GUARDRAILS = "aip_agents.integration.guardrails"
_INTEGRATION_PTC = "aip_agents.integration.ptc"
_INTEGRATION_SKILLS = "aip_agents.integration.skills"
_INTEGRATION_STORAGE = "aip_agents.integration.storage"

_LEGACY_PTC = "aip_agents.ptc"
_SCHEMA_HITL = "aip_agents.schema.hitl"

_SYMBOL_MODULES: dict[str, tuple[str, ...]] = {
    "LangGraphReactAgent": (_INTEGRATION_AGENT, "aip_agents.agent"),
    "ApprovalManager": (_INTEGRATION_HITL, "aip_agents.agent.hitl.manager"),
    "BasePromptHandler": (_INTEGRATION_HITL, "aip_agents.agent.hitl.prompt.base"),
    "ApprovalDecision": (_INTEGRATION_HITL, _SCHEMA_HITL),
    "ApprovalDecisionType": (_INTEGRATION_HITL, _SCHEMA_HITL),
    "ApprovalRequest": (_INTEGRATION_HITL, _SCHEMA_HITL),
    "GuardrailManager": (_INTEGRATION_GUARDRAILS, "aip_agents.guardrails.manager"),
    "PhraseMatcherEngine": (
        _INTEGRATION_GUARDRAILS,
        "aip_agents.guardrails.engines.phrase_matcher",
    ),
    "NemoGuardrailEngine": (_INTEGRATION_GUARDRAILS, "aip_agents.guardrails.engines.nemo"),
    "GuardrailMode": (_INTEGRATION_GUARDRAILS, "aip_agents.guardrails.schemas"),
    "PromptConfig": (_INTEGRATION_PTC, _LEGACY_PTC),
    "PTCSandboxConfig": (_INTEGRATION_PTC, _LEGACY_PTC),
    "PTCCustomToolConfig": (_INTEGRATION_PTC, _LEGACY_PTC),
    "PTCCustomToolValidationError": (_INTEGRATION_PTC, _LEGACY_PTC),
    "check_name_collisions": (_INTEGRATION_PTC, "aip_agents.ptc.custom_tools"),
    "validate_custom_tool_config": (_INTEGRATION_PTC, "aip_agents.ptc.custom_tools"),
    "sanitize_function_name": (_INTEGRATION_PTC, "aip_agents.ptc.naming"),
    "file_tool": (_INTEGRATION_PTC, "aip_agents.ptc.tool_def_helpers"),
    "package_tool": (_INTEGRATION_PTC, "aip_agents.ptc.tool_def_helpers"),
    "Skill": (_INTEGRATION_SKILLS, "aip_agents.skills"),
    "InMemoryStorageProvider": (_INTEGRATION_STORAGE, "aip_agents.storage.providers.memory"),
    "MinioConfig": (_INTEGRATION_STORAGE, "aip_agents.storage.clients.minio_client"),
    "MinioObjectStorage": (_INTEGRATION_STORAGE, "aip_agents.storage.clients.minio_client"),
    "ObjectStorageProvider": (_INTEGRATION_STORAGE, "aip_agents.storage.providers.object_storage"),
    "ToolOutputConfig": (
        _INTEGRATION_STORAGE,
        "aip_agents.utils.langgraph.tool_output_management",
    ),
    "ToolOutputManager": (
        _INTEGRATION_STORAGE,
        "aip_agents.utils.langgraph.tool_output_management",
    ),
}


def _is_integration_module(module_name: str) -> bool:
    return module_name == "aip_agents.integration" or module_name.startswith("aip_agents.integration.")


def _is_missing_target_module(module_name: str, exc: ModuleNotFoundError) -> bool:
    missing_name = exc.name
    if not missing_name:  # pragma: no cover - defensive fallback
        return False
    return missing_name == module_name or module_name.startswith(f"{missing_name}.")


def _import_module_candidate(module_name: str) -> tuple[Any | None, Exception | None]:
    try:
        return importlib.import_module(module_name), None
    except ModuleNotFoundError as exc:
        if _is_integration_module(module_name) and not _is_missing_target_module(module_name, exc):
            raise  # pragma: no cover - defensive re-raise for integration modules
        return None, exc
    except ImportError as exc:
        if _is_integration_module(module_name):
            raise  # pragma: no cover - defensive re-raise for integration modules
        return None, exc  # pragma: no cover - non-integration ImportError fallback


def _get_module_attr(module: Any, module_name: str, name: str) -> tuple[Any | None, Exception | None]:
    try:
        return getattr(module, name), None
    except AttributeError as exc:
        if _is_integration_module(module_name):
            raise ImportError(f"{module_name} is present but does not export {name!r}") from exc  # pragma: no cover
        return None, exc  # pragma: no cover - non-integration AttributeError fallback


def get_import_mode() -> str:
    """Return the configured import mode for AIP integration lookups."""
    mode = os.getenv(IMPORT_MODE_ENV_VAR, "auto").strip().lower() or "auto"
    if mode not in _VALID_IMPORT_MODES:
        choices = ", ".join(sorted(_VALID_IMPORT_MODES))
        raise ValueError(f"{IMPORT_MODE_ENV_VAR} must be one of: {choices}")
    return mode


def _select_modules(module_names: tuple[str, ...]) -> tuple[str, ...]:
    """Order/filter module candidates according to the configured import mode."""
    mode = get_import_mode()
    if mode == "auto":
        return module_names

    integration_modules = tuple(name for name in module_names if _is_integration_module(name))
    legacy_modules = tuple(name for name in module_names if not _is_integration_module(name))

    if mode == "integration":
        return integration_modules or module_names

    return legacy_modules or module_names


def import_attr(name: str, *module_names: str) -> Any:
    """Return the first matching attribute from the provided module names."""
    last_error: Exception | None = None
    selected_modules = _select_modules(tuple(module_names))

    for module_name in selected_modules:
        module, error = _import_module_candidate(module_name)
        if error is not None:
            last_error = error
            continue

        value, error = _get_module_attr(module, module_name, name)
        if error is None:
            return value
        last_error = error  # pragma: no cover - attribute not in module, try next

    modules = ", ".join(selected_modules)
    raise ImportError(f"Unable to import {name!r} from any of: {modules}") from last_error


def import_aip_symbol(name: str) -> Any:
    """Return a known AIP integration symbol using the centralized fallback map."""
    module_names = _SYMBOL_MODULES.get(name)
    if module_names is None:
        raise ImportError(f"No AIP import mapping registered for {name!r}")
    return import_attr(name, *module_names)
