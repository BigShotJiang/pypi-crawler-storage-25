# Notice

ScaleMAP is derived from `umap-learn` by Leland McInnes and contributors.

The upstream project is available at:

https://github.com/lmcinnes/umap

The upstream UMAP source is licensed under the BSD 3-Clause License. This
package contains modified portions of that source. The upstream authors and
contributors do not endorse this modified package.
