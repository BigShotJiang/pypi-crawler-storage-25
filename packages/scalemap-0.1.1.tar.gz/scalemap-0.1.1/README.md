# ScaleMAP

ScaleMAP is a modification of UMAP that incorporates local scale into the embedding.

This package is currently a quick release. It is derived from `umap-learn` and keeps the same scikit-learn-style estimator interface.

## Installation

```bash
pip install scalemap
```

## Usage

```python
import scaleMAP

mapper = scaleMAP.UMAP(scalemap=True, scale_lambda=1.0)
embedding = mapper.fit_transform(data)
```

The distribution name on PyPI is `scalemap`; the import package is `scaleMAP`.
If you don't set scalemap=True, it will behave just like UMAP. 
scale_lambda=1.0 sets the scaleMAP behavior to be fully on. You can interpolate between fully on and fully off by setting values between 0.0 and 1.0.

## Attribution

ScaleMAP is derived from `umap-learn` by Leland McInnes and contributors. The upstream project is available at:

https://github.com/lmcinnes/umap

The upstream UMAP package is BSD 3-Clause licensed. ScaleMAP is distributed under the same license. See `LICENSE` and `NOTICE.md`.

If you use this package in scientific work, cite the original UMAP work as appropriate:

```bibtex
@article{mcinnes2018umap-software,
  title={UMAP: Uniform Manifold Approximation and Projection},
  author={McInnes, Leland and Healy, John and Saul, Nathaniel and Grossberger, Lukas},
  journal={The Journal of Open Source Software},
  volume={3},
  number={29},
  pages={861},
  year={2018}
}
```
