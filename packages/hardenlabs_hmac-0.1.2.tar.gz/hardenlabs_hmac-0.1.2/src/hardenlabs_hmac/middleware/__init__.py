"""HardenHMAC middleware integrations."""
