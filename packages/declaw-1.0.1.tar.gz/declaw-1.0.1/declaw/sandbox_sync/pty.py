from __future__ import annotations

from typing import Any, Dict, Optional

from declaw.api.client import ApiClient
from declaw.sandbox.commands.models import PtySize
from declaw.sandbox_sync.commands.command_handle import CommandHandle

DEFAULT_USER = "user"


class Pty:
    """Module for interacting with PTYs (pseudo-terminals) in the sandbox."""

    def __init__(self, sandbox_id: str, client: ApiClient):
        self._sandbox_id = sandbox_id
        self._client = client

    def create(
        self,
        size: PtySize = PtySize(),
        user: str = DEFAULT_USER,
        cwd: Optional[str] = None,
        envs: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = 60,
        request_timeout: Optional[float] = None,
    ) -> CommandHandle:
        body: Dict[str, Any] = {
            "size": size.to_dict(),
            "user": user,
        }
        if cwd:
            body["cwd"] = cwd
        if envs:
            body["envs"] = envs
        if timeout is not None:
            body["timeout"] = timeout

        resp = self._client.post(
            f"/sandboxes/{self._sandbox_id}/pty",
            json=body,
            timeout=request_timeout,
        )
        data = resp.json()
        return CommandHandle(
            pid=data["pid"],
            sandbox_id=self._sandbox_id,
            client=self._client,
        )

    def kill(self, pid: int, request_timeout: Optional[float] = None) -> bool:
        resp = self._client.delete(
            f"/sandboxes/{self._sandbox_id}/pty/{pid}",
            timeout=request_timeout,
        )
        return bool(resp.json().get("killed", False))

    def send_stdin(self, pid: int, data: bytes, request_timeout: Optional[float] = None) -> None:
        self._client.post(
            f"/sandboxes/{self._sandbox_id}/pty/{pid}/stdin",
            json={"data": data.decode("utf-8", errors="replace")},
            timeout=request_timeout,
        )

    def resize(self, pid: int, size: PtySize, request_timeout: Optional[float] = None) -> None:
        self._client.patch(
            f"/sandboxes/{self._sandbox_id}/pty/{pid}",
            json={"size": size.to_dict()},
            timeout=request_timeout,
        )
