"""
Declaw -- Secure sandboxes for AI agents.

Execute code, intercept everything.
"""

from declaw.account import AccountClient
from declaw.account_async import AsyncAccountClient
from declaw.account_models import (
    AccountInfo,
    AccountOverview,
    DailyUsage,
    DepositInfo,
    UsageSummary,
    WalletInfo,
)
from declaw.api.async_client import AsyncApiClient
from declaw.api.client import ApiClient
from declaw.connection_config import ConnectionConfig
from declaw.exceptions import (
    AuthenticationException,
    BuildException,
    CommandExitException,
    FileUploadException,
    GitAuthException,
    GitUpstreamException,
    InsufficientBalanceException,
    InvalidArgumentException,
    NotEnoughSpaceException,
    NotFoundException,
    RateLimitException,
    SandboxError,
    SandboxException,
    TemplateException,
    TimeoutException,
)
from declaw.sandbox.commands.models import (
    CommandResult,
    ProcessInfo,
    PtyOutput,
    PtySize,
    Stderr,
    Stdout,
)
from declaw.sandbox.filesystem.models import (
    EntryInfo,
    FilesystemEvent,
    FilesystemEventType,
    FileType,
    WriteEntry,
    WriteInfo,
)
from declaw.sandbox.models import (
    SandboxInfo,
    SandboxLifecycle,
    SandboxMetrics,
    SandboxQuery,
    SandboxState,
    Snapshot,
    SnapshotInfo,
)
from declaw.sandbox.network import ALL_TRAFFIC, SandboxNetworkOpts, domain_matches
from declaw.sandbox_async.commands.command_handle import AsyncCommandHandle
from declaw.sandbox_async.filesystem.watch_handle import AsyncWatchHandle
from declaw.sandbox_async.main import AsyncSandbox
from declaw.sandbox_async.paginator import AsyncSandboxPaginator, AsyncSnapshotPaginator
from declaw.sandbox_sync.commands.command_handle import CommandHandle
from declaw.sandbox_sync.filesystem.watch_handle import WatchHandle
from declaw.sandbox_sync.main import Sandbox
from declaw.sandbox_sync.paginator import SandboxPaginator, SnapshotPaginator
from declaw.security.audit import AuditConfig, AuditEntry
from declaw.security.code_security import CodeSecurityConfig
from declaw.security.env import EnvSecurityConfig, SecureEnvVar
from declaw.security.injection import (
    InjectionAction,
    InjectionDefenseConfig,
    InjectionSensitivity,
)
from declaw.security.invisible_text import InvisibleTextConfig
from declaw.security.network_policy import NetworkPolicy
from declaw.security.pii import PIIConfig, PIIType, RedactionAction
from declaw.security.pii_handler import GuardrailsClient, PIIHandler
from declaw.security.policy import SecurityPolicy
from declaw.security.toxicity import ToxicityConfig
from declaw.security.transformations import TransformationRule, TransformDirection
from declaw.template.main import BuildInfo, CopyItem, TemplateBase, TemplateBuildStatus
from declaw.template_async.main import AsyncTemplate
from declaw.template_sync.main import Template

__all__ = [
    # Connection
    "ConnectionConfig",
    # Exceptions
    "SandboxError",
    "SandboxException",
    "TimeoutException",
    "NotFoundException",
    "AuthenticationException",
    "InvalidArgumentException",
    "NotEnoughSpaceException",
    "TemplateException",
    "BuildException",
    "FileUploadException",
    "GitAuthException",
    "GitUpstreamException",
    "CommandExitException",
    "InsufficientBalanceException",
    "RateLimitException",
    # Sandbox models
    "SandboxInfo",
    "SandboxState",
    "SandboxMetrics",
    "SandboxQuery",
    "SandboxLifecycle",
    "Snapshot",
    "SnapshotInfo",
    # Command models
    "CommandResult",
    "Stdout",
    "Stderr",
    "PtyOutput",
    "PtySize",
    "ProcessInfo",
    # Filesystem models
    "EntryInfo",
    "FileType",
    "WriteInfo",
    "WriteEntry",
    "FilesystemEvent",
    "FilesystemEventType",
    # Network
    "ALL_TRAFFIC",
    "SandboxNetworkOpts",
    "domain_matches",
    # Security
    "SecurityPolicy",
    "PIIConfig",
    "PIIType",
    "RedactionAction",
    "PIIHandler",
    "GuardrailsClient",
    "InjectionDefenseConfig",
    "InjectionAction",
    "InjectionSensitivity",
    "TransformationRule",
    "TransformDirection",
    "NetworkPolicy",
    "AuditConfig",
    "AuditEntry",
    "EnvSecurityConfig",
    "SecureEnvVar",
    "ToxicityConfig",
    "CodeSecurityConfig",
    "InvisibleTextConfig",
    # Sync sandbox
    "Sandbox",
    "CommandHandle",
    "WatchHandle",
    "SandboxPaginator",
    "SnapshotPaginator",
    # Async sandbox
    "AsyncSandbox",
    "AsyncCommandHandle",
    "AsyncWatchHandle",
    "AsyncSandboxPaginator",
    "AsyncSnapshotPaginator",
    # Templates
    "Template",
    "AsyncTemplate",
    "TemplateBase",
    "BuildInfo",
    "TemplateBuildStatus",
    "CopyItem",
    # API clients
    "ApiClient",
    "AsyncApiClient",
    # Account management
    "AccountClient",
    "AsyncAccountClient",
    "AccountInfo",
    "AccountOverview",
    "DailyUsage",
    "DepositInfo",
    "UsageSummary",
    "WalletInfo",
]
