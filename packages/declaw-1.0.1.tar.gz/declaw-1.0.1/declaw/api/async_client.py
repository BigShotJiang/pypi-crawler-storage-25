from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional

import httpx

from declaw.connection_config import ConnectionConfig
from declaw.exceptions import (
    AuthenticationException,
    InsufficientBalanceException,
    InvalidArgumentException,
    NotFoundException,
    RateLimitException,
    SandboxException,
    TimeoutException,
)

_STATUS_MAP = {
    401: AuthenticationException,
    403: AuthenticationException,
    404: NotFoundException,
    408: TimeoutException,
    422: InvalidArgumentException,
    402: InsufficientBalanceException,
    429: RateLimitException,
}


class AsyncApiClient:
    """Async HTTP client for the Declaw API."""

    def __init__(
        self,
        config: Optional[ConnectionConfig] = None,
        *,
        max_retries: int = 3,
        retry_delay: float = 0.5,
    ):
        self.config = config or ConnectionConfig()
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._client = httpx.AsyncClient(
            base_url=self.config.api_url or "",
            timeout=self.config.request_timeout or 30.0,
            headers=self._base_headers(),
        )

    def _base_headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        return headers

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.is_success:
            return
        exc_cls = _STATUS_MAP.get(response.status_code, SandboxException)
        try:
            body = response.json()
            message = body.get("message", body.get("error", response.text))
        except Exception:
            message = response.text
        if response.status_code == 429:
            retry_after: Optional[float] = None
            raw = response.headers.get("Retry-After")
            if raw is not None:
                try:
                    retry_after = float(raw)
                except ValueError:
                    pass
            raise RateLimitException(f"HTTP 429: {message}", retry_after=retry_after)
        if response.status_code == 402:
            try:
                wallet_type = response.json().get("wallet_type", "")
            except Exception:
                wallet_type = ""
            raise InsufficientBalanceException(f"HTTP 402: {message}", wallet_type=wallet_type)
        raise exc_cls(f"HTTP {response.status_code}: {message}")

    async def _request_with_retry(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: Optional[Dict[str, Any]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> httpx.Response:
        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries):
            try:
                response = await self._client.request(
                    method,
                    path,
                    json=json,
                    params=params,
                    content=content,
                    headers=headers,
                    timeout=timeout,
                )
                if response.status_code >= 500 and attempt < self._max_retries - 1:
                    await asyncio.sleep(self._retry_delay * (attempt + 1))
                    continue
                self._raise_for_status(response)
                return response
            except (httpx.ConnectError, httpx.ReadTimeout) as e:
                last_exc = e
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(self._retry_delay * (attempt + 1))
                    continue
                raise TimeoutException(f"Connection failed after {self._max_retries} retries: {e}")
        raise SandboxException(f"Request failed: {last_exc}")

    async def get(
        self, path: str, *, params: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None
    ) -> httpx.Response:
        return await self._request_with_retry("GET", path, params=params, timeout=timeout)

    async def post(
        self,
        path: str,
        *,
        json: Any = None,
        params: Optional[Dict[str, Any]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> httpx.Response:
        return await self._request_with_retry(
            "POST",
            path,
            json=json,
            params=params,
            content=content,
            headers=headers,
            timeout=timeout,
        )

    async def patch(
        self, path: str, *, json: Any = None, timeout: Optional[float] = None
    ) -> httpx.Response:
        return await self._request_with_retry("PATCH", path, json=json, timeout=timeout)

    async def delete(self, path: str, *, timeout: Optional[float] = None) -> httpx.Response:
        return await self._request_with_retry("DELETE", path, timeout=timeout)

    async def put(
        self,
        path: str,
        *,
        json: Any = None,
        params: Optional[Dict[str, Any]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> httpx.Response:
        return await self._request_with_retry(
            "PUT",
            path,
            json=json,
            params=params,
            content=content,
            headers=headers,
            timeout=timeout,
        )

    async def close(self) -> None:
        await self._client.aclose()
