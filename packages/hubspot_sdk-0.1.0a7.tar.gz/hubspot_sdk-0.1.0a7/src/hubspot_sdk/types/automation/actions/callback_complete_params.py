# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from ...._utils import PropertyInfo
from ..test_request_context_param import TestRequestContextParam
from ..agent_request_context_param import AgentRequestContextParam
from ..copilot_request_context_param import CopilotRequestContextParam
from ..workflows_request_context_param import WorkflowsRequestContextParam
from ..standalone_request_context_param import StandaloneRequestContextParam

__all__ = ["CallbackCompleteParams", "RequestContext"]


class CallbackCompleteParams(TypedDict, total=False):
    output_fields: Required[Annotated[Dict[str, str], PropertyInfo(alias="outputFields")]]
    """
    Contains the output fields associated with the callback, with each field
    represented as a key-value pair.
    """

    typed_outputs: Required[Annotated[object, PropertyInfo(alias="typedOutputs")]]
    """Holds the typed outputs related to the callback, structured as an object."""

    failure_reason_type: Annotated[str, PropertyInfo(alias="failureReasonType")]
    """Indicates the reason for the failure of a callback completion."""

    request_context: Annotated[RequestContext, PropertyInfo(alias="requestContext")]
    """
    Specifies the context in which the request is made, which can be one of several
    predefined contexts.
    """


RequestContext: TypeAlias = Union[
    WorkflowsRequestContextParam,
    AgentRequestContextParam,
    CopilotRequestContextParam,
    StandaloneRequestContextParam,
    TestRequestContextParam,
]
