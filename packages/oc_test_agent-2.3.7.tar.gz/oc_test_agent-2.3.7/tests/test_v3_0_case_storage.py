"""
用例级存储功能单元测试

版本: v3.0
"""

import pytest
import sys
import os
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestPytestOutputParser:
    """pytest输出解析测试"""

    def test_parse_passed_case(self):
        """测试解析PASSED用例"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = "tests/test_example.py::TestClass::test_example PASSED"
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 1
            assert results[0].case_id == "test_example"
            assert results[0].status == "passed"

    def test_parse_failed_case(self):
        """测试解析FAILED用例"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = "tests/test_example.py::TestClass::test_example FAILED"
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 1
            assert results[0].status == "failed"
            assert results[0].error_message is not None

    def test_parse_error_case(self):
        """测试解析ERROR用例"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = "tests/test_example.py::TestClass::test_example ERROR"
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 1
            assert results[0].status == "error"

    def test_parse_multiple_cases(self):
        """测试解析多个用例"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = """
tests/test_example.py::TestClass::test_one PASSED
tests/test_example.py::TestClass::test_two FAILED
tests/test_example.py::TestClass::test_three PASSED
            """
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 3
            assert results[0].status == "passed"
            assert results[1].status == "failed"
            assert results[2].status == "passed"

    def test_parse_skipped_case(self):
        """测试解析SKIPPED用例"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = "tests/test_example.py::TestClass::test_example SKIPPED"
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 1
            assert results[0].status == "skipped"

    def test_parse_empty_output(self):
        """测试解析空输出"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = ""
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 0

    def test_parse_no_match_lines(self):
        """测试解析无匹配行"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = "Some random text without test results"
            results = storage.parse_pytest_output(output, "test-123")
            
            assert len(results) == 0


class TestSaveCaseResult:
    """保存用例结果测试"""

    def test_save_case_result(self):
        """测试保存用例结果"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result = TestCaseResult(
                id="case-1",
                test_id="test-123",
                case_id="test_example",
                case_name="tests/test_example.py::TestClass::test_example",
                status="passed",
                duration=1.5,
                executed_at=datetime.now()
            )
            
            case_id = storage.save_case_result(result)
            assert case_id == "case-1"

    def test_save_batch_case_results(self):
        """测试批量保存用例结果"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            output = """
tests/test_example.py::TestClass::test_one PASSED
tests/test_example.py::TestClass::test_two FAILED
            """
            
            count = storage.save_batch_case_results("test-123", output)
            assert count == 2


class TestGetCaseHistory:
    """用例历史查询测试"""

    def test_get_case_history(self):
        """测试查询用例历史"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result1 = TestCaseResult(
                id="case-1",
                test_id="test-1",
                case_id="test_example",
                case_name="test_example",
                status="passed",
                duration=1.0,
                executed_at=datetime.now()
            )
            result2 = TestCaseResult(
                id="case-2",
                test_id="test-2",
                case_id="test_example",
                case_name="test_example",
                status="failed",
                duration=2.0,
                executed_at=datetime.now()
            )
            
            storage.save_case_result(result1)
            storage.save_case_result(result2)
            
            history = storage.get_case_history("test_example", page=1, size=10)
            assert history["total"] == 2

    def test_get_case_history_empty(self):
        """测试查询不存在的用例历史"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            history = storage.get_case_history("nonexistent", page=1, size=10)
            assert history["total"] == 0


class TestCaseStatistics:
    """用例统计测试"""

    def test_get_case_statistics(self):
        """测试获取用例统计"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result1 = TestCaseResult(
                id="case-1",
                test_id="test-1",
                case_id="test_example",
                case_name="test_example",
                status="passed",
                duration=1.0,
                executed_at=datetime.now()
            )
            result2 = TestCaseResult(
                id="case-2",
                test_id="test-2",
                case_id="test_example",
                case_name="test_example",
                status="failed",
                duration=2.0,
                executed_at=datetime.now()
            )
            
            storage.save_case_result(result1)
            storage.save_case_result(result2)
            
            stats = storage.get_case_statistics("test_example")
            assert stats.case_id == "test_example"
            assert stats.total_runs == 2
            assert stats.passed_count == 1
            assert stats.failed_count == 1
            assert stats.pass_rate == 0.5


class TestBatchOperations:
    """批次操作测试"""

    def test_save_batch(self):
        """测试保存批次"""
        from src.core.result_storage_service import ResultStorageService, TestBatch
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch = TestBatch(
                id="batch-1",
                project="test-project",
                status="running",
                started_at=datetime.now()
            )
            
            batch_id = storage.save_batch(batch)
            assert batch_id == "batch-1"

    def test_get_batch(self):
        """测试获取批次"""
        from src.core.result_storage_service import ResultStorageService, TestBatch
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch = TestBatch(
                id="batch-1",
                project="test-project",
                status="running",
                started_at=datetime.now()
            )
            storage.save_batch(batch)
            
            retrieved = storage.get_batch("batch-1")
            assert retrieved is not None
            assert retrieved.id == "batch-1"

    def test_update_batch_status(self):
        """测试更新批次状态"""
        from src.core.result_storage_service import ResultStorageService, TestBatch
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch = TestBatch(
                id="batch-1",
                project="test-project",
                status="running",
                started_at=datetime.now()
            )
            storage.save_batch(batch)
            
            result = storage.update_batch_status("batch-1", "completed")
            assert result is True


class TestBugReports:
    """Bug报告测试"""

    def test_save_bug_report(self):
        """测试保存Bug报告"""
        from src.core.result_storage_service import ResultStorageService, BugReport
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            bug = BugReport(
                id="bug-1",
                test_id="test-1",
                case_id="case-1",
                title="Test failure",
                severity="high"
            )
            
            bug_id = storage.save_bug_report(bug)
            assert bug_id == "bug-1"

    def test_get_bug_reports_by_test(self):
        """测试根据测试ID查询Bug报告"""
        from src.core.result_storage_service import ResultStorageService, BugReport
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            bug = BugReport(
                id="bug-1",
                test_id="test-1",
                case_id="case-1",
                title="Test failure",
                severity="high"
            )
            storage.save_bug_report(bug)
            
            bugs = storage.get_bugs(test_id="test-1")
            assert bugs["total"] == 1
            assert len(bugs["bugs"]) == 1


class TestStatistics:
    """统计测试"""

    def test_get_statistics(self):
        """测试获取全局统计"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result1 = TestCaseResult(
                id="case-1",
                test_id="test-1",
                case_id="test_example",
                case_name="test_example",
                status="passed",
                duration=1.0,
                executed_at=datetime.now()
            )
            result2 = TestCaseResult(
                id="case-2",
                test_id="test-2",
                case_id="test_example",
                case_name="test_example",
                status="failed",
                duration=2.0,
                executed_at=datetime.now()
            )
            
            storage.save_case_result(result1)
            storage.save_case_result(result2)
            
            stats = storage.get_statistics()
            assert stats["total_tests"] == 2
            assert stats["passed"] == 1
            assert stats["failed"] == 1


class TestGetBatch:
    """获取批次测试"""

    def test_get_batch_not_found(self):
        """测试获取不存在的批次"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch = storage.get_batch("nonexistent")
            assert batch is None

    def test_get_all_batches(self):
        """测试获取所有批次"""
        from src.core.result_storage_service import ResultStorageService, TestBatch
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch1 = TestBatch(
                id="batch-1",
                project="project-1",
                status="completed",
                started_at=datetime.now()
            )
            batch2 = TestBatch(
                id="batch-2",
                project="project-2",
                status="running",
                started_at=datetime.now()
            )
            
            storage.save_batch(batch1)
            storage.save_batch(batch2)
            
            batches = storage.get_all_batches(limit=10)
            assert len(batches) >= 2


class TestBulkSaveResults:
    """批量保存结果测试"""

    def test_bulk_save_results(self):
        """测试批量保存结果"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            results = [
                TestCaseResult(
                    id="case-1",
                    test_id="test-1",
                    case_id="test_example",
                    case_name="test_example",
                    status="passed",
                    duration=1.0,
                    executed_at=datetime.now()
                ),
                TestCaseResult(
                    id="case-2",
                    test_id="test-2",
                    case_id="test_example2",
                    case_name="test_example2",
                    status="failed",
                    duration=2.0,
                    executed_at=datetime.now()
                )
            ]
            
            success = storage.bulk_save_results(results)
            assert success is True
            
            history = storage.get_case_history("test_example", page=1, size=10)
            assert history["total"] == 1

    def test_bulk_save_empty_results(self):
        """测试批量保存空列表"""
        from src.core.result_storage_service import ResultStorageService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            success = storage.bulk_save_results([])
            assert success is True


class TestValidation:
    """验证测试"""

    def test_validate_result_empty_case_id(self):
        """测试验证空case_id"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result = TestCaseResult(
                id="case-1",
                test_id="test-1",
                case_id="",
                case_name="test_example",
                status="passed",
                duration=1.0,
                executed_at=datetime.now()
            )
            
            with pytest.raises(ValueError, match="case_id不能为空"):
                storage.save_case_result(result)

    def test_validate_result_invalid_status(self):
        """测试验证无效status"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result = TestCaseResult(
                id="case-1",
                test_id="test-1",
                case_id="test_example",
                case_name="test_example",
                status="invalid_status",
                duration=1.0,
                executed_at=datetime.now()
            )
            
            with pytest.raises(ValueError, match="无效的status"):
                storage.save_case_result(result)

    def test_validate_result_negative_duration(self):
        """测试验证负数duration"""
        from src.core.result_storage_service import ResultStorageService, TestCaseResult
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            result = TestCaseResult(
                id="case-1",
                test_id="test-1",
                case_id="test_example",
                case_name="test_example",
                status="passed",
                duration=-1.0,
                executed_at=datetime.now()
            )
            
            with pytest.raises(ValueError, match="duration不能为负数"):
                storage.save_case_result(result)


class TestGetBatchesFiltered:
    """带过滤条件的批次查询测试"""

    def test_get_all_batches_by_project(self):
        """测试按项目查询批次"""
        from src.core.result_storage_service import ResultStorageService, TestBatch
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch1 = TestBatch(
                id="batch-1",
                project="project-a",
                status="completed",
                started_at=datetime.now()
            )
            batch2 = TestBatch(
                id="batch-2",
                project="project-b",
                status="running",
                started_at=datetime.now()
            )
            
            storage.save_batch(batch1)
            storage.save_batch(batch2)
            
            batches = storage.get_all_batches(project="project-a")
            assert batches["total"] >= 1

    def test_get_all_batches_by_status(self):
        """测试按状态查询批次"""
        from src.core.result_storage_service import ResultStorageService, TestBatch
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            batch1 = TestBatch(
                id="batch-1",
                project="project-a",
                status="completed",
                started_at=datetime.now()
            )
            batch2 = TestBatch(
                id="batch-2",
                project="project-b",
                status="running",
                started_at=datetime.now()
            )
            
            storage.save_batch(batch1)
            storage.save_batch(batch2)
            
            batches = storage.get_all_batches(status="running")
            assert batches["total"] >= 1


class TestBugReportsFiltered:
    """Bug报告过滤测试"""

    def test_get_bugs_by_case_id(self):
        """测试按用例ID查询Bug报告"""
        from src.core.result_storage_service import ResultStorageService, BugReport
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            bug = BugReport(
                id="bug-1",
                test_id="test-1",
                case_id="case-1",
                title="Test failure",
                severity="high"
            )
            storage.save_bug_report(bug)
            
            bugs = storage.get_bugs(case_id="case-1")
            assert bugs["total"] == 1
            assert len(bugs["bugs"]) == 1

    def test_get_bugs_by_severity(self):
        """测试按严重程度查询Bug报告"""
        from src.core.result_storage_service import ResultStorageService, BugReport
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            bug = BugReport(
                id="bug-1",
                test_id="test-1",
                case_id="case-1",
                title="Test failure",
                severity="critical"
            )
            storage.save_bug_report(bug)
            
            bugs = storage.get_bugs(severity="critical")
            assert bugs["total"] == 1

    def test_get_bugs_no_filter(self):
        """测试查询所有Bug报告"""
        from src.core.result_storage_service import ResultStorageService, BugReport
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            config = {'storage': {'database': {'path': db_path}}}
            storage = ResultStorageService(config)
            
            bug1 = BugReport(
                id="bug-1",
                test_id="test-1",
                case_id="case-1",
                title="Test failure 1",
                severity="high"
            )
            bug2 = BugReport(
                id="bug-2",
                test_id="test-2",
                case_id="case-2",
                title="Test failure 2",
                severity="low"
            )
            storage.save_bug_report(bug1)
            storage.save_bug_report(bug2)
            
            bugs = storage.get_bugs()
            assert bugs["total"] == 2
