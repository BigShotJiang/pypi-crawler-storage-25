"""
test-agent Jenkins CI/CD集成单元测试

确保代码覆盖率 > 80%
"""

import pytest
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock
from datetime import datetime
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.api import app
from src.core.jenkins_client import JenkinsClient, JenkinsTestResult, TestCaseResult
from src.api.routes.jenkins import (
    report_to_oc_collab,
    process_jenkins_build,
    verify_api_key,
    JenkinsWebhookPayload,
    JenkinsWebhookResponse
)

API_KEY = "test-agent-secret"


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def mock_test_result():
    """Mock测试结果数据"""
    return JenkinsTestResult(
        build_id="test#42",
        job_name="test-job",
        total_tests=10,
        passed=8,
        failed=2,
        skipped=0,
        duration=45.5,
        test_cases=[
            TestCaseResult(
                class_name="TestClass",
                name="test_pass",
                status="passed",
                time=0.5
            ),
            TestCaseResult(
                class_name="TestClass",
                name="test_fail",
                status="failed",
                time=0.3,
                error_message="Assertion failed"
            )
        ],
        report_url="http://jenkins/job/test/42/testReport/",
        timestamp=datetime(2026, 3, 22, 12, 0, 0)
    )


# ==================== JenkinsClient单元测试 ====================

class TestJenkinsClient:
    """JenkinsClient类测试"""

    def test_init_with_url(self):
        """测试JenkinsClient初始化"""
        client = JenkinsClient(
            jenkins_url="http://localhost:8080/jenkins",
            username="user",
            api_token="token"
        )
        assert client.jenkins_url == "http://localhost:8080/jenkins"
        assert client.username == "user"
        assert client.api_token == "token"

    def test_init_without_auth(self):
        """测试无认证初始化"""
        client = JenkinsClient("http://localhost:8080/jenkins")
        assert client.username is None
        assert client.api_token is None

    def test_build_url(self):
        """测试URL构建"""
        client = JenkinsClient("http://localhost:8080/jenkins")
        url = client._build_url("/job/test/42/api/json")
        assert url == "http://localhost:8080/jenkins/job/test/42/api/json"

    def test_build_url_trailing_slash(self):
        """测试URL构建处理尾斜杠"""
        client = JenkinsClient("http://localhost:8080/jenkins/")
        url = client._build_url("/job/test/api/json")
        assert url == "http://localhost:8080/jenkins/job/test/api/json"

    @patch('requests.Session.get')
    def test_get_build_info_success(self, mock_get):
        """测试获取构建信息成功"""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": 42,
            "number": 42,
            "result": "SUCCESS",
            "duration": 50000,
            "url": "http://jenkins/job/test/42/",
            "timestamp": 1710000000000,
            "building": False
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        client = JenkinsClient()
        client.session = MagicMock()
        client.session.get.return_value = mock_response

        result = client.get_build_info("test-job", "42")
        assert result["number"] == 42
        assert result["result"] == "SUCCESS"

    @patch('requests.Session.get')
    def test_get_build_info_not_found(self, mock_get):
        """测试获取不存在的构建"""
        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = Exception("404")
        mock_get.return_value = mock_response

        client = JenkinsClient()
        client.session = MagicMock()
        client.session.get.side_effect = Exception("404")

        result = client.get_build_info("nonexistent", "999")
        assert result is None

    @patch('requests.Session.get')
    def test_get_build_result_success(self, mock_get):
        """测试获取构建结果"""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "number": 42,
            "result": "SUCCESS",
            "duration": 50000,
            "url": "http://jenkins/job/test/42/",
            "timestamp": 1710000000000,
            "building": False,
            "actions": []
        }
        mock_get.return_value = mock_response

        client = JenkinsClient()
        client.session = MagicMock()
        client.session.get.return_value = mock_response

        result = client.get_build_result("test-job", "42")
        assert result == "SUCCESS"

    @patch('requests.Session.get')
    def test_get_build_result_failure(self, mock_get):
        """测试获取失败的构建结果"""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "number": 42,
            "result": "FAILURE",
            "duration": 50000,
            "url": "http://jenkins/job/test/42/",
            "timestamp": 1710000000000,
            "building": False,
            "actions": []
        }
        mock_get.return_value = mock_response

        client = JenkinsClient()
        client.session = MagicMock()
        client.session.get.return_value = mock_response

        result = client.get_build_result("test-job", "42")
        assert result == "FAILURE"

    def test_parse_junit_xml_success(self):
        """测试解析标准JUnit XML"""
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
        <testsuites>
            <testsuite name="test" tests="3" failures="1" skipped="1" time="1.5">
                <testcase classname="TestClass" name="test_pass" time="0.5"/>
                <testcase classname="TestClass" name="test_fail" time="0.3">
                    <failure message="Assertion failed">stack trace</failure>
                </testcase>
                <testcase classname="TestClass" name="test_skip" time="0.1">
                    <skipped/>
                </testcase>
            </testsuite>
        </testsuites>
        """

        client = JenkinsClient()
        result = client.parse_junit_xml(xml_content)

        assert result.total_tests == 3
        assert result.passed == 1
        assert result.failed == 1
        assert result.skipped == 1
        assert len(result.test_cases) == 3

    def test_parse_junit_xml_multiple_suites(self):
        """测试解析多测试套件XML"""
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
        <testsuites>
            <testsuite name="suite1" tests="2" failures="0" skipped="0" time="1.0">
                <testcase classname="Class1" name="test1" time="0.5"/>
                <testcase classname="Class1" name="test2" time="0.5"/>
            </testsuite>
            <testsuite name="suite2" tests="2" failures="1" skipped="0" time="2.0">
                <testcase classname="Class2" name="test3" time="1.0"/>
                <testcase classname="Class2" name="test4" time="1.0">
                    <failure>error</failure>
                </testcase>
            </testsuite>
        </testsuites>
        """

        client = JenkinsClient()
        result = client.parse_junit_xml(xml_content)

        assert result.total_tests == 4
        assert result.passed == 3
        assert result.failed == 1

    def test_parse_junit_xml_empty(self):
        """测试解析空测试套件"""
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
        <testsuites>
            <testsuite name="empty" tests="0" failures="0" skipped="0" time="0">
            </testsuite>
        </testsuites>
        """

        client = JenkinsClient()
        result = client.parse_junit_xml(xml_content)

        assert result.total_tests == 0
        assert result.passed == 0
        assert result.failed == 0

    @patch('requests.Session.post')
    def test_trigger_build_success(self, mock_post):
        """测试触发构建成功"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response

        client = JenkinsClient()
        client.session = MagicMock()
        client.session.post.return_value = mock_response

        result = client.trigger_build("test-job")
        assert result is True

    @patch('requests.Session.post')
    def test_trigger_build_failure(self, mock_post):
        """测试触发构建失败"""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_post.return_value = mock_response

        client = JenkinsClient()
        client.session = MagicMock()
        client.session.post.return_value = mock_response

        result = client.trigger_build("test-job")
        assert result is False


# ==================== WebHook端点单元测试 ====================

class TestJenkinsWebhook:
    """Jenkins WebHook端点测试"""

    def test_receive_webhook_success(self, client):
        """测试接收WebHook成功"""
        payload = {
            "job_name": "test-agent-test",
            "build_number": 42,
            "build_status": "SUCCESS",
            "build_url": "http://8.149.137.233:8080/jenkins/job/test/42/"
        }

        response = client.post(
            "/api/v1/webhook/jenkins",
            json=payload,
            headers={"x-api-key": API_KEY}
        )

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "test-agent-test#42" in data["build_id"]
        assert "42" in data["message"]

    def test_receive_webhook_invalid_api_key(self, client):
        """测试无效API Key"""
        payload = {
            "job_name": "test-agent-test",
            "build_number": 42,
            "build_status": "SUCCESS",
            "build_url": "http://8.149.137.233:8080/jenkins/job/test/42/"
        }

        response = client.post(
            "/api/v1/webhook/jenkins",
            json=payload,
            headers={"x-api-key": "invalid-key"}
        )

        assert response.status_code in [401, 403]

    def test_receive_webhook_missing_api_key(self, client):
        """测试缺少API Key"""
        payload = {
            "job_name": "test-agent-test",
            "build_number": 42,
            "build_status": "SUCCESS",
            "build_url": "http://8.149.137.233:8080/jenkins/job/test/42/"
        }

        response = client.post(
            "/api/v1/webhook/jenkins",
            json=payload
        )

        assert response.status_code in [401, 422]

    def test_receive_webhook_failure_status(self, client):
        """测试接收失败状态的WebHook"""
        payload = {
            "job_name": "test-agent-test",
            "build_number": 42,
            "build_status": "FAILURE",
            "build_url": "http://8.149.137.233:8080/jenkins/job/test/42/"
        }

        response = client.post(
            "/api/v1/webhook/jenkins",
            json=payload,
            headers={"x-api-key": API_KEY}
        )

        assert response.status_code == 200
        assert response.json()["success"] is True


# ==================== 主动拉取单元测试 ====================

class TestJenkinsPull:
    """主动拉取测试结果测试"""

    def test_get_results_not_found(self, client):
        """测试获取不存在的Jenkins结果"""
        with patch('src.api.routes.jenkins.JenkinsClient') as MockJenkins:
            mock_instance = MockJenkins.return_value
            mock_instance.get_test_result.return_value = None

            response = client.get(
                "/api/v1/jenkins/results/test-job/42",
                headers={"x-api-key": API_KEY}
            )

            assert response.status_code == 404

    def test_get_results_invalid_api_key(self, client):
        """测试无效API Key"""
        response = client.get(
            "/api/v1/jenkins/results/test-job/42",
            headers={"x-api-key": "invalid-key"}
        )

        assert response.status_code in [401, 403]


# ==================== oc-collab集成单元测试 ====================

class TestOcCollabIntegration:
    """oc-collab集成测试"""

    @patch('src.api.routes.jenkins.OcCollabClient')
    def test_report_to_oc_collab_success(self, mock_oc_collab, mock_test_result):
        """测试成功报告到oc-collab"""
        mock_instance = mock_oc_collab.return_value
        mock_instance.report_test_results.return_value = True

        import asyncio
        asyncio.run(report_to_oc_collab(mock_test_result, "SUCCESS"))

        mock_instance.report_test_results.assert_called_once()
        call_args = mock_instance.report_test_results.call_args[0][0]

        # 验证payload字段
        assert call_args["task_id"] == "test#42"
        assert call_args["subsystem"] == "test-agent"
        assert call_args["project"] == "test-agent"
        assert call_args["version"] == "v2.2.0"
        assert call_args["status"] == "passed"
        assert call_args["passed"] == 8
        assert call_args["failed"] == 2
        assert call_args["skipped"] == 0
        assert call_args["errors"] == 2  # errors = failed
        assert "duration" in call_args
        assert "report_url" in call_args
        assert "timestamp" in call_args

    @patch('src.api.routes.jenkins.OcCollabClient')
    def test_report_to_oc_collab_failure_status(self, mock_oc_collab, mock_test_result):
        """测试失败状态报告到oc-collab"""
        mock_instance = mock_oc_collab.return_value
        mock_instance.report_test_results.return_value = True

        import asyncio
        asyncio.run(report_to_oc_collab(mock_test_result, "FAILURE"))

        call_args = mock_instance.report_test_results.call_args[0][0]
        assert call_args["status"] == "failed"

    @patch('src.api.routes.jenkins.OcCollabClient')
    def test_report_to_oc_collab_no_timestamp(self, mock_oc_collab):
        """测试无时间戳的报告"""
        mock_instance = mock_oc_collab.return_value
        mock_instance.report_test_results.return_value = True

        test_result = JenkinsTestResult(
            build_id="test#42",
            job_name="test-job",
            total_tests=10,
            passed=8,
            failed=2,
            skipped=0,
            duration=45.5,
            test_cases=[],
            report_url="http://jenkins/job/test/42/testReport/",
            timestamp=None
        )

        import asyncio
        asyncio.run(report_to_oc_collab(test_result, "SUCCESS"))

        call_args = mock_instance.report_test_results.call_args[0][0]
        assert call_args["timestamp"] is None

    @patch('src.api.routes.jenkins.OcCollabClient')
    def test_report_to_oc_collab_no_report_url(self, mock_oc_collab):
        """测试无report_url的报告"""
        mock_instance = mock_oc_collab.return_value
        mock_instance.report_test_results.return_value = True

        test_result = JenkinsTestResult(
            build_id="test#42",
            job_name="test-job",
            total_tests=10,
            passed=8,
            failed=2,
            skipped=0,
            duration=45.5,
            test_cases=[],
            report_url=None,
            timestamp=datetime.now()
        )

        import asyncio
        asyncio.run(report_to_oc_collab(test_result, "SUCCESS"))

        call_args = mock_instance.report_test_results.call_args[0][0]
        assert "report_url" in call_args
        assert "test#42" in call_args["report_url"] or call_args["report_url"] == ""

    @patch('src.api.routes.jenkins.OcCollabClient')
    def test_report_to_oc_collab_exception(self, mock_oc_collab, mock_test_result):
        """测试报告异常处理"""
        mock_instance = mock_oc_collab.return_value
        mock_instance.report_test_results.side_effect = Exception("Connection failed")

        import asyncio
        # 不应抛出异常，应记录日志
        asyncio.run(report_to_oc_collab(mock_test_result, "SUCCESS"))


# ==================== process_jenkins_build单元测试 ====================

class TestProcessJenkinsBuild:
    """process_jenkins_build函数测试"""

    @patch('src.api.routes.jenkins.JenkinsClient')
    @patch('src.api.routes.jenkins.report_to_oc_collab')
    def test_process_success(self, mock_report, mock_jenkins):
        """测试处理成功"""
        mock_jenkins_instance = mock_jenkins.return_value
        mock_test_result = JenkinsTestResult(
            build_id="test#42",
            job_name="test-job",
            total_tests=10,
            passed=8,
            failed=2,
            skipped=0,
            duration=45.5,
            test_cases=[],
            report_url=None,
            timestamp=None
        )
        mock_jenkins_instance.get_test_result.return_value = mock_test_result

        import asyncio
        asyncio.run(process_jenkins_build("test-job", 42, "SUCCESS"))

        mock_jenkins_instance.get_test_result.assert_called_once_with("test-job", "42")
        mock_report.assert_called_once()

    @patch('src.api.routes.jenkins.JenkinsClient')
    def test_process_no_result(self, mock_jenkins):
        """测试无结果处理"""
        mock_jenkins_instance = mock_jenkins.return_value
        mock_jenkins_instance.get_test_result.return_value = None

        import asyncio
        asyncio.run(process_jenkins_build("test-job", 42, "SUCCESS"))

        mock_jenkins_instance.get_test_result.assert_called_once()

    @patch('src.api.routes.jenkins.JenkinsClient')
    def test_process_exception(self, mock_jenkins):
        """测试异常处理"""
        mock_jenkins_instance = mock_jenkins.return_value
        mock_jenkins_instance.get_test_result.side_effect = Exception("Connection timeout")

        import asyncio
        # 不应抛出异常
        asyncio.run(process_jenkins_build("test-job", 42, "SUCCESS"))


# ==================== 数据模型单元测试 ====================

class TestDataModels:
    """数据模型测试"""

    def test_jenkins_test_result_creation(self):
        """测试JenkinsTestResult创建"""
        result = JenkinsTestResult(
            build_id="test#42",
            job_name="test",
            total_tests=10,
            passed=8,
            failed=2,
            skipped=0,
            duration=45.5,
            test_cases=[]
        )
        assert result.build_id == "test#42"
        assert result.passed == 8

    def test_test_case_result_creation(self):
        """测试TestCaseResult创建"""
        case = TestCaseResult(
            class_name="TestClass",
            name="test_method",
            status="passed",
            time=1.5
        )
        assert case.class_name == "TestClass"
        assert case.status == "passed"


# ==================== 边界条件测试 ====================

class TestBoundaryConditions:
    """边界条件测试"""

    def test_build_url_special_characters(self):
        """测试特殊字符URL构建"""
        client = JenkinsClient("http://localhost:8080/jenkins")
        url = client._build_url("/job/test%20job/api/json")
        assert "test%20job" in url

    def test_parse_xml_malformed(self):
        """测试解析畸形XML"""
        xml_content = """<?xml version="1.0"?>
        <invalid>not test suites</invalid>
        """

        client = JenkinsClient()
        with pytest.raises(Exception):
            client.parse_junit_xml(xml_content)

    def test_parse_xml_empty_content(self):
        """测试解析空内容"""
        client = JenkinsClient()
        result = client.parse_junit_xml("")
        assert result.total_tests == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--cov=src.api.routes.jenkins", "--cov-report=term-missing"])
