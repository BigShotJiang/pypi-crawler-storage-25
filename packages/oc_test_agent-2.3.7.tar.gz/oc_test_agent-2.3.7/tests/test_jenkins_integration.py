"""
test-agent Jenkins集成测试用例

测试Jenkins客户端和WebHook端点功能
"""

import pytest
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.api import app
from src.core.jenkins_client import JenkinsClient, JenkinsTestResult, TestCaseResult
from src.api.routes.jenkins import report_to_oc_collab

API_KEY = "test-agent-secret"


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def mock_jenkins_response():
    """Mock Jenkins API响应"""
    return {
        "id": 42,
        "number": 42,
        "result": "SUCCESS",
        "duration": 50000,
        "url": "http://8.149.137.233:8080/jenkins/job/test/42/",
        "timestamp": 1710000000000,
        "building": False,
        "actions": [
            {
                "_class": "jenkins.tasks.junit.TestResultAction",
                "totalCount": 10,
                "passCount": 8,
                "failCount": 2,
                "skipCount": 0,
                "result": {
                    "duration": 45.5,
                    "childReports": []
                }
            }
        ]
    }


class TestJenkinsClient:
    """Jenkins客户端测试"""
    
    def test_jenkins_client_init(self):
        """测试Jenkins客户端初始化"""
        client = JenkinsClient(
            jenkins_url="http://localhost:8080/jenkins",
            username="user",
            api_token="token"
        )
        assert client.jenkins_url == "http://localhost:8080/jenkins"
        assert client.username == "user"
        assert client.api_token == "token"
    
    def test_build_url(self):
        """测试URL构建"""
        client = JenkinsClient("http://localhost:8080/jenkins")
        url = client._build_url("/job/test/42/api/json")
        assert url == "http://localhost:8080/jenkins/job/test/42/api/json"
    
    @patch('requests.Session.get')
    def test_get_build_info(self, mock_get, mock_jenkins_response):
        """测试获取构建信息"""
        mock_response = MagicMock()
        mock_response.json.return_value = mock_jenkins_response
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        client = JenkinsClient()
        client.session = MagicMock()
        client.session.get.return_value = mock_response
        
        result = client.get_build_info("test-job", "42")
        assert result is not None
        assert result["number"] == 42
        assert result["result"] == "SUCCESS"
    
    @patch('requests.Session.get')
    def test_get_build_result(self, mock_get, mock_jenkins_response):
        """测试获取构建结果"""
        mock_response = MagicMock()
        mock_response.json.return_value = mock_jenkins_response
        mock_get.return_value = mock_response
        
        client = JenkinsClient()
        client.session = MagicMock()
        client.session.get.return_value = mock_response
        
        result = client.get_build_result("test-job", "42")
        assert result == "SUCCESS"
    
    def test_parse_junit_xml(self):
        """测试解析JUnit XML"""
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
        <testsuites>
            <testsuite name="test" tests="3" failures="1" skipped="0" time="1.5">
                <testcase classname="TestClass" name="test_pass" time="0.5"/>
                <testcase classname="TestClass" name="test_fail" time="0.3">
                    <failure message="Assertion failed">stack trace</failure>
                </testcase>
                <testcase classname="TestClass" name="test_skip" time="0.1">
                    <skipped/>
                </testcase>
            </testsuite>
        </testsuites>
        """
        
        client = JenkinsClient()
        result = client.parse_junit_xml(xml_content)
        
        assert result.total_tests == 3
        assert result.passed == 2
        assert result.failed == 1
        assert result.skipped == 0
        assert len(result.test_cases) == 3


class TestJenkinsWebhook:
    """Jenkins WebHook端点测试"""
    
    def test_receive_webhook_success(self, client):
        """测试接收WebHook成功"""
        payload = {
            "job_name": "test-agent-test",
            "build_number": 42,
            "build_status": "SUCCESS",
            "build_url": "http://8.149.137.233:8080/jenkins/job/test/42/"
        }
        
        response = client.post(
            "/api/v1/webhook/jenkins",
            json=payload,
            headers={"x-api-key": API_KEY}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        assert "test-agent-test#42" in data["build_id"]
    
    def test_receive_webhook_invalid_api_key(self, client):
        """测试无效API Key"""
        payload = {
            "job_name": "test-agent-test",
            "build_number": 42,
            "build_status": "SUCCESS",
            "build_url": "http://8.149.137.233:8080/jenkins/job/test/42/"
        }
        
        response = client.post(
            "/api/v1/webhook/jenkins",
            json=payload,
            headers={"x-api-key": "invalid-key"}
        )
        
        assert response.status_code in [401, 403]
    
    def test_get_jenkins_results_not_found(self, client):
        """测试获取不存在的Jenkins结果"""
        with patch('src.api.routes.jenkins.JenkinsClient') as MockJenkins:
            mock_instance = MockJenkins.return_value
            mock_instance.get_test_result.return_value = None
            
            response = client.get(
                "/api/v1/jenkins/jobs/test-job/results/42",
                headers={"x-api-key": API_KEY}
            )
            
            assert response.status_code == 404


class TestOcCollabIntegration:
    """oc-collab集成测试"""
    
    def test_report_test_results(self):
        """测试报告测试结果到oc-collab"""
        from src.core.oc_collab_client import OcCollabClient
        
        client = OcCollabClient()
        
        with patch.object(client, '_request') as mock_request:
            mock_request.return_value = {"status": "ok"}
            
            result = client.report_test_results({
                "task_id": "test#42",
                "subsystem": "test-agent",
                "status": "passed",
                "passed": 8,
                "failed": 2,
                "errors": 0,
                "duration": 45.5,
                "report": "summary",
                "timestamp": "2026-03-22T12:00:00"
            })
            
            assert result == True
            mock_request.assert_called_once()


class TestReportToOcCollab:
    """report_to_oc_collab函数测试"""

    @pytest.mark.asyncio
    async def test_report_success(self):
        """测试成功报告 - 验证payload格式与oc-collab对齐"""
        test_result = JenkinsTestResult(
            build_id="test#42",
            job_name="test-job",
            total_tests=10,
            passed=8,
            failed=2,
            skipped=1,
            duration=45.5,
            test_cases=[],
            report_url="http://jenkins/job/test/42/",
            timestamp=datetime.now()
        )

        with patch('src.api.routes.jenkins.OcCollabClient') as MockOcCollab:
            mock_instance = MockOcCollab.return_value
            mock_instance.report_test_results.return_value = True

            await report_to_oc_collab(test_result, "SUCCESS")

            call_args = mock_instance.report_test_results.call_args[0][0]

            # 验证必填字段
            assert call_args["task_id"] == "test#42"
            assert call_args["subsystem"] == "test-agent"
            assert call_args["project"] == "test-agent"  # 新增字段
            assert call_args["version"] == "v3.2.0"  # 新增字段
            assert call_args["status"] == "passed"
            assert call_args["passed"] == 8
            assert call_args["failed"] == 2
            assert call_args["errors"] == 2  # errors = failed
            assert call_args["skipped"] == 1  # 新增字段
            assert call_args["duration"] == 45.5
            assert call_args["report_url"] == "http://jenkins/job/test/42/"  # 字段名修改
            assert "timestamp" in call_args

    @pytest.mark.asyncio
    async def test_report_failed_status(self):
        """测试构建失败时状态为failed"""
        test_result = JenkinsTestResult(
            build_id="test#42",
            job_name="test-job",
            total_tests=10,
            passed=5,
            failed=5,
            skipped=0,
            duration=60.0,
            test_cases=[],
            report_url=None,
            timestamp=datetime.now()
        )

        with patch('src.api.routes.jenkins.OcCollabClient') as MockOcCollab:
            mock_instance = MockOcCollab.return_value
            mock_instance.report_test_results.return_value = True

            await report_to_oc_collab(test_result, "FAILURE")

            call_args = mock_instance.report_test_results.call_args[0][0]
            assert call_args["status"] == "failed"
            assert call_args["failed"] == 5


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
