"""
版本管理CLI命令测试用例

需求关联 (conf_man_cli_usage Skill):
- VER-001: register命令
- VER-002: list命令
- VER-003: show命令
- VER-004: release命令

需求文档: HQ/docs/05-tasks/TASK_conf_man_version_api_implement.md
版本: v2.0.0
"""

import pytest
import sys
import os
import json
from pathlib import Path
from click.testing import CliRunner

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.cli_version import version_group, register_cmd, list_cmd, show_cmd, release_cmd, compare_cmd, tag_cmd, export_cmd, import_cmd, rollback_cmd


@pytest.fixture(autouse=True)
def clean_versions_db():
    """每个测试前清理版本数据库"""
    import os
    db_path = os.environ.get("VERSIONS_DB_PATH", "/app/state/versions.db")
    if os.path.exists(db_path):
        os.remove(db_path)
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


@pytest.fixture
def runner():
    """创建CLI测试运行器"""
    return CliRunner()


class TestVersionCLI:
    """版本CLI测试"""

    def test_register_version(self, runner):
        """TC-v2-E016: 测试版本登记命令"""
        import time
        result = runner.invoke(register_cmd, ["--version", f"7.0.{int(time.time())}", "--project", "test-agent"])
        assert result.exit_code == 0
        assert "登记成功" in result.output or "登记完成" in result.output

    def test_list_versions(self, runner):
        """TC-v2-E017: 测试列出版本命令"""
        import time
        ts = int(time.time())
        runner.invoke(register_cmd, ["--version", f"1.{ts}", "--project", "test-agent"])
        runner.invoke(register_cmd, ["--version", f"2.{ts}", "--project", "test-agent"])
        
        result = runner.invoke(list_cmd, ["--project", "test-agent"])
        assert result.exit_code == 0
        assert f"1.{ts}" in result.output or "1." in result.output
        assert f"2.{ts}" in result.output or "2." in result.output

    def test_show_version(self, runner):
        """TC-v2-E018: 测试显示版本详情命令"""
        runner.invoke(register_cmd, ["--version", "3.0.0", "--project", "test-agent", "--git-commit", "abc123"])
        
        result = runner.invoke(show_cmd, ["3.0.0"])
        assert result.exit_code == 0
        assert "3.0.0" in result.output
        assert "abc123" in result.output

    def test_release_version(self, runner):
        """TC-v2-E019: 测试发布版本命令"""
        runner.invoke(register_cmd, ["--version", "3.0.0", "--project", "test-agent"])
        
        result = runner.invoke(release_cmd, ["--version", "3.0.0"])
        assert result.exit_code == 0
        assert "已发布" in result.output

    def test_release_already_released(self, runner):
        """TC-v2-E020: 测试重复发布"""
        runner.invoke(register_cmd, ["--version", "3.0.0", "--project", "test-agent"])
        runner.invoke(release_cmd, ["--version", "3.0.0"])
        
        result = runner.invoke(release_cmd, ["--version", "3.0.0"])
        assert "已发布" in result.output

    def test_show_not_found(self, runner):
        """TC-v2-E021: 测试显示不存在的版本"""
        result = runner.invoke(show_cmd, ["99.0.0"])
        assert result.exit_code == 1
        assert "不存在" in result.output

    def test_compare_versions(self, runner):
        """TC-v2-E022: 测试版本比较命令"""
        runner.invoke(register_cmd, ["--version", "1.0.0", "--project", "test-agent", "--git-commit", "aaa111"])
        runner.invoke(register_cmd, ["--version", "2.0.0", "--project", "test-agent", "--git-commit", "bbb222"])
        
        result = runner.invoke(compare_cmd, ["--version-a", "1.0.0", "--version-b", "2.0.0"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output
        assert "2.0.0" in result.output

    def test_tag_version(self, runner):
        """TC-v2-E023: 测试版本标签命令"""
        runner.invoke(register_cmd, ["--version", "3.0.0", "--project", "test-agent"])
        
        result = runner.invoke(tag_cmd, ["--version", "3.0.0", "--tag", "stable", "--message", "LTS release"])
        assert result.exit_code == 0
        assert "stable" in result.output

    def test_export_version(self, runner, tmp_path):
        """TC-v2-E024: 测试版本导出命令"""
        runner.invoke(register_cmd, ["--version", "3.0.0", "--project", "test-agent", "--git-commit", "abc123"])
        
        output_file = tmp_path / "export.json"
        result = runner.invoke(export_cmd, ["--version", "3.0.0", "--output", str(output_file)])
        assert result.exit_code == 0
        assert "已导出" in result.output
        assert output_file.exists()

    def test_import_version(self, runner, tmp_path):
        """TC-v2-E025: 测试版本导入命令"""
        import time
        test_data = {
            "version": f"4.{int(time.time())}",
            "project_id": "test-agent",
            "git_commit_hash": "imported123",
            "manifest": "",
            "status": "registered"
        }
        input_file = tmp_path / "import.json"
        with open(input_file, "w") as f:
            json.dump(test_data, f)
    
        result = runner.invoke(import_cmd, ["--file", str(input_file)])
        assert result.exit_code == 0
        assert "已导入" in result.output

    def test_rollback_version(self, runner):
        """TC-v2-E026: 测试版本回滚命令"""
        runner.invoke(register_cmd, ["--version", "2.0.0", "--project", "test-agent"])
        runner.invoke(register_cmd, ["--version", "3.0.0", "--project", "test-agent"])
        runner.invoke(release_cmd, ["--version", "3.0.0"])
        
        result = runner.invoke(rollback_cmd, ["--version", "3.0.0", "--to", "2.0.0"])
        assert result.exit_code == 0
        assert "已回滚" in result.output

    def test_compare_not_found(self, runner):
        """TC-v2-E027: 测试比较不存在的版本"""
        result = runner.invoke(compare_cmd, ["--version-a", "99.0.0", "--version-b", "1.0.0"])
        assert result.exit_code == 1
        assert "不存在" in result.output

    def test_tag_not_found(self, runner):
        """TC-v2-E028: 测试为不存在的版本打标签"""
        result = runner.invoke(tag_cmd, ["--version", "99.0.0", "--tag", "stable"])
        assert result.exit_code == 1
        assert "不存在" in result.output

    def test_export_not_found(self, runner, tmp_path):
        """TC-v2-E029: 测试导出不存在的版本"""
        output_file = tmp_path / "export.json"
        result = runner.invoke(export_cmd, ["--version", "99.0.0", "--output", str(output_file)])
        assert result.exit_code == 1
        assert "不存在" in result.output

    def test_import_invalid_json(self, runner, tmp_path):
        """TC-v2-E030: 测试导入损坏的JSON文件"""
        input_file = tmp_path / "invalid.json"
        with open(input_file, "w") as f:
            f.write("invalid json content")
        
        result = runner.invoke(import_cmd, ["--file", str(input_file)])
        assert result.exit_code == 1

    def test_rollback_not_found(self, runner):
        """TC-v2-E031: 测试回滚不存在的版本"""
        result = runner.invoke(rollback_cmd, ["--version", "99.0.0", "--to", "1.0.0"])
        assert result.exit_code == 1
        assert "不存在" in result.output


class TestVersionCLIDocStatus:
    """v2.1.0 CLI文档状态参数测试 - 使用主CLI"""

    @pytest.fixture
    def main_cli(self):
        from src import cli
        return cli

    def test_register_with_doc_status(self, main_cli):
        """TC-v2.1-E011: 测试带文档状态的版本登记"""
        import time
        runner = CliRunner()
        result = runner.invoke(main_cli, [
            'register',
            f"2.1.{int(time.time())}",
            "--project", "conf-man",
            "--api-doc-updated", "true",
            "--cli-doc-updated", "false"
        ])
        assert result.exit_code == 0

    def test_register_without_doc_status_uses_default(self, main_cli):
        """TC-v2.1-E012: 测试不带文档状态参数使用默认值"""
        import time
        runner = CliRunner()
        result = runner.invoke(main_cli, [
            'register',
            f"2.1.{int(time.time())}",
            "--project", "conf-man"
        ])
        assert result.exit_code == 0
        assert "登记成功" in result.output or "登记完成" in result.output


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
