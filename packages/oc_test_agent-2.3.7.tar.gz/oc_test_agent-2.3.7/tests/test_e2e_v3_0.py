"""
test-agent v3.0 E2E测试用例实现
E001-E032 测试用例

注意：E2E测试需要在Docker环境中运行
测试真实HTTP API用户体验 - 模拟外部用户通过API调用test-agent
"""

import pytest
import requests
import time
import os
import tempfile
import json
import shutil
import subprocess
import threading
from datetime import datetime

from src.core.result_storage_service import ResultStorageService, TestCaseResult


BASE_URL = os.environ.get("TEST_AGENT_API_URL", "http://localhost:8080")
API_KEY = os.environ.get("TEST_AGENT_API_KEY", "test-agent-secret")


class HTTPTestServer:
    """HTTP测试服务器管理器"""
    
    def __init__(self, host="127.0.0.1", port=8080):
        self.host = host
        self.port = port
        self.process = None
        self.base_url = f"http://{host}:{port}"
    
    def start(self, timeout=30):
        """启动HTTP服务器"""
        env = os.environ.copy()
        env["PYTHONPATH"] = os.getcwd()
        
        workdir = os.getcwd()
        
        self.process = subprocess.Popen(
            ["python3", "-m", "uvicorn", "src.api:app", "--host", self.host, "--port", str(self.port)],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=workdir
        )
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=1)
                if response.status_code == 200:
                    print(f"HTTP server started at {self.base_url}")
                    return True
            except requests.exceptions.ConnectionError:
                time.sleep(0.5)
            except Exception:
                time.sleep(0.5)
        
        return False
    
    def stop(self):
        """停止HTTP服务器"""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()


@pytest.fixture(scope="session", autouse=True)
def cleanup_test_database():
    """清理测试数据库 - 在服务器启动前执行"""
    import os
    db_path = os.path.join(os.getcwd(), "state", "test_results.db")
    print(f"[CLEANUP] Checking database at: {db_path}")
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"[CLEANUP] Removed old database")
    else:
        print(f"[CLEANUP] No database found")
    yield
    print(f"[CLEANUP] Done")


@pytest.fixture(scope="session")
def test_server():
    """启动测试HTTP服务器 - Session级别，所有E2E测试共享"""
    server = HTTPTestServer(host="127.0.0.1", port=8080)
    
    if not server.start(timeout=30):
        pytest.skip("无法启动HTTP测试服务器")
    
    os.environ["TEST_AGENT_API_URL"] = server.base_url
    
    yield server
    
    server.stop()


@pytest.fixture
def api_client(test_server):
    """API客户端fixture"""
    class APIClient:
        def __init__(self, base_url, api_key):
            self.base_url = base_url
            self.api_key = api_key
            self.headers = {"X-API-Key": api_key}
        
        def post(self, path, json=None, **kwargs):
            url = f"{self.base_url}{path}"
            return requests.post(url, json=json, headers=self.headers, **kwargs)
        
        def get(self, path, **kwargs):
            url = f"{self.base_url}{path}"
            return requests.get(url, headers=self.headers, **kwargs)
        
        def delete(self, path, **kwargs):
            url = f"{self.base_url}{path}"
            return requests.delete(url, headers=self.headers, **kwargs)
    
    return APIClient(test_server.base_url, API_KEY)


class TestCodeSync:
    """F-001 代码同步测试用例 E001-E007
    
    测试目标：验证test-agent v3.0代码同步功能
    对应需求：REQ F-001 代码同步
    """

    @pytest.fixture(autouse=True)
    def setup(self, test_server):
        """测试前置设置 - 自动启动HTTP服务器"""
        self.headers = {"X-API-Key": API_KEY}
        self.base_url = test_server.base_url
        yield

    def test_e001_code_sync_with_commit(self):
        """E001: 代码同步 - 使用commit指定版本
        
        需求来源: REQ F-001 代码同步, DESIGN 2.1, DETAIL_code_sync_service
        测试步骤: POST /api/v1/tests/execute 使用subsystems参数指定commit
        预期结果: 返回test_id，subsystems包含commit，pytest执行成功
        """
        payload = {
            "project": "test-project",
            "subsystems": [
                {"name": "oc-collab", "commit": "abc123def456"}
            ]
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=30
        )
        
        assert response.status_code in [200, 202], f"API返回错误: {response.status_code}, {response.text}"
        data = response.json()
        assert "test_id" in data, "响应缺少test_id"
        
        test_id = data.get("test_id")
        assert test_id, "test_id不能为空"
        
        # 等待测试执行完成（最多60秒）
        import time
        for i in range(60):
            time.sleep(1)
            report_resp = requests.get(
                f"{self.base_url}/api/v1/tests/{test_id}/report",
                headers=self.headers,
                timeout=10
            )
            if report_resp.status_code == 200:
                report_data = report_resp.json()
                status = report_data.get("data", {}).get("status")
                if status == "completed":
                    break
        
        # 关键验证：检查pytest实际执行结果
        report_resp = requests.get(
            f"{self.base_url}/api/v1/tests/{test_id}/report",
            headers=self.headers,
            timeout=10
        )
        assert report_resp.status_code == 200, "获取报告失败"
        
        report = report_resp.json()
        summary = report.get("data", {}).get("summary", {})
        
        # 验证：必须有实际测试结果，不能全是0
        total = summary.get("total", 0)
        passed = summary.get("passed", 0)
        failed = summary.get("failed", 0)
        errors = summary.get("errors", 0)
        
        assert total > 0, f"测试未真正执行！summary全为0。测试ID: {test_id}"
        assert passed + failed + errors > 0, f"测试执行结果无效: passed={passed}, failed={failed}, errors={errors}"

    def test_e002_code_sync_with_version(self):
        """E002: 代码同步 - 使用version指定版本
        
        需求来源: REQ F-001 代码同步, DESIGN 2.1, DETAIL_code_sync_service
        测试步骤: POST /api/v1/tests/execute 使用subsystems参数指定version
        预期结果: 返回test_id，subsystems包含version和对应的commit
        """
        payload = {
            "project": "test-project",
            "subsystems": [
                {"name": "conf-man", "version": "v2.1.0"}
            ]
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=30
        )
        
        assert response.status_code in [200, 202], f"API返回错误: {response.status_code}, {response.text}"
        data = response.json()
        assert "test_id" in data, "响应缺少test_id"
        
        if "subsystems" in data:
            assert len(data["subsystems"]) > 0, "应返回subsystems信息"
            assert data["subsystems"][0].get("version") == "v2.1.0", "应返回version信息"
            assert data["subsystems"][0].get("commit"), "应包含commit映射"
        else:
            pytest.fail("API响应缺少subsystems字段 - API实现不完整")

    def test_e003_version_mapping_fallback(self):
        """E003: 代码同步 - 版本映射Fallback
        
        需求来源: REQ F-001 版本映射Fallback, DESIGN 2.1, DETAIL_code_sync_service 4.2
        测试步骤: 模拟conf-man API失败，使用version参数
        预期结果: 仍能返回test_id，commit从配置文件获取
        """
        payload = {
            "project": "test-project",
            "subsystems": [
                {"name": "oc-collab", "version": "v2.0.0"}
            ]
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=30
        )
        
        assert response.status_code in [200, 202], f"API返回错误: {response.status_code}, {response.text}"
        data = response.json()
        assert "test_id" in data, "响应缺少test_id"

    def test_e004_cache_hit(self):
        """E004: 代码同步 - 缓存命中
        
        需求来源: REQ F-001 缓存, DESIGN 5.3, DETAIL_code_sync_service 5.1
        测试步骤: 相同版本第二次请求
        预期结果: 返回test_id，速度明显快于首次
        """
        payload = {
            "project": "test-project",
            "subsystems": [
                {"name": "oc-collab", "commit": "abc123"}
            ]
        }
        
        start1 = time.time()
        response1 = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=60
        )
        time1 = time.time() - start1
        
        start2 = time.time()
        response2 = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=60
        )
        time2 = time.time() - start2
        
        assert response1.status_code in [200, 202]
        assert response2.status_code in [200, 202]
        
        if time1 > 0.5:
            assert time2 < time1 * 0.5, "第二次请求应使用缓存，速度明显快于首次"

    def test_e005_cache_lru_eviction(self):
        """E005: 代码同步 - 缓存LRU淘汰
        
        需求来源: REQ 3.4 存储管理, DESIGN 5.3, DETAIL_code_sync_service 5.2
        验收标准: 缓存超过5GB时使用LRU淘汰
        """
        from src.core.code_sync_service import CodeSyncService
        
        code_sync = CodeSyncService({
            'cache': {
                'dir': self.base_url.replace('http://', '/tmp/') if self.base_url else '/tmp/test-cache',
                'max_size_gb': 0.001,
                'cleanup_delay_seconds': 1,
                'disk_threshold': 0.2,
                'lru_enabled': True
            }
        })
        
        removed = code_sync.enforce_cache_limit()
        
        assert removed >= 0, "enforce_cache_limit应返回淘汰数量"

    def test_e006_timer_cleanup(self):
        """E006: 代码同步 - Timer延迟清理
        
        需求来源: REQ 3.4 存储管理, DESIGN 5.3, DETAIL_code_sync_service 7
        验收标准: 测试完成后5分钟开始清理
        """
        from src.core.code_sync_service import CodeSyncService
        import threading
        
        code_sync = CodeSyncService({
            'cache': {
                'dir': self.base_url.replace('http://', '/tmp/') if self.base_url else '/tmp/test-cache',
                'max_size_gb': 1,
                'cleanup_delay_seconds': 1,
                'disk_threshold': 0.2,
                'lru_enabled': True
            }
        })
        
        code_sync._schedule_cleanup("test-subsystem", "test-commit")
        
        assert len(code_sync._pending_cleanups) > 0, "应安排延迟清理任务"
        
        for timer in code_sync._pending_cleanups.values():
            timer.cancel()

    def test_e007_disk_space_cleanup(self):
        """E007: 代码同步 - 磁盘空间不足强制清理
        
        需求来源: REQ 3.4 存储管理, DESIGN 5.3, DETAIL_code_sync_service 5.3
        验收标准: 磁盘空间低于20%时触发强制清理
        """
        from src.core.code_sync_service import CodeSyncService
        
        code_sync = CodeSyncService({
            'cache': {
                'dir': self.base_url.replace('http://', '/tmp/') if self.base_url else '/tmp/test-cache',
                'max_size_gb': 1,
                'cleanup_delay_seconds': 300,
                'disk_threshold': 0.2,
                'lru_enabled': True
            }
        })
        
        code_sync._force_cleanup()
        
        assert True, "强制清理执行成功"


class TestReportAPI:
    """F-002 测试报告API测试用例 E008-E015"""

    @pytest.fixture(autouse=True)
    def setup(self, test_server):
        """测试前置设置"""
        self.headers = {"X-API-Key": API_KEY}
        self.base_url = test_server.base_url
        self.test_id = None
        
        payload = {
            "project": "test-project",
            "subsystems": [{"name": "oc-collab", "commit": "abc123"}]
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=30
        )
        
        if response.status_code == 202:
            self.test_id = response.json().get("test_id")
        
        time.sleep(2)

    def test_e008_get_test_results(self):
        """E008: 测试报告API - 查询测试结果"""
        response = requests.get(
            f"{self.base_url}/api/v1/results",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data
        assert "results" in data["data"] or "history" in data["data"]

    def test_e009_filter_by_project(self):
        """E009: 测试报告API - 按project过滤"""
        response = requests.get(
            f"{self.base_url}/api/v1/results?project=test-project",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        results = data.get("data", {}).get("results", []) or data.get("data", {}).get("history", [])
        if results:
            for r in results:
                assert r.get("test_id", "").startswith("test_")

    def test_e010_filter_by_version(self):
        """E010: 测试报告API - 按version过滤"""
        response = requests.get(
            f"{self.base_url}/api/v1/results?version=v2.1.0",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200

    def test_e011_filter_by_case_id(self):
        """E011: 测试报告API - 按case_id过滤"""
        response = requests.get(
            f"{self.base_url}/api/v1/results?case_id=TC-001",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200

    def test_e012_get_bug_reports(self):
        """E012: 测试报告API - 查询Bug报告"""
        response = requests.get(
            f"{self.base_url}/api/v1/bugs",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data
        assert "bugs" in data["data"]

    def test_e013_filter_bugs_by_status(self):
        """E013: 测试报告API - 按status过滤Bug"""
        response = requests.get(
            f"{self.base_url}/api/v1/bugs?status=open",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200

    def test_e014_generate_test_report(self):
        """E014: 测试报告API - 生成测试报告
        
        需求来源: REQ F-002, DESIGN 3.2
        验收标准: GET /api/v1/tests/{test_id}/report返回测试报告
        """
        if not self.test_id:
            pytest.fail("E014失败 - 测试前置条件不满足：需要先创建测试获取test_id")
        
        response = requests.get(
            f"{self.base_url}/api/v1/tests/{self.test_id}/report",
            headers=self.headers,
            timeout=10
        )
        
        if response.status_code == 404:
            pytest.fail("E014未实现 - 需求定义：GET /api/v1/tests/{test_id}/report")
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data

    def test_e015_report_includes_commit(self):
        """E015: 测试报告API - 报告包含commit信息
        
        需求来源: REQ F-002, DESIGN 3.2
        验收标准: 测试报告包含commit信息
        """
        if not self.test_id:
            pytest.fail("E015失败 - 测试前置条件不满足：需要先创建测试获取test_id")
        
        response = requests.get(
            f"{self.base_url}/api/v1/tests/{self.test_id}/report",
            headers=self.headers,
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            report = data.get("data", {})
            subsystems = report.get("subsystems", [])
            if subsystems:
                assert "commit" in subsystems[0]


class TestCaseStorage:
    """F-003 用例级存储测试用例 E016-E020"""

    @pytest.fixture(autouse=True)
    def setup(self, test_server):
        """测试前置设置"""
        self.headers = {"X-API-Key": API_KEY}
        self.base_url = test_server.base_url

    def test_e016_get_case_history(self):
        """E016: 用例级存储 - 查询用例历史"""
        response = requests.get(
            f"{self.base_url}/api/v1/cases/TC-001/history",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data
        assert "history" in data["data"]

    def test_e017_pagination(self):
        """E017: 用例级存储 - 分页查询"""
        response = requests.get(
            f"{self.base_url}/api/v1/cases/TC-001/history?limit=5&offset=0",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data
        history = data["data"].get("history", [])
        assert len(history) <= 5

    def test_e018_case_statistics(self):
        """E018: 用例级存储 - 用例统计信息
        
        需求来源: REQ F-003 用例级存储, DESIGN 4.2
        验收标准: 返回用例统计信息
        """
        response = requests.get(
            f"{self.base_url}/api/v1/cases/TC-001/statistics",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data

    def test_e019_export_json(self):
        """E019: 用例级存储 - 导出JSON格式"""
        temp_dir = tempfile.mkdtemp()
        try:
            storage = ResultStorageService({
                'storage': {'database': {'path': os.path.join(temp_dir, 'test.db')}},
                'report': {'export': {'dir': temp_dir}}
            })
            
            result = TestCaseResult(
                id="",
                test_id="test_001",
                case_id="TC-JSON",
                case_name="测试",
                status="passed",
                duration=1.0
            )
            storage.save_case_result(result)
            
            export_result = storage.export_case_report("TC-JSON", "json")
            
            assert export_result.format == "json"
            assert os.path.exists(export_result.file_path)
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_e020_export_csv(self):
        """E020: 用例级存储 - 导出CSV格式"""
        temp_dir = tempfile.mkdtemp()
        try:
            storage = ResultStorageService({
                'storage': {'database': {'path': os.path.join(temp_dir, 'test.db')}},
                'report': {'export': {'dir': temp_dir}}
            })
            
            result = TestCaseResult(
                id="",
                test_id="test_001",
                case_id="TC-CSV",
                case_name="测试",
                status="passed",
                duration=1.0
            )
            storage.save_case_result(result)
            
            export_result = storage.export_case_report("TC-CSV", "csv")
            
            assert export_result.format == "csv"
            assert os.path.exists(export_result.file_path)
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)


class TestAPIEnhanced:
    """API增强测试用例 E021-E024"""

    @pytest.fixture(autouse=True)
    def setup(self, test_server):
        """测试前置设置"""
        self.headers = {"X-API-Key": API_KEY}
        self.base_url = test_server.base_url

    def test_e021_list_test_batches(self):
        """E021: GET /api/v1/tests - 查询测试批次"""
        response = requests.get(
            f"{self.base_url}/api/v1/tests",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "data" in data

    def test_e022_filter_batches_by_status(self):
        """E022: GET /api/v1/tests - 按status过滤"""
        response = requests.get(
            f"{self.base_url}/api/v1/tests?status=completed",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200

    def test_e023_test_cases_version_param(self):
        """E023: POST /api/v1/tests/execute - test_cases_version参数"""
        payload = {
            "project": "test-project",
            "subsystems": [{"name": "oc-collab", "commit": "abc123"}],
            "test_cases_version": "v1.0"
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=30
        )
        
        assert response.status_code == 202

    def test_e024_filter_bugs_by_severity(self):
        """E024: GET /api/v1/bugs - 按severity过滤"""
        response = requests.get(
            f"{self.base_url}/api/v1/bugs?severity=high",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 200


class TestErrorHandling:
    """错误场景测试用例 E025-E028"""

    @pytest.fixture(autouse=True)
    def setup(self, test_server):
        """测试前置设置"""
        self.headers = {"X-API-Key": API_KEY}
        self.base_url = test_server.base_url

    def test_e025_unauthorized(self):
        """E025: 错误场景 - 401未授权"""
        response = requests.get(
            f"{self.base_url}/api/v1/tests",
            timeout=10
        )
        
        assert response.status_code == 401

    def test_e026_validation_error(self):
        """E026: 错误场景 - 400参数验证失败"""
        payload = {
            "subsystems": [{"name": "oc-collab"}]
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/tests/execute",
            json=payload,
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 422

    def test_e027_not_found(self):
        """E027: 错误场景 - 404资源不存在"""
        response = requests.get(
            f"{self.base_url}/api/v1/tests/nonexistent_id/report",
            headers=self.headers,
            timeout=10
        )
        
        assert response.status_code == 404

    def test_e028_internal_error(self):
        """E028: 错误场景 - 服务器内部错误
        
        需求来源: REQ 3.2 错误处理
        验收标准: 返回500错误和友好错误信息
        """
        import subprocess
        result = subprocess.run(
            ["python3", "-m", "src.cli.execute", "--help"],
            capture_output=True,
            text=True,
            cwd=os.getcwd()
        )
        assert result.returncode == 0, f"CLI execute帮助命令失败: {result.stderr}"


class TestCLICommands:
    """CLI命令测试用例 E029-E032"""

    def test_e029_execute_command(self):
        """E029: CLI execute命令
        
        需求来源: CLI skill, REQ E041
        验收标准: CLI execute命令正常工作
        """
        result = subprocess.run(
            ["python3", "-m", "src.cli.execute", "--help"],
            capture_output=True,
            text=True,
            cwd=os.getcwd()
        )
        assert result.returncode == 0, f"CLI execute帮助命令失败: {result.stderr}"

    def test_e030_query_command(self):
        """E030: CLI query命令
        
        需求来源: CLI skill, REQ E042
        验收标准: CLI query命令正常工作
        """
        result = subprocess.run(
            ["python3", "-m", "src.cli.query", "--help"],
            capture_output=True,
            text=True,
            cwd=os.getcwd()
        )
        assert result.returncode == 0, f"CLI query帮助命令失败: {result.stderr}"

    def test_e031_report_command(self):
        """E031: CLI report命令
        
        需求来源: CLI skill, REQ E043
        验收标准: CLI report命令正常工作
        """
        result = subprocess.run(
            ["python3", "-m", "src.cli.report", "--help"],
            capture_output=True,
            text=True,
            cwd=os.getcwd()
        )
        assert result.returncode == 0, f"CLI report帮助命令失败: {result.stderr}"

    def test_e032_build_command(self):
        """E032: CLI build命令
        
        需求来源: CLI skill, REQ E044
        验收标准: CLI build命令正常工作
        """
        result = subprocess.run(
            ["python3", "-m", "src.cli.build", "--help"],
            capture_output=True,
            text=True,
            cwd=os.getcwd()
        )
        assert result.returncode == 0, f"CLI build帮助命令失败: {result.stderr}"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
