"""
版本管理API测试用例

需求关联:
- VER-001: register_version (POST /api/v1/versions)
- VER-002: list_versions (GET /api/v1/versions)
- VER-003: show_version (GET /api/v1/versions/{id})
- VER-004: release_version (POST /api/v1/versions/{id}/release)
- VER-007: update_version (PUT /api/v1/versions/{id})

需求文档: HQ/docs/05-tasks/TASK_conf_man_version_api_implement.md
版本: v2.0.0
"""

import pytest
import sys
import os
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api.serve import create_app


@pytest.fixture
def client():
    """创建测试客户端"""
    app = create_app()
    return TestClient(app)


@pytest.fixture(autouse=True)
def clean_versions_db():
    """每个测试前清理版本数据库"""
    import os
    from pathlib import Path
    project_root = Path(__file__).parent.parent
    db_path = project_root / "state" / "versions.db"
    if os.path.exists(db_path):
        os.remove(db_path)
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


class TestVersionAPI:
    """版本API测试"""

    def test_register_version(self, client):
        """TC-v2-E001: 测试版本登记"""
        response = client.post(
            "/api/v1/versions",
            json={
                "version": "3.0.0",
                "project_id": "test-agent",
                "git_commit_hash": "abc123def456",
                "manifest": '{"components": [{"name": "test-agent"}]}',
                "api_doc_updated": True,
                "cli_doc_updated": False
            }
        )
        assert response.status_code == 201
        data = response.json()
        assert data["version"] == "3.0.0"
        assert data["project_id"] == "test-agent"
        assert data["git_commit_hash"] == "abc123def456"
        assert data["status"] == "registered"
        assert "id" in data
        assert data["api_doc_updated"] is True
        assert data["cli_doc_updated"] is False

    def test_register_version_required_fields(self, client):
        """TC-v2-E001-b: 测试必填字段验证 - 不传api_doc_updated"""
        response = client.post(
            "/api/v1/versions",
            json={
                "version": "3.0.0",
                "project_id": "test-agent"
            }
        )
        assert response.status_code == 422

    def test_register_duplicate_version(self, client):
        """TC-v2-E002: 测试重复版本登记"""
        client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        assert response.status_code == 400
        assert "already exists" in response.json()["detail"]

    def test_list_versions(self, client):
        """TC-v2-E003: 测试列出版本"""
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        client.post(
            "/api/v1/versions",
            json={"version": "2.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        
        response = client.get("/api/v1/versions")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    def test_list_versions_by_project(self, client):
        """TC-v2-E004: 测试按项目筛选"""
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "pm-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        
        response = client.get("/api/v1/versions?project_id=test-agent")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["project_id"] == "test-agent"

    def test_get_version(self, client):
        """TC-v2-E005: 测试获取版本详情"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        response = client.get(f"/api/v1/versions/{version_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "3.0.0"

    def test_get_version_not_found(self, client):
        """TC-v2-E006: 测试获取不存在的版本"""
        response = client.get("/api/v1/versions/999")
        assert response.status_code == 404

    def test_update_version(self, client):
        """TC-v2-E007: 测试更新版本"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        response = client.put(
            f"/api/v1/versions/{version_id}",
            json={"version": "3.0.1", "git_commit_hash": "newhash123"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "3.0.1"
        assert data["git_commit_hash"] == "newhash123"

    def test_trigger_release(self, client):
        """TC-v2-E008: 测试触发发布"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        response = client.post(f"/api/v1/versions/{version_id}/release")
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        get_response = client.get(f"/api/v1/versions/{version_id}")
        assert get_response.json()["status"] == "released"

    def test_trigger_release_already_released(self, client):
        """TC-v2-E009: 测试重复发布"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        client.post(f"/api/v1/versions/{version_id}/release")
        response = client.post(f"/api/v1/versions/{version_id}/release")
        
        assert response.status_code == 400
        assert "already released" in response.json()["detail"]

    def test_delete_version(self, client):
        """TC-v2-E010: 测试删除版本"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        response = client.delete(f"/api/v1/versions/{version_id}")
        assert response.status_code == 200
        
        get_response = client.get(f"/api/v1/versions/{version_id}")
        assert get_response.status_code == 404


class TestVersionAPIRequired:
    """v2.1.0 必填字段测试"""

    def test_register_without_api_doc_updated(self, client):
        """TC-API-003: 测试不传api_doc_updated"""
        response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "cli_doc_updated": True}
        )
        assert response.status_code == 422

    def test_register_without_cli_doc_updated(self, client):
        """TC-API-004: 测试不传cli_doc_updated"""
        response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": True}
        )
        assert response.status_code == 422

    def test_register_invalid_doc_status(self, client):
        """TC-API-005: 测试无效的文档状态值"""
        response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "project_id": "test-agent", "api_doc_updated": "invalid"}
        )
        assert response.status_code == 422


class TestVersionAPIDocStatus:
    """v2.1.0 文档状态测试"""

    def test_register_with_doc_status(self, client):
        """TC-v2.1-E001: 测试带文档状态的版本登记"""
        response = client.post(
            "/api/v1/versions",
            json={
                "version": "2.1.0",
                "project_id": "conf-man",
                "api_doc_updated": True,
                "cli_doc_updated": True
            }
        )
        assert response.status_code == 201
        data = response.json()
        assert data["api_doc_updated"] is True
        assert data["cli_doc_updated"] is True

    def test_list_filter_by_api_doc_updated_true(self, client):
        """TC-v2.1-E002: 测试按API文档状态筛选 - true"""
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "conf-man", "api_doc_updated": True, "cli_doc_updated": False}
        )
        client.post(
            "/api/v1/versions",
            json={"version": "2.0.0", "project_id": "conf-man", "api_doc_updated": False, "cli_doc_updated": False}
        )
        
        response = client.get("/api/v1/versions?api_doc_updated=true")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["api_doc_updated"] is True

    def test_list_filter_by_api_doc_updated_false(self, client):
        """TC-v2.1-E003: 测试按API文档状态筛选 - false"""
        client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": "conf-man", "api_doc_updated": True, "cli_doc_updated": False}
        )
        client.post(
            "/api/v1/versions",
            json={"version": "2.0.0", "project_id": "conf-man", "api_doc_updated": False, "cli_doc_updated": False}
        )
        
        response = client.get("/api/v1/versions?api_doc_updated=false")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["api_doc_updated"] is False

    def test_update_doc_status(self, client):
        """TC-v2.1-E004: 测试更新文档状态"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "2.1.0", "project_id": "conf-man", "api_doc_updated": False, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        response = client.put(
            f"/api/v1/versions/{version_id}",
            json={"api_doc_updated": True, "cli_doc_updated": True}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["api_doc_updated"] is True
        assert data["cli_doc_updated"] is True


class TestVersionAPIProjectDefault:
    """v2.1.0 project_id默认值测试"""

    def test_register_without_project_uses_default(self, client):
        """TC-API-018: 测试不传project_id使用默认值"""
        response = client.post(
            "/api/v1/versions",
            json={"version": "3.0.0", "api_doc_updated": True, "cli_doc_updated": False}
        )
        assert response.status_code == 201
        data = response.json()
        assert data["project_id"] == "default"

    def test_get_version_includes_doc_status(self, client):
        """TC-API-011: 测试获取版本详情包含新字段"""
        reg_response = client.post(
            "/api/v1/versions",
            json={"version": "2.1.0", "project_id": "conf-man", "api_doc_updated": True, "cli_doc_updated": False}
        )
        version_id = reg_response.json()["id"]
        
        response = client.get(f"/api/v1/versions/{version_id}")
        assert response.status_code == 200
        data = response.json()
        assert "api_doc_updated" in data
        assert "cli_doc_updated" in data
        assert data["api_doc_updated"] is True
        assert data["cli_doc_updated"] is False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
