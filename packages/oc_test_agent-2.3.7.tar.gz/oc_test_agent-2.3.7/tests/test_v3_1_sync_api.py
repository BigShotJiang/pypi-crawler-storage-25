"""
代码同步API单元测试

需求关联:
- SYNC-001: 同步目标系统代码 (POST /api/v1/sync)
- SYNC-002: 同步测试用例代码 (POST /api/v1/sync/tests)
- SYNC-003: 同步需求和设计文档 (POST /api/v1/sync/docs)

版本: v3.1.0
"""

import pytest
import sys
import os
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api import app


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def temp_base_dir():
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


class TestSyncAPI:
    def test_sync_target_without_api_key(self, client):
        response = client.post(
            "/api/v1/sync",
            json={
                "project": "conf-man",
                "version": "2.1.0",
                "git_url": "https://gitee.com/test/conf-man.git"
            }
        )
        assert response.status_code == 401

    def test_sync_tests_without_api_key(self, client):
        response = client.post(
            "/api/v1/sync/tests",
            json={
                "project": "conf-man",
                "version": "2.1.0",
                "git_url": "https://gitee.com/test/conf-man.git"
            }
        )
        assert response.status_code == 401

    def test_sync_docs_without_api_key(self, client):
        response = client.post(
            "/api/v1/sync/docs",
            json={
                "project": "conf-man",
                "version": "2.1.0",
                "git_url": "https://gitee.com/test/conf-man.git"
            }
        )
        assert response.status_code == 401


class TestSyncTargetEndpoint:
    """sync_target API端点测试"""

    def test_sync_target_success(self, client, temp_base_dir):
        """测试同步目标系统代码成功"""
        with patch('src.api.routes.sync.SYSTEMS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (True, 100, None)
                    
                    response = client.post(
                        "/api/v1/sync",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git",
                            "commit": "abc123"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200
                    data = response.json()
                    assert data["success"] is True
                    assert data["data"]["sync_type"] == "target"
                    assert data["data"]["files_synced"] == 100

    def test_sync_target_without_commit(self, client, temp_base_dir):
        """测试不带commit参数"""
        with patch('src.api.routes.sync.SYSTEMS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (True, 50, None)
                    
                    response = client.post(
                        "/api/v1/sync",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200
                    data = response.json()
                    assert data["data"]["commit_hash"] == "latest"

    def test_sync_target_failure(self, client, temp_base_dir):
        """测试同步失败"""
        with patch('src.api.routes.sync.SYSTEMS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (False, 0, "Git clone failed")
                    
                    response = client.post(
                        "/api/v1/sync",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200
                    data = response.json()
                    assert data["success"] is False
                    assert data["error"]["code"] == 500


class TestSyncTestsEndpoint:
    """sync_tests API端点测试"""

    def test_sync_tests_success(self, client, temp_base_dir):
        """测试同步测试用例成功"""
        with patch('src.api.routes.sync.TESTS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    with patch('src.api.routes.sync.update_test_dispatcher') as mock_update:
                        mock_clone.return_value = (True, 50, None)
                        
                        response = client.post(
                            "/api/v1/sync/tests",
                            json={
                                "project": "conf-man",
                                "version": "2.1.0",
                                "git_url": "https://gitee.com/test/conf-man.git",
                                "commit": "def456"
                            },
                            headers={"x-api-key": "test-agent-secret"}
                        )
                        
                        assert response.status_code == 200
                        data = response.json()
                        assert data["success"] is True
                        assert data["data"]["sync_type"] == "test"

    def test_sync_tests_without_commit(self, client, temp_base_dir):
        """测试不带commit"""
        with patch('src.api.routes.sync.TESTS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    with patch('src.api.routes.sync.update_test_dispatcher') as mock_update:
                        mock_clone.return_value = (True, 30, None)
                        
                        response = client.post(
                            "/api/v1/sync/tests",
                            json={
                                "project": "conf-man",
                                "version": "2.1.0",
                                "git_url": "https://gitee.com/test/conf-man.git"
                            },
                            headers={"x-api-key": "test-agent-secret"}
                        )
                        
                        assert response.status_code == 200
                        assert response.json()["success"] is True

    def test_sync_tests_failure(self, client, temp_base_dir):
        """测试同步失败"""
        with patch('src.api.routes.sync.TESTS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (False, 0, "Network error")
                    
                    response = client.post(
                        "/api/v1/sync/tests",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200
                    data = response.json()
                    assert data["success"] is False
                    assert "Network error" in data["error"]["detail"]


class TestSyncDocsEndpoint:
    """sync_docs API端点测试"""

    def test_sync_docs_success(self, client, temp_base_dir):
        """测试同步文档成功"""
        with patch('src.api.routes.sync.DOCS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    with patch('pathlib.Path.rglob') as mock_rglob:
                        mock_clone.return_value = (True, 20, None)
                        mock_rglob.return_value = [
                            MagicMock(name="REQUIREMENT_conf-man.md"),
                            MagicMock(name="DESIGN_conf-man.md")
                        ]
                        
                        response = client.post(
                            "/api/v1/sync/docs",
                            json={
                                "project": "conf-man",
                                "version": "2.1.0",
                                "git_url": "https://gitee.com/test/conf-man.git",
                                "docs_type": "all"
                            },
                            headers={"x-api-key": "test-agent-secret"}
                        )
                        
                        assert response.status_code == 200
                        data = response.json()
                        assert data["success"] is True
                        assert data["data"]["sync_type"] == "docs"

    def test_sync_docs_requirements_type(self, client, temp_base_dir):
        """测试同步需求文档"""
        with patch('src.api.routes.sync.DOCS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (True, 10, None)
                    
                    response = client.post(
                        "/api/v1/sync/docs",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git",
                            "docs_type": "requirements"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200
                    assert response.json()["success"] is True

    def test_sync_docs_designs_type(self, client, temp_base_dir):
        """测试同步设计文档"""
        with patch('src.api.routes.sync.DOCS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (True, 15, None)
                    
                    response = client.post(
                        "/api/v1/sync/docs",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git",
                            "docs_type": "designs"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200

    def test_sync_docs_failure(self, client, temp_base_dir):
        """测试同步失败"""
        with patch('src.api.routes.sync.DOCS_DIR', Path(temp_base_dir)):
            with patch('src.api.routes.sync.clone_repo') as mock_clone:
                with patch('src.api.routes.sync.save_sync_record') as mock_save:
                    mock_clone.return_value = (False, 0, "Access denied")
                    
                    response = client.post(
                        "/api/v1/sync/docs",
                        json={
                            "project": "conf-man",
                            "version": "2.1.0",
                            "git_url": "https://gitee.com/test/conf-man.git"
                        },
                        headers={"x-api-key": "test-agent-secret"}
                    )
                    
                    assert response.status_code == 200
                    data = response.json()
                    assert data["success"] is False


class TestCloneRepoFunction:
    def test_clone_new_repo(self, temp_base_dir):
        from src.api.routes.sync import clone_repo
        
        with patch('src.api.routes.sync.subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            
            target_path = Path(temp_base_dir) / "test_repo"
            success, files_count, error = clone_repo(
                "https://gitee.com/test/repo.git",
                target_path
            )
            
            assert mock_run.call_count == 1

    def test_clone_existing_repo(self, temp_base_dir):
        from src.api.routes.sync import clone_repo
        
        existing_path = Path(temp_base_dir) / "existing_repo"
        existing_path.mkdir()
        
        with patch('src.api.routes.sync.subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            
            success, files_count, error = clone_repo(
                "https://gitee.com/test/repo.git",
                existing_path
            )
            
            assert mock_run.call_count >= 1

    def test_clone_failure(self, temp_base_dir):
        from src.api.routes.sync import clone_repo
        
        with patch('src.api.routes.sync.subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=128, stderr="Not a git repository")
            
            target_path = Path(temp_base_dir) / "fail_repo"
            success, files_count, error = clone_repo(
                "https://gitee.com/test/repo.git",
                target_path
            )
            
            assert success is False
            assert "Not a git repository" in error

    def test_clone_with_commit(self, temp_base_dir):
        from src.api.routes.sync import clone_repo
        
        with patch('src.api.routes.sync.subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            
            target_path = Path(temp_base_dir) / "commit_repo"
            success, files_count, error = clone_repo(
                "https://gitee.com/test/repo.git",
                target_path,
                commit="abc123"
            )
            
            assert mock_run.call_count == 2

    def test_clone_timeout(self, temp_base_dir):
        from src.api.routes.sync import clone_repo
        import subprocess
        
        with patch('src.api.routes.sync.subprocess.run') as mock_run:
            mock_run.side_effect = subprocess.TimeoutExpired("cmd", 1)
            
            target_path = Path(temp_base_dir) / "timeout_repo"
            success, files_count, error = clone_repo(
                "https://gitee.com/test/repo.git",
                target_path
            )
            
            assert success is False
            assert "timeout" in error.lower()

    def test_clone_exception(self, temp_base_dir):
        from src.api.routes.sync import clone_repo
        
        with patch('src.api.routes.sync.subprocess.run') as mock_run:
            mock_run.side_effect = Exception("Unknown error")
            
            target_path = Path(temp_base_dir) / "exception_repo"
            success, files_count, error = clone_repo(
                "https://gitee.com/test/repo.git",
                target_path
            )
            
            assert success is False
            assert "Unknown error" in error


class TestGetFileCount:
    def test_empty_directory(self, temp_base_dir):
        from src.api.routes.sync import get_file_count
        
        empty_dir = Path(temp_base_dir) / "empty"
        empty_dir.mkdir()
        
        count = get_file_count(empty_dir)
        assert count == 0

    def test_directory_with_files(self, temp_base_dir):
        from src.api.routes.sync import get_file_count
        
        dir_with_files = Path(temp_base_dir) / "files"
        dir_with_files.mkdir()
        (dir_with_files / "file1.py").touch()
        (dir_with_files / "file2.py").touch()
        
        count = get_file_count(dir_with_files)
        assert count == 2

    def test_nonexistent_directory(self, temp_base_dir):
        from src.api.routes.sync import get_file_count
        
        nonexistent = Path(temp_base_dir) / "nonexistent"
        count = get_file_count(nonexistent)
        assert count == 0

    def test_nested_files(self, temp_base_dir):
        from src.api.routes.sync import get_file_count
        
        nested = Path(temp_base_dir) / "nested"
        nested.mkdir()
        (nested / "a.py").touch()
        (nested / "sub").mkdir()
        (nested / "sub" / "b.py").touch()
        
        count = get_file_count(nested)
        assert count == 2


class TestSyncResponseModel:
    def test_response_model_success(self):
        from src.api.routes.sync import SyncResponse
        
        response = SyncResponse(
            success=True,
            data={"project": "conf-man", "version": "2.1.0"}
        )
        
        assert response.success is True
        assert response.data["project"] == "conf-man"

    def test_response_model_error(self):
        from src.api.routes.sync import SyncResponse
        
        response = SyncResponse(
            success=False,
            error={"code": 500, "message": "Error"}
        )
        
        assert response.success is False
        assert response.error["code"] == 500

    def test_response_model_with_none_data(self):
        from src.api.routes.sync import SyncResponse
        
        response = SyncResponse(success=False, error=None)
        
        assert response.success is False


class TestSyncRequestModels:
    def test_sync_request_model(self):
        from src.api.routes.sync import SyncRequest
        
        request = SyncRequest(
            project="conf-man",
            version="2.1.0",
            git_url="https://gitee.com/test/conf-man.git"
        )
        
        assert request.project == "conf-man"
        assert request.version == "2.1.0"
        assert request.commit is None

    def test_sync_request_with_commit(self):
        from src.api.routes.sync import SyncRequest
        
        request = SyncRequest(
            project="conf-man",
            version="2.1.0",
            git_url="https://gitee.com/test/conf-man.git",
            commit="abc123"
        )
        
        assert request.commit == "abc123"

    def test_sync_tests_request_model(self):
        from src.api.routes.sync import SyncTestsRequest
        
        request = SyncTestsRequest(
            project="conf-man",
            version="2.1.0",
            git_url="https://gitee.com/test/conf-man.git"
        )
        
        assert request.project == "conf-man"

    def test_sync_docs_request_model(self):
        from src.api.routes.sync import SyncDocsRequest
        
        request = SyncDocsRequest(
            project="conf-man",
            version="2.1.0",
            git_url="https://gitee.com/test/conf-man.git",
            docs_type="all"
        )
        
        assert request.docs_type == "all"

    def test_sync_docs_request_default_type(self):
        from src.api.routes.sync import SyncDocsRequest
        
        request = SyncDocsRequest(
            project="conf-man",
            version="2.1.0",
            git_url="https://gitee.com/test/conf-man.git"
        )
        
        assert request.docs_type == "all"


class TestUpdateTestDispatcher:
    def test_update_config_existing_project(self, temp_base_dir):
        from src.api.routes.sync import update_test_dispatcher
        
        config_path = Path(temp_base_dir) / "test_dispatcher.yaml"
        config_path.write_text('test_paths:\n  existing-project: []\n')
        
        with patch('src.api.routes.sync.BASE_DIR', Path(temp_base_dir)):
            update_test_dispatcher("existing-project", "test", "/app/tests/existing-project")

    def test_update_config_no_file(self, temp_base_dir):
        from src.api.routes.sync import update_test_dispatcher
        
        with patch('src.api.routes.sync.BASE_DIR', Path(temp_base_dir)):
            update_test_dispatcher("project", "test", "/path")

    def test_update_config_no_test_paths_key(self, temp_base_dir):
        from src.api.routes.sync import update_test_dispatcher
        
        config_path = Path(temp_base_dir) / "test_dispatcher.yaml"
        config_path.write_text('{}\n')
        
        with patch('src.api.routes.sync.BASE_DIR', Path(temp_base_dir)):
            update_test_dispatcher("new-project", "test", "/app/tests/new-project")

    def test_update_config_add_new_project(self, temp_base_dir):
        from src.api.routes.sync import update_test_dispatcher
        
        config_path = Path(temp_base_dir) / "test_dispatcher.yaml"
        config_path.write_text('test_paths: {}\n')
        
        with patch('src.api.routes.sync.BASE_DIR', Path(temp_base_dir)):
            update_test_dispatcher("new-project", "test", "/app/tests/new-project")

    def test_update_config_not_test_type(self, temp_base_dir):
        from src.api.routes.sync import update_test_dispatcher
        
        config_path = Path(temp_base_dir) / "test_dispatcher.yaml"
        config_path.write_text('test_paths: {}\n')
        
        with patch('src.api.routes.sync.BASE_DIR', Path(temp_base_dir)):
            update_test_dispatcher("project", "target", "/app/systems/project")

    def test_update_config_path_already_exists(self, temp_base_dir):
        """测试路径已存在不重复添加"""
        from src.api.routes.sync import update_test_dispatcher
        
        config_path = Path(temp_base_dir) / "test_dispatcher.yaml"
        config_path.write_text('test_paths:\n  existing: ["tests/existing/*.py"]\n')
        
        with patch('src.api.routes.sync.BASE_DIR', Path(temp_base_dir)):
            update_test_dispatcher("existing", "test", "/app/tests/existing")
