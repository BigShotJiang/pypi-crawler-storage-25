"""Health check route - No authentication required"""

from fastapi import APIRouter

router = APIRouter()

API_VERSION = "2.3.7"


@router.get("/health")
async def health_check():
    """Health check endpoint - no authentication required"""
    return {
        "status": "ok",
        "version": API_VERSION
    }
