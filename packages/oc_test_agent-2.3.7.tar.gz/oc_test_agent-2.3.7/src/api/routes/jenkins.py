"""
Jenkins WebHook接收端点

接收Gitea WebHook通知，触发获取Jenkins测试结果
"""

import os
import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Header, BackgroundTasks
from pydantic import BaseModel

from ...core.jenkins_client import JenkinsClient, JenkinsTestResult
from ...core.oc_collab_client import OcCollabClient

logger = logging.getLogger(__name__)

router = APIRouter()

API_KEY = os.environ.get("JENKINS_WEBHOOK_API_KEY", "test-agent-secret")


class JenkinsWebhookPayload(BaseModel):
    """Jenkins WebHook负载"""
    job_name: str
    build_number: int
    build_status: str
    build_url: str


class JenkinsWebhookResponse(BaseModel):
    """WebHook响应"""
    success: bool
    message: str
    build_id: Optional[str] = None


def verify_api_key(x_api_key: str = Header(...)) -> bool:
    """验证API Key"""
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API Key")
    return True


@router.post("/webhook/jenkins", response_model=JenkinsWebhookResponse)
async def receive_jenkins_webhook(
    payload: JenkinsWebhookPayload,
    background_tasks: BackgroundTasks,
    x_api_key: str = Header(...)
):
    """
    接收Jenkins构建完成的WebHook通知
    
    Gitea WebHook -> Jenkins构建 -> Jenkins回调 -> test-agent获取结果
    
    请求体:
    {
        "job_name": "test-agent-test",
        "build_number": 42,
        "build_status": "SUCCESS",
        "build_url": "http://8.149.137.233:8080/jenkins/job/test-agent-test/42/"
    }
    """
    verify_api_key(x_api_key)
    
    logger.info(f"收到Jenkins WebHook: job={payload.job_name}, build={payload.build_number}")
    
    background_tasks.add_task(
        process_jenkins_build,
        payload.job_name,
        payload.build_number,
        payload.build_status
    )
    
    return JenkinsWebhookResponse(
        success=True,
        message=f"已接收WebHook，开始处理构建 #{payload.build_number}",
        build_id=f"{payload.job_name}#{payload.build_number}"
    )


async def process_jenkins_build(job_name: str, build_number: int, build_status: str, version: str = "v2.2.0"):
    """
    后台处理Jenkins构建结果
    """
    try:
        jenkins = JenkinsClient()
        result = jenkins.get_test_result(job_name, str(build_number))
        
        if result:
            await report_to_oc_collab(result, build_status, version)
        else:
            logger.warning(f"未获取到测试结果: {job_name}#{build_number}")
    except Exception as e:
        logger.error(f"处理Jenkins构建结果失败: {e}")


async def report_to_oc_collab(test_result: JenkinsTestResult, build_status: str, version: str):
    """
    将测试结果报告给oc-collab

    payload格式与oc-collab /api/v1/test-results对齐
    """
    try:
        oc_collab = OcCollabClient()

        status = "passed" if build_status in ["SUCCESS", "UNSTABLE"] else "failed"

        payload = {
            "task_id": test_result.build_id,
            "subsystem": "test-agent",
            "project": "test-agent",
            "version": version,
            "status": status,
            "passed": test_result.passed,
            "failed": test_result.failed,
            "errors": test_result.failed,
            "skipped": test_result.skipped,
            "duration": test_result.duration,
            "report_url": test_result.report_url or f"Jenkins {test_result.job_name} #{test_result.build_id.split('#')[-1]}: {test_result.passed} passed, {test_result.failed} failed",
            "timestamp": test_result.timestamp.isoformat() if test_result.timestamp else None
        }

        oc_collab.report_test_results(payload)
        logger.info(f"已报告测试结果到oc-collab: {test_result.build_id}")
    except Exception as e:
        logger.error(f"报告测试结果到oc-collab失败: {e}")


@router.get("/jenkins/results/{job_name}/{build_number}")
async def get_jenkins_test_results(
    job_name: str,
    build_number: int,
    x_api_key: str = Header(...)
):
    """
    主动获取Jenkins测试结果
    
    当WebHook不可用时，可通过此接口主动拉取结果
    """
    verify_api_key(x_api_key)
    
    jenkins = JenkinsClient()
    result = jenkins.get_test_result(job_name, str(build_number))
    
    if not result:
        raise HTTPException(status_code=404, detail="未找到测试结果")
    
    return {
        "success": True,
        "data": {
            "build_id": result.build_id,
            "job_name": result.job_name,
            "total_tests": result.total_tests,
            "passed": result.passed,
            "failed": result.failed,
            "skipped": result.skipped,
            "duration": result.duration,
            "report_url": result.report_url,
            "test_cases": [
                {
                    "class_name": tc.class_name,
                    "name": tc.name,
                    "status": tc.status,
                    "time": tc.time,
                    "error_message": tc.error_message
                }
                for tc in result.test_cases[:100]
            ]
        }
    }
