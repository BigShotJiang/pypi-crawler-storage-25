import json
import uuid
import sqlite3
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from abc import ABC, abstractmethod


@dataclass
class TestCaseResult:
    id: str
    test_id: str
    case_id: str
    case_name: str
    status: str
    duration: float
    error_message: Optional[str] = None
    stack_trace: Optional[str] = None
    environment: Optional[Dict] = None
    executed_at: Optional[datetime] = None
    version: Optional[str] = None
    created_at: Optional[datetime] = None


@dataclass
class TestBatch:
    id: str
    project: str
    status: str
    test_cases_version: Optional[str] = None
    subsystems: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration: Optional[float] = None
    report_git_commit: Optional[str] = None
    summary: Optional[str] = None
    passed: Optional[int] = 0
    failed: Optional[int] = 0
    errors: Optional[int] = 0
    total: Optional[int] = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


@dataclass
class BugReport:
    id: str
    test_id: str
    case_id: str
    title: str
    description: Optional[str] = None
    severity: str = "medium"
    status: str = "open"
    priority: Optional[str] = None
    git_url: Optional[str] = None
    assignee: Optional[str] = None
    resolution: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


@dataclass
class CaseStatistics:
    case_id: str
    total_runs: int
    passed_count: int
    failed_count: int
    error_count: int
    pass_rate: float
    avg_duration: float
    last_executed: Optional[datetime] = None
    first_executed: Optional[datetime] = None


@dataclass
class ExportResult:
    format: str
    file_path: str
    record_count: int
    generated_at: datetime


class DatabaseManager:
    """数据库管理器"""
    
    def __init__(self, db_path: str = "state/test_results.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
    
    def _init_database(self):
        """初始化数据库表"""
        with self._get_connection() as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS test_batches (
                    id VARCHAR(36) PRIMARY KEY,
                    project VARCHAR(100) NOT NULL,
                    status VARCHAR(20) NOT NULL,
                    test_cases_version VARCHAR(50),
                    subsystems TEXT,
                    started_at DATETIME,
                    completed_at DATETIME,
                    duration FLOAT,
                    report_git_commit VARCHAR(40),
                    summary TEXT,
                    passed INTEGER DEFAULT 0,
                    failed INTEGER DEFAULT 0,
                    errors INTEGER DEFAULT 0,
                    total INTEGER DEFAULT 0,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL
                );
                
                CREATE INDEX IF NOT EXISTS idx_test_batches_project ON test_batches(project);
                CREATE INDEX IF NOT EXISTS idx_test_batches_status ON test_batches(status);
                CREATE INDEX IF NOT EXISTS idx_test_batches_started_at ON test_batches(started_at);
                
                CREATE TABLE IF NOT EXISTS test_results (
                    id VARCHAR(36) PRIMARY KEY,
                    test_id VARCHAR(36) NOT NULL,
                    case_id VARCHAR(50) NOT NULL,
                    case_name VARCHAR(200),
                    status VARCHAR(20) NOT NULL,
                    duration FLOAT,
                    error_message TEXT,
                    stack_trace TEXT,
                    environment TEXT,
                    executed_at DATETIME NOT NULL,
                    version VARCHAR(50),
                    created_at DATETIME NOT NULL
                );
                
                CREATE INDEX IF NOT EXISTS idx_test_results_test_id ON test_results(test_id);
                CREATE INDEX IF NOT EXISTS idx_test_results_case_id ON test_results(case_id);
                CREATE INDEX IF NOT EXISTS idx_test_results_status ON test_results(status);
                CREATE INDEX IF NOT EXISTS idx_test_results_executed_at ON test_results(executed_at);
                CREATE INDEX IF NOT EXISTS idx_test_results_case_executed ON test_results(case_id, executed_at);
                
                CREATE TABLE IF NOT EXISTS bug_reports (
                    id VARCHAR(50) PRIMARY KEY,
                    test_id VARCHAR(36) NOT NULL,
                    case_id VARCHAR(50) NOT NULL,
                    title VARCHAR(200) NOT NULL,
                    description TEXT,
                    severity VARCHAR(20) NOT NULL,
                    status VARCHAR(20) NOT NULL,
                    priority VARCHAR(20),
                    git_url VARCHAR(500),
                    assignee VARCHAR(50),
                    resolution TEXT,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL
                );
                
                CREATE INDEX IF NOT EXISTS idx_bug_reports_test_id ON bug_reports(test_id);
                CREATE INDEX IF NOT EXISTS idx_bug_reports_case_id ON bug_reports(case_id);
                CREATE INDEX IF NOT EXISTS idx_bug_reports_status ON bug_reports(status);
                CREATE INDEX IF NOT EXISTS idx_bug_reports_severity ON bug_reports(severity);
            ''')
    
    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn


class ResultStorageService:
    """结果存储服务 - 用例级结果存储、历史记录查询、报告导出"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        storage_config = self.config.get('storage', {})
        
        import os
        db_path = storage_config.get('database', {}).get('path')
        if not db_path:
            from src.db.database import TEST_RESULTS_DB_PATH
            db_path = TEST_RESULTS_DB_PATH
        self.db_manager = DatabaseManager(db_path)
        
        export_config = self.config.get('report', {}).get('export', {})
        self.export_dir = export_config.get('dir', 'exports')
        self.max_export_size = export_config.get('max_size', 10000)
        
        Path(self.export_dir).mkdir(parents=True, exist_ok=True)

    def save_case_result(self, result: TestCaseResult) -> str:
        """保存单个用例结果"""
        
        result.id = result.id or str(uuid.uuid4())
        result.created_at = result.created_at or datetime.now()
        result.executed_at = result.executed_at or datetime.now()
        
        self._validate_result(result)
        
        with self.db_manager._get_connection() as conn:
            conn.execute('''
                INSERT INTO test_results (
                    id, test_id, case_id, case_name, status, duration,
                    error_message, stack_trace, environment, executed_at, version, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                result.id, result.test_id, result.case_id, result.case_name,
                result.status, result.duration, result.error_message,
                result.stack_trace, json.dumps(result.environment or {}),
                result.executed_at.isoformat() if result.executed_at else datetime.now().isoformat(),
                result.version,
                result.created_at.isoformat() if result.created_at else datetime.now().isoformat()
            ))
        
        return result.id

    def bulk_save_results(self, results: List[TestCaseResult]) -> bool:
        """批量保存测试结果"""
        
        if not results:
            return True
        
        for result in results:
            self._validate_result(result)
            if not result.id:
                result.id = str(uuid.uuid4())
            if not result.created_at:
                result.created_at = datetime.now()
            if not result.executed_at:
                result.executed_at = datetime.now()
        
        with self.db_manager._get_connection() as conn:
            for result in results:
                conn.execute('''
                    INSERT INTO test_results (
                        id, test_id, case_id, case_name, status, duration,
                        error_message, stack_trace, environment, executed_at, version, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    result.id, result.test_id, result.case_id, result.case_name,
                    result.status, result.duration, result.error_message,
                    result.stack_trace, json.dumps(result.environment or {}),
                    result.executed_at.isoformat(), result.version,
                    result.created_at.isoformat()
                ))
        
        return True

    def get_case_history(
        self,
        case_id: str,
        page: int = 1,
        size: int = 10
    ) -> Dict[str, Any]:
        """获取用例的执行历史"""
        
        offset = (page - 1) * size
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute('''
                SELECT * FROM test_results
                WHERE case_id = ?
                ORDER BY executed_at DESC
                LIMIT ? OFFSET ?
            ''', (case_id, size, offset))
            rows = cursor.fetchall()
            
            count_cursor = conn.execute('''
                SELECT COUNT(*) as total FROM test_results WHERE case_id = ?
            ''', (case_id,))
            total = count_cursor.fetchone()['total']
        
        items = []
        for row in rows:
            items.append({
                'result_id': row['id'],
                'test_id': row['test_id'],
                'version': row['version'],
                'status': row['status'],
                'duration': row['duration'],
                'error_message': row['error_message'],
                'executed_at': row['executed_at']
            })
        
        return {
            'case_id': case_id,
            'history': items,
            'total': total,
            'limit': size,
            'offset': offset
        }

    def get_test_results(
        self,
        test_id: str,
        page: int = 1,
        size: int = 20
    ) -> Dict[str, Any]:
        """获取指定测试的所有用例结果"""
        
        offset = (page - 1) * size
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute('''
                SELECT * FROM test_results
                WHERE test_id = ?
                ORDER BY executed_at DESC
                LIMIT ? OFFSET ?
            ''', (test_id, size, offset))
            rows = cursor.fetchall()
            
            count_cursor = conn.execute('''
                SELECT COUNT(*) as total FROM test_results WHERE test_id = ?
            ''', (test_id,))
            total = count_cursor.fetchone()['total']
        
        items = []
        for row in rows:
            items.append({
                'result_id': row['id'],
                'test_id': row['test_id'],
                'case_id': row['case_id'],
                'case_name': row['case_name'],
                'status': row['status'],
                'duration': row['duration'],
                'error_message': row['error_message'],
                'executed_at': row['executed_at']
            })
        
        return {
            'test_id': test_id,
            'results': items,
            'total': total,
            'limit': size,
            'offset': offset
        }

    def export_case_report(self, case_id: str, format: str = "json") -> ExportResult:
        """导出用例级报告"""
        
        if format not in ["json", "csv", "html"]:
            raise ValueError(f"不支持的格式: {format}")
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute('''
                SELECT * FROM test_results
                WHERE case_id = ?
                ORDER BY executed_at DESC
                LIMIT ?
            ''', (case_id, self.max_export_size))
            rows = cursor.fetchall()
        
        results = []
        for row in rows:
            results.append({
                'result_id': row['id'],
                'test_id': row['test_id'],
                'case_id': row['case_id'],
                'case_name': row['case_name'],
                'status': row['status'],
                'duration': row['duration'],
                'error_message': row['error_message'],
                'executed_at': row['executed_at']
            })
        
        statistics = self.get_case_statistics(case_id)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if format == "json":
            file_path = self._export_json(case_id, results, statistics, timestamp)
        elif format == "csv":
            file_path = self._export_csv(case_id, results, timestamp)
        else:
            file_path = self._export_html(case_id, results, statistics, timestamp)
        
        return ExportResult(
            format=format,
            file_path=file_path,
            record_count=len(results),
            generated_at=datetime.now()
        )

    def get_case_statistics(self, case_id: str) -> CaseStatistics:
        """获取用例统计信息"""
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute('''
                SELECT * FROM test_results
                WHERE case_id = ?
                ORDER BY executed_at DESC
            ''', (case_id,))
            rows = cursor.fetchall()
        
        if not rows:
            return CaseStatistics(
                case_id=case_id,
                total_runs=0,
                passed_count=0,
                failed_count=0,
                error_count=0,
                pass_rate=0.0,
                avg_duration=0.0
            )
        
        passed = sum(1 for r in rows if r['status'] == 'passed')
        failed = sum(1 for r in rows if r['status'] == 'failed')
        error = sum(1 for r in rows if r['status'] == 'error')
        total = len(rows)
        
        durations = [r['duration'] for r in rows if r['duration']]
        avg_duration = sum(durations) / len(durations) if durations else 0
        
        executed_times = [datetime.fromisoformat(r['executed_at']) for r in rows]
        
        return CaseStatistics(
            case_id=case_id,
            total_runs=total,
            passed_count=passed,
            failed_count=failed,
            error_count=error,
            pass_rate=passed / total if total > 0 else 0,
            avg_duration=avg_duration,
            last_executed=max(executed_times) if executed_times else None,
            first_executed=min(executed_times) if executed_times else None
        )

    def save_batch(self, batch: TestBatch) -> str:
        """保存测试批次"""
        
        batch.id = batch.id or str(uuid.uuid4())
        batch.created_at = batch.created_at or datetime.now()
        batch.updated_at = datetime.now()
        
        with self.db_manager._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO test_batches (
                    id, project, status, test_cases_version, subsystems,
                    started_at, completed_at, duration, report_git_commit,
                    summary, passed, failed, errors, total, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                batch.id, batch.project, batch.status, batch.test_cases_version,
                batch.subsystems, batch.started_at.isoformat() if batch.started_at else None,
                batch.completed_at.isoformat() if batch.completed_at else None,
                batch.duration, batch.report_git_commit, batch.summary,
                batch.passed or 0, batch.failed or 0, batch.errors or 0, batch.total or 0,
                batch.created_at.isoformat(), batch.updated_at.isoformat()
            ))
        
        return batch.id

    def get_batch(self, batch_id: str) -> Optional[TestBatch]:
        """获取测试批次"""
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute('''
                SELECT * FROM test_batches WHERE id = ?
            ''', (batch_id,))
            row = cursor.fetchone()
        
        if not row:
            return None
        
        return TestBatch(
            id=row['id'],
            project=row['project'],
            status=row['status'],
            test_cases_version=row['test_cases_version'],
            subsystems=row['subsystems'],
            started_at=datetime.fromisoformat(row['started_at']) if row['started_at'] else None,
            completed_at=datetime.fromisoformat(row['completed_at']) if row['completed_at'] else None,
            duration=row['duration'],
            report_git_commit=row['report_git_commit'],
            summary=row['summary'],
            passed=row['passed'] if 'passed' in row.keys() else 0,
            failed=row['failed'] if 'failed' in row.keys() else 0,
            errors=row['errors'] if 'errors' in row.keys() else 0,
            total=row['total'] if 'total' in row.keys() else 0,
            created_at=datetime.fromisoformat(row['created_at']),
            updated_at=datetime.fromisoformat(row['updated_at'])
        )

    def update_batch_status(self, batch_id: str, status: str) -> bool:
        """更新批次状态"""
        
        with self.db_manager._get_connection() as conn:
            conn.execute('''
                UPDATE test_batches
                SET status = ?, updated_at = ?
                WHERE id = ?
            ''', (status, datetime.now().isoformat(), batch_id))
        
        return True

    def _validate_result(self, result: TestCaseResult):
        """验证结果数据"""
        
        if not result.case_id:
            raise ValueError("case_id不能为空")
        
        if result.status not in ["passed", "failed", "error", "skipped"]:
            raise ValueError(f"无效的status: {result.status}")
        
        if result.duration and result.duration < 0:
            raise ValueError("duration不能为负数")

    def _export_json(self, case_id: str, results: List, statistics: CaseStatistics, timestamp: str) -> str:
        """导出JSON格式"""
        
        def convert_to_serializable(obj):
            if isinstance(obj, datetime):
                return obj.isoformat()
            elif hasattr(obj, '__dict__'):
                return {k: convert_to_serializable(v) for k, v in obj.__dict__.items()}
            elif isinstance(obj, list):
                return [convert_to_serializable(item) for item in obj]
            elif isinstance(obj, dict):
                return {k: convert_to_serializable(v) for k, v in obj.items()}
            return obj
        
        data = {
            'case_id': case_id,
            'statistics': convert_to_serializable(asdict(statistics)),
            'history': [convert_to_serializable(r) for r in results]
        }
        
        file_path = f"{self.export_dir}/case_{case_id}_{timestamp}.json"
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return file_path

    def _export_csv(self, case_id: str, results: List, timestamp: str) -> str:
        """导出CSV格式"""
        
        import csv
        
        file_path = f"{self.export_dir}/case_{case_id}_{timestamp}.csv"
        if results:
            headers = results[0].keys()
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=headers)
                writer.writeheader()
                writer.writerows(results)
        
        return file_path

    def _export_html(self, case_id: str, results: List, statistics: CaseStatistics, timestamp: str) -> str:
        """导出HTML格式"""
        
        html = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Case Report: {case_id}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
        .passed {{ color: green; }}
        .failed {{ color: red; }}
        .error {{ color: orange; }}
    </style>
</head>
<body>
    <h1>Test Case Report: {case_id}</h1>
    <h2>Statistics</h2>
    <ul>
        <li>Total Runs: {statistics.total_runs}</li>
        <li>Passed: {statistics.passed_count}</li>
        <li>Failed: {statistics.failed_count}</li>
        <li>Error: {statistics.error_count}</li>
        <li>Pass Rate: {statistics.pass_rate:.2%}</li>
        <li>Avg Duration: {statistics.avg_duration:.2f}s</li>
    </ul>
    <h2>History</h2>
    <table>
        <tr>
            <th>Test ID</th>
            <th>Status</th>
            <th>Duration</th>
            <th>Executed At</th>
        </tr>
'''
        
        for r in results:
            status_class = r.get('status', '')
            html += f'''        <tr>
            <td>{r.get('test_id', '')}</td>
            <td class="{status_class}">{r.get('status', '')}</td>
            <td>{r.get('duration', 0):.2f}s</td>
            <td>{r.get('executed_at', '')}</td>
        </tr>
'''
        
        html += '''    </table>
</body>
</html>'''
        
        file_path = f"{self.export_dir}/case_{case_id}_{timestamp}.html"
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return file_path
    
    def save_bug_report(self, bug: 'BugReport') -> str:
        """保存Bug报告"""
        bug.id = bug.id or f"BUG-TESTAGENT-{datetime.now().year}-{str(uuid.uuid4())[:4]}"
        bug.created_at = bug.created_at or datetime.now()
        bug.updated_at = datetime.now()
        
        with self.db_manager._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO bug_reports (
                    id, test_id, case_id, title, description, severity,
                    status, priority, git_url, assignee, resolution,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                bug.id, bug.test_id, bug.case_id, bug.title, bug.description,
                bug.severity, bug.status, bug.priority, bug.git_url, bug.assignee,
                bug.resolution, bug.created_at.isoformat(), bug.updated_at.isoformat()
            ))
        
        return bug.id
    
    def get_bugs(
        self,
        project: Optional[str] = None,
        version: Optional[str] = None,
        case_id: Optional[str] = None,
        test_id: Optional[str] = None,
        status: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """查询Bug报告"""
        
        query = "SELECT * FROM bug_reports WHERE 1=1"
        params = []
        
        if test_id:
            query += " AND test_id = ?"
            params.append(test_id)
        if case_id:
            query += " AND case_id = ?"
            params.append(case_id)
        if status:
            query += " AND status = ?"
            params.append(status)
        if severity:
            query += " AND severity = ?"
            params.append(severity)
        
        query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute(query, params)
            rows = cursor.fetchall()
            
            count_query = "SELECT COUNT(*) as total FROM bug_reports WHERE 1=1"
            count_params = []
            if test_id:
                count_query += " AND test_id = ?"
                count_params.append(test_id)
            if case_id:
                count_query += " AND case_id = ?"
                count_params.append(case_id)
            if status:
                count_query += " AND status = ?"
                count_params.append(status)
            if severity:
                count_query += " AND severity = ?"
                count_params.append(severity)
            
            count_cursor = conn.execute(count_query, count_params)
            total = count_cursor.fetchone()['total']
        
        bugs = []
        for row in rows:
            bugs.append({
                'id': row['id'],
                'test_id': row['test_id'],
                'case_id': row['case_id'],
                'title': row['title'],
                'severity': row['severity'],
                'status': row['status'],
                'created_at': row['created_at']
            })
        
        return {
            'bugs': bugs,
            'total': total
        }
    
    def get_all_batches(
        self,
        project: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """查询所有测试批次"""
        
        query = "SELECT * FROM test_batches WHERE 1=1"
        params = []
        
        if project:
            query += " AND project = ?"
            params.append(project)
        if status:
            query += " AND status = ?"
            params.append(status)
        
        query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute(query, params)
            rows = cursor.fetchall()
            
            count_query = "SELECT COUNT(*) as total FROM test_batches WHERE 1=1"
            count_params = []
            if project:
                count_query += " AND project = ?"
                count_params.append(project)
            if status:
                count_query += " AND status = ?"
                count_params.append(status)
            
            count_cursor = conn.execute(count_query, count_params)
            total = count_cursor.fetchone()['total']
        
        batches = []
        for row in rows:
            summary = {}
            if row['summary']:
                try:
                    summary = json.loads(row['summary'])
                except:
                    pass
            
            batches.append({
                'test_id': row['id'],
                'project': row['project'],
                'status': row['status'],
                'summary': summary,
                'started_at': row['started_at'],
                'completed_at': row['completed_at']
            })
        
        return {
            'tests': batches,
            'total': total,
            'limit': limit,
            'offset': offset
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取全局测试统计"""
        
        with self.db_manager._get_connection() as conn:
            cursor = conn.execute('''
                SELECT 
                    COUNT(*) as total_tests,
                    SUM(CASE WHEN status = 'passed' THEN 1 ELSE 0 END) as passed,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                    SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors
                FROM test_results
            ''')
            row = cursor.fetchone()
            
            return {
                'total_tests': row['total_tests'] or 0,
                'passed': row['passed'] or 0,
                'failed': row['failed'] or 0,
                'errors': row['errors'] or 0
            }
    
    def parse_pytest_output(self, output: str, test_id: str) -> List[TestCaseResult]:
        """解析pytest输出，获取每个用例的结果"""
        import re
        from datetime import datetime
        
        results = []
        lines = output.split('\n')
        
        for line in lines:
            line = line.strip()
            
            pattern = r'(.+?)\s+(PASSED|FAILED|ERROR|SKIPPED|XPASS|XFAIL)'
            match = re.match(pattern, line)
            
            if match:
                case_path = match.group(1)
                status_str = match.group(2)
                
                if status_str in ['PASSED', 'FAILED', 'ERROR', 'SKIPPED']:
                    status = status_str.lower()
                    if status_str == 'PASSED':
                        status = 'passed'
                    elif status_str == 'FAILED':
                        status = 'failed'
                    elif status_str == 'ERROR':
                        status = 'error'
                    elif status_str == 'SKIPPED':
                        status = 'skipped'
                    
                    case_name = case_path.split('::')[-1] if '::' in case_path else case_path
                    
                    duration_match = re.search(r'\[(\d+\.?\d*)s\]', line)
                    duration = float(duration_match.group(1)) if duration_match else 0.0
                    
                    error_message = None
                    if status == 'failed' or status == 'error':
                        error_message = line[:500]
                    
                    case_result = TestCaseResult(
                        id=str(uuid.uuid4()),
                        test_id=test_id,
                        case_id=case_name,
                        case_name=case_path,
                        status=status,
                        duration=duration,
                        error_message=error_message,
                        executed_at=datetime.now()
                    )
                    results.append(case_result)
        
        return results
    
    def save_batch_case_results(self, test_id: str, output: str) -> int:
        """解析并保存所有用例结果，返回保存数量"""
        case_results = self.parse_pytest_output(output, test_id)
        
        for result in case_results:
            self.save_case_result(result)
        
        return len(case_results)
