"""
Jenkins API Client for test-agent

实现test-agent与Jenkins的集成：
1. 获取Jenkins构建结果
2. 解析JUnit XML测试报告
3. 触发构建（可选）
"""

import os
import json
import time
import xml.etree.ElementTree as ET
from typing import Optional, Dict, List, Any
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

POLLING_INTERVAL = 5


@dataclass
class JenkinsBuild:
    """Jenkins构建信息"""
    job_name: str
    build_number: int
    build_id: str
    status: str
    result: Optional[str]
    duration: int
    url: str
    timestamp: int
    phases: Optional[List[str]] = None


@dataclass
class TestCaseResult:
    """单条测试用例结果"""
    class_name: str
    name: str
    status: str
    time: float
    error_message: Optional[str] = None
    stack_trace: Optional[str] = None


@dataclass
class JenkinsTestResult:
    """Jenkins测试结果"""
    build_id: str
    job_name: str
    total_tests: int
    passed: int
    failed: int
    skipped: int
    duration: float
    test_cases: List[TestCaseResult]
    report_url: Optional[str] = None
    timestamp: Optional[datetime] = None
    status: Optional[str] = None


class JenkinsClient:
    """Jenkins API客户端"""
    
    def __init__(
        self,
        jenkins_url: str = "http://8.149.137.233:8080/jenkins",
        username: Optional[str] = None,
        api_token: Optional[str] = None
    ):
        self.jenkins_url = jenkins_url.rstrip('/')
        self.username = username
        self.api_token = api_token
        self.session = self._create_session()
    
    def _create_session(self):
        """创建HTTP会话"""
        import requests
        session = requests.Session()
        if self.username and self.api_token:
            session.auth = (self.username, self.api_token)
        return session
    
    def _build_url(self, path: str) -> str:
        """构建完整URL"""
        return f"{self.jenkins_url}/{path.lstrip('/')}"
    
    def get_build_info(self, job_name: str, build_number: str = "lastBuild") -> Optional[Dict]:
        """
        获取构建信息
        
        Args:
            job_name: 任务名称
            build_number: 构建号或lastBuild
            
        Returns:
            构建信息字典
        """
        import time
        url = self._build_url(f"/job/{job_name}/{build_number}/api/json")
        last_error = None
        for attempt in range(3):
            try:
                response = self.session.get(url, timeout=30)
                response.raise_for_status()
                return response.json()
            except Exception as e:
                last_error = e
                logger.warning(f"获取构建信息失败 (尝试 {attempt + 1}/3): {e}")
                if attempt < 2:
                    time.sleep(2)
        logger.error(f"获取构建信息失败，已重试3次: {last_error}")
        return None
    
    def get_build_result(self, job_name: str, build_number: str = "lastBuild") -> Optional[str]:
        """
        获取构建结果 (SUCCESS/FAILURE/ABORTED/UNSTABLE)
        """
        info = self.get_build_info(job_name, build_number)
        if info:
            return info.get('result')
        return None
    
    def get_test_result(self, job_name: str, build_number: str = "lastBuild") -> Optional[JenkinsTestResult]:
        """
        获取测试结果
        
        Args:
            job_name: 任务名称
            build_number: 构建号或lastBuild
            
        Returns:
            JenkinsTestResult对象，status字段表示: "success", "no_tests", "error"
        """
        info = self.get_build_info(job_name, build_number)
        if not info:
            return None
        
        build_id = f"{job_name}#{info.get('number')}"
        
        test_result = JenkinsTestResult(
            build_id=build_id,
            job_name=job_name,
            total_tests=0,
            passed=0,
            failed=0,
            skipped=0,
            duration=info.get('duration', 0) / 1000,
            test_cases=[],
            report_url=info.get('url'),
            timestamp=datetime.fromtimestamp(info.get('timestamp', 0) / 1000) if info.get('timestamp') else None,
            status="no_tests"
        )
        
        actions = info.get('actions', [])
        for action in actions:
            if action.get('_class') == 'jenkins.tasks.junit.TestResultAction':
                test_result.total_tests = action.get('totalCount', 0)
                test_result.passed = action.get('passCount', 0)
                test_result.failed = action.get('failCount', 0)
                test_result.skipped = action.get('skipCount', 0)
                test_result.status = "success"
                
                test_data = action.get('result', {})
                test_result.duration = test_data.get('duration', 0)
                
                child_reports = test_data.get('childReports', [])
                for child_report in child_reports:
                    report = child_report.get('result', {})
                    suites = report.get('suites', [])
                    for suite in suites:
                        cases = suite.get('cases', [])
                        for case in cases:
                            test_case = TestCaseResult(
                                class_name=case.get('className', ''),
                                name=case.get('name', ''),
                                status='passed' if not case.get('status') or case.get('status') == 'PASSED' else 'failed',
                                time=case.get('duration', 0),
                                error_message=case.get('errorDetails'),
                                stack_trace=case.get('errorStackTrace')
                            )
                            test_result.test_cases.append(test_case)
                break
        
        return test_result
    
    def get_test_report_xml(self, job_name: str, build_number: str = "lastBuild") -> Optional[str]:
        """
        获取JUnit XML测试报告
        """
        url = self._build_url(f"/job/{job_name}/{build_number}/testReport/api/xml")
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return response.text
        except Exception as e:
            logger.error(f"获取测试报告XML失败: {e}")
            return None
    
    def parse_junit_xml(self, xml_content: str) -> Optional[JenkinsTestResult]:
        """
        解析JUnit XML格式的测试报告
        
        Args:
            xml_content: JUnit XML内容
            
        Returns:
            JenkinsTestResult对象，如果解析失败返回None
        """
        if not xml_content or not xml_content.strip():
            logger.warning("XML内容为空")
            return None
        try:
            root = ET.fromstring(xml_content)
        except ET.ParseError as e:
            logger.error(f"XML解析失败: {e}")
            return None
        
        total_tests = 0
        passed = 0
        failed = 0
        skipped = 0
        duration = 0.0
        test_cases = []
        
        for testsuite in root.findall('.//testsuite'):
            total_tests += int(testsuite.get('tests', 0))
            passed += int(testsuite.get('tests', 0)) - int(testsuite.get('failures', 0)) - int(testsuite.get('skipped', 0))
            failed += int(testsuite.get('failures', 0))
            skipped += int(testsuite.get('skipped', 0))
            duration += float(testsuite.get('time', 0))
            
            for testcase in testsuite.findall('testcase'):
                status = 'passed'
                error_message = None
                stack_trace = None
                
                failure = testcase.find('failure')
                if failure is not None:
                    status = 'failed'
                    error_message = failure.get('message')
                    stack_trace = failure.text
                
                skipped_elem = testcase.find('skipped')
                if skipped_elem is not None:
                    status = 'skipped'
                
                test_case = TestCaseResult(
                    class_name=testcase.get('classname', ''),
                    name=testcase.get('name', ''),
                    status=status,
                    time=float(testcase.get('time', 0)),
                    error_message=error_message,
                    stack_trace=stack_trace
                )
                test_cases.append(test_case)
        
        return JenkinsTestResult(
            build_id="parsed-xml",
            job_name="unknown",
            total_tests=total_tests,
            passed=passed,
            failed=failed,
            skipped=skipped,
            duration=duration,
            test_cases=test_cases
        )
    
    def trigger_build(self, job_name: str, parameters: Optional[Dict] = None) -> bool:
        """
        触发Jenkins构建
        
        Args:
            job_name: 任务名称
            parameters: 构建参数
            
        Returns:
            是否成功触发
        """
        url = self._build_url(f"/job/{job_name}/build")
        if parameters:
            url = self._build_url(f"/job/{job_name}/buildWithParameters")
            data = parameters
        else:
            data = None
        
        try:
            response = self.session.post(url, data=data, timeout=30)
            return response.status_code in (200, 201, 302)
        except Exception as e:
            logger.error(f"触发构建失败: {e}")
            return False
    
    def get_queue_info(self, queue_id: int) -> Optional[Dict]:
        """
        获取队列信息（构建排队中）
        """
        url = self._build_url(f"/queue/item/{queue_id}/api/json")
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取队列信息失败: {e}")
            return None
    
    def wait_for_build(self, job_name: str, build_number: int, timeout: int = 300) -> Optional[JenkinsBuild]:
        """
        等待构建完成
        
        Args:
            job_name: 任务名称
            build_number: 构建号
            timeout: 超时时间（秒）
            
        Returns:
            JenkinsBuild对象
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            info = self.get_build_info(job_name, str(build_number))
            if info:
                if info.get('building') == False:
                    return JenkinsBuild(
                        job_name=job_name,
                        build_number=build_number,
                        build_id=f"{job_name}#{build_number}",
                        status='completed',
                        result=info.get('result'),
                        duration=info.get('duration', 0) // 1000,
                        url=info.get('url') or '',
                        timestamp=info.get('timestamp', 0)
                    )
            time.sleep(POLLING_INTERVAL)
        
        return None


def create_jenkins_client() -> JenkinsClient:
    """创建Jenkins客户端（从配置读取）"""
    from src.core.config_manager import ConfigManager
    
    config = ConfigManager()
    jenkins_url = config.get('jenkins.url', 'http://8.149.137.233:8080/jenkins') or 'http://8.149.137.233:8080/jenkins'
    username = config.get('jenkins.username')
    api_token = config.get('jenkins.api_token')
    
    return JenkinsClient(jenkins_url, username, api_token)
