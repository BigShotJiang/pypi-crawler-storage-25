"""
测试分发器 - 根据project动态选择测试文件
"""

import os
import yaml
from pathlib import Path
from typing import List, Optional


class TestDispatcher:
    """测试分发器 - 根据project参数选择对应的测试文件"""
    
    def __init__(self, config_path: Optional[str] = None, cache_dir: Optional[str] = None):
        if config_path is None:
            current = Path(__file__).resolve().parent
            for parent in [current] + list(current.parents):
                config_path = parent / 'config' / 'test_dispatcher.yaml'
                if config_path.exists():
                    break
        
        self.config_path = config_path
        self.cache_dir = Path(cache_dir) if cache_dir else Path('state/code_cache')
        self._load_config()
    
    def _load_config(self):
        """每次都重新加载配置"""
        if self.config_path and Path(self.config_path).exists():
            with open(self.config_path, 'r') as f:
                config = yaml.safe_load(f) or {}
        else:
            config = self._get_default_config()
        
        self.test_paths = config.get('test_paths', {})
        self.unknown_project_strategy = config.get('unknown_project', 'error')
    
    def _get_default_config(self) -> dict:
        return {
            'test_paths': {
                'test-agent': [
                    'tests/test_agent_daemon.py',
                    'tests/test_agent_behavior.py',
                    'tests/test_v3_0_core_services.py'
                ]
            },
            'unknown_project': 'error'
        }
    
    def _discover_tests_in_cache(self, project: str) -> List[str]:
        """自动发现测试文件 - 从cache_dir中扫描"""
        discovered = []
        
        if not self.cache_dir.exists():
            return discovered
        
        for commit_dir in self.cache_dir.iterdir():
            if commit_dir.is_dir() and commit_dir.name != project:
                continue
            
            tests_dir = commit_dir / 'tests'
            if tests_dir.exists():
                for test_file in sorted(tests_dir.glob('test_*.py')):
                    discovered.append(f'tests/{test_file.name}')
            
            for subdir in tests_dir.glob('*'):
                if subdir.is_dir():
                    for test_file in sorted(subdir.glob('test_*.py')):
                        discovered.append(f'tests/{subdir.name}/{test_file.name}')
        
        return discovered
    
    def get_test_paths(self, project: str) -> List[str]:
        self._load_config()
        
        if project in self.test_paths:
            return self.test_paths[project]
        
        discovered = self._discover_tests_in_cache(project)
        if discovered:
            return discovered
        
        if self.unknown_project_strategy == 'error':
            raise ValueError(f"未知项目: {project}")
        elif self.unknown_project_strategy == 'default':
            return self.test_paths.get('test-agent', [])
        
        return []
    
    def get_all_projects(self) -> List[str]:
        self._load_config()
        return list(self.test_paths.keys())
