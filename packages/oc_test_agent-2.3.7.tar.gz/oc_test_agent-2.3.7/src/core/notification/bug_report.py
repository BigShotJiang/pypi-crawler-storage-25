"""
缺陷报告生成模块
"""

import os
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
import aiohttp


class BugReportGenerator:
    """缺陷报告生成器"""
    
    def __init__(self, pm_agent_url: str = None):
        self.pm_agent_url = pm_agent_url or os.getenv("PM_AGENT_URL") or "http://pm-agent:8003"
    
    async def generate_and_send(self, test_result: Any, failed_cases: List[Dict] = None) -> Optional[List[Dict]]:
        """生成并发送缺陷报告"""
        if test_result.failed == 0 and test_result.errors == 0:
            return None
        
        failed_cases = failed_cases or []
        reports = []
        
        for case in failed_cases:
            report = self._build_case_report(test_result, case)
            reports.append(report)
            await self._save_to_database(report)
            await self._send_to_pm_agent(report)
        
        if not reports:
            report = self._build_report(test_result)
            reports.append(report)
            await self._save_to_database(report)
            await self._send_to_pm_agent(report)
        
        return reports
    
    def _build_report(self, test_result: Any) -> Dict[str, Any]:
        """构建汇总缺陷报告"""
        severity = "high" if test_result.failed > 5 else "medium"
        
        return {
            "title": f"[测试失败] {test_result.project} {test_result.version} - {test_result.failed}个用例失败",
            "description": self._build_description(test_result),
            "severity": severity,
            "labels": ["test-failed", "auto-report"],
            "test_id": test_result.id,
            "case_id": "",
            "source": "test-agent"
        }
    
    def _build_case_report(self, test_result: Any, case: Dict) -> Dict[str, Any]:
        """为单个失败用例构建缺陷报告"""
        severity = "high"
        
        error_msg = case.get('error_message', '') or ''
        stack_trace = case.get('stack_trace', '') or ''
        
        description_lines = [
            f"**项目**: {test_result.project}",
            f"**版本**: {test_result.version}",
            f"**测试ID**: {test_result.id}",
            f"**失败用例**: {case.get('test_case_name', 'unknown')}",
            f"**状态**: {case.get('status', 'failed')}",
            "",
            f"**错误信息**:",
            f"```",
            error_msg[:500] if error_msg else "无详细错误信息",
            f"```",
        ]
        
        if stack_trace:
            description_lines.extend([
                "",
                f"**堆栈信息**:",
                f"```",
                stack_trace[:500],
                f"```",
            ])
        
        description_lines.extend([
            "",
            f"详情: {os.getenv('TEST_AGENT_URL', 'http://test-agent:8004')}/tests/{test_result.id}"
        ])
        
        return {
            "title": f"[测试失败] {case.get('test_case_name', 'unknown')}",
            "description": "\n".join(description_lines),
            "severity": severity,
            "labels": ["test-failed", "auto-report"],
            "test_id": test_result.id,
            "case_id": case.get('test_case_name', ''),
            "source": "test-agent",
            "error_message": error_msg,
            "stack_trace": stack_trace
        }
    
    def _build_description(self, test_result: Any) -> str:
        """构建报告描述"""
        lines = [
            f"测试执行失败",
            "",
            f"**项目**: {test_result.project}",
            f"**版本**: {test_result.version}",
            f"**测试ID**: {test_result.id}",
            f"**失败用例**: {test_result.failed}",
            f"**错误用例**: {test_result.errors}",
            f"**通过用例**: {test_result.passed}",
            f"**总用例**: {test_result.total}",
            "",
            f"详情: {os.getenv('TEST_AGENT_URL', 'http://test-agent:8004')}/tests/{test_result.id}"
        ]
        return "\n".join(lines)
    
    async def _save_to_database(self, report: Dict[str, Any]):
        """保存缺陷报告到本地数据库"""
        try:
            from ..result_storage_service import ResultStorageService, BugReport
            
            storage = ResultStorageService()
            
            bug = BugReport(
                id=f"BUG-TESTAGENT-{datetime.now().year}-{str(uuid.uuid4())[:8]}",
                test_id=report.get('test_id', ''),
                case_id=report.get('case_id', ''),
                title=report.get('title', ''),
                description=report.get('description', ''),
                severity=report.get('severity', 'medium'),
                status='open',
                priority=None,
                git_url=None,
                assignee=None,
                resolution=None,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            
            storage.save_bug_report(bug)
        except Exception as e:
            print(f"保存缺陷报告到数据库失败: {e}")
    
    async def _send_to_pm_agent(self, report: Dict[str, Any]):
        """发送到pm-agent"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.pm_agent_url}/api/issues",
                    json=report,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as resp:
                    resp.raise_for_status()
        except Exception as e:
            print(f"发送缺陷报告失败: {e}")


_bug_report_generator: Optional[BugReportGenerator] = None


def get_bug_report_generator() -> BugReportGenerator:
    """获取缺陷报告生成器"""
    global _bug_report_generator
    if _bug_report_generator is None:
        _bug_report_generator = BugReportGenerator()
    return _bug_report_generator