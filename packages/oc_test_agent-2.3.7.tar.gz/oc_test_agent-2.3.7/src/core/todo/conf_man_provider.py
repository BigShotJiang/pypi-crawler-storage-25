"""ConfMan HTTP配置提供者 - 通过HTTP API获取配置"""

import os
from pathlib import Path
from typing import Optional, Dict, Any
import requests


class ConfManHttpProvider:
    """HTTP API-based configuration provider"""
    
    def __init__(self, api_url: str, api_key: Optional[str] = None):
        self._api_url = api_url.rstrip("/")
        self._api_key = api_key or os.getenv("CONF_MAN_API_KEY", "")
        self._session = requests.Session()
        if self._api_key:
            self._session.headers.update({"X-API-Key": self._api_key})
        
        self._project_path = os.environ.get("OC_PROJECT_PATH") or str(Path.cwd())
        self._base_dir = Path(self._project_path)
    
    def _get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """发送GET请求"""
        url = f"{self._api_url}{endpoint}"
        try:
            response = self._session.get(url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.RequestException:
            return {}
    
    def _get_path(self, key: str, default: str) -> str:
        """从环境变量或本地配置获取路径"""
        env_key = f"OC_{key.upper()}"
        env_value = os.getenv(env_key)
        if env_value:
            return env_value
        return str(self._base_dir / default)
    
    def _get_file(self, key: str, default: str) -> str:
        """获取文件路径"""
        return self._get_path(key, default)
    
    def _get_config_file(self, key: str, default: str) -> str:
        """获取配置文件路径"""
        config_dir = self._get_path("config_dir", "config")
        return str(Path(config_dir) / default)
    
    def get_data_dir(self) -> str:
        return self._get_path("data_dir", "state")
    
    def get_config_dir(self) -> str:
        return self._get_path("config_dir", "config")
    
    def get_log_dir(self) -> str:
        return self._get_path("log_dir", "logs")
    
    def get_temp_dir(self) -> str:
        return self._get_path("temp_dir", "tmp")
    
    def get_todo_db_path(self) -> str:
        return str(self._base_dir / "state" / "todos.db")
    
    def get_state_file_path(self) -> str:
        return self._get_file("state_file", "project_state.yaml")
    
    def get_lock_file_path(self, name: str) -> str:
        data_dir = self.get_data_dir()
        return str(Path(data_dir) / f"{name}.lock")
    
    def get_agent_status_db_path(self) -> str:
        return self._get_file("agent_status_db", "agent_status.db")
    
    def get_session_dir(self) -> str:
        return self._get_file("session_dir", "sessions")
    
    def get_adhoc_todos_path(self) -> str:
        return self._get_file("adhoc_todos", "agent_adhoc_todos.yaml")
    
    def get_identity_file_path(self) -> str:
        return self._get_file("identity_file", "agent.identity")
    
    def get_pid_file_path(self) -> str:
        return self._get_file("pid_file", "agent.pid")
    
    def get_opencode_db_path(self) -> str:
        return self._get_file("opencode_db", ".opencode/opencode.db")
    
    def get_agents_config_path(self) -> str:
        return self._get_config_file("agents", "agents.yaml")
    
    def get_git_sync_config_path(self) -> str:
        return self._get_config_file("git_sync", "git_sync.yaml")
    
    def get_notification_config_path(self) -> str:
        return self._get_config_file("notification", "notification.yaml")
    
    def get_skill_index_path(self) -> str:
        return self._get_config_file("skill_index", "skill_index.yaml")
    
    def get_file_owners_path(self) -> str:
        return self._get_config_file("file_owners", "file_owners.yaml")
    
    def get_full_path(self, relative_path: str, base_path: Optional[Path] = None) -> Path:
        """Get full path by joining base path with relative path"""
        base = base_path or self._base_dir
        return base / relative_path
    
    def get_version(self) -> str:
        """Get conf-man version from API"""
        try:
            result = self._get("/health")
            return result.get("version", "unknown")
        except Exception:
            return "unknown"
