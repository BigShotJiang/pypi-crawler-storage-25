"""TODO模块工厂类。

提供创建 TODO 相关实例的工厂方法，支持依赖注入。
"""
import logging
from typing import Optional, Type, TypeVar, Any
from pathlib import Path

from ..config import AppConfig, IConfigProvider, LocalConfigProvider
from .interfaces import ITodoStorage, ITodoIdGenerator


logger = logging.getLogger(__name__)


T = TypeVar('T')


class TodoModuleFactory:
    """TODO模块工厂类"""
    
    @staticmethod
    def create_storage(
        config: Optional[AppConfig] = None,
        db_path: Optional[str] = None
    ) -> ITodoStorage:
        """创建TODO存储实例
        
        Args:
            config: 应用配置
            db_path: 自定义数据库路径
        
        Returns:
            ITodoStorage: TODO存储实例
        """
        from ..todo_storage import TodoStorage
        
        if config:
            storage = TodoStorage(config.todo_db_path)
        elif db_path:
            storage = TodoStorage(db_path)
        else:
            storage = TodoStorage()
        
        return storage
    
    @staticmethod
    def create_id_generator(
        config: Optional[AppConfig] = None,
        state_file: Optional[str] = None,
        agent_id: Optional[str] = None
    ) -> ITodoIdGenerator:
        """创建ID生成器实例
        
        Args:
            config: 应用配置
            state_file: 状态文件路径
            agent_id: Agent ID
        
        Returns:
            ITodoIdGenerator: ID生成器实例
        """
        from ..todo_id_generator import TodoIdGenerator
        
        if config:
            generator = TodoIdGenerator(
                agent_id=agent_id,
                state_file=config.state_file_path
            )
        elif state_file:
            generator = TodoIdGenerator(
                agent_id=agent_id,
                state_file=state_file
            )
        else:
            generator = TodoIdGenerator(agent_id=agent_id)
        
        return generator
    
    @staticmethod
    def create_queue_manager(
        config: Optional[AppConfig] = None,
        db_path: Optional[str] = None
    ):
        """创建队列管理器实例
        
        Args:
            config: 应用配置
            db_path: 自定义数据库路径
        
        Returns:
            TodoQueueManager: 队列管理器实例
        """
        from ..todo_queue_manager import TodoQueueManager
        
        if config:
            manager = TodoQueueManager(db_path or str(config.todo_db_path))
        elif db_path:
            manager = TodoQueueManager(db_path)
        else:
            manager = TodoQueueManager()
        
        return manager
    
    @staticmethod
    def create_sync_manager(
        config: Optional[AppConfig] = None,
        project_path: Optional[str] = None
    ):
        """创建同步管理器实例
        
        Args:
            config: 应用配置
            project_path: 项目路径
        
        Returns:
            TodoSyncManager: 同步管理器实例
        """
        from ..todo_sync_manager import TodoSyncManager
        
        if config:
            manager = TodoSyncManager(str(config.project_path))
        elif project_path:
            manager = TodoSyncManager(project_path)
        else:
            manager = TodoSyncManager()
        
        return manager


class ConfigFactory:
    """配置工厂类"""
    
    @staticmethod
    def create_config_provider(
        provider_type: str = "local",
        project_path: Optional[str] = None,
        **kwargs
    ) -> IConfigProvider:
        """创建配置提供者实例
        
        Args:
            provider_type: 提供者类型 ("local" 或 "conf_man")
            project_path: 项目路径
            **kwargs: 其他参数
        
        Returns:
            IConfigProvider: 配置提供者实例
        """
        if provider_type == "local":
            return LocalConfigProvider(Path(project_path) if project_path else None)
        
        if provider_type == "conf_man":
            import os
            conf_man_api_url = os.getenv("CONF_MAN_API_URL")
            
            if not conf_man_api_url:
                logger.info("CONF_MAN_API_URL not set, falling back to local provider")
                return LocalConfigProvider(Path(project_path) if project_path else None)
            
            try:
                from ..conf_man_client import get_conf_man_client
                client = get_conf_man_client(api_url=conf_man_api_url)
                if client.health_check():
                    from .conf_man_provider import ConfManHttpProvider
                    return ConfManHttpProvider(conf_man_api_url)
                else:
                    logger.warning("conf-man API not available, falling back to local provider")
                    return LocalConfigProvider(Path(project_path) if project_path else None)
            except Exception as e:
                logger.warning(f"conf-man connection failed: {e}, falling back to local provider")
                return LocalConfigProvider(Path(project_path) if project_path else None)
        
        raise ValueError(f"Unknown provider type: {provider_type}")
    
    @staticmethod
    def create_app_config(
        project_path: Optional[str] = None,
        config_provider: Optional[IConfigProvider] = None
    ) -> AppConfig:
        """创建应用配置实例
        
        Args:
            project_path: 项目路径
            config_provider: 配置提供者
        
        Returns:
            AppConfig: 应用配置实例
        """
        return AppConfig(project_path, config_provider)
