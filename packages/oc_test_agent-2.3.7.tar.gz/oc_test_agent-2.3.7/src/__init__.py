
import os
from pathlib import Path

OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')

state_path = Path(OC_STATE_DIR)
if not state_path.is_absolute():
    state_path = Path(os.getcwd()) / OC_STATE_DIR

state_path.mkdir(parents=True, exist_ok=True)
(state_path / 'projects').mkdir(exist_ok=True)
(state_path / 'test_logs').mkdir(exist_ok=True)
