"""Unit tests for MSSQL connection-string builder helpers and backend."""

from __future__ import annotations

import sys
import threading
import types
from typing import Any
from unittest.mock import MagicMock

import pytest

from mcp_tools_sql.backends.mssql import (
    MSSQLBackend,
    _build_connection_string,
    _odbc_escape,
    build_sanitized_connection_string,
)
from mcp_tools_sql.config.models import ConnectionConfig
from tests.conftest import MSSQLTestEnv


@pytest.fixture
def fake_pyodbc(monkeypatch: pytest.MonkeyPatch) -> Any:
    """Replace pyodbc with a fake module exposing connect() returning a Mock."""
    fake = types.ModuleType("pyodbc")
    error_cls = type("Error", (Exception,), {})
    operational_error_cls = type("OperationalError", (error_cls,), {})
    fake.Error = error_cls  # type: ignore[attr-defined]
    fake.OperationalError = operational_error_cls  # type: ignore[attr-defined]
    fake.connect = MagicMock(  # type: ignore[attr-defined]
        return_value=MagicMock(name="connection")
    )
    monkeypatch.setitem(sys.modules, "pyodbc", fake)
    return fake


def _cfg(**kw: Any) -> ConnectionConfig:
    """Build a ConnectionConfig with sensible defaults for tests."""
    base: dict[str, Any] = {
        "backend": "mssql",
        "host": "h",
        "port": 1433,
        "database": "d",
        "username": "u",
        "password": "p",
    }
    base.update(kw)
    return ConnectionConfig(**base)


class TestOdbcEscape:
    """Tests for `_odbc_escape`."""

    def test_plain_value_unchanged(self) -> None:
        assert _odbc_escape("plain") == "plain"

    def test_value_with_semicolon_wrapped(self) -> None:
        assert _odbc_escape("a;b") == "{a;b}"

    def test_value_with_equals_wrapped(self) -> None:
        assert _odbc_escape("a=b") == "{a=b}"

    def test_value_with_opening_brace_wrapped(self) -> None:
        assert _odbc_escape("a{b") == "{a{b}"

    def test_value_with_closing_brace_doubled(self) -> None:
        assert _odbc_escape("a}b") == "{a}}b}"

    def test_value_with_leading_space_wrapped(self) -> None:
        assert _odbc_escape(" a") == "{ a}"

    def test_value_with_trailing_space_wrapped(self) -> None:
        assert _odbc_escape("a ") == "{a }"

    def test_empty_value_returned_empty(self) -> None:
        assert _odbc_escape("") == ""


class TestConnectionStringBuilder:
    """Tests for `_build_connection_string`."""

    def test_password_auth_basic(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            username="u",
            password="p",
        )
        s = _build_connection_string(c)
        assert "Server=h,1433" in s
        assert "UID=u" in s and "PWD=p" in s
        assert "Trusted_Connection" not in s
        assert "Encrypt=yes" in s
        assert "TrustServerCertificate=no" in s

    def test_trusted_connection_omits_uid_pwd(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            trusted_connection=True,
        )
        s = _build_connection_string(c)
        assert "Trusted_Connection=yes" in s
        assert "UID=" not in s and "PWD=" not in s

    def test_port_zero_omits_port_from_server(self) -> None:
        """port=0 (the model default) → Server=host with no ,port suffix."""
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=0,
            database="d",
            trusted_connection=True,
        )
        s = _build_connection_string(c)
        assert "Server=h;" in s
        assert "Server=h," not in s

    def test_named_instance_with_port_zero(self) -> None:
        """host=server\\instance, port=0 → Server=server\\instance (no port).

        This is the form ODBC needs so SQL Browser can resolve the named
        instance's dynamic port. Specifying a port alongside an instance
        name makes ODBC bypass SQL Browser, which is almost never desired.
        """
        c = ConnectionConfig(
            backend="mssql",
            host=r"myserver\inst",
            port=0,
            database="d",
            trusted_connection=True,
        )
        s = _build_connection_string(c)
        assert r"Server=myserver\inst;" in s
        assert ",1433" not in s

    def test_port_uses_comma_not_colon(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1234,
            database="d",
            trusted_connection=True,
        )
        s = _build_connection_string(c)
        assert "Server=h,1234" in s
        assert "h:1234" not in s

    def test_password_with_semicolon_escaped(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            username="u",
            password="a;b",
        )
        assert "PWD={a;b}" in _build_connection_string(c)

    def test_password_with_brace_doubled(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            username="u",
            password="a}b",
        )
        assert "PWD={a}}b}" in _build_connection_string(c)

    def test_encrypt_false(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            trusted_connection=True,
            encrypt=False,
        )
        assert "Encrypt=no" in _build_connection_string(c)

    def test_trust_server_certificate_true(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            trusted_connection=True,
            trust_server_certificate=True,
        )
        assert "TrustServerCertificate=yes" in _build_connection_string(c)

    def test_driver_wrapped_in_braces(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            trusted_connection=True,
            driver="ODBC Driver 18 for SQL Server",
        )
        assert "Driver={ODBC Driver 18 for SQL Server}" in _build_connection_string(c)

    def test_no_trailing_semicolon(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            trusted_connection=True,
        )
        assert not _build_connection_string(c).endswith(";")

    def test_database_with_semicolon_escaped(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="db;weird",
            trusted_connection=True,
        )
        assert "Database={db;weird}" in _build_connection_string(c)


class TestSanitizedConnectionString:
    """Tests for the public ``build_sanitized_connection_string`` helper."""

    def test_password_replaced_with_stars(self) -> None:
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            username="u",
            password="supersecret",
        )
        s = build_sanitized_connection_string(c)
        assert "supersecret" not in s
        assert "PWD=***" in s

    def test_trusted_connection_no_redaction_marker(self) -> None:
        """trusted_connection has no password → string identical to raw."""
        c = ConnectionConfig(
            backend="mssql",
            host="h",
            port=1433,
            database="d",
            trusted_connection=True,
        )
        s = build_sanitized_connection_string(c)
        assert "Trusted_Connection=yes" in s
        assert "***" not in s
        # No password → result identical to the raw connection string.
        assert s == _build_connection_string(c)

    def test_rest_of_string_matches_raw(self) -> None:
        """All non-password parts match ``_build_connection_string`` output."""
        c = ConnectionConfig(
            backend="mssql",
            host=r"myserver\inst",
            port=0,
            database="d",
            username="u",
            password="secret",
            encrypt=False,
            trust_server_certificate=True,
        )
        sanitized = build_sanitized_connection_string(c)
        raw = _build_connection_string(c)
        # The only difference is the password: replacing it should round-trip.
        assert sanitized == raw.replace("secret", "***")


class TestLifecycle:
    """Lifecycle tests: connect, close, idempotency, context manager."""

    def test_connect_lazy_no_call_at_init(self, fake_pyodbc: Any) -> None:
        MSSQLBackend(_cfg())
        fake_pyodbc.connect.assert_not_called()

    def test_connect_idempotent(self, fake_pyodbc: Any) -> None:
        b = MSSQLBackend(_cfg())
        b.connect()
        b.connect()
        assert fake_pyodbc.connect.call_count == 1

    def test_close_idempotent(self, fake_pyodbc: Any) -> None:
        b = MSSQLBackend(_cfg())
        b.connect()
        b.close()
        b.close()

    def test_post_close_raises_runtimeerror(self, fake_pyodbc: Any) -> None:
        b = MSSQLBackend(_cfg())
        b.connect()
        b.close()
        with pytest.raises(RuntimeError, match="closed"):
            b.execute_query("SELECT 1")

    def test_context_manager_closes(self, fake_pyodbc: Any) -> None:
        with MSSQLBackend(_cfg()) as b:
            b.execute_query("SELECT 1")
        with pytest.raises(RuntimeError):
            b.execute_query("SELECT 1")

    def test_lazy_connect_on_first_call(self, fake_pyodbc: Any) -> None:
        b = MSSQLBackend(_cfg())
        b.execute_query("SELECT 1")
        fake_pyodbc.connect.assert_called_once()


class TestQueries:
    """Query method tests: parameter translation, rowcount, cursor management."""

    def test_execute_query_translates_named_params(self, fake_pyodbc: Any) -> None:
        conn = fake_pyodbc.connect.return_value
        cur = conn.cursor.return_value
        cur.description = [("col",)]
        cur.fetchall.return_value = [("v",)]
        b = MSSQLBackend(_cfg())
        rows = b.execute_query("SELECT col FROM t WHERE x = :x", {"x": 1})
        cur.execute.assert_called_once_with("SELECT col FROM t WHERE x = ?", [1])
        assert rows == [{"col": "v"}]

    def test_execute_update_returns_rowcount(self, fake_pyodbc: Any) -> None:
        cur = fake_pyodbc.connect.return_value.cursor.return_value
        cur.rowcount = 3
        b = MSSQLBackend(_cfg())
        assert b.execute_update("UPDATE t SET x=:x", {"x": 1}) == 3

    def test_execute_query_no_params_no_placeholders(self, fake_pyodbc: Any) -> None:
        conn = fake_pyodbc.connect.return_value
        cur = conn.cursor.return_value
        cur.description = [("one",)]
        cur.fetchall.return_value = [(1,)]
        b = MSSQLBackend(_cfg())
        rows = b.execute_query("SELECT 1")
        assert rows == [{"one": 1}]

    def test_execute_query_placeholders_but_none_params_raises(
        self, fake_pyodbc: Any
    ) -> None:
        b = MSSQLBackend(_cfg())
        with pytest.raises(KeyError, match="x"):
            b.execute_query("SELECT :x", None)

    def test_autocommit_passed_to_pyodbc(self, fake_pyodbc: Any) -> None:
        MSSQLBackend(_cfg()).connect()
        kwargs = fake_pyodbc.connect.call_args.kwargs
        assert kwargs.get("autocommit") is True

    def test_cursor_closed_after_call(self, fake_pyodbc: Any) -> None:
        cur = fake_pyodbc.connect.return_value.cursor.return_value
        b = MSSQLBackend(_cfg())
        b.execute_query("SELECT 1")
        cur.close.assert_called()

    def test_explain_wraps_with_showplan(self, fake_pyodbc: Any) -> None:
        cur = fake_pyodbc.connect.return_value.cursor.return_value
        cur.fetchall.return_value = [("plan-line",)]
        b = MSSQLBackend(_cfg())
        plan = b.explain("SELECT :a", {"a": 1})
        executed = [c.args[0] for c in cur.execute.call_args_list]
        assert executed[0] == "SET SHOWPLAN_TEXT ON"
        assert executed[1] == "SELECT 1"  # literal substituted, no ?
        # cursor.execute is called with no positional args beyond the SQL:
        assert cur.execute.call_args_list[1].args == ("SELECT 1",)
        assert executed[-1] == "SET SHOWPLAN_TEXT OFF"
        assert plan == "plan-line"

    def test_explain_resets_showplan_on_error(self, fake_pyodbc: Any) -> None:
        cur = fake_pyodbc.connect.return_value.cursor.return_value
        cur.execute.side_effect = [None, RuntimeError("boom"), None]
        b = MSSQLBackend(_cfg())
        with pytest.raises(RuntimeError):
            b.explain("SELECT 1")
        executed = [c.args[0] for c in cur.execute.call_args_list]
        assert executed[-1] == "SET SHOWPLAN_TEXT OFF"


class TestIsolatedConnection:
    """Tests for ``MSSQLBackend.get_isolated_connection``."""

    def test_yields_fresh_connection_and_closes(self, fake_pyodbc: Any) -> None:
        fresh_conn = MagicMock(name="fresh_connection")
        fake_pyodbc.connect.return_value = fresh_conn
        b = MSSQLBackend(_cfg())
        with b.get_isolated_connection() as conn:
            assert conn is fresh_conn
            fresh_conn.close.assert_not_called()
        fresh_conn.close.assert_called_once()

    def test_closes_on_exception(self, fake_pyodbc: Any) -> None:
        fresh_conn = MagicMock(name="fresh_connection")
        fake_pyodbc.connect.return_value = fresh_conn
        b = MSSQLBackend(_cfg())
        with pytest.raises(RuntimeError, match="boom"):
            with b.get_isolated_connection():
                raise RuntimeError("boom")
        fresh_conn.close.assert_called_once()

    def test_autocommit_passed_for_isolated_connection(self, fake_pyodbc: Any) -> None:
        b = MSSQLBackend(_cfg())
        with b.get_isolated_connection():
            pass
        kwargs = fake_pyodbc.connect.call_args.kwargs
        assert kwargs.get("autocommit") is True


class TestConcurrency:
    """Thread-safety tests for lazy-connect."""

    def test_concurrent_connect_calls_pyodbc_once(self, fake_pyodbc: Any) -> None:
        b = MSSQLBackend(_cfg())
        barrier = threading.Barrier(5)

        def worker() -> None:
            barrier.wait()
            b.connect()

        threads = [threading.Thread(target=worker) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert fake_pyodbc.connect.call_count == 1


class TestErrorSanitization:
    """Tests that the password is redacted in errors from pyodbc.connect."""

    def test_password_redacted_in_pyodbc_error(self, fake_pyodbc: Any) -> None:
        original = fake_pyodbc.OperationalError(
            "08001", "Login failed; PWD=supersecret"
        )
        fake_pyodbc.connect.side_effect = original
        b = MSSQLBackend(_cfg(password="supersecret"))
        with pytest.raises(fake_pyodbc.Error) as exc:
            b.connect()
        # Secret removed, marker present.
        assert "supersecret" not in str(exc.value)
        assert "***" in str(exc.value)
        # Same instance re-raised: preserves type and sqlstate tuple shape.
        assert exc.value is original
        assert isinstance(exc.value, fake_pyodbc.OperationalError)
        assert exc.value.args[0] == "08001"


class TestConnectDebugLogging:
    """Tests that MSSQLBackend.connect() emits diagnostic debug logs."""

    def test_connect_logs_redacted_conn_string(
        self, fake_pyodbc: Any, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Successful connect → debug log contains the redacted conn string."""
        del fake_pyodbc  # only needed for module patching side effect
        b = MSSQLBackend(_cfg(password="supersecret"))
        with caplog.at_level("DEBUG", logger="mcp_tools_sql.backends.mssql"):
            b.connect()
        attempt_lines = [
            r.getMessage()
            for r in caplog.records
            if "MSSQL connect attempt" in r.getMessage()
        ]
        assert attempt_lines, "no attempt debug line emitted"
        for line in attempt_lines:
            assert "supersecret" not in line
            assert "PWD=***" in line

    def test_connect_failure_logs_exception_details(
        self, fake_pyodbc: Any, caplog: pytest.LogCaptureFixture
    ) -> None:
        """pyodbc.connect raises → debug log records exception type + args."""
        fake_pyodbc.connect.side_effect = fake_pyodbc.OperationalError(
            "08001", "Login failed; PWD=supersecret"
        )
        b = MSSQLBackend(_cfg(password="supersecret"))
        with caplog.at_level("DEBUG", logger="mcp_tools_sql.backends.mssql"):
            with pytest.raises(fake_pyodbc.Error):
                b.connect()
        failure_lines = [
            r.getMessage()
            for r in caplog.records
            if "MSSQL connect failed" in r.getMessage()
        ]
        assert failure_lines, "no failure debug line emitted"
        for line in failure_lines:
            assert "OperationalError" in line
            assert "08001" in line
            assert "supersecret" not in line


@pytest.mark.mssql_integration
class TestMSSQLIntegration:
    """Round-trip tests against a real SQL Server.

    Skipped automatically when ``TEST_MSSQL_*`` env vars are missing
    (handled by the ``mssql_db`` fixture).
    """

    def test_execute_query_real_round_trip(self, mssql_db: MSSQLTestEnv) -> None:
        with MSSQLBackend(mssql_db.config) as b:
            rows = b.execute_query(
                f"SELECT name FROM {mssql_db.schema}.customers "
                "WHERE country = :country",
                {"country": "Germany"},
            )
        assert rows == [{"name": "Bank A"}]

    def test_execute_update_real_round_trip(self, mssql_db: MSSQLTestEnv) -> None:
        with MSSQLBackend(mssql_db.config) as b:
            n = b.execute_update(
                f"INSERT INTO {mssql_db.schema}.customers "
                "VALUES (:id, :name, :country)",
                {"id": 99, "name": "Bank Z", "country": "Spain"},
            )
        assert n == 1

    def test_explain_returns_text_plan(self, mssql_db: MSSQLTestEnv) -> None:
        with MSSQLBackend(mssql_db.config) as b:
            plan = b.explain(
                f"SELECT * FROM {mssql_db.schema}.customers WHERE id = :id",
                {"id": 1},
            )
        assert isinstance(plan, str)
        assert len(plan) > 0

    def test_connect_close_lifecycle(self, mssql_db: MSSQLTestEnv) -> None:
        b = MSSQLBackend(mssql_db.config)
        b.connect()
        b.connect()
        b.execute_query("SELECT 1 AS one")
        b.close()
        b.close()
        with pytest.raises(RuntimeError):
            b.execute_query("SELECT 1")

    def test_isolated_connection_round_trip(self, mssql_db: MSSQLTestEnv) -> None:
        with MSSQLBackend(mssql_db.config) as b:
            with b.get_isolated_connection() as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute("SELECT 1")
                    row = cursor.fetchone()
                finally:
                    cursor.close()
            assert tuple(row) == (1,)

    def test_isolated_connection_does_not_affect_persistent(
        self, mssql_db: MSSQLTestEnv
    ) -> None:
        with MSSQLBackend(mssql_db.config) as b:
            with b.get_isolated_connection():
                pass
            rows = b.execute_query("SELECT 1 AS x")
        assert rows == [{"x": 1}]
