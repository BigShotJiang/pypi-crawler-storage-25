import signal
import sys
import time
import argparse
import os
import logging
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Optional, Type, TypeVar
import shutil
import platform

from common import ServiceExit, Context, Constants, Config, Args, AppError
from common import ServiceRestart
from common import Localization, Status, ConfigError, Persist, PersistError
from common import EncryptionError
from common.encryption import is_ciphertext
from common.config import _SECRET_FIELD_PATHS
from controller import Controller, ControllerJob, ControllerPersist, AutoQueue, AutoQueuePersist
from controller.webhook_manager import WebhookManager
from web import WebAppJob, WebAppBuilder

T_Persist = TypeVar('T_Persist', bound=Persist)

class Seedsyncarr:
    """
    Implements the service for seedsyncarr
    It is run in the main thread (no daemonization)
    """
    __FILE_CONFIG = "settings.cfg"
    __FILE_AUTO_QUEUE_PERSIST = "autoqueue.persist"
    __FILE_CONTROLLER_PERSIST = "controller.persist"
    __FILE_SECRETS_KEY = "secrets.key"
    __CONFIG_DUMMY_VALUE = "<replace me>"

    # This logger is used to print any exceptions caught at top module
    logger = None

    def __init__(self):
        # Parse the args
        args = self._parse_args(sys.argv[1:])

        # Create/load config
        config = None
        self.config_path = os.path.join(args.config_dir, Seedsyncarr.__FILE_CONFIG)
        Config.set_keyfile_path(os.path.join(args.config_dir, Seedsyncarr.__FILE_SECRETS_KEY))
        create_default_config = False
        if os.path.isfile(self.config_path):
            try:
                config = Config.from_file(self.config_path)
            except (ConfigError, PersistError):
                Seedsyncarr.__backup_file(self.config_path)
                # set config to default
                create_default_config = True
        else:
            create_default_config = True

        if create_default_config:
            # Create default config
            config = Seedsyncarr._create_default_config()
            config.to_file(self.config_path)

        # Determine the true value of debug
        is_debug = args.debug or config.general.debug

        # Create context args
        ctx_args = Args()
        ctx_args.local_path_to_scanfs = args.scanfs
        ctx_args.html_path = args.html
        ctx_args.debug = is_debug
        ctx_args.exit = args.exit

        # Logger setup
        # We separate the main log from the web-access log
        logger = self._create_logger(name=Constants.SERVICE_NAME,
                                     debug=is_debug,
                                     logdir=args.logdir)
        Seedsyncarr.logger = logger
        web_access_logger = self._create_logger(name=Constants.WEB_ACCESS_LOG_NAME,
                                                debug=is_debug,
                                                logdir=args.logdir)
        logger.info("Debug mode is {}.".format("enabled" if is_debug else "disabled"))

        # Create status
        status = Status()

        # Create context
        self.context = Context(logger=logger,
                               web_access_logger=web_access_logger,
                               config=config,
                               args=ctx_args,
                               status=status)

        # Register the signal handlers
        signal.signal(signal.SIGTERM, self.signal)
        signal.signal(signal.SIGINT, self.signal)

        # Print context to log
        self.context.print_to_log()

        # Load the persists
        self.controller_persist_path = os.path.join(args.config_dir, Seedsyncarr.__FILE_CONTROLLER_PERSIST)
        self.controller_persist = self._load_controller_persist(
            self.controller_persist_path,
            config.controller.max_tracked_files
        )

        self.auto_queue_persist_path = os.path.join(args.config_dir, Seedsyncarr.__FILE_AUTO_QUEUE_PERSIST)
        self.auto_queue_persist = self._load_persist(AutoQueuePersist, self.auto_queue_persist_path)

    def run(self):
        self.context.logger.info("Starting SeedSyncarr")
        self.context.logger.info("Platform: {}".format(platform.machine()))

        # SEC-02 #3a: re-encrypt plaintext secrets in place when encryption is on
        Seedsyncarr._reencrypt_plaintext_if_needed(
            self.context.config, self.config_path, self.context.logger
        )

        # Startup security warnings (WHOOK-02, WARN-01, WARN-02, WARN-03)
        Seedsyncarr._emit_startup_warnings(self.context.logger, self.context.config)

        # SEC-02 #5b: emit per-field warnings for decrypt failures from from_str
        Seedsyncarr._emit_decrypt_warnings(self.context.logger, self.context.config)

        # Create webhook manager (shared between controller and web app)
        webhook_manager = WebhookManager(self.context)

        # Create controller
        controller = Controller(self.context, self.controller_persist, webhook_manager)

        # Create auto queue
        auto_queue = AutoQueue(self.context, self.auto_queue_persist, controller)

        # Create web app
        web_app_builder = WebAppBuilder(self.context, controller, self.auto_queue_persist, webhook_manager)
        web_app = web_app_builder.build()

        # Define child threads
        controller_job = ControllerJob(
            context=self.context.create_child_context(ControllerJob.__name__),
            controller=controller,
            auto_queue=auto_queue
        )
        webapp_job = WebAppJob(
            context=self.context.create_child_context(WebAppJob.__name__),
            web_app=web_app
        )

        do_start_controller = True

        # Initial checks to see if we should bother starting the controller
        if Seedsyncarr._detect_incomplete_config(self.context.config):
            if not self.context.args.exit:
                do_start_controller = False
                self.context.logger.error("Config is incomplete")
                self.context.status.server.up = False
                self.context.status.server.error_msg = Localization.Error.SETTINGS_INCOMPLETE
            else:
                raise AppError("Config is incomplete")

        # Start child threads here
        if do_start_controller:
            controller_job.start()
        webapp_job.start()

        try:
            prev_persist_timestamp = datetime.now()

            # Thread loop
            while True:
                # Persist to file occasionally
                now = datetime.now()
                if (now - prev_persist_timestamp).total_seconds() > Constants.MIN_PERSIST_TO_FILE_INTERVAL_IN_SECS:
                    prev_persist_timestamp = now
                    self.persist()

                # Propagate exceptions
                webapp_job.propagate_exception()
                # Catch controller exceptions and keep running, but notify the web server of the error
                try:
                    controller_job.propagate_exception()
                except AppError as exc:
                    if not self.context.args.exit:
                        self.context.status.server.up = False
                        self.context.status.server.error_msg = str(exc)
                        Seedsyncarr.logger.exception("Caught exception")
                    else:
                        raise

                # Check if a restart is requested
                if web_app_builder.server_handler.is_restart_requested():
                    raise ServiceRestart()

                # Nothing else to do
                time.sleep(Constants.MAIN_THREAD_SLEEP_INTERVAL_IN_SECS)

        except Exception:
            self.context.logger.info("Exiting Seedsyncarr")

            # This sleep is important to allow the jobs to finish setup before we terminate them
            # If we kill too early, the jobs may leave lingering threads around
            # Note: There might be a better way to ensure that job setup has completed, but this
            #       will do for now
            time.sleep(Constants.MAIN_THREAD_SLEEP_INTERVAL_IN_SECS)

            # Join all the threads here
            if do_start_controller:
                controller_job.terminate()
            webapp_job.terminate()

            # Wait for the threads to close
            if do_start_controller:
                controller_job.join()
            webapp_job.join()

            # Last persist
            self.persist()

            # Raise any exceptions so they can be logged properly
            # Note: ServiceRestart and ServiceExit will be caught and handled
            #       by outer code
            raise

    def persist(self):
        # Save the persists
        self.context.logger.debug("Persisting states to file")
        self.controller_persist.to_file(self.controller_persist_path)
        self.auto_queue_persist.to_file(self.auto_queue_persist_path)
        self.context.config.to_file(self.config_path)

    def signal(self, signum: int, _):
        # Signals is a generated enum
        self.context.logger.info("Caught signal {}".format(signal.Signals(signum).name))
        raise ServiceExit()

    @staticmethod
    def _parse_args(args):
        parser = argparse.ArgumentParser(description="Seedsyncarr daemon")
        parser.add_argument("-c", "--config_dir", required=True, help="Path to config directory")
        parser.add_argument("--logdir", help="Directory for log files")
        parser.add_argument("-d", "--debug", action="store_true", help="Enable debug logs")
        parser.add_argument("--exit", action="store_true", help="Exit on error")

        # Whether package is frozen
        is_frozen = getattr(sys, 'frozen', False)

        # Html path is only required if not running a frozen package
        # For a frozen package, set default to root/html
        default_html_path = os.path.join(sys._MEIPASS, "html") if is_frozen else None
        parser.add_argument("--html",
                            required=not is_frozen,
                            default=default_html_path,
                            help="Path to directory containing html resources")

        # Scanfs path is only required if not running a frozen package
        # For a frozen package, set default to root/scanfs
        default_scanfs_path = os.path.join(sys._MEIPASS, "scanfs") if is_frozen else None
        parser.add_argument("--scanfs",
                            required=not is_frozen,
                            default=default_scanfs_path,
                            help="Path to scanfs executable")

        args = parser.parse_args(args)

        if not os.path.exists(args.config_dir):
            legacy_dir = os.path.expanduser("~/.seedsync")
            if os.path.exists(legacy_dir):
                logging.warning(
                    "Config directory %s not found; falling back to legacy %s",
                    args.config_dir, legacy_dir
                )
                args.config_dir = legacy_dir

        return args

    @staticmethod
    def _create_logger(name: str, debug: bool, logdir: Optional[str]) -> logging.Logger:
        logger = logging.getLogger(name)

        # Remove any existing handlers (needed when restarting)
        handlers = logger.handlers[:]
        for handler in handlers:
            handler.close()
            logger.removeHandler(handler)

        logger.setLevel(logging.DEBUG if debug else logging.INFO)
        if logdir is not None:
            # Output logs to a file in the given directory
            handler = RotatingFileHandler(
                        "{}/{}.log".format(logdir, name),
                        maxBytes=Constants.MAX_LOG_SIZE_IN_BYTES,
                        backupCount=Constants.LOG_BACKUP_COUNT
                      )
        else:
            handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(name)s (%(processName)s/%(threadName)s) - %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    @staticmethod
    def _create_default_config() -> Config:
        """
        Create a config with default values
        """
        config = Config()

        config.general.debug = False
        config.general.verbose = False
        config.general.webhook_secret = ""
        config.general.api_token = ""
        config.general.allowed_hostname = ""

        config.lftp.remote_address = Seedsyncarr.__CONFIG_DUMMY_VALUE
        config.lftp.remote_username = Seedsyncarr.__CONFIG_DUMMY_VALUE
        config.lftp.remote_password = Seedsyncarr.__CONFIG_DUMMY_VALUE
        config.lftp.remote_port = 22
        config.lftp.remote_path = Seedsyncarr.__CONFIG_DUMMY_VALUE
        config.lftp.local_path = Seedsyncarr.__CONFIG_DUMMY_VALUE
        config.lftp.remote_path_to_scan_script = "/tmp"
        config.lftp.use_ssh_key = False
        config.lftp.num_max_parallel_downloads = 2
        config.lftp.num_max_parallel_files_per_download = 4
        config.lftp.num_max_connections_per_root_file = 4
        config.lftp.num_max_connections_per_dir_file = 4
        config.lftp.num_max_total_connections = 16
        config.lftp.use_temp_file = False
        config.lftp.rate_limit = 0

        config.controller.interval_ms_remote_scan = 30000
        config.controller.interval_ms_local_scan = 10000
        config.controller.interval_ms_downloading_scan = 1000
        config.controller.extract_path = "/tmp"
        config.controller.use_local_path_as_extract_path = True
        config.controller.max_tracked_files = 10000

        config.web.port = 8800

        config.autoqueue.enabled = True
        config.autoqueue.patterns_only = False
        config.autoqueue.auto_extract = True

        config.sonarr.enabled = False
        config.sonarr.sonarr_url = ""
        config.sonarr.sonarr_api_key = ""

        config.radarr.enabled = False
        config.radarr.radarr_url = ""
        config.radarr.radarr_api_key = ""

        config.autodelete.enabled = False
        config.autodelete.dry_run = False
        config.autodelete.delay_seconds = 60

        config.encryption.enabled = False

        return config

    @staticmethod
    def _detect_incomplete_config(config: Config) -> bool:
        config_dict = config.as_dict()
        for sec_name in config_dict:
            for key in config_dict[sec_name]:
                if Seedsyncarr.__CONFIG_DUMMY_VALUE == config_dict[sec_name][key]:
                    return True
        return False

    @staticmethod
    def _emit_startup_warnings(logger: logging.Logger, config: Config) -> None:
        """Emit security warnings for insecure configuration states."""
        if not config.general.webhook_secret:
            logger.warning(
                "Security: webhook_secret is not configured. "
                "Webhook endpoints will accept requests from any caller."
            )
        if not config.general.api_token:
            logger.warning(
                "Security: No API token configured. "
                "All API requests will be accepted without authentication."
            )
            logger.warning(
                "Security: Application is bound to 0.0.0.0 without an API token. "
                "Any host on the network can access the API."
            )
        else:
            logger.info(
                "Security: API token configured — "
                "all /server/* endpoints require Bearer authentication."
            )

    @staticmethod
    def _reencrypt_plaintext_if_needed(config: Config, config_path: str, logger: logging.Logger) -> None:
        """Re-encrypt any plaintext secret fields in place when encryption is enabled.

        Runs once per startup (SEC-02 criterion #3a). If encryption.enabled is True
        and any of the 5 secret fields are still in plaintext, writes the config back
        to disk via to_file() so the on-disk settings.cfg gets ciphertext values.

        Never raises — logs at INFO level when re-encryption fires.
        """
        if not config.encryption.enabled:
            return
        has_plaintext = False
        for attr, field, _ in _SECRET_FIELD_PATHS:
            value = getattr(getattr(config, attr), field, None)
            if value and not is_ciphertext(value):
                has_plaintext = True
                break
        if has_plaintext:
            logger.info(
                "Encryption: re-encrypting plaintext secrets in settings.cfg"
            )
            try:
                config.to_file(config_path)
            except (OSError, EncryptionError, ConfigError) as exc:
                logger.warning("Encryption: failed to write re-encrypted config: %s", exc)

    @staticmethod
    def _emit_decrypt_warnings(logger: logging.Logger, config: Config) -> None:
        """Emit warnings for decrypt failures detected during Config.from_str.

        Never raises — advisory only (SEC-02 #5b). Mirrors the contract of
        _emit_startup_warnings: log-only, no exceptions propagated.
        """
        for field_path in getattr(config, "_decrypt_errors", []):
            logger.warning(
                "Security: Failed to decrypt '%s' in settings.cfg. "
                "The value looks like ciphertext but could not be decrypted with "
                "the current keyfile. Check that secrets.key matches the keyfile "
                "used to originally encrypt this value.",
                field_path,
            )

    @staticmethod
    def _load_persist(cls: Type[T_Persist], file_path: str) -> T_Persist:
        """
        Loads a persist from file.
        Backs up existing persist if it's corrupted. Returns a new blank
        persist in its place.
        """
        if os.path.isfile(file_path):
            try:
                return cls.from_file(file_path)
            except PersistError:
                if Seedsyncarr.logger:
                    Seedsyncarr.logger.exception("Caught exception")

                # backup file
                Seedsyncarr.__backup_file(file_path)

                return cls()
        else:
            return cls()

    @staticmethod
    def _load_controller_persist(file_path: str, max_tracked_files: int) -> ControllerPersist:
        """
        Loads ControllerPersist from file with a configured limit.
        Backs up existing persist if it's corrupted. Returns a new blank
        persist in its place.

        :param file_path: Path to the persist file
        :param max_tracked_files: Maximum files to track in bounded collections
        :return: ControllerPersist instance
        """
        if os.path.isfile(file_path):
            try:
                return ControllerPersist.from_file_with_limit(file_path, max_tracked_files)
            except PersistError:
                if Seedsyncarr.logger:
                    Seedsyncarr.logger.exception("Caught exception")

                # backup file
                Seedsyncarr.__backup_file(file_path)

                return ControllerPersist(max_tracked_files=max_tracked_files)
        else:
            return ControllerPersist(max_tracked_files=max_tracked_files)

    @staticmethod
    def __backup_file(file_path: str):
        file_name = os.path.basename(file_path)
        file_dir = os.path.dirname(file_path)
        i = 1
        while True:
            backup_path = os.path.join(
                file_dir, "{}.{}.bak".format(file_name, i)
            )
            if not os.path.exists(backup_path):
                break
            i += 1
        if Seedsyncarr.logger:
            Seedsyncarr.logger.info("Backing up {} to {}".format(file_path, backup_path))
        shutil.copy(file_path, backup_path)

def main():
    """Entry point for pip-installed seedsyncarr command."""
    if sys.hexversion < 0x03050000:
        sys.exit("Python 3.5 or newer is required to run this program.")
    while True:
        try:
            app = Seedsyncarr()
            app.run()
        except ServiceExit:
            break
        except ServiceRestart:
            Seedsyncarr.logger.info("Restarting...")
            continue
        except Exception:
            Seedsyncarr.logger.exception("Caught exception")
            raise
    Seedsyncarr.logger.info("Exited successfully")

if __name__ == "__main__":
    main()
