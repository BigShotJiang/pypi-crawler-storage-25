import logging
import threading
from abc import ABC, abstractmethod
from typing import Set

from common import AppError
from .file import ModelFile

class ModelError(AppError):
    """
    Exception indicating a model error
    """
    pass

class IModelListener(ABC):
    """
    Interface to listen to model events
    """
    @abstractmethod
    def file_added(self, file: ModelFile):
        """
        Event indicating a file was added to the model
        """
        pass

    @abstractmethod
    def file_removed(self, file: ModelFile):
        """
        Event indicating that the given file was removed from the model
        """
        pass

    @abstractmethod
    def file_updated(self, old_file: ModelFile, new_file: ModelFile):
        """
        Event indicating that the given file was updated
        """
        pass

class Model:
    """
    Represents the entire state of lftp

    Thread-safety: Listener operations are protected by __listeners_lock.
    The copy-under-lock pattern is used when notifying listeners to prevent
    race conditions with concurrent add/remove operations.
    """
    def __init__(self):
        self.logger = logging.getLogger("Model")
        self.__files = {}  # name->LftpFile
        self.__listeners = []
        self.__listeners_lock = threading.Lock()

    def set_base_logger(self, base_logger: logging.Logger):
        self.logger = base_logger.getChild("Model")

    def add_listener(self, listener: IModelListener):
        """
        Add a model listener
        """
        self.logger.debug("LftpModel: Adding a listener")
        with self.__listeners_lock:
            if listener not in self.__listeners:
                self.__listeners.append(listener)

    def remove_listener(self, listener: IModelListener):
        """
        Remove a model listener
        """
        self.logger.debug("LftpModel: Removing a listener")
        with self.__listeners_lock:
            if listener not in self.__listeners:
                self.logger.error("LftpModel: listener does not exist!")
            else:
                self.__listeners.remove(listener)

    def add_file(self, file: ModelFile):
        """
        Add a file to the model
        """
        self.logger.debug("LftpModel: Adding file '{}'".format(file.name))
        if file.name in self.__files:
            raise ModelError("File already exists in the model")
        # Freeze the file to make it immutable before storing
        file.freeze()
        self.__files[file.name] = file
        # Copy-under-lock: copy listeners while holding lock, then iterate outside lock
        with self.__listeners_lock:
            listeners = list(self.__listeners)
        for listener in listeners:
            listener.file_added(self.__files[file.name])

    def remove_file(self, filename: str):
        """
        Remove the file from the model
        """
        self.logger.debug("LftpModel: Removing file '{}'".format(filename))
        if filename not in self.__files:
            raise ModelError("File does not exist in the model")
        file = self.__files[filename]
        del self.__files[filename]
        # Copy-under-lock: copy listeners while holding lock, then iterate outside lock
        with self.__listeners_lock:
            listeners = list(self.__listeners)
        for listener in listeners:
            listener.file_removed(file)

    def update_file(self, file: ModelFile):
        """
        Update an already existing file
        """
        self.logger.debug("LftpModel: Updating file '{}'".format(file.name))
        if file.name not in self.__files:
            raise ModelError("File does not exist in the model")
        old_file = self.__files[file.name]
        new_file = file
        # Freeze the new file to make it immutable before storing
        new_file.freeze()
        self.__files[file.name] = new_file
        # Copy-under-lock: copy listeners while holding lock, then iterate outside lock
        with self.__listeners_lock:
            listeners = list(self.__listeners)
        for listener in listeners:
            listener.file_updated(old_file, new_file)

    def get_file(self, name: str) -> ModelFile:
        """
        Returns the file of the given name.
        The returned file is frozen (immutable) and safe to use across threads.
        """
        if name not in self.__files:
            raise ModelError("File does not exist in the model")
        return self.__files[name]

    def get_file_names(self) -> Set[str]:
        return set(self.__files.keys())
