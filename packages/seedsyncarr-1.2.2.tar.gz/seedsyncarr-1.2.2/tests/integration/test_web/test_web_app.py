import unittest
from unittest.mock import MagicMock
import logging
import sys

from webtest import TestApp

from common import overrides, Status, Config
from controller import AutoQueuePersist
from web import WebAppBuilder


class BaseTestWebApp(unittest.TestCase):
    """
    Base class for testing web app
    Sets up the web app with mocks
    """
    @overrides(unittest.TestCase)
    def setUp(self):
        self.context = MagicMock()
        self.controller = MagicMock()

        # Mock the base logger
        logger = logging.getLogger()
        self._test_handler = logging.StreamHandler(sys.stdout)
        logger.addHandler(self._test_handler)
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(message)s")
        self._test_handler.setFormatter(formatter)
        self.context.logger = logger

        # Model files
        self.model_files = []

        # Real status
        self.context.status = Status()

        # Real config
        self.context.config = Config()

        # Real auto-queue persist
        self.auto_queue_persist = AutoQueuePersist()

        # Capture the model listener
        def capture_listener(listener):
            self.model_listener = listener
            return self.model_files
        self.model_listener = None
        self.controller.get_model_files_and_add_listener = MagicMock()
        self.controller.get_model_files_and_add_listener.side_effect = capture_listener
        self.controller.remove_model_listener = MagicMock()

        self.web_app_builder = WebAppBuilder(self.context,
                                             self.controller,
                                             self.auto_queue_persist,
                                             MagicMock())
        self.web_app = self.web_app_builder.build()
        self.test_app = TestApp(self.web_app)

    @overrides(unittest.TestCase)
    def tearDown(self):
        logging.getLogger().removeHandler(self._test_handler)


class TestWebApp(BaseTestWebApp):
    def test_process(self):
        self.web_app.process()
