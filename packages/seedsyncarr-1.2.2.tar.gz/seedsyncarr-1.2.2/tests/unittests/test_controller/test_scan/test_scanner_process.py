import time
import unittest
import multiprocessing
import logging
import sys
import tempfile
from unittest.mock import MagicMock

import pytest

from controller import IScanner, ScannerProcess, ScannerError
from controller.scan import ActiveScanner
from system import SystemFile


class DummyScanner(IScanner):
    def scan(self):
        return [], None, None

    def set_base_logger(self, base_logger: logging.Logger):
        pass


class TestScannerProcess(unittest.TestCase):
    def setUp(self):
        logger = logging.getLogger()
        self._test_handler = logging.StreamHandler(sys.stdout)
        logger.addHandler(self._test_handler)
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(message)s")
        self._test_handler.setFormatter(formatter)

        # Assign process to this variable so that it can be cleaned up
        # even after an error
        self.process = None

    def tearDown(self):
        logging.getLogger().removeHandler(self._test_handler)
        if self.process:
            self.process.terminate()

    @pytest.mark.timeout(10)
    def test_retrieves_scan_results(self):
        # Use this as a signal to mock to control which result to send
        self.scan_signal = multiprocessing.Value('i', 0)
        self.scan_counter = multiprocessing.Value('i', 0)

        a = SystemFile("a", 100, True)
        aa = SystemFile("aa", 60, False)
        a.add_child(aa)
        ab = SystemFile("ab", 40, False)
        a.add_child(ab)

        b = SystemFile("b", 10, True)
        ba = SystemFile("ba", 10, True)
        b.add_child(ba)
        baa = SystemFile("baa", 10, False)
        ba.add_child(baa)

        c = SystemFile("c", 1234, False)

        mock_scanner = DummyScanner()
        mock_scanner.scan = MagicMock()

        def _scan():
            files = None
            if self.scan_signal.value == 0:
                files = [a]
            elif self.scan_signal.value == 1:
                files = [a, b]
            elif self.scan_signal.value == 2:
                files = [c]
            elif self.scan_signal.value == 3:
                files = []
            self.scan_counter.value += 1
            return files, None, None
        mock_scanner.scan.side_effect = _scan

        self.process = ScannerProcess(scanner=mock_scanner,
                                      interval_in_ms=100)
        self.process.start()

        # wait for first call to scan (actually second call to guarantee first scan is queued)
        while self.scan_counter.value < 2:
            time.sleep(0.01)
        result = self.process.pop_latest_result()
        self.assertEqual(1, len(result.files))
        self.assertEqual("a", result.files[0].name)
        self.assertEqual(True, result.files[0].is_dir)
        self.assertEqual(100, result.files[0].size)
        self.assertEqual(2, len(result.files[0].children))
        self.assertEqual("aa", result.files[0].children[0].name)
        self.assertEqual(False, result.files[0].children[0].is_dir)
        self.assertEqual(60, result.files[0].children[0].size)
        self.assertEqual("ab", result.files[0].children[1].name)
        self.assertEqual(False, result.files[0].children[1].is_dir)
        self.assertEqual(40, result.files[0].children[1].size)

        # signal for scan #1 and wait scan fetch
        self.scan_signal.value = 1
        orig_counter = self.scan_counter.value
        while self.scan_counter.value < orig_counter+2:
            time.sleep(0.01)
        result = self.process.pop_latest_result()
        self.assertEqual(2, len(result.files))
        self.assertEqual("a", result.files[0].name)
        self.assertEqual(True, result.files[0].is_dir)
        self.assertEqual(100, result.files[0].size)
        self.assertEqual(2, len(result.files[0].children))
        self.assertEqual("aa", result.files[0].children[0].name)
        self.assertEqual(False, result.files[0].children[0].is_dir)
        self.assertEqual(60, result.files[0].children[0].size)
        self.assertEqual("ab", result.files[0].children[1].name)
        self.assertEqual(False, result.files[0].children[1].is_dir)
        self.assertEqual(40, result.files[0].children[1].size)
        self.assertEqual("b", result.files[1].name)
        self.assertEqual(True, result.files[1].is_dir)
        self.assertEqual(10, result.files[1].size)
        self.assertEqual(1, len(result.files[1].children))
        self.assertEqual("ba", result.files[1].children[0].name)
        self.assertEqual(True, result.files[1].children[0].is_dir)
        self.assertEqual(10, result.files[1].children[0].size)
        self.assertEqual(1, len(result.files[1].children[0].children))
        self.assertEqual("baa", result.files[1].children[0].children[0].name)
        self.assertEqual(False, result.files[1].children[0].children[0].is_dir)
        self.assertEqual(10, result.files[1].children[0].children[0].size)

        # signal for scan #2 and wait scan fetch
        self.scan_signal.value = 2
        orig_counter = self.scan_counter.value
        while self.scan_counter.value < orig_counter+2:
            time.sleep(0.01)
        result = self.process.pop_latest_result()
        self.assertEqual(1, len(result.files))
        self.assertEqual("c", result.files[0].name)
        self.assertEqual(False, result.files[0].is_dir)
        self.assertEqual(1234, result.files[0].size)

        # signal for scan #3 and wait scan fetch
        self.scan_signal.value = 3
        orig_counter = self.scan_counter.value
        while self.scan_counter.value < orig_counter+2:
            time.sleep(0.01)
        result = self.process.pop_latest_result()
        self.assertEqual(0, len(result.files))

    @pytest.mark.timeout(10)
    def test_sends_error_result_on_recoverable_error(self):
        mock_scanner = DummyScanner()
        mock_scanner.scan = MagicMock()
        mock_scanner.scan.side_effect = ScannerError("recoverable error", recoverable=True)

        self.process = ScannerProcess(scanner=mock_scanner,
                                      interval_in_ms=100)
        self.process.start()

        while True:
            result = self.process.pop_latest_result()
            if result:
                break
            time.sleep(0.01)
        self.assertEqual(0, len(result.files))
        self.assertTrue(result.failed)
        self.assertEqual("recoverable error", result.error_message)

    @pytest.mark.timeout(10)
    def test_sends_fatal_exception_on_nonrecoverable_error(self):
        mock_scanner = DummyScanner()
        mock_scanner.scan = MagicMock()
        mock_scanner.scan.side_effect = ScannerError("non-recoverable error", recoverable=False)

        self.process = ScannerProcess(scanner=mock_scanner,
                                      interval_in_ms=100)
        self.process.start()
        with self.assertRaises(ScannerError) as ctx:
            while True:
                self.process.propagate_exception()
                time.sleep(0.01)
        self.assertEqual("non-recoverable error", str(ctx.exception))


class TestIScannerContract(unittest.TestCase):
    """
    Phase 74-02 widened IScanner.scan() to return (files, total_bytes, used_bytes).
    Regression guard: every IScanner implementation must return a 3-tuple so that
    ScannerProcess.run_loop unpacking does not raise ValueError.
    """

    def test_active_scanner_returns_three_tuple(self):
        scanner = ActiveScanner(tempfile.gettempdir())
        result = scanner.scan()
        self.assertIsInstance(result, tuple)
        self.assertEqual(3, len(result))
        files, total, used = result
        self.assertIsInstance(files, list)
        self.assertIsNone(total)
        self.assertIsNone(used)
