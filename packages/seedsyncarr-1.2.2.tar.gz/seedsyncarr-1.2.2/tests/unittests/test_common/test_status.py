import unittest
from unittest.mock import MagicMock
from datetime import datetime

from common import overrides, Status, IStatusListener, StatusComponent, IStatusComponentListener


class DummyStatusComponent(StatusComponent):
    a = StatusComponent._create_property("a")
    b = StatusComponent._create_property("b")

    def __init__(self):
        super().__init__()
        self.a = None
        self.b = None


class DummyStatusComponentListener(IStatusComponentListener):
    @overrides(IStatusComponentListener)
    def notify(self, name):
        pass


class DummyStatusListener(IStatusListener):
    @overrides(IStatusListener)
    def notify(self):
        pass


class TestStatusComponent(unittest.TestCase):
    def test_property_values(self):
        d = DummyStatusComponent()
        d.a = "hello"
        d.b = 33
        self.assertEqual("hello", d.a)
        self.assertEqual(33, d.b)

    def test_listeners(self):
        listener = DummyStatusComponentListener()
        listener.notify = MagicMock()
        d = DummyStatusComponent()
        d.add_listener(listener)
        d.a = "hello world"
        listener.notify.assert_called_once_with("a")
        listener.notify.reset_mock()
        d.b = 44
        listener.notify.assert_called_once_with("b")

        # remove listener
        listener.notify.reset_mock()
        d.remove_listener(listener)
        d.a = "bye world"
        listener.notify.assert_not_called()
        d.b = 22
        listener.notify.assert_not_called()

    def test_copy_values(self):
        d = DummyStatusComponent()
        d.a = "hello world"
        d.b = 55

        e = DummyStatusComponent()
        DummyStatusComponent.copy(d, e)
        self.assertEqual("hello world", e.a)
        self.assertEqual(55, e.b)

        # Modifying original doesn't touch copy
        d.a = "bye world"
        d.b = 66
        self.assertEqual("bye world", d.a)
        self.assertEqual(66, d.b)
        self.assertEqual("hello world", e.a)
        self.assertEqual(55, e.b)

        # Modifying copy doesn't touch original
        e.a = "copied world"
        e.b = 77
        self.assertEqual("bye world", d.a)
        self.assertEqual(66, d.b)
        self.assertEqual("copied world", e.a)
        self.assertEqual(77, e.b)

    def test_copy_doesnt_copy_listeners(self):
        d = DummyStatusComponent()
        d.a = "hello world"
        d.b = 55
        listener = DummyStatusComponentListener()
        listener.notify = MagicMock()
        d.add_listener(listener)

        e = DummyStatusComponent()
        DummyStatusComponent.copy(d, e)

        d.a = "bye world"
        listener.notify.assert_called_once_with("a")
        listener.notify.reset_mock()

        e.a = "copied world"
        listener.notify.assert_not_called()


class TestStatus(unittest.TestCase):
    def test_property_values(self):
        status = Status()
        status.server.up = True
        status.server.error_msg = "Everything's good"
        self.assertEqual(True, status.server.up)
        self.assertEqual("Everything's good", status.server.error_msg)

    def test_listeners(self):
        listener = DummyStatusListener()
        listener.notify = MagicMock()
        status = Status()
        status.add_listener(listener)
        status.server.up = False
        listener.notify.assert_called_once_with()
        listener.notify.reset_mock()
        status.server.error_msg = "Everything's good"
        listener.notify.assert_called_once_with()

    def test_cannot_replace_component(self):
        status = Status()
        new_server = Status.ServerStatus()
        with self.assertRaises(ValueError) as e:
            status.server = new_server
        self.assertEqual("Cannot reassign component", str(e.exception))

    def test_default_values(self):
        status = Status()
        self.assertEqual(True, status.server.up)
        self.assertEqual(None, status.server.error_msg)
        self.assertEqual(None, status.controller.latest_local_scan_time)
        self.assertEqual(None, status.controller.latest_remote_scan_time)

    def test_components_registered(self):
        # Test that all components were registered
        # This is done through the copy method
        status = Status()

        status.server.up = False
        status.server.error_msg = "an error message"
        copy = status.copy()
        self.assertEqual(False, copy.server.up)
        self.assertEqual("an error message", copy.server.error_msg)

        time1 = datetime.now()
        time2 = datetime.now()
        status.controller.latest_local_scan_time = time1
        status.controller.latest_remote_scan_time = time2
        copy = status.copy()
        self.assertEqual(time1, copy.controller.latest_local_scan_time)
        self.assertEqual(time2, copy.controller.latest_remote_scan_time)

    def test_copy_values(self):
        status = Status()
        status.server.up = False
        status.server.error_msg = "Bad error"

        copy = status.copy()
        self.assertEqual(False, copy.server.up)
        self.assertEqual("Bad error", copy.server.error_msg)

        # Modifying original doesn't touch copy
        status.server.up = True
        status.server.error_msg = "No error"
        self.assertEqual(True, status.server.up)
        self.assertEqual("No error", status.server.error_msg)
        self.assertEqual(False, copy.server.up)
        self.assertEqual("Bad error", copy.server.error_msg)

        # Modifying copy doesn't touch original
        copy.server.up = False
        copy.server.error_msg = "Worse error"
        self.assertEqual(True, status.server.up)
        self.assertEqual("No error", status.server.error_msg)
        self.assertEqual(False, copy.server.up)
        self.assertEqual("Worse error", copy.server.error_msg)

    def test_copy_doesnt_copy_listeners(self):
        status = Status()
        listener = DummyStatusListener()
        listener.notify = MagicMock()
        status.add_listener(listener)
        copy = status.copy()

        status.server.error_msg = "a"
        listener.notify.assert_called_once_with()
        listener.notify.reset_mock()

        copy.server.error_msg = "b"
        listener.notify.assert_not_called()

    def test_storage_default_values(self):
        status = Status()
        self.assertIsNone(status.storage.local_total)
        self.assertIsNone(status.storage.local_used)
        self.assertIsNone(status.storage.remote_total)
        self.assertIsNone(status.storage.remote_used)

    def test_storage_property_values(self):
        status = Status()
        status.storage.local_total = 500_000_000_000
        status.storage.local_used = 123_000_000_000
        status.storage.remote_total = 2_000_000_000_000
        status.storage.remote_used = 1_300_000_000_000
        self.assertEqual(500_000_000_000, status.storage.local_total)
        self.assertEqual(123_000_000_000, status.storage.local_used)
        self.assertEqual(2_000_000_000_000, status.storage.remote_total)
        self.assertEqual(1_300_000_000_000, status.storage.remote_used)

    def test_storage_listeners(self):
        listener = DummyStatusListener()
        listener.notify = MagicMock()
        status = Status()
        status.add_listener(listener)
        status.storage.local_total = 1
        listener.notify.assert_called_once_with()
        listener.notify.reset_mock()
        status.storage.remote_used = 2
        listener.notify.assert_called_once_with()

    def test_storage_cannot_replace_component(self):
        status = Status()
        new_storage = Status.StorageStatus()
        with self.assertRaises(ValueError) as e:
            status.storage = new_storage
        self.assertEqual("Cannot reassign component", str(e.exception))

    def test_storage_copy_preserves_values(self):
        status = Status()
        status.storage.local_total = 500
        status.storage.local_used = 100
        status.storage.remote_total = 2000
        status.storage.remote_used = 1300
        copy = status.copy()
        self.assertEqual(500, copy.storage.local_total)
        self.assertEqual(100, copy.storage.local_used)
        self.assertEqual(2000, copy.storage.remote_total)
        self.assertEqual(1300, copy.storage.remote_used)
