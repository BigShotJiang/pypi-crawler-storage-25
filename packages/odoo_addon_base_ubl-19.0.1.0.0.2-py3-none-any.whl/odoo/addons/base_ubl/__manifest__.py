# © 2016-2017 Akretion (Alexis de Lattre <alexis.delattre@akretion.com>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "Base UBL",
    "version": "19.0.1.0.0",
    "category": "Hidden",
    "license": "AGPL-3",
    "summary": "Base module for Universal Business Language (UBL)",
    "author": "Akretion,Onestein,Camptocamp,Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/edi",
    "depends": ["base"],
    "installable": True,
}
