# All-Day Build Contract: agentkit-cli v1.20.0 land release completion

Status: In Progress
Date: 2026-04-21
Owner: OpenClaw build-loop release finisher
Scope type: Deliverable-gated (no hour promises)

## 1. Objective

Take the already local release-ready `agentkit-cli v1.20.0 land lanes` branch through the full four-surface release checklist and leave all shared state truthful. The concrete outcome is: release commit validated, branch and tag pushed, PyPI `agentkit-cli==1.20.0` live, and repo chronology/report surfaces reconciled so later docs-only commits do not blur the shipped truth.

This contract is considered complete only when every deliverable and validation gate below is satisfied.

## 2. Non-Negotiable Build Rules

1. No time-based completion claims.
2. Completion is allowed only when all checklist items are checked.
3. Re-run validation from the release candidate state before shipping.
4. Never summarize contradictory repo prose without verifying source-of-truth surfaces first.
5. Do not modify files outside `/Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes`.
6. Commit only truthful release or chronology updates. No cosmetic drive-bys.
7. If stuck on the same blocker for 3 attempts, stop and write a blocker report.
8. Do not change product scope. This is release completion only.
9. Before any release claim, verify tests, origin refs, tag, and registry truth directly.
10. No silent cleanup of intentional contract artifacts. Leave them or note them explicitly.

## 3. Deliverables

### D1. Pre-release truth and validation refresh

Reconfirm that the repo is still truthfully local release-ready and repair any last-mile contradictions before irreversible release actions.

Required:
- `BUILD-REPORT.md`
- `FINAL-SUMMARY.md`
- `progress-log.md`
- any blocker report only if needed

- [ ] Run workspace recall and contradiction hygiene checks if available from the workspace.
- [ ] Re-run the focused land continuation slice and at least one release-confidence validation pass from the candidate tree.
- [ ] Confirm repo status is clean except intentional contract artifacts.
- [ ] Repair any stale or contradictory release prose before shipping.

### D2. Four-surface release completion

Ship `v1.20.0` from this branch with one coherent release commit and direct source-of-truth verification.

Required:
- git branch/tag state
- PyPI release artifacts
- release evidence recorded in repo reports

- [ ] Push the branch to origin.
- [ ] Create and push annotated tag `v1.20.0` pointing at the tested release commit.
- [ ] Build wheel and sdist for `1.20.0`.
- [ ] Publish to PyPI.
- [ ] Verify the branch ref, tag ref, and PyPI live state directly.

### D3. Post-release chronology reconciliation

After the irreversible release actions succeed, reconcile repo state so future sessions inherit one truthful chronology.

Required:
- `BUILD-REPORT.md`
- `BUILD-REPORT-v1.20.0.md`
- `FINAL-SUMMARY.md`
- `progress-log.md`

- [ ] Update report surfaces to distinguish shipped release commit from any later docs-only chronology head.
- [ ] Record final validation commands and source-of-truth release evidence.
- [ ] Leave the branch clean except intentional contract artifacts.
- [ ] Write a final summary that says either SHIPPED with proof or BLOCKED with exact blocker.

## 4. Test Requirements

- [ ] Focused land/closeout/relaunch/resume/reconcile workflow slice passes.
- [ ] Release-confidence validation pass succeeds.
- [ ] If repo prose changed materially, ensure the final full suite or previously validated full-suite truth is still represented accurately and not contradicted.
- [ ] All release claims are backed by direct checks of branch ref, tag ref, and PyPI live state.

## 5. Reports

- Append progress to `progress-log.md` after each deliverable.
- Before trusting release/status prose, use `/Users/mordecai/.openclaw/workspace/scripts/pre-action-recall.sh release agentkit-cli /Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes` if present.
- Run `/Users/mordecai/.openclaw/workspace/scripts/check-status-conflicts.sh /Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes` if present.
- Run `/Users/mordecai/.openclaw/workspace/scripts/post-agent-hygiene-check.sh /Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes` before final summary if present.
- If a workspace script is missing or fails for environmental reasons, note that explicitly and keep going with equivalent direct verification.

## 6. Stop Conditions

- All deliverables checked and all release surfaces verified -> DONE.
- 3 consecutive failed attempts on same blocker -> STOP and write blocker report.
- Any mismatch between tests, git refs, and registry truth that cannot be reconciled safely -> STOP and report exact mismatch.
- Public release completed but chronology not yet reconciled -> continue until the shared report surfaces are truthful.
