# All-Day Build Contract: agentkit-cli v1.20.0 land lanes

Status: In Progress
Date: 2026-04-21
Owner: OpenClaw build-loop kickoff
Scope type: Deliverable-gated (no hour promises)

## 1. Objective

Build a deterministic `agentkit land` workflow on top of the shipped `launch -> observe -> supervise -> reconcile -> resume -> relaunch -> closeout` lane so operators can turn merge-ready closeout state into one local landing plan without manually sequencing merges, archiving lane packets, or re-deciding which lanes still need review or must keep waiting. The concrete outcome is a local-only command that consumes saved closeout and upstream continuation artifacts plus local git/worktree evidence, emits stable markdown and JSON landing artifacts plus per-lane landing packets, preserves review-required, waiting, and already-closed lanes explicitly, and leaves the repo truthfully local release-ready with tests and docs updated.

This contract is considered complete only when every deliverable and validation gate below is satisfied.

## 2. Non-Negotiable Build Rules

1. No time-based completion claims.
2. Completion is allowed only when all checklist items are checked.
3. Full test suite must pass at the end.
4. New features must ship with docs and report addendum updates in the same pass.
5. CLI outputs must be deterministic and schema-backed where specified.
6. Never modify files outside the project directory.
7. Commit after each completed deliverable, not at the end.
8. If stuck on same issue for 3 attempts, stop and write a blocker report.
9. Do NOT refactor, restyle, or improve code outside the deliverables.
10. Read existing closeout, relaunch, resume, reconcile, and launch tests/docs before writing new code.
11. Stay local-only. No git push, tag, publish, remote mutation, or silent merge execution.
12. Do not auto-merge branches. Planning and packet generation only.

## 3. Feature Deliverables

### D1. Land engine and schema-backed landing plan assembly

Build the engine that reads saved closeout artifacts and local git/worktree state, then deterministically classifies which lanes are ready to land now, which remain review-required, which stay waiting, and which are archival-only.

Required:
- `agentkit_cli/land.py`
- any shared schema/helper surface needed for stable land artifacts
- tests for D1

- [ ] Load saved `closeout.json` plus the upstream continuation evidence needed for contradiction checks.
- [ ] Emit a stable landing plan with explicit buckets such as `land-now`, `review-required`, `waiting`, and `already-closed` or equivalent truthful terminology.
- [ ] Preserve dependency and serialization safety so downstream lanes are not marked landable prematurely.
- [ ] Track landing metadata per lane, including merge/landing reason, likely target branch context, and next operator action.
- [ ] Tests for D1.

### D2. First-class CLI and artifact writing

Add `agentkit land` as a first-class command that can print markdown, write markdown and JSON, and generate per-lane landing packets without mutating git state.

Required:
- `agentkit_cli/commands/land_cmd.py`
- `agentkit_cli/main.py`
- `tests/test_land_cmd.py`

- [ ] Add CLI wiring with deterministic stdout behavior matching adjacent commands.
- [ ] Support `--json` and `--output-dir` flows that produce stable file layouts.
- [ ] Write per-lane landing packets under a deterministic directory shape.
- [ ] Keep review-required, waiting, and archival-only lanes visible in summary output instead of dropping them.
- [ ] Tests for D2.

### D3. Landing packets and merge-order guidance

Turn eligible lanes into concrete landing packets that tell an operator exactly what to verify, what order to land merge-ready lanes in, what to archive, and what still needs human review, without manually restitching prior launch history.

Required:
- `agentkit_cli/land.py`
- `tests/test_land_engine.py`
- `tests/test_land_workflow.py`

- [ ] Generate deterministic per-lane packet content that names the source artifact chain, current worktree path if known, landing readiness reason, and next operator action.
- [ ] Surface landing-order guidance when multiple merge-ready lanes can land in sequence.
- [ ] Make the output explicit about what still needs human review before landing or archival.
- [ ] Cover edge cases: missing upstream artifacts, dirty worktrees, stale paths, conflicting local branch state, serialized groups, already-closed lanes, and contradictory saved state.
- [ ] Tests for D3.

### D4. Docs, reports, and local release-readiness surfaces

Update docs and repo state so the new land workflow is documented and the branch ends in a truthful local release-ready state for v1.20.0.

Required:
- `README.md`
- `CHANGELOG.md`
- `agentkit_cli/__init__.py`
- `pyproject.toml`
- `BUILD-REPORT.md`
- `FINAL-SUMMARY.md`
- `progress-log.md`

- [ ] Document where `land` fits after `closeout` in the continuation loop.
- [ ] Bump version surfaces to `1.20.0` and describe the feature accurately.
- [ ] Update progress and build report surfaces after each deliverable with truthful test status.
- [ ] Leave the repo in a coherent local `RELEASE-READY` state, not shipped.
- [ ] Tests and contradiction scan for D4.

## 4. Test Requirements

- [ ] Unit tests for each deliverable.
- [ ] Integration coverage for the full `closeout -> land` workflow.
- [ ] Edge cases: missing artifacts, malformed lane state, dirty or stale worktrees, conflicting branch state, serialized groups, already-closed lanes, and deterministic packet ordering.
- [ ] All existing tests must still pass.
- [ ] Final full suite passes locally.

## 5. Reports

- Write progress to `progress-log.md` after each deliverable.
- Include what was built, what tests pass, what is next, and any blockers.
- Before trusting any release or status narrative, run `scripts/pre-action-recall.sh release agentkit-cli /Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes` first so current handoff state, temporal drift, and learned rules are in view, then run `scripts/check-status-conflicts.sh /Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes` or an equivalent contradiction scan.
- Before final summary, run `scripts/post-agent-hygiene-check.sh /Users/mordecai/repos/agentkit-cli-v1.20.0-land-lanes` and either clean findings or note why they are intentional.
- Write a final summary when all deliverables are done or the pass stops.

## 6. Stop Conditions

- All deliverables checked and all tests passing -> DONE.
- 3 consecutive failed attempts on same issue -> STOP and write a blocker report.
- Scope creep detected, especially if the feature wants to auto-merge branches or mutate remote refs -> STOP and report the new requirement instead of freelancing it.
- All tests passing but deliverables remain -> continue to next deliverable.
