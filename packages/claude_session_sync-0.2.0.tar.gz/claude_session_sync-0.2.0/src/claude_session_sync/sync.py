"""
push_sessions / pull_sessions の高レベルオーケストレーション
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from claude_session_sync.config import Config


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _ensure_repo(config: "Config") -> None:
    """sync_repo_dir が無ければクローンする。"""
    from claude_session_sync.git_ops import git_clone, git_pull_safe

    repo_dir = config.sync_repo_dir
    if not os.path.isdir(os.path.join(repo_dir, ".git")):
        print(f"リポジトリが見つかりません。クローンします: {config.github_remote_url}")
        os.makedirs(os.path.dirname(repo_dir), exist_ok=True)
        git_clone(config.github_remote_url, repo_dir)
    else:
        if not git_pull_safe(repo_dir):
            print("警告: git pull に失敗しましたが、ローカルのデータで続行します。")


def _read_jsonl(file_path: str) -> list[dict]:
    """JSONL ファイルを読み込んで行ごとの dict リストを返す。"""
    lines: list[dict] = []
    try:
        with open(file_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        lines.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass  # 壊れた行はスキップ
    except FileNotFoundError:
        pass
    return lines


def _write_jsonl(file_path: str, records: list[dict]) -> None:
    """dict リストを JSONL ファイルに書き出す。"""
    dir_path = os.path.dirname(file_path)
    if dir_path:
        os.makedirs(dir_path, exist_ok=True)
    # 一時ファイルに書き出してからアトミックに置換
    fd, tmp_path = tempfile.mkstemp(dir=dir_path or ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for record in records:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        os.replace(tmp_path, file_path)
    except:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _apply_placeholder_to_record(record: dict, mapper) -> dict:
    """dict の文字列値を再帰的にプレースホルダ変換する。"""
    if isinstance(record, dict):
        return {k: _apply_placeholder_to_record(v, mapper) for k, v in record.items()}
    if isinstance(record, list):
        return [_apply_placeholder_to_record(item, mapper) for item in record]
    if isinstance(record, str):
        return mapper.to_placeholder(record)
    return record


def _apply_local_to_record(record: dict, mapper) -> dict:
    """dict の文字列値を再帰的にローカルパスへ復元する。"""
    if isinstance(record, dict):
        return {k: _apply_local_to_record(v, mapper) for k, v in record.items()}
    if isinstance(record, list):
        return [_apply_local_to_record(item, mapper) for item in record]
    if isinstance(record, str):
        return mapper.to_local(record)
    return record


def _session_id_from_filename(filename: str) -> str:
    """ファイル名（.jsonl 拡張子付き）からセッション ID を取得する。"""
    return filename.replace(".jsonl", "")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------

def push_sessions(config: "Config", dry_run: bool = False, skip_pull: bool = False) -> list[str]:
    """
    ローカルセッションを同期リポジトリに push する。

    Parameters
    ----------
    config : Config
    dry_run : bool
        True の場合、ファイルの書き出しと git 操作をスキップし変換結果を表示するだけ。
    skip_pull : bool
        True の場合、push 前の git pull をスキップする。
        セッション終了時の push で使用（pull がロック削除を巻き戻すのを防ぐ）。

    Returns
    -------
    list[str]
        push したセッション ID のリスト。
    """
    from claude_session_sync.session import discover_sessions
    from claude_session_sync.path_mapper import PathMapper
    from claude_session_sync.git_ops import git_add, git_commit, git_push
    from claude_session_sync.shared_placeholders import get_machine_placeholders_as_mapper_dict

    # shared_placeholders.json からこのマシンのプレースホルダを読み込み、
    # config.placeholders とマージして PathMapper を構築する
    merged_placeholders = dict(config.placeholders)
    if os.path.isdir(config.sync_repo_dir):
        shared = get_machine_placeholders_as_mapper_dict(config.sync_repo_dir, config.machine_id)
        # shared のエントリで config.placeholders に無いものを追加
        for k, v in shared.items():
            if k not in merged_placeholders:
                merged_placeholders[k] = v

    mapper = PathMapper(merged_placeholders)

    # 1. セッション一覧を発見
    sessions = discover_sessions(config.claude_projects_dir)
    print(f"ローカルセッション数: {len(sessions)}")

    # sync_directories フィルタリング
    sync_dirs = getattr(config, "sync_directories", []) or []
    if sync_dirs:
        filtered_sessions = []
        for session in sessions:
            project_path = (session.project_path or "").replace("\\", "/")
            in_sync_dir = any(
                project_path == sd.replace("\\", "/").rstrip("/") or project_path.startswith(sd.replace("\\", "/").rstrip("/") + "/")
                for sd in sync_dirs
            )
            if in_sync_dir:
                filtered_sessions.append(session)
            else:
                short_path = project_path or session.project_dir
                print(f"  スキップ: {short_path} (sync_directories 対象外)")
        sessions = filtered_sessions
        print(f"フィルタ後セッション数: {len(sessions)}")
    else:
        print("警告: sync_directories が未設定のため全セッションを push します。")

    if not sessions:
        print("プッシュするセッションがありません。")
        return []

    # 2 & 3. リポジトリ確保 + pull（dry_run でも確認のため行う）
    if not dry_run:
        if skip_pull:
            # リポジトリの存在だけ確認（pull はスキップ）
            repo_dir = config.sync_repo_dir
            if not os.path.isdir(os.path.join(repo_dir, ".git")):
                _ensure_repo(config)
        else:
            _ensure_repo(config)

    pushed_ids: list[str] = []
    # session_meta を更新すべきセッションID（実際にJSONLが変更されたもののみ）
    updated_meta_ids: list[str] = []
    files_written: list[str] = []

    # ロックチェック用インポート
    _lock_check_available = False
    try:
        from claude_session_sync.session_lock import check_lock
        _lock_check_available = True
    except ImportError:
        pass

    for session in sessions:
        # ロックチェック: 他マシンがロック中のセッションはスキップ
        if not dry_run and _lock_check_available:
            lock_info = check_lock(config.sync_repo_dir, session.session_id)
            if lock_info and lock_info.get("machine_id") != config.machine_id:
                locked_by = lock_info.get("machine_id", "unknown")
                print(
                    f"⚠ セッション {session.session_id} は {locked_by} が作業中です"
                    f"（push をスキップ）"
                )
                continue

        # 4. JSONL 読み込み
        records = _read_jsonl(session.file_path)

        # 5. プレースホルダ変換
        converted = [_apply_placeholder_to_record(r, mapper) for r in records]

        # プロジェクトディレクトリ名をプレースホルダ変換
        # project_path（実パス）をプレースホルダ化してからディレクトリ名に変換することで、
        # _paths.json のキーと一致させる（_paths.json 書き込み処理と同じロジック）
        if session.project_path:
            _placeholder_path = mapper.to_placeholder(session.project_path)
            placeholder_project_dir = PathMapper.path_to_project_dir(_placeholder_path)
        else:
            # project_path が取得できない場合は project_dir からパスを復元してプレースホルダ変換
            # ディレクトリ名に直接 to_placeholder すると部分マッチ（USERNAME等）が起きるため、
            # 必ずパス形式に戻してから変換する
            _path_form = PathMapper.dir_name_to_path(session.project_dir)
            _placeholder_path = mapper.to_placeholder(_path_form)
            placeholder_project_dir = PathMapper.path_to_project_dir(_placeholder_path)

        dest_rel = os.path.join(
            "sessions",
            placeholder_project_dir,
            f"{session.session_id}.jsonl",
        )
        dest_abs = os.path.join(config.sync_repo_dir, dest_rel)

        if dry_run:
            print(f"  [dry-run] {session.session_id} -> {dest_rel}")
            print(f"           レコード数: {len(records)}")
            pushed_ids.append(session.session_id)
            continue

        # 6. 書き出し前に「実際に変更があるか」を確認
        #    変更がないセッションは session_meta の last_editor を書き換えない
        _content_changed = True
        if os.path.isfile(dest_abs):
            existing_meta_path = os.path.join(
                config.sync_repo_dir, "session_meta", f"{session.session_id}.json"
            )
            if os.path.isfile(existing_meta_path):
                try:
                    with open(existing_meta_path, encoding="utf-8") as _mf:
                        _existing_meta = json.load(_mf)
                    _meta_mtime = _existing_meta.get("last_modified")
                    # ローカルファイルの mtime がメタと同じなら変更なし
                    if _meta_mtime is not None and abs(session.last_modified - _meta_mtime) < 1.0:
                        _content_changed = False
                except (json.JSONDecodeError, OSError):
                    pass

        _write_jsonl(dest_abs, converted)
        files_written.append(dest_rel)
        pushed_ids.append(session.session_id)
        if _content_changed:
            updated_meta_ids.append(session.session_id)

    # 7. subagents/ があれば同様に処理
    subagents_src = os.path.join(config.claude_projects_dir, "..", "subagents")
    subagents_src = os.path.normpath(subagents_src)
    if os.path.isdir(subagents_src) and not dry_run:
        dest_subagents_base = os.path.join(
            config.sync_repo_dir, "subagents"
        )
        for root, _, filenames in os.walk(subagents_src):
            for fname in filenames:
                src_file = os.path.join(root, fname)
                rel = os.path.relpath(src_file, subagents_src)
                dest_file = os.path.join(dest_subagents_base, rel)
                os.makedirs(os.path.dirname(dest_file), exist_ok=True)
                shutil.copy2(src_file, dest_file)
                files_written.append(os.path.relpath(dest_file, config.sync_repo_dir).replace("\\", "/"))

    if dry_run:
        print("dry-run モード: ファイルの書き出しと git 操作をスキップしました。")
        return pushed_ids

    # 8. マシンメタ情報を書き出し
    machines_dir = os.path.join(config.sync_repo_dir, "machines")
    os.makedirs(machines_dir, exist_ok=True)
    machine_meta = {
        "machine_id": config.machine_id,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "session_count": len(pushed_ids),
        "placeholders": config.placeholders,
    }
    machine_file = os.path.join(machines_dir, f"{config.machine_id}.json")
    with open(machine_file, "w", encoding="utf-8") as f:
        json.dump(machine_meta, f, ensure_ascii=False, indent=2)
    files_written.append(os.path.join("machines", f"{config.machine_id}.json"))

    # 8a. sessions/_paths.json を書き出し（新形式マーカー）
    # pull 時に旧形式（machine_id ベース）と区別するために使用する。
    sessions_paths_file = os.path.join(config.sync_repo_dir, "sessions", "_paths.json")
    os.makedirs(os.path.dirname(sessions_paths_file), exist_ok=True)
    sessions_paths_data: dict = {}
    if os.path.isfile(sessions_paths_file):
        try:
            with open(sessions_paths_file, encoding="utf-8") as _spf:
                sessions_paths_data = json.load(_spf)
        except (json.JSONDecodeError, OSError):
            sessions_paths_data = {}
    # 今回 push したプロジェクトのプレースホルダパスを登録する
    for session in sessions:
        placeholder_path = mapper.to_placeholder(session.project_path)
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)
        if placeholder_project_dir not in sessions_paths_data:
            sessions_paths_data[placeholder_project_dir] = placeholder_path
    with open(sessions_paths_file, "w", encoding="utf-8") as _spf:
        json.dump(sessions_paths_data, _spf, ensure_ascii=False, indent=2)
    files_written.append(os.path.join("sessions", "_paths.json"))

    # 8b. session_meta 書き出し
    # 実際にJSONLが変更されたセッション（updated_meta_ids）のみ last_editor を更新する。
    # 変更のないセッションの session_meta は書き換えないことで、他マシンで編集した
    # セッションの「最終実行端末」表示が誤って上書きされるのを防ぐ。
    session_meta_dir = os.path.join(config.sync_repo_dir, "session_meta")
    os.makedirs(session_meta_dir, exist_ok=True)
    now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    # セッションIDからlast_modifiedを引けるようにマップを作成
    session_mtime_map = {s.session_id: s.last_modified for s in sessions}
    for session_id in updated_meta_ids:
        meta = {
            "session_id": session_id,
            "last_editor": config.machine_id,
            "last_edited_at": now_iso,
        }
        # 元のJSONLファイルのmtimeを記録（他マシンで同一の「最終更新」時刻を表示するため）
        if session_id in session_mtime_map:
            meta["last_modified"] = session_mtime_map[session_id]
        meta_file = os.path.join(session_meta_dir, f"{session_id}.json")
        with open(meta_file, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        files_written.append(os.path.join("session_meta", f"{session_id}.json"))

    # 8c. メモリ・CLAUDE.md の同期
    try:
        from claude_session_sync.config_sync import push_shared_config
        config_files = push_shared_config(config, mapper)
        files_written.extend(config_files)
        if config_files:
            print(f"メモリ・設定ファイルを {len(config_files)} 件書き出しました。")
    except Exception as e:
        print(f"警告: メモリ同期の書き出しに失敗しました: {e}")

    # 9. git add / commit / push
    if files_written:
        git_add(config.sync_repo_dir, files_written)
        commit_msg = (
            f"sync: push {len(pushed_ids)} sessions from {config.machine_id} "
            f"[{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}]"
        )
        try:
            git_commit(config.sync_repo_dir, commit_msg)
        except subprocess.CalledProcessError:
            # nothing to commit（差分なし）の場合はスキップ
            print("変更がないためコミットをスキップしました。")
        else:
            git_push(config.sync_repo_dir)
            print(f"{len(pushed_ids)} 件のセッションをプッシュしました。")
    else:
        print("変更がないためプッシュをスキップしました。")

    # 10. 最終プッシュ日時を更新
    config.last_push_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    config.save()

    # 11. プッシュしたセッション ID リストを返す
    return pushed_ids


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------

def pull_sessions(
    config: "Config",
    dry_run: bool = False,
    force: bool = False,
) -> list[str]:
    """
    同期リポジトリから他マシンのセッションを pull してローカルに配置する。

    Parameters
    ----------
    config : Config
    dry_run : bool
        True の場合、ファイルの書き出しをスキップし変換結果を表示するだけ。
    force : bool
        True の場合、既存ローカルセッションを上書きする。

    Returns
    -------
    list[str]
        pull したセッション ID のリスト。
    """
    from claude_session_sync.path_mapper import PathMapper
    from claude_session_sync.git_ops import git_pull
    from claude_session_sync.shared_placeholders import get_machine_placeholders_as_mapper_dict

    # shared_placeholders.json からこのマシンのプレースホルダを読み込み、
    # config.placeholders とマージして PathMapper を構築する
    merged_placeholders = dict(config.placeholders)
    if os.path.isdir(config.sync_repo_dir):
        shared = get_machine_placeholders_as_mapper_dict(config.sync_repo_dir, config.machine_id)
        for k, v in shared.items():
            if k not in merged_placeholders:
                merged_placeholders[k] = v

    # pull 時は {{HOME}} / {{USERNAME}} をフォールバックとして追加（後方互換）
    from claude_session_sync.config import Config as _Config
    for k, v in _Config.fallback_placeholders().items():
        if k not in merged_placeholders:
            merged_placeholders[k] = v

    mapper = PathMapper(merged_placeholders)

    # 1. git pull
    if os.path.isdir(os.path.join(config.sync_repo_dir, ".git")):
        git_pull(config.sync_repo_dir)
    else:
        print("同期リポジトリが見つかりません。先に `init` または `push` を実行してください。")
        return []

    # 2. sessions/ 内の全マシンを列挙
    sessions_root = os.path.join(config.sync_repo_dir, "sessions")
    if not os.path.isdir(sessions_root):
        print("同期リポジトリにセッションデータがありません。")
        return []

    pulled_ids: list[str] = []
    updated_ids: list[str] = []

    # ロックチェック用インポート
    _pull_lock_available = False
    try:
        from claude_session_sync.session_lock import check_lock as _check_lock_fn
        _pull_lock_available = True
    except ImportError:
        pass

    # --- 新形式判定 ---
    # sessions/_paths.json が存在すれば新形式（共有1コピー方式）として処理する。
    sessions_paths_file = os.path.join(sessions_root, "_paths.json")
    is_new_format = os.path.isfile(sessions_paths_file)

    if is_new_format:
        # --- 新形式処理: sessions/{placeholder_project_dir}/{session_id}.jsonl を直接走査 ---
        # sessions/_paths.json のキー（= placeholder_project_dir）だけを走査することで
        # 旧 machine_id ディレクトリを自動的に無視する。
        try:
            with open(sessions_paths_file, encoding="utf-8") as _spf:
                sessions_paths_data: dict = json.load(_spf)
        except (json.JSONDecodeError, OSError):
            sessions_paths_data = {}

        project_dir_placeholders = list(sessions_paths_data.keys())
    else:
        # --- 旧形式フォールバック: sessions/{machine_id}/{placeholder_project_dir} を走査 ---
        # sessions/ 直下のディレクトリのうち、自マシン以外の machine_id を列挙する。
        # この分岐は後方互換のためだけに残す。
        project_dir_placeholders = []  # 旧形式では使わない

    if is_new_format:
        # 新形式: _paths.json のキーを placeholder_project_dir として走査
        for project_dir_placeholder in project_dir_placeholders:
            project_path_dir = os.path.join(sessions_root, project_dir_placeholder)
            if not os.path.isdir(project_path_dir):
                continue

            for fname in os.listdir(project_path_dir):
                if not fname.endswith(".jsonl"):
                    continue

                session_id = _session_id_from_filename(fname)
                src_file = os.path.join(project_path_dir, fname)

                # ロックチェック: 他マシンがロック中であれば警告表示（pull はする）
                if not dry_run and _pull_lock_available:
                    lock_info = _check_lock_fn(config.sync_repo_dir, session_id)
                    if lock_info and lock_info.get("machine_id") != config.machine_id:
                        locked_by = lock_info.get("machine_id", "unknown")
                        print(
                            f"⚠ セッション {session_id} は {locked_by} が作業中です"
                        )

                # JSONL 読み込み
                records = _read_jsonl(src_file)
                if not records:
                    continue

                # 3a. プレースホルダ → ローカルパス復元
                converted = [_apply_local_to_record(r, mapper) for r in records]

                # 3b. ローカル project_dir 名を計算
                # converted レコードの cwd から project_path を取得
                project_path = ""
                for record in converted:
                    cwd = record.get("cwd", "")
                    if cwd:
                        project_path = cwd
                        break

                # project_path からディレクトリ名を生成
                if project_path:
                    local_project_dir = mapper.path_to_project_dir(project_path)
                else:
                    # フォールバック: プレースホルダディレクトリ名から変換
                    placeholder_path = PathMapper.dir_name_to_path(project_dir_placeholder)
                    local_path = mapper.to_local(placeholder_path)
                    local_project_dir = PathMapper.path_to_project_dir(local_path)

                dest_dir = os.path.join(config.claude_projects_dir, local_project_dir)
                dest_file = os.path.join(dest_dir, fname)

                if dry_run:
                    action = "上書き" if os.path.exists(dest_file) else "新規"
                    print(f"  [dry-run] {session_id} -> {dest_file} [{action}]")
                    pulled_ids.append(session_id)
                    continue

                # 既存チェック
                if os.path.exists(dest_file) and not force:
                    remote_meta_path = os.path.join(
                        config.sync_repo_dir, "session_meta", f"{session_id}.json"
                    )
                    should_update = False
                    if os.path.isfile(remote_meta_path):
                        try:
                            with open(remote_meta_path, encoding="utf-8") as f:
                                remote_meta = json.load(f)
                            remote_mtime = remote_meta.get("last_modified", 0)
                            local_mtime = os.stat(dest_file).st_mtime
                            if remote_mtime > local_mtime:
                                should_update = True
                        except (json.JSONDecodeError, OSError):
                            pass
                    if not should_update:
                        continue
                    is_update = True
                else:
                    is_update = False

                # 3c. 配置
                os.makedirs(dest_dir, exist_ok=True)
                _write_jsonl(dest_file, converted)

                # 3d. mtime を session_meta の last_modified に合わせて復元する。
                #
                # _write_jsonl は tempfile + os.replace でファイルを書き出すため、
                # ファイルの mtime は「今」に更新される。
                # push_sessions はこのマシンのローカルファイルの mtime と
                # session_meta.last_modified を比較して「変更の有無」を判定するため、
                # mtime が書き換わると pull 直後の push で全セッションが
                # 「変更あり」と誤判定されて last_editor が全て自マシンに上書きされる。
                # os.utime で mtime を session_meta の値に戻すことでこれを防ぐ。
                remote_meta_path_for_utime = os.path.join(
                    config.sync_repo_dir, "session_meta", f"{session_id}.json"
                )
                if os.path.isfile(remote_meta_path_for_utime):
                    try:
                        with open(remote_meta_path_for_utime, encoding="utf-8") as _f:
                            _meta_for_utime = json.load(_f)
                        _saved_mtime = _meta_for_utime.get("last_modified")
                        if _saved_mtime is not None:
                            os.utime(dest_file, (_saved_mtime, _saved_mtime))
                    except (json.JSONDecodeError, OSError):
                        pass

                if is_update:
                    updated_ids.append(session_id)
                else:
                    pulled_ids.append(session_id)

                # 3e. history.jsonl にエントリ追加
                _update_history(
                    history_file=config.claude_history_file,
                    session_id=session_id,
                    project_path=project_path,
                    records=converted,
                )

    else:
        # --- 旧形式処理（後方互換）: sessions/{machine_id}/{placeholder_project_dir}/{session_id}.jsonl ---
        # session_id → {machine_id: (src_file, project_dir_placeholder)} のマップを構築する。
        # 同一 session_id が複数マシンに存在する場合に last_editor を優先選択するため。
        session_candidates: dict[str, dict[str, tuple[str, str]]] = {}

        for machine_id in os.listdir(sessions_root):
            # 自マシンはスキップ
            if machine_id == config.machine_id:
                continue

            machine_sessions_dir = os.path.join(sessions_root, machine_id)
            if not os.path.isdir(machine_sessions_dir):
                continue

            for project_dir_placeholder in os.listdir(machine_sessions_dir):
                project_path_placeholder = os.path.join(
                    machine_sessions_dir, project_dir_placeholder
                )
                if not os.path.isdir(project_path_placeholder):
                    continue

                for fname in os.listdir(project_path_placeholder):
                    if not fname.endswith(".jsonl"):
                        continue

                    session_id = _session_id_from_filename(fname)
                    src_file = os.path.join(project_path_placeholder, fname)

                    if session_id not in session_candidates:
                        session_candidates[session_id] = {}
                    session_candidates[session_id][machine_id] = (src_file, project_dir_placeholder)

        for session_id, machine_map in session_candidates.items():
            # session_meta から last_editor を取得して優先マシンを決める
            preferred_machine: str | None = None
            remote_meta_path = os.path.join(
                config.sync_repo_dir, "session_meta", f"{session_id}.json"
            )
            if os.path.isfile(remote_meta_path):
                try:
                    with open(remote_meta_path, encoding="utf-8") as _mf:
                        _session_meta = json.load(_mf)
                    _last_editor = _session_meta.get("last_editor")
                    if _last_editor and _last_editor in machine_map:
                        preferred_machine = _last_editor
                except (json.JSONDecodeError, OSError):
                    pass

            if preferred_machine is None:
                preferred_machine = next(iter(machine_map))

            machine_id = preferred_machine
            src_file, project_dir_placeholder = machine_map[machine_id]

            # ロックチェック: 他マシンがロック中であれば警告表示（pull はする）
            if not dry_run and _pull_lock_available:
                lock_info = _check_lock_fn(config.sync_repo_dir, session_id)
                if lock_info and lock_info.get("machine_id") not in (config.machine_id, machine_id):
                    locked_by = lock_info.get("machine_id", "unknown")
                    print(
                        f"⚠ セッション {session_id} は {locked_by} が作業中です"
                    )
                elif lock_info and lock_info.get("machine_id") == machine_id:
                    pass

            # JSONL 読み込み
            records = _read_jsonl(src_file)
            if not records:
                continue

            fname = os.path.basename(src_file)

            # プレースホルダ → ローカルパス復元
            converted = [_apply_local_to_record(r, mapper) for r in records]

            # ローカル project_dir 名を計算
            project_path = ""
            for record in converted:
                cwd = record.get("cwd", "")
                if cwd:
                    project_path = cwd
                    break

            if project_path:
                local_project_dir = mapper.path_to_project_dir(project_path)
            else:
                placeholder_path = PathMapper.dir_name_to_path(project_dir_placeholder)
                local_path = mapper.to_local(placeholder_path)
                local_project_dir = PathMapper.path_to_project_dir(local_path)

            dest_dir = os.path.join(config.claude_projects_dir, local_project_dir)
            dest_file = os.path.join(dest_dir, fname)

            if dry_run:
                action = "上書き" if os.path.exists(dest_file) else "新規"
                print(
                    f"  [dry-run] {session_id} ({machine_id}) "
                    f"-> {dest_file} [{action}]"
                )
                pulled_ids.append(session_id)
                continue

            # 既存チェック
            if os.path.exists(dest_file) and not force:
                remote_meta_path = os.path.join(
                    config.sync_repo_dir, "session_meta", f"{session_id}.json"
                )
                should_update = False
                if os.path.isfile(remote_meta_path):
                    try:
                        with open(remote_meta_path, encoding="utf-8") as f:
                            remote_meta = json.load(f)
                        remote_mtime = remote_meta.get("last_modified", 0)
                        local_mtime = os.stat(dest_file).st_mtime
                        if remote_mtime > local_mtime:
                            should_update = True
                    except (json.JSONDecodeError, OSError):
                        pass
                if not should_update:
                    continue
                is_update = True
            else:
                is_update = False

            # 配置
            os.makedirs(dest_dir, exist_ok=True)
            _write_jsonl(dest_file, converted)

            # mtime を session_meta の last_modified に合わせて復元する
            remote_meta_path_for_utime = os.path.join(
                config.sync_repo_dir, "session_meta", f"{session_id}.json"
            )
            if os.path.isfile(remote_meta_path_for_utime):
                try:
                    with open(remote_meta_path_for_utime, encoding="utf-8") as _f:
                        _meta_for_utime = json.load(_f)
                    _saved_mtime = _meta_for_utime.get("last_modified")
                    if _saved_mtime is not None:
                        os.utime(dest_file, (_saved_mtime, _saved_mtime))
                except (json.JSONDecodeError, OSError):
                    pass

            if is_update:
                updated_ids.append(session_id)
            else:
                pulled_ids.append(session_id)

            # history.jsonl にエントリ追加
            _update_history(
                history_file=config.claude_history_file,
                session_id=session_id,
                project_path=project_path,
                records=converted,
            )

    if dry_run:
        print(f"dry-run モード: {len(pulled_ids)} 件のセッションが取得対象です。")
        return pulled_ids

    if pulled_ids:
        print(f"{len(pulled_ids)} 件のセッションをプルしました。")
    if updated_ids:
        print(f"{len(updated_ids)} 件のセッションを更新しました。")
    if not pulled_ids and not updated_ids:
        print("新しいセッションはありませんでした。")

    # 3e. メモリ・CLAUDE.md の復元
    if not dry_run:
        try:
            from claude_session_sync.config_sync import pull_shared_config
            config_pulled = pull_shared_config(config, mapper)
            if config_pulled:
                print(f"メモリ・設定ファイルを {config_pulled} 件復元しました。")
        except Exception as e:
            print(f"警告: メモリ同期の復元に失敗しました: {e}")

    # 4. 最終プル日時を更新
    config.last_pull_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    config.save()

    # 5. プルしたセッション ID リストを返す（新規 + 更新の両方を含む）
    return pulled_ids + updated_ids


def _update_history(
    history_file: str,
    session_id: str,
    project_path: str,
    records: list[dict],
) -> None:
    """
    ~/.claude/history.jsonl に session_id のエントリを追加する。
    既に存在する場合はスキップ。
    """
    # 既存エントリを読み込み
    existing: list[dict] = []
    if os.path.exists(history_file):
        with open(history_file, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        existing.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass

    # sessionId の重複チェック
    for entry in existing:
        if entry.get("sessionId") == session_id:
            return  # 既に存在する

    # first_message を records から取得
    first_message = ""
    for record in records:
        msg = record.get("message", {})
        if isinstance(msg, dict):
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                first_message = content[:100]
                break
            if isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text = part.get("text", "")
                        if text:
                            first_message = text[:100]
                            break
                if first_message:
                    break

    now_ms = int(time.time() * 1000)
    new_entry = {
        "display": first_message,
        "pastedContents": {},
        "timestamp": now_ms,
        "project": project_path,
        "sessionId": session_id,
    }

    os.makedirs(os.path.dirname(os.path.abspath(history_file)), exist_ok=True)
    with open(history_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(new_entry, ensure_ascii=False) + "\n")
