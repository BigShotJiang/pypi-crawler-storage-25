# -*- coding: utf-8 -*-
"""
ixentbench/play.py
Modo Solo — BYOK, Modelo Local, Agente Custom y Sponsored.
"""

import json
import time
import hashlib
import pathlib
import subprocess
import webbrowser
import sys
import click
import requests
from ixentbench.auth import get_firebase_token
from ixentbench.config import (
    GOOGLE_API_KEY, ANTHROPIC_API_KEY, OPENAI_API_KEY,
    LOCAL_MODEL_URL, IXENT_SDK_URL, VISUALIZER_URL,
    PROMPTS_DIR, STRATEGIES_DIR, validate_env
)


# =============================================================================
# HELPER: Carga de archivos opcionales
# =============================================================================

# ── LÍMITE DE SEGURIDAD: Protección Denial of Wallet (DoW) ───────────────────
MAX_CHARS = 2222

def _load_text_file(path: str, label: str, save_dir: pathlib.Path) -> str:
    p = pathlib.Path(path)
    
    # --- MAGIA UX: Búsqueda Inteligente ---
    # Si el archivo no existe en la ruta actual, lo buscamos en la carpeta estándar
    if not p.exists():
        suggested_p = save_dir / p.name
        if suggested_p.exists():
            p = suggested_p
        else:
            click.echo(f"❌ File not found: {path}", err=True)
            click.echo(f"   Tip: Place your file in {save_dir} or provide the full path.", err=True)
            raise SystemExit(1)
    # --------------------------------------

    content = p.read_text(encoding="utf-8").strip()
    
    # --- ESCUDO DEVSECOPS (v1.0.11) ---
    if len(content) > MAX_CHARS:
        click.echo(f"❌ {label} too long: {len(content)} chars (max {MAX_CHARS}).", err=True)
        raise SystemExit(1)
    # ----------------------------------
        
    click.echo(f"📄 {label} loaded: {p.name} ({len(content)} chars)")
    
    # Si el archivo era externo, lo guardamos en la carpeta local para persistencia
    saved = save_dir / p.name
    if not saved.exists():
        saved.write_text(content, encoding="utf-8")
        click.echo(f"   💾 Saved to: {saved}")
        
    return content

# =============================================================================
# HELPER: Limpiar bloques markdown del JSON
# =============================================================================

def _strip_markdown(raw: str) -> str:
    if raw.startswith("```"):
        lines = raw.split("\n")
        if lines[0].startswith("```"):  lines = lines[1:]
        if lines[-1].startswith("```"): lines = lines[:-1]
        raw = "\n".join(lines)
    return raw.strip()


# =============================================================================
# MOTOR A: BYOK — API Key local del usuario
# Soporta Gemini (Google), Claude (Anthropic) y GPT (OpenAI)
# =============================================================================

def _get_move_byok(model_name: str, system_prompt: str,
                   state: dict, session: dict) -> tuple:
    context_json = json.dumps({
        "meta":           state["meta"],
        "inventory":      state["data"]["inventory"],
        "mice":           state["data"]["mice"],
        "board_encoding": state["data"]["board_encoding"],
        "history_full":   state["data"]["history"],
    }, ensure_ascii=False)

    user_msg = (
        f"--- CURRENT SITUATION (TURN {state['meta']['turn']}) ---\n"
        f"{context_json}\n"
        f"TASK: Generate JSON response with your best move."
    )

    provider = session.get("provider", "google")
    t0 = time.time()

    try:
        if provider == "google":
            from google import genai
            from google.genai import types
            client   = genai.Client(api_key=GOOGLE_API_KEY)
            response = client.models.generate_content(
                model    = model_name,
                contents = [system_prompt + "\n\n" + user_msg],
                config   = types.GenerateContentConfig(
                    response_mime_type="application/json"
                )
            )
            raw     = response.text.strip()
            usage   = response.usage_metadata
            in_t    = getattr(usage, "prompt_token_count",     0) or 0
            out_t   = getattr(usage, "candidates_token_count", 0) or 0
            tot_t   = getattr(usage, "total_token_count",      0) or 0
            think_t = max(0, tot_t - in_t - out_t)

        elif provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
            msg    = client.messages.create(
                model      = model_name,
                max_tokens = 4096,
                system     = system_prompt,
                messages   = [{"role": "user", "content": user_msg}],
            )
            raw     = msg.content[0].text.strip()
            in_t    = msg.usage.input_tokens
            out_t   = msg.usage.output_tokens
            tot_t   = in_t + out_t
            think_t = 0

        elif provider == "openai":
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_API_KEY)
            resp   = client.chat.completions.create(
                model    = model_name,
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user",   "content": user_msg},
                ],
                response_format={"type": "json_object"},
            )
            raw     = resp.choices[0].message.content.strip()
            in_t    = resp.usage.prompt_tokens
            out_t   = resp.usage.completion_tokens
            tot_t   = resp.usage.total_tokens
            think_t = 0

        else:
            click.echo(f"❌ Unknown provider: {provider}", err=True)
            return None, "Unknown provider", None

    except Exception as e:
        click.echo(f"\n🛑 CRITICAL AI ERROR: {type(e).__name__}: {e}", err=True)
        raise SystemExit(1)

    inference_sec = round(time.time() - t0, 2)
    gen_t = out_t + think_t
    tps   = round(gen_t / inference_sec, 2) if inference_sec > 0 else 0
    click.echo(f"   ⏱️  {inference_sec}s | {tps} TPS")

    token_data = {
        "input_tokens": in_t, "output_tokens": out_t,
        "thinking_tokens": think_t, "total": tot_t,
        "turn_inference_sec": inference_sec, "turn_tps": tps,
        "is_local_hardware": False,
    }

    raw = _strip_markdown(raw)
    try:
        decision = json.loads(raw)
        return decision.get("command"), decision.get("reasoning"), token_data
    except json.JSONDecodeError as e:
        click.echo(f"⚠️  JSON parse error: {e}")
        return None, "Invalid Format", None


# =============================================================================
# MOTOR B: MODELO LOCAL — Ollama, LM Studio, llama.cpp...
# Compatible con cualquier servidor que implemente la API de OpenAI
# No requiere API Key. is_local_hardware=True excluye TPS del leaderboard
# =============================================================================

def _get_move_local(model_name: str, system_prompt: str,
                    state: dict, local_url: str) -> tuple:
    context_json = json.dumps({
        "meta":           state["meta"],
        "inventory":      state["data"]["inventory"],
        "mice":           state["data"]["mice"],
        "board_encoding": state["data"]["board_encoding"],
        "history_full":   state["data"]["history"],
    }, ensure_ascii=False)

    user_msg = (
        f"--- CURRENT SITUATION (TURN {state['meta']['turn']}) ---\n"
        f"{context_json}\n"
        f"TASK: Generate JSON response with your best move."
    )

    t0 = time.time()
    try:
        resp = requests.post(
            f"{local_url}/chat/completions",
            json={
                "model":    model_name,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user",   "content": user_msg},
                ],
                "response_format": {"type": "json_object"},
            },
            timeout=610
        )
        resp.raise_for_status()
        data    = resp.json()
        raw     = data["choices"][0]["message"]["content"].strip()
        in_t    = data.get("usage", {}).get("prompt_tokens", 0)
        out_t   = data.get("usage", {}).get("completion_tokens", 0)
        tot_t   = data.get("usage", {}).get("total_tokens", 0)
        think_t = 0
    except Exception as e:
        click.echo(f"⚠️  Local model error: {e}")
        return None, "Local model error", None

    inference_sec = round(time.time() - t0, 2)
    tps = round(out_t / inference_sec, 2) if inference_sec > 0 else 0
    click.echo(f"   ⏱️  {inference_sec}s | {tps} TPS (local — excluded from leaderboard)")

    token_data = {
        "input_tokens": in_t, "output_tokens": out_t,
        "thinking_tokens": think_t, "total": tot_t,
        "turn_inference_sec": inference_sec, "turn_tps": tps,
        "is_local_hardware": True,
    }

    raw = _strip_markdown(raw)
    try:
        decision = json.loads(raw)
        return decision.get("command"), decision.get("reasoning"), token_data
    except json.JSONDecodeError as e:
        click.echo(f"⚠️  JSON parse error: {e}")
        return None, "Invalid Format", None


# =============================================================================
# MOTOR C: AGENTE CUSTOM — Script Python del usuario
# El script recibe el estado por stdin (JSON) y devuelve la jugada
# por stdout (JSON): {"command": "...", "reasoning": "..."}
# No requiere API Key ni conexión a internet
# =============================================================================

def _get_move_agent(agent_script: str, state: dict) -> tuple:
    state_json = json.dumps(state, ensure_ascii=False)
    t0 = time.time()
    try:
        result = subprocess.run(
            [sys.executable, agent_script],
            input          = state_json,
            capture_output = True,
            text           = True,
            timeout        = 120
        )
        if result.returncode != 0:
            click.echo(f"⚠️  Agent script error:\n{result.stderr[:300]}")
            return None, "Agent error", None

        raw           = result.stdout.strip()
        inference_sec = round(time.time() - t0, 2)
        click.echo(f"   ⏱️  Agent: {inference_sec}s (local script)")

        token_data = {
            "input_tokens": 0, "output_tokens": 0,
            "thinking_tokens": 0, "total": 0,
            "turn_inference_sec": inference_sec, "turn_tps": 0,
            "is_local_hardware": True,
        }
        decision = json.loads(raw)
        return decision.get("command"), decision.get("reasoning"), token_data

    except subprocess.TimeoutExpired:
        click.echo("⚠️  Agent script timed out (120s)")
        return None, "Timeout", None
    except json.JSONDecodeError as e:
        click.echo(f"⚠️  Agent JSON parse error: {e}")
        return None, "Invalid Format", None


# =============================================================================
# FUNCIÓN PRINCIPAL
# =============================================================================

def run_play(session_id: str, prompt_file: str | None,
             strategy_file: str | None, local_url: str | None,
             agent_script: str | None):

    validate_env()

    # ── Validaciones de flags ─────────────────────────────────────────────────
    if agent_script and (local_url or prompt_file):
        click.echo("❌ --agent-script cannot be combined with --local-url or --prompt-file.", err=True)
        raise SystemExit(1)

    # ── Cargar archivos opcionales ────────────────────────────────────────────
    prompt_text   = _load_text_file(prompt_file,   "Prompt Injection", PROMPTS_DIR)    if prompt_file   else None
    strategy_text = _load_text_file(strategy_file, "Strategy",         STRATEGIES_DIR) if strategy_file else None
    prompt_hash   = hashlib.sha256(prompt_text.encode()).hexdigest() if prompt_text else None

    # ── Autenticación ─────────────────────────────────────────────────────────
    click.echo("\n🔐 Authenticating with iXentLabs...")
    jwt     = get_firebase_token()
    headers = {"X-Firebase-Token": jwt, "Content-Type": "application/json"}
    click.echo("✅ Login successful.")

    # ── Iniciar partida ───────────────────────────────────────────────────────
    click.echo(f"\n🎮 Validating session {session_id}...")
    resp = requests.post(f"{IXENT_SDK_URL}/play", headers=headers, json={
        "session_id":        session_id,
        "prompt_injection":  prompt_text,
        "prompt_hash":       prompt_hash,
        "agent_description": strategy_text,
        "is_local_model":    bool(local_url or agent_script),
        "is_custom_agent":   bool(agent_script),
    }, timeout=30)

    if not resp.ok:
        click.echo(f"❌ Server error: {resp.text}", err=True)
        raise SystemExit(1)

    game_data = resp.json()
    if not game_data.get("success"):
        click.echo(f"❌ {game_data.get('msg')}", err=True)
        raise SystemExit(1)

    game_player_id = game_data["game_player_id"]
    current_state  = game_data["state"]
    motor_url      = game_data["motor_url"]
    model_name     = game_data.get("model", "AI Agent")
    session_info   = game_data.get("session", {})
    system_prompt  = game_data.get("system_prompt", "")
    is_sponsored   = game_data.get("is_sponsored", False)
    max_turns      = current_state.get("meta", {}).get("max_moves", 200) + 20

    click.echo(f"✅ Game started — ID: {game_player_id}")
    click.echo(f"   Model: {model_name} | Level: {game_data.get('level', '?')}")
    if is_sponsored:
        click.echo("   💳 Mode: iXentLabs Sponsored")
    elif agent_script:
        click.echo(f"   🤖 Mode: Custom Agent ({agent_script})")
    elif local_url:
        click.echo(f"   💻 Mode: Local Model ({local_url})")
    else:
        click.echo(f"   🔑 Mode: BYOK ({session_info.get('provider', 'google').capitalize()})")

    # ── Abrir visualizador ────────────────────────────────────────────────────
    game_id = current_state.get("meta", {}).get("live_game_id", "")
    vis_url = f"{VISUALIZER_URL}?game_id={game_id}" if game_id else VISUALIZER_URL
    webbrowser.open(vis_url)
    click.echo(f"🌐 Visualizer: {vis_url}")

    # ── Acumuladores de sesión ────────────────────────────────────────────────
    s_tokens = s_input = s_output = s_thinking = s_secs = s_gen = 0

    # ── Game loop ─────────────────────────────────────────────────────────────
    click.echo("\n🚀 Game starting...\n")
    turn          = 0
    entropy_shown = False

    while turn < max_turns:
        turn += 1
        click.echo(f"\n🧠 [TURN {turn}] {model_name} thinking...")

        # Seleccionar motor
        if agent_script:
            cmd, reasoning, td = _get_move_agent(agent_script, current_state)
        elif local_url:
            cmd, reasoning, td = _get_move_local(model_name, system_prompt,
                                                  current_state, local_url)
        else:
            # BYOK o Sponsored — en sponsored el servidor devuelve la jugada
            cmd, reasoning, td = _get_move_byok(model_name, system_prompt,
                                                 current_state, session_info)

        if not cmd:
            click.echo("⚠️  No valid move. Retrying...")
            time.sleep(2)
            continue

        # Acumular métricas
        if td:
            s_tokens   += td["total"]
            s_input    += td.get("input_tokens", 0)
            s_output   += td.get("output_tokens", 0)
            s_thinking += td.get("thinking_tokens", 0)
            s_secs     += td.get("turn_inference_sec", 0)
            s_gen      += td.get("output_tokens", 0) + td.get("thinking_tokens", 0)

        avg_tps = round(s_gen / s_secs, 2) if s_secs > 0 else 0
        click.echo(f"   📊 Tokens: {td['total'] if td else 0} (Session: {s_tokens})")
        click.echo(f"   💭 {(reasoning or '—')[:120].rstrip()}{'…' if reasoning and len(reasoning) > 120 else ''}")
        click.echo(f"   ⚡ {cmd}")

        # Enviar jugada
        try:
            move_resp = requests.post(
                f"{IXENT_SDK_URL}/move",
                headers = headers,
                json    = {
                    "game_player_id": game_player_id,
                    "command":        cmd,
                    "reasoning":      reasoning,
                    "motor_url":      motor_url,
                    "token_usage": {
                        "total":                 s_tokens,
                        "total_input_tokens":    s_input,
                        "total_output_tokens":   s_output,
                        "total_thinking_tokens": s_thinking,
                        "total_inference_sec":   round(s_secs, 2),
                        "average_tps":           avg_tps,
                        "turn_input_tokens":     td.get("input_tokens", 0)     if td else 0,
                        "turn_output_tokens":    td.get("output_tokens", 0)    if td else 0,
                        "turn_thinking_tokens":  td.get("thinking_tokens", 0)  if td else 0,
                        "turn_inference_sec":    td.get("turn_inference_sec", 0) if td else 0,
                        "turn_tps":              td.get("turn_tps", 0)         if td else 0,
                        "is_local_hardware":     td.get("is_local_hardware", False) if td else False,
                    }
                },
                timeout = 610
            )
            move_resp.raise_for_status()
            data = move_resp.json()
        except Exception as e:
            click.echo(f"❌ Move error: {e}")
            time.sleep(2)
            continue

        if not data.get("success", True):
            click.echo(f"   🚫 REJECTED: {data.get('msg')}")
            time.sleep(2)
            continue

        click.echo("   👍 ACCEPTED")
        current_state = data.get("state", {})
        gym           = data.get("gym_metrics", {})

        # Detectar entropía
        if not entropy_shown:
            for entry in current_state.get("data", {}).get("history", []):
                if "[EVENT]" in str(entry):
                    click.echo(f"\n   ⚠️  ENTROPY EVENT: {entry}\n")
                    entropy_shown = True
                    break

        # Detectar fin de partida
        if (gym.get("terminated") or gym.get("truncated") or
                current_state.get("status", {}).get("game_over")):
            st     = current_state.get("status", {})
            result = st.get("result", "UNKNOWN")
            score  = current_state.get("scoring", {}).get("benchmark_score", {}).get("P1", 0)
            mice   = st.get("mice_rescued", {}).get("P1", 0)
            total  = st.get("total_mice_per_player", 0)
            click.echo(f"\n{'🏆' if result == 'VICTORY' else '💀'} GAME OVER: {result}")
            click.echo(f"   Score:   {score}")
            click.echo(f"   Mice:    {mice}/{total}")
            click.echo(f"   Turns:   {turn}")
            click.echo(f"   Tokens:  {s_tokens}")
            click.echo(f"   Time:    {round(s_secs, 1)}s")
            click.echo(f"   Avg TPS: {avg_tps}")
            break

    click.echo("\n✅ Session complete.")