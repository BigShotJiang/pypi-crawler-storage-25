"""
pashudhan_ai.models
~~~~~~~~~~~~~~~~~~~~
Response data classes. These are simple Python objects that wrap
the JSON returned by the Pashudhan API — no logic lives here.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Ingredient:
    name: str
    kg_fresh_day: float
    cost_inr_day: float
    dm_pct: Optional[float] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Ingredient":
        return cls(
            name=d.get("name", ""),
            kg_fresh_day=d.get("kg_fresh_day", 0.0),
            cost_inr_day=d.get("cost_INR_day", 0.0),
            dm_pct=d.get("dm_pct"),
        )


@dataclass
class Nutrients:
    nel_mcal_kg_dm: Optional[float] = None
    cp_pct_dm: Optional[float] = None
    ndf_pct_dm: Optional[float] = None
    ca_pct_dm: Optional[float] = None
    p_pct_dm: Optional[float] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Nutrients":
        return cls(
            nel_mcal_kg_dm=d.get("NEL_Mcal_kg_DM"),
            cp_pct_dm=d.get("CP_pct_DM"),
            ndf_pct_dm=d.get("NDF_pct_DM"),
            ca_pct_dm=d.get("Ca_pct_DM"),
            p_pct_dm=d.get("P_pct_DM"),
        )


@dataclass
class Palatability:
    score: Optional[int] = None
    refusal_probability_pct: Optional[float] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "Palatability":
        return cls(
            score=d.get("score") or d.get("palatability_score"),
            refusal_probability_pct=d.get("refusal_probability_pct"),
        )


@dataclass
class RationOption:
    mode: str
    rank: int
    total_cost_inr: float
    ingredients: List[Ingredient] = field(default_factory=list)
    nutrients: Optional[Nutrients] = None
    palatability: Optional[Palatability] = None
    ai_explanation: Optional[str] = None
    solver_status: Optional[str] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "RationOption":
        fm = d.get("formulation", {})
        return cls(
            mode=d.get("mode", ""),
            rank=d.get("rank", 99),
            total_cost_inr=d.get("total_cost_INR_day", 0.0),
            ingredients=[Ingredient._from_dict(i) for i in fm.get("ingredients", [])],
            nutrients=Nutrients._from_dict(fm.get("nutrient_summary", {})),
            palatability=Palatability._from_dict(fm.get("palatability", {})),
            ai_explanation=d.get("adaptive_reasoning") or d.get("ai_explanation"),
            solver_status=fm.get("solver_status")
        )


@dataclass
class THIReport:
    thi: Optional[float] = None
    category: Optional[str] = None
    adjusted_water_l_day: Optional[float] = None

    @classmethod
    def _from_dict(cls, d: dict) -> "THIReport":
        return cls(
            thi=d.get("thi"),
            category=d.get("category"),
            adjusted_water_l_day=d.get("adjusted_water_L_day") or d.get("thi_adjusted_water_L_day"),
        )


@dataclass
class FormulationResult:
    """
    Returned by client.formulate().
    Access ration strategies as attributes.
    """
    request_id: str
    confidence: str
    formulations: List[RationOption] = field(default_factory=list)
    thi_report: Optional[THIReport] = None

    @property
    def least_cost(self) -> Optional[RationOption]:
        return next((o for o in self.formulations if o.mode == "least_cost"), None)

    @property
    def best_biological(self) -> Optional[RationOption]:
        return next((o for o in self.formulations if o.mode == "best_biological"), None)

    @property
    def compromise(self) -> Optional[RationOption]:
        return next((o for o in self.formulations if o.mode == "compromise"), None)

    @property
    def risk_aware(self) -> Optional[RationOption]:
        return next((o for o in self.formulations if o.mode == "risk_aware"), None)

    @property
    def ai_explanation(self) -> Optional[str]:
        """Shortcut: AI explanation from the first available option."""
        for opt in self.formulations:
            if opt.ai_explanation:
                return opt.ai_explanation
        return None

    @classmethod
    def _from_dict(cls, d: dict) -> "FormulationResult":
        return cls(
            request_id=d.get("request_id", ""),
            confidence=d.get("confidence", "UNKNOWN"),
            formulations=[RationOption._from_dict(o) for o in d.get("formulations", [])],
            thi_report=THIReport._from_dict(d["thi_report"]) if d.get("thi_report") else None,
        )


@dataclass
class StatusResult:
    """Returned by client.status()."""
    plan: str
    calls_used: int
    calls_limit: int

    @property
    def calls_remaining(self) -> int:
        return max(0, self.calls_limit - self.calls_used)

    @classmethod
    def _from_dict(cls, d: dict) -> "StatusResult":
        det = d.get("details", {})
        return cls(
            plan=det.get("plan", "unknown"),
            calls_used=det.get("requests_used", 0),
            calls_limit=det.get("limit", 0),
        )
