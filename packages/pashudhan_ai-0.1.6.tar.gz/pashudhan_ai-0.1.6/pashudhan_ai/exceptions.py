"""
pashudhan_ai.exceptions
~~~~~~~~~~~~~~~~~~~~~~~
Custom exception classes. All business logic errors originate
from the Pashudhan backend and are surfaced here as typed exceptions.
"""


class PashudhanError(Exception):
    """Base exception for all pashudhan_ai errors."""
    def __init__(self, message: str, status_code: int = None):
        super().__init__(message)
        self.status_code = status_code


class AuthError(PashudhanError):
    """Raised when the API key is missing, invalid, or expired (HTTP 401/403)."""
    pass


class RateLimitError(PashudhanError):
    """Raised when the monthly API call limit is exceeded (HTTP 429)."""
    pass


class APIError(PashudhanError):
    """Raised for unexpected backend errors (HTTP 5xx)."""
    pass
