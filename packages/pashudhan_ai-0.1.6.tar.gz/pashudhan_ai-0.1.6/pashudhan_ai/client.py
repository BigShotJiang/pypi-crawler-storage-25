"""
pashudhan_ai.client
~~~~~~~~~~~~~~~~~~~~
The main HTTP client. This is the ONLY file that makes network calls.
It contains zero formulation logic — it simply sends your parameters
to the Pashudhan API and returns typed response objects.

All NASEM 2021 calculations, Linear Programming, AI critique, and
regional databases run exclusively on Pashudhan's secure Cloud Run backend.
"""

import os
import requests
from typing import Optional

from . import __version__

from .models import FormulationResult, StatusResult
from .exceptions import AuthError, RateLimitError, APIError, PashudhanError

# The live API endpoint — all logic runs here, not in this package
_BASE_URL = "https://pashudhan-nutri-ai.web.app"
_DEFAULT_TIMEOUT = 30  # seconds


class Client:
    """
    Pashudhan Nutri AI API client.

    Example::

        import pashudhan_ai

        client = pashudhan_ai.Client(api_key="pd_your_key_here")

        result = client.formulate(
            animal_type="cow",
            breed="HF_crossbred",
            body_weight_kg=450,
            milk_yield_kg_day=18,
            fat_pct=3.5,
            production_stage="lactating",
            state="Punjab",
            month=5,
        )

        print(result.least_cost.total_cost_inr)
        print(result.ai_explanation)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = _DEFAULT_TIMEOUT,
    ):
        """
        Args:
            api_key:  Your Pashudhan API key (starts with ``pd_``).
                      If not provided, reads from the ``PASHUDHAN_API_KEY``
                      environment variable.
            base_url: Override the API base URL (useful for testing).
            timeout:  Request timeout in seconds (default: 30).
        """
        self._api_key = api_key or os.environ.get("PASHUDHAN_API_KEY", "")
        if not self._api_key:
            raise AuthError(
                "No API key provided. Pass api_key='pd_...' or set the "
                "PASHUDHAN_API_KEY environment variable. "
                "Get your key at https://pashudhan-nutri-ai.web.app/apikeys"
            )
        self._base_url = (base_url or _BASE_URL).rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "x-api-key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": f"pashudhan_ai-python/{__version__}",
        })

    # ── Public API ────────────────────────────────────────────────────────────

    def formulate(
        self,
        animal_type: str,
        breed: str,
        body_weight_kg: float,
        milk_yield_kg_day: float,
        fat_pct: float,
        production_stage: str,
        state: str,
        month: int,
        use_ai: bool = False,
        location: Optional[str] = None,
    ) -> FormulationResult:
        """
        Generate an optimised dairy ration.

        All computation runs on Pashudhan's secure backend using
        NASEM 2021 standards and Linear Programming.

        Args:
            animal_type:       ``"cow"`` | ``"buffalo"`` | ``"heifer"`` | ``"bull"``
            breed:             e.g. ``"HF_crossbred"``, ``"Sahiwal"``, ``"Murrah"``
            body_weight_kg:    Live body weight in kg.
            milk_yield_kg_day: Daily milk production in kg.
            fat_pct:           Milk fat percentage (e.g. ``3.5``).
            production_stage:  ``"mid_lactation"`` | ``"early_lactation"`` | ``"late_lactation"``
                               | ``"fresh"`` | ``"far_off_dry"`` | ``"close_up_dry"``
                               | ``"pre_calving"`` | ``"growing"``
            state:             Indian state name (e.g. ``"Punjab"``, ``"Gujarat"``).
            month:             Month number 1–12 for seasonal ingredient availability.
            use_ai:            Enable AI Nutritionist critique layer (Pro/ProMax only).
            location:          City name or ``"lat,lon"`` for live THI heat-stress data.

        Returns:
            :class:`~pashudhan_ai.models.FormulationResult` with ration options.

        Raises:
            :exc:`~pashudhan_ai.exceptions.AuthError`:       Invalid or missing API key.
            :exc:`~pashudhan_ai.exceptions.RateLimitError`:  Monthly call limit exceeded.
            :exc:`~pashudhan_ai.exceptions.APIError`:        Unexpected backend error.
        """
        # Map user-friendly production_stage to server's dim/milk parameters
        _stage_dim_map = {
            "lactating":        120,
            "early_lactation":   50,
            "mid_lactation":    120,
            "late_lactation":   210,
            "fresh":             10,
            "dry":                0,
            "far_off_dry":        0,
            "close_up_dry":       0,
            "pre_calving":        0,
            "growing":            0,
        }
        dim = _stage_dim_map.get(production_stage, 120)

        animal: dict = {
            "animal_type":        animal_type,
            "breed":              breed,
            "body_weight_kg":     body_weight_kg,
            "milk_yield_kg_day":  milk_yield_kg_day,
            "milk_fat_pct":       fat_pct,
            "dim":                dim,
        }
        if production_stage in ("dry", "far_off_dry", "close_up_dry", "pre_calving"):
            animal["milk_yield_kg_day"] = 0.0
        if production_stage == "close_up_dry":
            animal["days_pregnant"] = 255
        if production_stage == "pre_calving":
            animal["days_pregnant"] = 260
        if location:
            animal["location"] = location

        payload = {
            "animal": animal,
            "state":  state,
            "month":  month,
            "use_ai": use_ai,
        }

        data = self._post("/api/formulate", payload)
        return FormulationResult._from_dict(data)

    def status(self) -> StatusResult:
        """
        Fetch your current plan and monthly API usage.

        Returns:
            :class:`~pashudhan_ai.models.StatusResult`
        """
        data = self._get("/api/enterprise/status")
        return StatusResult._from_dict(data)

    def plans(self) -> dict:
        """
        List all available subscription plans (no auth required).

        Returns:
            Raw dict from the ``/api/plans`` endpoint.
        """
        return self._get("/api/plans")

    # ── Private HTTP helpers ──────────────────────────────────────────────────

    def _post(self, path: str, payload: dict) -> dict:
        url = self._base_url + path
        try:
            resp = self._session.post(url, json=payload, timeout=self._timeout)
        except requests.exceptions.ConnectionError as e:
            raise APIError(f"Connection failed: {e}")
        except requests.exceptions.Timeout:
            raise APIError(f"Request timed out after {self._timeout}s.")
        return self._handle_response(resp)

    def _get(self, path: str) -> dict:
        url = self._base_url + path
        try:
            resp = self._session.get(url, timeout=self._timeout)
        except requests.exceptions.ConnectionError as e:
            raise APIError(f"Connection failed: {e}")
        except requests.exceptions.Timeout:
            raise APIError(f"Request timed out after {self._timeout}s.")
        return self._handle_response(resp)

    @staticmethod
    def _handle_response(resp: requests.Response) -> dict:
        if resp.status_code == 401:
            raise AuthError("Invalid or expired API key.", status_code=401)
        if resp.status_code == 403:
            raise AuthError(f"Access denied. Ensure you have an Enterprise account. Backend returned: {resp.text[:200]}", status_code=403)
        if resp.status_code == 429:
            raise RateLimitError(
                "Monthly API call limit reached. Upgrade your plan at "
                "https://pashudhan-nutri-ai.web.app/apikeys",
                status_code=429,
            )
        if resp.status_code >= 500:
            raise APIError(f"Pashudhan API error ({resp.status_code}): {resp.text[:200]}", status_code=resp.status_code)
        if not resp.ok:
            try:
                detail = resp.json().get("detail", resp.text[:200])
            except Exception:
                detail = resp.text[:200]
            raise PashudhanError(f"API error ({resp.status_code}): {detail}", status_code=resp.status_code)
        return resp.json()
