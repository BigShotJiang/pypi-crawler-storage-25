"""
pashudhan_ai — Official Python SDK for the Pashudhan Nutri AI API
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A thin HTTP wrapper. All formulation logic runs securely on
Pashudhan's Cloud Run backend — nothing is exposed in this package.

Usage:
    import pashudhan_ai
    client = pashudhan_ai.Client(api_key="pd_your_key_here")
    result = client.formulate(animal_type="cow", breed="HF_crossbred", ...)
    print(result.least_cost.total_cost_inr)
"""

__version__ = "0.1.6"

from .client import Client
from .exceptions import PashudhanError, AuthError, RateLimitError, APIError

__all__ = ["Client", "PashudhanError", "AuthError", "RateLimitError", "APIError"]
