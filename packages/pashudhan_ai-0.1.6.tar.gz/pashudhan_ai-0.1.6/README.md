# Pashudhan Nutri AI — Official Python SDK

The official Python client library for the [Pashudhan Nutri AI API](https://pashudhan-nutri-ai.web.app/enterprise). 

This SDK provides a clean, typed interface to generate NASEM 2021 compliant dairy rations using Linear Programming. **Zero formulation logic is exposed** — all equations, ingredient databases, and AI models run securely on our backend.

## Installation

```bash
pip install pashudhan_ai
```

## Quickstart

```python
import pashudhan_ai

# Initialize the client with your API key
client = pashudhan_ai.Client(api_key="pd_your_api_key_here")

# Generate a ration
result = client.formulate(
    animal_type="cow",
    breed="HF_crossbred",
    body_weight_kg=450,
    milk_yield_kg_day=18,
    fat_pct=3.5,
    production_stage="lactating",
    state="Punjab",
    month=5
)

# Access the least cost option
print(f"Total Cost: ₹{result.least_cost.total_cost_inr}/day")

for ingredient in result.least_cost.ingredients:
    print(f"{ingredient.name}: {ingredient.kg_fresh_day} kg")
```

## Features
- **Fully Typed:** Data models for all API responses.
- **Secure:** Only acts as a wrapper for HTTP requests.
- **Lightweight:** Only relies on `requests`.

## Documentation
For full API reference, visit the [Developer Portal](https://pashudhan-nutri-ai.web.app/enterprise).
