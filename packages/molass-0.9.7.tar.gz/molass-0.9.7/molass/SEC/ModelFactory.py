"""
SEC.ModelFactory.py
"""
from importlib import reload

def create_model(model_name, **kwargs):
    """
    Create a model based on the model name.

    Parameters
    ----------
    model_name : str
        The name of the model to create.
    kwargs : dict
        Additional parameters to pass to the model constructor.
        
    Returns
    -------
    model : object
        The created model object.
    """
    debug = kwargs.get('debug', False)
    model_name = model_name.lower()
    if model_name == 'sdm':
        if debug:
            import molass.SEC.Models.SDM
            reload(molass.SEC.Models.SDM)
        from molass.SEC.Models.SDM import SDM
        return SDM(**kwargs)
    elif model_name in ('edm', 'cedm'):
        if debug:
            import molass.SEC.Models.EDM
            reload(molass.SEC.Models.EDM)   
        from molass.SEC.Models.EDM import EDM
        if model_name == 'cedm':
            kwargs.setdefault('shared_column', True)
        return EDM(**kwargs)
    elif model_name == 'lkm':
        if debug:
            import molass.SEC.Models.LKM
            reload(molass.SEC.Models.LKM)
        from molass.SEC.Models.LKM import LKM
        return LKM(**kwargs)
    else:
        raise ValueError(f"Unknown model name: {model_name}")