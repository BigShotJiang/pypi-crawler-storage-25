"""
Tests for pguard core functionality.
Run: pytest tests/ -v
"""
import pytest
import tempfile
import os
from pguard import Prompt
from pguard.models import PromptVersion, RunResult
from pguard.metrics import calc_cost, calc_quality_score
from pguard.comparator import compare


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def prompt_file(tmp_dir):
    return Prompt("test_prompt", storage="file", storage_path=tmp_dir)


@pytest.fixture
def prompt_sqlite(tmp_dir):
    db_path = os.path.join(tmp_dir, "test.db")
    p = Prompt("test_prompt", storage="sqlite", storage_path=db_path)
    yield p
    # Explicitly close SQLite connections before Windows cleanup
    import gc
    gc.collect()


# ── Version Management ────────────────────────────────────────────────────────

class TestVersionManagement:

    def test_save_and_get_version(self, prompt_file):
        prompt_file.save("v1", "Summarize: {text}", description="Initial version")
        v = prompt_file.get("v1")
        assert v.tag == "v1"
        assert v.template == "Summarize: {text}"
        assert v.description == "Initial version"

    def test_list_versions(self, prompt_file):
        prompt_file.save("v1", "Prompt v1")
        prompt_file.save("v2", "Prompt v2")
        versions = prompt_file.versions()
        assert len(versions) == 2
        tags = [v.tag for v in versions]
        assert "v1" in tags
        assert "v2" in tags

    def test_get_nonexistent_version_raises(self, prompt_file):
        with pytest.raises(KeyError):
            prompt_file.get("nonexistent")

    def test_render_template(self, prompt_file):
        prompt_file.save("v1", "Hello {name}, you are {age} years old.")
        rendered = prompt_file.render("v1", name="Ebad", age=25)
        assert rendered == "Hello Ebad, you are 25 years old."

    def test_render_missing_variable_raises(self, prompt_file):
        prompt_file.save("v1", "Hello {name}")
        with pytest.raises(ValueError):
            prompt_file.render("v1")  # missing 'name'

    def test_sqlite_backend(self, prompt_sqlite):
        prompt_sqlite.save("v1", "SQLite test: {text}")
        v = prompt_sqlite.get("v1")
        assert v.tag == "v1"
        assert v.template == "SQLite test: {text}"

    def test_overwrite_version(self, prompt_file):
        prompt_file.save("v1", "Original")
        prompt_file.save("v1", "Updated")
        v = prompt_file.get("v1")
        assert v.template == "Updated"


# ── Metrics ───────────────────────────────────────────────────────────────────

class TestMetrics:

    def test_calc_cost_known_model(self):
        cost = calc_cost("gpt-4o", tokens_in=1000, tokens_out=500)
        # 1000/1000 * 0.0025 + 500/1000 * 0.010 = 0.0025 + 0.005 = 0.0075
        assert abs(cost - 0.0075) < 0.0001

    def test_calc_cost_unknown_model_uses_default(self):
        cost = calc_cost("some-unknown-model", tokens_in=1000, tokens_out=1000)
        assert cost > 0

    def test_calc_cost_zero_tokens(self):
        assert calc_cost("gpt-4o", 0, 0) == 0.0

    def test_quality_score_empty_output(self):
        assert calc_quality_score("") == 0.0
        assert calc_quality_score("   ") == 0.0

    def test_quality_score_no_expected(self):
        score = calc_quality_score("This is a good output.")
        assert 0.0 <= score <= 1.0

    def test_quality_score_with_expected(self):
        score = calc_quality_score(
            output="The cat sat on the mat",
            expected="The cat sat on the mat"
        )
        assert score > 0.8

    def test_quality_score_wrong_output(self):
        score = calc_quality_score(
            output="completely different text",
            expected="The cat sat on the mat"
        )
        assert score < 0.5


# ── Comparator ────────────────────────────────────────────────────────────────

class TestComparator:

    def _make_run(self, version_tag, latency, cost, quality, tokens=100):
        return RunResult(
            prompt_name="test",
            version_tag=version_tag,
            input_vars={},
            rendered_prompt="test",
            output="test output",
            provider="openai",
            model="gpt-4o",
            tokens_in=tokens,
            tokens_out=tokens,
            cost_usd=cost,
            latency_ms=latency,
            quality_score=quality,
        )

    def test_compare_finds_faster_version(self):
        runs_a = [self._make_run("v1", latency=1000, cost=0.01, quality=0.8)]
        runs_b = [self._make_run("v2", latency=500, cost=0.01, quality=0.8)]
        result = compare("test", "v1", "v2", runs_a, runs_b)
        assert result.faster == "v2"

    def test_compare_finds_cheaper_version(self):
        runs_a = [self._make_run("v1", latency=500, cost=0.01, quality=0.8)]
        runs_b = [self._make_run("v2", latency=500, cost=0.001, quality=0.8)]
        result = compare("test", "v1", "v2", runs_a, runs_b)
        assert result.cheaper == "v2"

    def test_compare_finds_better_quality(self):
        runs_a = [self._make_run("v1", latency=500, cost=0.01, quality=0.6)]
        runs_b = [self._make_run("v2", latency=500, cost=0.01, quality=0.9)]
        result = compare("test", "v1", "v2", runs_a, runs_b)
        assert result.better_quality == "v2"

    def test_compare_summary_structure(self):
        runs_a = [self._make_run("v1", latency=1000, cost=0.01, quality=0.8)]
        runs_b = [self._make_run("v2", latency=500, cost=0.005, quality=0.9)]
        result = compare("test", "v1", "v2", runs_a, runs_b)
        summary = result.summary()
        assert "latency_ms" in summary
        assert "cost_usd" in summary
        assert "quality_score" in summary
        assert "tokens_avg" in summary

    def test_compare_no_runs_raises(self, prompt_file):
        prompt_file.save("v1", "Prompt v1")
        prompt_file.save("v2", "Prompt v2")
        with pytest.raises(ValueError):
            prompt_file.compare("v1", "v2")


# ── Run Persistence ───────────────────────────────────────────────────────────

class TestRunPersistence:

    def test_save_and_retrieve_run(self, prompt_file):
        from pguard.storage.file_storage import FileStorage
        import tempfile

        with tempfile.TemporaryDirectory() as d:
            storage = FileStorage(d)
            run = RunResult(
                prompt_name="test",
                version_tag="v1",
                input_vars={"text": "hello"},
                rendered_prompt="Summarize: hello",
                output="Summary here",
                provider="openai",
                model="gpt-4o",
                tokens_in=10,
                tokens_out=5,
                cost_usd=0.0001,
                latency_ms=300.0,
                quality_score=0.85,
            )
            storage.save_run(run)
            runs = storage.get_runs("test", "v1")
            assert len(runs) == 1
            assert runs[0].output == "Summary here"
            assert runs[0].tokens_in == 10