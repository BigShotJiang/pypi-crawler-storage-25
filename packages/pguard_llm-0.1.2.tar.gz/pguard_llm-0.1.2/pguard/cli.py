"""
pguard CLI — manage and compare prompts from the terminal.

Commands:
    pguard list                          # list all prompts
    pguard versions <prompt>             # list versions of a prompt
    pguard show <prompt> <version>       # show prompt template
    pguard runs <prompt> <version>       # show run history
    pguard compare <prompt> <v1> <v2>    # compare two versions
"""
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

from .storage.file_storage import FileStorage
from .storage.sqlite_storage import SQLiteStorage
from .comparator import compare

console = Console()


def _get_storage(sqlite: bool, path: str | None):
    if sqlite:
        return SQLiteStorage(path or ".pguard/pguard.db")
    return FileStorage(path or ".pguard")


@click.group()
@click.option("--sqlite", is_flag=True, default=False, help="Use SQLite backend")
@click.option("--path", default=None, help="Custom storage path")
@click.pass_context
def cli(ctx, sqlite, path):
    """🔮 pguard — Prompt version control and A/B testing"""
    ctx.ensure_object(dict)
    ctx.obj["storage"] = _get_storage(sqlite, path)


@cli.command("list")
@click.pass_context
def list_prompts(ctx):
    """List all prompts."""
    storage = ctx.obj["storage"]
    prompts = storage.list_prompts()

    if not prompts:
        console.print("[yellow]No prompts found. Save one first.[/yellow]")
        return

    table = Table(title="📝 Prompts", box=box.ROUNDED)
    table.add_column("Name", style="cyan")
    table.add_column("Versions", style="green")
    table.add_column("Total Runs", style="magenta")

    for name in prompts:
        versions = storage.list_versions(name)
        total_runs = sum(len(storage.get_runs(name, v.tag)) for v in versions)
        table.add_row(name, str(len(versions)), str(total_runs))

    console.print(table)


@cli.command("versions")
@click.argument("prompt_name")
@click.pass_context
def list_versions(ctx, prompt_name):
    """List all versions of a prompt."""
    storage = ctx.obj["storage"]
    versions = storage.list_versions(prompt_name)

    if not versions:
        console.print(f"[yellow]No versions found for '{prompt_name}'.[/yellow]")
        return

    table = Table(title=f"📌 Versions — {prompt_name}", box=box.ROUNDED)
    table.add_column("Tag", style="cyan bold")
    table.add_column("Description", style="white")
    table.add_column("Runs", style="magenta")
    table.add_column("Created", style="dim")

    for v in versions:
        runs = storage.get_runs(prompt_name, v.tag)
        table.add_row(
            v.tag,
            v.description or "—",
            str(len(runs)),
            v.created_at[:19],
        )

    console.print(table)


@cli.command("show")
@click.argument("prompt_name")
@click.argument("version_tag")
@click.pass_context
def show_version(ctx, prompt_name, version_tag):
    """Show a prompt version template."""
    storage = ctx.obj["storage"]
    version = storage.get_version(prompt_name, version_tag)

    if not version:
        console.print(f"[red]Version '{version_tag}' not found for '{prompt_name}'.[/red]")
        return

    console.print(Panel(
        version.template,
        title=f"[cyan]{prompt_name}[/cyan] / [green]{version.tag}[/green]",
        subtitle=f"[dim]{version.description or 'No description'}[/dim]",
        border_style="blue",
    ))


@cli.command("runs")
@click.argument("prompt_name")
@click.argument("version_tag")
@click.pass_context
def show_runs(ctx, prompt_name, version_tag):
    """Show run history for a prompt version."""
    storage = ctx.obj["storage"]
    runs = storage.get_runs(prompt_name, version_tag)

    if not runs:
        console.print(f"[yellow]No runs found for '{prompt_name}' / '{version_tag}'.[/yellow]")
        return

    table = Table(title=f"🏃 Runs — {prompt_name} / {version_tag}", box=box.ROUNDED)
    table.add_column("Run ID", style="dim", width=16)
    table.add_column("Provider", style="cyan")
    table.add_column("Model", style="cyan")
    table.add_column("Latency", style="yellow")
    table.add_column("Cost", style="green")
    table.add_column("Tokens", style="magenta")
    table.add_column("Quality", style="blue")
    table.add_column("Status", style="white")

    for r in runs:
        quality = f"{r.quality_score:.2f}" if r.quality_score is not None else "—"
        status = "✅" if not r.error else f"❌ {r.error[:30]}"
        table.add_row(
            r.run_id[-12:],
            r.provider,
            r.model,
            f"{r.latency_ms:.0f}ms",
            f"${r.cost_usd:.6f}",
            str(r.tokens_in + r.tokens_out),
            quality,
            status,
        )

    console.print(table)


@cli.command("compare")
@click.argument("prompt_name")
@click.argument("version_a")
@click.argument("version_b")
@click.pass_context
def compare_versions(ctx, prompt_name, version_a, version_b):
    """Compare two prompt versions side by side."""
    storage = ctx.obj["storage"]

    runs_a = storage.get_runs(prompt_name, version_a)
    runs_b = storage.get_runs(prompt_name, version_b)

    if not runs_a:
        console.print(f"[red]No runs for '{version_a}'. Run it first.[/red]")
        return
    if not runs_b:
        console.print(f"[red]No runs for '{version_b}'. Run it first.[/red]")
        return

    result = compare(prompt_name, version_a, version_b, runs_a, runs_b)
    s = result.summary()

    # ── Header ──
    console.print(f"\n[bold]🔬 Comparison: [cyan]{prompt_name}[/cyan] — [green]{version_a}[/green] vs [yellow]{version_b}[/yellow][/bold]\n")

    # ── Metrics Table ──
    table = Table(box=box.ROUNDED, show_header=True)
    table.add_column("Metric", style="bold white")
    table.add_column(version_a, style="green", justify="right")
    table.add_column(version_b, style="yellow", justify="right")
    table.add_column("Delta", style="dim", justify="right")
    table.add_column("Winner", style="cyan bold", justify="center")

    # Latency
    lat = s["latency_ms"]
    lat_delta = f"{lat['delta_pct']:+.1f}%"
    table.add_row(
        "⚡ Avg Latency",
        f"{lat[version_a]:.0f}ms",
        f"{lat[version_b]:.0f}ms",
        lat_delta,
        f"🏆 {lat['winner']}",
    )

    # Cost
    cost = s["cost_usd"]
    cost_delta = f"{cost['delta_pct']:+.1f}%"
    table.add_row(
        "💰 Avg Cost",
        f"${cost[version_a]:.6f}",
        f"${cost[version_b]:.6f}",
        cost_delta,
        f"🏆 {cost['winner']}",
    )

    # Quality
    qual = s["quality_score"]
    q_a = f"{qual[version_a]:.3f}" if qual[version_a] is not None else "—"
    q_b = f"{qual[version_b]:.3f}" if qual[version_b] is not None else "—"
    q_delta = f"{qual['delta']:+.3f}" if qual["delta"] is not None else "—"
    q_winner = f"🏆 {qual['winner']}" if qual["winner"] else "—"
    table.add_row("⭐ Avg Quality", q_a, q_b, q_delta, q_winner)

    # Tokens
    tok = s["tokens_avg"]
    table.add_row(
        "🔢 Avg Tokens",
        f"{tok[version_a]:.0f}",
        f"{tok[version_b]:.0f}",
        "—", "—",
    )

    # Runs
    runs = s["runs"]
    table.add_row("📊 Runs", str(runs["a"]), str(runs["b"]), "—", "—")

    console.print(table)
    console.print()


def main():
    cli()


if __name__ == "__main__":
    main()
