"""
Core Prompt class — the main interface for users.
"""
from typing import Optional, Literal
from .models import PromptVersion, RunResult
from .storage.base import BaseStorage
from .storage.file_storage import FileStorage
from .storage.sqlite_storage import SQLiteStorage
from .runner import run_prompt
from .comparator import compare, ComparisonResult


StorageBackend = Literal["file", "sqlite"]


class Prompt:
    """
    Manage, version, run, and compare prompts.

    Example:
        p = Prompt("summarize")
        p.save("v1", "Summarize this: {text}")
        p.save("v2", "In 3 bullet points, summarize: {text}")

        result = p.run("v1", provider="openai", model="gpt-4o",
                       api_key="sk-...", input_vars={"text": "..."})

        comparison = p.compare("v1", "v2")
        comparison.summary()
    """

    def __init__(
        self,
        name: str,
        storage: StorageBackend = "file",
        storage_path: str | None = None,
    ):
        self.name = name
        self._storage: BaseStorage = self._init_storage(storage, storage_path)

    # ── Version Management ────────────────────────────────────────────────────

    def save(
        self,
        tag: str,
        template: str,
        description: str = "",
        metadata: dict | None = None,
    ) -> PromptVersion:
        """
        Save a new version of this prompt.

        Args:
            tag:         Version identifier (e.g. "v1", "prod", "experiment-A")
            template:    Prompt text. Use {variable} for dynamic parts.
            description: What changed in this version.
            metadata:    Any extra data to store with this version.
        """
        version = PromptVersion(
            tag=tag,
            template=template,
            description=description,
            metadata=metadata or {},
        )
        self._storage.save_version(self.name, version)
        return version

    def get(self, tag: str) -> PromptVersion:
        """Retrieve a specific version."""
        version = self._storage.get_version(self.name, tag)
        if version is None:
            raise KeyError(f"Version '{tag}' not found for prompt '{self.name}'.")
        return version

    def versions(self) -> list[PromptVersion]:
        """List all versions of this prompt."""
        return self._storage.list_versions(self.name)

    def render(self, tag: str, **kwargs) -> str:
        """Render a version with given variables (no LLM call)."""
        return self.get(tag).render(**kwargs)

    # ── Running ───────────────────────────────────────────────────────────────

    def run(
        self,
        tag: str,
        provider: str,
        model: str,
        api_key: str,
        input_vars: dict | None = None,
        expected_output: str | None = None,
        save_run: bool = True,
        **provider_kwargs,
    ) -> RunResult:
        """
        Run a prompt version against an LLM.

        Args:
            tag:             Version tag to run.
            provider:        "openai" | "anthropic" | "gemini"
            model:           Model name.
            api_key:         API key for the provider.
            input_vars:      Variables to fill into the prompt template.
            expected_output: Ground truth for quality scoring.
            save_run:        Whether to persist this run.
            **provider_kwargs: Extra args for the provider (temperature, etc.)

        Returns:
            RunResult with output, tokens, cost, latency, quality_score.
        """
        version = self.get(tag)
        result = run_prompt(
            prompt_name=self.name,
            version=version,
            provider=provider,
            model=model,
            api_key=api_key,
            input_vars=input_vars,
            expected_output=expected_output,
            **provider_kwargs,
        )
        if save_run:
            self._storage.save_run(result)
        return result

    def runs(self, tag: str) -> list[RunResult]:
        """Get all saved runs for a version."""
        return self._storage.get_runs(self.name, tag)

    # ── Comparison ────────────────────────────────────────────────────────────

    def compare(self, tag_a: str, tag_b: str) -> ComparisonResult:
        """
        Compare two versions based on their saved runs.

        Returns a ComparisonResult with latency, cost, quality, and token metrics.
        Both versions must have at least one saved run.
        """
        runs_a = self._storage.get_runs(self.name, tag_a)
        runs_b = self._storage.get_runs(self.name, tag_b)

        if not runs_a:
            raise ValueError(f"No runs found for version '{tag_a}'. Run it first.")
        if not runs_b:
            raise ValueError(f"No runs found for version '{tag_b}'. Run it first.")

        return compare(self.name, tag_a, tag_b, runs_a, runs_b)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _init_storage(self, backend: StorageBackend, path: str | None) -> BaseStorage:
        if backend == "sqlite":
            return SQLiteStorage(path or ".pguard/pguard.db")
        return FileStorage(path or ".pguard")

    def __repr__(self) -> str:
        versions = self._storage.list_versions(self.name)
        return f"<Prompt name='{self.name}' versions={[v.tag for v in versions]}>"
