"""
A/B comparison engine — compares two prompt versions across metrics.
"""
from dataclasses import dataclass
from typing import Optional
from .models import RunResult


@dataclass
class ComparisonResult:
    prompt_name: str
    version_a: str
    version_b: str

    # Averages across all runs
    avg_latency_a: float
    avg_latency_b: float
    avg_cost_a: float
    avg_cost_b: float
    avg_quality_a: Optional[float]
    avg_quality_b: Optional[float]
    avg_tokens_a: float
    avg_tokens_b: float

    run_count_a: int
    run_count_b: int

    @property
    def faster(self) -> str:
        return self.version_a if self.avg_latency_a < self.avg_latency_b else self.version_b

    @property
    def cheaper(self) -> str:
        return self.version_a if self.avg_cost_a < self.avg_cost_b else self.version_b

    @property
    def better_quality(self) -> Optional[str]:
        if self.avg_quality_a is None or self.avg_quality_b is None:
            return None
        return self.version_a if self.avg_quality_a >= self.avg_quality_b else self.version_b

    @property
    def latency_delta_pct(self) -> float:
        """How much faster/slower B is vs A (%)"""
        if self.avg_latency_a == 0:
            return 0.0
        return round(((self.avg_latency_b - self.avg_latency_a) / self.avg_latency_a) * 100, 2)

    @property
    def cost_delta_pct(self) -> float:
        if self.avg_cost_a == 0:
            return 0.0
        return round(((self.avg_cost_b - self.avg_cost_a) / self.avg_cost_a) * 100, 2)

    @property
    def quality_delta(self) -> Optional[float]:
        if self.avg_quality_a is None or self.avg_quality_b is None:
            return None
        return round(self.avg_quality_b - self.avg_quality_a, 4)

    def summary(self) -> dict:
        return {
            "prompt": self.prompt_name,
            "versions": f"{self.version_a} vs {self.version_b}",
            "runs": {"a": self.run_count_a, "b": self.run_count_b},
            "latency_ms": {
                self.version_a: self.avg_latency_a,
                self.version_b: self.avg_latency_b,
                "delta_pct": self.latency_delta_pct,
                "winner": self.faster,
            },
            "cost_usd": {
                self.version_a: self.avg_cost_a,
                self.version_b: self.avg_cost_b,
                "delta_pct": self.cost_delta_pct,
                "winner": self.cheaper,
            },
            "quality_score": {
                self.version_a: self.avg_quality_a,
                self.version_b: self.avg_quality_b,
                "delta": self.quality_delta,
                "winner": self.better_quality,
            },
            "tokens_avg": {
                self.version_a: self.avg_tokens_a,
                self.version_b: self.avg_tokens_b,
            },
        }


def compare(
    prompt_name: str,
    version_a: str,
    version_b: str,
    runs_a: list[RunResult],
    runs_b: list[RunResult],
) -> ComparisonResult:
    """
    Compare two sets of runs and return a ComparisonResult.
    """

    def avg(values: list[float]) -> float:
        return round(sum(values) / len(values), 6) if values else 0.0

    def avg_optional(values: list[Optional[float]]) -> Optional[float]:
        filtered = [v for v in values if v is not None]
        return round(sum(filtered) / len(filtered), 4) if filtered else None

    successful_a = [r for r in runs_a if not r.error]
    successful_b = [r for r in runs_b if not r.error]

    return ComparisonResult(
        prompt_name=prompt_name,
        version_a=version_a,
        version_b=version_b,
        avg_latency_a=avg([r.latency_ms for r in successful_a]),
        avg_latency_b=avg([r.latency_ms for r in successful_b]),
        avg_cost_a=avg([r.cost_usd for r in successful_a]),
        avg_cost_b=avg([r.cost_usd for r in successful_b]),
        avg_quality_a=avg_optional([r.quality_score for r in successful_a]),
        avg_quality_b=avg_optional([r.quality_score for r in successful_b]),
        avg_tokens_a=avg([r.tokens_in + r.tokens_out for r in successful_a]),
        avg_tokens_b=avg([r.tokens_in + r.tokens_out for r in successful_b]),
        run_count_a=len(runs_a),
        run_count_b=len(runs_b),
    )
