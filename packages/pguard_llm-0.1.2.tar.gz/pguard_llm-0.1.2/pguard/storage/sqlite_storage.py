import sqlite3
import json
from typing import Optional
from .base import BaseStorage
from ..models import PromptVersion, RunResult


class SQLiteStorage(BaseStorage):
    """
    Stores prompts and runs in a SQLite database.
    Better for querying, filtering, and larger datasets.
    """

    def __init__(self, db_path: str = ".pguard/pguard.db"):
        import os
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def close(self) -> None:
        """Explicitly close any open connections (important on Windows)."""
        pass  # connections are closed per-operation via context manager

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS prompt_versions (
                    prompt_name TEXT NOT NULL,
                    tag TEXT NOT NULL,
                    template TEXT NOT NULL,
                    description TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    metadata TEXT DEFAULT '{}',
                    PRIMARY KEY (prompt_name, tag)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    prompt_name TEXT NOT NULL,
                    version_tag TEXT NOT NULL,
                    input_vars TEXT NOT NULL,
                    rendered_prompt TEXT NOT NULL,
                    output TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    tokens_in INTEGER DEFAULT 0,
                    tokens_out INTEGER DEFAULT 0,
                    cost_usd REAL DEFAULT 0.0,
                    latency_ms REAL DEFAULT 0.0,
                    quality_score REAL,
                    timestamp TEXT NOT NULL,
                    error TEXT
                )
            """)
            conn.commit()

    # ── Prompt Versions ──────────────────────────────────────────────────────

    def save_version(self, prompt_name: str, version: PromptVersion) -> None:
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO prompt_versions
                (prompt_name, tag, template, description, created_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                prompt_name,
                version.tag,
                version.template,
                version.description,
                version.created_at,
                json.dumps(version.metadata),
            ))
            conn.commit()

    def get_version(self, prompt_name: str, version_tag: str) -> Optional[PromptVersion]:
        with self._conn() as conn:
            row = conn.execute("""
                SELECT * FROM prompt_versions
                WHERE prompt_name = ? AND tag = ?
            """, (prompt_name, version_tag)).fetchone()
        if not row:
            return None
        return PromptVersion(
            tag=row["tag"],
            template=row["template"],
            description=row["description"],
            created_at=row["created_at"],
            metadata=json.loads(row["metadata"]),
        )

    def list_versions(self, prompt_name: str) -> list[PromptVersion]:
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT * FROM prompt_versions
                WHERE prompt_name = ?
                ORDER BY created_at ASC
            """, (prompt_name,)).fetchall()
        return [
            PromptVersion(
                tag=r["tag"],
                template=r["template"],
                description=r["description"],
                created_at=r["created_at"],
                metadata=json.loads(r["metadata"]),
            )
            for r in rows
        ]

    # ── Runs ─────────────────────────────────────────────────────────────────

    def save_run(self, run: RunResult) -> None:
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO runs
                (run_id, prompt_name, version_tag, input_vars, rendered_prompt,
                 output, provider, model, tokens_in, tokens_out, cost_usd,
                 latency_ms, quality_score, timestamp, error)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                run.run_id,
                run.prompt_name,
                run.version_tag,
                json.dumps(run.input_vars),
                run.rendered_prompt,
                run.output,
                run.provider,
                run.model,
                run.tokens_in,
                run.tokens_out,
                run.cost_usd,
                run.latency_ms,
                run.quality_score,
                run.timestamp,
                run.error,
            ))
            conn.commit()

    def get_runs(self, prompt_name: str, version_tag: str) -> list[RunResult]:
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT * FROM runs
                WHERE prompt_name = ? AND version_tag = ?
                ORDER BY timestamp ASC
            """, (prompt_name, version_tag)).fetchall()
        return [
            RunResult(
                run_id=r["run_id"],
                prompt_name=r["prompt_name"],
                version_tag=r["version_tag"],
                input_vars=json.loads(r["input_vars"]),
                rendered_prompt=r["rendered_prompt"],
                output=r["output"],
                provider=r["provider"],
                model=r["model"],
                tokens_in=r["tokens_in"],
                tokens_out=r["tokens_out"],
                cost_usd=r["cost_usd"],
                latency_ms=r["latency_ms"],
                quality_score=r["quality_score"],
                timestamp=r["timestamp"],
                error=r["error"],
            )
            for r in rows
        ]

    def list_prompts(self) -> list[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT DISTINCT prompt_name FROM prompt_versions"
            ).fetchall()
        return [r["prompt_name"] for r in rows]