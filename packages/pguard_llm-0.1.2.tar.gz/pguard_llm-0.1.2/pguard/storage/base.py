from abc import ABC, abstractmethod
from typing import Optional
from ..models import PromptVersion, RunResult


class BaseStorage(ABC):

    @abstractmethod
    def save_version(self, prompt_name: str, version: PromptVersion) -> None:
        pass

    @abstractmethod
    def get_version(self, prompt_name: str, version_tag: str) -> Optional[PromptVersion]:
        pass

    @abstractmethod
    def list_versions(self, prompt_name: str) -> list[PromptVersion]:
        pass

    @abstractmethod
    def save_run(self, run: RunResult) -> None:
        pass

    @abstractmethod
    def get_runs(self, prompt_name: str, version_tag: str) -> list[RunResult]:
        pass

    @abstractmethod
    def list_prompts(self) -> list[str]:
        pass
