import json
import os
from pathlib import Path
from typing import Optional
from .base import BaseStorage
from ..models import PromptVersion, RunResult


class FileStorage(BaseStorage):
    """
    Stores prompts and runs as JSON files.
    Zero setup — works out of the box.

    Structure:
        .pguard/
            prompts/
                summarize/
                    v1.json
                    v2.json
            runs/
                summarize/
                    v1/
                        20240101120000.json
    """

    def __init__(self, base_dir: str = ".pguard"):
        self.base = Path(base_dir)
        self.prompts_dir = self.base / "prompts"
        self.runs_dir = self.base / "runs"
        self.prompts_dir.mkdir(parents=True, exist_ok=True)
        self.runs_dir.mkdir(parents=True, exist_ok=True)

    # ── Prompt Versions ──────────────────────────────────────────────────────

    def save_version(self, prompt_name: str, version: PromptVersion) -> None:
        path = self._version_path(prompt_name, version.tag)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(version.__dict__, f, indent=2)

    def get_version(self, prompt_name: str, version_tag: str) -> Optional[PromptVersion]:
        path = self._version_path(prompt_name, version_tag)
        if not path.exists():
            return None
        with open(path) as f:
            data = json.load(f)
        return PromptVersion(**data)

    def list_versions(self, prompt_name: str) -> list[PromptVersion]:
        prompt_dir = self.prompts_dir / prompt_name
        if not prompt_dir.exists():
            return []
        versions = []
        for f in sorted(prompt_dir.glob("*.json")):
            with open(f) as fp:
                data = json.load(fp)
            versions.append(PromptVersion(**data))
        return versions

    # ── Runs ─────────────────────────────────────────────────────────────────

    def save_run(self, run: RunResult) -> None:
        run_dir = self.runs_dir / run.prompt_name / run.version_tag
        run_dir.mkdir(parents=True, exist_ok=True)
        path = run_dir / f"{run.run_id}.json"
        with open(path, "w") as f:
            json.dump(run.__dict__, f, indent=2)

    def get_runs(self, prompt_name: str, version_tag: str) -> list[RunResult]:
        run_dir = self.runs_dir / prompt_name / version_tag
        if not run_dir.exists():
            return []
        runs = []
        for f in sorted(run_dir.glob("*.json")):
            with open(f) as fp:
                data = json.load(fp)
            runs.append(RunResult(**data))
        return runs

    # ── List ─────────────────────────────────────────────────────────────────

    def list_prompts(self) -> list[str]:
        if not self.prompts_dir.exists():
            return []
        return [d.name for d in self.prompts_dir.iterdir() if d.is_dir()]

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _version_path(self, prompt_name: str, version_tag: str) -> Path:
        return self.prompts_dir / prompt_name / f"{version_tag}.json"
