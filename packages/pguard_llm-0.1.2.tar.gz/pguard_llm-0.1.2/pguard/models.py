from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime, timezone


@dataclass
class PromptVersion:
    tag: str                          # e.g. "v1", "v2", "prod"
    template: str                     # The actual prompt template
    description: str = ""             # What changed in this version
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict = field(default_factory=dict)

    def render(self, **kwargs) -> str:
        """Render the prompt template with given variables."""
        try:
            return self.template.format(**kwargs)
        except KeyError as e:
            raise ValueError(f"Missing variable in prompt template: {e}")


@dataclass
class RunResult:
    prompt_name: str
    version_tag: str
    input_vars: dict
    rendered_prompt: str
    output: str
    provider: str                     # "openai", "anthropic", "gemini"
    model: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    latency_ms: float
    quality_score: Optional[float]    # 0-1, None if not evaluated
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    error: Optional[str] = None
    run_id: str = field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f"))