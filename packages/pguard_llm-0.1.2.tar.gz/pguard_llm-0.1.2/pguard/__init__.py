"""
pguard — Prompt version control and A/B testing for LLM applications.

Quick start:
    from pguard import Prompt

    p = Prompt("summarize")
    p.save("v1", "Summarize this text: {text}")
    p.save("v2", "In 3 bullet points, summarize: {text}")

    result = p.run("v1", provider="openai", model="gpt-4o",
                   api_key="sk-...", input_vars={"text": "..."})

    print(result.output)
    print(result.cost_usd)
    print(result.latency_ms)

    comparison = p.compare("v1", "v2")
    print(comparison.summary())
"""

from .prompt import Prompt
from .models import PromptVersion, RunResult
from .comparator import ComparisonResult
from .metrics import calc_cost, calc_quality_score

__version__ = "0.1.0"
__all__ = [
    "Prompt",
    "PromptVersion",
    "RunResult",
    "ComparisonResult",
    "calc_cost",
    "calc_quality_score",
]
