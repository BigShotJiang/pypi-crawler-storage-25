"""
Executes prompts against LLM providers and collects metrics.
Supports: OpenAI, Anthropic, Gemini
"""
import time
from typing import Optional
from .models import PromptVersion, RunResult
from .metrics import calc_cost, calc_quality_score


def run_prompt(
    prompt_name: str,
    version: PromptVersion,
    provider: str,
    model: str,
    api_key: str,
    input_vars: dict | None = None,
    expected_output: str | None = None,
    **provider_kwargs,
) -> RunResult:
    """
    Run a prompt version against an LLM and return a RunResult with full metrics.

    Args:
        prompt_name:     Name of the prompt (e.g. "summarize")
        version:         PromptVersion to run
        provider:        "openai" | "anthropic" | "gemini"
        model:           Model name (e.g. "gpt-4o")
        api_key:         Provider API key
        input_vars:      Variables to render into the prompt template
        expected_output: Optional ground truth for quality scoring
        **provider_kwargs: Extra args passed to the provider (temperature, max_tokens, etc.)
    """
    input_vars = input_vars or {}
    rendered = version.render(**input_vars)

    start = time.time()
    output = ""
    tokens_in = 0
    tokens_out = 0
    error = None

    try:
        if provider == "openai":
            output, tokens_in, tokens_out = _run_openai(rendered, model, api_key, **provider_kwargs)
        elif provider == "anthropic":
            output, tokens_in, tokens_out = _run_anthropic(rendered, model, api_key, **provider_kwargs)
        elif provider == "gemini":
            output, tokens_in, tokens_out = _run_gemini(rendered, model, api_key, **provider_kwargs)
        else:
            raise ValueError(f"Unsupported provider: {provider}. Use 'openai', 'anthropic', or 'gemini'.")
    except Exception as e:
        error = str(e)

    latency_ms = round((time.time() - start) * 1000, 2)
    cost = calc_cost(model, tokens_in, tokens_out)
    quality = calc_quality_score(output, expected=expected_output) if not error else None

    return RunResult(
        prompt_name=prompt_name,
        version_tag=version.tag,
        input_vars=input_vars,
        rendered_prompt=rendered,
        output=output,
        provider=provider,
        model=model,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        cost_usd=cost,
        latency_ms=latency_ms,
        quality_score=quality,
        error=error,
    )


# ── Provider Implementations ──────────────────────────────────────────────────

def _run_openai(prompt: str, model: str, api_key: str, **kwargs) -> tuple[str, int, int]:
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError("Install openai: pip install openai")

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        **kwargs,
    )
    output = response.choices[0].message.content or ""
    tokens_in = response.usage.prompt_tokens if response.usage else 0
    tokens_out = response.usage.completion_tokens if response.usage else 0
    return output, tokens_in, tokens_out


def _run_anthropic(prompt: str, model: str, api_key: str, **kwargs) -> tuple[str, int, int]:
    try:
        import anthropic
    except ImportError:
        raise ImportError("Install anthropic: pip install anthropic")

    max_tokens = kwargs.pop("max_tokens", 1024)
    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}],
        **kwargs,
    )
    output = response.content[0].text if response.content else ""
    tokens_in = response.usage.input_tokens if response.usage else 0
    tokens_out = response.usage.output_tokens if response.usage else 0
    return output, tokens_in, tokens_out


def _run_gemini(prompt: str, model: str, api_key: str, **kwargs) -> tuple[str, int, int]:
    try:
        from google import genai
        from google.genai import types
    except ImportError:
        raise ImportError("Install google-genai: pip install google-genai")

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=model,
        contents=prompt,
    )
    output = response.text or ""
    usage = response.usage_metadata
    tokens_in = usage.prompt_token_count if usage else 0
    tokens_out = usage.candidates_token_count if usage else 0
    return output, tokens_in, tokens_out
