"""
Cost and quality metrics for LLM runs.
"""

# USD per 1K tokens — input / output
COST_TABLE: dict[str, dict[str, float]] = {
    # OpenAI
    "gpt-4o":              {"in": 0.0025,  "out": 0.010},
    "gpt-4o-mini":         {"in": 0.00015, "out": 0.0006},
    "gpt-4-turbo":         {"in": 0.010,   "out": 0.030},
    "gpt-3.5-turbo":       {"in": 0.0005,  "out": 0.0015},
    # Anthropic
    "claude-opus-4":       {"in": 0.015,   "out": 0.075},
    "claude-sonnet-4":     {"in": 0.003,   "out": 0.015},
    "claude-haiku-4":      {"in": 0.00025, "out": 0.00125},
    "claude-3-5-sonnet":   {"in": 0.003,   "out": 0.015},
    "claude-3-5-haiku":    {"in": 0.00025, "out": 0.00125},
    # Gemini
    "gemini-2.5-pro":      {"in": 0.00125, "out": 0.005},
    "gemini-2.5-flash":    {"in": 0.00015, "out": 0.0006},
    "gemini-1.5-pro":      {"in": 0.00125, "out": 0.005},
    "gemini-1.5-flash":    {"in": 0.000075,"out": 0.0003},
    # Fallback
    "default":             {"in": 0.001,   "out": 0.002},
}


def calc_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Calculate cost in USD for a given model and token counts."""
    key = next((k for k in COST_TABLE if model.lower().startswith(k)), "default")
    rates = COST_TABLE[key]
    return round(
        (tokens_in / 1000) * rates["in"] + (tokens_out / 1000) * rates["out"],
        8
    )


def calc_quality_score(
    output: str,
    expected: str | None = None,
    min_length: int = 0,
    max_length: int | None = None,
) -> float:
    """
    Simple rule-based quality scorer (0.0 - 1.0).
    For a real project, replace/extend with LLM-as-judge or embedding similarity.

    Rules:
    - Empty output → 0.0
    - Length constraints violated → penalty
    - If expected provided → simple token overlap score
    """
    if not output or not output.strip():
        return 0.0

    score = 1.0

    # Length check
    length = len(output.strip())
    if min_length and length < min_length:
        score *= 0.5
    if max_length and length > max_length:
        score *= 0.7

    # Token overlap with expected (if provided)
    if expected:
        output_tokens = set(output.lower().split())
        expected_tokens = set(expected.lower().split())
        if expected_tokens:
            overlap = len(output_tokens & expected_tokens) / len(expected_tokens)
            score *= overlap

    return round(min(max(score, 0.0), 1.0), 4)
