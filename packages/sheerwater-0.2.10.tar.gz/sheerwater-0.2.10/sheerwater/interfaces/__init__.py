"""Standard interfaces for Sheerwater data and forecasts."""
from .datasets import (forecast, data, DATA_REGISTRY, FORECAST_REGISTRY,
                       list_forecasts, get_forecast, list_data, get_data,
                       add_spatial_attrs, check_spatial_attr)
from .events import EVENT_REGISTRY, get_event_fn
from .spatial import spatial

__all__ = [
    "forecast",
    "data",
    "spatial",
    "DATA_REGISTRY",
    "FORECAST_REGISTRY",
    "EVENT_REGISTRY",
    "get_event_fn",
    "list_forecasts",
    "get_forecast",
    "list_data",
    "get_data",
    "add_spatial_attrs",
    "check_spatial_attr",
]
