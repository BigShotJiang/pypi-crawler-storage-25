"""Tests for the zero-setup bootstrap API."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

from supervisor.bootstrap import bootstrap, BootstrapResult, _validate_pane


def _step_by_name(result: BootstrapResult, name: str) -> dict | None:
    for step in result.steps:
        if step["name"] == name:
            return step
    return None


def test_bootstrap_no_tmux(tmp_path, monkeypatch):
    """Without $TMUX, bootstrap fails at step 1."""
    monkeypatch.delenv("TMUX", raising=False)
    monkeypatch.delenv("TMUX_PANE", raising=False)
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))
    result = bootstrap(cwd=str(tmp_path))
    assert not result.ok
    assert "tmux" in result.error.lower()
    tmux_step = _step_by_name(result, "tmux_check")
    assert tmux_step["status"] == "failed"


def test_bootstrap_fresh_project(tmp_path, monkeypatch):
    """Fresh project with no .supervisor/ gets auto-initialized."""
    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%0")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane", return_value=(None, None)):
        result = bootstrap(cwd=str(tmp_path))

    assert result.ok, f"error: {result.error}"
    assert (tmp_path / ".supervisor").exists()
    assert (tmp_path / ".supervisor" / "config.yaml").exists()
    init_step = _step_by_name(result, "init_repair")
    assert init_step["status"] == "ok"


def test_bootstrap_existing_project(tmp_path, monkeypatch):
    """Existing project skips init."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")
    (tmp_path / ".supervisor" / "runtime").mkdir(parents=True)

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%1")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane", return_value=(None, None)):
        result = bootstrap(cwd=str(tmp_path))

    assert result.ok
    init_step = _step_by_name(result, "init_repair")
    assert init_step["status"] == "skipped"


def test_bootstrap_daemon_already_running(tmp_path, monkeypatch):
    """If daemon is running, skip auto-start."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%2")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    mock_client = MagicMock()
    mock_client.is_running.return_value = True

    with patch("supervisor.daemon.client.DaemonClient", return_value=mock_client), \
         patch("supervisor.bootstrap._validate_pane", return_value=(None, None)):
        result = bootstrap(cwd=str(tmp_path))

    assert result.ok
    daemon_step = _step_by_name(result, "daemon_ensure")
    assert daemon_step["status"] == "ok"


def test_bootstrap_pane_detect(tmp_path, monkeypatch):
    """Pane target comes from $TMUX_PANE."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%42")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane", return_value=(None, None)):
        result = bootstrap(cwd=str(tmp_path))

    assert result.ok
    assert result.pane_target == "%42"
    assert result.surface_type == "tmux"


def test_bootstrap_no_pane(tmp_path, monkeypatch):
    """Without $TMUX_PANE, bootstrap fails at pane detection."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.delenv("TMUX_PANE", raising=False)
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane", return_value=(None, None)):
        result = bootstrap(cwd=str(tmp_path))

    assert not result.ok
    assert "pane" in result.error.lower()


def test_bootstrap_pane_locked(tmp_path, monkeypatch):
    """Bootstrap fails when pane is locked by another run."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%5")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane", return_value=("pane %5 is locked by run run_xyz", {"run_id": "run_xyz", "controller_mode": "daemon"})):
        result = bootstrap(cwd=str(tmp_path))

    assert not result.ok
    assert "locked" in result.error


def test_bootstrap_pane_locked_by_daemon(tmp_path, monkeypatch):
    """Bootstrap shows observe suggestion for daemon-locked pane."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%6")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    daemon_conflict = {
        "run_id": "run_d1", "controller_mode": "daemon",
        "spec_path": "s.yaml", "suggested_action": "thin-supervisor observe run_d1",
    }
    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane",
               return_value=("pane %6 is owned by daemon run run_d1", daemon_conflict)):
        result = bootstrap(cwd=str(tmp_path))

    assert not result.ok
    assert "daemon" in result.error
    assert result.conflict["run_id"] == "run_d1"
    assert result.conflict["suggested_action"] == "thin-supervisor observe run_d1"


def test_bootstrap_pane_locked_by_foreground(tmp_path, monkeypatch):
    """Bootstrap shows stop suggestion for foreground-locked pane."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%7")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    fg_conflict = {
        "run_id": "run_fg", "controller_mode": "foreground",
        "spec_path": "spec.yaml", "suggested_action": "kill 12345  # stop foreground debug run run_fg",
    }
    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane",
               return_value=("pane %7 is owned by foreground debug run run_fg", fg_conflict)):
        result = bootstrap(cwd=str(tmp_path))

    assert not result.ok
    assert "foreground" in result.error
    assert result.conflict["controller_mode"] == "foreground"


def test_bootstrap_result_structure(tmp_path, monkeypatch):
    """Bootstrap result has all expected fields."""
    (tmp_path / ".supervisor").mkdir()
    (tmp_path / ".supervisor" / "config.yaml").write_text("surface_type: tmux\n")

    monkeypatch.setenv("TMUX", "/tmp/tmux-test/default,1234,0")
    monkeypatch.setenv("TMUX_PANE", "%0")
    monkeypatch.setenv("THIN_SUPERVISOR_GLOBAL_CONFIG", str(tmp_path / "g.yaml"))

    with patch("supervisor.bootstrap._ensure_daemon_running"), \
         patch("supervisor.bootstrap._validate_pane", return_value=(None, None)):
        result = bootstrap(cwd=str(tmp_path))

    assert isinstance(result.steps, list)
    assert len(result.steps) >= 5
    step_names = [s["name"] for s in result.steps]
    assert "tmux_check" in step_names
    assert "init_repair" in step_names
    assert "config_load" in step_names
    assert "daemon_ensure" in step_names
    assert "pane_detect" in step_names
