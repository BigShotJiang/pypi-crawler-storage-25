from __future__ import annotations

import json
from pathlib import Path
import hashlib

import pytest


def _build_history_workspace(tmp_path: Path) -> tuple[Path, str]:
    run_id = "run_demo123"
    spec_path = tmp_path / ".supervisor" / "specs" / "demo.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text(
        "kind: linear_plan\n"
        "id: demo\n"
        "goal: history test\n"
        "steps:\n"
        "  - id: write_test\n"
        "    type: task\n"
        "    objective: write tests\n"
        "    verify:\n"
        "      - type: command\n"
        "        run: echo ok\n"
        "        expect: pass\n"
        "  - id: implement_feature\n"
        "    type: task\n"
        "    objective: implement\n"
        "    verify:\n"
        "      - type: command\n"
        "        run: echo ok\n"
        "        expect: pass\n"
        "  - id: final_check\n"
        "    type: task\n"
        "    objective: final\n"
        "    verify:\n"
        "      - type: command\n"
        "        run: echo ok\n"
        "        expect: pass\n"
    )

    run_dir = tmp_path / ".supervisor" / "runtime" / "runs" / run_id
    run_dir.mkdir(parents=True)
    (run_dir / "state.json").write_text(json.dumps({
        "run_id": run_id,
        "spec_id": "demo",
        "mode": "linear_plan",
        "top_state": "COMPLETED",
        "current_node_id": "final_check",
        "current_attempt": 0,
        "done_node_ids": ["write_test", "implement_feature", "final_check"],
        "branch_history": [],
        "human_escalations": [],
        "retry_budget": {"per_node": 3, "global_limit": 12, "used_global": 0},
        "last_agent_checkpoint": {
            "status": "workflow_done",
            "current_node": "final_check",
            "summary": "suite passed",
            "checkpoint_seq": 3,
        },
        "checkpoint_seq": 3,
        "verification": {"ok": True, "results": [{"type": "command", "ok": True}]},
        "last_event": {},
        "spec_path": str(spec_path),
        "spec_hash": "deadbeef",
        "pane_target": "%1",
        "surface_type": "tmux",
        "workspace_root": str(tmp_path),
        "completed_reviews": ["human"],
        "last_injected_node_id": "final_check",
        "last_injected_attempt": 0,
    }, ensure_ascii=False, indent=2))

    decisions = [
        {"decision_id": "dec_1", "decision": "VERIFY_STEP", "reason": "checkpoint says step_done", "confidence": 1.0, "needs_human": False, "timestamp": "2026-04-12T00:00:01Z", "gate_type": "checkpoint_status", "triggered_by_seq": 1, "triggered_by_checkpoint_id": "cp_1", "next_instruction": None, "selected_branch": None, "next_node_id": None},
        {"decision_id": "dec_2", "decision": "VERIFY_STEP", "reason": "checkpoint says step_done", "confidence": 1.0, "needs_human": False, "timestamp": "2026-04-12T00:00:02Z", "gate_type": "checkpoint_status", "triggered_by_seq": 2, "triggered_by_checkpoint_id": "cp_2", "next_instruction": None, "selected_branch": None, "next_node_id": None},
        {"decision_id": "dec_3", "decision": "VERIFY_STEP", "reason": "checkpoint says workflow_done", "confidence": 1.0, "needs_human": False, "timestamp": "2026-04-12T00:00:03Z", "gate_type": "checkpoint_status", "triggered_by_seq": 3, "triggered_by_checkpoint_id": "cp_3", "next_instruction": None, "selected_branch": None, "next_node_id": None},
    ]
    (run_dir / "decision_log.jsonl").write_text(
        "\n".join(json.dumps(item) for item in decisions) + "\n",
        encoding="utf-8",
    )

    session_events = [
        {"run_id": run_id, "seq": 1, "event_type": "checkpoint", "timestamp": "2026-04-12T00:00:01Z", "payload": {"checkpoint_id": "cp_1", "run_id": run_id, "checkpoint_seq": 1, "status": "step_done", "current_node": "write_test", "summary": "tests written"}},
        {"run_id": run_id, "seq": 2, "event_type": "gate_decision", "timestamp": "2026-04-12T00:00:01Z", "payload": decisions[0]},
        {"run_id": run_id, "seq": 3, "event_type": "verification", "timestamp": "2026-04-12T00:00:01Z", "payload": {"ok": True, "results": [{"type": "command", "ok": True, "command": "echo ok"}]}},
        {"run_id": run_id, "seq": 4, "event_type": "checkpoint", "timestamp": "2026-04-12T00:00:02Z", "payload": {"checkpoint_id": "cp_2", "run_id": run_id, "checkpoint_seq": 2, "status": "step_done", "current_node": "implement_feature", "summary": "implementation done"}},
        {"run_id": run_id, "seq": 5, "event_type": "gate_decision", "timestamp": "2026-04-12T00:00:02Z", "payload": decisions[1]},
        {"run_id": run_id, "seq": 6, "event_type": "verification", "timestamp": "2026-04-12T00:00:02Z", "payload": {"ok": True, "results": [{"type": "command", "ok": True, "command": "echo ok"}]}},
        {"run_id": run_id, "seq": 7, "event_type": "checkpoint", "timestamp": "2026-04-12T00:00:03Z", "payload": {"checkpoint_id": "cp_3", "run_id": run_id, "checkpoint_seq": 3, "status": "workflow_done", "current_node": "final_check", "summary": "suite passed"}},
        {"run_id": run_id, "seq": 8, "event_type": "gate_decision", "timestamp": "2026-04-12T00:00:03Z", "payload": decisions[2]},
        {"run_id": run_id, "seq": 9, "event_type": "verification", "timestamp": "2026-04-12T00:00:03Z", "payload": {"ok": True, "results": [{"type": "command", "ok": True, "command": "echo ok"}]}},
        {"run_id": run_id, "seq": 10, "event_type": "routing", "timestamp": "2026-04-12T00:00:04Z", "payload": {"routing_id": "rt_1", "target_type": "human", "scope": "single_question", "reason": "need review", "triggered_by_decision_id": "dec_3", "consultation_id": "oracle_123"}},
    ]
    (run_dir / "session_log.jsonl").write_text(
        "\n".join(json.dumps(item) for item in session_events) + "\n",
        encoding="utf-8",
    )

    shared = tmp_path / ".supervisor" / "runtime" / "shared"
    shared.mkdir(parents=True, exist_ok=True)
    (shared / "notes.jsonl").write_text(
        "\n".join([
            json.dumps({
                "note_id": "note_1",
                "timestamp": "2026-04-12T00:00:01Z",
                "author_run_id": run_id,
                "note_type": "context",
                "title": "context",
                "content": "keep tests narrow",
                "metadata": {},
            }),
            json.dumps({
                "note_id": "note_2",
                "timestamp": "2026-04-12T00:00:02Z",
                "author_run_id": run_id,
                "note_type": "oracle",
                "title": "oracle",
                "content": "independent review",
                "metadata": {
                    "consultation_id": "oracle_123",
                    "provider": "openai",
                    "model_name": "o3",
                    "mode": "review",
                },
            }),
        ]) + "\n",
        encoding="utf-8",
    )
    (shared / "friction_events.jsonl").write_text(
        "\n".join([
            json.dumps({
                "event_id": "friction_1",
                "timestamp": "2026-04-12T00:00:02Z",
                "kind": "repeated_confirmation",
                "message": "user approved but agent asked again",
                "run_id": run_id,
                "user_id": "default",
                "signals": ["user_repeated_approval"],
                "metadata": {},
            }),
            json.dumps({
                "event_id": "friction_2",
                "timestamp": "2026-04-12T00:00:03Z",
                "kind": "unexpected_pause_confusion",
                "message": "user did not realize run was paused",
                "run_id": "other_run",
                "user_id": "default",
                "signals": ["silent_pause"],
                "metadata": {},
            }),
        ]) + "\n",
        encoding="utf-8",
    )
    (shared / "user_preferences.json").write_text(
        json.dumps({
            "default": {
                "approval_style": "terse",
                "clarify_tolerance": "low",
            }
        }, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return tmp_path, run_id


def test_export_run_includes_state_logs_and_notes(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    from supervisor.history import export_run

    exported = export_run(run_id)

    assert exported["schema_version"] == "run_export.v1"
    assert exported["run_id"] == run_id
    assert exported["state"]["spec_id"] == "demo"
    assert len(exported["decision_log"]) == 3
    assert len(exported["session_log"]) == 10
    assert len(exported["notes"]) == 2
    assert len(exported["friction_events"]) == 1
    assert exported["user_preferences"]["approval_style"] == "terse"
    assert "spec_snapshot" in exported
    assert exported["spec_snapshot"]["path"].endswith("demo.yaml")
    assert exported["spec_snapshot"]["hash"] == hashlib.sha256(
        exported["spec_snapshot"]["content"].encode("utf-8")
    ).hexdigest()[:16]


def test_export_run_includes_event_plane_mailbox_and_waits(tmp_path, monkeypatch):
    """Task 6: history/export must include external task + mailbox events so
    reviewers can reconstruct the deferred-work timeline."""
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    # Seed the event plane with a completed review round-trip against the
    # run's session_id. This models what the daemon would have written.
    state = json.loads((workspace / ".supervisor" / "runtime" / "runs" / run_id / "state.json").read_text())
    session_id = "session_demo123"
    state["session_id"] = session_id
    (workspace / ".supervisor" / "runtime" / "runs" / run_id / "state.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8",
    )

    shared = workspace / ".supervisor" / "runtime" / "shared"
    shared.mkdir(parents=True, exist_ok=True)
    (shared / "external_tasks.jsonl").write_text(
        "\n".join([
            json.dumps({
                "record_type": "request",
                "request_id": "req_1", "session_id": session_id, "run_id": run_id,
                "phase": "execute", "task_kind": "review",
                "provider": "external_review", "target_ref": "PR#1",
                "blocking_policy": "notify_only", "status": "completed",
                "created_at": "2026-04-12T00:00:01Z", "updated_at": "2026-04-12T00:00:05Z",
            }),
            json.dumps({
                "record_type": "result",
                "result_id": "res_1", "request_id": "req_1", "session_id": session_id,
                "run_id": run_id, "provider": "external_review",
                "result_kind": "review_comments", "summary": "LGTM",
                "payload": {}, "occurred_at": "2026-04-12T00:00:05Z",
            }),
        ]) + "\n",
        encoding="utf-8",
    )
    (shared / "session_waits.jsonl").write_text(
        json.dumps({
            "wait_id": "wait_1", "session_id": session_id, "run_id": run_id,
            "request_id": "req_1", "wait_kind": "external_review",
            "status": "satisfied", "resume_policy": "operator_ack",
            "entered_at": "2026-04-12T00:00:01Z", "resolved_at": "2026-04-12T00:00:05Z",
            "deadline_at": "",
        }) + "\n",
        encoding="utf-8",
    )
    (shared / "session_mailbox.jsonl").write_text(
        json.dumps({
            "mailbox_item_id": "mb_1", "session_id": session_id, "run_id": run_id,
            "request_id": "req_1", "source_kind": "external_review",
            "summary": "LGTM", "payload": {"provider": "external_review"},
            "delivery_status": "new", "wake_decision": "notify_operator",
            "created_at": "2026-04-12T00:00:05Z", "updated_at": "2026-04-12T00:00:05Z",
        }) + "\n",
        encoding="utf-8",
    )

    from supervisor.history import export_run

    exported = export_run(run_id)
    ep = exported.get("event_plane", {})
    assert ep, "export_run must include event_plane section"
    assert ep["session_id"] == session_id
    assert len(ep["requests"]) == 1
    assert ep["requests"][0]["request_id"] == "req_1"
    assert len(ep["results"]) == 1
    assert ep["results"][0]["result_id"] == "res_1"
    assert len(ep["waits"]) == 1
    assert ep["waits"][0]["status"] == "satisfied"
    assert len(ep["mailbox"]) == 1
    assert ep["mailbox"][0]["wake_decision"] == "notify_operator"


def test_summarize_run_reports_counts_and_oracle_links(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    from supervisor.history import export_run, summarize_run

    summary = summarize_run(export_run(run_id))

    assert summary["run_id"] == run_id
    assert summary["top_state"] == "COMPLETED"
    assert summary["counts"]["checkpoints"] == 3
    assert summary["counts"]["verifications_ok"] == 3
    assert summary["counts"]["routing_events"] == 1
    assert summary["counts"]["oracle_notes"] == 1
    assert summary["counts"]["friction_events"] == 1
    assert summary["friction_kinds"] == ["repeated_confirmation"]
    assert summary["friction_summary"]["total_events"] == 1
    assert summary["friction_summary"]["by_kind"]["repeated_confirmation"] == 1
    assert summary["friction_summary"]["by_signal"]["user_repeated_approval"] == 1
    assert summary["oracle_consultation_ids"] == ["oracle_123"]


def test_replay_run_recomputes_decisions_without_injection(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    from supervisor.history import export_run, replay_run

    replay = replay_run(export_run(run_id))

    assert replay["run_id"] == run_id
    assert replay["decision_count"] == 3
    assert replay["matched_count"] == 3
    assert replay["mismatches"] == []


def test_render_postmortem_generates_markdown(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    from supervisor.history import export_run, render_postmortem

    markdown = render_postmortem(export_run(run_id))

    assert f"# Run Postmortem: {run_id}" in markdown
    assert "Top state: `COMPLETED`" in markdown
    assert "Oracle consultations: `oracle_123`" in markdown
    assert "Friction events: 1" in markdown
    assert "Friction kinds: `repeated_confirmation`" in markdown
    assert "Routing events: 1" in markdown


def test_replay_run_uses_exported_spec_snapshot_when_worktree_spec_changes(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    from supervisor.history import export_run, replay_run

    exported = export_run(run_id)
    spec_path = Path(exported["state"]["spec_path"])
    spec_path.write_text(
        "kind: linear_plan\nid: demo\ngoal: changed\nsteps:\n"
        "  - id: other\n    type: task\n    objective: mismatch\n"
        "    verify:\n      - type: command\n        run: echo nope\n        expect: pass\n"
    )

    replay = replay_run(exported)

    assert replay["matched_count"] == 3


def test_replay_run_uses_exported_spec_snapshot_when_spec_file_is_missing(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    from supervisor.history import export_run, replay_run

    exported = export_run(run_id)
    Path(exported["state"]["spec_path"]).unlink()

    replay = replay_run(exported)

    assert replay["matched_count"] == 3


def test_replay_run_passes_runtime_root_to_routing_lookup(tmp_path, monkeypatch):
    workspace, run_id = _build_history_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    exported = {
        "schema_version": "run_export.v1",
        "run_id": run_id,
        "paths": {
            "run_dir": str(workspace / ".supervisor" / "runtime" / "runs" / run_id),
            "runtime_dir": str(workspace / ".supervisor" / "runtime"),
        },
        "state": {
            "run_id": run_id,
            "spec_id": "demo",
            "mode": "linear_plan",
            "top_state": "PAUSED_FOR_HUMAN",
            "current_node_id": "write_test",
            "current_attempt": 0,
            "done_node_ids": [],
            "branch_history": [],
            "human_escalations": [],
            "retry_budget": {"per_node": 3, "global_limit": 12, "used_global": 0},
            "last_agent_checkpoint": {},
            "checkpoint_seq": 1,
            "verification": {},
            "last_event": {},
            "spec_path": str(workspace / ".supervisor" / "specs" / "demo.yaml"),
            "spec_hash": "",
            "pane_target": "%1",
            "surface_type": "tmux",
            "workspace_root": str(workspace),
            "completed_reviews": [],
            "last_injected_node_id": "",
            "last_injected_attempt": 0,
        },
        "spec_snapshot": {
            "path": str(workspace / ".supervisor" / "specs" / "demo.yaml"),
            "content": (
                "kind: linear_plan\nid: demo\ngoal: history test\n"
                "steps:\n  - id: write_test\n    type: task\n    objective: write tests\n"
                "    verify:\n      - type: command\n        run: echo ok\n        expect: pass\n"
            ),
        },
        "decision_log": [
            {"decision_id": "dec_1", "decision": "ESCALATE_TO_HUMAN", "reason": "checkpoint says blocked", "confidence": 1.0, "needs_human": True, "timestamp": "2026-04-12T00:00:01Z", "gate_type": "checkpoint_status", "triggered_by_seq": 1, "triggered_by_checkpoint_id": "cp_1"}
        ],
        "session_log": [
            {"run_id": run_id, "seq": 1, "event_type": "checkpoint", "timestamp": "2026-04-12T00:00:01Z", "payload": {"checkpoint_id": "cp_1", "run_id": run_id, "checkpoint_seq": 1, "status": "blocked", "current_node": "write_test", "summary": "need help"}},
            {"run_id": run_id, "seq": 2, "event_type": "gate_decision", "timestamp": "2026-04-12T00:00:01Z", "payload": {"decision_id": "dec_1", "decision": "ESCALATE_TO_HUMAN", "reason": "checkpoint says blocked", "confidence": 1.0, "needs_human": True, "timestamp": "2026-04-12T00:00:01Z", "gate_type": "checkpoint_status", "triggered_by_seq": 1, "triggered_by_checkpoint_id": "cp_1"}},
        ],
        "notes": [],
    }

    captured: dict[str, str] = {}

    def fake_lookup(run_id_arg: str, runtime_dir: str = ".supervisor/runtime") -> str:
        captured["run_id"] = run_id_arg
        captured["runtime_dir"] = runtime_dir
        return ""

    monkeypatch.setattr("supervisor.loop.latest_oracle_consultation_id_for_run", fake_lookup)

    from supervisor.history import replay_run

    replay_run(exported)

    assert captured["run_id"] == run_id
    assert captured["runtime_dir"] == str(workspace / ".supervisor" / "runtime")


def test_apply_replay_resume_restores_attached_when_pre_pause_captured():
    """Mirror the live daemon resume: a run paused from ATTACHED (captured
    in pre_pause_top_state) must replay back to ATTACHED, not RUNNING.
    Otherwise replay diverges from the live path and the attach-boundary
    gate is bypassed when re-driving the next checkpoint. Also must
    reset delivery_state to IDLE — the live daemon resume does this and
    leaving a stale waiting/paused delivery state would skew replay.
    """
    from supervisor.domain.enums import DeliveryState, TopState
    from supervisor.domain.models import SupervisorState
    from supervisor.history import _apply_replay_resume

    state = SupervisorState(
        run_id="r1",
        spec_id="s1",
        mode="linear_plan",
        top_state=TopState.PAUSED_FOR_HUMAN,
        current_node_id="n1",
    )
    state.top_state = TopState.PAUSED_FOR_HUMAN
    state.pre_pause_top_state = TopState.ATTACHED.value
    state.re_inject_count = 7
    state.delivery_state = DeliveryState.SUBMITTED

    _apply_replay_resume(state)

    assert state.top_state == TopState.ATTACHED
    assert state.re_inject_count == 0
    assert state.pre_pause_top_state == ""
    assert state.delivery_state == DeliveryState.IDLE


def test_apply_replay_resume_defaults_to_running_when_pre_pause_empty():
    from supervisor.domain.enums import TopState
    from supervisor.domain.models import SupervisorState
    from supervisor.history import _apply_replay_resume

    state = SupervisorState(
        run_id="r1",
        spec_id="s1",
        mode="linear_plan",
        top_state=TopState.PAUSED_FOR_HUMAN,
        current_node_id="n1",
    )
    state.top_state = TopState.PAUSED_FOR_HUMAN
    state.pre_pause_top_state = ""

    _apply_replay_resume(state)

    assert state.top_state == TopState.RUNNING
    assert state.pre_pause_top_state == ""


def test_apply_replay_resume_noop_when_not_paused():
    from supervisor.domain.enums import TopState
    from supervisor.domain.models import SupervisorState
    from supervisor.history import _apply_replay_resume

    state = SupervisorState(
        run_id="r1",
        spec_id="s1",
        mode="linear_plan",
        top_state=TopState.PAUSED_FOR_HUMAN,
        current_node_id="n1",
    )
    state.top_state = TopState.RUNNING

    _apply_replay_resume(state)

    assert state.top_state == TopState.RUNNING
