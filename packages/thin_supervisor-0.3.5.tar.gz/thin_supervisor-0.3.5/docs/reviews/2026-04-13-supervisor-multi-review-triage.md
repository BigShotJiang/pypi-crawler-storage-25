# Supervisor Multi-Review Triage

## Summary

`2026-04-13-supervisor-multi-review.md` mixes together three kinds of findings:

1. Local correctness bugs that can be fixed directly in code.
2. State-machine design flaws caused by implicit transitions and dead abstractions.
3. Control-plane trust/recovery gaps that need broader hardening, not one-off patches.

This document records which findings were closed in the first hardening pass and
which ones are symptoms of larger architectural issues.

## Closed in the first hardening pass

- `U-02` (partial): removed the unsafe `FINISH` bypass path from the continue
  judge flow and forced `apply_decision(FINISH)` through `FinishGate`.
  Note: `workflow_done -> VERIFY_STEP` remains intentional, because the final
  step verifier still has to run before completion.
- `U-03`: `handle_event()` no longer overwrites `VERIFYING` with `GATING`.
- `U-04`: seq reset from worker restart now tolerates `checkpoint_seq == 1`
  instead of silently discarding the restarted stream.
- `U-05`: mismatch checkpoints are no longer consumed before the threshold is
  reached, so node-mismatch escalation can actually trigger.
- `U-06`: `_do_ack_review()` now holds the daemon lock across the whole
  read-modify-write sequence.
- `U-07`: `classify_checkpoint()` now sees `summary` and `evidence`.
- `U-17`: removed the overly broad `waiting for` blocked pattern and narrowed
  it to missing-input language.

Related files:

- [supervisor/loop.py](../../supervisor/loop.py)
- [supervisor/daemon/server.py](../../supervisor/daemon/server.py)
- [supervisor/gates/rules.py](../../supervisor/gates/rules.py)
- [supervisor/llm/prompts/continue_or_escalate.txt](../../supervisor/llm/prompts/continue_or_escalate.txt)

## Local bugs still remaining

These are still concrete bugs, but they are smaller in scope than the broader
design issues below.

- `U-10`: `node_mismatch_count` reset behavior after auto-intervention may still
  make repeated mismatch recovery too forgiving.
- `U-11`: resume matching still mixes worker identity, daemon ownership, and
  spec identity too loosely.
- `U-12`: retry budget / auto-intervention counters are not treated as a single
  recovery policy with a clear reset contract.
- `U-22`: injection confirmation is improved, but still relies on UI-text
  heuristics rather than an explicit submission acknowledgement channel.
- `U-24`: judge JSON parsing should be hardened against fenced-code and similar
  output noise.

## Structural design flaws

These findings are not primarily "someone wrote the wrong `if`". They are
 symptoms of the current control-plane design.

### 1. Implicit state machine

Findings:

- `U-08` dead states and enums
- `U-09` no transition validation
- `U-21` `is_final()` naming drift

Root cause:

The runtime behaves like a state machine, but it is not implemented as one.
`top_state` is mutated ad hoc from multiple places, while enums such as
`INIT`, `AWAITING_AGENT_EVENT`, and `NodeStatus` exist without a live role.

Consequence:

- correctness depends on scattered conditionals
- dead states accumulate
- illegal transitions are not mechanically blocked
- future changes keep reintroducing edge cases

### 2. Multiple protocol sources of truth

Findings:

- `U-01` checkpoint template / parser incompatibility
- `U-14` skill vs protocol mismatch
- `U-25` codex skill missing verification guidance

Root cause:

Checkpoint behavior is specified in too many places:

- runtime-composed instructions
- `checkpoint_protocol.txt`
- `SKILL.md`
- parser assumptions

Consequence:

- one layer drifts and the others keep "working" until runtime silently drops
  checkpoints
- protocol evolution becomes brittle

### 3. Weak control-plane recovery contract

Findings:

- `U-11` resume ambiguity
- `U-13` observation-only injection black hole
- `U-19` persistence windows
- `U-20` session sequence thread safety
- `U-27` pause/human escalation cleanup inconsistency

Root cause:

The daemon, persisted run state, pane ownership, and observer surfaces do not
share one explicit recovery model.

Consequence:

- restart/resume semantics stay ambiguous
- some modes can inject work without delivery confirmation
- state durability and resumption semantics differ by path

### 4. Weak trust-boundary modeling

Findings:

- `U-24` judge output parsing
- `U-26` evidence substring / forgery
- `U-28` unsanitized checkpoint content
- `U-29` judge output reused as instruction text

Root cause:

The system still treats agent-authored text as if it were mostly trusted
control data. The current implementation has guardrails, but the boundary
between "observed evidence" and "control instruction" is still too soft.

Consequence:

- prompt injection style issues reappear in different forms
- acceptance and escalation logic remain easier to spoof than they should be

## Recommended next hardening tranche

1. Introduce an explicit transition table for `TopState` and remove dead states
   or make them real.
2. Collapse checkpoint protocol to one canonical schema and generate all
   external instructions from it.
3. Define one recovery contract for daemon restart, resume, pause, and
   observation-only delivery.
4. Separate trusted control data from untrusted agent text in judge, finish
   gate, and follow-up instruction generation.
