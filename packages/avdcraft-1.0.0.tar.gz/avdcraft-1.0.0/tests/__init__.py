"""Tests for avdcraft"""
