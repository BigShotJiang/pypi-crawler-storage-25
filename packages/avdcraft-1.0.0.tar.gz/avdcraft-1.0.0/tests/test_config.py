"""
Test configuration loader
"""
import unittest
from pathlib import Path
from avdcraft.config import Config


class TestConfig(unittest.TestCase):
    """Test configuration loading from TOML"""

    def setUp(self):
        self.config = Config()

    def test_system_image(self):
        """Test system image configuration"""
        self.assertIsNotNone(self.config.system_image)
        self.assertIn("android-33", self.config.system_image)

    def test_java_version(self):
        """Test Java version requirement"""
        self.assertEqual(self.config.java_version_required, 17)

    def test_api_level(self):
        """Test API level configuration"""
        self.assertEqual(self.config.api_level, 33)

    def test_urls_exist(self):
        """Test that all URLs are configured"""
        self.assertIsNotNone(self.config.adoptium_api_url)
        self.assertIsNotNone(self.config.repo_manifest_url)
        self.assertTrue(len(self.config.cmdtools_fallback_urls) > 0)


if __name__ == "__main__":
    unittest.main()
