"""
Configuration loader for avdcraft
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

try:
    import pytoml as toml
except ImportError:
    import tomllib as toml  # Python 3.11+


class Config:
    """Load and manage configuration from config.toml"""

    def __init__(self):
        self.config = self._load_config()

    @staticmethod
    def _load_config() -> Dict[str, Any]:
        """Load config.toml from package directory"""
        config_path = Path(__file__).parent / "config.toml"
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, "rb") as f:
            return toml.load(f)

    @property
    def system_image(self) -> str:
        return self.config["android"]["system_image"]

    @property
    def pixel7_device(self) -> str:
        return self.config["android"]["pixel7_device"]

    @property
    def default_name(self) -> str:
        return self.config["android"]["default_name"]

    @property
    def api_level(self) -> int:
        return self.config["android"]["api_level"]

    @property
    def android_version(self) -> str:
        return self.config["android"]["android_version"]

    @property
    def java_version_required(self) -> int:
        return self.config["java"]["version_required"]

    @property
    def adoptium_api_url(self) -> str:
        return self.config["java"]["adoptium_api_url"]

    @property
    def jdk_fallback_url(self) -> str:
        return self.config["java"]["fallback_url"]

    @property
    def repo_manifest_url(self) -> str:
        return self.config["cmdline_tools"]["repo_manifest_url"]

    @property
    def cmdtools_fallback_urls(self) -> list:
        return self.config["cmdline_tools"]["fallback_urls"]

    @property
    def banner(self) -> str:
        return self.config["display"]["banner"]

    @property
    def section_width(self) -> int:
        return self.config["ui"]["section_width"]

    @property
    def timeout_download(self) -> int:
        return self.config["ui"]["timeout_download"]

    @property
    def timeout_manifest(self) -> int:
        return self.config["ui"]["timeout_manifest"]


# Global config instance
config = Config()
