"""
avdcraft - Automated Android Virtual Device (AVD) Setup Tool

A Python package that automates the setup and management of Android Virtual Devices (AVDs)
for Android developers using Android Studio. It streamlines emulator configuration, handles
system image management, and simplifies AVD creation and deletion.

Works with any Android development project, whether using Flutter, Kotlin, Java, or other
Android frameworks.

Usage:
    avdcraft  # Run the interactive setup wizard
"""

__version__ = "1.0.0"
__author__ = "Nandhan K"
__email__ = "nandhank@scholarpeak.in"
__license__ = "MIT"

from .cli import main
from .config import config
from .banner import display_banner, print_banner
from .core import (
    ensure_java_17,
    check_tools,
    accept_licenses,
    list_avds,
    get_avd_details,
    ensure_system_image,
    create_avd,
    delete_avd,
    write_bat,
)

__all__ = [
    "main",
    "config",
    "ensure_java_17",
    "check_tools",
    "accept_licenses",
    "list_avds",
    "get_avd_details",
    "ensure_system_image",
    "create_avd",
    "delete_avd",
    "write_bat",
]
