"""
Banner display module for avdcraft
Displays project information with creator and version
"""

from . import __version__, __author__


def show_banner():
    """Display the avdcraft ASCII art banner."""
    banner = r"""
 █████╗ ██╗   ██╗██████╗  ██████╗██████╗  █████╗ ███████╗████████╗
██╔══██╗██║   ██║██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝
███████║██║   ██║██║  ██║██║     ██████╔╝███████║█████╗     ██║   
██╔══██║╚██╗ ██╔╝██║  ██║██║     ██╔══██╗██╔══██║██╔══╝     ██║   
██║  ██║ ╚████╔╝ ██████╔╝╚██████╗██║  ██║██║  ██║██║        ██║   
╚═╝  ╚═╝  ╚═══╝  ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝        ╚═╝   

        ▸ A V D C R A F T ◂
"""
    print(banner)


def print_banner():
    """Display the avdcraft banner with creator name and version."""
    show_banner()
    info = f"    Created by: {__author__:<28} | v{__version__}\n"
    info += "    ═══════════════════════════════════════════════════════════════\n"
    print(info)
    return info


def display_banner():
    """Print the banner to console with all information."""
    print_banner()


if __name__ == "__main__":
    display_banner()
