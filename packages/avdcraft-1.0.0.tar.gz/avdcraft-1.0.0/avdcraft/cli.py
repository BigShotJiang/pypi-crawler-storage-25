"""
Command-line interface for avdcraft
"""
from __future__ import annotations

import sys
from pathlib import Path

from .config import config
from .core import (
    ensure_java_17,
    check_tools,
    accept_licenses,
    list_avds,
    get_avd_details,
    ensure_system_image,
    create_avd,
    delete_avd,
    write_bat,
    _section,
    _ok,
    _info,
    _warn,
    _fail,
    _ask,
    _find_jdk,
    AVD_HOME,
)


def show_banner() -> None:
    """Display the avdcraft banner."""
    print(config.banner)


def show_summary(avd_name: str, bat: Path | None) -> None:
    """Display setup completion summary."""
    jdk = _find_jdk()
    print("\n")
    print("╔══════════════════════════════════════════════════╗")
    print("║                 Setup Complete ✅                ║")
    print("╚══════════════════════════════════════════════════╝")
    print(f"\n  AVD Name  : {avd_name}")
    print(f"  API Level : {config.api_level} ({config.android_version})")
    print(f"  Device    : Pixel 7")
    print(f"  Image     : {config.system_image}")
    print(f"  Java Home : {jdk}")
    print(f"  AVD INI   : {AVD_HOME / avd_name}.ini")
    if bat:
        print(f"  BAT Script: {bat}")
    print()
    print("  Next steps:")
    print("   1. Double-click  start_emulator.bat  on your Desktop")
    print("   2. Wait ~30–60 s for emulator to boot (headless mode)")
    print("   3. Run:  flutter devices  →  flutter run")
    print()


def main() -> None:
    """Main entry point for avdcraft."""
    show_banner()

    # ── Step 0: Java 17 — must be first ────────
    if not ensure_java_17():
        sys.exit(1)

    # ── Step 1: SDK tools ───────────────────────
    if not check_tools():
        sys.exit(1)

    accept_licenses()

    # ── Step 2: Existing AVDs ───────────────────
    _section("Scanning for Existing AVDs")
    existing_avds = list_avds()
    avd_name      = config.default_name

    if existing_avds:
        print(f"\n  Found {len(existing_avds)} existing AVD(s):\n")
        for i, name in enumerate(existing_avds, 1):
            d       = get_avd_details(name)
            api_str = d["api"] if d["api"] != "unknown" else "?"
            print(f"    [{i}]  {name}  (API {api_str})")

        print(f"\n  [0]  Create new Pixel 7 · API {config.api_level} AVD (default)\n")
        choice = input("  Select an AVD to reuse, or 0 for new: ").strip()

        if choice.isdigit() and 1 <= int(choice) <= len(existing_avds):
            selected = existing_avds[int(choice) - 1]
            details  = get_avd_details(selected)
            print(f"\n  Selected : {selected}")
            print(f"  Target   : {details['target']}")

            if details["api"] == str(config.api_level):
                _ok(f"This AVD is already on API {config.api_level} — reusing.")
                avd_name = selected
            else:
                _info(f"Will upgrade '{selected}' → API {config.api_level} ({config.android_version}).")
                _warn("The existing AVD will be deleted and recreated.")
                if _ask("  Proceed with upgrade?") == "y":
                    avd_name = selected
                    if not ensure_system_image():
                        sys.exit(1)
                    _section(f"Recreating '{avd_name}' with API {config.api_level}")
                    if not delete_avd(avd_name):
                        sys.exit(1)
                    if not create_avd(avd_name):
                        sys.exit(1)
                    _section("Writing BAT Script to Desktop")
                    bat = write_bat(avd_name)
                    show_summary(avd_name, bat)
                    return
                else:
                    _info("Upgrade cancelled — will create a new AVD instead.")
        else:
            _info(f"Creating a new Pixel 7 · API {config.api_level} AVD …")

    else:
        _info(f"No existing AVDs found. Creating a fresh Pixel 7 · API {config.api_level} AVD.")

    # ── Step 3: System image + AVD creation ────
    if not ensure_system_image():
        sys.exit(1)

    _section(f"Creating AVD: {avd_name}")
    if not create_avd(avd_name):
        _warn("\n  Possible reasons:")
        _warn("  • Java version wasn't applied — re-run the script once more")
        _warn("  • Try running as Administrator if permission errors appear")
        _warn(f"  • Delete old AVD manually: avdmanager delete avd -n {config.default_name}")
        sys.exit(1)

    # ── Step 4: Launcher BAT ───────────────────
    _section("Writing BAT Script to Desktop")
    bat = write_bat(avd_name)
    show_summary(avd_name, bat)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  ⚠  Interrupted by user. Exiting.")
        sys.exit(0)
