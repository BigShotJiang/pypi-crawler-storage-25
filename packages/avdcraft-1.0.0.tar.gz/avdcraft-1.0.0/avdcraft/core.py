"""
Core functionality for avdcraft
Handles Java detection, SDK tools, AVD creation, and downloads
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from .config import config


# ─────────────────────────────────────────────────────
#  SDK / Tool Paths
# ─────────────────────────────────────────────────────
_LOCAL       = os.environ.get("LOCALAPPDATA", "")
SDK_ROOT     = Path(_LOCAL) / "Android" / "Sdk"
TOOLS_BIN    = SDK_ROOT / "cmdline-tools" / "latest" / "bin"
EMULATOR_DIR = SDK_ROOT / "emulator"

AVDMANAGER   = TOOLS_BIN / "avdmanager.bat"
SDKMANAGER   = TOOLS_BIN / "sdkmanager.bat"
EMULATOR_EXE = EMULATOR_DIR / "emulator.exe"

JDK_DIR  = SDK_ROOT / "jdk17"
AVD_HOME = Path.home() / ".android" / "avd"

# Lines emitted by avdmanager/sdkmanager when Java is wrong
_JAVA_WARNING_FRAGMENTS = (
    "java version",
    "jdk_version_check",
    "skip_jdk",
    "version 17 or higher",
    "to override",
)


# ─────────────────────────────────────────────────────
#  Pretty Printers
# ─────────────────────────────────────────────────────
def _section(title: str) -> None:
    w = config.section_width
    print(f"\n{'─' * w}\n  {title}\n{'─' * w}")


def _ok(msg: str) -> None:
    print(f"  ✅  {msg}")


def _info(msg: str) -> None:
    print(f"  ℹ  {msg}")


def _warn(msg: str) -> None:
    print(f"  ⚠  {msg}")


def _fail(msg: str) -> None:
    print(f"  ✖  {msg}")


def _is_java_warning(line: str) -> bool:
    low = line.lower()
    return any(frag in low for frag in _JAVA_WARNING_FRAGMENTS)


# ─────────────────────────────────────────────────────
#  Java Detection & Installation
# ─────────────────────────────────────────────────────
def _find_jdk() -> Path | None:
    """Return Path to a JDK 17+ installation."""
    # 1. Our portable install
    if (JDK_DIR / "bin" / "java.exe").exists():
        return JDK_DIR

    # 2. JAVA_HOME environment variable
    jh = os.environ.get("JAVA_HOME", "")
    if jh and (Path(jh) / "bin" / "java.exe").exists():
        return Path(jh)

    # 3. Walk up from 'where java'
    try:
        r = subprocess.run("where java", shell=True, capture_output=True, text=True)
        for line in r.stdout.splitlines():
            p = Path(line.strip())
            if p.exists() and p.name.lower() == "java.exe":
                return p.parent.parent
    except Exception:
        pass

    return None


def _java_major_version(jdk: Path | None) -> int:
    """Return the JDK major version (e.g. 17) or 0 if undetectable."""
    if jdk is None:
        return 0
    java_exe = jdk / "bin" / "java.exe"
    try:
        r = subprocess.run(
            [str(java_exe), "-version"],
            capture_output=True, text=True
        )
        output = r.stderr + r.stdout
        m = re.search(r'version "(\d+)', output)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return 0


def _build_env() -> dict:
    """Build environment dict with JAVA_HOME and PATH set."""
    env = os.environ.copy()
    jdk = _find_jdk()
    if jdk:
        env["JAVA_HOME"] = str(jdk)
        env["PATH"] = str(jdk / "bin") + os.pathsep + env.get("PATH", "")
    return env


def _run(cmd: str, stream: bool = False, env: dict | None = None) -> subprocess.CompletedProcess:
    """Run a shell command with optional environment."""
    if env is None:
        env = _build_env()
    if stream:
        return subprocess.run(cmd, shell=True, text=True, env=env)
    return subprocess.run(cmd, shell=True, text=True, capture_output=True, env=env)


def _ask(prompt: str, valid: tuple = ("y", "n")) -> str:
    """Prompt user until they enter a valid choice."""
    choices = "/".join(valid)
    while True:
        answer = input(f"{prompt} [{choices}]: ").strip().lower()
        if answer in valid:
            return answer
        print(f"  ⚠  Please enter one of: {choices}")


def _download_with_progress(url: str, dest: Path) -> bool:
    """Download a file with progress bar."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=config.timeout_download) as resp:
            total      = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            chunk      = 65536
            with open(dest, "wb") as fh:
                while True:
                    block = resp.read(chunk)
                    if not block:
                        break
                    fh.write(block)
                    downloaded += len(block)
                    mb = downloaded / 1_048_576
                    if total:
                        pct  = downloaded / total * 100
                        done = int(pct / 2)
                        bar  = "█" * done + "░" * (50 - done)
                        print(f"\r  [{bar}] {pct:5.1f}%  {mb:.1f} MB", end="", flush=True)
                    else:
                        print(f"\r  Downloaded {mb:.1f} MB …", end="", flush=True)
        print()
        return True
    except Exception as exc:
        print()
        _fail(f"Download failed: {exc}")
        return False


def _fetch_jdk_download_url() -> str | None:
    """Query Adoptium API for latest JDK 17."""
    try:
        _info("Querying Eclipse Adoptium API for latest JDK 17 …")
        req = urllib.request.Request(config.adoptium_api_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode())

        for asset in data:
            binary = asset.get("binary", {})
            pkg    = binary.get("package", {})
            link   = pkg.get("link", "")
            if link.lower().endswith(".zip"):
                _ok(f"Found: {asset.get('release_name', 'JDK 17')}")
                return link
    except Exception as exc:
        _warn(f"Adoptium API unreachable: {exc}")
    return None


def _download_and_install_jdk17() -> bool:
    """Download and install Eclipse Temurin JDK 17."""
    _section("Downloading Eclipse Temurin OpenJDK 17")

    url = _fetch_jdk_download_url()
    if not url:
        _info("Using hard-coded fallback URL …")
        url = config.jdk_fallback_url

    _info(f"Source: {url}")
    zip_path = Path(tempfile.gettempdir()) / "temurin17.zip"

    if not _download_with_progress(url, zip_path):
        return False

    _info("Extracting JDK …")
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            members = zf.namelist()
            top_dir = members[0].split("/")[0]

            with tempfile.TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                zf.extractall(tmp_path)
                extracted = tmp_path / top_dir

                if JDK_DIR.exists():
                    shutil.rmtree(JDK_DIR)
                JDK_DIR.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(str(extracted), str(JDK_DIR))

        zip_path.unlink(missing_ok=True)
    except Exception as exc:
        _fail(f"JDK extraction failed: {exc}")
        return False

    version = _java_major_version(JDK_DIR)
    if version >= config.java_version_required:
        _ok(f"Java {version} installed successfully → {JDK_DIR}")
        return True

    _fail("JDK extraction completed but java.exe not functional.")
    return False


def ensure_java_17() -> bool:
    """Check for Java 17+, install if missing."""
    _section("Checking Java Version")

    jdk     = _find_jdk()
    version = _java_major_version(jdk)

    if version >= config.java_version_required:
        _ok(f"Java {version} found → {jdk}")
        return True

    if version > 0:
        _warn(f"Java {version} detected — Java {config.java_version_required}+ is required.")
    else:
        _fail("No Java installation found on this system.")

    _info(f"Eclipse Temurin OpenJDK {config.java_version_required} will be installed to:")
    _info(f"  {JDK_DIR}")
    _info("One-time download (~185 MB). No administrator rights needed.")
    if _ask(f"  Download and install Java {config.java_version_required} now?") == "n":
        _warn(f"Cannot proceed without Java {config.java_version_required}.")
        _warn("Manual install: https://adoptium.net/temurin/releases/?version=17")
        return False

    return _download_and_install_jdk17()


# ─────────────────────────────────────────────────────
#  Cmdline-Tools Management
# ─────────────────────────────────────────────────────
def _fetch_latest_cmdtools_url() -> str | None:
    """Fetch latest cmdline-tools URL from Google manifest."""
    _info("Fetching latest cmdline-tools URL from Google manifest …")
    try:
        req = urllib.request.Request(config.repo_manifest_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=config.timeout_manifest) as resp:
            xml_text = resp.read().decode("utf-8", errors="replace")
        matches = re.findall(r'commandlinetools-win-(\d+)_latest\.zip', xml_text)
        if not matches:
            return None
        build = max(matches, key=int)
        url   = f"https://dl.google.com/android/repository/commandlinetools-win-{build}_latest.zip"
        _ok(f"Found latest build: {build}")
        return url
    except Exception as exc:
        _warn(f"Manifest fetch failed: {exc}")
        return None


def _extract_cmdtools(zip_path: Path) -> bool:
    """Extract cmdline-tools from zip."""
    target = SDK_ROOT / "cmdline-tools" / "latest"
    _info(f"Extracting to: {target}")
    try:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(tmp_path)

            extracted = tmp_path / "cmdline-tools"
            if not extracted.is_dir():
                candidates = list(tmp_path.rglob("sdkmanager.bat"))
                if candidates:
                    extracted = candidates[0].parent.parent
                else:
                    _fail("sdkmanager.bat not found inside downloaded zip.")
                    return False

            if target.exists():
                shutil.rmtree(target)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(str(extracted), str(target))

        _ok(f"cmdline-tools extracted → {target}")
        return True
    except Exception as exc:
        _fail(f"Extraction failed: {exc}")
        return False


def download_cmdline_tools() -> bool:
    """Download and extract Android cmdline-tools."""
    _section("Auto-Downloading Android cmdline-tools")
    SDK_ROOT.mkdir(parents=True, exist_ok=True)

    url = _fetch_latest_cmdtools_url() or config.cmdtools_fallback_urls[0]
    candidate_urls = [url] + [u for u in config.cmdtools_fallback_urls if u != url]

    zip_path   = Path(tempfile.gettempdir()) / "cmdline-tools.zip"
    downloaded = False

    for attempt_url in candidate_urls:
        _info(f"Downloading: {attempt_url}")
        if _download_with_progress(attempt_url, zip_path):
            downloaded = True
            break
        _warn("Trying next fallback …")

    if not downloaded:
        _fail("All download attempts failed.")
        _warn("Manual download: https://developer.android.com/studio#command-line-tools-only")
        return False

    if not _extract_cmdtools(zip_path):
        return False

    zip_path.unlink(missing_ok=True)

    if SDKMANAGER.exists() and AVDMANAGER.exists():
        _ok("sdkmanager and avdmanager are ready.")
        _ok(f"sdkmanager  → {SDKMANAGER}")
        _ok(f"avdmanager  → {AVDMANAGER}")
        return True
    else:
        _fail("Tools not found after extraction — check SDK path.")
        _info(f"Expected: {TOOLS_BIN}")
        return False


def check_tools() -> bool:
    """Check for Android SDK tools, download if needed."""
    _section("Checking Android SDK Tools")

    tools_ok    = SDKMANAGER.exists() and AVDMANAGER.exists()
    emulator_ok = EMULATOR_EXE.exists()

    if tools_ok:
        _ok(f"sdkmanager  → {SDKMANAGER}")
        _ok(f"avdmanager  → {AVDMANAGER}")
    else:
        _fail("cmdline-tools (sdkmanager / avdmanager) not found.")
        _info(f"Expected location: {TOOLS_BIN}")
        print()
        if _ask("  Auto-download cmdline-tools from Google?") == "n":
            _warn("Install manually: https://developer.android.com/studio#command-line-tools-only")
            return False
        if not download_cmdline_tools():
            return False

    if emulator_ok:
        _ok(f"emulator    → {EMULATOR_EXE}")
    else:
        _warn("emulator not found — will be installed via sdkmanager.")

    return True


# ─────────────────────────────────────────────────────
#  Licenses & AVDs
# ─────────────────────────────────────────────────────
def accept_licenses() -> None:
    """Accept Android SDK licenses."""
    _section("Accepting Android SDK Licenses")
    result = subprocess.run(
        f'echo y | "{SDKMANAGER}" --licenses',
        shell=True, text=True, capture_output=True,
        env=_build_env()
    )
    for line in (result.stdout + result.stderr).splitlines():
        if line.strip() and not _is_java_warning(line):
            print(f"    {line}")
    _ok("Licenses accepted.")


def list_avds() -> list[str]:
    """List existing AVDs."""
    result = _run(f'"{AVDMANAGER}" list avd -c')
    avds   = []
    if not result.stdout.strip():
        return avds
    for line in result.stdout.splitlines():
        ln = line.strip()
        if not ln or _is_java_warning(ln):
            continue
        avds.append(ln)
    return avds


def get_avd_details(name: str) -> dict:
    """Get details of an AVD."""
    result  = _run(f'"{AVDMANAGER}" list avd')
    details = {"name": name, "target": "unknown", "api": "unknown"}
    capture = False
    for line in result.stdout.splitlines():
        if _is_java_warning(line):
            continue
        if f"Name: {name}" in line:
            capture = True
        if capture:
            if "Based on:" in line or "Target:" in line:
                details["target"] = line.strip()
            if "api level" in line.lower():
                parts = line.split()
                for i, p in enumerate(parts):
                    if "level" in p.lower() and i + 1 < len(parts):
                        details["api"] = parts[i + 1].rstrip(",")
            if capture and line.strip() == "":
                break
    return details


def ensure_system_image() -> bool:
    """Install system image for API 33."""
    _section(f"Checking System Image: API {config.api_level} ({config.android_version})")

    if not EMULATOR_EXE.exists():
        _info("Installing emulator + platform-tools via sdkmanager …")
        subprocess.run(
            f'echo y | "{SDKMANAGER}" "emulator" "platform-tools"',
            shell=True, text=True, env=_build_env()
        )
        if EMULATOR_EXE.exists():
            _ok("Emulator installed.")
        else:
            _warn("Emulator still not found — you may need to install Android Studio.")

    result = _run(f'"{SDKMANAGER}" --list_installed')
    if config.system_image in result.stdout:
        _ok("System image already installed.")
        return True

    _info(f"Installing: {config.system_image}")
    _info("This may take several minutes …")

    proc = subprocess.run(
        f'echo y | "{SDKMANAGER}" "{config.system_image}"',
        shell=True, text=True, env=_build_env()
    )
    if proc.returncode == 0:
        _ok("System image installed successfully.")
        return True
    else:
        _fail("System image installation failed.")
        _warn(f'Try manually: sdkmanager "{config.system_image}"')
        return False


# ─────────────────────────────────────────────────────
#  AVD Management
# ─────────────────────────────────────────────────────
def _avd_ini_exists(avd_name: str) -> bool:
    """Check if AVD .ini file exists."""
    return (AVD_HOME / f"{avd_name}.ini").exists()


def delete_avd(name: str) -> bool:
    """Delete an AVD."""
    result = _run(f'echo y | "{AVDMANAGER}" delete avd --name "{name}"')
    if result.returncode == 0:
        _ok(f"AVD '{name}' deleted.")
        return True
    _fail(f"Could not delete '{name}': {result.stderr.strip()}")
    return False


def create_avd(avd_name: str) -> bool:
    """Create a new AVD."""
    _info(f"Creating AVD '{avd_name}' (Pixel 7 · API {config.api_level}) …")
    AVD_HOME.mkdir(parents=True, exist_ok=True)

    cmd = (
        f'echo no | "{AVDMANAGER}" create avd '
        f'--name "{avd_name}" '
        f'--package "{config.system_image}" '
        f'--device "{config.pixel7_device}" '
        f'--force'
    )
    result = _run(cmd)

    if _avd_ini_exists(avd_name):
        _ok(f"AVD '{avd_name}' created successfully.")
        _ok(f"INI: {AVD_HOME / avd_name}.ini")
        return True

    _fail("AVD creation failed — .ini file was not written.")
    _info(f"Expected INI at: {AVD_HOME / avd_name}.ini")
    for label, text in (("stdout", result.stdout), ("stderr", result.stderr)):
        for line in text.splitlines():
            if line.strip() and not _is_java_warning(line):
                _info(f"  [{label}] {line}")
    return False


# ─────────────────────────────────────────────────────
#  BAT Launcher
# ─────────────────────────────────────────────────────
def write_bat(avd_name: str) -> Path | None:
    """Write BAT launcher script to Desktop."""
    desktop = Path.home() / "Desktop"
    desktop.mkdir(parents=True, exist_ok=True)
    bat_path = desktop / "start_emulator.bat"

    jdk = _find_jdk()
    java_home_line = f"SET JAVA_HOME={jdk}\n" if jdk else ""
    java_path_line = f"SET PATH={jdk}\\bin;%PATH%\n" if jdk else ""

    content = (
        "@echo off\n"
        "REM ── Java (required by Android SDK tools) ────────────────\n"
        f"{java_home_line}"
        f"{java_path_line}"
        "\n"
        "REM ── Android SDK paths ─────────────────────────────────────\n"
        "SET ANDROID_SDK_ROOT=%LOCALAPPDATA%\\Android\\Sdk\n"
        "SET EMULATOR=%ANDROID_SDK_ROOT%\\emulator\\emulator.exe\n"
        "\n"
        "IF NOT EXIST \"%EMULATOR%\" (\n"
        "  echo [ERROR] emulator.exe not found: %EMULATOR%\n"
        "  pause & exit /b 1\n"
        ")\n"
        "\n"
        f"echo Starting AVD: {avd_name} ...\n"
        f"\"%EMULATOR%\" -avd {avd_name} ^\n"
        "  -no-window ^\n"
        "  -no-audio ^\n"
        "  -no-boot-anim ^\n"
        "  -no-snapshot ^\n"
        "  -gpu swiftshader_indirect\n"
        "\n"
        "pause\n"
    )

    try:
        bat_path.write_text(content, encoding="utf-8")
        _ok(f"BAT script saved → {bat_path}")
        return bat_path
    except OSError as exc:
        _fail(f"Could not write BAT script: {exc}")
        return None
