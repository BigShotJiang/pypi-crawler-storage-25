"""
Setup script for avdcraft package
"""
from setuptools import setup, find_packages

setup(
    name="avdcraft",
    version="1.0.0",
    description="Automated Android Virtual Device (AVD) setup and management tool — streamlines emulator configuration and creation for Android developers using Android Studio",
    author="Nandhan K",
    author_email="nandhank@scholarpeak.in",
    url="https://github.com/Nandhan-KA/avdcraft",
    packages=find_packages(),
    package_data={"avdcraft": ["config.toml"]},
    install_requires=[
        "pytoml>=0.1.20",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "avdcraft=avdcraft.cli:main",
        ],
    },
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
