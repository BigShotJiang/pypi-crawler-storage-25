# avdcraft

[![PyPI version](https://img.shields.io/pypi/v/avdcraft?style=flat-square&color=blue)](https://pypi.org/project/avdcraft/)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue?style=flat-square)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green?style=flat-square)](LICENSE)
[![GitHub Repo](https://img.shields.io/badge/github-Nandhan--KA%2Favdcraft-blue?style=flat-square&logo=github)](https://github.com/Nandhan-KA/avdcraft)
[![Downloads](https://img.shields.io/pypi/dm/avdcraft?style=flat-square)](https://pypi.org/project/avdcraft/)

```
 █████╗ ██╗   ██╗██████╗  ██████╗██████╗  █████╗ ███████╗████████╗
██╔══██╗██║   ██║██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝
███████║██║   ██║██║  ██║██║     ██████╔╝███████║█████╗     ██║   
██╔══██║╚██╗ ██╔╝██║  ██║██║     ██╔══██╗██╔══██║██╔══╝     ██║   
██║  ██║ ╚████╔╝ ██████╔╝╚██████╗██║  ██║██║  ██║██║        ██║   
╚═╝  ╚═╝  ╚═══╝  ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝        ╚═╝   

        ▸ A V D C R A F T ◂

    Created by: Nandhan K                    | v1.0.0
    ═══════════════════════════════════════════════════════════════
```

**Automated Android Virtual Device (AVD) Setup and Management Tool**

A sophisticated Python utility that streamlines Android Virtual Device configuration and emulator management for Android developers using Android Studio. Automates complex setup tasks, eliminates manual configuration, and accelerates development workflow initialization.

- 📦 **[PyPI Package](https://pypi.org/project/avdcraft/)**
- 🔗 **[GitHub Repository](https://github.com/Nandhan-KA/avdcraft)**
- 📚 **[Documentation](https://github.com/Nandhan-KA/avdcraft/wiki)**

## Features

✅ **Intelligent Java Management** — Auto-detects, validates, and installs Java 17 (Eclipse Temurin) with version verification  
✅ **Automated SDK Acquisition** — Downloads Android cmdline-tools from Google's official manifests with integrity validation  
✅ **System Image Orchestration** — Automatically retrieves and installs required system images (API 33 / Android 13)  
✅ **Streamlined AVD Creation** — Configures Pixel 7 AVD with optimal emulator parameters and hardware profiles  
✅ **Launcher Generation** — Creates platform-specific scripts for immediate emulator deployment  
✅ **Cross-Framework Support** — Works with Flutter, Kotlin, Java, and any Android development framework  
✅ **Zero-Elevation Operation** — Portable installation without requiring administrator privileges  
✅ **Configuration-Driven** — TOML-based configuration system for advanced customization  
✅ **Windows Optimized** — Fully featured Windows support (Linux/macOS support planned)  

## Installation

### From PyPI (Recommended)
```bash
pip install avdcraft
```

Avdcraft is published on [PyPI](https://pypi.org/project/avdcraft/) and can be installed with a single command.

### From Source (Development)
For contributing or using the latest unreleased features:
```bash
git clone https://github.com/Nandhan-KA/avdcraft.git
cd avdcraft
pip install -e .
```

### System Requirements
- **Python**: 3.7 or higher
- **Operating System**: Windows (Linux/macOS support planned)
- **Disk Space**: ~400 MB (for Java + SDK tools + system image)
- **Internet**: Required for initial tool downloads

## Quick Start

### 1. Initialize setup
```bash
avdcraft
```

### 2. Automated Workflow
- Java 17 validation and installation (if required)
- Android SDK cmdline-tools acquisition
- System image provisioning
- AVD configuration and creation
- Launcher script generation

### 3. Ready to Deploy
Your configured emulator is ready for immediate use:
```bash
# Start the emulator
.\start_emulator.bat

# In another terminal, deploy your application
flutter run
# or for native Android development
./gradlew installDebug
```

## Configuration

Fine-tune behavior via `avdcraft/config.toml`:

```toml
[android]
system_image = "system-images;android-33;google_apis;x86_64"
default_name = "Pixel_7_API_33"
api_level = 33

[java]
version_required = 17

[ui]
section_width = 52
timeout_download = 120
```

### Configuration Parameters

- **system_image**: Target system image identifier from Android SDK
- **default_name**: AVD display name and identifier
- **api_level**: Android API level for the virtual device
- **version_required**: Minimum Java version (JDK) required
- **section_width**: Console output formatting width
- **timeout_download**: Download timeout in seconds

## Architecture

```
avdcraft/
├── config.py       # Configuration loader (uses pytoml)
├── core.py         # Core functionality (Java, tools, AVD management)
├── cli.py          # Command-line interface
├── config.toml     # Configuration file
└── __init__.py     # Package initialization
```

## Requirements

- Python 3.7+
- `pytoml` (automatically installed with avdcraft)
- Windows OS
- ~400 MB disk space (for Java + SDK tools + system image)
- No administrator privileges required

## Development

### Environment Setup
```bash
pip install -e ".[dev]"
```

### Testing & Quality Assurance
```bash
# Run comprehensive test suite
pytest -v

# Code formatting with Black
black avdcraft/

# Static analysis with Flake8
flake8 avdcraft/ --max-line-length=100

# Type checking (optional)
mypy avdcraft/ --ignore-missing-imports
```

## License

MIT License © 2026 Nandhan K - see [LICENSE](LICENSE) file for details

## Author

**Nandhan K** - [@Nandhan-KA](https://github.com/Nandhan-KA)  
Email: [nandhank@scholarpeak.in](mailto:nandhank@scholarpeak.in)

---

**Made with ❤️ for Android developers**

## Contributing

Contributions are welcome! Please feel free to:
- Report bugs via [GitHub Issues](https://github.com/Nandhan-KA/avdcraft/issues)
- Submit feature requests and suggestions
- Fork and submit pull requests
- Improve documentation

### Development Setup
```bash
git clone https://github.com/Nandhan-KA/avdcraft.git
cd avdcraft
pip install -e ".[dev]"
```

## Changelog

### v1.0.0 (2026-04-17)
- Initial release with full AVD automation
- Java 17 detection, validation, and installation
- Android SDK cmdline-tools automated acquisition
- Pixel 7 API 33 AVD creation with optimal configuration
- Cross-platform launcher script generation
- TOML-based configuration system
- Comprehensive error handling and user feedback
- Cross-framework support (Flutter, Kotlin, Java, etc.)

## FAQ

**Q: Does avdcraft require administrator privileges?**  
A: No. All components are installed portably in the user's `.android` directory, requiring no elevated permissions.

**Q: How does avdcraft handle existing Java installations?**  
A: The tool performs version validation and automatically uses compatible installations. If no suitable version exists, it performs a fresh installation.

**Q: Can AVD configuration be customized beyond the defaults?**  
A: Yes. Modify `avdcraft/config.toml` to adjust system images, API levels, AVD names, and other parameters.

**Q: Is this limited to Flutter development?**  
A: No. avdcraft works with any Android development framework (Flutter, Kotlin, Java, etc.) and integrates with Android Studio workflows.

**Q: What is the cleanup procedure?**  
A: The pip package can be uninstalled independently. Android SDK and Java installations remain available for other development tools.

**Q: What platforms are supported?**  
A: Currently Windows. Linux and macOS support is planned for future releases.
