# avdcraft Package Structure

```
avdcraft/
├── pyproject.toml              # PEP 518 project configuration
├── setup.py                    # Setuptools configuration (backward compatibility)
├── README.md                   # Project documentation
├── LICENSE                     # MIT License
├── MANIFEST.in                 # Distribution manifest
├── .gitignore                  # Git ignore rules
│
├── avdcraft/                   # Main package directory
│   ├── __init__.py            # Package initialization (exports public API)
│   ├── config.py              # Configuration loader (uses pytoml)
│   ├── core.py                # Core functionality
│   ├── cli.py                 # Command-line interface
│   └── config.toml            # Configuration file (TOML format)
│
└── tests/                      # Test directory
    ├── __init__.py
    └── test_config.py         # Config tests
```

## Installation & Usage

### Install from source
```bash
cd avdcraft
pip install -e .
pip install pytoml>=0.10.2
```

### Run the package
```bash
# Option 1: Use the command-line tool
avdcraft

# Option 2: Use as a Python module
python -m avdcraft.cli

# Option 3: Import and use programmatically
from avdcraft import main
main()
```

## Key Features

### Config-driven (TOML)
All settings are in `avdcraft/config.toml`:
- Java version requirements
- System image specifications
- Download URLs with fallbacks
- UI customization

### Modular Design
- **config.py**: Configuration management
- **core.py**: Core functionality (Java, SDK, AVD management)
- **cli.py**: Command-line orchestration

### Dependency: pytoml
Uses `pytoml` for robust TOML configuration file parsing:
```bash
pip install pytoml>=0.10.2
```

## Distribution

### Build package
```bash
python -m pip install --upgrade build
python -m build
```

### Upload to PyPI
```bash
python -m pip install --upgrade twine
python -m twine upload dist/*
```

## Development

### Install with dev dependencies
```bash
pip install -e ".[dev]"
```

### Run tests
```bash
pytest tests/
```

### Format code
```bash
black avdcraft/ tests/
```

### Lint
```bash
flake8 avdcraft/ tests/
```
