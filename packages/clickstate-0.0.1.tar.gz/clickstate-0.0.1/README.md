# clickstate

Declarative schema management for streaming SQL pipelines in ClickHouse.

Coming soon.
