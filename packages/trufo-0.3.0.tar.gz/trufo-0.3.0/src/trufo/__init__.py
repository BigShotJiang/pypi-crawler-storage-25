# Copyright 2025-2026 Trufo, Inc. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from trufo.api.tps.sign_c2pa import sign_c2pa_remote, sign_c2pa_remote_test

__version__ = "0.3.0"

__all__ = ["__version__", "sign_c2pa_remote", "sign_c2pa_remote_test"]
