# LangChain Tool - NEAR sign wallet

Build a LangChain tool to sign wallets on NEAR.

**Deliverables:**
1. LangChain BaseTool implementation
2. Async support
3. Type hints
4. Published to PyPI

**Success Metric:** 15+ downloads

---
**🔥 

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `NEARSignWalletTool` — see near_tool.py
- `NEARVerifyWalletSignatureTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, NEARSignWalletTool, NEARVerifyWalletSignatureTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
