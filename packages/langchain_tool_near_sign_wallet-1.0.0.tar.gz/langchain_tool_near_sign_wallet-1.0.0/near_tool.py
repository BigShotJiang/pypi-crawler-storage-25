"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - NEAR sign wallet
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class SignWalletInput(BaseModel):
    account_id: str
    private_key: str
    message: str
    network: str = "mainnet"

class NEARSignWalletTool(BaseTool):
    name: str = "near_sign_wallet"
    description: str = (
        "Sign a message with a NEAR wallet private key to prove ownership. "
        "Provide account_id, private_key (ed25519 base58 encoded), and message to sign. "
        "Returns the signature and public key for verification."
    )
    args_schema: Type[BaseModel] = SignWalletInput

    def _run(self, account_id: str, private_key: str, message: str, network: str = "mainnet") -> Dict[str, Any]:
        import base58
        import hashlib
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        except ImportError:
            return {"error": "cryptography package required: pip install cryptography"}
        try:
            key_str = private_key
            if ":" in key_str:
                key_str = key_str.split(":")[-1]
            raw_key = base58.b58decode(key_str)
            if len(raw_key) == 64:
                raw_key = raw_key[:32]
            private_key_obj = Ed25519PrivateKey.from_private_bytes(raw_key)
            public_key_obj = private_key_obj.public_key()
            msg_bytes = message.encode("utf-8")
            signature_bytes = private_key_obj.sign(msg_bytes)
            signature_b58 = base58.b58encode(signature_bytes).decode()
            pub_bytes = public_key_obj.public_bytes_raw()
            pub_b58 = base58.b58encode(pub_bytes).decode()
            account_info = _near_rpc(
                "query",
                {"request_type": "view_account", "finality": "final", "account_id": account_id},
                network=network,
            )
            if "error" in account_info:
                return {"error": f"Account not found: {account_info['error']}"}
            return {
                "account_id": account_id,
                "message": message,
                "signature": signature_b58,
                "public_key": f"ed25519:{pub_b58}",
                "network": network,
                "verified": True,
            }
        except Exception as e:
            return {"error": str(e)}

    async def _arun(self, account_id: str, private_key: str, message: str, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._run(account_id, private_key, message, network)
        )


class VerifyWalletSignatureInput(BaseModel):
    account_id: str
    message: str
    signature: str
    public_key: str
    network: str = "mainnet"

class NEARVerifyWalletSignatureTool(BaseTool):
    name: str = "near_verify_wallet_signature"
    description: str = (
        "Verify a NEAR wallet signature to confirm account ownership. "
        "Provide account_id, original message, signature (base58), and public_key (ed25519:...). "
        "Checks signature validity and that the public key belongs to the account on-chain."
    )
    args_schema: Type[BaseModel] = VerifyWalletSignatureInput

    def _run(self, account_id: str, message: str, signature: str, public_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import base58
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            from cryptography.exceptions import InvalidSignature
        except ImportError:
            return {"error": "cryptography package required: pip install cryptography"}
        try:
            pub_str = public_key.split(":")[-1] if ":" in public_key else public_key
            pub_bytes = base58.b58decode(pub_str)
            sig_bytes = base58.b58decode(signature)
            pub_key_obj = Ed25519PublicKey.from_public_bytes(pub_bytes)
            pub_key_obj.verify(sig_bytes, message.encode("utf-8"))
            sig_valid = True
        except Exception:
            sig_valid = False
        try:
            keys_result = _near_rpc(
                "query",
                {"request_type": "view_access_key_list", "finality": "final", "account_id": account_id},
                network=network,
            )
            keys = keys_result.get("keys", [])
            normalized = public_key if public_key.startswith("ed25519:") else f"ed25519:{public_key}"
            key_on_chain = any(k.get("public_key") == normalized for k in keys)
        except Exception as e:
            key_on_chain = False
        return {
            "account_id": account_id,
            "message": message,
            "signature_valid": sig_valid,
            "key_belongs_to_account": key_on_chain,
            "ownership_proven": sig_valid and key_on_chain,
            "network": network,
        }

    async def _arun(self, account_id: str, message: str, signature: str, public_key: str, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._run(account_id, message, signature, public_key, network)
        )