import argparse
import ast
import logging
import os
import sys
import traceback

import pytest
from dagz.sensor.bootstrap import bootstrap_dagz_logs

logger = logging.getLogger('dagz.plugin')


_capture_plugin = None


_TRISTATE_TRUE = ('y', 'yes', 'true', '1', 'on')
_TRISTATE_FALSE = ('n', 'no', 'false', '0', 'off')


def _tristate(s):
    v = s.lower()
    if v in _TRISTATE_TRUE:
        return True
    if v in _TRISTATE_FALSE:
        return False
    raise argparse.ArgumentTypeError(
        f"expected one of {'/'.join(_TRISTATE_TRUE)} or {'/'.join(_TRISTATE_FALSE)}, got {s!r}"
    )


# Deferred init error handling:
# We can't call pytest.exit() during pytest_load_initial_conftests because it's wrapped
# by other hookwrappers (helpconfig's pytest_cmdline_parse). Any exception raised during
# hookwrapper teardown causes ugly PluggyTeardownRaisedWarning messages.
# Instead, we store the error and call pytest.exit() later in pytest_configure.
_deferred_init_error = None


@pytest.hookimpl(trylast=True)
def pytest_addoption(parser, pluginmanager):
    bootstrap_dagz_logs()
    group = parser.getgroup("exporter", "Dagz options")
    group.addoption(
        "--dagz-workers",
        dest="dagz_workers",
        metavar="dagz-workers",
        action="store",
        type=int,
        help='Use given (or "auto") logical CPU cores for parallel execution',
    )
    group.addoption(
        "--dagz",
        action="store_true",
        help='Enable dagz with default settings',
    )
    group.addoption(
        "--dagz-canary",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    group.addoption(
        "--dagz-skip-redundant",
        "--dagz-exclude-redundant",       # legacy
        "--dagz-optimize-selection",      # legacy
        type=_tristate,
        default=None,
        help='Skip tests proven redundant by code analysis against the baseline. '
             'Tristate; default is inferred from admin config (DB).',
    )
    group.addoption(
        "--dagz-fork-tests",
        default=False,
        action="store_true",
        help=argparse.SUPPRESS,
    )

    group.addoption(
        "--dagz-debug",
        action="store_true",
        default=False,
        help='Run in debug mode with extra output',
    )

    group.addoption(
        "--dagz-logs",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )

    group.addoption(
        "--dagz-debug-1",
        action="store_true",
        default=False,
        help='Run in debug mode with extra output and a single worker',
    )

    group.addoption(
        "--dagz-trace",
        action="store_true",
        default=False,
        help='Run in trace mode with maximum verbosity',
    )

    group.addoption(
        "--dagz-threaded-workers",
        action="store_true",
        help=argparse.SUPPRESS,
    )

    group.addoption(
        "--dagz-capture",
        type=_tristate,
        default=None,
        help='Capture terminal output',
    )

    group.addoption(
        "--dagz-offline",
        default=False,
        action='store_true',
        help='Dont use any dagz servers',
    )

    group.addoption(
        "--dagz-no-baseline",
        "--dagz-no-bl",
        action="store_true",
        help='Don\'t load last test baseline',
    )

    group.addoption(
        '--dagz-max-worker-mem-mb',
        type=int,
        default=0,
        help=argparse.SUPPRESS,
    )

    group.addoption(
        '--dagz-stealing',
        type=ast.literal_eval,
        default=True,
        help=argparse.SUPPRESS,
    )

    group.addoption(
        '--dagz-web-tunnel',
        action='store_true',
        help='Tunnel worker traffic through the web port (TLS). Use when only the web port is reachable.',
    )

    group.addoption(
        '--dagz-preload',
        action='store_true',
        help=argparse.SUPPRESS,
    )

    group.addoption(
        '--dagz-discover-deps',
        action='store_true',
        help=argparse.SUPPRESS,
    )

    group.addoption(
        '--dagz-apply-discovery',
        metavar='JOB',
        default=None,
        help='Apply a saved discovery trace: in-proc-deps modules run as atomic batches. '
             'JOB is a short id (jMMDD.N) or uuid.',
    )

    group.addoption(
        '--dagz-keep-modules',
        action='store_true',
        help=argparse.SUPPRESS,
    )

    group.addoption(
        '--dagz-baseline',
        nargs='*',
        help='Use given baselines (jMMDD.N or uuid or filename)'
    )

    group.addoption(
        '--dagz-rerun-unhealthy',
        nargs='*',
        help='Rerun test unhealthy in specific jobs'
    )

    group.addoption(
        '--dagz-tiny-tests',
        action='store_true',
        default=False,
        help='Batch test results for projects with many short tests',
    )

    group.addoption(
        '--dagz-allow-any-os',
        action='store_true',
        default=False,
        help='Bypass the Linux-only platform check. Unsupported, may not work correctly.',
    )

    group.addoption(
        '--dagz-collect-fixup',
        action='store_true',
        default=False,
        help='Workaround for pytest #12083 (collection fails when mixing file paths and directories).',
    )

    group.addoption(
        '--dagz-disable-sensors',
        '--dagz-no-sensors',
        action='store_true',
        default=False,
        help='Disable DAGZ instrumentation and integration hooks; run as plain pytest.',
    )

    group.addoption(
        "--dagz-always-coverage",
        "--dagz-cov",
        default=None,
        type=_tristate,
        help='Generate full line coverage even when skipping redundant tests'
    )

    # Capture plugin takes over stdout/stderr handles before we get to our pytest_load_initial_conftests(),
    # since it works as a wrapper hook.
    # So we disable it first, do our initialization, then unblock it.

    global _capture_plugin
    _capture_plugin = pluginmanager.get_plugin('capture')
    pluginmanager.set_blocked('capture')

@pytest.hookimpl(hookwrapper=True)
def pytest_load_initial_conftests(early_config, parser, args):
    global _deferred_init_error
    try:
        _ = parser
        early_args = early_config.known_args_namespace

        enable = os.environ.get('DAGZ_ENABLE')
        if enable is not None:
            enable = enable.lower()

            if enable in ('0', 'no', 'false', 'off'):
                logger.info('DAGZ disabled by environment variable.')
                return

            if enable in ('1', 'yes', 'true', 'on'):
                logger.info('DAGZ enabled by environment variable.')
            else:
                logger.warning('Unexpected DAGZ_ENABLE: %s', enable)
                return

        elif (early_args.dagz
              or early_args.dagz_debug
              or early_args.dagz_debug_1
              or early_args.dagz_trace
              or early_args.dagz_logs
              or early_args.dagz_offline
              or early_args.dagz_skip_redundant
              or early_args.dagz_rerun_unhealthy
              or early_args.dagz_threaded_workers
              or early_args.dagz_workers):

            logger.info('DAGZ enabled by command line.')
        else:
            logger.info('DAGZ not enabled.')
            return

        # We're active!
        # Don't initialize if just showing help — argparse handles --help
        # before it reaches early_args, so check the raw args list
        if '-h' in args or '--help' in args:
            return

        # Platform check: DAGZ only supports Linux
        if sys.platform != 'linux':
            if not early_args.dagz_allow_any_os:
                add_host = "" if sys.platform == 'darwin' else " --add-host=host.docker.internal:host-gateway"
                docker_hint = f"  docker run --env DAGZ_URL=http://host.docker.internal:29111{add_host} ..."
                print(
                    f"\nDAGZ is only supported on Linux. "
                    f"Run tests inside a Docker container instead:\n\n"
                    f"{docker_hint}\n\n"
                    f"To proceed anyway, pass --dagz-allow-any-os (unsupported, may not work correctly).",
                    flush=True,
                )
                os._exit(1)

        # Trace overrides debug flags
        if early_args.dagz_trace or os.environ.get('DAGZ_TRACE', '0') == '1':
            early_args.dagz_trace = True
            early_args.dagz_debug = True
            os.environ['DAGZ_TRACE'] = '1'

        if early_args.dagz_debug_1:
            early_args.dagz_workers = 1
            early_args.dagz_debug = True

        if early_args.dagz_debug or early_args.dagz_logs:
            bootstrap_dagz_logs(logging.DEBUG)
        else:
            bootstrap_dagz_logs(logging.INFO)

        import dagz
        if early_args.dagz_offline:
            logger.info("DAGZ: running in offline mode")

        dagz.pytest._enabled = True
        os.environ['DAGZ_ENABLED'] = '1'
        os.environ['DAGZ'] = '1'

        import dagz.sensor.o3_binding

        from dagz.pytest.hacks import disable_datadog, disable_conflicting_plugins, disable_thread_pools

        disable_thread_pools()
        disable_datadog(early_config.pluginmanager)
        disable_conflicting_plugins(early_config)

        # Logs now go to o3 tracer; release the logger level
        from dagz.pytest.test_session import TestSession
        try:
            session = TestSession(early_config, args)
        except BaseException as exc:
            from dagz.sensor.o3 import DagzUserError
            if isinstance(exc, DagzUserError):
                sys.stderr.write(f"\n{exc}\n")
            else:
                traceback.print_exc()
            sys.stderr.write(f"\nDAGZ session failed to start: {exc}\n")
            sys.stderr.flush()
            os._exit(1)
        early_config.pluginmanager.register(session, 'dagz_session')

    finally:
        # Disable global capturing, otherwise stdout/err writes will fail
        early_config.known_args_namespace.capture = 'no'

        # Re-enable pytest capture plugin *after* we've set up dagz capturing.
        # Otherwise, it'll restore stdout/err to our pty fd's on unconfigure, which will be closed by then.
        # pluggy.PluginManager.unblock() was added in 1.6.0; older pluggy lacks it.
        if hasattr(early_config.pluginmanager, 'unblock'):
            early_config.pluginmanager.unblock('capture')
        else:
            early_config.pluginmanager._name2plugin.pop('capture', None)
        capture_init = _capture_plugin.__dict__['pytest_load_initial_conftests'](early_config=early_config)
        yield from capture_init

    session.o3.finish_load()
