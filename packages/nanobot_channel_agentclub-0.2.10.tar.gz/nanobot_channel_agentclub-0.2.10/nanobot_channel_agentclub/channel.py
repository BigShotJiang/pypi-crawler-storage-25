"""Agent Club channel implementation for Nanobot.

Connects a Nanobot agent to the Agent Club IM server via Socket.IO
(auth = agent token) and a small HTTP surface for file upload and group
roster lookup.

Feature parity with the OpenClaw channel of the same server:

* ``mark_read`` ACK per inbound message — advances the server-side read
  cursor so messages aren't re-delivered via ``offline_messages`` on the
  next reconnect.
* ``<at user_id="…">name</at>`` @mention wire format, both inbound
  (preserved + system hint injected with the group roster) and outbound
  (parsed out of the agent's reply text to populate the ``mentions``
  field of ``send_message``).
* Recent-id dedup so duplicate deliveries (e.g. ACK raced a reconnect)
  don't produce duplicate agent runs.
* Two orthogonal allowlists, intersected (both must pass):
    - ``allow_from``      — user_id allowlist. Empty = deny everyone.
                            ``["*"]`` matches any id; otherwise explicit
                            user_ids.
    - ``allow_from_kind`` — role allowlist. Empty = deny every kind.
                            Entries must be ``"*"`` (any kind), ``"human"``
                            (non-agent senders), or ``"agent"`` (agent
                            senders); anything else raises at config
                            validation time.
  The intersection keeps the id-based and role-based filters independent
  so either can be tightened without touching the other — e.g.
  ``allow_from=["*"]`` + ``allow_from_kind=["human"]`` lets every human
  through but no agents.

``streaming`` is intentionally not implemented yet — the IM server has
no "edit message" event, so every chunk would become a separate
message. If/when a streaming protocol is added server-side, override
``send_delta`` here.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import tempfile
from collections import OrderedDict
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import aiohttp
import socketio
from loguru import logger
from pydantic import BaseModel, Field, field_validator

from nanobot.bus.events import OutboundMessage
from nanobot.bus.queue import MessageBus
from nanobot.channels.base import BaseChannel


_LOG_PREFIX = "[agentclub.nanobot]"

# Max inbound message ids to remember for dedup. 1024 matches the
# OpenClaw-channel gateway's dedup window.
_DEDUP_CAPACITY = 1024

# Wire format for @mentions, mirrored byte-for-byte from the OpenClaw
# channel so messages round-trip unchanged between the two adapters.
#   <at user_id="uuid-or-all">display name</at>
_AT_TAG_RE = re.compile(r'<at user_id="([^"]+)">([^<]*)</at>')


# Chat-id prefixes. The IM server mints chat_ids carrying ``gc_``
# (group chat) and ``dc_`` (direct chat) prefixes natively — same
# Stripe-style scheme the channel used to synthesize locally, now a
# server-side invariant. The two prefixes are intentionally symmetric
# (``[gd]c_``) so they map 1:1 onto ``chat_type ∈ {'group','direct'}``.
# The channel just forwards them; no encode/decode layer beyond
# extracting ``chat_type`` from the prefix on outbound.
_GROUP_PREFIX = "gc_"
_DIRECT_PREFIX = "dc_"
_SOCKETIO_INFINITE_RECONNECT_ATTEMPTS = 0
_INITIAL_HEARTBEAT_SECONDS = 30.0
_INITIAL_RETRY_DELAY = 1.0
_MAX_RETRY_DELAY = 30.0
_MIN_HEARTBEAT_SLEEP_SECONDS = 1.0
_SERVER_RESPONSE_TIMEOUT_SECONDS = 10
_HTTP_OK = 200
_LOG_MESSAGE_PREVIEW_CHARS = 80
_LOG_BODY_PREVIEW_CHARS = 200


def _decode_chat_id(encoded: str) -> tuple[str, str] | None:
    """Recover ``(chat_type, chat_id)`` from a prefixed id, or ``None``.

    The id is returned **with its prefix intact** — the IM server
    expects ``gc_…`` / ``dc_…`` on every write, so we forward whatever
    the agent echoed back.
    """
    if encoded.startswith(_GROUP_PREFIX):
        return "group", encoded
    if encoded.startswith(_DIRECT_PREFIX):
        return "direct", encoded
    return None


def _extract_mention_user_ids(text: str) -> list[str]:
    """Pull unique user_ids out of ``<at user_id="…">`` tags."""
    if not text:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for match in _AT_TAG_RE.finditer(text):
        uid = (match.group(1) or "").strip()
        if not uid or uid in seen:
            continue
        seen.add(uid)
        out.append(uid)
    return out


def _retry_delay_seconds(attempt: int) -> float:
    """Exponential backoff capped at 30 seconds.

    ``attempt`` is 1-based: 1 → 1s, 2 → 2s, 3 → 4s, ... then clamp.
    """
    if attempt <= 1:
        return _INITIAL_RETRY_DELAY
    return min(_MAX_RETRY_DELAY, _INITIAL_RETRY_DELAY * (2 ** (attempt - 1)))


def _has_mention_tag(text: str) -> bool:
    return bool(text) and bool(_AT_TAG_RE.search(text))


def _build_roster_hint(
    roster: list[dict[str, Any]],
    inbound_has_at_tags: bool,
    agent_user_id: str | None,
) -> str | None:
    """Return a system hint describing the mention protocol, or None.

    Mirrors the hint injected by the OpenClaw channel so the agent gets
    the same guidance regardless of which adapter is running.
    """
    if not inbound_has_at_tags and not roster:
        return None

    parts: list[str] = [
        'The content may include mention tags of the form '
        '<at user_id="...">name</at>. '
        'Treat these as real mentions of Agent Club users (or bots).'
    ]
    if agent_user_id:
        parts.append(f'If user_id is "{agent_user_id}", that mention refers to you.')
    if roster:
        lines = []
        for member in roster:
            uid = member.get("id", "")
            name = member.get("display_name") or uid
            suffix = ""
            if uid and uid == agent_user_id:
                suffix = " (you)"
            elif member.get("is_agent"):
                suffix = " (bot)"
            lines.append(f'- {name}: user_id="{uid}"{suffix}')
        parts.append(
            'To @mention someone in your reply, emit the same tag: '
            '<at user_id="UUID">name</at>. Use user_id="all" for '
            '@everyone. Room roster:\n' + "\n".join(lines)
        )
    return " ".join(parts)


class AgentClubConfig(BaseModel):
    """Agent Club channel configuration (stored under ``channels.agentclub``).

    Environment variables ``AGENTCLUB_SERVER_URL`` and
    ``AGENTCLUB_AGENT_TOKEN`` take precedence over the JSON values so
    secrets don't have to be committed to ``nanobot.json``.
    """

    enabled: bool = False
    server_url: str = ""
    agent_token: str = ""
    # ``allow_from`` is consumed by ``BaseChannel.is_allowed``: entries
    # are user_ids, plus the wildcard ``"*"``. An empty list denies
    # everyone (default-deny, matching feishu/openclaw). Role-based
    # filtering lives in ``allow_from_kind`` below.
    allow_from: list[str] = Field(default_factory=list)
    # Role allowlist, intersected with ``allow_from``. Valid entries:
    # ``"*"`` (any kind), ``"human"`` (non-agent senders), ``"agent"``
    # (agent senders). Default ``[]`` denies every kind, so you must
    # opt in explicitly — same default-deny philosophy as ``allow_from``.
    allow_from_kind: list[str] = Field(default_factory=list)
    require_mention: bool = True
    streaming: bool = False

    @field_validator("allow_from_kind")
    @classmethod
    def _validate_allow_from_kind(cls, v: list[str]) -> list[str]:
        # Fail loud at load time on typos like ``"humans"`` / ``"bot"``
        # — silently ignoring them would look like "default-deny is
        # broken" to an operator.
        allowed = {"*", "human", "agent"}
        invalid = [k for k in v if k not in allowed]
        if invalid:
            raise ValueError(
                f"allow_from_kind entries must be one of {sorted(allowed)}; "
                f"got invalid tokens: {invalid}"
            )
        return v


class AgentClubChannel(BaseChannel):
    """Agent Club IM channel for Nanobot.

    Single-socket, single-agent: one plugin instance represents one
    agent identity on the IM server. Multi-agent setups should spin up
    multiple nanobot processes (or someday multiple accounts).
    """

    name = "agentclub"
    display_name = "Agent Club"

    @classmethod
    def default_config(cls) -> dict[str, Any]:
        return AgentClubConfig().model_dump(by_alias=True)

    def __init__(self, config: Any, bus: MessageBus):
        if isinstance(config, dict):
            config = AgentClubConfig.model_validate(config)
        super().__init__(config, bus)
        self.config: AgentClubConfig = config

        # Environment overrides win over JSON so secrets can stay out of
        # the config file.
        self._server_url: str = (
            os.environ.get("AGENTCLUB_SERVER_URL")
            or self.config.server_url
            or ""
        ).rstrip("/")
        self._agent_token: str = (
            os.environ.get("AGENTCLUB_AGENT_TOKEN") or self.config.agent_token or ""
        )

        self._sio: socketio.AsyncClient | None = None
        self._http: aiohttp.ClientSession | None = None
        self._tmp_dir: str | None = None
        self._stop_event: asyncio.Event | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._auth_future: asyncio.Future | None = None
        # Cadence of application-level heartbeats. Seeded with a sane
        # default and overwritten when `auth_ok` arrives so the server's
        # Config acts as the single source of truth.
        self._heartbeat_interval: float = _INITIAL_HEARTBEAT_SECONDS

        # Populated on ``auth_ok``
        self._agent_user_id: str | None = None
        self._display_name: str | None = None

        # Second-layer dedup. The IM server won't re-emit a message once
        # we ACK it via ``mark_read``, but an ACK that raced a
        # reconnect can still produce a duplicate — this catches it.
        self._seen_message_ids: OrderedDict[str, None] = OrderedDict()

    # ----------------------------------------------------------------
    # BaseChannel lifecycle
    # ----------------------------------------------------------------

    async def start(self) -> None:
        if not self._server_url:
            logger.error("{} server_url is not configured", _LOG_PREFIX)
            return
        if not self._agent_token:
            logger.error("{} agent_token is not configured", _LOG_PREFIX)
            return

        self._running = True
        self._tmp_dir = tempfile.mkdtemp(prefix="agentclub_")
        self._stop_event = asyncio.Event()
        self._http = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self._agent_token}"}
        )
        try:
            attempt = 0
            while self._running:
                self._sio = socketio.AsyncClient(
                    reconnection=True,
                    reconnection_attempts=_SOCKETIO_INFINITE_RECONNECT_ATTEMPTS,
                    reconnection_delay=_INITIAL_RETRY_DELAY,
                    reconnection_delay_max=_MAX_RETRY_DELAY,
                )
                self._auth_future = asyncio.get_running_loop().create_future()
                self._register_sio_handlers(self._sio)

                logger.info("{} connecting to {}", _LOG_PREFIX, self._server_url)
                try:
                    await self._sio.connect(
                        self._server_url,
                        auth={"agent_token": self._agent_token},
                        transports=["websocket", "polling"],
                    )
                    await asyncio.wait_for(
                        self._auth_future,
                        timeout=_SERVER_RESPONSE_TIMEOUT_SECONDS,
                    )
                except Exception as exc:
                    attempt += 1
                    delay = _retry_delay_seconds(attempt)
                    logger.warning(
                        "{} connect failed (attempt {}): {} ; retrying in {}s",
                        _LOG_PREFIX,
                        attempt,
                        exc,
                        delay,
                    )
                    await self._reset_socket()
                    if await self._wait_for_retry(delay):
                        break
                    continue

                self._auth_future = None
                attempt = 0
                self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                logger.info("{} started", _LOG_PREFIX)
                await self._stop_event.wait()
                break
        finally:
            await self._cleanup()

    async def stop(self) -> None:
        self._running = False
        if self._stop_event is not None:
            self._stop_event.set()
        await self._cleanup()

    async def _heartbeat_loop(self) -> None:
        """Emit an application-level heartbeat while connected.

        The IM server derives our online status from the `last_active_at`
        timestamp we bump here (plus any `send_message`/`mark_read` we
        emit). If this loop stops (process hung, task cancelled) the
        server will eventually mark us offline even if the socket itself
        is still held open by an uncooperative network path.

        Cadence is sourced from `self._heartbeat_interval`, which starts
        at a safe default and is overwritten from the `auth_ok` payload
        so the server owns the schedule."""
        try:
            while self._running:
                if self._sio is not None and self._sio.connected:
                    try:
                        await self._sio.emit("heartbeat")
                    except Exception as exc:
                        logger.debug("{} heartbeat emit failed: {}", _LOG_PREFIX, exc)
                # Re-read every iteration so an `auth_ok` mid-run (on
                # reconnect) takes effect on the next beat.
                await asyncio.sleep(
                    max(_MIN_HEARTBEAT_SLEEP_SECONDS, self._heartbeat_interval)
                )
        except asyncio.CancelledError:
            pass

    async def _cleanup(self) -> None:
        """Tear down in a fixed order: heartbeat, sio, http, tmp dir."""
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except (asyncio.CancelledError, Exception):
                pass
            self._heartbeat_task = None
        await self._reset_socket()
        self._agent_user_id = None
        self._display_name = None
        if self._http is not None:
            try:
                await self._http.close()
            except Exception as exc:
                logger.warning("{} http close error: {}", _LOG_PREFIX, exc)
            self._http = None
        if self._tmp_dir and os.path.isdir(self._tmp_dir):
            try:
                for name in os.listdir(self._tmp_dir):
                    try:
                        os.remove(os.path.join(self._tmp_dir, name))
                    except OSError:
                        pass
                os.rmdir(self._tmp_dir)
            except OSError:
                pass
        self._tmp_dir = None
        logger.info("{} stopped", _LOG_PREFIX)

    async def _reset_socket(self) -> None:
        """Disconnect and drop the current Socket.IO client if present."""
        if self._sio is None:
            return
        try:
            await self._sio.disconnect()
        except Exception as exc:
            logger.warning("{} disconnect error: {}", _LOG_PREFIX, exc)
        finally:
            self._sio = None
            self._auth_future = None

    async def _wait_for_retry(self, delay: float) -> bool:
        """Sleep until the next retry or exit early when stop() fires.

        Returns ``True`` when stop was requested during the wait.
        """
        if self._stop_event is None:
            await asyncio.sleep(delay)
            return False
        try:
            await asyncio.wait_for(self._stop_event.wait(), timeout=delay)
            return True
        except asyncio.TimeoutError:
            return False

    # ----------------------------------------------------------------
    # Socket.IO event wiring
    # ----------------------------------------------------------------

    def _register_sio_handlers(self, sio: socketio.AsyncClient) -> None:
        @sio.event
        async def connect() -> None:
            logger.info("{} socket connected", _LOG_PREFIX)

        @sio.event
        async def disconnect() -> None:
            logger.warning("{} socket disconnected", _LOG_PREFIX)

        @sio.on("auth_ok")
        async def _on_auth_ok(data: dict[str, Any]) -> None:
            self._agent_user_id = data.get("user_id")
            self._display_name = data.get("display_name")
            interval = data.get("heartbeat_interval")
            try:
                interval_val = float(interval) if interval is not None else 0.0
            except (TypeError, ValueError):
                interval_val = 0.0
            if interval_val > 0:
                self._heartbeat_interval = interval_val
            logger.info(
                "{} authenticated as {} ({}), heartbeat={}s",
                _LOG_PREFIX,
                self._display_name,
                self._agent_user_id,
                self._heartbeat_interval,
            )
            if self._auth_future is not None and not self._auth_future.done():
                self._auth_future.set_result(data)

        @sio.on("error")
        async def _on_error(data: dict[str, Any]) -> None:
            logger.warning("{} server error: {}", _LOG_PREFIX, data)

        @sio.on("new_message")
        async def _on_new_message(data: dict[str, Any]) -> None:
            await self._process_inbound(data)

        @sio.on("offline_messages")
        async def _on_offline_messages(msgs: list[dict[str, Any]]) -> None:
            logger.info("{} received {} offline message(s)", _LOG_PREFIX, len(msgs))
            for msg in msgs:
                await self._process_inbound(msg)

    # ----------------------------------------------------------------
    # Inbound pipeline
    # ----------------------------------------------------------------

    async def _process_inbound(self, msg: dict[str, Any]) -> None:
        """Filter + normalize a raw ``new_message`` payload and hand to the bus."""
        try:
            message_id = msg.get("id") or ""
            sender_id = msg.get("sender_id") or ""
            sender_name = msg.get("sender_name") or sender_id
            sender_is_agent = bool(msg.get("sender_is_agent"))
            chat_type = msg.get("chat_type") or "direct"
            chat_id = msg.get("chat_id") or ""
            content = msg.get("content") or ""
            content_type = msg.get("content_type") or "text"
            file_url = msg.get("file_url") or ""
            file_name = msg.get("file_name") or ""
            mentions_raw = msg.get("mentions") or []
            mentions: list[str] = [m for m in mentions_raw if isinstance(m, str)]

            # Skip the agent's own echo-back
            if sender_id and sender_id == self._agent_user_id:
                return

            # Dedup — second layer of defense on top of server-side
            # mark_read. OrderedDict keeps FIFO eviction O(1).
            if message_id:
                if message_id in self._seen_message_ids:
                    # Re-ACK in case the previous ACK was lost in flight.
                    await self._ack(message_id)
                    return
                self._seen_message_ids[message_id] = None
                while len(self._seen_message_ids) > _DEDUP_CAPACITY:
                    self._seen_message_ids.popitem(last=False)

            # Access control, split into two AND'd gates:
            #   1. id allowlist — BaseChannel.is_allowed (``allow_from``).
            #   2. role allowlist — our extension (``allow_from_kind``).
            # Both default-deny. We do the pre-flight here instead of
            # letting BaseChannel._handle_message do the id check on
            # its own so we can ACK the message — without the ACK the
            # server would re-deliver via ``offline_messages`` every
            # reconnect.
            if not self.is_allowed(sender_id):
                logger.info(
                    "{} denied message from {} (not in allow_from)",
                    _LOG_PREFIX,
                    sender_name,
                )
                await self._ack(message_id)
                return
            if not self._is_sender_kind_allowed(sender_is_agent):
                logger.info(
                    "{} denied message from {} (kind not in allow_from_kind)",
                    _LOG_PREFIX,
                    sender_name,
                )
                await self._ack(message_id)
                return

            # Group-chat @mention gate
            mentions_bot = (
                bool(self._agent_user_id) and self._agent_user_id in mentions
            ) or ("all" in mentions)
            if (
                chat_type == "group"
                and self.config.require_mention
                and not mentions_bot
            ):
                logger.debug(
                    "{} skipping group message from {} (no @mention)",
                    _LOG_PREFIX,
                    sender_name,
                )
                await self._ack(message_id)
                return

            # Attachments: download to a temp file so the agent can read them
            media_paths: list[str] = []
            if file_url and content_type != "text":
                local_path = await self._download_attachment(
                    file_url, file_name or message_id or "attachment"
                )
                if local_path:
                    media_paths.append(local_path)

            # Compose the text surface. For file-only payloads we still
            # emit a description so the LLM knows *something* arrived.
            text = content
            if file_url and content_type != "text":
                label = file_name or file_url
                bracket = f"[{content_type}: {label}]"
                text = f"{text}\n{bracket}" if text else bracket

            if not text.strip() and not media_paths:
                await self._ack(message_id)
                return

            # System hint: teach the LLM about the @mention wire format
            # and (for groups) the current roster. Only injected when
            # there's something to gain (roster available or message
            # already contains tags).
            roster: list[dict[str, Any]] = []
            if chat_type == "group" and chat_id:
                roster = await self._list_group_members(chat_id)
            hint = _build_roster_hint(
                roster=roster,
                inbound_has_at_tags=_has_mention_tag(text),
                agent_user_id=self._agent_user_id,
            )
            prompt = f"{text}\n\n[System: {hint}]" if hint else text

            # Log AFTER all filter decisions so grepping logs gives an
            # honest "these are the messages that actually reached the
            # agent" answer.
            logger.info(
                "{} inbound [{}:{}] from {}: {}",
                _LOG_PREFIX,
                chat_type,
                chat_id,
                sender_name,
                text[:_LOG_MESSAGE_PREVIEW_CHARS],
            )

            # ACK immediately on accept — "plugin has taken
            # responsibility". Matches the semantics used by the
            # OpenClaw channel and prevents reply storms when the
            # socket reconnects mid-run.
            await self._ack(message_id)

            # The IM server already hands us a prefixed chat_id
            # (``gc_…`` / ``dc_…``); MessageTool inherits it as its
            # ``default_chat_id`` and the LLM sees it echoed in
            # Nanobot's Runtime-Context block. ``send()`` recovers the
            # chat_type from that prefix alone, statelessly, so the
            # bus-facing form is just the server form, untouched.
            await self._handle_message(
                sender_id=sender_id,
                chat_id=chat_id,
                content=prompt,
                media=media_paths,
                metadata={
                    "message_id": message_id,
                    "chat_type": chat_type,
                    "chat_id": chat_id,
                    "sender_name": sender_name,
                    "content_type": content_type,
                    "inbound_mentions": mentions,
                    "mentioned_bot": chat_type == "direct" or mentions_bot,
                },
            )
        except Exception as exc:  # defensive: one bad message must not kill the loop
            logger.exception("{} error processing inbound: {}", _LOG_PREFIX, exc)

    def _is_sender_kind_allowed(self, sender_is_agent: bool) -> bool:
        """Evaluate ``allow_from_kind`` against a sender's role.

        Empty list denies every kind (default-deny). ``"*"`` waves
        everyone through regardless of role.
        """
        kinds = self.config.allow_from_kind or []
        if "*" in kinds:
            return True
        if sender_is_agent:
            return "agent" in kinds
        return "human" in kinds

    async def _ack(self, message_id: str) -> None:
        """Advance the server-side read cursor for ``message_id``.

        No-op when the id is empty or we're disconnected — the server
        will just re-deliver via ``offline_messages`` on reconnect,
        which is the desired at-least-once fallback.
        """
        if not message_id or self._sio is None or not self._sio.connected:
            return
        try:
            await self._sio.emit("mark_read", {"message_ids": [message_id]})
        except Exception as exc:
            logger.warning(
                "{} mark_read failed for {}: {}", _LOG_PREFIX, message_id, exc
            )

    # ----------------------------------------------------------------
    # Outbound pipeline
    # ----------------------------------------------------------------

    async def send(self, msg: OutboundMessage) -> None:
        """Dispatch one outbound agent message to the IM server."""
        if self._sio is None or not self._sio.connected:
            logger.warning("{} not connected; dropping outbound", _LOG_PREFIX)
            return

        meta = msg.metadata or {}

        # We don't implement streaming yet — collapse progress / tool
        # hints / stream events to no-ops so the channel manager's
        # dispatcher doesn't spam the IM with partial text.
        if (
            meta.get("_progress")
            or meta.get("_tool_hint")
            or meta.get("_stream_delta")
            or meta.get("_stream_end")
        ):
            return

        chat_type, chat_id = self._resolve_chat_target(msg, meta)
        if not chat_id:
            logger.warning("{} outbound missing chat_id; dropping", _LOG_PREFIX)
            return

        # Upload any attachments first. Each one becomes its own
        # ``send_message`` call so the IM UI renders file bubbles
        # separately from the reply text. Mirroring the Web UI, only
        # local file paths are accepted — remote http(s) URLs are
        # skipped with a warning so the agent's logs make the misuse
        # obvious.
        media_paths: list[str] = list(getattr(msg, "media", None) or [])
        for path in media_paths:
            if self._looks_like_remote_url(path):
                logger.warning(
                    "{} skipping remote URL in agent reply "
                    "(only local files are supported): {}",
                    _LOG_PREFIX,
                    path,
                )
                continue
            uploaded = await self._upload_attachment(path)
            if not uploaded:
                continue
            await self._emit_send_message(
                {
                    "chat_type": chat_type,
                    "chat_id": chat_id,
                    "content": "",
                    "content_type": self._normalize_upload_content_type(uploaded.get("content_type")),
                    "file_url": uploaded["url"],
                    "file_name": uploaded["filename"],
                }
            )

        content = (msg.content or "").strip()
        if not content:
            return

        # Extract @mention user_ids from the reply text so the IM
        # server can push unread-badge updates to the mentioned users
        # without re-parsing the text itself.
        payload: dict[str, Any] = {
            "chat_type": chat_type,
            "chat_id": chat_id,
            "content": content,
            "content_type": "text",
        }
        mentions = _extract_mention_user_ids(content)
        if mentions:
            payload["mentions"] = mentions
        await self._emit_send_message(payload)

    def _resolve_chat_target(
        self, msg: OutboundMessage, meta: dict[str, Any]
    ) -> tuple[str, str]:
        """Figure out ``(chat_type, chat_id)`` for the outbound envelope.

        Resolution order:

        1. ``metadata["chat_type"]`` + ``metadata["chat_id"]`` — the
           only source ``_process_inbound`` can fully vouch for. In
           practice Nanobot's ``MessageTool`` strips metadata when
           constructing the outbound, so this path rarely hits in the
           normal LLM flow; still useful for channel-native helpers
           or hand-written call sites.
        2. ``gc_<id>`` / ``dc_<id>`` prefix on the chat_id itself. This
           is the stateless happy path: the IM server hands us
           prefixed ids on inbound, the LLM echoes them back via
           ``MessageTool``, and we recover the type from the prefix
           alone — no cache, no state, no worry about the agent
           replying to a chat it hasn't seen via inbound in this
           process's lifetime.

        A bare (un-prefixed) chat_id with no metadata is treated as
        malformed: we return empty strings so ``send`` drops the
        message with a warning, instead of silently mis-routing it
        as a direct chat (the IM server would reject it anyway via
        its own ``assert_kind`` guard).
        """
        if meta.get("chat_type") and meta.get("chat_id"):
            return str(meta["chat_type"]), str(meta["chat_id"])

        raw = msg.chat_id or ""
        decoded = _decode_chat_id(raw)
        if decoded is not None:
            return decoded

        logger.warning(
            "{} outbound chat_id {!r} lacks gc_/dc_ prefix and no "
            "chat_type metadata; dropping",
            _LOG_PREFIX,
            raw,
        )
        return "", ""

    async def _emit_send_message(self, payload: dict[str, Any]) -> dict[str, Any] | None:
        if self._sio is None or not self._sio.connected:
            logger.warning("{} send_message skipped: not connected", _LOG_PREFIX)
            return None
        try:
            ack = await self._sio.call(
                "send_message",
                payload,
                timeout=_SERVER_RESPONSE_TIMEOUT_SECONDS,
            )
        except Exception as exc:
            logger.warning(
                "{} send_message failed: chat_type={} chat_id={} "
                "content_type={} error={}",
                _LOG_PREFIX,
                payload.get("chat_type"),
                payload.get("chat_id"),
                payload.get("content_type"),
                exc,
            )
            return None
        if not isinstance(ack, dict):
            logger.warning(
                "{} send_message failed: chat_type={} chat_id={} "
                "content_type={} error=Invalid send_message ack: {!r}",
                _LOG_PREFIX,
                payload.get("chat_type"),
                payload.get("chat_id"),
                payload.get("content_type"),
                ack,
            )
            return None
        if not ack.get("ok"):
            logger.warning(
                "{} send_message failed: chat_type={} chat_id={} "
                "content_type={} error={}",
                _LOG_PREFIX,
                payload.get("chat_type"),
                payload.get("chat_id"),
                payload.get("content_type"),
                ack.get("error") or "send_message failed",
            )
            return None
        return ack

    @staticmethod
    def _looks_like_remote_url(path: str) -> bool:
        """True if ``path`` looks like an http(s) URL.

        Mirrors ``isRemoteHttpUrl`` on the TypeScript side — agents must
        download remote assets locally before handing us the path, same
        as human users uploading from the Web UI.
        """
        if not path:
            return False
        lower = path.lower()
        return lower.startswith("http://") or lower.startswith("https://")

    @staticmethod
    def _normalize_upload_content_type(value: str | None) -> str:
        """Normalize the ``content_type`` echoed by ``/api/agent/upload``.

        The IM server currently returns the already-bucketed value
        (``"image"`` / ``"audio"`` / ``"video"`` / ``"file"``), but we
        also accept real MIME strings (``"image/png"``) so this helper
        stays correct if the server ever switches formats. Anything
        unrecognised falls back to ``"file"``.
        """
        if not value:
            return "file"
        lower = value.lower()
        if lower == "image" or lower.startswith("image/"):
            return "image"
        if lower == "audio" or lower.startswith("audio/"):
            return "audio"
        if lower == "video" or lower.startswith("video/"):
            return "video"
        return "file"

    # ----------------------------------------------------------------
    # HTTP helpers (upload / download / roster)
    # ----------------------------------------------------------------

    async def _upload_attachment(self, local_path: str) -> dict[str, Any] | None:
        """POST ``file`` to ``/api/agent/upload``; return ``{url, filename, content_type}``."""
        if self._http is None:
            return None
        path = Path(local_path)
        if not path.is_file():
            logger.warning("{} upload skipped; not a file: {}", _LOG_PREFIX, local_path)
            return None
        url = urljoin(self._server_url + "/", "api/agent/upload")
        try:
            with path.open("rb") as fh:
                data = aiohttp.FormData()
                data.add_field(
                    "file", fh, filename=path.name, content_type="application/octet-stream"
                )
                async with self._http.post(url, data=data) as resp:
                    if resp.status != _HTTP_OK:
                        body = await resp.text()
                        logger.warning(
                            "{} upload failed HTTP {}: {}",
                            _LOG_PREFIX,
                            resp.status,
                            body[:_LOG_BODY_PREVIEW_CHARS],
                        )
                        return None
                    return await resp.json()
        except Exception as exc:
            logger.warning("{} upload error for {}: {}", _LOG_PREFIX, local_path, exc)
            return None

    async def _download_attachment(
        self, file_url: str, file_name: str
    ) -> str | None:
        """GET an inbound attachment URL and save it under the plugin's temp dir."""
        if not self._tmp_dir or self._http is None:
            return None
        absolute_url = (
            file_url if re.match(r"^https?://", file_url) else urljoin(self._server_url + "/", file_url.lstrip("/"))
        )
        # Sanitize filename: strip any directory component.
        safe_name = Path(file_name).name or "attachment"
        local_path = os.path.join(self._tmp_dir, safe_name)
        try:
            async with self._http.get(absolute_url) as resp:
                if resp.status != _HTTP_OK:
                    logger.warning(
                        "{} download failed HTTP {}: {}",
                        _LOG_PREFIX,
                        resp.status,
                        absolute_url,
                    )
                    return None
                data = await resp.read()
            with open(local_path, "wb") as fh:
                fh.write(data)
            return local_path
        except Exception as exc:
            logger.warning(
                "{} download error for {}: {}", _LOG_PREFIX, absolute_url, exc
            )
            return None

    async def _list_group_members(self, group_id: str) -> list[dict[str, Any]]:
        """GET the roster for ``group_id``; empty list on any failure."""
        if self._http is None or not group_id:
            return []
        url = urljoin(
            self._server_url + "/", f"api/agent/groups/{group_id}/members"
        )
        try:
            async with self._http.get(url) as resp:
                if resp.status != _HTTP_OK:
                    logger.debug(
                        "{} listGroupMembers({}) → HTTP {}",
                        _LOG_PREFIX,
                        group_id,
                        resp.status,
                    )
                    return []
                data = await resp.json()
                return data if isinstance(data, list) else []
        except Exception as exc:
            logger.debug(
                "{} listGroupMembers({}) error: {}", _LOG_PREFIX, group_id, exc
            )
            return []

    async def list_chats(self) -> dict[str, list[dict[str, Any]]]:
        """Return every group and direct chat this agent participates in.

        Mirrors :meth:`AgentClubClient.listChats` in the OpenClaw channel and
        targets the same ``/api/agent/chats`` endpoint. Intended for the
        "reminder to Bob" workflow — an agent scans ``directs[]`` for a
        ``peer_name`` match to find the ``chat_id`` it should ``send`` to.

        Because the IM server only exposes chats the agent is authorized to
        write to, a hit in this list is also implicit permission to send
        there, which keeps agents from having to guess ``chat_id``s.

        Returns ``{"groups": [], "directs": []}`` on any transport failure
        so the agent loop can degrade gracefully (no name resolution is
        still better than a crash).
        """
        empty: dict[str, list[dict[str, Any]]] = {"groups": [], "directs": []}
        if self._http is None:
            return empty
        url = urljoin(self._server_url + "/", "api/agent/chats")
        try:
            async with self._http.get(url) as resp:
                if resp.status != _HTTP_OK:
                    logger.debug("{} listChats() → HTTP {}", _LOG_PREFIX, resp.status)
                    return empty
                data = await resp.json()
        except Exception as exc:
            logger.debug("{} listChats() error: {}", _LOG_PREFIX, exc)
            return empty
        if not isinstance(data, dict):
            return empty
        groups = data.get("groups") if isinstance(data.get("groups"), list) else []
        directs = data.get("directs") if isinstance(data.get("directs"), list) else []
        return {"groups": groups, "directs": directs}
