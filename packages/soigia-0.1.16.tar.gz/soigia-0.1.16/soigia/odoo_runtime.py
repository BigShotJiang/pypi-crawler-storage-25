from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable

from soigia.odoo_client import OdooClient

DEFAULT_DATABASE = "odoo"
DEFAULT_LOGIN = "admin"
DEFAULT_PASSWORD = "admin"
DEFAULT_CONTEXT = {"lang": "en_US"}


def _split_url_list(raw_value: str | None) -> list[str]:
    if not raw_value:
        return []
    parts: list[str] = []
    for chunk in raw_value.replace("\n", ",").split(","):
        candidate = chunk.strip()
        if candidate:
            parts.append(candidate)
    return parts


def _is_docker_environment() -> bool:
    return Path("/.dockerenv").exists() or bool(os.environ.get("container") or os.environ.get("DOCKER_CONTAINER"))


def _dedupe(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            ordered.append(value)
    return ordered


def candidate_base_urls() -> list[str]:
    configured = _split_url_list(os.environ.get("ODOO_SAMPLE_URLS"))
    if configured:
        return _dedupe(configured)

    urls: list[str] = []
    explicit_url = os.environ.get("ODOO_URL") or os.environ.get("ODOO_BASE_URL")
    if explicit_url:
        urls.append(explicit_url)

    if os.environ.get("ODOO_HOST"):
        host = os.environ["ODOO_HOST"].strip()
        port = os.environ.get("ODOO_PORT", "8069").strip()
        urls.append(f"http://{host}:{port}")

    docker_friendly = [
        "http://soigia-sdk-odoo:8069",
        "http://host.docker.internal:8070",
        "http://host.docker.internal:8069",
        "http://127.0.0.1:8070",
        "http://127.0.0.1:8069",
    ]
    localhost_first = [
        "http://127.0.0.1:8070",
        "http://127.0.0.1:8069",
        "http://host.docker.internal:8070",
        "http://host.docker.internal:8069",
        "http://soigia-sdk-odoo:8069",
    ]
    urls.extend(docker_friendly if _is_docker_environment() else localhost_first)
    return _dedupe(urls)


def _build_client(base_url: str) -> OdooClient:
    return OdooClient(
        base_url,
        os.environ.get("ODOO_DB", DEFAULT_DATABASE),
        login=os.environ.get("ODOO_LOGIN", DEFAULT_LOGIN),
        password=os.environ.get("ODOO_PASSWORD", DEFAULT_PASSWORD),
        api_key=os.environ.get("ODOO_API_KEY"),
        context=DEFAULT_CONTEXT,
    )


def build_client() -> OdooClient:
    """Build a client for the current environment.

    Priority order:
    1. explicit `ODOO_URL` / `ODOO_BASE_URL`
    2. an address built from `ODOO_HOST` + `ODOO_PORT`
    3. common Docker and local fallbacks
    """

    last_error: Exception | None = None
    for base_url in candidate_base_urls():
        client = _build_client(base_url)
        try:
            client.ping()
        except Exception as exc:
            last_error = exc
            continue
        return client

    attempted = ", ".join(candidate_base_urls())
    raise RuntimeError(f"Unable to connect to Odoo using any of these URLs: {attempted}") from last_error
