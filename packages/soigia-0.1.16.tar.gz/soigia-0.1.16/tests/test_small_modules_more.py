from __future__ import annotations

import importlib.util
import importlib
import runpy
import shutil
import sys
import time
from pathlib import Path

import pytest

import soigia
import soigia.config as config_mod
import soigia.demo as demo_mod
import soigia.domain as domain_mod


def _sandbox(name: str) -> Path:
    path = Path.cwd() / ".test_artifacts" / f"{name}_{time.time_ns()}"
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_package_and_domain_lazy_exports_cover_remaining_branches():
    assert getattr(soigia, "tester").__name__.endswith(".tester")
    assert getattr(domain_mod, "anki").__name__.endswith(".anki")
    with pytest.raises(AttributeError):
        getattr(domain_mod, "missing")


def test_config_helpers_store_and_edge_branches(monkeypatch):
    sandbox = _sandbox("config_more")
    config_path = sandbox / "nested" / "config.yaml"
    monkeypatch.chdir(sandbox)
    monkeypatch.setenv(config_mod.CONFIG_ENV_VAR, str(config_path))

    resolved = config_mod.resolve_config_path()
    assert resolved == config_path.resolve()
    assert config_mod.resolve_config_path("other.yaml").name == "other.yaml"
    monkeypatch.delenv(config_mod.CONFIG_ENV_VAR, raising=False)
    assert config_mod.resolve_config_path().name == config_mod.DEFAULT_CONFIG_FILENAME
    monkeypatch.setenv(config_mod.CONFIG_ENV_VAR, str(config_path))
    assert set(config_mod._default_account_bucket()) == set(config_mod.DEFAULT_ACCOUNT_TYPES)
    assert config_mod._normalize_mapping(None) == {}
    assert config_mod.normalize_config(None)["version"] == 1
    assert config_mod._normalize_account_entry(None, service="x", name="y")["name"] == "y"
    assert config_mod.get_accounts({"accounts": []}, "x") == {}
    assert config_mod.get_account({"accounts": {}}, "x", "y") is None

    loaded = config_mod.load_config(create=True)
    assert loaded["version"] == 1
    assert config_path.exists()

    payload = {
        "version": 2,
        "meta": {"description": "custom"},
        "accounts": {
            "custom": {
                "demo": {
                    "enabled": False,
                    "credentials": {"token": "x"},
                    "settings": {"region": "vn"},
                    "notes": 123,
                    "extra": True,
                }
            }
        },
    }
    normalized = config_mod.normalize_config(payload)
    assert normalized["version"] == 2
    assert normalized["accounts"]["custom"]["demo"]["extra"] is True
    saved = config_mod.save_config(payload)
    assert saved.exists()

    store = config_mod.ConfigStore(path=config_path)
    assert store.get_accounts("custom")
    store.upsert_account("custom", "demo2", {"credentials": {"token": "y"}})
    assert store.get_account("custom", "demo2")["credentials"]["token"] == "y"
    store.delete_account("custom", "missing")
    store.delete_account("custom", "demo2")
    assert store.get_account("custom", "demo2") is None


def test_demo_pipelines_and_module_entrypoint(monkeypatch):
    sandbox = _sandbox("demo_more")
    monkeypatch.chdir(sandbox)

    shopee = demo_mod.Shopee(name="demo")
    result = shopee.run()
    assert result.success
    assert list(shopee.datatable.columns) == ["id", "name", "status", "amount", "net_amount"]
    assert (sandbox / "data" / "demo" / "users.csv").exists()

    upsert = demo_mod.ShopeeUpsertDemo(name="demo-upsert")
    result = upsert.run()
    assert result.success
    assert (sandbox / "data" / "demo" / "user_2_vip.csv").exists()

    monkeypatch.setattr(sys, "argv", ["demo.py"])
    runpy.run_module("soigia.demo", run_name="__main__")

    spec = importlib.util.spec_from_file_location("__main__", Path(demo_mod.__file__).resolve())
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setattr(sys, "argv", ["demo.py"])
    assert spec.loader is not None
    spec.loader.exec_module(module)
