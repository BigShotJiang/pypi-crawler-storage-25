from __future__ import annotations

from collections import Counter

import pandas as pd
from hypothesis import given, strategies as st

from soigia.datatable import DataTable


@given(st.lists(st.integers(min_value=-10_000, max_value=10_000), max_size=100))
def test_sort_preserves_row_count_and_values(values):
    table = DataTable({"value": values})

    sorted_table = table.sort_values("value").reset_index(drop=True)

    assert len(sorted_table) == len(table)
    assert Counter(sorted_table["value"].tolist()) == Counter(values)


@given(st.lists(st.integers(min_value=0, max_value=50), max_size=100))
def test_drop_duplicates_never_increases_row_count(values):
    table = DataTable({"value": values})

    deduplicated = table.drop_duplicates(subset=["value"]).reset_index(drop=True)

    assert len(deduplicated) <= len(table)
    assert set(deduplicated["value"].tolist()).issubset(set(values))


@given(
    st.lists(
        st.one_of(st.none(), st.integers(min_value=-1000, max_value=1000)),
        min_size=1,
        max_size=100,
    )
)
def test_fill_missing_preserves_row_count(values):
    table = DataTable({"value": values})

    filled = table.fill_missing(0)

    assert len(filled) == len(table)
    assert filled["value"].isna().sum() == 0


@given(st.lists(st.text(min_size=1, max_size=20), min_size=1, max_size=30))
def test_clean_columns_preserves_row_count(column_names):
    data = {f" {name} ": [index] for index, name in enumerate(column_names)}
    table = DataTable(data)

    cleaned = table.clean_columns()

    assert len(cleaned) == len(table)
    assert cleaned.shape[1] == table.shape[1]


@given(st.lists(st.dictionaries(keys=st.text(min_size=1, max_size=10), values=st.integers()), max_size=20))
def test_from_records_roundtrip_preserves_rows(records):
    normalized_records = [{str(key): value for key, value in row.items()} for row in records]
    table = DataTable.from_records(normalized_records)

    assert isinstance(table, pd.DataFrame)
    assert len(table) == len(normalized_records)
