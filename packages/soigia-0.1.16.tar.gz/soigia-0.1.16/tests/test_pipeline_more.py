from __future__ import annotations

import shutil
import time
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest

from soigia.datatable import DataTable
import soigia.pipeline as pipeline_mod


def _sandbox(name: str) -> Path:
    path = Path.cwd() / ".test_artifacts" / f"{name}_{time.time_ns()}"
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_pipeline_helper_functions_and_namespace(monkeypatch):
    sandbox = _sandbox("pipeline_more_helpers")
    monkeypatch.chdir(sandbox)

    class DemoPipeline(pipeline_mod.Pipeline):
        stages = []

    assert pipeline_mod._pipeline_log_path("X").name == "X.log"
    assert pipeline_mod._pipeline_data_dir("X").name == "X"
    assert pipeline_mod._pipeline_module_dir(DemoPipeline).exists()
    assert pipeline_mod._pipeline_module_file(DemoPipeline).suffix == ".py"
    assert pipeline_mod._resolve_path_value("a/b.txt", create_parent=True).parent.exists()
    assert pipeline_mod._default_pipeline_db_path("X").name == "X.sqlite3"
    assert pipeline_mod._df_rows([1, 2]) == 2
    assert pipeline_mod._df_rows(object()) is None
    assert pipeline_mod._df_columns(pd.DataFrame({"x": [1]})) == ["x"]
    assert pipeline_mod._df_columns(object()) == []
    assert pipeline_mod._model_items(None) == []
    assert pipeline_mod._model_items(SimpleNamespace(a=1, _b=2)) == [("a", 1)]
    assert pipeline_mod._model_items(type("Bad", (), {"__slots__": ()})()) == []
    ns = pipeline_mod.ConfigNamespace(alpha=1)
    assert pipeline_mod._config_to_dict(ns) == {"alpha": 1}
    assert pipeline_mod._config_to_dict({"a": 1}) == {"a": 1}
    assert pipeline_mod._config_to_dict(type("Map", (), {"items": lambda self: [("a", 1)]})()) == {"a": 1}
    assert pipeline_mod._config_to_dict(object()) == {}
    assert isinstance(pipeline_mod._coerce_datatable(None), DataTable)
    assert isinstance(pipeline_mod._coerce_datatable(pd.DataFrame({"x": [1]})), DataTable)
    assert isinstance(pipeline_mod._coerce_datatable([{"x": 1}]), DataTable)
    assert isinstance(pipeline_mod._coerce_datatable(3), DataTable)
    ns.setdefault("beta", 2)
    ns.update({"gamma": 3}, delta=4)
    assert ns.as_dict() == {"alpha": 1, "beta": 2, "gamma": 3, "delta": 4}
    assert "alpha" in ns
    assert ns["alpha"] == 1
    with pytest.raises(KeyError):
        _ = ns["missing"]


def test_pipeline_sqlite_wrapper_query_types_and_upserts(monkeypatch):
    sandbox = _sandbox("pipeline_more_sqlite")
    monkeypatch.chdir(sandbox)

    class DemoPipeline(pipeline_mod.Pipeline):
        stages = []

    pipeline = DemoPipeline(name="demo", config={"db_upsert_keys": {"items": ["id"]}})
    db = pipeline.db
    assert db.path.exists()
    db.execute('CREATE TABLE sample (id INTEGER PRIMARY KEY, name TEXT)')
    db.executemany('INSERT INTO sample(id, name) VALUES (?, ?)', [(1, "a"), (2, "b")])
    assert list(db.query("SELECT * FROM sample ORDER BY id")["name"]) == ["a", "b"]
    assert "sample" in db.list_tables()
    assert db.table_exists("sample") is True
    assert list(db.read_df("sample")["id"]) == [1, 2]
    assert list(db.read_table("sample")["id"]) == [1, 2]
    assert list(db.to_df("sample")["id"]) == [1, 2]
    assert list(db.get("sample")["id"]) == [1, 2]
    db.write_table("items", [{"id": 1, "value": "a"}])
    db.from_df("items2", pd.DataFrame({"id": [1]}))
    db.set("items3", [{"id": 1}])
    assert db.upsert_df("empty", pd.DataFrame([])).exists()
    assert db.upsert_df("replace_items", [{"id": 1}], mode="replace").exists()
    assert db.upsert_df("insert_items", [{"id": 1}], mode="insert").exists()
    with pytest.raises(ValueError):
        db.upsert_df("bad", [{"id": 1}], mode="bad")
    with pytest.raises(ValueError):
        db.upsert_df("missing_key", [{"name": "a"}])
    with pytest.raises(KeyError):
        db.upsert_df("missing_col", [{"id": 1}], key_columns=["missing"])
    with pytest.raises(KeyError):
        db.upsert_df("missing_update", [{"id": 1}], key_columns=["id"], update_columns=["missing"])
    db.upsert_df("items", [{"id": 1, "value": "b"}], key_columns="id", update_columns=[])
    db.upsert_df("items", [{"id": 1, "value": "c"}], key_columns=["id"], update_columns=["value"])
    db.upsert_df("delete_insert", [{"id": 1, "value": "x"}], mode="delete-insert", key_columns=["id"])
    db.upsert("items", [{"id": 2, "value": "d"}], key_columns=["id"])
    assert list(db.read_df("items").sort_values("id")["id"]) == [1, 2]


def test_pipeline_context_steps_and_basepipeline_runtime():
    context = pipeline_mod.PipelineContext(pipeline=SimpleNamespace())
    assert context.put("x", 1) == 1
    assert context.get("x") == 1
    label = context.add_rollback_action(lambda: None)
    assert label == "<lambda>"

    assert pipeline_mod.StepOutcome(metadata={"final_rows": 2, "final_columns": ("a",), "db_output_path": "a.db"}).rows == 2
    assert pipeline_mod.StepOutcome(metadata={"final_columns": ("a",)}).columns == ["a"]
    assert pipeline_mod.StepOutcome(metadata={"final_columns": "a"}).columns == ["a"]
    assert pipeline_mod.StepOutcome(metadata={"db_output_path": "a.db"}).db_path == "a.db"
    assert pipeline_mod.StepOutcome(metadata={"parquet_output_path": "a.parquet"}).parquet_path == "a.parquet"
    assert pipeline_mod.StepOutcome(metadata={"summary_path": "a.md"}).summary_path == "a.md"
    assert pipeline_mod.StepOutcome(metadata={"csv_output_path": "a.csv"}).csv_path == "a.csv"
    assert pipeline_mod.StepOutcome(metadata={"duration_seconds": 1}).duration_seconds == 1.0
    assert pipeline_mod.StepOutcome(status=pipeline_mod.PipelineStatus.SKIPPED).skipped is True
    assert pipeline_mod.StepOutcome(status=pipeline_mod.PipelineStatus.FAILED).failed is True

    assert pipeline_mod._call_with_context(lambda: "x", context, 1) == "x"
    assert pipeline_mod._call_with_context(lambda data: data * 2, context, 2) == 4
    assert pipeline_mod._call_with_context(lambda data, ctx: (data, ctx.run_id), context, 2)[0] == 2
    bad_sig = type("NoSig", (), {"__call__": lambda self, data, ctx: (data, ctx.run_id)})()
    original_sig = pipeline_mod.inspect.signature
    pipeline_mod.inspect.signature = lambda value: (_ for _ in ()).throw(TypeError("bad")) if value is bad_sig else original_sig(value)
    try:
        assert pipeline_mod._call_with_context(bad_sig, context, 3)[0] == 3
    finally:
        pipeline_mod.inspect.signature = original_sig

    assert pipeline_mod._call_context_only(lambda: "x", context) == "x"
    assert pipeline_mod._call_context_only(lambda ctx: ctx.run_id, context) == context.run_id
    bad_ctx = type("NoSigCtx", (), {"__call__": lambda self, ctx: ctx.run_id})()
    pipeline_mod.inspect.signature = lambda value: (_ for _ in ()).throw(TypeError("bad")) if value is bad_ctx else original_sig(value)
    try:
        assert pipeline_mod._call_context_only(bad_ctx, context) == context.run_id
    finally:
        pipeline_mod.inspect.signature = original_sig

    class EchoStep(pipeline_mod.BaseStep):
        def run(self, context, data):
            return data + 1

    assert EchoStep("echo").execute(context, 1).data == 2
    skipped = EchoStep("skip", enabled=False).execute(context, 1)
    assert skipped.status == pipeline_mod.PipelineStatus.SKIPPED

    class RetryStep(pipeline_mod.BaseStep):
        def __init__(self):
            super().__init__("retry", retries=1)
            self.calls = 0

        def run(self, context, data):
            self.calls += 1
            raise RuntimeError("boom")

    failed = RetryStep().execute(context, 1)
    assert failed.status == pipeline_mod.PipelineStatus.FAILED
    assert context.errors

    function_step = pipeline_mod.FunctionStep(
        name="f",
        fn=lambda ctx: "ctx-only",
        pass_data=False,
        before_hook=lambda ctx: "before",
        after_hook=lambda ctx: "after",
        condition_hook=lambda ctx: True,
        input_validator=lambda ctx: None,
        output_validator=lambda ctx: None,
        rollback_hook=lambda ctx: "rollback",
    )
    assert function_step.condition(context, 1) is True
    assert function_step.before(context, 1) == "before"
    function_step.validate_input(context, 1)
    assert function_step.run(context, 1) == "ctx-only"
    function_step.validate_output(context, 1)
    assert function_step.after(context, 1) == "after"
    assert function_step.rollback(context, 1, RuntimeError("x")) == "rollback"
    fallback = pipeline_mod.FunctionStep(name="f2", fn=lambda data, ctx: data, rollback_hook=lambda ctx: "rb")
    assert fallback.rollback(context, 1, RuntimeError("x")) == "rb"

    pipeline = pipeline_mod.BasePipeline(name="base", config=SimpleNamespace(alpha=1), logger=SimpleNamespace(info=lambda *a, **k: None))
    assert pipeline.config.alpha == 1
    registered = []

    @pipeline.step(name="decorated", retries=1, enabled=True, before=lambda data, ctx: data + 1, after=lambda data, ctx: data + 1)
    def _decorated(data, ctx):
        registered.append(ctx.current_step)
        return data + 1

    assert pipeline.steps[-1].name == "decorated"
    pipeline.add_step(pipeline_mod.FunctionStep(name="manual", fn=lambda data, ctx: data))
    outcome = pipeline.run(1)
    assert outcome.success
    assert registered


def test_pipeline_dump_csv_and_save_outputs_error_branches(monkeypatch):
    sandbox = _sandbox("pipeline_more_outputs")
    monkeypatch.chdir(sandbox)

    class DemoPipeline(pipeline_mod.Pipeline):
        stages = []

        def load_data(self):
            return pd.DataFrame({"id": [1], "name": ["alice"]})

    pipeline = DemoPipeline(name="demo")
    context = pipeline_mod.PipelineContext(pipeline=pipeline)

    class BadCsv:
        def to_csv(self, *args, **kwargs):
            raise RuntimeError("csv-fail")

    pipeline._dump_step_csv(1, "bad", BadCsv(), context, pipeline_mod.FunctionStep(name="x", fn=lambda data, ctx: data))
    pipeline._dump_step_csv(1, "skip", object(), context, pipeline_mod.FunctionStep(name="x", fn=lambda data, ctx: data))
    pipeline._dump_step_csv(1, "skip2", pd.DataFrame({"x": [1]}), context, pipeline_mod.FunctionStep(name="x", fn=lambda data, ctx: data, dump_csv=False))
    assert context.errors

    pipeline.datatable = pd.DataFrame()
    assert pipeline.save_outputs().empty

    pipeline.datatable = pd.DataFrame({"id": [1], "name": ["alice"]})

    class BadParquet(pd.DataFrame):
        @property
        def _constructor(self):
            return BadParquet

        def to_csv(self, *args, **kwargs):
            raise RuntimeError("csv-fail")

        def to_parquet(self, *args, **kwargs):
            raise RuntimeError("parquet-fail")

    pipeline.datatable = BadParquet({"id": [1], "name": ["alice"]})
    pipeline._runtime_context = context
    pipeline.save_outputs()
    assert context.errors
