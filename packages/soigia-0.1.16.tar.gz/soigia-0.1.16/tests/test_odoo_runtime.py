from __future__ import annotations

import soigia.odoo_runtime as runtime


class _FakeClient:
    instances: list["_FakeClient"] = []

    def __init__(self, base_url, database, login=None, password=None, api_key=None, context=None):
        self.base_url = base_url
        self.database = database
        self.login = login
        self.password = password
        self.api_key = api_key
        self.context = context
        self.ping_calls = 0
        _FakeClient.instances.append(self)

    def ping(self):
        self.ping_calls += 1
        if self.base_url in {"http://bad.local:8069", "http://127.0.0.1:8070"}:
            raise RuntimeError("unreachable")
        return {"ok": True}


def test_candidate_base_urls_prefers_explicit_env_url(monkeypatch):
    monkeypatch.setenv("ODOO_URL", "http://bad.local:8069")
    monkeypatch.setenv("ODOO_DB", "odoo")
    monkeypatch.delenv("ODOO_SAMPLE_URLS", raising=False)
    monkeypatch.delenv("ODOO_HOST", raising=False)
    monkeypatch.delenv("ODOO_PORT", raising=False)
    monkeypatch.setattr(runtime, "_is_docker_environment", lambda: False)

    candidates = runtime.candidate_base_urls()

    assert candidates[0] == "http://bad.local:8069"
    assert "http://127.0.0.1:8070" in candidates


def test_candidate_base_urls_in_docker_includes_repo_service_name(monkeypatch):
    monkeypatch.delenv("ODOO_URL", raising=False)
    monkeypatch.delenv("ODOO_SAMPLE_URLS", raising=False)
    monkeypatch.delenv("ODOO_HOST", raising=False)
    monkeypatch.delenv("ODOO_PORT", raising=False)
    monkeypatch.setattr(runtime, "_is_docker_environment", lambda: True)

    candidates = runtime.candidate_base_urls()

    assert candidates[0] == "http://soigia-sdk-odoo:8069"


def test_build_client_probes_fallback_urls(monkeypatch):
    _FakeClient.instances = []
    monkeypatch.setattr(runtime, "OdooClient", _FakeClient)
    monkeypatch.setattr(runtime, "_is_docker_environment", lambda: False)
    monkeypatch.setenv("ODOO_URL", "http://bad.local:8069")
    monkeypatch.setenv("ODOO_DB", "odoo")
    monkeypatch.setenv("ODOO_LOGIN", "admin")
    monkeypatch.setenv("ODOO_PASSWORD", "admin")
    monkeypatch.delenv("ODOO_SAMPLE_URLS", raising=False)
    monkeypatch.delenv("ODOO_HOST", raising=False)
    monkeypatch.delenv("ODOO_PORT", raising=False)

    client = runtime.build_client()

    assert client.base_url == "http://127.0.0.1:8069"
    assert client.database == "odoo"
    assert client.login == "admin"
    assert client.password == "admin"
    assert len(_FakeClient.instances) >= 2
    assert _FakeClient.instances[0].ping_calls == 1
    assert _FakeClient.instances[-1].ping_calls == 1
