from __future__ import annotations

import json
import logging
from types import SimpleNamespace
from urllib.error import URLError
from urllib.error import HTTPError

import pytest

import soigia.odoo_client as odoo_mod
from soigia.odoo_client import OdooAuthenticationError, OdooClient, OdooError, OdooHttpError, OdooJson2Error


class _FakeResponse:
    def __init__(self, body: str) -> None:
        self._body = body.encode("utf-8")

    def read(self) -> bytes:
        return self._body

    def close(self) -> None:
        return None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False


class _FakeOpener:
    def __init__(self, responses: list[dict]) -> None:
        self.responses = list(responses)
        self.requests = []

    def open(self, request, timeout=None):
        self.requests.append((request, timeout))
        response = self.responses.pop(0)
        return _FakeResponse(json.dumps(response))


class _FakeCommonProxy:
    def __init__(self) -> None:
        self.authenticate_calls = []

    def version(self):
        return {"server_version": "19.0-20260324", "server_serie": "19.0"}

    def authenticate(self, db, login, password, context):
        self.authenticate_calls.append((db, login, password, context))
        return 42


class _FakeObjectProxy:
    def __init__(self) -> None:
        self.calls = []

    def execute_kw(self, db, uid, password, model, method, args, kwargs):
        self.calls.append((db, uid, password, model, method, args, kwargs))
        if method == "read":
            return [{"datas": "aGVsbG8="}]
        if method == "create":
            return 99
        return True


class _ListHandler(logging.Handler):
    def __init__(self) -> None:
        super().__init__()
        self.records = []

    def emit(self, record) -> None:
        self.records.append(record)


class _TypeErrorToDict:
    def to_dict(self, orient="records"):
        raise TypeError("unsupported")


def test_with_context_preserves_connection_and_merges_values():
    client = OdooClient("http://127.0.0.1:8070/", "odoo", login="admin", password="admin", context={"lang": "en_US"})

    clone = client.with_context(tz="Asia/Bangkok")

    assert client.base_url == "http://127.0.0.1:8070"
    assert clone.context == {"lang": "en_US", "tz": "Asia/Bangkok"}
    assert clone.login == client.login
    assert clone.database == client.database


def test_internal_helpers_cover_normalize_and_chunking():
    assert odoo_mod._normalize_records_payload(None) == []
    assert odoo_mod._normalize_records_payload({"id": 1}) == [{"id": 1}]
    with pytest.raises(TypeError):
        odoo_mod._normalize_records_payload(_TypeErrorToDict())
    with pytest.raises(TypeError):
        odoo_mod._normalize_records_payload([1])
    with pytest.raises(TypeError):
        odoo_mod._normalize_records_payload("bad")
    with pytest.raises(ValueError):
        odoo_mod._chunked([{"id": 1}], 0)
    assert odoo_mod._resolve_operation_name(SimpleNamespace(model="res.partner"), "save") == "res.partner.save"
    logger = logging.getLogger("tests.odoo.helper")
    assert odoo_mod._resolve_logger(SimpleNamespace(logger=logger)) is logger
    assert odoo_mod._resolve_logger(object()).name == odoo_mod.__name__
    assert odoo_mod._resolve_operation_name(object(), "save") == "save"


def test_from_env_builds_client(monkeypatch):
    monkeypatch.setenv("ODOO_URL", "http://127.0.0.1:8070")
    monkeypatch.setenv("ODOO_DB", "odoo")
    monkeypatch.setenv("ODOO_LOGIN", "admin")
    monkeypatch.setenv("ODOO_PASSWORD", "admin")

    client = OdooClient.from_env()

    assert client.base_url == "http://127.0.0.1:8070"
    assert client.database == "odoo"
    assert client.login == "admin"
    assert client.password == "admin"


def test_from_env_requires_url_and_db(monkeypatch):
    monkeypatch.delenv("ODOO_URL", raising=False)
    monkeypatch.delenv("ODOO_DB", raising=False)

    with pytest.raises(OdooAuthenticationError):
        OdooClient.from_env()


def test_from_django_settings_builds_client():
    class Settings:
        ODOO = {
            "URL": "http://127.0.0.1:8070",
            "DB": "odoo",
            "LOGIN": "admin",
            "PASSWORD": "admin",
            "RETRY_COUNT": 2,
        }

    client = OdooClient.from_django_settings(Settings())

    assert client.base_url == "http://127.0.0.1:8070"
    assert client.database == "odoo"
    assert client.retry_count == 2


def test_from_django_settings_fallback_prefix_attrs():
    class Settings:
        ODOO_URL = "http://127.0.0.1:8070"
        ODOO_DB = "odoo"
        ODOO_LOGIN = "admin"
        ODOO_PASSWORD = "admin"
        ODOO_TIMEOUT = 15

    client = OdooClient.from_django_settings(Settings())

    assert client.base_url == "http://127.0.0.1:8070"
    assert client.timeout == 15.0


def test_ping_and_ensure_api_key_and_clear_caches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin")
    monkeypatch.setattr(client, "version_info", lambda: {"server_version": "19.0", "server_serie": "19.0"})
    monkeypatch.setattr(client, "create_api_key", lambda **kwargs: "secret")
    client._fields_cache["x"] = {"a": 1}
    client._model_doc_cache["y"] = {"b": 2}

    ping = client.ping()
    api_key = client.ensure_api_key()
    client.close()

    assert ping["ok"] is True
    assert api_key == "secret"
    assert client._fields_cache == {}
    assert client._model_doc_cache == {}


def test_connection_info_and_getitem():
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", api_key="secret")
    info = client.connection_info

    assert info.base_url == "http://127.0.0.1:8070"
    assert client["res.partner"].model == "res.partner"


def test_context_manager_and_context_helpers(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", context={"lang": "en_US"})

    with client as managed:
        assert managed is client

    clone = client.with_timezone("Asia/Bangkok").with_company(3).with_lang("vi_VN")

    assert clone.context["tz"] == "Asia/Bangkok"
    assert clone.context["company_id"] == 3
    assert clone.context["allowed_company_ids"] == [3]
    assert clone.context["lang"] == "vi_VN"


def test_ensure_authenticated(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin")
    auth_calls = []
    key_calls = []
    monkeypatch.setattr(client, "authenticate", lambda: auth_calls.append(True) or 2)
    monkeypatch.setattr(client, "ensure_api_key", lambda **kwargs: key_calls.append(kwargs) or "secret")

    returned_client = client.ensure_authenticated()
    returned_client_key = client.ensure_authenticated(prefer_api_key=True, api_key_name="x", api_key_duration="7")

    assert returned_client is client
    assert returned_client_key is client
    assert len(auth_calls) == 1
    assert key_calls == [{"name": "x", "duration": "7"}]


def test_authenticate_uses_xmlrpc_proxy_and_stores_uid():
    common_proxy = _FakeCommonProxy()
    object_proxy = _FakeObjectProxy()

    def proxy_factory(url, allow_none=True):
        if url.endswith("/xmlrpc/2/common"):
            return common_proxy
        return object_proxy

    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", server_proxy_factory=proxy_factory)

    uid = client.authenticate(context={"lang": "vi_VN"})

    assert uid == 42
    assert client.uid == 42
    assert common_proxy.authenticate_calls == [("odoo", "admin", "admin", {"lang": "vi_VN"})]


def test_create_api_key_uses_identity_check_flow():
    responses = [
        {"result": {"uid": 2}},
        {"result": [5]},
        {"result": {"res_model": "res.users.identitycheck", "res_id": 8}},
        {"result": {"context": {"default_key": "json2-secret"}}},
    ]
    opener = _FakeOpener(responses)
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", opener=opener)

    api_key = client.create_api_key(name="Codex Test Key", duration="7")

    assert api_key == "json2-secret"
    assert client.api_key == "json2-secret"
    assert len(opener.requests) == 4


def test_create_api_key_requires_password():
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin")

    with pytest.raises(OdooAuthenticationError):
        client.create_api_key()


def test_json2_call_sets_required_headers_and_decodes_response():
    captured = {}

    def fake_urlopen(request, timeout=None):
        captured["url"] = request.full_url
        captured["headers"] = dict(request.header_items())
        captured["body"] = request.data.decode("utf-8")
        captured["timeout"] = timeout
        return _FakeResponse('{"result":"ok"}')

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret", urlopen_func=fake_urlopen)

    result = client.json2_call("res.partner", "search", {"domain": [["id", "=", 1]]})

    assert result == {"result": "ok"}
    assert captured["url"].endswith("/json/2/res.partner/search")
    assert captured["headers"]["Authorization"] == "bearer secret"
    assert captured["headers"]["X-odoo-database"] == "odoo"
    assert json.loads(captured["body"]) == {"domain": [["id", "=", 1]]}
    assert captured["timeout"] == 30.0


def test_json2_call_wraps_http_errors():
    def fake_urlopen(request, timeout=None):
        raise HTTPError(request.full_url, 422, "boom", hdrs=None, fp=None)

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret", urlopen_func=fake_urlopen)

    with pytest.raises(OdooJson2Error):
        client.json2_call("res.partner", "search", {"domain": []})


def test_json2_call_other_error_branches():
    def bad_urlopen(request, timeout=None):
        raise URLError("down")

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret", urlopen_func=bad_urlopen)
    with pytest.raises(OdooJson2Error):
        client.json2_call("res.partner", "search", {"domain": []})

    client_empty = OdooClient(
        "http://127.0.0.1:8070",
        "odoo",
        api_key="secret",
        urlopen_func=lambda request, timeout=None: _FakeResponse("   "),
    )
    assert client_empty.json2_call("res.partner", "search", {"domain": []}) is None

    client_invalid = OdooClient(
        "http://127.0.0.1:8070",
        "odoo",
        api_key="secret",
        urlopen_func=lambda request, timeout=None: _FakeResponse("not-json"),
    )
    with pytest.raises(OdooJson2Error):
        client_invalid.json2_call("res.partner", "search", {"domain": []})


def test_attachment_helpers_encode_and_decode_content():
    common_proxy = _FakeCommonProxy()
    object_proxy = _FakeObjectProxy()

    def proxy_factory(url, allow_none=True):
        if url.endswith("/xmlrpc/2/common"):
            return common_proxy
        return object_proxy

    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", server_proxy_factory=proxy_factory)

    attachment_id = client.upload_attachment(name="hello.txt", content=b"hello", mimetype="text/plain")
    content = client.download_attachment(attachment_id)

    assert attachment_id == 99
    assert content == b"hello"
    create_call = next(call for call in object_proxy.calls if call[4] == "create")
    assert create_call[5][0]["datas"] == "aGVsbG8="


def test_web_call_raises_on_odoo_error_payload():
    opener = _FakeOpener([{"error": {"message": "boom"}}])
    client = OdooClient("http://127.0.0.1:8070", "odoo", opener=opener)

    with pytest.raises(OdooHttpError):
        client.session_info()


def test_model_manager_filter_create_and_count(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name", "email"])

    monkeypatch.setattr(
        client,
        "search_read",
        lambda model, domain, fields=None, limit=None, offset=0, order=None: [{"id": 7, "name": "Alice", "email": "a@example.com"}],
    )
    monkeypatch.setattr(client, "search_count", lambda model, domain: 3)
    monkeypatch.setattr(client, "create", lambda model, values: 7)

    first = partner_model.objects.filter(name__icontains="ali").first()
    created = partner_model.objects.create(name="Alice", email="a@example.com")

    assert first is not None
    assert first.id == 7
    assert first.name == "Alice"
    assert created.email == "a@example.com"
    assert partner_model.objects.filter(name__icontains="ali").count() == 3


def test_manager_wrapper_methods(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    model = client.env.model("res.partner", key_fields=["email"])
    def fake_search_read(model_name, domain, fields=None, limit=None, offset=0, order=None):
        domain_text = str(domain)
        if "new@example.com" in domain_text or "new2@example.com" in domain_text:
            return []
        if '"id", "=", 1' in domain_text or "'id', '=', 1" in domain_text:
            return [{"id": 1, "email": "created@example.com"}]
        return [{"id": 1, "email": "a@example.com"}]

    monkeypatch.setattr(client, "search_read", fake_search_read)
    monkeypatch.setattr(client, "search_count", lambda *args, **kwargs: 1)
    monkeypatch.setattr(client, "create", lambda *args, **kwargs: 1)
    monkeypatch.setattr(client, "bulk_create", lambda *args, **kwargs: [1, 2])
    monkeypatch.setattr(client, "bulk_write", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "search", lambda *args, **kwargs: [1])
    monkeypatch.setattr(client, "write", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "unlink", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "upsert", lambda *args, **kwargs: ({"id": 1}, False))

    assert model.objects.all(limit=1)[0].id == 1
    assert model.objects.get(email="a@example.com").id == 1
    assert model.objects.browse(1).ids == [1]
    assert model.objects.count() == 1
    assert model.objects.exists() is True
    assert isinstance(model.objects.order_by("id desc"), odoo_mod.OdooQuerySet)
    assert isinstance(model.objects.limit(1), odoo_mod.OdooQuerySet)
    assert model.objects.values("id", limit=1)[0]["id"] == 1
    assert model.objects.values_list("id", flat=True, limit=1) == [1]
    assert list(model.objects.datatable("id").columns) == ["id"]
    assert model.objects.get_or_create(email="a@example.com")[1] is False
    created_record, created = model.objects.get_or_create(defaults={"name": "A"}, email="new@example.com")
    created_record2, created2 = model.objects.update_or_create(defaults={"name": "A"}, email="new2@example.com")
    assert created is True
    assert created_record.id == 1
    assert created2 is True
    assert created_record2.id == 1
    monkeypatch.setattr(model, "insert_many", lambda *args, **kwargs: model.browse([1]))  # type: ignore[method-assign]
    monkeypatch.setattr(model, "update_many", lambda *args, **kwargs: 1)  # type: ignore[method-assign]
    monkeypatch.setattr(model, "delete_many", lambda *args, **kwargs: 1)  # type: ignore[method-assign]
    monkeypatch.setattr(model, "delete_by_keys", lambda *args, **kwargs: 1)  # type: ignore[method-assign]
    monkeypatch.setattr(model, "upsert_many", lambda *args, **kwargs: {"updated_count": 1})  # type: ignore[method-assign]
    assert model.objects.bulk_create([{"name": "A"}]).ids == [1, 2]
    assert model.objects.bulk_write([1], {"name": "A"}) is True
    assert model.objects.insert_many([{"name": "A"}]).ids == [1]
    assert model.objects.update_many([{"id": 1, "name": "A"}]) == 1
    assert model.objects.delete_many([{"id": 1}]) == 1
    assert model.objects.delete_by_keys([{"email": "a@example.com"}]) == 1
    assert model.objects.upsert_many([{"email": "a@example.com", "name": "A"}])["updated_count"] == 1


def test_record_and_recordset_edge_cases(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    model = client.env["res.partner"]
    empty_record = model.record()
    assert "values={}" in repr(empty_record)
    rich_record = model.record({"id": 1, "name": "Alice"})
    assert "id=1" in repr(rich_record)
    rich_record._values = {"id": 2}  # type: ignore[attr-defined]
    with pytest.raises(AttributeError):
        _ = empty_record.unknown
    with pytest.raises(ValueError):
        empty_record.call("write", {})
    with pytest.raises(ValueError):
        empty_record.refresh()
    empty_record.delete()

    monkeypatch.setattr(client, "search", lambda model, domain, offset=0, limit=None, order=None: [])
    monkeypatch.setattr(client, "read", lambda model, ids, fields=None, load=None: [])
    monkeypatch.setattr(client, "unlink", lambda model, ids: True)
    rs = model.browse([])
    assert "ids=[]" in repr(rs)
    assert rs.exists() is False
    assert rs.read() == []
    assert rs.first() is None
    assert len(rs) == 0
    assert rs.delete() is True
    assert list(iter(rs)) == []


def test_queryset_chain_values_and_exists(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name", "email"])
    captured = []

    def fake_search_read(model, domain, fields=None, limit=None, offset=0, order=None):
        captured.append((model, domain, fields, limit, offset, order))
        return [{"id": 1, "name": "Alice", "email": "a@example.com"}]

    monkeypatch.setattr(client, "search_read", fake_search_read)
    monkeypatch.setattr(client, "search_count", lambda model, domain: 1)

    queryset = partner_model.objects.filter(name__icontains="ali").order_by("name asc").limit(5).offset(2)
    rows = queryset.values("id", "name")
    flat = queryset.values_list("name", flat=True)

    assert queryset.exists() is True
    assert rows == [{"id": 1, "name": "Alice", "email": "a@example.com"}]
    assert flat == ["Alice"]
    assert captured[0] == (
        "res.partner",
        [["name", "ilike", "ali"]],
        ["id", "name"],
        5,
        2,
        "name asc",
    )
    assert captured[1] == (
        "res.partner",
        [["name", "ilike", "ali"]],
        ["name"],
        5,
        2,
        "name asc",
    )


def test_queryset_error_and_mutation_paths(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    model = client.env["res.partner"]
    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [])
    monkeypatch.setattr(client, "search", lambda *args, **kwargs: [1, 2])
    monkeypatch.setattr(client, "write", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "unlink", lambda *args, **kwargs: True)

    with pytest.raises(ValueError):
        model.objects.filter().values_list(flat=True)
    with pytest.raises(ValueError):
        model.objects.filter().values_list("id", "name", flat=True)
    assert model.objects.filter().values_list("id", "name") == []
    with pytest.raises(LookupError):
        model.objects.filter().get()
    assert model.objects.filter().update(name="A") is True
    assert model.objects.filter().delete() is True
    assert list(iter(model.objects.filter())) == []


def test_queryset_and_manager_datatable(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name", "email"])
    monkeypatch.setattr(
        client,
        "search_read",
        lambda model, domain, fields=None, limit=None, offset=0, order=None: [
            {"id": 1, "name": "Alice", "email": "a@example.com"},
            {"id": 2, "name": "Bob", "email": "b@example.com"},
        ],
    )

    manager_df = partner_model.objects.datatable("id", "name")
    queryset_df = partner_model.objects.filter(name__icontains="a").datatable("id", "email")

    assert list(manager_df.columns) == ["id", "name"]
    assert manager_df.shape[0] == 2
    assert list(queryset_df.columns) == ["id", "email"]


def test_recordset_datatable(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name"])
    monkeypatch.setattr(
        client,
        "read",
        lambda model, ids, fields=None, load=None: [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}],
    )

    df = partner_model.browse([1, 2]).datatable()

    assert list(df.columns) == ["id", "name"]
    assert df.shape[0] == 2


def test_recordset_misc_paths(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    model = client.env["res.partner"]
    monkeypatch.setattr(client, "execute", lambda model, method, *args, transport="auto", **kwargs: ("ok", model, method, args, kwargs, transport))
    monkeypatch.setattr(client, "search", lambda model, domain, offset=0, limit=None, order=None: [2])
    rs = model.browse([1, 2])

    assert rs.count() == 2
    assert rs.call("action_archive")[0] == "ok"
    assert rs.refresh().ids == [2]


def test_search_read_iter_and_all(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    pages = [
        [{"id": 1}, {"id": 2}],
        [{"id": 3}],
        [],
    ]

    def fake_search_read(model, domain, fields=None, offset=0, limit=None, order=None):
        return pages.pop(0)

    monkeypatch.setattr(client, "search_read", fake_search_read)

    rows = list(client.search_read_iter("res.partner", [], batch_size=2))
    assert rows == [{"id": 1}, {"id": 2}, {"id": 3}]
    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [])
    assert list(client.search_read_iter("res.partner", [], batch_size=2)) == []
    assert client.search_read_all("res.partner", []) == []


def test_export_data_and_upsert(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    monkeypatch.setattr(client, "execute_kw", lambda model, method, args=None, kwargs=None: {"datas": [["Alice"]]})
    monkeypatch.setattr(client, "search_read", lambda model, domain, fields=None, limit=None, offset=0, order=None: [])
    monkeypatch.setattr(client, "create", lambda model, values: 7)
    monkeypatch.setattr(client, "read", lambda model, ids, fields=None, load=None: [{"id": 7, "name": "Alice"}])

    exported = client.export_data("res.partner", [1], ["name"])
    record, created = client.upsert("res.partner", lookup={"email": "a@example.com"}, values={"name": "Alice"})

    assert exported == [["Alice"]]
    assert created is True
    assert record["id"] == 7


def test_export_data_and_upsert_additional_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    monkeypatch.setattr(client, "execute_kw", lambda model, method, args=None, kwargs=None: [["Alice"]])
    assert client.export_data("res.partner", 1, ["name"]) == [["Alice"]]

    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [{"id": 9, "name": "A"}] * 2)
    with pytest.raises(OdooError):
        client.upsert("res.partner", lookup={"email": "dup@example.com"})

    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [{"id": 9, "name": "A"}] * 2)
    monkeypatch.setattr(client, "read", lambda *args, **kwargs: [{"id": 9, "name": "A"}])
    assert client.upsert("res.partner", lookup={"email": "dup@example.com"}, strict=False)[1] is False


def test_batch_insert_update_delete_and_upsert_many(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    monkeypatch.setattr(client, "bulk_create", lambda model, records: [11, 12])
    writes = []
    deletes = []
    monkeypatch.setattr(client, "write", lambda model, ids, values: writes.append((model, ids, values)) or True)
    monkeypatch.setattr(client, "unlink", lambda model, ids: deletes.append((model, ids)) or True)
    monkeypatch.setattr(
        client,
        "upsert",
        lambda model, lookup, values=None, fields=None, strict=True: (
            {"id": 20 if lookup.get("email") == "a@example.com" else 21},
            lookup.get("email") == "a@example.com",
        ),
    )

    inserted = client.insert_many("res.partner", [{"name": "A"}, {"name": "B"}])
    updated = client.update_many("res.partner", [{"id": 11, "name": "AA"}, {"id": 12, "phone": "+84"}])
    deleted = client.delete_many("res.partner", [{"id": 11}, {"id": 12}])
    result = client.upsert_many(
        "res.partner",
        [
            {"email": "a@example.com", "name": "A"},
            {"email": "b@example.com", "name": "B"},
        ],
        key_fields=["email"],
    )

    assert inserted == [11, 12]
    assert updated == 2
    assert deleted == 2
    assert len(writes) == 2
    assert len(deletes) == 1
    assert result["created_count"] == 1
    assert result["updated_count"] == 1


def test_model_batch_helpers_accept_dataframe():
    import pandas as pd

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", key_fields=["email"])
    frame = pd.DataFrame(
        [
            {"id": 1, "email": "a@example.com", "name": "Alice"},
            {"id": 2, "email": "b@example.com", "name": "Bob"},
        ]
    )

    client.bulk_create = lambda model, records: [1, 2]  # type: ignore[method-assign]
    client.write = lambda model, ids, values: True  # type: ignore[method-assign]
    client.unlink = lambda model, ids: True  # type: ignore[method-assign]
    client.upsert = (  # type: ignore[method-assign]
        lambda model, lookup, values=None, fields=None, strict=True: (
            {"id": lookup["id"] if "id" in lookup else 1},
            False,
        )
    )
    client.search_read = lambda model, domain, fields=None, limit=None, offset=0, order=None: [{"id": 1}]  # type: ignore[method-assign]

    inserted = partner_model.insert(frame)
    updated = partner_model.update(frame)
    deleted = partner_model.delete(frame)
    upserted = partner_model.upsert(frame)
    saved = partner_model.save(frame)
    deleted_by_keys = partner_model.delete_by_keys(frame)

    assert inserted.ids == [1, 2]
    assert updated == 2
    assert deleted == 2
    assert upserted["updated_count"] == 2
    assert saved["updated_count"] == 2
    assert deleted_by_keys == 1


def test_model_batch_upsert_requires_key_fields():
    import pandas as pd

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env["res.partner"]
    frame = pd.DataFrame([{"email": "a@example.com", "name": "Alice"}])

    with pytest.raises(ValueError, match="key_fields"):
        partner_model.upsert(frame)


def test_model_validate_detects_duplicate_key_rows():
    import pandas as pd

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", key_fields=["email"])
    frame = pd.DataFrame(
        [
            {"email": "dup@example.com", "name": "Alice"},
            {"email": "dup@example.com", "name": "Bob"},
        ]
    )

    with pytest.raises(ValueError, match="Duplicate key rows"):
        partner_model.validate(frame, operation="save")


def test_model_validate_returns_dataframe():
    import pandas as pd

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", key_fields=["email"])
    frame = pd.DataFrame([{"email": "a@example.com", "name": "Alice"}])

    validated = partner_model.validate(frame, operation="save")

    assert isinstance(validated, pd.DataFrame)
    assert list(validated.columns) == ["email", "name"]


def test_model_validate_missing_fields_branches():
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    model = client.env.model("res.partner", key_fields=["email"])
    client.search_read = lambda *args, **kwargs: []  # type: ignore[method-assign]
    with pytest.raises(ValueError):
        model.validate([{"name": "A"}], operation="save")
    with pytest.raises(ValueError):
        model.validate([{"name": "A"}], operation="update")
    with pytest.raises(ValueError):
        client.env["res.partner"].validate([{"name": "A"}], operation="save")
    with pytest.raises(ValueError):
        client.env["res.partner"].delete_by_keys([{"email": "a@example.com"}])
    with pytest.raises(ValueError):
        model.delete_by_keys([{"name": "A"}])
    with pytest.raises(ValueError):
        model.delete([{"name": "A"}])
    assert client.env["res.partner"].delete_by_keys([{"email": "a@example.com"}], key_fields=["email"]) == 0


def test_upsert_strict_raises_when_lookup_matches_multiple_records(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    monkeypatch.setattr(
        client,
        "search_read",
        lambda model, domain, fields=None, limit=None, offset=0, order=None: [{"id": 1}, {"id": 2}],
    )

    with pytest.raises(OdooError, match="expected at most one existing"):
        client.upsert("res.partner", lookup={"email": "dup@example.com"})


def test_delete_by_keys_strict_raises_when_lookup_matches_multiple_records(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", key_fields=["email"])
    monkeypatch.setattr(
        client,
        "search_read",
        lambda model, domain, fields=None, limit=None, offset=0, order=None: [{"id": 1}, {"id": 2}],
    )

    with pytest.raises(OdooError, match="expected at most one existing"):
        partner_model.delete_by_keys([{"email": "dup@example.com"}])


def test_record_save_refresh_and_delete(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name", "phone"])
    state = {"id": 11, "name": "Alice", "phone": "+841"}

    monkeypatch.setattr(client, "create", lambda model, values: state["id"])
    monkeypatch.setattr(client, "write", lambda model, ids, values: state.update(values) or True)
    monkeypatch.setattr(client, "unlink", lambda model, ids: True)
    monkeypatch.setattr(
        client,
        "search_read",
        lambda model, domain, fields=None, limit=None, offset=0, order=None: [dict(state)] if state.get("id") else [],
    )

    record = partner_model.new(name="Alice", phone="+840")
    record.save()
    assert record.id == 11

    record.phone = "+842"
    record.save()
    assert record.phone == "+842"

    record.delete()
    assert record.id is None


def test_model_validate_and_repr_paths():
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    model = client.env.model("res.partner", fields=["id", "name"], key_fields=["email"])

    assert "key_fields" in repr(model)
    assert model.selected_fields == ["id", "name"]
    assert model.key_fields == ["email"]
    with pytest.raises(ValueError):
        model.validate([], require_non_empty=True)


def test_browse_and_recordset_helpers(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name"])
    monkeypatch.setattr(client, "read", lambda model, ids, fields=None, load=None: [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}])
    monkeypatch.setattr(client, "search", lambda model, domain, offset=0, limit=None, order=None: [1, 2])
    monkeypatch.setattr(client, "write", lambda model, ids, values: True)
    monkeypatch.setattr(client, "unlink", lambda model, ids: True)

    recordset = partner_model.browse([1, 2])

    assert recordset.exists() is True
    assert len(recordset.records()) == 2
    assert recordset.first().name == "Alice"
    assert recordset.write({"name": "Updated"}) is True
    assert recordset.unlink() is True


def test_update_or_create_and_bulk_helpers(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env.model("res.partner", fields=["id", "name", "email"])
    state = {"id": 3, "name": "Alice", "email": "a@example.com"}
    monkeypatch.setattr(
        client,
        "search_read",
        lambda model, domain, fields=None, limit=None, offset=0, order=None: [dict(state)]
        if ("a@example.com" in str(domain) or "3" in str(domain))
        else [],
    )
    monkeypatch.setattr(client, "create", lambda model, values: 3 if isinstance(values, dict) else [4, 5])
    monkeypatch.setattr(client, "bulk_create", lambda model, values_list: [4, 5])
    monkeypatch.setattr(client, "bulk_write", lambda model, ids, values: True)
    monkeypatch.setattr(client, "write", lambda model, ids, values: state.update(values) or True)

    record, created = partner_model.objects.update_or_create(defaults={"name": "Alice 2"}, email="a@example.com")
    created_records = partner_model.objects.bulk_create([{"name": "B"}, {"name": "C"}])

    assert created is False
    assert record.name == "Alice 2"
    assert created_records.ids == [4, 5]
    assert partner_model.objects.bulk_write([4, 5], {"name": "X"}) is True


def test_env_getitem_returns_model():
    client = OdooClient("http://127.0.0.1:8070", "odoo")

    partner_model = client.env["res.partner"]

    assert partner_model.model == "res.partner"
    assert partner_model.client is client


def test_model_fields_uses_cache(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo")
    calls = []

    def fake_fields_get(model, attributes=None, allfields=None):
        calls.append((model, attributes, allfields))
        return {"name": {"type": "char"}}

    monkeypatch.setattr(client, "fields_get", fake_fields_get)

    partner_model = client.env["res.partner"]
    fields_a = partner_model.fields
    fields_b = partner_model.fields

    assert fields_a == {"name": {"type": "char"}}
    assert fields_b == {"name": {"type": "char"}}
    assert partner_model.field_names == ["name"]
    assert len(calls) == 1


def test_model_doc_and_functions_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    monkeypatch.setattr(client, "_json_request", lambda request, use_opener=False: {"methods": ["write", "read"]})
    assert client.model_functions("res.partner", refresh=True) == ["read", "write"]

    monkeypatch.setattr(client, "_json_request", lambda request, use_opener=False: [])
    with pytest.raises(OdooHttpError):
        client.model_doc("res.partner", refresh=True)

    client.api_key = None
    monkeypatch.setattr(client, "web_authenticate", lambda: {"uid": 2})
    monkeypatch.setattr(client, "_json_request", lambda request, use_opener=False: {"methods": {}})
    assert client.model_doc("res.partner", refresh=True) == {"methods": {}}
    assert client.model_functions("res.partner", refresh=True) == []
    assert client.model_methods("res.partner", refresh=True) == {}
    assert client.model_doc("res.partner") == {"methods": {}}
    client._model_doc_cache["x.model"] = {"methods": 1}
    assert client.model_functions("x.model") == []


def test_model_functions_and_methods_use_doc_cache(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo")
    calls = []

    def fake_doc(model, refresh=False):
        calls.append((model, refresh))
        return {"methods": {"name_search": {"doc": "..."}, "search_count": {"doc": "..."}}}

    monkeypatch.setattr(client, "model_doc", fake_doc)

    partner_model = client.env["res.partner"]
    functions = partner_model.functions
    methods = partner_model.methods

    assert functions == ["name_search", "search_count"]
    assert "name_search" in methods
    assert len(calls) == 2


def test_model_and_record_call_delegate_to_client(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    partner_model = client.env["res.partner"]
    captured = []

    def fake_call_method(model, method, args=None, kwargs=None, transport="auto"):
        captured.append((model, method, args, kwargs, transport))
        return "ok"

    monkeypatch.setattr(client, "call_method", fake_call_method)

    result_model = partner_model.call("name_search", "alice", limit=5)
    record = partner_model.record({"id": 10, "name": "Alice"})
    result_record = record.call("write", {"phone": "+84"})

    assert result_model == "ok"
    assert result_record == "ok"
    assert captured[0] == ("res.partner", "name_search", ("alice",), {"limit": 5}, "auto")
    assert captured[1] == ("res.partner", "write", [[10], {"phone": "+84"}], {}, "auto")


def test_execute_and_report_and_wizard_helpers(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", api_key="secret")
    monkeypatch.setattr(client, "call_method", lambda model, method, args=None, kwargs=None, transport="auto": ("ok", model, method, args, kwargs, transport))
    monkeypatch.setattr(client, "execute", lambda model, method, *args, transport="auto", **kwargs: ("ok", model, method, args, kwargs, transport))
    monkeypatch.setattr(client, "create_wizard", lambda model, values=None, transport="xmlrpc": 9)
    monkeypatch.setattr(client, "web_authenticate", lambda: {"uid": 2})
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b"PDF")

    executed = client.execute("res.partner", "name_search", "Alice", limit=5)
    wizard_result = client.run_wizard("res.config.settings", "execute", values={"x": 1})
    report_bytes = client.download_report("sale.report_saleorder", [1, 2])

    assert executed[0] == "ok"
    assert wizard_result[2] == "execute"
    assert report_bytes == b"PDF"


def test_client_transport_and_http_helpers(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    monkeypatch.setattr(client, "json2_call", lambda model, method, payload=None, **kwargs: ("json2", model, method, payload))
    monkeypatch.setattr(client, "execute_kw", lambda model, method, args=None, kwargs=None: ("xmlrpc", model, method, args, kwargs))
    assert client.call_method("res.partner", "search", kwargs={"domain": []}, transport="auto")[0] == "json2"
    assert client.call_method("res.partner", "write", args=[[1], {"name": "A"}], transport="auto")[0] == "xmlrpc"
    assert client.call_method("res.partner", "search", kwargs={"domain": []}, transport="json2")[0] == "json2"
    assert client.call_method("res.partner", "search", args=[["x"]], transport="json2")[3]["args"] == [["x"]]
    assert client.call_method("res.partner", "write", args=[[1]], transport="xmlrpc")[0] == "xmlrpc"
    with pytest.raises(ValueError):
        client.call_method("res.partner", "search", transport="bad")

    request = odoo_mod.Request("http://example.com")
    monkeypatch.setattr(client, "_call_with_retry", lambda operation, callback, retriable: b'{"result": 1}')
    assert client._binary_request(request) == b'{"result": 1}'
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b'{"result": 2}')
    assert client._json_request(request) == 2
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b'{"error": {"message": "boom"}}')
    with pytest.raises(OdooHttpError):
        client._json_request(request)
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b'not-json')
    with pytest.raises(OdooHttpError):
        client._json_request(request)
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b'{"x": 1}')
    assert client._json_request(request) == {"x": 1}
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b'{"x": 1}')
    assert client._json_request(request) == {"x": 1}


def test_binary_request_error_branches():
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    request = odoo_mod.Request("http://example.com")

    def raise_http(operation, callback, retriable):
        raise HTTPError(request.full_url, 500, "boom", hdrs=None, fp=_FakeResponse("bad"))

    client._call_with_retry = raise_http  # type: ignore[method-assign]
    with pytest.raises(OdooHttpError):
        client._binary_request(request)

    def raise_url(operation, callback, retriable):
        raise URLError("down")

    client._call_with_retry = raise_url  # type: ignore[method-assign]
    with pytest.raises(OdooHttpError):
        client._binary_request(request)


def test_client_crud_transport_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    captured = {}

    def fake_json2(model, method, payload=None, **kwargs):
        captured[(model, method)] = payload
        mapping = {
            "search": [1, 2],
            "search_count": 2,
            "read": [{"id": 1}],
            "search_read": [{"id": 1}],
            "fields_get": {"name": {"type": "char"}},
            "default_get": {"name": "x"},
            "name_search": [[1, "A"]],
            "read_group": [{"id_count": 1}],
            "create": [7, 8],
            "write": True,
            "unlink": True,
        }
        return mapping[method]

    monkeypatch.setattr(client, "json2_call", fake_json2)
    assert client.search("res.partner", [], limit=1, order="id desc") == [1, 2]
    assert client.search_count("res.partner", []) == 2
    assert client.read("res.partner", [1], fields=["id"], load="x") == [{"id": 1}]
    assert client.search_read("res.partner", [], fields=["id"], limit=1, order="id desc") == [{"id": 1}]
    assert client.fields_get("res.partner", attributes=["type"], allfields=["name"]) == {"name": {"type": "char"}}
    assert client.default_get("res.partner", ["name"]) == {"name": "x"}
    assert client.name_search("res.partner", "A", args=[["active", "=", True]]) == [[1, "A"]]
    assert client.read_group("res.partner", [], fields=["id:count"], groupby=["is_company"], limit=1, orderby="id") == [{"id_count": 1}]
    assert client.create("res.partner", [{"name": "A"}, {"name": "B"}]) == [7, 8]
    assert client.write("res.partner", [1], {"name": "A"}) is True
    assert client.unlink("res.partner", [1]) is True

    client.api_key = None
    monkeypatch.setattr(client, "execute_kw", lambda model, method, args=None, kwargs=None: 7 if method == "create" else True)
    assert client.create("res.partner", {"name": "A"}) == 7


def test_client_misc_helpers_and_retry(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", retry_count=1, retry_delay=0)
    attempts = {"n": 0}

    def flaky():
        attempts["n"] += 1
        if attempts["n"] == 1:
            raise OSError("retry")
        return "ok"

    assert client._call_with_retry("x", flaky, retriable=(OSError,)) == "ok"
    monkeypatch.setattr(
        client,
        "_xmlrpc_proxy",
        lambda path: SimpleNamespace(version=lambda: {"server_version": "19.0", "server_serie": "19.0"}),
    )
    assert client.version_info()["server_serie"] == "19.0"
    assert client.with_company(5, allowed_company_ids=[6]).context["allowed_company_ids"] == [5, 6]

    monkeypatch.setattr(client, "execute", lambda model, method, *args, transport="auto", **kwargs: 9 if method == "create" else ("ok", args, kwargs))
    assert client.create_wizard("x.wizard", {"a": 1}) == 9
    assert client.run_wizard("x.wizard", "action_run", wizard_id=9)[0] == "ok"

    monkeypatch.setattr(client, "_json_request", lambda request, use_opener=False: {"uid": 2})
    assert client._web_json("/web/test", {"x": 1}) == {"uid": 2}

    monkeypatch.setattr(client, "read", lambda model, ids, fields=None, load=None: [])
    with pytest.raises(OdooError):
        client.download_attachment(1)
    monkeypatch.setattr(client, "read", lambda model, ids, fields=None, load=None: [{"datas": ""}])
    assert client.download_attachment(1) == b""

    monkeypatch.setattr(client, "create", lambda model, values: 11)
    assert client.upload_attachment(name="a.txt", content="hello") == 11
    assert client.browse("res.partner", 1).ids == [1]


def test_delete_many_skips_validation_for_raw_id_lists(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo")
    model = client.model("res.partner")
    delete_calls = []

    monkeypatch.setattr(model, "validate", lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("validate should not run")))
    monkeypatch.setattr(client, "unlink", lambda model_name, ids: delete_calls.append((model_name, list(ids))) or True)

    deleted = model.delete_many([1, 2, 3])

    assert deleted == 3
    assert delete_calls == [("res.partner", [1, 2, 3])]


def test_auth_and_rpc_error_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo")
    with pytest.raises(OdooAuthenticationError):
        client._auth_secret()
    with pytest.raises(OdooAuthenticationError):
        client.authenticate()

    class FaultyCommon:
        def authenticate(self, *args, **kwargs):
            raise odoo_mod.xmlrpc.client.Fault(1, "boom")

    client = OdooClient(
        "http://127.0.0.1:8070",
        "odoo",
        login="admin",
        password="admin",
        server_proxy_factory=lambda url, allow_none=True: FaultyCommon(),
    )
    with pytest.raises(odoo_mod.OdooRpcError):
        client.authenticate()

    class EmptyCommon:
        def authenticate(self, *args, **kwargs):
            return 0

    client = OdooClient(
        "http://127.0.0.1:8070",
        "odoo",
        login="admin",
        password="admin",
        server_proxy_factory=lambda url, allow_none=True: EmptyCommon(),
    )
    with pytest.raises(OdooAuthenticationError):
        client.authenticate()

    monkeypatch.setitem(
        __import__("sys").modules,
        "django.conf",
        SimpleNamespace(settings=SimpleNamespace(ODOO={"URL": "http://127.0.0.1:8070", "DB": "odoo"})),
    )
    assert OdooClient.from_django_settings(None).database == "odoo"


def test_execute_kw_and_web_session_error_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", context={"lang": "en_US"})
    monkeypatch.setattr(client, "_require_uid", lambda: 2)
    monkeypatch.setattr(client, "_auth_secret", lambda: "secret")

    class FaultyObject:
        def execute_kw(self, *args, **kwargs):
            raise odoo_mod.xmlrpc.client.Fault(1, "rpc boom")

    monkeypatch.setattr(client, "_xmlrpc_proxy", lambda path: FaultyObject())
    with pytest.raises(odoo_mod.OdooRpcError):
        client.execute_kw("res.partner", "search")

    client2 = OdooClient("http://127.0.0.1:8070", "odoo")
    with pytest.raises(OdooAuthenticationError):
        client2.web_authenticate()

    client3 = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin")
    monkeypatch.setattr(client3, "_web_json", lambda path, payload: {"uid": 0})
    with pytest.raises(OdooAuthenticationError):
        client3.web_authenticate()


def test_web_call_kw_and_api_key_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin", api_key="secret", context={"lang": "en_US"})
    captured = {}
    monkeypatch.setattr(client, "_web_json", lambda path, payload: captured.setdefault("payload", payload) or {"ok": True})
    client.web_call_kw("res.partner", "search", kwargs={"context": {"tz": "UTC"}}, context={"company_id": 1})
    assert captured["payload"]["kwargs"]["context"] == {"lang": "en_US", "tz": "UTC", "company_id": 1}

    monkeypatch.setattr(client, "web_authenticate", lambda: {"uid": 2})
    monkeypatch.setattr(client, "web_call_kw", lambda *args, **kwargs: {"res_model": "res.users.identitycheck"})
    with pytest.raises(OdooHttpError):
        client.create_api_key()

    monkeypatch.setattr(client, "web_call_kw", lambda *args, **kwargs: {"context": {}})
    with pytest.raises(OdooHttpError):
        client.create_api_key()

    client.password = None
    with pytest.raises(OdooAuthenticationError):
        client.create_api_key()

    client.password = "admin"
    client.api_key = None
    monkeypatch.setattr(client, "create_api_key", lambda **kwargs: "secret")
    assert client.ensure_api_key() == "secret"
    client.api_key = "secret"
    assert client.ensure_api_key() == "secret"
    monkeypatch.setattr(client, "json2_call", lambda *args, **kwargs: True)
    assert client.revoke_api_key("other") is True
    with pytest.raises(OdooAuthenticationError):
        OdooClient("http://127.0.0.1:8070", "odoo").revoke_api_key()
    fresh_client = OdooClient("http://127.0.0.1:8070", "odoo")
    with pytest.raises(OdooAuthenticationError):
        fresh_client.json2_call("res.partner", "search", {})


def test_batch_methods_log_start_and_finish():
    logger = logging.getLogger("tests.odoo.batch.success")
    logger.handlers = []
    logger.setLevel(logging.INFO)
    logger.propagate = False
    handler = _ListHandler()
    logger.addHandler(handler)

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret", logger=logger)
    partner_model = client.env.model("res.partner", key_fields=["email"])
    client.upsert = (  # type: ignore[method-assign]
        lambda model, lookup, values=None, fields=None, strict=True: ({"id": 1}, False)
    )

    result = partner_model.save([{"email": "a@example.com", "name": "Alice"}])

    assert result["updated_count"] == 1
    save_records = [record for record in handler.records if getattr(record, "operation", None) == "res.partner.save"]
    assert [record.getMessage() for record in save_records] == ["Odoo operation started", "Odoo operation finished"]
    assert save_records[0].status == "started"
    assert save_records[1].status == "success"
    assert hasattr(save_records[1], "duration_seconds")


def test_batch_methods_log_failures():
    logger = logging.getLogger("tests.odoo.batch.error")
    logger.handlers = []
    logger.setLevel(logging.INFO)
    logger.propagate = False
    handler = _ListHandler()
    logger.addHandler(handler)

    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret", logger=logger)
    partner_model = client.env.model("res.partner", key_fields=["email"])
    client.upsert = (  # type: ignore[method-assign]
        lambda model, lookup, values=None, fields=None, strict=True: (_ for _ in ()).throw(OdooError("boom"))
    )

    with pytest.raises(OdooError, match="boom"):
        partner_model.save([{"email": "a@example.com", "name": "Alice"}])

    save_records = [record for record in handler.records if getattr(record, "operation", None) == "res.partner.save"]
    assert [record.getMessage() for record in save_records] == ["Odoo operation started", "Odoo operation failed"]
    assert save_records[1].status == "error"
    assert hasattr(save_records[1], "duration_seconds")


def test_remaining_client_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", api_key="secret")
    deleted_chunks = []
    monkeypatch.setattr(client, "unlink", lambda model, ids: deleted_chunks.append(list(ids)) or True)
    assert client.delete_many("res.partner", [1, 2, 3], chunk_size=2) == 3
    assert deleted_chunks == [[1, 2], [3]]

    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [{"id": 1, "name": "Old"}])
    monkeypatch.setattr(client, "write", lambda *args, **kwargs: True)
    monkeypatch.setattr(client, "read", lambda *args, **kwargs: [{"id": 1, "name": "New"}])
    record, created = client.upsert("res.partner", lookup={"email": "a@example.com"}, values={"name": "New"})
    assert created is False
    assert record["name"] == "New"

    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [])
    monkeypatch.setattr(client, "create", lambda *args, **kwargs: 9)
    monkeypatch.setattr(client, "read", lambda *args, **kwargs: [{"id": 9, "email": "a@example.com"}])
    record, created = client.upsert("res.partner", lookup={"email": "a@example.com"}, values={"name": "New"}, fields=["id"])
    assert created is True
    assert record["id"] == 9

    monkeypatch.setattr(client, "create", lambda model, values: 11)
    assert client.upload_attachment(name="a.txt", content="hello", res_model="res.partner", res_id=5) == 11

    monkeypatch.setattr(client, "read", lambda model, ids, fields=None, load=None: [])
    with pytest.raises(OdooError):
        client.download_attachment(5)

    monkeypatch.setattr(client, "create_wizard", lambda *args, **kwargs: 12)
    monkeypatch.setattr(client, "execute", lambda model, method, *args, **kwargs: {"id": args[0][0]})
    assert client.run_wizard("x.wizard", "action_apply") == {"id": 12}

    monkeypatch.setattr(client, "web_authenticate", lambda: {"uid": 2})
    captured = {}
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: captured.setdefault("req", request) or b"PDF")
    client.download_report("sale.report", 7, converter="pdf", data={"x": 1}, context={"lang": "vi_VN"})
    assert captured["req"].data is not None

    request = odoo_mod.Request("http://example.com")
    monkeypatch.setattr(client, "_binary_request", lambda request, use_opener=False: b'{"error": {"message": "bad"}}')
    with pytest.raises(OdooHttpError):
        client._json_request(request)


def test_remaining_wrapper_and_xmlrpc_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo")
    monkeypatch.setattr(
        client,
        "execute_kw",
        lambda model, method, args=None, kwargs=None: {
            "search": [1],
            "search_count": 1,
            "search_read": [{"id": 1}],
            "fields_get": {"name": {"type": "char"}},
            "default_get": {"name": "x"},
            "name_search": [[1, "A"]],
            "read_group": [{"id_count": 1}],
            "write": True,
            "unlink": True,
            "create": [7, 8],
        }[method],
    )
    assert client.search("res.partner", []) == [1]
    assert client.search_count("res.partner", []) == 1
    assert client.search_read("res.partner", []) == [{"id": 1}]
    assert client.search_read_all("res.partner", []) == [{"id": 1}]
    assert client.fields_get("res.partner") == {"name": {"type": "char"}}
    assert client.default_get("res.partner", ["name"]) == {"name": "x"}
    assert client.name_search("res.partner", "A") == [[1, "A"]]
    assert client.read_group("res.partner", [], fields=["id:count"], groupby=["x"]) == [{"id_count": 1}]
    assert client.create("res.partner", [{"name": "A"}, {"name": "B"}]) == [7, 8]
    assert client.write("res.partner", 1, {"name": "A"}) is True
    assert client.bulk_write("res.partner", 1, {"name": "A"}) is True
    assert client.unlink("res.partner", 1) is True
    with pytest.raises(ValueError):
        client.update_many("res.partner", [{"name": "A"}])
    monkeypatch.setattr(client, "model", lambda model, fields=None, key_fields=None: SimpleNamespace(delete_by_keys=lambda *args, **kwargs: 1))
    assert client.delete_by_keys("res.partner", [{"email": "a@example.com"}], key_fields=["email"]) == 1


def test_delete_many_mapping_scalar_and_iterable_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo")
    model = client.env["res.partner"]
    deleted = []
    monkeypatch.setattr(client, "unlink", lambda model_name, ids: deleted.append((model_name, ids)) or True)

    assert model.delete({"id": 1}) == 1
    assert model.delete(2) == 1
    assert client.delete_many("res.partner", {"id": 3}) == 1
    assert client.delete_many("res.partner", [{"id": 5}]) == 1
    assert client.delete_many("res.partner", 6) == 1
    assert client.delete_many("res.partner", [3, 4]) == 2

    assert deleted[0] == ("res.partner", [1])
    assert deleted[1] == ("res.partner", [2])
    assert deleted[2] == ("res.partner", [3])
    assert deleted[3] == ("res.partner", [5])
    assert deleted[4] == ("res.partner", [6])
    assert deleted[5] == ("res.partner", [3, 4])


def test_remaining_misc_branches(monkeypatch):
    client = OdooClient("http://127.0.0.1:8070", "odoo", login="admin", password="admin")
    monkeypatch.setattr(client, "search_read", lambda *args, **kwargs: [{"id": 1}])
    monkeypatch.setattr(client, "create", lambda *args, **kwargs: 1)
    monkeypatch.setattr(client, "read", lambda *args, **kwargs: [{"id": 1}])
    assert client.upsert("res.partner", lookup={"email": "a@example.com"})[1] is False

    client._fields_cache["res.partner|"] = {"name": {"type": "char"}}
    assert client.model_fields("res.partner") == {"name": {"type": "char"}}

    retry_client = OdooClient("http://127.0.0.1:8070", "odoo", retry_count=0)
    with pytest.raises(OSError):
        retry_client._call_with_retry("x", lambda: (_ for _ in ()).throw(OSError("boom")), retriable=(OSError,))
    retry_client.retry_count = -1
    with pytest.raises(RuntimeError):
        retry_client._call_with_retry("x", lambda: "ok", retriable=(OSError,))

    monkeypatch.setattr(client, "web_authenticate", lambda: {"uid": 2})
    captured = {}

    def fake_binary(request, use_opener=False):
        captured["data"] = request.data
        return b"PDF"

    monkeypatch.setattr(client, "_binary_request", fake_binary)
    assert client.download_report("sale.report", [1], data={"x": 1}, context={"lang": "vi_VN"}) == b"PDF"
    assert b'"data": {"x": 1}' in captured["data"]
