## Typing stubs for dateparser

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`dateparser`](https://github.com/scrapinghub/dateparser) package. It can be used by type checkers
to check code that uses `dateparser`. This version of
`types-dateparser` aims to provide accurate annotations for
`dateparser~=1.4.0`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/dateparser`](https://github.com/python/typeshed/tree/main/stubs/dateparser)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`e78872c57e4129e793f7665d62ecc91bbdc6f483`](https://github.com/python/typeshed/commit/e78872c57e4129e793f7665d62ecc91bbdc6f483).