"""End-to-end SDK tests against a local mock Keystone server."""

from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any, Dict, List

import pytest

from polarity_keystone import (
    Keystone, traced,
    # scorers
    ExactMatch, Levenshtein, NumericDiff, JSONDiff, JSONValidity, SemanticListContains,
    Factuality, Battle, ClosedQA, Humor, Moderation, Summarization, SQLJudge, Translation, Security,
    ContextPrecision, ContextRecall, ContextRelevancy, ContextEntityRecall,
    Faithfulness, AnswerRelevancy, AnswerSimilarity, AnswerCorrectness,
    EmbeddingSimilarity, openai_embedder,
    FileExists, FileContains, CommandExits, SQLEquals, LLMJudge,
    Scorer, run_client_scorers, scorers_to_invariants,
    set_default_llm_client,
    register_otel_flush, flush_otel,
    Prompt, render_template,
)
from polarity_keystone.types import KeystoneError
from conftest import Response


# ────────────────────────────────────────────────────────────────────────
# Sandboxes
# ────────────────────────────────────────────────────────────────────────


def test_sandbox_lifecycle(mock_server, ks):
    mock_server.route("POST", "/v1/sandboxes")(lambda r: Response(201, {
        "id": "sb-1", "spec_id": "spec-1", "state": "ready",
        "path": "/tmp/sb-1", "url": "http://sb-1",
        "services": {"db": {"host": "localhost", "port": 5432, "ready": True}},
    }))
    mock_server.route("GET", "/v1/sandboxes")(lambda r: Response(200, [{"id": "sb-1", "state": "ready"}]))
    mock_server.route("GET", "/v1/sandboxes/sb-1")(lambda r: Response(200, {"id": "sb-1", "state": "ready"}))
    mock_server.route("DELETE", "/v1/sandboxes/sb-1")(lambda r: Response(204))
    mock_server.route("POST", "/v1/sandboxes/sb-1/commands")(lambda r: Response(200, {
        "command": r.json()["command"], "stdout": "ok\n", "stderr": "", "exit_code": 0, "duration_ms": 1,
    }))
    mock_server.route("POST", "/v1/sandboxes/sb-1/files")(lambda r: Response(204))
    mock_server.route("GET", "/v1/sandboxes/sb-1/files/hello.py")(lambda r: Response(
        200, raw=b"print('hi')", headers={"Content-Type": "text/plain"}
    ))
    mock_server.route("DELETE", "/v1/sandboxes/sb-1/files/hello.py")(lambda r: Response(204))
    mock_server.route("GET", "/v1/sandboxes/sb-1/state")(lambda r: Response(200, {"captured_at": "now", "files": {}}))
    mock_server.route("GET", "/v1/sandboxes/sb-1/diff")(lambda r: Response(200, {"added": ["x"]}))

    sb = ks.sandboxes.create(spec_id="spec-1")
    assert sb.id == "sb-1" and sb.state == "ready"
    assert sb.services["db"].port == 5432

    assert len(ks.sandboxes.list()) == 1
    assert ks.sandboxes.get("sb-1").id == "sb-1"

    cmd = ks.sandboxes.run_command("sb-1", "ls")
    assert cmd.exit_code == 0 and cmd.stdout == "ok\n"

    ks.sandboxes.write_file("sb-1", "hello.py", "print('hi')")
    body = ks.sandboxes.read_file("sb-1", "hello.py")
    assert body == b"print('hi')"
    ks.sandboxes.delete_file("sb-1", "hello.py")

    snap = ks.sandboxes.state("sb-1")
    assert snap.captured_at == "now"
    diff = ks.sandboxes.diff("sb-1")
    assert "x" in diff.added

    ks.sandboxes.destroy("sb-1")


def test_trace_ingest_and_fetch(mock_server, ks):
    captured_events: List[Dict] = []
    @mock_server.route("POST", "/v1/sandboxes/sb-1/trace")
    def _(r):
        captured_events.extend(r.json()["events"])
        return Response(200, {"ingested": len(r.json()["events"])})
    @mock_server.route("GET", "/v1/sandboxes/sb-1/trace")
    def _g(r):
        return Response(200, {"events": [{"tool": "t1"}], "metrics": {}})

    resp = ks.sandboxes.ingest_trace("sb-1", [{"event_type": "tool_use", "tool": "run_cmd"}])
    assert resp["ingested"] == 1
    assert captured_events[0]["tool"] == "run_cmd"
    fetched = ks.sandboxes.get_trace("sb-1")
    assert len(fetched["events"]) == 1


# ────────────────────────────────────────────────────────────────────────
# Experiments + RunAndWait + client-side scorers
# ────────────────────────────────────────────────────────────────────────


def test_experiment_flow(mock_server, ks):
    mock_server.route("POST", "/v1/experiments")(lambda r: Response(201, {
        "id": "exp-1", "name": r.json()["name"], "spec_id": r.json()["spec_id"], "status": "created",
    }))
    mock_server.route("GET", "/v1/experiments")(lambda r: Response(200, [{"id": "exp-1"}]))
    mock_server.route("GET", "/v1/experiments/exp-1")(lambda r: Response(200, {
        "experiment_id": "exp-1", "total_scenarios": 1, "passed": 1, "scenarios": []
    }))
    mock_server.route("POST", "/v1/experiments/compare")(lambda r: Response(200, {
        "baseline_id": "a", "candidate_id": "b", "regressed": False,
    }))
    mock_server.route("GET", "/v1/metrics/experiments/exp-1")(lambda r: Response(200, {
        "experiment_id": "exp-1", "summary": {"pass_rate": 1.0}, "tool_breakdown": {},
        "cost_trend": [], "pass_rate_trend": [],
    }))

    exp = ks.experiments.create("e", "spec-1")
    assert exp.id == "exp-1"
    assert len(ks.experiments.list()) == 1

    cmp = ks.experiments.compare("a", "b")
    assert not cmp.regressed

    m = ks.experiments.metrics("exp-1")
    assert m.summary.pass_rate == 1.0


def test_run_and_wait_with_scores(mock_server, ks):
    poll = {"count": 0}

    @mock_server.route("POST", "/v1/experiments/exp-1/run")
    def _run(r):
        return Response(202)

    @mock_server.route("GET", "/v1/experiments/exp-1")
    def _g(r):
        poll["count"] += 1
        done = poll["count"] >= 2
        return Response(200, {
            "experiment_id": "exp-1",
            "total_scenarios": 2,
            "passed": 2 if done else 0,
            "failed": 0,
            "flaky": 0,
            "errors": 0,
            "metrics": {},
            "scenarios": [
                {"scenario_id": "s-1", "status": "pass", "agent_output": "hello world",
                 "parameters": {"expected": "hello world"}, "invariants": []},
                {"scenario_id": "s-2", "status": "pass", "agent_output": "bye world",
                 "parameters": {"expected": "bye moon"}, "invariants": []},
            ] if done else [],
        })

    scores = [
        ExactMatch(expected_key="expected", case_sensitive=False),
        Levenshtein(expected_key="expected", threshold=0.5),
    ]
    results = ks.experiments.run_and_wait("exp-1", poll_interval=0.01, timeout=5, scores=scores)
    assert results.total_scenarios == 2

    inv1 = results.scenarios[0].invariants
    assert any(i.name == "exact_match" and i.passed for i in inv1)
    inv2 = results.scenarios[1].invariants
    assert any(i.name == "exact_match" and not i.passed for i in inv2)


def test_run_and_wait_timeout(mock_server, ks):
    mock_server.route("POST", "/v1/experiments/exp-x/run")(lambda r: Response(202))
    mock_server.route("GET", "/v1/experiments/exp-x")(lambda r: Response(200, {
        "experiment_id": "exp-x", "total_scenarios": 3, "passed": 0, "scenarios": []
    }))
    with pytest.raises(KeystoneError):
        ks.experiments.run_and_wait("exp-x", poll_interval=0.01, timeout=0.05)


# ────────────────────────────────────────────────────────────────────────
# Scoring + Datasets + Alerts
# ────────────────────────────────────────────────────────────────────────


def test_scoring_service(mock_server, ks):
    mock_server.route("POST", "/v1/score-rules")(lambda r: Response(201, {
        "id": "r1", "name": r.json()["name"], "type": r.json()["type"], "config": r.json()["config"],
    }))
    mock_server.route("GET", "/v1/score-rules")(lambda r: Response(200, [{"id": "r1", "type": "contains"}]))
    mock_server.route("DELETE", "/v1/score-rules/r1")(lambda r: Response(204))
    mock_server.route("POST", "/v1/experiments/exp-1/score")(lambda r: Response(202, {"status": "queued"}))
    mock_server.route("GET", "/v1/experiments/exp-1/scores")(lambda r: Response(200, [
        {"rule_id": "r1", "trace_id": 1, "score": 0.9, "passed": True}
    ]))

    rule = ks.scoring.create_rule("r", "contains", {"text": "ok"})
    assert rule["id"] == "r1"
    assert len(ks.scoring.list_rules()) == 1
    assert ks.scoring.score_experiment("exp-1", ["r1"])["status"] == "queued"
    scores = ks.scoring.get_scores("exp-1")
    assert scores[0]["score"] == 0.9
    ks.scoring.delete_rule("r1")


def test_dataset_service(mock_server, ks):
    mock_server.route("POST", "/v1/datasets")(lambda r: Response(201, {"id": "ds-1", "name": "d"}))
    mock_server.route("GET", "/v1/datasets")(lambda r: Response(200, [{"id": "ds-1"}]))
    mock_server.route("GET", "/v1/datasets/ds-1")(lambda r: Response(200, {"id": "ds-1"}))
    mock_server.route("DELETE", "/v1/datasets/ds-1")(lambda r: Response(204))
    mock_server.route("POST", "/v1/datasets/ds-1/records")(lambda r: Response(200, {"added": 1}))
    mock_server.route("GET", "/v1/datasets/ds-1/records")(lambda r: Response(200, [{"input": {"q": 1}}]))

    assert ks.datasets.create("d").get("id") == "ds-1"
    assert len(ks.datasets.list()) == 1
    assert ks.datasets.get("ds-1").get("id") == "ds-1"
    assert ks.datasets.add_records("ds-1", [{"input": {"q": 1}}])["added"] == 1
    assert ks.datasets.get_records("ds-1")[0]["input"]["q"] == 1
    ks.datasets.delete("ds-1")


def test_alert_service(mock_server, ks):
    mock_server.route("POST", "/v1/alerts")(lambda r: Response(201, {
        "id": "a1", "name": r.json()["name"], "notify": r.json()["notify"], "condition": r.json()["condition"],
    }))
    mock_server.route("GET", "/v1/alerts")(lambda r: Response(200, [{"id": "a1", "name": "x", "notify": "webhook", "condition": "p<1"}]))
    mock_server.route("DELETE", "/v1/alerts/a1")(lambda r: Response(204))

    alert = ks.alerts.create("x", "pass_rate<0.8", notify="webhook", webhook_url="https://hook")
    assert alert.id == "a1"
    assert len(ks.alerts.list()) == 1
    ks.alerts.delete("a1")


# ────────────────────────────────────────────────────────────────────────
# Prompts
# ────────────────────────────────────────────────────────────────────────


def test_prompt_service_full(mock_server, ks):
    store: Dict[str, Dict] = {}
    versions: Dict[str, int] = {}

    @mock_server.route("POST", "/v1/prompts")
    def _create(r):
        body = r.json()
        versions[body["slug"]] = versions.get(body["slug"], 0) + 1
        pid = f"prompt-{versions[body['slug']]}"
        p = {"id": pid, "slug": body["slug"], "version": versions[body["slug"]],
             "template": body["template"], "variables": body.get("variables") or {},
             "tag": body.get("tag") or ""}
        store[pid] = p
        return Response(201, p)

    @mock_server.route("GET", "/v1/prompts")
    def _list(r):
        return Response(200, list(store.values()))

    @mock_server.route("GET", "/v1/prompts/greet/latest")
    def _latest(r):
        latest = max((p for p in store.values() if p["slug"] == "greet"), key=lambda p: p["version"])
        return Response(200, latest)

    @mock_server.route("DELETE", "/v1/prompts/*")
    def _del(r):
        pid = r.path.rsplit("/", 1)[-1]
        store.pop(pid, None)
        return Response(204)

    @mock_server.route("POST", "/v1/prompts/*/render")
    def _render(r):
        pid = r.path.split("/")[-2]
        p = store[pid]
        return Response(200, {"rendered": render_template(p["template"], {**p["variables"], **(r.json().get("variables") or {})})})

    p1 = ks.prompts.create(slug="greet", template="Hello {name}", variables={"name": "world"})
    assert p1.version == 1
    p2 = ks.prompts.create(slug="greet", template="Hi {name}")
    assert p2.version == 2

    latest = ks.prompts.get("greet")
    assert latest.version == 2

    # Local render with default + override
    assert p1.render() == "Hello world"
    assert p1.render(name="alex") == "Hello alex"

    # Remote render
    rendered = ks.prompts.render(p1.id, name="alex")
    assert rendered == "Hello alex"

    ks.prompts.delete(p1.id)


def test_prompt_render_edge_cases():
    # Interleaved sections with different names shouldn't corrupt each other.
    out = render_template("{#a}A:{_it}{/a}|{#b}B:{_it}{/b}", {"a": [1, 2], "b": [3]})
    assert out == "A:1A:2|B:3"

    # Missing variables remain as placeholders.
    assert render_template("Hi {who}", {}) == "Hi {who}"

    # Dot path lookups.
    assert render_template("{user.name}", {"user": {"name": "alex"}}) == "alex"

    # Falsy section is dropped.
    assert render_template("A{#x}B{/x}C", {"x": False}) == "AC"

    # List of objects — per-item scope overlays.
    out = render_template("{#items}[{name}={value}]{/items}", {"items": [
        {"name": "x", "value": 1}, {"name": "y", "value": 2},
    ]})
    assert out == "[x=1][y=2]"


# ────────────────────────────────────────────────────────────────────────
# Export
# ────────────────────────────────────────────────────────────────────────


def test_export_pagination(mock_server, ks):
    pages = {
        "": {"items": [{"id": 1, "tool": "a"}, {"id": 2, "tool": "b"}], "next_cursor": "p2", "count": 2},
        "p2": {"items": [{"id": 3, "tool": "c"}], "next_cursor": "", "count": 1},
    }

    @mock_server.route("GET", "/v1/traces")
    def _(r):
        cursor = ""
        for pair in r.query.split("&"):
            if pair.startswith("cursor="):
                cursor = pair.split("=", 1)[1]
        return Response(200, pages[cursor])

    rows = list(ks.export.traces(limit=2))
    assert len(rows) == 3
    assert [r["tool"] for r in rows] == ["a", "b", "c"]


def test_export_experiment_and_trace(mock_server, ks):
    mock_server.route("GET", "/v1/experiments/exp-1/export")(lambda r: Response(200, {
        "experiment": [{"id": "exp-1"}], "scenarios": [{"scenario_id": "s1"}],
    }))
    mock_server.route("GET", "/v1/traces/t1")(lambda r: Response(200, {"spans": [{"span_id": "s1"}]}))

    exp = ks.export.experiment("exp-1")
    assert "scenarios" in exp

    trace = ks.export.trace("t1")
    assert "spans" in trace


# ────────────────────────────────────────────────────────────────────────
# Scorers — heuristic
# ────────────────────────────────────────────────────────────────────────


def _scenario(output: str, **params: Any) -> SimpleNamespace:
    return SimpleNamespace(agent_output=output, parameters=params, invariants=[])


def test_exact_match_strip_and_case():
    s = ExactMatch(expected="  HELLO  ", case_sensitive=False, strip=True).score_result(_scenario("hello"))
    assert s.passed and s.score == 1.0

    s = ExactMatch(expected="hello", case_sensitive=True).score_result(_scenario("Hello"))
    assert not s.passed


def test_levenshtein_similarity_bounds():
    s = Levenshtein(expected="hello world", threshold=0.8).score_result(_scenario("hello wrld"))
    assert s.passed and s.score >= 0.8

    s = Levenshtein(expected="hi", threshold=0.9).score_result(_scenario("completely different"))
    assert not s.passed

    # Both empty → treated as matching via SequenceMatcher ratio=1.0 in Python.
    s = Levenshtein(expected="").score_result(_scenario(""))
    assert s.score == 1.0


def test_numeric_diff_handles_non_numeric():
    s = NumericDiff(expected=42).score_result(_scenario("no numbers here"))
    assert not s.passed and "no numeric value" in s.message


def test_json_diff_partial_match():
    s = JSONDiff(expected={"a": 1, "b": 2}, threshold=0.4).score_result(_scenario('{"a": 1, "b": 99}'))
    assert s.passed and 0.4 <= s.score <= 0.6


def test_json_validity():
    assert JSONValidity().score_result(_scenario("{\"x\":1}")).passed
    assert not JSONValidity().score_result(_scenario("nope")).passed


def test_semantic_list_contains_fuzzy():
    s = SemanticListContains(expected=["alphaa"], fuzzy=True, fuzzy_threshold=0.6, threshold=0.5).score_result(
        _scenario("the word is alpha and beta")
    )
    assert s is not None  # fuzzy match should register even though 'alphaa' is misspelled


# ────────────────────────────────────────────────────────────────────────
# Scorers — judges (with mock LLMClient)
# ────────────────────────────────────────────────────────────────────────


class MockLLM:
    def __init__(self, reply: str):
        self.reply = reply
        self.calls: List[Dict] = []

    def complete(self, messages, *, model, temperature=0.0, max_tokens=1024):
        self.calls.append({"messages": messages, "model": model, "temperature": temperature})
        return self.reply


def test_factuality_with_mock_client():
    llm = MockLLM('{"score": 0.9, "passed": true, "reason": "paraphrase"}')
    f = Factuality(client=llm)
    s = f.score_result(SimpleNamespace(
        agent_output="Paris",
        parameters={"question": "capital of France?", "expected": "Paris"},
    ))
    assert s.score == 0.9 and s.passed
    assert llm.calls[0]["model"] == "paragon-fast"


def test_all_judge_scorers_invariants():
    """Every judge scorer must produce a well-formed invariant JSON."""
    llm = MockLLM('{"score": 0.5, "passed": false, "reason": "x"}')
    judges = [
        Factuality(client=llm),
        Battle(client=llm),
        ClosedQA(client=llm),
        Humor(client=llm),
        Moderation(client=llm),
        Summarization(client=llm),
        SQLJudge(client=llm),
        Translation(client=llm),
        Security(client=llm),
        ContextPrecision(client=llm),
        ContextRecall(client=llm),
        ContextRelevancy(client=llm),
        ContextEntityRecall(client=llm),
        Faithfulness(client=llm),
        AnswerRelevancy(client=llm),
        AnswerSimilarity(client=llm),
        AnswerCorrectness(client=llm),
    ]
    for j in judges:
        inv = j.to_invariant()
        assert inv is not None, f"{type(j).__name__} missing invariant"
        assert inv["check"]["type"] == "llm_as_judge"
        assert inv["check"]["template_key"] == j.template_key
        rule = j.to_rule()
        assert rule["type"] == "llm_as_judge"


def test_judge_handles_parser_failure_gracefully():
    llm = MockLLM("this is not JSON at all")
    f = Factuality(client=llm)
    s = f.score_result(SimpleNamespace(
        agent_output="x", parameters={"question": "q", "expected": "e"},
    ))
    # Heuristic fallback: no number → 0.0 and fail.
    assert s is not None
    assert 0 <= s.score <= 1


def test_judge_missing_scenario_param_reports_skip():
    f = Factuality(client=MockLLM(""))
    s = f.score_result(SimpleNamespace(agent_output="x", parameters={}))
    # Missing required 'question' param → Score reports the skip reason.
    assert s is not None and "question" in s.message


def test_judge_rubric_threaded_into_invariant():
    j = Factuality(rubric={"clarity": "easy to read"}, prompt_template="X")
    inv = j.to_invariant()
    assert inv["check"]["rubric"] == {"clarity": "easy to read"}
    assert inv["check"]["prompt_template"] == "X"


# ────────────────────────────────────────────────────────────────────────
# Sandbox-invariant scorers (to_invariant only; no score_result)
# ────────────────────────────────────────────────────────────────────────


def test_sandbox_invariants_shape():
    fe = FileExists("out.txt", gate=True)
    assert fe.to_invariant() == {
        "description": "out.txt exists",
        "weight": 1.0,
        "gate": True,
        "check": {"type": "file_exists", "path": "out.txt"},
    }

    fc = FileContains("out.txt", contains="ok")
    assert fc.to_invariant()["check"]["contains"] == "ok"

    ce = CommandExits("echo hi", exit_code=0)
    assert ce.to_invariant()["check"]["command"] == "echo hi"

    sq = SQLEquals(service="db", query="SELECT 1", equals=1)
    assert sq.to_invariant()["check"]["service"] == "db"

    lj = LLMJudge("Is this good?", rubric={"a": "b"})
    assert lj.to_invariant()["check"]["criteria"] == "Is this good?"


def test_embedding_similarity_end_to_end():
    def embed(text: str):
        return [float(len(text)), 1.0, 0.0]
    s = EmbeddingSimilarity(embedder=embed, expected="hello").score_result(_scenario("hello"))
    assert s.passed and s.score > 0.9


def test_scorers_to_invariants_and_run_client_scorers():
    fe = FileExists("a.txt")
    em = ExactMatch(expected="x")
    @Scorer
    def always_true(scenario): return True

    inv_map = scorers_to_invariants([fe, em, always_true])
    # FileExists produces an invariant, ExactMatch and the decorator do not.
    assert "file_exists_a.txt" in inv_map
    assert len(inv_map) == 1

    scores = run_client_scorers([em, always_true], _scenario("x"))
    assert len(scores) == 2


# ────────────────────────────────────────────────────────────────────────
# Tracing + OTel hooks
# ────────────────────────────────────────────────────────────────────────


def test_traced_decorator_captures_sync_and_async_spans(mock_server, ks):
    received = []
    @mock_server.route("POST", "/v1/sandboxes/sb-1/trace")
    def _(r):
        received.extend(r.json()["events"])
        return Response(200, {"ingested": len(r.json()["events"])})

    ks.init_tracing("sb-1")

    @traced
    def outer(x):
        @traced
        def inner(x):
            return x * 2
        return inner(x)

    assert outer(21) == 42

    # Background threads need a beat to flush.
    import time
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline and len(received) < 4:
        time.sleep(0.02)
    # 2 spans × (start + end) = 4 events
    assert len(received) >= 4
    phases = [e["phase"] for e in received]
    assert phases.count("start") >= 2 and phases.count("end") >= 2


def test_otel_flush_hooks_run_in_registration_order():
    order = []
    register_otel_flush(lambda: order.append("a"))
    register_otel_flush(lambda: order.append("b"))
    flush_otel()
    assert "a" in order and "b" in order


# ────────────────────────────────────────────────────────────────────────
# Wrap — Anthropic + OpenAI shapes
# ────────────────────────────────────────────────────────────────────────


class FakeAnthropicMessages:
    def __init__(self, response): self._resp = response
    def create(self, **kwargs):
        return self._resp


class FakeAnthropicClient:
    def __init__(self, response): self.messages = FakeAnthropicMessages(response)


class FakeOpenAICompletions:
    def __init__(self, response): self._resp = response
    def create(self, **kwargs):
        return self._resp


class FakeOpenAIChat:
    def __init__(self, response): self.completions = FakeOpenAICompletions(response)


class FakeOpenAIClient:
    def __init__(self, response): self.chat = FakeOpenAIChat(response)


def test_wrap_anthropic_emits_traces(mock_server, ks):
    received = []
    @mock_server.route("POST", "/v1/sandboxes/sb-1/trace")
    def _(r):
        received.extend(r.json()["events"])
        return Response(200, {"ingested": len(r.json()["events"])})

    resp = SimpleNamespace(
        model="claude-sonnet-4-6",
        usage=SimpleNamespace(input_tokens=10, output_tokens=5, cache_read_input_tokens=0),
        content=[
            SimpleNamespace(type="text", text="hi"),
            SimpleNamespace(type="tool_use", id="t1", name="get_weather", input={"city": "NYC"}),
        ],
    )
    client = FakeAnthropicClient(resp)
    wrapped = ks.wrap(client, sandbox_id="sb-1")
    out = wrapped.messages.create(messages=[{"role": "user", "content": "weather?"}])
    assert out is resp  # unchanged passthrough

    import time
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline and len(received) < 2:
        time.sleep(0.02)
    event_types = [e["event_type"] for e in received]
    assert "llm_call" in event_types
    assert "tool_use" in event_types
    llm = next(e for e in received if e["event_type"] == "llm_call")
    assert llm["cost"]["input_tokens"] == 10
    assert llm["cost"]["output_tokens"] == 5
    assert llm["metadata"]["gen_ai.system"] == "anthropic"
    assert llm["metadata"]["gen_ai.request.model"] == "claude-sonnet-4-6"


def test_wrap_openai_emits_traces(mock_server, ks):
    received = []
    @mock_server.route("POST", "/v1/sandboxes/sb-1/trace")
    def _(r):
        received.extend(r.json()["events"])
        return Response(200, {"ingested": len(r.json()["events"])})

    fn = SimpleNamespace(name="search", arguments='{"q":"k"}')
    tc = SimpleNamespace(id="tc1", function=fn)
    msg = SimpleNamespace(content="ok", tool_calls=[tc])
    choice = SimpleNamespace(message=msg)
    resp = SimpleNamespace(
        model="gpt-4o",
        usage=SimpleNamespace(
            prompt_tokens=7, completion_tokens=3,
            prompt_tokens_details=SimpleNamespace(cached_tokens=2),
            completion_tokens_details=SimpleNamespace(reasoning_tokens=1),
        ),
        choices=[choice],
    )
    client = FakeOpenAIClient(resp)
    wrapped = ks.wrap(client, sandbox_id="sb-1")
    wrapped.chat.completions.create(messages=[{"role": "user", "content": "hi"}])

    import time
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline and len(received) < 2:
        time.sleep(0.02)
    llm = next(e for e in received if e["event_type"] == "llm_call")
    assert llm["cost"]["cache_read_tokens"] == 2
    assert llm["cost"]["reasoning_tokens"] == 1
    assert llm["metadata"]["gen_ai.system"] == "openai"


def test_wrap_unknown_client_raises():
    ks = Keystone(api_key="x", base_url="http://ignore")
    with pytest.raises(TypeError):
        ks.wrap(SimpleNamespace(), sandbox_id="sb-1")


# ────────────────────────────────────────────────────────────────────────
# Auth + error-path
# ────────────────────────────────────────────────────────────────────────


def test_auth_header_sent(mock_server, ks):
    mock_server.route("GET", "/v1/sandboxes")(lambda r: Response(200, []))
    ks.sandboxes.list()
    last = mock_server.captured[-1]
    assert last.headers.get("Authorization") == "Bearer ks_test"


def test_api_error_body_parsed(mock_server, ks):
    mock_server.route("GET", "/v1/sandboxes/bad")(lambda r: Response(403, {"error": "forbidden"}))
    with pytest.raises(KeystoneError) as e:
        ks.sandboxes.get("bad")
    assert e.value.status_code == 403
    assert "forbidden" in str(e.value)


def test_connection_failure_raises(ks):
    # Point at a port nothing is listening on.
    from polarity_keystone._http import HTTPClient
    from polarity_keystone.types import KeystoneError
    h = HTTPClient("http://127.0.0.1:1", api_key="x", timeout=1)
    with pytest.raises(KeystoneError):
        h.get("/")


# ────────────────────────────────────────────────────────────────────────
# Pricing parity
# ────────────────────────────────────────────────────────────────────────


def test_pricing_cost_matches_expected():
    # Match the Go/TS cross-SDK test: 1000 in, 500 out, 100 cache for sonnet-4-6.
    from polarity_keystone.wrap import _estimate_cost
    cost = _estimate_cost("claude-sonnet-4-6", 1000, 500, 100)
    assert abs(cost - 0.01023) < 1e-9
