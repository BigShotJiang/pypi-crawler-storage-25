"""Versioned prompt management.

Mirrors Braintrust's ``load_prompt`` surface: prompts are addressed by a
``slug`` that is stable across versions; every call to :meth:`create`
auto-increments the version. Tags are optional aliases. Templates use the
same mustache-lite syntax the server renders server-side, so rendering is
bit-identical locally vs via ``/v1/prompts/{id}/render``.

::

    ks.prompts.create(slug="greet", template="Hello {name}")
    p = ks.prompts.get("greet")  # latest version
    print(p.render(name="alex"))  # "Hello alex"
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ._http import HTTPClient


# ---------------------------------------------------------------------------
# Mustache-lite renderer (matches server prompts.go)
# ---------------------------------------------------------------------------

_SIMPLE_VAR_RE = re.compile(r"\{\{?\s*(\w+(?:\.\w+)*)\s*\}\}?")
_SECTION_RE = re.compile(r"\{#\s*(\w+)\s*\}(.*?)\{/\s*\1\s*\}", re.DOTALL)


def render_template(template: str, variables: Dict[str, Any]) -> str:
    def _expand_vars(body: str, vars_: Dict[str, Any]) -> str:
        def repl(match: re.Match) -> str:
            path = match.group(1).split(".")
            cur: Any = vars_
            for seg in path:
                if not isinstance(cur, dict) or seg not in cur:
                    return match.group(0)
                cur = cur[seg]
            return str(cur)

        return _SIMPLE_VAR_RE.sub(repl, body)

    def _is_falsy(v: Any) -> bool:
        if v is None:
            return True
        if isinstance(v, (bool, str, list, dict)):
            return not v
        if isinstance(v, (int, float)):
            return v == 0
        return False

    def _section_repl(match: re.Match) -> str:
        name, body = match.group(1), match.group(2)
        value = variables.get(name)
        if value is None:
            return ""
        if isinstance(value, list):
            out = []
            for item in value:
                local = dict(variables)
                local["_it"] = item
                if isinstance(item, dict):
                    local.update(item)
                out.append(_expand_vars(body, local))
            return "".join(out)
        if _is_falsy(value):
            return ""
        return _expand_vars(body, variables)

    expanded = _SECTION_RE.sub(_section_repl, template)
    return _expand_vars(expanded, variables)


# ---------------------------------------------------------------------------
# Prompt dataclass
# ---------------------------------------------------------------------------


@dataclass
class Prompt:
    """A single prompt record. Use :meth:`render` to expand variables."""

    id: str = ""
    user_id: str = ""
    slug: str = ""
    version: int = 0
    tag: str = ""
    template: str = ""
    variables: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = ""

    def render(self, **overrides: Any) -> str:
        """Render the template. Caller-supplied kwargs override stored defaults."""

        merged = dict(self.variables or {})
        merged.update(overrides)
        return render_template(self.template, merged)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Prompt":
        if data is None:
            return cls()
        return cls(
            id=data.get("id", ""),
            user_id=data.get("user_id", ""),
            slug=data.get("slug", ""),
            version=int(data.get("version", 0) or 0),
            tag=data.get("tag", "") or "",
            template=data.get("template", ""),
            variables=data.get("variables") or {},
            metadata=data.get("metadata") or {},
            created_at=data.get("created_at", "") or "",
        )


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class PromptService:
    """CRUD + versioning + templating for prompts."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        slug: str,
        template: str,
        *,
        tag: Optional[str] = None,
        variables: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Prompt:
        """Create (or version-up) a prompt at the given slug."""

        body: Dict[str, Any] = {"slug": slug, "template": template}
        if tag:
            body["tag"] = tag
        if variables:
            body["variables"] = variables
        if metadata:
            body["metadata"] = metadata
        data = self._http.post("/v1/prompts", body)
        return Prompt.from_dict(data)

    def get(
        self,
        slug: str,
        *,
        version: Optional[int] = None,
        tag: Optional[str] = None,
    ) -> Prompt:
        """Fetch a prompt. Without version/tag, returns the latest version."""

        if version is not None:
            path = f"/v1/prompts/{slug}/versions/{version}"
        elif tag:
            path = f"/v1/prompts/{slug}/tags/{tag}"
        else:
            path = f"/v1/prompts/{slug}/latest"
        return Prompt.from_dict(self._http.get(path))

    def list(self) -> List[Prompt]:
        """List every prompt owned by the caller."""

        data = self._http.get("/v1/prompts") or []
        return [Prompt.from_dict(item) for item in data]

    def delete(self, prompt_id: str) -> None:
        """Delete a prompt by ID."""

        self._http.delete(f"/v1/prompts/{prompt_id}")

    def render(self, prompt_id: str, **variables: Any) -> str:
        """Render a prompt server-side. Useful when you want the canonical output."""

        data = self._http.post(f"/v1/prompts/{prompt_id}/render", {"variables": variables})
        if isinstance(data, dict):
            return str(data.get("rendered", ""))
        return ""


def load_prompt(http: HTTPClient, slug: str, *, version: Optional[int] = None, tag: Optional[str] = None) -> Prompt:
    """Module-level convenience mirroring Braintrust's ``load_prompt`` API.

    Typically accessed via ``ks.prompts.get(...)``; this form is available for
    users who want to avoid keeping a ``Keystone`` handle in scope.
    """

    return PromptService(http).get(slug, version=version, tag=tag)
