"""Agent snapshot operations for the Keystone SDK."""

from __future__ import annotations

import io
import json
import os
import tarfile
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from ._http import HTTPClient
from .types import AgentSnapshot


class AgentService:
    """Upload, resolve, list, and delete agent snapshots."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def upload(
        self,
        name: str,
        path: str,
        entrypoint: "list[str]",
        *,
        runtime: Optional[str] = None,
        auth: Optional[Dict[str, Any]] = None,
        tag: Optional[str] = None,
    ) -> AgentSnapshot:
        """Upload an agent snapshot.

        ``path`` can be a directory, a single file, or a ``.tar.gz`` archive.
        The SDK auto-detects the format and tars directories/files automatically.

        Version is auto-assigned by the server.

        Args:
            name: Agent name (e.g. ``"codex"``).
            path: Local path to a directory, file, or tarball.
            entrypoint: Exec-form command (e.g. ``["python3", "agent.py"]``).
            runtime: Optional runtime hint (``"node20"``, ``"python3"``, etc.).
            auth: Optional auth requirements dict.
            tag: Optional human-readable label.

        Returns:
            The created AgentSnapshot with server-assigned version and id.
        """
        bundle_data = _prepare_bundle(path)

        metadata: Dict[str, Any] = {
            "name": name,
            "entrypoint": entrypoint,
        }
        if runtime:
            metadata["runtime"] = runtime
        if auth:
            metadata["auth"] = auth
        if tag:
            metadata["tag"] = tag

        data = self._http.post_multipart(
            "/v1/agents",
            fields={"metadata": json.dumps(metadata)},
            files={"bundle": (name + ".tar.gz", bundle_data, "application/gzip")},
        )
        return AgentSnapshot.from_dict(data)

    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        tag: Optional[str] = None,
    ) -> AgentSnapshot:
        """Resolve a snapshot by name. Without version or tag, returns latest.

        Args:
            name: Agent name.
            version: Specific version number.
            tag: Specific tag label.
        """
        if tag:
            data = self._http.get(f"/v1/agents/{name}/tags/{tag}")
        elif version is not None:
            data = self._http.get(f"/v1/agents/{name}/versions/{version}")
        else:
            data = self._http.get(f"/v1/agents/{name}/latest")
        return AgentSnapshot.from_dict(data)

    def get_by_id(self, snapshot_id: str) -> AgentSnapshot:
        """Get a snapshot by its immutable content-addressed ID."""
        data = self._http.get(f"/v1/snapshots/{snapshot_id}")
        return AgentSnapshot.from_dict(data)

    def list(
        self, limit: int = 100, cursor: Optional[str] = None
    ) -> Tuple[List[AgentSnapshot], Optional[str]]:
        """List all agent snapshots with cursor pagination.

        Returns:
            Tuple of (snapshots, next_cursor). next_cursor is None when
            there are no more pages.
        """
        path = f"/v1/agents?limit={limit}"
        if cursor:
            path += f"&cursor={cursor}"
        data = self._http.get(path)
        items = [AgentSnapshot.from_dict(d) for d in (data.get("items") or [])]
        return items, data.get("next_cursor")

    def list_versions(
        self, name: str, limit: int = 100, cursor: Optional[str] = None
    ) -> Tuple[List[AgentSnapshot], Optional[str]]:
        """List all versions of a named agent with cursor pagination."""
        path = f"/v1/agents/{name}/versions?limit={limit}"
        if cursor:
            path += f"&cursor={cursor}"
        data = self._http.get(path)
        items = [AgentSnapshot.from_dict(d) for d in (data.get("items") or [])]
        return items, data.get("next_cursor")

    def delete(self, snapshot: AgentSnapshot) -> None:
        """Delete a snapshot. Pass the AgentSnapshot object, not raw strings."""
        self._http.delete(f"/v1/snapshots/{snapshot.id}")


def _prepare_bundle(path: str) -> bytes:
    """Auto-detect path type and return tarball bytes."""
    if path.endswith(".tar.gz") or path.endswith(".tgz"):
        with open(path, "rb") as f:
            return f.read()

    if os.path.isdir(path):
        return _tar_directory(path)

    # Single file — wrap in a tarball.
    return _tar_single_file(path)


def _tar_directory(dir_path: str) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for root, dirs, files in os.walk(dir_path):
            for fname in files:
                full = os.path.join(root, fname)
                arcname = os.path.relpath(full, dir_path)
                tar.add(full, arcname=arcname)
    return buf.getvalue()


def _tar_single_file(file_path: str) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        tar.add(file_path, arcname=os.path.basename(file_path))
    return buf.getvalue()
