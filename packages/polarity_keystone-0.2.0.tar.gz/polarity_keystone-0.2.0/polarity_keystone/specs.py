"""Spec operations for the Keystone SDK."""

from __future__ import annotations

from typing import List

from ._http import HTTPClient
from .types import SandboxSpec


class SpecService:
    """CRUD operations for Keystone sandbox specifications."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(self, yaml_content: "str | bytes") -> SandboxSpec:
        """Create a spec by sending raw YAML content.

        The server parses the YAML and assigns an ID.

        Args:
            yaml_content: YAML string or bytes defining the sandbox spec.
        """
        if isinstance(yaml_content, str):
            yaml_content = yaml_content.encode("utf-8")
        data = self._http.post_raw("/v1/specs", yaml_content, content_type="application/x-yaml")
        return SandboxSpec.from_dict(data)

    def create_from_file(self, path: str) -> SandboxSpec:
        """Create a spec by reading a YAML file from disk and uploading it.

        Args:
            path: Local filesystem path to a YAML spec file.
        """
        with open(path, "rb") as f:
            content = f.read()
        return self.create(content)

    def get(self, spec_id: str) -> SandboxSpec:
        """Get a spec by ID."""
        data = self._http.get(f"/v1/specs/{spec_id}")
        return SandboxSpec.from_dict(data)

    def list(self) -> List[SandboxSpec]:
        """List all specs."""
        data = self._http.get("/v1/specs")
        if data is None:
            return []
        return [SandboxSpec.from_dict(item) for item in data]

    def delete(self, spec_id: str) -> None:
        """Delete a spec by ID."""
        self._http.delete(f"/v1/specs/{spec_id}")
