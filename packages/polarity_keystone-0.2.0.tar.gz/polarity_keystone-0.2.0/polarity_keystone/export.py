"""Bulk export / extraction API.

A thin layer over ``/v1/traces``, ``/v1/spans``, ``/v1/scenarios``,
``/v1/scores``, and ``/v1/experiments/{id}/export`` that yields every row
matching the supplied filters, transparently paginating via keyset cursors.

::

    from polarity_keystone import Keystone
    ks = Keystone()

    for trace in ks.export.traces(experiment_id="exp-123"):
        print(trace["id"], trace["tool"], trace["cost"])

    bundle = ks.export.experiment("exp-123")  # full JSON dump
"""

from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional, Union

from ._http import HTTPClient


class ExportService:
    """Paginated extraction of runs, traces, spans, scenarios, and scores."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    # ---------------- experiment export --------------------------------

    def experiment(self, experiment_id: str, *, format: str = "json") -> Union[Dict[str, Any], str]:
        """Export a full experiment dump.

        ``format="json"`` returns a dict with ``experiment``, ``result``,
        ``scenarios``, ``traces``, ``scores``. ``format="ndjson"`` returns
        newline-delimited JSON as a single string.
        """

        path = f"/v1/experiments/{experiment_id}/export"
        if format and format != "json":
            path += f"?format={format}"
        if format == "ndjson":
            # Bytes preserve formatting exactly; str() decoding is UTF-8.
            return self._http.get_bytes(path).decode("utf-8")
        return self._http.get(path) or {}

    # ---------------- paginated iterators ------------------------------

    def traces(self, *, limit: int = 100, **filters: Any) -> Iterator[Dict[str, Any]]:
        """Iterate every trace event matching the filters.

        Supported filters: ``experiment_id``, ``sandbox_id``, ``agent``,
        ``event_type``, ``tool``, ``since`` (ISO-8601 timestamp).
        """

        yield from self._paginate("/v1/traces", limit, filters)

    def spans(self, *, limit: int = 100, **filters: Any) -> Iterator[Dict[str, Any]]:
        """Iterate spans matching the filters.

        Supported filters: ``trace_id`` (root_span_id), ``span_id``,
        ``parent_span_id``, ``root_span_id``, ``tool``, ``event_type``.
        """

        yield from self._paginate("/v1/spans", limit, filters)

    def scenarios(self, *, limit: int = 100, **filters: Any) -> Iterator[Dict[str, Any]]:
        """Iterate scenario records matching the filters.

        Supported filters: ``experiment_id``, ``status``, ``scenario_id``.
        """

        yield from self._paginate("/v1/scenarios", limit, filters)

    def scores(self, *, limit: int = 100, **filters: Any) -> Iterator[Dict[str, Any]]:
        """Iterate persisted score results.

        Supported filters: ``experiment_id``, ``rule_id``.
        """

        yield from self._paginate("/v1/scores", limit, filters)

    def trace(self, trace_id: str) -> Dict[str, Any]:
        """Return every span belonging to the trace rooted at ``trace_id``."""

        return self._http.get(f"/v1/traces/{trace_id}") or {}

    # ---------------- internal -----------------------------------------

    def _paginate(
        self,
        base_path: str,
        limit: int,
        filters: Dict[str, Any],
    ) -> Iterator[Dict[str, Any]]:
        cursor: Optional[str] = None
        while True:
            params = [f"limit={limit}"]
            if cursor:
                params.append(f"cursor={cursor}")
            for k, v in filters.items():
                if v is None:
                    continue
                params.append(f"{k}={v}")
            path = base_path + "?" + "&".join(params)
            page = self._http.get(path) or {}

            items: List[Dict[str, Any]] = page.get("items") or []
            for item in items:
                yield item

            cursor = page.get("next_cursor")
            if not cursor:
                break
