"""Keystone scorer library — 28 built-in scorers spanning heuristics, LLM-judge,
RAG, embeddings, and sandbox invariants.

::

    from polarity_keystone import Keystone
    from polarity_keystone.scorers import (
        # heuristic
        ExactMatch, Levenshtein, NumericDiff, JSONDiff, JSONValidity,
        SemanticListContains,
        # llm-judge
        Factuality, Battle, ClosedQA, Humor, Moderation, Summarization,
        SQLJudge, Translation, Security,
        # rag
        ContextPrecision, ContextRecall, ContextRelevancy, ContextEntityRecall,
        Faithfulness, AnswerRelevancy, AnswerSimilarity, AnswerCorrectness,
        # embedding
        EmbeddingSimilarity, openai_embedder,
        # sandbox
        FileExists, FileContains, CommandExits, SQLEquals, LLMJudge,
        # base + decorator
        Scorer, BaseScorer, Score, CustomScorer,
        scorers_to_invariants, run_client_scorers,
        set_default_llm_client, default_llm_client,
    )
"""

from __future__ import annotations

from .base import (
    BaseScorer,
    CustomScorer,
    LLMClient,
    ParagonProxyClient,
    Score,
    Scorer,
    default_llm_client,
    run_client_scorers,
    scorers_to_invariants,
    set_default_llm_client,
)
from .heuristics import (
    ExactMatch,
    JSONDiff,
    JSONValidity,
    Levenshtein,
    NumericDiff,
    SemanticListContains,
)
from .llm_judge import (
    Battle,
    ClosedQA,
    Factuality,
    Humor,
    Moderation,
    Security,
    SQLJudge,
    Summarization,
    Translation,
    default_parser,
)
from .rag import (
    AnswerCorrectness,
    AnswerRelevancy,
    AnswerSimilarity,
    ContextEntityRecall,
    ContextPrecision,
    ContextRecall,
    ContextRelevancy,
    Faithfulness,
)
from .embedding import EmbeddingSimilarity, openai_embedder
from .sandbox import CommandExits, FileContains, FileExists, LLMJudge, SQLEquals

__all__ = [
    # Base
    "BaseScorer",
    "CustomScorer",
    "LLMClient",
    "ParagonProxyClient",
    "Score",
    "Scorer",
    "default_llm_client",
    "run_client_scorers",
    "scorers_to_invariants",
    "set_default_llm_client",
    "default_parser",
    # Heuristic (6)
    "ExactMatch",
    "Levenshtein",
    "NumericDiff",
    "JSONDiff",
    "JSONValidity",
    "SemanticListContains",
    # LLM-judge (9, incl. Security)
    "Factuality",
    "Battle",
    "ClosedQA",
    "Humor",
    "Moderation",
    "Summarization",
    "SQLJudge",
    "Translation",
    "Security",
    # RAG (8)
    "ContextPrecision",
    "ContextRecall",
    "ContextRelevancy",
    "ContextEntityRecall",
    "Faithfulness",
    "AnswerRelevancy",
    "AnswerSimilarity",
    "AnswerCorrectness",
    # Embedding (1)
    "EmbeddingSimilarity",
    "openai_embedder",
    # Sandbox invariants (5, original)
    "FileExists",
    "FileContains",
    "CommandExits",
    "SQLEquals",
    "LLMJudge",
]
