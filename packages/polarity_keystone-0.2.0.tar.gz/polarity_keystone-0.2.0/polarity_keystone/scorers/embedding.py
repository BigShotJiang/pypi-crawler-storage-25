"""Embedding-based similarity scoring.

Uses the user-provided ``embedder`` (any callable ``(str) -> list[float]``),
or falls back to a best-effort OpenAI embeddings adapter when the SDK detects
an OpenAI client. Cosine similarity is computed locally.
"""

from __future__ import annotations

import math
from typing import Any, Callable, Dict, List, Optional

from .base import BaseScorer, Score


def _cosine(a: List[float], b: List[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class EmbeddingSimilarity(BaseScorer):
    """Cosine similarity between embedded ``actual`` and ``expected``.

    Parameters
    ----------
    embedder : callable
        A function ``(text: str) -> list[float]``. Required.
    model : str
        Logged in the score ``message`` only — the ``embedder`` is responsible
        for model selection.
    expected, expected_key : str
        Either an inline expected string, or a parameter key to pull from
        ``scenario.parameters``. One must be provided.
    threshold : float
        Passing threshold for ``score.passed``.
    """

    rule_type = "embedding_similarity"

    def __init__(
        self,
        *,
        embedder: Callable[[str], List[float]],
        expected: Optional[str] = None,
        expected_key: Optional[str] = None,
        threshold: float = 0.85,
        model: str = "custom",
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        if expected is None and not expected_key:
            raise ValueError("EmbeddingSimilarity requires expected or expected_key")
        self.name = "embedding_similarity"
        self._embedder = embedder
        self.expected = expected
        self.expected_key = expected_key
        self.threshold = threshold
        self.model = model
        self.weight = weight
        self.gate = gate

    def score_result(self, scenario: Any) -> Optional[Score]:
        exp: Optional[str] = self.expected
        if exp is None and self.expected_key:
            params = getattr(scenario, "parameters", {}) or {}
            exp = params.get(self.expected_key)
        if not exp:
            return None
        actual = str(getattr(scenario, "agent_output", "") or "")
        if not actual:
            return Score(name=self.name, score=0.0, passed=False, message="empty output")

        try:
            a_emb = self._embedder(actual)
            e_emb = self._embedder(exp)
        except Exception as e:
            return Score(name=self.name, score=0.0, passed=False, message=f"embedder failed: {e}")

        sim = _cosine(a_emb, e_emb)
        return Score(
            name=self.name,
            score=sim,
            passed=sim >= self.threshold,
            message=f"cosine={sim:.4f} threshold={self.threshold} model={self.model}",
        )

    def _rule_config(self) -> Dict[str, Any]:
        return {
            "expected": self.expected,
            "expected_key": self.expected_key,
            "threshold": self.threshold,
            "model": self.model,
        }


def openai_embedder(openai_client: Any, model: str = "text-embedding-3-small") -> Callable[[str], List[float]]:
    """Build an embedder callable from an OpenAI client.

    >>> embedder = openai_embedder(my_openai)
    >>> EmbeddingSimilarity(embedder=embedder, expected_key="reference")
    """

    def _embed(text: str) -> List[float]:
        r = openai_client.embeddings.create(model=model, input=text)
        return list(r.data[0].embedding)

    return _embed
