"""RAG-specific scorers.

Retrieval-Augmented-Generation evaluators that inspect the retrieved
context alongside the question and answer. All scorers support the same
client-side + server-side split as :mod:`polarity_keystone.scorers.llm_judge`.

Scenarios must expose:

- ``scenario.agent_output``     — the model's answer (used when relevant)
- ``scenario.parameters[key]``  — per-scenario question, reference answer,
  retrieved context, etc.

Parameter keys are configurable per scorer. Defaults:

- ``question``      — user question
- ``context``       — list[str] or str of retrieved chunks
- ``expected``      — reference answer / ground truth
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from .llm_judge import _JudgeScorer, _actual, _get_param, _require


def _format_context(raw: Optional[str]) -> str:
    if not raw:
        return "(no context)"
    return raw


class _RAGScorer(_JudgeScorer):
    """Shared constructor for RAG scorers with customisable keys."""

    def __init__(
        self,
        *,
        question_key: str = "question",
        context_key: str = "context",
        expected_key: str = "expected",
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self._question_key = question_key
        self._context_key = context_key
        self._expected_key = expected_key


# ---------------------------------------------------------------------------
# Context-side scorers
# ---------------------------------------------------------------------------


class ContextPrecision(_RAGScorer):
    name = "context_precision"
    template_key = "context_precision"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            expected=_require(scenario, self._expected_key),
            context=_format_context(_get_param(scenario, self._context_key)),
        )


class ContextRecall(_RAGScorer):
    name = "context_recall"
    template_key = "context_recall"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            expected=_require(scenario, self._expected_key),
            context=_format_context(_get_param(scenario, self._context_key)),
        )


class ContextRelevancy(_RAGScorer):
    name = "context_relevancy"
    template_key = "context_relevancy"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            question=_require(scenario, self._question_key),
            context=_format_context(_get_param(scenario, self._context_key)),
        )


class ContextEntityRecall(_RAGScorer):
    name = "context_entity_recall"
    template_key = "context_entity_recall"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            expected=_require(scenario, self._expected_key),
            context=_format_context(_get_param(scenario, self._context_key)),
        )


# ---------------------------------------------------------------------------
# Answer-side scorers
# ---------------------------------------------------------------------------


class Faithfulness(_RAGScorer):
    name = "faithfulness"
    template_key = "faithfulness"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            context=_format_context(_get_param(scenario, self._context_key)),
            actual=_actual(scenario),
        )


class AnswerRelevancy(_RAGScorer):
    name = "answer_relevancy"
    template_key = "answer_relevancy"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            question=_require(scenario, self._question_key),
            actual=_actual(scenario),
        )


class AnswerSimilarity(_RAGScorer):
    name = "answer_similarity"
    template_key = "answer_similarity"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            expected=_require(scenario, self._expected_key),
            actual=_actual(scenario),
        )


class AnswerCorrectness(_RAGScorer):
    name = "answer_correctness"
    template_key = "answer_correctness"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            question=_require(scenario, self._question_key),
            expected=_require(scenario, self._expected_key),
            actual=_actual(scenario),
        )
