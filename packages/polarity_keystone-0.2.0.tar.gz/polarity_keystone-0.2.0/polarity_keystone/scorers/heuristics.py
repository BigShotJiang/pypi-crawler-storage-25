"""Heuristic (non-LLM) scorers.

Pure-function scorers that compare the agent's output against an expected
value. No model calls, no network, fully deterministic. Equivalent to
Braintrust's `autoevals` heuristic suite.

All heuristic scorers read ``scenario.agent_output`` and compare against a
caller-supplied ``expected`` value. Scorers that also accept an ``expected_key``
pull the expected value from ``scenario.parameters[expected_key]`` — useful
when dataset rows carry per-scenario expected outputs.
"""

from __future__ import annotations

import json
import math
import re
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional

from .base import BaseScorer, Score


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_actual(scenario: Any) -> str:
    return str(getattr(scenario, "agent_output", "") or "")


def _get_expected(
    scenario: Any, expected: Optional[str], expected_key: Optional[str]
) -> Optional[str]:
    if expected is not None:
        return expected
    if expected_key:
        params = getattr(scenario, "parameters", {}) or {}
        val = params.get(expected_key)
        return None if val is None else str(val)
    return None


# ---------------------------------------------------------------------------
# ExactMatch
# ---------------------------------------------------------------------------


class ExactMatch(BaseScorer):
    """1.0 iff actual == expected (after optional normalization)."""

    rule_type = "exact_match"

    def __init__(
        self,
        *,
        expected: Optional[str] = None,
        expected_key: Optional[str] = None,
        case_sensitive: bool = True,
        strip: bool = True,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = "exact_match"
        self.expected = expected
        self.expected_key = expected_key
        self.case_sensitive = case_sensitive
        self.strip = strip
        self.weight = weight
        self.gate = gate

    def _normalize(self, s: str) -> str:
        if self.strip:
            s = s.strip()
        if not self.case_sensitive:
            s = s.lower()
        return s

    def score_result(self, scenario: Any) -> Optional[Score]:
        exp = _get_expected(scenario, self.expected, self.expected_key)
        if exp is None:
            return None
        actual = self._normalize(_get_actual(scenario))
        exp_norm = self._normalize(exp)
        passed = actual == exp_norm
        return Score(
            name=self.name,
            score=1.0 if passed else 0.0,
            passed=passed,
            message="" if passed else f"expected {exp_norm!r}, got {actual!r}",
        )

    def _rule_config(self) -> Dict[str, Any]:
        return {
            "expected": self.expected,
            "expected_key": self.expected_key,
            "case_sensitive": self.case_sensitive,
            "strip": self.strip,
        }


# ---------------------------------------------------------------------------
# Levenshtein-ish similarity (uses difflib SequenceMatcher ratio).
# Kept stdlib-only — difflib gives a normalized 0..1 ratio that correlates
# closely with normalized edit distance for our purposes.
# ---------------------------------------------------------------------------


class Levenshtein(BaseScorer):
    """String similarity score in [0, 1]. 1.0 = identical."""

    rule_type = "levenshtein"

    def __init__(
        self,
        *,
        expected: Optional[str] = None,
        expected_key: Optional[str] = None,
        threshold: float = 0.8,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = "levenshtein"
        self.expected = expected
        self.expected_key = expected_key
        self.threshold = threshold
        self.weight = weight
        self.gate = gate

    def score_result(self, scenario: Any) -> Optional[Score]:
        exp = _get_expected(scenario, self.expected, self.expected_key)
        if exp is None:
            return None
        actual = _get_actual(scenario)
        ratio = SequenceMatcher(None, actual, exp).ratio()
        return Score(
            name=self.name,
            score=ratio,
            passed=ratio >= self.threshold,
            message=f"similarity={ratio:.3f} threshold={self.threshold}",
        )

    def _rule_config(self) -> Dict[str, Any]:
        return {"expected": self.expected, "expected_key": self.expected_key, "threshold": self.threshold}


# ---------------------------------------------------------------------------
# NumericDiff
# ---------------------------------------------------------------------------


class NumericDiff(BaseScorer):
    """Compare extracted numeric values. Score = 1 - |actual - expected| / max(|expected|, epsilon), clamped [0, 1]."""

    rule_type = "numeric_diff"
    _NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")

    def __init__(
        self,
        *,
        expected: Optional[float] = None,
        expected_key: Optional[str] = None,
        tolerance: float = 0.01,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = "numeric_diff"
        self.expected = expected
        self.expected_key = expected_key
        self.tolerance = tolerance
        self.weight = weight
        self.gate = gate

    def _extract(self, s: str) -> Optional[float]:
        m = self._NUM_RE.search(s)
        return float(m.group()) if m else None

    def score_result(self, scenario: Any) -> Optional[Score]:
        exp: Optional[float]
        if self.expected is not None:
            exp = float(self.expected)
        elif self.expected_key:
            params = getattr(scenario, "parameters", {}) or {}
            val = params.get(self.expected_key)
            exp = None if val is None else float(val)
        else:
            return None
        if exp is None:
            return None
        actual = self._extract(_get_actual(scenario))
        if actual is None:
            return Score(name=self.name, score=0.0, passed=False, message="no numeric value in output")
        rel = abs(actual - exp) / max(abs(exp), 1e-9)
        score = max(0.0, 1.0 - rel)
        passed = rel <= self.tolerance
        return Score(name=self.name, score=score, passed=passed, message=f"actual={actual} expected={exp} rel_err={rel:.4f}")

    def _rule_config(self) -> Dict[str, Any]:
        return {"expected": self.expected, "expected_key": self.expected_key, "tolerance": self.tolerance}


# ---------------------------------------------------------------------------
# JSONDiff — semantic diff between two JSON values, ignoring key order.
# Score: 1 - (mismatched_fields / total_fields).
# ---------------------------------------------------------------------------


class JSONDiff(BaseScorer):
    """JSON-structural similarity. Ignores key order; penalises structural mismatches."""

    rule_type = "json_diff"

    def __init__(
        self,
        *,
        expected: Optional[Any] = None,
        expected_key: Optional[str] = None,
        threshold: float = 1.0,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = "json_diff"
        self.expected = expected
        self.expected_key = expected_key
        self.threshold = threshold
        self.weight = weight
        self.gate = gate

    @staticmethod
    def _parse(s: str) -> Any:
        try:
            return json.loads(s)
        except (json.JSONDecodeError, TypeError):
            return None

    @classmethod
    def _similarity(cls, a: Any, b: Any) -> float:
        if type(a) is not type(b):
            return 0.0
        if isinstance(a, dict):
            keys = set(a) | set(b)
            if not keys:
                return 1.0
            return sum(cls._similarity(a.get(k), b.get(k)) for k in keys) / len(keys)
        if isinstance(a, list):
            if len(a) != len(b):
                # Soft-score: match prefix.
                pairs = zip(a, b)
                matched = sum(cls._similarity(x, y) for x, y in pairs)
                return matched / max(len(a), len(b), 1)
            if not a:
                return 1.0
            return sum(cls._similarity(x, y) for x, y in zip(a, b)) / len(a)
        if isinstance(a, float) and isinstance(b, float):
            return 1.0 if math.isclose(a, b) else 0.0
        return 1.0 if a == b else 0.0

    def score_result(self, scenario: Any) -> Optional[Score]:
        exp: Any
        if self.expected is not None:
            exp = self.expected
        elif self.expected_key:
            params = getattr(scenario, "parameters", {}) or {}
            exp = params.get(self.expected_key)
        else:
            return None
        if exp is None:
            return None

        actual = self._parse(_get_actual(scenario))
        if actual is None:
            return Score(name=self.name, score=0.0, passed=False, message="output is not valid JSON")
        sim = self._similarity(actual, exp)
        return Score(
            name=self.name,
            score=sim,
            passed=sim >= self.threshold,
            message=f"structural_similarity={sim:.3f}",
        )

    def _rule_config(self) -> Dict[str, Any]:
        return {"expected": self.expected, "expected_key": self.expected_key, "threshold": self.threshold}


# ---------------------------------------------------------------------------
# JSONValidity
# ---------------------------------------------------------------------------


class JSONValidity(BaseScorer):
    """1.0 iff the agent's output parses as JSON."""

    rule_type = "json_validity"

    def __init__(self, *, weight: float = 1.0, gate: bool = False) -> None:
        self.name = "json_validity"
        self.weight = weight
        self.gate = gate

    def score_result(self, scenario: Any) -> Optional[Score]:
        s = _get_actual(scenario).strip()
        try:
            json.loads(s)
            return Score(name=self.name, score=1.0, passed=True)
        except (json.JSONDecodeError, TypeError) as e:
            return Score(name=self.name, score=0.0, passed=False, message=f"invalid JSON: {e}")


# ---------------------------------------------------------------------------
# SemanticListContains — composite heuristic + optional LLM judge fallback.
# ---------------------------------------------------------------------------


class SemanticListContains(BaseScorer):
    """Check that every required item appears in the agent's list-style output.

    Accepts either ``expected`` (a list of required strings) or
    ``expected_key`` (pulled from ``scenario.parameters``). Match is
    case-insensitive substring by default. Set ``fuzzy=True`` to use
    Levenshtein-based fuzzy matching with ``fuzzy_threshold``.

    Score = fraction of required items that matched.
    """

    rule_type = "semantic_list_contains"

    def __init__(
        self,
        *,
        expected: Optional[List[str]] = None,
        expected_key: Optional[str] = None,
        fuzzy: bool = False,
        fuzzy_threshold: float = 0.75,
        threshold: float = 1.0,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = "semantic_list_contains"
        self.expected = expected
        self.expected_key = expected_key
        self.fuzzy = fuzzy
        self.fuzzy_threshold = fuzzy_threshold
        self.threshold = threshold
        self.weight = weight
        self.gate = gate

    def _match(self, needle: str, haystack: str) -> bool:
        if needle.lower() in haystack.lower():
            return True
        if not self.fuzzy:
            return False
        return SequenceMatcher(None, needle.lower(), haystack.lower()).ratio() >= self.fuzzy_threshold

    def score_result(self, scenario: Any) -> Optional[Score]:
        items: Optional[List[str]]
        if self.expected is not None:
            items = list(self.expected)
        elif self.expected_key:
            params = getattr(scenario, "parameters", {}) or {}
            items = params.get(self.expected_key)
        else:
            items = None
        if not items:
            return None
        actual = _get_actual(scenario)
        if not actual:
            return Score(name=self.name, score=0.0, passed=False, message="empty output")
        matched = sum(1 for item in items if self._match(item, actual))
        score = matched / len(items)
        return Score(
            name=self.name,
            score=score,
            passed=score >= self.threshold,
            message=f"matched {matched}/{len(items)}",
        )

    def _rule_config(self) -> Dict[str, Any]:
        return {
            "expected": self.expected,
            "expected_key": self.expected_key,
            "fuzzy": self.fuzzy,
            "fuzzy_threshold": self.fuzzy_threshold,
            "threshold": self.threshold,
        }
