"""Base types for all Keystone scorers.

Design
------

Every built-in scorer is a subclass of :class:`BaseScorer`. There are two
execution models:

1. **Server-side invariant** — the scorer serializes itself as a spec-level
   invariant via ``to_invariant()``. Keystone's server evaluates the check
   against the sandbox (filesystem, command output, SQL, LLM-as-judge).
   These scorers have no dependency on a local LLM client.

2. **Client-side score** — the scorer computes a score in-process via
   ``score_result(scenario)``. Heuristic scorers (exact match, Levenshtein,
   JSON diff) fall here, as do LLM-judge scorers when the caller wants to run
   them locally using their own wrapped Anthropic/OpenAI client.

LLM-judge scorers support *both* execution models. Calling ``to_invariant()``
gives you a server-side rule; calling ``score_result()`` runs locally through
the configured ``LLMClient``.

Customisation
-------------

Every scorer accepts the standard knobs — ``weight``, ``gate``, ``model``,
``temperature``, ``rubric``. LLM-judge scorers additionally accept
``prompt_template`` (override the built-in template) and ``parser`` (custom
response parser). All knobs have ergonomic builder methods:

>>> judge = Factuality(weight=0.5).with_client(my_client).tune(
...     prompt_template="Is '{answer}' correct for '{question}'?")
"""

from __future__ import annotations

import asyncio
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Protocol, Union


# ---------------------------------------------------------------------------
# Score result
# ---------------------------------------------------------------------------


@dataclass
class Score:
    """A single score produced by a scorer."""

    name: str
    score: float  # 0.0 – 1.0
    passed: bool = True
    message: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# LLM client protocol — local execution backend for judge scorers
# ---------------------------------------------------------------------------


class LLMClient(Protocol):
    """Thin protocol any LLM client must satisfy to back a judge scorer.

    Users can pass an Anthropic or OpenAI client wrapped by :meth:`Keystone.wrap`
    — the SDK auto-detects and adapts. Or they can implement this protocol
    directly for custom backends (Bedrock, Vertex, Ollama, …).
    """

    def complete(
        self,
        messages: List[Dict[str, Any]],
        *,
        model: str,
        temperature: float = 0.0,
        max_tokens: int = 1024,
    ) -> str:  # pragma: no cover — protocol
        ...


# ---------------------------------------------------------------------------
# Default LLM backend — paragon-llm-proxy
# ---------------------------------------------------------------------------


class ParagonProxyClient:
    """Default ``LLMClient`` used when no client is explicitly configured.

    Routes completions through the Paragon LLM proxy (per CLAUDE.md
    convention). Uses ``KEYSTONE_API_KEY`` from the Keystone client for
    authentication, or ``PARAGON_API_KEY`` as a fallback.
    """

    _PROXY_URL = "https://dmlkvjayquufspcpaqyq.supabase.co/functions/v1/paragon-llm-proxy/chat/completions"
    _ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtbGt2amF5cXV1ZnNwY3BhcXlxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzYxOTMxNDUsImV4cCI6MjA1MTc2OTE0NX0.-zAXDD-cT-u1tzYn-I0qEoF0XQp3j4nNgl9xUaa-_NU"

    def __init__(self, api_key: Optional[str] = None) -> None:
        self._api_key = api_key or os.environ.get("PARAGON_API_KEY") or os.environ.get("KEYSTONE_API_KEY") or ""

    def complete(
        self,
        messages: List[Dict[str, Any]],
        *,
        model: str,
        temperature: float = 0.0,
        max_tokens: int = 1024,
    ) -> str:
        body = json.dumps({
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }).encode("utf-8")

        req = urllib.request.Request(
            self._PROXY_URL,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._ANON_KEY}",
                "apikey": self._ANON_KEY,
                "x-paragon-api-key": self._api_key,
                "x-paragon-client": "keystone-sdk",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"paragon-llm-proxy {e.code}: {e.read().decode('utf-8', errors='ignore')}") from e

        choices = data.get("choices") or []
        if not choices:
            return ""
        return str(choices[0].get("message", {}).get("content", ""))


def _adapt_any_client(client: Any) -> LLMClient:
    """Adapt a Keystone-wrapped Anthropic/OpenAI client to the ``LLMClient`` protocol."""

    if hasattr(client, "complete") and callable(client.complete):  # Already protocol-compatible.
        return client  # type: ignore[return-value]

    # OpenAI-style client (preferred — what paragon proxy speaks)
    if hasattr(client, "chat") and hasattr(client.chat, "completions"):
        openai_client = client

        class _OpenAIAdapter:
            def complete(self, messages, *, model, temperature=0.0, max_tokens=1024):
                r = openai_client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                choices = getattr(r, "choices", None) or []
                if not choices:
                    return ""
                msg = getattr(choices[0], "message", None)
                return getattr(msg, "content", "") if msg else ""

        return _OpenAIAdapter()  # type: ignore[return-value]

    if hasattr(client, "messages") and hasattr(client.messages, "create"):
        anthropic_client = client

        class _AnthropicAdapter:
            def complete(self, messages, *, model, temperature=0.0, max_tokens=1024):
                # Anthropic API expects system separately + user/assistant turns.
                system = ""
                converted: List[Dict[str, Any]] = []
                for m in messages:
                    if m.get("role") == "system":
                        system += str(m.get("content", "")) + "\n"
                    else:
                        converted.append({"role": m["role"], "content": m["content"]})
                r = anthropic_client.messages.create(
                    model=model,
                    system=system.strip() or None,
                    messages=converted,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                for block in getattr(r, "content", []) or []:
                    if getattr(block, "type", None) == "text":
                        return getattr(block, "text", "")
                return ""

        return _AnthropicAdapter()  # type: ignore[return-value]

    raise TypeError(
        f"Unsupported LLM client of type {type(client).__name__}; "
        "expected an Anthropic/OpenAI client, or an object implementing LLMClient.complete()."
    )


# ---------------------------------------------------------------------------
# Base scorer
# ---------------------------------------------------------------------------


class BaseScorer:
    """Shared base for every scorer."""

    name: str = ""
    weight: float = 1.0
    gate: bool = False
    #: Rule type when this scorer is registered as a persistent server-side rule.
    rule_type: str = ""

    # ------- builder helpers ---------------------------------------------

    def with_client(self, client: Any) -> "BaseScorer":
        """Bind a specific LLM client to this scorer (LLM-judge scorers only)."""

        self._client = _adapt_any_client(client)  # type: ignore[attr-defined]
        return self

    def tune(
        self,
        *,
        prompt_template: Optional[str] = None,
        parser: Optional[Callable[[str], Score]] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        rubric: Optional[Dict[str, str]] = None,
    ) -> "BaseScorer":
        """Override any tunable knob without subclassing."""

        if prompt_template is not None:
            self._prompt_template = prompt_template  # type: ignore[attr-defined]
        if parser is not None:
            self._parser = parser  # type: ignore[attr-defined]
        if model is not None:
            self._model = model  # type: ignore[attr-defined]
        if temperature is not None:
            self._temperature = temperature  # type: ignore[attr-defined]
        if rubric is not None:
            self._rubric = rubric  # type: ignore[attr-defined]
        return self

    # ------- execution models --------------------------------------------

    def to_invariant(self) -> Optional[Dict[str, Any]]:
        """Serialize as a spec invariant dict, or return ``None`` if client-side only."""

        return None

    def to_rule(self) -> Optional[Dict[str, Any]]:
        """Serialize as a reusable ``score_rule`` dict suitable for ``ScoringService.create_rule``."""

        if not self.rule_type:
            return None
        config = self._rule_config()  # type: ignore[attr-defined]
        return {"name": self.name, "type": self.rule_type, "config": config}

    def _rule_config(self) -> Dict[str, Any]:
        """Subclasses override to supply the rule's config payload."""

        return {}

    def score_result(self, scenario: Any) -> Optional[Score]:
        """Run client-side scoring on a ScenarioResult. Override for custom scorers."""

        return None


# ---------------------------------------------------------------------------
# Custom scorer — wraps a user function
# ---------------------------------------------------------------------------


class CustomScorer(BaseScorer):
    """Wraps a user-defined function as a client-side scorer."""

    def __init__(
        self,
        fn: Callable[[Any], Union[float, bool, Score, Awaitable[Union[float, bool, Score]]]],
        name: str,
        weight: float = 1.0,
        gate: bool = False,
    ):
        self.fn = fn
        self.name = name
        self.weight = weight
        self.gate = gate

    def score_result(self, scenario: Any) -> Optional[Score]:
        try:
            result = self.fn(scenario)
            if asyncio.iscoroutine(result):
                # Running inside a non-async caller — drain the coroutine.
                result = asyncio.get_event_loop().run_until_complete(result) if not _loop_running() else asyncio.run(_await(result))  # type: ignore[arg-type]
            return _normalize_score(self.name, result)
        except Exception as e:
            return Score(name=self.name, score=0.0, passed=False, message=f"scorer error: {e}")


async def _await(coro: Awaitable[Any]) -> Any:
    return await coro


def _loop_running() -> bool:
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False


def _normalize_score(name: str, out: Any) -> Optional[Score]:
    if out is None:
        return None
    if isinstance(out, Score):
        return out
    if isinstance(out, bool):
        return Score(name=name, score=1.0 if out else 0.0, passed=out)
    if isinstance(out, (int, float)):
        return Score(name=name, score=float(out), passed=float(out) >= 0.5)
    return None


def Scorer(
    fn: Optional[Callable[..., Any]] = None,
    *,
    name: Optional[str] = None,
    weight: float = 1.0,
    gate: bool = False,
) -> Union[CustomScorer, Callable[[Callable[..., Any]], CustomScorer]]:
    """Decorator that wraps a function as a :class:`CustomScorer`.

    Usage::

        @Scorer
        def check_output(result):
            return 1.0 if "hello" in result.agent_output else 0.0

        @Scorer(name="critical", weight=2.0, gate=True)
        def critical_check(result):
            return result.exit_code == 0
    """

    if fn is not None:
        return CustomScorer(fn, name=name or fn.__name__, weight=weight, gate=gate)

    def decorator(f: Callable[..., Any]) -> CustomScorer:
        return CustomScorer(f, name=name or f.__name__, weight=weight, gate=gate)

    return decorator


# ---------------------------------------------------------------------------
# Bulk helpers
# ---------------------------------------------------------------------------


def scorers_to_invariants(scorers: List[BaseScorer]) -> Dict[str, Dict[str, Any]]:
    """Convert built-in scorers to a dict of spec invariants."""

    invariants: Dict[str, Dict[str, Any]] = {}
    for scorer in scorers:
        inv = scorer.to_invariant()
        if inv is None:
            continue
        key = scorer.name.replace(":", "_").replace("/", "_").replace(" ", "_")
        invariants[key] = inv
    return invariants


def run_client_scorers(scorers: List[BaseScorer], scenario: Any) -> List[Score]:
    """Run client-side scorers against a scenario result."""

    results: List[Score] = []
    for scorer in scorers:
        score = scorer.score_result(scenario)
        if score is not None:
            results.append(score)
    return results


# ---------------------------------------------------------------------------
# Helper used by LLM-judge scorers to lazily obtain a default client
# ---------------------------------------------------------------------------


_DEFAULT_CLIENT: Optional[LLMClient] = None


def default_llm_client() -> LLMClient:
    """Return a module-global ``ParagonProxyClient``, creating it on first use."""

    global _DEFAULT_CLIENT
    if _DEFAULT_CLIENT is None:
        _DEFAULT_CLIENT = ParagonProxyClient()
    return _DEFAULT_CLIENT


def set_default_llm_client(client: Any) -> None:
    """Override the module-global default client (e.g. from ``Keystone(scorer_client=...)``)."""

    global _DEFAULT_CLIENT
    _DEFAULT_CLIENT = _adapt_any_client(client)
