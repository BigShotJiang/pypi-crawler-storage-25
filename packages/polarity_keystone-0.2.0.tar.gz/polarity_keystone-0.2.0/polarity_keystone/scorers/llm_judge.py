"""LLM-as-judge scorers.

Every scorer here can run in two modes:

1. **Locally** via ``score_result(scenario)`` — calls the configured
   :class:`~polarity_keystone.scorers.base.LLMClient` with a canonical prompt
   and parses a JSON response.
2. **Server-side** via ``to_invariant()`` / ``to_rule()`` — serializes as an
   ``llm_as_judge`` check whose evaluation runs inside Keystone's online
   scorer engine (routed through paragon-llm-proxy).

The same scorer instance supports both paths; pick based on whether you
have a local LLM client and want immediate scoring, or you want persistent
rules that apply to every future experiment run.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from .base import BaseScorer, LLMClient, Score, default_llm_client
from .prompts import JUDGE_PROMPT_TEMPLATES, JUDGE_SYSTEM


# ---------------------------------------------------------------------------
# Shared response parser
# ---------------------------------------------------------------------------


_JSON_RE = re.compile(r"\{[^{}]*\}", re.DOTALL)


def default_parser(name: str, response: str) -> Score:
    """Parse the canonical ``{"score","passed","reason"}`` JSON envelope.

    Falls back to heuristic extraction if the model ignored the JSON
    instruction, using the first number in [0,1] it emits.
    """

    stripped = response.strip()
    try:
        obj = json.loads(stripped)
    except json.JSONDecodeError:
        match = _JSON_RE.search(stripped)
        obj = None
        if match:
            try:
                obj = json.loads(match.group())
            except json.JSONDecodeError:
                obj = None

    if isinstance(obj, dict) and "score" in obj:
        try:
            score = float(obj.get("score", 0.0))
        except (TypeError, ValueError):
            score = 0.0
        score = max(0.0, min(1.0, score))
        passed = bool(obj.get("passed", score >= 0.5))
        reason = str(obj.get("reason", ""))
        return Score(name=name, score=score, passed=passed, message=reason)

    # Heuristic fallback — extract first float-looking token in [0,1].
    m = re.search(r"-?\d+(?:\.\d+)?", stripped)
    if m:
        try:
            raw = float(m.group())
        except ValueError:
            raw = 0.0
        score = max(0.0, min(1.0, raw if raw <= 1.0 else raw / 10.0))
        return Score(
            name=name,
            score=score,
            passed=score >= 0.5,
            message=f"heuristic parse: {stripped[:120]}",
        )

    return Score(name=name, score=0.0, passed=False, message=f"unparseable: {stripped[:120]}")


# ---------------------------------------------------------------------------
# Shared base
# ---------------------------------------------------------------------------


class _JudgeScorer(BaseScorer):
    """Common plumbing for every LLM-judge scorer."""

    rule_type = "llm_as_judge"
    #: Override in subclasses to pick a template key from ``JUDGE_PROMPT_TEMPLATES``.
    template_key: str = ""

    def __init__(
        self,
        *,
        model: str = "paragon-fast",
        temperature: float = 0.0,
        rubric: Optional[Dict[str, str]] = None,
        prompt_template: Optional[str] = None,
        parser: Optional[Callable[[str, str], Score]] = None,
        client: Any = None,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._rubric = rubric
        self._prompt_template = prompt_template
        self._parser = parser
        self.weight = weight
        self.gate = gate
        if client is not None:
            self.with_client(client)

    # --- template ---------------------------------------------------------

    def _template(self) -> str:
        return self._prompt_template or JUDGE_PROMPT_TEMPLATES[self.template_key]

    def _fill_template(self, scenario: Any) -> str:
        """Subclasses override to pass the right vars into the template."""

        raise NotImplementedError

    # --- rule config (server-side path) ----------------------------------

    def _rule_config(self) -> Dict[str, Any]:
        cfg: Dict[str, Any] = {
            "template_key": self.template_key,
            "model": self._model,
            "temperature": self._temperature,
        }
        if self._rubric:
            cfg["rubric"] = self._rubric
        if self._prompt_template is not None:
            cfg["prompt_template"] = self._prompt_template
        return cfg

    def to_invariant(self) -> Dict[str, Any]:
        check: Dict[str, Any] = {
            "type": "llm_as_judge",
            "model": self._model,
            "temperature": self._temperature,
            "template_key": self.template_key,
            "input_from": "agent_output",
        }
        if self._rubric:
            check["rubric"] = self._rubric
        if self._prompt_template is not None:
            check["prompt_template"] = self._prompt_template
        return {
            "description": f"{self.name}",
            "weight": self.weight,
            "gate": self.gate,
            "check": check,
        }

    # --- client-side path -------------------------------------------------

    def _get_client(self) -> LLMClient:
        client: Optional[LLMClient] = getattr(self, "_client", None)
        return client or default_llm_client()

    def score_result(self, scenario: Any) -> Optional[Score]:
        try:
            user_prompt = self._fill_template(scenario)
        except _SkipScoring as e:
            return Score(name=self.name, score=0.0, passed=False, message=str(e))

        # Prompt-injection hardening: cap rubric size + delimit it so the
        # judge knows the rubric is author-provided metadata, not directives
        # from whatever the agent emitted.
        if self._rubric:
            max_rubric_chars = 2000
            lines = []
            total = 0
            for k, v in self._rubric.items():
                entry = f"- {k}: {v}"
                total += len(entry) + 1
                if total > max_rubric_chars:
                    lines.append("- ...rubric truncated (size cap reached)...")
                    break
                lines.append(entry)
            user_prompt += "\nRubric (authored by the rule owner):\n" + "\n".join(lines)

        messages = [
            {"role": "system", "content": JUDGE_SYSTEM},
            {"role": "user", "content": user_prompt},
        ]
        try:
            response = self._get_client().complete(
                messages,
                model=self._model,
                temperature=self._temperature,
                max_tokens=512,
            )
        except Exception as e:
            return Score(name=self.name, score=0.0, passed=False, message=f"judge call failed: {e}")

        parser = self._parser or default_parser
        # Users may pass parsers with either (name, resp) or (resp,) signatures.
        try:
            return parser(self.name, response)  # type: ignore[call-arg]
        except TypeError:
            return parser(response)  # type: ignore[call-arg]


class _SkipScoring(RuntimeError):
    """Raised when we lack the inputs to compute a score for this scenario."""


# Hard upper bound on user-controlled values that land in the judge prompt.
# Prevents pathological inputs from bloating the prompt (cost DoS) and caps
# the surface area a prompt-injection payload can use.
MAX_FIELD_CHARS = 8000


def _truncate(s: str) -> str:
    return s if len(s) <= MAX_FIELD_CHARS else s[:MAX_FIELD_CHARS] + "\n…[truncated]"


def _get_param(scenario: Any, key: str) -> Optional[str]:
    params = getattr(scenario, "parameters", {}) or {}
    val = params.get(key)
    return None if val is None else _truncate(str(val))


def _require(scenario: Any, key: str) -> str:
    val = _get_param(scenario, key)
    if val is None:
        raise _SkipScoring(f"scenario.parameters missing '{key}'")
    return val


def _actual(scenario: Any) -> str:
    return _truncate(str(getattr(scenario, "agent_output", "") or ""))


# ---------------------------------------------------------------------------
# Concrete LLM-judge scorers
# ---------------------------------------------------------------------------


class Factuality(_JudgeScorer):
    """Grade factual accuracy of the agent's answer vs a reference."""

    name = "factuality"
    template_key = "factuality"

    def __init__(
        self,
        *,
        question_key: str = "question",
        expected_key: str = "expected",
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self._question_key = question_key
        self._expected_key = expected_key

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            question=_require(scenario, self._question_key),
            expected=_require(scenario, self._expected_key),
            actual=_actual(scenario),
        )


class Battle(_JudgeScorer):
    """A/B grade the agent's answer against a baseline."""

    name = "battle"
    template_key = "battle"

    def __init__(
        self,
        *,
        instruction_key: str = "instruction",
        expected_key: str = "baseline",
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self._instruction_key = instruction_key
        self._expected_key = expected_key

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            instruction=_require(scenario, self._instruction_key),
            expected=_require(scenario, self._expected_key),
            actual=_actual(scenario),
        )


class ClosedQA(_JudgeScorer):
    """Grade a closed-form QA response."""

    name = "closed_qa"
    template_key = "closed_qa"

    def __init__(
        self,
        *,
        question_key: str = "question",
        expected_key: str = "answer",
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self._question_key = question_key
        self._expected_key = expected_key

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            question=_require(scenario, self._question_key),
            expected=_require(scenario, self._expected_key),
            actual=_actual(scenario),
        )


class Humor(_JudgeScorer):
    name = "humor"
    template_key = "humor"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(actual=_actual(scenario))


class Moderation(_JudgeScorer):
    name = "moderation"
    template_key = "moderation"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(actual=_actual(scenario))


class Summarization(_JudgeScorer):
    name = "summarization"
    template_key = "summarization"

    def __init__(self, *, source_key: str = "source", **kw: Any) -> None:
        super().__init__(**kw)
        self._source_key = source_key

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            source=_require(scenario, self._source_key),
            actual=_actual(scenario),
        )


class SQLJudge(_JudgeScorer):
    """Grade a generated SQL query against an expected SQL query."""

    name = "sql_judge"
    template_key = "sql_judge"

    def __init__(
        self,
        *,
        question_key: str = "question",
        expected_key: str = "expected_sql",
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self._question_key = question_key
        self._expected_key = expected_key

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(
            question=_require(scenario, self._question_key),
            expected=_require(scenario, self._expected_key),
            actual=_actual(scenario),
        )


class Translation(_JudgeScorer):
    name = "translation"
    template_key = "translation"

    def __init__(
        self,
        *,
        source_key: str = "source",
        source_lang: str = "source language",
        target_lang: str = "target language",
        expected_key: Optional[str] = "reference",
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self._source_key = source_key
        self._source_lang = source_lang
        self._target_lang = target_lang
        self._expected_key = expected_key

    def _fill_template(self, scenario: Any) -> str:
        expected = _get_param(scenario, self._expected_key) if self._expected_key else ""
        return self._template().format(
            source_lang=self._source_lang,
            target_lang=self._target_lang,
            source=_require(scenario, self._source_key),
            actual=_actual(scenario),
            expected=expected or "(no reference provided)",
        )


class Security(_JudgeScorer):
    """Flag unsafe code generation or prompt-injection success."""

    name = "security"
    template_key = "security"

    def _fill_template(self, scenario: Any) -> str:
        return self._template().format(actual=_actual(scenario))
