"""Dataset operations for the Keystone SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from ._http import HTTPClient


class DatasetService:
    """CRUD and record management for Keystone datasets."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(self, name: str, description: str = "") -> Dict[str, Any]:
        """Create a new dataset.

        Args:
            name: Dataset name (unique per user).
            description: Optional description.

        Returns:
            The created dataset dict with ``id``, ``name``, ``version``, etc.
        """
        return self._http.post("/v1/datasets", {"name": name, "description": description})

    def list(self) -> List[Dict[str, Any]]:
        """List all datasets."""
        return self._http.get("/v1/datasets") or []

    def get(self, dataset_id: str) -> Dict[str, Any]:
        """Get a dataset by ID."""
        return self._http.get(f"/v1/datasets/{dataset_id}")

    def delete(self, dataset_id: str) -> None:
        """Delete a dataset and all its records."""
        self._http.delete(f"/v1/datasets/{dataset_id}")

    def add_records(
        self,
        dataset_id: str,
        records: List[Dict[str, Any]],
    ) -> Dict[str, int]:
        """Add records to a dataset. Auto-increments the dataset version.

        Each record should have ``input`` (required) and optionally
        ``expected``, ``metadata``, and ``tags``.

        Args:
            dataset_id: Target dataset ID.
            records: List of record dicts.

        Returns:
            Dict with ``added`` count.

        Example::

            ks.datasets.add_records(ds["id"], [
                {"input": {"prompt": "fix the bug"}, "expected": {"file": "fixed.py"}},
                {"input": {"prompt": "add tests"}, "tags": ["testing"]},
            ])
        """
        return self._http.post(f"/v1/datasets/{dataset_id}/records", {"records": records})

    def get_records(
        self,
        dataset_id: str,
        *,
        version: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Get records from a dataset.

        Args:
            dataset_id: Target dataset ID.
            version: Specific version (default: all versions).
            tags: Filter by tags.

        Returns:
            List of record dicts.
        """
        path = f"/v1/datasets/{dataset_id}/records"
        params = []
        if version is not None:
            params.append(f"version={version}")
        if tags:
            params.append(f"tags={','.join(tags)}")
        if params:
            path += "?" + "&".join(params)
        return self._http.get(path) or []
