"""Experiment operations for the Keystone SDK."""

from __future__ import annotations

import time as _time
from typing import Any, Dict, List, Optional

from ._http import HTTPClient
from .types import (
    Comparison,
    Experiment,
    ExperimentMetrics,
    KeystoneError,
    RunResults,
)


class ExperimentService:
    """Operations for Keystone experiments."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(self, name: str, spec_id: str) -> Experiment:
        """Create a new experiment.

        Args:
            name: Human-readable experiment name.
            spec_id: ID of the spec this experiment runs against.
        """
        data = self._http.post("/v1/experiments", {"name": name, "spec_id": spec_id})
        return Experiment.from_dict(data)

    def get(self, experiment_id: str) -> RunResults:
        """Get experiment results (including scenario-level detail).

        Returns a ``RunResults`` object.  If the experiment is still
        running, the results will reflect progress so far.
        """
        data = self._http.get(f"/v1/experiments/{experiment_id}")
        return RunResults.from_dict(data)

    def list(self) -> List[Experiment]:
        """List all experiments."""
        data = self._http.get("/v1/experiments")
        if data is None:
            return []
        return [Experiment.from_dict(item) for item in data]

    def run(self, experiment_id: str) -> None:
        """Trigger an experiment run.

        This enqueues scenario jobs and returns immediately.  Use
        :meth:`get` or :meth:`run_and_wait` to poll for results.
        """
        self._http.post(f"/v1/experiments/{experiment_id}/run")

    def run_and_wait(
        self,
        experiment_id: str,
        poll_interval: float = 1.0,
        timeout: float = 600,
        scores: "Optional[list]" = None,
    ) -> RunResults:
        """Run an experiment and poll until it completes.

        This is the convenience "fire-and-forget" method: it triggers the
        run, then polls ``GET /v1/experiments/{id}`` until the experiment
        status is ``"completed"`` or the *timeout* is exceeded.

        After completion, any client-side scorer functions in ``scores``
        are executed against each scenario result. Their scores are appended
        to the invariant results.

        Args:
            experiment_id: Experiment to run.
            poll_interval: Seconds between polls (default 1).
            timeout: Maximum seconds to wait (default 600).
            scores: Optional list of scorer objects (built-in or custom).
                Built-in scorers (FileExists, LLMJudge, etc.) are converted
                to spec invariants. Custom scorers (``@Scorer`` decorated
                functions) run client-side after completion.

        Returns:
            Final ``RunResults`` once the experiment completes.

        Raises:
            KeystoneError: If the timeout is exceeded.
        """
        self.run(experiment_id)

        deadline = _time.monotonic() + timeout
        while True:
            results = self.get(experiment_id)

            if results.total_scenarios > 0:
                done = (results.passed + results.failed + results.flaky + results.errors)
                if done >= results.total_scenarios:
                    # Run client-side scorers.
                    if scores:
                        from .scores import run_client_scorers
                        for scenario in results.scenarios:
                            client_scores = run_client_scorers(scores, scenario)
                            for cs in client_scores:
                                from .types import InvariantResult
                                scenario.invariants.append(InvariantResult(
                                    name=cs.name,
                                    passed=cs.passed,
                                    score=cs.score,
                                    message=cs.message,
                                    weight=1.0,
                                ))
                    return results

            if _time.monotonic() >= deadline:
                raise KeystoneError(
                    0,
                    f"Timed out waiting for experiment {experiment_id} "
                    f"after {timeout}s",
                )

            _time.sleep(poll_interval)

    def compare(self, baseline_id: str, candidate_id: str) -> Comparison:
        """Compare two experiment runs.

        Args:
            baseline_id: Experiment ID of the baseline run.
            candidate_id: Experiment ID of the candidate run.
        """
        data = self._http.post(
            "/v1/experiments/compare",
            {"baseline_id": baseline_id, "candidate_id": candidate_id},
        )
        return Comparison.from_dict(data)

    def metrics(self, experiment_id: str) -> ExperimentMetrics:
        """Get detailed metrics for an experiment."""
        data = self._http.get(f"/v1/metrics/experiments/{experiment_id}")
        return ExperimentMetrics.from_dict(data)
