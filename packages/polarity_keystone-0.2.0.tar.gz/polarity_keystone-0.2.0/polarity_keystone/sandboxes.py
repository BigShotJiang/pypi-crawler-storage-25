"""Sandbox operations for the Keystone SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient
from .types import CommandResult, Sandbox, StateDiff, StateSnapshot


class SandboxService:
    """CRUD and interaction operations for Keystone sandboxes."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        spec_id: str,
        timeout: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Sandbox:
        """Create a new sandbox from a spec.

        Args:
            spec_id: ID of the spec to create the sandbox from.
            timeout: Optional duration string (e.g. ``"10m"``).
            metadata: Optional key-value metadata.
        """
        body: Dict[str, Any] = {"spec_id": spec_id}
        if timeout is not None:
            body["timeout"] = timeout
        if metadata is not None:
            body["metadata"] = metadata
        data = self._http.post("/v1/sandboxes", body)
        return Sandbox.from_dict(data)

    def get(self, sandbox_id: str) -> Sandbox:
        """Get a sandbox by ID."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}")
        return Sandbox.from_dict(data)

    def list(self) -> List[Sandbox]:
        """List all active sandboxes."""
        data = self._http.get("/v1/sandboxes")
        if data is None:
            return []
        return [Sandbox.from_dict(item) for item in data]

    def destroy(self, sandbox_id: str) -> None:
        """Destroy a sandbox and clean up all its resources."""
        self._http.delete(f"/v1/sandboxes/{sandbox_id}")

    def run_command(
        self,
        sandbox_id: str,
        command: str,
        timeout: Optional[str] = None,
    ) -> CommandResult:
        """Execute a shell command inside a sandbox.

        Args:
            sandbox_id: Target sandbox.
            command: Shell command to run.
            timeout: Optional duration string (e.g. ``"30s"``).
        """
        body: Dict[str, Any] = {"command": command}
        if timeout is not None:
            body["timeout"] = timeout
        data = self._http.post(f"/v1/sandboxes/{sandbox_id}/commands", body)
        return CommandResult.from_dict(data)

    def read_file(self, sandbox_id: str, path: str) -> bytes:
        """Read a file from the sandbox workspace.

        Returns the raw bytes of the file.
        """
        return self._http.get_bytes(f"/v1/sandboxes/{sandbox_id}/files/{path}")

    def write_file(self, sandbox_id: str, path: str, content: str) -> None:
        """Write a file to the sandbox workspace.

        Args:
            sandbox_id: Target sandbox.
            path: Relative file path inside the sandbox.
            content: File content as a string.
        """
        self._http.post(f"/v1/sandboxes/{sandbox_id}/files", {"path": path, "content": content})

    def delete_file(self, sandbox_id: str, path: str) -> None:
        """Delete a file from the sandbox workspace."""
        self._http.delete(f"/v1/sandboxes/{sandbox_id}/files/{path}")

    def state(self, sandbox_id: str) -> StateSnapshot:
        """Capture the current filesystem state of a sandbox."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}/state")
        return StateSnapshot.from_dict(data)

    def diff(self, sandbox_id: str) -> StateDiff:
        """Get the diff between the before-run snapshot and current state."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}/diff")
        return StateDiff.from_dict(data)

    def ingest_trace(self, sandbox_id: str, events: list) -> dict:
        """Post tool call trace events to a sandbox.

        Any agent can use this to report what it did. Keystone uses these
        for scoring, metrics, and observability.

        Args:
            sandbox_id: Target sandbox.
            events: List of trace event dicts with keys like:
                ts, event_type, tool, phase, duration_ms, status,
                input_bytes, output_bytes, cost
        """
        return self._http.post(
            f"/v1/sandboxes/{sandbox_id}/trace", {"events": events}
        )

    def get_trace(self, sandbox_id: str) -> dict:
        """Get trace events and computed metrics for a sandbox.

        Returns dict with 'events' (list) and 'metrics' (dict).
        """
        return self._http.get(f"/v1/sandboxes/{sandbox_id}/trace")
