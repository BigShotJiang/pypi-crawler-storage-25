"""Back-compat shim for the legacy ``polarity_keystone.scores`` module.

The scoring system was refactored into a dedicated subpackage
(:mod:`polarity_keystone.scorers`). This module re-exports the symbols that
existed in the original ``scores.py`` so code that did::

    from polarity_keystone.scores import FileExists, LLMJudge, Scorer

continues to work unchanged. New code should import from
``polarity_keystone.scorers`` (or ``polarity_keystone``) directly.
"""

from __future__ import annotations

from .scorers.base import (
    BaseScorer,
    CustomScorer,
    Score,
    Scorer,
    run_client_scorers,
    scorers_to_invariants,
)
from .scorers.sandbox import (
    CommandExits,
    FileContains,
    FileExists,
    LLMJudge,
    SQLEquals,
)

# ``_CustomScorer`` was the historical private name; keep it re-exported for any
# code that imported it directly.
_CustomScorer = CustomScorer

__all__ = [
    "BaseScorer",
    "CustomScorer",
    "Score",
    "Scorer",
    "FileExists",
    "FileContains",
    "CommandExits",
    "SQLEquals",
    "LLMJudge",
    "run_client_scorers",
    "scorers_to_invariants",
]
