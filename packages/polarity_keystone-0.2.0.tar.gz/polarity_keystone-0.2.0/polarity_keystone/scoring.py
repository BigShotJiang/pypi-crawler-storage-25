"""Online scoring operations for the Keystone SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient


class ScoringService:
    """Manage score rules and evaluate experiment traces."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create_rule(
        self,
        name: str,
        type: str,
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create a score rule.

        Args:
            name: Rule name.
            type: Rule type (``llm_as_judge``, ``regex``, ``contains``, ``custom``).
            config: Type-specific configuration.

        Returns:
            The created rule dict.

        Example::

            rule = ks.scoring.create_rule(
                name="output-quality",
                type="llm_as_judge",
                config={"criteria": "Is the output correct?", "model": "paragon-fast"},
            )
        """
        return self._http.post("/v1/score-rules", {
            "name": name, "type": type, "config": config,
        })

    def list_rules(self) -> List[Dict[str, Any]]:
        """List all score rules."""
        return self._http.get("/v1/score-rules") or []

    def delete_rule(self, rule_id: str) -> None:
        """Delete a score rule."""
        self._http.delete(f"/v1/score-rules/{rule_id}")

    def score_experiment(
        self, experiment_id: str, rule_ids: List[str]
    ) -> Dict[str, str]:
        """Trigger offline scoring for an experiment.

        Runs async on the server. Use :meth:`get_scores` to fetch results.

        Args:
            experiment_id: Experiment to score.
            rule_ids: List of rule IDs to apply.
        """
        return self._http.post(
            f"/v1/experiments/{experiment_id}/score",
            {"rule_ids": rule_ids},
        )

    def get_scores(self, experiment_id: str) -> List[Dict[str, Any]]:
        """Fetch offline scores for an experiment.

        Returns:
            List of score dicts with rule_id, trace_id, score, passed, message.
        """
        return self._http.get(f"/v1/experiments/{experiment_id}/scores") or []
