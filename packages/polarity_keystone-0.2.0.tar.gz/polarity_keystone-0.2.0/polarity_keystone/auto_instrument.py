"""Auto-instrumentation entry point.

One function — :func:`auto_instrument` — detects which LLM stacks are
importable and patches every one it finds. Lets callers write::

    from polarity_keystone import Keystone, auto_instrument
    ks = Keystone()
    auto_instrument(sandbox_id="sb-xxx")
    # Every subsequent call through OpenAI / Anthropic / Mistral / LangChain /
    # LiteLLM / Google GenAI / Claude Agent SDK / DSPy is traced.

Design
------

* **Fail soft.** Each provider is guarded by try/except — missing modules
  just skip, never raise.
* **Idempotent.** Calling twice leaves a single layer of instrumentation.
* **Decoupled from Keystone's main client.** Passing ``sandbox_id`` is enough;
  no ``Keystone`` instance is strictly required (it falls back to env vars).

Supported providers
-------------------

OpenAI, Anthropic, Mistral, Google GenAI (``google-genai``), OpenRouter
(OpenAI-compatible, so handled by the OpenAI branch when the caller points
at ``https://openrouter.ai``), LiteLLM, Claude Agent SDK, DSPy, LangChain.
"""

from __future__ import annotations

import os
import sys
import time
from datetime import datetime, timezone
from typing import Any, List, Optional

from ._http import HTTPClient
from .wrap import _build_events, _extract_anthropic, _extract_openai, _post_trace_fire_and_forget


_ALREADY_PATCHED: set = set()


def auto_instrument(
    *,
    sandbox_id: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> List[str]:
    """Patch every importable provider in one call. Returns the patched names."""

    sandbox_id = sandbox_id or os.environ.get("KEYSTONE_SANDBOX_ID") or ""
    if not sandbox_id:
        raise RuntimeError(
            "auto_instrument requires sandbox_id (arg) or KEYSTONE_SANDBOX_ID env var",
        )
    base_url = base_url or os.environ.get("KEYSTONE_BASE_URL", "https://keystone.ngrok-free.dev")
    api_key = api_key or os.environ.get("KEYSTONE_API_KEY")
    http = HTTPClient(base_url, api_key, 30)

    patched: List[str] = []
    for fn in (
        _patch_openai,
        _patch_anthropic,
        _patch_mistral,
        _patch_google_genai,
        _patch_litellm,
        _patch_claude_agent_sdk,
        _patch_dspy,
        _patch_langchain,
    ):
        try:
            name = fn(http, sandbox_id)
            if name:
                patched.append(name)
        except Exception as e:  # pragma: no cover — defensive
            print(f"[keystone] auto_instrument: {fn.__name__} failed: {e}", file=sys.stderr)
    return patched


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _is_patched(key: str) -> bool:
    if key in _ALREADY_PATCHED:
        return True
    _ALREADY_PATCHED.add(key)
    return False


def _emit_generic(
    http: HTTPClient,
    sandbox_id: str,
    provider: str,
    *,
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_tokens: int = 0,
    reasoning_tokens: int = 0,
    duration_ms: int = 0,
    output_text: str = "",
    tool_calls: Optional[list] = None,
    input_messages: str = "",
) -> None:
    events = _build_events(
        provider=provider,
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        tool_calls=tool_calls or [],
        duration_ms=duration_ms,
        cache_tokens=cache_tokens,
        reasoning_tokens=reasoning_tokens,
        output_text=output_text,
        input_messages=input_messages,
    )
    if events:
        _post_trace_fire_and_forget(http, sandbox_id, events)


# ---------------------------------------------------------------------------
# Per-provider patchers
# ---------------------------------------------------------------------------


def _patch_openai(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        import openai  # type: ignore
    except ImportError:
        return None
    if _is_patched("openai"):
        return "openai"

    from .wrap import _patch_openai as _patch  # reuse logic from wrap module

    # Patch the default module-level client if present.
    try:
        _patch(openai, http, sandbox_id)
    except Exception:
        pass

    # Patch the generic OpenAI class so any future client picks it up.
    if hasattr(openai, "OpenAI"):
        original_init = openai.OpenAI.__init__

        def patched_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            try:
                _patch(self, http, sandbox_id)
            except Exception:
                pass

        openai.OpenAI.__init__ = patched_init
    return "openai"


def _patch_anthropic(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        import anthropic  # type: ignore
    except ImportError:
        return None
    if _is_patched("anthropic"):
        return "anthropic"

    from .wrap import _patch_anthropic as _patch  # type: ignore

    if hasattr(anthropic, "Anthropic"):
        original_init = anthropic.Anthropic.__init__

        def patched_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            try:
                _patch(self, http, sandbox_id)
            except Exception:
                pass

        anthropic.Anthropic.__init__ = patched_init
    return "anthropic"


def _patch_mistral(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        import mistralai  # type: ignore
    except ImportError:
        return None
    if _is_patched("mistral"):
        return "mistral"

    try:
        client_cls = mistralai.Mistral  # type: ignore[attr-defined]
    except AttributeError:
        return None
    original_complete = client_cls.chat.complete  # type: ignore[attr-defined]

    def wrapped(self, *args, **kwargs):
        start = time.monotonic()
        resp = original_complete(self, *args, **kwargs)
        try:
            info = _extract_openai(resp)  # Mistral response shape ≈ OpenAI
            _emit_generic(
                http,
                sandbox_id,
                "mistral",
                model=info["model"],
                input_tokens=info["input_tokens"],
                output_tokens=info["output_tokens"],
                cache_tokens=info.get("cache_tokens", 0),
                reasoning_tokens=info.get("reasoning_tokens", 0),
                output_text=info.get("output_text", ""),
                tool_calls=info["tool_calls"],
                duration_ms=int((time.monotonic() - start) * 1000),
            )
        except Exception:
            pass
        return resp

    client_cls.chat.complete = wrapped  # type: ignore[attr-defined]
    return "mistral"


def _patch_google_genai(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        from google import genai  # type: ignore
    except ImportError:
        return None
    if _is_patched("google-genai"):
        return "google-genai"

    try:
        models_cls = genai.Client  # type: ignore[attr-defined]
    except AttributeError:
        return None

    original_init = models_cls.__init__

    def patched_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        models = getattr(self, "models", None)
        if models is None or not hasattr(models, "generate_content"):
            return
        original = models.generate_content

        def wrapped(*a, **kw):
            start = time.monotonic()
            resp = original(*a, **kw)
            try:
                usage = getattr(resp, "usage_metadata", None)
                input_tokens = getattr(usage, "prompt_token_count", 0) if usage else 0
                output_tokens = getattr(usage, "candidates_token_count", 0) if usage else 0
                model = kw.get("model", "") or ""
                candidates = getattr(resp, "candidates", None) or []
                out = ""
                tool_calls = []
                if candidates:
                    content = getattr(candidates[0], "content", None)
                    parts = getattr(content, "parts", None) or []
                    for p in parts:
                        if getattr(p, "text", None):
                            out += p.text
                        fc = getattr(p, "function_call", None)
                        if fc is not None:
                            tool_calls.append({
                                "name": getattr(fc, "name", ""),
                                "id": "",
                                "arguments": str(getattr(fc, "args", "")),
                            })
                _emit_generic(
                    http,
                    sandbox_id,
                    "google-genai",
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    output_text=out,
                    tool_calls=tool_calls,
                    duration_ms=int((time.monotonic() - start) * 1000),
                )
            except Exception:
                pass
            return resp

        models.generate_content = wrapped

    models_cls.__init__ = patched_init
    return "google-genai"


def _patch_litellm(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        import litellm  # type: ignore
    except ImportError:
        return None
    if _is_patched("litellm"):
        return "litellm"

    original = litellm.completion

    def wrapped(*args, **kwargs):
        start = time.monotonic()
        resp = original(*args, **kwargs)
        try:
            info = _extract_openai(resp)  # LiteLLM normalizes to OpenAI shape
            _emit_generic(
                http,
                sandbox_id,
                "litellm",
                model=info["model"] or kwargs.get("model", ""),
                input_tokens=info["input_tokens"],
                output_tokens=info["output_tokens"],
                cache_tokens=info.get("cache_tokens", 0),
                reasoning_tokens=info.get("reasoning_tokens", 0),
                output_text=info.get("output_text", ""),
                tool_calls=info["tool_calls"],
                duration_ms=int((time.monotonic() - start) * 1000),
            )
        except Exception:
            pass
        return resp

    litellm.completion = wrapped
    return "litellm"


def _patch_claude_agent_sdk(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        import claude_agent_sdk as cas  # type: ignore
    except ImportError:
        return None
    if _is_patched("claude-agent-sdk"):
        return "claude-agent-sdk"

    query = getattr(cas, "query", None)
    if query is None:
        return None

    def wrapped(*args, **kwargs):
        start = time.monotonic()
        async def _inner():
            async for msg in query(*args, **kwargs):
                try:
                    # Every turn of the conversation emits a Message object. We
                    # can't easily extract per-turn tokens; emit one tool_use
                    # per tool-call-shaped payload we see.
                    payload = getattr(msg, "content", None) or msg
                    text = ""
                    tool_calls = []
                    if isinstance(payload, list):
                        for block in payload:
                            if getattr(block, "type", "") == "text":
                                text += getattr(block, "text", "")
                            elif getattr(block, "type", "") == "tool_use":
                                tool_calls.append({
                                    "name": getattr(block, "name", ""),
                                    "id": getattr(block, "id", ""),
                                    "arguments": str(getattr(block, "input", "")),
                                })
                    if text or tool_calls:
                        _emit_generic(
                            http,
                            sandbox_id,
                            "claude-agent-sdk",
                            model="claude-agent-sdk",
                            input_tokens=0,
                            output_tokens=0,
                            output_text=text,
                            tool_calls=tool_calls,
                            duration_ms=int((time.monotonic() - start) * 1000),
                        )
                except Exception:
                    pass
                yield msg

        return _inner()

    cas.query = wrapped  # type: ignore[attr-defined]
    return "claude-agent-sdk"


def _patch_dspy(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        import dspy  # type: ignore
    except ImportError:
        return None
    if _is_patched("dspy"):
        return "dspy"

    # DSPy calls its LM via `dspy.LM.__call__`; patch that to capture model
    # usage. Tolerant of version skew — if the attribute is missing we no-op.
    lm_cls = getattr(dspy, "LM", None)
    if lm_cls is None or not hasattr(lm_cls, "__call__"):
        return None
    original = lm_cls.__call__

    def wrapped(self, *args, **kwargs):
        start = time.monotonic()
        result = original(self, *args, **kwargs)
        try:
            _emit_generic(
                http,
                sandbox_id,
                "dspy",
                model=getattr(self, "model", "dspy"),
                input_tokens=0,
                output_tokens=0,
                duration_ms=int((time.monotonic() - start) * 1000),
                output_text=str(result)[:2000],
            )
        except Exception:
            pass
        return result

    lm_cls.__call__ = wrapped
    return "dspy"


def _patch_langchain(http: HTTPClient, sandbox_id: str) -> Optional[str]:
    try:
        from langchain_core.callbacks import BaseCallbackHandler  # type: ignore
        from langchain_core.globals import set_debug  # noqa: F401 — availability sentinel
        from langchain_core.tracers import BaseTracer  # type: ignore  # noqa: F401
    except ImportError:
        return None
    if _is_patched("langchain"):
        return "langchain"

    class KeystoneHandler(BaseCallbackHandler):  # pragma: no cover — installs only
        def __init__(self) -> None:
            super().__init__()
            self._starts: dict = {}

        def on_llm_start(self, serialized, prompts, *, run_id=None, **kwargs):
            self._starts[run_id] = time.monotonic()

        def on_llm_end(self, response, *, run_id=None, **kwargs):
            start = self._starts.pop(run_id, None)
            duration_ms = int((time.monotonic() - start) * 1000) if start else 0
            try:
                llm_output = getattr(response, "llm_output", {}) or {}
                usage = llm_output.get("token_usage") or {}
                model = llm_output.get("model_name") or llm_output.get("model") or ""
                generations = getattr(response, "generations", []) or []
                text = ""
                for gen_list in generations:
                    for gen in gen_list:
                        text += getattr(gen, "text", "") or ""
                _emit_generic(
                    http,
                    sandbox_id,
                    "langchain",
                    model=model,
                    input_tokens=usage.get("prompt_tokens", 0) or 0,
                    output_tokens=usage.get("completion_tokens", 0) or 0,
                    output_text=text,
                    duration_ms=duration_ms,
                )
            except Exception:
                pass

    # Install as a global callback so every new LLM run picks it up.
    try:
        from langchain_core.callbacks.manager import (  # type: ignore
            register_configure_hook,
        )
    except ImportError:
        return None

    register_configure_hook(lambda: KeystoneHandler(), True)
    return "langchain"
