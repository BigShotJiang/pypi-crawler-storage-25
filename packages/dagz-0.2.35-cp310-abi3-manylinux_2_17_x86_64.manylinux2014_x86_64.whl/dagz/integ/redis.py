import logging

from dagz.integ.db_config import DbConfig, TruncateResult
from dagz.sensor.base_session import BaseSession

logger = logging.getLogger('dagz.redis')


def setup_redis_worker_init(worker_num):
    try:
        from urllib.parse import parse_qs, urlencode, urlparse

        from django.conf import settings as django_settings  # type: ignore[import-not-found]
        from django.core.signals import setting_changed  # type: ignore[import-not-found]

        caches_conf = getattr(django_settings, 'CACHES', {})
        for conf in caches_conf.values():
            location = conf.get('LOCATION', '')
            if not location:
                continue
            parts = urlparse(location)
            query = parse_qs(parts.query)
            query['db'] = [str(worker_num)]
            conf['LOCATION'] = parts._replace(query=urlencode(query, doseq=True)).geturl()
        django_settings.CACHES = caches_conf
        setting_changed.send(sender=None, setting='CACHES', value=caches_conf, enter=True)
        logger.info(f'Worker {worker_num}: isolated Django cache backends')
    except Exception as exc:
        logger.warning(f'Worker {worker_num}: Django cache isolation failed: {exc}')


class RedisConfig(DbConfig):
    def __init__(self):
        super().__init__(__name__)

    def _resolve_db(self, kwargs):
        db_num = kwargs.get('db', 0)
        if self.should_reroute(db_num):
            kwargs['db'] = self.reroute_db(db_num)

    def install_hooks(self, session):
        _ = session
        _config = REDIS_CONFIG

        try:
            import redis.connection
        except ImportError:
            pass
        else:
            # Sync hooks
            self._orig_sync_conn = _orig_sync_conn = redis.connection.Connection.__init__
            self._orig_sync_unix = _orig_sync_unix = redis.connection.UnixDomainSocketConnection.__init__

            def override_sync_conn(self, *args, **kwargs):
                _config._resolve_db(kwargs)
                return _orig_sync_conn(self, *args, **kwargs)

            def override_sync_unix(self, *args, **kwargs):
                _config._resolve_db(kwargs)
                return _orig_sync_unix(self, *args, **kwargs)

            redis.connection.Connection.__init__ = override_sync_conn
            redis.connection.UnixDomainSocketConnection.__init__ = override_sync_unix

        # Async hooks
        try:
            import redis.asyncio.connection as async_conn
        except ImportError:
            pass
        else:
            self._orig_async_conn = _orig_async_conn = async_conn.Connection.__init__
            self._orig_async_unix = _orig_async_unix = async_conn.UnixDomainSocketConnection.__init__

            def override_async_conn(self, *args, **kwargs):
                _config._resolve_db(kwargs)
                return _orig_async_conn(self, *args, **kwargs)

            def override_async_unix(self, *args, **kwargs):
                _config._resolve_db(kwargs)
                return _orig_async_unix(self, *args, **kwargs)

            async_conn.Connection.__init__ = override_async_conn
            async_conn.UnixDomainSocketConnection.__init__ = override_async_unix

    def unhook(self):
        try:
            import redis.connection
        except ImportError:
            pass
        else:
            redis.connection.Connection.__init__ = self._orig_sync_conn
            redis.connection.UnixDomainSocketConnection.__init__ = self._orig_sync_unix

        try:
            import redis.asyncio.connection
        except ImportError:
            pass
        else:
            redis.asyncio.connection.Connection.__init__ = self._orig_async_conn
            redis.asyncio.connection.UnixDomainSocketConnection.__init__ = self._orig_async_unix

    def default_should_reroute(self, db_name):
        return True

    def truncate(self, db_name, **connect_kwargs) -> TruncateResult:
        return TruncateResult(db_exists=True, tables=[])

    def configure(self, *, rewrite_db_name, single_worker_disable=False, main_worker_bypass=False):
        super().configure(rewrite_db_name=rewrite_db_name, prepare=None,
                          should_reroute=self.default_should_reroute, main_worker_bypass=main_worker_bypass)

    def default_rewrite_db_name(self, db_name, session: BaseSession):
        if session.worker_num is None:
            logger.warning(f'Redis connection before session start, cannot reroute, db={db_name}')
            return db_name

        _ = db_name
        return session.worker_num % session.workers_per_node


REDIS_CONFIG = RedisConfig()
