from __future__ import annotations

import types

import builtins
import importlib.machinery
import inspect
import logging
import os
import sys
from typing import Dict

import importlib.util
from importlib.machinery import ModuleSpec

from dagz.sensor.install import install_hook
from dagz.sensor.instrument import FileInstrumentor
from dagz.sensor.base_session import BaseSession
from dagz.sensor.o3 import SpanResult, PyObjectProxy

logger = logging.getLogger('dagz.importer')

_orig_import_module = importlib.import_module
_orig_reload = importlib.reload
_orig_compile = builtins.compile

SKIP_EXCEPTIONS = ()

try:
    import _pytest.outcomes
    SKIP_EXCEPTIONS = _pytest.outcomes.Skipped
except ImportError:
    pass


class LoaderWrapper:
    """Wraps a loader to fire a callback after module execution."""
    def __init__(self, callback, *args):
        self.inner = None
        self.callback = callback
        self.args = args

    def create_module(self, spec):
        return self.inner.create_module(spec)

    def exec_module(self, module):
        result = self.inner.exec_module(module)
        install_hook(self.callback(*self.args))
        return result

    # Forward loader protocol methods used by importlib.resources, inspect, etc.
    def get_data(self, path):
        return self.inner.get_data(path)

    def get_filename(self, fullname=None):
        return self.inner.get_filename(fullname)

    def is_package(self, fullname):
        return self.inner.is_package(fullname)

    def get_source(self, fullname):
        return self.inner.get_source(fullname)

    def get_code(self, fullname):
        return self.inner.get_code(fullname)


class ModuleLoader(importlib.abc.Loader):
    def __init__(self, finder: 'MetaFinder', spec: ModuleSpec):
        self.finder = finder
        self.wrapped = spec.loader
        self.spec = spec
        self._code = None
        self.span = None
        finder.loaders_by_path[spec.origin] = self

    def _start_load(self, module_or_spec):
        session = self.finder.session
        self.span, module_hash = session.o3.start_module_load(module_or_spec)
        try:
            if self._code is None:
                instrumentor = FileInstrumentor(self.spec.origin, session, module_hash, with_pytest=False)
                self._code = instrumentor.load_instrument()

            if session.app_expecting_entry:
                # Detect entry point module
                if self.spec.name == '__main__':
                    is_entry = True
                elif session.app_expecting_entry.is_module:
                    is_entry = session.app_expecting_entry.entrypoint == self.spec.name
                else:
                    is_entry = session.app_expecting_entry.entrypoint == self.spec.origin

                if is_entry:
                    logger.debug(f'Entry module loaded: {self.spec.name} at {self.spec.origin}')
                    session.app_expecting_entry.entry_loader = self
                    session.app_expecting_entry = None
        except BaseException:
            # SyntaxError during load_instrument's compile (and any other failure
            # before exec_code runs) would otherwise leave the span at NOT_SET.
            self.span.result = SpanResult.ERROR
            raise

    def get_code(self, fullname):
        """Called by runpy when loading app entrypoint modules.
        This implements some of SourceLoader protocol without inheriting from it.
        """

        if not self.finder.session.app_expecting_entry:
            raise RuntimeError(f'get_code() without app expecting entry: {fullname}')

        self._start_load(self.spec)
        return self._code

    def finish_load(self, module):
        if self.span:
            self.span = None
            self.finder.session.o3.finish_module_load(module)

    def create_module(self, spec):
        return self.wrapped.create_module(spec)

    def exec_module(self, module: types.ModuleType):
        try:
            self._start_load(module)
            self.exec_code(self.span, module, self._code)
        finally:
            self.finish_load(module)

    def exec_code(self, span, module: types.ModuleType, code: types.CodeType):
        __tracebackhide__ = True  # Hide this frame from pytest tracebacks
        try:
            exec(code, module.__dict__)
            span.result = SpanResult.OK
        except SKIP_EXCEPTIONS:
            span.result = SpanResult.SKIPPED_IN_CODE
            raise
        except SystemExit as exc:
            # SystemExit is BaseException, not Exception - handle separately
            exit_code = exc.code if isinstance(exc.code, int) else (1 if exc.code else 0)
            span.result = SpanResult.OK if exit_code == 0 else SpanResult.ERROR
            raise
        except Exception as exc:
            span.result = SpanResult.ERROR
            logger.debug(f"Error executing module {module.__spec__.name}: {exc}")
            raise


class MetaFinder(importlib.abc.MetaPathFinder):
    def __init__(self, session: BaseSession):
        self.session = session
        self.loaders_by_path: Dict[str, ModuleLoader] = {}
        self.module_proxies = {}
        self._import_callbacks: Dict[str, LoaderWrapper] = {}

    def register_import_callback(self, module_name, callback, *args):
        if module_name in sys.modules:
            install_hook(callback(*args))
        else:
            self._import_callbacks[module_name] = LoaderWrapper(callback, *args)

    def wrap_loader(self, spec):
        # First instrumenting loader created - the compile hook is no longer needed.
        spec.loader = ModuleLoader(self, spec)

    def find_spec(self, fullname, path, target=None):
        for finder in sys.meta_path:
            if isinstance(finder, MetaFinder):
                # Skip self
                continue

            if hasattr(finder, 'find_spec'):
                spec = finder.find_spec(fullname, path, target)
            else:
                loader = finder.find_module(fullname, path)
                if loader:
                    spec = importlib.util.spec_from_loader(fullname, loader, origin=path)
                else:
                    continue

            if spec:
                if self.session.o3.should_instrument(spec):
                    self.wrap_loader(spec)

                wrapper = self._import_callbacks.pop(fullname, None)
                if wrapper:
                    wrapper.inner = spec.loader
                    spec.loader = wrapper

                return spec

        return None

    def install(self):
        def _wrap_import_module(name, package=None):
            # Wrap a dynamically imported module so we can track usage of non-callable module members.
            mod = _orig_import_module(name, package)

            self.session.o3.record_import(mod)

            caller = inspect.currentframe().f_back
            if '/_pytest' in caller.f_code.co_filename:
                # pytest dynamic import - part of test discovery, we handle these separately
                return mod

            mod_spec = getattr(mod, '__spec__', None)
            if mod_spec is not None and self.session.o3.should_instrument(mod_spec):
                origin = mod_spec.origin
                cached = self.module_proxies.get(origin)
                if cached is None or cached[0] is not mod:
                    # Re-wrap on module reload
                    module_proxy = self.session.o3.wrap_dynamic_import(mod)
                    self.module_proxies[origin] = (mod, module_proxy)
                else:
                    module_proxy = cached[1]
                return module_proxy
            return mod

        def _wrap_reload(module):
            # importlib.reload verifies object identity - we let it see our own proxy.
            if isinstance(module, PyObjectProxy):
                sys.modules[module.__name__] = module
            return _orig_reload(module)

        # Patch importlib.import_module and reload
        importlib.import_module = _wrap_import_module
        importlib.reload = _wrap_reload
        hooked_import_module = []
        for mod in list(sys.modules.values()):
            if mod is importlib:
                continue
            mod_name = getattr(mod, '__name__', None)
            if mod_name and mod_name.startswith('dagz'):
                continue

            for name, value in mod.__dict__.items():
                if value is _orig_import_module:
                    # Patch the import_module function in the module's namespace
                    logger.debug(f'patching {mod.__name__}.{name}', )
                    hooked_import_module.append((mod, name))
                    setattr(mod, name, _wrap_import_module)

        sys.meta_path.insert(0, self)

        self.session.o3.install_hooks(import_hook=self.session.o3.import_hook)

        def uninstall_hooks():
            self.session.o3.uninstall_hooks()
            importlib.import_module = _orig_import_module
            importlib.reload = _orig_reload
            sys.meta_path.remove(self)

            for (mod, name) in hooked_import_module:
                setattr(mod, name, _orig_import_module)

        return uninstall_hooks
