from __future__ import annotations

import logging
import os

import msgpack
import pytest

from dagz.pytest.vassal import Vassal
from dagz.sensor.install import uninstall_dagz_hooks, install_hook
from dagz.sensor.base_session import BaseSession
from dagz.sensor.o3 import SpanType, TestSessionO3
from dagz.sensor.o3_binding import CoverageMode
from dagz.pytest.worker import DAGZ_NODE_MUTEX, DAGZ_MAIN_WORKER

logger = logging.getLogger('dagz.plugin')
logger.setLevel(logging.DEBUG)


class DagzConfig:
    def __init__(self):
        self.thread_pools_size = 16
        self.disable_sensors = False


class TestSession(BaseSession):
    instance: 'TestSession'

    def __init__(self, early_config, cli_args):
        self.pluginmanager = early_config.pluginmanager
        self.log_handler = None
        self.worker = None
        self.collect_fixer = None
        self.port_manager = None
        TestSession.instance = self
        early_args = early_config.known_args_namespace
        if early_args.dagz_collect_fixup:
            from .vassal import CollectionFixer
            self.collect_fixer = CollectionFixer(early_config, cli_args)

        self.config = DagzConfig()
        self.config.threaded_workers = early_args.dagz_threaded_workers
        self.config.disable_sensors = early_args.dagz_disable_sensors

        in_pydevd = bool(early_config.pluginmanager.getplugin('teamcity.pytest_plugin'))
        if in_pydevd and early_args.dagz_capture is None:
            early_args.dagz_capture = False

        o3 = TestSessionO3(early_config=early_config, session_hooks=self)
        try:
            super().__init__(o3)
            self.pyc_tail_pytest = self._pyc_base + f"-pytest{pytest.__version__}.pyc"

            from dagz.pytest.log_handler import TestLogHandler
            self.log_handler = TestLogHandler(self)
            if (early_args.dagz_logs or  early_args.dagz_debug or early_args.dagz_trace or
                    os.environ.get('DAGZ_DEBUG') == '1' or os.environ.get('DAGZ_TRACE') == '1'):
                logging.root.setLevel(logging.DEBUG)

            allure_report_dir = getattr(early_args, 'allure_report_dir', None)
            junit_xml = early_args.xmlpath
            if junit_xml or allure_report_dir or in_pydevd:
                # These options need pytest_logstart/end hooks.
                # Otherwise we have no reason to send them from the worker.
                self.o3.forward_pytest_reports = True
                logger.info(f"Forwarding pytest reports to master: junitxml={junit_xml} allure={allure_report_dir} in_pydevd={in_pydevd}")
            else:
                logger.info("Pytest report forwarding disabled")

            if self.config.disable_sensors:
                logger.info("DAGZ: sensors disabled by --dagz-disable-sensors; running without meta_finder instrumentation and integ hooks")
            else:
                from dagz.pytest.pytest_module_loader import PytestMetaFinder
                meta_finder = PytestMetaFinder(self)
                from dagz.sensor.install import install_dagz_hooks
                install_dagz_hooks(self, meta_finder)

            self.o3.start_span(SpanType.PROGRAM_LOAD, 'load', coverage=CoverageMode.NAMED.value)

            self.prepare_session()

            self.o3.load(preload_all=early_args.dagz_preload)
        except BaseException:
            o3.close()
            raise

    def start_master(self):
        master_plugin = MasterSession(self)
        self.pluginmanager.register(master_plugin, 'dagz_session_master')
        # Disable terminal reporter in master
        self.pluginmanager.set_blocked('terminalreporter')
        return master_plugin

    def start_vassal(self):
        vassal = Vassal(self)
        if self.o3.distributed_coverage:
            # Start hooking subprocess only when the master is ready to accept coverage
            from dagz.integ.subproc import hook_subprocess
            install_hook(hook_subprocess())

        self.pluginmanager.register(vassal, 'dagz_vassal')
        return vassal

    @pytest.hookimpl(tryfirst=True)
    def pytest_configure(self, config):
        # Don't let the logger print logs to stdout. We do it ourselves.
        config.option.log_cli_level = 'FATAL'

        # Since we disable rerunfailures plugin, we need to add our this marker - otherwise
        # pytest will complain about unknown marker (with a warning). This is an issue with -Wall.
        config.addinivalue_line(
            "markers",
            "flaky(reruns=1, reruns_delay=0): mark test to re-run up "
            "to 'reruns' times. Add a delay of 'reruns_delay' seconds "
            "between re-runs.",
        )

        config.addinivalue_line(
            "markers",
            f"{DAGZ_MAIN_WORKER}: the test should run in dagz' main worker of any worker node.",
        )

        config.addinivalue_line(
            "markers",
            f"{DAGZ_NODE_MUTEX}: the test should not run in parallel on the same worker node.",
        )

        config.addinivalue_line(
            "markers",
            "dagz_worker(N): pin test to worker N.",
        )

        config.addinivalue_line(
            "markers",
            "dagz_stage(N): execution stage (default 50). Lower stages run first.",
        )

        config.addinivalue_line(
            "markers",
            "dagz_flaky(tail_run=bool): per-test override for master-side reschedule on failure. "
            "Defaults to the project-level `flaky_tail_run` setting.",
        )


class MasterSession:
    def __init__(self, test_session: TestSession):
        self.test_session = test_session
        self.pytest_session = None

    def pytest_collection(self, session):
        self.pytest_session = session
        try:
            session.testscollected, error_report_buf = self.test_session.o3.wait_for_vassal_collect()

            # Check if spawner had collection errors and replay them
            if error_report_buf:
                config = session.config
                reports = msgpack.unpackb(error_report_buf, raw=False)
                for data in reports:
                    report = config.hook.pytest_report_from_serializable(config=config, data=data)
                    # Replay via hook - this increments session.testsfailed automatically
                    config.hook.pytest_collectreport(report=report)
        except Exception as exc:
            logger.error(f"Error collecting tests: {exc}")
            pytest.exit(f"Error collecting tests: {exc}", 2)

        # Stop pytest from doing its own collection - we already have the collected items
        # in the vassal and will schedule them via O3
        return True

    def pytest_runtestloop(self, session):
        if session.testsfailed and not session.config.option.continue_on_collection_errors:
            raise session.Interrupted(
                "%d error%s during collection"
                % (session.testsfailed, "s" if session.testsfailed != 1 else "")
            )

        if session.config.option.collectonly:
            return True
        # Standard behavior end

        self.test_session.o3.run()
        return True

    # Master callback
    def master_item_finished(self, msg):
        # logger.info(f"Test finished, unpacking report: {name}")
        msg = msgpack.unpackb(msg, raw=False)
        config = self.pytest_session.config
        for report in msg['reports']:
            report = config.hook.pytest_report_from_serializable(
                config=config, data=report
            )

            # Hack to overcome serialization conversion of tuple->list
            report.location = tuple(report.location)
            if isinstance(report.longrepr, list):
                report.longrepr = tuple(report.longrepr)

            config.hook.pytest_runtest_logreport(report=report)

        config.hook.pytest_runtest_logfinish(nodeid=msg['nodeid'], location=msg['location'])

    @pytest.hookimpl(trylast=True)
    def pytest_unconfigure(self, config):
        self.test_session.log_handler.unregister()
        uninstall_dagz_hooks()

    @pytest.hookimpl(trylast=True)
    def pytest_sessionfinish(self, session, exitstatus):
        o3_exitstatus = self.test_session.o3.get_exit_status()
        if bool(o3_exitstatus) != bool(exitstatus):
            pytest_status_name = getattr(exitstatus, 'name', str(exitstatus))
            logger.info(f"Exit code mismatch: dagz exit code {o3_exitstatus}, pytest exit code {exitstatus} ({pytest_status_name}). "
                        f"Using dagz exit code for finalization.")
            session.exitstatus = o3_exitstatus
        else:
            logger.info(f'Exit code: dagz returned {o3_exitstatus}; exiting with pytest exit status {exitstatus}')
