"""Tests for AgentLint CLI entry point."""
from __future__ import annotations

import json
import os
from unittest.mock import patch

from click.testing import CliRunner

from agentlint.cli import _resolve_adapter, main


class TestMainCommand:
    def test_version_option(self) -> None:
        """--version should print the installed AgentLint version."""
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])

        assert result.exit_code == 0
        assert result.output.strip() == "agentlint 2.3.0"


class TestCheckCommand:
    def test_check_with_empty_input(self, tmp_path) -> None:
        """Empty JSON input should produce no violations and exit 0."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0

    def test_check_blocks_secrets(self, tmp_path) -> None:
        """Write with an API key should be blocked via deny protocol (exit 0)."""
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        # PreToolUse blocking uses exit 0 + hookSpecificOutput deny protocol
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "deny"
        assert "no-secrets" in parsed["hookSpecificOutput"]["permissionDecisionReason"]

    def test_check_passes_clean_code(self, tmp_path) -> None:
        """Write with clean code should pass (exit code 0)."""
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "hello.py",
                "content": "def hello():\n    return 'world'\n",
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0


class TestInitCommand:
    def test_init_creates_config(self, tmp_path) -> None:
        """init should create agentlint.yml in the project directory."""
        runner = CliRunner()
        result = runner.invoke(main, ["init", "--project-dir", str(tmp_path)])

        assert result.exit_code == 0
        config_path = tmp_path / "agentlint.yml"
        assert config_path.exists()
        assert "agentlint" in config_path.read_text().lower()

    def test_init_detects_universal(self, tmp_path) -> None:
        """init should always include universal pack."""
        runner = CliRunner()
        result = runner.invoke(main, ["init", "--project-dir", str(tmp_path)])

        assert result.exit_code == 0
        assert "universal" in result.output.lower()

    def test_init_team_key_enables_agentchute_without_persisting_secret(self, tmp_path) -> None:
        """--team-key should wire AgentChute config without writing the key to disk."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["init", "--project-dir", str(tmp_path), "--team-key", "ac_team_test_secret"],
        )

        assert result.exit_code == 0
        config_text = (tmp_path / "agentlint.yml").read_text()
        assert "agentchute:" in config_text
        assert "enabled: true" in config_text
        assert "ac_team_test_secret" not in config_text
        assert "export AGENTCHUTE_LICENSE_KEY=ac_team_test_secret" in result.output


class TestCheckErrorPaths:
    def test_invalid_event_value(self, tmp_path) -> None:
        """Invalid --event value should cause a ValueError."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "InvalidEvent", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code != 0

    def test_malformed_json_stdin(self, tmp_path) -> None:
        """Malformed JSON should not crash — treated as empty input."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="not json at all {{{",
        )
        assert result.exit_code == 0

    def test_binary_like_content(self, tmp_path) -> None:
        """Binary-like content in stdin should not crash."""
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "test.bin",
                "content": "\x00\x01\x02\x03binary content\xff\xfe",
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_missing_event_flag(self, tmp_path) -> None:
        """--event is required."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code != 0


class TestCheckNewEvents:
    """New v0.4.0 hook events pass through gracefully."""

    def test_user_prompt_submit_passthrough(self, tmp_path) -> None:
        payload = json.dumps({"prompt": "delete everything"})
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "UserPromptSubmit", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_subagent_stop_passthrough(self, tmp_path) -> None:
        payload = json.dumps({"subagent_output": "done"})
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SubagentStop", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_notification_passthrough(self, tmp_path) -> None:
        payload = json.dumps({"notification_type": "warning"})
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "Notification", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_session_end_passthrough(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SessionEnd", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0

    def test_pre_compact_passthrough(self, tmp_path) -> None:
        payload = json.dumps({"compact_source": "auto"})
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreCompact", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_post_tool_use_failure_passthrough(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PostToolUseFailure", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0

    def test_all_new_events_accept_empty_input(self, tmp_path) -> None:
        """Every new event should accept empty JSON input without crashing."""
        new_events = [
            "SessionEnd", "UserPromptSubmit", "SubagentStart", "SubagentStop",
            "Notification", "PreCompact", "PostToolUseFailure", "PermissionRequest",
            "ConfigChange", "WorktreeCreate", "WorktreeRemove", "TeammateIdle",
            "TaskCompleted",
        ]
        runner = CliRunner()
        for event in new_events:
            result = runner.invoke(
                main,
                ["check", "--event", event, "--project-dir", str(tmp_path)],
                input="{}",
            )
            assert result.exit_code == 0, f"Event {event} failed with exit code {result.exit_code}"


class TestCheckEdgeCases:
    def test_empty_stdin_check(self, tmp_path) -> None:
        """Empty stdin (EOFError) on check should not crash."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="",
        )
        assert result.exit_code == 0

    def test_project_dir_from_env(self, tmp_path, monkeypatch) -> None:
        """CLAUDE_PROJECT_DIR env var is used when --project-dir not provided."""
        monkeypatch.setenv("CLAUDE_PROJECT_DIR", str(tmp_path))
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse"],
            input="{}",
        )
        assert result.exit_code == 0

    def test_path_traversal_blocked(self, tmp_path) -> None:
        """File path outside project dir should be blocked in PostToolUse."""
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "/etc/passwd"},
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0


class TestListRulesCommand:
    def test_list_all_rules(self) -> None:
        """list-rules should output a table of all rules."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules"])
        assert result.exit_code == 0
        assert "no-secrets" in result.output
        assert "no-env-commit" in result.output
        assert "rules total" in result.output

    def test_list_rules_security_pack(self) -> None:
        """list-rules --pack security should show only security rules."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "security"])
        assert result.exit_code == 0
        assert "no-bash-file-write" in result.output
        assert "no-network-exfil" in result.output
        assert "7 rules total" in result.output

    def test_list_rules_autopilot_pack(self) -> None:
        """list-rules --pack autopilot should show only autopilot rules."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "autopilot"])
        assert result.exit_code == 0
        assert "cloud-resource-deletion" in result.output
        assert "network-firewall-guard" in result.output
        assert "docker-volume-guard" in result.output
        assert "18 rules total" in result.output

    def test_list_rules_universal_pack(self) -> None:
        """list-rules --pack universal should show only universal rules."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "universal"])
        assert result.exit_code == 0
        assert "no-secrets" in result.output
        assert "23 rules total" in result.output

    def test_list_rules_quality_pack(self) -> None:
        """list-rules --pack quality should show only quality rules."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "quality"])
        assert result.exit_code == 0
        assert "commit-message-format" in result.output
        assert "no-dead-imports" in result.output
        assert "no-error-handling-removal" in result.output
        assert "no-large-diff" in result.output
        assert "naming-conventions" in result.output
        assert "7 rules total" in result.output

    def test_list_rules_unknown_pack(self) -> None:
        """list-rules with unknown pack should show no rules."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "nonexistent"])
        assert result.exit_code == 0
        assert "No rules found" in result.output

    def test_list_rules_columns(self) -> None:
        """list-rules should show Rule ID, Pack, Event, Severity, Description columns."""
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules"])
        assert "Rule ID" in result.output
        assert "Pack" in result.output
        assert "Event" in result.output
        assert "Severity" in result.output
        assert "Description" in result.output

    def test_list_rules_includes_custom_rules(self, tmp_path) -> None:
        """list-rules should include custom rules from project config."""
        # Create custom rule
        rules_dir = tmp_path / "custom_rules"
        rules_dir.mkdir()
        (rules_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "\n"
            "class MyRule(Rule):\n"
            "    id = 'my-custom-rule'\n"
            "    description = 'A test custom rule'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'mypack'\n"
            "\n"
            "    def evaluate(self, context: RuleContext) -> list[Violation]:\n"
            "        return []\n"
        )
        # Create agentlint.yml with custom_rules_dir
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: custom_rules/\n"
        )

        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "my-custom-rule" in result.output
        assert "mypack" in result.output

    def test_list_rules_filter_custom_pack(self, tmp_path) -> None:
        """list-rules --pack mypack should show only custom rules with that pack."""
        rules_dir = tmp_path / "custom_rules"
        rules_dir.mkdir()
        (rules_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "\n"
            "class MyRule(Rule):\n"
            "    id = 'my-custom-rule'\n"
            "    description = 'A test custom rule'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'mypack'\n"
            "\n"
            "    def evaluate(self, context: RuleContext) -> list[Violation]:\n"
            "        return []\n"
        )
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: custom_rules/\n"
        )

        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "mypack", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "my-custom-rule" in result.output
        assert "1 rules total" in result.output
        # Built-in rules should not appear
        assert "no-secrets" not in result.output

    def test_list_rules_custom_rule_with_builtin_pack_name(self, tmp_path) -> None:
        """Custom rule with pack='universal' should appear in --pack universal."""
        rules_dir = tmp_path / "custom_rules"
        rules_dir.mkdir()
        (rules_dir / "extra_universal.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "\n"
            "class ExtraUniversal(Rule):\n"
            "    id = 'custom-extra-universal'\n"
            "    description = 'A custom rule in the universal pack'\n"
            "    severity = Severity.INFO\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'universal'\n"
            "\n"
            "    def evaluate(self, context: RuleContext) -> list[Violation]:\n"
            "        return []\n"
        )
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: custom_rules/\n"
        )

        runner = CliRunner()
        result = runner.invoke(main, ["list-rules", "--pack", "universal", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "custom-extra-universal" in result.output
        assert "no-secrets" in result.output  # built-in universal rules still present


class TestMonorepoCheck:
    def test_check_resolves_project_packs(self, tmp_path) -> None:
        """check should use project-specific packs when projects: is configured."""
        # Python pack has no-bare-except. Frontend doesn't.
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\n"
            "projects:\n  backend/:\n    packs: [universal, python]\n"
            "  frontend/:\n    packs: [universal, frontend]\n"
        )
        (tmp_path / "backend").mkdir()
        (tmp_path / "frontend").mkdir()

        runner = CliRunner()
        # Python rule should fire on backend file
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(tmp_path / "backend" / "app.py"),
                "content": "try:\n    pass\nexcept:\n    pass\n",
            },
        })
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0
        # no-bare-except is a python pack rule — should fire for backend/
        if result.output.strip():
            assert "no-bare-except" in result.output


class TestStatusCommand:
    def test_status_outputs_version_and_rules(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "AgentLint" in result.output
        assert "Rules:" in result.output
        assert "Packs:" in result.output

    def test_status_shows_pack_names(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])
        assert "universal" in result.output

    def test_status_excludes_orphaned_custom_rules(self, tmp_path) -> None:
        """status should not count custom rules whose pack isn't in packs: list."""
        rules_dir = tmp_path / "rules"
        rules_dir.mkdir()
        (rules_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "\n"
            "class MyRule(Rule):\n"
            "    id = 'orphan-rule'\n"
            "    description = 'Orphaned'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'fintech'\n"
            "\n"
            "    def evaluate(self, context: RuleContext) -> list[Violation]:\n"
            "        return []\n"
        )
        # fintech NOT in packs: list
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: rules/\n"
        )

        runner = CliRunner()
        result_without = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])

        # Now add fintech to packs
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\n  - fintech\ncustom_rules_dir: rules/\n"
        )
        result_with = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])

        # Extract rule counts
        import re
        count_without = int(re.search(r"Rules: (\d+) active", result_without.output).group(1))
        count_with = int(re.search(r"Rules: (\d+) active", result_with.output).group(1))
        assert count_with == count_without + 1


    def test_status_shows_project_packs(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\n"
            "projects:\n  frontend/:\n    packs: [universal, frontend]\n"
            "  backend/:\n    packs: [universal, python]\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])
        assert "Projects:" in result.output
        assert "frontend/" in result.output
        assert "backend/" in result.output

    def test_status_no_projects_no_section(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])
        assert "Projects:" not in result.output


class TestSyncCommand:
    def test_sync_dry_run_matches_agentchute_flush_dry_run(self, tmp_path, monkeypatch) -> None:
        queue_dir = tmp_path / "queue"
        monkeypatch.setenv("AGENTLINT_AGENTCHUTE_QUEUE_DIR", str(queue_dir))
        monkeypatch.setenv("AGENTCHUTE_LICENSE_KEY", "ac_team_test_x")
        monkeypatch.setenv("AGENTCHUTE_ENABLED", "true")

        runner = CliRunner()
        sync_result = runner.invoke(main, ["sync", "--dry-run"])
        flush_result = runner.invoke(main, ["agentchute", "flush", "--dry-run"])

        assert sync_result.exit_code == 0
        assert flush_result.exit_code == 0
        assert sync_result.output == flush_result.output
        assert "Would deliver" in sync_result.output

    def test_agentchute_status_outputs_queue_and_policy(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_AGENTCHUTE_QUEUE_DIR", str(tmp_path / "queue"))
        monkeypatch.setenv("AGENTLINT_AGENTCHUTE_POLICY_DIR", str(tmp_path / "policy"))
        monkeypatch.setenv("AGENTCHUTE_LICENSE_KEY", "ac_team_test_x")
        from agentlint.agentchute import policy
        from agentlint.agentchute import queue

        queue.enqueue_event(
            {"tool_name": "Bash"},
            session_key="s1",
            config=type("Cfg", (), {"agentchute": {"enabled": True}})(),
        )
        policy._policy_root().mkdir(parents=True, exist_ok=True)
        policy._policy_path().write_text(
            '{"version": 2, "updated_at": "today", "rules": []}',
            encoding="utf-8",
        )

        runner = CliRunner()
        result = runner.invoke(main, ["agentchute", "status"])

        assert result.exit_code == 0
        assert "Queue: 1 pending / 1 total" in result.output
        assert "Policy: cached" in result.output
        assert "Policy version: 2" in result.output

    def test_agentchute_flush_locked_and_aborted_messages(self) -> None:
        from agentlint.agentchute.queue import FlushResult

        runner = CliRunner()
        with patch("agentlint.agentchute.queue.flush_queue", return_value=FlushResult(locked=True)):
            result = runner.invoke(main, ["agentchute", "flush"])
        assert result.exit_code == 0
        assert "already running" in result.output

        with patch(
            "agentlint.agentchute.queue.flush_queue",
            return_value=FlushResult(aborted_reason="missing key"),
        ):
            result = runner.invoke(main, ["agentchute", "flush"])
        assert result.exit_code == 2
        assert "Flush aborted: missing key" in result.output

    def test_agentchute_policy_commands(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_AGENTCHUTE_POLICY_DIR", str(tmp_path))
        from agentlint.agentchute import policy
        from agentlint.agentchute.policy import PolicyRefreshResult

        runner = CliRunner()

        with patch(
            "agentlint.agentchute.policy.refresh_policy",
            return_value=PolicyRefreshResult(ok=False, error="bad token"),
        ):
            result = runner.invoke(main, ["agentchute", "refresh"])
        assert result.exit_code == 2
        assert "Policy refresh failed: bad token" in result.output

        with patch(
            "agentlint.agentchute.policy.refresh_policy",
            return_value=PolicyRefreshResult(ok=True, version=9),
        ):
            result = runner.invoke(main, ["agentchute", "refresh"])
        assert result.exit_code == 0
        assert "Policy cached: version 9" in result.output

        policy._policy_root().mkdir(parents=True, exist_ok=True)
        policy._policy_path().write_text(
            '{"version": 4, "required_packs": [{"name": "agentlint"}], "rules": [{"id": "r", "match": {"field": "tool_name", "operator": "equals", "value": "Bash"}}]}',
            encoding="utf-8",
        )
        result = runner.invoke(main, ["agentchute", "policy"])
        assert result.exit_code == 0
        assert "Policy version: 4" in result.output
        assert "Rules: 1 declarative" in result.output
        result = runner.invoke(main, ["agentchute", "policy", "--format", "json"])
        assert result.exit_code == 0
        assert '"version": 4' in result.output

    def test_agentchute_policy_missing_cache_exits_one(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_AGENTCHUTE_POLICY_DIR", str(tmp_path))
        runner = CliRunner()

        result = runner.invoke(main, ["agentchute", "policy"])

        assert result.exit_code == 1
        assert "No AgentChute policy cache found." in result.output


class TestDoctorCommand:
    def test_doctor_all_checks_pass(self, tmp_path) -> None:
        # Create config and hooks so checks pass
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")
        settings_dir = tmp_path / ".claude"
        settings_dir.mkdir()
        (settings_dir / "settings.json").write_text(
            json.dumps({"hooks": {"PreToolUse": [{"hooks": [{"command": "agentlint check"}]}]}})
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "All checks passed" in result.output

    def test_doctor_warns_missing_config(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "not found" in result.output

    def test_doctor_warns_missing_hooks(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "not installed" in result.output

    def test_doctor_checks_python_version(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "Python:" in result.output

    def test_doctor_checks_recordings_dir_when_enabled(self, tmp_path, monkeypatch) -> None:
        """doctor should check recordings dir when recording is enabled."""
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        rec_dir = tmp_path / "recordings"
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(rec_dir))
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")

        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "Recordings dir:" in result.output
        # Dir doesn't exist yet, should say "will be created"
        assert "will be created" in result.output

    def test_doctor_checks_recordings_dir_writable(self, tmp_path, monkeypatch) -> None:
        """doctor should report writable recordings dir."""
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        rec_dir = tmp_path / "recordings"
        rec_dir.mkdir()
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(rec_dir))
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")

        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "Recordings dir:" in result.output
        assert "writable" in result.output


    def test_doctor_validates_custom_rules_dir_exists(self, tmp_path) -> None:
        """doctor should warn when custom_rules_dir is configured but missing."""
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: nonexistent_rules/\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "directory not found" in result.output

    def test_doctor_warns_empty_custom_rules_dir(self, tmp_path) -> None:
        """doctor should warn when custom_rules_dir exists but has no .py files."""
        rules_dir = tmp_path / "rules"
        rules_dir.mkdir()
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: rules/\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "has no .py files" in result.output

    def test_doctor_warns_orphaned_custom_pack(self, tmp_path) -> None:
        """doctor should warn when custom rules have packs not in packs: list."""
        rules_dir = tmp_path / "rules"
        rules_dir.mkdir()
        (rules_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "\n"
            "class MyRule(Rule):\n"
            "    id = 'orphan-rule'\n"
            "    description = 'Orphaned'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'fintech'\n"
            "\n"
            "    def evaluate(self, context: RuleContext) -> list[Violation]:\n"
            "        return []\n"
        )
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncustom_rules_dir: rules/\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "fintech" in result.output
        assert "not in packs" in result.output

    def test_doctor_ok_when_custom_pack_in_packs_list(self, tmp_path) -> None:
        """doctor should not warn when custom pack is properly listed in packs:."""
        rules_dir = tmp_path / "rules"
        rules_dir.mkdir()
        (rules_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "\n"
            "class MyRule(Rule):\n"
            "    id = 'good-rule'\n"
            "    description = 'Properly configured'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'fintech'\n"
            "\n"
            "    def evaluate(self, context: RuleContext) -> list[Violation]:\n"
            "        return []\n"
        )
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\n  - fintech\ncustom_rules_dir: rules/\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "1 rule file(s)" in result.output
        assert "not in packs" not in result.output

    def test_doctor_suggests_cli_recipe(self, tmp_path, monkeypatch) -> None:
        """doctor should suggest CLI recipes when tools are in PATH."""
        import shutil
        original_which = shutil.which
        monkeypatch.setattr(shutil, "which", lambda cmd: "/usr/bin/ruff" if cmd == "ruff" else original_which(cmd))
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "CLI recipe: ruff found" in result.output

    def test_doctor_suggests_ruff_format_recipe(self, tmp_path, monkeypatch) -> None:
        """doctor should suggest ruff format alongside ruff check."""
        import shutil
        original_which = shutil.which
        monkeypatch.setattr(shutil, "which", lambda cmd: "/usr/bin/ruff" if cmd == "ruff" else original_which(cmd))
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "ruff check" in result.output
        assert "ruff format" in result.output

    def test_doctor_no_recipes_when_cli_configured(self, tmp_path, monkeypatch) -> None:
        """doctor should not suggest recipes when cli-integration is already configured."""
        import shutil
        monkeypatch.setattr(shutil, "which", lambda cmd: "/usr/bin/ruff")
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\nrules:\n  cli-integration:\n    commands:\n"
            "      - name: ruff\n        command: ruff check\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "CLI recipe" not in result.output

    def test_doctor_no_recipes_when_tool_missing(self, tmp_path, monkeypatch) -> None:
        """doctor should not suggest recipes when tools aren't installed."""
        import shutil
        monkeypatch.setattr(shutil, "which", lambda cmd: None)
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert "CLI recipe" not in result.output


class TestReportCommand:
    def test_report_outputs_summary(self) -> None:
        """report should output JSON with AgentLint session summary."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", "/tmp"],
            input="{}",
        )

        assert result.exit_code == 0
        assert "AgentLint" in result.output

    def test_empty_stdin_report(self) -> None:
        """Empty stdin (EOFError) on report should not crash."""
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", "/tmp"],
            input="",
        )
        assert result.exit_code == 0
        assert "AgentLint" in result.output

    def test_report_includes_session_tracked_files(self, tmp_path, monkeypatch) -> None:
        """Report should count files tracked during the session, not just git diff."""
        from agentlint.session import save_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-report-files")

        # Simulate session state with files_touched (as check command would populate)
        save_session({"files_touched": ["/project/a.py", "/project/b.py", "/project/c.py"]})

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", str(tmp_path)],
            input="{}",
        )

        assert result.exit_code == 0
        # Should show at least the 3 session-tracked files
        parsed = json.loads(result.output)
        assert "Files changed: 3" in parsed["systemMessage"]

    def test_check_tracks_files_touched_in_session(self, tmp_path, monkeypatch) -> None:
        """check should accumulate file paths in session state files_touched."""
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-track-files")

        # Create a file so the tool_input file_path resolves
        target = tmp_path / "test.py"
        target.write_text("x = 1\n")

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(target),
                "content": "x = 2\n",
            },
        })
        runner = CliRunner()
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )

        session = load_session()
        assert str(target) in session.get("files_touched", [])


class TestSubagentFieldMapping:
    """v0.8.0 — subagent field mapping in CLI."""

    def test_subagent_start_passthrough(self, tmp_path) -> None:
        """SubagentStart event should accept agent fields."""
        payload = json.dumps({
            "agent_type": "general-purpose",
            "agent_id": "abc-123",
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SubagentStart", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_subagent_stop_reads_last_assistant_message(self, tmp_path) -> None:
        """SubagentStop should read last_assistant_message field."""
        payload = json.dumps({
            "last_assistant_message": "I completed the task",
            "agent_type": "general-purpose",
            "agent_id": "abc-123",
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SubagentStop", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_subagent_stop_falls_back_to_subagent_output(self, tmp_path) -> None:
        """SubagentStop should fall back to subagent_output for backward compat."""
        payload = json.dumps({
            "subagent_output": "legacy field",
            "agent_type": "general-purpose",
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SubagentStop", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_subagent_stop_with_transcript_path(self, tmp_path) -> None:
        """SubagentStop should accept agent_transcript_path."""
        payload = json.dumps({
            "agent_transcript_path": "/tmp/transcript.jsonl",
            "agent_type": "general-purpose",
            "agent_id": "abc-123",
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SubagentStop", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

    def test_subagent_start_with_autopilot_returns_context(self, tmp_path) -> None:
        """SubagentStart with autopilot enabled should return additionalContext."""
        config_path = tmp_path / "agentlint.yml"
        config_path.write_text("stack: auto\npacks:\n  - universal\n  - autopilot\n")

        payload = json.dumps({
            "agent_type": "general-purpose",
            "agent_id": "abc-123",
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "SubagentStart", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert "hookSpecificOutput" in parsed
        assert parsed["hookSpecificOutput"]["hookEventName"] == "SubagentStart"
        assert "SAFETY NOTICE" in parsed["hookSpecificOutput"]["additionalContext"]


class TestReportCircuitBreaker:
    def test_report_shows_cb_activity(self, tmp_path, monkeypatch) -> None:
        """Report should include circuit breaker data from session."""
        from agentlint.session import save_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-cb-report")

        save_session({
            "circuit_breaker": {
                "no-destructive-commands": {
                    "fire_count": 5,
                    "state": "degraded",
                }
            }
        })

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert "Circuit Breaker" in parsed["systemMessage"]
        assert "no-destructive-commands" in parsed["systemMessage"]


class TestRecordingsCommands:
    def test_recordings_list_empty(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "list"])
        assert result.exit_code == 0
        assert "No recordings found" in result.output

    def test_recordings_list_shows_entries(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({"ts": 1.0, "event": "PreToolUse", "tool_name": "Bash"}, "test-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "list"])
        assert result.exit_code == 0
        assert "test-sess" in result.output
        assert "1 recording(s)" in result.output

    def test_recordings_show(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({
            "ts": 1710000000.0, "event": "PreToolUse",
            "tool_name": "Bash", "violations": [],
            "tool_summary": {"command": "ls -la", "file_path": None, "content_length": None},
        }, "show-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "show-sess"])
        assert result.exit_code == 0
        assert "PreToolUse" in result.output
        assert "Bash" in result.output
        assert "$ ls -la" in result.output

    def test_recordings_stats(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        for i in range(5):
            append_event({
                "ts": float(i), "event": "PreToolUse",
                "tool_name": "Bash", "violations": [],
            }, "stats-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "stats"])
        assert result.exit_code == 0
        assert "Bash" in result.output
        assert "Events: 5" in result.output

    def test_recordings_clear(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({"ts": 1.0}, "to-delete")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "clear"], input="y\n")
        assert result.exit_code == 0
        assert "Removed 1 recording(s)" in result.output

    def test_recordings_stats_empty(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "stats"])
        assert result.exit_code == 0
        assert "No recordings found" in result.output

    def test_recordings_show_unknown_key(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "nonexistent-key"])
        assert result.exit_code == 0
        assert "No recordings found" in result.output

    def test_recordings_show_agent_summary(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({
            "ts": 1710000000.0, "event": "PreToolUse",
            "tool_name": "Agent", "violations": [],
            "tool_summary": {
                "command": None, "file_path": None, "content_length": None,
                "subagent_type": "Explore", "description": "Find auth code",
            },
        }, "agent-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "agent-sess"])
        assert result.exit_code == 0
        assert "[Explore]" in result.output
        assert "Find auth code" in result.output

    def test_recordings_show_web_summary(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({
            "ts": 1710000000.0, "event": "PreToolUse",
            "tool_name": "WebSearch", "violations": [],
            "tool_summary": {
                "command": None, "file_path": None, "content_length": None,
                "query": "python asyncio tutorial",
            },
        }, "web-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "web-sess"])
        assert result.exit_code == 0
        assert "python asyncio tutorial" in result.output

    def test_recordings_show_violations_only(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        # Clean event
        append_event({
            "ts": 1.0, "event": "PreToolUse",
            "tool_name": "Bash", "violations": [],
            "tool_summary": {"command": "ls", "file_path": None, "content_length": None},
        }, "filter-sess")
        # Event with violation
        append_event({
            "ts": 2.0, "event": "PreToolUse",
            "tool_name": "Write", "violations": [{"rule_id": "no-secrets", "severity": "error"}],
            "tool_summary": {"command": None, "file_path": "/bad.py", "content_length": 100},
        }, "filter-sess")

        runner = CliRunner()
        # Without filter: both events shown
        result = runner.invoke(main, ["recordings", "show", "filter-sess"])
        assert "2 event(s) shown (2 total)" in result.output
        assert "Violation summary:" in result.output
        assert "no-secrets" in result.output

        # With --violations-only: only the violation event shown
        result = runner.invoke(main, ["recordings", "show", "--violations-only", "filter-sess"])
        assert "1 event(s) shown (2 total)" in result.output
        assert "Write" in result.output
        assert "$ ls" not in result.output

    def test_recordings_show_url_summary(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({
            "ts": 1710000000.0, "event": "PreToolUse",
            "tool_name": "WebFetch", "violations": [],
            "tool_summary": {
                "command": None, "file_path": None, "content_length": None,
                "url": "https://example.com/api/docs",
            },
        }, "url-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "url-sess"])
        assert result.exit_code == 0
        assert "https://example.com/api/docs" in result.output

    def test_recordings_show_notebook_summary(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({
            "ts": 1710000000.0, "event": "PreToolUse",
            "tool_name": "NotebookEdit", "violations": [],
            "tool_summary": {
                "command": None, "file_path": None, "content_length": None,
                "cell_index": 5,
            },
        }, "nb-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "nb-sess"])
        assert result.exit_code == 0
        assert "cell #5" in result.output

    def test_recordings_show_no_violation_summary_when_clean(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        from agentlint.recorder import append_event
        append_event({
            "ts": 1.0, "event": "PreToolUse",
            "tool_name": "Bash", "violations": [],
            "tool_summary": {"command": "ls", "file_path": None, "content_length": None},
        }, "clean-sess")

        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "show", "clean-sess"])
        assert "Violation summary:" not in result.output


class TestRecordingIntegration:
    """Integration tests: recording fires (or doesn't) during check/report."""

    def test_check_records_when_enabled(self, tmp_path, monkeypatch):
        """check with recording enabled should write a .jsonl file."""
        rec_dir = tmp_path / "recordings"
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(rec_dir))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "rec-integration-test")
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))

        payload = json.dumps({
            "tool_name": "Bash",
            "tool_input": {"command": "ls -la"},
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

        from agentlint.recorder import load_recording
        recording = load_recording("rec-integration-test")
        assert len(recording) == 1
        assert recording[0]["tool_name"] == "Bash"
        assert recording[0]["v"] == 1
        assert recording[0]["event"] == "PreToolUse"

    def test_check_does_not_record_when_disabled(self, tmp_path, monkeypatch):
        """check with recording disabled should NOT create any .jsonl files."""
        rec_dir = tmp_path / "recordings"
        monkeypatch.delenv("AGENTLINT_RECORDING", raising=False)
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(rec_dir))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "no-rec-test")
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))

        payload = json.dumps({
            "tool_name": "Bash",
            "tool_input": {"command": "echo hello"},
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0

        # No recording files should exist
        if rec_dir.exists():
            assert list(rec_dir.glob("*.jsonl")) == []

    def test_report_records_when_enabled(self, tmp_path, monkeypatch):
        """report with recording enabled should write a Stop event."""
        rec_dir = tmp_path / "recordings"
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(rec_dir))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "rec-report-test")
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0

        from agentlint.recorder import load_recording
        recording = load_recording("rec-report-test")
        assert len(recording) == 1
        assert recording[0]["event"] == "Stop"
        assert recording[0]["v"] == 1

    def test_check_recording_failure_does_not_crash(self, tmp_path, monkeypatch):
        """If recording write fails, check should still succeed."""
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        # Point to a non-writable path to force failure
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", "/dev/null/impossible")
        monkeypatch.setenv("CLAUDE_SESSION_ID", "fail-test")
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))

        payload = json.dumps({
            "tool_name": "Bash",
            "tool_input": {"command": "ls"},
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        # Must not crash — recording failure is swallowed
        assert result.exit_code == 0

    def test_report_recording_failure_does_not_crash(self, tmp_path, monkeypatch):
        """If recording write fails during report, report should still succeed."""
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", "/dev/null/impossible")
        monkeypatch.setenv("CLAUDE_SESSION_ID", "fail-report")
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0
        assert "AgentLint" in result.output


class TestSuppressCommand:
    def test_suppress_adds_to_session(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress")
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "drift-detector"])
        assert result.exit_code == 0
        assert "Suppressed 'drift-detector'" in result.output

    def test_suppress_list(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress-list")
        runner = CliRunner()
        runner.invoke(main, ["suppress", "drift-detector"])
        result = runner.invoke(main, ["suppress", "--list"])
        assert "drift-detector" in result.output

    def test_suppress_clear(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress-clear")
        runner = CliRunner()
        runner.invoke(main, ["suppress", "drift-detector"])
        result = runner.invoke(main, ["suppress", "--clear"])
        assert "cleared" in result.output.lower()
        result2 = runner.invoke(main, ["suppress", "--list"])
        assert "No rules suppressed" in result2.output

    def test_suppress_remove_single(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress-remove")
        runner = CliRunner()
        runner.invoke(main, ["suppress", "drift-detector"])
        runner.invoke(main, ["suppress", "max-file-size"])
        result = runner.invoke(main, ["suppress", "--remove", "drift-detector"])
        assert "Removed suppression" in result.output
        result2 = runner.invoke(main, ["suppress", "--list"])
        assert "drift-detector" not in result2.output
        assert "max-file-size" in result2.output

    def test_suppress_mutual_exclusion(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress-mutex")
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "drift-detector", "--list"])
        assert result.exit_code != 0

    def test_suppress_already_suppressed(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress-idem")
        runner = CliRunner()
        runner.invoke(main, ["suppress", "drift-detector"])
        result = runner.invoke(main, ["suppress", "drift-detector"])
        assert "already suppressed" in result.output

    def test_suppress_remove_nonexistent(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-suppress-remove-none")
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "--remove", "nonexistent-rule"])
        assert "is not suppressed" in result.output


class TestReportSummaryFlag:
    """v1.7.0 — report --summary CLI tests."""

    def test_summary_flag_text(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import save_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-summary-text")

        save_session({
            "violation_log": {
                "total_evaluations": 10,
                "total_blocked": 2,
                "total_warnings": 3,
                "total_info": 1,
                "rule_violations": {"no-secrets": 2, "max-file-size": 4},
            },
            "files_touched": ["a.py", "b.py"],
        })

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--summary", "--project-dir", str(tmp_path)],
        )
        assert result.exit_code == 0
        assert "AgentLint Session Summary" in result.output
        assert "10 evaluations" in result.output
        assert "Violations (6 total)" in result.output

    def test_summary_flag_json(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import save_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-summary-json")

        save_session({
            "violation_log": {
                "total_evaluations": 5,
                "total_blocked": 1,
                "total_warnings": 2,
                "total_info": 0,
                "rule_violations": {"no-secrets": 1},
            },
        })

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--summary", "--format", "json", "--project-dir", str(tmp_path)],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["evaluations"] == 5
        assert data["violations"]["blocked"] == 1

    def test_summary_empty_session(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-summary-empty")

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--summary", "--project-dir", str(tmp_path)],
        )
        assert result.exit_code == 0
        assert "AgentLint Session Summary" in result.output

    def test_summary_does_not_consume_stdin(self, tmp_path, monkeypatch) -> None:
        """--summary should not block on stdin."""
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-summary-stdin")

        runner = CliRunner()
        # No input= means empty stdin; should not hang
        result = runner.invoke(
            main,
            ["report", "--summary", "--project-dir", str(tmp_path)],
        )
        assert result.exit_code == 0

    def test_report_without_summary_still_works(self, tmp_path, monkeypatch) -> None:
        """Existing Stop hook path should be unchanged."""
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-no-summary")

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert "systemMessage" in parsed
        assert "continue" in parsed


class TestViolationLogTracking:
    """v1.7.0 — violation_log accumulation in check command."""

    def test_violation_log_accumulates(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-vlog-accumulate")

        runner = CliRunner()

        # First check — triggers no-secrets
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )

        session = load_session()
        vlog = session.get("violation_log", {})
        assert vlog["total_evaluations"] == 1
        assert vlog["total_blocked"] >= 1
        assert "no-secrets" in vlog["rule_violations"]

    def test_violation_log_clean_check(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-vlog-clean")

        runner = CliRunner()

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "hello.py",
                "content": "def hello():\n    return 'world'\n",
            },
        })
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )

        session = load_session()
        vlog = session.get("violation_log", {})
        assert vlog["total_evaluations"] == 1
        assert vlog["total_blocked"] == 0
        assert vlog["total_warnings"] == 0


class TestClaudeProjectDirFallback:
    """v1.8.0 — All CLI commands respect CLAUDE_PROJECT_DIR."""

    def test_doctor_uses_claude_project_dir(self, tmp_path, monkeypatch) -> None:
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        (tmp_path / ".claude").mkdir()
        (tmp_path / ".claude" / "settings.json").write_text('{"hooks":{}}')
        monkeypatch.setenv("CLAUDE_PROJECT_DIR", str(tmp_path))
        monkeypatch.chdir(tmp_path / ".claude")  # CWD is NOT project root

        runner = CliRunner()
        result = runner.invoke(main, ["doctor"])
        assert result.exit_code == 0
        assert "Config file: agentlint.yml found" in result.output

    def test_ci_uses_claude_project_dir(self, tmp_path, monkeypatch) -> None:
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        monkeypatch.setenv("CLAUDE_PROJECT_DIR", str(tmp_path))
        monkeypatch.chdir(tmp_path / "..")  # CWD is NOT project root

        runner = CliRunner()
        result = runner.invoke(main, ["ci"])
        # Should find config and not crash
        assert result.exit_code == 0

    def test_init_uses_claude_project_dir(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("CLAUDE_PROJECT_DIR", str(tmp_path))
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        monkeypatch.chdir(subdir)

        runner = CliRunner()
        result = runner.invoke(main, ["init"])
        assert result.exit_code == 0
        # Config should be created at CLAUDE_PROJECT_DIR, not CWD
        assert (tmp_path / "agentlint.yml").exists()


class TestListRulesMultiEvent:
    """v1.8.0 — list-rules shows all events per rule."""

    def test_list_rules_shows_all_events(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["list-rules"])
        assert result.exit_code == 0
        # Rules with PostToolUse should show PostToolUse
        assert "PostToolUse" in result.output
        # Rules with PreToolUse should show PreToolUse
        assert "PreToolUse" in result.output


class TestSetupDryRun:
    """v1.8.0 — setup --dry-run shows preview without writing."""

    def test_dry_run_shows_preview(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["setup", "--project-dir", str(tmp_path), "--dry-run"],
        )
        assert result.exit_code == 0
        assert "Dry run" in result.output
        assert "hooks" in result.output
        # Should NOT have created settings.json or agentlint.yml
        settings_file = tmp_path / ".claude" / "settings.json"
        assert not settings_file.exists()
        assert not (tmp_path / "agentlint.yml").exists()

    def test_setup_without_dry_run_still_writes(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["setup", "--project-dir", str(tmp_path)],
        )
        assert result.exit_code == 0
        assert "Installed" in result.output


class TestHookTiming:
    """v1.9.0 — Hook timing tracking in session state."""

    def test_timing_stored_in_session(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing")
        runner = CliRunner()
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        session = load_session()
        timing = session.get("_hook_timing", {})
        assert timing.get("count") == 1
        assert timing.get("total_ms", 0) > 0

    def test_timing_count_increments(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-inc")
        runner = CliRunner()
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        session = load_session()
        assert session["_hook_timing"]["count"] == 2

    def test_timing_total_ms_positive(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-ms")
        runner = CliRunner()
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        session = load_session()
        assert session["_hook_timing"]["total_ms"] > 0

    def test_summary_text_shows_timing(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import save_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-text")
        save_session({
            "violation_log": {
                "total_evaluations": 5,
                "total_blocked": 0,
                "total_warnings": 1,
                "total_info": 0,
                "rule_violations": {},
            },
            "_hook_timing": {"total_ms": 42.5, "count": 5},
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--summary", "--project-dir", str(tmp_path)],
        )
        assert "Hook latency" in result.output

    def test_summary_json_has_timing(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import save_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-json")
        save_session({
            "violation_log": {
                "total_evaluations": 3,
                "total_blocked": 0,
                "total_warnings": 0,
                "total_info": 0,
                "rule_violations": {},
            },
            "_hook_timing": {"total_ms": 15.0, "count": 3},
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--summary", "--format", "json", "--project-dir", str(tmp_path)],
        )
        data = json.loads(result.output)
        assert "hook_timing" in data
        assert data["hook_timing"]["count"] == 3

    def test_no_timing_empty_session(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-empty")
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "--summary", "--project-dir", str(tmp_path)],
        )
        assert result.exit_code == 0
        assert "Hook latency" not in result.output

    def test_timing_accumulates(self, tmp_path, monkeypatch) -> None:
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-accum")
        runner = CliRunner()
        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        session1 = load_session()
        ms_after_1 = session1["_hook_timing"]["total_ms"]

        runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input="{}",
        )
        session2 = load_session()
        ms_after_2 = session2["_hook_timing"]["total_ms"]
        assert ms_after_2 > ms_after_1

    def test_timing_no_affect_on_violations(self, tmp_path, monkeypatch) -> None:
        """Violations should still work correctly with timing tracking."""
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-timing-viol")
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0
        output = json.loads(result.output)
        # Should still produce deny/block decision for secrets
        hook_output = output.get("hookSpecificOutput", {})
        assert hook_output.get("permissionDecision") == "deny"


class TestInlineIgnoreIntegration:
    """v1.9.0 — Inline ignore directives through full check command."""

    def test_ignore_file_suppresses_via_check(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-ignore-file-int")

        target = tmp_path / "big.py"
        content = "# agentlint:ignore-file\n" + "line\n" * 600
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        assert result.exit_code == 0

    def test_ignore_specific_rule_via_check(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-ignore-rule-int")

        content = "# agentlint:ignore max-file-size\n" + "line\n" * 600
        target = tmp_path / "big.py"
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        assert result.exit_code == 0


class TestIgnorePathsIntegration:
    """v1.9.0 — ignore_paths through full check command."""

    def test_ignore_paths_skips_via_check(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-ignore-paths-int")

        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\nrules:\n  ignore_paths:\n    - '**/legacy/**'\n"
        )

        target = tmp_path / "legacy" / "old.py"
        target.parent.mkdir(parents=True, exist_ok=True)
        content = "line\n" * 600
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        # max-file-size would fire but ignore_paths skips the file
        assert result.exit_code == 0

    def test_allow_paths_skips_specific_rule(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-allow-paths-int")

        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\nrules:\n  max-file-size:\n    allow_paths:\n      - '**/big.py'\n"
        )

        target = tmp_path / "big.py"
        content = "line\n" * 600
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        assert result.exit_code == 0


class TestCombinedFeaturesIntegration:
    """v1.9.0 — Multiple features interacting."""

    def test_timing_plus_ignore_paths(self, tmp_path, monkeypatch) -> None:
        """Timing works even when ignore_paths skips rules."""
        from agentlint.session import load_session

        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-combined-1")

        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\nrules:\n  ignore_paths:\n    - '**/*.py'\n"
        )

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "app.py", "content": "x = 1\n"},
        })
        runner = CliRunner()
        runner.invoke(main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload)

        session = load_session()
        timing = session.get("_hook_timing", {})
        assert timing.get("count") == 1  # timing still tracked even if all rules skipped

    def test_pre_existing_large_file_plus_ignore(self, tmp_path, monkeypatch) -> None:
        """Both threshold-crossing AND ignore-file should independently suppress."""
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-combined-2")

        content = "# agentlint:ignore-file\n" + "line\n" * 600
        target = tmp_path / "big.py"
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        assert result.exit_code == 0

    def test_md_file_no_large_diff_via_check(self, tmp_path, monkeypatch) -> None:
        """Markdown file should not trigger no-large-diff through check command."""
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-combined-3")

        target = tmp_path / "SKILL.md"
        content = "line\n" * 500
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        assert result.exit_code == 0

    def test_future_import_no_violation_via_check(self, tmp_path, monkeypatch) -> None:
        """__future__ import should not fire no-dead-imports through check command."""
        monkeypatch.setenv("AGENTLINT_CACHE_DIR", str(tmp_path / "cache"))
        monkeypatch.setenv("CLAUDE_SESSION_ID", "test-combined-4")

        target = tmp_path / "app.py"
        content = "from __future__ import annotations\n\ndef foo(): pass\n"
        target.write_text(content)

        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": content},
        })
        runner = CliRunner()
        result = runner.invoke(
            main, ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)], input=payload,
        )
        assert result.exit_code == 0


class TestAdapterFlags:
    def test_check_with_cursor_adapter_blocks_secrets(self, tmp_path) -> None:
        """Cursor adapter should block secrets with Cursor hook format."""
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "preToolUse", "--adapter", "cursor", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 2  # Cursor uses exit 2 for blocking
        data = json.loads(result.output)
        assert data["permission"] == "deny"

    def test_check_with_cursor_format_override(self, tmp_path) -> None:
        """Explicit --format cursor_hooks should use Cursor formatter even with default adapter."""
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--format", "cursor_hooks", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 2
        data = json.loads(result.output)
        assert data["permission"] == "deny"

    def test_check_auto_detects_cursor_from_env(self, tmp_path, monkeypatch) -> None:
        """CURSOR_SESSION_ID env var should auto-select cursor adapter."""
        monkeypatch.setenv("CURSOR_SESSION_ID", "test-session-123")
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "preToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 2
        data = json.loads(result.output)
        assert data["permission"] == "deny"

    def test_check_unknown_adapter_errors(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--adapter", "unknown", "--project-dir", str(tmp_path)],
            input="{}",
        )
        assert result.exit_code != 0
        assert "Unknown adapter" in result.output


class TestSetupPlatformSubcommands:
    def test_setup_claude_creates_settings(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["setup", "claude", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "Installed" in result.output

        settings_file = tmp_path / ".claude" / "settings.json"
        assert settings_file.exists()

    def test_setup_cursor_creates_hooks_json(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["setup", "cursor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "Installed" in result.output

        hooks_file = tmp_path / ".cursor" / "hooks.json"
        assert hooks_file.exists()
        data = json.loads(hooks_file.read_text())
        assert data["version"] == 1
        assert "hooks" in data

    def test_setup_default_is_claude(self, tmp_path) -> None:
        """Backward compat: agentlint setup without platform defaults to claude."""
        runner = CliRunner()
        result = runner.invoke(main, ["setup", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0

        settings_file = tmp_path / ".claude" / "settings.json"
        assert settings_file.exists()

    def test_setup_unknown_platform_errors(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["setup", "unknown", "--project-dir", str(tmp_path)])
        assert result.exit_code != 0
        assert "Unknown platform" in result.output


class TestUninstallPlatformSubcommands:
    def test_uninstall_claude_removes_settings(self, tmp_path) -> None:
        runner = CliRunner()
        runner.invoke(main, ["setup", "claude", "--project-dir", str(tmp_path)])
        result = runner.invoke(main, ["uninstall", "claude", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert not (tmp_path / ".claude" / "settings.json").exists()

    def test_uninstall_cursor_removes_hooks(self, tmp_path) -> None:
        runner = CliRunner()
        runner.invoke(main, ["setup", "cursor", "--project-dir", str(tmp_path)])
        result = runner.invoke(main, ["uninstall", "cursor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert not (tmp_path / ".cursor" / "hooks.json").exists()

    def test_uninstall_default_is_claude(self, tmp_path) -> None:
        """Backward compat: agentlint uninstall without platform defaults to claude."""
        runner = CliRunner()
        runner.invoke(main, ["setup", "--project-dir", str(tmp_path)])
        result = runner.invoke(main, ["uninstall", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert not (tmp_path / ".claude" / "settings.json").exists()


class TestResolveAdapter:
    def test_auto_detect_kimi(self, monkeypatch) -> None:
        monkeypatch.setenv("KIMI_SESSION_ID", "kimi-123")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "kimi"

    def test_auto_detect_grok(self, monkeypatch) -> None:
        monkeypatch.setenv("GROK_PROJECT_DIR", "/grok")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "grok"

    def test_auto_detect_gemini(self, monkeypatch) -> None:
        monkeypatch.setenv("GEMINI_SESSION_ID", "gemini-123")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "gemini"

    def test_auto_detect_codex(self, monkeypatch) -> None:
        monkeypatch.setenv("CODEX_PROJECT_DIR", "/codex")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "codex"

    def test_auto_detect_continue(self, monkeypatch) -> None:
        monkeypatch.setenv("CONTINUE_SESSION_ID", "continue-123")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "continue"

    def test_auto_detect_openai(self, monkeypatch) -> None:
        monkeypatch.setenv("OPENAI_RUN_ID", "run-123")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "openai"

    def test_auto_detect_mcp(self, monkeypatch) -> None:
        monkeypatch.setenv("MCP_SESSION_ID", "mcp-123")
        adapter = _resolve_adapter()
        assert adapter.platform_name == "mcp"

    def test_explicit_adapter_overrides_env(self, monkeypatch) -> None:
        monkeypatch.setenv("KIMI_SESSION_ID", "kimi-123")
        adapter = _resolve_adapter("cursor")
        assert adapter.platform_name == "cursor"


class TestCheckFormatOverride:
    def test_format_claude_hooks_override(self, tmp_path) -> None:
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "config.py",
                "content": 'API_KEY = "sk_live_abc123def456ghi789"',
            },
        })
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path), "--format", "claude_hooks"],
            input=payload,
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_check_with_circuit_breaker(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text(
            "packs:\n  - universal\ncircuit_breaker:\n  max_violations: 10\n"
        )
        payload = json.dumps({"tool_name": "Write", "tool_input": {"file_path": "x.py", "content": "a = 1"}})
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0


class TestCheckCustomRules:
    def test_check_loads_custom_rules_dir(self, tmp_path) -> None:
        custom_dir = tmp_path / "custom_rules"
        custom_dir.mkdir()
        (custom_dir / "my_rule.py").write_text(
            "from agentlint.models import HookEvent, Rule, RuleContext, Severity, Violation\n"
            "class MyRule(Rule):\n"
            "    id = 'my-custom-rule'\n"
            "    description = 'Test'\n"
            "    severity = Severity.ERROR\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'custom'\n"
            "    def evaluate(self, ctx):\n"
            "        return [Violation(rule_id=self.id, message='Custom hit', severity=self.severity)]\n"
        )
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n  - custom\ncustom_rules_dir: custom_rules\n")
        payload = json.dumps({"tool_name": "Write", "tool_input": {"file_path": "x.py", "content": "a = 1"}})
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PreToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0
        assert "my-custom-rule" in result.output


class TestStatusVersionFallback:
    def test_status_version_fallback_on_exception(self, tmp_path, monkeypatch) -> None:
        import importlib.metadata
        monkeypatch.setattr(importlib.metadata, "version", lambda _pkg: (_ for _ in ()).throw(RuntimeError("boom")))
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "dev" in result.output


class TestDoctorBranches:
    def test_doctor_corrupted_cursor_hooks(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        (cursor_dir / "hooks.json").write_text("not json")
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0

    def test_doctor_cursor_hooks_only(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        (cursor_dir / "hooks.json").write_text(
            json.dumps({"hooks": {"preToolUse": [{"command": "agentlint check --event preToolUse --adapter cursor"}]}})
        )
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert ".cursor/hooks.json" in result.output

    def test_doctor_alt_config_found(self, tmp_path) -> None:
        (tmp_path / ".agentlint.yml").write_text("stack: auto\n")
        runner = CliRunner()
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "found (alternate name)" in result.output

    def test_doctor_both_hooks_installed(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text("stack: auto\n")
        runner = CliRunner()
        runner.invoke(main, ["setup", "claude", "--project-dir", str(tmp_path)])
        runner.invoke(main, ["setup", "cursor", "--project-dir", str(tmp_path)])
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "both Claude and Cursor" in result.output

    def test_doctor_cli_integration_not_found(self, tmp_path) -> None:
        (tmp_path / "agentlint.yml").write_text(
            "stack: auto\n"
            "rules:\n"
            "  cli-integration:\n"
            "    commands:\n"
            "      - name: fake-linter\n"
            "        command: definitely_not_a_real_binary_12345 {file.path}\n"
        )
        # Install claude hooks so doctor doesn't complain about missing hooks
        runner = CliRunner()
        runner.invoke(main, ["setup", "claude", "--project-dir", str(tmp_path)])
        result = runner.invoke(main, ["doctor", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "not found in PATH" in result.output


class TestRecordingsStats:
    def test_stats_with_last_n(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        # Create a recording file
        rec = tmp_path / "test-session.jsonl"
        rec.write_text(
            json.dumps({"event": "PreToolUse", "tool_name": "Write", "violations": [{"rule_id": "no-secrets"}]}) + "\n"
        )
        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "stats", "--last", "1"])
        assert result.exit_code == 0
        assert "Sessions:" in result.output
        assert "Top rules fired:" in result.output

    def test_stats_no_recordings(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setenv("AGENTLINT_RECORDING", "1")
        monkeypatch.setenv("AGENTLINT_RECORDINGS_DIR", str(tmp_path))
        runner = CliRunner()
        result = runner.invoke(main, ["recordings", "stats"])
        assert result.exit_code == 0
        assert "No recordings found" in result.output


class TestSuppressCommand:
    def _patch_cache(self, monkeypatch, tmp_path):
        import agentlint.session
        monkeypatch.setattr(agentlint.session, "_cache_dir", lambda: tmp_path)

    def test_suppress_no_args_shows_usage(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["suppress"])
        assert result.exit_code == 0
        assert "Usage:" in result.output

    def test_suppress_add_rule(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "my-rule"])
        assert result.exit_code == 0
        assert "Suppressed 'my-rule'" in result.output

    def test_suppress_list_empty(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "--list"])
        assert result.exit_code == 0
        assert "No rules suppressed" in result.output

    def test_suppress_list_with_rules(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["suppress", "rule-a"])
        result = runner.invoke(main, ["suppress", "--list"])
        assert result.exit_code == 0
        assert "rule-a" in result.output

    def test_suppress_clear(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["suppress", "rule-a"])
        result = runner.invoke(main, ["suppress", "--clear"])
        assert result.exit_code == 0
        assert "All suppressions cleared" in result.output

    def test_suppress_remove_existing(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["suppress", "rule-a"])
        result = runner.invoke(main, ["suppress", "--remove", "rule-a"])
        assert result.exit_code == 0
        assert "Removed suppression" in result.output

    def test_suppress_remove_nonexistent(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "--remove", "rule-x"])
        assert result.exit_code == 0
        assert "not suppressed" in result.output

    def test_suppress_duplicate(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        runner.invoke(main, ["suppress", "rule-a"])
        result = runner.invoke(main, ["suppress", "rule-a"])
        assert result.exit_code == 0
        assert "already suppressed" in result.output

    def test_suppress_mutually_exclusive(self, tmp_path, monkeypatch) -> None:
        self._patch_cache(monkeypatch, tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, ["suppress", "--list", "--clear"])
        assert result.exit_code != 0
        assert "mutually exclusive" in result.output


class TestUninstallUnknownPlatform:
    def test_uninstall_unknown_platform_errors(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "unknown", "--project-dir", str(tmp_path)])
        assert result.exit_code != 0
        assert "Unknown platform" in result.output


class TestCheckOSError:
    def test_check_handles_file_read_oserror(self, tmp_path, monkeypatch) -> None:
        """Line 230-231: OSError when reading file should be handled gracefully."""
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        target = tmp_path / "test.py"
        target.write_text("a = 1\n")
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": str(target), "content": "a = 1"},
        })
        real_open = open
        def fake_open(path, *args, **kwargs):
            if str(path) == str(target):
                raise OSError("boom")
            return real_open(path, *args, **kwargs)
        monkeypatch.setattr("builtins.open", fake_open)
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["check", "--event", "PostToolUse", "--project-dir", str(tmp_path)],
            input=payload,
        )
        assert result.exit_code == 0


class TestCiCustomRules:
    def test_ci_loads_custom_rules_dir(self, tmp_path, monkeypatch) -> None:
        """Line 364: ci command should load custom_rules_dir."""
        custom_dir = tmp_path / "custom_rules"
        custom_dir.mkdir()
        (custom_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "class MyRule(Rule):\n"
            "    id = 'my-ci-rule'\n"
            "    description = 'Test'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.PRE_TOOL_USE]\n"
            "    pack = 'custom'\n"
            "    def evaluate(self, ctx):\n"
            "        return [Violation(rule_id=self.id, message='CI hit', severity=self.severity)]\n"
        )
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n  - custom\ncustom_rules_dir: custom_rules\n")
        test_file = tmp_path / "test.py"
        test_file.write_text("a = 1\n")
        import agentlint.cli
        monkeypatch.setattr(agentlint.cli, "get_diff_files", lambda _pd, _dr: [str(test_file)])
        runner = CliRunner()
        result = runner.invoke(main, ["ci", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "my-ci-rule" in result.output

    def test_ci_skips_unreadable_files(self, tmp_path, monkeypatch) -> None:
        """Line 385-386: ci should skip files that raise OSError."""
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n")
        test_file = tmp_path / "test.py"
        test_file.write_text("a = 1\n")
        import agentlint.cli
        monkeypatch.setattr(agentlint.cli, "get_diff_files", lambda _pd, _dr: [str(test_file)])
        real_open = open
        def fake_open(path, *args, **kwargs):
            if str(path) == str(test_file):
                raise OSError("boom")
            return real_open(path, *args, **kwargs)
        monkeypatch.setattr("builtins.open", fake_open)
        runner = CliRunner()
        result = runner.invoke(main, ["ci", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0


class TestReportCustomRules:
    def test_report_loads_custom_rules_dir(self, tmp_path, monkeypatch) -> None:
        """Line 521: report command should load custom_rules_dir."""
        custom_dir = tmp_path / "custom_rules"
        custom_dir.mkdir()
        (custom_dir / "my_rule.py").write_text(
            "from agentlint.models import Rule, RuleContext, Violation, HookEvent, Severity\n"
            "class MyRule(Rule):\n"
            "    id = 'my-report-rule'\n"
            "    description = 'Test'\n"
            "    severity = Severity.WARNING\n"
            "    events = [HookEvent.STOP]\n"
            "    pack = 'custom'\n"
            "    def evaluate(self, ctx):\n"
            "        return [Violation(rule_id=self.id, message='Report hit', severity=self.severity)]\n"
        )
        (tmp_path / "agentlint.yml").write_text("packs:\n  - universal\n  - custom\ncustom_rules_dir: custom_rules\n")
        runner = CliRunner()
        result = runner.invoke(main, ["report", "--project-dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "my-report-rule" in result.output
