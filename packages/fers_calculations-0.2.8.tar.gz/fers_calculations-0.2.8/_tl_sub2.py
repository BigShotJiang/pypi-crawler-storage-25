import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L_total = 1000.0; P = 1000.0
N_sub = 10

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((12, 12))
    ea = E*A/L; l2=L*L; l3=l2*L
    k[0,0] = ea; k[6,6] = ea; k[0,6] = k[6,0] = -ea
    eiz = E*Iz
    k[1,1] = 12*eiz/l3; k[1,5]=k[5,1]=6*eiz/l2; k[1,7]=k[7,1]=-12*eiz/l3; k[1,11]=k[11,1]=6*eiz/l2
    k[5,5] = 4*eiz/L; k[5,7]=k[7,5]=-6*eiz/l2; k[5,11]=k[11,5]=2*eiz/L
    k[7,7] = 12*eiz/l3; k[7,11]=k[11,7]=-6*eiz/l2; k[11,11]=4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3; k[2,4]=k[4,2]=-6*eiy/l2; k[2,8]=k[8,2]=-12*eiy/l3; k[2,10]=k[10,2]=-6*eiy/l2
    k[4,4] = 4*eiy/L; k[4,8]=k[8,4]=6*eiy/l2; k[4,10]=k[10,4]=2*eiy/L
    k[8,8] = 12*eiy/l3; k[8,10]=k[10,8]=6*eiy/l2; k[10,10]=4*eiy/L
    gj = G*J/L
    k[3,3] = gj; k[9,9] = gj; k[3,9] = k[9,3] = -gj
    return k

def beam_kgeo_12(N, L):
    k = np.zeros((12, 12))
    p_l = N/L; pL = N*L
    k[0,0]=p_l; k[0,6]=-p_l; k[6,0]=-p_l; k[6,6]=p_l
    for (i1,i5,i7,i11) in [(1,5,7,11),(2,4,8,10)]:
        k[i1,i1]=6/5*p_l; k[i1,i5]=k[i5,i1]=pL/10; k[i1,i7]=k[i7,i1]=-6/5*p_l; k[i1,i11]=k[i11,i1]=pL/10
        k[i5,i5]=4/15*pL; k[i5,i7]=k[i7,i5]=-pL/10; k[i5,i11]=k[i11,i5]=2/15*pL
        k[i7,i7]=6/5*p_l; k[i7,i11]=k[i11,i7]=-pL/10; k[i11,i11]=4/15*pL
    return k

def build_T12(R):
    T = np.zeros((12, 12))
    for n in range(2):
        b = n*6
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
    return T

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

members_orig = [
    (R1, np.array([0,0,0.]), np.array([1000,0,0.])),
    (R2, np.array([1000,0,0.]), np.array([1000,1000,0.])),
    (R3, np.array([1000,1000,0.]), np.array([1000,1000,1000.])),
]

# Node layout: 3*N_sub+1 nodes
n_nodes = 3*N_sub + 1
ndof = n_nodes * 6
sub_elements = []

for m_idx, (R, p1, p2) in enumerate(members_orig):
    Ls = L_total / N_sub
    for s in range(N_sub):
        ni = m_idx * N_sub + s
        nj = m_idx * N_sub + s + 1
        sub_elements.append((R, ni, nj, Ls))

fixed_dofs = list(range(6))  # node 0 fully fixed
free_dofs = [i for i in range(ndof) if i not in fixed_dofs]

# Load at last node (3*N_sub), Fy = -P
F_full = np.zeros(ndof)
F_full[3*N_sub*6 + 1] = -P

orig_n2_id = N_sub
orig_n3_id = 2*N_sub
orig_n4_id = 3*N_sub

def get_axial_12(T, ni, nj, Ls, u_full):
    u_elem = np.zeros(12)
    for d in range(6):
        u_elem[d] = u_full[ni*6+d]
        u_elem[6+d] = u_full[nj*6+d]
    u_loc = T @ u_elem
    return E*A/Ls * (u_loc[6] - u_loc[0])

def assemble_K(u_full=None):
    K = np.zeros((ndof, ndof))
    for R, ni, nj, Ls in sub_elements:
        T = build_T12(R)
        kl = beam_k_local(E, G, A, Iy, Iz, J, Ls)
        kg = T.T @ kl @ T
        dofs_e = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
        for i in range(12):
            for j in range(12):
                K[dofs_e[i], dofs_e[j]] += kg[i, j]
        if u_full is not None:
            N_ax = get_axial_12(T, ni, nj, Ls, u_full)
            if abs(N_ax) > 1.0:
                kgl = beam_kgeo_12(N_ax, Ls)
                kgg = T.T @ kgl @ T
                for i in range(12):
                    for j in range(12):
                        K[dofs_e[i], dofs_e[j]] += kgg[i, j]
    return K

# First-order
K0 = assemble_K()
u_1st = np.zeros(ndof)
u_1st[free_dofs] = np.linalg.solve(K0[np.ix_(free_dofs, free_dofs)], F_full[free_dofs])
rx2 = u_1st[orig_n2_id*6+3]; dy4 = u_1st[orig_n4_id*6+1]; dz4 = u_1st[orig_n4_id*6+2]
print(f'1st-order ({N_sub} sub): rx_n2={rx2:.6f} dy_n4={dy4:.2f} dz_n4={dz4:.2f}')

# TL N-R with subdivision
n_steps = 20
u = np.zeros(ndof)
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    F_norm = max(np.linalg.norm(F_lam[free_dofs]), 1.0)
    for it in range(50):
        Kt = assemble_K(u)
        Kff = Kt[np.ix_(free_dofs, free_dofs)]
        r = Kff @ u[free_dofs] - F_lam[free_dofs]
        res = np.linalg.norm(r) / F_norm
        if res < tol:
            break
        du = np.linalg.solve(Kff, -r)
        u[free_dofs] += du
    if step in (1,5,10,20):
        rx = u[orig_n2_id*6+3]; dy = u[orig_n4_id*6+1]; dz = u[orig_n4_id*6+2]
        print(f'Step {step:2d}: rx={rx:.6f} dy4={dy:.2f} dz4={dz:.2f} res={res:.2e} it={it}')

rx = u[orig_n2_id*6+3]; dy = u[orig_n4_id*6+1]; dz = u[orig_n4_id*6+2]
Mx_gj = G*J/L_total * rx
Mx_arm = -P * (1000 + dz)
print(f'\nTL 2nd ({N_sub} sub): rx_n2={rx:.6f} dy4={dy:.2f} dz4={dz:.2f}')
print(f'Mx(GJ/L*rx)={Mx_gj:.0f}  Mx(arm)={Mx_arm:.0f}')
print(f'Expected: dy=-350, dz=347, Mx=-1347000')
