use serde::{Deserialize, Deserializer, Serialize};
use utoipa::ToSchema;

/// Which internal-force component a stiffness curve depends on.
#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, ToSchema)]
pub enum ForceComponent {
    /// Axial force (along member local-x / global-Z at supports)
    N,
    /// Shear force in local-y
    Vy,
    /// Shear force in local-z
    Vz,
    /// Torsion moment
    Mx,
    /// Bending moment about local-y
    My,
    /// Bending moment about local-z
    Mz,
}

impl ForceComponent {
    /// Index into a 6-element force array [N, Vy, Vz, Mx, My, Mz].
    pub fn index(self) -> usize {
        match self {
            ForceComponent::N => 0,
            ForceComponent::Vy => 1,
            ForceComponent::Vz => 2,
            ForceComponent::Mx => 3,
            ForceComponent::My => 4,
            ForceComponent::Mz => 5,
        }
    }
}

/// A spring stiffness that varies with an internal-force component.
///
/// `points` is a sorted list of `[force_value, stiffness]` pairs.
/// `depends_on` specifies which force component at the owning location
/// (support node or member end) drives the interpolation.
///
/// Backward compatibility: a bare JSON array `[[0,100],[50000,1e7]]` is
/// accepted and treated as `{ depends_on: "Vz", points: [...] }`.
#[derive(Debug, Serialize, Clone, ToSchema)]
pub struct StiffnessCurveConfig {
    /// Which force component the stiffness depends on.
    pub depends_on: ForceComponent,
    /// Sorted `[force_value, stiffness]` pairs (≥ 2 points, positive stiffness).
    pub points: Vec<[f64; 2]>,
}

impl<'de> Deserialize<'de> for StiffnessCurveConfig {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        use serde::de;

        #[derive(Deserialize)]
        struct Full {
            depends_on: ForceComponent,
            points: Vec<[f64; 2]>,
        }

        // Accept either a full object or a bare array of points.
        let value = serde_json::Value::deserialize(deserializer)?;
        if value.is_array() {
            // Legacy: bare array → default to Vz
            let points: Vec<[f64; 2]> =
                serde_json::from_value(value).map_err(de::Error::custom)?;
            Ok(StiffnessCurveConfig {
                depends_on: ForceComponent::Vz,
                points,
            })
        } else {
            let full: Full = serde_json::from_value(value).map_err(de::Error::custom)?;
            Ok(StiffnessCurveConfig {
                depends_on: full.depends_on,
                points: full.points,
            })
        }
    }
}

impl StiffnessCurveConfig {
    /// Linearly interpolate the curve at `force_value`.
    /// Values outside the range are clamped to the nearest boundary stiffness.
    pub fn interpolate(&self, force_value: f64) -> f64 {
        interpolate_stiffness_curve(&self.points, force_value)
    }

    /// Validate the curve data, returning a descriptive error on failure.
    pub fn validate(&self, owner_label: &str, axis_label: &str) -> Result<(), String> {
        validate_stiffness_curve(owner_label, axis_label, &self.points)
    }

    /// Normalize the force-axis (points\[i\]\[0\]) and stiffness-axis (points\[i\]\[1\]).
    pub fn normalize(&mut self, force_factor: f64, stiffness_factor: f64) {
        for point in &mut self.points {
            point[0] *= force_factor;
            point[1] *= stiffness_factor;
        }
    }
}

// ── Free functions (usable without a StiffnessCurveConfig) ──────────────────

/// Linearly interpolate a stiffness curve at the given force value.
/// `points` must have ≥ 2 entries sorted by ascending column 0.
/// Values outside the range are clamped.
pub fn interpolate_stiffness_curve(points: &[[f64; 2]], force_value: f64) -> f64 {
    debug_assert!(points.len() >= 2, "StiffnessCurve must have ≥2 points");

    if force_value <= points[0][0] {
        return points[0][1];
    }
    if force_value >= points[points.len() - 1][0] {
        return points[points.len() - 1][1];
    }
    for i in 0..points.len() - 1 {
        let (x0, y0) = (points[i][0], points[i][1]);
        let (x1, y1) = (points[i + 1][0], points[i + 1][1]);
        if force_value >= x0 && force_value <= x1 {
            let t = (force_value - x0) / (x1 - x0);
            return y0 + t * (y1 - y0);
        }
    }
    points[points.len() - 1][1]
}

/// Validate stiffness curve points.
pub fn validate_stiffness_curve(
    owner_label: &str,
    axis_label: &str,
    points: &[[f64; 2]],
) -> Result<(), String> {
    if points.len() < 2 {
        return Err(format!(
            "{} {} StiffnessCurve must have at least 2 points (got {}).",
            owner_label, axis_label, points.len()
        ));
    }
    for (i, pt) in points.iter().enumerate() {
        if pt[1] <= 0.0 {
            return Err(format!(
                "{} {} StiffnessCurve point {} has non-positive stiffness ({}).",
                owner_label, axis_label, i, pt[1]
            ));
        }
    }
    for i in 1..points.len() {
        if points[i][0] < points[i - 1][0] {
            return Err(format!(
                "{} {} StiffnessCurve points must be sorted ascending \
                 (point {} value={} < point {} value={}).",
                owner_label, axis_label, i, points[i][0], i - 1, points[i - 1][0]
            ));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deserialize_full_format() {
        let json = r#"{"depends_on":"Vz","points":[[0,1000],[50000,1000000]]}"#;
        let cfg: StiffnessCurveConfig = serde_json::from_str(json).unwrap();
        assert_eq!(cfg.depends_on, ForceComponent::Vz);
        assert_eq!(cfg.points.len(), 2);
    }

    #[test]
    fn deserialize_bare_array_legacy() {
        let json = r#"[[0,1000],[50000,1000000]]"#;
        let cfg: StiffnessCurveConfig = serde_json::from_str(json).unwrap();
        assert_eq!(cfg.depends_on, ForceComponent::Vz);
        assert_eq!(cfg.points.len(), 2);
        assert_eq!(cfg.points[0], [0.0, 1000.0]);
    }

    #[test]
    fn deserialize_support_condition_legacy_type() {
        let json = r#"{
            "condition_type": "StiffnessCurve",
            "stiffness": null,
            "stiffness_curve": [[0,7929],[2000,15775]]
        }"#;
        let cond: crate::models::supports::supportcondition::SupportCondition =
            serde_json::from_str(json).unwrap();
        assert!(matches!(
            cond.condition_type,
            crate::models::supports::supportconditiontype::SupportConditionType::Spring
        ));
        let curve = cond.stiffness_curve.unwrap();
        assert_eq!(curve.depends_on, ForceComponent::Vz);
        assert_eq!(curve.points.len(), 2);
    }
}
