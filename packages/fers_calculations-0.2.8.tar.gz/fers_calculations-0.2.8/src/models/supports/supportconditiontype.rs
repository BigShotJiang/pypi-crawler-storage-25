use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Debug, Serialize, Deserialize, Clone, ToSchema)]
pub enum SupportConditionType {
    Fixed,
    Free,
    #[serde(alias = "StiffnessCurve")]
    Spring,
    #[serde(alias = "Positive-only")]
    PositiveOnly,
    #[serde(alias = "Negative-only")]
    NegativeOnly,
}
