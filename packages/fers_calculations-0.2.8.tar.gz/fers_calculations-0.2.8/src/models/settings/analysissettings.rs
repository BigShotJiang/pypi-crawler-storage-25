use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub enum RigidStrategy {
    /// Serialize as "LINEAR_MPC"; also accept "Linear_MPC" and "linear_mpc"
    #[serde(alias = "Linear_MPC", alias = "linear_mpc")]
    LinearMpc,

    /// Serialize as "RIGID_MEMBER"; also accept "rigid_member"
    #[serde(alias = "rigid_member", alias = "Rigid_Member")]
    RigidMember,
}

/// Python:
/// class AnalysisOrder(Enum):
///     LINEAR = "LINEAR"
///     NONLINEAR = "NONLINEAR"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "UPPERCASE")]
pub enum AnalysisOrder {
    /// Serialize as "LINEAR"; also accept "Linear" / "linear"
    #[serde(alias = "Linear", alias = "linear")]
    Linear,

    /// Serialize as "NONLINEAR"; also accept "Nonlinear" / "nonlinear"
    #[serde(alias = "Nonlinear", alias = "nonlinear")]
    Nonlinear,
}

/// Controls the nonlinear formulation used for second-order analysis.
///
/// - **PDelta**: Total-Lagrangian P-Δ.  Geometric stiffness is added to the
///   original-frame elastic stiffness. This is the approach used by most
///   commercial solvers.  Accurate for moderate
///   rotations (< ~10°) but increasingly approximate for larger rotations.
///
/// - **Corotational** (default): Load-incremental corotational Newton-Raphson.
///   The element frame tracks the deformed geometry, so internal forces and
///   equilibrium are self-consistent even for large rotations (> 15°).
///   For small rotations the results converge to P-Delta.
///
/// Python:
/// class NonlinearMethod(Enum):
///     P_DELTA = "P_DELTA"
///     COROTATIONAL = "COROTATIONAL"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema, Default)]
#[serde(rename_all = "UPPERCASE")]
#[allow(non_camel_case_types)]
pub enum NonlinearMethod {
    #[serde(
        alias = "P_Delta",
        alias = "p_delta",
        alias = "PDelta",
        alias = "pdelta"
    )]
    P_DELTA,

    #[serde(
        alias = "Corotational",
        alias = "corotational",
        alias = "COROT",
        alias = "corot"
    )]
    #[default]
    COROTATIONAL,
}

/// Controls the geometric stiffness (K_g) formulation for P-Delta analysis.
///
/// - **Consistent** (default): Full Przemieniecki K_g with 6/5·P/L translation
///   terms, bending-axial rotational coupling (P/10, PL/15, PL/30), and
///   Wagner torsion.  Most accurate near buckling and for lateral-torsional
///   stability; captures both global P-Δ and local P-δ effects.
///
/// - **Simplified**: Diagonal P/L terms for transverse translations only —
///   no rotational coupling, no Wagner torsion.  Matches the P-Delta
///   formulation used by most commercial solvers.
///   Captures global P-Δ (sway) but not local P-δ (member curvature).
///
/// Python:
/// class PdeltaFormulation(Enum):
///     CONSISTENT = "CONSISTENT"
///     SIMPLIFIED = "SIMPLIFIED"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema, Default)]
#[serde(rename_all = "UPPERCASE")]
pub enum PdeltaFormulation {
    #[default]
    #[serde(alias = "Consistent", alias = "consistent")]
    Consistent,

    #[serde(alias = "Simplified", alias = "simplified", alias = "commercial")]
    Simplified,
}

/// Controls the P-Delta amplification strategy.
///
/// - **Full** (default): All 3D translational directions are amplified by
///   geometric stiffness.  Most rigorous for general 3D structures.
///
/// - **InPlaneOnly**: Automatically detects the structural plane from the
///   model's bounding box and suppresses P-Delta amplification in the
///   thinnest (out-of-plane) direction.  Matches the in-plane-only sway
///   approach used by most commercial solvers.
///   If the model is truly 3D (all three axes have similar extent), no
///   axis is suppressed.
///
/// Python:
/// class PdeltaMode(Enum):
///     FULL = "FULL"
///     IN_PLANE_ONLY = "IN_PLANE_ONLY"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema, Default)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum PdeltaMode {
    #[default]
    #[serde(alias = "Full", alias = "full")]
    Full,

    #[serde(
        alias = "InPlaneOnly",
        alias = "in_plane_only",
        alias = "commercial",
        // backward compatibility
        alias = "SkyCivCompat",
        alias = "skyciv_compat",
        alias = "SKYCIV_COMPAT",
        alias = "skyciv",
        alias = "SkyCiv"
    )]
    InPlaneOnly,
}

/// Python:
/// class Dimensionality(Enum):
///     TWO_DIMENSIONAL = "2D"
///     THREE_DIMENSIONAL = "3D"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub enum Dimensionality {
    /// Serialize as "2D"; also accept several common spellings
    #[serde(rename = "2D", alias = "2d")]
    TwoDimensional,

    /// Serialize as "3D"; also accept several common spellings
    #[serde(rename = "3D", alias = "3d")]
    ThreeDimensional,
}

#[derive(Debug, Serialize, Deserialize, ToSchema, Clone)]
pub struct AnalysisOptions {
    pub id: u32,
    pub solve_loadcases: bool,
    pub solver: String,
    pub tolerance: f64,
    pub max_iterations: Option<u32>,
    pub dimensionality: Dimensionality,
    pub order: AnalysisOrder,
    pub rigid_strategy: RigidStrategy,
    #[serde(default = "default_axial_slack")]
    pub axial_slack: f64,
    /// When false, forces shear deformation factor φ=0 (Euler-Bernoulli) for all elements.
    #[serde(default = "default_true")]
    pub include_shear_deformation: bool,
    /// When false, ignores warping constant Iw and uses pure GJ/L torsion for all elements.
    #[serde(default = "default_true")]
    pub include_warping: bool,
    /// Controls the nonlinear solver formulation (P_DELTA or COROTATIONAL).
    /// Only affects second-order (nonlinear) analysis.
    #[serde(default)]
    pub nonlinear_method: NonlinearMethod,
    /// Controls the geometric stiffness matrix formulation for P-Delta analysis.
    /// `Consistent` (default) uses full Przemieniecki K_g; `Simplified` uses
    /// P/L-only diagonal terms matching commercial solvers.
    #[serde(default)]
    pub pdelta_formulation: PdeltaFormulation,
    /// Global translational axes to exclude from P-Delta amplification.
    ///
    /// When a structure is near buckling in an out-of-plane direction,
    /// the consistent P-Delta amplification can produce forces that differ
    /// significantly from commercial solvers which
    /// typically only amplify in-plane sway.
    ///
    /// Set to `["Z"]` for in-plane racks/portal frames where Z is out-of-plane,
    /// or `["X","Z"]` to limit P-Delta to Y-sway only.  Empty (default) means
    /// all translational directions are amplified.
    ///
    /// Maps to global DOFs: "X"→0,7  "Y"→1,8  "Z"→2,9  per element.
    #[serde(default)]
    pub pdelta_suppress_axes: Vec<String>,
    /// High-level P-Delta strategy.  `Full` (default) amplifies all directions.
    /// `InPlaneOnly` auto-detects the out-of-plane axis from the model's
    /// bounding box and suppresses it, matching commercial solver behavior.
    /// Overrides `pdelta_suppress_axes` when set to `InPlaneOnly`.
    #[serde(default)]
    pub pdelta_mode: PdeltaMode,
}

fn default_true() -> bool {
    true
}

fn default_axial_slack() -> f64 {
    1.0e-3
}
