use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, ToSchema, Debug, Clone)]
pub struct Section {
    pub id: u32,
    pub name: String,
    pub material: u32,
    pub h: Option<f64>,
    pub b: Option<f64>,
    pub i_y: f64,
    pub i_z: f64,
    pub j: f64,
    pub area: f64,
    pub shape_path: Option<u32>,
    /// Warping constant (m⁶). None = no warping (pure St. Venant torsion).
    #[serde(default)]
    pub i_w: Option<f64>,
    /// Shear center Y-coordinate relative to centroid (m).
    #[serde(default)]
    pub y_s: Option<f64>,
    /// Shear center Z-coordinate relative to centroid (m).
    #[serde(default)]
    pub z_s: Option<f64>,
    /// Wagner coefficient for lateral-torsional buckling.
    #[serde(default)]
    pub wagner_coeff: Option<f64>,
    /// Effective shear area in Y-direction (m²). None = no shear deformation (Euler-Bernoulli).
    #[serde(default)]
    pub a_sy: Option<f64>,
    /// Effective shear area in Z-direction (m²). None = no shear deformation (Euler-Bernoulli).
    #[serde(default)]
    pub a_sz: Option<f64>,
}
