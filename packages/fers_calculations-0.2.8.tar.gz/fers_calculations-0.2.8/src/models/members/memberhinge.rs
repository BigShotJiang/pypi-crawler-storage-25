use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::models::stiffness_curve::StiffnessCurveConfig;

#[derive(Debug, Serialize, Deserialize, ToSchema, Clone)]
pub struct MemberHinge {
    pub id: u32,
    pub hinge_type: String,
    pub translational_release_vx: Option<f64>,
    pub translational_release_vy: Option<f64>,
    pub translational_release_vz: Option<f64>,
    pub rotational_release_mx: Option<f64>,
    pub rotational_release_my: Option<f64>,
    pub rotational_release_mz: Option<f64>,
    #[serde(default)]
    pub rotational_release_warp: Option<f64>,
    pub max_tension_vx: Option<f64>,
    pub max_tension_vy: Option<f64>,
    pub max_tension_vz: Option<f64>,
    pub max_moment_mx: Option<f64>,
    pub max_moment_my: Option<f64>,
    pub max_moment_mz: Option<f64>,
    #[serde(default)]
    pub max_bimoment_warp: Option<f64>,
    /// Optional load-dependent stiffness curves for each DOF.
    /// When present, overrides the constant release stiffness for that DOF.
    /// The curve's `depends_on` field specifies which member-end force
    /// component drives the interpolation.
    #[serde(default)]
    pub stiffness_curve_vx: Option<StiffnessCurveConfig>,
    #[serde(default)]
    pub stiffness_curve_vy: Option<StiffnessCurveConfig>,
    #[serde(default)]
    pub stiffness_curve_vz: Option<StiffnessCurveConfig>,
    #[serde(default)]
    pub stiffness_curve_mx: Option<StiffnessCurveConfig>,
    #[serde(default)]
    pub stiffness_curve_my: Option<StiffnessCurveConfig>,
    #[serde(default)]
    pub stiffness_curve_mz: Option<StiffnessCurveConfig>,
}

impl MemberHinge {
    /// Returns `true` if any DOF has a load-dependent stiffness curve.
    pub fn has_curve(&self) -> bool {
        self.stiffness_curve_vx.is_some()
            || self.stiffness_curve_vy.is_some()
            || self.stiffness_curve_vz.is_some()
            || self.stiffness_curve_mx.is_some()
            || self.stiffness_curve_my.is_some()
            || self.stiffness_curve_mz.is_some()
    }

    /// Get the stiffness curve for a DOF by index (0=vx, 1=vy, 2=vz, 3=mx, 4=my, 5=mz).
    pub fn curve_for_dof(&self, dof_index: usize) -> Option<&StiffnessCurveConfig> {
        match dof_index {
            0 => self.stiffness_curve_vx.as_ref(),
            1 => self.stiffness_curve_vy.as_ref(),
            2 => self.stiffness_curve_vz.as_ref(),
            3 => self.stiffness_curve_mx.as_ref(),
            4 => self.stiffness_curve_my.as_ref(),
            5 => self.stiffness_curve_mz.as_ref(),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub enum AxisMode {
    Rigid,       // exact constraint (use elimination)
    Release,     // perfect release (no K contribution)
    Spring(f64), // finite stiffness (add connector term)
}
