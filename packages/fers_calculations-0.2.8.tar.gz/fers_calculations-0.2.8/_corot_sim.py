import numpy as np
from scipy.spatial.transform import Rotation

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L = 1000.0; P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((14, 14))
    ea_l = E*A/L
    k[0,0] = ea_l; k[7,7] = ea_l; k[0,7] = k[7,0] = -ea_l
    eiz = E*Iz; l2=L*L; l3=l2*L
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,8] = k[8,1] = -12*eiz/l3; k[1,12] = k[12,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,8] = k[8,5] = -6*eiz/l2
    k[5,12] = k[12,5] = 2*eiz/L
    k[8,8] = 12*eiz/l3;  k[8,12] = k[12,8] = -6*eiz/l2
    k[12,12] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,9] = k[9,2] = -12*eiy/l3; k[2,11] = k[11,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,9] = k[9,4] = 6*eiy/l2
    k[4,11] = k[11,4] = 2*eiy/L
    k[9,9] = 12*eiy/l3;  k[9,11] = k[11,9] = 6*eiy/l2
    k[11,11] = 4*eiy/L
    gj_l = G*J/L
    k[3,3] = gj_l; k[10,10] = gj_l; k[3,10] = k[10,3] = -gj_l
    k[6,6] = 1e-6; k[13,13] = 1e-6
    return k

def build_T(R):
    T = np.zeros((14, 14))
    for node in range(2):
        b = node * 7
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
        T[b+6, b+6] = 1.0
    return T

# Rotation matrices (same as FERS)
R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

# Member connectivity: (R_orig, node1_start_dof, node2_start_dof, p1_orig, p2_orig)
members = [
    (R1, np.array([0,0,0.]),    np.array([1000,0,0.])),     # member 1: X-axis
    (R2, np.array([1000,0,0.]), np.array([1000,1000,0.])),   # member 2: Y-axis
    (R3, np.array([1000,1000,0.]), np.array([1000,1000,1000.])),  # member 3: Z-axis
]
dof_map = [(list(range(0,7)), list(range(7,14))),
           (list(range(7,14)), list(range(14,21))),
           (list(range(14,21)), list(range(21,28)))]

ndof = 28; free = list(range(7, 28))
F_full = np.zeros(ndof); F_full[22] = -P
k_local = beam_k_local(E, G, A, Iy, Iz, J, L)

def rodrigues(v_from, v_to):
    """Rotation matrix from v_from to v_to via Rodrigues"""
    c = v_from @ v_to
    s_vec = np.cross(v_from, v_to)
    s = np.linalg.norm(s_vec)
    if s < 1e-12:
        return np.eye(3) if c > 0 else -np.eye(3)
    k = s_vec / s
    K = np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3) + K*s + K@K*(1-c)

def extract_corot_deformations(R_orig, p1_orig, p2_orig, u_mem):
    """Extract corotational deformations for a member"""
    l_orig = np.linalg.norm(p2_orig - p1_orig)
    x_orig = (p2_orig - p1_orig) / l_orig
    
    p1_def = p1_orig + u_mem[0:3]
    p2_def = p2_orig + u_mem[7:10]
    l_def = np.linalg.norm(p2_def - p1_def)
    x_def = (p2_def - p1_def) / l_def
    
    # R_chord: rotation from x_orig to x_def
    R_chord = rodrigues(x_orig, x_def)
    # R_def = R_orig * R_chord^T (maps global -> deformed local)
    R_def = R_orig @ R_chord.T
    T_def = build_T(R_def)
    
    # Rigid body rotation vector (in global coords)
    omega = Rotation.from_matrix(R_chord).as_rotvec()
    
    # Deformational rotations
    theta1_global = u_mem[3:6]
    theta2_global = u_mem[10:13]
    theta1_def_global = theta1_global - omega
    theta2_def_global = theta2_global - omega
    theta1_def_local = R_def @ theta1_def_global
    theta2_def_local = R_def @ theta2_def_global
    
    d_local = np.zeros(14)
    d_local[3:6] = theta1_def_local
    d_local[6] = u_mem[6]  # warping
    d_local[7] = l_def - l_orig  # axial deformation
    d_local[10:13] = theta2_def_local
    d_local[13] = u_mem[13]  # warping
    
    return d_local, T_def

def assemble_corot_Fint(u_full):
    """Corotational internal forces"""
    f_int = np.zeros(ndof)
    for (R_orig, p1, p2), (d1, d2) in zip(members, dof_map):
        u_mem = np.zeros(14)
        for i in range(7):
            u_mem[i] = u_full[d1[i]]
            u_mem[7+i] = u_full[d2[i]]
        d_local, T_def = extract_corot_deformations(R_orig, p1, p2, u_mem)
        f_local = k_local @ d_local
        f_global = T_def.T @ f_local
        for i in range(7):
            f_int[d1[i]] += f_global[i]
            f_int[d2[i]] += f_global[7+i]
    return f_int

def assemble_K_elastic(u_full=None):
    """K_elastic in original frame (tangent approximation)"""
    K = np.zeros((ndof, ndof))
    for (R_orig, _, _), (d1, d2) in zip(members, dof_map):
        T = build_T(R_orig)
        kg = T.T @ k_local @ T
        dofs = d1 + d2
        for i in range(14):
            for j in range(14):
                K[dofs[i], dofs[j]] += kg[i, j]
    return K

# First-order solution for reference
K0 = assemble_K_elastic()
u_1st = np.zeros(ndof)
u_1st[free] = np.linalg.solve(K0[np.ix_(free, free)], F_full[free])
print(f'First-order: rx_n2={u_1st[10]:.6f} dy_n4={u_1st[22]:.4f} dz_n4={u_1st[23]:.4f}')

# Corotational N-R with K_elastic tangent
n_steps = 20
u = np.zeros(ndof)
K_tangent = assemble_K_elastic()
K_ff = K_tangent[np.ix_(free, free)]
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    F_norm = max(np.linalg.norm(F_lam[free]), 1.0)
    
    for it in range(50):
        f_int = assemble_corot_Fint(u)
        r = f_int[free] - F_lam[free]  # note: support DOFs are zero in u, so f_int at supports is the reaction
        res = np.linalg.norm(r) / F_norm
        if res < tol:
            break
        du = np.linalg.solve(K_ff, -r)
        u[free] += du
    
    if step in (1,2,3,5,10,15,20):
        Mx_react = -f_int[3]  # reaction at node 1
        print(f'Step {step:2d} (lam={lam:.2f}): rx_n2={u[10]:.6f} dy_n4={u[22]:.4f} dz_n4={u[23]:.4f} Mx={Mx_react:.0f} res={res:.2e} iter={it}')

print(f'\nCorot 2nd-order: rx_n2={u[10]:.6f} dy_n4={u[22]:.4f} dz_n4={u[23]:.4f}')
Mx = G*J/L*u[10]
print(f'Mx = GJ/L * rx_n2 = {Mx:.0f} N.mm')
print(f'Mx via reaction = {-assemble_corot_Fint(u)[3]:.0f} N.mm')

# Expected: SkyCiv dy_n4=-350.2mm, dz_n4=347.3mm, Mx=-1,347,000 N.mm
