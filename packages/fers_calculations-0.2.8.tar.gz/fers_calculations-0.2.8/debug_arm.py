import json, math, numpy as np

# Arm geometry
L = 1200.0
E = 210000.0
I_y = 918305.0
I_z = 215974.0
A = 1034.0
J = 96028.0
G = 80769.0
EIy = E * I_y
EIz = E * I_z

# Build 12x12 local stiffness (standard Euler-Bernoulli)
K = np.zeros((12, 12))

# Axial: DOF 0,6
K[0, 0] = EA = E * A / L
K[6, 6] = EA
K[0, 6] = K[6, 0] = -EA

# Torsion: DOF 3,9
GJ = G * J / L
K[3, 3] = K[9, 9] = GJ
K[3, 9] = K[9, 3] = -GJ

a = 12 * EIy / L**3
b = 6 * EIy / L**2
c = 4 * EIy / L
d = 2 * EIy / L
dy_idx = [2, 4, 8, 10]
dy_k = np.array([[a, b, -a, b], [b, c, -b, d], [-a, -b, a, -b], [b, d, -b, c]])
for i, ii in enumerate(dy_idx):
    for j, jj in enumerate(dy_idx):
        K[ii, jj] += dy_k[i, j]

# Bending about z (deflection in local y): DOFs [1(uy_A), 5(rz_A), 7(uy_B), 11(rz_B)]
# Sign convention: bending about z with uy deflection
a2 = 12 * EIz / L**3
b2 = 6 * EIz / L**2
c2 = 4 * EIz / L
d2 = 2 * EIz / L
dz_idx = [1, 5, 7, 11]
dz_k = np.array(
    [[a2, -b2, -a2, -b2], [-b2, c2, b2, d2], [-a2, b2, a2, b2], [-b2, d2, b2, c2]]
)
for i, ii in enumerate(dz_idx):
    for j, jj in enumerate(dz_idx):
        K[ii, jj] += dz_k[i, j]

print(
    "K_local[4,4] =",
    round(K[4, 4], 1),
    "(should be 4EI_y/L =",
    round(4 * EIy / L, 1),
    ")",
)
print("K_local[8,8] =", round(K[8, 8], 4))
print("K_local[8,4] =", round(K[8, 4], 4))

k_spring = 479000000.0  # N.mm/rad
K_rr = K[4, 4] + k_spring
print("k_spring =", k_spring, "N.mm/rad")
print("K_rr = K[4,4] + k_spring =", round(K_rr, 1))
print("ratio k_spring/K[4,4] =", round(k_spring / K[4, 4], 4))

# Condensed K_eff using Schur complement
# Spring condensation: DOF 4 (ry_A) gets series spring
# Augmented matrix: DOF 4 moves to interface (DOF 12), keep DOF 4 as node-side
K_aug = np.zeros((13, 13))
loc_to_int = {4: 12}  # ry_A -> interface DOF 12
for i in range(12):
    for j in range(12):
        val = K[i, j]
        if val == 0.0:
            continue
        ii = loc_to_int.get(i, i)
        jj = loc_to_int.get(j, j)
        K_aug[ii, jj] += val

# Series spring: node DOF 4 <-> interface DOF 12
K_aug[4, 4] += k_spring
K_aug[12, 12] += k_spring
K_aug[4, 12] -= k_spring
K_aug[12, 4] -= k_spring

# Condense out DOF 12
keep_idx = list(range(12))
elim_idx = [12]
K_kk = K_aug[np.ix_(keep_idx, keep_idx)]
K_kr = K_aug[np.ix_(keep_idx, elim_idx)]
K_rk = K_aug[np.ix_(elim_idx, keep_idx)]
K_rr = K_aug[np.ix_(elim_idx, elim_idx)]
K_eff = K_kk - K_kr @ np.linalg.inv(K_rr) @ K_rk

print()
print(
    "K_eff[4,4] =",
    round(K_eff[4, 4], 2),
    "(should be series:",
    round(k_spring * K[4, 4] / (k_spring + K[4, 4]), 2),
    ")",
)
print("K_eff[8,8] =", round(K_eff[8, 8], 4))
print("K_eff[8,4] =", round(K_eff[8, 4], 4))
print("K_eff[4,8] =", round(K_eff[4, 8], 4))

# FERS local displacements
u_local = np.zeros(12)
u_local[2] = 0.427825  # uz_A
u_local[4] = -0.003473  # ry_A (node-side = upright rotation)
u_local[8] = 16.231467  # uz_B
u_local[10] = -0.014695  # ry_B

# Check: K_eff * u_local should equal f_eq (equivalent nodal load from UDL)
# UDL q = 4.0875 N/mm in local +z
q = 4.0875
# Fixed-end forces for UDL: [qL/2, qL^2/12, qL/2, -qL^2/12] for [uz_A, ry_A, uz_B, ry_B]
f_eq = np.zeros(12)
f_eq[2] = q * L / 2  # uz_A
f_eq[4] = q * L**2 / 12  # ry_A
f_eq[8] = q * L / 2  # uz_B
f_eq[10] = -q * L**2 / 12  # ry_B

f_computed = K_eff @ u_local
print()
print("K_eff * u_local (should equal f_eq at free DOFs, = 0 at arm tip):")
print("  f[uz_A] computed =", round(f_computed[2], 2), " f_eq =", round(f_eq[2], 2))
print("  f[ry_A] computed =", round(f_computed[4], 2), " f_eq =", round(f_eq[4], 2))
print(
    "  f[uz_B] computed =",
    round(f_computed[8], 2),
    " f_eq =",
    round(f_eq[8], 2),
    "(arm tip: should be 0, external load = 0)",
)
print(
    "  f[ry_B] computed =",
    round(f_computed[10], 4),
    " f_eq =",
    round(f_eq[10], 4),
    "(should be 0)",
)

print()
print(
    "Residual at uz_B (arm tip): K_eff*u - f_eq =",
    round(f_computed[8] - f_eq[8], 4),
    "(should be 0 if correct)",
)
print("Residual at ry_B:", round(f_computed[10] - f_eq[10], 4))

# Now compute what uz_B SHOULD be, given the other DOFs and arm loading
# Solve for [uz_B, ry_B] given [uz_A, ry_A] and external forces at arm tip = 0
# (arm tip is free: no external moment or force)
# Submatrix for free DOFs [uz_B=8, ry_B=10]
bending_dofs = [2, 4, 8, 10]
K_bending = K_eff[np.ix_(bending_dofs, bending_dofs)]
f_bending = f_eq[bending_dofs]  # = [qL/2, qL^2/12, qL/2, -qL^2/12]

# Fixed DOFs: uz_A=2 (value=0.427825), ry_A=4 (value=-0.003473)
# Free DOFs: uz_B=8 (idx 2 in bending), ry_B=10 (idx 3 in bending)
# K11 (free-free), K12 (free-fixed), K21 (fixed-free), K22 (fixed-fixed)
K11 = K_bending[2:4, 2:4]  # free-free (uz_B, ry_B)
K12 = K_bending[2:4, 0:2]  # free-fixed (depends on uz_A, ry_A)
u_fixed = np.array([u_local[2], u_local[4]])  # [uz_A, ry_A]
f_free = np.array(
    [f_bending[2], f_bending[3]]
)  # = [qL/2, -qL^2/12] (at arm tip, external=0)

# External forces at free DOFs = 0 (no tip load)
f_ext_free = np.array([0.0, 0.0])

# Solve: K11 * u_free = f_ext_free + f_free - K12 * u_fixed
rhs = f_ext_free + f_free - K12 @ u_fixed
u_free_expected = np.linalg.solve(K11, rhs)

print()
print(
    "Expected uz_B =",
    round(u_free_expected[0], 4),
    "mm  (from condensed K_eff + node BCs)",
)
print("FERS uz_B =", round(u_local[8], 4), "mm")
print("Difference =", round(u_free_expected[0] - u_local[8], 4), "mm")
print()
print("SkyCiv uz_B (from tip dy=-17.3458, uz_A=0.3317 local z):")
print("  SkyCiv relative uz_B =", 17.3458 - 0.3317, "mm")
