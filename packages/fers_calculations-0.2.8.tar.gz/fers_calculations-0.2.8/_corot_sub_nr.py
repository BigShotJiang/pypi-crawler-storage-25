import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L_total = 1000.0; P = 1000.0
N_sub = 4

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((12, 12))
    ea = E*A/L; l2=L*L; l3=l2*L
    k[0,0]=ea; k[6,6]=ea; k[0,6]=k[6,0]=-ea
    eiz = E*Iz
    k[1,1]=12*eiz/l3; k[1,5]=k[5,1]=6*eiz/l2; k[1,7]=k[7,1]=-12*eiz/l3; k[1,11]=k[11,1]=6*eiz/l2
    k[5,5]=4*eiz/L; k[5,7]=k[7,5]=-6*eiz/l2; k[5,11]=k[11,5]=2*eiz/L
    k[7,7]=12*eiz/l3; k[7,11]=k[11,7]=-6*eiz/l2; k[11,11]=4*eiz/L
    eiy = E*Iy
    k[2,2]=12*eiy/l3; k[2,4]=k[4,2]=-6*eiy/l2; k[2,8]=k[8,2]=-12*eiy/l3; k[2,10]=k[10,2]=-6*eiy/l2
    k[4,4]=4*eiy/L; k[4,8]=k[8,4]=6*eiy/l2; k[4,10]=k[10,4]=2*eiy/L
    k[8,8]=12*eiy/l3; k[8,10]=k[10,8]=6*eiy/l2; k[10,10]=4*eiy/L
    gj = G*J/L
    k[3,3]=gj; k[9,9]=gj; k[3,9]=k[9,3]=-gj
    return k

def build_T12(R):
    T = np.zeros((12, 12))
    for n in range(2):
        b = n*6; T[b:b+3,b:b+3] = R; T[b+3:b+6,b+3:b+6] = R
    return T

def rodrigues(v_from, v_to):
    c = float(v_from @ v_to)
    s_vec = np.cross(v_from, v_to)
    s = np.linalg.norm(s_vec)
    if s < 1e-12:
        if c > 0: return np.eye(3)
        perp = np.cross(np.array([1,0,0.]) if abs(v_from[0])<0.9 else np.array([0,1,0.]), v_from)
        perp /= np.linalg.norm(perp)
        return 2*np.outer(perp,perp) - np.eye(3)
    k = s_vec/s; K = np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3) + K*s + K@K*(1-c)

def rot_vec_from_mat(R):
    tr = np.trace(R)
    cos_t = np.clip((tr - 1)/2, -1, 1)
    theta = np.arccos(cos_t)
    if theta < 1e-12: return np.zeros(3)
    if np.pi - theta < 1e-6:
        S = R + np.eye(3); best = S[:, np.argmax(np.linalg.norm(S, axis=0))]
        best /= np.linalg.norm(best); return best * theta
    axis = np.array([R[2,1]-R[1,2], R[0,2]-R[2,0], R[1,0]-R[0,1]])
    return axis * theta / (2*np.sin(theta))

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

n_nodes = 3*N_sub+1; ndof = n_nodes*6; Ls0 = L_total/N_sub
orig_R_list = [R1]*N_sub + [R2]*N_sub + [R3]*N_sub
node_pos = np.zeros((n_nodes, 3))
for i in range(N_sub+1): node_pos[i] = [i*Ls0, 0, 0]
for i in range(1, N_sub+1): node_pos[N_sub+i] = [1000, i*Ls0, 0]
for i in range(1, N_sub+1): node_pos[2*N_sub+i] = [1000, 1000, i*Ls0]
elem_nodes = [(m*N_sub+s, m*N_sub+s+1) for m in range(3) for s in range(N_sub)]

fixed = list(range(6))
free = [i for i in range(ndof) if i not in fixed]
F_full = np.zeros(ndof); F_full[3*N_sub*6+1] = -P

def corot_fint_and_K(u_total):
    """Compute corotational F_int AND K_tangent (T_def^T * K * T_def)"""
    f_int = np.zeros(ndof)
    K_tan = np.zeros((ndof, ndof))
    
    for e_idx, (ni, nj) in enumerate(elem_nodes):
        p1_orig = node_pos[ni]; p2_orig = node_pos[nj]
        p1_def = p1_orig + u_total[ni*6:ni*6+3]
        p2_def = p2_orig + u_total[nj*6:nj*6+3]
        l_orig = np.linalg.norm(p2_orig - p1_orig)
        l_def = np.linalg.norm(p2_def - p1_def)
        if l_def < 1e-12: l_def = 1e-12
        x_orig = (p2_orig - p1_orig) / l_orig
        x_def = (p2_def - p1_def) / l_def
        
        R_orig = orig_R_list[e_idx]
        Rc = rodrigues(x_orig, x_def)
        R_def = R_orig @ Rc.T
        T_def = build_T12(R_def)
        omega = rot_vec_from_mat(Rc)
        
        u_elem = np.zeros(12)
        for d in range(6):
            u_elem[d] = u_total[ni*6+d]
            u_elem[6+d] = u_total[nj*6+d]
        
        # Corotational deformations
        d_local = np.zeros(12)
        theta1_g = u_elem[3:6]; theta2_g = u_elem[9:12]
        d_local[3:6] = R_def @ (theta1_g - omega)
        d_local[9:12] = R_def @ (theta2_g - omega)
        d_local[6] = l_def - l_orig  # axial = chord extension
        
        kl = beam_k_local(E, G, A, Iy, Iz, J, l_orig)  # K at original length
        f_local = kl @ d_local
        f_global = T_def.T @ f_local
        
        dofs_e = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
        for i in range(12):
            f_int[dofs_e[i]] += f_global[i]
        
        # Tangent: T_def^T * K * T_def (approximate)
        kg = T_def.T @ kl @ T_def
        for i in range(12):
            for j in range(12):
                K_tan[dofs_e[i], dofs_e[j]] += kg[i, j]
    
    return f_int, K_tan

# Corotational N-R with load stepping
n_steps = 20
u = np.zeros(ndof)
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    F_norm = max(np.linalg.norm(F_lam[free]), 1.0)
    
    for it in range(50):
        f_int, K_tan = corot_fint_and_K(u)
        # Zero support DOFs in residual
        r_full = f_int - F_lam
        r_full[:6] = 0  # node 0 is fixed
        r_free = r_full[free]
        res = np.linalg.norm(r_free) / F_norm
        if res < tol:
            break
        
        K_ff = K_tan[np.ix_(free, free)]
        du = np.linalg.solve(K_ff, -r_free)
        
        # Line search
        alpha = 1.0
        for _ in range(12):
            u_trial = u.copy()
            u_trial[free] += alpha * du
            f_trial, _ = corot_fint_and_K(u_trial)
            r_trial = f_trial - F_lam
            r_trial[:6] = 0
            res_trial = np.linalg.norm(r_trial[free]) / F_norm
            if res_trial < res:
                u[free] = u_trial[free]
                break
            alpha *= 0.5
        else:
            u[free] += alpha * du  # accept smallest step
    
    if step in (1,2,5,10,20):
        dy = u[3*N_sub*6+1]; dz = u[3*N_sub*6+2]; rx = u[N_sub*6+3]
        print(f'Step {step:2d} (l={lam:.2f}): rx={rx:.6f} dy4={dy:.2f} dz4={dz:.2f} res={res:.2e} it={it}')

dy = u[3*N_sub*6+1]; dz = u[3*N_sub*6+2]; rx = u[N_sub*6+3]
Mx_arm = -P * (1000 + dz)
f_final, _ = corot_fint_and_K(u)
print(f'\nCorot N-R ({N_sub} sub): dy4={dy:.2f} dz4={dz:.2f} rx_n2={rx:.6f}')
print(f'Mx_react={f_final[3]:.0f} Mx_arm={Mx_arm:.0f}')
print(f'Expected: dy=-350, dz=347, Mx=-1347000')
