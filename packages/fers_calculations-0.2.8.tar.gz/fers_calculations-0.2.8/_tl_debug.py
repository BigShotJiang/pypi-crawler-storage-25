import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L = 1000.0; P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((14, 14))
    ea_l = E*A/L
    k[0,0] = ea_l; k[7,7] = ea_l; k[0,7] = k[7,0] = -ea_l
    eiz = E*Iz; l2=L*L; l3=l2*L
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,8] = k[8,1] = -12*eiz/l3; k[1,12] = k[12,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,8] = k[8,5] = -6*eiz/l2
    k[5,12] = k[12,5] = 2*eiz/L
    k[8,8] = 12*eiz/l3;  k[8,12] = k[12,8] = -6*eiz/l2
    k[12,12] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,9] = k[9,2] = -12*eiy/l3; k[2,11] = k[11,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,9] = k[9,4] = 6*eiy/l2
    k[4,11] = k[11,4] = 2*eiy/L
    k[9,9] = 12*eiy/l3;  k[9,11] = k[11,9] = 6*eiy/l2
    k[11,11] = 4*eiy/L
    gj_l = G*J/L
    k[3,3] = gj_l; k[10,10] = gj_l; k[3,10] = k[10,3] = -gj_l
    k[6,6] = 1e-6; k[13,13] = 1e-6
    return k

def beam_kgeo_local(N, L):
    k = np.zeros((14, 14))
    p_l = N / L; pL = N * L
    k[0,0] = p_l; k[0,7] = -p_l; k[7,0] = -p_l; k[7,7] = p_l
    # Y-bending (1,5,8,12)
    k[1,1] = 6/5*p_l; k[1,5]=k[5,1]=pL/10; k[1,8]=k[8,1]=-6/5*p_l; k[1,12]=k[12,1]=pL/10
    k[5,5]=4/15*pL; k[5,8]=k[8,5]=-pL/10; k[5,12]=k[12,5]=2/15*pL
    k[8,8]=6/5*p_l; k[8,12]=k[12,8]=-pL/10
    k[12,12]=4/15*pL
    # Z-bending (2,4,9,11)
    k[2,2]=6/5*p_l; k[2,4]=k[4,2]=pL/10; k[2,9]=k[9,2]=-6/5*p_l; k[2,11]=k[11,2]=pL/10
    k[4,4]=4/15*pL; k[4,9]=k[9,4]=-pL/10; k[4,11]=k[11,4]=2/15*pL
    k[9,9]=6/5*p_l; k[9,11]=k[11,9]=-pL/10
    k[11,11]=4/15*pL
    return k

def build_T(R):
    T = np.zeros((14, 14))
    for node in range(2):
        b = node * 7
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
        T[b+6, b+6] = 1.0
    return T

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)
T1 = build_T(R1); T2 = build_T(R2); T3 = build_T(R3)
k_local = beam_k_local(E, G, A, Iy, Iz, J, L)

ndof = 28
free = list(range(7, 28))
dofs1 = list(range(0,7)) + list(range(7,14))
dofs2 = list(range(7,14)) + list(range(14,21))
dofs3 = list(range(14,21)) + list(range(21,28))
F_full = np.zeros(ndof); F_full[22] = -P

def get_axial(Ti, dofs, u_full):
    u_elem = np.array([u_full[d] for d in dofs])
    u_loc = Ti @ u_elem
    return E * A / L * (u_loc[7] - u_loc[0])

def assemble_K(u_full=None):
    K = np.zeros((ndof, ndof))
    for Ti, dofs in [(T1, dofs1), (T2, dofs2), (T3, dofs3)]:
        kg = Ti.T @ k_local @ Ti
        for i in range(14):
            for j in range(14):
                K[dofs[i], dofs[j]] += kg[i, j]
    if u_full is not None:
        for Ti, dofs in [(T1, dofs1), (T2, dofs2), (T3, dofs3)]:
            N = get_axial(Ti, dofs, u_full)
            if abs(N) > 250:
                kg_local = beam_kgeo_local(N, L)
                kg_global = Ti.T @ kg_local @ Ti
                for i in range(14):
                    for j in range(14):
                        K[dofs[i], dofs[j]] += kg_global[i, j]
    return K

# First-order
K0 = assemble_K()
u_1st = np.zeros(ndof)
u_1st[free] = np.linalg.solve(K0[np.ix_(free, free)], F_full[free])

# Check: how big is K_geo * u_1st?
K_total = assemble_K(u_1st)
r_1st = K_total[np.ix_(free, free)] @ u_1st[free] - F_full[free]
print(f'First-order residual with K_total: ||r|| = {np.linalg.norm(r_1st):.2f}')
print(f'||F|| = {np.linalg.norm(F_full[free]):.2f}')
print(f'Relative residual: {np.linalg.norm(r_1st)/np.linalg.norm(F_full[free]):.6f}')

# Check K_geo contribution
K_geo_only = K_total - K0
print(f'||K_geo * u_1st||/||F|| = {np.linalg.norm(K_geo_only[np.ix_(free,free)] @ u_1st[free])/np.linalg.norm(F_full[free]):.6f}')

# One Newton step from first-order solution
du = np.linalg.solve(K_total[np.ix_(free, free)], -r_1st)
u_2nd = u_1st.copy()
u_2nd[free] += du
print(f'\nFirst-order: rx_n2 = {u_1st[10]:.6f}')
print(f'After 1 NR step: rx_n2 = {u_2nd[10]:.6f}')
print(f'Change in rx: {du[10-7]:.6f} ({100*du[10-7]/u_1st[10]:.2f}%)')

# Check new residual
K_total2 = assemble_K(u_2nd)
r_2nd = K_total2[np.ix_(free, free)] @ u_2nd[free] - F_full[free]
print(f'New residual: {np.linalg.norm(r_2nd)/np.linalg.norm(F_full[free]):.8f}')

# Check axial forces
for mid, name, Ti, dofs in [(0,'M1',T1,dofs1),(1,'M2',T2,dofs2),(2,'M3',T3,dofs3)]:
    N = get_axial(Ti, dofs, u_1st)
    print(f'{name}: N_1st = {N:.2f} N')
