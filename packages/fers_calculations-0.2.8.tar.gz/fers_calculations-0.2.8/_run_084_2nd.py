import json
import fers_calculations as fers

# Second-order (original cross-check settings)
with open('C:/Users/Jeroe/Documents/Azure Repo/Backend/solver/tests/Solver_cross_checks/io_dumps/084_Triple_Cantilever_3D/fers_input.json') as f:
    data = json.load(f)

# Make sure it's Nonlinear
print(f"Order: {data['settings']['analysis_options']['order']}")
print(f"Solver: {data['settings']['analysis_options']['solver']}")

result_str = fers.calculate_from_json(json.dumps(data))
r = json.loads(result_str)
res = r['results']

for lc_name, lc_data in res['loadcases'].items():
    print(f'\nLoad case: {lc_name}')
    rx = lc_data['reaction_nodes']['1']['nodal_forces']
    print('  Reactions at N1:')
    for k in ['fx','fy','fz','mx','my','mz']:
        print(f'    {k} = {rx[k]:.4f}')

    print('  Displacements:')
    for nid in ['2','3','4']:
        d = lc_data['displacement_nodes'].get(nid, {})
        nonzero = {k: d[k] for k in ['dx','dy','dz','rx','ry','rz'] if abs(d.get(k,0)) > 1e-6}
        if nonzero:
            parts = ' '.join(f'{k}={v:.4f}' for k,v in nonzero.items())
            print(f'    N{nid}: {parts}')
