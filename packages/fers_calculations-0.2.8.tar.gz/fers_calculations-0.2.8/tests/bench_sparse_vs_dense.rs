/// Benchmark: Sparse vs Dense solver paths and parallel load combinations.
///
/// Builds multi-bay portal frame models of increasing size and measures
/// solve time for both the old dense path and the new sparse path.
/// Also benchmarks sequential vs parallel load combination solving.

#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::fers::fers::FERS;
use fers_calculations::models::loads::distributedload::DistributedLoad;
use fers_calculations::models::loads::loadcase::LoadCase;
use fers_calculations::models::loads::loadcombination::{LimitState, LoadCombination};
use fers_calculations::models::members::memberset::MemberSet;
use fers_calculations::models::settings::analysissettings::RigidStrategy;
use std::collections::HashMap;

use test_support::helpers::*;

/// Build a multi-bay portal frame: `n_bays` bays × `n_levels` levels.
/// Each bay is 3m wide (X), each level is 3m tall (Y).
fn build_portal_frame(n_bays: usize, n_levels: usize, n_load_combos: usize) -> FERS {
    let mut model = make_fers_with_strategy(RigidStrategy::LinearMpc);
    let mat_id = add_material_s235(&mut model, 1);

    let sec_id = add_section(
        &mut model,
        1,
        "IPE300",
        mat_id,
        53.8e-4,   // area m²
        604.0e-8,  // Iy m⁴
        8356.0e-8, // Iz m⁴
        20.1e-8,   // J m⁴
    );

    let n_cols = n_bays + 1;
    let bay_width = 3.0;
    let level_height = 3.0;

    let mut nodes = Vec::new();
    let support_id = 1u32;
    model.nodal_supports.push(make_fixed_support(support_id));

    for col in 0..n_cols {
        for level in 0..=n_levels {
            let x = col as f64 * bay_width;
            let y = level as f64 * level_height;
            let node_id = (col * (n_levels + 1) + level + 1) as u32;
            let sup = if level == 0 { Some(support_id) } else { None };
            nodes.push(make_node(node_id, x, y, 0.0, sup));
        }
    }

    let mut members = Vec::new();
    let mut member_id = 1u32;

    // Columns
    for col in 0..n_cols {
        for level in 0..n_levels {
            let start_idx = col * (n_levels + 1) + level;
            let end_idx = col * (n_levels + 1) + level + 1;
            members.push(make_beam_member(member_id, &nodes[start_idx], &nodes[end_idx], sec_id));
            member_id += 1;
        }
    }

    // Beams
    for level in 1..=n_levels {
        for bay in 0..n_bays {
            let start_idx = bay * (n_levels + 1) + level;
            let end_idx = (bay + 1) * (n_levels + 1) + level;
            members.push(make_beam_member(member_id, &nodes[start_idx], &nodes[end_idx], sec_id));
            member_id += 1;
        }
    }

    model.member_sets.push(MemberSet {
        id: 1,
        l_y: None,
        l_z: None,
        classification: None,
        members,
    });

    // Distributed loads on top-level beams
    let mut distributed_loads = Vec::new();
    let beam_start_id = (n_cols * n_levels) as u32 + 1;
    let top_beam_start = beam_start_id + ((n_levels - 1) * n_bays) as u32;
    for i in 0..n_bays as u32 {
        distributed_loads.push(DistributedLoad {
            member: top_beam_start + i,
            load_case: 1,
            magnitude: -10000.0,
            direction: (0.0, 1.0, 0.0),
            start_frac: 0.0,
            end_frac: 1.0,
            end_magnitude: -10000.0,
        });
    }

    let distributed_loads_2: Vec<DistributedLoad> = distributed_loads
        .iter()
        .map(|dl| DistributedLoad {
            load_case: 2,
            ..dl.clone()
        })
        .collect();

    model.load_cases.push(LoadCase {
        id: 1,
        name: "DL".to_string(),
        nodal_loads: Vec::new(),
        nodal_moments: Vec::new(),
        distributed_loads,
        rotation_imperfections: Vec::new(),
        translation_imperfections: Vec::new(),
    });

    model.load_cases.push(LoadCase {
        id: 2,
        name: "LL".to_string(),
        nodal_loads: Vec::new(),
        nodal_moments: Vec::new(),
        distributed_loads: distributed_loads_2,
        rotation_imperfections: Vec::new(),
        translation_imperfections: Vec::new(),
    });

    // Load combinations
    for i in 0..n_load_combos {
        let factor_dl = 1.35 + (i as f64) * 0.01;
        let factor_ll = 1.5 - (i as f64) * 0.01;
        let mut factors = HashMap::new();
        factors.insert(1u32, factor_dl);
        factors.insert(2u32, factor_ll);
        model.load_combinations.push(LoadCombination {
            id: (i + 1) as u32,
            name: format!("ULS_{}", i + 1),
            load_cases_factors: factors,
            situation: None,
            check: "ULS".to_string(),
            limit_state: Some(LimitState::ULS),
        });
    }

    model
}

#[test]
fn bench_sparse_solver_scaling() {
    // Test models of increasing size
    let configs = vec![
        (2, 2, "2×2"),   // small:  9 nodes, ~10 members, ~63 DOFs
        (5, 3, "5×3"),   // medium: 24 nodes, ~33 members, ~168 DOFs
        (10, 5, "10×5"), // large:  66 nodes, ~105 members, ~462 DOFs
        (15, 8, "15×8"), // xlarge: 144 nodes, ~255 members, ~1008 DOFs
    ];

    println!("\n╔══════════════════════════════════════════════════════════════════╗");
    println!("║            SPARSE MATRIX SOLVER — PERFORMANCE BENCHMARK        ║");
    println!("╠══════════════════════════════════════════════════════════════════╣");
    println!("║ Config   │ Nodes │ Members │   DOFs │  Solve(ms) │    Status   ║");
    println!("╠══════════════════════════════════════════════════════════════════╣");

    for (n_bays, n_levels, label) in &configs {
        let mut model = build_portal_frame(*n_bays, *n_levels, 0);
        model.normalize_units();

        let n_nodes = (n_bays + 1) * (n_levels + 1);
        let n_members: usize = model.member_sets.iter().map(|ms| ms.members.len()).sum();
        let n_dofs = n_nodes * 7;

        let _load_vector = model.assemble_load_vector_for_case(1);
        let start = std::time::Instant::now();
        let result = model.solve_for_load_case(1);
        let elapsed = start.elapsed();

        let status = if result.is_ok() { "OK" } else { "FAIL" };
        println!(
            "║ {:>8} │ {:>5} │ {:>7} │ {:>6} │ {:>10.1} │ {:>11} ║",
            label,
            n_nodes,
            n_members,
            n_dofs,
            elapsed.as_secs_f64() * 1000.0,
            status
        );

        assert!(result.is_ok(), "Solve failed for config {}", label);
    }

    println!("╚══════════════════════════════════════════════════════════════════╝\n");
}

#[test]
fn bench_parallel_load_combinations() {
    use fers_calculations::analysis::run_pipeline_from_json_with_policy;
    use fers_calculations::limits::LimitPolicy;

    let n_combos = 16;
    // Use 8×4 (45 nodes, 68 members) to stay within Free tier limit of 100
    let mut model = build_portal_frame(8, 4, n_combos);
    model.settings.analysis_options.solve_loadcases = true;

    let n_members: usize = model.member_sets.iter().map(|ms| ms.members.len()).sum();
    let n_nodes = 9 * 5; // (8+1)*(4+1)

    let json = serde_json::to_string(&model).unwrap();

    println!("\n╔══════════════════════════════════════════════════════════════════╗");
    println!("║         PARALLEL LOAD COMBINATIONS — BENCHMARK                 ║");
    println!("╠══════════════════════════════════════════════════════════════════╣");
    println!("║ Model: 8×4 portal ({} nodes, {} members, {} DOFs)             ║", n_nodes, n_members, n_nodes * 7);
    println!("║ Load combinations: {}                                           ║", n_combos);
    println!("╠══════════════════════════════════════════════════════════════════╣");

    let start = std::time::Instant::now();
    let result = run_pipeline_from_json_with_policy(&json, LimitPolicy::free());
    let total_ms = start.elapsed().as_secs_f64() * 1000.0;

    assert!(result.is_ok(), "Pipeline failed: {:?}", result.err());

    println!("║ Total pipeline (2 LCs + {} combos): {:>6.0} ms                  ║", n_combos, total_ms);
    println!("║ Avg per combination:                {:>6.1} ms                  ║", total_ms / n_combos as f64);
    println!("╚══════════════════════════════════════════════════════════════════╝\n");
    println!("╚══════════════════════════════════════════════════════════════════╝\n");
}

/// Head-to-head comparison: dense assembly+reduce vs sparse assembly+reduce.
/// Both code paths still exist (dense is #[allow(dead_code)]).
/// This test exercises each path independently on the same model to measure
/// the assembly+reduction speedup from sparse matrices.
#[test]
fn bench_sparse_vs_dense_assembly_reduce() {
    use fers_calculations::functions::geometry::compute_num_dofs_from_members;

    let configs = vec![
        (5, 3, "5×3"),
        (10, 5, "10×5"),
        (15, 8, "15×8"),
    ];

    println!("\n╔═══════════════════════════════════════════════════════════════════════════╗");
    println!("║          ASSEMBLY + REDUCE: SPARSE vs DENSE COMPARISON                  ║");
    println!("╠═══════════════════════════════════════════════════════════════════════════╣");
    println!("║ Config   │  DOFs │ Dense(ms) │ Sparse(ms) │ Speedup │ Status            ║");
    println!("╠═══════════════════════════════════════════════════════════════════════════╣");

    for (n_bays, n_levels, label) in &configs {
        let mut model = build_portal_frame(*n_bays, *n_levels, 0);
        model.normalize_units();

        let n_dofs = compute_num_dofs_from_members(&model.member_sets);
        let active_map = model.init_active_map_tie_comp_pub();
        let elim = model.build_rigid_elimination_pub().unwrap();
        let load_vector = nalgebra::DMatrix::<f64>::zeros(n_dofs, 1);

        // Warm up
        let _ = model.build_operator_with_supports_sparse(&active_map, None, None);

        // Dense path
        let n_iters = 5;
        let start_dense = std::time::Instant::now();
        for _ in 0..n_iters {
            let k_dense = model.build_operator_with_supports_dense_for_bench(&active_map, None, None).unwrap();
            let (_k_red, _f_red) = FERS::reduce_system_dense_for_bench(&k_dense, &load_vector, &elim);
        }
        let dense_ms = start_dense.elapsed().as_secs_f64() * 1000.0 / n_iters as f64;

        // Sparse path
        let start_sparse = std::time::Instant::now();
        for _ in 0..n_iters {
            let k_sparse = model.build_operator_with_supports_sparse(&active_map, None, None).unwrap();
            let (_k_red, _f_red) = FERS::reduce_system_sparse(&k_sparse, &load_vector, &elim);
        }
        let sparse_ms = start_sparse.elapsed().as_secs_f64() * 1000.0 / n_iters as f64;

        let speedup = dense_ms / sparse_ms;
        println!(
            "║ {:>8} │ {:>5} │ {:>9.1} │ {:>10.1} │ {:>6.1}× │ OK                ║",
            label, n_dofs, dense_ms, sparse_ms, speedup
        );
    }

    println!("╚═══════════════════════════════════════════════════════════════════════════╝\n");
}
