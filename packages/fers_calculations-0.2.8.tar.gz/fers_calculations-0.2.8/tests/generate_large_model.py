"""Generate FERS JSON input files for benchmarking the solver with large portal frames.

Produces multi-bay, multi-level 2D portal frames at five sizes:
  ~100, ~500, ~1000, ~2000, ~5000 members.

Each file is self-contained and matches the exact JSON schema expected by
fers_calculations (the Rust solver).  No FERS_core dependency is needed.

Portal frame geometry (XY plane, Z=0):
    - Each bay is 3 m wide (X direction)
    - Each level is 3 m tall (Y direction)
    - Bottom-row nodes are fully fixed (nodal_support = 1)
    - All members use a single IPE 300 section in S235 steel
    - Uniform distributed load of -10 kN/m (global Y) on all top-level beams

Usage:
    cd FERS_calculations
    python tests/generate_large_model.py
"""

from __future__ import annotations

import json
from pathlib import Path

# ---------------------------------------------------------------------------
# Target configurations: (label, n_bays, n_levels)
#
# Members per frame = n_levels * (2 * n_bays + 1)
#   columns = (n_bays + 1) * n_levels
#   beams   = n_bays * n_levels
# Nodes per frame   = (n_bays + 1) * (n_levels + 1)
# ---------------------------------------------------------------------------
CONFIGS: list[tuple[int, int, int]] = [
    (100, 7, 7),      # 105 members,   64 nodes
    (500, 16, 16),    # 528 members,  289 nodes
    (1000, 22, 22),   # 990 members,  529 nodes
    (2000, 32, 32),   # 2080 members, 1089 nodes
    (5000, 50, 50),   # 5050 members, 2601 nodes
]

BAY_WIDTH: float = 3.0    # metres
LEVEL_HEIGHT: float = 3.0  # metres
DOFS_PER_NODE: int = 6     # 3D beam element (Ux, Uy, Uz, Rx, Ry, Rz)


# ---------------------------------------------------------------------------
# Low-level JSON builders — produce plain dicts matching Rust serde structs
# ---------------------------------------------------------------------------


def make_node(
    nid: int,
    x: float,
    y: float,
    z: float,
    support: int | None,
) -> dict:
    """Build a Node dict matching ``src/models/nodes/node.rs::Node``."""
    return {
        "id": nid,
        "X": x,
        "Y": y,
        "Z": z,
        "nodal_support": support,
    }


def make_member(
    mid: int,
    start: dict,
    end: dict,
    section_id: int = 1,
) -> dict:
    """Build a Member dict matching ``src/models/members/member.rs::Member``."""
    return {
        "id": mid,
        "start_node": start,
        "end_node": end,
        "section": section_id,
        "rotation_angle": 0.0,
        "start_hinge": None,
        "end_hinge": None,
        "classification": "",
        "weight": 0.0,
        "chi": None,
        "reference_member": None,
        "reference_node": None,
        "member_type": "Normal",
    }


def make_distributed_load(
    member_id: int,
    load_case_id: int,
    magnitude: float = -10000.0,
) -> dict:
    """Build a DistributedLoad dict matching ``src/models/loads/distributedload.rs``."""
    return {
        "member": member_id,
        "load_case": load_case_id,
        "magnitude": magnitude,
        "direction": [0.0, 1.0, 0.0],
        "start_frac": 0.0,
        "end_frac": 1.0,
        "end_magnitude": magnitude,
    }


# ---------------------------------------------------------------------------
# Portal frame generator
# ---------------------------------------------------------------------------


def node_id(col: int, level: int, n_levels: int) -> int:
    """Return 1-based node ID using column-major ordering."""
    return col * (n_levels + 1) + level + 1


def build_portal_frame(n_bays: int, n_levels: int) -> dict:
    """Build a complete FERS model dict for a multi-bay, multi-level 2D portal frame.

    Parameters
    ----------
    n_bays : int
        Number of bays (horizontal spans).
    n_levels : int
        Number of levels (stories).

    Returns
    -------
    dict
        A JSON-serialisable dict matching the top-level ``FERS`` struct
        in ``src/models/fers/fers.rs``.
    """
    n_cols = n_bays + 1

    # -- Pre-compute every node as a dict keyed by (col, level) ---------------
    nodes: dict[tuple[int, int], dict] = {}
    for col in range(n_cols):
        for level in range(n_levels + 1):
            nid = node_id(col, level, n_levels)
            x = col * BAY_WIDTH
            y = level * LEVEL_HEIGHT
            support = 1 if level == 0 else None
            nodes[(col, level)] = make_node(nid, x, y, 0.0, support)

    # -- Members ---------------------------------------------------------------
    members: list[dict] = []
    mid = 0

    # Columns (vertical): for each column, connect successive levels
    for col in range(n_cols):
        for level in range(n_levels):
            mid += 1
            members.append(
                make_member(mid, nodes[(col, level)], nodes[(col, level + 1)])
            )

    # Beams (horizontal): for each level > 0, connect adjacent columns
    top_beam_ids: list[int] = []
    for level in range(1, n_levels + 1):
        for bay in range(n_bays):
            mid += 1
            members.append(
                make_member(mid, nodes[(bay, level)], nodes[(bay + 1, level)])
            )
            if level == n_levels:
                top_beam_ids.append(mid)

    # -- Load cases ------------------------------------------------------------
    # LC 1: Dead load — uniform -10 kN/m on top-level beams
    # LC 2: Live load — same geometry, separate case for combination
    load_cases = [
        {
            "id": 1,
            "name": "DL",
            "nodal_loads": [],
            "nodal_moments": [],
            "distributed_loads": [
                make_distributed_load(bid, load_case_id=1) for bid in top_beam_ids
            ],
            "rotation_imperfections": [],
            "translation_imperfections": [],
        },
        {
            "id": 2,
            "name": "LL",
            "nodal_loads": [],
            "nodal_moments": [],
            "distributed_loads": [
                make_distributed_load(bid, load_case_id=2) for bid in top_beam_ids
            ],
            "rotation_imperfections": [],
            "translation_imperfections": [],
        },
    ]

    # -- Load combinations (Eurocode-style factors) ----------------------------
    load_combinations = [
        {
            "id": 1,
            "name": "ULS_1",
            "load_cases_factors": {"1": 1.35, "2": 1.50},
            "situation": None,
            "check": "ALL",
            "limit_state": "ULS",
        },
        {
            "id": 2,
            "name": "ULS_2",
            "load_cases_factors": {"1": 1.20, "2": 1.50},
            "situation": None,
            "check": "ALL",
            "limit_state": "ULS",
        },
        {
            "id": 3,
            "name": "ULS_3",
            "load_cases_factors": {"1": 1.35, "2": 1.05},
            "situation": None,
            "check": "ALL",
            "limit_state": "ULS",
        },
        {
            "id": 4,
            "name": "SLS_1",
            "load_cases_factors": {"1": 1.00, "2": 1.00},
            "situation": None,
            "check": "ALL",
            "limit_state": "SLS",
        },
    ]

    # -- Material: S235 structural steel ---------------------------------------
    materials = [
        {
            "id": 1,
            "name": "S235",
            "e_mod": 210000000000.0,
            "g_mod": 81000000000.0,
            "density": 7850.0,
            "yield_stress": 235000000.0,
        }
    ]

    # -- Section: IPE 300 ------------------------------------------------------
    sections = [
        {
            "id": 1,
            "name": "IPE300",
            "material": 1,
            "area": 0.00538,
            "i_y": 6.04e-06,
            "i_z": 8.356e-05,
            "j": 2.01e-06,
            "h": None,
            "b": None,
            "shape_path": None,
            "i_w": None,
            "y_s": None,
            "z_s": None,
            "wagner_coeff": None,
            "a_sy": None,
            "a_sz": None,
        }
    ]

    # -- Nodal support: fully fixed (used for bottom-row nodes) ----------------
    fixed_condition = {"condition_type": "Fixed", "stiffness": None}
    nodal_supports = [
        {
            "id": 1,
            "classification": None,
            "displacement_conditions": {
                "X": fixed_condition,
                "Y": fixed_condition,
                "Z": fixed_condition,
            },
            "rotation_conditions": {
                "X": fixed_condition,
                "Y": fixed_condition,
                "Z": fixed_condition,
            },
            "warping_condition": fixed_condition,
        }
    ]

    # -- Settings: linear first-order 3D analysis ------------------------------
    settings = {
        "id": 1,
        "analysis_options": {
            "id": 1,
            "solve_loadcases": True,
            "solver": "Direct",
            "tolerance": 1e-9,
            "dimensionality": "3D",
            "order": "Linear",
            "max_iterations": 20,
            "rigid_strategy": "LinearMpc",
            "axial_slack": 0.001,
            "include_shear_deformation": True,
            "include_warping": True,
            "nonlinear_method": "COROTATIONAL",
        },
        "general_info": {
            "project_name": f"Benchmark {n_bays}x{n_levels} portal frame",
            "author": "Benchmark",
            "version": "0.0.1",
        },
        "unit_settings": {
            "system": "metric",
            "lengthUnit": "m",
            "forceUnit": "N",
            "densityUnit": "kg/m3",
            "pressureUnit": "Pa",
        },
    }

    # -- Assemble the top-level FERS model dict --------------------------------
    model = {
        "member_sets": [
            {
                "id": 1,
                "l_y": None,
                "l_z": None,
                "classification": None,
                "members": members,
            }
        ],
        "load_cases": load_cases,
        "load_combinations": load_combinations,
        "imperfection_cases": [],
        "settings": settings,
        "results": None,
        "memberhinges": None,
        "materials": materials,
        "sections": sections,
        "nodal_supports": nodal_supports,
        "shape_paths": None,
    }

    return model


# ---------------------------------------------------------------------------
# File output and summary
# ---------------------------------------------------------------------------


def format_size(size_bytes: int) -> str:
    """Return a human-readable file-size string."""
    if size_bytes >= 1_048_576:
        return f"{size_bytes / 1_048_576:.2f} MB"
    return f"{size_bytes / 1024:.1f} KB"


def main() -> None:
    # Output directory = tests/ (same directory as this script)
    script_dir = Path(__file__).resolve().parent
    out_dir = script_dir

    print(f"Output directory: {out_dir}")
    print()

    header = (
        f"{'Target':>8}  "
        f"{'Bays':>5} {'Lvls':>5}  "
        f"{'Members':>8} {'Nodes':>8} {'DOFs':>10}  "
        f"{'File':>20}  "
        f"{'Size':>12}"
    )
    print(header)
    print("-" * len(header))

    for target, n_bays, n_levels in CONFIGS:
        model = build_portal_frame(n_bays, n_levels)

        # Derive counts from the actual generated data
        n_members = len(model["member_sets"][0]["members"])
        n_cols = n_bays + 1
        n_nodes = n_cols * (n_levels + 1)
        n_dofs = n_nodes * DOFS_PER_NODE

        filename = f"bench_{target}.json"
        filepath = out_dir / filename

        # Write compact JSON (no indentation) to minimise file size
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(model, f, separators=(",", ":"))

        size_bytes = filepath.stat().st_size
        size_str = format_size(size_bytes)

        print(
            f"{target:>8}  "
            f"{n_bays:>5} {n_levels:>5}  "
            f"{n_members:>8} {n_nodes:>8} {n_dofs:>10}  "
            f"{filename:>20}  "
            f"{size_str:>12}"
        )

    print()
    print("Done. All benchmark files written.")


if __name__ == "__main__":
    main()
