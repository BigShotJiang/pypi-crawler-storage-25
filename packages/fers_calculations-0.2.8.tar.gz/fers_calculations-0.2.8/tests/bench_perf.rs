/// Performance benchmark for solver optimization.
///
/// Creates synthetic portal-frame models at various sizes and combo counts
/// to measure per-phase timing and verify linear scaling.
///
/// Run with:  cargo test bench_perf -- --nocapture --ignored

#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::fers::fers::FERS;
use fers_calculations::models::loads::distributedload::DistributedLoad;
use fers_calculations::models::loads::loadcase::LoadCase;
use fers_calculations::models::loads::loadcombination::{LimitState, LoadCombination};
use fers_calculations::models::loads::nodalload::NodalLoad;
use fers_calculations::models::members::memberset::MemberSet;
use fers_calculations::models::settings::analysissettings::{AnalysisOrder, RigidStrategy};
use std::collections::HashMap;

use test_support::helpers::*;

/// Build a multi-bay portal frame with horizontal wind load.
fn build_bench_model(n_bays: usize, n_levels: usize, n_combos: usize) -> FERS {
    let mut model = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section(
        &mut model, 1, "IPE300", mat_id,
        53.8e-4, 604.0e-8, 8356.0e-8, 20.1e-8,
    );

    let n_cols = n_bays + 1;
    let bay_width = 6.0;
    let level_height = 3.5;

    let support_id = 1u32;
    model.nodal_supports.push(make_fixed_support(support_id));

    let mut nodes = Vec::new();
    for col in 0..n_cols {
        for level in 0..=n_levels {
            let x = col as f64 * bay_width;
            let y = level as f64 * level_height;
            let node_id = (col * (n_levels + 1) + level + 1) as u32;
            let sup = if level == 0 { Some(support_id) } else { None };
            nodes.push(make_node(node_id, x, y, 0.0, sup));
        }
    }

    let mut members = Vec::new();
    let mut member_id = 1u32;

    // Columns
    for col in 0..n_cols {
        for level in 0..n_levels {
            let si = col * (n_levels + 1) + level;
            let ei = col * (n_levels + 1) + level + 1;
            members.push(make_beam_member(member_id, &nodes[si], &nodes[ei], sec_id));
            member_id += 1;
        }
    }

    // Beams (all levels)
    for level in 1..=n_levels {
        for bay in 0..n_bays {
            let si = bay * (n_levels + 1) + level;
            let ei = (bay + 1) * (n_levels + 1) + level;
            members.push(make_beam_member(member_id, &nodes[si], &nodes[ei], sec_id));
            member_id += 1;
        }
    }

    model.member_sets.push(MemberSet {
        id: 1, l_y: None, l_z: None, classification: None,
        members,
    });

    // --- Load cases ---
    // LC1: Dead load (vertical distributed on top beams)
    let top_beam_start = (n_cols * n_levels) as u32 + 1 + ((n_levels - 1) * n_bays) as u32;
    let dl_top: Vec<DistributedLoad> = (0..n_bays as u32)
        .map(|i| DistributedLoad {
            member: top_beam_start + i, load_case: 1,
            magnitude: -10000.0, direction: (0.0, 1.0, 0.0),
            start_frac: 0.0, end_frac: 1.0, end_magnitude: -10000.0,
        })
        .collect();
    model.load_cases.push(LoadCase {
        id: 1, name: "DL".into(),
        nodal_loads: vec![], nodal_moments: vec![],
        distributed_loads: dl_top,
        rotation_imperfections: vec![], translation_imperfections: vec![],
    });

    // LC2: Live load (vertical distributed, different magnitude)
    let ll_top: Vec<DistributedLoad> = (0..n_bays as u32)
        .map(|i| DistributedLoad {
            member: top_beam_start + i, load_case: 2,
            magnitude: -5000.0, direction: (0.0, 1.0, 0.0),
            start_frac: 0.0, end_frac: 1.0, end_magnitude: -5000.0,
        })
        .collect();
    model.load_cases.push(LoadCase {
        id: 2, name: "LL".into(),
        nodal_loads: vec![], nodal_moments: vec![],
        distributed_loads: ll_top,
        rotation_imperfections: vec![], translation_imperfections: vec![],
    });

    // LC3: Wind load (horizontal point loads on left column nodes)
    let wind_loads: Vec<NodalLoad> = (1..=n_levels)
        .map(|level| NodalLoad {
            id: level as u32,
            load_case: 3,
            node: (level + 1) as u32, // left column nodes (skip base)
            magnitude: 2000.0,
            direction: (1.0, 0.0, 0.0),
            load_type: "force".to_string(),
        })
        .collect();
    model.load_cases.push(LoadCase {
        id: 3, name: "Wind".into(),
        nodal_loads: wind_loads, nodal_moments: vec![],
        distributed_loads: vec![],
        rotation_imperfections: vec![], translation_imperfections: vec![],
    });

    // --- Load combinations ---
    for i in 0..n_combos {
        let mut factors = HashMap::new();
        factors.insert(1u32, 1.35);
        factors.insert(2u32, 1.5 * if i % 3 == 0 { 0.7 } else { 1.0 });
        if i % 2 == 0 {
            factors.insert(3u32, 1.5);
        } else {
            factors.insert(3u32, 0.0);
        }
        model.load_combinations.push(LoadCombination {
            id: (i + 1) as u32,
            name: format!("ULS_{}", i + 1),
            load_cases_factors: factors,
            situation: None,
            check: "ULS".into(),
            limit_state: Some(LimitState::ULS),
        });
    }

    model
}

#[allow(dead_code)]
fn time_ms(f: impl FnOnce()) -> f64 {
    let t = std::time::Instant::now();
    f();
    t.elapsed().as_secs_f64() * 1000.0
}

/// Profile a model: solve LCs + combos and report per-phase timing.
fn profile_model(label: &str, n_bays: usize, n_levels: usize, n_combos: usize, second_order: bool) {
    let mut model = build_bench_model(n_bays, n_levels, n_combos);
    let n_members: usize = model.member_sets.iter().map(|ms| ms.members.len()).sum();
    let n_nodes = (n_bays + 1) * (n_levels + 1);
    let n_dofs = n_nodes * 7;

    if second_order {
        model.settings.analysis_options.order = AnalysisOrder::Nonlinear;
    }
    model.normalize_units();

    let total_start = std::time::Instant::now();

    // Phase 1: Solve load cases
    let lc_start = std::time::Instant::now();
    let lc_ids: Vec<u32> = model.load_cases.iter().map(|lc| lc.id).collect();
    for &lc_id in &lc_ids {
        if second_order {
            model.solve_for_load_case_second_order(lc_id, 20).unwrap();
        } else {
            model.solve_for_load_case(lc_id).unwrap();
        }
    }
    let lc_ms = lc_start.elapsed().as_secs_f64() * 1000.0;

    // Phase 2: Solve combos
    let combo_start = std::time::Instant::now();
    let combo_ids: Vec<u32> = model.load_combinations.iter().map(|c| c.id).collect();

    if second_order {
        // Second-order: must clone per combo
        for &combo_id in &combo_ids {
            let mut clone = model.clone();
            clone.solve_for_load_combination_second_order(combo_id, 20).unwrap();
        }
    } else {
        // First-order: use cached path
        let cached = model.precompute_combo_system().unwrap();
        for &combo_id in &combo_ids {
            let _res = model.solve_combo_with_cached(combo_id, &cached).unwrap();
        }
    }
    let combo_ms = combo_start.elapsed().as_secs_f64() * 1000.0;

    let total_ms = total_start.elapsed().as_secs_f64() * 1000.0;
    let per_combo = if n_combos > 0 { combo_ms / n_combos as f64 } else { 0.0 };

    eprintln!(
        "║ {:<14} │ {:>4} │ {:>4} │ {:>5} │ {:>3} │ {:>8.1} │ {:>8.1} │ {:>8.1} │ {:>6.1} ║",
        label, n_members, n_nodes, n_dofs, n_combos,
        lc_ms, combo_ms, total_ms, per_combo
    );
}

#[test]
#[ignore] // Run explicitly: cargo test bench_perf_scaling -- --nocapture --ignored
fn bench_perf_scaling_first_order() {
    eprintln!();
    eprintln!("╔═══════════════════════════════════════════════════════════════════════════════════════════╗");
    eprintln!("║                    FIRST-ORDER SOLVER PERFORMANCE BENCHMARK                              ║");
    eprintln!("╠════════════════╤══════╤══════╤═══════╤═════╤══════════╤══════════╤══════════╤════════════╣");
    eprintln!("║ Config         │ Memb │ Node │  DOFs │ Cmb │   LCs ms │ Combo ms │ Total ms │ ms/combo  ║");
    eprintln!("╠════════════════╪══════╪══════╪═══════╪═════╪══════════╪══════════╪══════════╪════════════╣");

    // Size scaling (fixed 10 combos)
    profile_model("3×2  10cmb", 3, 2, 10, false);
    profile_model("5×3  10cmb", 5, 3, 10, false);
    profile_model("10×5 10cmb", 10, 5, 10, false);
    profile_model("15×8 10cmb", 15, 8, 10, false);

    eprintln!("╠════════════════╪══════╪══════╪═══════╪═════╪══════════╪══════════╪══════════╪════════════╣");

    // Combo count scaling (fixed size: 10×5 = ~105 members)
    profile_model("10×5  5cmb", 10, 5, 5, false);
    profile_model("10×5 10cmb", 10, 5, 10, false);
    profile_model("10×5 20cmb", 10, 5, 20, false);
    profile_model("10×5 40cmb", 10, 5, 40, false);

    eprintln!("╚════════════════╧══════╧══════╧═══════╧═════╧══════════╧══════════╧══════════╧════════════╝");
}

#[test]
#[ignore] // Run explicitly: cargo test bench_perf_scaling_second -- --nocapture --ignored
fn bench_perf_scaling_second_order() {
    eprintln!();
    eprintln!("╔═══════════════════════════════════════════════════════════════════════════════════════════╗");
    eprintln!("║                   SECOND-ORDER SOLVER PERFORMANCE BENCHMARK                              ║");
    eprintln!("╠════════════════╤══════╤══════╤═══════╤═════╤══════════╤══════════╤══════════╤════════════╣");
    eprintln!("║ Config         │ Memb │ Node │  DOFs │ Cmb │   LCs ms │ Combo ms │ Total ms │ ms/combo  ║");
    eprintln!("╠════════════════╪══════╪══════╪═══════╪═════╪══════════╪══════════╪══════════╪════════════╣");

    // Size scaling (fixed 5 combos — second-order is expensive)
    profile_model("3×2  5cmb", 3, 2, 5, true);
    profile_model("5×3  5cmb", 5, 3, 5, true);
    profile_model("10×5 5cmb", 10, 5, 5, true);

    eprintln!("╠════════════════╪══════╪══════╪═══════╪═════╪══════════╪══════════╪══════════╪════════════╣");

    // Combo count scaling (fixed size: 5×3 = ~33 members, fast enough to iterate)
    profile_model("5×3  2cmb", 5, 3, 2, true);
    profile_model("5×3  5cmb", 5, 3, 5, true);
    profile_model("5×3 10cmb", 5, 3, 10, true);

    eprintln!("╚════════════════╧══════╧══════╧═══════╧═════╧══════════╧══════════╧══════════╧════════════╝");
}
