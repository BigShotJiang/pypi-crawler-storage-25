// tests/integration/test_131_force_component_curves.rs
//
// 131 — ForceComponent-dependent stiffness curve tests
//
// Validates the generalized StiffnessCurve where any spring's stiffness can
// depend on any of the 6 force components (N, Vy, Vz, Mx, My, Mz) at the
// owning support node.
//
// Base geometry: single-member cantilever (vertical column along Z-axis)
//   Node 1 (z=0)   — spring support with stiffness curve
//   Node 2 (z=3.0) — free end, loads applied
//
// Uses a SYMMETRIC section (I_y = I_z = SECOND_MOMENT_STRONG_AXIS_IN_M4) so
// bending stiffness is orientation-independent.
//
// Key parameter: 3EI/L ≈ 2.77e6 N·m for L=3 m.
// Curve ranges [1e4..1e7] span the meaningful spring regime.

use std::collections::BTreeMap;

use super::test_support::helpers::*;
use super::test_support::*;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::stiffness_curve::{ForceComponent, StiffnessCurveConfig};
use fers_calculations::models::supports::nodalsupport::NodalSupport;
use fers_calculations::models::supports::supportcondition::SupportCondition;
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

// ═════════════════════════════════════════════════════════════════════════════
// Helper: build a support where every DOF is fixed except one DOF gets a
// spring with a stiffness curve.
// ═════════════════════════════════════════════════════════════════════════════

/// Axis identifiers for the 6 DOFs: DX, DY, DZ, RX, RY, RZ.
#[derive(Clone, Copy)]
#[allow(dead_code)]
enum Dof {
    Dx,
    Dy,
    Dz,
    Rx,
    Ry,
    Rz,
}

/// Build a support with all DOFs fixed except `curve_dof` which gets a spring
/// driven by `curve`. An optional constant `spring_dof` with given stiffness
/// can also be set.
fn make_curve_support(
    id: u32,
    curve_dof: Dof,
    curve: StiffnessCurveConfig,
) -> NodalSupport {
    make_curve_support_multi(id, &[(curve_dof, curve)])
}

/// Build a support with all DOFs fixed except those listed, which each get a
/// spring with a stiffness curve.
fn make_curve_support_multi(
    id: u32,
    curves: &[(Dof, StiffnessCurveConfig)],
) -> NodalSupport {
    let fixed = || SupportCondition {
        condition_type: SupportConditionType::Fixed,
        stiffness: None,
        stiffness_curve: None,
    };
    let spring_curve = |c: &StiffnessCurveConfig| SupportCondition {
        condition_type: SupportConditionType::Spring,
        stiffness: None,
        stiffness_curve: Some(c.clone()),
    };

    let mut dx = fixed();
    let mut dy = fixed();
    let mut dz = fixed();
    let mut rx = fixed();
    let mut ry = fixed();
    let mut rz = fixed();

    for (dof, curve) in curves {
        match dof {
            Dof::Dx => dx = spring_curve(curve),
            Dof::Dy => dy = spring_curve(curve),
            Dof::Dz => dz = spring_curve(curve),
            Dof::Rx => rx = spring_curve(curve),
            Dof::Ry => ry = spring_curve(curve),
            Dof::Rz => rz = spring_curve(curve),
        }
    }

    let mut displacement_conditions = BTreeMap::new();
    displacement_conditions.insert("X".to_string(), dx);
    displacement_conditions.insert("Y".to_string(), dy);
    displacement_conditions.insert("Z".to_string(), dz);

    let mut rotation_conditions = BTreeMap::new();
    rotation_conditions.insert("X".to_string(), rx);
    rotation_conditions.insert("Y".to_string(), ry);
    rotation_conditions.insert("Z".to_string(), rz);

    NodalSupport {
        id,
        classification: None,
        displacement_conditions,
        rotation_conditions,
        warping_condition: None,
    }
}

/// Build a single-member cantilever with SYMMETRIC section (I_y = I_z).
fn build_symmetric_cantilever(
    support: NodalSupport,
) -> (fers_calculations::models::fers::fers::FERS, u32) {
    let mut model = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut model, 1);
    // Symmetric section: both I values equal → orientation doesn't matter
    let sec = add_section(
        &mut model, 1, "SYM",
        mat,
        26.2e-4,                         // area (m²)
        SECOND_MOMENT_STRONG_AXIS_IN_M4, // I_y
        SECOND_MOMENT_STRONG_AXIS_IN_M4, // I_z (same as I_y)
        1.0e-5,                          // J
    );

    model.nodal_supports.push(support);

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 0.0, 0.0, 3.0, None);
    let beam = make_beam_member(1, &n1, &n2, sec);
    add_member_set(&mut model, 1, vec![beam]);

    let lc = add_load_case(&mut model, 1, "LC1");
    (model, lc)
}

/// Get tip displacement for a model. `tip_node` is the free-end node id.
fn get_tip_disp(
    model: &fers_calculations::models::fers::fers::FERS,
    tip_node: u32,
) -> (f64, f64, f64) {
    let res = &model.results.as_ref().unwrap().loadcases["LC1"];
    let d = res.displacement_nodes.get(&tip_node).unwrap();
    (d.dx, d.dy, d.dz)
}

/// Solve second-order and denormalize.
fn solve(model: &mut fers_calculations::models::fers::fers::FERS, lc: u32) {
    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .expect("Second-order solve failed");
    denorm_results_in_place(model);
}

// ─────────────────────────────────────────────────────────────────────────────
// 131a — Rotation Ry curve depends on Vz (axial Z-reaction)
//
// Rotational spring Ry at support, stiffness depends on Vz.
// Two models with different axial loads (5 kN vs 80 kN) share the same
// lateral 1 kN X-load. Higher axial → stiffer Ry → less lateral deflection.
//
// EI/L ≈ 9.2e5 N·m, curve [1e4..1e7] spans meaningful spring regime.
// At 5 kN:  k ≈ 5.1e5  (k/3EI_L ≈ 0.18 → spring contributes 85% of total δ)
// At 80 kN: k ≈ 8.0e6  (k/3EI_L ≈ 2.9  → spring is stiffer, δ ≈ beam only)
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_131a_rot_ry_depends_on_vz() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::Vz,
        points: vec![
            [0.0, 1.0e4],       // soft at zero axial
            [100_000.0, 1.0e7], // stiff at 100 kN
        ],
    };

    // ── Low axial load (5 kN) → soft Ry spring ──
    let (mut m_low, lc) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Ry, curve.clone()),
    );
    add_nodal_load(&mut m_low, 1, lc, 2, 5_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_low, 2, lc, 2, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_low, lc);

    // ── High axial load (80 kN) → stiff Ry spring ──
    let (mut m_high, lc2) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Ry, curve),
    );
    add_nodal_load(&mut m_high, 1, lc2, 2, 80_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_high, 2, lc2, 2, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_high, lc2);

    let (dx_low, _, _) = get_tip_disp(&m_low, 2);
    let (dx_high, _, _) = get_tip_disp(&m_high, 2);

    assert!(dx_low.abs() > 1e-6, "Low-axial dx={dx_low}");
    assert!(dx_high.abs() > 1e-6, "High-axial dx={dx_high}");

    // Low axial → soft spring → MORE deflection. High axial → stiff spring → LESS.
    let ratio = dx_low.abs() / dx_high.abs();
    assert!(
        ratio > 1.5,
        "High-axial model should be stiffer. dx_low={dx_low}, dx_high={dx_high}, ratio={ratio}",
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 131b — Rotation Rx curve depends on Vy (lateral Y-reaction)
//
// Y-load bends about X → Rx is the active spring DOF.
// Higher Y-force → stiffer Rx → less normalized deflection.
// No axial load → no P-delta.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_131b_rot_rx_depends_on_vy() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::Vy,
        points: vec![
            [0.0, 1.0e4],
            [50_000.0, 1.0e7],
        ],
    };

    // ── Small Y-load → soft Rx spring ──
    let (mut m_soft, lc) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Rx, curve.clone()),
    );
    add_nodal_load(&mut m_soft, 1, lc, 2, 500.0, (0.0, 1.0, 0.0));
    solve(&mut m_soft, lc);

    // ── Large Y-load → stiff Rx spring ──
    let (mut m_stiff, lc2) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Rx, curve),
    );
    add_nodal_load(&mut m_stiff, 1, lc2, 2, 20_000.0, (0.0, 1.0, 0.0));
    solve(&mut m_stiff, lc2);

    let (_, dy_soft, _) = get_tip_disp(&m_soft, 2);
    let (_, dy_stiff, _) = get_tip_disp(&m_stiff, 2);

    assert!(dy_soft.abs() > 1e-6, "Soft dy={dy_soft}");
    assert!(dy_stiff.abs() > 1e-6, "Stiff dy={dy_stiff}");

    let norm_soft = dy_soft.abs() / 500.0;
    let norm_stiff = dy_stiff.abs() / 20_000.0;
    assert!(
        norm_soft > norm_stiff * 1.5,
        "Higher Vy should stiffen Rx. norm_soft={norm_soft}, norm_stiff={norm_stiff}",
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 131c — Rotation Ry curve depends on N (X-reaction at support)
//
// Self-driving: X-load creates bending AND drives the curve.
// Higher X-load → stiffer Ry → less normalized deflection.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_131c_rot_ry_depends_on_n() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::N,
        points: vec![
            [0.0, 1.0e4],
            [50_000.0, 1.0e7],
        ],
    };

    // ── Small lateral X → soft Ry ──
    let (mut m_soft, lc) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Ry, curve.clone()),
    );
    add_nodal_load(&mut m_soft, 1, lc, 2, 500.0, (1.0, 0.0, 0.0));
    solve(&mut m_soft, lc);

    // ── Large lateral X → stiff Ry ──
    let (mut m_stiff, lc2) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Ry, curve),
    );
    add_nodal_load(&mut m_stiff, 1, lc2, 2, 20_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_stiff, lc2);

    let (dx_soft, _, _) = get_tip_disp(&m_soft, 2);
    let (dx_stiff, _, _) = get_tip_disp(&m_stiff, 2);

    assert!(dx_soft.abs() > 1e-6, "Soft dx={dx_soft}");
    assert!(dx_stiff.abs() > 1e-6, "Stiff dx={dx_stiff}");

    let norm_soft = dx_soft.abs() / 500.0;
    let norm_stiff = dx_stiff.abs() / 20_000.0;
    assert!(
        norm_soft > norm_stiff * 1.5,
        "Higher N should stiffen Ry. norm_soft={norm_soft}, norm_stiff={norm_stiff}",
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 131d — Multiple curves on the same support
//
// Ry has a curve depending on Vz (axial),
// Rx has a curve depending on Vy (lateral Y-reaction).
// Both effects compound when loads increase.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_131d_multiple_curves_on_same_support() {
    let curve_ry = StiffnessCurveConfig {
        depends_on: ForceComponent::Vz,
        points: vec![
            [0.0, 1.0e4],
            [100_000.0, 1.0e7],
        ],
    };
    let curve_rx = StiffnessCurveConfig {
        depends_on: ForceComponent::Vy,
        points: vec![
            [0.0, 1.0e4],
            [50_000.0, 1.0e7],
        ],
    };

    // ── Soft: low axial + low Y-load → both springs soft ──
    let (mut m_soft, lc) = build_symmetric_cantilever(
        make_curve_support_multi(1, &[
            (Dof::Ry, curve_ry.clone()),
            (Dof::Rx, curve_rx.clone()),
        ]),
    );
    add_nodal_load(&mut m_soft, 1, lc, 2, 5_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_soft, 2, lc, 2, 1_000.0, (1.0, 0.0, 0.0));
    add_nodal_load(&mut m_soft, 3, lc, 2, 500.0, (0.0, 1.0, 0.0));
    solve(&mut m_soft, lc);

    // ── Stiff: high axial + high Y-load → both springs stiff ──
    let (mut m_stiff, lc2) = build_symmetric_cantilever(
        make_curve_support_multi(1, &[
            (Dof::Ry, curve_ry),
            (Dof::Rx, curve_rx),
        ]),
    );
    add_nodal_load(&mut m_stiff, 1, lc2, 2, 80_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_stiff, 2, lc2, 2, 1_000.0, (1.0, 0.0, 0.0));
    add_nodal_load(&mut m_stiff, 3, lc2, 2, 20_000.0, (0.0, 1.0, 0.0));
    solve(&mut m_stiff, lc2);

    // Check X-deflection: Ry stiffens with axial load
    let (dx_soft, _, _) = get_tip_disp(&m_soft, 2);
    let (dx_stiff, _, _) = get_tip_disp(&m_stiff, 2);
    assert!(dx_soft.abs() > 1e-6, "Soft dx={dx_soft}");
    assert!(dx_stiff.abs() > 1e-6, "Stiff dx={dx_stiff}");
    // Same 1 kN X-load in both, but Ry is stiffer in the stiff model
    assert!(
        dx_soft.abs() > dx_stiff.abs() * 1.5,
        "Higher Vz should stiffen Ry → less X-deflection. dx_soft={dx_soft}, dx_stiff={dx_stiff}",
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 131e — Constant curve matches regular Spring for each ForceComponent
//
// A constant stiffness curve must produce identical results to a regular
// Spring with that stiffness, regardless of which ForceComponent it uses.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_131e_constant_curve_matches_spring_all_components() {
    let k_rot = 1.0e5; // comparable to 3EI/L ≈ 2.77e6 → spring adds ~97% of beam δ
    let tol = 1.0e-4;

    // Reference: regular Spring on Ry
    let (mut m_ref, lc) = build_symmetric_cantilever({
        let mut sup = make_fixed_support(1);
        sup.rotation_conditions.insert(
            "Y".to_string(),
            SupportCondition {
                condition_type: SupportConditionType::Spring,
                stiffness: Some(k_rot),
                stiffness_curve: None,
            },
        );
        sup
    });
    add_nodal_load(&mut m_ref, 1, lc, 2, 50_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_ref, 2, lc, 2, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_ref, lc);
    let (dx_ref, dy_ref, dz_ref) = get_tip_disp(&m_ref, 2);

    for fc in &[
        ForceComponent::N,
        ForceComponent::Vy,
        ForceComponent::Vz,
        ForceComponent::Mx,
        ForceComponent::My,
        ForceComponent::Mz,
    ] {
        let curve = StiffnessCurveConfig {
            depends_on: *fc,
            points: vec![[0.0, k_rot], [1.0e9, k_rot]],
        };
        let (mut m_curve, lc_c) = build_symmetric_cantilever(
            make_curve_support(1, Dof::Ry, curve),
        );
        add_nodal_load(&mut m_curve, 1, lc_c, 2, 50_000.0, (0.0, 0.0, -1.0));
        add_nodal_load(&mut m_curve, 2, lc_c, 2, 1_000.0, (1.0, 0.0, 0.0));
        solve(&mut m_curve, lc_c);
        let (dx_c, dy_c, dz_c) = get_tip_disp(&m_curve, 2);

        let ctx = format!("131e {:?}", fc);
        assert_close_ctx(&ctx, dx_ref, dx_c, tol, "dx");
        assert_close_ctx(&ctx, dy_ref, dy_c, tol, "dy");
        assert_close_ctx(&ctx, dz_ref, dz_c, tol, "dz");
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 131f — Force-component isolation: curve depending on Vy is unaffected
//        by changing Vz when Vy stays zero.
//
// Apply Z + X loads only (no Y). The curve depends on Vy≈0 always.
// Changing Z-load should NOT change spring stiffness.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_131f_force_component_isolation() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::Vy,
        points: vec![
            [0.0, 1.0e6],       // at Vy=0 → 1 MN·m/rad (stiff enough for P-delta stability)
            [50_000.0, 1.0e8],   // at Vy=50kN → 100 MN·m/rad
        ],
    };

    // Model A: 5 kN axial + 1 kN lateral X (no Y-load)
    let (mut m_a, lc) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Ry, curve.clone()),
    );
    add_nodal_load(&mut m_a, 1, lc, 2, 5_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_a, 2, lc, 2, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_a, lc);

    // Model B: 20 kN axial + 1 kN lateral X (still no Y-load)
    let (mut m_b, lc2) = build_symmetric_cantilever(
        make_curve_support(1, Dof::Ry, curve),
    );
    add_nodal_load(&mut m_b, 1, lc2, 2, 20_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_b, 2, lc2, 2, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_b, lc2);

    let (dx_a, _, _) = get_tip_disp(&m_a, 2);
    let (dx_b, _, _) = get_tip_disp(&m_b, 2);

    // Both models evaluate curve at Vy≈0, so Ry stiffness is identical (1e6 N·m/rad).
    // Small difference comes from P-delta effects, so ratio should be close to 1.
    let ratio = dx_a.abs() / dx_b.abs();
    assert!(
        (0.5..=2.0).contains(&ratio),
        "With Vy≈0, spring stiffness should be equal. \
         dx_a={dx_a}, dx_b={dx_b}, ratio={ratio}",
    );
}
