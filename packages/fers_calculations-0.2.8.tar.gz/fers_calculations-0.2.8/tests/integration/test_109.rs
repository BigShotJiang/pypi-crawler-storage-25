use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 109: Pure end moment → shear deformation irrelevant
//
// Cantilever with end moment M. Shear force V=0 everywhere, so Timoshenko
// gives the same deflection as Euler-Bernoulli:
//   δ = ML²/(2EI),  θ = ML/(EI)
// ============================================================================
fn test_109_pure_moment_shear_irrelevant_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_109_pure_moment", strategy, lu, fu, pu);

    let l_si = 5.0_f64;
    let m_si = 5000.0_f64;
    let e_si = 210.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let a_sz_si = 25.68e-4_f64;

    let delta_analytical = m_si * l_si.powi(2) / (2.0 * e_si * i_z_si);
    let theta_analytical = m_si * l_si / (e_si * i_z_si);

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x2 = l_si / l;
    let m_user = m_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_T", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        None, None, Some(a_sz_si),
    );

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m1]);

    let lc_id = add_load_case(&mut model, 1, "End Moment");
    add_nodal_moment(&mut model, 1, lc_id, 2, m_user, (0.0, 0.0, -1.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["End Moment"];
    let dy_end = res.displacement_nodes[&2].dy;
    let rz_end = res.displacement_nodes[&2].rz;

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);

    assert_close_ctx(&ctx, -delta_analytical / l, dy_end, tol_d, "moment: deflection = EB");
    assert_close_ctx(&ctx, -theta_analytical, rz_end, TOL_ABSOLUTE_ROTATION_IN_RADIAN, "moment: rotation = EB");
}

#[test]
fn test_109_pure_moment_shear_irrelevant() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_109_pure_moment_shear_irrelevant_case(strategy, lu, fu, pu);
        }
    }
}
