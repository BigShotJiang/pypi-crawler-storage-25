// tests/integration/test_133_frame_stiffness_curve.rs
//
// 133 — Small portal frame on stiffness-curve supports
//
// Reproduces the shuttle-rack–like scenario: a rectangular frame on 4 columns
// whose base supports have rotational stiffness curves that depend on the
// vertical reaction force.
//
// Geometry (Y-up, matching shuttle rack convention):
//   4 base nodes at Y=0: (0,0,0), (1.2,0,0), (0,0,1.4), (1.2,0,1.4)
//   4 top  nodes at Y=3: (0,3,0), (1.2,3,0), (0,3,1.4), (1.2,3,1.4)
//   4 columns (vertical, along Y), 4 beams (connecting tops)
//
// Support: Fixed in all displacements, fixed in RX, RY; curve spring on RZ.
//   The RZ curve depends on ForceComponent::Vy (vertical reaction),
//   using a simplified version of the upright_90 BLS data.
//
// Loads:
//   LC1 — gravity-like (vertical Y) + small lateral (X)
//   If the depends_on is set to the WRONG force component, the curve
//   evaluates at near-zero → minimum stiffness → convergence failure.

use std::collections::BTreeMap;

use super::test_support::helpers::*;
use super::test_support::*;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::stiffness_curve::{ForceComponent, StiffnessCurveConfig};
use fers_calculations::models::supports::nodalsupport::NodalSupport;
use fers_calculations::models::supports::supportcondition::SupportCondition;
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

// ═════════════════════════════════════════════════════════════════════════════
// Helpers
// ═════════════════════════════════════════════════════════════════════════════

/// Stiffness curve scaled so the spring dominates the column bending stiffness.
/// With the weak column section (I = 1.321e-7), 4EI/L ≈ 37 kN·m/rad.
/// The curve spans 500 → 100,000 N·m/rad, so the spring is comparable to or
/// larger than the column stiffness across the force range.
fn scaled_curve(depends_on: ForceComponent) -> StiffnessCurveConfig {
    StiffnessCurveConfig {
        depends_on,
        points: vec![
            [500.0,    500.0],
            [5_000.0,  40_000.0],
            [10_000.0, 70_000.0],
            [20_000.0, 110_000.0],
            [40_000.0, 140_000.0],
            [60_000.0, 160_000.0],
            [100_000.0, 200_000.0],
        ],
    }
}

/// Shuttle-rack–realistic curve: very soft relative to section stiffness.
/// Uses actual upright_90 BLS data (in N·m/rad after mm→m conversion).
fn upright_90_curve(depends_on: ForceComponent) -> StiffnessCurveConfig {
    StiffnessCurveConfig {
        depends_on,
        points: vec![
            [1_000.0, 4.546],
            [10_000.0, 40.617],
            [20_000.0, 71.512],
            [30_000.0, 94.341],
            [40_000.0, 110.760],
            [50_000.0, 122.425],
            [60_000.0, 130.992],
            [70_000.0, 138.117],
            [80_000.0, 145.456],
        ],
    }
}

/// Build a support with all DOFs fixed except RZ which gets a stiffness curve.
fn make_rz_curve_support(id: u32, curve: StiffnessCurveConfig) -> NodalSupport {
    let fixed = || SupportCondition {
        condition_type: SupportConditionType::Fixed,
        stiffness: None,
        stiffness_curve: None,
    };
    let spring_curve = |c: StiffnessCurveConfig| SupportCondition {
        condition_type: SupportConditionType::Spring,
        stiffness: None,
        stiffness_curve: Some(c),
    };

    let mut dc = BTreeMap::new();
    dc.insert("X".to_string(), fixed());
    dc.insert("Y".to_string(), fixed());
    dc.insert("Z".to_string(), fixed());

    let mut rc = BTreeMap::new();
    rc.insert("X".to_string(), fixed());
    rc.insert("Y".to_string(), fixed());
    rc.insert("Z".to_string(), spring_curve(curve));

    NodalSupport {
        id,
        classification: None,
        displacement_conditions: dc,
        rotation_conditions: rc,
        warping_condition: None,
    }
}

/// Build the 4-column portal frame on stiffness curve supports.
/// Uses a WEAK column section so that the base rotational spring dominates.
fn build_portal_frame(
    curve: StiffnessCurveConfig,
) -> (fers_calculations::models::fers::fers::FERS, u32) {
    let mut model = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut model, 1);
    // Weak column section: I reduced by 100× from IPE-like to make spring dominant.
    // 4EI/L = 4 * 210e9 * 1.321e-7 / 3 = 36,988 N·m/rad
    // The curve starts at k=500 (much softer) and goes to 200,000 (much stiffer).
    let i_weak = SECOND_MOMENT_STRONG_AXIS_IN_M4 / 100.0; // 1.321e-7 m⁴
    let sec_col = add_section(
        &mut model, 1, "COL",
        mat,
        26.2e-4,   // area (keep adequate for axial)
        i_weak,    // I_y (weak)
        i_weak,    // I_z (symmetric)
        1.0e-5,    // J
    );
    // Beam section: same weak section
    let sec_beam = sec_col;

    // 4 supports, one per base node
    for id in 1..=4u32 {
        model.nodal_supports.push(make_rz_curve_support(id, curve.clone()));
    }

    // Base nodes (Y=0)
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.2, 0.0, 0.0, Some(2));
    let n3 = make_node(3, 0.0, 0.0, 1.4, Some(3));
    let n4 = make_node(4, 1.2, 0.0, 1.4, Some(4));

    // Top nodes (Y=3)
    let n5 = make_node(5, 0.0, 3.0, 0.0, None);
    let n6 = make_node(6, 1.2, 3.0, 0.0, None);
    let n7 = make_node(7, 0.0, 3.0, 1.4, None);
    let n8 = make_node(8, 1.2, 3.0, 1.4, None);

    // 4 columns
    let col1 = make_beam_member(1, &n1, &n5, sec_col);
    let col2 = make_beam_member(2, &n2, &n6, sec_col);
    let col3 = make_beam_member(3, &n3, &n7, sec_col);
    let col4 = make_beam_member(4, &n4, &n8, sec_col);

    // 4 beams connecting tops
    let beam1 = make_beam_member(5, &n5, &n6, sec_beam);
    let beam2 = make_beam_member(6, &n7, &n8, sec_beam);
    let beam3 = make_beam_member(7, &n5, &n7, sec_beam);
    let beam4 = make_beam_member(8, &n6, &n8, sec_beam);

    add_member_set(&mut model, 1, vec![col1, col2, col3, col4, beam1, beam2, beam3, beam4]);

    let lc = add_load_case(&mut model, 1, "LC1");
    (model, lc)
}

fn solve(model: &mut fers_calculations::models::fers::fers::FERS, lc: u32) {
    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .expect("Second-order solve failed");
    denorm_results_in_place(model);
}

fn get_tip_disp(
    model: &fers_calculations::models::fers::fers::FERS,
    node: u32,
) -> (f64, f64, f64) {
    let res = &model.results.as_ref().unwrap().loadcases["LC1"];
    let d = res.displacement_nodes.get(&node).unwrap();
    (d.dx, d.dy, d.dz)
}

// ─────────────────────────────────────────────────────────────────────────────
// 133a — Frame with correct depends_on (Vy = vertical reaction)
//
// Gravity loads on top nodes (-Y), plus small lateral (X).
// RZ curve depends on Vy → evaluates at the vertical reaction (~25 kN per
// column) → meaningful stiffness → should converge.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_133a_frame_curve_depends_on_vy() {
    let (mut model, lc) = build_portal_frame(scaled_curve(ForceComponent::Vy));

    // 5 kN vertical load on each top node + 500 N lateral
    // (kept low: weak section N_cr ≈ 30–60 kN per column)
    for nid in 5..=8 {
        add_nodal_load(&mut model, nid * 10, lc, nid, 5_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut model, 100, lc, 5, 500.0, (1.0, 0.0, 0.0));

    solve(&mut model, lc);

    let (dx, dy, _) = get_tip_disp(&model, 5);
    assert!(dy.abs() > 1e-6, "Should have vertical deflection: dy={dy}");
    assert!(dx.abs() > 1e-6, "Should have lateral deflection: dx={dx}");
}

// ─────────────────────────────────────────────────────────────────────────────
// 133b — Frame with WRONG depends_on (Vz = near-zero for this geometry)
//
// Reduced loads (2 kN vertical per column, 500 N lateral) to stay well below
// the buckling limit (N/P_cr ≈ 0.21).  RZ curve depends on Vz → evaluates
// at ~0 → minimum stiffness (k=500 N·m/rad).  With Vy the curve gives
// k ≈ 13,600 → stiffer → less lateral deflection.
// ─────────────────────────────────────────────────────────────────────────────

/// Build a support with constant spring on RZ (no curve)
fn make_rz_constant_support(id: u32, k_rz: f64) -> NodalSupport {
    let fixed = || SupportCondition {
        condition_type: SupportConditionType::Fixed,
        stiffness: None,
        stiffness_curve: None,
    };
    let spring = |k: f64| SupportCondition {
        condition_type: SupportConditionType::Spring,
        stiffness: Some(k),
        stiffness_curve: None,
    };

    let mut dc = BTreeMap::new();
    dc.insert("X".to_string(), fixed());
    dc.insert("Y".to_string(), fixed());
    dc.insert("Z".to_string(), fixed());

    let mut rc = BTreeMap::new();
    rc.insert("X".to_string(), fixed());
    rc.insert("Y".to_string(), fixed());
    rc.insert("Z".to_string(), spring(k_rz));

    NodalSupport {
        id,
        classification: None,
        displacement_conditions: dc,
        rotation_conditions: rc,
        warping_condition: None,
    }
}

/// Build the same portal frame but with a constant spring stiffness (no curve).
fn build_portal_frame_constant_spring(
    k_rz: f64,
) -> (fers_calculations::models::fers::fers::FERS, u32) {
    let mut model = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut model, 1);
    let i_weak = SECOND_MOMENT_STRONG_AXIS_IN_M4 / 100.0;
    let sec_col = add_section(
        &mut model, 1, "COL", mat,
        26.2e-4, i_weak, i_weak, 1.0e-5,
    );
    for id in 1..=4u32 {
        model.nodal_supports.push(make_rz_constant_support(id, k_rz));
    }
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.2, 0.0, 0.0, Some(2));
    let n3 = make_node(3, 0.0, 0.0, 1.4, Some(3));
    let n4 = make_node(4, 1.2, 0.0, 1.4, Some(4));
    let n5 = make_node(5, 0.0, 3.0, 0.0, None);
    let n6 = make_node(6, 1.2, 3.0, 0.0, None);
    let n7 = make_node(7, 0.0, 3.0, 1.4, None);
    let n8 = make_node(8, 1.2, 3.0, 1.4, None);
    let col1 = make_beam_member(1, &n1, &n5, sec_col);
    let col2 = make_beam_member(2, &n2, &n6, sec_col);
    let col3 = make_beam_member(3, &n3, &n7, sec_col);
    let col4 = make_beam_member(4, &n4, &n8, sec_col);
    let beam1 = make_beam_member(5, &n5, &n6, sec_col);
    let beam2 = make_beam_member(6, &n7, &n8, sec_col);
    let beam3 = make_beam_member(7, &n5, &n7, sec_col);
    let beam4 = make_beam_member(8, &n6, &n8, sec_col);
    add_member_set(&mut model, 1, vec![col1, col2, col3, col4, beam1, beam2, beam3, beam4]);
    let lc = add_load_case(&mut model, 1, "LC1");
    (model, lc)
}

#[test]
fn test_133b_wrong_depends_on_gives_softer_response() {
    // First: verify the geometry IS sensitive to spring stiffness using constant springs.
    // With 2 kN vertical per column (N/P_cr ≈ 0.21, safe from bifurcation):
    //   Vy curve at ~2 kN → k ≈ 13,600 N·m/rad  (stiff)
    //   Vz curve at ~0    → k =    500 N·m/rad  (soft, minimum of curve)
    let (mut m_stiff, lc_s) = build_portal_frame_constant_spring(13_000.0);
    for nid in 5..=8 {
        add_nodal_load(&mut m_stiff, nid * 10, lc_s, nid, 2_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut m_stiff, 100, lc_s, 5, 500.0, (1.0, 0.0, 0.0));
    solve(&mut m_stiff, lc_s);
    let (dx_stiff, _, _) = get_tip_disp(&m_stiff, 5);

    let (mut m_soft, lc_t) = build_portal_frame_constant_spring(500.0);
    for nid in 5..=8 {
        add_nodal_load(&mut m_soft, nid * 10, lc_t, nid, 2_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut m_soft, 100, lc_t, 5, 500.0, (1.0, 0.0, 0.0));
    solve(&mut m_soft, lc_t);
    let (dx_soft, _, _) = get_tip_disp(&m_soft, 5);

    eprintln!("  dx_stiff(k=13K)  = {dx_stiff}");
    eprintln!("  dx_soft(k=500)   = {dx_soft}");
    eprintln!("  ratio = {}", dx_soft.abs() / dx_stiff.abs());

    // Verify constant springs give different results (geometry is sensitive)
    assert!(
        dx_soft.abs() > dx_stiff.abs() * 1.5,
        "Geometry must be sensitive to spring stiffness: soft={dx_soft}, stiff={dx_stiff}"
    );

    // Now test with curves: Vy (correct) should give stiffer springs → less deflection
    let (mut m_correct, lc) = build_portal_frame(scaled_curve(ForceComponent::Vy));
    for nid in 5..=8 {
        add_nodal_load(&mut m_correct, nid * 10, lc, nid, 2_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut m_correct, 100, lc, 5, 500.0, (1.0, 0.0, 0.0));
    solve(&mut m_correct, lc);

    // Vz (wrong) evaluates curve at near-zero → minimum stiffness (k≈500) → more deflection
    let (mut m_wrong, lc2) = build_portal_frame(scaled_curve(ForceComponent::Vz));
    for nid in 5..=8 {
        add_nodal_load(&mut m_wrong, nid * 10, lc2, nid, 2_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut m_wrong, 100, lc2, 5, 500.0, (1.0, 0.0, 0.0));
    solve(&mut m_wrong, lc2);

    let (dx_correct, _, _) = get_tip_disp(&m_correct, 5);
    let (dx_wrong, _, _) = get_tip_disp(&m_wrong, 5);

    eprintln!("  dx_correct(Vy curve) = {dx_correct}");
    eprintln!("  dx_wrong(Vz curve)   = {dx_wrong}");

    assert!(
        dx_wrong.abs() > dx_correct.abs() * 1.2,
        "Wrong depends_on should give larger deflection: wrong={dx_wrong}, correct={dx_correct}"
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 133c — Higher load level (shuttle rack–like: ~50 kN per column)
//
// Tests convergence with heavier loading typical of a loaded shuttle rack.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_133c_frame_heavy_load() {
    let (mut model, lc) = build_portal_frame(scaled_curve(ForceComponent::Vy));

    // 10 kN vertical per column + 1 kN lateral
    // (moderate load for weak section; well below N_cr)
    for nid in 5..=8 {
        add_nodal_load(&mut model, nid * 10, lc, nid, 10_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut model, 100, lc, 5, 1_000.0, (1.0, 0.0, 0.0));
    add_nodal_load(&mut model, 101, lc, 7, 1_000.0, (1.0, 0.0, 0.0));

    solve(&mut model, lc);

    let (dx, dy, _) = get_tip_disp(&model, 5);
    assert!(dy.abs() > 1e-6, "Heavy load: dy={dy}");
    assert!(dx.abs() > 1e-6, "Heavy load: dx={dx}");
}

// ─────────────────────────────────────────────────────────────────────────────
// 133d — Backward compat: bare array deserialization
//
// Verify that a model with the old JSON format (bare stiffness_curve array,
// "StiffnessCurve" condition type) deserializes and solves correctly.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_133d_backward_compat_bare_array() {
    // Construct a support condition using JSON with the old format
    let json_str = r#"{
        "condition_type": "StiffnessCurve",
        "stiffness": null,
        "stiffness_curve": [[1000, 4.546], [80000, 145.456]]
    }"#;

    let cond: SupportCondition = serde_json::from_str(json_str).unwrap();
    assert!(matches!(cond.condition_type, SupportConditionType::Spring));
    let curve = cond.stiffness_curve.as_ref().unwrap();
    // Bare array defaults to Vz
    assert_eq!(curve.depends_on, ForceComponent::Vz);
    assert_eq!(curve.points.len(), 2);
}

// ─────────────────────────────────────────────────────────────────────────────
// 133e — Soft springs (shuttle-rack–realistic values)
//
// Uses actual upright_90 BLS stiffness data. The springs are very soft
// relative to column EI/L, so the structure is essentially pinned at the base.
// This should still converge since a pinned frame is valid.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_133e_soft_springs_shuttle_rack_like() {
    let (mut model, lc) = build_portal_frame(upright_90_curve(ForceComponent::Vy));

    // Light loads: 5 kN vertical + 500 N lateral (well below pinned-base N_cr)
    for nid in 5..=8 {
        add_nodal_load(&mut model, nid * 10, lc, nid, 5_000.0, (0.0, -1.0, 0.0));
    }
    add_nodal_load(&mut model, 100, lc, 5, 500.0, (1.0, 0.0, 0.0));

    solve(&mut model, lc);

    let (dx, dy, _) = get_tip_disp(&model, 5);
    assert!(dy.abs() > 1e-6, "Soft springs: dy={dy}");
    assert!(dx.abs() > 1e-6, "Soft springs: dx={dx}");
}
