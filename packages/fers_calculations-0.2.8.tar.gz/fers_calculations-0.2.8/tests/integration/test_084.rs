use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  084 — Triple cantilever 3D (three orthogonal beams)
//
//  N1(0,0,0) ── beam1(X) ── N2(1,0,0) ── beam2(Y) ── N3(1,1,0) ── beam3(Z) ── N4(1,1,1)
//                                                                                  ↑
//                                                                        F = −1000 N in Y
//
//  Support:   N1 fully fixed
//  Checks:    Force & moment equilibrium at fixed support
// ─────────────────────────────────────────────────────────────────────────────

fn test_084_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("084_3d_triple", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let arm_si = 1.0_f64;
    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let arm = arm_si / l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, arm, 0.0, 0.0, None);
    let n3 = make_node(3, arm, arm, 0.0, None);
    let n4 = make_node(4, arm, arm, arm, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_beam_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, force_u, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Force equilibrium
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx(&ctx, force_u, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f, "Rx.fz");

    // Moment equilibrium about origin
    // r × F = (1,1,1) × (0,−1000,0) = (1000, 0, −1000)
    // → reaction moments = (−1000, 0, 1000) N·m
    assert_close_ctx(&ctx, -1000.0 / fl, rx.mx, tol_m, "Rx.mx");
    assert_close_ctx(&ctx, 0.0, rx.my, tol_m, "Rx.my");
    assert_close_ctx(&ctx, 1000.0 / fl, rx.mz, tol_m, "Rx.mz");
}

#[test]
fn test_084_triple_cantilever_3d_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_084_case(s, lu, fu, pu);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  084 — Second-order (Updated Lagrangian)
//
//  Same geometry but solved with P-Δ + UL T-updates.
//  Global force equilibrium must still hold; moment equilibrium is checked
//  against reference values from SkyCiv (~1347 N·m for Mx due to large rotation).
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_second_order_equilibrium() {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::M;
    let fu = ForceUnit::N;
    let pu = PressureUnit::Pa;
    let ctx = make_ctx("084_second_order", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.0, 0.0, 0.0, None);
    let n3 = make_node(3, 1.0, 1.0, 0.0, None);
    let n4 = make_node(4, 1.0, 1.0, 1.0, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_beam_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, 1000.0, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    // Force equilibrium (K_elastic + T_def tolerance: tiny off-axis from deformed frame)
    let tol_f_so = tol_force_user(0.2, 1.0);
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f_so, "Rx.fx");
    assert_close_ctx(&ctx, 1000.0, rx.fy, tol_f_so, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f_so, "Rx.fz");

    // Moment equilibrium: Mx = −1000 N·m, Mz = +1000 N·m (F×arm statics).
    // With stiff IPE-180 section and 1 m arms, deflection ≈ 1.6 mm,
    // so second-order shift is negligible and both moments ≈ first-order.
    let tol_m_so = tol_moment_user(50.0, 1.0, 1.0);
    assert_close_ctx(&ctx, -1000.0, rx.mx, tol_m_so, "Rx.mx");
    assert_close_ctx(&ctx, 1000.0, rx.mz, tol_m_so, "Rx.mz");

    // ── Displacement & rotation cross-check against analytical first-order ──
    //
    // Analytical (first-order, L=1m, F=1000N, E=210GPa, G=81GPa,
    //             I_z=13.21e-6, J=1e-5, A=26.2e-4):
    //
    //   N2: dy = -FL³/(3EI_z) = -0.1202 mm
    //       rx = TL/(GJ)      =  1.2346 mrad   (torsion from 1000 Nm)
    //       rz = -FL²/(2EI_z) = -0.1802 mrad
    //
    //   N3: dx =  0.1802 mm   (member 1 bending rotation × L_m2)
    //       dz =  1.4148 mm   (torsion twist × L_m2 + member 2 bending)
    //       rx =  1.5950 mrad (torsion + member 2 bending rotation)
    //
    //   N4: dy = -1.8372 mm   (N3 dy + rx_N3 × L_m3 + member 3 bending)
    //
    // Second-order shifts are <1% for this stiff section.
    // Use 1% relative tolerance (minimum 0.005 mm / 0.005 mrad absolute).

    let d2 = r.displacement_nodes.get(&2).unwrap();
    let d3 = r.displacement_nodes.get(&3).unwrap();
    let d4 = r.displacement_nodes.get(&4).unwrap();

    // Tolerances: 1% of expected value, floor of 5e-6 m / 5e-6 rad
    let tol_d = |expected_mm: f64| -> f64 {
        let abs_tol = expected_mm.abs() * 0.01;
        if abs_tol < 0.005 { 0.005 } else { abs_tol } // mm
    };
    let tol_r = |expected_mrad: f64| -> f64 {
        let abs_tol = expected_mrad.abs() * 0.01;
        if abs_tol < 0.005 { 0.005 } else { abs_tol } // mrad
    };

    // N2 displacements (mm) and rotations (mrad)
    assert_close_ctx(&ctx, -0.1202, d2.dy * 1e3, tol_d(0.1202), "N2.dy [mm]");
    assert_close_ctx(&ctx,  1.2346, d2.rx * 1e3, tol_r(1.2346), "N2.rx [mrad]");
    assert_close_ctx(&ctx, -0.1802, d2.rz * 1e3, tol_r(0.1802), "N2.rz [mrad]");

    // N3 displacements (mm) and rotations (mrad)
    assert_close_ctx(&ctx,  0.1802, d3.dx * 1e3, tol_d(0.1802), "N3.dx [mm]");
    assert_close_ctx(&ctx,  1.4148, d3.dz * 1e3, tol_d(1.4148), "N3.dz [mm]");
    assert_close_ctx(&ctx,  1.5950, d3.rx * 1e3, tol_r(1.5950), "N3.rx [mrad]");

    // N4 displacements (mm)
    assert_close_ctx(&ctx, -1.8372, d4.dy * 1e3, tol_d(1.8372), "N4.dy [mm]");
    assert_close_ctx(&ctx,  1.4148, d4.dz * 1e3, tol_d(1.4148), "N4.dz [mm]");
    assert_close_ctx(&ctx,  1.7753, d4.rx * 1e3, tol_r(1.7753), "N4.rx [mrad]");
}
