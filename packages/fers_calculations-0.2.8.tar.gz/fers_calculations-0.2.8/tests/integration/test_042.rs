use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::formulas::*;
use super::test_support::helpers::*;
use super::test_support::*;

// ---------------------------------------------------------
// 042: Rigid member reversed
// ---------------------------------------------------------

fn test_042_rigid_member_reversed_end_load_case(
    strategy: RigidStrategy,
    length_unit: LengthUnit,
    force_unit: ForceUnit,
    pressure_unit: PressureUnit,
) {
    let ctx = make_ctx(
        "test_042_rigid_member_reversed_end_load",
        strategy,
        length_unit,
        force_unit,
        pressure_unit,
    );
    let mut model =
        make_fers_with_strategy_and_units(strategy, length_unit, force_unit, pressure_unit);

    // Physical SI
    let length_elastic_si = 5.0_f64;
    let length_rigid_si = 5.0_f64;
    let total_length_si = length_elastic_si + length_rigid_si;
    let force_si = 1000.0_f64;
    let e_si = 210.0e9_f64;
    let i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let length_elastic = length_elastic_si / l;
    let length_rigid = length_rigid_si / l;
    let total_length = total_length_si / l;
    let force_user = force_si / f;

    let material_id = add_material_s235(&mut model, 1);
    let section_id = add_section_ipe180_like(&mut model, 1, material_id, i_zz);

    model.nodal_supports.push(make_fixed_support(1));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_elastic, 0.0, 0.0, None);
    let node3 = make_node(3, total_length, 0.0, 0.0, None);

    let beam_member = make_beam_member(1, &node1, &node2, section_id);
    let rigid_member_reversed = make_rigid_member(2, &node3, &node2);
    add_member_set(&mut model, 1, vec![beam_member, rigid_member_reversed]);

    let load_case_id = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, load_case_id, 2, force_user, (0.0, -1.0, 0.0));
    model.normalize_units();
    model
        .solve_for_load_case(load_case_id)
        .expect("Analysis failed");
    denorm_results_in_place(&mut model);
    let results = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("End Load")
        .unwrap();

    let dy_2 = results.displacement_nodes.get(&2).unwrap().dy;
    let dy_3 = results.displacement_nodes.get(&3).unwrap().dy;
    let rz_2 = results.displacement_nodes.get(&2).unwrap().rz;
    let rz_3 = results.displacement_nodes.get(&3).unwrap().rz;
    let mz_1 = results.reaction_nodes.get(&1).unwrap().nodal_forces.mz;

    // Expected in SI
    let dy_expected_si =
        cantilever_end_point_load_deflection_at_free_end(force_si, length_elastic_si, e_si, i_zz);
    let mz_expected_si =
        cantilever_end_point_load_fixed_end_moment_magnitude(force_si, length_elastic_si);
    let rz_expected = -force_si * length_elastic_si.powi(2) / (2.0 * e_si * i_zz);

    // Back to user
    let dy_expected = dy_expected_si / l;
    let mz_expected = mz_expected_si / (f * l);
    let dy_end_from_mid = dy_2 + length_rigid * rz_2;

    let tol_dy = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_mz = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);
    let tol_rz = TOL_ABSOLUTE_ROTATION_IN_RADIAN;

    assert_close_ctx(&ctx, dy_2, dy_expected, tol_dy, "deflection at node 2");
    assert_close_ctx(
        &ctx,
        mz_1.abs(),
        mz_expected,
        tol_mz,
        "moment at fixed support",
    );
    assert!((rz_2 - rz_3).abs() < tol_rz);
    assert!((rz_2 - rz_expected).abs() < tol_rz);
    assert_close_ctx(&ctx, dy_3, dy_end_from_mid, tol_dy, "deflection at node 3");
}

#[test]
fn test_042_rigid_member_reversed_end_load() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_042_rigid_member_reversed_end_load_case(strategy, lu, fu, pu);
        }
    }
}
