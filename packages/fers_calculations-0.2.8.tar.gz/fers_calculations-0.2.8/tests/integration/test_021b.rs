use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// =========================================================
// 021b: Cantilever with moment applied AT the fixed support
// =========================================================
//
// This test exposes a sign bug in the reaction computation:
// when an external load is applied directly at a supported node
// on a FIXED DOF, the reaction must account for it correctly.
//
// Geometry:
//   node1 (0,0,0) [fixed] ---- node2 (L,0,0) [free]
//
// Loading:
//   Nodal moment Mz = -M0 at node1 (the fixed support)
//
// Since the support is fully fixed, node1 cannot rotate.
// The beam does not deform (all displacements = 0).
// The reaction moment must balance the applied moment:
//   R_mz = +M0  (opposing the applied -M0)
//
// Member end forces are all zero (no deformation).

fn test_021b_cantilever_moment_at_fixed_end_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx(
        "test_021b_cantilever_moment_at_fixed_end",
        strategy,
        lu,
        fu,
        pu,
    );

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    // Physical (SI)
    let l_si = 5.0_f64;
    let m0_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x1 = 0.0;
    let x2 = l_si / l;
    let m0_user = m0_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, x1, 0.0, 0.0, Some(1)); // fixed end
    let n2 = make_node(2, x2, 0.0, 0.0, None); // free end
    let beam = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![beam]);

    let lc_id = add_load_case(&mut model, 1, "Moment at fixed end");

    // Apply moment -M0 at the fixed support (node 1)
    add_nodal_moment(&mut model, 1, lc_id, 1, m0_user, (0.0, 0.0, -1.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("Moment at fixed end")
        .unwrap();

    let dy_free = res.displacement_nodes[&2].dy;
    let mz_reaction = res.reaction_nodes[&1].nodal_forces.mz;

    // The beam should not deform (all load is at the fixed support)
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Applied Mz = -M0 at node 1. Support is fixed → reaction Mz = +M0.
    let mz_reaction_exp = m0_user;

    assert_close_ctx(
        &ctx,
        dy_free,
        0.0,
        tol_d,
        "free end should have zero deflection",
    );
    assert_close_ctx(
        &ctx,
        mz_reaction,
        mz_reaction_exp,
        tol_m,
        "reaction moment Mz at fixed support (should oppose applied moment)",
    );
}

#[test]
fn test_021b_cantilever_moment_at_fixed_end() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_021b_cantilever_moment_at_fixed_end_case(strategy, lu, fu, pu);
        }
    }
}
