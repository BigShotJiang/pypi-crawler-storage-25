use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::members::memberhinge::MemberHinge;

use super::test_support::helpers::*;
use super::test_support::*;

// ---------------------------------------------------------
// 051: Member hinge with root rotational spring
// ---------------------------------------------------------

fn test_051_member_hinge_root_rotational_spring_case(
    strategy: RigidStrategy,
    length_unit: LengthUnit,
    force_unit: ForceUnit,
    pressure_unit: PressureUnit,
) {
    // First-order model
    let ctx = make_ctx(
        "test_051_member_hinge_root_rotational_spring",
        strategy,
        length_unit,
        force_unit,
        pressure_unit,
    );
    let mut model =
        make_fers_with_strategy_and_units(strategy, length_unit, force_unit, pressure_unit);

    // Physical SI
    let length_rigid_si = 2.5_f64;
    let length_elastic_si = 2.5_f64;
    let total_length_si = length_rigid_si + length_elastic_si;
    let force_si = 1000.0_f64;
    let target_root_rotation_rad = 0.1_f64;
    let e_si = 210.0e9_f64;
    let i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let length_rigid = length_rigid_si / l;
    let total_length = total_length_si / l;
    let force_user = force_si / f;

    // Material and section
    let material_id = add_material_s235(&mut model, 1);
    let section_id = add_section_ipe180_like(&mut model, 1, material_id, i_zz);

    model.nodal_supports.push(make_fixed_support(1));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_rigid, 0.0, 0.0, None);
    let node3 = make_node(3, total_length, 0.0, 0.0, None);

    let rigid_member = make_rigid_member(1, &node1, &node2);
    let mut elastic_member = make_beam_member(2, &node2, &node3, section_id);

    // Rotational spring stiffness: define in SI, store in user units.
    let k_phi_z_si = (force_si * length_elastic_si) / target_root_rotation_rad; // [N·m/rad]
    let k_phi_z_user = k_phi_z_si / (f * l); // inverse of normalize (which multiplies by f*l)

    let hinge_id = 1_u32;
    let hinge = MemberHinge {
        id: hinge_id,
        hinge_type: "SPRING_Z".to_string(),
        translational_release_vx: None,
        translational_release_vy: None,
        translational_release_vz: None,
        rotational_release_mx: None,
        rotational_release_my: None,
        rotational_release_mz: Some(k_phi_z_user),
        rotational_release_warp: None,
        max_tension_vx: None,
        max_tension_vy: None,
        max_tension_vz: None,
        max_moment_mx: None,
        max_moment_my: None,
        max_moment_mz: None,
        max_bimoment_warp: None,
        stiffness_curve_vx: None,
        stiffness_curve_vy: None,
        stiffness_curve_vz: None,
        stiffness_curve_mx: None,
        stiffness_curve_my: None,
        stiffness_curve_mz: None,
    };

    if model.memberhinges.is_none() {
        model.memberhinges = Some(Vec::new());
    }
    model.memberhinges.as_mut().unwrap().push(hinge);
    elastic_member.start_hinge = Some(hinge_id);

    add_member_set(&mut model, 1, vec![rigid_member, elastic_member]);

    let load_case_id = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, load_case_id, 3, force_user, (0.0, -1.0, 0.0));
    model.normalize_units();
    model
        .solve_for_load_case(load_case_id)
        .expect("First-order analysis failed");
    denorm_results_in_place(&mut model);
    let results = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("End Load")
        .unwrap();

    let dy_3 = results.displacement_nodes.get(&3).unwrap().dy;
    let rz_3 = results.displacement_nodes.get(&3).unwrap().rz;
    let mz_1 = results.reaction_nodes.get(&1).unwrap().nodal_forces.mz;
    let fy_1 = results.reaction_nodes.get(&1).unwrap().nodal_forces.fy;

    // Expected in SI (your original formulas)
    let phi_root_expected = (force_si * length_elastic_si) / k_phi_z_si;
    let phi_tip_expected =
        -((force_si * length_elastic_si.powi(2)) / (2.0 * e_si * i_zz) + phi_root_expected);
    let deflection_tip_expected_si = -((force_si * length_elastic_si.powi(3))
        / (3.0 * e_si * i_zz)
        + phi_root_expected * length_elastic_si);
    let reaction_mz_expected_si = force_si * (length_elastic_si + length_rigid_si);

    // Convert expectations to user units
    let deflection_tip_expected = deflection_tip_expected_si / l;
    let reaction_mz_expected = reaction_mz_expected_si / (f * l);
    let force_expected_user = force_si / f; // should equal fy_1

    let tol_dy = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_mz = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_rz = TOL_ABSOLUTE_ROTATION_IN_RADIAN;

    // First-order assertions
    assert_close_ctx(
        &ctx,
        dy_3,
        deflection_tip_expected,
        tol_dy,
        "deflection at node 3",
    );
    assert_close_ctx(
        &ctx,
        fy_1,
        force_expected_user,
        tol_f,
        "force at fixed support",
    );
    assert_close_ctx(&ctx, rz_3, phi_tip_expected, tol_rz, "rotation at node 3");
    assert_close_ctx(
        &ctx,
        mz_1.abs(),
        reaction_mz_expected,
        tol_mz,
        "moment at fixed support",
    );

    // Second-order sanity (same setup, second-order solver)
    let mut model_so =
        make_fers_with_strategy_and_units(strategy, length_unit, force_unit, pressure_unit);

    let material_id_so = add_material_s235(&mut model_so, 1);
    let section_id_so = add_section_ipe180_like(&mut model_so, 1, material_id_so, i_zz);

    model_so.nodal_supports.push(make_fixed_support(1));

    let node1_so = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2_so = make_node(2, length_rigid, 0.0, 0.0, None);
    let node3_so = make_node(3, total_length, 0.0, 0.0, None);

    let rigid_member_so = make_rigid_member(1, &node1_so, &node2_so);
    let mut elastic_member_so = make_beam_member(2, &node2_so, &node3_so, section_id_so);

    let hinge_so = MemberHinge {
        id: hinge_id,
        hinge_type: "SPRING_Z".to_string(),
        translational_release_vx: None,
        translational_release_vy: None,
        translational_release_vz: None,
        rotational_release_mx: None,
        rotational_release_my: None,
        rotational_release_mz: Some(k_phi_z_user),
        rotational_release_warp: None,
        max_tension_vx: None,
        max_tension_vy: None,
        max_tension_vz: None,
        max_moment_mx: None,
        max_moment_my: None,
        max_moment_mz: None,
        max_bimoment_warp: None,
        stiffness_curve_vx: None,
        stiffness_curve_vy: None,
        stiffness_curve_vz: None,
        stiffness_curve_mx: None,
        stiffness_curve_my: None,
        stiffness_curve_mz: None,
    };

    model_so.memberhinges = Some(vec![hinge_so]);
    elastic_member_so.start_hinge = Some(hinge_id);

    add_member_set(&mut model_so, 1, vec![rigid_member_so, elastic_member_so]);

    let load_case_id_so = add_load_case(&mut model_so, 1, "End Load SO");
    add_nodal_load(
        &mut model_so,
        1,
        load_case_id_so,
        3,
        force_user,
        (0.0, -1.0, 0.0),
    );
    model_so.normalize_units();
    model_so
        .solve_for_load_case_second_order(load_case_id_so, 30)
        .expect("Second-order analysis failed");
    denorm_results_in_place(&mut model_so);
    let results_so = model_so
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("End Load SO")
        .unwrap();

    let dy_3_so = results_so.displacement_nodes.get(&3).unwrap().dy;
    let rz_3_so = results_so.displacement_nodes.get(&3).unwrap().rz;

    assert_close_ctx(
        &ctx,
        dy_3,
        dy_3_so,
        10.0 * tol_dy,
        "Second-order dy differs more than expected",
    );

    assert_close_ctx(
        &ctx,
        rz_3,
        rz_3_so,
        10.0 * tol_rz,
        "Second-order rz differs more than expected",
    );
}

#[test]
fn test_051_member_hinge_root_rotational_spring() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_051_member_hinge_root_rotational_spring_case(strategy, lu, fu, pu);
        }
    }
}
