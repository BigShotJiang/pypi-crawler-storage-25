use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 102: Vlasov warping — cantilever with end torque, warping fixed at root
//
// Analytical Vlasov solution for a cantilever with warping-fixed root (θ'(0)=0)
// and warping-free tip, under end torque T:
//
//   θ(L) = (T·L)/(G·J) · [1 − tanh(k·L)/(k·L)]
//
// where k = sqrt(G·J / (E·I_w))
//
// The twist θ is the rotation about x (DOF 3 = rx).
// When I_w=0, it simplifies to pure St. Venant: θ = T·L/(G·J).
//
// Uses multiple elements for mesh convergence (hyperbolic warping field
// cannot be captured exactly by a single cubic element).
// ============================================================================
fn test_102_vlasov_warping_cantilever_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_102_vlasov_warping_cantilever", strategy, lu, fu, pu);

    // Physical constants (SI) — IPE300
    let l_si = 3.0_f64;
    let t_si = 5000.0_f64;           // 5 kN·m end torque
    let e_si = 210.0e9_f64;
    let g_si = 81.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_y_si = 604.0e-8_f64;
    let i_z_si = 8356.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let i_w_si = 126.0e-9_f64;       // IPE300 warping constant (m⁶)

    let n_elem = 10_u32; // mesh refinement for convergence

    // Analytical: pure St. Venant twist (no warping resistance)
    let theta_sv = t_si * l_si / (g_si * j_si);

    // Analytical: Vlasov twist with warping restraint at root
    let k = (g_si * j_si / (e_si * i_w_si)).sqrt();
    let kl = k * l_si;
    let theta_vlasov = (t_si * l_si) / (g_si * j_si) * (1.0 - kl.tanh() / kl);

    // The warping effect reduces the twist (warping restraint stiffens the beam)
    assert!(theta_vlasov < theta_sv, "Vlasov twist should be less than St. Venant");

    // ---- Model A: No warping constant (pure St. Venant) ----
    let mut model_sv = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model_sv.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let t_user = t_si / (f * l);

    let mat_id = add_material_s235(&mut model_sv, 1);
    let sec_sv = add_section(
        &mut model_sv, 1, "IPE300_SV", mat_id,
        area_si, i_y_si, i_z_si, j_si,
    );

    // Build multi-element mesh
    model_sv.nodal_supports.push(make_fixed_support(1));
    let tip_node_id = n_elem + 1;
    let mut members = Vec::new();
    for i in 0..=n_elem {
        let x = (i as f64) * l_si / (n_elem as f64) / l;
        let sup = if i == 0 { Some(1) } else { None };
        let node = make_node(i + 1, x, 0.0, 0.0, sup);
        if i > 0 {
            let prev = make_node(i, ((i - 1) as f64) * l_si / (n_elem as f64) / l, 0.0, 0.0,
                if i == 1 { Some(1) } else { None });
            members.push(make_beam_member(i, &prev, &node, sec_sv));
        }
    }
    add_member_set(&mut model_sv, 1, members);

    let lc_id = add_load_case(&mut model_sv, 1, "End Torque");
    add_nodal_moment(&mut model_sv, 1, lc_id, tip_node_id, t_user, (1.0, 0.0, 0.0));

    model_sv.normalize_units();
    model_sv.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] SV solve failed: {e}"));
    denorm_results_in_place(&mut model_sv);

    let res_sv = &model_sv.results.as_ref().unwrap().loadcases["End Torque"];
    let rx_sv = res_sv.displacement_nodes[&tip_node_id].rx;

    // ---- Model B: With warping constant (Vlasov) ----
    let mut model_vl = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let mat_id_vl = add_material_s235(&mut model_vl, 1);
    let sec_vl = add_section_with_warping(
        &mut model_vl, 1, "IPE300_VL", mat_id_vl,
        area_si, i_y_si, i_z_si, j_si,
        Some(i_w_si), None, None,
    );

    model_vl.nodal_supports.push(make_fixed_support(1));
    let mut members_vl = Vec::new();
    for i in 0..=n_elem {
        let x = (i as f64) * l_si / (n_elem as f64) / l;
        let sup = if i == 0 { Some(1) } else { None };
        let node = make_node(i + 1, x, 0.0, 0.0, sup);
        if i > 0 {
            let prev = make_node(i, ((i - 1) as f64) * l_si / (n_elem as f64) / l, 0.0, 0.0,
                if i == 1 { Some(1) } else { None });
            members_vl.push(make_beam_member(i, &prev, &node, sec_vl));
        }
    }
    add_member_set(&mut model_vl, 1, members_vl);

    let lc_id_vl = add_load_case(&mut model_vl, 1, "End Torque");
    add_nodal_moment(&mut model_vl, 1, lc_id_vl, tip_node_id, t_user, (1.0, 0.0, 0.0));

    model_vl.normalize_units();
    model_vl.solve_for_load_case(lc_id_vl).unwrap_or_else(|e| panic!("[{ctx}] Vlasov solve failed: {e}"));
    denorm_results_in_place(&mut model_vl);

    let res_vl = &model_vl.results.as_ref().unwrap().loadcases["End Torque"];
    let rx_vl = res_vl.displacement_nodes[&tip_node_id].rx;

    // The warp DOF at the tip should be nonzero (warping rate)
    let warp_tip = res_vl.displacement_nodes[&tip_node_id].warp;

    // Tolerances
    let tol_r = TOL_ABSOLUTE_ROTATION_IN_RADIAN;

    // St. Venant model should match analytical pure torsion
    assert_close_ctx(&ctx, theta_sv, rx_sv, tol_r, "St. Venant twist at tip");

    // Vlasov model should match analytical warping-restrained solution
    assert_close_ctx(&ctx, theta_vlasov, rx_vl, tol_r, "Vlasov twist at tip");

    // Vlasov twist must be less than St. Venant twist (warping stiffens)
    assert!(
        rx_vl < rx_sv,
        "[{ctx}] Vlasov twist ({rx_vl}) should be less than St. Venant ({rx_sv})"
    );

    // Warping DOF at tip should be nonzero
    assert!(
        warp_tip.abs() > 1e-12,
        "[{ctx}] Warping DOF at tip should be nonzero, got {warp_tip}"
    );
}

#[test]
fn test_102_vlasov_warping_cantilever() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_102_vlasov_warping_cantilever_case(strategy, lu, fu, pu);
        }
    }
}
