use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// =========================================================
// 002: Cantilever with intermediate point load
// =========================================================

fn test_002_cantilever_intermediate_point_load_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx(
        "test_002_cantilever_intermediate_point_load",
        strategy,
        lu,
        fu,
        pu,
    );

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    // Physical (SI)
    let l_si = 5.0_f64;
    let a_si = 3.0_f64;
    let f_si = 1000.0_f64;
    let e_si = 210.0e9_f64;
    let i_zz = 13.21e-6_f64;

    // Units
    let u = &model.settings.unit_settings;
    let l = u.length_to_m(); // [user L] -> m
    let f = u.force_to_n(); // [user F] -> N

    // User units geometry / load
    let x1 = 0.0;
    let x_int = a_si / l;
    let x2 = l_si / l;
    let p_user = f_si / f;

    // Model
    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, i_zz);

    let support_id = 1_u32;
    model.nodal_supports.push(make_fixed_support(support_id));

    let n1 = make_node(1, x1, 0.0, 0.0, Some(support_id));
    let n_int = make_node(3, x_int, 0.0, 0.0, None);
    let n2 = make_node(2, x2, 0.0, 0.0, None);

    let m1 = make_beam_member(1, &n1, &n_int, sec_id);
    let m2 = make_beam_member(2, &n_int, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m1, m2]);

    let lc_id = add_load_case(&mut model, 1, "Intermediate Load");
    add_nodal_load(&mut model, 1, lc_id, 3, p_user, (0.0, -1.0, 0.0));
    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Intermediate Load"];

    let dy_int = res.displacement_nodes[&3].dy;
    let dy_end = res.displacement_nodes[&2].dy;
    let mz_fixed = res.reaction_nodes[&1].nodal_forces.mz;

    // Analytical (SI)
    // defl at x=a
    let dy_int_si = -(f_si * a_si.powi(3)) / (3.0 * e_si * i_zz);
    // defl at x=L
    let dy_end_si = -(f_si * a_si.powi(2) * (3.0 * l_si - a_si)) / (6.0 * e_si * i_zz);
    // fixed end moment
    let mz_si = f_si * a_si;

    // Convert expectations
    let dy_int_exp = dy_int_si / l;
    let dy_end_exp = dy_end_si / l;
    let mz_exp = mz_si / (f * l);

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    assert_close_ctx(
        &ctx,
        dy_int,
        dy_int_exp,
        tol_d,
        "deflection at intermediate point",
    );
    assert_close_ctx(&ctx, dy_end, dy_end_exp, tol_d, "deflection at free end");
    assert_close_ctx(&ctx, mz_fixed, mz_exp, tol_m, "moment at fixed support");
}

#[test]
fn test_002_cantilever_intermediate_point_load() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_002_cantilever_intermediate_point_load_case(strategy, lu, fu, pu);
        }
    }
}
