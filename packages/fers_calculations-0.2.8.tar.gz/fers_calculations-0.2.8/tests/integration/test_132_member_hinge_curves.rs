// tests/integration/test_132_member_hinge_curves.rs
//
// 132 — Member-hinge stiffness-curve tests
//
// Validates load-dependent stiffness curves on MemberHinge connections.
// Each test uses a two-member cantilever:
//   Node 1 (z=0) — fully fixed support
//   Node 2 (z=1.5) — midpoint (hinge connection)
//   Node 3 (z=3.0) — free tip, loads applied
//
// Member 1: Node 1→2, normal beam (no hinge)
// Member 2: Node 2→3, normal beam with start_hinge that has a stiffness curve
//
// Uses symmetric section (I_y = I_z) so bending is orientation-independent.
// Curve range [1e4..1e7] spans the meaningful spring regime relative to
// 3EI/L ≈ 2.77e6 N·m for full cantilever.

use std::collections::BTreeMap;

use super::test_support::helpers::*;
use super::test_support::*;

use fers_calculations::models::members::memberhinge::MemberHinge;
use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::stiffness_curve::{ForceComponent, StiffnessCurveConfig};
use fers_calculations::models::supports::nodalsupport::NodalSupport;
use fers_calculations::models::supports::supportcondition::SupportCondition;
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

// ═════════════════════════════════════════════════════════════════════════════
// Helpers
// ═════════════════════════════════════════════════════════════════════════════

/// Build a MemberHinge with a stiffness curve on one DOF, all others rigid.
fn make_curve_hinge(id: u32, dof: &str, curve: StiffnessCurveConfig) -> MemberHinge {
    let (cvx, cvy, cvz, cmx, cmy, cmz) = match dof {
        "vx" => (Some(curve), None, None, None, None, None),
        "vy" => (None, Some(curve), None, None, None, None),
        "vz" => (None, None, Some(curve), None, None, None),
        "mx" => (None, None, None, Some(curve), None, None),
        "my" => (None, None, None, None, Some(curve), None),
        "mz" => (None, None, None, None, None, Some(curve)),
        _ => panic!("Unknown DOF: {dof}"),
    };
    MemberHinge {
        id,
        hinge_type: "User".to_string(),
        translational_release_vx: None,
        translational_release_vy: None,
        translational_release_vz: None,
        rotational_release_mx: None,
        rotational_release_my: None,
        rotational_release_mz: None,
        rotational_release_warp: None,
        max_tension_vx: None,
        max_tension_vy: None,
        max_tension_vz: None,
        max_moment_mx: None,
        max_moment_my: None,
        max_moment_mz: None,
        max_bimoment_warp: None,
        stiffness_curve_vx: cvx,
        stiffness_curve_vy: cvy,
        stiffness_curve_vz: cvz,
        stiffness_curve_mx: cmx,
        stiffness_curve_my: cmy,
        stiffness_curve_mz: cmz,
    }
}

/// Fully fixed support
fn make_fixed_support(id: u32) -> NodalSupport {
    let fixed = || SupportCondition {
        condition_type: SupportConditionType::Fixed,
        stiffness: None,
        stiffness_curve: None,
    };
    let mut dc = BTreeMap::new();
    dc.insert("X".to_string(), fixed());
    dc.insert("Y".to_string(), fixed());
    dc.insert("Z".to_string(), fixed());
    let mut rc = BTreeMap::new();
    rc.insert("X".to_string(), fixed());
    rc.insert("Y".to_string(), fixed());
    rc.insert("Z".to_string(), fixed());
    NodalSupport {
        id,
        classification: None,
        displacement_conditions: dc,
        rotation_conditions: rc,
        warping_condition: None,
    }
}

/// Build a 2-member cantilever with a hinge at the start of member 2 (node 2).
/// Returns the model and load case id.
fn build_hinged_cantilever(
    hinge: MemberHinge,
) -> (fers_calculations::models::fers::fers::FERS, u32) {
    let mut model = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut model, 1);
    // Symmetric section: I_y = I_z
    let sec = add_section(
        &mut model, 1, "SYM",
        mat,
        26.2e-4,                         // area
        SECOND_MOMENT_STRONG_AXIS_IN_M4, // I_y
        SECOND_MOMENT_STRONG_AXIS_IN_M4, // I_z
        1.0e-5,                          // J
    );

    model.nodal_supports.push(make_fixed_support(1));

    let hinge_id = hinge.id;
    model.memberhinges = Some(vec![hinge]);

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 0.0, 0.0, 1.5, None);
    let n3 = make_node(3, 0.0, 0.0, 3.0, None);

    let beam1 = make_beam_member(1, &n1, &n2, sec);
    let mut beam2 = make_beam_member(2, &n2, &n3, sec);
    beam2.start_hinge = Some(hinge_id);

    add_member_set(&mut model, 1, vec![beam1, beam2]);

    let lc = add_load_case(&mut model, 1, "LC1");
    (model, lc)
}

/// Get tip displacement for node 3.
fn get_tip_disp(
    model: &fers_calculations::models::fers::fers::FERS,
    tip_node: u32,
) -> (f64, f64, f64) {
    let res = &model.results.as_ref().unwrap().loadcases["LC1"];
    let d = res.displacement_nodes.get(&tip_node).unwrap();
    (d.dx, d.dy, d.dz)
}

/// Solve second-order and denormalize.
fn solve(model: &mut fers_calculations::models::fers::fers::FERS, lc: u32) {
    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .expect("Second-order solve failed");
    denorm_results_in_place(model);
}

// ─────────────────────────────────────────────────────────────────────────────
// 132a — Rotational hinge My curve depends on axial force N
//
// Hinge at midpoint on My DOF, stiffness depends on axial force N.
// Two load cases: low axial (5 kN) vs high axial (80 kN), same lateral 1 kN.
// Higher axial → stiffer My → less lateral deflection at tip.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_132a_hinge_my_depends_on_n() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::N,
        points: vec![
            [0.0, 1.0e4],
            [100_000.0, 1.0e7],
        ],
    };

    // Low axial → soft hinge
    let (mut m_low, lc) = build_hinged_cantilever(make_curve_hinge(1, "my", curve.clone()));
    add_nodal_load(&mut m_low, 1, lc, 3, 5_000.0, (0.0, 0.0, -1.0));  // axial
    add_nodal_load(&mut m_low, 2, lc, 3, 1_000.0, (1.0, 0.0, 0.0));   // lateral
    solve(&mut m_low, lc);

    // High axial → stiff hinge
    let (mut m_high, lc2) = build_hinged_cantilever(make_curve_hinge(1, "my", curve));
    add_nodal_load(&mut m_high, 1, lc2, 3, 80_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_high, 2, lc2, 3, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_high, lc2);

    let (dx_low, _, _) = get_tip_disp(&m_low, 3);
    let (dx_high, _, _) = get_tip_disp(&m_high, 3);

    assert!(dx_low.abs() > 1e-6, "Low-axial dx={dx_low}");
    assert!(dx_high.abs() > 1e-6, "High-axial dx={dx_high}");
    assert!(
        dx_low.abs() > dx_high.abs() * 1.2,
        "Low-axial should deflect more: dx_low={dx_low}, dx_high={dx_high}"
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 132b — Rotational hinge Mz curve depends on N
//
// Same as 132a but Mz instead of My. Lateral load in Y direction.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_132b_hinge_mz_depends_on_n() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::N,
        points: vec![
            [0.0, 1.0e4],
            [100_000.0, 1.0e7],
        ],
    };

    let (mut m_low, lc) = build_hinged_cantilever(make_curve_hinge(1, "mz", curve.clone()));
    add_nodal_load(&mut m_low, 1, lc, 3, 5_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_low, 2, lc, 3, 1_000.0, (0.0, 1.0, 0.0));
    solve(&mut m_low, lc);

    let (mut m_high, lc2) = build_hinged_cantilever(make_curve_hinge(1, "mz", curve));
    add_nodal_load(&mut m_high, 1, lc2, 3, 80_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_high, 2, lc2, 3, 1_000.0, (0.0, 1.0, 0.0));
    solve(&mut m_high, lc2);

    let (_, dy_low, _) = get_tip_disp(&m_low, 3);
    let (_, dy_high, _) = get_tip_disp(&m_high, 3);

    assert!(dy_low.abs() > 1e-6, "Low-axial dy={dy_low}");
    assert!(dy_high.abs() > 1e-6, "High-axial dy={dy_high}");
    assert!(
        dy_low.abs() > dy_high.abs() * 1.2,
        "Low-axial should deflect more: dy_low={dy_low}, dy_high={dy_high}"
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 132c — Constant-stiffness hinge curve (sanity check)
//
// A curve with constant stiffness at all force levels should produce the
// same result regardless of axial load (no load-dependency effect).
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_132c_constant_curve_hinge() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::N,
        points: vec![
            [0.0, 5.0e5],
            [100_000.0, 5.0e5],
        ],
    };

    let (mut m_low, lc) = build_hinged_cantilever(make_curve_hinge(1, "my", curve.clone()));
    add_nodal_load(&mut m_low, 1, lc, 3, 5_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_low, 2, lc, 3, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_low, lc);

    let (mut m_high, lc2) = build_hinged_cantilever(make_curve_hinge(1, "my", curve));
    add_nodal_load(&mut m_high, 1, lc2, 3, 80_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_high, 2, lc2, 3, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_high, lc2);

    let (dx_low, _, _) = get_tip_disp(&m_low, 3);
    let (dx_high, _, _) = get_tip_disp(&m_high, 3);

    // With constant spring stiffness, lateral deflections should be similar.
    // P-delta effects from axial load will cause some difference, but the
    // hinge contribution should be the same.
    let ratio = dx_low.abs() / dx_high.abs();
    assert!(
        ratio > 0.5 && ratio < 2.0,
        "Constant curve: deflections should be similar, ratio={ratio}, dx_low={dx_low}, dx_high={dx_high}"
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 132d — Hinge curve vs no-hinge comparison
//
// A very stiff hinge curve (k=1e10 everywhere) should produce essentially
// the same result as no hinge at all (continuous beam).
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_132d_very_stiff_hinge_matches_continuous() {
    let curve = StiffnessCurveConfig {
        depends_on: ForceComponent::N,
        points: vec![
            [0.0, 1.0e10],
            [100_000.0, 1.0e10],
        ],
    };

    // With stiff hinge
    let (mut m_hinge, lc) = build_hinged_cantilever(make_curve_hinge(1, "my", curve));
    add_nodal_load(&mut m_hinge, 1, lc, 3, 10_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_hinge, 2, lc, 3, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_hinge, lc);

    // Without hinge (continuous cantilever, 2 members)
    let mut m_cont = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut m_cont, 1);
    let sec = add_section(
        &mut m_cont, 1, "SYM", mat,
        26.2e-4, SECOND_MOMENT_STRONG_AXIS_IN_M4, SECOND_MOMENT_STRONG_AXIS_IN_M4, 1.0e-5,
    );
    m_cont.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 0.0, 0.0, 1.5, None);
    let n3 = make_node(3, 0.0, 0.0, 3.0, None);
    let beam1 = make_beam_member(1, &n1, &n2, sec);
    let beam2 = make_beam_member(2, &n2, &n3, sec);
    add_member_set(&mut m_cont, 1, vec![beam1, beam2]);
    let lc2 = add_load_case(&mut m_cont, 1, "LC1");
    add_nodal_load(&mut m_cont, 1, lc2, 3, 10_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut m_cont, 2, lc2, 3, 1_000.0, (1.0, 0.0, 0.0));
    solve(&mut m_cont, lc2);

    let (dx_hinge, _, _) = get_tip_disp(&m_hinge, 3);
    let (dx_cont, _, _) = get_tip_disp(&m_cont, 3);

    let diff = (dx_hinge - dx_cont).abs() / dx_cont.abs();
    assert!(
        diff < 0.05,
        "Very stiff hinge should match continuous: dx_hinge={dx_hinge}, dx_cont={dx_cont}, diff={diff:.1}%"
    );
}
