use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  086 — Cantilever with UDL, second-order
//
//  N1(0,0,0) ──────── beam ──────── N2(5,0,0)
//    (fixed)                          (free)
//                                       ↓↓↓↓↓  w = 1 000 N/m (global −Y)
//
//  Analytical (1st-order):
//    Fy_support  =  w·L           = 5 000 N
//    Mz_support  = −w·L²/2       = −12 500 N·m
//
//  Section: IPE-180, Iz = 13.21e-6 m⁴
//  Max deflection = wL⁴/(8EI) ≈ 28 mm  (rotation ≈ 0.43° — small but non-negligible
//  for the corotational correction loop if F_equiv is not updated to deformed geometry)
//
//  Regression test: verifies distributed loads work correctly with the corotational
//  F_equiv deformed-geometry correction in the correction loop.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_086_second_order_cantilever_udl() {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::M;
    let fu = ForceUnit::N;
    let pu = PressureUnit::Pa;
    let ctx = make_ctx("086_so_udl", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let l_si = 5.0_f64;
    let w_si = 1_000.0_f64; // N/m — δ = wL⁴/(8EI) ≈ 28 mm

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, l_si, 0.0, 0.0, None);
    add_member_set(&mut model, 1, vec![make_beam_member(1, &n1, &n2, sec)]);

    let lc = add_load_case(&mut model, 1, "UDL");
    // Negative magnitude = downward load (direction is (0,1,0), sign flips to -Y)
    add_member_distributed_load_global_y(&mut model, 1, lc, 1, -w_si, -w_si, 0.0, 1.0);

    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["UDL"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let fy_expect = w_si * l_si;                   // +5 000 N  (exact by statics)
    let mz_expect = w_si * l_si * l_si / 2.0;     // +12 500 N·m (≈ 1st-order for small δ)

    let tol_f = tol_force_user(5.0, 1.0);           // 5 N  (0.1 %)
    let tol_m = tol_moment_user(50.0, 1.0, 1.0);    // 50 N·m (0.4 %)

    assert_close_ctx(&ctx, fy_expect, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx(&ctx, mz_expect, rx.mz, tol_m, "Rx.mz");
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f, "Rx.fz");
}
