use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 114: Both toggles OFF matches classic 6-DOF Euler-Bernoulli
//
// Standard cantilever end load. Both include_shear=false and
// include_warping=false. Must match PL³/(3EI) even though section has
// a_sz and i_w defined.
// ============================================================================
fn test_114_both_toggles_off_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_114_both_toggles_off", strategy, lu, fu, pu);

    let l_si = 5.0_f64;
    let f_si = 1000.0_f64;
    let e_si = 210.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let i_w_si = 126.0e-9_f64;
    let a_sz_si = 25.68e-4_f64;

    let delta_eb = f_si * l_si.powi(3) / (3.0 * e_si * i_z_si);

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    model.settings.analysis_options.include_shear_deformation = false;
    model.settings.analysis_options.include_warping = false;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x2 = l_si / l;
    let p_user = f_si / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_full", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        Some(i_w_si), None, Some(a_sz_si),
    );

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m1]);

    let lc_id = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc_id, 2, p_user, (0.0, -1.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["End Load"];
    let dy_end = res.displacement_nodes[&2].dy;

    let expected = -delta_eb / l;
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    assert_close_ctx(&ctx, expected, dy_end, tol_d, "both toggles off → classic EB");
}

#[test]
fn test_114_both_toggles_off() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_114_both_toggles_off_case(strategy, lu, fu, pu);
        }
    }
}
