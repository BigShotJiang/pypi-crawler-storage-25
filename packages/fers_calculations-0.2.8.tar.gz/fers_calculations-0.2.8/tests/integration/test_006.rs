use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// =========================================================
// 006: Cantilever with partial triangular / inverse triangular
//      (check shear + moment at fixed as in Python example)
// =========================================================

fn test_006_cantilever_partial_triangular_reactions_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx(
        "test_006_cantilever_partial_triangular_reactions",
        strategy,
        lu,
        fu,
        pu,
    );
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let l_si = 5.0_f64;
    let w_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x1 = 0.0;
    let x2 = l_si / l;
    let w_user = w_si * l / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, 13.21e-6_f64);

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, x1, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m]);

    let lc_tri = add_load_case(&mut model, 1, "Triangular Load");
    let lc_inv = add_load_case(&mut model, 2, "Inverse Triangular Load");

    // InverseTriangular: 0 -> 0.6 L
    add_member_distributed_load_global_y(&mut model, 1, lc_tri, 1, w_user, 0.0, 0.0, 0.6);

    // Inverse triangular: 0.3 L -> 0.7 L
    add_member_distributed_load_global_y(&mut model, 2, lc_inv, 1, 0.0, w_user, 0.3, 0.7);
    model.normalize_units();
    model
        .solve_for_load_case(lc_tri)
        .expect("Triangular analysis failed");
    model
        .solve_for_load_case(lc_inv)
        .expect("Inverse triangular analysis failed");
    denorm_results_in_place(&mut model);

    let res_tri = &model.results.as_ref().unwrap().loadcases["Triangular Load"];
    let res_inv = &model.results.as_ref().unwrap().loadcases["Inverse Triangular Load"];

    let fy_tri = res_tri.reaction_nodes[&1].nodal_forces.fy;
    let fy_inv = res_inv.reaction_nodes[&1].nodal_forces.fy;
    let mz_tri = res_tri.reaction_nodes[&1].nodal_forces.mz;
    let mz_inv = res_inv.reaction_nodes[&1].nodal_forces.mz;

    // Analytical (mirroring your Python expressions):

    // Triangular 0..0.6L (zero at free, max at fixed over that segment)
    let shear_tri_si = w_si * 0.5 * l_si * (0.6 - 0.0); // note: your python used L factor; adjust as in script
    let mz_tri_si = (w_si * l_si * 0.5 * (0.6 - 0.0)) * l_si * (1.0 / 3.0) * (0.6 - 0.0); // centroid of triangle from fixed

    // Inverse triangular 0.3L..0.7L (zero at fixed, max at free over that segment)
    let shear_inv_si = w_si * 0.5 * l_si * (0.7 - 0.3);
    let mz_inv_si = shear_inv_si * ((0.3 + (2.0 / 3.0) * (0.7 - 0.3)) * l_si);

    let fy_tri_exp = -shear_tri_si / (f);
    let fy_inv_exp = -shear_inv_si / (f);
    let mz_tri_exp = -mz_tri_si / (f * l);
    let mz_inv_exp = -mz_inv_si / (f * l);

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    assert_close_ctx(
        &ctx,
        fy_tri_exp,
        fy_tri,
        tol_f,
        "shear at fixed support triangle",
    );
    assert_close_ctx(
        &ctx,
        fy_inv_exp,
        fy_inv,
        tol_f,
        "shear at fixed support inverse",
    );
    assert_close_ctx(
        &ctx,
        mz_tri_exp,
        mz_tri,
        tol_m,
        "moment at fixed support triangle",
    );
    assert_close_ctx(
        &ctx,
        mz_inv_exp,
        mz_inv,
        tol_m,
        "moment at fixed support inverse",
    );
}

#[test]
fn test_006_cantilever_partial_triangular_reactions() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_006_cantilever_partial_triangular_reactions_case(strategy, lu, fu, pu);
        }
    }
}
