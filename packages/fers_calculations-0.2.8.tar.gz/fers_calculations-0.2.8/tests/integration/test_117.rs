use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 117: Bimoment sign and magnitude — analytical comparison
//
// Cantilever with warping restrained at root, free at tip, end torque T.
// Analytical bimoment at root: B(0) = -T/k · tanh(kL)
// where k = √(GJ/(EIw)).
// Uses L=2m for a different kL ratio than test 103.
// ============================================================================
fn test_117_bimoment_analytical_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_117_bimoment_analytical", strategy, lu, fu, pu);

    let l_si = 2.0_f64;
    let t_si = 500.0_f64;
    let g_si = 81.0e9_f64;
    let e_si = 210.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let i_w_si = 126.0e-9_f64;

    let k = (g_si * j_si / (e_si * i_w_si)).sqrt();
    let kl = k * l_si;
    let bw_analytical = -t_si / k * kl.tanh();

    let n_elem: u32 = 10;
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let t_user = t_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_W", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        Some(i_w_si), None, None,
    );

    model.nodal_supports.push(make_fixed_support(1));

    let mut nodes = Vec::new();
    let mut members = Vec::new();
    let tip_node_id = n_elem + 1;

    for i in 0..=n_elem {
        let x = (i as f64) * l_si / (n_elem as f64) / l;
        let sup_id = if i == 0 { Some(1) } else { None };
        nodes.push(make_node(i + 1, x, 0.0, 0.0, sup_id));
    }
    for i in 0..n_elem {
        members.push(make_beam_member(i + 1, &nodes[i as usize], &nodes[(i + 1) as usize], sec_id));
    }
    add_member_set(&mut model, 1, members);

    let lc_id = add_load_case(&mut model, 1, "End Torque");
    add_nodal_moment(&mut model, 1, lc_id, tip_node_id, t_user, (1.0, 0.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["End Torque"];
    let bw_root = res.member_results[&1].local_start_forces.bw;

    let bw_expected = bw_analytical / (f * l * l);
    let tol = bw_expected.abs() * 0.01;
    assert_close_ctx(&ctx, bw_expected, bw_root, tol, "bimoment at root");
}

#[test]
fn test_117_bimoment_analytical() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_117_bimoment_analytical_case(strategy, lu, fu, pu);
        }
    }
}
