//! Targeted tests for the corotational deformation extraction fix.
//!
//! Run fast with:  cargo test corot --no-fail-fast 2>&1 | tail -30
//!
//! These tests cover:
//!  1. rotation_matrix_from_vector  (new helper) — round-trip + orthogonality
//!  2. extract_corotational_deformations — rigid body rotation → d_local ≈ 0
//!  3. Integration: 084 triple cantilever second-order — Mx = −1000 N·m

use fers_calculations::models::members::member::{
    rotation_matrix_from_vector, rotation_vector_from_matrix,
};
use nalgebra::Vector3;

// ─────────────────────────────────────────────────────────────────────────────
//  Test 1 — rotation_matrix_from_vector: orthogonality + round-trip
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_corot_rotation_matrix_roundtrip() {
    let pi = std::f64::consts::PI;
    let cases: Vec<Vector3<f64>> = vec![
        Vector3::zeros(),                          // identity
        Vector3::new(0.0, 0.0, 0.3),              // small Z
        Vector3::new(0.0, 0.0, pi / 2.0),         // 90° Z
        Vector3::new(0.0, pi / 4.0, 0.0),         // 45° Y
        Vector3::new(pi / 3.0, 0.0, 0.0),         // 60° X
        Vector3::new(0.3, 0.4, 0.5),              // general axis
        Vector3::new(0.0, 0.0, pi * 0.999),       // near 180°
    ];

    for omega in &cases {
        let r = rotation_matrix_from_vector(omega);

        // R must be a proper rotation: R^T R = I
        let rtr = r.transpose() * r;
        for i in 0..3 {
            for j in 0..3 {
                let expected = if i == j { 1.0 } else { 0.0 };
                assert!(
                    (rtr[(i, j)] - expected).abs() < 1e-12,
                    "R not orthogonal for omega={omega:?}: R^T·R[{i},{j}] = {}",
                    rtr[(i, j)]
                );
            }
        }

        // det(R) = +1 (proper rotation, not reflection)
        let det = r.determinant();
        assert!(
            (det - 1.0).abs() < 1e-12,
            "det(R) = {det} ≠ 1 for omega={omega:?}"
        );

        // Round-trip: R → omega_back must recover the original omega
        let omega_back = rotation_vector_from_matrix(&r);
        let diff = (omega - omega_back).norm();
        assert!(
            diff < 1e-10,
            "Round-trip failed: omega={omega:?} → R → omega_back={omega_back:?}, diff={diff}"
        );
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 2 — extract_corotational_deformations: rigid body → d_local ≈ 0
//
//  A 30° planar rigid body rotation about Z (around node1 as pivot).
//  The chord rotates by the same angle as the cross-sections, so all
//  deformational components should be exactly zero.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_corot_rigid_body_zero_deformations() {
    use fers_calculations::models::members::enums::MemberType;
    use fers_calculations::models::members::member::Member;
    use fers_calculations::models::nodes::node::Node;
    use nalgebra::DVector;

    let angle = 30_f64.to_radians(); // 30° about Z

    // 1 m member along X axis
    let member = Member {
        id: 1,
        start_node: Node { id: 1, X: 0.0, Y: 0.0, Z: 0.0, nodal_support: None },
        end_node:   Node { id: 2, X: 1.0, Y: 0.0, Z: 0.0, nodal_support: None },
        section: None,
        rotation_angle: 0.0,
        start_hinge: None,
        end_hinge: None,
        classification: "Normal".to_string(),
        weight: 0.0,
        chi: None,
        reference_member: None,
        reference_node: None,
        member_type: MemberType::Normal,
    };

    // Rigid body rotation: 30° about Z, pivoting at node1
    //   node1 stays at (0,0,0), rotates by angle about Z
    //   node2 moves from (1,0,0) to (cos30°, sin30°, 0)
    // 14-DOF layout: [dx1,dy1,dz1, rx1,ry1,rz1, warp1,  dx2,dy2,dz2, rx2,ry2,rz2, warp2]
    let dx2 = angle.cos() - 1.0;
    let dy2 = angle.sin();
    let u = DVector::from_vec(vec![
        0.0, 0.0, 0.0,   0.0, 0.0, angle,   0.0,
        dx2, dy2, 0.0,   0.0, 0.0, angle,   0.0,
    ]);

    let (d_local, _t_def) = member.extract_corotational_deformations(&u);

    let tol = 1e-6;
    for i in 0..14 {
        assert!(
            d_local[i].abs() < tol,
            "d_local[{i}] = {:.3e} should be ~0 for 30° rigid body rotation",
            d_local[i]
        );
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 3 — 084 triple-cantilever second-order: Mx = −1000 N·m
//
//  IPE-180-like section, 1 m arms → deflection ≈ 1.6 mm (small).
//  Second-order Mx must be ≈ first-order statics = 1 kN × 1 m = −1000 N·m.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_corot_084_second_order_mx() {
    use fers_calculations::models::settings::analysissettings::RigidStrategy;
    use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
    use super::test_support::helpers::*;
    use super::test_support::SECOND_MOMENT_STRONG_AXIS_IN_M4;

    let mut model = make_fers_with_strategy_and_units(
        RigidStrategy::RigidMember,
        LengthUnit::M,
        ForceUnit::N,
        PressureUnit::Pa,
    );

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.0, 0.0, 0.0, None);
    let n3 = make_node(3, 1.0, 1.0, 0.0, None);
    let n4 = make_node(4, 1.0, 1.0, 1.0, None);

    add_member_set(&mut model, 1, vec![
        make_beam_member(1, &n1, &n2, sec),
        make_beam_member(2, &n2, &n3, sec),
        make_beam_member(3, &n3, &n4, sec),
    ]);

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, 1000.0, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .expect("Second-order solve failed");
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    println!("=== test_corot_084: reactions at N1 ===");
    println!("  fx={:.4}  fy={:.4}  fz={:.4}", rx.fx, rx.fy, rx.fz);
    println!("  mx={:.4}  my={:.4}  mz={:.4}", rx.mx, rx.my, rx.mz);

    // Force equilibrium: Fy = 1000 N
    assert!(
        (rx.fy - 1000.0).abs() < 1.0,
        "Fy = {:.4} ≠ 1000 N", rx.fy
    );

    // Moment equilibrium: statics gives Mx = -1000 N·m, Mz = +1000 N·m
    // Tolerance 50 N·m (5%) allows for small second-order shift
    let tol_m = 50.0;
    assert!(
        (rx.mx - (-1000.0)).abs() < tol_m,
        "Mx = {:.2} N·m, expected -1000 ± {tol_m}", rx.mx
    );
    assert!(
        (rx.mz - 1000.0).abs() < tol_m,
        "Mz = {:.2} N·m, expected +1000 ± {tol_m}", rx.mz
    );
}
