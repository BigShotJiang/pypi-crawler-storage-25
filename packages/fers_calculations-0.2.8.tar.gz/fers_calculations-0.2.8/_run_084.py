import json
import fers_calculations as fers

# First-order
with open('_test_084_first_order.json') as f:
    data = json.load(f)
result_str = fers.calculate_from_json(json.dumps(data))
r = json.loads(result_str)
res = r['results']

lc = res['loadcases']['End Load']
# Member 2 local forces
m2 = lc['member_results']['2']
print("Member 2 LOCAL start:", {k: f"{v:.4f}" for k,v in m2['local_start_forces'].items() if abs(v) > 0.001})
print("Member 2 LOCAL end:  ", {k: f"{v:.4f}" for k,v in m2['local_end_forces'].items() if abs(v) > 0.001})
print("Member 2 GLOBAL start:", {k: f"{v:.4f}" for k,v in m2['start_node_forces'].items() if abs(v) > 0.001})
print("Member 2 GLOBAL end:  ", {k: f"{v:.4f}" for k,v in m2['end_node_forces'].items() if abs(v) > 0.001})
print()
# Also check all member local N (axial) 
for mid in ['1','2','3']:
    m = lc['member_results'][mid]
    print(f"Member {mid}: local N_start={m['local_start_forces']['fx']:.4f}, N_end={m['local_end_forces']['fx']:.4f}")
print()
# Node displacements  
for nid in ['2','3','4']:
    d = lc['displacement_nodes'][nid]
    print(f"N{nid}: dy={d['dy']:.6f} rx={d['rx']:.6f}")
