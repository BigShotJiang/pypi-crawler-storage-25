import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L = 1000.0; P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((14, 14))
    ea_l = E*A/L
    k[0,0] = ea_l; k[7,7] = ea_l; k[0,7] = k[7,0] = -ea_l
    eiz = E*Iz; l2=L*L; l3=l2*L
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,8] = k[8,1] = -12*eiz/l3; k[1,12] = k[12,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,8] = k[8,5] = -6*eiz/l2
    k[5,12] = k[12,5] = 2*eiz/L
    k[8,8] = 12*eiz/l3;  k[8,12] = k[12,8] = -6*eiz/l2
    k[12,12] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,9] = k[9,2] = -12*eiy/l3; k[2,11] = k[11,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,9] = k[9,4] = 6*eiy/l2
    k[4,11] = k[11,4] = 2*eiy/L
    k[9,9] = 12*eiy/l3;  k[9,11] = k[11,9] = 6*eiy/l2
    k[11,11] = 4*eiy/L
    gj_l = G*J/L
    k[3,3] = gj_l; k[10,10] = gj_l; k[3,10] = k[10,3] = -gj_l
    k[6,6] = 1e-6; k[13,13] = 1e-6
    return k

def beam_kgeo_local(N, L):
    k = np.zeros((14, 14))
    p_l = N / L; pL = N * L
    k[0,0] = p_l; k[0,7] = -p_l; k[7,0] = -p_l; k[7,7] = p_l
    for (i1,i5,i8,i12) in [(1,5,8,12), (2,4,9,11)]:
        k[i1,i1] = 6/5*p_l; k[i1,i5]=k[i5,i1]=pL/10; k[i1,i8]=k[i8,i1]=-6/5*p_l; k[i1,i12]=k[i12,i1]=pL/10
        k[i5,i5]=4/15*pL; k[i5,i8]=k[i8,i5]=-pL/10; k[i5,i12]=k[i12,i5]=2/15*pL
        k[i8,i8]=6/5*p_l; k[i8,i12]=k[i12,i8]=-pL/10
        k[i12,i12]=4/15*pL
    return k

def build_T(R):
    T = np.zeros((14, 14))
    for node in range(2):
        b = node * 7
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
        T[b+6, b+6] = 1.0
    return T

phi1 = np.radians(90)
R1 = np.array([[1,0,0],[np.sin(phi1)*0+np.cos(phi1)*0, np.cos(phi1)*1, np.sin(phi1)*1],
               [-np.sin(phi1)*1+np.cos(phi1)*0, -np.sin(phi1)*1, np.cos(phi1)*1]])
# Simpler: just the exact matrices
R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

T1 = build_T(R1); T2 = build_T(R2); T3 = build_T(R3)
k_local = beam_k_local(E, G, A, Iy, Iz, J, L)

ndof = 28
free = list(range(7, 28))
dofs1 = list(range(0,7)) + list(range(7,14))
dofs2 = list(range(7,14)) + list(range(14,21))
dofs3 = list(range(14,21)) + list(range(21,28))

F_full = np.zeros(ndof); F_full[22] = -P

def get_axial(Ti, dofs, u_full):
    u_elem = np.array([u_full[d] for d in dofs])
    u_loc = Ti @ u_elem
    ext = u_loc[7] - u_loc[0]
    return E * A / L * ext

def assemble_K(u_full=None):
    K = np.zeros((ndof, ndof))
    for Ti, dofs in [(T1, dofs1), (T2, dofs2), (T3, dofs3)]:
        kg = Ti.T @ k_local @ Ti
        for i in range(14):
            for j in range(14):
                K[dofs[i], dofs[j]] += kg[i, j]
    if u_full is not None:
        for Ti, dofs in [(T1, dofs1), (T2, dofs2), (T3, dofs3)]:
            N = get_axial(Ti, dofs, u_full)
            if abs(N) > 250:
                kg_local = beam_kgeo_local(N, L)
                kg_global = Ti.T @ kg_local @ Ti
                for i in range(14):
                    for j in range(14):
                        K[dofs[i], dofs[j]] += kg_global[i, j]
    return K

# First-order
K0 = assemble_K()
K_ff = K0[np.ix_(free, free)]
u_1st = np.zeros(ndof)
u_1st[free] = np.linalg.solve(K_ff, F_full[free])
print(f"First-order: rx_n2={u_1st[10]:.6f} dy_n4={u_1st[22]:.4f}")

# TL N-R: incremental load stepping, starting from u=0
n_steps = 20
u = np.zeros(ndof)  # start from zero
for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    for it in range(30):
        K_total = assemble_K(u)
        K_ff = K_total[np.ix_(free, free)]
        r = K_ff @ u[free] - F_lam[free]
        res = np.linalg.norm(r) / max(np.linalg.norm(F_lam[free]), 1)
        if res < 1e-8:
            break
        du = np.linalg.solve(K_ff, -r)
        u[free] += du
    if step <= 3 or step == n_steps:
        Nm2 = get_axial(T2, dofs2, u)
        print(f"Step {step:2d} (lam={lam:.2f}): rx_n2={u[10]:.6f} N_m2={Nm2:.1f} res={res:.2e}")

print(f"\nTL 2nd-order: rx_n2={u[10]:.6f} dy_n4={u[22]:.4f}")
print(f"Ratio rx: {u[10]/u_1st[10]:.4f}")
print(f"Mx = GJ/L * rx_n2 = {G*J/L*u[10]:.0f} N.mm")
