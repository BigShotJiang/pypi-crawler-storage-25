# FERS_calculations

`FERS_calculations` is a high-performance library for Rust-backed calculations in mechanical engineering. It can process JSON input files to deliver fast and accurate results. While it can be run as a standalone tool, integration with `FERS_core` simplifies input creation and workflow management.

## Features

- **Standalone Functionality:** Run directly by providing a valid JSON input file.
- **Rust-Powered Performance:** Designed for speed and reliability in computational tasks.
- **Python Integration:** Seamless integration with `FERS_core` for easy preprocessing and result handling.
- **Engineer-Friendly Design:** Minimal coding effort required for complex structural engineering calculations.

---

## Installation

```bash
pip install fers_calculations
```

This installs the pre-built Rust bindings -- no Rust toolchain required.

## Usage

### Standalone (Python)

You can call `fers_calculations` directly from Python without `FERS_core`:

```python
import fers_calculations

# Load your JSON input
with open("001_cantilever_with_end_load.json") as f:
    json_data = f.read()

# Run the analysis
results_json = fers_calculations.calculate_from_json(json_data)

# Save the results
with open("results.json", "w") as f:
    f.write(results_json)
```

### With FERS_core (recommended)

For a more ergonomic workflow, install `FERS_core` which handles model creation, calling the Rust engine, and post-processing / visualisation:

```bash
pip install fers-core
```

```python
from fers_core import FERS

model = FERS.from_json("001_cantilever_with_end_load.json")
model.calculate()
model.plot_results_3d()
```

See [FERS_core on PyPI](https://pypi.org/project/fers-core/) for full documentation.
