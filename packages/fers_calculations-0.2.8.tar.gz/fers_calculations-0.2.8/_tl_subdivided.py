import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L_total = 1000.0; P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((12, 12))
    ea = E*A/L; l2=L*L; l3=l2*L
    k[0,0] = ea; k[6,6] = ea; k[0,6] = k[6,0] = -ea
    eiz = E*Iz
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,7] = k[7,1] = -12*eiz/l3; k[1,11] = k[11,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,7] = k[7,5] = -6*eiz/l2
    k[5,11] = k[11,5] = 2*eiz/L
    k[7,7] = 12*eiz/l3;  k[7,11] = k[11,7] = -6*eiz/l2
    k[11,11] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,8] = k[8,2] = -12*eiy/l3; k[2,10] = k[10,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,8] = k[8,4] = 6*eiy/l2
    k[4,10] = k[10,4] = 2*eiy/L
    k[8,8] = 12*eiy/l3;  k[8,10] = k[10,8] = 6*eiy/l2
    k[10,10] = 4*eiy/L
    gj = G*J/L
    k[3,3] = gj; k[9,9] = gj; k[3,9] = k[9,3] = -gj
    return k

def beam_kgeo_12(N, L):
    k = np.zeros((12, 12))
    p_l = N/L; pL = N*L
    k[0,0]=p_l; k[0,6]=-p_l; k[6,0]=-p_l; k[6,6]=p_l
    for (i1,i5,i7,i11) in [(1,5,7,11),(2,4,8,10)]:
        k[i1,i1]=6/5*p_l; k[i1,i5]=k[i5,i1]=pL/10; k[i1,i7]=k[i7,i1]=-6/5*p_l; k[i1,i11]=k[i11,i1]=pL/10
        k[i5,i5]=4/15*pL; k[i5,i7]=k[i7,i5]=-pL/10; k[i5,i11]=k[i11,i5]=2/15*pL
        k[i7,i7]=6/5*p_l; k[i7,i11]=k[i11,i7]=-pL/10
        k[i11,i11]=4/15*pL
    return k

def build_T12(R):
    T = np.zeros((12, 12))
    for n in range(2):
        b = n*6
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
    return T

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

# Subdivide each member into N_sub sub-elements
N_sub = 10
members_orig = [
    (R1, np.array([0,0,0.]), np.array([1000,0,0.])),
    (R2, np.array([1000,0,0.]), np.array([1000,1000,0.])),
    (R3, np.array([1000,1000,0.]), np.array([1000,1000,1000.])),
]

# Create sub-element nodes: original nodes 0,1,2,3 + intermediate nodes
# Global node numbering: 0-based
# Original: node0(0,0,0), node1(1000,0,0), node2(1000,1000,0), node3(1000,1000,1000)
# Sub-divided: member 1 has nodes 0, a1, a2, ..., a_{N-1}, 1
#              member 2 has nodes 1, b1, b2, ..., 2
#              member 3 has nodes 2, c1, c2, ..., 3
nodes = []
node_coords = {}
sub_elements = []  # (R, node_i, node_j, L_sub)

node_id = 0
for m_idx, (R, p1, p2) in enumerate(members_orig):
    L_sub = np.linalg.norm(p2 - p1) / N_sub
    direction = (p2 - p1) / np.linalg.norm(p2 - p1)
    
    if m_idx == 0:
        start_node = 0
        node_coords[0] = p1.copy()
        node_id = 1
    else:
        # Reuse the end node of previous member
        start_node = end_node_prev
    
    for s in range(N_sub):
        if s == 0:
            ni = start_node
        else:
            ni = node_id
            node_coords[ni] = p1 + direction * s * L_sub
            node_id += 1
        
        if s == N_sub - 1:
            if m_idx < 2:
                nj = node_id
                node_coords[nj] = p2.copy()
                node_id += 1
                end_node_prev = nj
            else:
                nj = node_id
                node_coords[nj] = p2.copy()
                node_id += 1
        else:
            nj = node_id
            node_coords[nj] = p1 + direction * (s+1) * L_sub
            node_id += 1
        
        sub_elements.append((R, ni, nj, L_sub))

n_nodes = node_id
ndof = n_nodes * 6
print(f'Subdivided mesh: {n_nodes} nodes, {len(sub_elements)} elements, {ndof} DOFs')

# Support: node 0 fully fixed
fixed_dofs = list(range(6))
free_dofs = [i for i in range(ndof) if i not in fixed_dofs]

# Load: node 3 (last node) Fy = -P
# Find the last node (node for original node 4)
load_node = n_nodes - 1
F_full = np.zeros(ndof)
F_full[load_node * 6 + 1] = -P  # Fy at last node

def get_axial_12(T, ni, nj, L_sub, u_full):
    u_elem = np.zeros(12)
    for d in range(6):
        u_elem[d] = u_full[ni*6+d]
        u_elem[6+d] = u_full[nj*6+d]
    u_loc = T @ u_elem
    return E*A/L_sub * (u_loc[6] - u_loc[0])

def assemble_K_sub(u_full=None, include_geo=True):
    K = np.zeros((ndof, ndof))
    for R, ni, nj, Ls in sub_elements:
        T = build_T12(R)
        kl = beam_k_local(E, G, A, Iy, Iz, J, Ls)
        kg = T.T @ kl @ T
        dofs = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
        for i in range(12):
            for j in range(12):
                K[dofs[i], dofs[j]] += kg[i, j]
    if u_full is not None and include_geo:
        for R, ni, nj, Ls in sub_elements:
            N = get_axial_12(build_T12(R), ni, nj, Ls, u_full)
            if abs(N) > 1.0:
                T = build_T12(R)
                kgl = beam_kgeo_12(N, Ls)
                kgg = T.T @ kgl @ T
                dofs = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
                for i in range(12):
                    for j in range(12):
                        K[dofs[i], dofs[j]] += kgg[i, j]
    return K

# First-order
K0 = assemble_K_sub()
u_1st = np.zeros(ndof)
u_1st[free_dofs] = np.linalg.solve(K0[np.ix_(free_dofs, free_dofs)], F_full[free_dofs])

# Node indices for original nodes 2,3,4
orig_n2 = N_sub  # end of member 1 subdivision
orig_n3 = 2 * N_sub  # end of member 2 subdivision
orig_n4 = n_nodes - 1  # last node

rx_n2 = u_1st[orig_n2*6+3]
dy_n4 = u_1st[orig_n4*6+1]
dz_n4 = u_1st[orig_n4*6+2]
print(f'1st-order ({N_sub} sub): rx_n2={rx_n2:.6f} dy_n4={dy_n4:.2f} dz_n4={dz_n4:.2f}')

# TL P-delta with subdivision
n_steps = 20
u = np.zeros(ndof)
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    F_norm = max(np.linalg.norm(F_lam[free_dofs]), 1.0)
    for it in range(50):
        K_total = assemble_K_sub(u)
        K_ff = K_total[np.ix_(free_dofs, free_dofs)]
        f_f = F_lam[free_dofs]
        r = K_ff @ u[free_dofs] - f_f
        res = np.linalg.norm(r) / F_norm
        if res < tol:
            break
        du = np.linalg.solve(K_ff, -r)
        u[free_dofs] += du
    if step in (1,5,10,20):
        rx = u[orig_n2*6+3]
        dy = u[orig_n4*6+1]
        dz = u[orig_n4*6+2]
        print(f'Step {step:2d} (l={lam:.2f}): rx={rx:.6f} dy4={dy:.2f} dz4={dz:.2f} res={res:.2e} it={it}')

rx_final = u[orig_n2*6+3]
dy_final = u[orig_n4*6+1]
dz_final = u[orig_n4*6+2]
print(f'\nTL 2nd-order ({N_sub} sub): rx_n2={rx_final:.6f} dy_n4={dy_final:.2f} dz_n4={dz_final:.2f}')
print(f'Mx = GJ/L * rx_n2 = {G*J/L_total*rx_final:.0f} N.mm')

# Reactions at node 0
K_final = assemble_K_sub(u)
F_reactions = K_final @ u
print(f'Reaction Mx = {F_reactions[3]:.0f} N.mm')
print(f'Reaction Fy = {F_reactions[1]:.2f} N')
print(f'Expected: dy_n4=-350, dz_n4=347, Mx=-1347000')
