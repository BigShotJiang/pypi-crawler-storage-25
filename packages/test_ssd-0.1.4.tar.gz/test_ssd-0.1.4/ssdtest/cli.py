from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

from ssdtest.reports import find_report, load_history
from ssdtest.system import inventory_devices
from ssdtest.workflow import run_interactive


DEFAULT_REPORT_ROOT = Path("/root/nvme-tests")


def build_parser() -> argparse.ArgumentParser:
    prog = Path(sys.argv[0]).name or "test-ssd"
    parser = argparse.ArgumentParser(prog=prog, description="UGREEN NAS NVMe SSD screening CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan = subparsers.add_parser("scan", help="list detected NVMe devices")
    scan.add_argument("--report-root", default=str(DEFAULT_REPORT_ROOT))

    run = subparsers.add_parser("run", help="run the guided destructive SSD screening workflow")
    run.add_argument("--label", help="human-readable label for the test run")
    run.add_argument("--device", help="specific NVMe namespace path, for example /dev/nvme2n1")
    run.add_argument("--report-root", default=str(DEFAULT_REPORT_ROOT))

    history = subparsers.add_parser("history", help="list historical test reports")
    history.add_argument("--report-root", default=str(DEFAULT_REPORT_ROOT))

    show = subparsers.add_parser("show", help="show one historical report summary")
    show.add_argument("run_id")
    show.add_argument("--report-root", default=str(DEFAULT_REPORT_ROOT))
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    report_root = Path(args.report_root)

    if args.command == "scan":
        devices, _ = inventory_devices()
        _print_scan(devices)
        return 0
    if args.command == "run":
        try:
            artifacts = run_interactive(report_root=report_root, label=args.label, requested_device=args.device)
        except KeyboardInterrupt:
            print("\nInterrupted.")
            _notify_completion("SSD test interrupted.", success=False)
            return 130
        except (PermissionError, RuntimeError, ValueError) as exc:
            print(f"Error: {exc}")
            _notify_completion(f"SSD test failed: {exc}", success=False)
            return 1
        print("")
        print(f"Verdict: {artifacts.verdict.verdict}")
        print(f"Report directory: {artifacts.log_dir}")
        print(f"Markdown report: {artifacts.log_dir / 'report.md'}")
        print(f"JSON report: {artifacts.log_dir / 'report.json'}")
        if artifacts.verdict.reasons:
            print("Reasons:")
            for item in artifacts.verdict.reasons:
                print(f"  - {item}")
        if artifacts.verdict.notes:
            print("Notes:")
            for item in artifacts.verdict.notes:
                print(f"  - {item}")
        _notify_completion(
            f"SSD test finished for {artifacts.device.serial} with verdict {artifacts.verdict.verdict}.",
            success=artifacts.verdict.verdict == "PASS",
        )
        return 0 if artifacts.verdict.verdict == "PASS" else 1
    if args.command == "history":
        _print_history(load_history(report_root))
        return 0
    if args.command == "show":
        try:
            report = find_report(report_root, args.run_id)
        except FileNotFoundError as exc:
            print(str(exc))
            return 1
        _print_show(report)
        return 0
    parser.error("unknown command")
    return 2


def _print_scan(devices) -> None:
    print("PATH\tCTRL\tSIZE_GIB\tMODEL\tSERIAL\tSTATUS")
    for device in devices:
        status: list[str] = []
        if device.is_system:
            status.append("system")
        if device.danger_reasons:
            status.extend(device.danger_reasons)
        if not status:
            status.append("candidate")
        print(
            f"{device.path}\t{device.ctrl_path}\t{device.size_gib:.1f}\t{device.model}\t{device.serial}\t"
            f"{'; '.join(status)}"
        )


def _print_history(records: list[dict[str, object]]) -> None:
    if not records:
        print("No reports found.")
        return
    print("RUN_ID\tSTARTED\tLABEL\tSERIAL\tVERDICT\tDURATION_S")
    for record in records:
        device = record.get("device", {})
        final = record.get("final", {})
        print(
            f"{record.get('run_id')}\t{record.get('started_at')}\t{record.get('label')}\t"
            f"{device.get('serial')}\t{final.get('verdict')}\t{record.get('duration_seconds')}"
        )


def _print_show(report: dict[str, object]) -> None:
    device = report.get("device", {})
    final = report.get("final", {})
    report_path = report.get("_report_path")
    report_dir = Path(report_path).parent if report_path else None
    print(f"Run ID: {report.get('run_id')}")
    print(f"Label: {report.get('label')}")
    print(f"Device: {device.get('dev')} ({device.get('model')}, {device.get('serial')})")
    print(f"Verdict: {final.get('verdict')}")
    print(f"Completed: {final.get('completed')}")
    print(f"Duration: {report.get('duration_seconds')} seconds")
    print(f"Markdown report: {report_dir / 'report.md' if report_dir else 'unknown'}")
    reasons = final.get("reasons") or []
    notes = final.get("notes") or []
    if reasons:
        print("Reasons:")
        for item in reasons:
            print(f"  - {item}")
    if notes:
        print("Notes:")
        for item in notes:
            print(f"  - {item}")


def _notify_completion(message: str, success: bool) -> None:
    title = "test-ssd complete" if success else "test-ssd alert"
    print("\a", end="", flush=True)
    _emit_terminal_notifications(title, message)
    notify_send = shutil.which("notify-send")
    if not notify_send:
        return
    if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
        return
    subprocess.run([notify_send, title, message], check=False)


def _emit_terminal_notifications(title: str, message: str) -> None:
    if not sys.stdout.isatty():
        return
    safe_title = _escape_osc_text(title)
    safe_message = _escape_osc_text(message)
    print(f"\033]9;{safe_message}\007", end="", flush=True)
    print(f"\033]777;notify;{safe_title};{safe_message}\007", end="", flush=True)


def _escape_osc_text(value: str) -> str:
    return value.replace("\033", "").replace("\x07", "").replace("\n", " ").replace("\r", " ")
