from functools import lru_cache
from typing import overload

import cv2
import kornia
import numpy as np
import torch
from affine import Affine

from glidergun import stack
from glidergun.grid import Grid, _to_uint8_range, from_ndarray
from glidergun.stack import Stack


@lru_cache
def _get_matcher(device_type: str) -> kornia.feature.LoFTR:
    matcher = kornia.feature.LoFTR(pretrained="outdoor")
    matcher.eval()
    return matcher.to(torch.device(device_type))


def _resize_for_loftr(image: np.ndarray, target: int) -> tuple[np.ndarray, float]:
    # LoFTR requires H and W divisible by 8; crop after resize.
    height, width = image.shape[:2]
    scale = min(1.0, target / max(height, width))
    if scale < 1.0:
        new_width = int(round(width * scale))
        new_height = int(round(height * scale))
        image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)

    height, width = image.shape[:2]
    height_8, width_8 = (height // 8) * 8, (width // 8) * 8
    if (height_8, width_8) != (height, width):
        image = image[:height_8, :width_8]

    return image, scale


def _to_tensor(image: np.ndarray, device: torch.device) -> torch.Tensor:
    return torch.from_numpy(image).float()[None, None].div(255.0).to(device)


def get_transform(
    reference_data: np.ndarray,
    reference_transform: Affine,
    input_data: np.ndarray,
    confidence_threshold: float = 0.7,
    max_long_side: int = 1024,
) -> Affine:
    ref_small, ref_scale = _resize_for_loftr(reference_data, max_long_side)
    src_small, src_scale = _resize_for_loftr(input_data, max_long_side)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    t_ref = _to_tensor(ref_small, device)
    t_src = _to_tensor(src_small, device)

    matcher: kornia.feature.LoFTR = _get_matcher(device.type)

    with torch.inference_mode():
        correspondences: dict[str, torch.Tensor] = matcher({"image0": t_src, "image1": t_ref})

    src_pts = correspondences["keypoints0"].cpu().numpy()
    ref_pts = correspondences["keypoints1"].cpu().numpy()

    conf = correspondences["confidence"].cpu().numpy()
    keep = conf >= confidence_threshold

    src_pts = src_pts[keep] / src_scale
    ref_pts = ref_pts[keep] / ref_scale

    del t_ref, t_src, correspondences

    if len(src_pts) < 3:
        raise ValueError(f"Not enough matches after filtering: {len(src_pts)}")

    affine_matrix, _ = cv2.estimateAffine2D(src_pts, ref_pts, method=cv2.RANSAC, ransacReprojThreshold=3.0)

    if affine_matrix is None:
        raise RuntimeError("Could not estimate affine transform")

    affine_matrix = np.asarray(affine_matrix, dtype=np.float64)

    pixel_to_refpixel = Affine(
        affine_matrix[0, 0],
        affine_matrix[0, 1],
        affine_matrix[0, 2],
        affine_matrix[1, 0],
        affine_matrix[1, 1],
        affine_matrix[1, 2],
    )

    output_transform: Affine = reference_transform * pixel_to_refpixel

    return output_transform


@overload
def georeference_to_reference(input: Grid, reference: Grid | Stack) -> Grid: ...


@overload
def georeference_to_reference(input: Stack, reference: Grid | Stack) -> Stack: ...


def georeference_to_reference(input: Grid | Stack, reference: Grid | Stack) -> Grid | Stack:
    reference = _to_uint8_range(reference.mean() if isinstance(reference, Stack) else reference).type("uint8")
    input_grid = _to_uint8_range(input.mean() if isinstance(input, Stack) else input).type("uint8")
    output_transform = get_transform(reference.data, reference.transform, input_grid.data, max_long_side=800)
    bands = [from_ndarray(band, output_transform, reference.crs) for band in input.to_array()]
    result = stack(bands)
    return result if isinstance(input, Stack) else result.first
