"""mempalace_ironrace.hooks
==========================
Install / uninstall the mempal-hook Rust binary into the user's
~/.claude/settings.json so Claude Code fires it on Stop, SessionStart,
and PreCompact events.

CLI:
    python -m mempalace_ironrace.hooks install
    python -m mempalace_ironrace.hooks uninstall
    python -m mempalace_ironrace.hooks status

Python API:
    from mempalace_ironrace.hooks import install, uninstall, status
    install()
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_BIN_NAME = "mempal-hook.exe" if platform.system() == "Windows" else "mempal-hook"
_INSTALL_DIR = Path.home() / ".mempalace" / "bin"
_INSTALLED_BIN = _INSTALL_DIR / _BIN_NAME
_SETTINGS = Path.home() / ".claude" / "settings.json"

# Marker embedded in the hook command so we can identify our entries later.
_MARKER = "mempal-hook"

# Timeouts (ms) per event.
_TIMEOUTS: dict[str, int] = {
    "Stop": 60_000,
    "SessionStart": 5_000,
    "PreCompact": 60_000,
}

# Vendored binary bundled into the wheel at build time.
_VENDORED = Path(__file__).parent / "bin" / _BIN_NAME

# SHA-256 checksum file bundled alongside the vendored binary.
# Present only when the wheel was built with cargo. Absence means
# verification is skipped (graceful degradation for source installs).
_SHA256_FILE = Path(__file__).parent / "bin" / f"{_BIN_NAME}.sha256"

# Cargo workspace root — two levels up from this file (…/ironrace).
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent


# ---------------------------------------------------------------------------
# Binary resolution
# ---------------------------------------------------------------------------


def _find_binary() -> Path:
    """Return the path to the mempal-hook binary.

    Search order:
    1. Already installed at ~/.mempalace/bin/mempal-hook
    2. Vendored inside the installed wheel
    3. Built in cargo target/release (dev workflow)
    4. Build from source via `cargo build -p mempal-hook --release`

    Raises FileNotFoundError if none of the above succeed.
    """
    if _INSTALLED_BIN.exists():
        return _INSTALLED_BIN

    if _VENDORED.exists():
        return _VENDORED

    # Dev workflow: binary was compiled but not yet installed.
    release_bin = _REPO_ROOT / "target" / "release" / _BIN_NAME
    if release_bin.exists():
        return release_bin

    # Last resort: build from source (requires Rust toolchain).
    if shutil.which("cargo"):
        print("mempal-hook binary not found — building from source …", file=sys.stderr)
        result = subprocess.run(
            ["cargo", "build", "-p", "mempal-hook", "--release", "--quiet"],
            cwd=_REPO_ROOT,
            check=False,
        )
        if result.returncode == 0 and release_bin.exists():
            return release_bin

    raise FileNotFoundError(
        "mempal-hook binary not found and could not be built.\n"
        "Either install the package from a wheel that includes the binary, "
        "or ensure `cargo` is on PATH and run: cargo build -p mempal-hook --release"
    )


def _verify_binary(path: Path) -> None:
    """Verify *path* matches the embedded SHA-256 checksum.

    No-op when the checksum file is absent (wheels built without cargo, or
    source installs where no vendored binary was produced). This ensures the
    check degrades gracefully rather than blocking legitimate dev workflows.

    Raises:
        FileNotFoundError: if the hash does not match, preventing a
            tampered or pre-planted binary from being registered as a hook.
    """
    if not _SHA256_FILE.exists():
        return
    expected = _SHA256_FILE.read_text(encoding="ascii").strip()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise FileNotFoundError(
            f"Binary integrity check failed for {path}.\n"
            f"  expected: {expected[:16]}…\n"
            f"  actual:   {actual[:16]}…\n"
            "Re-install the package from a trusted wheel to fix this."
        )


# ---------------------------------------------------------------------------
# settings.json helpers (immutable: always return new dicts, never mutate)
# ---------------------------------------------------------------------------


def _read_settings() -> dict[str, Any]:
    if not _SETTINGS.exists():
        return {}
    with _SETTINGS.open() as fh:
        try:
            return json.load(fh)
        except json.JSONDecodeError:
            return {}


def _write_settings(settings: dict[str, Any]) -> None:
    _SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    tmp = _SETTINGS.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(settings, indent=2) + "\n")
    tmp.replace(_SETTINGS)


def _hook_entry(bin_path: Path, event: str) -> dict[str, Any]:
    return {
        "matcher": "",
        "hooks": [
            {
                "type": "command",
                "command": str(bin_path),
                "timeout": _TIMEOUTS[event],
            }
        ],
    }


def _is_our_entry(group: dict[str, Any]) -> bool:
    """True iff the hook group was installed by us."""
    hooks = group.get("hooks", [])
    return any(_MARKER in str(h.get("command", "")) for h in hooks)


def _add_hook(
    settings: dict[str, Any], event: str, bin_path: Path
) -> dict[str, Any]:
    """Return a copy of settings with our hook entry added (or updated)."""
    hooks_block = dict(settings.get("hooks", {}))
    event_list: list[dict[str, Any]] = [
        g for g in hooks_block.get(event, []) if not _is_our_entry(g)
    ]
    event_list = [_hook_entry(bin_path, event)] + event_list
    return {**settings, "hooks": {**hooks_block, event: event_list}}


def _remove_hook(settings: dict[str, Any], event: str) -> dict[str, Any]:
    """Return a copy of settings with our hook entry removed."""
    hooks_block = dict(settings.get("hooks", {}))
    event_list = [g for g in hooks_block.get(event, []) if not _is_our_entry(g)]
    return {**settings, "hooks": {**hooks_block, event: event_list}}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def install(*, force: bool = False) -> None:
    """Install mempal-hook and wire it into ~/.claude/settings.json.

    Args:
        force: Re-install even if the binary is already in place.
    """
    bin_path = _find_binary()

    # Copy binary to install dir.
    _INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    if force or not _INSTALLED_BIN.exists():
        shutil.copy2(bin_path, _INSTALLED_BIN)
        _INSTALLED_BIN.chmod(0o755)
        print(f"Installed {_BIN_NAME} → {_INSTALLED_BIN}")
    else:
        print(f"Binary already present at {_INSTALLED_BIN} (use force=True to overwrite)")

    # Verify the binary we're about to register matches the embedded checksum.
    # This catches a pre-planted binary at ~/.mempalace/bin/ as well as any
    # post-install tampering. Raises FileNotFoundError on mismatch.
    _verify_binary(_INSTALLED_BIN)

    # Update settings.json.
    settings = _read_settings()
    for event in _TIMEOUTS:
        settings = _add_hook(settings, event, _INSTALLED_BIN)
    _write_settings(settings)
    print(f"Registered hooks (Stop, SessionStart, PreCompact) in {_SETTINGS}")


def uninstall(*, remove_binary: bool = False) -> None:
    """Remove mempal-hook entries from ~/.claude/settings.json.

    Args:
        remove_binary: Also delete the installed binary from ~/.mempalace/bin/.
    """
    settings = _read_settings()
    for event in _TIMEOUTS:
        settings = _remove_hook(settings, event)
    _write_settings(settings)
    print(f"Removed mempal-hook hooks from {_SETTINGS}")

    if remove_binary and _INSTALLED_BIN.exists():
        _INSTALLED_BIN.unlink()
        print(f"Removed {_INSTALLED_BIN}")


def status() -> None:
    """Print whether mempal-hook is installed and wired up."""
    bin_ok = _INSTALLED_BIN.exists()
    print(f"Binary:  {'✓' if bin_ok else '✗'}  {_INSTALLED_BIN}")

    settings = _read_settings()
    hooks_block = settings.get("hooks", {})
    for event in _TIMEOUTS:
        groups = hooks_block.get(event, [])
        wired = any(_is_our_entry(g) for g in groups)
        print(f"Hook {event:<14}: {'✓' if wired else '✗'}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _main() -> None:
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m mempalace_ironrace.hooks",
        description="Manage the mempal-hook Claude Code integration.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_install = sub.add_parser("install", help="Install and register mempal-hook")
    p_install.add_argument("--force", action="store_true", help="Overwrite existing binary")

    p_uninstall = sub.add_parser("uninstall", help="Remove mempal-hook from settings")
    p_uninstall.add_argument(
        "--remove-binary", action="store_true", help="Also delete the installed binary"
    )

    sub.add_parser("status", help="Show installation status")

    args = parser.parse_args()
    if args.cmd == "install":
        install(force=args.force)
    elif args.cmd == "uninstall":
        uninstall(remove_binary=args.remove_binary)
    elif args.cmd == "status":
        status()


if __name__ == "__main__":
    _main()
