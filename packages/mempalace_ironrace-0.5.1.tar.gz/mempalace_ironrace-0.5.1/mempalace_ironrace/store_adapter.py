"""ironrace-store dual-write adapter.

Intercepts ChromaDB collection.add() and collection.delete() to mirror
writes into the ironrace-store redb database, giving a fast secondary
store for metadata queries that doesn't require parsing the ChromaDB sqlite
file or holding the ChromaDB lock.

Usage (activated automatically by __init__.py when ironrace_store_ext is
available):

    from mempalace_ironrace.store_adapter import activate_store, deactivate_store
    activate_store()

The adapter is a soft dependency — if ironrace_store_ext is not installed
(e.g. first install before wheel is built), it silently no-ops.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger("mempalace_ironrace.store")

_store: Any = None          # DrawerStore instance
_store_lock = threading.Lock()
_store_active = False
_orig_add_for_store: Any = None
_orig_delete_for_store: Any = None
_backfill_thread: threading.Thread | None = None


# ---------------------------------------------------------------------------
# Store path
# ---------------------------------------------------------------------------

def _store_path() -> Path:
    return Path.home() / ".mempalace" / "palace" / "drawers.redb"


# ---------------------------------------------------------------------------
# Store access
# ---------------------------------------------------------------------------

def _get_store() -> Any | None:
    """Return the singleton DrawerStore, or None if unavailable."""
    global _store
    if _store is not None:
        return _store
    with _store_lock:
        if _store is not None:
            return _store
        try:
            from ironrace_store_ext import DrawerStore  # type: ignore[import]
        except ImportError:
            try:
                # Bundled inside the mempalace_ironrace wheel.
                from mempalace_ironrace.ironrace_store_ext import (
                    DrawerStore,  # type: ignore[import,no-redef]
                )
            except ImportError:
                logger.debug("ironrace_store_ext not available — store adapter is a no-op")
                return None
        path = _store_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            _store = DrawerStore(str(path))
            logger.info("ironrace-store opened at %s", path)
        except Exception as e:
            logger.warning("Could not open ironrace-store at %s: %s", path, e)
            return None
    return _store


# ---------------------------------------------------------------------------
# Metadata extraction helpers
# ---------------------------------------------------------------------------

def _extract_drawer_fields(
    doc_id: str,
    document: str | None,
    metadata: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Extract ironrace-store fields from a ChromaDB document.

    Returns None if the document text is absent (can't compute content_hash).
    """
    if not document:
        return None

    meta = metadata or {}
    raw_tags = meta.get("tags", [])
    tags: list[str] = (
        raw_tags if isinstance(raw_tags, list)
        else [t.strip() for t in raw_tags.split(",") if t.strip()]
    )

    content_hash = meta.get("content_hash") or hashlib.sha256(
        document.encode("utf-8", errors="replace")
    ).hexdigest()

    created_at = meta.get("created_at")
    if created_at is None:
        created_at = int(time.time())
    else:
        try:
            created_at = int(created_at)
        except (ValueError, TypeError):
            created_at = int(time.time())

    return {
        "id": doc_id,
        "document": document,
        "wing": str(meta.get("wing", "unknown")),
        "room": str(meta.get("room", "general")),
        "source_file": str(meta.get("source_file", "")),
        "tags": tags,
        "content_hash": str(content_hash),
        "created_at": created_at,
    }


# ---------------------------------------------------------------------------
# Patched ChromaDB methods
# ---------------------------------------------------------------------------

def _make_store_synced_add(original_add):
    """Wrap add() to mirror each document into ironrace-store."""

    def store_synced_add(self, documents=None, ids=None, metadatas=None, **kwargs):
        result = original_add(
            self, documents=documents, ids=ids, metadatas=metadatas, **kwargs
        )
        store = _get_store()
        if store is None or not ids or not documents:
            return result

        doc_list = list(documents)
        id_list = list(ids)
        meta_list = list(metadatas) if metadatas else [None] * len(id_list)

        for doc_id, doc, meta in zip(id_list, doc_list, meta_list):
            fields = _extract_drawer_fields(doc_id, doc, meta)
            if fields is None:
                continue
            try:
                store.add(**fields)
            except Exception as e:
                logger.warning("ironrace-store add failed for %s: %s", doc_id, e)

        return result

    return store_synced_add


def _make_store_synced_delete(original_delete):
    """Wrap delete() to mirror removals into ironrace-store."""

    def store_synced_delete(self, ids=None, **kwargs):
        result = original_delete(self, ids=ids, **kwargs)
        store = _get_store()
        if store is None or not ids:
            return result

        for doc_id in ids:
            try:
                store.delete(str(doc_id))
            except Exception as e:
                logger.warning("ironrace-store delete failed for %s: %s", doc_id, e)

        return result

    return store_synced_delete


# ---------------------------------------------------------------------------
# Auto-backfill
# ---------------------------------------------------------------------------

def _backfill_store() -> None:
    """Migrate existing ChromaDB drawers into ironrace-store in a background thread.

    Called automatically by activate_store() when the store is empty and ChromaDB
    contains documents. Runs once per process; subsequent calls are no-ops.

    Disable via environment variable: ``IRONRACE_BACKFILL=0``.
    """
    global _backfill_thread

    if os.environ.get("IRONRACE_BACKFILL", "1") == "0":
        return

    store = _get_store()
    if store is None:
        return

    # Only backfill when the store is empty — once populated, skip.
    try:
        if store.count() > 0:
            return
    except Exception:
        return

    # Check ChromaDB has something to migrate before spawning a thread.
    try:
        import chromadb

        palace_path = str(Path.home() / ".mempalace" / "palace")
        client = chromadb.PersistentClient(path=palace_path)
        col_names = [
            c if isinstance(c, str) else c.name
            for c in client.list_collections()
        ]
        total = sum(
            client.get_collection(n).count() for n in col_names
        )
        if total == 0:
            return
    except Exception as e:
        logger.debug("backfill pre-check failed: %s", e)
        return

    def _run() -> None:
        logger.info(
            "ironrace-store: backfilling %d existing drawers from ChromaDB …", total
        )
        try:
            stats = migrate_from_chroma(chroma_client=client)
            logger.info(
                "ironrace-store: backfill complete — %d inserted, %d skipped, %d errors",
                stats["inserted"],
                stats["skipped"],
                stats["errors"],
            )
        except Exception as e:
            logger.warning("ironrace-store: backfill failed: %s", e)

    _backfill_thread = threading.Thread(target=_run, daemon=True, name="ironrace-backfill")
    _backfill_thread.start()


# ---------------------------------------------------------------------------
# Activate / deactivate
# ---------------------------------------------------------------------------

def activate_store(
    *,
    current_add: Any | None = None,
    current_delete: Any | None = None,
) -> bool:
    """Patch ChromaDB to dual-write to ironrace-store.

    Args:
        current_add: The ``chromadb.Collection.add`` method to wrap.
            When called from ``__init__.activate()``, pass the already
            turbo-patched method so the store layer wraps the turbo layer
            and ``deactivate_store()`` restores the turbo-patched version,
            preserving correct layering order. If ``None``, reads from
            ``chromadb.Collection.add`` at call time.
        current_delete: Same as ``current_add`` but for ``delete``.

    Returns:
        True if the patch was applied, False if ironrace_store_ext is
        unavailable or already active.
    """
    global _store_active, _orig_add_for_store, _orig_delete_for_store

    if _store_active:
        return False
    if _get_store() is None:
        return False

    try:
        import chromadb
    except ImportError:
        return False

    _orig_add_for_store = current_add if current_add is not None else chromadb.Collection.add
    _orig_delete_for_store = (
        current_delete if current_delete is not None else chromadb.Collection.delete
    )

    chromadb.Collection.add = _make_store_synced_add(_orig_add_for_store)
    chromadb.Collection.delete = _make_store_synced_delete(_orig_delete_for_store)

    _store_active = True
    logger.info("ironrace-store dual-write activated")

    # Backfill existing ChromaDB data into the store on first install.
    _backfill_store()

    return True


def deactivate_store() -> None:
    """Remove store dual-write patches."""
    global _store_active, _orig_add_for_store, _orig_delete_for_store

    if not _store_active:
        return

    try:
        import chromadb

        if _orig_add_for_store is not None:
            chromadb.Collection.add = _orig_add_for_store
        if _orig_delete_for_store is not None:
            chromadb.Collection.delete = _orig_delete_for_store
    except Exception:
        # chromadb import may fail (e.g. Python 3.14 / pydantic incompat) —
        # just clear state without restoring; the process is shutting down anyway.
        pass

    _orig_add_for_store = None
    _orig_delete_for_store = None
    _store_active = False
    logger.info("ironrace-store dual-write deactivated")


# ---------------------------------------------------------------------------
# One-shot migration
# ---------------------------------------------------------------------------

def migrate_from_chroma(chroma_client=None, *, dry_run: bool = False, batch_size: int = 500) -> dict[str, int]:
    """Migrate existing ChromaDB drawers into ironrace-store.

    Args:
        chroma_client: An open ``chromadb.Client`` (or ``chromadb.PersistentClient``).
                       If None, opens the default mempalace ChromaDB at
                       ``~/.mempalace/palace/``.
        dry_run:       If True, count what would be migrated but write nothing.
        batch_size:    Number of drawers per write transaction (default 500).
                       Higher values reduce fsyncs and improve throughput.

    Returns:
        A dict with keys ``total``, ``inserted``, ``skipped``, ``errors``.
    """
    store = _get_store()
    if store is None:
        raise RuntimeError(
            "ironrace_store_ext is not available. "
            "Upgrade mempalace-ironrace to a version that bundles the store extension."
        )

    if chroma_client is None:
        try:
            import chromadb

            palace_path = str(Path.home() / ".mempalace" / "palace")
            chroma_client = chromadb.PersistentClient(path=palace_path)
        except ImportError as e:
            raise RuntimeError("chromadb is not installed") from e

    stats = {"total": 0, "inserted": 0, "skipped": 0, "errors": 0}

    # chromadb >= 0.6: list_collections() returns names only.
    collection_names = [
        c if isinstance(c, str) else c.name
        for c in chroma_client.list_collections()
    ]

    for col_name in collection_names:
        collection = chroma_client.get_collection(col_name)
        count = collection.count()
        if count == 0:
            continue

        logger.info("Migrating collection %s (%d docs)…", col_name, count)

        for offset in range(0, count, batch_size):
            chroma_batch = collection.get(
                include=["documents", "metadatas"],
                limit=batch_size,
                offset=offset,
            )
            doc_ids = chroma_batch.get("ids", [])
            docs = chroma_batch.get("documents") or [None] * len(doc_ids)
            metas = chroma_batch.get("metadatas") or [None] * len(doc_ids)

            drawer_batch = []
            for doc_id, doc, meta in zip(doc_ids, docs, metas):
                stats["total"] += 1
                fields = _extract_drawer_fields(doc_id, doc, meta)
                if fields is None:
                    stats["skipped"] += 1
                    continue
                if dry_run:
                    stats["inserted"] += 1
                    continue
                drawer_batch.append(fields)

            if not drawer_batch or dry_run:
                continue

            # Use add_batch if available (single fsync for whole batch),
            # fall back to add() per-drawer for older wheel versions.
            if hasattr(store, "add_batch"):
                try:
                    n = store.add_batch(drawer_batch)
                    stats["inserted"] += n
                    stats["skipped"] += len(drawer_batch) - n
                except Exception as e:
                    logger.warning("Migration batch error (offset=%d): %s", offset, e)
                    stats["errors"] += len(drawer_batch)
            else:
                for fields in drawer_batch:
                    try:
                        inserted = store.add(**fields)
                        if inserted:
                            stats["inserted"] += 1
                        else:
                            stats["skipped"] += 1
                    except Exception as e:
                        logger.warning("Migration error for %s: %s", fields.get("id"), e)
                        stats["errors"] += 1

    verb = "Would migrate" if dry_run else "Migrated"
    logger.info(
        "%s %d/%d drawers (%d skipped, %d errors)",
        verb,
        stats["inserted"],
        stats["total"],
        stats["skipped"],
        stats["errors"],
    )
    return stats
