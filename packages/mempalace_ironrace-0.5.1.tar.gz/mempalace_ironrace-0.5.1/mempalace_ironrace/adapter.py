"""ChromaDB monkey-patch adapter for IronRace turbo search.

Intercepts collection.query() to use HNSW search, and syncs
collection.add() / collection.delete() to keep the index current.
"""

import hashlib
import logging
import os
import shutil
import threading

logger = logging.getLogger("mempalace_ironrace")

# Cache TurboCollection instances per index path (avoid ONNX reload per query)
_collection_cache: dict[str, object] = {}
_cache_lock = threading.Lock()
_bootstrap_lock = threading.Lock()
_failure_count = 0
_MAX_FAILURES = 3
_disabled = False

EMBED_DIM = 384
MAX_BOOTSTRAP_BATCH = 10_000


def _get_index_path(chroma_collection) -> str:
    """Derive index path from collection ID (path-traversal safe)."""
    col_id = str(chroma_collection.id)
    safe_name = hashlib.sha256(col_id.encode()).hexdigest()[:16]
    return os.path.expanduser(f"~/.ironrace/collections/{safe_name}")


def _index_exists(index_path: str) -> bool:
    """Check if an IronRace index exists at the given path."""
    return os.path.isfile(os.path.join(index_path, "manifest.json"))


def _delete_index(index_path: str) -> None:
    """Delete a stale IronRace index."""
    try:
        if os.path.isdir(index_path):
            shutil.rmtree(index_path)
    except OSError as e:
        logger.warning("Failed to delete stale index at %s: %s", index_path, e)


def _get_or_create_turbo(index_path: str):
    """Get cached TurboCollection or create one (ONNX session reused)."""
    from ironrace_turbo import TurboCollection

    if index_path not in _collection_cache:
        with _cache_lock:
            if index_path not in _collection_cache:
                _collection_cache[index_path] = TurboCollection(index_path)
    return _collection_cache[index_path]


def reset_circuit_breaker() -> None:
    """Reset the circuit breaker state. Called from deactivate()."""
    global _failure_count, _disabled
    _failure_count = 0
    _disabled = False
    _collection_cache.clear()


def _invalidate_cache(index_path: str) -> None:
    """Remove a cached TurboCollection (e.g., after re-bootstrap)."""
    with _cache_lock:
        _collection_cache.pop(index_path, None)


def _bootstrap_from_chromadb(chroma_collection, index_path: str) -> None:
    """Read existing embeddings from ChromaDB and build IronRace index."""
    from ironrace_turbo import TurboCollection

    total = chroma_collection.count()
    if total == 0:
        logger.info("Empty collection — skipping IronRace bootstrap")
        return

    all_ids: list[str] = []
    all_embeddings: list[list[float]] = []

    # Paginated reads to avoid OOM at scale
    for offset in range(0, total, MAX_BOOTSTRAP_BATCH):
        batch = chroma_collection.get(
            include=["embeddings"],
            limit=MAX_BOOTSTRAP_BATCH,
            offset=offset,
        )
        batch_ids = batch["ids"]
        batch_embs = batch.get("embeddings")

        if not batch_ids:
            break

        if batch_embs is None:
            raise ValueError(
                "ChromaDB returned no embeddings. "
                "Ensure the collection was created with an embedding function."
            )

        # Validate embedding dimensions (batch_embs may be numpy array)
        if len(batch_embs) > 0 and len(batch_embs[0]) != EMBED_DIM:
            raise ValueError(
                f"Embedding dimension mismatch: expected {EMBED_DIM}, "
                f"got {len(batch_embs[0])}. Is ChromaDB using a different model? "
                f"IronRace requires all-MiniLM-L6-v2 (384-dim)."
            )

        all_ids.extend(batch_ids)
        # Convert numpy arrays to plain lists for PyO3
        for emb in batch_embs:
            all_embeddings.append(
                emb.tolist() if hasattr(emb, "tolist") else list(emb)
            )

    if not all_ids:
        return

    # Build the IronRace index from ChromaDB's stored vectors
    col = TurboCollection.build_from_vectors(index_path, all_ids, all_embeddings)

    # Cache the newly built collection
    with _cache_lock:
        _collection_cache[index_path] = col

    logger.info("Bootstrapped IronRace index: %d vectors from ChromaDB", len(all_ids))


def _fetch_results_from_chromadb(
    chroma_collection, turbo_results: list[tuple[str, float]], include: list[str]
) -> tuple[list[str], list[str], list[dict], list[float]]:
    """Fetch full document data from ChromaDB for IronRace result IDs."""
    result_ids = [r[0] for r in turbo_results]
    scores = [r[1] for r in turbo_results]

    if not result_ids:
        return [], [], [], []

    # Re-fetch metadata/documents from ChromaDB (source of truth)
    chroma_include = []
    if "documents" in include:
        chroma_include.append("documents")
    if "metadatas" in include:
        chroma_include.append("metadatas")

    if chroma_include:
        data = chroma_collection.get(ids=result_ids, include=chroma_include)
        # ChromaDB get() doesn't guarantee order matches input IDs.
        # Re-sort to match IronRace's score-ranked order.
        id_order = {id_: i for i, id_ in enumerate(result_ids)}
        returned_ids = data.get("ids", [])
        raw_docs = data.get("documents", [None] * len(returned_ids))
        raw_metas = data.get("metadatas", [None] * len(returned_ids))

        # Build lookup from returned data
        doc_map = dict(zip(returned_ids, raw_docs)) if raw_docs else {}
        meta_map = dict(zip(returned_ids, raw_metas)) if raw_metas else {}

        # Re-order to match IronRace ranking
        docs = [doc_map.get(id_) for id_ in result_ids]
        metas = [meta_map.get(id_) for id_ in result_ids]
    else:
        docs = [None] * len(result_ids)
        metas = [None] * len(result_ids)

    return result_ids, docs, metas, scores


def make_turbo_query(original_query):
    """Create a patched query method that uses IronRace for vector search."""

    def turbo_query(self, query_texts, n_results=5, **kwargs):
        global _failure_count, _disabled

        # Circuit breaker: fall back after repeated failures
        if _disabled:
            return original_query(self, query_texts=query_texts, n_results=n_results, **kwargs)

        index_path = _get_index_path(self)

        # Thread-safe bootstrap with double-checked locking
        if not _index_exists(index_path):
            with _bootstrap_lock:
                if not _index_exists(index_path):
                    try:
                        _bootstrap_from_chromadb(self, index_path)
                    except Exception as e:
                        logger.warning("IronRace bootstrap failed: %s", e)
                        return original_query(
                            self, query_texts, n_results=n_results, **kwargs
                        )

        # If bootstrap produced nothing (empty collection), fall back
        if not _index_exists(index_path):
            return original_query(self, query_texts=query_texts, n_results=n_results, **kwargs)

        try:
            turbo = _get_or_create_turbo(index_path)
            include = kwargs.get(
                "include", ["documents", "metadatas", "distances"]
            )

            # Handle ALL query texts (ChromaDB supports batch queries)
            all_ids = []
            all_docs = []
            all_metas = []
            all_dists = []

            for query_text in query_texts:
                results = turbo.search(query_text, n_results)
                ids, docs, metas, dists = _fetch_results_from_chromadb(
                    self, results, include
                )
                all_ids.append(ids)
                all_docs.append(docs)
                all_metas.append(metas)
                all_dists.append(dists)

            # Build ChromaDB-compatible response (nested lists, one per query)
            response = {"ids": all_ids}
            if "documents" in include:
                response["documents"] = all_docs
            if "metadatas" in include:
                response["metadatas"] = all_metas
            if "distances" in include:
                response["distances"] = all_dists
            if "embeddings" in include:
                response["embeddings"] = None

            _failure_count = 0  # Reset on success
            return response

        except Exception as e:
            _failure_count += 1
            logger.warning(
                "IronRace search failed (%d/%d): %s",
                _failure_count,
                _MAX_FAILURES,
                e,
            )
            if _failure_count >= _MAX_FAILURES:
                _disabled = True
                _delete_index(index_path)
                _invalidate_cache(index_path)
                logger.error(
                    "IronRace disabled after %d failures. Falling back to ChromaDB.",
                    _MAX_FAILURES,
                )
            return original_query(self, query_texts=query_texts, n_results=n_results, **kwargs)

    return turbo_query


def make_synced_add(original_add):
    """Create a patched add method that syncs to the IronRace index."""

    def synced_add(self, documents=None, ids=None, metadatas=None, **kwargs):
        # ChromaDB add first (source of truth)
        result = original_add(self, documents=documents, ids=ids, metadatas=metadatas, **kwargs)

        # Sync to IronRace (best-effort)
        try:
            index_path = _get_index_path(self)
            if _index_exists(index_path) and documents and ids:
                turbo = _get_or_create_turbo(index_path)
                turbo.add(list(ids), list(documents))
        except Exception as e:
            logger.warning("IronRace sync-on-add failed: %s", e)

        return result

    return synced_add


def make_synced_delete(original_delete):
    """Create a patched delete method that marks the IronRace index dirty."""

    def synced_delete(self, ids=None, **kwargs):
        result = original_delete(self, ids=ids, **kwargs)

        # Mark IronRace index as needing rebuild
        try:
            index_path = _get_index_path(self)
            if _index_exists(index_path):
                turbo = _get_or_create_turbo(index_path)
                turbo.mark_dirty()
        except Exception as e:
            logger.warning("IronRace sync-on-delete failed: %s", e)

        return result

    return synced_delete
