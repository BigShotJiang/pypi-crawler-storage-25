"""mempalace-ironrace: Turbo vector search for MemPalace.

Install and import to automatically accelerate MemPalace's vector search
using IronRace's Rust HNSW engine with ONNX embeddings.

Usage:
    pip install mempalace-ironrace
    # That's it. Searches are now ~30-40x faster at scale.

    # To disable auto-activation:
    # IRONRACE_AUTO_ACTIVATE=0 pip install mempalace-ironrace
"""

import logging
import os

logger = logging.getLogger("mempalace_ironrace")

# Re-export the migration helper at the package level for convenience.
from .store_adapter import migrate_from_chroma as migrate_from_chroma  # noqa: E402

_activated = False
_orig_query = None
_orig_add = None
_orig_delete = None


def activate():
    """Patch ChromaDB to use IronRace for vector search.

    Safe to call multiple times (idempotent). Guards against double-patching
    and foreign patchers.
    """
    global _activated, _orig_query, _orig_add, _orig_delete
    if _activated:
        return

    try:
        import chromadb
    except ImportError:
        logger.warning("chromadb not installed — skipping IronRace activation")
        return

    # Guard against double-patching
    if hasattr(chromadb.Collection.query, "_ironrace_patched"):
        logger.warning("IronRace already patched — skipping")
        return

    from .adapter import make_synced_add, make_synced_delete, make_turbo_query

    _orig_query = chromadb.Collection.query
    _orig_add = chromadb.Collection.add
    _orig_delete = chromadb.Collection.delete

    patched_query = make_turbo_query(_orig_query)
    patched_query._ironrace_patched = True

    chromadb.Collection.query = patched_query
    chromadb.Collection.add = make_synced_add(_orig_add)
    chromadb.Collection.delete = make_synced_delete(_orig_delete)

    # Pre-download ONNX model at activation time (not first search)
    try:
        from ironrace_turbo import ensure_model

        ensure_model()
    except Exception as e:
        logger.warning("Could not pre-download embedding model: %s", e)

    _activated = True
    logger.info("IronRace turbo search activated")

    # Activate ironrace-store dual-write (soft dependency — no-ops gracefully
    # if ironrace_store_ext wheel is not installed).
    # Pass the already-patched add/delete so store_adapter wraps the turbo
    # layer and restores to it (not to the bare ChromaDB original) on
    # deactivate_store(), preserving correct layering order.
    try:
        from .store_adapter import activate_store

        activate_store(
            current_add=chromadb.Collection.add,
            current_delete=chromadb.Collection.delete,
        )
    except Exception as e:
        logger.debug("ironrace-store dual-write not activated: %s", e)


def deactivate():
    """Remove IronRace patches and restore original ChromaDB behavior."""
    global _activated, _orig_query, _orig_add, _orig_delete

    # Deactivate the store layer first — it restores Collection.add/delete to
    # the turbo-wrapped versions (_orig_add_for_store). We then overwrite those
    # with the bare originals below. If the order were reversed, deactivate_store()
    # would clobber the bare originals we just restored.
    from .adapter import reset_circuit_breaker
    from .store_adapter import deactivate_store

    reset_circuit_breaker()
    deactivate_store()

    if _orig_query is not None:
        import chromadb

        chromadb.Collection.query = _orig_query
        chromadb.Collection.add = _orig_add
        chromadb.Collection.delete = _orig_delete
        _orig_query = None
        _orig_add = None
        _orig_delete = None

    _activated = False
    logger.info("IronRace turbo search deactivated")


# Auto-activate on import (disable via IRONRACE_AUTO_ACTIVATE=0)
if os.environ.get("IRONRACE_AUTO_ACTIVATE", "1") != "0":
    activate()
