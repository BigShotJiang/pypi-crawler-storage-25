"""Throughput benchmarks for ironrace-store (DrawerStore).

Run manually — not part of the default pytest suite.  Results are printed
to stdout so they're easy to copy into release notes.

    pytest integrations/mempalace/tests/test_store_benchmark.py -v -s

Thresholds are intentionally generous so CI runners don't flake.
"""

from __future__ import annotations

import hashlib
import tempfile
import time
import uuid
from pathlib import Path
from typing import Iterator

import pytest

try:
    import chromadb as _chromadb
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False

# ---------------------------------------------------------------------------
# Skip when the extension is absent (e.g. CI without a built wheel).
# ---------------------------------------------------------------------------

try:
    from ironrace_store_ext import DrawerStore  # type: ignore[import]

    STORE_AVAILABLE = True
except ImportError:
    STORE_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not STORE_AVAILABLE, reason="ironrace_store_ext not installed"
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# redb commits one fsync per write transaction (~7 ms each on macOS).
# Bulk throughput is intentionally modest — the store is optimised for
# query speed, not write-heavy ingestion.  Keep N small enough that the
# suite completes in reasonable time even on slow CI runners.
N_SMALL = 100
N_LARGE = 500


def _make_drawer(i: int) -> dict:
    doc = f"Benchmark drawer #{i}. " * 4
    return {
        "id": str(uuid.uuid4()),
        "document": doc,
        "wing": f"wing_{i % 10}",
        "room": f"room_{i % 50}",
        "source_file": f"/notes/file_{i % 100}.md",
        "tags": [f"tag{i % 5}", f"bench"],
        "content_hash": hashlib.sha256(doc.encode()).hexdigest(),
        "created_at": 1_700_000_000 + i,
    }


@pytest.fixture()
def store_path(tmp_path: Path) -> str:
    return str(tmp_path / "bench.redb")


@pytest.fixture()
def populated_store(store_path: str) -> Iterator[DrawerStore]:
    """A store pre-loaded with N_LARGE drawers."""
    store = DrawerStore(store_path)
    for i in range(N_LARGE):
        store.add(**_make_drawer(i))
    yield store


# ---------------------------------------------------------------------------
# add() throughput
# ---------------------------------------------------------------------------


def test_add_throughput_small(store_path: str) -> None:
    """Add N_SMALL drawers and report throughput; must finish in < 30 s."""
    store = DrawerStore(store_path)
    drawers = [_make_drawer(i) for i in range(N_SMALL)]

    start = time.perf_counter()
    for d in drawers:
        store.add(**d)
    elapsed = time.perf_counter() - start

    rate = N_SMALL / elapsed
    print(f"\n  add() {N_SMALL}: {elapsed * 1000:.0f} ms  ({rate:.0f} inserts/s)")
    assert elapsed < 30.0, f"{N_SMALL} inserts took {elapsed:.2f} s — too slow"
    assert store.count() == N_SMALL


def test_add_throughput_large(store_path: str) -> None:
    """Add N_LARGE drawers and report throughput; must finish in < 120 s."""
    store = DrawerStore(store_path)
    drawers = [_make_drawer(i) for i in range(N_LARGE)]

    start = time.perf_counter()
    for d in drawers:
        store.add(**d)
    elapsed = time.perf_counter() - start

    rate = N_LARGE / elapsed
    print(f"\n  add() {N_LARGE}: {elapsed * 1000:.0f} ms  ({rate:.0f} inserts/s)")
    assert elapsed < 120.0, f"{N_LARGE} inserts took {elapsed:.2f} s — too slow"
    assert store.count() == N_LARGE


# ---------------------------------------------------------------------------
# Dedup gate — duplicate content_hash must not double-insert
# ---------------------------------------------------------------------------


def test_dedup_gate(store_path: str) -> None:
    """Inserting the same content_hash twice keeps count at 1."""
    store = DrawerStore(store_path)
    d = _make_drawer(0)
    assert store.add(**d) is True
    d2 = {**d, "id": str(uuid.uuid4())}  # different id, same content_hash
    assert store.add(**d2) is False
    assert store.count() == 1


# ---------------------------------------------------------------------------
# Query throughput at 10 K scale
# ---------------------------------------------------------------------------


def test_get_by_id_throughput(populated_store: DrawerStore, store_path: str) -> None:
    """100 get_by_id lookups at 10 K scale must complete in < 500 ms."""
    # Collect some real ids to look up.
    samples = populated_store.list_by_wing("wing_0")[:50]
    ids = [d["id"] for d in samples]
    if not ids:
        pytest.skip("no drawers in wing_0")

    reps = 100
    start = time.perf_counter()
    for i in range(reps):
        populated_store.get_by_id(ids[i % len(ids)])
    elapsed = time.perf_counter() - start

    rate = reps / elapsed
    print(f"\n  get_by_id x{reps} @ 10 K: {elapsed * 1000:.0f} ms  ({rate:.0f} lookups/s)")
    assert elapsed < 0.5, f"{reps} get_by_id took {elapsed:.3f} s — too slow"


def test_list_by_wing_throughput(populated_store: DrawerStore) -> None:
    """list_by_wing across N_LARGE drawers; must finish in < 500 ms."""
    start = time.perf_counter()
    for w in range(10):
        results = populated_store.list_by_wing(f"wing_{w}")
        assert len(results) == N_LARGE // 10
    elapsed = time.perf_counter() - start

    print(f"\n  list_by_wing x10 @ {N_LARGE}: {elapsed * 1000:.0f} ms")
    assert elapsed < 0.5, f"list_by_wing (all wings) took {elapsed:.3f} s — too slow"


def test_list_by_room_throughput(populated_store: DrawerStore) -> None:
    """list_by_room across N_LARGE drawers; must finish in < 500 ms."""
    start = time.perf_counter()
    for r in range(50):
        results = populated_store.list_by_room(f"wing_{r % 10}", f"room_{r}")
        assert len(results) == N_LARGE // 50
    elapsed = time.perf_counter() - start

    print(f"\n  list_by_room x50 @ {N_LARGE}: {elapsed * 1000:.0f} ms")
    assert elapsed < 0.5, f"list_by_room (all rooms) took {elapsed:.3f} s — too slow"


def test_content_hash_lookup_throughput(populated_store: DrawerStore) -> None:
    """50 search_by_content_hash lookups at 10 K scale must finish in < 200 ms."""
    samples = populated_store.list_by_wing("wing_1")[:50]
    hashes = [d["content_hash"] for d in samples]
    if not hashes:
        pytest.skip("no drawers in wing_1")

    start = time.perf_counter()
    for h in hashes:
        results = populated_store.search_by_content_hash(h)
        assert len(results) >= 1
    elapsed = time.perf_counter() - start

    print(f"\n  search_by_content_hash x{len(hashes)} @ 10 K: {elapsed * 1000:.0f} ms")
    assert elapsed < 0.2, f"search_by_content_hash took {elapsed:.3f} s — too slow"


# ---------------------------------------------------------------------------
# delete() throughput
# ---------------------------------------------------------------------------


def test_delete_throughput(store_path: str) -> None:
    """Delete N_SMALL drawers; must finish in < 30 s."""
    store = DrawerStore(store_path)
    drawers = [_make_drawer(i) for i in range(N_SMALL)]
    for d in drawers:
        store.add(**d)

    ids = [d["id"] for d in drawers]
    start = time.perf_counter()
    for doc_id in ids:
        store.delete(doc_id)
    elapsed = time.perf_counter() - start

    rate = N_SMALL / elapsed
    print(f"\n  delete() {N_SMALL}: {elapsed * 1000:.0f} ms  ({rate:.0f} deletes/s)")
    assert elapsed < 30.0, f"{N_SMALL} deletes took {elapsed:.2f} s — too slow"
    assert store.count() == 0


# ---------------------------------------------------------------------------
# ironrace-store vs ChromaDB metadata query comparison
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not CHROMA_AVAILABLE, reason="chromadb not installed")
def test_vs_chromadb_metadata_queries(store_path: str, tmp_path: Path) -> None:
    """Compare ironrace-store vs ChromaDB for wing/room/id metadata queries.

    ChromaDB must scan all documents and filter in Python; ironrace-store
    uses dedicated secondary indexes.  Results are printed; no assertion on
    the ratio so the test never flakes on slow CI.
    """
    N = N_SMALL
    drawers = [_make_drawer(i) for i in range(N)]

    # ── Populate ironrace-store ──────────────────────────────────────────
    # Use only 10 rooms so each room has N//10 drawers at small N.
    for d in drawers:
        d["room"] = f"room_{int(d['room'].split('_')[1]) % 10}"

    store = DrawerStore(store_path)
    for d in drawers:
        store.add(**d)

    # ── Populate ChromaDB ────────────────────────────────────────────────
    import chromadb
    client = chromadb.PersistentClient(path=str(tmp_path / "chroma"))
    col = client.create_collection("bench")
    col.add(
        ids=[d["id"] for d in drawers],
        documents=[d["document"] for d in drawers],
        metadatas=[
            {
                "wing": d["wing"],
                "room": d["room"],
                "source_file": d["source_file"],
                "content_hash": d["content_hash"],
                "created_at": d["created_at"],
            }
            for d in drawers
        ],
    )

    reps = 10
    print(f"\n  ── vs ChromaDB @ {N} drawers (×{reps} reps each) ──")

    # ── list_by_wing ─────────────────────────────────────────────────────
    t0 = time.perf_counter()
    for _ in range(reps):
        for w in range(10):
            store.list_by_wing(f"wing_{w}")
    store_wing_s = time.perf_counter() - t0

    t0 = time.perf_counter()
    for _ in range(reps):
        for w in range(10):
            col.get(where={"wing": f"wing_{w}"})
    chroma_wing_s = time.perf_counter() - t0

    speedup = chroma_wing_s / store_wing_s if store_wing_s > 0 else float("inf")
    print(
        f"  list_by_wing  x{10 * reps}: "
        f"ironrace {store_wing_s * 1000:.0f} ms  "
        f"chromadb {chroma_wing_s * 1000:.0f} ms  "
        f"→ ~{speedup:.1f}x"
    )

    # ── list_by_room ──────────────────────────────────────────────────────
    t0 = time.perf_counter()
    for _ in range(reps):
        for r in range(10):
            store.list_by_room(f"wing_{r}", f"room_{r}")
    store_room_s = time.perf_counter() - t0

    t0 = time.perf_counter()
    for _ in range(reps):
        for r in range(10):
            col.get(where={"$and": [{"wing": f"wing_{r}"}, {"room": f"room_{r}"}]})
    chroma_room_s = time.perf_counter() - t0

    speedup = chroma_room_s / store_room_s if store_room_s > 0 else float("inf")
    print(
        f"  list_by_room  x{10 * reps}: "
        f"ironrace {store_room_s * 1000:.0f} ms  "
        f"chromadb {chroma_room_s * 1000:.0f} ms  "
        f"→ ~{speedup:.1f}x"
    )

    # ── get_by_id ────────────────────────────────────────────────────────
    sample_ids = [d["id"] for d in drawers[:50]]

    t0 = time.perf_counter()
    for _ in range(reps):
        for doc_id in sample_ids:
            store.get_by_id(doc_id)
    store_id_s = time.perf_counter() - t0

    t0 = time.perf_counter()
    for _ in range(reps):
        for doc_id in sample_ids:
            col.get(ids=[doc_id])
    chroma_id_s = time.perf_counter() - t0

    speedup = chroma_id_s / store_id_s if store_id_s > 0 else float("inf")
    print(
        f"  get_by_id     x{50 * reps}: "
        f"ironrace {store_id_s * 1000:.0f} ms  "
        f"chromadb {chroma_id_s * 1000:.0f} ms  "
        f"→ ~{speedup:.1f}x"
    )

    # ironrace-store must be faster than ChromaDB for all three query types.
    assert store_wing_s < chroma_wing_s, "ironrace list_by_wing slower than chromadb"
    assert store_room_s < chroma_room_s, "ironrace list_by_room slower than chromadb"
    assert store_id_s < chroma_id_s, "ironrace get_by_id slower than chromadb"
