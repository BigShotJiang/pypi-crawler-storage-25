"""Tests for mempalace_ironrace.store_adapter.

Uses a fake DrawerStore in place of the real ironrace_store_ext extension.
All tests run without the Rust wheel — they only test the Python adapter logic.
"""

from __future__ import annotations

import hashlib
from unittest.mock import MagicMock, patch

import mempalace_ironrace.store_adapter as sa
import pytest

# ---------------------------------------------------------------------------
# Fake DrawerStore (replaces the C extension for unit tests)
# ---------------------------------------------------------------------------


class FakeStore:
    """Minimal in-memory stand-in for ironrace_store_ext.DrawerStore."""

    def __init__(self):
        self._drawers: dict[str, dict] = {}

    def add(self, *, id, document, wing, room, source_file, tags, content_hash, created_at):
        if any(d["content_hash"] == content_hash for d in self._drawers.values()):
            return False
        self._drawers[id] = {
            "id": id,
            "document": document,
            "wing": wing,
            "room": room,
            "source_file": source_file,
            "tags": tags,
            "content_hash": content_hash,
            "created_at": created_at,
        }
        return True

    def delete(self, id):
        return self._drawers.pop(id, None) is not None

    def count(self):
        return len(self._drawers)

    def get_by_id(self, id):
        return self._drawers.get(id)

    def add_batch(self, drawers: list) -> int:
        inserted = 0
        for fields in drawers:
            if self.add(**fields):
                inserted += 1
        return inserted


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_adapter(monkeypatch):
    """Reset module-level state before each test."""
    monkeypatch.setattr(sa, "_store", None)
    monkeypatch.setattr(sa, "_store_active", False)
    monkeypatch.setattr(sa, "_orig_add_for_store", None)
    monkeypatch.setattr(sa, "_orig_delete_for_store", None)
    monkeypatch.setattr(sa, "_backfill_thread", None)
    yield
    # Ensure patches are removed even if a test fails mid-way.
    sa.deactivate_store()


@pytest.fixture()
def fake_store(monkeypatch):
    store = FakeStore()
    monkeypatch.setattr(sa, "_store", store)
    return store


# ---------------------------------------------------------------------------
# _extract_drawer_fields
# ---------------------------------------------------------------------------


def test_extract_uses_metadata_fields():
    fields = sa._extract_drawer_fields(
        "id1",
        "Hello world",
        {"wing": "backend", "room": "api", "source_file": "/src/a.py", "tags": ["x"]},
    )
    assert fields["wing"] == "backend"
    assert fields["room"] == "api"
    assert fields["source_file"] == "/src/a.py"
    assert fields["tags"] == ["x"]


def test_extract_computes_content_hash_when_absent():
    fields = sa._extract_drawer_fields("id1", "Hello", {})
    expected = hashlib.sha256(b"Hello").hexdigest()
    assert fields["content_hash"] == expected


def test_extract_uses_content_hash_when_present():
    fields = sa._extract_drawer_fields("id1", "Hello", {"content_hash": "abc123"})
    assert fields["content_hash"] == "abc123"


def test_extract_returns_none_for_missing_document():
    assert sa._extract_drawer_fields("id1", None, {}) is None
    assert sa._extract_drawer_fields("id1", "", {}) is None


def test_extract_splits_string_tags():
    fields = sa._extract_drawer_fields("id1", "doc", {"tags": "a, b, c"})
    assert fields["tags"] == ["a", "b", "c"]


def test_extract_defaults_missing_fields():
    fields = sa._extract_drawer_fields("id1", "doc", None)
    assert fields["wing"] == "unknown"
    assert fields["room"] == "general"
    assert fields["source_file"] == ""


# ---------------------------------------------------------------------------
# make_store_synced_add / make_store_synced_delete
# ---------------------------------------------------------------------------


def test_synced_add_calls_original_first(fake_store):
    original = MagicMock(return_value="original_result")
    add_fn = sa._make_store_synced_add(original)

    mock_collection = MagicMock()
    result = add_fn(
        mock_collection,
        documents=["doc text"],
        ids=["id1"],
        metadatas=[{"wing": "w", "room": "r", "source_file": "f.md"}],
    )

    original.assert_called_once()
    assert result == "original_result"


def test_synced_add_writes_to_store(fake_store):
    original = MagicMock(return_value=None)
    add_fn = sa._make_store_synced_add(original)

    mock_collection = MagicMock()
    add_fn(
        mock_collection,
        documents=["hello world"],
        ids=["id1"],
        metadatas=[{"wing": "my_wing"}],
    )

    assert fake_store.count() == 1
    assert fake_store.get_by_id("id1") is not None


def test_synced_add_dedup_gate(fake_store):
    original = MagicMock(return_value=None)
    add_fn = sa._make_store_synced_add(original)

    mock_collection = MagicMock()
    shared_meta = [{"wing": "w", "content_hash": "same"}]
    add_fn(mock_collection, documents=["doc"], ids=["id1"], metadatas=shared_meta)
    add_fn(mock_collection, documents=["doc"], ids=["id2"], metadatas=shared_meta)

    assert fake_store.count() == 1  # second was deduplicated


def test_synced_delete_removes_from_store(fake_store):
    fake_store.add(
        id="id1", document="doc", wing="w", room="r",
        source_file="f", tags=[], content_hash="h1", created_at=0
    )
    original = MagicMock(return_value=None)
    del_fn = sa._make_store_synced_delete(original)

    mock_collection = MagicMock()
    del_fn(mock_collection, ids=["id1"])

    assert fake_store.count() == 0


def test_synced_delete_no_error_for_missing(fake_store):
    original = MagicMock(return_value=None)
    del_fn = sa._make_store_synced_delete(original)
    mock_collection = MagicMock()
    # Should not raise even if id doesn't exist.
    del_fn(mock_collection, ids=["nonexistent"])


# ---------------------------------------------------------------------------
# activate_store / deactivate_store
# ---------------------------------------------------------------------------


def test_activate_returns_false_when_store_unavailable(monkeypatch):
    monkeypatch.setattr(sa, "_store", None)

    # Simulate ironrace_store_ext not installed — block both the standalone
    # import and the bundled fallback inside the package.
    import builtins
    original_import = builtins.__import__
    _BLOCKED = {"ironrace_store_ext", "mempalace_ironrace.ironrace_store_ext"}

    def mock_import(name, *args, **kwargs):
        if name in _BLOCKED:
            raise ImportError("not installed")
        return original_import(name, *args, **kwargs)

    with patch.object(builtins, "__import__", mock_import):
        result = sa.activate_store()

    assert result is False


def test_activate_patches_chromadb_add_and_delete(fake_store, monkeypatch):
    """activate_store() patches chromadb.Collection.add and .delete."""
    mock_chromadb = MagicMock()
    original_add = MagicMock()
    original_delete = MagicMock()
    mock_chromadb.Collection.add = original_add
    mock_chromadb.Collection.delete = original_delete

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        result = sa.activate_store()

    assert result is True
    assert mock_chromadb.Collection.add is not original_add
    assert mock_chromadb.Collection.delete is not original_delete


def test_deactivate_restores_original_methods(fake_store, monkeypatch):
    mock_chromadb = MagicMock()
    original_add = MagicMock()
    original_delete = MagicMock()
    mock_chromadb.Collection.add = original_add
    mock_chromadb.Collection.delete = original_delete

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        sa.activate_store()
        sa.deactivate_store()

    assert mock_chromadb.Collection.add is original_add
    assert mock_chromadb.Collection.delete is original_delete


def test_activate_with_explicit_methods_wraps_provided_not_class(fake_store, monkeypatch):
    """When current_add/current_delete are provided, the store layer wraps them
    (not whatever is on chromadb.Collection at call time), so deactivate_store
    restores to those provided methods — not to the bare original."""
    mock_chromadb = MagicMock()
    turbo_wrapped = MagicMock(name="turbo_wrapped_add")
    turbo_wrapped_del = MagicMock(name="turbo_wrapped_delete")

    # Simulate: chromadb.Collection.add has already been turbo-patched.
    mock_chromadb.Collection.add = turbo_wrapped
    mock_chromadb.Collection.delete = turbo_wrapped_del

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        sa.activate_store(current_add=turbo_wrapped, current_delete=turbo_wrapped_del)
        sa.deactivate_store()

    # After deactivate, the class should have been restored to turbo_wrapped
    # (the layer we were given), not bare_original.
    assert mock_chromadb.Collection.add is turbo_wrapped
    assert mock_chromadb.Collection.delete is turbo_wrapped_del


def test_activate_is_idempotent(fake_store, monkeypatch):
    mock_chromadb = MagicMock()
    mock_chromadb.Collection.add = MagicMock()
    mock_chromadb.Collection.delete = MagicMock()

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        r1 = sa.activate_store()
        r2 = sa.activate_store()  # second call should be no-op

    assert r1 is True
    assert r2 is False


# ---------------------------------------------------------------------------
# migrate_from_chroma
# ---------------------------------------------------------------------------


def _make_migration_client(name, docs, metas=None):
    """Build a mock chroma client for migration tests."""
    mock_client = MagicMock()
    mock_collection = MagicMock()
    mock_collection.name = name
    mock_collection.count.return_value = len(docs)
    mock_collection.get.return_value = {
        "ids": [f"id{i}" for i in range(len(docs))],
        "documents": docs,
        "metadatas": metas or [{} for _ in docs],
    }
    mock_client.list_collections.return_value = [name]  # v0.6 API: names only
    mock_client.get_collection.return_value = mock_collection
    return mock_client


def test_migrate_from_chroma_inserts_documents(fake_store):
    mock_client = _make_migration_client(
        "test_wing",
        ["Document one.", "Document two."],
        [{"wing": "test_wing", "room": "test_room"}, {"wing": "test_wing", "room": "test_room"}],
    )

    stats = sa.migrate_from_chroma(chroma_client=mock_client)

    assert stats["total"] == 2
    assert stats["inserted"] == 2
    assert stats["errors"] == 0
    assert fake_store.count() == 2


def test_migrate_dry_run_does_not_write(fake_store):
    mock_client = _make_migration_client("test_wing", ["doc"], [{"wing": "w"}])

    stats = sa.migrate_from_chroma(chroma_client=mock_client, dry_run=True)

    assert stats["inserted"] == 1
    assert fake_store.count() == 0  # nothing was written


def test_migrate_skips_documents_without_text(fake_store):
    mock_client = _make_migration_client("c", [None, "real doc"])

    stats = sa.migrate_from_chroma(chroma_client=mock_client)

    assert stats["skipped"] == 1
    assert stats["inserted"] == 1


def test_migrate_raises_when_store_unavailable(monkeypatch):
    monkeypatch.setattr(sa, "_store", None)

    import builtins
    original_import = builtins.__import__
    _BLOCKED = {"ironrace_store_ext", "mempalace_ironrace.ironrace_store_ext"}

    def mock_import(name, *args, **kwargs):
        if name in _BLOCKED:
            raise ImportError("not installed")
        return original_import(name, *args, **kwargs)

    with patch.object(builtins, "__import__", mock_import):
        with pytest.raises(RuntimeError, match="ironrace_store_ext is not available"):
            sa.migrate_from_chroma(chroma_client=MagicMock())


# ---------------------------------------------------------------------------
# _backfill_store
# ---------------------------------------------------------------------------


def _make_mock_chroma_client(doc_count: int = 2):
    """Return a mock chromadb.PersistentClient with one collection."""
    mock_client = MagicMock()
    mock_col = MagicMock()
    mock_col.name = "backfill_wing"
    mock_col.count.return_value = doc_count
    mock_col.get.return_value = {
        "ids": [f"id{i}" for i in range(doc_count)],
        "documents": [f"Document number {i}." for i in range(doc_count)],
        "metadatas": [{"wing": "backfill_wing", "room": "general"} for _ in range(doc_count)],
    }
    # v0.6 API: list_collections() returns names only; get_collection(name) returns object.
    mock_client.list_collections.return_value = ["backfill_wing"]
    mock_client.get_collection.return_value = mock_col
    return mock_client


def test_backfill_populates_empty_store(fake_store, monkeypatch):
    """_backfill_store() migrates ChromaDB docs when the store is empty."""
    mock_client = _make_mock_chroma_client(doc_count=3)

    with patch("chromadb.PersistentClient", return_value=mock_client):
        sa._backfill_store()
        if sa._backfill_thread is not None:
            sa._backfill_thread.join(timeout=5)

    assert fake_store.count() == 3


def test_backfill_skipped_when_store_already_populated(fake_store, monkeypatch):
    """_backfill_store() is a no-op when the store already has data."""
    fake_store.add(
        id="existing",
        document="already there",
        wing="w",
        room="r",
        source_file="",
        tags=[],
        content_hash="abc123",
        created_at=0,
    )
    assert fake_store.count() == 1

    with patch("chromadb.PersistentClient") as mock_persistent:
        sa._backfill_store()
        mock_persistent.assert_not_called()

    assert fake_store.count() == 1


def test_backfill_skipped_when_chroma_empty(fake_store, monkeypatch):
    """_backfill_store() spawns no thread when ChromaDB has nothing to migrate."""
    monkeypatch.setattr(sa, "_backfill_thread", None)
    mock_client = MagicMock()
    mock_client.list_collections.return_value = []

    with patch("chromadb.PersistentClient", return_value=mock_client):
        sa._backfill_store()

    assert sa._backfill_thread is None


def test_backfill_disabled_by_env_var(fake_store, monkeypatch):
    """IRONRACE_BACKFILL=0 prevents the backfill from running."""
    monkeypatch.setenv("IRONRACE_BACKFILL", "0")
    monkeypatch.setattr(sa, "_backfill_thread", None)

    with patch("chromadb.PersistentClient") as mock_persistent:
        sa._backfill_store()
        mock_persistent.assert_not_called()

    assert sa._backfill_thread is None


def test_backfill_concurrent_writes_use_dedup_gate(fake_store, monkeypatch):
    """A document added via dual-write during backfill isn't double-inserted."""
    import hashlib
    doc = "This document arrives from both backfill and live write."
    content_hash = hashlib.sha256(doc.encode()).hexdigest()

    mock_client = MagicMock()
    mock_col = MagicMock()
    mock_col.name = "w"
    mock_col.count.return_value = 1
    mock_col.get.return_value = {
        "ids": ["live-id"],
        "documents": [doc],
        "metadatas": [{"wing": "w", "room": "r"}],
    }
    mock_client.list_collections.return_value = [mock_col]

    # Simulate a live write arriving before the backfill thread runs.
    fake_store.add(
        id="live-id", document=doc, wing="w", room="r",
        source_file="", tags=[], content_hash=content_hash, created_at=0,
    )
    assert fake_store.count() == 1

    with patch("chromadb.PersistentClient", return_value=mock_client):
        sa._backfill_store()
        if sa._backfill_thread is not None:
            sa._backfill_thread.join(timeout=5)

    # Dedup gate prevents double-insert of the same content.
    assert fake_store.count() == 1
