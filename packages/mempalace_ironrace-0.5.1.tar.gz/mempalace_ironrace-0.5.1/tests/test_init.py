"""Tests for __init__.activate() / deactivate() patch-chain layering.

These tests verify that:
  1. activate() applies the HNSW turbo layer first, then the store layer on top.
  2. deactivate() restores all three methods to the bare ChromaDB originals.
  3. deactivate_store() alone restores only to the turbo-wrapped layer, not the
     bare original — preserving the correct two-layer stack.

All tests run without the Rust wheel; the store layer is stubbed via a
MagicMock DrawerStore.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_chromadb():
    """Return a mock chromadb module with plain-function stubs on Collection.

    Plain functions are used deliberately instead of MagicMock instances.
    MagicMock auto-creates *any* attribute on access, so
    ``hasattr(mock.Collection.query, "_ironrace_patched")`` would always
    return True — causing ``activate()`` to see a "already patched" guard
    and return early without applying any patches.
    """
    mock = MagicMock()

    # These must be plain callables so hasattr(fn, "_ironrace_patched") → False.
    def bare_query(self, *a, **kw): ...
    def bare_add(self, *a, **kw): ...
    def bare_delete(self, *a, **kw): ...

    mock.Collection.query = bare_query
    mock.Collection.add = bare_add
    mock.Collection.delete = bare_delete
    return mock


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def clean_state():
    """Reset all module-level activation state before and after each test."""
    import mempalace_ironrace as mi
    import mempalace_ironrace.store_adapter as sa

    # Reset before test.
    mi._activated = False
    mi._orig_query = None
    mi._orig_add = None
    mi._orig_delete = None
    sa._store = None
    sa._store_active = False
    sa._orig_add_for_store = None
    sa._orig_delete_for_store = None

    yield

    # Teardown: deactivate unconditionally so patched sys.modules don't leak.
    try:
        mi.deactivate()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# deactivate() restores bare originals
# ---------------------------------------------------------------------------


def test_full_deactivate_restores_to_bare_original():
    """deactivate() must restore query, add, and delete to the bare originals."""
    import mempalace_ironrace as mi

    mock_chromadb = _make_mock_chromadb()
    bare_add = mock_chromadb.Collection.add
    bare_delete = mock_chromadb.Collection.delete
    bare_query = mock_chromadb.Collection.query
    fake_store = MagicMock()

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        with patch("mempalace_ironrace.store_adapter._get_store", return_value=fake_store):
            mi.activate()
            mi.deactivate()

    assert mock_chromadb.Collection.add is bare_add, "add not restored to bare original"
    assert mock_chromadb.Collection.delete is bare_delete, "delete not restored to bare original"
    assert mock_chromadb.Collection.query is bare_query, "query not restored to bare original"


# ---------------------------------------------------------------------------
# deactivate_store() restores to turbo layer (not bare original)
# ---------------------------------------------------------------------------


def test_deactivate_store_only_restores_to_turbo_layer():
    """deactivate_store() must leave the turbo patches in place.

    After activate():
        chromadb.Collection.add  →  store_layer(turbo_layer(bare_add))

    After deactivate_store():
        chromadb.Collection.add  →  turbo_layer(bare_add)

    The turbo-wrapped method is what store_adapter captured as its
    ``_orig_add_for_store``, so that is what deactivate_store() restores.
    """
    import mempalace_ironrace as mi
    import mempalace_ironrace.store_adapter as sa

    mock_chromadb = _make_mock_chromadb()
    fake_store = MagicMock()

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        with patch("mempalace_ironrace.store_adapter._get_store", return_value=fake_store):
            mi.activate()
            # The store layer wraps whatever was on Collection.add after the
            # turbo patch was applied — that is exactly _orig_add_for_store.
            turbo_add = sa._orig_add_for_store
            turbo_delete = sa._orig_delete_for_store

            sa.deactivate_store()

    assert mock_chromadb.Collection.add is turbo_add, (
        "deactivate_store() should restore to turbo-wrapped add, not bare original"
    )
    assert mock_chromadb.Collection.delete is turbo_delete, (
        "deactivate_store() should restore to turbo-wrapped delete, not bare original"
    )


# ---------------------------------------------------------------------------
# Both layers are called on a Collection.add invocation
# ---------------------------------------------------------------------------


def test_full_activation_add_routes_through_both_layers():
    """After activate(), a Collection.add call must pass through both layers.

    We intercept the turbo layer by patching adapter.make_synced_add with a
    recording wrapper, so we can verify turbo saw the call.  The store layer
    is verified via the fake DrawerStore.
    """
    import mempalace_ironrace as mi
    from mempalace_ironrace import adapter

    mock_chromadb = _make_mock_chromadb()
    turbo_calls: list[int] = []
    store_calls: list[int] = []

    bare_add = mock_chromadb.Collection.add

    def recording_make_synced_add(original_add):
        """Return a synced-add that records calls then delegates to original."""
        def synced_add(self, documents=None, ids=None, metadatas=None, **kw):
            turbo_calls.append(1)
            return original_add(self, documents=documents, ids=ids, metadatas=metadatas, **kw)
        return synced_add

    fake_store = MagicMock()
    fake_store.add = MagicMock(side_effect=lambda **kw: store_calls.append(1) or True)

    with patch.dict("sys.modules", {"chromadb": mock_chromadb}):
        with patch.object(adapter, "make_synced_add", side_effect=recording_make_synced_add):
            with patch("mempalace_ironrace.store_adapter._get_store", return_value=fake_store):
                mi.activate()

                mock_collection = MagicMock()
                mock_chromadb.Collection.add(
                    mock_collection,
                    documents=["doc text"],
                    ids=["id1"],
                    metadatas=[{"wing": "w", "room": "r"}],
                )

    assert len(turbo_calls) == 1, "turbo (HNSW sync) layer was not called"
    assert len(store_calls) == 1, "store (redb dual-write) layer was not called"
