"""Tests for the ChromaDB adapter monkey-patching logic."""

import hashlib
import os
from unittest.mock import MagicMock, patch

import pytest

# Disable auto-activation
os.environ["IRONRACE_AUTO_ACTIVATE"] = "0"

from mempalace_ironrace.adapter import (
    _get_index_path,
    _index_exists,
    make_synced_add,
    make_synced_delete,
    make_turbo_query,
)


class TestGetIndexPath:
    """Tests for path derivation from collection ID."""

    def test_path_is_deterministic(self):
        col = MagicMock()
        col.id = "test-collection-uuid"
        path1 = _get_index_path(col)
        path2 = _get_index_path(col)
        assert path1 == path2

    def test_path_is_safe(self):
        """Ensure path traversal attacks are prevented."""
        col = MagicMock()
        col.id = "../../etc/passwd"
        path = _get_index_path(col)
        # Should be a hex hash, not the raw input
        assert "etc" not in path
        assert "passwd" not in path
        assert ".ironrace/collections/" in path

    def test_different_ids_different_paths(self):
        col1 = MagicMock()
        col1.id = "collection-1"
        col2 = MagicMock()
        col2.id = "collection-2"
        assert _get_index_path(col1) != _get_index_path(col2)


class TestIndexExists:
    """Tests for index existence checking."""

    def test_nonexistent_path(self, tmp_path):
        assert not _index_exists(str(tmp_path / "nonexistent"))

    def test_empty_dir(self, tmp_path):
        d = tmp_path / "empty"
        d.mkdir()
        assert not _index_exists(str(d))

    def test_with_manifest(self, tmp_path):
        d = tmp_path / "with_manifest"
        d.mkdir()
        (d / "manifest.json").write_text("{}")
        assert _index_exists(str(d))


class TestMakeTurboQuery:
    """Tests for the turbo query wrapper."""

    def test_fallback_when_no_index(self):
        """When no index exists and bootstrap fails, falls back to original."""
        original = MagicMock(return_value={"ids": [["id1"]]})
        patched = make_turbo_query(original)

        collection = MagicMock()
        collection.id = "test-id"
        collection.count.return_value = 0

        result = patched(collection, ["test query"], n_results=5)
        assert result == {"ids": [["id1"]]}
        original.assert_called_once()

    def test_circuit_breaker_disables_after_failures(self):
        """After MAX_FAILURES, turbo is disabled for the session."""
        import mempalace_ironrace.adapter as adapter

        # Reset state
        adapter._failure_count = 0
        adapter._disabled = False

        original = MagicMock(return_value={"ids": [[]]})
        patched = make_turbo_query(original)

        collection = MagicMock()
        collection.id = "breaker-test"

        # Should fall back each time since no real index
        for _ in range(5):
            patched(collection, ["query"], n_results=1)

        # Verify original was always called (turbo never succeeded)
        assert original.call_count >= 3

        # Reset state for other tests
        adapter._failure_count = 0
        adapter._disabled = False


class TestMakeSyncedAdd:
    """Tests for the synced add wrapper."""

    def test_original_always_called(self):
        """ChromaDB add is always called, even if sync fails."""
        original = MagicMock(return_value=None)
        patched = make_synced_add(original)

        collection = MagicMock()
        collection.id = "test-id"

        patched(
            collection,
            documents=["hello"],
            ids=["id1"],
            metadatas=[{"wing": "test"}],
        )

        original.assert_called_once()


class TestMakeSyncedDelete:
    """Tests for the synced delete wrapper."""

    def test_original_always_called(self):
        """ChromaDB delete is always called."""
        original = MagicMock(return_value=None)
        patched = make_synced_delete(original)

        collection = MagicMock()
        collection.id = "test-id"

        patched(collection, ids=["id1"])

        original.assert_called_once()
