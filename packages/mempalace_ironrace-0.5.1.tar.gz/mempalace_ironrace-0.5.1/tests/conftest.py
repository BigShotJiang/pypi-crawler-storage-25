"""Test fixtures for mempalace-ironrace integration tests."""

import os

# Skip tests that require the full ironrace-turbo extension
IRONRACE_AVAILABLE = False
try:
    from ironrace_turbo import TurboCollection

    IRONRACE_AVAILABLE = True
except ImportError:
    pass

# Disable auto-activation during tests
os.environ["IRONRACE_AUTO_ACTIVATE"] = "0"
