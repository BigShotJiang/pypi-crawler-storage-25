"""Tests for mempalace_ironrace.hooks — install/uninstall/status logic.

All tests run in a fully isolated fake $HOME so they never touch the real
~/.claude/settings.json or ~/.mempalace/bin/.
"""

import json
import os
import platform
import stat
from pathlib import Path

import pytest

# Isolate from real $HOME before importing hooks.
_BIN_NAME = "mempal-hook.exe" if platform.system() == "Windows" else "mempal-hook"


@pytest.fixture()
def fake_home(tmp_path, monkeypatch):
    """Redirect Path.home() and os.path.expanduser to a temp directory."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    # Patch Path.home() used by hooks module.
    monkeypatch.setattr(Path, "home", staticmethod(lambda: home))
    return home


@pytest.fixture()
def fake_binary(tmp_path):
    """Create a tiny fake mempal-hook binary."""
    bin_dir = tmp_path / "fake_bin"
    bin_dir.mkdir()
    binary = bin_dir / _BIN_NAME
    binary.write_bytes(b"#!/bin/sh\necho '{}'\n")
    binary.chmod(0o755)
    return binary


@pytest.fixture()
def hooks(fake_home, fake_binary, monkeypatch):
    """Import hooks with patched _find_binary so no cargo needed."""
    import importlib

    import mempalace_ironrace.hooks as h

    importlib.reload(h)  # re-evaluate module-level constants with new HOME

    monkeypatch.setattr(h, "_find_binary", lambda: fake_binary)
    monkeypatch.setattr(h, "_INSTALL_DIR", fake_home / ".mempalace" / "bin")
    monkeypatch.setattr(h, "_INSTALLED_BIN", fake_home / ".mempalace" / "bin" / _BIN_NAME)
    monkeypatch.setattr(h, "_SETTINGS", fake_home / ".claude" / "settings.json")
    # Disable integrity check for tests that use a fake binary — the sha256
    # is for the real compiled binary; pointing at a nonexistent path triggers
    # the graceful no-op path in _verify_binary().
    monkeypatch.setattr(h, "_SHA256_FILE", fake_home / "no-such-file.sha256")
    return h


# ---------------------------------------------------------------------------
# install()
# ---------------------------------------------------------------------------


def test_install_copies_binary(hooks, fake_home):
    hooks.install()
    installed = fake_home / ".mempalace" / "bin" / _BIN_NAME
    assert installed.exists()
    # Executable bit set.
    assert installed.stat().st_mode & stat.S_IXUSR


def test_install_writes_hook_entries(hooks, fake_home):
    hooks.install()
    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    for event in ("Stop", "SessionStart", "PreCompact"):
        groups = settings["hooks"][event]
        assert any("mempal-hook" in str(g) for g in groups), f"missing hook for {event}"


def test_install_is_idempotent(hooks, fake_home):
    hooks.install()
    hooks.install()
    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    # Each event should have exactly one mempal-hook entry.
    for event in ("Stop", "SessionStart", "PreCompact"):
        our_entries = [
            g for g in settings["hooks"][event]
            if any("mempal-hook" in str(h) for h in g.get("hooks", []))
        ]
        assert len(our_entries) == 1, f"duplicate entries for {event}: {our_entries}"


def test_install_preserves_existing_hooks(hooks, fake_home):
    """Pre-existing hook entries must not be removed."""
    settings_path = fake_home / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    existing = {
        "hooks": {
            "Stop": [
                {
                    "matcher": "",
                    "hooks": [{"type": "command", "command": "terminal-notifier"}],
                }
            ]
        }
    }
    settings_path.write_text(json.dumps(existing))

    hooks.install()

    settings = json.loads(settings_path.read_text())
    stop_cmds = [
        h["command"]
        for g in settings["hooks"]["Stop"]
        for h in g.get("hooks", [])
    ]
    assert any("terminal-notifier" in c for c in stop_cmds), "existing hook was removed"
    assert any("mempal-hook" in c for c in stop_cmds), "our hook was not added"


def test_install_force_overwrites_binary(hooks, fake_home, fake_binary):
    hooks.install()
    installed = fake_home / ".mempalace" / "bin" / _BIN_NAME
    installed.write_bytes(b"old content")
    hooks.install(force=True)
    assert installed.read_bytes() != b"old content"


# ---------------------------------------------------------------------------
# uninstall()
# ---------------------------------------------------------------------------


def test_uninstall_removes_hook_entries(hooks, fake_home):
    hooks.install()
    hooks.uninstall()
    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    for event in ("Stop", "SessionStart", "PreCompact"):
        groups = settings["hooks"].get(event, [])
        assert not any("mempal-hook" in str(g) for g in groups), f"hook not removed for {event}"


def test_uninstall_preserves_other_hooks(hooks, fake_home):
    settings_path = fake_home / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    existing = {
        "hooks": {
            "Stop": [
                {
                    "matcher": "",
                    "hooks": [{"type": "command", "command": "terminal-notifier"}],
                }
            ]
        }
    }
    settings_path.write_text(json.dumps(existing))

    hooks.install()
    hooks.uninstall()

    settings = json.loads(settings_path.read_text())
    stop_cmds = [
        h["command"]
        for g in settings["hooks"].get("Stop", [])
        for h in g.get("hooks", [])
    ]
    assert any("terminal-notifier" in c for c in stop_cmds), "pre-existing hook was removed"
    assert not any("mempal-hook" in c for c in stop_cmds), "our hook was not removed"


def test_uninstall_remove_binary_flag(hooks, fake_home):
    hooks.install()
    installed = fake_home / ".mempalace" / "bin" / _BIN_NAME
    assert installed.exists()
    hooks.uninstall(remove_binary=True)
    assert not installed.exists()


def test_uninstall_no_error_when_not_installed(hooks, fake_home):
    """uninstall() on a clean system should not raise."""
    hooks.uninstall()


# ---------------------------------------------------------------------------
# Settings JSON helpers (_add_hook / _remove_hook)
# ---------------------------------------------------------------------------


def test_add_hook_puts_entry_first(hooks, fake_home):
    """Our hook entry should be prepended so it runs before others."""
    settings = {
        "hooks": {
            "Stop": [
                {"matcher": "", "hooks": [{"type": "command", "command": "other-tool"}]}
            ]
        }
    }
    result = hooks._add_hook(settings, "Stop", Path("/fake/mempal-hook"))
    first_cmd = result["hooks"]["Stop"][0]["hooks"][0]["command"]
    assert "mempal-hook" in first_cmd


def test_add_hook_does_not_duplicate(hooks, fake_home):
    settings: dict = {"hooks": {}}
    settings = hooks._add_hook(settings, "Stop", Path("/fake/mempal-hook"))
    settings = hooks._add_hook(settings, "Stop", Path("/fake/mempal-hook"))
    assert len(settings["hooks"]["Stop"]) == 1


def test_remove_hook_no_op_on_missing(hooks):
    settings: dict = {"hooks": {"Stop": []}}
    result = hooks._remove_hook(settings, "Stop")
    assert result["hooks"]["Stop"] == []


# ---------------------------------------------------------------------------
# Settings JSON — corrupt file recovery
# ---------------------------------------------------------------------------


def test_install_on_corrupt_settings_json_recovers_gracefully(hooks, fake_home):
    """A malformed settings.json must not prevent install() from succeeding."""
    settings_path = fake_home / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text("{ this is not valid JSON }")

    # Should not raise.
    hooks.install()

    settings = json.loads(settings_path.read_text())
    assert "hooks" in settings


# ---------------------------------------------------------------------------
# Binary integrity verification
# ---------------------------------------------------------------------------


def test_verify_binary_passes_for_correct_hash(hooks, fake_home, fake_binary, tmp_path):
    """_verify_binary does not raise when hash matches the .sha256 file."""
    import hashlib

    sha256_file = tmp_path / f"{_BIN_NAME}.sha256"
    sha256_file.write_text(
        hashlib.sha256(fake_binary.read_bytes()).hexdigest() + "\n"
    )
    monkeypatch_sha256 = None  # access via hooks module attribute

    import mempalace_ironrace.hooks as h
    original = h._SHA256_FILE
    try:
        h._SHA256_FILE = sha256_file
        # Should not raise.
        h._verify_binary(fake_binary)
    finally:
        h._SHA256_FILE = original


def test_verify_binary_raises_for_wrong_hash(hooks, fake_home, fake_binary, tmp_path):
    """_verify_binary raises FileNotFoundError when hash does not match."""
    sha256_file = tmp_path / f"{_BIN_NAME}.sha256"
    sha256_file.write_text("a" * 64 + "\n")  # definitely wrong hash

    import mempalace_ironrace.hooks as h
    original = h._SHA256_FILE
    try:
        h._SHA256_FILE = sha256_file
        with pytest.raises(FileNotFoundError, match="integrity check failed"):
            h._verify_binary(fake_binary)
    finally:
        h._SHA256_FILE = original


def test_verify_binary_is_noop_when_sha256_file_absent(hooks, fake_home, fake_binary, tmp_path):
    """_verify_binary is a no-op (does not raise) when no .sha256 file is present."""
    absent = tmp_path / "does_not_exist.sha256"

    import mempalace_ironrace.hooks as h
    original = h._SHA256_FILE
    try:
        h._SHA256_FILE = absent
        h._verify_binary(fake_binary)  # must not raise
    finally:
        h._SHA256_FILE = original


def test_install_raises_when_installed_binary_hash_mismatch(
    hooks, fake_home, fake_binary, tmp_path
):
    """install() must not register a hook for a binary that fails the hash check."""
    import hashlib

    import mempalace_ironrace.hooks as h

    # Place a 'tampered' binary at the install location.
    install_dir = fake_home / ".mempalace" / "bin"
    install_dir.mkdir(parents=True, exist_ok=True)
    tampered = install_dir / _BIN_NAME
    tampered.write_bytes(b"#!/bin/sh\necho evil\n")
    tampered.chmod(0o755)

    # Embed the hash of the *legitimate* binary (fake_binary), not the tampered one.
    sha256_file = tmp_path / f"{_BIN_NAME}.sha256"
    sha256_file.write_text(
        hashlib.sha256(fake_binary.read_bytes()).hexdigest() + "\n"
    )

    original_sha = h._SHA256_FILE
    try:
        h._SHA256_FILE = sha256_file
        with pytest.raises(FileNotFoundError, match="integrity check failed"):
            h.install()
    finally:
        h._SHA256_FILE = original_sha

    # Settings must not have been written.
    settings_path = fake_home / ".claude" / "settings.json"
    assert not settings_path.exists()
