# mempalace-ironrace

Turbo vector search for MemPalace. ~100x faster at scale.

```
pip install mempalace-ironrace
```

That's it. Searches are automatically accelerated.
