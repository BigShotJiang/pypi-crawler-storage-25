"""Hatchling build hook — compiles Rust artifacts and vendors them into the
wheel at build time:

  1. mempal-hook binary  →  mempalace_ironrace/bin/mempal-hook[.exe]
  2. ironrace_store_ext  →  mempalace_ironrace/ironrace_store_ext.abi3.so (or .pyd)

If `cargo`/`maturin` are not on PATH the hook emits a warning and produces a
wheel without the corresponding artifact; the runtime code degrades gracefully.
"""

import hashlib
import platform
import shutil
import subprocess
import zipfile
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

# Absolute path to the workspace root (two dirs above this file).
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_PKG_DIR = Path(__file__).resolve().parent / "mempalace_ironrace"

# mempal-hook
_HOOK_CRATE = "mempal-hook"
_BIN_NAME = "mempal-hook.exe" if platform.system() == "Windows" else "mempal-hook"
_BIN_DEST_DIR = _PKG_DIR / "bin"

# ironrace-store-py
_STORE_CRATE_DIR = _REPO_ROOT / "crates" / "ironrace-store-py"
_STORE_WHEELS_DIR = _REPO_ROOT / "target" / "wheels"


class CustomBuildHook(BuildHookInterface):
    """Compile Rust artifacts and include them as package data."""

    PLUGIN_NAME = "custom"

    def initialize(self, version: str, build_data: dict) -> None:  # type: ignore[override]
        fi = build_data.setdefault("force_include", {})
        self._build_mempal_hook(fi)
        if self._build_store_ext(fi):
            # Wheel contains a native extension — mark as non-pure.
            build_data["pure_python"] = False

    # ------------------------------------------------------------------
    # mempal-hook
    # ------------------------------------------------------------------

    def _build_mempal_hook(self, force_include: dict) -> None:
        if not shutil.which("cargo"):
            self.app.display_warning(
                "cargo not found — skipping mempal-hook compilation. "
                "The wheel will not include the hook binary."
            )
            return

        self.app.display_info(f"Building {_HOOK_CRATE} (release) …")
        result = subprocess.run(
            ["cargo", "build", "-p", _HOOK_CRATE, "--release", "--quiet"],
            cwd=_REPO_ROOT,
            check=False,
        )
        if result.returncode != 0:
            self.app.display_warning(
                f"cargo build -p {_HOOK_CRATE} failed (exit {result.returncode}). "
                "The wheel will not include the hook binary."
            )
            return

        src = _REPO_ROOT / "target" / "release" / _BIN_NAME
        if not src.exists():
            self.app.display_warning(f"Built binary not found at {src}")
            return

        _BIN_DEST_DIR.mkdir(parents=True, exist_ok=True)
        dest = _BIN_DEST_DIR / _BIN_NAME
        shutil.copy2(src, dest)
        dest.chmod(0o755)
        self.app.display_info(f"Vendored {_BIN_NAME} → {dest.relative_to(_REPO_ROOT)}")

        sha256 = hashlib.sha256(dest.read_bytes()).hexdigest()
        sha256_dest = _BIN_DEST_DIR / f"{_BIN_NAME}.sha256"
        sha256_dest.write_text(sha256 + "\n", encoding="ascii")
        self.app.display_info(f"Wrote checksum → {sha256_dest.relative_to(_REPO_ROOT)}")

        force_include[str(dest)] = f"mempalace_ironrace/bin/{_BIN_NAME}"
        force_include[str(sha256_dest)] = f"mempalace_ironrace/bin/{_BIN_NAME}.sha256"

    # ------------------------------------------------------------------
    # ironrace-store-py  (maturin → .so / .pyd bundled inside package)
    # ------------------------------------------------------------------

    def _build_store_ext(self, force_include: dict) -> bool:
        """Build ironrace_store_ext and vendor the .so into the package.

        Returns True if the extension was successfully bundled.
        """
        if not shutil.which("maturin"):
            self.app.display_warning(
                "maturin not found — skipping ironrace-store-py compilation. "
                "DrawerStore will not be available without a separate install."
            )
            return False

        self.app.display_info("Building ironrace-store-py (release) …")
        _STORE_WHEELS_DIR.mkdir(parents=True, exist_ok=True)
        result = subprocess.run(
            [
                "maturin",
                "build",
                "--release",
                "--out",
                str(_STORE_WHEELS_DIR),
                "--quiet",
            ],
            cwd=_STORE_CRATE_DIR,
            check=False,
        )
        if result.returncode != 0:
            self.app.display_warning(
                f"maturin build failed (exit {result.returncode}). "
                "ironrace_store_ext will not be bundled."
            )
            return False

        # Pick the most recently built wheel.
        wheels = sorted(
            _STORE_WHEELS_DIR.glob("ironrace_store_ext-*.whl"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if not wheels:
            self.app.display_warning("No ironrace_store_ext wheel found after maturin build.")
            return False

        wheel = wheels[0]
        self.app.display_info(f"Extracting extension from {wheel.name} …")

        # Extract the platform extension (.so or .pyd) from the wheel zip.
        # Inside the wheel, maturin nests it as ironrace_store_ext/ironrace_store_ext.abi3.so
        with zipfile.ZipFile(wheel) as zf:
            so_entries = [
                n for n in zf.namelist()
                if n.endswith(".so") or n.endswith(".pyd")
            ]
            if not so_entries:
                self.app.display_warning("No .so/.pyd entry found in ironrace_store_ext wheel.")
                return False

            so_zip_path = so_entries[0]         # "ironrace_store_ext/ironrace_store_ext.abi3.so"
            so_filename = Path(so_zip_path).name # "ironrace_store_ext.abi3.so"
            dest = _PKG_DIR / so_filename
            dest.write_bytes(zf.read(so_zip_path))

        self.app.display_info(f"Vendored {so_filename} → {dest.relative_to(_REPO_ROOT)}")
        force_include[str(dest)] = f"mempalace_ironrace/{so_filename}"
        return True
