from __future__ import annotations

from pathlib import Path
from typing import Literal

from acw.config.shared import (
    PROMPT_EXTEND_MARKER,
    PROMPT_NAME_PATTERN,
    PROMPT_OVERRIDE_MARKER,
    ConfigError,
    ConfigLayout,
)
from acw.prompt_catalog import (
    FORMAT_PROMPT_NAMES,
    SUPPORTED_PROMPT_LANGUAGES,
    make_prompt_stem,
)


def resolve_prompt_path(
    layout: ConfigLayout, prompt_name: str, *, language: str | None = None
) -> Path:
    normalized_name = prompt_name.strip()
    if not normalized_name:
        raise ConfigError("프롬프트 이름은 비워둘 수 없습니다.")
    if PROMPT_NAME_PATTERN.match(normalized_name) is None:
        raise ConfigError(
            "프롬프트 이름 형식이 잘못되었습니다. 영문/숫자/`._-`만 사용할 수 있습니다."
        )
    if language is not None and language not in SUPPORTED_PROMPT_LANGUAGES:
        raise ConfigError(f"지원하지 않는 언어입니다: {language}")
    return (
        layout.prompts_dir
        / f"{make_prompt_stem(normalized_name, language=language)}.md"
    )


def save_prompt(
    layout: ConfigLayout,
    *,
    prompt_name: str,
    content: str,
    language: str | None = None,
) -> Path:
    prompt_path = resolve_prompt_path(layout, prompt_name, language=language)
    _ = prompt_path.write_text(content, encoding="utf-8")
    return prompt_path


def load_prompt(
    layout: ConfigLayout,
    *,
    prompt_name: str,
    language: str | None = None,
) -> str:
    prompt_path = resolve_prompt_path(layout, prompt_name, language=language)
    if not prompt_path.exists():
        if language is not None:
            fallback_path = resolve_prompt_path(layout, prompt_name, language=None)
            if fallback_path.exists():
                return fallback_path.read_text(encoding="utf-8")
        raise ConfigError(f"프롬프트를 찾을 수 없습니다: {prompt_name} ({prompt_path})")
    return prompt_path.read_text(encoding="utf-8")


def resolve_effective_prompt(
    layout: ConfigLayout,
    *,
    prompt_name: str | None,
    language: str,
    format_name: str,
) -> str:
    if format_name not in FORMAT_PROMPT_NAMES:
        raise ConfigError(f"지원하지 않는 포맷입니다: {format_name}")

    base_prompt = load_prompt(
        layout, prompt_name=format_name, language=language
    ).strip()
    custom_prompt_name = _resolve_custom_prompt_name(
        prompt_name=prompt_name,
        format_name=format_name,
    )
    if custom_prompt_name is None:
        return base_prompt

    custom_prompt = load_prompt(
        layout, prompt_name=custom_prompt_name, language=language
    )
    mode, custom_body = _parse_prompt_composition(custom_prompt)
    if mode == "override":
        return custom_body
    return _merge_prompt_sections(base_prompt, custom_body)


def list_prompt_names(
    layout: ConfigLayout, *, language: str | None = None
) -> list[str]:
    if language is not None:
        if language not in SUPPORTED_PROMPT_LANGUAGES:
            raise ConfigError(f"지원하지 않는 언어입니다: {language}")
        suffix = f".{language}.md"
        prompt_files = sorted(layout.prompts_dir.glob(f"*{suffix}"))
        return [file.name[: -len(suffix)] for file in prompt_files]

    prompt_files = sorted(layout.prompts_dir.glob("*.md"))
    return [file.stem for file in prompt_files]


def _parse_prompt_composition(
    content: str,
) -> tuple[Literal["extend", "override"], str]:
    lines = content.splitlines()
    first_non_empty_index = -1
    for index, line in enumerate(lines):
        if line.strip():
            first_non_empty_index = index
            break

    if first_non_empty_index == -1:
        return "extend", ""

    first_non_empty_line = lines[first_non_empty_index].strip().lower()
    if first_non_empty_line == PROMPT_OVERRIDE_MARKER:
        body_lines = lines[:first_non_empty_index] + lines[first_non_empty_index + 1 :]
        return "override", "\n".join(body_lines).strip()
    if first_non_empty_line == PROMPT_EXTEND_MARKER:
        body_lines = lines[:first_non_empty_index] + lines[first_non_empty_index + 1 :]
        return "extend", "\n".join(body_lines).strip()

    return "extend", content.strip()


def _resolve_custom_prompt_name(
    *,
    prompt_name: str | None,
    format_name: str,
) -> str | None:
    if prompt_name is None:
        return None

    normalized = prompt_name.strip()
    if not normalized:
        return None
    if normalized == format_name:
        return None
    return normalized


def _merge_prompt_sections(base: str, extra: str) -> str:
    base_text = base.strip()
    extra_text = extra.strip()
    if not base_text:
        return extra_text
    if not extra_text:
        return base_text
    return f"{base_text}\n\n{extra_text}"
