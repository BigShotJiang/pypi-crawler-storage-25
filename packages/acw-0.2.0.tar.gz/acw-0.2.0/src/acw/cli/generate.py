from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from acw.cli.parser import GenerateArgs
from acw.config import (
    ConfigError,
    ConfigLayout,
    MissingAPIKeyError,
    ResolvedGenerateSettings,
)
from acw.diff_collector import CollectedDiff, DiffCollectionError
from acw.generate_input import GenerateInput, GenerateInputError
from acw.generator import GenerationError


@dataclass(frozen=True, slots=True)
class GenerateCommandDeps:
    ensure_config_layout: Callable[[], ConfigLayout]
    is_interactive_terminal: Callable[[], bool]
    collect_staged_files: Callable[[], tuple[list[str], str | None]]
    confirm_generation_for_staged_files: Callable[[list[str], bool, bool, bool], bool]
    resolve_generate_settings_fn: Callable[
        [ConfigLayout, GenerateArgs], ResolvedGenerateSettings
    ]
    collect_diff_fn: Callable[..., CollectedDiff]
    truncate_diff_with_confirmation_fn: Callable[
        [CollectedDiff, int, bool], CollectedDiff | None
    ]
    resolve_prompt_selection_fn: Callable[
        [ConfigLayout, GenerateArgs, str, str], tuple[str | None, str | None]
    ]
    resolve_prompt_text_fn: Callable[
        [ConfigLayout, str | None, str | None, str, str], str
    ]
    build_generate_input_fn: Callable[..., GenerateInput]
    run_generation_loop_fn: Callable[[GenerateInput, bool, bool], list[str]]
    select_commit_message_interactive_fn: Callable[[list[str], bool], str | None]
    confirm_fn: Callable[[str, bool | str, list[str] | None], str | bool | None]
    create_git_commit_fn: Callable[[str, bool, bool], str | None]
    copy_to_clipboard_fn: Callable[[str], str | None]
    console: Console


@dataclass(frozen=True, slots=True)
class RunGenerationLoopDeps:
    run_with_generation_progress: Callable[
        [str, Callable[[], str | list[str]], float, bool], str | list[str]
    ]
    generate_commit_message: Callable[[GenerateInput], str]
    generate_commit_messages: Callable[[GenerateInput], list[str]]
    render_generated_messages: Callable[[list[str]], None]
    is_interactive_terminal: Callable[[], bool]
    confirm_fn: Callable[[str, bool | str, list[str] | None], str | bool | None]
    select_from_history_fn: Callable[[list[list[str]]], list[str] | None]


def handle_generate_command(
    args: GenerateArgs,
    deps: GenerateCommandDeps,
) -> int:
    interactive_commit_flow = (
        deps.is_interactive_terminal() and not args.json and args.output is None
    )
    emit_candidate_output = not args.json and args.output is None

    layout = deps.ensure_config_layout()
    if args.max_diff_size <= 0:
        print("입력 정규화 오류: `--max-diff-size` 는 1 이상의 정수여야 합니다.")
        return 2
    if args.json and args.print_prompt:
        print("입력 오류: `--json` 과 `--print-prompt` 는 함께 사용할 수 없습니다.")
        return 2

    if args.from_stash is None and args.from_ref is None:
        staged_files, staged_error = deps.collect_staged_files()
        if staged_error is not None:
            deps.console.print(
                Panel(
                    Text(f"staged 파일 목록을 가져오지 못했습니다.\n{staged_error}"),
                    title="실행 안내",
                    border_style="yellow",
                    expand=True,
                )
            )
            return 2
        if not staged_files:
            deps.console.print(
                Panel(
                    Text(
                        "staged된 파일이 없습니다.\n먼저 `git add` 후 다시 시도하세요."
                    ),
                    title="실행 안내",
                    border_style="yellow",
                    expand=True,
                )
            )
            return 2
        if not deps.confirm_generation_for_staged_files(
            staged_files,
            args.yes,
            not args.json,
            deps.is_interactive_terminal() and not args.json,
        ):
            deps.console.print(
                Panel(
                    Text("메시지 생성을 취소했습니다."),
                    title="실행 안내",
                    border_style="yellow",
                    expand=True,
                )
            )
            return 2

    try:
        resolved = deps.resolve_generate_settings_fn(layout, args)
    except ConfigError as error:
        print(f"설정 오류: {error}")
        return 2
    try:
        collected = deps.collect_diff_fn(
            from_stash=args.from_stash,
            from_ref=args.from_ref,
            exclude=args.exclude,
            max_diff_size=None,
        )
    except DiffCollectionError as error:
        print(f"입력 수집 오류: {error}")
        return 2

    collected = deps.truncate_diff_with_confirmation_fn(
        collected, args.max_diff_size, args.yes
    )
    if collected is None:
        return 2

    try:
        prompt_name, prompt_file = deps.resolve_prompt_selection_fn(
            layout,
            args,
            resolved.language,
            resolved.format,
        )
        prompt_text = deps.resolve_prompt_text_fn(
            layout,
            prompt_name,
            prompt_file,
            resolved.language,
            resolved.format,
        )
        normalized_input = deps.build_generate_input_fn(
            resolved=resolved,
            collected=collected,
            prompt_name=prompt_name,
            prompt_file=prompt_file,
            prompt_text=prompt_text,
            print_prompt=args.print_prompt,
            candidate_count=args.generate,
            exclude_patterns=args.exclude,
            max_diff_size=args.max_diff_size,
        )
    except GenerateInputError as error:
        print(f"입력 정규화 오류: {error}")
        return 2
    except ConfigError as error:
        print(f"설정 오류: {error}")
        return 2

    if normalized_input.print_prompt:
        print("----- ACW PROMPT BEGIN -----")
        print(normalized_input.prompt_text)
        print("----- ACW PROMPT END -----")

    try:
        commit_messages = deps.run_generation_loop_fn(
            normalized_input,
            emit_candidate_output,
            interactive_commit_flow and not args.yes,
        )
    except GenerationError as error:
        print(f"생성 오류: {error}")
        return 2

    selected_message = commit_messages[0]
    committed = False
    should_select_interactive = (
        len(commit_messages) > 1
        and deps.is_interactive_terminal()
        and not args.json
        and args.output is None
    )
    if should_select_interactive:
        selected_message = deps.select_commit_message_interactive_fn(
            commit_messages, args.yes
        )
        if selected_message is None:
            print("메시지 선택을 취소했습니다.")
            return 2
        print(f"선택된 메시지: {selected_message}")

    if interactive_commit_flow:
        if not args.yes:
            if emit_candidate_output:
                print()
            confirmed = deps.confirm_fn(
                "선택한 메시지로 실제 git commit을 생성할까요?", True, None
            )
            if confirmed is None or not confirmed:
                print("커밋 생성을 취소했습니다.")
                return 2
        if args.dry_run:
            print("`--dry-run` 모드이므로 실제 commit은 생성하지 않습니다.")
            committed = False
        else:
            commit_error = deps.create_git_commit_fn(
                selected_message,
                args.all,
                args.no_verify,
            )
            if commit_error is not None:
                print(f"커밋 오류: {commit_error}")
                return 2
            committed = True

    if args.output is not None:
        output_path = Path(args.output).expanduser()
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            _ = output_path.write_text(f"{selected_message}\n", encoding="utf-8")
        except OSError as error:
            print(
                f"출력 오류: 결과 파일을 저장할 수 없습니다. ({output_path}: {error})"
            )
            return 2

    if args.clipboard:
        clipboard_error = deps.copy_to_clipboard_fn(selected_message)
        if clipboard_error is not None:
            print(f"클립보드 오류: {clipboard_error}")
            return 2

    if args.json:
        payload = {
            "message": selected_message,
            "candidates": commit_messages,
            "candidate_count": len(commit_messages),
            "dry_run": args.dry_run,
            "committed": committed,
        }
        print(json.dumps(payload, ensure_ascii=False))

    return 0


def run_generation_loop(
    input_data: GenerateInput,
    *,
    emit_output: bool,
    prompt_retry: bool,
    deps: RunGenerationLoopDeps,
) -> list[str]:
    history: list[list[str]] = []
    while True:
        if input_data.candidate_count <= 1:
            commit_message = deps.run_with_generation_progress(
                "Generating your AI commit message...",
                lambda: deps.generate_commit_message(input_data),
                input_data.timeout_seconds,
                emit_output,
            )
            commit_messages = (
                [commit_message] if isinstance(commit_message, str) else commit_message
            )
        else:
            generated = deps.run_with_generation_progress(
                "Generating your AI commit messages...",
                lambda: deps.generate_commit_messages(input_data),
                input_data.timeout_seconds,
                emit_output,
            )
            commit_messages = generated if isinstance(generated, list) else [generated]

        history.append(commit_messages)

        while True:
            if emit_output:
                deps.render_generated_messages(
                    commit_messages[: input_data.candidate_count],
                )

            if not prompt_retry:
                return commit_messages
            if not deps.is_interactive_terminal():
                return commit_messages

            if len(history) > 1:
                choice = deps.confirm_fn(
                    "메시지를 어떻게 할까요?",
                    "Accept",
                    ["Accept", "Retry", "History"],
                )
                if choice == "Retry":
                    break  # Break inner loop to regenerate
                if choice == "History":
                    selected = deps.select_from_history_fn(history)
                    if selected is not None:
                        commit_messages = selected
                        # Re-render the selected messages and stay in inner loop to ask again
                        continue
                return commit_messages
            else:
                should_retry = deps.confirm_fn("메시지를 다시 생성할까요?", False, None)
                if not should_retry:
                    return commit_messages
                break  # Break inner loop to regenerate


def resolve_generate_settings_for_generate(
    layout: ConfigLayout,
    args: GenerateArgs,
    *,
    resolve_generate_settings: Callable[..., ResolvedGenerateSettings],
    is_interactive_terminal: Callable[[], bool],
    run_onboarding_wizard: Callable[[ConfigLayout], bool],
) -> ResolvedGenerateSettings:
    try:
        return resolve_generate_settings(
            layout=layout,
            cli_provider=args.provider,
            cli_model=args.model,
            cli_profile=args.profile,
            cli_language=args.language,
            cli_format=args.format,
        )
    except MissingAPIKeyError as error:
        if not is_interactive_terminal():
            raise ConfigError(
                f"{error} 비대화형 환경이므로 `acw config` 로 먼저 설정을 완료하세요."
            ) from error

        print(
            f"provider '{error.provider}'의 API 키 설정이 없어 설정 마법사를 시작합니다."
        )
        completed = run_onboarding_wizard(layout)
        if not completed:
            raise ConfigError(
                "설정 마법사를 취소했습니다. `acw config` 로 다시 시도하세요."
            ) from error
        return resolve_generate_settings(
            layout=layout,
            cli_provider=args.provider,
            cli_model=args.model,
            cli_profile=args.profile,
            cli_language=args.language,
            cli_format=args.format,
        )


def resolve_prompt_selection(
    layout: ConfigLayout,
    args: GenerateArgs,
    *,
    language: str,
    format_name: str,
    normalize_optional_str: Callable[[str | None], str | None],
    load_config_settings: Callable[[ConfigLayout], object],
    resolve_prompt_path: Callable[[ConfigLayout, str, str], Path],
    default_prompt: str,
) -> tuple[str | None, str | None]:
    prompt_file = normalize_optional_str(args.prompt_file)
    if prompt_file is not None:
        return None, prompt_file

    settings = load_config_settings(layout)
    settings_prompt = getattr(settings, "prompt", None)
    prompt_name = (
        normalize_optional_str(args.prompt)
        or normalize_optional_str(settings_prompt)
        or format_name
        or default_prompt
    )
    _ = resolve_prompt_path(layout, prompt_name, language)
    return prompt_name, None


def resolve_prompt_text(
    layout: ConfigLayout,
    *,
    prompt_name: str | None,
    prompt_file: str | None,
    language: str,
    format_name: str,
    resolve_effective_prompt: Callable[..., str],
) -> str:
    if prompt_file is not None:
        prompt_file_path = Path(prompt_file).expanduser()
        try:
            return prompt_file_path.read_text(encoding="utf-8")
        except OSError as error:
            raise ConfigError(
                f"프롬프트 파일을 읽을 수 없습니다: {prompt_file_path} ({error})"
            ) from error
    return resolve_effective_prompt(
        layout,
        prompt_name=prompt_name,
        language=language,
        format_name=format_name,
    )
