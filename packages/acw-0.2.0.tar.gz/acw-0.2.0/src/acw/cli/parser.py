from __future__ import annotations

import argparse
from collections.abc import Callable
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version as package_version
from typing import Literal, TypeAlias

CommandHandler: TypeAlias = Callable[["BaseArgs"], int]


class BaseArgs(argparse.Namespace):
    command: str | None = None
    handler: CommandHandler | None = None


class GenerateArgs(BaseArgs):
    provider: str | None = None
    model: str | None = None
    profile: str | None = None
    prompt: str | None = None
    prompt_file: str | None = None
    print_prompt: bool = False
    language: Literal["ko", "en"] | None = None
    format: Literal["plain", "conventional", "gitmoji"] | None = None
    generate: int = 1
    from_stash: str | None = None
    from_ref: str | None = None
    exclude: list[str] = []
    max_diff_size: int = 200_000
    yes: bool = False
    dry_run: bool = False
    json: bool = False
    output: str | None = None
    clipboard: bool = False
    no_verify: bool = False
    all: bool = False


class ConfigArgs(BaseArgs):
    delete: bool = False
    yes: bool = False


class PromptArgs(BaseArgs):
    name: str | None = None
    set_text: str | None = None
    file: str | None = None
    language: Literal["ko", "en"] | None = None
    show: bool = False
    list: bool = False
    sync: bool = False


class DoctorArgs(BaseArgs):
    provider: str | None = None
    model: str | None = None
    profile: str | None = None
    timeout: float | None = None


@dataclass(frozen=True, slots=True)
class ParserHandlers:
    handle_config: CommandHandler
    handle_prompt: CommandHandler
    handle_doctor: CommandHandler
    handle_generate: CommandHandler


def build_parser(handlers: ParserHandlers) -> argparse.ArgumentParser:
    cli_version = _resolve_cli_version()
    parser = argparse.ArgumentParser(
        prog="acw",
        description="Generate commit messages from git changes with AI.",
    )
    _ = parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {cli_version}",
    )
    subparsers = parser.add_subparsers(dest="command")

    config_parser = subparsers.add_parser("config", help="Manage ACW configuration.")
    config_parser.set_defaults(handler=handlers.handle_config)
    _ = config_parser.add_argument(
        "--delete",
        action="store_true",
        help="Delete all ACW config files and exit.",
    )
    _ = config_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompts.",
    )

    prompt_parser = subparsers.add_parser(
        "prompt",
        help="Manage prompt templates under ~/.config/acw/prompts.",
    )
    prompt_parser.set_defaults(handler=handlers.handle_prompt)
    _ = prompt_parser.add_argument(
        "-n",
        "--name",
        help="Prompt name to save/show. (without extension)",
    )
    _ = prompt_parser.add_argument(
        "--set",
        dest="set_text",
        help="Prompt body text to save.",
    )
    _ = prompt_parser.add_argument(
        "--file",
        help="Read prompt body text from a file path.",
    )
    _ = prompt_parser.add_argument(
        "-l",
        "--language",
        choices=["ko", "en"],
        help="Prompt language variant.",
    )
    _ = prompt_parser.add_argument(
        "--show",
        action="store_true",
        help="Show prompt content by name.",
    )
    _ = prompt_parser.add_argument(
        "--list",
        action="store_true",
        help="List saved prompt names.",
    )
    _ = prompt_parser.add_argument(
        "--sync",
        action="store_true",
        help="Overwrite builtin prompt templates with latest defaults.",
    )

    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Check local LLM server connectivity and model availability.",
    )
    doctor_parser.set_defaults(handler=handlers.handle_doctor)
    _ = doctor_parser.add_argument(
        "-p",
        "--provider",
        help="Provider to diagnose (recommended: ollama or lmstudio).",
    )
    _ = doctor_parser.add_argument("-m", "--model", help="Model name override.")
    _ = doctor_parser.add_argument("-P", "--profile", help="Saved profile name.")
    _ = doctor_parser.add_argument(
        "--timeout",
        type=float,
        default=None,
        help=(
            "HTTP timeout seconds for local server checks. "
            "If omitted, uses provider_timeout from config.toml."
        ),
    )

    generate_parser = subparsers.add_parser(
        "generate",
        help="Generate commit messages from git changes.",
    )
    generate_parser.set_defaults(handler=handlers.handle_generate)

    _ = generate_parser.add_argument(
        "-p",
        "--provider",
        help=("LLM provider name (예: openai, anthropic, google, ollama, lmstudio)."),
    )
    _ = generate_parser.add_argument("-m", "--model", help="Model name.")
    _ = generate_parser.add_argument("-P", "--profile", help="Saved profile name.")
    _ = generate_parser.add_argument("-t", "--prompt", help="Prompt preset name.")
    _ = generate_parser.add_argument("-F", "--prompt-file", help="Path to prompt file.")
    _ = generate_parser.add_argument(
        "--print-prompt",
        action="store_true",
        help="Print final prompt before generation.",
    )
    _ = generate_parser.add_argument(
        "-l",
        "--language",
        choices=["ko", "en"],
        help="Output language.",
    )
    _ = generate_parser.add_argument(
        "-f",
        "--format",
        choices=["plain", "conventional", "gitmoji"],
        help="Commit message format.",
    )
    _ = generate_parser.add_argument(
        "-g",
        "--generate",
        type=int,
        default=1,
        help="Number of candidates to generate.",
    )
    _ = generate_parser.add_argument(
        "--from-stash",
        help="Collect diff from a stash reference.",
    )
    _ = generate_parser.add_argument(
        "--from-ref",
        help="Collect diff from a git reference.",
    )
    _ = generate_parser.add_argument(
        "-x",
        "--exclude",
        action="append",
        default=[],
        help="Exclude glob pattern (can be repeated).",
    )
    _ = generate_parser.add_argument(
        "-s",
        "--max-diff-size",
        type=int,
        default=200_000,
        help="Maximum collected diff size in bytes.",
    )
    _ = generate_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompts.",
    )
    _ = generate_parser.add_argument(
        "-d",
        "--dry-run",
        action="store_true",
        help="Print result without committing.",
    )
    _ = generate_parser.add_argument(
        "-j",
        "--json",
        action="store_true",
        help="Emit output as JSON.",
    )
    _ = generate_parser.add_argument(
        "-o", "--output", help="Write message to file path."
    )
    _ = generate_parser.add_argument(
        "-c",
        "--clipboard",
        action="store_true",
        help="Copy selected message to clipboard.",
    )
    _ = generate_parser.add_argument(
        "-n",
        "--no-verify",
        action="store_true",
        help="Pass --no-verify when creating commit.",
    )
    _ = generate_parser.add_argument(
        "-a",
        "--all",
        action="store_true",
        help="Stage all tracked changes before commit.",
    )

    return parser


def _resolve_cli_version() -> str:
    try:
        return package_version("acw")
    except PackageNotFoundError:
        return "0.0.0-dev"
