from __future__ import annotations

import os
import sys
from collections.abc import Callable
from typing import TypeVar, cast

import questionary
from rich.console import Console

from acw.cli.commands import (
    ConfigCommandDeps,
    DoctorCommandDeps,
    PromptCommandDeps,
)
from acw.cli.commands import (
    delete_config as _delete_config_impl,
)
from acw.cli.commands import (
    handle_config_command as _handle_config_command_impl,
)
from acw.cli.commands import (
    handle_doctor_command as _handle_doctor_command_impl,
)
from acw.cli.commands import (
    handle_prompt_command as _handle_prompt_command_impl,
)
from acw.cli.commands import (
    has_existing_user_config as _has_existing_user_config_impl,
)
from acw.cli.dispatch import (
    MainDispatchDeps,
    MainDispatchHandlers,
)
from acw.cli.dispatch import (
    run_main as _run_main_impl,
)
from acw.cli.generate import (
    GenerateCommandDeps,
    RunGenerationLoopDeps,
)
from acw.cli.generate import (
    handle_generate_command as _handle_generate_command_impl,
)
from acw.cli.generate import (
    resolve_generate_settings_for_generate as _resolve_generate_settings_impl,
)
from acw.cli.generate import (
    resolve_prompt_selection as _resolve_prompt_selection_impl,
)
from acw.cli.generate import (
    resolve_prompt_text as _resolve_prompt_text_impl,
)
from acw.cli.generate import (
    run_generation_loop as _run_generation_loop_impl,
)
from acw.cli.helpers import (
    ConsoleConfirmDeps,
    GenerationProgressDeps,
    SelectionDeps,
)
from acw.cli.helpers import (
    collect_staged_files as _collect_staged_files_impl,
)
from acw.cli.helpers import (
    confirm_generation_for_staged_files as _confirm_generation_for_staged_files_impl,
)
from acw.cli.helpers import (
    copy_to_clipboard as _copy_to_clipboard_impl,
)
from acw.cli.helpers import (
    create_git_commit as _create_git_commit_impl,
)
from acw.cli.helpers import (
    normalize_optional_str as _normalize_optional_str_impl,
)
from acw.cli.helpers import (
    render_generated_messages as _render_generated_messages_impl,
)
from acw.cli.helpers import (
    run_with_generation_progress as _run_with_generation_progress_impl,
)
from acw.cli.helpers import (
    select_commit_message_interactive as _select_commit_message_interactive_impl,
)
from acw.cli.helpers import (
    truncate_diff_with_confirmation as _truncate_diff_with_confirmation_impl,
)
from acw.cli.parser import (
    BaseArgs,
    ConfigArgs,
    DoctorArgs,
    GenerateArgs,
    ParserHandlers,
    PromptArgs,
)
from acw.cli.parser import (
    build_parser as _build_parser,
)
from acw.config import (
    DEFAULT_FORMAT,
    DEFAULT_LANGUAGE,
    DEFAULT_MODEL,
    DEFAULT_PROMPT,
    DEFAULT_PROVIDER,
    DEFAULT_PROVIDER_ENV,
    ConfigLayout,
    ResolvedGenerateSettings,
    ensure_config_layout,
    get_config_layout,
    list_prompt_names,
    load_config_settings,
    load_prompt,
    load_provider_env_map,
    resolve_effective_prompt,
    resolve_generate_settings,
    resolve_prompt_path,
    resolve_provider_timeout,
    save_prompt,
    sync_builtin_prompt_templates,
)
from acw.diff_collector import CollectedDiff, collect_diff
from acw.doctor import LOCAL_PROVIDERS, diagnose_local_provider
from acw.generate_input import GenerateInput, build_generate_input
from acw.generator import generate_commit_message, generate_commit_messages
from acw.onboarding import run_onboarding_wizard
from acw.prompt_catalog import is_builtin_prompt_stem

ProgressResultT = TypeVar("ProgressResultT")
GENERATION_PROGRESS_REFRESH_SEC = 0.1
_CONSOLE = Console(highlight=False, soft_wrap=True)


def _ask_confirm(
    message: str, default: bool | str, choices: list[str] | None = None
) -> str | bool | None:
    if choices:
        return cast(
            str | None,
            questionary.select(
                message,
                choices=choices,
                default=default if isinstance(default, str) else choices[0],
            ).ask(),
        )
    return cast(
        bool | None,
        questionary.confirm(
            message,
            default=cast(bool, default),
            auto_enter=False,
        ).ask(),
    )


def _ask_select_from_history(history: list[list[str]]) -> list[str] | None:
    if not history:
        return None

    # Format choices for history selection
    choices: list[questionary.Choice] = []
    for i, msgs in enumerate(reversed(history)):
        # Calculate real index in original history
        original_idx = len(history) - 1 - i
        label = f"[{original_idx + 1}] {msgs[0]}"
        if len(label) > 60:
            label = label[:57] + "..."
        if len(msgs) > 1:
            label += f" (+{len(msgs) - 1} more)"
        choices.append(questionary.Choice(title=label, value=msgs))

    result = cast(
        list[str] | None,
        questionary.select(
            "이전 생성 기록에서 선택하세요:",
            choices=choices,
        ).ask(),
    )

    return result


def _ask_select_commit_message(choices: list[str]) -> str | None:
    return cast(
        str | None,
        questionary.select(
            "사용할 커밋 메시지를 선택하세요.",
            choices=choices,
        ).ask(),
    )


def _build_config_command_deps() -> ConfigCommandDeps:
    return ConfigCommandDeps(
        get_config_layout=get_config_layout,
        ensure_config_layout=ensure_config_layout,
        is_interactive_terminal=_is_interactive_terminal,
        has_existing_user_config_fn=_has_existing_user_config,
        confirm=_ask_confirm,
        run_onboarding_wizard=run_onboarding_wizard,
        sync_builtin_prompt_templates=lambda config_layout: (
            sync_builtin_prompt_templates(config_layout, overwrite=True)
        ),
        delete_config_fn=lambda config_layout, assume_yes: _delete_config(
            config_layout, assume_yes=assume_yes
        ),
    )


def _build_generate_command_deps() -> GenerateCommandDeps:
    return GenerateCommandDeps(
        ensure_config_layout=ensure_config_layout,
        is_interactive_terminal=_is_interactive_terminal,
        collect_staged_files=_collect_staged_files,
        confirm_generation_for_staged_files=lambda staged_files, assume_yes, emit_output, prompt_enabled: (
            _confirm_generation_for_staged_files(
                staged_files=staged_files,
                assume_yes=assume_yes,
                emit_output=emit_output,
                prompt_enabled=prompt_enabled,
            )
        ),
        resolve_generate_settings_fn=_resolve_generate_settings,
        collect_diff_fn=collect_diff,
        truncate_diff_with_confirmation_fn=lambda collected, max_diff_size, assume_yes: (
            _truncate_diff_with_confirmation(
                collected=collected,
                max_diff_size=max_diff_size,
                assume_yes=assume_yes,
            )
        ),
        resolve_prompt_selection_fn=lambda config_layout, gen_args, prompt_language, format_name: (
            _resolve_prompt_selection(
                config_layout,
                gen_args,
                language=prompt_language,
                format_name=format_name,
            )
        ),
        resolve_prompt_text_fn=lambda config_layout, prompt_name, prompt_file, prompt_language, format_name: (
            _resolve_prompt_text(
                config_layout,
                prompt_name=prompt_name,
                prompt_file=prompt_file,
                language=prompt_language,
                format_name=format_name,
            )
        ),
        build_generate_input_fn=build_generate_input,
        run_generation_loop_fn=lambda input_data, emit_output, prompt_retry: (
            _run_generation_loop(
                input_data,
                emit_output=emit_output,
                prompt_retry=prompt_retry,
            )
        ),
        select_commit_message_interactive_fn=lambda commit_messages, assume_yes: (
            _select_commit_message_interactive(
                commit_messages,
                assume_yes=assume_yes,
            )
        ),
        confirm_fn=_ask_confirm,
        create_git_commit_fn=lambda message, stage_all, no_verify: _create_git_commit(
            message=message,
            stage_all=stage_all,
            no_verify=no_verify,
        ),
        copy_to_clipboard_fn=_copy_to_clipboard,
        console=_CONSOLE,
    )


def _build_doctor_command_deps() -> DoctorCommandDeps:
    return DoctorCommandDeps(
        ensure_config_layout=ensure_config_layout,
        resolve_generate_settings=resolve_generate_settings,
        resolve_provider_timeout=resolve_provider_timeout,
        diagnose_local_provider=diagnose_local_provider,
        local_providers=LOCAL_PROVIDERS,
    )


def _build_prompt_command_deps() -> PromptCommandDeps:
    return PromptCommandDeps(
        ensure_config_layout=ensure_config_layout,
        load_config_settings=load_config_settings,
        default_language=DEFAULT_LANGUAGE,
        sync_builtin_prompt_templates=lambda config_layout: (
            sync_builtin_prompt_templates(config_layout, overwrite=True)
        ),
        list_prompt_names=lambda config_layout, prompt_language: list_prompt_names(
            config_layout, language=prompt_language
        ),
        load_prompt=lambda config_layout, prompt_name, prompt_language: load_prompt(
            config_layout,
            prompt_name=prompt_name,
            language=prompt_language,
        ),
        save_prompt=lambda config_layout, prompt_name, content, prompt_language: (
            save_prompt(
                config_layout,
                prompt_name=prompt_name,
                content=content,
                language=prompt_language,
            )
        ),
    )


def _build_run_generation_loop_deps() -> RunGenerationLoopDeps:
    return RunGenerationLoopDeps(
        run_with_generation_progress=lambda label, fn, timeout_seconds, enabled: (
            _run_with_generation_progress(
                label,
                fn,
                timeout_seconds=timeout_seconds,
                enabled=enabled,
            )
        ),
        generate_commit_message=generate_commit_message,
        generate_commit_messages=generate_commit_messages,
        render_generated_messages=render_generated_messages,
        is_interactive_terminal=_is_interactive_terminal,
        confirm_fn=_ask_confirm,
        select_from_history_fn=_ask_select_from_history,
    )


def handle_config(args: BaseArgs) -> int:
    config_args = ConfigArgs()
    config_args.__dict__.update(args.__dict__)
    deps = _build_config_command_deps()
    return _handle_config_command_impl(config_args, deps)


def handle_generate(args: BaseArgs) -> int:
    if args.command != "generate":
        return 2
    generate_args = GenerateArgs()
    generate_args.__dict__.update(args.__dict__)
    deps = _build_generate_command_deps()
    return _handle_generate_command_impl(generate_args, deps)


def handle_doctor(args: BaseArgs) -> int:
    if args.command != "doctor":
        return 2
    doctor_args = DoctorArgs()
    doctor_args.__dict__.update(args.__dict__)
    deps = _build_doctor_command_deps()
    return _handle_doctor_command_impl(doctor_args, deps)


def _run_generation_loop(
    input_data: GenerateInput,
    *,
    emit_output: bool = True,
    prompt_retry: bool = False,
) -> list[str]:
    deps = _build_run_generation_loop_deps()
    return _run_generation_loop_impl(
        input_data,
        emit_output=emit_output,
        prompt_retry=prompt_retry,
        deps=deps,
    )


def _select_commit_message_interactive(
    commit_messages: list[str], *, assume_yes: bool
) -> str | None:
    return _select_commit_message_interactive_impl(
        commit_messages,
        assume_yes=assume_yes,
        deps=SelectionDeps(
            ask_select=_ask_select_commit_message,
            ask_confirm=_ask_confirm,
        ),
    )


def handle_prompt(args: BaseArgs) -> int:
    if args.command != "prompt":
        return 2
    prompt_args = PromptArgs()
    prompt_args.__dict__.update(args.__dict__)
    deps = _build_prompt_command_deps()
    return _handle_prompt_command_impl(prompt_args, deps)


def _truncate_diff_with_confirmation(
    *,
    collected: CollectedDiff,
    max_diff_size: int,
    assume_yes: bool,
) -> CollectedDiff | None:
    return _truncate_diff_with_confirmation_impl(
        collected=collected,
        max_diff_size=max_diff_size,
        assume_yes=assume_yes,
        deps=ConsoleConfirmDeps(
            console=_CONSOLE,
            is_interactive_terminal=_is_interactive_terminal(),
            ask_confirm=_ask_confirm,
        ),
    )


def _resolve_generate_settings(
    layout: ConfigLayout, args: GenerateArgs
) -> ResolvedGenerateSettings:
    return _resolve_generate_settings_impl(
        layout,
        args,
        resolve_generate_settings=resolve_generate_settings,
        is_interactive_terminal=_is_interactive_terminal,
        run_onboarding_wizard=run_onboarding_wizard,
    )


def _resolve_prompt_selection(
    layout: ConfigLayout,
    args: GenerateArgs,
    *,
    language: str,
    format_name: str,
) -> tuple[str | None, str | None]:
    return _resolve_prompt_selection_impl(
        layout,
        args,
        language=language,
        format_name=format_name,
        normalize_optional_str=_normalize_optional_str,
        load_config_settings=load_config_settings,
        resolve_prompt_path=lambda config_layout, prompt_name, prompt_language: (
            resolve_prompt_path(config_layout, prompt_name, language=prompt_language)
        ),
        default_prompt=DEFAULT_PROMPT,
    )


def _resolve_prompt_text(
    layout: ConfigLayout,
    *,
    prompt_name: str | None,
    prompt_file: str | None,
    language: str,
    format_name: str,
) -> str:
    return _resolve_prompt_text_impl(
        layout,
        prompt_name=prompt_name,
        prompt_file=prompt_file,
        language=language,
        format_name=format_name,
        resolve_effective_prompt=resolve_effective_prompt,
    )


def _normalize_optional_str(value: str | None) -> str | None:
    return _normalize_optional_str_impl(value)


def _run_with_generation_progress(
    label: str,
    fn: Callable[[], ProgressResultT],
    *,
    timeout_seconds: float,
    enabled: bool,
) -> ProgressResultT:
    return _run_with_generation_progress_impl(
        label,
        fn,
        timeout_seconds=timeout_seconds,
        enabled=enabled,
        deps=GenerationProgressDeps(
            console=_CONSOLE,
            is_interactive_terminal=_is_interactive_terminal(),
            refresh_sec=GENERATION_PROGRESS_REFRESH_SEC,
            is_pytest="PYTEST_CURRENT_TEST" in os.environ,
        ),
    )


def render_generated_messages(messages: list[str]) -> None:
    _render_generated_messages_impl(messages, console=_CONSOLE)


def _create_git_commit(*, message: str, stage_all: bool, no_verify: bool) -> str | None:
    return _create_git_commit_impl(
        message=message,
        stage_all=stage_all,
        no_verify=no_verify,
    )


def _collect_staged_files() -> tuple[list[str], str | None]:
    return _collect_staged_files_impl()


def _confirm_generation_for_staged_files(
    *,
    staged_files: list[str],
    assume_yes: bool,
    emit_output: bool,
    prompt_enabled: bool,
) -> bool:
    return _confirm_generation_for_staged_files_impl(
        staged_files=staged_files,
        assume_yes=assume_yes,
        emit_output=emit_output,
        prompt_enabled=prompt_enabled,
        deps=ConsoleConfirmDeps(
            console=_CONSOLE,
            ask_confirm=_ask_confirm,
        ),
    )


def _copy_to_clipboard(message: str) -> str | None:
    return _copy_to_clipboard_impl(message)


def _delete_config(layout: ConfigLayout, *, assume_yes: bool) -> bool:
    return _delete_config_impl(
        layout,
        assume_yes=assume_yes,
        confirm=_ask_confirm,
    )


def _has_existing_user_config(layout: ConfigLayout) -> bool:
    return _has_existing_user_config_impl(
        layout,
        load_config_settings=load_config_settings,
        load_provider_env_map=load_provider_env_map,
        default_provider=DEFAULT_PROVIDER,
        default_model=DEFAULT_MODEL,
        default_language=DEFAULT_LANGUAGE,
        default_format=DEFAULT_FORMAT,
        default_prompt=DEFAULT_PROMPT,
        default_provider_env=DEFAULT_PROVIDER_ENV,
        is_builtin_prompt_file=_is_builtin_prompt_file,
    )


def _is_builtin_prompt_file(stem: str) -> bool:
    return is_builtin_prompt_stem(stem)


def _is_interactive_terminal() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _build_parser_handlers() -> ParserHandlers:
    return ParserHandlers(
        handle_config=handle_config,
        handle_prompt=handle_prompt,
        handle_doctor=handle_doctor,
        handle_generate=handle_generate,
    )


def _build_main_dispatch_handlers() -> MainDispatchHandlers:
    return MainDispatchHandlers(
        handle_generate=handle_generate,
        handle_config=handle_config,
        handle_prompt=handle_prompt,
        handle_doctor=handle_doctor,
    )


def build_parser():
    handlers = _build_parser_handlers()
    return _build_parser(handlers)


def main() -> int:
    deps = MainDispatchDeps(
        build_parser=build_parser,
        argv=sys.argv[1:],
        base_args_factory=BaseArgs,
        generate_args_factory=GenerateArgs,
        handlers=_build_main_dispatch_handlers(),
    )
    return _run_main_impl(deps)
