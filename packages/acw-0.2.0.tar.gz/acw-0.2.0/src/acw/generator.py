from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any, Protocol

from acw.generate_input import GenerateInput

PROVIDER_MODEL_PREFIX: dict[str, str] = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google": "gemini",
    "openrouter": "openrouter",
    "xai": "xai",
    "groq": "groq",
    "deepseek": "deepseek",
    "cohere": "cohere",
}


class GenerationError(RuntimeError):
    pass


class CandidateGenerator(Protocol):
    def generate(self, input_data: GenerateInput) -> Sequence[str]: ...


class LiteLLMCandidateGenerator:
    def generate(self, input_data: GenerateInput) -> Sequence[str]:
        model = resolve_litellm_model(
            provider=input_data.provider, model=input_data.model
        )
        messages = self._build_messages(input_data)
        try:
            if input_data.api_key and input_data.base_url:
                response: object = _litellm_completion(
                    model=model,
                    n=input_data.candidate_count,
                    timeout=input_data.timeout_seconds,
                    messages=messages,
                    api_base=input_data.base_url,
                    api_key=input_data.api_key,
                )
            elif input_data.api_key:
                response: object = _litellm_completion(
                    model=model,
                    n=input_data.candidate_count,
                    timeout=input_data.timeout_seconds,
                    messages=messages,
                    api_key=input_data.api_key,
                )
            elif input_data.base_url:
                response: object = _litellm_completion(
                    model=model,
                    n=input_data.candidate_count,
                    timeout=input_data.timeout_seconds,
                    messages=messages,
                    api_base=input_data.base_url,
                )
            else:
                response: object = _litellm_completion(
                    model=model,
                    n=input_data.candidate_count,
                    timeout=input_data.timeout_seconds,
                    messages=messages,
                )
        except Exception as error:
            detail = _format_generation_error(input_data=input_data, error=error)
            raise GenerationError(detail) from error

        choices = getattr(response, "choices", None)
        if not isinstance(choices, list) or not choices:
            raise GenerationError("모델 응답에 생성 결과가 없습니다.")

        outputs: list[str] = []
        for choice in choices:
            content = _extract_choice_content(choice)
            normalized = _normalize_content(content)
            if normalized:
                outputs.append(normalized)
        return outputs

    @staticmethod
    def _build_messages(input_data: GenerateInput) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": input_data.prompt_text},
            {
                "role": "user",
                "content": (
                    "Generate commit message candidates from the following git diff.\n"
                    f"Return up to {input_data.candidate_count} candidates.\n"
                    "Only return the commit message text.\n\n"
                    f"```diff\n{input_data.diff_text}\n```"
                ),
            },
        ]


class CallableCandidateGenerator:
    """`instructor` 같은 외부 생성기를 연결하기 위한 어댑터."""

    def __init__(self, generator: Callable[[GenerateInput], Sequence[str]]) -> None:
        self._generator: Callable[[GenerateInput], Sequence[str]]
        self._generator = generator

    def generate(self, input_data: GenerateInput) -> Sequence[str]:
        return self._generator(input_data)


def generate_commit_message(
    input_data: GenerateInput,
    *,
    generator: CandidateGenerator | None = None,
) -> str:
    messages = generate_commit_messages(input_data, generator=generator)
    return messages[0]


def generate_commit_messages(
    input_data: GenerateInput,
    *,
    generator: CandidateGenerator | None = None,
) -> list[str]:
    selected_generator = generator or LiteLLMCandidateGenerator()
    raw_outputs = selected_generator.generate(input_data)

    outputs: list[str] = []
    for output in raw_outputs:
        normalized = output.strip()
        if normalized:
            outputs.append(normalized)
    if not outputs:
        raise GenerationError("모델 응답 메시지가 비어 있습니다.")
    return outputs


def resolve_litellm_model(*, provider: str, model: str) -> str:
    normalized_model = model.strip()
    if "/" in normalized_model:
        return normalized_model
    normalized_provider = provider.strip().lower()
    provider_prefix = PROVIDER_MODEL_PREFIX.get(
        normalized_provider, normalized_provider
    )
    return f"{provider_prefix}/{normalized_model}"


def _normalize_content(content: object) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        text_parts: list[str] = []
        for item in content:
            text = _extract_text(item)
            if text:
                text_parts.append(text)
        return "\n".join(text_parts).strip()
    return ""


def _extract_text(item: object) -> str:
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, dict):
        text = item.get("text")
        if isinstance(text, str):
            return text.strip()
    return ""


def _extract_choice_content(choice: object) -> object:
    if isinstance(choice, dict):
        message = choice.get("message")
        if isinstance(message, dict):
            return message.get("content")
        return None
    message = getattr(choice, "message", None)
    return getattr(message, "content", None)


def _format_generation_error(*, input_data: GenerateInput, error: Exception) -> str:
    base = f"모델 호출에 실패했습니다: {error}"
    if input_data.provider not in {"ollama", "lmstudio"}:
        return base

    message = str(error).lower()
    error_type_name = type(error).__name__.lower()

    if "timeout" in message or "timeout" in error_type_name:
        return (
            f"{base}\n"
            "가이드: 로컬 서버 응답 시간이 길어 타임아웃이 발생했습니다. "
            "모델 로딩이 끝났는지 확인하고 다시 시도하세요."
        )
    if any(token in message for token in ["connection refused", "connecterror"]):
        return (
            f"{base}\n"
            "가이드: 로컬 서버가 실행 중인지 확인하세요. "
            "서버 미실행 또는 포트 충돌 가능성이 있습니다."
        )
    if any(
        token in message for token in ["404", "model", "not found", "no such model"]
    ):
        return (
            f"{base}\n"
            "가이드: 요청한 모델이 서버에 없습니다. "
            "모델 이름을 확인하거나 먼저 모델을 pull/load 하세요."
        )
    return (
        f"{base}\n"
        "가이드: provider_base_url 설정(host/port)과 로컬 서버 상태를 점검하세요."
    )


def _litellm_completion(**kwargs: Any) -> object:
    # litellm import 비용이 크므로 실제 생성 호출 시점에만 로드한다.
    import litellm

    return litellm.completion(**kwargs)
