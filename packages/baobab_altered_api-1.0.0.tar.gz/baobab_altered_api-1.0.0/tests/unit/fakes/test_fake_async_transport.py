"""Tests de ``FakeAsyncTransport`` (tests/fakes)."""

# pylint: disable=duplicate-code
# Exemples volontairement proches de ``test_fake_sync_transport`` (BL-003-005).

from __future__ import annotations

import pytest
from baobab_api_call import ApiRequest, ApiResponse

from tests.fakes.fake_async_transport import FakeAsyncTransport


class TestFakeAsyncTransport:
    """Routage async, historique et exceptions."""

    async def test_register_returns_configured_response(self) -> None:
        """La réponse enregistrée est renvoyée pour la même clé."""
        fake = FakeAsyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/cards",
            ApiResponse(200, b'{"items":[]}'),
        )
        req = ApiRequest(method="GET", path="https://api.test.example/v1/cards")
        resp = await fake.send(req)
        assert resp.status_code == 200
        assert resp.json() == {"items": []}
        assert fake.requests == [req]

    async def test_configured_exception_propagates(self) -> None:
        """Une exception enregistrée est propagée telle quelle."""
        fake = FakeAsyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/x",
            ValueError("async boom"),
        )
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        with pytest.raises(ValueError, match="async boom"):
            await fake.send(req)

    async def test_aclose_blocks_send(self) -> None:
        """Après ``aclose``, ``send`` est interdit."""
        fake = FakeAsyncTransport()
        fake.register("GET", "https://x.test/a", ApiResponse(204, b""))
        await fake.aclose()
        with pytest.raises(RuntimeError, match="after aclose"):
            await fake.send(ApiRequest(method="GET", path="https://x.test/a"))
