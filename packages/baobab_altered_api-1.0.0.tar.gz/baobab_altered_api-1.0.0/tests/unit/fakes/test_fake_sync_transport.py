"""Tests de ``FakeSyncTransport`` (tests/fakes)."""

from __future__ import annotations

import pytest
from baobab_api_call import ApiRequest, ApiResponse

from tests.fakes.fake_sync_transport import FakeSyncTransport


class TestFakeSyncTransport:
    """Routage sync, historique et exceptions."""

    def test_register_returns_configured_response(self) -> None:
        """La réponse enregistrée est renvoyée pour la même clé."""
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/cards",
            ApiResponse(200, b'{"items":[]}'),
        )
        req = ApiRequest(method="GET", path="https://api.test.example/v1/cards")
        resp = fake.send(req)
        assert resp.status_code == 200
        assert resp.json() == {"items": []}
        assert fake.requests == [req]

    def test_params_distinct_registrations(self) -> None:
        """Les paramètres de requête font partie de la clé de routage."""
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/cards",
            ApiResponse(200, b'{"page":"1"}'),
            params={"page": "1"},
        )
        fake.register(
            "GET",
            "https://api.test.example/v1/cards",
            ApiResponse(200, b'{"page":"2"}'),
            params={"page": "2"},
        )
        r1 = fake.send(
            ApiRequest(
                method="GET",
                path="https://api.test.example/v1/cards",
                params={"page": "1"},
            ),
        )
        r2 = fake.send(
            ApiRequest(
                method="GET",
                path="https://api.test.example/v1/cards",
                params={"page": "2"},
            ),
        )
        assert r1.json() == {"page": "1"}
        assert r2.json() == {"page": "2"}

    def test_configured_exception_propagates(self) -> None:
        """Une exception enregistrée est propagée telle quelle."""
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/x",
            RuntimeError("transport boom"),
        )
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        with pytest.raises(RuntimeError, match="transport boom"):
            fake.send(req)
        assert len(fake.requests) == 1

    def test_http_error_response_returned(self) -> None:
        """Une réponse 502 factice est renvoyée sans exception."""
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/x",
            ApiResponse(502, b"bad gateway"),
        )
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = fake.send(req)
        assert resp.is_error
        assert resp.status_code == 502

    def test_default_used_when_no_exact_match(self) -> None:
        """Le défaut s'applique si la clé exacte est absente."""
        fake = FakeSyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        req = ApiRequest(method="GET", path="https://api.test.example/v1/other")
        resp = fake.send(req)
        assert resp.status_code == 200

    def test_lookup_error_lists_param_keys_only(self) -> None:
        """Sans enregistrement ni défaut : LookupError avec clés de paramètres."""
        fake = FakeSyncTransport()
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/missing",
            params={"page": "1", "token": "baobab-api-token"},
        )
        with pytest.raises(LookupError) as ctx:
            fake.send(req)
        assert "page" in str(ctx.value)
        assert "token" in str(ctx.value)
        assert "baobab-api-token" not in str(ctx.value)

    def test_close_blocks_send(self) -> None:
        """Après ``close``, ``send`` est interdit."""
        fake = FakeSyncTransport()
        fake.register("GET", "https://x.test/a", ApiResponse(204, b""))
        fake.close()
        with pytest.raises(RuntimeError, match="after close"):
            fake.send(ApiRequest(method="GET", path="https://x.test/a"))

    def test_response_gets_request_attached(self) -> None:
        """Si la réponse n'a pas de requête, celle du ``send`` est fusionnée."""
        fake = FakeSyncTransport()
        fake.register("GET", "https://x.test/r", ApiResponse(200, b"{}"))
        req = ApiRequest(method="GET", path="https://x.test/r")
        resp = fake.send(req)
        assert resp.request is req
