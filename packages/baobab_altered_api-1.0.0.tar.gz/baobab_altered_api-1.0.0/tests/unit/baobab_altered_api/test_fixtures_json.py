"""Validation du corpus de fixtures JSON (BL-005-005)."""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.fixtures.json_loader import load_json_fixture

_SENTINEL_SECRET = "phf_fixture_must_not_contain_this_secret"


class TestFixturesJson:
    """Parseabilité et absence de secrets évidents."""

    @pytest.mark.parametrize(
        "name",
        [
            "card_minimal.json",
            "card_summary_minimal.json",
            "card_summary_full.json",
            "card_summary_shorthand.json",
            "page_cards.json",
            "deck_minimal.json",
            "market_offer_minimal.json",
            "error_404.json",
        ],
    )
    def test_json_fixture_loads(self, name: str) -> None:
        """Chaque fixture JSON listée est lisible."""
        data = load_json_fixture(name)
        assert data is not None

    def test_open_data_fixture_loads(self) -> None:
        """Fixture Open Data hiérarchique."""
        data = load_json_fixture("open_data_minimal.json", subdir="open_data")
        assert isinstance(data, dict)
        assert "cards" in data

    def test_fixtures_tree_has_no_sentinel_secret(self) -> None:
        """Scan simple : aucune fixture ne contient la chaîne sentinelle."""
        root = Path(__file__).resolve().parents[2] / "fixtures"
        for path in root.rglob("*.json"):
            text = path.read_text(encoding="utf-8")
            assert _SENTINEL_SECRET not in text
