"""Tests de la garde anti-réseau pour les tests unitaires."""

from __future__ import annotations

import socket

import pytest


class TestNetworkGuard:
    """Vérifie que les sockets réels sont refusés par défaut."""

    def test_socket_connect_is_blocked(self) -> None:
        """Toute création de socket doit être bloquée par la fixture autouse."""
        with pytest.raises(RuntimeError, match="Connexion réseau interdite"):
            socket.socket()
