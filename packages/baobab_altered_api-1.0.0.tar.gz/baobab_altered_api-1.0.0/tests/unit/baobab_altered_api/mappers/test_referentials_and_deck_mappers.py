"""Tests mappers référentiels, deck, marketplace, open data."""

from __future__ import annotations

import pytest

from baobab_altered_api.exceptions import AlteredMappingError
from baobab_altered_api.mappers.altered_deck_json_mapper import AlteredDeckJsonMapper
from baobab_altered_api.mappers.altered_marketplace_offer_json_mapper import (
    AlteredMarketplaceOfferJsonMapper,
)
from baobab_altered_api.mappers.altered_open_data_json_mapper import AlteredOpenDataJsonMapper
from baobab_altered_api.mappers.altered_referentials_json_mapper import (
    AlteredReferentialsJsonMapper,
)
from tests.fixtures.json_loader import load_json_fixture


class TestReferentialsAndDeckMappers:
    """Cas limites mappers."""

    def test_deck_from_fixture(self) -> None:
        """Deck minimal."""
        deck = AlteredDeckJsonMapper.deck_from_mapping(
            load_json_fixture("deck_minimal.json")
        )
        assert deck.cards[0].quantity == 2

    def test_marketplace_from_fixture(self) -> None:
        """Offre marketplace."""
        offer = AlteredMarketplaceOfferJsonMapper.offer_from_mapping(
            load_json_fixture("market_offer_minimal.json")
        )
        assert offer.price_currency == "EUR"

    def test_open_data_snapshot(self) -> None:
        """Snapshot Open Data."""
        snap = AlteredOpenDataJsonMapper.snapshot_from_mapping(
            load_json_fixture("open_data_minimal.json", subdir="open_data")
        )
        assert len(snap.cards) == 2

    def test_open_data_hierarchical_snapshot(self) -> None:
        """Arborescence Set → Faction → Carte."""
        snap = AlteredOpenDataJsonMapper.snapshot_from_mapping(
            load_json_fixture("minimal_snapshot.json", subdir="open_data")
        )
        assert len(snap.sets) == 1
        assert len(snap.cards) == 2
        assert snap.sets[0].factions[0].cards[0].number == "001"

    def test_referential_list_missing_items_raises(self) -> None:
        """Liste sans tableau : erreur."""
        with pytest.raises(AlteredMappingError, match="referential list"):
            AlteredReferentialsJsonMapper.list_from_mapping(
                {},
                item_mapper=AlteredReferentialsJsonMapper.set_reference_from_mapping,
            )
