"""Tests de ``AlteredPaginationJsonMapper``."""

from __future__ import annotations

import pytest

from baobab_altered_api.exceptions import AlteredMappingError
from baobab_altered_api.mappers.altered_pagination_json_mapper import (
    AlteredPaginationJsonMapper,
)


class TestAlteredPaginationJsonMapper:
    """Lecture de totaux et curseurs."""

    def test_total_count_aliases(self) -> None:
        """Alias usuels pour le total."""
        assert (
            AlteredPaginationJsonMapper.total_count_from_mapping({"totalCount": 5}) == 5
        )
        assert AlteredPaginationJsonMapper.total_count_from_mapping({"total": 0}) == 0
        assert AlteredPaginationJsonMapper.total_count_from_mapping({}) is None

    def test_cursors_flat(self) -> None:
        """Curseurs à la racine."""
        n, p = AlteredPaginationJsonMapper.cursors_from_mapping(
            {"nextCursor": "n", "previousCursor": "pr"}
        )
        assert n == "n"
        assert p == "pr"

    def test_cursors_nested(self) -> None:
        """Bloc ``pagination`` imbriqué."""
        body = {"pagination": {"next": "aa", "prev": "bb"}}
        n, prev = AlteredPaginationJsonMapper.cursors_from_mapping(body)
        assert n == "aa"
        assert prev == "bb"

    def test_has_next(self) -> None:
        """Indicateur booléen."""
        assert (
            AlteredPaginationJsonMapper.has_next_from_mapping({"hasNext": True}) is True
        )
        assert AlteredPaginationJsonMapper.has_next_from_mapping({}) is None

    def test_cursor_invalid_type_raises(self) -> None:
        """Curseur numérique : erreur de mapping."""
        with pytest.raises(AlteredMappingError, match="pagination field"):
            AlteredPaginationJsonMapper.cursors_from_mapping({"next": 123})
