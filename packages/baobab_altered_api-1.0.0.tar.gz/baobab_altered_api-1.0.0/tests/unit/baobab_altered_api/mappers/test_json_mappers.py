"""Tests des mappers JSON communs (BL-005-002)."""

from __future__ import annotations

import pytest

from baobab_altered_api.exceptions import AlteredMappingError
from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.models.altered_ref import AlteredRef
from tests.fixtures.json_loader import load_json_fixture


class TestAlteredCommonModelsJsonMapper:
    """Succès, tolérance et erreurs typées."""

    def test_ref_from_json_accepts_int(self) -> None:
        """Un identifiant numérique JSON devient une chaîne normalisée."""
        ref = AlteredCommonModelsJsonMapper.ref_from_json(42, field="id")
        assert ref.value == "42"

    def test_ref_from_json_rejects_bool(self) -> None:
        """Les booléens sont refusés (ambiguïté avec entiers)."""
        with pytest.raises(AlteredMappingError, match="boolean"):
            AlteredCommonModelsJsonMapper.ref_from_json(True, field="id")

    def test_card_summary_minimal_fixture(self) -> None:
        """Payload minimal : seule la référence carte est requise."""
        data = load_json_fixture("card_summary_minimal.json")
        summary = AlteredCommonModelsJsonMapper.card_summary_from_mapping(
            data, path="/v1/cards"
        )
        assert summary.ref.value == "fixture-card-minimal-01"
        assert summary.name is None
        assert summary.raw is None

    def test_card_summary_full_fixture(self) -> None:
        """Payload étendu : blocs imbriqués et clés inconnues en ``raw``."""
        data = load_json_fixture("card_summary_full.json")
        summary = AlteredCommonModelsJsonMapper.card_summary_from_mapping(data)
        assert summary.ref.value == "fixture-card-full-01"
        assert summary.name == "Sample Card"
        assert summary.faction is not None
        assert summary.faction.ref is not None
        assert summary.faction.ref.value == "fac-1"
        assert summary.faction.raw is not None
        assert summary.faction.raw.get("color") == "#112233"
        assert summary.expansion is not None
        assert summary.expansion.code == "CORE"
        assert summary.expansion.raw is not None
        assert summary.rarity is not None
        assert summary.rarity.code == "RARE"
        assert summary.image is not None
        assert summary.image.url == "https://cdn.example.test/cards/1.png"
        assert summary.raw is not None
        assert summary.raw.get("metaVersion") == 3
        assert summary.raw.get("unknownTopLevel") is True

    def test_card_summary_shorthand_strings(self) -> None:
        """``set`` et ``rarity`` peuvent être de simples chaînes."""
        data = load_json_fixture("card_summary_shorthand.json")
        summary = AlteredCommonModelsJsonMapper.card_summary_from_mapping(data)
        assert summary.expansion is not None
        assert summary.expansion.code == "EXP-A"
        assert summary.rarity is not None
        assert summary.rarity.code == "COMMON"

    def test_card_summary_missing_identifier_raises(self) -> None:
        """Sans identifiant connu : erreur de mapping sans corps JSON."""
        with pytest.raises(AlteredMappingError) as ctx:
            AlteredCommonModelsJsonMapper.card_summary_from_mapping({"name": "orphan"})
        msg = str(ctx.value)
        assert "card summary requires" in msg.lower()
        assert "orphan" not in msg

    def test_card_summary_non_mapping_raises(self) -> None:
        """La racine doit être un objet JSON."""
        with pytest.raises(AlteredMappingError, match="mapping"):
            AlteredCommonModelsJsonMapper.card_summary_from_mapping([])

    def test_card_summary_keep_unknown_in_raw_false(self) -> None:
        """Désactiver ``raw`` au niveau racine."""
        data = load_json_fixture("card_summary_full.json")
        summary = AlteredCommonModelsJsonMapper.card_summary_from_mapping(
            data, keep_unknown_in_raw=False
        )
        assert summary.raw is None

    def test_localized_label_ok(self) -> None:
        """Libellé avec locales optionnelles."""
        payload = {
            "default": "Hi",
            "locales": {"fr-FR": "Salut"},
        }
        label = AlteredCommonModelsJsonMapper.localized_label_from_mapping(payload)
        assert label.default == "Hi"
        assert label.by_locale is not None
        assert label.by_locale["fr-FR"] == "Salut"

    def test_localized_label_missing_default_raises(self) -> None:
        """Sans texte par défaut : erreur."""
        with pytest.raises(AlteredMappingError, match="default"):
            AlteredCommonModelsJsonMapper.localized_label_from_mapping({"locales": {}})

    def test_image_none(self) -> None:
        """Image absente."""
        assert AlteredCommonModelsJsonMapper.image_from_mapping(None) is None

    def test_faction_none(self) -> None:
        """Faction absente."""
        assert AlteredCommonModelsJsonMapper.faction_from_mapping(None) is None

    def test_optional_ref_empty_string(self) -> None:
        """Chaîne vide → pas de référence."""
        assert AlteredCommonModelsJsonMapper.optional_ref_from_json("  ") is None

    def test_card_summary_roundtrip_ref(self) -> None:
        """Alias ``cardId`` accepté."""
        summary = AlteredCommonModelsJsonMapper.card_summary_from_mapping(
            {"cardId": "x-1"}
        )
        assert summary.ref == AlteredRef("x-1")
