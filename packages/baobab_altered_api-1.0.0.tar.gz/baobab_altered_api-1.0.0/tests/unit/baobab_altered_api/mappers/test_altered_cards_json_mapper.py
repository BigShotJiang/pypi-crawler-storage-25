"""Tests de ``AlteredCardsJsonMapper``."""

from __future__ import annotations

from baobab_altered_api.mappers.altered_cards_json_mapper import AlteredCardsJsonMapper
from tests.fixtures.json_loader import load_json_fixture


class TestAlteredCardsJsonMapper:
    """Page cartes depuis fixture."""

    def test_page_from_fixture(self) -> None:
        """``page_cards.json`` produit deux résumés."""
        data = load_json_fixture("page_cards.json")
        page = AlteredCardsJsonMapper.page_from_mapping(data)
        assert len(page.items) == 2
        assert page.total_count == 42
