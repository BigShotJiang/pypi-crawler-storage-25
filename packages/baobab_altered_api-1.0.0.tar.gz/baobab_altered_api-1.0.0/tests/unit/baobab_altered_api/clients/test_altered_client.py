"""Tests de ``AlteredClient``."""

from __future__ import annotations

from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.transports.altered_sync_transport import AlteredSyncTransport
from tests.fakes.fake_sync_transport import FakeSyncTransport


def _config() -> AlteredApiConfig:
    return AlteredApiConfig(
        base_url="https://api.test.example",
        bearer_token="baobab-api-token",
    )


class TestAlteredClient:
    """Instanciation, transport factice et cycle de vie."""

    def test_instantiation_does_not_send(self) -> None:
        """L'instanciation n'émet aucune requête vers le transport."""
        fake = FakeSyncTransport()
        AlteredClient(_config(), transport=fake)
        assert not fake.requests

    def test_http_get_uses_injected_transport(self) -> None:
        """Un ``GET`` via le socle atteint le transport factice enregistré."""
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/ping",
            ApiResponse(200, b'{"ok": true}'),
        )
        client = AlteredClient(_config(), transport=fake)
        resp = client.http.get("/v1/ping")
        assert resp.json() == {"ok": True}
        assert len(fake.requests) == 1

    def test_with_closes_injected_transport(self) -> None:
        """Le context manager ``with`` ferme le client et le transport factice."""
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/ping",
            ApiResponse(200, b"{}"),
        )
        with AlteredClient(_config(), transport=fake) as client:
            client.http.get("/v1/ping")
        assert fake.closed

    def test_close_idempotent_with_fake(self) -> None:
        """``close`` peut être appelé après ``with`` sans effet de bord fatal."""
        fake = FakeSyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        client = AlteredClient(_config(), transport=fake)
        client.close()
        client.close()
        assert fake.closed

    def test_owned_default_transport_closes(self) -> None:
        """Sans transport injecté, la fermeture ferme le client HTTPX interne."""
        client = AlteredClient(_config())
        transport = client.http.transport
        assert isinstance(transport, AlteredSyncTransport)
        inner = transport._client  # pylint: disable=protected-access
        client.close()
        assert inner.is_closed

    def test_default_transport_inherits_config_timeout(self) -> None:
        """Le transport HTTPX par défaut reçoit le timeout global de la config."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
            timeout_seconds=18.5,
        )
        client = AlteredClient(cfg)
        transport = client.http.transport
        assert isinstance(transport, AlteredSyncTransport)
        assert getattr(transport, "_default_timeout_seconds") == 18.5
        client.close()
