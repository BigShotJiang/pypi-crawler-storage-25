"""Tests de ``AsyncAlteredClient``."""

from __future__ import annotations

from baobab_api_call import ApiResponse

from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.transports.altered_async_transport import AlteredAsyncTransport
from tests.fakes.fake_async_transport import FakeAsyncTransport


def _config() -> AlteredApiConfig:
    return AlteredApiConfig(
        base_url="https://api.test.example",
        bearer_token="baobab-api-token",
    )


class TestAsyncAlteredClient:
    """Instanciation async, transport factice et cycle de vie."""

    async def test_instantiation_does_not_send(self) -> None:
        """L'instanciation n'émet aucune requête vers le transport."""
        fake = FakeAsyncTransport()
        AsyncAlteredClient(_config(), transport=fake)
        assert not fake.requests

    async def test_http_get_uses_injected_transport(self) -> None:
        """Un ``GET`` async atteint le transport factice enregistré."""
        fake = FakeAsyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/ping",
            ApiResponse(200, b'{"ok": true}'),
        )
        client = AsyncAlteredClient(_config(), transport=fake)
        resp = await client.http.get("/v1/ping")
        assert resp.json() == {"ok": True}
        assert len(fake.requests) == 1

    async def test_async_with_closes_injected_transport(self) -> None:
        """``async with`` ferme le client et le transport factice."""
        fake = FakeAsyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/ping",
            ApiResponse(200, b"{}"),
        )
        async with AsyncAlteredClient(_config(), transport=fake) as client:
            await client.http.get("/v1/ping")
        assert fake.closed

    async def test_owned_default_transport_closes(self) -> None:
        """Sans transport injecté, ``aclose`` ferme le client HTTPX interne."""
        client = AsyncAlteredClient(_config())
        transport = client.http.transport
        assert isinstance(transport, AlteredAsyncTransport)
        inner = transport._client  # pylint: disable=protected-access
        await client.aclose()
        assert inner.is_closed

    async def test_default_transport_inherits_config_timeout(self) -> None:
        """Le transport HTTPX par défaut reçoit le timeout global de la config."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
            timeout_seconds=17.0,
        )
        client = AsyncAlteredClient(cfg)
        transport = client.http.transport
        assert isinstance(transport, AlteredAsyncTransport)
        assert getattr(transport, "_default_timeout_seconds") == 17.0
        await client.aclose()
