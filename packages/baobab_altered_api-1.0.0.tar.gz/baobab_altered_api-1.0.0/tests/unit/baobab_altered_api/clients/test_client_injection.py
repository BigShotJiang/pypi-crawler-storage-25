"""Tests d'injection ``api_client_config`` / transport et combinaisons invalides."""

# pylint: disable=duplicate-code
# Arrangements proches de ``test_altered_client`` / ``test_async_altered_client``.

from __future__ import annotations

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient
from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from tests.fakes.fake_async_transport import FakeAsyncTransport
from tests.fakes.fake_sync_transport import FakeSyncTransport


def _altered() -> AlteredApiConfig:
    """Configuration Altered minimale pour les tests d'injection."""
    return AlteredApiConfig(
        base_url="https://api.test.example",
        bearer_token="baobab-api-token",
    )


class TestClientInjection:
    """Injection contrôlée, alignement ``base_url`` et ports transport."""

    def test_sync_uses_injected_api_client_config_headers(self) -> None:
        """Le socle utilise ``api_client_config`` (en-têtes visibles sur la requête)."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        headers = dict(base_api.default_headers or {})
        headers["User-Agent"] = "injected-ua"
        injected = base_api.copy_with(default_headers=headers)
        fake = FakeSyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/ping",
            ApiResponse(200, b"{}"),
        )
        client = AlteredClient(
            altered,
            transport=fake,
            api_client_config=injected,
        )
        client.http.get("/v1/ping")
        assert fake.requests[0].headers.get("User-Agent") == "injected-ua"

    async def test_async_uses_injected_api_client_config_headers(self) -> None:
        """Variante async : en-têtes issus de ``api_client_config`` injectée."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        headers = dict(base_api.default_headers or {})
        headers["User-Agent"] = "injected-ua"
        injected = base_api.copy_with(default_headers=headers)
        fake = FakeAsyncTransport()
        fake.register(
            "GET",
            "https://api.test.example/v1/ping",
            ApiResponse(200, b"{}"),
        )
        client = AsyncAlteredClient(
            altered,
            transport=fake,
            api_client_config=injected,
        )
        await client.http.get("/v1/ping")
        assert fake.requests[0].headers.get("User-Agent") == "injected-ua"

    def test_sync_base_url_mismatch_raises(self) -> None:
        """``api_client_config.base_url`` doit coïncider avec ``config.base_url``."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        wrong = base_api.copy_with(base_url="https://other.example")
        with pytest.raises(AlteredConfigError, match="api_client_config.base_url"):
            AlteredClient(
                altered,
                transport=FakeSyncTransport(),
                api_client_config=wrong,
            )

    async def test_async_base_url_mismatch_raises(self) -> None:
        """Même règle pour la façade async."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        wrong = base_api.copy_with(base_url="https://other.example")
        with pytest.raises(AlteredConfigError, match="api_client_config.base_url"):
            AsyncAlteredClient(
                altered,
                transport=FakeAsyncTransport(),
                api_client_config=wrong,
            )

    def test_sync_accepts_trailing_slash_mismatch_after_rstrip(self) -> None:
        """Les URL sont comparées après ``rstrip('/')`` des deux côtés."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        slashy = base_api.copy_with(base_url=altered.base_url + "/")
        fake = FakeSyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        client = AlteredClient(altered, transport=fake, api_client_config=slashy)
        client.http.get("/v1/ping")
        assert len(fake.requests) == 1

    async def test_async_accepts_trailing_slash_mismatch_after_rstrip(self) -> None:
        """Même normalisation côté async."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        slashy = base_api.copy_with(base_url=altered.base_url + "/")
        fake = FakeAsyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        client = AsyncAlteredClient(altered, transport=fake, api_client_config=slashy)
        await client.http.get("/v1/ping")
        assert len(fake.requests) == 1

    def test_async_transport_on_sync_client_raises(self) -> None:
        """Un transport async (``send`` coroutine) est refusé sur ``AlteredClient``."""
        with pytest.raises(TypeError, match="async send"):
            AlteredClient(_altered(), transport=FakeAsyncTransport())

    async def test_sync_transport_on_async_client_raises(self) -> None:
        """Un transport sync est refusé sur ``AsyncAlteredClient``."""
        with pytest.raises(TypeError, match="synchronous send"):
            AsyncAlteredClient(_altered(), transport=FakeSyncTransport())

    def test_altered_config_identity_unchanged_on_sync_wrap(self) -> None:
        """La façade garde la même instance ``AlteredApiConfig``."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        client = AlteredClient(
            altered,
            transport=FakeSyncTransport(),
            api_client_config=base_api,
        )
        assert client.config is altered

    async def test_altered_config_identity_unchanged_on_async_wrap(self) -> None:
        """Même garantie pour la façade async."""
        altered = _altered()
        base_api = AlteredApiClientConfigBuilder.build(altered)
        client = AsyncAlteredClient(
            altered,
            transport=FakeAsyncTransport(),
            api_client_config=base_api,
        )
        assert client.config is altered

    def test_close_closes_injected_transport_with_injected_api_config(self) -> None:
        """``close`` propage au transport injecté (doc cycle de vie)."""
        altered = _altered()
        api_cfg = AlteredApiClientConfigBuilder.build(altered)
        fake = FakeSyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        with AlteredClient(
            altered,
            transport=fake,
            api_client_config=api_cfg,
        ) as client:
            client.http.get("/v1/ping")
        assert fake.closed

    async def test_aclose_closes_injected_transport_with_injected_api_config(
        self,
    ) -> None:
        """``aclose`` ferme le transport factice injecté."""
        altered = _altered()
        api_cfg = AlteredApiClientConfigBuilder.build(altered)
        fake = FakeAsyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        async with AsyncAlteredClient(
            altered,
            transport=fake,
            api_client_config=api_cfg,
        ) as client:
            await client.http.get("/v1/ping")
        assert fake.closed
