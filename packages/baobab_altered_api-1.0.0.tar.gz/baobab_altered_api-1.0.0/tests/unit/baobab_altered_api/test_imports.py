"""Tests d’import sans effets de bord (BL-001-003)."""

from __future__ import annotations

import importlib
import logging
import subprocess
import sys
from pathlib import Path
from typing import Any

import httpx
import pytest


class TestImportsWithoutSideEffects:
    """Garantit qu’un import reste sans effets de bord indésirables."""

    def test_import_does_not_add_root_logging_handlers(self) -> None:
        """Le rechargement du package ne doit pas ajouter de handlers racine."""
        root = logging.getLogger()
        before = len(root.handlers)
        importlib.reload(importlib.import_module("baobab_altered_api"))
        assert len(root.handlers) == before

    def test_import_does_not_instantiate_httpx_client(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Aucun ``httpx.Client`` ne doit être créé lors d’un import du package."""
        calls: list[object] = []
        original_init = httpx.Client.__init__

        def traced_init(self: httpx.Client, *args: Any, **kwargs: Any) -> None:
            calls.append(object())
            return original_init(self, *args, **kwargs)

        monkeypatch.setattr(httpx.Client, "__init__", traced_init)
        importlib.reload(importlib.import_module("baobab_altered_api"))
        assert not calls

    def test_fresh_process_import_does_not_query_altered_env(self) -> None:
        """Un processus Python vierge ne doit pas lire ``ALTERED_API_*`` à l’import."""
        repo_root = Path(__file__).resolve().parents[3]
        src = repo_root / "src"
        script = r"""
import os
import sys

seen: list[str] = []

_orig_getenv = os.getenv


def getenv(key: str, default: str | None = None) -> str | None:
    seen.append(str(key))
    return _orig_getenv(key, default)


os.getenv = getenv
sys.path.insert(0, sys.argv[1])

import baobab_altered_api  # noqa: F401, E402

bad = [k for k in seen if k.startswith("ALTERED_API_")]
sys.exit(1 if bad else 0)
"""
        result = subprocess.run(
            [sys.executable, "-c", script, str(src)],
            check=False,
            cwd=str(repo_root),
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr
