"""Tests retries, timeouts et mapping socle (BL-011-004)."""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import httpx
import pytest
from baobab_api_call import ApiRequest, AsyncApiClient, SyncApiClient

from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from baobab_altered_api.transports.altered_async_transport import AlteredAsyncTransport
from baobab_altered_api.transports.altered_sync_transport import AlteredSyncTransport


class TestRetriesTimeouts:
    """Propagation timeout / retry entre config, socle et transports."""

    def test_builder_maps_jitter_to_retry_policy(self) -> None:
        """Le jitter Altered est reflété dans la ``RetryPolicy`` du socle."""
        cfg = AlteredApiConfig(retry_jitter=False, retry_backoff_seconds=0.1)
        api = AlteredApiClientConfigBuilder.build(cfg)
        assert api.retry_policy is not None
        assert api.retry_policy.jitter is False
        assert api.retry_policy.backoff_initial == pytest.approx(0.1)

    def test_sync_transport_uses_default_timeout_when_request_omits_it(self) -> None:
        """HTTPX reçoit le délai par défaut du transport si la requête n'en a pas."""
        client = httpx.Client(
            transport=httpx.MockTransport(lambda r: httpx.Response(200)),
        )
        spy = MagicMock(wraps=client.build_request)
        client.build_request = spy  # type: ignore[method-assign]
        transport = AlteredSyncTransport(client, default_timeout_seconds=11.25)
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/x",
            timeout_seconds=None,
        )
        transport.send(req)
        assert spy.called
        assert spy.call_args.kwargs["timeout"] == 11.25

    def test_sync_client_retries_transient_503(self) -> None:
        """Le socle rejoue sur 503 puis réussit (politique par défaut)."""
        state = {"n": 0}

        def handler(_request: httpx.Request) -> httpx.Response:
            state["n"] += 1
            if state["n"] < 2:
                return httpx.Response(503, text="unavailable")
            return httpx.Response(200, json={"ok": True})

        altered = AlteredApiConfig(
            base_url="https://api.test.example",
            retry_max_attempts=4,
            retry_backoff_seconds=0.0,
            retry_jitter=False,
        )
        api_cfg = AlteredApiClientConfigBuilder.build(altered)
        httpx_client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(
            httpx_client,
            default_timeout_seconds=float(altered.timeout_seconds),
        )
        with SyncApiClient(api_cfg, transport, sleep=lambda _d: None) as client:
            resp = client.get("/v1/ping")
        assert resp.status_code == 200
        assert state["n"] == 2
        httpx_client.close()

    @pytest.mark.asyncio
    async def test_async_transport_uses_default_timeout_when_request_omits_it(
        self,
    ) -> None:
        """Transport async : même règle de délai par défaut."""
        client = httpx.AsyncClient(
            transport=httpx.MockTransport(lambda r: httpx.Response(200)),
        )
        spy = MagicMock(wraps=client.build_request)
        client.build_request = spy  # type: ignore[method-assign]
        transport = AlteredAsyncTransport(client, default_timeout_seconds=9.5)
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/y",
            timeout_seconds=None,
        )
        await transport.send(req)
        assert spy.called
        assert spy.call_args.kwargs["timeout"] == 9.5
        await client.aclose()

    @pytest.mark.asyncio
    async def test_async_client_retries_transient_503(self) -> None:
        """Parité async : retry sur 503 puis succès."""
        state = {"n": 0}

        def handler(_request: httpx.Request) -> httpx.Response:
            state["n"] += 1
            if state["n"] < 2:
                return httpx.Response(503, text="unavailable")
            return httpx.Response(200, json={"ok": True})

        altered = AlteredApiConfig(
            base_url="https://api.test.example",
            retry_max_attempts=4,
            retry_backoff_seconds=0.0,
            retry_jitter=False,
        )
        api_cfg = AlteredApiClientConfigBuilder.build(altered)
        httpx_client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        transport = AlteredAsyncTransport(
            httpx_client,
            default_timeout_seconds=float(altered.timeout_seconds),
        )
        async with AsyncApiClient(api_cfg, transport, sleep=asyncio.sleep) as client:
            resp = await client.get("/v1/ping")
        assert resp.status_code == 200
        assert state["n"] == 2
        await httpx_client.aclose()

    def test_sync_transport_rejects_invalid_default_timeout(self) -> None:
        """Un délai par défaut non strictement positif est refusé."""
        with pytest.raises(AlteredConfigError):
            AlteredSyncTransport(default_timeout_seconds=0.0)
