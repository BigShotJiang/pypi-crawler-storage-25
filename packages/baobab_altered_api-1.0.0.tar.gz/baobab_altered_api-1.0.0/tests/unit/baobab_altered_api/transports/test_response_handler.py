"""Tests de ``AlteredTransportResponseHandler``."""

from __future__ import annotations

import pytest
from baobab_api_call import ApiRequest, ApiResponse
from baobab_api_call.exceptions import ApiNetworkError, ApiTimeoutError

from baobab_altered_api.exceptions import (
    AlteredApiError,
    AlteredJsonDecodeError,
    AlteredNetworkError,
    AlteredNotFoundError,
    AlteredRateLimitError,
    AlteredServiceUnavailableError,
    AlteredTimeoutError,
)
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)


class TestAlteredTransportResponseHandler:
    """Normalisation JSON et erreurs HTTP / client."""

    def test_json_success_object(self) -> None:
        """Un corps JSON objet est exposé dans ``AlteredJsonPayload.data``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/items")
        resp = ApiResponse(200, b'{"items": []}', request=req)
        payload = AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert payload.data == {"items": []}
        assert payload.pagination is None

    def test_json_success_list(self) -> None:
        """Un corps JSON tableau est accepté."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/items")
        resp = ApiResponse(200, b"[1, 2, 3]", request=req)
        payload = AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert payload.data == [1, 2, 3]

    def test_json_invalid_raises(self) -> None:
        """Un corps non JSON sur 200 lève ``AlteredJsonDecodeError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(200, b"not-json", request=req)
        with pytest.raises(AlteredJsonDecodeError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.http_status == 200
        assert ctx.value.path == req.path
        assert "not-json" not in str(ctx.value)

    def test_json_scalar_root_raises(self) -> None:
        """Une racine JSON primitive est rejetée."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/n")
        resp = ApiResponse(200, b"42", request=req)
        with pytest.raises(AlteredJsonDecodeError, match="object or array"):
            AlteredTransportResponseHandler.json_payload_or_raise(resp)

    def test_http_404_altered_not_found(self) -> None:
        """HTTP 404 devient ``AlteredNotFoundError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/missing")
        resp = ApiResponse(404, b"{}", request=req)
        with pytest.raises(AlteredNotFoundError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.http_status == 404
        assert ctx.value.path == req.path
        assert "secret-token" not in str(ctx.value).lower()

    def test_http_429_rate_limit(self) -> None:
        """HTTP 429 devient ``AlteredRateLimitError`` avec ``Retry-After`` numérique."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/limited")
        resp = ApiResponse(
            429,
            b"{}",
            request=req,
            headers={"Retry-After": "120"},
        )
        with pytest.raises(AlteredRateLimitError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.retry_after == 120.0
        assert ctx.value.http_status == 429

    def test_http_502_service_unavailable(self) -> None:
        """HTTP 5xx devient ``AlteredServiceUnavailableError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(502, b"upstream", request=req)
        with pytest.raises(AlteredServiceUnavailableError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.http_status == 502
        assert "upstream" not in str(ctx.value)

    def test_http_error_without_stdlib_phrase(self) -> None:
        """Un code 4xx sans entrée ``HTTPStatus`` produit un message minimal."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(499, b"", request=req)
        with pytest.raises(AlteredApiError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert "HTTP 499" in str(ctx.value)
        assert ctx.value.error_code == "HTTP_ERROR"

    def test_http_error_message_without_request(self) -> None:
        """Message HTTP d'erreur sans requête associée (pas de segment chemin)."""
        resp = ApiResponse(418, b"", request=None)
        with pytest.raises(AlteredApiError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert "HTTP 418" in str(ctx.value)
        assert "[" not in str(ctx.value)

    def test_http_429_retry_after_non_numeric_ignored(self) -> None:
        """``Retry-After`` non entier est ignoré (pas de date HTTP)."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/lim")
        resp = ApiResponse(
            429,
            b"{}",
            request=req,
            headers={"Retry-After": "Wed, 21 Oct 2015 07:28:00 GMT"},
        )
        with pytest.raises(AlteredRateLimitError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.retry_after is None

    def test_http_429_retry_after_garbage_ignored(self) -> None:
        """``Retry-After`` non strictement numérique est ignoré."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/lim")
        resp = ApiResponse(
            429,
            b"{}",
            request=req,
            headers={"Retry-After": "12abc"},
        )
        with pytest.raises(AlteredRateLimitError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.retry_after is None

    def test_http_429_without_headers(self) -> None:
        """429 sans en-têtes : pas de ``Retry-After``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/lim")
        resp = ApiResponse(429, b"{}", request=req, headers=None)
        with pytest.raises(AlteredRateLimitError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.retry_after is None

    def test_http_429_headers_without_retry_after(self) -> None:
        """429 avec en-têtes sans clé ``Retry-After``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/lim")
        resp = ApiResponse(
            429,
            b"{}",
            request=req,
            headers={"X-Other": "1"},
        )
        with pytest.raises(AlteredRateLimitError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.retry_after is None

    def test_pagination_ignores_non_numeric_total_count(self) -> None:
        """``X-Total-Count`` non numérique ne remplit pas ``total_count``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/items")
        resp = ApiResponse(
            200,
            b"{}",
            request=req,
            headers={"X-Total-Count": "many"},
        )
        payload = AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert payload.pagination is None

    def test_pagination_hints_from_headers(self) -> None:
        """Les indices ``X-Total-Count`` et ``Link`` rel=next sont capturés."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/items")
        resp = ApiResponse(
            200,
            b"[]",
            request=req,
            headers={
                "X-Total-Count": "99",
                "Link": '<https://api.test.example/v1/items?page=2>; rel="next"',
            },
        )
        payload = AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert payload.pagination == {"total_count": 99, "has_next": True}

    def test_raise_for_client_failure_timeout(self) -> None:
        """``ApiTimeoutError`` devient ``AlteredTimeoutError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/slow")
        exc = ApiTimeoutError("Request timeout", timeout_seconds=5.0, request=req)
        with pytest.raises(AlteredTimeoutError) as ctx:
            AlteredTransportResponseHandler.raise_for_client_failure(exc, req)
        assert ctx.value.path == req.path
        assert "5" not in str(ctx.value)

    def test_raise_for_client_failure_network(self) -> None:
        """``ApiNetworkError`` devient ``AlteredNetworkError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        exc = ApiNetworkError("Network error", cause=RuntimeError("oops"), request=req)
        with pytest.raises(AlteredNetworkError) as ctx:
            AlteredTransportResponseHandler.raise_for_client_failure(exc, req)
        assert ctx.value.path == req.path
        assert "oops" not in str(ctx.value)

    def test_raise_for_client_failure_unknown_reraises(self) -> None:
        """Les exceptions non réseau du socle sont propagées telles quelles."""
        with pytest.raises(ValueError, match="plain"):
            AlteredTransportResponseHandler.raise_for_client_failure(
                ValueError("plain")
            )

    def test_altered_api_error_repr_safe(self) -> None:
        """``repr`` des erreurs de base n'inclut pas de corps de réponse."""
        err = AlteredApiError("safe", http_status=400, path="https://x.test/p")
        r = repr(err)
        assert "safe" in r
        assert "secret" not in r.lower()

    def test_altered_rate_limit_repr_includes_retry_after(self) -> None:
        """``repr`` de ``AlteredRateLimitError`` expose ``retry_after``."""
        err = AlteredRateLimitError(retry_after=30.0, path="https://x.test/l")
        assert "retry_after=30.0" in repr(err)
