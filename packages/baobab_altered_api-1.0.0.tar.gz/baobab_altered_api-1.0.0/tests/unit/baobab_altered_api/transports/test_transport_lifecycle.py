"""Tests du cycle de vie des transports HTTPX (fermeture, context managers)."""

# Accès intentionnel aux attributs internes pour vérifier l'état HTTPX.
# pylint: disable=protected-access

from __future__ import annotations

import httpx
import pytest

from baobab_altered_api.transports.altered_async_transport import AlteredAsyncTransport
from baobab_altered_api.transports.altered_sync_transport import AlteredSyncTransport

_OK = httpx.MockTransport(lambda r: httpx.Response(200))


class TestTransportLifecycle:
    """Fermeture idempotente et context managers sync/async."""

    def test_sync_close_twice_does_not_raise_owned(self) -> None:
        """Deux appels à ``close()`` sur un client possédé ne lèvent pas."""
        transport = AlteredSyncTransport()
        client = transport._client
        transport.close()
        assert client.is_closed
        transport.close()
        assert client.is_closed

    def test_sync_close_twice_does_not_raise_injected(self) -> None:
        """Deux appels à ``close()`` avec client injecté ne lèvent pas."""
        inner = httpx.Client(transport=_OK)
        transport = AlteredSyncTransport(inner)
        transport.close()
        transport.close()
        assert not inner.is_closed
        inner.close()

    def test_sync_with_closes_owned_client(self) -> None:
        """``with`` sur un transport propriétaire ferme le client HTTPX."""
        transport = AlteredSyncTransport()
        client = transport._client
        assert not client.is_closed
        with transport:
            pass
        assert client.is_closed

    def test_sync_with_closes_after_exception_owned(self) -> None:
        """Le ``close`` est appelé même si le bloc ``with`` lève."""
        transport = AlteredSyncTransport()
        client = transport._client
        with pytest.raises(ValueError, match="boom"):
            with transport:
                raise ValueError("boom")
        assert client.is_closed

    def test_sync_with_does_not_close_injected_client(self) -> None:
        """Un client injecté n'est pas fermé par le context manager."""
        inner = httpx.Client(transport=_OK)
        transport = AlteredSyncTransport(inner)
        with transport:
            pass
        assert not inner.is_closed
        inner.close()

    async def test_async_aclose_twice_does_not_raise_owned(self) -> None:
        """Deux appels à ``aclose()`` sur un client possédé ne lèvent pas."""
        transport = AlteredAsyncTransport()
        client = transport._client
        await transport.aclose()
        assert client.is_closed
        await transport.aclose()
        assert client.is_closed

    async def test_async_aclose_twice_does_not_raise_injected(self) -> None:
        """Deux appels à ``aclose()`` avec client injecté ne lèvent pas."""
        inner = httpx.AsyncClient(transport=_OK)
        transport = AlteredAsyncTransport(inner)
        await transport.aclose()
        await transport.aclose()
        assert not inner.is_closed
        await inner.aclose()

    async def test_async_with_closes_owned_client(self) -> None:
        """``async with`` sur un transport propriétaire ferme le client HTTPX."""
        transport = AlteredAsyncTransport()
        client = transport._client
        assert not client.is_closed
        async with transport:
            pass
        assert client.is_closed

    async def test_async_with_closes_after_exception_owned(self) -> None:
        """L'``aclose`` est appelé même si le bloc ``async with`` lève."""
        transport = AlteredAsyncTransport()
        client = transport._client
        with pytest.raises(ValueError, match="boom"):
            async with transport:
                raise ValueError("boom")
        assert client.is_closed

    async def test_async_with_does_not_close_injected_client(self) -> None:
        """Un client injecté n'est pas fermé par le context manager async."""
        inner = httpx.AsyncClient(transport=_OK)
        transport = AlteredAsyncTransport(inner)
        async with transport:
            pass
        assert not inner.is_closed
        await inner.aclose()
