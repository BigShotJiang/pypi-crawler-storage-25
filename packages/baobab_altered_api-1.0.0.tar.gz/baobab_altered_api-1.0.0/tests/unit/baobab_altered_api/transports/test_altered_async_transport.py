"""Tests de ``AlteredAsyncTransport``."""

# pylint: disable=duplicate-code
# Miroir volontaire de ``test_altered_sync_transport`` (FEAT-003).

# Accès intentionnel aux attributs internes pour les tests de cycle de vie.
# pylint: disable=protected-access

from __future__ import annotations

import logging
from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from baobab_api_call import ApiRequest, AsyncApiClient

from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.transports.altered_async_transport import AlteredAsyncTransport

_OK = httpx.MockTransport(lambda r: httpx.Response(200))


class TestAlteredAsyncTransport:
    """Vérifie le transport asynchrone sans réseau réel (``MockTransport``)."""

    async def test_get_success_returns_json(self) -> None:
        """Un GET 200 retourne une ``ApiResponse`` avec corps JSON."""

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert str(request.url) == "https://api.test.example/v1/cards"
            return httpx.Response(200, json={"items": []})

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(method="GET", path="https://api.test.example/v1/cards")
        resp = await transport.send(req)
        assert resp.status_code == 200
        assert resp.json() == {"items": []}
        await client.aclose()

    async def test_http_error_surfaces_in_response(self) -> None:
        """Les codes d'erreur HTTP sont portés par ``ApiResponse`` (pas d'exception)."""

        def handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(502, text="bad gateway")

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(method="GET", path="https://api.test.example/x")
        resp = await transport.send(req)
        assert resp.is_error
        assert resp.status_code == 502
        await client.aclose()

    async def test_async_api_client_propagates_auth_headers(self) -> None:
        """Le client du socle applique l'auth avant l'envoi au transport."""
        seen: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen.update(dict(request.headers))
            return httpx.Response(200, json={"ok": True})

        altered = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
        )
        api_cfg = AlteredApiClientConfigBuilder.build(altered)
        httpx_client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        transport = AlteredAsyncTransport(httpx_client)
        async with AsyncApiClient(api_cfg, transport) as client:
            resp = await client.get("/v1/ping")
        assert resp.json() == {"ok": True}
        assert seen.get("authorization") == "Bearer baobab-api-token"
        await httpx_client.aclose()

    async def test_owns_client_flag(self) -> None:
        """Le transport sait s'il doit fermer le client HTTPX sous-jacent."""
        owned = AlteredAsyncTransport()
        assert owned._owns_client is True
        borrowed = AlteredAsyncTransport(
            httpx.AsyncClient(
                transport=httpx.MockTransport(lambda r: httpx.Response(200))
            )
        )
        assert borrowed._owns_client is False
        await owned.aclose()
        await borrowed._client.aclose()

    async def test_string_body_encoded(self) -> None:
        """Un corps ``str`` est encodé en UTF-8 pour HTTPX."""

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.content == b"hello"
            return httpx.Response(201)

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(method="POST", path="https://api.test.example/x", body="hello")
        resp = await transport.send(req)
        assert resp.status_code == 201
        await client.aclose()

    async def test_bytearray_body_accepted(self) -> None:
        """Les corps ``bytearray`` sont convertis en ``bytes``."""

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.content == b"\x01\x02"
            return httpx.Response(200)

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(
            method="POST",
            path="https://api.test.example/bin",
            body=bytearray(b"\x01\x02"),
        )
        await transport.send(req)
        await client.aclose()

    async def test_invalid_body_type_raises(self) -> None:
        """Un type de corps non supporté est rejeté."""
        client = httpx.AsyncClient(transport=_OK)
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(
            method="POST",
            path="https://api.test.example/x",
            body=cast(Any, 123),
        )
        with pytest.raises(TypeError, match="request body"):
            await transport.send(req)
        await client.aclose()

    async def test_read_timeout_raises_timeout_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Les timeouts HTTPX sont mappés vers ``TimeoutError``."""
        client = httpx.AsyncClient(transport=_OK)
        transport = AlteredAsyncTransport(client)

        async def _boom(_request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out")

        monkeypatch.setattr(client, "send", _boom)
        with pytest.raises(TimeoutError, match="timed out"):
            await transport.send(
                ApiRequest(method="GET", path="https://api.test.example/x"),
            )
        await client.aclose()

    async def test_request_error_raises_connection_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Les erreurs de requête HTTPX sont mappées vers ``ConnectionError``."""
        client = httpx.AsyncClient(transport=_OK)
        transport = AlteredAsyncTransport(client)

        async def _boom(_request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("no route")

        monkeypatch.setattr(client, "send", _boom)
        with pytest.raises(ConnectionError, match="no route"):
            await transport.send(
                ApiRequest(method="GET", path="https://api.test.example/x"),
            )
        await client.aclose()

    async def test_success_logs_minimal_http_line(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Un succès émet une ligne ``INFO`` sans corps ni en-têtes."""
        client = httpx.AsyncClient(
            transport=httpx.MockTransport(lambda r: httpx.Response(200, json={}))
        )
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(method="GET", path="https://api.test.example/v1/cards")
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            await transport.send(req)
        text = caplog.text
        assert "http_outbound" in text
        assert "method=GET" in text
        assert "status=200" in text
        await client.aclose()

    async def test_success_log_masks_sensitive_query(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Un jeton en query n'apparaît pas dans les journaux du transport async."""
        sentinel = "phf_super_secret_async_transport_query_never_logged_zzzz"
        client = httpx.AsyncClient(
            transport=httpx.MockTransport(lambda r: httpx.Response(200, json={}))
        )
        transport = AlteredAsyncTransport(client)
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/cards",
            params={"token": sentinel},
        )
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            await transport.send(req)
        assert sentinel not in caplog.text
        await client.aclose()

    async def test_aclose_skips_injected_client(self) -> None:
        """Un client fourni n'est pas fermé par le transport."""
        mock_client = MagicMock(spec=httpx.AsyncClient)
        inner = httpx.AsyncClient(
            transport=httpx.MockTransport(lambda r: httpx.Response(204))
        )
        mock_client.build_request = inner.build_request
        mock_client.send = inner.send
        mock_client.aclose = AsyncMock()
        transport = AlteredAsyncTransport(mock_client)
        await transport.aclose()
        mock_client.aclose.assert_not_awaited()
        await inner.aclose()

    async def test_owned_client_gets_closed(self) -> None:
        """Le client HTTPX créé par défaut est fermé avec le transport."""
        transport = AlteredAsyncTransport()
        spy = AsyncMock()
        transport._client.aclose = spy
        await transport.aclose()
        spy.assert_awaited_once()
