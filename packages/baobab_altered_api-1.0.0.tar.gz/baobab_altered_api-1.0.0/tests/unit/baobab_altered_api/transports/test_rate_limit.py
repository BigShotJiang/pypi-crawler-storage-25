"""Tests du pacing client (BL-011-005) et branchement ``ApiClientConfig``."""

from __future__ import annotations

import pytest
from baobab_api_call import ApiRequest, ApiResponse, SyncApiClient

from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from baobab_altered_api.transports.altered_rate_limit_middleware import (
    AlteredRateLimitMiddleware,
)
from baobab_altered_api.transports.altered_rate_limit_middleware_async import (
    AlteredRateLimitMiddlewareAsync,
)
from tests.fakes.fake_sync_transport import FakeSyncTransport


class TestRateLimitMiddleware:
    """Comportement des middlewares de limitation et propagation builder → socle."""

    def test_sync_before_request_waits_until_min_interval(self) -> None:
        """Un second appel immédiat déclenche un ``sleep`` de l'intervalle minimal."""
        clock = {"t": 0.0}
        sleeps: list[float] = []

        def mono() -> float:
            return clock["t"]

        def sleep_fn(delay: float) -> None:
            sleeps.append(delay)
            clock["t"] += delay

        mw = AlteredRateLimitMiddleware(
            max_per_second=2.0,
            monotonic_fn=mono,
            sleep_fn=sleep_fn,
        )
        req = ApiRequest(method="GET", path="https://api.test.example/x")
        assert mw.before_request(req) is req
        assert not sleeps
        mw.before_request(req)
        assert len(sleeps) == 1
        assert sleeps[0] == pytest.approx(0.5)

    def test_sync_rejects_invalid_rate(self) -> None:
        """Un plafond non positif est refusé."""
        with pytest.raises(AlteredConfigError, match="max_per_second"):
            AlteredRateLimitMiddleware(max_per_second=0.0)

    @pytest.mark.asyncio
    async def test_async_before_request_waits_until_min_interval(self) -> None:
        """Parité async : ``await sleep`` reflète l'intervalle minimal."""
        clock = {"t": 0.0}
        sleeps: list[float] = []

        def mono() -> float:
            return clock["t"]

        async def sleep_fn(delay: float) -> None:
            sleeps.append(delay)
            clock["t"] += delay

        mw = AlteredRateLimitMiddlewareAsync(
            max_per_second=4.0,
            monotonic_fn=mono,
            sleep_fn=sleep_fn,
        )
        req = ApiRequest(method="GET", path="https://api.test.example/y")
        assert await mw.before_request(req) is req
        assert not sleeps
        await mw.before_request(req)
        assert len(sleeps) == 1
        assert sleeps[0] == pytest.approx(0.25)

    def test_builder_attaches_middlewares_when_rate_configured(self) -> None:
        """``rate_limit_per_second`` installe sync + async middlewares."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            rate_limit_per_second=3.0,
        )
        core = AlteredApiClientConfigBuilder.build(cfg)
        assert len(core.middlewares) == 1
        assert len(core.async_middlewares) == 1
        assert isinstance(core.middlewares[0], AlteredRateLimitMiddleware)
        assert isinstance(core.async_middlewares[0], AlteredRateLimitMiddlewareAsync)

    def test_builder_leaves_middlewares_empty_when_rate_none(self) -> None:
        """Sans limite de débit, aucun middleware n'est ajouté."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        core = AlteredApiClientConfigBuilder.build(cfg)
        assert not core.middlewares
        assert not core.async_middlewares

    def test_sync_client_runs_with_high_local_rate(self) -> None:
        """Un plafond élevé évite des attentes perceptibles entre deux GET."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
            rate_limit_per_second=50_000.0,
        )
        api = AlteredApiClientConfigBuilder.build(cfg)
        fake = FakeSyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        with SyncApiClient(api, fake, sleep=lambda _d: None) as client:
            client.get("/a")
            client.get("/b")
        assert len(fake.requests) == 2
