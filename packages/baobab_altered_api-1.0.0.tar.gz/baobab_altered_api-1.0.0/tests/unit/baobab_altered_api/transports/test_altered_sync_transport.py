"""Tests de ``AlteredSyncTransport``."""

# Accès intentionnel aux attributs internes pour les tests de cycle de vie.
# pylint: disable=protected-access

from __future__ import annotations

import logging
from typing import Any, cast
from unittest.mock import MagicMock

import httpx
import pytest
from baobab_api_call import ApiRequest, SyncApiClient

from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.transports.altered_sync_transport import AlteredSyncTransport

_OK = httpx.MockTransport(lambda r: httpx.Response(200))


class TestAlteredSyncTransport:
    """Vérifie le transport synchrone sans réseau réel (``MockTransport``)."""

    def test_get_success_returns_json(self) -> None:
        """Un GET 200 retourne une ``ApiResponse`` avec corps JSON."""

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert str(request.url) == "https://api.test.example/v1/cards"
            return httpx.Response(200, json={"items": []})

        client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(client)
        req = ApiRequest(method="GET", path="https://api.test.example/v1/cards")
        resp = transport.send(req)
        assert resp.status_code == 200
        assert resp.json() == {"items": []}

    def test_http_error_surfaces_in_response(self) -> None:
        """Les codes d'erreur HTTP sont portés par ``ApiResponse`` (pas d'exception)."""

        def handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(502, text="bad gateway")

        client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(client)
        req = ApiRequest(method="GET", path="https://api.test.example/x")
        resp = transport.send(req)
        assert resp.is_error
        assert resp.status_code == 502

    def test_sync_api_client_propagates_auth_headers(self) -> None:
        """Le client du socle applique l'auth avant l'envoi au transport."""
        seen: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen.update(dict(request.headers))
            return httpx.Response(200, json={"ok": True})

        altered = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
        )
        api_cfg = AlteredApiClientConfigBuilder.build(altered)
        httpx_client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(httpx_client)
        with SyncApiClient(api_cfg, transport) as client:
            resp = client.get("/v1/ping")
        assert resp.json() == {"ok": True}
        assert seen.get("authorization") == "Bearer baobab-api-token"

    def test_owns_client_flag(self) -> None:
        """Le transport sait s'il doit fermer le client HTTPX sous-jacent."""
        owned = AlteredSyncTransport()
        assert owned._owns_client is True
        borrowed = AlteredSyncTransport(
            httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200)))
        )
        assert borrowed._owns_client is False

    def test_string_body_encoded(self) -> None:
        """Un corps ``str`` est encodé en UTF-8 pour HTTPX."""

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.content == b"hello"
            return httpx.Response(201)

        client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(client)
        req = ApiRequest(method="POST", path="https://api.test.example/x", body="hello")
        resp = transport.send(req)
        assert resp.status_code == 201

    def test_bytearray_body_accepted(self) -> None:
        """Les corps ``bytearray`` sont convertis en ``bytes``."""

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.content == b"\x01\x02"
            return httpx.Response(200)

        client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(client)
        req = ApiRequest(
            method="POST",
            path="https://api.test.example/bin",
            body=bytearray(b"\x01\x02"),
        )
        transport.send(req)

    def test_invalid_body_type_raises(self) -> None:
        """Un type de corps non supporté est rejeté."""
        client = httpx.Client(transport=_OK)
        transport = AlteredSyncTransport(client)
        req = ApiRequest(
            method="POST",
            path="https://api.test.example/x",
            body=cast(Any, 123),
        )
        with pytest.raises(TypeError, match="request body"):
            transport.send(req)

    def test_read_timeout_raises_timeout_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Les timeouts HTTPX sont mappés vers ``TimeoutError``."""
        client = httpx.Client(transport=_OK)
        transport = AlteredSyncTransport(client)

        def _boom(_request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out")

        monkeypatch.setattr(client, "send", _boom)
        with pytest.raises(TimeoutError, match="timed out"):
            transport.send(
                ApiRequest(method="GET", path="https://api.test.example/x"),
            )

    def test_request_error_raises_connection_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Les erreurs de requête HTTPX sont mappées vers ``ConnectionError``."""
        client = httpx.Client(transport=_OK)
        transport = AlteredSyncTransport(client)

        def _boom(_request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("no route")

        monkeypatch.setattr(client, "send", _boom)
        with pytest.raises(ConnectionError, match="no route"):
            transport.send(
                ApiRequest(method="GET", path="https://api.test.example/x"),
            )

    def test_close_skips_injected_client(self) -> None:
        """Un client fourni n'est pas fermé par le transport."""
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.build_request = httpx.Client(
            transport=httpx.MockTransport(lambda r: httpx.Response(204))
        ).build_request
        mock_client.send = httpx.Client(
            transport=httpx.MockTransport(lambda r: httpx.Response(204))
        ).send
        transport = AlteredSyncTransport(mock_client)
        transport.close()
        mock_client.close.assert_not_called()

    def test_owned_client_gets_closed(self) -> None:
        """Le client HTTPX créé par défaut est fermé avec le transport."""
        transport = AlteredSyncTransport()
        spy = MagicMock(wraps=transport._client.close)
        transport._client.close = spy  # type: ignore[method-assign]
        transport.close()
        spy.assert_called_once()

    def test_success_logs_minimal_http_line(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Un succès émet une ligne ``INFO`` sans corps ni en-têtes."""
        client = httpx.Client(
            transport=httpx.MockTransport(lambda r: httpx.Response(200, json={}))
        )
        transport = AlteredSyncTransport(client)
        req = ApiRequest(method="GET", path="https://api.test.example/v1/cards")
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            transport.send(req)
        text = caplog.text
        assert "http_outbound" in text
        assert "method=GET" in text
        assert "status=200" in text
        assert "https://api.test.example/v1/cards" in text

    def test_success_log_masks_sensitive_query(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Un jeton en query n'apparaît pas dans les journaux du transport."""
        sentinel = "phf_super_secret_transport_query_never_logged_zzzz"

        def handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={})

        client = httpx.Client(transport=httpx.MockTransport(handler))
        transport = AlteredSyncTransport(client)
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/cards",
            params={"token": sentinel},
        )
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            transport.send(req)
        assert sentinel not in caplog.text
