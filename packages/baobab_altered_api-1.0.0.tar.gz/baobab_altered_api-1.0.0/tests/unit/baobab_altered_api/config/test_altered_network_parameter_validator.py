"""Tests du validateur de paramètres réseau."""

from __future__ import annotations

from typing import cast

import pytest

from baobab_altered_api.config.altered_network_parameter_validator import (
    MAX_RETRY_ATTEMPTS,
    AlteredNetworkParameterValidator,
)
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class TestAlteredNetworkParameterValidator:
    """Valide les règles réseau et numériques partagées."""

    def test_normalize_http_url_accepts_https(self) -> None:
        """Une URL HTTPS valide est normalisée."""
        out = AlteredNetworkParameterValidator.normalize_http_url(
            "https://Example.COM/api/"
        )
        assert out == "https://example.com/api"

    def test_normalize_http_url_rejects_credentials(self) -> None:
        """Les identifiants dans l'autorité sont refusés."""
        with pytest.raises(AlteredConfigError, match="base_url"):
            AlteredNetworkParameterValidator.normalize_http_url(
                "https://user:pass@example.com"
            )

    def test_validate_timeout_rejects_non_positive(self) -> None:
        """Un timeout nul ou négatif est refusé."""
        with pytest.raises(AlteredConfigError):
            AlteredNetworkParameterValidator.validate_timeout_seconds(0.0)

    def test_validate_retry_max_attempts(self) -> None:
        """Le nombre de tentatives doit être >= 1."""
        with pytest.raises(AlteredConfigError):
            AlteredNetworkParameterValidator.validate_retry_max_attempts(0)

    def test_validate_user_agent_empty(self) -> None:
        """Un ``User-Agent`` vide est refusé."""
        with pytest.raises(AlteredConfigError):
            AlteredNetworkParameterValidator.validate_non_empty_user_agent("  ")

    def test_validate_timeout_rejects_bool(self) -> None:
        """Les booléens ne sont pas des nombres valides pour le timeout."""
        with pytest.raises(AlteredConfigError):
            AlteredNetworkParameterValidator.validate_timeout_seconds(cast(float, True))

    def test_validate_retry_rejects_bool(self) -> None:
        """Les booléens ne sont pas des entiers valides pour les retries."""
        with pytest.raises(AlteredConfigError):
            AlteredNetworkParameterValidator.validate_retry_max_attempts(
                cast(int, True)
            )

    def test_validate_backoff_rejects_bool(self) -> None:
        """Le backoff refuse les booléens."""
        with pytest.raises(AlteredConfigError, match="retry_backoff_seconds"):
            AlteredNetworkParameterValidator.validate_retry_backoff_seconds(
                cast(float, True)
            )

    def test_validate_rate_limit_rejects_bool(self) -> None:
        """La limite de débit refuse les booléens."""
        with pytest.raises(AlteredConfigError, match="rate_limit_per_second"):
            AlteredNetworkParameterValidator.validate_optional_rate_limit(
                cast(float | None, True)
            )

    def test_validate_rate_limit_non_positive(self) -> None:
        """Une limite de débit nulle est refusée."""
        with pytest.raises(AlteredConfigError):
            AlteredNetworkParameterValidator.validate_optional_rate_limit(0.0)

    def test_validate_retry_max_attempts_upper_bound(self) -> None:
        """Au-delà du plafond, la validation échoue."""
        with pytest.raises(AlteredConfigError, match="retry_max_attempts"):
            AlteredNetworkParameterValidator.validate_retry_max_attempts(
                MAX_RETRY_ATTEMPTS + 1
            )
