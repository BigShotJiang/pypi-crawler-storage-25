"""Tests de ``AlteredApiConfig``."""

from __future__ import annotations

import dataclasses

import pytest

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.config.altered_locale import AlteredLocale
from baobab_altered_api.config.env_loader import load_config_from_env
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class TestAlteredApiConfig:
    """Couvre création, validation et immutabilité."""

    def test_default_config_is_valid(self) -> None:
        """La configuration par défaut doit être instanciable."""
        cfg = AlteredApiConfig()
        assert cfg.base_url == "https://api.altered.gg"
        assert cfg.locale == AlteredLocale.FR_FR
        assert "baobab-altered-api/" in cfg.user_agent

    def test_immutability(self) -> None:
        """Les champs frozen ne doivent pas être modifiables."""
        cfg = AlteredApiConfig()
        with pytest.raises(dataclasses.FrozenInstanceError):
            cfg.base_url = "https://other.example"  # type: ignore[misc]

    def test_copy_with_returns_new_instance(self) -> None:
        """``copy_with`` doit produire une nouvelle instance validée."""
        cfg = AlteredApiConfig()
        other = cfg.copy_with(base_url="https://api.example.com")
        assert other.base_url == "https://api.example.com"
        assert cfg.base_url == "https://api.altered.gg"

    def test_from_environment_delegates_to_loader(self) -> None:
        """``from_environment`` est un alias explicite de ``load_config_from_env``."""
        env = {"ALTERED_API_BASE_URL": "https://env-alias.example.com"}
        assert AlteredApiConfig.from_environment(env) == load_config_from_env(env)

    def test_invalid_base_url(self) -> None:
        """Une URL vide ou sans schéma HTTP(S) est refusée."""
        with pytest.raises(AlteredConfigError):
            AlteredApiConfig(base_url="")

    def test_mutually_exclusive_auth(self) -> None:
        """``api_key`` et ``bearer_token`` ne peuvent coexister."""
        with pytest.raises(AlteredConfigError, match="both"):
            AlteredApiConfig(api_key="k", bearer_token="baobab-api-token")

    def test_retry_bounds(self) -> None:
        """Les retries hors bornes sont refusés."""
        with pytest.raises(AlteredConfigError):
            AlteredApiConfig(retry_max_attempts=0)

    def test_base_url_stripped_and_normalized(self) -> None:
        """Les espaces et la normalisation d'URL mettent à jour le champ stocké."""
        cfg = AlteredApiConfig(base_url="  https://API.Altered.gg/path/  ")
        assert cfg.base_url == "https://api.altered.gg/path"

    def test_user_agent_stripped(self) -> None:
        """Le ``User-Agent`` est normalisé par ``strip``."""
        cfg = AlteredApiConfig(user_agent="  my-agent/2  ")
        assert cfg.user_agent == "my-agent/2"

    def test_locale_must_be_enum_member(self) -> None:
        """Un type de locale incorrect est refusé."""
        with pytest.raises(AlteredConfigError, match="locale must be AlteredLocale"):
            AlteredApiConfig(locale=object())  # type: ignore[arg-type]

    def test_api_key_empty_rejected(self) -> None:
        """Une clé API vide après strip est refusée."""
        with pytest.raises(AlteredConfigError, match="api_key must be non-empty"):
            AlteredApiConfig(api_key="   ")

    def test_api_key_header_name_empty(self) -> None:
        """Un nom d'en-tête vide est refusé."""
        with pytest.raises(AlteredConfigError, match="api_key_header_name"):
            AlteredApiConfig(api_key="x", api_key_header_name="  ")

    def test_api_key_query_param_empty(self) -> None:
        """Un paramètre de query vide est refusé."""
        with pytest.raises(AlteredConfigError, match="api_key_query_param"):
            AlteredApiConfig(api_key="x", api_key_query_param="  ")

    def test_bearer_token_whitespace_only_rejected(self) -> None:
        """Un bearer composé uniquement d'espaces est refusé."""
        with pytest.raises(AlteredConfigError, match="bearer_token"):
            AlteredApiConfig(bearer_token="   ")

    def test_rate_limit_positive_accepted(self) -> None:
        """Une limite de débit strictement positive est acceptée."""
        cfg = AlteredApiConfig(rate_limit_per_second=10.0)
        assert cfg.rate_limit_per_second == 10.0

    def test_rate_limit_invalid(self) -> None:
        """Une limite de débit non positive est refusée."""
        with pytest.raises(AlteredConfigError):
            AlteredApiConfig(rate_limit_per_second=0.0)

    def test_open_data_url_normalized(self) -> None:
        """``open_data_url`` est validé et normalisé."""
        cfg = AlteredApiConfig(
            open_data_url="  https://DATA.example.com/export/  ",
        )
        assert cfg.open_data_url == "https://data.example.com/export"

    def test_open_data_url_blank_rejected(self) -> None:
        """Une URL Open Data vide après strip est refusée."""
        with pytest.raises(AlteredConfigError, match="open_data_url"):
            AlteredApiConfig(open_data_url="   ")

    def test_str_matches_repr(self) -> None:
        """``str`` est aligné sur ``repr`` pour la lisibilité."""
        cfg = AlteredApiConfig()
        assert str(cfg) == repr(cfg)
