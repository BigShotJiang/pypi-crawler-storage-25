"""Tests pour :class:`~baobab_altered_api.config.altered_locale.AlteredLocale`."""

from __future__ import annotations

import pytest

from baobab_altered_api.config.altered_locale import AlteredLocale


class TestAlteredLocale:
    """Vérifie les locales supportées."""

    @pytest.mark.parametrize(
        ("member", "expected_accept_language"),
        (
            (AlteredLocale.FR_FR, "fr-FR"),
            (AlteredLocale.EN_US, "en-US"),
            (AlteredLocale.FR, "fr"),
            (AlteredLocale.EN, "en"),
        ),
    )
    def test_accept_language_value(
        self, member: AlteredLocale, expected_accept_language: str
    ) -> None:
        """Chaque membre doit exposer une valeur ``Accept-Language`` cohérente."""
        assert member.accept_language_value() == expected_accept_language
