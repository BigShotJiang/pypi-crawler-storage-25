"""Tests de non-fuite des secrets dans les représentations et erreurs."""

from __future__ import annotations

import pytest

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class TestSecretRedaction:
    """Vérifie que les sentinelles secrètes n'apparaissent pas dans les sorties."""

    _SENTINEL: str = "SENTINEL_SECRET_TOKEN_XYZ_12345"
    _TEST_BEARER: str = "baobab-api-token"

    def test_repr_masks_api_key(self) -> None:
        """``repr`` ne doit pas contenir la clé API en clair."""
        cfg = AlteredApiConfig(api_key=self._SENTINEL)
        text = repr(cfg)
        assert self._SENTINEL not in text
        assert "<redacted>" in text

    def test_repr_masks_bearer(self) -> None:
        """``repr`` ne doit pas contenir le bearer en clair."""
        cfg = AlteredApiConfig(bearer_token=self._TEST_BEARER)
        text = repr(cfg)
        assert self._TEST_BEARER not in text

    def test_validation_error_does_not_echo_bearer(self) -> None:
        """Une erreur de validation ne doit pas réimprimer le jeton."""
        with pytest.raises(AlteredConfigError) as excinfo:
            AlteredApiConfig(bearer_token=self._TEST_BEARER, timeout_seconds=-1.0)
        assert self._TEST_BEARER not in str(excinfo.value)

    def test_str_masks_secrets(self) -> None:
        """``str`` suit ``repr`` et ne divulgue pas les secrets."""
        cfg = AlteredApiConfig(api_key=self._SENTINEL)
        assert self._SENTINEL not in str(cfg)
