"""Tests pour la conversion vers ``ApiClientConfig``."""

from __future__ import annotations

from baobab_api_call import ApiClientConfig

from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
    to_api_client_config,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.config.altered_locale import AlteredLocale


class TestAlteredApiClientConfigBuilder:
    """Vérifie le mapping Altered → socle."""

    def test_build_sets_headers_and_urls(self) -> None:
        """Les en-têtes par défaut et l'URL de base sont transmis."""
        cfg = AlteredApiConfig(
            base_url="https://api.example.com",
            locale=AlteredLocale.EN_US,
            user_agent="ua-test/1",
        )
        core = AlteredApiClientConfigBuilder.build(cfg)
        assert isinstance(core, ApiClientConfig)
        assert core.base_url == "https://api.example.com"
        merged = core.merge_headers()
        assert merged["User-Agent"] == "ua-test/1"
        assert merged["Accept"] == "application/json"
        assert merged["Accept-Language"] == "en-US"

    def test_to_api_client_config_alias(self) -> None:
        """La fonction ``to_api_client_config`` délègue au builder."""
        cfg = AlteredApiConfig()
        assert to_api_client_config(cfg).base_url == cfg.base_url
