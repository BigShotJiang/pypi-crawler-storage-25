"""Tests pour :func:`~baobab_altered_api.config.env_loader.load_config_from_env`."""

from __future__ import annotations

import pytest

from baobab_altered_api.config.altered_locale import AlteredLocale
from baobab_altered_api.config.env_loader import load_config_from_env
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class TestLoadConfigFromEnv:
    """Vérifie le chargement explicite depuis un mapping."""

    def test_empty_mapping_yields_defaults(self) -> None:
        """Sans variables, la configuration par défaut s'applique."""
        cfg = load_config_from_env({})
        assert cfg.base_url == "https://api.altered.gg"

    def test_parses_known_variables(self) -> None:
        """Les variables supportées sont converties."""
        env = {
            "ALTERED_API_BASE_URL": "https://api.example.com",
            "ALTERED_API_LOCALE": "en-us",
            "ALTERED_API_TIMEOUT_SECONDS": "12.5",
            "ALTERED_API_RETRY_MAX_ATTEMPTS": "5",
        }
        cfg = load_config_from_env(env)
        assert cfg.base_url == "https://api.example.com"
        assert cfg.locale == AlteredLocale.EN_US
        assert cfg.timeout_seconds == 12.5
        assert cfg.retry_max_attempts == 5

    def test_parses_backoff_and_rate_limit(self) -> None:
        """Backoff et limite de débit optionnelle sont lus depuis l'environnement."""
        env = {
            "ALTERED_API_RETRY_BACKOFF_SECONDS": "2.5",
            "ALTERED_API_RATE_LIMIT_PER_SECOND": "8",
        }
        cfg = load_config_from_env(env)
        assert cfg.retry_backoff_seconds == 2.5
        assert cfg.rate_limit_per_second == 8.0

    def test_rejects_both_key_and_bearer(self) -> None:
        """Deux modes d'authentification simultanés sont interdits."""
        env = {
            "ALTERED_API_KEY": "abc",
            "ALTERED_API_BEARER_TOKEN": "xyz",
        }
        with pytest.raises(AlteredConfigError, match="both"):
            load_config_from_env(env)

    def test_invalid_numeric_does_not_echo_secret(self) -> None:
        """Une erreur de conversion ne doit pas reprendre une valeur secrète."""
        env = {"ALTERED_API_TIMEOUT_SECONDS": "not-a-number"}
        with pytest.raises(AlteredConfigError) as excinfo:
            load_config_from_env(env)
        msg = str(excinfo.value)
        assert "not-a-number" not in msg

    def test_optional_env_fields(self) -> None:
        """Les champs optionnels d'en-tête et d'Open Data sont pris en compte."""
        env = {
            "ALTERED_API_KEY": "k",
            "ALTERED_API_KEY_HEADER": "X-Custom",
            "ALTERED_API_KEY_QUERY_PARAM": "qkey",
            "ALTERED_API_OPEN_DATA_URL": "https://open.example.com/data",
        }
        cfg = load_config_from_env(env)
        assert cfg.api_key_header_name == "X-Custom"
        assert cfg.api_key_query_param == "qkey"
        assert cfg.open_data_url == "https://open.example.com/data"

    def test_parses_retry_jitter(self) -> None:
        """``ALTERED_API_RETRY_JITTER`` pilote le jitter du socle."""
        cfg = load_config_from_env({"ALTERED_API_RETRY_JITTER": "0"})
        assert cfg.retry_jitter is False
        cfg_on = load_config_from_env({"ALTERED_API_RETRY_JITTER": "on"})
        assert cfg_on.retry_jitter is True

    def test_invalid_retry_jitter_string(self) -> None:
        """Une valeur booléenne invalide est refusée."""
        with pytest.raises(AlteredConfigError, match="ALTERED_API_RETRY_JITTER"):
            load_config_from_env({"ALTERED_API_RETRY_JITTER": "maybe"})

    def test_invalid_retry_int_message(self) -> None:
        """Une valeur entière invalide produit une erreur typée."""
        with pytest.raises(AlteredConfigError, match="ALTERED_API_RETRY_MAX_ATTEMPTS"):
            load_config_from_env({"ALTERED_API_RETRY_MAX_ATTEMPTS": "x"})

    def test_invalid_locale_string(self) -> None:
        """Une locale inconnue est refusée."""
        with pytest.raises(AlteredConfigError, match="unsupported locale"):
            load_config_from_env({"ALTERED_API_LOCALE": "zz-ZZ"})

    def test_user_agent_from_env(self) -> None:
        """``ALTERED_API_USER_AGENT`` est appliqué."""
        cfg = load_config_from_env({"ALTERED_API_USER_AGENT": "  custom-ua  "})
        assert cfg.user_agent == "custom-ua"

    def test_bearer_only_from_env(self) -> None:
        """Un bearer seul est accepté."""
        cfg = load_config_from_env({"ALTERED_API_BEARER_TOKEN": "baobab-api-token"})
        assert cfg.bearer_token == "baobab-api-token"
        assert cfg.api_key is None

    def test_explicit_none_uses_process_environ(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``env=None`` lit le mapping du processus via ``os.environ``."""
        monkeypatch.setenv("ALTERED_API_BASE_URL", "https://from-os.example.com")
        cfg = load_config_from_env(None)
        assert cfg.base_url == "https://from-os.example.com"
