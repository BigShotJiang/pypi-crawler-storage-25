"""Tests des bornes retry / jitter sur ``AlteredApiConfig``."""

from __future__ import annotations

import pytest

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.config.altered_network_parameter_validator import (
    MAX_RETRY_ATTEMPTS,
)
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class TestAlteredApiConfigRetryLimits:
    """Validation retry / jitter au-delà des cas généraux de ``AlteredApiConfig``."""

    def test_retry_max_attempts_upper_bound(self) -> None:
        """Un nombre de tentatives excessif est refusé (pas de retry quasi infini)."""
        with pytest.raises(AlteredConfigError, match="retry_max_attempts"):
            AlteredApiConfig(retry_max_attempts=MAX_RETRY_ATTEMPTS + 1)

    def test_retry_jitter_must_be_bool(self) -> None:
        """``retry_jitter`` refuse les types non booléens."""
        with pytest.raises(AlteredConfigError, match="retry_jitter must be bool"):
            AlteredApiConfig(retry_jitter=object())  # type: ignore[arg-type]
