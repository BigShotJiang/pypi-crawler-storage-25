"""Tests de métadonnées du packaging (PEP 621)."""

from __future__ import annotations

import tomllib
from pathlib import Path


class TestPackageMetadata:
    """Valide les métadonnées déclarées dans ``pyproject.toml``."""

    @staticmethod
    def _load_pyproject(repo_root: Path) -> dict[str, object]:
        """Charge le ``pyproject.toml`` à la racine du dépôt.

        :param repo_root: Répertoire racine du dépôt.
        :return: Données TOML du projet.
        """
        path = repo_root / "pyproject.toml"
        data = tomllib.loads(path.read_text(encoding="utf-8"))
        assert isinstance(data, dict)
        return data

    def test_project_name_is_baobab_altered_api_distribution(self) -> None:
        """Le nom de distribution PyPI doit être ``baobab-altered-api``."""
        repo_root = Path(__file__).resolve().parents[3]
        project = self._load_pyproject(repo_root)["project"]
        assert isinstance(project, dict)
        assert project["name"] == "baobab-altered-api"

    def test_runtime_dependency_baobab_api_call(self) -> None:
        """La dépendance ``baobab-api-call`` doit être contrainte en runtime."""
        repo_root = Path(__file__).resolve().parents[3]
        project = self._load_pyproject(repo_root)["project"]
        assert isinstance(project, dict)
        deps = project["dependencies"]
        assert isinstance(deps, list)
        normalized = [str(item).replace(" ", "") for item in deps]
        assert "baobab-api-call>=2.1.0,<3.0" in normalized

    def test_runtime_dependency_httpx(self) -> None:
        """``httpx`` doit être déclaré conformément à la user story US-001."""
        repo_root = Path(__file__).resolve().parents[3]
        project = self._load_pyproject(repo_root)["project"]
        assert isinstance(project, dict)
        deps = project["dependencies"]
        assert isinstance(deps, list)
        normalized = [str(item).replace(" ", "") for item in deps]
        assert any(
            item.startswith("httpx>=0.27") and "<1" in item for item in normalized
        )

    def test_requires_python_is_at_least_3_11(self) -> None:
        """Le projet doit cibler Python 3.11 ou supérieur."""
        repo_root = Path(__file__).resolve().parents[3]
        project = self._load_pyproject(repo_root)["project"]
        assert isinstance(project, dict)
        assert project["requires-python"] == ">=3.11"

    def test_py_typed_exists_in_source_tree(self) -> None:
        """Le marqueur PEP 561 doit être présent dans l’arborescence source."""
        repo_root = Path(__file__).resolve().parents[3]
        marker = repo_root / "src" / "baobab_altered_api" / "py.typed"
        assert marker.is_file()
