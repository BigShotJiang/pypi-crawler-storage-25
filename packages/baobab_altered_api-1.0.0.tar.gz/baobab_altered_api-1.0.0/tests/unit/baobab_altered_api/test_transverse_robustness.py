"""Tests transverses de robustesse et sécurité (FEAT-011 / BL-011-006)."""

from __future__ import annotations

import logging
from pathlib import Path

import pytest
from baobab_api_call import ApiRequest, ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_rate_limit_error import AlteredRateLimitError
from baobab_altered_api.internal.altered_api_logger import AlteredApiLogger
from baobab_altered_api.transports.altered_sync_transport import AlteredSyncTransport
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)
from tests.fakes.fake_sync_transport import FakeSyncTransport


class TestTransverseRobustness:
    """Non-régression transverse : secrets, config, erreurs HTTP et logging."""

    def test_repr_and_str_mask_api_key_and_bearer(self) -> None:
        """Les représentations textuelles de la config n'exposent pas les secrets."""
        sentinel_key = "phf_transverse_api_key_never_in_repr_aaaa"
        sentinel_bearer = "phf_transverse_bearer_never_in_repr_bbbb"
        cfg_key = AlteredApiConfig(
            base_url="https://api.test.example",
            api_key=sentinel_key,
        )
        cfg_bearer = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token=sentinel_bearer,
        )
        for cfg in (cfg_key, cfg_bearer):
            text = f"{cfg!r}{cfg!s}"
            assert sentinel_key not in text
            assert sentinel_bearer not in text
            assert "<redacted>" in text

    def test_altered_client_http_config_propagates_timeout_retry_and_pacing(
        self,
    ) -> None:
        """La façade aligne le socle sur timeout, retry et middlewares locaux."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="phf_transverse_token_only_for_auth_cccc",
            timeout_seconds=41.0,
            retry_max_attempts=6,
            retry_backoff_seconds=1.25,
            retry_jitter=False,
            rate_limit_per_second=7.5,
        )
        fake = FakeSyncTransport()
        fake.set_default(ApiResponse(200, b"{}"))
        with AlteredClient(cfg, transport=fake) as client:
            api_cfg = client.http.config
        assert api_cfg.timeout_seconds == 41.0
        assert api_cfg.retry_policy is not None
        assert api_cfg.retry_policy.max_attempts == 6
        assert api_cfg.retry_policy.backoff_initial == pytest.approx(1.25)
        assert api_cfg.retry_policy.jitter is False
        assert len(api_cfg.middlewares) == 1

        with AlteredClient(cfg) as bare:
            transport = bare.http.transport
            assert isinstance(transport, AlteredSyncTransport)
            assert getattr(transport, "_default_timeout_seconds") == 41.0

    def test_response_handler_maps_429_to_altered_rate_limit_error(self) -> None:
        """Le handler transport convertit 429 vers ``AlteredRateLimitError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/limited")
        resp = ApiResponse(
            429,
            b"{}",
            request=req,
            headers={"Retry-After": "120"},
        )
        with pytest.raises(AlteredRateLimitError) as ctx:
            AlteredTransportResponseHandler.json_payload_or_raise(resp)
        assert ctx.value.http_status == 429
        assert ctx.value.retry_after == 120.0
        assert ctx.value.path == req.path

    def test_http_log_excludes_sensitive_query_value(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Les journaux HTTP outbound ne répètent pas les paramètres sensibles."""
        sentinel = "phf_transverse_log_secret_dddd"
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/items",
            params={"api_key": sentinel},
        )
        resp = ApiResponse(200, b"{}", None, "{}", 0.02, request=req)
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            AlteredApiLogger.log_http_roundtrip(req, resp)
        assert sentinel not in caplog.text
        assert "http_outbound" in caplog.text

    def test_public_package_init_avoids_global_logging_setup(self) -> None:
        """L'import racine ne force pas ``basicConfig`` ni ``dictConfig`` dans le code."""
        import baobab_altered_api as pkg

        init_path = Path(pkg.__file__)
        text = init_path.read_text(encoding="utf-8")
        assert "basicConfig(" not in text
        assert "fileConfig(" not in text
        assert "dictConfig(" not in text
