"""Tests de ``OpenDataReader``."""

from __future__ import annotations

from pathlib import Path

from baobab_altered_api.resources.open_data_reader import OpenDataReader


class TestOpenDataReader:
    """Lecture fichier Open Data local."""

    def test_from_path_minimal_fixture(self) -> None:
        """Charge ``open_data_minimal.json``."""
        path = (
            Path(__file__).resolve().parents[3]
            / "fixtures"
            / "open_data"
            / "open_data_minimal.json"
        )
        snap = OpenDataReader.from_path(path)
        assert snap.version == 1
        assert len(snap.cards) == 2
        found = snap.card_by_ref("od-card-1")
        assert found is not None
        assert found.name == "Open Data Card One"
