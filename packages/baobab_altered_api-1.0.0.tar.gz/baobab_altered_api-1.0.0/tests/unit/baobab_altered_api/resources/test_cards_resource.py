"""Tests de ``CardsResource``."""

from __future__ import annotations

import json

from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.card_search_filters import CardSearchFilters
from tests.fakes.fake_sync_transport import FakeSyncTransport
from tests.fixtures.json_loader import load_json_fixture


def _client_with_fake() -> tuple[AlteredClient, FakeSyncTransport]:
    cfg = AlteredApiConfig(
        base_url="https://api.test.example",
        bearer_token="baobab-api-token",
    )
    fake = FakeSyncTransport()
    client = AlteredClient(cfg, transport=fake)
    return client, fake


def _register_json(
    fake: FakeSyncTransport,
    method: str,
    path: str,
    fixture_name: str,
) -> None:
    body = json.dumps(load_json_fixture(fixture_name)).encode()
    fake.register(
        method,
        f"https://api.test.example{path}",
        ApiResponse(200, body),
    )


class TestCardsResource:
    """Recherche et détail carte via transport factice."""

    def test_search_uses_cards_path(self) -> None:
        """GET liste cartes avec fixture ``page_cards``."""
        client, fake = _client_with_fake()
        _register_json(fake, "GET", AlteredApiPaths.CARDS, "page_cards.json")
        page = client.cards.search()
        assert len(page.items) == 2
        assert page.items[0].ref.value == "fixture-card-a"
        assert page.next_cursor == "fixture-cursor-page-2"
        assert fake.requests[0].path.endswith(AlteredApiPaths.CARDS)

    def test_search_with_filters_query_params(self) -> None:
        """Les filtres deviennent des query params."""
        client, fake = _client_with_fake()
        fake.set_default(ApiResponse(200, b'{"items":[]}'))
        filters = CardSearchFilters(name="foo", faction="ax")
        client.cards.search(filters)
        params = fake.requests[0].params or {}
        assert params.get("name") == "foo"
        assert params.get("faction") == "ax"

    def test_get_by_id(self) -> None:
        """Détail carte."""
        client, fake = _client_with_fake()
        _register_json(
            fake,
            "GET",
            AlteredApiPaths.card_by_id("fixture-card-a"),
            "card_minimal.json",
        )
        card = client.cards.get_by_id("fixture-card-a")
        assert card.ref.value == "fixture-card-minimal-01"
