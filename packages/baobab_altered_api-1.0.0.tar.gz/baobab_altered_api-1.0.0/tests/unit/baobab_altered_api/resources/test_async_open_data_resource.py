"""Tests de ``AsyncOpenDataResource``."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_api_error import AlteredApiError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from tests.fakes.fake_async_transport import FakeAsyncTransport
from tests.fixtures.json_loader import load_json_fixture


@pytest.mark.asyncio
class TestAsyncOpenDataResource:
    """Miroir async Open Data."""

    async def test_fetch_snapshot_and_iter_cards(self) -> None:
        """Téléchargement async et parcours des cartes."""
        url = "https://open.example.com/async.json"
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            open_data_url=url,
        )
        fake = FakeAsyncTransport()
        payload = load_json_fixture("minimal_snapshot.json", subdir="open_data")
        fake.register("GET", url, ApiResponse(200, json.dumps(payload).encode()))
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            snap = await client.open_data.fetch_snapshot()
            cards = []
            async for card in client.open_data.iter_cards():
                cards.append(card)
        assert len(snap.sets) == 1
        assert len(cards) == 2

    async def test_load_from_file_sync_path(self) -> None:
        """Lecture locale sans réseau."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeAsyncTransport()
        path = (
            Path(__file__).resolve().parents[3]
            / "fixtures"
            / "open_data"
            / "open_data_minimal.json"
        )
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            snap = client.open_data.load_from_file(path)
        assert len(snap.cards) == 2

    async def test_save_snapshot_async(self, tmp_path: Path) -> None:
        """``save_snapshot`` async écrit le fichier."""
        url = "https://open.example.com/save.json"
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            open_data_url=url,
        )
        fake = FakeAsyncTransport()
        fake.register("GET", url, ApiResponse(200, b'{"version":1,"cards":[]}'))
        dest = tmp_path / "out.json"
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            path = await client.open_data.save_snapshot(dest)
        assert path.exists()

    async def test_fetch_http_error(self) -> None:
        """Erreur HTTP sur fetch async."""
        url = "https://open.example.com/err.json"
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            open_data_url=url,
        )
        fake = FakeAsyncTransport()
        fake.register("GET", url, ApiResponse(404, b"{}"))
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            with pytest.raises(AlteredOpenDataDownloadError, match="404"):
                await client.open_data.fetch_snapshot()

    async def test_iter_without_snapshot_raises(self) -> None:
        """Erreur si aucun snapshot chargé."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeAsyncTransport()
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            with pytest.raises(AlteredApiError, match="not loaded"):
                async for _ in client.open_data.iter_cards():
                    pass
