"""Tests d'itération paginée cartes."""

from __future__ import annotations

import json

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.card_search_filters import CardSearchFilters
from tests.fakes.fake_sync_transport import FakeSyncTransport
from tests.fixtures.json_loader import load_json_fixture


class TestCardsPagination:
    """``iter_pages`` avec plafond."""

    def test_iter_pages_two_pages(self) -> None:
        """Deux pages via curseur puis arrêt."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
        )
        fake = FakeSyncTransport()
        base = f"https://api.test.example{AlteredApiPaths.CARDS}"
        page1 = load_json_fixture("page_cards.json")
        page2 = {
            "items": [{"id": "fixture-card-c", "name": "C"}],
            "pagination": {"hasNext": False},
        }
        fake.register(
            "GET",
            base,
            ApiResponse(200, json.dumps(page1).encode()),
            params={"limit": "20"},
        )
        fake.register(
            "GET",
            base,
            ApiResponse(200, json.dumps(page2).encode()),
            params={"cursor": "fixture-cursor-page-2", "limit": "20"},
        )
        client = AlteredClient(cfg, transport=fake)
        pages = list(
            client.cards.iter_pages(
                CardSearchFilters(pagination=AlteredPaginationParams()),
                max_pages=2,
            )
        )
        assert len(pages) == 2
        assert pages[1].items[0].ref.value == "fixture-card-c"

    def test_max_pages_invalid(self) -> None:
        """``max_pages`` < 1 interdit."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        client = AlteredClient(cfg, transport=FakeSyncTransport())
        with pytest.raises(ValueError, match="max_pages"):
            list(client.cards.iter_pages(max_pages=0))
