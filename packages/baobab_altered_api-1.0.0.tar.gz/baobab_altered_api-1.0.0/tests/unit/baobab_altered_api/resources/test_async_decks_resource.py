"""Tests dédiés de ``AsyncDecksResource``."""

from __future__ import annotations

import json

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.async_decks_resource import AsyncDecksResource
from tests.fakes.fake_async_transport import FakeAsyncTransport
from tests.fixtures.json_loader import load_json_fixture


@pytest.mark.asyncio
class TestAsyncDecksResource:
    """Contrat async decks (BL-009-004)."""

    async def test_get_by_id_maps_deck(self) -> None:
        """GET factice renvoie un ``AlteredDeck`` typé."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeAsyncTransport()
        deck_id = "async-deck-42"
        path = f"https://api.test.example{AlteredApiPaths.deck_by_id(deck_id)}"
        fake.register(
            "GET",
            path,
            ApiResponse(
                200, json.dumps(load_json_fixture("deck_minimal.json")).encode()
            ),
        )
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            deck = await client.decks.get_by_id(deck_id)
        assert deck.ref.value == "fixture-deck-01"
        assert len(deck.cards) == 1
        assert fake.requests[-1].method == "GET"

    async def test_get_by_id_invalid_root_raises(self) -> None:
        """Racine JSON non mapping -> ``AlteredMappingError``."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeAsyncTransport()
        deck_id = "bad-root"
        path = f"https://api.test.example{AlteredApiPaths.deck_by_id(deck_id)}"
        fake.register("GET", path, ApiResponse(200, b'["not","a","mapping"]'))
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            resource: AsyncDecksResource = client.decks
            with pytest.raises(AlteredMappingError, match="mapping"):
                await resource.get_by_id(deck_id)
