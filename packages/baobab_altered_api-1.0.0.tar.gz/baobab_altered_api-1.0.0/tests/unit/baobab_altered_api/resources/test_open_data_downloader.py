"""Tests de ``OpenDataDownloader`` et ``OpenDataAccess``."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from baobab_altered_api.resources.open_data_downloader import OpenDataDownloader
from tests.fakes.fake_sync_transport import FakeSyncTransport
from tests.fixtures.json_loader import load_json_fixture


def _client_with_open_data_url() -> tuple[AlteredClient, FakeSyncTransport, str]:
    url = "https://open.example.com/export.json"
    cfg = AlteredApiConfig(
        base_url="https://api.test.example",
        open_data_url=url,
        retry_max_attempts=1,
    )
    fake = FakeSyncTransport()
    return AlteredClient(cfg, transport=fake), fake, url


class TestOpenDataDownloader:
    """Téléchargement explicite sans réseau réel."""

    def test_download_writes_file(self, tmp_path: Path) -> None:
        """Un GET factice écrit le JSON sur disque."""
        client, fake, url = _client_with_open_data_url()
        payload = load_json_fixture("open_data_minimal.json", subdir="open_data")
        fake.register("GET", url, ApiResponse(200, json.dumps(payload).encode()))
        dest = tmp_path / "export.json"
        written = client.open_data.download_to(dest)
        assert written == dest.resolve()
        assert dest.exists()
        loaded = json.loads(dest.read_text(encoding="utf-8"))
        assert loaded["version"] == 1

    def test_existing_file_without_overwrite_raises(self, tmp_path: Path) -> None:
        """Fichier existant sans ``overwrite`` -> erreur contrôlée."""
        client, fake, url = _client_with_open_data_url()
        fake.register("GET", url, ApiResponse(200, b'{"version":1,"cards":[]}'))
        dest = tmp_path / "export.json"
        dest.write_text("{}", encoding="utf-8")
        with pytest.raises(AlteredOpenDataDownloadError, match="already exists"):
            client.open_data.download_to(dest)

    def test_http_error_raises(self, tmp_path: Path) -> None:
        """Réponse HTTP en erreur -> ``AlteredOpenDataDownloadError``."""
        client, fake, url = _client_with_open_data_url()
        fake.register("GET", url, ApiResponse(404, b'{"error":"not_found"}'))
        with pytest.raises(AlteredOpenDataDownloadError, match="404"):
            client.open_data.download_to(tmp_path / "out.json")

    def test_missing_open_data_url_raises(self, tmp_path: Path) -> None:
        """URL absente de la configuration -> ``AlteredConfigError``."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeSyncTransport()
        client = AlteredClient(cfg, transport=fake)
        with pytest.raises(AlteredConfigError, match="open_data_url"):
            client.open_data.download_to(tmp_path / "out.json")

    def test_overwrite_replaces_file(self, tmp_path: Path) -> None:
        """``overwrite=True`` remplace un fichier existant."""
        client, fake, url = _client_with_open_data_url()
        fake.register("GET", url, ApiResponse(200, b'{"version":2,"cards":[]}'))
        dest = tmp_path / "export.json"
        dest.write_text("old", encoding="utf-8")
        client.open_data.download_to(dest, overwrite=True)
        assert json.loads(dest.read_text(encoding="utf-8"))["version"] == 2

    def test_max_bytes_guard(self, tmp_path: Path) -> None:
        """Export trop volumineux -> erreur avant écriture."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            open_data_url="https://open.example.com/big.json",
        )
        fake = FakeSyncTransport()
        client = AlteredClient(cfg, transport=fake)
        huge = {"cards": [{"id": "x", "payload": "z" * 2000}]}
        fake.register(
            "GET",
            cfg.open_data_url or "",
            ApiResponse(200, json.dumps(huge).encode()),
        )
        downloader = OpenDataDownloader(cfg, client.http, max_bytes=64)
        with pytest.raises(AlteredOpenDataDownloadError, match="max_bytes"):
            downloader.download_to(tmp_path / "big.json")
