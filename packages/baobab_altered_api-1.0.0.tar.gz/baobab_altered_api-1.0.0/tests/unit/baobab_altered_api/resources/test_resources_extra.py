"""Couverture complémentaire ressources et filtres."""

from __future__ import annotations

import json

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.card_search_filters import CardSearchFilters
from tests.fakes.fake_sync_transport import FakeSyncTransport
from tests.fixtures.json_loader import load_json_fixture


class TestResourcesExtra:
    """Branches restantes."""

    def test_card_filters_all_fields(self) -> None:
        """Tous les filtres sérialisés."""
        f = CardSearchFilters(
            name="n",
            faction="f",
            set_code="s",
            rarity="r",
            card_type="t",
            locale="fr-FR",
            sort_field="name",
            sort_descending=True,
        )
        p = f.to_query_params()
        assert p["order"] == "desc"

    def test_iter_cards_flattens(self) -> None:
        """``iter_cards`` aplatit les pages."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeSyncTransport()
        base = f"https://api.test.example{AlteredApiPaths.CARDS}"
        body = json.dumps(load_json_fixture("page_cards.json")).encode()
        fake.register("GET", base, ApiResponse(200, body), params={"limit": "20"})
        client = AlteredClient(cfg, transport=fake)
        cards = list(client.cards.iter_cards(max_pages=1))
        assert len(cards) == 2

    def test_referentials_sets_and_rarities(self) -> None:
        """Autres listes référentiels."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeSyncTransport()
        for path_suffix in (
            AlteredApiPaths.SETS,
            AlteredApiPaths.RARITIES,
            AlteredApiPaths.CARD_TYPES,
        ):
            url = f"https://api.test.example{path_suffix}"
            fake.register(
                "GET",
                url,
                ApiResponse(200, b'{"items":[{"id":"x","code":"c","name":"N"}]}'),
            )
        client = AlteredClient(cfg, transport=fake)
        assert len(client.referentials.list_sets()) == 1
        assert len(client.referentials.list_rarities()) == 1
        assert len(client.referentials.list_card_types()) == 1

    def test_cards_list_root_array(self) -> None:
        """Réponse racine tableau."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeSyncTransport()
        base = f"https://api.test.example{AlteredApiPaths.CARDS}"
        arr = [{"id": "only-one"}]
        fake.register("GET", base, ApiResponse(200, json.dumps(arr).encode()))
        page = AlteredClient(cfg, transport=fake).cards.search()
        assert len(page.items) == 1
