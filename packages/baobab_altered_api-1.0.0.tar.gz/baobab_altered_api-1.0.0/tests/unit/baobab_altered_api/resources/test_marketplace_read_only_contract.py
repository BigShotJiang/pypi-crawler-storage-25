"""Contrat lecture seule marketplace (aucune opération transactionnelle)."""

from __future__ import annotations

import inspect

from baobab_altered_api.resources.async_marketplace_resource import (
    AsyncMarketplaceResource,
)
from baobab_altered_api.resources.marketplace_resource import MarketplaceResource

_FORBIDDEN_METHODS: frozenset[str] = frozenset(
    {
        "buy",
        "sell",
        "create",
        "update",
        "delete",
        "checkout",
        "purchase",
        "place_order",
    }
)


def _public_callables(cls: type[object]) -> set[str]:
    return {
        name
        for name, member in inspect.getmembers(cls)
        if not name.startswith("_") and callable(member)
    }


class TestMarketplaceReadOnlyContract:
    """BL-010-005 : pas de surface transactionnelle publique."""

    def test_sync_resource_has_no_forbidden_methods(self) -> None:
        """``MarketplaceResource`` n'expose pas d'API d'achat/vente."""
        names = _public_callables(MarketplaceResource)
        assert _FORBIDDEN_METHODS.isdisjoint(names)
        assert "list_offers" in names

    def test_async_resource_has_no_forbidden_methods(self) -> None:
        """``AsyncMarketplaceResource`` reste lecture seule."""
        names = _public_callables(AsyncMarketplaceResource)
        assert _FORBIDDEN_METHODS.isdisjoint(names)
        assert "list_offers" in names
