"""Tests decks et marketplace (sync)."""

from __future__ import annotations

import json

from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from tests.fakes.fake_sync_transport import FakeSyncTransport
from tests.fixtures.json_loader import load_json_fixture


def _client() -> tuple[AlteredClient, FakeSyncTransport]:
    cfg = AlteredApiConfig(
        base_url="https://api.test.example",
        bearer_token="baobab-api-token",
    )
    fake = FakeSyncTransport()
    return AlteredClient(cfg, transport=fake), fake


class TestDecksAndMarketplace:
    """Lecture deck et offres marketplace."""

    def test_deck_get_by_id(self) -> None:
        """Mappe un deck minimal."""
        client, fake = _client()
        path = f"https://api.test.example{AlteredApiPaths.deck_by_id('fixture-deck-01')}"
        body = json.dumps(load_json_fixture("deck_minimal.json")).encode()
        fake.register("GET", path, ApiResponse(200, body))
        deck = client.decks.get_by_id("fixture-deck-01")
        assert deck.ref.value == "fixture-deck-01"
        assert len(deck.cards) == 1

    def test_marketplace_list_offers(self) -> None:
        """Liste d'offres factices."""
        client, fake = _client()
        base = f"https://api.test.example{AlteredApiPaths.MARKETPLACE_OFFERS}"
        payload = {"items": [load_json_fixture("market_offer_minimal.json")]}
        fake.register("GET", base, ApiResponse(200, json.dumps(payload).encode()))
        offers = client.marketplace.list_offers()
        assert len(offers) == 1
        assert offers[0].ref.value == "fixture-offer-01"
