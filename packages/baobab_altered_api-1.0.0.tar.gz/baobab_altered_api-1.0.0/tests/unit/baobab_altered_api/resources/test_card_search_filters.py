"""Tests de ``CardSearchFilters``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams
from baobab_altered_api.resources.card_search_filters import CardSearchFilters


class TestCardSearchFilters:
    """Sérialisation des filtres carte."""

    def test_empty_filters_only_pagination(self) -> None:
        """Pagination seule dans les params."""
        f = CardSearchFilters(pagination=AlteredPaginationParams(limit=10, page=1))
        params = f.to_query_params()
        assert params["limit"] == "10"
        assert params["page"] == "1"

    def test_optional_fields_ignored(self) -> None:
        """Valeurs ``None`` absentes."""
        assert CardSearchFilters().to_query_params() == {}

    def test_invalid_sort_rejected(self) -> None:
        """Tri hors liste blanche refusé."""
        with pytest.raises(ValueError, match="sort_field"):
            CardSearchFilters(sort_field="unknown_field")
