"""Tests ``AsyncCardsResource``."""

from __future__ import annotations

import json

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from tests.fakes.fake_async_transport import FakeAsyncTransport
from tests.fixtures.json_loader import load_json_fixture


@pytest.mark.asyncio
class TestAsyncCardsResource:
    """Recherche async."""

    async def test_search_async(self) -> None:
        """GET async liste cartes."""
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            bearer_token="baobab-api-token",
        )
        fake = FakeAsyncTransport()
        base = f"https://api.test.example{AlteredApiPaths.CARDS}"
        fake.register(
            "GET",
            base,
            ApiResponse(200, json.dumps(load_json_fixture("page_cards.json")).encode()),
        )
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            page = await client.cards.search()
        assert len(page.items) == 2
