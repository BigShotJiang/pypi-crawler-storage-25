"""Tests de ``OpenDataResource`` (US-016 / cahier des charges)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_api_error import AlteredApiError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from baobab_altered_api.resources.open_data_resource import OpenDataResource
from tests.fakes.fake_sync_transport import FakeSyncTransport
from tests.fixtures.json_loader import load_json_fixture


def _fixture_path(name: str) -> Path:
    return Path(__file__).resolve().parents[3] / "fixtures" / "open_data" / name


class TestOpenDataResource:
    """Contrat synchrone Open Data."""

    def test_load_from_file_hierarchy_and_iter_cards(self) -> None:
        """Parcours hiérarchique Set → Faction → Carte."""
        resource = OpenDataResource(
            AlteredApiConfig(base_url="https://api.test.example"),
            _http_without_network(),
        )
        snap = resource.load_from_file(_fixture_path("minimal_snapshot.json"))
        assert snap.version == 2
        assert len(snap.sets) == 1
        assert snap.sets[0].expansion.code == "CORE"
        assert len(snap.sets[0].factions[0].cards) == 2
        cards = list(resource.iter_cards())
        assert len(cards) == 2
        assert cards[0].ref.value == "hier-001"

    def test_fetch_snapshot_from_fake_transport(self) -> None:
        """``fetch_snapshot`` mappe une réponse GET factice."""
        url = "https://open.example.com/snap.json"
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            open_data_url=url,
            retry_max_attempts=1,
        )
        fake = FakeSyncTransport()
        payload = load_json_fixture("minimal_snapshot.json", subdir="open_data")
        fake.register("GET", url, ApiResponse(200, json.dumps(payload).encode()))
        client = AlteredClient(cfg, transport=fake)
        snap = client.open_data.fetch_snapshot()
        assert len(snap.cards) == 2

    def test_iter_cards_without_load_raises(self) -> None:
        """Itération sans snapshot chargé -> erreur typée."""
        resource = OpenDataResource(
            AlteredApiConfig(base_url="https://api.test.example"),
            _http_without_network(),
        )
        with pytest.raises(AlteredApiError, match="not loaded"):
            list(resource.iter_cards())

    def test_save_snapshot_writes_file(self, tmp_path: Path) -> None:
        """``save_snapshot`` alias téléchargement explicite."""
        url = "https://open.example.com/out.json"
        cfg = AlteredApiConfig(
            base_url="https://api.test.example",
            open_data_url=url,
            retry_max_attempts=1,
        )
        fake = FakeSyncTransport()
        fake.register("GET", url, ApiResponse(200, b'{"version":1,"cards":[]}'))
        client = AlteredClient(cfg, transport=fake)
        dest = tmp_path / "snap.json"
        written = client.open_data.save_snapshot(dest)
        assert written == dest.resolve()

    def test_oversized_local_file_rejected(self, tmp_path: Path) -> None:
        """Fichier local trop volumineux avant parsing."""
        path = tmp_path / "big.json"
        path.write_text('{"cards":[]}', encoding="utf-8")
        resource = OpenDataResource(
            AlteredApiConfig(base_url="https://api.test.example"),
            _http_without_network(),
            max_bytes=4,
        )
        with pytest.raises(AlteredOpenDataDownloadError, match="max_bytes"):
            resource.load_from_file(path)


def _http_without_network() -> object:
    """Client HTTP factice minimal (lecture fichier seulement)."""
    cfg = AlteredApiConfig(base_url="https://api.test.example", retry_max_attempts=1)
    fake = FakeSyncTransport()
    return AlteredClient(cfg, transport=fake).http
