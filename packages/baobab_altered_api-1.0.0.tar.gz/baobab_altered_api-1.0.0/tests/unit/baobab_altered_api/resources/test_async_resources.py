"""Tests ressources async (decks, référentiels, marketplace)."""

from __future__ import annotations

import json

import pytest
from baobab_api_call import ApiResponse

from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from tests.fakes.fake_async_transport import FakeAsyncTransport
from tests.fixtures.json_loader import load_json_fixture


@pytest.mark.asyncio
class TestAsyncResources:
    """Couverture async complémentaire."""

    async def test_async_deck_and_referentials(self) -> None:
        """Deck et factions en async."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeAsyncTransport()
        deck_path = f"https://api.test.example{AlteredApiPaths.deck_by_id('d1')}"
        fake.register(
            "GET",
            deck_path,
            ApiResponse(200, json.dumps(load_json_fixture("deck_minimal.json")).encode()),
        )
        fac_path = f"https://api.test.example{AlteredApiPaths.FACTIONS}"
        fake.register(
            "GET",
            fac_path,
            ApiResponse(200, b'{"items":[{"id":"f1","name":"F"}]}'),
        )
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            deck = await client.decks.get_by_id("d1")
            factions = await client.referentials.list_factions()
        assert deck.ref.value == "fixture-deck-01"
        assert len(factions) == 1

    async def test_async_marketplace(self) -> None:
        """Offres marketplace async."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeAsyncTransport()
        path = f"https://api.test.example{AlteredApiPaths.MARKETPLACE_OFFERS}"
        fake.register("GET", path, ApiResponse(200, b'{"items":[]}'))
        async with AsyncAlteredClient(cfg, transport=fake) as client:
            offers = await client.marketplace.list_offers()
        assert offers == ()
