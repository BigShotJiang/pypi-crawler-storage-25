"""Tests ``ReferentialsResource``."""

from __future__ import annotations

import json

from baobab_api_call import ApiResponse

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from tests.fakes.fake_sync_transport import FakeSyncTransport


class TestReferentialsResource:
    """Listes référentiels via fake."""

    def test_list_factions(self) -> None:
        """GET factions."""
        cfg = AlteredApiConfig(base_url="https://api.test.example")
        fake = FakeSyncTransport()
        path = f"https://api.test.example{AlteredApiPaths.FACTIONS}"
        body = json.dumps({"items": [{"id": "f1", "name": "Faction One"}]}).encode()
        fake.register("GET", path, ApiResponse(200, body))
        client = AlteredClient(cfg, transport=fake)
        factions = client.referentials.list_factions()
        assert len(factions) == 1
        assert factions[0].name == "Faction One"
