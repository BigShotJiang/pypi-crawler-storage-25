"""Tests de ``OpenDataCatalog``."""

from __future__ import annotations

from pathlib import Path

from baobab_altered_api.resources.open_data_access import OpenDataAccess
from baobab_altered_api.resources.open_data_reader import OpenDataReader
from baobab_altered_api.resources.open_data_catalog import OpenDataCatalog


class TestOpenDataCatalog:
    """Index local Open Data."""

    @staticmethod
    def _catalog() -> OpenDataCatalog:
        path = (
            Path(__file__).resolve().parents[3]
            / "fixtures"
            / "open_data"
            / "open_data_indexed.json"
        )
        return OpenDataCatalog(OpenDataReader.from_path(path))

    def test_get_card_found_and_missing(self) -> None:
        """Recherche par identifiant."""
        catalog = self._catalog()
        card = catalog.get_card("od-a1")
        assert card is not None
        assert card.name == "Alpha"
        assert catalog.get_card("missing-id") is None

    def test_list_by_set(self) -> None:
        """Filtre par code d'extension."""
        catalog = self._catalog()
        core = catalog.list_by_set("CORE")
        assert len(core) == 3
        ext = catalog.list_by_set("EXT")
        assert len(ext) == 1
        assert ext[0].ref.value == "od-b1"

    def test_list_by_faction(self) -> None:
        """Filtre par faction."""
        catalog = self._catalog()
        lyra = catalog.list_by_faction("Lyra")
        assert len(lyra) == 2
        assert catalog.list_by_faction("unknown") == ()

    def test_list_sets(self) -> None:
        """Ensembles distincts."""
        catalog = self._catalog()
        assert catalog.list_sets() == ("CORE", "EXT")

    def test_duplicate_refs_reported(self) -> None:
        """Doublon d'identifiant détecté ; dernière entrée conservée."""
        catalog = self._catalog()
        assert catalog.duplicate_refs == ("od-dup",)
        dup = catalog.get_card("od-dup")
        assert dup is not None
        assert dup.name == "Second"

    def test_catalog_from_path_helper(self) -> None:
        """``OpenDataAccess.catalog_from_path`` construit le catalogue."""
        path = (
            Path(__file__).resolve().parents[3]
            / "fixtures"
            / "open_data"
            / "open_data_minimal.json"
        )
        catalog = OpenDataAccess.catalog_from_path(path)
        assert len(catalog.snapshot.cards) == 2
