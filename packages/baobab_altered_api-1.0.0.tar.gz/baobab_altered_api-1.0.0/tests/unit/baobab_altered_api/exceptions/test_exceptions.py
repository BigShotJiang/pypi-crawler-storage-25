"""Tests de la hiérarchie d'exceptions exposée par ``baobab_altered_api.exceptions``."""

from __future__ import annotations

import pytest

from baobab_altered_api.exceptions import (
    AlteredApiError,
    AlteredAuthError,
    AlteredForbiddenError,
    AlteredJsonDecodeError,
    AlteredMappingError,
    AlteredNetworkError,
    AlteredNotFoundError,
    AlteredRateLimitError,
    AlteredServiceUnavailableError,
    AlteredTimeoutError,
    AlteredTransportError,
)


class TestAlteredApiErrorHierarchy:
    """Nouvelles exceptions BL-011-001 : héritage, attributs et messages safe."""

    @pytest.mark.parametrize(
        "exc_cls,expected_status,expected_code",
        [
            (AlteredAuthError, 401, "UNAUTHORIZED"),
            (AlteredForbiddenError, 403, "FORBIDDEN"),
            (AlteredServiceUnavailableError, 503, "SERVICE_UNAVAILABLE"),
            (AlteredTransportError, None, "TRANSPORT"),
            (AlteredMappingError, None, "MAPPING"),
        ],
    )
    def test_new_exceptions_inherit_altered_api_error(
        self,
        exc_cls: type[AlteredApiError],
        expected_status: int | None,
        expected_code: str,
    ) -> None:
        """Chaque nouvelle famille hérite de ``AlteredApiError`` avec codes attendus."""
        exc = exc_cls(path="https://api.test.example/v1/x")
        assert isinstance(exc, AlteredApiError)
        assert exc.http_status == expected_status
        assert exc.error_code == expected_code
        assert exc.path == "https://api.test.example/v1/x"

    def test_str_and_repr_exclude_sensitive_payload(self) -> None:
        """``str`` / ``repr`` ne doivent pas inventer de champs sensibles."""
        exc = AlteredForbiddenError("Access forbidden", path="/cards/1")
        text = str(exc)
        assert text == "Access forbidden"
        rep = repr(exc)
        assert "Access forbidden" in rep
        assert "secret" not in rep.lower()
        assert "authorization" not in rep.lower()

    @pytest.mark.parametrize(
        "exc_cls",
        [
            AlteredNotFoundError,
            AlteredRateLimitError,
            AlteredTimeoutError,
            AlteredNetworkError,
            AlteredJsonDecodeError,
        ],
    )
    def test_existing_altered_api_errors_still_subclasses(
        self,
        exc_cls: type[AlteredApiError],
    ) -> None:
        """Les exceptions déjà livrées restent sous ``AlteredApiError``."""
        assert issubclass(exc_cls, AlteredApiError)
