"""Tests de ``AlteredHttpError``."""

from __future__ import annotations

from baobab_api_call import ApiHTTPError

from baobab_altered_api.exceptions.altered_http_error import AlteredHttpError


class TestAlteredHttpError:
    """Vérifie la compatibilité avec les exceptions du socle."""

    def test_is_subclass_of_api_http_error(self) -> None:
        """Les appelsants peuvent intercepter ``ApiHTTPError``."""
        err = AlteredHttpError("HTTP 500", status_code=500)
        assert isinstance(err, ApiHTTPError)
