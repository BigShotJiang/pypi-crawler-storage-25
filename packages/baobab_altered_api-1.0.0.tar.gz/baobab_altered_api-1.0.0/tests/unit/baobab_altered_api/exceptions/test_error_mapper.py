"""Tests de ``ErrorMapper`` (BL-011-002)."""

from __future__ import annotations

import pytest
from baobab_api_call import ApiRequest, ApiResponse
from baobab_api_call.exceptions import ApiNetworkError, ApiTimeoutError

from baobab_altered_api.exceptions import (
    AlteredApiError,
    AlteredAuthError,
    AlteredForbiddenError,
    AlteredNetworkError,
    AlteredNotFoundError,
    AlteredRateLimitError,
    AlteredServiceUnavailableError,
    AlteredTimeoutError,
    ErrorMapper,
)


class TestErrorMapper:
    """Mapping HTTP et transport vers exceptions Altered."""

    def test_http_401_auth(self) -> None:
        """401 -> ``AlteredAuthError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(401, b"{}", request=req)
        with pytest.raises(AlteredAuthError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.http_status == 401
        assert ctx.value.path == req.path

    def test_http_403_forbidden(self) -> None:
        """403 -> ``AlteredForbiddenError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(403, b"{}", request=req)
        with pytest.raises(AlteredForbiddenError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.http_status == 403

    def test_http_404_not_found(self) -> None:
        """404 -> ``AlteredNotFoundError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/m")
        resp = ApiResponse(404, b"{}", request=req)
        with pytest.raises(AlteredNotFoundError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.http_status == 404

    def test_http_429_rate_limit(self) -> None:
        """429 -> ``AlteredRateLimitError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/l")
        resp = ApiResponse(
            429,
            b"{}",
            request=req,
            headers={"Retry-After": "60"},
        )
        with pytest.raises(AlteredRateLimitError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.retry_after == 60.0

    @pytest.mark.parametrize("code", [500, 502, 503])
    def test_http_5xx_service_unavailable(self, code: int) -> None:
        """5xx -> ``AlteredServiceUnavailableError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(code, b"upstream", request=req)
        with pytest.raises(AlteredServiceUnavailableError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.http_status == code
        assert "upstream" not in str(ctx.value).lower()

    def test_http_400_bad_request(self) -> None:
        """400 -> ``AlteredApiError`` BAD_REQUEST."""
        req = ApiRequest(method="POST", path="https://api.test.example/v1/x")
        resp = ApiResponse(400, b"{}", request=req)
        with pytest.raises(AlteredApiError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.error_code == "BAD_REQUEST"
        assert ctx.value.http_status == 400

    def test_http_408_request_timeout(self) -> None:
        """408 -> ``AlteredApiError`` REQUEST_TIMEOUT."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(408, b"{}", request=req)
        with pytest.raises(AlteredApiError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.error_code == "REQUEST_TIMEOUT"

    def test_http_409_conflict(self) -> None:
        """409 -> ``AlteredApiError`` CONFLICT."""
        req = ApiRequest(method="PUT", path="https://api.test.example/v1/x")
        resp = ApiResponse(409, b"{}", request=req)
        with pytest.raises(AlteredApiError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.error_code == "CONFLICT"

    def test_http_unknown_4xx_generic_altered_api_error(self) -> None:
        """Code 4xx non listé -> ``AlteredApiError`` HTTP_ERROR."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        resp = ApiResponse(418, b"", request=req)
        with pytest.raises(AlteredApiError) as ctx:
            ErrorMapper.raise_for_failed_response(resp)
        assert ctx.value.error_code == "HTTP_ERROR"
        assert ctx.value.http_status == 418
        assert "secret" not in str(ctx.value).lower()

    def test_transport_timeout(self) -> None:
        """``ApiTimeoutError`` -> ``AlteredTimeoutError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/slow")
        exc = ApiTimeoutError("timeout", timeout_seconds=5.0, request=req)
        with pytest.raises(AlteredTimeoutError) as ctx:
            ErrorMapper.raise_for_transport_failure(exc, req)
        assert ctx.value.path == req.path

    def test_transport_network(self) -> None:
        """``ApiNetworkError`` (hors timeout) -> ``AlteredNetworkError``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/x")
        exc = ApiNetworkError("net", cause=RuntimeError("x"), request=req)
        with pytest.raises(AlteredNetworkError) as ctx:
            ErrorMapper.raise_for_transport_failure(exc, req)
        assert ctx.value.path == req.path

    def test_transport_unknown_reraises(self) -> None:
        """Autre exception : propagation inchangée."""
        with pytest.raises(KeyError):
            ErrorMapper.raise_for_transport_failure(KeyError("k"), None)
