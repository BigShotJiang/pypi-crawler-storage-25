"""Contrats d'import public pour le package racine et ``clients``."""

from __future__ import annotations

import importlib

import baobab_altered_api
import baobab_altered_api.clients as clients_pkg
from baobab_altered_api import AsyncAlteredClient, AlteredClient
from baobab_altered_api.clients import AsyncAlteredClient as AsyncFromClients
from baobab_altered_api.clients import AlteredClient as SyncFromClients


class TestPublicExports:
    """Stabilité de ``__all__`` et chemins d'import documentés."""

    def test_clients_submodule_all_is_stable(self) -> None:
        """``baobab_altered_api.clients`` n'expose que les façades publiques."""
        assert clients_pkg.__all__ == ("AlteredClient", "AsyncAlteredClient")

    def test_clients_submodule_resolves_classes(self) -> None:
        """Les noms ``__all__`` pointent vers les classes attendues."""
        assert clients_pkg.AlteredClient is AlteredClient
        assert clients_pkg.AsyncAlteredClient is AsyncAlteredClient
        assert SyncFromClients is AlteredClient
        assert AsyncFromClients is AsyncAlteredClient

    def test_root_all_includes_clients_and_config(self) -> None:
        """Le package racine documente les symboles publics (dont les clients)."""
        expected_subset = (
            "AlteredClient",
            "AsyncAlteredClient",
            "AlteredApiConfig",
        )
        root_all = baobab_altered_api.__all__
        for name in expected_subset:
            assert name in root_all, f"missing {name!r} in __all__"

    def test_root_all_excludes_internal_client_modules(self) -> None:
        """Les helpers internes du sous-package ``clients`` ne sont pas au racine."""
        assert "TransportPortValidator" not in baobab_altered_api.__all__
        assert "ApiClientConfigAlignment" not in baobab_altered_api.__all__

    def test_clients_package_exposes_only_facade_classes(self) -> None:
        """Les helpers internes ne sont pas des attributs du package ``clients``."""
        assert not hasattr(clients_pkg, "TransportPortValidator")
        assert not hasattr(clients_pkg, "ApiClientConfigAlignment")

    def test_import_clients_does_not_construct_facade(self) -> None:
        """Importer le sous-package ne crée aucune instance de façade."""
        fresh = importlib.import_module("baobab_altered_api.clients")
        for name in fresh.__all__:
            obj = getattr(fresh, name)
            assert isinstance(obj, type)
