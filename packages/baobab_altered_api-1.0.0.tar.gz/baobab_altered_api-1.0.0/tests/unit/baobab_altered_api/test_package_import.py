"""Tests d’import du package (US-001)."""

from __future__ import annotations

from pathlib import Path

import baobab_altered_api


class TestPackageImport:
    """Vérifie les critères d’acceptation de la US-001."""

    def test_import_baobab_altered_api(self) -> None:
        """``import baobab_altered_api`` doit fonctionner."""
        assert isinstance(baobab_altered_api.__version__, str)
        assert baobab_altered_api.__version__

    def test_py_typed_marker_present(self) -> None:
        """Le fichier ``py.typed`` doit être présent à côté du package."""
        repo_root = Path(__file__).resolve().parents[3]
        marker = repo_root / "src" / "baobab_altered_api" / "py.typed"
        assert marker.is_file()

    def test_all_exports_reference_existing_attributes(self) -> None:
        """``__all__`` ne doit référencer que des attributs existants."""
        for name in baobab_altered_api.__all__:
            assert hasattr(baobab_altered_api, name), f"export manquant: {name}"
