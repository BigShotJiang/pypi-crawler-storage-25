"""Tests de ``AlteredLogRedactor``."""

from __future__ import annotations

from baobab_altered_api.internal.altered_log_redactor import AlteredLogRedactor


class TestAlteredLogRedactor:
    """Vérifie la redaction des surfaces sensibles pour les journaux."""

    def test_redact_query_params_none(self) -> None:
        """``None`` pour les paramètres de query reste ``None``."""
        assert AlteredLogRedactor.redact_query_params(None) is None

    def test_redact_http_target_relative_path_with_query(self) -> None:
        """Un chemin relatif avec ``?`` est parsé et redacté."""
        safe = AlteredLogRedactor.redact_http_target(
            "/v1/items?token=phf_super_secret_rel_path_never_logged_zzzz",
            None,
        )
        assert "phf_super_secret_rel_path_never_logged_zzzz" not in safe

    def test_redact_http_target_relative_path_without_query(self) -> None:
        """Un chemin sans query est renvoyé tel quel."""
        assert AlteredLogRedactor.redact_http_target("/v1/ping", None) == "/v1/ping"

    def test_redact_headers_masks_authorization(self) -> None:
        """Le header ``Authorization`` est masqué."""
        headers = {
            "Authorization": "Bearer example-fake-token",
            "Accept": "application/json",
        }
        red = AlteredLogRedactor.redact_headers(headers)
        assert red is not None
        assert red["Authorization"] == "<redacted>"
        assert red["Accept"] == "application/json"

    def test_redact_headers_none(self) -> None:
        """``None`` reste ``None``."""
        assert AlteredLogRedactor.redact_headers(None) is None

    def test_redact_query_params_masks_token_key(self) -> None:
        """Une clé ``token`` sensible masque la valeur."""
        params = {"token": "phf_super_secret_query_never_logged_zzzz", "page": "1"}
        red = AlteredLogRedactor.redact_query_params(params)
        assert red is not None
        assert red["token"] == "<redacted>"
        assert red["page"] == "1"

    def test_redact_query_params_bearer_value(self) -> None:
        """Une valeur ``Bearer …`` est masquée même si la clé est anodine."""
        params = {"q": "Bearer phf_super_secret_bearer_value_never_logged_zzzz"}
        red = AlteredLogRedactor.redact_query_params(params)
        assert red is not None
        assert red["q"] == "<redacted>"

    def test_redact_message_strips_bearer(self) -> None:
        """``redact_message`` retire un jeton Bearer inline."""
        raw = "failed: Bearer phf_super_secret_inline_never_logged_zzzz end"
        safe = AlteredLogRedactor.redact_message(raw)
        assert "phf_super_secret_inline_never_logged_zzzz" not in safe
        assert "Bearer <redacted>" in safe

    def test_redact_http_target_absolute_url(self) -> None:
        """Une URL absolue avec query sensible est nettoyée."""
        url = (
            "https://api.test.example/v1/cards"
            "?token=phf_super_secret_url_never_logged_zzzz"
        )
        safe = AlteredLogRedactor.redact_http_target(url, None)
        assert "phf_super_secret_url_never_logged_zzzz" not in safe
        assert "token=" in safe
        assert "redacted" in safe.lower()

    def test_redact_http_target_merges_params(self) -> None:
        """Les ``params`` logiques sont fusionnés avec la query de l'URL."""
        url = "https://api.test.example/x"
        safe = AlteredLogRedactor.redact_http_target(
            url,
            {"api_key": "phf_super_secret_param_never_logged_zzzz"},
        )
        assert "phf_super_secret_param_never_logged_zzzz" not in safe
