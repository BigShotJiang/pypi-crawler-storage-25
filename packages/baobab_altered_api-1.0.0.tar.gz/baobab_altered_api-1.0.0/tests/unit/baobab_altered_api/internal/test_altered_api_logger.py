"""Tests de ``AlteredApiLogger``."""

from __future__ import annotations

import logging
from pathlib import Path

import pytest
from baobab_api_call import ApiRequest, ApiResponse

from baobab_altered_api.internal.altered_api_logger import AlteredApiLogger


class TestAlteredApiLogger:
    """Vérifie le logger interne et les messages HTTP minimaux."""

    def test_module_does_not_invoke_basic_config(self) -> None:
        """Le module de logger ne doit pas forcer ``basicConfig``."""
        src = (
            Path(__file__).resolve().parents[4]
            / "src/baobab_altered_api/internal/altered_api_logger.py"
        )
        text = src.read_text(encoding="utf-8")
        assert "logging.basicConfig(" not in text

    def test_get_logger_name(self) -> None:
        """Le logger porte le nom attendu pour l'opt-in applicatif."""
        log = AlteredApiLogger.get_logger()
        assert log.name == "baobab_altered_api"

    def test_log_http_roundtrip_emits_info(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Un aller-retour émet une ligne structurée au niveau ``INFO``."""
        req = ApiRequest(method="GET", path="https://api.test.example/v1/ping")
        resp = ApiResponse(
            200,
            b"{}",
            headers=None,
            text="{}",
            elapsed_seconds=0.042,
            request=req,
        )
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            AlteredApiLogger.log_http_roundtrip(req, resp)
        joined = caplog.text
        assert "http_outbound" in joined
        assert "method=GET" in joined
        assert "status=200" in joined
        assert "duration_s=0.042" in joined
        assert "https://api.test.example/v1/ping" in joined

    def test_log_http_roundtrip_respects_level(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Au-dessus de ``INFO``, aucun message n'est émis par ce helper."""
        req = ApiRequest(method="GET", path="https://api.test.example/x")
        resp = ApiResponse(204, b"", None, "", None, request=req)
        with caplog.at_level(logging.WARNING, logger="baobab_altered_api"):
            AlteredApiLogger.log_http_roundtrip(req, resp)
        assert "http_outbound" not in caplog.text

    def test_log_excludes_sensitive_query_value(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """La valeur d'un paramètre sensible n'apparaît pas dans le log."""
        sentinel = "phf_super_secret_logger_never_logged_zzzz"
        req = ApiRequest(
            method="GET",
            path="https://api.test.example/v1/items",
            params={"token": sentinel},
        )
        resp = ApiResponse(200, b"{}", None, "{}", 0.01, request=req)
        with caplog.at_level(logging.INFO, logger="baobab_altered_api"):
            AlteredApiLogger.log_http_roundtrip(req, resp)
        assert sentinel not in caplog.text
