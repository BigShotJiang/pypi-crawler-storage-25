"""Tests de ``QueryParamsBuilder``."""

from __future__ import annotations

from enum import Enum

import pytest

from baobab_altered_api.internal.query_params import QueryParamsBuilder
from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams


class _SampleEnum(str, Enum):
    """Valeur fictive pour sérialisation enum."""

    ALPHA = "alpha"
    BETA = "beta"


class TestQueryParamsBuilder:
    """Sérialisation stable, pagination et tris."""

    def test_skips_none_and_blank_string(self) -> None:
        """``None`` et chaînes vides ne produisent pas d'entrée."""
        out = QueryParamsBuilder().add("a", None).add("b", "   ").add("c", "ok").build()
        assert out == {"c": "ok"}

    def test_bool_lowercase(self) -> None:
        """Booléens en ``true`` / ``false``."""
        out = QueryParamsBuilder().add("x", True).add("y", False).build()
        assert out["x"] == "true"
        assert out["y"] == "false"

    def test_int_not_bool(self) -> None:
        """Entier zéro distinct du booléen."""
        out = QueryParamsBuilder().add("n", 0).build()
        assert out["n"] == "0"

    def test_list_comma_join(self) -> None:
        """Séquences en liste séparée par des virgules."""
        out = QueryParamsBuilder().add("tags", ["a", "b", "c"]).build()
        assert out["tags"] == "a,b,c"

    def test_list_skips_none_members(self) -> None:
        """Éléments ``None`` retirés de la liste."""
        out = QueryParamsBuilder().add("ids", ["1", None, "3"]).build()
        assert out["ids"] == "1,3"

    def test_enum_uses_value(self) -> None:
        """Les :class:`enum.Enum` utilisent ``value``."""
        out = QueryParamsBuilder().add("e", _SampleEnum.BETA).build()
        assert out["e"] == "beta"

    def test_pagination_page_mode(self) -> None:
        """Pagination page + limite."""
        params = AlteredPaginationParams(limit=25, page=3)
        out = QueryParamsBuilder().add_pagination(params).build()
        assert out == {"limit": "25", "page": "3"}

    def test_pagination_cursor_mode(self) -> None:
        """Mode curseur : pas de ``page``."""
        params = AlteredPaginationParams(limit=10, cursor="tok-abc")
        out = QueryParamsBuilder().add_pagination(params).build()
        assert out == {"cursor": "tok-abc", "limit": "10"}

    def test_custom_pagination_keys(self) -> None:
        """Noms de paramètres surchargés."""
        params = AlteredPaginationParams(limit=5, page=1)
        out = (
            QueryParamsBuilder(page_key="p", limit_key="per_page")
            .add_pagination(params)
            .build()
        )
        assert out == {"p": "1", "per_page": "5"}

    def test_build_sorted_keys(self) -> None:
        """Clés triées pour stabilité."""
        out = QueryParamsBuilder().add("z", 1).add("a", 2).build()
        assert list(out.keys()) == ["a", "z"]

    def test_duplicate_key_last_wins(self) -> None:
        """Dernière valeur conservée pour une même clé."""
        out = QueryParamsBuilder().add("k", 1).add("k", 2).build()
        assert out == {"k": "2"}

    def test_add_mapping(self) -> None:
        """Fusion depuis un mapping."""
        out = QueryParamsBuilder().add_mapping({"x": 1, "y": None}).build()
        assert out == {"x": "1"}

    def test_add_sort(self) -> None:
        """Tri ascendant puis descendant."""
        asc = QueryParamsBuilder().add_sort("name", descending=False).build()
        assert asc["order"] == "asc"
        assert asc["sort"] == "name"
        desc = QueryParamsBuilder().add_sort("name", descending=True).build()
        assert desc["order"] == "desc"

    def test_add_sort_custom_keys(self) -> None:
        """Clés de tri configurables."""
        b = QueryParamsBuilder(sort_key="sortBy", order_key="sortDir")
        out = b.add_sort("created", descending=True).build()
        assert out == {"sortBy": "created", "sortDir": "desc"}

    def test_empty_key_raises(self) -> None:
        """Clé vide refusée."""
        with pytest.raises(ValueError, match="non-empty"):
            QueryParamsBuilder().add("  ", "x")

    @pytest.mark.parametrize(
        ("values", "expected"),
        [
            ([], None),
            ([1, 2], "1,2"),
        ],
    )
    def test_list_edge_cases(self, values: list[int], expected: str | None) -> None:
        """Listes vides ou scalaires."""
        b = QueryParamsBuilder().add("lst", values)
        out = b.build()
        if expected is None:
            assert "lst" not in out
        else:
            assert out["lst"] == expected
