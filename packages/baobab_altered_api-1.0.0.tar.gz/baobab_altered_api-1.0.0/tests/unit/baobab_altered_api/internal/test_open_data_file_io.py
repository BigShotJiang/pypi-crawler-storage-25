"""Tests de ``OpenDataFileIo``."""

from __future__ import annotations

from pathlib import Path

import pytest

from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from baobab_altered_api.internal.open_data_file_io import OpenDataFileIo


class TestOpenDataFileIo:
    """Garde-fous lecture fichier Open Data."""

    def test_read_json_object_success(self, tmp_path: Path) -> None:
        """Lit un petit JSON objet."""
        path = tmp_path / "ok.json"
        path.write_text('{"version":1}', encoding="utf-8")
        data = OpenDataFileIo.read_json_object(path)
        assert data["version"] == 1

    def test_read_rejects_oversized_file(self, tmp_path: Path) -> None:
        """Refuse un fichier dépassant max_bytes."""
        path = tmp_path / "big.json"
        path.write_text('{"x":1}', encoding="utf-8")
        with pytest.raises(AlteredOpenDataDownloadError, match="max_bytes"):
            OpenDataFileIo.read_json_object(path, max_bytes=2)
