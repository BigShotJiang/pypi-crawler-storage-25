"""Tests de la fabrique d'authentification Altered."""

from __future__ import annotations

from baobab_api_call import ApiKeyAuth, ApiRequest, BearerAuth

from baobab_altered_api.auth.altered_auth_factory import AlteredAuthFactory
from baobab_altered_api.config.altered_api_config import AlteredApiConfig


class TestAlteredAuthFactory:
    """Vérifie la construction des stratégies d'authentification."""

    def test_none_when_no_credentials(self) -> None:
        """Sans secret, la fabrique retourne ``None``."""
        cfg = AlteredApiConfig()
        assert AlteredAuthFactory().create(cfg) is None

    def test_bearer_strategy(self) -> None:
        """Un bearer produit ``BearerAuth``."""
        cfg = AlteredApiConfig(bearer_token="baobab-api-token")
        strategy = AlteredAuthFactory().create(cfg)
        assert isinstance(strategy, BearerAuth)
        req = ApiRequest(method="GET", path="/x")
        applied = strategy.apply(req)
        assert applied.headers is not None
        assert applied.headers["Authorization"] == "Bearer baobab-api-token"

    def test_api_key_header_strategy(self) -> None:
        """Une clé API en header produit ``ApiKeyAuth``."""
        cfg = AlteredApiConfig(api_key="secret-key", api_key_header_name="X-Test-Key")
        strategy = AlteredAuthFactory().create(cfg)
        assert isinstance(strategy, ApiKeyAuth)
        req = ApiRequest(method="GET", path="/x")
        applied = strategy.apply(req)
        assert applied.headers is not None
        assert applied.headers["X-Test-Key"] == "secret-key"

    def test_api_key_query_strategy(self) -> None:
        """Une clé API en query utilise ``scheme`` du socle."""
        cfg = AlteredApiConfig(
            api_key="q-secret",
            api_key_query_param="apikey",
        )
        strategy = AlteredAuthFactory().create(cfg)
        assert isinstance(strategy, ApiKeyAuth)
        req = ApiRequest(method="GET", path="/x")
        applied = strategy.apply(req)
        assert applied.params is not None
        assert applied.params["apikey"] == "q-secret"

    def test_factory_repr(self) -> None:
        """La représentation de la fabrique ne contient pas de secret."""
        assert "token" not in repr(AlteredAuthFactory()).lower()
