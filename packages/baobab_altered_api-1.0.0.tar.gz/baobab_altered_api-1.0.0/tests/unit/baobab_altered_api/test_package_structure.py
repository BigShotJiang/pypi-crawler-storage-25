"""Tests de structure des sous-packages."""

from __future__ import annotations

import importlib

import pytest


class TestPackageStructure:
    """Vérifie l’arborescence applicative attendue."""

    @pytest.mark.parametrize(
        "subpackage",
        (
            "auth",
            "clients",
            "config",
            "exceptions",
            "internal",
            "mappers",
            "models",
            "resources",
            "transports",
        ),
    )
    def test_subpackage_imports(self, subpackage: str) -> None:
        """Chaque sous-package doit être importable sans erreur."""
        module = importlib.import_module(f"baobab_altered_api.{subpackage}")
        assert module.__doc__
