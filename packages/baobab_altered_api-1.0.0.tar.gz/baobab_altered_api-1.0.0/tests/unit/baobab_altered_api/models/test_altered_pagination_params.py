"""Tests de ``AlteredPaginationParams``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams


class TestAlteredPaginationParams:
    """Garde-fous sur limites et modes page / curseur."""

    def test_defaults(self) -> None:
        """Valeurs par défaut prudents."""
        p = AlteredPaginationParams()
        assert p.limit == 20
        assert p.page is None
        assert p.cursor is None
        assert p.max_iterations_guard == 50

    def test_limit_too_high_rejected(self) -> None:
        """Au-delà de ``MAX_LIMIT`` : erreur."""
        with pytest.raises(ValueError, match="limit"):
            AlteredPaginationParams(limit=101)

    def test_limit_zero_rejected(self) -> None:
        """Limite nulle interdite."""
        with pytest.raises(ValueError, match="limit"):
            AlteredPaginationParams(limit=0)

    def test_page_and_cursor_exclusive(self) -> None:
        """Pas de combinaison page + curseur."""
        with pytest.raises(ValueError, match="mutually exclusive"):
            AlteredPaginationParams(page=1, cursor="abc")

    def test_cursor_stripped(self) -> None:
        """Curseur normalisé."""
        p = AlteredPaginationParams(cursor="  tok  ")
        assert p.cursor == "tok"

    def test_guard_minimum(self) -> None:
        """Plafond d'itérations client >= 1."""
        with pytest.raises(ValueError, match="max_iterations"):
            AlteredPaginationParams(max_iterations_guard=0)
