"""Tests de ``AlteredLocalizedLabel``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_localized_label import AlteredLocalizedLabel


class TestAlteredLocalizedLabel:
    """Libellé par défaut et variantes."""

    def test_default_only(self) -> None:
        """Libellé unique sans carte de locales."""
        label = AlteredLocalizedLabel("Hello")
        assert label.default == "Hello"
        assert label.by_locale is None

    def test_with_locales(self) -> None:
        """Carte optionnelle fr / en."""
        label = AlteredLocalizedLabel(
            "fallback",
            by_locale={"fr-FR": "Bonjour", "en-US": "Hello"},
        )
        assert label.by_locale is not None
        assert label.by_locale["fr-FR"] == "Bonjour"

    def test_default_blank_rejected(self) -> None:
        """Le défaut ne peut pas être vide."""
        with pytest.raises(ValueError, match="non-empty"):
            AlteredLocalizedLabel("  ")
