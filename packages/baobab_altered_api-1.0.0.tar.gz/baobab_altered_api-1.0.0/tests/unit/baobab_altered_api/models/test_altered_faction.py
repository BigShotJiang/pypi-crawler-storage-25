"""Tests de ``AlteredFaction``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_ref import AlteredRef


class TestAlteredFaction:
    """Champs optionnels et normalisation."""

    def test_empty_shell(self) -> None:
        """Bloc entièrement optionnel toléré."""
        fac = AlteredFaction()
        assert fac.ref is None
        assert fac.name is None

    def test_name_stripped_to_none(self) -> None:
        """Nom blanc normalisé en ``None``."""
        fac = AlteredFaction(name="  ")
        assert fac.name is None

    def test_with_ref(self) -> None:
        """Référence faction typée."""
        fac = AlteredFaction(ref=AlteredRef("faction-1"), name="Ax")
        assert fac.ref.value == "faction-1"
        assert fac.name == "Ax"

    def test_frozen(self) -> None:
        """Immutabilité."""
        fac = AlteredFaction()
        with pytest.raises(AttributeError):
            fac.name = "n"  # type: ignore[misc]
