"""Tests de ``AlteredRarity``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_rarity import AlteredRarity


class TestAlteredRarity:
    """Rareté : code et nom optionnels."""

    def test_all_none(self) -> None:
        """Coque vide pour JSON partiel."""
        r = AlteredRarity()
        assert r.code is None
        assert r.name is None

    def test_code_only(self) -> None:
        """Code seul suffit."""
        r = AlteredRarity(code="COMMON")
        assert r.name is None

    def test_frozen(self) -> None:
        """Immutabilité."""
        r = AlteredRarity(code="R")
        with pytest.raises(AttributeError):
            r.code = "S"  # type: ignore[misc]
