"""Tests de ``AlteredSet``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_ref import AlteredRef
from baobab_altered_api.models.altered_set import AlteredSet


class TestAlteredSet:
    """Extension / série : codes et noms optionnels."""

    def test_minimal(self) -> None:
        """Instance vide autorisée."""
        st = AlteredSet()
        assert st.ref is None
        assert st.code is None
        assert st.name is None

    def test_code_and_name_normalized(self) -> None:
        """Espaces superflus retirés."""
        st = AlteredSet(
            ref=AlteredRef("set-1"),
            code="  CORE01  ",
            name="  Core  ",
        )
        assert st.code == "CORE01"
        assert st.name == "Core"

    def test_frozen(self) -> None:
        """Immutabilité."""
        st = AlteredSet(code="x")
        with pytest.raises(AttributeError):
            st.code = "y"  # type: ignore[misc]
