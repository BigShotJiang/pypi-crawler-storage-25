"""Tests de ``AlteredImage``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_image import AlteredImage


class TestAlteredImage:
    """Champs optionnels et normalisation d'URL."""

    def test_all_optional(self) -> None:
        """Aucun champ obligatoire : instance minimale."""
        img = AlteredImage()
        assert img.url is None
        assert img.raw is None

    def test_url_stripped_blank_becomes_none(self) -> None:
        """Une URL blanche devient ``None``."""
        img = AlteredImage(url="   ")
        assert img.url is None

    def test_frozen(self) -> None:
        """Immutabilité."""
        img = AlteredImage(url="https://cdn.example/img.png")
        with pytest.raises(AttributeError):
            img.url = None  # type: ignore[misc]
