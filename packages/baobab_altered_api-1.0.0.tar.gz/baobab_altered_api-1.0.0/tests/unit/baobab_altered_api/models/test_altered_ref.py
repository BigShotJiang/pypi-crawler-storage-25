"""Tests de ``AlteredRef``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_ref import AlteredRef


class TestAlteredRef:
    """Construction et immutabilité."""

    def test_accepts_non_empty_value(self) -> None:
        """Une valeur non vide après strip est acceptée."""
        ref = AlteredRef("  card-abc  ")
        assert ref.value == "card-abc"

    def test_rejects_blank_value(self) -> None:
        """Une chaîne vide ou blanche est refusée."""
        with pytest.raises(ValueError, match="non-empty"):
            AlteredRef("   ")

    def test_frozen_no_mutation(self) -> None:
        """Les instances gelées ne permettent pas la réaffectation."""
        ref = AlteredRef("x")
        with pytest.raises(AttributeError):
            ref.value = "y"  # type: ignore[misc]
