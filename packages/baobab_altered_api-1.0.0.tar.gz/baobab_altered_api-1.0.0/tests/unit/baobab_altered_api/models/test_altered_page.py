"""Tests de ``AlteredPage``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_page import AlteredPage


class TestAlteredPage:
    """Page typée et immutabilité."""

    def test_items_only(self) -> None:
        """Page minimale : seulement les items."""
        page = AlteredPage(items=("a", "b"))
        assert page.items == ("a", "b")
        assert page.total_count is None

    def test_with_metadata(self) -> None:
        """Totaux et curseurs optionnels."""
        page = AlteredPage(
            items=("x",),
            total_count=100,
            next_cursor="n1",
            previous_cursor="p0",
            has_next_page=True,
            raw={"extra": 1},
        )
        assert page.total_count == 100
        assert page.next_cursor == "n1"
        assert page.has_next_page is True
        assert page.raw is not None
        assert page.raw["extra"] == 1

    def test_frozen(self) -> None:
        """Pas de mutation des attributs."""
        page = AlteredPage(items=("z",))
        with pytest.raises(AttributeError):
            page.items = ()  # type: ignore[misc]
