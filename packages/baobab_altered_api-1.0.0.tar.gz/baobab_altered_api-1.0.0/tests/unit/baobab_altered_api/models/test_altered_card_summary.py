"""Tests de ``AlteredCardSummary``."""

from __future__ import annotations

import pytest

from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_image import AlteredImage
from baobab_altered_api.models.altered_rarity import AlteredRarity
from baobab_altered_api.models.altered_ref import AlteredRef
from baobab_altered_api.models.altered_set import AlteredSet


class TestAlteredCardSummary:
    """Résumé carte : ref obligatoire, reste optionnel."""

    def test_ref_only(self) -> None:
        """Construction minimale avec seulement ``ref``."""
        summary = AlteredCardSummary(ref=AlteredRef("card-42"))
        assert summary.name is None
        assert summary.faction is None
        assert summary.expansion is None

    def test_full_optional_blocks(self) -> None:
        """Composition avec faction, extension, rareté, image."""
        summary = AlteredCardSummary(
            ref=AlteredRef("c1"),
            name="Title",
            faction=AlteredFaction(name="F"),
            expansion=AlteredSet(code="S1"),
            rarity=AlteredRarity(code="RARE"),
            image=AlteredImage(url="https://cdn.example/i.png"),
        )
        assert summary.faction is not None
        assert summary.faction.name == "F"
        assert summary.expansion is not None
        assert summary.expansion.code == "S1"
        assert summary.rarity is not None
        assert summary.rarity.code == "RARE"
        assert summary.image is not None
        assert summary.image.url == "https://cdn.example/i.png"

    def test_name_blank_normalized(self) -> None:
        """Nom blanc devient ``None``."""
        summary = AlteredCardSummary(ref=AlteredRef("x"), name="  ")
        assert summary.name is None

    def test_frozen(self) -> None:
        """Immutabilité."""
        summary = AlteredCardSummary(ref=AlteredRef("a"))
        with pytest.raises(AttributeError):
            summary.name = "b"  # type: ignore[misc]
