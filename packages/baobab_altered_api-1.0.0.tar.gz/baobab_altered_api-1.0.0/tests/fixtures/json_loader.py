"""Chargement des fixtures JSON de test (hors distribution publique)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_FIXTURES_ROOT = Path(__file__).resolve().parent


def load_json_fixture(name: str, *, subdir: str = "json") -> Any:
    """Charge un fichier JSON depuis ``tests/fixtures/<subdir>/``.

    :param name: Nom de fichier (ex. ``card_minimal.json``).
    :param subdir: Sous-dossier sous ``tests/fixtures`` (défaut ``json``).
    :return: Objet décodé (dict, list, etc.).
    :raises FileNotFoundError: Fichier absent.
    """
    path = _FIXTURES_ROOT / subdir / name
    return json.loads(path.read_text(encoding="utf-8"))
