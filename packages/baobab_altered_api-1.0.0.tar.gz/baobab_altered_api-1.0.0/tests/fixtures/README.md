# Fixtures de test

Corpus **synthétique** pour les tests unitaires (aucun secret, aucune donnée personnelle).

| Fichier | Usage | Origine |
|---------|--------|---------|
| `json/card_minimal.json` | Carte minimale | Synthétique |
| `json/card_summary_*.json` | Mappers communs (BL-005-002) | Synthétique |
| `json/page_cards.json` | Liste paginée de cartes | Synthétique |
| `json/deck_minimal.json` | Deck minimal | Synthétique |
| `json/market_offer_minimal.json` | Offre marketplace lecture seule | Synthétique |
| `json/error_404.json` | Corps d’erreur HTTP 404 typique | Synthétique |
| `open_data/open_data_minimal.json` | Export Open Data hiérarchique | Synthétique |

Chargement : ``tests.fixtures.json_loader.load_json_fixture("nom.json")``.
