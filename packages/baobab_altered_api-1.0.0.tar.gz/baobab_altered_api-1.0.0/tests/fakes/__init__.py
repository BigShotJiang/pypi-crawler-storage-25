"""Doubles de transport pour les tests (hors distribution runtime).

Ces classes complètent les fakes génériques du socle ``baobab-api-call`` en
permettant un routage déterministe par méthode HTTP, chemin et paramètres de
requête — utile pour les ressources métier Altered.
"""

from tests.fakes.fake_async_transport import FakeAsyncTransport
from tests.fakes.fake_sync_transport import FakeSyncTransport

__all__ = ("FakeAsyncTransport", "FakeSyncTransport")
