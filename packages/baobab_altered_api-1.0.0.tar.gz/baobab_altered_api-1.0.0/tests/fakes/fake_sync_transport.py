"""Transport synchrone factice routé par méthode, chemin et paramètres."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

from baobab_api_call import ApiRequest, ApiResponse


class FakeSyncTransport:
    """Double de test compatible ``SyncTransport`` (sans réseau).

    Enregistrez des réponses ou des exceptions par clé
    ``(méthode, chemin, paramètres normalisés)``. Les requêtes reçues sont
    conservées pour assertions. Aucune dépendance HTTPX : uniquement des
    :class:`~baobab_api_call.api_request.ApiRequest` /
    :class:`~baobab_api_call.api_response.ApiResponse`.

    :ivar requests: Copie défensive des requêtes passées à :meth:`send`.
    """

    __slots__ = ("_closed", "_default", "_history", "_registry")

    def __init__(self) -> None:
        self._closed: bool = False
        self._registry: dict[
            tuple[str, str, tuple[tuple[str, str], ...]],
            ApiResponse | BaseException,
        ] = {}
        self._default: ApiResponse | BaseException | None = None
        self._history: list[ApiRequest] = []

    @property
    def requests(self) -> list[ApiRequest]:
        """Historique des requêtes (copie défensive)."""
        return list(self._history)

    @property
    def closed(self) -> bool:
        """Vrai après :meth:`close`."""
        return self._closed

    @staticmethod
    def _route_key(
        method: str,
        path: str,
        params: Mapping[str, Any] | None,
    ) -> tuple[str, str, tuple[tuple[str, str], ...]]:
        m = method.upper()
        if params is None or len(params) == 0:
            pkey: tuple[tuple[str, str], ...] = ()
        else:
            pkey = tuple(
                sorted((str(k), str(v)) for k, v in dict(params).items()),
            )
        return (m, path, pkey)

    def register(
        self,
        method: str,
        path: str,
        outcome: ApiResponse | BaseException,
        *,
        params: Mapping[str, Any] | None = None,
    ) -> None:
        """Associe une réponse ou une exception à une requête cible.

        :param method: Verbe HTTP (insensible à la casse pour la clé).
        :param path: Chemin ou URL absolue attendue sur la requête.
        :param outcome: Réponse factice ou exception à lever.
        :param params: Paramètres de requête ; ``None`` ou vide = sans query.
        """
        key = self._route_key(method, path, params)
        self._registry[key] = outcome

    def set_default(self, outcome: ApiResponse | BaseException) -> None:
        """Définit le comportement si aucune entrée ne correspond à la requête."""
        self._default = outcome

    def clear(self) -> None:
        """Réinitialise enregistrements, défaut et historique."""
        self._registry.clear()
        self._default = None
        self._history.clear()

    def send(self, request: ApiRequest) -> ApiResponse:
        """Retourne la réponse enregistrée ou lève l'exception configurée."""
        if self._closed:
            raise RuntimeError("FakeSyncTransport.send() called after close()")
        self._history.append(request)
        key = self._route_key(request.method, request.path, request.params)
        outcome = self._registry.get(key, self._default)
        if outcome is None:
            param_keys = sorted((request.params or {}).keys())
            raise LookupError(
                "FakeSyncTransport: no registration for "
                f"{request.method} {request.path!r} (param keys: {param_keys})",
            )
        if isinstance(outcome, BaseException):
            raise outcome
        if outcome.request is None:
            return replace(outcome, request=request)
        return outcome

    def close(self) -> None:
        """Ferme le fake ; :meth:`send` refusera les appels suivants."""
        self._closed = True
