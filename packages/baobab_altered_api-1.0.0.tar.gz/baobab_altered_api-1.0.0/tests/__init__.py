"""Paquet ``tests`` : permet les imports ``tests.fakes`` depuis les tests unitaires."""
