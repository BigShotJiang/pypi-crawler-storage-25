"""Fixtures Pytest partagées pour la suite de tests."""

from __future__ import annotations

import socket
from typing import Any

import pytest


@pytest.fixture(autouse=True)
def _refuse_real_network(
    request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Interdit les sockets réels pour les tests non marqués ``integration``."""

    if request.node.get_closest_marker("integration") is not None:
        return

    _real_socket = socket.socket
    af_unix = getattr(socket, "AF_UNIX", None)

    def fake_socket(*args: Any, **kwargs: Any) -> socket.socket:
        # ``asyncio`` (boucle d'événements) utilise des sockets locaux (ex. ``AF_UNIX``)
        # pour ses tuyaux internes ; ils ne constituent pas un accès réseau Internet.
        family = kwargs.get("family", args[0] if args else socket.AF_INET)
        if af_unix is not None and family == af_unix:
            return _real_socket(*args, **kwargs)
        raise RuntimeError(
            "Connexion réseau interdite dans les tests unitaires "
            "(utilisez des fakes ou le marqueur ``integration``)."
        )

    monkeypatch.setattr(socket, "socket", fake_socket)
