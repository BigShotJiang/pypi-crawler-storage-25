"""Tests d'intégration Open Data (réseau optionnel, désactivés par défaut)."""

from __future__ import annotations

import os

import pytest

from baobab_altered_api import AlteredApiConfig, AlteredClient


@pytest.mark.integration
@pytest.mark.skipif(
    os.environ.get("ALTERED_API_OPEN_DATA_URL") is None,
    reason="ALTERED_API_OPEN_DATA_URL non défini",
)
class TestOpenDataLiveOptional:
    """Contrôle minimal contre l'URL Open Data réelle si configurée."""

    def test_fetch_snapshot_live(self) -> None:
        """Télécharge et mappe l'export distant (environnement autorisé uniquement)."""
        cfg = AlteredApiConfig.from_environment()
        with AlteredClient(cfg) as client:
            snap = client.open_data.fetch_snapshot()
        assert len(snap.cards) >= 0
