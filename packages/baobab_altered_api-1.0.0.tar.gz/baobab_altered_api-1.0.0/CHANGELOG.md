# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

Le format est inspiré de [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/).

## [Unreleased]

## [1.0.0] - 2026-05-17

Première release stable : portefeuille FEAT-001 à FEAT-012 livré (clients sync/async, ressources métier, Open Data, robustesse transverse, documentation et tests ≥ 90 % de couverture).

### Added

- Alignement cahier des charges Open Data : ``OpenDataResource``, ``AsyncOpenDataResource``, hiérarchie Set→Faction→Carte, ``fetch_snapshot`` / ``load_from_file`` / ``iter_cards`` / ``save_snapshot``, ``OpenDataFileIo``, ``AsyncAlteredClient.open_data``.
- Documentation : ``docs/decks.md``, ``docs/api_observations/decks.md``, ``marketplace.md``, ``auth.md`` ; index endpoints complété.
- Test d'intégration optionnel Open Data (``@pytest.mark.integration``).

- FEAT-012 : ``docs/development.md``, ``docs/guide_sync.md``, ``docs/guide_async.md``, ``docs/release_checklist.md``, index ``docs/api_observations/endpoints/``.
- FEAT-010 : ``AlteredMarketplaceOffer``, mapper et ``MarketplaceResource`` / ``AsyncMarketplaceResource`` (lecture seule).
- FEAT-009 : ``AlteredDeck``, mapper et ``DecksResource`` / ``AsyncDecksResource``.
- FEAT-008 : ``AlteredOpenDataSnapshot``, ``OpenDataReader``, ``OpenDataDownloader``, ``OpenDataCatalog``, ``OpenDataAccess`` et propriété ``AlteredClient.open_data`` ; fixtures ``tests/fixtures/open_data/`` ; ``docs/open_data.md``, ``docs/api_observations/open_data.md``.
- FEAT-009 : tests dédiés ``test_async_decks_resource.py`` (``AsyncDecksResource``).
- FEAT-010 : ``docs/marketplace.md``, section marketplace dans ``docs/security.md``, test contractuel ``test_marketplace_read_only_contract.py``.
- FEAT-007 : modèles référentiels, ``ReferentialsResource`` / ``AsyncReferentialsResource`` ; ``docs/api_observations/references.md``.
- FEAT-006 : ``CardSearchFilters``, ``CardsResource`` / ``AsyncCardsResource``, itération paginée contrôlée ; ``docs/cards.md``, ``docs/api_observations/cards.md``.
- FEAT-005 (`BL-005-005`) : corpus fixtures JSON + ``tests/fixtures/README.md``, ``json_loader``, tests parseabilité.
- FEAT-005 (`BL-005-004`) : builder interne ``QueryParamsBuilder`` (`internal/query_params.py`) pour sérialiser filtres, tris et ``AlteredPaginationParams`` vers ``dict[str, str]`` stable ; ``docs/api_observations/query_params.md``.
- FEAT-005 (`BL-005-003`) : ``AlteredPaginationParams``, ``AlteredPage`` (générique), ``AlteredPaginationJsonMapper`` ; ``docs/api_observations/pagination.md``.
- FEAT-005 (`BL-005-002`) : ``AlteredCommonModelsJsonMapper`` (résumé carte, faction, extension, rareté, image, libellé localisé, ref) ; tolérance alias JSON et ``AlteredMappingError`` ; fixtures ``tests/fixtures/json/*.json`` ; ``docs/api_observations/mappers.md``.
- FEAT-005 (`BL-005-001`) : modèles communs immuables `AlteredRef`, `AlteredImage`, `AlteredLocalizedLabel`, `AlteredFaction`, `AlteredSet`, `AlteredRarity`, `AlteredCardSummary` ; exports `models.__all__` ; hypothèses documentées dans `docs/api_observations/models.md`.
- FEAT-011 (`BL-011-006`) : tests transverses `test_transverse_robustness.py` ; section associée dans `docs/testing.md`.
- FEAT-011 (`BL-011-005`) : middlewares sync/async `AlteredRateLimitMiddleware` / `AlteredRateLimitMiddlewareAsync` sur `ApiClientConfig` si `rate_limit_per_second` ; tests `test_rate_limit.py` ; `docs/security.md` (débit / 429), `docs/configuration.md`, `docs/clients.md`.
- FEAT-011 (`BL-011-004`) : timeout global propagé au transport HTTPX par défaut ; `retry_jitter` + plafond `MAX_RETRY_ATTEMPTS` (50) ; `RetryPolicy` du socle alignée ; variable `ALTERED_API_RETRY_JITTER` ; tests `test_retries_timeouts.py`.
- FEAT-011 (`BL-011-001`) : exceptions `AlteredAuthError`, `AlteredForbiddenError`, `AlteredServiceUnavailableError`, `AlteredTransportError`, `AlteredMappingError` ; tests `test_exceptions.py` ; exports `exceptions.__all__`.
- FEAT-011 (`BL-011-003`) : logger `baobab_altered_api` (opt-in, sans `basicConfig`) ; `AlteredLogRedactor` / `AlteredApiLogger` ; journaux HTTP minimaux dans les transports sync/async ; tests `internal/test_*` et non-fuite dans `caplog`.
- FEAT-011 (`BL-011-002`) : `ErrorMapper` (HTTP → exceptions Altered, transport timeout / réseau) ; intégration dans `AlteredTransportResponseHandler` ; `AlteredServiceUnavailableError` accepte le code HTTP 5xx réel ; tests `test_error_mapper.py` et ajustements `test_response_handler.py`.
- FEAT-004 (BL-004-001, BL-004-002) : clients publics `AlteredClient` et `AsyncAlteredClient` (façade + `http`, context managers, transport par défaut ou injecté) ; exports package racine.
- FEAT-004 (BL-004-003) : injection optionnelle `api_client_config` sur `AlteredClient` / `AsyncAlteredClient` (alignement `base_url` avec `AlteredApiConfig`, garde-fous transport sync/async, `ApiClientConfigAlignment`, `TransportPortValidator`) ; tests `test_client_injection.py`.
- FEAT-004 (BL-004-004) : exports publics documentés pour `baobab_altered_api.clients` (`__all__` typé) ; tests `test_public_exports.py` ; clients toujours re-exportés depuis le package racine.
- FEAT-004 (BL-004-005) : guide `docs/clients.md` (usages minimaux sync/async, injection, pas d’endpoint présenté comme stable).
- FEAT-003 (BL-003-005) : fakes `tests.fakes.FakeSyncTransport` / `FakeAsyncTransport` (routage méthode + chemin + params, historique, défaut) ; documentation `docs/testing.md` ; `source-roots` Pylint pour les imports `tests.*`.
- FEAT-003 (BL-003-004) : `AlteredTransportResponseHandler`, `AlteredJsonPayload`, exceptions typées (`AlteredApiError`, 404, 429, timeout, réseau, JSON) ; amorce FEAT-011 pour la hiérarchie d’erreurs.
- FEAT-003 (BL-003-003) : fermeture idempotente, `with` / `async with` sur `AlteredSyncTransport` et `AlteredAsyncTransport` ; tests de cycle de vie dédiés.
- Docstrings Sphinx complètes sur le validateur réseau, `__repr__` / `__str__` de
  `AlteredApiConfig` et `__repr__` de `AlteredAuthFactory` ; jeton Bearer de test
  `baobab-api-token` dans les tests et exemples de documentation.
- FEAT-003 (BL-003-002) : transport asynchrone `AlteredAsyncTransport` (HTTPX + port `AsyncTransport`).
- FEAT-003 (BL-003-001) : transport synchrone `AlteredSyncTransport` (HTTPX + port `SyncTransport`) et exception `AlteredHttpError`.
- FEAT-002 : configuration immuable `AlteredApiConfig`, chargement explicite `load_config_from_env`, validation réseau, fabrique d’authentification `AlteredAuthFactory` et construction vers le socle `baobab-api-call`.
- `AlteredApiConfig.from_environment` (alias documentaire), variables d’environnement `ALTERED_API_RETRY_BACKOFF_SECONDS` et `ALTERED_API_RATE_LIMIT_PER_SECOND`.
- Documentation `docs/configuration.md`, `docs/authentication.md` et `docs/security.md` (variables d’environnement, bonnes pratiques secrets).
- Socle packaging PEP 621 (`hatchling`) pour la distribution `baobab-altered-api`.
- Arborescence applicative `src/baobab_altered_api` avec sous-packages (`config`, `clients`, `resources`, etc.).
- Tests unitaires initiaux, garde anti-réseau par défaut et documentation de test.
- Marqueur PEP 561 via `py.typed`.

### Documentation

- Pilotage portefeuille : `BOARD.md` étendu (`FEAT-005`–`FEAT-012`), décision **DEC-0001** dans `docs/ia_workflow/communication/003_decision_log.md`, fiche **NO GO** levée (`docs/ia_workflow/no_go/REQUEST_ALL_BACKLOGS_SINGLE_PASS/no_go_1.md`).

### Fixed

- Garde réseau des tests : les sockets ``AF_UNIX`` utilisés en interne par ``asyncio`` ne sont plus bloqués (nécessaire aux tests async / ``pytest-asyncio``).
- Dépendance dev ``pytest-asyncio>=1.3`` : suppression des warnings ``asyncio.get_event_loop_policy`` sous Python 3.14.
