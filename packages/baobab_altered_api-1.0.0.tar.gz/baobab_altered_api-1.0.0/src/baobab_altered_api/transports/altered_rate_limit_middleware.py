"""Middleware sync de limitation de débit entre requêtes HTTP."""

from __future__ import annotations

import math
import threading
import time
from typing import Callable

from baobab_api_call.api_request import ApiRequest
from baobab_api_call.api_response import ApiResponse

from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class AlteredRateLimitMiddleware:
    """Espace les envois HTTP pour respecter un plafond local (req/s).

    Implémente le protocole :class:`Middleware` du socle ``baobab-api-call``.
    :meth:`before_request` suspend le thread si deux appels surviennent plus
    vite que l'intervalle minimal ``1 / max_per_second``.

    Ce mécanisme **complète** une consommation responsable : les réponses
    ``429`` du serveur restent gérées par la politique de retry et le mapping
    d'exceptions Altered ; il ne s'agit pas d'un contournement de quota.

    :param max_per_second: Nombre maximal de requêtes par seconde (> 0, fini).
    :param monotonic_fn: Horloge monotone injectable (tests).
    :param sleep_fn: Fonction de sommeil injectable (tests ; défaut
        :func:`time.sleep`).
    """

    def __init__(
        self,
        *,
        max_per_second: float,
        monotonic_fn: Callable[[], float] = time.monotonic,
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        if not isinstance(max_per_second, (int, float)) or isinstance(
            max_per_second, bool
        ):
            raise AlteredConfigError(
                f"max_per_second must be a number, got {type(max_per_second).__name__}"
            )
        rate = float(max_per_second)
        if not math.isfinite(rate) or rate <= 0:
            raise AlteredConfigError("max_per_second must be a finite number > 0")
        self._interval: float = 1.0 / rate
        self._monotonic_fn: Callable[[], float] = monotonic_fn
        self._sleep_fn: Callable[[float], None] = sleep_fn
        self._lock: threading.Lock = threading.Lock()
        self._last_send_monotonic: float | None = None

    def before_request(self, request: ApiRequest) -> ApiRequest:
        """Retarde l'envoi si le délai minimal depuis le précédent n'est pas écoulé.

        :param request: Requête à envoyer (non modifiée).
        :return: La même instance ``request``.
        """
        with self._lock:
            now = self._monotonic_fn()
            if self._last_send_monotonic is None:
                self._last_send_monotonic = now
                return request
            elapsed = now - self._last_send_monotonic
            if elapsed < self._interval:
                wait_seconds = self._interval - elapsed
                self._sleep_fn(wait_seconds)
                now = self._monotonic_fn()
            self._last_send_monotonic = now
        return request

    def after_response(
        self, _request: ApiRequest, response: ApiResponse
    ) -> ApiResponse:
        """Passe la réponse sans modification.

        :param _request: Requête initiale.
        :param response: Réponse du transport.
        :return: ``response`` inchangée.
        """
        return response

    def on_error(self, _request: ApiRequest, _exc: BaseException) -> None:
        """Ne modifie pas la propagation des erreurs.

        :param _request: Requête en cours.
        :param _exc: Exception levée en aval.
        """
        return None
