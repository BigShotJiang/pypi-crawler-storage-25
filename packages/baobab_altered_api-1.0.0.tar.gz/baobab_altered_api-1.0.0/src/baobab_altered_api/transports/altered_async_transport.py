"""Transport asynchrone Altered basé sur HTTPX et le port ``AsyncTransport``."""

# pylint: disable=duplicate-code
# Couverture volontaire avec ``altered_sync_transport`` (FEAT-003) :
# similarité attendue.

from __future__ import annotations

from types import TracebackType
from typing import Any

import httpx
from baobab_api_call import ApiRequest, ApiResponse

from baobab_altered_api.config.altered_network_parameter_validator import (
    AlteredNetworkParameterValidator,
)
from baobab_altered_api.internal.altered_api_logger import AlteredApiLogger


class AlteredAsyncTransport:
    """Transport asynchrone via HTTPX, compatible ``AsyncTransport`` du socle.

    Délègue l'E/S à :class:`httpx.AsyncClient`. Les requêtes sont enrichies
    (URL absolue, en-têtes, auth) par ``AsyncApiClient``.

    Cycle de vie : appeler :meth:`aclose` lorsque le transport possède le
    client HTTPX (créé par défaut). Si un :class:`~httpx.AsyncClient` est
    injecté, la fermeture reste à la charge de l'appelant.

    Context manager async : ``async with AlteredAsyncTransport() as t:`` appelle
    :meth:`aclose` à la sortie du bloc (y compris sur exception).

    :param client: Client HTTPX async injecté ; si ``None``, un client par défaut
        est créé et détenu par ce transport.
    :param default_timeout_seconds: Délai HTTPX lorsque ``ApiRequest.timeout_seconds``
        est absent (requêtes directes sur le transport ; le client async du socle
        fixe sinon un délai explicite par appel).
    """

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        *,
        default_timeout_seconds: float | None = None,
    ) -> None:
        if default_timeout_seconds is not None:
            AlteredNetworkParameterValidator.validate_timeout_seconds(
                default_timeout_seconds
            )
        self._client: httpx.AsyncClient = (
            httpx.AsyncClient() if client is None else client
        )
        self._owns_client: bool = client is None
        self._owner_shutdown: bool = False
        self._default_timeout_seconds: float | None = default_timeout_seconds

    async def send(self, request: ApiRequest) -> ApiResponse:
        """Envoie la requête via HTTPX et renvoie une :class:`ApiResponse`.

        :param request: Requête logique (URL absolue attendue).
        :return: Réponse du socle (y compris codes 4xx/5xx, sans exception).
        :raises TimeoutError: Délai dépassé (normalisé pour ``AsyncApiClient``).
        :raises ConnectionError: Erreur réseau bas niveau.
        """
        content = self._body_to_bytes(request.body)
        effective_timeout = request.timeout_seconds
        if effective_timeout is None and self._default_timeout_seconds is not None:
            effective_timeout = self._default_timeout_seconds
        httpx_timeout = (
            effective_timeout
            if effective_timeout is not None
            else httpx.USE_CLIENT_DEFAULT
        )
        httpx_req = self._client.build_request(
            request.method,
            request.path,
            headers=dict(request.headers) if request.headers else None,
            params=dict(request.params) if request.params else None,
            content=content,
            timeout=httpx_timeout,
        )
        try:
            raw = await self._client.send(httpx_req)
        except httpx.TimeoutException as exc:
            raise TimeoutError(str(exc)) from exc
        except httpx.RequestError as exc:
            raise ConnectionError(str(exc)) from exc

        hdrs: dict[str, str] | None = dict(raw.headers.items()) if raw.headers else None
        body_bytes = await raw.aread()
        text_body = raw.text
        try:
            elapsed = raw.elapsed.total_seconds()
        except RuntimeError:
            elapsed = None
        api_response = ApiResponse(
            status_code=raw.status_code,
            content=body_bytes,
            headers=hdrs,
            text=text_body,
            elapsed_seconds=elapsed,
            request=request,
        )
        AlteredApiLogger.log_http_roundtrip(request, api_response)
        return api_response

    async def aclose(self) -> None:
        """Ferme le client HTTPX si ce transport en est propriétaire.

        Idempotent : les appels suivants sont sans effet.
        """
        if not self._owns_client:
            return
        if self._owner_shutdown:
            return
        await self._client.aclose()
        self._owner_shutdown = True

    async def __aenter__(self) -> AlteredAsyncTransport:
        """Entrée de context manager async : retourne ``self``."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Sortie de context manager async : appelle :meth:`aclose`."""
        await self.aclose()

    @staticmethod
    def _body_to_bytes(body: Any) -> bytes | None:
        if body is None:
            return None
        if isinstance(body, (bytes, bytearray)):
            return bytes(body)
        if isinstance(body, str):
            return body.encode("utf-8")
        raise TypeError(
            f"request body must be bytes, bytearray, str or None; "
            f"got {type(body).__name__}"
        )
