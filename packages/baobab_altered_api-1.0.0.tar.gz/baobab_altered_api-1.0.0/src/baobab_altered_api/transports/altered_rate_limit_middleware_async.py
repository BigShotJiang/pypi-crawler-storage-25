"""Middleware async de limitation de débit entre requêtes HTTP."""

# pylint: disable=duplicate-code
# Parité volontaire avec ``altered_rate_limit_middleware`` (FEAT-011 / BL-011-005).

from __future__ import annotations

import asyncio
import math
import time
from collections.abc import Awaitable, Callable

from baobab_api_call.api_request import ApiRequest
from baobab_api_call.api_response import ApiResponse

from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class AlteredRateLimitMiddlewareAsync:
    """Version async du pacing :class:`AlteredRateLimitMiddleware`.

    Respecte le protocole :class:`MiddlewareAsync` du socle. Utilise
    :func:`asyncio.sleep` par défaut entre deux envois trop rapprochés.

    :param max_per_second: Plafond local strictement positif (req/s).
    :param monotonic_fn: Horloge monotone injectable (tests).
    :param sleep_fn: Sommeil async injectable (tests).
    """

    def __init__(
        self,
        *,
        max_per_second: float,
        monotonic_fn: Callable[[], float] = time.monotonic,
        sleep_fn: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        if not isinstance(max_per_second, (int, float)) or isinstance(
            max_per_second, bool
        ):
            raise AlteredConfigError(
                f"max_per_second must be a number, got {type(max_per_second).__name__}"
            )
        rate = float(max_per_second)
        if not math.isfinite(rate) or rate <= 0:
            raise AlteredConfigError("max_per_second must be a finite number > 0")
        self._interval: float = 1.0 / rate
        self._monotonic_fn: Callable[[], float] = monotonic_fn
        self._sleep_fn: Callable[[float], Awaitable[None]] = sleep_fn
        self._lock: asyncio.Lock = asyncio.Lock()
        self._last_send_monotonic: float | None = None

    async def before_request(self, request: ApiRequest) -> ApiRequest:
        """Retarde l'envoi async si nécessaire.

        :param request: Requête à envoyer.
        :return: La même instance ``request``.
        """
        async with self._lock:
            now = self._monotonic_fn()
            if self._last_send_monotonic is None:
                self._last_send_monotonic = now
                return request
            elapsed = now - self._last_send_monotonic
            if elapsed < self._interval:
                wait_seconds = self._interval - elapsed
                await self._sleep_fn(wait_seconds)
                now = self._monotonic_fn()
            self._last_send_monotonic = now
        return request

    async def after_response(
        self, _request: ApiRequest, response: ApiResponse
    ) -> ApiResponse:
        """Passe la réponse sans modification.

        :param _request: Requête initiale.
        :param response: Réponse du transport.
        :return: ``response`` inchangée.
        """
        return response

    async def on_error(self, _request: ApiRequest, _exc: BaseException) -> None:
        """Ne modifie pas la propagation des erreurs.

        :param _request: Requête en cours.
        :param _exc: Exception levée en aval.
        """
        return None
