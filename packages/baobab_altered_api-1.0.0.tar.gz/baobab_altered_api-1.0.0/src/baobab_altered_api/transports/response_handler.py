"""Normalisation des réponses JSON et des erreurs de transport."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, NoReturn

from baobab_api_call import ApiRequest, ApiResponse
from baobab_api_call.exceptions import ApiSerializationError

from baobab_altered_api.exceptions.altered_json_decode_error import (
    AlteredJsonDecodeError,
)
from baobab_altered_api.exceptions.error_mapper import ErrorMapper
from baobab_altered_api.models.altered_json_payload import AlteredJsonPayload


def _pagination_hints(response: ApiResponse) -> dict[str, Any] | None:
    """Construit des indices de pagination non sensibles depuis la réponse."""
    hints: dict[str, Any] = {}
    headers = response.headers
    if headers:
        total = headers.get("X-Total-Count") or headers.get("x-total-count")
        if total is not None and total.strip().isdigit():
            hints["total_count"] = int(total.strip())
        link = headers.get("Link") or headers.get("link")
        if link is not None and ('rel="next"' in link or "rel=next" in link):
            hints["has_next"] = True
    return hints or None


class AlteredTransportResponseHandler:
    """Convertit ``ApiResponse`` et erreurs du socle vers le domaine Altered.

    Les messages restent **sans** corps de réponse ni jetons ; seuls statut,
    chemin et indices non sensibles sont portés par les exceptions.
    """

    @staticmethod
    def json_payload_or_raise(response: ApiResponse) -> AlteredJsonPayload:
        """Retourne le JSON racine (objet ou liste) pour une réponse réussie.

        :param response: Réponse du socle après transport / client.
        :return: Données JSON et indices de pagination éventuels.
        :raises AlteredNotFoundError: Si le code HTTP est 404.
        :raises AlteredRateLimitError: Si le code HTTP est 429.
        :raises AlteredAuthError: Si le code HTTP est 401.
        :raises AlteredForbiddenError: Si le code HTTP est 403.
        :raises AlteredServiceUnavailableError: Si le code HTTP est 5xx.
        :raises AlteredApiError: Autres codes HTTP d'erreur mappés ou génériques.
        :raises AlteredJsonDecodeError: JSON invalide ou racine non objet/liste.
        """
        if response.is_error:
            ErrorMapper.raise_for_failed_response(response)
        request = response.request
        path = request.path if request is not None else None
        try:
            data = response.json()
        except ApiSerializationError as exc:
            raise AlteredJsonDecodeError(
                "Invalid JSON response",
                http_status=response.status_code,
                path=path,
            ) from exc
        if isinstance(data, Mapping):
            payload_data: Mapping[str, Any] | list[Any] = dict(data)
        elif isinstance(data, list):
            payload_data = data
        else:
            raise AlteredJsonDecodeError(
                "JSON root must be object or array",
                http_status=response.status_code,
                path=path,
            )
        return AlteredJsonPayload(
            data=payload_data,
            pagination=_pagination_hints(response),
        )

    @staticmethod
    def raise_for_client_failure(
        exc: BaseException,
        request: ApiRequest | None = None,
    ) -> NoReturn:
        """Re-lève une exception du socle sous forme typée Altered.

        :param exc: Erreur émise par ``SyncApiClient`` / ``AsyncApiClient``.
        :param request: Requête associée, si disponible.
        :raises AlteredTimeoutError: Dépassement de délai.
        :raises AlteredNetworkError: Autre erreur réseau / transport.
        """
        ErrorMapper.raise_for_transport_failure(exc, request)
