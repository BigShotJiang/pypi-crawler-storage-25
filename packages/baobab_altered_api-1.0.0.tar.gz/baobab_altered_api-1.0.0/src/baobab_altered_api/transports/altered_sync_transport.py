"""Transport synchrone Altered basé sur HTTPX et le port ``SyncTransport``."""

from __future__ import annotations

from types import TracebackType
from typing import Any

import httpx
from baobab_api_call import ApiRequest, ApiResponse

from baobab_altered_api.config.altered_network_parameter_validator import (
    AlteredNetworkParameterValidator,
)
from baobab_altered_api.internal.altered_api_logger import AlteredApiLogger


class AlteredSyncTransport:
    """Transport synchrone via HTTPX, compatible ``SyncTransport`` du socle.

    Délègue l'E/S à :class:`httpx.Client`. Les requêtes sont enrichies
    (URL absolue, en-têtes, auth) par ``SyncApiClient``.

    Context manager : ``with AlteredSyncTransport() as t:`` appelle
    :meth:`close` à la sortie du bloc (y compris sur exception).

    :param client: Client HTTPX injecté ; si ``None``, un client par défaut est
        créé et détenu par ce transport.
    :param default_timeout_seconds: Délai HTTPX appliqué lorsque la
        :class:`~baobab_api_call.ApiRequest` n'a pas de ``timeout_seconds`` défini.
        Les requêtes produites par ``SyncApiClient`` portent toujours un délai
        explicite ; ce défaut sert aux usages directs du transport alignés sur
        :class:`~baobab_altered_api.config.altered_api_config.AlteredApiConfig`
        (voir aussi :class:`~baobab_altered_api.clients.altered_client.AlteredClient`).
    """

    def __init__(
        self,
        client: httpx.Client | None = None,
        *,
        default_timeout_seconds: float | None = None,
    ) -> None:
        if default_timeout_seconds is not None:
            AlteredNetworkParameterValidator.validate_timeout_seconds(
                default_timeout_seconds
            )
        self._client: httpx.Client = httpx.Client() if client is None else client
        self._owns_client: bool = client is None
        self._owner_shutdown: bool = False
        self._default_timeout_seconds: float | None = default_timeout_seconds

    def send(self, request: ApiRequest) -> ApiResponse:
        """Envoie la requête via HTTPX et renvoie une :class:`ApiResponse`.

        :param request: Requête logique (URL absolue attendue).
        :return: Réponse du socle (y compris codes 4xx/5xx, sans exception).
        :raises TimeoutError: Délai dépassé (normalisé pour ``SyncApiClient``).
        :raises ConnectionError: Erreur réseau bas niveau.
        """
        content = self._body_to_bytes(request.body)
        effective_timeout = request.timeout_seconds
        if effective_timeout is None and self._default_timeout_seconds is not None:
            effective_timeout = self._default_timeout_seconds
        httpx_timeout = (
            effective_timeout
            if effective_timeout is not None
            else httpx.USE_CLIENT_DEFAULT
        )
        httpx_req = self._client.build_request(
            request.method,
            request.path,
            headers=dict(request.headers) if request.headers else None,
            params=dict(request.params) if request.params else None,
            content=content,
            timeout=httpx_timeout,
        )
        try:
            raw = self._client.send(httpx_req)
        except httpx.TimeoutException as exc:
            raise TimeoutError(str(exc)) from exc
        except httpx.RequestError as exc:
            raise ConnectionError(str(exc)) from exc

        hdrs: dict[str, str] | None = dict(raw.headers.items()) if raw.headers else None
        body_bytes = raw.content
        text_body = raw.text
        try:
            elapsed = raw.elapsed.total_seconds()
        except RuntimeError:
            elapsed = None
        api_response = ApiResponse(
            status_code=raw.status_code,
            content=body_bytes,
            headers=hdrs,
            text=text_body,
            elapsed_seconds=elapsed,
            request=request,
        )
        AlteredApiLogger.log_http_roundtrip(request, api_response)
        return api_response

    def close(self) -> None:
        """Ferme le client HTTPX si ce transport en est propriétaire.

        Idempotent : les appels suivants sont sans effet.
        """
        if not self._owns_client:
            return
        if self._owner_shutdown:
            return
        self._client.close()
        self._owner_shutdown = True

    def __enter__(self) -> AlteredSyncTransport:
        """Entrée de context manager sync : retourne ``self``."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Sortie de context manager sync : appelle :meth:`close`."""
        self.close()

    @staticmethod
    def _body_to_bytes(body: Any) -> bytes | None:
        if body is None:
            return None
        if isinstance(body, (bytes, bytearray)):
            return bytes(body)
        if isinstance(body, str):
            return body.encode("utf-8")
        raise TypeError(
            f"request body must be bytes, bytearray, str or None; "
            f"got {type(body).__name__}"
        )
