"""Référentiel type de carte (liste API)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AlteredCardTypeReference:
    """Entrée de référentiel type de carte."""

    code: str | None = None
    name: str | None = None
    raw: Mapping[str, Any] | None = None
