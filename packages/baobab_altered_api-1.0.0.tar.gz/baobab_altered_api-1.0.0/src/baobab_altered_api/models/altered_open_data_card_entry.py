"""Entrée carte dans la hiérarchie Open Data (numéro + résumé)."""

from __future__ import annotations

from dataclasses import dataclass

from baobab_altered_api.models.altered_card_summary import AlteredCardSummary


@dataclass(frozen=True)
class AlteredOpenDataCardEntry:
    """Carte positionnée dans un set/faction avec numéro d'édition optionnel.

    :ivar card: Résumé carte mappé depuis l'export.
    :ivar number: Numéro dans le set (chaîne normalisée), si présent.
    """

    card: AlteredCardSummary
    number: str | None = None

    def __post_init__(self) -> None:
        if self.number is None:
            return
        stripped = self.number.strip()
        object.__setattr__(self, "number", stripped or None)
