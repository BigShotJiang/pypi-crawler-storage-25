"""Page typée de résultats (items + métadonnées de continuation)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Generic, TypeVar

T = TypeVar("T")


@dataclass(frozen=True)
class AlteredPage(Generic[T]):
    """Ensemble immuable d'éléments et indices de pagination côté réponse.

    :ivar items: Éléments de la page courante.
    :ivar total_count: Total logique si l'API l'expose ; sinon ``None``.
    :ivar next_cursor: Curseur pour la page suivante, si applicable.
    :ivar previous_cursor: Curseur pour la page précédente, si applicable.
    :ivar has_next_page: Indication booléenne lorsque l'API l'expose.
    :ivar raw: Fragment JSON non modélisé (totaux alternatifs, liens, etc.).
    """

    items: tuple[T, ...]
    total_count: int | None = None
    next_cursor: str | None = None
    previous_cursor: str | None = None
    has_next_page: bool | None = None
    raw: Mapping[str, Any] | None = None
