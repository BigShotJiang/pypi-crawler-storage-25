"""Paramètres de pagination pour requêtes client (page, taille, curseur)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar


@dataclass(frozen=True)
class AlteredPaginationParams:
    """Bornes de pagination alignées sur les usages offset / curseur.

    ``page`` et ``cursor`` sont **mutuellement exclusifs** : une requête ne
    combine pas numéro de page et jeton de curseur dans ce modèle minimal.

    :ivar limit: Nombre maximal d'éléments par page (>= 1, plafonné).
    :ivar page: Numéro de page commençant à 1 ; ``None`` si mode curseur.
    :ivar cursor: Jeton opaque de continuation ; ``None`` si mode page.
    :ivar max_iterations_guard: Plafond documentaire pour boucles client
        (auto-pagination) ; ne force aucun appel HTTP par lui-même.

    .. note::
        Les noms de champs restent indicatifs ; voir
        ``docs/api_observations/pagination.md``.
    """

    MAX_LIMIT: ClassVar[int] = 100
    DEFAULT_LIMIT: ClassVar[int] = 20
    DEFAULT_MAX_ITERATIONS_GUARD: ClassVar[int] = 50

    limit: int = DEFAULT_LIMIT
    page: int | None = None
    cursor: str | None = None
    max_iterations_guard: int = DEFAULT_MAX_ITERATIONS_GUARD

    def __post_init__(self) -> None:
        if self.limit < 1:
            msg = "limit must be >= 1"
            raise ValueError(msg)
        if self.limit > self.MAX_LIMIT:
            msg = f"limit must be <= {self.MAX_LIMIT}"
            raise ValueError(msg)
        if self.page is not None and self.page < 1:
            msg = "page must be >= 1 when provided"
            raise ValueError(msg)
        if self.cursor is not None:
            stripped = self.cursor.strip()
            if not stripped:
                msg = "cursor must be non-empty when provided"
                raise ValueError(msg)
            if stripped != self.cursor:
                object.__setattr__(self, "cursor", stripped)
        if self.page is not None and self.cursor is not None:
            msg = "page and cursor are mutually exclusive"
            raise ValueError(msg)
        if self.max_iterations_guard < 1:
            msg = "max_iterations_guard must be >= 1"
            raise ValueError(msg)
