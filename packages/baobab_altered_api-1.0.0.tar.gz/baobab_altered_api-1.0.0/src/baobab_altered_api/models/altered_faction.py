"""Faction ou maison associée à une carte ou à un deck."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_ref import AlteredRef


@dataclass(frozen=True)
class AlteredFaction:
    """Bloc métier minimal pour une faction.

    Tous les champs peuvent être absents si l'API ne renvoie qu'un fragment
    partiel : les mappers peuvent alors peupler ``raw`` en attendant un schéma
    stable.

    :ivar ref: Identifiant stable de la faction, si disponible.
    :ivar name: Nom court ou code affichable.
    :ivar raw: Champs additionnels non encore modélisés.
    """

    ref: AlteredRef | None = None
    name: str | None = None
    raw: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.name is None:
            return
        stripped = self.name.strip()
        object.__setattr__(self, "name", stripped or None)
