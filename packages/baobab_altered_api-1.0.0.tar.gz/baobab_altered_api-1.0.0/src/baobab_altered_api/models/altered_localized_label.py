"""Libellé affichable avec variantes linguistiques optionnelles."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass


@dataclass(frozen=True)
class AlteredLocalizedLabel:
    """Texte de présentation avec dictionnaire de traductions optionnel.

    Les clés de ``by_locale`` suivent typiquement des tags BCP-47 (ex.
    ``\"fr-FR\"``, ``\"en-US\"``) ; ce contrat reste indicatif tant que le
    schéma officiel Altered n'est pas figé dans la documentation produit.

    :ivar default: Libellé de repli lorsque la locale demandée est absente.
    :ivar by_locale: Carte locale → texte ; ``None`` si non fournie par l'API.
    """

    default: str
    by_locale: Mapping[str, str] | None = None

    def __post_init__(self) -> None:
        normalized = self.default.strip()
        if not normalized:
            msg = "AlteredLocalizedLabel.default must be non-empty after strip"
            raise ValueError(msg)
        object.__setattr__(self, "default", normalized)
