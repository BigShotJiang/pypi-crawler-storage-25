"""Nœud faction dans l'export Open Data hiérarchique."""

from __future__ import annotations

from dataclasses import dataclass

from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_open_data_card_entry import (
    AlteredOpenDataCardEntry,
)


@dataclass(frozen=True)
class AlteredOpenDataFactionNode:
    """Faction regroupant des cartes dans un set Open Data.

    :ivar faction: Métadonnées faction.
    :ivar cards: Cartes ordonnées sous cette faction.
    """

    faction: AlteredFaction
    cards: tuple[AlteredOpenDataCardEntry, ...] = ()
