"""Référence stable non vide pour des identifiants côté API Altered."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AlteredRef:
    """Identifiant logique Altered (slug, UUID ou autre jeton exposé par l'API).

    La valeur est normalisée (espaces de tête et de queue supprimés) et ne
    peut pas être vide : les appelants qui ne disposent pas encore d'une
    référence doivent utiliser ``None`` au niveau du champ parent plutôt qu'une
    instance vide.

    :ivar value: Jeton non vide après normalisation.
    """

    value: str

    def __post_init__(self) -> None:
        normalized = self.value.strip()
        if not normalized:
            msg = "AlteredRef.value must be non-empty after strip"
            raise ValueError(msg)
        object.__setattr__(self, "value", normalized)
