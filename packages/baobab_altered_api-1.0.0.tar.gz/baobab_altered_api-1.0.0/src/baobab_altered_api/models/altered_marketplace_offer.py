"""Offre marketplace en lecture seule (aucune donnée personnelle persistée)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_ref import AlteredRef


@dataclass(frozen=True)
class AlteredMarketplaceOffer:
    """Offre listée sans encourager la persistance de données vendeur.

    :ivar ref: Identifiant d'offre.
    :ivar card_ref: Carte concernée.
    :ivar price_amount: Montant entier (unité API, ex. centimes) si connu.
    :ivar price_currency: Code devise ISO (ex. ``EUR``).
    :ivar seller_label: Libellé public non sensible optionnel.
    :ivar raw: Champs additionnels.
    """

    ref: AlteredRef
    card_ref: AlteredRef | None = None
    price_amount: int | None = None
    price_currency: str | None = None
    seller_label: str | None = None
    raw: Mapping[str, Any] | None = None
