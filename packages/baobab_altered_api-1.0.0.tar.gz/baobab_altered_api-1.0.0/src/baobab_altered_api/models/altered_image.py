"""Référence visuelle minimale pour illustrations ou icônes."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AlteredImage:
    """Pointeur vers un visuel sans téléchargement ni validation HTTP.

    Les champs restent volontairement optionnels pour tolérer les réponses
    partielles de l'API. Le fragment ``raw`` permet aux mappers futurs de
    conserver des clés non encore modélisées.

    :ivar url: URL HTTP(S) ou chemin logique ; ``None`` si absent.
    :ivar raw: Données source additionnelles (résolutions, variantes, etc.).
    """

    url: str | None = None
    raw: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.url is None:
            return
        stripped = self.url.strip()
        object.__setattr__(self, "url", stripped or None)
