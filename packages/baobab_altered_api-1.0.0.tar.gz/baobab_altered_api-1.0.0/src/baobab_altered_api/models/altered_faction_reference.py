"""Référentiel faction (liste API)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_ref import AlteredRef


@dataclass(frozen=True)
class AlteredFactionReference:
    """Entrée de référentiel faction."""

    ref: AlteredRef | None = None
    name: str | None = None
    raw: Mapping[str, Any] | None = None
