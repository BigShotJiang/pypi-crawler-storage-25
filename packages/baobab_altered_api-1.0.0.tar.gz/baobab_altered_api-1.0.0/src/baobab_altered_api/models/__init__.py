"""Modèles de domaine Altered."""

from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_image import AlteredImage
from baobab_altered_api.models.altered_json_payload import AlteredJsonPayload
from baobab_altered_api.models.altered_localized_label import AlteredLocalizedLabel
from baobab_altered_api.models.altered_page import AlteredPage
from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams
from baobab_altered_api.models.altered_rarity import AlteredRarity
from baobab_altered_api.models.altered_ref import AlteredRef
from baobab_altered_api.models.altered_set import AlteredSet

__all__: tuple[str, ...] = (
    "AlteredCardSummary",
    "AlteredFaction",
    "AlteredImage",
    "AlteredJsonPayload",
    "AlteredLocalizedLabel",
    "AlteredPage",
    "AlteredPaginationParams",
    "AlteredRarity",
    "AlteredRef",
    "AlteredSet",
)
