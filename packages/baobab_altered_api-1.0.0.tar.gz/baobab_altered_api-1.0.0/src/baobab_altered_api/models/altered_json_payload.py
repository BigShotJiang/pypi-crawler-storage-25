"""Modèle de données pour un payload JSON normalisé côté transport."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class AlteredJsonPayload:
    """Résultat d'un parsing JSON « succès » pour les couches ressources.

    :param data: Objet JSON racine (mapping ou liste).
    :param pagination: Indices de pagination non sensibles (ex. en-têtes),
        ou ``None`` si aucun indice n'a été détecté.
    """

    data: Mapping[str, Any] | list[Any]
    pagination: Mapping[str, Any] | None
