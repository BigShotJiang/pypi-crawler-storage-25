"""Vue résumée d'une carte pour listes, aperçus ou références croisées."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_image import AlteredImage
from baobab_altered_api.models.altered_rarity import AlteredRarity
from baobab_altered_api.models.altered_ref import AlteredRef
from baobab_altered_api.models.altered_set import AlteredSet


@dataclass(frozen=True)
class AlteredCardSummary:
    """Sous-ensemble typé des informations carte encore sans ressource HTTP dédiée.

    Le champ ``expansion`` porte une :class:`~.altered_set.AlteredSet` afin
    d'éviter l'ombre du nom ``set`` sur le type builtin Python.

    :ivar ref: Référence obligatoire de la carte.
    :ivar name: Titre ou nom d'affichage optionnel.
    :ivar faction: Faction optionnelle.
    :ivar expansion: Extension / série optionnelle.
    :ivar rarity: Rareté optionnelle.
    :ivar image: Visuel optionnel.
    :ivar raw: Fragment JSON tolérant les champs inconnus des mappers.
    """

    ref: AlteredRef
    name: str | None = None
    faction: AlteredFaction | None = None
    expansion: AlteredSet | None = None
    rarity: AlteredRarity | None = None
    image: AlteredImage | None = None
    raw: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.name is None:
            return
        stripped = self.name.strip()
        object.__setattr__(self, "name", stripped or None)
