"""Référentiel extension / set (liste API)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_ref import AlteredRef


@dataclass(frozen=True)
class AlteredSetReference:
    """Entrée de référentiel « set » pour filtres et UI.

    :ivar ref: Identifiant stable optionnel.
    :ivar code: Code court optionnel.
    :ivar name: Libellé optionnel.
    :ivar raw: Champs non modélisés.
    """

    ref: AlteredRef | None = None
    code: str | None = None
    name: str | None = None
    raw: Mapping[str, Any] | None = None
