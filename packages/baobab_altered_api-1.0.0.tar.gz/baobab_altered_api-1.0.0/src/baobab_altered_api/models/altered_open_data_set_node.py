"""Nœud set / extension dans l'export Open Data hiérarchique."""

from __future__ import annotations

from dataclasses import dataclass

from baobab_altered_api.models.altered_open_data_faction_node import (
    AlteredOpenDataFactionNode,
)
from baobab_altered_api.models.altered_set import AlteredSet


@dataclass(frozen=True)
class AlteredOpenDataSetNode:
    """Extension avec factions et cartes imbriquées.

    :ivar expansion: Métadonnées set/extension.
    :ivar factions: Factions du set.
    """

    expansion: AlteredSet
    factions: tuple[AlteredOpenDataFactionNode, ...] = ()
