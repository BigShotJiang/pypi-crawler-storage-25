"""Extension / série (« set ») pour regrouper des cartes."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_ref import AlteredRef


@dataclass(frozen=True)
class AlteredSet:
    """Bloc d'extension ou de série Altered.

    :ivar ref: Référence stable de l'extension.
    :ivar code: Code court éventuellement exposé par l'API.
    :ivar name: Nom marketing ou interne.
    :ivar raw: Champs additionnels non modélisés.
    """

    ref: AlteredRef | None = None
    code: str | None = None
    name: str | None = None
    raw: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.code is not None:
            c = self.code.strip()
            object.__setattr__(self, "code", c or None)
        if self.name is not None:
            n = self.name.strip()
            object.__setattr__(self, "name", n or None)
