"""Snapshot Open Data local (export JSON hiérarchique)."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_open_data_set_node import AlteredOpenDataSetNode


@dataclass(frozen=True)
class AlteredOpenDataSnapshot:
    """Vue en mémoire d'un export Open Data chargé depuis fichier ou réseau.

    :ivar version: Version du schéma export si présente.
    :ivar cards: Cartes aplaties (liste plate et/ou hiérarchie).
    :ivar sets: Arborescence Set → Faction → Carte si présente dans l'export.
    :ivar raw: Racine JSON complète pour extensions futures.
    """

    version: int | None = None
    cards: tuple[AlteredCardSummary, ...] = ()
    sets: tuple[AlteredOpenDataSetNode, ...] = ()
    raw: Mapping[str, Any] | None = None

    def card_by_ref(self, ref_value: str) -> AlteredCardSummary | None:
        """Recherche linéaire par valeur de référence (index léger)."""
        for card in self.cards:
            if card.ref.value == ref_value:
                return card
        return None

    def iter_cards(self) -> Iterator[AlteredCardSummary]:
        """Parcourt toutes les cartes du snapshot (ordre d'insertion)."""
        yield from self.cards
