"""Deck Altered en lecture seule."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from baobab_altered_api.models.altered_ref import AlteredRef


@dataclass(frozen=True)
class AlteredDeckCardLine:
    """Ligne carte dans un deck (référence + quantité)."""

    card_ref: AlteredRef
    quantity: int = 1

    def __post_init__(self) -> None:
        if self.quantity < 1:
            msg = "quantity must be >= 1"
            raise ValueError(msg)


@dataclass(frozen=True)
class AlteredDeck:
    """Deck typé minimal (lecture seule).

    :ivar ref: Identifiant du deck.
    :ivar name: Nom affiché optionnel.
    :ivar cards: Lignes carte.
    :ivar raw: Fragment JSON additionnel.
    """

    ref: AlteredRef
    name: str | None = None
    cards: tuple[AlteredDeckCardLine, ...] = ()
    raw: Mapping[str, Any] | None = None
