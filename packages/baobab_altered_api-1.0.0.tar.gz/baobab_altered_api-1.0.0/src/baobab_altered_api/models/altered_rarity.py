"""Rareté de carte telle qu'exposée par les référentiels Altered."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AlteredRarity:
    """Code et libellé optionnels pour une rareté.

    :ivar code: Identifiant ou slug de rareté.
    :ivar name: Libellé humain optionnel.
    :ivar raw: Champs additionnels conservés pour évolution de schéma.
    """

    code: str | None = None
    name: str | None = None
    raw: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.code is not None:
            c = self.code.strip()
            object.__setattr__(self, "code", c or None)
        if self.name is not None:
            n = self.name.strip()
            object.__setattr__(self, "name", n or None)
