"""Locales supportées pour les en-têtes HTTP Altered."""

from __future__ import annotations

from enum import StrEnum


class AlteredLocale(StrEnum):
    """Valeurs de locale documentées pour l'API Altered."""

    FR_FR = "fr-fr"
    EN_US = "en-us"
    FR = "fr"
    EN = "en"

    def accept_language_value(self) -> str:
        """Retourne la valeur ``Accept-Language`` associée à la locale.

        :return: Code langue normalisé pour l'en-tête HTTP.
        """
        mapping = {
            AlteredLocale.FR_FR: "fr-FR",
            AlteredLocale.EN_US: "en-US",
            AlteredLocale.FR: "fr",
            AlteredLocale.EN: "en",
        }
        return mapping[self]
