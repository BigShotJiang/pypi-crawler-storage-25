"""Configuration immuable du client API Altered."""

from __future__ import annotations

# ``from_environment`` appelle ``env_loader`` ; pylint R0401 sur le graphe d'imports.
# pylint: disable=cyclic-import

from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from importlib.metadata import PackageNotFoundError, version
from typing import Any

from baobab_altered_api.config.altered_locale import AlteredLocale
from baobab_altered_api.config.altered_network_parameter_validator import (
    AlteredNetworkParameterValidator,
)
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


def _default_user_agent() -> str:
    """Construit un ``User-Agent`` par défaut à partir de la version du package."""
    try:
        ver = version("baobab-altered-api")
    except PackageNotFoundError:
        ver = "0.1.0"
    return f"baobab-altered-api/{ver}"


@dataclass(frozen=True)
class AlteredApiConfig:  # pylint: disable=too-many-instance-attributes
    """Paramètres Altered immuables pour instancier les clients de la librairie.

    Aucune variable d'environnement n'est lue à l'instanciation directe :
    utilisez :meth:`from_environment` ou
    :func:`~baobab_altered_api.config.env_loader.load_config_from_env` pour un
    chargement explicite.

    :ivar base_url: URL de base HTTP(S) sans identifiants dans l'autorité.
    :ivar locale: Locale pour les en-têtes ``Accept-Language``.
    :ivar user_agent: Valeur du ``User-Agent`` (non vide).
    :ivar api_key: Clé API optionnelle (incompatible avec ``bearer_token``).
    :ivar bearer_token: Jeton Bearer optionnel (incompatible avec ``api_key``).
    :ivar api_key_header_name: Nom d'en-tête pour ``api_key`` si envoi en header.
    :ivar api_key_query_param: Si non ``None``, envoie la clé en query sous ce nom.
    :ivar timeout_seconds: Délai global HTTP en secondes (> 0).
    :ivar retry_max_attempts: Nombre maximal de tentatives (>= 1, plafonné).
    :ivar retry_backoff_seconds: Backoff initial entre tentatives (>= 0).
    :ivar retry_jitter: Active le jitter réseau sur le backoff du socle
        (désactivable pour des tests déterministes).
    :ivar rate_limit_per_second: Limite optionnelle req/s (> 0 si défini).
    :ivar open_data_url: URL Open Data optionnelle (HTTP(S), sans identifiants).
    """

    base_url: str = "https://api.altered.gg"
    locale: AlteredLocale = AlteredLocale.FR_FR
    user_agent: str = field(default_factory=_default_user_agent)
    api_key: str | None = None
    bearer_token: str | None = None
    api_key_header_name: str = "X-API-Key"
    api_key_query_param: str | None = None
    timeout_seconds: float = 30.0
    retry_max_attempts: int = 3
    retry_backoff_seconds: float = 0.5
    retry_jitter: bool = True
    rate_limit_per_second: float | None = None
    open_data_url: str | None = None

    def __post_init__(self) -> None:  # pylint: disable=too-many-branches
        normalized_base = AlteredNetworkParameterValidator.normalize_http_url(
            self.base_url, field_label="base_url"
        )
        if normalized_base != self.base_url:
            object.__setattr__(self, "base_url", normalized_base)

        ua = AlteredNetworkParameterValidator.validate_non_empty_user_agent(
            self.user_agent
        )
        if ua != self.user_agent:
            object.__setattr__(self, "user_agent", ua)

        if not isinstance(self.locale, AlteredLocale):
            raise AlteredConfigError(
                f"locale must be AlteredLocale, got {type(self.locale).__name__}"
            )

        if self.api_key is not None and self.bearer_token is not None:
            raise AlteredConfigError(
                "api_key and bearer_token cannot both be set; choose one auth mode"
            )

        if self.api_key is not None:
            key = self.api_key.strip()
            if not key:
                raise AlteredConfigError("api_key must be non-empty when provided")
            object.__setattr__(self, "api_key", key)
            hn = self.api_key_header_name.strip()
            if not hn:
                raise AlteredConfigError("api_key_header_name must be non-empty")
            object.__setattr__(self, "api_key_header_name", hn)
            if self.api_key_query_param is not None:
                qp = self.api_key_query_param.strip()
                if not qp:
                    raise AlteredConfigError(
                        "api_key_query_param must be non-empty when provided"
                    )
                object.__setattr__(self, "api_key_query_param", qp)

        if self.bearer_token is not None:
            tok = self.bearer_token.strip()
            if not tok:
                raise AlteredConfigError("bearer_token must be non-empty when provided")
            object.__setattr__(self, "bearer_token", tok)

        AlteredNetworkParameterValidator.validate_timeout_seconds(self.timeout_seconds)
        AlteredNetworkParameterValidator.validate_retry_max_attempts(
            self.retry_max_attempts
        )
        AlteredNetworkParameterValidator.validate_retry_backoff_seconds(
            self.retry_backoff_seconds
        )
        if not isinstance(self.retry_jitter, bool):
            raise AlteredConfigError(
                f"retry_jitter must be bool, got {type(self.retry_jitter).__name__}"
            )
        AlteredNetworkParameterValidator.validate_optional_rate_limit(
            self.rate_limit_per_second
        )

        if self.open_data_url is not None:
            od = self.open_data_url.strip()
            if not od:
                raise AlteredConfigError(
                    "open_data_url must be non-empty when provided"
                )
            normalized_od = AlteredNetworkParameterValidator.normalize_http_url(
                od, field_label="open_data_url"
            )
            object.__setattr__(self, "open_data_url", normalized_od)

    @classmethod
    def from_environment(cls, env: Mapping[str, str] | None = None) -> AlteredApiConfig:
        """Construit une configuration depuis les variables ``ALTERED_API_*``.

        Délègue à :func:`~baobab_altered_api.config.env_loader.load_config_from_env`
        (même comportement ; alias prévu par la feature FEAT-002).

        :param env: Mapping optionnel (tests, CI). Si ``None``, utilise
            :data:`os.environ`.
        :return: Instance validée.
        """
        # Import local : ``env_loader`` importe déjà ``AlteredApiConfig``.
        # pylint: disable-next=import-outside-toplevel
        from baobab_altered_api.config.env_loader import load_config_from_env

        return load_config_from_env(env)

    def copy_with(self, **overrides: Any) -> AlteredApiConfig:
        """Retourne une copie en remplaçant les champs nommés.

        :param overrides: Champs à surcharger.
        :return: Nouvelle instance immuable validée.
        """
        return replace(self, **overrides)

    def __repr__(self) -> str:
        """Résumé des champs non sensibles ; masque clé API et bearer.

        :return: Chaîne ``AlteredApiConfig(...)`` avec secrets remplacés par
            ``<redacted>``.
        """
        api_key_frag = "None" if self.api_key is None else "<redacted>"
        bearer_frag = "None" if self.bearer_token is None else "<redacted>"
        rate_frag = repr(self.rate_limit_per_second)
        open_frag = repr(self.open_data_url)
        return (
            f"AlteredApiConfig(base_url={self.base_url!r}, locale={self.locale!r}, "
            f"user_agent={self.user_agent!r}, api_key={api_key_frag}, "
            f"bearer_token={bearer_frag}, "
            f"api_key_header_name={self.api_key_header_name!r}, "
            f"api_key_query_param={self.api_key_query_param!r}, "
            f"timeout_seconds={self.timeout_seconds!r}, "
            f"retry_max_attempts={self.retry_max_attempts!r}, "
            f"retry_backoff_seconds={self.retry_backoff_seconds!r}, "
            f"retry_jitter={self.retry_jitter!r}, "
            f"rate_limit_per_second={rate_frag}, open_data_url={open_frag})"
        )

    def __str__(self) -> str:
        """Affichage aligné sur :meth:`__repr__` (aucune fuite de secret).

        :return: Identique à :meth:`__repr__`.
        """
        return self.__repr__()
