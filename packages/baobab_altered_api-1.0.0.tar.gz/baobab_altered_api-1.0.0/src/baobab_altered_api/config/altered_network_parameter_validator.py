"""Validation des paramètres réseau et numériques de configuration."""

from __future__ import annotations

import math
from typing import Final

from baobab_api_call import ApiClientConfig
from baobab_api_call.exceptions import ApiConfigError

from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError

_DEFAULT_FIELD_LABEL: Final[str] = "base_url"

# Borne supérieure prudente : évite des boucles de retry excessives côté client.
MAX_RETRY_ATTEMPTS: Final[int] = 50


class AlteredNetworkParameterValidator:
    """Valide et normalise les paramètres réseau réutilisables par la configuration."""

    @staticmethod
    def normalize_http_url(raw: str, *, field_label: str = _DEFAULT_FIELD_LABEL) -> str:
        """Valide une URL HTTP(S) sans identifiants et retourne la forme normalisée.

        Délègue aux règles du socle ``baobab-api-call`` via :class:`ApiClientConfig`.

        :param raw: URL brute non vide.
        :param field_label: Nom du champ pour les messages d'erreur.
        :return: URL normalisée.
        :raises AlteredConfigError: Si l'URL est invalide ou contient des identifiants.
        """
        try:
            return ApiClientConfig(base_url=raw.strip()).base_url
        except (ApiConfigError, ValueError) as exc:
            raise AlteredConfigError(
                f"{field_label}: configuration réseau invalide ({exc})"
            ) from exc

    @staticmethod
    def validate_non_empty_user_agent(value: str) -> str:
        """Valide que le ``User-Agent`` est une chaîne non vide après ``strip``.

        :param value: Valeur brute du ``User-Agent``.
        :return: Chaîne sans espaces en tête ni en queue.
        :raises AlteredConfigError: Si la valeur est vide ou ne contient que des
            espaces.
        """
        cleaned = value.strip()
        if not cleaned:
            raise AlteredConfigError("user_agent must be a non-empty string")
        return cleaned

    @staticmethod
    def validate_timeout_seconds(value: float) -> None:
        """Vérifie que le délai global est strictement positif et fini.

        :param value: Délai en secondes (entier ou flottant, ``bool`` refusé).
        :raises AlteredConfigError: Si le type est invalide, la valeur n'est pas
            finie ou n'est pas strictement positive.
        """
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise AlteredConfigError(
                f"timeout_seconds must be a number, got {type(value).__name__}"
            )
        if not math.isfinite(float(value)) or float(value) <= 0:
            raise AlteredConfigError("timeout_seconds must be a finite number > 0")

    @staticmethod
    def validate_retry_max_attempts(value: int) -> None:
        """Vérifie le nombre maximal de tentatives (>= 1).

        :param value: Nombre de tentatives (entier, ``bool`` refusé).
        :raises AlteredConfigError: Si le type est invalide ou la valeur est < 1.
        """
        if not isinstance(value, int) or isinstance(value, bool):
            raise AlteredConfigError(
                f"retry_max_attempts must be int, got {type(value).__name__}"
            )
        if value < 1:
            raise AlteredConfigError("retry_max_attempts must be >= 1")
        if value > MAX_RETRY_ATTEMPTS:
            raise AlteredConfigError(
                f"retry_max_attempts must be <= {MAX_RETRY_ATTEMPTS} "
                "(borne prudente anti-surcharge de l'API)"
            )

    @staticmethod
    def validate_retry_backoff_seconds(value: float) -> None:
        """Vérifie que le backoff initial est fini et positif ou nul.

        :param value: Délai initial entre tentatives (secondes).
        :raises AlteredConfigError: Si le type est invalide, la valeur n'est pas
            finie ou est strictement négative.
        """
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise AlteredConfigError(
                f"retry_backoff_seconds must be a number, got {type(value).__name__}"
            )
        if not math.isfinite(float(value)) or float(value) < 0:
            raise AlteredConfigError(
                "retry_backoff_seconds must be a finite number >= 0"
            )

    @staticmethod
    def validate_optional_rate_limit(value: float | None) -> None:
        """Vérifie la limite de débit optionnelle (positive si renseignée).

        :param value: Limite en requêtes par seconde, ou ``None`` si désactivée.
        :raises AlteredConfigError: Si la valeur n'est ni ``None`` ni un nombre fini
            strictement positif (``bool`` refusé).
        """
        if value is None:
            return
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            msg = (
                "rate_limit_per_second must be a number or None, "
                f"got {type(value).__name__}"
            )
            raise AlteredConfigError(msg)
        if not math.isfinite(float(value)) or float(value) <= 0:
            raise AlteredConfigError(
                "rate_limit_per_second must be a finite number > 0 when set"
            )
