"""Chargement explicite d'``AlteredApiConfig`` depuis l'environnement."""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Final, TypedDict

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.config.altered_locale import AlteredLocale
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError

_ENV_BASE_URL: Final[str] = "ALTERED_API_BASE_URL"
_ENV_LOCALE: Final[str] = "ALTERED_API_LOCALE"
_ENV_USER_AGENT: Final[str] = "ALTERED_API_USER_AGENT"
_ENV_API_KEY: Final[str] = "ALTERED_API_KEY"
_ENV_BEARER_TOKEN: Final[str] = "ALTERED_API_BEARER_TOKEN"
_ENV_TIMEOUT: Final[str] = "ALTERED_API_TIMEOUT_SECONDS"
_ENV_RETRY: Final[str] = "ALTERED_API_RETRY_MAX_ATTEMPTS"
_ENV_BACKOFF: Final[str] = "ALTERED_API_RETRY_BACKOFF_SECONDS"
_ENV_RETRY_JITTER: Final[str] = "ALTERED_API_RETRY_JITTER"
_ENV_RATE: Final[str] = "ALTERED_API_RATE_LIMIT_PER_SECOND"
_ENV_OPEN_DATA: Final[str] = "ALTERED_API_OPEN_DATA_URL"
_ENV_KEY_HEADER: Final[str] = "ALTERED_API_KEY_HEADER"
_ENV_KEY_QUERY: Final[str] = "ALTERED_API_KEY_QUERY_PARAM"


class _AlteredApiConfigEnvOverrides(TypedDict, total=False):
    """Champs optionnels d'``AlteredApiConfig`` issus des variables d'environnement."""

    base_url: str
    locale: AlteredLocale
    user_agent: str
    api_key: str | None
    bearer_token: str | None
    timeout_seconds: float
    retry_max_attempts: int
    retry_backoff_seconds: float
    retry_jitter: bool
    rate_limit_per_second: float | None
    open_data_url: str | None
    api_key_header_name: str
    api_key_query_param: str | None


def _parse_float(raw: str, *, label: str) -> float:
    try:
        return float(raw.strip())
    except ValueError as exc:
        raise AlteredConfigError(f"{label}: invalid numeric value") from exc


def _parse_int(raw: str, *, label: str) -> int:
    try:
        return int(raw.strip(), 10)
    except ValueError as exc:
        raise AlteredConfigError(f"{label}: invalid integer value") from exc


def _parse_bool(raw: str, *, label: str) -> bool:
    key = raw.strip().lower()
    if key in ("1", "true", "yes", "on"):
        return True
    if key in ("0", "false", "no", "off"):
        return False
    raise AlteredConfigError(f"{label}: expected boolean (e.g. true/false, 1/0)")


def _parse_locale(raw: str) -> AlteredLocale:
    key = raw.strip().lower().replace("_", "-")
    for member in AlteredLocale:
        if member.value == key:
            return member
    raise AlteredConfigError(f"ALTERED_API_LOCALE: unsupported locale {raw!r}")


def load_config_from_env(  # pylint: disable=too-many-locals,too-many-branches
    env: Mapping[str, str] | None = None,
) -> AlteredApiConfig:
    """Lit les variables ``ALTERED_API_*`` et construit une configuration.

    L'appel est **explicite** : aucune lecture n'est effectuée à l'import de ce module.

    :param env: Mapping à utiliser (ex. pour les tests). Si ``None``, utilise
        :data:`os.environ`.
    :return: Instance :class:`AlteredApiConfig` validée.
    :raises AlteredConfigError: Valeur invalide ou combinaison interdite.
    """
    source: Mapping[str, str] = os.environ if env is None else env

    def get(name: str) -> str | None:
        val = source.get(name)
        if val is None:
            return None
        stripped = val.strip()
        return stripped or None

    kwargs: _AlteredApiConfigEnvOverrides = {}

    if (b := get(_ENV_BASE_URL)) is not None:
        kwargs["base_url"] = b
    if (loc := get(_ENV_LOCALE)) is not None:
        kwargs["locale"] = _parse_locale(loc)
    if (ua := get(_ENV_USER_AGENT)) is not None:
        kwargs["user_agent"] = ua

    api_key = get(_ENV_API_KEY)
    bearer = get(_ENV_BEARER_TOKEN)
    if api_key is not None and bearer is not None:
        raise AlteredConfigError(
            "Cannot set both ALTERED_API_KEY and ALTERED_API_BEARER_TOKEN"
        )
    if api_key is not None:
        kwargs["api_key"] = api_key
    if bearer is not None:
        kwargs["bearer_token"] = bearer

    if (ts := get(_ENV_TIMEOUT)) is not None:
        kwargs["timeout_seconds"] = _parse_float(ts, label=_ENV_TIMEOUT)
    if (rm := get(_ENV_RETRY)) is not None:
        kwargs["retry_max_attempts"] = _parse_int(rm, label=_ENV_RETRY)
    if (bo := get(_ENV_BACKOFF)) is not None:
        kwargs["retry_backoff_seconds"] = _parse_float(bo, label=_ENV_BACKOFF)
    if (jit := get(_ENV_RETRY_JITTER)) is not None:
        kwargs["retry_jitter"] = _parse_bool(jit, label=_ENV_RETRY_JITTER)
    if (rl := get(_ENV_RATE)) is not None:
        kwargs["rate_limit_per_second"] = _parse_float(rl, label=_ENV_RATE)
    if (odu := get(_ENV_OPEN_DATA)) is not None:
        kwargs["open_data_url"] = odu
    if (kh := get(_ENV_KEY_HEADER)) is not None:
        kwargs["api_key_header_name"] = kh
    if (kq := get(_ENV_KEY_QUERY)) is not None:
        kwargs["api_key_query_param"] = kq

    return AlteredApiConfig(**kwargs)
