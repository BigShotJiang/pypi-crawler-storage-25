"""Conversion ``AlteredApiConfig`` vers ``ApiClientConfig`` (baobab-api-call)."""

from __future__ import annotations

from baobab_api_call import ApiClientConfig, RetryPolicy
from baobab_api_call.middleware import Middleware, MiddlewareAsync

from baobab_altered_api.config.altered_api_config import AlteredApiConfig


class AlteredApiClientConfigBuilder:
    """Construit un ``ApiClientConfig`` à partir d'un ``AlteredApiConfig``."""

    @staticmethod
    def build(config: AlteredApiConfig) -> ApiClientConfig:
        """Produit la configuration du socle ``baobab-api-call``.

        Les en-têtes par défaut incluent ``User-Agent``, ``Accept`` et
        ``Accept-Language``. ``timeout_seconds`` et la :class:`RetryPolicy`
        (tentatives, backoff initial, jitter) sont alignés sur le socle.
        Si ``rate_limit_per_second`` est défini, des middlewares sync et async
        espacent les envois côté client (pacing local ; voir
        ``altered_rate_limit_middleware``). Les réponses ``429`` serveur restent
        traitées par le socle et le mapping d'exceptions Altered.

        :param config: Source Altered validée.
        :return: Instance immuable du socle.
        """
        default_headers: dict[str, str] = {
            "User-Agent": config.user_agent,
            "Accept": "application/json",
            "Accept-Language": config.locale.accept_language_value(),
        }
        retry_policy = RetryPolicy(
            max_attempts=int(config.retry_max_attempts),
            backoff_initial=float(config.retry_backoff_seconds),
            jitter=bool(config.retry_jitter),
        )
        # Import local pour éviter un cycle config → auth → config.
        # pylint: disable-next=import-outside-toplevel
        from baobab_altered_api.auth.altered_auth_factory import (
            AlteredAuthFactory,
        )

        # Import local : middlewares dépendent du transport, pas de l'auth.
        # pylint: disable-next=import-outside-toplevel
        from baobab_altered_api.transports.altered_rate_limit_middleware import (
            AlteredRateLimitMiddleware,
        )

        # pylint: disable-next=import-outside-toplevel
        from baobab_altered_api.transports.altered_rate_limit_middleware_async import (
            AlteredRateLimitMiddlewareAsync,
        )

        auth_strategy = AlteredAuthFactory().create(config)
        sync_middlewares: tuple[Middleware, ...] = ()
        async_middlewares: tuple[MiddlewareAsync, ...] = ()
        if config.rate_limit_per_second is not None:
            rps = float(config.rate_limit_per_second)
            sync_middlewares = (AlteredRateLimitMiddleware(max_per_second=rps),)
            async_middlewares = (AlteredRateLimitMiddlewareAsync(max_per_second=rps),)

        return ApiClientConfig(
            base_url=config.base_url,
            default_headers=default_headers,
            timeout_seconds=float(config.timeout_seconds),
            retry_policy=retry_policy,
            auth_strategy=auth_strategy,
            middlewares=sync_middlewares,
            async_middlewares=async_middlewares,
        )


def to_api_client_config(config: AlteredApiConfig) -> ApiClientConfig:
    """Convertit une configuration Altered en :class:`ApiClientConfig`.

    :param config: Configuration applicative Altered.
    :return: Configuration du client HTTP générique.
    """
    return AlteredApiClientConfigBuilder.build(config)
