"""Authentification Altered compatible avec le socle ``baobab-api-call``."""

from baobab_altered_api.auth.altered_auth_factory import AlteredAuthFactory

__all__ = ("AlteredAuthFactory",)
