"""Fabrique d'authentification pour le socle ``baobab-api-call``."""

from __future__ import annotations

from baobab_api_call import ApiKeyAuth, AuthStrategy, BearerAuth

from baobab_altered_api.config.altered_api_config import AlteredApiConfig


class AlteredAuthFactory:
    """Produit une stratégie ``AuthStrategy`` du socle."""

    def create(self, config: AlteredApiConfig) -> AuthStrategy | None:
        """Retourne la stratégie d'authentification ou ``None`` si aucune n'est requise.

        Priorité : ``bearer_token`` puis ``api_key`` (cahier des charges).

        :param config: Configuration Altered.
        :return: ``BearerAuth``, ``ApiKeyAuth`` ou ``None``.
        """
        if config.bearer_token is not None:
            return BearerAuth(token=config.bearer_token)
        if config.api_key is not None:
            return ApiKeyAuth(
                api_key=config.api_key,
                header_name=config.api_key_header_name,
                scheme=config.api_key_query_param,
            )
        return None

    def __repr__(self) -> str:
        """Représentation de débogage sans données sensibles.

        :return: Identifiant fixe de la fabrique (aucun secret ni état).
        """
        return "AlteredAuthFactory()"
