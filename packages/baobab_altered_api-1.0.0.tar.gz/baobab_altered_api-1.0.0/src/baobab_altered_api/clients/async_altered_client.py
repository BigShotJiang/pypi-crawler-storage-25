"""Façade asynchrone publique pour les appels HTTP Altered."""

# pylint: disable=duplicate-code
# Parallèle volontaire avec ``altered_client`` (FEAT-004 / BL-004-002).

from __future__ import annotations

from types import TracebackType

from baobab_api_call import ApiClientConfig, AsyncApiClient
from baobab_api_call.transports.async_transport import AsyncTransport

from baobab_altered_api.clients.api_client_config_alignment import (
    ApiClientConfigAlignment,
)
from baobab_altered_api.clients.transport_port_validator import TransportPortValidator
from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.async_cards_resource import AsyncCardsResource
from baobab_altered_api.resources.async_decks_resource import AsyncDecksResource
from baobab_altered_api.resources.async_marketplace_resource import (
    AsyncMarketplaceResource,
)
from baobab_altered_api.resources.async_open_data_resource import AsyncOpenDataResource
from baobab_altered_api.resources.async_referentials_resource import (
    AsyncReferentialsResource,
)
from baobab_altered_api.transports.altered_async_transport import AlteredAsyncTransport


class AsyncAlteredClient:
    """Façade asynchrone : assemble ``AlteredApiConfig`` et ``AsyncApiClient``.

    Aucune requête réseau n'est effectuée à l'instanciation.

    :param config: Configuration applicative Altered (immuable) ; sert de
        référence métier et, par défaut, de source pour ``ApiClientConfig``.
    :param transport: Port ``AsyncTransport`` avec ``send`` asynchrone ; si
        ``None``, un
        :class:`~baobab_altered_api.transports.altered_async_transport.AlteredAsyncTransport`
        est créé et détenu par cette façade.
    :param api_client_config: Configuration du socle ; si fournie, elle remplace
        celle du builder. Son ``base_url`` doit coïncider avec ``config.base_url``.

    **Cycle de vie** : :meth:`aclose` délègue à :class:`~baobab_api_call.AsyncApiClient`
    qui appelle ``aclose()`` sur le transport s'il est exposé. Un transport
    **injecté** est fermé par cette chaîne : ne pas réutiliser un transport fermé
    sans le recréer.
    """

    def __init__(
        self,
        config: AlteredApiConfig,
        *,
        transport: AsyncTransport | None = None,
        api_client_config: ApiClientConfig | None = None,
    ) -> None:
        self._altered_config: AlteredApiConfig = config
        if api_client_config is not None:
            ApiClientConfigAlignment.assert_matching_base_url(config, api_client_config)
            api_config = api_client_config
        else:
            api_config = AlteredApiClientConfigBuilder.build(config)
        self._transport: AsyncTransport = (
            AlteredAsyncTransport(
                default_timeout_seconds=float(config.timeout_seconds),
            )
            if transport is None
            else transport
        )
        TransportPortValidator.verify_async_send(self._transport)
        self._client: AsyncApiClient = AsyncApiClient(api_config, self._transport)
        self._cards: AsyncCardsResource | None = None
        self._decks: AsyncDecksResource | None = None
        self._referentials: AsyncReferentialsResource | None = None
        self._marketplace: AsyncMarketplaceResource | None = None
        self._open_data: AsyncOpenDataResource | None = None

    @property
    def config(self) -> AlteredApiConfig:
        """Configuration Altered (lecture seule)."""
        return self._altered_config

    @property
    def http(self) -> AsyncApiClient:
        """Client HTTP async du socle (accès direct, en attendant les ressources)."""
        return self._client

    @property
    def cards(self) -> AsyncCardsResource:
        """Ressource cartes async."""
        if self._cards is None:
            self._cards = AsyncCardsResource(self._client)
        return self._cards

    @property
    def decks(self) -> AsyncDecksResource:
        """Ressource decks async."""
        if self._decks is None:
            self._decks = AsyncDecksResource(self._client)
        return self._decks

    @property
    def referentials(self) -> AsyncReferentialsResource:
        """Référentiels async."""
        if self._referentials is None:
            self._referentials = AsyncReferentialsResource(self._client)
        return self._referentials

    @property
    def marketplace(self) -> AsyncMarketplaceResource:
        """Marketplace async (lecture seule)."""
        if self._marketplace is None:
            self._marketplace = AsyncMarketplaceResource(self._client)
        return self._marketplace

    @property
    def open_data(self) -> AsyncOpenDataResource:
        """Open Data async : téléchargement explicite et lecture locale."""
        if self._open_data is None:
            self._open_data = AsyncOpenDataResource(self._altered_config, self._client)
        return self._open_data

    async def aclose(self) -> None:
        """Ferme le client du socle et le transport sous-jacent si applicable."""
        await self._client.aclose()

    async def __aenter__(self) -> AsyncAlteredClient:
        """Context manager async : retourne ``self``."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Ferme la façade à la sortie du bloc ``async with``."""
        await self.aclose()
