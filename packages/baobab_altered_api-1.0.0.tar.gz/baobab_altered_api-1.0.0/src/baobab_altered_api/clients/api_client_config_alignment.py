"""Alignement entre ``AlteredApiConfig`` et ``ApiClientConfig`` du socle."""

from __future__ import annotations

from baobab_api_call import ApiClientConfig

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError


class ApiClientConfigAlignment:
    """Vérifie la cohérence minimale entre ``AlteredApiConfig`` et ``ApiClientConfig``.

    Utilisé lorsque l'appelant injecte une configuration du socle via
    ``api_client_config`` sur les façades publiques.
    """

    @staticmethod
    def assert_matching_base_url(
        altered: AlteredApiConfig,
        api_cfg: ApiClientConfig,
    ) -> None:
        """Vérifie que les URL de base HTTP concordent après normalisation.

        :param altered: Configuration applicative Altered (référence métier).
        :param api_cfg: Configuration ``baobab-api-call`` injectée.
        :raises AlteredConfigError: Si ``base_url`` diffère après ``rstrip('/')``.
        """
        left = altered.base_url.rstrip("/")
        right = api_cfg.base_url.rstrip("/")
        if left != right:
            raise AlteredConfigError(
                "api_client_config.base_url must match config.base_url "
                f"(got {right!r} vs config {left!r})",
            )
