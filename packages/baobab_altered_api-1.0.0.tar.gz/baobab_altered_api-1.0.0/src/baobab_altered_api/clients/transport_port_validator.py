"""Vérifications runtime des ports transport pour les façades clients."""

from __future__ import annotations

import inspect
from typing import Any


class TransportPortValidator:
    """Rejette les transports dont ``send`` ne correspond pas au mode sync/async.

    Les protocoles ``SyncTransport`` / ``AsyncTransport`` du socle ne sont pas
    vérifiables statiquement à l'exécution : ces garde-fous évitent les erreurs
    tardives lorsqu'un fake ou un adaptateur incorrect est injecté.
    """

    @staticmethod
    def verify_sync_send(transport: Any) -> None:
        """Lève si ``send`` est une coroutine (transport async sur client sync)."""
        send = getattr(transport, "send", None)
        if send is None or not callable(send):
            raise TypeError("transport must expose a callable send() method")
        if inspect.iscoroutinefunction(send):
            raise TypeError(
                "This transport uses async send(); use AsyncAlteredClient instead "
                "of AlteredClient."
            )

    @staticmethod
    def verify_async_send(transport: Any) -> None:
        """Lève si ``send`` n'est pas une coroutine (transport sync sur async)."""
        send = getattr(transport, "send", None)
        if send is None or not callable(send):
            raise TypeError("transport must expose a callable send() method")
        if not inspect.iscoroutinefunction(send):
            raise TypeError(
                "This transport uses synchronous send(); use AlteredClient instead "
                "of AsyncAlteredClient."
            )
