"""Clients publics synchrones et asynchrones.

Les classes ci-dessous constituent la surface publique de ce sous-package ;
les modules internes (validateurs, alignement de config) ne sont pas
ré-exportés ici.

Imports supportés :

- ``from baobab_altered_api.clients import AlteredClient, AsyncAlteredClient``
- ``from baobab_altered_api import AlteredClient, AsyncAlteredClient`` (re-export
  racine, voir ``baobab_altered_api.__all__``).
"""

from baobab_altered_api.clients.altered_client import AlteredClient
from baobab_altered_api.clients.async_altered_client import AsyncAlteredClient

__all__: tuple[str, ...] = ("AlteredClient", "AsyncAlteredClient")
