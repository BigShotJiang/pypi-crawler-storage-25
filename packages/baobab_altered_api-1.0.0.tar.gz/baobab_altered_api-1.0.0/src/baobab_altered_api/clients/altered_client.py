"""Façade synchrone publique pour les appels HTTP Altered."""

from __future__ import annotations

from types import TracebackType

from baobab_api_call import ApiClientConfig, SyncApiClient
from baobab_api_call.transports.sync_transport import SyncTransport

from baobab_altered_api.clients.api_client_config_alignment import (
    ApiClientConfigAlignment,
)
from baobab_altered_api.clients.transport_port_validator import TransportPortValidator
from baobab_altered_api.config.altered_api_client_config_builder import (
    AlteredApiClientConfigBuilder,
)
from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.resources.cards_resource import CardsResource
from baobab_altered_api.resources.decks_resource import DecksResource
from baobab_altered_api.resources.marketplace_resource import MarketplaceResource
from baobab_altered_api.resources.open_data_resource import OpenDataResource
from baobab_altered_api.resources.referentials_resource import ReferentialsResource
from baobab_altered_api.transports.altered_sync_transport import AlteredSyncTransport


class AlteredClient:
    """Façade synchrone : assemble ``AlteredApiConfig`` et ``SyncApiClient``.

    Aucune requête réseau n'est effectuée à l'instanciation.

    :param config: Configuration applicative Altered (immuable) ; sert de
        référence métier et, par défaut, de source pour ``ApiClientConfig``.
    :param transport: Port ``SyncTransport`` avec ``send`` synchrone ; si
        ``None``, un
        :class:`~baobab_altered_api.transports.altered_sync_transport.AlteredSyncTransport`
        est créé et détenu par cette façade.
    :param api_client_config: Configuration du socle ``baobab-api-call`` ; si
        fournie, elle remplace celle produite par ``AlteredApiClientConfigBuilder``
        pour le client HTTP. Son ``base_url`` doit coïncider avec
        ``config.base_url`` (normalisation par ``rstrip('/')``).

    **Cycle de vie** : :meth:`close` délègue à :class:`~baobab_api_call.SyncApiClient`,
    qui appelle ``close()`` sur le transport s'il est exposé. Un transport
    **injecté** subit donc aussi ``close()`` : ne pas partager un transport fermé
    entre plusieurs clients sans le recréer. Un transport **créé par défaut**
    est fermé avec la façade.
    """

    def __init__(
        self,
        config: AlteredApiConfig,
        *,
        transport: SyncTransport | None = None,
        api_client_config: ApiClientConfig | None = None,
    ) -> None:
        self._altered_config: AlteredApiConfig = config
        if api_client_config is not None:
            ApiClientConfigAlignment.assert_matching_base_url(config, api_client_config)
            api_config = api_client_config
        else:
            api_config = AlteredApiClientConfigBuilder.build(config)
        self._transport: SyncTransport = (
            AlteredSyncTransport(
                default_timeout_seconds=float(config.timeout_seconds),
            )
            if transport is None
            else transport
        )
        TransportPortValidator.verify_sync_send(self._transport)
        self._client: SyncApiClient = SyncApiClient(api_config, self._transport)
        self._cards: CardsResource | None = None
        self._decks: DecksResource | None = None
        self._referentials: ReferentialsResource | None = None
        self._marketplace: MarketplaceResource | None = None
        self._open_data: OpenDataResource | None = None

    @property
    def config(self) -> AlteredApiConfig:
        """Configuration Altered (lecture seule)."""
        return self._altered_config

    @property
    def http(self) -> SyncApiClient:
        """Client HTTP du socle (accès direct, en attendant les ressources métier)."""
        return self._client

    @property
    def cards(self) -> CardsResource:
        """Ressource cartes (lecture)."""
        if self._cards is None:
            self._cards = CardsResource(self._client)
        return self._cards

    @property
    def decks(self) -> DecksResource:
        """Ressource decks (lecture)."""
        if self._decks is None:
            self._decks = DecksResource(self._client)
        return self._decks

    @property
    def referentials(self) -> ReferentialsResource:
        """Référentiels (sets, factions, etc.)."""
        if self._referentials is None:
            self._referentials = ReferentialsResource(self._client)
        return self._referentials

    @property
    def marketplace(self) -> MarketplaceResource:
        """Marketplace lecture seule."""
        if self._marketplace is None:
            self._marketplace = MarketplaceResource(self._client)
        return self._marketplace

    @property
    def open_data(self) -> OpenDataResource:
        """Open Data : téléchargement explicite et lecture locale."""
        if self._open_data is None:
            self._open_data = OpenDataResource(self._altered_config, self._client)
        return self._open_data

    def close(self) -> None:
        """Ferme le client du socle et le transport sous-jacent si applicable."""
        self._client.close()

    def __enter__(self) -> AlteredClient:
        """Context manager synchrone : retourne ``self``."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Ferme la façade à la sortie du bloc ``with``."""
        self.close()
