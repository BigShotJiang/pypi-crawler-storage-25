"""Erreur de service temporairement indisponible."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredServiceUnavailableError(AlteredApiError):
    """Service indisponible (HTTP 5xx).

    :param message: Texte safe pour l'utilisateur.
    :param path: Chemin ou URL de la requête, si disponible.
    :param http_status: Code 5xx concret (500–599), défaut 503.
    """

    def __init__(
        self,
        message: str = "Service temporarily unavailable",
        *,
        path: str | None = None,
        http_status: int = 503,
    ) -> None:
        if http_status < 500 or http_status > 599:
            raise ValueError("http_status must be between 500 and 599")
        super().__init__(
            message,
            http_status=http_status,
            path=path,
            error_code="SERVICE_UNAVAILABLE",
        )
