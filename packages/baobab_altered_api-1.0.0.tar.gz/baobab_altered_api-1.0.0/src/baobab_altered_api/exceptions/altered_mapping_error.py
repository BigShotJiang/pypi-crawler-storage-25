"""Erreur de mapping ou de forme de données (hors décodage JSON brut)."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredMappingError(AlteredApiError):
    """Données incompatibles avec le modèle attendu (mapping métier).

    Distinct de :class:`~.altered_json_decode_error.AlteredJsonDecodeError`
    (échec de parsing JSON).

    :param message: Texte safe pour l'utilisateur.
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Response mapping failed",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=None,
            path=path,
            error_code="MAPPING",
        )
