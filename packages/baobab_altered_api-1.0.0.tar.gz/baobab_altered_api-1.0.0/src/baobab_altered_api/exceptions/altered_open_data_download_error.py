"""Erreurs liées au téléchargement explicite d'exports Open Data."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredOpenDataDownloadError(AlteredApiError):
    """Échec ou refus de téléchargement Open Data (configuration, fichier, HTTP).

    :param message: Texte safe sans URL complète ni corps de réponse.
    :param path: Chemin cible ou contexte, si pertinent.
    """

    def __init__(
        self,
        message: str = "Open Data download failed",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=None,
            path=path,
            error_code="OPEN_DATA_DOWNLOAD",
        )
