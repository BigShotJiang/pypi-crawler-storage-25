"""Erreur de décodage JSON sur une réponse Altered."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredJsonDecodeError(AlteredApiError):
    """Corps de réponse non JSON ou JSON invalide pour l'usage attendu.

    Le message reste **générique** : aucun fragment du corps n'y figure.

    :param message: Message safe.
    :param http_status: Code HTTP de la réponse (souvent 2xx si le serveur
        a renvoyé un corps inattendu).
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Invalid JSON response",
        *,
        http_status: int | None = None,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=http_status,
            path=path,
            error_code="JSON_DECODE",
        )
