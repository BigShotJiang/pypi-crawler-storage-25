"""Erreur de base pour les exceptions typées ``baobab-altered-api``."""

from __future__ import annotations


class AlteredApiError(Exception):
    """Racine des erreurs métier / transport exposées par la librairie.

    Les messages sont volontairement **stables** et sans corps de réponse ni
    secrets. Les attributs ``http_status``, ``path`` et ``error_code``
    aident le diagnostic sans exposer de données sensibles.

    :param message: Texte safe (pas de jeton, pas de fragment de payload).
    :param http_status: Code HTTP associé, si pertinent.
    :param path: Chemin ou URL de requête telle que portée par le socle, si
        disponible (peut contenir une URL complète sans authentification).
    :param error_code: Code d'erreur applicatif non sensible, si connu.
    """

    def __init__(
        self,
        message: str,
        *,
        http_status: int | None = None,
        path: str | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message: str = message
        self.http_status: int | None = http_status
        self.path: str | None = path
        self.error_code: str | None = error_code

    def __str__(self) -> str:
        """Retourne uniquement le message safe."""
        return self.message

    def __repr__(self) -> str:
        """Résumé court sans données sensibles."""
        return (
            f"{type(self).__name__}(message={self.message!r}, "
            f"http_status={self.http_status!r}, path={self.path!r}, "
            f"error_code={self.error_code!r})"
        )
