"""Erreur HTTP 429 (rate limiting) pour les appels Altered."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredRateLimitError(AlteredApiError):
    """Quota ou limite de débit atteinte (HTTP 429).

    :param message: Message safe.
    :param path: Chemin ou URL de la requête, si disponible.
    :param retry_after: Délai recommandé avant nouvel essai (secondes), si
        dérivé de l'en-tête ``Retry-After`` numérique uniquement.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        path: str | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=429,
            path=path,
            error_code="RATE_LIMIT",
        )
        self.retry_after: float | None = retry_after

    def __repr__(self) -> str:
        """Résumé court ; ``retry_after`` n'apparaît pas dans ``__str__``."""
        return (
            f"AlteredRateLimitError(message={self.message!r}, "
            f"http_status={self.http_status!r}, path={self.path!r}, "
            f"retry_after={self.retry_after!r})"
        )
