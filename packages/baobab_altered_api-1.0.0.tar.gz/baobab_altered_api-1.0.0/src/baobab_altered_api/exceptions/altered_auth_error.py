"""Erreur d'authentification ou d'autorisation (identité / credentials)."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredAuthError(AlteredApiError):
    """Échec d'authentification (HTTP 401 typique).

    Les messages restent génériques : ne jamais y inclure de jeton, clé ou
    fragment de réponse brute.

    :param message: Texte safe pour l'utilisateur.
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=401,
            path=path,
            error_code="UNAUTHORIZED",
        )
