"""Erreur de timeout réseau normalisée pour Altered."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredTimeoutError(AlteredApiError):
    """Dépassement de délai lors d'un appel HTTP.

    :param message: Message safe.
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Request timeout",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=None,
            path=path,
            error_code="TIMEOUT",
        )
