"""Erreur HTTP levée par les transports Altered."""

from __future__ import annotations

from baobab_api_call import ApiHTTPError


class AlteredHttpError(ApiHTTPError):
    """Erreur HTTP pour les appels Altered (transport ou client).

    Sous-classe de :class:`baobab_api_call.ApiHTTPError` pour permettre un
    filtrage côté application tout en restant compatible avec le socle.
    """
