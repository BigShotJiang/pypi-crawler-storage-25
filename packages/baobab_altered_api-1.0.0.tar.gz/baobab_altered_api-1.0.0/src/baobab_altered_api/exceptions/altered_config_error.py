"""Erreur levée lorsqu'une valeur de configuration Altered est invalide."""


class AlteredConfigError(ValueError):
    """Erreur de configuration ``AlteredApiConfig``.

    Les messages ne doivent pas contenir de secrets (jetons, clés API).
    """
