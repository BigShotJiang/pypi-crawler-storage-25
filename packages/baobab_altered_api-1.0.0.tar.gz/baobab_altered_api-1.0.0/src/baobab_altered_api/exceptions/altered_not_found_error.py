"""Erreur HTTP 404 normalisée pour les ressources Altered."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredNotFoundError(AlteredApiError):
    """Ressource absente ou chemin inconnu (HTTP 404).

    :param message: Message safe (défaut orienté utilisateur).
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Resource not found",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=404,
            path=path,
            error_code="NOT_FOUND",
        )
