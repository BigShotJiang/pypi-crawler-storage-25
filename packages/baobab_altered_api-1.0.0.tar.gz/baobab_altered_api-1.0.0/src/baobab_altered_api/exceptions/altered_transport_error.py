"""Erreur de transport HTTP (couche client / connexion) côté Altered."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredTransportError(AlteredApiError):
    """Échec au niveau transport (sans code HTTP applicatif connu).

    Utiliser pour des erreurs de pile HTTPX / socle déjà traduites en message
    safe, sans corps de réponse ni secrets.

    :param message: Texte safe pour l'utilisateur.
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Transport error",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=None,
            path=path,
            error_code="TRANSPORT",
        )
