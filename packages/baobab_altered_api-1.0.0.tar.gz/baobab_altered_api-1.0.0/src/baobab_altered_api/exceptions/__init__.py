"""Hiérarchie d'exceptions métier et techniques pour Altered."""

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError
from baobab_altered_api.exceptions.altered_auth_error import AlteredAuthError
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from baobab_altered_api.exceptions.altered_forbidden_error import AlteredForbiddenError
from baobab_altered_api.exceptions.altered_http_error import AlteredHttpError
from baobab_altered_api.exceptions.altered_json_decode_error import (
    AlteredJsonDecodeError,
)
from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.exceptions.altered_network_error import AlteredNetworkError
from baobab_altered_api.exceptions.altered_not_found_error import AlteredNotFoundError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from baobab_altered_api.exceptions.altered_rate_limit_error import AlteredRateLimitError
from baobab_altered_api.exceptions.altered_service_unavailable_error import (
    AlteredServiceUnavailableError,
)
from baobab_altered_api.exceptions.altered_timeout_error import AlteredTimeoutError
from baobab_altered_api.exceptions.altered_transport_error import AlteredTransportError
from baobab_altered_api.exceptions.error_mapper import ErrorMapper

__all__ = (
    "AlteredApiError",
    "AlteredAuthError",
    "AlteredConfigError",
    "AlteredForbiddenError",
    "AlteredHttpError",
    "AlteredJsonDecodeError",
    "AlteredMappingError",
    "AlteredNetworkError",
    "AlteredNotFoundError",
    "AlteredOpenDataDownloadError",
    "AlteredRateLimitError",
    "AlteredServiceUnavailableError",
    "AlteredTimeoutError",
    "AlteredTransportError",
    "ErrorMapper",
)
