"""Mapping des erreurs HTTP du socle vers les exceptions typées Altered."""

from __future__ import annotations

from collections.abc import Mapping
from http import HTTPStatus
from typing import NoReturn

from baobab_api_call import ApiRequest, ApiResponse
from baobab_api_call.exceptions import ApiNetworkError, ApiTimeoutError

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError
from baobab_altered_api.exceptions.altered_auth_error import AlteredAuthError
from baobab_altered_api.exceptions.altered_forbidden_error import AlteredForbiddenError
from baobab_altered_api.exceptions.altered_not_found_error import AlteredNotFoundError
from baobab_altered_api.exceptions.altered_network_error import AlteredNetworkError
from baobab_altered_api.exceptions.altered_rate_limit_error import AlteredRateLimitError
from baobab_altered_api.exceptions.altered_service_unavailable_error import (
    AlteredServiceUnavailableError,
)
from baobab_altered_api.exceptions.altered_timeout_error import AlteredTimeoutError


def _safe_http_message(status_code: int, method: str | None, path: str | None) -> str:
    """Construit un message stable sans corps de réponse ni secrets."""
    phrase = ""
    try:
        phrase = HTTPStatus(status_code).phrase
    except ValueError:
        pass
    parts: list[str] = [f"HTTP {status_code}"]
    if phrase:
        parts.append(phrase)
    if method is not None and path is not None:
        parts.append(f"[{method} {path}]")
    return " ".join(parts)


def _retry_after_seconds(headers: Mapping[str, str] | None) -> float | None:
    """Extrait ``Retry-After`` numérique uniquement (secondes)."""
    if not headers:
        return None
    raw = headers.get("Retry-After") or headers.get("retry-after")
    if raw is None:
        return None
    stripped = raw.strip()
    if stripped.isdigit():
        return float(int(stripped))
    return None


class ErrorMapper:
    """Convertit erreurs HTTP (réponse) et transport (client) vers ``Altered*``.

    Aucune exception ``ApiHTTPError`` brute n'est levée pour les réponses
    d'erreur mappées : les codes connus deviennent des sous-types de
    :class:`~.altered_api_error.AlteredApiError`. Les autres codes HTTP reçoivent
    un :class:`~.altered_api_error.AlteredApiError` générique avec
    ``error_code="HTTP_ERROR"`` (message safe, sans corps).
    """

    @staticmethod
    def raise_for_transport_failure(
        exc: BaseException,
        request: ApiRequest | None,
    ) -> NoReturn:
        """Convertit ``ApiTimeoutError`` / ``ApiNetworkError`` du socle.

        :param exc: Erreur émise par le client HTTP du socle.
        :param request: Requête associée, si disponible.
        :raises AlteredTimeoutError: Dépassement de délai.
        :raises AlteredNetworkError: Autre erreur réseau / transport.
        """
        path = request.path if request is not None else None
        if isinstance(exc, ApiTimeoutError):
            raise AlteredTimeoutError(path=path) from exc
        if isinstance(exc, ApiNetworkError):
            raise AlteredNetworkError(path=path) from exc
        raise exc

    @staticmethod
    def raise_for_failed_response(response: ApiResponse) -> NoReturn:
        """Lève l'exception Altered appropriée pour une réponse ``is_error``.

        :param response: Réponse du socle avec ``status_code`` >= 400.
        :raises AlteredAuthError: HTTP 401.
        :raises AlteredForbiddenError: HTTP 403.
        :raises AlteredNotFoundError: HTTP 404.
        :raises AlteredRateLimitError: HTTP 429.
        :raises AlteredServiceUnavailableError: HTTP 5xx.
        :raises AlteredApiError: 400, 408, 409 ou code non spécialisé autrement.
        """
        request = response.request
        path = request.path if request is not None else None
        method = request.method if request is not None else None
        code = response.status_code

        if code == 401:
            raise AlteredAuthError(path=path)
        if code == 403:
            raise AlteredForbiddenError(path=path)
        if code == 404:
            raise AlteredNotFoundError(path=path)
        if code == 429:
            retry_after = _retry_after_seconds(response.headers)
            raise AlteredRateLimitError(path=path, retry_after=retry_after)
        if 500 <= code <= 599:
            raise AlteredServiceUnavailableError(path=path, http_status=code)
        if code == 400:
            raise AlteredApiError(
                "Bad request",
                http_status=400,
                path=path,
                error_code="BAD_REQUEST",
            )
        if code == 408:
            raise AlteredApiError(
                "Request timeout",
                http_status=408,
                path=path,
                error_code="REQUEST_TIMEOUT",
            )
        if code == 409:
            raise AlteredApiError(
                "Conflict",
                http_status=409,
                path=path,
                error_code="CONFLICT",
            )
        message = _safe_http_message(code, method, path)
        raise AlteredApiError(
            message,
            http_status=code,
            path=path,
            error_code="HTTP_ERROR",
        )
