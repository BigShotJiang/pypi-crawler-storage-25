"""Erreur d'accès refusé (autorisations insuffisantes)."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredForbiddenError(AlteredApiError):
    """Accès refusé (HTTP 403).

    :param message: Texte safe pour l'utilisateur.
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Access forbidden",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=403,
            path=path,
            error_code="FORBIDDEN",
        )
