"""Erreur réseau / transport normalisée pour Altered."""

from __future__ import annotations

from baobab_altered_api.exceptions.altered_api_error import AlteredApiError


class AlteredNetworkError(AlteredApiError):
    """Échec réseau ou transport avant réponse HTTP exploitable.

    :param message: Message safe.
    :param path: Chemin ou URL de la requête, si disponible.
    """

    def __init__(
        self,
        message: str = "Network error",
        *,
        path: str | None = None,
    ) -> None:
        super().__init__(
            message,
            http_status=None,
            path=path,
            error_code="NETWORK",
        )
