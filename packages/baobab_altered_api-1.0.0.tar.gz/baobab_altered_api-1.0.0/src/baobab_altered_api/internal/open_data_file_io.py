"""Lecture fichier Open Data avec garde-fou de taille."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from baobab_altered_api.exceptions.altered_json_decode_error import (
    AlteredJsonDecodeError,
)
from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)

DEFAULT_OPEN_DATA_MAX_BYTES: int = 50 * 1024 * 1024


class OpenDataFileIo:
    """Utilitaires I/O pour exports Open Data locaux."""

    @staticmethod
    def read_json_object(
        path: Path | str,
        *,
        max_bytes: int = DEFAULT_OPEN_DATA_MAX_BYTES,
    ) -> Mapping[str, Any]:
        """Lit un fichier JSON objet après contrôle de taille sur disque.

        :param path: Chemin du fichier export.
        :param max_bytes: Taille maximale autorisée en octets.
        :return: Racine JSON typée comme mapping.
        :raises FileNotFoundError: Fichier absent.
        :raises AlteredOpenDataDownloadError: Fichier trop volumineux.
        :raises AlteredJsonDecodeError: JSON invalide.
        :raises AlteredMappingError: Racine non objet.
        """
        file_path = Path(path)
        if not file_path.is_file():
            msg = f"open data file not found: {file_path}"
            raise FileNotFoundError(msg)
        size = file_path.stat().st_size
        if size > max_bytes:
            raise AlteredOpenDataDownloadError(
                "Open Data file exceeds configured max_bytes limit",
                path=str(file_path),
            )
        try:
            raw_text = file_path.read_text(encoding="utf-8")
            decoded: Any = json.loads(raw_text)
        except json.JSONDecodeError as exc:
            raise AlteredJsonDecodeError(
                "Invalid Open Data JSON file",
                path=str(file_path),
            ) from exc
        if not isinstance(decoded, Mapping):
            msg = "open data root must be a JSON object"
            raise AlteredMappingError(msg, path=str(file_path))
        return decoded
