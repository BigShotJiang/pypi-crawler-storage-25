"""Redaction de données sensibles avant journalisation."""

from __future__ import annotations

import re
from typing import Mapping
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

# Motifs volontairement étroits : éviter de masquer des identifiants métier longs.
_BEARER_VALUE = re.compile(r"(?i)Bearer\s+\S+")
_QUERY_PAIR_SECRET = re.compile(
    r"(?i)((?:api_?key|access_token|refresh_token|client_secret|password|secret|token|"
    r"authorization|auth)\s*=\s*)[^\s&]+"
)


class AlteredLogRedactor:
    """Utilitaires statiques pour retirer secrets et jetons des surfaces de log.

    Les noms d'en-têtes et de paramètres de requête sont comparés en
    insensible à la casse. Les valeurs ``Bearer …`` sont masquées même si la
    clé n'est pas listée explicitement.
    """

    _SENSITIVE_HEADER_NAMES: frozenset[str] = frozenset(
        {
            "authorization",
            "cookie",
            "proxy-authorization",
            "set-cookie",
            "x-api-key",
            "x-auth-token",
        }
    )
    _SENSITIVE_QUERY_KEYS: frozenset[str] = frozenset(
        {
            "access_token",
            "api_key",
            "apikey",
            "auth",
            "authorization",
            "client_secret",
            "id_token",
            "password",
            "refresh_token",
            "secret",
            "token",
        }
    )

    @classmethod
    def redact_headers(cls, headers: Mapping[str, str] | None) -> dict[str, str] | None:
        """Retourne une copie des en-têtes avec les valeurs sensibles masquées.

        :param headers: Carte d'en-têtes HTTP ou ``None``.
        :return: Nouvelle carte ou ``None`` si l'entrée est ``None``.
        """
        if headers is None:
            return None
        out: dict[str, str] = {}
        for name, value in headers.items():
            if name.lower() in cls._SENSITIVE_HEADER_NAMES:
                out[name] = "<redacted>"
            else:
                out[name] = value
        return out

    @classmethod
    def redact_query_params(
        cls,
        params: Mapping[str, str | int | float | bool] | None,
    ) -> dict[str, str] | None:
        """Retourne une copie des paramètres de query avec valeurs masquées.

        :param params: Paramètres logiques ou ``None``.
        :return: Chaînes uniquement, ou ``None`` si l'entrée est ``None``.
        """
        if params is None:
            return None
        out: dict[str, str] = {}
        for key, raw in params.items():
            text = str(raw)
            if cls._is_sensitive_query_key(key) or _BEARER_VALUE.match(text):
                out[str(key)] = "<redacted>"
            else:
                out[str(key)] = text
        return out

    @classmethod
    def redact_message(cls, message: str) -> str:
        """Masque jetons Bearer et paires ``clé=valeur`` sensibles dans une chaîne.

        :param message: Texte potentiellement non sûr pour les journaux.
        :return: Texte avec segments sensibles remplacés par des marqueurs.
        """
        redacted = _BEARER_VALUE.sub("Bearer <redacted>", message)
        return _QUERY_PAIR_SECRET.sub(r"\1<redacted>", redacted)

    @classmethod
    def redact_http_target(
        cls,
        path: str,
        params: Mapping[str, str | int | float | bool] | None,
    ) -> str:
        """Construit une cible HTTP unique pour les journaux (URL ou chemin).

        Les segments de query (dans ``path`` ou ``params``) sont fusionnés puis
        redactés. Aucun corps de requête n'est inclus.

        :param path: URL absolue ou chemin tel que porté par :class:`ApiRequest`.
        :param params: Paramètres de query additionnels éventuels.
        :return: Chaîne prête pour un message de log structuré.
        """
        merged: dict[str, str] = {}
        display_base: str

        if path.startswith(("http://", "https://")):
            parsed = urlparse(path)
            display_base = urlunparse(
                (parsed.scheme, parsed.netloc, parsed.path, "", "", "")
            )
            for key, value in parse_qsl(parsed.query, keep_blank_values=True):
                merged[key] = value
        elif "?" in path:
            base, _, query_part = path.partition("?")
            display_base = base
            for key, value in parse_qsl(query_part, keep_blank_values=True):
                merged[key] = value
        else:
            display_base = path

        if params:
            for key, raw in params.items():
                merged[str(key)] = str(raw)

        redacted_params = cls.redact_query_params(merged)
        if not redacted_params:
            return display_base
        query = urlencode(redacted_params, doseq=True)
        return f"{display_base}?{query}"

    @classmethod
    def _is_sensitive_query_key(cls, key: str) -> bool:
        return key.lower() in cls._SENSITIVE_QUERY_KEYS
