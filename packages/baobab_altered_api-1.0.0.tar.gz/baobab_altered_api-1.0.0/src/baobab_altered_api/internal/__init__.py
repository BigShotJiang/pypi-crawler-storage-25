"""Utilitaires internes non garantis stables pour les consommateurs."""
