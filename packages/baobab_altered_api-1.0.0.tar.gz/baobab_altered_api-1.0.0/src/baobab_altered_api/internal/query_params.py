"""Construction interne de paramètres de requête HTTP (query string)."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import Enum
from typing import Any, Literal, Self

from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams


class QueryParamsBuilder:
    """Assemble un ``dict[str, str]`` stable pour les ``params`` du socle HTTP.

    Rôle interne : pas d’encodage d’URL complet ici (délégué au client HTTP).
    Les entrées ``None`` et les chaînes uniquement blanches sont ignorées.
    Les booléens deviennent ``\"true\"`` / ``\"false\"`` en minuscules.

    :ivar _page_key: Nom du paramètre de page (1-based).
    :ivar _limit_key: Nom du paramètre de taille de page.
    :ivar _cursor_key: Nom du paramètre de curseur opaque.
    :ivar _list_format: Sérialisation des séquences (voir :meth:`add`).
    :ivar _pairs: Paires clé/valeur dans l’ordre d’insertion (dernière valeur gagne).
    """

    def __init__(
        self,
        *,
        page_key: str = "page",
        limit_key: str = "limit",
        cursor_key: str = "cursor",
        sort_key: str = "sort",
        order_key: str = "order",
        list_format: Literal["comma"] = "comma",
    ) -> None:
        self._page_key = page_key
        self._limit_key = limit_key
        self._cursor_key = cursor_key
        self._sort_key = sort_key
        self._order_key = order_key
        self._list_format: Literal["comma"] = list_format
        self._pairs: list[tuple[str, str]] = []

    def add(self, key: str, value: Any) -> Self:
        """Ajoute une paire si la valeur est significative après sérialisation.

        :param key: Nom du paramètre HTTP (non vide après strip).
        :param value: Scalaire, énumération, séquence homogène ou ``None``.
        :return: ``self`` pour enchaînement fluide.
        :raises ValueError: Si ``key`` est vide ou blanc.
        """
        stripped_key = key.strip()
        if not stripped_key:
            msg = "query param key must be non-empty"
            raise ValueError(msg)
        text = self._serialize_value(value)
        if text is None:
            return self
        self._pairs.append((stripped_key, text))
        return self

    def add_mapping(self, data: Mapping[str, Any]) -> Self:
        """Ajoute toutes les paires non triviales d’un mapping."""
        for k, v in data.items():
            self.add(k, v)
        return self

    def add_pagination(self, params: AlteredPaginationParams) -> Self:
        """Dérive ``limit`` et soit ``page`` soit ``cursor`` depuis :class:`AlteredPaginationParams`.

        :param params: Paramètres déjà validés (exclusivité page/curseur).
        """
        self.add(self._limit_key, params.limit)
        if params.cursor is not None:
            self.add(self._cursor_key, params.cursor)
        elif params.page is not None:
            self.add(self._page_key, params.page)
        return self

    def add_sort(self, field: str, *, descending: bool = False) -> Self:
        """Ajoute un tri générique ``sort`` + ``order`` (noms fixes documentés).

        :param field: Champ de tri (non vide).
        :param descending: Si vrai, ``order=desc`` sinon ``order=asc``.
        """
        self.add(self._sort_key, field)
        self.add(self._order_key, "desc" if descending else "asc")
        return self

    def build(self) -> dict[str, str]:
        """Produit un dictionnaire **trié par clé** puis ordre d’insertion stable.

        En cas de clé dupliquée, la dernière insertion l’emporte (comportement
        explicite pour surcharges successives).
        """
        merged: dict[str, str] = {}
        for k, v in self._pairs:
            merged[k] = v
        return dict(sorted(merged.items()))

    def _serialize_value(self, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            s = value.strip()
            return s or None
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, int) and not isinstance(value, bool):
            return str(value)
        if isinstance(value, float):
            return str(value)
        if isinstance(value, Enum):
            return str(value.value)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            if self._list_format != "comma":
                msg = "only comma list_format is supported"
                raise ValueError(msg)
            parts: list[str] = []
            for item in value:
                piece = self._serialize_scalar_for_list(item)
                if piece is not None:
                    parts.append(piece)
            if not parts:
                return None
            return ",".join(parts)
        return str(value)

    @staticmethod
    def _serialize_scalar_for_list(item: Any) -> str | None:
        if item is None:
            return None
        if isinstance(item, str):
            s = item.strip()
            return s or None
        if isinstance(item, bool):
            return "true" if item else "false"
        if isinstance(item, int) and not isinstance(item, bool):
            return str(item)
        if isinstance(item, float):
            return str(item)
        if isinstance(item, Enum):
            return str(item.value)
        return str(item)
