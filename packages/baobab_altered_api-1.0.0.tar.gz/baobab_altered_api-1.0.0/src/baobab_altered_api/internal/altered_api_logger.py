"""Journalisation HTTP minimale sans configuration globale forcée."""

from __future__ import annotations

import logging

from baobab_api_call import ApiRequest, ApiResponse

from baobab_altered_api.internal.altered_log_redactor import AlteredLogRedactor

_LOGGER_NAME = "baobab_altered_api"


class AlteredApiLogger:
    """Point d'entrée pour les journaux de la librairie ``baobab_altered_api``.

    Le logger porte le nom ``baobab_altered_api``. Aucun gestionnaire n'est
    ajouté par la librairie et aucune initialisation globale du module
    :mod:`logging` n'est forcée : l'application configure explicitement les
    niveaux et sorties (opt-in).

    Les messages d'appel HTTP sont au niveau ``INFO`` et n'incluent que la
    méthode, une cible redactée, le statut et la durée éventuelle.
    """

    @staticmethod
    def get_logger() -> logging.Logger:
        """Retourne le :class:`logging.Logger` racine du package.

        :return: Logger nommé ``baobab_altered_api`` (sans handler imposé).
        """
        return logging.getLogger(_LOGGER_NAME)

    @classmethod
    def log_http_roundtrip(cls, request: ApiRequest, response: ApiResponse) -> None:
        """Enregistre un aller-retour HTTP minimal si ``INFO`` est activé.

        N'inclut ni corps de requête ni en-têtes ; la cible est passée au
        redacteur (URL, query et jetons).

        :param request: Requête logique envoyée.
        :param response: Réponse associée (statut et durée).
        """
        logger = cls.get_logger()
        if not logger.isEnabledFor(logging.INFO):
            return
        safe_target = AlteredLogRedactor.redact_http_target(
            request.path, request.params
        )
        elapsed = response.elapsed_seconds
        if elapsed is not None:
            logger.info(
                "http_outbound method=%s target=%s status=%s duration_s=%.3f",
                request.method,
                safe_target,
                response.status_code,
                elapsed,
            )
        else:
            logger.info(
                "http_outbound method=%s target=%s status=%s",
                request.method,
                safe_target,
                response.status_code,
            )
