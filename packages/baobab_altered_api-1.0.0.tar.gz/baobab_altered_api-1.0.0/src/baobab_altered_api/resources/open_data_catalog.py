"""Index en mémoire pour interroger un export Open Data déjà chargé."""

from __future__ import annotations

from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_open_data_snapshot import AlteredOpenDataSnapshot


def _expansion_key(card: AlteredCardSummary) -> str | None:
    expansion = card.expansion
    if expansion is None:
        return None
    if expansion.code:
        return expansion.code
    if expansion.ref is not None:
        return expansion.ref.value
    return expansion.name


def _faction_matches(card: AlteredCardSummary, needle: str) -> bool:
    faction = card.faction
    if faction is None:
        return False
    if faction.ref is not None and faction.ref.value == needle:
        return True
    return faction.name == needle


class OpenDataCatalog:
    """Catalogue local en lecture seule construit depuis un snapshot Open Data.

    Les index sont immuables après construction. Les doublons d'identifiant carte
    conservent la **dernière** occurrence et sont listés via :attr:`duplicate_refs`.

    :param snapshot: Export déjà mappé (fichier local ou mémoire).
    """

    def __init__(self, snapshot: AlteredOpenDataSnapshot) -> None:
        by_ref: dict[str, AlteredCardSummary] = {}
        duplicates: list[str] = []
        for card in snapshot.cards:
            key = card.ref.value
            if key in by_ref:
                duplicates.append(key)
            by_ref[key] = card
        self._by_ref: dict[str, AlteredCardSummary] = by_ref
        self._duplicate_refs: tuple[str, ...] = tuple(duplicates)
        self._snapshot = snapshot

    @property
    def snapshot(self) -> AlteredOpenDataSnapshot:
        """Snapshot source (lecture seule)."""
        return self._snapshot

    @property
    def duplicate_refs(self) -> tuple[str, ...]:
        """Identifiants carte rencontrés plus d'une fois dans l'export."""
        return self._duplicate_refs

    def get_card(self, ref: str) -> AlteredCardSummary | None:
        """Retourne une carte par identifiant, ou ``None`` si absente.

        :param ref: Valeur d'identifiant telle que dans l'export (``id`` / ``ref``).
        """
        return self._by_ref.get(ref)

    def list_sets(self) -> tuple[str, ...]:
        """Codes ou clés d'extension distincts présents dans le catalogue."""
        keys: set[str] = set()
        for card in self._by_ref.values():
            key = _expansion_key(card)
            if key is not None:
                keys.add(key)
        return tuple(sorted(keys))

    def list_by_set(self, set_code: str) -> tuple[AlteredCardSummary, ...]:
        """Cartes rattachées à une extension (code, ref ou nom selon disponibilité)."""
        needle = set_code.strip()
        if not needle:
            return ()
        return tuple(
            card for card in self._by_ref.values() if _expansion_key(card) == needle
        )

    def list_by_faction(self, faction_key: str) -> tuple[AlteredCardSummary, ...]:
        """Cartes d'une faction (ref ou nom selon disponibilité)."""
        needle = faction_key.strip()
        if not needle:
            return ()
        return tuple(
            card for card in self._by_ref.values() if _faction_matches(card, needle)
        )
