"""Ressource Open Data asynchrone (miroir de :class:`OpenDataResource`)."""

from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path

from baobab_api_call import AsyncApiClient

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_api_error import AlteredApiError
from baobab_altered_api.mappers.altered_open_data_json_mapper import (
    AlteredOpenDataJsonMapper,
)
from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_open_data_snapshot import AlteredOpenDataSnapshot
from baobab_altered_api.resources.async_open_data_downloader import (
    AsyncOpenDataDownloader,
)
from baobab_altered_api.resources.open_data_catalog import OpenDataCatalog
from baobab_altered_api.internal.open_data_file_io import DEFAULT_OPEN_DATA_MAX_BYTES
from baobab_altered_api.resources.open_data_reader import OpenDataReader


class AsyncOpenDataResource:
    """Variante async de la ressource Open Data."""

    def __init__(
        self,
        config: AlteredApiConfig,
        http: AsyncApiClient,
        *,
        max_bytes: int = DEFAULT_OPEN_DATA_MAX_BYTES,
    ) -> None:
        self._downloader = AsyncOpenDataDownloader(config, http, max_bytes=max_bytes)
        self._max_bytes = max_bytes
        self._snapshot: AlteredOpenDataSnapshot | None = None

    @property
    def snapshot(self) -> AlteredOpenDataSnapshot | None:
        """Dernier snapshot chargé."""
        return self._snapshot

    async def fetch_snapshot(self) -> AlteredOpenDataSnapshot:
        """Télécharge l'export et le mappe en mémoire."""
        root = await self._downloader.fetch_root_mapping()
        self._snapshot = AlteredOpenDataJsonMapper.snapshot_from_mapping(root)
        return self._snapshot

    def load_from_file(self, path: Path | str) -> AlteredOpenDataSnapshot:
        """Charge un fichier local (lecture synchrone sûre, sans réseau)."""
        self._snapshot = OpenDataReader.from_path(path, max_bytes=self._max_bytes)
        return self._snapshot

    async def save_snapshot(
        self,
        destination: Path | str,
        *,
        overwrite: bool = False,
    ) -> Path:
        """Télécharge l'export vers ``destination``."""
        return await self._downloader.download_to(destination, overwrite=overwrite)

    async def download_to(
        self,
        destination: Path | str,
        *,
        overwrite: bool = False,
    ) -> Path:
        """Alias de :meth:`save_snapshot`."""
        return await self.save_snapshot(destination, overwrite=overwrite)

    async def iter_cards(self) -> AsyncIterator[AlteredCardSummary]:
        """Itère les cartes du snapshot courant (async generator)."""
        if self._snapshot is None:
            raise AlteredApiError(
                "Open Data snapshot not loaded; call load_from_file or fetch_snapshot first",
                error_code="OPEN_DATA_NOT_LOADED",
            )
        for card in self._snapshot.iter_cards():
            yield card

    @staticmethod
    def catalog_from_path(path: Path | str) -> OpenDataCatalog:
        """Catalogue indexé depuis un fichier local."""
        return OpenDataCatalog(OpenDataReader.from_path(path))
