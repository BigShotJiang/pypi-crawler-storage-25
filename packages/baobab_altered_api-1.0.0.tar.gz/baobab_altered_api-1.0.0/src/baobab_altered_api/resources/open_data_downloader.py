"""Téléchargement explicite d'un export Open Data (opt-in, aucun auto-fetch)."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from baobab_api_call import SyncApiClient

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from baobab_altered_api.internal.open_data_file_io import DEFAULT_OPEN_DATA_MAX_BYTES
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)


class OpenDataDownloader:
    """Télécharge l'export JSON vers un chemin local via le client HTTP du socle.

    Aucun téléchargement n'est déclenché implicitement : l'appelant doit invoquer
    :meth:`download_to` explicitement. L'URL provient de
    :attr:`~baobab_altered_api.config.AlteredApiConfig.open_data_url`.

    :param config: Configuration avec ``open_data_url`` renseignée.
    :param http: Client synchrone du socle (transport injecté / factice en tests).
    :param max_bytes: Taille maximale acceptée pour le corps de réponse.
    """

    def __init__(
        self,
        config: AlteredApiConfig,
        http: SyncApiClient,
        *,
        max_bytes: int = DEFAULT_OPEN_DATA_MAX_BYTES,
    ) -> None:
        self._config = config
        self._http = http
        self._max_bytes = max_bytes

    def fetch_root_mapping(self) -> Mapping[str, Any]:
        """GET l'export et retourne la racine JSON (sans écriture disque).

        :return: Objet racine de l'export Open Data.
        :raises AlteredConfigError: ``open_data_url`` absente.
        :raises AlteredOpenDataDownloadError: HTTP en erreur ou corps trop volumineux.
        """
        url = self._config.open_data_url
        if url is None:
            raise AlteredConfigError(
                "open_data_url must be set in AlteredApiConfig to download Open Data"
            )
        response = self._http.get(url)
        if response.is_error:
            raise AlteredOpenDataDownloadError(
                f"Open Data download failed with HTTP {response.status_code}",
            )
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        raw = payload.data
        text = json.dumps(raw, ensure_ascii=False)
        if len(text.encode("utf-8")) > self._max_bytes:
            raise AlteredOpenDataDownloadError(
                "Open Data export exceeds configured max_bytes limit",
            )
        if isinstance(raw, Mapping):
            return raw
        msg = "Open Data root must be a JSON object"
        raise AlteredOpenDataDownloadError(msg)

    def download_to(
        self,
        destination: Path | str,
        *,
        overwrite: bool = False,
    ) -> Path:
        """GET l'export et l'écrit en UTF-8 sur ``destination``.

        :param destination: Fichier cible.
        :param overwrite: Si ``False`` et le fichier existe, lève une erreur.
        :return: Chemin résolu du fichier écrit.
        :raises AlteredConfigError: ``open_data_url`` absente de la configuration.
        :raises AlteredOpenDataDownloadError: Fichier existant, HTTP en erreur ou trop volumineux.
        """
        dest = Path(destination)
        if dest.exists() and not overwrite:
            raise AlteredOpenDataDownloadError(
                "destination file already exists; pass overwrite=True to replace",
                path=str(dest),
            )
        root = self.fetch_root_mapping()
        text = json.dumps(root, ensure_ascii=False, indent=2)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(text, encoding="utf-8")
        return dest.resolve()
