"""Parse les réponses HTTP de listes de référentiels."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any, TypeVar

from baobab_api_call import ApiResponse

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_referentials_json_mapper import (
    AlteredReferentialsJsonMapper,
)
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)

T = TypeVar("T")


class ReferentialListResponseParser:
    """Décode ``ApiResponse`` en tuples de modèles référentiels."""

    @staticmethod
    def parse(
        response: ApiResponse,
        path: str,
        mapper: Callable[[Mapping[str, Any]], T],
    ) -> tuple[T, ...]:
        """Retourne les entrées typées d'une liste référentiel."""
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        data = payload.data
        if isinstance(data, Mapping):
            return AlteredReferentialsJsonMapper.list_from_mapping(
                data, item_mapper=mapper, path=path
            )
        if isinstance(data, list):
            wrapper: dict[str, Any] = {"items": data}
            return AlteredReferentialsJsonMapper.list_from_mapping(
                wrapper, item_mapper=mapper, path=path
            )
        msg = "referential list root must be mapping or array"
        raise AlteredMappingError(msg, path=path)
