"""Ressource asynchrone decks."""

from __future__ import annotations

from collections.abc import Mapping

from baobab_api_call import AsyncApiClient

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_deck_json_mapper import AlteredDeckJsonMapper
from baobab_altered_api.models.altered_deck import AlteredDeck
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)


class AsyncDecksResource:
    """Lecture async de decks."""

    def __init__(self, http: AsyncApiClient) -> None:
        self._http = http

    async def get_by_id(self, deck_id: str) -> AlteredDeck:
        """Détail deck async."""
        response = await self._http.get(AlteredApiPaths.deck_by_id(deck_id))
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        data = payload.data
        if isinstance(data, Mapping):
            return AlteredDeckJsonMapper.deck_from_mapping(
                data, path=AlteredApiPaths.deck_by_id(deck_id)
            )
        msg = "deck detail root must be a mapping"
        raise AlteredMappingError(msg, path=AlteredApiPaths.deck_by_id(deck_id))
