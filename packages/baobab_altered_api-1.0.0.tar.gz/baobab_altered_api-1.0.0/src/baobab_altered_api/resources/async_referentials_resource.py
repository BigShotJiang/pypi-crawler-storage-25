"""Ressource asynchrone des référentiels."""

from __future__ import annotations

from baobab_api_call import AsyncApiClient

from baobab_altered_api.mappers.altered_referentials_json_mapper import (
    AlteredReferentialsJsonMapper,
)
from baobab_altered_api.models.altered_card_type_reference import (
    AlteredCardTypeReference,
)
from baobab_altered_api.models.altered_faction_reference import AlteredFactionReference
from baobab_altered_api.models.altered_rarity_reference import AlteredRarityReference
from baobab_altered_api.models.altered_set_reference import AlteredSetReference
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.referential_list_response_parser import (
    ReferentialListResponseParser,
)


class AsyncReferentialsResource:
    """Listes de référentiels (async)."""

    def __init__(self, http: AsyncApiClient) -> None:
        self._http = http

    async def list_sets(self) -> tuple[AlteredSetReference, ...]:
        """Référentiel sets."""
        response = await self._http.get(AlteredApiPaths.SETS)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.SETS,
            AlteredReferentialsJsonMapper.set_reference_from_mapping,
        )

    async def list_factions(self) -> tuple[AlteredFactionReference, ...]:
        """Référentiel factions."""
        response = await self._http.get(AlteredApiPaths.FACTIONS)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.FACTIONS,
            AlteredReferentialsJsonMapper.faction_reference_from_mapping,
        )

    async def list_rarities(self) -> tuple[AlteredRarityReference, ...]:
        """Référentiel raretés."""
        response = await self._http.get(AlteredApiPaths.RARITIES)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.RARITIES,
            AlteredReferentialsJsonMapper.rarity_reference_from_mapping,
        )

    async def list_card_types(self) -> tuple[AlteredCardTypeReference, ...]:
        """Référentiel types."""
        response = await self._http.get(AlteredApiPaths.CARD_TYPES)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.CARD_TYPES,
            AlteredReferentialsJsonMapper.card_type_reference_from_mapping,
        )
