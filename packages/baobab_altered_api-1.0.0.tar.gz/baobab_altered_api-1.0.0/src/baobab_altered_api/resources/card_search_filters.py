"""Filtres et tris typés pour la recherche de cartes (FEAT-006)."""

from __future__ import annotations

from dataclasses import dataclass

from baobab_altered_api.internal.query_params import QueryParamsBuilder
from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams

_ALLOWED_SORT_FIELDS: frozenset[str] = frozenset({"name", "id", "created", "rarity"})


@dataclass(frozen=True)
class CardSearchFilters:
    """Critères de recherche carte sérialisables en query string.

    Les noms de paramètres HTTP restent indicatifs (voir ``docs/api_observations/cards.md``).

    :ivar name: Filtre texte sur le nom (partiel ou exact selon API).
    :ivar faction: Code ou identifiant de faction.
    :ivar set_code: Code d'extension / set.
    :ivar rarity: Code de rareté.
    :ivar card_type: Type de carte (créature, sort, etc.) si exposé.
    :ivar locale: Tag de langue (ex. ``fr-FR``).
    :ivar pagination: Paramètres de page / curseur.
    :ivar sort_field: Champ de tri autorisé.
    :ivar sort_descending: Ordre décroissant si ``True``.
    """

    name: str | None = None
    faction: str | None = None
    set_code: str | None = None
    rarity: str | None = None
    card_type: str | None = None
    locale: str | None = None
    pagination: AlteredPaginationParams | None = None
    sort_field: str | None = None
    sort_descending: bool = False

    def __post_init__(self) -> None:
        if self.sort_field is not None:
            field = self.sort_field.strip()
            if not field:
                object.__setattr__(self, "sort_field", None)
            elif field not in _ALLOWED_SORT_FIELDS:
                allowed = ", ".join(sorted(_ALLOWED_SORT_FIELDS))
                msg = f"sort_field must be one of: {allowed}"
                raise ValueError(msg)
            else:
                object.__setattr__(self, "sort_field", field)

    def to_query_params(self) -> dict[str, str]:
        """Produit les paramètres de requête pour le client HTTP du socle."""
        builder = QueryParamsBuilder()
        builder.add("name", self.name)
        builder.add("faction", self.faction)
        builder.add("set", self.set_code)
        builder.add("rarity", self.rarity)
        builder.add("type", self.card_type)
        builder.add("locale", self.locale)
        if self.pagination is not None:
            builder.add_pagination(self.pagination)
        if self.sort_field is not None:
            builder.add_sort(self.sort_field, descending=self.sort_descending)
        return builder.build()
