"""Ressource synchrone des référentiels Altered."""

from __future__ import annotations

from baobab_api_call import SyncApiClient

from baobab_altered_api.mappers.altered_referentials_json_mapper import (
    AlteredReferentialsJsonMapper,
)
from baobab_altered_api.models.altered_card_type_reference import (
    AlteredCardTypeReference,
)
from baobab_altered_api.models.altered_faction_reference import AlteredFactionReference
from baobab_altered_api.models.altered_rarity_reference import AlteredRarityReference
from baobab_altered_api.models.altered_set_reference import AlteredSetReference
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.referential_list_response_parser import (
    ReferentialListResponseParser,
)


class ReferentialsResource:
    """Listes de référentiels (sets, factions, raretés, types)."""

    def __init__(self, http: SyncApiClient) -> None:
        self._http = http

    def list_sets(self) -> tuple[AlteredSetReference, ...]:
        """GET référentiel extensions."""
        response = self._http.get(AlteredApiPaths.SETS)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.SETS,
            AlteredReferentialsJsonMapper.set_reference_from_mapping,
        )

    def list_factions(self) -> tuple[AlteredFactionReference, ...]:
        """GET référentiel factions."""
        response = self._http.get(AlteredApiPaths.FACTIONS)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.FACTIONS,
            AlteredReferentialsJsonMapper.faction_reference_from_mapping,
        )

    def list_rarities(self) -> tuple[AlteredRarityReference, ...]:
        """GET référentiel raretés."""
        response = self._http.get(AlteredApiPaths.RARITIES)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.RARITIES,
            AlteredReferentialsJsonMapper.rarity_reference_from_mapping,
        )

    def list_card_types(self) -> tuple[AlteredCardTypeReference, ...]:
        """GET référentiel types de carte."""
        response = self._http.get(AlteredApiPaths.CARD_TYPES)
        return ReferentialListResponseParser.parse(
            response,
            AlteredApiPaths.CARD_TYPES,
            AlteredReferentialsJsonMapper.card_type_reference_from_mapping,
        )
