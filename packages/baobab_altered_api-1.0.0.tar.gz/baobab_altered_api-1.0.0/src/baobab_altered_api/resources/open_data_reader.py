"""Lecture locale d'exports Open Data JSON (sans réseau)."""

from __future__ import annotations

from pathlib import Path

from baobab_altered_api.internal.open_data_file_io import OpenDataFileIo
from baobab_altered_api.mappers.altered_open_data_json_mapper import (
    AlteredOpenDataJsonMapper,
)
from baobab_altered_api.models.altered_open_data_snapshot import AlteredOpenDataSnapshot


class OpenDataReader:
    """Charge un fichier export Open Data et produit un snapshot typé."""

    @staticmethod
    def from_path(
        path: Path | str,
        *,
        max_bytes: int | None = None,
    ) -> AlteredOpenDataSnapshot:
        """Lit UTF-8, parse JSON et mappe vers :class:`AlteredOpenDataSnapshot`.

        :param path: Chemin vers le fichier export.
        :param max_bytes: Limite de taille optionnelle (défaut socle Open Data).
        :return: Snapshot immuable.
        :raises FileNotFoundError: Fichier absent.
        :raises AlteredJsonDecodeError: JSON invalide.
        :raises AlteredMappingError: Racine non objet.
        :raises AlteredOpenDataDownloadError: Fichier trop volumineux.
        """
        if max_bytes is None:
            decoded = OpenDataFileIo.read_json_object(path)
        else:
            decoded = OpenDataFileIo.read_json_object(path, max_bytes=max_bytes)
        return AlteredOpenDataJsonMapper.snapshot_from_mapping(decoded)
