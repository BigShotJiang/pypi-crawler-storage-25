"""Alias historique de :class:`OpenDataResource` (compatibilité PR #18)."""

from __future__ import annotations

from baobab_altered_api.resources.open_data_resource import OpenDataResource


class OpenDataAccess(OpenDataResource):
    """Alias de :class:`~baobab_altered_api.resources.OpenDataResource`."""
