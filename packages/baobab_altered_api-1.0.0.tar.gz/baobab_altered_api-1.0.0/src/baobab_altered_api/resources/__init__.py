"""Ressources HTTP Altered (cartes, référentiels, decks, marketplace, Open Data)."""

from baobab_altered_api.resources.async_cards_resource import AsyncCardsResource
from baobab_altered_api.resources.async_decks_resource import AsyncDecksResource
from baobab_altered_api.resources.async_marketplace_resource import (
    AsyncMarketplaceResource,
)
from baobab_altered_api.resources.async_referentials_resource import (
    AsyncReferentialsResource,
)
from baobab_altered_api.resources.cards_resource import CardsResource
from baobab_altered_api.resources.decks_resource import DecksResource
from baobab_altered_api.resources.marketplace_resource import MarketplaceResource
from baobab_altered_api.resources.async_open_data_resource import AsyncOpenDataResource
from baobab_altered_api.resources.open_data_access import OpenDataAccess
from baobab_altered_api.resources.open_data_catalog import OpenDataCatalog
from baobab_altered_api.resources.open_data_downloader import OpenDataDownloader
from baobab_altered_api.resources.open_data_reader import OpenDataReader
from baobab_altered_api.resources.open_data_resource import OpenDataResource
from baobab_altered_api.resources.referentials_resource import ReferentialsResource

__all__: tuple[str, ...] = (
    "AsyncCardsResource",
    "AsyncDecksResource",
    "AsyncMarketplaceResource",
    "AsyncReferentialsResource",
    "CardsResource",
    "DecksResource",
    "MarketplaceResource",
    "AsyncOpenDataResource",
    "OpenDataAccess",
    "OpenDataCatalog",
    "OpenDataDownloader",
    "OpenDataReader",
    "OpenDataResource",
    "ReferentialsResource",
)
