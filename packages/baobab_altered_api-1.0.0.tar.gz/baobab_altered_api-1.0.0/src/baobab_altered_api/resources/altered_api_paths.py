"""Chemins HTTP Altered (hypothèses documentées — voir ``docs/api_observations``)."""

from __future__ import annotations


class AlteredApiPaths:
    """Constantes de chemins relatifs à ``AlteredApiConfig.base_url``.

    Les segments restent **provisoires** tant que le portail développeur
    Altered ne les confirme pas officiellement.
    """

    CARDS: str = "/v1/cards"
    DECKS: str = "/v1/decks"
    FACTIONS: str = "/v1/factions"
    SETS: str = "/v1/sets"
    RARITIES: str = "/v1/rarities"
    CARD_TYPES: str = "/v1/card-types"
    MARKETPLACE_OFFERS: str = "/v1/marketplace/offers"

    @staticmethod
    def card_by_id(card_id: str) -> str:
        """Chemin de détail carte.

        :param card_id: Identifiant logique (non vide).
        :return: Chemin relatif ``/v1/cards/{id}``.
        """
        return f"{AlteredApiPaths.CARDS}/{card_id.strip()}"

    @staticmethod
    def deck_by_id(deck_id: str) -> str:
        """Chemin de détail deck."""
        return f"{AlteredApiPaths.DECKS}/{deck_id.strip()}"
