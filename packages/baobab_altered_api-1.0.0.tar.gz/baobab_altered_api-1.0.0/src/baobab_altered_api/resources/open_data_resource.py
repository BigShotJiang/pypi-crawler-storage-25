"""Ressource Open Data synchrone (cahier des charges / US-016)."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from baobab_api_call import SyncApiClient

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_api_error import AlteredApiError
from baobab_altered_api.mappers.altered_open_data_json_mapper import (
    AlteredOpenDataJsonMapper,
)
from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_open_data_snapshot import AlteredOpenDataSnapshot
from baobab_altered_api.resources.open_data_catalog import OpenDataCatalog
from baobab_altered_api.internal.open_data_file_io import DEFAULT_OPEN_DATA_MAX_BYTES
from baobab_altered_api.resources.open_data_downloader import OpenDataDownloader
from baobab_altered_api.resources.open_data_reader import OpenDataReader


class OpenDataResource:
    """Export Open Data : téléchargement explicite et lecture locale.

    Aucun appel réseau à l'instanciation. Chargez un snapshot via
    :meth:`load_from_file` ou :meth:`fetch_snapshot`, puis parcourez les cartes
    avec :meth:`iter_cards`.
    """

    def __init__(
        self,
        config: AlteredApiConfig,
        http: SyncApiClient,
        *,
        max_bytes: int = DEFAULT_OPEN_DATA_MAX_BYTES,
    ) -> None:
        self._config = config
        self._downloader = OpenDataDownloader(config, http, max_bytes=max_bytes)
        self._max_bytes = max_bytes
        self._snapshot: AlteredOpenDataSnapshot | None = None

    @property
    def snapshot(self) -> AlteredOpenDataSnapshot | None:
        """Dernier snapshot chargé en mémoire, le cas échéant."""
        return self._snapshot

    def fetch_snapshot(self) -> AlteredOpenDataSnapshot:
        """Télécharge l'export configuré et le mappe en mémoire (sans fichier)."""
        root = self._downloader.fetch_root_mapping()
        self._snapshot = AlteredOpenDataJsonMapper.snapshot_from_mapping(root)
        return self._snapshot

    def load_from_file(self, path: Path | str) -> AlteredOpenDataSnapshot:
        """Charge un export local (contrôle de taille avant parsing complet)."""
        self._snapshot = OpenDataReader.from_path(path, max_bytes=self._max_bytes)
        return self._snapshot

    def save_snapshot(
        self,
        destination: Path | str,
        *,
        overwrite: bool = False,
    ) -> Path:
        """Télécharge l'export vers un chemin local (alias explicite CDC)."""
        return self._downloader.download_to(destination, overwrite=overwrite)

    def download_to(
        self,
        destination: Path | str,
        *,
        overwrite: bool = False,
    ) -> Path:
        """Alias de :meth:`save_snapshot` pour compatibilité."""
        return self.save_snapshot(destination, overwrite=overwrite)

    def iter_cards(self) -> Iterator[AlteredCardSummary]:
        """Itère les cartes du snapshot courant."""
        if self._snapshot is None:
            raise AlteredApiError(
                "Open Data snapshot not loaded; call load_from_file or fetch_snapshot first",
                error_code="OPEN_DATA_NOT_LOADED",
            )
        return self._snapshot.iter_cards()

    @staticmethod
    def catalog_from_path(path: Path | str) -> OpenDataCatalog:
        """Construit un catalogue indexé depuis un fichier local."""
        return OpenDataCatalog(OpenDataReader.from_path(path))
