"""Ressource marketplace lecture seule (aucune opération d'achat/vente)."""

from __future__ import annotations

from collections.abc import Mapping

from baobab_api_call import ApiResponse, SyncApiClient

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_marketplace_offer_json_mapper import (
    AlteredMarketplaceOfferJsonMapper,
)
from baobab_altered_api.models.altered_marketplace_offer import AlteredMarketplaceOffer
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)


class MarketplaceResource:
    """Consultation d'offres marketplace — **lecture seule**."""

    def __init__(self, http: SyncApiClient) -> None:
        self._http = http

    def list_offers(self) -> tuple[AlteredMarketplaceOffer, ...]:
        """Liste les offres (GET hypothétique)."""
        response = self._http.get(AlteredApiPaths.MARKETPLACE_OFFERS)
        return MarketplaceResource.parse_list_response(response)

    @staticmethod
    def parse_list_response(
        response: ApiResponse,
    ) -> tuple[AlteredMarketplaceOffer, ...]:
        """Décode une réponse liste d'offres."""
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        data = payload.data
        path = AlteredApiPaths.MARKETPLACE_OFFERS
        items_key = ("items", "data", "offers")
        if isinstance(data, Mapping):
            for key in items_key:
                block = data.get(key)
                if isinstance(block, list):
                    return MarketplaceResource._map_offers(block, path)
        if isinstance(data, list):
            return MarketplaceResource._map_offers(data, path)
        msg = "marketplace list root must be mapping or array"
        raise AlteredMappingError(msg, path=path)

    @staticmethod
    def _map_offers(
        entries: list[object],
        path: str,
    ) -> tuple[AlteredMarketplaceOffer, ...]:
        out: list[AlteredMarketplaceOffer] = []
        for entry in entries:
            if isinstance(entry, Mapping):
                out.append(
                    AlteredMarketplaceOfferJsonMapper.offer_from_mapping(
                        entry, path=path
                    )
                )
        return tuple(out)
