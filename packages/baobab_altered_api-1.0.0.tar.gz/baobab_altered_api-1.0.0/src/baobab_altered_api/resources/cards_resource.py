"""Ressource synchrone de lecture des cartes Altered."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from baobab_api_call import ApiResponse, SyncApiClient

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_cards_json_mapper import AlteredCardsJsonMapper
from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_page import AlteredPage
from baobab_altered_api.models.altered_pagination_params import AlteredPaginationParams
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.card_search_filters import CardSearchFilters
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)


class CardsResource:
    """Opérations HTTP synchrones de lecture sur les cartes.

    :param http: Client du socle ``baobab-api-call`` (transport injecté).
    """

    def __init__(self, http: SyncApiClient) -> None:
        self._http = http

    def search(
        self,
        filters: CardSearchFilters | None = None,
    ) -> AlteredPage[AlteredCardSummary]:
        """Liste ou recherche de cartes (GET ``/v1/cards`` — hypothèse).

        :param filters: Critères optionnels ; ``None`` pour requête sans filtre.
        :return: Page typée de résumés carte.
        """
        params = filters.to_query_params() if filters is not None else {}
        response = self._http.get(AlteredApiPaths.CARDS, params=params or None)
        return self._page_from_response(response)

    def get_by_id(self, card_id: str) -> AlteredCardSummary:
        """Récupère une carte par identifiant.

        :param card_id: Référence carte non vide.
        :return: Résumé carte mappé.
        """
        response = self._http.get(AlteredApiPaths.card_by_id(card_id))
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        data = payload.data
        if isinstance(data, Mapping):
            return AlteredCommonModelsJsonMapper.card_summary_from_mapping(data)
        msg = "card detail root must be a mapping"
        raise AlteredMappingError(msg, path=AlteredApiPaths.card_by_id(card_id))

    def iter_pages(
        self,
        filters: CardSearchFilters | None = None,
        *,
        max_pages: int = 10,
    ) -> Iterator[AlteredPage[AlteredCardSummary]]:
        """Parcourt les pages jusqu'à épuisement, limite ou absence de curseur suivant.

        :param filters: Filtres initiaux (curseur mis à jour entre pages).
        :param max_pages: Plafond de pages (>= 1).
        :yields: Pages successives.
        :raises ValueError: Si ``max_pages`` < 1.
        """
        if max_pages < 1:
            msg = "max_pages must be >= 1"
            raise ValueError(msg)
        base = filters or CardSearchFilters()
        pagination = base.pagination or AlteredPaginationParams()
        cursor: str | None = pagination.cursor
        page_num = pagination.page
        for _ in range(max_pages):
            if cursor is not None:
                page_params = AlteredPaginationParams(
                    limit=pagination.limit,
                    cursor=cursor,
                    max_iterations_guard=pagination.max_iterations_guard,
                )
            elif page_num is not None:
                page_params = AlteredPaginationParams(
                    limit=pagination.limit,
                    page=page_num,
                    max_iterations_guard=pagination.max_iterations_guard,
                )
            else:
                page_params = pagination
            current = CardSearchFilters(
                name=base.name,
                faction=base.faction,
                set_code=base.set_code,
                rarity=base.rarity,
                card_type=base.card_type,
                locale=base.locale,
                pagination=page_params,
                sort_field=base.sort_field,
                sort_descending=base.sort_descending,
            )
            page = self.search(current)
            yield page
            if not page.next_cursor and page.has_next_page is not True:
                break
            if page.next_cursor:
                cursor = page.next_cursor
                page_num = None
                continue
            if page_num is not None:
                page_num += 1
                continue
            break

    def iter_cards(
        self,
        filters: CardSearchFilters | None = None,
        *,
        max_pages: int = 10,
    ) -> Iterator[AlteredCardSummary]:
        """Aplatit :meth:`iter_pages` en flux de cartes."""
        for page in self.iter_pages(filters, max_pages=max_pages):
            yield from page.items

    @staticmethod
    def _page_from_response(response: ApiResponse) -> AlteredPage[AlteredCardSummary]:
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        data = payload.data
        if isinstance(data, Mapping):
            return AlteredCardsJsonMapper.page_from_mapping(
                data, path=AlteredApiPaths.CARDS
            )
        if isinstance(data, list):
            wrapper: dict[str, Any] = {"items": data}
            if payload.pagination:
                wrapper["pagination"] = dict(payload.pagination)
            return AlteredCardsJsonMapper.page_from_mapping(
                wrapper, path=AlteredApiPaths.CARDS
            )
        msg = "card list root must be mapping or array"
        raise AlteredMappingError(msg, path=AlteredApiPaths.CARDS)
