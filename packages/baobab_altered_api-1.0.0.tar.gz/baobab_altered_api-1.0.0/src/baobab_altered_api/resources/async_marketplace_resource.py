"""Ressource marketplace async (lecture seule)."""

from __future__ import annotations

from baobab_api_call import AsyncApiClient

from baobab_altered_api.models.altered_marketplace_offer import AlteredMarketplaceOffer
from baobab_altered_api.resources.altered_api_paths import AlteredApiPaths
from baobab_altered_api.resources.marketplace_resource import MarketplaceResource


class AsyncMarketplaceResource:
    """Consultation async d'offres — lecture seule."""

    def __init__(self, http: AsyncApiClient) -> None:
        self._http = http

    async def list_offers(self) -> tuple[AlteredMarketplaceOffer, ...]:
        """Liste async des offres."""
        response = await self._http.get(AlteredApiPaths.MARKETPLACE_OFFERS)
        return MarketplaceResource.parse_list_response(response)
