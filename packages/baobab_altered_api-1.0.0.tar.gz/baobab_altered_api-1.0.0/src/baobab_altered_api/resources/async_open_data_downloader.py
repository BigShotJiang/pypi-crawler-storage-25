"""Téléchargement asynchrone explicite d'un export Open Data."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from baobab_api_call import AsyncApiClient

from baobab_altered_api.config.altered_api_config import AlteredApiConfig
from baobab_altered_api.exceptions.altered_config_error import AlteredConfigError
from baobab_altered_api.exceptions.altered_open_data_download_error import (
    AlteredOpenDataDownloadError,
)
from baobab_altered_api.internal.open_data_file_io import DEFAULT_OPEN_DATA_MAX_BYTES
from baobab_altered_api.transports.response_handler import (
    AlteredTransportResponseHandler,
)


class AsyncOpenDataDownloader:
    """Variante async de :class:`~baobab_altered_api.resources.OpenDataDownloader`."""

    def __init__(
        self,
        config: AlteredApiConfig,
        http: AsyncApiClient,
        *,
        max_bytes: int = DEFAULT_OPEN_DATA_MAX_BYTES,
    ) -> None:
        self._config = config
        self._http = http
        self._max_bytes = max_bytes

    async def fetch_root_mapping(self) -> Mapping[str, Any]:
        """GET async de l'export (racine JSON, sans écriture disque)."""
        url = self._config.open_data_url
        if url is None:
            raise AlteredConfigError(
                "open_data_url must be set in AlteredApiConfig to download Open Data"
            )
        response = await self._http.get(url)
        if response.is_error:
            raise AlteredOpenDataDownloadError(
                f"Open Data download failed with HTTP {response.status_code}",
            )
        payload = AlteredTransportResponseHandler.json_payload_or_raise(response)
        raw = payload.data
        text = json.dumps(raw, ensure_ascii=False)
        if len(text.encode("utf-8")) > self._max_bytes:
            raise AlteredOpenDataDownloadError(
                "Open Data export exceeds configured max_bytes limit",
            )
        if isinstance(raw, Mapping):
            return raw
        msg = "Open Data root must be a JSON object"
        raise AlteredOpenDataDownloadError(msg)

    async def download_to(
        self,
        destination: Path | str,
        *,
        overwrite: bool = False,
    ) -> Path:
        """Télécharge l'export vers ``destination``."""
        dest = Path(destination)
        if dest.exists() and not overwrite:
            raise AlteredOpenDataDownloadError(
                "destination file already exists; pass overwrite=True to replace",
                path=str(dest),
            )
        root = await self.fetch_root_mapping()
        text = json.dumps(root, ensure_ascii=False, indent=2)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(text, encoding="utf-8")
        return dest.resolve()
