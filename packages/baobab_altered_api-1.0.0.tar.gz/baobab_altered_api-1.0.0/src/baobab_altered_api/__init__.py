"""Point d’entrée public du package ``baobab_altered_api``.

L’import de ce module ne doit pas créer de client HTTP, lire la configuration
depuis l’environnement ni configurer le logging global. Les classes client
exposées ici ne réalisent aucune requête tant qu’aucune méthode HTTP n’est
appelée sur ``AlteredClient.http`` ou ``AsyncAlteredClient.http``.
"""

from __future__ import annotations

from baobab_altered_api.auth import AlteredAuthFactory
from baobab_altered_api.clients import AlteredClient, AsyncAlteredClient
from baobab_altered_api.config import (
    AlteredApiConfig,
    AlteredLocale,
    load_config_from_env,
    to_api_client_config,
)
from baobab_altered_api.exceptions import AlteredConfigError

__version__ = "1.0.0"

__all__: tuple[str, ...] = (
    "__version__",
    "AlteredApiConfig",
    "AlteredAuthFactory",
    "AlteredClient",
    "AlteredConfigError",
    "AlteredLocale",
    "AsyncAlteredClient",
    "load_config_from_env",
    "to_api_client_config",
)
