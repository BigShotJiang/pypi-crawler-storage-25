"""Extraction de métadonnées de pagination depuis des fragments JSON."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError


class AlteredPaginationJsonMapper:
    """Lit totaux et curseurs depuis des formes JSON usuelles (hypothèses documentées)."""

    @staticmethod
    def total_count_from_mapping(data: Mapping[str, Any]) -> int | None:
        """Retourne un total entier positif ou ``None`` si absent / non entier."""
        for key in ("totalCount", "total", "itemTotal", "count"):
            raw = data.get(key)
            if raw is None:
                continue
            if isinstance(raw, bool):
                continue
            if isinstance(raw, int) and raw >= 0:
                return raw
        return None

    @staticmethod
    def cursors_from_mapping(
        data: Mapping[str, Any],
        *,
        path: str | None = None,
    ) -> tuple[str | None, str | None]:
        """Retourne ``(next_cursor, previous_cursor)`` depuis l'objet ou un bloc imbriqué."""
        nested = AlteredPaginationJsonMapper._maybe_nested_pagination(data)
        source: Mapping[str, Any] = nested if nested is not None else data
        nxt = AlteredPaginationJsonMapper._cursor_string(
            source,
            ("nextCursor", "next", "after"),
            path=path,
        )
        prev = AlteredPaginationJsonMapper._cursor_string(
            source,
            ("previousCursor", "prev", "prevCursor", "before"),
            path=path,
        )
        return nxt, prev

    @staticmethod
    def has_next_from_mapping(data: Mapping[str, Any]) -> bool | None:
        """Lit un indicateur ``hasNext`` / ``has_next`` si présent et booléen."""
        for key in ("hasNext", "has_next", "hasMore", "has_more"):
            if key not in data:
                continue
            val = data[key]
            if isinstance(val, bool):
                return val
        return None

    @staticmethod
    def _maybe_nested_pagination(
        data: Mapping[str, Any],
    ) -> Mapping[str, Any] | None:
        for key in ("pagination", "pageInfo", "page_info", "cursors"):
            block = data.get(key)
            if isinstance(block, Mapping):
                return block
        return None

    @staticmethod
    def _cursor_string(
        data: Mapping[str, Any],
        keys: tuple[str, ...],
        *,
        path: str | None,
    ) -> str | None:
        for key in keys:
            val = data.get(key)
            if val is None:
                continue
            if isinstance(val, str):
                s = val.strip()
                if s:
                    return s
                continue
            if isinstance(val, Mapping):
                inner = val.get("cursor") or val.get("token")
                if isinstance(inner, str) and inner.strip():
                    return inner.strip()
                continue
            msg = f"pagination field {key!r} must be a string or mapping"
            raise AlteredMappingError(msg, path=path)
        return None
