"""Mappers JSON vers modèles Altered."""

from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.mappers.altered_pagination_json_mapper import (
    AlteredPaginationJsonMapper,
)

__all__: tuple[str, ...] = (
    "AlteredCommonModelsJsonMapper",
    "AlteredPaginationJsonMapper",
)
