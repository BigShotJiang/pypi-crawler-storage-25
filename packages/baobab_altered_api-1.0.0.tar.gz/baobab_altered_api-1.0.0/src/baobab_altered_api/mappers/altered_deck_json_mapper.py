"""Mapping JSON deck."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.models.altered_deck import AlteredDeck, AlteredDeckCardLine
from baobab_altered_api.models.altered_ref import AlteredRef


class AlteredDeckJsonMapper:
    """Construit :class:`~baobab_altered_api.models.altered_deck.AlteredDeck`."""

    @staticmethod
    def deck_from_mapping(
        data: Mapping[str, Any],
        *,
        path: str | None = None,
    ) -> AlteredDeck:
        """Mappe un deck depuis un objet JSON."""
        ref_val = None
        for key in ("id", "ref", "deckId"):
            if key in data and data[key] is not None:
                ref_val = data[key]
                break
        if ref_val is None:
            msg = "deck requires id, ref or deckId"
            raise AlteredMappingError(msg, path=path)
        ref = AlteredCommonModelsJsonMapper.ref_from_json(ref_val, field="deck_ref")
        name_val = data.get("name")
        name = (
            name_val.strip() if isinstance(name_val, str) and name_val.strip() else None
        )
        lines: list[AlteredDeckCardLine] = []
        cards_block = data.get("cards")
        if isinstance(cards_block, list):
            for entry in cards_block:
                if not isinstance(entry, Mapping):
                    continue
                cid = entry.get("id") or entry.get("cardId")
                if cid is None:
                    continue
                qty_raw = entry.get("quantity", 1)
                qty = (
                    int(qty_raw)
                    if isinstance(qty_raw, int) and not isinstance(qty_raw, bool)
                    else 1
                )
                lines.append(
                    AlteredDeckCardLine(
                        card_ref=AlteredRef(str(cid).strip()),
                        quantity=max(1, qty),
                    )
                )
        consumed = frozenset({"id", "ref", "deckId", "name", "cards"})
        raw = {k: v for k, v in data.items() if k not in consumed} or None
        return AlteredDeck(ref=ref, name=name, cards=tuple(lines), raw=raw)
