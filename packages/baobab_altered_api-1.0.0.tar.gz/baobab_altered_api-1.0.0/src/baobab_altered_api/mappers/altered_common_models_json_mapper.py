"""Mapping JSON tolérant vers les modèles communs Altered (BL-005-002)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_image import AlteredImage
from baobab_altered_api.models.altered_localized_label import AlteredLocalizedLabel
from baobab_altered_api.models.altered_rarity import AlteredRarity
from baobab_altered_api.models.altered_ref import AlteredRef
from baobab_altered_api.models.altered_set import AlteredSet


class AlteredCommonModelsJsonMapper:
    """Convertit des fragments JSON typiques en dataclasses communes.

    Les clés reconnues restent **indicatives** : voir ``docs/api_observations/mappers.md``.
    Les messages d'erreur :class:`~baobab_altered_api.exceptions.AlteredMappingError`
    restent génériques (aucune fuite de payload complet).

    Toutes les méthodes sont statiques pour faciliter la composition sans état.
    """

    _REF_STRING_KEYS: tuple[str, ...] = ("ref", "id")
    _CARD_REF_KEYS: tuple[str, ...] = ("id", "ref", "cardId", "card_id")

    @staticmethod
    def ref_from_json(
        value: Any,
        *,
        field: str = "ref",
        path: str | None = None,
    ) -> AlteredRef:
        """Construit un :class:`~baobab_altered_api.models.AlteredRef` depuis une valeur JSON.

        :param value: Chaîne non vide ou entier (converti en décimal).
        :param field: Nom logique du champ (message d'erreur).
        :param path: Contexte HTTP ou ressource, sans secret.
        :return: Référence normalisée.
        :raises AlteredMappingError: Type ou contenu incompatible.
        """
        if isinstance(value, bool):
            msg = f"{field} must be a string or integer, not boolean"
            raise AlteredMappingError(msg, path=path)
        if isinstance(value, int):
            value = str(value)
        if not isinstance(value, str) or not value.strip():
            msg = f"{field} must be a non-empty string"
            raise AlteredMappingError(msg, path=path)
        return AlteredRef(value)

    @staticmethod
    def optional_ref_from_json(
        value: Any,
        *,
        field: str = "ref",
        path: str | None = None,
    ) -> AlteredRef | None:
        """Comme :meth:`ref_from_json` mais accepte ``None`` ou chaîne vide (→ ``None``)."""
        if value is None:
            return None
        if isinstance(value, str) and not value.strip():
            return None
        return AlteredCommonModelsJsonMapper.ref_from_json(
            value, field=field, path=path
        )

    @staticmethod
    def image_from_mapping(
        data: Any,
        *,
        path: str | None = None,
    ) -> AlteredImage | None:
        """Image optionnelle depuis un objet JSON ou ``None``."""
        if data is None:
            return None
        if not isinstance(data, Mapping):
            msg = "image payload must be a mapping or null"
            raise AlteredMappingError(msg, path=path)
        raw_dict: dict[str, Any] = dict(data)
        url: str | None = None
        for key in ("url", "href", "src"):
            candidate = raw_dict.get(key)
            if isinstance(candidate, str) and candidate.strip():
                url = candidate.strip()
                break
        consumed = frozenset({"url", "href", "src"})
        rest = {k: v for k, v in raw_dict.items() if k not in consumed}
        raw_out: dict[str, Any] | None = rest or None
        return AlteredImage(url=url, raw=raw_out)

    @staticmethod
    def localized_label_from_mapping(
        data: Any,
        *,
        path: str | None = None,
    ) -> AlteredLocalizedLabel:
        """Libellé localisé : exige au moins un texte par défaut."""
        if not isinstance(data, Mapping):
            msg = "localized label must be a mapping"
            raise AlteredMappingError(msg, path=path)
        d: dict[str, Any] = dict(data)
        default: str | None = None
        for key in ("default", "label", "value"):
            val = d.get(key)
            if isinstance(val, str) and val.strip():
                default = val.strip()
                break
        if default is None:
            msg = "localized label requires default, label or value string"
            raise AlteredMappingError(msg, path=path)
        by_locale: dict[str, str] | None = None
        for key in ("by_locale", "locales", "translations", "byLocale"):
            block = d.get(key)
            if isinstance(block, Mapping):
                pairs: dict[str, str] = {}
                for loc_key, loc_val in block.items():
                    if isinstance(loc_key, str) and isinstance(loc_val, str):
                        pairs[loc_key] = loc_val
                by_locale = pairs or None
                break
        return AlteredLocalizedLabel(default=default, by_locale=by_locale)

    @staticmethod
    def faction_from_mapping(
        data: Any,
        *,
        path: str | None = None,
    ) -> AlteredFaction | None:
        """Faction optionnelle ; champs inconnus conservés dans ``raw``."""
        if data is None:
            return None
        if not isinstance(data, Mapping):
            msg = "faction payload must be a mapping or null"
            raise AlteredMappingError(msg, path=path)
        d: dict[str, Any] = dict(data)
        ref_obj: AlteredRef | None = None
        for key in AlteredCommonModelsJsonMapper._REF_STRING_KEYS:
            if key in d:
                ref_obj = AlteredCommonModelsJsonMapper.optional_ref_from_json(
                    d[key], field=key, path=path
                )
                break
        name: str | None = None
        for key in ("name", "label"):
            val = d.get(key)
            if isinstance(val, str):
                stripped = val.strip()
                if stripped:
                    name = stripped
                    break
        consumed = frozenset({"ref", "id", "name", "label"})
        rest = {k: v for k, v in d.items() if k not in consumed}
        raw_out: dict[str, Any] | None = rest or None
        return AlteredFaction(ref=ref_obj, name=name, raw=raw_out)

    @staticmethod
    def set_from_mapping(
        data: Any,
        *,
        path: str | None = None,
    ) -> AlteredSet | None:
        """Extension / série (:class:`~baobab_altered_api.models.AlteredSet`) optionnelle."""
        if data is None:
            return None
        if not isinstance(data, Mapping):
            msg = "set payload must be a mapping or null"
            raise AlteredMappingError(msg, path=path)
        d: dict[str, Any] = dict(data)
        ref_obj: AlteredRef | None = None
        for key in AlteredCommonModelsJsonMapper._REF_STRING_KEYS:
            if key in d:
                ref_obj = AlteredCommonModelsJsonMapper.optional_ref_from_json(
                    d[key], field=key, path=path
                )
                break
        code: str | None = None
        c_val = d.get("code")
        if isinstance(c_val, str) and c_val.strip():
            code = c_val.strip()
        name: str | None = None
        n_val = d.get("name")
        if isinstance(n_val, str) and n_val.strip():
            name = n_val.strip()
        consumed = frozenset({"ref", "id", "code", "name"})
        rest = {k: v for k, v in d.items() if k not in consumed}
        raw_out: dict[str, Any] | None = rest or None
        return AlteredSet(ref=ref_obj, code=code, name=name, raw=raw_out)

    @staticmethod
    def rarity_from_mapping(
        data: Any,
        *,
        path: str | None = None,
    ) -> AlteredRarity | None:
        """Rareté optionnelle."""
        if data is None:
            return None
        if not isinstance(data, Mapping):
            msg = "rarity payload must be a mapping or null"
            raise AlteredMappingError(msg, path=path)
        d: dict[str, Any] = dict(data)
        code: str | None = None
        c_val = d.get("code")
        if isinstance(c_val, str) and c_val.strip():
            code = c_val.strip()
        name: str | None = None
        n_val = d.get("name")
        if isinstance(n_val, str) and n_val.strip():
            name = n_val.strip()
        consumed = frozenset({"code", "name"})
        rest = {k: v for k, v in d.items() if k not in consumed}
        raw_out: dict[str, Any] | None = rest or None
        return AlteredRarity(code=code, name=name, raw=raw_out)

    @staticmethod
    def card_summary_from_mapping(
        data: Any,
        *,
        path: str | None = None,
        keep_unknown_in_raw: bool = True,
    ) -> AlteredCardSummary:
        """Résumé carte depuis un objet JSON racine.

        :param data: Mapping JSON (objet carte minimal ou étendu).
        :param path: Contexte de requête optionnel.
        :param keep_unknown_in_raw: Si vrai, les clés non consommées vont dans ``raw``.
        :return: :class:`~baobab_altered_api.models.AlteredCardSummary`.
        :raises AlteredMappingError: Objet non mapping ou identifiant carte absent.
        """
        if not isinstance(data, Mapping):
            msg = "card summary root must be a mapping"
            raise AlteredMappingError(msg, path=path)
        root: dict[str, Any] = dict(data)
        ref_val: Any = None
        for key in AlteredCommonModelsJsonMapper._CARD_REF_KEYS:
            if key in root and root[key] is not None:
                ref_val = root[key]
                break
        if ref_val is None:
            msg = "card summary requires one of id, ref, cardId, card_id"
            raise AlteredMappingError(msg, path=path)
        ref = AlteredCommonModelsJsonMapper.ref_from_json(
            ref_val, field="card_ref", path=path
        )
        name: str | None = None
        for key in ("name", "title"):
            val = root.get(key)
            if isinstance(val, str) and val.strip():
                name = val.strip()
                break
        faction = AlteredCommonModelsJsonMapper.faction_from_mapping(
            root.get("faction"), path=path
        )
        expansion_payload = None
        for key in ("expansion", "set", "package"):
            if key in root:
                expansion_payload = root.get(key)
                break
        if isinstance(expansion_payload, str):
            code = expansion_payload.strip()
            expansion = (
                AlteredSet(code=code, name=None, ref=None, raw=None) if code else None
            )
        else:
            expansion = AlteredCommonModelsJsonMapper.set_from_mapping(
                expansion_payload, path=path
            )
        rarity_raw = root.get("rarity")
        if isinstance(rarity_raw, str):
            rc = rarity_raw.strip()
            rarity = AlteredRarity(code=rc, name=None, raw=None) if rc else None
        else:
            rarity = AlteredCommonModelsJsonMapper.rarity_from_mapping(
                rarity_raw, path=path
            )
        image_payload = None
        for key in ("image", "thumbnail", "art"):
            if key in root:
                image_payload = root.get(key)
                break
        image = AlteredCommonModelsJsonMapper.image_from_mapping(
            image_payload, path=path
        )
        consumed = frozenset(
            {
                "id",
                "ref",
                "cardId",
                "card_id",
                "name",
                "title",
                "faction",
                "expansion",
                "set",
                "package",
                "rarity",
                "image",
                "thumbnail",
                "art",
            }
        )
        raw_out: dict[str, Any] | None
        if keep_unknown_in_raw:
            leftovers = {k: v for k, v in root.items() if k not in consumed}
            raw_out = leftovers or None
        else:
            raw_out = None
        return AlteredCardSummary(
            ref=ref,
            name=name,
            faction=faction,
            expansion=expansion,
            rarity=rarity,
            image=image,
            raw=raw_out,
        )
