"""Mapping JSON export Open Data local (plat ou hiérarchique)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_faction import AlteredFaction
from baobab_altered_api.models.altered_open_data_card_entry import (
    AlteredOpenDataCardEntry,
)
from baobab_altered_api.models.altered_open_data_faction_node import (
    AlteredOpenDataFactionNode,
)
from baobab_altered_api.models.altered_open_data_set_node import AlteredOpenDataSetNode
from baobab_altered_api.models.altered_open_data_snapshot import AlteredOpenDataSnapshot
from baobab_altered_api.models.altered_set import AlteredSet


class AlteredOpenDataJsonMapper:
    """Construit :class:`~baobab_altered_api.models.AlteredOpenDataSnapshot`."""

    @staticmethod
    def snapshot_from_mapping(data: Mapping[str, Any]) -> AlteredOpenDataSnapshot:
        """Mappe la racine d'un export Open Data (liste plate et/ou arborescence)."""
        version_raw = data.get("version")
        version = (
            int(version_raw)
            if isinstance(version_raw, int) and not isinstance(version_raw, bool)
            else None
        )
        summaries: list[AlteredCardSummary] = []
        set_nodes: list[AlteredOpenDataSetNode] = []
        sets_block = data.get("sets")
        if isinstance(sets_block, list):
            for set_entry in sets_block:
                if isinstance(set_entry, Mapping):
                    node = AlteredOpenDataJsonMapper._set_node_from_mapping(set_entry)
                    set_nodes.append(node)
                    for fac in node.factions:
                        for entry in fac.cards:
                            summaries.append(entry.card)
        cards_block = data.get("cards")
        if isinstance(cards_block, list):
            for entry in cards_block:
                if isinstance(entry, Mapping):
                    summaries.append(
                        AlteredCommonModelsJsonMapper.card_summary_from_mapping(entry)
                    )
        return AlteredOpenDataSnapshot(
            version=version,
            cards=tuple(summaries),
            sets=tuple(set_nodes),
            raw=dict(data),
        )

    @staticmethod
    def _set_node_from_mapping(data: Mapping[str, Any]) -> AlteredOpenDataSetNode:
        expansion = AlteredCommonModelsJsonMapper.set_from_mapping(data)
        if expansion is None:
            code_raw = data.get("code")
            code = code_raw.strip() if isinstance(code_raw, str) else None
            name_raw = data.get("name")
            name = name_raw.strip() if isinstance(name_raw, str) else None
            expansion = AlteredSet(code=code, name=name, ref=None, raw=None)
        factions_out: list[AlteredOpenDataFactionNode] = []
        factions_block = data.get("factions")
        if isinstance(factions_block, list):
            for fac_entry in factions_block:
                if isinstance(fac_entry, Mapping):
                    factions_out.append(
                        AlteredOpenDataJsonMapper._faction_node_from_mapping(
                            fac_entry, expansion=expansion
                        )
                    )
        return AlteredOpenDataSetNode(
            expansion=expansion,
            factions=tuple(factions_out),
        )

    @staticmethod
    def _faction_node_from_mapping(
        data: Mapping[str, Any],
        *,
        expansion: AlteredSet,
    ) -> AlteredOpenDataFactionNode:
        faction = AlteredCommonModelsJsonMapper.faction_from_mapping(data)
        if faction is None:
            name_raw = data.get("name")
            name = name_raw.strip() if isinstance(name_raw, str) else "unknown"
            faction = AlteredFaction(name=name, ref=None, raw=None)
        card_entries: list[AlteredOpenDataCardEntry] = []
        cards_block = data.get("cards")
        if isinstance(cards_block, list):
            for card_raw in cards_block:
                if isinstance(card_raw, Mapping):
                    card_entries.append(
                        AlteredOpenDataJsonMapper._card_entry_from_mapping(
                            card_raw,
                            expansion=expansion,
                            faction=faction,
                        )
                    )
        return AlteredOpenDataFactionNode(faction=faction, cards=tuple(card_entries))

    @staticmethod
    def _card_entry_from_mapping(
        data: Mapping[str, Any],
        *,
        expansion: AlteredSet,
        faction: AlteredFaction,
    ) -> AlteredOpenDataCardEntry:
        number_raw = data.get("number")
        number: str | None = None
        if isinstance(number_raw, (str, int)) and not isinstance(number_raw, bool):
            number = str(number_raw).strip() or None
        enriched = dict(data)
        if "faction" not in enriched:
            enriched["faction"] = {
                "id": faction.ref.value if faction.ref else None,
                "name": faction.name,
            }
        if "set" not in enriched and "expansion" not in enriched:
            enriched["set"] = expansion.code or (
                expansion.ref.value if expansion.ref else expansion.name
            )
        summary = AlteredCommonModelsJsonMapper.card_summary_from_mapping(enriched)
        return AlteredOpenDataCardEntry(card=summary, number=number)
