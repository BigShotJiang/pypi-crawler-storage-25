"""Mapping JSON des listes et pages de cartes."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.mappers.altered_pagination_json_mapper import (
    AlteredPaginationJsonMapper,
)
from baobab_altered_api.models.altered_card_summary import AlteredCardSummary
from baobab_altered_api.models.altered_page import AlteredPage


class AlteredCardsJsonMapper:
    """Convertit les réponses JSON de listes cartes en :class:`~.altered_page.AlteredPage`."""

    _ITEM_KEYS: tuple[str, ...] = ("items", "data", "results", "cards")

    @staticmethod
    def page_from_mapping(
        data: Mapping[str, Any],
        *,
        path: str | None = None,
    ) -> AlteredPage[AlteredCardSummary]:
        """Construit une page de résumés carte depuis un objet JSON racine.

        :param data: Objet JSON (liste paginée typique).
        :param path: Contexte de requête pour erreurs.
        :return: Page immuable avec métadonnées de pagination si présentes.
        :raises AlteredMappingError: Racine invalide ou élément non mappable.
        """
        items_raw: list[Any] | None = None
        for key in AlteredCardsJsonMapper._ITEM_KEYS:
            block = data.get(key)
            if isinstance(block, list):
                items_raw = block
                break
        if items_raw is None:
            msg = "card page requires items, data, results or cards array"
            raise AlteredMappingError(msg, path=path)
        summaries: list[AlteredCardSummary] = []
        for entry in items_raw:
            summaries.append(
                AlteredCommonModelsJsonMapper.card_summary_from_mapping(
                    entry, path=path
                )
            )
        pagination_block = data.get("pagination")
        if isinstance(pagination_block, Mapping):
            total = AlteredPaginationJsonMapper.total_count_from_mapping(pagination_block)
            nxt, prev = AlteredPaginationJsonMapper.cursors_from_mapping(
                pagination_block, path=path
            )
            has_next = AlteredPaginationJsonMapper.has_next_from_mapping(pagination_block)
        else:
            total = AlteredPaginationJsonMapper.total_count_from_mapping(data)
            nxt, prev = AlteredPaginationJsonMapper.cursors_from_mapping(data, path=path)
            has_next = AlteredPaginationJsonMapper.has_next_from_mapping(data)
        if total is None:
            total = AlteredPaginationJsonMapper.total_count_from_mapping(data)
        if has_next is None and nxt is not None:
            has_next = True
        consumed = frozenset(AlteredCardsJsonMapper._ITEM_KEYS) | frozenset(
            {
                "pagination",
                "pageInfo",
                "page_info",
                "totalCount",
                "total",
                "itemTotal",
                "count",
                "nextCursor",
                "next",
                "previousCursor",
                "prev",
                "hasNext",
                "has_next",
                "hasMore",
            }
        )
        raw = {k: v for k, v in data.items() if k not in consumed} or None
        return AlteredPage(
            items=tuple(summaries),
            total_count=total,
            next_cursor=nxt,
            previous_cursor=prev,
            has_next_page=has_next,
            raw=raw,
        )
