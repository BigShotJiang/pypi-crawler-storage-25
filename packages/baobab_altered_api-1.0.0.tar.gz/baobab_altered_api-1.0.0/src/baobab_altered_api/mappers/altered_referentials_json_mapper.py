"""Mapping JSON des listes de référentiels."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.models.altered_card_type_reference import (
    AlteredCardTypeReference,
)
from baobab_altered_api.models.altered_faction_reference import AlteredFactionReference
from baobab_altered_api.models.altered_rarity_reference import AlteredRarityReference
from baobab_altered_api.models.altered_ref import AlteredRef
from baobab_altered_api.models.altered_set_reference import AlteredSetReference


class AlteredReferentialsJsonMapper:
    """Convertit des entrées JSON de référentiels en modèles typés."""

    @staticmethod
    def set_reference_from_mapping(data: Mapping[str, Any]) -> AlteredSetReference:
        """Mappe un objet set."""
        block = AlteredCommonModelsJsonMapper.set_from_mapping(data)
        if block is None:
            return AlteredSetReference()
        return AlteredSetReference(
            ref=block.ref,
            code=block.code,
            name=block.name,
            raw=block.raw,
        )

    @staticmethod
    def faction_reference_from_mapping(
        data: Mapping[str, Any],
    ) -> AlteredFactionReference:
        """Mappe un objet faction."""
        block = AlteredCommonModelsJsonMapper.faction_from_mapping(data)
        if block is None:
            return AlteredFactionReference()
        return AlteredFactionReference(ref=block.ref, name=block.name, raw=block.raw)

    @staticmethod
    def rarity_reference_from_mapping(
        data: Mapping[str, Any],
    ) -> AlteredRarityReference:
        """Mappe un objet rareté."""
        block = AlteredCommonModelsJsonMapper.rarity_from_mapping(data)
        if block is None:
            return AlteredRarityReference()
        return AlteredRarityReference(code=block.code, name=block.name, raw=block.raw)

    @staticmethod
    def card_type_reference_from_mapping(
        data: Mapping[str, Any],
    ) -> AlteredCardTypeReference:
        """Mappe un type de carte."""
        code = data.get("code")
        name = data.get("name")
        c = code.strip() if isinstance(code, str) and code.strip() else None
        n = name.strip() if isinstance(name, str) and name.strip() else None
        consumed = frozenset({"code", "name"})
        rest = {k: v for k, v in data.items() if k not in consumed} or None
        return AlteredCardTypeReference(code=c, name=n, raw=rest)

    @staticmethod
    def list_from_mapping(
        data: Mapping[str, Any],
        *,
        item_mapper: Any,
        path: str | None = None,
    ) -> tuple[Any, ...]:
        """Extrait un tableau sous ``items`` / ``data`` et mappe chaque entrée."""
        for key in ("items", "data", "results"):
            block = data.get(key)
            if isinstance(block, list):
                out: list[Any] = []
                for entry in block:
                    if not isinstance(entry, Mapping):
                        msg = "referential list entries must be mappings"
                        raise AlteredMappingError(msg, path=path)
                    out.append(item_mapper(entry))
                return tuple(out)
        msg = "referential list requires items, data or results array"
        raise AlteredMappingError(msg, path=path)
