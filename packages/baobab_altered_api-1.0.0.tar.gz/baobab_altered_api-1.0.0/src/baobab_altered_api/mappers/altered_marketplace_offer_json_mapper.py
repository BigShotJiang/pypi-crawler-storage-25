"""Mapping JSON offres marketplace (lecture seule)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from baobab_altered_api.exceptions.altered_mapping_error import AlteredMappingError
from baobab_altered_api.mappers.altered_common_models_json_mapper import (
    AlteredCommonModelsJsonMapper,
)
from baobab_altered_api.models.altered_marketplace_offer import AlteredMarketplaceOffer
from baobab_altered_api.models.altered_ref import AlteredRef


class AlteredMarketplaceOfferJsonMapper:
    """Mappe une offre marketplace sans données personnelles obligatoires."""

    @staticmethod
    def offer_from_mapping(
        data: Mapping[str, Any],
        *,
        path: str | None = None,
    ) -> AlteredMarketplaceOffer:
        """Construit une offre depuis un objet JSON."""
        ref_val = data.get("id") or data.get("offerId")
        if ref_val is None:
            msg = "marketplace offer requires id or offerId"
            raise AlteredMappingError(msg, path=path)
        ref = AlteredCommonModelsJsonMapper.ref_from_json(ref_val, field="offer_ref")
        card_ref: AlteredRef | None = None
        cid = data.get("cardId") or data.get("card_id")
        if cid is not None:
            card_ref = AlteredCommonModelsJsonMapper.ref_from_json(cid, field="cardId")
        amount: int | None = None
        currency: str | None = None
        price = data.get("price")
        if isinstance(price, Mapping):
            raw_amt = price.get("amount")
            if isinstance(raw_amt, int) and not isinstance(raw_amt, bool):
                amount = raw_amt
            cur = price.get("currency")
            if isinstance(cur, str) and cur.strip():
                currency = cur.strip()
        seller = data.get("sellerLabel") or data.get("seller")
        seller_label = (
            seller.strip() if isinstance(seller, str) and seller.strip() else None
        )
        consumed = frozenset(
            {"id", "offerId", "cardId", "card_id", "price", "sellerLabel", "seller"}
        )
        raw = {k: v for k, v in data.items() if k not in consumed} or None
        return AlteredMarketplaceOffer(
            ref=ref,
            card_ref=card_ref,
            price_amount=amount,
            price_currency=currency,
            seller_label=seller_label,
            raw=raw,
        )
