"""
Unit Converter
===============
Length, weight, temperature, time, area, volume, speed, data, pressure, energy.
"""

from typing import Union

Number = Union[int, float]


class UnitConverter:
    """
    Bi-directional unit conversions across common measurement categories.

    All methods return a float.
    """

    # ═══════════════════════════════════════════════════════════════════════════
    # LENGTH
    # ═══════════════════════════════════════════════════════════════════════════

    # Base unit: metre
    _LENGTH_TO_METRES = {
        "m": 1.0,
        "km": 1_000.0,
        "cm": 0.01,
        "mm": 0.001,
        "um": 1e-6,       # micrometre
        "nm": 1e-9,       # nanometre
        "ft": 0.3048,
        "in": 0.0254,
        "yd": 0.9144,
        "mi": 1_609.344,
        "nmi": 1_852.0,   # nautical mile
        "ly": 9.460730472580800e15,  # light-year
        "au": 1.495978707e11,        # astronomical unit
    }

    def convert_length(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert length between any supported units.

        Units: m, km, cm, mm, um, nm, ft, in, yd, mi, nmi, ly, au
        """
        return self._convert(value, from_unit, to_unit, self._LENGTH_TO_METRES)

    # Shortcuts
    def m_to_ft(self, m: Number) -> float: return m / 0.3048
    def ft_to_m(self, ft: Number) -> float: return ft * 0.3048
    def km_to_mi(self, km: Number) -> float: return km / 1.609344
    def mi_to_km(self, mi: Number) -> float: return mi * 1.609344
    def cm_to_in(self, cm: Number) -> float: return cm / 2.54
    def in_to_cm(self, inches: Number) -> float: return inches * 2.54

    # ═══════════════════════════════════════════════════════════════════════════
    # WEIGHT / MASS
    # ═══════════════════════════════════════════════════════════════════════════

    _MASS_TO_KG = {
        "kg": 1.0,
        "g": 0.001,
        "mg": 1e-6,
        "t": 1_000.0,       # metric tonne
        "lb": 0.45359237,
        "oz": 0.028349523125,
        "st": 6.35029318,    # stone (UK)
        "ct": 0.0002,        # carat
    }

    def convert_mass(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert mass/weight. Units: kg, g, mg, t, lb, oz, st, ct"""
        return self._convert(value, from_unit, to_unit, self._MASS_TO_KG)

    def kg_to_lb(self, kg: Number) -> float: return kg / 0.45359237
    def lb_to_kg(self, lb: Number) -> float: return lb * 0.45359237
    def g_to_oz(self, g: Number) -> float: return g / 28.349523125
    def oz_to_g(self, oz: Number) -> float: return oz * 28.349523125

    # ═══════════════════════════════════════════════════════════════════════════
    # TEMPERATURE
    # ═══════════════════════════════════════════════════════════════════════════

    def celsius_to_fahrenheit(self, c: Number) -> float:
        """Convert Celsius to Fahrenheit."""
        return c * 9 / 5 + 32

    def fahrenheit_to_celsius(self, f: Number) -> float:
        """Convert Fahrenheit to Celsius."""
        return (f - 32) * 5 / 9

    def celsius_to_kelvin(self, c: Number) -> float:
        """Convert Celsius to Kelvin."""
        return c + 273.15

    def kelvin_to_celsius(self, k: Number) -> float:
        """Convert Kelvin to Celsius."""
        if k < 0:
            raise ValueError("Kelvin cannot be negative.")
        return k - 273.15

    def fahrenheit_to_kelvin(self, f: Number) -> float:
        return self.celsius_to_kelvin(self.fahrenheit_to_celsius(f))

    def kelvin_to_fahrenheit(self, k: Number) -> float:
        return self.celsius_to_fahrenheit(self.kelvin_to_celsius(k))

    def convert_temperature(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert temperature. Units: C, F, K (case-insensitive)."""
        f, t = from_unit.upper(), to_unit.upper()
        conversions = {
            ("C", "F"): self.celsius_to_fahrenheit,
            ("F", "C"): self.fahrenheit_to_celsius,
            ("C", "K"): self.celsius_to_kelvin,
            ("K", "C"): self.kelvin_to_celsius,
            ("F", "K"): self.fahrenheit_to_kelvin,
            ("K", "F"): self.kelvin_to_fahrenheit,
        }
        if f == t:
            return float(value)
        fn = conversions.get((f, t))
        if fn is None:
            raise ValueError(f"Unknown temperature units: {from_unit}, {to_unit}")
        return fn(value)

    # ═══════════════════════════════════════════════════════════════════════════
    # TIME
    # ═══════════════════════════════════════════════════════════════════════════

    _TIME_TO_SECONDS = {
        "s": 1.0,
        "ms": 0.001,
        "us": 1e-6,
        "min": 60.0,
        "h": 3_600.0,
        "d": 86_400.0,
        "wk": 604_800.0,
        "mo": 2_628_000.0,   # average month (365.25/12 days)
        "yr": 31_557_600.0,  # Julian year
    }

    def convert_time(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert time. Units: s, ms, us, min, h, d, wk, mo, yr"""
        return self._convert(value, from_unit, to_unit, self._TIME_TO_SECONDS)

    def seconds_to_hms(self, seconds: Number) -> str:
        """Convert total seconds to HH:MM:SS string."""
        seconds = int(seconds)
        h = seconds // 3600
        m = (seconds % 3600) // 60
        s = seconds % 60
        return f"{h:02d}:{m:02d}:{s:02d}"

    def hms_to_seconds(self, h: int, m: int, s: int) -> int:
        """Convert hours, minutes, seconds to total seconds."""
        return h * 3600 + m * 60 + s

    # ═══════════════════════════════════════════════════════════════════════════
    # AREA
    # ═══════════════════════════════════════════════════════════════════════════

    _AREA_TO_M2 = {
        "m2": 1.0,
        "km2": 1e6,
        "cm2": 1e-4,
        "mm2": 1e-6,
        "ft2": 0.09290304,
        "in2": 6.4516e-4,
        "yd2": 0.83612736,
        "mi2": 2_589_988.110336,
        "ac": 4_046.8564224,   # acre
        "ha": 10_000.0,        # hectare
    }

    def convert_area(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert area. Units: m2, km2, cm2, mm2, ft2, in2, yd2, mi2, ac, ha"""
        return self._convert(value, from_unit, to_unit, self._AREA_TO_M2)

    # ═══════════════════════════════════════════════════════════════════════════
    # VOLUME
    # ═══════════════════════════════════════════════════════════════════════════

    _VOLUME_TO_L = {
        "l": 1.0,
        "ml": 0.001,
        "m3": 1_000.0,
        "cm3": 0.001,
        "ft3": 28.316846592,
        "in3": 0.016387064,
        "gal_us": 3.785411784,
        "gal_uk": 4.54609,
        "qt": 0.946352946,
        "pt": 0.473176473,
        "fl_oz_us": 0.0295735296,
        "tsp": 0.00492892159,
        "tbsp": 0.0147867648,
        "cup": 0.24,
    }

    def convert_volume(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert volume. Units: l, ml, m3, cm3, ft3, in3, gal_us, gal_uk, qt, pt, fl_oz_us, tsp, tbsp, cup"""
        return self._convert(value, from_unit, to_unit, self._VOLUME_TO_L)

    # ═══════════════════════════════════════════════════════════════════════════
    # SPEED
    # ═══════════════════════════════════════════════════════════════════════════

    _SPEED_TO_MS = {
        "m/s": 1.0,
        "km/h": 1 / 3.6,
        "mph": 0.44704,
        "ft/s": 0.3048,
        "knot": 0.514444,
        "mach": 343.0,  # at sea level, 20°C
        "c": 299_792_458.0,  # speed of light
    }

    def convert_speed(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert speed. Units: m/s, km/h, mph, ft/s, knot, mach, c"""
        return self._convert(value, from_unit, to_unit, self._SPEED_TO_MS)

    # ═══════════════════════════════════════════════════════════════════════════
    # DIGITAL DATA
    # ═══════════════════════════════════════════════════════════════════════════

    _DATA_TO_BITS = {
        "bit": 1,
        "byte": 8,
        "kb": 1_000,
        "kib": 1_024,
        "mb": 1_000_000,
        "mib": 1_048_576,
        "gb": 1_000_000_000,
        "gib": 1_073_741_824,
        "tb": 1_000_000_000_000,
        "tib": 1_099_511_627_776,
        "pb": 1_000_000_000_000_000,
    }

    def convert_data(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert digital data. Units: bit, byte, kb, kib, mb, mib, gb, gib, tb, tib, pb"""
        f = from_unit.lower()
        t = to_unit.lower()
        if f not in self._DATA_TO_BITS:
            raise ValueError(f"Unknown data unit: {from_unit}")
        if t not in self._DATA_TO_BITS:
            raise ValueError(f"Unknown data unit: {to_unit}")
        return value * self._DATA_TO_BITS[f] / self._DATA_TO_BITS[t]

    # ═══════════════════════════════════════════════════════════════════════════
    # PRESSURE
    # ═══════════════════════════════════════════════════════════════════════════

    _PRESSURE_TO_PA = {
        "pa": 1.0,
        "kpa": 1_000.0,
        "mpa": 1_000_000.0,
        "bar": 100_000.0,
        "atm": 101_325.0,
        "psi": 6_894.757293168,
        "mmhg": 133.322387415,
        "torr": 133.322387415,
    }

    def convert_pressure(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert pressure. Units: pa, kpa, mpa, bar, atm, psi, mmhg, torr"""
        return self._convert(value, from_unit.lower(), to_unit.lower(), self._PRESSURE_TO_PA)

    # ═══════════════════════════════════════════════════════════════════════════
    # ENERGY
    # ═══════════════════════════════════════════════════════════════════════════

    _ENERGY_TO_J = {
        "j": 1.0,
        "kj": 1_000.0,
        "mj": 1_000_000.0,
        "cal": 4.184,
        "kcal": 4_184.0,
        "wh": 3_600.0,
        "kwh": 3_600_000.0,
        "ev": 1.602176634e-19,
        "btu": 1_055.05585262,
        "ft_lb": 1.3558179483314,
    }

    def convert_energy(self, value: Number, from_unit: str, to_unit: str) -> float:
        """Convert energy. Units: j, kj, mj, cal, kcal, wh, kwh, ev, btu, ft_lb"""
        return self._convert(value, from_unit.lower(), to_unit.lower(), self._ENERGY_TO_J)

    # ═══════════════════════════════════════════════════════════════════════════
    # Generic helper
    # ═══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _convert(value: Number, from_unit: str, to_unit: str, table: dict) -> float:
        if from_unit not in table:
            raise ValueError(f"Unknown unit: '{from_unit}'. Available: {sorted(table)}")
        if to_unit not in table:
            raise ValueError(f"Unknown unit: '{to_unit}'. Available: {sorted(table)}")
        return value * table[from_unit] / table[to_unit]
