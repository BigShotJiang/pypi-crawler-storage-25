"""
Algebra Calculator
===================
Quadratic solver, linear systems, polynomial evaluation,
expression parsing (via sympy when available), and more.
"""

import math
from typing import List, Tuple, Optional, Dict, Union

Number = Union[int, float]


class AlgebraCalculator:
    """
    Algebraic calculations: equation solving, polynomials, linear systems.

    Uses sympy when available for symbolic computation; otherwise falls back
    to numerical methods.
    """

    # ── Quadratic Equation  ax² + bx + c = 0 ─────────────────────────────────
    def solve_quadratic(
        self, a: Number, b: Number, c: Number
    ) -> Dict[str, object]:
        """Solve ax² + bx + c = 0.

        Returns:
            dict with keys:
                'discriminant' – Δ = b²-4ac
                'roots'        – tuple of solutions (real or complex)
                'nature'       – 'two real roots' | 'one real root' | 'complex roots'

        Example:
            >>> alg.solve_quadratic(1, -5, 6)
            {'discriminant': 1, 'roots': (3.0, 2.0), 'nature': 'two real roots'}
        """
        if a == 0:
            # Degenerate: bx + c = 0
            if b == 0:
                return {"discriminant": None, "roots": (), "nature": "no solution" if c != 0 else "infinite solutions"}
            root = -c / b
            return {"discriminant": None, "roots": (root,), "nature": "linear equation"}

        disc = b ** 2 - 4 * a * c
        if disc > 0:
            r1 = (-b + math.sqrt(disc)) / (2 * a)
            r2 = (-b - math.sqrt(disc)) / (2 * a)
            return {"discriminant": disc, "roots": (r1, r2), "nature": "two real roots"}
        elif disc == 0:
            r = -b / (2 * a)
            return {"discriminant": disc, "roots": (r,), "nature": "one real root (repeated)"}
        else:
            real = -b / (2 * a)
            imag = math.sqrt(-disc) / (2 * a)
            return {
                "discriminant": disc,
                "roots": (complex(real, imag), complex(real, -imag)),
                "nature": "complex conjugate roots",
            }

    # ── Linear Equation  ax + b = 0 ──────────────────────────────────────────
    def solve_linear(self, a: Number, b: Number) -> Optional[float]:
        """Solve ax + b = 0. Returns x, or None if no unique solution."""
        if a == 0:
            return None
        return -b / a

    # ── 2×2 Linear System  a1x + b1y = c1,  a2x + b2y = c2 ──────────────────
    def solve_2x2(
        self,
        a1: Number, b1: Number, c1: Number,
        a2: Number, b2: Number, c2: Number,
    ) -> Optional[Tuple[float, float]]:
        """Solve a 2×2 linear system using Cramer's rule.

        Returns:
            (x, y) or None if system has no unique solution.

        Example:
            >>> alg.solve_2x2(2, 1, 5,  1, -1, 1)
            (2.0, 1.0)
        """
        det = a1 * b2 - a2 * b1
        if det == 0:
            return None
        x = (c1 * b2 - c2 * b1) / det
        y = (a1 * c2 - a2 * c1) / det
        return (x, y)

    # ── 3×3 Linear System via Gaussian Elimination ────────────────────────────
    def solve_3x3(
        self,
        coeffs: List[List[Number]],
        rhs: List[Number],
    ) -> Optional[Tuple[float, ...]]:
        """Solve a 3×3 linear system Ax = b via Gaussian elimination.

        Args:
            coeffs: 3×3 coefficient matrix [[a11,a12,a13], ...]
            rhs:    right-hand side [b1, b2, b3]

        Returns:
            Tuple (x1, x2, x3) or None if singular.

        Example:
            >>> coeffs = [[2,1,-1],[−3,−1,2],[−2,1,2]]
            >>> rhs    = [8,-11,-3]
            >>> alg.solve_3x3(coeffs, rhs)
            (2.0, 3.0, -1.0)
        """
        n = 3
        # Build augmented matrix
        mat = [row[:] + [rhs[i]] for i, row in enumerate(coeffs)]

        for col in range(n):
            # Partial pivoting
            max_row = max(range(col, n), key=lambda r: abs(mat[r][col]))
            mat[col], mat[max_row] = mat[max_row], mat[col]
            if mat[col][col] == 0:
                return None  # Singular
            for row in range(col + 1, n):
                factor = mat[row][col] / mat[col][col]
                for j in range(col, n + 1):
                    mat[row][j] -= factor * mat[col][j]

        # Back substitution
        x = [0.0] * n
        for i in range(n - 1, -1, -1):
            x[i] = mat[i][n] / mat[i][i]
            for j in range(i + 1, n):
                x[i] -= mat[i][j] * x[j] / mat[i][i]

        return tuple(x)

    # ── Polynomial ────────────────────────────────────────────────────────────
    def poly_evaluate(self, coeffs: List[Number], x: Number) -> Number:
        """Evaluate polynomial at x using Horner's method.

        Args:
            coeffs: list of coefficients [a_n, a_{n-1}, ..., a_1, a_0]
                    (highest degree first)

        Example:
            >>> alg.poly_evaluate([1, -6, 11, -6], 3)  # x³ - 6x² + 11x - 6
            0
        """
        result = 0
        for coef in coeffs:
            result = result * x + coef
        return result

    def poly_roots_numerical(
        self, coeffs: List[Number], iterations: int = 1000
    ) -> List[float]:
        """Numerically find real roots of a polynomial (bisection on a grid).

        Note:
            This is an approximate method. For exact symbolic roots use sympy directly.

        Args:
            coeffs: [a_n, ..., a_0] highest degree first.

        Returns:
            List of approximate real roots.
        """
        f = lambda x: self.poly_evaluate(coeffs, x)
        roots = []
        search_range = 1000
        step = 0.001
        x = -search_range
        prev_fx = f(x)
        while x <= search_range:
            x += step
            fx = f(x)
            if prev_fx * fx < 0:
                # Root bracketed – refine with bisection
                lo, hi = x - step, x
                for _ in range(50):
                    mid = (lo + hi) / 2
                    if f(mid) == 0:
                        break
                    if f(lo) * f(mid) < 0:
                        hi = mid
                    else:
                        lo = mid
                root = (lo + hi) / 2
                # Deduplicate
                if not roots or abs(root - roots[-1]) > 1e-5:
                    roots.append(round(root, 8))
            prev_fx = fx
        return roots

    def poly_derivative(self, coeffs: List[Number]) -> List[Number]:
        """Return coefficients of the derivative polynomial.

        Example:
            >>> alg.poly_derivative([3, 2, 1])  # 3x² + 2x + 1 → 6x + 2
            [6, 2]
        """
        n = len(coeffs)
        if n <= 1:
            return [0]
        return [(n - 1 - i) * c for i, c in enumerate(coeffs[:-1])]

    def poly_integral(
        self, coeffs: List[Number], constant: Number = 0
    ) -> List[Number]:
        """Return coefficients of the indefinite integral (antiderivative).

        Args:
            coeffs:   [a_n, ..., a_0] highest degree first.
            constant: integration constant C (appended as constant term).
        """
        n = len(coeffs)
        result = [c / (n - i) for i, c in enumerate(coeffs)]
        result.append(constant)
        return result

    # ── Expression Evaluation (safe) ──────────────────────────────────────────
    def evaluate_expression(self, expr: str, variables: Optional[Dict[str, Number]] = None) -> float:
        """Safely evaluate a mathematical expression string.

        Args:
            expr:      e.g. "2**3 + sqrt(16)"  or  "x**2 + 3*x + 1"
            variables: mapping of variable names to values, e.g. {'x': 5}

        Example:
            >>> alg.evaluate_expression("x**2 + 3*x + 1", {'x': 5})
            41
        """
        import math as _math
        safe_globals = {
            "__builtins__": {},
            "abs": abs, "round": round,
            **{k: v for k, v in vars(_math).items() if not k.startswith("_")},
        }
        safe_locals = variables or {}
        try:
            return float(eval(compile(expr, "<expr>", "eval"), safe_globals, safe_locals))
        except Exception as exc:
            raise ValueError(f"Could not evaluate expression '{expr}': {exc}") from exc
