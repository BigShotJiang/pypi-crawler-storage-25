"""
UkeshUkesh UltraCalc - A comprehensive Python calculator library
======================================================
Supports: Basic Arithmetic, Scientific, Statistical, Algebraic,
Unit Conversion, Programmer, Financial calculations and more.
"""

from .basic import BasicCalculator
from .scientific import ScientificCalculator
from .statistics import StatisticsCalculator
from .algebra import AlgebraCalculator
from .converter import UnitConverter
from .programmer import ProgrammerCalculator
from .financial import FinancialCalculator
from .matrix import MatrixCalculator
from .complex_calc import ComplexCalculator

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your@email.com"
__all__ = [
    "BasicCalculator",
    "ScientificCalculator",
    "StatisticsCalculator",
    "AlgebraCalculator",
    "UnitConverter",
    "ProgrammerCalculator",
    "FinancialCalculator",
    "MatrixCalculator",
    "ComplexCalculator",
]
