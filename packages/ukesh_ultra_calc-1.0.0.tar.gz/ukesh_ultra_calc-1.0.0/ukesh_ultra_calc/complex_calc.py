"""
Complex Number Calculator
==========================
Arithmetic, polar/rectangular conversion, powers, roots, trig functions
for complex numbers using Python's built-in complex type.
"""

import cmath
import math
from typing import Tuple, Union

Number = Union[int, float, complex]


class ComplexCalculator:
    """
    Operations on complex numbers.

    All inputs can be real numbers (int/float) or Python complex numbers.
    Results are returned as Python complex unless stated otherwise.
    """

    # ── Construction ──────────────────────────────────────────────────────────

    @staticmethod
    def make(real: float, imag: float = 0.0) -> complex:
        """Create a complex number from rectangular form."""
        return complex(real, imag)

    @staticmethod
    def from_polar(r: float, theta: float) -> complex:
        """Create a complex number from polar form (r, θ) where θ is in radians."""
        return cmath.rect(r, theta)

    @staticmethod
    def from_polar_deg(r: float, theta_deg: float) -> complex:
        """Create a complex number from polar form where θ is in degrees."""
        return cmath.rect(r, math.radians(theta_deg))

    # ── Properties ────────────────────────────────────────────────────────────

    @staticmethod
    def real(z: complex) -> float:
        """Return the real part of z."""
        return z.real

    @staticmethod
    def imag(z: complex) -> float:
        """Return the imaginary part of z."""
        return z.imag

    @staticmethod
    def modulus(z: complex) -> float:
        """Return |z| (absolute value / modulus)."""
        return abs(z)

    @staticmethod
    def argument(z: complex) -> float:
        """Return arg(z) in radians (principal value in (-π, π])."""
        return cmath.phase(z)

    def argument_deg(self, z: complex) -> float:
        """Return arg(z) in degrees."""
        return math.degrees(self.argument(z))

    @staticmethod
    def conjugate(z: complex) -> complex:
        """Return the complex conjugate z̄."""
        return z.conjugate()

    def to_polar(self, z: complex) -> Tuple[float, float]:
        """Return (r, θ) with θ in radians."""
        return abs(z), self.argument(z)

    def to_polar_deg(self, z: complex) -> Tuple[float, float]:
        """Return (r, θ_degrees)."""
        r, theta = self.to_polar(z)
        return r, math.degrees(theta)

    # ── Arithmetic ────────────────────────────────────────────────────────────

    @staticmethod
    def add(a: complex, b: complex) -> complex:
        """Return a + b."""
        return a + b

    @staticmethod
    def subtract(a: complex, b: complex) -> complex:
        """Return a - b."""
        return a - b

    @staticmethod
    def multiply(a: complex, b: complex) -> complex:
        """Return a × b."""
        return a * b

    @staticmethod
    def divide(a: complex, b: complex) -> complex:
        """Return a / b.

        Raises:
            ZeroDivisionError: when b is 0.
        """
        if b == 0:
            raise ZeroDivisionError("Complex division by zero.")
        return a / b

    @staticmethod
    def power(z: complex, n: Number) -> complex:
        """Return z^n."""
        return z ** n

    @staticmethod
    def sqrt(z: complex) -> complex:
        """Return the principal square root of z."""
        return cmath.sqrt(z)

    def nth_roots(self, z: complex, n: int) -> list:
        """Return all n-th roots of z as a list of complex numbers."""
        r, theta = self.to_polar(z)
        root_r = r ** (1 / n)
        return [
            cmath.rect(root_r, (theta + 2 * math.pi * k) / n)
            for k in range(n)
        ]

    # ── Transcendental ────────────────────────────────────────────────────────

    @staticmethod
    def exp(z: complex) -> complex:
        """Return e^z."""
        return cmath.exp(z)

    @staticmethod
    def log(z: complex, base: complex = math.e) -> complex:
        """Return log_base(z). Defaults to natural log."""
        return cmath.log(z, base)

    @staticmethod
    def log10(z: complex) -> complex:
        """Return log₁₀(z)."""
        return cmath.log10(z)

    @staticmethod
    def sin(z: complex) -> complex:
        """Return sin(z)."""
        return cmath.sin(z)

    @staticmethod
    def cos(z: complex) -> complex:
        """Return cos(z)."""
        return cmath.cos(z)

    @staticmethod
    def tan(z: complex) -> complex:
        """Return tan(z)."""
        return cmath.tan(z)

    @staticmethod
    def asin(z: complex) -> complex:
        """Return arcsin(z)."""
        return cmath.asin(z)

    @staticmethod
    def acos(z: complex) -> complex:
        """Return arccos(z)."""
        return cmath.acos(z)

    @staticmethod
    def atan(z: complex) -> complex:
        """Return arctan(z)."""
        return cmath.atan(z)

    # ── Formatting ────────────────────────────────────────────────────────────

    @staticmethod
    def to_string(z: complex, decimals: int = 4) -> str:
        """Return a pretty string representation of z."""
        r, i = z.real, z.imag
        if i == 0:
            return f"{r:.{decimals}f}"
        sign = "+" if i >= 0 else "-"
        return f"{r:.{decimals}f} {sign} {abs(i):.{decimals}f}i"

    def to_polar_string(self, z: complex, decimals: int = 4) -> str:
        """Return polar form string: r∠θ°."""
        r, theta = self.to_polar_deg(z)
        return f"{r:.{decimals}f} ∠ {theta:.{decimals}f}°"

    def info(self, z: complex) -> dict:
        """Return a dict with all key properties of z."""
        r, theta = self.to_polar(z)
        return {
            "real": z.real,
            "imag": z.imag,
            "modulus": r,
            "argument_rad": theta,
            "argument_deg": math.degrees(theta),
            "conjugate": z.conjugate(),
            "rectangular": self.to_string(z),
            "polar": self.to_polar_string(z),
        }
