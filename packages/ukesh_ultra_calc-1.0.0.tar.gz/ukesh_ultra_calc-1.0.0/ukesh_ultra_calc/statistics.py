"""
Statistics Calculator
======================
Mean, median, mode, variance, standard deviation,
percentiles, correlation, z-score, and more.
"""

import math
from typing import List, Union, Tuple, Dict, Any
from collections import Counter

Number = Union[int, float]


class StatisticsCalculator:
    """
    Descriptive & inferential statistics without external dependencies.

    All methods accept a list of numbers unless stated otherwise.
    """

    # ── Central Tendency ──────────────────────────────────────────────────────
    def mean(self, data: List[Number]) -> float:
        """Return the arithmetic mean."""
        self._check_data(data)
        return sum(data) / len(data)

    def weighted_mean(self, data: List[Number], weights: List[Number]) -> float:
        """Return the weighted arithmetic mean."""
        if len(data) != len(weights):
            raise ValueError("data and weights must have the same length.")
        total_weight = sum(weights)
        if total_weight == 0:
            raise ValueError("Weights must not all be zero.")
        return sum(v * w for v, w in zip(data, weights)) / total_weight

    def geometric_mean(self, data: List[Number]) -> float:
        """Return the geometric mean (all values must be positive)."""
        self._check_data(data)
        if any(x <= 0 for x in data):
            raise ValueError("Geometric mean requires all positive values.")
        log_sum = sum(math.log(x) for x in data)
        return math.exp(log_sum / len(data))

    def harmonic_mean(self, data: List[Number]) -> float:
        """Return the harmonic mean (all values must be non-zero)."""
        self._check_data(data)
        if any(x == 0 for x in data):
            raise ValueError("Harmonic mean requires all non-zero values.")
        return len(data) / sum(1 / x for x in data)

    def median(self, data: List[Number]) -> float:
        """Return the median (middle value when sorted)."""
        self._check_data(data)
        sorted_data = sorted(data)
        n = len(sorted_data)
        mid = n // 2
        if n % 2 == 0:
            return (sorted_data[mid - 1] + sorted_data[mid]) / 2
        return float(sorted_data[mid])

    def mode(self, data: List[Number]) -> List[Number]:
        """Return the mode(s) — value(s) that appear most frequently."""
        self._check_data(data)
        counts = Counter(data)
        max_count = max(counts.values())
        return sorted(k for k, v in counts.items() if v == max_count)

    def midrange(self, data: List[Number]) -> float:
        """Return (max + min) / 2."""
        self._check_data(data)
        return (max(data) + min(data)) / 2

    # ── Dispersion ────────────────────────────────────────────────────────────
    def variance(self, data: List[Number], population: bool = True) -> float:
        """Return variance.

        Args:
            data: list of numbers
            population: True  → population variance (÷ N)
                        False → sample variance    (÷ N-1)
        """
        self._check_data(data)
        n = len(data)
        if not population and n < 2:
            raise ValueError("Sample variance requires at least 2 data points.")
        mu = self.mean(data)
        divisor = n if population else n - 1
        return sum((x - mu) ** 2 for x in data) / divisor

    def std_dev(self, data: List[Number], population: bool = True) -> float:
        """Return standard deviation (square root of variance)."""
        return math.sqrt(self.variance(data, population))

    def range_(self, data: List[Number]) -> Number:
        """Return max - min."""
        self._check_data(data)
        return max(data) - min(data)

    def iqr(self, data: List[Number]) -> float:
        """Return Interquartile Range (Q3 - Q1)."""
        q1, _, q3 = self.quartiles(data)
        return q3 - q1

    def mad(self, data: List[Number]) -> float:
        """Return Mean Absolute Deviation."""
        self._check_data(data)
        mu = self.mean(data)
        return sum(abs(x - mu) for x in data) / len(data)

    def coefficient_of_variation(self, data: List[Number]) -> float:
        """Return CV = (std_dev / mean) * 100  (as percentage)."""
        mu = self.mean(data)
        if mu == 0:
            raise ValueError("Mean is zero; CV is undefined.")
        return (self.std_dev(data) / mu) * 100

    # ── Percentiles & Quartiles ───────────────────────────────────────────────
    def percentile(self, data: List[Number], p: float) -> float:
        """Return the p-th percentile (0 <= p <= 100).

        Uses linear interpolation (method closest to Excel/numpy).
        """
        self._check_data(data)
        if not 0 <= p <= 100:
            raise ValueError("Percentile p must be between 0 and 100.")
        sorted_data = sorted(data)
        n = len(sorted_data)
        index = (p / 100) * (n - 1)
        lower = int(index)
        upper = lower + 1
        if upper >= n:
            return float(sorted_data[-1])
        frac = index - lower
        return sorted_data[lower] + frac * (sorted_data[upper] - sorted_data[lower])

    def quartiles(self, data: List[Number]) -> Tuple[float, float, float]:
        """Return (Q1, Q2, Q3)."""
        return (
            self.percentile(data, 25),
            self.percentile(data, 50),
            self.percentile(data, 75),
        )

    # ── Shape ─────────────────────────────────────────────────────────────────
    def skewness(self, data: List[Number]) -> float:
        """Return Pearson's moment coefficient of skewness."""
        n = len(data)
        if n < 3:
            raise ValueError("Skewness requires at least 3 data points.")
        mu = self.mean(data)
        sigma = self.std_dev(data)
        if sigma == 0:
            return 0.0
        return (sum((x - mu) ** 3 for x in data) / n) / (sigma ** 3)

    def kurtosis(self, data: List[Number]) -> float:
        """Return excess kurtosis (Fisher's definition; normal distribution = 0)."""
        n = len(data)
        if n < 4:
            raise ValueError("Kurtosis requires at least 4 data points.")
        mu = self.mean(data)
        sigma = self.std_dev(data)
        if sigma == 0:
            return 0.0
        return (sum((x - mu) ** 4 for x in data) / n) / (sigma ** 4) - 3

    # ── Correlation & Regression ──────────────────────────────────────────────
    def z_score(self, value: Number, data: List[Number]) -> float:
        """Return the z-score of *value* relative to *data*."""
        mu = self.mean(data)
        sigma = self.std_dev(data)
        if sigma == 0:
            raise ValueError("Standard deviation is zero; z-score undefined.")
        return (value - mu) / sigma

    def z_scores(self, data: List[Number]) -> List[float]:
        """Return z-scores for every element in *data*."""
        mu = self.mean(data)
        sigma = self.std_dev(data)
        if sigma == 0:
            raise ValueError("Standard deviation is zero; z-scores undefined.")
        return [(x - mu) / sigma for x in data]

    def covariance(self, x: List[Number], y: List[Number]) -> float:
        """Return sample covariance of x and y."""
        if len(x) != len(y):
            raise ValueError("x and y must have the same length.")
        n = len(x)
        if n < 2:
            raise ValueError("Covariance requires at least 2 data points.")
        mean_x, mean_y = self.mean(x), self.mean(y)
        return sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y)) / (n - 1)

    def correlation(self, x: List[Number], y: List[Number]) -> float:
        """Return Pearson correlation coefficient r (-1 to 1)."""
        cov = self.covariance(x, y)
        sx = self.std_dev(x, population=False)
        sy = self.std_dev(y, population=False)
        if sx == 0 or sy == 0:
            raise ValueError("Std dev is zero; correlation undefined.")
        return cov / (sx * sy)

    def linear_regression(
        self, x: List[Number], y: List[Number]
    ) -> Dict[str, float]:
        """Return simple linear regression coefficients.

        Returns:
            dict with keys 'slope', 'intercept', 'r_squared'
        """
        if len(x) != len(y):
            raise ValueError("x and y must have the same length.")
        n = len(x)
        mean_x, mean_y = self.mean(x), self.mean(y)
        ss_xy = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
        ss_xx = sum((xi - mean_x) ** 2 for xi in x)
        if ss_xx == 0:
            raise ValueError("All x values are identical; regression undefined.")
        slope = ss_xy / ss_xx
        intercept = mean_y - slope * mean_x
        y_pred = [slope * xi + intercept for xi in x]
        ss_res = sum((yi - yp) ** 2 for yi, yp in zip(y, y_pred))
        ss_tot = sum((yi - mean_y) ** 2 for yi in y)
        r_squared = 1 - ss_res / ss_tot if ss_tot != 0 else 1.0
        return {"slope": slope, "intercept": intercept, "r_squared": r_squared}

    # ── Summary ───────────────────────────────────────────────────────────────
    def summary(self, data: List[Number]) -> Dict[str, Any]:
        """Return a full descriptive statistics summary dict."""
        q1, q2, q3 = self.quartiles(data)
        return {
            "count": len(data),
            "min": min(data),
            "max": max(data),
            "range": self.range_(data),
            "mean": self.mean(data),
            "median": q2,
            "mode": self.mode(data),
            "variance_pop": self.variance(data, population=True),
            "std_dev_pop": self.std_dev(data, population=True),
            "variance_sample": self.variance(data, population=False) if len(data) > 1 else None,
            "std_dev_sample": self.std_dev(data, population=False) if len(data) > 1 else None,
            "Q1": q1,
            "Q2": q2,
            "Q3": q3,
            "IQR": q3 - q1,
            "skewness": self.skewness(data) if len(data) >= 3 else None,
            "kurtosis": self.kurtosis(data) if len(data) >= 4 else None,
        }

    # ── Internal ──────────────────────────────────────────────────────────────
    @staticmethod
    def _check_data(data: List[Number]) -> None:
        if not data:
            raise ValueError("Data list must not be empty.")
