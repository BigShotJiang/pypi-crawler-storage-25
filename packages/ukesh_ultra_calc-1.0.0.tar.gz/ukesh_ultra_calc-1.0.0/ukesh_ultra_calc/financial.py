"""
Financial Calculator
=====================
Simple & compound interest, EMI, tax, discount,
profit/loss, NPV, IRR, ROI, and break-even analysis.
"""

import math
from typing import List, Optional, Union

Number = Union[int, float]


class FinancialCalculator:
    """
    Business and personal finance calculations.

    All monetary amounts are returned as float.
    Rates are expressed as percentages (e.g. 5.0 means 5 %).
    """

    # ── Simple Interest ───────────────────────────────────────────────────────

    def simple_interest(self, principal: Number, rate: Number, time: Number) -> float:
        """Return Simple Interest = P × R × T / 100.

        Args:
            principal: initial amount
            rate:      annual interest rate (%)
            time:      time in years
        """
        return (principal * rate * time) / 100

    def simple_interest_total(self, principal: Number, rate: Number, time: Number) -> float:
        """Return total amount (principal + simple interest)."""
        return principal + self.simple_interest(principal, rate, time)

    # ── Compound Interest ─────────────────────────────────────────────────────

    def compound_interest(
        self,
        principal: Number,
        rate: Number,
        time: Number,
        n: int = 1,
    ) -> float:
        """Return the compound interest earned.

        Args:
            principal: initial amount
            rate:      annual interest rate (%)
            time:      time in years
            n:         compounding frequency per year
                       (1=annually, 12=monthly, 365=daily, etc.)
        """
        return principal * ((1 + rate / (100 * n)) ** (n * time)) - principal

    def compound_total(
        self,
        principal: Number,
        rate: Number,
        time: Number,
        n: int = 1,
    ) -> float:
        """Return total amount after compound growth."""
        return principal * (1 + rate / (100 * n)) ** (n * time)

    def continuous_compound(self, principal: Number, rate: Number, time: Number) -> float:
        """Return total amount with continuous compounding: P × e^(rt)."""
        return principal * math.exp((rate / 100) * time)

    # ── EMI (Equated Monthly Instalment) ──────────────────────────────────────

    def emi(
        self, principal: Number, annual_rate: Number, months: int
    ) -> float:
        """Calculate the monthly EMI for a loan.

        Formula: EMI = P × r × (1+r)^n / ((1+r)^n - 1)

        Args:
            principal:   loan amount
            annual_rate: annual interest rate (%)
            months:      loan tenure in months
        """
        if annual_rate == 0:
            return principal / months
        r = annual_rate / (12 * 100)
        return principal * r * (1 + r) ** months / ((1 + r) ** months - 1)

    def emi_schedule(
        self, principal: Number, annual_rate: Number, months: int
    ) -> List[dict]:
        """Return a full amortisation schedule.

        Returns:
            List of dicts with keys: month, emi, principal_paid, interest_paid, balance
        """
        emi = self.emi(principal, annual_rate, months)
        r = annual_rate / (12 * 100)
        balance = float(principal)
        schedule = []
        for m in range(1, months + 1):
            interest_paid = balance * r
            principal_paid = emi - interest_paid
            balance -= principal_paid
            schedule.append({
                "month": m,
                "emi": round(emi, 2),
                "principal_paid": round(principal_paid, 2),
                "interest_paid": round(interest_paid, 2),
                "balance": round(max(balance, 0), 2),
            })
        return schedule

    # ── Tax ───────────────────────────────────────────────────────────────────

    def tax_amount(self, amount: Number, tax_rate: Number) -> float:
        """Return the tax payable: amount × tax_rate / 100."""
        return (amount * tax_rate) / 100

    def amount_after_tax(self, amount: Number, tax_rate: Number) -> float:
        """Return amount including tax."""
        return amount + self.tax_amount(amount, tax_rate)

    def amount_before_tax(self, amount_with_tax: Number, tax_rate: Number) -> float:
        """Back-calculate the pre-tax amount from a tax-inclusive price."""
        return amount_with_tax / (1 + tax_rate / 100)

    def effective_tax_rate(self, total_tax: Number, gross_income: Number) -> float:
        """Return the effective tax rate = (total_tax / gross_income) × 100."""
        if gross_income == 0:
            raise ValueError("Gross income cannot be zero.")
        return (total_tax / gross_income) * 100

    # ── Discount ──────────────────────────────────────────────────────────────

    def discount_amount(self, original_price: Number, discount_rate: Number) -> float:
        """Return the monetary discount: price × rate / 100."""
        return (original_price * discount_rate) / 100

    def price_after_discount(self, original_price: Number, discount_rate: Number) -> float:
        """Return the final price after applying a percentage discount."""
        return original_price - self.discount_amount(original_price, discount_rate)

    def discount_rate_from_prices(self, original: Number, discounted: Number) -> float:
        """Calculate the discount percentage from original and sale prices."""
        if original == 0:
            raise ValueError("Original price cannot be zero.")
        return ((original - discounted) / original) * 100

    # ── Profit / Loss ─────────────────────────────────────────────────────────

    def profit_or_loss(self, selling_price: Number, cost_price: Number) -> float:
        """Return profit (positive) or loss (negative)."""
        return selling_price - cost_price

    def profit_percent(self, selling_price: Number, cost_price: Number) -> float:
        """Return profit percentage on cost price."""
        if cost_price == 0:
            raise ValueError("Cost price cannot be zero.")
        return ((selling_price - cost_price) / cost_price) * 100

    def selling_price_from_profit(self, cost_price: Number, profit_percent: Number) -> float:
        """Calculate selling price given cost price and desired profit %."""
        return cost_price * (1 + profit_percent / 100)

    def cost_price_from_profit(self, selling_price: Number, profit_percent: Number) -> float:
        """Calculate cost price given selling price and profit %."""
        return selling_price / (1 + profit_percent / 100)

    def markup(self, cost: Number, markup_percent: Number) -> float:
        """Return selling price after applying a markup percentage."""
        return cost * (1 + markup_percent / 100)

    # ── ROI ───────────────────────────────────────────────────────────────────

    def roi(self, net_profit: Number, cost_of_investment: Number) -> float:
        """Return Return on Investment (%) = net_profit / cost × 100."""
        if cost_of_investment == 0:
            raise ValueError("Cost of investment cannot be zero.")
        return (net_profit / cost_of_investment) * 100

    # ── NPV ───────────────────────────────────────────────────────────────────

    def npv(self, rate: Number, cash_flows: List[Number]) -> float:
        """Return Net Present Value.

        Args:
            rate:        discount rate per period (%)
            cash_flows:  list of cash flows starting at t=0

        Example:
            >>> fin.npv(10, [-1000, 300, 400, 500])
        """
        r = rate / 100
        return sum(cf / (1 + r) ** t for t, cf in enumerate(cash_flows))

    def irr(self, cash_flows: List[Number], guess: float = 0.1, iterations: int = 1000, tol: float = 1e-6) -> float:
        """Estimate Internal Rate of Return using Newton-Raphson.

        Args:
            cash_flows: list starting with initial investment (negative)

        Returns:
            IRR as a percentage.
        """
        r = guess
        for _ in range(iterations):
            npv_val = sum(cf / (1 + r) ** t for t, cf in enumerate(cash_flows))
            d_npv = sum(-t * cf / (1 + r) ** (t + 1) for t, cf in enumerate(cash_flows))
            if d_npv == 0:
                break
            r_new = r - npv_val / d_npv
            if abs(r_new - r) < tol:
                r = r_new
                break
            r = r_new
        return r * 100

    # ── Break-Even ────────────────────────────────────────────────────────────

    def break_even_units(
        self,
        fixed_costs: Number,
        selling_price_per_unit: Number,
        variable_cost_per_unit: Number,
    ) -> float:
        """Return break-even units = Fixed Costs / (Price - Variable Cost)."""
        contribution_margin = selling_price_per_unit - variable_cost_per_unit
        if contribution_margin <= 0:
            raise ValueError("Selling price must exceed variable cost per unit.")
        return fixed_costs / contribution_margin

    def break_even_revenue(
        self,
        fixed_costs: Number,
        selling_price_per_unit: Number,
        variable_cost_per_unit: Number,
    ) -> float:
        """Return break-even revenue."""
        units = self.break_even_units(fixed_costs, selling_price_per_unit, variable_cost_per_unit)
        return units * selling_price_per_unit

    # ── Depreciation ─────────────────────────────────────────────────────────

    def straight_line_depreciation(
        self, cost: Number, salvage: Number, useful_life: int
    ) -> float:
        """Return annual depreciation using straight-line method."""
        return (cost - salvage) / useful_life

    def declining_balance_depreciation(
        self, cost: Number, salvage: Number, useful_life: int, year: int
    ) -> float:
        """Return depreciation for a specific *year* (1-indexed) using declining balance."""
        rate = 1 - (salvage / cost) ** (1 / useful_life)
        book_value = cost * (1 - rate) ** (year - 1)
        return book_value * rate

    # ── Future / Present Value ────────────────────────────────────────────────

    def future_value(
        self, present_value: Number, rate: Number, periods: int
    ) -> float:
        """Return Future Value = PV × (1 + r)^n."""
        return present_value * (1 + rate / 100) ** periods

    def present_value(
        self, future_value: Number, rate: Number, periods: int
    ) -> float:
        """Return Present Value = FV / (1 + r)^n."""
        return future_value / (1 + rate / 100) ** periods

    def cagr(
        self, beginning_value: Number, ending_value: Number, periods: int
    ) -> float:
        """Return Compound Annual Growth Rate (%) over *periods* years."""
        if beginning_value <= 0:
            raise ValueError("Beginning value must be positive.")
        return ((ending_value / beginning_value) ** (1 / periods) - 1) * 100
