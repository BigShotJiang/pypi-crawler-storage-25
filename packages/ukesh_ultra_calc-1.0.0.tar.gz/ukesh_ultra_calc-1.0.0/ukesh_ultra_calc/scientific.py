"""
Scientific Calculator
======================
Trigonometry, hyperbolic, logarithmic, root functions,
constants, angle conversion, factorial, primes, GCD/LCM,
Fibonacci, random numbers, and more.
"""

import math
import random
from typing import List, Union

Number = Union[int, float]


class ScientificCalculator:
    """
    Full scientific calculator powered by Python's math module.

    Constants available as class attributes:
        PI  – π  (3.14159…)
        E   – Euler's number (2.71828…)
        TAU – τ = 2π
        INF – positive infinity
    """

    PI = math.pi
    E = math.e
    TAU = math.tau
    INF = math.inf

    # ── Trigonometric (input in radians) ─────────────────────────────────────
    def sin(self, x: Number) -> float:
        """Return sin(x), x in radians."""
        return math.sin(x)

    def cos(self, x: Number) -> float:
        """Return cos(x), x in radians."""
        return math.cos(x)

    def tan(self, x: Number) -> float:
        """Return tan(x), x in radians."""
        return math.tan(x)

    def asin(self, x: Number) -> float:
        """Return arc-sine of x in radians. |x| must be <= 1."""
        return math.asin(x)

    def acos(self, x: Number) -> float:
        """Return arc-cosine of x in radians. |x| must be <= 1."""
        return math.acos(x)

    def atan(self, x: Number) -> float:
        """Return arc-tangent of x in radians."""
        return math.atan(x)

    def atan2(self, y: Number, x: Number) -> float:
        """Return atan(y/x) in radians, handling all quadrants."""
        return math.atan2(y, x)

    # ── Trigonometric helpers (degrees) ──────────────────────────────────────
    def sin_deg(self, x: Number) -> float:
        """Return sin(x°)."""
        return math.sin(math.radians(x))

    def cos_deg(self, x: Number) -> float:
        """Return cos(x°)."""
        return math.cos(math.radians(x))

    def tan_deg(self, x: Number) -> float:
        """Return tan(x°)."""
        return math.tan(math.radians(x))

    # ── Hyperbolic ────────────────────────────────────────────────────────────
    def sinh(self, x: Number) -> float:
        """Return hyperbolic sine of x."""
        return math.sinh(x)

    def cosh(self, x: Number) -> float:
        """Return hyperbolic cosine of x."""
        return math.cosh(x)

    def tanh(self, x: Number) -> float:
        """Return hyperbolic tangent of x."""
        return math.tanh(x)

    def asinh(self, x: Number) -> float:
        """Return inverse hyperbolic sine of x."""
        return math.asinh(x)

    def acosh(self, x: Number) -> float:
        """Return inverse hyperbolic cosine of x (x >= 1)."""
        return math.acosh(x)

    def atanh(self, x: Number) -> float:
        """Return inverse hyperbolic tangent of x (|x| < 1)."""
        return math.atanh(x)

    # ── Logarithmic ───────────────────────────────────────────────────────────
    def log(self, x: Number, base: Number = math.e) -> float:
        """Return log_base(x). Defaults to natural log."""
        return math.log(x, base)

    def log10(self, x: Number) -> float:
        """Return base-10 logarithm of x."""
        return math.log10(x)

    def log2(self, x: Number) -> float:
        """Return base-2 logarithm of x."""
        return math.log2(x)

    def log1p(self, x: Number) -> float:
        """Return natural log of (1 + x). More accurate for small x."""
        return math.log1p(x)

    def exp(self, x: Number) -> float:
        """Return e^x."""
        return math.exp(x)

    def exp2(self, x: Number) -> float:
        """Return 2^x."""
        return 2 ** x

    # ── Root & Power ──────────────────────────────────────────────────────────
    def sqrt(self, x: Number) -> float:
        """Return square root of x."""
        if x < 0:
            raise ValueError("Square root of negative number is not real.")
        return math.sqrt(x)

    def cbrt(self, x: Number) -> float:
        """Return cube root of x (works for negatives)."""
        return math.copysign(abs(x) ** (1 / 3), x)

    def nth_root(self, x: Number, n: Number) -> float:
        """Return the n-th root of x.

        Example:
            >>> sci.nth_root(27, 3)
            3.0
        """
        if n == 0:
            raise ValueError("Root degree cannot be zero.")
        if x < 0 and n % 2 == 0:
            raise ValueError("Even root of a negative number is not real.")
        return math.copysign(abs(x) ** (1 / n), x)

    def hypot(self, *args: Number) -> float:
        """Return Euclidean norm: sqrt(sum of squares)."""
        return math.hypot(*args)

    # ── Angle Conversion ──────────────────────────────────────────────────────
    def degrees(self, radians: Number) -> float:
        """Convert radians to degrees."""
        return math.degrees(radians)

    def radians(self, degrees: Number) -> float:
        """Convert degrees to radians."""
        return math.radians(degrees)

    # ── Number Theory ─────────────────────────────────────────────────────────
    def factorial(self, n: int) -> int:
        """Return n! (n must be a non-negative integer)."""
        if not isinstance(n, int) or n < 0:
            raise ValueError("Factorial is defined only for non-negative integers.")
        return math.factorial(n)

    def is_prime(self, n: int) -> bool:
        """Return True if n is a prime number."""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        for i in range(3, int(math.sqrt(n)) + 1, 2):
            if n % i == 0:
                return False
        return True

    def primes_up_to(self, limit: int) -> List[int]:
        """Return all primes up to *limit* using the Sieve of Eratosthenes."""
        if limit < 2:
            return []
        sieve = [True] * (limit + 1)
        sieve[0] = sieve[1] = False
        for i in range(2, int(limit ** 0.5) + 1):
            if sieve[i]:
                for j in range(i * i, limit + 1, i):
                    sieve[j] = False
        return [i for i, v in enumerate(sieve) if v]

    def gcd(self, a: int, b: int) -> int:
        """Return Greatest Common Divisor of a and b."""
        return math.gcd(a, b)

    def lcm(self, a: int, b: int) -> int:
        """Return Least Common Multiple of a and b."""
        return abs(a * b) // math.gcd(a, b) if a and b else 0

    def gcd_many(self, *args: int) -> int:
        """Return GCD of multiple integers."""
        from functools import reduce
        return reduce(math.gcd, args)

    def lcm_many(self, *args: int) -> int:
        """Return LCM of multiple integers."""
        from functools import reduce
        return reduce(self.lcm, args)

    # ── Sequences ─────────────────────────────────────────────────────────────
    def fibonacci(self, n: int) -> List[int]:
        """Return the first n Fibonacci numbers.

        Example:
            >>> sci.fibonacci(8)
            [0, 1, 1, 2, 3, 5, 8, 13]
        """
        if n <= 0:
            return []
        if n == 1:
            return [0]
        seq = [0, 1]
        for _ in range(2, n):
            seq.append(seq[-1] + seq[-2])
        return seq

    def fibonacci_n(self, n: int) -> int:
        """Return the n-th Fibonacci number (0-indexed)."""
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        return a

    def power_table(self, base: Number, start: int = 0, end: int = 10) -> dict:
        """Return {exponent: base**exponent} for exponent in range(start, end+1)."""
        return {i: base ** i for i in range(start, end + 1)}

    # ── Random ────────────────────────────────────────────────────────────────
    def random_int(self, low: int, high: int) -> int:
        """Return a random integer in [low, high]."""
        return random.randint(low, high)

    def random_float(self, low: float = 0.0, high: float = 1.0) -> float:
        """Return a random float in [low, high)."""
        return random.uniform(low, high)

    def random_choice(self, seq: list):
        """Return a random element from a non-empty sequence."""
        return random.choice(seq)

    # ── Miscellaneous ─────────────────────────────────────────────────────────
    def clamp(self, value: Number, min_val: Number, max_val: Number) -> Number:
        """Clamp *value* between *min_val* and *max_val*."""
        return max(min_val, min(value, max_val))

    def is_perfect_square(self, n: int) -> bool:
        """Return True if n is a perfect square."""
        if n < 0:
            return False
        root = int(math.isqrt(n))
        return root * root == n

    def is_perfect_cube(self, n: int) -> bool:
        """Return True if n is a perfect cube."""
        cbrt = round(abs(n) ** (1 / 3))
        return cbrt ** 3 == abs(n)

    def digits_sum(self, n: int) -> int:
        """Return the sum of digits of integer n."""
        return sum(int(d) for d in str(abs(n)))
