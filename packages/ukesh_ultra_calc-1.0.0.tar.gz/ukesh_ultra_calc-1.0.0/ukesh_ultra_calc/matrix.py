"""
Matrix Calculator
==================
Pure-Python matrix operations without NumPy.
Supports: creation, addition, subtraction, multiplication,
transpose, determinant, inverse, trace, and more.
"""

from typing import List, Union
import copy

Matrix = List[List[float]]


class MatrixCalculator:
    """
    Pure-Python matrix arithmetic.

    Matrices are represented as List[List[float]] —
    a list of rows, each row being a list of column values.
    """

    # ── Factory Helpers ───────────────────────────────────────────────────────

    @staticmethod
    def zeros(rows: int, cols: int) -> Matrix:
        """Return a rows×cols zero matrix."""
        return [[0.0] * cols for _ in range(rows)]

    @staticmethod
    def identity(n: int) -> Matrix:
        """Return an n×n identity matrix."""
        m = [[0.0] * n for _ in range(n)]
        for i in range(n):
            m[i][i] = 1.0
        return m

    @staticmethod
    def from_flat(data: List[float], rows: int, cols: int) -> Matrix:
        """Build a matrix from a flat list of values (row-major order)."""
        if len(data) != rows * cols:
            raise ValueError("Data length must equal rows × cols.")
        return [[data[i * cols + j] for j in range(cols)] for i in range(rows)]

    # ── Validation ────────────────────────────────────────────────────────────

    @staticmethod
    def shape(m: Matrix):
        """Return (rows, cols) of matrix m."""
        return len(m), len(m[0]) if m else 0

    def _assert_same_shape(self, a: Matrix, b: Matrix):
        if self.shape(a) != self.shape(b):
            raise ValueError(f"Shape mismatch: {self.shape(a)} vs {self.shape(b)}")

    # ── Element-Wise Operations ───────────────────────────────────────────────

    def add(self, a: Matrix, b: Matrix) -> Matrix:
        """Return element-wise a + b."""
        self._assert_same_shape(a, b)
        return [[a[i][j] + b[i][j] for j in range(len(a[i]))] for i in range(len(a))]

    def subtract(self, a: Matrix, b: Matrix) -> Matrix:
        """Return element-wise a - b."""
        self._assert_same_shape(a, b)
        return [[a[i][j] - b[i][j] for j in range(len(a[i]))] for i in range(len(a))]

    def scalar_multiply(self, m: Matrix, scalar: float) -> Matrix:
        """Return m scaled by scalar."""
        return [[v * scalar for v in row] for row in m]

    def element_multiply(self, a: Matrix, b: Matrix) -> Matrix:
        """Return Hadamard (element-wise) product."""
        self._assert_same_shape(a, b)
        return [[a[i][j] * b[i][j] for j in range(len(a[i]))] for i in range(len(a))]

    # ── Matrix Multiplication ─────────────────────────────────────────────────

    def multiply(self, a: Matrix, b: Matrix) -> Matrix:
        """Return the matrix product a @ b.

        Requires cols(a) == rows(b).
        """
        rows_a, cols_a = self.shape(a)
        rows_b, cols_b = self.shape(b)
        if cols_a != rows_b:
            raise ValueError(f"Cannot multiply {rows_a}×{cols_a} by {rows_b}×{cols_b}.")
        result = self.zeros(rows_a, cols_b)
        for i in range(rows_a):
            for j in range(cols_b):
                result[i][j] = sum(a[i][k] * b[k][j] for k in range(cols_a))
        return result

    # ── Transpose ─────────────────────────────────────────────────────────────

    def transpose(self, m: Matrix) -> Matrix:
        """Return the transpose of m."""
        rows, cols = self.shape(m)
        return [[m[i][j] for i in range(rows)] for j in range(cols)]

    # ── Determinant (recursive cofactor expansion) ────────────────────────────

    def determinant(self, m: Matrix) -> float:
        """Return the determinant of a square matrix.

        Uses Bareiss algorithm for numerical stability.
        """
        n, nc = self.shape(m)
        if n != nc:
            raise ValueError("Determinant requires a square matrix.")
        if n == 1:
            return m[0][0]
        if n == 2:
            return m[0][0] * m[1][1] - m[0][1] * m[1][0]
        # Bareiss algorithm (integer-safe, no floating-point drift)
        mat = [row[:] for row in m]  # deep copy
        sign = 1
        for col in range(n - 1):
            # Pivot
            pivot_row = next((r for r in range(col, n) if mat[r][col] != 0), None)
            if pivot_row is None:
                return 0.0
            if pivot_row != col:
                mat[col], mat[pivot_row] = mat[pivot_row], mat[col]
                sign *= -1
            for row in range(col + 1, n):
                for j in range(col + 1, n):
                    mat[row][j] = mat[col][col] * mat[row][j] - mat[row][col] * mat[col][j]
                    if col > 0:
                        mat[row][j] //= mat[col - 1][col - 1] if isinstance(mat[col - 1][col - 1], int) else mat[col - 1][col - 1]
                mat[row][col] = 0
        return sign * mat[n - 1][n - 1]

    def _det_recursive(self, m: Matrix) -> float:
        """Recursive cofactor determinant (used for small matrices)."""
        n = len(m)
        if n == 1:
            return m[0][0]
        if n == 2:
            return m[0][0] * m[1][1] - m[0][1] * m[1][0]
        det = 0
        for j in range(n):
            sub = [row[:j] + row[j + 1:] for row in m[1:]]
            det += ((-1) ** j) * m[0][j] * self._det_recursive(sub)
        return det

    # ── Inverse ───────────────────────────────────────────────────────────────

    def inverse(self, m: Matrix) -> Matrix:
        """Return the inverse of a square matrix using Gauss-Jordan elimination."""
        n, nc = self.shape(m)
        if n != nc:
            raise ValueError("Inverse requires a square matrix.")
        # Augment with identity
        aug = [m[i][:] + [1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
        for col in range(n):
            pivot_row = max(range(col, n), key=lambda r: abs(aug[r][col]))
            if aug[pivot_row][col] == 0:
                raise ValueError("Matrix is singular (non-invertible).")
            aug[col], aug[pivot_row] = aug[pivot_row], aug[col]
            pivot = aug[col][col]
            aug[col] = [v / pivot for v in aug[col]]
            for row in range(n):
                if row != col:
                    factor = aug[row][col]
                    aug[row] = [aug[row][j] - factor * aug[col][j] for j in range(2 * n)]
        return [row[n:] for row in aug]

    # ── Properties ────────────────────────────────────────────────────────────

    def trace(self, m: Matrix) -> float:
        """Return the trace (sum of diagonal elements) of a square matrix."""
        n, nc = self.shape(m)
        if n != nc:
            raise ValueError("Trace requires a square matrix.")
        return sum(m[i][i] for i in range(n))

    def is_symmetric(self, m: Matrix) -> bool:
        """Return True if m equals its transpose."""
        return m == self.transpose(m)

    def rank(self, m: Matrix) -> int:
        """Return the rank of the matrix using row reduction."""
        mat = [row[:] for row in m]
        rows, cols = self.shape(mat)
        r = 0
        for col in range(cols):
            pivot = next((i for i in range(r, rows) if mat[i][col] != 0), None)
            if pivot is None:
                continue
            mat[r], mat[pivot] = mat[pivot], mat[r]
            scale = mat[r][col]
            mat[r] = [v / scale for v in mat[r]]
            for i in range(rows):
                if i != r:
                    factor = mat[i][col]
                    mat[i] = [mat[i][j] - factor * mat[r][j] for j in range(cols)]
            r += 1
        return r

    def power(self, m: Matrix, n: int) -> Matrix:
        """Return m raised to integer power n (n >= 0)."""
        rows, cols = self.shape(m)
        if rows != cols:
            raise ValueError("Matrix power requires a square matrix.")
        if n == 0:
            return self.identity(rows)
        result = self.identity(rows)
        base = [row[:] for row in m]
        while n > 0:
            if n % 2 == 1:
                result = self.multiply(result, base)
            base = self.multiply(base, base)
            n //= 2
        return result

    # ── Display ───────────────────────────────────────────────────────────────

    def to_string(self, m: Matrix, decimals: int = 4) -> str:
        """Return a formatted string representation of the matrix."""
        lines = []
        for row in m:
            formatted = "  ".join(f"{v:>{decimals + 4}.{decimals}f}" for v in row)
            lines.append(f"[ {formatted} ]")
        return "\n".join(lines)
