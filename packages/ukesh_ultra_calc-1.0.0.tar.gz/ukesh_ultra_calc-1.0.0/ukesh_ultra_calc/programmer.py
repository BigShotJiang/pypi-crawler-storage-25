"""
Programmer Calculator
======================
Base conversions (bin/oct/hex/dec), bitwise operations,
bit manipulation utilities.
"""

from typing import Union

Number = Union[int, float]


class ProgrammerCalculator:
    """
    Developer-focused calculations: base conversions and bitwise operations.

    All bitwise methods operate on Python integers (arbitrary precision).
    """

    # ── Base Conversions ──────────────────────────────────────────────────────

    def to_binary(self, n: int, prefix: bool = True) -> str:
        """Convert integer to binary string.

        Args:
            n:      integer to convert
            prefix: include '0b' prefix when True

        Example:
            >>> pc.to_binary(42)
            '0b101010'
            >>> pc.to_binary(42, prefix=False)
            '101010'
        """
        b = bin(n)
        return b if prefix else b[2:] if n >= 0 else "-" + b[3:]

    def to_octal(self, n: int, prefix: bool = True) -> str:
        """Convert integer to octal string."""
        o = oct(n)
        return o if prefix else o[2:] if n >= 0 else "-" + o[3:]

    def to_hexadecimal(self, n: int, prefix: bool = True, upper: bool = True) -> str:
        """Convert integer to hexadecimal string."""
        h = hex(n)
        h = h.upper().replace("0X", "0x") if upper else h
        return h if prefix else h[2:] if n >= 0 else "-" + h[3:]

    def from_binary(self, s: str) -> int:
        """Parse a binary string (with or without '0b' prefix) to int."""
        return int(s, 2)

    def from_octal(self, s: str) -> int:
        """Parse an octal string (with or without '0o' prefix) to int."""
        return int(s, 8)

    def from_hexadecimal(self, s: str) -> int:
        """Parse a hexadecimal string (with or without '0x' prefix) to int."""
        return int(s, 16)

    def to_base(self, n: int, base: int) -> str:
        """Convert integer n to any base (2–36).

        Example:
            >>> pc.to_base(255, 16)
            'FF'
            >>> pc.to_base(10, 2)
            '1010'
        """
        if not 2 <= base <= 36:
            raise ValueError("Base must be between 2 and 36.")
        if n == 0:
            return "0"
        digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        negative = n < 0
        n = abs(n)
        result = []
        while n:
            result.append(digits[n % base])
            n //= base
        if negative:
            result.append("-")
        return "".join(reversed(result))

    def from_base(self, s: str, base: int) -> int:
        """Parse string *s* as integer in given *base* (2–36)."""
        return int(s, base)

    # ── Bitwise Operations ────────────────────────────────────────────────────

    def bitwise_and(self, a: int, b: int) -> int:
        """Return a & b."""
        return a & b

    def bitwise_or(self, a: int, b: int) -> int:
        """Return a | b."""
        return a | b

    def bitwise_xor(self, a: int, b: int) -> int:
        """Return a ^ b."""
        return a ^ b

    def bitwise_not(self, a: int) -> int:
        """Return ~a (bitwise NOT)."""
        return ~a

    def left_shift(self, a: int, n: int) -> int:
        """Return a << n."""
        return a << n

    def right_shift(self, a: int, n: int) -> int:
        """Return a >> n."""
        return a >> n

    def unsigned_right_shift(self, a: int, n: int, bits: int = 32) -> int:
        """Return unsigned (logical) right shift of a by n positions.

        Treats *a* as an unsigned integer of *bits* width.
        """
        mask = (1 << bits) - 1
        return (a & mask) >> n

    # ── Bit Utilities ─────────────────────────────────────────────────────────

    def bit_length(self, n: int) -> int:
        """Return number of bits required to represent abs(n)."""
        return abs(n).bit_length()

    def count_set_bits(self, n: int) -> int:
        """Return number of 1-bits (popcount) in abs(n)."""
        return bin(abs(n)).count("1")

    def count_zero_bits(self, n: int, width: int = 0) -> int:
        """Return number of 0-bits in the binary representation of abs(n).

        Args:
            width: pad to this width before counting (0 = natural width)
        """
        b = bin(abs(n))[2:]
        if width:
            b = b.zfill(width)
        return b.count("0")

    def get_bit(self, n: int, position: int) -> int:
        """Return the bit at *position* (0-indexed from LSB) in *n*."""
        return (n >> position) & 1

    def set_bit(self, n: int, position: int) -> int:
        """Return *n* with bit at *position* set to 1."""
        return n | (1 << position)

    def clear_bit(self, n: int, position: int) -> int:
        """Return *n* with bit at *position* cleared to 0."""
        return n & ~(1 << position)

    def toggle_bit(self, n: int, position: int) -> int:
        """Return *n* with bit at *position* toggled."""
        return n ^ (1 << position)

    def is_power_of_two(self, n: int) -> bool:
        """Return True if n is a positive power of two."""
        return n > 0 and (n & (n - 1)) == 0

    def next_power_of_two(self, n: int) -> int:
        """Return the smallest power of two >= n."""
        if n <= 0:
            return 1
        p = 1
        while p < n:
            p <<= 1
        return p

    def reverse_bits(self, n: int, width: int = 8) -> int:
        """Return *n* with its bits reversed over a *width*-bit window."""
        result = 0
        for _ in range(width):
            result = (result << 1) | (n & 1)
            n >>= 1
        return result

    def parity(self, n: int) -> int:
        """Return 0 (even parity) or 1 (odd parity) for abs(n)."""
        return self.count_set_bits(n) % 2

    def twos_complement(self, n: int, bits: int = 8) -> int:
        """Return 2's complement representation of *n* in *bits* bits."""
        if n >= 0:
            return n & ((1 << bits) - 1)
        return (1 << bits) + n

    # ── Summarise ─────────────────────────────────────────────────────────────

    def show_all_bases(self, n: int) -> dict:
        """Return a dict showing *n* in binary, octal, decimal, hex.

        Example:
            >>> pc.show_all_bases(255)
            {'decimal': 255, 'binary': '0b11111111', 'octal': '0o377', 'hex': '0xFF'}
        """
        return {
            "decimal": n,
            "binary": self.to_binary(n),
            "octal": self.to_octal(n),
            "hex": self.to_hexadecimal(n),
        }
