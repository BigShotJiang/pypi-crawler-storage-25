"""
UkeshUkesh UltraCalc CLI
=============
A simple interactive command-line calculator.

Usage:
    python -m ukesh_ultra_calc
    ukesh_ultra_calc           # if installed via pip
"""

import sys
import math
from ukesh_ultra_calc import (
    BasicCalculator,
    ScientificCalculator,
    StatisticsCalculator,
    AlgebraCalculator,
    UnitConverter,
    ProgrammerCalculator,
    FinancialCalculator,
)


BANNER = r"""
╔══════════════════════════════════════════════════════╗
║          U L T R A C A L C  v1.0.0                   ║
║   The comprehensive Python calculator library        ║
╚══════════════════════════════════════════════════════╝
Type 'help' for available commands, 'quit' to exit.
"""

HELP = """
Available commands
──────────────────
  <expression>          Evaluate any Python math expression
                        Examples:  2**10 + sqrt(16)
                                   sin(pi/2)
                                   factorial(10)

  stats <n1> <n2> ...   Descriptive statistics for a list of numbers
  quad <a> <b> <c>      Solve quadratic ax² + bx + c = 0
  emi <P> <rate> <n>    Monthly EMI (principal, annual rate %, months)
  bin <n>               Show number in all bases (bin/oct/dec/hex)
  convert               Launch unit converter wizard
  help                  Show this help
  quit / exit           Exit UkeshUkesh UltraCalc
"""

_sci = ScientificCalculator()
_SAFE_GLOBALS = {
    "__builtins__": {},
    "abs": abs, "round": round, "min": min, "max": max, "sum": sum,
    **{k: v for k, v in vars(math).items() if not k.startswith("_")},
    "factorial": _sci.factorial,
    "gcd": _sci.gcd,
    "lcm": _sci.lcm,
    "fibonacci": _sci.fibonacci,
    "is_prime": _sci.is_prime,
}


def _eval_expr(expr: str) -> str:
    try:
        result = eval(compile(expr, "<input>", "eval"), _SAFE_GLOBALS, {})
        return str(result)
    except Exception as e:
        return f"Error: {e}"


def _cmd_stats(args):
    try:
        nums = list(map(float, args))
    except ValueError:
        return "Usage: stats <n1> <n2> <n3> ..."
    s = StatisticsCalculator()
    summary = s.summary(nums)
    lines = [f"  {k:<18} {v}" for k, v in summary.items()]
    return "Statistics:\n" + "\n".join(lines)


def _cmd_quad(args):
    if len(args) != 3:
        return "Usage: quad <a> <b> <c>"
    try:
        a, b, c = map(float, args)
    except ValueError:
        return "a, b, c must be numbers."
    result = AlgebraCalculator().solve_quadratic(a, b, c)
    return (
        f"  Discriminant : {result['discriminant']}\n"
        f"  Nature       : {result['nature']}\n"
        f"  Roots        : {result['roots']}"
    )


def _cmd_emi(args):
    if len(args) != 3:
        return "Usage: emi <principal> <annual_rate_%> <months>"
    try:
        p, r, n = float(args[0]), float(args[1]), int(args[2])
    except ValueError:
        return "Invalid arguments."
    emi = FinancialCalculator().emi(p, r, n)
    total = emi * n
    return (
        f"  Monthly EMI  : {emi:,.2f}\n"
        f"  Total paid   : {total:,.2f}\n"
        f"  Total interest: {total - p:,.2f}"
    )


def _cmd_bin(args):
    if len(args) != 1:
        return "Usage: bin <integer>"
    try:
        n = int(args[0], 0)
    except ValueError:
        return "Argument must be an integer (dec/0x.../0b.../0o...)"
    d = ProgrammerCalculator().show_all_bases(n)
    return "\n".join(f"  {k:<10} {v}" for k, v in d.items())


def main():
    print(BANNER)
    while True:
        try:
            line = input("ukesh_ultra_calc> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            sys.exit(0)

        if not line:
            continue
        if line.lower() in ("quit", "exit", "q"):
            print("Bye!")
            sys.exit(0)
        if line.lower() == "help":
            print(HELP)
            continue

        parts = line.split()
        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == "stats":
            print(_cmd_stats(args))
        elif cmd == "quad":
            print(_cmd_quad(args))
        elif cmd == "emi":
            print(_cmd_emi(args))
        elif cmd == "bin":
            print(_cmd_bin(args))
        else:
            print(" =", _eval_expr(line))


if __name__ == "__main__":
    main()
