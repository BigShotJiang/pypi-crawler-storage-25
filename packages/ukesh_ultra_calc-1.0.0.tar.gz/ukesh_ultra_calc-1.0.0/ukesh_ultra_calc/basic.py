"""
Basic Arithmetic Calculator
============================
Core arithmetic operations: +, -, *, /, %, **, //, percentage
"""

from typing import Union

Number = Union[int, float]


class BasicCalculator:
    """
    Provides all fundamental arithmetic operations.

    Example:
        >>> calc = BasicCalculator()
        >>> calc.add(5, 3)
        8
        >>> calc.divide(10, 2)
        5.0
        >>> calc.power(2, 4)
        16
    """

    # ── Addition ──────────────────────────────────────────────────────────────
    def add(self, a: Number, b: Number) -> Number:
        """Return a + b."""
        return a + b

    def add_many(self, *args: Number) -> Number:
        """Return the sum of all supplied numbers."""
        return sum(args)

    # ── Subtraction ───────────────────────────────────────────────────────────
    def subtract(self, a: Number, b: Number) -> Number:
        """Return a - b."""
        return a - b

    # ── Multiplication ────────────────────────────────────────────────────────
    def multiply(self, a: Number, b: Number) -> Number:
        """Return a * b."""
        return a * b

    def multiply_many(self, *args: Number) -> Number:
        """Return the product of all supplied numbers."""
        result = 1
        for n in args:
            result *= n
        return result

    # ── Division ──────────────────────────────────────────────────────────────
    def divide(self, a: Number, b: Number) -> float:
        """Return a / b (true division).

        Raises:
            ZeroDivisionError: when b is 0.
        """
        if b == 0:
            raise ZeroDivisionError("Division by zero is undefined.")
        return a / b

    def floor_divide(self, a: Number, b: Number) -> int:
        """Return a // b (floor / integer division).

        Raises:
            ZeroDivisionError: when b is 0.
        """
        if b == 0:
            raise ZeroDivisionError("Floor division by zero is undefined.")
        return a // b

    # ── Modulus ───────────────────────────────────────────────────────────────
    def modulus(self, a: Number, b: Number) -> Number:
        """Return a % b (remainder).

        Raises:
            ZeroDivisionError: when b is 0.
        """
        if b == 0:
            raise ZeroDivisionError("Modulus by zero is undefined.")
        return a % b

    # ── Exponentiation ────────────────────────────────────────────────────────
    def power(self, base: Number, exp: Number) -> Number:
        """Return base ** exp."""
        return base ** exp

    # ── Percentage ────────────────────────────────────────────────────────────
    def percentage(self, value: Number, total: Number) -> float:
        """Return what percentage *value* is of *total*.

        Example:
            >>> calc.percentage(25, 200)
            12.5
        """
        if total == 0:
            raise ZeroDivisionError("Total cannot be zero for percentage calculation.")
        return (value / total) * 100

    def percent_of(self, percent: Number, total: Number) -> float:
        """Return *percent*% of *total*.

        Example:
            >>> calc.percent_of(15, 200)
            30.0
        """
        return (percent / 100) * total

    def percent_change(self, old: Number, new: Number) -> float:
        """Return the percentage change from *old* to *new*.

        Example:
            >>> calc.percent_change(100, 120)
            20.0
        """
        if old == 0:
            raise ZeroDivisionError("Original value cannot be zero.")
        return ((new - old) / old) * 100

    # ── Rounding ──────────────────────────────────────────────────────────────
    def round_number(self, value: Number, decimals: int = 0) -> Number:
        """Round *value* to *decimals* decimal places."""
        return round(value, decimals)

    def ceil(self, value: Number) -> int:
        """Return the ceiling of *value* (smallest integer >= value)."""
        import math
        return math.ceil(value)

    def floor(self, value: Number) -> int:
        """Return the floor of *value* (largest integer <= value)."""
        import math
        return math.floor(value)

    def absolute(self, value: Number) -> Number:
        """Return the absolute value of *value*."""
        return abs(value)

    # ── Convenience ───────────────────────────────────────────────────────────
    def sign(self, value: Number) -> int:
        """Return 1, -1, or 0 indicating the sign of *value*."""
        if value > 0:
            return 1
        if value < 0:
            return -1
        return 0

    def reciprocal(self, value: Number) -> float:
        """Return 1 / value.

        Raises:
            ZeroDivisionError: when value is 0.
        """
        if value == 0:
            raise ZeroDivisionError("Reciprocal of zero is undefined.")
        return 1 / value
