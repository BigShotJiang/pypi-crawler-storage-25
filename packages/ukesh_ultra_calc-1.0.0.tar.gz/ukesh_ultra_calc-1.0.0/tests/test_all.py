"""
UkeshUkesh UltraCalc Test Suite
=====================
Run with: python -m pytest tests/ -v
"""

import math
import pytest
from ukesh_ultra_calc import (
    BasicCalculator,
    ScientificCalculator,
    StatisticsCalculator,
    AlgebraCalculator,
    UnitConverter,
    ProgrammerCalculator,
    FinancialCalculator,
    MatrixCalculator,
    ComplexCalculator,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────
@pytest.fixture
def basic(): return BasicCalculator()
@pytest.fixture
def sci(): return ScientificCalculator()
@pytest.fixture
def stats(): return StatisticsCalculator()
@pytest.fixture
def alg(): return AlgebraCalculator()
@pytest.fixture
def conv(): return UnitConverter()
@pytest.fixture
def prog(): return ProgrammerCalculator()
@pytest.fixture
def fin(): return FinancialCalculator()
@pytest.fixture
def mat(): return MatrixCalculator()
@pytest.fixture
def cx(): return ComplexCalculator()


# ═══════════════════════════════════════════════════════════════════════════════
# BasicCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestBasicCalculator:
    def test_add(self, basic): assert basic.add(3, 4) == 7
    def test_subtract(self, basic): assert basic.subtract(10, 4) == 6
    def test_multiply(self, basic): assert basic.multiply(3, 5) == 15
    def test_divide(self, basic): assert basic.divide(10, 4) == 2.5
    def test_divide_by_zero(self, basic):
        with pytest.raises(ZeroDivisionError): basic.divide(5, 0)
    def test_floor_divide(self, basic): assert basic.floor_divide(10, 3) == 3
    def test_modulus(self, basic): assert basic.modulus(10, 3) == 1
    def test_power(self, basic): assert basic.power(2, 10) == 1024
    def test_percentage(self, basic): assert basic.percentage(25, 200) == 12.5
    def test_percent_of(self, basic): assert basic.percent_of(50, 200) == 100.0
    def test_percent_change(self, basic): assert basic.percent_change(100, 120) == 20.0
    def test_absolute(self, basic): assert basic.absolute(-7) == 7
    def test_ceil(self, basic): assert basic.ceil(3.1) == 4
    def test_floor(self, basic): assert basic.floor(3.9) == 3
    def test_add_many(self, basic): assert basic.add_many(1, 2, 3, 4, 5) == 15
    def test_multiply_many(self, basic): assert basic.multiply_many(2, 3, 4) == 24


# ═══════════════════════════════════════════════════════════════════════════════
# ScientificCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestScientificCalculator:
    def test_sin(self, sci): assert abs(sci.sin(math.pi / 2) - 1.0) < 1e-9
    def test_cos(self, sci): assert abs(sci.cos(0) - 1.0) < 1e-9
    def test_tan(self, sci): assert abs(sci.tan(math.pi / 4) - 1.0) < 1e-9
    def test_sqrt(self, sci): assert sci.sqrt(16) == 4.0
    def test_sqrt_negative(self, sci):
        with pytest.raises(ValueError): sci.sqrt(-1)
    def test_cbrt(self, sci): assert abs(sci.cbrt(27) - 3.0) < 1e-9
    def test_nth_root(self, sci): assert abs(sci.nth_root(32, 5) - 2.0) < 1e-9
    def test_log(self, sci): assert abs(sci.log(math.e) - 1.0) < 1e-9
    def test_log10(self, sci): assert abs(sci.log10(1000) - 3.0) < 1e-9
    def test_log2(self, sci): assert abs(sci.log2(8) - 3.0) < 1e-9
    def test_factorial(self, sci): assert sci.factorial(5) == 120
    def test_factorial_zero(self, sci): assert sci.factorial(0) == 1
    def test_is_prime(self, sci):
        assert sci.is_prime(7)
        assert not sci.is_prime(9)
        assert not sci.is_prime(1)
    def test_primes_up_to(self, sci):
        assert sci.primes_up_to(10) == [2, 3, 5, 7]
    def test_gcd(self, sci): assert sci.gcd(12, 8) == 4
    def test_lcm(self, sci): assert sci.lcm(4, 6) == 12
    def test_fibonacci(self, sci): assert sci.fibonacci(7) == [0, 1, 1, 2, 3, 5, 8]
    def test_degrees_radians(self, sci):
        assert abs(sci.degrees(math.pi) - 180.0) < 1e-9
        assert abs(sci.radians(180) - math.pi) < 1e-9
    def test_pi_constant(self, sci): assert sci.PI == math.pi
    def test_e_constant(self, sci): assert sci.E == math.e


# ═══════════════════════════════════════════════════════════════════════════════
# StatisticsCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestStatisticsCalculator:
    DATA = [2, 4, 4, 4, 5, 5, 7, 9]

    def test_mean(self, stats): assert stats.mean(self.DATA) == 5.0
    def test_median(self, stats): assert stats.median(self.DATA) == 4.5
    def test_mode(self, stats): assert stats.mode(self.DATA) == [4]
    def test_variance_pop(self, stats): assert abs(stats.variance(self.DATA) - 4.0) < 1e-9
    def test_std_dev(self, stats): assert abs(stats.std_dev(self.DATA) - 2.0) < 1e-9
    def test_range(self, stats): assert stats.range_(self.DATA) == 7
    def test_percentile_50(self, stats):
        assert abs(stats.percentile(self.DATA, 50) - stats.median(self.DATA)) < 1e-6
    def test_z_score(self, stats):
        z = stats.z_score(5.0, self.DATA)
        assert abs(z) < 1.0  # 5 is the mean, z close to 0
    def test_summary_keys(self, stats):
        s = stats.summary(self.DATA)
        for key in ("mean", "median", "mode", "std_dev_pop", "IQR"):
            assert key in s
    def test_correlation(self, stats):
        x = [1, 2, 3, 4, 5]
        y = [2, 4, 6, 8, 10]
        assert abs(stats.correlation(x, y) - 1.0) < 1e-9
    def test_empty_data(self, stats):
        with pytest.raises(ValueError): stats.mean([])


# ═══════════════════════════════════════════════════════════════════════════════
# AlgebraCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestAlgebraCalculator:
    def test_quadratic_two_roots(self, alg):
        result = alg.solve_quadratic(1, -5, 6)
        assert result["nature"] == "two real roots"
        roots = result["roots"]
        assert abs(roots[0] - 3.0) < 1e-9 or abs(roots[1] - 3.0) < 1e-9

    def test_quadratic_complex(self, alg):
        result = alg.solve_quadratic(1, 0, 1)
        assert result["nature"] == "complex conjugate roots"

    def test_solve_linear(self, alg):
        assert abs(alg.solve_linear(2, -6) - 3.0) < 1e-9

    def test_solve_2x2(self, alg):
        x, y = alg.solve_2x2(2, 1, 5,  1, -1, 1)
        assert abs(x - 2.0) < 1e-9
        assert abs(y - 1.0) < 1e-9

    def test_poly_evaluate(self, alg):
        # x^2 - 5x + 6 at x=3 → 0
        assert abs(alg.poly_evaluate([1, -5, 6], 3)) < 1e-9

    def test_poly_derivative(self, alg):
        # d/dx(3x^2 + 2x + 1) = 6x + 2
        assert alg.poly_derivative([3, 2, 1]) == [6, 2]

    def test_evaluate_expression(self, alg):
        assert abs(alg.evaluate_expression("2**3 + sqrt(16)") - 12.0) < 1e-9
        assert abs(alg.evaluate_expression("x**2", {"x": 5}) - 25.0) < 1e-9


# ═══════════════════════════════════════════════════════════════════════════════
# UnitConverter
# ═══════════════════════════════════════════════════════════════════════════════
class TestUnitConverter:
    def test_km_to_mi(self, conv): assert abs(conv.km_to_mi(1) - 0.621371) < 1e-4
    def test_kg_to_lb(self, conv): assert abs(conv.kg_to_lb(1) - 2.20462) < 1e-4
    def test_celsius_to_fahrenheit(self, conv): assert conv.celsius_to_fahrenheit(0) == 32.0
    def test_fahrenheit_to_celsius(self, conv): assert conv.fahrenheit_to_celsius(32) == 0.0
    def test_celsius_to_kelvin(self, conv): assert conv.celsius_to_kelvin(0) == 273.15
    def test_convert_time(self, conv): assert conv.convert_time(1, "h", "min") == 60.0
    def test_convert_data(self, conv): assert conv.convert_data(1, "gb", "mb") == 1000.0
    def test_convert_temperature_round_trip(self, conv):
        c = 25.0
        assert abs(conv.fahrenheit_to_celsius(conv.celsius_to_fahrenheit(c)) - c) < 1e-9
    def test_seconds_to_hms(self, conv): assert conv.seconds_to_hms(3661) == "01:01:01"


# ═══════════════════════════════════════════════════════════════════════════════
# ProgrammerCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestProgrammerCalculator:
    def test_to_binary(self, prog): assert prog.to_binary(10, prefix=False) == "1010"
    def test_to_octal(self, prog): assert prog.to_octal(8, prefix=False) == "10"
    def test_to_hex(self, prog): assert prog.to_hexadecimal(255, prefix=False) == "FF"
    def test_from_binary(self, prog): assert prog.from_binary("1010") == 10
    def test_from_hex(self, prog): assert prog.from_hexadecimal("FF") == 255
    def test_bitwise_and(self, prog): assert prog.bitwise_and(0b1100, 0b1010) == 0b1000
    def test_bitwise_or(self, prog): assert prog.bitwise_or(0b1100, 0b1010) == 0b1110
    def test_bitwise_xor(self, prog): assert prog.bitwise_xor(0b1100, 0b1010) == 0b0110
    def test_left_shift(self, prog): assert prog.left_shift(1, 4) == 16
    def test_right_shift(self, prog): assert prog.right_shift(16, 4) == 1
    def test_is_power_of_two(self, prog):
        assert prog.is_power_of_two(64)
        assert not prog.is_power_of_two(63)
    def test_count_set_bits(self, prog): assert prog.count_set_bits(255) == 8
    def test_to_base(self, prog): assert prog.to_base(255, 16) == "FF"


# ═══════════════════════════════════════════════════════════════════════════════
# FinancialCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestFinancialCalculator:
    def test_simple_interest(self, fin):
        assert fin.simple_interest(1000, 10, 2) == 200.0

    def test_compound_interest(self, fin):
        ci = fin.compound_total(1000, 10, 1)
        assert abs(ci - 1100.0) < 1e-9

    def test_emi(self, fin):
        emi = fin.emi(100_000, 12, 12)
        assert 8000 < emi < 9000  # sanity range

    def test_tax_amount(self, fin):
        assert fin.tax_amount(1000, 15) == 150.0

    def test_discount(self, fin):
        assert fin.price_after_discount(200, 10) == 180.0

    def test_profit_percent(self, fin):
        assert fin.profit_percent(120, 100) == 20.0

    def test_roi(self, fin):
        assert fin.roi(500, 2000) == 25.0

    def test_break_even(self, fin):
        units = fin.break_even_units(10_000, 50, 30)
        assert units == 500.0

    def test_cagr(self, fin):
        cagr = fin.cagr(1000, 1610.51, 10)
        assert abs(cagr - 4.878) < 0.01

    def test_npv(self, fin):
        npv = fin.npv(10, [-1000, 400, 400, 400])
        assert abs(npv - (-5.26)) < 1.0  # approximate


# ═══════════════════════════════════════════════════════════════════════════════
# MatrixCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestMatrixCalculator:
    A = [[1, 2], [3, 4]]
    B = [[5, 6], [7, 8]]

    def test_add(self, mat):
        result = mat.add(self.A, self.B)
        assert result == [[6, 8], [10, 12]]

    def test_multiply(self, mat):
        result = mat.multiply(self.A, self.B)
        assert result == [[19, 22], [43, 50]]

    def test_transpose(self, mat):
        assert mat.transpose(self.A) == [[1, 3], [2, 4]]

    def test_determinant(self, mat):
        assert abs(mat._det_recursive(self.A) - (-2)) < 1e-9

    def test_identity(self, mat):
        assert mat.identity(2) == [[1.0, 0.0], [0.0, 1.0]]

    def test_trace(self, mat):
        assert mat.trace(self.A) == 5

    def test_inverse(self, mat):
        inv = mat.inverse([[2, 1], [5, 3]])
        result = mat.multiply([[2, 1], [5, 3]], inv)
        for i in range(2):
            for j in range(2):
                expected = 1.0 if i == j else 0.0
                assert abs(result[i][j] - expected) < 1e-9


# ═══════════════════════════════════════════════════════════════════════════════
# ComplexCalculator
# ═══════════════════════════════════════════════════════════════════════════════
class TestComplexCalculator:
    def test_make(self, cx): assert cx.make(3, 4) == complex(3, 4)
    def test_modulus(self, cx): assert cx.modulus(complex(3, 4)) == 5.0
    def test_conjugate(self, cx): assert cx.conjugate(complex(3, 4)) == complex(3, -4)
    def test_add(self, cx): assert cx.add(complex(1, 2), complex(3, 4)) == complex(4, 6)
    def test_multiply(self, cx): assert cx.multiply(complex(1, 1), complex(1, -1)) == complex(2, 0)
    def test_sqrt(self, cx): assert abs(cx.sqrt(complex(-1, 0)) - complex(0, 1)) < 1e-9
    def test_polar_roundtrip(self, cx):
        z = complex(3, 4)
        r, theta = cx.to_polar(z)
        z2 = cx.from_polar(r, theta)
        assert abs(z - z2) < 1e-9
    def test_divide_by_zero(self, cx):
        with pytest.raises(ZeroDivisionError): cx.divide(complex(1, 1), 0)
