# UkeshUkesh UltraCalc 🧮

**A comprehensive, zero-dependency Python calculator library.**

[![PyPI version](https://badge.fury.io/py/ukesh_ultra_calc.svg)](https://pypi.org/project/ukesh_ultra_calc/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

---

## Features

| Module | Capabilities |
|---|---|
| `BasicCalculator` | +, −, ×, ÷, %, **, //, percentage, rounding |
| `ScientificCalculator` | Trig, hyperbolic, log, roots, primes, GCD/LCM, Fibonacci, random |
| `StatisticsCalculator` | Mean, median, mode, variance, std dev, correlation, regression |
| `AlgebraCalculator` | Quadratic & linear solvers, 2×2/3×3 systems, polynomials |
| `UnitConverter` | Length, mass, temperature, time, area, volume, speed, data, pressure, energy |
| `ProgrammerCalculator` | Base conversions, bitwise ops, bit manipulation |
| `FinancialCalculator` | Interest, EMI, NPV, IRR, ROI, tax, profit/loss, depreciation |
| `MatrixCalculator` | Add, multiply, transpose, determinant, inverse, rank |
| `ComplexCalculator` | Arithmetic, polar form, roots, trig on complex numbers |

---

## Installation

```bash
pip install ukesh_ultra_calc
```

Optional extras:

```bash
pip install ukesh_ultra_calc[symbolic]   # adds sympy
pip install ukesh_ultra_calc[numeric]    # adds numpy
pip install ukesh_ultra_calc[full]       # adds both
```

---

## Quick Start

```python
from ukesh_ultra_calc import (
    BasicCalculator, ScientificCalculator, StatisticsCalculator,
    AlgebraCalculator, UnitConverter, ProgrammerCalculator,
    FinancialCalculator, MatrixCalculator, ComplexCalculator,
)

# ── Basic Arithmetic ─────────────────────────────────────────────
basic = BasicCalculator()
print(basic.add(5, 3))           # 8
print(basic.power(2, 10))        # 1024
print(basic.percent_of(15, 200)) # 30.0
print(basic.percent_change(100, 120))  # 20.0

# ── Scientific ───────────────────────────────────────────────────
sci = ScientificCalculator()
import math
print(sci.sin(math.pi / 2))      # 1.0
print(sci.log10(1000))           # 3.0
print(sci.sqrt(144))             # 12.0
print(sci.nth_root(27, 3))       # 3.0
print(sci.factorial(10))         # 3628800
print(sci.is_prime(97))          # True
print(sci.gcd(48, 18))           # 6
print(sci.fibonacci(8))          # [0, 1, 1, 2, 3, 5, 8, 13]
print(sci.PI)                    # 3.141592653589793

# ── Statistics ───────────────────────────────────────────────────
stats = StatisticsCalculator()
data = [2, 4, 4, 4, 5, 5, 7, 9]
print(stats.mean(data))          # 5.0
print(stats.median(data))        # 4.5
print(stats.mode(data))          # [4]
print(stats.std_dev(data))       # 2.0
print(stats.summary(data))       # Full descriptive stats dict

x = [1, 2, 3, 4, 5]
y = [2, 4, 6, 8, 10]
print(stats.correlation(x, y))  # 1.0
reg = stats.linear_regression(x, y)
print(reg)  # {'slope': 2.0, 'intercept': 0.0, 'r_squared': 1.0}

# ── Algebra ──────────────────────────────────────────────────────
alg = AlgebraCalculator()
print(alg.solve_quadratic(1, -5, 6))
# {'discriminant': 1, 'roots': (3.0, 2.0), 'nature': 'two real roots'}

print(alg.solve_2x2(2, 1, 5,  1, -1, 1))  # (2.0, 1.0)

coeffs = [[2, 1, -1], [-3, -1, 2], [-2, 1, 2]]
rhs    = [8, -11, -3]
print(alg.solve_3x3(coeffs, rhs))  # (2.0, 3.0, -1.0)

# Polynomial  x³ - 6x² + 11x - 6  at x = 1
print(alg.poly_evaluate([1, -6, 11, -6], 1))  # 0

# Safe expression evaluator
print(alg.evaluate_expression("x**2 + 3*x + 1", {"x": 5}))  # 41

# ── Unit Conversion ──────────────────────────────────────────────
conv = UnitConverter()
print(conv.km_to_mi(100))                       # 62.137...
print(conv.celsius_to_fahrenheit(100))          # 212.0
print(conv.convert_length(1, "mi", "km"))       # 1.609344
print(conv.convert_mass(70, "kg", "lb"))        # 154.32...
print(conv.convert_time(2, "h", "min"))         # 120.0
print(conv.convert_data(1, "gb", "mb"))         # 1000.0
print(conv.seconds_to_hms(3661))               # '01:01:01'

# ── Programmer ───────────────────────────────────────────────────
prog = ProgrammerCalculator()
print(prog.to_binary(42))         # '0b101010'
print(prog.to_hexadecimal(255))   # '0xFF'
print(prog.show_all_bases(255))
# {'decimal': 255, 'binary': '0b11111111', 'octal': '0o377', 'hex': '0xFF'}
print(prog.bitwise_and(0b1100, 0b1010))  # 8
print(prog.left_shift(1, 8))             # 256
print(prog.count_set_bits(255))          # 8
print(prog.is_power_of_two(1024))        # True

# ── Financial ────────────────────────────────────────────────────
fin = FinancialCalculator()
print(fin.simple_interest(10_000, 5, 3))       # 1500.0
print(fin.compound_total(10_000, 5, 10))       # ~16288.94
print(fin.emi(500_000, 8.5, 240))              # monthly EMI

schedule = fin.emi_schedule(100_000, 12, 3)
for row in schedule:
    print(row)

print(fin.npv(10, [-1000, 300, 400, 500]))
print(fin.roi(500, 2000))                      # 25.0
print(fin.cagr(1000, 2000, 10))               # ~7.18

# ── Matrix ───────────────────────────────────────────────────────
mat = MatrixCalculator()
A = [[1, 2], [3, 4]]
B = [[5, 6], [7, 8]]

print(mat.add(A, B))           # [[6, 8], [10, 12]]
print(mat.multiply(A, B))      # [[19, 22], [43, 50]]
print(mat.transpose(A))        # [[1, 3], [2, 4]]
print(mat._det_recursive(A))   # -2.0
print(mat.trace(A))            # 5
inv = mat.inverse([[2, 1], [5, 3]])
print(mat.to_string(inv))

# ── Complex Numbers ──────────────────────────────────────────────
cx = ComplexCalculator()
z1 = cx.make(3, 4)
z2 = cx.make(1, -2)

print(cx.modulus(z1))          # 5.0
print(cx.argument_deg(z1))     # ~53.13°
print(cx.multiply(z1, z2))     # (11+2j)
print(cx.to_polar_string(z1))  # '5.0000 ∠ 53.1301°'
print(cx.info(z1))             # Full property dict
roots = cx.nth_roots(cx.make(-1, 0), 4)  # 4th roots of -1
```

---

## CLI Usage

```bash
# Interactive mode
python -m ukesh_ultra_calc

# Example session
ukesh_ultra_calc> 2**32
 = 4294967296
ukesh_ultra_calc> sin(pi/6)
 = 0.49999999999999994
ukesh_ultra_calc> stats 2 4 6 8 10
  count              5
  mean               6.0
  ...
ukesh_ultra_calc> quad 1 -5 6
  Discriminant : 1
  Nature       : two real roots
  Roots        : (3.0, 2.0)
ukesh_ultra_calc> emi 500000 8.5 240
  Monthly EMI  : 4,340.13
  ...
ukesh_ultra_calc> bin 255
  decimal    255
  binary     0b11111111
  octal      0o377
  hex        0xFF
```

---

## Running Tests

```bash
pip install ukesh_ultra_calc[dev]
pytest tests/ -v --cov=ukesh_ultra_calc
```

---

## Project Structure

```
ukesh_ultra_calc/
├── ukesh_ultra_calc/
│   ├── __init__.py          # Public API
│   ├── __main__.py          # CLI entry point
│   ├── basic.py             # BasicCalculator
│   ├── scientific.py        # ScientificCalculator
│   ├── statistics.py        # StatisticsCalculator
│   ├── algebra.py           # AlgebraCalculator
│   ├── converter.py         # UnitConverter
│   ├── programmer.py        # ProgrammerCalculator
│   ├── financial.py         # FinancialCalculator
│   ├── matrix.py            # MatrixCalculator
│   └── complex_calc.py      # ComplexCalculator
├── tests/
│   └── test_all.py
├── pyproject.toml
├── README.md
└── LICENSE
```

---

## License

MIT © 2024 Your Name
