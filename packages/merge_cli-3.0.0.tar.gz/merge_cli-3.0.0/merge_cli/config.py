"""
merge_cli/config.py  —  v3.0.0
固定服务器地址为 https://merge.fanglab.cn/
去除注册/登录/Token 认证，去除用户手动配置 URL。
"""
import os, json
from pathlib import Path

# ── 固定服务器地址 ─────────────────────────────────────────────
FIXED_API_URL = "https://merge.fanglab.cn"

_CONFIG_FILE = Path.home() / ".config" / "merge-cli" / "config.json"


def _load_file() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_file(data: dict) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2))


def get_api_url() -> str:
    """始终返回固定服务器地址（不允许用户覆盖）。"""
    return FIXED_API_URL


def get_mode() -> str:
    return _load_file().get("mode", "remote")


def set_mode(mode: str) -> None:
    if mode not in ("remote", "local"):
        raise ValueError(f"mode 必须是 'remote' 或 'local'，收到：{mode}")
    cfg = _load_file()
    cfg["mode"] = mode
    _save_file(cfg)


_LOCAL_DEFAULTS = {
    "data_dir":     str(Path.home() / ".merge-data"),
    "model_dir":    str(Path.home() / ".merge-models"),
    "annovar_dir":  "",
    "hyenadna_url": "http://localhost:5001",
    "nt_url":       "http://localhost:5002",
    "evo2_url":     "http://localhost:8082",
}


def get_local_config() -> dict:
    cfg = _load_file()
    local = cfg.get("local", {})
    # 兼容旧版废弃字段
    local.pop("evo1_url", None)
    return {**_LOCAL_DEFAULTS, **local}


def set_local_config(key: str, value) -> None:
    cfg = _load_file()
    if "local" not in cfg:
        cfg["local"] = {}
    cfg["local"][key] = value
    _save_file(cfg)


def set_local_config_bulk(updates: dict) -> None:
    cfg = _load_file()
    if "local" not in cfg:
        cfg["local"] = {}
    cfg["local"].update(updates)
    _save_file(cfg)


def show_config() -> dict:
    local_cfg = get_local_config()
    return {
        "api_url":     FIXED_API_URL,
        "mode":        get_mode(),
        "config_file": str(_CONFIG_FILE),
        "local":       local_cfg,
    }
