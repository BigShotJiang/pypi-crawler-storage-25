"""
merge_cli/api.py  —  v3.0.0
封装所有对 Django 后端的 HTTP 请求。
服务器地址固定为 https://merge.fanglab.cn/，无需 Token 认证。
"""
import sys
from typing import Optional

import requests

from .config import FIXED_API_URL

_TIMEOUT_SINGLE = 180
_TIMEOUT_BATCH  = 60

_BASE = FIXED_API_URL


def _headers() -> dict:
    return {"Accept": "application/json"}


# ─────────────────────────────────────────────────────────────
# 1. 单变异预测  POST /predict/
# ─────────────────────────────────────────────────────────────
def predict_single(
    chrom: str, pos: int, ref: str, alt: str,
    genome_version: str = "hg38",
    use_alphagenome:   bool = True,
    use_hyenadna:      bool = True,
    use_nt:            bool = True,
    use_alphamissense: bool = True,
    use_esm1b:         bool = True,
    use_gpn_msa:       bool = True,
    use_popeve:        bool = True,
    use_evo2:          bool = True,
    use_evo1:          bool = True,
) -> dict:
    payload = {
        "chr": chrom, "pos": pos, "ref": ref, "alt": alt,
        "genome_version": genome_version,
        "use_alphagenome":   str(use_alphagenome).lower(),
        "use_hyenadna":      str(use_hyenadna).lower(),
        "use_nt":            str(use_nt).lower(),
        "use_alphamissense": str(use_alphamissense).lower(),
        "use_esm1b":         str(use_esm1b).lower(),
        "use_gpn_msa":       str(use_gpn_msa).lower(),
        "use_popeve":        str(use_popeve).lower(),
        "use_evo2":          str(use_evo2).lower(),
        "use_evo1":          str(use_evo1).lower(),
    }
    resp = requests.post(
        f"{_BASE}/predict/",
        json=payload,
        headers=_headers(),
        timeout=_TIMEOUT_SINGLE,
    )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 2. 集成模型评分  POST /ensemble/
# ─────────────────────────────────────────────────────────────
def predict_ensemble(prediction: dict, all_transcripts: list) -> dict:
    payload = {"prediction": prediction, "all_transcripts": all_transcripts}
    resp = requests.post(
        f"{_BASE}/ensemble/",
        json=payload,
        headers=_headers(),
        timeout=_TIMEOUT_SINGLE,
    )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 3. 批量提交  POST /api/submit_batch_job/
# ─────────────────────────────────────────────────────────────
def submit_batch(
    vcf_path: str,
    email: str,
    genome_version: str = "hg38",
    use_alphagenome:   bool = True,
    use_hyenadna:      bool = True,
    use_nt:            bool = True,
    use_alphamissense: bool = True,
    use_esm1b:         bool = True,
    use_gpn_msa:       bool = True,
    use_popeve:        bool = True,
    use_evo2:          bool = True,
    use_evo1:          bool = True,
) -> dict:
    data = {
        "notify_email":    email,
        "genome_version":  genome_version,
        "use_alphagenome":   str(use_alphagenome).lower(),
        "use_hyenadna":      str(use_hyenadna).lower(),
        "use_nt":            str(use_nt).lower(),
        "use_alphamissense": str(use_alphamissense).lower(),
        "use_esm1b":         str(use_esm1b).lower(),
        "use_gpn_msa":       str(use_gpn_msa).lower(),
        "use_popeve":        str(use_popeve).lower(),
        "use_evo2":          str(use_evo2).lower(),
        "use_evo1":          str(use_evo1).lower(),
    }
    with open(vcf_path, "rb") as f:
        resp = requests.post(
            f"{_BASE}/api/submit_batch_job/",
            data=data,
            files={"vcf_file": (vcf_path.split("/")[-1], f)},
            headers=_headers(),
            timeout=_TIMEOUT_BATCH,
        )
    resp.raise_for_status()
    return resp.json()


# ─────────────────────────────────────────────────────────────
# 4. 查询批量任务状态  GET /api/batch_job/<job_id>/
# ─────────────────────────────────────────────────────────────
def get_batch_status(job_id: str) -> dict:
    resp = requests.get(
        f"{_BASE}/api/batch_job/{job_id}/",
        headers=_headers(),
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()
