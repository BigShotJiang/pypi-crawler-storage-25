"""
ensemble_predict.py
放置路径: <django_app>/ensemble_predict.py（与 views.py 同级）

功能:
  1. 启动时加载三个 pkl 模型文件 (Coding, Splice, Non-coding)
  2. 从预测结果中提取特征（多转录本取均值）
  3. 自动用模型自带分布补充缺失值
  4. 用对应模型计算最终致病性得分
  5. 生成 SHAP 瀑布图，返回 base64 PNG
"""
import os
import subprocess
import tempfile
import sys
import os
import pickle
import logging
import io
import base64
import re
from itertools import combinations

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

from sklearn.experimental import enable_iterative_imputer   # noqa: F401
from sklearn.impute import IterativeImputer
from sklearn.preprocessing import MinMaxScaler, StandardScaler

logger = logging.getLogger(__name__)

# ==========================================
# 自定义特征工程类（用于反序列化 pkl 模型）
# ==========================================
class FeatureEngineer:
    def __init__(self, base_feature_names: list):
        self.base_names = base_feature_names
        self.n = len(base_feature_names)
        self._train_median: np.ndarray = None
        self._std_scaler = StandardScaler()
        self.feature_names_: list = []
        self._fitted = False

    def _build_feature_names(self) -> list:
        names = []
        for n in self.base_names:
            names.append(f"orig|{self._short(n)}")
        for n in self.base_names:
            names.append(f"rank|{self._short(n)}")
        names += ["cons|vote_ratio", "cons|std", "cons|range", "cons|max", "cons|min"]
        for i, j in combinations(range(self.n), 2):
            ni = self._short(self.base_names[i])
            nj = self._short(self.base_names[j])
            names.append(f"inter|{ni}×{nj}")
        return names

    @staticmethod
    def _short(name: str) -> str:
        return re.sub(r'_(rank)?score', '', name, flags=re.IGNORECASE).strip('_')

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        self._train_median = np.median(X, axis=0)
        X_fe = self._build_features(X)
        X_fe = self._std_scaler.fit_transform(X_fe)
        self.feature_names_ = self._build_feature_names()
        self._fitted = True
        return X_fe

    def transform(self, X: np.ndarray) -> np.ndarray:
        if not self._fitted:
            raise RuntimeError("FeatureEngineer must be fit_transform()'d first.")
        X_fe = self._build_features(X)
        return self._std_scaler.transform(X_fe)

    def _build_features(self, X: np.ndarray) -> np.ndarray:
        orig = X.copy()
        n_s = X.shape[0]
        rank = np.apply_along_axis(lambda col: (np.argsort(np.argsort(col)) + 1) / n_s, axis=0, arr=X)
        vote = (X > self._train_median).astype(float)
        vote_r = vote.mean(axis=1, keepdims=True)
        std_v = X.std(axis=1, keepdims=True)
        range_ = (X.max(axis=1) - X.min(axis=1)).reshape(-1, 1)
        max_v = X.max(axis=1, keepdims=True)
        min_v = X.min(axis=1, keepdims=True)
        consensus = np.hstack([vote_r, std_v, range_, max_v, min_v])

        pairs = []
        for i, j in combinations(range(self.n), 2):
            pairs.append(X[:, i:i + 1] * X[:, j:j + 1])
        if pairs:
            interaction = np.hstack(pairs)
            return np.hstack([orig, rank, consensus, interaction])
        else:
            return np.hstack([orig, rank, consensus])

    @property
    def group_slices(self) -> dict:
        n = self.n
        n_inter = len(list(combinations(range(n), 2)))
        return {
            f'Original ({n})': slice(0, n),
            f'Rank ({n})': slice(n, 2 * n),
            'Consensus (5)': slice(2 * n, 2 * n + 5),
            f'Interaction ({n_inter})': slice(2 * n + 5, 2 * n + 5 + n_inter),
        }

# 欺骗 pickle/joblib，将类强制注册到全局 __main__ 命名空间
import sys
sys.modules['__main__'].FeatureEngineer = FeatureEngineer
# ==========================================


# ─────────────────────────────────────────────────────────────
# 1. 路径配置
# ─────────────────────────────────────────────────────────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATHS = {
    'ClinVar':               os.path.join(_THIS_DIR, 'BestModel_Clinvar.pkl'),
    'Splice_ClinVar_GnomAD': os.path.join(_THIS_DIR, 'BestModel_Splice_Unsupervised Only.pkl'),
    'NonCoding_ClinVar':     os.path.join(_THIS_DIR, 'BestModel_Clinvar-noncoding.pkl'),
}

for _name, _path in MODEL_PATHS.items():
    logger.info(f"[Ensemble] 模型路径 {_name} => {_path} (存在: {os.path.exists(_path)})")

TRAIN_CSV_PATHS = {
    'ClinVar':               os.path.join(_THIS_DIR, 'clinvar.csv'),
    'Splice_ClinVar_GnomAD': os.path.join(_THIS_DIR, 'spliceall.csv'),
    'NonCoding_ClinVar':     os.path.join(_THIS_DIR, 'clinvar_noncoding.csv'),
}

# 🚨 这里的顺序严格按照特征排列，解决 Feature 9 not in pool 的问题
TRAIN_FEATURE_COLS = {
    'ClinVar': [
        'heyenadna_score', 'alphagenome_raw_score_mean', 'evo2_score',
         'NT_score', 'ESM1b_score',
        'AlphaMissense_score', 'popEVE_score', 'GPN_MSA_score',
    ],
    'Splice_ClinVar_GnomAD': [
        'alphagenome_splicing', 'evo2_score'
    ],
    'NonCoding_ClinVar': [
        'GPN_MSA_score', 
        'NT_score', 
        'heyenadna_score', 
        'alphagenome_raw_score_max',
        'alphagenome_quantile_score_max', 
        'alphagenome_raw_score_min', 
        'alphagenome_quantile_score_min',
        'alphagenome_raw_score_mean', 
        'alphagenome_quantile_score_mean',
        'evo2_score'
    ],
}

# ─────────────────────────────────────────────────────────────
# 预处理器缓存
# ─────────────────────────────────────────────────────────────
_preprocessor_cache: dict = {}

def _fit_preprocessors() -> None:
    global _preprocessor_cache
    for model_name, csv_path in TRAIN_CSV_PATHS.items():
        if model_name in _preprocessor_cache: continue
        feat_cols = TRAIN_FEATURE_COLS.get(model_name, [])
        if not feat_cols or not os.path.exists(csv_path): continue

        try:
            df = pd.read_csv(csv_path, usecols=lambda c: c in feat_cols)
            df = df[feat_cols]
            mice = IterativeImputer(max_iter=10, random_state=42, min_value=-np.inf, max_value=np.inf)
            mice.fit(df.values)
            df_imputed = pd.DataFrame(mice.transform(df.values), columns=feat_cols)
            scaler = MinMaxScaler()
            scaler.fit(df_imputed.values)
            _preprocessor_cache[model_name] = {'scaler': scaler, 'imputer': mice, 'feature_cols': feat_cols}
            logger.info(f"[Preproc] {model_name}: MinMaxScaler + MICE 拟合完成")
        except Exception as exc:
            logger.error(f"[Preproc] 拟合预处理器失败 [{model_name}]: {exc}", exc_info=True)

_fit_preprocessors()

# ─────────────────────────────────────────────────────────────
# 2. 特征名别名映射
# ─────────────────────────────────────────────────────────────
FEATURE_ALIASES: dict[str, list[str]] = {
    'AlphaMissense': ['AlphaMissense_score', 'AlphaMissense', 'alphamissense', 'alphamissense_score', 'AM_score'],
    'ESM1b': ['ESM1b_score', 'ESM1b', 'esm1b', 'esm1b_score', 'ESM1v_score'],
    'GPN_MSA': ['GPN_MSA_score', 'GPN_MSA', 'gpn_msa', 'GPN-MSA'],
    'popEVE': ['popEVE_score', 'popEVE', 'popeve'],
    'AlphaGenome': ['alphagenome_raw_score_mean', 'AlphaGenome', 'AG_raw_mean'],
    'AlphaGenomeSplicing': ['alphagenome_splicing', 'AG_splicing'],
    'AlphaGenomeMax': ['alphagenome_raw_score_max', 'AG_raw_max'],
    'AlphaGenomeMin': ['alphagenome_raw_score_min', 'AG_raw_min'],
    'AlphaGenomeQuantileMean': ['alphagenome_quantile_score_mean', 'AG_quantile_mean'],
    'AlphaGenomeQuantileMax': ['alphagenome_quantile_score_max', 'AG_quantile_max'],
    'AlphaGenomeQuantileMin': ['alphagenome_quantile_score_min', 'AG_quantile_min'],
    'HyenaDNA': ['heyenadna_score', 'hyenadna_score', 'HyenaDNA'],
    'NT': ['NT_score', 'NT', 'nt', 'NT_l2'],
    'Evo2': ['evo2_score', 'Evo2', 'Evo2_llr'],
    'Evo1': ['evo1_delta_score', 'Evo1', 'Evo1_delta'],
}

def _resolve_alias(model_col: str) -> str | None:
    col_lower = model_col.lower()
    for our_key, aliases in FEATURE_ALIASES.items():
        if model_col in aliases or col_lower == our_key.lower(): return our_key
        for alias in aliases:
            if col_lower == alias.lower(): return our_key
    return None


# ─────────────────────────────────────────────────────────────
# 3. 模型缓存
# ─────────────────────────────────────────────────────────────
_model_cache: dict = {}
_raw_cache: dict = {}
_model_load_errors: dict = {}

def _extract_model_from_obj(obj, path: str):
    if hasattr(obj, 'predict'): return obj
    if isinstance(obj, dict):
        preferred_keys = ['model', 'best_model', 'classifier', 'estimator', 'pipeline', 'clf']
        for key in preferred_keys:
            if key in obj and hasattr(obj[key], 'predict'): return obj[key]
        for key, val in obj.items():
            if hasattr(val, 'predict'): return val
        raise RuntimeError("pkl 是 dict，但未找到含 predict 方法的对象。")
    raise RuntimeError("无法自动提取模型。")

def load_models() -> dict:
    global _model_cache, _raw_cache, _model_load_errors
    for name, path in MODEL_PATHS.items():
        if name in _model_cache: continue
        if not os.path.exists(path):
            _model_load_errors[name] = f"文件不存在: {path}"
            continue
        
        raw_obj = None
        errors = []
        for loader_name, loader in [
            ('joblib', lambda p: __import__('joblib').load(p)), 
            ('pickle', lambda p: pickle.load(open(p, 'rb')))
        ]:
            try:
                raw_obj = loader(path)
                break
            except Exception:
                import traceback
                errors.append(f"[{loader_name}] 报错:\n{traceback.format_exc()}")
        
        if raw_obj is None:
            _model_load_errors[name] = "\n".join(errors)
            continue
        
        try:
            _raw_cache[name] = raw_obj if isinstance(raw_obj, dict) else {}
            model = _extract_model_from_obj(raw_obj, path)
            _model_cache[name] = model
        except Exception:
            import traceback
            _model_load_errors[name] = traceback.format_exc()
            
    return _model_cache

def get_feature_names_from_cache(model_name: str) -> list[str] | None:
    raw = _raw_cache.get(model_name, {})
    for key in ('feature_names', 'features', 'columns', 'feature_list', 'feature_names_in_'):
        if key in raw and isinstance(raw[key], (list, tuple)): return list(raw[key])
    return None

# ─────────────────────────────────────────────────────────────
# 4. 特征提取
# ─────────────────────────────────────────────────────────────
def _to_float(value) -> float:
    try:
        return float('nan') if value in [None, '.', 'N/A', '', 'NA'] else float(value)
    except: return float('nan')

def extract_features(pred_data: dict, all_transcripts: list, is_splice: bool = False) -> dict[str, float]:
    feats: dict[str, float] = {}
    am_vals, esm_vals = [], []
    for t in all_transcripts:
        dm = t.get('dl_models', {}) or {}
        v_am = _to_float((dm.get('AlphaMissense') or {}).get('score'))
        if not np.isnan(v_am): am_vals.append(v_am)
        v_esm = _to_float((dm.get('ESM1b') or {}).get('score'))
        if not np.isnan(v_esm): esm_vals.append(v_esm)

    feats['AlphaMissense'] = float(np.mean(am_vals)) if am_vals else float('nan')
    feats['ESM1b'] = float(np.mean(esm_vals)) if esm_vals else float('nan')
    feats['GPN_MSA'] = _to_float((pred_data.get('gpn_msa') or {}).get('score'))
    feats['popEVE'] = _to_float((pred_data.get('popeve') or {}).get('score'))

    ag_stats = (pred_data.get('alphagenome') or {}).get('statistics') or {}
    if is_splice:
        feats['AlphaGenomeSplicing'] = _to_float(ag_stats.get('alphagenome_splicing'))
        feats['AlphaGenome'] = feats['AlphaGenomeMax'] = feats['AlphaGenomeMin'] = float('nan')
        feats['AlphaGenomeQuantileMean'] = float('nan')
        feats['AlphaGenomeQuantileMax'] = float('nan')
        feats['AlphaGenomeQuantileMin'] = float('nan')
    else:
        feats['AlphaGenome'] = _to_float(ag_stats.get('raw_score_mean'))
        feats['AlphaGenomeMax'] = _to_float(ag_stats.get('raw_score_max'))
        feats['AlphaGenomeMin'] = _to_float(ag_stats.get('raw_score_min'))
        feats['AlphaGenomeQuantileMean'] = _to_float(ag_stats.get('quantile_score_mean'))
        feats['AlphaGenomeQuantileMax'] = _to_float(ag_stats.get('quantile_score_max'))
        feats['AlphaGenomeQuantileMin'] = _to_float(ag_stats.get('quantile_score_min'))
        feats['AlphaGenomeSplicing'] = float('nan')

    feats['HyenaDNA'] = _to_float((pred_data.get('hyenadna') or {}).get('score'))
    feats['NT'] = _to_float((pred_data.get('nt') or {}).get('score'))
    feats['Evo2'] = _to_float((pred_data.get('evo2') or {}).get('llr_score'))
    feats['Evo1'] = _to_float((pred_data.get('evo1') or {}).get('evo1_delta_score'))
    return feats


# ─────────────────────────────────────────────────────────────
# 5. 特征对齐 & 缺失值补充
# ─────────────────────────────────────────────────────────────
def _get_model_feature_names(model) -> list[str] | None:
    for attr in ('feature_names_in_', 'feature_name_', 'feature_names_'):
        if hasattr(model, attr): return list(getattr(model, attr))
    if hasattr(model, 'named_steps'): steps = list(model.named_steps.values())
    elif hasattr(model, 'steps'): steps = [v for _, v in model.steps]
    else: return None
    for step in reversed(steps):
        for attr in ('feature_names_in_', 'feature_name_', 'feature_names_'):
            if hasattr(step, attr): return list(getattr(step, attr))
    return None

def build_feature_dataframe(our_feats: dict, model, model_name: str = '') -> tuple[pd.DataFrame, list[str]]:
    # 🚨 强制从我们配置好的 TRAIN_FEATURE_COLS 里取列，严格规避特征漏传
    if model_name in TRAIN_FEATURE_COLS:
        model_cols = TRAIN_FEATURE_COLS[model_name]
    else:
        model_cols = get_feature_names_from_cache(model_name)
        if not model_cols: model_cols = _get_model_feature_names(model)
        if not model_cols: model_cols = list(FEATURE_ALIASES.keys())

    row = {}
    for col in model_cols:
        our_key = _resolve_alias(col)
        row[col] = our_feats.get(our_key, float('nan')) if our_key else float('nan')
    df = pd.DataFrame([row], columns=model_cols)
    return df, model_cols

def impute_missing(df: pd.DataFrame, model_name: str) -> pd.DataFrame:
    df = df.copy()
    prep = _preprocessor_cache.get(model_name)

    if prep is not None:
        mice: IterativeImputer = prep['imputer']
        feat_cols: list[str]   = prep['feature_cols']
        try:
            cols_in_df = [c for c in feat_cols if c in df.columns]
            if cols_in_df:
                arr = df[cols_in_df].values.astype(float)
                arr_imp = mice.transform(arr)
                df[cols_in_df] = arr_imp
                return df
        except Exception as exc:
            logger.error(f"[Impute] MICE 填补失败 [{model_name}]: {exc}", exc_info=True)

    _FALLBACK_DEFAULTS: dict[str, float] = {
        'AlphaMissense_score':        0.5,
        'popEVE_score':               0.5,
        'alphagenome_raw_score_mean': 0.5,
        'alphagenome_raw_score_max':  0.5,
        'alphagenome_raw_score_min':  0.5,
        'alphagenome_quantile_score_mean': 0.5,
        'alphagenome_quantile_score_max': 0.5,
        'alphagenome_quantile_score_min': 0.5,
        'alphagenome_splicing':       0.0,
        'ESM1b_score':                0.0,
        'GPN_MSA_score':              0.0,
        'heyenadna_score':            0.0,
        'NT_score':                   0.0,
        'evo2_score':                 0.0,
        'evo1_delta_score':           0.0,
    }
    for col in df.columns:
        if df[col].isna().any():
            fill_val = _FALLBACK_DEFAULTS.get(col, 0.0)
            df[col] = df[col].fillna(fill_val)
    return df

def normalize_features(df: pd.DataFrame, model_name: str) -> pd.DataFrame:
    df = df.copy()
    prep = _preprocessor_cache.get(model_name)
    if prep is None: return df
    scaler: MinMaxScaler = prep['scaler']
    feat_cols: list[str] = prep['feature_cols']
    cols_in_df = [c for c in feat_cols if c in df.columns]
    if not cols_in_df: return df
    try:
        arr = df[cols_in_df].values.astype(float)
        arr_scaled = scaler.transform(arr)
        arr_scaled = np.clip(arr_scaled, 0.0, 1.0)
        df[cols_in_df] = arr_scaled
    except Exception as exc:
        logger.error(f"[Normalize] 归一化失败 [{model_name}]: {exc}")
    return df


# ─────────────────────────────────────────────────────────────
# 6. SHAP 与兜底重要性图绘制（完整恢复）
# ─────────────────────────────────────────────────────────────
def _get_final_estimator(model):
    if hasattr(model, 'named_steps'): return list(model.named_steps.values())[-1]
    if hasattr(model, 'steps'): return model.steps[-1][1]
    return model

def _make_background(feature_df, n=10):
    n_feat = feature_df.shape[1]
    rows = [[0.0] * n_feat, [1.0] * n_feat]
    for v in [0.2, 0.4, 0.5, 0.6, 0.8]:
        rows.append([v] * n_feat)
    return pd.DataFrame(rows[:n], columns=feature_df.columns)

def _extract_shap_1d(sv, n_features):
    if hasattr(sv, 'values'): sv = sv.values
    if isinstance(sv, list): sv = sv[1] if len(sv) > 1 else sv[0]
    arr = np.array(sv, dtype=float)
    if arr.ndim == 3: arr = arr[0, :, 1]
    elif arr.ndim == 2 and arr.shape[0] == 1: arr = arr[0]
    elif arr.ndim == 2 and arr.shape[1] == 2: arr = arr[:, 1]
    if arr.shape == (1,): arr = np.full(n_features, arr[0])
    return arr.astype(float)

def _get_shap_values(model, feature_df, feature_names):
    try:
        import shap
    except ImportError:
        logger.warning("[Ensemble] shap not installed. pip install shap")
        return None

    estimator = _get_final_estimator(model)
    arr = feature_df.values
    n_feat = len(feature_names)
    bg = _make_background(feature_df)

    try:
        exp = shap.TreeExplainer(estimator, data=bg, feature_perturbation='interventional')
        return _extract_shap_1d(exp.shap_values(arr), n_feat)
    except: pass

    try:
        exp = shap.TreeExplainer(estimator)
        return _extract_shap_1d(exp.shap_values(arr), n_feat)
    except: pass

    try:
        exp = shap.LinearExplainer(estimator, bg)
        return _extract_shap_1d(exp.shap_values(arr), n_feat)
    except: pass

    try:
        masker = shap.maskers.Independent(bg)
        exp = shap.Explainer(estimator, masker)
        return _extract_shap_1d(exp(feature_df), n_feat)
    except: pass

    try:
        def _pred_fn(x):
            _df = pd.DataFrame(x, columns=feature_names)
            try: return model.predict_proba(_df)[:, 1]
            except AttributeError: return model.predict(_df).astype(float)
        exp = shap.KernelExplainer(_pred_fn, bg)
        return _extract_shap_1d(exp.shap_values(arr, nsamples=200, silent=True), n_feat)
    except Exception as e5:
        logger.warning(f"[Ensemble] All SHAP strategies failed: {e5}")

    return None

def _fallback_importance_plot(model, feature_names: list[str], feat_vals: np.ndarray, model_name: str) -> str | None:
    """SHAP 失败时的兜底重要性绘图（完整保留）"""
    estimator = _get_final_estimator(model)
    if not hasattr(estimator, 'feature_importances_'): return None
    try:
        importances = np.array(estimator.feature_importances_, dtype=float)
        sorted_idx = np.argsort(importances)[::-1][:min(len(feature_names), 9)]
        names_s = [feature_names[i] for i in sorted_idx]
        imp_s   = importances[sorted_idx]
        fval_s  = feat_vals[sorted_idx]

        y_labels = [f"{n}  [{v:.4f}]" for n, v in zip(names_s, fval_s)]
        max_label_chars = max(len(lb) for lb in y_labels)
        left_inch  = max(3.5, max_label_chars * 0.072)
        fig_width  = left_inch + 7.5
        n_bars     = len(names_s)
        fig_height = max(5, 0.75 * n_bars + 2.2)

        fig, ax = plt.subplots(figsize=(fig_width, fig_height))
        fig.patch.set_facecolor('#1a2a55')
        ax.set_facecolor('#1e3c72')
        ax.barh(np.arange(n_bars), imp_s, color='#60aaff', alpha=0.85, height=0.55, edgecolor='none')

        ax.invert_yaxis()
        ax.set_yticks(np.arange(n_bars))
        ax.set_yticklabels(y_labels, color='white', fontsize=9.5)
        ax.set_xlabel('Feature Importance (Gini/Gain)', color='#c8d8ff', fontsize=10)
        ax.set_title(
            f"Feature Importance — {model_name}  (SHAP unavailable, using built-in importance)",
            color='white', fontsize=11, fontweight='bold', pad=12
        )
        ax.tick_params(colors='white', length=0)
        for spine in ax.spines.values(): spine.set_visible(False)
        ax.spines['bottom'].set_visible(True)
        ax.spines['bottom'].set_color('rgba(255,255,255,0.2)')

        left_frac = left_inch / fig_width
        fig.subplots_adjust(left=left_frac + 0.01, right=0.97, top=0.92, bottom=0.10)

        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight', dpi=130, facecolor='#1a2a55', edgecolor='none')
        plt.close(fig)
        buf.seek(0)
        return base64.b64encode(buf.read()).decode('utf-8')
    except Exception as exc:
        logger.error(f"[Ensemble] 兜底重要性图失败: {exc}")
        return None

def generate_shap_plot(model, feature_df: pd.DataFrame, feature_names: list[str], model_name: str = '') -> str | None:
    feat_vals = feature_df.values[0]
    sv_1d = _get_shap_values(model, feature_df, feature_names)

    if sv_1d is None:
        logger.warning(f"[Ensemble] {model_name}: SHAP 不可用，改用 feature_importances_")
        return _fallback_importance_plot(model, feature_names, feat_vals, model_name)

    try:
        n = len(feature_names)
        sorted_idx   = np.argsort(np.abs(sv_1d))[::-1][:min(n, 9)]
        names_sorted = [feature_names[i] for i in sorted_idx]
        shap_sorted  = sv_1d[sorted_idx]
        fval_sorted  = feat_vals[sorted_idx]

        y_labels = [f"{nm}  [{fv:.4f}]" for nm, fv in zip(names_sorted, fval_sorted)]
        max_label_chars = max(len(lb) for lb in y_labels)
        left_inch       = max(3.5, max_label_chars * 0.072)
        fig_width       = left_inch + 7.5
        n_bars = len(names_sorted)
        fig_height = max(5, 0.75 * n_bars + 2.2)

        fig, ax = plt.subplots(figsize=(fig_width, fig_height))
        fig.patch.set_facecolor('#1a2a55')
        ax.set_facecolor('#1e3c72')

        colors = ['#ff6b6b' if v > 0 else '#6bcf7f' for v in shap_sorted]
        y_pos  = np.arange(n_bars)
        bars   = ax.barh(y_pos, shap_sorted, color=colors, alpha=0.88, height=0.55, edgecolor='none')

        ax.invert_yaxis()
        ax.set_yticks(y_pos)
        ax.set_yticklabels(y_labels, color='white', fontsize=9.5)
        ax.set_xlabel('SHAP Value  (contribution to pathogenicity)', color='#c8d8ff', fontsize=10)
        ax.set_title(
            f"SHAP Feature Contributions — {model_name}" if model_name else "SHAP Feature Contributions",
            color='white', fontsize=12, fontweight='bold', pad=12
        )
        ax.axvline(0, color='white', linewidth=0.6, alpha=0.35)
        ax.tick_params(colors='white', length=0)
        for sp in ax.spines.values(): sp.set_visible(False)
        ax.spines['bottom'].set_visible(True)
        ax.spines['bottom'].set_color('white')
        ax.spines['bottom'].set_alpha(0.25)

        max_abs = max(abs(shap_sorted)) or 1.0
        for bar, val in zip(bars, shap_sorted):
            offset = 0.025 * max_abs
            ax.text(
                val + (offset if val >= 0 else -offset),
                bar.get_y() + bar.get_height() / 2,
                f'{val:+.4f}',
                ha='left' if val >= 0 else 'right',
                va='center', color='white', fontsize=8.5, fontweight='bold'
            )

        p_patch = mpatches.Patch(color='#ff6b6b', label='↑ Increases pathogenicity')
        b_patch = mpatches.Patch(color='#6bcf7f', label='↓ Decreases pathogenicity')
        ax.legend(handles=[p_patch, b_patch], loc='lower right', facecolor='#1e3c72', edgecolor='none', labelcolor='white', fontsize=9)

        left_frac = left_inch / fig_width
        fig.subplots_adjust(left=left_frac + 0.01, right=0.97, top=0.92, bottom=0.10)

        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight', dpi=130, facecolor='#1a2a55', edgecolor='none')
        plt.close(fig)
        buf.seek(0)
        return base64.b64encode(buf.read()).decode('utf-8')

    except Exception as exc:
        logger.error(f"[Ensemble] SHAP 绘图失败: {exc}", exc_info=True)
        return None

# ─────────────────────────────────────────────────────────────
# 7. 得分解读
# ─────────────────────────────────────────────────────────────
def interpret_score(score: float) -> dict:
    if score >= 0.8: return {'label': 'Likely Pathogenic',      'color': '#ff4444', 'badge': '🔴'}
    if score >= 0.6: return {'label': 'Possibly Pathogenic',    'color': '#ff9500', 'badge': '🟠'}
    if score >= 0.4: return {'label': 'Uncertain Significance', 'color': '#ffd93d', 'badge': '🟡'}
    if score >= 0.2: return {'label': 'Possibly Benign',        'color': '#4ecb71', 'badge': '🟢'}
    return           {'label': 'Likely Benign',                 'color': '#00cc55', 'badge': '🟢'}

# ─────────────────────────────────────────────────────────────
# 8. 变异类型判断（ANNOVAR + HGVSc/Func 双重策略）
# ─────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
# 8. 变异类型判断（纯 ANNOVAR 严格判定策略）
# ─────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
# 8. 变异类型判断（纯 ANNOVAR 严格判定策略 - 相对路径版）
# ─────────────────────────────────────────────────────────────
import os
import subprocess
import tempfile
import logging

logger = logging.getLogger(__name__)

# 动态获取当前 ensemble_predict.py 所在的目录
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))

# 定位到同级的 annovar 文件夹
ANNOVAR_DIR = os.path.join(_THIS_DIR, 'annovar')
# 默认的数据库文件夹通常叫 humandb
ANNOVAR_DB  = os.path.join(ANNOVAR_DIR, 'humandb')

def get_variant_type_by_annovar(chrom: str, pos: str, ref: str, alt: str, genome_version: str = 'hg19') -> str | None:
    pl = os.path.join(ANNOVAR_DIR, 'annotate_variation.pl')
    
    # 强制打印到 uWSGI 控制台
    print(f"\n[ANNOVAR-DEBUG] 开始处理变异: {chrom}:{pos} {ref}>{alt} ({genome_version})", flush=True)

    if not os.path.exists(pl):
        print(f"[ANNOVAR-DEBUG] 严重错误：找不到脚本 {pl}", flush=True)
        return None

    build = 'hg19' if genome_version == 'hg19' else 'hg38'
    if not chrom.startswith('chr'):
        chrom = 'chr' + chrom
        
    pos_int = int(pos)
    end_int = pos_int + len(ref) - 1 if ref != '-' else pos_int
    avinput = f"{chrom}\t{pos_int}\t{end_int}\t{ref}\t{alt}\n"

    # 获取 perl 绝对路径，防止 uWSGI 找不到 perl
    perl_bin = 'perl'
    import shutil
    if shutil.which('perl'):
        perl_bin = shutil.which('perl')
    else:
        # 如果 shutil 都找不到，尝试硬编码常见路径
        perl_bin = '/usr/bin/perl' 

    fin_path = None
    out_prefix = None
    try:
        project_tmp = os.path.join(ANNOVAR_DIR, 'tmp')
        os.makedirs(project_tmp, exist_ok=True)
        
        with tempfile.NamedTemporaryFile('w', dir=project_tmp, suffix='.avinput', delete=False) as fin:
            fin.write(avinput)
            fin_path = fin.name

        out_prefix = fin_path + '_out'
        
        cmd = [
            perl_bin, pl, '-geneanno', '-dbtype', 'refGene', 
            '-buildver', build, fin_path, ANNOVAR_DB, '-out', out_prefix
        ]
        
        print(f"[ANNOVAR-DEBUG] 执行命令: {' '.join(cmd)}", flush=True)
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

        vf_path = out_prefix + '.variant_function'
        if os.path.exists(vf_path):
            with open(vf_path) as fh:
                line = fh.readline().strip()
            
            if not line:
                print(f"[ANNOVAR-DEBUG] 错误：文件为空 {vf_path}", flush=True)
                return None

            func_field = line.split('\t')[0].lower()
            print(f"[ANNOVAR-DEBUG] 成功！ANNOVAR 原始判定结果为: {func_field}", flush=True)

            if 'splicing' in func_field: return 'splice'
            elif 'exonic' in func_field: return 'coding'
            else: return 'noncoding'
        else:
            print(f"[ANNOVAR-DEBUG] 严重错误：未生成 .variant_function 文件！", flush=True)
            print(f"[ANNOVAR-DEBUG] STDOUT: {result.stdout}", flush=True)
            print(f"[ANNOVAR-DEBUG] STDERR: {result.stderr}", flush=True)
            return None

    except Exception as exc:
        print(f"[ANNOVAR-DEBUG] 发生 Python 异常: {exc}", flush=True)
        import traceback
        traceback.print_exc(file=sys.stdout)
        return None
    finally:
        if fin_path and os.path.exists(fin_path):
            try: os.unlink(fin_path)
            except: pass
        if out_prefix:
            for ext in ['.variant_function', '.exonic_variant_function', '.log']:
                p = out_prefix + ext
                if os.path.exists(p):
                    try: os.unlink(p)
                    except: pass
def determine_variant_type(pred_data: dict, all_transcripts: list) -> str:
    """
    废弃 dbNSFP 解析，完全依赖本地 ANNOVAR 进行类型判定
    """
    inp = pred_data.get('input', {})
    chrom = inp.get('chrom') or inp.get('chr', '')
    pos = inp.get('pos', '')
    ref = inp.get('ref', '')
    alt = inp.get('alt', '')
    gv = pred_data.get('genome_version', 'hg19')

    if chrom and pos and ref and alt:
        vt = get_variant_type_by_annovar(chrom, pos, ref, alt, gv)
        if vt:
            return vt

    # 兜底机制：如果 ANNOVAR 没配置好或崩溃，记录错误日志并退回兜底模型
    logger.warning(f"⚠️ 无法通过 ANNOVAR 确定变异类型 ({chrom}:{pos} {ref}>{alt})，强制按 [noncoding] 兜底计算")
    return 'noncoding'

# ─────────────────────────────────────────────────────────────
# 9. 主执行逻辑
# ─────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
# 9. 主执行逻辑
# ─────────────────────────────────────────────────────────────
def _run_one_model(model_name: str, model, raw_feats: dict, skip_shap: bool = False) -> dict:
    try:
        # 1. 严格按照预设的特征顺序构建 DataFrame (这 9 个原始特征)
        feat_cols = TRAIN_FEATURE_COLS.get(model_name, list(FEATURE_ALIASES.keys()))
        row = {col: raw_feats.get(_resolve_alias(col), float('nan')) for col in feat_cols}
        feat_df = pd.DataFrame([row], columns=feat_cols)
        missing = feat_df.columns[feat_df.isna().any()].tolist()

        # 2. MICE 填补缺失值
        feat_df_imp = impute_missing(feat_df, model_name)

        # 3. 检查模型字典中是否包含了你的 FeatureEngineer
        raw_obj = _raw_cache.get(model_name, {})
        fe_obj = None
        if isinstance(raw_obj, dict):
            # 在字典里寻找你的特征工程实例
            fe_obj = next((v for v in raw_obj.values() if type(v).__name__ == 'FeatureEngineer'), None)
        
        is_pipeline = type(model).__name__ in ('Pipeline', 'GridSearchCV')

        # 4. 数据特征扩维流转（解决 Feature 9 报错的核心！）
        if fe_obj and not is_pipeline:
            # 如果模型绑定了 FeatureEngineer，调用它把 9 列扩充为 59 列！
            # 并且 FeatureEngineer 内部自带了 StandardScaler 标准化
            X_input = fe_obj.transform(feat_df_imp.values)
            feat_df_norm = feat_df_imp  # 仅用作前端展示的原始状态映射
            
            # 为 SHAP 获取扩展后的 59 个特征名
            final_cols = getattr(fe_obj, 'feature_names_', [f"F{i}" for i in range(X_input.shape[1])])
            final_feat_df = pd.DataFrame(X_input, columns=final_cols)
        else:
            # 对于普通的模型（比如原来的编码区），走基础归一化
            feat_df_norm = normalize_features(feat_df_imp, model_name)
            X_input = feat_df_norm
            final_feat_df = feat_df_norm

        # 5. 预测与 SHAP 图表生成
        proba = model.predict_proba(X_input) if hasattr(model, 'predict_proba') else model.predict(X_input)
        score = max(0.0, min(1.0, float(proba[0][1] if hasattr(model, 'predict_proba') else proba[0])))
        shap_b64 = None if skip_shap else generate_shap_plot(model, final_feat_df, final_feat_df.columns.tolist(), model_name)

        features_raw_aligned = {}
        for col in feat_cols:
            our_key = _resolve_alias(col)
            raw_v   = raw_feats.get(our_key) if our_key else None
            features_raw_aligned[col] = None if (raw_v is None or np.isnan(raw_v)) else round(float(raw_v), 4)

        return {
            'score': round(score, 4),
            'interpretation': interpret_score(score),
            'features_input': {k: (None if np.isnan(v) else round(v, 4)) for k, v in raw_feats.items()},
            'features_raw_aligned': features_raw_aligned,
            'missing_features': missing,
            'imputed_features': {col: round(float(feat_df_imp[col].iloc[0]), 4) for col in feat_cols},
            'normalized_features': {col: round(float(feat_df_norm[col].iloc[0]), 4) for col in feat_cols},
            'shap_plot': shap_b64,
        }
    except Exception as exc:
        import traceback
        return {'score': None, 'error': f"预测过程失败: {exc}\n{traceback.format_exc()}"}

def run_ensemble(pred_data: dict, all_transcripts: list, skip_shap: bool = False) -> tuple[dict | None, str | None]:
    models = load_models()
    variant_type = determine_variant_type(pred_data, all_transcripts)

    type_to_model = {'splice': 'Splice_ClinVar_GnomAD', 'coding': 'ClinVar', 'noncoding': 'NonCoding_ClinVar'}
    chosen_key = type_to_model.get(variant_type, 'ClinVar')

    # 💣 砸掉强行兜底机制！把真实报错扔给前端
    if chosen_key not in models:
        err_msg = _model_load_errors.get(chosen_key, "未知加载错误")
        return {
            chosen_key: {
                'error': f"模型 {chosen_key} 加载失败！报错信息：<br><pre style='font-size:12px; text-align:left; color:#ffcccc; margin-top:10px; white-space: pre-wrap; word-wrap: break-word;'>{err_msg}</pre>", 
                'variant_type': variant_type, 
                'model_used': chosen_key
            }
        }, None

    raw_feats = extract_features(pred_data, all_transcripts, is_splice=(variant_type == 'splice'))
    result = _run_one_model(chosen_key, models[chosen_key], raw_feats, skip_shap=skip_shap)
    result['variant_type'] = variant_type
    result['model_used'] = chosen_key

    return {chosen_key: result}, None