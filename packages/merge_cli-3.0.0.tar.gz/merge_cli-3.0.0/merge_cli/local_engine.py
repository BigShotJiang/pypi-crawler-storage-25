"""
merge_cli/local_engine.py  —  v3.0.0

本地预测引擎变更：
  1. 集成模型 pkl 文件直接内嵌在包内（通过 importlib.resources 访问），
     pip install 时自动下载，无需再从服务器下载。
  2. Evo2 改为使用官方预构建 Docker 镜像（fanglab/merge-evo2:latest），
     与 HyenaDNA 完全一致的自动拉取 + 启动流程，无需用户手动构建。
  3. 新增 detect_gpu() 函数：自动检测 NVIDIA GPU，
     local setup / doctor 命令据此给出本地 vs 远程模式建议。

Evo2 容器信息：
  镜像：fanglab/merge-evo2:latest
  端口：8082
  监听端点：POST /predict
  接受 JSON：{chrom, pos, ref, alt, genome}
  返回 JSON：{llr_score, ref_score, var_score, interpretation}
"""
from __future__ import annotations

import importlib.resources
import importlib.util
import logging
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import requests

from .config import get_local_config

logger = logging.getLogger(__name__)


# ─── GPU 检测 ─────────────────────────────────────────────────
def detect_gpu() -> dict:
    """
    检测本机 GPU 情况。
    返回：
      {
        "has_gpu": bool,
        "gpus": [str, ...],   # GPU 名称列表
        "vram_gb": [float, ...],  # 对应显存（GB）
        "recommendation": "local" | "remote"
      }
    """
    gpus, vram = [], []

    # 方法 1：nvidia-smi（最可靠）
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=name,memory.total",
                 "--format=csv,noheader,nounits"],
                timeout=5, text=True,
            ).strip()
            for line in out.splitlines():
                if "," in line:
                    name, mem = line.rsplit(",", 1)
                    gpus.append(name.strip())
                    try:
                        vram.append(round(float(mem.strip()) / 1024, 1))
                    except ValueError:
                        vram.append(None)
        except Exception:
            pass

    # 方法 2：PyTorch（如已安装）
    if not gpus:
        try:
            import torch
            if torch.cuda.is_available():
                for i in range(torch.cuda.device_count()):
                    gpus.append(torch.cuda.get_device_name(i))
                    props = torch.cuda.get_device_properties(i)
                    vram.append(round(props.total_memory / 1073741824, 1))
        except Exception:
            pass

    has_gpu = bool(gpus)
    recommendation = "local" if has_gpu else "remote"
    return {
        "has_gpu": has_gpu,
        "gpus": gpus,
        "vram_gb": vram,
        "recommendation": recommendation,
    }


# ─── 内嵌模型路径 ─────────────────────────────────────────────
_BUNDLED_MODELS = {
    "ClinVar":                 "BestModel_Clinvar.pkl",
    "NonCoding_ClinVar":       "BestModel_Clinvar-noncoding.pkl",
    "Splice_ClinVar_GnomAD":   "BestModel_Splice_Unsupervised Only.pkl",
    "ensemble_predict":        "ensemble_predict.py",
}


def get_bundled_model_path(filename: str) -> Path:
    """
    返回内嵌在包内的模型文件路径（pip install 后自动存在）。
    优先顺序：
      1. 用户自定义 model_dir（兼容旧版手动下载）
      2. 包内 data/models/ 目录
    """
    # 1. 用户自定义目录优先
    cfg = get_local_config()
    user_path = Path(cfg["model_dir"]) / filename
    if user_path.exists():
        return user_path

    # 2. 包内内嵌模型
    try:
        pkg_data = importlib.resources.files("merge_cli") / "data" / "models" / filename
        if pkg_data.is_file():
            return Path(str(pkg_data))
    except Exception:
        pass

    raise FileNotFoundError(
        f"模型文件未找到：{filename}\n"
        f"请确认 pip install merge-cli 已正常完成，"
        f"或手动放置文件到：{cfg['model_dir']}"
    )


def _cfg() -> dict:
    return get_local_config()


def _safe_float(val) -> Optional[float]:
    try:
        if val in (None, ".", "N/A", "", "NA", "-"):
            return None
        return float(val)
    except (TypeError, ValueError):
        return None


def _check_file(path: str, label: str, hint: str = "") -> None:
    if not os.path.exists(path):
        msg = f"{label} 文件未找到：{path}"
        if hint:
            msg += f"\n提示：{hint}"
        raise FileNotFoundError(msg)


# ─── 1. dbNSFP 本地查询 ───────────────────────────────────────
_DBNSFP_COLS = {
    "chr": 0, "pos(1-based)": 1, "ref": 2, "alt": 3,
    "aaref": 4, "aaalt": 5, "rs_dbSNP": 6,
    "hg19_chr": 7, "hg19_pos(1-based)": 8, "aapos": 11,
    "genename": 12, "Ensembl_geneid": 13, "Ensembl_transcriptid": 14,
    "Ensembl_proteinid": 15, "Uniprot_acc": 16,
    "HGVSc_snpEff": 18, "HGVSp_snpEff": 19, "HGVSc_VEP": 20, "HGVSp_VEP": 21,
    "APPRIS": 22, "VEP_canonical": 25, "MANE": 26, "cds_strand": 27,
    "clinvar_id": 36, "clinvar_clnsig": 37, "clinvar_trait": 38,
    "clinvar_review": 39, "clinvar_hgvs": 40,
    "ESM1b_score": 129, "AlphaMissense_score": 132,
}


def query_dbnsfp_local(chrom, pos, ref, alt, genome="hg38") -> dict:
    try:
        import pysam
    except ImportError:
        raise ImportError("缺少依赖：pip install pysam")
    cfg = _cfg()
    build = "grch37" if genome == "hg19" else "grch38"
    fpath = os.path.join(cfg["data_dir"], f"dbNSFP5.3a_{build}.gz")
    _check_file(fpath, "dbNSFP", "请访问 https://www.dbnsfp.org/ 下载并放入数据目录")
    chrom_q = chrom.lstrip("chr") if genome == "hg19" else chrom
    annotations, dl_models_list = [], []
    try:
        tbx = pysam.TabixFile(fpath)
        for row in tbx.fetch(chrom_q, pos - 1, pos):
            fields = row.split("\t")
            row_ref = fields[_DBNSFP_COLS["ref"]] if len(fields) > 2 else ""
            row_alt = fields[_DBNSFP_COLS["alt"]] if len(fields) > 3 else ""
            if row_ref != ref or row_alt != alt:
                continue

            def _get(col):
                idx = _DBNSFP_COLS.get(col, -1)
                return fields[idx] if 0 <= idx < len(fields) else "."

            ann = {k: _get(k) for k in _DBNSFP_COLS
                   if k not in ("ESM1b_score", "AlphaMissense_score")}
            annotations.append(ann)
            dl_models_list.append({
                "ESM1b":             {"score": _safe_float(_get("ESM1b_score"))},
                "AlphaMissense":     {"score": _safe_float(_get("AlphaMissense_score"))},
                "Ensembl_transcriptid": _get("Ensembl_transcriptid"),
                "HGVSc_VEP": _get("HGVSc_VEP"),
                "HGVSp_VEP": _get("HGVSp_VEP"),
                "VEP_canonical": _get("VEP_canonical"),
                "MANE": _get("MANE"),
            })
    except Exception as exc:
        logger.error(f"[local/dbnsfp] 查询失败：{exc}", exc_info=True)
        return {"error": str(exc), "annotations": [], "dl_models": []}
    return {
        "annotations": annotations, "dl_models": dl_models_list,
        "transcripts": dl_models_list,
        "clinvar_clnsig": (annotations[0].get("clinvar_clnsig", ".") if annotations else "."),
    }


# ─── 2. GPN-MSA ───────────────────────────────────────────────
def query_gpn_msa_local(chrom, pos, ref, alt) -> dict:
    try:
        import pysam
    except ImportError:
        raise ImportError("缺少依赖：pip install pysam")
    fpath = os.path.join(_cfg()["data_dir"], "scores.tsv.bgz")
    _check_file(
        fpath, "GPN-MSA",
        "请访问 https://huggingface.co/datasets/songlab/gpn-msa-hg38-scores/tree/main 下载"
    )
    try:
        tbx = pysam.TabixFile(fpath)
        chrom_q = chrom.lstrip("chr")
        for row in tbx.fetch(chrom_q, pos - 1, pos):
            fields = row.split("\t")
            if len(fields) >= 5 and fields[2] == ref and fields[3] == alt:
                return {"score": _safe_float(fields[4])}
    except Exception as exc:
        logger.error(f"[local/gpn-msa] 查询失败：{exc}", exc_info=True)
        return {"score": None, "error": str(exc)}
    return {"score": None}


# ─── 3. popEVE ────────────────────────────────────────────────
def query_popeve_local(chrom, pos, ref, alt) -> dict:
    try:
        import pysam
    except ImportError:
        raise ImportError("缺少依赖：pip install pysam")
    fpath = os.path.join(_cfg()["data_dir"], "grch38_popEVE_ukbb_20250715.vcf.gz")
    _check_file(fpath, "popEVE", "请访问 https://pop.evemodel.org/ 下载")
    try:
        tbx = pysam.TabixFile(fpath)
        for row in tbx.fetch(chrom, pos - 1, pos):
            fields = row.split("\t")
            if len(fields) < 8:
                continue
            if fields[3] != ref or fields[4] != alt:
                continue
            for token in fields[7].split(";"):
                if token.startswith("popEVE="):
                    return {"score": _safe_float(token.split("=", 1)[1])}
    except Exception as exc:
        logger.error(f"[local/popeve] 查询失败：{exc}", exc_info=True)
        return {"score": None, "error": str(exc)}
    return {"score": None}


# ─── 4. Docker 容器 API 调用 ─────────────────────────────────
# HyenaDNA 和 Evo2 均使用预构建 Docker 镜像，无需手动构建。
# NT 不走 Docker，直接本地调用。

_DOCKER_CONTAINERS = {
    "hyenadna": {
        "image":      "hyenadna/hyena-dna:latest",
        "port":       "5001:5001",
        "name":       "merge-hyenadna",
        "url_key":    "hyenadna_url",
        "gpu_args":   ["--gpus", "all"],
        "extra_args": [],
    },
    "evo2": {
        # v3.0.0：使用官方预构建镜像，与 HyenaDNA 流程完全一致
        "image":      "fanglab/merge-evo2:latest",
        "port":       "8082:8082",
        "name":       "merge-evo2",
        "url_key":    "evo2_url",
        "gpu_args":   ["--gpus", "all"],
        "extra_args": [],
    },
}


def call_docker_model(model_name: str, chrom, pos, ref, alt,
                      genome="hg38", timeout=120) -> dict:
    """调用本地 Docker 容器的预测 API。"""
    cfg = _cfg()
    container = _DOCKER_CONTAINERS.get(model_name)
    if not container:
        return {"error": f"未知模型：{model_name}"}
    base_url = cfg.get(container["url_key"], "")
    if not base_url:
        return {"error": f"{model_name} 地址未配置，请运行 merge local setup"}
    payload = {"chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "genome": genome}
    try:
        resp = requests.post(
            f"{base_url}/predict", json=payload, timeout=timeout
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        return {
            "error": (
                f"{model_name} 容器未运行或无法连接 {base_url}。\n"
                f"请先执行：merge local docker start --model {model_name}"
            )
        }
    except requests.exceptions.Timeout:
        return {"error": f"{model_name} 请求超时（>{timeout}s），容器可能正在加载模型"}
    except Exception as exc:
        return {"error": f"{model_name} 调用失败：{exc}"}


def call_nt_local(chrom, pos, ref, alt, genome="hg38", timeout=180) -> dict:
    """NT（Nucleotide Transformer）直接本地调用，无需 Docker。"""
    nt_url = _cfg().get("nt_url", "http://localhost:5002")
    try:
        resp = requests.post(
            f"{nt_url}/predict",
            json={"chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "genome": genome},
            timeout=timeout,
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        pass
    except Exception as exc:
        return {"error": f"NT 服务调用失败：{exc}"}

    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        MODEL_NAME = "InstaDeepAI/nucleotide-transformer-500m-human-ref"
        logger.info("[local/nt] 加载 NT 模型（首次加载需下载）…")
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
        device    = "cuda" if torch.cuda.is_available() else "cpu"
        model_nt  = AutoModelForCausalLM.from_pretrained(MODEL_NAME).to(device)
        model_nt.eval()
        return {"score": None, "error": "NT 本地直接调用尚未集成，请启动 NT 本地服务"}
    except ImportError:
        return {"error": "NT 本地调用失败：缺少依赖，请运行 pip install transformers torch"}
    except Exception as exc:
        return {"error": f"NT 本地调用失败：{exc}"}


# ─── 5. 集成模型（内嵌 pkl）──────────────────────────────────
_ep_module_cache: dict = {}


def _load_ep_module():
    """
    加载 ensemble_predict.py 模块。
    v3.0.0：优先使用包内内嵌版本（pip install 时随包下载）。
    """
    cache_key = "bundled"
    if cache_key in _ep_module_cache:
        return _ep_module_cache[cache_key]

    ep_path = str(get_bundled_model_path("ensemble_predict.py"))
    model_dir = str(Path(ep_path).parent)

    if model_dir not in sys.path:
        sys.path.insert(0, model_dir)

    spec = importlib.util.spec_from_file_location("ep_local", ep_path)
    ep   = importlib.util.module_from_spec(spec)
    ep.__file__ = ep_path
    spec.loader.exec_module(ep)
    _ep_module_cache[cache_key] = ep
    return ep


def run_local_ensemble(pred_data, all_transcripts, ensemble_type=None):
    ep = _load_ep_module()
    if ensemble_type:
        type_to_model = {
            "coding":    "ClinVar",
            "noncoding": "NonCoding_ClinVar",
            "splice":    "Splice_ClinVar_GnomAD",
        }
        chosen_key = type_to_model[ensemble_type]
        models = ep.load_models()
        if chosen_key not in models:
            err = ep._model_load_errors.get(chosen_key, "未知错误")
            return (
                {chosen_key: {
                    "error": f"模型 {chosen_key} 加载失败：{err}",
                    "variant_type": ensemble_type,
                    "model_used": chosen_key,
                }},
                err,
            )
        raw_feats = ep.extract_features(
            pred_data, all_transcripts, is_splice=(ensemble_type == "splice")
        )
        result = ep._run_one_model(chosen_key, models[chosen_key], raw_feats)
        result["variant_type"] = ensemble_type
        result["model_used"]   = chosen_key
        return {chosen_key: result}, None
    else:
        return ep.run_ensemble(pred_data, all_transcripts)


# ─── 6. 顶层预测入口 ──────────────────────────────────────────
def predict_local(chrom, pos, ref, alt, genome="hg38",
                  use_alphagenome=True, use_hyenadna=True, use_nt=True,
                  use_alphamissense=True, use_esm1b=True,
                  use_gpn_msa=True, use_popeve=True, use_evo2=True) -> dict:
    errors: dict = {}
    tasks:  dict = {}

    tasks["dbnsfp"] = lambda: query_dbnsfp_local(chrom, pos, ref, alt, genome)
    if use_gpn_msa:
        tasks["gpn_msa"] = lambda: query_gpn_msa_local(chrom, pos, ref, alt)
    if use_popeve:
        tasks["popeve"] = lambda: query_popeve_local(chrom, pos, ref, alt)
    if use_hyenadna:
        tasks["hyenadna"] = lambda: call_docker_model("hyenadna", chrom, pos, ref, alt, genome)
    if use_nt:
        tasks["nt"] = lambda: call_nt_local(chrom, pos, ref, alt, genome)
    if use_evo2:
        tasks["evo2"] = lambda: call_docker_model("evo2", chrom, pos, ref, alt, genome)
    if use_alphagenome:
        tasks["alphagenome"] = lambda: _call_alphagenome_remote(chrom, pos, ref, alt, genome)

    results: dict = {}
    with ThreadPoolExecutor(max_workers=6) as executor:
        future_map = {executor.submit(fn): key for key, fn in tasks.items()}
        for future in as_completed(future_map):
            key = future_map[future]
            try:
                results[key] = future.result()
            except Exception as exc:
                logger.warning(f"[local/{key}] 异常：{exc}")
                results[key] = {"error": str(exc)}
                errors[key]  = str(exc)

    prediction = {
        "input": {"chrom": chrom, "pos": pos, "ref": ref, "alt": alt},
        "genome_version": genome, "errors": errors, **results,
    }
    return {"success": True, "prediction": prediction}


def _call_alphagenome_remote(chrom, pos, ref, alt, genome) -> dict:
    api_url = os.environ.get("ALPHAGENOME_API_URL", "")
    api_key = os.environ.get("ALPHAGENOME_API_KEY", "")
    if not api_url or not api_key:
        return {"statistics": None, "error": "未配置 AlphaGenome API"}
    try:
        resp = requests.post(
            f"{api_url}/predict",
            json={"chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "genome": genome},
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=int(os.environ.get("ALPHAGENOME_TIMEOUT", "120")),
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:
        return {"statistics": None, "error": str(exc)}


# ─── 7. Docker 管理（pull / start / stop / restart / status）──
def docker_pull(model_name: str, console=None) -> bool:
    """拉取 Docker 镜像（HyenaDNA 和 Evo2 均使用预构建镜像）。"""
    container = _DOCKER_CONTAINERS.get(model_name)
    if not container:
        return False
    image = container["image"]
    if console:
        console.print(f"[cyan]▼ 拉取 {model_name} 镜像：{image}[/cyan]")
    try:
        subprocess.run(["docker", "pull", image], check=True)
        if console:
            console.print(f"[green]✓ {model_name} 镜像拉取完成[/green]")
        return True
    except subprocess.CalledProcessError as e:
        if console:
            console.print(f"[red]✗ {model_name} 拉取失败：{e}[/red]")
        return False


def docker_start(model_name: str, console=None) -> bool:
    """启动 Docker 容器。"""
    container = _DOCKER_CONTAINERS.get(model_name)
    if not container:
        return False
    cfg = _cfg()
    name = container["name"]
    # 检查是否已运行
    try:
        check = subprocess.run(
            ["docker", "ps", "-q", "--filter", f"name={name}"],
            capture_output=True, text=True, check=True,
        )
        if check.stdout.strip():
            if console:
                console.print(f"[yellow]⚠ {model_name} 已在运行，跳过[/yellow]")
            return True
    except Exception:
        return False

    run_cmd = (
        ["docker", "run", "-d", "--rm", "--name", name]
        + container["gpu_args"]
        + container["extra_args"]
        + ["-p", container["port"], container["image"]]
    )
    try:
        subprocess.run(run_cmd, check=True)
        if console:
            console.print(f"  [dim]等待 {model_name} 就绪…[/dim]", end="")
        health_url = cfg.get(container["url_key"], "")
        _wait_for_health(health_url, timeout=120)
        if console:
            console.print(f"\r[green]✓ {model_name} 已启动并就绪[/green]          ")
        return True
    except subprocess.CalledProcessError as e:
        if console:
            console.print(f"[red]✗ {model_name} 启动失败：{e}[/red]")
        return False
    except TimeoutError:
        if console:
            console.print(f"\n[yellow]⚠ {model_name} 启动成功，但健康检查超时（模型权重仍在加载）[/yellow]")
        return True


def _wait_for_health(base_url: str, timeout: int = 120) -> None:
    import requests as _req
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = _req.get(f"{base_url}/health", timeout=3)
            if r.status_code == 200:
                return
        except Exception:
            pass
        time.sleep(2)
    raise TimeoutError(f"容器 {base_url} 健康检查超时")


# ─── 8. Docker 健康检查 ────────────────────────────────────────
def check_docker_health(model_name: str) -> dict:
    cfg = _cfg()
    container = _DOCKER_CONTAINERS.get(model_name)
    if not container:
        return {"online": False, "error": f"未知模型：{model_name}"}
    base_url = cfg.get(container["url_key"], "")
    try:
        t0 = time.time()
        resp = requests.get(f"{base_url}/health", timeout=5)
        lat  = (time.time() - t0) * 1000
        if resp.status_code == 200:
            return {"online": True, "latency_ms": round(lat, 1)}
        return {"online": False, "latency_ms": round(lat, 1), "error": f"HTTP {resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return {"online": False, "error": "容器未运行"}
    except Exception as exc:
        return {"online": False, "error": str(exc)}


# ─── 9. 文件检查（含内嵌模型）────────────────────────────────
def check_local_files() -> dict:
    cfg = _cfg()
    data_dir = cfg["data_dir"]

    files: dict = {
        "dbNSFP (hg38)": os.path.join(data_dir, "dbNSFP5.3a_grch38.gz"),
        "dbNSFP (hg19)": os.path.join(data_dir, "dbNSFP5.3a_grch37.gz"),
        "GPN-MSA":       os.path.join(data_dir, "scores.tsv.bgz"),
        "popEVE":        os.path.join(data_dir, "grch38_popEVE_ukbb_20250715.vcf.gz"),
    }

    result = {}
    for label, path in files.items():
        exists = os.path.exists(path)
        size_gb = None
        if exists:
            try:
                size_gb = round(os.path.getsize(path) / 1e9, 2)
            except OSError:
                pass
        result[label] = {"exists": exists, "path": path, "size_gb": size_gb}

    # 内嵌集成模型文件（pip install 随包附带）
    for key, fname in _BUNDLED_MODELS.items():
        label = f"集成模型（{fname}）"
        try:
            path = str(get_bundled_model_path(fname))
            exists = os.path.exists(path)
            size_gb = round(os.path.getsize(path) / 1e9, 4) if exists else None
            result[label] = {"exists": exists, "path": path,
                             "size_gb": size_gb, "bundled": True}
        except FileNotFoundError:
            result[label] = {"exists": False, "path": "(内嵌包)",
                             "size_gb": None, "bundled": True}

    return result
