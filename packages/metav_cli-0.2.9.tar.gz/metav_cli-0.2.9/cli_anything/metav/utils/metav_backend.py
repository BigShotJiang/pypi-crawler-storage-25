"""MetaV backend API client.

This module handles all HTTP API calls to the MetaV server.
"""

import base64
import json
import os
import sys
from typing import Any, Dict, List, Optional

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from .env import DEFAULT_BASE_URL, get_metav_authkey, get_metav_base_url

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


def rsa_encrypt(password: str, public_key: str, salt: str = "") -> str:
    """Encrypt password using RSA public key.

    Flow:
    1. SHA256 hash the password
    2. Concatenate salt + sha256hex(password)
    3. RSA encrypt with PKCS1v15 padding
    """
    try:
        import hashlib
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.backends import default_backend
    except ImportError:
        print("[WARNING] cryptography not installed, using fallback", file=sys.stderr)
        return password

    try:
        # Decode the public key from base64
        key_bytes = base64.b64decode(public_key)
        public_key_obj = serialization.load_der_public_key(key_bytes, backend=default_backend())

        # Step 1: SHA256 hash the password
        sha256_password = hashlib.sha256(password.encode('utf-8')).hexdigest()

        # Step 2: Concatenate salt + sha256hex(password)
        salted_password = salt + sha256_password

        # Step 3: RSA encrypt with PKCS1v15 padding
        encrypted = public_key_obj.encrypt(
            salted_password.encode('utf-8'),
            padding.PKCS1v15()
        )
        # Return base64 encoded encrypted password
        return base64.b64encode(encrypted).decode('utf-8')
    except Exception as e:
        raise MetaVError(f"RSA encryption failed: {e}")


class MetaVBackend:
    """Backend API client for MetaV server."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        authkey: Optional[str] = None,
        session_file: Optional[str] = None,
    ):
        self.base_url = (base_url or get_metav_base_url()).rstrip("/")
        self.authkey = authkey or get_metav_authkey()
        self.session_file = session_file or os.path.expanduser("~/.metav_session.json")
        self._token: Optional[str] = None
        self._user_info: Optional[Dict] = None
        # Load session from file if exists
        self._load_session()

    def _get_headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.authkey:
            headers["authkey"] = self.authkey
        if self._token:
            headers["mtoken"] = self._token
        return headers

    def _request(
        self,
        method: str,
        path: str,
        data: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Make HTTP request to MetaV API."""
        url = f"{self.base_url}{path}"
        try:
            if method.upper() == "GET":
                resp = requests.get(
                    url,
                    headers=self._get_headers(),
                    params=params,
                    timeout=30,
                    verify=False,
                )
            else:
                resp = requests.post(
                    url,
                    headers=self._get_headers(),
                    json=data,
                    params=params,
                    timeout=30,
                    verify=False,
                )
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.ConnectionError:
            raise MetaVError(f"Cannot connect to MetaV server at {self.base_url}. Is the server running?")
        except requests.exceptions.Timeout:
            raise MetaVError(f"Request to {url} timed out.")
        except requests.exceptions.HTTPError as e:
            try:
                error_body = e.response.json()
                msg = error_body.get("msg", str(e))
            except Exception:
                msg = str(e)
            raise MetaVError(f"HTTP {e.response.status_code}: {msg}")

    def _check_response(self, body: Dict) -> Any:
        """Check API response and extract data."""
        code = body.get("code")
        if code is not None and code != 200:
            msg = body.get("msg", "Unknown error")
            raise MetaVError(f"API error {code}: {msg}")
        return body.get("data", body)

    def get_rsa_public_key(self) -> str:
        """Get RSA public key from server for password encryption."""
        result = self._request("GET", "/auth/rsa/publicKey")
        data = self._check_response(result)
        if isinstance(data, dict):
            return data.get("data", "")
        return str(data)

    def get_rsa_salt(self) -> str:
        """Get RSA salt from server for password encryption."""
        result = self._request("GET", "/auth/rsa/salt")
        data = self._check_response(result)
        if isinstance(data, dict):
            return data.get("data", "")
        return str(data)

    # Authentication
    def login(self, username: str, password: str) -> Dict[str, Any]:
        """Login to MetaV with encrypted password."""
        # Get RSA public key and salt, then encrypt password
        try:
            public_key = self.get_rsa_public_key()
            salt = self.get_rsa_salt()
            encrypted_password = rsa_encrypt(password, public_key, salt)
        except MetaVError as e:
            print(f"[WARNING] RSA encryption failed, using plain password: {e}", file=sys.stderr)
            encrypted_password = password

        result = self._request(
            "POST",
            "/login/login",
            data={"username": username, "password": encrypted_password},
        )
        data = self._check_response(result)
        self._token = data.get("token")
        self._user_info = data.get("userInfo", {})
        self._save_session()
        return data

    def get_current_user(self) -> Dict[str, Any]:
        """Get current user info."""
        result = self._request("GET", "/login/user")
        return self._check_response(result)

    def logout(self) -> None:
        """Logout and clear session."""
        try:
            self._request("GET", "/login/logout")
        except Exception:
            pass
        self._token = None
        self._user_info = None
        self._clear_session()

    # Session management
    def _save_session(self) -> None:
        """Save session to file."""
        session_data = {
            "base_url": self.base_url,
            "authkey": self.authkey,
            "token": self._token,
            "user_info": self._user_info,
        }
        os.makedirs(os.path.dirname(self.session_file), exist_ok=True)
        with open(self.session_file, "w", encoding="utf-8") as f:
            json.dump(session_data, f, ensure_ascii=False)

    def _load_session(self) -> bool:
        """Load session from file. Returns True if session exists."""
        if not os.path.exists(self.session_file):
            return False
        try:
            with open(self.session_file, "r", encoding="utf-8") as f:
                session_data = json.load(f)
            # Only use session values if they are not None
            loaded_base_url = session_data.get("base_url")
            if loaded_base_url:
                self.base_url = loaded_base_url
            loaded_authkey = session_data.get("authkey")
            if loaded_authkey:
                self.authkey = loaded_authkey
            self._token = session_data.get("token")
            self._user_info = session_data.get("user_info")
            return bool(self._token or self.authkey)
        except (json.JSONDecodeError, IOError):
            return False

    def _clear_session(self) -> None:
        """Clear session file."""
        if os.path.exists(self.session_file):
            os.remove(self.session_file)

    def load_session(self) -> bool:
        """Load existing session or authkey from environment/file."""
        return self._load_session() or bool(self.authkey)

    # App operations
    def list_apps(
        self,
        page: int = 1,
        page_size: int = 20,
        keyword: Optional[str] = None,
        app_group_type: str = "all",
    ) -> List[Dict[str, Any]]:
        """List applications."""
        params = {
            "pageNumber": page,
            "pageSize": page_size,
            "appGroupType": app_group_type,
            "name": keyword or "",
            "sort": "create_time",
            "appGroup": "all",
        }
        result = self._request("GET", "/app/list", params=params)
        data = self._check_response(result)
        if isinstance(data, dict):
            # Handle pager format: data.pager.data
            pager = data.get("pager", {})
            if pager:
                return pager.get("data", [])
            # Handle list/records format
            return data.get("list", data.get("records", []))
        return data if isinstance(data, list) else []

    def get_app(self, app_id: str) -> Dict[str, Any]:
        """Get application details."""
        result = self._request("GET", f"/app/{app_id}")
        return self._check_response(result)

    def create_app(self, name: str, remark: str = "") -> Dict[str, Any]:
        """Create a new application."""
        result = self._request(
            "POST",
            "/app/add",
            data={"name": name, "remark": remark},
        )
        return self._check_response(result)

    def update_app(self, app_id: str, name: str, remark: str = "") -> Dict[str, Any]:
        """Update an application."""
        result = self._request(
            "POST",
            "/app/edit",
            data={"id": app_id, "name": name, "remark": remark},
        )
        return self._check_response(result)

    def delete_app(self, app_id: str) -> Dict[str, Any]:
        """Delete an application."""
        result = self._request("POST", "/app/delete", data={"id": app_id})
        return self._check_response(result)

    def export_app(self, app_id: str) -> bytes:
        """Export application as ZIP bytes."""
        url = f"{self.base_url}/app/export"
        resp = requests.get(
            url,
            headers=self._get_headers(),
            params={"appId": app_id},
            timeout=60,
            verify=False,
        )
        resp.raise_for_status()
        return resp.content

    def import_app(self, file_path: str) -> Dict[str, Any]:
        """Import application from ZIP file."""
        url = f"{self.base_url}/app/import"
        with open(file_path, "rb") as f:
            files = {"file": (os.path.basename(file_path), f, "application/zip")}
            data = {"id": ""}
            resp = requests.post(
                url,
                data=data,
                files=files,
                headers={"authkey": self.authkey} if self.authkey else {},
                timeout=60,
                verify=False,
            )
        resp.raise_for_status()
        return resp.json()

    def copy_app(self, app_id: str, new_name: str) -> Dict[str, Any]:
        """Copy an application."""
        result = self._request(
            "POST",
            "/app/copy",
            data={"id": app_id, "name": new_name},
        )
        return self._check_response(result)

    def release_app(self, app_id: str) -> Dict[str, Any]:
        """Release/publish an application."""
        result = self._request("POST", "/app/release", data={"id": app_id})
        return self._check_response(result)

    # Page operations
    def list_pages(self, app_id: str) -> List[Dict[str, Any]]:
        """List pages in an application."""
        result = self._request("GET", "/page/list", params={"appId": app_id})
        data = self._check_response(result)
        return data if isinstance(data, list) else []

    def get_page(self, page_id: str) -> Dict[str, Any]:
        """Get page details."""
        result = self._request("GET", f"/page/{page_id}")
        return self._check_response(result)

    def create_page(self, app_id: str, name: str) -> Dict[str, Any]:
        """Create a new page."""
        result = self._request(
            "POST",
            "/page/add",
            data={"appId": app_id, "name": name},
        )
        return self._check_response(result)

    def update_page(self, page_id: str, name: str, content: Optional[Dict] = None) -> Dict[str, Any]:
        """Update a page."""
        data = {"id": page_id, "name": name}
        if content:
            data["pageContent"] = json.dumps(content) if isinstance(content, dict) else content
        result = self._request("POST", "/page/edit", data=data)
        return self._check_response(result)

    def delete_page(self, page_id: str) -> Dict[str, Any]:
        """Delete a page."""
        result = self._request("POST", "/page/delete", data={"id": page_id})
        return self._check_response(result)

    def copy_page(self, page_id: str, new_name: str) -> Dict[str, Any]:
        """Copy a page."""
        result = self._request(
            "POST",
            "/page/copy",
            data={"id": page_id, "name": new_name},
        )
        return self._check_response(result)

    # DataSource operations
    def list_datasources(
        self,
        page: int = 1,
        page_size: int = 20,
        keyword: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List data sources."""
        params = {"page": page, "pageSize": page_size}
        if keyword:
            params["keyword"] = keyword
        result = self._request("GET", "/dataSource/list", params=params)
        data = self._check_response(result)
        if isinstance(data, dict):
            return data.get("list", data.get("records", []))
        return data if isinstance(data, list) else []

    def list_all_datasources(self) -> List[Dict[str, Any]]:
        """List all data sources without pagination."""
        result = self._request("GET", "/dataSource/listAll")
        data = self._check_response(result)
        return data if isinstance(data, list) else []

    def get_datasource(self, datasource_id: str) -> Dict[str, Any]:
        """Get data source details."""
        result = self._request("GET", f"/dataSource/{datasource_id}")
        return self._check_response(result)

    def create_datasource(
        self,
        name: str,
        source_type: str,
        config: Dict[str, Any],
        page_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new data source.

        Args:
            name: Data source name
            source_type: "static", "restful", or "websocket"
            config: Data source configuration
            page_id: Optional page ID to associate with
        """
        data = {
            "name": name,
            "sourceType": source_type,
            "config": json.dumps(config) if isinstance(config, dict) else config,
        }
        if page_id:
            data["pageId"] = page_id
        result = self._request("POST", "/dataSource/add", data=data)
        return self._check_response(result)

    def update_datasource(
        self,
        datasource_id: str,
        name: str,
        source_type: str,
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update a data source."""
        data = {
            "id": datasource_id,
            "name": name,
            "sourceType": source_type,
            "config": json.dumps(config) if isinstance(config, dict) else config,
        }
        result = self._request("POST", "/dataSource/edit", data=data)
        return self._check_response(result)

    def delete_datasource(self, datasource_id: str) -> Dict[str, Any]:
        """Delete a data source."""
        result = self._request("POST", "/dataSource/delete", data={"id": datasource_id})
        return self._check_response(result)

    # Dashboard operations
    def create_dashboard(
        self,
        app_name: str,
        page_name: str,
        page_schema: Dict[str, Any],
        remark: str = "",
    ) -> Dict[str, Any]:
        """Create a dashboard application with full page schema.

        Args:
            app_name: Application name
            page_name: Page name
            page_schema: Complete page schema JSON
            remark: Optional remark
        """
        result = self._request(
            "POST",
            "/dashboard/create",
            data={
                "appName": app_name,
                "pageName": page_name,
                "remark": remark,
                "pageSchema": page_schema,
            },
        )
        return self._check_response(result)

    def list_components(self) -> List[Dict[str, Any]]:
        """List available components."""
        result = self._request("GET", "/dashboard/components")
        return self._check_response(result)

    def list_dashboard_templates(self, name: Optional[str] = None) -> List[Dict[str, Any]]:
        """List available templates for dashboard creation."""
        params: Dict[str, Any] = {}
        if name:
            params["name"] = name
        result = self._request("GET", "/dashboard/templates", params=params)
        data = self._check_response(result)
        return data if isinstance(data, list) else []

    def create_dashboard_from_template(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Create dashboard application from template payload."""
        result = self._request("POST", "/dashboard/template/create", data=payload)
        return self._check_response(result)


class MetaVError(Exception):
    """MetaV API error."""

    pass


# Backend instance cache
_backend: Optional[MetaVBackend] = None


def get_backend(
    base_url: Optional[str] = None,
    authkey: Optional[str] = None,
) -> MetaVBackend:
    """Get or create a backend instance."""
    global _backend
    if _backend is None:
        # Ensure base_url has a default value
        if base_url is None:
            base_url = get_metav_base_url()
        _backend = MetaVBackend(base_url=base_url, authkey=authkey)
    return _backend


def reset_backend() -> None:
    """Reset backend instance (for testing)."""
    global _backend
    _backend = None
