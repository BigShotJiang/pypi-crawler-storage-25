"""Environment variable helpers for MetaV CLI."""

import os

METAV_BASE_URL_ENV = "METAV_BASE_URL"
METAV_AUTHKEY_ENV = "METAV_AUTHKEY"
DEFAULT_BASE_URL = "http://localhost:3066/metav"
# DEFAULT_BASE_URL = "https://metav.xuelangyun.com/metav"


def get_metav_base_url(default: str = DEFAULT_BASE_URL) -> str:
    return os.getenv(METAV_BASE_URL_ENV, default)


def get_metav_authkey(default: str = "") -> str:
    return os.getenv(METAV_AUTHKEY_ENV, default)


def get_env_display_value(name: str) -> str:
    return os.getenv(name, "")

