"""Dashboard operations for MetaV CLI."""

import click
import json
import os
from typing import Optional

from ..utils.metav_backend import get_backend, MetaVError
from .session import get_session


def _load_json_file(file_path: str):
    """读取并解析 JSON 文件。"""
    if not os.path.exists(file_path):
        raise MetaVError(f"JSON 文件不存在: {file_path}")
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _validate_placeholder_replacements(replacements):
    """校验占位替换内容，要求每一项都是组件 schema 对象。"""
    if replacements is None:
        return
    if not isinstance(replacements, dict):
        raise MetaVError("placeholderReplacements 必须为 JSON 对象")

    for placeholder_name, schema in replacements.items():
        if not isinstance(placeholder_name, str) or not placeholder_name.strip():
            raise MetaVError("placeholderReplacements 中的占位名称不能为空")
        if not isinstance(schema, dict):
            raise MetaVError(f"占位[{placeholder_name}]替换内容必须为 JSON 对象")
        if not schema:
            raise MetaVError(f"占位[{placeholder_name}]替换内容不能为空对象")

        has_component = isinstance(schema.get("component"), str) and bool(schema.get("component").strip())
        has_children = "children" in schema
        has_slots = "slots" in schema
        if not (has_component or has_children or has_slots):
            raise MetaVError(f"占位[{placeholder_name}]替换内容必须至少包含 component/children/slots 之一")

        if "component" in schema and not has_component:
            raise MetaVError(f"占位[{placeholder_name}]的component不能为空")
        if has_children and not isinstance(schema.get("children"), list):
            raise MetaVError(f"占位[{placeholder_name}]的children必须为数组")
        if has_slots and not isinstance(schema.get("slots"), dict):
            raise MetaVError(f"占位[{placeholder_name}]的slots必须为对象")


@click.group(name="dashboard")
def dashboard_group():
    """Dashboard operations."""
    pass


@dashboard_group.command(name="create")
@click.option("--app-name", "-a", required=True, help="Application name")
@click.option("--page-name", "-p", default="首页", help="Page name")
@click.option("--schema", "-s", required=True, help="Page schema JSON file or @file:path")
@click.option("--remark", "-r", default="", help="Remark")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def create_dashboard(app_name: str, page_name: str, schema: str, remark: str, output_json: bool):
    """Create a dashboard application with full page schema.

    This is the main command for creating dashboards. It accepts a pageSchema JSON file
    and creates both the application and page in one operation.
    """
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)

    try:
        if schema.startswith("@"):
            schema_file = schema[1:]
        else:
            schema_file = schema

        if not os.path.exists(schema_file):
            try:
                page_schema = json.loads(schema)
            except json.JSONDecodeError:
                click.echo(f"[ERROR] Schema file not found and not valid JSON: {schema}", err=True)
                raise SystemExit(1)
        else:
            with open(schema_file, "r", encoding="utf-8") as f:
                page_schema = json.load(f)

        result = backend.create_dashboard(app_name, page_name, page_schema, remark)

        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            app_id = result.get("appId")
            page_id = result.get("pageId")
            share_link = result.get("shareLink")
            home_page_url = result.get("homePageUrl")

            click.echo(f"[OK] Dashboard created: {app_name}")
            click.echo(f"  App ID: {app_id}")
            click.echo(f"  Page ID: {page_id}")
            if share_link:
                click.echo(f"  Share Link: {share_link}")
            if home_page_url:
                click.echo(f"  Home Page: {home_page_url}")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="components")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_components(output_json: bool):
    """List available dashboard components."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        components = backend.list_components()

        if output_json:
            click.echo(json.dumps(components, ensure_ascii=False, indent=2))
        else:
            if not components:
                click.echo("No components found.")
                return

            def extract_components(node_list, result=None):
                if result is None:
                    result = []
                if not isinstance(node_list, list):
                    return result
                for node in node_list:
                    comp_name = node.get("componentName")
                    version = node.get("version", "1.0.0")
                    if comp_name:
                        result.append({"name": comp_name, "version": version})
                    children = node.get("children") or node.get("typeChildren", [])
                    extract_components(children, result)
                return result

            comp_list = extract_components(components)
            click.echo(f"{'Component Name':<40} {'Version':<15}")
            click.echo("-" * 57)
            for comp in comp_list:
                click.echo(f"{comp['name']:<40} {comp['version']:<15}")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="templates")
@click.option("--name", "-n", default="", help="Template name keyword")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_templates(name: str, output_json: bool):
    """List available templates (id/name/placeholders)."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        templates = backend.list_dashboard_templates(name=name.strip() or None)
        if output_json:
            click.echo(json.dumps(templates, ensure_ascii=False, indent=2))
            return

        if not templates:
            click.echo("No templates found.")
            return

        click.echo(f"{'Template ID':<34} {'Name':<24} Placeholders")
        click.echo("-" * 90)
        for item in templates:
            template_id = item.get("id", "")
            template_name = item.get("name", "")
            placeholders = item.get("placeholders") or []
            placeholder_text = ", ".join(
                [
                    f"{p.get('name')}({p.get('description')})" if p.get("description") else str(p.get("name", ""))
                    for p in placeholders
                    if p.get("name")
                ]
            )
            click.echo(f"{template_id:<34} {template_name:<24} {placeholder_text}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="template-create")
@click.option("--input", "-i", "input_file", required=True, help="Template create JSON file path")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def create_dashboard_from_template(input_file: str, output_json: bool):
    """Create dashboard from template by JSON file."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        payload = _load_json_file(input_file)
        if not isinstance(payload, dict):
            raise MetaVError("输入 JSON 顶层必须为对象")

        template_id = payload.get("templateId")
        if not isinstance(template_id, str) or not template_id.strip():
            raise MetaVError("templateId 不能为空")
        if "pageName" in payload:
            raise MetaVError("template-create 入参不支持 pageName")
        if "pagePlaceholderReplacements" in payload:
            raise MetaVError("template-create 入参不支持 pagePlaceholderReplacements，请改用 placeholderReplacements")
        _validate_placeholder_replacements(payload.get("placeholderReplacements"))
        result = backend.create_dashboard_from_template(payload)

        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
            return

        click.echo(f"[OK] Dashboard created from template: {template_id}")
        click.echo(f"  App ID: {result.get('appId', '')}")
        click.echo(f"  Page ID: {result.get('pageId', '')}")
        if result.get("homePageUrl"):
            click.echo(f"  Home Page: {result.get('homePageUrl')}")
    except (MetaVError, json.JSONDecodeError) as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="info")
@click.argument("app_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def dashboard_info(app_id: str, output_json: bool):
    """Get dashboard application details."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        app = backend.get_app(app_id)
        if output_json:
            click.echo(json.dumps(app, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Dashboard: {app.get('name', 'unknown')}")
            click.echo(f"ID: {app.get('id', '')}")
            click.echo(f"Status: {app.get('status', 'unknown')}")

            pages = backend.list_pages(app_id)
            if pages:
                click.echo(f"\nPages ({len(pages)}):")
                for page in pages:
                    click.echo(f"  - {page.get('name', 'unknown')} (ID: {page.get('id', '')})")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)
