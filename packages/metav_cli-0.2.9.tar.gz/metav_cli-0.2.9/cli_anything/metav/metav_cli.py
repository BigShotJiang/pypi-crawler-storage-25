"""MetaV CLI - Command-line interface for MetaV Visual Dashboard Platform.

Usage:
    metav [OPTIONS] COMMAND [ARGS]...

Options:
    --base-url TEXT    MetaV server base URL
    --authkey TEXT     Authentication key
    --json             Output as JSON
    --help             Show this message and exit.

Commands:
    app         Application management
    page        Page management
    datasource  Data source management
    dashboard   Dashboard operations
    auth        Authentication management
    info        Information and configuration
    repl        Interactive REPL mode
"""

import click
import os
import sys
import importlib.metadata

try:
    __version__ = importlib.metadata.version("metav-cli")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"

from .core.auth import auth_group
from .core.project import app_group, page_group, datasource_group
from .core.dashboard import dashboard_group
from .core.info import info_group
from .utils.metav_backend import get_backend


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="metav-cli")
@click.option("--base-url", help="MetaV server base URL")
@click.option("--authkey", help="Authentication key")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def cli(ctx, base_url, authkey, output_json):
    """MetaV CLI - Command-line interface for MetaV Visual Dashboard Platform."""
    ctx.ensure_object(dict)
    if base_url:
        os.environ["METAV_BASE_URL"] = base_url
    if authkey:
        os.environ["METAV_AUTHKEY"] = authkey
    ctx.obj["output_json"] = output_json

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# Register command groups
cli.add_command(auth_group)
cli.add_command(app_group)
cli.add_command(page_group)
cli.add_command(datasource_group)
cli.add_command(dashboard_group)
cli.add_command(info_group)


@cli.command(name="repl")
@click.option("--base-url", help="MetaV server base URL")
@click.option("--authkey", help="Authentication key")
def repl(base_url, authkey):
    """Interactive REPL mode for MetaV."""
    if base_url:
        os.environ["METAV_BASE_URL"] = base_url
    if authkey:
        os.environ["METAV_AUTHKEY"] = authkey

    click.echo("MetaV REPL - Interactive Mode")
    click.echo("Type 'help' for available commands, 'exit' to quit.")
    click.echo()

    while True:
        try:
            line = click.prompt("metav> ", default="", show_default=False)
        except (KeyboardInterrupt, EOFError):
            click.echo("\nExiting...")
            break

        if not line.strip():
            continue

        if line.strip() in ("exit", "quit", "q"):
            click.echo("Goodbye!")
            break

        if line.strip() == "help":
            click.echo("Available commands:")
            click.echo("  app list              - List applications")
            click.echo("  app create -n NAME    - Create application")
            click.echo("  page list --app-id X  - List pages")
            click.echo("  dashboard create ... - Create dashboard")
            click.echo("  dashboard components - List components")
            click.echo("  auth status           - Show auth status")
            click.echo("  info config           - Show configuration")
            click.echo("  exit                  - Exit REPL")
            continue

        if line.strip() == "auth status":
            from .core.session import get_session
            session = get_session()
            if not session.is_authenticated:
                click.echo("Not authenticated")
            else:
                click.echo("Authenticated")
                if session.token:
                    click.echo(f"  Token: {session.token[:20]}...")
            continue

        if line.strip() == "info config":
            from .core.session import get_session
            session = get_session()
            click.echo(f"Base URL: {session.base_url or 'http://localhost:10517/metav'}")
            click.echo(f"Authkey: {'set' if session.authkey else 'not set'}")
            continue

        if line.strip() == "dashboard components":
            try:
                backend = get_backend()
                components = backend.list_components()
                click.echo(f"Found {len(components)} components")
            except Exception as e:
                click.echo(f"Error: {e}", err=True)
            continue

        if line.strip().startswith("app list"):
            try:
                backend = get_backend()
                apps = backend.list_apps()
                for app in apps[:10]:
                    click.echo(f"  {app.get('id', '')} - {app.get('name', '')}")
            except Exception as e:
                click.echo(f"Error: {e}", err=True)
            continue

        click.echo(f"Unknown command: {line.strip()}")
        click.echo("Type 'help' for available commands.")


def main():
    """Entry point for the CLI."""
    cli(obj={})


if __name__ == "__main__":
    main()
