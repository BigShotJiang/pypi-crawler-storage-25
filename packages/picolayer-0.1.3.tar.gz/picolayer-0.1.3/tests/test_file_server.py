"""Tests for picolayer.file_server — temporary HTTP file server."""

from __future__ import annotations

from pathlib import Path

import httpx

from picolayer.file_server import _find_free_port, serve_directory


class TestFindFreePort:
    """Tests for _find_free_port."""

    def test_returns_positive_integer(self) -> None:
        port = _find_free_port()
        assert isinstance(port, int)
        assert port > 0

    def test_returns_different_ports(self) -> None:
        """Consecutive calls should generally return different ports."""
        ports = {_find_free_port() for _ in range(5)}
        # At least some should differ (extremely unlikely all 5 are the same)
        assert len(ports) >= 2


class TestServeDirectory:
    """Tests for serve_directory context manager."""

    def test_serves_file(self, tmp_path: Path) -> None:
        test_file = tmp_path / "hello.txt"
        test_file.write_text("Hello, world!")

        with serve_directory(tmp_path) as port:
            resp = httpx.get(f"http://127.0.0.1:{port}/hello.txt")
            assert resp.status_code == 200
            assert resp.text == "Hello, world!"

    def test_serves_binary_file(self, tmp_path: Path) -> None:
        binary_file = tmp_path / "data.bin"
        content = bytes(range(256))
        binary_file.write_bytes(content)

        with serve_directory(tmp_path) as port:
            resp = httpx.get(f"http://127.0.0.1:{port}/data.bin")
            assert resp.status_code == 200
            assert resp.content == content

    def test_returns_404_for_missing_file(self, tmp_path: Path) -> None:
        with serve_directory(tmp_path) as port:
            resp = httpx.get(f"http://127.0.0.1:{port}/nonexistent.txt")
            assert resp.status_code == 404

    def test_server_stops_after_context(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        with serve_directory(tmp_path) as port:
            resp = httpx.get(f"http://127.0.0.1:{port}/test.txt")
            assert resp.status_code == 200

        # After context exit, the server should be shut down
        with httpx.Client() as client:
            try:
                client.get(f"http://127.0.0.1:{port}/test.txt", timeout=1.0)
                # If we get here, connection should have failed
                raise AssertionError("Expected connection error after server shutdown")
            except httpx.ConnectError:
                pass  # Expected

    def test_port_is_valid(self, tmp_path: Path) -> None:
        with serve_directory(tmp_path) as port:
            assert isinstance(port, int)
            assert 1024 <= port <= 65535

    def test_serves_nested_file(self, tmp_path: Path) -> None:
        subdir = tmp_path / "sub"
        subdir.mkdir()
        nested_file = subdir / "nested.txt"
        nested_file.write_text("nested content")

        with serve_directory(tmp_path) as port:
            resp = httpx.get(f"http://127.0.0.1:{port}/sub/nested.txt")
            assert resp.status_code == 200
            assert resp.text == "nested content"
