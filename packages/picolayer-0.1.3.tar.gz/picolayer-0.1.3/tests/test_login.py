"""Tests for picolayer login command."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from picolayer.app import app
from picolayer.config import load_config

runner = CliRunner()


class TestLoginCommand:
    """Tests for the ``picolayer login`` command."""

    def test_login_with_valid_key(self, tmp_config_dir: Path, monkeypatch: Any) -> None:
        mock_client = MagicMock()
        mock_client.validate_auth.return_value = True
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            result = runner.invoke(app, ["login", "--api-key", "valid-key-123"])

        assert result.exit_code == 0
        assert "Logged in successfully" in result.output
        cfg = load_config()
        assert cfg["auth"]["api_key"] == "valid-key-123"

    def test_login_with_invalid_key(self, tmp_config_dir: Path, monkeypatch: Any) -> None:
        mock_client = MagicMock()
        mock_client.validate_auth.return_value = False
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            result = runner.invoke(app, ["login", "--api-key", "bad-key"])

        assert result.exit_code == 1
        assert "Invalid API key" in result.output

    def test_login_with_api_error(self, tmp_config_dir: Path, monkeypatch: Any) -> None:
        from picolayer.api_client import ApiError

        mock_client = MagicMock()
        mock_client.validate_auth.side_effect = ApiError(500, "Server error")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            result = runner.invoke(app, ["login", "--api-key", "some-key"])

        assert result.exit_code == 1
        assert "Authentication failed" in result.output

    def test_login_prompts_for_key(self, tmp_config_dir: Path, monkeypatch: Any) -> None:
        mock_client = MagicMock()
        mock_client.validate_auth.return_value = True
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            result = runner.invoke(app, ["login"], input="prompted-key\n")

        assert result.exit_code == 0
        cfg = load_config()
        assert cfg["auth"]["api_key"] == "prompted-key"

    def test_login_warns_existing_key_and_replaces(
        self, tmp_config_dir: Path, saved_config: Any
    ) -> None:
        saved_config({"auth": {"api_key": "old-key"}})

        mock_client = MagicMock()
        mock_client.validate_auth.return_value = True
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            # Answer "yes" to replace, then provide new key
            result = runner.invoke(app, ["login"], input="y\nnew-key\n")

        assert result.exit_code == 0
        assert "already logged in" in result.output
        cfg = load_config()
        assert cfg["auth"]["api_key"] == "new-key"

    def test_login_aborts_when_declining_replace(
        self, tmp_config_dir: Path, saved_config: Any
    ) -> None:
        saved_config({"auth": {"api_key": "old-key"}})

        result = runner.invoke(app, ["login"], input="n\n")
        assert result.exit_code != 0
        # Key should remain unchanged
        cfg = load_config()
        assert cfg["auth"]["api_key"] == "old-key"

    def test_login_custom_endpoint(self, tmp_config_dir: Path, monkeypatch: Any) -> None:
        mock_client = MagicMock()
        mock_client.validate_auth.return_value = True
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            result = runner.invoke(
                app,
                [
                    "login",
                    "--api-key",
                    "key-123",
                    "--api-endpoint",
                    "https://custom.api.dev",
                ],
            )

        assert result.exit_code == 0
        cfg = load_config()
        assert cfg["auth"]["api_endpoint"] == "https://custom.api.dev"

    def test_login_stores_default_endpoint(self, tmp_config_dir: Path, monkeypatch: Any) -> None:
        from picolayer.config import DEFAULT_API_ENDPOINT

        mock_client = MagicMock()
        mock_client.validate_auth.return_value = True
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.commands.login.PicolayerClient", return_value=mock_client):
            result = runner.invoke(app, ["login", "--api-key", "key-123"])

        assert result.exit_code == 0
        cfg = load_config()
        assert cfg["auth"]["api_endpoint"] == DEFAULT_API_ENDPOINT
