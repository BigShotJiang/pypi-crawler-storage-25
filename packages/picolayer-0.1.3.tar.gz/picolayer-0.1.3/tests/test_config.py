"""Tests for picolayer.config — config read/write and helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from picolayer.config import (
    DEFAULT_API_ENDPOINT,
    get_api_endpoint,
    get_api_key,
    load_config,
    save_config,
)


class TestLoadConfig:
    """Tests for load_config."""

    def test_returns_empty_dict_when_missing(self, tmp_config_dir: Path) -> None:
        cfg = load_config()
        assert cfg == {}

    def test_loads_existing_config(self, tmp_config_path: Path, saved_config: Any) -> None:
        saved_config({"auth": {"api_key": "my-key"}})
        cfg = load_config()
        assert cfg["auth"]["api_key"] == "my-key"

    def test_loads_complex_config(self, tmp_config_path: Path, saved_config: Any) -> None:
        data = {
            "auth": {"api_key": "key-123", "api_endpoint": "https://custom.api.dev"},
            "preferences": {"color": True},
        }
        saved_config(data)
        cfg = load_config()
        assert cfg == data


class TestSaveConfig:
    """Tests for save_config."""

    def test_creates_file(self, tmp_config_dir: Path) -> None:
        save_config({"auth": {"api_key": "new-key"}})
        cfg = load_config()
        assert cfg["auth"]["api_key"] == "new-key"

    def test_creates_directory_if_needed(self, tmp_path: Path, monkeypatch: Any) -> None:
        new_dir = tmp_path / "nested" / ".picolayer"
        new_path = new_dir / "config.toml"
        monkeypatch.setattr("picolayer.config.CONFIG_DIR", new_dir)
        monkeypatch.setattr("picolayer.config.CONFIG_PATH", new_path)

        save_config({"test": True})
        assert new_path.exists()

    def test_overwrites_existing(self, tmp_config_path: Path, saved_config: Any) -> None:
        saved_config({"old": True})
        save_config({"new": True})
        cfg = load_config()
        assert "old" not in cfg
        assert cfg["new"] is True

    def test_round_trip_preserves_data(self, tmp_config_dir: Path) -> None:
        original = {
            "auth": {"api_key": "k", "api_endpoint": "https://example.com"},
            "settings": {"timeout": 60},
        }
        save_config(original)
        loaded = load_config()
        assert loaded == original


class TestGetApiKey:
    """Tests for get_api_key."""

    def test_returns_none_when_no_config(self, tmp_config_dir: Path) -> None:
        assert get_api_key() is None

    def test_returns_none_when_no_auth_section(
        self, saved_config: Any, tmp_config_dir: Path
    ) -> None:
        saved_config({"other": "stuff"})
        assert get_api_key() is None

    def test_returns_none_when_no_api_key_field(
        self, saved_config: Any, tmp_config_dir: Path
    ) -> None:
        saved_config({"auth": {"api_endpoint": "https://example.com"}})
        assert get_api_key() is None

    def test_returns_key_when_present(self, saved_config: Any, tmp_config_dir: Path) -> None:
        saved_config({"auth": {"api_key": "secret-key-42"}})
        assert get_api_key() == "secret-key-42"


class TestGetApiEndpoint:
    """Tests for get_api_endpoint."""

    def test_returns_default_when_no_config(self, tmp_config_dir: Path) -> None:
        assert get_api_endpoint() == DEFAULT_API_ENDPOINT

    def test_returns_default_when_no_auth_section(
        self, saved_config: Any, tmp_config_dir: Path
    ) -> None:
        saved_config({"other": "stuff"})
        assert get_api_endpoint() == DEFAULT_API_ENDPOINT

    def test_returns_custom_endpoint(self, saved_config: Any, tmp_config_dir: Path) -> None:
        saved_config({"auth": {"api_endpoint": "https://custom.api.dev"}})
        assert get_api_endpoint() == "https://custom.api.dev"

    def test_returns_default_when_endpoint_missing_from_auth(
        self, saved_config: Any, tmp_config_dir: Path
    ) -> None:
        saved_config({"auth": {"api_key": "key"}})
        assert get_api_endpoint() == DEFAULT_API_ENDPOINT
