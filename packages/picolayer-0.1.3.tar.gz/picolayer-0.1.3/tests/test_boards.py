"""Tests for picolayer.boards — board catalog and lookup."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from picolayer.boards import BOARD_NAMES, BOARDS, BoardInfo, get_board, reload_boards


class TestBoardInfo:
    """Tests for the BoardInfo dataclass."""

    def test_board_info_is_frozen(self) -> None:
        board = BoardInfo(
            name="test",
            display_name="Test Board",
            mcu="MCU1",
            architecture="arm",
            description="A test board",
        )
        assert board.name == "test"
        # Frozen dataclass should reject attribute assignment
        import pytest

        with pytest.raises(AttributeError):
            board.name = "changed"  # type: ignore[misc]

    def test_board_info_fields(self) -> None:
        board = BoardInfo(
            name="my_board",
            display_name="My Board",
            mcu="ARM-M4",
            architecture="cortex-m4f",
            description="desc",
        )
        assert board.name == "my_board"
        assert board.display_name == "My Board"
        assert board.mcu == "ARM-M4"
        assert board.architecture == "cortex-m4f"
        assert board.description == "desc"


class TestBoardCatalog:
    """Tests for the BOARDS list and BOARD_NAMES."""

    def test_boards_not_empty(self) -> None:
        assert len(BOARDS) > 0

    def test_board_names_matches_boards(self) -> None:
        assert len(BOARD_NAMES) == len(BOARDS)
        for board, name in zip(BOARDS, BOARD_NAMES, strict=True):
            assert board.name == name

    def test_all_boards_have_required_fields(self) -> None:
        for board in BOARDS:
            assert board.name, f"Board missing name: {board}"
            assert board.display_name, f"Board missing display_name: {board}"
            assert board.mcu, f"Board missing mcu: {board}"
            assert board.architecture, f"Board missing architecture: {board}"
            assert board.description, f"Board missing description: {board}"

    def test_board_names_are_lowercase_underscored(self) -> None:
        for board in BOARDS:
            assert board.name == board.name.lower(), f"Board name not lowercase: {board.name}"
            assert "-" not in board.name, f"Board name contains hyphens: {board.name}"

    def test_no_duplicate_board_names(self) -> None:
        names = [b.name for b in BOARDS]
        assert len(names) == len(set(names)), "Duplicate board names found"

    def test_known_boards_present(self) -> None:
        """Verify key boards exist in the catalog."""
        expected = {"stm32f4_discovery", "nrf52840dk", "hifive1", "leon3"}
        actual = set(BOARD_NAMES)
        assert expected.issubset(actual)


class TestGetBoard:
    """Tests for the get_board lookup function."""

    def test_exact_match(self) -> None:
        board = get_board("stm32f4_discovery")
        assert board is not None
        assert board.name == "stm32f4_discovery"

    def test_case_insensitive(self) -> None:
        board = get_board("STM32F4_DISCOVERY")
        assert board is not None
        assert board.name == "stm32f4_discovery"

    def test_hyphens_normalized_to_underscores(self) -> None:
        board = get_board("stm32f4-discovery")
        assert board is not None
        assert board.name == "stm32f4_discovery"

    def test_mixed_case_and_hyphens(self) -> None:
        board = get_board("NRF52840DK")
        assert board is not None
        assert board.name == "nrf52840dk"

    def test_unknown_board_returns_none(self) -> None:
        assert get_board("nonexistent_board") is None

    def test_empty_string_returns_none(self) -> None:
        assert get_board("") is None

    def test_all_boards_lookable(self) -> None:
        for board in BOARDS:
            found = get_board(board.name)
            assert found is not None
            assert found.name == board.name


class TestJsonLoader:
    """Tests that exercise the canonical platforms/board_catalog.json loader."""

    def test_aliases_deduped_by_renode_platform(self) -> None:
        """nrf52840dk and nrf52840dk_nrf52840 share a platform → only one shown."""
        platforms = [b.name for b in BOARDS]
        # The alias entry must not appear in the deduped CLI list.
        assert "nrf52840dk" in platforms
        assert "nrf52840dk_nrf52840" not in platforms

    def test_env_override_loads_alternate_catalog(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """PICOLAYER_BOARD_CATALOG should redirect the loader."""
        alt = tmp_path / "alt.json"
        alt.write_text(
            json.dumps(
                {
                    "version": 1,
                    "boards": [
                        {
                            "name": "alt_board",
                            "display_name": "Alt",
                            "mcu": "ALT-1",
                            "architecture": "cortex-m4f",
                            "renode_platform": "platforms/cpus/alt.repl",
                            "description": "Test override",
                            "peripherals": [],
                        }
                    ],
                }
            )
        )
        monkeypatch.setenv("PICOLAYER_BOARD_CATALOG", str(alt))
        try:
            reload_boards()
            from picolayer.boards import BOARDS as reloaded

            assert any(b.name == "alt_board" for b in reloaded)
            assert not any(b.name == "stm32f4_discovery" for b in reloaded)
        finally:
            monkeypatch.delenv("PICOLAYER_BOARD_CATALOG", raising=False)
            reload_boards()


class TestCandidateCatalogPaths:
    """Edge cases for the path-discovery walk.

    Mirrors the executor regression: a shallow ``__file__`` location
    must not crash the loader. The walk-the-ancestors implementation
    must produce one candidate per ancestor without indexing a fixed
    depth.
    """

    def test_dev_layout_includes_repo_root_candidate(self) -> None:
        from picolayer.boards import _candidate_catalog_paths

        fake = Path("/Users/me/repo/cli/picolayer/boards.py")
        paths = _candidate_catalog_paths(here=fake)
        assert Path("/Users/me/repo/platforms/board_catalog.json") in paths

    def test_shallow_path_does_not_index_error(self) -> None:
        """A 1-parent path used to crash with IndexError on parents[2]."""
        from picolayer.boards import _candidate_catalog_paths

        fake = Path("/x/y.py")
        paths = _candidate_catalog_paths(here=fake)
        assert len(paths) >= 1
        assert Path("/x/platforms/board_catalog.json") in paths

    def test_env_override_takes_precedence(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from picolayer.boards import _candidate_catalog_paths

        override = tmp_path / "override.json"
        monkeypatch.setenv("PICOLAYER_BOARD_CATALOG", str(override))
        paths = _candidate_catalog_paths(here=Path("/x/y.py"))
        assert paths[0] == override
