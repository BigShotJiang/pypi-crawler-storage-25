"""Tests for picolayer test command — config validation and error paths."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from picolayer.app import app

runner = CliRunner()


class TestTestCommandValidation:
    """Tests for input validation in the test command."""

    def test_missing_firmware(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(tmp_path / "nonexistent.elf"),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
            ],
        )
        assert result.exit_code == 1
        assert "Firmware not found" in result.output

    def test_missing_test_script(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(tmp_path / "nonexistent.robot"),
                "--config",
                str(config_file),
            ],
        )
        assert result.exit_code == 1
        assert "Test script not found" in result.output

    def test_missing_config(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(tmp_path / "missing.yml"),
            ],
        )
        assert result.exit_code == 1
        assert "Config not found" in result.output


class TestPicolayerConfigValidation:
    """Tests for picolayer.yml content validation."""

    def _invoke_test(self, tmp_path: Path, config_content: str) -> Any:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(config_content)

        return runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
            ],
        )

    def test_invalid_yaml(self, tmp_path: Path) -> None:
        result = self._invoke_test(tmp_path, "board: [invalid yaml\n")
        assert result.exit_code == 1
        assert "Invalid YAML" in result.output

    def test_yaml_not_a_mapping(self, tmp_path: Path) -> None:
        # A bare string is parsed as a scalar by yaml.safe_load, not a dict
        result = self._invoke_test(tmp_path, "just a string\n")
        assert result.exit_code == 1
        assert "YAML mapping" in result.output

    def test_no_board_or_hardware(self, tmp_path: Path) -> None:
        result = self._invoke_test(tmp_path, "timeout: 300\n")
        assert result.exit_code == 1
        assert "Must specify either" in result.output

    def test_both_board_and_hardware(self, tmp_path: Path) -> None:
        result = self._invoke_test(
            tmp_path, "board: stm32f4_discovery\nhardware:\n  platform: stm32\n"
        )
        assert result.exit_code == 1
        assert "Cannot specify both" in result.output

    def test_unknown_board(self, tmp_path: Path) -> None:
        result = self._invoke_test(tmp_path, "board: nonexistent_board\n")
        assert result.exit_code == 1
        assert "Unknown board" in result.output

    def test_valid_config_proceeds_to_docker(self, tmp_path: Path) -> None:
        """A valid config should proceed past validation to Docker check."""
        mock_check_docker = MagicMock()
        mock_check_docker.side_effect = Exception("docker not available")

        with patch("picolayer.docker_runner.check_docker", mock_check_docker):
            self._invoke_test(tmp_path, "board: stm32f4_discovery\ntimeout: 300\n")

        # Should have gotten past config validation (the error is from Docker check)
        mock_check_docker.assert_called_once()


class TestTestCommandLocalMode:
    """Tests for local Docker execution path."""

    def test_docker_not_available(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.docker_runner import DockerError

        with patch(
            "picolayer.docker_runner.check_docker",
            side_effect=DockerError("Docker is not installed."),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                ],
            )
        assert result.exit_code == 1
        assert "Docker is not installed" in result.output


class TestTestCommandRemoteMode:
    """Tests for remote API execution path."""

    def test_remote_not_logged_in(self, tmp_path: Path, tmp_config_dir: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--remote",
            ],
        )
        assert result.exit_code == 1
        assert "Not logged in" in result.output

    def test_remote_with_api_error(
        self, tmp_path: Path, tmp_config_dir: Path, saved_config: Any
    ) -> None:
        saved_config({"auth": {"api_key": "test-key", "api_endpoint": "https://api.test.dev"}})

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.api_client import ApiError

        mock_client = MagicMock()
        mock_client.upload_file.side_effect = ApiError(500, "Upload failed")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.api_client.PicolayerClient", return_value=mock_client):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--remote",
                ],
            )
        assert result.exit_code == 1
        assert "API error" in result.output


class TestDisplayResult:
    """Tests for _display_result helper."""

    def test_passed_result(self, capsys: Any) -> None:
        from picolayer.commands.test import _display_result

        _display_result("completed", "passed", "All tests passed", None)
        # _display_result uses Rich console, so we don't check capsys here
        # Just verify no exception is raised

    def test_failed_result(self) -> None:
        from picolayer.commands.test import _display_result

        _display_result("completed", "failed", "1 test failed", "Assertion error")

    def test_error_result(self) -> None:
        from picolayer.commands.test import _display_result

        _display_result("error", None, None, "Container crashed")

    def test_truncates_long_output(self) -> None:
        from picolayer.commands.test import _display_result

        long_output = "x" * 5000
        # Should not raise — output is truncated at 2000 chars internally
        _display_result("completed", "passed", long_output, None)


class TestJsonOutput:
    """Tests for the ``picolayer test --json`` flag."""

    def test_missing_firmware_emits_json_error(self, tmp_path: Path) -> None:
        import json as _json

        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(tmp_path / "missing.elf"),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--json",
            ],
        )
        assert result.exit_code != 0
        payload = _json.loads(result.stdout)
        assert payload["ok"] is False
        assert "Firmware not found" in payload["error"]

    def test_invalid_yaml_emits_json_error(self, tmp_path: Path) -> None:
        import json as _json

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: [unclosed\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--json",
            ],
        )
        assert result.exit_code != 0
        payload = _json.loads(result.stdout)
        assert payload["ok"] is False
        assert "Invalid YAML" in payload["error"]

    def test_local_run_emits_json_payload(self, tmp_path: Path) -> None:
        import json as _json

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.docker_runner import RunResult

        run_result = RunResult(
            status="completed",
            result="passed",
            output="ok",
            error_message=None,
            artifacts={"uart0_transcript.txt": str(tmp_path / "uart0.txt")},
        )

        with (
            patch("picolayer.commands.test.check_docker", create=True),
            patch("picolayer.commands.test.ensure_image", create=True),
            patch("picolayer.commands.test.run_test", create=True, return_value=run_result),
        ):
            # The patches above are no-ops; the real lookups happen inside _run_local.
            with (
                patch("picolayer.docker_runner.check_docker"),
                patch("picolayer.docker_runner.ensure_image"),
                patch("picolayer.docker_runner.run_test", return_value=run_result),
            ):
                result = runner.invoke(
                    app,
                    [
                        "test",
                        "--firmware",
                        str(firmware),
                        "--test-script",
                        str(test_file),
                        "--config",
                        str(config_file),
                        "--json",
                    ],
                )
        assert result.exit_code == 0
        payload = _json.loads(result.stdout)
        assert payload["ok"] is True
        assert payload["mode"] == "local"
        assert payload["result"] == "passed"
        assert payload["status"] == "completed"
        assert any(a["name"] == "uart0_transcript.txt" for a in payload["artifacts"])
