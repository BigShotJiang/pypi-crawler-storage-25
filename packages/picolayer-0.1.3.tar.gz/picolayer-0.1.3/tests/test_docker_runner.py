"""Tests for picolayer.docker_runner — Docker test runner."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from picolayer.docker_runner import (
    DockerError,
    RunResult,
    _collect_results,
    check_docker,
    ensure_image,
)


class TestCheckDocker:
    """Tests for check_docker."""

    def test_success_when_docker_available(self, mocker: Any) -> None:
        mocker.patch("subprocess.run", return_value=MagicMock(returncode=0))
        # Should not raise
        check_docker()

    def test_raises_when_docker_not_installed(self, mocker: Any) -> None:
        mocker.patch("subprocess.run", side_effect=FileNotFoundError)
        with pytest.raises(DockerError, match="not installed"):
            check_docker()

    def test_raises_when_daemon_not_running(self, mocker: Any) -> None:
        mocker.patch(
            "subprocess.run",
            side_effect=subprocess.CalledProcessError(1, "docker info"),
        )
        with pytest.raises(DockerError, match="not running"):
            check_docker()


class TestEnsureImage:
    """Tests for ensure_image."""

    def test_does_nothing_when_image_exists(self, mocker: Any) -> None:
        mocker.patch("subprocess.run", return_value=MagicMock(returncode=0))
        ensure_image("test-image:latest")
        # Only docker image inspect should be called, not pull
        subprocess.run.assert_called_once()  # type: ignore[attr-defined]

    def test_pulls_image_when_missing(self, mocker: Any) -> None:
        inspect_result = MagicMock(returncode=1)
        pull_result = MagicMock(returncode=0)
        mocker.patch("subprocess.run", side_effect=[inspect_result, pull_result])
        ensure_image("test-image:latest")
        assert subprocess.run.call_count == 2  # type: ignore[attr-defined]

    def test_raises_on_pull_failure(self, mocker: Any) -> None:
        inspect_result = MagicMock(returncode=1)
        mocker.patch(
            "subprocess.run",
            side_effect=[
                inspect_result,
                subprocess.CalledProcessError(1, "docker pull"),
            ],
        )
        with pytest.raises(DockerError, match="Failed to pull"):
            ensure_image("test-image:latest")


class TestCollectResults:
    """Tests for _collect_results."""

    def test_parses_results_json(self, tmp_path: Path) -> None:
        results_data = {
            "status": "completed",
            "result": "passed",
            "output": "All 3 tests passed",
            "error_message": None,
        }
        results_file = tmp_path / "results.json"
        results_file.write_text(json.dumps(results_data))

        # Add an artifact file
        artifact = tmp_path / "log.xml"
        artifact.write_text("<xml>log</xml>")

        result = _collect_results(tmp_path, exit_code=0)
        assert result.status == "completed"
        assert result.result == "passed"
        assert result.output == "All 3 tests passed"
        assert "log.xml" in result.artifacts
        assert result.artifacts["log.xml"] == str(artifact)

    def test_error_when_no_results_file(self, tmp_path: Path) -> None:
        result = _collect_results(tmp_path, exit_code=1)
        assert result.status == "error"
        assert "exited with code 1" in (result.error_message or "")

    def test_defaults_unknown_status(self, tmp_path: Path) -> None:
        results_file = tmp_path / "results.json"
        results_file.write_text(json.dumps({"output": "something"}))
        result = _collect_results(tmp_path, exit_code=0)
        assert result.status == "unknown"

    def test_multiple_artifacts(self, tmp_path: Path) -> None:
        results_file = tmp_path / "results.json"
        results_file.write_text(json.dumps({"status": "completed", "result": "passed"}))

        for name in ["log.xml", "output.txt", "screenshot.png"]:
            (tmp_path / name).write_text("data")

        result = _collect_results(tmp_path, exit_code=0)
        assert len(result.artifacts) == 3
        for name in ["log.xml", "output.txt", "screenshot.png"]:
            assert name in result.artifacts


class TestRunResult:
    """Tests for the RunResult dataclass."""

    def test_defaults(self) -> None:
        result = RunResult(status="pending")
        assert result.result is None
        assert result.output is None
        assert result.error_message is None
        assert result.artifacts == {}

    def test_with_all_fields(self) -> None:
        result = RunResult(
            status="completed",
            result="passed",
            output="output text",
            error_message=None,
            artifacts={"log.xml": "/tmp/log.xml"},
        )
        assert result.status == "completed"
        assert result.artifacts["log.xml"] == "/tmp/log.xml"
