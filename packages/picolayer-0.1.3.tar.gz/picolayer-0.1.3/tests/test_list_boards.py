"""Tests for ``picolayer list-boards`` CLI command."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from picolayer.app import app

runner = CliRunner()


class TestListBoardsCommand:
    def test_table_output_exits_zero(self) -> None:
        result = runner.invoke(app, ["list-boards"])
        assert result.exit_code == 0

    def test_table_contains_known_board(self) -> None:
        result = runner.invoke(app, ["list-boards"])
        assert result.exit_code == 0
        assert "nrf52840dk" in result.output

    def test_table_contains_header(self) -> None:
        result = runner.invoke(app, ["list-boards"])
        assert result.exit_code == 0
        assert "Name" in result.output
        assert "MCU" in result.output

    def test_json_output_is_valid(self) -> None:
        result = runner.invoke(app, ["list-boards", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output.strip())
        assert data["ok"] is True
        assert isinstance(data["count"], int)
        assert data["count"] > 0
        assert isinstance(data["boards"], list)

    def test_json_output_includes_required_fields(self) -> None:
        result = runner.invoke(app, ["list-boards", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output.strip())
        for board in data["boards"]:
            assert "name" in board
            assert "display_name" in board
            assert "mcu" in board
            assert "architecture" in board
            assert "description" in board

    def test_json_count_matches_boards_length(self) -> None:
        result = runner.invoke(app, ["list-boards", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output.strip())
        assert data["count"] == len(data["boards"])

    def test_json_contains_nrf52840dk(self) -> None:
        result = runner.invoke(app, ["list-boards", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output.strip())
        names = [b["name"] for b in data["boards"]]
        assert "nrf52840dk" in names
