"""Tests for picolayer init command."""

from __future__ import annotations

import json
from pathlib import Path

import yaml
from typer.testing import CliRunner

from picolayer.app import app

runner = CliRunner()


class TestInitCommand:
    """Tests for the ``picolayer init`` command."""

    def test_creates_picolayer_yml_by_number(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path)], input="1\n")
        assert result.exit_code == 0
        config_path = tmp_path / "picolayer.yml"
        assert config_path.exists()
        data = yaml.safe_load(config_path.read_text())
        assert data["board"] == "stm32f4_discovery"
        assert data["timeout"] == 300

    def test_creates_picolayer_yml_by_name(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path)], input="nrf52840dk\n")
        assert result.exit_code == 0
        config_path = tmp_path / "picolayer.yml"
        data = yaml.safe_load(config_path.read_text())
        assert data["board"] == "nrf52840dk"

    def test_case_insensitive_name(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path)], input="NRF52840DK\n")
        assert result.exit_code == 0
        config_path = tmp_path / "picolayer.yml"
        data = yaml.safe_load(config_path.read_text())
        assert data["board"] == "nrf52840dk"

    def test_hyphenated_name(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path)], input="stm32f4-discovery\n")
        assert result.exit_code == 0
        data = yaml.safe_load((tmp_path / "picolayer.yml").read_text())
        assert data["board"] == "stm32f4_discovery"

    def test_aborts_if_file_exists_and_user_declines(self, tmp_path: Path) -> None:
        existing = tmp_path / "picolayer.yml"
        existing.write_text("board: old\n")
        result = runner.invoke(app, ["init", str(tmp_path)], input="n\n")
        assert result.exit_code != 0
        # Original file should be unchanged
        assert yaml.safe_load(existing.read_text())["board"] == "old"

    def test_overwrites_if_file_exists_and_user_confirms(self, tmp_path: Path) -> None:
        existing = tmp_path / "picolayer.yml"
        existing.write_text("board: old\n")
        result = runner.invoke(app, ["init", str(tmp_path)], input="y\n1\n")
        assert result.exit_code == 0
        data = yaml.safe_load(existing.read_text())
        assert data["board"] == "stm32f4_discovery"

    def test_invalid_number_then_valid(self, tmp_path: Path) -> None:
        # Enter 0 (invalid), then 999 (invalid), then 1 (valid)
        result = runner.invoke(app, ["init", str(tmp_path)], input="0\n999\n1\n")
        assert result.exit_code == 0
        assert "Enter a number" in result.output

    def test_invalid_name_then_valid(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app, ["init", str(tmp_path)], input="nonexistent\nstm32f4_discovery\n"
        )
        assert result.exit_code == 0
        assert "Unknown board" in result.output

    def test_displays_board_table(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path)], input="1\n")
        assert result.exit_code == 0
        assert "Supported Boards" in result.output
        assert "stm32f4_discovery" in result.output

    def test_shows_next_steps(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path)], input="1\n")
        assert result.exit_code == 0
        assert "Next steps" in result.output

    def test_creates_directory_if_needed(self, tmp_path: Path) -> None:
        new_dir = tmp_path / "new_project"
        result = runner.invoke(app, ["init", str(new_dir)], input="1\n")
        assert result.exit_code == 0
        assert (new_dir / "picolayer.yml").exists()

    def test_select_last_board(self, tmp_path: Path) -> None:
        from picolayer.boards import BOARDS

        result = runner.invoke(app, ["init", str(tmp_path)], input=f"{len(BOARDS)}\n")
        assert result.exit_code == 0
        data = yaml.safe_load((tmp_path / "picolayer.yml").read_text())
        assert data["board"] == BOARDS[-1].name


class TestInitJsonMode:
    """Tests for ``picolayer init --json --board <name>``."""

    def test_json_with_board_creates_file(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path), "--json", "--board", "nrf52840dk"])
        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        assert payload["ok"] is True
        assert payload["board"]["name"] == "nrf52840dk"
        assert (tmp_path / "picolayer.yml").exists()

    def test_json_without_board_errors(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path), "--json"])
        assert result.exit_code != 0
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert "--board" in payload["error"]

    def test_json_unknown_board_errors(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["init", str(tmp_path), "--json", "--board", "nope"])
        assert result.exit_code != 0
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert "Unknown board" in payload["error"]

    def test_json_existing_file_errors_without_overwrite(self, tmp_path: Path) -> None:
        existing = tmp_path / "picolayer.yml"
        existing.write_text("board: old\n")
        result = runner.invoke(app, ["init", str(tmp_path), "--json", "--board", "nrf52840dk"])
        assert result.exit_code != 0
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert "already exists" in payload["error"]

    def test_json_overwrite_succeeds(self, tmp_path: Path) -> None:
        existing = tmp_path / "picolayer.yml"
        existing.write_text("board: old\n")
        result = runner.invoke(
            app,
            ["init", str(tmp_path), "--json", "--board", "nrf52840dk", "--overwrite"],
        )
        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        assert payload["ok"] is True
        data = yaml.safe_load(existing.read_text())
        assert data["board"] == "nrf52840dk"
