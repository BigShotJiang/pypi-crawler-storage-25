"""Shared fixtures for Picolayer CLI tests."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest


@pytest.fixture()
def tmp_config_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Override CONFIG_DIR and CONFIG_PATH to use a temporary directory."""
    config_dir = tmp_path / ".picolayer"
    config_dir.mkdir()
    config_path = config_dir / "config.toml"

    monkeypatch.setattr("picolayer.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("picolayer.config.CONFIG_PATH", config_path)
    return config_dir


@pytest.fixture()
def tmp_config_path(tmp_config_dir: Path) -> Path:
    """Return the config.toml path inside the temp config dir."""
    return tmp_config_dir / "config.toml"


@pytest.fixture()
def saved_config(tmp_config_dir: Path) -> Any:
    """Helper to write a config dict to the temp config.toml.

    Usage in tests:
        saved_config({"auth": {"api_key": "test-key"}})
    """
    import tomli_w

    def _save(data: dict[str, Any]) -> None:
        with open(tmp_config_dir / "config.toml", "wb") as f:
            tomli_w.dump(data, f)

    return _save


@pytest.fixture()
def mock_api_responses() -> dict[str, Any]:
    """Common API response payloads for mocking."""
    return {
        "job_submitted": {
            "job_id": "job-abc123",
            "status": "pending",
            "result": None,
            "output": None,
            "error_message": None,
        },
        "job_completed": {
            "job_id": "job-abc123",
            "status": "completed",
            "result": "passed",
            "output": "All tests passed",
            "error_message": None,
        },
        "job_failed": {
            "job_id": "job-abc123",
            "status": "completed",
            "result": "failed",
            "output": "1 test failed",
            "error_message": "Assertion error",
        },
        "upload_response": {
            "url": "https://s3.example.com/firmware.elf",
        },
        "artifacts_response": {
            "job_id": "job-abc123",
            "artifacts": [
                {
                    "name": "log.xml",
                    "size_bytes": 1024,
                    "content_type": "application/xml",
                    "download_url": "https://s3.example.com/log.xml",
                },
            ],
            "is_streaming": False,
        },
    }


@pytest.fixture()
def project_dir(tmp_path: Path) -> Path:
    """Create a minimal project directory with firmware and test script."""
    firmware = tmp_path / "firmware.elf"
    firmware.write_bytes(b"\x7fELF" + b"\x00" * 100)

    test_file = tmp_path / "test.robot"
    test_file.write_text("*** Test Cases ***\nSimple Test\n    Log    Hello\n")

    config = tmp_path / "picolayer.yml"
    config.write_text("board: stm32f4_discovery\ntimeout: 300\n")

    return tmp_path
