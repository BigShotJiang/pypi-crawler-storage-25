"""Tests for ``picolayer generate`` commands."""

from __future__ import annotations

import json
from pathlib import Path

import yaml
from typer.testing import CliRunner

from picolayer.app import app
from picolayer.generate.test_scaffold import generate_test_scaffold

runner = CliRunner()


class TestGenerateConfigTemplate:
    def test_template_writes_file(self, tmp_path: Path) -> None:
        out = tmp_path / "picolayer.yml"
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "template",
                "--board",
                "nrf52840dk",
                "--output",
                str(out),
            ],
        )
        assert result.exit_code == 0, result.output
        assert out.exists()
        data = yaml.safe_load(out.read_text())
        assert data["board"] == "nrf52840dk"

    def test_template_unknown_board_fails(self, tmp_path: Path) -> None:
        out = tmp_path / "picolayer.yml"
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "template",
                "--board",
                "fake",
                "--output",
                str(out),
            ],
        )
        assert result.exit_code != 0
        assert "Unknown board" in result.output

    def test_template_existing_file_requires_overwrite(self, tmp_path: Path) -> None:
        out = tmp_path / "picolayer.yml"
        out.write_text("board: old\n")
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "template",
                "--board",
                "nrf52840dk",
                "--output",
                str(out),
            ],
        )
        assert result.exit_code != 0
        assert "already exists" in result.output

    def test_template_overwrite_replaces(self, tmp_path: Path) -> None:
        out = tmp_path / "picolayer.yml"
        out.write_text("board: old\n")
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "template",
                "--board",
                "nrf52840dk",
                "--output",
                str(out),
                "--overwrite",
            ],
        )
        assert result.exit_code == 0
        assert yaml.safe_load(out.read_text())["board"] == "nrf52840dk"

    def test_template_json_mode(self, tmp_path: Path) -> None:
        out = tmp_path / "picolayer.yml"
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "template",
                "--board",
                "stm32f4_discovery",
                "--output",
                str(out),
                "--json",
            ],
        )
        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        assert payload["ok"] is True
        assert payload["source"] == "template"
        assert payload["config_path"] == str(out)


class TestGenerateConfigLlm:
    def test_llm_writes_context_bundle(self, tmp_path: Path) -> None:
        repo = tmp_path / "fw"
        repo.mkdir()
        (repo / "CMakeLists.txt").write_text("project(fw)\nset(BOARD nrf52840dk)\n")
        (repo / "main.c").write_text("int main(){return 0;}\n")
        (repo / "build").mkdir()
        (repo / "build" / "binary.elf").write_bytes(b"\x7fELF")  # should be skipped

        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "llm",
                "--repo",
                str(repo),
                "--hint",
                "STM32F4 with TMP102",
            ],
        )
        assert result.exit_code == 0, result.output
        bundle_path = repo / ".picolayer" / "generate-context.json"
        assert bundle_path.exists()
        bundle = json.loads(bundle_path.read_text())
        assert bundle["hint"] == "STM32F4 with TMP102"
        # The CMakeLists.txt is interesting and should have its content captured
        cmake_entries = [e for e in bundle["files"] if e["path"] == "CMakeLists.txt"]
        assert cmake_entries
        assert "BOARD nrf52840dk" in cmake_entries[0]["content"]
        # build/ should be excluded
        assert not any("build/" in e["path"] for e in bundle["files"])

    def test_llm_missing_repo_fails(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "llm",
            ],
        )
        assert result.exit_code != 0
        assert "--repo is required" in result.output

    def test_llm_repo_must_be_directory(self, tmp_path: Path) -> None:
        not_dir = tmp_path / "file.txt"
        not_dir.write_text("hi")
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "llm",
                "--repo",
                str(not_dir),
            ],
        )
        assert result.exit_code != 0
        assert "must be a directory" in result.output

    def test_llm_with_datasheet(self, tmp_path: Path) -> None:
        repo = tmp_path / "fw"
        repo.mkdir()
        (repo / "main.c").write_text("int main(){return 0;}\n")
        ds = tmp_path / "datasheet.txt"
        ds.write_text("STM32F4 — UART base 0x40004400\n")
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "llm",
                "--repo",
                str(repo),
                "--datasheet",
                str(ds),
            ],
        )
        assert result.exit_code == 0
        bundle = json.loads((repo / ".picolayer" / "generate-context.json").read_text())
        assert len(bundle["datasheets"]) == 1
        assert "0x40004400" in bundle["datasheets"][0]["content"]


class TestGenerateConfigStubs:
    def test_cad_stub_fails_with_message(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app, ["generate", "config", "--from", "cad", "--model", str(tmp_path / "x.step")]
        )
        assert result.exit_code != 0
        assert "DEV-301" in result.output or "tier 1" in result.output

    def test_schematic_stub_fails_with_message(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "schematic",
                "--file",
                str(tmp_path / "x.kicad_sch"),
            ],
        )
        assert result.exit_code != 0
        assert "DEV-302" in result.output or "tier 2" in result.output

    def test_datasheet_stub_fails_with_message(self, tmp_path: Path) -> None:
        result = runner.invoke(
            app,
            [
                "generate",
                "config",
                "--from",
                "datasheet",
                "--pdf",
                str(tmp_path / "x.pdf"),
            ],
        )
        assert result.exit_code != 0
        assert "DEV-303" in result.output or "tier 4" in result.output


class TestGenerateTest:
    def test_emits_robot_skeleton(self, tmp_path: Path) -> None:
        config = tmp_path / "picolayer.yml"
        config.write_text("board: stm32f4_discovery\ntimeout: 300\n")
        out = tmp_path / "test.robot"
        result = runner.invoke(
            app,
            ["generate", "test", "--config", str(config), "--output", str(out)],
        )
        assert result.exit_code == 0, result.output
        assert out.exists()
        content = out.read_text()
        assert "*** Test Cases ***" in content
        assert "Boot Reaches UART" in content
        assert "Start Emulation" in content

    def test_existing_output_requires_overwrite(self, tmp_path: Path) -> None:
        config = tmp_path / "picolayer.yml"
        config.write_text("board: nrf52840dk\n")
        out = tmp_path / "test.robot"
        out.write_text("old")
        result = runner.invoke(
            app,
            ["generate", "test", "--config", str(config), "--output", str(out)],
        )
        assert result.exit_code != 0
        assert "already exists" in result.output

    def test_with_hardware_block_emits_led_test(self, tmp_path: Path) -> None:
        config = tmp_path / "picolayer.yml"
        config.write_text(
            """
hardware:
  cpu: cortex-m4f
  memory:
    flash:
      base: 0x08000000
      size: 1MB
  peripherals:
    uart0:
      type: uart
      base: 0x40000000
    gpioA:
      type: gpio
      base: 0x40020000
"""
        )
        out = tmp_path / "test.robot"
        result = runner.invoke(
            app,
            ["generate", "test", "--config", str(config), "--output", str(out)],
        )
        assert result.exit_code == 0
        text = out.read_text()
        assert "LED Toggles" in text
        assert "gpioA" in text


class TestGenerateTestScaffoldUnit:
    def test_uart_only(self) -> None:
        result = generate_test_scaffold("board: nrf52840dk\n")
        assert result.ok
        assert "uart0" in (result.text or "")

    def test_handles_invalid_yaml(self) -> None:
        result = generate_test_scaffold("[")
        assert not result.ok


class TestGenerateListSources:
    def test_lists_all_five_tiers(self) -> None:
        result = runner.invoke(app, ["generate", "list-sources", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        ids = {s["id"] for s in payload["sources"]}
        assert ids == {"template", "llm", "cad", "schematic", "datasheet"}
        # Tiers 3 and 5 are available; 1, 2, 4 are stubs
        by_id = {s["id"]: s for s in payload["sources"]}
        assert by_id["template"]["available"] is True
        assert by_id["llm"]["available"] is True
        assert by_id["cad"]["available"] is False
        assert by_id["schematic"]["available"] is False
        assert by_id["datasheet"]["available"] is False
