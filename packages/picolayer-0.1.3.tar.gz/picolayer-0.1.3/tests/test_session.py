"""Tests for the ``picolayer session`` command group."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from picolayer.app import app

runner = CliRunner()


@pytest.fixture
def mock_client(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):  # type: ignore[no-untyped-def]
    """Patch the PicolayerClient and the api-key resolver."""
    from picolayer.config import CONFIG_PATH

    # Pretend we're logged in
    monkeypatch.setattr("picolayer.commands.session.get_api_key", lambda: "test-key", raising=False)
    fake_config = tmp_path / "config.toml"
    fake_config.write_text('[auth]\napi_key = "test-key"\napi_endpoint = "https://api.test"\n')
    monkeypatch.setattr("picolayer.config.CONFIG_PATH", fake_config)

    client = MagicMock()
    client.__enter__ = MagicMock(return_value=client)
    client.__exit__ = MagicMock(return_value=False)

    with patch("picolayer.api_client.PicolayerClient", return_value=client) as constructor:
        yield client, constructor


class TestSessionCreate:
    def test_create_without_firmware(
        self, mock_client: tuple[MagicMock, Any], tmp_path: Path
    ) -> None:
        client, _ = mock_client
        client.create_session.return_value = {
            "session_id": "sess_abc",
            "status": "creating",
            "label": None,
        }
        config_path = tmp_path / "picolayer.yml"
        config_path.write_text("board: nrf52840dk\n")

        result = runner.invoke(
            app,
            ["session", "create", "--config", str(config_path), "--json"],
        )
        assert result.exit_code == 0, result.output
        payload = json.loads(result.stdout)
        assert payload["ok"] is True
        assert payload["session"]["session_id"] == "sess_abc"
        client.create_session.assert_called_once()

    def test_create_with_firmware_uploads_first(
        self, mock_client: tuple[MagicMock, Any], tmp_path: Path
    ) -> None:
        client, _ = mock_client
        client.upload_file.return_value = "https://presigned/firmware.elf"
        client.create_session.return_value = {
            "session_id": "sess_xyz",
            "status": "creating",
        }
        config_path = tmp_path / "picolayer.yml"
        config_path.write_text("board: nrf52840dk\n")
        firmware = tmp_path / "fw.elf"
        firmware.write_bytes(b"\x7fELF")

        result = runner.invoke(
            app,
            [
                "session",
                "create",
                "--config",
                str(config_path),
                "--firmware",
                str(firmware),
                "--json",
            ],
        )
        assert result.exit_code == 0
        client.upload_file.assert_called_once_with(firmware)
        call = client.create_session.call_args
        assert call.kwargs["firmware_url"] == "https://presigned/firmware.elf"
        assert call.kwargs["firmware_name"] == "fw.elf"

    def test_create_missing_config(
        self, mock_client: tuple[MagicMock, Any], tmp_path: Path
    ) -> None:
        result = runner.invoke(
            app,
            [
                "session",
                "create",
                "--config",
                str(tmp_path / "missing.yml"),
                "--json",
            ],
        )
        assert result.exit_code != 0
        payload = json.loads(result.stdout)
        assert "Config not found" in payload["error"]


class TestSessionList:
    def test_list_default(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.list_sessions.return_value = [
            {
                "session_id": "sess_1",
                "status": "running",
                "created_by_email": "alice@co",
                "duration_seconds": 30,
            }
        ]
        result = runner.invoke(app, ["session", "list", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        assert len(payload["sessions"]) == 1

    def test_only_mine(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.list_sessions.return_value = []
        runner.invoke(app, ["session", "list", "--only-mine", "--json"])
        call = client.list_sessions.call_args
        assert call.kwargs["created_by"] == "me"


class TestSessionStatusAndDestroy:
    def test_status(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.get_session.return_value = {
            "session_id": "sess_a",
            "status": "ready",
        }
        result = runner.invoke(app, ["session", "status", "sess_a", "--json"])
        assert result.exit_code == 0
        assert json.loads(result.stdout)["session"]["status"] == "ready"

    def test_destroy(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.destroy_session.return_value = {"session_id": "sess_a", "status": "ended"}
        result = runner.invoke(app, ["session", "destroy", "sess_a", "--json"])
        assert result.exit_code == 0
        assert json.loads(result.stdout)["ok"] is True


class TestSessionInteraction:
    def test_monitor_command(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.session_proxy.return_value = {"stdout": "OK", "stderr": "", "ok": True}
        result = runner.invoke(
            app,
            ["session", "monitor", "sess_a", "sysbus ReadByte 0x20000000", "--json"],
        )
        assert result.exit_code == 0
        call = client.session_proxy.call_args
        assert call.args[0] == "sess_a"
        assert call.args[1] == "/monitor"
        assert call.kwargs["json_body"]["command"] == "sysbus ReadByte 0x20000000"

    def test_start_with_duration(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.session_proxy.return_value = {"state": "running"}
        result = runner.invoke(app, ["session", "start", "sess_a", "--duration", "5", "--json"])
        assert result.exit_code == 0
        call = client.session_proxy.call_args
        assert call.kwargs["json_body"]["duration_seconds"] == 5.0

    def test_step(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.session_proxy.return_value = {"stepped": 100}
        result = runner.invoke(app, ["session", "step", "sess_a", "--count", "100", "--json"])
        assert result.exit_code == 0

    def test_memory_parses_hex(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.session_proxy.return_value = {"raw": "00 11 22"}
        result = runner.invoke(
            app,
            [
                "session",
                "memory",
                "sess_a",
                "--address",
                "0x20000000",
                "--length",
                "16",
                "--json",
            ],
        )
        assert result.exit_code == 0
        call = client.session_proxy.call_args
        assert call.kwargs["json_body"]["address"] == 0x20000000
        assert call.kwargs["json_body"]["length"] == 16

    def test_memory_invalid_address(self, mock_client: tuple[MagicMock, Any]) -> None:
        result = runner.invoke(
            app,
            [
                "session",
                "memory",
                "sess_a",
                "--address",
                "garbage",
                "--length",
                "16",
                "--json",
            ],
        )
        assert result.exit_code != 0

    def test_uart_with_since(self, mock_client: tuple[MagicMock, Any]) -> None:
        client, _ = mock_client
        client.session_proxy.return_value = {"text": "Boot OK\n"}
        result = runner.invoke(
            app, ["session", "uart", "sess_a", "--name", "uart0", "--since", "100", "--json"]
        )
        assert result.exit_code == 0
        call = client.session_proxy.call_args
        assert call.kwargs["params"]["since"] == 100


class TestSessionFirmwareAndTest:
    def test_firmware_uploads_then_loads(
        self, mock_client: tuple[MagicMock, Any], tmp_path: Path
    ) -> None:
        client, _ = mock_client
        client.upload_file.return_value = "https://presigned/fw.elf"
        client.session_proxy.return_value = {"loaded": "fw.elf", "state": "firmware_loaded"}
        firmware = tmp_path / "fw.elf"
        firmware.write_bytes(b"\x7fELF")
        result = runner.invoke(
            app,
            ["session", "firmware", "sess_a", "--firmware", str(firmware), "--json"],
        )
        assert result.exit_code == 0
        client.upload_file.assert_called_once_with(firmware)
        call = client.session_proxy.call_args
        assert call.args[1] == "/firmware"

    def test_test_uploads_robot(self, mock_client: tuple[MagicMock, Any], tmp_path: Path) -> None:
        client, _ = mock_client
        client.upload_file.return_value = "https://presigned/test.robot"
        client.session_proxy.return_value = {"summary": {"total": 0}}
        test_script = tmp_path / "test.robot"
        test_script.write_text("*** Test Cases ***\n")
        result = runner.invoke(
            app,
            ["session", "test", "sess_a", "--test-script", str(test_script), "--json"],
        )
        assert result.exit_code == 0
        client.upload_file.assert_called_once_with(test_script)
