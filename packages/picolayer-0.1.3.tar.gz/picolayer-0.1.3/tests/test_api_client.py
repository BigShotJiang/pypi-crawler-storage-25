"""Tests for picolayer.api_client — HTTP client for the Picolayer API."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from picolayer.api_client import (
    ApiError,
    ArtifactList,
    JobInfo,
    PicolayerClient,
)


def _make_transport(
    status_code: int = 200,
    json_data: dict[str, Any] | None = None,
    text: str = "",
) -> httpx.MockTransport:
    """Create a MockTransport returning a fixed response."""

    def handler(request: httpx.Request) -> httpx.Response:
        if json_data is not None:
            return httpx.Response(status_code, json=json_data)
        return httpx.Response(status_code, text=text)

    return httpx.MockTransport(handler)


def _make_client(transport: httpx.MockTransport) -> PicolayerClient:
    """Create a PicolayerClient with a mocked transport."""
    client = PicolayerClient(api_key="test-key", base_url="https://api.test.dev")
    client._client = httpx.Client(
        base_url="https://api.test.dev",
        headers={"Authorization": "Bearer test-key"},
        transport=transport,
    )
    return client


class TestApiError:
    """Tests for the ApiError exception."""

    def test_stores_status_and_detail(self) -> None:
        err = ApiError(401, "Unauthorized")
        assert err.status_code == 401
        assert err.detail == "Unauthorized"
        assert "401" in str(err)
        assert "Unauthorized" in str(err)


class TestJobInfo:
    """Tests for the JobInfo dataclass."""

    def test_defaults(self) -> None:
        job = JobInfo(job_id="j1", status="pending")
        assert job.result is None
        assert job.output is None
        assert job.error_message is None


class TestPicolayerClientContextManager:
    """Tests for context manager protocol."""

    def test_context_manager(self) -> None:
        transport = _make_transport(200, {"status": "ok"})
        client = _make_client(transport)
        with client as c:
            assert c is client
        # After exiting, the underlying client should be closed
        assert client._client.is_closed


class TestValidateAuth:
    """Tests for PicolayerClient.validate_auth."""

    def test_returns_true_on_200(self) -> None:
        transport = _make_transport(200, {"jobs": []})
        client = _make_client(transport)
        assert client.validate_auth() is True

    def test_returns_false_on_401(self) -> None:
        transport = _make_transport(401, {"detail": "Unauthorized"})
        client = _make_client(transport)
        assert client.validate_auth() is False

    def test_returns_false_on_403(self) -> None:
        transport = _make_transport(403, {"detail": "Forbidden"})
        client = _make_client(transport)
        assert client.validate_auth() is False


class TestUploadFile:
    """Tests for PicolayerClient.upload_file."""

    def test_returns_url(self, tmp_path: Path) -> None:
        firmware = tmp_path / "test.elf"
        firmware.write_bytes(b"\x7fELF")

        transport = _make_transport(200, {"url": "https://s3.example.com/test.elf"})
        client = _make_client(transport)
        url = client.upload_file(firmware)
        assert url == "https://s3.example.com/test.elf"

    def test_raises_on_error(self, tmp_path: Path) -> None:
        firmware = tmp_path / "test.elf"
        firmware.write_bytes(b"\x7fELF")

        transport = _make_transport(500, {"detail": "Internal Server Error"})
        client = _make_client(transport)
        with pytest.raises(ApiError) as exc_info:
            client.upload_file(firmware)
        assert exc_info.value.status_code == 500


class TestSubmitJob:
    """Tests for PicolayerClient.submit_job."""

    def test_returns_job_info(self) -> None:
        response_data = {
            "job_id": "job-xyz",
            "status": "pending",
            "result": None,
            "output": None,
            "error_message": None,
        }
        transport = _make_transport(200, response_data)
        client = _make_client(transport)

        job = client.submit_job(firmware_url="https://s3.example.com/fw.elf")
        assert job.job_id == "job-xyz"
        assert job.status == "pending"

    def test_passes_optional_params(self) -> None:
        """Verify optional parameters are included in the request body."""
        captured_body: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json

            captured_body.update(json.loads(request.content))
            return httpx.Response(
                200,
                json={
                    "job_id": "j1",
                    "status": "pending",
                },
            )

        transport = httpx.MockTransport(handler)
        client = _make_client(transport)

        client.submit_job(
            firmware_url="https://example.com/fw.elf",
            test_script="my_test.robot",
            test_script_url="https://example.com/test.robot",
            test_type="auto",
            timeout_seconds=600,
            picolayer_config="board: stm32f4_discovery",
        )

        assert captured_body["firmware_url"] == "https://example.com/fw.elf"
        assert captured_body["test_script"] == "my_test.robot"
        assert captured_body["test_script_url"] == "https://example.com/test.robot"
        assert captured_body["timeout_seconds"] == 600
        assert captured_body["picolayer_config"] == "board: stm32f4_discovery"

    def test_raises_on_error(self) -> None:
        transport = _make_transport(422, {"detail": "Validation error"})
        client = _make_client(transport)
        with pytest.raises(ApiError) as exc_info:
            client.submit_job(firmware_url="https://example.com/fw.elf")
        assert exc_info.value.status_code == 422


class TestGetJob:
    """Tests for PicolayerClient.get_job."""

    def test_returns_job_info(self) -> None:
        response_data = {
            "job_id": "job-abc",
            "status": "completed",
            "result": "passed",
            "output": "All tests passed",
            "error_message": None,
        }
        transport = _make_transport(200, response_data)
        client = _make_client(transport)
        job = client.get_job("job-abc")
        assert job.job_id == "job-abc"
        assert job.status == "completed"
        assert job.result == "passed"

    def test_raises_on_404(self) -> None:
        transport = _make_transport(404, {"detail": "Job not found"})
        client = _make_client(transport)
        with pytest.raises(ApiError) as exc_info:
            client.get_job("nonexistent")
        assert exc_info.value.status_code == 404


class TestGetArtifacts:
    """Tests for PicolayerClient.get_artifacts."""

    def test_returns_artifact_list(self) -> None:
        response_data = {
            "job_id": "job-abc",
            "artifacts": [
                {
                    "name": "log.xml",
                    "size_bytes": 2048,
                    "content_type": "application/xml",
                    "download_url": "https://s3.example.com/log.xml",
                },
                {
                    "name": "output.txt",
                    "size_bytes": 512,
                    "content_type": "text/plain",
                    "download_url": "https://s3.example.com/output.txt",
                },
            ],
            "is_streaming": False,
        }
        transport = _make_transport(200, response_data)
        client = _make_client(transport)

        result = client.get_artifacts("job-abc")
        assert result.job_id == "job-abc"
        assert len(result.artifacts) == 2
        assert result.artifacts[0].name == "log.xml"
        assert result.artifacts[1].size_bytes == 512
        assert result.is_streaming is False

    def test_empty_artifacts(self) -> None:
        response_data = {
            "job_id": "job-abc",
            "artifacts": [],
            "is_streaming": False,
        }
        transport = _make_transport(200, response_data)
        client = _make_client(transport)
        result = client.get_artifacts("job-abc")
        assert len(result.artifacts) == 0


class TestRaiseForStatus:
    """Tests for the _raise_for_status internal method."""

    def test_no_raise_on_success(self) -> None:
        transport = _make_transport(200, {"ok": True})
        client = _make_client(transport)
        resp = httpx.Response(200, json={"ok": True})
        # Should not raise
        client._raise_for_status(resp)

    def test_raises_with_detail_from_json(self) -> None:
        transport = _make_transport(400)
        client = _make_client(transport)
        resp = httpx.Response(400, json={"detail": "Bad request body"})
        with pytest.raises(ApiError) as exc_info:
            client._raise_for_status(resp)
        assert exc_info.value.detail == "Bad request body"

    def test_raises_with_message_fallback(self) -> None:
        transport = _make_transport(500)
        client = _make_client(transport)
        resp = httpx.Response(500, json={"message": "Server error"})
        with pytest.raises(ApiError) as exc_info:
            client._raise_for_status(resp)
        assert exc_info.value.detail == "Server error"

    def test_raises_with_text_fallback(self) -> None:
        transport = _make_transport(502)
        client = _make_client(transport)
        resp = httpx.Response(502, text="Bad Gateway")
        with pytest.raises(ApiError) as exc_info:
            client._raise_for_status(resp)
        assert "Bad Gateway" in exc_info.value.detail
