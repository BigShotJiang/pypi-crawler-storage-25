"""Hatchling build hook — stages board_catalog.json into the package before building.

When building from the monorepo, copies ../platforms/board_catalog.json into
picolayer/data/ so it is bundled into both the sdist and the wheel.  When
building a wheel from an already-built sdist (e.g. the second stage of
``uv build``), the file is already present in the extracted sdist tree and the
copy is skipped.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class CustomBuildHook(BuildHookInterface):
    def initialize(self, version: str, build_data: dict[str, Any]) -> None:
        root = Path(self.root)
        dst = root / "picolayer" / "data" / "board_catalog.json"

        src = root.parent / "platforms" / "board_catalog.json"
        if src.exists():
            # Monorepo build — always copy so stale builds are impossible.
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        elif not dst.exists():
            raise FileNotFoundError(
                "board_catalog.json not found. Build from the monorepo root, or "
                "copy it manually: cp ../platforms/board_catalog.json picolayer/data/board_catalog.json"
            )

        # Force inclusion regardless of hatchling include/exclude rules.
        build_data["force_include"][str(dst)] = "picolayer/data/board_catalog.json"
