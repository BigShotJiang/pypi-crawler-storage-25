"""Allow running as ``python -m picolayer``."""

from picolayer.app import main

main()
