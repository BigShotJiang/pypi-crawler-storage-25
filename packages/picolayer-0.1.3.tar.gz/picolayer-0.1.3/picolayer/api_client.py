"""HTTP client for the Picolayer API."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx


class ApiError(Exception):
    """Raised when the API returns an error response."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"API error {status_code}: {detail}")


@dataclass
class JobInfo:
    """Minimal job information returned by the API."""

    job_id: str
    status: str
    result: str | None = None
    output: str | None = None
    error_message: str | None = None


@dataclass
class ArtifactInfo:
    """A downloadable artifact."""

    name: str
    size_bytes: int
    content_type: str
    download_url: str


@dataclass
class ArtifactList:
    """Response from the artifacts endpoint."""

    job_id: str
    artifacts: list[ArtifactInfo]
    is_streaming: bool


class PicolayerClient:
    """Thin wrapper around the Picolayer REST API."""

    def __init__(self, api_key: str, base_url: str) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> PicolayerClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            try:
                body = resp.json()
                detail = body.get("detail", body.get("message", resp.text))
            except Exception:
                detail = resp.text
            raise ApiError(resp.status_code, str(detail))

    def validate_auth(self) -> bool:
        """Return True if the stored API key is valid."""
        resp = self._client.get("/api/v1/jobs", params={"limit": 1})
        return resp.status_code == 200

    def upload_file(self, path: Path) -> str:
        """Upload a file and return the presigned download URL."""
        with open(path, "rb") as f:
            resp = self._client.post(
                "/api/v1/upload",
                files={"file": (path.name, f)},
            )
        self._raise_for_status(resp)
        return str(resp.json()["url"])

    def submit_job(
        self,
        *,
        firmware_url: str,
        test_script: str = "test.robot",
        test_script_url: str | None = None,
        test_type: str = "auto",
        timeout_seconds: int | None = None,
        picolayer_config: str | None = None,
    ) -> JobInfo:
        """Submit a test job and return its info."""
        body: dict[str, Any] = {
            "firmware_url": firmware_url,
            "test_script": test_script,
            "test_type": test_type,
        }
        if test_script_url:
            body["test_script_url"] = test_script_url
        if timeout_seconds:
            body["timeout_seconds"] = timeout_seconds
        if picolayer_config:
            body["picolayer_config"] = picolayer_config

        resp = self._client.post("/api/v1/jobs", json=body)
        self._raise_for_status(resp)
        data = resp.json()
        return JobInfo(
            job_id=data["job_id"],
            status=data["status"],
            result=data.get("result"),
            output=data.get("output"),
            error_message=data.get("error_message"),
        )

    def get_job(self, job_id: str) -> JobInfo:
        """Fetch current job status."""
        resp = self._client.get(f"/api/v1/jobs/{job_id}")
        self._raise_for_status(resp)
        data = resp.json()
        return JobInfo(
            job_id=data["job_id"],
            status=data["status"],
            result=data.get("result"),
            output=data.get("output"),
            error_message=data.get("error_message"),
        )

    def get_artifacts(self, job_id: str) -> ArtifactList:
        """List artifacts for a job."""
        resp = self._client.get(f"/api/v1/jobs/{job_id}/artifacts")
        self._raise_for_status(resp)
        data = resp.json()
        artifacts = [
            ArtifactInfo(
                name=a["name"],
                size_bytes=a["size_bytes"],
                content_type=a["content_type"],
                download_url=a["download_url"],
            )
            for a in data["artifacts"]
        ]
        return ArtifactList(
            job_id=data["job_id"],
            artifacts=artifacts,
            is_streaming=data.get("is_streaming", False),
        )

    def download_artifact(self, url: str, dest: Path) -> None:
        """Download an artifact to a local path."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        with httpx.stream("GET", url) as resp:
            resp.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in resp.iter_bytes():
                    f.write(chunk)

    # ── Sessions (P1.3 — Use Case B) ─────────────────────────────────

    def create_session(
        self,
        *,
        picolayer_config: str,
        firmware_url: str | None = None,
        firmware_name: str | None = None,
        label: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"picolayer_config": picolayer_config}
        if firmware_url and firmware_name:
            body["firmware_url"] = firmware_url
            body["firmware_name"] = firmware_name
        if label:
            body["label"] = label
        resp = self._client.post("/api/v1/sessions", json=body)
        self._raise_for_status(resp)
        return dict(resp.json())

    def list_sessions(
        self,
        *,
        status: str | None = None,
        created_by: str | None = None,
        limit: int = 25,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        if created_by:
            params["created_by"] = created_by
        resp = self._client.get("/api/v1/sessions", params=params)
        self._raise_for_status(resp)
        data = resp.json()
        return list(data.get("sessions", []))

    def get_session(self, session_id: str) -> dict[str, Any]:
        resp = self._client.get(f"/api/v1/sessions/{session_id}")
        self._raise_for_status(resp)
        return dict(resp.json())

    def destroy_session(self, session_id: str) -> dict[str, Any]:
        resp = self._client.delete(f"/api/v1/sessions/{session_id}")
        self._raise_for_status(resp)
        return dict(resp.json()) if resp.text else {}

    def session_proxy(
        self,
        session_id: str,
        path: str,
        *,
        method: str = "POST",
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"/api/v1/sessions/{session_id}{path}"
        resp = self._client.request(method, url, json=json_body, params=params)
        self._raise_for_status(resp)
        return dict(resp.json()) if resp.text else {}
