"""Embedded board catalog for interactive board selection.

Loads from the canonical ``platforms/board_catalog.json`` so the CLI and the
executor (``containers/renode-executor/board_catalog/catalog.py``) share a
single source of truth. The JSON file is bundled into the wheel via
``[tool.hatch.build.force-include]`` in ``cli/pyproject.toml`` and copied to
``picolayer/data/board_catalog.json``.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from importlib import resources
from pathlib import Path


@dataclass(frozen=True)
class BoardInfo:
    """Lightweight board metadata for CLI display."""

    name: str
    display_name: str
    mcu: str
    architecture: str
    description: str


def _candidate_catalog_paths(here: Path | None = None) -> list[Path]:
    """Search paths for ``board_catalog.json``, in priority order.

    ``here`` is exposed for unit tests so they can pin a fake module
    location (e.g. a shallow path) without touching the filesystem.
    """
    candidates: list[Path] = []
    env_override = os.environ.get("PICOLAYER_BOARD_CATALOG")
    if env_override:
        candidates.append(Path(env_override))
    if here is None:
        here = Path(__file__).resolve()
    # Walk every ancestor; never index parents[N] directly because shallow
    # paths (e.g. /app/picolayer/boards.py) would IndexError.
    for parent in here.parents:
        candidates.append(parent / "platforms" / "board_catalog.json")
    return candidates


def _read_catalog_bytes() -> str:
    """Read the catalog JSON from filesystem or packaged resources."""
    for candidate in _candidate_catalog_paths():
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8")
    # Packaged install: bundled at picolayer/data/board_catalog.json
    try:
        return (
            resources.files("picolayer.data")
            .joinpath("board_catalog.json")
            .read_text(encoding="utf-8")
        )
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        raise FileNotFoundError(
            "Could not locate platforms/board_catalog.json. Set "
            "PICOLAYER_BOARD_CATALOG to override the search path."
        ) from exc


def _load_boards() -> list[BoardInfo]:
    """Load and dedupe board entries from the canonical JSON.

    Aliases (entries with the same ``renode_platform``) are collapsed so the
    CLI shows each physical board exactly once.
    """
    raw = json.loads(_read_catalog_bytes())
    entries = raw.get("boards", [])
    if not isinstance(entries, list):
        raise ValueError("board_catalog.json: 'boards' must be a list")

    seen_platforms: set[str] = set()
    boards: list[BoardInfo] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        platform = str(entry.get("renode_platform", ""))
        if platform in seen_platforms:
            continue
        seen_platforms.add(platform)
        boards.append(
            BoardInfo(
                name=str(entry["name"]),
                display_name=str(entry["display_name"]),
                mcu=str(entry["mcu"]),
                architecture=str(entry["architecture"]),
                description=str(entry["description"]),
            )
        )
    return boards


# Eagerly populated at import time. Tests that override PICOLAYER_BOARD_CATALOG
# should call reload_boards() afterwards.
BOARDS: list[BoardInfo] = _load_boards()
BOARD_NAMES: list[str] = [b.name for b in BOARDS]


def reload_boards() -> None:
    """Reload BOARDS from disk. Used by tests."""
    global BOARDS, BOARD_NAMES
    BOARDS = _load_boards()
    BOARD_NAMES = [b.name for b in BOARDS]


def get_board(name: str) -> BoardInfo | None:
    """Look up a board by name (case-insensitive, hyphens/underscores normalized)."""
    if not name:
        return None
    normalized = name.lower().replace("-", "_")
    for board in BOARDS:
        if board.name == normalized:
            return board
    return None
