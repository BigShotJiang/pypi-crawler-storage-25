"""``picolayer list-boards`` — print the supported board catalog."""

from __future__ import annotations

import json
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from picolayer.boards import BOARDS

console = Console()


def list_boards(
    json_output: Annotated[
        bool, typer.Option("--json", help="Emit JSON instead of a table")
    ] = False,
) -> None:
    """List all boards supported by Picolayer."""
    if json_output:
        typer.echo(
            json.dumps(
                {
                    "ok": True,
                    "count": len(BOARDS),
                    "boards": [
                        {
                            "name": b.name,
                            "display_name": b.display_name,
                            "mcu": b.mcu,
                            "architecture": b.architecture,
                            "description": b.description,
                        }
                        for b in BOARDS
                    ],
                }
            )
        )
        return

    table = Table(title="Supported Boards", show_lines=False)
    table.add_column("Name", style="cyan")
    table.add_column("Display Name")
    table.add_column("MCU", style="green")
    table.add_column("Architecture", style="magenta")
    table.add_column("Description")
    for b in BOARDS:
        table.add_row(b.name, b.display_name, b.mcu, b.architecture, b.description)
    console.print(table)
