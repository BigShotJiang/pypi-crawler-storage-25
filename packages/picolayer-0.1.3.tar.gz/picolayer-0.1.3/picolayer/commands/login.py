"""``picolayer login`` — authenticate with the Picolayer API."""

from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

from picolayer.api_client import ApiError, PicolayerClient
from picolayer.config import DEFAULT_API_ENDPOINT, get_api_key, load_config, save_config

console = Console()


def login(
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", help="API key (prompted if omitted)"),
    ] = None,
    api_endpoint: Annotated[
        str,
        typer.Option("--api-endpoint", help="API endpoint URL"),
    ] = DEFAULT_API_ENDPOINT,
) -> None:
    """Store an API key and verify it against the Picolayer API."""
    existing = get_api_key()
    if existing and not api_key:
        console.print("[yellow]You are already logged in.[/yellow]")
        if not typer.confirm("Replace the existing API key?"):
            raise typer.Abort()

    if not api_key:
        api_key = typer.prompt("API key", hide_input=True)

    # Validate
    console.print("Validating API key...")
    try:
        with PicolayerClient(api_key, api_endpoint) as client:
            if not client.validate_auth():
                console.print("[red]Invalid API key.[/red]")
                raise typer.Exit(code=1)
    except ApiError as e:
        console.print(f"[red]Authentication failed: {e.detail}[/red]")
        raise typer.Exit(code=1) from None

    # Store
    cfg = load_config()
    cfg["auth"] = {"api_key": api_key, "api_endpoint": api_endpoint}
    save_config(cfg)

    console.print("[green]Logged in successfully.[/green]")
