"""``picolayer session ...`` — interactive session command group (P1.5).

Mirrors the MCP session toolset and the session API endpoints. All commands
support ``--json`` for non-interactive use. Disjoint from ``picolayer test``
which is the job (Use Case A) entry point.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.table import Table

console = Console()

session_app = typer.Typer(
    name="session",
    help="Interactive Renode sessions (Use Case B).",
    no_args_is_help=True,
)


def _emit_error(message: str, json_output: bool, code: int = 1) -> None:
    if json_output:
        typer.echo(json.dumps({"ok": False, "error": message}))
    else:
        console.print(f"[red]{message}[/red]")
    raise typer.Exit(code=code)


def _emit_json(payload: dict[str, Any]) -> None:
    typer.echo(json.dumps(payload))


def _client():  # type: ignore[no-untyped-def]
    from picolayer.api_client import PicolayerClient
    from picolayer.config import get_api_endpoint, get_api_key

    api_key = get_api_key()
    if not api_key:
        return None
    return PicolayerClient(api_key, get_api_endpoint())


def _require_client(json_output: bool):  # type: ignore[no-untyped-def]
    client = _client()
    if client is None:
        _emit_error("Not logged in. Run `picolayer login` first.", json_output)
    return client


@session_app.command("create")
def create(
    config: Annotated[Path, typer.Option("--config", "-c", help="Path to picolayer.yml")] = Path(
        "picolayer.yml"
    ),
    firmware: Annotated[
        Path | None,
        typer.Option("--firmware", "-f", help="Optional firmware ELF to load on creation"),
    ] = None,
    label: Annotated[
        str | None, typer.Option("--label", help="Optional human-readable label")
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Create a new persistent Renode session."""
    if not config.exists():
        _emit_error(f"Config not found: {config}", json_output)
    config_text = config.read_text()
    if firmware and not firmware.exists():
        _emit_error(f"Firmware not found: {firmware}", json_output)

    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            firmware_url = None
            firmware_name = None
            if firmware:
                firmware_url = client.upload_file(firmware)
                firmware_name = firmware.name
            session = client.create_session(
                picolayer_config=config_text,
                firmware_url=firmware_url,
                firmware_name=firmware_name,
                label=label,
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "session": session})
    else:
        console.print(f"[green]Created session[/green] {session['session_id']}")
        console.print(f"  status: [yellow]{session['status']}[/yellow]")
        if session.get("label"):
            console.print(f"  label: {session['label']}")


@session_app.command("list")
def list_cmd(
    status: Annotated[str | None, typer.Option("--status", help="Filter by status")] = None,
    only_mine: Annotated[
        bool, typer.Option("--only-mine", help="Only show sessions I created")
    ] = False,
    limit: Annotated[int, typer.Option("--limit", help="Max rows")] = 25,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """List the current org's sessions."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            sessions = client.list_sessions(
                status=status,
                created_by="me" if only_mine else None,
                limit=limit,
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "sessions": sessions})
        return

    if not sessions:
        console.print("[dim]No sessions yet.[/dim]")
        return
    table = Table(title="Sessions")
    table.add_column("ID", style="cyan")
    table.add_column("Status", style="yellow")
    table.add_column("Author")
    table.add_column("Started")
    table.add_column("Duration")
    for s in sessions:
        table.add_row(
            s.get("session_id", ""),
            s.get("status", ""),
            s.get("created_by_name") or s.get("created_by_email") or s.get("created_by") or "—",
            str(s.get("started_at") or "—"),
            f"{s.get('duration_seconds') or 0:.0f}s",
        )
    console.print(table)


@session_app.command("status")
def status_cmd(
    session_id: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Show the status of a single session."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            session = client.get_session(session_id)
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "session": session})
    else:
        console.print(json.dumps(session, indent=2))


@session_app.command("destroy")
def destroy(
    session_id: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Stop a session and tear down its container."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.destroy_session(session_id)
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "session": result})
    else:
        console.print(f"[green]Destroyed[/green] {session_id}")


@session_app.command("firmware")
def firmware_cmd(
    session_id: str,
    firmware: Annotated[Path, typer.Option("--firmware", "-f", help="ELF to load")],
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Upload and load a firmware ELF into a session."""
    if not firmware.exists():
        _emit_error(f"Firmware not found: {firmware}", json_output)

    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            firmware_url = client.upload_file(firmware)
            result = client.session_proxy(
                session_id,
                "/firmware",
                method="POST",
                json_body={
                    "firmware_url": firmware_url,
                    "firmware_name": firmware.name,
                },
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[green]Loaded[/green] {firmware.name} into {session_id}")


@session_app.command("monitor")
def monitor_cmd(
    session_id: str,
    command: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Execute an arbitrary Renode Monitor command."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/monitor",
                method="POST",
                json_body={"command": command, "source": "cli"},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        if result.get("stdout"):
            console.print(result["stdout"])
        if result.get("stderr"):
            console.print(f"[red]{result['stderr']}[/red]")


@session_app.command("start")
def start_cmd(
    session_id: str,
    duration: Annotated[
        float | None, typer.Option("--duration", "-d", help="Run-for duration in seconds")
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Start emulation."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/emulation/start",
                method="POST",
                json_body={"duration_seconds": duration},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[green]Started[/green] {session_id}")


@session_app.command("pause")
def pause_cmd(
    session_id: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Pause emulation."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(session_id, "/emulation/pause", method="POST")
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[yellow]Paused[/yellow] {session_id}")


@session_app.command("step")
def step_cmd(
    session_id: str,
    count: Annotated[int, typer.Option("--count", "-n")] = 1,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Step N CPU instructions."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/emulation/step",
                method="POST",
                json_body={"count": count},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"Stepped {count} instructions in {session_id}")


@session_app.command("registers")
def registers_cmd(
    session_id: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Read all CPU registers."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(session_id, "/registers", method="GET")
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(result.get("registers_dump", json.dumps(result, indent=2)))


@session_app.command("memory")
def memory_cmd(
    session_id: str,
    address: Annotated[str, typer.Option("--address", "-a", help="Hex or decimal start address")],
    length: Annotated[int, typer.Option("--length", "-l", help="Bytes to read")] = 64,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Read memory at a given address."""
    from picolayer.api_client import ApiError

    try:
        addr_int = int(address, 0)
    except ValueError:
        _emit_error(f"Invalid address: {address!r}", json_output)
        return

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/memory",
                method="POST",
                json_body={"address": addr_int, "length": length},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(json.dumps(result, indent=2))


@session_app.command("uart")
def uart_cmd(
    session_id: str,
    name: Annotated[str, typer.Option("--name", "-n")] = "uart0",
    since: Annotated[int, typer.Option("--since")] = 0,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Read a UART transcript from a byte offset."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                f"/uart/{name}",
                method="GET",
                params={"since": since},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(result.get("text", ""))


@session_app.command("reload")
def reload_cmd(
    session_id: str,
    firmware: Annotated[Path, typer.Option("--firmware", "-f", help="ELF to hot-reload")],
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Hot-reload firmware (P2.1) — pause + reset + load without losing the session."""
    if not firmware.exists():
        _emit_error(f"Firmware not found: {firmware}", json_output)

    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            firmware_url = client.upload_file(firmware)
            result = client.session_proxy(
                session_id,
                "/hot-reload",
                method="POST",
                json_body={
                    "firmware_url": firmware_url,
                    "firmware_name": firmware.name,
                },
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[green]Hot-reloaded[/green] {firmware.name} into {session_id}")


@session_app.command("register")
def register_by_name_cmd(
    session_id: str,
    name: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Read a single CPU register by name (P2.2)."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(session_id, f"/registers/{name}", method="GET")
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"{name} = {result.get('value', '')}")


@session_app.command("peripherals")
def peripherals_cmd(
    session_id: str,
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="Read one peripheral instead of listing"),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """List peripherals or read one (P2.2)."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    path = f"/peripherals/{name}" if name else "/peripherals"
    try:
        with client:
            result = client.session_proxy(session_id, path, method="GET")
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(result.get("raw", json.dumps(result, indent=2)))


@session_app.command("snapshot-create")
def snapshot_create_cmd(
    session_id: str,
    name: Annotated[str, typer.Option("--name", help="Snapshot label")],
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """P3.1 — save the current machine state."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/snapshots",
                method="POST",
                json_body={"snapshot_id": name, "name": name},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[green]Snapshot {name} created[/green] for {session_id}")


@session_app.command("snapshot-restore")
def snapshot_restore_cmd(
    session_id: str,
    snapshot_id: str,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """P3.1 — restore a previously created snapshot."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                f"/snapshots/{snapshot_id}/restore",
                method="POST",
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[green]Restored[/green] {snapshot_id} on {session_id}")


@session_app.command("trace-start")
def trace_start_cmd(
    session_id: str,
    trace_id: Annotated[str, typer.Option("--trace-id", help="Trace label")] = "trace1",
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """P3.2 — begin instruction-level execution tracing."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/tracing/start",
                method="POST",
                json_body={"trace_id": trace_id},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[green]Tracing started[/green] {trace_id}")


@session_app.command("trace-stop")
def trace_stop_cmd(
    session_id: str,
    trace_id: Annotated[str, typer.Option("--trace-id", help="Trace label")] = "trace1",
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """P3.2 — stop tracing and finalise the trace file."""
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(
                session_id,
                "/tracing/stop",
                method="POST",
                json_body={"trace_id": trace_id},
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"[yellow]Tracing stopped[/yellow] {trace_id}")


@session_app.command("gdb-info")
def gdb_info_cmd(
    session_id: str,
    port: Annotated[int, typer.Option("--port", "-p", help="GDB server port")] = 3333,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """P3.3 — start the GDB server and print connection info.

    The GDB port is reachable only from inside the VPC. Use a VPN or bastion
    to connect with `target remote <host>:<port>`.
    """
    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            result = client.session_proxy(session_id, f"/gdb-info?port={port}", method="GET")
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(f"GDB available at [cyan]{result.get('host')}:{result.get('port')}[/cyan]")
        console.print("[dim]Connect from inside the VPC: target remote <host>:<port>[/dim]")


@session_app.command("test")
def test_cmd(
    session_id: str,
    test_script: Annotated[Path, typer.Option("--test-script", "-t", help="Path to .robot file")],
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Run a Robot Framework test against an existing session."""
    if not test_script.exists():
        _emit_error(f"Test script not found: {test_script}", json_output)

    from picolayer.api_client import ApiError

    client = _require_client(json_output)
    try:
        with client:
            test_url = client.upload_file(test_script)
            result = client.session_proxy(
                session_id,
                "/test",
                method="POST",
                json_body={
                    "test_script_url": test_url,
                    "test_script_name": test_script.name,
                },
            )
    except ApiError as exc:
        _emit_error(str(exc), json_output)

    if json_output:
        _emit_json({"ok": True, "result": result})
    else:
        console.print(json.dumps(result, indent=2))
