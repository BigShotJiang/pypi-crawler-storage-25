"""``picolayer init`` — scaffold a picolayer.yml configuration file."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
import yaml
from rich.console import Console
from rich.table import Table

from picolayer.boards import BOARDS, BoardInfo, get_board

console = Console()


def init(  # noqa: C901  (interactive + JSON branches mean a higher cyclomatic count)
    directory: Annotated[
        Path,
        typer.Argument(help="Project directory (default: current)"),
    ] = Path("."),
    board: Annotated[
        str | None,
        typer.Option(
            "--board",
            "-b",
            help="Skip the interactive picker by providing a board name. "
            "Required when --json is set.",
        ),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Non-interactive mode. Emit a single JSON document on stdout. Requires --board.",
        ),
    ] = False,
    overwrite: Annotated[
        bool,
        typer.Option(
            "--overwrite",
            help="Overwrite an existing picolayer.yml without prompting.",
        ),
    ] = False,
) -> None:
    """Create a picolayer.yml with interactive board selection."""
    config_path = directory / "picolayer.yml"
    if config_path.exists() and not overwrite:
        if json_output:
            typer.echo(
                json.dumps(
                    {
                        "ok": False,
                        "error": f"{config_path} already exists. Use --overwrite to replace it.",
                    }
                )
            )
            raise typer.Exit(code=1)
        console.print(f"[yellow]{config_path} already exists.[/yellow]")
        if not typer.confirm("Overwrite?"):
            raise typer.Abort()

    selected: BoardInfo | None = None
    if board:
        selected = get_board(board)
        if selected is None:
            if json_output:
                typer.echo(json.dumps({"ok": False, "error": f"Unknown board: {board!r}"}))
            else:
                console.print(f"[red]Unknown board '{board}'.[/red]")
            raise typer.Exit(code=1)

    if selected is None:
        if json_output:
            typer.echo(
                json.dumps(
                    {
                        "ok": False,
                        "error": "--json mode requires --board to skip interactive selection",
                    }
                )
            )
            raise typer.Exit(code=1)

        # Interactive mode
        table = Table(title="Supported Boards", show_lines=False)
        table.add_column("#", style="dim", width=4)
        table.add_column("Name", style="cyan")
        table.add_column("Display Name")
        table.add_column("MCU", style="green")
        table.add_column("Architecture", style="magenta")
        for idx, b in enumerate(BOARDS, 1):
            table.add_row(str(idx), b.name, b.display_name, b.mcu, b.architecture)
        console.print(table)
        console.print()

        while selected is None:
            choice = typer.prompt("Select a board (number or name)")
            if choice.isdigit():
                idx = int(choice)
                if 1 <= idx <= len(BOARDS):
                    selected = BOARDS[idx - 1]
                else:
                    console.print(f"[red]Enter a number between 1 and {len(BOARDS)}.[/red]")
            else:
                matched = get_board(choice)
                if matched:
                    selected = matched
                else:
                    console.print(f"[red]Unknown board '{choice}'. Try again.[/red]")

    # Generate picolayer.yml
    config_data = {"board": selected.name, "timeout": 300}
    directory.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)

    if json_output:
        typer.echo(
            json.dumps(
                {
                    "ok": True,
                    "config_path": str(config_path),
                    "board": {
                        "name": selected.name,
                        "display_name": selected.display_name,
                        "mcu": selected.mcu,
                        "architecture": selected.architecture,
                    },
                }
            )
        )
        return

    console.print(f"\n[green]Created {config_path}[/green]")
    console.print(f"  board: [cyan]{selected.name}[/cyan] ({selected.display_name})")
    console.print("\n[dim]Next steps:[/dim]")
    console.print("  1. Add your firmware (.elf) to the project")
    console.print("  2. Write a Robot Framework test (.robot)")
    console.print("  3. Run [bold]picolayer test --firmware <path> --test-script <path>[/bold]")
