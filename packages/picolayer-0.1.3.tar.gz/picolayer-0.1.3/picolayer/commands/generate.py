"""``picolayer generate`` — config and test scaffolding commands.

Two subcommands:

  - ``picolayer generate config --from {template,llm,cad,schematic,datasheet}``
  - ``picolayer generate test --config picolayer.yml``

The full menu is always visible (so the UX surface is stable across releases),
but tiers 1, 2, and 4 fail fast with a "tracked in DEV-XXX" message.
"""

from __future__ import annotations

import json
from enum import StrEnum
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from picolayer.generate import SOURCES
from picolayer.generate.config_source import GenerateContext
from picolayer.generate.test_scaffold import generate_test_scaffold

console = Console()

generate_app = typer.Typer(
    name="generate",
    help="Generate picolayer.yml or test scaffolds.",
    no_args_is_help=True,
)


class _SourceId(StrEnum):
    template = "template"
    llm = "llm"
    cad = "cad"
    schematic = "schematic"
    datasheet = "datasheet"


def _emit_error(message: str, json_output: bool) -> None:
    if json_output:
        typer.echo(json.dumps({"ok": False, "error": message}))
    else:
        console.print(f"[red]{message}[/red]")


@generate_app.command("config")
def generate_config(
    source: Annotated[
        _SourceId,
        typer.Option(
            "--from",
            help=(
                "Generation source: template (5), llm (3), cad (1), schematic "
                "(2), or datasheet (4). Tiers ranked by ergonomics in the plan."
            ),
        ),
    ] = _SourceId.template,
    board: Annotated[
        str | None,
        typer.Option("--board", help="Board name (template source)."),
    ] = None,
    repo: Annotated[
        Path | None,
        typer.Option("--repo", help="Path to a firmware repo (llm source)."),
    ] = None,
    datasheet: Annotated[
        list[Path] | None,
        typer.Option(
            "--datasheet",
            help="Path to a datasheet text file (llm source, may be repeated).",
        ),
    ] = None,
    hint: Annotated[
        str | None,
        typer.Option("--hint", help="Free-form hint for the agent (llm source)."),
    ] = None,
    cad_model: Annotated[
        Path | None,
        typer.Option("--model", help="CAD STEP file (cad source — stub)."),
    ] = None,
    schematic_file: Annotated[
        Path | None,
        typer.Option("--file", help="Schematic file (schematic source — stub)."),
    ] = None,
    datasheet_pdf: Annotated[
        Path | None,
        typer.Option("--pdf", help="Datasheet PDF (datasheet source — stub)."),
    ] = None,
    output: Annotated[
        Path,
        typer.Option("--output", "-o", help="Output path for picolayer.yml."),
    ] = Path("picolayer.yml"),
    overwrite: Annotated[
        bool,
        typer.Option("--overwrite", help="Overwrite the output file if it exists."),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Emit a JSON document on stdout."),
    ] = False,
) -> None:
    """Generate a ``picolayer.yml`` from one of the 5 generation tiers."""
    impl = SOURCES.get(source.value)
    if impl is None:
        _emit_error(f"Unknown generation source: {source.value}", json_output)
        raise typer.Exit(code=1)

    context = GenerateContext(
        output=output,
        board=board,
        repo=repo,
        datasheets=list(datasheet or []),
        hint=hint,
        cad_model=cad_model,
        schematic=schematic_file,
        overwrite=overwrite,
    )
    # The datasheet stub also accepts --pdf as a stand-in for "input file".
    if datasheet_pdf is not None:
        context.datasheets.append(datasheet_pdf)

    result = impl.generate(context)

    if json_output:
        payload: dict[str, object] = {
            "ok": result.ok,
            "source": source.value,
            "config_path": str(result.config_path) if result.config_path else None,
            "notes": list(result.notes),
            "artifacts": {k: str(v) for k, v in result.artifacts.items()},
        }
        if result.error:
            payload["error"] = result.error
        typer.echo(json.dumps(payload))
        if not result.ok:
            raise typer.Exit(code=1)
        return

    if not result.ok:
        console.print(f"[red]{result.error}[/red]")
        raise typer.Exit(code=1)
    if result.config_path:
        console.print(f"[green]Wrote {result.config_path}[/green]")
    for note in result.notes:
        console.print(f"  [dim]{note}[/dim]")
    for name, path in result.artifacts.items():
        console.print(f"  [dim]{name}: {path}[/dim]")


@generate_app.command("test")
def generate_test(
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Path to picolayer.yml"),
    ] = Path("picolayer.yml"),
    output: Annotated[
        Path,
        typer.Option("--output", "-o", help="Output .robot file path"),
    ] = Path("test.robot"),
    overwrite: Annotated[
        bool,
        typer.Option("--overwrite", help="Overwrite the output file if it exists."),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Emit a JSON document on stdout."),
    ] = False,
) -> None:
    """Generate a Robot Framework smoke test for a ``picolayer.yml``."""
    if not config.exists():
        _emit_error(f"Config not found: {config}", json_output)
        raise typer.Exit(code=1)
    if output.exists() and not overwrite:
        _emit_error(f"{output} already exists. Pass --overwrite to replace it.", json_output)
        raise typer.Exit(code=1)
    config_text = config.read_text()
    result = generate_test_scaffold(config_text)
    if not result.ok:
        _emit_error(result.error or "Unknown error generating test", json_output)
        raise typer.Exit(code=1)
    output.parent.mkdir(parents=True, exist_ok=True)
    assert result.text is not None
    output.write_text(result.text)
    if json_output:
        typer.echo(
            json.dumps(
                {
                    "ok": True,
                    "test_path": str(output),
                    "config_path": str(config),
                }
            )
        )
        return
    console.print(f"[green]Wrote {output}[/green]")
    console.print("[dim]This is a smoke test scaffold — extend it as needed.[/dim]")


@generate_app.command("list-sources")
def list_sources(
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Emit a JSON document on stdout."),
    ] = False,
) -> None:
    """List all generation sources (tiers 1–5) and their availability."""
    rows: list[dict[str, object]] = []
    for source in SOURCES.values():
        caps = source.describe()
        rows.append(
            {
                "id": caps.id,
                "tier": caps.tier,
                "label": caps.label,
                "available": caps.available,
                "tracking_issue": caps.tracking_issue,
                "description": caps.description,
            }
        )
    rows.sort(key=lambda r: r["tier"])  # type: ignore[arg-type, return-value]

    if json_output:
        typer.echo(json.dumps({"ok": True, "sources": rows}))
        return

    table = Table(title="picolayer generate sources", show_lines=False)
    table.add_column("Tier", style="dim", width=4)
    table.add_column("ID", style="cyan")
    table.add_column("Label")
    table.add_column("Available", style="green")
    table.add_column("Description")
    for row in rows:
        table.add_row(
            str(row["tier"]),
            str(row["id"]),
            str(row["label"]),
            "✓" if row["available"] else f"stub ({row.get('tracking_issue')})",
            str(row["description"]),
        )
    console.print(table)
