"""Temporary HTTP server for serving local files to Docker containers."""

from __future__ import annotations

import socket
import threading
from collections.abc import Generator
from contextlib import contextmanager
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path


def _find_free_port() -> int:
    """Find a free TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return int(s.getsockname()[1])


class _QuietHandler(SimpleHTTPRequestHandler):
    """HTTP handler that suppresses access logs."""

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        pass


@contextmanager
def serve_directory(directory: Path) -> Generator[int]:
    """Start an HTTP server on a free port, serving *directory*.

    Yields the port number. The server is stopped when the context exits.
    """
    port = _find_free_port()
    handler = partial(_QuietHandler, directory=str(directory))
    server = HTTPServer(("0.0.0.0", port), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield port
    finally:
        server.shutdown()
        thread.join(timeout=5)
