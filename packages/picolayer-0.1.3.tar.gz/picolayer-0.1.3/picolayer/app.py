"""Picolayer CLI application."""

from __future__ import annotations

import typer

from picolayer import __version__
from picolayer.commands.boards import list_boards
from picolayer.commands.generate import generate_app
from picolayer.commands.init import init
from picolayer.commands.login import login
from picolayer.commands.session import session_app
from picolayer.commands.test import test

app = typer.Typer(
    name="picolayer",
    help="Picolayer CLI — scaffold, test, and deploy embedded firmware tests.",
    no_args_is_help=True,
)

app.command()(login)
app.command()(init)
app.command()(test)
app.command("list-boards")(list_boards)
app.add_typer(generate_app)
app.add_typer(session_app)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"picolayer {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True, help="Show version"
    ),
) -> None:
    """Picolayer CLI."""


def main() -> None:
    app()
