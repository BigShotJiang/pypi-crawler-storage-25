"""Read/write ~/.picolayer/config.toml for CLI configuration."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import tomli_w

DEFAULT_API_ENDPOINT = "https://api.picolayer.dev"
CONFIG_DIR = Path.home() / ".picolayer"
CONFIG_PATH = CONFIG_DIR / "config.toml"


def load_config() -> dict[str, Any]:
    """Load the CLI config file, returning an empty dict if missing."""
    if not CONFIG_PATH.exists():
        return {}
    with open(CONFIG_PATH, "rb") as f:
        return tomllib.load(f)


def save_config(data: dict[str, Any]) -> None:
    """Write the CLI config file, creating the directory if needed.

    Sets file permissions to 0o600 (owner-only) since the file may contain API keys.
    """
    import os
    import stat

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "wb") as f:
        tomli_w.dump(data, f)
    os.chmod(CONFIG_PATH, stat.S_IRUSR | stat.S_IWUSR)


def get_api_key() -> str | None:
    """Return the stored API key, or None if not configured."""
    cfg = load_config()
    value = cfg.get("auth", {}).get("api_key")
    return str(value) if value is not None else None


def get_api_endpoint() -> str:
    """Return the configured API endpoint, falling back to the default."""
    cfg = load_config()
    value = cfg.get("auth", {}).get("api_endpoint", DEFAULT_API_ENDPOINT)
    return str(value)
