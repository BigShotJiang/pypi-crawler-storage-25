"""``ConfigSource`` abstraction for the 5-tier ``picolayer.yml`` pathway.

Each tier (template, LLM, CAD, schematic, datasheet) implements
``ConfigSource``. The ``picolayer generate config --from <id>`` CLI looks the
ID up in the global ``SOURCES`` registry and dispatches.

This protocol intentionally lives in ``cli/picolayer/generate/`` rather than
in a shared package: the CLI is the only consumer today, and we don't want
to drag the abstraction into the executor or MCP server. If a future caller
needs it, it can import from here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol


@dataclass
class GenerateContext:
    """Inputs a ``ConfigSource`` may consume.

    Not every source uses every field. ``template_source`` only needs
    ``board``; ``llm_source`` consumes ``repo``, ``datasheets``, and
    ``hint``; ``datasheet_source`` (stub) would consume ``datasheets``; etc.
    """

    output: Path
    board: str | None = None
    repo: Path | None = None
    datasheets: list[Path] = field(default_factory=list)
    hint: str | None = None
    cad_model: Path | None = None
    schematic: Path | None = None
    overwrite: bool = False


@dataclass
class GenerateResult:
    """Result of a ``ConfigSource.generate()`` call."""

    ok: bool
    config_path: Path | None = None
    config_text: str | None = None
    notes: list[str] = field(default_factory=list)
    error: str | None = None
    artifacts: dict[str, Path] = field(default_factory=dict)


@dataclass(frozen=True)
class SourceCapabilities:
    """Static metadata describing a ``ConfigSource``."""

    id: str
    tier: int
    label: str
    description: str
    available: bool
    tracking_issue: str | None = None


class ConfigSource(Protocol):
    """A pluggable provider that turns inputs into a ``picolayer.yml``."""

    def describe(self) -> SourceCapabilities:
        """Return static metadata about this source."""

    def generate(self, context: GenerateContext) -> GenerateResult:
        """Run the source against ``context`` and return a result."""


SOURCES: dict[str, ConfigSource] = {}


def register_source(source: ConfigSource) -> None:
    """Register a ``ConfigSource`` under its capability ID."""
    caps = source.describe()
    SOURCES[caps.id] = source
