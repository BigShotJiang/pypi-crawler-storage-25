"""Tier 1 — DigiKey 3D CAD model → picolayer.yml. Stubbed."""

from __future__ import annotations

from picolayer.generate.config_source import (
    GenerateContext,
    GenerateResult,
    SourceCapabilities,
    register_source,
)


class CadConfigSource:
    def describe(self) -> SourceCapabilities:
        return SourceCapabilities(
            id="cad",
            tier=1,
            label="DigiKey / 3D CAD model",
            description=(
                "Future: extract MCU + peripheral list from a DigiKey-style 3D "
                "CAD model (STEP file). Not yet implemented; tracked in DEV-301."
            ),
            available=False,
            tracking_issue="DEV-301",
        )

    def generate(self, context: GenerateContext) -> GenerateResult:
        return GenerateResult(
            ok=False,
            error=(
                "The CAD source (tier 1) is not yet implemented. Tracked in "
                "DEV-301. For now, use --from llm (tier 3) or --from template "
                "(tier 5)."
            ),
        )


register_source(CadConfigSource())
