"""Tier 2 — board schematic → picolayer.yml. Stubbed."""

from __future__ import annotations

from picolayer.generate.config_source import (
    GenerateContext,
    GenerateResult,
    SourceCapabilities,
    register_source,
)


class SchematicConfigSource:
    def describe(self) -> SourceCapabilities:
        return SourceCapabilities(
            id="schematic",
            tier=2,
            label="Board schematics",
            description=(
                "Future: extract MCU + nets + peripherals from a KiCad / Altium / "
                "Eagle schematic. Not yet implemented; tracked in DEV-302."
            ),
            available=False,
            tracking_issue="DEV-302",
        )

    def generate(self, context: GenerateContext) -> GenerateResult:
        return GenerateResult(
            ok=False,
            error=(
                "The schematic source (tier 2) is not yet implemented. Tracked "
                "in DEV-302. For now, use --from llm (tier 3) or --from template "
                "(tier 5)."
            ),
        )


register_source(SchematicConfigSource())
