"""Tier 5 — hand-written template from the board catalog.

Deterministic. Takes a board name and writes a minimal ``picolayer.yml``.
This is the lowest-friction shipping tier and the right answer when you
already know which board you want.
"""

from __future__ import annotations

import yaml

from picolayer.boards import get_board
from picolayer.generate.config_source import (
    GenerateContext,
    GenerateResult,
    SourceCapabilities,
    register_source,
)


class TemplateConfigSource:
    """Generate a picolayer.yml from a catalog board name."""

    def describe(self) -> SourceCapabilities:
        return SourceCapabilities(
            id="template",
            tier=5,
            label="Catalog template",
            description=(
                "Deterministic minimal config from the board catalog. Takes only --board."
            ),
            available=True,
        )

    def generate(self, context: GenerateContext) -> GenerateResult:
        if not context.board:
            return GenerateResult(
                ok=False,
                error="--board is required for the template source",
            )
        board = get_board(context.board)
        if board is None:
            return GenerateResult(
                ok=False,
                error=(
                    f"Unknown board: {context.board!r}. "
                    "Run `picolayer init` (without --json) to see the catalog."
                ),
            )
        if context.output.exists() and not context.overwrite:
            return GenerateResult(
                ok=False,
                error=(f"{context.output} already exists. Pass --overwrite to replace it."),
            )
        config_data = {"board": board.name, "timeout": 300}
        text = yaml.safe_dump(config_data, sort_keys=False, default_flow_style=False)
        context.output.parent.mkdir(parents=True, exist_ok=True)
        context.output.write_text(text)
        return GenerateResult(
            ok=True,
            config_path=context.output,
            config_text=text,
            notes=[
                f"Wrote a board-shortcut config for {board.display_name}.",
                "Add a `hardware:` block (or `renode:` escape hatch) if you need "
                "more than the catalog defaults.",
            ],
        )


register_source(TemplateConfigSource())
