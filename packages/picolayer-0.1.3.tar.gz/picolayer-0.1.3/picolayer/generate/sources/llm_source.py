"""Tier 3 — LLM generates picolayer.yml from a codebase + datasheets.

This source does NOT actually call an LLM directly. Instead, it bundles a
context an MCP-enabled agent (Claude Code, Cursor, etc.) can read via the
``picolayer://generate-context/{bundle_id}`` resource (planned). The bundle
includes:

- A summary of the repository tree (filenames, sizes)
- The contents of common build/board files: linker scripts, CMakeLists.txt,
  prj.conf, platformio.ini, Zephyr ``.overlay``, device-tree fragments
- Optional user-supplied datasheet text (when --datasheet is passed)
- A short hint string (--hint)

The CLI writes the bundle to ``.picolayer/generate-context.json`` so the
agent (or a follow-up `picolayer generate config --from llm` invocation
that has access to an LLM API) can pick it up.

Why a CLI bundle instead of "just call the LLM": this keeps the CLI usable
in environments without an LLM API key, lets the user choose any agent
(Claude Code, Cursor, OpenAI), and matches the MCP-first design of the
plan — the agent reads the bundle through MCP, not through CLI flags.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

from picolayer.generate.config_source import (
    GenerateContext,
    GenerateResult,
    SourceCapabilities,
    register_source,
)

# Files we always include verbatim in the bundle when present.
INTERESTING_FILENAMES: set[str] = {
    "CMakeLists.txt",
    "Makefile",
    "platformio.ini",
    "prj.conf",
    "west.yml",
    "west.yaml",
    "sdkconfig",
    "Cargo.toml",
    "build.rs",
    "Kconfig",
    "soc.yml",
    "soc.yaml",
}

INTERESTING_SUFFIXES: set[str] = {
    ".ld",  # linker scripts
    ".dts",
    ".dtsi",
    ".overlay",  # Zephyr device-tree
    ".cfg",  # OpenOCD configs
    ".uvprojx",  # Keil project files
}

# Hard cap on how much we put into the bundle so the agent can read it
# without blowing its context window.
MAX_BUNDLE_BYTES = 200 * 1024  # 200 KB
MAX_FILE_BYTES = 16 * 1024  # 16 KB per file


class LlmConfigSource:
    """Bundle a codebase + optional datasheets into a generate context."""

    def describe(self) -> SourceCapabilities:
        return SourceCapabilities(
            id="llm",
            tier=3,
            label="LLM from codebase + datasheets",
            description=(
                "Bundle a repository (and optional datasheet text files) into "
                "an MCP-readable context. An MCP-enabled agent then generates "
                "the picolayer.yml from the bundle."
            ),
            available=True,
        )

    def generate(self, context: GenerateContext) -> GenerateResult:
        if context.repo is None:
            return GenerateResult(
                ok=False,
                error="--repo is required for the llm source",
            )
        repo = context.repo.resolve()
        if not repo.is_dir():
            return GenerateResult(
                ok=False,
                error=f"--repo must be a directory: {repo}",
            )
        bundle_path = repo / ".picolayer" / "generate-context.json"
        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        bundle = self._build_bundle(repo, context.datasheets, context.hint)
        bundle_text = json.dumps(bundle, indent=2)
        bundle_path.write_text(bundle_text)
        return GenerateResult(
            ok=True,
            config_path=None,
            config_text=None,
            artifacts={"context_bundle": bundle_path},
            notes=[
                f"Wrote LLM context bundle to {bundle_path}.",
                (
                    "Now run an MCP-enabled agent (Claude Code / Cursor) and ask it"
                    " to read picolayer://generate-context/<bundle_id> +"
                    " picolayer://config-schema and emit a picolayer.yml."
                ),
                (
                    "If the agent is uncertain it should ask one targeted question"
                    " instead of guessing — that's what the MCP prompt template"
                    " enforces."
                ),
                f"Bundle ID: {bundle['bundle_id']}",
            ],
        )

    def _build_bundle(
        self,
        repo: Path,
        datasheets: list[Path],
        hint: str | None,
    ) -> dict[str, object]:
        files: list[dict[str, object]] = []
        total_bytes = 0
        for path in self._walk(repo):
            try:
                size = path.stat().st_size
            except OSError:
                continue
            entry: dict[str, object] = {
                "path": str(path.relative_to(repo)),
                "size_bytes": size,
            }
            if self._is_interesting(path):
                content = self._read_truncated(path)
                if content is not None:
                    entry["content"] = content
                    total_bytes += len(content)
                    if total_bytes >= MAX_BUNDLE_BYTES:
                        entry["note"] = "bundle size cap reached, content truncated"
                        files.append(entry)
                        break
            files.append(entry)

        datasheet_blocks: list[dict[str, object]] = []
        for ds in datasheets:
            text = self._read_truncated(ds)
            datasheet_blocks.append(
                {
                    "path": str(ds),
                    "content": text or "",
                }
            )

        bundle_id = hashlib.sha256(f"{repo}|{time.time()}".encode()).hexdigest()[:16]

        return {
            "version": 1,
            "bundle_id": bundle_id,
            "repo_root": str(repo),
            "hint": hint or "",
            "files": files,
            "datasheets": datasheet_blocks,
            "instructions": (
                "Use this bundle plus picolayer://board-catalog, "
                "picolayer://config-schema, picolayer://peripheral-types, "
                "and picolayer://cpu-types to generate a picolayer.yml. "
                "Cross-reference detected MCU strings against the catalog. "
                "If no catalog board matches, fall through to the hardware "
                "block. If even that doesn't fit, use the renode: escape "
                "hatch (custom_peripherals / platform_repl_inline). Ask one "
                "targeted question if anything is ambiguous instead of guessing."
            ),
        }

    def _walk(self, repo: Path) -> list[Path]:
        paths: list[Path] = []
        for path in sorted(repo.rglob("*")):
            rel = path.relative_to(repo)
            top = rel.parts[0] if rel.parts else ""
            # Skip junk: VCS, build artifacts, node_modules, virtualenvs, picolayer cache
            if top in {
                ".git",
                ".github",
                ".venv",
                "venv",
                "node_modules",
                "build",
                "dist",
                "target",
                "__pycache__",
                ".picolayer",
            }:
                continue
            if path.is_file():
                paths.append(path)
        return paths

    def _is_interesting(self, path: Path) -> bool:
        if path.name in INTERESTING_FILENAMES:
            return True
        if path.suffix.lower() in INTERESTING_SUFFIXES:
            return True
        return False

    def _read_truncated(self, path: Path) -> str | None:
        try:
            data = path.read_bytes()[:MAX_FILE_BYTES]
            return data.decode("utf-8", errors="replace")
        except OSError:
            return None


register_source(LlmConfigSource())
