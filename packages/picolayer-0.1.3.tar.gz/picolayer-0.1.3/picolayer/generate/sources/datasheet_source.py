"""Tier 4 — datasheet PDF → picolayer.yml. Stubbed."""

from __future__ import annotations

from picolayer.generate.config_source import (
    GenerateContext,
    GenerateResult,
    SourceCapabilities,
    register_source,
)


class DatasheetConfigSource:
    def describe(self) -> SourceCapabilities:
        return SourceCapabilities(
            id="datasheet",
            tier=4,
            label="Datasheets",
            description=(
                "Future: parse a vendor datasheet PDF for memory map, peripheral "
                "registers, and IRQ table. Not yet implemented; tracked in DEV-303. "
                "For now, drop datasheet text into --from llm to feed it to the "
                "agent."
            ),
            available=False,
            tracking_issue="DEV-303",
        )

    def generate(self, context: GenerateContext) -> GenerateResult:
        return GenerateResult(
            ok=False,
            error=(
                "The datasheet source (tier 4) is not yet implemented. Tracked "
                "in DEV-303. For now, use --from llm with --datasheet to feed "
                "datasheet text to an MCP-enabled agent."
            ),
        )


register_source(DatasheetConfigSource())
