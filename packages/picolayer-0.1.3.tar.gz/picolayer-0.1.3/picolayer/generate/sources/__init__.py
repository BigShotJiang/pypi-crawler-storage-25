"""Concrete ``ConfigSource`` implementations for the 5 generation tiers."""
