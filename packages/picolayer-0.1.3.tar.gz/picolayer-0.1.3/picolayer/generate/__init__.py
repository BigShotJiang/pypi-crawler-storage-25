"""``picolayer generate`` — config and test scaffolding.

Implements the **5-tier picolayer.yml generation pathway** described in the
plan:

  1. CAD model → config (stub)
  2. Schematic → config (stub)
  3. LLM from codebase + datasheets (CLI bundles a context for the agent)
  4. Datasheet → config (stub)
  5. Hand-written template (deterministic, board catalog driven)

Tiers 3 and 5 ship now. Tiers 1, 2, and 4 are visible in the CLI surface
(``picolayer generate config --from cad|schematic|datasheet``) but raise
``NotImplementedError`` with a tracking-issue link, so the UX surface and
extension points are stable across releases.

The actual sources live in ``cli/picolayer/generate/sources/``. Each source
implements the ``ConfigSource`` protocol from ``config_source.py``.
"""

from __future__ import annotations

from picolayer.generate.config_source import (
    SOURCES,
    ConfigSource,
    GenerateContext,
    GenerateResult,
    SourceCapabilities,
    register_source,
)
from picolayer.generate.sources import (  # noqa: F401  (each module registers its source)
    cad_source,
    datasheet_source,
    llm_source,
    schematic_source,
    template_source,
)

__all__ = [
    "ConfigSource",
    "GenerateContext",
    "GenerateResult",
    "SOURCES",
    "SourceCapabilities",
    "register_source",
]
