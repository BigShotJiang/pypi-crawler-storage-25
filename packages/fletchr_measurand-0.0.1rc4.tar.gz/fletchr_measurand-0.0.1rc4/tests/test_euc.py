"""Direct tests for `EUC.apply` behavior (Level-2 scaling)."""

import numpy as np
import pytest

from fletchr_measurand import EUC


class TestApplyScalar:
    def test_scale_factor_only(self):
        euc = EUC(scale_factor=0.5)
        np.testing.assert_array_almost_equal(euc.apply(np.array([10.0, 20.0])), [5.0, 10.0])

    def test_scale_and_scaled_bias(self):
        euc = EUC(scale_factor=2.0, scaled_bias=100.0)
        np.testing.assert_array_almost_equal(euc.apply(np.array([10.0])), [120.0])

    def test_data_bias_scale_scaled_bias(self):
        # (x - data_bias) * scale + scaled_bias
        euc = EUC(data_bias=10, scale_factor=5.0, scaled_bias=3.0)
        np.testing.assert_array_almost_equal(euc.apply(np.array([20.0])), [53.0])

    def test_negative_inputs(self):
        euc = EUC(scale_factor=0.1)
        np.testing.assert_array_almost_equal(euc.apply(np.array([-1.0])), [-0.1])


class TestApplyCallable:
    def test_square(self):
        euc = EUC(scale_factor=lambda PV: PV**2)
        np.testing.assert_array_almost_equal(euc.apply(np.array([3.0, 4.0])), [9.0, 16.0])

    def test_callable_with_data_bias(self):
        # data_bias subtracted before callable
        euc = EUC(scale_factor=lambda PV: PV * 10, data_bias=2)
        np.testing.assert_array_almost_equal(
            euc.apply(np.array([5.0])),
            [30.0],  # (5 - 2) * 10
        )


class TestNoMutation:
    def test_input_unchanged(self):
        original = np.array([10.0, 20.0])
        euc = EUC(scale_factor=0.5)
        _ = euc.apply(original)
        np.testing.assert_array_equal(original, [10.0, 20.0])


class TestPostInitVectorize:
    def test_callable_is_vectorized(self):
        """A non-vectorized callable is wrapped by `__post_init__`."""
        euc = EUC(scale_factor=lambda PV: PV + 1)
        # Should accept arrays even though lambda is scalar
        result = euc.apply(np.array([1.0, 2.0, 3.0]))
        np.testing.assert_array_almost_equal(result, [2.0, 3.0, 4.0])


@pytest.mark.parametrize(
    "scale, expected",
    [
        (1.0, [1.0, 2.0, 3.0]),
        (0.5, [0.5, 1.0, 1.5]),
        (2.0, [2.0, 4.0, 6.0]),
        (-1.0, [-1.0, -2.0, -3.0]),
    ],
)
def test_scale_factor_parametrized(scale, expected):
    euc = EUC(scale_factor=scale)
    np.testing.assert_array_almost_equal(euc.apply(np.array([1.0, 2.0, 3.0])), expected)
