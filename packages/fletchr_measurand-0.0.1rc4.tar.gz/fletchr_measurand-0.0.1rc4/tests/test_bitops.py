"""Regression tests pinning the 1-based inclusive bit-numbering convention
used by [fletchr_measurand._bitops.bits_to_mask_and_shift][].

Bit 1 is the LSB. `(lo, hi)` selects positions `lo..hi` inclusive.
Documented here so any future edit that would change the convention
produces a visible test failure.
"""

from __future__ import annotations

import pytest

from fletchr_measurand import _bitops


class TestBitsToMaskAndShift:
    def test_single_lsb(self) -> None:
        assert _bitops.bits_to_mask_and_shift((1, 1)) == (0b1, 0)

    def test_single_bit_3(self) -> None:
        assert _bitops.bits_to_mask_and_shift((3, 3)) == (0b100, 2)

    def test_full_byte(self) -> None:
        assert _bitops.bits_to_mask_and_shift((1, 8)) == (0xFF, 0)

    def test_high_nibble(self) -> None:
        assert _bitops.bits_to_mask_and_shift((5, 8)) == (0xF0, 4)

    def test_low_nibble(self) -> None:
        assert _bitops.bits_to_mask_and_shift((1, 4)) == (0x0F, 0)

    def test_mid_range(self) -> None:
        # bits 3-5 → positions 2,3,4 → 0b11100 = 28, shift 2
        assert _bitops.bits_to_mask_and_shift((3, 5)) == (0b11100, 2)

    def test_order_invariant(self) -> None:
        # (lo, hi) and (hi, lo) must produce identical result
        assert _bitops.bits_to_mask_and_shift((5, 2)) == _bitops.bits_to_mask_and_shift((2, 5))

    def test_large_word(self) -> None:
        # bits 17-24 of a 32-bit word → byte 3 (0-indexed byte 2)
        mask, shift = _bitops.bits_to_mask_and_shift((17, 24))
        assert mask == 0xFF << 16
        assert shift == 16


class TestWordSizeToMachineSize:
    @pytest.mark.parametrize(
        "size,expected",
        [(1, 8), (8, 8), (9, 16), (16, 16), (17, 32), (32, 32), (33, 64), (64, 64)],
    )
    def test_valid(self, size: int, expected: int) -> None:
        assert _bitops.word_size_to_machine_size(size) == expected

    def test_negative_has_message(self) -> None:
        with pytest.raises(ValueError, match="non-negative"):
            _bitops.word_size_to_machine_size(-1)

    def test_oversized_has_message(self) -> None:
        with pytest.raises(ValueError, match="exceeds maximum"):
            _bitops.word_size_to_machine_size(65)
