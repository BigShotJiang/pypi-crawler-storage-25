import numpy as np
import pyarrow as pa
import pytest
from byteforge import create_encoding

from fletchr_measurand import EUC
from fletchr_measurand.measurand import Measurand
from fletchr_measurand.parameter import Parameter
from fletchr_measurand.parsers.lark import parameter_parser
from fletchr_uintn import uintn_array


def _param(spec: str) -> Parameter:
    """Helper to create a Parameter from a parameter spec string."""
    return parameter_parser.parse(spec)


def _make_data(word_size: int) -> pa.Table:
    """Create a single-row FrameArray-shaped table with 2**word_size columns.

    Each `c{j}` column contains its 1-based index (clamped to `2**word_size - 1`
    so it fits in the bit width), so column k has value `min(k+1, 2**word_size - 1)`.
    Tests reference columns whose 1-based index fits within the bit width, so
    the clamp only affects the last column which no test reads.

    Self-documenting expected values:
      [1+2] on 8-bit data = 1 * 256 + 2 = 258
      [3]   on 8-bit data = 3
    """
    n_cols = 2**word_size
    max_val = (1 << word_size) - 1
    row = np.minimum(np.arange(1, n_cols + 1), max_val)
    dtype = np.uint8 if word_size <= 8 else np.uint16
    arr = row.astype(dtype)
    return pa.table({f"c{j}": uintn_array(arr[j : j + 1], bits=word_size) for j in range(n_cols)})


def _table_from_row(row: list[int], word_size: int) -> pa.Table:
    """Build a single-row `c{j}` table from a flat list of word values."""
    dtype = np.uint8 if word_size <= 8 else np.uint16
    arr = np.array(row, dtype=dtype)
    return pa.table({f"c{j}": uintn_array(arr[j : j + 1], bits=word_size) for j in range(len(row))})


def _table_from_rows(rows: list[list[int]], word_size: int) -> pa.Table:
    """Build an n-row `c{j}` table from a 2-D list of word values."""
    dtype = np.uint8 if word_size <= 8 else np.uint16
    arr = np.array(rows, dtype=dtype)
    n_cols = arr.shape[1]
    return pa.table({f"c{j}": uintn_array(arr[:, j], bits=word_size) for j in range(n_cols)})


@pytest.fixture
def data4():
    return _make_data(4)


@pytest.fixture
def data8():
    return _make_data(8)


@pytest.fixture
def data10():
    return _make_data(10)


# --- Parameter extraction ---


class TestParameterBuild:
    def test_single_word(self, data8):
        m = Measurand(parameter=_param("[1]"))
        assert m.build(data8)[0] == 1

    def test_single_word_col3(self, data8):
        m = Measurand(parameter=_param("[3]"))
        assert m.build(data8)[0] == 3

    def test_two_words(self, data8):
        # [1+2] = 1 * 2**8 + 2 = 258
        m = Measurand(parameter=_param("[1+2]"))
        assert m.build(data8)[0] == 1 * 2**8 + 2

    def test_two_words_reversed(self, data8):
        # [2+1] = 2 * 2**8 + 1 = 513
        m = Measurand(parameter=_param("[2+1]"))
        assert m.build(data8)[0] == 2 * 2**8 + 1

    def test_three_words(self, data8):
        # [1+2+3] = 1 * 2**16 + 2 * 2**8 + 3
        m = Measurand(parameter=_param("[1+2+3]"))
        assert m.build(data8)[0] == 1 * 2**16 + 2 * 2**8 + 3

    def test_four_words(self, data8):
        # [1+2+3+4] = 1 * 2**24 + 2 * 2**16 + 3 * 2**8 + 4
        m = Measurand(parameter=_param("[1+2+3+4]"))
        assert m.build(data8)[0] == 1 * 2**24 + 2 * 2**16 + 3 * 2**8 + 4

    def test_range(self, data8):
        # [1-3] = [1+2+3]
        m = Measurand(parameter=_param("[1-3]"))
        assert m.build(data8)[0] == 1 * 2**16 + 2 * 2**8 + 3

    def test_4bit_single(self, data4):
        m = Measurand(parameter=_param("[1]"))
        assert m.build(data4)[0] == 1

    def test_4bit_two_words(self, data4):
        # [1+2] = 1 * 2**4 + 2 = 18
        m = Measurand(parameter=_param("[1+2]"))
        assert m.build(data4)[0] == 1 * 2**4 + 2

    def test_10bit_single(self, data10):
        m = Measurand(parameter=_param("[1]"))
        assert m.build(data10)[0] == 1

    def test_10bit_two_words(self, data10):
        # [1+2] = 1 * 2**10 + 2 = 1026
        m = Measurand(parameter=_param("[1+2]"))
        assert m.build(data10)[0] == 1 * 2**10 + 2


# --- Encoding ---


class TestEncoding:
    def test_unsigned_identity(self, data8):
        m = Measurand(parameter=_param("[1]"), encoding="u")
        assert m.build(data8)[0] == 1

    def test_unsigned_two_words(self, data8):
        m = Measurand(parameter=_param("[1+2]"), encoding="u")
        assert m.build(data8)[0] == 1 * 2**8 + 2

    def test_twos_complement_positive(self, data8):
        m = Measurand(parameter=_param("[1]"), encoding="2c")
        # value 1 is positive in 2c
        assert m.build(data8)[0] == 1

    def test_twos_complement_negative(self, data8):
        """Column 255 = 0xFF in 8-bit 2c = -1"""
        m = Measurand(parameter=_param("[255]"), encoding="2c")
        assert m.build(data8)[0] == -1

    def test_twos_complement_16bit_negative(self, data8):
        """[255+255] = 0xFF * 256 + 0xFF = 0xFFFF -> 2c 16-bit -> -1"""
        m = Measurand(parameter=_param("[255+255]"), encoding="2c")
        assert m.build(data8)[0] == -1

    def test_twos_complement_16bit_min(self, data8):
        """[128+256] = 128 * 256 + 256 = 0x8100, not 0x8000.
        Use explicit data for clean boundary test."""
        m = Measurand(parameter=_param("[1+2]"), encoding="2c")
        data = _table_from_rows([[0x80, 0x00]], word_size=8)
        assert m.build(data)[0] == -32768

    def test_unsigned_10bit(self, data10):
        m = Measurand(parameter=_param("[1]"), encoding="u")
        assert m.build(data10)[0] == 1

    def test_twos_complement_10bit(self, data10):
        """Column 1023 has value 1023, which is all-ones in 10-bit 2c = -1"""
        m = Measurand(parameter=_param("[1023]"), encoding="2c")
        assert m.build(data10)[0] == -1


# --- EUC ---


class TestEUC:
    def test_scale_factor(self, data8):
        m = Measurand(
            parameter=_param("[1]"),
            encoding="u",
            euc=EUC(scale_factor=10.0),
        )
        # 1 * 10.0 = 10.0
        assert m.build(data8)[0] == pytest.approx(10.0)

    def test_scale_and_scaled_bias(self, data8):
        m = Measurand(
            parameter=_param("[2]"),
            encoding="u",
            euc=EUC(scale_factor=3.0, scaled_bias=100.0),
        )
        # 2 * 3.0 + 100.0 = 106.0
        assert m.build(data8)[0] == pytest.approx(106.0)

    def test_data_bias_scale_and_scaled_bias(self, data8):
        m = Measurand(
            parameter=_param("[4]"),
            encoding="u",
            euc=EUC(data_bias=1, scale_factor=5.0, scaled_bias=10.0),
        )
        # (4 - 1) * 5.0 + 10.0 = 25.0
        assert m.build(data8)[0] == pytest.approx(25.0)

    def testapplyable_scale_factor(self, data8):
        m = Measurand(
            parameter=_param("[3]"),
            encoding="u",
            euc=EUC(scale_factor=lambda PV: PV**2),
        )
        # 3 ** 2 = 9.0
        assert m.build(data8)[0] == pytest.approx(9.0)


# --- Full pipeline ---


class TestFullPipeline:
    def test_twos_complement_with_euc(self, data8):
        """[255+255];2c;EUC[0.1] -> 0xFFFF -> -1 -> -0.1"""
        m = Measurand(
            parameter=_param("[255+255]"),
            encoding="2c",
            euc=EUC(scale_factor=0.1),
        )
        assert m.build(data8)[0] == pytest.approx(-0.1)

    def test_unsigned_with_power_euc(self, data8):
        """[1+2+3+4];u;EUC[2**-31]
        = (1*2**24 + 2*2**16 + 3*2**8 + 4) * 2**-31"""
        m = Measurand(
            parameter=_param("[1+2+3+4]"),
            encoding="u",
            euc=EUC(scale_factor=2**-31),
        )
        expected = (1 * 2**24 + 2 * 2**16 + 3 * 2**8 + 4) * 2**-31
        assert m.build(data8)[0] == pytest.approx(expected)

    def test_multiple_rows(self):
        m = Measurand(
            parameter=_param("[1]"),
            encoding="2c",
            euc=EUC(scale_factor=0.5),
        )
        data = _table_from_rows([[0], [127], [255]], word_size=8)
        result = m.build(data)
        np.testing.assert_array_almost_equal(np.asarray(result), [0.0, 63.5, -0.5])

    def test_4bit_pipeline(self, data4):
        # [1+2] on 4-bit = 1 * 16 + 2 = 18; unsigned 8-bit stays 18; * 0.5 = 9.0
        m = Measurand(
            parameter=_param("[1+2]"),
            encoding=create_encoding("u", bit_width=8),
            euc=EUC(scale_factor=0.5),
        )
        assert m.build(data4)[0] == pytest.approx(9.0)

    def test_10bit_pipeline(self, data10):
        # [1+2] on 10-bit = 1 * 1024 + 2 = 1026; unsigned 20-bit = 1026; * 0.01 = 10.26
        m = Measurand(
            parameter=_param("[1+2]"),
            encoding=create_encoding("u", bit_width=20),
            euc=EUC(scale_factor=0.01),
        )
        assert m.build(data10)[0] == pytest.approx(10.26)


class TestGeneratorMeasurand:
    """End-to-end: a Generator-bearing Measurand produces a 2-D MeasurandResult
    whose `.values` is per-row × per-iteration."""

    def test_generator_two_iterations(self):
        # [1]++1<3 → start=1 (max_word), stop=3 → 2 iterations reading c0,c1
        m = Measurand(parameter=_param("[1]++1<3"))
        table = _table_from_rows([[10, 20, 30], [40, 50, 60]], word_size=8)
        arr = np.asarray(m.build(table))
        assert arr.shape == (2, 2)
        np.testing.assert_array_equal(arr, [[10, 20], [40, 50]])

    def test_generator_two_word_inner(self):
        # [1+2]++2<5 → 16-bit inner, iterations at offsets 0,2
        m = Measurand(parameter=_param("[1+2]++2<5"))
        table = _table_from_rows([[1, 2, 3, 4, 5]], word_size=8)
        arr = np.asarray(m.build(table))
        # row 0: iter 0 = [1+2] at offset 0 = 1*256 + 2 = 258
        #        iter 1 = [1+2] at offset 2 = 3*256 + 4 = 772
        np.testing.assert_array_equal(arr, [[258, 772]])
