"""Behavioral tests for `Parameter.build` and `Fragment.build`.

Arrow-only after the VarUIntArray drop: parameters and fragments take a
FrameArray-shaped `pa.Table` and return a `UIntNArray` (or
`pa.FixedSizeListArray<UIntN>` for Generator/Supercom).
"""

from __future__ import annotations

import numpy as np
import pyarrow as pa
import pytest

from fletchr_measurand.parameter import (
    BasicParameter,
    BitOperator,
    FragmentConstant,
    FragmentWord,
    GeneratorParameter,
    Iterator,
    SupercomParameter,
)
from fletchr_uintn import UIntNType, uintn_array

# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #


def _build_table(data: np.ndarray, word_size: int) -> pa.Table:
    """Wrap a (n_rows × n_cols) numpy array as a FrameArray-style table.

    Builds `c0..c{n_cols-1}` columns of `fletchr.uintn(bits=word_size)`.
    """
    _n_rows, n_cols = data.shape
    columns: dict[str, pa.Array] = {}
    for j in range(n_cols):
        columns[f"c{j}"] = uintn_array(data[:, j], bits=word_size)
    return pa.table(columns)


def _build(parameter, data: np.ndarray, word_size: int) -> tuple[np.ndarray, int]:
    """Build via `parameter.build(table)`; return (numpy_result, bit_width)."""
    table = _build_table(data, word_size)
    arr = parameter.build(table)
    return arr.to_numpy(zero_copy_only=False), arr.type.bits


# --------------------------------------------------------------------------- #
# Fragment-level tests                                                        #
# --------------------------------------------------------------------------- #


class TestFragmentWord:
    def test_whole_word_8bit(self) -> None:
        data = np.array([[10, 20, 30], [40, 50, 60]], dtype=np.uint8)
        frag = FragmentWord(word=2)  # 1-based — pick column index 1
        result, bits = _build(BasicParameter([frag]), data, word_size=8)
        assert bits == 8
        assert np.array_equal(result, [20, 50])

    def test_bit_range_extraction_16bit(self) -> None:
        # Extract bits 9-12 (1-based) of a 16-bit word.
        data = np.array([[0xABCD, 0x1234], [0x5678, 0x9ABC]], dtype=np.uint16)
        frag = FragmentWord(word=1, bits=[9, 10, 11, 12])
        result, bits = _build(BasicParameter([frag]), data, word_size=16)
        assert bits == 4
        # Bits 9-12 of 0xABCD = 0b1011 = 11; of 0x5678 = 0b0110 = 6.
        assert np.array_equal(result, [11, 6])

    def test_multi_range_bits(self) -> None:
        """Non-contiguous `bits` concatenate at output positions.

        `bits=[1,2,5,6]` on an 8-bit word picks bits 1-2 (→ output bits
        0-1) and bits 5-6 (→ output bits 2-3), yielding a 4-bit value.
        """
        # 0xFF → bits 1,2 = 0b11, bits 5,6 = 0b11 → concat = 0b1111 = 15
        # 0x00 → 0
        # 0xF0 = 0b1111_0000 → bits 1,2 = 0, bits 5,6 = 0b11 → 0b1100 = 12
        data = np.array([[0xFF], [0x00], [0xF0]], dtype=np.uint8)
        frag = FragmentWord(word=1, bits=[1, 2, 5, 6])
        result, bits = _build(BasicParameter([frag]), data, word_size=8)
        assert bits == 4
        assert np.array_equal(result, [15, 0, 12])

    def test_complement_masks_padding_bits(self) -> None:
        """The complement op zeroes the high padding bits at `frag_size`.

        With bits=[1..10] from a 16-bit word, the fragment is 10 bits.
        `~x` flips all storage bits; the high 6 must be masked to zero
        to preserve the fragment's bit-width invariant.
        """
        data = np.array([[0b0000_0011_1111_1111, 0]], dtype=np.uint16)
        frag = FragmentWord(word=1, bits=list(range(1, 11)), complement=True)
        result, bits = _build(BasicParameter([frag]), data, word_size=16)
        assert bits == 10
        # Input 0x03FF (10 ones) → bits [1..10] = 0x3FF → complement(10-bit) = 0
        assert result[0] == 0

    def test_reverse(self) -> None:
        data = np.array([[0b1010_0000, 0]], dtype=np.uint8)
        frag = FragmentWord(word=1, bits=[1, 2, 3, 4, 5, 6, 7, 8], reverse=True)
        result, bits = _build(BasicParameter([frag]), data, word_size=8)
        assert bits == 8
        # 0b10100000 bit-reversed (across 8 bits) = 0b00000101 = 5
        assert result[0] == 5

    @pytest.mark.parametrize(
        "bits,expected",
        [
            (None, "2"),  # no bits → just the word
            ([5], "2:5"),  # single-bit range — previously raised TypeError
            ([1, 5], "2:1,5"),  # two non-adjacent singles
            ([1, 2, 3], "2:1-3"),  # one consecutive run
            ([1, 2, 3, 5], "2:1-3,5"),  # run + single
            ([5, 6, 7, 9, 10], "2:5-7,9-10"),  # two runs
        ],
    )
    def test_str_formatting(self, bits, expected) -> None:
        assert str(FragmentWord(word=2, bits=bits)) == expected


class TestFragmentConstant:
    def test_constant_broadcasts(self) -> None:
        data = np.zeros((3, 1), dtype=np.uint8)
        frag = FragmentConstant(value=42, size=8)
        result, bits = _build(BasicParameter([frag]), data, word_size=8)
        assert bits == 8
        assert np.array_equal(result, [42, 42, 42])


# --------------------------------------------------------------------------- #
# BasicParameter integration tests                                            #
# --------------------------------------------------------------------------- #


class TestBasicParameter:
    def test_two_word_concat(self) -> None:
        """Combine two 8-bit columns into a single 16-bit parameter."""
        data = np.array([[0x12, 0x34], [0xAB, 0xCD]], dtype=np.uint8)
        param = BasicParameter([FragmentWord(word=1), FragmentWord(word=2)])
        result, bits = _build(param, data, word_size=8)
        assert bits == 16
        assert np.array_equal(result, [0x1234, 0xABCD])

    def test_three_word_concat_with_bit_extraction(self) -> None:
        """First two words use bit ranges, third uses whole word."""
        data = np.array([[0xAB, 0x12, 0x99], [0xFF, 0x00, 0x55]], dtype=np.uint8)
        param = BasicParameter(
            [
                FragmentWord(word=1, bits=[1, 2, 3, 4]),
                FragmentWord(word=2, bits=[5, 6, 7, 8]),
                FragmentWord(word=3),
            ]
        )
        _result, bits = _build(param, data, word_size=8)
        assert bits == 4 + 4 + 8

    def test_with_bit_operator_and(self) -> None:
        data = np.array([[0xFF, 0xAA]], dtype=np.uint8)
        param = BasicParameter(
            [FragmentWord(word=1), FragmentWord(word=2)],
            bit_op=BitOperator(mode="AND", value=0xF0F0),
        )
        result, _ = _build(param, data, word_size=8)
        assert result[0] == (0xFFAA & 0xF0F0)

    def test_with_bit_operator_xor(self) -> None:
        """`bit_op` fires after every fragment, not once at the end.

        - frag 0: result = 0x00FF; XOR 0xFFFF → 0xFF00
        - frag 1: shift_left(0xFF00, 8) wraps in uint16 → 0x0000;
                  add 0xAA → 0x00AA; XOR 0xFFFF → 0xFF55
        """
        data = np.array([[0xFF, 0xAA]], dtype=np.uint8)
        param = BasicParameter(
            [FragmentWord(word=1), FragmentWord(word=2)],
            bit_op=BitOperator(mode="XOR", value=0xFFFF),
        )
        result, _ = _build(param, data, word_size=8)
        assert result[0] == 0xFF55

    def test_constant_mixed_with_word(self) -> None:
        data = np.array([[0xAB], [0xCD]], dtype=np.uint8)
        param = BasicParameter([FragmentWord(word=1), FragmentConstant(value=0xF0, size=8)])
        result, bits = _build(param, data, word_size=8)
        assert bits == 16
        # word[0] << 8 | 0xF0
        assert np.array_equal(result, [0xABF0, 0xCDF0])


# --------------------------------------------------------------------------- #
# Extension-type input                                                        #
# --------------------------------------------------------------------------- #


class TestExtensionInput:
    def test_extension_input_bits(self) -> None:
        """Input columns of `fletchr.uintn(bits=12)` drive the fragment's word_size."""
        data = np.array([[100, 200, 4095]], dtype=np.uint16)
        table = _build_table(data, word_size=12)
        assert isinstance(table.column("c0").type, UIntNType)
        assert table.column("c0").type.bits == 12

        param = BasicParameter([FragmentWord(word=1), FragmentWord(word=2)])
        arr = param.build(table)
        assert arr.type.bits == 24
        # word1 << 12 | word2
        assert np.array_equal(arr.to_numpy(zero_copy_only=False), [(100 << 12) | 200])


# --------------------------------------------------------------------------- #
# GeneratorParameter / SupercomParameter — FixedSizeListArray output          #
# --------------------------------------------------------------------------- #


class TestGeneratorParameter:
    """`GeneratorParameter.build` returns a `pa.FixedSizeListArray` whose
    inner values are a `UIntNArray`. Each row's list contains the inner
    parameter evaluated at successive column offsets."""

    def test_basic_iteration(self) -> None:
        # [2]++1<4 → start=2 (max_word), stop=4, step=1 → 2 iters at offsets 0,1
        data = np.array(
            [[1, 2, 3, 4, 5], [11, 12, 13, 14, 15], [21, 22, 23, 24, 25]],
            dtype=np.uint8,
        )
        table = _build_table(data, word_size=8)
        param = GeneratorParameter(
            parameter=BasicParameter([FragmentWord(word=2)]),
            iterator=Iterator(step=1, stop=4),
        )
        arr = param.build(table)
        assert arr.type.list_size == 2
        assert arr.type.value_type.bits == 8
        # Each row contains [c1, c2]
        flat = np.asarray(arr.values).reshape(-1, arr.type.list_size)
        np.testing.assert_array_equal(flat, [[2, 3], [12, 13], [22, 23]])

    def test_multi_word_inner_param(self) -> None:
        # [1+2]++2<6 → 16-bit inner param, iterations at offsets 0,2
        data = np.array(
            [[1, 2, 3, 4, 5, 6], [10, 20, 30, 40, 50, 60]],
            dtype=np.uint8,
        )
        table = _build_table(data, word_size=8)
        param = GeneratorParameter(
            parameter=BasicParameter([FragmentWord(word=1), FragmentWord(word=2)]),
            iterator=Iterator(step=2, stop=6),
        )
        arr = param.build(table)
        assert arr.type.list_size == 2
        assert arr.type.value_type.bits == 16
        # Row 0: iter 0 = [1+2] at offset 0 = 1*256 + 2 = 258
        #        iter 1 = [1+2] at offset 2 = 3*256 + 4 = 772
        # Row 1: iter 0 = 10*256 + 20 = 2580
        #        iter 1 = 30*256 + 40 = 7720
        flat = np.asarray(arr.values).reshape(-1, arr.type.list_size)
        np.testing.assert_array_equal(flat, [[258, 772], [2580, 7720]])

    def test_default_stop_uses_table_width(self) -> None:
        # No explicit stop — with start=1 (max_word) and stop=n_cols=4,
        # range(1,4,1) = [1,2,3] → 3 iterations reading c0,c1,c2.
        data = np.array([[10, 20, 30, 40]], dtype=np.uint8)
        param = GeneratorParameter(
            parameter=BasicParameter([FragmentWord(word=1)]),
            iterator=Iterator(step=1),
        )
        table = _build_table(data, word_size=8)
        arr = param.build(table)
        assert arr.type.list_size == 3
        assert arr.values.to_pylist() == [10, 20, 30]

    def test_validity_propagates(self) -> None:
        # Null in one input column → null in the corresponding flat output position.
        cols = {
            "c0": uintn_array(np.array([10], dtype=np.uint8), bits=8),
            "c1": pa.ExtensionArray.from_storage(
                UIntNType(8),
                pa.array(np.array([0], dtype=np.uint8), mask=np.array([True])),
            ),
            "c2": uintn_array(np.array([30], dtype=np.uint8), bits=8),
        }
        table = pa.table(cols)
        # start=1, stop=4, step=1 → iter at offsets 0,1,2 → read c0,c1,c2
        param = GeneratorParameter(
            parameter=BasicParameter([FragmentWord(word=1)]),
            iterator=Iterator(step=1, stop=4),
        )
        arr = param.build(table)
        assert arr.values.to_pylist() == [10, None, 30]


class TestSupercomParameter:
    """`SupercomParameter` inherits `build` from `GeneratorParameter` —
    same FixedSizeList shape, same semantics."""

    def test_supercom_matches_generator(self) -> None:
        data = np.array([[1, 2, 3, 4]], dtype=np.uint8)
        table = _build_table(data, word_size=8)
        gen = GeneratorParameter(
            parameter=BasicParameter([FragmentWord(word=1)]),
            iterator=Iterator(step=1, stop=4),
        )
        sup = SupercomParameter(
            parameter=BasicParameter([FragmentWord(word=1)]),
            iterator=Iterator(step=1, stop=4),
        )
        gen_arr = gen.build(table)
        sup_arr = sup.build(table)
        assert gen_arr.values.to_pylist() == sup_arr.values.to_pylist()
        assert gen_arr.type.list_size == sup_arr.type.list_size


# --------------------------------------------------------------------------- #
# Validation                                                                  #
# --------------------------------------------------------------------------- #


class TestBuildSignature:
    def test_basic_parameter_rejects_non_table(self) -> None:
        # `build` now requires a pa.Table; passing other types raises (the
        # specific error comes from the body trying to call table.column).
        param = BasicParameter([FragmentWord(word=1)])
        with pytest.raises(AttributeError):
            param.build([1, 2, 3])  # plain list — no `.column` method
