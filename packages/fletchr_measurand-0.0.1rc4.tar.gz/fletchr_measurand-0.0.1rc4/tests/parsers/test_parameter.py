import numpy as np
import pytest

from fletchr_measurand.parameter import (
    BasicParameter,
    BitOperator,
    FragmentConstant,
    FragmentWord,
)

# --- Single word ---


@pytest.mark.parametrize(
    "expr, word",
    [
        ("[1]", 1),
        ("[2]", 2),
        ("[10]", 10),
    ],
)
def test_single_word(parse_parameter, expr, word):
    result = parse_parameter(expr)
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 1
    frag = result.fragments[0]
    assert isinstance(frag, FragmentWord)
    assert frag.word == word
    assert frag.bits is None


# --- Word range ---


@pytest.mark.parametrize(
    "expr, words",
    [
        ("[1-3]", [1, 2, 3]),
        ("[3-1]", [3, 2, 1]),
        ("[1-1]", [1]),
    ],
)
def test_word_range(parse_parameter, expr, words):
    result = parse_parameter(expr)
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == len(words)
    for frag, expected_word in zip(result.fragments, words):
        assert isinstance(frag, FragmentWord)
        assert frag.word == expected_word
        assert frag.bits is None


# --- Concatenation ---


@pytest.mark.parametrize(
    "expr, words",
    [
        ("[1+2]", [1, 2]),
        ("[1+2+3]", [1, 2, 3]),
        ("[5+1+3]", [5, 1, 3]),
    ],
)
def test_concatenation(parse_parameter, expr, words):
    result = parse_parameter(expr)
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == len(words)
    for frag, expected_word in zip(result.fragments, words):
        assert isinstance(frag, FragmentWord)
        assert frag.word == expected_word


# --- Bit selection ---


@pytest.mark.parametrize(
    "expr, word, bits",
    [
        ("[1:1-4]", 1, [1, 2, 3, 4]),
        ("[1:1,2,3,4]", 1, [1, 2, 3, 4]),
        ("[1:8-5]", 1, [8, 7, 6, 5]),
        ("[3:1]", 3, [1]),
    ],
)
def test_bit_selection(parse_parameter, expr, word, bits):
    result = parse_parameter(expr)
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 1
    frag = result.fragments[0]
    assert isinstance(frag, FragmentWord)
    assert frag.word == word
    assert frag.bits == bits


# --- Bit selection with range of words ---


def test_bit_selection_range(parse_parameter):
    result = parse_parameter("[1-2:1-4]")
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 2
    for i, frag in enumerate(result.fragments):
        assert isinstance(frag, FragmentWord)
        assert frag.word == i + 1
        assert frag.bits == [1, 2, 3, 4]


# --- Bit mask ---


def test_bit_mask_hex(parse_parameter):
    result = parse_parameter("[1:xFF]")
    assert isinstance(result, BasicParameter)
    frag = result.fragments[0]
    assert isinstance(frag, FragmentWord)
    assert frag.bits == [1, 2, 3, 4, 5, 6, 7, 8]


def test_bit_mask_binary(parse_parameter):
    result = parse_parameter("[1:b101]")
    assert isinstance(result, BasicParameter)
    frag = result.fragments[0]
    assert isinstance(frag, FragmentWord)
    assert frag.bits == [1, 3]


# --- Complement and reverse ---


def test_complement(parse_parameter):
    result = parse_parameter("[~1]")
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 1
    assert result.fragments[0].complement is True
    assert result.fragments[0].reverse is False


def test_reverse(parse_parameter):
    result = parse_parameter("[1R]")
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 1
    assert result.fragments[0].complement is False
    assert result.fragments[0].reverse is True


def test_complement_and_reverse(parse_parameter):
    result = parse_parameter("[~1R]")
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 1
    assert result.fragments[0].complement is True
    assert result.fragments[0].reverse is True


# --- Constants ---


@pytest.mark.parametrize(
    "expr, value, size",
    [
        ("[xFF]", 0xFF, 8),
        ("[xAB]", 0xAB, 8),
        ("[b101]", 0b101, 3),
        ("[o77]", 0o77, 6),
        ("[x0F+1]", None, None),  # mixed: constant + word
    ],
)
def test_constants(parse_parameter, expr, value, size):
    result = parse_parameter(expr)
    assert isinstance(result, BasicParameter)
    if value is not None:
        frag = result.fragments[0]
        assert isinstance(frag, FragmentConstant)
        assert frag.value == value
        assert frag.size == size
    else:
        # Mixed: first is constant, second is word
        assert isinstance(result.fragments[0], FragmentConstant)
        assert isinstance(result.fragments[1], FragmentWord)


def test_quoted_constant(parse_parameter):
    result = parse_parameter("['xFF']")
    assert isinstance(result, BasicParameter)
    frag = result.fragments[0]
    assert isinstance(frag, FragmentConstant)
    assert frag.value == 0xFF


# --- Bit operators ---


@pytest.mark.parametrize(
    "expr, mode, value",
    [
        ("[1] AND xFF", "AND", 0xFF),
        ("[1] OR xFF", "OR", 0xFF),
        ("[1] XOR xFF", "XOR", 0xFF),
        ("[1] AND b1111", "AND", 0b1111),
        ("[1] AND o77", "AND", 0o77),
    ],
)
def test_bit_operators(parse_parameter, expr, mode, value):
    result = parse_parameter(expr)
    assert isinstance(result, BasicParameter)
    assert result.bit_op is not None
    assert isinstance(result.bit_op, BitOperator)
    assert result.bit_op.mode == mode
    assert result.bit_op.value == value


# --- Concatenation with bits and constants ---


def test_concat_word_and_bits(parse_parameter):
    result = parse_parameter("[1:1-4+2]")
    assert isinstance(result, BasicParameter)
    assert len(result.fragments) == 2
    assert isinstance(result.fragments[0], FragmentWord)
    assert result.fragments[0].word == 1
    assert result.fragments[0].bits == [1, 2, 3, 4]
    assert isinstance(result.fragments[1], FragmentWord)
    assert result.fragments[1].word == 2
    assert result.fragments[1].bits is None


# --- FragmentConstant width dispatch (regression B2: uint32 vs uint64) ---


def _fc_dtype(fc: FragmentConstant) -> type:
    # After __post_init__, value is an np.unsignedinteger scalar; typestub
    # still shows int as a union option, so narrow at runtime.
    assert isinstance(fc.value, np.unsignedinteger)
    return type(fc.value)


class TestFragmentConstantDtype:
    def test_uint8(self) -> None:
        fc = FragmentConstant(value=0xFF, size=8)
        assert _fc_dtype(fc) is np.uint8

    def test_uint16(self) -> None:
        fc = FragmentConstant(value=0xFFFF, size=16)
        assert _fc_dtype(fc) is np.uint16

    def test_uint32(self) -> None:
        fc = FragmentConstant(value=0xFFFF_FFFF, size=32)
        assert _fc_dtype(fc) is np.uint32

    def test_uint64_lower(self) -> None:
        # Previously this value fell through because of a duplicate 2**32 check
        fc = FragmentConstant(value=2**32, size=64)
        assert _fc_dtype(fc) is np.uint64

    def test_uint64_upper(self) -> None:
        fc = FragmentConstant(value=2**64 - 1, size=64)
        assert _fc_dtype(fc) is np.uint64

    def test_value_too_large(self) -> None:
        with pytest.raises(ValueError, match="2\\*\\*64-1"):
            FragmentConstant(value=2**64, size=64)
