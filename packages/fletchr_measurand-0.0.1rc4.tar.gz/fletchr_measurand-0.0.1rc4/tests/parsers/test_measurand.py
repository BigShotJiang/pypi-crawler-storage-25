import math

import pytest

from fletchr_measurand import EUC
from fletchr_measurand.measurand import Measurand
from fletchr_measurand.parameter import BasicParameter, FragmentWord


def test_parameter_only(parse_measurand):
    result = parse_measurand("[1+2]")
    assert isinstance(result, Measurand)
    assert isinstance(result.parameter, BasicParameter)
    assert len(result.parameter.fragments) == 2
    assert result.encoding is None
    assert result.euc is None


def test_parameter_with_trailing_semicolon(parse_measurand):
    result = parse_measurand("[1+2];")
    assert isinstance(result, Measurand)
    assert isinstance(result.parameter, BasicParameter)
    assert result.encoding is None
    assert result.euc is None


# --- Parameter + encoding ---


@pytest.mark.parametrize(
    "expr, encoding",
    [
        ("[1+2];u", "u"),
        ("[1+2];2c", "2c"),
        ("[1-4];ieee32", "ieee32"),
        ("[1];UINT", "UINT"),
    ],
)
def test_parameter_with_encoding(parse_measurand, expr, encoding):
    result = parse_measurand(expr)
    assert isinstance(result, Measurand)
    assert result.encoding == encoding
    assert result.euc is None


@pytest.mark.parametrize(
    "expr, encoding",
    [
        ("[1+2];u;", "u"),
        ("[1+2];2c;", "2c"),
    ],
)
def test_parameter_with_encoding_trailing_semicolon(parse_measurand, expr, encoding):
    result = parse_measurand(expr)
    assert isinstance(result, Measurand)
    assert result.encoding == encoding
    assert result.euc is None


# --- Parameter + encoding + EUC ---


def test_euc_single_scale(parse_measurand):
    result = parse_measurand("[1+2];2c;EUC[0.05]")
    assert isinstance(result, Measurand)
    assert result.encoding == "2c"
    assert isinstance(result.euc, EUC)
    assert result.euc.scale_factor == pytest.approx(0.05)
    assert result.euc.data_bias is None
    assert result.euc.scaled_bias is None


def test_euc_scale_and_bias(parse_measurand):
    result = parse_measurand("[1+2];u;EUC[0.5, 10]")
    assert isinstance(result, Measurand)
    assert isinstance(result.euc, EUC)
    assert result.euc.scale_factor == pytest.approx(0.5)
    assert result.euc.scaled_bias == pytest.approx(10)
    assert result.euc.data_bias is None


def test_euc_data_bias_scale_and_bias(parse_measurand):
    result = parse_measurand("[1+2];u;EUC[100, 0.5, 10]")
    assert isinstance(result, Measurand)
    assert isinstance(result.euc, EUC)
    assert result.euc.data_bias == pytest.approx(100)
    assert result.euc.scale_factor == pytest.approx(0.5)
    assert result.euc.scaled_bias == pytest.approx(10)


def test_euc_without_prefix(parse_measurand):
    result = parse_measurand("[1+2];u;[0.05]")
    assert isinstance(result, Measurand)
    assert isinstance(result.euc, EUC)
    assert result.euc.scale_factor == pytest.approx(0.05)


def test_euc_with_expression(parse_measurand):
    result = parse_measurand("[1-4];2c;EUC[2**-31]")
    assert isinstance(result, Measurand)
    assert isinstance(result.euc, EUC)
    assert result.euc.scale_factor == pytest.approx(2**-31)


def test_euc_with_pv_expression(parse_measurand):
    result = parse_measurand("[1];u;EUC[PV * 2 + 1]")
    assert isinstance(result, Measurand)
    assert isinstance(result.euc, EUC)
    # scale_factor should be a callable (vectorized) since it depends on PV
    assert callable(result.euc.scale_factor)


def test_euc_trailing_semicolon(parse_measurand):
    result = parse_measurand("[1+2];2c;EUC[0.05];")
    assert isinstance(result, Measurand)
    assert isinstance(result.euc, EUC)
    assert result.euc.scale_factor == pytest.approx(0.05)


# --- Bit selections in measurand context ---


def test_measurand_with_bit_selection(parse_measurand):
    result = parse_measurand("[1:1-4+2];2c;EUC[0.05]")
    assert isinstance(result, Measurand)
    param = result.parameter
    assert isinstance(param, BasicParameter)
    assert len(param.fragments) == 2
    assert isinstance(param.fragments[0], FragmentWord)
    assert param.fragments[0].bits == [1, 2, 3, 4]
    assert isinstance(param.fragments[1], FragmentWord)
    assert param.fragments[1].bits is None


# --- Word ranges in measurand context ---


def test_measurand_with_word_range(parse_measurand):
    result = parse_measurand("[1-4];ieee32")
    assert isinstance(result, Measurand)
    param = result.parameter
    assert isinstance(param, BasicParameter)
    assert len(param.fragments) == 4
    for i, frag in enumerate(param.fragments):
        assert isinstance(frag, FragmentWord)
        assert frag.word == i + 1


# --- EUC with math functions ---


def test_euc_with_sqrt(parse_measurand):
    result = parse_measurand("[1];u;EUC[sqrt(2)]")
    assert isinstance(result, Measurand)
    assert result.euc is not None
    assert result.euc.scale_factor == pytest.approx(math.sqrt(2))


def test_euc_with_pi(parse_measurand):
    result = parse_measurand("[1];u;EUC[PI]")
    assert isinstance(result, Measurand)
    assert result.euc is not None
    assert result.euc.scale_factor == pytest.approx(math.pi)


class TestEucParserValidation:
    """EUC arguments must be numeric, not callables.

    The lark transformer previously used `assert not callable(...)`,
    which is stripped under `python -O`. The check is now an explicit
    `TypeError` — pin the specific messages so a regression can't
    silently remove them.
    """

    def test_rejectsapplyable_bias_via_explicit_typeerror(self) -> None:
        from fletchr_measurand.parsers.lark.measurand import MeasurandTransformer

        t = MeasurandTransformer()

        def callable_value(pv):
            return pv

        with pytest.raises(TypeError, match="scaled_bias"):
            t.euc(2.0, callable_value)
        with pytest.raises(TypeError, match="data_bias"):
            t.euc(callable_value, 2.0, 3.0)
        with pytest.raises(TypeError, match="scaled_bias"):
            t.euc(1.0, 2.0, callable_value)
        with pytest.raises(TypeError, match="1-3 arguments"):
            t.euc(1.0, 2.0, 3.0, 4.0)
