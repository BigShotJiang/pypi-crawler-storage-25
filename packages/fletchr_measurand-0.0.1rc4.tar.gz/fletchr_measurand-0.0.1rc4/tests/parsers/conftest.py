import pytest

from fletchr_measurand.parsers.antlr import calculator_parser as antlr_calc
from fletchr_measurand.parsers.antlr import measurand_parser as antlr_meas
from fletchr_measurand.parsers.antlr import parameter_parser as antlr_param
from fletchr_measurand.parsers.lark import calculator_parser as lark_calc
from fletchr_measurand.parsers.lark import measurand_parser as lark_meas
from fletchr_measurand.parsers.lark import parameter_parser as lark_param


@pytest.fixture(params=["lark", "antlr"])
def parse_calculator(request):
    parsers = {"lark": lark_calc, "antlr": antlr_calc}
    return parsers[request.param].parse


@pytest.fixture(params=["lark", "antlr"])
def parse_parameter(request):
    parsers = {"lark": lark_param, "antlr": antlr_param}
    return parsers[request.param].parse


@pytest.fixture(params=["lark", "antlr"])
def parse_measurand(request):
    parsers = {"lark": lark_meas, "antlr": antlr_meas}
    return parsers[request.param].parse
