import math
from collections.abc import Callable

import pytest

# --- Constants and literals ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("42", 42),
        ("3.14", 3.14),
        ("-5", -5),
        ("-2.5", -2.5),
        ("PI", math.pi),
        ("E", math.e),
    ],
)
def test_constants_and_literals(parse_calculator, expr, expected):
    assert parse_calculator(expr) == pytest.approx(expected)


# --- Arithmetic with constants ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("2 + 3", 5),
        ("10 - 4", 6),
        ("3 * 7", 21),
        ("20 / 4", 5.0),
        ("2 ** 3", 8),
        ("2 + 3 * 4", 14),
        ("(2 + 3) * 4", 20),
        ("-3 + 5", 2),
        ("10 / 3", pytest.approx(10 / 3)),
    ],
)
def test_constant_arithmetic(parse_calculator, expr, expected):
    result = parse_calculator(expr)
    assert not isinstance(result, Callable)
    assert result == pytest.approx(expected)


# --- PV expressions ---


def test_pv_identity(parse_calculator):
    f = parse_calculator("PV")
    assert callable(f)
    assert f(42) == 42
    assert f(-3.5) == -3.5


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("PV * 2", 5, 10),
        ("PV + 10", 3, 13),
        ("PV - 1", 7, 6),
        ("PV / 4", 20, 5.0),
        ("PV ** 2", 3, 9),
        ("2 * PV + 1", 5, 11),
        ("-PV", 3, -3),
        ("PV * PV", 4, 16),
        ("(PV + 1) * (PV - 1)", 5, 24),
    ],
)
def test_pv_arithmetic(parse_calculator, expr, pv, expected):
    f = parse_calculator(expr)
    assert callable(f)
    assert f(pv) == pytest.approx(expected)


# --- Unary math functions ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("abs(-5)", 5),
        ("abs(3)", 3),
        ("sqrt(16)", 4.0),
        ("sqrt(2)", math.sqrt(2)),
        ("exp(1)", math.e),
        ("exp(0)", 1.0),
        ("ln(1)", 0.0),
        ("ln(E)", 1.0),
        ("log10(100)", 2.0),
        ("log10(1000)", 3.0),
        ("tento(3)", 1000),
        ("tento(0)", 1),
        ("nxtwo(5)", 8),
        ("nxtwo(8)", 8),
        ("nxtwo(1)", 1),
    ],
)
def test_unary_math_constants(parse_calculator, expr, expected):
    assert parse_calculator(expr) == pytest.approx(expected)


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("abs(PV)", -7, 7),
        ("sqrt(PV)", 25, 5.0),
        ("exp(PV)", 0, 1.0),
        ("ln(PV)", math.e, 1.0),
        ("log10(PV)", 1000, 3.0),
        ("tento(PV)", 2, 100),
        ("nxtwo(PV)", 5, 8),
    ],
)
def test_unary_math_pv(parse_calculator, expr, pv, expected):
    f = parse_calculator(expr)
    assert callable(f)
    assert f(pv) == pytest.approx(expected)


# --- Trig functions ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("sin(0)", 0.0),
        ("cos(0)", 1.0),
        ("tan(0)", 0.0),
        ("sin(PI / 2)", 1.0),
        ("cos(PI)", -1.0),
        ("asin(1)", math.pi / 2),
        ("acos(1)", 0.0),
        ("atan(1)", math.pi / 4),
        ("atan2(1, 1)", math.pi / 4),
        ("atan2(0, -1)", math.pi),
    ],
)
def test_trig_constants(parse_calculator, expr, expected):
    assert parse_calculator(expr) == pytest.approx(expected)


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("sin(PV)", 0, 0.0),
        ("cos(PV)", 0, 1.0),
        ("tan(PV)", 0, 0.0),
        ("asin(PV)", 0, 0.0),
        ("acos(PV)", 1, 0.0),
        ("atan(PV)", 0, 0.0),
        ("atan2(PV, 1)", 1, math.atan2(1, 1)),
        ("atan2(1, PV)", 1, math.atan2(1, 1)),
        ("atan2(PV, PV)", 1, math.atan2(1, 1)),
    ],
)
def test_trig_pv(parse_calculator, expr, pv, expected):
    f = parse_calculator(expr)
    assert callable(f)
    assert f(pv) == pytest.approx(expected)


# --- Degree/radian conversion ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("deg(PI)", 180.0),
        ("rad(180)", math.pi),
        ("deg(PI / 2)", 90.0),
        ("rad(90)", math.pi / 2),
    ],
)
def test_deg_rad_constants(parse_calculator, expr, expected):
    assert parse_calculator(expr) == pytest.approx(expected)


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("deg(PV)", math.pi, 180.0),
        ("rad(PV)", 180, math.pi),
    ],
)
def test_deg_rad_pv(parse_calculator, expr, pv, expected):
    assert parse_calculator(expr)(pv) == pytest.approx(expected)


# --- Rounding functions ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("round(3.7)", 4),
        ("round(3.2)", 3),
        ("floor(3.9)", 3),
        ("floor(-1.1)", -2),
        ("ceil(3.1)", 4),
        ("ceil(-1.9)", -1),
        ("fix(3.9)", 3),
        ("fix(-3.9)", -3),
        ("float(3)", 3.0),
    ],
)
def test_rounding_constants(parse_calculator, expr, expected):
    result = parse_calculator(expr)
    assert result == expected
    if expr.startswith("float"):
        assert isinstance(result, float)
    elif expr.startswith("fix"):
        assert isinstance(result, int)


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("round(PV)", 3.7, 4),
        ("floor(PV)", 3.9, 3),
        ("ceil(PV)", 3.1, 4),
        ("fix(PV)", 3.9, 3),
        ("float(PV)", 3, 3.0),
    ],
)
def test_rounding_pv(parse_calculator, expr, pv, expected):
    assert parse_calculator(expr)(pv) == expected


# --- min / max ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("max(1, 2, 3)", 3),
        ("min(1, 2, 3)", 1),
        ("max(5, 2)", 5),
        ("min(5, 2)", 2),
        ("max(-1, -5, -2)", -1),
        ("min(-1, -5, -2)", -5),
    ],
)
def test_min_max_constants(parse_calculator, expr, expected):
    assert parse_calculator(expr) == expected


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("max(PV, 10)", 5, 10),
        ("max(PV, 10)", 15, 15),
        ("min(PV, 10)", 5, 5),
        ("min(PV, 10)", 15, 10),
        ("max(PV, 0)", -3, 0),
        ("min(PV, PV)", 7, 7),
    ],
)
def test_min_max_pv(parse_calculator, expr, pv, expected):
    assert parse_calculator(expr)(pv) == expected


# --- if ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("if(1, 10, 20)", 10),
        ("if(-1, 10, 20)", 20),
        ("if(0, 10, 20)", 20),
    ],
)
def test_if_constants(parse_calculator, expr, expected):
    assert parse_calculator(expr) == expected


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("if(PV, 10, 20)", 5, 10),
        ("if(PV, 10, 20)", -1, 20),
        ("if(PV, 10, 20)", 0, 20),
        ("if(1, PV, 0)", 42, 42),
        ("if(-1, 0, PV)", 42, 42),
        ("if(PV, PV, 0)", 5, 5),
        ("if(PV, PV, 0)", -1, 0),
    ],
)
def test_if_pv(parse_calculator, expr, pv, expected):
    assert parse_calculator(expr)(pv) == expected


# --- hamdist ---


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("hamdist(0, 0)", 0),
        ("hamdist(7, 0)", 3),
        ("hamdist(15, 15)", 0),
        ("hamdist(0, 255)", 8),
    ],
)
def test_hamdist_constants(parse_calculator, expr, expected):
    assert parse_calculator(expr) == expected


@pytest.mark.parametrize(
    "expr, pv, expected",
    [
        ("hamdist(PV, 0)", 7, 3),
        ("hamdist(0, PV)", 7, 3),
        ("hamdist(PV, PV)", 7, 0),
    ],
)
def test_hamdist_pv(parse_calculator, expr, pv, expected):
    assert parse_calculator(expr)(pv) == expected


# --- Case insensitivity ---


@pytest.mark.parametrize(
    "expr",
    ["SIN(0)", "Sin(0)", "sin(0)", "SQRT(4)", "Sqrt(4)", "ABS(-1)", "Abs(-1)"],
)
def test_case_insensitive(parse_calculator, expr):
    parse_calculator(expr)


# --- Complex expressions ---


def test_complex_linear_scaling(parse_calculator):
    f = parse_calculator("PV * 2.5 + 10")
    assert f(0) == pytest.approx(10)
    assert f(4) == pytest.approx(20)


def test_complex_polynomial(parse_calculator):
    f = parse_calculator("PV ** 2 + 2 * PV + 1")
    assert f(0) == pytest.approx(1)
    assert f(3) == pytest.approx(16)


def test_complex_nested_functions(parse_calculator):
    f = parse_calculator("sqrt(abs(PV))")
    assert f(16) == pytest.approx(4)
    assert f(-16) == pytest.approx(4)


def test_complex_trig_chain(parse_calculator):
    f = parse_calculator("deg(atan2(PV, 1))")
    assert f(1) == pytest.approx(45.0)
    assert f(0) == pytest.approx(0.0)
