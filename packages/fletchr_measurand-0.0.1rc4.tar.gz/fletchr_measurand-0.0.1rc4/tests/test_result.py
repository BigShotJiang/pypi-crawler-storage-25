"""Tests for `MeasurandResult` — the unified output of `Measurand.build`.

Arrow-backed throughout: dns is either a 1-D `UIntNArray` or a 2-D
`pa.FixedSizeListArray<UIntN>` (from Generator/Supercom output).
"""

import numpy as np
import pyarrow as pa
import pytest
from byteforge import create_encoding

from fletchr_measurand import EUC, MeasurandResult
from fletchr_uintn import UIntNType

# --- helpers ---


def _pa_dns(values, bits):
    dtype = np.uint8 if bits <= 8 else np.uint16
    storage = pa.array(np.array(values, dtype=dtype))
    return pa.ExtensionArray.from_storage(UIntNType(bits), storage)


def _pa_dns_with_nulls(values, validity, bits):
    dtype = np.uint8 if bits <= 8 else np.uint16
    arr = np.array(values, dtype=dtype)
    storage = pa.array(arr, mask=~np.asarray(validity, dtype=bool))
    return pa.ExtensionArray.from_storage(UIntNType(bits), storage)


def _fsl_dns(rows_of_iters, bits):
    """Build a FixedSizeListArray<UIntN(bits), list_size> from a 2-D Python list."""
    n_rows = len(rows_of_iters)
    list_size = len(rows_of_iters[0])
    flat = [v for row in rows_of_iters for v in row]
    dtype = np.uint8 if bits <= 8 else np.uint16
    storage = pa.array(np.array(flat, dtype=dtype))
    inner = pa.ExtensionArray.from_storage(UIntNType(bits), storage)
    fsl = pa.FixedSizeListArray.from_arrays(inner, list_size=list_size)
    assert len(fsl) == n_rows
    return fsl


# --- 1-D arrow backing ---


class TestArrowBacking:
    def test_decoded_unsigned(self):
        r = MeasurandResult(_pa_dns([0, 1, 127, 255], 8), create_encoding("u", bit_width=8))
        assert r.decoded.to_pylist() == [0, 1, 127, 255]

    def test_decoded_twos_complement(self):
        r = MeasurandResult(_pa_dns([0, 127, 128, 255], 8), create_encoding("2c", bit_width=8))
        assert r.decoded.to_pylist() == [0, 127, -128, -1]

    def test_decoded_twos_complement_non_machine_size(self):
        # 12-bit 2c uses the compute strategy
        r = MeasurandResult(
            _pa_dns([0, 0x7FF, 0x800, 0xFFF], 12), create_encoding("2c", bit_width=12)
        )
        assert r.decoded.to_pylist() == [0, 2047, -2048, -1]

    def test_values_equals_decoded_when_no_euc(self):
        r = MeasurandResult(_pa_dns([1, 2, 3], 8), create_encoding("u", bit_width=8))
        assert r.values is r.decoded

    def test_values_with_euc(self):
        r = MeasurandResult(
            _pa_dns([10, 20, 30], 8),
            create_encoding("u", bit_width=8),
            euc=EUC(scale_factor=0.5),
        )
        np.testing.assert_array_almost_equal(np.asarray(r), [5.0, 10.0, 15.0])

    def test_dns_returned_unchanged(self):
        dns = _pa_dns([1, 2, 3], 8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8))
        assert r.dns is dns

    def test_decoded_returns_pa_array(self):
        r = MeasurandResult(_pa_dns([1, 2], 8), create_encoding("u", bit_width=8))
        assert isinstance(r.decoded, pa.Array)

    def test_np_asarray_returns_values(self):
        r = MeasurandResult(
            _pa_dns([10, 20], 8),
            create_encoding("u", bit_width=8),
            euc=EUC(scale_factor=0.1),
        )
        np.testing.assert_array_almost_equal(np.asarray(r), [1.0, 2.0])


# --- null preservation ---


class TestNullPreservation:
    def test_nulls_propagate_to_decoded(self):
        dns = _pa_dns_with_nulls([10, 0, 30], [True, False, True], bits=8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8))
        assert r.decoded.to_pylist() == [10, None, 30]

    def test_nulls_propagate_through_euc(self):
        dns = _pa_dns_with_nulls([10, 0, 30], [True, False, True], bits=8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8), euc=EUC(scale_factor=0.5))
        assert r.values.to_pylist() == [5.0, None, 15.0]

    def test_compute_strategy_preserves_nulls(self):
        # 12-bit 2c (compute strategy, not view)
        dns = _pa_dns_with_nulls([0x7FF, 0, 0x800], [True, False, True], bits=12)
        r = MeasurandResult(dns, create_encoding("2c", bit_width=12))
        assert r.decoded.to_pylist() == [2047, None, -2048]

    def test_np_asarray_nulls_become_nan_with_euc(self):
        dns = _pa_dns_with_nulls([10, 0, 30], [True, False, True], bits=8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8), euc=EUC(scale_factor=0.5))
        arr = np.asarray(r)
        assert arr[0] == 5.0
        assert np.isnan(arr[1])
        assert arr[2] == 15.0


# --- caching ---


class TestCaching:
    def test_decoded_is_cached(self):
        r = MeasurandResult(_pa_dns([1, 2], 8), create_encoding("u", bit_width=8))
        assert r.decoded is r.decoded

    def test_values_is_cached(self):
        r = MeasurandResult(
            _pa_dns([1, 2], 8),
            create_encoding("u", bit_width=8),
            euc=EUC(scale_factor=0.5),
        )
        assert r.values is r.values

    def test_values_aliases_decoded_when_no_euc(self):
        r = MeasurandResult(_pa_dns([1, 2], 8), create_encoding("u", bit_width=8))
        assert r.values is r.decoded


# --- size / indexing / repr ---


class TestSizeAndIndexing:
    def test_len(self):
        r = MeasurandResult(_pa_dns([1, 2, 3], 8), create_encoding("u", bit_width=8))
        assert len(r) == 3

    def test_scalar_index(self):
        r = MeasurandResult(_pa_dns([10, 20, 30], 8), create_encoding("u", bit_width=8))
        assert r[1] == 20

    def test_slice_returns_result(self):
        r = MeasurandResult(_pa_dns([10, 20, 30, 40], 8), create_encoding("u", bit_width=8))
        sliced = r[1:3]
        assert isinstance(sliced, MeasurandResult)
        assert sliced.values.to_pylist() == [20, 30]

    def test_slice_preserves_euc(self):
        euc = EUC(scale_factor=2.0)
        r = MeasurandResult(_pa_dns([1, 2, 3], 8), create_encoding("u", bit_width=8), euc=euc)
        sliced = r[:2]
        assert sliced.euc is euc


class TestRepr:
    def test_repr_includes_class(self):
        r = MeasurandResult(_pa_dns([1], 8), create_encoding("u", bit_width=8))
        assert "MeasurandResult" in repr(r)

    def test_repr_includes_euc_when_present(self):
        r = MeasurandResult(
            _pa_dns([1], 8),
            create_encoding("u", bit_width=8),
            euc=EUC(scale_factor=0.5),
        )
        assert "euc=" in repr(r)


# --- validation ---


class TestValidation:
    def test_rejects_bare_ndarray_dns(self):
        with pytest.raises(TypeError, match="UIntNArray or FixedSizeListArray"):
            MeasurandResult(np.array([1, 2]), create_encoding("u", bit_width=8))  # type: ignore[arg-type]

    def test_rejects_non_encoding(self):
        with pytest.raises(TypeError, match="Encoding"):
            MeasurandResult(_pa_dns([1], 8), "not an encoding")  # type: ignore[arg-type]

    def test_rejects_bit_width_mismatch(self):
        with pytest.raises(ValueError, match="bit width"):
            MeasurandResult(_pa_dns([1], 8), create_encoding("u", bit_width=16))


# --- 2-D FixedSizeList backing (Generator/Supercom output) ---


class TestFixedSizeListBacking:
    def test_decoded_returns_fsl(self):
        dns = _fsl_dns([[10, 20], [30, 40], [50, 60]], bits=8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8))
        assert isinstance(r.decoded, pa.FixedSizeListArray)
        assert r.decoded.to_pylist() == [[10, 20], [30, 40], [50, 60]]

    def test_values_with_2c(self):
        dns = _fsl_dns([[0x7F, 0x80], [0x00, 0xFF]], bits=8)
        r = MeasurandResult(dns, create_encoding("2c", bit_width=8))
        assert r.decoded.to_pylist() == [[127, -128], [0, -1]]

    def test_np_asarray_reshapes_to_2d(self):
        dns = _fsl_dns([[1, 2, 3], [4, 5, 6]], bits=8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8))
        arr = np.asarray(r)
        assert arr.shape == (2, 3)
        np.testing.assert_array_equal(arr, [[1, 2, 3], [4, 5, 6]])

    def test_values_with_euc(self):
        dns = _fsl_dns([[10, 20], [30, 40]], bits=8)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8), euc=EUC(scale_factor=0.5))
        arr = np.asarray(r)
        np.testing.assert_array_almost_equal(arr, [[5.0, 10.0], [15.0, 20.0]])

    def test_nulls_in_flat_values_propagate(self):
        flat = np.array([10, 0, 30, 40], dtype=np.uint8)
        mask = np.array([False, True, False, False])
        storage = pa.array(flat, mask=mask)
        inner = pa.ExtensionArray.from_storage(UIntNType(8), storage)
        dns = pa.FixedSizeListArray.from_arrays(inner, list_size=2)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8))
        assert r.decoded.to_pylist() == [[10, None], [30, 40]]

    def test_nulls_through_euc(self):
        flat = np.array([10, 0, 30, 40], dtype=np.uint8)
        mask = np.array([False, True, False, False])
        storage = pa.array(flat, mask=mask)
        inner = pa.ExtensionArray.from_storage(UIntNType(8), storage)
        dns = pa.FixedSizeListArray.from_arrays(inner, list_size=2)
        r = MeasurandResult(dns, create_encoding("u", bit_width=8), euc=EUC(scale_factor=0.5))
        assert r.values.to_pylist() == [[5.0, None], [15.0, 20.0]]

    def test_rejects_non_uintn_value_type(self):
        plain = pa.FixedSizeListArray.from_arrays(
            pa.array([1, 2, 3, 4], type=pa.uint8()), list_size=2
        )
        with pytest.raises(TypeError, match="UIntNType values"):
            MeasurandResult(plain, create_encoding("u", bit_width=8))

    def test_rejects_bit_width_mismatch(self):
        dns = _fsl_dns([[1, 2]], bits=8)
        with pytest.raises(ValueError, match="bit width"):
            MeasurandResult(dns, create_encoding("u", bit_width=16))
