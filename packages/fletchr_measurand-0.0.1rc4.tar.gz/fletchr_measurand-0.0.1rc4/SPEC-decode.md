# `fletchr` decode metadata convention — draft

**Status: DRAFT v0.5.** One open question (expression-mode allow-list)
remains; resolve before incrementing to v1.0.

> **Python implementation lives in `fletchr-measurand`** (this package).
> The `EUC` class, the `MeasurandResult` container, and the
> field-metadata round-trip helpers implement what this spec describes.
> The spec doc is shipped here for proximity but is versioned
> independently of the package.

Companion to [SPEC.md](../fletchr-uintn/SPEC.md): SPEC.md describes how raw bytes are encoded
in a column; this document describes how application-layer "decoded" or
"engineering-unit" values can be derived from those raw bytes.

## Scope

A column's *Arrow type* (e.g. `fletchr.uintn(bits=12)`) describes the
physical storage of the raw bytes — what bit width they are and how big a
container holds them. **Interpretation** of those bits (as unsigned integer,
two's-complement signed, IEEE 754, MIL-STD-1750A, BCD, ...) is **not** part
of the type; it is **field metadata**.

Decoding a column to its physical quantity is a **two-stage** operation:

```
raw bits
   │
   ▼  Level 1: bit-pattern decoder, selected by   `fletchr.encoding`
   │  (raw bits → number)
   ▼
number  (signed int, IEEE 754 float, BCD digits, …)
   │
   ▼  Level 2: numerical transform, configured by `fletchr.scale_factor` /
   │          `fletchr.data_bias` / `fletchr.scaled_bias` / `fletchr.expression`
   ▼
float64 decoded value
```

Both stages are metadata-driven. Both stages are optional and may be omitted
independently.

This convention applies to any column whose storage is `fletchr.uintn` (or
a compatible raw integer / `FixedSizeBinary` storage type). Two columns
with the same raw storage type but different decoding metadata remain the
*same Arrow type* and concat / join / schema-compare without conflict.

## Where the metadata lives

Decode keys live in the `metadata` dict of the column's `pa.Field`,
alongside Arrow's reserved `ARROW:extension:*` keys. They round-trip
losslessly through Arrow IPC and Parquet.

All values are UTF-8 byte strings, matching pyarrow's `Dict[bytes, bytes]`
field metadata model.

## Reserved key namespace

All keys defined here use the prefix `fletchr.`. Producers and consumers MAY
add keys outside this prefix; those are out of scope and untouched by this
convention.

## Level 1 — bit-pattern encoding

| Key                  | Value type | Required | Meaning                                                      |
|----------------------|------------|----------|--------------------------------------------------------------|
| `fletchr.encoding`   | string     | no       | Identifier from the registry below. Absent ≡ `"uint"`.       |

If present, `fletchr.encoding` selects the Level 1 decoder that turns raw
bits into a number. The result is the input to Level 2.

### Encoding registry (v1)

The value is a short identifier; readers dispatch on exact-match. Readers
MUST tolerate unknown encoding values and SHOULD surface a clear error
(rather than silently skipping Level 1).

| `fletchr.encoding` | Required raw storage             | Level 1 produces            | Decoder notes |
|--------------------|----------------------------------|-----------------------------|---------------|
| absent / `"u"`     | `fletchr.uintn(bits=N)`          | unsigned integer            | Identity. Raw bits are the number. |
| `"sm"`             | `fletchr.uintn(bits=N)`, `N>=2`  | signed integer              | Sign-magnitude. High bit is sign; remaining `N-1` bits are unsigned magnitude. Two encodings of zero (`+0`, `-0`) decode to `0`. |
| `"1c"`             | `fletchr.uintn(bits=N)`, `N>=2`  | signed integer              | One's-complement. Negative values are the bitwise NOT of the absolute value over `N` bits. Two encodings of zero. |
| `"2c"`             | `fletchr.uintn(bits=N)`, `N>=2`  | signed integer              | Two's-complement. Sign-extend the high bit across the unused upper bits of the container. |
| `"ob"`             | `fletchr.uintn(bits=N)`, `N>=2`  | signed integer              | Offset binary. Decoded value is `raw - 2^(N-1)`. Equivalent to setting `data_bias = 2^(N-1)` on a `uint` encoding. |
| `"ieee32"`         | `fletchr.uintn(bits=32)`         | IEEE 754 `binary32`         | Reinterpret the 32-bit container as IEEE 754 single precision. |
| `"ieee64"`         | `fletchr.uintn(bits=64)`         | IEEE 754 `binary64`         | Reinterpret the 64-bit container as IEEE 754 double precision. |
| `"1750a32"`        | `fletchr.uintn(bits=32)`         | IEEE 754 `binary64`         | MIL-STD-1750A 32-bit. 24-bit two's-complement mantissa (bits 8–31, normalized) × `2^exponent` where exponent is the 8-bit two's-complement value in bits 0–7. |
| `"1750a48"`        | `fletchr.uintn(bits=48)`         | IEEE 754 `binary64`         | MIL-STD-1750A 48-bit extended precision. 40-bit two's-complement mantissa × `2^exponent`, exponent as for `1750a32`. Storage is `fletchr.uintn(bits=48)`; the 48-bit value occupies the low 48 bits of a uint64 container, with the high 16 bits zero per the fletchr-uintn padding rule. |
| `"bcd"`            | `fletchr.uintn(bits=N)`, `N` multiple of `4` | unsigned integer | Packed BCD. Each 4-bit nibble carries one decimal digit `0..9`. The numeric value is the sum of digit × `10^position`, most-significant nibble first. Nibble values `10..15` are invalid; readers MAY emit `nan` (after Level 2 promotion) or raise. |
| `"boolean"`        | `fletchr.uintn(bits=1)`          | unsigned integer (`0` or `1`) | Single-bit boolean. The Level 1 output is the raw bit. Bit width is fixed at 1. |
| `"gray"`           | `fletchr.uintn(bits=N)`, `N>=1`  | unsigned integer            | Gray code (reflected binary). Adjacent integers differ by exactly one bit. The Level 1 output is the standard-binary integer equivalent of the input Gray code. |
| `"ibm32"`          | `fletchr.uintn(bits=32)`         | IEEE 754 `binary64`          | IBM System/360 hexadecimal floating-point, 32-bit. Sign bit, 7-bit excess-64 exponent (base 16), 24-bit hex mantissa. |
| `"ibm64"`          | `fletchr.uintn(bits=64)`         | IEEE 754 `binary64`          | IBM System/360 hexadecimal floating-point, 64-bit. Same layout as `ibm32` with a 56-bit hex mantissa. |
| `"dec32"`          | `fletchr.uintn(bits=32)`         | IEEE 754 `binary64`          | DEC VAX F-float (single precision). 8-bit excess-128 exponent, 23-bit fraction with hidden leading bit. |
| `"dec64"`          | `fletchr.uintn(bits=64)`         | IEEE 754 `binary64`          | DEC VAX D-float (double precision, F-float-compatible exponent). 8-bit excess-128 exponent, 55-bit fraction with hidden leading bit. |
| `"dec64g"`         | `fletchr.uintn(bits=64)`         | IEEE 754 `binary64`          | DEC VAX G-float (double precision, extended range). 11-bit excess-1024 exponent, 52-bit fraction with hidden leading bit. |
| `"ti32"`           | `fletchr.uintn(bits=32)`         | IEEE 754 `binary64`          | Texas Instruments 32-bit floating-point. 8-bit signed exponent, 23-bit two's-complement mantissa with implicit leading bit. |
| `"ti40"`           | `fletchr.uintn(bits=40)`         | IEEE 754 `binary64`          | Texas Instruments 40-bit floating-point. 8-bit signed exponent, 31-bit two's-complement mantissa with implicit leading bit. Storage is `fletchr.uintn(bits=40)`; the 40-bit value occupies the low 40 bits of a uint64 container, with the high 24 bits zero per the fletchr-uintn padding rule. |

**Storage-compatibility check.** Readers MUST verify the column's storage
type matches the "Required raw storage" entry for the declared encoding. A
mismatch (e.g. `encoding="ieee32"` on a `fletchr.uintn(bits=16)` column)
MUST be rejected as malformed.

**Future encodings.** The registry is open to additions in patch revisions
of this spec (new identifiers, no behavior change to existing ones). Readers
MUST tolerate unknown identifiers; they MUST NOT silently fall back to
`"uint"`.

**Linear scaling is intentionally not a Level 1 encoding.** Although
linear scaling could in principle be modeled as a bit-pattern decoder, it
is fully expressible via Level 2's `fletchr.scale_factor`,
`fletchr.data_bias`, and `fletchr.scaled_bias` keys (see § Level 2).
Producers MUST express linear scaling through Level 2 to avoid two
inequivalent ways of saying the same thing. (Implementations like
byteforge that expose `linear_scaled` as a numeric encoding for their
own ergonomics do not map it into this registry.)

## Level 2 — numerical transform

Three states:

| State | Triggering metadata | Result |
|-------|---------------------|--------|
| **Identity** | None of the linear keys or `fletchr.expression` present. | Level 2 is the identity; the Level 1 output is promoted to `float64`. |
| **Linear** | Any of `scale_factor`, `data_bias`, `scaled_bias` present. | Conditional three-step affine transform; see formula below. Steps with absent keys are skipped. |
| **Expression** | `fletchr.expression` present. | Arbitrary expression evaluated per element; see below. |

Linear and Expression states MUST NOT both be specified for the same column.
Readers MUST reject metadata that contains `fletchr.expression` *and* any of
the linear keys as malformed.

### Linear-mode keys

Each key is independently optional. **Absent means "skip this step,"** not
"use a default of zero or one." A producer that has no raw-domain bias
SHOULD simply omit `fletchr.data_bias` rather than emit `0.0`.

| Key                       | Value type | Required | Meaning when present                                                       |
|---------------------------|------------|----------|----------------------------------------------------------------------------|
| `fletchr.scale_factor`    | number     | no       | Multiplicative factor. When absent, no scaling step is applied.            |
| `fletchr.data_bias`       | number     | no       | Offset in **Level-1-output units** — the Level-1 value that maps to zero in the scaled domain. When absent, no Level-1-domain shift is applied. |
| `fletchr.scaled_bias`     | number     | no       | Offset in **scaled units**, added after scaling. When absent, no scaled-domain shift is applied. |

**Decode formula** (operating on `value` = Level 1 output, promoted to
`float64`):

```
result = float64(value)
if data_bias    is present:  result = result - data_bias
if scale_factor is present:  result = result * scale_factor
if scaled_bias  is present:  result = result + scaled_bias
decoded = result
```

The three steps apply in a fixed order: subtraction in Level-1 units, then
multiplication, then addition in scaled units. Each step is independently
opt-in.

**Inverse (encode) reference** — for documentation only; v1 does not require
implementations to provide an `encode` operation:

```
value = decoded
if scaled_bias  is present:  value = value - scaled_bias
if scale_factor is present:  value = value / scale_factor
if data_bias    is present:  value = value + data_bias
```

(The Level 1 step is also invertible per encoding, but those inverses are
out of scope for the v1 metadata convention.)

### Expression-mode key

| Key                   | Value type | Meaning                                                                |
|-----------------------|------------|------------------------------------------------------------------------|
| `fletchr.expression`  | string     | A mathematical expression in `raw`, evaluated element-wise.            |

When present, the expression is the sole Level 2 rule for the column. The
three linear-mode keys MUST NOT also be present.

The expression operates on the **Level 1 output**, not on the original raw
bits. Inside the expression, the variable `raw` refers to the Level 1 value
(the signed integer, IEEE 754 float, etc. produced by the configured
`fletchr.encoding`). This is so that the same expression text works
regardless of which encoding produced the number.

**Grammar (v1):**

- The expression MUST be parseable as a Python expression
  (`ast.parse(expr, mode='eval')`).
- Implementations MUST parse to an AST and walk it, rejecting any node type
  or name not on the allow-list. **Use of `eval()` on the raw expression
  string is FORBIDDEN** — these strings come from data files and are
  untrusted input.
- The only variable in scope is `raw` (the per-element Level 1 output).
- The decoded output type is `float64`.

The exact allow-lists for operators, functions, and named constants are
**deferred** to v1.0 finalization (see Open Questions). Implementations
targeting draft v0.5 SHOULD use a conservative interim allow-list (basic
arithmetic + the most common `math` module functions) and document what
they accept.

**Vectorization:** implementations SHOULD compile the expression to a
NumPy-vectorized form (e.g. by binding `numpy.sqrt` rather than `math.sqrt`)
so it operates over the whole array, not element-by-element in Python.

**Edge cases:** division by zero, `log(0)`, `sqrt(-1)`, etc. — implementations
MAY emit IEEE-754 special values (`inf`, `nan`) and SHOULD NOT raise.
Producers SHOULD avoid emitting expressions that hit these points unless the
resulting `nan` / `inf` is semantically intended.

## Ancillary keys (any mode)

| Key                       | Value type | Meaning                                                                                                                          |
|---------------------------|------------|----------------------------------------------------------------------------------------------------------------------------------|
| `fletchr.unit`            | string     | Free-form physical-unit string. **UCUM is recommended** (`Cel`, `mV`, `m/s`); UDUNITS (`celsius`, `millivolt`, `m s-1`) is also widely understood. Consumers SHOULD NOT attempt to parse unless the producer documents which standard was used. |
| `fletchr.description`     | string     | Free-text human-readable label for the column.                                                                                   |

These have no effect on the decoded numeric values; they are documentation
that travels with the column.

**Unit examples** for reference:

| Quantity         | UCUM       | UDUNITS-2                       |
|------------------|------------|---------------------------------|
| Celsius          | `Cel`      | `degC`, `celsius`               |
| Fahrenheit       | `[degF]`   | `degF`, `degree_Fahrenheit`     |
| Kelvin           | `K`        | `K`, `kelvin`                   |
| millivolt        | `mV`       | `mV`, `millivolt`               |
| meters/second    | `m/s`      | `m/s`, `m s-1`, `meter/second`  |
| newton (kg·m/s²) | `N`        | `N`, `kg m s-2`                 |
| parts per million| `[ppm]`    | `ppm`                           |
| percent          | `%`        | `%`, `percent`                  |
| dimensionless    | `1`        | `1`                             |
| time since epoch | (no native)| `seconds since 1970-01-01`      |

## Number format

Numeric metadata values (`scale_factor`, `data_bias`, `scaled_bias`, plus any
numeric literals embedded in `expression`) MUST be valid JSON number literals
(`json.loads`-parseable for the metadata keys; standard Python numeric
literals for the expression body). This admits decimal (`"0.001"`),
scientific (`"1e-3"`), integer (`"42"`), and signed (`"-273.15"`) forms.

The strings `"null"`, `""`, and `"undefined"` are NOT valid number
representations. Readers MUST reject metadata in which any of the linear keys
carries a non-numeric value. To indicate "this step is not applied,"
producers MUST omit the key.

## Decoded value type

The decoded value type is always **`float64`** in v1. This applies uniformly
to identity, linear, and expression Level 2 states, and to every Level 1
encoding.

Rationale: raw bits are preserved on disk as the canonical source of truth;
the decoded view is a presentation layer that doesn't need to preserve
integer types or minimize bit width. `float64` covers exact integer
representation up to `2^53`, which encompasses every fixed-bit-width raw
type up to and including most of `uint64`. Any producer needing a
non-default output dtype can post-process the result.

Reference implementations MAY expose a `target_type=` parameter on their
`decode()` function as a caller-side convenience; the wire format does not
carry this preference in v1.

The key `fletchr.decoded_dtype` is **reserved** for a future revision that
may permit producer-side override; v1 producers MUST NOT emit it and v1
readers MUST tolerate its presence.

## Decode operation

Given a column `arr` of length `n` and its field `field`:

1. **Materialize raw values as numeric.** Use `arr.to_numpy(zero_copy_only=False)`
   after `pc.fill_null(arr, 0)`; remember the null mask separately.
2. **Apply Level 1** by looking up `fletchr.encoding` in the registry and
   running the corresponding bit-pattern decoder. When the key is absent (or
   set to `"uint"`), Level 1 is the identity.
   Verify that the column's storage type matches the encoding's storage
   requirement; reject as malformed on mismatch.
3. **Determine Level 2 state** from the metadata (Identity / Linear /
   Expression). Reject as malformed if Linear and Expression keys are both
   present.
4. **Promote the Level 1 output to `float64`.**
5. **Compute the Level 2 transform** per the state's formula.
6. **Reapply nulls.** Positions null in `arr` are null in the result.
7. **Wrap** as a `pa.Array` of `float64`.

## Null handling

Nulls propagate from raw to decoded. The decoded column has the same null
bitmap as the input. Level 1 decoding operates on filled-null values
(typically `0`) and the result for those positions is discarded by the
reapply-nulls step.

## Examples

### A — unsigned scale + scaled bias (no Level 1 encoding)

```python
import pyarrow as pa
from fletchr_arrow import uintn_array

raw = uintn_array([100, 250, 175], bits=8)
field = pa.field("temperature", raw.type, metadata={
    b"fletchr.scale_factor": b"0.1",
    b"fletchr.scaled_bias":  b"-40.0",
    b"fletchr.unit":         b"Cel",
})
# fletchr.encoding omitted → Level 1 is identity (raw uintn).

# Level 1:  100, 250, 175    (just promoted to float)
# Level 2:  *0.1 + (-40)
# Decoded:  -30.0, -15.0, -22.5
```

### B — two's-complement signed integer

```python
raw = uintn_array([0x00, 0x7F, 0x80, 0xFF], bits=8)
field = pa.field("counter", raw.type, metadata={
    b"fletchr.encoding": b"2c",
})

# Level 1 (two's-complement):  0, 127, -128, -1
# Level 2 (identity):           0.0, 127.0, -128.0, -1.0
```

### C — offset-binary signed integer

```python
# 8-bit ADC where 128 represents 0 mV.
raw = uintn_array([128, 200, 50], bits=8)
field = pa.field("voltage", raw.type, metadata={
    b"fletchr.encoding": b"ob",
    b"fletchr.unit":     b"mV",
})

# Level 1 (offset binary):  0, 72, -78
# Level 2 (identity):       0.0, 72.0, -78.0
```

(Equivalent to: `encoding` omitted + `data_bias=128`. The `ob` encoding is
more explicit; the linear form is more arithmetic-flexible if you want to
compose biases.)

### D — IEEE 754 single precision reinterpretation

```python
# Raw is a uint32 column holding 32-bit IEEE 754 bit patterns
# (e.g. read from a binary file that stores floats as packed bytes).
raw = uintn_array([0x3F800000, 0x40490FDB, 0xC0000000], bits=32)
field = pa.field("measurement", raw.type, metadata={
    b"fletchr.encoding": b"ieee32",
})

# Level 1:  1.0, π ≈ 3.14159, -2.0
# Level 2 (identity).
```

### E — MIL-STD-1750A with linear post-scaling

```python
raw = uintn_array([...], bits=32)
field = pa.field("airspeed", raw.type, metadata={
    b"fletchr.encoding":     b"1750a32",
    b"fletchr.scale_factor": b"1.94384",   # m/s → knots
    b"fletchr.unit":         b"[kn_i]",
})

# Level 1:  the floating-point value encoded in 1750A bits (m/s)
# Level 2:  * 1.94384
# Decoded:  airspeed in knots
```

### F — packed BCD

```python
# Each byte holds two decimal digits: 0x42 → 42, 0x99 → 99
raw = uintn_array([0x12, 0x42, 0x99], bits=8)
field = pa.field("count", raw.type, metadata={
    b"fletchr.encoding": b"bcd",
})

# Level 1:  12, 42, 99
# Level 2 (identity): 12.0, 42.0, 99.0
```

### G — expression mode over a signed encoding

```python
raw = uintn_array([0, 0x7F, 0x80, 0xFF], bits=8)
field = pa.field("nonlinear", raw.type, metadata={
    b"fletchr.encoding":   b"2c",
    b"fletchr.expression": b"raw * raw * 0.01",
})

# Level 1 (2c):  0, 127, -128, -1
# Level 2 (expr): raw**2 * 0.01
#   0    → 0.0
#   127  → 161.29
#   -128 → 163.84
#   -1   → 0.01
```

### H — identity decode (no metadata at all)

```python
raw = uintn_array([0, 1, 2, 3], bits=2)
field = pa.field("flag", raw.type)   # no decode metadata

# Level 1 (uint): 0, 1, 2, 3
# Level 2 (identity)
# Decoded: 0.0, 1.0, 2.0, 3.0
```

### I — wire-level view of a Parquet column with metadata

```
field "airspeed":
    type: uint32
    metadata:
        "ARROW:extension:name":     "fletchr.uintn"
        "ARROW:extension:metadata": "{\"bits\":32}"
        "fletchr.encoding":         "1750a32"
        "fletchr.scale_factor":     "1.94384"
        "fletchr.unit":             "[kn_i]"
```

A reader in any language can read the metadata bytes directly — no
`fletchr-arrow` library dependency is required to interpret the decode rule,
provided the reader implements the Level 1 decoders it cares about.

## Forward-extensibility hooks (reserved, v1 producers MUST NOT emit)

Readers MUST tolerate the presence of these keys even if they don't understand
them. v1 producers MUST NOT emit them.

| Key                       | Reserved for                                                |
|---------------------------|-------------------------------------------------------------|
| `fletchr.decoded_dtype`   | Producer-side override of the default `float64` output type.|
| `fletchr.encode_kind`     | Explicit reverse-mapping configuration for writers.         |

## Versioning

This document is **draft v0.5**. Future revisions:

- Within v1, only backwards-compatible additions are permitted. The
  Level 1 encoding registry is open to new identifiers in patch revisions
  (e.g. `v1.1` could add `"cf_packed_uint12"` or `"ccsds_cuc"`) without
  changing the behavior of existing ones.
- Readers MUST ignore unknown metadata keys; readers MUST surface a clear
  error rather than silently ignoring an unknown `fletchr.encoding`.
- Breaking changes increment the major version and SHOULD coincide with
  changes to either the metadata key prefix or the documented decode
  pipeline, so that v1 readers fail loudly rather than misinterpret v2 data.

### Changelog

**v0.4 → v0.5**
- Fixed typo: `1750a64` renamed to `1750a48`, storage corrected to
  `fletchr.uintn(bits=48)`. Producers using the v0.4 typo MUST migrate.
- Added Level 1 encodings to the registry: `boolean`, `gray`, `ibm32`,
  `ibm64`, `dec32`, `dec64`, `dec64g`, `ti32`, `ti40`.
- Clarified that `linear_scaled` is intentionally NOT a Level 1 encoding
  — linear scaling lives in Level 2.
- Documented that the Python reference implementation delegates Level 1
  to byteforge (with a future Arrow-native rewrite as `fletchr-encodings`).

## Open design questions

### 1. Expression-mode allow-list (DEFERRED)

v1.0 needs to pin exact sets for:

- Allowed AST node types (`BinOp`, `UnaryOp`, `Call`, `Name`, `Constant`,
  parentheses — but what about `IfExp`? Boolean ops? Comparisons?).
- Allowed binary/unary operators (`+ - * / // % **` and unary `-` are the
  uncontroversial core; what about `|`, `&`, `^`, `<<`, `>>`?).
- Allowed named constants (`pi`, `e`, `inf`, `nan` — others?).
- Allowed function names (the `math` module is the obvious starting set, but
  the exact list — e.g. include `gamma`, `erf`, `atan2`? — wants a
  deliberate decision rather than "whatever Python's math has today").
- Whether implementations are allowed to add functions beyond the
  allow-list (probably no — interop demands a single source of truth).

Until v1.0 pins this, draft-v0.5 implementations SHOULD document what subset
they accept and reject anything else loudly.

## Reference implementation (planned)

To be added under `fletchr_decode` after this draft is reviewed.

**The prose specification is authoritative.** The reference implementation
is a convenience; if its behavior diverges from this document, the
implementation is buggy.

**Level 1 backend.** The reference implementation delegates Level 1
decoding to [byteforge](https://github.com/jolsten/byteforge), which
implements every encoding above with both pure-Python and C
fast-paths. A thin name-alias layer reconciles short-name differences
(e.g. byteforge's `offset_binary` is exposed as `ob` per this SPEC).
A future Arrow-native rewrite — provisionally `fletchr-encodings` —
will provide bit-width-safe `pa.compute`-style kernels operating
directly on `pa.Array<fletchr.uintn>` columns; at that point the
reference implementation will swap its Level 1 dependency. The SPEC
above is independent of that backend choice.

```python
def decode(
    column: pa.Array,
    field: pa.Field,
    *,
    target_type: pa.DataType = pa.float64(),
) -> pa.Array:
    """Apply decode metadata from `field` to `column`; return decoded array.

    Two-stage pipeline:
      1. Level 1 (bit-pattern): selected by `fletchr.encoding`.
      2. Level 2 (numerical):   linear keys or `fletchr.expression`.

    Spec is authoritative; this function is a reference implementation.
    """


def decoded_table(
    table: pa.Table,
    *,
    raw_suffix: str = "_raw",
    keep_raw: bool = True,
) -> pa.Table:
    """Materialize decoded sibling columns for every column that has
    decode metadata.

    Naming policy: decoded column keeps the bare original name; the raw
    column is renamed with `raw_suffix` (default `"_raw"`). Pass
    `keep_raw=False` to drop the raw column entirely.
    """
```
