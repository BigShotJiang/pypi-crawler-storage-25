from __future__ import annotations

from .euc import EUC, SamplingStrategy
from .measurand import Measurand, MeasurandSpec
from .parameter import Parameter, ParameterSpec
from .parsers import calculator_parser, measurand_parser, parameter_parser
from .result import MeasurandResult


def resolve_parameter(parameter: ParameterSpec) -> Parameter:
    """Return a `Parameter`, parsing from a spec string if needed.

    A prebuilt `Parameter` passes through unchanged. Used in
    transformer constructors to accept either form ergonomically.
    """
    if isinstance(parameter, str):
        return parameter_parser.parse(parameter)
    return parameter


def resolve_measurand(measurand: MeasurandSpec) -> Measurand:
    """Return a `Measurand`, parsing from a spec string if needed.

    A prebuilt `Measurand` passes through unchanged. Used in
    transformer constructors to accept either form ergonomically.
    """
    if isinstance(measurand, str):
        return measurand_parser.parse(measurand)
    return measurand


__all__ = [
    "EUC",
    "Measurand",
    "MeasurandResult",
    "MeasurandSpec",
    "Parameter",
    "ParameterSpec",
    "SamplingStrategy",
    "calculator_parser",
    "measurand_parser",
    "parameter_parser",
    "resolve_measurand",
    "resolve_parameter",
]
