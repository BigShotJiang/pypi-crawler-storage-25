"""Typed aliases for the `pyarrow.compute` kernels used in this package.

`pyarrow.compute` generates most of its kernels dynamically at import
time via `make_compute_function`; pyright/pylance's stubs don't cover
all of them, producing spurious `reportAttributeAccessIssue` warnings
on every call site. Re-exporting them as `Any`-typed module-level
aliases here gives pyright something it can resolve without changing
runtime behavior.

Usage:

    from . import _pa_compute as pc
    result = pc.bit_wise_and(arr, mask)

The list mirrors the kernels actually invoked from `parameter.py`;
extend it as new kernels get adopted.
"""

from __future__ import annotations

from typing import Any

import pyarrow.compute as _pc

add: Any = _pc.add
bit_wise_and: Any = _pc.bit_wise_and
bit_wise_not: Any = _pc.bit_wise_not
bit_wise_or: Any = _pc.bit_wise_or
bit_wise_xor: Any = _pc.bit_wise_xor
cast: Any = _pc.cast
fill_null: Any = _pc.fill_null
shift_left: Any = _pc.shift_left
shift_right: Any = _pc.shift_right
