from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal, Union

import numpy as np
import pyarrow as pa

from fletchr_uintn import UIntNType

from . import _bitops
from . import _pa_compute as pc

if TYPE_CHECKING:
    from collections.abc import Callable


# --------------------------------------------------------------------------- #
# Storage-type helpers (numpy ⇄ pyarrow)                                      #
# --------------------------------------------------------------------------- #


def _pa_storage_type(bit_width: int) -> pa.DataType:
    """Smallest pyarrow unsigned primitive holding `bit_width` bits."""
    machine = _bitops.word_size_to_machine_size(bit_width)
    return {8: pa.uint8(), 16: pa.uint16(), 32: pa.uint32(), 64: pa.uint64()}[machine]


def _column_bit_width(col: pa.Array) -> int:
    """Bit width of `col`'s value type.

    For a `fletchr.uintn(bits=N)` extension column, returns `N`. For a
    plain `pa.uintN`, returns the storage width (8/16/32/64).
    """
    col_type = col.type
    bits = getattr(col_type, "bits", None)
    if bits is not None:
        return int(bits)
    # Plain uint storage — fall back to the storage width.
    return col_type.bit_width


def _data_column_name(index: int) -> str:
    """Name of the i-th data column in a FrameArray-shaped table.

    Mirrors fletchr-core's `c{j}` convention (see `_data_column_names`
    in `fletchr_core.containers.framearray`). Centralized here so the
    naming contract has a single point of change.
    """
    return f"c{index}"


def _normalize_column(col: pa.Array | pa.ChunkedArray) -> pa.ExtensionArray:
    """Return `col` as a single-chunk `UIntNArray`.

    `pa.Table.column(...)` returns a `ChunkedArray`; bit-width-safe
    methods (`bit_wise_and`, `bit_wise_not`, …) live on `UIntNArray`,
    not on `ChunkedArray`, so we combine chunks here. Plain `pa.uintN`
    columns get wrapped as `UIntNArray(bits=storage_width)` so the
    downstream build path is uniform.
    """
    if isinstance(col, pa.ChunkedArray):
        col = col.combine_chunks()
    if isinstance(col.type, UIntNType):
        return col  # already a UIntNArray
    # Plain uintN — wrap at storage width.
    return pa.ExtensionArray.from_storage(UIntNType(_column_bit_width(col)), col)


# --------------------------------------------------------------------------- #
# Fragments                                                                   #
# --------------------------------------------------------------------------- #


class Fragment(ABC):
    complement: bool
    reverse: bool

    @abstractmethod
    def build(self, table: pa.Table, /, offset: int = 0) -> pa.ExtensionArray:
        """Build the fragment from a FrameArray-shaped `pa.Table`.

        Each fragment self-extracts the c{j} column(s) it needs from
        `table` (normalizing chunks + extension-wrapping lazily) — so
        only the columns this fragment actually reads incur the
        `combine_chunks` cost.

        Args:
            table: FrameArray-shaped `pa.Table` with `c0..cN` columns.
            offset: Column-index offset (used by `GeneratorParameter`).

        Returns:
            A `UIntNArray` whose `type.bits` is the semantic bit width
            of the fragment's output.
        """


@dataclass
class FragmentWord(Fragment):
    word: int
    bits: list[int] | None = None
    complement: bool = False
    reverse: bool = False
    word_size: int | None = None

    one_based: bool = True
    _mask_shift: list[tuple[int, int]] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if self.bits is not None:
            self._bit_ranges = _bitops.bit_list_to_ranges(self.bits)
            self._mask_shift = []
            for bit_range in self._bit_ranges:
                self._mask_shift.append(_bitops.bits_to_mask_and_shift(bit_range))

    def __str__(self) -> str:
        if self.bits:
            bit_ranges: list[str] = []
            for a, b in _bitops.bit_list_to_ranges(self.bits):
                if a == b:
                    bit_ranges.append(str(b))
                else:
                    bit_ranges.append(f"{a}-{b}")
            s = f"""{self.word}:{",".join(bit_ranges)}"""
        else:
            s = f"{self.word}"

        s = ("~" if self.complement else "") + s
        s = s + ("R" if self.reverse else "")

        return s

    def __eq__(self, other) -> bool:
        if isinstance(other, FragmentWord):
            bits_a = self.bits if self.bits is None else sorted(self.bits)
            bits_b = other.bits if other.bits is None else sorted(other.bits)
            return all(
                [
                    self._column_index() == other._column_index(),
                    bits_a == bits_b,
                    self.complement == other.complement,
                    self.reverse == other.reverse,
                ]
            )
        return NotImplemented

    def _column_index(self, offset: int = 0) -> int:
        """0-based column index this fragment reads, accounting for `one_based`."""
        return self.word - int(self.one_based) + offset

    def build(self, table: pa.Table, /, offset: int = 0) -> pa.ExtensionArray:
        result = _normalize_column(table.column(_data_column_name(self._column_index(offset))))
        input_word_size = _column_bit_width(result)
        if self.word_size is None:
            self.word_size = input_word_size

        if self.bits is not None:
            if self.word_size != input_word_size:
                msg = (
                    f"data.word_size={input_word_size} does not match "
                    f"fragment.word_size={self.word_size}"
                )
                raise ValueError(msg)

            column = result
            frag_size = len(self.bits)
            narrow_storage_type = _pa_storage_type(frag_size)

            # Use an accumulator to handle potentially non-contiguous bit ranges
            accumulator = pa.ExtensionArray.from_storage(
                UIntNType(frag_size),
                pa.array(
                    np.zeros(len(column), dtype=_bitops.word_size_to_dtype(frag_size)),
                    type=narrow_storage_type,
                ),
            )
            out_pos = 0
            for mask, shift in self._mask_shift:
                width = bin(mask).count("1")
                chunk = column.bit_wise_and(mask).shift_right(shift)
                chunk_storage = chunk.storage
                if chunk_storage.type != narrow_storage_type:
                    chunk_storage = pc.cast(chunk_storage, narrow_storage_type, safe=False)
                chunk_narrow = pa.ExtensionArray.from_storage(UIntNType(frag_size), chunk_storage)
                accumulator = accumulator.bit_wise_or(chunk_narrow.shift_left(out_pos))
                out_pos += width
            result = accumulator

        if self.complement:
            result = result.bit_wise_not()

        if self.reverse:
            result = result.bit_wise_reverse()

        return result


@dataclass
class FragmentConstant(Fragment):
    value: int | np.unsignedinteger
    size: int
    complement: bool = False
    reverse: bool = False

    def __str__(self) -> str:
        if self.size % 4 == 0:
            s = f"{self.value:x}"
        elif self.size % 3 == 0:
            s = f"{self.value:o}"
        else:
            s = f"{self.value:b}"

        if self.complement:
            s = "~" + s

        if self.reverse:
            s = s + "R"

        return s

    def __post_init__(self) -> None:
        if self.value < 0:
            msg = f"FragmentConstant(value={self.value}) value must be positive"
            raise ValueError(msg)
        elif self.value < 2**8:
            self.value = np.uint8(self.value)
        elif self.value < 2**16:
            self.value = np.uint16(self.value)
        elif self.value < 2**32:
            self.value = np.uint32(self.value)
        elif self.value < 2**64:
            self.value = np.uint64(self.value)
        else:
            msg = f"FragmentConstant(value={self.value}) value exceeds 2**64-1"
            raise ValueError(msg)

    def build(self, table: pa.Table, /, offset: int = 0) -> pa.ExtensionArray:
        # Broadcast the scalar value across n_rows
        n_rows = table.num_rows
        storage_type = _pa_storage_type(self.size)
        storage = pa.array(
            np.full(n_rows, self.value, dtype=_bitops.word_size_to_dtype(self.size)),
            type=storage_type,
        )
        return pa.ExtensionArray.from_storage(UIntNType(self.size), storage)


def _value_to_constant(value: int, size: int | None = None) -> str:
    if size is None:
        size = len(f"{value:b}")

    if size % 4 == 0:
        return f"x{value:0{size // 4}X}"
    if size % 3 == 0:
        return f"o{value:0{size // 3}o}"
    return f"b{value:b}"


BitOpMode = Literal["AND", "OR", "XOR"]


@dataclass
class BitOperator:
    mode: BitOpMode
    value: int

    _func: Callable = field(init=False, repr=False)

    def __str__(self) -> str:
        return self.mode + " " + _value_to_constant(self.value)

    def __post_init__(self) -> None:
        mode = self.mode.upper()

        if mode == "AND":
            self._func = pc.bit_wise_and
        elif mode == "OR":
            self._func = pc.bit_wise_or
        elif mode == "XOR":
            self._func = pc.bit_wise_xor
        else:
            msg = f"BitOperator(mode={mode}) invalid mode specified"
            raise ValueError(msg)


@dataclass
class Iterator:
    step: int
    stop: int | None = None


# --------------------------------------------------------------------------- #
# Parameters                                                                  #
# --------------------------------------------------------------------------- #


class Parameter:
    def build(self, table: pa.Table, /):
        """Build the parameter from a FrameArray-shaped `pa.Table`.

        Returns a `UIntNArray` (whose `type.bits` carries the output bit
        width) for 1-D outputs, or a `pa.FixedSizeListArray<UIntN>` for
        `GeneratorParameter`/`SupercomParameter`.
        """
        raise NotImplementedError


@dataclass
class BasicParameter(Parameter):
    fragments: list[Fragment]
    bit_op: BitOperator | None = None

    def __str__(self) -> str:
        s = "[" + "+".join(str(f) for f in self.fragments) + "]"

        if self.bit_op:
            s = s + " " + str(self.bit_op)

        return s

    def _calculate_parameter_size(self, word_size: int) -> int:
        """Determine the size of the parameter by adding the fragment sizes."""
        size = 0
        for frag in self.fragments:
            if isinstance(frag, FragmentConstant):
                size += frag.size
            elif isinstance(frag, FragmentWord):
                if frag.bits is None:
                    size += word_size
                else:
                    size += len(frag.bits)
            else:
                msg = f"expected Fragment subclass, but got {type(frag)}"
                raise TypeError(msg)
        return size

    def _all_words(self) -> list[int]:
        """Generate a list of all the words in each Fragment."""
        return [f.word for f in self.fragments if isinstance(f, FragmentWord)]

    def max_word(self) -> int:
        return max(self._all_words())

    def min_word(self) -> int:
        return min(self._all_words())

    def build(self, table: pa.Table, /, offset: int = 0) -> pa.ExtensionArray:
        """Build the parameter from a FrameArray-shaped `pa.Table`.

        Nulls in input columns propagate through to the result via the
        Arrow validity bitmap.
        """
        # Read the input word size from any data column without
        # normalizing — `type.bits` is available on the column's type
        # directly. `c0` is guaranteed to exist on a FrameArray-shaped
        # table.
        input_word_size = _column_bit_width(table.column(_data_column_name(0)))
        size = self._calculate_parameter_size(input_word_size)
        target_type = _pa_storage_type(size)
        n_rows = table.num_rows

        # Accumulate on raw storage (pa.compute kernels) for the shift+add
        # combine; wrap as `UIntNArray<size>` at the end.
        result = pa.array(
            np.zeros(n_rows, dtype=_bitops.word_size_to_dtype(size)),
            type=target_type,
        )

        for frag_idx, frag in enumerate(self.fragments):
            tmp_uintn = frag.build(table, offset=offset)
            tmp_size = tmp_uintn.type.bits
            tmp = tmp_uintn.storage

            if frag_idx != 0:
                # Use a typed scalar for the shift count so the result
                # stays in target_type (Python-int scalars promote to
                # int64 in pyarrow's compute kernels).
                result = pc.shift_left(result, pa.scalar(tmp_size, type=target_type))

            # Promote tmp to the accumulator's storage width before adding.
            if tmp.type != target_type:
                tmp = pc.cast(tmp, target_type, safe=False)
            result = pc.add(result, tmp)

            if self.bit_op:
                # Typed scalar to keep us in target_type.
                result = self.bit_op._func(result, pa.scalar(self.bit_op.value, type=target_type))

        return pa.ExtensionArray.from_storage(UIntNType(size), result)


@dataclass
class GeneratorParameter(Parameter):
    parameter: BasicParameter
    iterator: Iterator
    word_size: int | None = None

    def __post_init__(self) -> None:
        if self.iterator.stop is None and self.iterator.step < 0:
            self.iterator.stop = 0

    def build(self, table: pa.Table, /) -> pa.FixedSizeListArray:
        """Iterates the inner BasicParameter at successive column offsets and
        interleaves the per-iteration `UIntNArray` results into a flat,
        row-major buffer wrapped as `pa.FixedSizeListArray<UIntN(bits),
        list_size=n_iter>`. Each output row's list holds the inner
        parameter's value at each iteration.

        Validity is propagated by interleaving the per-iteration bitmaps
        in lockstep with the values.
        """
        n_data_cols = sum(1 for name in table.column_names if name.startswith("c"))

        start = self.parameter.max_word() if self.iterator.step > 0 else self.parameter.min_word()
        stop = self.iterator.stop if self.iterator.stop is not None else n_data_cols

        results: list[pa.ExtensionArray] = []
        for target in range(start, stop, self.iterator.step):
            offset = target - start
            results.append(self.parameter.build(table, offset=offset))

        # Empty `results` crashes on `results[0]` — intentional. We
        # don't manufacture an empty FixedSizeListArray of unknown
        # bit width.
        n_iter = len(results)
        bits = results[0].type.bits

        has_nulls = any(r.null_count > 0 for r in results)

        # Row-major interleave: for row i, iter j → flat[i * n_iter + j].
        # np.stack(..., axis=1).ravel() gives exactly that layout.
        if has_nulls:
            value_cols = [
                pc.fill_null(r.storage, 0).to_numpy(zero_copy_only=False) for r in results
            ]
            valid_cols = [r.storage.is_valid().to_numpy(zero_copy_only=False) for r in results]
            flat_values = np.stack(value_cols, axis=1).ravel()
            flat_valid = np.stack(valid_cols, axis=1).ravel()
            storage = pa.array(flat_values, mask=~flat_valid)
        else:
            value_cols = [r.storage.to_numpy(zero_copy_only=False) for r in results]
            flat_values = np.stack(value_cols, axis=1).ravel()
            storage = pa.array(flat_values)

        inner = pa.ExtensionArray.from_storage(UIntNType(bits), storage)
        return pa.FixedSizeListArray.from_arrays(inner, list_size=n_iter)


@dataclass
class SupercomParameter(GeneratorParameter):
    parameter: BasicParameter
    iterator: Iterator
    word_size: int | None = None

    # `build` inherited from `GeneratorParameter` — same semantics.


ParameterSpec = Union[str, Parameter]
"""A `Parameter` or a spec string parsed by `parameter_parser`."""
