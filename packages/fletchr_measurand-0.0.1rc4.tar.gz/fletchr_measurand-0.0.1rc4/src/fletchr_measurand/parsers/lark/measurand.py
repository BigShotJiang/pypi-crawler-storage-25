from __future__ import annotations

from collections.abc import Callable
from functools import lru_cache
from typing import TYPE_CHECKING, Any, Union

import lark
from lark import Token, Transformer, v_args

from fletchr_measurand.euc import EUC
from fletchr_measurand.measurand import Measurand
from fletchr_measurand.parsers.lark.calculator import CalculatorTransformer
from fletchr_measurand.parsers.lark.parameter import ParameterTransformer

if TYPE_CHECKING:
    from fletchr_measurand.parameter import Parameter

Number = Union[int, float]
EucArg = Union[Number, Callable[..., Any]]


@v_args(inline=True)
class MeasurandTransformer(Transformer):
    def measurand(
        self,
        parameter: Parameter,
        interp: Any | None = None,
        euc: Any | None = None,
        ss: Any | None = None,
    ) -> Measurand:
        return Measurand(parameter=parameter, encoding=interp, euc=euc)

    def interp(self, token: Token) -> str:
        return str(token)

    def euc(self, *args: EucArg) -> EUC:
        if len(args) == 1:
            return EUC(scale_factor=args[0])

        if len(args) == 2:
            if callable(args[1]):
                raise TypeError(f"EUC scaled_bias must be a Number, got callable: {args[1]!r}")
            return EUC(scale_factor=args[0], scaled_bias=args[1])

        if len(args) == 3:
            if callable(args[0]):
                raise TypeError(f"EUC data_bias must be a Number, got callable: {args[0]!r}")
            if callable(args[2]):
                raise TypeError(f"EUC scaled_bias must be a Number, got callable: {args[2]!r}")
            return EUC(data_bias=args[0], scale_factor=args[1], scaled_bias=args[2])

        raise TypeError(f"EUC expects 1-3 arguments, got {len(args)}")


@lru_cache(maxsize=1)
def _get_measurand_parser():
    """Cache measurand parser instance."""
    measurand_transformer = lark.visitors.merge_transformers(
        MeasurandTransformer(),
        parameter=ParameterTransformer(),
        calculator=CalculatorTransformer(),
    )
    return lark.Lark.open(
        "measurand.lark",
        rel_to=__file__,
        parser="lalr",
        transformer=measurand_transformer,
    )
