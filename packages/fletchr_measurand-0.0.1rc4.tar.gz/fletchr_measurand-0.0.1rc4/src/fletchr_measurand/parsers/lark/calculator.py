"""Parser and evaluator for mathematical expressions.

This module implements a caculator for evaluating mathematical expressions
contained within Engineering Unit Conversion (EUC) specification strings.

Supported Operations:
    - Arithmetic: +, -, *, /, **, %
    - Functions: sin, cos, tan, sqrt, log, log10, abs, ceil, floor
    - Constants: PI, E
    - Custom: nxtwo (next power of 2), deg (rad to deg), rad (deg to rad), tento (10**x)

Examples:
    "PV * 2.5 + 10                  - Linear scaling
    "sqrt(x**2 + y**2)              - Vector magnitude
    "180/pi * x"                    - Radians to Degrees
    "10**(x / 1000)"                - Exponential conversion

    The parser produces callable functions that can be applied to numeric values.
"""

from __future__ import annotations

import math
import operator
from collections.abc import Callable
from functools import lru_cache
from typing import Any, Union

from lark import Lark, Token, Transformer, v_args

Number = Union[int, float]
CN = Union[Number, Callable]


def nxtwo(val: Number) -> int:
    return 2 ** math.ceil(math.log(val, 2))


def tento(val: Number) -> Number:
    return 10**val


def hamdist(a: Number, b: Number) -> int:
    return f"{int(a) ^ int(b):b}".count("1")


def _lift(fn: Callable[..., Any]) -> Any:
    """Lift a plain function to transparently handle Callable (PV-dependent) arguments."""

    def method(self, *args: CN) -> CN:
        if any(callable(a) for a in args):

            def f(PV):
                return fn(*(a(PV) if callable(a) else a for a in args))

            return f
        return fn(*args)

    return method


@v_args(inline=True)
class CalculatorTransformer(Transformer):
    def pv(self, _: Token) -> CN:
        def f(PV):
            return PV

        return f

    def number(self, token: Token) -> Number:
        try:
            return int(token)
        except ValueError:
            return float(token)

    def constant(self, token: Token) -> float:
        if token == "E":
            return math.e
        if token == "PI":
            return math.pi
        raise ValueError(f"Unknown calculator constant: {token!r}")

    # Arithmetic
    add = _lift(operator.add)
    sub = _lift(operator.sub)
    mul = _lift(operator.mul)
    div = _lift(operator.truediv)
    pow = _lift(operator.pow)
    neg = _lift(operator.neg)

    # Type conversion / rounding
    float = _lift(float)
    integer = _lift(int)
    fix = integer
    round = _lift(round)
    floor = _lift(math.floor)
    ceil = _lift(math.ceil)

    # Math
    abs = _lift(abs)
    sqrt = _lift(math.sqrt)
    exp = _lift(math.exp)
    log = _lift(math.log)
    log10 = _lift(math.log10)
    nxtwo = _lift(nxtwo)
    tento = _lift(tento)

    # Trig
    sin = _lift(math.sin)
    cos = _lift(math.cos)
    tan = _lift(math.tan)
    asin = _lift(math.asin)
    acos = _lift(math.acos)
    atan = _lift(math.atan)
    atan2 = _lift(math.atan2)
    deg = _lift(math.degrees)
    rad = _lift(math.radians)

    # Other
    hamdist = _lift(hamdist)
    max = _lift(max)
    min = _lift(min)

    def if_(self, a: CN, b: CN, c: CN) -> CN:
        args = [a, b, c]

        if any(callable(x) for x in args):

            def f(PV):
                vals = []
                for x in args:
                    if callable(x):
                        vals.append(x(PV))
                    else:
                        vals.append(x)
                a, b, c = vals
                return b if a > 0 else c

            return f
        if not callable(a):
            return b if a > 0 else c
        raise TypeError(f"if_: condition must be numeric or Callable, got {type(a).__name__}")


@lru_cache(maxsize=1)
def _get_calculator_parser():
    """Cache calculator parser instance."""
    return Lark.open(
        "calculator.lark",
        rel_to=__file__,
        parser="lalr",
        transformer=CalculatorTransformer(),
    )
