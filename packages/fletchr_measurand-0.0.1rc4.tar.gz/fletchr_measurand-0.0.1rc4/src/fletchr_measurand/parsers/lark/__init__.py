from __future__ import annotations

from typing import TYPE_CHECKING, Any, Generic, TypeVar, cast

from .calculator import _get_calculator_parser
from .measurand import _get_measurand_parser
from .parameter import _get_parameter_parser

if TYPE_CHECKING:
    from lark import Lark

T = TypeVar("T")


class TypedParser(Generic[T]):
    """Thin wrapper around a Lark parser that returns a typed result.

    Lark's `parse()` always declares `ParseTree` as its return type,
    even when an inline transformer produces a different type. This wrapper
    casts the result so callers get correct type information.
    """

    def __init__(self, lark: Lark) -> None:
        self._lark = lark

    def parse(self, text: str) -> T:
        return cast("T", self._lark.parse(text))


calculator_parser: TypedParser[Any] = TypedParser(_get_calculator_parser())
parameter_parser: TypedParser[Any] = TypedParser(_get_parameter_parser())
measurand_parser: TypedParser[Any] = TypedParser(_get_measurand_parser())

__all__ = ["calculator_parser", "measurand_parser", "parameter_parser"]
