grammar Parameter;

start_: parameter EOF;

parameter
    : '[' allFragments ']'                                      # BasicParam
    | '[' allFragments ']' bitOp                                # ParamWithBitop
    | '[' '(' allFragments ')' iterator ']' bitOp               # GenParamWithBitop
    | '[' allFragments iterator ']' bitOp                       # GenParamNpBitop
    | '[' '(' allFragments ')' iterator ']'                     # GenParam
    | '[' allFragments iterator ']'                             # GenParamNp
    | '[' allFragments ']' bitOp iterator                       # SupercomParamWithBitop
    | '[' allFragments ']' iterator                             # SupercomParam
    ;

iterator
    : PLUS_PLUS INT (LT INT)?                                   # UpIterator
    | MINUS_MINUS INT (LT INT)?                                 # DnIterator
    ;

bitOp: (AND | OR | XOR) constValue;

allFragments: crFragments (PLUS crFragments)*;

crFragments: TILDE? (fragments | constant) REVERSE?;

constant
    : HEX_LITERAL                                               # HexConst
    | OCT_LITERAL                                               # OctConst
    | BIN_LITERAL                                               # BinConst
    | QUOTE HEX_LITERAL QUOTE                                   # QuotedHexConst
    | QUOTE OCT_LITERAL QUOTE                                   # QuotedOctConst
    | QUOTE BIN_LITERAL QUOTE                                   # QuotedBinConst
    ;

fragments
    : INT                                                       # FragSingle
    | INT MINUS INT                                             # FragRange
    | INT MINUS INT COLON bitSpec                               # FragBitsLast3
    | INT COLON bitSpec (MINUS INT)?                            # FragBits
    ;

bitSpec: bitList | bitMask;

bitList: range_ (COMMA range_)*;

range_: INT (MINUS INT)?;

constValue: HEX_LITERAL | OCT_LITERAL | BIN_LITERAL;
bitMask: constValue;

// Keywords (must precede REVERSE to avoid conflicts)
AND: 'AND';
OR: 'OR';
XOR: 'XOR';

// Multi-character operators (must precede single-char)
PLUS_PLUS: '++';
MINUS_MINUS: '--';

// Single-character tokens
TILDE: '~';
QUOTE: '\'';
PLUS: '+';
MINUS: '-';
COLON: ':';
COMMA: ',';
LT: '<';
REVERSE: 'R';

// Literals (prefix + digits as one token)
HEX_LITERAL: 'x' [0-9a-fA-F]+;
OCT_LITERAL: 'o' [0-7]+;
BIN_LITERAL: 'b' [01]+;
INT: [0-9]+;

WS: [ \t\r\n]+ -> skip;
