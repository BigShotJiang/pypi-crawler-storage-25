# Generated from Parameter.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,22,166,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,1,0,1,0,
        1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,
        76,8,1,1,2,1,2,1,2,1,2,3,2,82,8,2,1,2,1,2,1,2,1,2,3,2,88,8,2,3,2,
        90,8,2,1,3,1,3,1,3,1,4,1,4,1,4,5,4,98,8,4,10,4,12,4,101,9,4,1,5,
        3,5,104,8,5,1,5,1,5,3,5,108,8,5,1,5,3,5,111,8,5,1,6,1,6,1,6,1,6,
        1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,3,6,125,8,6,1,7,1,7,1,7,1,7,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,141,8,7,3,7,143,8,7,1,8,
        1,8,3,8,147,8,8,1,9,1,9,1,9,5,9,152,8,9,10,9,12,9,155,9,9,1,10,1,
        10,1,10,3,10,160,8,10,1,11,1,11,1,12,1,12,1,12,0,0,13,0,2,4,6,8,
        10,12,14,16,18,20,22,24,0,2,1,0,5,7,1,0,18,20,178,0,26,1,0,0,0,2,
        75,1,0,0,0,4,89,1,0,0,0,6,91,1,0,0,0,8,94,1,0,0,0,10,103,1,0,0,0,
        12,124,1,0,0,0,14,142,1,0,0,0,16,146,1,0,0,0,18,148,1,0,0,0,20,156,
        1,0,0,0,22,161,1,0,0,0,24,163,1,0,0,0,26,27,3,2,1,0,27,28,5,0,0,
        1,28,1,1,0,0,0,29,30,5,1,0,0,30,31,3,8,4,0,31,32,5,2,0,0,32,76,1,
        0,0,0,33,34,5,1,0,0,34,35,3,8,4,0,35,36,5,2,0,0,36,37,3,6,3,0,37,
        76,1,0,0,0,38,39,5,1,0,0,39,40,5,3,0,0,40,41,3,8,4,0,41,42,5,4,0,
        0,42,43,3,4,2,0,43,44,5,2,0,0,44,45,3,6,3,0,45,76,1,0,0,0,46,47,
        5,1,0,0,47,48,3,8,4,0,48,49,3,4,2,0,49,50,5,2,0,0,50,51,3,6,3,0,
        51,76,1,0,0,0,52,53,5,1,0,0,53,54,5,3,0,0,54,55,3,8,4,0,55,56,5,
        4,0,0,56,57,3,4,2,0,57,58,5,2,0,0,58,76,1,0,0,0,59,60,5,1,0,0,60,
        61,3,8,4,0,61,62,3,4,2,0,62,63,5,2,0,0,63,76,1,0,0,0,64,65,5,1,0,
        0,65,66,3,8,4,0,66,67,5,2,0,0,67,68,3,6,3,0,68,69,3,4,2,0,69,76,
        1,0,0,0,70,71,5,1,0,0,71,72,3,8,4,0,72,73,5,2,0,0,73,74,3,4,2,0,
        74,76,1,0,0,0,75,29,1,0,0,0,75,33,1,0,0,0,75,38,1,0,0,0,75,46,1,
        0,0,0,75,52,1,0,0,0,75,59,1,0,0,0,75,64,1,0,0,0,75,70,1,0,0,0,76,
        3,1,0,0,0,77,78,5,8,0,0,78,81,5,21,0,0,79,80,5,16,0,0,80,82,5,21,
        0,0,81,79,1,0,0,0,81,82,1,0,0,0,82,90,1,0,0,0,83,84,5,9,0,0,84,87,
        5,21,0,0,85,86,5,16,0,0,86,88,5,21,0,0,87,85,1,0,0,0,87,88,1,0,0,
        0,88,90,1,0,0,0,89,77,1,0,0,0,89,83,1,0,0,0,90,5,1,0,0,0,91,92,7,
        0,0,0,92,93,3,22,11,0,93,7,1,0,0,0,94,99,3,10,5,0,95,96,5,12,0,0,
        96,98,3,10,5,0,97,95,1,0,0,0,98,101,1,0,0,0,99,97,1,0,0,0,99,100,
        1,0,0,0,100,9,1,0,0,0,101,99,1,0,0,0,102,104,5,10,0,0,103,102,1,
        0,0,0,103,104,1,0,0,0,104,107,1,0,0,0,105,108,3,14,7,0,106,108,3,
        12,6,0,107,105,1,0,0,0,107,106,1,0,0,0,108,110,1,0,0,0,109,111,5,
        17,0,0,110,109,1,0,0,0,110,111,1,0,0,0,111,11,1,0,0,0,112,125,5,
        18,0,0,113,125,5,19,0,0,114,125,5,20,0,0,115,116,5,11,0,0,116,117,
        5,18,0,0,117,125,5,11,0,0,118,119,5,11,0,0,119,120,5,19,0,0,120,
        125,5,11,0,0,121,122,5,11,0,0,122,123,5,20,0,0,123,125,5,11,0,0,
        124,112,1,0,0,0,124,113,1,0,0,0,124,114,1,0,0,0,124,115,1,0,0,0,
        124,118,1,0,0,0,124,121,1,0,0,0,125,13,1,0,0,0,126,143,5,21,0,0,
        127,128,5,21,0,0,128,129,5,13,0,0,129,143,5,21,0,0,130,131,5,21,
        0,0,131,132,5,13,0,0,132,133,5,21,0,0,133,134,5,14,0,0,134,143,3,
        16,8,0,135,136,5,21,0,0,136,137,5,14,0,0,137,140,3,16,8,0,138,139,
        5,13,0,0,139,141,5,21,0,0,140,138,1,0,0,0,140,141,1,0,0,0,141,143,
        1,0,0,0,142,126,1,0,0,0,142,127,1,0,0,0,142,130,1,0,0,0,142,135,
        1,0,0,0,143,15,1,0,0,0,144,147,3,18,9,0,145,147,3,24,12,0,146,144,
        1,0,0,0,146,145,1,0,0,0,147,17,1,0,0,0,148,153,3,20,10,0,149,150,
        5,15,0,0,150,152,3,20,10,0,151,149,1,0,0,0,152,155,1,0,0,0,153,151,
        1,0,0,0,153,154,1,0,0,0,154,19,1,0,0,0,155,153,1,0,0,0,156,159,5,
        21,0,0,157,158,5,13,0,0,158,160,5,21,0,0,159,157,1,0,0,0,159,160,
        1,0,0,0,160,21,1,0,0,0,161,162,7,1,0,0,162,23,1,0,0,0,163,164,3,
        22,11,0,164,25,1,0,0,0,14,75,81,87,89,99,103,107,110,124,140,142,
        146,153,159
    ]

class ParameterParser ( Parser ):

    grammarFileName = "Parameter.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'['", "']'", "'('", "')'", "'AND'", "'OR'",
                     "'XOR'", "'++'", "'--'", "'~'", "'''", "'+'", "'-'",
                     "':'", "','", "'<'", "'R'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "AND", "OR", "XOR", "PLUS_PLUS", "MINUS_MINUS",
                      "TILDE", "QUOTE", "PLUS", "MINUS", "COLON", "COMMA",
                      "LT", "REVERSE", "HEX_LITERAL", "OCT_LITERAL", "BIN_LITERAL",
                      "INT", "WS" ]

    RULE_start_ = 0
    RULE_parameter = 1
    RULE_iterator = 2
    RULE_bitOp = 3
    RULE_allFragments = 4
    RULE_crFragments = 5
    RULE_constant = 6
    RULE_fragments = 7
    RULE_bitSpec = 8
    RULE_bitList = 9
    RULE_range_ = 10
    RULE_constValue = 11
    RULE_bitMask = 12

    ruleNames =  [ "start_", "parameter", "iterator", "bitOp", "allFragments",
                   "crFragments", "constant", "fragments", "bitSpec", "bitList",
                   "range_", "constValue", "bitMask" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    AND=5
    OR=6
    XOR=7
    PLUS_PLUS=8
    MINUS_MINUS=9
    TILDE=10
    QUOTE=11
    PLUS=12
    MINUS=13
    COLON=14
    COMMA=15
    LT=16
    REVERSE=17
    HEX_LITERAL=18
    OCT_LITERAL=19
    BIN_LITERAL=20
    INT=21
    WS=22

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Start_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameter(self):
            return self.getTypedRuleContext(ParameterParser.ParameterContext,0)


        def EOF(self):
            return self.getToken(ParameterParser.EOF, 0)

        def getRuleIndex(self):
            return ParameterParser.RULE_start_

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart_" ):
                listener.enterStart_(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart_" ):
                listener.exitStart_(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart_" ):
                return visitor.visitStart_(self)
            else:
                return visitor.visitChildren(self)




    def start_(self):

        localctx = ParameterParser.Start_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start_)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 26
            self.parameter()
            self.state = 27
            self.match(ParameterParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ParameterParser.RULE_parameter


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class GenParamNpBitopContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def iterator(self):
            return self.getTypedRuleContext(ParameterParser.IteratorContext,0)

        def bitOp(self):
            return self.getTypedRuleContext(ParameterParser.BitOpContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGenParamNpBitop" ):
                listener.enterGenParamNpBitop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGenParamNpBitop" ):
                listener.exitGenParamNpBitop(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGenParamNpBitop" ):
                return visitor.visitGenParamNpBitop(self)
            else:
                return visitor.visitChildren(self)


    class GenParamWithBitopContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def iterator(self):
            return self.getTypedRuleContext(ParameterParser.IteratorContext,0)

        def bitOp(self):
            return self.getTypedRuleContext(ParameterParser.BitOpContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGenParamWithBitop" ):
                listener.enterGenParamWithBitop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGenParamWithBitop" ):
                listener.exitGenParamWithBitop(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGenParamWithBitop" ):
                return visitor.visitGenParamWithBitop(self)
            else:
                return visitor.visitChildren(self)


    class ParamWithBitopContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def bitOp(self):
            return self.getTypedRuleContext(ParameterParser.BitOpContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParamWithBitop" ):
                listener.enterParamWithBitop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParamWithBitop" ):
                listener.exitParamWithBitop(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamWithBitop" ):
                return visitor.visitParamWithBitop(self)
            else:
                return visitor.visitChildren(self)


    class GenParamNpContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def iterator(self):
            return self.getTypedRuleContext(ParameterParser.IteratorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGenParamNp" ):
                listener.enterGenParamNp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGenParamNp" ):
                listener.exitGenParamNp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGenParamNp" ):
                return visitor.visitGenParamNp(self)
            else:
                return visitor.visitChildren(self)


    class SupercomParamWithBitopContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def bitOp(self):
            return self.getTypedRuleContext(ParameterParser.BitOpContext,0)

        def iterator(self):
            return self.getTypedRuleContext(ParameterParser.IteratorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSupercomParamWithBitop" ):
                listener.enterSupercomParamWithBitop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSupercomParamWithBitop" ):
                listener.exitSupercomParamWithBitop(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSupercomParamWithBitop" ):
                return visitor.visitSupercomParamWithBitop(self)
            else:
                return visitor.visitChildren(self)


    class BasicParamContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBasicParam" ):
                listener.enterBasicParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBasicParam" ):
                listener.exitBasicParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBasicParam" ):
                return visitor.visitBasicParam(self)
            else:
                return visitor.visitChildren(self)


    class SupercomParamContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def iterator(self):
            return self.getTypedRuleContext(ParameterParser.IteratorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSupercomParam" ):
                listener.enterSupercomParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSupercomParam" ):
                listener.exitSupercomParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSupercomParam" ):
                return visitor.visitSupercomParam(self)
            else:
                return visitor.visitChildren(self)


    class GenParamContext(ParameterContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ParameterContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def allFragments(self):
            return self.getTypedRuleContext(ParameterParser.AllFragmentsContext,0)

        def iterator(self):
            return self.getTypedRuleContext(ParameterParser.IteratorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGenParam" ):
                listener.enterGenParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGenParam" ):
                listener.exitGenParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGenParam" ):
                return visitor.visitGenParam(self)
            else:
                return visitor.visitChildren(self)



    def parameter(self):

        localctx = ParameterParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_parameter)
        try:
            self.state = 75
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                localctx = ParameterParser.BasicParamContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 29
                self.match(ParameterParser.T__0)
                self.state = 30
                self.allFragments()
                self.state = 31
                self.match(ParameterParser.T__1)
                pass

            elif la_ == 2:
                localctx = ParameterParser.ParamWithBitopContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 33
                self.match(ParameterParser.T__0)
                self.state = 34
                self.allFragments()
                self.state = 35
                self.match(ParameterParser.T__1)
                self.state = 36
                self.bitOp()
                pass

            elif la_ == 3:
                localctx = ParameterParser.GenParamWithBitopContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 38
                self.match(ParameterParser.T__0)
                self.state = 39
                self.match(ParameterParser.T__2)
                self.state = 40
                self.allFragments()
                self.state = 41
                self.match(ParameterParser.T__3)
                self.state = 42
                self.iterator()
                self.state = 43
                self.match(ParameterParser.T__1)
                self.state = 44
                self.bitOp()
                pass

            elif la_ == 4:
                localctx = ParameterParser.GenParamNpBitopContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 46
                self.match(ParameterParser.T__0)
                self.state = 47
                self.allFragments()
                self.state = 48
                self.iterator()
                self.state = 49
                self.match(ParameterParser.T__1)
                self.state = 50
                self.bitOp()
                pass

            elif la_ == 5:
                localctx = ParameterParser.GenParamContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 52
                self.match(ParameterParser.T__0)
                self.state = 53
                self.match(ParameterParser.T__2)
                self.state = 54
                self.allFragments()
                self.state = 55
                self.match(ParameterParser.T__3)
                self.state = 56
                self.iterator()
                self.state = 57
                self.match(ParameterParser.T__1)
                pass

            elif la_ == 6:
                localctx = ParameterParser.GenParamNpContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 59
                self.match(ParameterParser.T__0)
                self.state = 60
                self.allFragments()
                self.state = 61
                self.iterator()
                self.state = 62
                self.match(ParameterParser.T__1)
                pass

            elif la_ == 7:
                localctx = ParameterParser.SupercomParamWithBitopContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 64
                self.match(ParameterParser.T__0)
                self.state = 65
                self.allFragments()
                self.state = 66
                self.match(ParameterParser.T__1)
                self.state = 67
                self.bitOp()
                self.state = 68
                self.iterator()
                pass

            elif la_ == 8:
                localctx = ParameterParser.SupercomParamContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 70
                self.match(ParameterParser.T__0)
                self.state = 71
                self.allFragments()
                self.state = 72
                self.match(ParameterParser.T__1)
                self.state = 73
                self.iterator()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IteratorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ParameterParser.RULE_iterator


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class UpIteratorContext(IteratorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.IteratorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def PLUS_PLUS(self):
            return self.getToken(ParameterParser.PLUS_PLUS, 0)
        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.INT)
            else:
                return self.getToken(ParameterParser.INT, i)
        def LT(self):
            return self.getToken(ParameterParser.LT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpIterator" ):
                listener.enterUpIterator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpIterator" ):
                listener.exitUpIterator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUpIterator" ):
                return visitor.visitUpIterator(self)
            else:
                return visitor.visitChildren(self)


    class DnIteratorContext(IteratorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.IteratorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def MINUS_MINUS(self):
            return self.getToken(ParameterParser.MINUS_MINUS, 0)
        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.INT)
            else:
                return self.getToken(ParameterParser.INT, i)
        def LT(self):
            return self.getToken(ParameterParser.LT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDnIterator" ):
                listener.enterDnIterator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDnIterator" ):
                listener.exitDnIterator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDnIterator" ):
                return visitor.visitDnIterator(self)
            else:
                return visitor.visitChildren(self)



    def iterator(self):

        localctx = ParameterParser.IteratorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_iterator)
        self._la = 0 # Token type
        try:
            self.state = 89
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [8]:
                localctx = ParameterParser.UpIteratorContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 77
                self.match(ParameterParser.PLUS_PLUS)
                self.state = 78
                self.match(ParameterParser.INT)
                self.state = 81
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==16:
                    self.state = 79
                    self.match(ParameterParser.LT)
                    self.state = 80
                    self.match(ParameterParser.INT)


                pass
            elif token in [9]:
                localctx = ParameterParser.DnIteratorContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 83
                self.match(ParameterParser.MINUS_MINUS)
                self.state = 84
                self.match(ParameterParser.INT)
                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==16:
                    self.state = 85
                    self.match(ParameterParser.LT)
                    self.state = 86
                    self.match(ParameterParser.INT)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constValue(self):
            return self.getTypedRuleContext(ParameterParser.ConstValueContext,0)


        def AND(self):
            return self.getToken(ParameterParser.AND, 0)

        def OR(self):
            return self.getToken(ParameterParser.OR, 0)

        def XOR(self):
            return self.getToken(ParameterParser.XOR, 0)

        def getRuleIndex(self):
            return ParameterParser.RULE_bitOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitOp" ):
                listener.enterBitOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitOp" ):
                listener.exitBitOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitOp" ):
                return visitor.visitBitOp(self)
            else:
                return visitor.visitChildren(self)




    def bitOp(self):

        localctx = ParameterParser.BitOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_bitOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 91
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 224) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 92
            self.constValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AllFragmentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def crFragments(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ParameterParser.CrFragmentsContext)
            else:
                return self.getTypedRuleContext(ParameterParser.CrFragmentsContext,i)


        def PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.PLUS)
            else:
                return self.getToken(ParameterParser.PLUS, i)

        def getRuleIndex(self):
            return ParameterParser.RULE_allFragments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAllFragments" ):
                listener.enterAllFragments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAllFragments" ):
                listener.exitAllFragments(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAllFragments" ):
                return visitor.visitAllFragments(self)
            else:
                return visitor.visitChildren(self)




    def allFragments(self):

        localctx = ParameterParser.AllFragmentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_allFragments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 94
            self.crFragments()
            self.state = 99
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==12:
                self.state = 95
                self.match(ParameterParser.PLUS)
                self.state = 96
                self.crFragments()
                self.state = 101
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CrFragmentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fragments(self):
            return self.getTypedRuleContext(ParameterParser.FragmentsContext,0)


        def constant(self):
            return self.getTypedRuleContext(ParameterParser.ConstantContext,0)


        def TILDE(self):
            return self.getToken(ParameterParser.TILDE, 0)

        def REVERSE(self):
            return self.getToken(ParameterParser.REVERSE, 0)

        def getRuleIndex(self):
            return ParameterParser.RULE_crFragments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCrFragments" ):
                listener.enterCrFragments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCrFragments" ):
                listener.exitCrFragments(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCrFragments" ):
                return visitor.visitCrFragments(self)
            else:
                return visitor.visitChildren(self)




    def crFragments(self):

        localctx = ParameterParser.CrFragmentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_crFragments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 102
                self.match(ParameterParser.TILDE)


            self.state = 107
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21]:
                self.state = 105
                self.fragments()
                pass
            elif token in [11, 18, 19, 20]:
                self.state = 106
                self.constant()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 110
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 109
                self.match(ParameterParser.REVERSE)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ParameterParser.RULE_constant


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class QuotedBinConstContext(ConstantContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ConstantContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.QUOTE)
            else:
                return self.getToken(ParameterParser.QUOTE, i)
        def BIN_LITERAL(self):
            return self.getToken(ParameterParser.BIN_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuotedBinConst" ):
                listener.enterQuotedBinConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuotedBinConst" ):
                listener.exitQuotedBinConst(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuotedBinConst" ):
                return visitor.visitQuotedBinConst(self)
            else:
                return visitor.visitChildren(self)


    class BinConstContext(ConstantContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ConstantContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BIN_LITERAL(self):
            return self.getToken(ParameterParser.BIN_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBinConst" ):
                listener.enterBinConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBinConst" ):
                listener.exitBinConst(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinConst" ):
                return visitor.visitBinConst(self)
            else:
                return visitor.visitChildren(self)


    class HexConstContext(ConstantContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ConstantContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def HEX_LITERAL(self):
            return self.getToken(ParameterParser.HEX_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHexConst" ):
                listener.enterHexConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHexConst" ):
                listener.exitHexConst(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitHexConst" ):
                return visitor.visitHexConst(self)
            else:
                return visitor.visitChildren(self)


    class QuotedOctConstContext(ConstantContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ConstantContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.QUOTE)
            else:
                return self.getToken(ParameterParser.QUOTE, i)
        def OCT_LITERAL(self):
            return self.getToken(ParameterParser.OCT_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuotedOctConst" ):
                listener.enterQuotedOctConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuotedOctConst" ):
                listener.exitQuotedOctConst(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuotedOctConst" ):
                return visitor.visitQuotedOctConst(self)
            else:
                return visitor.visitChildren(self)


    class OctConstContext(ConstantContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ConstantContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OCT_LITERAL(self):
            return self.getToken(ParameterParser.OCT_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOctConst" ):
                listener.enterOctConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOctConst" ):
                listener.exitOctConst(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOctConst" ):
                return visitor.visitOctConst(self)
            else:
                return visitor.visitChildren(self)


    class QuotedHexConstContext(ConstantContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.ConstantContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.QUOTE)
            else:
                return self.getToken(ParameterParser.QUOTE, i)
        def HEX_LITERAL(self):
            return self.getToken(ParameterParser.HEX_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuotedHexConst" ):
                listener.enterQuotedHexConst(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuotedHexConst" ):
                listener.exitQuotedHexConst(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuotedHexConst" ):
                return visitor.visitQuotedHexConst(self)
            else:
                return visitor.visitChildren(self)



    def constant(self):

        localctx = ParameterParser.ConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_constant)
        try:
            self.state = 124
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                localctx = ParameterParser.HexConstContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 112
                self.match(ParameterParser.HEX_LITERAL)
                pass

            elif la_ == 2:
                localctx = ParameterParser.OctConstContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 113
                self.match(ParameterParser.OCT_LITERAL)
                pass

            elif la_ == 3:
                localctx = ParameterParser.BinConstContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 114
                self.match(ParameterParser.BIN_LITERAL)
                pass

            elif la_ == 4:
                localctx = ParameterParser.QuotedHexConstContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 115
                self.match(ParameterParser.QUOTE)
                self.state = 116
                self.match(ParameterParser.HEX_LITERAL)
                self.state = 117
                self.match(ParameterParser.QUOTE)
                pass

            elif la_ == 5:
                localctx = ParameterParser.QuotedOctConstContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 118
                self.match(ParameterParser.QUOTE)
                self.state = 119
                self.match(ParameterParser.OCT_LITERAL)
                self.state = 120
                self.match(ParameterParser.QUOTE)
                pass

            elif la_ == 6:
                localctx = ParameterParser.QuotedBinConstContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 121
                self.match(ParameterParser.QUOTE)
                self.state = 122
                self.match(ParameterParser.BIN_LITERAL)
                self.state = 123
                self.match(ParameterParser.QUOTE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FragmentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ParameterParser.RULE_fragments


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class FragBitsContext(FragmentsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.FragmentsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.INT)
            else:
                return self.getToken(ParameterParser.INT, i)
        def COLON(self):
            return self.getToken(ParameterParser.COLON, 0)
        def bitSpec(self):
            return self.getTypedRuleContext(ParameterParser.BitSpecContext,0)

        def MINUS(self):
            return self.getToken(ParameterParser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFragBits" ):
                listener.enterFragBits(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFragBits" ):
                listener.exitFragBits(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFragBits" ):
                return visitor.visitFragBits(self)
            else:
                return visitor.visitChildren(self)


    class FragSingleContext(FragmentsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.FragmentsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(ParameterParser.INT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFragSingle" ):
                listener.enterFragSingle(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFragSingle" ):
                listener.exitFragSingle(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFragSingle" ):
                return visitor.visitFragSingle(self)
            else:
                return visitor.visitChildren(self)


    class FragBitsLast3Context(FragmentsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.FragmentsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.INT)
            else:
                return self.getToken(ParameterParser.INT, i)
        def MINUS(self):
            return self.getToken(ParameterParser.MINUS, 0)
        def COLON(self):
            return self.getToken(ParameterParser.COLON, 0)
        def bitSpec(self):
            return self.getTypedRuleContext(ParameterParser.BitSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFragBitsLast3" ):
                listener.enterFragBitsLast3(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFragBitsLast3" ):
                listener.exitFragBitsLast3(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFragBitsLast3" ):
                return visitor.visitFragBitsLast3(self)
            else:
                return visitor.visitChildren(self)


    class FragRangeContext(FragmentsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ParameterParser.FragmentsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.INT)
            else:
                return self.getToken(ParameterParser.INT, i)
        def MINUS(self):
            return self.getToken(ParameterParser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFragRange" ):
                listener.enterFragRange(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFragRange" ):
                listener.exitFragRange(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFragRange" ):
                return visitor.visitFragRange(self)
            else:
                return visitor.visitChildren(self)



    def fragments(self):

        localctx = ParameterParser.FragmentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_fragments)
        self._la = 0 # Token type
        try:
            self.state = 142
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                localctx = ParameterParser.FragSingleContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 126
                self.match(ParameterParser.INT)
                pass

            elif la_ == 2:
                localctx = ParameterParser.FragRangeContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 127
                self.match(ParameterParser.INT)
                self.state = 128
                self.match(ParameterParser.MINUS)
                self.state = 129
                self.match(ParameterParser.INT)
                pass

            elif la_ == 3:
                localctx = ParameterParser.FragBitsLast3Context(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 130
                self.match(ParameterParser.INT)
                self.state = 131
                self.match(ParameterParser.MINUS)
                self.state = 132
                self.match(ParameterParser.INT)
                self.state = 133
                self.match(ParameterParser.COLON)
                self.state = 134
                self.bitSpec()
                pass

            elif la_ == 4:
                localctx = ParameterParser.FragBitsContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 135
                self.match(ParameterParser.INT)
                self.state = 136
                self.match(ParameterParser.COLON)
                self.state = 137
                self.bitSpec()
                self.state = 140
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==13:
                    self.state = 138
                    self.match(ParameterParser.MINUS)
                    self.state = 139
                    self.match(ParameterParser.INT)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bitList(self):
            return self.getTypedRuleContext(ParameterParser.BitListContext,0)


        def bitMask(self):
            return self.getTypedRuleContext(ParameterParser.BitMaskContext,0)


        def getRuleIndex(self):
            return ParameterParser.RULE_bitSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitSpec" ):
                listener.enterBitSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitSpec" ):
                listener.exitBitSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitSpec" ):
                return visitor.visitBitSpec(self)
            else:
                return visitor.visitChildren(self)




    def bitSpec(self):

        localctx = ParameterParser.BitSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_bitSpec)
        try:
            self.state = 146
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21]:
                self.enterOuterAlt(localctx, 1)
                self.state = 144
                self.bitList()
                pass
            elif token in [18, 19, 20]:
                self.enterOuterAlt(localctx, 2)
                self.state = 145
                self.bitMask()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def range_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ParameterParser.Range_Context)
            else:
                return self.getTypedRuleContext(ParameterParser.Range_Context,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.COMMA)
            else:
                return self.getToken(ParameterParser.COMMA, i)

        def getRuleIndex(self):
            return ParameterParser.RULE_bitList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitList" ):
                listener.enterBitList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitList" ):
                listener.exitBitList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitList" ):
                return visitor.visitBitList(self)
            else:
                return visitor.visitChildren(self)




    def bitList(self):

        localctx = ParameterParser.BitListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_bitList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.range_()
            self.state = 153
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==15:
                self.state = 149
                self.match(ParameterParser.COMMA)
                self.state = 150
                self.range_()
                self.state = 155
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Range_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(ParameterParser.INT)
            else:
                return self.getToken(ParameterParser.INT, i)

        def MINUS(self):
            return self.getToken(ParameterParser.MINUS, 0)

        def getRuleIndex(self):
            return ParameterParser.RULE_range_

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRange_" ):
                listener.enterRange_(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRange_" ):
                listener.exitRange_(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRange_" ):
                return visitor.visitRange_(self)
            else:
                return visitor.visitChildren(self)




    def range_(self):

        localctx = ParameterParser.Range_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_range_)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self.match(ParameterParser.INT)
            self.state = 159
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.state = 157
                self.match(ParameterParser.MINUS)
                self.state = 158
                self.match(ParameterParser.INT)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HEX_LITERAL(self):
            return self.getToken(ParameterParser.HEX_LITERAL, 0)

        def OCT_LITERAL(self):
            return self.getToken(ParameterParser.OCT_LITERAL, 0)

        def BIN_LITERAL(self):
            return self.getToken(ParameterParser.BIN_LITERAL, 0)

        def getRuleIndex(self):
            return ParameterParser.RULE_constValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstValue" ):
                listener.enterConstValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstValue" ):
                listener.exitConstValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstValue" ):
                return visitor.visitConstValue(self)
            else:
                return visitor.visitChildren(self)




    def constValue(self):

        localctx = ParameterParser.ConstValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_constValue)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1835008) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitMaskContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constValue(self):
            return self.getTypedRuleContext(ParameterParser.ConstValueContext,0)


        def getRuleIndex(self):
            return ParameterParser.RULE_bitMask

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitMask" ):
                listener.enterBitMask(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitMask" ):
                listener.exitBitMask(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitMask" ):
                return visitor.visitBitMask(self)
            else:
                return visitor.visitChildren(self)




    def bitMask(self):

        localctx = ParameterParser.BitMaskContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_bitMask)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self.constValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx
