# Generated from Parameter.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .ParameterParser import ParameterParser
else:
    from ParameterParser import ParameterParser

# This class defines a complete generic visitor for a parse tree produced by ParameterParser.

class ParameterVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ParameterParser#start_.
    def visitStart_(self, ctx:ParameterParser.Start_Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#BasicParam.
    def visitBasicParam(self, ctx:ParameterParser.BasicParamContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#ParamWithBitop.
    def visitParamWithBitop(self, ctx:ParameterParser.ParamWithBitopContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#GenParamWithBitop.
    def visitGenParamWithBitop(self, ctx:ParameterParser.GenParamWithBitopContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#GenParamNpBitop.
    def visitGenParamNpBitop(self, ctx:ParameterParser.GenParamNpBitopContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#GenParam.
    def visitGenParam(self, ctx:ParameterParser.GenParamContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#GenParamNp.
    def visitGenParamNp(self, ctx:ParameterParser.GenParamNpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#SupercomParamWithBitop.
    def visitSupercomParamWithBitop(self, ctx:ParameterParser.SupercomParamWithBitopContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#SupercomParam.
    def visitSupercomParam(self, ctx:ParameterParser.SupercomParamContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#UpIterator.
    def visitUpIterator(self, ctx:ParameterParser.UpIteratorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#DnIterator.
    def visitDnIterator(self, ctx:ParameterParser.DnIteratorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#bitOp.
    def visitBitOp(self, ctx:ParameterParser.BitOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#allFragments.
    def visitAllFragments(self, ctx:ParameterParser.AllFragmentsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#crFragments.
    def visitCrFragments(self, ctx:ParameterParser.CrFragmentsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#HexConst.
    def visitHexConst(self, ctx:ParameterParser.HexConstContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#OctConst.
    def visitOctConst(self, ctx:ParameterParser.OctConstContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#BinConst.
    def visitBinConst(self, ctx:ParameterParser.BinConstContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#QuotedHexConst.
    def visitQuotedHexConst(self, ctx:ParameterParser.QuotedHexConstContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#QuotedOctConst.
    def visitQuotedOctConst(self, ctx:ParameterParser.QuotedOctConstContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#QuotedBinConst.
    def visitQuotedBinConst(self, ctx:ParameterParser.QuotedBinConstContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#FragSingle.
    def visitFragSingle(self, ctx:ParameterParser.FragSingleContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#FragRange.
    def visitFragRange(self, ctx:ParameterParser.FragRangeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#FragBitsLast3.
    def visitFragBitsLast3(self, ctx:ParameterParser.FragBitsLast3Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#FragBits.
    def visitFragBits(self, ctx:ParameterParser.FragBitsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#bitSpec.
    def visitBitSpec(self, ctx:ParameterParser.BitSpecContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#bitList.
    def visitBitList(self, ctx:ParameterParser.BitListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#range_.
    def visitRange_(self, ctx:ParameterParser.Range_Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#constValue.
    def visitConstValue(self, ctx:ParameterParser.ConstValueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ParameterParser#bitMask.
    def visitBitMask(self, ctx:ParameterParser.BitMaskContext):
        return self.visitChildren(ctx)



del ParameterParser
