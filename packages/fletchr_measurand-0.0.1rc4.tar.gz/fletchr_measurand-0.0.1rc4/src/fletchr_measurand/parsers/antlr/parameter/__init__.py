# pyright: reportIncompatibleMethodOverride=false
#
# ANTLR's Python generator emits every visit method as `-> None`, so any
# override that returns a useful value trips reportIncompatibleMethodOverride.
# The mismatch is a generator-output limitation, not a real typing error.
"""ANTLR-based parameter parser.

Drop-in replacement for the Lark-based parameter parser. Provides the same
interface: `parameter_parser.parse(expr)` returns a Parameter object.
"""

from __future__ import annotations

from typing import Any, TypeVar, cast

from antlr4 import CommonTokenStream, InputStream

from fletchr_measurand import _bitops
from fletchr_measurand.parameter import (
    BasicParameter,
    BitOperator,
    BitOpMode,
    Fragment,
    FragmentConstant,
    FragmentWord,
    GeneratorParameter,
    Iterator,
    Parameter,
    SupercomParameter,
)

from .ParameterLexer import ParameterLexer
from .ParameterParser import ParameterParser
from .ParameterVisitor import ParameterVisitor

_T = TypeVar("_T")


def _req(x: _T | None) -> _T:
    """Narrow an Optional ANTLR child access to non-None.

    The grammar guarantees these children are present for the matched
    alternative; a `None` here indicates a parser/visitor mismatch.
    """
    assert x is not None, "antlr: required context child was None"
    return x


def _text(node: Any) -> str:
    """Extract text from an ANTLR TerminalNode (typestubs are incomplete)."""
    assert node is not None, "antlr: TerminalNode was None"
    return node.getText()


class _ParamVisitor(ParameterVisitor):
    # The base class declares every visit method as returning None;
    # overriding `visit` to return Any lets the typed overrides below
    # assign the result to concrete types without repeated casts.
    def visit(self, tree: Any) -> Any:  # type: ignore[override]
        return super().visit(tree)

    def visitStart_(self, ctx: Any) -> Parameter:
        return self.visit(_req(ctx.parameter()))

    # --- parameter alternatives ---

    def visitBasicParam(self, ctx: Any) -> BasicParameter:
        fragments: list[Fragment] = self.visit(_req(ctx.allFragments()))
        return BasicParameter(fragments=fragments)

    def visitParamWithBitop(self, ctx: Any) -> BasicParameter:
        fragments: list[Fragment] = self.visit(_req(ctx.allFragments()))
        bit_op: BitOperator = self.visit(_req(ctx.bitOp()))
        return BasicParameter(fragments=fragments, bit_op=bit_op)

    def visitGenParamWithBitop(self, ctx: Any) -> GeneratorParameter:
        fragments: list[Fragment] = self.visit(_req(ctx.allFragments()))
        iterator: Iterator = self.visit(_req(ctx.iterator()))
        bit_op: BitOperator = self.visit(_req(ctx.bitOp()))
        parameter = BasicParameter(fragments=fragments, bit_op=bit_op)
        return GeneratorParameter(parameter=parameter, iterator=iterator)

    def visitGenParamNpBitop(self, ctx: Any) -> GeneratorParameter:
        return self.visitGenParamWithBitop(ctx)

    def visitGenParam(self, ctx: Any) -> GeneratorParameter:
        fragments: list[Fragment] = self.visit(_req(ctx.allFragments()))
        iterator: Iterator = self.visit(_req(ctx.iterator()))
        parameter = BasicParameter(fragments=fragments)
        return GeneratorParameter(parameter=parameter, iterator=iterator)

    def visitGenParamNp(self, ctx: Any) -> GeneratorParameter:
        return self.visitGenParam(ctx)

    def visitSupercomParamWithBitop(self, ctx: Any) -> SupercomParameter:
        fragments: list[Fragment] = self.visit(_req(ctx.allFragments()))
        bit_op: BitOperator = self.visit(_req(ctx.bitOp()))
        iterator: Iterator = self.visit(_req(ctx.iterator()))
        parameter = BasicParameter(fragments=fragments, bit_op=bit_op)
        return SupercomParameter(parameter, iterator=iterator)

    def visitSupercomParam(self, ctx: Any) -> SupercomParameter:
        fragments: list[Fragment] = self.visit(_req(ctx.allFragments()))
        iterator: Iterator = self.visit(_req(ctx.iterator()))
        parameter = BasicParameter(fragments=fragments)
        return SupercomParameter(parameter, iterator=iterator)

    # --- iterator ---

    def visitUpIterator(self, ctx: Any) -> Iterator:
        ints = _req(ctx.INT())
        step = int(_text(ints[0]))
        if len(ints) == 2:
            return Iterator(step, int(_text(ints[1])))
        return Iterator(step)

    def visitDnIterator(self, ctx: Any) -> Iterator:
        ints = _req(ctx.INT())
        step = -int(_text(ints[0]))
        if len(ints) == 2:
            return Iterator(step, int(_text(ints[1])))
        return Iterator(step)

    # --- bitOp ---

    def visitBitOp(self, ctx: Any) -> BitOperator:
        if ctx.AND():
            mode = "AND"
        elif ctx.OR():
            mode = "OR"
        else:
            mode = "XOR"
        value: int = self.visit(_req(ctx.constValue()))
        return BitOperator(mode=cast("BitOpMode", mode), value=value)

    # --- allFragments / crFragments ---

    def visitAllFragments(self, ctx: Any) -> list[Fragment]:
        result: list[Fragment] = []
        for cr in _req(ctx.crFragments()):
            result.extend(self.visit(cr))
        return result

    def visitCrFragments(self, ctx: Any) -> list[Fragment]:
        complement = ctx.TILDE() is not None
        reverse = ctx.REVERSE() is not None

        if ctx.fragments():
            frags: list[Fragment] = self.visit(_req(ctx.fragments()))
        else:
            frags = self.visit(_req(ctx.constant()))

        for frag in frags:
            frag.complement = complement
            frag.reverse = reverse

        return frags

    # --- constant ---

    def _const_from_hex(self, token: Any) -> list[FragmentConstant]:
        digits = _text(token)[1:]  # strip 'x' prefix
        size = 4 * len(digits)
        value = _bitops.hex2dec(digits)
        return [FragmentConstant(value, size)]

    def _const_from_oct(self, token: Any) -> list[FragmentConstant]:
        digits = _text(token)[1:]  # strip 'o' prefix
        size = 3 * len(digits)
        value = _bitops.oct2dec(digits)
        return [FragmentConstant(value, size)]

    def _const_from_bin(self, token: Any) -> list[FragmentConstant]:
        digits = _text(token)[1:]  # strip 'b' prefix
        size = len(digits)
        value = _bitops.bin2dec(digits)
        return [FragmentConstant(value, size)]

    def visitHexConst(self, ctx: Any) -> list[FragmentConstant]:
        return self._const_from_hex(ctx.HEX_LITERAL())

    def visitOctConst(self, ctx: Any) -> list[FragmentConstant]:
        return self._const_from_oct(ctx.OCT_LITERAL())

    def visitBinConst(self, ctx: Any) -> list[FragmentConstant]:
        return self._const_from_bin(ctx.BIN_LITERAL())

    def visitQuotedHexConst(self, ctx: Any) -> list[FragmentConstant]:
        return self._const_from_hex(ctx.HEX_LITERAL())

    def visitQuotedOctConst(self, ctx: Any) -> list[FragmentConstant]:
        return self._const_from_oct(ctx.OCT_LITERAL())

    def visitQuotedBinConst(self, ctx: Any) -> list[FragmentConstant]:
        return self._const_from_bin(ctx.BIN_LITERAL())

    # --- fragments ---

    def visitFragSingle(self, ctx: Any) -> list[FragmentWord]:
        word = int(_text(ctx.INT()))
        return [FragmentWord(word=word)]

    def visitFragRange(self, ctx: Any) -> list[FragmentWord]:
        ints = _req(ctx.INT())
        start = int(_text(ints[0]))
        stop = int(_text(ints[1]))
        return [FragmentWord(word=w) for w in _bitops.irange(start, stop)]

    def visitFragBitsLast3(self, ctx: Any) -> list[FragmentWord]:
        ints = _req(ctx.INT())
        start = int(_text(ints[0]))
        stop = int(_text(ints[1]))
        bits: list[int] = self.visit(_req(ctx.bitSpec()))
        return [FragmentWord(word=w, bits=bits) for w in _bitops.irange(start, stop)]

    def visitFragBits(self, ctx: Any) -> list[FragmentWord]:
        ints = _req(ctx.INT())
        start = int(_text(ints[0]))
        bits: list[int] = self.visit(_req(ctx.bitSpec()))
        if ctx.MINUS():
            # fragments_bits_first: INT COLON bitSpec MINUS INT
            stop = int(_text(ints[1]))
            return [FragmentWord(word=w, bits=bits) for w in _bitops.irange(start, stop)]
        # fragments_bits_last: INT COLON bitSpec
        return [FragmentWord(word=start, bits=bits)]

    # --- bitSpec ---

    def visitBitSpec(self, ctx: Any) -> list[int]:
        if ctx.bitList():
            return self.visit(_req(ctx.bitList()))
        return self.visit(_req(ctx.bitMask()))

    def visitBitList(self, ctx: Any) -> list[int]:
        result: list[int] = []
        for r in _req(ctx.range_()):
            result.extend(self.visit(r))
        return result

    def visitRange_(self, ctx: Any) -> list[int]:
        ints = _req(ctx.INT())
        start = int(_text(ints[0]))
        if len(ints) == 2:
            stop = int(_text(ints[1]))
            return _bitops.irange(start, stop)
        return [start]

    def visitBitMask(self, ctx: Any) -> list[int]:
        return _bitops.bit_mask(self.visit(_req(ctx.constValue())))

    def visitConstValue(self, ctx: Any) -> int:
        if ctx.HEX_LITERAL():
            return _bitops.hex2dec(_text(ctx.HEX_LITERAL())[1:])
        if ctx.OCT_LITERAL():
            return _bitops.oct2dec(_text(ctx.OCT_LITERAL())[1:])
        return _bitops.bin2dec(_text(ctx.BIN_LITERAL())[1:])


_param_visitor = _ParamVisitor()


class _ParameterParser:
    """Wrapper providing `.parse(expr)` for parameter expressions."""

    def parse(self, expr: str) -> Parameter:
        lexer = ParameterLexer(InputStream(expr))
        stream = CommonTokenStream(lexer)
        parser = ParameterParser(stream)
        tree = parser.start_()
        return _param_visitor.visit(tree)


parameter_parser = _ParameterParser()
