# Generated from Parameter.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .ParameterParser import ParameterParser
else:
    from ParameterParser import ParameterParser

# This class defines a complete listener for a parse tree produced by ParameterParser.
class ParameterListener(ParseTreeListener):

    # Enter a parse tree produced by ParameterParser#start_.
    def enterStart_(self, ctx:ParameterParser.Start_Context):
        pass

    # Exit a parse tree produced by ParameterParser#start_.
    def exitStart_(self, ctx:ParameterParser.Start_Context):
        pass


    # Enter a parse tree produced by ParameterParser#BasicParam.
    def enterBasicParam(self, ctx:ParameterParser.BasicParamContext):
        pass

    # Exit a parse tree produced by ParameterParser#BasicParam.
    def exitBasicParam(self, ctx:ParameterParser.BasicParamContext):
        pass


    # Enter a parse tree produced by ParameterParser#ParamWithBitop.
    def enterParamWithBitop(self, ctx:ParameterParser.ParamWithBitopContext):
        pass

    # Exit a parse tree produced by ParameterParser#ParamWithBitop.
    def exitParamWithBitop(self, ctx:ParameterParser.ParamWithBitopContext):
        pass


    # Enter a parse tree produced by ParameterParser#GenParamWithBitop.
    def enterGenParamWithBitop(self, ctx:ParameterParser.GenParamWithBitopContext):
        pass

    # Exit a parse tree produced by ParameterParser#GenParamWithBitop.
    def exitGenParamWithBitop(self, ctx:ParameterParser.GenParamWithBitopContext):
        pass


    # Enter a parse tree produced by ParameterParser#GenParamNpBitop.
    def enterGenParamNpBitop(self, ctx:ParameterParser.GenParamNpBitopContext):
        pass

    # Exit a parse tree produced by ParameterParser#GenParamNpBitop.
    def exitGenParamNpBitop(self, ctx:ParameterParser.GenParamNpBitopContext):
        pass


    # Enter a parse tree produced by ParameterParser#GenParam.
    def enterGenParam(self, ctx:ParameterParser.GenParamContext):
        pass

    # Exit a parse tree produced by ParameterParser#GenParam.
    def exitGenParam(self, ctx:ParameterParser.GenParamContext):
        pass


    # Enter a parse tree produced by ParameterParser#GenParamNp.
    def enterGenParamNp(self, ctx:ParameterParser.GenParamNpContext):
        pass

    # Exit a parse tree produced by ParameterParser#GenParamNp.
    def exitGenParamNp(self, ctx:ParameterParser.GenParamNpContext):
        pass


    # Enter a parse tree produced by ParameterParser#SupercomParamWithBitop.
    def enterSupercomParamWithBitop(self, ctx:ParameterParser.SupercomParamWithBitopContext):
        pass

    # Exit a parse tree produced by ParameterParser#SupercomParamWithBitop.
    def exitSupercomParamWithBitop(self, ctx:ParameterParser.SupercomParamWithBitopContext):
        pass


    # Enter a parse tree produced by ParameterParser#SupercomParam.
    def enterSupercomParam(self, ctx:ParameterParser.SupercomParamContext):
        pass

    # Exit a parse tree produced by ParameterParser#SupercomParam.
    def exitSupercomParam(self, ctx:ParameterParser.SupercomParamContext):
        pass


    # Enter a parse tree produced by ParameterParser#UpIterator.
    def enterUpIterator(self, ctx:ParameterParser.UpIteratorContext):
        pass

    # Exit a parse tree produced by ParameterParser#UpIterator.
    def exitUpIterator(self, ctx:ParameterParser.UpIteratorContext):
        pass


    # Enter a parse tree produced by ParameterParser#DnIterator.
    def enterDnIterator(self, ctx:ParameterParser.DnIteratorContext):
        pass

    # Exit a parse tree produced by ParameterParser#DnIterator.
    def exitDnIterator(self, ctx:ParameterParser.DnIteratorContext):
        pass


    # Enter a parse tree produced by ParameterParser#bitOp.
    def enterBitOp(self, ctx:ParameterParser.BitOpContext):
        pass

    # Exit a parse tree produced by ParameterParser#bitOp.
    def exitBitOp(self, ctx:ParameterParser.BitOpContext):
        pass


    # Enter a parse tree produced by ParameterParser#allFragments.
    def enterAllFragments(self, ctx:ParameterParser.AllFragmentsContext):
        pass

    # Exit a parse tree produced by ParameterParser#allFragments.
    def exitAllFragments(self, ctx:ParameterParser.AllFragmentsContext):
        pass


    # Enter a parse tree produced by ParameterParser#crFragments.
    def enterCrFragments(self, ctx:ParameterParser.CrFragmentsContext):
        pass

    # Exit a parse tree produced by ParameterParser#crFragments.
    def exitCrFragments(self, ctx:ParameterParser.CrFragmentsContext):
        pass


    # Enter a parse tree produced by ParameterParser#HexConst.
    def enterHexConst(self, ctx:ParameterParser.HexConstContext):
        pass

    # Exit a parse tree produced by ParameterParser#HexConst.
    def exitHexConst(self, ctx:ParameterParser.HexConstContext):
        pass


    # Enter a parse tree produced by ParameterParser#OctConst.
    def enterOctConst(self, ctx:ParameterParser.OctConstContext):
        pass

    # Exit a parse tree produced by ParameterParser#OctConst.
    def exitOctConst(self, ctx:ParameterParser.OctConstContext):
        pass


    # Enter a parse tree produced by ParameterParser#BinConst.
    def enterBinConst(self, ctx:ParameterParser.BinConstContext):
        pass

    # Exit a parse tree produced by ParameterParser#BinConst.
    def exitBinConst(self, ctx:ParameterParser.BinConstContext):
        pass


    # Enter a parse tree produced by ParameterParser#QuotedHexConst.
    def enterQuotedHexConst(self, ctx:ParameterParser.QuotedHexConstContext):
        pass

    # Exit a parse tree produced by ParameterParser#QuotedHexConst.
    def exitQuotedHexConst(self, ctx:ParameterParser.QuotedHexConstContext):
        pass


    # Enter a parse tree produced by ParameterParser#QuotedOctConst.
    def enterQuotedOctConst(self, ctx:ParameterParser.QuotedOctConstContext):
        pass

    # Exit a parse tree produced by ParameterParser#QuotedOctConst.
    def exitQuotedOctConst(self, ctx:ParameterParser.QuotedOctConstContext):
        pass


    # Enter a parse tree produced by ParameterParser#QuotedBinConst.
    def enterQuotedBinConst(self, ctx:ParameterParser.QuotedBinConstContext):
        pass

    # Exit a parse tree produced by ParameterParser#QuotedBinConst.
    def exitQuotedBinConst(self, ctx:ParameterParser.QuotedBinConstContext):
        pass


    # Enter a parse tree produced by ParameterParser#FragSingle.
    def enterFragSingle(self, ctx:ParameterParser.FragSingleContext):
        pass

    # Exit a parse tree produced by ParameterParser#FragSingle.
    def exitFragSingle(self, ctx:ParameterParser.FragSingleContext):
        pass


    # Enter a parse tree produced by ParameterParser#FragRange.
    def enterFragRange(self, ctx:ParameterParser.FragRangeContext):
        pass

    # Exit a parse tree produced by ParameterParser#FragRange.
    def exitFragRange(self, ctx:ParameterParser.FragRangeContext):
        pass


    # Enter a parse tree produced by ParameterParser#FragBitsLast3.
    def enterFragBitsLast3(self, ctx:ParameterParser.FragBitsLast3Context):
        pass

    # Exit a parse tree produced by ParameterParser#FragBitsLast3.
    def exitFragBitsLast3(self, ctx:ParameterParser.FragBitsLast3Context):
        pass


    # Enter a parse tree produced by ParameterParser#FragBits.
    def enterFragBits(self, ctx:ParameterParser.FragBitsContext):
        pass

    # Exit a parse tree produced by ParameterParser#FragBits.
    def exitFragBits(self, ctx:ParameterParser.FragBitsContext):
        pass


    # Enter a parse tree produced by ParameterParser#bitSpec.
    def enterBitSpec(self, ctx:ParameterParser.BitSpecContext):
        pass

    # Exit a parse tree produced by ParameterParser#bitSpec.
    def exitBitSpec(self, ctx:ParameterParser.BitSpecContext):
        pass


    # Enter a parse tree produced by ParameterParser#bitList.
    def enterBitList(self, ctx:ParameterParser.BitListContext):
        pass

    # Exit a parse tree produced by ParameterParser#bitList.
    def exitBitList(self, ctx:ParameterParser.BitListContext):
        pass


    # Enter a parse tree produced by ParameterParser#range_.
    def enterRange_(self, ctx:ParameterParser.Range_Context):
        pass

    # Exit a parse tree produced by ParameterParser#range_.
    def exitRange_(self, ctx:ParameterParser.Range_Context):
        pass


    # Enter a parse tree produced by ParameterParser#constValue.
    def enterConstValue(self, ctx:ParameterParser.ConstValueContext):
        pass

    # Exit a parse tree produced by ParameterParser#constValue.
    def exitConstValue(self, ctx:ParameterParser.ConstValueContext):
        pass


    # Enter a parse tree produced by ParameterParser#bitMask.
    def enterBitMask(self, ctx:ParameterParser.BitMaskContext):
        pass

    # Exit a parse tree produced by ParameterParser#bitMask.
    def exitBitMask(self, ctx:ParameterParser.BitMaskContext):
        pass



del ParameterParser
