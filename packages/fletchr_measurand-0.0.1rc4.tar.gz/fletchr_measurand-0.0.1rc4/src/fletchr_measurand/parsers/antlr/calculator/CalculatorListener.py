# Generated from C:/Users/jolst/repos/measurand/src/measurand/parser/antlr/Calculator.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .CalculatorParser import CalculatorParser
else:
    from CalculatorParser import CalculatorParser

# This class defines a complete listener for a parse tree produced by CalculatorParser.
class CalculatorListener(ParseTreeListener):

    # Enter a parse tree produced by CalculatorParser#start_.
    def enterStart_(self, ctx:CalculatorParser.Start_Context):
        pass

    # Exit a parse tree produced by CalculatorParser#start_.
    def exitStart_(self, ctx:CalculatorParser.Start_Context):
        pass


    # Enter a parse tree produced by CalculatorParser#Add.
    def enterAdd(self, ctx:CalculatorParser.AddContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Add.
    def exitAdd(self, ctx:CalculatorParser.AddContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Sub.
    def enterSub(self, ctx:CalculatorParser.SubContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Sub.
    def exitSub(self, ctx:CalculatorParser.SubContext):
        pass


    # Enter a parse tree produced by CalculatorParser#SumPassthrough.
    def enterSumPassthrough(self, ctx:CalculatorParser.SumPassthroughContext):
        pass

    # Exit a parse tree produced by CalculatorParser#SumPassthrough.
    def exitSumPassthrough(self, ctx:CalculatorParser.SumPassthroughContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Div.
    def enterDiv(self, ctx:CalculatorParser.DivContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Div.
    def exitDiv(self, ctx:CalculatorParser.DivContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Mul.
    def enterMul(self, ctx:CalculatorParser.MulContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Mul.
    def exitMul(self, ctx:CalculatorParser.MulContext):
        pass


    # Enter a parse tree produced by CalculatorParser#ProductPassthrough.
    def enterProductPassthrough(self, ctx:CalculatorParser.ProductPassthroughContext):
        pass

    # Exit a parse tree produced by CalculatorParser#ProductPassthrough.
    def exitProductPassthrough(self, ctx:CalculatorParser.ProductPassthroughContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Pow.
    def enterPow(self, ctx:CalculatorParser.PowContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Pow.
    def exitPow(self, ctx:CalculatorParser.PowContext):
        pass


    # Enter a parse tree produced by CalculatorParser#PowerPassthrough.
    def enterPowerPassthrough(self, ctx:CalculatorParser.PowerPassthroughContext):
        pass

    # Exit a parse tree produced by CalculatorParser#PowerPassthrough.
    def exitPowerPassthrough(self, ctx:CalculatorParser.PowerPassthroughContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Number.
    def enterNumber(self, ctx:CalculatorParser.NumberContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Number.
    def exitNumber(self, ctx:CalculatorParser.NumberContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Neg.
    def enterNeg(self, ctx:CalculatorParser.NegContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Neg.
    def exitNeg(self, ctx:CalculatorParser.NegContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Pv.
    def enterPv(self, ctx:CalculatorParser.PvContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Pv.
    def exitPv(self, ctx:CalculatorParser.PvContext):
        pass


    # Enter a parse tree produced by CalculatorParser#ConstantAtom.
    def enterConstantAtom(self, ctx:CalculatorParser.ConstantAtomContext):
        pass

    # Exit a parse tree produced by CalculatorParser#ConstantAtom.
    def exitConstantAtom(self, ctx:CalculatorParser.ConstantAtomContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Parens.
    def enterParens(self, ctx:CalculatorParser.ParensContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Parens.
    def exitParens(self, ctx:CalculatorParser.ParensContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Float.
    def enterFloat(self, ctx:CalculatorParser.FloatContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Float.
    def exitFloat(self, ctx:CalculatorParser.FloatContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Fix.
    def enterFix(self, ctx:CalculatorParser.FixContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Fix.
    def exitFix(self, ctx:CalculatorParser.FixContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Round.
    def enterRound(self, ctx:CalculatorParser.RoundContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Round.
    def exitRound(self, ctx:CalculatorParser.RoundContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Floor.
    def enterFloor(self, ctx:CalculatorParser.FloorContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Floor.
    def exitFloor(self, ctx:CalculatorParser.FloorContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Ceil.
    def enterCeil(self, ctx:CalculatorParser.CeilContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Ceil.
    def exitCeil(self, ctx:CalculatorParser.CeilContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Nxtwo.
    def enterNxtwo(self, ctx:CalculatorParser.NxtwoContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Nxtwo.
    def exitNxtwo(self, ctx:CalculatorParser.NxtwoContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Sin.
    def enterSin(self, ctx:CalculatorParser.SinContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Sin.
    def exitSin(self, ctx:CalculatorParser.SinContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Cos.
    def enterCos(self, ctx:CalculatorParser.CosContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Cos.
    def exitCos(self, ctx:CalculatorParser.CosContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Tan.
    def enterTan(self, ctx:CalculatorParser.TanContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Tan.
    def exitTan(self, ctx:CalculatorParser.TanContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Asin.
    def enterAsin(self, ctx:CalculatorParser.AsinContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Asin.
    def exitAsin(self, ctx:CalculatorParser.AsinContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Acos.
    def enterAcos(self, ctx:CalculatorParser.AcosContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Acos.
    def exitAcos(self, ctx:CalculatorParser.AcosContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Atan.
    def enterAtan(self, ctx:CalculatorParser.AtanContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Atan.
    def exitAtan(self, ctx:CalculatorParser.AtanContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Atan2.
    def enterAtan2(self, ctx:CalculatorParser.Atan2Context):
        pass

    # Exit a parse tree produced by CalculatorParser#Atan2.
    def exitAtan2(self, ctx:CalculatorParser.Atan2Context):
        pass


    # Enter a parse tree produced by CalculatorParser#Deg.
    def enterDeg(self, ctx:CalculatorParser.DegContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Deg.
    def exitDeg(self, ctx:CalculatorParser.DegContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Rad.
    def enterRad(self, ctx:CalculatorParser.RadContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Rad.
    def exitRad(self, ctx:CalculatorParser.RadContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Abs.
    def enterAbs(self, ctx:CalculatorParser.AbsContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Abs.
    def exitAbs(self, ctx:CalculatorParser.AbsContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Exp.
    def enterExp(self, ctx:CalculatorParser.ExpContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Exp.
    def exitExp(self, ctx:CalculatorParser.ExpContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Tento.
    def enterTento(self, ctx:CalculatorParser.TentoContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Tento.
    def exitTento(self, ctx:CalculatorParser.TentoContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Ln.
    def enterLn(self, ctx:CalculatorParser.LnContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Ln.
    def exitLn(self, ctx:CalculatorParser.LnContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Log10.
    def enterLog10(self, ctx:CalculatorParser.Log10Context):
        pass

    # Exit a parse tree produced by CalculatorParser#Log10.
    def exitLog10(self, ctx:CalculatorParser.Log10Context):
        pass


    # Enter a parse tree produced by CalculatorParser#Sqrt.
    def enterSqrt(self, ctx:CalculatorParser.SqrtContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Sqrt.
    def exitSqrt(self, ctx:CalculatorParser.SqrtContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Max.
    def enterMax(self, ctx:CalculatorParser.MaxContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Max.
    def exitMax(self, ctx:CalculatorParser.MaxContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Min.
    def enterMin(self, ctx:CalculatorParser.MinContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Min.
    def exitMin(self, ctx:CalculatorParser.MinContext):
        pass


    # Enter a parse tree produced by CalculatorParser#If.
    def enterIf(self, ctx:CalculatorParser.IfContext):
        pass

    # Exit a parse tree produced by CalculatorParser#If.
    def exitIf(self, ctx:CalculatorParser.IfContext):
        pass


    # Enter a parse tree produced by CalculatorParser#Hamdist.
    def enterHamdist(self, ctx:CalculatorParser.HamdistContext):
        pass

    # Exit a parse tree produced by CalculatorParser#Hamdist.
    def exitHamdist(self, ctx:CalculatorParser.HamdistContext):
        pass


    # Enter a parse tree produced by CalculatorParser#constant.
    def enterConstant(self, ctx:CalculatorParser.ConstantContext):
        pass

    # Exit a parse tree produced by CalculatorParser#constant.
    def exitConstant(self, ctx:CalculatorParser.ConstantContext):
        pass


    # Enter a parse tree produced by CalculatorParser#csv.
    def enterCsv(self, ctx:CalculatorParser.CsvContext):
        pass

    # Exit a parse tree produced by CalculatorParser#csv.
    def exitCsv(self, ctx:CalculatorParser.CsvContext):
        pass



del CalculatorParser
