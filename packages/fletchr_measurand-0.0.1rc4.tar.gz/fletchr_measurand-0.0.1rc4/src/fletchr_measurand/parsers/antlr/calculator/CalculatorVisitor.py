# Generated from C:/Users/jolst/repos/measurand/src/measurand/parser/antlr/Calculator.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .CalculatorParser import CalculatorParser
else:
    from CalculatorParser import CalculatorParser

# This class defines a complete generic visitor for a parse tree produced by CalculatorParser.

class CalculatorVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by CalculatorParser#start_.
    def visitStart_(self, ctx:CalculatorParser.Start_Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Add.
    def visitAdd(self, ctx:CalculatorParser.AddContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Sub.
    def visitSub(self, ctx:CalculatorParser.SubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#SumPassthrough.
    def visitSumPassthrough(self, ctx:CalculatorParser.SumPassthroughContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Div.
    def visitDiv(self, ctx:CalculatorParser.DivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Mul.
    def visitMul(self, ctx:CalculatorParser.MulContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#ProductPassthrough.
    def visitProductPassthrough(self, ctx:CalculatorParser.ProductPassthroughContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Pow.
    def visitPow(self, ctx:CalculatorParser.PowContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#PowerPassthrough.
    def visitPowerPassthrough(self, ctx:CalculatorParser.PowerPassthroughContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Number.
    def visitNumber(self, ctx:CalculatorParser.NumberContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Neg.
    def visitNeg(self, ctx:CalculatorParser.NegContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Pv.
    def visitPv(self, ctx:CalculatorParser.PvContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#ConstantAtom.
    def visitConstantAtom(self, ctx:CalculatorParser.ConstantAtomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Parens.
    def visitParens(self, ctx:CalculatorParser.ParensContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Float.
    def visitFloat(self, ctx:CalculatorParser.FloatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Fix.
    def visitFix(self, ctx:CalculatorParser.FixContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Round.
    def visitRound(self, ctx:CalculatorParser.RoundContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Floor.
    def visitFloor(self, ctx:CalculatorParser.FloorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Ceil.
    def visitCeil(self, ctx:CalculatorParser.CeilContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Nxtwo.
    def visitNxtwo(self, ctx:CalculatorParser.NxtwoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Sin.
    def visitSin(self, ctx:CalculatorParser.SinContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Cos.
    def visitCos(self, ctx:CalculatorParser.CosContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Tan.
    def visitTan(self, ctx:CalculatorParser.TanContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Asin.
    def visitAsin(self, ctx:CalculatorParser.AsinContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Acos.
    def visitAcos(self, ctx:CalculatorParser.AcosContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Atan.
    def visitAtan(self, ctx:CalculatorParser.AtanContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Atan2.
    def visitAtan2(self, ctx:CalculatorParser.Atan2Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Deg.
    def visitDeg(self, ctx:CalculatorParser.DegContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Rad.
    def visitRad(self, ctx:CalculatorParser.RadContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Abs.
    def visitAbs(self, ctx:CalculatorParser.AbsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Exp.
    def visitExp(self, ctx:CalculatorParser.ExpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Tento.
    def visitTento(self, ctx:CalculatorParser.TentoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Ln.
    def visitLn(self, ctx:CalculatorParser.LnContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Log10.
    def visitLog10(self, ctx:CalculatorParser.Log10Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Sqrt.
    def visitSqrt(self, ctx:CalculatorParser.SqrtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Max.
    def visitMax(self, ctx:CalculatorParser.MaxContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Min.
    def visitMin(self, ctx:CalculatorParser.MinContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#If.
    def visitIf(self, ctx:CalculatorParser.IfContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#Hamdist.
    def visitHamdist(self, ctx:CalculatorParser.HamdistContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#constant.
    def visitConstant(self, ctx:CalculatorParser.ConstantContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalculatorParser#csv.
    def visitCsv(self, ctx:CalculatorParser.CsvContext):
        return self.visitChildren(ctx)



del CalculatorParser
