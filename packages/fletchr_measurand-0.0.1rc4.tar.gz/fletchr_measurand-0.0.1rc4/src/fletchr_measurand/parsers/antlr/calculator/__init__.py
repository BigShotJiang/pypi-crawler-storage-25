# pyright: reportIncompatibleMethodOverride=false
#
# ANTLR's Python generator emits every visit method as `-> None`, so any
# override that returns a useful value trips reportIncompatibleMethodOverride.
# The mismatch is a generator-output limitation, not a real typing error.
"""ANTLR-based calculator parser.

Drop-in replacement for the Lark-based calculator parser. Provides the same
interface: `calculator_parser.parse(expr)` returns a number or a callable `f(PV)`.
"""

from __future__ import annotations

import math
import operator
from collections.abc import Callable
from typing import Any, TypeVar, Union

from antlr4 import CommonTokenStream, InputStream

from .CalculatorLexer import CalculatorLexer
from .CalculatorParser import CalculatorParser
from .CalculatorVisitor import CalculatorVisitor

Number = Union[int, float]
CN = Union[Number, Callable]

_T = TypeVar("_T")


def _req(x: _T | None) -> _T:
    """Narrow an Optional ANTLR child access to non-None."""
    assert x is not None, "antlr: required context child was None"
    return x


def _text(node: Any) -> str:
    """Extract text from an ANTLR TerminalNode (typestubs are incomplete)."""
    assert node is not None, "antlr: TerminalNode was None"
    return node.getText()


def nxtwo(val: Number) -> int:
    return 2 ** math.ceil(math.log(val, 2))


def tento(val: Number) -> Number:
    return 10**val


def hamdist(a: Number, b: Number) -> int:
    return f"{int(a) ^ int(b):b}".count("1")


def _lift(fn: Callable[..., Any]) -> Callable[..., CN]:
    """Lift a plain function to transparently handle Callable (PV-dependent) arguments."""

    def wrapper(*args: CN) -> CN:
        if any(isinstance(a, Callable) for a in args):

            def f(PV):
                return fn(*(a(PV) if isinstance(a, Callable) else a for a in args))

            return f
        return fn(*args)

    return wrapper


_add = _lift(operator.add)
_sub = _lift(operator.sub)
_mul = _lift(operator.mul)
_div = _lift(operator.truediv)
_pow = _lift(operator.pow)
_neg = _lift(operator.neg)
_float = _lift(float)
_int = _lift(int)
_round = _lift(round)
_floor = _lift(math.floor)
_ceil = _lift(math.ceil)
_abs = _lift(abs)
_sqrt = _lift(math.sqrt)
_exp = _lift(math.exp)
_log = _lift(math.log)
_log10 = _lift(math.log10)
_nxtwo = _lift(nxtwo)
_tento = _lift(tento)
_sin = _lift(math.sin)
_cos = _lift(math.cos)
_tan = _lift(math.tan)
_asin = _lift(math.asin)
_acos = _lift(math.acos)
_atan = _lift(math.atan)
_atan2 = _lift(math.atan2)
_deg = _lift(math.degrees)
_rad = _lift(math.radians)
_hamdist = _lift(hamdist)
_max = _lift(max)
_min = _lift(min)


class _EvalVisitor(CalculatorVisitor):
    def visit(self, tree: Any) -> Any:  # type: ignore[override]
        return super().visit(tree)

    def visitStart_(self, ctx: Any) -> CN:
        return self.visit(_req(ctx.sum_()))

    # Passthrough rules
    def visitSumPassthrough(self, ctx: Any) -> CN:
        return self.visit(_req(ctx.product()))

    def visitProductPassthrough(self, ctx: Any) -> CN:
        return self.visit(_req(ctx.power()))

    def visitPowerPassthrough(self, ctx: Any) -> CN:
        return self.visit(_req(ctx.atom()))

    # Arithmetic
    def visitAdd(self, ctx: Any) -> CN:
        return _add(self.visit(_req(ctx.sum_())), self.visit(_req(ctx.product())))

    def visitSub(self, ctx: Any) -> CN:
        return _sub(self.visit(_req(ctx.sum_())), self.visit(_req(ctx.product())))

    def visitMul(self, ctx: Any) -> CN:
        return _mul(self.visit(_req(ctx.product())), self.visit(_req(ctx.power())))

    def visitDiv(self, ctx: Any) -> CN:
        return _div(self.visit(_req(ctx.product())), self.visit(_req(ctx.power())))

    def visitPow(self, ctx: Any) -> CN:
        return _pow(self.visit(_req(ctx.power())), self.visit(_req(ctx.atom())))

    def visitNeg(self, ctx: Any) -> CN:
        return _neg(self.visit(_req(ctx.atom())))

    # Literals / terminals
    def visitNumber(self, ctx: Any) -> Number:
        text = _text(ctx.NUMBER())
        try:
            return int(text)
        except ValueError:
            return float(text)

    def visitPv(self, ctx: Any) -> Callable[[Any], Any]:
        def f(PV: Any) -> Any:
            return PV

        return f

    def visitConstantAtom(self, ctx: Any) -> CN:
        return self.visit(_req(ctx.constant()))

    def visitConstant(self, ctx: Any) -> Number:
        if ctx.PI():
            return math.pi
        if ctx.E():
            return math.e
        raise ValueError(f"Unknown calculator constant: {ctx.getText()!r}")

    def visitParens(self, ctx: Any) -> CN:
        return self.visit(_req(ctx.sum_()))

    # Unary functions
    def visitFloat(self, ctx: Any) -> CN:
        return _float(self.visit(_req(ctx.sum_())))

    def visitFix(self, ctx: Any) -> CN:
        return _int(self.visit(_req(ctx.sum_())))

    def visitRound(self, ctx: Any) -> CN:
        return _round(self.visit(_req(ctx.sum_())))

    def visitFloor(self, ctx: Any) -> CN:
        return _floor(self.visit(_req(ctx.sum_())))

    def visitCeil(self, ctx: Any) -> CN:
        return _ceil(self.visit(_req(ctx.sum_())))

    def visitNxtwo(self, ctx: Any) -> CN:
        return _nxtwo(self.visit(_req(ctx.sum_())))

    def visitSin(self, ctx: Any) -> CN:
        return _sin(self.visit(_req(ctx.sum_())))

    def visitCos(self, ctx: Any) -> CN:
        return _cos(self.visit(_req(ctx.sum_())))

    def visitTan(self, ctx: Any) -> CN:
        return _tan(self.visit(_req(ctx.sum_())))

    def visitAsin(self, ctx: Any) -> CN:
        return _asin(self.visit(_req(ctx.sum_())))

    def visitAcos(self, ctx: Any) -> CN:
        return _acos(self.visit(_req(ctx.sum_())))

    def visitAtan(self, ctx: Any) -> CN:
        return _atan(self.visit(_req(ctx.sum_())))

    def visitAtan2(self, ctx: Any) -> CN:
        return _atan2(self.visit(_req(ctx.sum_(0))), self.visit(_req(ctx.sum_(1))))

    def visitDeg(self, ctx: Any) -> CN:
        return _deg(self.visit(_req(ctx.sum_())))

    def visitRad(self, ctx: Any) -> CN:
        return _rad(self.visit(_req(ctx.sum_())))

    def visitAbs(self, ctx: Any) -> CN:
        return _abs(self.visit(_req(ctx.sum_())))

    def visitExp(self, ctx: Any) -> CN:
        return _exp(self.visit(_req(ctx.sum_())))

    def visitTento(self, ctx: Any) -> CN:
        return _tento(self.visit(_req(ctx.sum_())))

    def visitLn(self, ctx: Any) -> CN:
        return _log(self.visit(_req(ctx.sum_())))

    def visitLog10(self, ctx: Any) -> CN:
        return _log10(self.visit(_req(ctx.sum_())))

    def visitSqrt(self, ctx: Any) -> CN:
        return _sqrt(self.visit(_req(ctx.sum_())))

    # Binary / variadic
    def visitHamdist(self, ctx: Any) -> CN:
        return _hamdist(self.visit(_req(ctx.sum_(0))), self.visit(_req(ctx.sum_(1))))

    def visitMax(self, ctx: Any) -> CN:
        return _max(*self._visit_csv(_req(ctx.csv())))

    def visitMin(self, ctx: Any) -> CN:
        return _min(*self._visit_csv(_req(ctx.csv())))

    def visitIf(self, ctx: Any) -> CN:
        a = self.visit(_req(ctx.sum_(0)))
        b = self.visit(_req(ctx.sum_(1)))
        c = self.visit(_req(ctx.sum_(2)))
        args = [a, b, c]

        if any(isinstance(x, Callable) for x in args):

            def f(PV: Any) -> Any:
                vals = [x(PV) if isinstance(x, Callable) else x for x in args]
                return vals[1] if vals[0] > 0 else vals[2]

            return f
        if not isinstance(a, Callable):
            return b if a > 0 else c
        raise TypeError(f"visitIf: condition must be numeric or Callable, got {type(a).__name__}")

    # Helpers
    def _visit_csv(self, ctx: Any) -> list[Any]:
        return [self.visit(s) for s in _req(ctx.sum_())]


_visitor = _EvalVisitor()


class _Parser:
    """Wrapper providing the same `.parse(expr)` interface as the Lark parser."""

    def parse(self, expr: str) -> CN:
        lexer = CalculatorLexer(InputStream(expr))
        stream = CommonTokenStream(lexer)
        parser = CalculatorParser(stream)
        tree = parser.start_()
        return _visitor.visit(tree)


calculator_parser = _Parser()
