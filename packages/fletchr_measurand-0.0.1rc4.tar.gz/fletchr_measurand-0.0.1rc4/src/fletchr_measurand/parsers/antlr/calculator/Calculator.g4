grammar Calculator;

options { caseInsensitive = true; }

start_: sum_ EOF;

sum_
    : sum_ '+' product    # Add
    | sum_ '-' product    # Sub
    | product             # SumPassthrough
    ;

product
    : product '*' power   # Mul
    | product '/' power   # Div
    | power               # ProductPassthrough
    ;

power
    : power '**' atom     # Pow
    | atom                # PowerPassthrough
    ;

atom
    : NUMBER              # Number
    | '-' atom            # Neg
    | PV                  # Pv
    | constant            # ConstantAtom
    | '(' sum_ ')'                              # Parens
    | 'float' '(' sum_ ')'                      # Float
    | 'fix'   '(' sum_ ')'                      # Fix
    | 'round' '(' sum_ ')'                      # Round
    | 'floor' '(' sum_ ')'                      # Floor
    | 'ceil'  '(' sum_ ')'                      # Ceil
    | 'nxtwo' '(' sum_ ')'                      # Nxtwo
    | 'sin'   '(' sum_ ')'                      # Sin
    | 'cos'   '(' sum_ ')'                      # Cos
    | 'tan'   '(' sum_ ')'                      # Tan
    | 'asin'  '(' sum_ ')'                      # Asin
    | 'acos'  '(' sum_ ')'                      # Acos
    | 'atan'  '(' sum_ ')'                      # Atan
    | 'atan2' '(' sum_ ',' sum_ ')'             # Atan2
    | 'deg'   '(' sum_ ')'                      # Deg
    | 'rad'   '(' sum_ ')'                      # Rad
    | 'abs'   '(' sum_ ')'                      # Abs
    | 'exp'   '(' sum_ ')'                      # Exp
    | 'tento' '(' sum_ ')'                      # Tento
    | 'ln'    '(' sum_ ')'                      # Ln
    | 'log10' '(' sum_ ')'                      # Log10
    | 'sqrt'  '(' sum_ ')'                      # Sqrt
    | 'max'   '(' csv ')'                       # Max
    | 'min'   '(' csv ')'                       # Min
    | 'if'    '(' sum_ ',' sum_ ',' sum_ ')'    # If
    | 'hamdist' '(' sum_ ',' sum_ ')'           # Hamdist
    ;

constant: PI | E;

csv: sum_ (',' sum_)*;

PV: 'PV';
PI: 'PI';
E:  'E';

NUMBER: [0-9]+ ('.' [0-9]+)?;

WS: [ \t]+ -> skip;
