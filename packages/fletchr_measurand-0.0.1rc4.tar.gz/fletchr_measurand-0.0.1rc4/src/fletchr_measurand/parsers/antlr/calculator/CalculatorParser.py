# Generated from C:/Users/jolst/repos/measurand/src/measurand/parser/antlr/Calculator.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,38,211,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,1,27,8,1,10,
        1,12,1,30,9,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,5,2,41,8,2,10,
        2,12,2,44,9,2,1,3,1,3,1,3,1,3,1,3,1,3,5,3,52,8,3,10,3,12,3,55,9,
        3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,199,
        8,4,1,5,1,5,1,6,1,6,1,6,5,6,206,8,6,10,6,12,6,209,9,6,1,6,0,3,2,
        4,6,7,0,2,4,6,8,10,12,0,1,1,0,35,36,238,0,14,1,0,0,0,2,17,1,0,0,
        0,4,31,1,0,0,0,6,45,1,0,0,0,8,198,1,0,0,0,10,200,1,0,0,0,12,202,
        1,0,0,0,14,15,3,2,1,0,15,16,5,0,0,1,16,1,1,0,0,0,17,18,6,1,-1,0,
        18,19,3,4,2,0,19,28,1,0,0,0,20,21,10,3,0,0,21,22,5,1,0,0,22,27,3,
        4,2,0,23,24,10,2,0,0,24,25,5,2,0,0,25,27,3,4,2,0,26,20,1,0,0,0,26,
        23,1,0,0,0,27,30,1,0,0,0,28,26,1,0,0,0,28,29,1,0,0,0,29,3,1,0,0,
        0,30,28,1,0,0,0,31,32,6,2,-1,0,32,33,3,6,3,0,33,42,1,0,0,0,34,35,
        10,3,0,0,35,36,5,3,0,0,36,41,3,6,3,0,37,38,10,2,0,0,38,39,5,4,0,
        0,39,41,3,6,3,0,40,34,1,0,0,0,40,37,1,0,0,0,41,44,1,0,0,0,42,40,
        1,0,0,0,42,43,1,0,0,0,43,5,1,0,0,0,44,42,1,0,0,0,45,46,6,3,-1,0,
        46,47,3,8,4,0,47,53,1,0,0,0,48,49,10,2,0,0,49,50,5,5,0,0,50,52,3,
        8,4,0,51,48,1,0,0,0,52,55,1,0,0,0,53,51,1,0,0,0,53,54,1,0,0,0,54,
        7,1,0,0,0,55,53,1,0,0,0,56,199,5,37,0,0,57,58,5,2,0,0,58,199,3,8,
        4,0,59,199,5,34,0,0,60,199,3,10,5,0,61,62,5,6,0,0,62,63,3,2,1,0,
        63,64,5,7,0,0,64,199,1,0,0,0,65,66,5,8,0,0,66,67,5,6,0,0,67,68,3,
        2,1,0,68,69,5,7,0,0,69,199,1,0,0,0,70,71,5,9,0,0,71,72,5,6,0,0,72,
        73,3,2,1,0,73,74,5,7,0,0,74,199,1,0,0,0,75,76,5,10,0,0,76,77,5,6,
        0,0,77,78,3,2,1,0,78,79,5,7,0,0,79,199,1,0,0,0,80,81,5,11,0,0,81,
        82,5,6,0,0,82,83,3,2,1,0,83,84,5,7,0,0,84,199,1,0,0,0,85,86,5,12,
        0,0,86,87,5,6,0,0,87,88,3,2,1,0,88,89,5,7,0,0,89,199,1,0,0,0,90,
        91,5,13,0,0,91,92,5,6,0,0,92,93,3,2,1,0,93,94,5,7,0,0,94,199,1,0,
        0,0,95,96,5,14,0,0,96,97,5,6,0,0,97,98,3,2,1,0,98,99,5,7,0,0,99,
        199,1,0,0,0,100,101,5,15,0,0,101,102,5,6,0,0,102,103,3,2,1,0,103,
        104,5,7,0,0,104,199,1,0,0,0,105,106,5,16,0,0,106,107,5,6,0,0,107,
        108,3,2,1,0,108,109,5,7,0,0,109,199,1,0,0,0,110,111,5,17,0,0,111,
        112,5,6,0,0,112,113,3,2,1,0,113,114,5,7,0,0,114,199,1,0,0,0,115,
        116,5,18,0,0,116,117,5,6,0,0,117,118,3,2,1,0,118,119,5,7,0,0,119,
        199,1,0,0,0,120,121,5,19,0,0,121,122,5,6,0,0,122,123,3,2,1,0,123,
        124,5,7,0,0,124,199,1,0,0,0,125,126,5,20,0,0,126,127,5,6,0,0,127,
        128,3,2,1,0,128,129,5,21,0,0,129,130,3,2,1,0,130,131,5,7,0,0,131,
        199,1,0,0,0,132,133,5,22,0,0,133,134,5,6,0,0,134,135,3,2,1,0,135,
        136,5,7,0,0,136,199,1,0,0,0,137,138,5,23,0,0,138,139,5,6,0,0,139,
        140,3,2,1,0,140,141,5,7,0,0,141,199,1,0,0,0,142,143,5,24,0,0,143,
        144,5,6,0,0,144,145,3,2,1,0,145,146,5,7,0,0,146,199,1,0,0,0,147,
        148,5,25,0,0,148,149,5,6,0,0,149,150,3,2,1,0,150,151,5,7,0,0,151,
        199,1,0,0,0,152,153,5,26,0,0,153,154,5,6,0,0,154,155,3,2,1,0,155,
        156,5,7,0,0,156,199,1,0,0,0,157,158,5,27,0,0,158,159,5,6,0,0,159,
        160,3,2,1,0,160,161,5,7,0,0,161,199,1,0,0,0,162,163,5,28,0,0,163,
        164,5,6,0,0,164,165,3,2,1,0,165,166,5,7,0,0,166,199,1,0,0,0,167,
        168,5,29,0,0,168,169,5,6,0,0,169,170,3,2,1,0,170,171,5,7,0,0,171,
        199,1,0,0,0,172,173,5,30,0,0,173,174,5,6,0,0,174,175,3,12,6,0,175,
        176,5,7,0,0,176,199,1,0,0,0,177,178,5,31,0,0,178,179,5,6,0,0,179,
        180,3,12,6,0,180,181,5,7,0,0,181,199,1,0,0,0,182,183,5,32,0,0,183,
        184,5,6,0,0,184,185,3,2,1,0,185,186,5,21,0,0,186,187,3,2,1,0,187,
        188,5,21,0,0,188,189,3,2,1,0,189,190,5,7,0,0,190,199,1,0,0,0,191,
        192,5,33,0,0,192,193,5,6,0,0,193,194,3,2,1,0,194,195,5,21,0,0,195,
        196,3,2,1,0,196,197,5,7,0,0,197,199,1,0,0,0,198,56,1,0,0,0,198,57,
        1,0,0,0,198,59,1,0,0,0,198,60,1,0,0,0,198,61,1,0,0,0,198,65,1,0,
        0,0,198,70,1,0,0,0,198,75,1,0,0,0,198,80,1,0,0,0,198,85,1,0,0,0,
        198,90,1,0,0,0,198,95,1,0,0,0,198,100,1,0,0,0,198,105,1,0,0,0,198,
        110,1,0,0,0,198,115,1,0,0,0,198,120,1,0,0,0,198,125,1,0,0,0,198,
        132,1,0,0,0,198,137,1,0,0,0,198,142,1,0,0,0,198,147,1,0,0,0,198,
        152,1,0,0,0,198,157,1,0,0,0,198,162,1,0,0,0,198,167,1,0,0,0,198,
        172,1,0,0,0,198,177,1,0,0,0,198,182,1,0,0,0,198,191,1,0,0,0,199,
        9,1,0,0,0,200,201,7,0,0,0,201,11,1,0,0,0,202,207,3,2,1,0,203,204,
        5,21,0,0,204,206,3,2,1,0,205,203,1,0,0,0,206,209,1,0,0,0,207,205,
        1,0,0,0,207,208,1,0,0,0,208,13,1,0,0,0,209,207,1,0,0,0,7,26,28,40,
        42,53,198,207
    ]

class CalculatorParser ( Parser ):

    grammarFileName = "Calculator.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'+'", "'-'", "'*'", "'/'", "'**'", "'('",
                     "')'", "'float'", "'fix'", "'round'", "'floor'", "'ceil'",
                     "'nxtwo'", "'sin'", "'cos'", "'tan'", "'asin'", "'acos'",
                     "'atan'", "'atan2'", "','", "'deg'", "'rad'", "'abs'",
                     "'exp'", "'tento'", "'ln'", "'log10'", "'sqrt'", "'max'",
                     "'min'", "'if'", "'hamdist'", "'PV'", "'PI'", "'E'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>",
                      "<INVALID>", "<INVALID>", "PV", "PI", "E", "NUMBER",
                      "WS" ]

    RULE_start_ = 0
    RULE_sum_ = 1
    RULE_product = 2
    RULE_power = 3
    RULE_atom = 4
    RULE_constant = 5
    RULE_csv = 6

    ruleNames =  [ "start_", "sum_", "product", "power", "atom", "constant",
                   "csv" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    PV=34
    PI=35
    E=36
    NUMBER=37
    WS=38

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Start_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def EOF(self):
            return self.getToken(CalculatorParser.EOF, 0)

        def getRuleIndex(self):
            return CalculatorParser.RULE_start_

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart_" ):
                listener.enterStart_(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart_" ):
                listener.exitStart_(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart_" ):
                return visitor.visitStart_(self)
            else:
                return visitor.visitChildren(self)




    def start_(self):

        localctx = CalculatorParser.Start_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start_)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 14
            self.sum_(0)
            self.state = 15
            self.match(CalculatorParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sum_Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CalculatorParser.RULE_sum_


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class AddContext(Sum_Context):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.Sum_Context
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)

        def product(self):
            return self.getTypedRuleContext(CalculatorParser.ProductContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdd" ):
                listener.enterAdd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdd" ):
                listener.exitAdd(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdd" ):
                return visitor.visitAdd(self)
            else:
                return visitor.visitChildren(self)


    class SubContext(Sum_Context):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.Sum_Context
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)

        def product(self):
            return self.getTypedRuleContext(CalculatorParser.ProductContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSub" ):
                listener.enterSub(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSub" ):
                listener.exitSub(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSub" ):
                return visitor.visitSub(self)
            else:
                return visitor.visitChildren(self)


    class SumPassthroughContext(Sum_Context):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.Sum_Context
            super().__init__(parser)
            self.copyFrom(ctx)

        def product(self):
            return self.getTypedRuleContext(CalculatorParser.ProductContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSumPassthrough" ):
                listener.enterSumPassthrough(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSumPassthrough" ):
                listener.exitSumPassthrough(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSumPassthrough" ):
                return visitor.visitSumPassthrough(self)
            else:
                return visitor.visitChildren(self)



    def sum_(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CalculatorParser.Sum_Context(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_sum_, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = CalculatorParser.SumPassthroughContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 18
            self.product(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 28
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,1,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 26
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                    if la_ == 1:
                        localctx = CalculatorParser.AddContext(self, CalculatorParser.Sum_Context(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_sum_)
                        self.state = 20
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 21
                        self.match(CalculatorParser.T__0)
                        self.state = 22
                        self.product(0)
                        pass

                    elif la_ == 2:
                        localctx = CalculatorParser.SubContext(self, CalculatorParser.Sum_Context(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_sum_)
                        self.state = 23
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 24
                        self.match(CalculatorParser.T__1)
                        self.state = 25
                        self.product(0)
                        pass


                self.state = 30
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ProductContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CalculatorParser.RULE_product


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class DivContext(ProductContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.ProductContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def product(self):
            return self.getTypedRuleContext(CalculatorParser.ProductContext,0)

        def power(self):
            return self.getTypedRuleContext(CalculatorParser.PowerContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDiv" ):
                listener.enterDiv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDiv" ):
                listener.exitDiv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDiv" ):
                return visitor.visitDiv(self)
            else:
                return visitor.visitChildren(self)


    class MulContext(ProductContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.ProductContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def product(self):
            return self.getTypedRuleContext(CalculatorParser.ProductContext,0)

        def power(self):
            return self.getTypedRuleContext(CalculatorParser.PowerContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMul" ):
                listener.enterMul(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMul" ):
                listener.exitMul(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMul" ):
                return visitor.visitMul(self)
            else:
                return visitor.visitChildren(self)


    class ProductPassthroughContext(ProductContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.ProductContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def power(self):
            return self.getTypedRuleContext(CalculatorParser.PowerContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProductPassthrough" ):
                listener.enterProductPassthrough(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProductPassthrough" ):
                listener.exitProductPassthrough(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProductPassthrough" ):
                return visitor.visitProductPassthrough(self)
            else:
                return visitor.visitChildren(self)



    def product(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CalculatorParser.ProductContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_product, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = CalculatorParser.ProductPassthroughContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 32
            self.power(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 42
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 40
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                    if la_ == 1:
                        localctx = CalculatorParser.MulContext(self, CalculatorParser.ProductContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_product)
                        self.state = 34
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 35
                        self.match(CalculatorParser.T__2)
                        self.state = 36
                        self.power(0)
                        pass

                    elif la_ == 2:
                        localctx = CalculatorParser.DivContext(self, CalculatorParser.ProductContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_product)
                        self.state = 37
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 38
                        self.match(CalculatorParser.T__3)
                        self.state = 39
                        self.power(0)
                        pass


                self.state = 44
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class PowerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CalculatorParser.RULE_power


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class PowContext(PowerContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.PowerContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def power(self):
            return self.getTypedRuleContext(CalculatorParser.PowerContext,0)

        def atom(self):
            return self.getTypedRuleContext(CalculatorParser.AtomContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPow" ):
                listener.enterPow(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPow" ):
                listener.exitPow(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPow" ):
                return visitor.visitPow(self)
            else:
                return visitor.visitChildren(self)


    class PowerPassthroughContext(PowerContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.PowerContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def atom(self):
            return self.getTypedRuleContext(CalculatorParser.AtomContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPowerPassthrough" ):
                listener.enterPowerPassthrough(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPowerPassthrough" ):
                listener.exitPowerPassthrough(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPowerPassthrough" ):
                return visitor.visitPowerPassthrough(self)
            else:
                return visitor.visitChildren(self)



    def power(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CalculatorParser.PowerContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 6
        self.enterRecursionRule(localctx, 6, self.RULE_power, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = CalculatorParser.PowerPassthroughContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 46
            self.atom()
            self._ctx.stop = self._input.LT(-1)
            self.state = 53
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CalculatorParser.PowContext(self, CalculatorParser.PowerContext(self, _parentctx, _parentState))
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_power)
                    self.state = 48
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 49
                    self.match(CalculatorParser.T__4)
                    self.state = 50
                    self.atom()
                self.state = 55
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CalculatorParser.RULE_atom


        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TanContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTan" ):
                listener.enterTan(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTan" ):
                listener.exitTan(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTan" ):
                return visitor.visitTan(self)
            else:
                return visitor.visitChildren(self)


    class ConstantAtomContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constant(self):
            return self.getTypedRuleContext(CalculatorParser.ConstantContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstantAtom" ):
                listener.enterConstantAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstantAtom" ):
                listener.exitConstantAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantAtom" ):
                return visitor.visitConstantAtom(self)
            else:
                return visitor.visitChildren(self)


    class MaxContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def csv(self):
            return self.getTypedRuleContext(CalculatorParser.CsvContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMax" ):
                listener.enterMax(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMax" ):
                listener.exitMax(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMax" ):
                return visitor.visitMax(self)
            else:
                return visitor.visitChildren(self)


    class ParensContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParens" ):
                listener.enterParens(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParens" ):
                listener.exitParens(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParens" ):
                return visitor.visitParens(self)
            else:
                return visitor.visitChildren(self)


    class AbsContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAbs" ):
                listener.enterAbs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAbs" ):
                listener.exitAbs(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAbs" ):
                return visitor.visitAbs(self)
            else:
                return visitor.visitChildren(self)


    class NumberContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(CalculatorParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)


    class RoundContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRound" ):
                listener.enterRound(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRound" ):
                listener.exitRound(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRound" ):
                return visitor.visitRound(self)
            else:
                return visitor.visitChildren(self)


    class AtanContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtan" ):
                listener.enterAtan(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtan" ):
                listener.exitAtan(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtan" ):
                return visitor.visitAtan(self)
            else:
                return visitor.visitChildren(self)


    class FloorContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloor" ):
                listener.enterFloor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloor" ):
                listener.exitFloor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloor" ):
                return visitor.visitFloor(self)
            else:
                return visitor.visitChildren(self)


    class NxtwoContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNxtwo" ):
                listener.enterNxtwo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNxtwo" ):
                listener.exitNxtwo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNxtwo" ):
                return visitor.visitNxtwo(self)
            else:
                return visitor.visitChildren(self)


    class Log10Context(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLog10" ):
                listener.enterLog10(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLog10" ):
                listener.exitLog10(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLog10" ):
                return visitor.visitLog10(self)
            else:
                return visitor.visitChildren(self)


    class LnContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLn" ):
                listener.enterLn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLn" ):
                listener.exitLn(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLn" ):
                return visitor.visitLn(self)
            else:
                return visitor.visitChildren(self)


    class PvContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def PV(self):
            return self.getToken(CalculatorParser.PV, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPv" ):
                listener.enterPv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPv" ):
                listener.exitPv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPv" ):
                return visitor.visitPv(self)
            else:
                return visitor.visitChildren(self)


    class CosContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCos" ):
                listener.enterCos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCos" ):
                listener.exitCos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCos" ):
                return visitor.visitCos(self)
            else:
                return visitor.visitChildren(self)


    class DegContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeg" ):
                listener.enterDeg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeg" ):
                listener.exitDeg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeg" ):
                return visitor.visitDeg(self)
            else:
                return visitor.visitChildren(self)


    class SqrtContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSqrt" ):
                listener.enterSqrt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSqrt" ):
                listener.exitSqrt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSqrt" ):
                return visitor.visitSqrt(self)
            else:
                return visitor.visitChildren(self)


    class AsinContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsin" ):
                listener.enterAsin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsin" ):
                listener.exitAsin(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsin" ):
                return visitor.visitAsin(self)
            else:
                return visitor.visitChildren(self)


    class HamdistContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalculatorParser.Sum_Context)
            else:
                return self.getTypedRuleContext(CalculatorParser.Sum_Context,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHamdist" ):
                listener.enterHamdist(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHamdist" ):
                listener.exitHamdist(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitHamdist" ):
                return visitor.visitHamdist(self)
            else:
                return visitor.visitChildren(self)


    class NegContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def atom(self):
            return self.getTypedRuleContext(CalculatorParser.AtomContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNeg" ):
                listener.enterNeg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNeg" ):
                listener.exitNeg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNeg" ):
                return visitor.visitNeg(self)
            else:
                return visitor.visitChildren(self)


    class FloatContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloat" ):
                listener.enterFloat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloat" ):
                listener.exitFloat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloat" ):
                return visitor.visitFloat(self)
            else:
                return visitor.visitChildren(self)


    class MinContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def csv(self):
            return self.getTypedRuleContext(CalculatorParser.CsvContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMin" ):
                listener.enterMin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMin" ):
                listener.exitMin(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMin" ):
                return visitor.visitMin(self)
            else:
                return visitor.visitChildren(self)


    class FixContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFix" ):
                listener.enterFix(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFix" ):
                listener.exitFix(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFix" ):
                return visitor.visitFix(self)
            else:
                return visitor.visitChildren(self)


    class RadContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRad" ):
                listener.enterRad(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRad" ):
                listener.exitRad(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRad" ):
                return visitor.visitRad(self)
            else:
                return visitor.visitChildren(self)


    class TentoContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTento" ):
                listener.enterTento(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTento" ):
                listener.exitTento(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTento" ):
                return visitor.visitTento(self)
            else:
                return visitor.visitChildren(self)


    class Atan2Context(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalculatorParser.Sum_Context)
            else:
                return self.getTypedRuleContext(CalculatorParser.Sum_Context,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtan2" ):
                listener.enterAtan2(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtan2" ):
                listener.exitAtan2(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtan2" ):
                return visitor.visitAtan2(self)
            else:
                return visitor.visitChildren(self)


    class SinContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSin" ):
                listener.enterSin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSin" ):
                listener.exitSin(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSin" ):
                return visitor.visitSin(self)
            else:
                return visitor.visitChildren(self)


    class AcosContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAcos" ):
                listener.enterAcos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAcos" ):
                listener.exitAcos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAcos" ):
                return visitor.visitAcos(self)
            else:
                return visitor.visitChildren(self)


    class CeilContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCeil" ):
                listener.enterCeil(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCeil" ):
                listener.exitCeil(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCeil" ):
                return visitor.visitCeil(self)
            else:
                return visitor.visitChildren(self)


    class ExpContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self):
            return self.getTypedRuleContext(CalculatorParser.Sum_Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExp" ):
                listener.enterExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExp" ):
                listener.exitExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExp" ):
                return visitor.visitExp(self)
            else:
                return visitor.visitChildren(self)


    class IfContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalculatorParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sum_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalculatorParser.Sum_Context)
            else:
                return self.getTypedRuleContext(CalculatorParser.Sum_Context,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf" ):
                listener.enterIf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf" ):
                listener.exitIf(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIf" ):
                return visitor.visitIf(self)
            else:
                return visitor.visitChildren(self)



    def atom(self):

        localctx = CalculatorParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_atom)
        try:
            self.state = 198
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [37]:
                localctx = CalculatorParser.NumberContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 56
                self.match(CalculatorParser.NUMBER)
                pass
            elif token in [2]:
                localctx = CalculatorParser.NegContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 57
                self.match(CalculatorParser.T__1)
                self.state = 58
                self.atom()
                pass
            elif token in [34]:
                localctx = CalculatorParser.PvContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 59
                self.match(CalculatorParser.PV)
                pass
            elif token in [35, 36]:
                localctx = CalculatorParser.ConstantAtomContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 60
                self.constant()
                pass
            elif token in [6]:
                localctx = CalculatorParser.ParensContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 61
                self.match(CalculatorParser.T__5)
                self.state = 62
                self.sum_(0)
                self.state = 63
                self.match(CalculatorParser.T__6)
                pass
            elif token in [8]:
                localctx = CalculatorParser.FloatContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 65
                self.match(CalculatorParser.T__7)
                self.state = 66
                self.match(CalculatorParser.T__5)
                self.state = 67
                self.sum_(0)
                self.state = 68
                self.match(CalculatorParser.T__6)
                pass
            elif token in [9]:
                localctx = CalculatorParser.FixContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 70
                self.match(CalculatorParser.T__8)
                self.state = 71
                self.match(CalculatorParser.T__5)
                self.state = 72
                self.sum_(0)
                self.state = 73
                self.match(CalculatorParser.T__6)
                pass
            elif token in [10]:
                localctx = CalculatorParser.RoundContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 75
                self.match(CalculatorParser.T__9)
                self.state = 76
                self.match(CalculatorParser.T__5)
                self.state = 77
                self.sum_(0)
                self.state = 78
                self.match(CalculatorParser.T__6)
                pass
            elif token in [11]:
                localctx = CalculatorParser.FloorContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 80
                self.match(CalculatorParser.T__10)
                self.state = 81
                self.match(CalculatorParser.T__5)
                self.state = 82
                self.sum_(0)
                self.state = 83
                self.match(CalculatorParser.T__6)
                pass
            elif token in [12]:
                localctx = CalculatorParser.CeilContext(self, localctx)
                self.enterOuterAlt(localctx, 10)
                self.state = 85
                self.match(CalculatorParser.T__11)
                self.state = 86
                self.match(CalculatorParser.T__5)
                self.state = 87
                self.sum_(0)
                self.state = 88
                self.match(CalculatorParser.T__6)
                pass
            elif token in [13]:
                localctx = CalculatorParser.NxtwoContext(self, localctx)
                self.enterOuterAlt(localctx, 11)
                self.state = 90
                self.match(CalculatorParser.T__12)
                self.state = 91
                self.match(CalculatorParser.T__5)
                self.state = 92
                self.sum_(0)
                self.state = 93
                self.match(CalculatorParser.T__6)
                pass
            elif token in [14]:
                localctx = CalculatorParser.SinContext(self, localctx)
                self.enterOuterAlt(localctx, 12)
                self.state = 95
                self.match(CalculatorParser.T__13)
                self.state = 96
                self.match(CalculatorParser.T__5)
                self.state = 97
                self.sum_(0)
                self.state = 98
                self.match(CalculatorParser.T__6)
                pass
            elif token in [15]:
                localctx = CalculatorParser.CosContext(self, localctx)
                self.enterOuterAlt(localctx, 13)
                self.state = 100
                self.match(CalculatorParser.T__14)
                self.state = 101
                self.match(CalculatorParser.T__5)
                self.state = 102
                self.sum_(0)
                self.state = 103
                self.match(CalculatorParser.T__6)
                pass
            elif token in [16]:
                localctx = CalculatorParser.TanContext(self, localctx)
                self.enterOuterAlt(localctx, 14)
                self.state = 105
                self.match(CalculatorParser.T__15)
                self.state = 106
                self.match(CalculatorParser.T__5)
                self.state = 107
                self.sum_(0)
                self.state = 108
                self.match(CalculatorParser.T__6)
                pass
            elif token in [17]:
                localctx = CalculatorParser.AsinContext(self, localctx)
                self.enterOuterAlt(localctx, 15)
                self.state = 110
                self.match(CalculatorParser.T__16)
                self.state = 111
                self.match(CalculatorParser.T__5)
                self.state = 112
                self.sum_(0)
                self.state = 113
                self.match(CalculatorParser.T__6)
                pass
            elif token in [18]:
                localctx = CalculatorParser.AcosContext(self, localctx)
                self.enterOuterAlt(localctx, 16)
                self.state = 115
                self.match(CalculatorParser.T__17)
                self.state = 116
                self.match(CalculatorParser.T__5)
                self.state = 117
                self.sum_(0)
                self.state = 118
                self.match(CalculatorParser.T__6)
                pass
            elif token in [19]:
                localctx = CalculatorParser.AtanContext(self, localctx)
                self.enterOuterAlt(localctx, 17)
                self.state = 120
                self.match(CalculatorParser.T__18)
                self.state = 121
                self.match(CalculatorParser.T__5)
                self.state = 122
                self.sum_(0)
                self.state = 123
                self.match(CalculatorParser.T__6)
                pass
            elif token in [20]:
                localctx = CalculatorParser.Atan2Context(self, localctx)
                self.enterOuterAlt(localctx, 18)
                self.state = 125
                self.match(CalculatorParser.T__19)
                self.state = 126
                self.match(CalculatorParser.T__5)
                self.state = 127
                self.sum_(0)
                self.state = 128
                self.match(CalculatorParser.T__20)
                self.state = 129
                self.sum_(0)
                self.state = 130
                self.match(CalculatorParser.T__6)
                pass
            elif token in [22]:
                localctx = CalculatorParser.DegContext(self, localctx)
                self.enterOuterAlt(localctx, 19)
                self.state = 132
                self.match(CalculatorParser.T__21)
                self.state = 133
                self.match(CalculatorParser.T__5)
                self.state = 134
                self.sum_(0)
                self.state = 135
                self.match(CalculatorParser.T__6)
                pass
            elif token in [23]:
                localctx = CalculatorParser.RadContext(self, localctx)
                self.enterOuterAlt(localctx, 20)
                self.state = 137
                self.match(CalculatorParser.T__22)
                self.state = 138
                self.match(CalculatorParser.T__5)
                self.state = 139
                self.sum_(0)
                self.state = 140
                self.match(CalculatorParser.T__6)
                pass
            elif token in [24]:
                localctx = CalculatorParser.AbsContext(self, localctx)
                self.enterOuterAlt(localctx, 21)
                self.state = 142
                self.match(CalculatorParser.T__23)
                self.state = 143
                self.match(CalculatorParser.T__5)
                self.state = 144
                self.sum_(0)
                self.state = 145
                self.match(CalculatorParser.T__6)
                pass
            elif token in [25]:
                localctx = CalculatorParser.ExpContext(self, localctx)
                self.enterOuterAlt(localctx, 22)
                self.state = 147
                self.match(CalculatorParser.T__24)
                self.state = 148
                self.match(CalculatorParser.T__5)
                self.state = 149
                self.sum_(0)
                self.state = 150
                self.match(CalculatorParser.T__6)
                pass
            elif token in [26]:
                localctx = CalculatorParser.TentoContext(self, localctx)
                self.enterOuterAlt(localctx, 23)
                self.state = 152
                self.match(CalculatorParser.T__25)
                self.state = 153
                self.match(CalculatorParser.T__5)
                self.state = 154
                self.sum_(0)
                self.state = 155
                self.match(CalculatorParser.T__6)
                pass
            elif token in [27]:
                localctx = CalculatorParser.LnContext(self, localctx)
                self.enterOuterAlt(localctx, 24)
                self.state = 157
                self.match(CalculatorParser.T__26)
                self.state = 158
                self.match(CalculatorParser.T__5)
                self.state = 159
                self.sum_(0)
                self.state = 160
                self.match(CalculatorParser.T__6)
                pass
            elif token in [28]:
                localctx = CalculatorParser.Log10Context(self, localctx)
                self.enterOuterAlt(localctx, 25)
                self.state = 162
                self.match(CalculatorParser.T__27)
                self.state = 163
                self.match(CalculatorParser.T__5)
                self.state = 164
                self.sum_(0)
                self.state = 165
                self.match(CalculatorParser.T__6)
                pass
            elif token in [29]:
                localctx = CalculatorParser.SqrtContext(self, localctx)
                self.enterOuterAlt(localctx, 26)
                self.state = 167
                self.match(CalculatorParser.T__28)
                self.state = 168
                self.match(CalculatorParser.T__5)
                self.state = 169
                self.sum_(0)
                self.state = 170
                self.match(CalculatorParser.T__6)
                pass
            elif token in [30]:
                localctx = CalculatorParser.MaxContext(self, localctx)
                self.enterOuterAlt(localctx, 27)
                self.state = 172
                self.match(CalculatorParser.T__29)
                self.state = 173
                self.match(CalculatorParser.T__5)
                self.state = 174
                self.csv()
                self.state = 175
                self.match(CalculatorParser.T__6)
                pass
            elif token in [31]:
                localctx = CalculatorParser.MinContext(self, localctx)
                self.enterOuterAlt(localctx, 28)
                self.state = 177
                self.match(CalculatorParser.T__30)
                self.state = 178
                self.match(CalculatorParser.T__5)
                self.state = 179
                self.csv()
                self.state = 180
                self.match(CalculatorParser.T__6)
                pass
            elif token in [32]:
                localctx = CalculatorParser.IfContext(self, localctx)
                self.enterOuterAlt(localctx, 29)
                self.state = 182
                self.match(CalculatorParser.T__31)
                self.state = 183
                self.match(CalculatorParser.T__5)
                self.state = 184
                self.sum_(0)
                self.state = 185
                self.match(CalculatorParser.T__20)
                self.state = 186
                self.sum_(0)
                self.state = 187
                self.match(CalculatorParser.T__20)
                self.state = 188
                self.sum_(0)
                self.state = 189
                self.match(CalculatorParser.T__6)
                pass
            elif token in [33]:
                localctx = CalculatorParser.HamdistContext(self, localctx)
                self.enterOuterAlt(localctx, 30)
                self.state = 191
                self.match(CalculatorParser.T__32)
                self.state = 192
                self.match(CalculatorParser.T__5)
                self.state = 193
                self.sum_(0)
                self.state = 194
                self.match(CalculatorParser.T__20)
                self.state = 195
                self.sum_(0)
                self.state = 196
                self.match(CalculatorParser.T__6)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PI(self):
            return self.getToken(CalculatorParser.PI, 0)

        def E(self):
            return self.getToken(CalculatorParser.E, 0)

        def getRuleIndex(self):
            return CalculatorParser.RULE_constant

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstant" ):
                listener.enterConstant(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstant" ):
                listener.exitConstant(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstant" ):
                return visitor.visitConstant(self)
            else:
                return visitor.visitChildren(self)




    def constant(self):

        localctx = CalculatorParser.ConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_constant)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 200
            _la = self._input.LA(1)
            if not(_la==35 or _la==36):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CsvContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def sum_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalculatorParser.Sum_Context)
            else:
                return self.getTypedRuleContext(CalculatorParser.Sum_Context,i)


        def getRuleIndex(self):
            return CalculatorParser.RULE_csv

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCsv" ):
                listener.enterCsv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCsv" ):
                listener.exitCsv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCsv" ):
                return visitor.visitCsv(self)
            else:
                return visitor.visitChildren(self)




    def csv(self):

        localctx = CalculatorParser.CsvContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_csv)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.sum_(0)
            self.state = 207
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==21:
                self.state = 203
                self.match(CalculatorParser.T__20)
                self.state = 204
                self.sum_(0)
                self.state = 209
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.sum__sempred
        self._predicates[2] = self.product_sempred
        self._predicates[3] = self.power_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def sum__sempred(self, localctx:Sum_Context, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 3)


            if predIndex == 1:
                return self.precpred(self._ctx, 2)


    def product_sempred(self, localctx:ProductContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 3)


            if predIndex == 3:
                return self.precpred(self._ctx, 2)


    def power_sempred(self, localctx:PowerContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 2)
