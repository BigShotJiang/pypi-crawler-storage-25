"""ANTLR-based measurand parser.

Staged parser that splits the measurand string on `;` then delegates
parameter parsing to the ANTLR parameter parser and EUC calculator
expressions to the ANTLR calculator parser.
"""

from __future__ import annotations

from fletchr_measurand.euc import EUC
from fletchr_measurand.measurand import Measurand

from .calculator import calculator_parser
from .parameter import parameter_parser


def _find_first_semi(expr: str) -> int:
    """Find first ';' at bracket depth 0."""
    depth = 0
    for i, ch in enumerate(expr):
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        elif ch == ";" and depth == 0:
            return i
    return len(expr)


def _split_top_level(s: str, sep: str) -> list[str]:
    """Split *s* on *sep* only at parenthesis depth 0."""
    parts: list[str] = []
    depth = 0
    current: list[str] = []
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == sep and depth == 0:
            parts.append("".join(current))
            current = []
            continue
        current.append(ch)
    parts.append("".join(current))
    return parts


def _parse_euc(euc_str: str) -> EUC:
    s = euc_str.strip()
    if s.upper().startswith("EUC"):
        s = s[3:].strip()
    # Remove outer brackets
    s = s.strip("[]")
    parts = _split_top_level(s, ",")
    values = [calculator_parser.parse(p.strip()) for p in parts]

    if len(values) == 1:
        return EUC(scale_factor=values[0])
    if len(values) == 2:
        if callable(values[1]):
            raise TypeError(f"EUC scaled_bias must be a Number, got callable: {values[1]!r}")
        return EUC(scale_factor=values[0], scaled_bias=values[1])
    if len(values) == 3:
        if callable(values[0]):
            raise TypeError(f"EUC data_bias must be a Number, got callable: {values[0]!r}")
        if callable(values[2]):
            raise TypeError(f"EUC scaled_bias must be a Number, got callable: {values[2]!r}")
        return EUC(data_bias=values[0], scale_factor=values[1], scaled_bias=values[2])
    raise ValueError(f"EUC expects 1-3 expressions, got {len(values)}")


class _MeasurandParser:
    """Staged parser: splits the measurand string and delegates to sub-parsers."""

    def parse(self, expr: str) -> Measurand:
        # Find where the parameter portion ends (first ';' at depth 0)
        sep = _find_first_semi(expr)
        param_str = expr[:sep]
        rest = expr[sep:]

        parameter = parameter_parser.parse(param_str)

        encoding: str | None = None
        euc: EUC | None = None

        if rest.startswith(";"):
            parts = rest[1:].split(";")
            parts = [p.strip() for p in parts if p.strip()]
            if parts:
                encoding = parts[0]
            if len(parts) > 1:
                euc = _parse_euc(parts[1])

        return Measurand(parameter=parameter, encoding=encoding, euc=euc)


measurand_parser = _MeasurandParser()
