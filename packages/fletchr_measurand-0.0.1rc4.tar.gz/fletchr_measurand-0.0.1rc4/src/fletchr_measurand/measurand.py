from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Union

import pyarrow as pa
from byteforge import Encoding, Unsigned, create_encoding

from .result import MeasurandResult

if TYPE_CHECKING:
    from .euc import EUC, SamplingStrategy
    from .parameter import Parameter


@dataclass
class Measurand:
    parameter: Parameter
    encoding: str | Encoding | None = None
    euc: EUC | None = None
    ss: SamplingStrategy | None = None
    _encoding_cache: Encoding | None = field(default=None, init=False, repr=False)

    def _resolve_encoding(self, bit_width: int) -> Encoding:
        if self._encoding_cache is not None:
            if self._encoding_cache.bit_width != bit_width:
                raise ValueError(
                    f"encoding bit_width={self._encoding_cache.bit_width} "
                    f"does not match parameter word_size={bit_width}"
                )
            return self._encoding_cache

        if isinstance(self.encoding, Encoding):
            encoding = self.encoding
        elif isinstance(self.encoding, str):
            encoding = create_encoding(self.encoding, bit_width=bit_width)
        else:
            encoding = Unsigned(bit_width=bit_width)

        self._encoding_cache = encoding
        return encoding

    def build(self, data: pa.Table) -> MeasurandResult:
        dns = self.parameter.build(data)
        if isinstance(dns, pa.FixedSizeListArray):
            # GeneratorParameter / SupercomParameter output
            encoding = self._resolve_encoding(dns.type.value_type.bits)
        else:
            encoding = self._resolve_encoding(dns.type.bits)
        result = MeasurandResult(dns, encoding, euc=self.euc)

        if self.ss is not None:
            return self.ss.apply(result)

        return result


MeasurandSpec = Union[str, Measurand]
"""A `Measurand` or a spec string parsed by `measurand_parser`."""
