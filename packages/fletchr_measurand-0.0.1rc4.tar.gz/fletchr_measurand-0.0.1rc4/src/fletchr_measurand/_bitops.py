from __future__ import annotations

import numpy as np

ONE = np.uint8(1)


def word_size_to_machine_size(size: int) -> int:
    if size < 0:
        raise ValueError(f"word size must be non-negative, got {size}")

    if size <= 8:
        return 8
    if size <= 16:
        return 16
    if size <= 32:
        return 32
    if size <= 64:
        return 64
    raise ValueError(f"word size {size} exceeds maximum supported (64)")


def word_size_to_dtype(size: int) -> str:
    return f"u{word_size_to_machine_size(size) // 8}"


def irange(start: int, stop: int) -> list[int]:
    if start <= stop:
        return list(range(start, stop + 1))
    return list(range(start, stop - 1, -1))


def bit_list_to_ranges(bit_list: list[int]) -> list[tuple[int, int]]:
    """Converts a list of integers into a list of tuples which represent the (inclusive) ranges for that list."""
    r: list[list[int]] = []
    for bit in sorted(bit_list):
        if not r or bit - r[-1][-1] > 1:
            r.append([bit, bit])
        else:
            r[-1][1] = bit
    return [(x[0], x[1]) for x in r]


def hex2dec(val: str) -> int:
    return int(val, base=16)


def oct2dec(val: str) -> int:
    return int(val, base=8)


def bin2dec(val: str) -> int:
    return int(val, base=2)


def bit_mask(val: int) -> list[int]:
    bits = []
    i = 1

    while val > 0:
        if val % 2 == 1:
            bits.append(i)
        val = val >> 1
        i += 1

    return bits


def bits_to_mask_and_shift(bits: tuple[int, int]) -> tuple[int, int]:
    """Return `(mask, shift)` for an inclusive 1-based bit range.

    `bits = (lo, hi)` selects bit positions `lo..hi` inclusive, both
    1-based (bit 1 is the LSB). The mask has a `1` at every selected
    position; `shift` is the right-shift needed to move `lo` to the
    LSB. `lo` and `hi` may be supplied in either order.

    Examples:
        >>> bits_to_mask_and_shift((1, 3))
        (7, 0)
        >>> bits_to_mask_and_shift((3, 3))
        (4, 2)
        >>> bits_to_mask_and_shift((5, 8))
        (240, 4)
    """
    lo, hi = min(bits), max(bits)
    mask = 0
    for bit in range(lo - 1, hi):
        mask += 2**bit
    shift = lo - 1
    return mask, shift
