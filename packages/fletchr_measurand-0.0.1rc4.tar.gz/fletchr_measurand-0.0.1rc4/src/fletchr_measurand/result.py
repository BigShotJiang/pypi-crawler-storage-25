"""`MeasurandResult` — the product of evaluating a `Measurand`.

A single value type that carries the full chain — raw DN bit patterns,
Level-1 decoded values, and Level-2 scaled values — exposed as lazy,
cached properties. Arrow-backed throughout: dns is either a 1-D
`UIntNArray` or a 2-D `pa.FixedSizeListArray<UIntN>`, and `.decoded`
preserves the input validity bitmap through both decode levels.

Users wanting the physical-unit values read `.values` (or
`np.asarray(result)`); users doing bit-pattern analysis read `.dns`;
users wanting Level-1 numbers without EUC scaling read `.decoded`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Union

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc
from byteforge import IEEE754, Encoding, TwosComplement, Unsigned

from fletchr_uintn import UIntNType

if TYPE_CHECKING:
    from .euc import EUC


_MACHINE_SIZES = frozenset({8, 16, 32, 64})


def _decode_strategy(encoding: Encoding) -> tuple[str, str | None]:
    """Pick the optimal numpy decode strategy for an encoding.

    Returns `(strategy, view_dtype)` where strategy is one of
    `"view"`, `"identity"`, or `"compute"`; `view_dtype` is the numpy
    dtype string for view-based decoding (else `None`).
    """
    if isinstance(encoding, IEEE754):
        nbytes = encoding.bit_width // 8
        return ("view", f"f{nbytes}")
    if isinstance(encoding, TwosComplement) and encoding.bit_width in _MACHINE_SIZES:
        nbytes = encoding.bit_width // 8
        return ("view", f"i{nbytes}")
    if isinstance(encoding, Unsigned):
        return ("identity", None)
    return ("compute", None)


def _decode_numpy(
    dns_np: np.ndarray, encoding: Encoding, strategy: str, view_dtype: str | None
) -> np.ndarray:
    """Apply the strategy to a raw numpy dn buffer."""
    if strategy == "view":
        assert view_dtype is not None
        return dns_np.view(view_dtype)
    if strategy == "identity":
        return dns_np
    return encoding.decode(dns_np)


def _split_arrow_storage(
    dns: pa.ExtensionArray,
) -> tuple[np.ndarray, np.ndarray | None]:
    """Return `(storage_values, valid_mask)` for an Arrow dns.

    `valid_mask` is `None` when there are no nulls; otherwise it is a
    bool array where `True` marks valid positions. Null positions in
    `storage_values` are filled with `0` so they are safe to view/decode.
    """
    storage = dns.storage
    if storage.null_count == 0:
        return storage.to_numpy(zero_copy_only=False), None
    filled = pc.fill_null(storage, 0)
    valid_mask = storage.is_valid().to_numpy(zero_copy_only=False)
    return filled.to_numpy(zero_copy_only=False), valid_mask


DnsType = Union[pa.ExtensionArray, pa.FixedSizeListArray]
ArrayType = Union[pa.Array, pa.FixedSizeListArray]


class MeasurandResult:
    """Lazy carrier of the three values a `Measurand` produces.

    `.dns` — raw bit patterns (`UIntNArray` or `FixedSizeListArray<UIntN>`).
    `.decoded` — Level-1 numeric values (encoding applied).
    `.values` — Level-2 scaled values (EUC applied if present; same as
        `.decoded` otherwise).

    Arrow-backed throughout. The validity bitmap on the input dns
    propagates through both decode levels: nulls in raw bits stay as
    nulls in the decoded `pa.Array`.

    `np.asarray(result)` returns `.values` as a numpy array — the
    common idiom for callers that just want the final numbers.
    """

    __slots__ = (
        "_decoded_cache",
        "_dns",
        "_encoding",
        "_euc",
        "_is_2d",
        "_list_size",
        "_strategy",
        "_values_cache",
        "_view_dtype",
    )

    def __init__(
        self,
        dns: DnsType,
        encoding: Encoding,
        euc: EUC | None = None,
    ) -> None:
        if isinstance(dns, pa.FixedSizeListArray):
            # 2-D path: per-row list of UIntN values (Generator/Supercom output).
            if not isinstance(dns.type.value_type, UIntNType):
                raise TypeError(
                    "FixedSizeListArray dns must have UIntNType values, "
                    f"got value_type={dns.type.value_type!r}"
                )
            self._is_2d = True
            self._list_size = dns.type.list_size
            dns_bits = dns.type.value_type.bits
        elif isinstance(dns, pa.ExtensionArray) and isinstance(dns.type, UIntNType):
            self._is_2d = False
            self._list_size = 0
            dns_bits = dns.type.bits
        else:
            raise TypeError(
                f"dns must be a UIntNArray or FixedSizeListArray<UIntN>, got {type(dns).__name__}"
            )
        if not isinstance(encoding, Encoding):
            raise TypeError(f"encoding must be an Encoding, got {type(encoding).__name__}")
        if dns_bits != encoding.bit_width:
            raise ValueError(
                f"dns bit width ({dns_bits}) does not match encoding.bit_width "
                f"({encoding.bit_width})"
            )

        self._dns = dns
        self._encoding = encoding
        self._euc = euc
        self._strategy, self._view_dtype = _decode_strategy(encoding)
        self._decoded_cache: ArrayType | None = None
        self._values_cache: ArrayType | None = None

    # --- raw views ---

    @property
    def dns(self) -> DnsType:
        """Raw DN bit patterns (input-typed)."""
        return self._dns

    @property
    def encoding(self) -> Encoding:
        return self._encoding

    @property
    def euc(self) -> EUC | None:
        return self._euc

    @property
    def word_size(self) -> int:
        return self._encoding.bit_width

    # --- decoded (Level 1) ---

    @property
    def decoded(self) -> ArrayType:
        """Level-1 decoded values (encoding applied, no EUC)."""
        if self._decoded_cache is None:
            self._decoded_cache = self._compute_decoded()
        return self._decoded_cache

    def _compute_decoded(self) -> ArrayType:
        if self._is_2d:
            # FixedSizeListArray: decode the flat inner values, re-wrap.
            inner = self._dns.values  # ExtensionArray<UIntN>
            storage_vals, valid_mask = _split_arrow_storage(inner)
            decoded = _decode_numpy(storage_vals, self._encoding, self._strategy, self._view_dtype)
            mask = ~valid_mask if valid_mask is not None else None
            decoded_flat = pa.array(decoded, mask=mask)
            return pa.FixedSizeListArray.from_arrays(decoded_flat, self._list_size)
        storage_vals, valid_mask = _split_arrow_storage(self._dns)
        decoded = _decode_numpy(storage_vals, self._encoding, self._strategy, self._view_dtype)
        mask = ~valid_mask if valid_mask is not None else None
        return pa.array(decoded, mask=mask)

    # --- values (Level 2) ---

    @property
    def values(self) -> ArrayType:
        """Level-2 scaled values (EUC applied if present, else identical to `.decoded`)."""
        if self._values_cache is None:
            self._values_cache = self._compute_values()
        return self._values_cache

    def _compute_values(self) -> ArrayType:
        if self._euc is None:
            return self.decoded
        decoded = self.decoded
        if self._is_2d:
            # FixedSizeList: apply EUC to the flat inner values and re-wrap.
            inner = decoded.values
            if inner.null_count == 0:
                scaled = self._euc.apply(np.asarray(inner))
                return pa.FixedSizeListArray.from_arrays(pa.array(scaled), self._list_size)
            valid_mask = inner.is_valid().to_numpy(zero_copy_only=False)
            filled = pc.fill_null(inner, 0).to_numpy(zero_copy_only=False)
            scaled = self._euc.apply(filled)
            return pa.FixedSizeListArray.from_arrays(
                pa.array(scaled, mask=~valid_mask), self._list_size
            )
        assert isinstance(decoded, pa.Array)
        if decoded.null_count == 0:
            return pa.array(self._euc.apply(np.asarray(decoded)))
        valid_mask = decoded.is_valid().to_numpy(zero_copy_only=False)
        filled = pc.fill_null(decoded, 0).to_numpy(zero_copy_only=False)
        scaled = self._euc.apply(filled)
        return pa.array(scaled, mask=~valid_mask)

    # --- numpy interop ---

    def __array__(self, dtype: Any = None, copy: Any = None) -> np.ndarray:
        vals = self.values
        if self._is_2d:
            # Reshape flat values → (n_rows, list_size). pa.FixedSizeList.to_numpy
            # default behavior returns an object array of lists; flatten manually
            # to preserve dtype.
            inner = vals.values.to_numpy(zero_copy_only=False)
            arr = inner.reshape(len(self._dns), self._list_size)
        else:
            arr = vals.to_numpy(zero_copy_only=False)
        if dtype is not None:
            arr = arr.astype(dtype, copy=False)
        return arr

    # --- size / repr / indexing ---

    def __len__(self) -> int:
        return len(self._dns)

    def __getitem__(self, key: Any) -> Any:
        if isinstance(key, (int, np.integer)):
            return self.values[int(key)].as_py()
        if isinstance(key, slice):
            return MeasurandResult(self._dns[key], self._encoding, euc=self._euc)
        raise TypeError(f"MeasurandResult indexing requires int or slice, got {type(key).__name__}")

    def __repr__(self) -> str:
        parts = [repr(self.values), f"encoding={self._encoding!r}"]
        if self._euc is not None:
            parts.append(f"euc={self._euc!r}")
        return f"MeasurandResult({', '.join(parts)})"
