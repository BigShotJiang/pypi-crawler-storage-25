from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Union

import numpy as np

Number = Union[int, float]


@dataclass
class EUC:
    scale_factor: Number | Callable
    data_bias: Number | None = None
    scaled_bias: Number | None = None

    def __post_init__(self) -> None:
        if callable(self.scale_factor):
            self.scale_factor = np.vectorize(self.scale_factor)

    def apply(self, data: np.ndarray) -> np.ndarray:
        result = data

        if self.data_bias is not None:
            result = result - self.data_bias

        result = (
            self.scale_factor(result) if callable(self.scale_factor) else result * self.scale_factor
        )

        if self.scaled_bias is not None:
            result = result + self.scaled_bias

        return result


@dataclass
class SamplingStrategy:
    def apply(self, data: Any) -> Any: ...
