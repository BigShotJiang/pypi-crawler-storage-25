from pandas.util import hash_pandas_object
import hashlib


def find_duplicate_columns(df):

    seen = {}
    duplicates = []

    for col in df.columns:

        col_hash = hashlib.md5(
            hash_pandas_object(
                df[col],
                index=False
            ).values
        ).hexdigest()

        if col_hash in seen:

            original_col = seen[col_hash]

            # Verify actual equality
            if df[col].equals(df[original_col]):
                duplicates.append(col)

        else:
            seen[col_hash] = col

    return duplicates


def drop_duplicate_columns(df):

    duplicates = find_duplicate_columns(df)

    return df.drop(columns=duplicates)