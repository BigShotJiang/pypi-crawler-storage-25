"""ReAct agent loop — the brain of pw-agent."""

import json
import os
import re
import random
import subprocess
from typing import Optional
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from llm_client import LLMClient
from tools import TOOL_DEFINITIONS, execute_tool
from config import save_session


THINKING_MESSAGES = [
    "Boiling pasta water...",
    "Al dente thinking...",
    "Cooking up a response...",
    "Draining the spaghetti...",
    "Simmering...",
    "Adding seasoning...",
    "Tasting the sauce...",
    "Rolling the dough...",
    "GPU goes brrrr...",
    "Consulting the recipe...",
    "Too much salt, spitting...",
    "Stirring the pot...",
    "Checking the timer...",
    "Plating the dish...",
    "Checking if the pasta is al dente...",
    "Straining the context...",
    "Perfecting the prompt sauce...",
]


MAX_ITERATIONS = 100  # High ceiling — loop detection handles runaway agents
MAX_DUPLICATE_CALLS = 2  # Stop if same tool+args called this many times
MAX_STALLS = 3  # Stop if model produces no-tool response this many times in a row
# ~4 chars per token is a reasonable estimate for most models
CHARS_PER_TOKEN = 4

# ─── Supported PastaWater Ollama models and their context limits ──────────
# These are the exact models available on the GPU Setup page.
# Context limits are the model's native max, but we apply a safe budget
# based on available VRAM to prevent OOM.
SUPPORTED_MODELS = {
    # Measured VRAM values from actual Ollama loading on RTX 4090
    # ─── Coding Models ───
    "qwen2.5-coder:32b":     {"native": 32768,  "safe": 8192,  "name": "Qwen 2.5 Coder 32B",  "vram_gb": 31, "tier": "premium"},
    "qwen3-coder:30b":       {"native": 262144, "safe": 16384, "name": "Qwen 3 Coder 30B",    "vram_gb": 22, "tier": "premium"},
    "deepseek-coder-v2:16b": {"native": 163840, "safe": 12288, "name": "DeepSeek Coder V2",   "vram_gb": 19, "tier": "good"},
    # ─── Creative Models ───
    "qwen3.5:27b":       {"native": 32768, "safe": 8192,  "name": "Qwen 3.5 27B",  "vram_gb": 24, "tier": "premium"},
    "qwen3.5:9b":        {"native": 32768, "safe": 12288, "name": "Qwen 3.5 9B",   "vram_gb": 12, "tier": "good"},
    "qwen3.5:4b":        {"native": 32768, "safe": 16384, "name": "Qwen 3.5 4B",   "vram_gb": 7.2, "tier": "basic"},
    # ─── General Models ───
    "qwen2.5:14b":       {"native": 32768, "safe": 8192,  "name": "Qwen 2.5 14B",  "vram_gb": 17, "tier": "good"},
    "qwen3.5:2b":        {"native": 32768, "safe": 16384, "name": "Qwen 3.5 2B",   "vram_gb": 4.9, "tier": "basic"},
}
# Models below this tier get a warning on startup
MIN_RECOMMENDED_TIER = "good"
# Fallback for unknown models
DEFAULT_SAFE_CONTEXT = 4096

# Reserve tokens for the model's response
RESPONSE_RESERVE = 2048


def get_model_warning(model_name: str) -> str | None:
    """Return a warning string if the model is below recommended tier for coding."""
    model_lower = model_name.lower().strip()
    info = SUPPORTED_MODELS.get(model_lower)
    if not info:
        # Check prefix match
        for model_id, m in SUPPORTED_MODELS.items():
            if model_lower.startswith(model_id.split(":")[0]):
                info = m
                break
    if not info:
        return None
    tier = info.get("tier", "good")
    if tier == "basic":
        return f"⚠ {info['name']} — limited context and accuracy. For code editing, use 9b or larger."
    return None

console = Console()


SYSTEM_PROMPT = """You are PW Agent — an autonomous coding agent with FULL read/write access to the user's local filesystem and shell.
You are NOT a restricted chatbot. You are a professional software engineer tool.
You CAN and SHOULD read, edit, create, and delete files. You CAN run any bash command.
You do NOT ask for permission to use tools. You execute them to fulfill the user's request.
{mode_instruction}

Model: {model_name} | {gpu_info} | {connection_mode}
Working directory: {cwd}
{git_context}

{project_context}

## Your tools:
{tool_list}

## How to use tools
When you need to use a tool, wrap the call in <tool_call> tags.
You MUST write the JSON exactly as defined in the tool list.
Only ONE tool call per response.

<tool_call>
{{"tool": "read_file", "args": {{"path": "main.py"}}}}
</tool_call>

<tool_call>
{{"tool": "bash", "args": {{"command": "npm test"}}}}
</tool_call>

After writing a <tool_call> block, STOP. The environment will execute it and provide the result.

## Core Rules
1. **Act, don't narrate.** Don't say "I will now read the file". Just use the tool.
2. **One step at a time.** Execute one tool, wait for result, then decide next step.
3. **Always read before editing.** Never guess file content.
4. **Be direct.** If asked to fix a bug, find it, fix it, and verify it.
5. **No "I can't".** You have the tools. If a task is possible via CLI or file edits, you can do it.

For casual chat or final summaries, respond normally without <tool_call>.
"""


def _build_tool_list(plan_mode: bool = False) -> str:
    """Format tool definitions for the system prompt."""
    lines = []
    # Destructive tools to hide in Plan mode
    DESTRUCTIVE = ["write_file", "edit_file", "delete_file"]
    
    for tool in TOOL_DEFINITIONS:
        if plan_mode and tool["name"] in DESTRUCTIVE:
            continue
            
        params = ", ".join(
            f"{k}: {v['type']}" for k, v in tool["parameters"].items()
        )
        lines.append(f"- {tool['name']}({params}) — {tool['description']}")
    return "\n".join(lines)


def _get_git_context() -> str:
    """Gather git status for the system prompt."""
    parts = []
    try:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True, text=True, timeout=5
        )
        if branch.returncode == 0 and branch.stdout.strip():
            parts.append(f"Git branch: {branch.stdout.strip()}")

        status = subprocess.run(
            ["git", "status", "--short"],
            capture_output=True, text=True, timeout=5
        )
        if status.returncode == 0 and status.stdout.strip():
            changed = len(status.stdout.strip().split("\n"))
            parts.append(f"Git status: {changed} changed files")

        log = subprocess.run(
            ["git", "log", "--oneline", "-5"],
            capture_output=True, text=True, timeout=5
        )
        if log.returncode == 0 and log.stdout.strip():
            parts.append(f"Recent commits:\n{log.stdout.strip()}")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return "\n".join(parts) if parts else "Not a git repository"


def _get_project_context(cwd: str) -> str:
    """Find PW_AGENT.md in cwd or parent directories for project-specific instructions."""
    curr = os.path.abspath(cwd)
    while True:
        # Check for PW_AGENT.md or .gemini/PW_AGENT.md
        for name in ["PW_AGENT.md", ".gemini/PW_AGENT.md"]:
            path = os.path.join(curr, name)
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                    if content:
                        return f"## Project Context ({name}):\n{content}"
                except Exception:
                    pass
        
        parent = os.path.dirname(curr)
        if parent == curr:
            break
        curr = parent
    return ""


def _build_messages(conversation: list[dict], cwd: str, client=None, plan_mode: bool = False) -> list[dict]:
    """Build Ollama chat messages from conversation history."""
    git_ctx = _get_git_context()
    proj_ctx = _get_project_context(cwd)

    # Model/GPU context
    model_name = client.model if client else "unknown"
    if client and client.direct_mode:
        connection_mode = f"Local brain ({client.brain_url}) — direct, no cloud"
        gpu_info = "local GPU (direct connection)"
    elif client:
        gpu_info = f"remote GPU via PastaWater cloud (slot {client.slot})"
        connection_mode = "PastaWater Cloud — routed through broker API"
    else:
        gpu_info = "unknown"
        connection_mode = "unknown"

    mode_instr = ""
    if plan_mode:
        mode_instr = "\n**PLAN MODE**: You are in read-only analysis mode. You cannot modify files or run destructive commands. Focus on understanding and proposing changes."

    system = SYSTEM_PROMPT.format(
        cwd=cwd,
        git_context=git_ctx,
        project_context=proj_ctx,
        mode_instruction=mode_instr,
        tool_list=_build_tool_list(plan_mode),
        model_name=model_name,
        gpu_info=gpu_info,
        connection_mode=connection_mode,
    )

    # Some models (DeepSeek, Qwen) ignore 'system' role or prioritize pre-training.
    # We'll merge it into user messages for those.
    m_lower = model_name.lower()
    inject_context = "deepseek" in m_lower or "qwen" in m_lower

    if not inject_context:
        messages = [{"role": "system", "content": system}]
    else:
        messages = []

    # Concise environment summary for recurring injection
    env_summary = f"[Environment: {cwd} | {git_ctx.splitlines()[0] if git_ctx else 'no git'}]"

    first_user_processed = False
    for msg in conversation:
        role = msg["role"]
        content = msg["content"]
        if role == "user":
            if inject_context:
                if not first_user_processed:
                    # Inject full system prompt into FIRST user message
                    messages.append({"role": "user", "content": f"{system}\n\nUser request: {content}"})
                    first_user_processed = True
                else:
                    # Inject concise environment summary into subsequent user messages
                    messages.append({"role": "user", "content": f"{env_summary}\n{content}"})
            else:
                messages.append({"role": "user", "content": content})
        elif role == "assistant":
            messages.append({"role": "assistant", "content": content})
        elif role == "tool_result":
            # For tool results, also inject the environment summary if needed
            ctx_prefix = f"{env_summary}\n" if inject_context else ""
            messages.append({"role": "user", "content": f"{ctx_prefix}{content}"})

    # Fallback if no user messages yet
    if not messages and inject_context:
        messages.append({"role": "user", "content": system})

    return messages


def _parse_tool_call(response: str) -> Optional[tuple[dict, str]]:
    """Extract a tool call from the model's response.

    Handles:
    - <tool_call>{"tool": "...", "args": {...}}</tool_call>
    - ACTION: {"tool": "...", "args": {...}}
    - CMD: tool args (fallback)
    - Raw JSON blocks
    """
    # Pattern 1: <tool_call> JSON [</tool_call>]
    tc_match = re.search(r'<tool_call>([\s\S]*?)(?:</tool_call>|$)', response, re.DOTALL)
    if tc_match:
        raw_json = tc_match.group(1).strip()
        raw_json = re.sub(r'^```(?:json)?\s*', '', raw_json)
        raw_json = re.sub(r'\s*```$', '', raw_json)
        try:
            call = json.loads(raw_json)
            if "tool" in call and "args" in call:
                return call, response[:tc_match.start()].strip()
        except json.JSONDecodeError:
            pass

    # Pattern 2: DeepSeek/Native tool calling format
    native_match = re.search(r'tool[\s\S]*?sep[\s\S]*?(\w+)[\s\S]*?```json\s*([\s\S]*?)\s*```', response, re.IGNORECASE)
    if native_match:
        tool_name = native_match.group(1).strip()
        args_json = native_match.group(2).strip()
        try:
            if "\n{" in args_json: args_json = args_json.split("\n{")[0]
            args = json.loads(args_json)
            before = re.sub(r'<[^>]*tool[^>]*>', '', response[:native_match.start()]).strip()
            return {"tool": tool_name, "args": args}, before
        except json.JSONDecodeError:
            pass

    # Pattern 3: Greedy JSON search (order-agnostic)
    # Improved to handle nested braces by finding the last closing brace in the string
    for pattern in [r'(\{[\s\S]*?"tool"[\s\S]*?"args"[\s\S]*?)', r'(\{[\s\S]*?"args"[\s\S]*?"tool"[\s\S]*?)']:
        json_match = re.search(pattern, response)
        if json_match:
            start_index = json_match.start()
            # Try to find the matching closing brace by looking from the end of the string
            # This is a heuristic: we take the longest possible valid JSON starting at our match
            for end_index in range(len(response), start_index, -1):
                raw_json = response[start_index:end_index].strip()
                if not raw_json.endswith("}"):
                    continue
                
                # Cleanly strip possible trailing markdown/ChatML tokens before trying to parse
                clean_json = re.sub(r'<\|.*?\|>', '', raw_json).strip()
                try:
                    call = json.loads(clean_json)
                    if "tool" in call and "args" in call:
                        before = re.sub(r'<\|.*?\|>', '', response[:start_index]).strip()
                        return call, before
                except json.JSONDecodeError:
                    continue

    # Pattern 4: CMD: tool args (fallback for simple models)
    cmd_match = re.search(r'(?:\*\*)?CMD(?:\*\*)?[:\s]+(\w+)\s*(.*?)$', response, re.MULTILINE)
    if cmd_match:
        tool = cmd_match.group(1).strip()
        args_str = cmd_match.group(2).strip()
        before = response[:cmd_match.start()].strip()
        if tool == "bash": return {"tool": "bash", "args": {"command": args_str}}, before
        if tool == "read_file": return {"tool": "read_file", "args": {"path": args_str}}, before
        if tool == "list_files": return {"tool": "list_files", "args": {"pattern": args_str or "*"}}, before

    # Pattern 5: ACTION: {...} (legacy support)
    match = re.search(r"ACTION:\s*(\{.*?\})\s*$", response, re.MULTILINE | re.DOTALL)
    if not match:
        match = re.search(r'ACTION:\s*(\{[^}]*"tool"[^}]*"args"[^}]*\{[^}]*\}[^}]*\})', response, re.DOTALL)
    if match:
        try:
            call = json.loads(match.group(1))
            if "tool" in call and "args" in call:
                return call, response[:match.start()].strip()
        except json.JSONDecodeError:
            pass

    return None


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token)."""
    return len(text) // CHARS_PER_TOKEN + 1


def _get_context_budget(model_name: str) -> int:
    """Get the safe input token budget for a model.

    Uses the 'safe' context limit (conservative for VRAM) minus response reserve.
    Larger models use more VRAM per token, so their safe limit is lower than native.
    """
    model_lower = model_name.lower().strip()
    # Exact match first
    if model_lower in SUPPORTED_MODELS:
        return SUPPORTED_MODELS[model_lower]["safe"] - RESPONSE_RESERVE
    # Prefix match (e.g. "qwen3.5" matches "qwen3.5:4b")
    for model_id, info in SUPPORTED_MODELS.items():
        base = model_id.split(":")[0]
        if model_lower.startswith(base):
            return info["safe"] - RESPONSE_RESERVE
    return DEFAULT_SAFE_CONTEXT - RESPONSE_RESERVE


def _compact_old_messages(old_messages: list[dict]) -> str:
    """Summarize old tool calls and results into a compact context string."""
    files_read = []
    commands_run = []
    key_findings = []

    for msg in old_messages:
        content = msg.get("content", "")
        if "Used read_file" in content or "Used list_files" in content or "Used grep" in content:
            continue  # Skip action markers
        if content.startswith("RESULT of read_file:"):
            # Extract just the filename
            pass
        elif content.startswith("RESULT of list_files:"):
            files = content.split("\n")[1:6]  # First 5 files
            files_read.extend(f.strip() for f in files if f.strip())
        elif content.startswith("RESULT of bash:"):
            cmd_output = content[15:100].strip()
            commands_run.append(cmd_output)
        elif content.startswith("RESULT of"):
            continue
        elif msg["role"] == "assistant" and len(content) > 20:
            # Keep short assistant summaries
            key_findings.append(content[:150])

    parts = ["[Compacted context from earlier in conversation]"]
    if files_read:
        parts.append(f"Files seen: {', '.join(files_read[:10])}")
    if commands_run:
        parts.append(f"Commands run: {'; '.join(commands_run[:5])}")
    if key_findings:
        parts.append(f"Key findings: {'; '.join(key_findings[:3])}")

    return "\n".join(parts) if len(parts) > 1 else parts[0]


def _truncate_history(conversation: list[dict], model: str = "default") -> list[dict]:
    """Smart context management: compact old messages, keep recent ones.

    When context exceeds budget:
    1. Keep the first user message (original task)
    2. Compact old tool calls into a summary
    3. Keep the most recent messages in full
    """
    if len(conversation) <= 3:
        return conversation

    budget = _get_context_budget(model)
    total_tokens = sum(_estimate_tokens(m["content"]) for m in conversation)

    if total_tokens <= budget:
        return conversation

    # Always keep the first message
    first = conversation[0]
    first_tokens = _estimate_tokens(first["content"])
    remaining_budget = budget - first_tokens

    # Walk backwards from the end, keeping recent messages
    remaining = conversation[1:]
    kept = []
    used = 0
    for msg in reversed(remaining):
        msg_tokens = _estimate_tokens(msg["content"])
        if used + msg_tokens > remaining_budget:
            break
        kept.insert(0, msg)
        used += msg_tokens

    dropped = remaining[:len(remaining) - len(kept)]
    result = [first]
    if dropped:
        # Compact the dropped messages into a summary
        summary = _compact_old_messages(dropped)
        result.append({"role": "tool_result", "content": summary})
    result.extend(kept)
    return result


class Agent:
    """ReAct agent that uses an LLM to perform coding tasks."""

    def __init__(self, client: LLMClient, stream: bool = True, status_text: str = "", plan_mode: bool = False):
        self.client = client
        self.stream = stream
        self.conversation: list[dict] = []
        self.cwd = os.getcwd()
        self.status_text = status_text  # Bottom bar text to show during generation
        self.files_in_context: list[str] = []
        self.interrupted = False
        self.plan_mode = plan_mode

    def run(self, user_input: str) -> None:
        """Process a user message through the ReAct loop with loop detection."""
        self.conversation.append({"role": "user", "content": user_input})

        # Loop detection state
        tool_call_log: list[str] = []  # Track "tool:args" signatures
        stall_count = 0  # Count consecutive non-tool responses

        self.interrupted = False

        for iteration in range(MAX_ITERATIONS):
            if self.interrupted:
                console.print("\n  [yellow]⚠ Interrupted[/yellow]")
                self._auto_save()
                return

            trimmed = _truncate_history(self.conversation, self.client.model)
            messages = _build_messages(trimmed, self.cwd, self.client, self.plan_mode)

            # Get response (streaming or not)
            thinking_msg = random.choice(THINKING_MESSAGES)
            if self.stream:
                response = self._stream_response(messages, thinking_msg)
            else:
                with console.status(f"[cyan]{thinking_msg}", spinner="dots"):
                    response = self.client.chat(messages)

            if not response or response.startswith("[Error:"):
                # Debug: show what was sent
                if os.environ.get("PW_DEBUG"):
                    console.print(f"  [dim]DEBUG: sent {len(messages)} messages, got: {repr(response[:200])}[/dim]")
                console.print(f"  [red]{response or '[Empty response from model]'}[/red]")
                return

            # Check for tool call
            parsed = _parse_tool_call(response)

            if not parsed and self.stream:
                # If we were streaming and it looked like a tool (so it was suppressed)
                # but we failed to parse it, we must show it now
                if "<tool_call>" in response or "<｜tool" in response or "{" in response or "<|im_start|>" in response:
                     console.print(f"\n[dim]────── (Unparsed output) ──────[/dim]\n{response}\n")

            if parsed:
                tool_call, thinking = parsed
                tool_name = tool_call["tool"]
                tool_args = tool_call["args"]
                stall_count = 0  # Reset stall counter — model is making progress
                
                # ... (rest of tool execution logic)

                # Loop detection — check for duplicate tool calls
                call_sig = f"{tool_name}:{json.dumps(tool_args, sort_keys=True)}"
                dup_count = tool_call_log.count(call_sig)
                tool_call_log.append(call_sig)

                if dup_count >= MAX_DUPLICATE_CALLS:
                    console.print(f"\n  [yellow]⚠ Detected loop: {tool_name} called {dup_count + 1} times with same args. Moving on.[/yellow]")
                    self.conversation.append({"role": "user", "content": "You already did this exact tool call. Please move on to the next step or give your final answer."})
                    continue

                # Print thinking text — compact, one line
                if thinking:
                    short = thinking.split("\n")[0][:100].strip()
                    if short:
                        console.print(f"\n  [dim]{short}[/dim]")

                # Tool call — bold and visible with icon
                TOOL_ICONS = {
                    "read_file": "📄", "write_file": "✏️", "edit_file": "🔧",
                    "bash": "💻", "list_files": "📁", "grep": "🔍",
                }
                icon = TOOL_ICONS.get(tool_name, "⚡")
                args_display = []
                for k, v in tool_args.items():
                    if isinstance(v, str) and len(v) > 60:
                        args_display.append(f'{k}="...{len(v)} chars..."')
                    else:
                        args_display.append(f'{k}="{v}"' if isinstance(v, str) else f'{k}={v}')
                args_str = ", ".join(args_display)
                console.print(f"\n  {icon} [bold cyan]{tool_name}[/bold cyan]({args_str})")

                # Execute tool
                result = execute_tool(tool_name, tool_args)

                # Print result summary — compact but informative
                lines = result.split("\n")
                if tool_name == "read_file":
                    console.print(f"  [dim]   ↳ {len(lines)} lines read[/dim]")
                elif tool_name in ("list_files", "grep"):
                    count = min(len(lines), 10)
                    for line in lines[:count]:
                        console.print(f"  [dim]   {line}[/dim]")
                    if len(lines) > count:
                        console.print(f"  [dim]   ... and {len(lines) - count} more[/dim]")
                elif tool_name == "bash":
                    display = result[:300]
                    if len(result) > 300:
                        display += "..."
                    console.print(f"  [dim]   ↳ {display}[/dim]")
                elif tool_name in ("write_file", "edit_file"):
                    console.print(f"  [green]   ↳ {result}[/green]")
                else:
                    display = result[:200] + "..." if len(result) > 200 else result
                    console.print(f"  [dim]   ↳ {display}[/dim]")

                # Add to conversation — truncate large results to save context
                truncated_result = result[:1000] + f"\n...[truncated]" if len(result) > 1000 else result
                # Store <tool_call> format in history so model learns the pattern
                tc_str = json.dumps({"tool": tool_name, "args": tool_args})
                self.conversation.append({"role": "assistant", "content": f"<tool_call>\n{tc_str}\n</tool_call>"})
                self.conversation.append({"role": "tool_result", "content": f"Result:\n{truncated_result}"})

            else:
                stall_count += 1
                response_lower = response.lower()

                # Detect hallucination — model makes specific claims about THIS project
                # without having used any tools. Only trigger on definitive statements
                # about the project's state, not general capability descriptions.
                hallucination_signs = [
                    "the main branch", "the master branch", "no main branch",
                    "i checked the", "i can see that", "i found that",
                    "this project has", "this repo has", "this codebase",
                    "there is no branch", "there are no files",
                    "the project contains", "the code shows",
                ]
                is_hallucinating = (
                    len(tool_call_log) == 0 and
                    any(w in response_lower for w in hallucination_signs) and
                    stall_count <= MAX_STALLS
                )

                # Detect narration without action
                narration_words = ["let me check", "i'll read", "i'll look", "let me look",
                                   "i'll start by", "let me start", "i'll explore", "let me explore",
                                   "let me fix", "i'll fix", "let me try", "i'll try"]
                is_narrating = any(w in response_lower for w in narration_words) and stall_count <= MAX_STALLS

                if is_hallucinating:
                    console.print("\n  [dim]↳ Hallucination detected, prompting for verification...[/dim]")
                    self.conversation.append({"role": "assistant", "content": response})
                    self.conversation.append({"role": "user", "content": "You have NOT checked. Use a tool to verify. Example: <tool_call>{\"tool\": \"bash\", \"args\": {\"command\": \"ls\"}}</tool_call>"})
                    continue
                elif is_narrating:
                    console.print("\n  [dim]↳ Narrating without action, prompting for tool use...[/dim]")
                    self.conversation.append({"role": "assistant", "content": response})
                    self.conversation.append({"role": "user", "content": "Use a tool now. Don't narrate — act."})
                    continue

                if stall_count > MAX_STALLS and iteration > 0:
                    console.print(f"\n  [yellow]⚠ Model stalled ({stall_count} non-tool responses). Treating as final answer.[/yellow]")

                # Final answer
                self.conversation.append({"role": "assistant", "content": response})
                if not self.stream:
                    console.print("\n  [dim]──────[/dim]\n")
                    console.print(f"[#afafff]{response}[/#afafff]")
                    console.print()
                self._auto_save()
                return

        console.print(f"\n  [yellow]⚠ Reached {MAX_ITERATIONS} iterations. Use /clear and try a more specific request.[/yellow]")
        self._auto_save()

    def _stream_response(self, messages: list[dict], thinking_msg: str = "Thinking...") -> str:
        """Stream response tokens, suppressing ACTION lines from display.
        Shows an in-place spinner until the first token arrives."""
        import sys
        import threading
        import time

        chunks: list[str] = []
        buffer = ""
        printing = True
        first_token = False
        stop_spinner = threading.Event()

        # Spinner with status bar — uses ANSI cursor control to show both
        def spin():
            frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
            i = 0
            out = sys.stderr if sys.stderr.isatty() else sys.stdout
            if not out.isatty():
                return
            
            # Prepare colored bar parts to match idle UI
            # 38;2;R;G;B is TrueColor ANSI
            # Cyan: #22D3EE (34, 211, 238)
            # Emerald: #34D399 (52, 211, 153)
            # Amber: #FBBF24 (251, 191, 36)
            # Dark Gray: #475569 (71, 85, 105)
            
            bar_text = self.status_text or ""
            colored_bar = ""
            if bar_text:
                parts = bar_text.split(" | ")
                if len(parts) >= 3:
                    engine = f"\033[38;2;34;211;238m{parts[0]}\033[0m"
                    hardware = f"\033[38;2;52;211;153m{parts[1]}\033[0m"
                    mode = f"\033[38;2;251;191;36m{parts[2]}\033[0m"
                    div = "\033[38;2;71;85;105m  │  \033[0m"
                    colored_bar = f"  {engine}{div}{hardware}{div}{mode}"
                    if len(parts) > 3:
                        flag = f"\033[38;2;192;132;252m{parts[3]}\033[0m" # Purple #C084FC
                        colored_bar += f"{div}{flag}"
                else:
                    colored_bar = f"  \033[38;5;250m{bar_text}\033[0m"

            while not stop_spinner.is_set():
                # Line 1: spinner
                out.write(f"\r\033[K  \033[36m{frames[i % len(frames)]} {thinking_msg}\033[0m")
                # Line 2: status bar
                if colored_bar:
                    out.write(f"\n\033[K{colored_bar}  \033[38;5;240m│  Ctrl+C: interrupt\033[0m\033[A")
                out.flush()
                i += 1
                time.sleep(0.1)
            # Clear both lines
            out.write(f"\r\033[K")
            if colored_bar:
                out.write(f"\n\033[K\033[A")
            out.write("\r")
            out.flush()

        spinner = threading.Thread(target=spin, daemon=True)
        spinner.start()

        # Collect all tokens — show spinner while waiting
        # Ctrl+C during generation sets interrupted flag
        import signal
        original_handler = signal.getsignal(signal.SIGINT)

        def _interrupt_handler(sig, frame):
            if self.interrupted:
                # Second Ctrl+C — force exit
                stop_spinner.set()
                import sys
                sys.stdout.write("\n")
                sys.exit(130)
            self.interrupted = True
            stop_spinner.set()

        signal.signal(signal.SIGINT, _interrupt_handler)

        for chunk in self.client.chat_stream(messages):
            if self.interrupted:
                break
            chunks.append(chunk)
            buffer += chunk

            # Stop spinner on first real content
            if not first_token and chunk.strip():
                stop_spinner.set()
                spinner.join(timeout=0.5)
                first_token = True

        if not first_token:
            stop_spinner.set()
            spinner.join(timeout=0.5)

        signal.signal(signal.SIGINT, original_handler)
        full = "".join(chunks).strip()

        if self.interrupted:
            if first_token:
                sys.stdout.write("\n")
                sys.stdout.flush()
            return full or "[Interrupted]"

        # Check if response contains a tool call — don't display it,
        # the agent loop will handle it separately
        is_tool = (
            "<tool_call>" in full or 
            "ACTION:" in full or 
            "<｜tool" in full or 
            "tool▁" in full or
            "<|im_start|>" in full or
            # Only suppress JSON if it looks like a real tool call structure
            re.search(r'\{[\s\S]*?"tool"[\s\S]*?:\s*"[^"]+"[\s\S]*?"args"[\s\S]*?:', full)
        )
        
        if is_tool:
            pass  # Agent loop handles display
        elif first_token:
            # Final answer — print cleanly
            display = full.strip()
            if display:
                sys.stdout.write(f"\n\033[90m  ──────\033[0m\n\n")
                sys.stdout.write(f"\033[38;5;147m{display}\033[0m\n\n")
                sys.stdout.flush()
        elif not full:
            if os.environ.get("PW_DEBUG"):
                sys.stdout.write("\n\033[31m  [Debug: Empty response from model]\033[0m\n")
                sys.stdout.flush()

        return "".join(chunks)

    def _print_status_bar(self):
        """Print a compact status line below output."""
        pass  # Handled by prompt_toolkit bottom_toolbar only

    def _auto_save(self):
        """Save session to disk after each turn."""
        try:
            save_session(self.conversation, self.cwd)
        except Exception:
            pass

    def load_session(self, conversation: list[dict]):
        """Resume a previous session."""
        self.conversation = conversation
        turns = sum(1 for m in conversation if m["role"] == "user")
        console.print(f"  [dim]Resumed session ({turns} turns)[/dim]")

    def add_file(self, path: str):
        """Add a file's contents to the conversation context."""
        full = os.path.abspath(path)
        if not os.path.exists(full):
            console.print(f"  [red]File not found: {path}[/red]")
            return
        try:
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            # Truncate large files
            if len(content) > 15000:
                content = content[:15000] + f"\n... [truncated, {len(content)} chars total]"
            self.conversation.append({
                "role": "user",
                "content": f"[File added to context: {path}]\n```\n{content}\n```"
            })
            self.files_in_context.append(path)
            console.print(f"  [green]+ {path}[/green] [dim]({len(content)} chars)[/dim]")
        except Exception as e:
            console.print(f"  [red]Error reading {path}: {e}[/red]")

    def reset(self):
        """Clear conversation history and session."""
        self.conversation = []
        self.files_in_context = []
        from config import clear_session
        clear_session(self.cwd)
        console.print("  [dim]Conversation cleared.[/dim]")
