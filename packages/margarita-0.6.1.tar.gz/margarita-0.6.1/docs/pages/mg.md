# .mg Template files

.mg files are the base level files for Margarita. They contain your prompts and can be
converted to plain Markdown on their own or can be used in [.mgx](mgx.md) files directly.

### Example .mg file

```margarita
<<
Hello, ${name}!
>>
```

### Provide context

Add JSON either inline or in a file `greeting.json`:

```json
{"name": "Batman"}
```

### Render

Render the template with the CLI:

```sh
margarita render greeting.mg -f greeting.json
```

### Rendered result

Using the template and context above the output will be:

```text
Hello, Batman!
```

<br/>
### Alternate options

- Pass context as a JSON string: `-c '{"name": "Bob"}'`
- Render a directory of `.mg` files: `margarita render templates/ -o output/`
- Inspect template metadata before rendering: `margarita render template.mg --show-metadata`

>
> Tip: When rendering a single file, MARGARITA will auto-detect a same-name `.json` file (e.g. `greeting.json`) if no context is supplied.
>
