# Craft Easy Jobs

Batch job runner for Craft Easy APIs. **Coming soon.**

Schedule, chain, and run background jobs — settlement, invoicing, BI export, and more.
