from requests.auth import HTTPBasicAuth
import requests
import traceback
import zipfile
from io import BytesIO
import time
import base64


def get_token_with_refresh(refresh_token, clientID, clientSecret, parameters):
    url = "https://logincert.anaf.ro/anaf-oauth2/v1/token"
    auth = HTTPBasicAuth(clientID, clientSecret)
    data = {
        'refresh_token': refresh_token,
        'grant_type': 'refresh_token'
    }
    try:
        proxies = {
            'http': None,
            'https': None
        }

        if "proxi_pt_anaf_https" in parameters and parameters["proxi_pt_anaf_https"] != None and parameters["proxi_pt_anaf_https"] != "":
            proxies["https"] = parameters["proxi_pt_anaf_https"]
            print("[AnafUtils.get_token_with_refresh] Se foloseste proxy HTTPS: " + proxies["https"])
        else:
            print("[AnafUtils.get_token_with_refresh] Nu este setat proxy HTTPS.")

        if "proxi_pt_anaf_http" in parameters and parameters["proxi_pt_anaf_http"] != None and parameters["proxi_pt_anaf_http"] != "":
            proxies["http"] = parameters["proxi_pt_anaf_http"]
            print("[AnafUtils.get_token_with_refresh] Se foloseste proxy HTTP: " + proxies["http"])
        else:
            print("[AnafUtils.get_token_with_refresh] Nu este setat proxy HTTP.")

        response = requests.post(url, auth=auth, data=data, proxies=proxies)
        response.raise_for_status()

        json_response = response.json()

        if 'access_token' in json_response:
            return json_response['access_token']
        else:
            error_message = "[AnafUtils.get_token_with_refresh] Token-ul de acces nu a fost gasit in raspunsul ANAF."
            print(error_message)
            raise Exception(error_message)
    except Exception as e:
        error_message = f"[AnafUtils.get_token_with_refresh] Eroare la obtinerea token-ului de acces ANAF: {str(e)}. Proxy folosit: {proxies}"
        detailed_error = traceback.format_exc()
        print(error_message)
        print(detailed_error)
        raise Exception(f"{error_message}\n{detailed_error}")
    

def get_lista_paginata_mesaje(token, start_time, end_time, cif, pagina, filter=None, parameters={}):
    url = f"https://api.anaf.ro/prod/FCTEL/rest/listaMesajePaginatieFactura?startTime={start_time}&endTime={end_time}&cif={cif}&pagina={pagina}"
    if filter is not None:
        if filter != "":
            url += "&filtru=" + filter

    headers = {'Authorization': f'Bearer {token}'}
    try:
        proxies = {
            'http': None,
            'https': None
        }

        if "proxi_pt_anaf_https" in parameters and parameters["proxi_pt_anaf_https"] != None and parameters["proxi_pt_anaf_https"] != "":
            proxies["https"] = parameters["proxi_pt_anaf_https"]

        if "proxi_pt_anaf_http" in parameters and parameters["proxi_pt_anaf_http"] != None and parameters["proxi_pt_anaf_http"] != "":
            proxies["http"] = parameters["proxi_pt_anaf_http"]

        response = requests.get(url, headers=headers, proxies=proxies)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        error_message = f"[AnafUtils.get_lista_paginata_mesaje] Eroare la obtinerea mesajelor pentru pagina {pagina}: {str(e)}"
        detailed_error = traceback.format_exc()
        print(error_message)
        print(detailed_error)
        return {'eroare': error_message + '\n' + detailed_error}

 
def get_all_messages(token, start_time, end_time, cif, filter=None, parameters={}):
    all_messages = []  # Lista pentru a stoca toate mesajele
    current_page = 1  # Indexul paginii curente începe de la 0

    # Încercăm să obținem mesajele de pe prima pagină pentru a verifica dacă există date
    first_page_response = get_lista_paginata_mesaje(
        token, start_time, end_time, cif, current_page, filter=filter, parameters=parameters)

    # Verificăm dacă răspunsul conține o eroare
    if "eroare" in first_page_response:
        if 'Nu exista mesaje' in first_page_response["eroare"]:
            print(f"[AnafUtils.get_all_messages] Textul 'Nu exista mesaje' a fost gasit in raspunsul ANAF: {first_page_response['eroare']}")
            exit(0)
        error_message = f"[AnafUtils.get_all_messages] Eroare la obtinerea tuturor mesajelor de la ANAF: {first_page_response['eroare']}"
        print(error_message)
        raise Exception(error_message)

    # Dacă există mesaje, continuăm să le adunăm din toate paginile
    total_pages = first_page_response['numar_total_pagini']
    all_messages.extend(first_page_response['mesaje'])

    # Continuăm cu următoarele pagini, dacă există
    for current_page in range(2, total_pages + 1):
        response = get_lista_paginata_mesaje(
            token, start_time, end_time, cif, current_page, filter=filter, parameters=parameters)
        if "eroare" in response:
            if 'Nu exista mesaje' in response["eroare"]:
                print(f"[AnafUtils.get_all_messages] {response['eroare']}")
                exit(0)
            else:
                error_message = f"[AnafUtils.get_all_messages] Eroare la obtinerea tuturor mesajelor de la ANAF: {response['eroare']}"
                print(error_message)
                raise Exception(error_message)
        all_messages.extend(response['mesaje'])

    return all_messages


"""
Această funcție descarcă o arhivă ZIP de la ANAF folosind un ID de factură
și extrage un fișier specificat prin nume_fisier din aceasta. 
"""
def descarca_factura_si_extrage_fisier(token, id, nume_fisier, parameters):
    try:
        url = f"https://api.anaf.ro/prod/FCTEL/rest/descarcare?id={id}"
        headers = {'Authorization': f'Bearer {token}'}

        proxies = {
            'http': None,
            'https': None
        }

        if "proxi_pt_anaf_https" in parameters and parameters["proxi_pt_anaf_https"] != None and parameters["proxi_pt_anaf_https"] != "":
            proxies["https"] = parameters["proxi_pt_anaf_https"]

        if "proxi_pt_anaf_http" in parameters and parameters["proxi_pt_anaf_http"] != None and parameters["proxi_pt_anaf_http"] != "":
            proxies["http"] = parameters["proxi_pt_anaf_http"]

        response = requests.get(url, headers=headers, proxies=proxies)

        if response.status_code != 200:
            error_message = f"[AnafUtils.descarca_factura_si_extrage_fisier] Eroare la descarcarea arhivei ZIP cu XML-ul. Cod HTTP: {response.status_code}"
            print(error_message)
            raise Exception(error_message)

        # Create a BytesIO object from the response content
        zip_in_memory = BytesIO(response.content)

        try:
            # Open the ZIP archive
            with zipfile.ZipFile(zip_in_memory, 'r') as zip_ref:
                # Check if the file exists in the archive
                if nume_fisier in zip_ref.namelist():
                    # Extract the specified file content
                    with zip_ref.open(nume_fisier) as fisier:
                        content_bytes = fisier.read()
                        # Decode bytes into a string using UTF-8
                        content_string = content_bytes.decode('utf-8')
                        return content_string
                else:
                    error_message = f"[AnafUtils.descarca_factura_si_extrage_fisier] Fisierul '{nume_fisier}' nu a fost gasit in arhiva ZIP."
                    print(error_message)
                    raise Exception(error_message)
        except zipfile.BadZipFile as zp_err:
            error_message = f"[AnafUtils.descarca_factura_si_extrage_fisier] Eroare la extragerea arhivei ZIP cu XML-ul: {zp_err}"
            detailed_error = traceback.format_exc()
            print(error_message)
            print(detailed_error)
            raise Exception(error_message + '\n' + detailed_error)
    except Exception as e:
        error_message = f"[AnafUtils.descarca_factura_si_extrage_fisier] Eroare la descarcarea/extragerea arhivei ZIP cu XML-ul: {e}"
        detailed_error = traceback.format_exc()
        print(error_message)
        print(detailed_error)
        raise Exception(error_message + '\n' + detailed_error)
    

def xml_to_pdf_to_base64(xml_data, parameters, document_type):
    """
    Funcția trimite date XML către un serviciu web al ANAF pentru a fi convertite
    într-un document PDF, apoi encodează conținutul binar al PDF-ului obținut în format Base64
    """

    if document_type == "Invoice":
        url = "https://webservicesp.anaf.ro/prod/FCTEL/rest/transformare/FACT1/DA"
    elif document_type == "CreditNote":
        url = "https://webservicesp.anaf.ro/prod/FCTEL/rest/transformare/FCN/DA"
    else:
        raise ValueError(f"[AnafUtils.xml_to_pdf_to_base64] Tip de document invalid pentru conversia XML in PDF. Tip document: {document_type}")
    
    headers = {'Content-Type': 'text/plain'}
    proxies = {'http': None, 'https': None}

    # Set proxies if provided in parameters
    if "proxi_pt_anaf_https" in parameters and parameters["proxi_pt_anaf_https"]:
        proxies["https"] = parameters["proxi_pt_anaf_https"]
    if "proxi_pt_anaf_http" in parameters and parameters["proxi_pt_anaf_http"]:
        proxies["http"] = parameters["proxi_pt_anaf_http"]

    # Retry logic
    max_retries = 5
    attempts = 0

    # Encode the XML data to UTF-8 bytes to ensure compatibility
    xml_data = xml_data.encode('utf-8')

    while attempts < max_retries:
        try:
            response = requests.post(
                url, headers=headers, data=xml_data, proxies=proxies)
            if response.status_code != 200:
                response.raise_for_status()

            # Directly check if the response is JSON
            if "application/json" in response.headers.get('Content-Type', ''):
                print(f"[AnafUtils.xml_to_pdf_to_base64] Raspuns JSON primit, se reincearca... {str(response.content)}")
                attempts += 1
                time.sleep(1)
                continue
            else:
                # Assume the response is the binary content of the PDF
                pdf_content = response.content
                # Encode the PDF content to Base64
                base64_encoded_pdf = base64.b64encode(pdf_content)
                return base64_encoded_pdf.decode('utf-8')
        except Exception as e:
            error_message = f"[AnafUtils.xml_to_pdf_to_base64] Eroare la conversia XML in PDF: {str(e)}"
            detailed_error = traceback.format_exc()
            print(error_message + '\n' + detailed_error)
            attempts += 1

    error_message = "[AnafUtils.xml_to_pdf_to_base64] Numarul maxim de reincercari a fost atins, continutul PDF nu a putut fi obtinut."
    print(error_message)
    raise Exception(error_message)
