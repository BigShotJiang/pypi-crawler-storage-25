# Updating SessionBridge on PyPI

## How PyPI Updates Work

PyPI project pages are automatically generated from your package metadata. To update anything on the PyPI page, you need to publish a new version.

## What Can Be Updated

### Automatically Updated (from package metadata)
- ✅ Project description (from README.md)
- ✅ Links (from pyproject.toml [project.urls])
- ✅ Version number
- ✅ Dependencies
- ✅ Python version requirements
- ✅ Keywords
- ✅ Classifiers
- ✅ License

### Cannot Be Updated Without New Version
- ❌ Old version's metadata (immutable once published)
- ❌ Package files (wheels/tarballs are immutable)

## Updating Links on PyPI Homepage

### Step 1: Update pyproject.toml

Edit the `[project.urls]` section:

```toml
[project.urls]
Homepage = "https://github.ibm.com/your-actual-username/sessionbridge"
Documentation = "https://github.ibm.com/your-actual-username/sessionbridge#readme"
Repository = "https://github.ibm.com/your-actual-username/sessionbridge"
Issues = "https://github.ibm.com/your-actual-username/sessionbridge/issues"
```

### Step 2: Increment Version

Edit `pyproject.toml`:

```toml
[project]
name = "sessionbridge"
version = "0.1.1"  # Increment from 0.1.0
```

**Version Numbering:**
- `0.1.0` → `0.1.1` - Bug fixes, metadata updates
- `0.1.0` → `0.2.0` - New features
- `0.1.0` → `1.0.0` - Stable release

### Step 3: Rebuild and Republish

```bash
# Clean old builds
rm -rf dist/

# Build new version
uv build

# Publish
UV_PUBLISH_TOKEN="pypi-your-token" uv publish
```

### Step 4: Verify on PyPI

Visit https://pypi.org/project/sessionbridge/ and check:
- Links in the sidebar
- README content
- Version number

## Updating Only README (No Code Changes)

If you only want to update the README/description:

```bash
# 1. Edit README.md with your changes

# 2. Increment version (required!)
# Edit pyproject.toml: version = "0.1.1"

# 3. Rebuild and publish
rm -rf dist/
uv build
UV_PUBLISH_TOKEN="pypi-token" uv publish
```

**Note:** You MUST increment the version. PyPI doesn't allow re-uploading the same version.

## Common Updates

### Update GitHub Links

```toml
# In pyproject.toml
[project.urls]
Homepage = "https://github.ibm.com/aakshu/sessionbridge"
Repository = "https://github.ibm.com/aakshu/sessionbridge"
Issues = "https://github.ibm.com/aakshu/sessionbridge/issues"
```

Then: Increment version → Build → Publish

### Update Description/README

```bash
# 1. Edit README.md
vim README.md

# 2. Increment version in pyproject.toml
version = "0.1.1"

# 3. Publish
rm -rf dist/ && uv build && uv publish
```

### Add New Links

```toml
[project.urls]
Homepage = "https://github.ibm.com/aakshu/sessionbridge"
Documentation = "https://sessionbridge.readthedocs.io"  # New!
Repository = "https://github.ibm.com/aakshu/sessionbridge"
Issues = "https://github.ibm.com/aakshu/sessionbridge/issues"
Changelog = "https://github.ibm.com/aakshu/sessionbridge/blob/main/CHANGELOG.md"  # New!
```

Then: Increment version → Build → Publish

## Version Management Best Practices

### Semantic Versioning

- **0.1.0** - Initial release
- **0.1.1** - Bug fixes, documentation updates, metadata fixes
- **0.2.0** - New features (backward compatible)
- **1.0.0** - Stable release
- **2.0.0** - Breaking changes

### When to Increment

| Change | Version Bump |
|--------|--------------|
| Fix typo in README | 0.1.0 → 0.1.1 |
| Update links | 0.1.0 → 0.1.1 |
| Add new MCP tool | 0.1.0 → 0.2.0 |
| Change tool signature | 0.1.0 → 1.0.0 |
| Bug fix | 0.1.0 → 0.1.1 |

## Quick Update Workflow

```bash
# 1. Make your changes
vim pyproject.toml  # Update links
vim README.md       # Update description

# 2. Increment version
# Edit pyproject.toml: version = "0.1.1"

# 3. Commit changes (optional but recommended)
git add .
git commit -m "Update links and README for v0.1.1"
git tag v0.1.1
git push origin main --tags

# 4. Build and publish
rm -rf dist/
uv build
UV_PUBLISH_TOKEN="pypi-token" uv publish

# 5. Verify
# Visit https://pypi.org/project/sessionbridge/
```

## What Happens After Publishing

1. **PyPI indexes new version** (takes 1-5 minutes)
2. **Project page updates** with new metadata
3. **Old versions remain available** (users can still install them)
4. **Latest version becomes default** for new installations

## Checking Your Updates

```bash
# View on PyPI
open https://pypi.org/project/sessionbridge/

# Test installation
uvx sessionbridge  # Gets latest version

# Test specific version
uvx sessionbridge==0.1.1
```

## Troubleshooting

### "File already exists"
You're trying to upload a version that already exists. Increment the version number.

### "Links not updating"
- Wait 5 minutes for PyPI to re-index
- Clear browser cache
- Check you incremented the version
- Verify pyproject.toml has correct URLs

### "README not showing"
- Ensure README.md is in the root directory
- Check `readme = "README.md"` in pyproject.toml
- Verify README is valid Markdown
- Try rebuilding: `rm -rf dist/ && uv build`

## Example: Fixing Links After First Publish

```bash
# Scenario: You published 0.1.0 but links are wrong

# 1. Fix links in pyproject.toml
[project.urls]
Homepage = "https://github.ibm.com/aakshu/sessionbridge"  # Fixed!

# 2. Increment version
version = "0.1.1"

# 3. Rebuild and publish
rm -rf dist/
uv build
UV_PUBLISH_TOKEN="pypi-token" uv publish

# 4. Check PyPI page
# Links should update within 5 minutes
```

## Managing Multiple Versions

PyPI keeps all versions:
- Users can install any version: `pip install sessionbridge==0.1.0`
- Latest version is default: `pip install sessionbridge`
- You can't delete versions (only hide them)

## Best Practices

1. **Always increment version** - Required for any update
2. **Use git tags** - Tag each release: `git tag v0.1.1`
3. **Keep CHANGELOG** - Document what changed
4. **Test before publishing** - Use TestPyPI first
5. **Don't rush** - Take time to get metadata right

## Quick Reference

```bash
# Update workflow
1. Edit files (pyproject.toml, README.md)
2. Increment version in pyproject.toml
3. rm -rf dist/ && uv build
4. UV_PUBLISH_TOKEN="token" uv publish
5. Wait 5 minutes, check PyPI page
```

## Need to Update Right After Publishing?

If you just published and need to fix something:

```bash
# Quick fix workflow
vim pyproject.toml  # Fix the issue
# Change version = "0.1.0" to version = "0.1.1"
rm -rf dist/ && uv build && uv publish
```

**Remember:** Every PyPI update requires a new version number!

---

**TL;DR:** To update anything on PyPI, increment version in `pyproject.toml`, rebuild with `uv build`, and republish with `uv publish`.