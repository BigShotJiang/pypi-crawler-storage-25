#!/usr/bin/env python3
"""Simple test client to verify MCP server tools work correctly."""
import sys
import os

# Add sessionbridge to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'sessionbridge'))

from sessionbridge.server import new_session, list_sessions, save_progress, resume_session, end_session

def test_tools():
    """Test all MCP tools directly."""
    print("=" * 60)
    print("Testing Enhanced SessionBridge MCP Tools")
    print("=" * 60)
    
    print("\n✓ Testing 5 MCP tools with smart status tracking")
    
    print("\n" + "=" * 60)
    print("Test 1: Create a new session with task goal")
    print("=" * 60)
    result = new_session(
        name="demo-session",
        task_goal="Build authentication system with JWT tokens",
        repos=["/code/api-service", "/code/auth-library"]
    )
    print(f"Result: {result}")
    
    print("\n" + "=" * 60)
    print("Test 2: List sessions")
    print("=" * 60)
    result = list_sessions()
    print(f"Result:\n{result}")
    
    print("\n" + "=" * 60)
    print("Test 3: Save progress with status inference")
    print("=" * 60)
    
    result = save_progress(
        "demo-session",
        "Completed JWT token generation in auth-library/token.py. Successfully tested locally."
    )
    print(f"Result: {result}")
    
    result = save_progress(
        "demo-session",
        "Implemented token validation. Blocked on API key configuration - waiting for DevOps team. Next: integrate with API service."
    )
    print(f"Result: {result}")
    
    result = save_progress(
        "demo-session",
        "Fixed token expiration bug in config.py line 42. Need to deploy to staging and run integration tests."
    )
    print(f"Result: {result}")
    
    print("\n" + "=" * 60)
    print("Test 4: Resume session (check status tracking)")
    print("=" * 60)
    result = resume_session("demo-session")
    print(f"Result:\n{result}")
    
    print("\n" + "=" * 60)
    print("Test 5: End session with wrap-up")
    print("=" * 60)
    result = end_session(
        "demo-session",
        "Completed JWT implementation and testing. Deployed to staging. Still need production deployment approval from security team."
    )
    print(f"Result: {result}")
    
    print("\n" + "=" * 60)
    print("Test 6: Resume to see final state")
    print("=" * 60)
    result = resume_session("demo-session")
    print(f"Result:\n{result}")
    
    print("\n" + "=" * 60)
    print("✓ All enhanced features tested successfully!")
    print("=" * 60)
    print("\nSession file created at: ~/.sessionbridge/sessions/demo-session.md")
    print("You can view it with: cat ~/.sessionbridge/sessions/demo-session.md")
    print("\nNotice the smart status tracking extracted from your summaries!")

if __name__ == "__main__":
    test_tools()

# Made with Bob
