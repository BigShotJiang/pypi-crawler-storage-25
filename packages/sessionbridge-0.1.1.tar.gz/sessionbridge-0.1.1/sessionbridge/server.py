#!/usr/bin/env python3
"""SessionBridge MCP Server - Persistent cross-repo session memory."""
from fastmcp import FastMCP
from sessionbridge.session_manager import SessionManager
from typing import List, Optional

# Initialize FastMCP server
mcp = FastMCP("SessionBridge")

# Initialize session manager
session_mgr = SessionManager()


@mcp.tool()
def new_session(name: str, task_goal: str, repos: List[str]) -> str:
    """
    Create a new session with a clear task goal and repository paths.
    
    ⚠️ WHEN TO USE:
    - User explicitly asks to create/start a session
    - User wants to track work across multiple conversations
    
    If user asks a general question without mentioning sessions, consider asking:
    "Would you like me to:
    1. Create a new session to track this work?
    2. Continue an existing session? (I can list them)
    3. Just help without session tracking?"
    
    Only call this tool if user chooses option 1.
    
    Args:
        name: Short, descriptive session name (e.g., "auth-refactor", "api-redesign")
        task_goal: Clear description of what you're trying to accomplish
        repos: List of repository paths involved in this work
    
    Returns:
        Success message
    
    Example:
        new_session(
            name="jwt-token-fix",
            task_goal="Fix JWT token expiration issue causing 401 errors in production",
            repos=["/code/api-service", "/code/auth-library"]
        )
    """
    try:
        return session_mgr.create_session(name, task_goal, repos)
    except Exception as e:
        return f"Error creating session: {str(e)}"


@mcp.tool()
def resume_session(name: str, add_repos: Optional[List[str]] = None) -> str:
    """
    Resume a session by reading its content. Automatically trims to last 20 entries
    if token estimate exceeds 3000. Optionally add new repositories to the session.
    
    Use this when:
    - Continuing work on an existing task
    - Work has expanded to include additional repositories
    - You need the full context to continue
    
    Args:
        name: Session name to resume
        add_repos: Optional list of new repository paths to add to this session
    
    Returns:
        Session content as context
    
    Example:
        # Simple resume
        resume_session(name="jwt-token-fix")
        
        # Resume and add new repos
        resume_session(
            name="jwt-token-fix",
            add_repos=["/code/frontend", "/code/mobile-app"]
        )
    """
    try:
        # Add new repos if provided
        if add_repos:
            result = session_mgr.add_repos(name, add_repos)
            print(f"Note: {result}")
        
        return session_mgr.read_session(name)
    except Exception as e:
        return f"Error resuming session: {str(e)}"


@mcp.tool()
def add_repos_to_session(name: str, repos: List[str]) -> str:
    """
    Add new repositories to an existing session. Use when work expands to
    additional codebases.
    
    ⚠️ REQUIRES ACTIVE SESSION - Only call if user is working within a session context.
    
    Args:
        name: Session name
        repos: List of new repository paths to add
    
    Returns:
        Success message with repo count
    
    Example:
        add_repos_to_session(
            name="api-redesign",
            repos=["/code/mobile-app", "/code/admin-panel"]
        )
    """
    try:
        return session_mgr.add_repos(name, repos)
    except Exception as e:
        return f"Error adding repos: {str(e)}"


@mcp.tool()
def save_progress(name: str, summary: str) -> str:
    """
    Save significant progress to a session. Automatically infers and updates status
    from your summary text (completed items, blockers, next steps).
    
    ⚠️ REQUIRES ACTIVE SESSION - Only call if user is working within a session context.
    
    ⚠️ WHEN TO CALL THIS (Event-Driven):
    ✓ Root cause or key finding identified
    ✓ Architectural decision made
    ✓ Task or subtask completed
    ✓ About to switch repos or context
    ✓ Blocking issue encountered
    
    ✗ DO NOT call for:
    - Clarifying questions
    - General exploration or dead ends
    - Every small step
    - Normal conversations without sessions
    
    The summary should describe WHAT was accomplished or discovered, not just actions taken.
    
    Args:
        name: Session name
        summary: Meaningful progress description (e.g., "Identified root cause in auth.py line 42:
                 JWT expiration not being validated. Need to add token refresh logic.")
    
    Returns:
        Success message
    
    Example:
        save_progress(
            name="jwt-token-fix",
            summary="Completed JWT validation fix in auth-library/token.py. Tested locally.
                     Next: deploy to staging and update API service to use new version."
        )
    """
    try:
        return session_mgr.save_progress(name, summary)
    except Exception as e:
        return f"Error saving progress: {str(e)}"


@mcp.tool()
def end_session(name: str, summary: str) -> str:
    """
    End a session with a wrap-up summary.
    
    ⚠️ REQUIRES ACTIVE SESSION - Only call if user is working within a session context.
    
    Use this when:
    - Task is completed
    - Switching to a different task/session
    - Taking a break and want to capture final state
    - Handing off work to someone else
    
    This adds a clear session boundary and final status update for easy resumption.
    
    Args:
        name: Session name
        summary: Final wrap-up (what was accomplished, what's left, any handoff notes)
    
    Returns:
        Success message
    
    Example:
        end_session(
            name="jwt-token-fix",
            summary="Fixed JWT validation in auth-library v2.1.0. Deployed to staging.
                     API service still needs update - blocked on code review approval."
        )
    """
    try:
        return session_mgr.end_session(name, summary)
    except Exception as e:
        return f"Error ending session: {str(e)}"


@mcp.tool()
def list_sessions() -> str:
    """
    List all available sessions with their last-modified dates.
    
    Returns:
        Formatted list of sessions
    """
    try:
        sessions = session_mgr.list_sessions()
        
        if not sessions:
            return "No sessions found."
        
        result = "Available sessions:\n\n"
        for session in sessions:
            result += f"- {session['name']} (last modified: {session['last_modified']})\n"
        
        return result
    except Exception as e:
        return f"Error listing sessions: {str(e)}"


def main():
    """Main entry point for the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
