"""Entry point for running sessionbridge as a module or with uvx."""
from sessionbridge.server import main

if __name__ == "__main__":
    main()

# Made with Bob
