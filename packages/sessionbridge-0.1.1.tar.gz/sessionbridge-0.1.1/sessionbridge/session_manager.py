"""Session management logic for SessionBridge."""
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import re


class SessionManager:
    """Manages session files in ~/.sessionbridge/sessions/"""
    
    def __init__(self):
        self.sessions_dir = Path.home() / ".sessionbridge" / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
    
    def create_session(self, name: str, task_goal: str, repos: List[str]) -> str:
        """Create a new session file with task goal, repo paths and creation date."""
        session_file = self.sessions_dir / f"{name}.md"
        
        if session_file.exists():
            raise ValueError(f"Session '{name}' already exists")
        
        created_date = datetime.now().strftime("%Y-%m-%d")
        
        content = f"""# {name}
**Goal:** {task_goal}
**Repos:** {", ".join(repos)}
**Created:** {created_date}

**Status:** not-started
- Done:
- Blocked on:
- Next:

"""
        
        session_file.write_text(content)
        return f"Session '{name}' created successfully with goal: {task_goal}"
    
    def read_session(self, name: str) -> str:
        """Read session file and trim if necessary."""
        session_file = self.sessions_dir / f"{name}.md"
        
        if not session_file.exists():
            raise ValueError(f"Session '{name}' not found")
        
        content = session_file.read_text()
        
        # Estimate token count (rough: 1 token ≈ 4 chars)
        estimated_tokens = len(content) / 4
        
        if estimated_tokens > 3000:
            content = self._trim_to_last_entries(content, max_entries=20)
            # Save trimmed version back to file
            session_file.write_text(content)
        
        return content
    
    def add_repos(self, name: str, new_repos: List[str]) -> str:
        """Add new repositories to an existing session."""
        session_file = self.sessions_dir / f"{name}.md"
        
        if not session_file.exists():
            raise ValueError(f"Session '{name}' not found")
        
        content = session_file.read_text()
        lines = content.split("\n")
        
        # Find the Repos line
        for i, line in enumerate(lines):
            if line.startswith("**Repos:**"):
                # Extract existing repos
                repos_text = line.split("**Repos:**")[1].strip()
                existing_repos = [r.strip() for r in repos_text.split(",")]
                
                # Add new repos (avoid duplicates)
                for repo in new_repos:
                    if repo not in existing_repos:
                        existing_repos.append(repo)
                
                # Update the line
                lines[i] = f"**Repos:** {', '.join(existing_repos)}"
                
                # Write back
                content = "\n".join(lines)
                session_file.write_text(content)
                
                return f"Added {len(new_repos)} repo(s) to session '{name}'. Total repos: {len(existing_repos)}"
        
        raise ValueError(f"Could not find Repos line in session '{name}'")
    
    def save_progress(self, name: str, summary: str) -> str:
        """Append a new dated entry and intelligently update status."""
        session_file = self.sessions_dir / f"{name}.md"
        
        if not session_file.exists():
            raise ValueError(f"Session '{name}' not found")
        
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        # Read existing content
        content = session_file.read_text()
        
        # Infer status updates from summary
        status_updates = self._infer_status_from_summary(summary)
        
        # Update status section if we found relevant info
        if status_updates:
            content = self._update_status_section(content, status_updates)
        
        # Check if there's already an entry for today
        date_header = f"## {current_date}"
        
        if date_header in content:
            # Append to existing date section
            new_entry = f"{summary}\n"
        else:
            # Create new date section
            new_entry = f"\n{date_header}\n{summary}\n"
        
        # Append the new entry
        content += new_entry
        session_file.write_text(content)
        
        return f"Progress saved to session '{name}'"
    
    def end_session(self, name: str, summary: str) -> str:
        """End a session with a wrap-up summary and final status."""
        session_file = self.sessions_dir / f"{name}.md"
        
        if not session_file.exists():
            raise ValueError(f"Session '{name}' not found")
        
        current_date = datetime.now().strftime("%Y-%m-%d")
        current_time = datetime.now().strftime("%H:%M")
        
        # Read existing content
        content = session_file.read_text()
        
        # Infer final status from summary
        status_updates = self._infer_status_from_summary(summary)
        
        # Update status section
        if status_updates:
            content = self._update_status_section(content, status_updates)
        
        # Add session end marker
        date_header = f"## {current_date}"
        
        if date_header in content:
            wrap_up = f"\n**[Session ended at {current_time}]**\n{summary}\n"
        else:
            wrap_up = f"\n{date_header}\n**[Session ended at {current_time}]**\n{summary}\n"
        
        content += wrap_up
        session_file.write_text(content)
        
        return f"Session '{name}' ended successfully"
    def _infer_status_from_summary(self, summary: str) -> Dict[str, List[str]]:
        """Infer status updates from summary text using keyword patterns."""
        summary_lower = summary.lower()
        updates = {
            "done": [],
            "blocked": [],
            "next": [],
            "status": None
        }
        
        # Patterns for completed items
        done_patterns = [
            r"(?:completed|finished|implemented|fixed|resolved|done|merged|deployed)\s+(.+?)(?:\.|$|,|\n)",
            r"(?:successfully|finally)\s+(.+?)(?:\.|$|,|\n)",
        ]
        
        # Patterns for blockers
        blocked_patterns = [
            r"(?:blocked on|waiting for|need|requires|pending)\s+(.+?)(?:\.|$|,|\n)",
            r"(?:can't|cannot|unable to)\s+(.+?)(?:until|because|due to)\s+(.+?)(?:\.|$|,|\n)",
        ]
        
        # Patterns for next steps
        next_patterns = [
            r"(?:next|todo|need to|should|will|plan to)\s+(.+?)(?:\.|$|,|\n)",
            r"(?:remaining|still need)\s+(.+?)(?:\.|$|,|\n)",
        ]
        
        # Extract done items
        for pattern in done_patterns:
            matches = re.finditer(pattern, summary_lower, re.IGNORECASE)
            for match in matches:
                item = match.group(1).strip()
                if item and len(item) > 3:  # Avoid very short matches
                    updates["done"].append(item)
        
        # Extract blockers
        for pattern in blocked_patterns:
            matches = re.finditer(pattern, summary_lower, re.IGNORECASE)
            for match in matches:
                # Get the last captured group (the blocker description)
                item = match.group(match.lastindex).strip() if match.lastindex else match.group(1).strip()
                if item and len(item) > 3:
                    updates["blocked"].append(item)
        
        # Extract next steps
        for pattern in next_patterns:
            matches = re.finditer(pattern, summary_lower, re.IGNORECASE)
            for match in matches:
                item = match.group(1).strip()
                if item and len(item) > 3:
                    updates["next"].append(item)
        
        # Infer overall status
        if any(word in summary_lower for word in ["completed", "finished", "done", "resolved all"]):
            updates["status"] = "completed"
        elif any(word in summary_lower for word in ["blocked", "stuck", "waiting", "can't proceed"]):
            updates["status"] = "blocked"
        elif updates["done"] or updates["next"]:
            updates["status"] = "in-progress"
        
        return updates
    
    def _update_status_section(self, content: str, updates: Dict[str, List[str]]) -> str:
        """Update the status section in the session file."""
        lines = content.split("\n")
        
        # Find the status section
        status_start = -1
        status_end = -1
        
        for i, line in enumerate(lines):
            if line.startswith("**Status:**"):
                status_start = i
            elif status_start != -1 and (line.startswith("##") or line.startswith("**Goal:**") or line.startswith("**Repos:**")):
                status_end = i
                break
            elif status_start != -1 and i == len(lines) - 1:
                status_end = i + 1
        
        if status_start == -1:
            # No status section found, can't update
            return content
        
        # Parse existing status
        existing_done = []
        existing_blocked = []
        existing_next = []
        current_status = "in-progress"
        
        for i in range(status_start, status_end):
            line = lines[i]
            if line.startswith("**Status:**"):
                current_status = line.split("**Status:**")[1].strip()
            elif line.strip().startswith("- Done:"):
                done_text = line.split("- Done:")[1].strip()
                if done_text:
                    existing_done = [item.strip() for item in done_text.split(",") if item.strip()]
            elif line.strip().startswith("- Blocked on:"):
                blocked_text = line.split("- Blocked on:")[1].strip()
                if blocked_text:
                    existing_blocked = [item.strip() for item in blocked_text.split(",") if item.strip()]
            elif line.strip().startswith("- Next:"):
                next_text = line.split("- Next:")[1].strip()
                if next_text:
                    existing_next = [item.strip() for item in next_text.split(",") if item.strip()]
        
        # Merge updates with existing
        if updates["done"]:
            existing_done.extend(updates["done"])
            # Remove duplicates while preserving order
            existing_done = list(dict.fromkeys(existing_done))
        
        if updates["blocked"]:
            existing_blocked.extend(updates["blocked"])
            existing_blocked = list(dict.fromkeys(existing_blocked))
        
        if updates["next"]:
            existing_next.extend(updates["next"])
            existing_next = list(dict.fromkeys(existing_next))
        
        # Update status if inferred
        if updates["status"]:
            current_status = updates["status"]
        
        # Rebuild status section
        new_status_lines = [
            f"**Status:** {current_status}",
            f"- Done: {', '.join(existing_done) if existing_done else ''}",
            f"- Blocked on: {', '.join(existing_blocked) if existing_blocked else ''}",
            f"- Next: {', '.join(existing_next) if existing_next else ''}",
            ""
        ]
        
        # Replace old status section with new one
        new_lines = lines[:status_start] + new_status_lines + lines[status_end:]
        
        return "\n".join(new_lines)
    
    
    def list_sessions(self) -> List[Dict[str, str]]:
        """List all sessions with last-modified date."""
        sessions = []
        
        for session_file in self.sessions_dir.glob("*.md"):
            modified_time = datetime.fromtimestamp(session_file.stat().st_mtime)
            sessions.append({
                "name": session_file.stem,
                "last_modified": modified_time.strftime("%Y-%m-%d %H:%M:%S")
            })
        
        # Sort by last modified (most recent first)
        sessions.sort(key=lambda x: x["last_modified"], reverse=True)
        
        return sessions
    
    def _trim_to_last_entries(self, content: str, max_entries: int = 20) -> str:
        """Trim content to keep only the last N date entries."""
        lines = content.split("\n")
        
        # Find the header section (everything before first ## date entry)
        header_lines = []
        body_start_idx = 0
        
        for i, line in enumerate(lines):
            if line.startswith("## "):
                body_start_idx = i
                break
            header_lines.append(line)
        
        # Find all date section starts
        date_sections = []
        for i in range(body_start_idx, len(lines)):
            if lines[i].startswith("## "):
                date_sections.append(i)
        
        # Keep only last max_entries sections
        if len(date_sections) > max_entries:
            keep_from_idx = date_sections[-max_entries]
            trimmed_lines = header_lines + lines[keep_from_idx:]
        else:
            trimmed_lines = lines
        
        return "\n".join(trimmed_lines)

# Made with Bob
