#!/usr/bin/env python3
"""Test script for SessionManager with enhanced features."""
from session_manager import SessionManager
from pathlib import Path
import shutil

def test_session_manager():
    """Test the enhanced SessionManager functionality."""
    print("=" * 60)
    print("Testing Enhanced SessionManager")
    print("=" * 60)
    
    # Initialize manager
    mgr = SessionManager()
    print(f"✓ Sessions directory: {mgr.sessions_dir}")
    
    # Test 1: Create a new session with task goal
    print("\n1. Creating new session with task goal...")
    try:
        result = mgr.create_session(
            name="test-session",
            task_goal="Test all SessionManager features including smart status tracking",
            repos=["/code/repo1", "/code/repo2"]
        )
        print(f"✓ {result}")
    except Exception as e:
        print(f"✗ Error: {e}")
        return
    
    # Test 2: List sessions
    print("\n2. Listing sessions...")
    sessions = mgr.list_sessions()
    for session in sessions:
        print(f"✓ {session['name']} - {session['last_modified']}")
    
    # Test 3: Save progress with smart status inference
    print("\n3. Saving progress with status inference...")
    try:
        result = mgr.save_progress(
            name="test-session",
            summary="Completed feature X implementation. Successfully tested locally."
        )
        print(f"✓ {result}")
        
        result = mgr.save_progress(
            name="test-session",
            summary="Fixed bug Y in module Z. Blocked on code review approval. Next: deploy to staging."
        )
        print(f"✓ {result}")
        
        result = mgr.save_progress(
            name="test-session",
            summary="Implemented validation logic. Need to write unit tests and update documentation."
        )
        print(f"✓ {result}")
    except Exception as e:
        print(f"✗ Error: {e}")
        return
    
    # Test 4: Resume session and check status
    print("\n4. Resuming session to check status tracking...")
    try:
        content = mgr.read_session("test-session")
        print("✓ Session content with smart status:")
        print("-" * 60)
        print(content)
        print("-" * 60)
        
        # Verify status section exists
        if "**Status:**" in content:
            print("✓ Status section found")
        if "- Done:" in content:
            print("✓ Done items tracked")
        if "- Blocked on:" in content:
            print("✓ Blockers tracked")
        if "- Next:" in content:
            print("✓ Next steps tracked")
    except Exception as e:
        print(f"✗ Error: {e}")
        return
    
    # Test 5: End session
    print("\n5. Testing end_session...")
    try:
        result = mgr.end_session(
            name="test-session",
            summary="Completed all testing. All features working correctly. Ready for production."
        )
        print(f"✓ {result}")
        
        # Check session end marker
        content = mgr.read_session("test-session")
        if "**[Session ended at" in content:
            print("✓ Session end marker added")
        if "completed" in content.lower():
            print("✓ Final status updated")
    except Exception as e:
        print(f"✗ Error: {e}")
        return
    
    # Test 6: Test trimming with large content
    print("\n6. Testing auto-trim with large content...")
    try:
        # Add many entries to trigger trimming
        for i in range(25):
            mgr.save_progress(
                name="test-session",
                summary=f"Entry {i+4}: " + ("x" * 200)  # Make entries large
            )
        
        # Resume should trigger trimming
        content = mgr.read_session("test-session")
        entry_count = content.count("##")
        print(f"✓ After trimming, session has {entry_count} date sections")
        
        if entry_count <= 20:
            print("✓ Trimming works correctly!")
        else:
            print(f"✗ Expected <= 20 sections, got {entry_count}")
    except Exception as e:
        print(f"✗ Error: {e}")
        return
    
    # Test 7: Try to create duplicate session
    print("\n7. Testing duplicate session prevention...")
    try:
        mgr.create_session(
            name="test-session",
            task_goal="This should fail",
            repos=["/code/repo3"]
        )
        print("✗ Should have raised an error for duplicate session")
    except ValueError as e:
        print(f"✓ Correctly prevented duplicate: {e}")
    
    # Test 8: Try to resume non-existent session
    print("\n8. Testing non-existent session handling...")
    try:
        mgr.read_session("non-existent-session")
        print("✗ Should have raised an error for non-existent session")
    except ValueError as e:
        print(f"✓ Correctly handled non-existent session: {e}")
    
    print("\n" + "=" * 60)
    print("✓ All enhanced features tested successfully!")
    print("=" * 60)
    
    # Show final session
    print("\nFinal session file at:", mgr.sessions_dir / "test-session.md")
    print("You can view it with: cat ~/.sessionbridge/sessions/test-session.md")
    print("\nNotice the smart status tracking and session end marker!")

if __name__ == "__main__":
    test_session_manager()

# Made with Bob
