#!/usr/bin/env python3
"""Test script for repo update functionality."""
import sys
import os

# Add sessionbridge to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'sessionbridge'))

from sessionbridge.server import new_session, add_repos_to_session, resume_session
from sessionbridge.session_manager import SessionManager

def test_repo_updates():
    """Test adding repos to sessions."""
    print("=" * 60)
    print("Testing Repo Update Functionality")
    print("=" * 60)
    
    # Clean up if exists
    mgr = SessionManager()
    test_file = mgr.sessions_dir / "repo-test.md"
    if test_file.exists():
        test_file.unlink()
        print("✓ Cleaned up existing test session")
    
    # Test 1: Create session with one repo
    print("\n1. Creating session with single repo...")
    result = new_session(
        name="repo-test",
        task_goal="Test repo update functionality",
        repos=["/code/api"]
    )
    print(f"✓ {result}")
    
    # Test 2: View initial state
    print("\n2. Initial session state...")
    content = resume_session("repo-test")
    print("Session content:")
    print("-" * 60)
    for line in content.split("\n")[:6]:  # Show first 6 lines
        print(line)
    print("-" * 60)
    
    # Test 3: Add repos using dedicated tool
    print("\n3. Adding repos using add_repos_to_session...")
    result = add_repos_to_session(
        name="repo-test",
        repos=["/code/frontend", "/code/mobile"]
    )
    print(f"✓ {result}")
    
    # Test 4: Verify repos were added
    print("\n4. Verifying repos were added...")
    content = resume_session("repo-test")
    print("Updated session content:")
    print("-" * 60)
    for line in content.split("\n")[:6]:
        print(line)
    print("-" * 60)
    
    if "/code/api" in content and "/code/frontend" in content and "/code/mobile" in content:
        print("✓ All repos present!")
    else:
        print("✗ Some repos missing")
    
    # Test 5: Add repos via resume_session
    print("\n5. Adding repos via resume_session...")
    content = resume_session(
        name="repo-test",
        add_repos=["/code/backend", "/code/admin"]
    )
    print("Session after resume with add_repos:")
    print("-" * 60)
    for line in content.split("\n")[:6]:
        print(line)
    print("-" * 60)
    
    # Test 6: Verify all repos
    print("\n6. Final verification...")
    content = resume_session("repo-test")
    expected_repos = ["/code/api", "/code/frontend", "/code/mobile", "/code/backend", "/code/admin"]
    
    all_present = all(repo in content for repo in expected_repos)
    if all_present:
        print(f"✓ All {len(expected_repos)} repos present!")
        print(f"  Repos: {', '.join(expected_repos)}")
    else:
        print("✗ Some repos missing")
        for repo in expected_repos:
            status = "✓" if repo in content else "✗"
            print(f"  {status} {repo}")
    
    # Test 7: Try adding duplicate repo
    print("\n7. Testing duplicate prevention...")
    result = add_repos_to_session(
        name="repo-test",
        repos=["/code/api", "/code/new-service"]  # /code/api is duplicate
    )
    print(f"✓ {result}")
    
    content = resume_session("repo-test")
    api_count = content.count("/code/api")
    if api_count == 1:
        print("✓ Duplicate prevention working - /code/api appears only once")
    else:
        print(f"✗ Duplicate found - /code/api appears {api_count} times")
    
    print("\n" + "=" * 60)
    print("✓ Repo update functionality tested successfully!")
    print("=" * 60)
    print(f"\nTest session at: {test_file}")
    print("View with: cat ~/.sessionbridge/sessions/repo-test.md")

if __name__ == "__main__":
    test_repo_updates()

# Made with Bob
