# Publishing SessionBridge to PyPI

## Prerequisites

1. **Install build tools:**
```bash
pip install build twine
```

2. **Create PyPI account:**
   - Go to https://pypi.org/account/register/
   - Verify your email
   - Set up 2FA (recommended)

3. **Create API token:**
   - Go to https://pypi.org/manage/account/token/
   - Create a new API token with scope "Entire account"
   - Save the token securely (starts with `pypi-`)

## Package Structure

Your package should have this structure:

```
session-bridge/
├── sessionbridge/
│   ├── __init__.py
│   ├── __main__.py
│   ├── server.py
│   └── session_manager.py
├── pyproject.toml
├── README.md
├── LICENSE
└── .gitignore
```

## Step-by-Step Publishing

### 1. Clean Previous Builds

```bash
rm -rf dist/ build/ *.egg-info
```

### 2. Build the Package

```bash
python -m build
```

This creates:
- `dist/sessionbridge-0.1.0.tar.gz` (source distribution)
- `dist/sessionbridge-0.1.0-py3-none-any.whl` (wheel)

### 3. Check the Package

```bash
twine check dist/*
```

Should show: `Checking dist/sessionbridge-0.1.0.tar.gz: PASSED`

### 4. Test on TestPyPI (Optional but Recommended)

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ sessionbridge

# Test with uvx
uvx --from https://test.pypi.org/simple/ sessionbridge
```

### 5. Upload to PyPI

```bash
twine upload dist/*
```

Enter your PyPI credentials:
- Username: `__token__`
- Password: Your API token (including the `pypi-` prefix)

### 6. Verify Installation

```bash
# Install from PyPI
pip install sessionbridge

# Test with uvx (no installation needed!)
uvx sessionbridge
```

## Using with Bob

After publishing, users can configure Bob with:

```json
{
  "mcpServers": {
    "sessionbridge": {
      "command": "uvx",
      "args": ["sessionbridge"],
      "alwaysAllow": [
        "list_sessions",
        "resume_session",
        "new_session",
        "save_progress",
        "end_session",
        "add_repos_to_session"
      ]
    }
  }
}
```

No local setup required! `uvx` will automatically download and run the package.

## Updating the Package

### 1. Update Version

Edit `pyproject.toml`:
```toml
version = "0.1.1"  # Increment version
```

### 2. Rebuild and Upload

```bash
rm -rf dist/
python -m build
twine check dist/*
twine upload dist/*
```

## Version Numbering

Follow [Semantic Versioning](https://semver.org/):
- `0.1.0` - Initial release
- `0.1.1` - Bug fixes
- `0.2.0` - New features (backward compatible)
- `1.0.0` - Stable release
- `2.0.0` - Breaking changes

## Troubleshooting

### "File already exists"
You're trying to upload a version that already exists. Increment the version number.

### "Invalid credentials"
- Make sure username is `__token__`
- Check your API token is correct
- Token should start with `pypi-`

### "Package name already taken"
Choose a different name in `pyproject.toml`. Check availability at https://pypi.org/

### uvx can't find package
- Wait a few minutes after upload (PyPI needs to index)
- Check package exists: https://pypi.org/project/sessionbridge/
- Try: `uvx --refresh sessionbridge`

## Best Practices

1. **Test locally first:**
   ```bash
   pip install -e .
   sessionbridge
   ```

2. **Use TestPyPI for testing:**
   Always test on TestPyPI before uploading to real PyPI

3. **Tag releases in Git:**
   ```bash
   git tag v0.1.0
   git push origin v0.1.0
   ```

4. **Write changelog:**
   Document changes in README or CHANGELOG.md

5. **Keep dependencies minimal:**
   Only `fastmcp` is required - keep it that way!

## GitHub Integration (Optional)

### 1. Create GitHub Repository

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/sessionbridge.git
git push -u origin main
```

### 2. Update pyproject.toml URLs

```toml
[project.urls]
Homepage = "https://github.com/yourusername/sessionbridge"
Repository = "https://github.com/yourusername/sessionbridge"
Issues = "https://github.com/yourusername/sessionbridge/issues"
```

### 3. Add GitHub Actions (Optional)

Create `.github/workflows/publish.yml` for automatic publishing on release.

## Support

- PyPI Help: https://pypi.org/help/
- Packaging Guide: https://packaging.python.org/
- uvx Documentation: https://github.com/astral-sh/uv

## Quick Reference

```bash
# Build
python -m build

# Check
twine check dist/*

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*

# Test with uvx
uvx sessionbridge
```

---

**Ready to publish? Follow the steps above and SessionBridge will be available worldwide via `uvx sessionbridge`!**