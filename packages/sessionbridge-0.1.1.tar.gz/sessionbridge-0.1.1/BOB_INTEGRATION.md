# Connecting SessionBridge to Bob MCP

## Prerequisites

✓ SessionBridge is working locally (run `test_mcp_client.py` to verify)
✓ Bob is installed and configured on your system

## Step-by-Step Integration

### 1. Locate Bob's MCP Configuration File

Bob typically stores MCP server configurations in one of these locations:

```bash
# Check if Bob config directory exists
ls -la ~/.bob/

# Common locations:
# ~/.bob/mcp.json
# ~/.config/bob/mcp.json
```

If the file doesn't exist, create it:

```bash
mkdir -p ~/.bob
touch ~/.bob/mcp.json
```

### 2. Add SessionBridge to Bob's Configuration

Edit `~/.bob/mcp.json` and add the SessionBridge server:

```json
{
  "mcpServers": {
    "sessionbridge": {
      "command": "python",
      "args": ["/Users/aakshu/Code/session-bridge/sessionbridge/server.py"],
      "alwaysAllow": [
        "list_sessions",
        "resume_session",
        "new_session",
        "save_progress"
      ]
    }
  }
}
```

**Important Notes:**
- Use the **absolute path** to `server.py`
- If you have other MCP servers, add SessionBridge to the existing `mcpServers` object
- The `alwaysAllow` array grants automatic permission for all 4 tools

### 3. Alternative: Use Python from Virtual Environment

For better isolation, you can use the Python from your virtual environment:

```json
{
  "mcpServers": {
    "sessionbridge": {
      "command": "/Users/aakshu/Code/session-bridge/.venv/bin/python",
      "args": ["/Users/aakshu/Code/session-bridge/sessionbridge/server.py"],
      "alwaysAllow": [
        "list_sessions",
        "resume_session",
        "new_session",
        "save_progress"
      ]
    }
  }
}
```

### 4. Restart Bob

After updating the configuration:

1. Completely quit Bob
2. Restart Bob
3. Bob will automatically connect to SessionBridge on startup

### 5. Verify Connection in Bob

Try these commands in Bob to verify the connection:

```
"List my sessions"
"Create a new session called test-bob for repos /code/project1"
"Save progress to test-bob: Initial setup complete"
"Resume the test-bob session"
```

Bob should now have access to all 4 SessionBridge tools!

## Testing the Integration

### Create a Session
```
Bob: "Create a new session called auth-refactor for repositories /code/api-service and /code/auth-library"
```

Expected response: "Session 'auth-refactor' created successfully"

### Save Progress
```
Bob: "Save progress to auth-refactor: Found JWT issue in config.py line 42"
```

Expected response: "Progress saved to session 'auth-refactor'"

### List Sessions
```
Bob: "List all my sessions"
```

Expected response: List of all sessions with last-modified dates

### Resume Session
```
Bob: "Resume the auth-refactor session"
```

Expected response: Full session content with all saved progress

## Troubleshooting

### Bob Can't Find SessionBridge

**Check Bob's logs** for MCP connection errors:
```bash
# Bob logs are typically in:
~/.bob/logs/
# or
~/Library/Logs/Bob/
```

**Verify the server works standalone:**
```bash
cd /Users/aakshu/Code/session-bridge
.venv/bin/python sessionbridge/server.py
# Should wait for input (press Ctrl+C to exit)
```

### Tools Not Available in Bob

1. **Check `alwaysAllow` list** - All 4 tool names must be exact:
   - `list_sessions`
   - `resume_session`
   - `new_session`
   - `save_progress`

2. **Verify Python path** - Make sure Python can import fastmcp:
   ```bash
   /Users/aakshu/Code/session-bridge/.venv/bin/python -c "import fastmcp; print('OK')"
   ```

3. **Check file permissions:**
   ```bash
   ls -l /Users/aakshu/Code/session-bridge/sessionbridge/server.py
   # Should be readable and executable
   ```

### Sessions Not Persisting

Check if the sessions directory exists and is writable:
```bash
ls -la ~/.sessionbridge/sessions/
# Should show your session files
```

## Example Bob Workflow

Here's a complete workflow you can try with Bob:

1. **Start a new project session:**
   ```
   "Create a session called api-redesign for repos /code/api and /code/frontend"
   ```

2. **Work on the project and save progress:**
   ```
   "Save progress to api-redesign: Implemented new REST endpoints"
   "Save progress to api-redesign: Updated frontend to use new API"
   ```

3. **Later, resume your work:**
   ```
   "Resume the api-redesign session"
   ```
   Bob will load all your previous context!

4. **Check all your sessions:**
   ```
   "List my sessions"
   ```

## Advanced: Multiple Bob Instances

If you use Bob on multiple machines, you can sync sessions by:

1. Storing sessions in a cloud-synced folder (Dropbox, iCloud, etc.)
2. Updating `session_manager.py` to use a custom path
3. Or manually copying `~/.sessionbridge/sessions/` between machines

## Need Help?

- Test locally first: `python test_mcp_client.py`
- Check session files: `cat ~/.sessionbridge/sessions/*.md`
- Verify Bob config: `cat ~/.bob/mcp.json`
- Check Bob logs for errors