# SessionBridge Setup and Testing Guide

## Step 1: Local Testing (Without Bob)

### Quick Test - Verify All Tools Work

```bash
# Make sure you're in the project directory
cd /Users/aakshu/Code/session-bridge

# Run the test client (tests all 4 MCP tools)
.venv/bin/python test_mcp_client.py
```

This will:
- Create a demo session
- List all sessions
- Save progress entries
- Resume the session
- Show you the session content

### View Created Sessions

```bash
# List all session files
ls -la ~/.sessionbridge/sessions/

# View a specific session
cat ~/.sessionbridge/sessions/demo-session.md
```

## Step 2: Connect to Bob MCP

### Option A: Using Bob's MCP Configuration

1. **Locate or create Bob's MCP config file:**
   ```bash
   # Bob typically uses one of these locations:
   # ~/.bob/mcp.json
   # or check Bob's documentation for the exact path
   ```

2. **Add SessionBridge to the config:**
   ```json
   {
     "mcpServers": {
       "sessionbridge": {
         "command": "python",
         "args": ["/Users/aakshu/Code/session-bridge/sessionbridge/server.py"],
         "alwaysAllow": [
           "list_sessions",
           "resume_session",
           "new_session",
           "save_progress"
         ]
       }
     }
   }
   ```

   **Important:** If you have other MCP servers, merge this into your existing config.

3. **Restart Bob** to load the new MCP server

4. **Verify in Bob:**
   - Bob should now have access to the 4 SessionBridge tools
   - Try: "List my sessions" or "Create a new session called test"

### Option B: Direct STDIO Testing (Advanced)

Test the server directly with STDIO protocol:

```bash
# Run the server
.venv/bin/python sessionbridge/server.py

# The server will wait for JSON-RPC messages on stdin
# You can send MCP protocol messages manually (for debugging)
```

## Step 3: Test Workflow in Bob

Once connected to Bob, try this workflow:

1. **Create a session:**
   ```
   "Create a new session called 'auth-refactor' for repos /code/api and /code/auth-lib"
   ```

2. **Save progress:**
   ```
   "Save progress to auth-refactor: Found JWT issue in config.py line 42"
   ```

3. **List sessions:**
   ```
   "List all my sessions"
   ```

4. **Resume session:**
   ```
   "Resume the auth-refactor session"
   ```
   Bob will receive the full session context to continue work.

## Troubleshooting

### Server won't start
- Check Python path: `which python` or `which python3`
- Verify fastmcp is installed: `.venv/bin/pip list | grep fastmcp`
- Check for errors: `.venv/bin/python sessionbridge/server.py` (should wait for input)

### Bob can't find the server
- Verify the path in mcp.json is absolute and correct
- Check Bob's logs for MCP connection errors
- Ensure `alwaysAllow` includes all 4 tool names

### Session files not created
- Check permissions on home directory
- Verify `~/.sessionbridge/sessions/` was created
- Run test script: `.venv/bin/python sessionbridge/test_session_manager.py`

## Quick Test Commands

```bash
# Test session manager directly
.venv/bin/python sessionbridge/test_session_manager.py

# Run MCP inspector for interactive testing
.venv/bin/python -m fastmcp dev sessionbridge/server.py

# Check if sessions directory exists
ls -la ~/.sessionbridge/sessions/

# View a session file
cat ~/.sessionbridge/sessions/test-session.md
```

## Session File Location

All sessions are stored in: `~/.sessionbridge/sessions/`

Each session is a markdown file named `{session-name}.md`

You can manually edit these files if needed - they're just markdown!