# Publishing SessionBridge to PyPI with UV

## ✅ Good News!

1. **IBM GitHub Enterprise is fine!** PyPI doesn't care where your code is hosted. The repository URL is just metadata.
2. **Yes, you can use `uv` to publish!** It's actually simpler than using `twine`.

## Publishing with UV (Recommended)

### Prerequisites

```bash
# You already have uv installed!
uv --version

# Create PyPI account (if you haven't)
# Go to https://pypi.org/account/register/
```

### Step 1: Build the Package

```bash
# Clean previous builds
rm -rf dist/

# Build with uv
uv build
```

This creates:
- `dist/sessionbridge-0.1.0.tar.gz`
- `dist/sessionbridge-0.1.0-py3-none-any.whl`

### Step 2: Get PyPI API Token

1. Go to https://pypi.org/manage/account/token/
2. Create a new API token
3. Scope: "Entire account" (or specific to sessionbridge after first upload)
4. Copy the token (starts with `pypi-`)

### Step 3: Configure UV with PyPI Token

```bash
# Set PyPI token as environment variable
export UV_PUBLISH_TOKEN="pypi-your-token-here"

# Or create ~/.pypirc (more permanent)
cat > ~/.pypirc << EOF
[pypi]
username = __token__
password = pypi-your-token-here
EOF
```

### Step 4: Publish to PyPI

```bash
# Publish with uv
uv publish
```

That's it! UV handles everything automatically.

## IBM GitHub Enterprise Considerations

### What Works

✅ **Publishing to PyPI** - No issues! PyPI is public, your repo can be private.
✅ **Repository URL** - Can point to github.ibm.com (just metadata)
✅ **Source code** - Packaged in the wheel, not fetched from GitHub
✅ **uvx installation** - Works perfectly, downloads from PyPI

### What to Update

1. **Update pyproject.toml URLs** (already done):
   ```toml
   [project.urls]
   Homepage = "https://github.ibm.com/yourusername/sessionbridge"
   Repository = "https://github.ibm.com/yourusername/sessionbridge"
   ```

2. **Update README.md** - Replace GitHub URLs with your IBM GitHub URLs

### Access Considerations

⚠️ **If your IBM GitHub is private:**
- PyPI package will be **public** (anyone can install)
- Source code in package is **public** (included in wheel)
- Repository URL points to **private** IBM GitHub (users can't access)

**Options:**
1. **Keep it public** - Most common for open source
2. **Make repo public on IBM GitHub** - If allowed by policy
3. **Use public GitHub mirror** - Create public mirror on github.com
4. **Remove repository URLs** - Just don't include them in pyproject.toml

## Testing Before Publishing

### Test Locally

```bash
# Install in development mode
uv pip install -e .

# Test the command
sessionbridge

# Or test as module
python -m sessionbridge
```

### Test with TestPyPI (Recommended)

```bash
# Build
uv build

# Publish to TestPyPI
uv publish --publish-url https://test.pypi.org/legacy/

# Test installation
uv pip install --index-url https://test.pypi.org/simple/ sessionbridge

# Test with uvx
uvx --from https://test.pypi.org/simple/ sessionbridge
```

## Complete Publishing Workflow with UV

```bash
# 1. Clean and build
rm -rf dist/
uv build

# 2. Check the build (optional)
ls -lh dist/

# 3. Test locally
uv pip install -e .
sessionbridge  # Should work

# 4. Publish to TestPyPI (optional but recommended)
export UV_PUBLISH_TOKEN="pypi-your-testpypi-token"
uv publish --publish-url https://test.pypi.org/legacy/

# 5. Test from TestPyPI
uvx --from https://test.pypi.org/simple/ sessionbridge

# 6. Publish to real PyPI
export UV_PUBLISH_TOKEN="pypi-your-real-token"
uv publish

# 7. Verify
uvx sessionbridge
```

## UV vs Traditional Tools

| Task | Traditional | UV |
|------|-------------|-----|
| Build | `python -m build` | `uv build` |
| Publish | `twine upload dist/*` | `uv publish` |
| Install | `pip install` | `uv pip install` |
| Run | `uvx` | `uvx` (same!) |

**UV is simpler and faster!**

## After Publishing

Users can install with:

```bash
# No setup needed!
uvx sessionbridge

# Or traditional install
pip install sessionbridge
uv pip install sessionbridge
```

Bob configuration:
```json
{
  "mcpServers": {
    "sessionbridge": {
      "command": "uvx",
      "args": ["sessionbridge"],
      "alwaysAllow": ["list_sessions", "resume_session", "new_session", 
                      "save_progress", "end_session", "add_repos_to_session"]
    }
  }
}
```

## Troubleshooting

### "uv: command not found"
```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### "Authentication failed"
- Check your token starts with `pypi-`
- Verify token is set: `echo $UV_PUBLISH_TOKEN`
- Try using `~/.pypirc` instead

### "Package already exists"
- Increment version in `pyproject.toml`
- Rebuild: `uv build`
- Publish again: `uv publish`

### "IBM GitHub URL not accessible"
This is fine! The URL is just metadata. Users install from PyPI, not GitHub.

## IBM-Specific Considerations

### Legal/Compliance
- ✅ Check if you can publish IBM code to public PyPI
- ✅ Ensure no proprietary IBM code included
- ✅ MIT License is appropriate
- ✅ Get approval if required by IBM policy

### Branding
- Consider using IBM email in authors (already done)
- Add IBM copyright if required
- Mention IBM in README if appropriate

### Support
- Decide on support model (personal vs IBM-backed)
- Set expectations in README
- Consider using IBM GitHub issues (if public)

## Quick Reference

```bash
# Build
uv build

# Publish to TestPyPI
UV_PUBLISH_TOKEN="pypi-test-token" uv publish --publish-url https://test.pypi.org/legacy/

# Publish to PyPI
UV_PUBLISH_TOKEN="pypi-real-token" uv publish

# Test
uvx sessionbridge
```

## Next Steps

1. ✅ Update `pyproject.toml` with your IBM GitHub username
2. ✅ Get PyPI account and API token
3. ✅ Test locally: `uv pip install -e .`
4. ✅ Build: `uv build`
5. ✅ Publish to TestPyPI (optional)
6. ✅ Publish to PyPI: `uv publish`
7. ✅ Test: `uvx sessionbridge`
8. ✅ Update Bob config
9. ✅ Celebrate! 🎉

---

**UV makes publishing simple! Just `uv build` and `uv publish`.**