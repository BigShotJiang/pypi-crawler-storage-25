import paho.mqtt.client as paho
import ssl
import time
import json
import threading

from typing import Callable, Any

from ..const.event import Event

from ..data.mqttFilterData import MqttFilterData
from ..data.mainData import MainData

from ..cdrutils.cdrUtil import CDRUtil
from ..cdrutils.log import CDRLog




class MqttVar :

    KEY_TOPIC   :str = "topic"

    def __init__(self, eventCallback:Callable[[int, Any], None]) :
    
        self._eventCallback            :Callable[[int, Any], None] = eventCallback
        self._mqttClient               :paho.Client                = None   
        
        self._readPacket               :dict                       = None 
        self._readPacketList           :list[dict]                 = []

    

    def __del__(self) :
        if self._mqttClient != None:
            #self._mqttClient.loop_stop()  # loop를 확실히 중단!
            self._mqttClient.disconnect()
            self._mqttClient.on_message = None  # 메시지 콜백도 제거해줘서 안전하게!
            self._mqttClient = None

        CDRLog.print('MQTTVar instance is deleted.')



    def connect(self, addr:str, port:int, userId:str, userPW:str, topics : list, filter:MqttFilterData = None):
        max_retries = 5
        retry_count = 0

        while retry_count < max_retries: #250605
            try:
                self._mqttAddr = addr
                self._mqttPort = port
                self._mqttUserId = userId
                self._mqttUserPW = userPW
                self._mqttTopics = topics

                self._mqttClient = paho.Client(paho.CallbackAPIVersion.VERSION2)
                self._mqttClient.tls_set(tls_version=ssl.PROTOCOL_TLS)
                self._mqttClient.username_pw_set(userId, userPW)
                self._mqttClient.on_connect = self.onMQTTConnect
                self._mqttClient.on_disconnect = self.onMQTTDisconnect
                self._mqttClient.on_subscribe = self.onMQTTSubscribe
                self._mqttClient.on_message = self.onMqttMsgCallback

                self._mqttClient.connect(addr, port)
                #self._mqttClient.loop_start()
                
                # 변경 후 260508 - loop_start() 대신 별도의 스레드에서 loop_forever() 실행하도록 수정
                self._mqttClient.connect(addr, port)

                def _run_loop():
                    self._mqttClient.loop_forever()

                t = threading.Thread(target=_run_loop, daemon=True)
                t.start()
            
                return  # 연결 성공 시 함수 종료

            except Exception as e:
                retry_count += 1
                CDRLog.print(f"MQTT 연결 실패 {retry_count}/{max_retries}: {e}")
                time.sleep(2)  # 재시도 간격

        # 5번 모두 실패 시 프로그램 종료 이벤트 발생
        if MainData.isRunningTPMProgram and self._eventCallback is not None:
            self._eventCallback(Event.COMM_VAR_FAILED_TO_CONNECT, self)
        self._mqttClient = None
        
    def disconnect(self):
        if self._mqttClient is not None:
            #self._mqttClient.loop_stop()
            self._mqttClient.disconnect()
            self._mqttClient.on_message = None
            self._mqttClient = None
            
    #250414 4차개발 - topic에 매장번호 추가하면서 MQTT 필터 불필요
    # def setSubscribeFilter(self, filter:MqttFilterData):
    #     '''
    #     구독 데이터 필터 설정
    #     '''

    #     self._mqttFilter = filter



    # def write(self, topic:str, msg:str) :
    #     #print(f"write mqtt data : {topic} / {msg}")
    #     try : 
    #         if self._mqttClient != None:

    #             self._mqttClient.publish(topic, msg, 1)
    #             return True
            
    #         else:
    #             return False            
    #     except :
    #         return False
        
    #260212 수정 
    def write(self, topic:str, msg:Any) :

        if msg is None:
            payload = ''
        elif isinstance(msg, str):
            payload = msg.replace("'", '"')   # MQTT 발행시에는 작은따옴표가 아닌 큰따옴표로 감싸야 함
        else:
            try:
                payload = json.dumps(msg, ensure_ascii=False)
            except Exception:
                payload = str(msg).replace("'", '"')
        try:
            if self._mqttClient != None:
                self._mqttClient.publish(topic, payload, 1)
                return True
            else:
                return False
        except Exception:
            return False

    def clearReadPacket(self):

        self._readPacketList   = []
        self._readPacket       = None



    def read(self) -> dict:
        '''
        단일 변수에 저장된 패킷 읽기
        '''
        if self._readPacket == None:
            return None
        else:
            # read된 패킷 정보는 재사용 안되도록 호출 뒤에 초기화
            returnValue:dict = self._readPacket.copy()
            self._readPacket = None
        
            return returnValue
    


    def readFirstPacket(self) -> dict:
        '''
        리스트 변수에 저장된 첫번째 패킷 읽기
        '''

        if self._readPacketList == None or len(self._readPacketList) == 0:
            return None
        
        else:
            # CDRLog.print(f"get mqtt packet from list.... remains : {len(self._readPacketList) - 1}")
            return self._readPacketList.pop(0)
        
      

    def isConnected(self) -> bool:

        if self._mqttClient != None and self._mqttClient.is_connected() == True:
            return True
        else:
            return False
        


    def onMQTTConnect(self, client, userdata, flags, rc, properties = None):
        
        for topic in self._mqttTopics :
            
            self._mqttClient.subscribe(topic, 1)



    def onMQTTDisconnect(self, client, userdata, flags, rc , properties = None):
        '''
        # MQTT 연결 해제 함수
        '''
        if self._mqttClient is not None: 
            #self._mqttClient.loop_stop()
            self._mqttClient.on_message = None
            self._mqttClient = None
        CDRLog.print("MqttVar disconnect B")  # 로그용!
        #250605
        try:
            CDRLog.print("MQTT 재연결 시도 1/1...")
            self.connect(self._mqttAddr, self._mqttPort, self._mqttUserId, self._mqttUserPW, self._mqttTopics)
            if self.isConnected():
                CDRLog.print("MQTT 재연결 성공")
                return
        except Exception as e:
            CDRLog.print(f"MQTT 재연결 실패: {e}")

            # 프로그램 실행 중에 mqtt 통신이 disconnect 된 상황 -> 의도하지 않은 에러 상황으로 판단하여, 이벤트 발생! 
            if MainData.isRunningTPMProgram == True and self._eventCallback != None:
                self._eventCallback(Event.COMM_VAR_DISCONNECTED, self)




    def onMQTTSubscribe(self, client, userdata, mid, granted_qos, properties = None):
        '''
        # MQTT topic 구독 함수
        '''
        CDRLog.print("MQTT Subscribed")



    def onMqttMsgCallback(self, client, userdata, msg : paho.MQTTMessage):       
        '''
        # MQTT 메세지 수신 콜백 함수
        '''    

        # 수신 메세지를 json형식으로 변환
        msgDict:dict = CDRUtil.strToJson(msg.payload.decode())
        
        # 예외처리 : 필터가 존재하고, read된 데이터가 필터의 key값을 가지고 있고, 데이터와 필터의 value값이 다르면 skip
        #250414 4차개발 - topic에 매장번호 추가하면서 MQTT 필터 불필요
        # if self._mqttFilter != None:    
            
        #     key     :str    = self._mqttFilter.getKey()
        #     value           = self._mqttFilter.getValue()
            
        #     if key in msgDict: 
                
        #         if msgDict[key] != value:
        #             return
        
        msgDict[MqttVar.KEY_TOPIC]      = msg.topic
            
        self._readPacket               = msgDict
            
        # 리스트의 read 패킷 개수가 100개가 넘지 않도록 조절 
        if len(self._readPacketList) > 100:
            self._readPacketList.pop(0)

        self._readPacketList.append(msgDict.copy())