# tracine-guard

Production-grade security hooks for Claude Code.

> This is a placeholder release. The full package is coming soon.
>
> See [tracinehq/tracine-guard](https://github.com/tracinehq/tracine-guard) for details.
