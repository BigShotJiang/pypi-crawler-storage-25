"""Production-grade security hooks for Claude Code."""

__version__ = "0.0.1"
