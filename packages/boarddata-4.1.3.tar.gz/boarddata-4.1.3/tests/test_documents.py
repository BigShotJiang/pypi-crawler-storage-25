"""Tests for DocumentMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._documents import DocumentMixin
    from boarddata._base import Base

    class TestClient(DocumentMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestCreateDocument:
    def test_sends_required_and_optional(self):
        c = make_client()
        c._request.return_value = {"id": "doc1", "title": "Report"}
        c.create_document("Annual Report", "annual_report", fiscal_year=2024, isin="FR000")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["title"] == "Annual Report"
        assert payload["document_type"] == "annual_report"
        assert payload["fiscal_year"] == 2024


class TestGetPresignedUrl:
    def test_calls_correct_path(self):
        c = make_client()
        c._request.return_value = {"url": "https://s3.example.com/doc.pdf"}
        c.get_document_presigned_url("doc-uuid")
        args, _ = c._request.call_args
        assert args == ("GET", "documents/doc-uuid/presigned-url/")
