"""Tests for DirectorMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._directors import DirectorMixin
    from boarddata._base import Base

    class TestClient(DirectorMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestListDirectors:
    def test_passes_common_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(company="uuid1", person="uuid2", page=1)
        _, kwargs = c._request.call_args
        assert kwargs["params"]["company"] == "uuid1"
        assert kwargs["params"]["person"] == "uuid2"

    def test_passes_advanced_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(indexes="CAC40", gender="F", independence="yes")
        _, kwargs = c._request.call_args
        assert kwargs["params"]["indexes"] == "CAC40"
        assert kwargs["params"]["gender"] == "F"


class TestCreateDirectorCompensation:
    def test_sends_token_fields(self):
        c = make_client()
        c._request.return_value = {"id": "comp1", "fiscal_year": 2024}
        c.create_director_compensation(
            "dir-uuid", 2024, "REAL", token_personal="15000.00", currency="EUR"
        )
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["token_personal"] == "15000.00"
        assert payload["nature"] == "REAL"
        assert "fixed" not in payload  # comex field, not board


class TestUpsertDirector:
    def test_returns_upsert_result(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 0, "results": []},
            {"id": "new-uuid", "title": "Director"},
        ]
        result = c.upsert_director("comp-uuid", "pers-uuid", title="Director")
        assert result["action"] == "created"
        assert result["id"] == "new-uuid"
