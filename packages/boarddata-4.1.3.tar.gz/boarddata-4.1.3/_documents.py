"""Document methods."""

from __future__ import annotations

from typing import Any

from .types.core import PaginatedResponse
from .types.documents import DocumentDetail, PresignedUrlResponse


class DocumentMixin:
    """Document API methods."""

    def list_documents(self, **params: Any) -> PaginatedResponse:
        """List documents.

        Args:
            isin: Filter by company ISIN.
            document_type: Filter by document type.
            fiscal_year: Filter by fiscal year.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with DocumentDetail results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("documents/", **params)  # type: ignore[attr-defined]

    def get_document(self, uid: str) -> DocumentDetail:
        """Retrieve a document by UUID.

        Args:
            uid: Document UUID.

        Returns:
            DocumentDetail with full document data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"documents/{uid}/")  # type: ignore[attr-defined]

    def create_document(
        self,
        title: str,
        document_type: str,
        *,
        publication_date: str | None = None,
        fiscal_year: int | None = None,
        isin: str | None = None,
        language: str | None = None,
        url: str | None = None,
    ) -> DocumentDetail:
        """Create a document.

        Args:
            title: Document title.
            document_type: Type of document (e.g. ``"annual_report"``).
            publication_date: Publication date (``"YYYY-MM-DD"``).
            fiscal_year: Fiscal year the document covers.
            isin: Company ISIN.
            language: Document language code.
            url: URL to the document.

        Returns:
            Created DocumentDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            title=title,
            document_type=document_type,
            publication_date=publication_date,
            fiscal_year=fiscal_year,
            isin=isin,
            language=language,
            url=url,
        )
        return self._post("documents/", payload)  # type: ignore[attr-defined]

    def get_document_presigned_url(
        self, uid: str, *, page: int | None = None,
    ) -> PresignedUrlResponse:
        """Get a time-limited presigned URL for the document's S3 object.

        Args:
            uid: Document UUID.
            page: Optional page number for multi-page documents.

        Returns:
            PresignedUrlResponse with ``url`` field.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"documents/{uid}/presigned-url/", page=page)  # type: ignore[attr-defined]

    def update_document(
        self,
        uid: str,
        *,
        title: str | None = None,
        document_type: str | None = None,
        publication_date: str | None = None,
        fiscal_year: int | None = None,
        isin: str | None = None,
        language: str | None = None,
        url: str | None = None,
    ) -> DocumentDetail:
        """Partial update a document.

        Args:
            uid: Document UUID.
            title: Document title.
            document_type: Type of document.
            publication_date: Publication date.
            fiscal_year: Fiscal year.
            isin: Company ISIN.
            language: Document language code.
            url: URL to the document.

        Returns:
            Updated DocumentDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            title=title,
            document_type=document_type,
            publication_date=publication_date,
            fiscal_year=fiscal_year,
            isin=isin,
            language=language,
            url=url,
        )
        return self._patch(f"documents/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_document(self, uid: str) -> None:
        """Delete a document.

        Args:
            uid: Document UUID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"documents/{uid}/")  # type: ignore[attr-defined]
