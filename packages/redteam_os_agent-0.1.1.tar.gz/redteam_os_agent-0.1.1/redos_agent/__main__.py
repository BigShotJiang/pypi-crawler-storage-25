from redos_agent.client import RedOSAgentClient
from redos_agent.config import AgentConfig
from redos_agent.runner import RedOSAgentRunner


def main() -> int:
    config = AgentConfig.from_env()
    client = RedOSAgentClient(api_url=config.api_url, worker_token=config.worker_token)
    runner = RedOSAgentRunner(config=config, client=client)
    runner.run_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
