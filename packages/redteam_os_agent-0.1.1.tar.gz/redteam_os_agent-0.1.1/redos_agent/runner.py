from __future__ import annotations

import json
import mimetypes
import os
import queue
import signal
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any, TextIO

from redos_agent.client import RedOSAgentClient
from redos_agent.config import AgentConfig


@dataclass
class CommandSpec:
    command: str
    timeout_seconds: int


@dataclass
class StreamChunk:
    stream: str
    chunk: str


class RedOSAgentRunner:
    def __init__(self, *, config: AgentConfig, client: RedOSAgentClient) -> None:
        self.config = config
        self.client = client
        self._stop = False
        signal.signal(signal.SIGTERM, self._handle_stop)
        signal.signal(signal.SIGINT, self._handle_stop)

    def run_forever(self) -> None:
        print(f"Starting {self.config.name}; API={self.config.api_url}", flush=True)
        self._heartbeat(status="IDLE")
        while not self._stop:
            try:
                claim = self.client.claim_task()
                if claim is None:
                    self._heartbeat(status="IDLE")
                    time.sleep(self.config.claim_interval_seconds)
                    continue
                self._run_claim(claim)
            except Exception as exc:  # noqa: BLE001 - agent should keep polling after transient API failures.
                print(f"agent loop error: {exc}", flush=True)
                time.sleep(self.config.claim_interval_seconds)

    def _run_claim(self, claim: dict[str, Any]) -> None:
        task = claim["task"]
        execution = claim["execution"]
        task_id = task["id"]
        execution_id = execution["id"]
        artifact_paths = self._normalize_artifact_paths(
            task.get("output_artifact_paths") or task.get("artifact_paths")
        )
        command_spec = self._parse_command(task["command_payload"])
        setup_script = str(claim.get("setup_script") or "").strip()
        resolved_environment = claim.get("resolved_environment") or {}
        self._heartbeat(status="BUSY", active_task_id=task_id, active_execution_id=execution_id)
        self.client.progress(
            task_id=task_id,
            execution_id=execution_id,
            result={"agent": self.config.name, "phase": "started"},
            error_message=f"Starting command: {command_spec.command}",
        )
        print(f"claimed task={task_id} execution={execution_id}", flush=True)

        stdout_capture = ""
        stderr_capture = ""
        exit_code = 1
        cancelled = False
        started_at = time.monotonic()
        chunks: queue.Queue[StreamChunk] = queue.Queue()

        self._download_input_artifacts(task_id=task_id, execution_id=execution_id, task=task)

        env = os.environ.copy()
        if isinstance(resolved_environment, dict):
            for k, v in resolved_environment.items():
                env[str(k)] = str(v)

        shell_payload = self._combine_shell_payload(
            setup_script=setup_script,
            command=command_spec.command,
        )

        process = subprocess.Popen(
            shell_payload,
            shell=True,
            executable="/bin/sh",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            text=True,
            bufsize=1,
        )
        readers = [
            threading.Thread(target=self._read_stream, args=("stdout", process.stdout, chunks), daemon=True),
            threading.Thread(target=self._read_stream, args=("stderr", process.stderr, chunks), daemon=True),
        ]
        for reader in readers:
            reader.start()

        last_cancel_check = 0.0
        last_heartbeat = 0.0
        try:
            while True:
                now = time.monotonic()
                try:
                    chunk = chunks.get(timeout=0.2)
                    if chunk.stream == "stdout":
                        stdout_capture = self._append_capture(stdout_capture, chunk.chunk)
                        self.client.progress(task_id=task_id, execution_id=execution_id, stdout=chunk.chunk)
                    else:
                        stderr_capture = self._append_capture(stderr_capture, chunk.chunk)
                        self.client.progress(task_id=task_id, execution_id=execution_id, stderr=chunk.chunk)
                except queue.Empty:
                    pass

                if now - last_heartbeat >= self.config.heartbeat_interval_seconds:
                    last_heartbeat = now
                    self._heartbeat(status="BUSY", active_task_id=task_id, active_execution_id=execution_id)

                if now - last_cancel_check >= self.config.cancel_check_seconds:
                    last_cancel_check = now
                    status = self.client.task_status(task_id=task_id, execution_id=execution_id)
                    if status.get("cancelled"):
                        cancelled = True
                        self._terminate_process(process)
                        break

                if time.monotonic() - started_at > command_spec.timeout_seconds:
                    self._terminate_process(process)
                    raise TimeoutError(f"Command timed out after {command_spec.timeout_seconds} seconds.")

                if process.poll() is not None and chunks.empty():
                    break

            exit_code = process.wait(timeout=5)
            for reader in readers:
                reader.join(timeout=1)
            while not chunks.empty():
                chunk = chunks.get_nowait()
                if chunk.stream == "stdout":
                    stdout_capture = self._append_capture(stdout_capture, chunk.chunk)
                    self.client.progress(task_id=task_id, execution_id=execution_id, stdout=chunk.chunk)
                else:
                    stderr_capture = self._append_capture(stderr_capture, chunk.chunk)
                    self.client.progress(task_id=task_id, execution_id=execution_id, stderr=chunk.chunk)

            result = {
                "agent": self.config.name,
                "command": command_spec.command,
                "duration_seconds": round(time.monotonic() - started_at, 3),
                "cancelled": cancelled,
            }
            if cancelled:
                print(f"task cancelled task={task_id} execution={execution_id}", flush=True)
                return
            self._upload_artifacts(task_id=task_id, execution_id=execution_id, artifact_paths=artifact_paths)
            if exit_code == 0:
                self.client.complete(
                    task_id=task_id,
                    execution_id=execution_id,
                    stdout=stdout_capture,
                    stderr=stderr_capture,
                    result=result,
                    exit_code=exit_code,
                )
            else:
                self.client.fail(
                    task_id=task_id,
                    execution_id=execution_id,
                    stdout=stdout_capture,
                    stderr=stderr_capture,
                    result=result,
                    exit_code=exit_code,
                    error_message=stderr_capture.strip() or f"Command exited with code {exit_code}.",
                )
        except Exception as exc:  # noqa: BLE001 - report task failure and continue the agent loop.
            self._terminate_process(process)
            self.client.fail(
                task_id=task_id,
                execution_id=execution_id,
                stdout=stdout_capture,
                stderr=stderr_capture,
                result={"agent": self.config.name, "command": command_spec.command},
                exit_code=exit_code,
                error_message=str(exc),
            )
        finally:
            self._heartbeat(status="IDLE")

    def _heartbeat(
        self,
        *,
        status: str,
        active_task_id: str | None = None,
        active_execution_id: str | None = None,
    ) -> None:
        self.client.heartbeat(
            status=status,
            capabilities={
                "agent_name": self.config.name,
                "runtime": "python-subprocess",
                "execution_modes": ["WORKER_RUNTIME"],
                "active_task_id": active_task_id,
                "active_execution_id": active_execution_id,
            },
        )

    def _parse_command(self, command_payload: str) -> CommandSpec:
        command = command_payload
        timeout_seconds = self.config.command_timeout_seconds
        try:
            parsed = json.loads(command_payload)
        except json.JSONDecodeError:
            parsed = None
        if isinstance(parsed, dict):
            if parsed.get("type", "shell") != "shell":
                raise ValueError("Only shell task payloads are supported by this agent.")
            command = str(parsed.get("command") or "")
            timeout_seconds = int(parsed.get("timeout_seconds") or timeout_seconds)
        if not command.strip():
            raise ValueError("Task command payload is empty.")
        return CommandSpec(command=command, timeout_seconds=timeout_seconds)

    def _download_input_artifacts(self, *, task_id: str, execution_id: str, task: dict[str, Any]) -> None:
        configs = task.get("input_artifact_configs")
        if not configs:
            return

        try:
            for config in configs:
                artifact_id = config.get("artifact_id")
                target_path = config.get("local_path")
                if not artifact_id or not target_path:
                    continue

                content = self.client.download_input_artifact(task_id=task_id, artifact_id=artifact_id)
                
                # Ensure local directory exists
                target_dir = os.path.dirname(target_path)
                if target_dir:
                    os.makedirs(target_dir, exist_ok=True)

                with open(target_path, "wb") as f:
                    f.write(content)
                
                self.client.progress(
                    task_id=task_id,
                    execution_id=execution_id,
                    error_message=f"Downloaded input artifact to {target_path}",
                )
        except Exception as exc:
            print(f"Failed to download input artifacts: {exc}")
            self.client.progress(
                task_id=task_id,
                execution_id=execution_id,
                error_message=f"Failed to download input artifacts: {exc}",
            )

    def _upload_artifacts(self, *, task_id: str, execution_id: str, artifact_paths: list[str]) -> None:
        for path in artifact_paths:
            filename = os.path.basename(path.rstrip("/")) or "artifact"
            if not os.path.exists(path):
                self.client.upload_artifact(
                    task_id=task_id,
                    execution_id=execution_id,
                    requested_path=path,
                    filename=filename,
                    status="MISSING",
                    error_message="Artifact file does not exist.",
                )
                continue
            if not os.path.isfile(path):
                self.client.upload_artifact(
                    task_id=task_id,
                    execution_id=execution_id,
                    requested_path=path,
                    filename=filename,
                    status="FAILED",
                    error_message="Artifact path is not a regular file.",
                )
                continue
            try:
                size = os.path.getsize(path)
                if size > self.config.artifact_max_bytes:
                    self.client.upload_artifact(
                        task_id=task_id,
                        execution_id=execution_id,
                        requested_path=path,
                        filename=filename,
                        status="FAILED",
                        error_message=f"Artifact exceeds maximum size of {self.config.artifact_max_bytes} bytes.",
                    )
                    continue
                with open(path, "rb") as handle:
                    content = handle.read()
                self.client.upload_artifact(
                    task_id=task_id,
                    execution_id=execution_id,
                    requested_path=path,
                    filename=filename,
                    status="COLLECTED",
                    content=content,
                    content_type=mimetypes.guess_type(path)[0] or "application/octet-stream",
                )
            except OSError as exc:
                self.client.upload_artifact(
                    task_id=task_id,
                    execution_id=execution_id,
                    requested_path=path,
                    filename=filename,
                    status="FAILED",
                    error_message=str(exc),
                )

    def _normalize_artifact_paths(self, paths) -> list[str]:
        normalized = []
        for path in paths or []:
            value = str(path or "").strip()
            if value:
                normalized.append(value)
        return sorted(set(normalized))

    def _read_stream(self, stream: str, pipe: TextIO | None, chunks: queue.Queue[StreamChunk]) -> None:
        if pipe is None:
            return
        try:
            for line in iter(pipe.readline, ""):
                if line:
                    chunks.put(StreamChunk(stream=stream, chunk=line))
        finally:
            pipe.close()

    def _append_capture(self, existing: str, chunk: str) -> str:
        max_chars = self.config.result_capture_bytes
        combined = f"{existing}{chunk}"
        if len(combined) <= max_chars:
            return combined
        return combined[-max_chars:]

    def _combine_shell_payload(self, *, setup_script: str, command: str) -> str:
        lines = ["set -e"]
        if setup_script:
            lines.append(setup_script)
        lines.append(command)
        return "\n".join(lines)

    def _terminate_process(self, process: subprocess.Popen) -> None:
        if process.poll() is not None:
            return
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)

    def _handle_stop(self, signum, frame) -> None:  # noqa: ANN001 - signal callback signature is fixed.
        self._stop = True
