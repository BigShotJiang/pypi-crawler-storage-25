import os
from dataclasses import dataclass


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer.") from exc
    if parsed <= 0:
        raise ValueError(f"{name} must be greater than zero.")
    return parsed


@dataclass(frozen=True)
class AgentConfig:
    api_url: str
    worker_token: str
    name: str
    heartbeat_interval_seconds: int
    claim_interval_seconds: int
    cancel_check_seconds: int
    command_timeout_seconds: int
    result_capture_bytes: int
    artifact_max_bytes: int

    @classmethod
    def from_env(cls) -> "AgentConfig":
        api_url = os.getenv("REDOS_AGENT_API_URL", "").rstrip("/")
        worker_token = os.getenv("REDOS_AGENT_WORKER_TOKEN", "")
        if not api_url:
            raise ValueError("REDOS_AGENT_API_URL is required.")
        if not worker_token:
            raise ValueError("REDOS_AGENT_WORKER_TOKEN is required.")
        return cls(
            api_url=api_url,
            worker_token=worker_token,
            name=os.getenv("REDOS_AGENT_NAME", "redos-agent"),
            heartbeat_interval_seconds=_env_int("REDOS_AGENT_HEARTBEAT_INTERVAL_SECONDS", 20),
            claim_interval_seconds=_env_int("REDOS_AGENT_CLAIM_INTERVAL_SECONDS", 5),
            cancel_check_seconds=_env_int("REDOS_AGENT_CANCEL_CHECK_SECONDS", 2),
            command_timeout_seconds=_env_int("REDOS_AGENT_COMMAND_TIMEOUT_SECONDS", 900),
            result_capture_bytes=_env_int("REDOS_AGENT_RESULT_CAPTURE_BYTES", 65536),
            artifact_max_bytes=_env_int("REDOS_AGENT_ARTIFACT_MAX_BYTES", 10485760),
        )
