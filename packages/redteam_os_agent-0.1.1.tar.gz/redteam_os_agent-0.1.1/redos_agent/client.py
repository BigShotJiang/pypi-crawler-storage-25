from __future__ import annotations

import base64
from typing import Any

import requests


class RedOSAgentClient:
    def __init__(self, *, api_url: str, worker_token: str, timeout: int = 30) -> None:
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Worker {worker_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "redos-agent/0.1.0",
            }
        )

    def heartbeat(self, *, status: str, capabilities: dict[str, Any]) -> dict[str, Any]:
        return self._request(
            "POST",
            "/worker/heartbeat",
            json={"status": status, "capabilities": capabilities},
        )

    def claim_task(self) -> dict[str, Any] | None:
        return self._request("POST", "/worker/tasks/claim", allow_empty=True)

    def task_status(self, *, task_id: str, execution_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            f"/worker/tasks/{task_id}/status",
            params={"execution_id": execution_id},
        )

    def progress(
        self,
        *,
        task_id: str,
        execution_id: str,
        stdout: str | None = None,
        stderr: str | None = None,
        result: dict[str, Any] | None = None,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/worker/tasks/{task_id}/progress",
            json=self._compact(
                {
                "execution_id": execution_id,
                "stdout": stdout,
                "stderr": stderr,
                "result": result,
                "error_message": error_message,
                }
            ),
        )

    def complete(
        self,
        *,
        task_id: str,
        execution_id: str,
        stdout: str,
        stderr: str,
        result: dict[str, Any],
        exit_code: int,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/worker/tasks/{task_id}/complete",
            json=self._compact(
                {
                "execution_id": execution_id,
                "stdout": stdout,
                "stderr": stderr,
                "result": result,
                "exit_code": exit_code,
                }
            ),
        )

    def fail(
        self,
        *,
        task_id: str,
        execution_id: str,
        stdout: str,
        stderr: str,
        result: dict[str, Any],
        exit_code: int,
        error_message: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/worker/tasks/{task_id}/fail",
            json=self._compact(
                {
                "execution_id": execution_id,
                "stdout": stdout,
                "stderr": stderr,
                "result": result,
                "exit_code": exit_code,
                "error_message": error_message,
                }
            ),
        )

    def list_input_artifacts(self, *, task_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/worker/tasks/{task_id}/input-artifacts") or []

    def download_input_artifact(self, *, task_id: str, artifact_id: str) -> bytes:
        response = self.session.request(
            "GET",
            f"{self.api_url}/worker/tasks/{task_id}/input-artifacts/{artifact_id}/download",
            timeout=self.timeout,
        )
        if response.status_code >= 400:
            raise RuntimeError(f"Failed to download input artifact {artifact_id}: {response.status_code}")
        return response.content

    def upload_artifact(
        self,
        *,
        task_id: str,
        execution_id: str,
        requested_path: str,
        status: str,
        filename: str | None = None,
        content: bytes | None = None,
        content_type: str | None = None,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        content_base64 = base64.b64encode(content).decode("ascii") if content is not None else None
        return self._request(
            "POST",
            f"/worker/tasks/{task_id}/artifacts",
            json=self._compact(
                {
                "execution_id": execution_id,
                "requested_path": requested_path,
                "filename": filename,
                "status": status,
                "content_base64": content_base64,
                "content_type": content_type,
                "error_message": error_message,
                }
            ),
        )

    def _compact(self, payload: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in payload.items() if value is not None}

    def _request(self, method: str, path: str, *, allow_empty: bool = False, **kwargs) -> dict[str, Any] | None:
        response = self.session.request(
            method,
            f"{self.api_url}{path}",
            timeout=self.timeout,
            **kwargs,
        )
        if allow_empty and response.status_code == 204:
            return None
        if response.status_code >= 400:
            raise RuntimeError(f"{method} {path} failed with {response.status_code}: {response.text}")
        if response.status_code == 204 or not response.content:
            return None
        return response.json()
