from __future__ import annotations

import argparse
import getpass
import os
import shutil
import subprocess
import sys
from pathlib import Path

from redos_agent.client import RedOSAgentClient


SERVICE_NAME = "redteam-os-agent"
ENV_DIR = Path("/etc/redteam-os-agent")
ENV_PATH = ENV_DIR / "agent.env"
SERVICE_PATH = Path("/etc/systemd/system/redteam-os-agent.service")
STATE_DIR = Path("/var/lib/redteam-os-agent")


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="redteam-os-agent-install",
        description="Install and start the Redteam OS agent as a systemd service.",
    )
    parser.add_argument("--api-url", help="RedOS API base URL, for example http://localhost:5000/api")
    parser.add_argument("--worker-token", help="Worker token in rw_<worker_id>_<secret> format")
    parser.add_argument(
        "--agent-name",
        default="redos-agent-service",
        help="Agent name reported in heartbeat capabilities.",
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip the final confirmation prompt after validation.",
    )
    args = parser.parse_args()

    _require_root()
    _require_systemd()

    api_url = _prompt("RedOS API URL", default=args.api_url or "http://localhost:5000/api").rstrip("/")
    worker_token = args.worker_token or getpass.getpass("Worker token: ").strip()
    agent_name = _prompt("Agent name", default=args.agent_name).strip() or "redos-agent-service"

    print("Validating worker token with the control plane...", flush=True)
    client = RedOSAgentClient(api_url=api_url, worker_token=worker_token)
    try:
        response = client.heartbeat(
            status="IDLE",
            capabilities={
                "installer": True,
                "agent_name": agent_name,
                "runtime": "python-subprocess",
                "execution_modes": ["WORKER_RUNTIME"],
            },
        )
    except Exception as exc:  # noqa: BLE001
        print(f"Validation failed: {exc}", file=sys.stderr)
        return 1

    worker_name = response.get("name") or response.get("id") or "<unknown>"
    print(f"Validation succeeded for worker: {worker_name}", flush=True)

    if not args.yes:
        proceed = _prompt("Create and start the systemd service now? [y/N]", default="N").strip().lower()
        if proceed not in {"y", "yes"}:
            print("Aborted before writing the service.", flush=True)
            return 0

    exec_path = _resolve_exec_path()
    _write_env_file(api_url=api_url, worker_token=worker_token, agent_name=agent_name)
    _write_service_file(exec_path=exec_path)
    _reload_and_start_service()

    print(f"Service {SERVICE_NAME} installed and started.", flush=True)
    print(f"Environment file: {ENV_PATH}", flush=True)
    print(f"Service file: {SERVICE_PATH}", flush=True)
    print(f"Check status with: systemctl status {SERVICE_NAME}", flush=True)
    print(f"View logs with: journalctl -u {SERVICE_NAME} -f", flush=True)
    return 0


def _require_root() -> None:
    if os.geteuid() != 0:
        raise SystemExit("Please run redteam-os-agent-install with sudo or as root.")


def _require_systemd() -> None:
    if shutil.which("systemctl") is None:
        raise SystemExit("systemctl was not found. The installer currently supports systemd hosts only.")


def _prompt(label: str, *, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def _resolve_exec_path() -> str:
    exec_path = shutil.which("redteam-os-agent")
    if exec_path:
        return exec_path
    return f"{sys.executable} -m redos_agent"


def _write_env_file(*, api_url: str, worker_token: str, agent_name: str) -> None:
    ENV_DIR.mkdir(parents=True, exist_ok=True)
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    content = "\n".join(
        [
            f'REDOS_AGENT_API_URL="{api_url}"',
            f'REDOS_AGENT_WORKER_TOKEN="{worker_token}"',
            f'REDOS_AGENT_NAME="{agent_name}"',
            'REDOS_AGENT_HEARTBEAT_INTERVAL_SECONDS="20"',
            'REDOS_AGENT_CLAIM_INTERVAL_SECONDS="5"',
            'REDOS_AGENT_CANCEL_CHECK_SECONDS="2"',
            'REDOS_AGENT_COMMAND_TIMEOUT_SECONDS="900"',
            'REDOS_AGENT_RESULT_CAPTURE_BYTES="65536"',
            'REDOS_AGENT_ARTIFACT_MAX_BYTES="10485760"',
            "",
        ]
    )
    ENV_PATH.write_text(content, encoding="utf-8")
    os.chmod(ENV_PATH, 0o600)


def _write_service_file(*, exec_path: str) -> None:
    service = f"""[Unit]
Description=Redteam OS Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory={STATE_DIR}
EnvironmentFile={ENV_PATH}
ExecStart={exec_path}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
    SERVICE_PATH.write_text(service, encoding="utf-8")
    os.chmod(SERVICE_PATH, 0o644)


def _reload_and_start_service() -> None:
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "enable", "--now", SERVICE_NAME], check=True)


if __name__ == "__main__":
    raise SystemExit(main())
