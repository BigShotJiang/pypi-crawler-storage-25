# tests/test_scale.py
"""
Scale-correctness tests.

Verifies that BMC produces correct results across varying workload
parameters (M, K, D, C, zones, depth) and that performance scales
proportionally — not pathologically.

All tests use small data (≤5K samples). If correctness holds at 1K
and 2K with proportional scaling, it holds at 100K.
"""

import time
import numpy as np
import pytest
from bmc.core.cell import BMCCell
from bmc.core.seeding import kmeanspp_init
from bmc.core.geodesic import build_tsp_path
from bmc.composition.layer import BMCLayer
from bmc.composition.sequential import BMCNetwork
from bmc.composition.skip import BMCSkipConnection
from bmc.composition.rvq import SequentialRVQ
from bmc.observation.tabular import TabularObservationSpace
from bmc.metrics.l2 import L2Metric


def _make_binary(M, D, separation=5.0, rng_seed=42):
    rng = np.random.default_rng(rng_seed)
    half = M // 2
    X = rng.normal(0, 1, (M, D)).astype(np.float32)
    X[:half] += separation
    y = np.array([0] * half + [1] * (M - half), dtype=np.int32)
    return X, y


def _make_multiclass(M, D, C, separation=5.0, rng_seed=42):
    rng = np.random.default_rng(rng_seed)
    per_class = M // C
    Xs, ys = [], []
    for c in range(C):
        center = np.zeros(D, dtype=np.float32)
        center[:min(D, 10)] = c * separation
        Xs.append(rng.normal(0, 0.5, (per_class, D)).astype(np.float32) + center)
        ys.extend([c] * per_class)
    return np.vstack(Xs), np.array(ys, dtype=np.int32)


# ── Proportional scaling ─────────────────────────────────────────────────────

def test_time_scales_proportionally_with_M():
    """Doubling M should roughly double time, not 10x it."""
    D, K = 25, 64
    X1, y1 = _make_binary(1_000, D)
    X2, y2 = _make_binary(2_000, D)

    t0 = time.perf_counter()
    c1 = BMCCell(n_clusters=K, rng=np.random.default_rng(42))
    c1.fit(X1, y1, n_classes=2)
    t1 = time.perf_counter() - t0

    t0 = time.perf_counter()
    c2 = BMCCell(n_clusters=K, rng=np.random.default_rng(42))
    c2.fit(X2, y2, n_classes=2)
    t2 = time.perf_counter() - t0

    # 2x data should take at most 4x time (generous for overhead)
    ratio = t2 / max(t1, 1e-6)
    assert ratio < 4.0, f"2x data took {ratio:.1f}x time (expected <4x)"


def test_accuracy_stable_across_M():
    """Accuracy should not degrade when M increases on the same distribution."""
    D, K = 25, 64
    X1, y1 = _make_binary(1_000, D)
    X2, y2 = _make_binary(3_000, D)

    c1 = BMCCell(n_clusters=K, rng=np.random.default_rng(42))
    c1.fit(X1, y1, n_classes=2)
    acc1 = np.mean(c1.predict(X1) == y1)

    c2 = BMCCell(n_clusters=K, rng=np.random.default_rng(42))
    c2.fit(X2, y2, n_classes=2)
    acc2 = np.mean(c2.predict(X2) == y2)

    assert acc1 >= 0.95
    assert acc2 >= 0.95
    assert acc2 >= acc1 - 0.05, "Accuracy degraded with more data"


# ── Varying K ────────────────────────────────────────────────────────────────

def test_k512_clusters():
    X, y = _make_binary(3_000, 50)
    cell = BMCCell(n_clusters=512)
    cell.fit(X, y, n_classes=2)
    assert cell.seeds_.shape == (512, 50)
    assert cell.lut_.shape == (512, 2)
    assert np.mean(cell.predict(X) == y) >= 0.95


def test_k1024_clusters():
    X, y = _make_binary(3_000, 50)
    cell = BMCCell(n_clusters=1024)
    cell.fit(X, y, n_classes=2)
    assert cell.seeds_.shape == (1024, 50)
    assert np.allclose(cell.lut_.sum(axis=1), 1.0)


# ── Varying D ────────────────────────────────────────────────────────────────

def test_d500_dimensions():
    X, y = _make_binary(2_000, 500, separation=3.0)
    cell = BMCCell(n_clusters=64)
    cell.fit(X, y, n_classes=2)
    assert cell.seeds_.shape == (64, 500)
    assert np.mean(cell.predict(X) == y) >= 0.90


def test_d1000_dimensions():
    X, y = _make_binary(1_000, 1000, separation=3.0)
    cell = BMCCell(n_clusters=32)
    cell.fit(X, y, n_classes=2)
    assert cell.predict(X).shape == (1_000,)
    assert np.mean(cell.predict(X) == y) >= 0.85


# ── Zones ────────────────────────────────────────────────────────────────────

def test_20_zones():
    X, y = _make_binary(2_000, 60)
    obs = TabularObservationSpace(n_features=60, n_zones=20)
    layer = BMCLayer(obs, n_clusters=32)
    layer.fit(X, y, n_classes=2)
    assert len(layer.layers_) == 20
    assert np.mean(layer.predict(X) == y) >= 0.90


def test_vote_matrix_shape():
    X, y = _make_binary(1_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=10)
    layer = BMCLayer(obs, n_clusters=16)
    layer.fit(X, y, n_classes=2)
    vm = layer.transform(X)
    assert vm.shape == (1_000, 10, 2)
    assert np.allclose(vm.sum(axis=2), 1.0, atol=1e-5)


# ── Deep networks ────────────────────────────────────────────────────────────

def test_3layer_network():
    X, y = _make_binary(2_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=8)
    net = BMCNetwork([
        BMCLayer(obs, n_clusters=64),
        BMCCell(n_clusters=32),
        BMCCell(n_clusters=16),
    ])
    net.fit(X, y, n_classes=2)
    assert net.predict(X).shape == (2_000,)
    assert np.mean(net.predict(X) == y) >= 0.85


def test_4layer_network():
    X, y = _make_binary(2_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=8)
    net = BMCNetwork([
        BMCLayer(obs, n_clusters=64),
        BMCCell(n_clusters=32),
        BMCCell(n_clusters=16),
        BMCCell(n_clusters=8),
    ])
    net.fit(X, y, n_classes=2)
    assert net.predict(X).shape == (2_000,)


# ── Large batch inference ────────────────────────────────────────────────────

def test_large_batch_inference():
    X_train, y_train = _make_binary(500, 30)
    cell = BMCCell(n_clusters=64)
    cell.fit(X_train, y_train, n_classes=2)
    X_test = np.random.default_rng(99).normal(0, 1, (5_000, 30)).astype(np.float32)
    assert cell.predict(X_test).shape == (5_000,)


# ── Multiclass ───────────────────────────────────────────────────────────────

def test_10_classes():
    X, y = _make_multiclass(3_000, 50, C=10)
    cell = BMCCell(n_clusters=128)
    cell.fit(X, y, n_classes=10)
    assert cell.lut_.shape == (128, 10)
    assert np.mean(cell.predict(X) == y) >= 0.70


def test_50_classes():
    X, y = _make_multiclass(2_500, 100, C=50, separation=8.0)
    cell = BMCCell(n_clusters=128)
    cell.fit(X, y, n_classes=50)
    assert cell.lut_.shape == (128, 50)
    assert np.mean(cell.predict(X) == y) >= 0.30


# ── Skip connection at scale ─────────────────────────────────────────────────

def test_skip_binary_k64():
    X, y = _make_binary(2_000, 25)
    cell = BMCCell(n_clusters=64)
    skip = BMCSkipConnection(cell, n_clusters_l2=64)
    skip.fit(X, y, n_classes=2)
    acc_l1 = np.mean(skip.predict_l1(X) == y)
    acc_skip = np.mean(skip.predict(X) == y)
    assert acc_skip >= acc_l1


def test_skip_multiclass_10():
    X, y = _make_multiclass(3_000, 50, C=10)
    cell = BMCCell(n_clusters=128)
    skip = BMCSkipConnection(cell, n_clusters_l2=128)
    skip.fit(X, y, n_classes=10)
    acc_l1 = np.mean(skip.predict_l1(X) == y)
    acc_skip = np.mean(skip.predict(X) == y)
    assert acc_skip >= acc_l1


def test_skip_high_d():
    X, y = _make_binary(1_000, 500, separation=3.0)
    cell = BMCCell(n_clusters=32)
    skip = BMCSkipConnection(cell, n_clusters_l2=32)
    skip.fit(X, y, n_classes=2)
    acc_l1 = np.mean(skip.predict_l1(X) == y)
    acc_skip = np.mean(skip.predict(X) == y)
    assert acc_skip >= acc_l1


# ── RVQ sequential ───────────────────────────────────────────────────────────

def test_rvq_binary():
    X, y = _make_binary(1_000, 25)
    model = SequentialRVQ(max_layers=16, k_per_layer=2)
    model.fit(X, y, n_classes=2)
    acc = np.mean(model.predict(X) == y)
    assert acc >= 0.90


def test_rvq_multiclass():
    X, y = _make_multiclass(1_000, 30, C=10)
    model = SequentialRVQ(max_layers=16, k_per_layer=4, n_clusters_head=64)
    model.fit(X, y, n_classes=10)
    acc = np.mean(model.predict(X) == y)
    assert acc >= 0.70


def test_rvq_auto_convergence():
    X, y = _make_binary(500, 10, separation=8.0)
    model = SequentialRVQ(max_layers=64, k_per_layer=2, convergence_threshold=0.1)
    model.fit(X, y, n_classes=2)
    assert model.n_layers_used_ < 64
    acc = np.mean(model.predict(X) == y)
    assert acc >= 0.95


# ── Geodesic TSP ─────────────────────────────────────────────────────────────

def test_tsp_k256():
    rng = np.random.default_rng(42)
    seeds = rng.normal(0, 1, (256, 20)).astype(np.float32)
    dists = L2Metric().pairwise(seeds, seeds)
    path = build_tsp_path(dists)
    assert sorted(path.tolist()) == list(range(256))


# ── Seeding ──────────────────────────────────────────────────────────────────

def test_seeding_5k_samples():
    rng = np.random.default_rng(42)
    X = rng.normal(0, 1, (5_000, 30)).astype(np.float32)
    seeds = kmeanspp_init(X, 256, rng)
    assert seeds.shape == (256, 30)


# ── LUT invariants ──────────────────────────────────────────────────────────

def test_lut_invariants():
    X, y = _make_multiclass(3_000, 50, C=5)
    cell = BMCCell(n_clusters=128)
    cell.fit(X, y, n_classes=5)

    assert np.allclose(cell.lut_.sum(axis=1), 1.0, atol=1e-10)
    assert np.all(cell.lut_ >= 0)
    assert sorted(cell.tsp_path_.tolist()) == list(range(128))
    purities = cell.purity()
    assert np.all(purities >= 1.0 / 5 - 1e-10)
    assert np.all(purities <= 1.0 + 1e-10)
    dists = cell.transform(X[:100])
    assert np.allclose(dists.sum(axis=1), 1.0, atol=1e-5)


# ── Concurrent memory safety ────────────────────────────────────────────────

def test_parallel_layer_fit_memory_bounded():
    """
    Verify that BMCLayer parallel zone fitting doesn't blow memory.

    The bug: _resolve_batch_k checks available RAM per-thread, so N
    concurrent threads each claim 75% of RAM → N*75% total allocation.

    The fix: BMCLayer precomputes a shared batch_k divided by n_workers
    before spawning threads.

    This test monitors peak RSS during a parallel layer fit and asserts
    it stays within a reasonable bound.
    """
    import tracemalloc
    import os

    M, D_total, N_zones, K = 10_000, 80, 16, 64
    n_workers = min(N_zones, os.cpu_count() or 1)

    X, y = _make_binary(M, D_total)
    obs = TabularObservationSpace(n_features=D_total, n_zones=N_zones)

    # Measure memory used by a single-zone cell fit for reference
    D_zone = D_total // N_zones
    zone_data = X[:, :D_zone].copy()
    tracemalloc.start()
    snap_before = tracemalloc.take_snapshot()
    single_cell = BMCCell(n_clusters=K, rng=np.random.default_rng(42))
    single_cell.fit(zone_data, y, n_classes=2)
    snap_after = tracemalloc.take_snapshot()
    single_zone_peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    del single_cell, zone_data

    # Now measure the full parallel layer fit
    tracemalloc.start()
    layer = BMCLayer(obs, n_clusters=K)
    layer.fit(X, y, n_classes=2)
    parallel_peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()

    # Peak memory should be bounded by roughly n_workers * single_zone
    # plus overhead for zone_vectors array and the layer object.
    # Without the fix, it would be n_workers * (full-K pairwise matrix)
    # each claiming 75% of RAM independently.
    # Allow 3x headroom over the naive n_workers * single_zone estimate
    # to account for zone_vectors array, GC timing, and thread overhead.
    budget = n_workers * single_zone_peak * 3 + M * D_total * 4  # + zone_vectors
    assert parallel_peak < budget, (
        f"Parallel fit used {parallel_peak / 1e6:.1f} MB peak, "
        f"budget was {budget / 1e6:.1f} MB "
        f"({n_workers} workers × {single_zone_peak / 1e6:.1f} MB × 3 "
        f"+ {M * D_total * 4 / 1e6:.1f} MB zone_vectors)"
    )

    # Sanity: the layer actually works
    assert len(layer.layers_) == N_zones
    acc = np.mean(layer.predict(X) == y)
    assert acc >= 0.85
