# bmc/composition/layer.py
"""
BMCLayer — parallel composition of BMCCells.

This is the primary composition pattern in the BMC framework.
N_zones independent layers each observe one zone of the input,
produce a probability distribution, and their distributions are
accumulated (soft-voted) into a final prediction.

This corresponds to the 25-zone parallel setup in the EMNIST experiment:
25 independent BMCCells, one per grid zone, whose outputs
are summed and argmax-ed.

The BMCLayer is the standard first-layer model — it takes raw inputs,
decomposes them via an ObservationSpace, and runs each zone through
its own BMCCell.

Usage:
    obs = ImageObservationSpace(28, 10, 5, 5)
    model = BMCLayer(
        observation_space=obs,
        n_clusters=256,
        metric=L2Metric(),
    )
    model.fit(images, labels)
    preds = model.predict(test_images)
    vote_matrix = model.transform(test_images)  # (M, N_zones, C) for LUT2
"""

import numpy as np
from typing import Optional, List
import os

from bmc.core.cell import BMCCell
from bmc.core.inference import accumulate_zones, predict, normalize_distributions
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric
from bmc.observation.base import ObservationSpace


def _fit_zone(args):
    """Fit a single BMCCell for one zone (used by ThreadPoolExecutor)."""
    zone_vectors, labels, n_clusters, metric, interpolate, seed_int, n_classes, batch_k = args
    cell = BMCCell(
        n_clusters=n_clusters,
        metric=metric,
        interpolate=interpolate,
        rng=np.random.default_rng(seed_int),
        batch_k=batch_k,
    )
    cell.fit(zone_vectors, labels, n_classes=n_classes)
    return cell


class BMCLayer:
    """
    Parallel composition of N_zones BMCCells.

    Parameters
    ----------
    observation_space : ObservationSpace
        Defines how inputs are decomposed into zone feature vectors.
    n_clusters : int
        Number of Voronoi cells per zone.
    metric : SimilarityMetric, optional
        Distance metric. Defaults to L2Metric().
    interpolate : bool
        Use geodesic interpolation at inference. Default: False.
    rng : np.random.Generator, optional
        Random generator. Each zone gets a distinct derived seed.

    Attributes (after fit())
    ----------
    layers_ : list of BMCCell
        One fitted layer per zone.
    n_classes_ : int
    is_fitted_ : bool
    """

    def __init__(
        self,
        observation_space: ObservationSpace,
        n_clusters: int,
        metric: Optional[SimilarityMetric] = None,
        interpolate: bool = False,
        rng: Optional[np.random.Generator] = None,
        batch_k: Optional[int] = None,
    ):
        self.observation_space = observation_space
        self.n_clusters = n_clusters
        self.metric = metric if metric is not None else L2Metric()
        self.interpolate = interpolate
        self.rng = rng if rng is not None else np.random.default_rng(42)
        self.batch_k = batch_k

        self.layers_: Optional[List[BMCCell]] = None
        self.n_classes_: Optional[int] = None
        self.is_fitted_: bool = False

    def fit(
        self,
        inputs: np.ndarray,
        labels: np.ndarray,
        n_classes: Optional[int] = None,
    ) -> "BMCLayer":
        """
        Fit all zone layers on training data.

        Parameters
        ----------
        inputs : np.ndarray
            Raw training inputs. Shape depends on observation space.
        labels : np.ndarray, shape (M,), dtype int
        n_classes : int, optional

        Returns
        -------
        self
        """
        labels = np.asarray(labels, dtype=np.int32)
        if n_classes is None:
            n_classes = int(labels.max()) + 1
        self.n_classes_ = n_classes

        # extract zone vectors: (N_zones, M, D)
        zone_vectors = self.observation_space.extract(inputs)
        N_zones = zone_vectors.shape[0]

        # Pre-generate per-zone seeds for reproducibility
        zone_seeds = [int(self.rng.integers(0, 2**31)) for _ in range(N_zones)]

        n_workers = min(N_zones, os.cpu_count() or 1)

        # Pre-compute a safe batch_k once, dividing the memory budget by
        # the number of concurrent workers so threads don't each claim 75%
        # of available memory independently.  Checks VRAM when the metric
        # uses CUDA, system RAM otherwise.
        if self.batch_k is None and n_workers > 1:
            from bmc.core.seeding import _available_memory_bytes
            device = getattr(self.metric, '_device', None)
            M = zone_vectors.shape[1]
            bytes_per_col = M * 4  # float32
            budget = int(_available_memory_bytes(device) * 0.75) // n_workers
            shared_batch_k = max(1, min(budget // bytes_per_col, self.n_clusters))
        else:
            shared_batch_k = self.batch_k

        if n_workers > 1 and N_zones >= 4:
            # Parallel zone fitting using threads.
            # NumPy releases the GIL during array operations (matmul, argmin,
            # pairwise distances), so threads achieve real parallelism for
            # the compute-heavy parts without the memory duplication cost of
            # ProcessPoolExecutor (which pickle-copies the full zone array
            # into each worker process — OOMs on large datasets like EMNIST).
            from concurrent.futures import ThreadPoolExecutor
            args_list = [
                (zone_vectors[z], labels, self.n_clusters,
                 self.metric, self.interpolate, zone_seeds[z], n_classes,
                 shared_batch_k)
                for z in range(N_zones)
            ]
            with ThreadPoolExecutor(max_workers=n_workers) as executor:
                self.layers_ = list(executor.map(_fit_zone, args_list))
        else:
            # Sequential fallback for small zone counts
            self.layers_ = []
            for z in range(N_zones):
                cell = BMCCell(
                    n_clusters=self.n_clusters,
                    metric=self.metric,
                    interpolate=self.interpolate,
                    rng=np.random.default_rng(zone_seeds[z]),
                    batch_k=shared_batch_k,
                )
                cell.fit(zone_vectors[z], labels, n_classes=n_classes)
                self.layers_.append(cell)

        self.is_fitted_ = True
        return self

    def transform(self, inputs: np.ndarray) -> np.ndarray:
        """
        Return per-zone probability distributions for each input.

        This is the vote matrix — used as input to LUT2 or attention.

        Parameters
        ----------
        inputs : np.ndarray

        Returns
        -------
        vote_matrix : np.ndarray, shape (M, N_zones, C)
        """
        self._check_fitted()
        zone_vectors = self.observation_space.extract(inputs)  # (N_zones, M, D)
        N_zones, M, D = zone_vectors.shape
        C = self.n_classes_

        vote_matrix = np.zeros((M, N_zones, C), dtype=np.float64)
        for z, layer in enumerate(self.layers_):
            vote_matrix[:, z, :] = layer.transform(zone_vectors[z])

        return vote_matrix

    def predict(self, inputs: np.ndarray) -> np.ndarray:
        """
        Predict class labels by soft voting across all zones.

        Parameters
        ----------
        inputs : np.ndarray

        Returns
        -------
        predictions : np.ndarray, shape (M,), dtype int32
        """
        vote_matrix = self.transform(inputs)  # (M, N_zones, C)
        accumulated = vote_matrix.sum(axis=1)  # (M, C)
        return predict(accumulated)

    def predict_proba(self, inputs: np.ndarray) -> np.ndarray:
        """
        Return normalized probability distributions for each input.

        Parameters
        ----------
        inputs : np.ndarray

        Returns
        -------
        probabilities : np.ndarray, shape (M, C)
            Each row sums to 1.0.
        """
        vote_matrix = self.transform(inputs)
        accumulated = vote_matrix.sum(axis=1)
        return normalize_distributions(accumulated)

    def get_state(self) -> dict:
        self._check_fitted()
        return {
            "model_class": self.__class__.__name__,
            "n_clusters": self.n_clusters,
            "interpolate": self.interpolate,
            "n_classes_": self.n_classes_,
            "layers_": [layer.get_state() for layer in self.layers_],
            "observation_space_class": self.observation_space.__class__.__name__,
        }

    def set_state(self, state: dict, observation_space: ObservationSpace) -> "BMCLayer":
        self.n_clusters = state["n_clusters"]
        self.interpolate = state["interpolate"]
        self.n_classes_ = state["n_classes_"]
        self.observation_space = observation_space

        self.layers_ = []
        for layer_state in state["layers_"]:
            layer = BMCCell(n_clusters=self.n_clusters)
            layer.set_state(layer_state)
            self.layers_.append(layer)

        self.is_fitted_ = True
        return self

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError(
                "BMCLayer is not fitted. Call fit() first."
            )

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        return (
            f"BMCLayer("
            f"n_zones={self.observation_space.n_zones}, "
            f"n_clusters={self.n_clusters}, "
            f"metric={self.metric}, "
            f"interpolate={self.interpolate}, "
            f"status={status})"
        )
