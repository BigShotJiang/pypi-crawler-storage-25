# bmc/core/cell.py
"""
BMCCell — the core primitive of the bmc framework.

This is the fundamental building block, analogous to nn.Linear in PyTorch.
It encapsulates a single zone's complete pipeline:
    observation → seed assignment → LUT retrieval → distribution output

A cell is:
- Stateful: it holds seeds and a LUT after fitting
- Composable: multiple cells can be stacked in parallel (BMCLayer)
  or sequentially (BMCNetwork)
- Configurable: metric and interpolator are constructor arguments
- Persistable: state can be serialized and restored

Usage (hard lookup):
    cell = BMCCell(n_clusters=128, metric=L2Metric())
    cell.fit(vectors, labels, n_classes=10)
    distributions = cell.transform(test_vectors)

Usage with spline interpolation:
    from bmc.core.interpolators import SplineInterpolator
    cell = BMCCell(n_clusters=128, interpolator=SplineInterpolator())
    cell.fit(vectors, labels, n_classes=10)
    distributions = cell.transform(test_vectors)
"""

import numpy as np
from typing import Optional, Union

from bmc.core.seeding import kmeanspp_init, assign_clusters
from bmc.core.geodesic import build_tsp_path
from bmc.core.lut import build_lut, reorder_lut, lut_purity, lut_dominant_class
from bmc.core.inference import lookup_single_zone
from bmc.core.interpolators import (
    Interpolator, LinearInterpolator, SplineInterpolator,
    RDDAInterpolator, restore_interpolator,
)
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric


def _compute_arc_lengths(seeds: np.ndarray, metric: SimilarityMetric) -> np.ndarray:
    """
    Compute normalized arc-length positions for seeds in TSP order.

    Parameters
    ----------
    seeds : np.ndarray, shape (K, D)
        Seeds already in TSP order.
    metric : SimilarityMetric

    Returns
    -------
    arc_lengths : np.ndarray, shape (K,)
        Normalized to [0, 1]. arc_lengths[0] = 0, arc_lengths[-1] = 1.
    """
    K = len(seeds)
    if K <= 1:
        return np.zeros(K, dtype=np.float64)

    # Compute all consecutive distances in one vectorized call
    seeds_f32 = seeds.astype(np.float32)
    # pairwise returns (K-1, K-1) but we only need the diagonal
    # Instead, compute consecutive distances directly
    diffs = seeds_f32[1:] - seeds_f32[:-1]  # (K-1, D)
    consecutive_dists = np.sqrt((diffs.astype(np.float64) ** 2).sum(axis=1))

    arc = np.zeros(K, dtype=np.float64)
    arc[1:] = np.cumsum(consecutive_dists)

    total = arc[-1]
    if total > 1e-12:
        arc /= total
    return arc


class BMCCell:
    """
    A single Voronoi lookup cell — the core primitive of the bmc framework.

    Encapsulates one zone's complete pipeline:
    seeding → geodesic ordering → LUT construction → inference.

    Parameters
    ----------
    n_clusters : int
        Number of Voronoi cells (K). Acts as the memory budget.
    metric : SimilarityMetric, optional
        Distance metric for seeding and assignment.
        Defaults to L2Metric().
    interpolate : bool
        Backward-compatible flag. If True and no interpolator is provided,
        uses SplineInterpolator. If False and no interpolator, uses hard
        lookup (no interpolation). Ignored if interpolator is explicitly set.
    interpolator : Interpolator, optional
        Interpolation strategy. If provided, overrides the interpolate flag.
        Pass None for hard lookup, or an Interpolator instance.
    rng : np.random.Generator, optional
        Random generator for reproducibility. Defaults to default_rng(42).

    Attributes (set after fit())
    ----------
    seeds_ : np.ndarray, shape (K, D)
        Fitted seed vectors in TSP geodesic order.
    lut_ : np.ndarray, shape (K, C)
        Lookup table in TSP order. lut_[k] sums to 1.0.
    tsp_path_ : np.ndarray, shape (K,)
        TSP ordering of the original seeds.
    arc_lengths_ : np.ndarray, shape (K,)
        Normalized arc-length positions of seeds along the geodesic.
    n_classes_ : int
        Number of output classes.
    is_fitted_ : bool
        True after fit() has been called.
    """

    def __init__(
        self,
        n_clusters: int,
        metric: Optional[SimilarityMetric] = None,
        interpolate: bool = False,
        interpolator: Optional[Interpolator] = None,
        rng: Optional[np.random.Generator] = None,
        batch_k: Optional[int] = None,
    ):
        self.n_clusters = n_clusters
        self.metric = metric if metric is not None else L2Metric()
        self.rng = rng if rng is not None else np.random.default_rng(42)
        self.batch_k = batch_k

        # Resolve interpolation strategy
        if interpolator is not None:
            self.interpolator = interpolator
            self.interpolate = True
        elif interpolate:
            self.interpolator = SplineInterpolator()
            self.interpolate = True
        else:
            self.interpolator = None
            self.interpolate = False

        # state — set by fit()
        self.seeds_: Optional[np.ndarray] = None
        self.lut_: Optional[np.ndarray] = None
        self.tsp_path_: Optional[np.ndarray] = None
        self.arc_lengths_: Optional[np.ndarray] = None
        self.n_classes_: Optional[int] = None
        self.is_fitted_: bool = False

    def fit(
        self,
        vectors: np.ndarray,
        labels: np.ndarray,
        n_classes: Optional[int] = None,
    ) -> "BMCCell":
        """
        Fit the cell on training vectors and labels.

        Steps:
        1. Initialize K seeds via kmeans++ and refine with Lloyd's
        2. Assign each training vector to its nearest seed
        3. Build LUT from assignments and labels
        4. Compute TSP geodesic ordering
        5. Reorder seeds and LUT by TSP path
        6. Compute arc-length positions and fit interpolator

        Parameters
        ----------
        vectors : np.ndarray, shape (M, D)
        labels : np.ndarray, shape (M,), dtype int
        n_classes : int, optional

        Returns
        -------
        self : BMCCell
        """
        vectors = np.asarray(vectors, dtype=np.float32)
        labels = np.asarray(labels, dtype=np.int32)

        if n_classes is None:
            n_classes = int(labels.max()) + 1
        self.n_classes_ = n_classes

        # 1. seed initialization + Lloyd's refinement
        seeds = kmeanspp_init(vectors, self.n_clusters, self.rng, self.metric,
                              batch_k=self.batch_k)

        # 2. assignment
        assignments = assign_clusters(vectors, seeds, self.metric,
                                      batch_k=self.batch_k)

        # 3. LUT construction
        lut = build_lut(assignments, labels, self.n_clusters, n_classes)

        # 4. TSP geodesic ordering
        dist_matrix = self.metric.pairwise(seeds, seeds)
        tsp_path = build_tsp_path(dist_matrix)

        # 5. reorder by TSP
        self.seeds_ = seeds[tsp_path].astype(np.float32)
        self.lut_ = reorder_lut(lut, tsp_path)
        self.tsp_path_ = tsp_path

        # 6. compute arc-length positions and fit interpolator
        self.arc_lengths_ = _compute_arc_lengths(self.seeds_, self.metric)

        if self.interpolator is not None:
            if isinstance(self.interpolator, RDDAInterpolator):
                self.interpolator.fit(self.seeds_, self.lut_, self.metric)
            else:
                self.interpolator.fit(self.arc_lengths_, self.lut_)

        self.is_fitted_ = True
        return self

    def fit_regression(
        self,
        vectors: np.ndarray,
        targets: np.ndarray,
    ) -> "BMCCell":
        """
        Fit the cell for regression on continuous targets.

        Identical to fit() except the LUT stores mean target values
        per cell (K, 1) instead of class probability distributions (K, C).
        Rows are NOT normalized.

        Parameters
        ----------
        vectors : np.ndarray, shape (M, D)
        targets : np.ndarray, shape (M,), continuous float

        Returns
        -------
        self : BMCCell
        """
        from bmc.core.lut import build_lut_regression

        vectors = np.asarray(vectors, dtype=np.float32)
        targets = np.asarray(targets, dtype=np.float64)

        self.n_classes_ = 1  # regression: single output column

        # 1. seed initialization + Lloyd's refinement
        seeds = kmeanspp_init(vectors, self.n_clusters, self.rng, self.metric,
                              batch_k=self.batch_k)

        # 2. assignment
        assignments = assign_clusters(vectors, seeds, self.metric,
                                      batch_k=self.batch_k)

        # 3. regression LUT: mean target per cell
        lut = build_lut_regression(assignments, targets, self.n_clusters)

        # 4. TSP geodesic ordering
        dist_matrix = self.metric.pairwise(seeds, seeds)
        tsp_path = build_tsp_path(dist_matrix)

        # 5. reorder by TSP
        self.seeds_ = seeds[tsp_path].astype(np.float32)
        self.lut_ = reorder_lut(lut, tsp_path)
        self.tsp_path_ = tsp_path

        # 6. arc-length positions and fit interpolator
        self.arc_lengths_ = _compute_arc_lengths(self.seeds_, self.metric)

        if self.interpolator is not None:
            if isinstance(self.interpolator, RDDAInterpolator):
                self.interpolator.fit(self.seeds_, self.lut_, self.metric)
            else:
                self.interpolator.fit(self.arc_lengths_, self.lut_)

        self.is_fitted_ = True
        return self

    def predict_regression(self, vectors: np.ndarray) -> np.ndarray:
        """
        Predict continuous values (regression mode).

        Uses hard lookup (nearest seed → lut value) or geodesic
        interpolation if an interpolator is fitted.

        Parameters
        ----------
        vectors : np.ndarray, shape (M, D)

        Returns
        -------
        predictions : np.ndarray, shape (M,), float64
        """
        if not self.is_fitted_:
            raise RuntimeError("BMCCell is not fitted.")

        vectors = np.asarray(vectors, dtype=np.float32)

        if self.interpolator is None:
            # Hard lookup
            assignments = assign_clusters(vectors, self.seeds_, self.metric,
                                          batch_k=self.batch_k)
            return self.lut_[assignments, 0]

        if isinstance(self.interpolator, RDDAInterpolator):
            result = self.interpolator.evaluate(vectors, self.seeds_, self.metric)
            return result.ravel()

        # Geodesic interpolation
        from bmc.core.interpolation import project_onto_segment
        from bmc.core.seeding import _distances_to_seed

        assignments = assign_clusters(vectors, self.seeds_, self.metric,
                                      batch_k=self.batch_k)
        K = len(self.seeds_)
        M = len(vectors)
        query_arc = np.zeros(M, dtype=np.float64)

        for m in range(M):
            i = int(assignments[m])
            j_prev = (i - 1) % K
            j_next = (i + 1) % K

            d_prev = float(_distances_to_seed(
                vectors[m:m+1], self.seeds_[j_prev], self.metric)[0])
            d_next = float(_distances_to_seed(
                vectors[m:m+1], self.seeds_[j_next], self.metric)[0])
            j = j_prev if d_prev <= d_next else j_next

            p_i = self.seeds_[i].flatten().astype(np.float64)
            p_j = self.seeds_[j].flatten().astype(np.float64)
            q = vectors[m].flatten().astype(np.float64)
            t_local = project_onto_segment(q, p_i, p_j)

            arc_i = self.arc_lengths_[i]
            arc_j = self.arc_lengths_[j]
            query_arc[m] = arc_i + t_local * (arc_j - arc_i)

        result = self.interpolator.evaluate(query_arc)
        return result.ravel()

    def transform(
        self,
        vectors: np.ndarray,
    ) -> np.ndarray:
        """
        Map input vectors to probability distributions.

        Parameters
        ----------
        vectors : np.ndarray, shape (M, D)

        Returns
        -------
        distributions : np.ndarray, shape (M, C)
        """
        self._check_fitted()
        vectors = np.asarray(vectors, dtype=np.float32)

        if self.interpolator is None:
            # Hard lookup
            return lookup_single_zone(
                vectors, self.seeds_, self.lut_, self.metric,
                batch_k=self.batch_k,
            )

        # RDDA operates in feature space directly
        if isinstance(self.interpolator, RDDAInterpolator):
            result = self.interpolator.evaluate(vectors, self.seeds_, self.metric)
            # Ensure valid probability distributions
            if result.ndim == 2:
                result = np.clip(result, 0.0, None)
                row_sums = result.sum(axis=1, keepdims=True)
                row_sums = np.where(row_sums == 0, 1.0, row_sums)
                result = result / row_sums
            return result

        # Arc-length interpolated lookup
        return self._transform_interpolated(vectors)

    def _transform_interpolated(self, vectors: np.ndarray) -> np.ndarray:
        """
        Interpolated lookup using the fitted interpolator.

        For each query:
        1. Find nearest seed p_i
        2. Select closer TSP neighbor j* from {i-1, i+1}
        3. Compute arc-length position for the query
        4. Evaluate interpolator at that position
        """
        dists = self.metric.pairwise(vectors, self.seeds_)  # (M, K)
        nearest_idx = np.argmin(dists, axis=1)               # (M,)

        K = len(self.seeds_)
        M = len(vectors)
        C = self.lut_.shape[1]

        # Compute query arc-length positions
        query_arc = np.zeros(M, dtype=np.float64)
        for m in range(M):
            i = int(nearest_idx[m])
            j_prev = (i - 1) % K
            j_next = (i + 1) % K

            d_prev = float(dists[m, j_prev])
            d_next = float(dists[m, j_next])

            # Symmetric neighbor selection
            j = j_prev if d_prev <= d_next else j_next

            # Project onto segment to get local t
            from bmc.core.interpolation import project_onto_segment
            p_i = self.seeds_[i].flatten().astype(np.float64)
            p_j = self.seeds_[j].flatten().astype(np.float64)
            q = vectors[m].flatten().astype(np.float64)
            t_local = project_onto_segment(q, p_i, p_j)

            # Convert local t to global arc-length
            arc_i = self.arc_lengths_[i]
            arc_j = self.arc_lengths_[j]
            query_arc[m] = arc_i + t_local * (arc_j - arc_i)

        # Evaluate interpolator for all queries at once
        result = self.interpolator.evaluate(query_arc)

        # Ensure valid probability distributions for classification LUTs
        if result.ndim == 2 and result.shape[1] == C:
            result = np.clip(result, 0.0, None)
            row_sums = result.sum(axis=1, keepdims=True)
            row_sums = np.where(row_sums == 0, 1.0, row_sums)
            result = result / row_sums

        return result

    def predict(
        self,
        vectors: np.ndarray,
    ) -> np.ndarray:
        """
        Predict class labels for input vectors.

        Parameters
        ----------
        vectors : np.ndarray, shape (M, D)

        Returns
        -------
        predictions : np.ndarray, shape (M,), dtype int32
        """
        distributions = self.transform(vectors)
        return np.argmax(distributions, axis=1).astype(np.int32)

    # Explicit aliases for symmetry with fit_regression / predict_regression
    fit_classification = fit
    predict_classification = predict

    def trace_query(self, query: np.ndarray) -> dict:
        """
        Trace a single query through the cell's geodesic.

        Returns the nearest seed index, chosen geodesic neighbor,
        parametric position t on the edge, and arc-length position.

        Parameters
        ----------
        query : np.ndarray, shape (D,) or (1, D)

        Returns
        -------
        trace : dict with keys:
            i : int — nearest seed index
            j : int — chosen geodesic neighbor index
            t : float — parametric position on edge i→j (0=at i, 1=at j)
            arc : float — global arc-length position
            dist_i : float — distance to seed i
            dist_j : float — distance to seed j
        """
        self._check_fitted()
        from bmc.core.interpolation import project_onto_segment
        from bmc.core.seeding import _distances_to_seed

        q = np.asarray(query, dtype=np.float32).reshape(1, -1)
        K = len(self.seeds_)

        # Find nearest seed
        assignments = assign_clusters(q, self.seeds_, self.metric)
        i = int(assignments[0])
        dist_i = float(_distances_to_seed(q, self.seeds_[i], self.metric)[0])

        # Geodesic neighbors
        j_prev = (i - 1) % K
        j_next = (i + 1) % K
        d_prev = float(_distances_to_seed(q, self.seeds_[j_prev], self.metric)[0])
        d_next = float(_distances_to_seed(q, self.seeds_[j_next], self.metric)[0])
        j = j_prev if d_prev <= d_next else j_next
        dist_j = d_prev if j == j_prev else d_next

        # Project onto segment
        p_i = self.seeds_[i].flatten().astype(np.float64)
        p_j = self.seeds_[j].flatten().astype(np.float64)
        q_flat = q.flatten().astype(np.float64)
        t = float(project_onto_segment(q_flat, p_i, p_j))

        # Arc-length
        arc_i = float(self.arc_lengths_[i])
        arc_j = float(self.arc_lengths_[j])
        arc = arc_i + t * (arc_j - arc_i)

        return {
            "i": i, "j": j, "t": t, "arc": arc,
            "dist_i": dist_i, "dist_j": dist_j,
        }

    def purity(self) -> np.ndarray:
        """Return the purity of each Voronoi cell."""
        self._check_fitted()
        return lut_purity(self.lut_)

    def dominant_classes(self) -> np.ndarray:
        """Return the dominant class for each Voronoi cell."""
        self._check_fitted()
        return lut_dominant_class(self.lut_)

    def get_state(self) -> dict:
        """Return serializable state for persistence."""
        self._check_fitted()
        state = {
            "model_class": self.__class__.__name__,
            "n_clusters": self.n_clusters,
            "interpolate": self.interpolate,
            "n_classes_": self.n_classes_,
            "seeds_": self.seeds_,
            "lut_": self.lut_,
            "tsp_path_": self.tsp_path_,
            "arc_lengths_": self.arc_lengths_,
            "metric_class": self.metric.__class__.__name__,
            "batch_k": self.batch_k,
        }
        if self.interpolator is not None:
            state["interpolator_state"] = self.interpolator.get_state()
        return state

    def set_state(self, state: dict) -> "BMCCell":
        """Restore state from a dict (used by persistence module)."""
        self.n_clusters = state["n_clusters"]
        self.interpolate = state["interpolate"]
        self.n_classes_ = state["n_classes_"]
        self.batch_k = state.get("batch_k", None)
        self.seeds_ = state["seeds_"]
        self.lut_ = state["lut_"]
        self.tsp_path_ = state["tsp_path_"]
        self.arc_lengths_ = state.get("arc_lengths_")

        if "interpolator_state" in state:
            self.interpolator = restore_interpolator(state["interpolator_state"])
        else:
            self.interpolator = None

        self.is_fitted_ = True
        return self

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError(
                "BMCCell is not fitted. Call fit() before transform() or predict()."
            )

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        interp_str = repr(self.interpolator) if self.interpolator else "None"
        return (
            f"BMCCell("
            f"n_clusters={self.n_clusters}, "
            f"metric={self.metric}, "
            f"interpolator={interp_str}, "
            f"status={status})"
        )
