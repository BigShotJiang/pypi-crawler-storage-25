# bmc/core/seeding.py
"""
Manifold seeding — finding K representative points from a data distribution.

This module is fully data-agnostic. It operates on (M, D) float32 arrays
and returns (K, D) seed arrays. The similarity metric is passed in as a
callable, decoupling seeding from any particular geometry.

The core algorithm is kmeans++ initialization: seeds are selected
sequentially, each new seed chosen with probability proportional to its
squared distance from the nearest already-chosen seed. This produces
well-spread seeds that approximate the support of the data distribution,
which is the finite-sample approximation of manifold seeding described
in the TAI framework.
"""

import os
import warnings
import numpy as np
from typing import Optional


def kmeanspp_init(
    vectors: np.ndarray,
    k: int,
    rng: np.random.Generator,
    metric: "bmc.metrics.base.SimilarityMetric" = None,
    max_iter: int = 50,
    tol: float = 1e-4,
    lloyd_batch: Optional[int] = None,
    batch_k: Optional[int] = None,
) -> np.ndarray:
    """
    Initialize K seeds via kmeans++ then refine with Lloyd's algorithm.

    Phase 1 (kmeans++ init): seeds are selected sequentially, each new
    seed chosen with probability proportional to its squared distance
    from the nearest already-chosen seed.

    Phase 2 (Lloyd's iteration): seeds are iteratively refined by
    assigning a sample of vectors to the nearest seed, then recomputing
    each seed as the mean of its assigned vectors. Iteration stops when
    seeds move less than `tol` or `max_iter` is reached.

    When ``lloyd_batch`` < M, each iteration samples a random subset
    of vectors (mini-batch Lloyd's). This reduces per-iteration cost
    from O(K*M*D) to O(K*B*D) while converging to the same centroids.
    The final assignment always uses the full dataset to ensure the
    returned seeds are exact cluster means.

    Parameters
    ----------
    vectors : np.ndarray, shape (M, D)
        Data points to seed from. float32.
    k : int
        Number of seeds to select.
    rng : np.random.Generator
        Seeded random generator for reproducibility.
    metric : SimilarityMetric, optional
        Distance metric for computing inter-point distances.
        Defaults to L2 if None.
    max_iter : int
        Maximum number of Lloyd's iterations. Default: 50.
    tol : float
        Convergence tolerance on seed movement. Default: 1e-4.
    lloyd_batch : int or None
        Number of samples per Lloyd iteration.
        None → min(M, 10*K).  Full-batch when M ≤ 10*K (not enough
        samples to spare), mini-batch otherwise — at least 10 samples
        per cluster per iteration for stable centroid estimates.
    batch_k : int or None
        Seed-batch size for pairwise distance computation in
        ``assign_clusters``.  Forwarded to every ``assign_clusters``
        call (Lloyd iterations and final full-dataset pass).
        None → auto-compute from available memory inside
        ``assign_clusters``.

    Returns
    -------
    seeds : np.ndarray, shape (K, D)
        Converged seed vectors.

    Notes
    -----
    Phase 1 complexity: O(K * M) distance computations.
    Phase 2 complexity: O(max_iter * K * min(M, 10*K)).
    """
    if metric is None:
        from bmc.metrics.l2 import L2Metric
        metric = L2Metric()

    M, D = vectors.shape
    if k > M:
        raise ValueError(
            f"Cannot select {k} seeds from {M} vectors. k must be <= M."
        )
    if k <= 0:
        raise ValueError(f"k must be positive, got {k}.")

    # Resolve mini-batch size: at least 10 samples per cluster for
    # stable centroid estimates; full-batch when M is small enough.
    if lloyd_batch is None:
        lloyd_batch = min(M, 10 * k)
    else:
        lloyd_batch = max(k, min(int(lloyd_batch), M))

    # ── Phase 1: kmeans++ initialization ─────────────────────────────────

    # choose first seed uniformly at random
    idx = rng.integers(0, M)
    seeds = [vectors[idx]]

    # initial min-distances: distance from each point to seed 0
    min_dists = _distances_to_seed(vectors, seeds[0], metric)

    for _ in range(k - 1):
        # sample next seed proportional to squared distance
        sq = min_dists ** 2
        total = sq.sum()
        if total == 0:
            # all points are identical — choose uniformly
            idx = rng.integers(0, M)
        else:
            probs = sq / total
            idx = rng.choice(M, p=probs)

        new_seed = vectors[idx]
        seeds.append(new_seed)

        # update min-distances
        new_dists = _distances_to_seed(vectors, new_seed, metric)
        min_dists = np.minimum(min_dists, new_dists)

    seeds = np.stack(seeds).astype(np.float64)

    # ── Phase 2: Lloyd's iteration (mini-batch when M > lloyd_batch) ─────

    full_batch = (lloyd_batch >= M)
    vectors_f64 = vectors.astype(np.float64)

    for _ in range(max_iter):
        if full_batch:
            batch_idx = None
            batch_vecs = vectors
            batch_vecs_f64 = vectors_f64
        else:
            batch_idx = rng.choice(M, size=lloyd_batch, replace=False)
            batch_vecs = vectors[batch_idx]
            batch_vecs_f64 = vectors_f64[batch_idx]

        B = len(batch_vecs)

        # assign batch vectors to nearest seed
        assignments = assign_clusters(batch_vecs, seeds.astype(vectors.dtype), metric,
                                      batch_k=batch_k)

        # recompute seeds as cluster means from batch
        counts = np.bincount(assignments, minlength=k)
        new_seeds = np.zeros((k, D), dtype=np.float64)
        np.add.at(new_seeds, assignments, batch_vecs_f64)
        # normalize non-empty, keep old seed for empty clusters
        nonempty = counts > 0
        new_seeds[nonempty] /= counts[nonempty, np.newaxis]
        new_seeds[~nonempty] = seeds[~nonempty]

        # check convergence
        shift = np.sqrt(((new_seeds - seeds) ** 2).sum(axis=1)).max()
        seeds = new_seeds
        if shift < tol:
            break

    if not full_batch:
        # Final full-dataset pass: recompute exact means from all M samples
        assignments = assign_clusters(vectors, seeds.astype(vectors.dtype), metric,
                                      batch_k=batch_k)
        counts = np.bincount(assignments, minlength=k)
        final_seeds = np.zeros((k, D), dtype=np.float64)
        np.add.at(final_seeds, assignments, vectors_f64)
        nonempty = counts > 0
        final_seeds[nonempty] /= counts[nonempty, np.newaxis]
        final_seeds[~nonempty] = seeds[~nonempty]
        seeds = final_seeds

    return seeds.astype(vectors.dtype)


def assign_clusters(
    vectors: np.ndarray,
    seeds: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
    batch_k: Optional[int] = None,
) -> np.ndarray:
    """
    Assign each vector to its nearest seed (Voronoi assignment).

    Processes seeds in batches of ``batch_k``, computing pairwise
    distances for each batch and keeping a running minimum.  When
    ``batch_k >= K`` the full (M, K) pairwise matrix is computed in
    one vectorized call.  When ``batch_k == 1`` this degenerates to
    the original streaming behaviour.

    Parameters
    ----------
    vectors : np.ndarray, shape (M, D)
    seeds : np.ndarray, shape (K, D)
    metric : SimilarityMetric
    batch_k : int or None
        Number of seeds to process per batch.
        None  → auto-compute from 75 % of available memory (RAM or VRAM).
        int   → use this value (clamped to [1, K]; warned if > 99 % memory).

    Returns
    -------
    assignments : np.ndarray, shape (M,), dtype int32
        assignments[i] = index of nearest seed to vectors[i].
    """
    K = len(seeds)
    M = len(vectors)

    device = getattr(metric, '_device', None)
    batch_k = _resolve_batch_k(batch_k, M, K, device=device)

    best_dist = np.full(M, np.inf, dtype=np.float32)
    best_idx = np.zeros(M, dtype=np.int32)

    for start in range(0, K, batch_k):
        end = min(start + batch_k, K)
        dists = metric.pairwise(vectors, seeds[start:end])   # (M, end-start)
        local_min_idx = np.argmin(dists, axis=1)              # (M,)
        local_min_dist = dists[np.arange(M), local_min_idx]   # (M,)
        mask = local_min_dist < best_dist
        best_dist[mask] = local_min_dist[mask]
        best_idx[mask] = (start + local_min_idx)[mask]

    return best_idx


# ── internal helpers ──────────────────────────────────────────────────────────

def _available_memory_bytes(device: Optional[str] = None) -> int:
    """
    Return available memory in bytes for the given device (best-effort).

    Parameters
    ----------
    device : str or None
        "cpu" (default/None) → system RAM.
        "cuda" → free GPU VRAM via ``torch.cuda.mem_get_info``.
    """
    if device is not None and device.startswith("cuda"):
        try:
            import torch
            if torch.cuda.is_available():
                free, _total = torch.cuda.mem_get_info()
                return free
        except (ImportError, RuntimeError):
            pass
        # CUDA requested but unavailable — fall through to CPU
    try:
        import psutil
        return psutil.virtual_memory().available
    except ImportError:
        pass
    try:
        pages = os.sysconf("SC_AVPHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        if pages > 0 and page_size > 0:
            return pages * page_size
    except (AttributeError, ValueError, OSError):
        pass
    # Conservative fallback: 1 GB
    return 1 << 30


def _resolve_batch_k(
    batch_k: Optional[int],
    M: int,
    K: int,
    device: Optional[str] = None,
) -> int:
    """
    Resolve batch_k to a concrete value in [1, K].

    None  → auto: 75 % of available memory (RAM or VRAM).
    int   → user override, clamped to [1, K] and warned if > 99 % of memory.

    Parameters
    ----------
    device : str or None
        "cpu" or None → budget from system RAM.
        "cuda" → budget from GPU VRAM.
    """
    avail = _available_memory_bytes(device)
    bytes_per_col = M * 4  # float32

    if batch_k is None:
        # Auto: use 75 % of available memory
        budget = int(avail * 0.75)
        batch_k = max(1, min(budget // bytes_per_col, K))
        return batch_k

    # User override
    batch_k = max(1, min(int(batch_k), K))
    needed = batch_k * bytes_per_col
    if needed > avail * 0.99:
        safe = max(1, int(avail * 0.99) // bytes_per_col)
        mem_type = "VRAM" if device and device.startswith("cuda") else "RAM"
        warnings.warn(
            f"batch_k={batch_k} would use {needed / 1e9:.1f} GB "
            f"but only {avail / 1e9:.1f} GB {mem_type} available. "
            f"Clamping to batch_k={safe} (99 % of available {mem_type}).",
            ResourceWarning,
            stacklevel=3,
        )
        return min(safe, K)
    return batch_k


def _distances_to_seed(
    vectors: np.ndarray,
    seed: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
) -> np.ndarray:
    """
    Compute distance from each vector to a single seed.

    Parameters
    ----------
    vectors : (M, D)
    seed    : (D,)
    metric  : SimilarityMetric

    Returns
    -------
    dists : (M,) float32
    """
    # pairwise expects (M, D) x (K, D) -> (M, K)
    seed_2d = seed[np.newaxis, :]             # (1, D)
    dists = metric.pairwise(vectors, seed_2d) # (M, 1)
    return dists[:, 0]                        # (M,)
