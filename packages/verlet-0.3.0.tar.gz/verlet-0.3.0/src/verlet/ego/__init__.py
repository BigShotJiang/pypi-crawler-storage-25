"""Ego data commands."""
