"""Verlet Data CLI."""
