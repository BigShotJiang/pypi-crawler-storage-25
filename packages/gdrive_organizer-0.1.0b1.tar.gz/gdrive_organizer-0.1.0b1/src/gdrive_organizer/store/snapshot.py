"""Snapshot storage — save, load, list, and diff Drive snapshots."""

from __future__ import annotations

import contextlib
import gzip
import json
import os
import platform
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from gdrive_organizer.models import DriveFile, DriveInfo, DrivePermission, Snapshot, SnapshotStats
from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from gdrive_organizer.config import Config

logger = get_logger("store.snapshot")

FOLDER_MIME = "application/vnd.google-apps.folder"
_LOCK_TIMEOUT_MSG = (
    "Could not acquire snapshot lock. Another gdrive-organizer process "
    "may be writing. Wait for it to finish or remove the .lock file manually."
)


@contextlib.contextmanager
def _snapshot_write_lock(snapshots_dir: Path, timeout: float = 30.0):
    """Advisory file lock for snapshot writes.

    Uses fcntl.flock on POSIX (blocking with timeout via alarm) and
    msvcrt.locking on Windows. If the lock cannot be acquired, raises
    TimeoutError with guidance.

    The lock file lives at <snapshots_dir>/snapshot.lock and is advisory —
    it prevents concurrent CLI processes from corrupting the snapshot but
    does not block readers.
    """
    lock_path = snapshots_dir / "snapshot.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_fd = None

    try:
        lock_fd = open(lock_path, "w")  # noqa: SIM115
        if platform.system() == "Windows":
            import msvcrt

            try:
                msvcrt.locking(lock_fd.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as e:
                raise TimeoutError(_LOCK_TIMEOUT_MSG) from e
        else:
            import fcntl
            import signal

            def _alarm_handler(signum, frame):
                raise TimeoutError(_LOCK_TIMEOUT_MSG)

            old_handler = signal.signal(signal.SIGALRM, _alarm_handler)
            signal.alarm(int(timeout))
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_EX)
            finally:
                signal.alarm(0)
                signal.signal(signal.SIGALRM, old_handler)

        yield lock_path
    finally:
        if lock_fd is not None:
            lock_fd.close()


def _update_latest_pointer(latest: Path, target: Path) -> None:
    """Create a pointer to the latest snapshot (symlink on Unix, copy on Windows)."""
    import platform
    import shutil

    if latest.exists() or latest.is_symlink():
        latest.unlink()

    if platform.system() == "Windows":
        shutil.copy2(target, latest)
    else:
        latest.symlink_to(target.name)


def _raw_to_drive_file(raw: dict) -> DriveFile:
    """Convert a raw API dict to a DriveFile model."""
    owners = [o.get("emailAddress", o.get("displayName", "")) for o in raw.get("owners", [])]
    permissions = [
        DrivePermission(
            id=p.get("id", ""),
            type=p.get("type", ""),
            role=p.get("role", "reader"),
            email=p.get("emailAddress"),
            display_name=p.get("displayName"),
        )
        for p in raw.get("permissions", [])
    ]
    sharing_user_data = raw.get("sharingUser")
    sharing_user = None
    if sharing_user_data:
        sharing_user = sharing_user_data.get("emailAddress", sharing_user_data.get("displayName"))

    last_modifying = raw.get("lastModifyingUser")
    last_modifier = None
    if last_modifying:
        last_modifier = last_modifying.get("emailAddress", last_modifying.get("displayName"))

    return DriveFile(
        id=raw["id"],
        name=raw.get("name", "Untitled"),
        mime_type=raw.get("mimeType", ""),
        parents=raw.get("parents", []),
        path=raw.get("path", ""),
        owners=owners,
        shared=raw.get("shared", False),
        permissions=permissions,
        created_time=raw.get("createdTime"),
        modified_time=raw.get("modifiedTime"),
        size=int(raw.get("size", 0)),
        web_view_link=raw.get("webViewLink"),
        drive_id=raw.get("driveId"),
        md5_checksum=raw.get("md5Checksum"),
        sha256_checksum=raw.get("sha256Checksum"),
        owned_by_me=raw.get("ownedByMe"),
        description=raw.get("description"),
        starred=raw.get("starred", False),
        last_modifying_user=last_modifier,
        original_filename=raw.get("originalFilename"),
        quota_bytes_used=int(raw.get("quotaBytesUsed", 0)),
        file_extension=raw.get("fileExtension"),
        full_file_extension=raw.get("fullFileExtension"),
        viewed_by_me_time=raw.get("viewedByMeTime"),
        image_media_metadata=raw.get("imageMediaMetadata"),
        video_media_metadata=raw.get("videoMediaMetadata"),
        sharing_user=sharing_user,
        version=raw.get("version"),
        revision_count=int(raw.get("revisionCount", 0)),
    )


def drive_file_to_raw(f: DriveFile) -> dict:
    """Convert a DriveFile model back to a raw API-like dict."""
    raw: dict = {
        "id": f.id,
        "name": f.name,
        "mimeType": f.mime_type,
        "parents": f.parents,
        "path": f.path,
        "shared": f.shared,
        "size": str(f.size),
        "starred": f.starred,
    }
    if f.owners:
        raw["owners"] = [{"emailAddress": e} for e in f.owners]
    if f.created_time:
        raw["createdTime"] = f.created_time.isoformat()
    if f.modified_time:
        raw["modifiedTime"] = f.modified_time.isoformat()
    if f.web_view_link:
        raw["webViewLink"] = f.web_view_link
    if f.drive_id:
        raw["driveId"] = f.drive_id
    if f.md5_checksum:
        raw["md5Checksum"] = f.md5_checksum
    if f.sha256_checksum:
        raw["sha256Checksum"] = f.sha256_checksum
    if f.owned_by_me is not None:
        raw["ownedByMe"] = f.owned_by_me
    if f.description:
        raw["description"] = f.description
    if f.last_modifying_user:
        raw["lastModifyingUser"] = {"emailAddress": f.last_modifying_user}
    if f.original_filename:
        raw["originalFilename"] = f.original_filename
    if f.quota_bytes_used:
        raw["quotaBytesUsed"] = str(f.quota_bytes_used)
    if f.file_extension:
        raw["fileExtension"] = f.file_extension
    if f.full_file_extension:
        raw["fullFileExtension"] = f.full_file_extension
    if f.viewed_by_me_time:
        raw["viewedByMeTime"] = f.viewed_by_me_time.isoformat()
    if f.image_media_metadata:
        raw["imageMediaMetadata"] = f.image_media_metadata
    if f.video_media_metadata:
        raw["videoMediaMetadata"] = f.video_media_metadata
    if f.sharing_user:
        raw["sharingUser"] = {"emailAddress": f.sharing_user}
    if f.version:
        raw["version"] = f.version
    if f.revision_count:
        raw["revisionCount"] = f.revision_count
    return raw


def _atomic_write_gz(filepath: Path, data: str) -> None:
    """Write data to a gzip file atomically using temp-file + fsync + rename.

    A crash at any point will leave either the old file intact or no file,
    never a truncated/corrupted file at the final path.
    """
    dirpath = filepath.parent
    fd = None
    tmp_path = None
    try:
        fd, tmp_path_str = tempfile.mkstemp(suffix=".tmp.gz", dir=dirpath)
        tmp_path = Path(tmp_path_str)
        os.close(fd)
        fd = None

        with gzip.open(tmp_path, "wt", encoding="utf-8") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())

        # Keep one previous generation as .bak
        bak_path = filepath.with_suffix(".gz.bak")
        if filepath.exists():
            try:
                filepath.rename(bak_path)
            except OSError:
                pass  # Best effort; don't block the save

        # Atomic replace
        os.replace(tmp_path, filepath)
        tmp_path = None  # Prevent cleanup from removing the final file

        # Restrict permissions — snapshot contains sensitive Drive metadata
        import platform

        if platform.system() != "Windows":
            os.chmod(filepath, 0o600)
    finally:
        if fd is not None:
            os.close(fd)
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink(missing_ok=True)


def save_snapshot(
    files: list[dict],
    change_token: str | None,
    config: Config,
    snapshot_type: str = "full",
    duration_ms: int = 0,
    drive_info_data: dict | None = None,
) -> Path:
    """Convert raw file dicts to a Snapshot and save to disk.

    Uses atomic write (temp file → fsync → os.replace) to prevent corruption
    from crashes during write. Keeps one previous generation as .bak.
    """
    drive_files = [_raw_to_drive_file(f) for f in files]

    total_folders = sum(1 for f in drive_files if f.mime_type == FOLDER_MIME)
    total_files = len(drive_files) - total_folders
    total_size = sum(f.size for f in drive_files)

    di = DriveInfo(**drive_info_data) if drive_info_data else None

    snapshot = Snapshot(
        scanned_at=datetime.now(UTC),
        type=snapshot_type,
        drive_info=di,
        stats=SnapshotStats(
            total_files=total_files,
            total_folders=total_folders,
            total_size=total_size,
            scan_duration_ms=duration_ms,
        ),
        change_token=change_token,
        files=drive_files,
    )

    snapshots_dir = config.data_dir / "snapshots"
    snapshots_dir.mkdir(parents=True, exist_ok=True)

    timestamp = snapshot.scanned_at.strftime("%Y-%m-%dT%H-%M-%S")
    filename = f"{timestamp}.json.gz"
    filepath = snapshots_dir / filename

    json_data = snapshot.model_dump_json()

    # Advisory write lock prevents concurrent CLI processes from racing
    with _snapshot_write_lock(snapshots_dir):
        _atomic_write_gz(filepath, json_data)

        # Update latest pointer (symlink on Unix, copy on Windows)
        latest = snapshots_dir / "latest.json.gz"
        _update_latest_pointer(latest, filepath)

        # Remove old uncompressed pointer if it exists
        old_latest = snapshots_dir / "latest.json"
        if old_latest.exists() or old_latest.is_symlink():
            old_latest.unlink()

    return filepath


def load_snapshot(path: Path | None = None, config: Config | None = None) -> Snapshot:
    """Load a snapshot from disk (supports both .json and .json.gz)."""
    if path is None:
        if config is None:
            raise ValueError("Either path or config must be provided")
        snapshots_dir = config.data_dir / "snapshots"
        # Try gzip first, then plain JSON
        gz_latest = snapshots_dir / "latest.json.gz"
        json_latest = snapshots_dir / "latest.json"
        if gz_latest.exists() or gz_latest.is_symlink():
            path = gz_latest
        elif json_latest.exists() or json_latest.is_symlink():
            path = json_latest
        else:
            raise FileNotFoundError("No snapshot found. Run 'gdrive-organizer scan' first.")

    if str(path).endswith(".gz"):
        with gzip.open(path, "rt", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = json.loads(path.read_text())
    return Snapshot.model_validate(data)


def check_snapshot_freshness(
    snapshot: Snapshot,
    max_age_minutes: int = 60,
) -> tuple[bool, str]:
    """Check if a snapshot is fresh enough for plan apply.

    Returns (is_fresh, message). If the snapshot is older than max_age_minutes,
    returns False with an explanation.
    """
    if not snapshot.scanned_at:
        return False, "Snapshot has no scanned_at timestamp."
    now = datetime.now(UTC)
    scanned = snapshot.scanned_at
    if scanned.tzinfo is None:
        scanned = scanned.replace(tzinfo=UTC)
    age = now - scanned
    age_minutes = age.total_seconds() / 60
    if age_minutes > max_age_minutes:
        hours = int(age_minutes // 60)
        mins = int(age_minutes % 60)
        return False, (
            f"Snapshot is {hours}h {mins}m old (scanned at {scanned.isoformat()}). "
            f"Maximum age is {max_age_minutes} minutes. "
            f"Run 'gdrive-organizer scan --incremental' to refresh."
        )
    return True, f"Snapshot is {int(age_minutes)}m old — fresh enough."


def list_snapshots(config: Config) -> list[Path]:
    """List all snapshot files sorted by date (newest first)."""
    snapshots_dir = config.data_dir / "snapshots"
    if not snapshots_dir.exists():
        return []
    files = [
        f
        for f in snapshots_dir.iterdir()
        if f.suffix in (".json", ".gz") and not f.name.startswith("latest") and not f.is_symlink()
    ]
    return sorted(files, reverse=True)


def diff_snapshots(old: Snapshot, new: Snapshot) -> dict:
    """Compute diff between two snapshots."""
    old_map = {f.id: f for f in old.files}
    new_map = {f.id: f for f in new.files}

    old_ids = set(old_map)
    new_ids = set(new_map)

    added = [new_map[fid] for fid in new_ids - old_ids]
    removed = [old_map[fid] for fid in old_ids - new_ids]
    modified = []
    for fid in old_ids & new_ids:
        o, n = old_map[fid], new_map[fid]
        if o.name != n.name or o.parents != n.parents or o.modified_time != n.modified_time:
            modified.append(n)

    return {"added": added, "removed": removed, "modified": modified}
