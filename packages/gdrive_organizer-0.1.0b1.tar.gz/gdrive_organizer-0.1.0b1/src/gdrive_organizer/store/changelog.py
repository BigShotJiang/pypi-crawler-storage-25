"""Changes API integration for incremental sync."""

from __future__ import annotations

from typing import TYPE_CHECKING

from googleapiclient.errors import HttpError

from gdrive_organizer.models import Snapshot
from gdrive_organizer.scanner.tree import build_tree, compute_paths, inject_paths_into_raw
from gdrive_organizer.store.snapshot import (
    _raw_to_drive_file,
    drive_file_to_raw,
    load_snapshot,
    save_snapshot,
)
from gdrive_organizer.utils.logger import get_logger
from gdrive_organizer.utils.retry import with_retry

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config

logger = get_logger("store.changelog")


class ChangeTokenExpiredError(Exception):
    """Raised when the stored Changes API page token has expired (410 Gone)."""


def poll_changes(service: Resource, saved_token: str) -> tuple[list[dict], str]:
    """Poll for changes since the given page token.

    Raises ChangeTokenExpiredError if the token has expired (410 Gone),
    signaling that a full rescan is needed.
    """
    from gdrive_organizer.scanner.crawler import CHANGE_FIELDS

    @with_retry(max_retries=5)
    def _execute(token):
        return (
            service.changes()
            .list(
                pageToken=token,
                fields=CHANGE_FIELDS,
                includeItemsFromAllDrives=True,
                supportsAllDrives=True,
            )
            .execute()
        )

    all_changes: list[dict] = []
    token = saved_token

    while True:
        try:
            response = _execute(token)
        except HttpError as e:
            if e.resp.status == 410:
                raise ChangeTokenExpiredError(
                    "Changes API page token has expired (HTTP 410 Gone). "
                    "The token is no longer valid — a full rescan is required. "
                    "Run: gdrive-organizer scan"
                ) from e
            raise
        changes = response.get("changes", [])
        all_changes.extend(changes)

        if "newStartPageToken" in response:
            new_token = response["newStartPageToken"]
            break
        token = response["nextPageToken"]

    return all_changes, new_token


def apply_changes(snapshot: Snapshot, changes: list[dict]) -> Snapshot:
    """Apply a list of changes to an existing snapshot."""
    file_map = {f.id: f for f in snapshot.files}

    for change in changes:
        file_id = change.get("fileId")
        if not file_id:
            continue

        removed = change.get("removed", False)
        file_data = change.get("file")

        if removed or file_data is None:
            file_map.pop(file_id, None)
        else:
            if file_data.get("trashed", False):
                file_map.pop(file_id, None)
            else:
                file_map[file_id] = _raw_to_drive_file(file_data)

    snapshot.files = list(file_map.values())
    return snapshot


def incremental_scan(service: Resource, config: Config, *, apply_filter: bool = True) -> Snapshot:
    """Load latest snapshot, apply changes, save new snapshot.

    If the stored change token has expired (410 Gone), raises
    ChangeTokenExpiredError with clear guidance to run a full scan.
    The expired token is NOT silently reused.
    """
    snapshot = load_snapshot(config=config)

    if not snapshot.change_token:
        raise ValueError("No change token in snapshot. Run a full scan first.")

    # ChangeTokenExpiredError propagates here — callers must handle it
    changes, new_token = poll_changes(service, snapshot.change_token)
    updated = apply_changes(snapshot, changes)

    # Convert to raw dicts, apply filters, and recompute paths
    raw_files = [drive_file_to_raw(f) for f in updated.files]

    if apply_filter:
        from gdrive_organizer.scanner.filter import filter_files, load_exclude_rules

        rules = load_exclude_rules(config)
        raw_files, _ = filter_files(raw_files, rules)
    node_map, roots = build_tree(raw_files)
    compute_paths(roots)
    inject_paths_into_raw(node_map)

    save_snapshot(raw_files, new_token, config, snapshot_type="incremental")
    return load_snapshot(config=config)
