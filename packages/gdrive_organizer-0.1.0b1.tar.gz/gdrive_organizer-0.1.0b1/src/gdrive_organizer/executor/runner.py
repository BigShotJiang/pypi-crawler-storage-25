"""Plan execution runner with 4-phase execution and rollback support."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field
from rich.progress import BarColumn, Progress, TextColumn, TimeRemainingColumn

from gdrive_organizer.executor.batch import (
    create_folder,
    create_shortcut,
    execute_batch,
    update_description,
)
from gdrive_organizer.executor.rate_limiter import TokenBucket
from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation
from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config

logger = get_logger("executor.runner")


class ExecutionResult(BaseModel):
    success_count: int = 0
    failure_count: int = 0
    errors: list[dict] = Field(default_factory=list)
    rollback_log_path: Path | None = None


class PlanRunner:
    """Executes a plan against the Drive API with 4-phase execution."""

    def __init__(self, service: Resource, config: Config):
        self.service = service
        self.config = config

    def execute(
        self,
        plan: ExecutionPlan,
        dry_run: bool = False,
        skip_freshness_check: bool = False,
    ) -> ExecutionResult:
        """Execute the plan in 4 phases.

        Before any mutations, checks snapshot freshness to reduce the risk of
        operating on stale state. Set skip_freshness_check=True to bypass.
        """
        from rich.console import Console

        console = Console()

        # Stale snapshot guard: refuse to apply if snapshot is too old
        if not dry_run and not skip_freshness_check:
            from gdrive_organizer.store.snapshot import check_snapshot_freshness, load_snapshot

            try:
                snapshot = load_snapshot(config=self.config)
                is_fresh, msg = check_snapshot_freshness(
                    snapshot,
                    max_age_minutes=self.config.snapshot_max_age_minutes,
                )
                if not is_fresh:
                    console.print(f"[bold red]Stale snapshot:[/bold red] {msg}")
                    console.print(
                        "[yellow]Run 'gdrive-organizer scan --incremental' to refresh, "
                        "or set GDRIVE_SNAPSHOT_MAX_AGE_MINUTES to a higher value.[/yellow]"
                    )
                    return ExecutionResult(
                        failure_count=len(plan.operations),
                        errors=[{"file_id": "_stale_snapshot", "error": msg}],
                    )
            except FileNotFoundError:
                pass  # No snapshot = nothing to check

        if dry_run:
            self._dry_run_display(plan, console)
            return ExecutionResult(success_count=len(plan.operations))

        results: dict[str, dict] = {}
        errors: list[dict] = []
        before_states: dict[str, dict] = {}

        # Record before-states
        for op in plan.operations:
            before_states[op.file_id] = {
                "name": op.current_name,
                "path": op.current_path,
                "parent_id": op.current_parent_id,
            }

        # Categorize operations by phase
        folder_ops = [o for o in plan.operations if o.operation == OperationType.CREATE_FOLDER]
        move_ops = [
            o
            for o in plan.operations
            if o.operation
            in (
                OperationType.MOVE,
                OperationType.RENAME,
                OperationType.RENAME_AND_MOVE,
                OperationType.TRASH,
                OperationType.UNTRASH,
            )
        ]
        shortcut_ops = [o for o in plan.operations if o.operation == OperationType.CREATE_SHORTCUT]
        desc_ops = [o for o in plan.operations if o.operation == OperationType.UPDATE_DESCRIPTION]

        # --- Phase 1: Create folders (topologically sorted) ---
        id_mapping: dict[str, str] = {}
        if folder_ops:
            # Sort by path depth so parents are created before children
            folder_ops.sort(key=lambda op: op.new_path.count("/") if op.new_path else 0)
            console.print(f"[bold]Phase 1:[/bold] Creating {len(folder_ops)} folders...")
            for op in folder_ops:
                parent = op.new_parent_id
                if parent and parent in id_mapping:
                    parent = id_mapping[parent]
                try:
                    result = create_folder(self.service, op.current_name, parent)
                    id_mapping[op.file_id] = result["id"]
                    results[op.file_id] = {"status": "success", "response": result}
                except Exception as e:
                    logger.error("Failed to create folder %s: %s", op.current_name, e)
                    errors.append({"file_id": op.file_id, "error": str(e)})

        # Resolve placeholders in subsequent phases and validate resolution
        unresolved = []
        for op in move_ops + shortcut_ops:
            if op.new_parent_id and op.new_parent_id.startswith("__new_folder_"):
                if op.new_parent_id in id_mapping:
                    op.new_parent_id = id_mapping[op.new_parent_id]
                else:
                    unresolved.append((op.file_id, "new_parent_id", op.new_parent_id))
            if op.shortcut_parent_id and op.shortcut_parent_id.startswith("__new_folder_"):
                if op.shortcut_parent_id in id_mapping:
                    op.shortcut_parent_id = id_mapping[op.shortcut_parent_id]
                else:
                    unresolved.append((op.file_id, "shortcut_parent_id", op.shortcut_parent_id))

        if unresolved:
            for file_id, field, placeholder in unresolved:
                msg = f"Unresolved placeholder {placeholder} in {field} for {file_id}"
                logger.error(msg)
                errors.append({"file_id": file_id, "error": msg})
            # Remove operations with unresolved placeholders
            bad_ids = {file_id for file_id, _, _ in unresolved}
            move_ops = [o for o in move_ops if o.file_id not in bad_ids]
            shortcut_ops = [o for o in shortcut_ops if o.file_id not in bad_ids]

        # --- Phase 2: Move/Rename/Trash ---
        if move_ops:
            console.print(f"[bold]Phase 2:[/bold] Processing {len(move_ops)} file operations...")
            self._execute_batch_phase(move_ops, results, errors, console)

        # --- Phase 3: Create shortcuts (with semantic validation) ---
        if shortcut_ops:
            console.print(f"[bold]Phase 3:[/bold] Creating {len(shortcut_ops)} shortcuts...")
            for op in shortcut_ops:
                parent = op.shortcut_parent_id or op.new_parent_id
                target = op.shortcut_target_id
                # Validate: both parent and target must be real IDs
                if not parent or not target:
                    errors.append(
                        {
                            "file_id": op.file_id,
                            "error": f"Shortcut missing parent ({parent}) or target ({target})",
                        }
                    )
                    continue
                # Reject shortcuts where target looks like another shortcut synthetic ID
                if target.startswith("shortcut__"):
                    errors.append(
                        {
                            "file_id": op.file_id,
                            "error": f"Shortcut-to-shortcut chain rejected: target={target}",
                        }
                    )
                    continue
                # Reject if parent is still a placeholder (folder creation failed)
                if parent.startswith("__new_folder_"):
                    errors.append(
                        {
                            "file_id": op.file_id,
                            "error": f"Shortcut parent is unresolved placeholder: {parent}",
                        }
                    )
                    continue
                try:
                    result = create_shortcut(self.service, op.current_name, target, parent)
                    results[op.file_id] = {"status": "success", "response": result}
                except Exception as e:
                    errors.append({"file_id": op.file_id, "error": str(e)})

        # --- Phase 4: Update descriptions ---
        if desc_ops:
            console.print(f"[bold]Phase 4:[/bold] Updating {len(desc_ops)} descriptions...")
            for op in desc_ops:
                if not op.new_description:
                    continue
                try:
                    result = update_description(self.service, op.file_id, op.new_description)
                    results[op.file_id] = {"status": "success", "response": result}
                except Exception as e:
                    errors.append({"file_id": op.file_id, "error": str(e)})

        success_count = sum(1 for r in results.values() if r.get("status") == "success")
        rollback_path = self._save_rollback_log(plan, results, before_states, id_mapping)

        return ExecutionResult(
            success_count=success_count,
            failure_count=len(errors),
            errors=errors,
            rollback_log_path=rollback_path,
        )

    def _execute_batch_phase(
        self,
        operations: list[PlanOperation],
        results: dict,
        errors: list,
        console,
    ):
        """Execute operations in batches with rate limiting."""
        limiter = TokenBucket(
            rate=self.config.write_rate_limit,
            capacity=min(self.config.batch_size, 10.0),
        )
        batch_size = self.config.batch_size

        def batch_callback(request_id, response, exception):
            if exception:
                errors.append({"file_id": request_id, "error": str(exception)})
                results[request_id] = {"status": "failed", "error": str(exception)}
            else:
                results[request_id] = {"status": "success", "response": response}

        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TimeRemainingColumn(),
        ) as progress:
            task = progress.add_task("Executing...", total=len(operations))
            for i in range(0, len(operations), batch_size):
                batch = operations[i : i + batch_size]
                limiter.acquire(len(batch))
                try:
                    execute_batch(self.service, batch, batch_callback)
                except Exception as e:
                    for op in batch:
                        if op.file_id not in results:
                            errors.append({"file_id": op.file_id, "error": str(e)})
                progress.update(task, advance=len(batch))

    def _dry_run_display(self, plan: ExecutionPlan, console):
        """Display plan phases in dry-run mode."""
        phase_map = {
            OperationType.CREATE_FOLDER: "Phase 1 - FOLDER",
            OperationType.MOVE: "Phase 2 - MOVE",
            OperationType.RENAME: "Phase 2 - RENAME",
            OperationType.RENAME_AND_MOVE: "Phase 2 - RENAME+MOVE",
            OperationType.TRASH: "Phase 2 - TRASH",
            OperationType.UNTRASH: "Phase 2 - UNTRASH",
            OperationType.CREATE_SHORTCUT: "Phase 3 - SHORTCUT",
            OperationType.UPDATE_DESCRIPTION: "Phase 4 - DESCRIPTION",
        }
        for op in plan.operations:
            phase = phase_map.get(op.operation, op.operation.value)
            console.print(f"  [dim][DRY RUN][/dim] [{phase}] {op.current_name}", end="")
            if op.new_path:
                console.print(f" -> {op.new_path}", end="")
            if op.new_description:
                console.print(f" [dim]({op.new_description[:40]}...)[/dim]", end="")
            console.print()

    def rollback(self, rollback_log_path: Path) -> ExecutionResult:
        """Rollback operations using a saved rollback log."""
        data = json.loads(rollback_log_path.read_text())
        reverse_ops = self._build_reverse_operations(data)
        if not reverse_ops:
            return ExecutionResult()
        reverse_plan = ExecutionPlan(
            created_at=datetime.now(UTC),
            operations=reverse_ops,
        )
        return self.execute(reverse_plan)

    def _save_rollback_log(self, plan, results, before_states, id_mapping) -> Path:
        """Save a rollback log for recovery.

        id_mapping contains placeholder→real-id from Phase 1, needed so rollback
        can TRASH the created folders by their real Drive IDs.
        """
        log = {
            "executedAt": datetime.now(UTC).isoformat(),
            "planRef": str(plan.created_at),
            "id_mapping": id_mapping,  # placeholder → real Drive ID
            "operations": [],
        }
        for op in plan.operations:
            entry = {
                "fileId": op.file_id,
                "type": op.operation.value,
                "before": before_states.get(op.file_id, {}),
                "after": {
                    "name": op.new_name or op.current_name,
                    "path": op.new_path or op.current_path,
                    "parent_id": op.new_parent_id or op.current_parent_id,
                    "description": op.new_description,
                },
                "status": results.get(op.file_id, {}).get("status", "unknown"),
            }
            # For created folders, record the real Drive ID in the log entry
            if op.operation == OperationType.CREATE_FOLDER and op.file_id in id_mapping:
                entry["realDriveId"] = id_mapping[op.file_id]
            log["operations"].append(entry)

        logs_dir = self.config.data_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%S")
        log_path = logs_dir / f"rollback-{timestamp}.json"
        log_path.write_text(json.dumps(log, indent=2))
        return log_path

    def _build_reverse_operations(self, rollback_data: dict) -> list[PlanOperation]:
        """Create reverse operations from a rollback log.

        Operations are reversed in reverse execution order so that dependencies
        (shortcuts before folders, moves before folder deletions) are respected.
        """
        reverse_ops = []
        id_mapping = rollback_data.get("id_mapping", {})

        for entry in reversed(rollback_data.get("operations", [])):
            if entry.get("status") != "success":
                continue
            before = entry.get("before", {})
            after = entry.get("after", {})
            op_type = entry.get("type", "rename")

            if op_type == "trash":
                # Correctly restore from trash via UNTRASH (sets trashed=false)
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=after.get("name", ""),
                        current_path=after.get("path", ""),
                        operation=OperationType.UNTRASH,
                        reason="rollback: restore from trash",
                    )
                )
            elif op_type == "create_folder":
                # Trash the created folder using its real Drive ID
                real_id = entry.get("realDriveId") or id_mapping.get(entry["fileId"])
                if real_id:
                    reverse_ops.append(
                        PlanOperation(
                            file_id=real_id,
                            current_name=after.get("name", ""),
                            current_path=after.get("path", ""),
                            operation=OperationType.TRASH,
                            reason="rollback: remove created folder",
                        )
                    )
                else:
                    logger.warning(
                        "Cannot rollback folder %s: no real Drive ID in log",
                        entry["fileId"],
                    )
            elif op_type == "create_shortcut":
                # Delete the created shortcut
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=after.get("name", ""),
                        current_path=after.get("path", ""),
                        operation=OperationType.TRASH,
                        reason="rollback: remove shortcut",
                    )
                )
            elif op_type == "update_description":
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=before.get("name", ""),
                        current_path=before.get("path", ""),
                        operation=OperationType.UPDATE_DESCRIPTION,
                        new_description=before.get("description", ""),
                        reason="rollback: restore description",
                    )
                )
            elif op_type in ("move", "rename", "rename_and_move"):
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=after.get("name", ""),
                        current_path=after.get("path", ""),
                        operation=OperationType(op_type),
                        new_name=before.get("name"),
                        new_parent_id=(
                            before.get("parent_id")
                            if op_type in ("move", "rename_and_move")
                            else None
                        ),
                        current_parent_id=after.get("parent_id"),
                        new_path=before.get("path"),
                        reason="rollback",
                    )
                )
        return reverse_ops
