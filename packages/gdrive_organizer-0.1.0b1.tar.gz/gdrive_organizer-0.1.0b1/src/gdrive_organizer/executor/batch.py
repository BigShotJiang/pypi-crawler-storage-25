"""Batch API wrapper for Google Drive operations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from googleapiclient.http import BatchHttpRequest

from gdrive_organizer.models import OperationType, PlanOperation

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

# Google Drive Batch API hard limit — requests per single BatchHttpRequest
GOOGLE_BATCH_LIMIT = 100


def build_request(service: Resource, operation: PlanOperation):
    """Build a Drive API update request for the given operation."""
    body = {}
    kwargs = {
        "fileId": operation.file_id,
        "supportsAllDrives": True,
    }

    if operation.operation in (OperationType.RENAME, OperationType.RENAME_AND_MOVE):
        if operation.new_name:
            body["name"] = operation.new_name

    if operation.operation in (OperationType.MOVE, OperationType.RENAME_AND_MOVE):
        if operation.new_parent_id:
            kwargs["addParents"] = operation.new_parent_id
            if operation.current_parent_id:
                kwargs["removeParents"] = operation.current_parent_id

    if operation.operation == OperationType.UPDATE_DESCRIPTION:
        if operation.new_description:
            body["description"] = operation.new_description

    if operation.operation == OperationType.TRASH:
        body["trashed"] = True

    if operation.operation == OperationType.UNTRASH:
        body["trashed"] = False

    kwargs["body"] = body
    return service.files().update(**kwargs)


def create_folder(service: Resource, name: str, parent_id: str | None = None) -> dict:
    """Create a new folder in Google Drive."""
    body: dict = {
        "name": name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    if parent_id:
        body["parents"] = [parent_id]
    return (
        service.files()
        .create(body=body, fields="id,name,mimeType,parents", supportsAllDrives=True)
        .execute()
    )


def create_shortcut(service: Resource, name: str, target_id: str, parent_id: str) -> dict:
    """Create a shortcut to an existing file."""
    body = {
        "name": name,
        "mimeType": "application/vnd.google-apps.shortcut",
        "shortcutDetails": {"targetId": target_id},
        "parents": [parent_id],
    }
    return (
        service.files()
        .create(body=body, fields="id,name,shortcutDetails", supportsAllDrives=True)
        .execute()
    )


def update_description(service: Resource, file_id: str, description: str) -> dict:
    """Update a file's description metadata."""
    return (
        service.files()
        .update(
            fileId=file_id,
            body={"description": description},
            supportsAllDrives=True,
        )
        .execute()
    )


def trash_file(service: Resource, file_id: str) -> dict:
    """Move a file to trash."""
    return (
        service.files()
        .update(
            fileId=file_id,
            body={"trashed": True},
            supportsAllDrives=True,
        )
        .execute()
    )


def execute_batch(
    service: Resource,
    operations: list[PlanOperation],
    callback,
) -> None:
    """Execute operations via Google Drive's batch API, chunked to the API limit.

    Google enforces a hard limit of 100 requests per BatchHttpRequest.
    This function automatically chunks larger lists into safe-sized batches.
    """
    for chunk_start in range(0, len(operations), GOOGLE_BATCH_LIMIT):
        chunk = operations[chunk_start : chunk_start + GOOGLE_BATCH_LIMIT]
        batch: BatchHttpRequest = service.new_batch_http_request(callback=callback)
        for op in chunk:
            request = build_request(service, op)
            batch.add(request, request_id=op.file_id)
        batch.execute()
