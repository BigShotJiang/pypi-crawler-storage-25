"""Plan generation — preset-based LLM pipeline for file organization."""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from gdrive_organizer.ai.classifier import GrokClient
from gdrive_organizer.ai.prompts import (
    build_preset_input,
    load_preset,
    parse_preset_output_raw,
)
from gdrive_organizer.ai.validator import (
    save_quarantine_log,
    validate_llm_responses,
)
from gdrive_organizer.models import (
    DriveFile,
    ExecutionPlan,
    LLMResponseItem,
    OperationType,
    PlanOperation,
    PlanStats,
    Snapshot,
)
from gdrive_organizer.scanner.content import extract_text_snippet, is_exportable
from gdrive_organizer.scanner.filter import build_md5_index, detect_junk_files
from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config

logger = get_logger("ai.planner")

BATCH_SIZE = 50
FOLDER_MIME = "application/vnd.google-apps.folder"


def _resolve_time_path(file: DriveFile) -> str:
    """Compute time-based archive path from modified_time."""
    dt = file.modified_time or file.created_time
    if dt:
        return f"보관함/{dt.year}/{dt.month:02d}"
    return "보관함/미분류"


def _get_existing_folders(snapshot: Snapshot) -> list[str]:
    """Extract meaningful folder paths from snapshot."""
    folders = []
    for f in snapshot.files:
        if f.mime_type == FOLDER_MIME and f.path:
            folders.append(f.path)
    return sorted(folders)


async def _extract_snippets(
    service: Resource | None,
    files: list[DriveFile],
    rate_limit_delay: float = 0.1,
) -> dict[str, str]:
    """Extract text snippets from exportable files."""
    snippets: dict[str, str] = {}
    if service is None:
        return snippets

    exportable = [f for f in files if is_exportable(f.mime_type)]
    for _i, f in enumerate(exportable):
        snippet = extract_text_snippet(service, f.id, f.mime_type)
        if snippet:
            snippets[f.id] = snippet
        if rate_limit_delay > 0:
            time.sleep(rate_limit_delay)
    return snippets


async def _classify_with_preset(
    client: GrokClient,
    files: list[DriveFile],
    preset_prompt: str,
    snippets: dict[str, str],
    junk_ids: set[str],
    existing_folders: list[str],
    batch_size: int = BATCH_SIZE,
) -> list[dict]:
    """Classify files using LLM with the given preset prompt.

    Returns raw dicts (not validated models) so the validator layer can
    quarantine individual invalid items.
    """
    all_raw: list[dict] = []

    for i in range(0, len(files), batch_size):
        batch = files[i : i + batch_size]
        input_text = build_preset_input(
            batch,
            snippets=snippets,
            junk_ids=junk_ids,
            existing_folders=existing_folders,
        )
        response = await client.chat(preset_prompt, input_text)
        raw_items = parse_preset_output_raw(response)
        all_raw.extend(raw_items)

    return all_raw


def _response_to_operations(
    items: list[LLMResponseItem],
    files_by_id: dict[str, DriveFile],
    existing_folder_paths: set[str],
) -> list[PlanOperation]:
    """Convert LLM response items into PlanOperations."""
    operations: list[PlanOperation] = []
    folders_to_create: dict[str, str] = {}  # path → placeholder_id
    placeholder_counter = 0

    def _ensure_folder(path: str) -> str | None:
        """Return placeholder ID for a folder, creating entry if needed."""
        nonlocal placeholder_counter
        if path in existing_folder_paths:
            return None  # Already exists, no need to create
        if path in folders_to_create:
            return folders_to_create[path]
        pid = f"__new_folder_{placeholder_counter}__"
        placeholder_counter += 1
        folders_to_create[path] = pid
        return pid

    for item in items:
        file = files_by_id.get(item.file_id)
        if not file:
            continue

        # 1. MOVE to time-based archive
        move_to = item.move_to or _resolve_time_path(file)
        _ensure_folder(move_to)
        current_parent = file.parents[0] if file.parents else None

        operations.append(
            PlanOperation(
                file_id=file.id,
                current_name=file.name,
                current_path=file.path,
                operation=OperationType.MOVE,
                new_path=f"{move_to}/{file.name}",
                new_parent_id=folders_to_create.get(move_to),
                current_parent_id=current_parent,
                reason=f"시계열 정리: {move_to}",
            )
        )

        # 2. CREATE_SHORTCUT for each tag/folder
        for shortcut_path in item.shortcuts:
            _ensure_folder(shortcut_path)
            operations.append(
                PlanOperation(
                    file_id=f"shortcut__{file.id}__{shortcut_path}",
                    current_name=file.name,
                    current_path=file.path,
                    operation=OperationType.CREATE_SHORTCUT,
                    shortcut_target_id=file.id,
                    shortcut_parent_id=folders_to_create.get(shortcut_path),
                    new_path=f"{shortcut_path}/{file.name}",
                    reason=f"바로가기: {shortcut_path}",
                )
            )

        # 3. UPDATE_DESCRIPTION
        if item.new_description:
            operations.append(
                PlanOperation(
                    file_id=file.id,
                    current_name=file.name,
                    current_path=file.path,
                    operation=OperationType.UPDATE_DESCRIPTION,
                    new_description=item.new_description,
                    reason="설명 주입",
                )
            )

    # Prepend folder creation operations
    folder_ops = []
    for path, pid in folders_to_create.items():
        parts = path.rsplit("/", 1)
        name = parts[-1] if len(parts) > 1 else path
        parent_path = parts[0] if len(parts) > 1 else None
        parent_id = folders_to_create.get(parent_path) if parent_path else None
        folder_ops.append(
            PlanOperation(
                file_id=pid,
                current_name=name,
                current_path="",
                operation=OperationType.CREATE_FOLDER,
                new_parent_id=parent_id,
                new_path=path,
                reason=f"폴더 생성: {path}",
            )
        )

    return folder_ops + operations


def _add_trash_operations(
    junk_list: list,
    files_by_id: dict[str, DriveFile],
) -> list[PlanOperation]:
    """Create TRASH operations for confirmed junk duplicates."""
    ops = []
    for junk in junk_list:
        if junk.is_trash_candidate:
            file = files_by_id.get(junk.file_id)
            if not file:
                continue
            ops.append(
                PlanOperation(
                    file_id=file.id,
                    current_name=file.name,
                    current_path=file.path,
                    operation=OperationType.TRASH,
                    reason=f"중복 파일 (junk: {junk.reason})",
                )
            )
    return ops


def detect_conflicts(
    operations: list[PlanOperation],
) -> list[tuple[PlanOperation, PlanOperation]]:
    """Find operations that would create name collisions in the same folder."""
    conflicts = []
    targets: dict[str, PlanOperation] = {}
    for op in operations:
        if op.operation in (OperationType.CREATE_FOLDER, OperationType.UPDATE_DESCRIPTION):
            continue
        target_name = op.new_name or op.current_name
        target_path = op.new_path or op.current_path
        target_folder = target_path.rsplit("/", 1)[0] if "/" in target_path else ""
        key = f"{target_folder}/{target_name}"
        if key in targets:
            conflicts.append((targets[key], op))
        else:
            targets[key] = op
    return conflicts


async def generate_plan(
    snapshot: Snapshot,
    config: Config,
    preset_id: str = "migration",
    prompt_file: Path | None = None,
    service: Resource | None = None,
) -> ExecutionPlan:
    """Generate an execution plan using the preset-based pipeline."""
    preset = load_preset(preset_id, prompt_file)
    client = GrokClient(config)

    # Separate files and folders
    files = [f for f in snapshot.files if f.mime_type != FOLDER_MIME]
    files_by_id = {f.id: f for f in snapshot.files}
    existing_folders = _get_existing_folders(snapshot)
    existing_folder_paths = set(existing_folders)

    # Junk detection
    from gdrive_organizer.store.snapshot import drive_file_to_raw

    raw_files = [drive_file_to_raw(f) for f in files]
    md5_index = build_md5_index(raw_files)
    junk_list = detect_junk_files(raw_files, md5_index=md5_index)
    junk_ids = {j.file_id for j in junk_list}

    # Text snippet extraction
    snippets = await _extract_snippets(service, files)

    # LLM classification — returns raw dicts for validator
    try:
        raw_items = await _classify_with_preset(
            client,
            files,
            preset.system_prompt,
            snippets,
            junk_ids,
            existing_folders,
        )
    finally:
        await client.close()

    # --- Trust boundary: validate LLM responses before conversion ---
    snapshot_file_ids = set(files_by_id.keys())
    validation = validate_llm_responses(
        raw_items=raw_items,
        snapshot_file_ids=snapshot_file_ids,
        snapshot_folder_paths=existing_folder_paths,
    )
    if validation.rejected:
        save_quarantine_log(validation.rejected, config)
        logger.warning(
            "LLM validation: %d accepted, %d rejected (quarantined)",
            len(validation.accepted),
            validation.reject_count,
        )
    items = validation.accepted

    # Convert to operations
    operations = _response_to_operations(items, files_by_id, existing_folder_paths)

    # Add trash operations for junk duplicates
    trash_ops = _add_trash_operations(junk_list, files_by_id)
    operations.extend(trash_ops)

    # Conflict detection
    conflicts = detect_conflicts(operations)
    if conflicts:
        conflict_ids = set()
        for _, b in conflicts:
            conflict_ids.add(b.file_id)
            logger.warning("Conflict removed: %s", b.current_name)
        operations = [op for op in operations if op.file_id not in conflict_ids]

    # Stats
    stats = PlanStats(
        total_operations=len(operations),
        renames=sum(1 for op in operations if op.operation == OperationType.RENAME),
        moves=sum(1 for op in operations if op.operation == OperationType.MOVE),
        rename_and_moves=sum(
            1 for op in operations if op.operation == OperationType.RENAME_AND_MOVE
        ),
        shortcuts=sum(1 for op in operations if op.operation == OperationType.CREATE_SHORTCUT),
        descriptions=sum(
            1 for op in operations if op.operation == OperationType.UPDATE_DESCRIPTION
        ),
        trashed=sum(1 for op in operations if op.operation == OperationType.TRASH),
    )

    plan = ExecutionPlan(
        created_at=datetime.now(UTC),
        snapshot_ref=str(snapshot.scanned_at),
        preset_id=preset_id,
        operations=operations,
        stats=stats,
    )

    # Save
    plans_dir = config.data_dir / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    timestamp = plan.created_at.strftime("%Y-%m-%dT%H-%M-%S")
    plan_path = plans_dir / f"plan-{timestamp}.json"
    plan_path.write_text(plan.model_dump_json(indent=2))

    return plan


def load_plan(path: Path | None = None, config: Config | None = None) -> ExecutionPlan | None:
    """Load the latest plan from disk."""
    if path:
        data = json.loads(path.read_text())
        return ExecutionPlan.model_validate(data)
    if config is None:
        raise ValueError("Either path or config must be provided")
    plans_dir = config.data_dir / "plans"
    plan_files = sorted(plans_dir.glob("plan-*.json"), reverse=True)
    if not plan_files:
        return None
    data = json.loads(plan_files[0].read_text())
    return ExecutionPlan.model_validate(data)
