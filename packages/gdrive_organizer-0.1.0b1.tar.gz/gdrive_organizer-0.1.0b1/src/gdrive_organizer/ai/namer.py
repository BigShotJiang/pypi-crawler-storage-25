"""Naming rule engine for file renaming suggestions."""

from __future__ import annotations

import json
import re
from pathlib import Path

from gdrive_organizer.models import DriveFile


class NamingRuleEngine:
    """Apply naming rules to generate clean file names."""

    def __init__(self, custom_rules: list[dict] | None = None):
        self.custom_rules = custom_rules or []

    @classmethod
    def from_file(cls, path: Path) -> NamingRuleEngine:
        """Load custom rules from a JSON file."""
        data = json.loads(path.read_text())
        return cls(custom_rules=data)

    def apply(self, file: DriveFile, classification: dict | None = None) -> str | None:
        """Apply naming rules. Returns new name or None if no change needed."""
        name = file.name
        original = name

        # Rule 1: Date prefix
        name = self._apply_date_prefix(name, file)

        # Rule 2: Special character cleanup
        name = self._cleanup_special_chars(name)

        # Rule 3: Use LLM suggestion if provided and different
        if classification and classification.get("suggested_name"):
            suggested = classification["suggested_name"]
            if suggested != file.name and suggested.strip():
                # Keep the date prefix if we added one
                if name != original and not suggested.startswith(name[:11]):
                    date_prefix = name[:11] if len(name) > 11 and name[10] == "_" else ""
                    if date_prefix:
                        name = date_prefix + suggested
                    else:
                        name = suggested
                else:
                    name = suggested

        # Rule 4: Apply custom rules
        for rule in self.custom_rules:
            pattern = rule.get("pattern", "")
            replacement = rule.get("replacement", "")
            scope = rule.get("scope", "name")
            if scope == "name" and pattern:
                name = re.sub(pattern, replacement, name)

        return name if name != original else None

    def _apply_date_prefix(self, name: str, file: DriveFile) -> str:
        """Add date prefix if missing."""
        # Skip if already has date prefix (YYYY-MM-DD)
        if re.match(r"\d{4}-\d{2}-\d{2}", name):
            return name
        if file.modified_time:
            date_str = file.modified_time.strftime("%Y-%m-%d")
            return f"{date_str}_{name}"
        return name

    def _cleanup_special_chars(self, name: str) -> str:
        """Replace problematic characters in file names."""
        # Preserve extension
        stem, _, ext = name.rpartition(".")
        if not stem:
            stem = name
            ext = ""

        # Replace problematic characters
        stem = re.sub(r'[\\/?*"|<>]', "_", stem)
        # Collapse multiple underscores/spaces
        stem = re.sub(r"[_\s]+", "_", stem)
        stem = stem.strip("_")

        return f"{stem}.{ext}" if ext else stem
