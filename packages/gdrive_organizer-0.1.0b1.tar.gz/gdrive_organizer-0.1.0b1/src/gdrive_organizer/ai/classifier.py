"""xAI Grok API client for file classification — async, parallel, batch."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import httpx
import keyring
from openai import AsyncOpenAI, RateLimitError

from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from gdrive_organizer.config import Config

logger = get_logger("ai.classifier")


class LLMError(Exception):
    """Raised when an LLM API call fails for non-rate-limit reasons."""


SERVICE_NAME = "gdrive-organizer"
KEY_ACCOUNT = "xai-api-key"
XAI_BASE_URL = "https://api.x.ai/v1"
DEFAULT_MODEL = "grok-4-1-fast-non-reasoning"
MAX_CONCURRENT = 10


# --- API Key Management (System Keychain) ---


def save_api_key(api_key: str) -> None:
    """Save xAI API key to system keychain."""
    keyring.set_password(SERVICE_NAME, KEY_ACCOUNT, api_key)


def load_api_key() -> str | None:
    """Load xAI API key from system keychain."""
    return keyring.get_password(SERVICE_NAME, KEY_ACCOUNT)


def delete_api_key() -> None:
    """Delete xAI API key from system keychain."""
    try:
        keyring.delete_password(SERVICE_NAME, KEY_ACCOUNT)
    except keyring.errors.PasswordDeleteError:
        pass


# --- Async LLM Client ---


class GrokClient:
    """Async xAI Grok API client with parallel processing support."""

    def __init__(self, config: Config | None = None):
        api_key = load_api_key()
        if not api_key:
            raise ValueError("xAI API key not found. Run: gdrive-organizer config api-key set")
        model = DEFAULT_MODEL
        if config:
            model = config.llm_model or DEFAULT_MODEL

        self.model = model
        self.client = AsyncOpenAI(
            api_key=api_key,
            base_url=XAI_BASE_URL,
            timeout=httpx.Timeout(120.0),
        )
        self._semaphore = asyncio.Semaphore(MAX_CONCURRENT)

    async def chat(
        self,
        system_prompt: str,
        user_message: str,
        temperature: float = 0.1,
    ) -> str:
        """Single chat completion with rate limit retry."""
        async with self._semaphore:
            return await self._call_with_retry(system_prompt, user_message, temperature)

    async def _call_with_retry(
        self,
        system_prompt: str,
        user_message: str,
        temperature: float,
        max_retries: int = 5,
    ) -> str:
        """Call API with exponential backoff on rate limit.

        Raises on non-rate-limit errors rather than silently returning empty.
        Callers must handle LLMError to distinguish real failures from empty results.
        """
        import random

        for attempt in range(max_retries):
            try:
                response = await self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message},
                    ],
                    temperature=temperature,
                )
                return response.choices[0].message.content or ""
            except RateLimitError:
                if attempt == max_retries - 1:
                    raise
                delay = (2**attempt) + random.uniform(0, 0.5)
                logger.warning(
                    "Rate limited, retrying in %.1fs (%d/%d)",
                    delay,
                    attempt + 1,
                    max_retries,
                )
                await asyncio.sleep(delay)
            except Exception as e:
                logger.error("LLM API error (not rate limit): %s", e)
                raise LLMError(f"LLM API call failed: {e}") from e
        raise LLMError("LLM API call exhausted retries without success")

    async def classify_batch_parallel(
        self,
        batches: list[tuple[str, str]],
    ) -> list[str]:
        """Process multiple (system_prompt, user_message) pairs in parallel.

        Uses asyncio.Semaphore to limit concurrent requests.
        Raises LLMError if any batch item fails, after logging all failures.
        """
        tasks = [self.chat(system, user) for system, user in batches]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        failures = [(i, r) for i, r in enumerate(results) if isinstance(r, Exception)]
        if failures:
            for i, exc in failures:
                logger.error("Batch item %d failed: %s", i, exc)
            raise LLMError(
                f"{len(failures)}/{len(batches)} batch items failed. First error: {failures[0][1]}"
            )
        return [r if isinstance(r, str) else "" for r in results]

    async def close(self):
        """Close the HTTP client."""
        await self.client.close()
