"""LLM response validator — defense-in-depth boundary between LLM output and PlanOperations.

Validates schema, semantic invariants, and policy rules before any LLM-derived
item is allowed to become a mutating PlanOperation.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import ValidationError

from gdrive_organizer.models import LLMResponseItem
from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from gdrive_organizer.config import Config

logger = get_logger("ai.validator")

# Patterns that suggest prompt injection in LLM output
_INJECTION_MARKERS = [
    "ignore previous",
    "ignore all",
    "disregard",
    "override",
    "system prompt",
    "you are now",
    "forget your instructions",
]

# Maximum allowed shortcuts per file to prevent LLM hallucination
MAX_SHORTCUTS_PER_FILE = 5
MAX_DESCRIPTION_LENGTH = 1000


@dataclass
class ValidationResult:
    """Result of validating LLM response items against the snapshot."""

    accepted: list[LLMResponseItem] = field(default_factory=list)
    rejected: list[dict] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.accepted) + len(self.rejected)

    @property
    def reject_count(self) -> int:
        return len(self.rejected)


def validate_llm_responses(
    raw_items: list[dict],
    snapshot_file_ids: set[str],
    snapshot_folder_paths: set[str],
) -> ValidationResult:
    """Validate raw LLM response dicts into accepted LLMResponseItems or rejects.

    Performs three layers of validation:
    1. Schema validation — must parse as LLMResponseItem
    2. Semantic validation — file_id must exist in snapshot
    3. Policy validation — no injection markers, sane limits
    """
    result = ValidationResult()

    for raw in raw_items:
        # Layer 1: Schema validation
        try:
            item = LLMResponseItem.model_validate(raw)
        except (ValidationError, Exception) as e:
            result.rejected.append(
                {
                    "raw": raw,
                    "reason": f"schema_validation_failed: {e}",
                    "layer": "schema",
                }
            )
            continue

        # Layer 2: Semantic validation
        rejection = _check_semantic(item, snapshot_file_ids, snapshot_folder_paths)
        if rejection:
            result.rejected.append(
                {
                    "raw": raw,
                    "reason": rejection,
                    "layer": "semantic",
                }
            )
            continue

        # Layer 3: Policy validation
        rejection = _check_policy(item)
        if rejection:
            result.rejected.append(
                {
                    "raw": raw,
                    "reason": rejection,
                    "layer": "policy",
                }
            )
            continue

        result.accepted.append(item)

    return result


def _check_semantic(
    item: LLMResponseItem,
    snapshot_file_ids: set[str],
    snapshot_folder_paths: set[str],
) -> str | None:
    """Check that file_id exists and move_to targets a plausible path."""
    if not item.file_id:
        return "empty_file_id"
    if item.file_id not in snapshot_file_ids:
        return f"file_id_not_in_snapshot: {item.file_id}"
    # Validate move_to looks like a real archive path, not garbage
    if item.move_to:
        # Must contain at least one / (folder separator)
        if "/" not in item.move_to:
            return f"move_to_not_a_path: {item.move_to[:80]}"
        # Reject absolute or dot-segment paths
        if item.move_to.startswith("/") or ".." in item.move_to:
            return f"move_to_suspicious_path: {item.move_to[:80]}"
    return None


def _check_policy(item: LLMResponseItem) -> str | None:
    """Check for injection markers, excessive shortcuts, oversized descriptions."""
    # Check move_to for injection
    if item.move_to and _has_injection_marker(item.move_to):
        return f"injection_marker_in_move_to: {item.move_to[:80]}"

    # Check shortcuts count
    if len(item.shortcuts) > MAX_SHORTCUTS_PER_FILE:
        return f"too_many_shortcuts: {len(item.shortcuts)} > {MAX_SHORTCUTS_PER_FILE}"

    # Check each shortcut path for injection
    for sp in item.shortcuts:
        if _has_injection_marker(sp):
            return f"injection_marker_in_shortcut: {sp[:80]}"

    # Check description
    if item.new_description:
        if len(item.new_description) > MAX_DESCRIPTION_LENGTH:
            return f"description_too_long: {len(item.new_description)} > {MAX_DESCRIPTION_LENGTH}"
        if _has_injection_marker(item.new_description):
            return f"injection_marker_in_description: {item.new_description[:80]}"

    return None


def _has_injection_marker(text: str) -> bool:
    """Check if text contains patterns suggestive of prompt injection."""
    lower = text.lower()
    return any(marker in lower for marker in _INJECTION_MARKERS)


def save_quarantine_log(
    rejected: list[dict],
    config: Config,
) -> Path | None:
    """Persist rejected items to a reviewable quarantine log."""
    if not rejected:
        return None

    quarantine_dir = config.data_dir / "llm_rejects"
    quarantine_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%S")
    path = quarantine_dir / f"rejects-{timestamp}.json"

    log_data = {
        "timestamp": timestamp,
        "reject_count": len(rejected),
        "items": rejected,
    }
    path.write_text(json.dumps(log_data, indent=2, ensure_ascii=False, default=str))
    logger.warning("Quarantined %d LLM response items → %s", len(rejected), path)
    return path
