/* DriveCore — Client-side Application */

// ════════════════════════════════════════
// Theme
// ════════════════════════════════════════

function toggleTheme() {
    const html = document.documentElement;
    const isDark = html.classList.toggle('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

// ════════════════════════════════════════
// Toast Notifications
// ════════════════════════════════════════

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// ════════════════════════════════════════
// Utilities
// ════════════════════════════════════════

function debounce(fn, ms) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), ms);
    };
}

function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function formatSize(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0, size = bytes;
    while (size >= 1024 && i < units.length - 1) { size /= 1024; i++; }
    return `${size.toFixed(1)} ${units[i]}`;
}

function formatDate(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleString('ko-KR', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit',
    });
}

function timeAgo(iso) {
    if (!iso) return 'never';
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
}

async function apiFetch(url, opts) {
    try {
        const resp = await fetch(url, opts);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        return await resp.json();
    } catch (e) {
        console.error(`API error [${url}]:`, e);
        throw e;
    }
}

// ════════════════════════════════════════
// Dashboard
// ════════════════════════════════════════

async function loadDashboard() {
    try {
        const [statsData, dupData, permData] = await Promise.all([
            apiFetch('/api/stats'),
            apiFetch('/api/duplicates'),
            apiFetch('/api/permissions'),
        ]);
        renderMetrics(statsData, dupData, permData);
        renderStorageBreakdown(statsData);
    } catch {
        showToast('Failed to load dashboard data. Run "gdrive-organizer scan" first.', 'error');
    }
}

function renderMetrics(statsData, dupData, permData) {
    const stats = statsData.stats || {};
    const totalSize = stats.total_size || 0;
    const totalItems = statsData.total_files_count || 0;
    const scannedAt = stats.scanned_at;

    // Storage Used
    const elStorage = document.getElementById('metric-storage');
    if (elStorage) {
        elStorage.querySelector('.metric-value').textContent = formatSize(totalSize);
        elStorage.querySelector('.metric-sub').textContent = `${(totalItems || 0).toLocaleString()} items indexed`;
    }

    // Indexed Items
    const elItems = document.getElementById('metric-items');
    if (elItems) {
        elItems.querySelector('.metric-value').textContent = totalItems.toLocaleString();
        elItems.querySelector('.metric-sub').textContent = scannedAt ? `Updated ${timeAgo(scannedAt)}` : 'No scan yet';
    }

    // Wasted Space (duplicates)
    const dupGroups = dupData.total_duplicate_groups || 0;
    let wastedSize = 0;
    if (dupData.duplicates) {
        for (const files of Object.values(dupData.duplicates)) {
            for (let i = 1; i < files.length; i++) {
                wastedSize += files[i].size || 0;
            }
        }
    }
    const elWaste = document.getElementById('metric-waste');
    if (elWaste) {
        elWaste.querySelector('.metric-value').textContent = formatSize(wastedSize);
        elWaste.querySelector('.metric-sub').textContent = `Found in ${dupGroups} duplicate groups`;
    }
}

function renderStorageBreakdown(statsData) {
    const dist = statsData.type_distribution || {};

    // Categorize MIME types
    const categories = { Video: 0, Images: 0, Documents: 0, Other: 0 };
    for (const [mime, count] of Object.entries(dist)) {
        if (mime.startsWith('video/')) categories.Video += count;
        else if (mime.startsWith('image/')) categories.Images += count;
        else if (mime.startsWith('application/pdf') || mime.startsWith('text/') ||
                 mime.includes('document') || mime.includes('spreadsheet') ||
                 mime.includes('presentation') || mime.includes('form')) {
            categories.Documents += count;
        } else {
            categories.Other += count;
        }
    }

    const total = Object.values(categories).reduce((a, b) => a + b, 0) || 1;
    const colors = ['#6366F1', '#A855F7', '#D946EF'];
    const catEntries = Object.entries(categories);

    // Bar segments
    const barEl = document.getElementById('storage-bar');
    if (barEl) {
        barEl.innerHTML = catEntries.map(([, count], i) => {
            const pct = Math.max((count / total) * 100, 1);
            const bg = i < 3 ? colors[i] : 'var(--bar-other)';
            return `<div class="storage-bar-segment h-full" style="width:${pct}%;background:${bg}"></div>`;
        }).join('');
    }

    // Legend
    const legendEl = document.getElementById('storage-legend');
    if (legendEl) {
        legendEl.innerHTML = catEntries.map(([label, count], i) => {
            const dotColor = i < 3 ? colors[i] : '#86868B';
            return `
                <div>
                    <div class="flex items-center space-x-2 mb-1.5">
                        <div class="w-2.5 h-2.5 rounded-full" style="background:${dotColor}"></div>
                        <span class="text-[13px] font-medium text-[#86868B]">${label}</span>
                    </div>
                    <p class="text-[20px] font-bold">${count.toLocaleString()}</p>
                </div>`;
        }).join('');
    }

    // MIME detail table
    const detailEl = document.getElementById('storage-detail');
    if (detailEl) {
        const sorted = Object.entries(dist).sort((a, b) => b[1] - a[1]);
        const maxCount = sorted.length > 0 ? sorted[0][1] : 1;
        detailEl.innerHTML = sorted.map(([mime, count]) => {
            const pct = (count / maxCount) * 100;
            return `
                <div class="flex items-center gap-3 py-1.5">
                    <span class="w-48 text-[13px] truncate text-[#86868B]" title="${escapeHtml(mime)}">${escapeHtml(mime)}</span>
                    <div class="flex-1 h-2 rounded-full bg-[#E5E5EA] dark:bg-[#2C2C2E] overflow-hidden">
                        <div class="h-full rounded-full bg-gradient-to-r from-[#6366F1] to-[#A855F7]" style="width:${pct}%"></div>
                    </div>
                    <span class="text-[13px] font-medium w-12 text-right">${count}</span>
                </div>`;
        }).join('');
    }
}

// ════════════════════════════════════════
// Explorer
// ════════════════════════════════════════

let selectedFileId = null;

async function loadExplorerTree(nodeId) {
    const container = document.getElementById('tree-container');
    if (!container) return;

    if (!nodeId) {
        container.innerHTML = '<div class="flex justify-center py-8"><div class="spinner"></div></div>';
        try {
            const data = await apiFetch('/api/tree');
            container.innerHTML = '';
            const ul = buildTreeNodes(data.tree);
            container.appendChild(ul);
        } catch {
            container.innerHTML = '<p class="text-[#86868B] text-[13px] text-center py-8">No data. Run scan first.</p>';
        }
    }
}

function buildTreeNodes(nodes) {
    if (!nodes || nodes.length === 0) return document.createDocumentFragment();
    const ul = document.createElement('ul');
    ul.className = 'tree-node';

    for (const node of nodes) {
        const li = document.createElement('li');
        const item = document.createElement('div');
        item.className = 'tree-item';
        item.dataset.id = node.id;

        if (node.isFolder) {
            const hasChildren = node.childCount > 0;
            item.innerHTML = `
                <span class="tree-arrow${hasChildren ? '' : ' invisible'}">${hasChildren ? '<i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>' : ''}</span>
                <i data-lucide="folder" class="w-4 h-4 text-[#6366F1] flex-shrink-0"></i>
                <span class="truncate">${escapeHtml(node.name)}</span>
                <span class="tree-child-count">${node.childCount}</span>`;
            item.onclick = (e) => {
                e.stopPropagation();
                handleTreeToggle(li, node);
            };
        } else {
            item.innerHTML = `
                <span class="tree-arrow invisible"></span>
                <i data-lucide="file-text" class="w-4 h-4 text-[#86868B] flex-shrink-0"></i>
                <span class="truncate">${escapeHtml(node.name)}</span>`;
            item.onclick = () => showFileDetail(node);
        }

        li.appendChild(item);

        // Pre-loaded children
        if (node.isFolder && node.children && node.children.length > 0) {
            const childUl = buildTreeNodes(node.children);
            childUl.style.display = 'none';
            li.appendChild(childUl);
            li.dataset.loaded = 'true';
        } else {
            li.dataset.loaded = 'false';
        }

        ul.appendChild(li);
    }

    // Reinitialize lucide icons for new elements
    setTimeout(() => lucide.createIcons(), 0);
    return ul;
}

async function handleTreeToggle(li, node) {
    let childUl = li.querySelector(':scope > ul');
    const arrow = li.querySelector('.tree-arrow');

    if (childUl && childUl.style.display !== 'none') {
        childUl.style.display = 'none';
        arrow?.classList.remove('open');
        return;
    }

    if (childUl) {
        childUl.style.display = '';
        arrow?.classList.add('open');
        return;
    }

    // Lazy load
    arrow?.classList.add('open');
    try {
        const data = await apiFetch(`/api/tree?node_id=${encodeURIComponent(node.id)}`);
        childUl = buildTreeNodes(data.children);
        li.appendChild(childUl);
        li.dataset.loaded = 'true';
    } catch {
        arrow?.classList.remove('open');
    }
}

async function showFileDetail(node) {
    const content = document.getElementById('detail-content');
    const closeBtn = document.getElementById('detail-close-btn');
    if (!content) return;

    // Mark selected
    document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));
    const item = document.querySelector(`.tree-item[data-id="${node.id}"]`);
    if (item) item.classList.add('selected');

    selectedFileId = node.id;
    if (closeBtn) closeBtn.classList.remove('hidden');
    content.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const f = await apiFetch(`/api/file/${encodeURIComponent(node.id)}`);
        if (f.error) throw new Error(f.error);

        const rows = [
            ['Name', f.name],
            ['Path', f.path || node.path],
            ['Type', f.mime_type],
            ['Size', formatSize(f.size)],
        ];
        if (f.owned_by_me !== null && f.owned_by_me !== undefined) rows.push(['Owned', f.owned_by_me ? 'Yes' : 'No']);
        if (f.starred) rows.push(['Starred', 'Yes']);
        if (f.description) rows.push(['Desc', f.description]);
        if (f.file_extension) rows.push(['Ext', f.file_extension]);
        if (f.original_filename) rows.push(['Original', f.original_filename]);
        if (f.last_modifying_user) rows.push(['Editor', f.last_modifying_user]);
        if (f.owners?.length) rows.push(['Owner', f.owners.join(', ')]);
        if (f.created_time) rows.push(['Created', formatDate(f.created_time)]);
        if (f.modified_time) rows.push(['Modified', formatDate(f.modified_time)]);

        let linkHtml = '';
        if (f.web_view_link) {
            linkHtml = `<a href="${escapeHtml(f.web_view_link)}" target="_blank" rel="noopener"
                class="inline-flex items-center gap-1.5 text-[#6366F1] hover:underline text-[13px] mt-5 font-medium">
                <i data-lucide="external-link" class="w-3.5 h-3.5"></i> Open in Drive
            </a>`;
        }

        let idHtml = '';
        if (f.id) {
            idHtml = `<div class="mt-4 pt-4 border-t border-[#E5E5EA] dark:border-[#38383A]">
                <span class="text-[11px] text-[#A1A1A6] break-all font-mono">${escapeHtml(f.id)}</span>
            </div>`;
        }

        let md5Html = '';
        if (f.md5_checksum) {
            md5Html = `<div class="mt-2">
                <span class="text-[11px] text-[#A1A1A6] font-mono">MD5: ${escapeHtml(f.md5_checksum)}</span>
            </div>`;
        }

        content.innerHTML = `
            <h3 class="text-[15px] font-bold mb-5 break-words">${escapeHtml(f.name)}</h3>
            <div class="space-y-2.5">
                ${rows.map(([label, value]) => `
                    <div class="flex gap-2">
                        <span class="w-20 text-[12px] font-medium text-[#86868B] flex-shrink-0 pt-px">${label}</span>
                        <span class="text-[12px] min-w-0 break-words">${typeof value === 'string' && !value.includes('<') ? escapeHtml(value) : value}</span>
                    </div>
                `).join('')}
            </div>
            ${linkHtml}
            ${idHtml}
            ${md5Html}`;
        lucide.createIcons();
    } catch {
        content.innerHTML = '<p class="text-[#86868B] text-center py-8">Failed to load details.</p>';
    }
}

function closeDetailPanel() {
    const content = document.getElementById('detail-content');
    const closeBtn = document.getElementById('detail-close-btn');
    if (content) {
        content.innerHTML = `
            <div class="flex flex-col items-center justify-center h-full text-center">
                <i data-lucide="mouse-pointer-click" class="w-10 h-10 text-[#C7C7CC] dark:text-[#545456] mb-3"></i>
                <p class="text-[14px] text-[#86868B]">Select a file to view details</p>
            </div>`;
        lucide.createIcons();
    }
    if (closeBtn) closeBtn.classList.add('hidden');
    selectedFileId = null;
    document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));
}

async function explorerSearch() {
    const query = document.getElementById('explorer-search')?.value;
    const container = document.getElementById('tree-container');
    if (!container) return;

    if (!query) {
        loadExplorerTree();
        return;
    }

    container.innerHTML = '<div class="flex justify-center py-8"><div class="spinner"></div></div>';
    try {
        const data = await apiFetch(`/api/files?q=${encodeURIComponent(query)}`);
        if (data.files.length === 0) {
            container.innerHTML = '<p class="text-[#86868B] text-[13px] text-center py-8">No results found.</p>';
            return;
        }

        const ul = document.createElement('ul');
        ul.className = 'tree-node';
        for (const f of data.files) {
            const li = document.createElement('li');
            const item = document.createElement('div');
            item.className = 'tree-item';
            item.dataset.id = f.id;
            item.innerHTML = `
                <span class="tree-arrow invisible"></span>
                <i data-lucide="file-text" class="w-4 h-4 text-[#86868B] flex-shrink-0"></i>
                <span class="truncate">${escapeHtml(f.name)}</span>
                <span class="tree-child-count">${formatSize(f.size)}</span>`;
            item.onclick = () => showFileDetail({ id: f.id, name: f.name, path: f.path, mimeType: f.mime_type });
            li.appendChild(item);
            ul.appendChild(li);
        }
        container.innerHTML = '';
        container.appendChild(ul);
        lucide.createIcons();
    } catch {
        container.innerHTML = '<p class="text-[#86868B] text-[13px] text-center py-8">Search failed.</p>';
    }
}

// ════════════════════════════════════════
// Plan (AI Classify)
// ════════════════════════════════════════

let currentPlanOps = [];

async function loadPlan() {
    const container = document.getElementById('plan-container');
    const summary = document.getElementById('plan-summary');
    if (!container) return;

    container.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const data = await apiFetch('/api/plan');
        if (!data.plan || !data.plan.operations || data.plan.operations.length === 0) {
            container.innerHTML = `
                <div class="text-center py-16">
                    <i data-lucide="clipboard-list" class="w-12 h-12 text-[#86868B] mx-auto mb-4"></i>
                    <p class="text-[15px] font-medium mb-2">No plan to review</p>
                    <p class="text-[#86868B] text-[13px] mb-4">Generate a plan from the CLI first:</p>
                    <code class="px-3 py-1.5 rounded-lg bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[12px] font-mono">gdrive-organizer classify</code>
                    <p class="text-[#86868B] text-[12px] mt-4">Then return here to review and approve the plan.</p>
                </div>`;
            lucide.createIcons();
            return;
        }
        currentPlanOps = data.plan.operations;
        renderPlanOps(currentPlanOps, container);
        updatePlanSummary(currentPlanOps, summary);
    } catch {
        container.innerHTML = '<p class="text-[#86868B] text-center py-8">Failed to load plan.</p>';
    }
}

function renderPlanOps(ops, container) {
    const filter = document.getElementById('plan-filter')?.value || 'all';
    const filtered = filter === 'all' ? ops : ops.filter(o => o.operation === filter);

    if (filtered.length === 0) {
        container.innerHTML = '<p class="text-[#86868B] text-center py-8">No operations matching filter.</p>';
        return;
    }

    container.innerHTML = filtered.map((op, i) => `
        <div class="glass-card p-5 flex gap-4 items-start">
            <input type="checkbox" class="plan-check mt-1 w-4 h-4 rounded accent-[#6366F1]" data-id="${escapeHtml(op.file_id)}" checked>
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-3">
                    <span class="op-badge op-${op.operation}">${op.operation.replace(/_/g, ' ')}</span>
                    <span class="text-[13px] text-[#86868B]">#${i + 1}</span>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div class="rounded-xl p-3 bg-red-50 dark:bg-red-500/10">
                        <p class="text-[11px] font-semibold text-[#86868B] mb-1">BEFORE</p>
                        <p class="text-[13px] font-medium">${escapeHtml(op.current_name)}</p>
                        <p class="text-[12px] text-[#86868B] truncate">${escapeHtml(op.current_path)}</p>
                    </div>
                    <div class="rounded-xl p-3 bg-green-50 dark:bg-green-500/10">
                        <p class="text-[11px] font-semibold text-[#86868B] mb-1">AFTER</p>
                        <p class="text-[13px] font-medium">${escapeHtml(op.new_name || op.current_name)}</p>
                        <p class="text-[12px] text-[#86868B] truncate">${escapeHtml(op.new_path || op.current_path)}</p>
                    </div>
                </div>
                ${op.reason ? `<p class="text-[12px] text-[#86868B] mt-2">${escapeHtml(op.reason)}</p>` : ''}
            </div>
        </div>
    `).join('');
}

function updatePlanSummary(ops, el) {
    if (!el) return;
    const counts = {};
    for (const op of ops) {
        counts[op.operation] = (counts[op.operation] || 0) + 1;
    }
    const parts = Object.entries(counts).map(([k, v]) => `${v} ${k.replace(/_/g, ' ')}`);
    el.textContent = `${ops.length} operations — ${parts.join(', ')}`;
}

function planApproveAll() {
    document.querySelectorAll('.plan-check').forEach(cb => cb.checked = true);
}

function planRejectAll() {
    document.querySelectorAll('.plan-check').forEach(cb => cb.checked = false);
}

let _pendingApprovalIds = [];

async function planApply() {
    const ids = [];
    document.querySelectorAll('.plan-check:checked').forEach(cb => ids.push(cb.dataset.id));
    if (ids.length === 0) {
        showToast('No operations selected.', 'error');
        return;
    }
    // Step 1: Request confirmation summary from server (without confirmed=true)
    try {
        const data = await apiFetch('/api/plan/approve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ approved_ids: ids, confirmed: false }),
        });
        if (data.status === 'confirmation_required') {
            _pendingApprovalIds = ids;
            showConfirmModal(data);
        } else if (data.status === 'approved') {
            showToast(`Approved ${data.operations} operations.`, 'success');
        }
    } catch {
        showToast('Failed to approve plan.', 'error');
    }
}

function showConfirmModal(data) {
    const modal = document.getElementById('confirm-modal');
    const summary = document.getElementById('confirm-summary');
    const trashWarning = document.getElementById('confirm-trash-warning');
    const confirmInput = document.getElementById('confirm-input');

    if (!modal || !summary) return;

    let html = `<p class="font-medium">${data.operations} operations selected:</p><ul class="ml-4 mt-1 space-y-1">`;
    for (const [op, count] of Object.entries(data.summary || {})) {
        const isTrash = op === 'trash';
        html += `<li class="${isTrash ? 'text-red-500 font-semibold' : ''}">${count} ${op.replace(/_/g, ' ')}</li>`;
    }
    html += '</ul>';
    summary.innerHTML = html;

    if (data.trash_count > 0) {
        trashWarning.classList.remove('hidden');
        if (confirmInput) confirmInput.value = '';
    } else {
        trashWarning.classList.add('hidden');
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
    lucide.createIcons();
}

function closeConfirmModal() {
    const modal = document.getElementById('confirm-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    _pendingApprovalIds = [];
}

async function confirmPlanApply() {
    const trashWarning = document.getElementById('confirm-trash-warning');
    const confirmInput = document.getElementById('confirm-input');
    let trashConfirmed = false;

    // If trash ops present, require typed confirmation
    if (trashWarning && !trashWarning.classList.contains('hidden')) {
        if (!confirmInput || confirmInput.value.trim().toLowerCase() !== 'apply') {
            showToast('Type "apply" to confirm destructive operations.', 'error');
            return;
        }
        trashConfirmed = true;
    }

    try {
        const data = await apiFetch('/api/plan/approve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                approved_ids: _pendingApprovalIds,
                confirmed: true,
                trash_confirmed: trashConfirmed,
            }),
        });
        if (data.status === 'approved') {
            showToast(`Approved ${data.operations} operations.`, 'success');
            // Show next-step guidance inline
            const container = document.getElementById('plan-container');
            if (container) {
                container.innerHTML = `
                    <div class="glass-card p-8 text-center">
                        <i data-lucide="check-circle" class="w-12 h-12 text-green-500 mx-auto mb-4"></i>
                        <p class="text-[16px] font-bold mb-2">${data.operations} operations approved</p>
                        <p class="text-[14px] text-[#86868B] mb-4">Run the following command to execute:</p>
                        <code class="px-4 py-2 rounded-lg bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[13px] font-mono">gdrive-organizer plan apply</code>
                        <p class="text-[12px] text-[#86868B] mt-4">Add <code class="text-[11px]">--dry-run</code> to preview without executing. Use <code class="text-[11px]">gdrive-organizer plan rollback</code> to undo.</p>
                    </div>`;
                lucide.createIcons();
            }
        } else if (data.status === 'trash_confirmation_required') {
            showToast('Trash operations require typed confirmation. Please try again.', 'error');
        } else {
            showToast(data.error || 'Approval failed.', 'error');
        }
    } catch {
        showToast('Failed to approve plan.', 'error');
    } finally {
        closeConfirmModal();
    }
}

function filterPlan() {
    const container = document.getElementById('plan-container');
    if (container && currentPlanOps.length > 0) {
        renderPlanOps(currentPlanOps, container);
    }
}

// ════════════════════════════════════════
// Permissions
// ════════════════════════════════════════

async function loadPermissions() {
    const container = document.getElementById('permissions-container');
    if (!container) return;

    container.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const data = await apiFetch('/api/permissions');
        renderPermissions(data, container);
    } catch {
        container.innerHTML = '<p class="text-[#86868B] text-center py-8">Failed to load permissions. Run scan first.</p>';
    }
}

function renderPermissions(data, container) {
    const categories = [
        { key: 'public', label: 'Public', icon: 'globe', color: 'perm-public', desc: 'Accessible to anyone on the internet' },
        { key: 'domain', label: 'Domain', icon: 'building', color: 'perm-domain', desc: 'Shared with your organization' },
        { key: 'specific_users', label: 'Specific Users', icon: 'users', color: 'perm-specific', desc: 'Shared with individual people' },
        { key: 'not_shared', label: 'Private', icon: 'lock', color: 'perm-private', desc: 'Only you have access' },
    ];

    const total = categories.reduce((sum, c) => sum + (data[c.key] || 0), 0) || 1;

    container.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            ${categories.map(c => {
                const count = data[c.key] || 0;
                const pct = ((count / total) * 100).toFixed(1);
                return `
                    <div class="glass-card p-6">
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-[13px] font-semibold uppercase text-[#86868B]">${c.label}</span>
                            <i data-lucide="${c.icon}" class="w-[18px] h-[18px] ${c.color}"></i>
                        </div>
                        <p class="text-[28px] font-bold mb-1">${count.toLocaleString()}</p>
                        <p class="text-[13px] text-[#86868B]">${pct}% of total</p>
                    </div>`;
            }).join('')}
        </div>
        ${data.details?.public_files?.length ? `
            <div class="glass-card p-6">
                <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                    <i data-lucide="alert-triangle" class="w-5 h-5 text-red-500"></i>
                    Public Files (${data.details.public_files.length})
                </h3>
                <div class="space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar">
                    ${data.details.public_files.map(f => `
                        <div class="flex items-center gap-3 p-3 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                            <i data-lucide="file-warning" class="w-4 h-4 text-red-400 flex-shrink-0"></i>
                            <div class="min-w-0">
                                <p class="text-[13px] font-medium truncate">${escapeHtml(f.name)}</p>
                                <p class="text-[12px] text-[#86868B] truncate">${escapeHtml(f.id)}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : ''}`;

    lucide.createIcons();
}

// ════════════════════════════════════════
// Duplicates
// ════════════════════════════════════════

async function loadDuplicates() {
    const container = document.getElementById('duplicates-container');
    if (!container) return;

    container.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const data = await apiFetch('/api/duplicates');
        renderDuplicates(data, container);
    } catch {
        container.innerHTML = '<p class="text-[#86868B] text-center py-8">Failed to load duplicates. Run scan first.</p>';
    }
}

function renderDuplicates(data, container) {
    const groups = data.duplicates || {};
    const groupEntries = Object.entries(groups);

    if (groupEntries.length === 0) {
        container.innerHTML = `
            <div class="text-center py-16">
                <i data-lucide="check-circle" class="w-12 h-12 text-green-500 mx-auto mb-4"></i>
                <p class="text-[15px] font-medium">No duplicates found!</p>
                <p class="text-[13px] text-[#86868B] mt-1">Your Drive is clean.</p>
            </div>`;
        lucide.createIcons();
        return;
    }

    // Calculate total wasted
    let totalWasted = 0;
    for (const files of Object.values(groups)) {
        for (let i = 1; i < files.length; i++) totalWasted += files[i].size || 0;
    }

    container.innerHTML = `
        <div class="glass-card p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-[13px] font-semibold uppercase text-[#86868B]">Summary</p>
                    <p class="text-[24px] font-bold mt-1">${groupEntries.length} duplicate groups</p>
                </div>
                <div class="text-right">
                    <p class="text-[13px] font-semibold uppercase text-[#86868B]">Wasted Space</p>
                    <p class="text-[24px] font-bold mt-1 text-orange-500">${formatSize(totalWasted)}</p>
                </div>
            </div>
        </div>
        <div class="space-y-4">
            ${groupEntries.slice(0, 50).map(([md5, files], idx) => `
                <div class="glass-card p-5">
                    <div class="flex items-center gap-2 mb-3">
                        <i data-lucide="copy" class="w-4 h-4 text-orange-500"></i>
                        <span class="text-[13px] font-semibold">Group #${idx + 1}</span>
                        <span class="text-[12px] text-[#86868B]">${files.length} copies</span>
                        <span class="text-[11px] text-[#86868B] ml-auto font-mono">${md5.slice(0, 12)}...</span>
                    </div>
                    <div class="space-y-2">
                        ${files.map((f, fi) => `
                            <div class="flex items-center gap-3 p-2.5 rounded-xl ${fi === 0 ? 'bg-green-50 dark:bg-green-500/10' : 'bg-black/[0.02] dark:bg-white/[0.02]'}">
                                ${fi === 0 ? '<i data-lucide="star" class="w-3.5 h-3.5 text-green-500 flex-shrink-0"></i>' : '<i data-lucide="file" class="w-3.5 h-3.5 text-[#86868B] flex-shrink-0"></i>'}
                                <div class="min-w-0 flex-1">
                                    <p class="text-[13px] font-medium truncate">${escapeHtml(f.name)}</p>
                                    <p class="text-[12px] text-[#86868B] truncate">${escapeHtml(f.path || '')}</p>
                                </div>
                                <span class="text-[12px] text-[#86868B] flex-shrink-0">${formatSize(f.size)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `).join('')}
            ${groupEntries.length > 50 ? `<p class="text-center text-[13px] text-[#86868B]">...and ${groupEntries.length - 50} more groups</p>` : ''}
        </div>`;

    lucide.createIcons();
}

// ════════════════════════════════════════
// Settings
// ════════════════════════════════════════

async function loadSettings() {
    const container = document.getElementById('settings-container');
    if (!container) return;

    try {
        const [configData, authData, apikeyData] = await Promise.all([
            apiFetch('/api/config'),
            apiFetch('/api/auth/status'),
            apiFetch('/api/apikey/status'),
        ]);
        renderSettings(configData, authData, apikeyData, container);
    } catch {
        container.innerHTML = '<p class="text-[#86868B] text-center py-8">Failed to load settings.</p>';
    }
}

function renderSettings(configData, authData, apikeyData, container) {
    const config = configData.config || {};
    const auth = authData || {};
    const apikey = apikeyData || {};

    container.innerHTML = `
        <!-- Auth Status -->
        <div class="glass-card p-6 mb-6">
            <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                <i data-lucide="key" class="w-5 h-5 text-[#6366F1]"></i>
                Google OAuth
            </h3>
            <div class="space-y-3">
                <div class="flex items-center justify-between">
                    <span class="text-[13px] text-[#86868B]">Status</span>
                    <span class="text-[13px] font-medium ${auth.authenticated ? 'text-green-500' : 'text-red-500'}">
                        ${auth.authenticated ? 'Connected' : 'Not Connected'}
                    </span>
                </div>
                ${auth.email ? `
                    <div class="flex items-center justify-between">
                        <span class="text-[13px] text-[#86868B]">Account</span>
                        <span class="text-[13px] font-medium">${escapeHtml(auth.email)}</span>
                    </div>` : ''}
                ${auth.token_expiry ? `
                    <div class="flex items-center justify-between">
                        <span class="text-[13px] text-[#86868B]">Token Expires</span>
                        <span class="text-[13px] font-medium">${formatDate(auth.token_expiry)}</span>
                    </div>` : ''}
                ${!auth.authenticated ? `
                    <p class="text-[12px] text-[#A1A1A6] mt-2">Run <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">gdrive-organizer auth login</code> in terminal to connect.</p>` : ''}
            </div>
        </div>

        <!-- xAI API Key -->
        <div class="glass-card p-6 mb-6">
            <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                <i data-lucide="sparkles" class="w-5 h-5 text-[#D946EF]"></i>
                xAI API Key
            </h3>
            <div class="space-y-4">
                <div class="flex items-center justify-between">
                    <span class="text-[13px] text-[#86868B]">Status</span>
                    <span class="text-[13px] font-medium ${apikey.registered ? 'text-green-500' : 'text-red-500'}">
                        ${apikey.registered ? 'Registered' : 'Not Set'}
                    </span>
                </div>
                ${apikey.masked_key ? `
                    <div class="flex items-center justify-between">
                        <span class="text-[13px] text-[#86868B]">Key</span>
                        <span class="text-[12px] font-mono text-[#86868B]">${escapeHtml(apikey.masked_key)}</span>
                    </div>` : ''}

                <!-- Input form -->
                <div class="pt-2 border-t border-[#E5E5EA] dark:border-[#38383A]">
                    <label class="text-[12px] font-medium text-[#86868B] block mb-2">
                        ${apikey.registered ? 'Update API Key' : 'Enter API Key'}
                    </label>
                    <div class="flex gap-2">
                        <input
                            type="password"
                            id="apikey-input"
                            placeholder="xai-..."
                            class="flex-1 px-3 py-2 rounded-xl border text-[13px] outline-none transition-colors
                                bg-white border-[#E5E5EA] text-[#1D1D1F] focus:border-[#6366F1]
                                dark:bg-[#1C1C1E] dark:border-[#38383A] dark:text-[#F5F5F7] dark:focus:border-[#6366F1]"
                        >
                        <button onclick="saveApiKey()"
                            class="px-4 py-2 rounded-xl text-[13px] font-semibold text-white
                                bg-gradient-to-r from-[#6366F1] to-[#D946EF]
                                hover:opacity-90 transition-opacity">
                            Save
                        </button>
                    </div>
                </div>

                ${apikey.registered ? `
                    <button onclick="deleteApiKey()"
                        class="text-[13px] text-red-500 hover:text-red-600 font-medium transition-colors">
                        Remove API Key
                    </button>` : ''}
            </div>
        </div>

        <!-- Configuration -->
        <div class="glass-card p-6">
            <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                <i data-lucide="sliders-horizontal" class="w-5 h-5 text-[#6366F1]"></i>
                Configuration
            </h3>
            <div class="space-y-3">
                ${Object.entries(config).map(([key, value]) => `
                    <div class="flex items-center justify-between py-2 border-b border-[#E5E5EA] dark:border-[#38383A] last:border-0">
                        <span class="text-[13px] font-medium">${escapeHtml(key)}</span>
                        <span class="text-[13px] text-[#86868B]">${escapeHtml(String(value))}</span>
                    </div>
                `).join('')}
            </div>
        </div>`;

    lucide.createIcons();
}

async function saveApiKey() {
    const input = document.getElementById('apikey-input');
    const saveBtn = input?.parentElement?.querySelector('button');
    const key = input?.value?.trim();
    if (!key) {
        showToast('API key를 입력하세요.', 'error');
        return;
    }
    // Disable button during validation
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Validating...'; }
    try {
        const data = await apiFetch('/api/apikey/set', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ api_key: key }),
        });
        if (data.error) {
            showToast(data.error, 'error');
            return;
        }
        input.value = '';
        showToast('API key 검증 완료, 저장되었습니다.', 'success');
        loadSettings();
    } catch {
        showToast('API key 저장에 실패했습니다.', 'error');
    } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save'; }
    }
}

async function deleteApiKey() {
    if (!confirm('API key를 삭제하시겠습니까?')) return;
    try {
        await apiFetch('/api/apikey', { method: 'DELETE' });
        showToast('API key가 삭제되었습니다.', 'success');
        loadSettings();
    } catch {
        showToast('API key 삭제에 실패했습니다.', 'error');
    }
}

// ════════════════════════════════════════
// Keyboard Shortcuts
// ════════════════════════════════════════

document.addEventListener('keydown', (e) => {
    // Cmd+K → Focus search
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        const search = document.getElementById('global-search') || document.getElementById('explorer-search');
        if (search) search.focus();
    }
    // Escape → Close detail panel
    if (e.key === 'Escape') {
        closeDetailPanel();
    }
});
