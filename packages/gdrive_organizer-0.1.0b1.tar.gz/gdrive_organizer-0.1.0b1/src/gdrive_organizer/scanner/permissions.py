"""Permission scanning and summarization."""

from __future__ import annotations

from typing import TYPE_CHECKING

from gdrive_organizer.models import DriveFile
from gdrive_organizer.utils.retry import with_retry

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource


def get_file_permissions(service: Resource, file_id: str) -> list[dict]:
    """Fetch permissions for a single file."""

    @with_retry(max_retries=5)
    def _execute():
        return (
            service.permissions()
            .list(
                fileId=file_id,
                fields="permissions(id,type,role,emailAddress,displayName)",
                supportsAllDrives=True,
            )
            .execute()
        )

    result = _execute()
    return result.get("permissions", [])


def enrich_permissions(service: Resource, files: list[dict]) -> list[dict]:
    """Enrich shared drive files with full permission details."""
    for f in files:
        if f.get("driveId") and not f.get("permissions"):
            perms = get_file_permissions(service, f["id"])
            f["permissions"] = perms
    return files


def summarize_permissions(files: list[DriveFile]) -> dict:
    """Summarize permission status across all files."""
    public = []
    domain = []
    specific_users = []
    not_shared = []

    for f in files:
        if not f.permissions:
            not_shared.append(f)
            continue

        has_public = False
        has_domain = False
        has_specific = False

        for p in f.permissions:
            if p.type == "anyone":
                has_public = True
            elif p.type == "domain":
                has_domain = True
            elif p.type in ("user", "group"):
                has_specific = True

        if has_public:
            public.append(f)
        elif has_domain:
            domain.append(f)
        elif has_specific:
            specific_users.append(f)
        else:
            not_shared.append(f)

    return {
        "public": len(public),
        "domain": len(domain),
        "specific_users": len(specific_users),
        "not_shared": len(not_shared),
        "details": {
            "public_files": [{"id": f.id, "name": f.name, "path": f.path} for f in public],
            "domain_files": [{"id": f.id, "name": f.name, "path": f.path} for f in domain],
        },
    }
