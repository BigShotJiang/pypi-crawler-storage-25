"""File content reading — export Google Workspace docs and download binary files."""

from __future__ import annotations

import io
from typing import TYPE_CHECKING

from googleapiclient.http import MediaIoBaseDownload

from gdrive_organizer.utils.retry import with_retry

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

# Google Workspace MIME types → available export formats
WORKSPACE_EXPORT_MAP: dict[str, dict[str, str]] = {
    "application/vnd.google-apps.document": {
        "text/plain": "txt",
        "text/html": "html",
        "application/pdf": "pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    },
    "application/vnd.google-apps.spreadsheet": {
        "text/csv": "csv",
        "application/pdf": "pdf",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    },
    "application/vnd.google-apps.presentation": {
        "text/plain": "txt",
        "application/pdf": "pdf",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    },
    "application/vnd.google-apps.drawing": {
        "image/png": "png",
        "application/pdf": "pdf",
        "image/svg+xml": "svg",
    },
}

# Human-friendly format aliases
FORMAT_ALIASES: dict[str, str] = {
    "text": "text/plain",
    "txt": "text/plain",
    "html": "text/html",
    "pdf": "application/pdf",
    "csv": "text/csv",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "png": "image/png",
    "svg": "image/svg+xml",
}


def is_exportable(mime_type: str) -> bool:
    """Check if a MIME type is a Google Workspace type that requires export."""
    return mime_type in WORKSPACE_EXPORT_MAP


def get_export_formats(mime_type: str) -> dict[str, str]:
    """Return available export formats for a Google Workspace MIME type."""
    return WORKSPACE_EXPORT_MAP.get(mime_type, {})


def resolve_export_mime(format_name: str) -> str:
    """Resolve a human-friendly format name to a MIME type."""
    return FORMAT_ALIASES.get(format_name.lower(), format_name)


@with_retry(max_retries=3)
def export_file(service: Resource, file_id: str, export_mime: str = "text/plain") -> bytes:
    """Export a Google Workspace file to the specified format."""
    request = service.files().export_media(fileId=file_id, mimeType=export_mime)
    buffer = io.BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)
    done = False
    while not done:
        _, done = downloader.next_chunk()
    return buffer.getvalue()


@with_retry(max_retries=3)
def download_file(service: Resource, file_id: str) -> bytes:
    """Download a binary (non-Google-Workspace) file."""
    request = service.files().get_media(fileId=file_id)
    buffer = io.BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)
    done = False
    while not done:
        _, done = downloader.next_chunk()
    return buffer.getvalue()


def read_file_content(service: Resource, file_id: str, mime_type: str) -> str | bytes:
    """Read file content — auto-detects whether to export or download.

    Returns str for text-exportable Google Workspace files, bytes otherwise.
    """
    if is_exportable(mime_type):
        data = export_file(service, file_id, "text/plain")
        return data.decode("utf-8", errors="replace")
    return download_file(service, file_id)


def truncate_text(text: str, head: int = 300, tail: int = 150) -> str:
    """Truncate text to head + tail with sentence-boundary alignment.

    - head: max chars from beginning, cut at last sentence boundary
    - tail: max chars from end, cut at first sentence boundary
    - If total text <= head + tail, return as-is
    """
    if len(text) <= head + tail:
        return text.strip()

    # Head: find last sentence boundary within limit
    head_text = text[:head]
    sentence_ends = [head_text.rfind(c) for c in (".\n", "\n", ". ", "! ", "? ")]
    cut = max(p for p in sentence_ends if p > 0) + 1 if any(p > 0 for p in sentence_ends) else head
    head_part = text[:cut].strip()

    # Tail: find first sentence boundary from the tail region
    tail_start = len(text) - tail
    tail_text = text[tail_start:]
    sentence_starts = []
    for c in ("\n", ". ", "! ", "? "):
        idx = tail_text.find(c)
        if idx >= 0:
            sentence_starts.append(idx + len(c))
    start = min(sentence_starts) if sentence_starts else 0
    tail_part = tail_text[start:].strip()

    return f"{head_part}\n\n[...중략...]\n\n{tail_part}"


def extract_text_snippet(
    service: Resource,
    file_id: str,
    mime_type: str,
    head: int = 300,
    tail: int = 150,
) -> str:
    """Extract a text snippet for LLM classification.

    For Google Workspace files: export as text, then truncate.
    For binary/non-exportable files: return empty string.
    """
    if not is_exportable(mime_type):
        return ""
    # Skip drawings (no meaningful text)
    if mime_type == "application/vnd.google-apps.drawing":
        return ""
    try:
        data = export_file(service, file_id, "text/plain")
        full_text = data.decode("utf-8", errors="replace")
        return truncate_text(full_text, head, tail)
    except Exception:
        return ""


def get_file_metadata(service: Resource, file_id: str) -> dict:
    """Fetch metadata for a single file."""
    return (
        service.files()
        .get(fileId=file_id, fields="id,name,mimeType,size", supportsAllDrives=True)
        .execute()
    )
