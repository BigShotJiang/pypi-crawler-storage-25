"""Flat crawl scanner for Google Drive API v3."""

from __future__ import annotations

from typing import TYPE_CHECKING

from googleapiclient.errors import HttpError
from rich.progress import Progress, SpinnerColumn, TextColumn

from gdrive_organizer.utils.logger import get_logger
from gdrive_organizer.utils.retry import with_retry

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

logger = get_logger("scanner.crawler")

# Shared file field list — used by both files.list and changes.list.
# Note: permissions field is excluded because it forces pageSize to max 100.
# Permissions are fetched separately via the permissions command.
_FILE_FIELDS = (
    "id,name,mimeType,parents,owners(displayName,emailAddress),"
    "shared,createdTime,modifiedTime,size,webViewLink,driveId,shortcutDetails,"
    "md5Checksum,sha256Checksum,ownedByMe,description,starred,"
    "lastModifyingUser(displayName,emailAddress),"
    "originalFilename,quotaBytesUsed,fileExtension,fullFileExtension,viewedByMeTime,"
    "imageMediaMetadata(width,height,rotation,cameraMake,cameraModel),"
    "videoMediaMetadata(width,height,durationMillis),"
    "sharingUser(displayName,emailAddress),version"
)

FIELDS = f"files({_FILE_FIELDS}),nextPageToken"
CHANGE_FIELDS = f"changes(fileId,file({_FILE_FIELDS}),removed),newStartPageToken,nextPageToken"


def scan_all_files(
    service: Resource,
    query: str = "trashed=false",
    page_size: int = 1000,
) -> list[dict]:
    """Flat crawl all files using files.list with pagination."""
    all_files: list[dict] = []

    @with_retry(max_retries=5)
    def _execute_list(request):
        return request.execute()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Scanning Drive...", total=None)

        request = service.files().list(
            q=query,
            pageSize=page_size,
            fields=FIELDS,
            includeItemsFromAllDrives=True,
            supportsAllDrives=True,
        )

        while request is not None:
            response = _execute_list(request)
            files = response.get("files", [])
            all_files.extend(files)
            progress.update(task, description=f"Scanning Drive... ({len(all_files)} files)")
            request = service.files().list_next(request, response)

    return all_files


def fetch_drive_info(service: Resource) -> dict:
    """Fetch Drive account info (user, storage quota)."""

    @with_retry(max_retries=3)
    def _execute():
        return service.about().get(fields="user(displayName,emailAddress),storageQuota").execute()

    about = _execute()
    user = about.get("user", {})
    quota = about.get("storageQuota", {})
    return {
        "user_name": user.get("displayName", ""),
        "user_email": user.get("emailAddress", ""),
        "storage_limit": int(quota.get("limit", 0)),
        "storage_used": int(quota.get("usage", 0)),
        "storage_in_drive": int(quota.get("usageInDrive", 0)),
        "storage_in_trash": int(quota.get("usageInDriveTrash", 0)),
    }


def enrich_permissions_for_shared(
    service: Resource,
    files: list[dict],
    delay: float = 0.05,
) -> int:
    """Enrich permissions for files that I own AND are shared (in-place).

    Only fetches permissions for files where ownedByMe=True AND shared=True.
    This is fast because shared-by-me files are usually a small subset.
    Returns the number of files enriched.
    """
    import time

    enriched = 0
    for f in files:
        if not (f.get("ownedByMe") and f.get("shared")):
            continue
        if f.get("mimeType") == "application/vnd.google-apps.folder":
            # Folders can also be shared — include them
            pass

        @with_retry(max_retries=3)
        def _get_perms(fid=f["id"]):
            return (
                service.permissions()
                .list(
                    fileId=fid,
                    fields=(
                        "permissions(id,type,role,emailAddress,"
                        "displayName,domain,allowFileDiscovery)"
                    ),
                    supportsAllDrives=True,
                )
                .execute()
            )

        try:
            result = _get_perms()
            f["permissions"] = result.get("permissions", [])
            enriched += 1
            if delay > 0:
                time.sleep(delay)
        except HttpError as e:
            logger.warning(
                "Permission fetch failed for %s (HTTP %s): %s",
                f["id"],
                e.resp.status if e.resp else "?",
                e,
            )
            f["permissions"] = []
        except Exception as e:
            # Unexpected non-API error — log at ERROR and re-raise
            logger.error("Unexpected error fetching permissions for %s: %s", f["id"], e)
            raise

    return enriched


def enrich_revisions(
    service: Resource,
    files: list[dict],
    max_files: int = 200,
    delay: float = 0.05,
) -> None:
    """Enrich files with revision count (in-place). Only for non-folder files."""
    import time

    count = 0
    for f in files:
        if f.get("mimeType") == "application/vnd.google-apps.folder":
            continue
        if count >= max_files:
            break

        @with_retry(max_retries=3)
        def _get_revisions(fid=f["id"]):
            return service.revisions().list(fileId=fid, fields="revisions(id)").execute()

        try:
            revs = _get_revisions()
            f["revisionCount"] = len(revs.get("revisions", []))
            count += 1
            if delay > 0:
                time.sleep(delay)
        except HttpError as e:
            logger.warning(
                "Revision fetch failed for %s (HTTP %s): %s",
                f["id"],
                e.resp.status if e.resp else "?",
                e,
            )
            f["revisionCount"] = 0
        except Exception as e:
            logger.error("Unexpected error fetching revisions for %s: %s", f["id"], e)
            raise

    # Files not enriched get 0
    for f in files:
        if "revisionCount" not in f:
            f["revisionCount"] = 0


def get_start_page_token(service: Resource) -> str:
    """Get the starting page token for the Changes API."""

    @with_retry(max_retries=5)
    def _execute():
        return service.changes().getStartPageToken(supportsAllDrives=True).execute()

    response = _execute()
    return response["startPageToken"]
