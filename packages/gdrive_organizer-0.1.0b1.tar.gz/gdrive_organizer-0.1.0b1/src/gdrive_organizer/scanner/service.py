"""Scan orchestration service — extracted from cli.py to create a testable seam.

This module owns the full-scan workflow: crawl → filter → tree → enrich → save.
CLI commands call this instead of orchestrating inline.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config


@dataclass
class ScanResult:
    """Result of a full scan operation."""

    filepath: Path
    file_count: int
    folder_count: int
    total_items: int
    duration_ms: int
    permissions_enriched: int


def run_full_scan(
    service: Resource,
    config: Config,
    *,
    folder_id: str | None = None,
    apply_filters: bool = True,
) -> ScanResult:
    """Execute a full Drive scan: crawl → filter → tree → enrich → snapshot.

    This is the extracted orchestration from cli.py:scan(). It returns a
    ScanResult with summary data instead of printing directly to the console.
    """
    from gdrive_organizer.scanner.crawler import (
        enrich_permissions_for_shared,
        enrich_revisions,
        fetch_drive_info,
        get_start_page_token,
        scan_all_files,
    )
    from gdrive_organizer.scanner.tree import (
        build_tree,
        compute_paths,
        filter_subtree,
        inject_paths_into_raw,
    )
    from gdrive_organizer.store.snapshot import save_snapshot

    start_time = time.time()

    query = "trashed=false"
    files = scan_all_files(service, query=query, page_size=config.scan_page_size)

    # Apply exclusion filters
    filter_stats = None
    if apply_filters:
        from gdrive_organizer.scanner.filter import filter_files, load_exclude_rules

        rules = load_exclude_rules(config)
        files, filter_stats = filter_files(files, rules)

    # Subtree filter
    if folder_id:
        node_map, _ = build_tree(files)
        subtree = filter_subtree(node_map, folder_id)
        if not subtree:
            raise ValueError(f"Folder {folder_id} not found in scan results.")
        subtree_ids: set[str] = set()
        _collect_ids(subtree[0], subtree_ids)
        files = [f for f in files if f["id"] in subtree_ids]

    # Build tree and compute paths
    node_map, roots = build_tree(files)
    compute_paths(roots)
    inject_paths_into_raw(node_map)

    # Fetch drive info
    drive_info_data = fetch_drive_info(service)

    # Enrich permissions
    perm_count = enrich_permissions_for_shared(service, files)

    # Enrich revisions
    enrich_revisions(service, files, max_files=200)

    # Save
    change_token = get_start_page_token(service)
    duration_ms = int((time.time() - start_time) * 1000)
    filepath = save_snapshot(
        files,
        change_token,
        config,
        duration_ms=duration_ms,
        drive_info_data=drive_info_data,
    )

    mime_folder = "application/vnd.google-apps.folder"
    folder_count = sum(1 for f in files if f.get("mimeType") == mime_folder)
    file_count = len(files) - folder_count

    return ScanResult(
        filepath=filepath,
        file_count=file_count,
        folder_count=folder_count,
        total_items=len(files),
        duration_ms=duration_ms,
        permissions_enriched=perm_count,
    )


def _collect_ids(node, ids: set) -> None:
    """Recursively collect all file IDs in a subtree."""
    ids.add(node.file_id)
    for child in node.children:
        _collect_ids(child, ids)
