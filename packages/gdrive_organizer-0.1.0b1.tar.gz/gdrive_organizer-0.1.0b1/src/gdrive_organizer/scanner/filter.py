"""Scan filtering — exclude cache, packages, build artifacts from snapshots."""

from __future__ import annotations

import json
import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gdrive_organizer.config import Config

FOLDER_MIME = "application/vnd.google-apps.folder"

# --- Default exclude patterns ---

DEFAULT_EXCLUDED_FOLDERS: frozenset[str] = frozenset(
    {
        # JavaScript / Node
        "node_modules",
        ".npm",
        ".yarn",
        ".pnpm-store",
        # Python
        "__pycache__",
        ".venv",
        "venv",
        "env",
        ".tox",
        ".nox",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        ".eggs",
        # VCS
        ".git",
        ".svn",
        ".hg",
        # Build artifacts
        "vendor",
        "target",
        "build",
        "dist",
        "out",
        # Build tools
        ".gradle",
        ".maven",
        ".cargo",
        # Frontend frameworks
        ".next",
        ".nuxt",
        ".output",
        ".cache",
        # iOS / macOS
        "Pods",
        "DerivedData",
        # IaC
        ".terraform",
        ".pulumi",
    }
)

DEFAULT_EXCLUDED_EXTENSIONS: frozenset[str] = frozenset(
    {
        # Compiled / object files
        ".pyc",
        ".pyo",
        ".class",
        ".o",
        ".obj",
        ".so",
        ".dll",
        ".dylib",
        # Temp / logs
        ".log",
        ".tmp",
        ".swp",
        ".swo",
    }
)

DEFAULT_EXCLUDED_NAMES: frozenset[str] = frozenset(
    {
        ".DS_Store",
        "Thumbs.db",
        "desktop.ini",
    }
)


@dataclass(frozen=True)
class ExcludeRules:
    folders: frozenset[str] = field(default_factory=lambda: DEFAULT_EXCLUDED_FOLDERS)
    extensions: frozenset[str] = field(default_factory=lambda: DEFAULT_EXCLUDED_EXTENSIONS)
    names: frozenset[str] = field(default_factory=lambda: DEFAULT_EXCLUDED_NAMES)


@dataclass
class FilterStats:
    total_before: int = 0
    total_after: int = 0
    excluded_by_folder: int = 0
    excluded_by_extension: int = 0
    excluded_by_name: int = 0


def load_exclude_rules(config: Config) -> ExcludeRules:
    """Load exclude rules: defaults merged with user config."""
    exclude_path = config.config_dir / "exclude.json"
    if not exclude_path.exists():
        return ExcludeRules()

    data = json.loads(exclude_path.read_text())

    folders = _merge_set(
        DEFAULT_EXCLUDED_FOLDERS,
        data.get("excluded_folders", {}),
    )
    extensions = _merge_set(
        DEFAULT_EXCLUDED_EXTENSIONS,
        data.get("excluded_extensions", {}),
    )
    names = _merge_set(
        DEFAULT_EXCLUDED_NAMES,
        data.get("excluded_names", {}),
    )
    return ExcludeRules(folders=folders, extensions=extensions, names=names)


def save_exclude_config(config: Config, data: dict) -> None:
    """Save user exclude overrides to exclude.json."""
    exclude_path = config.config_dir / "exclude.json"
    exclude_path.parent.mkdir(parents=True, exist_ok=True)
    exclude_path.write_text(json.dumps(data, indent=2))


def load_exclude_config(config: Config) -> dict:
    """Load raw exclude.json user overrides."""
    exclude_path = config.config_dir / "exclude.json"
    if not exclude_path.exists():
        return {
            "excluded_folders": {"add": [], "remove": []},
            "excluded_extensions": {"add": [], "remove": []},
            "excluded_names": {"add": [], "remove": []},
        }
    return json.loads(exclude_path.read_text())


def detect_desktop_sync_folders(files: list[dict]) -> set[str]:
    """Detect Google Drive Desktop sync root folders by structure.

    Desktop sync creates a top-level "machine name" folder (e.g., "내 컴퓨터",
    "Computers", "My Computer", "マイコンピュータ"). These folders are locale-dependent
    so we detect them by a heuristic: a root-level folder that contains
    child folders named like drive letters (C:, D:) or common OS paths
    (Desktop, Documents, Users, home).
    """
    # Build quick lookups
    id_to_file: dict[str, dict] = {f["id"]: f for f in files}
    children_of: dict[str, list[str]] = defaultdict(list)
    root_folders: list[dict] = []

    for f in files:
        fid = f["id"]
        parents = f.get("parents", [])
        for pid in parents:
            children_of[pid].append(fid)
        # Root-level folder = parent not in our file set
        if f.get("mimeType") == FOLDER_MIME:
            if not parents or all(p not in id_to_file for p in parents):
                root_folders.append(f)

    # Heuristic: check child folder names of each root folder
    desktop_indicators = {
        "Desktop",
        "Documents",
        "Users",
        "home",
        "바탕 화면",
        "바탕화면",
        "문서",  # Korean
        "デスクトップ",
        "ドキュメント",  # Japanese
        "Escritorio",
        "Documentos",  # Spanish
        "Bureau",
        "Mes documents",  # French
        "Schreibtisch",
        "Dokumente",  # German
        "桌面",
        "文档",  # Chinese
    }
    # Also detect drive letters like "C:", "D:"
    import re

    drive_letter_re = re.compile(r"^[A-Z]:$")

    detected: set[str] = set()
    for folder in root_folders:
        child_names = set()
        for child_id in children_of.get(folder["id"], []):
            child = id_to_file.get(child_id)
            if child and child.get("mimeType") == FOLDER_MIME:
                child_names.add(child.get("name", ""))

        has_os_folders = bool(child_names & desktop_indicators)
        has_drive_letters = any(drive_letter_re.match(n) for n in child_names)
        if has_os_folders or has_drive_letters:
            detected.add(folder["id"])

    return detected


def filter_files(
    files: list[dict],
    rules: ExcludeRules,
    *,
    exclude_desktop_sync: bool = True,
) -> tuple[list[dict], FilterStats]:
    """Remove excluded files from the flat file list.

    Algorithm:
    1. Detect and exclude desktop sync folders (locale-independent)
    2. Identify folders whose name matches excluded folder set
    3. BFS to propagate exclusion to ALL descendants
    4. Filter remaining files by extension and exact name
    """
    # Step 0: Detect desktop sync folders
    desktop_ids: set[str] = set()
    if exclude_desktop_sync:
        desktop_ids = detect_desktop_sync_folders(files)

    # Step 1: Build parent→children index and find excluded folder IDs
    children_of: dict[str, list[str]] = defaultdict(list)
    excluded_ids: set[str] = set(desktop_ids)

    for f in files:
        fid = f["id"]
        for pid in f.get("parents", []):
            children_of[pid].append(fid)
        if f.get("mimeType") == FOLDER_MIME and f.get("name", "") in rules.folders:
            excluded_ids.add(fid)

    # Step 2: BFS — propagate exclusion to all descendants
    queue = deque(excluded_ids)
    while queue:
        current = queue.popleft()
        for child_id in children_of.get(current, []):
            if child_id not in excluded_ids:
                excluded_ids.add(child_id)
                queue.append(child_id)

    folder_excluded_count = len(excluded_ids)

    # Step 3: Filter by extension and exact name
    kept: list[dict] = []
    ext_excluded = 0
    name_excluded = 0

    for f in files:
        if f["id"] in excluded_ids:
            continue
        name = f.get("name", "")
        if name in rules.names:
            name_excluded += 1
            continue
        dot_idx = name.rfind(".")
        if dot_idx > 0:
            ext = name[dot_idx:].lower()
            if ext in rules.extensions:
                ext_excluded += 1
                continue
        kept.append(f)

    stats = FilterStats(
        total_before=len(files),
        total_after=len(kept),
        excluded_by_folder=folder_excluded_count,
        excluded_by_extension=ext_excluded,
        excluded_by_name=name_excluded,
    )
    return kept, stats


# --- Junk detection ---

JUNK_PREFIXES = frozenset({"Copy of", "복사본 ", "사본 - "})
JUNK_SUFFIXES_RE = re.compile(r"\s*\(\d+\)(\.\w+)?$")  # " (1)", " (2).pdf", etc.
JUNK_EXACT_NAMES = frozenset(
    {
        "새 폴더",
        "Untitled folder",
        "Untitled",
        "Untitled document",
        "New folder",
        "New Folder",
    }
)
JUNK_FOLDER_NAMES = frozenset({"tmp", "temp", "backup", "다운로드", "Downloads"})


@dataclass
class JunkInfo:
    file_id: str
    name: str
    reason: str  # prefix_copy, suffix_number, default_name, temp_folder
    md5: str | None = None
    is_trash_candidate: bool = False


def detect_junk_files(
    files: list[dict],
    md5_index: dict[str, list[str]] | None = None,
) -> list[JunkInfo]:
    """Detect junk files by naming patterns.

    Args:
        files: raw file dicts
        md5_index: optional {md5 -> [file_ids]} for duplicate detection
    """
    junk: list[JunkInfo] = []

    for f in files:
        name = f.get("name", "")
        fid = f["id"]
        mime = f.get("mimeType", "")
        md5 = f.get("md5Checksum")
        reason = None

        # Check prefix (Copy of, 복사본)
        for prefix in JUNK_PREFIXES:
            if name.startswith(prefix):
                reason = "prefix_copy"
                break

        # Check suffix (1), (2)
        if not reason and JUNK_SUFFIXES_RE.search(name):
            reason = "suffix_number"

        # Check exact name
        if not reason and name in JUNK_EXACT_NAMES:
            reason = "default_name"

        # Check junk folder
        if not reason and mime == FOLDER_MIME and name in JUNK_FOLDER_NAMES:
            reason = "temp_folder"

        if reason:
            is_trash = False
            if md5 and md5_index and md5 in md5_index and len(md5_index[md5]) > 1:
                is_trash = True
            junk.append(
                JunkInfo(
                    file_id=fid,
                    name=name,
                    reason=reason,
                    md5=md5,
                    is_trash_candidate=is_trash,
                )
            )

    return junk


def build_md5_index(files: list[dict]) -> dict[str, list[str]]:
    """Build md5 → [file_ids] index for duplicate detection."""
    index: dict[str, list[str]] = defaultdict(list)
    for f in files:
        md5 = f.get("md5Checksum")
        if md5:
            index[md5].append(f["id"])
    return dict(index)


def _merge_set(default: frozenset[str], overrides: dict) -> frozenset[str]:
    """Merge default set with add/remove overrides."""
    result = set(default)
    result |= set(overrides.get("add", []))
    result -= set(overrides.get("remove", []))
    return frozenset(result)
