"""In-memory tree reconstruction from flat file list."""

from __future__ import annotations

from dataclasses import dataclass, field

from rich.tree import Tree


@dataclass
class TreeNode:
    file_id: str
    name: str
    mime_type: str
    children: list[TreeNode] = field(default_factory=list)
    path: str = ""
    raw: dict = field(default_factory=dict)

    @property
    def is_folder(self) -> bool:
        return self.mime_type == "application/vnd.google-apps.folder"


def build_tree(files: list[dict]) -> tuple[dict[str, TreeNode], list[TreeNode]]:
    """Build a tree from a flat list of file dicts.

    Returns:
        (node_map, roots) — node_map keyed by file id, roots are top-level nodes.
    """
    node_map: dict[str, TreeNode] = {}

    # Create nodes
    for f in files:
        node = TreeNode(
            file_id=f["id"],
            name=f.get("name", "Untitled"),
            mime_type=f.get("mimeType", ""),
            raw=f,
        )
        node_map[node.file_id] = node

    # Link children to parents
    roots: list[TreeNode] = []
    for f in files:
        file_id = f["id"]
        parents = f.get("parents", [])
        node = node_map[file_id]
        if parents and parents[0] in node_map:
            parent_node = node_map[parents[0]]
            parent_node.children.append(node)
        else:
            roots.append(node)

    # Sort children by name (folders first, then files)
    for node in node_map.values():
        node.children.sort(key=lambda n: (not n.is_folder, n.name.lower()))

    return node_map, roots


def compute_paths(roots: list[TreeNode], prefix: str = "") -> None:
    """Compute full paths for all nodes via DFS."""
    for node in roots:
        node.path = f"{prefix}/{node.name}" if prefix else node.name
        if node.children:
            compute_paths(node.children, node.path)


def inject_paths_into_raw(node_map: dict[str, TreeNode]) -> None:
    """Write computed paths back into each node's raw dict.

    Since raw is a reference to the original dict from the files list,
    this mutates the original dicts in-place.
    """
    for node in node_map.values():
        node.raw["path"] = node.path


def filter_subtree(node_map: dict[str, TreeNode], folder_id: str) -> list[TreeNode]:
    """Return only nodes under the given folder."""
    if folder_id not in node_map:
        return []
    root = node_map[folder_id]
    return [root]


def resolve_shortcuts(node_map: dict[str, TreeNode], files: list[dict]) -> None:
    """Annotate shortcut nodes with target info from raw data."""
    for f in files:
        details = f.get("shortcutDetails")
        if details and f["id"] in node_map:
            node = node_map[f["id"]]
            node.raw["target_id"] = details.get("targetId")
            node.raw["target_mime_type"] = details.get("targetMimeType")


def tree_to_rich(roots: list[TreeNode], max_depth: int | None = None) -> Tree:
    """Convert TreeNode hierarchy to a Rich Tree for terminal display."""
    rich_tree = Tree("[bold]My Drive[/bold]")
    _add_children(rich_tree, roots, current_depth=0, max_depth=max_depth)
    return rich_tree


def _add_children(
    parent: Tree,
    nodes: list[TreeNode],
    current_depth: int,
    max_depth: int | None,
) -> None:
    """Recursively add children to a Rich Tree."""
    if max_depth is not None and current_depth >= max_depth:
        return
    for node in nodes:
        icon = "\U0001f4c1" if node.is_folder else "\U0001f4c4"
        label = f"{icon} {node.name}"
        branch = parent.add(label)
        if node.children:
            _add_children(branch, node.children, current_depth + 1, max_depth)
