"""Configuration management for GDrive Organizer."""

import json
import os
import platform
from pathlib import Path

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings

APP_NAME = "gdrive-organizer"


def _default_config_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        appdata = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
        return appdata / APP_NAME
    # macOS and Linux: use ~/.config/ (widely adopted by CLI tools)
    return Path.home() / ".config" / APP_NAME


def _default_data_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        localappdata = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return localappdata / APP_NAME
    # macOS and Linux
    return Path.home() / ".local" / "share" / APP_NAME


class Config(BaseSettings):
    model_config = {"env_prefix": "GDRIVE_"}

    config_dir: Path = _default_config_dir()
    data_dir: Path = _default_data_dir()
    credentials_path: Path = Path()
    token_path: Path = Path()

    llm_model: str = "grok-4-1-fast-non-reasoning"
    viewer_port: int = 8765
    viewer_host: str = "127.0.0.1"
    log_level: str = "INFO"
    scan_page_size: int = 1000
    batch_size: int = 100
    write_rate_limit: float = 3.0
    snapshot_max_age_minutes: int = 60
    oauth_readonly: bool = False

    @field_validator("batch_size")
    @classmethod
    def _clamp_batch_size(cls, v: int) -> int:
        """Enforce Google Batch API limit: max 100 requests per batch."""
        if v < 1 or v > 100:
            raise ValueError(
                f"batch_size must be between 1 and 100 (got {v}). "
                "Google Drive Batch API rejects larger batches."
            )
        return v

    @model_validator(mode="after")
    def _derive_paths(self):
        if self.credentials_path == Path():
            self.credentials_path = self.config_dir / "credentials.json"
        if self.token_path == Path():
            self.token_path = self.config_dir / "token.json"
        return self


def _mkdir_restricted(path: Path) -> None:
    """Create directory with owner-only permissions on POSIX."""
    path.mkdir(parents=True, exist_ok=True)
    if platform.system() != "Windows":
        os.chmod(path, 0o700)


def ensure_dirs(config: Config) -> None:
    """Create necessary directories with restricted permissions.

    All directories are chmod 0700 (owner rwx only) on POSIX.
    On Windows, default ACLs apply (no chmod equivalent).
    """
    _mkdir_restricted(config.config_dir)
    _mkdir_restricted(config.data_dir / "snapshots")
    _mkdir_restricted(config.data_dir / "plans")
    _mkdir_restricted(config.data_dir / "logs")


def save_config(config: Config, path: Path | None = None) -> None:
    """Save config to JSON file."""
    config_file = path or (config.config_dir / "config.json")
    config_file.parent.mkdir(parents=True, exist_ok=True)
    data = config.model_dump(mode="json")
    # Convert Path objects to strings for JSON serialization
    for _key, value in data.items():
        if isinstance(value, str) and ("/" in value or "\\" in value):
            try:
                Path(value)
            except (TypeError, ValueError):
                pass
    config_file.write_text(json.dumps(data, indent=2, default=str))


def load_config(config_dir: Path | None = None) -> Config:
    """Load config from JSON file, falling back to defaults + env vars."""
    dir_path = config_dir or _default_config_dir()
    config_file = dir_path / "config.json"
    if config_file.exists():
        data = json.loads(config_file.read_text())
        data["config_dir"] = str(dir_path)
        return Config(**data)
    return Config(config_dir=dir_path)
