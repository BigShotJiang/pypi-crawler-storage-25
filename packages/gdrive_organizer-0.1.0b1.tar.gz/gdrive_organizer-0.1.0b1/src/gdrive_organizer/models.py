"""Shared Pydantic models for GDrive Organizer."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field


class FileType(StrEnum):
    FILE = "file"
    FOLDER = "folder"
    SHORTCUT = "shortcut"


class PermissionRole(StrEnum):
    OWNER = "owner"
    WRITER = "writer"
    COMMENTER = "commenter"
    READER = "reader"


class DrivePermission(BaseModel):
    id: str
    type: str  # user, group, domain, anyone
    role: PermissionRole
    email: str | None = None
    display_name: str | None = None


class DriveFile(BaseModel):
    id: str
    name: str
    mime_type: str
    parents: list[str] = Field(default_factory=list)
    path: str = ""
    owners: list[str] = Field(default_factory=list)
    shared: bool = False
    permissions: list[DrivePermission] = Field(default_factory=list)
    created_time: datetime | None = None
    modified_time: datetime | None = None
    size: int = 0
    web_view_link: str | None = None
    drive_id: str | None = None

    # Extended metadata
    md5_checksum: str | None = None
    sha256_checksum: str | None = None
    owned_by_me: bool | None = None
    description: str | None = None
    starred: bool = False
    last_modifying_user: str | None = None
    original_filename: str | None = None
    quota_bytes_used: int = 0
    file_extension: str | None = None
    full_file_extension: str | None = None
    viewed_by_me_time: datetime | None = None
    image_media_metadata: dict | None = None
    video_media_metadata: dict | None = None

    # Sharing metadata
    sharing_user: str | None = None  # who shared this file with me
    version: str | None = None  # file version number
    revision_count: int = 0  # number of revisions (populated by enrich step)

    @property
    def file_type(self) -> FileType:
        if self.mime_type == "application/vnd.google-apps.folder":
            return FileType.FOLDER
        if self.mime_type == "application/vnd.google-apps.shortcut":
            return FileType.SHORTCUT
        return FileType.FILE


class SnapshotStats(BaseModel):
    total_files: int = 0
    total_folders: int = 0
    total_size: int = 0
    scan_duration_ms: int = 0


class DriveInfo(BaseModel):
    """Drive account storage and user info from about() API."""

    user_name: str = ""
    user_email: str = ""
    storage_limit: int = 0  # bytes
    storage_used: int = 0
    storage_in_drive: int = 0
    storage_in_trash: int = 0


class Snapshot(BaseModel):
    version: str = "1.2"
    scanned_at: datetime
    type: str = "full"  # full or incremental
    stats: SnapshotStats = Field(default_factory=SnapshotStats)
    drive_info: DriveInfo | None = None
    change_token: str | None = None
    files: list[DriveFile] = Field(default_factory=list)


class OperationType(StrEnum):
    RENAME = "rename"
    MOVE = "move"
    RENAME_AND_MOVE = "rename_and_move"
    CREATE_FOLDER = "create_folder"
    CREATE_SHORTCUT = "create_shortcut"
    UPDATE_DESCRIPTION = "update_description"
    TRASH = "trash"
    UNTRASH = "untrash"


class PlanOperation(BaseModel):
    file_id: str
    current_name: str
    current_path: str
    operation: OperationType
    new_name: str | None = None
    new_parent_id: str | None = None
    current_parent_id: str | None = None
    new_path: str | None = None
    reason: str = ""

    # Shortcut-specific
    shortcut_target_id: str | None = None
    shortcut_parent_id: str | None = None

    # Description-specific
    new_description: str | None = None


class PlanStats(BaseModel):
    total_operations: int = 0
    renames: int = 0
    moves: int = 0
    rename_and_moves: int = 0
    shortcuts: int = 0
    descriptions: int = 0
    trashed: int = 0


class ExecutionPlan(BaseModel):
    version: str = "2.0"
    created_at: datetime
    snapshot_ref: str = ""
    preset_id: str = ""
    operations: list[PlanOperation] = Field(default_factory=list)
    stats: PlanStats = Field(default_factory=PlanStats)


# --- LLM Response Contract ---


class LLMResponseItem(BaseModel):
    """Schema for LLM classification output (JSON Contract)."""

    file_id: str
    move_to: str = ""  # e.g., "보관함/2026/04"
    shortcuts: list[str] = Field(default_factory=list)  # e.g., ["Sec_Brain", "태그/AI"]
    new_description: str | None = None
