"""Exponential backoff retry decorator for Google API calls."""

import functools
import random
import time

from googleapiclient.errors import HttpError

RETRYABLE_STATUS_CODES = {429, 500, 503}


def _is_rate_limit_error(error: HttpError) -> bool:
    """Check if a 403 error is a rate limit (not permission denied)."""
    try:
        content = error.error_details
        if content:
            for detail in content:
                reason = detail.get("reason", "")
                if reason in ("rateLimitExceeded", "userRateLimitExceeded"):
                    return True
    except (AttributeError, KeyError, TypeError):
        pass
    return False


def _is_retryable(error: HttpError) -> bool:
    """Determine if an HttpError should be retried."""
    status = error.resp.status
    if status in RETRYABLE_STATUS_CODES:
        return True
    if status == 403:
        return _is_rate_limit_error(error)
    return False


def with_retry(max_retries: int = 5, max_delay: float = 64.0):
    """Decorator that retries on transient Google API errors with exponential backoff."""

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except HttpError as e:
                    if attempt == max_retries or not _is_retryable(e):
                        raise
                    delay = min(2**attempt + random.uniform(0, 1), max_delay)
                    time.sleep(delay)

        return wrapper

    return decorator
