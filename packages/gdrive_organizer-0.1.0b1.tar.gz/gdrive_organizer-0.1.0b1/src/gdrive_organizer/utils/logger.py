"""Rich-based logging setup."""

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from rich.logging import RichHandler

_configured: set[str] = set()


def setup_logger(
    name: str = "gdrive_organizer",
    log_level: str = "INFO",
    log_dir: Path | None = None,
) -> logging.Logger:
    """Configure and return a logger with Rich console output and optional file output."""
    logger = logging.getLogger(name)

    if name in _configured:
        return logger

    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # Rich console handler
    console_handler = RichHandler(
        rich_tracebacks=True,
        show_time=True,
        show_path=False,
    )
    console_handler.setLevel(logging.DEBUG)
    logger.addHandler(console_handler)

    # File handler (if log_dir provided)
    if log_dir:
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_dir / "gdrive-organizer.log",
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=3,
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        )
        logger.addHandler(file_handler)

    _configured.add(name)
    return logger


def get_logger(name: str) -> logging.Logger:
    """Get a child logger. Assumes setup_logger was already called."""
    return logging.getLogger(f"gdrive_organizer.{name}")
