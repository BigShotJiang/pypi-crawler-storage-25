# GDrive Organizer — Architecture Document

> **Version**: 1.0
> **Last Updated**: 2026-04-08
> **Status**: Ready for Implementation

---

## 1. Project Overview

### 1.1 Purpose

Google Drive에 저장된 대량의 파일/폴더를 체계적으로 관리하기 위한 CLI 기반 도구.
Drive API를 통해 전체 메타데이터를 수집하고, AI(LLM)를 활용해 파일 분류/이름 규칙 적용/폴더 정리를 자동화한다.

### 1.2 Core Capabilities

- **Full Drive Scan**: 전체 파일/폴더 메타데이터를 재귀적으로 수집 → JSON snapshot 저장
- **Tree Visualization**: 브라우저 기반 트리 뷰어로 현재 Drive 구조 확인
- **Permission Audit**: 파일/폴더별 공유 상태, 권한 정보 조회
- **AI Classification**: LLM을 활용한 파일 자동 분류 및 이름 규칙 제안
- **Batch Operations**: 이름 변경, 폴더 이동을 일괄 처리 (dry-run → approve → apply)
- **Change Tracking**: Changes API를 활용한 증분 동기화 (재스캔 없이 변경사항만 반영)

### 1.3 Target Users

- 본인 (Primary)
- 소수 개발자 지인 (Secondary) — 각자 GCP OAuth 클라이언트를 등록하여 사용

### 1.4 Distribution Model

- GitHub (private or public) 배포
- `pip install` 또는 `pipx install` 로 설치
- 사용자가 각자 GCP 프로젝트에서 OAuth 2.0 Desktop App 클라이언트를 생성하고 `credentials.json`을 등록
- Google OAuth 심사 불필요 (testing mode, 최대 100명 테스트 사용자)

---

## 2. System Architecture

### 2.1 Three-Layer Design

```
┌─────────────────────────────────────────────────────┐
│  USER LAYER                                         │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │
│  │  CLI (typer)  │ │  Web Viewer  │ │  Config/Auth │ │
│  │  scan/plan/   │ │  (FastAPI +  │ │  OAuth creds │ │
│  │  apply/export │ │   Jinja2)    │ │  token.json  │ │
│  └──────┬───────┘ └──────┬───────┘ └──────────────┘ │
└─────────┼────────────────┼──────────────────────────┘
          │                │
┌─────────┼────────────────┼──────────────────────────┐
│  CORE ENGINE             │                          │
│  ┌──────────────┐ ┌──────┴───────┐ ┌──────────────┐ │
│  │ Drive Scanner │ │  JSON Store  │ │AI Classifier │ │
│  │ flat-crawl +  │ │  snapshot/   │ │  LLM Hub     │ │
│  │ pagination    │ │  diff/plans  │ │  integration │ │
│  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ │
│         │         ┌──────┴───────┐        │         │
│         │         │ Batch Runner │        │         │
│         │         │ rate-limited │        │         │
│         │         │ executor     │        │         │
│         │         └──────┬───────┘        │         │
└─────────┼────────────────┼────────────────┼─────────┘
          │                │                │
┌─────────┼────────────────┼────────────────┼─────────┐
│  EXTERNAL SERVICES       │                │         │
│  ┌──────┴───────┐ ┌──────┴───────┐ ┌─────┴────────┐│
│  │ Google Drive  │ │ Google Drive  │ │   LLM Hub    ││
│  │ API v3 (read) │ │ API v3 (write)│ │  (OpenAI-    ││
│  │ files.list    │ │ files.update  │ │  compatible)  ││
│  │ files.export  │ │ batch API     │ │              ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└─────────────────────────────────────────────────────┘
```

### 2.2 Data Flow

```
[1] scan → files.list (flat crawl, pageSize=1000)
         → 로컬 JSON snapshot 저장
         → 메모리에서 트리 구조 재구성

[2] view → FastAPI 로컬 서버 → 브라우저에서 트리/권한/통계 확인

[3] classify → snapshot JSON 로드
             → LLM Hub에 메타데이터 전송
             → AI가 분류/이름 규칙 제안
             → plan.json 생성 (변경 계획)

[4] review → 웹 뷰어에서 plan 확인/수정
           → diff 형태로 before/after 비교

[5] apply → plan.json 읽기
          → batch API로 Drive에 변경 적용
          → rate limit 준수 (3 writes/sec)
          → 결과 로그 저장
```

### 2.3 Directory Structure

```
gdrive-organizer/
├── pyproject.toml              # Project metadata, dependencies
├── README.md                   # 사용자 가이드 (GCP 설정 포함)
├── src/
│   └── gdrive_organizer/
│       ├── __init__.py
│       ├── cli.py              # Typer CLI entry point
│       ├── config.py           # 설정 관리 (paths, defaults)
│       ├── auth/
│       │   ├── __init__.py
│       │   └── oauth.py        # OAuth flow, token management
│       ├── scanner/
│       │   ├── __init__.py
│       │   ├── crawler.py      # Flat-crawl + pagination
│       │   ├── tree.py         # In-memory tree reconstruction
│       │   └── permissions.py  # Permission fetching
│       ├── store/
│       │   ├── __init__.py
│       │   ├── snapshot.py     # JSON snapshot read/write
│       │   └── changelog.py    # Changes API integration
│       ├── ai/
│       │   ├── __init__.py
│       │   ├── classifier.py   # LLM-based file classification
│       │   ├── namer.py        # Naming rule engine
│       │   └── planner.py      # Plan generation (rename/move)
│       ├── executor/
│       │   ├── __init__.py
│       │   ├── batch.py        # Batch API wrapper
│       │   ├── rate_limiter.py # Token bucket rate limiter
│       │   └── runner.py       # Plan execution with rollback
│       ├── viewer/
│       │   ├── __init__.py
│       │   ├── app.py          # FastAPI local server
│       │   ├── templates/      # Jinja2 HTML templates
│       │   └── static/         # CSS/JS for tree viewer
│       └── utils/
│           ├── __init__.py
│           ├── retry.py        # Exponential backoff decorator
│           └── logger.py       # Structured logging
├── data/                       # 런타임 데이터 (gitignored)
│   ├── snapshots/              # JSON snapshots
│   ├── plans/                  # Execution plans
│   └── logs/                   # Execution logs
├── tests/
│   ├── test_crawler.py
│   ├── test_tree.py
│   ├── test_batch.py
│   └── fixtures/               # Mock API responses
└── docs/
    ├── 01-ARCHITECTURE.md      # This file
    ├── 02-API-REFERENCE.md     # Drive API usage patterns
    ├── 03-WORK-PLAN.md         # Stage-by-stage work plan
    └── 04-USER-GUIDE.md        # End-user setup guide
```

---

## 3. Technology Stack

| Component | Choice | Rationale |
|-----------|--------|-----------|
| Language | Python 3.12+ | Google API 공식 SDK 최고 지원, FastAPI 경험 활용 |
| CLI Framework | typer | 타입 힌트 기반 CLI, rich 통합 |
| Web Viewer | FastAPI + Jinja2 | 로컬 서버, 경량, 이미 익숙한 프레임워크 |
| Google API | google-api-python-client | 공식 Python SDK, OAuth + Drive API v3 |
| OAuth | google-auth-oauthlib | Desktop app OAuth flow 지원 |
| LLM Integration | httpx | LLM Hub의 OpenAI-compatible endpoint 호출 |
| Data Format | JSON | Snapshot, plan, config 모두 JSON |
| Package Manager | uv | 빠른 의존성 관리, lockfile 지원 |
| Testing | pytest + pytest-asyncio | 비동기 테스트 지원 |
| Linting | ruff | 빠른 Python linter/formatter |

### 3.1 Key Dependencies

```toml
[project]
dependencies = [
    "typer[all]>=0.12",
    "google-api-python-client>=2.150",
    "google-auth-oauthlib>=1.2",
    "google-auth-httplib2>=0.2",
    "fastapi>=0.115",
    "uvicorn>=0.30",
    "jinja2>=3.1",
    "httpx>=0.27",
    "rich>=13.0",
    "pydantic>=2.9",
]
```

---

## 4. Authentication Design

### 4.1 OAuth 2.0 Desktop App Flow

각 사용자가 자신의 GCP 프로젝트에서:
1. Google Cloud Console에서 프로젝트 생성
2. Drive API 활성화
3. OAuth 동의 화면 설정 (External, testing mode)
4. OAuth 2.0 클라이언트 ID 생성 (Desktop App 유형)
5. `credentials.json` 다운로드 → 프로젝트 디렉터리에 배치

### 4.2 Required Scopes

```python
SCOPES = [
    "https://www.googleapis.com/auth/drive",  # Full read/write access
]
```

> `drive` scope는 restricted scope로 분류되어 Google 심사가 필요하지만,
> testing mode에서는 심사 없이 100명까지 테스트 사용자 등록 가능.
> 단, refresh token이 7일 후 만료 → 주기적 재인증 필요.

### 4.3 Token Management

```
~/.config/gdrive-organizer/
├── credentials.json     # GCP에서 다운로드한 OAuth 클라이언트 시크릿
└── token.json           # 발급된 access/refresh token (자동 생성)
```

- Access token: 1시간 유효, 자동 갱신
- Refresh token: testing mode에서 7일 유효, 만료 시 브라우저 OAuth 재실행
- Token 파일은 `.gitignore`에 추가

---

## 5. Core Module Specifications

### 5.1 Scanner (Drive Crawler)

**Strategy: Flat Crawl + In-Memory Tree Reconstruction**

files.list를 한 번의 paginated call로 전체 파일을 수집하고, parents 필드를 기반으로 메모리에서 트리를 재구성한다.

- `pageSize=1000` (API 최대값)
- `fields=nextPageToken,files(id,name,mimeType,parents,owners,shared,createdTime,modifiedTime,size,trashed,webViewLink,permissions,shortcutDetails,driveId)`
- `q="trashed=false"` (기본 필터)
- 100K 파일 기준 ~100 API calls, 12,000/min 쿼터 내 충분

```python
# 핵심 크롤링 로직 (간략)
async def scan_all_files(service) -> list[DriveFile]:
    all_files = []
    request = service.files().list(
        q="trashed=false",
        pageSize=1000,
        fields="nextPageToken,files(id,name,mimeType,parents,...)",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
    )
    while request:
        response = request.execute()
        all_files.extend(response.get("files", []))
        request = service.files().list_next(request, response)
    return all_files
```

### 5.2 JSON Store (Snapshot)

스캔 결과를 타임스탬프 기반 JSON 파일로 저장:

```
data/snapshots/
├── 2026-04-08T14-30-00.json    # Full snapshot
├── 2026-04-09T10-00-00.json    # Incremental (changes only)
└── latest.json                 # Symlink to latest full snapshot
```

**Snapshot Schema:**
```json
{
  "version": 1,
  "scannedAt": "2026-04-08T14:30:00Z",
  "type": "full",
  "stats": {
    "totalFiles": 12345,
    "totalFolders": 890,
    "totalSize": 5368709120,
    "scanDurationMs": 45000
  },
  "changeToken": "abc123...",
  "files": [
    {
      "id": "1abc...",
      "name": "Meeting Notes.gdoc",
      "mimeType": "application/vnd.google-apps.document",
      "parents": ["0def..."],
      "path": "/Work/Projects/Meeting Notes.gdoc",
      "owners": [{"email": "user@gmail.com"}],
      "shared": true,
      "permissions": [...],
      "createdTime": "2025-01-15T09:00:00Z",
      "modifiedTime": "2026-03-20T15:30:00Z",
      "size": null
    }
  ]
}
```

### 5.3 AI Classifier

LLM Hub의 OpenAI-compatible endpoint를 통해 파일 메타데이터를 분석:

```python
# LLM Hub 연동 (OpenAI-compatible)
async def classify_files(files: list[DriveFile], config: Config) -> ClassificationResult:
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{config.llm_hub_url}/v1/chat/completions",
            headers={"X-Project-Id": "gdrive-organizer"},
            json={
                "model": "claude-sonnet",  # alias → LLM Hub가 resolve
                "messages": [
                    {"role": "system", "content": CLASSIFICATION_PROMPT},
                    {"role": "user", "content": json.dumps(file_metadata_batch)}
                ],
                "temperature": 0.1,
            }
        )
```

**분류 기능:**
- 파일을 카테고리별로 분류 (문서, 스프레드시트, 미디어, 코드 등)
- 이름 규칙 제안 (날짜 prefix, 카테고리 태그 등)
- 폴더 재구조화 제안
- 중복 파일 탐지 (이름 + 크기 기반)

### 5.4 Batch Executor

Drive API의 rate limit를 준수하면서 변경사항을 적용:

- **Rate Limit**: ~3 writes/second (token bucket 알고리즘)
- **Batch API**: 최대 100개 요청/배치, HTTP overhead 절감
- **Dry Run**: 실제 API 호출 없이 변경 계획만 출력
- **Rollback Log**: 각 변경의 원래 상태를 기록하여 되돌리기 가능

```python
# Rate-limited batch execution
class BatchExecutor:
    def __init__(self, service, rate_limit=3.0):
        self.service = service
        self.limiter = TokenBucket(rate_limit)

    async def execute_plan(self, plan: ExecutionPlan) -> ExecutionResult:
        results = []
        for batch in chunked(plan.operations, 100):
            batch_req = self.service.new_batch_http_request(callback=self._callback)
            for op in batch:
                self.limiter.acquire()
                batch_req.add(self._build_request(op))
            batch_req.execute()
            results.extend(self._collect_results())
        return ExecutionResult(results)
```

### 5.5 Web Viewer

FastAPI 로컬 서버로 브라우저에서 Drive 구조를 시각화:

- **Tree View**: 파일/폴더 트리 (collapsible, searchable)
- **Permission Matrix**: 파일별 공유 상태 한눈에 확인
- **Plan Review**: AI 제안 변경사항 diff 뷰 (before/after)
- **Statistics**: 파일 타입별 분포, 크기 분포, 최근 수정 현황

```
CLI 명령으로 서버 시작:
$ gdrive-organizer view
→ http://localhost:8765 에서 대시보드 열림
```

---

## 6. CLI Command Design

```bash
# 인증
gdrive-organizer auth login          # OAuth 브라우저 로그인
gdrive-organizer auth status         # 토큰 상태 확인
gdrive-organizer auth logout         # 토큰 삭제

# 스캔
gdrive-organizer scan                # 전체 Drive 스캔 → snapshot 저장
gdrive-organizer scan --folder <id>  # 특정 폴더 하위만 스캔
gdrive-organizer scan --incremental  # Changes API로 증분 스캔

# 조회
gdrive-organizer tree                # 터미널에 트리 출력 (rich)
gdrive-organizer tree --depth 3      # 깊이 제한
gdrive-organizer stats               # 파일 통계 출력
gdrive-organizer permissions         # 공유 파일/권한 요약

# AI 분류
gdrive-organizer classify            # AI로 파일 분류 → plan 생성
gdrive-organizer classify --rules <file>  # 커스텀 규칙 파일 적용

# 변경 적용
gdrive-organizer plan show           # 현재 plan 확인
gdrive-organizer plan apply          # plan 실행 (확인 프롬프트)
gdrive-organizer plan apply --dry-run # 실행하지 않고 결과만 출력

# 웹 뷰어
gdrive-organizer view                # 브라우저 대시보드 열기
gdrive-organizer view --port 9000    # 커스텀 포트

# 설정
gdrive-organizer config show         # 현재 설정 출력
gdrive-organizer config set <key> <value>  # 설정 변경
```

---

## 7. Data Models (Pydantic)

### 7.1 Core Types

```python
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

class FileType(str, Enum):
    FILE = "file"
    FOLDER = "folder"
    SHORTCUT = "shortcut"

class PermissionRole(str, Enum):
    OWNER = "owner"
    WRITER = "writer"
    COMMENTER = "commenter"
    READER = "reader"

class DrivePermission(BaseModel):
    id: str
    type: str          # user, group, domain, anyone
    role: PermissionRole
    email: str | None = None
    display_name: str | None = None

class DriveFile(BaseModel):
    id: str
    name: str
    mime_type: str
    parents: list[str] = []
    path: str = ""     # Computed after tree build
    owners: list[dict] = []
    shared: bool = False
    permissions: list[DrivePermission] = []
    created_time: datetime | None = None
    modified_time: datetime | None = None
    size: int | None = None
    web_view_link: str | None = None
    drive_id: str | None = None  # Shared drive

class Snapshot(BaseModel):
    version: int = 1
    scanned_at: datetime
    type: str = "full"  # full | incremental
    stats: dict
    change_token: str | None = None
    files: list[DriveFile]
```

### 7.2 Plan Types

```python
class OperationType(str, Enum):
    RENAME = "rename"
    MOVE = "move"
    RENAME_AND_MOVE = "rename_and_move"

class PlanOperation(BaseModel):
    file_id: str
    current_name: str
    current_path: str
    operation: OperationType
    new_name: str | None = None
    new_parent_id: str | None = None
    new_path: str | None = None
    reason: str = ""    # AI가 제안한 이유

class ExecutionPlan(BaseModel):
    version: int = 1
    created_at: datetime
    snapshot_ref: str   # 기반 snapshot 파일명
    operations: list[PlanOperation]
    stats: dict         # 요약 (rename N개, move M개 등)
```

---

## 8. Rate Limit Strategy

### 8.1 Read Operations (Scan)

| Metric | Value |
|--------|-------|
| files.list pageSize | 1000 (최대) |
| 100K 파일 스캔 시 API calls | ~100 |
| 분당 가능 횟수 | 12,000 (쿼터) |
| 예상 스캔 시간 (100K) | 2-3분 |

→ 읽기는 rate limit 걱정 거의 없음. Exponential backoff만 구현.

### 8.2 Write Operations (Apply)

| Metric | Value |
|--------|-------|
| Sustained write rate | ~3/sec |
| Batch size | 100 requests/batch |
| Batch 간 대기 | ~33초 |
| 1,000개 파일 rename | ~5.5분 |
| 10,000개 파일 rename | ~55분 |

→ Token bucket rate limiter + exponential backoff on 403/429.

### 8.3 Retry Strategy

```python
# Exponential backoff with jitter
max_retries = 5
for attempt in range(max_retries):
    delay = min(2 ** attempt + random.uniform(0, 1), 64)
    # Retry on: 403 (rateLimitExceeded), 429, 500, 503
    # No retry on: 400, 401, 404, 403 (permission denied)
```

---

## 9. Security Considerations

- OAuth credentials (`credentials.json`, `token.json`)은 `.gitignore`에 반드시 포함
- Token은 사용자 홈 디렉터리(`~/.config/gdrive-organizer/`)에 저장
- LLM Hub 통신 시 파일 내용은 전송하지 않음 — 메타데이터(이름, 경로, 타입)만 전송
- Plan apply 전 반드시 사용자 확인 (interactive prompt 또는 `--yes` 플래그)
- Rollback log를 남겨 실수 시 복원 가능
