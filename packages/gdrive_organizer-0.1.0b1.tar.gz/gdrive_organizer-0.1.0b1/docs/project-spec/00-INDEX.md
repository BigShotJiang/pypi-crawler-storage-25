# GDrive Organizer — 프로젝트 스펙 문서

> 최종 업데이트: 2026-04-08

## 문서 목록

| 문서 | 내용 |
|------|------|
| [01-PROJECT-OVERVIEW.md](./01-PROJECT-OVERVIEW.md) | 프로젝트 개요, 핵심 수치, 기술 스택 |
| [02-ARCHITECTURE-DETAIL.md](./02-ARCHITECTURE-DETAIL.md) | 모듈별 상세 구조, 의존성 그래프, 설계 결정 근거 |
| [03-FEATURES-AND-COMMANDS.md](./03-FEATURES-AND-COMMANDS.md) | 전체 CLI 명령어, Web API, 기능별 동작 방식 |
| [04-DESIGN-DECISIONS.md](./04-DESIGN-DECISIONS.md) | 왜 이렇게 만들었는가 — 모든 설계 결정의 이유 |
| [05-KNOWN-ISSUES-AND-ROADMAP.md](./05-KNOWN-ISSUES-AND-ROADMAP.md) | 알려진 한계, 남은 과제, 향후 로드맵 |
| [06-PIVOT-AND-NEW-ARCHITECTURE.md](./06-PIVOT-AND-NEW-ARCHITECTURE.md) | AI 파워 유저 피벗, Storage/View 분리, 프롬프트 주도 설계 |
| [07-MIGRATION-PLAN.md](./07-MIGRATION-PLAN.md) | AS-IS/TO-BE 비교, 7개 WP 체크리스트, 실행 순서, 리스크, 검증 계획 |
