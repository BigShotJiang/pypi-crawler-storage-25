# 04. 설계 결정과 그 이유

## 아키텍처 결정

### 1. Flat Crawl (단일 호출) vs Recursive Crawl (폴더별 호출)

**결정**: Flat Crawl — `files.list` 한 번의 페이지네이션으로 전체 파일 수집

**이유**:
- Recursive: 폴더 N개 × API 호출 = N회. 40,000 폴더면 40,000 API 호출
- Flat: 전체 파일 / pageSize = 호출 수. 348K 파일 / 1000 = ~349 API 호출
- **API 호출 100배 절감**
- 트레이드오프: 메모리에 전체 파일 로드 (348K × ~500B = ~170MB). 현대 시스템에서 허용 가능

### 2. permissions 필드 제외

**결정**: `files.list`에서 `permissions` 필드를 요청하지 않음

**이유**:
- permissions 포함 시 Google API가 **pageSize를 100으로 강제 제한**
- 348K 파일: permissions 포함 → 3,487 페이지 (10배 느림)
- permissions 미포함 → 349 페이지
- 별도 `permissions` 명령에서 필요할 때만 개별 조회

### 3. Snapshot 기반 파이프라인 (Scan → Classify → Apply 분리)

**결정**: 각 단계를 독립적으로 실행, JSON 스냅샷으로 상태 전달

**이유**:
- 안전성: 사용자가 계획을 검토한 후에만 실행
- 재현성: 같은 스냅샷으로 여러 분류 전략 시도 가능
- 디버깅: JSON으로 저장되므로 사람이 읽고 수정 가능
- 트레이드오프: 디스크 사용량 증가 (gzip으로 해결)

### 4. OAuth 2.0 Desktop App (API Key 아님)

**결정**: OAuth 2.0 사용

**이유**:
- Google Drive API에서 **사용자 파일 접근은 OAuth만 허용**
- API Key는 공개 데이터만 조회 가능 (사용자 Drive 파일 목록, 수정 불가)
- 이건 선택이 아니라 Google의 정책

### 5. OAuth Credentials 자동 탐지

**결정**: Downloads 폴더에서 `client_secret_*.apps.googleusercontent.com.json` 패턴 자동 탐색

**이유**:
- 사용자 경험 단순화: GCP에서 JSON 다운로드 → `auth login` 실행 → 끝
- 수동 복사 불필요 (`cp ~/Downloads/client_secret_xxx.json ~/.config/gdrive-organizer/credentials.json`)
- 가장 최근 파일 자동 선택 (여러 번 다운로드한 경우)

### 6. 데스크톱 동기화 감지 — 이름이 아닌 구조 기반

**결정**: 하드코딩된 `"내 컴퓨터"` 대신 자식 폴더 구조로 감지

**이유**:
- Google Drive 데스크톱 동기화 폴더명은 로케일에 따라 다름
  - 한국어: `내 컴퓨터`
  - 영어: `Computers` 또는 `My Computer`
  - 일본어: `マイコンピュータ`
  - 중국어: `我的电脑`
- **이름으로 감지하면 전세계 사용자 대응 불가**
- 구조 기반 감지: 루트 폴더의 자식에 `Desktop`, `Documents`, `C:`, `D:` 등이 있으면 데스크톱 동기화
- 다국어 폴더명도 포함: `바탕 화면`, `デスクトップ`, `桌面`, `Escritorio`, `Bureau`, `Schreibtisch`

### 7. gzip 압축 스냅샷

**결정**: `.json.gz`로 저장

**이유**:
- 비압축 스냅샷: 206MB (348K 파일)
- 메타데이터 확장 후 더 커질 예정
- gzip은 JSON에 대해 ~85% 압축률
- `load_snapshot()`에서 `.json`과 `.json.gz` 모두 자동 감지

### 8. Symlink vs Copy (latest 포인터)

**결정**: Unix에서 symlink, Windows에서 copy

**이유**:
- Windows에서 symlink 생성은 **Administrator 권한 필요** (또는 Developer Mode)
- 일반 사용자 환경에서 `PermissionError` 발생
- `shutil.copy2()`로 fallback하면 기능적으로 동일
- 파일 크기가 작을 때 성능 차이 무시 가능

---

## 코드 설계 결정

### 9. Pydantic vs dataclass

| 용도 | 선택 | 이유 |
|------|------|------|
| DriveFile, Snapshot 등 | **Pydantic** | JSON 직렬화/역직렬화 필수, 유효성 검증 |
| TreeNode | **dataclass** | 내부용, 직렬화 불필요, 오버헤드 최소화 |
| FilterStats, ExcludeRules | **dataclass** | 단순 데이터 컨테이너, Pydantic 불필요 |

### 10. Async (httpx) vs Sync (google-api-python-client)

| 모듈 | 방식 | 이유 |
|------|------|------|
| Scanner/Executor | **Sync** | google-api-python-client가 동기식 SDK |
| LLM Classifier | **Async** | 여러 배치를 동시 처리 가능, httpx는 async 네이티브 |
| CLI 진입점 | **Sync** | Typer는 동기식, `asyncio.run()`으로 async 브릿지 |

### 11. 필터 규칙 — Set 기반 (O(1)) vs Glob/Regex (O(N))

**결정**: `frozenset` 기반 정확 매칭

**이유**:
- 348K 파일 × 32개 폴더 규칙 = 정규식이면 O(N×M) 비교
- set lookup은 O(1)
- 확장자도 `name.rfind(".")` + set lookup = O(1)
- 348K 파일 필터링이 1초 미만

### 12. 경로 구분자 `/` 통일

**결정**: 모든 플랫폼에서 `/` 사용 (OS 경로가 아닌 논리적 경로)

**이유**:
- Google Drive의 경로는 파일 시스템 경로가 아님
- `os.sep`을 쓰면 Windows에서 `\`가 되어 JSON 직렬화 시 이스케이프 문제
- 스냅샷 호환성: 다른 OS에서 만든 스냅샷도 동일하게 해석

### 13. Move 작업 — addParents + removeParents 동시 사용

**결정**: 이동 시 반드시 양쪽 부모를 지정

**이유**:
- `addParents`만 보내면: 파일이 기존 폴더에도 **남아있고** 새 폴더에도 **나타남** (복사 효과)
- `removeParents`를 같이 보내야: 기존 폴더에서 **제거**되고 새 폴더로 **이동**
- `PlanOperation`에 `current_parent_id` 필드를 추가하여 항상 현재 부모 추적
- 롤백 시에도 양방향 parent_id를 기록하여 정확한 역방향 이동

### 14. 2단계 실행 (폴더 먼저 → 파일 이동)

**결정**: `CREATE_FOLDER` 작업을 `RENAME/MOVE`보다 먼저 실행

**이유**:
- AI가 "이 파일을 `리서치/AI` 폴더로 이동하라"고 제안할 때, `리서치/AI` 폴더가 아직 없을 수 있음
- Phase 1에서 폴더를 먼저 생성하고 실제 Drive ID를 받음
- Phase 2에서 placeholder ID를 실제 ID로 교체 후 파일 이동
- 순서가 보장되어 "폴더 없음" 에러 방지
