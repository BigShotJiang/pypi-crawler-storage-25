# 01. 프로젝트 개요

## 한줄 요약

Google Drive API v3를 활용한 AI 기반 파일 정리 CLI 도구. 전체 파일을 스캔하고, 트리 구조를 재구성하며, AI로 분류/이름 변경/폴더 정리를 자동화한다.

## 핵심 수치

| 항목 | 수치 |
|------|------|
| Python 소스 | 3,048줄 (28개 파일) |
| 테스트 | 89개 (15개 테스트 모듈) |
| CLI 명령 | 18개 (5개 그룹) |
| Web API 엔드포인트 | 9개 |
| Pydantic 모델 | 7개 |
| 외부 API | 2개 (Google Drive v3, LLM Hub) |

## 기술 스택

| 영역 | 기술 | 선택 이유 |
|------|------|----------|
| CLI 프레임워크 | Typer + Rich | 타입 안전 인자 파싱, 컬러풀 터미널 출력 |
| Google API | google-api-python-client | 공식 Python SDK, Drive v3 전체 지원 |
| 인증 | google-auth-oauthlib | Desktop App OAuth 2.0 플로우 |
| 웹 뷰어 | FastAPI + Jinja2 | 비동기 지원, 가벼운 로컬 서버 |
| LLM 통신 | httpx (async) | OpenAI-compatible 엔드포인트, 비동기 배치 처리 |
| 데이터 모델 | Pydantic v2 | 직렬화/역직렬화, 유효성 검증, JSON 스키마 |
| 설정 관리 | pydantic-settings | 환경변수 오버라이드, 타입 안전 설정 |
| 패키지 관리 | uv + hatchling | 빠른 의존성 해결, PEP 517 빌드 |
| 테스트 | pytest + pytest-asyncio | 동기/비동기 테스트, fixture 지원 |
| 린트 | ruff | 빠르고 포괄적인 Python 린터/포매터 |

## 작동 파이프라인

```
[1] Auth          사용자 Google 계정 인증 (OAuth 2.0)
      ↓
[2] Scan          Drive 전체 파일 메타데이터 수집 (Flat Crawl)
      ↓
[3] Filter        캐시/패키지/데스크톱 동기화 파일 제외
      ↓
[4] Tree Build    부모-자식 관계로 트리 재구성 + 경로 계산
      ↓
[5] Snapshot      JSON.gz로 로컬 저장 (증분 동기화 지원)
      ↓
[6] Classify      LLM Hub로 파일 분류 + 이름 제안
      ↓
[7] Plan          실행 계획 생성 (RENAME/MOVE/CREATE_FOLDER)
      ↓
[8] Review        CLI 또는 웹 뷰어에서 계획 검토
      ↓
[9] Execute       Batch API로 실행 (Rate Limiting + Rollback)
```

## 실제 검증 결과

| 테스트 | 결과 |
|--------|------|
| OAuth 인증 | 완료 (papachanny@gmail.com) |
| 전체 스캔 (348,787 파일) | 15분 소요 |
| 필터링 후 | 1,596개 순수 Drive 파일 |
| 증분 스캔 | 0.8초 |
| 웹 뷰어 응답 | 1.3ms |
| gzip 스냅샷 | 기존 206MB → 압축 적용 |

## 디렉토리 구조

```
src/gdrive_organizer/
├── cli.py              # Typer CLI 진입점 (18개 명령)
├── config.py           # 플랫폼별 설정 관리
├── models.py           # 공유 Pydantic 모델 (7개)
├── auth/oauth.py       # OAuth 2.0 + credentials 자동 탐지
├── scanner/
│   ├── crawler.py      # files.list Flat Crawl
│   ├── tree.py         # 메모리 내 트리 재구성
│   ├── filter.py       # 제외 규칙 + 데스크톱 동기화 감지
│   ├── permissions.py  # 권한 스캔/요약
│   └── content.py      # 파일 export/download
├── store/
│   ├── snapshot.py     # gzip JSON 스냅샷 저장/로드
│   └── changelog.py    # Changes API 증분 동기화
├── ai/
│   ├── classifier.py   # LLM Hub 클라이언트
│   ├── namer.py        # 네이밍 규칙 엔진
│   ├── planner.py      # 실행 계획 생성
│   └── prompts.py      # 분류 프롬프트 + 응답 파싱
├── executor/
│   ├── batch.py        # Batch API 래퍼 + 폴더 생성
│   ├── rate_limiter.py # Token Bucket (3 writes/sec)
│   └── runner.py       # 2단계 실행 + 롤백
├── viewer/
│   ├── app.py          # FastAPI 웹 뷰어 (9개 API)
│   ├── templates/      # Jinja2 HTML (대시보드, Plan 리뷰)
│   └── static/         # CSS + JS (Lazy-load 트리)
└── utils/
    ├── logger.py       # Rich 로깅
    └── retry.py        # 지수 백오프 재시도
```
