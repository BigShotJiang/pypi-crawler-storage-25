# 07. 피벗 구현 마이그레이션 계획

> 최종 업데이트: 2026-04-09
> 선행 문서: [06-PIVOT-AND-NEW-ARCHITECTURE.md](./06-PIVOT-AND-NEW-ARCHITECTURE.md)

---

## 1. AS-IS → TO-BE 전체 비교

### 파이프라인 변화

```
AS-IS (현재):
  Scan → Filter → Snapshot → [LLM: 단일 분류 프롬프트] → Plan(RENAME/MOVE) → Execute → Rollback

TO-BE (피벗 후):
  Scan → Filter → Snapshot
    → [텍스트 추출: Head+Tail 500자]
    → [LLM: 프리셋 프롬프트 선택]
    → Plan(MOVE + SHORTCUT + DESCRIPTION + TRASH)
    → 4단계 Execute
    → Rollback
```

### 모듈별 AS-IS / TO-BE

| 모듈 | AS-IS | TO-BE | 변경 크기 |
|------|-------|-------|----------|
| **models.py** | OperationType 4종 (RENAME, MOVE, RENAME_AND_MOVE, CREATE_FOLDER) | OperationType 7종 (+CREATE_SHORTCUT, UPDATE_DESCRIPTION, TRASH) | 중간 |
| **ai/prompts.py** | 단일 하드코딩 분류 프롬프트, 10개 고정 카테고리 | 프리셋 시스템 (마이그레이션/세컨드브레인/커스텀), JSON Contract 출력 | **대규모 재작성** |
| **ai/planner.py** | 단일 분류 → NamingRuleEngine → RENAME/MOVE 결정 | 프리셋 라우팅 → 시계열 move_to + shortcuts + description 결정 | **대규모 재작성** |
| **ai/namer.py** | 독립 네이밍 엔진 (날짜 접두사, 특수문자 정리) | 제거 또는 축소 (시계열 보관함이 네이밍 대체) | 축소 |
| **scanner/content.py** | export/download (전체 내용) | Head+Tail Truncation 추가 (300+150자, 문장 경계 절삭) | 추가 |
| **scanner/filter.py** | 폴더명/확장자/파일명 정확 매칭 | Junk 패턴 추가 (Copy of, (1), 새 폴더, Untitled 등) | 추가 |
| **executor/batch.py** | build_request(RENAME/MOVE), create_folder() | +create_shortcut(), +update_description(), +trash_file() | 추가 |
| **executor/runner.py** | 2단계 (폴더 생성 → 파일 이동) | 4단계 (폴더 → 이동 → 바로가기 → 설명 업데이트) + 쓰레기 처리 | **대규모 수정** |
| **cli.py** | classify --rules | classify --preset (마이그레이션/세컨드브레인/커스텀) + preset 관리 명령 | 중간 |
| **store/snapshot.py** | description 읽기/쓰기 이미 지원 | 변경 없음 | 없음 |

---

## 2. 작업 단위 분해 (Work Packages)

### WP-1: 데이터 모델 확장
> 선행 조건: 없음

**목표**: 새 아키텍처의 모든 작업 유형과 JSON Contract를 모델에 반영

**파일**: `src/gdrive_organizer/models.py`

**체크리스트**:
- [ ] `OperationType`에 추가: `CREATE_SHORTCUT`, `UPDATE_DESCRIPTION`, `TRASH`
- [ ] `PlanOperation`에 필드 추가:
  - `shortcut_target_id: str | None = None` — 바로가기가 가리킬 원본 파일 ID
  - `shortcut_parent_id: str | None = None` — 바로가기를 놓을 폴더 ID
  - `new_description: str | None = None` — 주입할 설명 텍스트
- [ ] `PlanStats`에 카운터 추가: `shortcuts`, `descriptions`, `trashed`
- [ ] 새 모델 `LLMResponseItem` 추가 (JSON Contract 스키마):
  ```python
  class LLMResponseItem(BaseModel):
      file_id: str
      move_to: str  # "보관함/2026/04"
      shortcuts: list[str] = []  # ["Sec_Brain", "태그/AI"]
      new_description: str | None = None
  ```
- [ ] 기존 테스트 깨지지 않는지 확인 (모든 새 필드에 기본값)

**가이드라인**:
- 모든 새 필드는 `None` 또는 `0` 기본값 → 기존 Plan JSON과 하위 호환
- `LLMResponseItem`은 LLM 응답 파싱 전용, `PlanOperation`은 실행 전용 → 분리 유지

---

### WP-2: 텍스트 추출 파이프라인 (Head + Tail Truncation)
> 선행 조건: 없음 (독립)

**목표**: Google Docs 등에서 분류용 텍스트 스니펫을 효율적으로 추출

**파일**: `src/gdrive_organizer/scanner/content.py`

**체크리스트**:
- [ ] `extract_text_snippet(service, file_id, mime_type, head=300, tail=150) → str` 함수 추가
  - Google Workspace 파일: `export_file(text/plain)` 호출
  - 바이너리/불가능한 파일: 빈 문자열 반환
- [ ] 절삭 규칙 구현:
  - head 영역: 처음부터 `head`자 이내에서 마지막 문장 종결 지점(`.`, `\n`, `!`, `?`)에서 자름
  - tail 영역: 끝에서 `tail`자 이내에서 첫 문장 시작 지점에서 자름
  - 전체 텍스트가 `head + tail`보다 짧으면 그대로 반환
  - head와 tail 사이에 `\n\n[...중략...]\n\n` 삽입
- [ ] Rate limit 방어: `time.sleep(0.1)` (초당 ~10개) 또는 TokenBucket 재활용
- [ ] 테스트: 긴 텍스트, 짧은 텍스트, 빈 텍스트, 바이너리 파일 케이스

**가이드라인**:
- 텍스트 추출은 LLM 호출과 별도 단계 — 먼저 모든 파일의 스니펫을 추출한 후 배치로 LLM에 전송
- export API 호출을 최소화하기 위해 이미 description이 있는 파일은 스킵 옵션 제공
- 10MB 초과 문서는 export 실패 가능 → try/except로 graceful skip

---

### WP-3: Junk 패턴 감지 강화
> 선행 조건: 없음 (독립)

**목표**: 복사본, OS 자동 생성 파일 등 무가치 파일 감지 + MD5 연계 중복 처리

**파일**: `src/gdrive_organizer/scanner/filter.py`

**체크리스트**:
- [ ] `JunkPatterns` 상수 추가:
  ```python
  JUNK_PREFIXES = {"Copy of", "복사본 ", "사본 - "}
  JUNK_SUFFIXES_RE = re.compile(r"\s*\(\d+\)\s*$")  # (1), (2), etc.
  JUNK_EXACT_NAMES = {"새 폴더", "Untitled folder", "Untitled", "Untitled document"}
  JUNK_FOLDER_NAMES = {"tmp", "temp", "backup", "다운로드", "Downloads"}
  ```
- [ ] `detect_junk_files(files) → list[dict]` 함수 추가:
  - 위 패턴 매칭으로 junk 파일 목록 반환
  - 각 파일에 `junk_reason` 태그 부여 (prefix_copy, suffix_number, default_name, temp_folder)
- [ ] MD5 연계: junk로 감지된 파일 중 MD5가 다른 파일과 동일하면 `trash_candidate`로 표시
- [ ] `filter_files()`에 `junk_files` 카운트를 `FilterStats`에 추가 (필터링하진 않고 감지만)
- [ ] 테스트: "Copy of report.txt", "보고서 (1).pdf", "새 폴더", "Untitled document" 케이스

**가이드라인**:
- Junk 파일은 **스캔에서 제외하지 않음** — 감지만 하고 Plan 단계에서 처리
- 제외하면 나중에 정리할 기회를 잃음
- Junk 감지 결과는 LLM에 전달하여 "이 파일은 중복 의심" 컨텍스트로 활용

---

### WP-4: 프리셋 프롬프트 시스템
> 선행 조건: WP-1 (LLMResponseItem 모델)

**목표**: 하드코딩 프롬프트를 프리셋 시스템으로 교체

**파일**: `src/gdrive_organizer/ai/prompts.py` (대규모 재작성)

**체크리스트**:
- [ ] `Preset` 데이터클래스 정의:
  ```python
  @dataclass
  class Preset:
      id: str               # "migration", "second-brain", "custom"
      name: str             # 표시 이름
      description: str      # 설명
      system_prompt: str    # LLM 시스템 프롬프트
      user_prompt_template: str  # 파일 배치 전달 템플릿
  ```
- [ ] 빌트인 프리셋 3종 구현:
  - **마이그레이션 모드**: 기존 폴더 구조 분석 → 시계열 보관함 이동 + 기존 의미 폴더를 shortcuts로
  - **세컨드 브레인 모드**: 텍스트 스니펫 기반 → 다중 태그 추출 → shortcuts + description 생성
  - **커스텀 모드**: `--prompt-file` 인자로 사용자 프롬프트 로드
- [ ] `build_preset_input(files, snippets) → str` 함수:
  - 파일 메타데이터 + 텍스트 스니펫을 JSON 배열로 포맷
  - junk 표시 포함
- [ ] `parse_preset_output(response) → list[LLMResponseItem]` 함수:
  - JSON Contract 스키마로 파싱
  - 마크다운 코드블록 처리 유지
- [ ] 프리셋 로더: `load_preset(preset_id, prompt_file_path=None) → Preset`
- [ ] JSON Contract를 시스템 프롬프트에 명시적으로 포함

**가이드라인**:
- 시스템 프롬프트에 반드시 JSON 출력 스키마를 예시와 함께 포함
- `move_to`는 항상 `보관함/YYYY/MM` 형태 강제 (시계열 원칙)
- `shortcuts`는 LLM이 자유롭게 결정하되, 기존 폴더 목록을 컨텍스트로 제공
- 각 프리셋의 system_prompt는 `prompts.py` 내 상수로 관리 (외부 파일 아님)

---

### WP-5: Planner 재설계
> 선행 조건: WP-1, WP-2, WP-3, WP-4

**목표**: 프리셋 기반 Plan 생성 파이프라인

**파일**: `src/gdrive_organizer/ai/planner.py` (대규모 재작성)

**체크리스트**:
- [ ] `generate_plan()` 시그니처 변경:
  ```python
  async def generate_plan(
      snapshot: Snapshot,
      config: Config,
      preset_id: str = "migration",
      prompt_file: Path | None = None,
  ) -> ExecutionPlan
  ```
- [ ] 파이프라인 구현:
  1. 프리셋 로드 (`load_preset`)
  2. Junk 파일 감지 (`detect_junk_files`)
  3. 텍스트 스니펫 추출 (`extract_text_snippet` — 배치, 초당 10개 제한)
  4. LLM 배치 호출 (50개씩, `build_preset_input` + `parse_preset_output`)
  5. `LLMResponseItem` → `PlanOperation` 변환:
     - `move_to` → CREATE_FOLDER (없는 경우) + MOVE
     - `shortcuts[]` → CREATE_FOLDER (없는 경우) + CREATE_SHORTCUT (각각)
     - `new_description` → UPDATE_DESCRIPTION
  6. Junk + MD5 중복 → TRASH
  7. 충돌 감지 + Plan 저장
- [ ] 기존 폴더 목록을 LLM 컨텍스트에 포함 (shortcuts가 기존 폴더를 활용하도록)
- [ ] `_resolve_time_path(file) → str` 헬퍼: `modified_time` → `보관함/2026/04`
- [ ] 테스트: mock LLM 응답으로 각 operation type 생성 확인

**가이드라인**:
- 텍스트 추출은 export 가능한 파일만 (Google Workspace). 바이너리는 메타데이터만 전달
- 스니펫 추출 실패 시 (10MB 초과 등) 해당 파일은 메타데이터만으로 분류
- `move_to`가 항상 시계열이므로 LLM이 `move_to`를 잘못 지정해도 fallback으로 `modified_time` 기반 경로 사용

---

### WP-6: Executor 확장 (3개 신규 작업 + 4단계 실행)
> 선행 조건: WP-1, WP-5

**목표**: 바로가기 생성, 설명 업데이트, 휴지통 이동 지원

**파일**: `src/gdrive_organizer/executor/batch.py`, `src/gdrive_organizer/executor/runner.py`

#### batch.py 체크리스트:
- [ ] `create_shortcut(service, name, target_id, parent_id) → dict` 함수 추가:
  ```python
  body = {
      "name": name,
      "mimeType": "application/vnd.google-apps.shortcut",
      "shortcutDetails": {"targetId": target_id},
      "parents": [parent_id],
  }
  service.files().create(body=body, fields="id,name", supportsAllDrives=True).execute()
  ```
- [ ] `update_description(service, file_id, description) → dict` 함수 추가:
  ```python
  service.files().update(
      fileId=file_id,
      body={"description": description},
      supportsAllDrives=True,
  ).execute()
  ```
- [ ] `trash_file(service, file_id) → dict` 함수 추가:
  ```python
  service.files().update(
      fileId=file_id,
      body={"trashed": True},
      supportsAllDrives=True,
  ).execute()
  ```
- [ ] `build_request()` 확장: 새 OperationType 처리

#### runner.py 체크리스트:
- [ ] `execute()` 4단계 재구성:
  ```
  Phase 1: CREATE_FOLDER (폴더 생성, placeholder 해소)
  Phase 2: MOVE + RENAME + TRASH (파일 이동/정리)
  Phase 3: CREATE_SHORTCUT (바로가기 생성)
  Phase 4: UPDATE_DESCRIPTION (설명 주입)
  ```
- [ ] 각 Phase별 작업 분리 로직
- [ ] TRASH 작업은 Phase 2에 포함 (이동과 같은 단계)
- [ ] Phase 3에서 shortcut 대상 파일이 Phase 2에서 이동된 경우 새 ID 참조
- [ ] 롤백 로그에 모든 새 작업 유형 기록
- [ ] `_build_reverse_operations()` 확장:
  - CREATE_SHORTCUT 롤백 → shortcut 파일 삭제
  - UPDATE_DESCRIPTION 롤백 → 이전 description 복원 (before에 기록)
  - TRASH 롤백 → `trashed=False`로 복원
- [ ] 테스트: dry-run에서 4단계 모두 표시, 롤백 시 역방향 작업 생성

**가이드라인**:
- Phase 순서가 중요: 폴더 먼저 → 파일 이동 → 바로가기(이동된 파일 참조) → 설명(마지막)
- description 업데이트는 Rate Limit에 여유 있음 (read 아닌 write이지만 경량)
- TRASH는 영구 삭제가 아닌 휴지통 이동 (30일 후 자동 삭제). 안전장치.

---

### WP-7: CLI 명령 업데이트
> 선행 조건: WP-4, WP-5, WP-6

**목표**: 프리셋 기반 classify + 프리셋 관리 명령

**파일**: `src/gdrive_organizer/cli.py`

**체크리스트**:
- [ ] `classify` 명령 시그니처 변경:
  ```python
  @app.command("classify")
  def classify(
      preset: str = typer.Option("migration", "--preset", "-p", help="Preset: migration, second-brain, custom"),
      prompt_file: Path | None = typer.Option(None, "--prompt-file", help="Custom prompt file."),
  )
  ```
- [ ] `preset` 서브앱 추가:
  ```bash
  gdrive-organizer preset list          # 사용 가능한 프리셋 목록
  gdrive-organizer preset show migration  # 프리셋 상세 (프롬프트 포함)
  ```
- [ ] `plan show` 업데이트: 새 작업 유형(SHORTCUT, DESCRIPTION, TRASH) 표시
- [ ] `plan apply --dry-run` 업데이트: 4단계 미리보기
- [ ] 기존 `--rules` 옵션 제거 (namer.py 축소에 따라)

**가이드라인**:
- 프리셋 이름은 짧고 직관적으로: `migration`, `second-brain`, `custom`
- 커스텀 프리셋의 prompt 파일은 plain text (.txt) — 복잡한 JSON 아님
- `classify` 실행 시 진행 상황 Rich 표시: "텍스트 추출 중 [50/200]" → "LLM 분류 중 [3/4 배치]"

---

## 3. 실행 순서 및 의존성

```
WP-1 (모델 확장) ─────────────────┐
WP-2 (텍스트 추출) ───────────────┤── 독립 작업, 병렬 가능
WP-3 (Junk 감지) ─────────────────┘
         ↓
WP-4 (프리셋 프롬프트) ───────────── WP-1 의존
         ↓
WP-5 (Planner 재설계) ────────────── WP-1 + WP-2 + WP-3 + WP-4 전부 의존
         ↓
WP-6 (Executor 확장) ─────────────── WP-1 + WP-5 의존
         ↓
WP-7 (CLI 업데이트) ──────────────── WP-4 + WP-5 + WP-6 의존
```

**병렬 가능**: WP-1, WP-2, WP-3은 동시 작업 가능
**Critical Path**: WP-1 → WP-4 → WP-5 → WP-6 → WP-7

---

## 4. 리스크 및 완화 전략

| 리스크 | 영향 | 완화 |
|--------|------|------|
| LLM이 JSON Contract를 지키지 않음 | Plan 생성 실패 | 강력한 파싱 + fallback (시계열 경로만 적용) |
| 텍스트 추출 API 429 에러 | 분류 중단 | 엄격한 Rate Limit (초당 10개) + 재시도 |
| 바로가기 생성 대량 실패 | View 체계 불완전 | Phase 3 실패는 비치명적 — 원본 이동은 이미 완료 |
| 기존 사용자의 Plan JSON 호환 | 기존 계획 실행 불가 | PlanOperation 새 필드 모두 기본값 None |
| description 길이 제한 | 긴 설명 잘림 | Drive API description 최대 ~약 10,000자, LLM에 500자 제한 지시 |
| `보관함` 폴더 미존재 | 첫 실행 시 이동 실패 | Phase 1에서 자동 생성 |

---

## 5. 검증 계획

### 단위 테스트
```bash
uv run pytest tests/ -v  # 기존 89개 + 새 테스트 전부 통과
```

### 통합 테스트 (실제 Drive)
```bash
# 1. 프리셋 확인
gdrive-organizer preset list
gdrive-organizer preset show migration

# 2. 마이그레이션 모드 분류 (dry-run)
gdrive-organizer classify --preset migration
gdrive-organizer plan show
gdrive-organizer plan apply --dry-run

# 3. 실행 후 확인
gdrive-organizer plan apply
gdrive-organizer scan --incremental
gdrive-organizer tree  # 보관함/2026/04/ 구조 확인

# 4. 롤백
gdrive-organizer plan rollback
```

### 검증 포인트
- [ ] 원본 파일이 `보관함/YYYY/MM/`로 이동되었는가
- [ ] 바로가기가 올바른 폴더에 생성되었는가
- [ ] 바로가기가 원본 파일을 정확히 가리키는가
- [ ] description이 Drive 검색에서 검색되는가
- [ ] 중복 파일이 휴지통으로 이동되었는가
- [ ] 롤백 시 모든 작업이 역방향으로 수행되는가
