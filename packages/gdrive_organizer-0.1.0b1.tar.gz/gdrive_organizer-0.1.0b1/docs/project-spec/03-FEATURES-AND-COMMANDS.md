# 03. 기능 및 명령어 레퍼런스

## CLI 명령어 전체 목록 (18개)

### 인증 (auth)

```bash
# OAuth 로그인 — Downloads에서 credentials 자동 탐지, 브라우저 인증
gdrive-organizer auth login

# 토큰 상태 확인
gdrive-organizer auth status

# 로그아웃 (토큰 삭제)
gdrive-organizer auth logout
```

### 설정 (config)

```bash
# 전체 설정 표시
gdrive-organizer config show

# 설정 값 변경
gdrive-organizer config set viewer_port 9000
gdrive-organizer config set write_rate_limit 5.0

# 스캔 제외 규칙 관리
gdrive-organizer config exclude --show
gdrive-organizer config exclude --add-folder .bazel-bin
gdrive-organizer config exclude --remove-folder build
gdrive-organizer config exclude --add-ext .bak
gdrive-organizer config exclude --reset
```

### 스캔

```bash
# 전체 스캔 (필터 적용)
gdrive-organizer scan

# 특정 폴더만 스캔
gdrive-organizer scan --folder <FOLDER_ID>

# 증분 스캔 (변경분만)
gdrive-organizer scan --incremental

# 필터 없이 전체 스캔
gdrive-organizer scan --no-filter
```

### 조회

```bash
# 파일 트리 표시
gdrive-organizer tree
gdrive-organizer tree --depth 3

# Drive 통계
gdrive-organizer stats

# 권한 요약
gdrive-organizer permissions
```

### 파일 내용

```bash
# 파일 내용 텍스트로 읽기 (Google Docs → 자동 export)
gdrive-organizer cat <FILE_ID>

# 파일 export (다양한 포맷)
gdrive-organizer export <FILE_ID> --format pdf --output report.pdf
gdrive-organizer export <FILE_ID> --format csv --output data.csv
gdrive-organizer export <FILE_ID> --format docx --output doc.docx
```

**지원 export 포맷**:
| 소스 | 가능한 포맷 |
|------|------------|
| Google Docs | txt, html, pdf, docx |
| Google Sheets | csv, pdf, xlsx |
| Google Slides | txt, pdf, pptx |
| Google Drawings | png, pdf, svg |

### AI 분류

```bash
# AI로 파일 분류 + 실행 계획 생성
gdrive-organizer classify
gdrive-organizer classify --rules custom_rules.json
```

### 실행 계획 (plan)

```bash
# 계획 확인
gdrive-organizer plan show

# 계획 실행 (미리보기)
gdrive-organizer plan apply --dry-run

# 계획 실행 (확인 후)
gdrive-organizer plan apply

# 확인 없이 바로 실행
gdrive-organizer plan apply --yes

# 마지막 실행 롤백
gdrive-organizer plan rollback
```

### 유틸리티

```bash
# 웹 뷰어 시작 (브라우저 자동 오픈)
gdrive-organizer view
gdrive-organizer view --port 9000

# 폴더 생성
gdrive-organizer create-folder "새 폴더"
gdrive-organizer create-folder "하위 폴더" --parent <PARENT_FOLDER_ID>
```

### 글로벌 옵션

```bash
gdrive-organizer --version        # 버전 표시
gdrive-organizer --verbose         # 상세 로그
gdrive-organizer --config-dir /path/to/config  # 설정 디렉토리 지정
```

---

## Web Viewer API

| 엔드포인트 | 메서드 | 파라미터 | 응답 |
|-----------|--------|---------|------|
| `/` | GET | - | 대시보드 HTML |
| `/plan` | GET | - | Plan 리뷰 HTML |
| `/api/tree` | GET | `node_id` (선택) | 트리 JSON (lazy-load) |
| `/api/files` | GET | `q` (검색어) | 파일 목록 (최대 100) |
| `/api/stats` | GET | - | MIME 분포, 통계 |
| `/api/permissions` | GET | - | 권한 요약 |
| `/api/plan` | GET | - | 실행 계획 JSON |
| `/api/plan/approve` | POST | `approved_ids[]` | 승인 결과 |
| `/api/file/{id}` | GET | - | 파일 전체 메타데이터 (21개 필드) |
| `/api/duplicates` | GET | - | MD5 기반 중복 그룹 |

---

## 스캔 필터링 시스템

### 기본 제외 규칙

**폴더** (32개 — 하위 파일 전부 재귀 제외):
```
node_modules, .npm, .yarn, .pnpm-store,
__pycache__, .venv, venv, env, .tox, .nox, .mypy_cache, .ruff_cache, .pytest_cache, .eggs,
.git, .svn, .hg,
vendor, target, build, dist, out,
.gradle, .maven, .cargo,
.next, .nuxt, .output, .cache,
Pods, DerivedData,
.terraform, .pulumi
```

**확장자** (12개):
```
.pyc, .pyo, .class, .o, .obj, .so, .dll, .dylib, .log, .tmp, .swp, .swo
```

**파일명** (3개):
```
.DS_Store, Thumbs.db, desktop.ini
```

**데스크톱 동기화**: 이름이 아닌 폴더 구조 분석으로 자동 감지 (다국어 지원)

### 필터링 성능

| 단계 | 파일 수 | 설명 |
|------|---------|------|
| API 전체 | 348,787 | 모든 비휴지통 파일 |
| 데스크톱 동기화 제외 후 | ~10,000 | `내 컴퓨터/` 하위 제거 |
| 캐시/패키지 제외 후 | ~1,596 | node_modules, .git 등 제거 |

---

## 실행 가능한 Write 작업

| 작업 | API | 설명 |
|------|-----|------|
| **파일명 변경** | `files.update(body={"name":...})` | 단일 API 호출 |
| **폴더 이동** | `files.update(addParents=..., removeParents=...)` | 현재+새 부모 ID 필요 |
| **이름+이동 동시** | 위 결합 | 원자적 단일 호출 |
| **폴더 생성** | `files.create(body={"mimeType":"folder"})` | 새 폴더 생성 |
| **Batch 실행** | `new_batch_http_request()` | 최대 100개/배치 |

### Rate Limiting

- Token Bucket: 기본 3.0 writes/sec, 버스트 용량 10
- 설정 가능: `gdrive-organizer config set write_rate_limit 5.0`

### 롤백

- 모든 `plan apply` 실행 시 롤백 로그 자동 저장
- `plan rollback`으로 성공한 작업만 역방향 실행
- 롤백 로그 위치: `~/.local/share/gdrive-organizer/logs/rollback-*.json`
