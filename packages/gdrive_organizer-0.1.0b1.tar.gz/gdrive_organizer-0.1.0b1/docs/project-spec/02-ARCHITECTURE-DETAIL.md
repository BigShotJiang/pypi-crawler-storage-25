# 02. 모듈별 상세 아키텍처

## 모듈 의존성 레이어

```
Layer 3 (진입점)    cli.py, viewer/app.py
                        ↓
Layer 2 (오케스트레이션) ai/planner.py, executor/runner.py, store/changelog.py
                        ↓
Layer 1 (핵심 로직)   scanner/*, store/snapshot.py, executor/batch.py, ai/classifier.py
                        ↓
Layer 0 (기반)       models.py, config.py, utils/retry.py, utils/logger.py, auth/oauth.py
```

순환 의존성 없음. 모든 import는 상위 레이어 → 하위 레이어 방향.

---

## 모듈별 상세

### auth/oauth.py (152줄)

**역할**: Google OAuth 2.0 인증 전체 생명주기 관리

**핵심 함수**:
| 함수 | 설명 |
|------|------|
| `get_drive_service(config)` | 인증된 Drive API v3 서비스 반환 |
| `_load_or_refresh_token(config)` | 토큰 로드 → 유효하면 반환, 만료 시 갱신 |
| `_run_oauth_flow(config)` | 브라우저 OAuth 플로우 실행 |
| `auto_detect_credentials(config)` | Downloads 폴더에서 GCP credentials JSON 자동 탐지 |
| `check_token_status(config)` | 토큰 유효성/만료/이메일 정보 반환 |

**인증 플로우**:
```
get_drive_service()
  → token.json 존재? → 유효? → 바로 사용
                       → 만료? → refresh_token으로 갱신
  → token.json 없음? → credentials.json 존재? → OAuth 브라우저 플로우
                       → credentials.json 없음? → Downloads에서 자동 탐지
```

**Credentials 자동 탐지**:
- GCP Console에서 다운로드한 파일명 패턴: `client_secret_*.apps.googleusercontent.com.json`
- 탐색 경로: `~/Downloads`, `~/Desktop` (OS별)
- 가장 최근 수정된 파일 선택 → config 디렉토리로 이동 → chmod 600 (Unix)

**보안**:
- token.json, credentials.json에 `chmod 600` 적용 (Unix)
- Windows에서는 OS 수준 ACL에 의존 (chmod 스킵)
- .gitignore에 두 파일 모두 포함

---

### scanner/crawler.py (80줄)

**역할**: Google Drive API files.list를 이용한 Flat Crawl

**핵심 상수**:
```python
_FILE_FIELDS = (
    "id,name,mimeType,parents,owners(displayName,emailAddress),"
    "shared,createdTime,modifiedTime,size,webViewLink,driveId,shortcutDetails,"
    "md5Checksum,sha256Checksum,ownedByMe,description,starred,"
    "lastModifyingUser(displayName,emailAddress),"
    "originalFilename,quotaBytesUsed,fileExtension,fullFileExtension,viewedByMeTime,"
    "imageMediaMetadata(width,height,rotation,cameraMake,cameraModel),"
    "videoMediaMetadata(width,height,durationMillis)"
)
FIELDS = f"files({_FILE_FIELDS}),nextPageToken"
CHANGE_FIELDS = f"changes(fileId,file({_FILE_FIELDS}),removed),newStartPageToken,nextPageToken"
```

`_FILE_FIELDS`를 공유 상수로 추출하여 files.list와 changes.list가 동일한 필드를 요청.

**pageSize 제한 이슈**:
- `permissions` 필드를 요청하면 Google API가 pageSize를 100으로 강제 제한
- 348K 파일 기준: permissions 포함 시 3,487 페이지 vs 미포함 시 349 페이지 (10배 차이)
- 결정: permissions 제외, 별도 명령으로 가져옴

---

### scanner/tree.py (119줄)

**역할**: 플랫 파일 리스트에서 계층 트리 구조 재구성

**알고리즘**:
1. 모든 파일을 `TreeNode`로 변환 (O(N))
2. `parents[0]` 기준으로 부모-자식 연결 (O(N))
3. 부모가 리스트에 없는 노드는 루트로 처리 (고아 노드)
4. 자식 정렬: 폴더 우선, 이름 알파벳순
5. DFS로 전체 경로 계산: `Root/SubFolder/file.txt`
6. `inject_paths_into_raw()`: 계산된 경로를 원본 dict에 기록 (참조 변환)

**TreeNode 데이터클래스**:
```python
@dataclass
class TreeNode:
    file_id: str
    name: str
    mime_type: str
    children: list[TreeNode]
    path: str
    raw: dict  # 원본 API 응답 dict (참조)
```

`raw`가 원본 dict의 참조이므로 `inject_paths_into_raw()`에서 `node.raw["path"] = node.path`로 기록하면 원본 리스트의 dict도 변경됨. 이를 통해 `save_snapshot()`에 path가 포함된 채로 저장.

---

### scanner/filter.py (238줄)

**역할**: 캐시/패키지/데스크톱 동기화 파일 제외

**4단계 필터링 알고리즘**:
```
Step 0: 데스크톱 동기화 폴더 자동 감지 (구조 기반 휴리스틱)
Step 1: 제외 폴더 ID 수집 (이름 매칭) + 데스크톱 ID 합산
Step 2: BFS로 하위 전체 전파 (자식 → 손자 → ... 재귀)
Step 3: 확장자 필터 (case-insensitive) + 파일명 정확 매칭
```

**데스크톱 동기화 감지** (로케일 독립):
- 하드코딩된 폴더명(`내 컴퓨터` 등)을 사용하지 않음
- 루트 레벨 폴더의 자식 폴더 이름을 검사
- 자식에 `Desktop`, `Documents`, `Users`, `바탕 화면`, `デスクトップ`, `桌面` 등이 있거나 드라이브 문자(`C:`, `D:`)가 있으면 데스크톱 동기화로 판단
- 한국어/영어/일본어/중국어/스페인어/프랑스어/독일어 지원

**기본 제외 규칙**:
- 폴더 32개: `node_modules`, `__pycache__`, `.git`, `.venv`, `build`, `dist`, `target`, `vendor`, `.next`, `Pods` 등
- 확장자 12개: `.pyc`, `.class`, `.o`, `.so`, `.dll`, `.log`, `.tmp` 등
- 파일명 3개: `.DS_Store`, `Thumbs.db`, `desktop.ini`

**사용자 커스터마이징**: `~/.config/gdrive-organizer/exclude.json`
```json
{
  "excluded_folders": { "add": ["my_cache"], "remove": ["build"] },
  "excluded_extensions": { "add": [".bak"], "remove": [] },
  "excluded_names": { "add": [], "remove": [] }
}
```
기본값 + add(합집합) - remove(차집합) = 최종 규칙

---

### store/snapshot.py (238줄)

**역할**: Drive 스캔 결과를 gzip JSON으로 로컬 저장/로드

**스냅샷 스키마** (v1.1):
```json
{
  "version": "1.1",
  "scanned_at": "ISO datetime",
  "type": "full | incremental",
  "stats": { "total_files": N, "total_folders": M, "total_size": bytes },
  "change_token": "Changes API 토큰",
  "files": [DriveFile 배열]
}
```

**DriveFile 필드** (21개):
- 기본: id, name, mime_type, parents, path, owners, shared, permissions
- 시간: created_time, modified_time, viewed_by_me_time
- 크기: size, quota_bytes_used
- 해시: md5_checksum, sha256_checksum
- 소유: owned_by_me, last_modifying_user
- 파일: file_extension, full_file_extension, original_filename
- 기타: description, starred, web_view_link, drive_id
- 미디어: image_media_metadata, video_media_metadata

**양방향 변환**:
- `_raw_to_drive_file(raw)`: API 응답 dict → DriveFile 모델
- `drive_file_to_raw(f)`: DriveFile 모델 → API 호환 dict (증분 동기화, 트리 재구성에 사용)

**latest 포인터**:
- Unix: symlink (`latest.json.gz` → `2026-04-08T13-25-25.json.gz`)
- Windows: `shutil.copy2()` (symlink은 admin 권한 필요)

---

### store/changelog.py (106줄)

**역할**: Changes API를 이용한 증분 동기화

**플로우**:
```
load_snapshot → poll_changes(token) → apply_changes(snapshot, changes)
→ filter_files → build_tree → compute_paths → save_snapshot
```

- 변경분만 가져오므로 0.8초만에 완료 (전체 스캔 15분 대비)
- 삭제/휴지통 파일은 스냅샷에서 제거
- 새 파일/수정 파일은 `_raw_to_drive_file()`로 변환 후 추가/교체

---

### executor/batch.py (65줄)

**지원하는 Write 작업**:
| 작업 | API 호출 | 구현 |
|------|---------|------|
| 이름 변경 | `files().update(body={"name": new})` | `build_request()` |
| 폴더 이동 | `files().update(addParents=new, removeParents=old)` | `build_request()` |
| 이름+이동 동시 | 위 두 개 결합 (단일 API 호출) | `build_request()` |
| 폴더 생성 | `files().create(body={"name": n, "mimeType": folder})` | `create_folder()` |

**Batch API**: 최대 100개 요청을 하나의 HTTP 요청으로 묶음 (HTTP 오버헤드만 줄임, 쿼터 절감 없음)

---

### executor/runner.py (219줄)

**2단계 실행**:
1. **Phase 1**: `CREATE_FOLDER` 작업 실행 → placeholder ID를 실제 Drive 폴더 ID로 매핑
2. **Phase 2**: RENAME/MOVE 작업에서 placeholder 해소 후 배치 실행

**롤백 로그** (`rollback-YYYY-MM-DDTHH-MM-SS.json`):
```json
{
  "executedAt": "ISO datetime",
  "operations": [{
    "fileId": "...",
    "type": "rename|move|rename_and_move",
    "before": { "name": "old", "path": "old/path", "parent_id": "..." },
    "after": { "name": "new", "path": "new/path", "parent_id": "..." },
    "status": "success|failed"
  }]
}
```

롤백 시 `before`와 `after`를 교환하여 역방향 작업 생성. 실패한 작업은 롤백하지 않음.

---

### ai/ 서브시스템

**classifier.py**: httpx.AsyncClient로 LLM Hub에 OpenAI-compatible 요청. 60초 타임아웃, 연결 실패 시 빈 문자열 반환 (graceful degradation).

**prompts.py**: 10개 카테고리 분류 체계. JSON 배열 출력 요구. 마크다운 코드블록에서 JSON 추출 지원.

**namer.py**: 규칙 기반 이름 정리. 날짜 접두사(`YYYY-MM-DD_`), 특수문자 제거, LLM 제안 적용, 커스텀 regex 규칙.

**planner.py**: 50개씩 배치 분류 → 이름 규칙 적용 → 작업 유형 결정 → 충돌 감지 → JSON 계획 저장.

---

### viewer/ 서브시스템

**API 엔드포인트 9개**:
| 엔드포인트 | 메서드 | 설명 |
|-----------|--------|------|
| `/` | GET | 대시보드 HTML |
| `/plan` | GET | Plan 리뷰 HTML |
| `/api/tree?node_id=` | GET | Lazy-load 트리 (기본 depth 2) |
| `/api/files?q=` | GET | 파일 검색 (최대 100개) |
| `/api/stats` | GET | MIME 분포, 크기 통계 |
| `/api/permissions` | GET | 권한 요약 |
| `/api/plan` | GET | 현재 실행 계획 |
| `/api/plan/approve` | POST | 선택한 작업만 승인 |
| `/api/file/{id}` | GET | 파일 전체 메타데이터 |
| `/api/duplicates` | GET | MD5 기반 중복 그룹 |

**SnapshotCache**: 스냅샷을 메모리에 1회만 로드 후 캐싱. 1,596개 파일 기준 첫 로드 ~1초, 이후 요청 즉시.

**Lazy-load 트리**: 초기 로드 시 depth 2까지만 전송. 폴더 클릭 시 `/api/tree?node_id=`로 자식 노드 추가 로드.
