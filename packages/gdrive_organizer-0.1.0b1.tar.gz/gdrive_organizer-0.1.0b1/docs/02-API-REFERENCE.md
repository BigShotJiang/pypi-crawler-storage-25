# GDrive Organizer — Drive API Reference

> **Version**: 1.0
> **Last Updated**: 2026-04-08
> **Based on**: Google Drive API v3

---

## 1. Endpoints Used

이 프로젝트에서 사용하는 Google Drive API v3 엔드포인트 목록.
Base URL: `https://www.googleapis.com/drive/v3/`

### 1.1 Read Operations

| Endpoint | Method | Purpose | Quota Cost |
|----------|--------|---------|------------|
| `files.list` | GET /files | 전체 파일 목록 (flat crawl) | 1 per call |
| `files.get` | GET /files/{id} | 단일 파일 메타데이터 | 1 per call |
| `files.export` | GET /files/{id}/export | Google Docs → plain text 변환 | 1 per call |
| `permissions.list` | GET /files/{id}/permissions | 파일 권한 목록 | 1 per call |
| `changes.getStartPageToken` | GET /changes/startPageToken | 변경 추적 시작 토큰 | 1 per call |
| `changes.list` | GET /changes | 변경사항 목록 | 1 per call |
| `drives.list` | GET /drives | 공유 드라이브 목록 | 1 per call |

### 1.2 Write Operations

| Endpoint | Method | Purpose | Quota Cost |
|----------|--------|---------|------------|
| `files.update` | PATCH /files/{id} | 이름 변경 + 폴더 이동 | 1 per call |
| Batch API | POST /batch/drive/v3 | 최대 100개 요청 묶기 | N per batch (N = inner requests) |

---

## 2. files.list — Flat Crawl Strategy

### 2.1 Request Parameters

```python
service.files().list(
    q="trashed=false",
    pageSize=1000,              # 최대값. 기본 100.
    fields="nextPageToken,files(id,name,mimeType,parents,owners(emailAddress,displayName),shared,createdTime,modifiedTime,size,webViewLink,shortcutDetails,driveId,permissions(id,type,role,emailAddress,displayName))",
    includeItemsFromAllDrives=True,   # 공유 드라이브 포함
    supportsAllDrives=True,           # 공유 드라이브 API 호환
    orderBy="folder,name",            # 폴더 먼저, 이름순
)
```

### 2.2 Query Language (q parameter)

| Query | Description |
|-------|-------------|
| `trashed=false` | 휴지통 제외 |
| `'FOLDER_ID' in parents` | 특정 폴더의 직접 자식만 |
| `mimeType='application/vnd.google-apps.folder'` | 폴더만 |
| `mimeType!='application/vnd.google-apps.folder'` | 파일만 |
| `name contains 'report'` | 이름에 'report' 포함 |
| `modifiedTime > '2025-01-01T00:00:00'` | 수정일 필터 |
| `sharedWithMe=true` | 공유된 파일만 |

복합 조건: `and` / `or` / `not` 사용 가능.

```python
# 예: 2025년 이후 수정된 Google Docs만
q = "mimeType='application/vnd.google-apps.document' and modifiedTime > '2025-01-01T00:00:00' and trashed=false"
```

### 2.3 Pagination

```python
def list_all_files(service, query="trashed=false"):
    all_files = []
    request = service.files().list(
        q=query,
        pageSize=1000,
        fields="nextPageToken,files(id,name,mimeType,parents,owners,shared,createdTime,modifiedTime,size,webViewLink,shortcutDetails,driveId)",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
    )
    page_count = 0
    while request is not None:
        response = request.execute()
        files = response.get("files", [])
        all_files.extend(files)
        page_count += 1
        logger.info(f"Page {page_count}: {len(files)} files (total: {len(all_files)})")
        request = service.files().list_next(request, response)
    return all_files
```

> **list_next()**: `nextPageToken`을 자동으로 추출하여 다음 요청 생성.
> 더 이상 페이지가 없으면 `None` 반환.

### 2.4 Fields Parameter (Critical in v3)

v3에서는 `fields`를 명시하지 않으면 `kind`, `id`, `name`, `mimeType`만 반환.

**컬렉션 (files.list):**
```
fields=nextPageToken,files(id,name,mimeType,parents)
```

**단일 리소스 (files.get):**
```
fields=id,name,mimeType,parents,permissions
```

**중첩 필드:**
```
files(permissions(id,type,role,emailAddress))
```

**전체 필드 (디버깅용):**
```
fields=*
```

### 2.5 In-Memory Tree Reconstruction

```python
from dataclasses import dataclass, field

@dataclass
class TreeNode:
    file: DriveFile
    children: list["TreeNode"] = field(default_factory=list)
    path: str = ""

def build_tree(files: list[dict]) -> dict[str, TreeNode]:
    """Flat list → tree structure."""
    nodes = {f["id"]: TreeNode(file=f) for f in files}
    roots = []

    for f in files:
        node = nodes[f["id"]]
        parent_id = f.get("parents", [None])[0]
        if parent_id and parent_id in nodes:
            nodes[parent_id].children.append(node)
        else:
            roots.append(node)

    # Compute paths
    def set_paths(node: TreeNode, prefix: str = ""):
        node.path = f"{prefix}/{node.file['name']}"
        node.file["path"] = node.path
        for child in node.children:
            set_paths(child, node.path)

    for root in roots:
        set_paths(root)

    return nodes
```

---

## 3. files.update — Rename & Move

### 3.1 Rename Only

```python
service.files().update(
    fileId="FILE_ID",
    body={"name": "New Name.docx"},
    fields="id,name",
    supportsAllDrives=True,
).execute()
```

### 3.2 Move Only

```python
service.files().update(
    fileId="FILE_ID",
    addParents="NEW_PARENT_ID",
    removeParents="OLD_PARENT_ID",
    fields="id,name,parents",
    supportsAllDrives=True,
).execute()
```

### 3.3 Rename + Move (Atomic)

```python
service.files().update(
    fileId="FILE_ID",
    body={"name": "New Name.docx"},
    addParents="NEW_PARENT_ID",
    removeParents="OLD_PARENT_ID",
    fields="id,name,parents",
    supportsAllDrives=True,
).execute()
```

---

## 4. files.export — Content Reading

### 4.1 Google Workspace Docs → Plain Text

```python
from googleapiclient.http import MediaIoBaseDownload
import io

def export_doc_as_text(service, file_id: str) -> str:
    request = service.files().export_media(
        fileId=file_id,
        mimeType="text/plain"
    )
    buffer = io.BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)
    done = False
    while not done:
        _, done = downloader.next_chunk()
    return buffer.getvalue().decode("utf-8")
```

### 4.2 Export MIME Types

| Google Format | Export To | MIME Type |
|--------------|----------|-----------|
| Google Docs | Plain text | `text/plain` |
| Google Docs | HTML | `text/html` |
| Google Docs | PDF | `application/pdf` |
| Google Docs | DOCX | `application/vnd.openxmlformats-officedocument.wordprocessingml.document` |
| Google Sheets | CSV | `text/csv` |
| Google Sheets | XLSX | `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` |
| Google Slides | Plain text | `text/plain` |
| Google Slides | PDF | `application/pdf` |
| Google Slides | PPTX | `application/vnd.openxmlformats-officedocument.presentationml.presentation` |

> **제한**: Export 최대 10MB. 초과 시 Docs/Sheets/Slides API 직접 사용.

---

## 5. permissions.list — Permission Audit

```python
def get_permissions(service, file_id: str) -> list[dict]:
    permissions = []
    request = service.permissions().list(
        fileId=file_id,
        pageSize=100,
        fields="nextPageToken,permissions(id,type,role,emailAddress,displayName,expirationTime)",
        supportsAllDrives=True,
    )
    while request:
        response = request.execute()
        permissions.extend(response.get("permissions", []))
        request = service.permissions().list_next(request, response)
    return permissions
```

> **주의**: files.list의 `fields`에 `permissions`를 포함하면 각 파일의 권한이
> 함께 반환되지만, 공유 드라이브의 파일은 별도 호출 필요.

---

## 6. Changes API — Incremental Sync

### 6.1 Initial Token

```python
start_token = service.changes().getStartPageToken().execute()["startPageToken"]
# → snapshot과 함께 저장
```

### 6.2 Polling Changes

```python
def poll_changes(service, saved_token: str) -> tuple[list[dict], str]:
    changes = []
    page_token = saved_token

    while page_token:
        response = service.changes().list(
            pageToken=page_token,
            fields="nextPageToken,newStartPageToken,changes(fileId,removed,file(id,name,mimeType,parents,trashed,modifiedTime))",
            spaces="drive",
            includeItemsFromAllDrives=True,
            supportsAllDrives=True,
        ).execute()

        changes.extend(response.get("changes", []))

        if "newStartPageToken" in response:
            new_token = response["newStartPageToken"]
            return changes, new_token
        page_token = response.get("nextPageToken")

    return changes, saved_token
```

### 6.3 Applying Changes to Snapshot

```python
def apply_changes(snapshot: dict, changes: list[dict]) -> dict:
    file_map = {f["id"]: f for f in snapshot["files"]}

    for change in changes:
        file_id = change["fileId"]
        if change.get("removed") or change.get("file", {}).get("trashed"):
            file_map.pop(file_id, None)
        elif "file" in change:
            file_map[file_id] = change["file"]

    snapshot["files"] = list(file_map.values())
    return snapshot
```

---

## 7. Batch API

### 7.1 Python Client 사용법

```python
def batch_rename(service, operations: list[tuple[str, str]], callback):
    """
    operations: list of (file_id, new_name) tuples
    Maximum 100 per batch.
    """
    batch = service.new_batch_http_request(callback=callback)
    for file_id, new_name in operations:
        batch.add(
            service.files().update(
                fileId=file_id,
                body={"name": new_name},
                fields="id,name",
                supportsAllDrives=True,
            ),
            request_id=file_id,
        )
    batch.execute()
```

### 7.2 Callback Pattern

```python
results = {}
errors = {}

def batch_callback(request_id, response, exception):
    if exception:
        errors[request_id] = str(exception)
    else:
        results[request_id] = response
```

### 7.3 Rate-Limited Batch Execution

```python
import time

def execute_in_batches(service, all_operations, batch_size=100, writes_per_sec=3.0):
    """
    all_operations를 batch_size 단위로 나누어 실행.
    각 배치 사이에 rate limit 대기.
    """
    delay_between_batches = batch_size / writes_per_sec  # 100 / 3 ≈ 33초

    for i in range(0, len(all_operations), batch_size):
        chunk = all_operations[i:i + batch_size]
        batch = service.new_batch_http_request(callback=batch_callback)

        for op in chunk:
            batch.add(build_request(service, op), request_id=op.file_id)

        batch.execute()
        logger.info(f"Batch {i // batch_size + 1}: {len(chunk)} operations completed")

        if i + batch_size < len(all_operations):
            logger.info(f"Rate limit pause: {delay_between_batches:.0f}s")
            time.sleep(delay_between_batches)
```

---

## 8. Google Workspace MIME Types

| MIME Type | Description |
|-----------|-------------|
| `application/vnd.google-apps.folder` | 폴더 |
| `application/vnd.google-apps.document` | Google Docs |
| `application/vnd.google-apps.spreadsheet` | Google Sheets |
| `application/vnd.google-apps.presentation` | Google Slides |
| `application/vnd.google-apps.form` | Google Forms |
| `application/vnd.google-apps.drawing` | Google Drawings |
| `application/vnd.google-apps.shortcut` | 바로가기 |
| `application/vnd.google-apps.site` | Google Sites |

---

## 9. Retry & Error Handling

### 9.1 Retryable Errors

| Status | Reason | Action |
|--------|--------|--------|
| 403 | `rateLimitExceeded` | Exponential backoff |
| 403 | `userRateLimitExceeded` | Exponential backoff |
| 429 | Too Many Requests | Exponential backoff |
| 500 | Internal Server Error | Retry (transient) |
| 503 | Service Unavailable | Retry (transient) |

### 9.2 Non-Retryable Errors

| Status | Reason | Action |
|--------|--------|--------|
| 400 | Bad Request | Fix request, don't retry |
| 401 | Unauthorized | Re-authenticate |
| 403 | `insufficientPermissions` | Check scope/permissions |
| 404 | Not Found | Skip file, log warning |

### 9.3 Exponential Backoff Implementation

```python
import time
import random
from functools import wraps
from googleapiclient.errors import HttpError

RETRYABLE_STATUS = {403, 429, 500, 503}
RATE_LIMIT_REASONS = {"rateLimitExceeded", "userRateLimitExceeded"}

def with_retry(max_retries=5, max_delay=64.0):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except HttpError as e:
                    status = e.resp.status
                    if status not in RETRYABLE_STATUS or attempt == max_retries:
                        raise
                    # 403이지만 rate limit이 아닌 경우 retry하지 않음
                    if status == 403:
                        error_reason = _get_error_reason(e)
                        if error_reason not in RATE_LIMIT_REASONS:
                            raise
                    delay = min(2 ** attempt + random.uniform(0, 1), max_delay)
                    logger.warning(f"Retry {attempt + 1}/{max_retries} after {delay:.1f}s (HTTP {status})")
                    time.sleep(delay)
        return wrapper
    return decorator

def _get_error_reason(error: HttpError) -> str:
    try:
        import json
        content = json.loads(error.content)
        return content.get("error", {}).get("errors", [{}])[0].get("reason", "")
    except Exception:
        return ""
```

---

## 10. Shared Drives vs My Drive

| Feature | My Drive | Shared Drive |
|---------|----------|-------------|
| `parents` 필드 | 항상 존재 | 항상 존재 |
| `owners` 필드 | 사용자 이메일 | 비어있음 (drive가 소유) |
| `permissions` in files.list | 포함 가능 | 별도 호출 필요 |
| `supportsAllDrives` 필수 | No | Yes |
| `driveId` 필드 | null | 공유 드라이브 ID |
| Move 제한 | 자유 | `fileOrganizer` 역할 필요 |

### 공유 드라이브 목록 조회

```python
def list_shared_drives(service) -> list[dict]:
    drives = []
    request = service.drives().list(pageSize=100)
    while request:
        response = request.execute()
        drives.extend(response.get("drives", []))
        request = service.drives().list_next(request, response)
    return drives
```

---

## 11. Key Reference Links

| Resource | URL |
|----------|-----|
| Drive API v3 Reference | https://developers.google.com/workspace/drive/api/reference/rest/v3 |
| files.list | https://developers.google.com/workspace/drive/api/reference/rest/v3/files/list |
| files.update | https://developers.google.com/workspace/drive/api/reference/rest/v3/files/update |
| files.export | https://developers.google.com/workspace/drive/api/reference/rest/v3/files/export |
| permissions.list | https://developers.google.com/workspace/drive/api/reference/rest/v3/permissions/list |
| Usage Limits | https://developers.google.com/workspace/drive/api/guides/limits |
| Performance Tips | https://developers.google.com/drive/api/guides/performance |
| Batch Requests | https://developers.google.com/drive/api/guides/performance#batch |
| Fields Parameter | https://developers.google.com/workspace/drive/api/guides/fields-parameter |
| Shared Drives | https://developers.google.com/workspace/drive/api/guides/enable-shareddrives |
| Changes API | https://developers.google.com/workspace/drive/api/guides/manage-changes |
| Python Quickstart | https://developers.google.com/workspace/drive/api/quickstart/python |
| OAuth Scopes | https://developers.google.com/workspace/drive/api/guides/api-specific-auth |
