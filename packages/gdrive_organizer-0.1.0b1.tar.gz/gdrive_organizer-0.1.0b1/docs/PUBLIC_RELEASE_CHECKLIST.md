# Public Release Checklist

Copy-pasteable metadata and steps for making the repo publicly visible.

---

## GitHub Repository Settings

### Description (copy-paste)

```
AI-powered Google Drive organizer CLI. Scan, classify with AI, review plans, dry-run, apply, rollback. Safety-first automation for technical users.
```

### Topics (add all)

```
google-drive  cli  python  ai  file-organizer  automation  xai  grok  fastapi  drive-api
```

### Website URL

```
https://github.com/papa-channy/google-drive-manager#quick-start
```

---

## GitHub Release

### Release title

```
v0.1.0-beta.1 -- Public Beta
```

### Release body

```markdown
First public beta of gdrive-organizer.

**What it does**: Scans your Google Drive, classifies files with AI (xAI Grok), generates a reviewable execution plan, and applies changes with dry-run and rollback support.

**Who it's for**: Technical users comfortable with CLI tools who want safe, reviewable Drive automation.

**Quick start**: See the [README](https://github.com/papa-channy/google-drive-manager#quick-start) for install and first-run instructions.

**What's included**:
- Flat-crawl scanner with in-memory tree reconstruction
- AI classification via xAI Grok (migration, second-brain, custom presets)
- Plan/Apply separation with dry-run and rollback
- Readonly OAuth mode for safe exploration
- Local FastAPI web viewer for visual inspection
- 210 passing tests, CI via GitHub Actions

**Known limitations**:
- Install from source only (PyPI publishing coming soon)
- OAuth testing mode: tokens expire after 7 days
- Classifies by metadata only (content-based classification on roadmap)

See [CHANGELOG.md](CHANGELOG.md) for full details.
```

### Release settings

- [x] Mark as pre-release
- [ ] Set as latest release

---

## Social Preview Text

For sharing on Twitter/X, Reddit, HN, etc:

### Short (under 280 chars)

```
gdrive-organizer: AI-powered Google Drive cleanup for technical users. Scan your Drive, classify files with AI, review a plan, dry-run it, then apply. Rollback if anything's wrong. Safety-first, CLI-first. Open source beta.

github.com/papa-channy/google-drive-manager
```

### One-liner

```
CLI tool that scans your Google Drive, uses AI to classify files, generates a reviewable plan, and applies changes with dry-run + rollback. Python, open source.
```

---

## Pre-Public Checklist

- [ ] All tests pass (`just check`)
- [ ] README is up to date
- [ ] CHANGELOG has current version entry
- [ ] License file matches pyproject.toml (Apache-2.0)
- [ ] No credentials or tokens in repo (`credentials.json`, `token.json` in .gitignore)
- [ ] No internal dev artifacts in repo root
- [ ] CI workflow runs green on GitHub
- [ ] GitHub description and topics are set
- [ ] Screenshots added to README (see `docs/SCREENSHOTS.md`)
- [ ] PyPI published (or README clearly notes source-install-only)

---

## Post-Public Checklist

- [ ] Create GitHub release (pre-release) — use title and body from above
- [ ] Pin issue for beta feedback if desired
- [ ] Monitor issues for first-user friction reports
- [ ] Publish to PyPI (`uv build && uv publish`)
- [ ] **After PyPI publish**: update README install section (see `docs/RELEASING.md` § "Post-Publish README Update")
- [ ] Add Homebrew formula when stable
- [ ] Capture and embed screenshots (see `docs/SCREENSHOTS.md`)
