First public beta of gdrive-organizer.

**What it does**: Scans your Google Drive, classifies files with AI (xAI Grok), generates a reviewable execution plan, and applies changes with dry-run and rollback support.

**Who it's for**: Technical users comfortable with CLI tools who want safe, reviewable Drive automation.

**Quick start**: See the [README](https://github.com/papa-channy/google-drive-manager#quick-start) for install and first-run instructions.

**What's included**:
- Flat-crawl scanner with in-memory tree reconstruction
- AI classification via xAI Grok (migration, second-brain, custom presets)
- Plan/Apply separation with dry-run and rollback
- Readonly OAuth mode for safe exploration
- Local FastAPI web viewer for visual inspection
- 210 passing tests, CI via GitHub Actions

**Known limitations**:
- Install from source only (PyPI publishing coming soon)
- OAuth testing mode: tokens expire after 7 days
- Classifies by metadata only (content-based classification on roadmap)

See [CHANGELOG.md](CHANGELOG.md) for full details.
