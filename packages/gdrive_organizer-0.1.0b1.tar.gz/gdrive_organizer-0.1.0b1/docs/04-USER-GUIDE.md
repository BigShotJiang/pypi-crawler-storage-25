# GDrive Organizer — User Guide

> **Version**: 1.0
> **Last Updated**: 2026-04-08

---

## 1. Prerequisites

- Python 3.12+
- Google 계정
- Google Cloud Platform 프로젝트 (무료)

---

## 2. GCP OAuth Setup (필수, 최초 1회)

### Step 1: GCP 프로젝트 생성

1. [Google Cloud Console](https://console.cloud.google.com/) 접속
2. 상단의 프로젝트 선택 → "새 프로젝트" 클릭
3. 프로젝트 이름: `gdrive-organizer` (자유)
4. "만들기" 클릭

### Step 2: Drive API 활성화

1. 왼쪽 메뉴 → "API 및 서비스" → "라이브러리"
2. "Google Drive API" 검색 → 클릭
3. "사용" 버튼 클릭

### Step 3: OAuth 동의 화면 설정

1. 왼쪽 메뉴 → "API 및 서비스" → "OAuth 동의 화면"
2. User Type: **외부(External)** 선택 → "만들기"
3. 앱 정보 입력:
   - 앱 이름: `GDrive Organizer`
   - 사용자 지원 이메일: 본인 이메일
   - 개발자 연락처 이메일: 본인 이메일
4. "저장 후 계속" 클릭
5. 범위(Scopes) 페이지: "범위 추가" →
   - `https://www.googleapis.com/auth/drive` 검색 후 추가
   - "업데이트" → "저장 후 계속"
6. 테스트 사용자 페이지:
   - "+ 사용자 추가" → 본인 Gmail 주소 입력
   - (공유할 지인이 있으면 그들의 Gmail도 추가, 최대 100명)
   - "저장 후 계속"
7. 요약 확인 → "대시보드로 돌아가기"

> **중요**: 앱이 "testing" 상태이므로 Google 심사 불필요.
> 단, refresh token이 **7일 후 만료**됨 → 주기적으로 재로그인 필요.

### Step 4: OAuth 클라이언트 ID 생성

1. 왼쪽 메뉴 → "API 및 서비스" → "사용자 인증 정보"
2. "사용자 인증 정보 만들기" → "OAuth 클라이언트 ID"
3. 애플리케이션 유형: **데스크톱 앱**
4. 이름: `GDrive Organizer CLI`
5. "만들기" 클릭
6. 생성된 클라이언트에서 **JSON 다운로드** (↓ 아이콘)
7. 다운로드된 파일을 `credentials.json`으로 이름 변경

---

## 3. Installation

```bash
# pipx (권장 — 격리된 환경에 설치)
pipx install gdrive-organizer

# 또는 pip
pip install gdrive-organizer

# 또는 소스에서 설치 (개발자용)
git clone https://github.com/your-username/gdrive-organizer.git
cd gdrive-organizer
uv sync
```

---

## 4. Initial Setup

```bash
# 1. credentials.json 배치
mkdir -p ~/.config/gdrive-organizer
cp ~/Downloads/credentials.json ~/.config/gdrive-organizer/

# 2. 로그인
gdrive-organizer auth login
# → 브라우저가 열리며 Google 계정 선택 화면 표시
# → 계정 선택 → "계속" → "GDrive Organizer가 Google 계정에 액세스하도록 허용"
# → "허용" 클릭
# → 터미널에 "Authentication successful!" 표시

# 3. 인증 상태 확인
gdrive-organizer auth status
# → Token valid. Expires at: 2026-04-08T15:30:00Z
```

---

## 5. Basic Usage

### 5.1 Drive 스캔

```bash
# 전체 Drive 스캔
gdrive-organizer scan
# → Scanning Google Drive...
# → Page 1: 1000 files (total: 1000)
# → Page 2: 1000 files (total: 2000)
# → ...
# → Scan complete: 12,345 files, 890 folders (45.2s)
# → Snapshot saved: data/snapshots/2026-04-08T14-30-00.json

# 특정 폴더만 스캔
gdrive-organizer scan --folder "1abc2def3ghi"

# 증분 스캔 (이전 스캔 이후 변경사항만)
gdrive-organizer scan --incremental
```

### 5.2 트리 확인

```bash
# 터미널에 트리 표시
gdrive-organizer tree
# My Drive
# ├── Work
# │   ├── Projects
# │   │   ├── Project A
# │   │   └── Project B
# │   └── Reports
# └── Personal
#     ├── Photos
#     └── Documents

# 깊이 제한
gdrive-organizer tree --depth 2
```

### 5.3 통계 확인

```bash
gdrive-organizer stats
# ┌──────────────────────────┬───────┬──────────┐
# │ File Type                │ Count │     Size │
# ├──────────────────────────┼───────┼──────────┤
# │ Google Docs              │ 2,345 │      N/A │
# │ Google Sheets            │   456 │      N/A │
# │ PDF                      │   789 │   2.1 GB │
# │ Images (jpg/png)         │ 1,234 │   5.6 GB │
# │ ...                      │   ... │      ... │
# └──────────────────────────┴───────┴──────────┘
```

### 5.4 권한 확인

```bash
gdrive-organizer permissions
# Shared Files Summary:
#   Public (anyone): 12 files
#   Domain-wide: 45 files
#   Specific users: 234 files
#   Not shared: 10,054 files
```

### 5.5 AI 분류

```bash
# AI로 파일 분류 + plan 생성
gdrive-organizer classify
# → Analyzing 12,345 files with AI...
# → Classification complete.
# → Generated plan: 234 renames, 56 moves
# → Plan saved: data/plans/plan-2026-04-08.json

# Plan 확인
gdrive-organizer plan show
# ┌───────────────────────────────────────────────────────┐
# │ Operation  │ Current Name        │ New Name           │
# ├────────────┼─────────────────────┼────────────────────┤
# │ RENAME     │ meeting notes       │ 2025-03-15_Meeting │
# │ MOVE       │ /root/report.docx   │ /Work/Reports/     │
# └────────────┴─────────────────────┴────────────────────┘
```

### 5.6 변경 적용

```bash
# Dry run (실제 변경 없이 결과만 확인)
gdrive-organizer plan apply --dry-run
# → [DRY RUN] Would rename: meeting notes → 2025-03-15_Meeting Notes
# → [DRY RUN] Would move: /root/report.docx → /Work/Reports/report.docx
# → Total: 234 renames, 56 moves (0 applied)

# 실제 적용
gdrive-organizer plan apply
# → Apply 290 operations to Google Drive? [y/N]: y
# → Applying... ████████████████████ 290/290 (100%)
# → Complete: 288 success, 2 failed
# → Rollback log: data/logs/rollback-2026-04-08T15-00-00.json

# 문제 시 되돌리기
gdrive-organizer plan rollback
# → Rollback 288 operations? [y/N]: y
# → Rolling back... ████████████████ 288/288
# → Rollback complete.
```

### 5.7 웹 대시보드

```bash
gdrive-organizer view
# → Starting dashboard at http://localhost:8765
# → (브라우저 자동 열림)
```

---

## 6. Configuration

```bash
# 현재 설정 확인
gdrive-organizer config show

# 설정 변경
gdrive-organizer config set llm_hub_url http://my-server:3456
gdrive-organizer config set viewer_port 9000
gdrive-organizer config set write_rate_limit 2.0
```

### 설정 파일 위치

```
~/.config/gdrive-organizer/
├── config.json          # 사용자 설정
├── credentials.json     # GCP OAuth 클라이언트 시크릿
└── token.json           # 발급된 토큰 (자동 생성)
```

### 데이터 파일 위치

```
~/.local/share/gdrive-organizer/
├── snapshots/           # Drive 스냅샷
├── plans/               # 실행 계획
└── logs/                # 실행/롤백 로그
```

---

## 7. LLM Hub Configuration

이 도구는 LLM Hub 서버를 통해 AI 분류를 수행합니다.

```bash
# LLM Hub URL 설정 (기본: http://localhost:3456)
gdrive-organizer config set llm_hub_url http://your-hub-server:3456

# 사용 모델 설정 (LLM Hub 별칭 사용)
gdrive-organizer config set llm_model claude-sonnet
```

LLM Hub가 없는 경우, `classify` 명령은 사용할 수 없지만 나머지 기능(scan, tree, permissions, 수동 plan 작성 등)은 정상 동작합니다.

---

## 8. Troubleshooting

### "Token has been expired or revoked"

Testing mode에서 refresh token은 7일 후 만료됩니다.

```bash
gdrive-organizer auth logout
gdrive-organizer auth login
```

### "Rate limit exceeded"

대량 파일 작업 시 Google API rate limit에 도달할 수 있습니다.
도구가 자동으로 exponential backoff를 수행하지만, 지속되면:

```bash
# write rate를 낮추기
gdrive-organizer config set write_rate_limit 2.0

# batch 크기 줄이기
gdrive-organizer config set batch_size 50
```

### "File not found (404)" during apply

스캔 이후 Drive에서 파일이 삭제/이동된 경우 발생합니다.

```bash
# 최신 상태로 재스캔
gdrive-organizer scan
# plan 재생성
gdrive-organizer classify
```

### credentials.json 분실

GCP Console → 사용자 인증 정보 → 기존 클라이언트에서 다시 JSON 다운로드.

---

## 9. Security Notes

- `credentials.json`과 `token.json`은 절대 Git에 커밋하지 마세요
- 이 도구는 파일 **내용**을 LLM에 전송하지 않습니다 — 메타데이터(이름, 경로, 타입)만 전송
- Apply 전 반드시 `--dry-run`으로 변경 사항을 확인하세요
- Rollback이 가능하지만, 다른 사용자가 동시에 파일을 수정하면 충돌할 수 있습니다
