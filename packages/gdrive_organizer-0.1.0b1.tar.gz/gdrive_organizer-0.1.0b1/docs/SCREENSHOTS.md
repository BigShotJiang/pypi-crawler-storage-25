# Screenshots Guide

This document describes the recommended screenshots for the README and project documentation.

## Required Screenshots

Place all screenshots in `docs/assets/` as PNG files.

### 1. CLI Scan Output (`docs/assets/scan-cli.png`)

Capture the output of `gdrive-organizer scan` showing:
- Progress pages being fetched
- Final summary line with file/folder counts and timing

```bash
gdrive-organizer scan
```

### 2. CLI Plan Review (`docs/assets/plan-cli.png`)

Capture the output of `gdrive-organizer plan show` showing:
- Table of proposed operations (rename, move)
- Current and new file paths/names

```bash
gdrive-organizer plan show
```

### 3. CLI Tree Output (`docs/assets/tree-cli.png`)

Capture a trimmed tree view:

```bash
gdrive-organizer tree --depth 3
```

### 4. Viewer Dashboard (`docs/assets/viewer-dashboard.png`)

Open `gdrive-organizer view` and capture the main dashboard page showing:
- Navigation sidebar
- Stats overview
- File type distribution

### 5. Viewer Plan Review (`docs/assets/viewer-plan.png`)

Navigate to the Plan tab in the viewer and capture:
- Operation list with checkboxes
- Approve/reject controls

### 6. Dry-Run Output (`docs/assets/dry-run-cli.png`)

Capture:

```bash
gdrive-organizer plan apply --dry-run
```

## How to Capture

On macOS:
```bash
# Full window screenshot
Cmd+Shift+4, then Space, then click the terminal window

# Or use a terminal recording tool
# brew install vhs  (for animated GIF recordings)
```

## Embedding in README

Once captured, add to README.md:

```markdown
![CLI scan output](docs/assets/scan-cli.png)
![Plan review](docs/assets/plan-cli.png)
![Web viewer](docs/assets/viewer-dashboard.png)
```
