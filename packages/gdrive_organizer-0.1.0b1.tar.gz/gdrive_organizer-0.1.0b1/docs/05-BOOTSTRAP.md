# GDrive Organizer — Claude Code Bootstrap

> **Purpose**: Claude Code에서 즉시 작업을 시작하기 위한 초기 명령 가이드
> **Last Updated**: 2026-04-08

---

## Quick Start: Stage 1, Task 1-1

Claude Code를 열고 아래 순서로 실행:

### 1. 프로젝트 생성

```bash
# 프로젝트 디렉터리 생성
mkdir gdrive-organizer && cd gdrive-organizer

# Git 초기화
git init

# uv로 Python 프로젝트 초기화
uv init --name gdrive-organizer --python 3.12
```

### 2. pyproject.toml 작성

```toml
[project]
name = "gdrive-organizer"
version = "0.1.0"
description = "AI-powered Google Drive organizer CLI"
readme = "README.md"
requires-python = ">=3.12"
license = { text = "MIT" }

dependencies = [
    "typer[all]>=0.12",
    "google-api-python-client>=2.150",
    "google-auth-oauthlib>=1.2",
    "google-auth-httplib2>=0.2",
    "fastapi>=0.115",
    "uvicorn>=0.30",
    "jinja2>=3.1",
    "httpx>=0.27",
    "rich>=13.0",
    "pydantic>=2.9",
    "pydantic-settings>=2.5",
]

[project.scripts]
gdrive-organizer = "gdrive_organizer.cli:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/gdrive_organizer"]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
    "ruff>=0.6",
]
```

### 3. 디렉터리 구조 생성

```bash
mkdir -p src/gdrive_organizer/{auth,scanner,store,ai,executor,viewer/{templates,static},utils}
mkdir -p tests/fixtures
mkdir -p docs

# __init__.py 생성
touch src/gdrive_organizer/__init__.py
touch src/gdrive_organizer/{auth,scanner,store,ai,executor,viewer,utils}/__init__.py
```

### 4. .gitignore

```
# Python
__pycache__/
*.py[cod]
*.egg-info/
dist/
.venv/

# Secrets
credentials.json
token.json

# Runtime data
data/

# IDE
.vscode/
.idea/

# OS
.DS_Store
```

### 5. ruff.toml

```toml
line-length = 100
target-version = "py312"

[lint]
select = ["E", "F", "I", "N", "W", "UP"]

[format]
quote-style = "double"
```

### 6. 최소 CLI 엔트리포인트

```python
# src/gdrive_organizer/cli.py
import typer

app = typer.Typer(
    name="gdrive-organizer",
    help="AI-powered Google Drive organizer",
    no_args_is_help=True,
)

@app.command()
def version():
    """Show version."""
    typer.echo("gdrive-organizer v0.1.0")

if __name__ == "__main__":
    app()
```

### 7. 의존성 설치 및 확인

```bash
uv sync
uv run gdrive-organizer --help
uv run ruff check src/
```

---

## 문서 배치

docs/ 디렉터리에 아래 문서 파일을 배치:

```
docs/
├── 01-ARCHITECTURE.md      # 아키텍처 문서
├── 02-API-REFERENCE.md     # Drive API 레퍼런스
├── 03-WORK-PLAN.md         # 작업 계획
├── 04-USER-GUIDE.md        # 사용자 가이드
└── 05-BOOTSTRAP.md         # 이 파일
```

---

## Claude Code 작업 시 참고사항

### 작업 흐름

1. **현재 Stage/Task 확인**: `03-WORK-PLAN.md` 에서 진행할 Task 확인
2. **관련 문서 참조**: 해당 Task에 필요한 API나 아키텍처 문서 참조
3. **구현**: Task의 "작업 내용" 항목에 따라 코드 작성
4. **검증**: "완료 기준" 체크리스트 확인
5. **커밋**: Task 단위로 커밋

### 커밋 컨벤션

```
feat(module): 기능 설명
fix(module): 버그 수정
docs: 문서 업데이트
test: 테스트 추가
refactor(module): 리팩터링
```

예시:
```
feat(auth): implement OAuth desktop app flow
feat(scanner): implement flat crawl with pagination
feat(cli): add scan command with progress bar
```

### 테스트 실행

```bash
# 전체 테스트
uv run pytest

# 특정 모듈
uv run pytest tests/test_crawler.py -v

# 린트
uv run ruff check src/
uv run ruff format src/
```

---

## Stage 1 완료 후 다음 단계

Stage 1 (Task 1-1 ~ 1-4) 완료 후:

1. `gdrive-organizer auth login` 으로 실제 Google 인증 테스트
2. `gdrive-organizer auth status` 로 토큰 상태 확인
3. 문서 업데이트 (실제 구현 결과 반영)
4. Stage 2 시작 (Drive Scanner)
