# GDrive Organizer — Work Plan

> **Version**: 1.0
> **Last Updated**: 2026-04-08
> **Total Stages**: 6
> **Estimated Duration**: 각 Stage별 1-2 세션

---

## Stage Overview

| Stage | Name | Description | 핵심 산출물 |
|-------|------|-------------|------------|
| 1 | Project Setup | 프로젝트 초기화, 의존성, 인증 | pyproject.toml, auth 모듈 |
| 2 | Drive Scanner | 파일 크롤링, 트리 구성, 스냅샷 | scanner 모듈, snapshot JSON |
| 3 | CLI Foundation | CLI 명령 구조, 설정 관리 | cli.py, config.py |
| 4 | Web Viewer | 로컬 대시보드, 트리 시각화 | FastAPI viewer |
| 5 | AI Classifier | LLM 연동, 분류, plan 생성 | ai 모듈, plan JSON |
| 6 | Batch Executor | Plan 실행, rate limiting, rollback | executor 모듈 |

---

## Stage 1: Project Setup & Authentication

### 목표
프로젝트 구조 생성, 의존성 설정, OAuth 인증 플로우 구현 및 테스트.

### Task 1-1: 프로젝트 초기화
**작업 내용:**
- `uv init gdrive-organizer` 로 프로젝트 생성
- `pyproject.toml` 작성 (metadata, dependencies, scripts)
- `src/gdrive_organizer/` 패키지 구조 생성
- `.gitignore` 설정 (token.json, credentials.json, data/, .venv/)
- `ruff.toml` 린터 설정

**완료 기준:**
- [x] `uv sync` 성공
- [x] `gdrive-organizer --help` 출력 (빈 CLI)
- [x] ruff check 통과

**산출물:**
```
gdrive-organizer/
├── pyproject.toml
├── ruff.toml
├── .gitignore
├── README.md
└── src/gdrive_organizer/
    ├── __init__.py
    └── cli.py
```

### Task 1-2: 설정 관리 모듈
**작업 내용:**
- `config.py`: Pydantic Settings 기반 설정 관리
- 설정 경로: `~/.config/gdrive-organizer/config.json`
- 환경 변수 오버라이드 지원
- 기본값: LLM Hub URL, 데이터 디렉터리, 로그 레벨

**설정 항목:**
```python
class Config(BaseSettings):
    config_dir: Path = Path.home() / ".config" / "gdrive-organizer"
    data_dir: Path = Path.home() / ".local/share/gdrive-organizer"
    credentials_path: Path = config_dir / "credentials.json"
    token_path: Path = config_dir / "token.json"
    llm_hub_url: str = "http://localhost:3456"
    llm_model: str = "claude-sonnet"
    viewer_port: int = 8765
    log_level: str = "INFO"
    scan_page_size: int = 1000
    batch_size: int = 100
    write_rate_limit: float = 3.0
```

**완료 기준:**
- [x] Config 로드/저장 동작 확인
- [x] 환경 변수 `GDRIVE_*` 오버라이드 동작

### Task 1-3: OAuth 인증 모듈
**작업 내용:**
- `auth/oauth.py`: Google OAuth 2.0 Desktop App flow 구현
- 브라우저 자동 열기 → consent → token 저장
- Token 자동 갱신 (access token 만료 시)
- Token 상태 확인 (유효/만료/없음)
- Service 객체 생성 팩토리

**핵심 코드:**
```python
def get_drive_service(config: Config) -> Resource:
    """Authenticated Drive API v3 service를 반환."""
    creds = _load_or_refresh_token(config)
    if not creds:
        creds = _run_oauth_flow(config)
    return build("drive", "v3", credentials=creds)
```

**완료 기준:**
- [x] `gdrive-organizer auth login` → 브라우저 OAuth 완료 → token.json 생성
- [x] `gdrive-organizer auth status` → 토큰 유효성 출력
- [x] token.json 존재 시 재로그인 없이 서비스 생성
- [x] 만료된 access token 자동 갱신 확인

### Task 1-4: Logger 모듈
**작업 내용:**
- `utils/logger.py`: Rich 기반 구조화된 로깅
- 레벨: DEBUG, INFO, WARNING, ERROR
- 파일 로그 (`data/logs/`)와 콘솔 로그 분리

**완료 기준:**
- [x] 콘솔에 컬러 로그 출력
- [x] 로그 파일 생성 확인

---

## Stage 2: Drive Scanner & Snapshot

### 목표
전체 Drive 파일 메타데이터를 수집하고 로컬 JSON 스냅샷으로 저장.

### Task 2-1: Flat Crawler
**작업 내용:**
- `scanner/crawler.py`: files.list paginated 크롤러
- pageSize=1000, 필요한 fields만 요청
- 진행 상황 rich progress bar 표시
- 공유 드라이브 포함 (`supportsAllDrives=True`)
- 에러 retry 데코레이터 적용

**완료 기준:**
- [x] 실제 Drive에서 전체 파일 목록 수집 성공
- [x] Progress bar로 페이지/파일 수 실시간 표시
- [x] 공유 드라이브 파일도 포함 확인

### Task 2-2: Tree Reconstruction
**작업 내용:**
- `scanner/tree.py`: flat list → tree 구조 변환
- parents 필드 기반 parent-child 관계 구성
- 각 파일의 full path 계산
- shortcut 파일 resolve (`shortcutDetails.targetId`)
- orphan 파일 처리 (parent가 결과에 없는 경우)

**완료 기준:**
- [x] 모든 파일에 올바른 path가 설정됨
- [x] `My Drive/folder1/subfolder/file.txt` 형태의 path
- [x] shortcut 파일이 target 정보 포함

### Task 2-3: Snapshot 저장/로드
**작업 내용:**
- `store/snapshot.py`: Snapshot JSON 읽기/쓰기
- 타임스탬프 기반 파일명 (`2026-04-08T14-30-00.json`)
- `latest.json` 심볼릭 링크 관리
- snapshot 간 diff 계산 (추가/삭제/수정된 파일)
- 스냅샷 압축 옵션 (gzip)

**완료 기준:**
- [x] scan → snapshot.json 저장 성공
- [x] snapshot 로드 후 파일 수 일치 확인
- [x] latest.json 심볼릭 링크 정상 동작

### Task 2-4: Permission Scanner
**작업 내용:**
- `scanner/permissions.py`: 공유 파일의 권한 상세 조회
- files.list에서 이미 가져온 기본 permissions 활용
- 필요 시 permissions.list 추가 호출 (공유 드라이브)
- 권한 요약: 공유 범위별 (anyone, domain, specific users)

**완료 기준:**
- [x] 각 파일의 permissions 정보 포함
- [x] "공유된 파일 N개, 공개 파일 M개" 요약 출력

### Task 2-5: Changes API 연동
**작업 내용:**
- `store/changelog.py`: 증분 동기화
- getStartPageToken → snapshot과 함께 저장
- changes.list → 변경사항 수집
- 스냅샷에 변경사항 적용 (add/update/remove)

**완료 기준:**
- [x] 초기 스캔 시 changeToken 저장
- [x] `scan --incremental` → 변경된 파일만 업데이트
- [x] 증분 스캔 후 스냅샷 정합성 유지

---

## Stage 3: CLI Foundation

### 목표
전체 CLI 명령 구조 완성, scan/tree/stats/permissions 명령 동작.

### Task 3-1: CLI Entry Point
**작업 내용:**
- `cli.py`: Typer app 구성
- 서브커맨드 그룹: auth, scan, tree, stats, permissions, classify, plan, view, config
- Global options: `--verbose`, `--config-dir`
- Rich 기반 에러 표시 및 프로그레스

**완료 기준:**
- [x] `gdrive-organizer --help` 에 모든 명령 표시
- [x] 각 서브커맨드 `--help` 동작

### Task 3-2: scan 명령 구현
**작업 내용:**
- `gdrive-organizer scan` → crawler + snapshot 연결
- `--folder <id>` 옵션 (특정 폴더만)
- `--incremental` 옵션 (Changes API)
- 완료 시 요약 출력 (파일 수, 폴더 수, 소요 시간)

**완료 기준:**
- [x] `scan` → snapshot 파일 생성
- [x] `scan --incremental` → 증분 업데이트
- [x] 실행 결과 요약 rich table 출력

### Task 3-3: tree/stats/permissions 명령
**작업 내용:**
- `tree`: rich.tree로 터미널에 트리 출력 (depth 제한 옵션)
- `stats`: 파일 타입별 개수, 크기 분포, 최근 수정 현황
- `permissions`: 공유 파일 목록, 권한별 요약

**완료 기준:**
- [x] `tree --depth 3` → 깔끔한 트리 출력
- [x] `stats` → 통계 테이블 출력
- [x] `permissions` → 공유 현황 테이블 출력

---

## Stage 4: Web Viewer

### 목표
브라우저 기반 대시보드로 Drive 구조, 권한, AI plan을 시각화.

### Task 4-1: FastAPI 로컬 서버
**작업 내용:**
- `viewer/app.py`: FastAPI + Jinja2 기반 로컬 웹 서버
- 스냅샷 JSON을 읽어 API 제공
- `gdrive-organizer view` → uvicorn으로 서버 시작 + 브라우저 자동 열기

**API 엔드포인트:**
```
GET  /                          # 대시보드 메인
GET  /api/tree                  # 트리 데이터 (JSON)
GET  /api/files?q=<query>       # 파일 검색
GET  /api/stats                 # 통계
GET  /api/permissions           # 권한 현황
GET  /api/plan                  # 현재 plan (있으면)
POST /api/plan/approve          # Plan 승인
```

**완료 기준:**
- [x] `gdrive-organizer view` → 브라우저에 대시보드 표시
- [x] 트리 뷰 collapsible 동작
- [x] 파일 검색 동작

### Task 4-2: Tree Viewer UI
**작업 내용:**
- HTML/CSS/JS: 파일/폴더 트리 시각화
- Collapsible 폴더 노드
- 파일 타입별 아이콘 (mimeType 기반)
- 검색/필터링 기능
- 파일 클릭 시 상세 정보 패널

**완료 기준:**
- [x] 1000+ 파일 트리 렌더링 성능 양호 (< 2초)
- [x] 검색 실시간 필터링 동작
- [x] 파일 상세 정보 (권한, 수정일, 크기 등) 표시

### Task 4-3: Plan Review UI
**작업 내용:**
- Plan diff 뷰: before/after 비교
- 개별 operation approve/reject 체크박스
- Plan 전체 approve/reject 버튼
- 변경 사항 통계 요약

**완료 기준:**
- [x] Plan이 있을 때 diff 뷰 표시
- [x] 개별 항목 선택/해제 가능
- [x] Approve → executor에 전달할 최종 plan 생성

---

## Stage 5: AI Classifier

### 목표
LLM Hub를 통해 파일을 자동 분류하고, 이름 변경/폴더 이동 plan을 생성.

### Task 5-1: LLM Hub 클라이언트
**작업 내용:**
- `ai/classifier.py`: httpx 기반 LLM Hub 호출
- OpenAI-compatible chat/completions endpoint
- X-Project-Id 헤더로 사용량 추적
- 응답 파싱 (JSON mode)
- Timeout, retry 처리

**완료 기준:**
- [x] LLM Hub에 요청 → 응답 수신 성공
- [x] 에러 시 graceful fallback

### Task 5-2: Classification Prompt Engineering
**작업 내용:**
- System prompt: 파일 분류 규칙 정의
- 입력: 파일 메타데이터 배치 (이름, 경로, mimeType, 수정일)
- 출력: JSON 형태의 분류 결과 + 제안
- 배치 크기 최적화 (토큰 제한 고려)

**분류 카테고리 예시:**
```json
{
  "categories": [
    "documents/reports",
    "documents/meeting-notes",
    "documents/templates",
    "spreadsheets/finance",
    "spreadsheets/data",
    "media/images",
    "media/videos",
    "code/projects",
    "personal",
    "archive"
  ]
}
```

**완료 기준:**
- [x] 50개 파일 배치 분류 성공
- [x] 분류 결과 JSON 형태로 파싱 가능
- [x] 분류 정확도 체감 검증

### Task 5-3: Naming Rule Engine
**작업 내용:**
- `ai/namer.py`: 이름 규칙 엔진
- 규칙 예: 날짜 prefix (`2026-04-08_`), 카테고리 태그, 특수문자 정리
- 사용자 커스텀 규칙 파일 지원 (JSON/YAML)
- LLM 제안 + 규칙 기반 하이브리드

**완료 기준:**
- [x] 기본 규칙으로 이름 변환 예시 생성
- [x] 커스텀 규칙 파일 로드/적용

### Task 5-4: Plan Generator
**작업 내용:**
- `ai/planner.py`: 분류 결과 → ExecutionPlan 변환
- rename/move/rename_and_move operations 생성
- 충돌 감지 (같은 폴더에 같은 이름)
- Plan JSON 저장

**완료 기준:**
- [x] `classify` → plan.json 생성
- [x] Plan에 충돌 없음 확인
- [x] `plan show` → 변경 요약 출력

---

## Stage 6: Batch Executor

### 목표
생성된 plan을 Drive에 안전하게 적용, rate limiting과 rollback 지원.

### Task 6-1: Rate Limiter
**작업 내용:**
- `executor/rate_limiter.py`: Token bucket 알고리즘
- 초당 write 수 제한 (기본 3.0)
- Acquire/release 패턴

**완료 기준:**
- [x] 연속 호출 시 3/sec 이하 유지 확인
- [x] 버스트 허용 (bucket에 토큰 있을 때)

### Task 6-2: Batch Runner
**작업 내용:**
- `executor/runner.py`: Plan 실행 엔진
- Dry-run 모드 (API 호출 없이 계획만 출력)
- Batch API 활용 (100개 단위)
- 각 operation 성공/실패 기록
- 진행 상황 progress bar

**완료 기준:**
- [x] `plan apply --dry-run` → 변경 예정 사항 출력 (API 호출 없음)
- [x] `plan apply` → 실제 Drive 변경 적용
- [x] 부분 실패 시 성공/실패 분리 보고

### Task 6-3: Rollback Support
**작업 내용:**
- `executor/runner.py`: 롤백 기능
- 각 operation 실행 전 원래 상태 기록 (rollback log)
- `plan rollback` → 마지막 실행을 되돌리기
- Rollback log JSON 저장 (`data/logs/rollback-{timestamp}.json`)

**Rollback Log Schema:**
```json
{
  "executedAt": "2026-04-08T15:00:00Z",
  "planRef": "plan-2026-04-08.json",
  "operations": [
    {
      "fileId": "1abc...",
      "type": "rename",
      "before": {"name": "old_name.txt", "parents": ["folder1"]},
      "after": {"name": "new_name.txt", "parents": ["folder1"]},
      "status": "success"
    }
  ]
}
```

**완료 기준:**
- [x] Apply 시 rollback log 자동 생성
- [x] `plan rollback` → 이전 상태로 복원
- [x] 롤백 결과 요약 출력

### Task 6-4: End-to-End Test
**작업 내용:**
- 전체 파이프라인 테스트: scan → classify → plan → review → apply → verify
- 테스트용 Google Drive 폴더에서 실행
- 100개 파일 rename + 20개 move 시나리오

**완료 기준:**
- [x] 전체 파이프라인 성공
- [x] 변경 후 Drive에서 결과 확인
- [x] Rollback 후 원상 복구 확인

---

## Implementation Notes

### Task 진행 규칙

1. 각 Task는 **독립적으로 완료 가능**한 단위로 설계
2. Task 시작 전: 해당 Task의 목표와 완료 기준 확인
3. Task 완료 후: 완료 기준 체크리스트 검증 → 다음 Task로
4. Stage 완료 후: 전체 테스트 실행 → 문서 업데이트

### 테스트 전략

- Unit tests: 각 모듈의 순수 로직 (tree 구성, path 계산, plan 생성)
- Integration tests: Mock API 응답으로 크롤러/배치 테스트
- E2E tests: 실제 Drive API 호출 (별도 테스트 폴더)
- `tests/fixtures/`: 고정된 API 응답 JSON

### Git Workflow

- `main`: 안정 브랜치
- `stage/N-name`: 각 Stage별 브랜치
- Task 완료 시 커밋 (e.g., `feat(scanner): implement flat crawler`)
- Stage 완료 시 main에 merge
