# Release Guide

How to publish a new version of gdrive-organizer.

## Version Locations

Update the version string in **both** of these files before releasing:

1. `pyproject.toml` -- `version` field
2. `src/gdrive_organizer/__init__.py` -- `__version__` string

These must match. The CLI reads from `__init__.py`; PyPI reads from `pyproject.toml`.

## Pre-Release Checklist

```bash
# 1. Ensure all tests pass
just check

# 2. Verify version strings match
grep 'version' pyproject.toml | head -1
grep '__version__' src/gdrive_organizer/__init__.py

# 3. Verify CHANGELOG.md has an entry for this version

# 4. Verify clean working tree
git status
```

## Build

```bash
uv build
# Creates dist/gdrive_organizer-X.Y.Z.tar.gz and .whl
```

## Publish to PyPI

### First-time setup

```bash
# Create a PyPI API token at https://pypi.org/manage/account/token/
# Store it securely
```

### Upload

```bash
# Test PyPI first (recommended for first release)
uv publish --publish-url https://test.pypi.org/legacy/

# Verify on test.pypi.org, then publish to real PyPI
uv publish
```

### Verify

```bash
# In a fresh venv — always do this after publish
python -m venv /tmp/gdo-test
source /tmp/gdo-test/bin/activate
pip install gdrive-organizer
gdrive-organizer --version
deactivate
rm -rf /tmp/gdo-test
```

## Post-Publish README Update

After PyPI publish succeeds, update the install section in `README.md`.

**Replace** the current source-first block:

```markdown
### 1. Install

<!-- MAINTAINER: after PyPI publish, replace this install section with the
     post-publish version from docs/RELEASING.md § "Post-Publish README Update" -->

\`\`\`bash
# Install from source (recommended for beta)
git clone https://github.com/papa-channy/google-drive-manager.git
...
\`\`\`

> **PyPI package coming soon.** ...
```

**With** this pip-first version:

```markdown
### 1. Install

\`\`\`bash
# Recommended: isolated install
pipx install gdrive-organizer

# Or with pip
pip install gdrive-organizer
\`\`\`

> For development or contributing, install from source instead:
> \`\`\`bash
> git clone https://github.com/papa-channy/google-drive-manager.git
> cd google-drive-manager
> uv sync --all-extras
> \`\`\`
```

Also remove the "Coming soon" line from the Roadmap section.

Commit this change as: `docs(readme): switch install to PyPI after publish`

## Post-Release

1. Tag and create GitHub release using the dedicated release notes file:
   ```bash
   gh release create v0.1.0-beta.1 \
     --title "v0.1.0-beta.1 -- Public Beta" \
     --notes-file docs/release-notes-v0.1.0-beta.1.md \
     --prerelease
   ```

2. Push the tag if needed:
   ```bash
   git push origin v0.1.0-beta.1
   ```

## Version Scheme

- `X.Y.Z-beta.N` -- beta releases (current stage)
- `X.Y.Z` -- stable releases
- Follow [Semantic Versioning](https://semver.org/)
