# Surface Ownership — CLI vs Viewer

This document defines which surface owns each capability.

## Ownership Rule

- **CLI** is the canonical owner of all auth, mutation, and generation actions.
- **Viewer** is a read/review surface that can *trigger* CLI-owned actions via approved-plan files, but never executes mutations directly.
- If a feature is not implemented yet, the Viewer must not surface it as if it were.

## Capability Matrix

| Capability       | CLI        | Viewer         | Notes                                            |
| ---------------- | ---------- | -------------- | ------------------------------------------------ |
| Auth login       | Owner      | —              | CLI only; viewer shows status                    |
| Auth status      | Owner      | Display        | Both show token info                             |
| Scan             | Owner      | —              | Viewer shows "run scan from CLI" on empty state  |
| Incremental sync | Owner      | —              |                                                  |
| Tree / Stats     | Owner      | Display owner  | Viewer is the primary visual tree browser         |
| File search      | Owner      | Display owner  |                                                  |
| Permissions      | Owner      | Display owner  |                                                  |
| Classify (plan)  | Owner      | —              | Viewer reviews plans, does not generate them     |
| Plan review      | Display    | Display owner  | Viewer is the primary plan review surface         |
| Plan approve     | Owner      | Trigger        | Viewer writes approved-plan.json; CLI executes   |
| Plan apply       | Owner      | —              | CLI only; viewer shows "run from CLI" message    |
| Plan rollback    | Owner      | —              | CLI only                                         |
| Duplicates       | Owner      | Display        | Read-only view; bulk cleanup not yet implemented |
| Config / API key | Owner      | Trigger        | Viewer can set API key (session-token gated)     |

## Data Flow for Mutations

```
Viewer "Approve Selected" → writes approved-plan.json → User runs CLI "plan apply" → Drive API
```

The Viewer never calls the Drive API directly.

## Data Egress to LLM Provider

When `gdrive-organizer classify` runs:
- File names, paths, sizes, and modification dates are sent to the configured LLM provider (default: xAI Grok).
- For Workspace files (Docs/Sheets/Slides), the first ~500 characters of exported text are also sent.
- Binary files are classified by metadata only.

The LLM provider's data retention policy applies. Review your provider's terms.
Set `GDRIVE_OAUTH_READONLY=true` for scan/browse workflows that never need LLM access.
