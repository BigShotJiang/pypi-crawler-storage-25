"""Tests for token bucket rate limiter."""

import time

from gdrive_organizer.executor.rate_limiter import TokenBucket


def test_initial_burst():
    bucket = TokenBucket(rate=3.0, capacity=5.0)
    start = time.monotonic()
    for _ in range(5):
        bucket.acquire(1.0)
    elapsed = time.monotonic() - start
    # Initial burst should be nearly instant
    assert elapsed < 0.5


def test_rate_limiting():
    bucket = TokenBucket(rate=10.0, capacity=1.0)
    # Drain the initial capacity
    bucket.acquire(1.0)
    start = time.monotonic()
    bucket.acquire(1.0)
    elapsed = time.monotonic() - start
    # Should wait ~0.1 seconds for 1 token at rate 10/sec
    assert elapsed >= 0.05


def test_refill():
    bucket = TokenBucket(rate=100.0, capacity=10.0)
    bucket.acquire(10.0)  # drain
    time.sleep(0.1)  # wait for ~10 tokens to refill
    start = time.monotonic()
    bucket.acquire(5.0)  # should be available
    elapsed = time.monotonic() - start
    assert elapsed < 0.1
