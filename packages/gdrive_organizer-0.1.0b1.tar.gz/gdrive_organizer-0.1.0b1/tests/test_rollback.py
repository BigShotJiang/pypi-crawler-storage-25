"""Tests for rollback correctness — TRASH→UNTRASH, CREATE_FOLDER→TRASH, reverse order."""

from __future__ import annotations

import json

import pytest

from gdrive_organizer.executor.runner import PlanRunner
from gdrive_organizer.models import OperationType, PlanOperation


class TestBuildReverseOperations:
    """Test _build_reverse_operations produces correct reversal semantics."""

    def _make_runner(self, tmp_path):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        return PlanRunner(MagicMock(), config)

    def test_trash_reversed_to_untrash(self, tmp_path):
        """TRASH operations must produce UNTRASH (trashed=false), not RENAME."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "file1",
                    "type": "trash",
                    "before": {"name": "doc.txt", "path": "/docs/doc.txt"},
                    "after": {"name": "doc.txt", "path": "/docs/doc.txt"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.UNTRASH
        assert ops[0].file_id == "file1"
        assert ops[0].reason == "rollback: restore from trash"

    def test_create_folder_reversed_to_trash_with_real_id(self, tmp_path):
        """CREATE_FOLDER must produce TRASH targeting the real Drive ID."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "id_mapping": {"__new_folder_0__": "real_drive_id_abc"},
            "operations": [
                {
                    "fileId": "__new_folder_0__",
                    "type": "create_folder",
                    "realDriveId": "real_drive_id_abc",
                    "before": {},
                    "after": {"name": "보관함", "path": "보관함"},
                    "status": "success",
                }
            ],
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.TRASH
        assert ops[0].file_id == "real_drive_id_abc"  # real ID, not placeholder
        assert "remove created folder" in ops[0].reason

    def test_create_folder_without_real_id_skipped_with_warning(self, tmp_path):
        """CREATE_FOLDER without a real Drive ID cannot be rolled back."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "__new_folder_0__",
                    "type": "create_folder",
                    "before": {},
                    "after": {"name": "orphan"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 0  # Cannot rollback without real ID

    def test_create_folder_uses_id_mapping_fallback(self, tmp_path):
        """If realDriveId is missing but id_mapping has the entry, use that."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "id_mapping": {"__new_folder_0__": "from_mapping_id"},
            "operations": [
                {
                    "fileId": "__new_folder_0__",
                    "type": "create_folder",
                    "before": {},
                    "after": {"name": "test"},
                    "status": "success",
                }
            ],
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].file_id == "from_mapping_id"

    def test_move_reversed_correctly(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "file1",
                    "type": "move",
                    "before": {"name": "doc.txt", "path": "/old/doc.txt", "parent_id": "old_parent"},
                    "after": {"name": "doc.txt", "path": "/new/doc.txt", "parent_id": "new_parent"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.MOVE
        assert ops[0].new_parent_id == "old_parent"
        assert ops[0].current_parent_id == "new_parent"

    def test_failed_operations_skipped(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {"fileId": "f1", "type": "move", "before": {}, "after": {}, "status": "failed"},
                {"fileId": "f2", "type": "trash", "before": {}, "after": {}, "status": "success"},
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].file_id == "f2"

    def test_reverse_order_is_preserved(self, tmp_path):
        """Operations should be reversed in reverse order of execution."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {"fileId": "f1", "type": "trash", "before": {}, "after": {"name": "first"}, "status": "success"},
                {"fileId": "f2", "type": "trash", "before": {}, "after": {"name": "second"}, "status": "success"},
                {"fileId": "f3", "type": "trash", "before": {}, "after": {"name": "third"}, "status": "success"},
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        # Should be reversed: f3, f2, f1
        assert [o.file_id for o in ops] == ["f3", "f2", "f1"]

    def test_shortcut_reversed_to_trash(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "shortcut_real_id",
                    "type": "create_shortcut",
                    "before": {},
                    "after": {"name": "link.txt"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.TRASH

    def test_description_reversed_to_previous(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "f1",
                    "type": "update_description",
                    "before": {"name": "doc.txt", "description": "old desc"},
                    "after": {"name": "doc.txt", "description": "new desc"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.UPDATE_DESCRIPTION
        assert ops[0].new_description == "old desc"


class TestUntrashBuildRequest:
    """Test that UNTRASH produces the correct Drive API request."""

    def test_untrash_sets_trashed_false(self):
        from unittest.mock import MagicMock

        from gdrive_organizer.executor.batch import build_request

        service = MagicMock()
        op = PlanOperation(
            file_id="file1",
            current_name="doc.txt",
            current_path="/trash/doc.txt",
            operation=OperationType.UNTRASH,
            reason="rollback: restore from trash",
        )
        build_request(service, op)
        # Verify the update call includes trashed=False
        call_kwargs = service.files().update.call_args
        assert call_kwargs is not None
        body = call_kwargs.kwargs.get("body", call_kwargs[1].get("body", {}))
        assert body.get("trashed") is False


class TestRollbackLogContainsIdMapping:
    """Verify that _save_rollback_log persists id_mapping for folder rollback."""

    def test_log_contains_id_mapping_and_real_drive_ids(self, tmp_path):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        runner = PlanRunner(MagicMock(), config)

        from gdrive_organizer.models import ExecutionPlan

        plan = ExecutionPlan(
            created_at="2026-04-11T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="__new_folder_0__",
                    current_name="test",
                    current_path="",
                    operation=OperationType.CREATE_FOLDER,
                    new_path="test",
                ),
            ],
        )
        results = {"__new_folder_0__": {"status": "success"}}
        before_states = {"__new_folder_0__": {}}
        id_mapping = {"__new_folder_0__": "real_id_123"}

        log_path = runner._save_rollback_log(plan, results, before_states, id_mapping)
        log = json.loads(log_path.read_text())

        assert log["id_mapping"] == {"__new_folder_0__": "real_id_123"}
        assert log["operations"][0]["realDriveId"] == "real_id_123"
