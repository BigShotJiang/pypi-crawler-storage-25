"""Tests for utils modules (logger and retry)."""

import logging
from unittest.mock import MagicMock, patch

import pytest
from googleapiclient.errors import HttpError

from gdrive_organizer.utils.logger import get_logger, setup_logger
from gdrive_organizer.utils.retry import _is_retryable, with_retry


class TestLogger:
    def test_setup_logger_returns_logger(self):
        logger = setup_logger("test_logger_1", "DEBUG")
        assert isinstance(logger, logging.Logger)
        assert logger.level == logging.DEBUG

    def test_setup_logger_with_file(self, tmp_path):
        logger = setup_logger("test_logger_2", "INFO", log_dir=tmp_path)
        logger.info("test message")
        log_files = list(tmp_path.glob("*.log"))
        assert len(log_files) == 1

    def test_get_logger(self):
        child = get_logger("scanner")
        assert child.name == "gdrive_organizer.scanner"


def _make_http_error(status: int, reason: str = "") -> HttpError:
    resp = MagicMock()
    resp.status = status
    content = b'{"error": {"errors": [{"reason": "' + reason.encode() + b'"}]}}'
    return HttpError(resp, content)


class TestRetry:
    def test_retryable_429(self):
        error = _make_http_error(429)
        assert _is_retryable(error) is True

    def test_retryable_500(self):
        error = _make_http_error(500)
        assert _is_retryable(error) is True

    def test_retryable_503(self):
        error = _make_http_error(503)
        assert _is_retryable(error) is True

    def test_not_retryable_400(self):
        error = _make_http_error(400)
        assert _is_retryable(error) is False

    def test_not_retryable_404(self):
        error = _make_http_error(404)
        assert _is_retryable(error) is False

    def test_403_rate_limit_is_retryable(self):
        error = _make_http_error(403, "rateLimitExceeded")
        # error_details may not parse from raw bytes the same way,
        # so we mock it
        error.error_details = [{"reason": "rateLimitExceeded"}]
        assert _is_retryable(error) is True

    def test_403_permission_denied_not_retryable(self):
        error = _make_http_error(403, "forbidden")
        error.error_details = [{"reason": "forbidden"}]
        assert _is_retryable(error) is False

    @patch("gdrive_organizer.utils.retry.time.sleep")
    def test_with_retry_succeeds_after_failure(self, mock_sleep):
        call_count = 0

        @with_retry(max_retries=3, max_delay=1.0)
        def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                error = _make_http_error(503)
                raise error
            return "success"

        result = flaky()
        assert result == "success"
        assert call_count == 3
        assert mock_sleep.call_count == 2

    def test_with_retry_raises_non_retryable(self):
        @with_retry(max_retries=3)
        def fail():
            raise _make_http_error(404)

        with pytest.raises(HttpError):
            fail()
