"""Tests for xAI Grok API key management."""

from unittest.mock import patch

from gdrive_organizer.ai.classifier import (
    delete_api_key,
    load_api_key,
    save_api_key,
)


def test_save_and_load_api_key():
    with patch("gdrive_organizer.ai.classifier.keyring") as mock_kr:
        save_api_key("xai-test-key-123")
        mock_kr.set_password.assert_called_once_with(
            "gdrive-organizer", "xai-api-key", "xai-test-key-123"
        )


def test_load_api_key():
    with patch("gdrive_organizer.ai.classifier.keyring") as mock_kr:
        mock_kr.get_password.return_value = "xai-test-key-123"
        result = load_api_key()
        assert result == "xai-test-key-123"


def test_load_api_key_missing():
    with patch("gdrive_organizer.ai.classifier.keyring") as mock_kr:
        mock_kr.get_password.return_value = None
        result = load_api_key()
        assert result is None


def test_delete_api_key():
    with patch("gdrive_organizer.ai.classifier.keyring") as mock_kr:
        delete_api_key()
        mock_kr.delete_password.assert_called_once()
