"""Tests for content extraction and truncation."""

from gdrive_organizer.scanner.content import truncate_text


def test_truncate_short_text():
    text = "This is a short text."
    result = truncate_text(text, head=300, tail=150)
    assert result == text


def test_truncate_long_text():
    head = "First sentence. Second sentence. Third sentence. "
    middle = "Middle content. " * 100
    tail = "Penultimate sentence. Last sentence."
    text = head + middle + tail
    result = truncate_text(text, head=60, tail=40)
    assert "[...중략...]" in result
    assert result.startswith("First sentence. Second sentence.")
    assert result.endswith("Last sentence.")


def test_truncate_preserves_sentence_boundary():
    text = "Hello world. " * 200
    result = truncate_text(text, head=30, tail=20)
    # Should not cut mid-word
    assert "[...중략...]" in result
    assert "Hello" in result


def test_truncate_no_sentence_boundary():
    text = "a" * 1000  # No sentence boundaries
    result = truncate_text(text, head=100, tail=50)
    assert "[...중략...]" in result
    assert len(result) < len(text)


def test_truncate_exact_boundary():
    text = "A" * 450  # Exactly head + tail
    result = truncate_text(text, head=300, tail=150)
    assert result == text  # No truncation needed


def test_truncate_empty():
    assert truncate_text("") == ""
    assert truncate_text("  ") == ""
