"""Tests for Changes API integration."""

from datetime import UTC, datetime

from gdrive_organizer.models import DriveFile, Snapshot
from gdrive_organizer.store.changelog import apply_changes


def _make_snapshot(files: list[DriveFile]) -> Snapshot:
    return Snapshot(
        scanned_at=datetime(2026, 1, 1, tzinfo=UTC),
        change_token="old_token",
        files=files,
    )


def test_apply_changes_add_file():
    snapshot = _make_snapshot([
        DriveFile(id="1", name="existing.txt", mime_type="text/plain"),
    ])
    changes = [
        {
            "fileId": "2",
            "file": {"id": "2", "name": "new.txt", "mimeType": "text/plain"},
        }
    ]
    updated = apply_changes(snapshot, changes)
    assert len(updated.files) == 2
    ids = {f.id for f in updated.files}
    assert "2" in ids


def test_apply_changes_remove_file():
    snapshot = _make_snapshot([
        DriveFile(id="1", name="keep.txt", mime_type="text/plain"),
        DriveFile(id="2", name="remove.txt", mime_type="text/plain"),
    ])
    changes = [{"fileId": "2", "removed": True}]
    updated = apply_changes(snapshot, changes)
    assert len(updated.files) == 1
    assert updated.files[0].id == "1"


def test_apply_changes_modify_file():
    snapshot = _make_snapshot([
        DriveFile(id="1", name="old_name.txt", mime_type="text/plain"),
    ])
    changes = [
        {
            "fileId": "1",
            "file": {"id": "1", "name": "new_name.txt", "mimeType": "text/plain"},
        }
    ]
    updated = apply_changes(snapshot, changes)
    assert updated.files[0].name == "new_name.txt"


def test_apply_changes_trashed_file():
    snapshot = _make_snapshot([
        DriveFile(id="1", name="will_trash.txt", mime_type="text/plain"),
    ])
    changes = [
        {
            "fileId": "1",
            "file": {"id": "1", "name": "will_trash.txt", "mimeType": "text/plain", "trashed": True},
        }
    ]
    updated = apply_changes(snapshot, changes)
    assert len(updated.files) == 0


def test_apply_changes_empty():
    snapshot = _make_snapshot([
        DriveFile(id="1", name="unchanged.txt", mime_type="text/plain"),
    ])
    updated = apply_changes(snapshot, [])
    assert len(updated.files) == 1
