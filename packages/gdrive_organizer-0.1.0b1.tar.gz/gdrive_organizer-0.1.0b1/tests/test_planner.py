"""Tests for plan generation."""

from datetime import UTC, datetime

from gdrive_organizer.ai.planner import (
    _resolve_time_path,
    _response_to_operations,
    detect_conflicts,
)
from gdrive_organizer.models import (
    DriveFile,
    LLMResponseItem,
    OperationType,
    PlanOperation,
)


def _make_file(fid: str, name: str, path: str = "", modified: str | None = None) -> DriveFile:
    return DriveFile(
        id=fid,
        name=name,
        mime_type="text/plain",
        path=path or f"root/{name}",
        parents=["root_folder"],
        modified_time=modified or datetime(2026, 4, 8, tzinfo=UTC),
    )


def test_resolve_time_path():
    f = _make_file("1", "test.txt", modified=datetime(2026, 4, 8, tzinfo=UTC))
    assert _resolve_time_path(f) == "보관함/2026/04"


def test_resolve_time_path_no_date():
    f = DriveFile(id="1", name="test.txt", mime_type="text/plain")
    assert _resolve_time_path(f) == "보관함/미분류"


def test_response_to_operations_move():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
    ops = _response_to_operations(items, files, set())
    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert len(move_ops) == 1
    assert move_ops[0].new_path == "보관함/2026/04/report.txt"


def test_response_to_operations_shortcut():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(
        file_id="1",
        move_to="보관함/2026/04",
        shortcuts=["태그/AI"],
    )]
    ops = _response_to_operations(items, files, set())
    shortcut_ops = [op for op in ops if op.operation == OperationType.CREATE_SHORTCUT]
    assert len(shortcut_ops) == 1
    assert shortcut_ops[0].shortcut_target_id == "1"


def test_response_to_operations_description():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(
        file_id="1",
        move_to="보관함/2026/04",
        new_description="AI 관련 리서치 문서",
    )]
    ops = _response_to_operations(items, files, set())
    desc_ops = [op for op in ops if op.operation == OperationType.UPDATE_DESCRIPTION]
    assert len(desc_ops) == 1
    assert desc_ops[0].new_description == "AI 관련 리서치 문서"


def test_response_to_operations_creates_folders():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04", shortcuts=["태그/AI"])]
    ops = _response_to_operations(items, files, set())
    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    assert len(folder_ops) >= 2  # 보관함/2026/04 and 태그/AI


def test_response_skips_existing_folders():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
    # Mark 보관함/2026/04 as already existing
    ops = _response_to_operations(items, files, {"보관함/2026/04"})
    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    # Should NOT create 보관함/2026/04 since it exists
    created_paths = {op.new_path for op in folder_ops}
    assert "보관함/2026/04" not in created_paths


def test_detect_conflicts():
    ops = [
        PlanOperation(
            file_id="1", current_name="a.txt", current_path="root/a.txt",
            operation=OperationType.MOVE, new_name="report.txt", new_path="보관함/report.txt",
        ),
        PlanOperation(
            file_id="2", current_name="b.txt", current_path="root/b.txt",
            operation=OperationType.MOVE, new_name="report.txt", new_path="보관함/report.txt",
        ),
    ]
    conflicts = detect_conflicts(ops)
    assert len(conflicts) == 1


def test_detect_no_conflicts():
    ops = [
        PlanOperation(
            file_id="1", current_name="a.txt", current_path="root/a.txt",
            operation=OperationType.MOVE, new_path="보관함/2026/04/a.txt",
        ),
        PlanOperation(
            file_id="2", current_name="b.txt", current_path="root/b.txt",
            operation=OperationType.MOVE, new_path="보관함/2026/04/b.txt",
        ),
    ]
    conflicts = detect_conflicts(ops)
    assert len(conflicts) == 0
