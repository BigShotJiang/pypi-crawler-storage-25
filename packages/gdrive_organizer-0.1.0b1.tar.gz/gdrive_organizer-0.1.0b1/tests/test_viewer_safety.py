"""Tests for viewer safety gates — session token, confirmation barrier, empty state."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from gdrive_organizer.config import Config
from gdrive_organizer.viewer.app import create_app


# config fixture provided by conftest.py

@pytest.fixture
def app(config):
    return create_app(config)


@pytest.fixture
def client(app):
    return TestClient(app)


# --- Session Token ---


class TestSessionToken:
    def test_index_sets_session_cookie(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert "drivecore_session" in resp.cookies

    def test_plan_page_also_sets_session_cookie(self, client):
        """Cookie must be set on all pages, not just /."""
        resp = client.get("/plan")
        assert resp.status_code == 200
        assert "drivecore_session" in resp.cookies

    def test_approve_works_from_plan_page_cookie(self, client, config):
        """User can go directly to /plan and approve without visiting / first."""
        plans_dir = config.data_dir / "plans"
        plan_data = {"operations": [{"file_id": "f1", "operation": "move"}]}
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(
            json.dumps(plan_data)
        )
        cookies = client.get("/plan").cookies
        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "approved"

    def test_approve_without_session_returns_403(self, client):
        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": [], "confirmed": True},
        )
        assert resp.status_code == 403

    def test_approve_with_valid_session_works(self, client, config):
        # First get the cookie
        index_resp = client.get("/")
        cookies = index_resp.cookies

        # Create a plan file for the endpoint to find
        plans_dir = config.data_dir / "plans"
        plan_data = {
            "operations": [
                {"file_id": "f1", "operation": "move", "current_name": "a.txt"},
            ],
        }
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(
            json.dumps(plan_data)
        )

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "approved"

    def test_apikey_set_without_session_returns_403(self, client):
        resp = client.post(
            "/api/apikey/set",
            json={"api_key": "test-key"},
        )
        assert resp.status_code == 403

    def test_apikey_delete_without_session_returns_403(self, client):
        resp = client.delete("/api/apikey")
        assert resp.status_code == 403


# --- Confirmation Barrier ---


class TestConfirmationBarrier:
    def _setup_plan(self, config, operations):
        plans_dir = config.data_dir / "plans"
        plan_data = {"operations": operations}
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(
            json.dumps(plan_data)
        )

    def test_approve_without_confirmed_returns_summary(self, client, config):
        self._setup_plan(config, [
            {"file_id": "f1", "operation": "move", "current_name": "a.txt"},
            {"file_id": "f2", "operation": "trash", "current_name": "b.txt"},
        ])
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1", "f2"], "confirmed": False},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "confirmation_required"
        assert data["trash_count"] == 1
        assert data["operations"] == 2
        assert "summary" in data

    def test_approve_with_confirmed_true_proceeds(self, client, config):
        self._setup_plan(config, [
            {"file_id": "f1", "operation": "move", "current_name": "a.txt"},
        ])
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "approved"
        assert data["operations"] == 1

    def test_trash_ops_require_trash_confirmed_flag(self, client, config):
        """Server enforces separate trash_confirmed for plans with TRASH ops."""
        self._setup_plan(config, [
            {"file_id": "f1", "operation": "trash", "current_name": "junk.txt"},
        ])
        cookies = client.get("/").cookies

        # confirmed=True but no trash_confirmed → server rejects
        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "trash_confirmation_required"

    def test_trash_ops_pass_with_both_flags(self, client, config):
        """TRASH ops pass when both confirmed and trash_confirmed are set."""
        self._setup_plan(config, [
            {"file_id": "f1", "operation": "trash", "current_name": "junk.txt"},
        ])
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True, "trash_confirmed": True},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "approved"


# --- Empty State ---


class TestEmptyState:
    """All read endpoints must return a clean empty response, never 500."""

    @pytest.mark.parametrize(
        "path",
        [
            "/api/stats",
            "/api/tree",
            "/api/files",
            "/api/permissions",
            "/api/duplicates",
            "/api/file/nonexistent",
            "/api/shared-with-me",
            "/api/shared-by-me",
            "/api/drive-info",
        ],
    )
    def test_read_endpoint_returns_empty_on_no_snapshot(self, client, path):
        resp = client.get(path)
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("empty") is True
        assert "message" in data

    def test_plan_returns_none_when_no_plan(self, client):
        resp = client.get("/api/plan")
        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] is None


class TestRateLimiting:
    def test_rapid_mutation_calls_get_429(self, client, config):
        """Flooding /api/plan/approve should eventually return 429."""
        plans_dir = config.data_dir / "plans"
        plan_data = {"operations": [{"file_id": "f1", "operation": "move"}]}
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(
            json.dumps(plan_data)
        )
        cookies = client.get("/").cookies

        # Send many rapid requests — should hit 429 within 15 calls
        statuses = []
        for _ in range(15):
            resp = client.post(
                "/api/plan/approve",
                json={"approved_ids": ["f1"], "confirmed": True},
                cookies=cookies,
            )
            statuses.append(resp.status_code)

        assert 429 in statuses, f"Expected 429 in statuses but got: {set(statuses)}"


# --- Page Routes Smoke Test ---


class TestPageRoutes:
    @pytest.mark.parametrize(
        "path",
        ["/", "/explorer", "/plan", "/permissions", "/duplicates", "/settings"],
    )
    def test_pages_return_200(self, client, path):
        resp = client.get(path)
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
