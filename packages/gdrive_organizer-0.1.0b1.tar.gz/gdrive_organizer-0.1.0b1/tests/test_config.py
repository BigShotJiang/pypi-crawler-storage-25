"""Tests for config module."""

from pathlib import Path

from gdrive_organizer.config import Config, ensure_dirs, load_config, save_config


def test_default_values():
    config = Config()
    assert config.viewer_port == 8765
    assert config.scan_page_size == 1000
    assert config.batch_size == 100
    assert config.write_rate_limit == 3.0
    assert config.log_level == "INFO"


def test_derived_paths():
    config = Config(config_dir=Path("/tmp/test-gdrive"))
    assert config.credentials_path == Path("/tmp/test-gdrive/credentials.json")
    assert config.token_path == Path("/tmp/test-gdrive/token.json")


def test_env_var_override(monkeypatch):
    monkeypatch.setenv("GDRIVE_VIEWER_PORT", "9000")
    config = Config()
    assert config.viewer_port == 9000


def test_save_load_roundtrip(tmp_path):
    original = Config(config_dir=tmp_path, data_dir=tmp_path / "data")
    save_config(original, tmp_path / "config.json")
    loaded = load_config(tmp_path)
    assert loaded.viewer_port == original.viewer_port
    assert loaded.llm_model == original.llm_model
    assert loaded.batch_size == original.batch_size


def test_ensure_dirs(tmp_path):
    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    ensure_dirs(config)
    assert (tmp_path / "config").is_dir()
    assert (tmp_path / "data" / "snapshots").is_dir()
    assert (tmp_path / "data" / "plans").is_dir()
    assert (tmp_path / "data" / "logs").is_dir()
