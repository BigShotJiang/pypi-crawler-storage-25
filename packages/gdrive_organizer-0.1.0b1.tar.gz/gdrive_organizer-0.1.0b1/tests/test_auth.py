"""Tests for OAuth authentication module."""

import json
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from gdrive_organizer.auth.oauth import (
    _load_or_refresh_token,
    auto_detect_credentials,
    check_token_status,
    logout,
)
from gdrive_organizer.config import Config


@pytest.fixture
def config(tmp_path):
    return Config(config_dir=tmp_path, data_dir=tmp_path / "data")


def _make_token_data(*, expired: bool = False) -> dict:
    expiry = datetime.now(timezone.utc) + (
        timedelta(hours=-1) if expired else timedelta(hours=1)
    )
    return {
        "token": "fake-access-token",
        "refresh_token": "fake-refresh-token",
        "token_uri": "https://oauth2.googleapis.com/token",
        "client_id": "test-client-id",
        "client_secret": "test-secret",
        "scopes": ["https://www.googleapis.com/auth/drive"],
        "expiry": expiry.isoformat(),
    }


def test_load_token_missing(config):
    result = _load_or_refresh_token(config)
    assert result is None


def test_load_token_valid(config):
    token_data = _make_token_data(expired=False)
    config.token_path.write_text(json.dumps(token_data))
    with patch("gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info") as mock_creds:
        mock_creds.return_value.valid = True
        result = _load_or_refresh_token(config)
        assert result is not None


def test_load_token_expired_refresh(config):
    token_data = _make_token_data(expired=True)
    config.token_path.write_text(json.dumps(token_data))
    with patch("gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info") as mock_creds:
        creds_instance = MagicMock()
        creds_instance.valid = False
        creds_instance.expired = True
        creds_instance.refresh_token = "fake-refresh"
        creds_instance.to_json.return_value = '{"token": "refreshed"}'
        mock_creds.return_value = creds_instance
        with patch("gdrive_organizer.auth.oauth.Request"):
            result = _load_or_refresh_token(config)
            creds_instance.refresh.assert_called_once()
            assert result is creds_instance


def test_check_token_status_no_token(config):
    status = check_token_status(config)
    assert status["valid"] is False
    assert status["email"] is None


def test_check_token_status_with_token(config):
    token_data = _make_token_data(expired=False)
    config.token_path.write_text(json.dumps(token_data))
    with patch("gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info") as mock_creds:
        mock_creds.return_value.valid = True
        mock_creds.return_value.expired = False
        mock_creds.return_value.expiry = datetime.now(timezone.utc) + timedelta(hours=1)
        status = check_token_status(config)
        assert status["valid"] is True


def test_logout_removes_token(config):
    config.token_path.write_text("{}")
    assert logout(config) is True
    assert not config.token_path.exists()


def test_logout_no_token(config):
    assert logout(config) is False


def test_auto_detect_credentials_found(tmp_path):
    # Simulate Downloads folder with GCP credentials file
    downloads = tmp_path / "Downloads"
    downloads.mkdir()
    creds_file = downloads / "client_secret_12345.apps.googleusercontent.com.json"
    creds_file.write_text('{"installed": {"client_id": "test"}}')

    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")

    with patch("gdrive_organizer.auth.oauth._get_download_dirs", return_value=[downloads]):
        result = auto_detect_credentials(config)

    assert result is True
    assert config.credentials_path.exists()
    assert not creds_file.exists()  # moved, not copied


def test_auto_detect_credentials_not_found(tmp_path):
    downloads = tmp_path / "Downloads"
    downloads.mkdir()  # empty

    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")

    with patch("gdrive_organizer.auth.oauth._get_download_dirs", return_value=[downloads]):
        result = auto_detect_credentials(config)

    assert result is False


def test_auto_detect_picks_newest(tmp_path):
    import time

    downloads = tmp_path / "Downloads"
    downloads.mkdir()

    old_file = downloads / "client_secret_old.apps.googleusercontent.com.json"
    old_file.write_text('{"installed": {"client_id": "old"}}')
    time.sleep(0.05)
    new_file = downloads / "client_secret_new.apps.googleusercontent.com.json"
    new_file.write_text('{"installed": {"client_id": "new"}}')

    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")

    with patch("gdrive_organizer.auth.oauth._get_download_dirs", return_value=[downloads]):
        auto_detect_credentials(config)

    content = json.loads(config.credentials_path.read_text())
    assert content["installed"]["client_id"] == "new"
