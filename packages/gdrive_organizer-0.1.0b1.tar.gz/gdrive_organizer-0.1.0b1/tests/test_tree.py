"""Tests for tree reconstruction."""

from gdrive_organizer.scanner.tree import (
    build_tree,
    compute_paths,
    filter_subtree,
    resolve_shortcuts,
    tree_to_rich,
)

SAMPLE_FILES = [
    {"id": "root1", "name": "Root Folder", "mimeType": "application/vnd.google-apps.folder"},
    {
        "id": "sub1",
        "name": "Sub Folder",
        "mimeType": "application/vnd.google-apps.folder",
        "parents": ["root1"],
    },
    {"id": "f1", "name": "doc.txt", "mimeType": "text/plain", "parents": ["root1"]},
    {"id": "f2", "name": "image.png", "mimeType": "image/png", "parents": ["sub1"]},
    {"id": "orphan1", "name": "orphan.pdf", "mimeType": "application/pdf", "parents": ["missing"]},
    {
        "id": "sc1",
        "name": "Link",
        "mimeType": "application/vnd.google-apps.shortcut",
        "parents": ["root1"],
        "shortcutDetails": {"targetId": "f2", "targetMimeType": "image/png"},
    },
]


def test_build_tree_structure():
    node_map, roots = build_tree(SAMPLE_FILES)
    assert len(node_map) == 6
    # root1 and orphan1 should be roots
    root_ids = {r.file_id for r in roots}
    assert "root1" in root_ids
    assert "orphan1" in root_ids


def test_build_tree_children():
    node_map, _ = build_tree(SAMPLE_FILES)
    root = node_map["root1"]
    child_ids = {c.file_id for c in root.children}
    assert "sub1" in child_ids
    assert "f1" in child_ids


def test_compute_paths():
    node_map, roots = build_tree(SAMPLE_FILES)
    compute_paths(roots)
    assert node_map["root1"].path == "Root Folder"
    assert node_map["sub1"].path == "Root Folder/Sub Folder"
    assert node_map["f2"].path == "Root Folder/Sub Folder/image.png"
    assert node_map["orphan1"].path == "orphan.pdf"


def test_filter_subtree():
    node_map, _ = build_tree(SAMPLE_FILES)
    subtree = filter_subtree(node_map, "sub1")
    assert len(subtree) == 1
    assert subtree[0].file_id == "sub1"


def test_filter_subtree_missing():
    node_map, _ = build_tree(SAMPLE_FILES)
    assert filter_subtree(node_map, "nonexistent") == []


def test_resolve_shortcuts():
    node_map, _ = build_tree(SAMPLE_FILES)
    resolve_shortcuts(node_map, SAMPLE_FILES)
    sc = node_map["sc1"]
    assert sc.raw["target_id"] == "f2"
    assert sc.raw["target_mime_type"] == "image/png"


def test_tree_to_rich():
    _, roots = build_tree(SAMPLE_FILES)
    rich_tree = tree_to_rich(roots)
    assert rich_tree.label == "[bold]My Drive[/bold]"


def test_tree_to_rich_max_depth():
    _, roots = build_tree(SAMPLE_FILES)
    rich_tree = tree_to_rich(roots, max_depth=1)
    # Should have root-level children but no deeper
    assert len(rich_tree.children) > 0


def test_folders_sorted_first():
    node_map, _ = build_tree(SAMPLE_FILES)
    root = node_map["root1"]
    # Folders should come before files
    assert root.children[0].is_folder  # Sub Folder first
