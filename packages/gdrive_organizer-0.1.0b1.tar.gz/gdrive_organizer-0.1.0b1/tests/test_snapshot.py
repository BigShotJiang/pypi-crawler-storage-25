"""Tests for snapshot storage."""

from datetime import UTC, datetime

from gdrive_organizer.config import Config
from gdrive_organizer.models import DriveFile, Snapshot, SnapshotStats
from gdrive_organizer.store.snapshot import (
    diff_snapshots,
    list_snapshots,
    load_snapshot,
    save_snapshot,
)

SAMPLE_FILES = [
    {"id": "1", "name": "doc.txt", "mimeType": "text/plain", "size": "1024"},
    {"id": "2", "name": "Photos", "mimeType": "application/vnd.google-apps.folder"},
    {"id": "3", "name": "pic.jpg", "mimeType": "image/jpeg", "parents": ["2"], "size": "2048"},
]


def test_save_and_load_roundtrip(tmp_path):
    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    filepath = save_snapshot(SAMPLE_FILES, "token123", config)
    assert filepath.exists()

    loaded = load_snapshot(filepath)
    assert len(loaded.files) == 3
    assert loaded.change_token == "token123"
    assert loaded.stats.total_files == 2
    assert loaded.stats.total_folders == 1


def test_latest_symlink(tmp_path):
    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    save_snapshot(SAMPLE_FILES, None, config)

    latest = tmp_path / "data" / "snapshots" / "latest.json.gz"
    assert latest.is_symlink()

    loaded = load_snapshot(config=config)
    assert len(loaded.files) == 3


def test_list_snapshots(tmp_path):
    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    save_snapshot(SAMPLE_FILES, None, config)
    snapshots = list_snapshots(config)
    assert len(snapshots) == 1


def test_diff_snapshots():
    old = Snapshot(
        scanned_at=datetime(2026, 1, 1, tzinfo=UTC),
        files=[
            DriveFile(id="1", name="old.txt", mime_type="text/plain"),
            DriveFile(id="2", name="removed.txt", mime_type="text/plain"),
        ],
    )
    new = Snapshot(
        scanned_at=datetime(2026, 1, 2, tzinfo=UTC),
        files=[
            DriveFile(id="1", name="renamed.txt", mime_type="text/plain"),
            DriveFile(id="3", name="added.txt", mime_type="text/plain"),
        ],
    )
    diff = diff_snapshots(old, new)
    assert len(diff["added"]) == 1
    assert diff["added"][0].id == "3"
    assert len(diff["removed"]) == 1
    assert diff["removed"][0].id == "2"
    assert len(diff["modified"]) == 1
    assert diff["modified"][0].name == "renamed.txt"


def test_paths_preserved_in_snapshot(tmp_path):
    from gdrive_organizer.scanner.tree import build_tree, compute_paths, inject_paths_into_raw

    files = [
        {"id": "root", "name": "Root", "mimeType": "application/vnd.google-apps.folder"},
        {"id": "f1", "name": "doc.txt", "mimeType": "text/plain", "parents": ["root"]},
    ]
    node_map, roots = build_tree(files)
    compute_paths(roots)
    inject_paths_into_raw(node_map)

    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    save_snapshot(files, None, config)
    loaded = load_snapshot(config=config)
    file_by_id = {f.id: f for f in loaded.files}
    assert file_by_id["f1"].path == "Root/doc.txt"
    assert file_by_id["root"].path == "Root"


def test_save_snapshot_stats(tmp_path):
    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    save_snapshot(SAMPLE_FILES, None, config, duration_ms=500)
    loaded = load_snapshot(config=config)
    assert loaded.stats.total_size == 3072  # 1024 + 2048
    assert loaded.stats.scan_duration_ms == 500
