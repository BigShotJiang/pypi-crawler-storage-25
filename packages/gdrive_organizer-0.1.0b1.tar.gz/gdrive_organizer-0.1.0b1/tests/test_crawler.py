"""Tests for the flat crawler."""

from unittest.mock import MagicMock

from gdrive_organizer.scanner.crawler import get_start_page_token, scan_all_files


def _mock_service(pages: list[dict]):
    """Create a mock Drive service that returns paginated results."""
    service = MagicMock()
    files_resource = MagicMock()
    service.files.return_value = files_resource

    # Chain list → execute calls for each page
    responses = []
    for i, page in enumerate(pages):
        resp = {"files": page}
        if i < len(pages) - 1:
            resp["nextPageToken"] = f"token_{i + 1}"
        responses.append(resp)

    list_mock = MagicMock()
    list_mock.execute.return_value = responses[0]
    files_resource.list.return_value = list_mock

    # list_next: return None when there are no more pages
    call_count = {"n": 0}

    def list_next_fn(prev_request, prev_response):
        call_count["n"] += 1
        if call_count["n"] >= len(responses):
            return None
        next_mock = MagicMock()
        next_mock.execute.return_value = responses[call_count["n"]]
        return next_mock

    files_resource.list_next.side_effect = list_next_fn
    return service


def test_scan_single_page():
    files = [{"id": "1", "name": "a.txt"}, {"id": "2", "name": "b.txt"}]
    service = _mock_service([files])
    result = scan_all_files(service)
    assert len(result) == 2
    assert result[0]["name"] == "a.txt"


def test_scan_multiple_pages():
    page1 = [{"id": "1", "name": "a.txt"}]
    page2 = [{"id": "2", "name": "b.txt"}, {"id": "3", "name": "c.txt"}]
    service = _mock_service([page1, page2])
    result = scan_all_files(service)
    assert len(result) == 3


def test_scan_empty():
    service = _mock_service([[]])
    result = scan_all_files(service)
    assert result == []


def test_get_start_page_token():
    service = MagicMock()
    service.changes.return_value.getStartPageToken.return_value.execute.return_value = {
        "startPageToken": "12345"
    }
    token = get_start_page_token(service)
    assert token == "12345"
