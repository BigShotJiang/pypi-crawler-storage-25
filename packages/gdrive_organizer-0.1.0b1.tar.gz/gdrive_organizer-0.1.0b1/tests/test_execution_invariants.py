"""Tests for sprint 2 business logic invariants: batch chunking, folder ordering,
placeholder resolution, shortcut validation, config batch_size clamping."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from gdrive_organizer.config import Config
from gdrive_organizer.executor.batch import GOOGLE_BATCH_LIMIT, execute_batch
from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation


@pytest.fixture
def runner_config(tmp_path):
    """Create a real Config with tmp_path for rollback log writing."""
    return Config(data_dir=tmp_path, config_dir=tmp_path / "config")


@pytest.fixture
def runner(runner_config):
    """Create a PlanRunner with mocked service."""
    from gdrive_organizer.executor.runner import PlanRunner

    service = MagicMock()
    return PlanRunner(service, runner_config)


# --- A1: Batch limit enforcement ---


class TestBatchChunking:
    def test_google_batch_limit_is_100(self):
        assert GOOGLE_BATCH_LIMIT == 100

    def test_batch_chunks_large_list(self):
        """150 operations should produce 2 batch.execute() calls (100 + 50)."""
        service = MagicMock()
        batch_mock = MagicMock()
        service.new_batch_http_request.return_value = batch_mock
        service.files.return_value.update.return_value = MagicMock()

        ops = [
            PlanOperation(
                file_id=f"f{i}",
                current_name=f"file{i}.txt",
                current_path=f"/old/{i}",
                operation=OperationType.MOVE,
                new_parent_id="target_folder",
                current_parent_id="old_parent",
            )
            for i in range(150)
        ]

        execute_batch(service, ops, lambda *a: None)

        # 2 batches: 100 + 50
        assert batch_mock.execute.call_count == 2
        # First batch got 100 adds, second got 50
        assert batch_mock.add.call_count == 150

    def test_batch_exact_limit_is_single_batch(self):
        """Exactly 100 operations should be one batch."""
        service = MagicMock()
        batch_mock = MagicMock()
        service.new_batch_http_request.return_value = batch_mock
        service.files.return_value.update.return_value = MagicMock()

        ops = [
            PlanOperation(
                file_id=f"f{i}",
                current_name="x",
                current_path="/x",
                operation=OperationType.TRASH,
            )
            for i in range(100)
        ]

        execute_batch(service, ops, lambda *a: None)
        assert batch_mock.execute.call_count == 1

    def test_batch_small_list_single_batch(self):
        """5 operations should be one batch."""
        service = MagicMock()
        batch_mock = MagicMock()
        service.new_batch_http_request.return_value = batch_mock
        service.files.return_value.update.return_value = MagicMock()

        ops = [
            PlanOperation(
                file_id=f"f{i}",
                current_name="x",
                current_path="/x",
                operation=OperationType.TRASH,
            )
            for i in range(5)
        ]

        execute_batch(service, ops, lambda *a: None)
        assert batch_mock.execute.call_count == 1

    def test_empty_batch_no_execute(self):
        """Empty list should not call batch.execute."""
        service = MagicMock()
        execute_batch(service, [], lambda *a: None)
        service.new_batch_http_request.assert_not_called()


class TestConfigBatchSizeValidation:
    def test_valid_batch_size(self):
        config = Config(batch_size=50)
        assert config.batch_size == 50

    def test_batch_size_at_limit(self):
        config = Config(batch_size=100)
        assert config.batch_size == 100

    def test_batch_size_too_large_rejected(self):
        with pytest.raises(Exception, match="batch_size must be between 1 and 100"):
            Config(batch_size=200)

    def test_batch_size_zero_rejected(self):
        with pytest.raises(Exception, match="batch_size must be between 1 and 100"):
            Config(batch_size=0)


# --- A2: Folder creation ordering ---


class TestFolderOrdering:
    def _make_folder_op(self, path: str, pid: str, parent_pid: str | None = None):
        return PlanOperation(
            file_id=pid,
            current_name=path.rsplit("/", 1)[-1],
            current_path="",
            operation=OperationType.CREATE_FOLDER,
            new_parent_id=parent_pid,
            new_path=path,
            reason=f"folder: {path}",
        )

    def test_folder_ops_sorted_by_depth(self, runner):
        """Runner should sort folder_ops so shallower paths come first."""
        # Create folders in wrong order: deep before shallow
        ops = [
            self._make_folder_op("보관함/2026/04", "__new_folder_2__", "__new_folder_1__"),
            self._make_folder_op("보관함", "__new_folder_0__", None),
            self._make_folder_op("보관함/2026", "__new_folder_1__", "__new_folder_0__"),
        ]
        plan = ExecutionPlan(created_at="2026-04-11T00:00:00Z", operations=ops)

        call_order = []

        def mock_create(svc, name, parent=None):
            call_order.append(name)
            return {"id": f"real_{name}"}

        with patch("gdrive_organizer.executor.runner.create_folder", side_effect=mock_create):
            runner.execute(plan, skip_freshness_check=True)

        assert call_order == ["보관함", "2026", "04"]


class TestPlaceholderResolution:
    def test_unresolved_placeholder_produces_error(self, runner):
        """If folder creation fails, MOVE ops referencing that placeholder should error."""
        folder_op = PlanOperation(
            file_id="__new_folder_0__", current_name="test_folder",
            current_path="", operation=OperationType.CREATE_FOLDER, new_path="test_folder",
        )
        move_op = PlanOperation(
            file_id="file1", current_name="doc.txt", current_path="/old/doc.txt",
            operation=OperationType.MOVE, new_parent_id="__new_folder_0__",
            current_parent_id="old_parent",
        )
        plan = ExecutionPlan(created_at="2026-04-11T00:00:00Z", operations=[folder_op, move_op])

        with patch("gdrive_organizer.executor.runner.create_folder", side_effect=Exception("API error")):
            with patch("gdrive_organizer.executor.runner.execute_batch"):
                result = runner.execute(plan, skip_freshness_check=True)

        error_ids = {e["file_id"] for e in result.errors}
        assert "__new_folder_0__" in error_ids
        assert "file1" in error_ids
        move_errors = [e for e in result.errors if e["file_id"] == "file1"]
        assert any("Unresolved placeholder" in e["error"] for e in move_errors)


class TestShortcutValidation:
    def test_shortcut_to_shortcut_rejected(self, runner):
        """Shortcut whose target is a synthetic shortcut ID should be rejected."""
        shortcut_op = PlanOperation(
            file_id="shortcut__abc__tag", current_name="test.txt",
            current_path="/test.txt", operation=OperationType.CREATE_SHORTCUT,
            shortcut_target_id="shortcut__xyz__other", shortcut_parent_id="real_folder_id",
        )
        plan = ExecutionPlan(created_at="2026-04-11T00:00:00Z", operations=[shortcut_op])

        result = runner.execute(plan, skip_freshness_check=True)
        assert result.failure_count >= 1
        assert any("shortcut chain" in e["error"].lower() for e in result.errors)

    def test_shortcut_with_unresolved_parent_rejected(self, runner):
        """Shortcut whose parent is still a placeholder should be rejected."""
        shortcut_op = PlanOperation(
            file_id="shortcut__abc__tag", current_name="test.txt",
            current_path="/test.txt", operation=OperationType.CREATE_SHORTCUT,
            shortcut_target_id="real_file_id", shortcut_parent_id="__new_folder_99__",
        )
        plan = ExecutionPlan(created_at="2026-04-11T00:00:00Z", operations=[shortcut_op])

        result = runner.execute(plan, skip_freshness_check=True)
        assert result.failure_count >= 1
        assert any("unresolved placeholder" in e["error"].lower() for e in result.errors)
