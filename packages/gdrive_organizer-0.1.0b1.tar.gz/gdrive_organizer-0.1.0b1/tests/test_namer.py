"""Tests for naming rule engine."""

from datetime import UTC, datetime

from gdrive_organizer.ai.namer import NamingRuleEngine
from gdrive_organizer.models import DriveFile


def _make_file(name: str, modified: datetime | None = None) -> DriveFile:
    return DriveFile(
        id="test",
        name=name,
        mime_type="text/plain",
        modified_time=modified or datetime(2026, 3, 15, tzinfo=UTC),
    )


def test_date_prefix_added():
    namer = NamingRuleEngine()
    f = _make_file("report.txt")
    result = namer.apply(f)
    assert result is not None
    assert result.startswith("2026-03-15_")


def test_date_prefix_not_duplicated():
    namer = NamingRuleEngine()
    f = _make_file("2026-03-15_report.txt")
    result = namer.apply(f)
    assert result is None  # No change needed


def test_special_chars_cleaned():
    namer = NamingRuleEngine()
    f = _make_file("bad?file*name|here.txt", modified=None)
    f.modified_time = None
    result = namer.apply(f)
    assert result is not None
    assert "?" not in result
    assert "*" not in result
    assert "|" not in result


def test_llm_suggestion_applied():
    namer = NamingRuleEngine()
    f = _make_file("messy file.txt")
    classification = {"suggested_name": "clean-report.txt"}
    result = namer.apply(f, classification)
    assert result is not None
    assert "clean-report" in result


def test_custom_rules():
    rules = [{"pattern": r"^draft_", "replacement": "", "scope": "name"}]
    namer = NamingRuleEngine(custom_rules=rules)
    f = _make_file("draft_report.txt")
    result = namer.apply(f)
    assert result is not None
    # custom rule removes "draft_" prefix, date prefix is added
    assert "draft" not in result or result.startswith("2026")


def test_no_change_needed():
    namer = NamingRuleEngine()
    f = _make_file("2026-03-15_clean-file.txt")
    result = namer.apply(f)
    assert result is None


def test_from_file(tmp_path):
    rules_file = tmp_path / "rules.json"
    rules_file.write_text('[{"pattern": "foo", "replacement": "bar", "scope": "name"}]')
    namer = NamingRuleEngine.from_file(rules_file)
    assert len(namer.custom_rules) == 1
