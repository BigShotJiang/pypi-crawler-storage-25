"""Shared test fixtures for gdrive-organizer test suite."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from gdrive_organizer.config import Config


@pytest.fixture
def config(tmp_path) -> Config:
    """Config backed by a temporary directory with all subdirs created."""
    cfg = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
    (tmp_path / "plans").mkdir(parents=True, exist_ok=True)
    (tmp_path / "snapshots").mkdir(parents=True, exist_ok=True)
    (tmp_path / "logs").mkdir(parents=True, exist_ok=True)
    return cfg


@pytest.fixture
def mock_drive_service() -> MagicMock:
    """A mock Google Drive service with standard endpoints stubbed."""
    service = MagicMock()
    # about().get().execute()
    service.about.return_value.get.return_value.execute.return_value = {
        "user": {"displayName": "Test User", "emailAddress": "test@example.com"},
        "storageQuota": {
            "limit": "15000000000",
            "usage": "5000000000",
            "usageInDrive": "4000000000",
            "usageInDriveTrash": "100000000",
        },
    }
    # changes().getStartPageToken().execute()
    service.changes.return_value.getStartPageToken.return_value.execute.return_value = {
        "startPageToken": "token_123",
    }
    # permissions().list().execute()
    service.permissions.return_value.list.return_value.execute.return_value = {
        "permissions": [],
    }
    # revisions().list().execute()
    service.revisions.return_value.list.return_value.execute.return_value = {
        "revisions": [],
    }
    return service


SAMPLE_RAW_FILES = [
    {
        "id": "root",
        "name": "My Drive",
        "mimeType": "application/vnd.google-apps.folder",
        "parents": [],
        "size": "0",
    },
    {
        "id": "folder1",
        "name": "Documents",
        "mimeType": "application/vnd.google-apps.folder",
        "parents": ["root"],
        "size": "0",
    },
    {
        "id": "file1",
        "name": "report.docx",
        "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "parents": ["folder1"],
        "size": "2048",
        "modifiedTime": "2026-03-15T10:00:00Z",
        "createdTime": "2026-03-01T08:00:00Z",
    },
    {
        "id": "file2",
        "name": "photo.jpg",
        "mimeType": "image/jpeg",
        "parents": ["root"],
        "size": "512000",
        "modifiedTime": "2026-04-01T14:00:00Z",
    },
    {
        "id": "file3",
        "name": "notes.txt",
        "mimeType": "text/plain",
        "parents": ["folder1"],
        "size": "1024",
        "modifiedTime": "2026-04-10T09:00:00Z",
    },
]


@pytest.fixture
def sample_raw_files() -> list[dict]:
    """A small set of representative raw Drive file dicts."""
    return [dict(f) for f in SAMPLE_RAW_FILES]


@pytest.fixture
def saved_snapshot(config, sample_raw_files) -> Path:
    """Save a snapshot from sample files and return the path."""
    from gdrive_organizer.store.snapshot import save_snapshot

    return save_snapshot(sample_raw_files, "change_token_abc", config)
