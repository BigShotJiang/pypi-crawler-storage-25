"""Tests for the extracted scan service (scanner/service.py).

This is the CLI maintainability starter — proving the extracted orchestration
seam is testable independently of Typer command wiring.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from gdrive_organizer.config import Config
from gdrive_organizer.scanner.service import ScanResult, run_full_scan


@pytest.fixture
def config(tmp_path) -> Config:
    return Config(data_dir=tmp_path, config_dir=tmp_path / "config")


@pytest.fixture
def mock_service():
    """Create a mock Drive service that returns minimal valid data."""
    service = MagicMock()
    # Mock about().get().execute() for fetch_drive_info
    service.about.return_value.get.return_value.execute.return_value = {
        "user": {"displayName": "Test", "emailAddress": "test@test.com"},
        "storageQuota": {"limit": "1000", "usage": "500", "usageInDrive": "400", "usageInDriveTrash": "100"},
    }
    # Mock changes().getStartPageToken().execute()
    service.changes.return_value.getStartPageToken.return_value.execute.return_value = {
        "startPageToken": "token123",
    }
    # Mock permissions list
    service.permissions.return_value.list.return_value.execute.return_value = {
        "permissions": [],
    }
    # Mock revisions list
    service.revisions.return_value.list.return_value.execute.return_value = {
        "revisions": [],
    }
    return service


def _mock_scan_all_files(service, query="", page_size=1000):
    """Return a small set of fake files."""
    return [
        {
            "id": "f1",
            "name": "document.txt",
            "mimeType": "text/plain",
            "parents": ["root"],
            "size": "1024",
        },
        {
            "id": "folder1",
            "name": "My Folder",
            "mimeType": "application/vnd.google-apps.folder",
            "parents": ["root"],
            "size": "0",
        },
        {
            "id": "f2",
            "name": "spreadsheet.xlsx",
            "mimeType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "parents": ["folder1"],
            "size": "2048",
        },
    ]


class TestRunFullScan:
    @patch("gdrive_organizer.scanner.crawler.scan_all_files", side_effect=_mock_scan_all_files)
    def test_basic_scan_returns_result(self, mock_scan, mock_service, config):
        result = run_full_scan(mock_service, config, apply_filters=False)

        assert isinstance(result, ScanResult)
        assert result.file_count == 2  # f1 and f2
        assert result.folder_count == 1  # folder1
        assert result.total_items == 3
        assert result.duration_ms >= 0
        assert result.filepath.exists()

    @patch("gdrive_organizer.scanner.crawler.scan_all_files", side_effect=_mock_scan_all_files)
    def test_scan_creates_snapshot_file(self, mock_scan, mock_service, config):
        result = run_full_scan(mock_service, config, apply_filters=False)
        assert result.filepath.suffix == ".gz"
        assert result.filepath.parent.name == "snapshots"

    @patch("gdrive_organizer.scanner.crawler.scan_all_files", side_effect=_mock_scan_all_files)
    def test_scan_with_nonexistent_folder_raises(self, mock_scan, mock_service, config):
        with pytest.raises(ValueError, match="not found"):
            run_full_scan(
                mock_service, config,
                folder_id="nonexistent_folder",
                apply_filters=False,
            )

    @patch("gdrive_organizer.scanner.crawler.scan_all_files", side_effect=_mock_scan_all_files)
    def test_scan_with_valid_folder_filters(self, mock_scan, mock_service, config):
        result = run_full_scan(
            mock_service, config,
            folder_id="folder1",
            apply_filters=False,
        )
        # folder1 + f2 (child of folder1)
        assert result.total_items == 2

    @patch("gdrive_organizer.scanner.crawler.scan_all_files", return_value=[])
    def test_empty_scan(self, mock_scan, mock_service, config):
        result = run_full_scan(mock_service, config, apply_filters=False)
        assert result.file_count == 0
        assert result.folder_count == 0
        assert result.total_items == 0
