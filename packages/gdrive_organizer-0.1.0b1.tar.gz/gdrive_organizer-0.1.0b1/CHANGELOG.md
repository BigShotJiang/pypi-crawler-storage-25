# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0-beta.1] - 2026-04-12

### Added

- **Core workflow**: scan -> classify -> plan -> apply -> rollback
- **Flat-crawl scanner**: single `files.list` call with in-memory tree reconstruction
- **AI classification**: xAI Grok integration with configurable presets (migration, second-brain, custom)
- **Plan/Apply separation**: AI generates reviewable JSON plans, never mutates Drive directly
- **Dry-run support**: `plan apply --dry-run` previews changes without execution
- **Rollback**: undo applied plans with correct operation ordering and untrash semantics
- **Readonly OAuth mode**: `oauth_readonly` config for inspection without write credentials
- **Incremental sync**: Changes API integration for fast re-scans after initial crawl
- **Local web viewer**: FastAPI dashboard with tree explorer, plan review, duplicate detection, permission audit
- **Batch executor**: Google Batch API wrapper with token-bucket rate limiter (3 writes/sec default)
- **Atomic snapshot writes**: prevents corruption from interrupted writes
- **Advisory snapshot locking**: reduces concurrent write races
- **Session-gated viewer mutations**: confirmation and session token checks for web-initiated changes
- **LLM response validation**: validates AI output structure before mutation planning
- **System keychain API key storage**: via `keyring` library
- **Restricted directory permissions**: `0700` on POSIX for config and data directories
- **File content reading**: `cat` command with auto-export for Google Workspace files
- **Scan exclusion rules**: configurable file/folder exclusions
- **Snapshot freshness checks**: warns when applying plans against stale snapshots
- **CLI**: typer-based with rich output formatting
- **justfile**: task runner with 32 recipes for common operations

### Security

- OAuth scope mismatch detection prevents readonly config from reusing write tokens
- Localhost-only viewer binding by default
- Credentials and tokens excluded from version control via `.gitignore`
