"""Real-Time Upscaler for Linux"""

__version__ = "1.0.1.post1"
