"""Version info for dcc-mcp-houdini."""

__version__ = "0.2.0"  # x-release-please-version
