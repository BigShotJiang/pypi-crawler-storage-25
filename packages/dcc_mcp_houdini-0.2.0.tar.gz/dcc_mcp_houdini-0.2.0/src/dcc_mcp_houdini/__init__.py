"""SideFX Houdini adapter for DCC MCP Core."""

from dcc_mcp_houdini.__version__ import __version__
from dcc_mcp_houdini._env import (
    ENV_ENABLE_GATEWAY_FAILOVER,
    ENV_GATEWAY_PORT,
    ENV_METRICS,
    ENV_PORT,
    ENV_READINESS_TIMEOUT_SECS,
    resolve_enable_gateway_failover,
    resolve_minimal_mode_enabled,
)
from dcc_mcp_houdini._readiness import ReadinessBinder, install_readiness
from dcc_mcp_houdini._skill_loader import (
    MINIMAL_SKILLS,
    STAGE_SKILLS,
    STAGES,
    build_minimal_mode_config,
    build_minimal_mode_for_stages,
    skills_for_stage,
)
from dcc_mcp_houdini._version_probe import (
    get_houdini_version_string,
    get_houdini_version_tuple,
    is_houdini_available,
)
from dcc_mcp_houdini.api import (
    MissingParamError,
    get_param,
    houdini_error,
    houdini_from_exception,
    houdini_success,
    require_param,
    with_houdini,
)
from dcc_mcp_houdini.api import (
    is_houdini_available as is_hou_available,
)
from dcc_mcp_houdini.dispatcher import (
    HoudiniStandaloneDispatcher,
    create_execution_stack,
)
from dcc_mcp_houdini.host import HoudiniCallableDispatcher, HoudiniHost
from dcc_mcp_houdini.server import (
    DEFAULT_PORT,
    SERVER_NAME,
    HoudiniMcpServer,
    HoudiniServerOptions,
    get_server,
    start_server,
    stop_server,
)

__all__ = [
    "__version__",
    "DEFAULT_PORT",
    "ENV_ENABLE_GATEWAY_FAILOVER",
    "ENV_GATEWAY_PORT",
    "ENV_METRICS",
    "ENV_PORT",
    "ENV_READINESS_TIMEOUT_SECS",
    "HoudiniCallableDispatcher",
    "HoudiniHost",
    "HoudiniMcpServer",
    "HoudiniServerOptions",
    "HoudiniStandaloneDispatcher",
    "MINIMAL_SKILLS",
    "MissingParamError",
    "ReadinessBinder",
    "SERVER_NAME",
    "STAGES",
    "STAGE_SKILLS",
    "build_minimal_mode_config",
    "build_minimal_mode_for_stages",
    "skills_for_stage",
    "create_execution_stack",
    "get_houdini_version_string",
    "get_houdini_version_tuple",
    "get_param",
    "get_server",
    "houdini_error",
    "houdini_from_exception",
    "houdini_success",
    "install_readiness",
    "is_houdini_available",
    "is_hou_available",
    "require_param",
    "resolve_enable_gateway_failover",
    "resolve_minimal_mode_enabled",
    "start_server",
    "stop_server",
    "with_houdini",
]
