import logging
from typing import List, Dict
from agent_api_server.shared.common import process_model_from_config_dict
from agent_api_server.shared.util_func import load_graph_config, load_graph
from model_manage_client import ModelManageClient

logger = logging.getLogger(__name__)

class AgentRegistry:
    def __init__(self, base_url:str, client_token:str):
        self.client = ModelManageClient(
            base_url=base_url,
            client_token=client_token
        )

    @staticmethod
    async def get_llm_model_from_agent_cfg(agent: Dict) -> Dict:
        graph_cfg = await load_graph_config()
        _, graph_instance, _ = await load_graph(agent['agent_name'], graph_cfg, False)

        cfg = graph_instance.get_context_jsonschema()

        logger.info(f"Get agent config {cfg} from {agent['agent_name']}")

        return process_model_from_config_dict(cfg)

    async def register_all(self, agents: List[Dict]):
        for agent in agents:
            try:
                model_info = await self.get_llm_model_from_agent_cfg(agent)

                extra_params = {
                    "agent_description": agent["agent_description"],
                    "agent_icon_url": agent["agent_icon_url"],
                    "agent_api_version": agent["agent_api_version"],
                    "agent_features": agent["agent_features"],
                    "agent_labels": agent["agent_labels"],
                    "support_models": model_info,
                    "has_site": agent["has_site"],
                    "is_system_agent": agent["is_system_agent"],
                    "multilangs": agent.get("multilangs", {})
                }

                agent_find = self.client.get_agent(agent_name=agent["agent_name"])
                if agent_find:
                    logger.info(f"agent: {agent['agent_name']} already register successfully, update agent with extra_params {extra_params}")

                    self.client.update_agent(
                        agent_name=agent["agent_name"],
                        agent_url=agent["agent_url"],
                        **extra_params
                    )
                    continue

                self.client.register_agent(
                    agent_name=agent["agent_name"],
                    agent_id=agent["agent_name"],
                    agent_url=agent["agent_url"],
                    **extra_params
                )

                logger.info(
                    f"agent: {agent['agent_name']} register successfully, register agent with extra_params {extra_params}")
            except Exception as e:
                raise e