import inspect
import logging
import json
from typing import Dict, Any, Optional, List, Callable, Awaitable
from functools import wraps, partial
from datetime import datetime

from langgraph.config import get_stream_writer
from langgraph.graph.state import CompiledStateGraph
from fastmcp import FastMCP,Context
from mcp import types
from mcp.types import RequestParams, CallToolResult, TextContent

from agent_api_server.schema.context import Context as RuntimeContext
from agent_api_server.shared.message import handle_stream_event
from agent_api_server.shared.util_func import load_graph_config, load_graph, get_env

logger = logging.getLogger(__name__)


async def handle_messages(message):
    writer = get_stream_writer()
    if isinstance(message, types.ServerNotification):
        notification = message.root
        if isinstance(notification, types.ProgressNotification):
            params = notification.params
            logger.info(f"receive progress message: ({params.message})")
            writer(params.message)

async def create_mcp_tool_from_agent() -> FastMCP:
    """Create and configure MCP tools from LangGraph agent configurations.

    Returns:
        FastMCP: Configured MCP instance with all graph tools registered.

    Raises:
        RuntimeError: If tool creation fails due to configuration or loading errors.
    """
    mcp = FastMCP(name="langgraph_mcp_tool")

    try:
        graph_cfg = await load_graph_config()

        # Validate configurations
        graphs = graph_cfg.get("graphs", {})
        if not isinstance(graphs, dict):
            raise RuntimeError(f"Invalid graphs config. Expected dict, got {type(graphs)}")

        agent_descriptions = graph_cfg.get("agent_description", {})
        if not isinstance(agent_descriptions, dict):
            logger.warning("agent_description should be dict, got %s", type(agent_descriptions))
            agent_descriptions = {}

        for graph_name, graph_path in graphs.items():
            _, graph_instance, _ = await load_graph(graph_name, graph_cfg, False)

            if not isinstance(graph_instance, CompiledStateGraph):
                raise RuntimeError(f"Graph {graph_name} is not CompiledStateGraph")

            tool_impl = partial(
                _execute_graph_tool,
                mcp=mcp,
                graph_name=graph_name,
                graph_instance=graph_instance
            )
            tool_impl.__name__ = graph_name

            tool = create_tool_from_schema(
                schema=graph_instance.get_input_jsonschema(),
                func_name=graph_name,
                func_doc=agent_descriptions.get(graph_name, ""),
                implementation=tool_impl
            )

            mcp.tool()(_add_metrics_wrapper(tool, graph_name))
            logger.info("Registered tool: %s", graph_name)

        return mcp
    except Exception as e:
        logger.error("MCP tool creation failed", exc_info=True)
        raise RuntimeError(f"MCP tool creation failed: {str(e)}")


async def _execute_graph_tool(
        mcp: FastMCP,
        graph_name: str,
        graph_instance: CompiledStateGraph,
        **kwargs: Any
) -> Dict[str, Any]:
    """Execute a LangGraph agent and stream results.

    Args:
        mcp: FastMCP instance
        graph_name: Name of the graph to execute
        graph_instance: Compiled graph instance
        **kwargs: Input parameters

    Returns:
        Execution result dict
    """
    ctx = Context(fastmcp=mcp)

    from fastmcp.server.dependencies import get_http_request
    request = get_http_request()

    use_sys_llm = request.headers.get("UseSysLLM", None)
    ts_tenant = request.headers.get("TSTenant", "")
    ei_token = request.headers.get("Authorization", "")
    if ei_token.startswith("Bearer "):
        ei_token = ei_token.removeprefix("Bearer ")
    thread_id = request.headers.get('thread_id', '')
    start_time = datetime.now()

    logger.info(f"Executing graph '{graph_name}' for tenant '{ts_tenant}', ei_token is '{ei_token}', use_sys_llm is {use_sys_llm}")

    # Validate input
    schema = graph_instance.get_input_jsonschema()
    if schema:
        if schema.get("properties"):
            if schema["properties"].get("messages"):
                schema["properties"].pop("messages")
                if schema.get("required"):
                    required_schema = schema.get("required")

                    real_required_schema = []
                    for _, s in enumerate(required_schema):
                        if s == "messages":
                            continue
                        real_required_schema.append(s)
                    schema["required"] = real_required_schema

    input_dict = {}
    validation_errors = []

    for field, prop in schema.get("properties", {}).items():
        if field in kwargs:
            try:
                input_dict[field] = _validate_field(field, kwargs[field], prop)
            except ValueError as e:
                validation_errors.append(str(e))
        elif field in schema.get("required", []):
            validation_errors.append(f"Missing required field: {field}")

    if validation_errors:
        error_msg = "Validation errors:\n" + "\n".join(validation_errors)
        logger.error(error_msg)
        return CallToolResult(
            content=[TextContent(type="text", text=error_msg)],
            isError=True
        )

    if thread_id is not None and thread_id != "":
        logger.info(f"execute graph {graph_name} with thread id {thread_id} which get from context headers")
    else:
        thread_id = ctx.session_id
        logger.info(f"execute graph {graph_name} with session id {ctx.session_id}")

    configurable_params = {
        "use_sys_llm": use_sys_llm,
        "thread_id": thread_id,
        "TSTenant": ts_tenant,
        "EIToken": ei_token,
        "graph_name": graph_name
    }

    if ts_tenant is not None and ts_tenant != "":
        configurable_params = {
            **dict(get_env(ts_tenant=ts_tenant)),
            **configurable_params
        }

    chunks = []
    try:
        async for stream_event in graph_instance.astream(
                input_dict,
                config={
                    "configurable": configurable_params
                },
                context=RuntimeContext(
                    use_system_llm=configurable_params.get("use_sys_llm"),
                    ts_tenant=configurable_params.get("TSTenant"),
                    ei_token=configurable_params.get("EIToken"),
                    input=input_dict,
                    config=configurable_params,
                    graph_name=configurable_params.get("graph_name"),
                ),
                stream_mode=["updates"],
                subgraphs=True
        ):
            async for chunk in handle_stream_event(stream_event):
                ctx.request_context.meta = RequestParams.Meta(progressToken=ctx.request_id)
                await ctx.report_progress(message=chunk, progress=len(chunks))
                chunks.append(chunk)

        if not chunks:
            raise ValueError("No response from graph execution")

        last_chunk = chunks[-1].strip()
        if not last_chunk.startswith("data: "):
            raise ValueError("Invalid response format")

        data = json.loads(last_chunk[6:])
        if not data.get("update_content", {}).get("content"):
            raise ValueError("Missing content in response")

        logger.info(
            "Graph '%s' executed in %.2fs (%d chunks)",
            graph_name,
            (datetime.now() - start_time).total_seconds(),
            len(chunks)
        )

        return CallToolResult(
            content=[TextContent(type="text", text=data["update_content"]["content"])],
            isError=False
        )

    except Exception as err:
        logger.error("Graph execution failed: %s", str(err), exc_info=True)
        return CallToolResult(
            content=[TextContent(type="text", text=f"Execution failed: {str(err)}")],
            isError=True
        )


def create_tool_from_schema(
        schema: Dict[str, Any],
        func_name: str,
        func_doc: str = "",
        implementation: Optional[Callable[..., Awaitable[Dict[str, Any]]]] = None
) -> Callable[..., Awaitable[Dict[str, Any]]]:
    if schema:
        if schema.get("properties"):
            if schema["properties"].get("messages"):
                schema["properties"].pop("messages")
                if schema.get("required"):
                    required_schema = schema.get("required")

                    real_required_schema = []
                    for _, s in enumerate(required_schema):
                        if s == "messages":
                            continue
                        real_required_schema.append(s)
                    schema["required"] = real_required_schema

    properties = schema.get("properties", {})
    required = schema.get("required", [])
    type_map = {
        "string": str,
        "number": float,
        "integer": int,
        "boolean": bool,
        "array": List,
        "object": Dict
    }

    params = []
    type_hints = {}
    for param_name, param_info in properties.items():
        param_type = type_map.get(param_info.get("type"), Any)

        if param_name not in required:
            if 'anyOf' in param_info:
                first_non_null_type = None
                for item in param_info['anyOf']:
                    item_type = item.get('type')
                    if item_type and item_type != 'null':
                        first_non_null_type = item_type
                        break

                if first_non_null_type:
                    non_null_param_type = type_map.get(first_non_null_type, Any)
                    param_type = non_null_param_type

        type_hints[param_name] = param_type
        params.append(
            inspect.Parameter(
                param_name,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                default=None if param_name not in required else inspect.Parameter.empty,
                annotation=param_type,
            )
        )

    if implementation is None:
        async def default_impl(**kwargs: Any) -> Dict[str, Any]:
            missing = [f for f in required if f not in kwargs]
            if missing:
                raise ValueError(f"Missing fields: {missing}")
            return {"content": [f"Default response for {func_name}"]}

        implementation = default_impl

    implementation.__name__ = func_name
    implementation.__qualname__ = func_name
    implementation.__doc__ = func_doc or f"Tool from schema: {schema.get('title', '')}"
    implementation.__signature__ = inspect.Signature(
        parameters=params,
        return_annotation=Dict[str, Any],
    )
    implementation.__annotations__ = type_hints

    return implementation


def _add_metrics_wrapper(
        func: Callable[..., Awaitable[Dict[str, Any]]],
        tool_name: str
) -> Callable[..., Awaitable[Dict[str, Any]]]:

    @wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Dict[str, Any]:
        start_time = datetime.now()
        logger.info("Tool '%s' started", tool_name)

        try:
            result = await func(*args, **kwargs)
            logger.info(
                "Tool '%s' completed in %.2fs",
                tool_name,
                (datetime.now() - start_time).total_seconds()
            )
            return result
        except Exception as e:
            logger.error(
                "Tool '%s' failed after %.2fs: %s",
                tool_name,
                (datetime.now() - start_time).total_seconds(),
                str(e),
                exc_info=True
            )
            raise

    return wrapper


def _validate_field(
        field_name: str,
        value: Any,
        schema: Dict[str, Any]
) -> Any:
    field_type = schema.get("type")

    try:
        if field_type == "string":
            if not isinstance(value, str):
                value = str(value)
            if "enum" in schema and value not in schema["enum"]:
                raise ValueError(f"Value not in {schema['enum']}")
        elif field_type == "number":
            value = float(value)
        elif field_type == "integer":
            value = int(value)
        elif field_type == "boolean":
            if isinstance(value, str):
                value = value.lower() in ("true", "1", "yes")
            value = bool(value)
        elif field_type == "array":
            if not isinstance(value, list):
                raise ValueError("Expected list")
        elif field_type == "object":
            if not isinstance(value, dict):
                raise ValueError("Expected dict")
    except (ValueError, TypeError) as e:
        raise ValueError(f"Invalid value for '{field_name}': {str(e)}")

    return value