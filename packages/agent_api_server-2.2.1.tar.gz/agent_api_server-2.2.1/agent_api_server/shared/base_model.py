import logging
from typing import Optional
from pydantic import Field
from pydantic import BaseModel
from fastapi import HTTPException, status
from typing import Any, Literal, NotRequired
from typing_extensions import TypedDict

logger = logging.getLogger(__name__)

class ThreadInfo(BaseModel):
    thread_id: str
    graph_name: str
    status: str

class RunResponse(BaseModel):
    status: str
    thread_id: str
    result: Optional[Any] = None
    error: Optional[str] = None

def error_response(
    status_code: int,
    error_type: str,
    message: str,
    **additional_info: Any
) -> HTTPException:
    """Helper function to create consistent error responses."""
    detail = {
        "status": "error",
        "error": error_type,
        "message": message,
        **additional_info
    }
    return HTTPException(
        status_code=status_code,
        detail=detail
    )

class ToolCall(TypedDict):
    """Represents a request to call a tool."""

    name: str
    """The name of the tool to be called."""
    args: dict[str, Any]
    """The arguments to the tool call."""
    id: str | None
    """An identifier associated with the tool call."""
    type: NotRequired[Literal["tool_call"]]

class ChatMessage(BaseModel):
    """Message in a chat."""
    type: Literal["human", "ai", "tool"] = Field(
        description="Role of the message.",
        examples=["human", "ai", "tool"],
    )
    content_type: Literal["markdown", "json", "html", "xml", "python", "yaml", "text"] = Field(
        description="The data type of the message.",
        examples=["markdown", "json", "html", "xml", "python", "yaml", "text"],
    )
    content: str = Field(
        description="Content of the message.",
        examples=["Hello, world!"],
    )
    tool_calls: list[ToolCall] = Field(
        description="Tool calls in the message.",
        default=[],
    )
    response_metadata: dict[str, Any] = Field(
        description="Response metadata. For example: response headers, logprobs, token counts.",
        default={},
    )
    references: list[dict[str, Any]] = Field(
        description="references metadata. For example: List of reference materials.",
        default=[],
    )

    def pretty_repr(self) -> str:
        """Get a pretty representation of the message."""
        base_title = self.type.title() + " Message"
        padded = " " + base_title + " "
        sep_len = (80 - len(padded)) // 2
        sep = "=" * sep_len
        second_sep = sep + "=" if len(padded) % 2 else sep
        title = f"{sep}{padded}{second_sep}"
        return f"{title}\n\n{self.content}"

    def pretty_print(self) -> None:
        logger.info(self.pretty_repr())  # noqa: T201


def sse_response_example() -> dict[int | str, Any]:
    return {
        status.HTTP_200_OK: {
            "description": "Server Sent Event Response",
            "content": {
                "text/event-stream": {
                    "example": "data: {'type': 'token', 'content': 'Hello'}\n\ndata: {'type': 'token', 'content': ' World'}\n\ndata: [DONE]\n\n",
                    "schema": {"type": "string"},
                }
            },
        }
    }