import asyncio
import aiohttp
import logging
import os
import threading
import time
from typing import List, Dict
from urllib.parse import urljoin

from agent_api_server.configs import global_config

logger = logging.getLogger(__name__)


class AsyncConfigCenterClient:
    _instance = None

    def __init__(self):
        self.url = os.getenv("CONFIG_CENTER_ADDRESS") or "http://configcenter:10086"
        if self.url.endswith("/"):
            self.url = self.url.rstrip("/")
        self._agents = []
        self._session = None
        logger.info(f"ConfigCenter Client registered URL is: {self.url}")

    async def initialize(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
            logger.info("ConfigCenter Client initialized")

    async def close(self):
        if self._session:
            await self._session.close()
            self._session = None
            logger.info("ConfigCenter Client closed")

    async def ensure_initialized(self):
        if self._session is None or self._session.closed:
            await self.initialize()

    async def register_to_config_center(self, agents: List[Dict], with_secret: bool) -> None:
        if not agents:
            raise ValueError("Agents list cannot be empty")

        await self.ensure_initialized()
        self._agents = agents

        for agent in agents:
            if "agent_name" not in agent:
                raise ValueError(f"Agent is missing 'agent_name' field: {agent}")
            if not agent.get("agent_labels"):
                raise ValueError(f"Agent is missing 'agent_labels' field: {agent}")

        await self._register_agents(agents, global_config.ENABLE_MCP_SERVER, with_secret)

    async def _register_agents(self, agents: List[Dict], is_mcp: bool, with_secret: bool) -> None:
        config_endpoint = f"{self.url}/v1/services"

        main_agent = agents[0]
        if not main_agent.get("agent_labels"):
            raise ValueError("agent_labels is required but empty")

        service_name = main_agent["agent_labels"][0]
        payload = {
            "name": service_name,
            "serviceInstances": [] if with_secret else [
                {"schema": "postgres"},
                {"schema": "redis"},
            ],
            "routers": {}
        }

        for agent in agents:
            agent_name = agent["agent_name"]
            payload["routers"][agent_name] = {
                "name": agent_name,
                "address": os.getenv("SERVICE_EXTERNAL_URL")
            }

        if is_mcp:
            mcp_router_name = f"{service_name}_mcp"
            payload["routers"][mcp_router_name] = {
                "name": mcp_router_name,
                "address": urljoin(os.getenv("MCP_SERVER_EXTERNAL_URL"), "mcp"),
                "isMcpServer": True,
                "mcpServerParams": {
                    "isAuth": "true",
                }
            }

        max_retries = 3
        for attempt in range(max_retries):
            try:
                async with self._session.post(config_endpoint, json=payload, timeout=30) as response:
                    response.raise_for_status()
                    router_names = list(payload['routers'].keys())
                    logger.info(
                        f"Service '{service_name}' registered successfully with {len(router_names)} routers: {router_names}")
                    return
            except Exception as e:
                logger.error(f"Attempt {attempt + 1}: Failed to register service '{service_name}', "
                             f"request url: {config_endpoint}; error {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    logger.error(f"Failed to register service '{service_name}' after 3 attempts")
                    raise e

    def start_periodic_registration(self, agents: List[Dict], with_secret: bool, interval: int = 5):
        if not agents:
            raise ValueError("Agents list cannot be empty")

        self._agents = agents

        def registration_loop():
            logger.info(f"🚀 Starting periodic registration thread with interval {interval}s")

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            session = aiohttp.ClientSession(loop=loop)
            original_session = self._session
            self._session = session

            try:
                while True:
                    try:
                        logger.info(f"🔄 Registration started")
                        loop.run_until_complete(self._run_registration_iteration(with_secret))
                        logger.info(f"✅ Registration completed successfully")
                        time.sleep(interval)
                    except Exception as e:
                        logger.error(f"❌ Error in registration: {e}")
                        time.sleep(5)
            finally:
                loop.run_until_complete(session.close())
                loop.close()
                self._session = original_session
                logger.info("⏹️ Periodic registration thread stopped")

        thread = threading.Thread(
            target=registration_loop,
            name="config_center_registration",
            daemon=True
        )
        thread.start()
        logger.info("✅ Periodic registration thread started")

    async def _run_registration_iteration(self, with_secret: bool):
        await self.ensure_initialized()
        await self._register_agents(self._agents, global_config.ENABLE_MCP_SERVER, with_secret)

    async def database_credential(self) -> dict:
        if not self._agents:
            raise ValueError("No agents registered yet")

        await self.ensure_initialized()

        main_agent = self._agents[0]
        if not main_agent.get("agent_labels"):
            raise ValueError("agent_labels is required but empty")

        service_name = main_agent["agent_labels"][0]
        config_endpoint = urljoin(self.url, f"/v1/{service_name}/serviceintance")

        async with self._session.get(config_endpoint) as response:
            response.raise_for_status()
            data = await response.json()

        postgres_url = data.get("postgres", "")
        if postgres_url:
            postgres_url = postgres_url.replace("postgres://", "postgresql://", 1)

        redis_url = data.get("redis", "")
        return {
            "POSTGRES_URL": postgres_url,
            "REDIS_URL": redis_url
        }

    async def public_config(self) -> dict:
        await self.ensure_initialized()
        config_endpoint = urljoin(self.url, "/v1/public/configs")

        async with self._session.get(config_endpoint) as response:
            response.raise_for_status()
            config_data = await response.json()

        return {
            "cluster": config_data.get("cluster"),
            "datacenter": config_data.get("datacenter"),
            "workspace": config_data.get("workspace"),
            "namespace": config_data.get("namespace")
        }

    async def service_config(self) -> dict:
        await self.ensure_initialized()
        config_endpoint = urljoin(self.url, "/v1/services")

        async with self._session.get(config_endpoint) as response:
            response.raise_for_status()
            config_data = await response.json()

        sso_api_url = config_data.get("SSO", {}).get("routers", {}).get("API", {}).get("address")
        model_management_url = config_data.get("model-management", {}).get("routers", {}).get("API", {}).get("address")

        return {
            "SSO_URL": sso_api_url,
            "MODEL_MANAGER_SERVICE_URL": model_management_url,
        }

    async def get_service_internal_url_with_router_path(self, service_name: str, router_path: str) -> str:
        await self.ensure_initialized()
        config_endpoint = urljoin(self.url, "/v1/services")

        async with self._session.get(config_endpoint) as response:
            response.raise_for_status()
            config_data = await response.json()

        url = config_data.get(service_name, {}).get("routers", {}).get(router_path, {}).get("address")

        return url

    async def get_service_public_url_with_router_path(self, service_name: str, router_path: str) -> str:
        await self.ensure_initialized()
        config_endpoint = urljoin(self.url, "/v1/services")

        async with self._session.get(config_endpoint) as response:
            response.raise_for_status()
            config_data = await response.json()

        url = config_data.get(service_name, {}).get("routers", {}).get(router_path, {}).get("publicAddress")

        return url

    @staticmethod
    async def get_instance() -> "AsyncConfigCenterClient":
        if AsyncConfigCenterClient._instance is None:
            AsyncConfigCenterClient._instance = AsyncConfigCenterClient()
        return AsyncConfigCenterClient._instance