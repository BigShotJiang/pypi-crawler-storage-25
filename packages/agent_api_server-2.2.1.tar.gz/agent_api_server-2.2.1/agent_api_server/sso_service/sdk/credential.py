import time
from .encoding import AesEncrypt, Base64UrlSafeEncode

SRP_TOKEN_KEY = "ssoisno12345678987654321"


def get_srp_token(service_name: str) -> str:
    cur_time = str(int(time.time()))
    src = f"{cur_time}-{service_name}"
    crypted = AesEncrypt(src, SRP_TOKEN_KEY)
    return Base64UrlSafeEncode(crypted)
