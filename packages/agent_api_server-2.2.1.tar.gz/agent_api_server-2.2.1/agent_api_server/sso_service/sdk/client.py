import os
import json
import logging
from urllib.parse import quote
from typing import List, Optional

import requests

logger = logging.getLogger(__name__)

CLIENT_CREDENTIALS = "client_credentials"
CURRENT_SERVICE_NAME = "KB-Insight"


class ClientRequest:
    def __init__(
            self,
            datacenter: Optional[str] = None,
            cluster: Optional[str] = None,
            workspace: Optional[str] = None,
            namespace: Optional[str] = None,
            app_id: Optional[str] = None,
            app_name: Optional[str] = None,
            scopes: Optional[List[str]] = None,
            service_name: Optional[str] = None,
            redirect_url: Optional[str] = None,
            **kwargs,
    ):
        self.datacenter = datacenter
        self.cluster = cluster
        self.workspace = workspace
        self.namespace = namespace
        self.app_id = app_id
        self.app_name = app_name
        self.scopes = scopes if scopes else ["Admin", "Editor", "Viewer"]
        self.service_name = service_name
        self.redirect_url = redirect_url

    def to_dict(self):
        return {
            "datacenter": self.datacenter,
            "cluster": self.cluster,
            "workspace": self.workspace,
            "namespace": self.namespace,
            "appId": self.app_id,
            "appName": self.app_name,
            "scopes": self.scopes,
            "serviceName": self.service_name,
            "redirectUrl": self.redirect_url,
        }


class ClientInfo(ClientRequest):
    def __init__(
            self,
            client_id: Optional[str] = None,
            creation_time: Optional[int] = None,
            last_modified_time: Optional[int] = None,
            client_secret: Optional[str] = None,
            client_type: Optional[str] = None,
            **kwargs,
    ):
        super().__init__(**kwargs)
        self.client_id = client_id
        self.creation_time = creation_time
        self.last_modified_time = last_modified_time
        self.client_secret = client_secret
        self.client_type = client_type

    @classmethod
    def from_dict(cls, data: dict):
        # 过滤掉 ClientRequest 不支持的字段
        client_request_data = {
            "datacenter": data.get("datacenter"),
            "cluster": data.get("cluster"),
            "workspace": data.get("workspace"),
            "namespace": data.get("namespace"),
            "app_id": data.get("appId"),
            "app_name": data.get("appName"),
            "scopes": data.get("scopes"),
            "service_name": data.get("serviceName"),
            "redirect_url": data.get("redirectUrl"),
        }
        return cls(
            client_id=data.get("clientId"),
            creation_time=data.get("creationTime"),
            last_modified_time=data.get("lastModifiedTime"),
            client_secret=data.get("clientSecret"),
            client_type=data.get("clientType"),
            **client_request_data,  # 只传递 ClientRequest 支持的字段
        )


class SsoToken:
    def __init__(
            self,
            access_token: Optional[str] = None,
            token_type: Optional[str] = None,
            expires_in: Optional[int] = None,
            refresh_token: Optional[str] = None,
    ):
        self.access_token = access_token
        self.token_type = token_type
        self.expires_in = expires_in
        self.refresh_token = refresh_token

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            access_token=data.get("accessToken"),
            token_type=data.get("tokenType"),
            expires_in=data.get("expiresIn"),
            refresh_token=data.get("refreshToken"),
        )


class SSOClient:
    def __init__(self, service_name: Optional[str] = None):
        self.client_info = ClientInfo(
            datacenter=os.getenv("datacenter"),
            cluster=os.getenv("cluster"),
            workspace=os.getenv("workspace"),
            namespace=os.getenv("namespace"),
            app_id=os.getenv("appID") or os.getenv("appId"),
            app_name=service_name or CURRENT_SERVICE_NAME,
            service_name=service_name or CURRENT_SERVICE_NAME,
        )

    def query_sso_client(self, address: str, req: ClientRequest) -> ClientInfo:
        path = f"{address}/clients/{quote(req.app_name)}"
        path += f"?namespace={req.namespace}&workspace={req.workspace}&cluster={req.cluster}&datacenter={req.datacenter}&serviceName={quote(req.service_name)}&appId={req.app_id}"

        credential = self.new_srp_token_credential(req.service_name)
        headers = {credential["header_name"]: credential["header_value"]}

        response = requests.get(path, headers=headers)
        response.raise_for_status()
        return ClientInfo.from_dict(response.json())

    def register_client(self, address: str, req: ClientRequest) -> ClientInfo:
        path = f"{address}/clients"
        body = json.dumps(req.to_dict())

        logger.info({body})

        credential = self.new_srp_token_credential(req.service_name)
        headers = {
            credential["header_name"]: credential["header_value"],
            "Content-Type": "application/json"
        }

        response = requests.post(path, headers=headers, data=body)
        response.raise_for_status()
        return ClientInfo.from_dict(response.json())

    def update_sso_client(self, address: str, client_id: str, req: ClientRequest) -> ClientInfo:
        path = f"{address}/clients/{client_id}"
        body = json.dumps(req.to_dict())

        credential = self.new_srp_token_credential(req.service_name)
        headers = {
            credential["header_name"]: credential["header_value"],
            "Content-Type": "application/json"
        }

        response = requests.put(path, headers=headers, data=body)
        response.raise_for_status()
        return ClientInfo.from_dict(response.json())

    def query_sso_client_token(self, address: str) -> SsoToken:
        path = f"{address}/oauth/token"
        path += f"?grant_type={CLIENT_CREDENTIALS}&client_id={self.client_info.client_id}&client_secret={self.client_info.client_secret}&duration=eternal"

        response = requests.post(path)
        response.raise_for_status()
        return SsoToken.from_dict(response.json())

    def set_sso_client(self, address: str) -> None:
        if not address.endswith("/v4.0"):
            address += "/v4.0"

        try:
            rsp = self.query_sso_client(address, self.client_info)
        except requests.exceptions.HTTPError as e:
            if "Not Found" in str(e):
                rsp = self.register_client(address, self.client_info)
            else:
                raise e

        if rsp is None:
            raise Exception("Failed to set SSO client")

        if rsp.app_id != self.client_info.app_id:
            try:
                new_rsp = self.update_sso_client(address, rsp.client_id, self.client_info)
                rsp = new_rsp
            except requests.exceptions.HTTPError as e:
                logger.error(f"Failed to update SSO client: {e}")

        self.client_info = rsp
        return None

    @staticmethod
    def new_srp_token_credential(service_name: str) -> dict:
        from .credential import get_srp_token
        return {
            "header_name": "X-Auth-SRPToken",
            "header_value": get_srp_token(service_name),
        }


def get_sso_client_id_and_secret(address: str, service: str) -> tuple:
    sso = SSOClient(service)
    logger.debug(f"{sso.client_info.__dict__}")

    try:
        sso.set_sso_client(address)
    except Exception as e:
        raise ValueError(f"get sso clientId and ClientSecret err: {e}")

    logger.debug(
        f"ServiceName: {sso.client_info.service_name}, ClientID: {sso.client_info.client_id}, ClientSecret: {sso.client_info.client_secret}")

    return sso.client_info.client_id, sso.client_info.client_secret
