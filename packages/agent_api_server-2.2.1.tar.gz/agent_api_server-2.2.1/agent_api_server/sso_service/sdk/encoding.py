import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding


def AesEncrypt(src: str, key: str) -> bytes:
    key_bytes = key.encode("utf-8")
    src_bytes = src.encode("utf-8")

    # Pad the source data
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_data = padder.update(src_bytes) + padder.finalize()

    # Encrypt
    cipher = Cipher(algorithms.AES(key_bytes), modes.ECB())
    encryptor = cipher.encryptor()
    return encryptor.update(padded_data) + encryptor.finalize()


def Base64UrlSafeEncode(data: bytes) -> str:
    encoded = base64.urlsafe_b64encode(data).decode("utf-8")
    return encoded.rstrip("=")
