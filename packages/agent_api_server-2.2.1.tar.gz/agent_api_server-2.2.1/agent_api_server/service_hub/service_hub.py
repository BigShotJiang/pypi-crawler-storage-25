import json
import os
import logging
from typing import Dict, List, Union
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

class ServiceHubError(Exception):
    """Base exception for ServiceHub credential parsing errors"""
    pass


class CredentialNotFoundError(ServiceHubError):
    """Raised when a specific credential type is not found"""
    pass


class InvalidCredentialError(ServiceHubError):
    """Raised when credential data is invalid"""
    pass


@dataclass
class PostgresCredential:
    async_flag: bool
    binding_name: str
    database: str
    external_hosts: str
    host: str
    internal_hosts: str
    password: str
    port: int
    uri: str
    username: str
    instance_name: str = ""
    label: str = ""
    plan: str = ""
    service_instance_id: str = ""
    subscription_id: str = ""


@dataclass
class RedisCredential:
    binding_name: str
    external_hosts: str
    host: str
    internal_hosts: str
    password: str
    port: int
    uri: str = ""
    username: str = ""
    instance_name: str = ""
    label: str = ""
    plan: str = ""
    service_instance_id: str = ""
    subscription_id: str = ""

@dataclass
class BlobstoreCredential:
    """Blobstore (S3-compatible) connection credentials"""
    binding_name: str
    access_key: str
    secret_key: str
    endpoint: str
    external_hosts: str
    internal_hosts: str
    signature_version: str
    type: str
    instance_name: str = ""
    label: str = ""
    plan: str = ""
    service_instance_id: str = ""
    subscription_id: str = ""


@dataclass
class ServiceHubCredentials:
    postgres: List[PostgresCredential] = field(default_factory=list)
    redis: List[RedisCredential] = field(default_factory=list)
    blobstore: List[BlobstoreCredential] = field(default_factory=list)

    def to_postgres_dsn(self) -> str:
        if not self.postgres:
            raise CredentialNotFoundError("PostgreSQL credentials not found")

        cred = self.postgres[0]
        return f"postgresql://{cred.username}:{cred.password}@{cred.internal_hosts}/{cred.database}"

    def to_redis_dsn(self) -> str:
        if not self.redis:
            raise CredentialNotFoundError("Redis credentials not found")

        cred = self.redis[0]

        if not cred.password and not cred.username:
            return f"redis://{cred.internal_hosts}:{cred.port}"

        if cred.password and not cred.username:
            return f"redis://:{cred.password}@{cred.internal_hosts}:{cred.port}"

        if cred.username and not cred.password:
            return f"redis://{cred.username}@{cred.internal_hosts}:{cred.port}"

        if cred.username and cred.password:
            return f"redis://{cred.username}:{cred.password}@{cred.internal_hosts}:{cred.port}"

    def get_blobstore_s3_config(self) -> Dict[str, str]:
        """Get Blobstore credentials as S3-compatible configuration dictionary"""
        if not self.blobstore:
            logger.warning("Blobstore credentials not found")
            return {}

        cred = self.blobstore[0]
        return {
            "access_key": cred.access_key,
            "secret_key": cred.secret_key,
            "endpoint": cred.endpoint,
            "external_hosts": cred.external_hosts,
            "internal_hosts": cred.internal_hosts,
            "signature_version": cred.signature_version,
            "type": cred.type
        }

    def get_service_instance_id(self) -> str:
        """Get the first available service instance ID"""
        for cred_list in [
            self.postgres,
            self.redis,
            self.blobstore,
        ]:
            if cred_list and cred_list[0].service_instance_id:
                return cred_list[0].service_instance_id
        raise CredentialNotFoundError("No service instance ID found")


class ServiceHubCredentialParser:
    @staticmethod
    def _parse_postgres(data: Dict) -> PostgresCredential:
        return PostgresCredential(
            async_flag=data.get("async", False),
            binding_name=data.get("binding_name", ""),
            database=data.get("credentials", {}).get("database", ""),
            external_hosts=data.get("credentials", {}).get("externalHosts", ""),
            host=data.get("credentials", {}).get("host", ""),
            internal_hosts=data.get("credentials", {}).get("internalHosts", ""),
            password=data.get("credentials", {}).get("password", ""),
            port=data.get("credentials", {}).get("port", 0),
            uri=data.get("credentials", {}).get("uri", ""),
            username=data.get("credentials", {}).get("username", ""),
            instance_name=data.get("instance_name", ""),
            label=data.get("label", ""),
            plan=data.get("plan", ""),
            service_instance_id=data.get("serviceInstanceId", ""),
            subscription_id=data.get("subscriptionId", ""),
        )

    @staticmethod
    def _parse_redis(data: Dict) -> RedisCredential:
        return RedisCredential(
            binding_name=data.get("binding_name", ""),
            external_hosts=data.get("credentials", {}).get("externalHosts", ""),
            host=data.get("credentials", {}).get("host", ""),
            internal_hosts=data.get("credentials", {}).get("internalHosts", ""),
            password=data.get("credentials", {}).get("password", ""),
            port=data.get("credentials", {}).get("port", 0),
            uri=data.get("credentials", {}).get("uri", ""),
            username=data.get("credentials", {}).get("username", ""),
            instance_name=data.get("instance_name", ""),
            label=data.get("label", ""),
            plan=data.get("plan", ""),
            service_instance_id=data.get("serviceInstanceId", ""),
            subscription_id=data.get("subscriptionId", ""),
        )

    @staticmethod
    def _parse_blobstore(data: Dict) -> BlobstoreCredential:
        return BlobstoreCredential(
            binding_name=data.get("binding_name", ""),
            access_key=data.get("credentials", {}).get("accessKey", ""),
            secret_key=data.get("credentials", {}).get("secretKey", ""),
            endpoint=data.get("credentials", {}).get("endpoint", ""),
            external_hosts=data.get("credentials", {}).get("externalHosts", ""),
            internal_hosts=data.get("credentials", {}).get("internalHosts", ""),
            signature_version=data.get("credentials", {}).get("signature-version", ""),
            type=data.get("credentials", {}).get("type", ""),
            instance_name=data.get("instance_name", ""),
            label=data.get("label", ""),
            plan=data.get("plan", ""),
            service_instance_id=data.get("serviceInstanceId", ""),
            subscription_id=data.get("subscriptionId", ""),
        )

    @staticmethod
    def parse(data: Union[str, bytes, Dict]) -> ServiceHubCredentials:
        """Parse ServiceHub credentials from JSON data"""
        if isinstance(data, (str, bytes)):
            try:
                if isinstance(data, bytes):
                    data = data.decode('utf-8')
                data = json.loads(data)
            except json.JSONDecodeError as e:
                raise InvalidCredentialError(f"Invalid JSON data: {e}") from e

        if not isinstance(data, dict):
            raise InvalidCredentialError("Expected dictionary data")

        credentials = ServiceHubCredentials()

        if "postgresql" in data:
            credentials.postgres = [
                ServiceHubCredentialParser._parse_postgres(item)
                for item in data["postgresql"]
            ]

        if "redis" in data:
            credentials.redis = [
                ServiceHubCredentialParser._parse_redis(item)
                for item in data["redis"]
            ]

        if "blobstore" in data:
            credentials.blobstore = [
                ServiceHubCredentialParser._parse_blobstore(item)
                for item in data["blobstore"]
            ]

        return credentials

class ServiceHubCredentialLoader:
    @staticmethod
    def load_credentials() -> ServiceHubCredentials:
        return ServiceHubCredentialParser.parse(os.getenv("ENSAAS_SERVICES"))