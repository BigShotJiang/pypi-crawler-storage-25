from __future__ import annotations
from typing import Optional
from dataclasses import dataclass

@dataclass
class Context:
    ts_tenant: str
    use_system_llm: Optional[bool] = None
    input: Optional[dict] = None
    ei_token: Optional[str] = None
    graph_name: Optional[str] = None
    files: Optional[list[dict]] = None
    config: Optional[dict] = None
