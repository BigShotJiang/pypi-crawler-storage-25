from langchain.agents import AgentState
from typing_extensions import Required


class InputState(AgentState):
    user_input: Required[str]