from langchain_core.messages import HumanMessage

from agent_api_server.middleware.schema import InputState
from agent_api_server.schema.context import Context
from agent_api_server.dynamic_llm.model import get_chat_model_instance
from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse, wrap_tool_call
from typing import Callable

class ModelMiddleware(AgentMiddleware[InputState]):
    state_schema = InputState

    def __init__(self, use_system_llm:bool=False):
        super().__init__()
        self.use_system_llm = use_system_llm

    async def abefore_agent(self,state: InputState) -> ModelRequest:
        human_message = [HumanMessage(content=state["user_input"])]
        return {
            "messages": [
                *state["messages"],
                *human_message
            ]
        }

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        context: Context = request.runtime.context
        if context.use_system_llm is None:
            context.use_system_llm = self.use_system_llm

        model_instance = get_chat_model_instance(context)

        model_settings = request.model_settings.copy()
        model_settings.pop("cache_control", None)

        return await handler(request.override(model=model_instance, model_settings=model_settings))

class ChangeModel(AgentMiddleware):
    def __init__(self, use_system_llm: bool = False):
        super().__init__()
        self.use_system_llm = use_system_llm

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        context: Context = request.runtime.context
        context.use_system_llm = self.use_system_llm

        model_instance = get_chat_model_instance(context)

        model_settings = request.model_settings.copy()
        model_settings.pop("cache_control", None)

        return await handler(request.override(model=model_instance, model_settings=model_settings))