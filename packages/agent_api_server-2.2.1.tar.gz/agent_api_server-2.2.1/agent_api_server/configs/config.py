from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv


class SSOConfig(BaseSettings):
    SSO_URL: str = Field(
        default="http://sso/v4.0", description="The URL of SSO service"
    )
    CLIENT_ID: str = Field(default="", description="The client-id of server")
    CLIENT_SECRET: str = Field(default="", description="The client secret of server")
    CLIENT_TOKEN: str = Field(default="", description="The client token of server")


class CacheConfig(BaseSettings):
    REDIS_URL: Optional[str] = Field(
        default="redis://localhost:6379/0",
        description="Redis server URL in format redis://host:port/db"
    )
    MAX_THREADS: int = Field(
        default=1000,
        description="Maximum number of threads for concurrent operations"
    )

class PostgresConfig(BaseSettings):
    POSTGRES_URL: Optional[str] = Field(
        default="postgresql://user:password@host:port/dbname",
        description="complete PostgresSQL URL，formater is：postgresql://user:password@host:port/dbname"
    )

    # 连接池参数
    POSTGRES_POOL_MIN_SIZE: int = Field(
        default=1,
        description="mini connection count for postgres"
    )

    POSTGRES_POOL_MAX_SIZE: int = Field(
        default=10,
        description="max connection count for postgres"
    )

    POSTGRES_POOL_TIMEOUT: float = Field(
        default=30.0,
        description="time out for postgres connection"
    )

    POSTGRES_POOL_RECYCLE: int = Field(
        default=3600,
        description="recycle time for postgres connection"
    )

    POSTGRES_POOL_MAX_INACTIVE: int = Field(
        default=600,
        description="inactive time for postgres"
    )

class LoggingConfig(BaseSettings):
    LOG_LEVEL: str = Field(
        default="INFO", description="Logging level for the application"
    )

class ModelManagerServiceConfig(BaseSettings):
    MODEL_MANAGER_SERVICE_URL: str = Field(
        default="https://api-am-ensaas.axa.wise-paas.com.cn", description="The URL of model manager service url"
    )

    SERVICE_EXTERNAL_URL: str = Field(
        default="http://172.21.84.86:8080", description="The URL of agent"
    )

    MODEL_MANAGER_REDIS_URL: str = Field(
        default="redis://localhost:6379/0", description="Redis server URL which used by model_manager, format is: redis://host:port/db"
    )

    MODEL_MANAGER_NATS_URL: str =  Field(
        default="", description="NATS server URL which used by model_manager, format is: nats://localhost:4222"
    )

class WebServerConfig(BaseSettings):
    SERVER_PORT: int = Field(
        default=8080, description="The port of web server"
    )

    SERVER_WORKER_AMOUNT: int = Field(
        default=1, description="The amount of web server."
    )

    AGENT_AUTO_REGISTRATION: bool = Field(
        default=False,
        description="Whether to enable automatic agent registration through API server. "
                    "If True, agents will be automatically registered via API. "
                    "If False, manual registration is required."
    )

    ENABLE_MCP_SERVER: bool = Field(
        default=False,
        description="Whether to enable mcp server"
    )

    MCP_SERVER_PORT: int = Field(
        default=8081, description="The port of mcp server"
    )

    MCP_SERVER_EXTERNAL_URL: str = Field(
        default="http://172.21.84.86:8081", description="The URL of agent"
    )

    MCP_GATEWAY_URL: str = Field(
        default="http://172.21.92.186:10105", description="The URL of MCP gateway"
    )


class ConfigCenterConfig(BaseSettings):
    ENABLE_CONFIG_CENTER: bool =Field(
        default=False, description="Whether to enable config center to get service information."
    )

    CONFIG_CENTER_ADDRESS: str = Field(
        default='', description="The URL of config center."
    )

class StorageConfig(BaseSettings):
    STORAGE_ENDPOINT: str =  Field(
        default='', description="The URL of storage(like: s3)."
    )

    ACCESS_KEY: str =  Field(
        default='', description="The access key of storage(like: s3)."
    )

    SECRET_KEY: str =  Field(
        default='', description="The secret key of storage(like: s3)."
    )


def find_and_load_dotenv(filename: str = '.env') -> Optional[str]:
    search_paths = [
        Path.cwd() / filename,
        Path(__file__).parent.parent / filename,
    ]

    for path in search_paths:
        if path.exists():
            load_dotenv(path, override=True)
            return str(path)

    for parent in Path.cwd().parents:
        candidate = parent / filename
        if candidate.exists():
            load_dotenv(candidate, override=True)
            return str(candidate)

    return None

class Config(PostgresConfig, CacheConfig, LoggingConfig, SSOConfig, WebServerConfig, ModelManagerServiceConfig, ConfigCenterConfig, StorageConfig):
    model_config = SettingsConfigDict(
        env_file=find_and_load_dotenv(),
        env_file_encoding="utf-8",
        extra="ignore",
    )

