from .config import Config

global_config = Config()