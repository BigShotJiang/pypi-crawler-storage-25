import logging
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from fastapi import HTTPException
from agent_api_server.shared.base_model import error_response
from agent_api_server.shared.util_func import get_all_graph_names

logger = logging.getLogger(__name__)
api_router = APIRouter()


@api_router.get(
    "/",
    responses={
        200: {
            "description": "Successfully returned list of available graphs",
            "content": {
                "application/json": {
                    "example": {
                        "graphs": ["Test_App", "iot_data_analyse"],
                        "count": 2
                    }
                }
            }
        },
        500: {"model": error_response, "description": "Internal server error"}
    },
    summary="Get all available graph names",
    response_description="List of available graph names"
)
async def get_available_graphs():
    """
    Get all available graph names defined in the configuration file.

    Returns:
        JSON response containing:
        - graphs: List of available graph names
        - count: Number of available graphs
    """
    try:
        graph_names = await get_all_graph_names()
        return JSONResponse(
            content={
                "graphs": graph_names,
                "count": len(graph_names)
            },
            status_code=200
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Failed to get graph names: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "error": "internal_server_error",
                "message": "Failed to retrieve graph names"
            }
        )