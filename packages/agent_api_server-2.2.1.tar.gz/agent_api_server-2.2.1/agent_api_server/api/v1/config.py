import logging
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from agent_api_server.shared.base_model import error_response
from agent_api_server.shared.util_func import load_graph_config, load_graph
from langgraph.graph.state import CompiledStateGraph

logger = logging.getLogger(__name__)
api_router = APIRouter()

@api_router.get(
    "/",
    responses={
        200: {
            "description": "Successfully returned config JSON Schema",
            "content": {"application/schema+json": {}}
        },
        400: {"model": error_response, "description": "Invalid graph instance"},
        422: {"model": error_response, "description": "Schema validation error"},
        500: {"model": error_response, "description": "Internal server error"}
    },
    summary="Get JSON Schema for graph_name"
)
async def get_config_schema(graph_name: str):
    try:
        graph_cfg = await load_graph_config()
        validated_name, graph_instance, _ = await load_graph(graph_name, graph_cfg, False)

        if not isinstance(graph_instance, CompiledStateGraph):
            raise error_response(
                status_code=400,
                error_type="invalid_graph",
                message="Graph instance type mismatch",
                graph_name=graph_name,
                actual_type=type(graph_instance).__name__
            )

        return JSONResponse(
            content=graph_instance.get_context_jsonschema(),
            media_type="application/schema+json",
        )
    except ValueError as ve:
        logger.error(f"Schema validation failed for {graph_name}: {str(ve)}", exc_info=True)
        raise error_response(
            status_code=422,
            error_type="schema_validation",
            message=str(ve),
            graph_name=graph_name
        )
    except Exception as e:
        logger.critical(f"Unexpected error in {graph_name}: {str(e)}", exc_info=True)
        raise error_response(
            status_code=500,
            error_type="internal_error",
            message=str(e),
            graph_name=graph_name
        )