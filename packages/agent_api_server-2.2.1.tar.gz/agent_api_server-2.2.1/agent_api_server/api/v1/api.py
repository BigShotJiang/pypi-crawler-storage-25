import os
from fastapi import APIRouter
from agent_api_server.api.v1.schema import api_router as schema_router
from agent_api_server.api.v1.thread import api_router as thread_router
from agent_api_server.api.v1.config import api_router as config_router
from agent_api_server.api.v1.graph import api_router as graph_router



api_router = APIRouter()
api_router.include_router(thread_router, prefix="/thread", tags=["thread"])
api_router.include_router(schema_router, prefix="/schema", tags=["schema"])
api_router.include_router(config_router, prefix="/config", tags=["config"])
api_router.include_router(graph_router, prefix="/graph", tags=["graph"])



@api_router.get("/health")
async def health_check(
):
    """Health check endpoint with connection pool verification"""
    return {
        "message": "Welcome to the LangGraph FastAPI Server!",
        "worker_pid": os.getpid(),
    }