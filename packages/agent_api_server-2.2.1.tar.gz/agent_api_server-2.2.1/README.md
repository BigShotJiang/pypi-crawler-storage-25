# agent-api-server

`agent-api-server` is a FastAPI-based API server for LangGraph agents. It exposes REST endpoints for thread, schema, graph, and runtime configuration management, and it serves a built-in web client from `/site`.

## Features

- FastAPI application factory for embedding or standalone deployment
- LangGraph-oriented API routes under `/api/v1`
- Built-in static client assets bundled in both sdist and wheel artifacts
- Redis-backed thread storage and PostgreSQL checkpoint integration
- Optional integration with config center, SSO, MCP, and model management services

## Requirements

- Python 3.11 to 3.13
- Redis
- PostgreSQL
- Access to all runtime dependencies declared in `pyproject.toml`

## Installation

Install from a package index that provides all required dependencies:

```bash
pip install agent-api-server
```

This project depends on `llm-sdk` and `model-manage-client`. If those packages are hosted on a private index in your environment, configure `pip` or Poetry to use that index before installation.

## Configuration

The server reads configuration from environment variables. Common settings include:

```env
REDIS_URL=redis://localhost:6379/0
POSTGRES_URL=postgresql://postgres:postgres@localhost:5432/postgres
MODEL_MANAGER_SERVICE_URL=http://127.0.0.1:10053
SERVER_PORT=8080
SERVER_WORKER_AMOUNT=1
LOG_LEVEL=INFO
ENABLE_MCP_SERVER=False
```

See `.env_example` for a more complete example.

## Running the server

Run the application with Uvicorn:

```bash
uvicorn agent_api_server.service:create_fastapi_app --factory --host 0.0.0.0 --port 8080
```

After startup:

- API root: `http://127.0.0.1:8080/api/v1`
- OpenAPI docs: `http://127.0.0.1:8080/docs`
- Built-in client: `http://127.0.0.1:8080/site`

## Build

Build source and wheel distributions with Poetry:

```bash
poetry build
```

## Repository

Source repository: <https://gitlab.wise-paas.com/openai/agent_api_server>
