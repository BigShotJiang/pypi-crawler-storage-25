from __future__ import annotations

import re
import os
import sys
import locale
import platform
import inspect
import textwrap
import traceback
import httpx
from pathlib     import Path
from textwrap    import dedent, fill
from typing      import Optional


#------------------------------------------------------------------------------

def formatException(e: Exception, indent='') -> str:
    t = type(e).__name__

    if isinstance(e, httpx.HTTPStatusError):
        parts = [t]

        req = e.request
        resp = e.response

        parts.append(f"{resp.status_code} {resp.reason_phrase}")
        parts.append(f"{req.method} {req.url}")

        try:
            body = resp.text.strip()
        except Exception:
            body = None

        msg = ": ".join([parts[0], ", ".join(parts[1:])])

        if body:
            msg += f"\nresponse_body: {body}"

    elif isinstance(e, httpx.HTTPError):
        parts = [t]
        req = getattr(e, "request", None)
        if req is not None:
            parts.append(f"{req.method} {req.url}")
        s = str(e).strip()
        if s:
            parts.append(s)
        msg = ": ".join([parts[0], ", ".join(parts[1:])]) if len(parts) > 1 else parts[0]

    elif isinstance(e, OSError):
        parts = [t]

        if getattr(e, "errno", None) is not None:
            parts.append(f"errno={e.errno}")

        if getattr(e, "strerror", None):
            parts.append(e.strerror)

        if getattr(e, "filename", None):
            parts.append(f"path={e.filename!r}")

        msg = ": ".join([parts[0], ", ".join(parts[1:])]) if len(parts) > 1 else parts[0]
    else:
        s = str(e).strip()
        msg = f"{t}: {s}" if s else t

    filename: Optional[str] = None
    lineno: Optional[int] = None

    tb = e.__traceback__
    if tb is not None:
        last = traceback.extract_tb(tb)[-1]
        filename = last.filename
        lineno = last.lineno

    if filename is not None and lineno is not None:
        msg += f"\n   filename:{filename}({lineno})"

    return bgnormstr(msg)


#------------------------------------------------------------------------------
def invokeCallbackWithContext(fn:Callable, context:dict) -> Any:
    if not fn:
        return None

    sig = inspect.signature(fn)

    args = []
    kwargs = {}

    for name, param in sig.parameters.items():
        if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
            raise Exception(bgnormstr(f"""
                invokeCallbackWithContext: callback function should not use *args or **kwargs.
                    function={fn!r}
                """))

        if name in context:
            value = context[name]
        elif param.default is not inspect.Parameter.empty:
            continue
        else:
            raise Exception(bgnormstr(f"""
                invokeCallbackWithContext: callback function has unsupported required parameter
                    Unknown name: '{name}'
                    Supported names: {', '.join(sorted(context))}
                function={fn!r}
                """))

        if param.kind == param.POSITIONAL_ONLY:
            args.append(value)
        elif param.kind in (param.POSITIONAL_OR_KEYWORD, param.KEYWORD_ONLY):
            kwargs[name] = value

    return fn(*args, **kwargs)



#------------------------------------------------------------------------------
def findLanguageFile(baseName:Path|str, *, lang:str|None=None, appName:str=None) -> Path|None:
    candidateFolders = getSuportFileSearchFolders(appName)

    baseName = Path(Path(baseName).name)

    if lang is None:
        lang = (locale.getlocale()[0] or "en_US").replace("_", "-")

    langParts = lang.split("-")
    candidateNames = []

    # helpNotation.en-US
    candidateNames.append(baseName.with_suffix(baseName.suffix + f".{lang}"))

    # helpNotation.en
    if langParts:
        candidateNames.append(baseName.with_suffix(baseName.suffix + f".{langParts[0]}"))

    # helpNotation
    candidateNames.append(baseName)

    for name in candidateNames:
        for folder in candidateFolders:
            candidate = folder / name
            if candidate.is_file():
                return candidate

    return None


#------------------------------------------------------------------------------
def getSuportFileSearchFolders(appName:str=None) -> list[Path]:
    appName = appName or Path(sys.argv[0]).name

    folders = [
        Path.cwd(),
        Path(sys.argv[0]).resolve().parent,
    ]

    if platform.system() == "Windows":
        appData = os.environ.get("APPDATA")
        programData = os.environ.get("PROGRAMDATA")

        if appData:
            folders.append(Path(appData) / appName)

        if programData:
            folders.append(Path(programData) / appName)

    else:
        folders.extend([
            Path.home() / ".config" / appName,
            Path("/etc") / appName,
            Path("/usr/local/share") / appName,
            Path("/usr/share") / appName,
        ])

    return folders


#------------------------------------------------------------------------------
class ExpectedException(Exception):
    def __init__(self, msg:str):
        super().__init__(msg)

#------------------------------------------------------------------------------
# Normalize the indenting of a multiline string. This allows defining inline multi
# line strings with indenting that matches the surrounding code
#
# Rules:
# - dedent the text
# - remove purely empty leading/trailing lines introduced by triple quotes
# - if the first or last remaining line is exactly "." or " " replace that
#   line with an empty line so callers can intentionally preserve a leading
#   or trailing blank line
# - add indent to each line
def bgnormstr(text:str|None, *, width:int=130, indent:str|int='', first:str|int|None=None, cont:str=None, debug=False) -> str | None:
    if text is None:
        return None
    if isinstance(indent, int):
        indent = ' '*indent
    if isinstance(first, int):
        first = ' '*first

    text = dedent(text)
    lines = text.splitlines()

    # Strip empty edge lines commonly introduced by triple-quoted strings.
    while lines and lines[0] == "":
        lines.pop(0)
    while lines and lines[-1] == "":
        lines.pop()

    # Sentinel lines to preserve an intentional blank line at either edge.
    dottedLine = re.compile(r"^\s*[.]\s*$")
    for i in range(0,len(lines)):
        if dottedLine.match(lines[i]):
            lines[i] = ""

    result = "\n".join(lines)
    result = wrap(result, width, leadingTxt=indent, firstLeadingTxt=first, cont=cont, debug=debug)

    return result

#------------------------------------------------------------------------------
def wrap(text:str, width:int, leadingTxt:str|int="", firstLeadingTxt:str|int|None=None, cont=None, debug=False) -> str:
    if isinstance(leadingTxt, int):
        leadingTxt = ' '*leadingTxt
    leadingTxt = leadingTxt or ''
    if isinstance(firstLeadingTxt, int):
        firstLeadingTxt = ' '*firstLeadingTxt

    out = []

    if not text or not isinstance(text,str):
        return ""

    wrapLeading = firstLeadingTxt if firstLeadingTxt is not None else leadingTxt
    for line in text.splitlines():
        if not line:
            out.append(wrapLeading)
            continue

        indentLen = len(line) - len(line.lstrip())
        indent = line[:indentLen]
        content = line[indentLen:]

        contentLines = textwrap.wrap(content, width=width)
        contentLinesCont = ''
        for line2 in contentLines:
            if debug:
                print(f"!!! wrapLeading='{wrapLeading}'")
            out.append(wrapLeading + indent + contentLinesCont + line2)
            contentLinesCont = cont or ''
            wrapLeading = leadingTxt

    if debug:
        print(f"")
        print(f"!!! width='{width}'")
        print(f"!!! leadingTxt='{leadingTxt}'")
        print(f"!!! firstLeadingTxt='{firstLeadingTxt}'")
        print(f"!!! cont='{cont}'")
        print("\n".join(out))
        print(f"!!!")

    return "\n".join(out)

_BASE62_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
_BASE62_LEN = len(_BASE62_ALPHABET)



################################################################################
### bgtrace mechanism

defaultTraceFile="/tmp/bgtrace.out"
_bgtraceFile = None

def bgtrace(msg:str):
    global _bgtraceFile
    if "bgTracingOn" in os.environ:
        parts = os.environ["bgTracingOn"].split(':')
        if parts[0] in ["on","file"]:
            if _bgtraceFile is None:
                destFilename = Path(parts[1] or defaultTraceFile)
                _bgtraceFile = open(destFilename, "a", buffering=1)  # line-buffered
            _bgtraceFile.write(msg + "\n")
