from __future__ import annotations

from typing  import Literal, Dict, Any, List
from types   import SimpleNamespace

from .bg_cliHelpers  import bgtrace, bgnormstr
from .bg_cliArgument import CliArgument

################################################################################
# A ParsingContext stores the context while parsing for either the real command
# execution or a bash completion run.
class ParsingContext:
    def __init__(self, argv:List[str], cliCmds:CliCmdTree, *, bcPos:int=0, argsNS:SimpleNamespace=None, errorFn=None, cli=None):
        self.argsNS = argsNS or SimpleNamespace()
        self.cliCmds = cliCmds
        self.errorFn = errorFn
        self.cli = cli

        self.argsNS.ctx = self

        # when doing bash completion bcPos is the argv index being completed
        self.bcPos = bcPos or 0
        self.bcType    = None
        self.bcCliCmd  = None
        self.bcCmdPath = None
        self.bcPosIdx  = None
        self.bcToken   = None

        # argvPos points to the argument currently being parsed
        self.argv = argv
        self.argvPos = 0

        # the first argv is the cmdName so pop it off
        self.argsNS.cmdName = self.pop()

        # cmdPath is a tuple of sub cmd tokens that represent where we are currently
        # at in the cmd tree. By the end of the argv list we should be at a terminal
        # subCmd
        self.cmdPath = None    # set by advanceCmdPos
        self.cliCmd = None  # set by advanceCmdPos
        self.advanceCmdPos(self.cliCmds[()])

        # within a cmd position, positional args this is the idex of the next
        # unresolved positional arg cliCmd.posSpecs[self.positionalIdx]
        self.positionalIdx = 0

        # when argvPos points to a token of short opts, this points the next short
        # opt letter to be processed
        self.shortOptIdx = 1

        # while parsing, if we encounter an option that is not valid at the current
        # cliCmd but is a valid option somewhere, we put it in pending and after
        # parsing check to see if its valid for any cliCmd in the chain
        self.pendingOpts = []

    def done(self):
        return self.argvPos >= len(self.argv)

    def peek(self) -> str:
        return self.argv[self.argvPos]

    def pop(self) -> str:
        token = self.argv[self.argvPos]
        self.argvPos += 1
        self.shortOptIdx = 1
        return token

    # True if performing bash completion
    def bcMode(self):
        return self.bcPos > 0

    def bcOnToken(self):
        return (self.bcPos > 0) and (self.bcPos == self.argvPos)

    def bcSetType(self, type:str):
        self.bcType = type
        self.bcCliCmd = self.cliCmd
        self.bcCmdPath = self.cmdPath
        self.bcPosIdx = self.positionalIdx
        self.bcToken = self.argv[self.bcPos]

    def bcGetPosSpec(self):
        if self.bcPosIdx < len(self.bcCliCmd.posSpecs):
            return self.bcCliCmd.posSpecs[self.bcPosIdx]
        return None


    def advanceCmdPos(self, newCmdParser:CliCommand, token=None):
        # this will determine the name of the var that contains the subCmdName
        # depending on the subCmdName activated it changes. It will end in *Cmd
        # Example: sessionsCmd='list'
        if newCmdParser.cmdPath:
            subCmdName = newCmdParser.cmdPath.leaf
            self.cliCmd.setCmdToken(subCmdName)
            setattr(self.argsNS, self.cliCmd.subCmdName, token)

            # when subCmdName is a catchall, we need to also set its value like a
            # positional arg
            if subCmdName.startswith('<'):
                setattr(self.argsNS, subCmdName.strip('<>'), token)

        self.cliCmd = newCmdParser
        self.cmdPath = self.cliCmd.cmdPath
        self.cliCmd.initNS(self.argsNS)

    def requiredPosArgsLeft(self):
        for i in range(self.positionalIdx, len(self.cliCmd.posSpecs)):
            if not self.cliCmd.posSpecs[i].optional:
                return True
        return False

    def shortOptHasMore(self) -> bool:
        token = self.peek()
        return token.startswith('-') and self.shortOptIdx < len(token)

    def shortOptPeek(self) -> str:
        token = self.peek()
        if not token.startswith('-'):
            raise Exception("Invariant violation. Treating non option as an option")
        if self.shortOptIdx < len(token):
            return token[self.shortOptIdx]
        else:
            return None

    def shortOptPop(self) -> str:
        optLetter = self.shortOptPeek()
        if optLetter is None:
            return None
        self.shortOptIdx += 1
        return '-'+optLetter

    def shortOptPopValue(self, optName) -> str:
        if self.shortOptHasMore():
            token = self.peek()
            value = token[self.shortOptIdx:]
            self.shortOptIdx = len(token)
            self.pop()
        else:
            self.pop()
            if self.bcOnToken():
                self.bcSetType("optvalue")
                self.bcOptInProgress = optName
            if self.done():
                self.errorFn(self.cmdPath, "Required option value missing")
            value = self.pop()
        return value

    def shortOptDone(self):
        if not self.shortOptHasMore():
            self.pop()


    ############################################################################
    ### Parsing

    #---------------------------------------------------------------------------
    def doParsing(self):

        # iterate through the argv processing each token. Because of options with
        # values and short option runs that can be combined, its not one iteration
        # per token. Its one action per iteration until the end of argv is reached
        while not self.done():
            self.doAdvanceOneToken()

        # we are at the end of the argv input. Check to see if we need to advance over
        # one or more default sub commands. A terminal cmdPath will not have any
        # getSubCommandNames
        self.doAdvanceDefaultCmds()

        # check to see if there are required positional args not specified
        if self.requiredPosArgsLeft():
            self.errorFn(self.cmdPath, bgnormstr(f"""
                Missing required argument.
                    {self.cliCmd.posSpecs[self.positionalIdx].name}
                """))

        # now we know the final subCmd, resolve any pending options
        self.commitPendingOptions()

        self.invokeFinalHits()

        return self

    #---------------------------------------------------------------------------
    def doHelpParsing(self):

        # iterate through the argv processing each token. Because of options with
        # values and short option runs that can be combined, its not one iteration
        # per token. Its one action per iteration until the end of argv is reached
        while not self.done():
            self.doAdvanceOneToken()

        # we dont do the default commands because we want to be able to show help
        # for branch cmds.
        #self.doAdvanceDefaultCmds()

        # now we know the final subCmd, resolve any pending options
        self.commitPendingOptions()

        self.invokeFinalHits()

        return self

    #---------------------------------------------------------------------------
    def doCompletionParsing(self):
        try:
            while not self.done():
                self.doAdvanceOneToken()
        except Exception as e:
            bgtrace(f"best effort cmdline parse error: {e}")

        try:
            self.commitPendingOptions()
        except Exception as e:
            bgtrace(f"best effort _commitPendingOptions error: {e}")

        try:
            self.invokeFinalHits()
        except Exception as e:
            bgtrace(f"best effort invokeFinalHits error: {e}")

    #---------------------------------------------------------------------------
    def doAdvanceOneToken(self):
        if self.peek().startswith('--'):
            self.doLongOption()
            return

        if self.peek().startswith('-'):
            self.doShortOption()
            return

        # positional args can be subCmd identifiers or positional args for the current subCmd

        if self.bcOnToken():
            self.bcSetType("cmdOrPos")

        # if the current cliCmd is not a leaf, the token must be a cmd token
        if not self.cliCmd.isLeaf():
            if self.cliCmds.getNextSubCmd(self.cmdPath, self.peek()):
                token = self.pop()
                self.advanceCmdPos(self.cliCmds.getNextSubCmd(self.cmdPath, token), token)
                return
            self.errorFn(self.cmdPath, bgnormstr(f"""
                Expected a sub command.
                    expected : {'|'.join(self.cliCmds.getSubCommandNames(self.cmdPath))}
                    got : {self.pop()}
                """))

        # now advance the positional arg of the active subcmd
        if self.positionalIdx < len(self.cliCmd.posSpecs):
            posArg = self.cliCmd.posSpecs[self.positionalIdx]
            token = self.pop()
            if posArg.remainder:
                token = [token]
                while not self.done():
                    token.append(self.pop())
            posArg.hit(token, self.argsNS, self, self.cli)
            self.positionalIdx += 1
            return

        self.errorFn(self.cmdPath, f"Too many arguments at '{self.pop()}'")

    #---------------------------------------------------------------------------
    def doLongOption(self):
        if self.bcOnToken():
            self.bcSetType("longopt")

        optName = self.pop()
        optVal = None
        if '=' in optName:
            optName, optVal = optName.split('=',1)

        if optName in self.cliCmd.optByAlias:
            optSpec = self.cliCmd.optByAlias[optName]
            whichOptSpec = "local"
        elif self.cliCmds.hasArg(optName):
            optSpec = self.cliCmds.getArg(optName)
            whichOptSpec = "global"
        else:
            self.errorFn(self.cmdPath, f"Unknown option '{optName}'")
            return "unknown"

        if optVal is None and optSpec.requiresValue:
            if self.bcOnToken():
                self.bcSetType("optvalue")
                self.bcOptInProgress = optName
            if self.done():
                self.errorFn(self.cmdPath, f"Required option value missing for {optName}")
            optVal = self.pop()

        if whichOptSpec == "local" or self.bcMode():
            optSpec.hit(optVal, self.argsNS, self, self.cli)
            return "done"
        else:
            self.pendingOpts.append((optName,optVal,optSpec,self.cliCmd))
            return "pending"

    #---------------------------------------------------------------------------
    def doShortOption(self):
        if self.bcOnToken():
            self.bcSetType("shortopt")

        optName = self.shortOptPop()
        if optName is None:
            self.pop()
            return
        optVal = None

        if optName in self.cliCmd.optByAlias:
            optSpec = self.cliCmd.optByAlias[optName]
            whichOptSpec = "local"
        elif self.cliCmds.hasArg(optName):
            optSpec = self.cliCmds.getArg(optName)
            whichOptSpec = "global"
        else:
            self.errorFn(self.cmdPath, f"Unknown option '{optName}'")
            return "unknown"

        if optSpec.requiresValue:
            optVal = self.shortOptPopValue(optName)
        else:
            self.shortOptDone()

        if whichOptSpec == "local" or self.bcMode():
            optSpec.hit(optVal, self.argsNS, self, self.cli)
            return "done"
        else:
            self.pendingOpts.append((optName,optVal,optSpec,self.cliCmd))
            return "pending"

    #---------------------------------------------------------------------------
    def doAdvanceDefaultCmds(self):
        done = False
        while not done and self.cliCmds.getSubCommandNames(self.cmdPath):
            foundDefault = False
            for anotherSub in self.cliCmds.getSubCommandNames(self.cmdPath):
                nextSubCmd = self.cliCmds.getNextSubCmd(self.cmdPath, anotherSub)
                if nextSubCmd.isDefault:
                    self.advanceCmdPos(nextSubCmd, anotherSub)
                    foundDefault = True
                    break
            if not foundDefault:
                done = True
                self.errorFn(self.cmdPath, bgnormstr(f"""
                    Missing required sub command.
                        {'|'.join(self.cliCmds.getSubCommandNames(self.cmdPath))}
                    """))


    #---------------------------------------------------------------------------
    def commitPendingOptions(self):
        # now we know the final subCmd, resolve any pending options
        for optName,optVal,optSpec,cliCmd in self.pendingOpts:
            subCmd = cliCmd
            found = False
            while not found and subCmd:
                if optName in subCmd.optByAlias.keys():
                    optSpec.hit(optVal, self.argsNS, self, self.cli)
                    found = True
                    continue
                subCmd = subCmd.parent
            if not found:
                self.errorFn(self.cmdPath, bgnormstr(f"""
                    Invalid option for this command. Its not valis in any position.
                        cmd   : {self.cmdPath}
                        option: {optName} {optVal or ""}
                    """))

    #---------------------------------------------------------------------------
    def invokeFinalHits(self):
        for hitFn in self.cliCmds.finalHitFns:
            CliArgument.invokeCallbackWithContext(hitFn, ctx=self, argsNS=self.argsNS, cli=self.cli)
