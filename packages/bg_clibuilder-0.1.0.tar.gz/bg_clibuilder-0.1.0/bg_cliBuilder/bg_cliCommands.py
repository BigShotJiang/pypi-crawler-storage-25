from __future__ import annotations

import textwrap
import os
import re
import sys
import inspect
from dataclasses     import dataclass, field
from collections.abc import MutableMapping, Iterator, Callable
from pathlib         import Path
from typing          import Literal, Dict, Any, List
from types           import SimpleNamespace

from .bg_cliArgument import CliArgument, PosArgument, OptArgument
from .bg_cliParsingContext import ParsingContext

################################################################################
# CmdPath represents the cli tokens that identify a sub cmd like "sessions create"
@dataclass(frozen=True)
class CmdPath:
    parts: tuple[str, ...] = ()
    leafMarkedDefault: bool = field(default=False, compare=False)

    def __init__(self, spec=()):
        leafMarkedDefault = False
        if isinstance(spec, str):
            parts = tuple(spec.split())
        elif isinstance(spec, CmdPath):
            parts = spec.parts
            leafMarkedDefault = spec.leafMarkedDefault
        else:
            parts = tuple(spec)
        leaf = parts[-1] if parts else ""
        if leaf.startswith('['):
            leafMarkedDefault = True
            parts = parts[0:-1] + (leaf.strip('[]'),)
        object.__setattr__(self, "parts", tuple(parts))
        object.__setattr__(self, "leafMarkedDefault", leafMarkedDefault)

    @property
    def displayName(self) -> str:
        if self.leafMarkedDefault:
            return ' '.join(self.parent) + f" [{self.leaf}]"
        else:
            return ' '.join(self)

    # path navigation properties
    def child(self, token:str) -> "CmdPath": return CmdPath(self.parts + (token,))
    @property
    def parent(self) -> "CmdPath": return CmdPath(self.parts[:-1])
    @property
    def leaf(self) -> str | None:  return self.parts[-1] if self.parts else None
    @property
    def depth(self) -> int:        return len(self.parts)
    @property
    def isRoot(self) -> bool:      return not self.parts

    def startswith(self, other: "CmdPath") -> bool: return self.parts[:len(other.parts)] == other.parts

    # iteration of parts
    def __iter__(self):            return iter(self.parts)
    def __len__(self):             return len(self.parts)
    def __getitem__(self, idx):    return self.parts[idx]

    # iteration of (one,), (one,two), (one,two,three) ...
    def prefixes(self, start=1):
        for i in range(start, len(self.parts) + 1):
            yield CmdPath(self.parts[:i])

    # formating
    def __str__(self):             return " ".join(self.parts)
    def __format__(self, spec):    return format(str(self), spec)


type CmdPathLike = str | tuple[str, ...] | CmdPath

################################################################################
# A CliCommand instance exists for each multilevel command leaf.
class CliCommand:
    def __init__(self, cmdPath:CmdPathLike, parent:CliCommand, helpText:str|None=None):
        self.cmdPath = CmdPath(cmdPath)
        self.parent = parent
        self.helpText = helpText
        self.posSpecs = []
        self.optSpecs = []
        self.optByAlias = {}
        self.cmdToken = None
        self.isDefault = self.cmdPath.leafMarkedDefault
        self.nextSubCmdNames = None

    @property
    def displayName(self) -> str:
        if not self.cmdPath:
            return ""
        return self.cmdPath.displayName

    @property
    def usage(self) -> str:
        return (f"{self.displayName} "
               f"{' '.join(f"{s.usage}" for s in self.optSpecs)} "
               f"{' '.join(s.usage for s in self.posSpecs)}")

    @property
    def key(self):
        return self.cmdPath

    def isLeaf(self) -> bool:
        if self.nextSubCmdNames is None:
            raise Exception("CliCommand: Can not use isLeaf during syntaxt construction ")
        return not bool(self.nextSubCmdNames)

    @property
    def subCmdName(self) -> str:
        if self.parent is None:
            return "rootCmd"
        return f"{self.parent.cmdToken.strip('<>')}Cmd"

    def addArgs(self, arg:CliArgument) -> None:
        if isinstance(arg, PosArgument):
            self.posSpecs.append(arg)
        elif isinstance(arg, OptArgument):
            self.optSpecs.append(arg)
            for name in arg.names:
                self.optByAlias[name] = arg

    def setCmdToken(self, token:str):
        self.cmdToken = token

    def initNS(self, argsNS):
        for argSpec in self.optSpecs + self.posSpecs:
            if argSpec.varName not in vars(argsNS):
                setattr(argsNS, argSpec.varName, argSpec.default)

    def printDump(self):
        print(f"cmdPath    : {self.cmdPath!r}")
        print(f"parent     : {self.parent!r}")
        print(f"helpText   : {self.helpText!r}")
        print(f"posSpecs   : {self.posSpecs!r}")
        print(f"optSpecs   : {self.optSpecs!r}")
        print(f"optByAlias : {self.optByAlias!r}")
        print(f"cmdToken   : {self.cmdToken!r}")
        print(f"isDefault  : {self.isDefault!r}")
        print(f"nextSubCmdNames : {self.nextSubCmdNames!r}")

    def __str__(self):
        return f"CliCommand: {self.cmdPath}"

    def __repl__(self):
        return f"CliCommand: {self.cmdPath} pos={self.posSpecs} opt={self.optSpecs}"



################################################################################
# A CliCommand instance exists for each multilevel command leaf.
class CliCmdTree(MutableMapping):
    @staticmethod
    def looksLike(token:str, nextToken:str=None) -> str:
        if token.startswith("-"):
            return "OPT"
        elif token.startswith("<"):
            if nextToken and CliCmdTree.looksLike(nextToken) == "CMD":
                return "CMD"
            else:
                return "POS"
        else:
            return "CMD"

    # sessions create
    @classmethod
    def fromSpec(cls, spec:str, extraArgs:CliArgsLike=None) -> tuple[CmdPath, List[CliArgument]]:
        cmdPath = CmdPath()
        args = []
        posArgs = []
        tokens = spec.split()
        for i, token in enumerate(tokens):
            nextToken = tokens[i+1] if (i+1) < len(tokens) else None
            match CliCmdTree.looksLike(token, nextToken):
              case "CMD":
                # if we had collected any pos-like tokens, now we know they were
                # really catchall subcmd tokens because a cmd token followed them
                while posArgs:
                    cmdPath = cmdPath.child(posArgs.pop(0))
                cmdPath = cmdPath.child(token)
              case "OPT":
                args.append(token)
              case "POS":
                posArgs.append(token)
        args.extend(posArgs)
        if extraArgs is not None:
            if isinstance(extraArgs, list):
                args.extend(extraArgs)
            else:
                args.append(extraArgs)
        return (cmdPath, args)

    def __init__(self, *, cmdName:str=None, helpText:str=None):
        self.cmds:dict[CmdPath,CliCommand] = {CmdPath(): CliCommand(CmdPath(), None, helpText)}
        self.argsByKey = {}    # (no dupes) opts and pos args by key. used for iteration
        self.argsByAlias = {}  # (dupes) a map of all arg names regardless of position and sub cmd
        self.finalHitFns = []
        self.cmdName = cmdName

        # this sets the actual invoked cmdName from parsing the cmdline. The one
        # passed into this __init__ is from the code and will normally be correct
        def setCmdName(args):
            nonlocal self
            self.cmdName = Path(args.cmdName).name
        self.addFinalHitFn(setCmdName)


    #---------------------------------------------------------------------------
    # This will create a new {cpath: cliCmd} for cmdPath and all its parents
    # The helpText will only be applied to cmdPath, not its parents. If cmdPath
    # exists, helpText will only be added if it was None
    def ensureCommandPath(self, cmdPath:CmdPathLike, *, helpText=None):
        cmdPath = CmdPath(cmdPath)

        for cmdToken in cmdPath:
            if cmdToken.startswith('<'):
                if cmdToken not in self.argsByKey:
                    posArg = PosArgument(cmdToken)
                    self.argsByKey[posArg.key] = posArg
                    self.argsByAlias[posArg.name] = posArg


        parent = self.cmds[CmdPath()]
        for path in cmdPath.prefixes():
            if path != cmdPath:
                if path not in self.cmds:
                    self.cmds[path] = CliCommand(path, parent)
                parent = self.cmds[path]

        if cmdPath not in self.cmds:
            self.cmds[cmdPath] = CliCommand(cmdPath, parent, helpText)
        else:
            self.cmds[cmdPath].helpText = self.cmds[cmdPath].helpText or helpText
            if cmdPath.leafMarkedDefault:
                self.cmds[cmdPath].isDefault = True

    #---------------------------------------------------------------------------
    # this can be used to add arguments to a cmdPath. If an argument already exists
    # the non-None attributes will be merged into the existing attributes. The names
    # of all arguments are global so an arg "<sessionID>" used anywhere in the cli
    # will have the same attributes
    def addArgForPath(self, cmdPath:CmdPathLike, oneOrMoreArgsLike:CliArgsLike, **kwargs):
        cmdPath = CmdPath(cmdPath)
        argList = CliArgument.resolveArgListLike(oneOrMoreArgsLike, **kwargs)

        cliCmd = self.cmds[cmdPath]

        for oneArg in argList:
            # make index so we can lookup regardless of subcmd
            if oneArg.key in self.argsByKey:
                self.argsByKey[oneArg.key].merge(oneArg)
                oneArg = self.argsByKey[oneArg.key]
            else:
                self.argsByKey[oneArg.key] = oneArg

            for name in oneArg.names:
                self.argsByAlias[name] = oneArg

            cliCmd.addArgs(oneArg)


        if cliCmd.isDefault:
            self.addArgForPath(cmdPath.parent, argList)


    # final hit functions get called after the last argv token has been consumed
    # this is used by features like projectRoot so that it has the final parsed
    # state before it runs.
    def addFinalHitFn(self, hitFn:Callable):
        self.finalHitFns.append(hitFn)

    #---------------------------------------------------------------------------
    # this declares that all the methods to build up the cli syntax have been called
    # Some things are easier to do after we have all the info
    def finalizeBuild(self):
        for cmdPath, cliCmd in self.cmds.items():
            cliCmd.nextSubCmdNames = self.getSubCommandNames(cmdPath)


    #---------------------------------------------------------------------------
    # return the cmd choices after cmdPath
    def getSubCommandNames(self, cmdPath:CmdPathLike) -> List[str]:
        cmdPath = CmdPath(cmdPath)
        nextPos = cmdPath.depth
        return list(dict.fromkeys(
            path[nextPos]
            for path in self.cmds.keys()
                if path.depth > nextPos
                    and path.startswith(cmdPath)
        ))

    #---------------------------------------------------------------------------
    # get the next subcmd of cmdPath identified by nextToken if it exists or None
    # parsing uses this to determine if nextToken is a cmd token or a posiitional arg
    def getNextSubCmd(self, cmdPath:CmdPathLike, nextToken) -> CliCommand|None:
        cmdPath = CmdPath(cmdPath)
        # sometimes when doing bash completion, it sends ''
        if not nextToken:
            return None

        nextTry = cmdPath.child(nextToken)
        if nextTry in self.cmds:
            return self.cmds[nextTry]

        for subCmdToken in self.getSubCommandNames(cmdPath):
            if subCmdToken.startswith('<'):
                return self.cmds[cmdPath.child(subCmdToken)]
        return None


    #---------------------------------------------------------------------------

    # given a cmdPath, return all option str that are valid for it and any of its parents
    # bash completion uses this to provide suggested options
    def getValidOptionNamesFor(self, cmdPath:CmdPath) -> List[str]:
        cliCmd = self.cmds[cmdPath]
        optionSet = set()
        while cliCmd is not None:
            for optName in cliCmd.optByAlias.keys():
                optionSet.add(optName)
            cliCmd = cliCmd.parent
        return list(optionSet)

    # format one cmd in usage syntax
    def getUsage(self, cmdPath:CmdPathLike) -> str:
        cmdPath = CmdPath(cmdPath)
        return f"{self.cmdName} {self.cmds[cmdPath].usage} "

    def hasArg(self, name) -> bool:
        return name in self.argsByAlias

    def getArg(self, name) -> CliArgument:
        return self.argsByAlias[name]

    #--------------------------------------------------------------------------
    # iterate all defined postional arguments

    def allPosArgsKeys(self) -> Iterator[str]:
        for key, arg in self.argsByKey.items():
            if isinstance(arg,PosArgument):
                yield key
    def allPosArgsValues(self) -> Iterator[PosArgument]:
        for key, arg in self.argsByKey.items():
            if isinstance(arg,PosArgument):
                yield arg
    def allPosArgsItems(self) -> Iterator[tuple[str,PosArgument]]:
        for key, arg in self.argsByKey.items():
            if isinstance(arg,PosArgument):
                yield (key,arg)

    #--------------------------------------------------------------------------
    # iterate all defined optional arguments

    def allOptArgsKeys(self) -> Iterator[str]:
        for key, arg in self.argsByKey.items():
            if isinstance(arg,OptArgument):
                yield key
    def allOptArgsValues(self) -> Iterator[OptArgument]:
        for key, arg in self.argsByKey.items():
            if isinstance(arg,OptArgument):
                yield arg
    def allOptArgsItems(self) -> Iterator[tuple[str,OptArgument]]:
        for key, arg in self.argsByKey.items():
            if isinstance(arg,OptArgument):
                yield (key,arg)

    #--------------------------------------------------------------------------
    # iterate leaf commands (no subcommands)

    def leafKeys(self) -> Iterator[CmdPath]:
        for cmdPath in self.keys():
            if not self.getSubCommandNames(cmdPath):
                yield cmdPath
    def leafValues(self) -> Iterator[CliCommand]:
        for cmdPath, cmd in self.items():
            if not self.getSubCommandNames(cmdPath):
                yield cmd
    def leafItems(self) -> Iterator[tuple[CmdPath, CliCommand]]:
        for cmdPath, cmd in self.items():
            if not self.getSubCommandNames(cmdPath):
                yield (cmdPath, cmd)


    #--------------------------------------------------------------------------
    # iterate branch commands (has subcommands)

    def branchKeys(self) -> Iterator[CmdPath]:
        for cmdPath in self.keys():
            if self.getSubCommandNames(cmdPath):
                yield cmdPath
    def branchValues(self) -> Iterator[CliCommand]:
        for cmdPath, cmd in self.items():
            if self.getSubCommandNames(cmdPath):
                yield cmd
    def branchItems(self) -> Iterator[tuple[CmdPath, CliCommand]]:
        for cmdPath, cmd in self.items():
            if self.getSubCommandNames(cmdPath):
                yield (cmdPath, cmd)

    #--------------------------------------------------------------------------
    # dict-like behavior (MutableMapping)
    def __iter__(    self) -> Iterator[CmdPath]:               return iter(self.cmds)
    def __len__(     self) -> int: return len(self.cmds)
    def __setitem__( self, cmdPath:CmdPathLike, cmd: CliCommand) -> None: self.cmds[CmdPath(cmdPath)] = cmd
    def __getitem__( self, cmdPath:CmdPathLike) -> CliCommand: return self.cmds[CmdPath(cmdPath)]
    def __delitem__( self, cmdPath:CmdPathLike) -> None:       del self.cmds[CmdPath(cmdPath)]
    def __contains__(self, cmdPath:CmdPathLike) -> bool:       return CmdPath(cmdPath) in self.cmds
    def get(         self, cmdPath:CmdPathLike, default=None): return self.cmds.get(CmdPath(cmdPath), default)
