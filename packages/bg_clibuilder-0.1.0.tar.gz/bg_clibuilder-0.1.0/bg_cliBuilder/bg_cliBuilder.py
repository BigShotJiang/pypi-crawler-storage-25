from __future__ import annotations

import textwrap
import os
import re
import sys
import pwd
import shlex
import asyncio
import subprocess
from collections.abc import Callable
from pathlib         import Path
from typing          import Literal, Dict, Any, List
from types           import SimpleNamespace

from .bg_cliHelpers import bgnormstr, ExpectedException, findLanguageFile, bgtrace, formatException
from .bg_cliArgument import CliArgument, pos, opt
from .bg_cliParsingContext import ParsingContext
from .bg_cliCommands import CmdPath,CmdPathLike, CliCommand, CliCmdTree


# pass through the tool and tArg annotations because when you create a LLMApp
# subclass you should be declaring tools.
__all__ = [
    "pos",
    "opt",
    "CliBuilder",
]


################################################################################
# CliBuilder - This implements a DSL for declaring the command line syntax of a
# command line application. The cli is organized into one or more sub commands,
# each accepting a specific set of optional and positional arguments.
#
# CmdPaths:
# The first argument to cli.cmd() is a str containing 0 or more space separated tokens.
# When all the cli.cmd() calls are taken together they form a command tree. For example
# all the first tokens form the choices that the user can specify in the first positional
# argument of the command line. As the user specifies each sub command position they
# identify the terminal sub command that will be invoked. Once a terminal sub command
# is identified, subsequent positional arguments are assigned to the arguments of the
# sub command.
#
# After parsing, the <name>Cmd variables will be set with the choices that identify the
# selected sub command.
#   * cli.rootCmd : the first sub command level is hardcoded to this name.
#   * cli.<token>Cmd : subsequent levels will have the name of the previous levels value.
#          e.g. if rootCmd=="classes" then cli.classesCmd will contain the second level.
#
# Default Sub Command:
# At each sub command position one token can be surrounded by []. (e.g. [list]).
# This indicates the default sub command that will be matched when the user does
# not specify a token for that sub command. Any further sub command positions (if any)
# must also have defaults.
#
# Dynamic Sub Command:
# At each cmd position, there can be one choice surrounded by <>. (e.g. <varName>).
# This indicates a dynamic sub command path that will be matched when the token
# entered byt the user does not match any static token for that position.
#  1) The cli.varName variable's value will be set to the token
#  2) The subcommand path <varName> will be selected for the purpose of identifying
#     the sub command to invoke.
#
# Optional Arguments:
# This refers to arguments that start with '-'. (as opposed to positional arguments
# that can be omitted because they have default values).
#
# Options can be added to both terminal and non-terminal command positions. The set
# of valid options is determined by the union of options from the terminal sub command
# and all of its command position parents.
#
# A valid option can be specified anywhere on the command line not just at the position
# where it is defined.
#
# Parsed Namespace:
# Variables corresponding to all arguments and sub command positions of the selected
# sub command are availble for the program to use in cli.argsNS.<varName>. Variables that do
# not collide with members of the CliBuilder class can be accessed directly like
# cli.<varName>
#
# Argument Grammar:
#   [name]                       positional string, required
#   [name:type]                  positional with type
#   [name:type?=default]          optional positional
#   [name:{a|b|c}]                choices
#   [name:...]                    argparse.REMAINDER
#
#   --flag                       boolean store_true
#   --name:type                  option with value
#   --name:type=default           option with default
#   -a|--long                    aliases
#   -v|--verbose:+               count/increment
#   -q|--quiet:-                 count/decrement, if you support that behavior
#
# Argument Examples:
#   "mode:{production|toy}"
#   "n:int?=1"
#   "instructions:... "
#   "--modelID"
#   "--agentClass?"
#   "-C|--pwd:Path=."
#   "-v|--verbose:+"
#   "-q|--quiet:-"
#
# Example:
#   cli = CliBuilder(prog="bg-agent",
#                   description="bg-agent CLI",
#                   usage="",
#                   args = [
#                       opt("--pwd", "-C", dest="pwd", type=Path, default=Path.cwd()),
#                       opt("-v", "--verbose", action="count", default=0),
#                       opt("-q", "--quiet", action="count", default=0),
#                   ]
#               )
#
#   cli.cmd("init")
#   cli.cmd("sessions    list" )
#   cli.cmd("sessions    create"     , args=[pos("agentClass"),pos("sessionID")])
#   cli.cmd("classes     list" )
#   cli.cmd("upstreams   list"       , args=[opt("--agentClass")])
#   cli.cmd("models      list"       , args=[opt("--agentClass")])
#   cli.cmd("apps        list"       , args=[opt("--agentClass")])
#   cli.cmd("captured"               , args=[pos("idx", type=int)])
#   cli.cmd("<sessionID> reset")
#   cli.cmd("<sessionID> undo"       , args=[pos("n", type=int, nargs="?", default=1)])
#   cli.cmd("<sessionID> tools list")
#   cli.cmd("<sessionID> tools call" , args=[pos("toolName"),  pos("argsJsonStr")])
#   cli.cmd("<sessionID> info")
#   cli.cmd("<sessionID> journal")
#   cli.cmd("<sessionID> context"    , args=[pos("interactionSpec", nargs="?", default="-1")])
#   cli.cmd("<sessionID> apps"       , args=[pos("interactionSpec", nargs="?", default="-1")])
#   cli.cmd("<sessionID> data"       , args=[pos("interactionSpec", nargs="?", default="-1")])
#   cli.cmd("<sessionID> convo"      , args=[pos("interactionSpec", nargs="?", default="-1")])
#   cli.cmd("<sessionID> run", args=[
#       opt("--modelID"),
#       pos("instructions", nargs=CliBuilder.REMAINDER),
#   ])
#
#   # note that you dont need to capture the namespace returned by parseArgs (aka parse_args)
#   # because cli exposes that namespace of parsed argument values.
#   cli.parseArgs(argv)
#
#   match cli.rootCmd:
#      ...
#     case "sessions":
#        match cli.sessionCmd:
#            ...
class CliBuilder:
    current: "CliBuilder|None" = None

    def __init__(self, prog:str|None=None, *, args:list|None=None, helpText=None, helpNotation=None):
        self.prog = prog
        self.helpText = helpText
        self.cliCmds = CliCmdTree(cmdName=self.prog, helpText=helpText)
        self.features = {}

        # we support overriding the builtin helpNotion by reading from language files
        # set system locale.getlocale() to change the language searched
        self.helpNotation = self._getHelpData(helpNotation)
        self.helpData = parseHelpNotation(self.helpNotation)
        self.helpLang = "en-US" # the langauage of the builtin helpNotation is assumed to be


        self.cliCmds.addArgForPath((), args)

        self.enableHelpFeature()
        self.enableBashCompletionInstallFeature()

        CliBuilder.current = self

    #---------------------------------------------------------------------------
    # Instances of this class act like
    #   1) the parsed arguments (returned by parse_args) and
    #   2) the underlying argparse.ArgumentParser
    # So the CLI author can work with this object like both of those classes combined
    # The parsed argument namespace is only available after parseArgs is called
    def __getattr__(self, name):
        ns = self.__dict__.get("argsNS")
        if ns is not None and name in vars(ns):
            return getattr(ns, name)

        raise ExpectedException(bgnormstr(f"""
                CliBuilder: unknown attribute. The code expects '{name}' to be an argument
                but the parser config in the command did not declare it for this command.
            """))

    ############################################################################
    ### Building Methods

    #---------------------------------------------------------------------------
    # This is the main entry point for declaring the syntax of a cli program.
    # cmdPath identifies a nested sub cmd and the args list defines the optional
    # and positional arguments that the sub cmd accepts.
    #
    # Example:
    #   cli.cmd("sessions list" )
    #   cli.cmd("sessions create", args=["--modelID <id>", "<agentClass>","<sessionID>"])
    #
    # Params:
    #    cmdPath : a string of space separated tokens the user can specify to
    #        select this sub command. If a token is surrounded by <> it signifies the
    #        default for that token position so that when the user enters a token that
    #        does not match any known token, it will 1) set that token as the value for
    #        <varName> and 2) select this sub command path to determine the terminal
    #        sub command.
    #    args : a list of argument specifications (argSpec). Each argSpec can be either
    #        a string using the argument specification notation or a dict that specifies
    #        the attributes supported by the CliArgument class. See class CliArgument
    #        for details on the str notation and attributes.
    def cmd(self, cmdPath:CmdPathLike, *, args:CliArgsLike=None, helpText:str|None=None):
        # if isinstance(cmdPath, str) and ('<' in cmdPath or '-' in cmdPath):
        #     cmdPath, args = self.cliCmds.fromSpec(cmdPath.strip(), extraArgs=args)

        cmdPath = CmdPath(cmdPath)
        # if not cmdPath:
        #     raise ValueError("CliBuilder.cmd: <cmdPath> argument must not be empty")

        self.cliCmds.ensureCommandPath(cmdPath, helpText=helpText)
        self.cliCmds.addArgForPath(cmdPath, args)
        return self

    def cmds(self, text:str):
        for line in text.splitlines():
            line = line.strip()
            if line:
                cmdPath, args = self.cliCmds.fromSpec(line.strip())
                self.cmd(cmdPath, args=args)

    def addTo(self, argName, **kwargs):
        if not self.cliCmds.hasArg(argName):
            raise Exception(f"CliBuilder.addTo: argument name ({argName}) not found")
        self.cliCmds.getArg(argName).mergeParams(kwargs)

    # alias for addTo(argName, completer=completerFn)
    def addCompleter(self, argName, completerFn):
        if not self.cliCmds.hasArg(argName):
            raise Exception(f"CliBuilder.addCompleter: argument name ({argName}) not found")
        self.cliCmds.getArg(argName).completer = completerFn

    def addFinalHitFn(self, hitFn:Callable):
        self.cliCmds.addFinalHitFn(hitFn)

    def enableBashCompletionInstallFeature(self):
        self.features["verbosity"] = True
        self.cliCmds.addArgForPath((), "--installBashCompletion", hitFn=installBashCompletion, helpText="make bash completion work for this command")


    def enableVerbosityFeature(self):
        self.features["verbosity"] = True
        self.cliCmds.addArgForPath((), "-v|--verbose:+", varName="verbosity", helpText="Increase the the command's output. More v's, more output.")
        self.cliCmds.addArgForPath((), "-q|--quiet:-",   varName="verbosity", helpText="Decrease the the command's output. More q's, less output.")

    def enablePwdFeature(self):
        self.features["pwd"] = True
        def doRwdFeature(argsNS):
            if argsNS.pwd:
                os.chdir(argsNS.pwd)
        self.cliCmds.addArgForPath((), "--pwd|-C:Path=.", completer="$(_filedir)", hitFn=doRwdFeature, helpText="Run the command with the current folder specified")

    def enableFindProjectRootFeature(self, typeFolder:Path|str):
        typeFolder = Path(typeFolder)
        self.features["FindProjectRoot"] = typeFolder
        def doFindProjectRoot():
            nonlocal self
            if "FindProjectRoot" in self.features:
                self.argsNS.projectRoot = None
                self.argsNS.projectFolder = None
                p = Path.cwd()
                for folder in [p, *p.parents]:
                    if (folder / self.features["FindProjectRoot"]).is_dir():
                        self.argsNS.projectRoot = folder
                        self.argsNS.projectFolder = folder
                        break
        self.cliCmds.addFinalHitFn(doFindProjectRoot)

    def enableHelpFeature(self):
        self.features["help"] = True
        def doHelpFeature(ctx):
            nonlocal self
            if ctx.bcPos == 0:  # not in bash completion
                self.printHelp(ctx=ctx)
                sys.exit(0)
        self.cliCmds.addArgForPath((), "--help|-h", helpText="Show help", hitFn=doHelpFeature)

        def doHelpCreate(ctx):
            nonlocal self
            if ctx.bcPos == 0:  # not in bash completion
                self._createHelpDataFile()
                sys.exit(0)
        self.cliCmds.addArgForPath((), "--helpCreateFile", helpText="create a file in the PWD for translation", hitFn=doHelpCreate)


    # This is called automatically at the start of parseArgs to finalize the sctructure
    # before parsing. We allow structure building in a flexible order so sometimes we
    # have to wait until all the building method calls are made before creating the
    # structure for parsing.
    def finalizeBuild(self):
        self.helpText = self.helpText or self.helpData["helpText"]

        for cmdPath, text in self.helpData["cmds"].items():
            if not cmdPath in self.cliCmds:
                raise Exception(f"CliBuider: [cmd:{cmdPath}] referenced in helpNotation does not exist. cmdPath='{cmdPath}'")
            self.cliCmds[cmdPath].helpText = text

        for argName, text in self.helpData["args"].items():
            if not self.cliCmds.hasArg(argName):
                raise Exception(f"CliBuider: [arg:argName] referenced in helpNotation does not exist. argName='{argName}'")
            self.cliCmds.getArg(argName).helpText = self.cliCmds.getArg(argName).helpText or text

        for optName, text in self.helpData["opts"].items():
            if not self.cliCmds.hasArg(optName):
                raise Exception(f"CliBuider: [opt:optName] referenced in helpNotation does not exist. optName='{optName}'")
            self.cliCmds.getArg(optName).helpText = self.cliCmds.getArg(optName).helpText or text

        self.cliCmds.finalizeBuild()




    ############################################################################
    ### Parsing

    #---------------------------------------------------------------------------
    # Call this to pass in the actual cmdline args to parse and to finallize the
    # syntaxt building. All building method calls must be done before this call.
    # When argv is None it retrieves them from sys.argv
    def parseArgs(self, argv=None, argsNS=None):
        argv = argv or sys.argv
        self.argsNS = argsNS or SimpleNamespace()
        self.finalizeBuild()

        bcPos = None
        if argv and len(argv)>1 and argv[1] == "-hbOOBCompGen":
            mode = "completion"
            bcPos = int(argv[2])
            argv = argv[3:]
        elif any(arg in ("-h", "--help") for arg in argv):
            mode = "help"
        else:
            mode = "normal"

        errorFn = self.cmdLineError if mode=="normal" else self.bgtraceError

        ctx = ParsingContext(   argv,
                                self.cliCmds,
                                argsNS=self.argsNS,
                                errorFn=errorFn,
                                bcPos=bcPos,
                                cli=self
                            )

        match mode:
          case "normal":
            ctx.doParsing()

          case "help":
            ctx.doHelpParsing()

          case "completion":
            # doCompletionParsing is tolerant to malformed args since its in progress
            ctx.doCompletionParsing()
            self._outputBGBCStyleCompletion(ctx)

        return self.argsNS

    #---------------------------------------------------------------------------
    def _outputBGBCStyleCompletion(self, ctx:ParsingContext):
        # given the current ctx.cmdPath, get all the options that it can accept
        # as the user completes the cmdline ctx.cmdPath will resolve.
        validOptions = self.cliCmds.getValidOptionNamesFor(ctx.cmdPath)

        bgtrace(f"!!! parser dump ctx.cmdPath='{ctx.cmdPath}'")
        for partCmdPath in ctx.cmdPath.prefixes(0):
            partCmd = self.cliCmds[partCmdPath]
            bgtrace(f"  prefix='{partCmdPath:30}' : {partCmd.usage}")
            for argSpec in partCmd.optSpecs + partCmd.posSpecs:
                argSpec.bgtrace("    ")


        match ctx.bcType:

          case "cmdOrPos":
            # if there are valid sub cmd choices add them
            bcList = ctx.bcCliCmd.nextSubCmdNames
            if bcList:
                print( f"<subcmd> {bcToWords(bcList)}")

            # If there is a <catchall> choice, add its suggestions
            catchAllChoice = next((s for s in bcList if s.startswith("<") and s.endswith(">")),None,)
            if catchAllChoice:
                self.cliCmds.getArg(catchAllChoice).printCompletions(ctx, self)

            # before the user starts entering a token, let them know that options
            # are available if they enter a '-'.
            # We dont show the options because often there are many which overwhelms
            if validOptions and not ctx.bcToken:
                print("<optsAvail>")

            # if there is a postional arg, add its suggestions
            posSpec = ctx.bcGetPosSpec()
            if posSpec:
                posSpec.printCompletions(ctx, self)

          case "longopt"|"shortopt":
            print(f"{bcToWords(validOptions)}")

          case "optvalue":
            print("<optArg>")
            optSpec = self.cliCmds.getArg(ctx.bcOptInProgress)
            optSpec.printCompletions(ctx, self)

        sys.exit(0)



    ############################################################################
    ### Post-Parsing User Interface

    #---------------------------------------------------------------------------
    def error(self, message:str):
        self.cmdLineError(self.ctx.cmdPath, message)

    #---------------------------------------------------------------------------
    def cmdLineError(self, cmdPath:CmdPathLike, message):
        print(f"*** CLI Parse: {message}\n", file=sys.stderr)
        if cmdPath:
            print(f"Usage:", file=sys.stderr)
            self.printUsage(cmdPath)
            print(f"", file=sys.stderr)
        sys.exit(2)

    #---------------------------------------------------------------------------
    def bgtraceError(self, cmdPath:CmdPathLike, message):
        bgtrace(f"\n*** ERROR: {message}\n")

    #---------------------------------------------------------------------------
    def printUsage(self, cmdPath:CmdPathLike=None):
        cliCmd = self.cliCmds[cmdPath] if cmdPath else None
        type = "subCmd" if cliCmd else "full"

        match type:
          case "full":
            print(f"Usage:", file=sys.stderr)

            print(f"   # Global Options:", file=sys.stderr)
            print(f"   {self.cliCmds.getUsage(())}", file=sys.stderr)

            print(f"", file=sys.stderr)

            cmdPaths = set(self.cliCmds.leafKeys())
            for cmdGrpName, cmdGrp in self.helpData["cmdGrps"].items():
                print(f"   # {cmdGrp["text"]}", file=sys.stderr)
                for cmdPath in cmdGrp["cmds"]:
                    cmdPaths.discard(cmdPath)
                    print(f"   {self.cliCmds.getUsage(cmdPath)}", file=sys.stderr)
                print(f"", file=sys.stderr)
            if cmdPaths:
                if self.helpData["cmdGrps"]:
                    print("   # Misc sub commands", file=sys.stderr)
                for cmdPath in cmdPaths:
                    print(f"   {self.cliCmds.getUsage(cmdPath)}", file=sys.stderr)
                print(f"", file=sys.stderr)

          case "subCmd":
            print(f"   {Path(self.cmdName).name} "
                f"{cliCmd.usage} ",
                file=sys.stderr)

    #---------------------------------------------------------------------------
    def printHelp(self, *, cmdPath:CmdPathLike=None, ctx:ParsingContext=None):
        type = "full"
        cmdPath = cmdPath or (ctx.cmdPath if ctx else None)
        if cmdPath:
            type = "subCmd"

        match type:
          case "full":
            if self.helpText:
                print(self.helpText, file=sys.stderr)
                print(f"", file=sys.stderr)

            print(f"Commands:", file=sys.stderr)
            curCmdPrefix = CmdPath()
            curIndent = '   ' * (1+curCmdPrefix.depth)
            for subCmdName in sorted(self.cliCmds.getSubCommandNames(curCmdPrefix)):
                subCmd = self.cliCmds[curCmdPrefix.child(subCmdName)]
                print(f"{curIndent}{subCmdName} {'|'.join(sorted(self.cliCmds.getSubCommandNames(subCmd.cmdPath)))} :", file=sys.stderr)
                print(bgnormstr(subCmd.helpText or "help text...", indent='   '+curIndent), file=sys.stderr)
                print(f"", file=sys.stderr)
            print(f"", file=sys.stderr)

            self.printUsage()

            print(f"Arguments:", file=sys.stderr)
            argNameWidth = min(30, max(len(o.displayName) for o in self.cliCmds.allPosArgsValues()))
            for argSpec in self.cliCmds.allPosArgsValues():
                print(f"   {argSpec.displayName:{argNameWidth}}: {
                    bgnormstr(argSpec.helpText, indent=' '*(argNameWidth+5), first="")}", file=sys.stderr)
            print(f"", file=sys.stderr)

            print(f"Options:", file=sys.stderr)
            optNameWidth = min(30, max(len(o.displayName) for o in self.cliCmds.allOptArgsValues()))
            for optSpec in self.cliCmds.allOptArgsValues():
                print(f"   {optSpec.displayName:{optNameWidth}}: {
                    bgnormstr(optSpec.helpText, indent=' '*(argNameWidth+5), first="")}", file=sys.stderr)
            print(f"", file=sys.stderr)

          case "subCmd":
            print(f"Usage:", file=sys.stderr)
            print(f"   {Path(self.cmdName).name} "
                  f"{ctx.cliCmd.usage} "
                  f"{'|'.join(self.cliCmds.getSubCommandNames(ctx.cliCmd.cmdPath))}",
                  file=sys.stderr)
            print(bgnormstr(ctx.cliCmd.helpText or "help text...", indent='      '), file=sys.stderr)

    #---------------------------------------------------------------------------
    def printNS(self):
        ns = self.argsNS
        print(f"\n({type(ns).__name__}):", file=sys.stderr)
        for name, value in sorted(vars(ns).items()):
            vtype = type(value).__name__
            print(f"    {name:<20} : {vtype:<12} = {value!r}", file=sys.stderr)


    #---------------------------------------------------------------------------
    def _getHelpData(self, defaultText:str) -> str:
        resolvedHelpPath = findLanguageFile(Path(sys.argv[0]).with_suffix(".help"))
        if resolvedHelpPath:
            self.helpLang = resolvedHelpPath.suffix
            return resolvedHelpPath.read_text(encoding="utf-8")
        return defaultText

    #---------------------------------------------------------------------------
    def _createHelpDataFile(self):
        newHelpFile = Path(sys.argv[0]).with_suffix(f".help.{self.helpLang}")
        if newHelpFile.exists():
            print(f"The Help file already exists. file='{newHelpFile}' ", file=sys.stderr)
        else:
            newHelpFile.write_text(self.helpNotation, encoding="utf-8")
            print(bgnormstr(f"""
                A help file has been created with the current language help text. You can change the extention
                of this file to a new langauage code and then translate the contents to that language.
                Pull requests are appreciated for quality translations.
                    file: '{newHelpFile}'
                """), file=sys.stderr)

    @staticmethod
    def run(entryPointFn:Callable[[],int|None]):
        try:
            rc = asyncio.run(entryPointFn())
            raise SystemExit(rc or 0)

        except KeyboardInterrupt:
            print("Interrupted")
            raise SystemExit(130)

        except ExpectedException as e:
            verbosity = 1
            if CliBuilder.current and hasattr(CliBuilder.current, "argsNS"):
                verbosity = getattr(CliBuilder.current.argsNS, "verbosity", 1)

            if verbosity >= 1:
                raise
            print(f"{e}")
            raise SystemExit(1)

        except Exception as e:
            verbosity = 1
            if CliBuilder.current and hasattr(CliBuilder.current, "argsNS"):
                verbosity = getattr(CliBuilder.current.argsNS, "verbosity", 1)

            if verbosity >= 1:
                raise
            print(f"{formatException(e)}")
            raise SystemExit(1)


#---------------------------------------------------------------------------
def parseHelpNotation(text: str) -> dict[str, Any]:
    text = text or ""

    _sectionRe = re.compile(r"^\s*\[(cmd|arg|opt|cmdGrp):([^\]]+)\]\s*$")

    result = {
        "helpText": "",
        "cmdGrps": {},
        "cmds": {},
        "args": {},
        "opts": {},
    }

    currentKind = "helpText"
    currentKey = None
    buf: list[str] = []
    currentCmdGrp = None

    def flush():
        nonlocal buf, currentKind, currentKey, currentCmdGrp

        value = textwrap.dedent("\n".join(buf)).strip("\n")

        if currentKind == "helpText":
            result["helpText"] = value
        elif currentKind == "cmd":
            result["cmds"][currentKey] = value
            if currentCmdGrp:
                currentCmdGrp["cmds"].append(currentKey)
        elif currentKind == "arg":
            result["args"][currentKey] = value
        elif currentKind == "opt":
            result["opts"][currentKey] = value
        elif currentKind == "cmdGrp":
            currentCmdGrp = {
                "cmds" : [],
                "text" : value
            }
            result["cmdGrps"][currentKey] = currentCmdGrp

        buf = []

    for line in text.splitlines():
        m = _sectionRe.match(line)
        if m:
            flush()

            currentKind = m.group(1)
            spec = m.group(2).strip()

            if currentKind == "cmd":
                currentKey = CmdPath(spec)
            else:
                currentKey = spec

            continue

        buf.append(line)

    flush()
    return result


#---------------------------------------------------------------------------
def bcToWords(words) -> str:
    if isinstance(words, list):
        parts = []
        for word in words:
            parts.append(str(word))
        return ' '.join(parts)
    else:
        return str(words)



def installBashCompletion():
    from importlib.resources import files


    #loginShell = Path(pwd.getpwuid(os.getuid()).pw_shell)
    shellName = Path(os.environ["SHELL"]).name
    if shellName != "bash":
        print(bgnormstr(f"""
            {Path(sys.argv[0]).name} currently only supports completion under bash.
            zsh users may be able to use it via bashcompinit.
            Your current shell is detected from $SHELL as {shellName}
            """))
        sys.exit(1)

    # in deployment, the two scripts might be in inline strings.

    bcScriptPath = files("bg_cliBuilder").joinpath("bg_bashCompletion.globalBashCompletion")
    bcScript = bcScriptPath.read_text()
    bcScriptPath = Path.home() / ".local" / "share" / "bg_cliBuilder" / "bg_bashCompletion.globalBashCompletion"
    if not bcScriptPath.exists():
        bcScriptPath.parent.mkdir(parents=True, exist_ok=True)
        bcScriptPath.write_text(bcScript)

    bcLoaderPath = files("bg_cliBuilder").joinpath("bg_cmdChainLoader.globalBashCompletion")
    bcLoader = bcLoaderPath.read_text()
    bcLoaderPath = Path.home() / ".local" / "share" / "bg_cliBuilder" / "bg_cmdChainLoader.globalBashCompletion"
    if not bcLoaderPath.exists():
        bcLoaderPath.parent.mkdir(parents=True, exist_ok=True)
        bcLoaderPath.write_text(bcLoader)

    bashrcPath = Path.home() / ".bashrc"
    text = bashrcPath.read_text() if bashrcPath.exists() else ""
    marker = "# BGBC non-bg-core"
    if marker not in text:
        with bashrcPath.open("a") as f:
            if text and not text.endswith("\n"):
                f.write("\n")
            f.write(bgnormstr(f"""
                .
                [ -f {shlex.quote(str(bcScriptPath))} ] && source {shlex.quote(str(bcScriptPath))} {marker}
                [ -f {shlex.quote(str(bcLoaderPath))} ] && source {shlex.quote(str(bcLoaderPath))} {marker}
                """, width=1000))
        print(bgnormstr(f"""
            BGBC style completion support has been added to your .bashrc file. Any python script
            that uses CliBuilder will automatically have completion support without further installation.
            To continue in this terminal run these commands:
                complete -r {Path(sys.argv[0]).name}
                source {bashrcPath}
            """))
    else:
        print(bgnormstr(f"""
            BGBC style completion support is already installed in your .bashrc
            (The lines ending in {marker})
            """))

    sys.exit(0)
