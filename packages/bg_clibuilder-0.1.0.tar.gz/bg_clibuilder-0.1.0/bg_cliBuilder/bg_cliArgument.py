from __future__ import annotations

import re
import inspect
from collections.abc import Callable
from abc import ABC, abstractmethod
from pathlib  import Path
from typing   import Literal, Dict, Any, List
from types    import SimpleNamespace

from .bg_cliHelpers import bgnormstr, bgtrace, invokeCallbackWithContext

################################################################################

# Global helper function to declare a positional argument.
# Typically you would pass a str <posSpecStr> that decribes the positional argument
# but when you want to specify an attribute that is not supported by the <posSpecStr>
# syntax you can use pos(<posSpecStr>, <attrib>="<val>", ...)
# Example:
#   cli.cmd("sessions create", args=[pos("agentClass", completer=getAgentClasses)])
def pos(spec:str, **kwargs) -> PosArgument:
    argSpec = PosArgument.fromSpec(spec, kwargs)
    return argSpec


# Global helper function to declare an optional argument to a specific cmd/subCmd.
# Typically you would pass a str <optSpecStr> that decribes the optional argument
# but when you want to specify an attribute that is not supported by the <optSpecStr>
# syntax you can use pos(<optSpecStr>, <attrib>="<val>", ...)
# Example:
#   cli.cmd("upstreams list", args=[opt("--agent:str", action="append")])
def opt(*spec:str, **kwargs) -> OptArgument:
    if isinstance(spec, tuple):
        spec = '|'.join(spec)
    argSpec = OptArgument.fromSpec(spec, **kwargs)
    return argSpec



################################################################################
class CliArgument(ABC):
    #-------------------------------------------------------------------------------
    @classmethod
    def fromSpec(cls, spec:str, **kwargs) -> CliArgument:
        spec = spec.strip()
        if spec.startswith('-'):
            return OptArgument.fromSpec(spec, **kwargs)
        elif spec.startswith('<'):
            return PosArgument.fromSpec(spec, **kwargs)
        else:
            raise Exception(f"CliArgument.fromSpec: Bad spec. Expected it to start with '-' for options or '<' for positional arguments")

    #-------------------------------------------------------------------------------
    @classmethod
    def resolveArgListLike(cls, argOrArgs:list|str|CliArgument, **kwargs) -> List[CliArgument]:
        if argOrArgs is None:
            return []

        elif isinstance(argOrArgs, list):
            out = []
            for oneArg in argOrArgs:
                out.extend(cls.resolveArgListLike(oneArg, **kwargs))
            return out

        elif isinstance(argOrArgs,str):
            return [CliArgument.fromSpec(argOrArgs, **kwargs)]

        elif isinstance(argOrArgs, CliArgument):
            argOrArgs.mergeParams(**kwargs)
            return [argOrArgs]

        else:
            raise Exception(f"Unexpected argOrArgs type. Expected list|str|CliArgument. Got '{type(argOrArgs)}'")

    #-------------------------------------------------------------------------------
    def __init__(self, key:str, varName:str):
        self.key = key

        self.varName = varName
        self.type = str
        self.default = None

        self.choices = []
        self.completer = None

        self.helpText = ""

    def printDump(self):
        print(f"  key      = {self.key!r}       ")
        print(f"  varName  = {self.varName!r}   ")
        print(f"  type     = {self.type!r}      ")
        print(f"  default  = {self.default!r}   ")
        print(f"  choices  = {self.choices!r}   ")
        print(f"  completer= {self.completer!r} ")
        print(f"  helpText = {self.helpText!r}  ")


    #-------------------------------------------------------------------------------
    @property
    @abstractmethod
    def usage(self):
        pass

    @property
    @abstractmethod
    def displayName(self):
        pass

    @property
    @abstractmethod
    def bcLabel(self):
        pass

    @abstractmethod
    def hit(self, argToken, argsNS, ctx:ParsingContext, cli):
        pass

    #-------------------------------------------------------------------------------
    def merge(self, other:CliArgument) -> CliArgument:
        if type(self) is not type(other):
            raise TypeError(bgnormstr(f"""
                CliArgument.merge: PosArgument and OptArgument can not be merged
                    existing type : '{type(self).__name__}'
                    merging type  : '{type(other).__name__}'
                """))

        mustNotChangeNames = ("key", "varName", "names", "name")

        # invariant checks
        for name in mustNotChangeNames:
            # for convenience we can include subclass attributes to check which should be
            # ignored when this is being called for the other subclass
            if not hasattr(self, name):
                continue
            otherValue = getattr(other, name, None)
            selfValue = getattr(self, name, None)
            if (otherValue is not None and selfValue is not None and otherValue != selfValue):
                raise Exception(bgnormstr(f"""
                    CliArgument.merge. A repeated argument has a conflicting attribute.
                        atrribute name : '{name}'
                        existing value : '{selfValue}'
                        new value      : '{otherValue}'
                    """))

        for name, value in vars(other).items():
            if value is not None and name not in mustNotChangeNames:
                match name:
                  # TODO: if any attrubutes need special handling (like appending
                  #       instead of overwriting, add cases here)
                  case _:
                    self.setAttribute(name, value, raiseUnknown=False)

        return self


    def mergeParams(self, **kwargs):
        for name, value in (kwargs).items():
            self.setAttribute(name, value)

    @property
    def typeStr(self) -> str:
        if self.type:
            return self.type.__name__
        else:
            return "str"

    def validatAndCoerceValue(self, value):
        out = _coerceValue(value, self.type)
        if out is None:
            return out
            # raise Exception(bgnormstr(f"""
            #     CliArgument: Value is not a valid for the type of argument.
            #         type : '{self.typeStr}'
            #         value: '{value}'
            #     """))
        if self.choices and out not in self.choices:
            raise Exception(bgnormstr(f"""
                CliArgument: Value is not a valid choice.
                    entered value : '{value}'
                    valid values  : {'|'.join(self.choices)}
                """))
        return out

    # When creating a CliArgument, the user can specify kwargs which get sent here
    # to translate into our class members
    def setAttribute(self, name, value, raiseUnknown=False) -> bool:
        match name:
          case "key":
            self.key = value
          case "varName"|"dest":
            self.varName = value
          case "type":
            self.type = _TYPE_MAP.get(value,value)
          case "default":
            self.default = value
          case "choices":
            self.choices = value
          case "completer":
              self.completer = value
          case "helpText":
            self.helpText = value
          case _:
              if raiseUnknown:
                  raise Exception(f"CliArgument.setAttribute: Unknown attribute '{name}'")
              return False
        return True

    #---------------------------------------------------------------------------
    # for OptArgument args this only gets calls when a required value is being completed
    # for PosArgument args it gets called when the position is being completed
    def printCompletions(self, ctx, cli):
        print(self.bcLabel)

        for choice in self.choices:
            print(choice)

        completer = self.completer

        if completer:
            # str are pass throughs. Typically bgbc directives like $(_filedir)
            if isinstance(completer, str):
                print(completer)
            elif callable(completer):
                output = self.invokeCallbackWithContext(completer, cliArg=self, ctx=ctx, argsNS=ctx.argsNS, cli=cli)
                bgtrace(f"output='{output}'")
                if output:
                    if isinstance(output, list):
                        for word in output:
                            print(str(word.replace(' ',"%20")))
                    else:
                        print(str(output))

    @staticmethod
    def invokeCallbackWithContext(fn:Callable, *, argToken=None, cliArg:CliArgument=None, ctx=None, argsNS:SimpleNamespace=None, cli=None):
        available = {
            "argToken"  : argToken,
            "value"     : argToken,
            "cli"           : cli,
            "cliBuilder"    : cli,
            "ctx"           : ctx,
            "parsingContext": ctx,
            "argsNS"   : argsNS,
            "args"     : argsNS,
            "ns"       : argsNS,
            "arg"    : cliArg,
            "argSpec": cliArg,
            "cliArg" : cliArg,
            **vars(argsNS if argsNS else {})
        }

        return invokeCallbackWithContext(fn, available)


type CliArgsLike = str | list[CliArgument] | CliArgument



################################################################################
# PosArgument represents a CliArgument that follows the *nix standard for positional
# arguments.
#
# argsNS <varName>:
# When a subcmd is activated that contains this argument, it will create <varName>
# in the argsNS.
# The <varName> will be the first of...
#    0) varName=<varName> if explicitly passed in kwargs
#    1) the argument's name with the surounding <> removed
#
# Inactive varName value:
# when the option is not specified on the cmdline varName in argsNS is intiiallized to...
#    0) <default> if specified
#    1) None
#
# Active varName value:
# when the option appears on the cmdline varName is set to the clitoken in its position.
#
# Creating a PosArgument:
# When passing a PosArgument into a function like CliBuilder.cmd that expects a CliArgsLike
# There are three ways to specify a PosArgument.
#    1) normal ctor: PosArgument("<myArgName>", default="foo", ...)
#    2) pos() short alias: pos("<specStr>", default="foo", ...)
#    3) a str: "<specStr>"
# Note that the actual constructor PosArgument expects the arg name but pos() expects a
# <specStr> which is the arg name with optional annotations.
#
# See Also:
#    CliArgument : for attributes/features available to OptArgument that are shared with PosArgument
#    PosArgument.fromSpec: to see the accepted syntax for <specStr>
#
class PosArgument(CliArgument):
    #---------------------------------------------------------------------------
    # SpecStr Syntax:
    #    <varName>[:<metaSpec>][=<defaultSpec>]
    #    metaSpec    := <type>[?][...]
    #    defaultSpec := <defaultValue>
    #    defaultSpec := one|two*|three
    #    defaultSpec := None or <emptyStr>  <- converts to None and sets optional to True
    @classmethod
    def fromSpec(cls, spec:str, **kwargs) -> PosArgument:
        spec = spec.strip()

        metaSpec = ""
        defaultSpec = ""

        if '=' in spec:
            spec, defaultSpec = spec.split('=',1)
        if ':' in spec:
            spec, metaSpec = spec.split(':', 1)
        name = f"<{spec.strip('<>')}>"

        if '?' in metaSpec:
            kwargs["optional"] = True
            metaSpec = metaSpec.strip('?')

        if defaultSpec:
            kwargs["optional"] = True
            if '|' in defaultSpec:
                kwargs["choices"], kwargs["default"] = parseChoicesAndDefault(defaultSpec)
            elif not defaultSpec or defaultSpec=="None":
                kwargs["default"] = None
            else:
                kwargs["default"] = defaultSpec

        if '...' in metaSpec:
            kwargs["remainder"] = True
            metaSpec = metaSpec.replace("...", "")

        if metaSpec:
            kwargs["type"] = _TYPE_MAP.get(metaSpec, metaSpec) if metaSpec else str

        return PosArgument(name, **kwargs)

    #---------------------------------------------------------------------------
    def __init__(self, name:str, **kwargs):
        super().__init__(key=name, varName=name.strip('<>'))
        self.name = name
        self.optional = False
        self.remainder = False

        self.mergeParams(**kwargs)

        self.default = self.validatAndCoerceValue(self.default)

    def printDump(self):
        print(f"PosArgument:")
        super().printDump()
        print(f"  name      = {self.name!r}      ")
        print(f"  optional  = {self.optional!r}  ")
        print(f"  remainder = {self.remainder!r} ")

    def bgtrace(self, indent=""):
        bgtrace(f"{indent}{self.key:20} vals='{f"{self.default}<-<cliToken>":13}' optional='{self.optional}' remainder='{self.remainder}'")

    #---------------------------------------------------------------------------
    @property
    def names(self) -> tuple:
        return (self.name,)

    #---------------------------------------------------------------------------
    @property
    def usage(self):
        return f"[{self.displayName}]" if self.optional else self.displayName

    #---------------------------------------------------------------------------
    @property
    def displayName(self):
        return f"<{self.varName}>"

    #---------------------------------------------------------------------------
    @property
    def bcLabel(self):
        label = self.displayName
        if self.type and self.type != str:
            label = label.replace('>', f":{self.typeStr}>")
        return label

    #---------------------------------------------------------------------------
    def setAttribute(self, name, value, raiseUnknown=True):
        match name:
          case "optional":
            self.optional = value
          case "remainder":
            self.remainder = value
          case _:
            if not super().setAttribute(name, value, raiseUnknown=False):
                raise Exception(f"CliBuilder: Unknown attribute({name}={value}) for a positional argument")
        return True

    #---------------------------------------------------------------------------
    def hit(self, argToken, argsNS, ctx:ParsingContext, cli):
        argToken = self.validatAndCoerceValue(argToken)
        setattr(argsNS, self.varName, argToken)

    def __str__(self):
        return f"PosArgument:{self.name}, {self.varName}"

    def __repr__(self):
        return f"PosArgument:{self.name}, {self.varName}"


################################################################################
# OptArgument represents a CliArgument that follows the *nix standard for options.
# Two dashes for --longOpt and one -? for one letter short options.
# These options may or may not require a value argument to be specified.
#
# argsNS <varName>:
# When a subcmd is activated that contains the option, it will create <varName>
# in the argsNS.
# The <varName> will be the first of...
#    0) varName=<varName> if explicitly passed in kwargs
#    1) first long option name without the leading --
#    2) <valueName> (e.g. -C <pwd> -> varName=="pwd")
#    3) first short option letter without the leading -
#
# Inactive varName value:
# when the option is not specified on the cmdline varName in argsNS is intiiallized to...
#    0) <default> if specified
#    1) False
#
# Active varName value:
# when the option appears on the cmdline varName is modified follow these steps...
# First a value is taken as...
#    0) <cliToken> if requiresValue==True
#    1) <constValue>
# Then that value is acted on depending on the the <action> setting...
#    "store"     -> argsNS[varName] = value
#    "append"    -> argsNS[varName].append[value]
#    "increment" -> argsNS[varName] += int(value)
#    "decrement" -> argsNS[varName] -= int(value)
#
# HitFn:
# In addition to setting <varName> in argsNS, if a <hitFn> is specified it will
# be invoked when the option is encountered on the cmdline.
#
# See Also:
#    CliArgument : for attributes/features available to OptArgument that are shared with PosArgument
#
class OptArgument(CliArgument):
    #---------------------------------------------------------------------------
    # OptSpecStr:
    #    <optName>[|<optName>][:<metaSpec>][{ |=}<valueSpec>]
    #    optName := --<longOpt>
    #    optName := -?   # <shortOpt> ? is a char
    #    metaSpec:= <type>
    #    metaSpec:= +
    #    valueSpec := <valueName>
    #    valueSpec := one|two*|three
    #    valueSpec := constValue
    @classmethod
    def fromSpec(cls, spec:str, **kwargs) -> CliArgument:
        spec = spec.strip()

        metaSpec = ""
        valueSpec = ""

        # "--modelID <id>"
        # "--modelID=<id>"
        if ' ' in spec or '\t' in spec:
            spec, valueSpec = spec.split(None, 1)
        elif '=' in spec:
            spec, valueSpec = spec.split('=', 1)

        if ':' in spec:
            spec, metaSpec = spec.split(':', 1)

        names=tuple(spec.split("|"))

        if '+' in metaSpec:
            metaSpec = metaSpec.replace('+','')
            kwargs["requiresValue"] = False
            kwargs["action"] = "increment"
            kwargs["default"] = 0
            kwargs["constValue"] = 1
            kwargs["type"] = int

        if '-' in metaSpec:
            metaSpec = metaSpec.replace('-','')
            kwargs["requiresValue"] = False
            kwargs["action"] = "decrement"
            kwargs["default"] = 0
            kwargs["constValue"] = 1
            kwargs["type"] = int

        if metaSpec:
            kwargs["requiresValue"] = True
            kwargs["type"] = _TYPE_MAP.get(metaSpec, metaSpec) if metaSpec else str

        if valueSpec:
            kwargs["requiresValue"] = True
            if '|' in valueSpec:
                kwargs["choices"], kwargs["default"] = parseChoicesAndDefault(valueSpec)
            elif valueSpec.startswith('<'):
                kwargs["valueName"] = valueSpec
            else:
                kwargs["constValue"] = valueSpec

        return OptArgument(names, **kwargs)

    @staticmethod
    def getKeyAndVarnameFromNames(names:tuple) -> tuple[str,str]:
        for name in names:
            if name.startswith('--'):
                return (name, name[2:])
        return (names[0], names[0][1:])

    #---------------------------------------------------------------------------
    def __init__(self, names:tuple, **kwargs):
        super().__init__(*self.getKeyAndVarnameFromNames(names))
        self.names         = names
        self.requiresValue = False
        self._valueName     = None
        self.constValue    = True
        self.action        = "store"
        self.hitFn         = None

        # change the default of these CliArgument members to match default flag behavior
        self.type = bool

        self.mergeParams(**kwargs)

        self.default = self.validatAndCoerceValue(self.default)
        self.constValue = self.validatAndCoerceValue(self.constValue)

    def printDump(self):
        print(f"OptArgument:")
        super().printDump()
        print(f"  names         = {self.names!r}         ")
        print(f"  requiresValue = {self.requiresValue!r} ")
        print(f"  valueName     = {self.valueName!r}     ")
        print(f"  constValue    = {self.constValue!r}    ")
        print(f"  action        = {self.action!r}        ")
        print(f"  hitFn         = {self.hitFn!r}         ")

    def bgtrace(self, indent=""):
        bgtrace(f"{indent}{self.key:20} value?='{self.valueName:15}' vals='{f"{self.default}<-{self.constValue}":13}' action='{self.action:9}' hitFn={"yes" if self.hitFn else "no"}")

    #---------------------------------------------------------------------------
    @property
    def name(self) -> str:
        return self.key

    #---------------------------------------------------------------------------
    @property
    def usage(self):
        return f"[{self.displayName}]"

    #---------------------------------------------------------------------------
    @property
    def displayName(self):
        label = '|'.join(self.names)
        if self.requiresValue:
            label = f"{label} {self.optValueName}"
        return label

    #---------------------------------------------------------------------------
    @property
    def valueName(self) -> str:
        if not self.requiresValue:
            return ""
        elif self._valueName:
            return self._valueName
        else:
            return f"<{self.varName}>"

    @property
    def optValueName(self) -> str:
        return self.valueName

    #---------------------------------------------------------------------------
    @property
    def bcLabel(self):
        # for options bcLabel is called when completing a required value
        label = self.optValueName
        if self.type and self.type != str:
            label = label.replace('>', f":{self.typeStr}>")
        return self.optValueName

    #---------------------------------------------------------------------------
    def setAttribute(self, name, value, raiseUnknown=True):
        match name:
          case "requiresValue":
            self.requiresValue = value
          case "valueName":
            self._valueName = value
            self.requiresValue = True
          case "constValue"|"const":
            self.constValue = value
          case "action":
            self.action = value
          case "activationFN"|"hitFN"|"hitFn":
              self.hitFn = value
          case _:
            if not super().setAttribute(name, value, raiseUnknown=False):
                raise Exception(f"CliBuilder: Unknown attribute({name}={value}) for an optional argument")
        return True

    #---------------------------------------------------------------------------
    def hit(self, argToken, argsNS, ctx:ParsingContext, cli):
        argToken = self.validatAndCoerceValue(argToken)

        match self.action:
          case "store":
            value = argToken or self.constValue
          case "append":
            value = getattr(argsNS, self.varName) or []
            value.append(argToken or self.constValue)
          case "count"|"increment":
            value = getattr(argsNS, self.varName, self.default)
            value += int(argToken or self.constValue)
          case "decrement":
            value = getattr(argsNS, self.varName, self.default)
            value -= int(argToken or self.constValue)
          case _:
              raise Exception(f"OptArgument.hit: unknown action. expected store|append|increment|decrement but got '{self.action}'")

        setattr(argsNS, self.varName, value)

        if self.hitFn:
            self.invokeCallbackWithContext(self.hitFn, argToken=argToken, cliArg=self, ctx=ctx, argsNS=argsNS, cli=cli)

    # self.key = key
    #
    # self.varName = varName
    # self.type = str
    # self.default = None
    #
    # self.choices = []
    # self.completer = None
    #
    # self.helpText = ""

    # self.name = name
    # self.optional = False
    # self.remainder = False

    # self.names         = names
    # self.requiresValue = False
    # self.valueName     = None
    # self.constValue    = True
    # self.action        = "store"
    # self.hitFn         = None

    def __str__(self):
        return f"OptArgument:{self.key}, {self.varName}"

    def __repr__(self):
        return f"OptArgument:{self.key}, {self.varName}"

################################################################################
### Global helper Functions

_TYPE_MAP = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "Path": Path,
}


#-------------------------------------------------------------------------------
def _coerceValue(value:str, typ):
    if typ is None or value is None:
        return value

    if isinstance(value, typ):
        return value

    if typ is bool:
        if isinstance(value, str):
            return value.lower() in ("1", "true", "yes", "on")
        return bool(value)

    try:
        return typ(value)
    except Exception as e:
        pass

    if not value:
        try:
            return typ()
        except Exception as e:
            pass

    return None

def parseChoicesAndDefault(choicesSpec:str) -> tuple[List[str],str]:
    choices = []
    default = None
    for choice in choicesSpec.split('|'):
        if choice.endswith('*'):
            choice = choice[:-1]
            default = choice
        choices.append(choice)
    return choices, default
