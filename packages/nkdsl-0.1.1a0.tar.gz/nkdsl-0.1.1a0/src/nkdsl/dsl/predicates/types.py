# Copyright (c) 2026 The neuraLQX and nkDSL Authors - All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Type aliases for predicate clause implementations."""

from __future__ import annotations

from typing import Any
from typing import TypeAlias

PredicateValue: TypeAlias = Any
"""Predicate value returned by predicate clauses (coercible to PredicateExpr)."""


__all__ = ["PredicateValue"]
