import os
import boto3
from ..utils.logger import logger
import re


class S3Utils:
    # Hard cap on pagination when listing under a single prefix. Each
    # list_objects_v2 page returns up to 1000 keys, so 200 pages == ~200K keys.
    # If a caller passes a prefix that contains more than this, we refuse to
    # enumerate further. Direct callers (download_directory, delete_directory)
    # always pass naturally tight prefixes so this cap is never hit in practice.
    MAX_PAGES_PER_PREFIX = 200

    # Cap for find_latest_training_artifact's cuid-walk. With ~1 cuid per pb
    # run, 200 covers ~30 days at 6 runs/day. Hitting it logs a warning and
    # returns None so the caller proceeds to retrain (safe).
    MAX_CUIDS_TO_SCAN = 200

    # Defensive per-cuid pagination cap during the cuid-walk.
    MAX_PAGES_PER_CUID = 50

    def extract_object_list(s3_client, bucket_name, s3_path):
        continuation_token = None
        all_objects = []

        page = 0
        while page < S3Utils.MAX_PAGES_PER_PREFIX:
            if continuation_token:
                response = s3_client.list_objects_v2(
                    Bucket=bucket_name,
                    Prefix=s3_path,
                    ContinuationToken=continuation_token,
                )
            else:
                response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=s3_path)

            if "Contents" in response:
                all_objects.extend(response["Contents"])

            if not response.get("IsTruncated"):
                break

            continuation_token = response.get("NextContinuationToken")
            page += 1
        if page >= S3Utils.MAX_PAGES_PER_PREFIX:
            msg = (
                f"S3 prefix '{s3_path}' returned more than "
                f"{S3Utils.MAX_PAGES_PER_PREFIX} pages of objects "
                f"(~{S3Utils.MAX_PAGES_PER_PREFIX * 1000:,} keys); "
                f"refusing to enumerate further."
            )
            logger.get().error(msg)
            raise Exception(msg)
        return all_objects

    def _list_common_prefixes(s3_client, bucket_name, prefix):
        common_prefixes = []
        continuation_token = None
        page = 0
        while page < S3Utils.MAX_PAGES_PER_PREFIX:
            kwargs = {"Bucket": bucket_name, "Prefix": prefix, "Delimiter": "/"}
            if continuation_token:
                kwargs["ContinuationToken"] = continuation_token
            response = s3_client.list_objects_v2(**kwargs)
            for cp in response.get("CommonPrefixes") or []:
                common_prefixes.append(cp["Prefix"])
            if not response.get("IsTruncated"):
                break
            continuation_token = response.get("NextContinuationToken")
            page += 1
        return common_prefixes

    def _list_keys_under(s3_client, bucket_name, prefix, max_pages):
        keys = []
        continuation_token = None
        page = 0
        while page < max_pages:
            kwargs = {"Bucket": bucket_name, "Prefix": prefix}
            if continuation_token:
                kwargs["ContinuationToken"] = continuation_token
            response = s3_client.list_objects_v2(**kwargs)
            for obj in response.get("Contents") or []:
                keys.append(obj)
            if not response.get("IsTruncated"):
                break
            continuation_token = response.get("NextContinuationToken")
            page += 1
        return keys

    def find_latest_training_artifact(
        s3_client,
        bucket_name,
        project_prefix,
        folder_substring,
        min_creation_time,
        max_cuids_to_scan=None,
    ):
        """Walk recent cuid subfolders newest-first to find the latest training
        artifact whose LastModified > min_creation_time. Returns
        (matched_object, derived_path_to_download) or None if no match.

        Bounded by validity_time (via early bail-out when a cuid's newest key
        is past min_creation_time) and by max_cuids_to_scan as a safety net.
        """
        if max_cuids_to_scan is None:
            max_cuids_to_scan = S3Utils.MAX_CUIDS_TO_SCAN

        normalized = project_prefix.rstrip("/") + "/"
        cuids = S3Utils._list_common_prefixes(s3_client, bucket_name, normalized)
        # cuid v2 is time-sortable lexicographically; newest first.
        cuids.sort(reverse=True)

        best_obj = None
        best_path = None
        for i, cuid in enumerate(cuids):
            if i >= max_cuids_to_scan:
                logger.get().warning(
                    f"Reached max_cuids_to_scan={max_cuids_to_scan} while "
                    f"searching {normalized} for {folder_substring}; treating "
                    f"as no-match (caller will retrain). If validity_time is "
                    f"unusually large, consider raising the cap."
                )
                return None

            keys = S3Utils._list_keys_under(
                s3_client, bucket_name, cuid, S3Utils.MAX_PAGES_PER_CUID
            )
            if not keys:
                continue

            max_lm_in_cuid = max(k["LastModified"] for k in keys)
            if max_lm_in_cuid <= min_creation_time:
                # All keys here, and in older cuids, are past validity.
                break

            for k in keys:
                key = k["Key"]
                lm = k["LastModified"]
                if (
                    lm > min_creation_time
                    and folder_substring in key
                    and folder_substring not in os.path.basename(key)
                ):
                    if best_obj is None or lm > best_obj["LastModified"]:
                        match = re.search(
                            f"(.*?{re.escape(folder_substring)}[^/]*)", key
                        )
                        if match:
                            best_obj = k
                            best_path = match.group(1) + "/"

        if best_obj is None:
            return None
        return best_obj, best_path

    def download_directory(s3_config, local_directory):
        s3_client = boto3.client("s3", region_name=s3_config["region"])
        bucket_name = s3_config["bucket"]
        s3_path = s3_config["path"]

        all_objects = S3Utils.extract_object_list(s3_client, bucket_name, s3_path)

        for obj in all_objects:
            key = obj["Key"]
            if key == s3_path:
                logger.get().debug(f"Skipping object: key: {key}, s3_path: {s3_path}")
                continue
            local_file_path = os.path.join(
                local_directory, os.path.relpath(key, s3_path)
            )
            if not os.path.exists(os.path.dirname(local_file_path)):
                os.makedirs(os.path.dirname(local_file_path))
            s3_client.download_file(bucket_name, key, local_file_path)
            logger.get().debug(f"File {key} downloaded to {local_file_path}")
        logger.get().debug(
            f"All files from {bucket_name}/{s3_path} downloaded to {local_directory}"
        )

    def delete_directory(bucket_name, aws_region_name, folder_name):
        s3_client = boto3.client("s3", region_name=aws_region_name)
        all_objects = S3Utils.extract_object_list(s3_client, bucket_name, folder_name)

        for obj in all_objects:
            s3_client.delete_object(Bucket=bucket_name, Key=obj["Key"])
            logger.get().debug(f"Deleted object: {obj['Key']}")
        s3_client.delete_object(Bucket=bucket_name, Key=folder_name)
        logger.get().debug(f"Deleted folder: {folder_name}")

    def download_training_artifacts(
        bucket_name,
        region,
        prefix,
        download_directory,
        folder_substring,
        min_creation_time,
    ):
        logger.get().debug(
            f"all arguments: prefix: {prefix}, download_directory: {download_directory}, folder_substring: {folder_substring}, min_creation_time: {min_creation_time}"
        )
        s3_client = boto3.client("s3", region_name=region)

        match = S3Utils.find_latest_training_artifact(
            s3_client, bucket_name, prefix, folder_substring, min_creation_time
        )
        if match is None:
            logger.get().debug("No matching training artifacts found.")
            return False

        _, path_to_download = match
        logger.get().info(
            f"Downloading training artifacts from {path_to_download} to {download_directory}"
        )
        S3Utils.download_directory(
            {"region": region, "bucket": bucket_name, "path": path_to_download},
            download_directory,
        )
        return True

    def upload_directory(bucket, aws_region_name, destination, path, allowedFiles):
        client = boto3.client("s3", region_name=aws_region_name)
        for subdir, _, files in os.walk(path):
            for file in files:
                if file not in allowedFiles:
                    continue
                full_path = os.path.join(subdir, file)
                with open(full_path, "rb") as data:
                    s3_key = os.path.join(destination, subdir[len(path) + 1 :], file)
                    try:
                        client.upload_fileobj(data, bucket, s3_key)
                        logger.get().debug(
                            f"File {full_path} uploaded to {bucket}/{s3_key}"
                        )
                    except FileNotFoundError:
                        raise Exception(
                            f"The file {full_path} was not found in ec2 while uploading trained files to s3."
                        )

    def get_temporary_credentials(role_arn: str):
        sts_client = boto3.client("sts")
        response = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName="ml_redshift_s3_access",
            DurationSeconds=900,  # min vale
        )
        credentials = response["Credentials"]
        return {
            "access_key_id": credentials["AccessKeyId"],
            "access_key_secret": credentials["SecretAccessKey"],
            "aws_session_token": credentials["SessionToken"],
        }

    def delete_file(
        bucket_name: str, file_key: str, aws_region_name: str = None, s3_client=None
    ) -> bool:
        """
        Delete a single file from S3.

        Args:
            bucket_name: The S3 bucket name
            file_key: The key (path) of the file to delete
            aws_region_name: AWS region (optional if s3_client is provided)
            s3_client: Pre-configured boto3 S3 client (optional)

        Returns:
            True if deletion was successful, False otherwise
        """
        try:
            if s3_client is None:
                s3_client = boto3.client("s3", region_name=aws_region_name)
            s3_client.delete_object(Bucket=bucket_name, Key=file_key)
            logger.get().debug(f"Deleted S3 file: s3://{bucket_name}/{file_key}")
            return True
        except Exception as e:
            logger.get().warning(
                f"Failed to delete S3 file s3://{bucket_name}/{file_key}: {e}"
            )
            return False

    def upload_file_content(
        bucket_name: str,
        file_key: str,
        content: str,
        aws_region_name: str = None,
        s3_client=None,
    ) -> str:
        """
        Upload string content to S3 as a file.

        Args:
            bucket_name: The S3 bucket name
            file_key: The key (path) for the file
            content: String content to upload
            aws_region_name: AWS region (optional if s3_client is provided)
            s3_client: Pre-configured boto3 S3 client (optional)

        Returns:
            The S3 URI of the uploaded file
        """
        try:
            if s3_client is None:
                s3_client = boto3.client("s3", region_name=aws_region_name)
            s3_client.put_object(
                Bucket=bucket_name, Key=file_key, Body=content.encode("utf-8")
            )
            s3_uri = f"s3://{bucket_name}/{file_key}"
            logger.get().debug(f"Uploaded content to S3: {s3_uri}")
            return s3_uri
        except Exception as e:
            logger.get().error(
                f"Failed to upload content to S3 s3://{bucket_name}/{file_key}: {e}"
            )
            raise
