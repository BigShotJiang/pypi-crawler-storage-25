import os
from copy import deepcopy
from typing import Union

import requests

from . import constants
from .logger import logger


def resolve_if_needed(options: dict) -> dict:
    """If credential_provider is set to 'http', resolve remote creds. Otherwise return as-is."""
    if options.get("credential_provider") == "http":
        return resolve_remote_credentials(options)
    return options


def resolve_remote_credentials(options: dict) -> dict:
    """Fetch credentials from an HTTP vending endpoint and merge into options.

    Mirrors the Go implementation in wht/credprovider.go.
    """
    endpoint = _get_config_value(
        options,
        "credential_provider_endpoint",
        constants.CRED_PROVIDER_ENDPOINT_ENV,
    )
    session_id = _get_config_value(
        options,
        "credential_provider_session",
        constants.CRED_PROVIDER_SESSION_ENV,
    )
    token = _resolve_token(options)

    if not endpoint:
        raise ValueError(
            "credential_provider is 'http' but no endpoint configured. "
            "Set 'credential_provider_endpoint' in siteconfig or "
            f"the {constants.CRED_PROVIDER_ENDPOINT_ENV} environment variable."
        )
    if not session_id:
        raise ValueError(
            "credential_provider is 'http' but no session ID configured. "
            "Set 'credential_provider_session' in siteconfig or "
            f"the {constants.CRED_PROVIDER_SESSION_ENV} environment variable."
        )
    if not token:
        raise ValueError(
            "credential_provider is 'http' but no token configured. "
            "Set 'credential_provider_token_file' in siteconfig or "
            f"the {constants.CRED_PROVIDER_TOKEN_ENV} environment variable."
        )

    verify = _get_ca_cert_path()

    headers = {
        "Authorization": f"CS-Token {token}",
        "Content-Type": "application/json",
    }
    payload = {"sid": session_id}

    try:
        resp = requests.post(
            endpoint,
            json=payload,
            headers=headers,
            verify=verify,
            timeout=30,
        )
        resp.raise_for_status()
        body = resp.json()
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to fetch credentials from {endpoint}: {e}") from e
    except ValueError as e:
        raise RuntimeError(
            f"Failed to parse credential vending response from {endpoint}: {e}"
        ) from e

    secret = body.get("secret", {})
    extra_options = body.get("options", {})

    merged = deepcopy(options)
    merged.update(secret)
    merged.update(extra_options)

    keys_to_remove = [k for k in merged if k.startswith("credential_provider")]
    for k in keys_to_remove:
        del merged[k]

    return merged


def _get_config_value(options: dict, key: str, env_var: str) -> str:
    """Return value from options dict, falling back to environment variable."""
    value = options.get(key, "")
    if value:
        return value
    return os.environ.get(env_var, "")


def _resolve_token(options: dict) -> str:
    """Resolve the auth token: try token_file from options first, then env var."""
    token_file = options.get("credential_provider_token_file", "")
    if token_file:
        try:
            with open(token_file, "r") as f:
                return f.read().strip()
        except OSError as e:
            logger.get().error(f"Failed to read token file {token_file}: {e}")

    return os.environ.get(constants.CRED_PROVIDER_TOKEN_ENV, "")


def _get_ca_cert_path() -> Union[str, bool]:
    """Return custom CA cert path if the file exists, else True to use system CAs."""
    path = os.environ.get(
        constants.CRED_PROVIDER_CA_CERT_PATH_ENV,
        constants.CRED_PROVIDER_DEFAULT_CA_CERT_PATH,
    )
    if path and os.path.isfile(path):
        return path
    return True
