import os
import shutil
import sys
from profiles_rudderstack.model import BaseModelType
from profiles_rudderstack.recipe import PyNativeRecipe
from profiles_rudderstack.material import WhtMaterial
from profiles_rudderstack.logger import Logger
from profiles_rudderstack.schema import (
    EntityKeyBuildSpecSchema,
    MaterializationBuildSpecSchema,
)

from ..utils.logger import logger

from ..utils import constants, utils
from ..utils.S3Utils import S3Utils

from ..wht.pyNativeWHT import PyNativeWHT
from ..train import _train
from datetime import datetime, timedelta, timezone
import pandas as pd


class TrainingModel(BaseModelType):
    TypeName = "training_model"
    BuildSpecSchema = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "occurred_at_col": {"type": "string"},
            **EntityKeyBuildSpecSchema["properties"],
            **MaterializationBuildSpecSchema["properties"],
            "training_file_lookup_path": {"type": ["string", "null"]},
            "validity_time": {
                "oneOf": [
                    {"type": "string", "enum": ["day", "week", "month"]},
                    {"type": "null"},
                ]
            },
            "warehouse": {"type": ["string", "null"]},
            "inputs": {"type": "array", "items": {"type": "string"}, "minItems": 1},
            "ml_config": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "data": {
                        "type": "object",
                        "additionalProperties": True,
                        "properties": {
                            "label_column": {"type": "string"},
                            "prediction_horizon_days": {"type": "integer"},
                        },
                        "required": ["label_column", "prediction_horizon_days"],
                    },
                    "preprocessing": {
                        "type": "object",
                    },
                    "train": {
                        "type": "object",
                    },
                },
                "required": ["data"],
            },
        },
        "required": [
            "inputs",
            "ml_config",
        ]
        + EntityKeyBuildSpecSchema["required"],
    }

    def __init__(self, build_spec: dict, schema_version: int, pb_version: str) -> None:
        if (
            "materialization" not in build_spec
            or "requested_enable_status" not in build_spec["materialization"]
        ):
            # This will ensure that the training model won't run if there is no prediction model in the project
            build_spec["materialization"] = {
                "requested_enable_status": "only_if_necessary"
            }
        if build_spec.get("validity_time", None) is None:
            build_spec["validity_time"] = "month"
        label_column = build_spec["ml_config"]["data"]["label_column"]
        if label_column not in build_spec["inputs"]:
            build_spec["inputs"].append(label_column)
        super().__init__(build_spec, schema_version, pb_version)

    def get_material_recipe(self) -> PyNativeRecipe:
        return TrainingRecipe(self.build_spec)

    def validate(self) -> tuple[bool, str]:
        data_config = self.build_spec["ml_config"]["data"]
        task = data_config.get("task", "")
        if task != "regression" and task != "" and task != "classification":
            return (
                False,
                f"Invalid task {task}. Supported tasks - classification, regression",
            )
        label_value = data_config.get("label_value", "")
        if label_value != "" and task == "regression":
            return False, "label_value is not allowed for regression task"
        return super().validate()


class TrainingRecipe(PyNativeRecipe):
    def __init__(self, build_spec: dict) -> None:
        self.build_spec = build_spec
        self.logger = Logger("TrainingRecipe")

    def describe(self, this: WhtMaterial):
        return (
            f"""
        Material - {this.name()}
        """,
            ".txt",
        )

    def _skip_training(self, this: WhtMaterial):
        if not self.build_spec.get("validity_time"):
            return False
        whtService = PyNativeWHT(
            this,
            this.wht_ctx.site_config().get("FilePath"),
            this.base_wht_project.project_path(),
        )
        s3_config = None
        # Preserve old behavior: use run_artefacts_s3 when configured.
        # This is fetched via parent runtime RPC subset, not direct siteconfig file read.
        if hasattr(this.wht_ctx, "py_models_credentials_presets"):
            try:
                presets = this.wht_ctx.py_models_credentials_presets() or {}
                run_artefacts_s3 = presets.get("run_artefacts_s3")
                if isinstance(run_artefacts_s3, dict):
                    s3_config = run_artefacts_s3
            except Exception:
                # Keep execution resilient; fallback to runtime storage config below.
                pass

        if s3_config is None:
            s3_config = whtService.get_s3_config() or {}
        mat_name_without_seq = this.name().rsplit("_", 1)[0]
        if (
            s3_config.get("bucket")
            and s3_config.get("region")
            and s3_config.get("path")
        ):
            bucket = s3_config["bucket"]
            region = s3_config["region"]
            path = s3_config["path"]
            self.logger.info(f"Checking for training files in {bucket} at {path}")
            return S3Utils.download_training_artifacts(
                bucket,
                region,
                path,
                os.path.join(this.get_output_folder(), this.name()),
                mat_name_without_seq,
                self._map_validity_to_timestamp(datetime.now(timezone.utc)),
            )
        # This flow is for runs from CLI
        if self.build_spec.get("training_file_lookup_path"):
            lookup_path = self.build_spec.get("training_file_lookup_path")
            if not os.path.exists(lookup_path):
                raise Exception(f"Path {lookup_path} does not exist")
            for root, dirs, _ in os.walk(lookup_path):
                for subdir in dirs:
                    if mat_name_without_seq in subdir:
                        subdir_path = os.path.join(root, subdir)
                        creation_time = os.path.getctime(subdir_path)
                        creation_datetime = datetime.fromtimestamp(creation_time)
                        if creation_datetime >= self._map_validity_to_timestamp(
                            datetime.now()
                        ):
                            subdir_files = [
                                f
                                for f in os.listdir(subdir_path)
                                if os.path.isfile(os.path.join(subdir_path, f))
                            ]
                            if len(subdir_files) == 0:
                                # Run probably failed that is why no files are present
                                continue
                            dest_dir = os.path.join(
                                this.get_output_folder(), this.name()
                            )
                            os.makedirs(dest_dir, exist_ok=True)
                            for file in os.listdir(subdir_path):
                                src_path = os.path.join(subdir_path, file)
                                dst_path = os.path.join(dest_dir, file)
                                if os.path.isdir(src_path):
                                    shutil.copytree(src_path, dst_path)
                                else:
                                    shutil.copy2(src_path, dst_path)
                            self.logger.info(
                                f"Valid training file found for {this.name()} in {subdir_path}"
                            )
                            return True
        return False

    def _map_validity_to_timestamp(self, current_time):
        validity_time = self.build_spec.get("validity_time")
        time_delta = {
            "day": timedelta(days=1),
            "week": timedelta(weeks=1),
            "month": timedelta(days=30),
        }
        return current_time - time_delta[validity_time]

    def register_dependencies(self, this: WhtMaterial):
        if self._get_creds(this)["type"] == "snowflake":
            if sys.version_info >= (3, 11):
                raise Exception(
                    f"Propensity model on Snowflake requires Python versions between 3.8 and 3.10. Current version: {sys.version_info}"
                )
        this.de_ref(self.build_spec["ml_config"]["data"]["label_column"])
        whtService = PyNativeWHT(
            this,
            this.wht_ctx.site_config().get("FilePath"),
            this.base_wht_project.project_path(),
        )
        # This method call is only for registering dependencies
        whtService.get_inputs(self.build_spec["inputs"])

    def get_training_file_path(this: WhtMaterial):
        folder = this.get_output_folder()
        return f"{folder}/{this.name()}/training_file.json"

    def _get_creds(self, this: WhtMaterial):
        site_config_path = this.wht_ctx.site_config().get("FilePath")
        whtService = PyNativeWHT(
            this, site_config_path, this.base_wht_project.project_path()
        )
        # TODO: Get creds from pywht
        creds = whtService.get_credentials(
            this.base_wht_project.project_path(), site_config_path
        )
        return creds

    def _resolve_snowflake_material_target(self, this: WhtMaterial):
        material_string = this.string()
        quoted_parts = [
            part for part in material_string.split('"') if part and part != "."
        ]
        if len(quoted_parts) >= 2:
            return quoted_parts[-1], quoted_parts[-2]

        plain_parts = [part for part in material_string.split(".") if part]
        if len(plain_parts) >= 2:
            return plain_parts[-1], plain_parts[-2]

        return material_string, None

    def _get_snowflake_material_target(self, this: WhtMaterial):
        # TODO: Prefer structured WHT grpc methods over local parsing wherever possible.
        resolved_target = getattr(this, "resolved_target", None)
        if callable(resolved_target):
            target = resolved_target()
            return target.get("table_name"), target.get("schema_name")

        table_name, schema_name = self._resolve_snowflake_material_target(this)
        if schema_name is None:
            # Fail loud instead of silently falling back to creds["schema"].
            # The original Snowflake bug (PR #735) was that the training write
            # and PB's latest-view creation routed to different schemas. If we
            # can't extract a schema here, we'd re-expose that same mismatch.
            raise ValueError(
                "Unable to resolve Snowflake target schema from material "
                f"string {this.string()!r}. Expected quoted or dotted "
                "schema-qualified identifier. Upgrade to a PB version that "
                "exposes resolved_target() grpc method."
            )
        return table_name, schema_name

    def execute(self, this: WhtMaterial):
        logger.set_logger(self.logger)
        if self._skip_training(this):
            self.logger.info(f"Skipping training for {this.name()}")
            # pb expects every model to create a material
            data = {"dummy_column": ["dummy_value"]}
            df = pd.DataFrame(data)
            this.write_output(df)
            return
        self.logger.info(
            f"No past training artefacts found within given validity time. Training for {this.name()}"
        )
        site_config_path = this.wht_ctx.site_config().get("FilePath")
        whtService = PyNativeWHT(
            this, site_config_path, this.base_wht_project.project_path()
        )
        # TODO: Get creds from pywht
        creds = self._get_creds(this)
        metrics_table_name = this.name()
        if creds["type"] == "snowflake":
            creds["warehouse"] = (
                self.build_spec.get("warehouse")
                if self.build_spec.get("warehouse")
                else creds["warehouse"]
            )
            metrics_table_name, target_schema = self._get_snowflake_material_target(
                this
            )
            if target_schema:
                creds["schema"] = target_schema
        output_filename = TrainingRecipe.get_training_file_path(this)
        runtime_info = {"is_rudder_backend": this.base_wht_project.is_rudder_backend()}
        config = self.build_spec.get("ml_config", {})
        _train(
            creds,
            whtService.get_inputs(self.build_spec["inputs"]),
            output_filename,
            config,
            site_config_path,
            runtime_info,
            whtService,
            constants.ML_CORE_PYNATIVE_PATH,
            metrics_table_name,
            os.path.join(this.get_output_folder(), this.name()),
        )
