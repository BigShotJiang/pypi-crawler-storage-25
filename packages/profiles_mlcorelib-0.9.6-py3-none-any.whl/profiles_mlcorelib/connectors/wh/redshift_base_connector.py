#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Amazon RedShift Connector."""

import io
import pandas as pd
import urllib.parse
import pandas_redshift as pr
import boto3
from typing import Literal, Optional

from sqlalchemy import create_engine
from sqlalchemy import orm as sa_orm
from sqlalchemy import text

from ...utils.logger import logger
from ...utils.S3Utils import S3Utils
from .connector_base import ConnectorBase


class RedShiftConnector(ConnectorBase):
    def __init__(self, creds: dict, db_config: dict, **kwargs) -> None:
        super().__init__(creds, db_config, **kwargs)

        self.s3_config = kwargs.get("s3_config", None)
        encoded_password = urllib.parse.quote(creds["password"], safe="")
        connection_string = f"postgresql://{creds['user']}:{encoded_password}@{creds['host']}:{creds['port']}/{db_config['database']}"
        self.engine = create_engine(connection_string)

        Session = sa_orm.sessionmaker()
        Session.configure(bind=self.engine)
        self.connection = Session()
        if db_config.get("schema", None):
            schema_sql = text(f"SET search_path TO {db_config['schema']}")
            self.connection.execute(schema_sql)
            self.connection.commit()

    def write_to_table(
        self,
        df: pd.DataFrame,
        table_name: str,
        schema: str,
        if_exists: Literal["fail", "replace", "append"] = "append",
    ):
        # Parse schema.table from quoted identifiers like "schema"."table"
        clean_name = table_name.replace('"', "").replace("'", "")
        if "." in clean_name:
            parts = clean_name.split(".")
            schema = parts[-2]
            table_name = parts[-1]
        logger.get().debug("Redshift write_to_table")

        try:
            use_iam_role = bool(self.s3_config and self.s3_config.get("role_arn"))
            use_explicit_keys = bool(
                self.s3_config
                and self.s3_config.get("access_key_id")
                and self.s3_config.get("access_key_secret")
            )
            if not self.s3_config or (not use_iam_role and not use_explicit_keys):
                logger.get().warning(
                    "Using INSERT statement to write to Redshift, consider using S3 based approach by "
                    "specifying role_arn or access_key_id/secret_access_key in the storage config"
                )
                df.to_sql(
                    name=table_name.lower(),
                    con=self.engine,
                    schema=schema,
                    index=False,
                    if_exists=if_exists,
                    method="multi",
                )
            else:
                logger.get().info(f"Establishing connection to Redshift")
                pr.connect_to_redshift(
                    dbname=self.db_config["database"],
                    host=self.creds["host"],
                    port=self.creds["port"],
                    user=self.creds["user"],
                    password=self.creds["password"],
                )

                s3_bucket = self.s3_config.get("bucket", None)
                s3_sub_dir = self.s3_config.get("path", None)

                logger.get().info(f"Establishing connection to S3")
                if use_iam_role:
                    # pandas_redshift requires access key args even for IAM role mode.
                    # We assume the role to fetch temporary keys, then pass aws_iam_role.
                    temp_creds = self._assume_role_credentials(
                        self.s3_config["role_arn"]
                    )
                    pr.connect_to_s3(
                        aws_access_key_id=temp_creds["AccessKeyId"],
                        aws_secret_access_key=temp_creds["SecretAccessKey"],
                        aws_session_token=temp_creds.get("SessionToken", ""),
                        aws_iam_role=self.s3_config["role_arn"],
                        bucket=s3_bucket,
                        subdirectory=s3_sub_dir,
                    )
                else:
                    pr.connect_to_s3(
                        aws_access_key_id=self.s3_config["access_key_id"],
                        aws_secret_access_key=self.s3_config["access_key_secret"],
                        bucket=s3_bucket,
                        subdirectory=s3_sub_dir,
                        # As of release 1.1.1 you are able to specify an aws_session_token (if necessary):
                        aws_session_token=self.s3_config["aws_session_token"],
                    )

                # Write the DataFrame to S3 and then to redshift
                logger.get().info(f"Writing pandas df to S3 and then to Redshift")
                pr.pandas_to_redshift(
                    data_frame=df,
                    redshift_table_name=f"{schema}.{table_name}",
                    append=if_exists == "append",
                )
                logger.get().info(
                    f"Successfully wrote table {table_name} to S3 and then to Redshift"
                )
        except Exception as e:
            logger.get().error(f"Error while writing to warehouse: {e}")
            raise Exception(f"Error while writing to warehouse: {e}")

    def write_with_s3_cleanup(
        self,
        df: pd.DataFrame,
        table_name: str,
        schema: str,
        s3_job_path: str,
        batch_id: str,
        if_exists: Literal["fail", "replace", "append"] = "append",
    ) -> None:
        """
        Write DataFrame to Redshift via S3 COPY with automatic cleanup.

        This method provides better control over S3 staging files compared to pandas_redshift:
        - Uses a unique path per batch for data isolation
        - Cleans up S3 files immediately after successful COPY
        - Supports multi-tenant environments with isolated paths
        - Falls back to direct SQL INSERT when explicit S3 credentials are not provided

        Args:
            df: DataFrame to write
            table_name: Target table name in Redshift
            schema: Target schema name
            s3_job_path: S3 path for this job (e.g., "staging/model_name/hash/uuid")
            batch_id: Unique identifier for this batch
            if_exists: How to handle existing table ("fail", "replace", "append")
        """
        if not self.s3_config or not self.s3_config.get("bucket"):
            logger.get().warning(
                "S3 bucket not configured in storage config, falling back to direct SQL insert"
            )
            self.write_to_table(df, table_name, schema, if_exists)
            return

        # For first batch (replace mode), delegate to write_to_table() which creates
        # the table with correct column types via pandas type inference.
        # S3 COPY requires a pre-existing table and we avoid creating it with
        # all-VARCHAR(65535) columns. Subsequent batches (append) use S3 COPY.
        if if_exists == "replace":
            logger.get().info(
                "First batch: using write_to_table() to create table with correct column types"
            )
            self.write_to_table(df, table_name, schema, if_exists)
            return

        # Parse schema.table from quoted identifiers like "schema"."table"
        clean_name = table_name.replace('"', "").replace("'", "")
        if "." in clean_name:
            parts = clean_name.split(".")
            schema = parts[-2]
            table_name = parts[-1]

        s3_bucket = self.s3_config.get("bucket")
        # Strip leading slashes to avoid double-slash in S3 paths
        s3_file_key = f"{s3_job_path.lstrip('/')}/batch_{batch_id}.csv"
        s3_uri = None

        # Stage 1: S3 upload and credential resolution. If either fails (wrong
        # path, permissions, STS error), fall back to direct SQL INSERT.
        try:
            s3_client = self._create_s3_client()
            s3_uri = self._upload_df_to_s3(df, s3_bucket, s3_file_key, s3_client)
            logger.get().info(f"Uploaded batch {batch_id} to {s3_uri}")
            # Resolve COPY auth clause before executing the command.
            copy_auth_sql = self._get_copy_auth_sql()
        except Exception as e:
            logger.get().warning(
                f"S3 upload/credential resolution failed for batch {batch_id}, "
                f"falling back to direct SQL insert: {e}"
            )
            # Clean up the S3 file if it was uploaded before the failure
            if s3_uri:
                self._delete_s3_file(s3_bucket, s3_file_key, s3_client)
            self.write_to_table(df, table_name, schema, if_exists)
            return

        # Stage 2: Execute COPY command. If this fails the error propagates —
        # the data is already in S3 and the issue is likely a schema/data mismatch
        # that INSERT wouldn't solve either.
        try:
            self._execute_copy_command(
                s3_uri=s3_uri,
                table_name=table_name,
                schema=schema,
                columns=list(df.columns),
                if_exists=if_exists,
                copy_auth_sql=copy_auth_sql,
            )
            logger.get().info(
                f"Successfully loaded batch {batch_id} into {schema}.{table_name}"
            )
        finally:
            # Always attempt to clean up the S3 file after COPY
            self._delete_s3_file(s3_bucket, s3_file_key, s3_client)

    def _has_explicit_s3_creds(self) -> bool:
        """Check if explicit S3 credentials are available in the config."""
        return bool(
            self.s3_config
            and self.s3_config.get("access_key_id")
            and self.s3_config.get("access_key_secret")
        )

    def _has_iam_role(self) -> bool:
        """Check if IAM role based auth is configured."""
        return bool(self.s3_config and self.s3_config.get("role_arn"))

    def _assume_role_credentials(self, role_arn: str) -> dict:
        """Assume IAM role and return temporary credentials."""
        region = self.s3_config.get("region", "us-east-1")
        sts_client = boto3.client("sts", region_name=region)
        response = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName="profiles_redshift_s3_access",
            DurationSeconds=900,
        )
        return response["Credentials"]

    def _create_s3_client(self):
        """Create a boto3 S3 client using configured auth mechanism.

        Auth priority:
        1. role_arn (assume role)
        2. explicit keys (access_key_id/access_key_secret)
        """
        region = self.s3_config.get("region", "us-east-1")

        if self._has_iam_role():
            creds = self._assume_role_credentials(self.s3_config["role_arn"])
            return boto3.client(
                "s3",
                aws_access_key_id=creds.get("AccessKeyId"),
                aws_secret_access_key=creds.get("SecretAccessKey"),
                aws_session_token=creds.get("SessionToken"),
                region_name=region,
            )

        if not self._has_explicit_s3_creds():
            raise RuntimeError(
                "No supported S3 auth found (role_arn or access_key_id/access_key_secret). "
                "Cannot use S3 COPY path."
            )

        return boto3.client(
            "s3",
            aws_access_key_id=self.s3_config.get("access_key_id"),
            aws_secret_access_key=self.s3_config.get("access_key_secret"),
            aws_session_token=self.s3_config.get("aws_session_token") or None,
            region_name=region,
        )

    def _get_temporary_credentials(self, access_key: str, secret_key: str) -> dict:
        """Exchange long-lived IAM user credentials for short-lived temporary ones
        via STS GetSessionToken.

        This avoids embedding long-lived credentials in the COPY SQL, which gets
        logged in Redshift system tables (stl_query, SVL_STATEMENTTEXT). Temporary
        credentials expire and are safe to expose in logs.

        Args:
            access_key: Long-lived AWS access key ID
            secret_key: Long-lived AWS secret access key

        Returns:
            Dict with keys: AccessKeyId, SecretAccessKey, SessionToken
        """
        region = self.s3_config.get("region", "us-east-1")
        sts_client = boto3.client(
            "sts",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region,
        )
        response = sts_client.get_session_token(DurationSeconds=900)
        return response["Credentials"]

    def _get_copy_credentials_str(self) -> str:
        """Build the CREDENTIALS string for the Redshift COPY command.

        Security: To avoid exposing long-lived credentials in Redshift query logs
        (stl_query, SVL_STATEMENTTEXT), this method exchanges long-lived IAM user
        credentials for short-lived temporary ones via STS GetSessionToken.

        Credential handling:
        - Long-lived explicit creds (no session token) → exchange via STS for temp creds
        - Already-temporary explicit creds (has session token) → use as-is (already safe)
        - No explicit creds → raises (caller falls back to direct SQL INSERT)
        """
        if self._has_iam_role():
            raise RuntimeError(
                "_get_copy_credentials_str should not be used for IAM role mode."
            )

        if not self._has_explicit_s3_creds():
            raise RuntimeError(
                "No explicit S3 credentials (access_key_id, access_key_secret) "
                "in block_store_creds. Cannot build COPY credentials."
            )

        # If a session token already exists, the credentials are already temporary
        # (e.g., from AssumeRole). Use them directly — GetSessionToken cannot be
        # called with temporary credentials.
        if self.s3_config.get("aws_session_token"):
            logger.get().debug("Using existing temporary credentials for COPY command")
            return (
                f"aws_access_key_id={self.s3_config['access_key_id']};"
                f"aws_secret_access_key={self.s3_config['access_key_secret']};"
                f"token={self.s3_config['aws_session_token']}"
            )

        # Long-lived credentials — exchange for temporary ones via STS
        # to avoid exposing them in Redshift query logs.
        logger.get().info(
            "Exchanging long-lived credentials for temporary ones via STS "
            "to avoid exposing them in Redshift query logs"
        )
        temp_creds = self._get_temporary_credentials(
            self.s3_config["access_key_id"],
            self.s3_config["access_key_secret"],
        )
        return (
            f"aws_access_key_id={temp_creds['AccessKeyId']};"
            f"aws_secret_access_key={temp_creds['SecretAccessKey']};"
            f"token={temp_creds['SessionToken']}"
        )

    def _get_copy_auth_sql(self) -> str:
        """Build COPY auth SQL clause with IAM role preference."""
        if self._has_iam_role():
            safe_role_arn = self.s3_config["role_arn"].replace("'", "''")
            return f"IAM_ROLE '{safe_role_arn}'"
        return f"CREDENTIALS '{self._get_copy_credentials_str()}'"

    def _upload_df_to_s3(
        self, df: pd.DataFrame, bucket: str, file_key: str, s3_client
    ) -> str:
        """
        Upload DataFrame as CSV to S3.

        Args:
            df: DataFrame to upload
            bucket: S3 bucket name
            file_key: S3 object key (path)
            s3_client: Configured boto3 S3 client

        Returns:
            Full S3 URI of the uploaded file
        """
        # Convert DataFrame to CSV directly as bytes to avoid holding
        # two copies (string + encoded bytes) in memory simultaneously
        csv_buffer = io.BytesIO()
        df.to_csv(csv_buffer, index=False, header=False, encoding="utf-8")
        csv_buffer.seek(0)

        # Upload to S3
        s3_client.upload_fileobj(csv_buffer, bucket, file_key)

        return f"s3://{bucket}/{file_key}"

    def _execute_copy_command(
        self,
        s3_uri: str,
        table_name: str,
        schema: str,
        columns: list,
        copy_auth_sql: str,
        if_exists: str = "append",
    ) -> None:
        """
        Execute Redshift COPY command to load data from S3.

        Args:
            s3_uri: S3 URI of the CSV file
            table_name: Target table name
            schema: Target schema name
            columns: List of column names
            copy_auth_sql: Pre-resolved COPY auth SQL clause
            if_exists: How to handle existing data
        """
        # Note: This method is only called with if_exists="append" since
        # write_with_s3_cleanup() delegates "replace" to write_to_table()
        # which creates the table with correct column types.

        # Build column list for COPY
        column_list = ", ".join([f'"{col}"' for col in columns])

        # Execute COPY command
        copy_sql = f"""
            COPY "{schema}"."{table_name}" ({column_list})
            FROM '{s3_uri}'
            {copy_auth_sql}
            CSV
            IGNOREHEADER 0
            EMPTYASNULL
            BLANKSASNULL
            REGION '{self.s3_config.get("region", "us-east-1")}'
        """

        self.connection.execute(text(copy_sql))
        self.connection.commit()

    def _delete_s3_file(self, bucket: str, file_key: str, s3_client=None) -> bool:
        """
        Delete a single S3 file after successful COPY.

        Args:
            bucket: S3 bucket name
            file_key: S3 object key to delete
            s3_client: Pre-configured boto3 S3 client (optional, creates one if not provided)

        Returns:
            True if deletion was successful, False otherwise
        """
        try:
            if s3_client is None:
                s3_client = self._create_s3_client()
            s3_client.delete_object(Bucket=bucket, Key=file_key)
            logger.get().debug(f"Cleaned up S3 staging file: s3://{bucket}/{file_key}")
            return True
        except Exception as e:
            logger.get().warning(
                f"Failed to clean up S3 staging file s3://{bucket}/{file_key}: {e}"
            )
            return False

    def cleanup_s3_job_directory(self, s3_job_path: str) -> bool:
        """
        Clean up entire S3 job directory. Use this on job failure to ensure
        no orphaned files remain.

        Args:
            s3_job_path: The S3 path prefix to delete (e.g., "staging/model/hash/uuid")

        Returns:
            True if cleanup was successful, False otherwise
        """
        if not self.s3_config:
            return True

        try:
            bucket = self.s3_config.get("bucket")
            region = self.s3_config.get("region", "us-east-1")
            S3Utils.delete_directory(bucket, region, s3_job_path)
            logger.get().info(
                f"Cleaned up S3 job directory: s3://{bucket}/{s3_job_path}"
            )
            return True
        except Exception as e:
            logger.get().warning(
                f"Failed to clean up S3 job directory s3://{bucket}/{s3_job_path}: {e}"
            )
            return False
