import asyncio
import os
import re
import sys
from collections.abc import Callable
from functools import wraps
from importlib import metadata
from pathlib import Path
from typing import Any

import httpx
from packaging.version import Version, parse

_ENV_VAR_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(:-([^}]*))?\}")


def expand_env_vars(value: Any) -> Any:
    """Recursively expand ``${VAR}`` and ``${VAR:-default}`` in string values.

    Matches pydantic-ai's MCP config convention. Raises ``ValueError`` when a
    required variable is missing and no default is provided.
    """
    if isinstance(value, str):

        def replace(match: re.Match[str]) -> str:
            name = match.group(1)
            has_default = match.group(2) is not None
            default = match.group(3) or ""
            if name in os.environ:
                return os.environ[name]
            if has_default:
                return default
            raise ValueError(f"Environment variable ${{{name}}} is not defined")

        return _ENV_VAR_PATTERN.sub(replace, value)
    if isinstance(value, dict):
        return {k: expand_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [expand_env_vars(v) for v in value]
    return value


def debounce(wait: float) -> Callable:
    """
    A decorator to debounce a function, ensuring it is called only after a specified delay
    and always executes after the last call.

    Args:
        wait (float): The debounce delay in seconds.

    Returns:
        Callable: The decorated function.
    """

    def decorator(func: Callable) -> Callable:
        last_call = None
        task = None

        @wraps(func)
        async def debounced(*args, **kwargs):
            nonlocal last_call, task
            last_call = asyncio.get_event_loop().time()

            if task:
                task.cancel()

            async def call_func():
                await asyncio.sleep(wait)
                if asyncio.get_event_loop().time() - last_call >= wait:  # ty: ignore[unsupported-operator]  # pragma: no branch
                    await func(*args, **kwargs)

            task = asyncio.create_task(call_func())

        return debounced

    return decorator


def throttle(interval: float) -> Callable:
    """
    A decorator to throttle a function, ensuring it is called at most once per interval.
    The first call executes immediately, subsequent calls within the interval are ignored.

    Args:
        interval (float): The throttle interval in seconds.

    Returns:
        Callable: The decorated function.
    """

    def decorator(func: Callable) -> Callable:
        last_called_at = None

        @wraps(func)
        async def throttled(*args, **kwargs):
            nonlocal last_called_at
            now = asyncio.get_event_loop().time()

            if last_called_at is None or now - last_called_at >= interval:
                last_called_at = now
                await func(*args, **kwargs)

        return throttled

    return decorator


def get_default_data_dir() -> Path:
    """
    Get the user data directory for the current system platform.

    Linux/Android: ~/.local/share/oterm
    macOS: ~/Library/Application Support/oterm
    Windows: C:/Users/<USER>/AppData/Roaming/oterm

    :return: User Data Path
    :rtype: Path
    """
    home = Path.home()

    system_paths = {
        "win32": home / "AppData/Roaming/oterm",
        "linux": Path(os.getenv("XDG_DATA_HOME") or Path(home / ".local/share"))
        / "oterm",
        "darwin": Path(
            os.getenv("XDG_DATA_HOME") or Path(home / "Library/Application Support")
        )
        / "oterm",
        "android": Path(os.getenv("XDG_DATA_HOME") or Path(home / ".local/share"))
        / "oterm",
    }

    data_path = system_paths[sys.platform]
    return data_path


def semantic_version_to_int(version: str) -> int:
    """
    Convert a semantic version string to an integer.

    :param version: Semantic version string
    :type version: str
    :return: Integer representation of semantic version
    :rtype: int
    """
    major, minor, patch = version.split(".")
    major = int(major) << 16
    minor = int(minor) << 8
    patch = int(patch)
    return major + minor + patch


def int_to_semantic_version(version: int) -> str:
    """
    Convert an integer to a semantic version string.

    :param version: Integer representation of semantic version
    :type version: int
    :return: Semantic version string
    :rtype: str
    """
    major = version >> 16
    minor = (version >> 8) & 255
    patch = version & 255
    return f"{major}.{minor}.{patch}"


async def is_up_to_date() -> tuple[bool, Version, Version]:
    """
    Checks whether oterm is current.

    :return: A tuple containing a boolean indicating whether oterm is current, the running version and the latest version
    :rtype: tuple[bool, Version, Version]
    """

    async with httpx.AsyncClient() as client:
        running_version = parse(metadata.version("oterm"))
        try:
            response = await client.get("https://pypi.org/pypi/oterm/json")
            data = response.json()
            pypi_version = parse(data["info"]["version"])
        except Exception:
            # If no network connection, do not raise alarms.
            pypi_version = running_version
    return running_version >= pypi_version, running_version, pypi_version
