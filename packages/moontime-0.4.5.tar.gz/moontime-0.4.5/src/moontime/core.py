from __future__ import annotations

from datetime import datetime, timedelta
import os
from typing import Optional

import pytz
from dateutil import parser

from . import aether as af
from .ledger import planetary_day_for as _planetary_day_for
from .ledger import load_calendar_for_date as _load_calendar_for_date
from .ledger import get_pytz_timezone as _get_pytz_timezone
from .aether_thresher import (
    current_season as _season_for_dt,
    season_start_for as _season_start_for,
    sunrise_azimuth as _sunrise_azimuth,
    sunrise_azimuth_for_declination as _sunrise_az_for_dec,
    planetary_temporal as _planetary_temporal,
)
try:
    from aetherfield.core import OBLIQUITY_DEG as _OB_DEG
except Exception:
    _OB_DEG= 23.43928

# Defaults configurable via environment variables
DEFAULT_ZONE = pytz.timezone(os.getenv("MOONTIME_TZ", "UTC")) if hasattr(pytz, "timezone") else pytz.UTC
DEFAULT_COORDS = os.getenv("MOONTIME_COORDS", "0,0")
DEFAULT_HEMISPHERE = os.getenv("MOONTIME_HEMISPHERE", "N")


def get_pytz_timezone(zone) -> pytz.BaseTzInfo:
    """Best-effort tz resolver compatible with pytz-aware datetimes.

    Accepts either a tzinfo object or an IANA TZ string. Falls back to UTC.
    """
    try:
        if hasattr(zone, "localize"):
            return zone
        if isinstance(zone, str) and zone:
            return pytz.timezone(zone)
    except Exception:
        pass
    return pytz.UTC


# Module-level defaults used by fromisoformat() fallbacks
ZONE = DEFAULT_ZONE
COORDS = DEFAULT_COORDS


class MoonTime:
    """
    A timezone-aware wrapper around a moment that exposes "temporal" time:
    - Each civil day splits into 12 night hours (sunset→sunrise) and 12 day hours (sunrise→next sunset).
    - Each temporal hour has 60 temporal minutes and each minute has 60 temporal seconds.
    - Temporal minutes/seconds have variable real-time length depending on season and day/night.

    Works alongside datetime/timedelta via +/− operators. Arithmetic uses real seconds.
    """

    __slots__ = (
        "moment",
        "zone",
        "coords",
        # seasonal fields
        "season",
        "season_start",
        # solar day-length and sunrise geometry
        "day_length_seconds",
        "day_length_delta_seconds",
        "day_length_trend",
        "sunrise_azimuth_deg",
        "sunrise_solstice_scale_0_100",
        "solar_movement",
        "info",
        "day",
        "day_index",
        "day_ruler",
        "hour",
        "hour_index",
        "hour_ruler",
        "hour_start",
        "hour_end",
        "hour_length_seconds",
        "minute",
        "minute_index",
        "minute_start",
        "minute_end",
        "minute_length_seconds",
        "second",
        "second_index",
        "second_start",
        "second_end",
        "second_length_seconds",
        # lunar calendar fields
        "year",
        "lunar_year",
        "gregorian_year",
        "month",
        "lunar_month_index",
        "lunar_month_name",
        "lunar_day",
        "lunar_weekday",
        "sun_sign",
        "lunar_sun_sign",
        # moon phase
        "moon_phase",
        "moon_illum",
        "moon_angle",
        "phase",
        "angle",
        "illumination"
    )

    def __init__(self, moment: Optional[datetime] = None, zone=None, coords=None):
        self.zone = zone if zone is not None else ZONE
        self.coords = coords if coords is not None else COORDS

        local_tz = _get_pytz_timezone(self.zone)
        if moment is None:
            self.moment = datetime.now(local_tz)
        else:
            if getattr(moment, "tzinfo", None) is None:
                self.moment = local_tz.localize(moment)
            else:
                self.moment = moment.astimezone(local_tz)

        self._compute()

    @staticmethod
    def now(zone=None, coords=None) -> "MoonTime":
        return MoonTime(moment=None, zone=zone, coords=coords)

    @staticmethod
    def from_datetime(dt: datetime, zone=None, coords=None) -> "MoonTime":
        return MoonTime(moment=dt, zone=zone, coords=coords)

    def _compute(self) -> None:
        info = _planetary_day_for(self.moment, self.zone, self.coords)
        if not info:
            raise ValueError("Moment is outside the planetary-day ledger range.")
        self.info = info

        # Seasonal awareness (North hemisphere by default)
        hemi = DEFAULT_HEMISPHERE
        self.season = _season_for_dt(self.moment, hemisphere=hemi)
        try:
            _, start_dt = _season_start_for(self.moment, _get_pytz_timezone(self.zone), hemisphere=hemi)
        except Exception:
            start_dt = None
        self.season_start = start_dt

        # Solar day length and sunrise geometry
        self.day_length_seconds = None
        self.day_length_delta_seconds = None
        self.day_length_trend = None
        self.sunrise_azimuth_deg = None
        self.sunrise_solstice_scale_0_100 = None
        self.solar_movement = None

        try:
            tz = _get_pytz_timezone(self.zone)
            # Day length today
            sr, ss = af.sunrise_sunset(tz, str(self.coords), date=self.moment.date())
            if sr and ss:
                self.day_length_seconds = max(0.0, (ss - sr).total_seconds())

            # Compare to yesterday
            from datetime import timedelta as _td
            y_date = (self.moment - _td(days=1)).date()
            ysr, yss = af.sunrise_sunset(tz, str(self.coords), date=y_date)
            if self.day_length_seconds is not None and ysr and yss:
                y_len = max(0.0, (yss - ysr).total_seconds())
                self.day_length_delta_seconds = self.day_length_seconds - y_len
                if abs(self.day_length_delta_seconds) < 0.5:
                    self.day_length_trend = "equal"
                elif self.day_length_delta_seconds > 0:
                    self.day_length_trend = "longer"
                else:
                    self.day_length_trend = "shorter"

            # Sunrise azimuth today
            try:
                lat_s, lon_s = str(self.coords).split(",")
                lat = float(lat_s.strip()); lon = float(lon_s.strip())
                self.sunrise_azimuth_deg = _sunrise_azimuth(self.moment, lat, lon, tz)
            except Exception:
                self.sunrise_azimuth_deg = None

            # Solar movement (north/south) via sunrise az change vs yesterday
            try:
                if self.sunrise_azimuth_deg is not None:
                    from datetime import timedelta as _td
                    y_az = _sunrise_azimuth(self.moment - _td(days=1), lat, lon, tz)
                    if y_az is not None:
                        delta = self.sunrise_azimuth_deg - y_az
                        eps = 1e-3
                        if delta < -eps:
                            self.solar_movement = "north"
                        elif delta > eps:
                            self.solar_movement = "south"
                        else:
                            self.solar_movement = "stationary"
            except Exception:
                self.solar_movement = None

            # Normalized sunrise position scale: 0 at equinox, 100 at solstice
            if self.sunrise_azimuth_deg is not None:
                try:
                    eq_az = _sunrise_az_for_dec(lat, 0.0)
                    sol_n = _sunrise_az_for_dec(lat, _OB_DEG)
                    sol_s = _sunrise_az_for_dec(lat, -_OB_DEG)
                    extremes = []
                    if sol_n is not None and eq_az is not None:
                        extremes.append(abs(sol_n - eq_az))
                    if sol_s is not None and eq_az is not None:
                        extremes.append(abs(sol_s - eq_az))
                    if eq_az is not None and extremes:
                        dmax = max(extremes)
                        dcur = abs(self.sunrise_azimuth_deg - eq_az)
                        if dmax > 1e-6:
                            self.sunrise_solstice_scale_0_100 = max(0.0, min(100.0, 100.0 * dcur / dmax))
                except Exception:
                    self.sunrise_solstice_scale_0_100 = None
        except Exception:
            # Leave fields as None on any failure (e.g., bad coords)
            pass

        # Copy commonly used fields for convenience
        self.day_index = info["day_index"]
        self.day_ruler = info["day_ruler"]
        self.hour_index = info["hour_index"]
        self.hour = info["hour_index"]
        self.hour_ruler = info["hour_ruler"]
        self.hour_start = info["hour_start"]
        self.hour_end = info["hour_end"]
        self.hour_length_seconds = info["hour_length_seconds"]
        self.minute_index = info["minute_index"]
        self.minute = info["minute_index"]
        self.minute_start = info["minute_start"]
        self.minute_end = info["minute_end"]
        self.minute_length_seconds = info["minute_length_seconds"]
        self.second_index = info["second_index"]
        self.second = info["second_index"]
        self.second_start = info["second_start"]
        self.second_end = info["second_end"]
        self.second_length_seconds = info["second_length_seconds"]

        # Lunar calendar alignment for this moment
        if _load_calendar_for_date is not None:
            cal = _load_calendar_for_date(self.moment)
        else:
            cal = None
        if cal:
            self.lunar_year = cal.get("lunar_year") + 6738
            self.year = cal.get("lunar_year") + 6738
            self.gregorian_year = cal.get("gregorian_year")
            self.lunar_month_index = cal.get("month_index")
            self.month = cal.get("month_index")
            self.lunar_month_name = cal.get("month_name")
            self.lunar_day = cal.get("day_in_month")
            self.day = cal.get("day_in_month")

            self.lunar_weekday = cal.get("weekday")[0]
            # Use AetherField for sun sign (runtime; avoids Skyfield dependency)
            try:
                sign = af.sign(self, body="sun")
                self.lunar_sun_sign = sign
                self.sun_sign = sign
            except Exception:
                sign = cal.get("sun_sign")
                self.lunar_sun_sign = sign
                self.sun_sign = sign

        else:
            self.lunar_year = None
            self.year = None
            self.gregorian_year = None
            self.lunar_month_index = None
            self.month = None
            self.lunar_month_name = None
            self.lunar_day = None
            self.lunar_weekday = None
            self.lunar_sun_sign = None
            self.sun_sign = None

        # Moon phase via AetherField (fallbacks set None)
        try:
            _, moon_data = af.moon_phase(self)
            self.moon_phase = moon_data.get("name")
            self.moon_illum = moon_data.get("illum")
            self.moon_angle = moon_data.get("angle_deg")
            self.phase = moon_data.get("name")
            self.illumination = moon_data.get("illum")
            self.angle = moon_data.get("angle_deg")
        except Exception:
            self.moon_phase = None
            self.moon_illum = None
            self.moon_angle = None
            self.phase = None
            self.illumination = None
            self.angle = None

    # -------- Temporal readouts --------
    @property
    def is_day(self) -> bool:
        return self.hour_index > 12

    @property
    def hour_24(self) -> int:
        return self.hour_index  # 1..24

    @property
    def hour_12(self) -> int:
        return self.hour_index - 12 if self.is_day else self.hour_index  # 1..12

    @property
    def minute_60(self) -> int:
        return max(0, self.minute_index - 1)  # 0..59 for display

    @property
    def second_60(self) -> int:
        return max(0, self.second_index - 1)  # 0..59 for display

    def temporal_hms(self, use_24h: bool = True, timespec: str = "seconds") -> str:
        """Return temporal time as HH:MM:SS[.mmm|.ffffff].

        - use_24h: when False, uses 12-hour clock for the temporal hour.
        - timespec: one of "seconds" (default), "milliseconds", or "microseconds".
        """
        h = self.hour_24 if use_24h else self.hour_12
        if timespec not in ("seconds", "milliseconds", "ms", "microseconds", "us"):
            raise ValueError("timespec must be 'seconds', 'milliseconds', or 'microseconds'")
        base = f"{h:02d}:{self.minute_60:02d}:{self.second_60:02d}"
        if timespec in ("milliseconds", "ms"):
            return f"{base}.{self.temporal_millisecond:03d}"
        if timespec in ("microseconds", "us"):
            return f"{base}.{self.temporal_microsecond:06d}"
        return base

    @property
    def temporal_millisecond(self) -> int:
        """Millisecond (0..999) into the current temporal second.

        Computed by dividing the variable-length temporal second into 1000
        equal parts and measuring progress of the current moment within it.
        Falls back to wall-clock millisecond if bounds are unavailable.
        """
        try:
            span = float(self.second_length_seconds)
            if span <= 0:
                raise ValueError
            elapsed = (self.moment - self.second_start).total_seconds()
            if elapsed < 0:
                frac = 0.0
            elif elapsed >= span:
                frac = 0.999999
            else:
                frac = elapsed / span
            ms = int(frac * 1000.0)
            return 0 if ms < 0 else (999 if ms > 999 else ms)
        except Exception:
            return int(self.moment.microsecond // 1000)

    @property
    def temporal_microsecond(self) -> int:
        """Microsecond (0..999999) into the current temporal second.

        Computed by dividing the variable-length temporal second into 1,000,000
        equal parts and measuring progress of the current moment within it.
        Falls back to wall-clock microsecond if bounds are unavailable.
        """
        try:
            span = float(self.second_length_seconds)
            if span <= 0:
                raise ValueError
            elapsed = (self.moment - self.second_start).total_seconds()
            if elapsed < 0:
                frac = 0.0
            elif elapsed >= span:
                frac = 0.999999999999
            else:
                frac = elapsed / span
            us = int(frac * 1_000_000.0)
            return 0 if us < 0 else (999_999 if us > 999_999 else us)
        except Exception:
            return int(self.moment.microsecond)

    def as_dict(self) -> dict:
        return {
            "moment": self.moment,
            "zone": (getattr(self.moment.tzinfo, "zone", None)
                      or self.moment.tzinfo.tzname(self.moment)
                      or str(self.moment.tzinfo)),
            "coords": self.coords,
            "phase": self.phase,
            "day_index": self.day_index,
            "day_ruler": self.day_ruler,
            "hour_index": self.hour_index,
            "hour_ruler": self.hour_ruler,
            "hour_start": self.hour_start,
            "hour_end": self.hour_end,
            "hour_length_seconds": self.hour_length_seconds,
            "minute_index": self.minute_index,
            "minute_start": self.minute_start,
            "minute_end": self.minute_end,
            "minute_length_seconds": self.minute_length_seconds,
            "second_index": self.second_index,
            "second_start": self.second_start,
            "second_end": self.second_end,
            "second_length_seconds": self.second_length_seconds,
            "temporal_time": self.temporal_hms(timespec="seconds"),
            "temporal_time_us": self.temporal_hms(timespec="microseconds"),
            "temporal_millisecond": self.temporal_millisecond,
            "temporal_microsecond": self.temporal_microsecond,
            # lunar
            "lunar_year": self.lunar_year,
            "gregorian_year": self.gregorian_year,
            "lunar_month_index": self.lunar_month_index,
            "lunar_month_name": self.lunar_month_name,
            "lunar_day": self.lunar_day,
            "lunar_weekday": self.lunar_weekday,
            "lunar_sun_sign": self.lunar_sun_sign,
            "moon_phase": self.moon_phase,
            "moon_illum": self.moon_illum,
            "moon_angle": self.moon_angle,
            # solar day length + sunrise geometry
            "day_length_seconds": self.day_length_seconds,
            "day_length_delta_seconds": self.day_length_delta_seconds,
            "day_length_trend": self.day_length_trend,
            "sunrise_azimuth_deg": self.sunrise_azimuth_deg,
            "sunrise_solstice_scale_0_100": self.sunrise_solstice_scale_0_100,
            "solar_movement": self.solar_movement,
            # seasons
            "season": self.season,
            "season_start": (self.season_start.isoformat() if self.season_start else None),
            "lunar_date_str": self.lunar_date_str,
            "lunar_date_iso": self.temporal_iso(timespec="microseconds"),
            "iso": self.isoformat(),
            "iso5": self.isoformat5(timespec="microseconds"),
        }

    @property
    def lunar_date_str(self) -> str:
        if self.lunar_year is None or self.lunar_month_name is None or self.lunar_day is None:
            return "?-?-?"
        return (
            f"{self.lunar_year:04d}-{self.lunar_month_index:02d}-{self.lunar_day:02d} "
            f"{self.temporal_hms(timespec='microseconds')}"
        )

    @property
    def display_str(self) -> str:
        year = self.lunar_year if self.lunar_year is not None else "?"
        month = self.lunar_month_index if self.lunar_month_index is not None else "?"
        day = self.lunar_day if self.lunar_day is not None else "?"
        date_str = f"{int(year):04d}-{int(month):02d}-{int(day):02d}" if year != "?" and month != "?" and day != "?" else "?-?-?"

        illum_raw = self.moon_illum if self.moon_illum is not None else 0
        if illum_raw > 100:
            illum = illum_raw / 1000.0
        else:
            illum = illum_raw / 100.0
        illum = max(0.0, min(1.0, float(illum)))

        def infer_waxing() -> bool | None:
            phase = getattr(self, "moon_phase", None) or ""
            p = str(phase).lower()
            if p.startswith("wax"):
                return True
            if p.startswith("wan"):
                return False
            if "first quarter" in p:
                return True
            if "last quarter" in p:
                return False
            return None

        waxing = infer_waxing()

        if illum <= 0.03:
            emoji = "dYO`"
        elif illum >= 0.97:
            emoji = "dYO\a"
        elif 0.45 <= illum <= 0.55:
            emoji = "dYO" if waxing is not False else "dYO-"
        elif illum < 0.25:
            emoji = "dYO'" if waxing is not False else "dYO~"
        elif illum < 0.75:
            emoji = "dYO" if waxing is not False else "dYO-"
        else:
            emoji = "dYO" if waxing is not False else "dYO-"

        return f"{emoji} - {date_str} {self.temporal_hms(timespec='milliseconds')}"

    @property
    def moon_summary(self) -> str:
        """Compact moon string: "{illum%} {angle}° {wx|wn}".

        - Illumination computed from self.moon_illum (0..1, 0..100, or 0..1000 supported)
        - Angle from self.moon_angle (degrees)
        - wx for waxing, wn for waning; New treated as waxing, Full as waning.
        """
        # Illumination normalization
        illum_raw = self.moon_illum if self.moon_illum is not None else 0
        if illum_raw > 100:
            illum = illum_raw / 1000.0
        else:
            illum = illum_raw / 100.0
        illum = max(0.0, min(1.0, float(illum)))
        illum_pct = int(round(illum * 100))
        # Angle
        ang = self.moon_angle if self.moon_angle is not None else 0.0
        ang_i = int(round(float(ang)))

        # Waxing vs Waning
        p = (getattr(self, "moon_phase", "") or "").strip().lower()
        code = "?"
        if p:
            if p.startswith("wax") or "first quarter" in p or p.startswith("new"):
                code = "wx"
            elif p.startswith("wan") or "last quarter" in p or p.startswith("full"):
                code = "wn"
        return f"{illum_pct}% {ang_i}° {code}"

    def lunar_temporal_hms(self, timespec: str = "seconds") -> str:
        """Return lunar temporal time as HH:MM:SS within 12 up or 12 down hours.

        Uses Aether-backed Moon up/down crossing times. Prefixes with 'L↑' when
        the Moon is up, or 'L↓' when down.
        """
        try:
            from aether_thresher import lunar_temporal
            tz = _get_pytz_timezone(self.zone)
            info = lunar_temporal(self.moment, tz, str(self.coords))
            if not info or info.get('hour_length_seconds') in (None, 0):
                return "L? 00:00:00"
            h = int(info['hour_index'] or 0)
            m = int(info['minute_index'] or 0)
            s = int(info['second_index'] or 0)
            if h < 1: h = 1
            if m < 1: m = 1
            if s < 1: s = 1
            # Choose arrow or ASCII fallback based on output encoding
            try:
                import sys as _sys
                enc = (_sys.stdout.encoding or 'utf-8')
                '↑'.encode(enc)
                up_mark, down_mark = 'L↑', 'L↓'
            except Exception:
                up_mark, down_mark = 'Lu', 'Ld'
            mark = up_mark if info.get('is_up') else down_mark
            if timespec in ("microseconds","us"):
                return f"{mark} {h:02d}:{m:02d}:{s:02d}.000000"
            if timespec in ("milliseconds","ms"):
                return f"{mark} {h:02d}:{m:02d}:{s:02d}.000"
            return f"{mark} {h:02d}:{m:02d}:{s:02d}"
        except Exception:
            return "L? 00:00:00"

    def planetary_temporal_hms(self, body: str, timespec: str = "seconds") -> str:
        """Return temporal time for a planet-like body (Sun, Moon, Mercury..Saturn).

        Splits current up/down interval into 12 hours and returns HH:MM:SS
        with a leading code+arrow mark (encoding-aware). Codes: Su, L, Me, Ve,
        Ma, Ju, Sa; arrows ↑/↓ or 'u/d' fallback.
        """
        try:
            tz = _get_pytz_timezone(self.zone)
            info = _planetary_temporal(self.moment, tz, str(self.coords), body)
            if not info or not info.get('hour_length_seconds'):
                return f"{body[:2].title()}? 00:00:00"
            try:
                import sys as _sys
                enc = (_sys.stdout.encoding or 'utf-8')
                '↑'.encode(enc)
                up_arrow, down_arrow = '↑', '↓'
            except Exception:
                up_arrow, down_arrow = 'u', 'd'
            code_map = {
                'sun': 'Su', 'moon': 'L', 'mercury': 'Me', 'venus': 'Ve',
                'mars': 'Ma', 'jupiter': 'Ju', 'saturn': 'Sa'
            }
            prefix = code_map.get(body.lower(), body[:2].title())
            mark = f"{prefix}{up_arrow if info.get('is_up') else down_arrow}"
            h = int(info['hour_index'] or 0); m = int(info['minute_index'] or 0); s = int(info['second_index'] or 0)
            if h < 1: h = 1
            if m < 1: m = 1
            if s < 1: s = 1
            if timespec in ("microseconds","us"):
                return f"{mark} {h:02d}:{m:02d}:{s:02d}.000000"
            if timespec in ("milliseconds","ms"):
                return f"{mark} {h:02d}:{m:02d}:{s:02d}.000"
            return f"{mark} {h:02d}:{m:02d}:{s:02d}"
        except Exception:
            return f"{body[:2].title()}? 00:00:00"

    # -------- Serialization --------
    def isoformat(self, timespec: Optional[str] = "microseconds") -> str:
        """
        Return a stable, round-trippable string for this MoonTime.
        Format: "mt:{dt_iso};zone=<TZID>;coords=<lat,lon>"
        """
        if timespec is None:
            dt_iso = self.moment.isoformat()
        else:
            dt_iso = self.moment.isoformat(timespec=timespec)
        try:
            tzid = (
                getattr(self.moment.tzinfo, "zone", None)
                or self.moment.tzinfo.tzname(self.moment)
                or str(self.moment.tzinfo)
            )
        except Exception:
            tzid = str(self.moment.tzinfo)
        coords = self.coords if isinstance(self.coords, str) else str(self.coords)
        return f"mt:{dt_iso};zone={tzid};coords={coords}"

    def strftime(self, fmt: str, use_24h: bool = True) -> str:
        out = fmt.replace("%%", "__PCT__")
        replacements = [
            ("%Y", f"{(self.lunar_year if self.lunar_year is not None else 0):04d}"),
            ("%m", f"{(self.lunar_month_index if self.lunar_month_index is not None else 0):02d}"),
            ("%d", f"{(self.lunar_day if self.lunar_day is not None else 0):02d}"),
            ("%H", f"{(self.hour_24 if use_24h else self.hour_12):02d}"),
            ("%I", f"{self.hour_12:02d}"),
            ("%M", f"{self.minute_60:02d}"),
            ("%S", f"{self.second_60:02d}"),
            ("%L", f"{self.temporal_millisecond:03d}"),
            ("%f", f"{self.temporal_microsecond:06d}"),
            ("%i", f"{self.moon_illum if self.moon_illum is not None else 0:03d}"),
            ("%a", f"{self.moon_angle if self.moon_angle is not None else 0:03.0f}"),
        ]
        for k, v in replacements:
            out = out.replace(k, v)
        return out.replace("__PCT__", "%")

    def isoformat5(self, timespec: Optional[str] = "microseconds") -> str:
        dt = self.moment
        # Build fraction
        frac = ""
        if timespec is None:
            if dt.microsecond:
                frac = f".{dt.microsecond:06d}"
        elif timespec in ("microseconds", "us"):
            frac = f".{dt.microsecond:06d}"
        elif timespec in ("milliseconds", "ms"):
            frac = f".{dt.microsecond // 1000:03d}"
        elif timespec == "seconds":
            frac = ""
        else:
            raise ValueError("timespec must be one of None, 'seconds', 'milliseconds', 'microseconds'")

        z = dt.strftime("%z") or ""
        if z and len(z) == 5:
            z = z[:3] + ":" + z[3:]
        tzid = getattr(dt.tzinfo, "zone", None) or dt.tzinfo.tzname(dt) or str(dt.tzinfo)
        coords = self.coords if isinstance(self.coords, str) else str(self.coords)

        dt_iso5 = (
            f"{dt.year:05d}-{dt.month:02d}-{dt.day:02d}T{dt.hour:02d}:{dt.minute:02d}:{dt.second:02d}{frac}{z}"
        )
        return f"mt:{dt_iso5};zone={tzid};coords={coords}"

    def temporal_iso(self, timespec: str = "microseconds") -> str:
        if self.lunar_year is None or self.lunar_month_index is None or self.lunar_day is None:
            return "????-??-??T??:??:??"
        return f"{self.lunar_year:04d}-{self.lunar_month_index:02d}-{self.lunar_day:02d}T{self.temporal_hms(timespec=timespec)}"

    @staticmethod
    def fromisoformat(s: str, default_zone=None, default_coords=None) -> "MoonTime":
        s = s.strip()
        if s.startswith("mt:"):
            body = s[3:]
            parts = body.split(";")
            dt_part = parts[0]
            zone_part = None
            coords_part = None
            for p in parts[1:]:
                if p.startswith("zone="):
                    zone_part = p[5:]
                elif p.startswith("coords="):
                    coords_part = p[7:]
            dt = parser.parse(dt_part)
            z = _get_pytz_timezone(zone_part) if zone_part else (default_zone or ZONE)
            c = coords_part if coords_part else (default_coords or COORDS)
            return MoonTime.from_datetime(dt, zone=z, coords=c)
        else:
            dt = parser.parse(s)
            z = default_zone or ZONE
            c = default_coords or COORDS
            return MoonTime.from_datetime(dt, zone=z, coords=c)

    # -------- Temporal arithmetic --------
    def add_temporal_seconds(self, t_seconds: float) -> "MoonTime":
        if not isinstance(t_seconds, (int, float)):
            raise TypeError("t_seconds must be a number")
        if abs(t_seconds) < 1e-12:
            return MoonTime(self.moment, self.zone, self.coords)

        moment = self.moment
        remaining = float(t_seconds)
        while abs(remaining) > 1e-9:
            info = _planetary_day_for(moment, self.zone, self.coords)
            if not info:
                raise ValueError("Moment outside planetary-day ledger range during arithmetic")
            rate = info["hour_length_seconds"] / 3600.0
            if remaining > 0:
                real_left = (info["hour_end"] - moment).total_seconds()
                tsec_left = real_left / rate if rate > 0 else float("inf")
                if remaining <= tsec_left + 1e-9:
                    moment = moment + timedelta(seconds=remaining * rate)
                    remaining = 0.0
                else:
                    moment = info["hour_end"]
                    remaining -= tsec_left
            else:
                real_back = (moment - info["hour_start"]).total_seconds()
                tsec_back = real_back / rate if rate > 0 else float("inf")
                if -remaining <= tsec_back + 1e-9:
                    moment = moment + timedelta(seconds=remaining * rate)
                    remaining = 0.0
                else:
                    moment = info["hour_start"]
                    remaining += tsec_back

        return MoonTime(moment, self.zone, self.coords)

    def add_temporal(self, hours: float = 0, minutes: float = 0, seconds: float = 0) -> "MoonTime":
        total_tsec = float(hours) * 3600.0 + float(minutes) * 60.0 + float(seconds)
        return self.add_temporal_seconds(total_tsec)

    def temporal_seconds_to(self, other) -> float:
        if isinstance(other, MoonTime):
            target = other.moment
            zone = other.zone
            coords = other.coords
        elif isinstance(other, datetime):
            target = other
            zone = self.zone
            coords = self.coords
        else:
            raise TypeError("other must be MoonTime or datetime")

        local_tz = _get_pytz_timezone(zone if zone is not None else self.zone)
        if getattr(target, "tzinfo", None) is None:
            target = local_tz.localize(target)
        else:
            target = target.astimezone(local_tz)

        start = self.moment
        if target == start:
            return 0.0

        sign = 1.0
        if target < start:
            start, target = target, start
            sign = -1.0

        total_tsec = 0.0
        current = start
        while current < target:
            info = _planetary_day_for(current, self.zone, self.coords)
            if not info:
                raise ValueError("Moment outside planetary-day ledger range during diff")
            rate = info["hour_length_seconds"] / 3600.0
            end = min(target, info["hour_end"])  # do not cross this hour
            delta_real = (end - current).total_seconds()
            total_tsec += delta_real / rate if rate > 0 else 0.0
            current = end

        return sign * total_tsec

    # -------- Interop with datetime/timedelta --------
    @property
    def tzinfo(self):
        return self.moment.tzinfo

    def to_datetime(self) -> datetime:
        return self.moment

    def __add__(self, delta):
        if isinstance(delta, timedelta):
            return MoonTime(self.moment + delta, self.zone, self.coords)
        return NotImplemented

    def __sub__(self, other):
        if isinstance(other, timedelta):
            return MoonTime(self.moment - other, self.zone, self.coords)
        if isinstance(other, MoonTime):
            return self.moment - other.moment
        return NotImplemented

    def __repr__(self) -> str:
        return f"{self.lunar_date_str}"


def moontime(moment: Optional[datetime] = None, zone=None, coords=None) -> MoonTime:
    """Convenience function returning a MoonTime for the given moment."""
    return MoonTime(moment=moment, zone=zone, coords=coords)
