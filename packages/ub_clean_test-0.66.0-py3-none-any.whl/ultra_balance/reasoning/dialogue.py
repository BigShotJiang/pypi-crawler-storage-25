from typing import Dict, List, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import hashlib


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


class Intent(Enum):
    GREET = "greet"           # 打招呼
    QUESTION = "question"      # 提问
    COMMAND = "command"        # 命令
    FEEDBACK = "feedback"      # 反馈
    CLARIFY = "clarify"        # 澄清
    FAREWELL = "farewell"      # 告别
    UNKNOWN = "unknown"        # 未知


@dataclass
class Turn:
    """对话轮次"""
    turn_id: int
    user_input: str
    bot_response: str
    intent: Intent
    entities: Dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Context:
    """对话上下文"""
    key: str
    value: Any
    confidence: float
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


class DialogueManager:
    """
    多轮对话模块 (0.66.0)
    能力：上下文记忆、意图识别、实体提取、多轮推理、主动澄清
    """
    
    def __init__(self, max_history: int = 20):
        self.history: List[Turn] = []           # 对话历史
        self.context: Dict[str, Context] = {}   # 上下文变量
        self.max_history = max_history
        self.current_turn = 0
        
        # 初始化意图识别模式
        self._init_intent_patterns()
        # 初始化实体模式
        self._init_entity_patterns()
    
    def _init_intent_patterns(self):
        """初始化意图识别模式"""
        self.intent_patterns = {
            Intent.GREET: ["你好", "嗨", "早上好", "下午好", "晚上好", "hello", "hi"],
            Intent.QUESTION: ["什么", "哪个", "怎么", "如何", "为什么", "哪里", "几", "多少", "？", "?"],
            Intent.COMMAND: ["做", "去", "拿", "打开", "关闭", "开始", "停止", "帮", "请"],
            Intent.FAREWELL: ["再见", "拜拜", "bye", "下次见", "告辞"],
            Intent.FEEDBACK: ["对", "不对", "是", "不是", "正确", "错误", "好的", "可以", "不行"],
        }
    
    def _init_entity_patterns(self):
        """初始化实体提取模式"""
        self.entity_patterns = {
            "time": ["今天", "明天", "昨天", "现在", "然后", "之后", "之前"],
            "place": ["这里", "那里", "家", "公司", "厨房", "客厅", "卧室"],
            "object": ["水", "饭", "门", "窗", "灯", "空调", "电视"],
            "number": ["一", "二", "三", "四", "五", "1", "2", "3", "4", "5"],
            "person": ["我", "你", "他", "她", "我们", "你们", "他们"],
        }
    
    # ========== 1. 意图识别 ==========
    def recognize_intent(self, user_input: str) -> Intent:
        """
        识别用户意图
        
        参数：
            user_input: 用户输入
            
        返回：
            意图类型
        """
        user_input_lower = user_input.lower()
        
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if pattern in user_input_lower:
                    return intent
        
        return Intent.UNKNOWN
    
    # ========== 2. 实体提取 ==========
    def extract_entities(self, user_input: str) -> Dict[str, Any]:
        """
        提取实体
        
        参数：
            user_input: 用户输入
            
        返回：
            实体字典
        """
        entities = {}
        user_input_lower = user_input.lower()
        
        for entity_type, patterns in self.entity_patterns.items():
            for pattern in patterns:
                if pattern in user_input_lower:
                    if entity_type not in entities:
                        entities[entity_type] = []
                    entities[entity_type].append(pattern)
        
        return entities
    
    # ========== 3. 上下文管理 ==========
    def update_context(self, key: str, value: Any, confidence: float = 0.8):
        """
        更新上下文
        
        参数：
            key: 上下文键
            value: 值
            confidence: 置信度
        """
        self.context[key] = Context(
            key=key,
            value=value,
            confidence=confidence
        )
    
    def get_context(self, key: str) -> Optional[Any]:
        """
        获取上下文
        
        参数：
            key: 上下文键
            
        返回：
            值（如果存在）
        """
        if key in self.context:
            return self.context[key].value
        return None
    
    def get_all_context(self) -> Dict[str, Any]:
        """获取所有上下文"""
        return {k: v.value for k, v in self.context.items()}
    
    def clear_context(self, key: str = None):
        """清除上下文"""
        if key:
            self.context.pop(key, None)
        else:
            self.context.clear()
    
    # ========== 4. 上下文推理 ==========
    def infer_from_context(self, user_input: str) -> Dict:
        """
        从上下文推理补全信息
        
        参数：
            user_input: 用户输入
            
        返回：
            {
                "has_inference": bool,
                "inferred_info": Dict,
                "explanation": str
            }
        """
        inferred = {}
        explanation = []
        
        # 处理代词指代
        if "它" in user_input or "这个" in user_input:
            last_object = self.get_context("last_object")
            if last_object:
                inferred["object"] = last_object
                explanation.append(f"“它”指代之前的“{last_object}”")
        
        # 处理省略
        if "也" in user_input:
            last_action = self.get_context("last_action")
            if last_action:
                inferred["action"] = last_action
                explanation.append(f"“也”表示执行相同动作“{last_action}”")
        
        # 处理时间关联
        if "然后" in user_input or "之后" in user_input:
            last_time = self.get_context("last_time")
            if last_time:
                inferred["next_time"] = last_time
                explanation.append(f"时间关联到之前的“{last_time}”")
        
        # 处理地点关联
        if "那里" in user_input:
            last_place = self.get_context("last_place")
            if last_place:
                inferred["place"] = last_place
                explanation.append(f"“那里”指代之前的“{last_place}”")
        
        return {
            "has_inference": len(inferred) > 0,
            "inferred_info": inferred,
            "explanation": "; ".join(explanation) if explanation else "无上下文推理"
        }
    
    # ========== 5. 生成回复 ==========
    def generate_response(self, user_input: str) -> Dict:
        """
        生成回复
        
        参数：
            user_input: 用户输入
            
        返回：
            {
                "response": str,
                "intent": Intent,
                "entities": Dict,
                "context_used": bool
            }
        """
        # 1. 识别意图
        intent = self.recognize_intent(user_input)
        
        # 2. 提取实体
        entities = self.extract_entities(user_input)
        
        # 3. 上下文推理
        inference = self.infer_from_context(user_input)
        
        # 4. 更新上下文（从当前输入）
        self._update_context_from_input(user_input, entities)
        
        # 5. 根据意图生成回复
        response = self._generate_by_intent(user_input, intent, entities, inference)
        
        # 6. 记录对话轮次
        turn = Turn(
            turn_id=self.current_turn,
            user_input=user_input,
            bot_response=response,
            intent=intent,
            entities=entities
        )
        self.history.append(turn)
        self.current_turn += 1
        
        # 保持历史长度
        if len(self.history) > self.max_history:
            self.history.pop(0)
        
        return {
            "response": response,
            "intent": intent.value,
            "entities": entities,
            "context_used": inference["has_inference"],
            "inference": inference["explanation"] if inference["has_inference"] else None
        }
    
    def _update_context_from_input(self, user_input: str, entities: Dict):
        """从输入更新上下文"""
        # 更新最后动作
        if "去" in user_input or "做" in user_input:
            self.update_context("last_action", user_input[:20])
        
        # 更新最后提及的对象
        if "object" in entities:
            self.update_context("last_object", entities["object"][0])
        
        # 更新地点
        if "place" in entities:
            self.update_context("last_place", entities["place"][0])
        
        # 更新时间
        if "time" in entities:
            self.update_context("last_time", entities["time"][0])
    
    def _generate_by_intent(self, user_input: str, intent: Intent, 
                            entities: Dict, inference: Dict) -> str:
        """根据意图生成回复"""
        
        if intent == Intent.GREET:
            return "你好！有什么我可以帮你的吗？"
        
        elif intent == Intent.QUESTION:
            return self._answer_question(user_input, entities, inference)
        
        elif intent == Intent.COMMAND:
            return self._handle_command(user_input, entities)
        
        elif intent == Intent.FAREWELL:
            return "再见！下次见。"
        
        elif intent == Intent.FEEDBACK:
            # 处理反馈
            if "对" in user_input or "是" in user_input or "好" in user_input:
                return "好的，我明白了。"
            else:
                return "抱歉，我会改进的。"
        
        else:
            # 未知意图，尝试从上下文理解
            last_response = self.get_last_response()
            if last_response:
                return f"我不太确定你的意思。刚才我说：{last_response[:30]}... 能再说清楚一点吗？"
            return "我不太明白你的意思，能再说一遍吗？"
    
    def _answer_question(self, user_input: str, entities: Dict, inference: Dict) -> str:
        """回答问题"""
        # 从上下文找答案
        if "last_object" in self.context and "什么" in user_input:
            obj = self.get_context("last_object")
            return f"刚才提到的是{obj}。"
        
        if "时间" in user_input:
            time = self.get_context("last_time")
            if time:
                return f"之前说的是{time}。"
        
        # 默认回答
        return "让我想想... 你能提供更多信息吗？"
    
    def _handle_command(self, user_input: str, entities: Dict) -> str:
        """处理命令"""
        # 如果有上下文推理的补充信息
        if "action" in self.get_all_context():
            action = self.get_context("last_action")
            if action and "也" in user_input:
                return f"好的，{action}"
        
        # 提取动作对象
        for obj in self.entity_patterns["object"]:
            if obj in user_input:
                return f"好的，正在{user_input}。"
        
        return f"收到命令：{user_input[:30]}..."
    
    # ========== 6. 多轮推理 ==========
    def multi_turn_reason(self, user_input: str, history_count: int = 3) -> Dict:
        """
        多轮推理：结合多轮历史进行推理
        
        参数：
            user_input: 当前输入
            history_count: 考虑的历史轮次数
            
        返回：
            {
                "reasoning": str,
                "referenced_turns": List[int],
                "confidence": float
            }
        """
        referenced_turns = []
        reasoning_parts = []
        
        # 获取最近的历史
        recent_history = self.history[-history_count:] if self.history else []
        
        # 检查是否引用历史
        for i, turn in enumerate(recent_history):
            if turn.user_input and any(word in user_input for word in ["刚才", "之前", "刚刚", "前面"]):
                referenced_turns.append(turn.turn_id)
                reasoning_parts.append(f"引用第{turn.turn_id+1}轮: {turn.user_input[:20]}...")
        
        # 检查代词指代历史中的实体
        if "它" in user_input or "那个" in user_input:
            for turn in reversed(recent_history):
                if turn.entities.get("object"):
                    referenced_turns.append(turn.turn_id)
                    reasoning_parts.append(f"指代第{turn.turn_id+1}轮的{ turn.entities['object'][0]}")
                    break
        
        if reasoning_parts:
            reasoning = f"多轮推理: {'; '.join(reasoning_parts)}"
            confidence = 0.7
        else:
            reasoning = "单轮推理，未引用历史"
            confidence = 0.9
        
        return {
            "reasoning": reasoning,
            "referenced_turns": referenced_turns,
            "confidence": confidence
        }
    
    # ========== 7. 主动澄清 ==========
    def need_clarification(self, user_input: str) -> Dict:
        """
        判断是否需要澄清
        
        参数：
            user_input: 用户输入
            
        返回：
            {
                "need": bool,
                "reason": str,
                "clarification_question": str
            }
        """
        # 检查信息是否不足
        if len(user_input) < 3:
            return {
                "need": True,
                "reason": "输入太短",
                "clarification_question": "能说详细一点吗？"
            }
        
        # 检查是否缺少主语或宾语
        has_subject = any(p in user_input for p in self.entity_patterns["person"])
        has_object = any(o in user_input for o in self.entity_patterns["object"])
        
        if "去" in user_input and not has_object:
            return {
                "need": True,
                "reason": "缺少目的地",
                "clarification_question": "请问要去哪里？"
            }
        
        if "拿" in user_input and not has_object:
            return {
                "need": True,
                "reason": "缺少物品",
                "clarification_question": "请问要拿什么？"
            }
        
        # 检查歧义
        ambiguous_words = ["那个", "这个", "那里", "这里"]
        for word in ambiguous_words:
            if word in user_input and not self.get_context("last_object"):
                return {
                    "need": True,
                    "reason": f"指代不明（{word}）",
                    "clarification_question": f"你说的{word}具体指什么？"
                }
        
        return {
            "need": False,
            "reason": None,
            "clarification_question": None
        }
    
    def ask_clarification(self, user_input: str) -> str:
        """
        主动提问澄清
        
        参数：
            user_input: 用户输入
            
        返回：
            澄清问题
        """
        clarification = self.need_clarification(user_input)
        if clarification["need"]:
            return clarification["clarification_question"]
        return None
    
    # ========== 8. 辅助方法 ==========
    def get_last_response(self) -> Optional[str]:
        """获取最后一轮回复"""
        if self.history:
            return self.history[-1].bot_response
        return None
    
    def get_history_summary(self) -> str:
        """获取对话历史摘要"""
        if not self.history:
            return "暂无对话历史"
        
        summary = f"共{len(self.history)}轮对话\n"
        for turn in self.history[-5:]:  # 最近5轮
            summary += f"  {turn.turn_id+1}. 用户: {turn.user_input[:20]}...\n"
            summary += f"     机器人: {turn.bot_response[:30]}...\n"
        
        return summary
    
    def get_statistics(self) -> Dict:
        """获取对话统计"""
        intent_counts = {}
        for turn in self.history:
            intent = turn.intent.value
            intent_counts[intent] = intent_counts.get(intent, 0) + 1
        
        return {
            "total_turns": len(self.history),
            "intent_distribution": intent_counts,
            "context_variables": len(self.context),
            "context_keys": list(self.context.keys())
        }