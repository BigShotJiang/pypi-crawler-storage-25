# PDF2HTML Engine 项目文档

本项目是一个基于 Python 的 PDF 转 HTML 工具，专注于 **精确布局还原**、**复杂表格提取** 以及 **跨页表格无缝合并**。

---

## 1. 核心架构与实现

### 1.1 模块职责
- **`pdf2html_engine/pdf_loader.py`**: 负责 PDF 加载与结构修复。
- **`pdf2html_engine/layout_engine.py`**: 视觉布局分析，处理文本行聚类与样式推断。
- **`pdf2html_engine/table_extractor.py`**: 基于几何坐标的表格提取。
- **`pdf2html_engine/html_renderer.py`**: 基于 Jinja2 的 HTML 渲染。
- **`pdf2html_engine/converter.py`**: 转换流程编排。
- **`pdf2html_engine/license.py`**: 授权校验模块，处理密钥算法与有效期校验。
- **`pdf2html_engine/cli.py`**: 命令行入口。

### 1.2 关键技术
- **双阶段扫描 (Two-Pass Scanning)**: 统一全文档表格网格。
- **视觉行合并**: 基于 Y 轴聚类的文本还原。
- **智能跨页合并**: 自动识别并合并被分页符切断的表格。
- **HMAC 授权签名**: 基于 HMAC-SHA256 的授权校验机制，支持机器绑定与有效期限制。

---

## 2. 授权管理系统 (License System)

本项目集成了私有授权校验机制，以确保代码仅在受控环境下运行。

### 2.1 密钥生成
使用根目录下的 `generate_license.py`（该文件已忽略，仅供管理者使用）生成密钥：

```bash
# 生成默认一年的密钥
python3 generate_license.py -c "项目A"

# 生成指定天数的密钥
python3 generate_license.py -c "测试项目" -d 30

# 生成永久有效的密钥
python3 generate_license.py -c "内部服务器" -d 0
```

### 2.2 运行环境配置
调用方需要通过以下两种方式之一提供有效的 License：

1. **环境变量 (推荐)**:
   设置系统环境变量 `PDF2HTML_LICENSE_KEY`。
2. **显式传参**:
   在调用 `parse_pdf` 或初始化 `PDFConverter` 时传入 `license_key` 参数。

### 2.3 安全加固建议
由于 Python 脚本易于反编译，建议在正式分发前使用 **Cython** 将 `pdf2html_engine/license.py` 编译为二进制 `.so` 或 `.pyd` 文件，以隐藏签名密钥。

---

## 3. 开发指南

### 2.1 环境准备
建议项目使用 Python 3.8+。

```bash
# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境 (MacOS/Linux)
source venv/bin/activate

# 激活虚拟环境 (Windows)
# venv\Scripts\activate
```

### 2.2 安装依赖
```bash
# 升级 pip
pip install --upgrade pip

# 安装开发环境（包含所有依赖并以可编辑模式安装项目）
pip install -e .
```

### 2.3 运行开发版本
由于在 `pyproject.toml` 中配置了 `project.scripts`，你可以直接在命令行运行：
```bash
pdf2html --help
```

---

## 3. 打包与发布流程

本项目采用标准的 PEP 517 构建流程。

### 3.1 准备构建工具
确保安装了最新版本的 `build` 和 `twine`：
```bash
pip install --upgrade build twine
```

### 3.2 打包项目
执行以下命令生成分发包（Source Distribution 和 Wheel）：
```bash
# 清理旧的构建产物（可选）
rm -rf dist/ build/ *.egg-info

# 执行构建
python3 -m build
```
构建完成后，`dist/` 目录下会出现 `.tar.gz` 和 `.whl` 文件。

### 3.3 发布到 PyPI
发布前建议先检查包的完整性：
```bash
twine check dist/*
```

**发布到测试服务器 (TestPyPI):**
```bash
twine upload --repository testpypi dist/*
```

**正式发布到 PyPI:**
```bash
twine upload dist/*
```
*注意：发布需要 PyPI 账号及相应的 API Token。*

---

## 4. 版本维护指南

### 4.1 更新版本号
版本号维护在 `pyproject.toml` 的 `[project].version` 字段中。

### 4.2 开发与发布检查清单
1. **测试**: 运行测试套件（如 `pytest`），确保功能正常。
2. **文档**: 如果有 API 变更，同步更新 `README.md`。
3. **版本**: 在 `pyproject.toml` 中增加版本号。
4. **Git**: 提交更改并打上版本标签：
   ```bash
   git add pyproject.toml
   git commit -m "chore: bump version to 0.1.2"
   git tag v0.1.2
   git push origin main --tags
   ```
5. **打包发布**: 按照上述“打包与发布流程”操作。
