import fitz
import re

class LayoutEngine:
    @staticmethod
    def _is_page_number(text):
        """Identifies common page number patterns."""
        if not text: return False
        # Remove non-printable characters and extra whitespace
        text = "".join(c for c in text if c.isprintable()).strip()
        if not text: return False
        
        # Patterns like: "1", "1 / 10", "Page 1", "第 1 页", "- 1 -", "1 of 10", "(1)", "32."
        # Use a limit for single numbers to avoid filtering large values (like 1100 in tables)
        if text.isdigit() and int(text) > 2000:
            return False

        # Identify common background tracking codes (very long digits)
        if text.isdigit() and len(text) > 15:
            return True

        patterns = [
            r"^[\(\-\–\—\s]*\d+[\)\-\–\—\s]*$",
            r"^\d+[\.\s]*$",
            r"^\d+\s*/\s*\d+$",
            r"^\d+\s+of\s+\d+$",
            r"^Page\s*\d+$",
            r"^第\s*\d+\s*页$",
            r"^第\s*\d+\s*页\s*[，,/-]?\s*共\s*\d+\s*页$"
        ]
        for p in patterns:
            if re.match(p, text, re.IGNORECASE):
                return True
        return False

    @staticmethod
    def _is_not_black(c):
        """Checks if a color is clearly not black/gray (e.g., red seals)."""
        if c is None: return False
        if isinstance(c, int):
            # Convert integer color to RGB tuple (0-1)
            r = ((c >> 16) & 255) / 255.0
            g = ((c >> 8) & 255) / 255.0
            b = (c & 255) / 255.0
            c = (r, g, b)
            
        if len(c) == 3: # RGB
            # If it has significant color saturation or is too light
            is_colored = (max(c) - min(c)) > 0.2
            is_light = all(v > 0.8 for v in c)
            return is_colored or is_light
        if len(c) == 1: # Gray
            return c[0] > 0.8
        if len(c) == 4: # CMYK
            # If any of C, M, Y components are high
            return any(v > 0.2 for v in c[:3])
        return False

    @staticmethod
    def extract_layout(fitz_page, table_bboxes):
        """
        Extracts layout by merging text and drawings into stable visual lines with dynamic font sizes.
        Uses padding-left for precise horizontal positioning.
        """
        page_width = fitz_page.rect.width
        page_height = fitz_page.rect.height
        header_threshold = page_height * 0.05
        footer_threshold = page_height * 0.95
        all_fragments = []

        # 1. Collect text spans with detailed styles using rawdict for character-level precision
        text_dict = fitz_page.get_text("rawdict", flags=fitz.TEXT_PRESERVE_WHITESPACE)
        for b in text_dict["blocks"]:
            if b["type"] != 0: continue
            if LayoutEngine._is_inside_table(b["bbox"], table_bboxes): continue

            # Calculate max font size in the block to distinguish titles from headers/footers
            max_size = 0
            for line in b["lines"]:
                for span in line["spans"]:
                    if span["size"] > max_size:
                        max_size = span["size"]
            
            # Skip blocks that are entirely in the header/footer area, BUT preserve large titles (size >= 12)
            if b["bbox"][3] < header_threshold or b["bbox"][1] > footer_threshold:
                if max_size < 12:
                    continue
                
            # If a block is in a wider header/footer margin, check if its content is just a page number
            if b["bbox"][1] < page_height * 0.15 or b["bbox"][3] > page_height * 0.85:
                block_text = "".join(char["c"] for line in b["lines"] for span in line["spans"] for char in span["chars"]).strip()
                if LayoutEngine._is_page_number(block_text):
                    continue

            for line in b["lines"]:
                for span in line["spans"]:
                    if not span["chars"]: continue
                    
                    # 过滤掉非黑色/灰色的文本（例如印章中的数字、彩色水印）
                    # 同时也过滤掉纯白色的不可见文本（常用于内部编码或防伪）
                    text_color = span.get("color")
                    if LayoutEngine._is_not_black(text_color):
                        continue
                    
                    # 检查是否为白色 (RGB 16777215 或 (1,1,1))
                    is_white_text = False
                    if isinstance(text_color, int):
                        if text_color >= 0xFFFFFF: is_white_text = True
                    elif isinstance(text_color, (list, tuple)):
                        if len(text_color) == 3 and all(v > 0.95 for v in text_color): is_white_text = True
                        if len(text_color) == 1 and text_color[0] > 0.95: is_white_text = True
                    
                    if is_white_text:
                        continue

                    font_name = span["font"].lower()
                    is_bold = bool(
                        (span["flags"] & 2**4) or
                        "bold" in font_name or
                        "semibold" in font_name or
                        "medium" in font_name or
                        "heavy" in font_name or
                        "black" in font_name or
                        "simhei" in font_name or
                        "fzhei" in font_name or
                        "黑体" in font_name or
                        "w6" in font_name or
                        "w7" in font_name or
                        "w8" in font_name or
                        "w9" in font_name
                    )                    
                    for char in span["chars"]:
                        c = char["c"]
                        if not c.strip():
                            continue
                        c_bbox = char["bbox"]
                        all_fragments.append({
                            "x0": c_bbox[0], "y0": c_bbox[1], "x1": c_bbox[2], "y1": c_bbox[3],
                            "text": c,
                            "size": span["size"], "bold": is_bold, "is_drawing": False
                        })

        # 2. Collect drawings (underscores)
        drawings = []
        for p in fitz_page.get_drawings():
            # 过滤不可见线条或极细线条
            d_type = p.get("type", "")
            if d_type == "n": continue # 裁剪路径
            
            # 忽略极细线条
            p_width = p.get("width")
            if p_width is not None and p_width < 0.1:
                continue

            def is_white(c):
                if c is None: return True
                if not c: return True
                if len(c) == 4: # CMYK: 0,0,0,0 is white
                    return all(v < 0.05 for v in c)
                return all(v >= 0.95 for v in c) # RGB/Gray: 1 is white

            def is_transparent(o):
                return o is not None and o < 0.05

            # 只有当对应的颜色和透明度都不可见时才跳过
            # 同时过滤掉彩色线条（如红印章），因为下划线通常是黑色的
            color_s = p.get("color")
            color_f = p.get("fill")
            
            invisible_s = is_white(color_s) or is_transparent(p.get("stroke_opacity")) or LayoutEngine._is_not_black(color_s)
            invisible_f = is_white(color_f) or is_transparent(p.get("fill_opacity")) or LayoutEngine._is_not_black(color_f)

            if d_type == "s" and invisible_s: continue
            if d_type == "f" and invisible_f: continue
            if d_type == "fs" and invisible_s and invisible_f: continue

            # Only consider paths that are purely horizontal segments (typical for underlines/placeholders)
            # This avoids mistaking vector-drawn characters or complex shapes as underlines.
            is_pure_horizontal = True
            for item in p["items"]:
                if item[0] == "l":
                    if abs(item[2].y - item[1].y) > 2:
                        is_pure_horizontal = False; break
                elif item[0] == "re":
                    if item[1].height > 3:
                        is_pure_horizontal = False; break
                elif item[0] in ["c", "q"]: # curves
                    is_pure_horizontal = False; break
            
            if not is_pure_horizontal: continue

            for item in p["items"]:
                r = None
                if item[0] == "l":
                    p0, p1 = item[1], item[2]
                    # Check if it's a horizontal line
                    if abs(p1.y - p0.y) < 3 and abs(p1.x - p0.x) > 5:
                        r = fitz.Rect(min(p0.x, p1.x), p0.y - 1, max(p0.x, p1.x), p0.y + 1)
                elif item[0] == "re":
                    # Check if it's a thin rectangle (horizontal line)
                    if item[1].height < 3 and item[1].width > 5:
                        r = item[1]
                
                if r and not LayoutEngine._is_inside_table(r, table_bboxes):
                    # Skip drawings in header/footer area
                    if r.y1 < header_threshold or r.y0 > footer_threshold:
                        continue
                    drawings.append(r)

        # 2.1 Associate drawings with text to detect underlines
        for f in all_fragments:
            f["underlined"] = False
            for r in drawings:
                # Vertical check: drawing is near the bottom of the text
                # Horizontal check: significant overlap
                if abs(r.y0 - f["y1"]) < 4:
                    overlap_x0 = max(f["x0"], r.x0)
                    overlap_x1 = min(f["x1"], r.x1)
                    # For single characters, if overlap is > 40% of its width
                    if overlap_x1 > overlap_x0 and (overlap_x1 - overlap_x0) > (f["x1"] - f["x0"]) * 0.4:
                        f["underlined"] = True
                        break

        # 2.2 Add remaining drawing parts as underscore placeholders
        for r in drawings:
            # Find all text fragments that this drawing underlines
            overlapping_text_ranges = []
            for f in all_fragments:
                if abs(r.y0 - f["y1"]) < 4 or (f["y0"] < r.y0 < f["y1"] + 2):
                    overlap_x0 = max(f["x0"], r.x0)
                    overlap_x1 = min(f["x1"], r.x1)
                    if overlap_x1 > overlap_x0:
                        overlapping_text_ranges.append((overlap_x0, overlap_x1))
            
            # If no significant overlap, add as underscores (avoid full-page decorative lines)
            if not overlapping_text_ranges:
                # 检查同一行是否有文本，如果没有且线很长，可能是装饰线或边框，直接忽略
                text_on_same_line = False
                for f in all_fragments:
                    if f.get("is_drawing"): continue
                    if abs((f["y0"] + f["y1"])/2 - (r.y0 + r.y1)/2) < 12:
                        text_on_same_line = True
                        break
                
                if not text_on_same_line and r.width > page_width * 0.5:
                    continue

                if r.width < page_width * 0.9: 
                    width_chars = max(1, int(r.width / 6))
                    all_fragments.append({
                        "x0": r.x0, "y0": r.y0, "x1": r.x1, "y1": r.y1,
                        "text": "_" * width_chars, "size": 10.5, "bold": False, "is_drawing": True
                    })
            else:
                # If there is overlap, we only add underscores for the "trailing" part 
                # or parts that don't cover text.
                overlapping_text_ranges.sort()
                current_x = r.x0
                for tx0, tx1 in overlapping_text_ranges:
                    if tx0 > current_x + 5:
                        # Gap before text
                        width_chars = max(1, int((tx0 - current_x) / 6))
                        all_fragments.append({
                            "x0": current_x, "y0": r.y0, "x1": tx0, "y1": r.y1,
                            "text": "_" * width_chars, "size": 10.5, "bold": False, "is_drawing": True
                        })
                    current_x = max(current_x, tx1)
                
                if r.x1 > current_x + 5:
                    # Trailing line
                    width_chars = max(1, int((r.x1 - current_x) / 6))
                    all_fragments.append({
                        "x0": current_x, "y0": r.y0, "x1": r.x1, "y1": r.y1,
                        "text": "_" * width_chars, "size": 10.5, "bold": False, "is_drawing": True
                    })

        if not all_fragments: return []

        # 3. Group fragments into lines
        all_fragments.sort(key=lambda s: ((s["y0"] + s["y1"])/2, s["x0"]))
        lines = []
        if all_fragments:
            current_line = [all_fragments[0]]
            for i in range(1, len(all_fragments)):
                prev = all_fragments[i-1]
                curr = all_fragments[i]
                prev_mid = (prev["y0"] + prev["y1"]) / 2
                curr_mid = (curr["y0"] + curr["y1"]) / 2
                # 动态阈值：取碎片高度的 60% 与 8px 的较大值，以容纳大字号标题下的下划线
                threshold = max(8, max(prev["y1"]-prev["y0"], curr["y1"]-curr["y0"]) * 0.6)
                if abs(curr_mid - prev_mid) < threshold:
                    current_line.append(curr)
                else:
                    lines.append(current_line)
                    current_line = [curr]
            lines.append(current_line)

        # 4. Convert lines to HTML
        elements = []
        prev_line_y1 = None
        prev_is_heading = False
        
        # --- 优化：计算页面基础左边距 (base_x0) ---
        x0_coords = []
        for line in lines:
            line_text = "".join(s["text"] for s in line).strip()
            if len(line_text) < 4: continue
            lx0 = min(s["x0"] for s in line)
            lx1 = max(s["x1"] for s in line)
            l_width = lx1 - lx0
            # 排除居中行和过短行
            l_margin = lx0
            r_margin = page_width - lx1
            if not (abs(l_margin - r_margin) < 15 and l_width < page_width * 0.65):
                x0_coords.append(lx0)
        
        # 取出现频率最高的 x0 附近的值，或者简单取最小值（过滤掉极少数悬挂缩进）
        base_x0 = 0
        if x0_coords:
            x0_coords.sort()
            # 取 10% 分位数处的 x0，避免被个别悬挂缩进干扰
            base_x0 = x0_coords[len(x0_coords) // 10]
            if base_x0 < 10: base_x0 = 0
            
            # 防止在没有正常正文的页面（如只有落款、签名的页面或只有缩进段落），base_x0 错误地取到靠右的坐标，
            # 导致所有元素失去相对缩进。最大限制为标准边距（约12%）。
            if base_x0 > page_width * 0.12:
                base_x0 = page_width * 0.12

        for i, line in enumerate(lines):
            line.sort(key=lambda s: s["x0"])
            
            # 分析整行属性
            max_size = max(s["size"] for s in line)
            line_text_plain = "".join(s["text"] for s in line).strip()
            line_x0 = line[0]["x0"]
            line_y0 = line[0]["y0"]
            line_width = line[-1]["x1"] - line[0]["x0"]
            
            # 计算加粗比例 (排除下划线等绘图元素的影响)
            text_only_fragments = [s for s in line if s["text"].strip() and not s.get("is_drawing", False)]
            bold_fragments = [s for s in text_only_fragments if s["bold"]]
            is_mostly_bold = len(text_only_fragments) > 0 and (len(bold_fragments) / len(text_only_fragments)) >= 0.8
            
            # 对齐判断
            left_margin = line_x0
            right_margin = page_width - line[-1]["x1"]

            # 定义标题匹配模式 (提前定义以供对齐判断使用)
            list_like_pattern = r'^(([A-Z]?\d+[.．\xb7])+\d*|[\d一二三四五六七八九十百]+[、.．\xb7]|[A-Z][.．\xb7]|\([\d一二三四五六七八九十百]+\)|（[\d一二三四五六七八九十百]+）)\s*'
            strong_heading_pattern_for_center = r'^(第[一二三四五六七八九十百]+[卷章节部分]|[一二三四五六七八九十百]+[、]|（[一二三四五六七八九十百]+）|\([一二三四五六七八九十百]+\))\s*'

            # 居中判断要求：左右边距相近，且文本不能太宽（不超过页面宽度的 85%），防止将两端对齐的长段落误判为居中标题
            # 优化：增加容忍度（从 15pt 提升到页宽的 8% 或 25pt 中的较大值），解决因排版微小偏差导致的标题无法居中问题
            # 最小改动：如果是强标题模式，进一步放宽容忍度到页宽的 15% 或 80pt，确保视觉居中的标题不失效
            tolerance_limit = max(25, page_width * 0.08)
            if re.match(strong_heading_pattern_for_center, line_text_plain):
                tolerance_limit = max(80, page_width * 0.15)
            
            is_centered = abs(left_margin - right_margin) < tolerance_limit and line_width < page_width * (0.85 if (is_mostly_bold or max_size >= 14) else 0.65)

            # 【优化】：排除因巧合导致最后一行居中的情况（如果左边缘与上一长行对齐，则是段落延续）
            if is_centered and i > 0:
                prev_line_for_align = lines[i-1]
                prev_lm = prev_line_for_align[0]["x0"]
                prev_lw = prev_line_for_align[-1]["x1"] - prev_line_for_align[0]["x0"]
                if abs(left_margin - prev_lm) < 15 and prev_lw > page_width * 0.6:
                    is_centered = False

            if is_centered and re.match(list_like_pattern, line_text_plain):
                # 如果是强语义标题（如“一、”），即使没加粗也允许保持居中（只要不超长）
                if re.match(strong_heading_pattern_for_center, line_text_plain):
                    if line_width > page_width * 0.65:
                        is_centered = False
                # 普通列表序号，必须是大字号、加粗，或者是较短的纯标题（如“3.承诺函”）才能居中
                elif not (is_mostly_bold or max_size >= 14 or line_width < page_width * 0.4) or line_width > page_width * 0.5:
                    is_centered = False

            # 【优化】：识别落款/表单行
            is_signature_line = ("_" in line_text_plain or re.search(r'(?:人|方|单位|机构|日期|时间|地点|地址|电话|手机|传真|邮箱|代码|号码|证号)[：:]', line_text_plain) or re.search(r'盖章|签字|年.*月.*日', line_text_plain) or re.match(r'^.{1,12}[：:]', line_text_plain))
            # 【修正】：如果同时匹配强标题模式，且不包含冒号或下划线，则优先视为标题而非落款（防止标题中含日期被误判）
            if is_signature_line and re.match(strong_heading_pattern_for_center, line_text_plain) and not re.search(r'[：:_]', line_text_plain):
                is_signature_line = False

            if is_signature_line and is_centered:
                is_centered = False # 强制取消居中，改用 margin-left 以维持块级左对齐形态

            # 决定标签类型 (计分制精准识别标题)
            score = 0
            # 优化：加粗分值受长度影响，防止长加粗行被误判为标题
            if is_mostly_bold: score += 2 if len(line_text_plain) < 25 else 1
            if max_size >= 14: score += 2
            elif max_size >= 12: score += 1
            
            # 为了兼容老逻辑中的 heading_pattern 变量引用
            heading_pattern = r'^(第[一二三四五六七八九十百]+[卷章节部分]|([A-Z]?\d+[.．\xb7])+\d*|[\d一二三四五六七八九十百]+[、.．\xb7\s]|[A-Z][.．\xb7]|\([\d一二三四五六七八九十百]+\)|（[\d一二三四五六七八九十百]+）)\s*'
            
            # 区分强结构标题与普通列表序号
            # 移除阿拉伯数字加顿号（如 3、），阿拉伯数字括号 (1) 和 （1） 从强标题中，防止正文普通列表项污染大纲
            strong_heading_pattern = r'^(第[一二三四五六七八九十百]+[卷章节部分]|[一二三四五六七八九十百]+[、]|（[一二三四五六七八九十百]+）|\([一二三四五六七八九十百]+\))\s*'
            # 将 3、, (1), （1） 归类为普通列表模式
            list_pattern = r'^(([A-Z]?\d+[.．\xb7])+\d*|\d+[、]|[A-Z][.．\xb7]|\(\d+\)|（\d+）)\s*'
            
            is_strong_heading = False
            if re.match(strong_heading_pattern, line_text_plain):
                # 优化：模式分值受长度和字号双重约束
                if len(line_text_plain) <= 25 or max_size >= 14:
                    score += 1
                
                # 特例提权：不加粗的12pt“一、投标函”类型，只要是单行强标题，补1分使其及格
                if max_size >= 12 and not line_text_plain.endswith(('。', '.', '；', ';', '：', ':')) and len(line_text_plain) <= 20:
                    score += 1
                
                if len(line_text_plain) <= 30:
                    # 升级为强标题：必须是大字号，且满足加粗
                    if max_size >= 14 and is_mostly_bold:
                        score = 5
                        is_strong_heading = True
            elif re.match(list_pattern, line_text_plain):
                # 普通列表模式仅在短行时加分
                if len(line_text_plain) <= 20:
                    score += 1
                
                is_short_no_punct = len(line_text_plain) <= 20 and not line_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':'))
                if is_short_no_punct:
                    if max_size >= 14:
                        score = 5
                        is_strong_heading = True
            elif re.match(heading_pattern, line_text_plain):
                if len(line_text_plain) <= 25:
                    score += 1
                    
            # 附件/附录提权：如果是独立成行的附件标题且字号>=12，直接给高分保送
            if re.match(r'^(附件|附表|附录)[一二三四五六七八九十\d]+', line_text_plain) and max_size >= 12 and not line_text_plain.endswith(('。', '.', '；', ';', '：', ':')):
                score += 3
                is_strong_heading = True
            
            # 排除项：以标点符号结尾的通常是段落强调而非标题
            if line_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':')):
                # 分号和句号永远扣分（即使是强标题）；冒号等仅在非强标题时扣分
                if line_text_plain.endswith(('。', '.', '；', ';')) or not is_strong_heading:
                    score -= 3
            
            # 排除项：包含键值对特征的文本（如 "项目编号: xxx", "日期: xxx"）通常是封面元数据而非标题
            if re.search(r'^.{2,10}[：:]', line_text_plain) and not is_strong_heading:
                score -= 4
            
            # 移除之前基于居中的排除项，保持规则的一致性

            # 段落连续性检测（严谨排除换行长文本，同时检查上下文）
            is_part_of_paragraph = False
            is_semantic_continuation = False
            should_merge_with_prev = False
            
            # 定义表单/字段特征模式
            field_pattern = r'^.{1,12}[：:].*$'
            date_pattern = r'^\s*__*年__*月__*日\s*$|^\d{2,4}年\d{1,2}月\d{1,2}日$'
            is_current_field_or_date = bool(re.match(field_pattern, line_text_plain) or re.match(date_pattern, line_text_plain))
            # 优化：如果是长行且没有结束标点，不将其视为独立字段，允许段落合并
            if is_current_field_or_date and len(line_text_plain) > 30 and not line_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':', ')', '）', '_')):
                is_current_field_or_date = False

            # 1. 检查下一行 (样式一致性)
            if i < len(lines) - 1:
                next_line = lines[i+1]
                next_y0 = min(s["y0"] for s in next_line)
                next_max_size = max(s["size"] for s in next_line)
                line_y1 = max(s["y1"] for s in line)
                dist_next = next_y0 - line_y1
                next_texts = [s for s in next_line if s["text"].strip() and not s.get("is_drawing", False)]
                next_bold = len(next_texts) > 0 and (len([s for s in next_texts if s["bold"]]) / len(next_texts)) >= 0.8
                
                # 如果当前行是明确的强标题，坚决不将其视为段落中间行
                if not re.match(strong_heading_pattern, line_text_plain):
                    # 如果当前行是字段或日期，或者以括号/下划线结尾，则不视为段落中间行
                    # 优化：如果是居中的标题，也不应视为段落中间行，防止其丢失居中样式
                    if dist_next < max_size * 1.8 and abs(next_max_size - max_size) < 1.5 and next_bold == is_mostly_bold:
                        if not line_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':', ')', '）', '_')):
                            if not is_current_field_or_date and not is_centered:
                                is_part_of_paragraph = True

            # 2. 检查上一行 (样式一致性 或 语义延续性)
            if i > 0:
                prev_line = lines[i-1]
                prev_y1 = max(s["y1"] for s in prev_line)
                prev_max_size = max(s["size"] for s in prev_line)
                prev_line_x0 = prev_line[0]["x0"]
                dist_prev = line_y0 - prev_y1
                prev_texts = [s for s in prev_line if s["text"].strip() and not s.get("is_drawing", False)]
                prev_bold = len(prev_texts) > 0 and (len([s for s in prev_texts if s["bold"]]) / len(prev_texts)) >= 0.8
                prev_text_plain = "".join(s["text"] for s in prev_line).strip()
                
                # 上一行对齐判断，用于辅助断开合并
                prev_line_width = prev_line[-1]["x1"] - prev_line[0]["x0"]
                prev_left_margin = prev_line_x0
                prev_right_margin = page_width - prev_line[-1]["x1"]
                is_prev_centered = abs(prev_left_margin - prev_right_margin) < 15 and prev_line_width < page_width * 0.65
                
                # 判定上一行是否是字段或日期
                is_prev_field_or_date = bool(re.match(field_pattern, prev_text_plain) or re.match(date_pattern, prev_text_plain))
                # 优化：如果是长行且没有结束标点，不将其视为独立字段，允许段落合并
                if is_prev_field_or_date and len(prev_text_plain) > 30 and not prev_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':', ')', '）', '_')):
                    is_prev_field_or_date = False

                # 判断字体样式是否发生突变 (字号相差较大，或者加粗状态不一致)
                is_style_mutated = abs(prev_max_size - max_size) >= 1.5 or prev_bold != is_mostly_bold

                # 样式一致性延续 (修改：完全放宽对折行回退的限制，解决悬挂缩进问题)
                if dist_prev < max_size * 1.8 and not is_style_mutated:
                    if not prev_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':', ')', '）', '_')):
                        # 修改：如果上一行语义未完，即便当前行看起来像个短字段，也允许合并
                        # 但是：如果当前行本身就是一个明确的标题，坚决不合并
                        # 补充：如果上一行本身已经被确认为独立标题，也坚决不合并，防止正文粘连到标题中
                        if not is_prev_field_or_date and not prev_is_heading and not re.match(heading_pattern, line_text_plain):
                            if not is_prev_centered: # 只要上一行不居中，就允许尝试合并下一行（即便下一行因为排版短小被误判为居中）
                                # 只要差值不大于页宽的 40%（允许由于排版不规范导致的悬挂缩进）
                                if line_x0 - prev_line_x0 <= page_width * 0.4:
                                    is_part_of_paragraph = True
                                    should_merge_with_prev = True
                
                # 语义延续 (即使样式变了，如果上一行没结束且当前行没有标题特征，也视为段落延续)
                if not should_merge_with_prev and dist_prev < max_size * 2.0 and not is_style_mutated:
                    if not prev_text_plain.endswith(('。', '.', '！', '!', '？', '?', '；', ';', '：', ':', ')', '）', '_')):
                        if not prev_is_heading and not re.match(heading_pattern, line_text_plain) and not is_prev_centered:
                            # 同样：如果上一行语义未完，忽略当前行的字段锁定状态
                            if not is_prev_field_or_date:
                                # 同样应用放宽后的 x 坐标限制
                                if line_x0 - prev_line_x0 <= page_width * 0.4:
                                    is_semantic_continuation = True
                                    should_merge_with_prev = True

            # 终极排除：既不居中，又没有明确的序号特征，且长度/宽度较大的文本，绝对不是标题
            if not is_centered and not re.match(heading_pattern, line_text_plain):
                if len(line_text_plain) > 15 or line_width > page_width * 0.5:
                    score = 0

            # 排除项：属于连续段落的换行文本，或横跨页面大部分宽度的长行，通常不是标题
            if (is_part_of_paragraph or is_semantic_continuation) and not is_strong_heading:
                score -= 4
            
            if not is_centered and not is_strong_heading:
                if line_width > page_width * 0.6:
                    score -= 3
                if len(line_text_plain) >= 20:
                    score -= 3
            
            tag = "p"
            is_heading_style = score >= 3 and 0 < len(line_text_plain) < 80
            
            # 优化拦截逻辑：确保标题具有显著的视觉特征（大字号或加粗）
            # 1. 如果字号达到 15pt (约等于三号字) 以上，通常是章级标题，允许不加粗
            # 2. 如果是强标题模式（如“第1章”）且字号达到 14pt (四号字)，允许不加粗
            # 3. 如果字号在 12-15pt 之间，必须满足“加粗”或者“分值极高(score >= 4)”
            # 4. 如果字号小于 12pt，坚决不认作标题
            visual_check = False
            if max_size >= 15:
                visual_check = True
            elif re.match(strong_heading_pattern, line_text_plain) and max_size >= 14:
                visual_check = True
            elif max_size >= 12 and (is_mostly_bold or score >= 4):
                visual_check = True
            elif max_size >= 12 and not line_text_plain.endswith(('。', '.', '；', ';', '：', ':')):
                # 最小改动：针对 12pt 不加粗的漏网之鱼，如果具有极强的语义开头（附件/附表 或 中文数字加顿号），且无结尾标点，予以放行
                if re.match(r'^(附件|附表|附录)[一二三四五六七八九十\d]+', line_text_plain) or re.match(r'^[一二三四五六七八九十百]+[、]', line_text_plain):
                    visual_check = True
            
            if not visual_check:
                is_heading_style = False
            
            if is_heading_style:
                # 语义层级优先：根据中文排版规范强行映射到 h1-h3，使文档大纲结构清晰规整
                if re.match(r'^(第[一二三四五六七八九十百]+[卷章节部分])', line_text_plain):
                    tag = "h1"
                elif re.match(r'^(（[\d一二三四五六七八九十百]+）|\([\d一二三四五六七八九十百]+\))', line_text_plain):
                    tag = "h3"
                elif re.match(r'^([\d一二三四五六七八九十百]+[、])', line_text_plain):
                    tag = "h2"
                else:
                    # 对于无明确结构序号的文本（如封面“响应文件”，或大字正文，以及阿拉伯数字序号如 "3."），
                    # 彻底剥夺其标题资格，降级为普通段落（p），防止任何级别的 h 标签污染（即使是 h4/h5）。
                    # 其加粗排版将由后续处理内部文本时的 <strong> 标签承担。
                    tag = "p"
            
            prev_is_heading = is_heading_style and tag.startswith("h")
            
            # 生成 HTML 内容
            line_html = ""
            current_x = line_x0

            # --- 优化：合并片段以提升可编辑性 ---
            merged_fragments = []
            if line:
                temp_f = line[0].copy()
                if temp_f.get("is_drawing"):
                    # 将线条还原为下划线字符，使其可搜索、可编辑
                    temp_f["text"] = "_" * max(1, int((temp_f["x1"] - temp_f["x0"]) / 6))

                for next_f in line[1:]:
                    gap = next_f["x0"] - temp_f["x1"]
                    # 允许正常的字符间距，阈值根据字体大小动态调整
                    threshold = max(2.0, temp_f.get("size", 10.5) * 0.25)
                    if gap < threshold and next_f.get("bold") == temp_f.get("bold") and next_f.get("underlined") == temp_f.get("underlined") and not next_f.get("is_drawing") and not temp_f.get("is_drawing"):
                        temp_f["text"] += next_f["text"]
                        temp_f["x1"] = next_f["x1"]
                        temp_f["y0"] = min(temp_f["y0"], next_f["y0"])
                        temp_f["y1"] = max(temp_f["y1"], next_f["y1"])
                    else:
                        merged_fragments.append(temp_f)
                        temp_f = next_f.copy()
                        if temp_f.get("is_drawing"):
                            temp_f["text"] = "_" * max(1, int((temp_f["x1"] - temp_f["x0"]) / 6))
                merged_fragments.append(temp_f)

            for f in merged_fragments:
                gap = f["x0"] - current_x
                if gap > 2.0:
                    if gap > 15: # 只有大间距（如列间距）才使用 span 定位
                        line_html += f'<span style="display:inline-block; width:{gap/page_width*100:.2f}%"></span>'
                    else:
                        line_html += " " * max(1, int(gap / 3.5))

                txt = f["text"]
                # 移除多余的引导点虚线：3个及以上的连续点/间隔号/中文句号，或单个及以上的中文省略号(…)
                txt = re.sub(r'(?:[\.·。]\s*){3,}|[…]+', '', txt)
                
                if f.get("underlined"):
                    txt = f"<u>{txt}</u>"

                if tag == "p" and f.get("bold"):
                    line_html += f"<strong>{txt}</strong>"
                else:
                    line_html += txt
                current_x = f["x1"]
            
            # 计算样式
            margin_top = 0
            if prev_line_y1 is not None:
                dist = line_y0 - prev_line_y1
                if dist > 5: margin_top = min(40, int(dist * 0.8))
            
            style_parts = [
                f"margin-top: {margin_top}px",
                "white-space: pre-wrap",
                "word-break: break-word"
            ]
            
            if is_centered and not is_part_of_paragraph and not is_semantic_continuation:
                style_parts.append("text-align: center")
            else:
                # 使用相对偏移计算缩进
                # 【优化】：落款行如果不居中，应维持其在页面中的绝对位置比例，不减去 base_x0，以确保与上方表格等元素对齐
                if is_signature_line and line_x0 > page_width * 0.25:
                    indent_percent = (line_x0 / page_width) * 100
                else:
                    rel_indent = max(0, line_x0 - base_x0)
                    indent_percent = (rel_indent / page_width) * 100
                
                if indent_percent > 0.5: # 只有显著偏移才添加 margin-left
                    style_parts.append(f"margin-left: {indent_percent:.2f}%")

            if tag.startswith("h"):
                style_parts.append("font-weight: bold")
                style_parts.append("margin: 0.8em 0")

            # --- 实现强语义合并逻辑 ---
            if should_merge_with_prev and elements and elements[-1]["type"] == "text":
                prev_html = elements[-1]["html"]
                # 寻找闭合标签，例如 </p> 或 </h5>
                close_match = re.search(r'</([a-z0-9]+)>$', prev_html)
                if close_match:
                    close_tag = close_match.group(0)
                    inner_html = prev_html[:-len(close_tag)]
                    
                    # 智能空格连接逻辑：如果前后都是英文字母或数字，则添加空格
                    last_char = prev_text_plain[-1] if prev_text_plain else ""
                    first_char = line_text_plain[0] if line_text_plain else ""
                    
                    join_str = ""
                    if (re.match(r'[a-zA-Z0-9]', last_char) and re.match(r'[a-zA-Z0-9]', first_char)):
                        join_str = " "
                    
                    elements[-1]["html"] = inner_html + join_str + line_html + close_tag
                else:
                    elements.append({
                        "type": "text",
                        "html": f'<{tag} style="{"; ".join(style_parts)}">{line_html}</{tag}>',
                        "y0": line_y0
                    })
            else:
                elements.append({
                    "type": "text",
                    "html": f'<{tag} style="{"; ".join(style_parts)}">{line_html}</{tag}>',
                    "y0": line_y0
                })
            
            prev_line_y1 = max(s["y1"] for s in line)

        return elements

    @staticmethod
    def _is_inside_table(bbox, table_bboxes):
        r = fitz.Rect(bbox)
        for tb in table_bboxes:
            if r.intersects(fitz.Rect(tb)):
                return True
        return False
