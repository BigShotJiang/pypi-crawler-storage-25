import os
import re
from .pdf_loader import PDFLoader
from .table_extractor import TableExtractor
from .layout_engine import LayoutEngine
from .html_renderer import HTMLRenderer

class PDFConverter:
    def __init__(self, file_path):
        self.file_path = file_path
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File {file_path} not found.")

    def convert(self, pages=None, full_html=False):
        """
        Convert PDF to HTML.
        :param pages: List of page numbers (1-based), e.g., [1, 2]. If None, convert all pages.
        :param full_html: If True, return full HTML document. If False, return HTML snippets.
        :return: HTML string.
        """
        # 为了保证准确性，网格统一通常建议扫描全文档（Pass 1）
        # 即使只提取一页，也需要知道这页表格在全文档中的列对齐情况
        unified_grids = self._get_unified_grids(scan_all=True)

        pages_data = []
        with PDFLoader(self.file_path) as loader:
            total_pages = len(loader)
            target_indices = None
            if pages:
                # 过滤掉非法的页码
                target_indices = sorted([p - 1 for p in pages if 1 <= p <= total_pages])

            # 使用优化后的 get_pages
            for fitz_page, plumber_page, p_idx in loader.get_pages(target_indices):
                # 获取该页前 30 个字符作为预览
                preview = fitz_page.get_text().strip().replace("\n", " ")[:30]
                print(f"Processing Physical Page {p_idx + 1} | Preview: {preview}...")
                # 1. Extract tables with unified grids
                tables = TableExtractor.extract_tables_from_page(
                    plumber_page, unified_grids
                )
                table_bboxes = [t["bbox"] for t in tables]

                # 2. Extract layout (filtering out table areas)
                text_elements = LayoutEngine.extract_layout(fitz_page, table_bboxes)

                # 3. Combine and sort
                table_elements = []
                for t in tables:
                    table_elements.append(
                        {
                            "type": "table",
                            "html": t["html"],
                            "y0": t["bbox"][1],
                            "num_cols": t.get("num_cols"),
                            "col_widths": t.get("col_widths"),
                            "bbox": t["bbox"],
                        }
                    )

                all_elements = text_elements + table_elements
                all_elements.sort(key=lambda x: x["y0"])

                pages_data.append(
                    {
                        "page_index": p_idx,  # 记录物理页码，用于判断连续性
                        "elements": all_elements,
                    }
                )

        # 3. Merge tables and paragraphs across pages
        pages_data = self._merge_tables_across_pages(pages_data)
        pages_data = self._merge_paragraphs_across_pages(pages_data)

        # 4. Render
        renderer = HTMLRenderer()
        if full_html:
            return renderer.render(pages_data)
        else:
            return renderer.render_fragments(pages_data)

    def _merge_paragraphs_across_pages(self, pages_data):
        if not pages_data or len(pages_data) < 2:
            return pages_data

        for i in range(len(pages_data) - 1):
            prev_page = pages_data[i]
            curr_page = pages_data[i+1]
            
            # 物理页码必须连续
            if curr_page["page_index"] != prev_page["page_index"] + 1:
                continue
                
            if not prev_page["elements"] or not curr_page["elements"]:
                continue
                
            last_elem = prev_page["elements"][-1]
            first_elem = curr_page["elements"][0]
            
            # 只有文本段落才尝试跨页合并
            if last_elem["type"] == "text" and first_elem["type"] == "text":
                last_html = last_elem["html"]
                first_html = first_elem["html"]
                
                # 检查是否都是普通段落 <p> (排除标题 h1-h5)
                if last_html.startswith("<p") and first_html.startswith("<p"):
                    # 提取纯文本内容检查结束符
                    def get_inner_content(html):
                        # 移除标签提取内容
                        content = re.sub(r"<[^>]+>", "", html).strip()
                        return content
                    
                    prev_text = get_inner_content(last_html)
                    curr_text = get_inner_content(first_html)
                    
                    if not prev_text: continue
                    
                    # 如果前一页末尾没有结束标点，且后一页开头不是标题或独立字段
                    terminators = ('。', '.', '！', '!', '？', '?', '；', ';', '：', ':', ')', '）', '_')
                    if not prev_text.endswith(terminators):
                        # 检查当前行是否包含明显的标题序号特征
                        heading_pattern = r'^(第[一二三四五六七八九十百]+[章节部分]|(\d+\.)+\d*|[\d、]+|[A-Z]\.|\(?\d+\)?|（\d+）)\s*'
                        if not re.match(heading_pattern, curr_text):
                            # 执行跨页合并
                            # 提取第一个元素的 inner html
                            first_inner_match = re.search(r"<p[^>]*>(.*?)</p>", first_html, re.DOTALL)
                            if first_inner_match:
                                first_inner = first_inner_match.group(1)
                                
                                # 智能空格连接
                                join_str = ""
                                if prev_text and curr_text:
                                    if re.match(r'[a-zA-Z0-9]', prev_text[-1]) and re.match(r'[a-zA-Z0-9]', curr_text[0]):
                                        join_str = " "
                                
                                # 拼入前页末尾
                                close_tag = "</p>"
                                last_elem["html"] = last_html[:last_html.rfind(close_tag)] + join_str + first_inner + close_tag
                                # 从当前页移除已被合并的元素
                                curr_page["elements"].pop(0)
        
        return pages_data

    def _get_unified_grids(self, scan_all=True):
        """
        扫描文档以统一表格网格。
        scan_all=True 保证了无论提取哪一页，表格列宽的计算标准都是一致的，这极大提升了"准确度"。
        """
        raw_grids = []
        with PDFLoader(self.file_path) as loader:
            # 扫描所有页面的表格边框以计算统一的列坐标
            for _, plumber_page, _ in loader.get_pages():
                page_grids = TableExtractor.get_table_grids(plumber_page)
                raw_grids.extend(page_grids)

        unified_grids = []
        for rg in raw_grids:
            matched = False
            for ug in unified_grids:
                # 判定为同一个表格列结构的逻辑
                if (
                    abs(rg["bbox"][0] - ug["bbox"][0]) < 10
                    and abs(rg["bbox"][2] - ug["bbox"][2]) < 10
                ):
                    combined = sorted(list(set(ug["x_coords"] + rg["x_coords"])))
                    clusters = []
                    for val in combined:
                        if not clusters:
                            clusters.append([val])
                        else:
                            if val - clusters[-1][-1] <= 3:
                                clusters[-1].append(val)
                            else:
                                clusters.append([val])
                    ug["x_coords"] = [round(sum(c) / len(c), 1) for c in clusters]
                    ug["bbox"] = (
                        min(ug["bbox"][0], rg["bbox"][0]),
                        min(ug["bbox"][1], rg["bbox"][1]),
                        max(ug["bbox"][2], rg["bbox"][2]),
                        max(ug["bbox"][3], rg["bbox"][3]),
                    )
                    matched = True
                    break
            if not matched:
                unified_grids.append({"bbox": rg["bbox"], "x_coords": rg["x_coords"]})
        return unified_grids

    def _merge_tables_across_pages(self, pages_data):
        if not pages_data:
            return []

        last_table_elem = None
        last_page_idx = -1

        final_pages = []

        for page_data in pages_data:
            current_page_idx = page_data["page_index"]
            elements = page_data["elements"]

            if not elements:
                final_pages.append(page_data)
                last_page_idx = current_page_idx
                last_table_elem = None
                continue

            first_elem = elements[0]

            # 关键改进：只有当物理页码连续时，才尝试合并表格
            can_merge = (
                last_table_elem is not None
                and first_elem["type"] == "table"
                and current_page_idx == last_page_idx + 1
            )

            if can_merge:
                is_match = False
                if "bbox" in first_elem and "bbox" in last_table_elem:
                    bbox1 = last_table_elem["bbox"]
                    bbox2 = first_elem["bbox"]
                    if abs(bbox1[0] - bbox2[0]) < 15 and abs(bbox1[2] - bbox2[2]) < 15:
                        is_match = True

                if is_match:
                    html1 = last_table_elem["html"]
                    html2 = first_elem["html"]

                    tr_pattern = re.compile(r"    <tr>.*?    </tr>", re.DOTALL)
                    rows1 = tr_pattern.findall(html1)
                    rows2 = tr_pattern.findall(html2)

                    if rows1 and rows2:
                        header1_clean = re.sub(r"\s+", "", rows1[0])
                        header2_clean = re.sub(r"\s+", "", rows2[0])
                        if header1_clean == header2_clean:
                            rows2 = rows2[1:]

                        if rows1 and rows2:
                            last_tr = rows1[-1]
                            first_tr_2 = rows2[0]
                            td_pattern = re.compile(r"<td(.*?)>(.*?)</td>", re.DOTALL)
                            cells1 = td_pattern.findall(last_tr)
                            cells2 = td_pattern.findall(first_tr_2)

                            if len(cells1) == len(cells2):

                                def is_empty(h_content):
                                    return not re.sub(
                                        r"<.*?>|\s+|&nbsp;", "", h_content
                                    )

                                if is_empty(cells2[0][1]) and not is_empty(
                                    cells1[0][1]
                                ):
                                    merged_cells = []
                                    for i in range(len(cells1)):
                                        attr1, cont1 = cells1[i]
                                        attr2, cont2 = cells2[i]
                                        new_cont = cont1.strip()
                                        c2_stripped = cont2.strip()
                                        if c2_stripped:
                                            if new_cont:
                                                new_cont += "<br>" + c2_stripped
                                            else:
                                                new_cont = c2_stripped
                                        merged_cells.append(
                                            f"      <td{attr1}>{new_cont}</td>"
                                        )
                                    merged_cells_str = '\n'.join(merged_cells)
                                    rows1[-1] = (
                                        f"    <tr>\n{merged_cells_str}\n    </tr>"
                                    )
                                    rows2 = rows2[1:]

                    all_rows = rows1 + rows2
                    new_rows_html = "\n".join(all_rows)
                    table_start = html1[: html1.find("  <tbody>") + 9]
                    last_table_elem["html"] = (
                        table_start + "\n" + new_rows_html + "\n  </tbody>\n</table>"
                    )
                    elements.pop(0)

            if elements:
                final_pages.append(page_data)
                if elements and elements[-1]["type"] == "table":
                    last_table_elem = elements[-1]
                else:
                    last_table_elem = None
            else:
                # 整个页面内容都被合并到了上一页
                pass

            last_page_idx = current_page_idx

        return final_pages


def parse_pdf(file_path, pages=None):
    converter = PDFConverter(file_path)
    return converter.convert(pages=pages)
