import argparse
import os
from .converter import PDFConverter

def main():
    parser = argparse.ArgumentParser(description="Convert PDF to HTML with preserved layout and table extraction.")
    parser.add_argument("input_pdf", help="Path to the input PDF file")
    parser.add_argument("-o", "--output", help="Path to the output HTML file", default="output.html")
    parser.add_argument("-p", "--pages", help="Pages to convert (e.g., 1,2,3 or 1-5)", default=None)
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input_pdf):
        print(f"Error: File {args.input_pdf} not found.")
        return

    # Parse pages argument
    pages = None
    if args.pages:
        pages = []
        try:
            for part in args.pages.split(','):
                if '-' in part:
                    start, end = map(int, part.split('-'))
                    pages.extend(range(start, end + 1))
                else:
                    pages.append(int(part))
            pages = sorted(list(set(pages)))
        except ValueError:
            print("Error: Invalid pages format. Use '1,2,3' or '1-5'.")
            return

    print(f"Converting {args.input_pdf}...")
    try:
        converter = PDFConverter(args.input_pdf)
        # In CLI mode, we usually want full HTML
        html_content = converter.convert(pages=pages, full_html=True)
        
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"Successfully converted {args.input_pdf} to {args.output}")
    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
