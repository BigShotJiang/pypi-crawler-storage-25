import re

class TableExtractor:
    @staticmethod
    def _is_visible(obj):
        """检查 pdfplumber 对象（如线条、矩形、曲线）是否可见（非白色且非透明）。"""
        def _is_invisible_color(color):
            if color is None: return True
            # 支持 RGB (1,1,1), Grayscale (1,), CMYK (0,0,0,0) 等
            if isinstance(color, (list, tuple)):
                if not color: return True
                if len(color) == 1: return color[0] >= 0.95
                if len(color) == 3: 
                    # 过滤白色
                    if all(c >= 0.95 for c in color): return True
                    # 过滤明显的彩色（如红色印章），只保留黑色/灰色（RGB 分量相近）
                    if (max(color) - min(color)) > 0.1: return True
                    return False
                if len(color) == 4: return all(c < 0.05 for c in color) # CMYK 0,0,0,0 is white
            elif isinstance(color, (int, float)):
                return color >= 0.95
            return False

        def _is_transparent(obj, prefix=""):
            # 有些 PDF 会把透明度放在不同的属性里
            opacity = obj.get(f"{prefix}opacity") or obj.get("opacity")
            return opacity is not None and opacity < 0.05

        # 忽略极细的线条（通常是排版残留）
        obj_type = obj.get("object_type")
        if obj_type == "line":
            linewidth = obj.get("linewidth", 1.0)
            if linewidth is not None and linewidth < 0.1:
                return False
            if _is_invisible_color(obj.get("stroking_color")) or _is_transparent(obj, "stroke_"):
                return False
        elif obj_type in ("rect", "curve"):
            # 只有当填充色和边框色都不可见时，才认为该对象不可见
            invisible_fill = _is_invisible_color(obj.get("non_stroking_color")) or _is_transparent(obj, "fill_")
            invisible_stroke = _is_invisible_color(obj.get("stroking_color")) or _is_transparent(obj, "stroke_")
            if invisible_fill and invisible_stroke:
                return False
        elif obj_type == "char":
            # 过滤不可见或彩色的文本（常用于防伪码、追踪码、印章内容）
            if _is_invisible_color(obj.get("non_stroking_color")):
                return False
        return True

    @staticmethod
    def get_table_grids(plumber_page):
        """仅提取页面中所有表格的 X 轴坐标网格，不处理文本。"""
        # 过滤掉不可见的布局线条
        filtered_page = plumber_page.filter(TableExtractor._is_visible)
        page_height = filtered_page.height
        explicit_h_lines = [0, page_height]
        
        # 增加跨页表格识别：寻找垂直线的端点并补充水平线
        v_edges = [e for e in filtered_page.edges if e['orientation'] == 'v']
        if v_edges:
            min_top = min(e['top'] for e in v_edges)
            max_bottom = max(e['bottom'] for e in v_edges)
            # 只有当垂直线靠近页面边缘时，才认为是跨页被截断的表格
            if min_top < page_height * 0.15:
                explicit_h_lines.append(min_top)
            if max_bottom > page_height * 0.85:
                explicit_h_lines.append(max_bottom)

        table_settings_lines = {
            "vertical_strategy": "lines",
            "horizontal_strategy": "lines",
            "explicit_horizontal_lines": explicit_h_lines,
            "snap_tolerance": 3,
            "join_tolerance": 3,
            "edge_min_length": 3,
            "intersection_tolerance": 3,
        }
        table_settings_text = {
            "vertical_strategy": "text",
            "horizontal_strategy": "lines",
            "explicit_horizontal_lines": explicit_h_lines,
            "snap_tolerance": 3,
            "join_tolerance": 3,
            "edge_min_length": 3,
            "intersection_tolerance": 3,
        }
        
        found_tables = filtered_page.find_tables(table_settings_lines)
        found_tables_text = filtered_page.find_tables(table_settings_text)
        
        # Merge results, avoiding duplicates
        final_tables = list(found_tables)
        for t_text in found_tables_text:
            overlap = False
            for t_line in found_tables:
                # Check for bbox intersection
                if (t_text.bbox[0] < t_line.bbox[2] and t_text.bbox[2] > t_line.bbox[0] and
                    t_text.bbox[1] < t_line.bbox[3] and t_text.bbox[3] > t_line.bbox[1]):
                    overlap = True
                    break
            if not overlap:
                final_tables.append(t_text)
                
        grids = []
        for table in final_tables:
            all_cells = [c for r in table.rows for c in r.cells if c is not None]
            if not all_cells: continue
            x_coords = sorted(list(set([round(c[0], 1) for c in all_cells] + [round(c[2], 1) for c in all_cells])))
            grids.append({
                'bbox': table.bbox,
                'x_coords': x_coords
            })
        return grids

    @staticmethod
    def extract_tables_from_page(plumber_page, unified_grids=None):
        """
        使用几何坐标分析法提取表格，支持外部传入统一网格以保持跨页一致性。
        """
        # 过滤不可见元素
        filtered_page = plumber_page.filter(TableExtractor._is_visible)
        
        tables = []
        all_words = filtered_page.extract_words(extra_attrs=['fontname'])
        
        lines = [l for l in filtered_page.lines if abs(l["y0"] - l["y1"]) < 2]
        rects = [r for r in filtered_page.rects if r["height"] < 2]
        curves = [c for c in filtered_page.curves if abs(c["y0"] - c["y1"]) < 2]
        drawings = lines + rects + curves

        page_height = filtered_page.height
        explicit_h_lines = [0, page_height]

        # 增加跨页表格识别：寻找垂直线的端点并补充水平线
        v_edges = [e for e in filtered_page.edges if e['orientation'] == 'v']
        if v_edges:
            min_top = min(e['top'] for e in v_edges)
            max_bottom = max(e['bottom'] for e in v_edges)
            # 只有当垂直线靠近页面边缘时，才认为是跨页被截断的表格
            if min_top < page_height * 0.15:
                explicit_h_lines.append(min_top)
            if max_bottom > page_height * 0.85:
                explicit_h_lines.append(max_bottom)

        table_settings_lines = {
            "vertical_strategy": "lines",
            "horizontal_strategy": "lines",
            "explicit_horizontal_lines": explicit_h_lines,
            "snap_tolerance": 3,
            "join_tolerance": 3,
            "edge_min_length": 3,
            "intersection_tolerance": 3,
        }
        table_settings_text = {
            "vertical_strategy": "text",
            "horizontal_strategy": "lines",
            "explicit_horizontal_lines": explicit_h_lines,
            "snap_tolerance": 3,
            "join_tolerance": 3,
            "edge_min_length": 3,
            "intersection_tolerance": 3,
        }

        found_tables = filtered_page.find_tables(table_settings_lines)
        found_tables_text = filtered_page.find_tables(table_settings_text)
        
        final_tables = list(found_tables)
        for t_text in found_tables_text:
            overlap = False
            for t_line in found_tables:
                if (t_text.bbox[0] < t_line.bbox[2] and t_text.bbox[2] > t_line.bbox[0] and
                    t_text.bbox[1] < t_line.bbox[3] and t_text.bbox[3] > t_line.bbox[1]):
                    overlap = True
                    break
            if not overlap:
                final_tables.append(t_text)

        page_height = filtered_page.height
        # Tables can be close to edges, use a smaller threshold for skipping
        header_threshold = page_height * 0.05
        footer_threshold = page_height * 0.95

        for table in final_tables:
            # Only skip if the table is entirely within the header/footer area AND is small
            # This allows cross-page tables to be captured.
            is_in_header = table.bbox[3] < header_threshold
            is_in_footer = table.bbox[1] > footer_threshold
            
            if is_in_header or is_in_footer:
                # If it is a very small table in header/footer, skip it (likely page number or decoration)
                if (table.bbox[3] - table.bbox[1]) < 30:
                    continue

            # 寻找匹配的统一网格
            x_grid = None
            if unified_grids:
                for ug in unified_grids:
                    # 如果 bbox 的左右边界对齐（15像素误差内），则使用该统一网格
                    if abs(table.bbox[0] - ug['bbox'][0]) < 15 and abs(table.bbox[2] - ug['bbox'][2]) < 15:
                        x_grid = ug['x_coords']
                        break

            raw_data = table.extract()
            html, num_cols, col_widths = TableExtractor._generate_precise_html(table, raw_data, drawings, filtered_page, all_words, x_grid)
            tables.append({
                'html': html,
                'bbox': table.bbox,
                'num_cols': num_cols,
                'col_widths': col_widths
            })
            
        return tables

    @staticmethod
    def _generate_precise_html(table, raw_data, drawings, page, all_words, unified_x_coords=None):
        """基于几何坐标网格生成精确的 HTML 表格。"""
        rows = table.rows
        all_cells = [c for r in rows for c in r.cells if c is not None]
        if not all_cells: return "", 0, []
        
        # 1. 建立坐标网格
        if unified_x_coords:
            # 根据当前表格单元格的实际范围裁剪统一网格
            min_x0 = min(c[0] for c in all_cells)
            max_x1 = max(c[2] for c in all_cells)
            x_coords = [x for x in unified_x_coords if min_x0 - 2 <= x <= max_x1 + 2]
            
            # 确保边界被包含
            if not x_coords or x_coords[0] > min_x0 + 1:
                x_coords.insert(0, round(min_x0, 1))
            if x_coords[-1] < max_x1 - 1:
                x_coords.append(round(max_x1, 1))
            x_coords = sorted(list(set(x_coords)))
        else:
            x_coords = sorted(list(set([round(c[0], 1) for c in all_cells] + [round(c[2], 1) for c in all_cells])))
        
        y_coords = sorted(list(set([round(c[1], 1) for c in all_cells] + [round(c[3], 1) for c in all_cells])))
        
        def find_closest(val, coords):
            best_i = 0
            min_diff = float('inf')
            for i, c in enumerate(coords):
                diff = abs(val - c)
                if diff < min_diff:
                    min_diff = diff
                    best_i = i
            return best_i

        num_rows = len(y_coords) - 1
        num_cols = len(x_coords) - 1
        
        total_w = x_coords[-1] - x_coords[0] if len(x_coords) > 1 else 1
        col_widths = [round((x_coords[i+1] - x_coords[i]) / total_w, 3) for i in range(num_cols)]
        
        processed = [[False for _ in range(num_cols)] for _ in range(num_rows)]
        
        html = ['<table>']
        if col_widths:
            html.append('  <colgroup>')
            for w in col_widths:
                html.append(f'    <col style="width: {w * 100:.2f}%;">')
            html.append('  </colgroup>')
        html.append('  <tbody>')
        
        for r_idx, row in enumerate(rows):
            html.append('    <tr>')
            for c_idx, cell_bbox in enumerate(row.cells):
                if cell_bbox is None: continue
                
                x0, y0, x1, y1 = [round(v, 1) for v in cell_bbox]
                
                # 使用吸附逻辑映射到网格
                col_start = find_closest(x0, x_coords)
                col_end = find_closest(x1, x_coords)
                row_start = find_closest(y0, y_coords)
                row_end = find_closest(y1, y_coords)
                
                # 确保 start 小于 end
                if col_start >= col_end: col_end = min(col_start + 1, num_cols)
                if row_start >= row_end: row_end = min(row_start + 1, num_rows)
                
                # 索引越界保护
                if col_start >= num_cols or row_start >= num_rows:
                    continue

                if processed[row_start][col_start]: continue
                
                # 再次校正结束索引，确保不越界
                col_end = min(col_end, num_cols)
                row_end = min(row_end, num_rows)
                
                cs = col_end - col_start
                rs = row_end - row_start
                for r in range(row_start, row_end):
                    for c in range(col_start, col_end):
                        if r < num_rows and c < num_cols: processed[r][c] = True
                
                cell_text = raw_data[r_idx][c_idx] or ""
                
                cell_drawings = []
                for d in drawings:
                    if (d["width"] > 10 and d["x0"] >= x0 + 1.5 and d["x1"] <= x1 - 1.5 and
                        y0 + 1.5 <= d["top"] <= y1 - 1.5):
                        cell_drawings.append(d)
                
                has_drawings = len(cell_drawings) > 0
                
                if has_drawings:
                    total_width = sum(d["width"] for d in cell_drawings)
                    # 增加最大长度，并调整比例使其更接近原貌
                    underscores = "_" * min(40, max(2, int(total_width / 5.0)))
                    if cell_text:
                        if "：" in cell_text or ":" in cell_text:
                            cell_text = cell_text.replace("：", "：" + underscores).replace(":", ":" + underscores)
                        else:
                            # 启发式判断：根据图形中心点位置决定插入位置
                            words_in_cell = [w for w in all_words if 
                                             w['x0'] >= x0 - 0.5 and w['x1'] <= x1 + 0.5 and 
                                             w['top'] >= y0 - 0.5 and w['bottom'] <= y1 + 0.5]
                            if words_in_cell:
                                min_w_x0 = min(w['x0'] for w in words_in_cell)
                                max_w_x1 = max(w['x1'] for w in words_in_cell)
                                mid_line_x = sum(d['x0'] + d['x1'] for d in cell_drawings) / (2 * len(cell_drawings))
                                
                                if mid_line_x < min_w_x0:
                                    cell_text = underscores + cell_text
                                elif mid_line_x > max_w_x1:
                                    cell_text = cell_text + underscores
                                elif " " in cell_text:
                                    cell_text = cell_text.replace(" ", underscores)
                                else:
                                    # 线段在文本正下方（下划线/边框），且没有空格占位，忽略它
                                    pass
                            else:
                                cell_text = underscores
                    else:
                        cell_text = underscores

                clean_val = cell_text.strip()
                # 移除多余的引导点虚线：3个及以上的连续点/间隔号/中文句号，或单个及以上的中文省略号(…)
                clean_val = re.sub(r'(?:[\.·。]\s*){3,}|[…]+', '', clean_val).strip()
                align = "left"
                is_bold = False
                
                if clean_val and not has_drawings:
                    words = [w for w in all_words if 
                             w['x0'] >= x0 - 0.5 and w['x1'] <= x1 + 0.5 and 
                             w['top'] >= y0 - 0.5 and w['bottom'] <= y1 + 0.5]
                    
                    if words:
                        text_x0 = min(w['x0'] for w in words)
                        text_x1 = max(w['x1'] for w in words)
                        cell_mid = (x0 + x1) / 2
                        text_mid = (text_x0 + text_x1) / 2
                        cell_width = x1 - x0
                        if abs(text_mid - cell_mid) < (cell_width * 0.18):
                            align = "center"
                        elif (x1 - text_x1) < (text_x0 - x0) * 0.4:
                            align = "right"
                            
                        bold_count = 0
                        for w in words:
                            fname = w.get('fontname', "").lower()
                            if any(k in fname for k in ["bold", "semibold", "medium", "heavy", "w6", "w7"]):
                                bold_count += 1
                        if bold_count >= len(words) / 2:
                            is_bold = True
                
                if align == "left" and not has_drawings:
                    text_content = clean_val.replace(" ", "").replace("\u3000", "")
                    if 0 < len(text_content) <= 10 and "：" not in clean_val and ":" not in clean_val:
                        align = "center"

                display_val = clean_val.replace('\n', '<br>')
                if is_bold:
                    display_val = f"<strong>{display_val}</strong>"

                style_parts = [f"text-align: {align};", "vertical-align: middle;"]
                style_str = f' style="{" ".join(style_parts)}"'
                
                span_attrs = []
                if rs > 1: span_attrs.append(f'rowspan="{rs}"')
                if cs > 1: span_attrs.append(f'colspan="{cs}"')
                attr_str = " " + " ".join(span_attrs) if span_attrs else ""
                
                html.append(f'      <td{style_str}{attr_str}>{display_val}</td>')
            html.append('    </tr>')
            
        html.append('  </tbody>')
        html.append('</table>')
        return "\n".join(html), num_cols, col_widths
