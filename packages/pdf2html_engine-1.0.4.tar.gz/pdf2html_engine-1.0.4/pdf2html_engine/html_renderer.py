from jinja2 import Template

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Converted PDF</title>
    <style>
        body {
            font-family: "PingFang SC", "Microsoft YaHei", "SimSun", serif;
            color: #333;
            max-width: 860px;
            margin: 0 auto;
            padding: 20px 40px;
            background-color: #fff;
            line-height: 1.6;
        }
        p, h1, h2, h3, h4, h5 {
            margin: 0.8em 0;
            font-weight: normal; /* 由内联 style 控制加粗 */
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 15px 0;
            border: 1px solid #666;
            font-size: 0.95em;
        }
        table td {
            border: 1px solid #999;
            padding: 6px 10px;
            vertical-align: middle;
            min-height: 1.8em;
            word-break: break-all;
        }
        strong {
            font-weight: bold;
        }
        .page {
            margin-bottom: 30px;
            position: relative;
        }
    </style>

<body>
    {% for page in pages %}
    <div class="page">
        {% for element in page.elements %}
            {{ element.html | safe }}
        {% endfor %}
    </div>
    {% if not loop.last %}
    {% endif %}
    {% endfor %}
</body>
</html>
"""


class HTMLRenderer:
    def __init__(self):
        self.template = Template(HTML_TEMPLATE)

    def render(self, pages_data):
        """
        pages_data is a list of dicts:
        {
            'elements': [{'type': 'text'|'table', 'html': str}]
        }
        """
        return self.template.render(pages=pages_data)

    def render_fragments(self, pages_data):
        """
        Returns only the HTML content of pages, suitable for embedding.
        """
        fragments = []
        for page in pages_data:
            page_html = ['<div class="page">']
            for element in page['elements']:
                page_html.append(element['html'])
            page_html.append('</div>')
            fragments.append("\n".join(page_html))
        return "\n".join(fragments)
