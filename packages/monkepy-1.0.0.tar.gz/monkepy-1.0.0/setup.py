from setuptools import setup

setup(
    name="monkepy",
    version="1.0.0",
    py_modules=["monkepy"],
    install_requires=[
        "matplotlib",
        "numpy",
    ],
    author="Sundaram",
    description="High-Visualization DL monitoring with Red Alert NaN detection",
    # UPDATE THIS LINE BELOW:
    long_description=open("README.md", encoding="utf-8").read(), 
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
)