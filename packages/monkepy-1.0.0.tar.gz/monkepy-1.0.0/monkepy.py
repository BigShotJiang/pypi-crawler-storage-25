import matplotlib.pyplot as plt
import numpy as np
import json

class graph:
    def __init__(self, file_name=None, theme="dark", label_printing=True):
        self.file_name = file_name
        self.label_printing = label_printing
        self.knowledge_base = "monkepy_key.json"
        self.data_registry = {}
        self.color_main = "#00FF41" # Neon Green
        self.color_alt = "#00BFFF"  # Deep Sky Blue
        
        if theme == "dark":
            plt.style.use('dark_background')

    def _process_data(self, data):
        """Processes tensors and checks for explosions."""
        is_broken = False
        # (Internal logic to convert Torch/Numpy to plottable arrays)
        # Assuming the logic from our previous version is here
        import torch # Local import for safety
        if torch.is_tensor(data):
            if torch.isnan(data).any() or torch.isinf(data).any():
                is_broken = True
            return data.detach().cpu().numpy(), is_broken
        arr = np.array(data)
        if np.isnan(arr).any() or np.isinf(arr).any():
            is_broken = True
        return arr, is_broken

    def plot(self, data, alt_data=None, name="tensor_01", alt_name="tensor_02"):
        """
        MASTER PLOT: Supports Dual-Graphs and Loop Breaking.
        Returns: True if healthy, False if NaN/Inf detected.
        """
        # Process Main Data
        main_plot, main_broken = self._process_data(data)
        
        # Determine Layout: Single or Dual
        if alt_data is not None:
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))
            alt_plot, alt_broken = self._process_data(alt_data)
            any_broken = main_broken or alt_broken
            
            # Plot 1
            ax1.plot(main_plot, color="#FF0000" if main_broken else self.color_main)
            ax1.set_title(f"{name} {'(EXPLODED)' if main_broken else ''}")
            
            # Plot 2
            ax2.plot(alt_plot, color="#FF0000" if alt_broken else self.color_alt)
            ax2.set_title(f"{alt_name} {'(EXPLODED)' if alt_broken else ''}")
        else:
            fig, ax1 = plt.subplots(figsize=(10, 4))
            any_broken = main_broken
            ax1.plot(main_plot, color="#FF0000" if any_broken else self.color_main)
            ax1.set_title(f"monkepy | {name}")

        plt.tight_layout()

        # MASTER BREAK SIGNAL LOGIC
        if any_broken:
            print(f"\n[!!!] CRITICAL: {name} or {alt_name} has EXPLODED.")
            plt.show(block=True)
            return False # This is your BREAK SIGNAL
        
        if self.file_name:
            plt.savefig(self.file_name)
            plt.close()
        else:
            plt.show(block=False)
            plt.pause(0.1)
            plt.close()
            
        return True # Continue Learning