# 🐒 monkepy
**Master-Level Data-visulizations.**

`monkepy` is a high-performance bridge for Big Frameworks like Torch and NumPy.

## 🔥 Why monkepy?
- **Red Alert:** Visual line color shifts to Red on NaN/Inf detection.
- **Dual-Graph:** Compare two metrics (Loss/Acc) side-by-side automatically.
- **Loop Break:** Returns a `False` signal to kill training loops when gradients explode.

## 🚀 Installation
```bash
pip install monkepy