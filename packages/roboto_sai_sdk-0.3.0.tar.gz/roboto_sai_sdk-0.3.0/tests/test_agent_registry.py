from __future__ import annotations

import pytest

import roboto_sai_sdk.agent_registry as registry
from roboto_sai_sdk.agent_registry import ORCHESTRATOR_IDENTITY, get_agent, list_agents, register_agent
from roboto_sai_sdk.agent_types import AgentManifest


def test_only_code_fast_and_heavy_are_registered() -> None:
    agents = list_agents()

    assert [agent.id for agent in agents] == ["heavy", "code", "fast"]
    assert {agent.display_name for agent in agents} == {"Heavy", "Code X", "Lightning"}


def test_register_agent_rejects_orchestrator_identity(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(registry, "_AGENTS", {})

    with pytest.raises(ValueError, match="orchestrator identity"):
        register_agent(ORCHESTRATOR_IDENTITY)


def test_register_agent_adds_new_worker_when_valid(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(registry, "_AGENTS", {})
    worker = AgentManifest(
        id="scribe",
        display_name="Scribe",
        role="worker",
        specialization="Documentation and summarization.",
        model_preference="roboto-sai",
        routing_priority=250,
        memory_scope="session",
        tool_access=("analysis",),
        output_style="clear",
    )

    registered = register_agent(worker)

    assert registered is worker
    assert get_agent("SCRIBE") is worker


def test_list_agents_returns_priority_sorted_workers() -> None:
    agents = list_agents()

    assert [agent.routing_priority for agent in agents] == [400, 300, 200]
    assert [agent.id for agent in agents] == ["heavy", "code", "fast"]


def test_get_agent_is_case_insensitive_and_returns_none_for_unknown() -> None:
    assert get_agent("CoDe") is not None
    assert get_agent("FAST") is not None
    assert get_agent("unknown-agent") is None
    assert get_agent("roboto-sai") is None
