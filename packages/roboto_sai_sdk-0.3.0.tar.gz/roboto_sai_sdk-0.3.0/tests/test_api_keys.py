from __future__ import annotations

import hashlib

import pytest

from roboto_sai_sdk.api_keys import (
    SAI_API_KEY,
    XAI_API_KEY,
    get_sai_api_key,
    get_xai_api_key,
    hash_key,
    resolve_api_keys,
)


def test_precedence_is_explicit_then_sai_then_xai() -> None:
    environment = {
        SAI_API_KEY: "sai-key",
        XAI_API_KEY: "xai-key",
    }

    assert resolve_api_keys("explicit-key", environment)["active_source"] == "explicit"
    assert resolve_api_keys("explicit-key", environment)["active_key"] == "explicit-key"
    assert resolve_api_keys(None, environment)["active_source"] == SAI_API_KEY
    assert resolve_api_keys(None, {XAI_API_KEY: "xai-key"})["active_source"] == XAI_API_KEY


def test_environment_lookup_and_normalization_work() -> None:
    environment = {
        SAI_API_KEY: "  sai-key  ",
        XAI_API_KEY: "  xai-key  ",
    }

    assert get_sai_api_key(environment) == "sai-key"
    assert get_xai_api_key(environment) == "xai-key"
    assert resolve_api_keys(None, environment) == {
        "active_key": "sai-key",
        "active_source": SAI_API_KEY,
        "sai_api_key": "sai-key",
        "xai_api_key": "xai-key",
    }


def test_provided_environment_overrides_process_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(SAI_API_KEY, "process-sai")

    resolved = resolve_api_keys(None, {XAI_API_KEY: "provided-xai"})

    assert resolved["active_key"] == "provided-xai"
    assert resolved["active_source"] == XAI_API_KEY


def test_hashing_is_deterministic_and_normalizes_input() -> None:
    expected = hashlib.sha256("secret-key".encode("utf-8")).hexdigest()

    assert hash_key("  secret-key  ") == expected
    assert hash_key("secret-key") == expected


def test_missing_key_handling_and_blank_hashing_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("SAI_API_KEY", raising=False)
    monkeypatch.delenv("XAI_API_KEY", raising=False)
    resolved = resolve_api_keys(None, {})

    assert resolved["active_key"] is None
    assert resolved["active_source"] is None
    assert resolved["sai_api_key"] is None
    assert resolved["xai_api_key"] is None

    with pytest.raises(ValueError, match="API key is required"):
        hash_key("   ")
