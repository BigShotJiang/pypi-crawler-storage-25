from __future__ import annotations

import socket

import pytest

from roboto_sai_sdk import DEFAULT_PUBLIC_MODEL, PUBLIC_MODEL_NAMES, RobotoSAI, RuntimeProfile, get_runtime_profile


def test_roboto_sai_uses_default_model() -> None:
    client = RobotoSAI()

    assert client.model == DEFAULT_PUBLIC_MODEL
    assert client.get_current_profile() == get_runtime_profile(DEFAULT_PUBLIC_MODEL)


def test_invalid_model_raises_on_init() -> None:
    with pytest.raises(ValueError, match="Unknown public model"):
        RobotoSAI(model="not-a-real-model")


def test_no_network_or_key_resolution_happens_during_init(monkeypatch: pytest.MonkeyPatch) -> None:
    def fail(*args: object, **kwargs: object) -> None:
        raise AssertionError("unexpected side effect during client init")

    monkeypatch.setattr(socket, "create_connection", fail)
    monkeypatch.setattr("roboto_sai_sdk.client.resolve_api_keys", fail)

    client = RobotoSAI(
        model="roboto-sai-lightning",
        provider="xai",
        api_key="explicit-key",
        base_url="https://example.invalid",
    )

    assert client.model == "roboto-sai-lightning"
    assert client.provider == "xai"
    assert client.base_url == "https://example.invalid"


def test_get_current_profile_returns_the_expected_profile() -> None:
    client = RobotoSAI(model="roboto-sai-heavy")

    assert client.get_current_profile() == get_runtime_profile("roboto-sai-heavy")


def test_root_package_exports_the_public_contract_surface() -> None:
    profile = get_runtime_profile(DEFAULT_PUBLIC_MODEL)

    assert DEFAULT_PUBLIC_MODEL == "roboto-sai"
    assert "roboto-sai-cortex" in PUBLIC_MODEL_NAMES
    assert "roboto-sai-flex" in PUBLIC_MODEL_NAMES
    assert isinstance(profile, RuntimeProfile)
