"""Tests for RobotoSAI client behavior — dry_run and live (mocked) paths."""

from __future__ import annotations

import importlib
import warnings
from typing import Any, cast
from unittest.mock import MagicMock

import pytest

from roboto_sai_sdk import RobotoSAI
from roboto_sai_sdk.errors import RobotoSAIError
from roboto_sai_sdk.model_registry import (
    PUBLIC_RUNTIME_MAP,
    get_runtime_profile,
    normalize_public_model,
)
from roboto_sai_sdk.types import StreamEvent


# ── helpers ────────────────────────────────────────────────────────────────


def _chat_response(text: str, model: str = "grok-4-1-fast-reasoning") -> dict[str, Any]:
    """Build a minimal /chat/completions response body."""
    return {
        "id": "resp-test-id",
        "object": "chat.completion",
        "model": model,
        "choices": [{"message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }


# ── dry_run tests (no HTTP) ────────────────────────────────────────────────


def test_dry_run_returns_stub_with_subtitle_and_key_source(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SAI_API_KEY", "sai-env-key")
    client = RobotoSAI(model="roboto-sai", dry_run=True)

    result = cast(dict[str, object], client.send_message("hello world"))

    assert result["model"] == "roboto-sai"
    assert result["subtitle"] == "Core runtime"
    assert result["configured_api_key_source"] == "SAI_API_KEY"
    assert "[dry_run]" in cast(str, result["text"])
    assert result["response_id"] is None
    assert result["usage"] is None


@pytest.mark.parametrize(
    ("model_name", "expected_subtitle"),
    [
        ("roboto-sai", "Core runtime"),
        ("roboto-sai-lightning", "Lightning runtime"),
        ("roboto-sai-code-x", "Code generation runtime"),
        ("roboto-sai-heavy", "Function & tool runtime (pre-release)"),
        ("roboto-sai-flex", "Function & tool runtime (pre-release)"),
        ("roboto-sai-cortex", "Cortex runtime"),
    ],
)
def test_dry_run_different_models_produce_correct_subtitles(
    model_name: str, expected_subtitle: str
) -> None:
    client = RobotoSAI(model=model_name, dry_run=True)
    result = cast(dict[str, object], client.send_message("ping"))

    assert result["model"] == model_name
    assert result["subtitle"] == expected_subtitle


def test_dry_run_explicit_key_source_wins(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SAI_API_KEY", "env-key")
    client = RobotoSAI(model="roboto-sai-code-x", api_key="explicit-key", dry_run=True)

    result = cast(dict[str, object], client.send_message("implement this"))

    assert result["configured_api_key_source"] == "explicit"


def test_dry_run_env_fallback_key_source(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("SAI_API_KEY", raising=False)
    monkeypatch.setenv("XAI_API_KEY", "xai-key")
    client = RobotoSAI(model="roboto-sai-cortex", dry_run=True)

    result = cast(dict[str, object], client.send_message("research this"))

    assert result["configured_api_key_source"] == "XAI_API_KEY"


def test_dry_run_stream_yields_one_event() -> None:
    client = RobotoSAI(model="roboto-sai", dry_run=True)
    events = list(client.stream("hello"))

    assert len(events) == 1
    assert isinstance(events[0], StreamEvent)
    assert "[dry_run]" in events[0].data["choices"][0]["delta"]["content"]


# ── no API key raises RobotoSAIError ──────────────────────────────────────


def test_send_message_raises_without_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("SAI_API_KEY", raising=False)
    monkeypatch.delenv("XAI_API_KEY", raising=False)

    client = RobotoSAI(model="roboto-sai", api_key=None)

    with pytest.raises(RobotoSAIError, match="No API key configured"):
        client.send_message("hello")


# ── live (mocked HTTPClient) tests ─────────────────────────────────────────


def test_send_message_calls_http_and_returns_text(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XAI_API_KEY", "xai-test-key")

    mock_http = MagicMock()
    mock_http.request.return_value = _chat_response("Hello from Grok!")

    client = RobotoSAI(model="roboto-sai", api_key="xai-test-key")
    object.__setattr__(client, "_http", mock_http)

    result = cast(dict[str, object], client.send_message("hi there"))

    assert result["text"] == "Hello from Grok!"
    assert result["model"] == "roboto-sai"
    assert result["response_id"] == "resp-test-id"
    assert result["usage"] == {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}

    mock_http.request.assert_called_once()
    call_kwargs = mock_http.request.call_args
    body = call_kwargs.kwargs["json_body"]
    assert body["stream"] is False
    assert body["input"][-1]["role"] == "user"
    assert body["input"][-1]["content"] == "hi there"


def test_send_message_includes_system_prompt_when_provided(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("XAI_API_KEY", "xai-test-key")

    mock_http = MagicMock()
    mock_http.request.return_value = _chat_response("Understood.")

    client = RobotoSAI(model="roboto-sai-lightning", api_key="xai-test-key")
    object.__setattr__(client, "_http", mock_http)

    client.send_message("what time is it?", system="You are a helpful clock.")

    body = mock_http.request.call_args.kwargs["json_body"]
    assert body["input"][0]["role"] == "system"
    assert body["input"][0]["content"] == "You are a helpful clock."
    assert body["input"][1]["role"] == "user"


def test_send_message_passes_max_tokens_when_set(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XAI_API_KEY", "xai-test-key")

    mock_http = MagicMock()
    mock_http.request.return_value = _chat_response("short answer")

    client = RobotoSAI(model="roboto-sai", api_key="xai-test-key")
    object.__setattr__(client, "_http", mock_http)

    client.send_message("summarize this", max_tokens=256)

    body = mock_http.request.call_args.kwargs["json_body"]
    assert body["max_output_tokens"] == 256


def test_send_message_resolves_provider_model_from_registry(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("XAI_API_KEY", "xai-test-key")

    mock_http = MagicMock()
    mock_http.request.return_value = _chat_response("ok")

    client = RobotoSAI(model="roboto-sai-lightning", api_key="xai-test-key")
    object.__setattr__(client, "_http", mock_http)

    client.send_message("fast query")

    body = mock_http.request.call_args.kwargs["json_body"]
    # roboto-sai-lightning maps to the lowest-latency 4.1 non-reasoning worker.
    from roboto_sai_sdk.models import GROK_41_NON_REASONING

    assert body["model"] == GROK_41_NON_REASONING


def test_stream_calls_stream_sse_with_stream_true(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XAI_API_KEY", "xai-test-key")

    fake_event = StreamEvent(
        type="message",
        data={"choices": [{"delta": {"content": "Hello"}}]},
        raw="data: ...",
        id=None,
    )
    mock_http = MagicMock()
    mock_http.stream_sse.return_value = iter([fake_event])

    client = RobotoSAI(model="roboto-sai", api_key="xai-test-key")
    object.__setattr__(client, "_http", mock_http)

    events = list(client.stream("stream this"))

    assert len(events) == 1
    assert events[0].data["choices"][0]["delta"]["content"] == "Hello"

    body = mock_http.stream_sse.call_args.kwargs["json_body"]
    assert body["stream"] is True


def test_http_error_propagates_as_roboto_sai_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XAI_API_KEY", "xai-test-key")

    mock_http = MagicMock()
    mock_http.request.side_effect = RobotoSAIError(401, "Unauthorized")

    client = RobotoSAI(model="roboto-sai", api_key="xai-test-key")
    object.__setattr__(client, "_http", mock_http)

    with pytest.raises(RobotoSAIError, match="Unauthorized"):
        client.send_message("hello")


# ── get_current_profile ────────────────────────────────────────────────────


def test_get_current_profile_returns_runtime_profile() -> None:
    client = RobotoSAI(model="roboto-sai-heavy")
    profile = client.get_current_profile()

    assert profile.subtitle == "Function & tool runtime (pre-release)"
    assert profile.orchestrator is False
    assert profile.reasoning is True


def test_runtime_registry_exposes_explicit_heavy_flex_and_cortex_split() -> None:
    heavy = get_runtime_profile("roboto-sai-heavy")
    flex = get_runtime_profile("roboto-sai-flex")
    cortex = get_runtime_profile("roboto-sai-cortex")

    assert heavy.api_mode == "responses"
    assert heavy.provider_model == heavy.base_model == "grok-4.20-0309-reasoning"
    assert heavy.supports_previous_response_id is False
    assert heavy.mode == "single-agent"
    assert flex.api_mode == "responses"
    assert flex.provider_model == flex.base_model == "grok-4.20-0309-non-reasoning"
    assert flex.supports_previous_response_id is False
    assert flex.mode == "single-agent"
    assert cortex.api_mode == "responses"
    assert cortex.mode == "multi-agent"
    assert cortex.supports_builtin_tools is True
    assert cortex.supports_previous_response_id is True


def test_runtime_registry_exports_public_map_and_safe_normalizer() -> None:
    assert "roboto-sai" in PUBLIC_RUNTIME_MAP
    with pytest.raises(ValueError, match="Unknown public model 'unknown-model'."):
        normalize_public_model("unknown-model")


# ── deprecated wrapper compatibility ──────────────────────────────────────


def test_deprecated_wrapper_chat_returns_expected_shape(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SAI_API_KEY", "env-key")

    with warnings.catch_warnings(record=True):
        module = importlib.import_module("roboto_sai_sdk.roboto_sai_client")

    client = module.RobotoSAIClient(
        {"api_key": "explicit-key", "default_model": "roboto-sai-heavy"}
    )

    # Inject a mock HTTP client so no real network call is made
    mock_http = MagicMock()
    mock_http.request.return_value = _chat_response("All good.")
    object.__setattr__(client._client, "_http", mock_http)

    response = cast(dict[str, object], client.chat("review this system"))

    assert response["success"] is True
    assert response["model"] == "roboto-sai-heavy"
    assert response["subtitle"] == "Function & tool runtime (pre-release)"
    assert response["configured_api_key_source"] == "explicit"


def test_deprecated_wrapper_status_matches_profile() -> None:
    module = importlib.import_module("roboto_sai_sdk.roboto_sai_client")
    client = module.RobotoSAIClient({"default_model": "roboto-sai-cortex"})

    status = client.get_status()

    assert status["current_model"] == "roboto-sai-cortex"
    assert status["subtitle"] == "Cortex runtime"
