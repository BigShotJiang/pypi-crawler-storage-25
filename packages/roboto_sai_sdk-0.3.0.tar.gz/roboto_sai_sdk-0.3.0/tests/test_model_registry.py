from __future__ import annotations

import pytest

from roboto_sai_sdk.model_registry import (
    DEFAULT_PUBLIC_MODEL,
    PUBLIC_MODEL_NAMES,
    get_runtime_profile,
    normalize_public_model,
)
from roboto_sai_sdk.models import (
    GROK_41_NON_REASONING,
    GROK_41_REASONING,
    GROK_420_NON_REASONING,
    GROK_420_REASONING,
    GROK_420_MULTI_AGENT,
    GROK_CODE_FAST_1,
    GROK_2_AUDIO,
)


@pytest.mark.parametrize(
    (
        "model_name",
        "expected_base_model",
        "expected_subtitle",
        "expected_description",
    ),
    [
        (
            "roboto-sai",
            GROK_41_REASONING,
            "Core runtime",
            "General intelligence for everyday chat, planning, and execution. Default route: grok-4-1-fast-reasoning.",
        ),
        (
            "roboto-sai-lightning",
            GROK_41_NON_REASONING,
            "Lightning runtime",
            "Fast answers with low latency.",
        ),
        (
            "roboto-sai-code-x",
            GROK_CODE_FAST_1,
            "Code generation runtime",
            "Built for coding, debugging, architecture, and implementation.",
        ),
        (
            "roboto-sai-heavy",
            GROK_420_REASONING,
            "Function & tool runtime (pre-release)",
            "Function/tool execution with built-in tools. Pre-release \u2014 not yet available in production.",
        ),
        (
            "roboto-sai-flex",
            GROK_420_NON_REASONING,
            "Function & tool runtime (pre-release)",
            "Function/tool execution with built-in tools. Pre-release \u2014 not yet available in production.",
        ),
        (
            "roboto-sai-cortex",
            GROK_420_MULTI_AGENT,
            "Cortex runtime",
            "Deep multi-agent orchestration with optional search tools.",
        ),
        (
            "roboto-sai-rovox",
            GROK_2_AUDIO,
            "Voice runtime (Vox)",
            "Audio input/output. Free tier, no paywall.",
        ),
    ],
)
def test_all_public_models_resolve_with_expected_runtime_metadata(
    model_name: str,
    expected_base_model: str,
    expected_subtitle: str,
    expected_description: str,
) -> None:
    profile = get_runtime_profile(model_name)

    assert profile.public_name == model_name
    assert profile.base_model == expected_base_model
    assert profile.subtitle == expected_subtitle
    assert profile.description == expected_description


def test_public_model_names_are_exactly_the_frozen_seven_names() -> None:
    assert tuple(PUBLIC_MODEL_NAMES) == (
        "roboto-sai",
        "roboto-sai-lightning",
        "roboto-sai-code-x",
        "roboto-sai-heavy",
        "roboto-sai-flex",
        "roboto-sai-cortex",
        "roboto-sai-rovox",
    )


def test_unknown_model_raises_value_error_with_helpful_model_list() -> None:
    with pytest.raises(ValueError) as exc_info:
        get_runtime_profile("roboto-sai-unknown")

    message = str(exc_info.value)
    assert message == "Unknown public model 'roboto-sai-unknown'."


def test_default_public_model_fallback_accepts_falsey_inputs() -> None:
    default_profile = get_runtime_profile(DEFAULT_PUBLIC_MODEL)

    assert get_runtime_profile("") == default_profile
    assert get_runtime_profile(None) == default_profile 
    with pytest.raises(ValueError, match="Unknown public model 'unknown-model'."):
        normalize_public_model("unknown-model")
