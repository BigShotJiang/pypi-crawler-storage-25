# Roboto SAI SDK

Python SDK for the Roboto SAI platform.

The standalone SDK is the source of truth for:

- the seven public model names
- runtime profile metadata
- API key precedence
- the frozen runtime contract consumed by the CLI and Fuego

## Install

```bash
pip install roboto-sai-sdk
```

## Public Model Surface

- `roboto-sai`
- `roboto-sai-lightning`
- `roboto-sai-code-x`
- `roboto-sai-heavy`
- `roboto-sai-flex`
- `roboto-sai-cortex`
- `roboto-sai-rovox`

Legacy model aliases were removed in `0.2.0`; use only the canonical `roboto-sai-*` names.

## Current Client Usage

```python
from roboto_sai_sdk import DEFAULT_PUBLIC_MODEL, RobotoSAI

client = RobotoSAI(model=DEFAULT_PUBLIC_MODEL, api_key="roboto-sai-...")
result = client.send_message("Review this repository and propose the next refactor.")

print(result["model"])
print(result["subtitle"])
print(result["text"])
```

## Inspect Runtime Profiles

```python
from roboto_sai_sdk import DEFAULT_PUBLIC_MODEL, PUBLIC_MODEL_NAMES, get_runtime_profile, list_agents

print(DEFAULT_PUBLIC_MODEL)
print(sorted(PUBLIC_MODEL_NAMES))
print(get_runtime_profile("roboto-sai-lightning"))
print([agent.id for agent in list_agents()])
```

## Runtime Notes

The standalone client is currently an offline-first stub. `send_message()` returns a normalized payload shaped like:

- `model`
- `subtitle`
- `text`
- `configured_api_key_source`

The runtime profile contract is available through `get_runtime_profile(...)` and remains the integration boundary for downstream consumers.

## Worker Registry

The SDK agent registry currently exposes these worker agents:

- `code`
- `fast`
- `heavy`

`Roboto SAI` remains the root system identity, not a worker listing.

## Key Precedence

For configured API flows the SDK resolves keys in this order:

1. explicit `api_key=...`
2. `SAI_API_KEY`
3. `XAI_API_KEY`

## Low-Level REST Compatibility

Low-level HTTP compatibility layers still exist for direct API clients, but the public Phase 2 integration surface is:

- `RobotoSAI(...)`
- `send_message(...)`
- `get_current_profile()`
- `DEFAULT_PUBLIC_MODEL`
- `PUBLIC_MODEL_NAMES`
- `get_runtime_profile(...)`

```python
from roboto_sai_sdk import RobotoSAI, get_runtime_profile

client = RobotoSAI(api_key="roboto-sai-...")
profile = get_runtime_profile("roboto-sai-heavy")
response = client.responses.create(
    model=profile.provider_model,
    input="Summarize why the SDK is the source of truth.",
)

print(RobotoSAI.extract_output_text(response))
```

## Migration Notes

Old style:

- `RobotoSAIClient(...)` wrappers that assumed orchestration-first behavior
- direct entrypoint-first usage through deprecated compatibility layers
- stale six-model assumptions in downstream consumers

New style:

- `RobotoSAI(...)`
- `send_message(...)`
- `get_current_profile()`
- `DEFAULT_PUBLIC_MODEL`
- `get_runtime_profile(...)`
- `list_agents()`

The compatibility wrapper module remains importable during the transition sprint, but it now forwards to the current client surface instead of exposing the removed orchestration API.

## Release Notes

Version `0.2.0` removes legacy public model aliases. If you are updating old scripts, replace any `robotosai*` model names with the canonical `roboto-sai-*` names.
