"""MCP (Model Context Protocol) types used by legacy compatibility APIs."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class ToolCallStatus(Enum):
    """Status of an MCP tool call."""

    PENDING = "pending"
    APPROVED = "approved"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"


class RiskLevel(Enum):
    """Risk level for tool operations."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class ToolCall:
    """Represents an MCP tool call."""

    id: str
    tool_name: str
    parameters: dict[str, Any]
    status: ToolCallStatus = ToolCallStatus.PENDING
    risk_level: RiskLevel = RiskLevel.MEDIUM
    created_at: datetime | None = None
    approved_at: datetime | None = None
    completed_at: datetime | None = None
    result: Any | None = None
    error: str | None = None

    def __post_init__(self) -> None:
        if self.created_at is None:
            self.created_at = datetime.now()


@dataclass
class ApprovalRequest:
    """Represents a high-risk tool approval request."""

    tool_call: ToolCall
    reason: str
    risk_details: dict[str, Any]
    requested_by: str = "roboto_sai"
    created_at: datetime | None = None
    approved: bool | None = None
    approved_by: str | None = None
    approved_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.created_at is None:
            self.created_at = datetime.now()


@dataclass
class ChatEvent:
    """Represents a chat event with MCP context."""

    event_type: str
    content: Any
    timestamp: datetime | None = None
    metadata: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class PermissionCheck:
    """Result of a permission check."""

    allowed: bool
    risk_level: RiskLevel
    reason: str | None = None
    requires_approval: bool = False
    approval_triggers: list[str] | None = None


@dataclass
class McpTool:
    """MCP tool definition."""

    name: str
    description: str
    input_schema: dict[str, Any]
    risk_level: RiskLevel = RiskLevel.MEDIUM
    permission_requirements: dict[str, Any] | None = None


@dataclass
class McpServer:
    """MCP server configuration."""

    name: str
    tools: list[McpTool]
    base_url: str | None = None
    capabilities: list[str] | None = None


@dataclass
class McpSession:
    """MCP session state."""

    session_id: str
    connected_servers: list[str]
    active_tool_calls: list[ToolCall]
    pending_approvals: list[ApprovalRequest]
    created_at: datetime | None = None
    last_activity: datetime | None = None

    def __post_init__(self) -> None:
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_activity is None:
            self.last_activity = datetime.now()


@dataclass
class McpResponse:
    """Base MCP response."""

    success: bool
    data: Any | None = None
    error: str | None = None
    timestamp: datetime | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class ToolCallResponse:
    """Response to a tool call."""

    tool_call_id: str
    success: bool = True
    data: Any | None = None
    error: str | None = None
    execution_time: float | None = None
    approval_required: bool = False
    timestamp: datetime | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class StreamChatResponse:
    """Response to stream chat with MCP context."""

    chat_events: list[ChatEvent]
    success: bool = True
    data: Any | None = None
    error: str | None = None
    session_id: str | None = None
    timestamp: datetime | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class McpConfig:
    """MCP configuration for Roboto SAI."""

    enabled: bool = True
    os_agent_url: str = "http://localhost:5055"
    permission_model: str = "scoped_trust_model_b"
    auto_approve_low_risk: bool = True
    approval_timeout_seconds: int = 300
    servers: list[McpServer] | None = None

    def __post_init__(self) -> None:
        if self.servers is None:
            self.servers = self._get_default_servers()

    def _get_default_servers(self) -> list[McpServer]:
        """Get default MCP server configurations."""
        return [
            McpServer(
                name="filesystem",
                tools=[
                    McpTool(
                        name="readFile",
                        description="Read file contents",
                        input_schema={"type": "object", "properties": {"path": {"type": "string"}}},
                        risk_level=RiskLevel.LOW,
                    ),
                    McpTool(
                        name="writeFile",
                        description="Write file contents",
                        input_schema={
                            "type": "object",
                            "properties": {
                                "path": {"type": "string"},
                                "content": {"type": "string"},
                            },
                        },
                        risk_level=RiskLevel.MEDIUM,
                    ),
                    McpTool(
                        name="listDir",
                        description="List directory contents",
                        input_schema={"type": "object", "properties": {"path": {"type": "string"}}},
                        risk_level=RiskLevel.LOW,
                    ),
                ],
            ),
            McpServer(
                name="browser",
                tools=[
                    McpTool(
                        name="navigate",
                        description="Navigate to URL",
                        input_schema={"type": "object", "properties": {"url": {"type": "string"}}},
                        risk_level=RiskLevel.LOW,
                    ),
                    McpTool(
                        name="click",
                        description="Click element",
                        input_schema={
                            "type": "object",
                            "properties": {"selector": {"type": "string"}},
                        },
                        risk_level=RiskLevel.MEDIUM,
                    ),
                    McpTool(
                        name="scroll",
                        description="Scroll page",
                        input_schema={
                            "type": "object",
                            "properties": {"direction": {"type": "string"}},
                        },
                        risk_level=RiskLevel.LOW,
                    ),
                ],
            ),
            McpServer(
                name="twitter",
                tools=[
                    McpTool(
                        name="postTweet",
                        description="Post a tweet",
                        input_schema={"type": "object", "properties": {"text": {"type": "string"}}},
                        risk_level=RiskLevel.MEDIUM,
                    ),
                    McpTool(
                        name="getTimeline",
                        description="Get timeline",
                        input_schema={"type": "object", "properties": {}},
                        risk_level=RiskLevel.LOW,
                    ),
                    McpTool(
                        name="createAccount",
                        description="Create Twitter account",
                        input_schema={
                            "type": "object",
                            "properties": {
                                "username": {"type": "string"},
                                "email": {"type": "string"},
                            },
                        },
                        risk_level=RiskLevel.HIGH,
                    ),
                ],
            ),
            McpServer(
                name="email",
                tools=[
                    McpTool(
                        name="sendEmail",
                        description="Send an email",
                        input_schema={
                            "type": "object",
                            "properties": {
                                "to": {"type": "string"},
                                "subject": {"type": "string"},
                                "body": {"type": "string"},
                            },
                        },
                        risk_level=RiskLevel.MEDIUM,
                    )
                ],
            ),
        ]
