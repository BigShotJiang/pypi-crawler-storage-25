"""Small legacy utility helpers retained for backward compatibility."""

from __future__ import annotations

from .constants import EMOTIONS


def get_emotion_from_message(message: str) -> str | None:
    """Extract an emotion from a message using simple keyword matching."""
    message_lower = message.lower()

    for emotion, variations in EMOTIONS.items():
        for variation in variations:
            if variation.lower() in message_lower:
                return emotion

    return None
