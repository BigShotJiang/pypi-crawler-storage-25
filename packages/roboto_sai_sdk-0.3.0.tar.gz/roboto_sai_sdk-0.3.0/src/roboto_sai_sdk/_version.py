# version is kept in pyproject.toml and imported from package metadata
# this prevents duplication when bumping the release version.
# importlib.metadata is available in stdlib on py3.8+
from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("roboto-sai-sdk")
except Exception:  # pragma: no cover - fallback for local dev
    __version__ = "0.0.0"
