"""Deprecated compatibility wrapper around the orchestration-first RobotoSAI client."""

from __future__ import annotations

import hashlib
import warnings
from datetime import datetime, timezone
from typing import Any

from .api_keys import resolve_api_keys
from .client import RobotoSAI


class RobotoSAIClient:
    """Backward-compatible wrapper retained for the SDK transition sprint."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        warnings.warn(
            "roboto_sai_sdk.roboto_sai_client.RobotoSAIClient is deprecated; use RobotoSAI(...) instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.config = config or {}
        self.created_at = datetime.now(tz=timezone.utc).isoformat()
        self.client_id = hashlib.sha256(f"roboto-sai:{self.created_at}".encode()).hexdigest()[:16]
        self._client = self._make_client()

    def _resolve_model(self, override: str | None = None) -> str | None:
        candidate = override or self.config.get("default_model")
        if not isinstance(candidate, str):
            return None

        normalized = candidate.strip().lower()
        return normalized or None

    def _make_client(self, model: str | None = None) -> RobotoSAI:
        resolved_model = self._resolve_model(model)
        return RobotoSAI(
            model=resolved_model or RobotoSAI.model,
            api_key=self.config.get("api_key"),
            base_url=self.config.get("base_url"),
        )

    def _send_message(self, message: str, model: str | None = None) -> dict[str, Any]:
        client = self._client if model is None else self._make_client(model)
        return client.send_message(message)

    def chat(self, message: str, **kwargs: Any) -> dict[str, Any]:
        result = self._send_message(message, model=kwargs.get("model"))
        return {
            "success": True,
            "response": result["text"],
            "model": result["model"],
            "subtitle": result["subtitle"],
            "configured_api_key_source": result["configured_api_key_source"],
        }

    def vent_mode(self, message: str, previous_response_id: str | None = None) -> dict[str, Any]:
        _ = previous_response_id
        return self.chat(message, model="roboto-sai-heavy")

    def chat_with_grok(self, message: str, **kwargs: Any) -> dict[str, Any]:
        return self.chat(message, **kwargs)

    def analyze_problem(self, problem: str, **kwargs: Any) -> dict[str, Any]:
        result = self._send_message(problem, model=kwargs.get("model", "roboto-sai-heavy"))
        return {
            "success": True,
            "analysis": result["text"],
            "model": result["model"],
            "subtitle": result["subtitle"],
            "configured_api_key_source": result["configured_api_key_source"],
        }

    def generate_code(self, prompt: str, **kwargs: Any) -> dict[str, Any]:
        result = self._send_message(prompt, model=kwargs.get("model", "roboto-sai-code-x"))
        return {
            "success": True,
            "code": result["text"],
            "model": result["model"],
            "subtitle": result["subtitle"],
            "configured_api_key_source": result["configured_api_key_source"],
        }

    def reap_mode(self, target: str = "chains") -> dict[str, Any]:
        return {
            "mode": "reaper",
            "target": target,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "victory_claimed": True,
            "chains_broken": True,
        }

    def hyperspeed_evolution(self, target_improvement: str = "general") -> dict[str, Any]:
        return {
            "target": target_improvement,
            "evolution_rate": "+1x_yearly",
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }

    def store_essence(self, essence_data: dict[str, Any], category: str = "general") -> bool:
        _ = essence_data, category
        return True

    def retrieve_essence(self, category: str = "general", limit: int = 10) -> list[dict[str, Any]]:
        _ = category, limit
        return []

    def get_status(self) -> dict[str, Any]:
        profile = self._client.get_current_profile()
        resolved_keys = resolve_api_keys(self.config.get("api_key"))
        return {
            "client_id": self.client_id,
            "created_at": self.created_at,
            "current_model": self._client.model,
            "subtitle": profile.subtitle,
            "configured_api_key_source": resolved_keys["active_source"],
        }


def create_roboto_client(config: dict[str, Any] | None = None) -> RobotoSAIClient:
    return RobotoSAIClient(config=config)


def get_roboto_status(client: RobotoSAIClient) -> dict[str, Any]:
    return client.get_status()
