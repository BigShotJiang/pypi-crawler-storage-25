"""Worker agent registry for the Roboto SAI SDK."""

from __future__ import annotations

from typing import Final

from .agent_types import AgentManifest

ORCHESTRATOR_IDENTITY: Final[AgentManifest] = AgentManifest(
    id="roboto-sai",
    display_name="Roboto SAI",
    role="orchestrator",
    specialization="Root system orchestration and runtime selection.",
    model_preference="roboto-sai",
    routing_priority=1000,
    memory_scope="system",
    tool_access=("routing", "coordination"),
    output_style="orchestrated",
)

_AGENTS: dict[str, AgentManifest] = {}


def register_agent(agent: AgentManifest) -> AgentManifest:
    """Register a worker agent by normalized identifier."""

    agent_id = agent.id.strip().lower()
    if agent_id == ORCHESTRATOR_IDENTITY.id:
        raise ValueError("Roboto SAI is the orchestrator identity and cannot be registered as a worker agent.")
    if agent.role.strip().lower() != "worker":
        raise ValueError(f"Only worker agents can be registered. Received role '{agent.role}'.")
    _AGENTS[agent_id] = agent
    return agent


def get_agent(agent_id: str) -> AgentManifest | None:
    """Return a registered worker agent by identifier."""

    return _AGENTS.get((agent_id or "").strip().lower())


def list_agents() -> tuple[AgentManifest, ...]:
    """Return all registered worker agents in deterministic priority order."""

    return tuple(sorted(_AGENTS.values(), key=lambda agent: (-agent.routing_priority, agent.id)))


register_agent(
    AgentManifest(
        id="code",
        display_name="Code X",
        role="worker",
        specialization="Code generation, debugging, and architecture.",
        model_preference="roboto-sai-code-x",
        routing_priority=300,
        memory_scope="workspace",
        tool_access=("analysis", "code_generation"),
        output_style="implementation",
    )
)
register_agent(
    AgentManifest(
        id="fast",
        display_name="Lightning",
        role="worker",
        specialization="Fast task execution and concise synthesis.",
        model_preference="roboto-sai-lightning",
        routing_priority=200,
        memory_scope="session",
        tool_access=("analysis",),
        output_style="concise",
    )
)
register_agent(
    AgentManifest(
        id="heavy",
        display_name="Heavy",
        role="worker",
        specialization="Deep reasoning, planning, and synthesis.",
        model_preference="roboto-sai-heavy",
        routing_priority=400,
        memory_scope="workspace",
        tool_access=("analysis", "routing", "synthesis"),
        output_style="comprehensive",
    )
)
