"""Deprecated compatibility re-exports for legacy model registry imports."""

from __future__ import annotations

import warnings

from ..model_registry import PUBLIC_RUNTIME_MAP

GOD_MAP = PUBLIC_RUNTIME_MAP

_EXPORTS = {
    "DEFAULT_PUBLIC_MODEL",
    "GOD_MAP",
    "PUBLIC_MODEL_NAMES",
    "PUBLIC_RUNTIME_MAP",
    "RuntimeProfile",
    "get_runtime_profile",
    "normalize_public_model",
}

__all__ = list(_EXPORTS)


def __getattr__(name: str):
    if name in _EXPORTS:
        warnings.warn(
            f"roboto_sai_sdk.models.registry.{name} is deprecated; "
            "import from roboto_sai_sdk.model_registry instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
