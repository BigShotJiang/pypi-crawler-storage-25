"""API key helpers for the Roboto SAI SDK."""

from __future__ import annotations

import hashlib
import os
from collections.abc import Mapping
from typing import Final, TypedDict

SAI_API_KEY: Final[str] = "SAI_API_KEY"
XAI_API_KEY: Final[str] = "XAI_API_KEY"


class ResolvedAPIKeys(TypedDict):
    """Resolved API key state without performing any network calls."""

    active_key: str | None
    active_source: str | None
    sai_api_key: str | None
    xai_api_key: str | None


def _normalize(value: str | None) -> str | None:
    normalized = (value or "").strip()
    return normalized or None


def _lookup(environment: Mapping[str, str] | None, name: str) -> str | None:
    source = environment if environment is not None else os.environ
    return _normalize(source.get(name))


def get_sai_api_key(environment: Mapping[str, str] | None = None) -> str | None:
    """Return ``SAI_API_KEY`` when present."""

    return _lookup(environment, SAI_API_KEY)


def get_xai_api_key(environment: Mapping[str, str] | None = None) -> str | None:
    """Return ``XAI_API_KEY`` when present."""

    return _lookup(environment, XAI_API_KEY)


def hash_key(key: str) -> str:
    """Hash an API key for logging and debugging."""
    normalized = _normalize(key)
    if not normalized:
        raise ValueError("API key is required")
    return hashlib.sha256(normalized.encode()).hexdigest()


def resolve_xai_api_key(
    explicit_api_key: str | None = None,
    environment: Mapping[str, str] | None = None,
) -> str | None:
    """Resolve the outbound xAI provider key.

    Roboto-issued SAI keys are for platform auth and must not be forwarded to
    xAI. Only an explicit override or ``XAI_API_KEY`` is valid for upstream
    xAI requests.
    """

    explicit = _normalize(explicit_api_key)
    if explicit:
        return explicit
    return get_xai_api_key(environment)


def resolve_api_keys(
    explicit_api_key: str | None = None,
    environment: Mapping[str, str] | None = None,
) -> ResolvedAPIKeys:
    """Resolve keys using explicit, SAI, then xAI precedence."""

    explicit = _normalize(explicit_api_key)
    sai_api_key = get_sai_api_key(environment)
    xai_api_key = get_xai_api_key(environment)

    if explicit:
        active_key = explicit
        active_source = "explicit"
    elif sai_api_key:
        active_key = sai_api_key
        active_source = SAI_API_KEY
    else:
        active_key = xai_api_key
        active_source = XAI_API_KEY if xai_api_key else None

    return {
        "active_key": active_key,
        "active_source": active_source,
        "sai_api_key": sai_api_key,
        "xai_api_key": xai_api_key,
    }


def hash_key(key: str) -> str:
    """Hash an API key for logging and debugging."""
    normalized = _normalize(key)
    if not normalized:
        raise ValueError("API key is required")
    return hashlib.sha256(normalized.encode()).hexdigest()
