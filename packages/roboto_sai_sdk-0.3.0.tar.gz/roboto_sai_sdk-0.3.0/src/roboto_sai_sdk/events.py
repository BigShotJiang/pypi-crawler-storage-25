"""Typed orchestration event contracts for the Roboto SAI SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal

EventType = Literal[
    "message_received",
    "message_sent",
    "tool_call_requested",
    "approval_requested",
    "approval_granted",
    "approval_denied",
    "error",
    "state_changed",
]


@dataclass(frozen=True)
class EventEnvelope:
    type: EventType
    payload: dict[str, Any]
    agent_id: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
