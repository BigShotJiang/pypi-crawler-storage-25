from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class StreamEvent:
    """
    Normalized Server-Sent Event (SSE) wrapper.

    - type: SSE `event:` value if provided, otherwise "message"
    - data: parsed JSON if possible, else raw string
    - raw: the raw SSE block text
    - id: SSE `id:` if present
    - ts: event timestamp (UTC)
    """

    type: str
    data: Any
    raw: str
    id: str | None = None
    ts: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
