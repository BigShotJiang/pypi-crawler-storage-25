"""Roboto SAI client — orchestration-first with stable runtime contracts."""

from __future__ import annotations

import os
from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any, TypedDict

from ._version import __version__
from .api_keys import resolve_api_keys
from .errors import RobotoSAIError
from .http import HTTPClient
from .model_registry import DEFAULT_PUBLIC_MODEL, RuntimeProfile, get_runtime_profile
from .models import GROK_FALLBACK
from .types import StreamEvent

_DEFAULT_BASE_URL = "https://api.x.ai/v1"
_RESPONSES_PATH = "/responses"


class SendMessageResult(TypedDict, total=False):
    """Response returned by :meth:`RobotoSAI.send_message`.

    All keys are always present in practice; ``total=False`` avoids
    TypedDict strictness conflicts for callers on older type-checkers.
    """

    model: str
    subtitle: str
    text: str
    configured_api_key_source: str | None
    response_id: str | None
    usage: dict[str, int] | None


# ── Module-level helpers ───────────────────────────────────────────────────


def _build_user_agent() -> str:
    return f"roboto-sai-sdk/{__version__} httpx"


def _extract_text(data: dict[str, Any]) -> str:
    """Pull assistant content from a /v1/responses response dict.

    Handles both the shorthand ``output_text`` field and the standard
    ``output[*].content[*].text`` array. Falls back to the legacy
    ``choices[*].message.content`` shape for backward compatibility.
    """
    # /v1/responses shorthand
    output_text = data.get("output_text")
    if isinstance(output_text, str) and output_text.strip():
        return output_text

    # /v1/responses standard output array
    output = data.get("output")
    if isinstance(output, list):
        for item in output:
            if not isinstance(item, dict):
                continue
            content = item.get("content")
            if not isinstance(content, list):
                continue
            for part in content:
                if not isinstance(part, dict):
                    continue
                text = part.get("text")
                if isinstance(text, str) and text.strip():
                    return text

    # Legacy /v1/chat/completions fallback (backward compat / dry_run mocks)
    choices = data.get("choices") or []
    if choices:
        return (choices[0].get("message") or {}).get("content") or ""
    return ""


def _extract_usage(data: dict[str, Any]) -> dict[str, int] | None:
    """Extract token usage from a /v1/responses or /v1/chat/completions response dict."""
    usage = data.get("usage")
    if not isinstance(usage, dict):
        return None
    return {k: int(v) for k, v in usage.items() if isinstance(v, (int, float))}


def _extract_stream_delta(event_data: Any) -> str:
    """Pull the incremental text delta from a streaming SSE data payload.

    Handles both /v1/responses and /v1/chat/completions streaming formats:
    - /v1/responses:       ``{"type": "response.output_text.delta", "delta": "..."}
    - /v1/chat/completions: ``{"choices": [{"delta": {"content": "..."}}]}``
    """
    if not isinstance(event_data, dict):
        return ""
    # /v1/responses streaming delta
    if event_data.get("type") == "response.output_text.delta":
        return event_data.get("delta") or ""
    # /v1/chat/completions streaming delta (also used by dry_run stubs)
    choices = event_data.get("choices") or []
    if not choices:
        return ""
    delta = choices[0].get("delta") or {}
    return delta.get("content") or ""


# ── Client ─────────────────────────────────────────────────────────────────


@dataclass(slots=True)
class RobotoSAI:
    """Roboto SAI client — resolves public model names and calls the configured API backend.

    Parameters
    ----------
    model:
        One of the public Roboto SAI model names (e.g. ``"roboto-sai"``,
        ``"roboto-sai-lightning"``).  Defaults to ``"roboto-sai"``.
    api_key:
        API key override. Falls back to the ``SAI_API_KEY`` → ``XAI_API_KEY``
        environment variables when *None*.
    base_url:
        Override the API base URL. Defaults to ``https://api.x.ai/v1``.
        Also reads ``XAI_API_BASE_URL`` when *None*.
    dry_run:
        When *True*, no HTTP call is made and an offline stub is returned.
        Useful for testing the model/key resolution path without API credit.
    """

    model: str = DEFAULT_PUBLIC_MODEL
    provider: str = "xai"
    api_key: str | None = None
    base_url: str | None = None
    dry_run: bool = False
    _current_profile: RuntimeProfile = field(init=False, repr=False)
    _http: HTTPClient | None = field(init=False, repr=False, default=None)

    def __post_init__(self) -> None:
        self.model = self.model.strip().lower()
        self.provider = self.provider.strip().lower()
        if self.provider != "xai":
            raise ValueError("Only provider='xai' is currently supported.")
        self._current_profile = get_runtime_profile(self.model)
        self.model = self._current_profile.public_name

    # ── Internal helpers ───────────────────────────────────────────────────

    def _resolved_base_url(self) -> str:
        if self.base_url:
            return self.base_url.rstrip("/")
        return (os.getenv("XAI_API_BASE_URL") or _DEFAULT_BASE_URL).rstrip("/")

    def _resolved_api_key(self) -> str | None:
        return resolve_api_keys(self.api_key)["active_key"]

    def _get_http(self) -> HTTPClient:
        """Lazily build and cache the HTTPClient."""
        if self._http is not None:
            return self._http
        api_key = self._resolved_api_key()
        if not api_key:
            raise RobotoSAIError(
                0,
                "No API key configured. Set SAI_API_KEY or "
                "XAI_API_KEY in the environment, or pass api_key= to RobotoSAI().",
            )
        object.__setattr__(
            self,
            "_http",
            HTTPClient(
                base_url=self._resolved_base_url(),
                api_key=api_key,
                user_agent=_build_user_agent(),
            ),
        )
        return self._http  # type: ignore[return-value]

    def _provider_model(self) -> str:
        """Resolve the xAI provider model ID for this client's public model."""
        return self._current_profile.base_model or GROK_FALLBACK

    def _build_messages(
        self, message: str, system: str | None
    ) -> list[dict[str, str]]:
        msgs: list[dict[str, str]] = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": message.strip()})
        return msgs

    # ── Public API ─────────────────────────────────────────────────────────

    def get_current_profile(self) -> RuntimeProfile:
        """Return the currently resolved :class:`RuntimeProfile`."""
        return self._current_profile

    def send_message(
        self,
        message: str,
        *,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> SendMessageResult:
        """Send *message* to the xAI API and return the assistant reply.

        Parameters
        ----------
        message:
            The user turn text.
        system:
            Optional system prompt prepended before the user message.
        temperature:
            Sampling temperature (0.0–2.0).  Defaults to 0.7.
        max_tokens:
            Hard cap on response tokens.  When *None* the server default
            applies.

        Returns
        -------
        SendMessageResult
            A typed dict containing ``text``, ``model``, ``subtitle``,
            ``configured_api_key_source``, ``response_id``, and ``usage``.

        Raises
        ------
        RobotoSAIError
            On any API or network error.
        """
        resolved_keys = resolve_api_keys(self.api_key)

        # ── dry_run: return offline stub without any HTTP call ─────────────
        if self.dry_run:
            return {
                "model": self.model,
                "subtitle": self._current_profile.subtitle,
                "text": (
                    f"[dry_run] {self._current_profile.subtitle}: "
                    f"no network call made. message={message!r}"
                ),
                "configured_api_key_source": resolved_keys["active_source"],
                "response_id": None,
                "usage": None,
            }

        # ── live call ──────────────────────────────────────────────────────
        http = self._get_http()
        provider_model = self._provider_model()

        if self._current_profile.api_mode == "audio":
            raise NotImplementedError(
                f"Model '{self.model}' uses the realtime WebSocket API "
                "(wss://api.x.ai/v1/realtime) and is not supported by send_message(). "
                "Use the voice/audio integration layer instead."
            )

        body: dict[str, Any] = {
            "model": provider_model,
            "input": self._build_messages(message, system),
            "temperature": temperature,
            "stream": False,
        }
        if max_tokens is not None:
            body["max_output_tokens"] = max_tokens

        data: dict[str, Any] = http.request("POST", _RESPONSES_PATH, json_body=body)

        text = _extract_text(data)
        usage = _extract_usage(data)
        response_id: str | None = data.get("id")

        return {
            "model": self.model,
            "subtitle": self._current_profile.subtitle,
            "text": text,
            "configured_api_key_source": resolved_keys["active_source"],
            "response_id": response_id,
            "usage": usage,
        }

    def stream(
        self,
        message: str,
        *,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> Iterator[StreamEvent]:
        """Stream the assistant reply token-by-token as :class:`StreamEvent` objects.

        Each event's ``data`` field is the raw SSE payload dict.  Use
        :func:`_extract_stream_delta` to pull the incremental text from
        each event, or iterate and collect yourself::

            text = ""
            for evt in client.stream("hello"):
                text += _extract_stream_delta(evt.data)

        Parameters
        ----------
        message:
            The user turn text.
        system:
            Optional system prompt.
        temperature:
            Sampling temperature (0.0–2.0).
        max_tokens:
            Hard cap on response tokens.

        Yields
        ------
        StreamEvent
            One event per SSE chunk from the API.

        Raises
        ------
        RobotoSAIError
            On any API or network error.
        """
        if self.dry_run:
            from .types import StreamEvent as _SE  # local import avoids circular ref at module top
            yield _SE(
                type="message",
                data={"choices": [{"delta": {"content": f"[dry_run] {message}"}}]},
                raw="[dry_run]",
                id=None,
            )
            return

        if self._current_profile.api_mode == "audio":
            raise NotImplementedError(
                f"Model '{self.model}' uses the realtime WebSocket API "
                "(wss://api.x.ai/v1/realtime) and is not supported by stream(). "
                "Use the voice/audio integration layer instead."
            )

        http = self._get_http()
        provider_model = self._provider_model()

        body: dict[str, Any] = {
            "model": provider_model,
            "input": self._build_messages(message, system),
            "temperature": temperature,
            "stream": True,
        }
        if max_tokens is not None:
            body["max_output_tokens"] = max_tokens

        yield from http.stream_sse("POST", _RESPONSES_PATH, json_body=body)
