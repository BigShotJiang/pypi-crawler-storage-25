"""Internal helpers for exporting the frozen public runtime contract."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .agent_registry import list_agents
from .model_registry import PUBLIC_MODEL_NAMES, PUBLIC_RUNTIME_MAP


def _json_safe(value: Any) -> Any:
    if isinstance(value, tuple):
        return [_json_safe(item) for item in value]
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    return value


def build_public_runtime_contract() -> dict[str, Any]:
    return _json_safe(
        {
            "public_model_names": list(PUBLIC_MODEL_NAMES),
            "runtime_profiles": {
                name: asdict(profile) for name, profile in PUBLIC_RUNTIME_MAP.items()
            },
            "default_worker_ids": [agent.id for agent in sorted(list_agents(), key=lambda item: item.id)],
        }
    )
