"""
roboto_sai_sdk.memory
~~~~~~~~~~~~~~~~~~~~~
Lightweight local conversation memory backed by a JSON file.

This module is intentionally dependency-free and suitable for lightweight
CLI tools, demos, and unit tests that need a simple memory context.
For production-scale memory or vector search, use an external store and
pass the retrieved context directly in your API calls.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

_DEFAULT_FILE = "roboto_memory.json"
_DEFAULT_MAX = 10_000


class ConversationMemory:
    """
    Append-only conversation memory persisted to a local JSON file.

    Each entry records a user/assistant exchange along with a timestamp,
    optional emotion tag, and optional user identifier.

    Example::

        from roboto_sai_sdk.memory import ConversationMemory

        mem = ConversationMemory()
        mem.add("What is 2+2?", "4", emotion="neutral")
        recent = mem.recent(top_k=3)
    """

    def __init__(
        self,
        memory_file: str = _DEFAULT_FILE,
        max_entries: int = _DEFAULT_MAX,
    ) -> None:
        resolved = os.path.realpath(memory_file)
        cwd = os.path.realpath(os.getcwd())
        if not resolved.startswith(cwd + os.sep) and resolved != cwd:
            raise ValueError(
                f"memory_file must resolve inside the working directory ({cwd}); "
                f"got {resolved!r}"
            )
        self.memory_file = memory_file
        self.max_entries = max_entries
        self._entries: list[dict] = []
        self._load()

    # ── Public API ──────────────────────────────────────────────────────────

    def add(
        self,
        user_input: str,
        assistant_response: str,
        *,
        emotion: str = "neutral",
        user_name: str | None = None,
    ) -> None:
        """Append a conversation turn and persist to disk."""
        entry = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "user_input": user_input,
            "assistant_response": assistant_response,
            "emotion": emotion,
            "user_name": user_name or "user",
        }
        self._entries.append(entry)
        self._trim()
        self._save()

    # Backward-compatible alias used by older app code
    def add_episodic_memory(
        self,
        user_input: str,
        roboto_response: str,
        emotion: str,
        user_name: str | None = None,
    ) -> None:
        """Deprecated alias for :meth:`add`. Prefer ``add()`` in new code."""
        import warnings
        warnings.warn(
            "add_episodic_memory() is deprecated; use add() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.add(user_input, roboto_response, emotion=emotion, user_name=user_name)

    def recent(self, top_k: int = 5) -> list[str]:
        """
        Return the ``top_k`` most recent assistant responses as plain strings.

        Falls back to ``user_input`` when the assistant response is empty.
        """
        if not self._entries:
            return []
        entries = self._entries[-max(top_k, 1) :]
        results: list[str] = []
        for item in reversed(entries):
            snippet = (item.get("assistant_response") or "").strip()
            if not snippet:
                snippet = (item.get("user_input") or "").strip()
            if snippet:
                results.append(snippet)
        return results[:top_k]

    # Backward-compatible alias
    def retrieve_relevant_memories(self, query: str, top_k: int = 5) -> list[str]:
        """Deprecated alias for :meth:`recent`. Prefer ``recent()`` in new code."""
        import warnings
        warnings.warn(
            "retrieve_relevant_memories() is deprecated; use recent() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.recent(top_k=top_k)

    def clear(self) -> None:
        """Remove all in-memory entries and delete the backing file if it exists."""
        self._entries = []
        if self.memory_file and os.path.exists(self.memory_file):
            try:
                os.remove(self.memory_file)
            except OSError as exc:
                logger.warning("Could not remove memory file: %s", exc)

    # ── Private helpers ─────────────────────────────────────────────────────

    def _trim(self) -> None:
        if len(self._entries) > self.max_entries:
            self._entries = self._entries[-self.max_entries :]

    def _load(self) -> None:
        if not self.memory_file or not os.path.exists(self.memory_file):
            return
        try:
            with open(self.memory_file, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, list):
                self._entries = data[-self.max_entries :]
        except Exception as exc:
            logger.warning("Failed to load memory file '%s': %s", self.memory_file, exc)

    def _save(self) -> None:
        if not self.memory_file:
            return
        try:
            with open(self.memory_file, "w", encoding="utf-8") as fh:
                json.dump(self._entries[-self.max_entries :], fh, ensure_ascii=False, indent=2)
        except Exception as exc:
            logger.warning("Failed to save memory file '%s': %s", self.memory_file, exc)


# Backward-compatibility alias — existing code using QuantumEnhancedMemorySystem keeps working
def __getattr__(name: str):
    if name == "QuantumEnhancedMemorySystem":
        import warnings
        warnings.warn(
            "QuantumEnhancedMemorySystem is deprecated; use ConversationMemory instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return ConversationMemory
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
