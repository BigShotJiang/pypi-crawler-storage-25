from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class RobotoSAIError(Exception):
    """
    Raised for any API or transport error produced by the SDK.

    Attributes:
        status_code: HTTP status code (0 for network / transport errors).
        message:     Human-readable error description.
        request_id:  Server-returned request identifier, when available.
        payload:     Raw error body returned by the API, when available.
    """

    status_code: int
    message: str
    request_id: str | None = None
    payload: Any | None = None

    def __str__(self) -> str:
        rid = f" request_id={self.request_id}" if self.request_id else ""
        return f"RobotoSAIError(status={self.status_code}{rid} message={self.message})"
