from __future__ import annotations

import json
import os
import random
import time
from collections.abc import Iterator
from typing import Any

import httpx

from .errors import RobotoSAIError
from .types import StreamEvent


def _default_timeout() -> float:
    try:
        value = float(os.getenv("ROBOTO_SAI_TIMEOUT", "60"))
        return max(5.0, min(value, 300.0))
    except Exception:
        return 60.0


_RETRYABLE_STATUS: frozenset[int] = frozenset({408, 409, 429, 500, 502, 503, 504})

_MAX_SSE_BUFFER = 10 * 1024 * 1024  # 10MB
_MAX_RETRY_AFTER = 60.0


class HTTPClient:
    """
    Lightweight HTTP client with:
    - retries + exponential backoff + jitter
    - Retry-After support
    - SSE streaming parser
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        user_agent: str = "roboto-sai-sdk",
        timeout: float | None = None,
        max_retries: int = 3,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        if not self.base_url.startswith("https://"):
            raise ValueError("base_url must use HTTPS scheme for security")
        self.api_key = api_key
        if "\n" in self.api_key or "\r" in self.api_key:
            raise ValueError("api_key must not contain newline or carriage return characters")
        self.user_agent = user_agent
        self.timeout = timeout if timeout is not None else _default_timeout()
        self.max_retries = max_retries

        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "User-Agent": self.user_agent,
            },
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        last_err: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                r = self._client.request(
                    method=method,
                    url=path,
                    json=json_body,
                    params=params,
                    headers={"Content-Type": "application/json"},
                )

                request_id = r.headers.get("x-request-id") or r.headers.get("request-id")

                if 200 <= r.status_code < 300:
                    if r.content:
                        return r.json()
                    return None

                if r.status_code in _RETRYABLE_STATUS and attempt < self.max_retries:
                    time.sleep(self._backoff_s(attempt, r.headers))
                    continue

                payload: Any
                try:
                    payload = r.json()
                except Exception:
                    payload = {"text": r.text}

                msg = _extract_error_msg(payload) or f"HTTP {r.status_code}"
                raise RobotoSAIError(r.status_code, msg, request_id=request_id, payload=payload)

            except RobotoSAIError:
                raise
            except httpx.RequestError as e:
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(self._jitter_s(attempt))
                    continue
                raise RobotoSAIError(0, f"Network error: {e}") from e
            except Exception as e:
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(self._jitter_s(attempt))
                    continue
                raise RobotoSAIError(0, f"Unexpected error: {e}") from e

        raise RobotoSAIError(0, f"Request failed after {self.max_retries} retries: {last_err}")

    def stream_sse(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Iterator[StreamEvent]:
        """
        Streams SSE events as StreamEvent objects.
        Works with OpenAI-compatible streaming for:
        - /responses (stream=True in body)
        - /chat/completions (stream=True in body)
        """
        last_err: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                with self._client.stream(
                    method=method,
                    url=path,
                    json=json_body,
                    params=params,
                    headers={
                        "Accept": "text/event-stream",
                        "Content-Type": "application/json",
                    },
                ) as r:
                    request_id = r.headers.get("x-request-id") or r.headers.get("request-id")

                    if not (200 <= r.status_code < 300):
                        if r.status_code in _RETRYABLE_STATUS and attempt < self.max_retries:
                            time.sleep(self._backoff_s(attempt, r.headers))
                            continue

                        body = r.read()
                        try:
                            payload = json.loads(body.decode("utf-8", "replace")) if body else None
                        except Exception:
                            payload = {"text": body.decode("utf-8", "replace")}

                        msg = _extract_error_msg(payload) or f"HTTP {r.status_code}"
                        raise RobotoSAIError(
                            r.status_code, msg, request_id=request_id, payload=payload
                        )

                    yield from self._iter_sse(r.iter_bytes())
                    return  # clean exit

            except RobotoSAIError:
                raise
            except httpx.RequestError as e:
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(self._jitter_s(attempt))
                    continue
                raise RobotoSAIError(0, f"Network error: {e}") from e
            except Exception as e:
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(self._jitter_s(attempt))
                    continue
                raise RobotoSAIError(0, f"Unexpected error: {e}") from e

        raise RobotoSAIError(0, f"Stream failed after {self.max_retries} retries: {last_err}")

    @staticmethod
    def _backoff_s(attempt: int, headers: httpx.Headers) -> float:
        """Return sleep duration, honouring Retry-After when present."""
        retry_after = headers.get("retry-after")
        if retry_after:
            try:
                return min(float(retry_after), _MAX_RETRY_AFTER)
            except Exception:
                pass
        return HTTPClient._jitter_s(attempt)

    @staticmethod
    def _jitter_s(attempt: int) -> float:
        return min(8.0, 2.0**attempt) + random.random()

    @staticmethod
    def _iter_sse(byte_iter: Iterator[bytes]) -> Iterator[StreamEvent]:
        buffer = b""

        for chunk in byte_iter:
            if not chunk:
                continue
            buffer += chunk

            if len(buffer) > _MAX_SSE_BUFFER:
                raise RobotoSAIError(0, "SSE buffer overflow: server sent more than 10 MB without a complete event")

            while b"\n\n" in buffer:
                block, buffer = buffer.split(b"\n\n", 1)
                text = block.decode("utf-8", "replace").strip()
                if not text:
                    continue

                event_type = "message"
                event_id: str | None = None
                data_lines = []

                for line in text.splitlines():
                    line = line.strip()
                    if not line or line.startswith(":"):
                        continue
                    if line.startswith("event:"):
                        event_type = line.split(":", 1)[1].strip() or "message"
                    elif line.startswith("id:"):
                        event_id = line.split(":", 1)[1].strip() or None
                    elif line.startswith("data:"):
                        data_lines.append(line.split(":", 1)[1].lstrip())

                data_raw = "\n".join(data_lines).strip()

                if data_raw == "[DONE]":
                    return

                # Parse JSON if possible
                data: Any = data_raw
                if data_raw:
                    try:
                        data = json.loads(data_raw)
                    except Exception:
                        data = data_raw

                yield StreamEvent(type=event_type, data=data, raw=text, id=event_id)


# ── Module-level helpers ────────────────────────────────────────────────────


def _extract_error_msg(payload: Any) -> str | None:
    if not isinstance(payload, dict):
        return None
    return (payload.get("error") or {}).get("message") or payload.get("message")
