"""Provider model constants for the Roboto SAI SDK.

These are the canonical provider model identifiers verified against the live
API model list. Update this file whenever the upstream model catalog changes.

Context window and pricing (as of 2026-03-18):
  grok-4.20-0309-reasoning             2M ctx  $2.00 in / $6.00 out
  grok-4.20-0309-non-reasoning         2M ctx  $2.00 in / $6.00 out
  grok-4.20-multi-agent-0309           2M ctx  $2.00 in / $6.00 out
  grok-4-1-fast-reasoning              2M ctx  $0.20 in / $0.50 out
  grok-4-1-fast-non-reasoning          2M ctx  $0.20 in / $0.50 out
  grok-code-fast-1                   256K ctx  $0.20 in / $1.50 out
"""

from __future__ import annotations

# ── 4.20 premium tier ($2.00 in / $6.00 out, 2M context) ──────────────────

GROK_420_REASONING = "grok-4.20-0309-reasoning"
"""Premium reasoning model — highest quality, full thinking trace."""

GROK_420_NON_REASONING = "grok-4.20-0309-non-reasoning"
"""Premium non-reasoning model — highest quality, lower latency."""

GROK_420_MULTI_AGENT = "grok-4.20-multi-agent-0309"
"""Premium multi-agent supervisor model — orchestrates worker agents."""

# ── 4.1 tier ($0.20 in / $0.50 out, 2M context) ───────────────────────────

GROK_41_FAST_REASONING = "grok-4-1-fast-reasoning"
"""4.1 fast reasoning model — cost-efficient with reasoning capability."""

GROK_41_FAST_NON_REASONING = "grok-4-1-fast-non-reasoning"
"""4.1 fast non-reasoning model — lowest latency and cost."""

# ── Backward-compatible 4.1 aliases (do not remove) ───────────────────────

GROK_41_REASONING = GROK_41_FAST_REASONING
GROK_41_NON_REASONING = GROK_41_FAST_NON_REASONING

# ── Code-specialised ($0.20 in / $1.50 out, 256K context) ─────────────────

GROK_CODE_FAST_1 = "grok-code-fast-1"
"""Code-specialised model — optimised for generation and debugging."""

# ── Audio / Voice (Rovox) ─────────────────────────────────────────────────

GROK_2_AUDIO = "grok-2-audio"
"""Audio model — voice input/output for the Rovox runtime."""

# ── Safe fallback (broadly available fast tier) ────────────────────────────

GROK_FALLBACK = GROK_41_FAST_REASONING
"""Fallback used when a requested model returns 404. Always a valid ID."""

# ── Backward-compatibility aliases (do not remove) ────────────────────────
# These preserve imports from code written against earlier SDK versions.

GROK_4_20_EXPERIMENTAL_REASONING = GROK_420_REASONING
GROK_4_20_EXPERIMENTAL_NON_REASONING = GROK_420_NON_REASONING
GROK_4_20_MULTI_AGENT_SUPERVISOR = GROK_420_MULTI_AGENT
GROK_4_20_MULTI_AGENT = GROK_420_MULTI_AGENT
