"""Typed worker agent manifests for the Roboto SAI SDK."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AgentManifest:
    """Immutable description of a registered worker agent."""

    id: str
    display_name: str
    role: str
    specialization: str
    model_preference: str
    routing_priority: int
    memory_scope: str
    tool_access: tuple[str, ...]
    output_style: str
