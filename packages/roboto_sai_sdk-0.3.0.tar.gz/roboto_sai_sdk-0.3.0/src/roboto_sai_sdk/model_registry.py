"""Frozen public runtime registry for the Roboto SAI SDK.

This module is the source of truth for the public Roboto SAI runtime surface.
Fuego consumers must derive routing behavior from these explicit fields rather
than inferring behavior from model names.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from .models import (
    GROK_2_AUDIO,
    GROK_41_NON_REASONING,
    GROK_41_REASONING,
    GROK_420_MULTI_AGENT,
    GROK_420_NON_REASONING,
    GROK_420_REASONING,
    GROK_CODE_FAST_1,
)


@dataclass(frozen=True, slots=True)
class RuntimeProfile:
    """Static runtime metadata for a public Roboto SAI model."""

    public_name: str
    display_name: str
    family: str
    mode: str
    supervisor_model: str | None
    worker_model: str
    provider: str
    provider_model: str
    api_mode: str
    supports_reasoning_effort: bool
    supports_builtin_tools: bool
    supports_max_tokens: bool
    supports_previous_response_id: bool
    orchestrator: bool
    reasoning: bool
    code_specialized: bool
    research_mode: bool
    worker_agents: tuple[str, ...]
    base_model: str
    entrypoint: str
    default_agent_id: str
    subtitle: str
    description: str
    # Access tier required to use this model (0=free, 1=standard, 2=premium).
    # Tier 0: no paywall. Tier 1+: requires approved SAI API key at that tier.
    access_tier: int = 0


DEFAULT_PUBLIC_MODEL: Final[str] = "roboto-sai"

PUBLIC_MODEL_NAMES: Final[tuple[str, ...]] = (
    "roboto-sai",
    "roboto-sai-lightning",
    "roboto-sai-code-x",
    "roboto-sai-heavy",
    "roboto-sai-flex",
    "roboto-sai-cortex",
    "roboto-sai-rovox",
)

# Models that are free to use (no paywall, no subscription required).
FREE_MODEL_NAMES: Final[tuple[str, ...]] = (
    "roboto-sai-lightning",
    "roboto-sai-rovox",
)

# Models that require an active subscription / approved API key tier.
PAYWALLED_MODEL_NAMES: Final[tuple[str, ...]] = (
    "roboto-sai",
    "roboto-sai-code-x",
    "roboto-sai-heavy",
    "roboto-sai-flex",
    "roboto-sai-cortex",
)

PUBLIC_RUNTIME_MAP: Final[dict[str, RuntimeProfile]] = {
    "roboto-sai": RuntimeProfile(
        public_name="roboto-sai",
        display_name="Roboto SAI",
        family="general",
        mode="single-agent",
        supervisor_model=None,
        worker_model=GROK_41_REASONING,
        provider="xai",
        provider_model=GROK_41_REASONING,
        api_mode="responses",
        supports_reasoning_effort=True,
        supports_builtin_tools=True,
        supports_max_tokens=True,
        supports_previous_response_id=True,
        orchestrator=False,
        reasoning=True,
        code_specialized=True,
        research_mode=True,
        worker_agents=("heavy",),
        base_model=GROK_41_REASONING,
        entrypoint="worker",
        default_agent_id="heavy",
        subtitle="Core runtime",
        description="General intelligence for everyday chat, planning, and execution. Default route: grok-4-1-fast-reasoning.",
        access_tier=1,
    ),
    "roboto-sai-lightning": RuntimeProfile(
        public_name="roboto-sai-lightning",
        display_name="Roboto SAI Lightning",
        family="general",
        mode="single-agent",
        supervisor_model=None,
        worker_model=GROK_41_NON_REASONING,
        provider="xai",
        provider_model=GROK_41_NON_REASONING,
        api_mode="responses",
        supports_reasoning_effort=False,
        supports_builtin_tools=False,
        supports_max_tokens=True,
        supports_previous_response_id=False,
        orchestrator=False,
        reasoning=False,
        code_specialized=False,
        research_mode=False,
        worker_agents=("fast",),
        base_model=GROK_41_NON_REASONING,
        entrypoint="worker",
        default_agent_id="fast",
        subtitle="Lightning runtime",
        description="Fast answers with low latency.",
        access_tier=0,
    ),
    "roboto-sai-code-x": RuntimeProfile(
        public_name="roboto-sai-code-x",
        display_name="Roboto SAI Code X",
        family="code",
        mode="single-agent",
        supervisor_model=None,
        worker_model=GROK_CODE_FAST_1,
        provider="xai",
        provider_model=GROK_CODE_FAST_1,
        api_mode="responses",
        supports_reasoning_effort=False,
        supports_builtin_tools=False,
        supports_max_tokens=True,
        supports_previous_response_id=False,
        orchestrator=False,
        reasoning=False,
        code_specialized=True,
        research_mode=False,
        worker_agents=("code",),
        base_model=GROK_CODE_FAST_1,
        entrypoint="worker",
        default_agent_id="code",
        subtitle="Code generation runtime",
        description="Built for coding, debugging, architecture, and implementation.",
        access_tier=2,
    ),
    "roboto-sai-heavy": RuntimeProfile(
        public_name="roboto-sai-heavy",
        display_name="Roboto SAI Heavy",
        family="general",
        mode="single-agent",
        supervisor_model=GROK_420_REASONING,
        worker_model=GROK_420_REASONING,
        provider="xai",
        provider_model=GROK_420_REASONING,
        api_mode="responses",
        supports_reasoning_effort=True,
        supports_builtin_tools=True,
        supports_max_tokens=True,
        supports_previous_response_id=False,
        orchestrator=False,
        reasoning=True,
        code_specialized=False,
        research_mode=False,
        worker_agents=("heavy", "fast", "code"),
        base_model=GROK_420_REASONING,
        entrypoint="worker",
        default_agent_id="heavy",
        subtitle="Function & tool runtime (pre-release)",
        description="Function/tool execution with built-in tools. Pre-release — not yet available in production.",
        access_tier=2,
    ),
    "roboto-sai-flex": RuntimeProfile(
        public_name="roboto-sai-flex",
        display_name="Roboto SAI Flex",
        family="general",
        mode="single-agent",
        supervisor_model=GROK_420_NON_REASONING,
        worker_model=GROK_420_NON_REASONING,
        provider="xai",
        provider_model=GROK_420_NON_REASONING,
        api_mode="responses",
        supports_reasoning_effort=False,
        supports_builtin_tools=True,
        supports_max_tokens=True,
        supports_previous_response_id=False,
        orchestrator=False,
        reasoning=False,
        code_specialized=False,
        research_mode=False,
        worker_agents=("heavy", "fast", "code"),
        base_model=GROK_420_NON_REASONING,
        entrypoint="worker",
        default_agent_id="heavy",
        subtitle="Function & tool runtime (pre-release)",
        description="Function/tool execution with built-in tools. Pre-release — not yet available in production.",
        access_tier=2,
    ),
    "roboto-sai-cortex": RuntimeProfile(
        public_name="roboto-sai-cortex",
        display_name="Roboto SAI Cortex",
        family="general",
        mode="multi-agent",
        supervisor_model=GROK_420_MULTI_AGENT,
        worker_model=GROK_420_MULTI_AGENT,
        provider="xai",
        provider_model=GROK_420_MULTI_AGENT,
        api_mode="responses",
        supports_reasoning_effort=True,
        supports_builtin_tools=True,
        supports_max_tokens=False,
        supports_previous_response_id=True,
        orchestrator=True,
        reasoning=True,
        code_specialized=False,
        research_mode=True,
        worker_agents=("heavy", "fast"),
        base_model=GROK_420_MULTI_AGENT,
        entrypoint="orchestrator",
        default_agent_id="heavy",
        subtitle="Cortex runtime",
        description="Deep multi-agent orchestration with optional search tools.",
        access_tier=2,
    ),
    "roboto-sai-rovox": RuntimeProfile(
        public_name="roboto-sai-rovox",
        display_name="Roboto SAI RoVox",
        family="voice",
        mode="single-agent",
        supervisor_model=None,
        worker_model=GROK_2_AUDIO,
        provider="xai",
        provider_model=GROK_2_AUDIO,
        api_mode="audio",
        supports_reasoning_effort=False,
        supports_builtin_tools=False,
        supports_max_tokens=False,
        supports_previous_response_id=False,
        orchestrator=False,
        reasoning=False,
        code_specialized=False,
        research_mode=False,
        worker_agents=("vox",),
        base_model=GROK_2_AUDIO,
        entrypoint="worker",
        default_agent_id="vox",
        subtitle="Voice runtime (Vox)",
        description="Audio input/output. Free tier, no paywall.",
        access_tier=0,
    ),
}


def normalize_public_model(model_name: str | None) -> str:
    """Return a valid public model or raise ValueError for invalid input."""

    candidate = (model_name or DEFAULT_PUBLIC_MODEL).strip().lower()
    if candidate not in PUBLIC_MODEL_NAMES:
        raise ValueError(
            f"Unknown public model '{candidate}'. Available: {', '.join(PUBLIC_MODEL_NAMES)}"
        )
    return candidate


def get_runtime_profile(model_name: str) -> RuntimeProfile:
    """Return the runtime profile for a supported public model name."""

    candidate = (model_name or DEFAULT_PUBLIC_MODEL).strip().lower()
    if candidate not in PUBLIC_MODEL_NAMES:
        raise ValueError(f"Unknown public model '{candidate}'.")
    return PUBLIC_RUNTIME_MAP[candidate]
