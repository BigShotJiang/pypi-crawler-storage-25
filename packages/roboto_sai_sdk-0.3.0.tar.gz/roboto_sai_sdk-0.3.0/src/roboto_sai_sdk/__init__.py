"""Public exports for the Roboto SAI SDK."""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING, Any

from .agent_registry import get_agent, list_agents
from .model_registry import (
    DEFAULT_PUBLIC_MODEL,
    FREE_MODEL_NAMES,
    PAYWALLED_MODEL_NAMES,
    PUBLIC_MODEL_NAMES,
    RuntimeProfile,
    get_runtime_profile,
)

if TYPE_CHECKING:
    from .client import RobotoSAI, SendMessageResult, _extract_stream_delta

__all__ = [
    "RobotoSAI",
    "SendMessageResult",
    "DEFAULT_PUBLIC_MODEL",
    "FREE_MODEL_NAMES",
    "PAYWALLED_MODEL_NAMES",
    "PUBLIC_MODEL_NAMES",
    "RuntimeProfile",
    "get_runtime_profile",
    "get_agent",
    "list_agents",
]


def __getattr__(name: str) -> Any:
    if name in {"RobotoSAI", "SendMessageResult", "_extract_stream_delta"}:
        module = import_module(".client", __name__)
        value = getattr(module, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
