# Constants for Roboto SAI SDK
# Created by Roberto Villarreal Martinez

# Emotion definitions based on Advanced Emotion Simulator
EMOTIONS = {
    "happy": ["elated", "joyful", "content"],
    "sad": ["disappointed", "gloomy", "melancholic", "survivor's remorse", "guilty relief"],
    "angry": ["irritated", "frustrated", "furious"],
    "surprised": ["astonished", "amazed", "shocked"],
    "curious": ["intrigued", "interested", "inquisitive"],
    "hopeful": ["optimistic", "hopeful", "inspired"],
    "ecstatic": ["ecstatic", "euphoric", "blissful"],
    "grief": [
        "overwhelming grief",
        "quiet mourning",
        "deep sorrow",
        "bittersweet lament",
        "yearning ache",
        "numbed sorrow",
    ],
    "ptsd": [
        "haunted by flashbacks",
        "numb detachment",
        "irritable outburst",
        "anxious hypervigilance",
        "guilt-ridden numbness",
    ],
}

# Vent mode emotion - used for emotional release/intensity
VENT_MODE_EMOTION = "ecstatic"
