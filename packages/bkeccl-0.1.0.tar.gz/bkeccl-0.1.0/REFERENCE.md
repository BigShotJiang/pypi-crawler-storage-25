# API Reference

For task-oriented examples see the [Usage section of the
README](README.md#usage).

Everything below is importable directly from `bkeccl`
(`from bkeccl import ccl, ...`).

## `ccl(input_data, algorithm="bke", dimensionality="2D", output_mode="dense", *, label_output=None)`

Label connected components of a 2D or 3D array (CUDA only). 2D is
8-connectivity on 2x2 blocks; 3D is 26-connectivity on 2x2x2 blocks. This is
the validated, normalizing entry point: it establishes every precondition the
underlying fast paths assume and handles the empty-input case.

- `input_data` (`cupy.ndarray | SupportsDLPack`): GPU-resident array, shape
  `(H, W)` for 2D or `(D, H, W)` for 3D. A `cupy.ndarray` is used directly;
  any object exposing the DLPack protocol whose `__dlpack_device__` reports
  CUDA memory is imported zero-copy. Any non-zero value is foreground; `0` is
  background. `bool`/`uint8` are used directly (`bool` via a zero-copy view);
  other dtypes are reduced to their non-zero mask. Non-contiguous input is
  copied to a contiguous `uint8` temporary.
- `algorithm` (`str`): `"bke"` (default, standard BKE) or `"bke_ic"` (inline
  path compression). Other values raise `ValueError`.
- `dimensionality` (`str`): `"2D"` (default) or `"3D"`. Must match
  `input_data.ndim`. Other values raise `ValueError`.
- `output_mode` (`str`): `"dense"` (default) renumbers components to a
  contiguous `1..N` and returns `(labels, count)`; `"raw"` returns the native
  sparse root-raster IDs as a single array.
- `label_output` (`cupy.ndarray`, optional, keyword-only): pre-allocated
  C-contiguous `int32` buffer with the same shape as `input_data`. When given,
  it is written in place and the result aliases it. When `None`, an output
  buffer is allocated.

Returns, for `output_mode="dense"`, a tuple `(labels, count)`: `labels` is an
`int32` array of the input shape (background `0`, components `1..N`) and
`count` is a 0-dim `int32` device array holding `N` (read with `int(count)`,
which synchronizes). For `output_mode="raw"`, returns just the `int32` label
array (sparse positive IDs, **not** dense `1..N`).

For an empty input the shape is preserved and the component count is `0`.

Raises `TypeError` if `input_data` is neither a `cupy.ndarray` nor a
GPU-resident DLPack-exposing tensor (host-resident DLPack tensors are
rejected). Raises `ValueError` if `dimensionality` is not `"2D"`/`"3D"`, if
`input_data.ndim` does not match `dimensionality`, or if `label_output` is not
a C-contiguous `int32` buffer of the input's shape.

## `ccl_masks(input_data, algorithm="bke", dimensionality="2D", *, label_output=None)`

Label an array and return its per-component boolean mask stack. Runs `ccl` in
dense mode and expands the result with the device one-hot kernel, keeping the
whole path on the GPU.

- `input_data` (`cupy.ndarray | SupportsDLPack`): same contract as `ccl`.
- `algorithm` (`str`): `"bke"` (default) or `"bke_ic"`.
- `dimensionality` (`str`): `"2D"` (default) or `"3D"`; must match
  `input_data.ndim`.
- `label_output` (`cupy.ndarray`, optional, keyword-only): pre-allocated
  C-contiguous `int32` buffer with the input's shape, used as the
  dense-labeling scratch.

Returns a `(N, *spatial)` C-contiguous `bool` array; plane `k` is the mask of
component `k + 1`. Returns `(0, *spatial)` when the input has no foreground.
The single host synchronization is the count read needed to size the stack.

Raises `TypeError` / `ValueError` under the same conditions as `ccl`.

## `masks_from_labels(dense_labels, count)`

Expand a dense label map into a per-component boolean mask stack.

- `dense_labels` (`cupy.ndarray | SupportsDLPack`): 2D `(H, W)` or 3D
  `(D, H, W)` `int32` map with values in `0..count` (background `0`). A
  `cupy.ndarray` or GPU-resident DLPack tensor; made C-contiguous if needed.
- `count` (`int | cupy.ndarray`): number of components `N` (the maximum label
  value). A device scalar (e.g. the `count` returned by `ccl`) is read to host,
  which synchronizes once.

Returns a `(N, *spatial)` C-contiguous `bool` array; plane `k` is the mask of
component `k + 1`.

Raises `TypeError` if `dense_labels` is neither a `cupy.ndarray` nor a
GPU-resident DLPack-exposing tensor. Raises `ValueError` if `dense_labels` is
not a 2D/3D `int32` array, or if `count` is negative.

## Shape-specialized runners

`make_ccl_2D` and `make_ccl_3D` return a reusable callable with every
shape-derived value baked in once (launch grid, kernel scalars, resolved kernel
handles, and all device scratch). They trade safety for speed and are the
deliberate counterpart to `ccl`.

The returned runner performs **no input validation whatsoever** and assumes the
caller upholds, on every call: `input_data` is a `cupy.ndarray` of dtype
`uint8` (non-zero is foreground), C-contiguous, with `ndim` matching the
runner's dimensionality, with exactly the `shape` the runner was built for,
resident on the build device, with that device current.

The returned label buffer (and, for `output_mode="dense"`, the 0-dim `count`)
is process-owned and reused: the next call overwrites it, so consume or copy it
before invoking the runner again. The runners are not thread- or stream-safe;
use one per device, per stream, per in-flight op.

### `make_ccl_2D(shape, algorithm="bke", output_mode="dense", device=None)`

Build a shape-specialized 2D BKE runner (8-connectivity). Memoized for the
process by argument identity, so identical arguments return the same runner.

- `shape` (`tuple[int, int]`): fixed `(H, W)` every call will supply; positive
  ints.
- `algorithm` (`str`): `"bke"` (default) or `"bke_ic"`.
- `output_mode` (`str`): `"dense"` (default) returns `(labels, count)` and
  renumbers to `1..N`; `"raw"` returns the sparse label array only.
- `device` (`int`, optional): CUDA device id to allocate and run on. `None`
  (default) resolves to the current device at build time.

Returns a callable; invoke as `runner(input_data)`. For `output_mode="dense"`
it returns `(labels, count)`; for `"raw"` it returns `labels`.

Raises `ValueError` if `shape` is not a 2-tuple of positive ints, or if
`algorithm` / `output_mode` is not a recognized literal.

### `make_ccl_3D(shape, algorithm="bke", output_mode="dense", device=None)`

The 3D (26-connectivity) counterpart of `make_ccl_2D`, with the same baked
state, memoization, contract, and return shapes.

- `shape` (`tuple[int, int, int]`): fixed `(D, H, W)` every call will supply;
  positive ints.
- `algorithm`, `output_mode`, `device`: as `make_ccl_2D`.

Raises `ValueError` if `shape` is not a 3-tuple of positive ints, or if
`algorithm` / `output_mode` is not a recognized literal.

## Typing

### `SupportsDLPack`

A `runtime_checkable` `Protocol` for a GPU tensor exposing the DLPack producer
interface: `__dlpack__(self, *, stream=...)` and
`__dlpack_device__(self) -> tuple[int, int]`. `torch.Tensor`, `jax.Array`,
Triton tensors, and other framework device arrays satisfy it structurally with
no import dependency on those frameworks. Use it to annotate code that accepts
any bkeccl-compatible non-CuPy input.

### `CCLInput`

Type alias `cupy.ndarray | SupportsDLPack`: the public input contract for
`ccl`, `ccl_masks`, and `masks_from_labels`. Annotate your own wrappers with
this to match the package's accepted input type.

## Version

### `__version__`

Module-level `str` holding the installed package version, resolved from the
installed distribution metadata via `importlib.metadata`. For a source tree
without installed metadata it reports `"0.0.0+unknown"`.
