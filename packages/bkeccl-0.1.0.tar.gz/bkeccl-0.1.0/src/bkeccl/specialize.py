"""
Shape-specialized 2D and 3D BKE runners for locked-down, hot-loop callers.

:func:`make_ccl_2D` (2D, 8-connectivity) and :func:`make_ccl_3D` (3D,
26-connectivity) each return a reusable callable that has every value
derivable from a *fixed* image shape baked in once: the launch grid, the
``int64`` kernel scalars, the resolved kernel handles, and all device
scratch (the ``int32`` label buffer and the dense-relabel ``present`` /
``scan`` buffers). Nothing in the per-call path allocates or recomputes
geometry, in contrast to :func:`bkeccl.ccl`, which re-derives the grid and
re-allocates scratch on every call.

The factory resolves the ``(algorithm, output_mode)`` combination once and
returns a closure specialized to exactly that path: the per-call function
contains no configuration branches and reads its baked state from captured
locals rather than instance attributes.

This module trades safety for speed and is the deliberate counterpart to the
validated :func:`bkeccl.ccl` surface. The returned runner performs **no
input validation whatsoever** and assumes the caller upholds, on every call:

- ``input_data`` is a ``cupy.ndarray`` of dtype ``uint8`` (non-zero is
  foreground), C-contiguous, with ``ndim`` matching the runner's
  dimensionality (2 for :func:`make_ccl_2D`, 3 for :func:`make_ccl_3D`),
  with exactly the ``shape`` the runner was built for, resident on the
  build device, and the current CUDA device is that build device.

The returned label buffer (and, for ``output_mode="dense"``, the 0-dim
``count``) is process-owned and reused: it is overwritten by the next call,
so consume or copy it before invoking the runner again. This is sound for a
synchronous serving ``execute`` path and unsuitable as a general API, which
is why it lives behind an explicit factory rather than in :func:`bkeccl.ccl`.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Literal

import cupy

from bkeccl.backend.threeD import algorithms as _alg3d
from bkeccl.backend.threeD import kernels as kernels3d
from bkeccl.backend.twoD import algorithms as _alg
from bkeccl.backend.twoD import kernels


__all__ = ["make_ccl_2D", "make_ccl_3D"]

# A runner labels one image and returns either the sparse label map
# (``output_mode="raw"``) or ``(labels, count)`` (``output_mode="dense"``).
CclRunner = Callable[[cupy.ndarray], cupy.ndarray | tuple[cupy.ndarray, cupy.ndarray]]


@functools.cache
def make_ccl_2D(
    shape: tuple[int, int],
    algorithm: Literal["bke", "bke_ic"] = "bke",
    output_mode: Literal["dense", "raw"] = "dense",
    device: int | None = None,
) -> CclRunner:
    """
    Build a shape-specialized, reusable 2D BKE runner.

    The result is memoized for the process by argument identity, so repeated
    calls with the same arguments return the same runner. The
    ``(algorithm, output_mode)`` combination is resolved here, so the
    returned closure's per-call path has no configuration branches and no
    instance-attribute dispatch. Use this only when the caller can guarantee
    the runner contract described in the module docstring on every
    invocation; otherwise use :func:`bkeccl.ccl`.

    Parameters
    ----------
    shape : tuple[int, int]
        Fixed ``(H, W)`` image shape every call will supply.
    algorithm : {"bke", "bke_ic"}, optional
        BKE variant; ``"bke_ic"`` uses inline path compression. Default
        ``"bke"``.
    output_mode : {"dense", "raw"}, optional
        ``"raw"`` returns sparse root-raster ids; ``"dense"`` renumbers to
        ``1..N`` and also returns the 0-dim ``int32`` device count. Default
        ``"dense"``.
    device : int, optional
        CUDA device id to allocate on and run on. Default ``None`` resolves
        to the current device at build time.

    Returns
    -------
    CclRunner
        A callable; invoke as ``runner(input_data)``.

    Raises
    ------
    ValueError
        If ``shape`` is not a 2-tuple of positive ints, or ``algorithm`` /
        ``output_mode`` is not a recognized literal.
    """
    if len(shape) != 2 or shape[0] <= 0 or shape[1] <= 0:
        raise ValueError(f"shape must be a 2-tuple of positive ints, got {shape!r}")
    if algorithm not in ("bke", "bke_ic"):
        raise ValueError(f"algorithm must be 'bke' or 'bke_ic', got {algorithm!r}")
    if output_mode not in ("dense", "raw"):
        raise ValueError(f"output_mode must be 'dense' or 'raw', got {output_mode!r}")

    resolved_device = cupy.cuda.Device().id if device is None else device
    dense = output_mode == "dense"

    with cupy.cuda.Device(resolved_device):
        out = cupy.empty(shape, dtype=cupy.int32)
        # Identical launch geometry to the fast path, derived once.
        grid, h, w = _alg._bke_grid(out)
        step = w
        threads = _alg._THREADS

        init_k = kernels.init_kernel()
        compress_k = kernels.compress_kernel() if algorithm == "bke" else kernels.compress_ic_kernel()
        reduction_k = kernels.reduction_kernel()
        final_k = kernels.final_kernel()

        n = out.size
        flat = out.reshape(-1)
        if dense:
            present = cupy.empty(n + 1, dtype=cupy.uint8)
            scan = cupy.empty(n + 1, dtype=cupy.int32)
            count = scan[n].reshape(())
            gather = _alg._gather_kernel()

        def _label(src: cupy.ndarray) -> None:
            init_k(grid, threads, (src, out, h, w, step, step))
            compress_k(grid, threads, (out, h, w, step))
            reduction_k(grid, threads, (out, h, w, step))
            compress_k(grid, threads, (out, h, w, step))
            final_k(grid, threads, (out, h, w, step))

        def _relabel() -> None:
            present.fill(0)
            present[flat] = 1
            present[0] = 0  # Background never consumes a dense id.
            cupy.cumsum(present, dtype=cupy.int32, out=scan)
            gather(out, scan, out)

        if dense:

            def run_dense(input_data: cupy.ndarray) -> tuple[cupy.ndarray, cupy.ndarray]:
                _label(input_data)
                _relabel()
                return out, count

            return run_dense

        def run_raw(input_data: cupy.ndarray) -> cupy.ndarray:
            _label(input_data)
            return out

        return run_raw


@functools.cache
def make_ccl_3D(
    shape: tuple[int, int, int],
    algorithm: Literal["bke", "bke_ic"] = "bke",
    output_mode: Literal["dense", "raw"] = "dense",
    device: int | None = None,
) -> CclRunner:
    """
    Build a shape-specialized, reusable 3D BKE runner.

    The 3D (26-connectivity) counterpart of :func:`make_ccl_2D`, with the
    same baked state (launch grid, ``int64`` shape/step scalars, resolved
    kernel handles, and reused ``int32`` label and dense-relabel scratch).
    The result is memoized for the process by argument identity, so repeated
    calls with the same arguments return the same runner. Use this only when
    the caller can guarantee the runner contract described in the module
    docstring on every invocation; otherwise use :func:`bkeccl.ccl`.

    Parameters
    ----------
    shape : tuple[int, int, int]
        Fixed ``(D, H, W)`` volume shape every call will supply.
    algorithm : {"bke", "bke_ic"}, optional
        BKE variant; ``"bke_ic"`` uses inline path compression. Default
        ``"bke"``.
    output_mode : {"dense", "raw"}, optional
        ``"raw"`` returns sparse root-raster ids; ``"dense"`` renumbers to
        ``1..N`` and also returns the 0-dim ``int32`` device count. Default
        ``"dense"``.
    device : int, optional
        CUDA device id to allocate on and run on. Default ``None`` resolves
        to the current device at build time.

    Returns
    -------
    CclRunner
        A callable; invoke as ``runner(input_data)``.

    Raises
    ------
    ValueError
        If ``shape`` is not a 3-tuple of positive ints, or ``algorithm`` /
        ``output_mode`` is not a recognized literal.
    """
    if len(shape) != 3 or shape[0] <= 0 or shape[1] <= 0 or shape[2] <= 0:
        raise ValueError(f"shape must be a 3-tuple of positive ints, got {shape!r}")
    if algorithm not in ("bke", "bke_ic"):
        raise ValueError(f"algorithm must be 'bke' or 'bke_ic', got {algorithm!r}")
    if output_mode not in ("dense", "raw"):
        raise ValueError(f"output_mode must be 'dense' or 'raw', got {output_mode!r}")

    resolved_device = cupy.cuda.Device().id if device is None else device
    dense = output_mode == "dense"

    with cupy.cuda.Device(resolved_device):
        out = cupy.empty(shape, dtype=cupy.int32)
        # Identical launch geometry to the fast path, derived once.
        grid, d, h, w, step_z, step_y = _alg3d._bke3d_grid(out)
        threads = _alg3d._THREADS

        init_k = kernels3d.init_kernel_3d()
        compress_k = kernels3d.compress_kernel_3d() if algorithm == "bke" else kernels3d.compress_ic_kernel_3d()
        reduction_k = kernels3d.reduction_kernel_3d()
        final_k = kernels3d.final_kernel_3d()

        n = out.size
        flat = out.reshape(-1)
        if dense:
            present = cupy.empty(n + 1, dtype=cupy.uint8)
            scan = cupy.empty(n + 1, dtype=cupy.int32)
            count = scan[n].reshape(())
            gather = _alg3d._gather_kernel()

        def _label(src: cupy.ndarray) -> None:
            init_k(grid, threads, (src, out, d, h, w, step_z, step_y))
            compress_k(grid, threads, (out, d, h, w, step_z, step_y))
            reduction_k(grid, threads, (out, d, h, w, step_z, step_y))
            compress_k(grid, threads, (out, d, h, w, step_z, step_y))
            final_k(grid, threads, (out, d, h, w, step_z, step_y))

        def _relabel() -> None:
            present.fill(0)
            present[flat] = 1
            present[0] = 0  # Background never consumes a dense id.
            cupy.cumsum(present, dtype=cupy.int32, out=scan)
            gather(out, scan, out)

        if dense:

            def run_dense(input_data: cupy.ndarray) -> tuple[cupy.ndarray, cupy.ndarray]:
                _label(input_data)
                _relabel()
                return out, count

            return run_dense

        def run_raw(input_data: cupy.ndarray) -> cupy.ndarray:
            _label(input_data)
            return out

        return run_raw
