"""
Validated per-component boolean mask surface.

This is the safe layer over the strict one-hot scatter fast paths
:func:`bkeccl.backend.twoD.masks.onehot_masks_2D` (2D) and
:func:`bkeccl.backend.threeD.masks.onehot_masks_3D` (3D), analogous to how
:func:`bkeccl.ccl` wraps the labeling fast paths. :func:`masks_from_labels`
expands an existing dense label map; :func:`ccl_masks` is the one-call
convenience that labels an image and returns its component masks, intended
for callers (such as a serving ``execute`` path) that want the
``(N, *spatial)`` mask stack directly and keep everything on device.
"""

from __future__ import annotations

from typing import Literal

import cupy

from bkeccl._base import (
    CCLInput,
    _as_cupy,
    ccl,
)
from bkeccl.backend.threeD.masks import onehot_masks_3D
from bkeccl.backend.twoD.masks import onehot_masks_2D


# Dense-label ndim -> one-hot scatter fast path.
_ONEHOT_BY_NDIM = {2: onehot_masks_2D, 3: onehot_masks_3D}

__all__ = ["masks_from_labels", "ccl_masks"]


def _resolve_count(count: int | cupy.ndarray) -> int:
    """
    Reduce a component count to a host ``int``.

    A device ``count`` (the 0-dim array :func:`bkeccl.ccl` returns in dense
    mode) forces one device-to-host transfer and synchronizes: the
    output's leading dimension cannot be sized without it.

    Parameters
    ----------
    count : int or cupy.ndarray
        Component count, either a host ``int`` or a device ``int`` scalar.

    Returns
    -------
    int
        The count as a host ``int``.

    Raises
    ------
    ValueError
        If ``count`` is negative.
    """
    n = int(count)
    if n < 0:
        raise ValueError(f"count must be non-negative, got {n}")
    return n


def masks_from_labels(dense_labels: CCLInput, count: int | cupy.ndarray) -> cupy.ndarray:
    """
    Expand a dense label map into a per-component boolean mask stack.

    Parameters
    ----------
    dense_labels : cupy.ndarray or SupportsDLPack
        2D ``(H, W)`` or 3D ``(D, H, W)`` ``int32`` map with values in
        ``0..count`` (background 0). A :class:`cupy.ndarray` or GPU-resident
        DLPack tensor; made C-contiguous if needed. Its value range is
        checked on device against ``0..count`` before the scatter, which
        reads two scalars to host and synchronizes.
    count : int or cupy.ndarray
        Number of components ``N`` (the maximum label value). A device
        scalar is read to host, which synchronizes.

    Returns
    -------
    cupy.ndarray
        ``(N, *spatial)`` C-contiguous ``bool`` array; stack entry ``k`` is
        the mask of component ``k + 1``.

    Raises
    ------
    TypeError
        If ``dense_labels`` is neither a :class:`cupy.ndarray` nor a
        GPU-resident DLPack-exposing tensor.
    ValueError
        If ``dense_labels`` is not a 2D/3D ``int32`` array, ``count`` is
        negative, or ``dense_labels`` holds a value outside ``0..count``.
    """
    dense_labels = _as_cupy(dense_labels)
    onehot = _ONEHOT_BY_NDIM.get(dense_labels.ndim)
    if onehot is None:
        raise ValueError(f"dense_labels must be 2D or 3D, got ndim {dense_labels.ndim}")
    if dense_labels.dtype != cupy.int32:
        raise ValueError(f"dense_labels dtype must be int32, got {dense_labels.dtype}")

    n = _resolve_count(count)
    contig = cupy.ascontiguousarray(dense_labels)
    if contig.size > 0:
        lo = int(contig.min())
        hi = int(contig.max())
        if lo < 0:
            raise ValueError(f"dense_labels must be non-negative, got minimum {lo}")
        if hi > n:
            raise ValueError(f"dense_labels has value {hi} exceeding count {n}")
    return onehot(contig, n)


def ccl_masks(
    input_data: CCLInput,
    algorithm: Literal["bke", "bke_ic"] = "bke",
    dimensionality: Literal["2D", "3D"] = "2D",
    *,
    label_output: cupy.ndarray | None = None,
) -> cupy.ndarray:
    """
    Label a 2D or 3D image and return its per-component boolean masks.

    Runs :func:`bkeccl.ccl` in dense mode and expands the result with the
    device one-hot kernel, keeping the whole path on the GPU. The single
    host synchronization is the count read needed to size the output. 2D
    uses 8-connectivity; 3D uses 26-connectivity.

    Parameters
    ----------
    input_data : cupy.ndarray or SupportsDLPack
        2D ``(H, W)`` or 3D ``(D, H, W)`` image on the current CUDA device;
        non-zero entries are foreground. A :class:`cupy.ndarray` is used
        directly; any GPU-resident object exposing the DLPack protocol is
        imported zero-copy. ``bool``/``uint8`` are used directly; other
        dtypes are reduced to their non-zero mask.
    algorithm : {"bke", "bke_ic"}, optional
        BKE variant; ``"bke_ic"`` uses inline path compression. Default
        ``"bke"``.
    dimensionality : {"2D", "3D"}, optional
        Image dimensionality; must match ``input_data.ndim``. Default
        ``"2D"``.
    label_output : cupy.ndarray, optional
        Keyword-only. Pre-allocated C-contiguous ``int32`` buffer with the
        same shape as ``input_data``, used as the dense-labeling scratch.
        When ``None``, it is allocated.

    Returns
    -------
    cupy.ndarray
        ``(N, *spatial)`` C-contiguous ``bool`` array; stack entry ``k`` is
        the mask of component ``k + 1``. ``(0, *spatial)`` when the image
        has no foreground.

    Raises
    ------
    TypeError
        If ``input_data`` is neither a :class:`cupy.ndarray` nor a
        GPU-resident DLPack-exposing tensor.
    ValueError
        If ``dimensionality`` is not ``"2D"``/``"3D"``, ``input_data`` ndim
        does not match it, or ``label_output`` is incompatible.
    """
    dense_labels, count = ccl(
        input_data,
        algorithm,
        dimensionality,
        output_mode="dense",
        label_output=label_output,
    )
    onehot = _ONEHOT_BY_NDIM[dense_labels.ndim]
    return onehot(dense_labels, _resolve_count(count))
