"""
2D Block-based Komura Equivalence (BKE) CUDA kernels and module accessors.

The device algorithm is the BKE 8-connectivity labeler of Allegretti, Bolelli,
Cancilla, Grana, *"Optimized Block-Based Algorithms to Label Connected
Components on GPUs"* (IEEE TPDS 2019), operating on 2x2 pixel blocks. The
``__global__`` kernels run in the fixed order Init -> Compress -> Reduction ->
Compress -> FinalLabel, entirely in place in an ``int32`` label buffer. The
Compress step has two compile-time-distinct kernels selected by algorithm:
``bke_compress_kernel`` (standard find-and-compress) and
``bke_compress_ic_kernel`` (inline compression), so the variant is fixed at
launch with no in-kernel branch.

The source is a single ``extern "C"`` translation unit using only built-in C
types (``int``, ``long long``, ``unsigned char``, ``unsigned short``), so it
needs no ``<cstdint>`` preamble, no C++ name mangling, and no per-dtype template
instantiation. The init kernel consumes a ``const unsigned char*`` foreground
image; callers normalize ``bool`` inputs with a zero-copy ``view(uint8)``
upstream. The compiled :class:`cupy.RawModule` is built once and cached for the
process.
"""

from __future__ import annotations

import functools

import cupy


__all__ = [
    "init_kernel",
    "compress_kernel",
    "compress_ic_kernel",
    "reduction_kernel",
    "final_kernel",
]

_BKE_SOURCE = r"""
#define K_BACKGROUND_PARENT (-1)

__device__ __forceinline__ int find(int* labels, int index) {
    while (labels[index] != index) {
        index = labels[index];
    }
    return index;
}

__device__ __forceinline__ int find_n_compress(int* labels, int index) {
    int root = find(labels, index);
    labels[index] = root;
    return root;
}

__device__ __forceinline__ int find_inline_compress(int* labels, int index) {
    int id = index;
    while (labels[index] != index) {
        index = labels[index];
        labels[id] = index;
    }
    return index;
}

__device__ __forceinline__ unsigned char read_info_byte(
    const int* __restrict__ labels,
    const long long xL,
    const long long x,
    const long long y,
    const long long width,
    const long long height,
    const long long step_L) {

    // Info byte is stored in top-right pixel, or bottom-left for odd-width edges
    if (x + 1 < width) {
        return (unsigned char)(labels[xL + 1]);
    } else if (y + 1 < height) {
        return (unsigned char)(labels[xL + step_L]);
    }
    // Single-pixel block at the bottom-right corner (odd height AND odd
    // width): foreground state is the sign of labels[xL] (>= 0 means a real
    // block id, i.e. foreground).
    return labels[xL] >= 0 ? (unsigned char)1 : (unsigned char)0;
}

__device__ void atomic_union(int* labels, int index_a, int index_b) {
    bool done = false;
    while (!done) {
        index_a = find(labels, index_a);
        index_b = find(labels, index_b);

        if (index_a < index_b) {
            int index_old = atomicMin(&labels[index_b], index_a);
            done = (index_old == index_b);
            index_b = index_old;
        } else if (index_b < index_a) {
            int index_old = atomicMin(&labels[index_a], index_b);
            done = (index_old == index_a);
            index_a = index_old;
        } else {
            done = true;
        }
    }
}

__device__ __forceinline__ bool has_bit(unsigned short bitset, int pos) {
    return (bitset >> pos) & 1;
}

__device__ __forceinline__ bool is_internal_fg(unsigned char info_byte, int pixel_idx) {
    return (info_byte >> pixel_idx) & 1;
}

__device__ __forceinline__ bool needs_union(unsigned char info_byte, int neighbor_idx) {
    return (info_byte >> (5 + neighbor_idx)) & 1;
}

extern "C" __global__ void bke_init_kernel(
    const unsigned char* __restrict__ input,
    int* __restrict__ labels,
    const long long height,
    const long long width,
    const long long step_I,
    const long long step_L) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h) return;

    const long long y = by * 2;  // Top-left pixel row of this block
    const long long x = bx * 2;  // Top-left pixel col of this block
    const long long xI = y * step_I + x;  // Input image index
    const long long xL = y * step_L + x;  // Labels image index

    int min_label = (int)xL;

    unsigned char info_byte = 0;
    unsigned short bit_set = 0;

    if (y < height && x < width && input[xI] > 0) {
        bit_set |= 0x777;
        info_byte |= (1 << 0);
    }

    if (y < height && x + 1 < width && input[xI + 1] > 0) {
        bit_set |= (0x777 << 1);
        info_byte |= (1 << 1);
    }

    if (y + 1 < height && x < width && input[xI + step_I] > 0) {
        bit_set |= (0x777 << 4);
        info_byte |= (1 << 2);
    }

    if (y + 1 < height && x + 1 < width && input[xI + step_I + 1] > 0) {
        info_byte |= (1 << 3);
    }

    // Background block: all four pixels background.
    if ((info_byte & 0x0F) == 0) {
        labels[xL] = K_BACKGROUND_PARENT;
        if (x + 1 < width) {
            labels[xL + 1] = 0;
        } else if (y + 1 < height) {
            labels[xL + step_L] = 0;
        }
        return;
    }

    // Block P: upper-left diagonal.
    if (y >= 2 && x >= 2) {
        if (has_bit(bit_set, 0) && input[xI - step_I - 1] > 0) {
            int label_P = (int)(xL - 2 * step_L - 2);
            if (label_P < min_label) {
                min_label = label_P;
            }
        }
    }

    bool connects_Q = false, connects_R = false, connects_S = false;

    // Block Q: directly above.
    if (y >= 2) {
        if ((has_bit(bit_set, 1) && x < width && input[xI - step_I] > 0) ||
            (has_bit(bit_set, 2) && x + 1 < width && input[xI - step_I + 1] > 0)) {
            connects_Q = true;
            int label_Q = (int)(xL - 2 * step_L);
            if (label_Q < min_label) {
                min_label = label_Q;
            }
        }
    }

    // Block R: upper-right diagonal.
    if (y >= 2 && x + 2 < width) {
        if (has_bit(bit_set, 3) && input[xI - step_I + 2] > 0) {
            connects_R = true;
            int label_R = (int)(xL - 2 * step_L + 2);
            if (label_R < min_label) {
                min_label = label_R;
            }
        }
    }

    // Block S: directly left.
    if (x >= 2) {
        if ((has_bit(bit_set, 4) && y < height && input[xI - 1] > 0) ||
            (has_bit(bit_set, 8) && y + 1 < height && input[xI + step_I - 1] > 0)) {
            connects_S = true;
            int label_S = (int)(xL - 2);
            if (label_S < min_label) {
                min_label = label_S;
            }
        }
    }

    if (connects_Q && (int)(xL - 2 * step_L) != min_label) {
        info_byte |= (1 << 5);
    }
    if (connects_R && (int)(xL - 2 * step_L + 2) != min_label) {
        info_byte |= (1 << 6);
    }
    if (connects_S && (int)(xL - 2) != min_label) {
        info_byte |= (1 << 7);
    }

    labels[xL] = min_label;

    if (x + 1 < width) {
        labels[xL + 1] = (int)info_byte;
    } else if (y + 1 < height) {
        labels[xL + step_L] = (int)info_byte;
    }
}

extern "C" __global__ void bke_compress_kernel(
    int* __restrict__ labels,
    const long long height,
    const long long width,
    const long long step_L) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h) return;

    const long long y = by * 2;
    const long long x = bx * 2;
    const long long xL = y * step_L + x;

    // Skip background blocks (negative sentinel; 0 is a valid block id).
    if (labels[xL] < 0) return;

    find_n_compress(labels, (int)xL);
}

extern "C" __global__ void bke_compress_ic_kernel(
    int* __restrict__ labels,
    const long long height,
    const long long width,
    const long long step_L) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h) return;

    const long long y = by * 2;
    const long long x = bx * 2;
    const long long xL = y * step_L + x;

    // Skip background blocks (negative sentinel; 0 is a valid block id).
    if (labels[xL] < 0) return;

    find_inline_compress(labels, (int)xL);
}

extern "C" __global__ void bke_reduction_kernel(
    int* __restrict__ labels,
    const long long height,
    const long long width,
    const long long step_L) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h) return;

    const long long y = by * 2;
    const long long x = bx * 2;
    const long long xL = y * step_L + x;

    int block_label = labels[xL];

    if (block_label < 0) return;

    unsigned char info_byte = read_info_byte(labels, xL, x, y, width, height, step_L);

    if ((info_byte & 0x0F) == 0) return;

    // Bit 5: union with block Q (directly above).
    if (needs_union(info_byte, 0) && y >= 2) {
        int label_Q = (int)(xL - 2 * step_L);
        atomic_union(labels, (int)xL, label_Q);
    }

    // Bit 6: union with block R (upper-right diagonal).
    if (needs_union(info_byte, 1) && y >= 2 && x + 2 < width) {
        int label_R = (int)(xL - 2 * step_L + 2);
        atomic_union(labels, (int)xL, label_R);
    }

    // Bit 7: union with block S (directly left).
    if (needs_union(info_byte, 2) && x >= 2) {
        int label_S = (int)(xL - 2);
        atomic_union(labels, (int)xL, label_S);
    }
}

extern "C" __global__ void bke_final_labeling_kernel(
    int* __restrict__ labels,
    const long long height,
    const long long width,
    const long long step_L) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h) return;

    const long long y = by * 2;
    const long long x = bx * 2;
    const long long xL = y * step_L + x;

    int block_label = labels[xL];

    unsigned char info_byte = read_info_byte(labels, xL, x, y, width, height, step_L);

    // Background block: set all four pixels to 0.
    if ((info_byte & 0x0F) == 0) {
        labels[xL] = 0;
        if (x + 1 < width) {
            labels[xL + 1] = 0;
        }
        if (y + 1 < height) {
            labels[xL + step_L] = 0;
            if (x + 1 < width) {
                labels[xL + step_L + 1] = 0;
            }
        }
        return;
    }

    // Shift to start at 1 (0 reserved for background).
    int final_label = block_label + 1;

    labels[xL] = is_internal_fg(info_byte, 0) ? final_label : 0;

    if (x + 1 < width) {
        labels[xL + 1] = is_internal_fg(info_byte, 1) ? final_label : 0;
    }

    if (y + 1 < height) {
        labels[xL + step_L] = is_internal_fg(info_byte, 2) ? final_label : 0;

        if (x + 1 < width) {
            labels[xL + step_L + 1] = is_internal_fg(info_byte, 3) ? final_label : 0;
        }
    }
}
"""


@functools.cache
def _module() -> cupy.RawModule:
    """
    Compile and cache the BKE translation unit for the process.

    The :class:`cupy.RawModule` is built once on first use (NVRTC JIT for the
    active device) and memoized by :func:`functools.lru_cache`, so subsequent
    calls reuse the compiled module with no recompilation.

    Returns
    -------
    cupy.RawModule
        The compiled module exposing the four ``bke_*`` kernels.
    """
    return cupy.RawModule(code=_BKE_SOURCE, options=("--std=c++11",))


@functools.cache
def init_kernel() -> cupy.RawKernel:
    """
    Return the cached ``bke_init_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Init kernel; expects a ``const unsigned char*`` foreground image.
    """
    return _module().get_function("bke_init_kernel")


@functools.cache
def compress_kernel() -> cupy.RawKernel:
    """
    Return the cached standard ``bke_compress_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Standard ``bke`` path-compression kernel (find-and-compress).
    """
    return _module().get_function("bke_compress_kernel")


@functools.cache
def compress_ic_kernel() -> cupy.RawKernel:
    """
    Return the cached ``bke_compress_ic_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        ``bke_ic`` inline-compression path-compression kernel.
    """
    return _module().get_function("bke_compress_ic_kernel")


@functools.cache
def reduction_kernel() -> cupy.RawKernel:
    """
    Return the cached ``bke_reduction_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Atomic-union reduction kernel.
    """
    return _module().get_function("bke_reduction_kernel")


@functools.cache
def final_kernel() -> cupy.RawKernel:
    """
    Return the cached ``bke_final_labeling_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Final per-pixel labeling kernel.
    """
    return _module().get_function("bke_final_labeling_kernel")
