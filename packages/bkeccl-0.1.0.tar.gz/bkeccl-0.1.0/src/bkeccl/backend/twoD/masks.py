"""
2D one-hot component-mask expansion CUDA kernel and fast path.

Given a *dense* ``int32`` label map (background 0, components ``1..N``) and
the component count ``N``, :func:`onehot_masks_2D` produces the
``(N, H, W)`` boolean stack where plane ``k`` is the binary mask of
component ``k + 1``. This is the device replacement for the host
``labels == arange(1, N + 1)[:, None, None]`` broadcast: a single scatter
over ``H * W`` label pixels into a pre-zeroed output, so the cost is one
memset of the ``N * H * W`` payload plus ``H * W`` one-byte writes rather
than ``N * H * W`` compares.

Like :mod:`bkeccl.backend.twoD.algorithms`, this fast path performs **no
input validation whatsoever**. Every assumption below is caller-guaranteed
and a violation is undefined behavior, not a raised error:

- ``dense_labels`` is a 2D, C-contiguous ``cupy.ndarray`` of dtype
  ``int32`` whose values lie in ``0..n`` (background 0), on the current
  CUDA device.
- ``n`` is a non-negative Python ``int`` equal to the maximum label value.

Establishing these conditions is the responsibility of the higher-level
entry point (:mod:`bkeccl._masks`).
"""

from __future__ import annotations

import functools

import cupy
import numpy as np


__all__ = ["onehot_masks_2D"]

_ONEHOT_SOURCE = r"""
extern "C" __global__
void bke_onehot_masks(const int* __restrict__ labels,
                      unsigned char* __restrict__ out,
                      long long plane) {
    long long p = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= plane) {
        return;
    }
    int v = labels[p];
    if (v != 0) {
        out[(long long)(v - 1) * plane + p] = 1;
    }
}
"""

_ONEHOT_THREADS = 256


@functools.cache
def _onehot_kernel() -> cupy.RawKernel:
    """
    Return the cached one-hot mask scatter kernel.

    One thread per label pixel writes ``out[(label - 1) * plane + p] = 1``
    for foreground pixels into a pre-zeroed ``(N, H, W)`` byte buffer. The
    :class:`cupy.RawModule` is compiled once on first use and cached for the
    process.

    Returns
    -------
    cupy.RawKernel
        Kernel ``bke_onehot_masks(const int* labels, unsigned char* out,
        long long plane)``.
    """
    return cupy.RawModule(code=_ONEHOT_SOURCE, options=("--std=c++11",)).get_function("bke_onehot_masks")


def onehot_masks_2D(dense_labels: cupy.ndarray, n: int) -> cupy.ndarray:
    """
    Expand a dense label map into a per-component boolean mask stack.

    Allocates a pre-zeroed ``(n, H, W)`` ``bool`` buffer and scatters each
    foreground pixel into its component's plane with one device launch. For
    ``n == 0`` the empty ``(0, H, W)`` stack is returned without a launch.

    Parameters
    ----------
    dense_labels : cupy.ndarray
        2D, C-contiguous ``int32`` map with values in ``0..n`` (background
        0), on the current CUDA device.
    n : int
        Component count (the maximum label value).

    Returns
    -------
    cupy.ndarray
        ``(n, H, W)`` C-contiguous ``bool`` array; plane ``k`` is the mask
        of component ``k + 1``.
    """
    h, w = dense_labels.shape
    if n == 0:
        return cupy.empty((0, h, w), dtype=cupy.bool_)

    out = cupy.zeros((n, h, w), dtype=cupy.bool_)
    plane = np.int64(h * w)
    blocks = (int(plane) + _ONEHOT_THREADS - 1) // _ONEHOT_THREADS
    _onehot_kernel()((blocks,), (_ONEHOT_THREADS,), (dense_labels, out, plane))
    return out
