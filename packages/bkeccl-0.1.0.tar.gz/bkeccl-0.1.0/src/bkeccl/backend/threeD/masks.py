"""
3D one-hot component-mask expansion CUDA kernel and fast path.

Given a *dense* ``int32`` label volume (background 0, components ``1..N``)
and the component count ``N``, :func:`onehot_masks_3D` produces the
``(N, D, H, W)`` boolean stack where volume ``k`` is the binary mask of
component ``k + 1``. This is the device replacement for the host
``labels == arange(1, N + 1)[:, None, None, None]`` broadcast: a single
scatter over ``D * H * W`` label voxels into a pre-zeroed output, so the
cost is one memset of the ``N * D * H * W`` payload plus ``D * H * W``
one-byte writes rather than ``N * D * H * W`` compares.

Like :mod:`bkeccl.backend.threeD.algorithms`, this fast path performs **no
input validation whatsoever**. Every assumption below is caller-guaranteed
and a violation is undefined behavior, not a raised error:

- ``dense_labels`` is a 3D, C-contiguous ``cupy.ndarray`` of dtype
  ``int32`` whose values lie in ``0..n`` (background 0), on the current
  CUDA device.
- ``n`` is a non-negative Python ``int`` equal to the maximum label value.

Establishing these conditions is the responsibility of the higher-level
entry point (:mod:`bkeccl._masks`).
"""

from __future__ import annotations

import functools

import cupy
import numpy as np


__all__ = ["onehot_masks_3D"]

_ONEHOT_SOURCE = r"""
extern "C" __global__
void bke3d_onehot_masks(const int* __restrict__ labels,
                        unsigned char* __restrict__ out,
                        long long volume) {
    long long p = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= volume) {
        return;
    }
    int v = labels[p];
    if (v != 0) {
        out[(long long)(v - 1) * volume + p] = 1;
    }
}
"""

_ONEHOT_THREADS = 256


@functools.cache
def _onehot_kernel() -> cupy.RawKernel:
    """
    Return the cached 3D one-hot mask scatter kernel.

    One thread per label voxel writes ``out[(label - 1) * volume + p] = 1``
    for foreground voxels into a pre-zeroed ``(N, D, H, W)`` byte buffer.
    The :class:`cupy.RawModule` is compiled once on first use and cached for
    the process.

    Returns
    -------
    cupy.RawKernel
        Kernel ``bke3d_onehot_masks(const int* labels, unsigned char* out,
        long long volume)``.
    """
    return cupy.RawModule(code=_ONEHOT_SOURCE, options=("--std=c++11",)).get_function("bke3d_onehot_masks")


def onehot_masks_3D(dense_labels: cupy.ndarray, n: int) -> cupy.ndarray:
    """
    Expand a dense label volume into a per-component boolean mask stack.

    Allocates a pre-zeroed ``(n, D, H, W)`` ``bool`` buffer and scatters
    each foreground voxel into its component's volume with one device
    launch. For ``n == 0`` the empty ``(0, D, H, W)`` stack is returned
    without a launch.

    Parameters
    ----------
    dense_labels : cupy.ndarray
        3D, C-contiguous ``int32`` volume with values in ``0..n``
        (background 0), on the current CUDA device.
    n : int
        Component count (the maximum label value).

    Returns
    -------
    cupy.ndarray
        ``(n, D, H, W)`` C-contiguous ``bool`` array; volume ``k`` is the
        mask of component ``k + 1``.
    """
    d, h, w = dense_labels.shape
    if n == 0:
        return cupy.empty((0, d, h, w), dtype=cupy.bool_)

    out = cupy.zeros((n, d, h, w), dtype=cupy.bool_)
    volume = np.int64(d * h * w)
    blocks = (int(volume) + _ONEHOT_THREADS - 1) // _ONEHOT_THREADS
    _onehot_kernel()((blocks,), (_ONEHOT_THREADS,), (dense_labels, out, volume))
    return out
