"""
3D Block-based Komura Equivalence (BKE) CUDA kernels and module accessors.

The device algorithm is the 3D variant of the BKE labeler of Allegretti,
Bolelli, Cancilla, Grana, *"Optimized Block-Based Algorithms to Label
Connected Components on GPUs"* (IEEE TPDS 2019), Section 5.3 ("3D
Variations"), operating on 2x2x2 voxel blocks at full 26-connectivity. The
``__global__`` kernels run in the fixed order Init -> Compress -> Reduction
-> Compress -> FinalLabel, entirely in place in an ``int32`` label buffer,
mirroring the 2D pipeline. The Compress step has two compile-time-distinct
kernels selected by algorithm: ``bke3d_compress_kernel`` (standard
find-and-compress) and ``bke3d_compress_ic_kernel`` (inline compression).

Per Section 5.3 the 2D 8-bit info byte becomes a 21-bit info integer: bits
0..7 are the 8 internal-voxel foreground flags and bits 8..20 are the
``Union`` flags for the 13 already-processed neighbor blocks. Neighbor reads
are gated by the 64-bit neighbor bitset of the paper's Fig. 9: a 4x4x4 cube
centered on block X, voxel ``bit = cz*16 + cy*4 + cx``, with X's own 2x2x2
block at cube coordinates ``1..2`` on each axis. The bitset is the OR, over
X's foreground internal voxels, of each voxel's 27-cell cube neighborhood
mask; a prior neighbor block connects iff one of its in-cube voxel bits is
set in the bitset and foreground in the input. The eight cube neighborhood
masks are computed once on the host and embedded as device constants.

The source is a single ``extern "C"`` translation unit using only built-in
C types, so it needs no ``<cstdint>`` preamble and no C++ name mangling. The
init kernel consumes a ``const unsigned char*`` foreground volume; callers
normalize ``bool`` inputs with a zero-copy ``view(uint8)`` upstream. The
compiled :class:`cupy.RawModule` is built once and cached for the process.
"""

from __future__ import annotations

import functools

import cupy


__all__ = [
    "init_kernel_3d",
    "compress_kernel_3d",
    "compress_ic_kernel_3d",
    "reduction_kernel_3d",
    "final_kernel_3d",
]

# The 13 already-processed neighbor blocks in block-raster order
# (z slow, y, x fast), as (dz, dy, dx) block deltas. The list index is the
# ``Union``-flag bit offset within the info integer (bit 8 + k).
_PRIOR_BLOCKS: tuple[tuple[int, int, int], ...] = (
    (-1, -1, -1),
    (-1, -1, 0),
    (-1, -1, 1),
    (-1, 0, -1),
    (-1, 0, 0),
    (-1, 0, 1),
    (-1, 1, -1),
    (-1, 1, 0),
    (-1, 1, 1),
    (0, -1, -1),
    (0, -1, 0),
    (0, -1, 1),
    (0, 0, -1),
)

# Internal-voxel offsets within a 2x2x2 block; list index is the info
# bit i == vz*4 + vy*2 + vx.
_VOXELS: tuple[tuple[int, int, int], ...] = (
    (0, 0, 0),
    (0, 0, 1),
    (0, 1, 0),
    (0, 1, 1),
    (1, 0, 0),
    (1, 0, 1),
    (1, 1, 0),
    (1, 1, 1),
)


def _neighbor_bitset_masks() -> list[int]:
    """
    Compute the eight Fig. 9 cube neighborhood masks.

    For each internal X voxel (info bit ``i == vz*4 + vy*2 + vx``) the voxel
    sits at cube coordinate ``(vz+1, vy+1, vx+1)`` of the 4x4x4 cube. Its
    mask is the OR of every cube bit within Chebyshev distance 1 (the
    27-cell neighborhood, clipped to the cube), where the cube position is
    ``bit = cz*16 + cy*4 + cx``.

    Returns
    -------
    list[int]
        Eight 64-bit masks indexed by the internal-voxel info bit.
    """
    masks: list[int] = []
    for vz, vy, vx in _VOXELS:
        cz0, cy0, cx0 = vz + 1, vy + 1, vx + 1
        mask = 0
        for cz in range(max(0, cz0 - 1), min(3, cz0 + 1) + 1):
            for cy in range(max(0, cy0 - 1), min(3, cy0 + 1) + 1):
                for cx in range(max(0, cx0 - 1), min(3, cx0 + 1) + 1):
                    mask |= 1 << (cz * 16 + cy * 4 + cx)
        masks.append(mask)
    return masks


def _c_array(name: str, ctype: str, values: list[int], suffix: str = "") -> str:
    """
    Render a ``__device__ const`` C array initializer line.

    Parameters
    ----------
    name : str
        C identifier for the array.
    ctype : str
        Element C type.
    values : list[int]
        Array contents.
    suffix : str, optional
        Integer literal suffix (e.g. ``"ULL"``), by default ``""``.

    Returns
    -------
    str
        A single ``__device__ const`` declaration line.
    """
    body = ", ".join(f"{v}{suffix}" for v in values)
    return f"__device__ const {ctype} {name}[{len(values)}] = {{ {body} }};"


def _build_source() -> str:
    """
    Assemble the 3D BKE CUDA translation unit.

    The 13 prior-block deltas and the eight Fig. 9 neighbor bitset masks are
    materialized as embedded device constants so the kernels carry no host
    state.

    Returns
    -------
    str
        The complete ``extern "C"`` CUDA source.
    """
    constants = "\n".join(
        (
            _c_array("PRIOR_DZ", "int", [d[0] for d in _PRIOR_BLOCKS]),
            _c_array("PRIOR_DY", "int", [d[1] for d in _PRIOR_BLOCKS]),
            _c_array("PRIOR_DX", "int", [d[2] for d in _PRIOR_BLOCKS]),
            _c_array("VOX_DZ", "int", [v[0] for v in _VOXELS]),
            _c_array("VOX_DY", "int", [v[1] for v in _VOXELS]),
            _c_array("VOX_DX", "int", [v[2] for v in _VOXELS]),
            _c_array("NEIGH_MASK", "unsigned long long", _neighbor_bitset_masks(), suffix="ULL"),
        )
    )

    return (
        r"""
#define K_BACKGROUND_PARENT (-1)
#define N_PRIOR 13

"""
        + constants
        + r"""

__device__ __forceinline__ int find(int* labels, int index) {
    while (labels[index] != index) {
        index = labels[index];
    }
    return index;
}

__device__ __forceinline__ int find_n_compress(int* labels, int index) {
    int root = find(labels, index);
    labels[index] = root;
    return root;
}

__device__ __forceinline__ int find_inline_compress(int* labels, int index) {
    int id = index;
    while (labels[index] != index) {
        index = labels[index];
        labels[id] = index;
    }
    return index;
}

__device__ void atomic_union(int* labels, int index_a, int index_b) {
    bool done = false;
    while (!done) {
        index_a = find(labels, index_a);
        index_b = find(labels, index_b);

        if (index_a < index_b) {
            int index_old = atomicMin(&labels[index_b], index_a);
            done = (index_old == index_b);
            index_b = index_old;
        } else if (index_b < index_a) {
            int index_old = atomicMin(&labels[index_a], index_b);
            done = (index_old == index_a);
            index_a = index_old;
        } else {
            done = true;
        }
    }
}

__device__ __forceinline__ bool has_bit_u64(unsigned long long bitset, int pos) {
    return (bitset >> pos) & 1ULL;
}

// The info integer is stored in the first spare voxel cell of the block:
// the +x voxel, else the +y voxel, else the +z voxel. A single-voxel block
// at an all-odd far corner has no spare cell; its foreground state is the
// sign of labels[xL] (>= 0 means a real block id), so its info reduces to
// bit 0 set (the corner voxel is foreground) with no Union flags.
__device__ __forceinline__ int info_cell_index(
    const long long xL,
    const long long x,
    const long long y,
    const long long z,
    const long long width,
    const long long height,
    const long long depth,
    const long long step_y,
    const long long step_z) {

    if (x + 1 < width)  { return (int)(xL + 1); }
    if (y + 1 < height) { return (int)(xL + step_y); }
    if (z + 1 < depth)  { return (int)(xL + step_z); }
    return -1;
}

__device__ __forceinline__ int read_info(
    const int* __restrict__ labels,
    const long long xL,
    const long long x,
    const long long y,
    const long long z,
    const long long width,
    const long long height,
    const long long depth,
    const long long step_y,
    const long long step_z) {

    int cell = info_cell_index(xL, x, y, z, width, height, depth, step_y, step_z);
    if (cell >= 0) {
        return labels[cell];
    }
    // Single-voxel corner block: only the foreground bit is recoverable.
    return labels[xL] >= 0 ? 1 : 0;
}

extern "C" __global__ void bke3d_init_kernel(
    const unsigned char* __restrict__ input,
    int* __restrict__ labels,
    const long long depth,
    const long long height,
    const long long width,
    const long long step_z,
    const long long step_y) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;
    const long long bz = blockIdx.z * blockDim.z + threadIdx.z;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;
    const long long blocks_d = (depth + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h || bz >= blocks_d) return;

    const long long x = bx * 2;
    const long long y = by * 2;
    const long long z = bz * 2;
    const long long xL = z * step_z + y * step_y + x;

    int info = 0;
    unsigned long long bit_set = 0ULL;

    for (int i = 0; i < 8; ++i) {
        const long long vz = z + VOX_DZ[i];
        const long long vy = y + VOX_DY[i];
        const long long vx = x + VOX_DX[i];
        if (vz < depth && vy < height && vx < width) {
            if (input[vz * step_z + vy * step_y + vx] > 0) {
                info |= (1 << i);
                bit_set |= NEIGH_MASK[i];
            }
        }
    }

    // Background block: every internal voxel is background.
    if ((info & 0xFF) == 0) {
        labels[xL] = K_BACKGROUND_PARENT;
        int cell = info_cell_index(xL, x, y, z, width, height, depth, step_y, step_z);
        if (cell >= 0) {
            labels[cell] = 0;
        }
        return;
    }

    int min_label = (int)xL;

    for (int k = 0; k < N_PRIOR; ++k) {
        const long long nz0 = z + 2 * PRIOR_DZ[k];
        const long long ny0 = y + 2 * PRIOR_DY[k];
        const long long nx0 = x + 2 * PRIOR_DX[k];
        if (nz0 < 0 || ny0 < 0 || nx0 < 0 ||
            nz0 >= depth || ny0 >= height || nx0 >= width) {
            continue;
        }

        bool connected = false;
        for (int j = 0; j < 8 && !connected; ++j) {
            const long long wz = nz0 + VOX_DZ[j];
            const long long wy = ny0 + VOX_DY[j];
            const long long wx = nx0 + VOX_DX[j];
            if (wz >= depth || wy >= height || wx >= width) continue;

            const int cz = (int)(wz - z) + 1;
            const int cy = (int)(wy - y) + 1;
            const int cx = (int)(wx - x) + 1;
            if (cz < 0 || cz > 3 || cy < 0 || cy > 3 || cx < 0 || cx > 3) continue;

            const int pos = cz * 16 + cy * 4 + cx;
            if (has_bit_u64(bit_set, pos) && input[wz * step_z + wy * step_y + wx] > 0) {
                connected = true;
            }
        }

        if (connected) {
            int nb_label = (int)(nz0 * step_z + ny0 * step_y + nx0);
            if (nb_label < min_label) {
                min_label = nb_label;
            }
            info |= (1 << (8 + k));
        }
    }

    labels[xL] = min_label;

    int cell = info_cell_index(xL, x, y, z, width, height, depth, step_y, step_z);
    if (cell >= 0) {
        labels[cell] = info;
    }
}

extern "C" __global__ void bke3d_compress_kernel(
    int* __restrict__ labels,
    const long long depth,
    const long long height,
    const long long width,
    const long long step_z,
    const long long step_y) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;
    const long long bz = blockIdx.z * blockDim.z + threadIdx.z;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;
    const long long blocks_d = (depth + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h || bz >= blocks_d) return;

    const long long xL = (bz * 2) * step_z + (by * 2) * step_y + (bx * 2);

    if (labels[xL] < 0) return;

    find_n_compress(labels, (int)xL);
}

extern "C" __global__ void bke3d_compress_ic_kernel(
    int* __restrict__ labels,
    const long long depth,
    const long long height,
    const long long width,
    const long long step_z,
    const long long step_y) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;
    const long long bz = blockIdx.z * blockDim.z + threadIdx.z;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;
    const long long blocks_d = (depth + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h || bz >= blocks_d) return;

    const long long xL = (bz * 2) * step_z + (by * 2) * step_y + (bx * 2);

    if (labels[xL] < 0) return;

    find_inline_compress(labels, (int)xL);
}

extern "C" __global__ void bke3d_reduction_kernel(
    int* __restrict__ labels,
    const long long depth,
    const long long height,
    const long long width,
    const long long step_z,
    const long long step_y) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;
    const long long bz = blockIdx.z * blockDim.z + threadIdx.z;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;
    const long long blocks_d = (depth + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h || bz >= blocks_d) return;

    const long long x = bx * 2;
    const long long y = by * 2;
    const long long z = bz * 2;
    const long long xL = z * step_z + y * step_y + x;

    if (labels[xL] < 0) return;

    int info = read_info(labels, xL, x, y, z, width, height, depth, step_y, step_z);

    if ((info & 0xFF) == 0) return;

    for (int k = 0; k < N_PRIOR; ++k) {
        if (((info >> (8 + k)) & 1) == 0) continue;

        const long long nz0 = z + 2 * PRIOR_DZ[k];
        const long long ny0 = y + 2 * PRIOR_DY[k];
        const long long nx0 = x + 2 * PRIOR_DX[k];
        if (nz0 < 0 || ny0 < 0 || nx0 < 0 ||
            nz0 >= depth || ny0 >= height || nx0 >= width) {
            continue;
        }

        int nb_label = (int)(nz0 * step_z + ny0 * step_y + nx0);
        atomic_union(labels, (int)xL, nb_label);
    }
}

extern "C" __global__ void bke3d_final_labeling_kernel(
    int* __restrict__ labels,
    const long long depth,
    const long long height,
    const long long width,
    const long long step_z,
    const long long step_y) {

    const long long bx = blockIdx.x * blockDim.x + threadIdx.x;
    const long long by = blockIdx.y * blockDim.y + threadIdx.y;
    const long long bz = blockIdx.z * blockDim.z + threadIdx.z;

    const long long blocks_w = (width + 1) / 2;
    const long long blocks_h = (height + 1) / 2;
    const long long blocks_d = (depth + 1) / 2;

    if (bx >= blocks_w || by >= blocks_h || bz >= blocks_d) return;

    const long long x = bx * 2;
    const long long y = by * 2;
    const long long z = bz * 2;
    const long long xL = z * step_z + y * step_y + x;

    int block_label = labels[xL];
    int info = read_info(labels, xL, x, y, z, width, height, depth, step_y, step_z);

    // Background block: zero every in-bounds internal voxel.
    if ((info & 0xFF) == 0) {
        for (int i = 0; i < 8; ++i) {
            const long long vz = z + VOX_DZ[i];
            const long long vy = y + VOX_DY[i];
            const long long vx = x + VOX_DX[i];
            if (vz < depth && vy < height && vx < width) {
                labels[vz * step_z + vy * step_y + vx] = 0;
            }
        }
        return;
    }

    // Shift to start at 1 (0 reserved for background).
    int final_label = block_label + 1;

    for (int i = 0; i < 8; ++i) {
        const long long vz = z + VOX_DZ[i];
        const long long vy = y + VOX_DY[i];
        const long long vx = x + VOX_DX[i];
        if (vz < depth && vy < height && vx < width) {
            labels[vz * step_z + vy * step_y + vx] = ((info >> i) & 1) ? final_label : 0;
        }
    }
}
"""
    )


@functools.cache
def _module() -> cupy.RawModule:
    """
    Compile and cache the 3D BKE translation unit for the process.

    Returns
    -------
    cupy.RawModule
        The compiled module exposing the five ``bke3d_*`` kernels.
    """
    return cupy.RawModule(code=_build_source(), options=("--std=c++11",))


@functools.cache
def init_kernel_3d() -> cupy.RawKernel:
    """
    Return the cached ``bke3d_init_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Init kernel; expects a ``const unsigned char*`` foreground volume.
    """
    return _module().get_function("bke3d_init_kernel")


@functools.cache
def compress_kernel_3d() -> cupy.RawKernel:
    """
    Return the cached standard ``bke3d_compress_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Standard ``bke`` path-compression kernel (find-and-compress).
    """
    return _module().get_function("bke3d_compress_kernel")


@functools.cache
def compress_ic_kernel_3d() -> cupy.RawKernel:
    """
    Return the cached ``bke3d_compress_ic_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        ``bke_ic`` inline-compression path-compression kernel.
    """
    return _module().get_function("bke3d_compress_ic_kernel")


@functools.cache
def reduction_kernel_3d() -> cupy.RawKernel:
    """
    Return the cached ``bke3d_reduction_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Atomic-union reduction kernel.
    """
    return _module().get_function("bke3d_reduction_kernel")


@functools.cache
def final_kernel_3d() -> cupy.RawKernel:
    """
    Return the cached ``bke3d_final_labeling_kernel`` callable.

    Returns
    -------
    cupy.RawKernel
        Final per-voxel labeling kernel.
    """
    return _module().get_function("bke3d_final_labeling_kernel")
