"""
3D BKE connected-component labeling fast paths.

Each public function is a dedicated fast path for one exact combination of
``{bke, bke_ic} x {raw, dense} x {pre_alloc, no_pre_alloc}``, the 3D analog
of :mod:`bkeccl.backend.twoD.algorithms`. The functions make strict
assumptions and perform **no input validation, normalization, emptiness
checks, or device management whatsoever**: there are no guards. Every
assumption below is taken on faith and a violation is undefined behavior
(wrong result, crash, or illegal memory access), not a raised error.
Establishing these conditions is the responsibility of the higher-level
entry point (:mod:`bkeccl._base`).

Assumptions for every function (caller-guaranteed, unchecked):

- ``input_data`` is a 3D ``cupy.ndarray`` of dtype ``uint8`` (non-zero is
  foreground), C-contiguous, with ``ndim == 3`` and axis order
  ``(depth, height, width)``. ``bool`` inputs must be reinterpreted with a
  zero-copy ``view(cupy.uint8)`` upstream.
- ``input_data`` is non-empty in the sense the caller intends; these
  functions do not special-case ``size == 0`` or zero-length axes.
- ``label_output`` (``*_pre_alloc`` variants) is a 3D, C-contiguous
  ``cupy.ndarray`` of dtype ``int32``, the same shape as ``input_data``, on
  the same CUDA device.
- All arrays reside on the current CUDA device; launches use the current
  stream.

``raw`` variants return the native sparse BKE labels (positive root-raster
ids, background 0). ``dense`` variants additionally renumber to ``1..N`` on
device with no host synchronization and return ``(labels, count)`` where
``count`` is a 0-dim ``int32`` device array.
"""

from __future__ import annotations

import functools

import cupy
import numpy as np

from bkeccl.backend.threeD import kernels


__all__ = [
    "ccl_bke_3D_raw_no_pre_alloc",
    "ccl_bke_ic_3D_raw_no_pre_alloc",
    "ccl_bke_3D_raw_pre_alloc",
    "ccl_bke_ic_3D_raw_pre_alloc",
    "ccl_bke_3D_dense_no_pre_alloc",
    "ccl_bke_ic_3D_dense_no_pre_alloc",
    "ccl_bke_3D_dense_pre_alloc",
    "ccl_bke_ic_3D_dense_pre_alloc",
]

_THREADS = (8, 8, 8)


@functools.cache
def _gather_kernel() -> cupy.ElementwiseKernel:
    """
    Return the cached in-place sparse-to-dense gather kernel.

    Maps each label value ``v`` to its dense id ``scan[v]`` with a single
    1:1 elementwise pass, reading and writing the same buffer. Background
    (``v == 0``) maps to ``scan[0] == 0`` by construction.

    Returns
    -------
    cupy.ElementwiseKernel
        Kernel computing ``dense = scan[sparse]`` in place.
    """
    return cupy.ElementwiseKernel(
        "int32 sparse, raw int32 scan",
        "int32 dense",
        "dense = scan[sparse];",
        "bke3d_dense_gather",
    )


def _bke3d_grid(out: cupy.ndarray) -> tuple[tuple[int, int, int], np.int64, np.int64, np.int64, np.int64, np.int64]:
    """
    Compute the launch grid and ``int64`` shape/step scalars for ``out``.

    The grid of 8x8x8 thread blocks tiles the
    ``(width+1)//2 x (height+1)//2 x (depth+1)//2`` block grid the 3D BKE
    kernels operate on. For a C-contiguous ``(D, H, W)`` buffer the element
    strides are ``step_z == H*W`` and ``step_y == W`` (the innermost stride
    is 1), shared by the ``uint8`` input volume and the ``int32`` label
    buffer.

    Parameters
    ----------
    out : cupy.ndarray
        3D C-contiguous ``int32`` label buffer.

    Returns
    -------
    tuple
        The launch ``grid`` and the ``depth``, ``height``, ``width``,
        ``step_z``, ``step_y`` kernel scalars.
    """
    depth, height, width = int(out.shape[0]), int(out.shape[1]), int(out.shape[2])

    blocks_w = (width + 1) // 2
    blocks_h = (height + 1) // 2
    blocks_d = (depth + 1) // 2
    grid = (
        (blocks_w + _THREADS[0] - 1) // _THREADS[0],
        (blocks_h + _THREADS[1] - 1) // _THREADS[1],
        (blocks_d + _THREADS[2] - 1) // _THREADS[2],
    )

    d = np.int64(depth)
    h = np.int64(height)
    w = np.int64(width)
    step_z = np.int64(height * width)
    step_y = np.int64(width)
    return grid, d, h, w, step_z, step_y


def _label_in_place_bke(input_data: cupy.ndarray, out: cupy.ndarray) -> None:
    """
    Run the standard ``bke`` five-launch 3D pipeline in place on ``out``.

    Launches Init -> Compress -> Reduction -> Compress -> FinalLabel using
    the standard find-and-compress kernel for both Compress launches.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.
    out : cupy.ndarray
        3D C-contiguous ``int32`` label buffer, same shape as ``input_data``.
    """
    grid, d, h, w, step_z, step_y = _bke3d_grid(out)

    init_k = kernels.init_kernel_3d()
    compress_k = kernels.compress_kernel_3d()
    reduction_k = kernels.reduction_kernel_3d()
    final_k = kernels.final_kernel_3d()

    init_k(grid, _THREADS, (input_data, out, d, h, w, step_z, step_y))
    compress_k(grid, _THREADS, (out, d, h, w, step_z, step_y))
    reduction_k(grid, _THREADS, (out, d, h, w, step_z, step_y))
    compress_k(grid, _THREADS, (out, d, h, w, step_z, step_y))
    final_k(grid, _THREADS, (out, d, h, w, step_z, step_y))


def _label_in_place_bke_ic(input_data: cupy.ndarray, out: cupy.ndarray) -> None:
    """
    Run the ``bke_ic`` (inline-compression) five-launch 3D pipeline in place.

    Launches Init -> Compress -> Reduction -> Compress -> FinalLabel using
    the inline-compression kernel for both Compress launches.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.
    out : cupy.ndarray
        3D C-contiguous ``int32`` label buffer, same shape as ``input_data``.
    """
    grid, d, h, w, step_z, step_y = _bke3d_grid(out)

    init_k = kernels.init_kernel_3d()
    compress_ic_k = kernels.compress_ic_kernel_3d()
    reduction_k = kernels.reduction_kernel_3d()
    final_k = kernels.final_kernel_3d()

    init_k(grid, _THREADS, (input_data, out, d, h, w, step_z, step_y))
    compress_ic_k(grid, _THREADS, (out, d, h, w, step_z, step_y))
    reduction_k(grid, _THREADS, (out, d, h, w, step_z, step_y))
    compress_ic_k(grid, _THREADS, (out, d, h, w, step_z, step_y))
    final_k(grid, _THREADS, (out, d, h, w, step_z, step_y))


def _dense_relabel(out: cupy.ndarray) -> tuple[cupy.ndarray, cupy.ndarray]:
    """
    Densely renumber a sparse BKE label volume in place on device.

    A ``uint8`` mark-present over the sparse root-raster ids -> inclusive
    scan (``cupy.cumsum``, CUB-backed) -> fused in-place gather. ``out`` is
    overwritten with the dense ``1..N`` map and the return aliases it. The
    ``count`` is the last inclusive-scan element, produced device-side with
    no host synchronization.

    Parameters
    ----------
    out : cupy.ndarray
        3D ``int32`` sparse label volume (background 0, positive
        root-raster ids). Overwritten in place with the dense map.

    Returns
    -------
    tuple[cupy.ndarray, cupy.ndarray]
        ``out``, now holding the dense ``int32`` ``(D, H, W)`` map
        (background 0, components ``1..N``), and the 0-dim ``int32`` device
        component count.
    """
    n = out.size
    flat = out.reshape(-1)

    present = cupy.zeros(n + 1, dtype=cupy.uint8)
    present[flat] = 1
    present[0] = 0  # Background never consumes a dense id.
    scan = cupy.cumsum(present, dtype=cupy.int32)  # Inclusive scan, CUB-backed.
    _gather_kernel()(out, scan, out)  # In place: out[i] = scan[out[i]].
    count = scan[n].reshape(())
    return out, count


def ccl_bke_3D_raw_no_pre_alloc(input_data: cupy.ndarray) -> cupy.ndarray:
    """
    Standard 3D BKE, sparse labels, allocating the output buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.

    Returns
    -------
    cupy.ndarray
        ``int32`` ``(D, H, W)`` sparse label volume; background 0.
    """
    out = cupy.empty(input_data.shape, dtype=cupy.int32)
    _label_in_place_bke(input_data, out)
    return out


def ccl_bke_ic_3D_raw_no_pre_alloc(input_data: cupy.ndarray) -> cupy.ndarray:
    """
    3D BKE InlineCompression, sparse labels, allocating the output buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.

    Returns
    -------
    cupy.ndarray
        ``int32`` ``(D, H, W)`` sparse label volume; background 0.
    """
    out = cupy.empty(input_data.shape, dtype=cupy.int32)
    _label_in_place_bke_ic(input_data, out)
    return out


def ccl_bke_3D_raw_pre_alloc(input_data: cupy.ndarray, label_output: cupy.ndarray) -> cupy.ndarray:
    """
    Standard 3D BKE, sparse labels, writing into a caller-supplied buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.
    label_output : cupy.ndarray
        3D C-contiguous ``int32`` buffer, same shape as ``input_data``, on
        the same device. Written in place; the return aliases it.

    Returns
    -------
    cupy.ndarray
        ``label_output``, holding the ``int32`` sparse label volume;
        background 0.
    """
    _label_in_place_bke(input_data, label_output)
    return label_output


def ccl_bke_ic_3D_raw_pre_alloc(input_data: cupy.ndarray, label_output: cupy.ndarray) -> cupy.ndarray:
    """
    3D BKE InlineCompression, sparse labels, writing into a caller buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.
    label_output : cupy.ndarray
        3D C-contiguous ``int32`` buffer, same shape as ``input_data``, on
        the same device. Written in place; the return aliases it.

    Returns
    -------
    cupy.ndarray
        ``label_output``, holding the ``int32`` sparse label volume;
        background 0.
    """
    _label_in_place_bke_ic(input_data, label_output)
    return label_output


def ccl_bke_3D_dense_no_pre_alloc(input_data: cupy.ndarray) -> tuple[cupy.ndarray, cupy.ndarray]:
    """
    Standard 3D BKE, dense ``1..N`` labels, allocating the output buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.

    Returns
    -------
    tuple[cupy.ndarray, cupy.ndarray]
        The dense ``int32`` ``(D, H, W)`` label volume (background 0,
        components ``1..N``) and the 0-dim ``int32`` device component count.
    """
    out = cupy.empty(input_data.shape, dtype=cupy.int32)
    _label_in_place_bke(input_data, out)
    return _dense_relabel(out)


def ccl_bke_ic_3D_dense_no_pre_alloc(input_data: cupy.ndarray) -> tuple[cupy.ndarray, cupy.ndarray]:
    """
    3D BKE InlineCompression, dense ``1..N`` labels, allocating the buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.

    Returns
    -------
    tuple[cupy.ndarray, cupy.ndarray]
        The dense ``int32`` ``(D, H, W)`` label volume (background 0,
        components ``1..N``) and the 0-dim ``int32`` device component count.
    """
    out = cupy.empty(input_data.shape, dtype=cupy.int32)
    _label_in_place_bke_ic(input_data, out)
    return _dense_relabel(out)


def ccl_bke_3D_dense_pre_alloc(
    input_data: cupy.ndarray, label_output: cupy.ndarray
) -> tuple[cupy.ndarray, cupy.ndarray]:
    """
    Standard 3D BKE, dense ``1..N`` labels, writing into a caller buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.
    label_output : cupy.ndarray
        3D C-contiguous ``int32`` buffer, same shape as ``input_data``, on
        the same device. Holds the dense labels on return; the returned map
        aliases it.

    Returns
    -------
    tuple[cupy.ndarray, cupy.ndarray]
        ``label_output`` holding the dense ``int32`` label volume
        (background 0, components ``1..N``) and the 0-dim ``int32`` device
        component count.
    """
    _label_in_place_bke(input_data, label_output)
    return _dense_relabel(label_output)


def ccl_bke_ic_3D_dense_pre_alloc(
    input_data: cupy.ndarray, label_output: cupy.ndarray
) -> tuple[cupy.ndarray, cupy.ndarray]:
    """
    3D BKE InlineCompression, dense ``1..N`` labels, writing into a buffer.

    Parameters
    ----------
    input_data : cupy.ndarray
        3D C-contiguous ``uint8`` foreground volume.
    label_output : cupy.ndarray
        3D C-contiguous ``int32`` buffer, same shape as ``input_data``, on
        the same device. Holds the dense labels on return; the returned map
        aliases it.

    Returns
    -------
    tuple[cupy.ndarray, cupy.ndarray]
        ``label_output`` holding the dense ``int32`` label volume
        (background 0, components ``1..N``) and the 0-dim ``int32`` device
        component count.
    """
    _label_in_place_bke_ic(input_data, label_output)
    return _dense_relabel(label_output)
