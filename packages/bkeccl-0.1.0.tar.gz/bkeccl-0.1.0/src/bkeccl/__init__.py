from __future__ import annotations

from importlib.metadata import (
    PackageNotFoundError,
    version,
)


try:
    import cupy as _cupy  # noqa: F401
except ImportError as exc:
    raise ImportError(
        "bkeccl requires CuPy, which is not installed. CuPy ships as a "
        "CUDA-version-specific wheel, so bkeccl does not pin one for you. "
        "Install the wheel matching your CUDA toolkit, e.g. "
        "`pip install cupy-cuda13x` (CUDA 13.x) or `pip install cupy-cuda12x` "
        "(CUDA 12.x); see https://docs.cupy.dev/en/stable/install.html for "
        "other CUDA versions and the bundled-toolkit `[ctk]` extra."
    ) from exc

from bkeccl._base import (
    CCLInput,
    SupportsDLPack,
    ccl,
)
from bkeccl._masks import (
    ccl_masks,
    masks_from_labels,
)
from bkeccl.specialize import (
    make_ccl_2D,
    make_ccl_3D,
)


try:
    __version__ = version("bkeccl")
except PackageNotFoundError:  # Source tree without installed distribution metadata.
    __version__ = "0.0.0+unknown"

__all__ = [
    "ccl",
    "ccl_masks",
    "masks_from_labels",
    "make_ccl_2D",
    "make_ccl_3D",
    "SupportsDLPack",
    "CCLInput",
    "__version__",
]
