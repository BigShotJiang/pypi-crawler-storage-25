"""
High-level connected-component labeling entry point.

:func:`ccl` is the public, safe surface over the strict BKE fast paths in
:mod:`bkeccl.backend.twoD.algorithms` (2D) and
:mod:`bkeccl.backend.threeD.algorithms` (3D). The fast paths take every
input property on faith; this layer is where the contract they assume is
actually established: dtype/foreground normalization, C-contiguity,
dimensionality, ``label_output`` compatibility, and the empty-input guard.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import (
    Any,
    Literal,
    Protocol,
    TypeAlias,
    overload,
    runtime_checkable,
)

import cupy

from bkeccl.backend.threeD import algorithms as _alg3d
from bkeccl.backend.twoD import algorithms as _alg


__all__ = ["ccl", "SupportsDLPack", "CCLInput"]


@runtime_checkable
class SupportsDLPack(Protocol):
    """
    A GPU tensor exposing the DLPack producer interface.

    This is the structural contract :func:`bkeccl.ccl` actually requires of
    a non-:class:`cupy.ndarray` input: the two methods the Array API DLPack
    exchange defines. ``torch.Tensor``, ``jax.Array``, Triton tensors, and
    other framework device arrays satisfy it structurally with no import
    dependency on those frameworks. The ``__dlpack__`` capsule is opaque
    (the producers themselves type it as ``Any``); ``__dlpack_device__``
    returns the standardized ``(device_type, device_id)`` pair.
    """

    def __dlpack__(self, *, stream: int | None = ...) -> Any: ...

    def __dlpack_device__(self) -> tuple[int, int]: ...


# Public input contract: an on-device cupy array, or any DLPack-exposing
# GPU tensor (zero-copy imported via cupy.from_dlpack). TypeAlias (rather
# than the 3.12 `type` statement) keeps this importable on requires-python
# >=3.10.
CCLInput: TypeAlias = cupy.ndarray | SupportsDLPack

# (algorithm, output_mode, pre_alloc) -> fast path.
_DISPATCH_2D: dict[tuple[str, str, bool], Callable[..., Any]] = {
    ("bke", "raw", False): _alg.ccl_bke_2D_raw_no_pre_alloc,
    ("bke", "raw", True): _alg.ccl_bke_2D_raw_pre_alloc,
    ("bke_ic", "raw", False): _alg.ccl_bke_ic_2D_raw_no_pre_alloc,
    ("bke_ic", "raw", True): _alg.ccl_bke_ic_2D_raw_pre_alloc,
    ("bke", "dense", False): _alg.ccl_bke_2D_dense_no_pre_alloc,
    ("bke", "dense", True): _alg.ccl_bke_2D_dense_pre_alloc,
    ("bke_ic", "dense", False): _alg.ccl_bke_ic_2D_dense_no_pre_alloc,
    ("bke_ic", "dense", True): _alg.ccl_bke_ic_2D_dense_pre_alloc,
}

_DISPATCH_3D: dict[tuple[str, str, bool], Callable[..., Any]] = {
    ("bke", "raw", False): _alg3d.ccl_bke_3D_raw_no_pre_alloc,
    ("bke", "raw", True): _alg3d.ccl_bke_3D_raw_pre_alloc,
    ("bke_ic", "raw", False): _alg3d.ccl_bke_ic_3D_raw_no_pre_alloc,
    ("bke_ic", "raw", True): _alg3d.ccl_bke_ic_3D_raw_pre_alloc,
    ("bke", "dense", False): _alg3d.ccl_bke_3D_dense_no_pre_alloc,
    ("bke", "dense", True): _alg3d.ccl_bke_3D_dense_pre_alloc,
    ("bke_ic", "dense", False): _alg3d.ccl_bke_ic_3D_dense_no_pre_alloc,
    ("bke_ic", "dense", True): _alg3d.ccl_bke_ic_3D_dense_pre_alloc,
}

# Dimensionality token -> (expected ndim, fast-path dispatch table).
_DISPATCH_BY_DIM: dict[str, tuple[int, dict[tuple[str, str, bool], Callable[..., Any]]]] = {
    "2D": (2, _DISPATCH_2D),
    "3D": (3, _DISPATCH_3D),
}


# DLPack ``__dlpack_device__`` type codes that denote CUDA device memory:
# kDLCUDA (2) and kDLCUDAManaged (13). kDLCPU (1) and kDLCUDAHost (3, CUDA
# pinned host memory) are host-resident and deliberately rejected rather
# than silently staged onto the device.
_DLPACK_CUDA_DEVICE_TYPES = frozenset({2, 13})


def _as_cupy(input_data: CCLInput) -> cupy.ndarray:
    """
    Normalize an accepted input to a GPU-resident :class:`cupy.ndarray`.

    A :class:`cupy.ndarray` passes through unchanged. Anything else that
    exposes the DLPack protocol and reports a CUDA device is imported
    zero-copy with :func:`cupy.from_dlpack` (this is the Triton / framework
    interop path). Host arrays are rejected with a hard error rather than
    silently copied to the device, since an implicit host-to-device
    transfer is exactly the latency cost this surface exists to avoid.

    Parameters
    ----------
    input_data : cupy.ndarray or SupportsDLPack
        A :class:`cupy.ndarray`, or any object implementing ``__dlpack__``
        whose ``__dlpack_device__`` reports CUDA device memory.

    Returns
    -------
    cupy.ndarray
        The input as a device ``cupy.ndarray`` (zero-copy for both paths).

    Raises
    ------
    TypeError
        If ``input_data`` is neither a :class:`cupy.ndarray` nor a
        DLPack-exposing object, or if its DLPack tensor is host-resident.
    """
    if isinstance(input_data, cupy.ndarray):
        return input_data
    if not hasattr(input_data, "__dlpack__"):
        raise TypeError(
            f"input_data must be a cupy.ndarray or a DLPack-exposing GPU tensor, got {type(input_data).__name__}"
        )
    dlpack_device = getattr(input_data, "__dlpack_device__", None)
    if dlpack_device is not None:
        device_type = dlpack_device()[0]
        if device_type not in _DLPACK_CUDA_DEVICE_TYPES:
            raise TypeError(
                f"input_data DLPack tensor is host-resident (DLPack device type {device_type}); "
                f"bkeccl requires a GPU-resident cupy.ndarray or CUDA DLPack tensor"
            )
    return cupy.from_dlpack(input_data)


def _as_foreground_uint8(input_data: cupy.ndarray) -> cupy.ndarray:
    """
    Normalize an input image to a C-contiguous ``uint8`` foreground map.

    ``bool`` is reinterpreted with a zero-copy ``view``; ``uint8`` is passed
    through; any other dtype is reduced to its non-zero mask. The result is
    made C-contiguous so the fast paths' row-major step assumptions hold.

    Parameters
    ----------
    input_data : cupy.ndarray
        2D image; non-zero entries are foreground.

    Returns
    -------
    cupy.ndarray
        2D, C-contiguous ``uint8`` array, same shape as ``input_data``.
    """
    if input_data.dtype == cupy.bool_:
        normalized = input_data.view(cupy.uint8)
    elif input_data.dtype == cupy.uint8:
        normalized = input_data
    else:
        normalized = (input_data != 0).view(cupy.uint8)
    return cupy.ascontiguousarray(normalized)


def _validate_label_output(label_output: cupy.ndarray, input_data: cupy.ndarray) -> None:
    """
    Check a caller-supplied output buffer against the fast-path contract.

    The pre-allocated variants return a view aliasing ``label_output``, so it
    cannot be silently copied; an incompatible buffer is a hard error rather
    than something this layer normalizes.

    Parameters
    ----------
    label_output : cupy.ndarray
        Caller-supplied output buffer.
    input_data : cupy.ndarray
        The (original) input image whose shape the buffer must match.

    Raises
    ------
    ValueError
        If ``label_output`` is not a C-contiguous ``int32`` array with the
        same ``ndim`` and shape as ``input_data``.
    """
    if label_output.ndim != input_data.ndim:
        raise ValueError(f"label_output ndim {label_output.ndim} does not match input ndim {input_data.ndim}")
    if label_output.shape != input_data.shape:
        raise ValueError(f"label_output shape {label_output.shape} does not match input shape {input_data.shape}")
    if label_output.dtype != cupy.int32:
        raise ValueError(f"label_output dtype must be int32, got {label_output.dtype}")
    if not label_output.flags.c_contiguous:
        raise ValueError("label_output must be C-contiguous")


@overload
def ccl(
    input_data: CCLInput,
    algorithm: Literal["bke", "bke_ic"] = ...,
    dimensionality: Literal["2D", "3D"] = ...,
    output_mode: Literal["dense"] = ...,
    *,
    label_output: cupy.ndarray | None = ...,
) -> tuple[cupy.ndarray, cupy.ndarray]: ...


@overload
def ccl(
    input_data: CCLInput,
    algorithm: Literal["bke", "bke_ic"] = ...,
    dimensionality: Literal["2D", "3D"] = ...,
    *,
    output_mode: Literal["raw"],
    label_output: cupy.ndarray | None = ...,
) -> cupy.ndarray: ...


def ccl(
    input_data: CCLInput,
    algorithm: Literal["bke", "bke_ic"] = "bke",
    dimensionality: Literal["2D", "3D"] = "2D",
    output_mode: Literal["dense", "raw"] = "dense",
    *,
    label_output: cupy.ndarray | None = None,
) -> cupy.ndarray | tuple[cupy.ndarray, cupy.ndarray]:
    """
    Label connected components of a 2D or 3D image with the BKE algorithm.

    This is the validated, normalizing entry point: it establishes every
    precondition the underlying fast paths assume (matching dimensionality,
    ``uint8`` foreground, C-contiguity, ``label_output`` compatibility) and
    handles the empty-input case, then dispatches to the single fast path
    matching the requested options. 2D uses 8-connectivity on 2x2 blocks; 3D
    uses 26-connectivity on 2x2x2 blocks.

    Parameters
    ----------
    input_data : cupy.ndarray or SupportsDLPack
        2D ``(H, W)`` or 3D ``(D, H, W)`` image on the current CUDA device;
        non-zero entries are foreground. A :class:`cupy.ndarray` is used
        directly; any GPU-resident object exposing the DLPack protocol (e.g.
        a Triton GPU tensor) is imported zero-copy. ``bool``/``uint8`` are
        used directly (``bool`` via a zero-copy view); other dtypes are
        reduced to their non-zero mask.
    algorithm : {"bke", "bke_ic"}, optional
        BKE variant; ``"bke_ic"`` uses inline path compression. Default
        ``"bke"``.
    dimensionality : {"2D", "3D"}, optional
        Image dimensionality; must match ``input_data.ndim``. Default
        ``"2D"``.
    output_mode : {"dense", "raw"}, optional
        ``"raw"`` returns the native sparse root-raster ids. ``"dense"``
        renumbers components to ``1..N`` on device. Default ``"dense"``.
    label_output : cupy.ndarray, optional
        Keyword-only. Pre-allocated C-contiguous ``int32`` buffer with the
        same shape as ``input_data``. When given, it is written in place and
        the result aliases it (the pre-allocated fast path). When ``None``,
        an output buffer is allocated.

    Returns
    -------
    cupy.ndarray or tuple[cupy.ndarray, cupy.ndarray]
        For ``output_mode="raw"``, the ``int32`` sparse label array with the
        input shape. For ``output_mode="dense"``, ``(labels, count)`` where
        ``labels`` is the dense ``int32`` map (background 0, components
        ``1..N``) and ``count`` is a 0-dim ``int32`` device array.

    Raises
    ------
    TypeError
        If ``input_data`` is neither a :class:`cupy.ndarray` nor a
        GPU-resident DLPack-exposing tensor.
    ValueError
        If ``dimensionality`` is not ``"2D"``/``"3D"``, ``input_data``
        ndim does not match it, ``algorithm`` is not ``"bke"``/``"bke_ic"``,
        ``output_mode`` is not ``"dense"``/``"raw"``, or ``label_output``
        is incompatible.
    """
    input_data = _as_cupy(input_data)
    if dimensionality not in _DISPATCH_BY_DIM:
        raise ValueError(f"dimensionality must be '2D' or '3D', got {dimensionality!r}")
    expected_ndim, dispatch = _DISPATCH_BY_DIM[dimensionality]
    if input_data.ndim != expected_ndim:
        raise ValueError(f"input_data must be {dimensionality} ({expected_ndim}D), got ndim {input_data.ndim}")

    if algorithm not in ("bke", "bke_ic"):
        raise ValueError(f"algorithm must be 'bke' or 'bke_ic', got {algorithm!r}")
    if output_mode not in ("dense", "raw"):
        raise ValueError(f"output_mode must be 'dense' or 'raw', got {output_mode!r}")

    if label_output is not None:
        _validate_label_output(label_output, input_data)

    # Empty-input contract: shape is preserved, no components. This is the
    # guard the fast paths deliberately omit.
    if input_data.size == 0:
        empty = label_output if label_output is not None else cupy.empty(input_data.shape, dtype=cupy.int32)
        if output_mode == "raw":
            return empty
        return empty, cupy.zeros((), dtype=cupy.int32)

    normalized = _as_foreground_uint8(input_data)
    fast_path = dispatch[(algorithm, output_mode, label_output is not None)]
    if label_output is not None:
        return fast_path(normalized, label_output)
    return fast_path(normalized)
