"""
mandala_gnn.analytics.metrics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Structural graph metrics.

References:
    [1] Watts, D.J. & Strogatz, S.H. (1998). "Collective dynamics of
        'small-world' networks." Nature, 393(6684), 440-442.
        DOI: 10.1038/30918

    [2] Newman, M.E.J. (2002). "Assortative mixing in networks."
        Physical Review Letters, 89(20), 208701.
        DOI: 10.1103/PhysRevLett.89.208701

    [3] Newman, M.E.J. (2003). "The structure and function of complex
        networks." SIAM Review, 45(2), 167-256.
        DOI: 10.1137/S003614450342480
"""

import networkx as nx
import numpy as np
from typing import Dict, Any
from ..core.graph import MandalaGraph


class GraphMetrics:
    """
    Structural metrics for a ``MandalaGraph``.

    Example::

        gm = GraphMetrics(graph)
        print(gm.density())
        print(gm.clustering_coefficient())
        print(gm.summary())  # all metrics at once
    """

    def __init__(self, graph: MandalaGraph):
        self._g = graph.graph
        self._ug = graph.graph.to_undirected()

    def density(self) -> float:
        """
        Graph density.

        Formula (directed):
            D = m / (n × (n - 1))

        Formula (undirected):
            D = 2m / (n × (n - 1))

        Range: [0, 1].  D = 1 for a complete graph.
        """
        return nx.density(self._g)

    def clustering_coefficient(self, node: str = None) -> float:
        """
        Local or average clustering coefficient.

        Formula (for node i):
            C_i = 2 T_i / (k_i (k_i - 1))

        Where:
            T_i = number of triangles through node i
            k_i = degree of node i

        Reference:
            Watts, D.J. & Strogatz, S.H. (1998). "Collective dynamics
            of 'small-world' networks." Nature, 393, 440-442.
            DOI: 10.1038/30918
        """
        if node is not None:
            return nx.clustering(self._ug, node)
        return nx.average_clustering(self._ug)

    def transitivity(self) -> float:
        """
        Global transitivity (fraction of all possible triangles).

        Formula:
            T = 3 × (number of triangles) / (number of connected triples)

        Reference:
            Newman, M.E.J. (2003). "The structure and function of complex
            networks." SIAM Review, 45(2), 167-256.
        """
        return nx.transitivity(self._ug)

    def assortativity(self) -> float:
        """
        Degree assortativity coefficient.

        Measures the tendency of nodes to connect with nodes of
        similar degree.  Positive r → assortative, negative → disassortative.

        Formula:
            r = [M⁻¹ Σ_i j_i k_i - [M⁻¹ Σ_i ½(j_i + k_i)]²]
                / [M⁻¹ Σ_i ½(j_i² + k_i²) - [M⁻¹ Σ_i ½(j_i + k_i)]²]

        Where (j_i, k_i) are the degrees of the two endpoints of edge i.

        Reference:
            Newman, M.E.J. (2002). "Assortative mixing in networks."
            Physical Review Letters, 89(20), 208701.
            DOI: 10.1103/PhysRevLett.89.208701
        """
        try:
            return nx.degree_assortativity_coefficient(self._g)
        except Exception:
            return 0.0

    def reciprocity(self) -> float:
        """
        Reciprocity of a directed graph.

        Formula:
            ρ = L↔ / L

        Where:
            L↔ = edges that have a reciprocal (both i→j and j→i)
            L  = total edges
        """
        return nx.reciprocity(self._g)

    def connected_components(self) -> int:
        """Number of weakly connected components."""
        return nx.number_weakly_connected_components(self._g)

    def strongly_connected_components(self) -> int:
        """Number of strongly connected components."""
        return nx.number_strongly_connected_components(self._g)

    def degree_statistics(self) -> Dict[str, float]:
        """
        Basic degree statistics: mean, std, min, max.
        """
        degrees = [d for _, d in self._g.degree()]
        if not degrees:
            return {"mean": 0, "std": 0, "min": 0, "max": 0}
        return {
            "mean": float(np.mean(degrees)),
            "std": float(np.std(degrees)),
            "min": int(np.min(degrees)),
            "max": int(np.max(degrees)),
        }

    def summary(self) -> Dict[str, Any]:
        """All structural metrics in one dict."""
        return {
            "nodes": self._g.number_of_nodes(),
            "edges": self._g.number_of_edges(),
            "density": self.density(),
            "clustering_coefficient": self.clustering_coefficient(),
            "transitivity": self.transitivity(),
            "assortativity": self.assortativity(),
            "reciprocity": self.reciprocity(),
            "weakly_connected_components": self.connected_components(),
            "strongly_connected_components": self.strongly_connected_components(),
            "degree_stats": self.degree_statistics(),
        }
