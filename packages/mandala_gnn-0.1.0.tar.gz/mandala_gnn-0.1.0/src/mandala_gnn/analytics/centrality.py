"""
mandala_gnn.analytics.centrality
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Node importance measures for knowledge graphs.

Every method includes the mathematical formula and the original
journal reference in its docstring.

References:
    [1] Brin, S. & Page, L. (1998). "The anatomy of a large-scale
        hypertextual web search engine." Computer Networks, 30(1-7), 107-117.
        DOI: 10.1016/S0169-7552(98)00110-X

    [2] Freeman, L.C. (1977). "A set of measures of centrality based on
        betweenness." Sociometry, 40(1), 35-41.
        DOI: 10.2307/3033543

    [3] Bavelas, A. (1950). "Communication patterns in task-oriented groups."
        JASA, 22(6), 725-730.
        DOI: 10.1121/1.1906679

    [4] Bonacich, P. (1987). "Power and centrality: A family of measures."
        American Journal of Sociology, 92(5), 1170-1182.
        DOI: 10.1086/228631

    [5] Kleinberg, J.M. (1999). "Authoritative sources in a hyperlinked
        environment." JACM, 46(5), 604-632.
        DOI: 10.1145/324133.324140

    [6] Katz, L. (1953). "A new status index derived from sociometric
        analysis." Psychometrika, 18(1), 39-43.
        DOI: 10.1007/BF02289026
"""

import networkx as nx
import numpy as np
from typing import Dict, Optional
from ..core.graph import MandalaGraph


class CentralityAnalyzer:
    """
    Computes node centrality measures on a ``MandalaGraph``.

    Example::

        analyzer = CentralityAnalyzer(graph)
        pr = analyzer.pagerank()
        bc = analyzer.betweenness()
        print(analyzer.summary())   # all metrics in one dict
    """

    def __init__(self, graph: MandalaGraph):
        self._g = graph.graph

    # ------------------------------------------------------------------
    # PageRank  (Brin & Page, 1998)
    # ------------------------------------------------------------------

    def pagerank(self, alpha: float = 0.85, max_iter: int = 100,
                 tol: float = 1e-6) -> Dict[str, float]:
        """
        PageRank centrality.

        Formula:
            PR(v) = (1 - d)/N  +  d × Σ_{u∈B(v)} PR(u) / L(u)

        Where:
            d     = damping factor (alpha)
            N     = number of nodes
            B(v)  = set of nodes linking to v
            L(u)  = number of outgoing links from u

        Reference:
            Brin, S. & Page, L. (1998). "The anatomy of a large-scale
            hypertextual web search engine." Computer Networks, 30(1-7).
            DOI: 10.1016/S0169-7552(98)00110-X
        """
        return dict(nx.pagerank(self._g, alpha=alpha, max_iter=max_iter,
                                tol=tol))

    # ------------------------------------------------------------------
    # Betweenness Centrality  (Freeman, 1977)
    # ------------------------------------------------------------------

    def betweenness(self, normalized: bool = True,
                    weight: Optional[str] = "weight") -> Dict[str, float]:
        """
        Betweenness centrality.

        Formula:
            C_B(v) = Σ_{s≠v≠t}  σ_st(v) / σ_st

        Where:
            σ_st     = number of shortest paths from s to t
            σ_st(v)  = number of those paths passing through v

        Reference:
            Freeman, L.C. (1977). "A set of measures of centrality based
            on betweenness." Sociometry, 40(1), 35-41.
            DOI: 10.2307/3033543
        """
        return dict(nx.betweenness_centrality(self._g, normalized=normalized,
                                              weight=weight))

    # ------------------------------------------------------------------
    # Closeness Centrality  (Bavelas, 1950)
    # ------------------------------------------------------------------

    def closeness(self) -> Dict[str, float]:
        """
        Closeness centrality.

        Formula:
            C_C(v) = (N - 1) / Σ_{u≠v} d(v, u)

        Where d(v,u) is the shortest-path distance from v to u.

        Reference:
            Bavelas, A. (1950). "Communication patterns in task-oriented
            groups." JASA, 22(6), 725-730.
            DOI: 10.1121/1.1906679
        """
        return dict(nx.closeness_centrality(self._g))

    # ------------------------------------------------------------------
    # Eigenvector Centrality  (Bonacich, 1987)
    # ------------------------------------------------------------------

    def eigenvector(self, max_iter: int = 100,
                    tol: float = 1e-6) -> Dict[str, float]:
        """
        Eigenvector centrality.

        Formula:
            x_i = (1/λ) Σ_j a_ij x_j

        The eigenvector corresponding to the largest eigenvalue of
        the adjacency matrix.

        Reference:
            Bonacich, P. (1987). "Power and centrality: A family of
            measures." American Journal of Sociology, 92(5), 1170-1182.
            DOI: 10.1086/228631
        """
        try:
            return dict(nx.eigenvector_centrality(
                self._g, max_iter=max_iter, tol=tol))
        except nx.PowerIterationFailedConvergence:
            return dict(nx.eigenvector_centrality_numpy(self._g))

    # ------------------------------------------------------------------
    # HITS  (Kleinberg, 1999)
    # ------------------------------------------------------------------

    def hits(self, max_iter: int = 100,
             tol: float = 1e-8) -> Dict[str, Dict[str, float]]:
        """
        HITS (Hyperlink-Induced Topic Search) — Hub and Authority scores.

        Iterative formulas:
            auth(v) = Σ_{u→v} hub(u)
            hub(v)  = Σ_{v→u} auth(u)

        Reference:
            Kleinberg, J.M. (1999). "Authoritative sources in a
            hyperlinked environment." JACM, 46(5), 604-632.
            DOI: 10.1145/324133.324140

        Returns:
            {node_id: {'hub': float, 'authority': float}}
        """
        hubs, authorities = nx.hits(self._g, max_iter=max_iter, tol=tol)
        return {
            node: {"hub": hubs[node], "authority": authorities[node]}
            for node in self._g.nodes()
        }

    # ------------------------------------------------------------------
    # Katz Centrality  (Katz, 1953)
    # ------------------------------------------------------------------

    def katz(self, alpha: float = 0.1, beta: float = 1.0) -> Dict[str, float]:
        """
        Katz centrality.

        Formula:
            C_Katz(i) = Σ_{k=1}^{∞} Σ_{j=1}^{N} α^k (A^k)_{ji}

        α must be less than 1/λ_max (largest eigenvalue of A).

        Reference:
            Katz, L. (1953). "A new status index derived from sociometric
            analysis." Psychometrika, 18(1), 39-43.
            DOI: 10.1007/BF02289026
        """
        return dict(nx.katz_centrality(self._g, alpha=alpha, beta=beta))

    # ------------------------------------------------------------------
    # Degree Centrality
    # ------------------------------------------------------------------

    def degree(self) -> Dict[str, float]:
        """
        Degree centrality: C_D(v) = deg(v) / (N - 1).
        """
        return dict(nx.degree_centrality(self._g))

    def in_degree(self) -> Dict[str, float]:
        """In-degree centrality for directed graphs."""
        return dict(nx.in_degree_centrality(self._g))

    def out_degree(self) -> Dict[str, float]:
        """Out-degree centrality for directed graphs."""
        return dict(nx.out_degree_centrality(self._g))

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def summary(self) -> Dict[str, Dict[str, float]]:
        """Compute all centrality measures and return a combined dict."""
        return {
            "pagerank": self.pagerank(),
            "betweenness": self.betweenness(),
            "closeness": self.closeness(),
            "degree": self.degree(),
        }
