"""
mandala_gnn.analytics.community
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Community detection algorithms for knowledge graphs.

References:
    [1] Blondel, V.D. et al. (2008). "Fast unfolding of communities in
        large networks." JSTAT, P10008.
        DOI: 10.1088/1742-5468/2008/10/P10008

    [2] Raghavan, U.N. et al. (2007). "Near linear time algorithm to
        detect community structures in large-scale networks."
        Physical Review E, 76(3), 036106.
        DOI: 10.1103/PhysRevE.76.036106

    [3] Newman, M.E.J. & Girvan, M. (2004). "Finding and evaluating
        community structure in networks." Physical Review E, 69(2), 026113.
        DOI: 10.1103/PhysRevE.69.026113
"""

import networkx as nx
from typing import Dict, List, Optional
from ..core.graph import MandalaGraph


class CommunityDetector:
    """
    Community detection on a ``MandalaGraph``.

    Example::

        detector = CommunityDetector(graph)
        communities = detector.louvain()
        mod = detector.modularity(communities)
        print(f"Found {len(set(communities.values()))} communities, Q={mod:.4f}")
    """

    def __init__(self, graph: MandalaGraph):
        self._g = graph.graph
        # For community detection we often need an undirected view
        self._ug = graph.graph.to_undirected()

    def louvain(self, resolution: float = 1.0,
                seed: int = 42) -> Dict[str, int]:
        """
        Louvain community detection.

        The Louvain method optimises modularity in two phases:
        1. Local modularity optimisation (node moves)
        2. Community aggregation (coarsen the graph)

        Modularity:
            Q = (1/2m) Σ_{ij} [A_ij - γ k_i k_j / (2m)] δ(c_i, c_j)

        Where:
            m  = total edge weight
            k_i = degree of node i
            γ  = resolution parameter
            δ  = Kronecker delta

        Reference:
            Blondel, V.D. et al. (2008). "Fast unfolding of communities
            in large networks." JSTAT, P10008.
            DOI: 10.1088/1742-5468/2008/10/P10008

        Returns:
            {node_id: community_index}
        """
        communities = nx.community.louvain_communities(
            self._ug, resolution=resolution, seed=seed
        )
        result = {}
        for idx, community in enumerate(communities):
            for node in community:
                result[node] = idx
        return result

    def label_propagation(self) -> Dict[str, int]:
        """
        Label Propagation Algorithm (LPA).

        Each node adopts the label most frequent among its neighbours.
        Converges when no node changes its label.

        Time complexity: O(m) per iteration — near-linear.

        Reference:
            Raghavan, U.N. et al. (2007). "Near linear time algorithm to
            detect community structures." Phys. Rev. E, 76(3), 036106.
            DOI: 10.1103/PhysRevE.76.036106

        Returns:
            {node_id: community_index}
        """
        communities = nx.community.label_propagation_communities(self._ug)
        result = {}
        for idx, community in enumerate(communities):
            for node in community:
                result[node] = idx
        return result

    def modularity(self, partition: Dict[str, int]) -> float:
        """
        Modularity score Q for a given partition.

        Formula:
            Q = Σ_c [ L_c/m  -  (k_c / 2m)² ]

        Where:
            L_c = number of intra-community edges
            k_c = total degree of community c
            m   = total edges

        Higher Q indicates stronger community structure.
        Typical range: [-0.5, 1.0], good structure > 0.3.

        Reference:
            Newman, M.E.J. & Girvan, M. (2004). "Finding and evaluating
            community structure." Phys. Rev. E, 69(2), 026113.
            DOI: 10.1103/PhysRevE.69.026113
        """
        # Convert partition dict to list of sets
        comm_map = {}
        for node, comm_id in partition.items():
            comm_map.setdefault(comm_id, set()).add(node)
        communities = list(comm_map.values())
        return nx.community.modularity(self._ug, communities)

    def n_communities(self, partition: Dict[str, int]) -> int:
        """Number of distinct communities in a partition."""
        return len(set(partition.values()))

    def community_sizes(self, partition: Dict[str, int]) -> Dict[int, int]:
        """Size of each community: {community_id: node_count}."""
        sizes = {}
        for comm_id in partition.values():
            sizes[comm_id] = sizes.get(comm_id, 0) + 1
        return sizes
