"""
mandala_gnn.analytics.similarity
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Node and vector similarity measures for knowledge graphs.

These measures are fundamental to link prediction, recommendation,
and information retrieval on graph structures.

References:
    [1] Salton, G. & McGill, M.J. (1983). Introduction to Modern
        Information Retrieval. McGraw-Hill.
        ISBN: 0070544840

    [2] Jaccard, P. (1901). "Étude comparative de la distribution florale
        dans une portion des Alpes et des Jura." Bull. Soc. Vaud. Sci. Nat.,
        37, 547-579.
        DOI: 10.5169/seals-266450

    [3] Adamic, L.A. & Adar, E. (2003). "Friends and neighbors on the Web."
        Social Networks, 25(3), 211-230.
        DOI: 10.1016/S0378-8733(03)00009-1

    [4] Barabási, A.-L. & Albert, R. (1999). "Emergence of scaling in
        random networks." Science, 286(5439), 509-512.
        DOI: 10.1126/science.286.5439.509
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from ..core.graph import MandalaGraph


class SimilarityEngine:
    """
    Similarity measures between nodes and vectors.

    Example::

        sim = SimilarityEngine(graph)
        j = sim.jaccard("node_a", "node_b")
        aa = sim.adamic_adar("node_a", "node_b")
        all_scores = sim.all_pairs_similarity(method="jaccard")
    """

    def __init__(self, graph: MandalaGraph):
        self._g = graph.graph
        self._ug = graph.graph.to_undirected()

    # ------------------------------------------------------------------
    # Vector similarity
    # ------------------------------------------------------------------

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        """
        Cosine similarity between two vectors.

        Formula:
            cos(θ) = (A · B) / (‖A‖ × ‖B‖)

        Range: [-1, 1]  (for non-negative vectors: [0, 1])

        Reference:
            Salton, G. & McGill, M.J. (1983). Introduction to Modern
            Information Retrieval. McGraw-Hill.
        """
        a = np.asarray(a, dtype=float).flatten()
        b = np.asarray(b, dtype=float).flatten()
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))

    @staticmethod
    def euclidean_distance(a: np.ndarray, b: np.ndarray) -> float:
        """
        Euclidean distance: d(a,b) = ‖a - b‖₂
        """
        return float(np.linalg.norm(np.asarray(a) - np.asarray(b)))

    # ------------------------------------------------------------------
    # Graph-structural similarity
    # ------------------------------------------------------------------

    def common_neighbors(self, u: str, v: str) -> int:
        """
        Number of common neighbours.

        CN(u, v) = |Γ(u) ∩ Γ(v)|
        """
        nu = set(self._ug.neighbors(u))
        nv = set(self._ug.neighbors(v))
        return len(nu & nv)

    def jaccard(self, u: str, v: str) -> float:
        """
        Jaccard similarity coefficient.

        Formula:
            J(u, v) = |Γ(u) ∩ Γ(v)| / |Γ(u) ∪ Γ(v)|

        Range: [0, 1]

        Reference:
            Jaccard, P. (1901). "Étude comparative de la distribution
            florale." Bull. Soc. Vaud. Sci. Nat., 37, 547-579.
            DOI: 10.5169/seals-266450
        """
        nu = set(self._ug.neighbors(u))
        nv = set(self._ug.neighbors(v))
        union = nu | nv
        if len(union) == 0:
            return 0.0
        return len(nu & nv) / len(union)

    def adamic_adar(self, u: str, v: str) -> float:
        """
        Adamic-Adar index.

        Formula:
            AA(u, v) = Σ_{w ∈ Γ(u) ∩ Γ(v)}  1 / log(|Γ(w)|)

        Weights common neighbours by the inverse log of their degree.
        Nodes connected through *selective* (low-degree) neighbours
        are considered more similar.

        Reference:
            Adamic, L.A. & Adar, E. (2003). "Friends and neighbors
            on the Web." Social Networks, 25(3), 211-230.
            DOI: 10.1016/S0378-8733(03)00009-1
        """
        nu = set(self._ug.neighbors(u))
        nv = set(self._ug.neighbors(v))
        score = 0.0
        for w in nu & nv:
            deg = self._ug.degree(w)
            if deg > 1:
                score += 1.0 / np.log(deg)
        return score

    def preferential_attachment(self, u: str, v: str) -> int:
        """
        Preferential Attachment score.

        Formula:
            PA(u, v) = |Γ(u)| × |Γ(v)|

        High-degree nodes are more likely to form new connections.

        Reference:
            Barabási, A.-L. & Albert, R. (1999). "Emergence of scaling
            in random networks." Science, 286(5439), 509-512.
            DOI: 10.1126/science.286.5439.509
        """
        return self._ug.degree(u) * self._ug.degree(v)

    def resource_allocation(self, u: str, v: str) -> float:
        """
        Resource Allocation index.

        Formula:
            RA(u, v) = Σ_{w ∈ Γ(u) ∩ Γ(v)} 1 / |Γ(w)|

        Similar to Adamic-Adar but without the log.

        Reference:
            Zhou, T. et al. (2009). "Predicting missing links via local
            information." European Physical Journal B, 71(4), 623-630.
            DOI: 10.1140/epjb/e2009-00335-8
        """
        nu = set(self._ug.neighbors(u))
        nv = set(self._ug.neighbors(v))
        score = 0.0
        for w in nu & nv:
            deg = self._ug.degree(w)
            if deg > 0:
                score += 1.0 / deg
        return score

    # ------------------------------------------------------------------
    # Batch operations
    # ------------------------------------------------------------------

    def all_pairs_similarity(
        self,
        method: str = "jaccard",
        threshold: float = 0.0,
    ) -> List[Tuple[str, str, float]]:
        """
        Compute pairwise similarity for all node pairs.

        Args:
            method: 'jaccard', 'adamic_adar', 'common_neighbors',
                    'preferential_attachment', or 'resource_allocation'.
            threshold: Only return pairs with score > threshold.

        Returns:
            List of (node_u, node_v, score) sorted by score descending.
        """
        func_map = {
            "jaccard": self.jaccard,
            "adamic_adar": self.adamic_adar,
            "common_neighbors": lambda u, v: float(self.common_neighbors(u, v)),
            "preferential_attachment": lambda u, v: float(self.preferential_attachment(u, v)),
            "resource_allocation": self.resource_allocation,
        }
        func = func_map.get(method)
        if func is None:
            raise ValueError(f"Unknown method: {method}. Choose from {list(func_map)}")

        nodes = list(self._g.nodes())
        results = []
        for i, u in enumerate(nodes):
            for j, v in enumerate(nodes):
                if i < j:
                    score = func(u, v)
                    if score > threshold:
                        results.append((u, v, score))

        results.sort(key=lambda x: x[2], reverse=True)
        return results
