"""
mandala_gnn.nn.models
~~~~~~~~~~~~~~~~~~~~~~
Pre-built multi-layer GNN models with training loops.

Each model wraps the corresponding ``Conv`` layer from ``mandala_gnn.nn.conv``
and provides ``fit()`` / ``predict()`` / ``evaluate()`` methods for
semi-supervised node classification.

Training uses simple gradient-free optimisation (direct weight update via
pseudo-inverse) for single-layer models, and iterative label propagation
for multi-layer models, keeping the library free of autograd dependencies.

References:
    Kipf & Welling (2017) — GCN    [arXiv:1609.02907]
    Veličković et al. (2018) — GAT  [arXiv:1710.10903]
    Hamilton et al. (2017) — SAGE   [arXiv:1706.02216]
    Xu et al. (2019) — GIN          [arXiv:1810.00826]
"""

import numpy as np
from typing import Optional, List, Dict, Any
from .conv import GCNConv, GATConv, SAGEConv, GINConv
from .pool import GlobalMeanPool, GlobalSumPool
from .functional import relu, softmax, normalize_adjacency, glorot_uniform


def _one_hot(labels: np.ndarray, n_classes: int) -> np.ndarray:
    """Convert integer labels to one-hot matrix."""
    oh = np.zeros((len(labels), n_classes))
    for i, lbl in enumerate(labels):
        if 0 <= lbl < n_classes:
            oh[i, lbl] = 1.0
    return oh


class GCN:
    """
    Two-layer Graph Convolutional Network for node classification.

    Architecture:
        H1 = ReLU( Â X W0 )       — hidden layer
        Z  = softmax( Â H1 W1 )   — output layer

    Where Â = D̃^{-1/2} Ã D̃^{-1/2} (symmetric normalization).

    Training is done via iterative forward pass with direct weight
    updates — no backpropagation framework required.

    Reference:
        Kipf, T.N. & Welling, M. (2017). "Semi-Supervised Classification
        with Graph Convolutional Networks." ICLR 2017.
        arXiv: https://arxiv.org/abs/1609.02907

    Args:
        in_features:  Number of input features per node.
        hidden:       Hidden layer dimension.
        n_classes:    Number of output classes.
        dropout:      Dropout probability (applied as mask each epoch).
        lr:           Learning rate for weight updates.
    """

    def __init__(self, in_features: int, hidden: int, n_classes: int,
                 dropout: float = 0.5, lr: float = 0.01, seed: int = 42):
        self.in_features = in_features
        self.hidden = hidden
        self.n_classes = n_classes
        self.dropout = dropout
        self.lr = lr
        self.seed = seed
        self.rng = np.random.RandomState(seed)

        self.W0 = glorot_uniform(in_features, hidden, self.rng)
        self.W1 = glorot_uniform(hidden, n_classes, self.rng)
        self._A_norm = None

    def _forward(self, A_norm: np.ndarray, X: np.ndarray,
                 training: bool = False) -> np.ndarray:
        """Single forward pass returning logits."""
        H = relu(A_norm @ X @ self.W0)
        if training and self.dropout > 0:
            mask = (self.rng.rand(*H.shape) > self.dropout).astype(float)
            H = H * mask / (1 - self.dropout)
        logits = A_norm @ H @ self.W1
        return logits

    def fit(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
            train_mask: Optional[np.ndarray] = None,
            epochs: int = 200, verbose: bool = False) -> "GCN":
        """
        Train the GCN on a graph.

        Args:
            A: Adjacency matrix (N × N).
            X: Feature matrix (N × in_features).
            y: Integer labels (N,). Use -1 for unlabelled nodes.
            train_mask: Boolean mask indicating training nodes.
            epochs: Number of training iterations.
            verbose: Print loss every 20 epochs.

        Returns:
            self (for chaining).
        """
        A_norm = normalize_adjacency(A)
        self._A_norm = A_norm
        self._X = X

        if train_mask is None:
            train_mask = (y >= 0)
        Y_true = _one_hot(y, self.n_classes)

        for epoch in range(epochs):
            logits = self._forward(A_norm, X, training=True)
            probs = softmax(logits, axis=1)

            # Cross-entropy gradient at output
            grad_out = probs.copy()
            grad_out[train_mask] -= Y_true[train_mask]
            grad_out[~train_mask] = 0
            n_train = train_mask.sum()
            if n_train > 0:
                grad_out /= n_train

            # Update W1
            H = relu(A_norm @ X @ self.W0)
            self.W1 -= self.lr * (A_norm @ H).T @ grad_out

            # Backprop through ReLU to W0
            grad_H = (A_norm @ grad_out @ self.W1.T)
            grad_H[A_norm @ X @ self.W0 <= 0] = 0  # ReLU derivative
            self.W0 -= self.lr * (A_norm @ X).T @ grad_H

            if verbose and (epoch % 20 == 0 or epoch == epochs - 1):
                loss = -np.sum(Y_true[train_mask] * np.log(probs[train_mask] + 1e-12))
                preds = logits.argmax(axis=1)
                acc = (preds[train_mask] == y[train_mask]).mean()
                print(f"Epoch {epoch:4d}  loss={loss:.4f}  train_acc={acc:.4f}")

        return self

    def predict(self, A: Optional[np.ndarray] = None,
                X: Optional[np.ndarray] = None) -> np.ndarray:
        """Predict class labels for all nodes."""
        A_norm = normalize_adjacency(A) if A is not None else self._A_norm
        X = X if X is not None else self._X
        logits = self._forward(A_norm, X, training=False)
        return logits.argmax(axis=1)

    def predict_proba(self, A: Optional[np.ndarray] = None,
                      X: Optional[np.ndarray] = None) -> np.ndarray:
        """Predict class probabilities for all nodes."""
        A_norm = normalize_adjacency(A) if A is not None else self._A_norm
        X = X if X is not None else self._X
        logits = self._forward(A_norm, X, training=False)
        return softmax(logits, axis=1)

    def evaluate(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
                 mask: Optional[np.ndarray] = None) -> Dict[str, float]:
        """
        Evaluate accuracy on specified nodes.

        Returns:
            dict with 'accuracy' and 'loss'.
        """
        A_norm = normalize_adjacency(A)
        logits = self._forward(A_norm, X, training=False)
        probs = softmax(logits, axis=1)
        preds = logits.argmax(axis=1)

        if mask is None:
            mask = np.ones(len(y), dtype=bool)

        acc = (preds[mask] == y[mask]).mean() if mask.sum() > 0 else 0.0
        Y_true = _one_hot(y, self.n_classes)
        loss = -np.sum(Y_true[mask] * np.log(probs[mask] + 1e-12))
        return {"accuracy": float(acc), "loss": float(loss)}


class GAT:
    """
    Two-layer Graph Attention Network for node classification.

    Architecture:
        H1 = ELU( GAT_k(A, X) )     — multi-head attention (concat)
        Z  = softmax( GAT_1(A, H1) ) — single-head (average)

    Reference:
        Veličković, P. et al. (2018). "Graph Attention Networks."
        ICLR 2018.
        arXiv: https://arxiv.org/abs/1710.10903
    """

    def __init__(self, in_features: int, hidden: int, n_classes: int,
                 n_heads: int = 4, dropout: float = 0.5,
                 lr: float = 0.005, seed: int = 42):
        self.n_classes = n_classes
        self.lr = lr
        self.dropout = dropout
        self.rng = np.random.RandomState(seed)

        self.layer1 = GATConv(in_features, hidden, n_heads=n_heads,
                              concat=True, seed=seed)
        self.layer2 = GATConv(hidden * n_heads, n_classes, n_heads=1,
                              concat=False, seed=seed + 1)
        self._A = None
        self._X = None

    def fit(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
            train_mask: Optional[np.ndarray] = None,
            epochs: int = 200, verbose: bool = False) -> "GAT":
        self._A = A
        self._X = X
        if train_mask is None:
            train_mask = (y >= 0)

        for epoch in range(epochs):
            H1 = self.layer1.forward(A, X, activation=relu)
            logits = self.layer2.forward(A, H1, activation=None)
            probs = softmax(logits, axis=1)

            preds = logits.argmax(axis=1)
            if verbose and (epoch % 50 == 0):
                acc = (preds[train_mask] == y[train_mask]).mean()
                print(f"GAT Epoch {epoch:4d}  train_acc={acc:.4f}")

            # Simplified weight perturbation update
            Y_true = _one_hot(y, self.n_classes)
            error = probs.copy()
            error[train_mask] -= Y_true[train_mask]
            scale = self.lr / max(train_mask.sum(), 1)

            for k in range(self.layer2.n_heads):
                grad = H1.T @ error * scale
                self.layer2.W[k] -= grad[:self.layer2.W[k].shape[0],
                                         :self.layer2.W[k].shape[1]]

        return self

    def predict(self, A: Optional[np.ndarray] = None,
                X: Optional[np.ndarray] = None) -> np.ndarray:
        A = A if A is not None else self._A
        X = X if X is not None else self._X
        H1 = self.layer1.forward(A, X, activation=relu)
        logits = self.layer2.forward(A, H1, activation=None)
        return logits.argmax(axis=1)

    def predict_proba(self, A: Optional[np.ndarray] = None,
                      X: Optional[np.ndarray] = None) -> np.ndarray:
        A = A if A is not None else self._A
        X = X if X is not None else self._X
        H1 = self.layer1.forward(A, X, activation=relu)
        logits = self.layer2.forward(A, H1, activation=None)
        return softmax(logits, axis=1)

    def evaluate(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
                 mask: Optional[np.ndarray] = None) -> Dict[str, float]:
        preds = self.predict(A, X)
        if mask is None:
            mask = np.ones(len(y), dtype=bool)
        acc = (preds[mask] == y[mask]).mean() if mask.sum() > 0 else 0.0
        return {"accuracy": float(acc)}


class GraphSAGE:
    """
    Two-layer GraphSAGE model for node classification.

    Reference:
        Hamilton, W.L., Ying, R. & Leskovec, J. (2017).
        "Inductive Representation Learning on Large Graphs."
        NeurIPS 2017.
        arXiv: https://arxiv.org/abs/1706.02216
    """

    def __init__(self, in_features: int, hidden: int, n_classes: int,
                 aggregator: str = "mean", lr: float = 0.01, seed: int = 42):
        self.n_classes = n_classes
        self.lr = lr
        self.rng = np.random.RandomState(seed)

        self.layer1 = SAGEConv(in_features, hidden, aggregator=aggregator,
                               seed=seed)
        # layer2 input is hidden (from layer1 output)
        self.layer2 = SAGEConv(hidden, n_classes, aggregator=aggregator,
                               seed=seed + 1)
        # Fix: layer2 needs W of shape (2*hidden, n_classes)
        self.layer2.W = glorot_uniform(2 * hidden, n_classes, self.rng)
        self._A = None
        self._X = None

    def fit(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
            train_mask: Optional[np.ndarray] = None,
            epochs: int = 200, verbose: bool = False) -> "GraphSAGE":
        self._A = A
        self._X = X
        if train_mask is None:
            train_mask = (y >= 0)
        Y_true = _one_hot(y, self.n_classes)

        for epoch in range(epochs):
            H1 = self.layer1.forward(A, X, activation=relu)
            logits = self.layer2.forward(A, H1, activation=None)
            probs = softmax(logits, axis=1)

            error = probs.copy()
            error[train_mask] -= Y_true[train_mask]
            error[~train_mask] = 0
            n_train = max(train_mask.sum(), 1)

            # Update layer2 weights
            deg = A.sum(axis=1, keepdims=True)
            deg = np.where(deg == 0, 1.0, deg)
            neigh_agg = (A @ H1) / deg
            combined = np.concatenate([H1, neigh_agg], axis=1)
            self.layer2.W -= self.lr * (combined.T @ error) / n_train

            if verbose and (epoch % 50 == 0):
                acc = (logits.argmax(1)[train_mask] == y[train_mask]).mean()
                print(f"SAGE Epoch {epoch:4d}  train_acc={acc:.4f}")

        return self

    def predict(self, A: Optional[np.ndarray] = None,
                X: Optional[np.ndarray] = None) -> np.ndarray:
        A = A if A is not None else self._A
        X = X if X is not None else self._X
        H1 = self.layer1.forward(A, X, activation=relu)
        logits = self.layer2.forward(A, H1, activation=None)
        return logits.argmax(axis=1)

    def predict_proba(self, A: Optional[np.ndarray] = None,
                      X: Optional[np.ndarray] = None) -> np.ndarray:
        A = A if A is not None else self._A
        X = X if X is not None else self._X
        H1 = self.layer1.forward(A, X, activation=relu)
        logits = self.layer2.forward(A, H1, activation=None)
        return softmax(logits, axis=1)

    def evaluate(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
                 mask: Optional[np.ndarray] = None) -> Dict[str, float]:
        preds = self.predict(A, X)
        if mask is None:
            mask = np.ones(len(y), dtype=bool)
        acc = (preds[mask] == y[mask]).mean() if mask.sum() > 0 else 0.0
        return {"accuracy": float(acc)}


class GIN:
    """
    Two-layer Graph Isomorphism Network for node/graph classification.

    GIN is provably the most powerful GNN under the message-passing
    framework, matching the expressiveness of the 1-WL test.

    Reference:
        Xu, K., Hu, W., Leskovec, J. & Jegelka, S. (2019).
        "How Powerful are Graph Neural Networks?" ICLR 2019.
        arXiv: https://arxiv.org/abs/1810.00826
    """

    def __init__(self, in_features: int, hidden: int, n_classes: int,
                 epsilon: float = 0.0, lr: float = 0.01, seed: int = 42):
        self.n_classes = n_classes
        self.lr = lr
        self.rng = np.random.RandomState(seed)

        self.layer1 = GINConv(in_features, hidden, hidden,
                              epsilon=epsilon, seed=seed)
        self.layer2 = GINConv(hidden, hidden, n_classes,
                              epsilon=epsilon, seed=seed + 1)
        self.pool = GlobalSumPool()
        self._A = None
        self._X = None

    def fit(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
            train_mask: Optional[np.ndarray] = None,
            epochs: int = 200, verbose: bool = False) -> "GIN":
        self._A = A
        self._X = X
        if train_mask is None:
            train_mask = (y >= 0)
        Y_true = _one_hot(y, self.n_classes)

        for epoch in range(epochs):
            H1 = self.layer1.forward(A, X, activation=relu)
            logits = self.layer2.forward(A, H1, activation=None)
            probs = softmax(logits, axis=1)

            error = probs.copy()
            error[train_mask] -= Y_true[train_mask]
            error[~train_mask] = 0
            n_train = max(train_mask.sum(), 1)

            # Update layer2 MLP
            agg = (1 + self.layer2.epsilon) * H1 + A @ H1
            h_hidden = relu(agg @ self.layer2.W1 + self.layer2.b1)
            self.layer2.W2 -= self.lr * (h_hidden.T @ error) / n_train

            if verbose and (epoch % 50 == 0):
                acc = (logits.argmax(1)[train_mask] == y[train_mask]).mean()
                print(f"GIN Epoch {epoch:4d}  train_acc={acc:.4f}")

        return self

    def predict(self, A: Optional[np.ndarray] = None,
                X: Optional[np.ndarray] = None) -> np.ndarray:
        A = A if A is not None else self._A
        X = X if X is not None else self._X
        H1 = self.layer1.forward(A, X, activation=relu)
        logits = self.layer2.forward(A, H1, activation=None)
        return logits.argmax(axis=1)

    def predict_proba(self, A: Optional[np.ndarray] = None,
                      X: Optional[np.ndarray] = None) -> np.ndarray:
        A = A if A is not None else self._A
        X = X if X is not None else self._X
        H1 = self.layer1.forward(A, X, activation=relu)
        logits = self.layer2.forward(A, H1, activation=None)
        return softmax(logits, axis=1)

    def evaluate(self, A: np.ndarray, X: np.ndarray, y: np.ndarray,
                 mask: Optional[np.ndarray] = None) -> Dict[str, float]:
        preds = self.predict(A, X)
        if mask is None:
            mask = np.ones(len(y), dtype=bool)
        acc = (preds[mask] == y[mask]).mean() if mask.sum() > 0 else 0.0
        return {"accuracy": float(acc)}
