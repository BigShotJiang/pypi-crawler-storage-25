"""
mandala_gnn.nn.conv
~~~~~~~~~~~~~~~~~~~~
Native Graph Neural Network convolutional layers (pure NumPy).

Each layer implements the forward pass of a well-known GNN architecture.
Training is performed via simple gradient-free optimization or
integration with the ``models`` module.

Implemented architectures and references:

    GCNConv — Kipf, T.N. & Welling, M. (2017).
        "Semi-Supervised Classification with Graph Convolutional Networks."
        ICLR 2017.  arXiv: 1609.02907

    GATConv — Veličković, P. et al. (2018).
        "Graph Attention Networks." ICLR 2018.
        arXiv: 1710.10903

    GATv2Conv — Brody, S. et al. (2022).
        "How Attentive are Graph Attention Networks?" ICLR 2022.
        arXiv: 2105.14491

    SAGEConv — Hamilton, W.L. et al. (2017).
        "Inductive Representation Learning on Large Graphs."
        NeurIPS 2017.  arXiv: 1706.02216

    GINConv — Xu, K. et al. (2019).
        "How Powerful are Graph Neural Networks?" ICLR 2019.
        arXiv: 1810.00826
"""

import numpy as np
from typing import Optional
from .functional import (
    relu, leaky_relu, softmax, sigmoid,
    normalize_adjacency, add_self_loops, glorot_uniform, zeros,
)


class GCNConv:
    """
    Graph Convolutional Network layer (Kipf & Welling, 2017).

    Propagation rule:
        H^{(l+1)} = σ( D̃^{-1/2} Ã D̃^{-1/2} H^{(l)} W^{(l)} )

    Where:
        Ã = A + I_N           (adjacency with self-loops)
        D̃_ii = Σ_j Ã_ij      (degree of Ã)
        W^{(l)}               (trainable weight matrix)
        σ                     (activation function, default ReLU)

    Reference:
        Kipf, T.N. & Welling, M. (2017). "Semi-Supervised Classification
        with Graph Convolutional Networks." ICLR 2017.
        arXiv: https://arxiv.org/abs/1609.02907

    Args:
        in_features:  Input feature dimension.
        out_features: Output feature dimension.
        bias:         Whether to add a bias term.
    """

    def __init__(self, in_features: int, out_features: int, bias: bool = True,
                 seed: int = 42):
        self.in_features = in_features
        self.out_features = out_features
        rng = np.random.RandomState(seed)
        self.W = glorot_uniform(in_features, out_features, rng)
        self.b = zeros(out_features) if bias else None
        # Cache for adjacency
        self._A_norm = None
        self._last_A_id = None

    def forward(self, A: np.ndarray, H: np.ndarray,
                activation=relu) -> np.ndarray:
        """
        Forward pass.

        Args:
            A: Adjacency matrix (N × N).
            H: Node feature matrix (N × in_features).
            activation: Nonlinearity (default: ReLU).

        Returns:
            H': Updated node features (N × out_features).
        """
        # Cache normalized adjacency for repeated forward calls
        a_id = id(A)
        if self._A_norm is None or self._last_A_id != a_id:
            self._A_norm = normalize_adjacency(A)
            self._last_A_id = a_id

        out = self._A_norm @ H @ self.W
        if self.b is not None:
            out = out + self.b
        if activation is not None:
            out = activation(out)
        return out


class GATConv:
    """
    Graph Attention Network layer (Veličković et al., 2018).

    Attention coefficient:
        e_ij   = LeakyReLU( a^T [W h_i ‖ W h_j] )
        α_ij   = softmax_j(e_ij)

    Output (single head):
        h'_i   = σ( Σ_{j∈N(i)} α_ij W h_j )

    Multi-head (K heads, concatenation):
        h'_i   = ‖_{k=1}^{K} σ( Σ_j α_ij^k W^k h_j )

    Reference:
        Veličković, P. et al. (2018). "Graph Attention Networks."
        ICLR 2018.
        arXiv: https://arxiv.org/abs/1710.10903

    Args:
        in_features:  Input dimension.
        out_features: Output dimension per head.
        n_heads:      Number of attention heads.
        concat:       If True, concatenate heads; else average.
    """

    def __init__(self, in_features: int, out_features: int,
                 n_heads: int = 1, concat: bool = True,
                 negative_slope: float = 0.2, seed: int = 42):
        self.in_features = in_features
        self.out_features = out_features
        self.n_heads = n_heads
        self.concat = concat
        self.negative_slope = negative_slope

        rng = np.random.RandomState(seed)
        # Per-head parameters
        self.W = [glorot_uniform(in_features, out_features, rng)
                  for _ in range(n_heads)]
        # Attention vectors: a = [a_left ; a_right], each of size out_features
        self.a_left = [glorot_uniform(out_features, 1, rng).flatten()
                       for _ in range(n_heads)]
        self.a_right = [glorot_uniform(out_features, 1, rng).flatten()
                        for _ in range(n_heads)]

    def forward(self, A: np.ndarray, H: np.ndarray,
                activation=relu) -> np.ndarray:
        """
        Forward pass with multi-head attention.

        Args:
            A: Adjacency matrix (N × N). Non-zero entries define the
               neighbourhood; values are ignored (attention replaces them).
            H: Node features (N × in_features).

        Returns:
            H': (N × out_features*n_heads) if concat else (N × out_features).
        """
        N = H.shape[0]
        A_mask = (add_self_loops(A) > 0).astype(float)

        head_outputs = []
        for k in range(self.n_heads):
            # Linear transform
            Wh = H @ self.W[k]  # N × out_features

            # Attention scores  e_ij = LeakyReLU(a_l^T Wh_i + a_r^T Wh_j)
            score_left = Wh @ self.a_left[k]    # (N,)
            score_right = Wh @ self.a_right[k]  # (N,)

            # Broadcast:  e[i,j] = score_left[i] + score_right[j]
            e = score_left[:, None] + score_right[None, :]  # N × N
            e = leaky_relu(e, self.negative_slope)

            # Mask non-neighbours with -inf
            e = np.where(A_mask > 0, e, -1e9)

            # Softmax per row
            alpha = softmax(e, axis=1)  # N × N

            # Weighted aggregation
            head_out = alpha @ Wh  # N × out_features
            head_outputs.append(head_out)

        if self.concat:
            out = np.concatenate(head_outputs, axis=1)
        else:
            out = np.mean(head_outputs, axis=0)

        if activation is not None:
            out = activation(out)
        return out


class GATv2Conv:
    """
    GATv2 — Dynamic Graph Attention (Brody et al., 2022).

    The key difference from GAT v1 is that the attention function
    is *dynamic* — it can attend to any node, not just those with
    similar representations.

    Attention coefficient:
        e_ij = a^T LeakyReLU( W · [h_i ‖ h_j] )

    Compared to GAT v1 where:
        e_ij = LeakyReLU( a^T [W h_i ‖ W h_j] )

    The non-linearity is applied *before* the dot product with a,
    making the attention strictly more expressive.

    Reference:
        Brody, S., Alon, U. & Yahav, E. (2022).
        "How Attentive are Graph Attention Networks?" ICLR 2022.
        arXiv: https://arxiv.org/abs/2105.14491
    """

    def __init__(self, in_features: int, out_features: int,
                 n_heads: int = 1, concat: bool = True,
                 negative_slope: float = 0.2, seed: int = 42):
        self.in_features = in_features
        self.out_features = out_features
        self.n_heads = n_heads
        self.concat = concat
        self.negative_slope = negative_slope

        rng = np.random.RandomState(seed)
        self.W_l = [glorot_uniform(in_features, out_features, rng)
                    for _ in range(n_heads)]
        self.W_r = [glorot_uniform(in_features, out_features, rng)
                    for _ in range(n_heads)]
        self.a = [glorot_uniform(out_features, 1, rng).flatten()
                  for _ in range(n_heads)]

    def forward(self, A: np.ndarray, H: np.ndarray,
                activation=relu) -> np.ndarray:
        N = H.shape[0]
        A_mask = (add_self_loops(A) > 0).astype(float)

        head_outputs = []
        for k in range(self.n_heads):
            Wl_h = H @ self.W_l[k]  # N × out
            Wr_h = H @ self.W_r[k]  # N × out

            # e[i,j] = a^T LeakyReLU(Wl*h_i + Wr*h_j)  — dynamic
            # Broadcast: Wl_h[i] + Wr_h[j] for all i,j
            combined = Wl_h[:, None, :] + Wr_h[None, :, :]  # N × N × out
            combined = leaky_relu(combined, self.negative_slope)
            e = combined @ self.a[k]  # N × N

            e = np.where(A_mask > 0, e, -1e9)
            alpha = softmax(e, axis=1)

            head_out = alpha @ (H @ self.W_r[k])
            head_outputs.append(head_out)

        if self.concat:
            out = np.concatenate(head_outputs, axis=1)
        else:
            out = np.mean(head_outputs, axis=0)

        if activation is not None:
            out = activation(out)
        return out


class SAGEConv:
    """
    GraphSAGE convolutional layer (Hamilton et al., 2017).

    Update rule (mean aggregator):
        h'_i = σ( W · CONCAT(h_i, MEAN({h_j : j ∈ N(i)})) )

    The key idea is *inductive* — the model learns an aggregation
    function rather than per-node embeddings, so it can generalise
    to unseen nodes and graphs.

    Reference:
        Hamilton, W.L., Ying, R. & Leskovec, J. (2017).
        "Inductive Representation Learning on Large Graphs."
        NeurIPS 2017.
        arXiv: https://arxiv.org/abs/1706.02216

    Args:
        in_features:  Input dimension.
        out_features: Output dimension.
        aggregator:   'mean', 'max', or 'sum'.
    """

    def __init__(self, in_features: int, out_features: int,
                 aggregator: str = "mean", bias: bool = True,
                 seed: int = 42):
        self.in_features = in_features
        self.out_features = out_features
        self.aggregator = aggregator

        rng = np.random.RandomState(seed)
        # Weight for concatenated [self || neighbor_agg]
        self.W = glorot_uniform(2 * in_features, out_features, rng)
        self.b = zeros(out_features) if bias else None

    def forward(self, A: np.ndarray, H: np.ndarray,
                activation=relu) -> np.ndarray:
        """
        Forward pass.

        Args:
            A: Adjacency matrix (N × N). Does NOT need self-loops.
            H: Node features (N × in_features).
        """
        N = H.shape[0]

        # Neighbour aggregation (no self-loops intentionally)
        deg = A.sum(axis=1, keepdims=True)
        deg = np.where(deg == 0, 1.0, deg)

        if self.aggregator == "mean":
            neigh_agg = (A @ H) / deg
        elif self.aggregator == "max":
            # Element-wise max over neighbours
            neigh_agg = np.zeros_like(H)
            for i in range(N):
                nbrs = np.where(A[i] > 0)[0]
                if len(nbrs) > 0:
                    neigh_agg[i] = H[nbrs].max(axis=0)
        elif self.aggregator == "sum":
            neigh_agg = A @ H
        else:
            raise ValueError(f"Unknown aggregator: {self.aggregator}")

        # Concatenate self + aggregated neighbours
        combined = np.concatenate([H, neigh_agg], axis=1)  # N × 2F
        out = combined @ self.W
        if self.b is not None:
            out = out + self.b
        if activation is not None:
            out = activation(out)
        return out


class GINConv:
    """
    Graph Isomorphism Network layer (Xu et al., 2019).

    Update rule:
        h'_i = MLP( (1 + ε) · h_i  +  Σ_{j∈N(i)} h_j )

    GIN is provably as powerful as the Weisfeiler-Leman (WL) graph
    isomorphism test when ε is a learnable parameter.

    Reference:
        Xu, K., Hu, W., Leskovec, J. & Jegelka, S. (2019).
        "How Powerful are Graph Neural Networks?" ICLR 2019.
        arXiv: https://arxiv.org/abs/1810.00826

    Args:
        in_features:  Input dimension.
        hidden:       MLP hidden dimension.
        out_features: Output dimension.
        epsilon:      Learnable/fixed scalar for self-loop weighting.
    """

    def __init__(self, in_features: int, hidden: int, out_features: int,
                 epsilon: float = 0.0, seed: int = 42):
        self.in_features = in_features
        self.out_features = out_features
        self.epsilon = epsilon

        rng = np.random.RandomState(seed)
        # 2-layer MLP
        self.W1 = glorot_uniform(in_features, hidden, rng)
        self.b1 = zeros(hidden)
        self.W2 = glorot_uniform(hidden, out_features, rng)
        self.b2 = zeros(out_features)

    def _mlp(self, x: np.ndarray) -> np.ndarray:
        """2-layer MLP with ReLU."""
        h = relu(x @ self.W1 + self.b1)
        return h @ self.W2 + self.b2

    def forward(self, A: np.ndarray, H: np.ndarray,
                activation=relu) -> np.ndarray:
        """
        Forward pass.

        Args:
            A: Adjacency matrix (N × N).
            H: Node features (N × in_features).
        """
        # Sum of neighbours
        neigh_sum = A @ H  # N × in_features
        # (1 + ε) · h_i + Σ h_j
        out = (1 + self.epsilon) * H + neigh_sum
        out = self._mlp(out)
        if activation is not None:
            out = activation(out)
        return out
