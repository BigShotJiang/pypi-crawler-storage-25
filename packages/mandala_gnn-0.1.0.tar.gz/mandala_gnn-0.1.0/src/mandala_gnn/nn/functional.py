"""
mandala_gnn.nn.functional
~~~~~~~~~~~~~~~~~~~~~~~~~~
Activation functions and graph-level primitives for GNN layers.

All operations are implemented in pure NumPy so that mandala-gnn
remains free of deep-learning framework dependencies.

References:
    Kipf, T.N. & Welling, M. (2017). "Semi-Supervised Classification
    with Graph Convolutional Networks." ICLR 2017.
    arXiv: 1609.02907

    Glorot, X. & Bengio, Y. (2010). "Understanding the difficulty of
    training deep feedforward neural networks." AISTATS 2010.
"""

import numpy as np
from typing import Optional


# ======================================================================
# Activation functions
# ======================================================================

def relu(x: np.ndarray) -> np.ndarray:
    """Rectified Linear Unit: max(0, x)."""
    return np.maximum(0, x)


def leaky_relu(x: np.ndarray, alpha: float = 0.2) -> np.ndarray:
    """Leaky ReLU with configurable negative slope *alpha*."""
    return np.where(x > 0, x, alpha * x)


def elu(x: np.ndarray, alpha: float = 1.0) -> np.ndarray:
    """Exponential Linear Unit (Clevert et al., 2016)."""
    return np.where(x > 0, x, alpha * (np.exp(x) - 1))


def sigmoid(x: np.ndarray) -> np.ndarray:
    """Logistic sigmoid σ(x) = 1 / (1 + e^{-x})."""
    return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))


def tanh(x: np.ndarray) -> np.ndarray:
    """Hyperbolic tangent."""
    return np.tanh(x)


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    """
    Numerically stable softmax.

    softmax(x_i) = exp(x_i - max(x)) / Σ exp(x_j - max(x))
    """
    e = np.exp(x - np.max(x, axis=axis, keepdims=True))
    return e / e.sum(axis=axis, keepdims=True)


# ======================================================================
# Graph primitives
# ======================================================================

def add_self_loops(A: np.ndarray) -> np.ndarray:
    """
    Ã = A + I_N

    Adds self-loops so that each node aggregates its own features
    during message passing (Kipf & Welling, 2017).
    """
    return A + np.eye(A.shape[0])


def degree_matrix(A: np.ndarray) -> np.ndarray:
    """
    Diagonal degree matrix D where D_ii = Σ_j A_ij.
    """
    return np.diag(A.sum(axis=1))


def normalize_adjacency(A: np.ndarray) -> np.ndarray:
    """
    Symmetric normalization: D̃^{-1/2} Ã D̃^{-1/2}

    Where Ã = A + I (adjacency with self-loops).

    This is the renormalization trick from Kipf & Welling (2017):
        H^{(l+1)} = σ( D̃^{-1/2} Ã D̃^{-1/2} H^{(l)} W^{(l)} )

    Reference:
        Kipf, T.N. & Welling, M. (2017). "Semi-Supervised Classification
        with Graph Convolutional Networks." ICLR 2017.
        arXiv: 1609.02907
    """
    A_tilde = add_self_loops(A)
    D_tilde = A_tilde.sum(axis=1)
    # D^{-1/2}
    D_inv_sqrt = np.diag(np.where(D_tilde > 0, D_tilde ** -0.5, 0.0))
    return D_inv_sqrt @ A_tilde @ D_inv_sqrt


def row_normalize(A: np.ndarray) -> np.ndarray:
    """
    Row normalization: D^{-1} A

    Each row sums to 1 (random-walk normalization).
    """
    row_sum = A.sum(axis=1, keepdims=True)
    row_sum = np.where(row_sum == 0, 1.0, row_sum)
    return A / row_sum


# ======================================================================
# Weight initialization
# ======================================================================

def glorot_uniform(fan_in: int, fan_out: int, rng: Optional[np.random.RandomState] = None) -> np.ndarray:
    """
    Glorot / Xavier uniform initialization.

    W ~ U[-limit, limit],  limit = sqrt(6 / (fan_in + fan_out))

    Reference:
        Glorot, X. & Bengio, Y. (2010). "Understanding the difficulty
        of training deep feedforward neural networks." AISTATS 2010.
    """
    rng = rng or np.random.RandomState()
    limit = np.sqrt(6.0 / (fan_in + fan_out))
    return rng.uniform(-limit, limit, size=(fan_in, fan_out))


def zeros(shape):
    """Zero initialization."""
    return np.zeros(shape)
