"""
mandala_gnn.nn.pool
~~~~~~~~~~~~~~~~~~~~
Graph-level readout (pooling) operations.

Pooling collapses a set of node representations into a single
graph-level representation, enabling graph classification tasks.

References:
    Li, Y. et al. (2016). "Gated Graph Sequence Neural Networks."
    ICLR 2016.  arXiv: 1511.05493

    Xu, K. et al. (2019). "How Powerful are Graph Neural Networks?"
    ICLR 2019.  arXiv: 1810.00826
"""

import numpy as np
from .functional import softmax, sigmoid, glorot_uniform


class GlobalMeanPool:
    """
    Mean readout: h_G = (1/N) Σ_i h_i

    Simple and effective baseline readout.  Equivalent to treating
    every node equally regardless of degree or importance.
    """

    def forward(self, H: np.ndarray) -> np.ndarray:
        """
        Args:
            H: Node feature matrix (N × F).
        Returns:
            Graph-level vector (1 × F).
        """
        return H.mean(axis=0, keepdims=True)


class GlobalMaxPool:
    """
    Max readout: h_G = max_i h_i  (element-wise)

    Captures the most activated feature across all nodes.
    """

    def forward(self, H: np.ndarray) -> np.ndarray:
        return H.max(axis=0, keepdims=True)


class GlobalSumPool:
    """
    Sum readout: h_G = Σ_i h_i

    Used in GIN (Xu et al., 2019) for injective multiset functions.
    Preserves cardinality information (larger graphs → larger sums).

    Reference:
        Xu, K. et al. (2019). "How Powerful are Graph Neural Networks?"
        ICLR 2019.  arXiv: 1810.00826
    """

    def forward(self, H: np.ndarray) -> np.ndarray:
        return H.sum(axis=0, keepdims=True)


class GlobalAttentionPool:
    """
    Attention-based readout (Li et al., 2016).

    Gate function:
        g_i = σ(W_gate h_i + b_gate)

    Readout:
        h_G = Σ_i g_i ⊙ (W_feat h_i + b_feat)

    Reference:
        Li, Y. et al. (2016). "Gated Graph Sequence Neural Networks."
        ICLR 2016.  arXiv: 1511.05493
    """

    def __init__(self, in_features: int, gate_features: int = 1,
                 seed: int = 42):
        rng = np.random.RandomState(seed)
        self.W_gate = glorot_uniform(in_features, gate_features, rng)
        self.b_gate = np.zeros(gate_features)
        self.W_feat = glorot_uniform(in_features, in_features, rng)
        self.b_feat = np.zeros(in_features)

    def forward(self, H: np.ndarray) -> np.ndarray:
        gate = sigmoid(H @ self.W_gate + self.b_gate)  # N × 1
        feat = H @ self.W_feat + self.b_feat            # N × F
        return (gate * feat).sum(axis=0, keepdims=True)  # 1 × F
