"""
mandala_gnn.nn
~~~~~~~~~~~~~~
Native Graph Neural Network layers implemented in pure NumPy/SciPy.

No PyTorch or TensorFlow required — designed for lightweight,
interpretable graph learning with full scientific rigor.
"""

from mandala_gnn.nn.functional import (
    relu, leaky_relu, elu, sigmoid, softmax, tanh,
    normalize_adjacency, add_self_loops, degree_matrix,
)
from mandala_gnn.nn.conv import GCNConv, GATConv, GATv2Conv, SAGEConv, GINConv
from mandala_gnn.nn.pool import GlobalMeanPool, GlobalMaxPool, GlobalSumPool
from mandala_gnn.nn.models import GCN, GAT, GraphSAGE, GIN

__all__ = [
    "relu", "leaky_relu", "elu", "sigmoid", "softmax", "tanh",
    "normalize_adjacency", "add_self_loops", "degree_matrix",
    "GCNConv", "GATConv", "GATv2Conv", "SAGEConv", "GINConv",
    "GlobalMeanPool", "GlobalMaxPool", "GlobalSumPool",
    "GCN", "GAT", "GraphSAGE", "GIN",
]
