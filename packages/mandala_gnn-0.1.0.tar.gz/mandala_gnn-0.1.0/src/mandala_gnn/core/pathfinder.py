"""
mandala_gnn.core.pathfinder
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Shortest-path, topological-ordering, and distance utilities.

References:
    Dijkstra, E.W. (1959). "A note on two problems in connexion with graphs."
    Numerische Mathematik, 1(1), 269-271.
    DOI: 10.1007/BF01386390
"""

import networkx as nx
from typing import List, Optional
from .graph import MandalaGraph


class Pathfinder:
    """
    Path and distance utilities over a ``MandalaGraph``.

    Implements Dijkstra's shortest-path algorithm (Dijkstra, 1959)
    and topological ordering for DAG prerequisite resolution.

    Example::

        pf = Pathfinder(graph)
        pf.shortest_path("node_a", "node_d")
        # => ['node_a', 'node_b', 'node_d']
    """

    def __init__(self, graph: MandalaGraph):
        self._g = graph.graph  # underlying networkx DiGraph

    def shortest_path(self, source: str, target: str) -> List[str]:
        """
        Dijkstra shortest path between two nodes.

        Reference:
            Dijkstra, E.W. (1959). "A note on two problems in connexion
            with graphs." Numerische Mathematik, 1(1), 269-271.
        """
        try:
            return nx.shortest_path(self._g, source, target, weight="weight")
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return []

    def shortest_path_length(self, source: str, target: str) -> float:
        """Weighted shortest-path distance.  Returns ``float('inf')`` if unreachable."""
        try:
            return nx.shortest_path_length(self._g, source, target, weight="weight")
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return float("inf")

    def all_paths(self, source: str, target: str, cutoff: int = 10) -> List[List[str]]:
        """All simple paths up to *cutoff* length."""
        try:
            return list(nx.all_simple_paths(self._g, source, target, cutoff=cutoff))
        except nx.NodeNotFound:
            return []

    def ordered_prerequisites(self, target: str) -> List[str]:
        """
        All transitive ancestors of *target*, topologically sorted
        so that prerequisites come first.
        """
        if not self._g.has_node(target):
            return []
        ancestors = nx.ancestors(self._g, target)
        ancestors.add(target)
        sub = self._g.subgraph(ancestors)
        try:
            return list(nx.topological_sort(sub))
        except nx.NetworkXUnfeasible:
            # Cycle detected — fall back to BFS order
            from .graph import MandalaGraph as _MG
            tmp = _MG()
            tmp.graph = self._g
            return tmp.get_predecessors(target) + [target]

    def diameter(self) -> float:
        """
        Diameter of the graph (longest shortest path).

        For directed graphs, uses the strongly-connected components.
        Returns ``float('inf')`` if the graph is not strongly connected.
        """
        if not nx.is_strongly_connected(self._g):
            return float("inf")
        return nx.diameter(self._g)

    def average_path_length(self) -> float:
        """
        Average shortest-path length over all reachable node pairs.

        Returns ``float('inf')`` if the graph is not strongly connected.
        """
        if not nx.is_strongly_connected(self._g):
            return float("inf")
        return nx.average_shortest_path_length(self._g, weight="weight")
