"""
mandala_gnn.core.graph
~~~~~~~~~~~~~~~~~~~~~~
In-memory directed knowledge graph backed by NetworkX.

Pure graph structure — no database coupling.
All persistence is delegated to external storage libraries.
"""

import networkx as nx
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from collections import deque


class MandalaGraph:
    """
    Core knowledge graph — a thin, powerful wrapper around ``networkx.DiGraph``.

    This class provides the foundational data structure for all graph
    operations in mandala-gnn: analytics, GNN layers, embeddings,
    and machine-learning utilities all operate on a ``MandalaGraph``.

    Example::

        g = MandalaGraph()
        g.add_node("A", content="Node A")
        g.add_node("B", content="Node B")
        g.add_edge("A", "B", weight=0.9)
    """

    def __init__(self):
        self.graph = nx.DiGraph()

    # ------------------------------------------------------------------
    # Node operations
    # ------------------------------------------------------------------

    def add_node(
        self,
        node_id: str,
        content: str = "",
        embedding: Any = None,
        metadata: Optional[Dict] = None,
    ):
        """Adds or updates a node in the graph."""
        self.graph.add_node(
            node_id, content=content, embedding=embedding, metadata=metadata
        )

    def remove_node(self, node_id: str):
        """Removes a node and all its incident edges."""
        if self.graph.has_node(node_id):
            self.graph.remove_node(node_id)

    def get_node(self, node_id: str) -> Optional[Dict]:
        """Returns node data dict or None."""
        if self.graph.has_node(node_id):
            return dict(self.graph.nodes[node_id])
        return None

    def has_node(self, node_id: str) -> bool:
        return self.graph.has_node(node_id)

    # ------------------------------------------------------------------
    # Edge operations
    # ------------------------------------------------------------------

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        weight: float = 1.0,
        metadata: Optional[Dict] = None,
    ):
        """Adds a directed edge (source → target)."""
        if not self.graph.has_node(source_id) or not self.graph.has_node(target_id):
            raise ValueError(
                f"Both nodes must exist. "
                f"Missing: {[n for n in (source_id, target_id) if not self.graph.has_node(n)]}"
            )
        self.graph.add_edge(source_id, target_id, weight=weight, metadata=metadata)

    def remove_edge(self, source_id: str, target_id: str):
        if self.graph.has_edge(source_id, target_id):
            self.graph.remove_edge(source_id, target_id)

    # ------------------------------------------------------------------
    # Traversal
    # ------------------------------------------------------------------

    def get_predecessors(self, node_id: str) -> List[str]:
        """BFS backwards — all transitive predecessors."""
        if not self.graph.has_node(node_id):
            return []
        result, visited, queue = [], set(), deque(self.graph.predecessors(node_id))
        while queue:
            cur = queue.popleft()
            if cur not in visited:
                visited.add(cur)
                result.append(cur)
                queue.extend(self.graph.predecessors(cur))
        return result

    def get_successors(self, node_id: str) -> List[str]:
        """Direct successors (next steps)."""
        if not self.graph.has_node(node_id):
            return []
        return list(self.graph.successors(node_id))

    # ------------------------------------------------------------------
    # Import / Export
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict:
        """Serialises the graph to a plain dict (JSON-friendly)."""
        return {
            "nodes": [
                {"id": nid, **{k: v for k, v in data.items() if k != "embedding"}}
                for nid, data in self.graph.nodes(data=True)
            ],
            "edges": [
                {"source": s, "target": t, **d}
                for s, t, d in self.graph.edges(data=True)
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "MandalaGraph":
        """Creates a MandalaGraph from a dict produced by ``to_dict()``."""
        g = cls()
        for node in data.get("nodes", []):
            nid = node.pop("id")
            g.graph.add_node(nid, **node)
        for edge in data.get("edges", []):
            src = edge.pop("source")
            tgt = edge.pop("target")
            g.graph.add_edge(src, tgt, **edge)
        return g

    @classmethod
    def from_edge_list(
        cls, edges: List[Tuple[str, str]], directed: bool = True
    ) -> "MandalaGraph":
        """Creates a graph from an edge list: ``[('A','B'), ('B','C')]``."""
        g = cls()
        for src, tgt in edges:
            if not g.has_node(src):
                g.graph.add_node(src)
            if not g.has_node(tgt):
                g.graph.add_node(tgt)
            g.graph.add_edge(src, tgt)
        return g

    @classmethod
    def from_adjacency_matrix(
        cls, matrix: np.ndarray, node_ids: Optional[List[str]] = None
    ) -> "MandalaGraph":
        """Creates a graph from a square adjacency matrix."""
        n = matrix.shape[0]
        ids = node_ids or [str(i) for i in range(n)]
        g = cls()
        for i in range(n):
            g.graph.add_node(ids[i])
        for i in range(n):
            for j in range(n):
                if matrix[i, j] != 0:
                    g.graph.add_edge(ids[i], ids[j], weight=float(matrix[i, j]))
        return g

    def to_adjacency_matrix(self) -> Tuple[np.ndarray, List[str]]:
        """
        Returns (adjacency_matrix, node_id_list).

        The matrix entry ``A[i][j]`` is the weight of edge ``i → j``
        (0 if no edge).
        """
        nodes = list(self.graph.nodes())
        n = len(nodes)
        idx = {nid: i for i, nid in enumerate(nodes)}
        A = np.zeros((n, n))
        for s, t, d in self.graph.edges(data=True):
            A[idx[s], idx[t]] = d.get("weight", 1.0)
        return A, nodes

    def to_edge_list(self) -> List[Tuple[str, str, float]]:
        """Returns list of (source, target, weight) tuples."""
        return [
            (s, t, d.get("weight", 1.0))
            for s, t, d in self.graph.edges(data=True)
        ]

    # ------------------------------------------------------------------
    # Structural helpers
    # ------------------------------------------------------------------

    def subgraph(self, node_ids: List[str]) -> "MandalaGraph":
        """Returns a new MandalaGraph induced by *node_ids*."""
        g = MandalaGraph()
        g.graph = self.graph.subgraph(node_ids).copy()
        return g

    def degree_sequence(self) -> Dict[str, Dict[str, int]]:
        """Returns ``{node_id: {'in': int, 'out': int, 'total': int}}``."""
        return {
            nid: {
                "in": self.graph.in_degree(nid),
                "out": self.graph.out_degree(nid),
                "total": self.graph.in_degree(nid) + self.graph.out_degree(nid),
            }
            for nid in self.graph.nodes()
        }

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def list_nodes(self) -> List[Tuple[str, Dict]]:
        return list(self.graph.nodes(data=True))

    def list_edges(self) -> List[Tuple[str, str, Dict]]:
        return list(self.graph.edges(data=True))

    def node_count(self) -> int:
        return self.graph.number_of_nodes()

    def edge_count(self) -> int:
        return self.graph.number_of_edges()
