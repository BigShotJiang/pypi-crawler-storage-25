"""
mandala_gnn.evaluation.regression_metrics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Regression evaluation metrics.

Standard prediction-quality metrics for continuous-valued outputs.
"""

import numpy as np
from typing import Dict


class RegressionMetrics:
    """
    Regression evaluation metrics.

    Example::

        from mandala_gnn.evaluation import RegressionMetrics as RM

        y_true = [3.0, 5.0, 2.5, 7.0]
        y_pred = [2.8, 5.2, 2.0, 6.8]

        print(RM.rmse(y_true, y_pred))
        print(RM.r2_score(y_true, y_pred))
        print(RM.regression_report(y_true, y_pred))
    """

    @staticmethod
    def mse(y_true, y_pred) -> float:
        """
        Mean Squared Error.

        Formula:
            MSE = (1/N) Σ (y_i - ŷ_i)²
        """
        y_true = np.asarray(y_true, dtype=float)
        y_pred = np.asarray(y_pred, dtype=float)
        return float(np.mean((y_true - y_pred) ** 2))

    @staticmethod
    def rmse(y_true, y_pred) -> float:
        """
        Root Mean Squared Error.

        Formula:
            RMSE = √MSE
        """
        return float(np.sqrt(RegressionMetrics.mse(y_true, y_pred)))

    @staticmethod
    def mae(y_true, y_pred) -> float:
        """
        Mean Absolute Error.

        Formula:
            MAE = (1/N) Σ |y_i - ŷ_i|
        """
        y_true = np.asarray(y_true, dtype=float)
        y_pred = np.asarray(y_pred, dtype=float)
        return float(np.mean(np.abs(y_true - y_pred)))

    @staticmethod
    def r2_score(y_true, y_pred) -> float:
        """
        Coefficient of Determination (R²).

        Formula:
            R² = 1 - SS_res / SS_tot
            SS_res = Σ (y_i - ŷ_i)²
            SS_tot = Σ (y_i - ȳ)²

        Range: (-∞, 1].  1 = perfect, 0 = mean baseline.
        """
        y_true = np.asarray(y_true, dtype=float)
        y_pred = np.asarray(y_pred, dtype=float)
        ss_res = np.sum((y_true - y_pred) ** 2)
        ss_tot = np.sum((y_true - y_true.mean()) ** 2)
        if ss_tot == 0:
            return 0.0
        return float(1 - ss_res / ss_tot)

    @staticmethod
    def mape(y_true, y_pred) -> float:
        """
        Mean Absolute Percentage Error.

        Formula:
            MAPE = (100/N) Σ |y_i - ŷ_i| / |y_i|

        Returns percentage value.  Undefined when y_i = 0.
        """
        y_true = np.asarray(y_true, dtype=float)
        y_pred = np.asarray(y_pred, dtype=float)
        mask = y_true != 0
        if mask.sum() == 0:
            return 0.0
        return float(100 * np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])))

    @staticmethod
    def explained_variance(y_true, y_pred) -> float:
        """
        Explained Variance Score.

        Formula:
            EV = 1 - Var(y - ŷ) / Var(y)
        """
        y_true = np.asarray(y_true, dtype=float)
        y_pred = np.asarray(y_pred, dtype=float)
        var_residual = np.var(y_true - y_pred)
        var_true = np.var(y_true)
        if var_true == 0:
            return 0.0
        return float(1 - var_residual / var_true)

    @staticmethod
    def regression_report(y_true, y_pred) -> Dict[str, float]:
        """Complete regression report."""
        return {
            "mse": RegressionMetrics.mse(y_true, y_pred),
            "rmse": RegressionMetrics.rmse(y_true, y_pred),
            "mae": RegressionMetrics.mae(y_true, y_pred),
            "r2_score": RegressionMetrics.r2_score(y_true, y_pred),
            "mape": RegressionMetrics.mape(y_true, y_pred),
            "explained_variance": RegressionMetrics.explained_variance(y_true, y_pred),
        }
