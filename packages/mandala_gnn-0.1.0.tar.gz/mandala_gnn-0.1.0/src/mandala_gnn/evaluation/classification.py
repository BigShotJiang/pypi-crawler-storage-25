"""
mandala_gnn.evaluation.classification
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Classification evaluation metrics.

All metrics are implemented in pure NumPy for zero external dependency
beyond the standard scientific stack.

References:
    [1] Van Rijsbergen, C.J. (1979). Information Retrieval. 2nd ed.
        Butterworths. ISBN: 0408709294

    [2] Hanley, J.A. & McNeil, B.J. (1982). "The meaning and use of the
        area under a receiver operating characteristic (ROC) curve."
        Radiology, 143(1), 29-36.
        DOI: 10.1148/radiology.143.1.7063747

    [3] Matthews, B.W. (1975). "Comparison of the predicted and observed
        secondary structure of T4 phage lysozyme." Biochimica et Biophysica
        Acta, 405(2), 442-451.
        DOI: 10.1016/0005-2795(75)90109-9

    [4] Davis, J. & Goadrich, M. (2006). "The relationship between
        Precision-Recall and ROC curves." ICML 2006.
        DOI: 10.1145/1143844.1143874
"""

import numpy as np
from typing import Dict, List, Optional, Any


class ClassificationMetrics:
    """
    Comprehensive classification evaluation.

    All methods are static — no instantiation required.

    Example::

        from mandala_gnn.evaluation import ClassificationMetrics as CM

        y_true = [1, 0, 1, 1, 0]
        y_pred = [1, 0, 0, 1, 0]

        print(CM.accuracy(y_true, y_pred))       # 0.8
        print(CM.f1_score(y_true, y_pred))        # 0.8
        print(CM.classification_report(y_true, y_pred))
    """

    @staticmethod
    def accuracy(y_true, y_pred) -> float:
        """
        Classification accuracy.

        Formula:
            Accuracy = (TP + TN) / (TP + TN + FP + FN)
        """
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)
        return float((y_true == y_pred).mean())

    @staticmethod
    def confusion_matrix(y_true, y_pred) -> np.ndarray:
        """
        Confusion matrix C where C[i, j] = count of samples
        with true label i and predicted label j.
        """
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)
        classes = np.unique(np.concatenate([y_true, y_pred]))
        n = len(classes)
        cls_to_idx = {c: i for i, c in enumerate(classes)}
        cm = np.zeros((n, n), dtype=int)
        for t, p in zip(y_true, y_pred):
            cm[cls_to_idx[t], cls_to_idx[p]] += 1
        return cm

    @staticmethod
    def precision(y_true, y_pred, average: str = "binary",
                  pos_label: int = 1) -> float:
        """
        Precision = TP / (TP + FP)

        Args:
            average: 'binary', 'macro', or 'micro'.

        Reference:
            Van Rijsbergen, C.J. (1979). Information Retrieval.
        """
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)

        if average == "binary":
            tp = ((y_pred == pos_label) & (y_true == pos_label)).sum()
            fp = ((y_pred == pos_label) & (y_true != pos_label)).sum()
            return float(tp / (tp + fp)) if (tp + fp) > 0 else 0.0

        classes = np.unique(np.concatenate([y_true, y_pred]))
        if average == "macro":
            precisions = []
            for c in classes:
                tp = ((y_pred == c) & (y_true == c)).sum()
                fp = ((y_pred == c) & (y_true != c)).sum()
                precisions.append(tp / (tp + fp) if (tp + fp) > 0 else 0.0)
            return float(np.mean(precisions))
        else:  # micro
            tp = (y_pred == y_true).sum()
            return float(tp / len(y_true)) if len(y_true) > 0 else 0.0

    @staticmethod
    def recall(y_true, y_pred, average: str = "binary",
               pos_label: int = 1) -> float:
        """
        Recall (Sensitivity, True Positive Rate).

        Formula:
            Recall = TP / (TP + FN)
        """
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)

        if average == "binary":
            tp = ((y_pred == pos_label) & (y_true == pos_label)).sum()
            fn = ((y_pred != pos_label) & (y_true == pos_label)).sum()
            return float(tp / (tp + fn)) if (tp + fn) > 0 else 0.0

        classes = np.unique(np.concatenate([y_true, y_pred]))
        if average == "macro":
            recalls = []
            for c in classes:
                tp = ((y_pred == c) & (y_true == c)).sum()
                fn = ((y_pred != c) & (y_true == c)).sum()
                recalls.append(tp / (tp + fn) if (tp + fn) > 0 else 0.0)
            return float(np.mean(recalls))
        else:
            tp = (y_pred == y_true).sum()
            return float(tp / len(y_true)) if len(y_true) > 0 else 0.0

    @staticmethod
    def f1_score(y_true, y_pred, average: str = "binary",
                 pos_label: int = 1) -> float:
        """
        F1 Score — harmonic mean of precision and recall.

        Formula:
            F1 = 2 × (Precision × Recall) / (Precision + Recall)

        Reference:
            Van Rijsbergen, C.J. (1979). Information Retrieval.
            ISBN: 0408709294
        """
        p = ClassificationMetrics.precision(y_true, y_pred, average, pos_label)
        r = ClassificationMetrics.recall(y_true, y_pred, average, pos_label)
        if (p + r) == 0:
            return 0.0
        return float(2 * p * r / (p + r))

    @staticmethod
    def matthews_corrcoef(y_true, y_pred) -> float:
        """
        Matthews Correlation Coefficient (MCC).

        Formula:
            MCC = (TP×TN - FP×FN) / √((TP+FP)(TP+FN)(TN+FP)(TN+FN))

        Range: [-1, 1].  +1 = perfect, 0 = random, -1 = inverse.

        Reference:
            Matthews, B.W. (1975). "Comparison of the predicted and
            observed secondary structure of T4 phage lysozyme."
            BBA, 405(2), 442-451.
            DOI: 10.1016/0005-2795(75)90109-9
        """
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)
        classes = np.unique(np.concatenate([y_true, y_pred]))

        if len(classes) == 2:
            pos = classes[1]
            tp = ((y_pred == pos) & (y_true == pos)).sum()
            tn = ((y_pred != pos) & (y_true != pos)).sum()
            fp = ((y_pred == pos) & (y_true != pos)).sum()
            fn = ((y_pred != pos) & (y_true == pos)).sum()
            denom = np.sqrt(float((tp+fp) * (tp+fn) * (tn+fp) * (tn+fn)))
            if denom == 0:
                return 0.0
            return float((tp * tn - fp * fn) / denom)

        # Multi-class MCC
        cm = ClassificationMetrics.confusion_matrix(y_true, y_pred)
        n = cm.sum()
        t_k = cm.sum(axis=1)
        p_k = cm.sum(axis=0)
        c = np.trace(cm)
        s2 = (t_k * p_k).sum()
        t2 = (t_k ** 2).sum()
        p2 = (p_k ** 2).sum()
        denom = np.sqrt((n**2 - t2) * (n**2 - p2))
        if denom == 0:
            return 0.0
        return float((c * n - s2) / denom)

    @staticmethod
    def auc_roc(y_true, y_scores) -> float:
        """
        Area Under the ROC Curve (AUC-ROC).

        Computed via the trapezoidal rule over sorted thresholds.

        Reference:
            Hanley, J.A. & McNeil, B.J. (1982). "The meaning and use
            of the area under a ROC curve." Radiology, 143(1), 29-36.
            DOI: 10.1148/radiology.143.1.7063747
        """
        y_true = np.asarray(y_true, dtype=float)
        y_scores = np.asarray(y_scores, dtype=float)

        # Sort by decreasing score
        desc_idx = np.argsort(-y_scores)
        y_true_sorted = y_true[desc_idx]

        n_pos = y_true.sum()
        n_neg = len(y_true) - n_pos
        if n_pos == 0 or n_neg == 0:
            return 0.5

        tpr_prev, fpr_prev = 0.0, 0.0
        auc = 0.0
        tp, fp = 0, 0

        for i in range(len(y_true_sorted)):
            if y_true_sorted[i] == 1:
                tp += 1
            else:
                fp += 1
            tpr = tp / n_pos
            fpr = fp / n_neg
            auc += 0.5 * (tpr + tpr_prev) * (fpr - fpr_prev)
            tpr_prev, fpr_prev = tpr, fpr

        return float(auc)

    @staticmethod
    def auc_pr(y_true, y_scores) -> float:
        """
        Area Under the Precision-Recall Curve (AUC-PR).

        Reference:
            Davis, J. & Goadrich, M. (2006). "The relationship between
            Precision-Recall and ROC curves." ICML 2006.
            DOI: 10.1145/1143844.1143874
        """
        y_true = np.asarray(y_true, dtype=float)
        y_scores = np.asarray(y_scores, dtype=float)

        desc_idx = np.argsort(-y_scores)
        y_sorted = y_true[desc_idx]

        n_pos = y_true.sum()
        if n_pos == 0:
            return 0.0

        tp, fp = 0, 0
        precisions = [1.0]
        recalls = [0.0]

        for i in range(len(y_sorted)):
            if y_sorted[i] == 1:
                tp += 1
            else:
                fp += 1
            precisions.append(tp / (tp + fp))
            recalls.append(tp / n_pos)

        auc = 0.0
        for i in range(1, len(recalls)):
            auc += (recalls[i] - recalls[i-1]) * precisions[i]
        return float(auc)

    @staticmethod
    def classification_report(y_true, y_pred) -> Dict[str, Any]:
        """
        Complete classification report with all metrics.
        """
        return {
            "accuracy": ClassificationMetrics.accuracy(y_true, y_pred),
            "precision_macro": ClassificationMetrics.precision(y_true, y_pred, "macro"),
            "recall_macro": ClassificationMetrics.recall(y_true, y_pred, "macro"),
            "f1_macro": ClassificationMetrics.f1_score(y_true, y_pred, "macro"),
            "mcc": ClassificationMetrics.matthews_corrcoef(y_true, y_pred),
            "confusion_matrix": ClassificationMetrics.confusion_matrix(y_true, y_pred).tolist(),
        }
