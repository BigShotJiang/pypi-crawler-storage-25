"""
mandala_gnn.evaluation.clustering_metrics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Clustering evaluation metrics.

References:
    [1] Rousseeuw, P.J. (1987). "Silhouettes: A graphical aid to the
        interpretation and validation of cluster analysis."
        JCAM, 20, 53-65.
        DOI: 10.1016/0377-0427(87)90125-7

    [2] Davies, D.L. & Bouldin, D.W. (1979). "A cluster separation
        measure." IEEE TPAMI, 1(2), 224-227.
        DOI: 10.1109/TPAMI.1979.4766909

    [3] Caliński, T. & Harabasz, J. (1974). "A dendrite method for
        cluster analysis." Communications in Statistics, 3(1), 1-27.
        DOI: 10.1080/03610927408827101

    [4] Strehl, A. & Ghosh, J. (2002). "Cluster ensembles — a knowledge
        reuse framework." JMLR, 3, 583-617.
        DOI: 10.1162/153244303321897735

    [5] Hubert, L. & Arabie, P. (1985). "Comparing partitions."
        Journal of Classification, 2(1), 193-218.
        DOI: 10.1007/BF01908075
"""

import numpy as np
from typing import Dict, Optional, Any
from sklearn.metrics import (
    silhouette_score as _sk_silhouette,
    davies_bouldin_score as _sk_dbi,
    calinski_harabasz_score as _sk_chi,
    normalized_mutual_info_score as _sk_nmi,
    adjusted_rand_score as _sk_ari,
)


class ClusteringMetrics:
    """
    Clustering evaluation metrics.

    Example::

        from mandala_gnn.evaluation import ClusteringMetrics as CM

        X = [[1,2], [1,3], [5,6], [5,7]]
        labels = [0, 0, 1, 1]

        print(CM.silhouette_score(X, labels))
        print(CM.davies_bouldin_index(X, labels))
        print(CM.clustering_report(X, labels))
    """

    @staticmethod
    def silhouette_score(X, labels) -> float:
        """
        Silhouette Score — measures how similar each point is to its own
        cluster versus the nearest neighbouring cluster.

        Formula (for sample i):
            s(i) = (b(i) - a(i)) / max(a(i), b(i))

        Where:
            a(i) = mean intra-cluster distance
            b(i) = mean nearest-cluster distance

        Range: [-1, 1].  Higher is better.  >0.5 = reasonable structure.

        Reference:
            Rousseeuw, P.J. (1987). "Silhouettes: A graphical aid to the
            interpretation and validation of cluster analysis."
            JCAM, 20, 53-65.
            DOI: 10.1016/0377-0427(87)90125-7
        """
        X = np.asarray(X)
        labels = np.asarray(labels)
        if len(np.unique(labels)) < 2:
            return 0.0
        return float(_sk_silhouette(X, labels))

    @staticmethod
    def davies_bouldin_index(X, labels) -> float:
        """
        Davies-Bouldin Index — ratio of within-cluster scatter to
        between-cluster separation.

        Formula:
            DB = (1/K) Σ_{i=1}^{K} max_{j≠i} (S_i + S_j) / d(c_i, c_j)

        Where:
            S_i  = average distance of points in cluster i to centroid
            d(c_i, c_j) = distance between centroids i and j

        Lower is better.  0 = perfect separation.

        Reference:
            Davies, D.L. & Bouldin, D.W. (1979). "A cluster separation
            measure." IEEE TPAMI, 1(2), 224-227.
            DOI: 10.1109/TPAMI.1979.4766909
        """
        X = np.asarray(X)
        labels = np.asarray(labels)
        if len(np.unique(labels)) < 2:
            return 0.0
        return float(_sk_dbi(X, labels))

    @staticmethod
    def calinski_harabasz_index(X, labels) -> float:
        """
        Calinski-Harabasz Index (Variance Ratio Criterion).

        Formula:
            CH = [B_K / (K - 1)] / [W_K / (N - K)]

        Where:
            B_K = between-cluster dispersion
            W_K = within-cluster dispersion
            K   = number of clusters
            N   = total samples

        Higher is better.

        Reference:
            Caliński, T. & Harabasz, J. (1974). "A dendrite method for
            cluster analysis." Communications in Statistics, 3(1), 1-27.
            DOI: 10.1080/03610927408827101
        """
        X = np.asarray(X)
        labels = np.asarray(labels)
        if len(np.unique(labels)) < 2:
            return 0.0
        return float(_sk_chi(X, labels))

    @staticmethod
    def normalized_mutual_info(labels_true, labels_pred) -> float:
        """
        Normalized Mutual Information (NMI).

        Formula:
            NMI(U, V) = 2 × I(U; V) / (H(U) + H(V))

        Where I = mutual information, H = entropy.

        Range: [0, 1].  1 = perfect agreement.

        Reference:
            Strehl, A. & Ghosh, J. (2002). "Cluster ensembles."
            JMLR, 3, 583-617.
            DOI: 10.1162/153244303321897735
        """
        return float(_sk_nmi(labels_true, labels_pred))

    @staticmethod
    def adjusted_rand_index(labels_true, labels_pred) -> float:
        """
        Adjusted Rand Index (ARI).

        Corrects the Rand Index for chance groupings.

        Range: [-1, 1].  1 = perfect, 0 = random, <0 = worse than random.

        Reference:
            Hubert, L. & Arabie, P. (1985). "Comparing partitions."
            Journal of Classification, 2(1), 193-218.
            DOI: 10.1007/BF01908075
        """
        return float(_sk_ari(labels_true, labels_pred))

    @staticmethod
    def clustering_report(X, labels,
                          labels_true=None) -> Dict[str, Any]:
        """Complete clustering evaluation report."""
        report = {
            "silhouette_score": ClusteringMetrics.silhouette_score(X, labels),
            "davies_bouldin_index": ClusteringMetrics.davies_bouldin_index(X, labels),
            "calinski_harabasz_index": ClusteringMetrics.calinski_harabasz_index(X, labels),
            "n_clusters": int(len(np.unique(labels))),
            "n_samples": int(len(labels)),
        }
        if labels_true is not None:
            report["nmi"] = ClusteringMetrics.normalized_mutual_info(labels_true, labels)
            report["ari"] = ClusteringMetrics.adjusted_rand_index(labels_true, labels)
        return report
