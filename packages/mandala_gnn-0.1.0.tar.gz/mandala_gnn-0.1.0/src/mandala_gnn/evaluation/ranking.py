"""
mandala_gnn.evaluation.ranking
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ranking evaluation metrics for link prediction and knowledge graphs.

References:
    [1] Voorhees, E.M. (1999). "The TREC-8 Question Answering Track Report."
        TREC 1999.  https://trec.nist.gov/pubs/trec8/papers/qa_report.pdf

    [2] Järvelin, K. & Kekäläinen, J. (2002). "Cumulated gain-based
        evaluation of IR techniques." ACM TOIS, 20(4), 422-446.
        DOI: 10.1145/582415.582418

    [3] Zhu, M. (2004). "Recall, Precision and Average Precision."
        Working Paper, University of Waterloo.

    [4] Bordes, A. et al. (2013). "Translating Embeddings for Modeling
        Multi-relational Data." NeurIPS 2013.  arXiv: 1301.4083
"""

import numpy as np
from typing import List, Dict, Any


class RankingMetrics:
    """
    Ranking evaluation for link prediction and knowledge graph tasks.

    Example::

        from mandala_gnn.evaluation import RankingMetrics as RM

        # Ranks of correct answers in prediction lists
        ranks = [1, 3, 2, 10, 1]
        print(RM.mean_reciprocal_rank(ranks))  # MRR
        print(RM.hits_at_k(ranks, k=3))        # Hits@3
    """

    @staticmethod
    def mean_reciprocal_rank(ranks: List[int]) -> float:
        """
        Mean Reciprocal Rank (MRR).

        Formula:
            MRR = (1/|Q|) × Σ_{i=1}^{|Q|}  1 / rank_i

        Where rank_i is the rank position of the first correct answer.

        Reference:
            Voorhees, E.M. (1999). "The TREC-8 Question Answering Track."
            https://trec.nist.gov/pubs/trec8/papers/qa_report.pdf
        """
        if not ranks:
            return 0.0
        return float(np.mean([1.0 / r for r in ranks if r > 0]))

    @staticmethod
    def hits_at_k(ranks: List[int], k: int = 10) -> float:
        """
        Hits@K — fraction of correct answers ranked within top K.

        Formula:
            Hits@K = (1/|Q|) × Σ 𝟙(rank_i ≤ K)

        Common values: K ∈ {1, 3, 10}.

        Reference:
            Bordes, A. et al. (2013). "Translating Embeddings for Modeling
            Multi-relational Data." NeurIPS 2013.
            arXiv: https://arxiv.org/abs/1301.4083
        """
        if not ranks:
            return 0.0
        return float(np.mean([1.0 if r <= k else 0.0 for r in ranks]))

    @staticmethod
    def ndcg_at_k(relevances: List[float], k: int = 10) -> float:
        """
        Normalized Discounted Cumulative Gain at K (NDCG@K).

        Formula:
            DCG@K  = Σ_{i=1}^{K}  rel_i / log₂(i + 1)
            IDCG@K = DCG@K for ideal ranking
            NDCG@K = DCG@K / IDCG@K

        Range: [0, 1].  1.0 = perfect ranking.

        Reference:
            Järvelin, K. & Kekäläinen, J. (2002). "Cumulated gain-based
            evaluation of IR techniques." ACM TOIS, 20(4), 422-446.
            DOI: 10.1145/582415.582418
        """
        def _dcg(rels, k):
            rels = np.asarray(rels[:k], dtype=float)
            if len(rels) == 0:
                return 0.0
            discounts = np.log2(np.arange(1, len(rels) + 1) + 1)
            return float(np.sum(rels / discounts))

        dcg = _dcg(relevances, k)
        ideal = sorted(relevances, reverse=True)
        idcg = _dcg(ideal, k)
        if idcg == 0:
            return 0.0
        return dcg / idcg

    @staticmethod
    def mean_average_precision(y_true_lists: List[List[int]],
                               y_score_lists: List[List[float]]) -> float:
        """
        Mean Average Precision (MAP).

        Formula:
            AP  = Σ_{k} (Precision@k × rel(k)) / |relevant|
            MAP = mean of AP over all queries

        Reference:
            Zhu, M. (2004). "Recall, Precision and Average Precision."
            University of Waterloo.
        """
        aps = []
        for y_true, y_scores in zip(y_true_lists, y_score_lists):
            y_true = np.asarray(y_true)
            y_scores = np.asarray(y_scores)
            order = np.argsort(-y_scores)
            y_sorted = y_true[order]

            n_relevant = y_true.sum()
            if n_relevant == 0:
                aps.append(0.0)
                continue

            cumsum = np.cumsum(y_sorted)
            precisions = cumsum / np.arange(1, len(y_sorted) + 1)
            ap = (precisions * y_sorted).sum() / n_relevant
            aps.append(float(ap))

        return float(np.mean(aps)) if aps else 0.0

    @staticmethod
    def precision_at_k(y_true: List[int], y_scores: List[float],
                       k: int = 10) -> float:
        """
        Precision@K — fraction of relevant items in top-K predictions.

        Formula:
            P@K = |{relevant items in top-K}| / K
        """
        y_true = np.asarray(y_true)
        y_scores = np.asarray(y_scores)
        top_k = np.argsort(-y_scores)[:k]
        return float(y_true[top_k].sum() / k)

    @staticmethod
    def ranking_report(ranks: List[int]) -> Dict[str, float]:
        """Complete ranking report."""
        return {
            "mrr": RankingMetrics.mean_reciprocal_rank(ranks),
            "hits@1": RankingMetrics.hits_at_k(ranks, 1),
            "hits@3": RankingMetrics.hits_at_k(ranks, 3),
            "hits@10": RankingMetrics.hits_at_k(ranks, 10),
            "mean_rank": float(np.mean(ranks)) if ranks else 0.0,
            "median_rank": float(np.median(ranks)) if ranks else 0.0,
        }
