"""mandala_gnn.embed — Native graph embedding methods."""

from mandala_gnn.embed.spectral import SpectralEmbedder

__all__ = ["SpectralEmbedder"]
