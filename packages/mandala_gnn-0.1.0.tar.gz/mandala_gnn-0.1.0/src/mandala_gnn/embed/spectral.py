"""
mandala_gnn.embed.spectral
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Native graph embedding via spectral methods.

These methods produce node embeddings using only the graph structure
(adjacency matrix), requiring no external ML models or training data.

References:
    [1] Belkin, M. & Niyogi, P. (2003). "Laplacian Eigenmaps for
        Dimensionality Reduction and Data Representation."
        Neural Computation, 15(6), 1373-1396.
        DOI: 10.1162/089976603321780317

    [2] Von Luxburg, U. (2007). "A Tutorial on Spectral Clustering."
        Statistics and Computing, 17(4), 395-416.
        DOI: 10.1007/s11222-007-9033-z

    [3] Fiedler, M. (1973). "Algebraic Connectivity of Graphs."
        Czechoslovak Mathematical Journal, 23(2), 298-305.
"""

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh
from typing import Optional, Tuple, List
from ..core.graph import MandalaGraph


class SpectralEmbedder:
    """
    Graph embeddings via spectral decomposition.

    Provides two methods:
    1. **Laplacian Eigenmaps** — project nodes into a low-dimensional
       space that preserves local neighbourhood structure.
    2. **Adjacency Spectral Embedding** — SVD of the adjacency matrix.

    Example::

        embedder = SpectralEmbedder(n_components=3)
        node_embeddings, node_ids = embedder.fit_transform(graph)
        # node_embeddings.shape => (n_nodes, 3)
    """

    def __init__(self, n_components: int = 2):
        """
        Args:
            n_components: Embedding dimensionality.
        """
        self.n_components = n_components
        self._embeddings = None
        self._node_ids = None

    def laplacian_eigenmaps(
        self,
        graph: MandalaGraph,
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Laplacian Eigenmaps (Belkin & Niyogi, 2003).

        Procedure:
            1. Compute graph Laplacian: L = D - A
            2. Solve generalised eigenvalue problem: L f = λ D f
            3. Select the k smallest non-zero eigenvalues
            4. Use corresponding eigenvectors as embedding coordinates

        The embedding preserves local structure: connected nodes
        are mapped to nearby points in the embedding space.

        Formula:
            min  Σ_{(i,j) ∈ E}  w_ij ‖y_i - y_j‖²
            s.t. Y^T D Y = I

        This is equivalent to:
            min  tr(Y^T L Y)  s.t.  Y^T D Y = I

        Reference:
            Belkin, M. & Niyogi, P. (2003). "Laplacian Eigenmaps for
            Dimensionality Reduction and Data Representation."
            Neural Computation, 15(6), 1373-1396.
            DOI: 10.1162/089976603321780317

        Returns:
            (embeddings, node_ids) — (N × n_components) matrix and list of node IDs.
        """
        A, node_ids = graph.to_adjacency_matrix()
        # Make symmetric for undirected Laplacian
        A_sym = (A + A.T) / 2.0
        n = A_sym.shape[0]

        if n <= self.n_components + 1:
            # Graph too small — return positions as-is
            self._embeddings = A_sym[:, :self.n_components]
            self._node_ids = node_ids
            return self._embeddings, node_ids

        # Degree matrix and Laplacian
        D = np.diag(A_sym.sum(axis=1))
        L = D - A_sym

        # Convert to sparse for efficiency
        L_sp = sparse.csr_matrix(L)
        D_sp = sparse.csr_matrix(D)

        # Add small epsilon to D to avoid singularity
        D_reg = D_sp + sparse.eye(n) * 1e-10

        # Compute smallest eigenvalues (skip the first trivial one)
        k = min(self.n_components + 1, n - 1)
        try:
            eigenvalues, eigenvectors = eigsh(
                L_sp, k=k, M=D_reg, which="SM", sigma=0
            )
            # Skip first eigenvector (constant, eigenvalue ≈ 0)
            embeddings = eigenvectors[:, 1:self.n_components + 1]
        except Exception:
            # Fallback: use standard eigendecomposition
            eigenvalues, eigenvectors = np.linalg.eigh(L)
            embeddings = eigenvectors[:, 1:self.n_components + 1]

        self._embeddings = embeddings
        self._node_ids = node_ids
        return embeddings, node_ids

    def adjacency_spectral(
        self,
        graph: MandalaGraph,
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Adjacency Spectral Embedding via truncated SVD.

        Procedure:
            A ≈ U_k Σ_k V_k^T
            Embedding = U_k √Σ_k

        Uses the top-k singular values of the adjacency matrix.

        Reference:
            Von Luxburg, U. (2007). "A Tutorial on Spectral Clustering."
            Statistics and Computing, 17(4), 395-416.
            DOI: 10.1007/s11222-007-9033-z

        Returns:
            (embeddings, node_ids)
        """
        A, node_ids = graph.to_adjacency_matrix()
        A_sym = (A + A.T) / 2.0
        n = A_sym.shape[0]

        k = min(self.n_components, n - 1)
        if k < 1:
            self._embeddings = np.zeros((n, 1))
            self._node_ids = node_ids
            return self._embeddings, node_ids

        A_sp = sparse.csr_matrix(A_sym)
        try:
            eigenvalues, eigenvectors = eigsh(A_sp, k=k, which="LM")
            # Scale by sqrt of eigenvalues
            scale = np.sqrt(np.abs(eigenvalues))
            embeddings = eigenvectors * scale[np.newaxis, :]
        except Exception:
            eigenvalues, eigenvectors = np.linalg.eigh(A_sym)
            idx = np.argsort(-np.abs(eigenvalues))[:k]
            scale = np.sqrt(np.abs(eigenvalues[idx]))
            embeddings = eigenvectors[:, idx] * scale

        self._embeddings = embeddings
        self._node_ids = node_ids
        return embeddings, node_ids

    def fit_transform(
        self,
        graph: MandalaGraph,
        method: str = "laplacian",
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Convenience method — calls the specified embedding method.

        Args:
            graph: A ``MandalaGraph`` instance.
            method: 'laplacian' or 'adjacency'.

        Returns:
            (embeddings, node_ids)
        """
        if method == "laplacian":
            return self.laplacian_eigenmaps(graph)
        elif method == "adjacency":
            return self.adjacency_spectral(graph)
        else:
            raise ValueError(f"Unknown method: {method}. Use 'laplacian' or 'adjacency'.")

    def fiedler_vector(self, graph: MandalaGraph) -> Tuple[np.ndarray, List[str]]:
        """
        Fiedler vector — the eigenvector associated with the second-smallest
        eigenvalue of the graph Laplacian.

        Used for graph bisection: nodes with positive values go in one
        partition, negative in the other.

        Reference:
            Fiedler, M. (1973). "Algebraic Connectivity of Graphs."
            Czechoslovak Mathematical Journal, 23(2), 298-305.

        Returns:
            (fiedler_vector, node_ids)
        """
        A, node_ids = graph.to_adjacency_matrix()
        A_sym = (A + A.T) / 2.0
        D = np.diag(A_sym.sum(axis=1))
        L = D - A_sym
        eigenvalues, eigenvectors = np.linalg.eigh(L)
        # Second-smallest eigenvalue (algebraic connectivity)
        return eigenvectors[:, 1], node_ids
