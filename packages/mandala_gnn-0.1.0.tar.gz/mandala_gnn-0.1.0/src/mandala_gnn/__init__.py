"""
Mandala-GNN — Native Graph Neural Network & Knowledge Graph Analytics.

A lightweight, pure-Python library for graph construction, analysis,
and learning. All GNN layers are implemented natively in NumPy/SciPy,
with algorithms backed by peer-reviewed scientific publications.
"""

__version__ = "0.2.0"

# ── Core ─────────────────────────────────────────────────────────────
from mandala_gnn.core.graph import MandalaGraph
from mandala_gnn.core.pathfinder import Pathfinder

# ── Native GNN Layers ────────────────────────────────────────────────
from mandala_gnn.nn.conv import GCNConv, GATConv, GATv2Conv, SAGEConv, GINConv
from mandala_gnn.nn.models import GCN, GAT, GraphSAGE, GIN
from mandala_gnn.nn.pool import GlobalMeanPool, GlobalMaxPool, GlobalSumPool

# ── Graph Analytics ──────────────────────────────────────────────────
from mandala_gnn.analytics.centrality import CentralityAnalyzer
from mandala_gnn.analytics.community import CommunityDetector
from mandala_gnn.analytics.similarity import SimilarityEngine
from mandala_gnn.analytics.metrics import GraphMetrics

# ── Evaluation ───────────────────────────────────────────────────────
from mandala_gnn.evaluation.classification import ClassificationMetrics
from mandala_gnn.evaluation.ranking import RankingMetrics
from mandala_gnn.evaluation.clustering_metrics import ClusteringMetrics
from mandala_gnn.evaluation.regression_metrics import RegressionMetrics

# ── ML ───────────────────────────────────────────────────────────────
from mandala_gnn.ml.clustering import Clusterer
from mandala_gnn.ml.regression import OutcomePredictor
from mandala_gnn.ml.link_prediction import LinkPredictor

# ── Embeddings ───────────────────────────────────────────────────────
from mandala_gnn.embed.spectral import SpectralEmbedder

__all__ = [
    # Core
    "MandalaGraph", "Pathfinder",
    # GNN
    "GCNConv", "GATConv", "GATv2Conv", "SAGEConv", "GINConv",
    "GCN", "GAT", "GraphSAGE", "GIN",
    "GlobalMeanPool", "GlobalMaxPool", "GlobalSumPool",
    # Analytics
    "CentralityAnalyzer", "CommunityDetector", "SimilarityEngine", "GraphMetrics",
    # Evaluation
    "ClassificationMetrics", "RankingMetrics", "ClusteringMetrics", "RegressionMetrics",
    # ML
    "Clusterer", "OutcomePredictor", "LinkPredictor",
    # Embeddings
    "SpectralEmbedder",
]
