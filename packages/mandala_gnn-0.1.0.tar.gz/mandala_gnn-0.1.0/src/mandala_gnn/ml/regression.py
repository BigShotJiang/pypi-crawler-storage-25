"""
mandala_gnn.ml.regression
~~~~~~~~~~~~~~~~~~~~~~~~~~
Binary-outcome predictor with evaluation and cross-validation.

References:
    [1] Cox, D.R. (1958). "The regression analysis of binary sequences."
        JRSS Series B, 20(2), 215-242.
        DOI: 10.1111/j.2517-6161.1958.tb00292.x

    [2] Van Rijsbergen, C.J. (1979). Information Retrieval. 2nd ed.
        Butterworths.  ISBN: 0408709294
"""

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
import numpy as np
from typing import List, Optional, Dict, Any


class OutcomePredictor:
    """
    Logistic regression wrapper for predicting binary outcomes,
    with built-in evaluation and cross-validation.

    Reference:
        Cox, D.R. (1958). "The regression analysis of binary sequences."
        JRSS Series B, 20(2), 215-242.
        DOI: 10.1111/j.2517-6161.1958.tb00292.x

    Examples::

        p = OutcomePredictor(positive_label="pass", negative_label="fail")
        p.fit(X=[[90,1.0],[80,0.9],[40,0.3],[30,0.2]], y=[1,1,0,0])
        p.predict([[85, 0.95]])      # => ['pass']
        p.predict_proba([[85, 0.95]]) # => [0.97]
        p.evaluate(X_test, y_test)    # => {'accuracy': ..., 'f1': ...}
    """

    def __init__(
        self,
        positive_label: str = "positive",
        negative_label: str = "negative",
        **sklearn_kwargs,
    ):
        self.positive_label = positive_label
        self.negative_label = negative_label
        self.model = LogisticRegression(**sklearn_kwargs)
        self.is_fitted = False
        self._X = None
        self._y = None

    def fit(self, X: List[List[float]], y: List[int]) -> "OutcomePredictor":
        """
        Train on feature matrix *X* and binary labels *y* (0 or 1).
        Returns self for chaining.
        """
        self._X = np.asarray(X)
        self._y = np.asarray(y)
        self.model.fit(self._X, self._y)
        self.is_fitted = True
        return self

    def predict_proba(self, X: List[List[float]]) -> List[float]:
        """Probability of the *positive* outcome for each row."""
        if not self.is_fitted:
            return [0.5] * len(X)
        return self.model.predict_proba(np.asarray(X))[:, 1].tolist()

    def predict(self, X: List[List[float]]) -> List[str]:
        """Returns human-readable label for each row."""
        if not self.is_fitted:
            return [self.negative_label] * len(X)
        indices = self.model.predict(np.asarray(X))
        return [
            self.positive_label if idx == 1 else self.negative_label
            for idx in indices
        ]

    def evaluate(self, X: List[List[float]], y: List[int]) -> Dict[str, float]:
        """
        Evaluate with accuracy, precision, recall, F1, and MCC.

        Reference:
            Van Rijsbergen (1979), Matthews (1975).
        """
        from ..evaluation.classification import ClassificationMetrics as CM

        if not self.is_fitted:
            return {}
        y_true = np.asarray(y)
        y_pred = self.model.predict(np.asarray(X))

        return {
            "accuracy": CM.accuracy(y_true, y_pred),
            "precision": CM.precision(y_true, y_pred, "binary", 1),
            "recall": CM.recall(y_true, y_pred, "binary", 1),
            "f1": CM.f1_score(y_true, y_pred, "binary", 1),
            "mcc": CM.matthews_corrcoef(y_true, y_pred),
        }

    def confusion_matrix(self, X: List[List[float]], y: List[int]) -> np.ndarray:
        """Returns the 2×2 confusion matrix."""
        from ..evaluation.classification import ClassificationMetrics as CM

        if not self.is_fitted:
            return np.zeros((2, 2), dtype=int)
        y_pred = self.model.predict(np.asarray(X))
        return CM.confusion_matrix(y, y_pred)

    def cross_validate(
        self,
        X: Optional[List[List[float]]] = None,
        y: Optional[List[int]] = None,
        cv: int = 5,
    ) -> Dict[str, float]:
        """
        K-fold cross-validation.

        Args:
            X: Features (uses training data if None).
            y: Labels (uses training labels if None).
            cv: Number of folds.

        Returns:
            Mean and std of accuracy and F1 across folds.
        """
        X = np.asarray(X) if X is not None else self._X
        y = np.asarray(y) if y is not None else self._y

        if X is None or y is None or len(X) < cv:
            return {}

        model = LogisticRegression()
        n_folds = min(cv, len(X))

        acc = cross_val_score(model, X, y, cv=n_folds, scoring="accuracy")
        f1 = cross_val_score(model, X, y, cv=n_folds, scoring="f1")

        return {
            "accuracy_mean": float(acc.mean()),
            "accuracy_std": float(acc.std()),
            "f1_mean": float(f1.mean()),
            "f1_std": float(f1.std()),
        }
