"""
mandala_gnn.ml.link_prediction
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Link prediction using graph-structural features.

Extracts topological features for node pairs and trains a classifier
to predict whether an edge should exist.

Features used (with references):
    - Common Neighbors
    - Jaccard Index (Jaccard, 1901)
    - Adamic-Adar Index (Adamic & Adar, 2003)
    - Preferential Attachment (Barabási & Albert, 1999)
    - Resource Allocation (Zhou et al., 2009)

References:
    Liben-Nowell, D. & Kleinberg, J. (2007). "The link-prediction problem
    for social networks." JASIST, 58(7), 1019-1031.
    DOI: 10.1002/asi.20591
"""

import numpy as np
from typing import List, Tuple, Dict, Optional, Any
from sklearn.linear_model import LogisticRegression
from ..core.graph import MandalaGraph
from ..analytics.similarity import SimilarityEngine


class LinkPredictor:
    """
    Predicts missing or future edges using structural graph features.

    Pipeline:
        1. Extract features for each node pair (CN, Jaccard, AA, PA, RA)
        2. Train a Logistic Regression classifier
        3. Predict probability of edge existence

    Reference:
        Liben-Nowell, D. & Kleinberg, J. (2007). "The link-prediction
        problem for social networks." JASIST, 58(7), 1019-1031.
        DOI: 10.1002/asi.20591

    Example::

        lp = LinkPredictor(graph)
        lp.fit()
        predictions = lp.predict_top_k(k=5)
        # => [('A', 'D', 0.91), ('B', 'E', 0.87), ...]
    """

    def __init__(self, graph: MandalaGraph, seed: int = 42):
        self.graph = graph
        self.sim = SimilarityEngine(graph)
        self.model = LogisticRegression(random_state=seed, max_iter=1000)
        self.is_fitted = False
        self._seed = seed

    def _extract_features(self, u: str, v: str) -> List[float]:
        """Extract 5 structural features for a node pair."""
        return [
            float(self.sim.common_neighbors(u, v)),
            self.sim.jaccard(u, v),
            self.sim.adamic_adar(u, v),
            float(self.sim.preferential_attachment(u, v)),
            self.sim.resource_allocation(u, v),
        ]

    def _generate_samples(
        self, negative_ratio: float = 1.0
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate positive (existing edges) and negative (non-edges) samples.

        Args:
            negative_ratio: Ratio of negative to positive samples.
        """
        rng = np.random.RandomState(self._seed)
        nodes = list(self.graph.graph.nodes())
        edges = set(self.graph.graph.edges())

        # Positive samples
        X_pos = []
        for u, v in edges:
            X_pos.append(self._extract_features(u, v))

        # Negative samples
        n_neg = int(len(X_pos) * negative_ratio)
        X_neg = []
        attempts = 0
        while len(X_neg) < n_neg and attempts < n_neg * 10:
            u = rng.choice(nodes)
            v = rng.choice(nodes)
            if u != v and (u, v) not in edges:
                X_neg.append(self._extract_features(u, v))
            attempts += 1

        X = np.array(X_pos + X_neg)
        y = np.array([1] * len(X_pos) + [0] * len(X_neg))
        return X, y

    def fit(self, negative_ratio: float = 1.0) -> "LinkPredictor":
        """
        Train the link predictor on the current graph.

        Args:
            negative_ratio: Ratio of negative to positive training samples.

        Returns:
            self (for chaining).
        """
        X, y = self._generate_samples(negative_ratio)
        if len(X) < 2 or len(np.unique(y)) < 2:
            self.is_fitted = False
            return self
        self.model.fit(X, y)
        self.is_fitted = True
        return self

    def predict_pair(self, u: str, v: str) -> float:
        """Predict probability that edge (u → v) should exist."""
        if not self.is_fitted:
            return 0.5
        features = np.array([self._extract_features(u, v)])
        return float(self.model.predict_proba(features)[0, 1])

    def predict_top_k(
        self, k: int = 10, exclude_existing: bool = True
    ) -> List[Tuple[str, str, float]]:
        """
        Predict the top-K most likely missing edges.

        Args:
            k: Number of predictions to return.
            exclude_existing: Skip edges that already exist.

        Returns:
            List of (source, target, probability) sorted by probability.
        """
        if not self.is_fitted:
            return []

        nodes = list(self.graph.graph.nodes())
        edges = set(self.graph.graph.edges())
        candidates = []

        for i, u in enumerate(nodes):
            for j, v in enumerate(nodes):
                if u == v:
                    continue
                if exclude_existing and (u, v) in edges:
                    continue
                prob = self.predict_pair(u, v)
                candidates.append((u, v, prob))

        candidates.sort(key=lambda x: x[2], reverse=True)
        return candidates[:k]

    def evaluate(self) -> Dict[str, float]:
        """
        Evaluate the predictor using cross-validation on current graph.

        Returns AUC-ROC and accuracy via 5-fold CV.
        """
        from sklearn.model_selection import cross_val_score

        X, y = self._generate_samples()
        if len(X) < 10 or len(np.unique(y)) < 2:
            return {"auc_roc": 0.0, "accuracy": 0.0}

        model = LogisticRegression(random_state=self._seed, max_iter=1000)
        try:
            auc = cross_val_score(model, X, y, cv=min(5, len(X)),
                                  scoring="roc_auc").mean()
            acc = cross_val_score(model, X, y, cv=min(5, len(X)),
                                  scoring="accuracy").mean()
        except Exception:
            auc, acc = 0.0, 0.0

        return {"auc_roc": float(auc), "accuracy": float(acc)}
