"""
mandala_gnn.ml.clustering
~~~~~~~~~~~~~~~~~~~~~~~~~~
K-Means clustering with validation metrics.

References:
    [1] MacQueen, J.B. (1967). "Some methods for classification and analysis
        of multivariate observations." Proc. 5th Berkeley Symposium, 1, 281-297.
        https://projecteuclid.org/euclid.bsmsp/1200512992

    [2] Rousseeuw, P.J. (1987). "Silhouettes: A graphical aid to the
        interpretation and validation of cluster analysis."
        JCAM, 20, 53-65.   DOI: 10.1016/0377-0427(87)90125-7

    [3] Davies, D.L. & Bouldin, D.W. (1979). "A cluster separation measure."
        IEEE TPAMI, 1(2), 224-227.  DOI: 10.1109/TPAMI.1979.4766909
"""

from sklearn.cluster import KMeans
import numpy as np
from typing import List, Optional, Dict, Any
from ..evaluation.clustering_metrics import ClusteringMetrics


class Clusterer:
    """
    K-Means clusterer with built-in validation metrics.

    Args:
        n_clusters: Number of groups to create.
        labels: Optional human-readable names for each cluster index.
        random_state: Seed for reproducibility.

    Reference:
        MacQueen, J.B. (1967). "Some methods for classification and
        analysis of multivariate observations." 5th Berkeley Symposium.

    Examples::

        c = Clusterer(n_clusters=3, labels=["visual", "reading", "practice"])
        c.fit([[0.9,0.1], [0.1,0.9], [0.5,0.5], ...])
        c.predict([[0.8, 0.2]])
        c.evaluate()  # Silhouette, Davies-Bouldin, Calinski-Harabasz
    """

    def __init__(
        self,
        n_clusters: int = 3,
        labels: Optional[List[str]] = None,
        random_state: int = 42,
    ):
        self.n_clusters = n_clusters
        self.labels = labels or [str(i) for i in range(n_clusters)]
        self.model = KMeans(
            n_clusters=n_clusters, random_state=random_state, n_init="auto"
        )
        self.is_fitted = False
        self._X = None

    def fit(self, vectors: List[List[float]]) -> "Clusterer":
        """Train on a matrix of feature vectors. Returns self for chaining."""
        self._X = np.asarray(vectors)
        self.model.fit(self._X)
        self.is_fitted = True
        return self

    def predict(self, vectors: List[List[float]]) -> List[Dict[str, Any]]:
        """
        Assigns each vector to a cluster.

        Returns a list of dicts::

            [{"cluster": 1, "label": "reading"}, ...]
        """
        if not self.is_fitted:
            raise RuntimeError("Call .fit() before .predict().")
        indices = self.model.predict(np.asarray(vectors))
        return [
            {"cluster": int(idx), "label": self.labels[idx]}
            for idx in indices
        ]

    def predict_index(self, vectors: List[List[float]]) -> List[int]:
        """Lightweight variant — returns raw cluster indices only."""
        if not self.is_fitted:
            raise RuntimeError("Call .fit() before .predict_index().")
        return self.model.predict(np.asarray(vectors)).tolist()

    @property
    def centers(self) -> List[List[float]]:
        """Cluster centroids (available after fit)."""
        if not self.is_fitted:
            return []
        return self.model.cluster_centers_.tolist()

    @property
    def inertia(self) -> float:
        """
        Sum of squared distances to closest cluster centre.
        Lower = tighter clusters.
        """
        if not self.is_fitted:
            return 0.0
        return float(self.model.inertia_)

    def evaluate(self) -> Dict[str, float]:
        """
        Evaluate clustering quality using validation metrics.

        Returns:
            - silhouette_score (Rousseeuw, 1987)
            - davies_bouldin_index (Davies & Bouldin, 1979)
            - calinski_harabasz_index (Caliński & Harabasz, 1974)
            - inertia
        """
        if not self.is_fitted or self._X is None:
            return {}
        labels = self.model.labels_
        report = ClusteringMetrics.clustering_report(self._X, labels)
        report["inertia"] = self.inertia
        return report

    def elbow_analysis(
        self,
        vectors: List[List[float]],
        k_range: Optional[List[int]] = None,
    ) -> Dict[int, float]:
        """
        Elbow analysis — compute inertia for multiple values of K.

        Helps determine the optimal number of clusters by plotting
        inertia vs K and looking for the "elbow" point.

        Args:
            vectors: Feature matrix.
            k_range: List of K values to test. Default: [2..10].

        Returns:
            {k: inertia} dict.
        """
        X = np.asarray(vectors)
        if k_range is None:
            k_range = list(range(2, min(11, len(X))))

        results = {}
        for k in k_range:
            model = KMeans(n_clusters=k, random_state=42, n_init="auto")
            model.fit(X)
            results[k] = float(model.inertia_)
        return results
