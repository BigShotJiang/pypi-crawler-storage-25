"""Tests for the cross-file hallucination detector."""

from qamigrate.core.hallucination import detect_hallucinations


REAL_LOGIN_PAGE_API = [
    "public LoginPage(Page page)",
    "public boolean isLoaded()",
    "public LoginPage enterUsername(String username)",
    "public LoginPage enterPassword(String password)",
    "public void clickLogin()",
    "public void login(String username, String password)",
    "public String getErrorMessage()",
    "public boolean isErrorDisplayed()",
    "public boolean isLoginSuccessful()",
]


class TestHallucinationDetector:
    def test_flags_invented_method(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        assertThat(loginPage.getSuccessIndicator()).isVisible();
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert len(results) == 1
        assert results[0].called_method == "LoginPage.getSuccessIndicator()"
        assert results[0].on_class == "LoginPage"
        # "getSuccessIndicator" has no close real method so similar_to may
        # be None or something else; don't assert on it strictly.

    def test_suggests_close_match(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        System.out.println(loginPage.getErrorMessge());  // typo
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert len(results) == 1
        assert results[0].similar_to is not None
        assert "getErrorMessage" in results[0].similar_to

    def test_real_calls_are_not_flagged(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        loginPage.enterUsername("u");
        loginPage.enterPassword("p");
        loginPage.clickLogin();
        assertTrue(loginPage.isLoginSuccessful());
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert results == []

    def test_unknown_receiver_is_ignored(self) -> None:
        """Calls on types we don't have signatures for (e.g. Page, Playwright
        built-ins) should not be flagged."""
        code = """
public class LoginTests {
    Page page;
    public void foo() {
        page.navigate("x");  // page is not a LoginPage
        page.locator("#x").click();
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert results == []

    def test_deduplicates_repeated_calls(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        loginPage.getFoo();
        loginPage.getFoo();
        loginPage.getFoo();
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert len(results) == 1

    def test_empty_inputs_return_empty(self) -> None:
        assert detect_hallucinations("", {"LoginPage": REAL_LOGIN_PAGE_API}) == []
        assert detect_hallucinations("some code", {}) == []

    def test_sensitivity_after_real_method_renamed(self) -> None:
        """
        Concrete scenario the user asked about: rename `isLoginSuccessful`
        in LoginPage -> `didLoginSucceed`, then re-migrate LoginTests alone.
        LoginTests still calls the old name. The detector must flag it.
        """
        login_tests_source = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        assertTrue(loginPage.isLoginSuccessful(), "Login failed");
    }
}
"""
        # Simulate a LoginPage that has been renamed -- "isLoginSuccessful"
        # no longer exists; it's "didLoginSucceed" now.
        renamed_api = [
            s.replace("isLoginSuccessful", "didLoginSucceed")
            for s in REAL_LOGIN_PAGE_API
        ]

        results = detect_hallucinations(login_tests_source, {"LoginPage": renamed_api})

        assert len(results) == 1
        assert results[0].called_method == "LoginPage.isLoginSuccessful()"
        # Should suggest the closest match (difflib.get_close_matches)
        assert results[0].similar_to is not None
        assert "didLoginSucceed" in results[0].similar_to
