"""
QAMigrate - AI-powered test framework migration.
"""

__version__ = "0.5.0"
__author__ = "QATonic Innovations"

from qamigrate.core.config import QAMigrateConfig
from qamigrate.core.report import MigrationRecord, MigrationReport, PatternSummary

__all__ = [
    "QAMigrateConfig",
    "MigrationRecord",
    "MigrationReport",
    "PatternSummary",
    "__version__",
]
