from django.apps import AppConfig


class PaletteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dj_palette'
    verbose_name = 'Palette'

