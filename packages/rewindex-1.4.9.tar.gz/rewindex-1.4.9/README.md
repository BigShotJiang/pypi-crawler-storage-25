# Rewindex

![python](https://img.shields.io/badge/python-3.10%2B-blue)
![license](https://img.shields.io/badge/license-proprietary-red)

![rewindex](https://raw.githubusercontent.com/crsxmd/rewindex/main/img/og-image.png)

**Rewindex - Reduce the risk of AI breaking your code.**

Records what your AI changed before you realize something broke. Audit and recover from your AI chat or the built-in dashboard. Free, runs locally.

- **Versioning**: snap, rewind, and track every change your AI makes
- **Change visibility**: view diffs, session logs, and full file history
- **Changelog**: flag milestones and export as CHANGELOG.md
- **Audit code**: let your AI review and audit it, or browse it yourself via the built-in dashboard

Works with any AI agent via MCP. Works with Git. Rewind the code that you didn't commit.

**[rewindex.org](https://rewindex.org)** | [GitHub](https://github.com/crsxmd/rewindex)

---

## What you get

- **Auto backup** - every file change is captured automatically. Nothing is ever lost.
- **Built-in dashboard** - browse snapshots, view diffs, and rewind from the browser or your AI chat. No extra install. No coding required.
- **Free to start** - free forever. No credit card. Upgrade only when you need more.
- **Runs locally** - everything stays on your machine. No cloud. No account required.
- **Audit code** - your AI already knows which file to check. Give it a bug and it traces that file's history to find exactly when it broke.

### Try it! Then ask your AI if it likes it.

---

## Quick Start

> **Supported platforms: macOS, Linux, and Windows (beta).**

Requires Python 3.10+.

---

### AI agent setup (recommended)

Paste this into your AI agent's chat. It handles everything including install, MCP setup, and init:

```text
Read https://raw.githubusercontent.com/crsxmd/rewindex/main/AI-SETUP.md and follow the setup instructions.
```

---

### Manual setup

**1. Install**
```bash
pipx install rewindex   # recommended
pip install rewindex    # alternative
uv tool install rewindex
```

**2. Add as MCP server** — see [mcp-register.md](https://github.com/crsxmd/rewindex/blob/main/mcp-register.md) for per-agent instructions

Supported agents: Claude Code, Cursor, Windsurf, Cline, Roo Code, Continue, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, Warp, OpenHands, Goose, Augment, Kilo Code, Junie, Hermes, and more

**3. Initialize your workspace**
```bash
rewindex init           # interactive — asks for workspace name and folder
```

---

## Dashboard

```bash
rewindex web
```

Open [http://localhost:9009](http://localhost:9009) — browse snapshots, view diffs, rewind files, manage flags and settings. Included in the package, no extra install needed.

---

## Pricing

Free forever. No account required.

Want to upgrade? Check [rewindex.org](https://rewindex.org)

---

## Documentation

- [Learn Rewindex](https://github.com/crsxmd/rewindex/blob/main/learnRewindex.md): everything you need to know about Rewindex as a user
- [AI Agent Setup](https://github.com/crsxmd/rewindex/blob/main/AI-SETUP.md): install guide for AI agents with per-agent MCP setup

---

## License

Proprietary. See [LICENSE](https://github.com/crsxmd/rewindex/blob/main/LICENSE) for details.
