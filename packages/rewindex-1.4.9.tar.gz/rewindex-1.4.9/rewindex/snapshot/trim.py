# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import hashlib
import logging
import os
import sqlite3

from rewindex.config.defaults import DEFAULT_SESSION_MAX, DEFAULT_SESSION_SAFE
from rewindex.db.queries import (
    get_all_tracked_files,
    get_file_versions_since,
    get_session_count,
    get_sessions_to_trim,
    mark_corrupted,
    promote_to_full_base,
)
from rewindex.snapshot.reconstruct import reconstruct
from rewindex.snapshot.storage import write_full

logger = logging.getLogger("rewindex.daemon")


def maybe_trim(conn: sqlite3.Connection, workspace: str) -> None:
    from rewindex.config.loader import load_config
    config = load_config()
    safe = config.get("session_safe", DEFAULT_SESSION_SAFE)
    max_val = config.get("session_max", DEFAULT_SESSION_MAX)

    count = get_session_count(conn, workspace)
    if count < max_val:
        return

    cut = max_val - safe
    if cut <= 0:
        return

    _run_trim(conn, workspace, cut)


def _run_trim(conn: sqlite3.Connection, workspace: str, cut: int) -> None:
    sessions = get_sessions_to_trim(conn, workspace, cut)
    if not sessions:
        return

    last_session_uid = sessions[-1]["uid"]
    boundary_uid = last_session_uid + 1

    tracked = get_all_tracked_files(conn, workspace)
    paths_to_delete: list[str] = []

    # Phase 1: promote fullbases (must happen before any deletion, outside transaction)
    promote_targets: list[tuple[int, str, int]] = []  # (registry_uid, filepath, first_kept_uid)
    ephemeral_registries: list[int] = []  # registries with ALL versions before boundary

    for reg in tracked:
        registry_uid = reg["uid"]
        filepath = reg["filepath"]

        versions = get_file_versions_since(conn, registry_uid, 0, limit=10000)
        if not versions:
            continue

        first_kept = None
        for v in versions:
            if v["session_uid"] is not None and v["session_uid"] >= boundary_uid:
                first_kept = v
                break

        if first_kept is None:
            ephemeral_registries.append(registry_uid)
            continue

        if not first_kept["is_full"]:
            try:
                lines = reconstruct(conn, registry_uid, first_kept["uid"])
                expected_hash = first_kept["hash"]
                if expected_hash and expected_hash != "__deleted__":
                    actual_hash = hashlib.sha256("".join(lines).encode("utf-8")).hexdigest()
                    if actual_hash != expected_hash:
                        logger.error(
                            "[trim] Hash mismatch for uid=%d (%s): expected %s, got %s — marking corrupted",
                            first_kept["uid"], filepath, expected_hash[:12], actual_hash[:12],
                        )
                        mark_corrupted(conn, first_kept["uid"])
                        continue
                storage_path, file_size = write_full(workspace, first_kept["uid"], filepath, lines)
                promote_to_full_base(conn, first_kept["uid"], storage_path, file_size, promoted_by="trim")
            except (ValueError, OSError):
                continue

        promote_targets.append((registry_uid, filepath, first_kept["uid"]))

    trimmed_session_uids = [s["uid"] for s in sessions]

    # Phase 2: delete old versions + sessions in a single transaction.
    # PRAGMA foreign_keys must be disabled before BEGIN — SQLite does not allow
    # changing it inside a transaction. We mark flags as orphaned (is_orphaned=1)
    # while FK is off so the flag record is preserved. session_uid keeps its
    # original value as a historical reference; SQLite only re-checks the FK on
    # that column when session_uid itself is updated (e.g. move_flag), not when
    # other columns on the same row change.
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.execute("BEGIN IMMEDIATE")
    try:
        for registry_uid, filepath, first_kept_uid in promote_targets:
            rows = conn.execute(
                "SELECT storage_path FROM file WHERE file_registry_uid = ? AND uid < ?",
                (registry_uid, first_kept_uid),
            ).fetchall()
            paths_to_delete.extend(r["storage_path"] for r in rows if r["storage_path"])
            conn.execute(
                "DELETE FROM file WHERE file_registry_uid = ? AND uid < ?",
                (registry_uid, first_kept_uid),
            )

        for registry_uid in ephemeral_registries:
            rows = conn.execute(
                "SELECT storage_path FROM file WHERE file_registry_uid = ?",
                (registry_uid,),
            ).fetchall()
            paths_to_delete.extend(r["storage_path"] for r in rows if r["storage_path"])
            conn.execute(
                "DELETE FROM file WHERE file_registry_uid = ?",
                (registry_uid,),
            )

        # Clean up any remaining file versions in trimmed sessions (including corrupted ones)
        leftover = conn.execute(
            """SELECT f.storage_path FROM file f
               JOIN file_registry r ON f.file_registry_uid = r.uid
               WHERE r.workspace = ? AND f.session_uid < ?""",
            (workspace, boundary_uid),
        ).fetchall()
        paths_to_delete.extend(r["storage_path"] for r in leftover if r["storage_path"])
        conn.execute(
            """DELETE FROM file WHERE uid IN (
               SELECT f.uid FROM file f
               JOIN file_registry r ON f.file_registry_uid = r.uid
               WHERE r.workspace = ? AND f.session_uid < ?)""",
            (workspace, boundary_uid),
        )

        # Preserve flags — mark as orphaned before deleting their sessions
        if trimmed_session_uids:
            placeholders = ",".join("?" * len(trimmed_session_uids))
            conn.execute(
                f"UPDATE flags SET is_orphaned = 1"
                f" WHERE workspace = ? AND session_uid IN ({placeholders})",
                (workspace, *trimmed_session_uids),
            )

        conn.execute(
            "DELETE FROM sessions WHERE workspace = ? AND uid < ?",
            (workspace, boundary_uid),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.execute("PRAGMA foreign_keys=ON")

    # Phase 3: disk cleanup (outside transaction — orphan sweep catches leftovers)
    for p in paths_to_delete:
        try:
            if p and os.path.isfile(p):
                os.remove(p)
        except OSError:
            pass


