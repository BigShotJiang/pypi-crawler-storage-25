# ibr-defused-algorithms

Independent PyPI module for:

- `IBR5Net` (5-stage from-scratch CNN)
- `IBR6Net` (6-stage from-scratch CNN)
- `FusedIBR5IBR6` (late fusion of IBR5 + IBR6 features)
- `IBR5MobileNetV2` (MobileNetV2 IBR5-style branch)
- `IBR6MobileNetV2` (MobileNetV2 IBR6-style branch)
- `FusedIBR5IBR6MobileNetV2` (fused MobileNetV2 branches)

TensorFlow/Keras backend only.

## Install

```bash
pip install ibr-defused-algorithms
```

## TensorFlow/Keras Usage

```python
import tensorflow as tf
from ibr_defused_algo import (
    FusedIBR5IBR6,
    FusedIBR5IBR6MobileNetV2,
    IBR5MobileNetV2,
    IBR5Net,
    IBR6MobileNetV2,
    IBR6Net,
)

# TensorFlow models expect NHWC tensors: [batch, height, width, channels]
x = tf.random.normal((4, 224, 224, 3))

ibr5 = IBR5Net(num_classes=7)
ibr6 = IBR6Net(num_classes=7)
fused = FusedIBR5IBR6(num_classes=7)
ibr5_mnv2 = IBR5MobileNetV2(num_classes=7, pretrained=False)
ibr6_mnv2 = IBR6MobileNetV2(num_classes=7, pretrained=False)
fused_mnv2 = FusedIBR5IBR6MobileNetV2(num_classes=7, pretrained=False)

print(ibr5(x).shape)     # [4, 7]
print(ibr6(x).shape)     # [4, 7]
print(fused(x).shape)    # [4, 7]
print(ibr5_mnv2(x).shape)   # [4, 7]
print(ibr6_mnv2(x).shape)   # [4, 7]
print(fused_mnv2(x).shape)  # [4, 7]

# Compile and train:
ibr5.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)
# ibr5.fit(train_ds, epochs=10)
```

### Framework sanity check (recommended in notebooks)

```python
import tensorflow as tf
from ibr_defused_algo.tensorflow_models import IBR5Net

print("Module:", IBR5Net.__module__)  # should be: ibr_defused_algo.tensorflow_models
model = IBR5Net(num_classes=7)
print("Is tf.keras.Model:", isinstance(model, tf.keras.Model))
```

If that last line prints `False`, the runtime is importing the wrong backend. Reinstall and restart kernel.

## Build & Publish

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```
