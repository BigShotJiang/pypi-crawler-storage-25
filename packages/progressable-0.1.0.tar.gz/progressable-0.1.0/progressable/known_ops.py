"""
Monkey-patches well-known C-extension functions and sklearn class methods so
they emit session progress events even though the AST transformer cannot reach them.

Two patch strategies
--------------------
- Module-level  (`_MODULE_OPS`): patches `module.attr`. Works when callers
  do `module.func()`. Fails for `from module import func` (already-bound local).
- Class-method  (`_CLASS_OPS`): patches the unbound method on the class itself.
  Works regardless of how the caller imported the module.
"""
from __future__ import annotations

from typing import Callable, Tuple


def _make_wrapper(original: Callable, label: str) -> Callable:
    def wrapper(*args, **kwargs):
        from . import _runtime
        t = _runtime.start(label)
        try:
            result = original(*args, **kwargs)
            _runtime.complete(label, t)
            return result
        except Exception:
            _runtime.error_event(label, t)
            raise
    wrapper.__wrapped__ = original  # type: ignore[attr-defined]
    wrapper.__name__ = getattr(original, "__name__", label)
    return wrapper


# (import_path, attr_chain, label)
_MODULE_OPS: Tuple[Tuple[str, str, str], ...] = (
    ("numpy.linalg", "svd",               "numpy.linalg.svd"),
    ("numpy.linalg", "eig",               "numpy.linalg.eig"),
    ("numpy.linalg", "eigh",              "numpy.linalg.eigh"),
    ("numpy.linalg", "lstsq",             "numpy.linalg.lstsq"),
    ("numpy.linalg", "solve",             "numpy.linalg.solve"),
    ("scipy.linalg", "svd",               "scipy.linalg.svd"),
    ("scipy.sparse.linalg", "svds",       "scipy.sparse.linalg.svds"),
    ("scipy.sparse.linalg", "eigs",       "scipy.sparse.linalg.eigs"),
)

# (import_path, class_attr, method_attr, label)
# Sklearn uses `from sklearn.utils.extmath import _randomized_svd` internally,
# so module-level patching is ineffective — class-method patching is required.
_CLASS_OPS: Tuple[Tuple[str, str, str, str], ...] = (
    ("sklearn.decomposition._pca",
     "PCA", "_fit_full",
     "sklearn.decomposition.PCA._fit_full"),
    ("sklearn.decomposition._pca",
     "PCA", "_fit_truncated",
     "sklearn.decomposition.PCA._fit_truncated"),
    ("sklearn.decomposition._truncated_svd",
     "TruncatedSVD", "fit_transform",
     "sklearn.decomposition.TruncatedSVD.fit_transform"),
    ("sklearn.decomposition._incremental_pca",
     "IncrementalPCA", "fit_transform",
     "sklearn.decomposition.IncrementalPCA.fit_transform"),
)

_patched: set[str] = set()


def patch_all() -> None:
    """Attempt to patch all known ops. Safe to call multiple times."""
    import importlib

    for mod_path, attr_chain, label in _MODULE_OPS:
        if label in _patched:
            continue
        try:
            mod = importlib.import_module(mod_path)
            parts = attr_chain.split(".")
            obj = mod
            for part in parts[:-1]:
                obj = getattr(obj, part)
            original = getattr(obj, parts[-1])
            if getattr(original, "__wrapped__", None) is not None:
                _patched.add(label)
                continue
            setattr(obj, parts[-1], _make_wrapper(original, label))
            _patched.add(label)
        except Exception:
            pass

    for mod_path, class_attr, method_attr, label in _CLASS_OPS:
        if label in _patched:
            continue
        try:
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, class_attr)
            original = getattr(cls, method_attr)
            if getattr(original, "__wrapped__", None) is not None:
                _patched.add(label)
                continue
            setattr(cls, method_attr, _make_wrapper(original, label))
            _patched.add(label)
        except Exception:
            pass
