"""
Event bus.

Event schema
------------
{
    "entry_point":   str          # top-level watched function, e.g. "scanpy.preprocessing._pca.pca"
    "current_step":  str          # innermost currently-running label
    "status":        str          # "running" | "completed" | "error"
    "percent":       float | None # 0.0–1.0, null on first run until total is known
    "elapsed_ms":    float        # milliseconds since entry_point started
    "timestamp":     str          # ISO-8601 UTC
}

One event is emitted on every step change (function start, complete, loop progress)
and on session end. Consumers never see raw started/completed pairs.
"""
from __future__ import annotations

import time
from typing import Callable, Dict, List, TYPE_CHECKING

if TYPE_CHECKING:
    from ._session import Session

Event = Dict[str, object]
_listeners: List[Callable[[Event], None]] = []


def on_event(fn: Callable[[Event], None]) -> None:
    _listeners.append(fn)


def emit_session(session: "Session", status: str) -> None:
    if not _listeners:
        return
    now = time.time()
    event: Event = {
        "entry_point": session.entry_point,
        "current_step": session.current_step,
        "status": status,
        "percent": session.percent if status != "completed" else 1.0,
        "elapsed_ms": (now - session.start_time) * 1000.0,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now)),
    }
    for fn in _listeners:
        try:
            fn(event)
        except Exception:
            pass
