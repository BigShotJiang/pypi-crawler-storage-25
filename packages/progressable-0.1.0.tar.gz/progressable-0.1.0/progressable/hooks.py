"""
sys.meta_path hook: intercepts module loading for watched packages and applies
the ProgressTransformer in memory before execution. Source files are never modified.

Usage (called by progressable.watch):
    hook = ProgressableHook()
    sys.meta_path.insert(0, hook)
    hook.add_package("scanpy")
"""
from __future__ import annotations

import ast
import importlib.abc
import importlib.machinery
import sys
from typing import Optional, Set

from .transformer import ProgressTransformer


class _ProgressableLoader(importlib.abc.Loader):
    """Wraps an original loader, applying AST transformation before exec."""

    def __init__(self, original_spec: importlib.machinery.ModuleSpec) -> None:
        self._original_spec = original_spec

    def create_module(self, spec: importlib.machinery.ModuleSpec) -> None:  # noqa: ARG002
        # Return None → use default module creation.
        return None

    def exec_module(self, module: object) -> None:
        origin = self._original_spec.origin

        if origin and origin.endswith(".py"):
            try:
                with open(origin, "r", encoding="utf-8", errors="replace") as fh:
                    source = fh.read()

                tree = ast.parse(source, filename=origin)
                transformer = ProgressTransformer(module.__name__)
                new_tree = transformer.visit(tree)
                ast.fix_missing_locations(new_tree)
                code = compile(new_tree, origin, "exec")
                exec(code, module.__dict__)  # noqa: S102
                return
            except Exception:
                # Never break the target library — fall through to original.
                pass

        self._original_spec.loader.exec_module(module)


class ProgressableHook(importlib.abc.MetaPathFinder):
    """MetaPathFinder that wraps loaders for watched packages."""

    def __init__(self) -> None:
        self._packages: Set[str] = set()

    def add_package(self, package: str) -> None:
        self._packages.add(package)

    def find_spec(
        self,
        fullname: str,
        path: Optional[object],
        target: Optional[object] = None,
    ) -> Optional[importlib.machinery.ModuleSpec]:
        top = fullname.split(".")[0]
        if top not in self._packages:
            return None

        # Ask every *other* finder for the real spec.
        for finder in sys.meta_path:
            if finder is self:
                continue
            try:
                spec = finder.find_spec(fullname, path, target)
            except Exception:
                continue
            if spec is None or spec.loader is None:
                continue
            # Only intercept pure-Python sources. C extensions (.so / .pyd)
            # must load via their original loader — wrapping them breaks their
            # internal symbol resolution.
            if not spec.origin or not spec.origin.endswith(".py"):
                continue

            new_spec = importlib.machinery.ModuleSpec(
                name=spec.name,
                loader=_ProgressableLoader(spec),
                origin=spec.origin,
                is_package=spec.submodule_search_locations is not None,
            )
            # _set_fileattr controls whether __file__ is populated on the module.
            # The real spec has this set by FileFinder; we must copy it so that
            # code like `Path(__file__).parent` works inside the target package.
            new_spec._set_fileattr = getattr(spec, "_set_fileattr", bool(spec.origin))
            if spec.submodule_search_locations is not None:
                new_spec.submodule_search_locations = list(
                    spec.submodule_search_locations
                )
            return new_spec

        return None
