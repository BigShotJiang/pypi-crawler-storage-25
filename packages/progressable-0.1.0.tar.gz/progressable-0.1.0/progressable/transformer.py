"""
In-memory AST transformer applied to every Python module in a watched package.

Rules
-----
- Injects `import progressable._runtime as __pg__` at module top.
- Instruments *substantial* functions: body >= 5 lines OR contains a loop.
  Generators are skipped (yield/yield-from).
- For loops: caches the iterable, reads __len__ for percent, emits per-iteration progress.
- While loops: emits per-iteration progress with null percent.
- All injected variable names are scoped with the source line number to avoid
  collisions with user code: __pg_t_42__, __pg_iter_42__, etc.
"""
from __future__ import annotations

import ast
from typing import List, Union

_IMPORT_STMT = "import progressable._runtime as __pg__"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _name(id_: str) -> ast.Name:
    return ast.Name(id=id_, ctx=ast.Load())


def _store(id_: str) -> ast.Name:
    return ast.Name(id=id_, ctx=ast.Store())


def _attr(obj: ast.expr, attr: str) -> ast.Attribute:
    return ast.Attribute(value=obj, attr=attr, ctx=ast.Load())


def _call(func: ast.expr, *args: ast.expr) -> ast.Call:
    return ast.Call(func=func, args=list(args), keywords=[])


def _expr(node: ast.expr) -> ast.Expr:
    return ast.Expr(value=node)


def _const(v: object) -> ast.Constant:
    return ast.Constant(value=v)


def _pg_call(method: str, *args: ast.expr) -> ast.Call:
    return _call(_attr(_name("__pg__"), method), *args)


# ---------------------------------------------------------------------------
# Transformer
# ---------------------------------------------------------------------------

class ProgressTransformer(ast.NodeTransformer):
    def __init__(self, module_name: str) -> None:
        self.module_name = module_name
        # Stack of function names as we descend — used to build qualified labels.
        self._func_stack: List[str] = []
        # Depth counter; loops are only instrumented inside functions.
        self._func_depth: int = 0

    # ------------------------------------------------------------------
    # Module: inject the __pg__ import once at the top
    # ------------------------------------------------------------------

    def visit_Module(self, node: ast.Module) -> ast.Module:
        self.generic_visit(node)
        import_node = ast.parse(_IMPORT_STMT).body[0]
        # Insert AFTER any module docstring and `from __future__` imports.
        # Python requires __future__ imports to precede all other statements.
        insert_at = 0
        for i, stmt in enumerate(node.body):
            if i == 0 and isinstance(stmt, ast.Expr) and isinstance(
                stmt.value, ast.Constant
            ):
                insert_at = 1  # skip module docstring
            elif isinstance(stmt, ast.ImportFrom) and stmt.module == "__future__":
                insert_at = i + 1
            else:
                break
        node.body.insert(insert_at, import_node)
        # Single pass over the full tree — generated nodes get locations from
        # their nearest real ancestor, avoiding end_lineno < lineno errors.
        ast.fix_missing_locations(node)
        return node

    # ------------------------------------------------------------------
    # Functions
    # ------------------------------------------------------------------

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        return self._instrument_func(node)

    def visit_AsyncFunctionDef(
        self, node: ast.AsyncFunctionDef
    ) -> ast.AsyncFunctionDef:
        return self._instrument_func(node)

    def _instrument_func(
        self, node: Union[ast.FunctionDef, ast.AsyncFunctionDef]
    ) -> Union[ast.FunctionDef, ast.AsyncFunctionDef]:
        # Skip generators entirely — don't transform their loops either,
        # since the loop body runs lazily and wrapping it would break iteration.
        if self._is_generator(node):
            return node

        # Descend first so inner loops/functions get their labels right.
        self._func_stack.append(node.name)
        self._func_depth += 1
        self.generic_visit(node)
        self._func_depth -= 1
        self._func_stack.pop()

        if not self._is_substantial(node):
            return node

        label = f"{self.module_name}.{'.'.join(self._func_stack + [node.name])}"
        ln = node.lineno
        t_var = f"__pg_t_{ln}__"

        # __pg_t_N__ = __pg__.start("label")
        start_assign = ast.Assign(
            targets=[_store(t_var)],
            value=_pg_call("start", _const(label)),
        )

        # __pg__.complete("label", __pg_t_N__)  — in finally
        complete_stmt = _expr(_pg_call("complete", _const(label), _name(t_var)))

        # __pg__.error_event("label", __pg_t_N__)  — in except, then re-raise
        error_stmt = _expr(_pg_call("error_event", _const(label), _name(t_var)))
        reraise = ast.Raise()

        except_handler = ast.ExceptHandler(
            type=_name("Exception"),
            name=None,
            body=[error_stmt, reraise],
        )

        # Preserve the docstring as the very first statement so that
        # `func.__doc__` is still set (decorators often assert it exists).
        body = node.body
        if (
            body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            docstring, body = [body[0]], body[1:]
        else:
            docstring = []

        try_node = ast.Try(
            body=body,
            handlers=[except_handler],
            orelse=[],
            finalbody=[complete_stmt],
        )

        node.body = docstring + [start_assign, try_node]
        return node

    # ------------------------------------------------------------------
    # For loops
    # ------------------------------------------------------------------

    def visit_For(self, node: ast.For) -> Union[ast.For, List[ast.stmt]]:
        if self._func_depth == 0:
            return node

        # Instrument children first (nested loops get their own labels).
        self.generic_visit(node)

        ln = node.lineno
        label = self._loop_label(ln)
        iter_var = f"__pg_iter_{ln}__"
        total_var = f"__pg_total_{ln}__"
        t_var = f"__pg_t_{ln}__"
        n_var = f"__pg_n_{ln}__"

        # __pg_iter_N__ = <original iter expr>
        cache_iter = ast.Assign(
            targets=[_store(iter_var)],
            value=node.iter,
        )

        # __pg_total_N__ = len(__pg_iter_N__) if hasattr(__pg_iter_N__, '__len__') else None
        total_assign = ast.Assign(
            targets=[_store(total_var)],
            value=ast.IfExp(
                test=_call(_name("hasattr"), _name(iter_var), _const("__len__")),
                body=_call(_name("len"), _name(iter_var)),
                orelse=_const(None),
            ),
        )

        # __pg_t_N__ = __pg__.start("label")
        start_assign = ast.Assign(
            targets=[_store(t_var)],
            value=_pg_call("start", _const(label)),
        )

        # __pg_n_N__ = 0
        counter_init = ast.Assign(
            targets=[_store(n_var)],
            value=_const(0),
        )

        # __pg__.progress("label", __pg_n_N__, __pg_total_N__, __pg_t_N__)
        progress_stmt = _expr(
            _pg_call("progress", _const(label), _name(n_var), _name(total_var), _name(t_var))
        )

        # __pg_n_N__ += 1
        counter_incr = ast.AugAssign(
            target=_store(n_var),
            op=ast.Add(),
            value=_const(1),
        )

        # Rewrite the for loop: iterate over cached iter, inject progress + counter
        node.iter = _name(iter_var)
        node.body = [progress_stmt, counter_incr] + node.body

        # __pg__.complete("label", __pg_t_N__)
        complete_stmt = _expr(_pg_call("complete", _const(label), _name(t_var)))

        return [cache_iter, total_assign, start_assign, counter_init, node, complete_stmt]

    # ------------------------------------------------------------------
    # While loops
    # ------------------------------------------------------------------

    def visit_While(self, node: ast.While) -> Union[ast.While, List[ast.stmt]]:
        if self._func_depth == 0:
            return node

        self.generic_visit(node)

        ln = node.lineno
        label = self._loop_label(ln)
        t_var = f"__pg_t_{ln}__"
        n_var = f"__pg_n_{ln}__"

        start_assign = ast.Assign(
            targets=[_store(t_var)],
            value=_pg_call("start", _const(label)),
        )
        counter_init = ast.Assign(
            targets=[_store(n_var)],
            value=_const(0),
        )

        # progress with null total
        progress_stmt = _expr(
            _pg_call("progress", _const(label), _name(n_var), _const(None), _name(t_var))
        )
        counter_incr = ast.AugAssign(
            target=_store(n_var),
            op=ast.Add(),
            value=_const(1),
        )

        node.body = [progress_stmt, counter_incr] + node.body
        complete_stmt = _expr(_pg_call("complete", _const(label), _name(t_var)))

        return [start_assign, counter_init, node, complete_stmt]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _loop_label(self, lineno: int) -> str:
        func_part = ".".join(self._func_stack) if self._func_stack else "<module>"
        return f"{self.module_name}.{func_part}.loop@L{lineno}"

    @staticmethod
    def _is_substantial(node: Union[ast.FunctionDef, ast.AsyncFunctionDef]) -> bool:
        body_lines = (
            (node.end_lineno - node.lineno)
            if hasattr(node, "end_lineno")
            else len(node.body)
        )
        has_loop = any(isinstance(n, (ast.For, ast.While)) for n in ast.walk(node))
        return body_lines >= 5 or has_loop

    @staticmethod
    def _is_generator(node: Union[ast.FunctionDef, ast.AsyncFunctionDef]) -> bool:
        return any(isinstance(n, (ast.Yield, ast.YieldFrom)) for n in ast.walk(node))
