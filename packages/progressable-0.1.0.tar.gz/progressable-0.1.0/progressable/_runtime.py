"""
Runtime helpers injected into transformed modules via:
    import progressable._runtime as __pg__

Session lifecycle
-----------------
- First call to start() with no active session → creates the session (that
  function becomes the entry_point).
- Every subsequent start() pushes a step onto the session's call stack.
- complete() pops the step; if it was the entry_point the session closes.
- progress() updates the session's loop-percent override for finer granularity.
"""
from __future__ import annotations

import time
from typing import Optional

from .events import emit_session
from ._session import current_session, end_session, start_session


def start(label: str) -> float:
    t = time.time()
    session = current_session()
    if session is None:
        session = start_session(label, t)
    else:
        session.on_start(label)
    emit_session(session, "running")
    return t


def complete(label: str, _: float) -> None:
    session = current_session()
    if session is None:
        return
    done = session.on_complete(label)
    if done:
        emit_session(session, "completed")
        end_session()
    # No event on sub-function completion — returning to parent is not actionable.


def error_event(label: str, _: float) -> None:
    session = current_session()
    if session is None:
        return
    session.on_complete(label)
    emit_session(session, "error")
    if label == session.entry_point:
        end_session()


def progress(
    label: str,
    current: int,
    total: Optional[int],
    _: float,
) -> None:
    session = current_session()
    if session is None:
        return
    session.on_loop_progress(label, current, total)
    emit_session(session, "running")
