"""
progressable — automatic progress tracking via in-memory AST instrumentation.

Usage
-----
    import progressable

    progressable.watch("scanpy.pp.pca")        # must be before `import scanpy`
    progressable.on_event(lambda e: print(e))  # subscribe to event stream

    import scanpy
    scanpy.pp.pca(adata)                       # unchanged — events flow automatically

Event schema
------------
{
    "entry_point":  str          # top-level watched function
    "current_step": str          # innermost currently-running label
    "status":       str          # "running" | "completed" | "error"
    "percent":      float | None # 0–1, null on first run (total unknown)
    "elapsed_ms":   float
    "timestamp":    str          # ISO-8601 UTC
}
"""
from __future__ import annotations

import sys
from .events import on_event  # re-export
from .hooks import ProgressableHook

__all__ = ["watch", "on_event"]

_hook: ProgressableHook | None = None

# Packages auto-watched alongside the user's target because they contain
# Python-level computation worth tracking.
_AUTO_DEPS = ("sklearn",)


def watch(entry_point: str) -> None:
    """
    Instrument a package for automatic progress tracking.

    entry_point : dotted Python name, e.g. "scanpy.pp.pca".
                  The top-level package is extracted; every module under it
                  is AST-transformed on import.

    Must be called *before* importing the target package.
    Safe to call multiple times with different entry points.
    """
    global _hook

    top_package = entry_point.split(".")[0]

    if _hook is None:
        _hook = ProgressableHook()
        sys.meta_path.insert(0, _hook)

    _hook.add_package(top_package)

    # Auto-watch known Python-heavy dependencies for deeper coverage.
    for dep in _AUTO_DEPS:
        _hook.add_package(dep)

    # Patch C-extension known ops (numpy, scipy, sklearn) — best-effort.
    from .known_ops import patch_all
    patch_all()
