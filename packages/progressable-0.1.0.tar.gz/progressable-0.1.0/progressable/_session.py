"""
Session tracking: one Session per top-level watched-function call.

A session starts when _runtime.start() is called with no session already active
on this thread — that first function becomes the entry_point.
It ends when that same function's complete() is called.

Percent calculation
-------------------
First run:  unknown total → percent = None
Run 2+:     use step count from the previous run as the denominator so that
            percent rises monotonically from 0 → 1 across the call.

Loop granularity
----------------
When a for/while loop inside the call emits progress events, the session
temporarily overrides percent with the loop's own 0→1 fraction so the UI
shows finer-grained movement inside long single functions.
"""
from __future__ import annotations

import threading
from typing import List, Optional

_tls = threading.local()

# After each completed session, store total non-entry-point steps seen.
# Key: entry_point label  →  Value: int
_known_totals: dict[str, int] = {}


class Session:
    def __init__(self, entry_point: str, start_time: float) -> None:
        self.entry_point = entry_point
        self.start_time = start_time

        # Call stack of currently-running function labels (entry_point is always [0])
        self._running: List[str] = [entry_point]

        # Sub-function bookkeeping (entry_point excluded)
        self._n_seen: int = 0       # sub-functions started
        self._n_completed: int = 0  # sub-functions completed

        # Loop progress override: set by _runtime.progress(), cleared on loop complete
        self._loop_label: Optional[str] = None
        self._loop_percent: Optional[float] = None

    # ------------------------------------------------------------------
    # Public properties consumed by the event emitter
    # ------------------------------------------------------------------

    @property
    def current_step(self) -> str:
        """Innermost currently-running label, falling back to entry_point."""
        return self._running[-1] if self._running else self.entry_point

    @property
    def percent(self) -> Optional[float]:
        """
        Loop-level percent when a loop is active (finest granularity).
        Session-level percent when no loop is active (null on first run).
        """
        if self._loop_percent is not None:
            return self._loop_percent

        known = _known_totals.get(self.entry_point)
        if not known or known == 0:
            return None  # first run

        # Cap at 0.99 — only emit 1.0 on explicit completed event
        return min(self._n_completed / known, 0.99)

    # ------------------------------------------------------------------
    # Mutation — called by _runtime
    # ------------------------------------------------------------------

    def on_start(self, label: str) -> None:
        self._running.append(label)
        self._n_seen += 1

    def on_complete(self, label: str) -> bool:
        """
        Update state, return True iff the entry_point just completed
        (signals the session should be closed).
        """
        # Pop from running stack
        for i in range(len(self._running) - 1, -1, -1):
            if self._running[i] == label:
                self._running.pop(i)
                break

        if label == self.entry_point:
            _known_totals[self.entry_point] = self._n_seen
            return True  # session over

        self._n_completed += 1
        # Clear loop override if the loop just completed
        if label == self._loop_label:
            self._loop_label = None
            self._loop_percent = None
        return False

    def on_loop_progress(self, label: str, current: int, total: Optional[int]) -> None:
        self._loop_label = label
        self._loop_percent = (current / total) if total and total > 0 else None


# ------------------------------------------------------------------
# Thread-local accessors
# ------------------------------------------------------------------

def current_session() -> Optional[Session]:
    return getattr(_tls, "session", None)


def start_session(entry_point: str, start_time: float) -> Session:
    s = Session(entry_point, start_time)
    _tls.session = s
    return s


def end_session() -> None:
    _tls.session = None
