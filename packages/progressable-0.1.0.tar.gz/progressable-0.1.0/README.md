# progressable

Automatic progress tracking for any Python library — no changes to the library required.

`progressable` instruments a package at import time using in-memory AST transformation
and `sys.meta_path` hooks. Every substantial function and loop in the call graph emits
progress events that you can consume however you like: terminal display, websocket,
logging, or a custom UI.

---

## How it works

```
your script
  └── progressable.watch("scanpy.pp.pca")   # install hook before import
        └── sys.meta_path hook              # intercepts module loading
              └── AST transformer           # rewrites source in memory (no files touched)
                    └── _runtime            # injected calls emit session events
```

When a function in the watched package is called, a **session** starts.
Each step in the call graph (function start, loop iteration) updates a single
event with `current_step` and `percent`. The session closes with `percent=1.0`
when the entry-point function returns.

C-extension hot paths (numpy, scipy, sklearn) are covered via targeted
monkey-patches in `known_ops.py`.

---

## Installation

```bash
# with uv (recommended)
uv venv .venv
uv pip install -e .

# or plain pip
pip install .
```

Requires **Python 3.8+**. Zero runtime dependencies.

---

## Quickstart

```python
import progressable

# 1. Register a listener
progressable.on_event(lambda e: print(e))

# 2. Watch the target — must happen BEFORE importing the library
progressable.watch("scanpy.pp.pca")

# 3. Import and use as normal
import scanpy as sc
import anndata, numpy as np

adata = anndata.AnnData(np.random.rand(500, 2000).astype("float32"))
sc.pp.pca(adata, n_comps=50)
```

Output (second run, after total is learned from the first):

```
{'entry_point': 'scanpy.preprocessing._pca.pca', 'current_step': 'scanpy.preprocessing._pca.pca',     'status': 'running',   'percent': 0.0,   'elapsed_ms': 0.1, ...}
{'entry_point': 'scanpy.preprocessing._pca.pca', 'current_step': 'scanpy.preprocessing._pca._handle_mask_var', 'status': 'running', 'percent': 0.03, ...}
...
{'entry_point': 'scanpy.preprocessing._pca.pca', 'current_step': 'sklearn.decomposition.PCA._fit_truncated', 'status': 'running', 'percent': 0.58, ...}
...
{'entry_point': 'scanpy.preprocessing._pca.pca', 'current_step': 'scanpy.preprocessing._pca.pca',     'status': 'completed', 'percent': 1.0,  'elapsed_ms': 312.4, ...}
```

---

## Event schema

| Field         | Type           | Description |
|---------------|----------------|-------------|
| `entry_point` | `str`          | The first instrumented function that started the session, e.g. `"scanpy.preprocessing._pca.pca"` |
| `current_step`| `str`          | The innermost currently-running function or loop label |
| `status`      | `str`          | `"running"` \| `"completed"` \| `"error"` |
| `percent`     | `float\|None`  | `0.0`–`1.0`. `null` on the first run (total unknown); accurate from the second run onward |
| `elapsed_ms`  | `float`        | Milliseconds since the entry-point function was called |
| `timestamp`   | `str`          | ISO-8601 UTC |

Events are emitted:
- When a new function or loop **starts** (current_step advances)
- On each **loop iteration** (percent updates within a long loop)
- When the session **completes or errors**

---

## API

### `progressable.watch(entry_point)`

Register a package for automatic instrumentation.

- `entry_point` — dotted Python name, e.g. `"scanpy.pp.pca"` or `"mylib"`.
  The top-level package name is extracted; every `.py` module under it is
  AST-transformed on import.
- **Must be called before `import <target>`.**
- Safe to call multiple times with different targets.
- `sklearn` is automatically added as a co-dependency when any target is watched,
  because most scientific Python libraries delegate heavy computation to it.

### `progressable.on_event(callback)`

Register a listener function `callback(event: dict) -> None`.
Multiple listeners are supported. Exceptions in listeners are silently swallowed.

---

## Sending events over a websocket

```python
import asyncio, websockets, json, progressable

async def handler(ws):
    progressable.on_event(lambda e: asyncio.get_event_loop().call_soon_threadsafe(
        ws.send, json.dumps(e)
    ))
    await ws.wait_closed()

async def main():
    async with websockets.serve(handler, "localhost", 8765):
        await asyncio.Future()  # run forever

asyncio.run(main())
```

---

## Notes on granularity

| Source              | Granularity |
|---------------------|-------------|
| Python loops (`for`/`while`) in watched packages | Per-iteration with `percent` when length is known |
| Python functions in watched packages | Start / end |
| `sklearn.decomposition.PCA._fit_truncated` | Start / end (C call inside) |
| `numpy.linalg.svd`, `scipy.linalg.svd`, etc. | Start / end |

The first run always has `percent=null` because the total number of steps is
unknown. From the second run onward, the total from the previous run is used
as the denominator, giving monotonically increasing percent values.

---

## Project layout

```
progressable/
├── __init__.py          # watch(), on_event()
├── events.py            # event bus and schema
├── _session.py          # session lifecycle and percent tracking
├── _runtime.py          # helpers injected into transformed code
├── hooks.py             # sys.meta_path hook + loader
├── transformer.py       # in-memory AST transformer
└── known_ops.py         # numpy / scipy / sklearn monkey-patches
```

---

## License

MIT
