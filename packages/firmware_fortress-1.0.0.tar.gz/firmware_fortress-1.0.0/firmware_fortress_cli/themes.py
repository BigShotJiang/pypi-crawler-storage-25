"""
Firmware Fortress — Theme System
Central config for CLI + desktop colour palettes.
Switch at runtime: firmware-fortress --theme cyberpunk
"""
from typing import Dict, Any

THEMES: Dict[str, Dict[str, Any]] = {
    "cyberpunk": {
        "name":        "cyberpunk",
        "primary":     "#00ff41",   # matrix green
        "secondary":   "#00ffff",   # cyan
        "accent":      "#ff00ff",   # magenta
        "warning":     "#ffff00",   # yellow
        "danger":      "#ff3333",   # red
        "dim":         "#1a3a1a",
        "bg":          "black",
        "rule":        "bright_green",
        "banner":      "bold bright_green",
        "header":      "bold cyan",
        "success":     "bright_green",
        "error":       "bold red",
        "info":        "cyan",
        "label":       "dim",
        "value":       "white",
        "border":      "bright_green",
        "table_header":"bold cyan",
        "critical":    "bold red",
        "high":        "bold yellow",
        "medium":      "bold cyan",
        "low":         "bright_green",
    },
    "minimal": {
        "name":        "minimal",
        "primary":     "#ffffff",
        "secondary":   "#aaaaaa",
        "accent":      "#888888",
        "warning":     "#ffaa00",
        "danger":      "#ff4444",
        "dim":         "#555555",
        "bg":          "black",
        "rule":        "white",
        "banner":      "bold white",
        "header":      "bold white",
        "success":     "green",
        "error":       "red",
        "info":        "white",
        "label":       "dim",
        "value":       "white",
        "border":      "white",
        "table_header":"bold white",
        "critical":    "bold red",
        "high":        "bold yellow",
        "medium":      "bold white",
        "low":         "green",
    },
    "light": {
        "name":        "light",
        "primary":     "#006600",
        "secondary":   "#0066cc",
        "accent":      "#cc00cc",
        "warning":     "#cc6600",
        "danger":      "#cc0000",
        "dim":         "#888888",
        "bg":          "default",
        "rule":        "green",
        "banner":      "bold green",
        "header":      "bold blue",
        "success":     "green",
        "error":       "red",
        "info":        "blue",
        "label":       "dim",
        "value":       "default",
        "border":      "green",
        "table_header":"bold blue",
        "critical":    "bold red",
        "high":        "bold dark_orange",
        "medium":      "bold blue",
        "low":         "green",
    },
}

_active_theme = "cyberpunk"


def set_theme(name: str) -> None:
    global _active_theme
    if name in THEMES:
        _active_theme = name


def get_theme() -> Dict[str, Any]:
    return THEMES[_active_theme]


def t(key: str) -> str:
    """Shorthand: get a colour/style from the active theme."""
    return THEMES[_active_theme].get(key, "white")
