"""CLI command: firmware-fortress correlate"""
import json
import time
from pathlib import Path

import typer
import requests
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich import box

console = Console()

DEMO_INCIDENT = {
    "title": "Telnet Buffer Overflow — Active Exploitation",
    "root_cause_cve": "CVE-2019-1234",
    "confidence_pct": 90,
    "timeline": [
        {"timestamp": "14:37:00", "event": "Port scan targeting telnet (port 23)", "severity": "HIGH"},
        {"timestamp": "14:38:12", "event": "Buffer overflow triggered in auth handler", "severity": "CRITICAL"},
        {"timestamp": "14:39:05", "event": "Backdoor binary dropped at /tmp/.hidden", "severity": "CRITICAL"},
        {"timestamp": "14:41:33", "event": "DNS exfiltration via base64-encoded queries", "severity": "CRITICAL"},
    ],
    "containment_steps": [
        "Isolate device from network immediately",
        "Terminate process at /tmp/.hidden",
        "Restore /bin/sh from trusted backup",
        "Rotate all credentials",
        "Apply CVE-2019-1234 patch",
    ],
    "patch_strategy": "Disable telnet, update OpenSSL, rebuild BusyBox from patched source.",
    "id": "demo-incident",
}


def run_correlate(
    logs: Path = typer.Option(..., "--logs", "-l", help="Path to log file"),
    output_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data without backend"),
):
    """Correlate logs with CVEs to detect incidents (Agent 2)."""
    if not logs.exists():
        console.print(f"[red]File not found: {logs}[/red]")
        raise typer.Exit(1)

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        task = progress.add_task("Correlating logs with CVE database...", total=None)

        if demo:
            time.sleep(1)
            incidents = [DEMO_INCIDENT]
            job_id = "demo-correlate"
        else:
            try:
                resp = requests.post(
                    f"{backend_url}/scan/logs",
                    json={"log_path": str(logs.resolve())},
                    timeout=300,
                )
                resp.raise_for_status()
                data = resp.json()
                job_id = data.get("job_id", "unknown")
            except requests.RequestException as e:
                progress.stop()
                console.print(f"[yellow]Backend unreachable ({e}). Using demo data.[/yellow]")
                _print_incident(DEMO_INCIDENT, output_json, "demo-fallback")
                return

            progress.update(task, description="Analysis submitted — fetching incidents...")
            time.sleep(5)

            try:
                inc_resp = requests.get(f"{backend_url}/incidents", timeout=30)
                inc_resp.raise_for_status()
                incidents = inc_resp.json()
            except requests.RequestException:
                incidents = []

            if not incidents:
                console.print("[yellow]No incidents yet. Showing demo data.[/yellow]")
                incidents = [DEMO_INCIDENT]

        progress.stop()

    _print_incident(incidents[0] if incidents else DEMO_INCIDENT, output_json, job_id if not demo else "demo-correlate")


def _print_incident(latest: dict, output_json: bool, job_id: str):
    if output_json:
        print(json.dumps(latest, indent=2, default=str))
        return

    timeline_text = ""
    for entry in (latest.get("timeline") or []):
        sev = (entry.get("severity") or "").upper()
        colour = {"CRITICAL": "red", "HIGH": "yellow", "MEDIUM": "blue"}.get(sev, "white")
        timeline_text += f"  [{colour}]{entry.get('timestamp')}[/{colour}] — {entry.get('event')}\n"

    containment = "\n".join(
        f"  • {step}" for step in (latest.get("containment_steps") or [])
    )

    panel_content = (
        f"[bold]Title:[/bold] {latest.get('title')}\n"
        f"[bold]Root Cause CVE:[/bold] {latest.get('root_cause_cve') or 'Unknown'}\n"
        f"[bold]Confidence:[/bold] {latest.get('confidence_pct') or 0}%\n\n"
        f"[bold]Timeline:[/bold]\n{timeline_text}\n"
        f"[bold]Containment Steps:[/bold]\n{containment}\n\n"
        f"[bold]Patch Strategy:[/bold] {latest.get('patch_strategy') or 'N/A'}"
    )

    console.print(Panel(panel_content, title="[bold red]Incident Report[/bold red]", expand=False))
    console.print(f"\n[bold]Job ID:[/bold] {job_id}")
