"""CLI command: firmware-fortress ci-check"""
import json
import time
from pathlib import Path

import typer
import requests
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

DEMO_BLOCK = {
    "repo": "acme-iot/router-firmware",
    "branch": "main",
    "commit_sha": "a1b2c3d4",
    "reason": "CRITICAL CVEs detected: CVE-2019-7406 (CVSS 9.8), CVE-2018-17177 (CVSS 9.1). Build blocked by security gate.",
    "cve_ids": ["CVE-2019-7406", "CVE-2018-17177", "CVE-2020-9374"],
    "secrets_found": [],
    "blocked_at": "2024-01-15T14:00:00Z",
}


def run_ci_check(
    artifact: Path = typer.Option(..., "--artifact", "-a", help="Path to build artifact"),
    repo: str = typer.Option(..., "--repo", "-r", help="Repository name"),
    branch: str = typer.Option(..., "--branch", "-b", help="Branch name"),
    commit: str = typer.Option("HEAD", "--commit", "-c", help="Commit SHA"),
    output_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data without backend"),
):
    """Check a build artifact for security violations (Agent 3)."""
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        task = progress.add_task("Running CI/CD security check...", total=None)

        if demo:
            time.sleep(1)
            blocks = [DEMO_BLOCK]
            job_id = "demo-ci-check"
        else:
            payload = {
                "repo": repo,
                "branch": branch,
                "commit_sha": commit,
                "artifact_path": str(artifact.resolve()) if artifact.exists() else str(artifact),
                "dependencies": [],
            }

            # If artifact is a JSON file (like demo/build_event.json), read deps from it
            if artifact.exists() and artifact.suffix.lower() == ".json":
                try:
                    event_data = json.loads(artifact.read_text())
                    payload["dependencies"] = event_data.get("dependencies", [])
                    payload["repo"] = event_data.get("repo", repo)
                    payload["branch"] = event_data.get("branch", branch)
                    payload["commit_sha"] = event_data.get("commit_sha", commit)
                    payload["artifact_path"] = event_data.get("artifact_path", str(artifact))
                except Exception:
                    pass

            try:
                resp = requests.post(
                    f"{backend_url}/scan/build",
                    json=payload,
                    timeout=120,
                )
                resp.raise_for_status()
                data = resp.json()
                job_id = data.get("job_id", "unknown")
            except requests.RequestException as e:
                progress.stop()
                console.print(f"[yellow]Backend unreachable ({e}). Using demo data.[/yellow]")
                _print_result([DEMO_BLOCK], output_json, "demo-fallback")
                return

            progress.update(task, description="Check submitted — fetching result...")
            time.sleep(4)

            try:
                blocks_resp = requests.get(f"{backend_url}/pipeline-blocks", timeout=30)
                blocks_resp.raise_for_status()
                blocks = blocks_resp.json()
            except requests.RequestException:
                blocks = []

            if not blocks:
                blocks = [DEMO_BLOCK]

        progress.stop()

    _print_result(blocks, output_json, job_id if not demo else "demo-ci-check")


def _print_result(blocks: list, output_json: bool, job_id: str):
    if output_json:
        print(json.dumps(blocks[:1], indent=2, default=str))
        return

    if not blocks:
        console.print(Panel("[green]✓ Build approved — no violations found.[/green]", title="CI/CD Watchdog", border_style="green"))
        return

    latest = blocks[0]
    has_violations = bool(latest.get("cve_ids") or latest.get("secrets_found") or latest.get("reason"))

    if has_violations:
        content = (
            f"[bold red]✗ BUILD BLOCKED[/bold red]\n\n"
            f"[bold]Reason:[/bold] {latest.get('reason') or 'Security violations detected'}\n"
            f"[bold]CVEs:[/bold] {', '.join(latest.get('cve_ids') or []) or 'None'}\n"
            f"[bold]Secrets Found:[/bold] {', '.join(latest.get('secrets_found') or []) or 'None'}\n"
            f"[bold]Repo:[/bold] {latest.get('repo')} @ {latest.get('branch')}\n"
            f"[bold]Commit:[/bold] {latest.get('commit_sha')}"
        )
        console.print(Panel(content, title="CI/CD Watchdog", border_style="red"))
    else:
        console.print(Panel("[green]✓ Build approved — no violations found.[/green]", title="CI/CD Watchdog", border_style="green"))

    console.print(f"\n[bold]Job ID:[/bold] {job_id}")
