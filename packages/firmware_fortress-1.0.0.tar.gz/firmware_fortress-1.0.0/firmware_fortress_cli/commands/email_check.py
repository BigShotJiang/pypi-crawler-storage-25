"""CLI command: firmware-fortress email-check"""
import json
import time
from pathlib import Path

import typer
import requests
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

DEMO_THREAT = {
    "email_subject": "URGENT: Critical firmware security update required",
    "sender_raw": "support@tp-iink.com",
    "sender_domain": "tp-iink.com",
    "is_spoofed": True,
    "homograph_attacks": [
        "tp-iink.com contains doubled 'i' — possible typosquat",
        "tp-iink.com may impersonate 'tp-link'",
    ],
    "risk_level": "CRITICAL",
    "risk_score": 92,
    "forensic_report": (
        "CRITICAL PHISHING ATTEMPT DETECTED\n\n"
        "• Sender domain 'tp-iink.com' uses doubled 'i' homograph attack impersonating 'tp-link.com'\n"
        "• Return-Path domain 'suspicious-domain.ru' does not match sender (spoofing confirmed)\n"
        "• Reply-To 'tp-link-update.xyz' is a newly registered lookalike domain\n"
        "• URL 'tp-link-firmware-update.xyz/update.exe' — executable from unverified domain\n"
        "• DKIM signature is invalid\n"
        "• No valid SPF or DMARC records found\n\n"
        "Verdict: Sophisticated phishing targeting IoT device owners. Do not click any links."
    ),
}


def run_email_check(
    file: Path = typer.Option(..., "--file", "-f", help="Path to .eml file"),
    output_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data without backend"),
):
    """Analyse an email for phishing and spoofing (Agent 4)."""
    if not file.exists():
        console.print(f"[red]File not found: {file}[/red]")
        raise typer.Exit(1)

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        task = progress.add_task("Running email forensics...", total=None)

        if demo:
            time.sleep(1)
            threats = [DEMO_THREAT]
            job_id = "demo-email-check"
        else:
            try:
                resp = requests.post(
                    f"{backend_url}/scan/email",
                    json={"eml_path": str(file.resolve())},
                    timeout=120,
                )
                resp.raise_for_status()
                data = resp.json()
                job_id = data.get("job_id", "unknown")
            except requests.RequestException as e:
                progress.stop()
                console.print(f"[yellow]Backend unreachable ({e}). Using demo data.[/yellow]")
                _print_threat(DEMO_THREAT, output_json, "demo-fallback")
                return

            progress.update(task, description="Analysis submitted — fetching report...")
            time.sleep(4)

            try:
                threats_resp = requests.get(f"{backend_url}/threats", timeout=30)
                threats_resp.raise_for_status()
                threats = threats_resp.json()
            except requests.RequestException:
                threats = []

            if not threats:
                console.print("[yellow]No threat data yet. Showing demo data.[/yellow]")
                threats = [DEMO_THREAT]

        progress.stop()

    _print_threat(threats[0] if threats else DEMO_THREAT, output_json, job_id if not demo else "demo-email-check")


def _print_threat(latest: dict, output_json: bool, job_id: str):
    if output_json:
        print(json.dumps(latest, indent=2, default=str))
        return

    risk_level = (latest.get("risk_level") or "UNKNOWN").upper()
    risk_colours = {"CRITICAL": "red", "HIGH": "yellow", "MEDIUM": "blue", "LOW": "green"}
    colour = risk_colours.get(risk_level, "white")

    homographs = "\n".join(f"  • {h}" for h in (latest.get("homograph_attacks") or []))

    content = (
        f"[bold]Subject:[/bold] {latest.get('email_subject')}\n"
        f"[bold]Sender:[/bold] {latest.get('sender_raw')}\n"
        f"[bold]Domain:[/bold] {latest.get('sender_domain')}\n"
        f"[bold]Spoofed:[/bold] {'[red]YES[/red]' if latest.get('is_spoofed') else '[green]NO[/green]'}\n"
        f"[bold]Risk Level:[/bold] [{colour}]{risk_level}[/{colour}]\n"
        f"[bold]Risk Score:[/bold] {latest.get('risk_score')}/100\n\n"
        f"[bold]Homograph Attacks:[/bold]\n{homographs or '  None detected'}\n\n"
        f"[bold]Forensic Report:[/bold]\n{latest.get('forensic_report') or 'N/A'}"
    )

    console.print(Panel(content, title="[bold]Email Forensics Report[/bold]", border_style=colour))
    console.print(f"\n[bold]Job ID:[/bold] {job_id}")
