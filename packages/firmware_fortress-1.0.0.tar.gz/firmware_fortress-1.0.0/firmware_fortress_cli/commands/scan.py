"""CLI command: firmware-fortress scan"""
import json
import time
from pathlib import Path

import typer
import requests
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box

console = Console()

# Demo fallback data
DEMO_CVES = [
    {"cve_id": "CVE-2019-7406",  "cvss_score": 9.8, "severity": "CRITICAL", "affected_component": "httpd / BusyBox 1.19.4", "recommended_action": "Update to firmware v4.30.1 or later. Disable remote management."},
    {"cve_id": "CVE-2018-17177", "cvss_score": 9.1, "severity": "CRITICAL", "affected_component": "Authentication Module",   "recommended_action": "Immediately change default credentials. Apply firmware patch."},
    {"cve_id": "CVE-2020-9374",  "cvss_score": 8.8, "severity": "HIGH",     "affected_component": "TFTP Server",             "recommended_action": "Disable TFTP service if not required. Apply vendor patch."},
    {"cve_id": "CVE-2019-17147", "cvss_score": 8.1, "severity": "HIGH",     "affected_component": "Web Management Interface","recommended_action": "Update firmware. Restrict management interface access."},
    {"cve_id": "CVE-2014-0160",  "cvss_score": 7.5, "severity": "HIGH",     "affected_component": "OpenSSL 1.0.1e",          "recommended_action": "Upgrade OpenSSL to 1.0.1g or later. Regenerate SSL certificates."},
    {"cve_id": "CVE-2022-0778",  "cvss_score": 6.5, "severity": "MEDIUM",   "affected_component": "OpenSSL 1.0.1e",          "recommended_action": "Upgrade OpenSSL to 1.0.2zd, 1.1.1n, or 3.0.2."},
    {"cve_id": "CVE-2021-28831", "cvss_score": 3.3, "severity": "LOW",      "affected_component": "BusyBox 1.19.4 unzip",    "recommended_action": "Update BusyBox to 1.33.0 or later."},
]


def run_scan(
    file: Path = typer.Option(..., "--file", "-f", help="Path to firmware binary"),
    output_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data without backend"),
):
    """Scan a firmware binary for CVEs (Agent 1)."""
    if not file.exists():
        console.print(f"[red]File not found: {file}[/red]")
        raise typer.Exit(1)

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        task = progress.add_task("Scanning firmware for CVEs...", total=None)

        if demo:
            time.sleep(1)
            results = DEMO_CVES
            job_id = "demo-scan"
        else:
            try:
                resp = requests.post(
                    f"{backend_url}/scan/firmware",
                    json={"firmware_path": str(file.resolve())},
                    timeout=300,
                )
                resp.raise_for_status()
                data = resp.json()
                job_id = data.get("job_id", "unknown")
            except requests.RequestException as e:
                progress.stop()
                console.print(f"[yellow]Backend unreachable ({e}). Using demo data.[/yellow]")
                results = DEMO_CVES
                job_id = "demo-fallback"
                _print_results(file, results, output_json, job_id)
                return

            progress.update(task, description="Scan submitted — fetching results...")
            time.sleep(3)

            try:
                vuln_resp = requests.get(f"{backend_url}/vulnerabilities?limit=50", timeout=30)
                vuln_resp.raise_for_status()
                results = vuln_resp.json()
            except requests.RequestException:
                results = []

            if not results:
                console.print("[yellow]No results from backend yet. Showing demo data.[/yellow]")
                results = DEMO_CVES

        progress.stop()

    _print_results(file, results, output_json, job_id)


def _print_results(file: Path, results: list, output_json: bool, job_id: str):
    if output_json:
        print(json.dumps(results, indent=2, default=str))
        return

    if not results:
        console.print("[yellow]No CVEs found or scan still running. Check back shortly.[/yellow]")
        return

    table = Table(
        title=f"CVE Scan Results — {file.name}",
        show_lines=True,
        box=box.ROUNDED,
    )
    table.add_column("CVE ID", style="bold cyan", no_wrap=True)
    table.add_column("CVSS", justify="right", width=6)
    table.add_column("Severity", width=10)
    table.add_column("Component", style="dim")
    table.add_column("Recommended Action", max_width=50)

    severity_styles = {
        "CRITICAL": "bold red",
        "HIGH": "bold yellow",
        "MEDIUM": "bold blue",
        "LOW": "green",
    }

    for cve in results:
        sev = (cve.get("severity") or "UNKNOWN").upper()
        style = severity_styles.get(sev, "white")
        table.add_row(
            cve.get("cve_id", "N/A"),
            str(cve.get("cvss_score") or "N/A"),
            f"[{style}]{sev}[/{style}]",
            cve.get("affected_component") or "N/A",
            cve.get("recommended_action") or "N/A",
        )

    console.print(table)
    console.print(f"\n[bold]Job ID:[/bold] {job_id}")
    console.print(f"[bold]Total CVEs:[/bold] {len(results)}")
    critical = sum(1 for c in results if (c.get("severity") or "").upper() == "CRITICAL")
    if critical:
        console.print(f"[bold red]Critical CVEs:[/bold red] {critical}")
