"""
Firmware Fortress CLI — Cyberpunk Security Platform
"""
import asyncio
import json
import os
import sys
import time
import ctypes
from pathlib import Path
from datetime import datetime

# Ensure UTF-8 output on Windows (fixes box-drawing characters in terminal)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

import typer
import requests
import websockets
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.panel import Panel
from rich.text import Text
from rich.columns import Columns
from rich.rule import Rule
from rich.align import Align
from rich.padding import Padding
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich import box
from dotenv import load_dotenv

from firmware_fortress_cli.themes import set_theme, get_theme, t
from firmware_fortress_cli.commands.scan import run_scan
from firmware_fortress_cli.commands.correlate import run_correlate
from firmware_fortress_cli.commands.ci_check import run_ci_check
from firmware_fortress_cli.commands.email_check import run_email_check

load_dotenv()

console = Console(width=120, highlight=False)

# ── Demo data ──────────────────────────────────────────────────────────────────

DEMO_CVES = [
    {"cve_id": "CVE-2019-1234", "cvss_score": 9.8, "severity": "CRITICAL", "affected_component": "telnetd",  "description": "Buffer overflow in telnet auth handler — unauthenticated RCE.", "recommended_action": "Disable telnet service immediately."},
    {"cve_id": "CVE-2020-5678", "cvss_score": 9.2, "severity": "CRITICAL", "affected_component": "openssl",  "description": "Heap overflow in TLS handshake — remote code execution.", "recommended_action": "Update OpenSSL to 3.0.x or later."},
    {"cve_id": "CVE-2021-9012", "cvss_score": 8.7, "severity": "HIGH",     "affected_component": "busybox",  "description": "Stack overflow in HTTP server — DoS and potential RCE.", "recommended_action": "Rebuild BusyBox from patched source."},
    {"cve_id": "CVE-2018-3456", "cvss_score": 8.1, "severity": "HIGH",     "affected_component": "dnsmasq",  "description": "DNS cache poisoning via crafted responses.", "recommended_action": "Update dnsmasq to 2.89+."},
    {"cve_id": "CVE-2022-1111", "cvss_score": 7.5, "severity": "HIGH",     "affected_component": "dropbear", "description": "Use-after-free in SSH key exchange.", "recommended_action": "Update dropbear to 2022.83+."},
    {"cve_id": "CVE-2017-8888", "cvss_score": 6.5, "severity": "MEDIUM",   "affected_component": "lighttpd", "description": "Path traversal exposes config files.", "recommended_action": "Apply vendor patch or disable directory listing."},
]

DEMO_INCIDENT = {
    "title": "Telnet Buffer Overflow — Active Exploitation",
    "root_cause_cve": "CVE-2019-1234",
    "confidence_pct": 90,
    "timeline": [
        {"timestamp": "14:37:00", "event": "Port scan targeting telnet (port 23)", "severity": "HIGH"},
        {"timestamp": "14:38:12", "event": "Buffer overflow triggered in auth handler", "severity": "CRITICAL"},
        {"timestamp": "14:39:05", "event": "Backdoor binary dropped at /tmp/.hidden", "severity": "CRITICAL"},
        {"timestamp": "14:41:33", "event": "DNS exfiltration via base64-encoded queries", "severity": "CRITICAL"},
    ],
    "containment_steps": [
        "Isolate device from network immediately",
        "Terminate process at /tmp/.hidden",
        "Restore /bin/sh from trusted backup",
        "Rotate all credentials",
        "Apply CVE-2019-1234 patch",
    ],
    "patch_strategy": "Disable telnet, update OpenSSL, rebuild BusyBox from patched source.",
}

# ── Privilege helpers ──────────────────────────────────────────────────────────

def _is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        try:
            return os.geteuid() == 0  # type: ignore[attr-defined]
        except Exception:
            return False


def _request_elevation():
    if sys.platform == "win32" and not _is_admin():
        try:
            args = " ".join(f'"{a}"' for a in sys.argv)
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, args, None, 1)
            sys.exit(0)
        except Exception:
            pass


# ── Boot sequence ──────────────────────────────────────────────────────────────

BANNER_LINES = [
    " ███████╗██╗██████╗ ███╗   ███╗██╗    ██╗ █████╗ ██████╗ ███████╗",
    " ██╔════╝██║██╔══██╗████╗ ████║██║    ██║██╔══██╗██╔══██╗██╔════╝",
    " █████╗  ██║██████╔╝██╔████╔██║██║ █╗ ██║███████║██████╔╝█████╗  ",
    " ██╔══╝  ██║██╔══██╗██║╚██╔╝██║██║███╗██║██╔══██║██╔══██╗██╔══╝  ",
    " ██║     ██║██║  ██║██║ ╚═╝ ██║╚███╔███╔╝██║  ██║██║  ██║███████╗",
    " ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝",
    "",
    " ███████╗ ██████╗ ██████╗ ████████╗██████╗ ███████╗███████╗███████╗",
    " ██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔════╝██╔════╝██╔════╝",
    " █████╗  ██║   ██║██████╔╝   ██║   ██████╔╝█████╗  ███████╗███████╗",
    " ██╔══╝  ██║   ██║██╔══██╗   ██║   ██╔══██╗██╔══╝  ╚════██║╚════██║",
    " ██║     ╚██████╔╝██║  ██║   ██║   ██║  ██║███████╗███████║███████║",
    " ╚═╝      ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝",
]

BOOT_SEQUENCE = [
    ("Initialising threat intelligence engine", 0.06),
    ("Loading NVD CVE database connector",      0.05),
    ("Connecting to Supabase realtime",          0.07),
    ("Authenticating Groq LLaMA-3.3-70B",       0.06),
    ("Spawning agent pool",                      0.05),
    ("WebSocket broadcast layer ready",          0.04),
    ("System armed",                             0.08),
]


def _print_banner(boot: bool = False):
    theme = get_theme()
    console.print()
    for line in BANNER_LINES:
        console.print(line, style=theme["banner"], overflow="fold", highlight=False)
    console.print()
    console.print(Rule(style=theme["rule"]))

    if boot:
        console.print()
        with Progress(
            SpinnerColumn(style=theme["primary"]),
            TextColumn("[{task.description}]", style=theme["info"]),
            BarColumn(bar_width=30, style=theme["dim"], complete_style=theme["primary"]),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Booting...", total=len(BOOT_SEQUENCE))
            for msg, delay in BOOT_SEQUENCE:
                progress.update(task, description=msg)
                time.sleep(delay)
                progress.advance(task)
        console.print(f"  [{theme['success']}]System ready.[/{theme['success']}]\n")

    grid = Table.grid(padding=(0, 3))
    grid.add_column(style=theme["header"], justify="right", min_width=12)
    grid.add_column(style=theme["value"])
    grid.add_row("Version",  "1.0.0")
    grid.add_row("Theme",    get_theme()["name"])
    grid.add_row("Engine",   "Groq  llama-3.3-70b-versatile")
    grid.add_row("Database", "Supabase  PostgreSQL + Realtime")
    grid.add_row("NVD",      "National Vulnerability Database API")
    grid.add_row("Agents",   "CVE Hunter / Incident Detective / CI/CD Watchdog / Email Forensics")
    grid.add_row("Access",   "Administrator" if _is_admin() else f"[{theme['warning']}]Standard user[/{theme['warning']}]")
    grid.add_row("Time",     datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))

    console.print(Padding(grid, (1, 4)))
    console.print(Rule(style=theme["rule"]))
    console.print()


# ── Typer app ──────────────────────────────────────────────────────────────────

def _version_cb(value: bool):
    if value:
        _print_banner(boot=False)
        raise typer.Exit()


app = typer.Typer(
    name="firmware-fortress",
    help="Autonomous firmware supply chain security platform",
    add_completion=False,
    no_args_is_help=False,
    invoke_without_command=True,
)


@app.callback(invoke_without_command=True)
def _cb(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-v", callback=_version_cb, is_eager=True),
    elevate: bool = typer.Option(False, "--elevate", help="Re-launch with administrator privileges"),
    theme: str = typer.Option("cyberpunk", "--theme", help="UI theme: cyberpunk | minimal | light"),
):
    """Firmware Fortress -- Autonomous Supply Chain Security"""
    set_theme(theme)
    if elevate:
        _request_elevation()
    if ctx.invoked_subcommand is None:
        _print_banner(boot=True)
        console.print(ctx.get_help())


# ── Commands ───────────────────────────────────────────────────────────────────

@app.command("scan")
def scan(
    file: str = typer.Option(..., "--file", "-f", help="Path to firmware binary"),
    output_json: bool = typer.Option(False, "--json"),
    theme: str = typer.Option("cyberpunk", "--theme"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data (no backend required)"),
):
    """Scan a firmware binary for CVEs  [Agent 1 -- CVE Hunter]"""
    set_theme(theme)
    _print_banner()
    run_scan(file=Path(file), output_json=output_json, backend_url=backend_url, demo=demo)


@app.command("correlate")
def correlate(
    logs: str = typer.Option(..., "--logs", "-l", help="Path to log file"),
    output_json: bool = typer.Option(False, "--json"),
    theme: str = typer.Option("cyberpunk", "--theme"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data (no backend required)"),
):
    """Correlate logs with CVEs to reconstruct attack timelines  [Agent 2 -- Incident Detective]"""
    set_theme(theme)
    _print_banner()
    run_correlate(logs=Path(logs), output_json=output_json, backend_url=backend_url, demo=demo)


@app.command("ci-check")
def ci_check(
    artifact: str = typer.Option(..., "--artifact", "-a", help="Path to build artifact"),
    repo: str = typer.Option(..., "--repo", "-r", help="Repository name"),
    branch: str = typer.Option(..., "--branch", "-b", help="Branch name"),
    commit: str = typer.Option("HEAD", "--commit", "-c", help="Commit SHA"),
    output_json: bool = typer.Option(False, "--json"),
    theme: str = typer.Option("cyberpunk", "--theme"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data (no backend required)"),
):
    """Check a build artifact for CVEs, secrets and policy violations  [Agent 3 -- CI/CD Watchdog]"""
    set_theme(theme)
    _print_banner()
    run_ci_check(
        artifact=Path(artifact), repo=repo, branch=branch,
        commit=commit, output_json=output_json, backend_url=backend_url, demo=demo,
    )


@app.command("email-check")
def email_check(
    file: str = typer.Option(..., "--file", "-f", help="Path to .eml file"),
    output_json: bool = typer.Option(False, "--json"),
    theme: str = typer.Option("cyberpunk", "--theme"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
    demo: bool = typer.Option(False, "--demo", help="Use demo data (no backend required)"),
):
    """Deep forensic analysis of an email for phishing and spoofing  [Agent 4 -- Email Forensics]"""
    set_theme(theme)
    _print_banner()
    run_email_check(file=Path(file), output_json=output_json, backend_url=backend_url, demo=demo)


@app.command("status")
def status(
    output_json: bool = typer.Option(False, "--json"),
    theme: str = typer.Option("cyberpunk", "--theme"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
):
    """Show live platform statistics"""
    set_theme(theme)
    th = get_theme()
    _print_banner()
    try:
        resp = requests.get(f"{backend_url}/stats", timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        console.print(Panel(
            f"[{th['warning']}]Backend unreachable: {e}\nShowing demo statistics.[/{th['warning']}]",
            title=f"[{th['warning']}]Connection Warning[/{th['warning']}]",
            border_style=th["warning"],
        ))
        data = {
            "total_cves": 47,
            "critical_cves": 12,
            "active_incidents": 3,
            "blocked_builds": 8,
            "threats_detected": 5,
        }

    if output_json:
        print(json.dumps(data, indent=2))
        return

    th = get_theme()
    console.print(Rule(f"[{th['header']}]Platform Status[/{th['header']}]", style=th["rule"]))
    console.print()

    metrics = [
        ("Total CVEs",       data.get("total_cves", 0),       th["secondary"]),
        ("Critical CVEs",    data.get("critical_cves", 0),    th["danger"]),
        ("Active Incidents", data.get("active_incidents", 0), th["warning"]),
        ("Blocked Builds",   data.get("blocked_builds", 0),   th["danger"]),
        ("Email Threats",    data.get("threats_detected", 0), th["accent"]),
    ]
    cards = []
    for label, val, colour in metrics:
        tbl = Table.grid()
        tbl.add_row(Text(str(val), style=f"bold {colour}", justify="center"))
        tbl.add_row(Text(label, style="dim", justify="center"))
        cards.append(Panel(Align.center(tbl), border_style=colour, width=22))

    console.print(Columns(cards, equal=True))
    console.print()

    try:
        health = requests.get(f"{backend_url}/health", timeout=5).json()
        console.print(f"  Backend  [{th['success']}]connected[/{th['success']}]  {backend_url}  status={health.get('status')}")
    except Exception:
        console.print(f"  Backend  [{th['error']}]unreachable[/{th['error']}]  {backend_url}")
    console.print()


@app.command("watch")
def watch(
    ws_url: str = typer.Option("ws://localhost:8000/ws", envvar="WS_URL"),
    theme: str = typer.Option("cyberpunk", "--theme"),
):
    """Stream live agent events in real time"""
    set_theme(theme)
    th = get_theme()
    _print_banner()
    console.print(Rule(f"[{th['header']}]Live Event Stream[/{th['header']}]", style=th["rule"]))
    console.print(f"  Connecting to [{th['info']}]{ws_url}[/{th['info']}]\n")

    EVENT_STYLES = {
        "cve_scan_complete":     (th["secondary"], "CVE SCAN COMPLETE"),
        "incident_detected":     (th["danger"],    "INCIDENT DETECTED"),
        "build_blocked":         (th["danger"],    "BUILD BLOCKED"),
        "build_approved":        (th["success"],   "BUILD APPROVED"),
        "email_threat_detected": (th["warning"],   "EMAIL THREAT"),
        "error":                 (th["danger"],    "ERROR"),
    }

    events_log: list[dict] = []

    def _make_table() -> Table:
        tbl = Table(
            box=box.SIMPLE_HEAD, show_header=True,
            header_style=th["table_header"],
            expand=True, border_style=th["border"],
        )
        tbl.add_column("Time",     style="dim",  width=8,  no_wrap=True)
        tbl.add_column("Event",    style="bold", width=26, no_wrap=True)
        tbl.add_column("Severity", justify="center", width=10, no_wrap=True)
        tbl.add_column("Details",  style="dim")

        for ev in events_log[:35]:
            colour, label = EVENT_STYLES.get(ev["event"], ("white", ev["event"].upper()))
            sev = (ev["data"].get("risk_level") or ev["data"].get("severity") or "—").upper()
            sev_style = {
                "CRITICAL": th["critical"], "HIGH": th["high"],
                "MEDIUM": th["medium"],     "LOW": th["low"],
            }.get(sev, "dim")
            detail = json.dumps(ev["data"], default=str)[:80]
            tbl.add_row(
                ev["ts"],
                f"[{colour}]{label}[/{colour}]",
                f"[{sev_style}]{sev}[/{sev_style}]",
                detail,
            )
        return tbl

    async def _stream():
        backoff = 1
        while True:
            try:
                async with websockets.connect(ws_url, open_timeout=5) as ws:
                    console.print(f"  [{th['success']}]●[/{th['success']}] Connected  [dim](Ctrl+C to stop)[/dim]\n")
                    backoff = 1
                    with Live(_make_table(), console=console, refresh_per_second=4) as live:
                        async for message in ws:
                            try:
                                payload = json.loads(message)
                            except json.JSONDecodeError:
                                continue
                            events_log.insert(0, {
                                "event": payload.get("event", "unknown"),
                                "ts":    payload.get("timestamp", "")[-8:-3],
                                "data":  payload.get("data", {}),
                            })
                            live.update(_make_table())
            except (ConnectionRefusedError, OSError) as e:
                console.print(f"\n  [{th['warning']}]●[/{th['warning']}] Backend not reachable ({e}). Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
            except Exception as e:
                console.print(f"\n  [{th['warning']}]●[/{th['warning']}] Disconnected ({e}). Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
    try:
        asyncio.run(_stream())
    except KeyboardInterrupt:
        console.print(f"\n  [{th['warning']}]Disconnected.[/{th['warning']}]")


@app.command("demo")
def demo(
    theme: str = typer.Option("cyberpunk", "--theme"),
):
    """Run offline demo with preloaded TP-Link WR740N breach scenario"""
    set_theme(theme)
    th = get_theme()
    _print_banner(boot=True)

    console.print(Panel(
        f"[{th['warning']}]DEMO MODE — No backend required. Preloaded TP-Link WR740N v4.30 scenario.[/{th['warning']}]",
        border_style=th["warning"],
    ))
    console.print()

    # ── CVE results ────────────────────────────────────────────────────────────
    console.print(Rule(f"[{th['header']}]Agent 1 — CVE Hunter Results[/{th['header']}]", style=th["rule"]))
    console.print()

    sev_styles = {
        "CRITICAL": th["critical"],
        "HIGH":     th["high"],
        "MEDIUM":   th["medium"],
        "LOW":      th["low"],
    }

    tbl = Table(
        title=f"[{th['primary']}]TP-Link WR740N v4.30  —  47 CVEs  —  Risk Score 87/100[/{th['primary']}]",
        box=box.SIMPLE_HEAD,
        header_style=th["table_header"],
        border_style=th["border"],
        show_lines=False,
    )
    tbl.add_column("CVE ID",    style=th["secondary"], width=18, no_wrap=True)
    tbl.add_column("CVSS",      justify="right", width=6)
    tbl.add_column("Severity",  width=10)
    tbl.add_column("Component", style=th["info"], width=12)
    tbl.add_column("Description", max_width=50)

    for cve in DEMO_CVES:
        sev = cve["severity"]
        sev_style = sev_styles.get(sev, "white")
        tbl.add_row(
            cve["cve_id"],
            str(cve["cvss_score"]),
            f"[{sev_style}]{sev}[/{sev_style}]",
            cve["affected_component"],
            cve["description"],
        )

    console.print(tbl)
    console.print()

    # ── Severity summary ───────────────────────────────────────────────────────
    summary_cards = [
        Panel(Align.center(Text("12\nCRITICAL", style=th["critical"])), border_style=th["danger"],  width=18),
        Panel(Align.center(Text("34\nHIGH",     style=th["high"])),     border_style=th["warning"], width=18),
        Panel(Align.center(Text("1\nMEDIUM",    style=th["medium"])),   border_style=th["info"],    width=18),
        Panel(Align.center(Text("0\nLOW",       style=th["low"])),      border_style=th["success"], width=18),
    ]
    console.print(Columns(summary_cards))
    console.print()

    # ── Incident report ────────────────────────────────────────────────────────
    console.print(Rule(f"[{th['header']}]Agent 2 — Incident Detective[/{th['header']}]", style=th["rule"]))
    console.print()

    inc = DEMO_INCIDENT
    console.print(Panel(
        f"[{th['danger']}]{inc['title']}[/{th['danger']}]\n"
        f"Root CVE: [{th['secondary']}]{inc['root_cause_cve']}[/{th['secondary']}]  "
        f"Confidence: [{th['warning']}]{inc['confidence_pct']}%[/{th['warning']}]",
        title=f"[{th['header']}]Incident Report[/{th['header']}]",
        border_style=th["danger"],
    ))

    tl_tbl = Table(box=box.SIMPLE, header_style=th["table_header"], border_style=th["border"])
    tl_tbl.add_column("Time",     style="dim",       width=10)
    tl_tbl.add_column("Event",    style=th["value"], max_width=60)
    tl_tbl.add_column("Severity", width=10)
    for entry in inc["timeline"]:
        sev_style = sev_styles.get(entry["severity"], "white")
        tl_tbl.add_row(
            entry["timestamp"],
            entry["event"],
            f"[{sev_style}]{entry['severity']}[/{sev_style}]",
        )
    console.print(tl_tbl)
    console.print()

    console.print(f"[{th['header']}]Containment Steps:[/{th['header']}]")
    for i, step in enumerate(inc["containment_steps"], 1):
        console.print(f"  [{th['primary']}]{i:02d}[/{th['primary']}]  {step}")
    console.print()
    console.print(f"[{th['header']}]Patch Strategy:[/{th['header']}]  {inc['patch_strategy']}")
    console.print()

    console.print(Panel(
        f"[{th['success']}]Demo complete. Run with a real backend:[/{th['success']}]\n"
        f"  [{th['info']}]firmware-fortress scan --file firmware.bin[/{th['info']}]",
        border_style=th["success"],
    ))


@app.command("scan-dir")
def scan_dir(
    path: str = typer.Option(..., "--path", "-p", help="Directory to recursively scan"),
    extensions: str = typer.Option(".bin,.img,.fw,.hex,.rom,.elf", "--ext"),
    theme: str = typer.Option("cyberpunk", "--theme"),
    backend_url: str = typer.Option("http://localhost:8000", envvar="BACKEND_URL"),
):
    """Recursively scan a directory for all firmware files  [system-level access]"""
    set_theme(theme)
    th = get_theme()
    _print_banner()

    if not _is_admin():
        console.print(Panel(
            f"[{th['warning']}]Running without administrator privileges.\n"
            f"Some system directories may be inaccessible.\n"
            f"Run [bold]firmware-fortress --elevate[/bold] to restart with admin rights.[/{th['warning']}]",
            title=f"[{th['warning']}]Privilege Warning[/{th['warning']}]",
            border_style=th["warning"],
        ))

    exts = {e.strip().lower() for e in extensions.split(",")}
    scan_path = Path(path)

    if not scan_path.exists():
        console.print(f"[{th['error']}]Path not found: {path}[/{th['error']}]")
        raise typer.Exit(1)

    console.print(f"\n  Scanning [{th['info']}]{scan_path}[/{th['info']}] for: [{th['info']}]{extensions}[/{th['info']}]\n")

    found: list[Path] = []
    errors: list[str] = []

    with console.status(f"[{th['info']}]Discovering firmware files...[/{th['info']}]"):
        for fpath in scan_path.rglob("*"):
            try:
                if fpath.is_file() and fpath.suffix.lower() in exts:
                    found.append(fpath)
            except PermissionError as e:
                errors.append(str(e))

    if not found:
        console.print(f"[{th['warning']}]No firmware files found.[/{th['warning']}]")
        return

    tbl = Table(
        title=f"Found {len(found)} firmware file(s)",
        box=box.SIMPLE_HEAD, header_style=th["table_header"],
    )
    tbl.add_column("#",    width=5,  style="dim")
    tbl.add_column("Path", style=th["info"])
    tbl.add_column("Size", justify="right", style=th["value"])
    for i, fp in enumerate(found, 1):
        try:
            size = f"{fp.stat().st_size:,} B"
        except Exception:
            size = "?"
        tbl.add_row(str(i), str(fp), size)
    console.print(tbl)

    if errors:
        console.print(f"\n  [dim]{len(errors)} path(s) skipped (permission denied)[/dim]")

    if typer.confirm(f"\n  Submit all {len(found)} file(s) to CVE Hunter?"):
        for fp in found:
            try:
                resp = requests.post(
                    f"{backend_url}/scan/firmware",
                    json={"firmware_path": str(fp)},
                    timeout=10,
                )
                console.print(f"  [{th['success']}]OK[/{th['success']}] Submitted: {fp.name}  job={resp.json().get('job_id','?')[:8]}")
            except Exception as e:
                console.print(f"  [{th['error']}]FAIL[/{th['error']}] {fp.name}  {e}")


if __name__ == "__main__":
    app()
