"""Firmware Fortress CLI — Autonomous firmware supply chain security."""

__version__ = "1.0.0"
__author__ = "Firmware Fortress Contributors"
__license__ = "MIT"
