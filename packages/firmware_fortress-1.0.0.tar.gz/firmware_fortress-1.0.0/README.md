# 🛡 Firmware Fortress

**Autonomous firmware supply chain security — powered by four AI agents.**

Firmware Fortress hunts CVEs in firmware binaries, reconstructs attack timelines from breach logs, enforces CI/CD pipeline security, and performs deep email phishing forensics. Every result is written to Supabase and broadcast in real time across four interfaces: a Next.js landing page, a React web dashboard, a PyQt5 Windows desktop app, and a Python CLI.

> **Demo mode works without any API keys or backend.** Every interface falls back to preloaded TP-Link WR740N breach scenario data instantly.

---

## What It Does

| Agent | Role | Input | Output |
|---|---|---|---|
| **CVE Hunter** | Extracts components, queries NVD, enriches with AI | Firmware binary | CVE list + CVSS scores + remediation |
| **Incident Detective** | Correlates logs, reconstructs attack timeline | JSON / plain-text logs | Timeline + confidence score + patch strategy |
| **CI/CD Watchdog** | Scans secrets, checks deps, blocks/approves builds | Build event JSON | Block/approve decision + findings |
| **Email Forensics** | Homograph detection, SPF/DMARC/MX, URL analysis | `.eml` file | Forensic report + 0–100 risk score |

All agents use **Groq LLaMA-3.3-70B** for structured reasoning. CVE data comes from the **NVD API** (authenticated). All results persist in **Supabase** and sync via **WebSocket**. **All interfaces fall back to demo data if APIs are unavailable.**

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                      FastAPI Backend                          │
│                                                              │
│   Agent 1: CVE Hunter        Agent 2: Incident Detective     │
│   Agent 3: CI/CD Watchdog    Agent 4: Email Forensics        │
│                                                              │
│   REST API  ·  WebSocket /ws  ·  Supabase PostgreSQL         │
└───────────────────────┬──────────────────────────────────────┘
                        │  WebSocket + REST
          ┌─────────────┼──────────────┬──────────────┐
          │             │              │              │
   Next.js Landing   Web Dashboard  Desktop App     CLI
   (port 3000)       (port 5173)    (PyQt5 EXE)   (pip)
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | FastAPI · Uvicorn · Python 3.11+ |
| AI Engine | Groq API · LLaMA-3.3-70B-Versatile |
| CVE Data | NVD API (authenticated) · nvdlib |
| Database | Supabase (PostgreSQL + Realtime) |
| Landing Page | Next.js 15 · React 19 · Tailwind CSS |
| Web Dashboard | React 18 + Vite · Tailwind CSS |
| Desktop App | PyQt5 · Windows EXE (PyInstaller onedir) |
| CLI | Typer · Rich · Python |

---

## Prerequisites

- Python **3.11+**
- Node **18+**
- A [Supabase](https://supabase.com) project (free tier works) — **optional, falls back to in-memory**
- A [Groq API key](https://console.groq.com) (free tier available) — **optional, falls back to demo data**
- An [NVD API key](https://nvd.nist.gov/developers/request-an-api-key) (free) — **optional**
- `binwalk` — `apt install binwalk` / `brew install binwalk` — **optional, falls back to filename parsing**

---

## Environment Setup

```bash
cp .env.example .env
```

Fill in `.env` (all optional — system works in demo mode without them):

```env
GROQ_API_KEY=your_groq_api_key
NVD_API_KEY=your_nvd_api_key
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_key
BACKEND_URL=http://localhost:8000
WS_URL=ws://localhost:8000/ws
```

---

## Quick Start

### 1. Backend

```bash
# Windows
start_backend.bat

# Linux/Mac
./start_backend.sh

# Or manually
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload --port 8000
```

API: `http://localhost:8000`  
Docs: `http://localhost:8000/docs`  
Health: `http://localhost:8000/health`

### 2. Web Dashboard

```bash
cd web
npm install
npm run dev
# http://localhost:5173
```

### 3. Landing Page

```bash
cd landing
npm install
npm run dev
# http://localhost:3000
```

### 4. CLI

```bash
# Install from source
pip install -e .

# Or from PyPI
pip install firmware-fortress

# Verify
firmware-fortress --help
```

### 5. Desktop App

```bash
pip install -r desktop/requirements.txt
python desktop/main.py

# Demo mode (no backend required)
python desktop/main.py --demo
```

---

## CLI Commands

```bash
firmware-fortress --help

# Scan a firmware binary for CVEs
firmware-fortress scan --file demo/firmware-sample.bin

# Correlate breach logs into an attack timeline
firmware-fortress correlate --logs demo/breach_logs.json

# Check a CI/CD build artifact
firmware-fortress ci-check --artifact demo/build_event.json --repo acme-iot/router-firmware --branch main

# Analyse a phishing email
firmware-fortress email-check --file demo/phishing_email.eml

# Show platform status
firmware-fortress status

# Stream live agent events
firmware-fortress watch

# Run offline demo (no backend required)
firmware-fortress demo

# Add --demo flag to any command for instant results without backend
firmware-fortress scan --file demo/firmware-sample.bin --demo
firmware-fortress correlate --logs demo/breach_logs.json --demo
firmware-fortress ci-check --artifact demo/build_event.json --repo x --branch main --demo
firmware-fortress email-check --file demo/phishing_email.eml --demo
```

---

## Demo Walkthrough

The `demo/` directory has pre-built test files for a full end-to-end run.

**Step 1 — Firmware CVE scan**
```bash
firmware-fortress scan --file demo/firmware-sample.bin
```

**Step 2 — Breach log correlation**
```bash
firmware-fortress correlate --logs demo/breach_logs.json
```

**Step 3 — CI/CD build check**
```bash
firmware-fortress ci-check \
  --artifact demo/build_event.json \
  --repo acme-iot/router-firmware \
  --branch main
```

**Step 4 — Phishing email forensics**
```bash
firmware-fortress email-check --file demo/phishing_email.eml
```

**Step 5 — Live event stream**
```bash
firmware-fortress watch
```

**Step 6 — Full offline demo (no backend)**
```bash
firmware-fortress demo
```

---

## Build Windows EXE

```bat
cd desktop
build_windows.bat
```

Output: `desktop\dist\FirmwareFortress\FirmwareFortress.exe`  
Distribution: `desktop\dist\FirmwareFortress-v1.0.0-win64.zip`

**Usage after distribution:**
```
FirmwareFortress.exe              # connects to http://localhost:8000
FirmwareFortress.exe --demo       # demo mode, no backend required
FirmwareFortress.exe --backend http://your-server:8000
```

---

## Demo Mode

Every interface has a demo mode that works without any backend, API keys, or internet:

| Interface | Demo Mode |
|---|---|
| CLI | `firmware-fortress demo` or `--demo` flag on any command |
| Web | Click "Try demo →" on the upload page |
| Desktop | `python desktop/main.py --demo` or `FirmwareFortress.exe --demo` |
| Backend | Automatically falls back to demo data when API keys are missing |

Demo scenario: **TP-Link WR740N v4.30** — 12 CVEs (2 CRITICAL), active breach, blocked CI/CD build, CRITICAL phishing email.

---

## Failure Handling

The system **never crashes** — it always falls back gracefully:

| Failure | Behaviour |
|---|---|
| Backend unreachable | CLI shows demo data with warning |
| Supabase not configured | Backend uses in-memory store |
| Groq API key missing | Agents return demo/NVD data |
| NVD API key missing | CVE Hunter uses Groq alone or demo data |
| File not found | Clear error message, no crash |
| WebSocket disconnected | Auto-reconnect with exponential backoff |

---

## Cross-System Test Checklist

### CLI
- [ ] `pip install firmware-fortress` on clean Python 3.11
- [ ] `firmware-fortress --help` shows all commands
- [ ] `firmware-fortress demo` runs without backend
- [ ] `firmware-fortress scan --file demo/firmware-sample.bin --demo` shows CVE table
- [ ] `firmware-fortress correlate --logs demo/breach_logs.json --demo` shows incident
- [ ] `firmware-fortress ci-check --artifact demo/build_event.json --repo x --branch main --demo` shows block
- [ ] `firmware-fortress email-check --file demo/phishing_email.eml --demo` shows CRITICAL
- [ ] `firmware-fortress status` shows stats (or demo stats if backend down)
- [ ] `firmware-fortress watch` connects and shows events (or retries gracefully)

### Web Dashboard
- [ ] `npm run dev` starts on port 5173
- [ ] Upload page loads with matrix background
- [ ] "Try demo →" navigates to result page instantly
- [ ] Result page shows CVE table, attack timeline, CI/CD panel
- [ ] File upload sends to backend and shows results
- [ ] Path input works for server-side paths
- [ ] Navigation `/result/:id` works with cached results

### Desktop App
- [ ] `python desktop/main.py --demo` opens without backend
- [ ] All 5 tabs visible: Dashboard, Vulnerabilities, Incidents, Pipeline, Threats
- [ ] Stats cards show values (or "—" if backend down)
- [ ] WebSocket status shows CONNECTING → LIVE when backend starts
- [ ] Scan Firmware button opens file dialog
- [ ] Check Email button opens file dialog

### Windows EXE
- [ ] `build_windows.bat` completes without errors
- [ ] `dist\FirmwareFortress\FirmwareFortress.exe` launches
- [ ] `FirmwareFortress.exe --demo` works without backend
- [ ] No DLL errors on clean Windows machine
- [ ] ZIP file created at `dist\FirmwareFortress-v1.0.0-win64.zip`

### Backend
- [ ] `uvicorn backend.main:app --reload` starts
- [ ] `GET /health` returns `{"status": "ok"}`
- [ ] `GET /stats` returns stats object
- [ ] `POST /scan/upload` accepts file upload
- [ ] `GET /scan/result/{id}` returns scan result
- [ ] `WS /ws` accepts WebSocket connections

---

## Project Structure

```
firmware-fortress/
├── backend/              # FastAPI app + four AI agents
│   ├── agents/
│   │   ├── cve_hunter.py          # Agent 1 — CVE detection
│   │   ├── incident_detective.py  # Agent 2 — Log correlation
│   │   ├── cicd_watchdog.py       # Agent 3 — Build security
│   │   └── email_forensics.py     # Agent 4 — Phishing analysis
│   ├── db/               # Supabase client (with in-memory fallback)
│   ├── models/
│   │   ├── schemas.py    # Pydantic models
│   │   └── demo_data.py  # Preloaded demo scenario
│   └── main.py           # FastAPI entry point
├── landing/              # Next.js 15 landing page
├── web/                  # React + Vite dashboard
│   └── src/
│       ├── lib/
│       │   ├── api.ts    # Backend API client
│       │   └── demo.ts   # Demo data + session storage
│       └── pages/        # Home, Result, History, etc.
├── desktop/              # PyQt5 Windows app
│   ├── windows/          # Tab implementations
│   ├── widgets/          # Reusable widgets
│   ├── ws_client.py      # WebSocket client
│   ├── firmware_fortress.spec  # PyInstaller spec
│   └── build_windows.bat
├── firmware_fortress_cli/ # CLI (pip installable)
│   ├── commands/         # scan, correlate, ci-check, email-check
│   ├── main.py           # Typer app + demo command
│   └── themes.py         # Color themes
├── demo/                 # Test files
│   ├── firmware-sample.bin   # TP-Link WR740N firmware (512KB)
│   ├── breach_logs.json      # Attack scenario logs
│   ├── build_event.json      # CI/CD build event
│   └── phishing_email.eml    # Phishing email sample
├── pyproject.toml        # CLI package config
├── start_backend.bat     # Windows backend launcher
├── start_backend.sh      # Linux/Mac backend launcher
└── .env.example
```

---

## Easter Eggs (Landing Page)

| Key | Action |
|---|---|
| `↑↑↓↓←→←→BA` | Konami code — full-screen breach sequence |
| `T` | Matrix theme picker (5 color themes) |
| `1` – `5` | Quick theme switch |
| `/` | Secret hacker terminal with real commands |
| `H` | Show all secret commands |
| `ESC` | Close any overlay |

---

## License

MIT
