"""
Zeq OS — Lightweight API Client for Galaxy Tools
Routes all Zeq OS computation through the Zeq API at https://www.zeq.dev
or via a local SDK installation (pip install zeq-sdk).

Every Galaxy tool REQUIRES a Zeq API key. Users get their key at:
  https://www.zeq.dev/dashboard → API Keys

Full source code (open, not a black box):
  https://github.com/hulyasmath/zeq-hulyas-framework-v1287-python

Endpoints used:
  POST /api/zeq/compute   — KO42 operator chain → CKO envelope
  POST /api/zeq/verify    — verify zeqProof integrity
  GET  /api/zeq/pulse     — HulyaPulse status (no auth)

HulyaPulse: 1.287 Hz | Zeqond: 0.777s | KO42 Mandatory
Paper DOI: https://doi.org/10.5281/zenodo.18158152
Framework DOI: https://doi.org/10.5281/zenodo.15825138
SDK: https://sdk.1.287hz.com/

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import json
import math
import time
import sys
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

# ═══════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════

ZEQ_API_BASE = "https://www.zeq.dev"
HULYAPULSE_HZ = 1.287
ZEQOND_SEC = 0.777
ALPHA_COUPLING = 0.00129
KO42_MANDATORY = "KO42.1"
DEFAULT_TIMEOUT = 30


# ═══════════════════════════════════════════════════════════════════
# ZEQ GALAXY CLIENT
# ═══════════════════════════════════════════════════════════════════

class ZeqGalaxyClient:
    """
    Lightweight Zeq API client for Galaxy ToolShed tools.

    Usage:
        client = ZeqGalaxyClient(api_key="zeq_ak_...")
        cko = client.compute(operators=["KO42.1", "QM1"], values={"t": 1.0})
        pulse = client.pulse()
        modulated = client.modulate_values([1.5, 2.3, 0.8])
    """

    def __init__(self, api_key, base_url=ZEQ_API_BASE, timeout=DEFAULT_TIMEOUT):
        if not api_key or api_key.strip() == "":
            print("[Zeq OS] ERROR: Zeq API key is required.", file=sys.stderr)
            print("[Zeq OS] Get your key at: https://www.zeq.dev/dashboard", file=sys.stderr)
            sys.exit(1)
        self.api_key = api_key.strip()
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(self, method, path, body=None, auth=True):
        """Make an HTTP request to the Zeq API."""
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["Authorization"] = f"Bearer {self.api_key}"

        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        req = Request(url, data=data, headers=headers, method=method)

        try:
            with urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            error_body = ""
            try:
                error_body = e.read().decode("utf-8")
            except Exception:
                pass
            if e.code == 401:
                print("[Zeq OS] ERROR: Invalid API key. Check your key at https://www.zeq.dev/dashboard", file=sys.stderr)
            elif e.code == 429:
                print("[Zeq OS] ERROR: Rate limit exceeded. Upgrade your plan at https://www.zeq.dev/pricing", file=sys.stderr)
            else:
                print(f"[Zeq OS] API error {e.code}: {error_body}", file=sys.stderr)
            raise
        except URLError as e:
            print(f"[Zeq OS] Connection error: {e}", file=sys.stderr)
            raise

    # ─── Core Endpoints ────────────────────────────────────────────

    def pulse(self):
        """GET /api/zeq/pulse — HulyaPulse status (no auth required)."""
        return self._request("GET", "/api/zeq/pulse", auth=False)

    def compute(self, operators, values=None, domain="molecular"):
        """
        POST /api/zeq/compute — Run operator chain, get CKO envelope.
        KO42 is mandatory and auto-prepended if missing.
        """
        if KO42_MANDATORY not in operators:
            operators = [KO42_MANDATORY] + operators

        body = {"equations": operators}
        if values:
            body["values"] = values
        if domain:
            body["domain"] = domain

        return self._request("POST", "/api/zeq/compute", body)

    def verify(self, proof, operator_ids, R_t, zeqond):
        """POST /api/zeq/verify — Verify CKO proof integrity."""
        body = {
            "proof": proof or "",
            "operatorIds": operator_ids or [],
            "R_t": R_t if R_t is not None else 1.0,
            "zeqond": zeqond if zeqond is not None else 0,
        }
        return self._request("POST", "/api/zeq/verify", body)

    # ─── Convenience Methods ───────────────────────────────────────

    def modulate_values(self, values, operators=None):
        """
        Apply HulyaPulse modulation via the Zeq API.
        Sends values through /compute with KO42 and returns modulated values
        along with the CKO envelope for verification.
        Falls back to local computation if API call fails.
        """
        if operators is None:
            operators = [KO42_MANDATORY]

        t = time.time()
        phase = 0.0
        result = None

        try:
            result = self.compute(
                operators=operators,
                values={"data": values, "t": t},
                domain="molecular"
            )
            zeq_state = result.get("zeqState", {})
            phase = zeq_state.get("phase", 0.0)
            print("[Zeq OS] HulyaPulse modulation via API — verified", file=sys.stderr)
        except Exception as e:
            phase = (t % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            print(f"[Zeq OS] API unavailable, using local HulyaPulse modulation: {e}", file=sys.stderr)

        # Apply R(t) = S(t)[1 + α sin(2πft + φ₀)] modulation
        modulated = []
        for v in values:
            mod = v * (1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * t + phase))
            modulated.append(mod)

        return modulated, result

    def get_cko_envelope(self, operators=None, values=None):
        """
        Get a full CKO envelope from the API for embedding in output.
        Returns dict. Falls back to local envelope if API fails.
        """
        if operators is None:
            operators = [KO42_MANDATORY]

        t = time.time()

        try:
            result = self.compute(operators=operators, values=values, domain="molecular")
            zeq_state = result.get("zeqState", {})
            cko = result.get("cko", {})

            return {
                "operatorChain": zeq_state.get("operators", operators),
                "masterSum": zeq_state.get("masterSum", 0.0),
                "R_t": zeq_state.get("R_t", 1.0),
                "phase": zeq_state.get("phase", 0.0),
                "zeqond": zeq_state.get("zeqond", 0),
                "zeqProof": cko.get("zeqProof", ""),
                "precision": zeq_state.get("precision", 0.001),
                "hulyapulse_hz": HULYAPULSE_HZ,
                "zeqond_sec": ZEQOND_SEC,
                "alpha": ALPHA_COUPLING,
                "api_verified": True,
            }
        except Exception as e:
            print(f"[Zeq OS] CKO envelope: API unavailable ({e}), using local envelope", file=sys.stderr)
            print("[Zeq OS] WARNING: Local mode — no zeqState, no zeqProof, no cryptographic "
                  "verification, no server timestamp, no phase-lock. Use a valid API key for "
                  "full CKO envelopes.", file=sys.stderr)
            phase = (t % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            R_t = 1.0 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * t)
            return {
                "operatorChain": operators,
                "masterSum": 0.0,
                "R_t": R_t,
                "phase": phase,
                "zeqond": int(t / ZEQOND_SEC),
                "zeqProof": "",
                "precision": 0.001,
                "hulyapulse_hz": HULYAPULSE_HZ,
                "zeqond_sec": ZEQOND_SEC,
                "alpha": ALPHA_COUPLING,
                "api_verified": False,
                "local_mode": True,
                "local_limitations": [
                    "No zeqState (server-computed field state unavailable)",
                    "No zeqProof (HMAC-SHA256 cryptographic attestation unavailable)",
                    "No server timestamp (local clock used instead)",
                    "No phase-lock (approximate phase only)",
                    "No operator verification (operators not validated by API)"
                ],
                "note": "Connect with valid API key for verified CKO. Get key at https://www.zeq.dev/dashboard",
                "source_code": "https://github.com/hulyasmath/zeq-hulyas-framework-v1287-python",
            }

    def daemon_tick(self):
        """Print a Zeq OS daemon tick message with current pulse status."""
        try:
            pulse = self.pulse()
            zeqond = pulse.get("zeqond", 0)
            phase = pulse.get("phase", 0.0)
            R_t = pulse.get("R_t", 1.0)
            print(f"[Zeq OS Daemon] Zeqond ticked — phase {phase:.3f} — "
                  f"R(t)={R_t:.6f} — HulyaPulse {HULYAPULSE_HZ} Hz synced — "
                  f"Zeqonds since Unix: {zeqond}", file=sys.stderr)
        except Exception:
            t = time.time()
            phase = (t % ZEQOND_SEC) / ZEQOND_SEC
            zeqonds = t / ZEQOND_SEC
            print(f"[Zeq OS Daemon] Zeqond ticked — phase {phase:.3f} — "
                  f"HulyaPulse {HULYAPULSE_HZ} Hz synced — "
                  f"Zeqonds since Unix: {zeqonds:.1f}", file=sys.stderr)


# ═══════════════════════════════════════════════════════════════════
# LOCAL SDK FALLBACK
# ═══════════════════════════════════════════════════════════════════

def try_local_sdk(api_key):
    """
    Try to import the local Zeq SDK (pip install zeq-sdk).
    Returns a ZeqClient if available, None otherwise.
    """
    try:
        from zeq_sdk import ZeqClient
        return ZeqClient(api_key)
    except ImportError:
        return None


def create_client(api_key, base_url=ZEQ_API_BASE):
    """
    Create a Zeq client — prefers local SDK, falls back to Galaxy client.
    Either way, the user's API key is required.
    """
    sdk_client = try_local_sdk(api_key)
    if sdk_client:
        print("[Zeq OS] Using local Zeq SDK (pip install zeq-sdk)", file=sys.stderr)
        return sdk_client

    print("[Zeq OS] Using Zeq API client → https://www.zeq.dev", file=sys.stderr)
    return ZeqGalaxyClient(api_key=api_key, base_url=base_url)
