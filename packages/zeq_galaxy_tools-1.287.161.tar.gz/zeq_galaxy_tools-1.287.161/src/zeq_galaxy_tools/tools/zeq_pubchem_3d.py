#!/usr/bin/env python3
"""
Zeq OS — PubChem 3D Molecular Connector for Galaxy
Fetches 3D conformer data from PubChem PUG REST API and computes
bond lengths, atomic distances, and molecular properties.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import csv
import json
import math
import sys
import time
import urllib.parse
import urllib.request

try:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC
except ImportError:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC

PUBCHEM_BASE = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"


def resolve_cid(molecule_name):
    """Resolve a molecule name to a PubChem CID."""
    try:
        url = f"{PUBCHEM_BASE}/compound/name/{urllib.parse.quote(molecule_name)}/cids/JSON"
        with urllib.request.urlopen(url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
            return data["IdentifierList"]["CID"][0]
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not resolve molecule '{molecule_name}': {e}", file=sys.stderr)
        sys.exit(1)


def fetch_3d_conformer(cid):
    """Fetch 3D conformer data for a CID."""
    url = f"{PUBCHEM_BASE}/compound/cid/{cid}/JSON?record_type=3d"
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch 3D data for CID {cid}: {e}", file=sys.stderr)
        sys.exit(1)


def fetch_properties(cid):
    """Fetch molecular properties for a CID."""
    props = "MolecularWeight,XLogP,HBondDonorCount,HBondAcceptorCount,TPSA,Complexity,HeavyAtomCount,RotatableBondCount,MolecularFormula,IsomericSMILES"
    url = f"{PUBCHEM_BASE}/compound/cid/{cid}/property/{props}/JSON"
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
            return data["PropertyTable"]["Properties"][0]
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch properties for CID {cid}: {e}", file=sys.stderr)
        sys.exit(1)


def compute_bond_lengths(compound):
    """Compute 3D bond lengths from conformer data."""
    coords = compound["coords"][0]["conformers"][0]
    bonds = compound.get("bonds", {})
    xs, ys, zs = coords["x"], coords["y"], coords["z"]

    bond_lengths = []
    if bonds and "aid1" in bonds:
        for i in range(len(bonds["aid1"])):
            a1 = bonds["aid1"][i] - 1
            a2 = bonds["aid2"][i] - 1
            dx = xs[a1] - xs[a2]
            dy = ys[a1] - ys[a2]
            dz = zs[a1] - zs[a2]
            bond_lengths.append({
                "atom1": a1 + 1,
                "atom2": a2 + 1,
                "element1": compound["atoms"]["element"][a1],
                "element2": compound["atoms"]["element"][a2],
                "length_angstrom": math.sqrt(dx*dx + dy*dy + dz*dz),
                "bond_order": bonds.get("order", [1]*len(bonds["aid1"]))[i] if "order" in bonds else 1
            })
    return bond_lengths


def compute_atomic_distances(compound):
    """Compute distances of each atom from the molecular centroid."""
    coords = compound["coords"][0]["conformers"][0]
    xs, ys, zs = coords["x"], coords["y"], coords["z"]
    n = len(xs)

    cx = sum(xs) / n
    cy = sum(ys) / n
    cz = sum(zs) / n

    distances = []
    for i in range(n):
        dx = xs[i] - cx
        dy = ys[i] - cy
        dz = zs[i] - cz
        distances.append({
            "atom_index": i + 1,
            "element": compound["atoms"]["element"][i],
            "x": xs[i],
            "y": ys[i],
            "z": zs[i],
            "distance_from_centroid": math.sqrt(dx*dx + dy*dy + dz*dz)
        })
    return distances, (cx, cy, cz)


# Element number to symbol mapping
ELEMENT_SYMBOLS = {
    1: "H", 2: "He", 3: "Li", 4: "Be", 5: "B", 6: "C", 7: "N", 8: "O",
    9: "F", 10: "Ne", 11: "Na", 12: "Mg", 13: "Al", 14: "Si", 15: "P",
    16: "S", 17: "Cl", 18: "Ar", 19: "K", 20: "Ca", 26: "Fe", 29: "Cu",
    30: "Zn", 35: "Br", 53: "I"
}


def element_symbol(num):
    return ELEMENT_SYMBOLS.get(num, f"#{num}")


def main():
    parser = argparse.ArgumentParser(description="Zeq OS PubChem 3D Molecular Connector (HulyaPulse v1.287.110)")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required). Get your key at https://www.zeq.dev/dashboard")
    parser.add_argument("--molecule", required=True, help="Molecule name (e.g., caffeine, aspirin)")
    parser.add_argument("--mode", choices=["bonds", "atoms", "properties", "all"], default="all",
                        help="Analysis mode: bonds (3D bond lengths), atoms (atomic distances), properties, or all")
    parser.add_argument("--output_bonds", default=None, help="Output CSV file for bond lengths")
    parser.add_argument("--output_atoms", default=None, help="Output CSV file for atomic distances")
    parser.add_argument("--output_properties", default=None, help="Output CSV file for molecular properties")
    parser.add_argument("--output_json", default=None, help="Output JSON file with all results")
    parser.add_argument("--hulyapulse", action="store_true", help="Apply HulyaPulse 1.287 Hz modulation via Zeq API")

    args = parser.parse_args()

    # Create Zeq API client (validates key)
    client = create_client(args.zeq_api_key)

    # Resolve molecule
    print(f"[Zeq OS] Resolving molecule: {args.molecule}", file=sys.stderr)
    cid = resolve_cid(args.molecule)
    print(f"[Zeq OS] Resolved to PubChem CID: {cid}", file=sys.stderr)

    results = {"molecule": args.molecule, "cid": cid, "hulyapulse_hz": HULYAPULSE_HZ, "zeqond_sec": ZEQOND_SEC}

    # Fetch 3D conformer
    if args.mode in ("bonds", "atoms", "all"):
        print(f"[Zeq OS] Fetching 3D conformer for CID {cid}...", file=sys.stderr)
        conf_data = fetch_3d_conformer(cid)
        compound = conf_data["PC_Compounds"][0]
        num_atoms = len(compound["atoms"]["element"])
        print(f"[Zeq OS] 3D conformer loaded: {num_atoms} atoms", file=sys.stderr)

    # Bond lengths
    if args.mode in ("bonds", "all"):
        bond_lengths = compute_bond_lengths(compound)
        print(f"[Zeq OS] Computed {len(bond_lengths)} bond lengths", file=sys.stderr)

        if args.hulyapulse:
            raw_lengths = [b["length_angstrom"] for b in bond_lengths]
            mod_lengths, zeq_result = client.modulate_values(raw_lengths)
            for i, b in enumerate(bond_lengths):
                b["length_hulyapulse"] = mod_lengths[i]

        results["bond_lengths"] = bond_lengths

        if args.output_bonds:
            with open(args.output_bonds, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                header = ["atom1", "atom2", "element1", "element2", "bond_order", "length_angstrom"]
                if args.hulyapulse:
                    header.append("length_hulyapulse")
                writer.writerow(header)
                for b in bond_lengths:
                    row = [b["atom1"], b["atom2"], element_symbol(b["element1"]),
                           element_symbol(b["element2"]), b["bond_order"],
                           f"{b['length_angstrom']:.6f}"]
                    if args.hulyapulse:
                        row.append(f"{b['length_hulyapulse']:.6f}")
                    writer.writerow(row)

    # Atomic distances
    if args.mode in ("atoms", "all"):
        distances, centroid = compute_atomic_distances(compound)
        print(f"[Zeq OS] Computed {len(distances)} atomic distances from centroid ({centroid[0]:.3f}, {centroid[1]:.3f}, {centroid[2]:.3f})", file=sys.stderr)

        results["atomic_distances"] = distances
        results["centroid"] = {"x": centroid[0], "y": centroid[1], "z": centroid[2]}

        if args.output_atoms:
            with open(args.output_atoms, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["atom_index", "element", "x", "y", "z", "distance_from_centroid"])
                for d in distances:
                    writer.writerow([d["atom_index"], element_symbol(d["element"]),
                                     f"{d['x']:.6f}", f"{d['y']:.6f}", f"{d['z']:.6f}",
                                     f"{d['distance_from_centroid']:.6f}"])

    # Properties
    if args.mode in ("properties", "all"):
        print(f"[Zeq OS] Fetching molecular properties for CID {cid}...", file=sys.stderr)
        props = fetch_properties(cid)
        results["properties"] = props
        print(f"[Zeq OS] MW={props.get('MolecularWeight')}, Formula={props.get('MolecularFormula')}", file=sys.stderr)

        if args.output_properties:
            with open(args.output_properties, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["property", "value"])
                for k, v in props.items():
                    writer.writerow([k, v])

    # Get CKO envelope from API
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    # Daemon tick with API status
    client.daemon_tick()
    print(f"[Zeq OS] Analysis complete for {args.molecule} (CID {cid})", file=sys.stderr)


if __name__ == "__main__":
    main()
