#!/usr/bin/env python3
"""
Zeq OS — NIST Spectral Emission Time-Modulation Sibling
Wraps zeq_nist_spectral with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to emission intensities and wavelengths via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import sys
import json
import csv
import math
import time

try:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING
except ImportError:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING

# Built-in NIST emission line database — matches original zeq_nist_spectral
# Format: element: [(wavelength_nm, relative_intensity, series), ...]
EMISSION_DATABASE = {
    "H": [
        (656.3, 100.0, "Balmer Ha"),
        (486.1, 65.0, "Balmer Hb"),
        (434.0, 40.0, "Balmer Hg"),
        (410.2, 25.0, "Balmer Hd"),
    ],
    "He": [
        (587.6, 100.0, "Helium Yellow"),
        (501.6, 70.0, "Helium Cyan"),
        (667.8, 85.0, "Helium Red"),
        (706.5, 60.0, "Helium Far-Red"),
    ],
    "Li": [
        (670.8, 100.0, "Lithium Red"),
        (610.4, 80.0, "Lithium Orange"),
        (460.3, 65.0, "Lithium Blue"),
    ],
    "Be": [
        (313.0, 100.0, "Beryllium UV"),
        (332.1, 90.0, "Beryllium UV"),
        (234.9, 70.0, "Beryllium Far-UV"),
    ],
    "B": [
        (249.7, 100.0, "Boron UV"),
        (249.8, 95.0, "Boron UV"),
        (208.9, 75.0, "Boron Far-UV"),
    ],
    "C": [
        (247.9, 100.0, "Carbon UV"),
        (193.1, 85.0, "Carbon Far-UV"),
        (165.7, 70.0, "Carbon Extreme-UV"),
    ],
    "N": [
        (746.8, 100.0, "Nitrogen Red"),
        (744.2, 98.0, "Nitrogen Red"),
        (868.0, 75.0, "Nitrogen Far-Red"),
        (862.9, 73.0, "Nitrogen Far-Red"),
    ],
    "O": [
        (777.2, 100.0, "Oxygen Triplet"),
        (777.4, 100.0, "Oxygen Triplet"),
        (844.6, 85.0, "Oxygen Far-Red"),
        (615.8, 80.0, "Oxygen Orange"),
    ],
    "Na": [
        (589.0, 100.0, "Sodium D1"),
        (589.6, 100.0, "Sodium D2"),
        (330.2, 65.0, "Sodium UV"),
        (330.3, 65.0, "Sodium UV"),
    ],
    "Mg": [
        (285.2, 100.0, "Magnesium UV"),
        (280.3, 95.0, "Magnesium UV"),
        (518.4, 70.0, "Magnesium Green"),
    ],
    "Al": [
        (396.2, 100.0, "Aluminum Violet"),
        (394.4, 98.0, "Aluminum Violet"),
        (309.3, 75.0, "Aluminum UV"),
    ],
    "Si": [
        (251.6, 100.0, "Silicon UV"),
        (288.2, 85.0, "Silicon UV"),
        (390.6, 70.0, "Silicon Violet"),
    ],
    "Fe": [
        (371.9, 100.0, "Iron Violet"),
        (374.6, 95.0, "Iron Violet"),
        (382.0, 90.0, "Iron Violet"),
        (385.6, 85.0, "Iron Violet"),
        (404.6, 80.0, "Iron Violet"),
    ],
    "Cu": [
        (324.8, 100.0, "Copper UV"),
        (327.4, 95.0, "Copper UV"),
        (510.6, 75.0, "Copper Green"),
        (515.3, 70.0, "Copper Green"),
    ],
    "Zn": [
        (213.9, 100.0, "Zinc Far-UV"),
        (330.3, 85.0, "Zinc UV"),
        (334.5, 80.0, "Zinc UV"),
        (481.1, 70.0, "Zinc Blue"),
    ],
    "Br": [
        (478.6, 100.0, "Bromine Blue"),
        (481.7, 98.0, "Bromine Blue"),
        (614.8, 75.0, "Bromine Orange"),
    ],
}


def apply_time_modulation(values, zeq_client, domain="electromagnetism", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to spectral values via single batch Zeq API call."""
    current_time = time.time()

    # Single batch API call instead of per-value loop
    modulated_vals, result = zeq_client.modulate_values(values)

    if result:
        zeq_state = result.get("zeqState", {})
        phase = zeq_state.get("phase", 0.0)
        r_t = zeq_state.get("masterSum", 1.0)
        zeqond = zeq_state.get("zeqond", 0)
        proof = result.get("zeqProof", "")
    else:
        phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
        r_t = 1.0
        zeqond = int(current_time / ZEQOND_SEC)
        proof = ""

    modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)

    modulated = []
    for i, val in enumerate(values):
        modulated.append({
            "original": val,
            "modulated": modulated_vals[i],
            "R_t": r_t,
            "phase": phase,
            "zeqond": zeqond,
            "proof": proof,
            "modulation_factor": modulation_factor
        })

    return modulated


def compute_gaussian_spectrum(wavelengths, intensities, sigma=2.0):
    """Compute Gaussian-broadened spectrum."""
    min_wl = min(wavelengths) - 50
    max_wl = max(wavelengths) + 50
    spectrum = []

    for wl in range(int(min_wl), int(max_wl), 5):
        intensity = 0
        for line_wl, line_int in zip(wavelengths, intensities):
            gauss = line_int * math.exp(-((wl - line_wl) ** 2) / (2 * sigma * sigma))
            intensity += gauss
        spectrum.append({"wavelength": wl, "intensity": intensity})

    return spectrum


def main():
    parser = argparse.ArgumentParser(description="Zeq OS NIST Spectral Time-Modulation Sibling (HulyaPulse v1.287.110)")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--element", required=True, help="Element symbol (e.g., H, He, Fe, Na)")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_lines", default=None, help="Output CSV for emission lines")
    parser.add_argument("--output_spectrum", default=None, help="Output CSV for broadened spectrum")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    element = args.element.strip().capitalize()  # Na, He, etc. — first letter upper, rest lower

    if element not in EMISSION_DATABASE:
        print(f"[Zeq OS] ERROR: Element {element} not in database. Available: {', '.join(sorted(EMISSION_DATABASE.keys()))}", file=sys.stderr)
        sys.exit(1)

    print(f"[Zeq OS] Fetching emission lines for {element}...", file=sys.stderr)

    # Get emission lines
    lines = EMISSION_DATABASE[element]
    wavelengths = [line[0] for line in lines]
    intensities = [line[1] for line in lines]
    labels = [line[2] for line in lines]

    print(f"[Zeq OS] Retrieved {len(lines)} emission lines for {element}", file=sys.stderr)

    results = {
        "element": element,
        "num_lines": len(lines),
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_sec": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Apply time modulation to wavelengths and intensities
    mod_wavelengths = apply_time_modulation(wavelengths, client, domain="electromagnetism", tm_steps=args.tm_steps)
    mod_intensities = apply_time_modulation(intensities, client, domain="electromagnetism", tm_steps=args.tm_steps)

    # Build emission line data
    emission_lines = []
    for i, (wl, intensity, label) in enumerate(zip(wavelengths, intensities, labels)):
        emission_lines.append({
            "wavelength_nm": wl,
            "intensity": intensity,
            "label": label,
            "wavelength_tm": mod_wavelengths[i],
            "intensity_tm": mod_intensities[i]
        })

    results["emission_lines"] = emission_lines

    # Output emission lines
    if args.output_lines:
        with open(args.output_lines, "w", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["wavelength_nm", "intensity", "label",
                            "wavelength_tm_modulated", "intensity_tm_modulated",
                            "R_t_wl", "phase_wl", "zeqond_wl"])
            for line in emission_lines:
                wl_mod = line["wavelength_tm"]
                int_mod = line["intensity_tm"]
                writer.writerow([
                    f"{line['wavelength_nm']:.6f}",
                    f"{line['intensity']:.6f}",
                    line["label"],
                    f"{wl_mod['modulated']:.6f}",
                    f"{int_mod['modulated']:.6f}",
                    f"{wl_mod['R_t']:.6f}",
                    f"{wl_mod['phase']:.6f}",
                    wl_mod['zeqond']
                ])

    # Compute Gaussian-broadened spectrum
    print(f"[Zeq OS] Computing Gaussian-broadened spectrum...", file=sys.stderr)
    spectrum = compute_gaussian_spectrum(wavelengths, intensities)

    # Apply modulation to spectrum intensities
    spec_intensities = [s["intensity"] for s in spectrum]
    mod_spec = apply_time_modulation(spec_intensities, client, domain="electromagnetism", tm_steps=args.tm_steps)

    for i, s in enumerate(spectrum):
        s["intensity_tm"] = mod_spec[i]

    results["spectrum"] = spectrum[:len(spectrum)//2 + len(spectrum)%2]  # Limit for JSON

    # Output spectrum
    if args.output_spectrum:
        with open(args.output_spectrum, "w", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["wavelength_nm", "intensity", "intensity_tm_modulated", "R_t", "phase", "zeqond"])
            for spec in spectrum:
                mod = spec["intensity_tm"]
                writer.writerow([
                    f"{spec['wavelength']:.2f}",
                    f"{spec['intensity']:.4f}",
                    f"{mod['modulated']:.4f}",
                    f"{mod['R_t']:.6f}",
                    f"{mod['phase']:.6f}",
                    mod['zeqond']
                ])

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for {element}", file=sys.stderr)


if __name__ == "__main__":
    main()
