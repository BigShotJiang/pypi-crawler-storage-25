#!/usr/bin/env python3
"""
Zeq OS — Molecular Dynamics Simulator Time-Modulation Sibling
Wraps zeq_md_simulator with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to particle trajectories and energy values via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import csv
import json
import math
import random
import sys
import time

try:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING
except ImportError:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING


class MDSimulatorTM:
    """Molecular Dynamics Simulator with Time-Modulation."""

    def __init__(self, num_particles=10, dt=0.01, temperature=300, potential="lennard_jones"):
        self.num_particles = num_particles
        self.dt = dt
        self.temperature = temperature
        self.potential = potential

        random.seed(42)
        self.positions = [[random.uniform(-5, 5) for _ in range(3)] for _ in range(num_particles)]
        self.velocities = [[random.uniform(-0.1, 0.1) for _ in range(3)] for _ in range(num_particles)]
        self.accelerations = [[0, 0, 0] for _ in range(num_particles)]

        self.energies = []
        self.trajectory = []
        self.kinetic_energies = []
        self.potential_energies = []

    def compute_forces(self):
        for i in range(self.num_particles):
            self.accelerations[i] = [0, 0, 0]
        for i in range(self.num_particles):
            for j in range(i + 1, self.num_particles):
                dx = self.positions[j][0] - self.positions[i][0]
                dy = self.positions[j][1] - self.positions[i][1]
                dz = self.positions[j][2] - self.positions[i][2]
                r = math.sqrt(dx*dx + dy*dy + dz*dz)
                if r < 0.1:
                    r = 0.1
                if self.potential == "lennard_jones":
                    sigma = 1.0
                    epsilon = 1.0
                    s6 = (sigma / r) ** 6
                    force = 24 * epsilon * (2 * s6 * s6 - s6) / r
                else:
                    force = -100 * r
                fx = force * dx / r
                fy = force * dy / r
                fz = force * dz / r
                self.accelerations[i][0] += fx
                self.accelerations[i][1] += fy
                self.accelerations[i][2] += fz
                self.accelerations[j][0] -= fx
                self.accelerations[j][1] -= fy
                self.accelerations[j][2] -= fz

    def compute_energy(self):
        ke = 0
        pe = 0
        for i in range(self.num_particles):
            v_sq = sum(v*v for v in self.velocities[i])
            ke += 0.5 * v_sq
        for i in range(self.num_particles):
            for j in range(i + 1, self.num_particles):
                dx = self.positions[j][0] - self.positions[i][0]
                dy = self.positions[j][1] - self.positions[i][1]
                dz = self.positions[j][2] - self.positions[i][2]
                r = math.sqrt(dx*dx + dy*dy + dz*dz)
                if self.potential == "lennard_jones":
                    sigma = 1.0
                    epsilon = 1.0
                    s6 = (sigma / r) ** 6
                    pe += 4 * epsilon * (s6*s6 - s6)
                else:
                    pe += 50 * (dx*dx + dy*dy + dz*dz)
        return ke, pe

    def velocity_verlet_step(self):
        for i in range(self.num_particles):
            for d in range(3):
                self.positions[i][d] += (self.velocities[i][d] * self.dt
                    + 0.5 * self.accelerations[i][d] * self.dt * self.dt)
        old_acc = [list(a) for a in self.accelerations]
        self.compute_forces()
        for i in range(self.num_particles):
            for d in range(3):
                self.velocities[i][d] += 0.5 * (old_acc[i][d] + self.accelerations[i][d]) * self.dt
        ke, pe = self.compute_energy()
        self.kinetic_energies.append(ke)
        self.potential_energies.append(pe)
        self.energies.append(ke + pe)

    def run(self, num_steps):
        for step in range(num_steps):
            self.velocity_verlet_step()
            self.trajectory.append([list(p) for p in self.positions])

    def get_energy_data(self):
        return [{"step": i, "kinetic": self.kinetic_energies[i],
                 "potential": self.potential_energies[i], "total": self.energies[i]}
                for i in range(len(self.energies))]


def apply_time_modulation(values, zeq_client, domain="classical-mechanics", tm_steps=16):
    current_time = time.time()
    modulated_vals, result = zeq_client.modulate_values(values)
    if result:
        zeq_state = result.get("zeqState", {})
        phase = zeq_state.get("phase", 0.0)
        r_t = zeq_state.get("masterSum", 1.0)
        zeqond = zeq_state.get("zeqond", 0)
        proof = result.get("zeqProof", "")
    else:
        phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
        r_t = 1.0
        zeqond = int(current_time / ZEQOND_SEC)
        proof = ""
    mod_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
    modulated = []
    for i, val in enumerate(values):
        modulated.append({"original": val, "modulated": modulated_vals[i],
                          "R_t": r_t, "phase": phase, "zeqond": zeqond,
                          "proof": proof, "modulation_factor": mod_factor})
    return modulated


def main():
    parser = argparse.ArgumentParser(description="Zeq OS Molecular Dynamics Time-Modulation Sibling (HulyaPulse v1.287.110)")
    parser.add_argument("--zeq_api_key", required=True)
    parser.add_argument("--num_particles", type=int, default=10)
    parser.add_argument("--num_steps", type=int, default=100)
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--potential", choices=["lennard_jones", "harmonic"], default="lennard_jones")
    parser.add_argument("--tm_steps", type=int, default=16)
    parser.add_argument("--output_trajectory", default=None)
    parser.add_argument("--output_energy", default=None)
    parser.add_argument("--output_json", default=None)
    args = parser.parse_args()

    client = create_client(args.zeq_api_key)
    print(f"[Zeq OS] Initializing MD simulator: {args.num_particles} particles, {args.potential} potential", file=sys.stderr)

    sim = MDSimulatorTM(num_particles=args.num_particles, dt=args.dt, potential=args.potential)
    print(f"[Zeq OS] Running {args.num_steps} MD steps...", file=sys.stderr)
    sim.run(args.num_steps)
    print("[Zeq OS] MD simulation complete", file=sys.stderr)

    results = {"num_particles": args.num_particles, "num_steps": args.num_steps,
               "dt": args.dt, "potential": args.potential, "hulyapulse_hz": HULYAPULSE_HZ,
               "zeqond_sec": ZEQOND_SEC, "tm_steps": args.tm_steps, "alpha_coupling": ALPHA_COUPLING}

    # Energy modulation
    energy_data = sim.get_energy_data()
    print("[Zeq OS] Applying HulyaPulse modulation to energy values...", file=sys.stderr)
    mod_total = apply_time_modulation([e["total"] for e in energy_data], client, tm_steps=args.tm_steps)
    mod_ke = apply_time_modulation([e["kinetic"] for e in energy_data], client, tm_steps=args.tm_steps)
    mod_pe = apply_time_modulation([e["potential"] for e in energy_data], client, tm_steps=args.tm_steps)
    for i, e in enumerate(energy_data):
        e["total_tm"] = mod_total[i]
        e["kinetic_tm"] = mod_ke[i]
        e["potential_tm"] = mod_pe[i]
    results["energy_data"] = energy_data

    # Trajectory position modulation
    trajectory_data = []
    if sim.trajectory:
        print("[Zeq OS] Applying HulyaPulse modulation to trajectory positions...", file=sys.stderr)
        all_coords = []
        for snapshot in sim.trajectory:
            for pos in snapshot:
                all_coords.extend(pos)
        mod_coords = apply_time_modulation(all_coords, client, tm_steps=args.tm_steps)
        for step_idx, snapshot in enumerate(sim.trajectory):
            for p_idx, pos in enumerate(snapshot):
                base = (step_idx * args.num_particles + p_idx) * 3
                trajectory_data.append({
                    "step": step_idx, "particle": p_idx,
                    "x": pos[0], "y": pos[1], "z": pos[2],
                    "x_tm": mod_coords[base]["modulated"],
                    "y_tm": mod_coords[base + 1]["modulated"],
                    "z_tm": mod_coords[base + 2]["modulated"],
                    "R_t": mod_coords[base]["R_t"],
                    "phase": mod_coords[base]["phase"],
                    "zeqond": mod_coords[base]["zeqond"]
                })

    # Write trajectory TSV
    if args.output_trajectory and trajectory_data:
        with open(args.output_trajectory, "w", newline="") as f:
            w = csv.writer(f, delimiter="\t")
            w.writerow(["step", "particle", "x", "y", "z", "x_tm", "y_tm", "z_tm", "R_t", "phase", "zeqond"])
            for t in trajectory_data:
                w.writerow([t["step"], t["particle"],
                    f"{t['x']:.6f}", f"{t['y']:.6f}", f"{t['z']:.6f}",
                    f"{t['x_tm']:.6f}", f"{t['y_tm']:.6f}", f"{t['z_tm']:.6f}",
                    f"{t['R_t']:.6f}", f"{t['phase']:.6f}", t["zeqond"]])

    # Write energy TSV
    if args.output_energy:
        with open(args.output_energy, "w", newline="") as f:
            w = csv.writer(f, delimiter="\t")
            w.writerow(["step", "kinetic", "potential", "total", "kinetic_tm", "potential_tm", "total_tm", "R_t_total", "phase_total", "zeqond_total"])
            for e in energy_data:
                w.writerow([e["step"],
                    f"{e['kinetic']:.6f}", f"{e['potential']:.6f}", f"{e['total']:.6f}",
                    f"{e['kinetic_tm']['modulated']:.6f}", f"{e['potential_tm']['modulated']:.6f}",
                    f"{e['total_tm']['modulated']:.6f}", f"{e['total_tm']['R_t']:.6f}",
                    f"{e['total_tm']['phase']:.6f}", e["total_tm"]["zeqond"]])

    # CKO envelope + JSON
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope
    if args.output_json:
        export = results.copy()
        if energy_data:
            export["energy_data"] = energy_data[:5] + (energy_data[-5:] if len(energy_data) > 10 else [])
        with open(args.output_json, "w") as f:
            json.dump(export, f, indent=2)

    client.daemon_tick()
    print("[Zeq OS] Time-modulation analysis complete", file=sys.stderr)


if __name__ == "__main__":
    main()
