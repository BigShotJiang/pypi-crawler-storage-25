#!/usr/bin/env python3
"""
Zeq OS — AlphaFold Structure Time-Modulation Sibling
Wraps zeq_alphafold with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to pLDDT scores and atomic coordinates via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import sys
import argparse
import json
import csv
import math
import time
import urllib.request
import urllib.error

try:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING
except ImportError:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING


AF_BASE_URL = "https://alphafold.ebi.ac.uk/files/AF-{uniprot}-F1-model_{version}.pdb"
VERSION_FALLBACK = ["v6", "v4", "v3", "v2"]


def fetch_alphafold_structure(uniprot_id):
    """Fetch AlphaFold predicted structure from EMBL-EBI AlphaFold DB."""
    for version in VERSION_FALLBACK:
        url = AF_BASE_URL.format(uniprot=uniprot_id, version=version)
        try:
            with urllib.request.urlopen(url, timeout=30) as resp:
                pdb_text = resp.read().decode()
                print(f"[Zeq OS] Successfully fetched using version {version}", file=sys.stderr)
                return pdb_text, version
        except urllib.error.HTTPError:
            continue
        except Exception as e:
            print(f"[Zeq OS] Warning: Error trying {version}: {e}", file=sys.stderr)
            continue
    print(f"[Zeq OS] ERROR: Could not fetch AlphaFold structure for {uniprot_id} (tried all versions)", file=sys.stderr)
    sys.exit(1)


def fetch_alphafold_metadata(uniprot_id):
    """Fetch pLDDT and other metadata."""
    try:
        url = f"https://alphafold.ebi.ac.uk/api/prediction/{uniprot_id}"
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[Zeq OS] Warning: Could not fetch AlphaFold metadata: {e}", file=sys.stderr)
        return {}


def parse_pdb_atoms(pdb_text):
    """Parse AlphaFold PDB to extract per-atom coordinates and pLDDT (B-factor)."""
    residues = []
    for line in pdb_text.split('\n'):
        if line.startswith('ATOM') or line.startswith('HETATM'):
            try:
                res_num = line[22:26].strip()
                x = float(line[30:38].strip())
                y = float(line[38:46].strip())
                z = float(line[46:54].strip())
                b_factor = float(line[60:66].strip())  # pLDDT in AlphaFold PDB

                residues.append({
                    'residue_number': res_num,
                    'x': x,
                    'y': y,
                    'z': z,
                    'plddt_equivalent': b_factor,
                    'distance_from_origin': math.sqrt(x*x + y*y + z*z)
                })
            except (ValueError, IndexError):
                continue
    return residues


def apply_time_modulation(values, zeq_client, domain="quantum-mechanics", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to values via single batch Zeq API call."""
    current_time = time.time()

    # Single batch API call instead of per-value loop
    modulated_vals, result = zeq_client.modulate_values(values)

    if result:
        zeq_state = result.get("zeqState", {})
        phase = zeq_state.get("phase", 0.0)
        r_t = zeq_state.get("masterSum", 1.0)
        zeqond = zeq_state.get("zeqond", 0)
        proof = result.get("zeqProof", "")
    else:
        phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
        r_t = 1.0
        zeqond = int(current_time / ZEQOND_SEC)
        proof = ""

    modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)

    modulated = []
    for i, val in enumerate(values):
        modulated.append({
            "original": val,
            "modulated": modulated_vals[i],
            "R_t": r_t,
            "phase": phase,
            "zeqond": zeqond,
            "proof": proof,
            "modulation_factor": modulation_factor
        })

    return modulated


def main():
    parser = argparse.ArgumentParser(description="Zeq OS AlphaFold Time-Modulation Sibling (HulyaPulse v1.287.110)")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--uniprot_id", required=True, help="UniProt ID (e.g., P12345)")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_residues", default=None, help="Output CSV for residue data")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    print(f"[Zeq OS] Fetching AlphaFold structure for {args.uniprot_id}...", file=sys.stderr)

    # Fetch structure and metadata
    pdb_text, version = fetch_alphafold_structure(args.uniprot_id)
    metadata = fetch_alphafold_metadata(args.uniprot_id)

    print(f"[Zeq OS] Fetched AlphaFold data for {args.uniprot_id} (version {version})", file=sys.stderr)

    results = {
        "uniprot_id": args.uniprot_id,
        "pdb_version": version,
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_sec": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Parse structure
    residues = parse_pdb_atoms(pdb_text)
    print(f"[Zeq OS] Parsed {len(residues)} atoms from PDB", file=sys.stderr)

    if residues:
        # Apply time modulation to pLDDT scores
        print(f"[Zeq OS] Applying HulyaPulse modulation to pLDDT scores...", file=sys.stderr)
        scores = [r['plddt_equivalent'] for r in residues]
        mod_scores = apply_time_modulation(scores, client, domain="quantum-mechanics", tm_steps=args.tm_steps)

        for i, r in enumerate(residues):
            r["plddt_tm"] = mod_scores[i]

        # Apply time modulation to atomic coordinates (x, y, z)
        print(f"[Zeq OS] Applying HulyaPulse modulation to atomic coordinates...", file=sys.stderr)
        all_coords = []
        for r in residues:
            all_coords.extend([r['x'], r['y'], r['z']])
        mod_coords = apply_time_modulation(all_coords, client, domain="quantum-mechanics", tm_steps=args.tm_steps)

        for i, r in enumerate(residues):
            base = i * 3
            r["x_tm"] = mod_coords[base]
            r["y_tm"] = mod_coords[base + 1]
            r["z_tm"] = mod_coords[base + 2]

        results["residues"] = residues

        # Output residue data
        if args.output_residues:
            with open(args.output_residues, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["residue_number", "x", "y", "z",
                                "x_tm", "y_tm", "z_tm",
                                "plddt_score", "plddt_tm_modulated",
                                "R_t", "phase", "zeqond", "distance_from_origin"])
                for r in residues:
                    pmod = r["plddt_tm"]
                    writer.writerow([
                        r["residue_number"],
                        f"{r['x']:.4f}",
                        f"{r['y']:.4f}",
                        f"{r['z']:.4f}",
                        f"{r['x_tm']['modulated']:.4f}",
                        f"{r['y_tm']['modulated']:.4f}",
                        f"{r['z_tm']['modulated']:.4f}",
                        f"{r['plddt_equivalent']:.1f}",
                        f"{pmod['modulated']:.1f}",
                        f"{pmod['R_t']:.6f}",
                        f"{pmod['phase']:.6f}",
                        pmod["zeqond"],
                        f"{r['distance_from_origin']:.4f}"
                    ])

    # Add metadata
    if metadata:
        results["alphafold_metadata"] = metadata

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for {args.uniprot_id}", file=sys.stderr)



if __name__ == '__main__':
    main()
