"""Zeq OS Galaxy Tools — 12 tools (6 originals + 6 TM siblings)."""
