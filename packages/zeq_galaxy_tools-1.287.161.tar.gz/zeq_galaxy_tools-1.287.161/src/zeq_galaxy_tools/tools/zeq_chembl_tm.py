#!/usr/bin/env python3
"""
Zeq OS — ChEMBL Bioactivity Time-Modulation Sibling
Wraps zeq_chembl with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to bioactivity data (IC50, EC50, Ki, pChEMBL) via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import sys
import argparse
import json
import csv
import math
import time
import urllib.request
import urllib.parse
import urllib.error

try:
    from zeq_galaxy_tools.zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING
except ImportError:
    from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING


def resolve_chembl_id(molecule_name):
    """Resolve molecule name to ChEMBL ID."""
    # Already a ChEMBL ID
    if molecule_name.upper().startswith("CHEMBL"):
        return molecule_name.upper()
    try:
        url = f"https://www.ebi.ac.uk/chembl/api/data/molecule/search.json?q={urllib.parse.quote(molecule_name)}"
        with urllib.request.urlopen(url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
            if data.get("molecules"):
                return data["molecules"][0]["molecule_chembl_id"]
            return None
    except Exception as e:
        print(f"[Zeq OS] WARNING: Could not resolve {molecule_name}: {e}", file=sys.stderr)
        return None


def fetch_bioactivity_data(chembl_id):
    """Fetch bioactivity data for a molecule from ChEMBL."""
    try:
        url = f"https://www.ebi.ac.uk/chembl/api/data/activity?molecule_chembl_id={chembl_id}&format=json&limit=1000"
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch bioactivity data for {chembl_id}: {e}", file=sys.stderr)
        sys.exit(1)


def extract_bioactivity_values(activities):
    """Extract IC50, EC50, Ki, and pChEMBL values from activity records."""
    bioactivities = []
    
    for activity in activities.get("activities", []):
        record = {
            "assay_id": activity.get("assay_chembl_id"),
            "target_id": activity.get("target_chembl_id"),
            "activity_type": activity.get("type"),
            "value": activity.get("value"),
            "unit": activity.get("unit"),
            "relation": activity.get("relation"),
            "pchembl_value": activity.get("pchembl_value"),
            "activity_comment": activity.get("activity_comment", "")
        }
        
        # Only include if we have a numeric value
        if record.get("pchembl_value"):
            bioactivities.append(record)
    
    return bioactivities


def apply_time_modulation(values, zeq_client, domain="biomedical", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to values via single batch Zeq API call."""
    current_time = time.time()

    # Single batch API call instead of per-value loop
    modulated_vals, result = zeq_client.modulate_values(values)

    # Extract shared CKO state from the batch response
    if result:
        zeq_state = result.get("zeqState", {})
        phase = zeq_state.get("phase", 0.0)
        r_t = zeq_state.get("masterSum", 1.0)
        zeqond = zeq_state.get("zeqond", 0)
        proof = result.get("zeqProof", "")
    else:
        phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
        r_t = 1.0
        zeqond = int(current_time / ZEQOND_SEC)
        proof = ""

    modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)

    modulated = []
    for i, val in enumerate(values):
        modulated.append({
            "original": val,
            "modulated": modulated_vals[i],
            "R_t": r_t,
            "phase": phase,
            "zeqond": zeqond,
            "proof": proof,
            "modulation_factor": modulation_factor
        })

    return modulated


def main():
    parser = argparse.ArgumentParser(description="Zeq OS ChEMBL Bioactivity Time-Modulation Sibling (HulyaPulse v1.287.110)")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--molecule", required=True, help="Molecule name or ChEMBL ID")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_activities", default=None, help="Output CSV for bioactivity data")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    print(f"[Zeq OS] Resolving molecule: {args.molecule}", file=sys.stderr)
    
    # Check if it's already a ChEMBL ID
    if args.molecule.startswith("CHEMBL"):
        chembl_id = args.molecule
    else:
        chembl_id = resolve_chembl_id(args.molecule)
        if not chembl_id:
            print(f"[Zeq OS] ERROR: Could not resolve {args.molecule}", file=sys.stderr)
            sys.exit(1)
    
    print(f"[Zeq OS] Resolved to ChEMBL ID: {chembl_id}", file=sys.stderr)

    results = {
        "molecule": args.molecule,
        "chembl_id": chembl_id,
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_sec": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Fetch bioactivity data
    print(f"[Zeq OS] Fetching bioactivity data for {chembl_id}...", file=sys.stderr)
    activity_data = fetch_bioactivity_data(chembl_id)
    bioactivities = extract_bioactivity_values(activity_data)
    print(f"[Zeq OS] Retrieved {len(bioactivities)} bioactivity records", file=sys.stderr)

    if bioactivities:
        # Apply time modulation to pChEMBL values
        pchembl_vals = [float(b["pchembl_value"]) for b in bioactivities if b.get("pchembl_value")]
        mod_vals = apply_time_modulation(pchembl_vals, client, domain="biomedical", tm_steps=args.tm_steps)
        
        for i, b in enumerate(bioactivities):
            if i < len(mod_vals):
                b["pchembl_tm"] = mod_vals[i]

        results["bioactivities"] = bioactivities

        # Output activities
        if args.output_activities:
            with open(args.output_activities, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["assay_id", "target_id", "activity_type", "pchembl_value",
                                "pchembl_tm_modulated", "R_t", "phase", "zeqond", "unit", "relation"])
                for b in bioactivities:
                    if "pchembl_tm" in b:
                        mod = b["pchembl_tm"]
                        writer.writerow([
                            b.get("assay_id", ""),
                            b.get("target_id", ""),
                            b.get("activity_type", ""),
                            f"{float(b.get('pchembl_value', 0)):.6f}",
                            f"{mod['modulated']:.6f}",
                            f"{mod['R_t']:.6f}",
                            f"{mod['phase']:.6f}",
                            mod["zeqond"],
                            b.get("unit", ""),
                            b.get("relation", "")
                        ])

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for {args.molecule} ({chembl_id})", file=sys.stderr)


if __name__ == "__main__":
    main()
