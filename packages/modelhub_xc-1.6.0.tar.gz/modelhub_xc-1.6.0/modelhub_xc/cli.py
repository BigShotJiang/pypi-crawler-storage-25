#!/usr/bin/env python
"""
ModelHub CLI Tool
Command-line interface for downloading models from ModelHub
"""

import argparse
import sys
from .downloader import ModelDownloader


def main():
    """CLI主函数"""
    parser = argparse.ArgumentParser(
        description='ModelHub - XC社区模型下载工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 下载完整模型库（自动识别来源）
  modelhub-xc download --model mlx-community/Qwen3-8B-bf16
  modelhub-xc download --model Tencent-Hunyuan/HY-Embodied-0.5
  modelhub-xc download --model tiiuae/falcon-7b

  # 下载单个文件到指定本地文件夹（仅支持modelhub源）
  modelhub-xc download --model mlx-community/Qwen3-8B-bf16 README.md --local_dir ./dir

  # 指定本地保存目录
  modelhub-xc download --model mlx-community/Qwen3-8B-bf16 --local_dir ./models
        '''
    )

    # 添加子命令
    subparsers = parser.add_subparsers(dest='command', help='可用命令')

    # download 子命令
    download_parser = subparsers.add_parser('download', help='下载模型')
    download_parser.add_argument(
        '--model',
        type=str,
        required=True,
        help='模型ID，例如: mlx-community/Qwen3-8B-bf16'
    )
    download_parser.add_argument(
        'files',
        nargs='*',
        help='要下载的文件列表（可选），如果不指定则下载所有文件'
    )
    download_parser.add_argument(
        '--local_dir',
        type=str,
        default=None,
        help='本地保存目录（可选），默认为 ~/.cache/modelhub-xc/models/{model_id}'
    )
    download_parser.add_argument(
        '--api-url',
        type=str,
        default='https://modelhub.org.cn/api',
        help='API基础URL（可选），默认为 https://modelhub.org.cn/api'
    )

    # 解析参数
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == 'download':
        try:
            downloader = ModelDownloader(args.api_url)

            files = args.files if args.files else None

            model_dir = downloader.download_model(
                model_id=args.model,
                local_dir=args.local_dir,
                files=files
            )

            print(f"\n✓ 下载成功!")
            print(f"模型位置: {model_dir}")
            sys.exit(0)

        except KeyboardInterrupt:
            print("\n\n用户中断下载")
            sys.exit(1)
        except Exception as e:
            print(f"\n✗ 下载失败: {str(e)}", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
