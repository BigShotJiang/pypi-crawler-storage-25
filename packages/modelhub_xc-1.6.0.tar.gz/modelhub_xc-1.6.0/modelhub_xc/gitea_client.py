"""
Gitea Repository Client
Handles file listing and downloading from Gitea repositories
"""

import os
import re
import requests
from typing import List, Dict, Any, Optional
from urllib.parse import urlparse, quote


class GiteaClient:
    """Gitea仓库客户端"""

    def __init__(self, gitea_url: str):
        """
        初始化Gitea客户端

        Args:
            gitea_url: Gitea仓库URL，例如 'https://dev.modelhub.org.cn/mlx-community/Qwen3-8B-bf16'
        """
        self.gitea_url = gitea_url.rstrip('/')
        parsed = urlparse(gitea_url)
        self.base_url = f"{parsed.scheme}://{parsed.netloc}"
        self.repo_path = parsed.path.strip('/')

        # 解析 owner 和 repo
        parts = self.repo_path.split('/')
        if len(parts) >= 2:
            self.owner = parts[0]
            self.repo = parts[1]
        else:
            raise ValueError(f"Invalid Gitea URL format: {gitea_url}")

        self.api_url = f"{self.base_url}/api/v1"

    def list_files(self, branch: str = "main", path: str = "") -> List[Dict[str, Any]]:
        """
        列出仓库中的文件

        Args:
            branch: 分支名，默认为 'main'
            path: 文件路径，默认为根目录

        Returns:
            文件列表，每个文件包含 name, path, type, size, download_url 等信息
        """
        url = f"{self.api_url}/repos/{self.owner}/{self.repo}/contents/{quote(path)}"
        params = {'ref': branch}

        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            contents = response.json()
            if not isinstance(contents, list):
                contents = [contents]

            files = []
            for item in contents:
                file_info = {
                    'name': item.get('name'),
                    'path': item.get('path'),
                    'type': item.get('type'),  # 'file' or 'dir'
                    'size': item.get('size', 0),
                    'sha': item.get('sha'),
                    'download_url': item.get('download_url'),
                }
                files.append(file_info)

            return files
        except requests.RequestException as e:
            raise Exception(f"获取文件列表失败: {str(e)}")

    def list_all_files(self, branch: str = "main") -> List[Dict[str, Any]]:
        """
        递归列出仓库中的所有文件

        Args:
            branch: 分支名，默认为 'main'

        Returns:
            所有文件列表
        """
        all_files = []

        def _recursive_list(path: str = ""):
            items = self.list_files(branch=branch, path=path)
            for item in items:
                if item['type'] == 'file':
                    all_files.append(item)
                elif item['type'] == 'dir':
                    _recursive_list(item['path'])

        _recursive_list()
        return all_files

    def download_file(self, file_path: str, local_path: str, branch: str = "main") -> str:
        """
        下载单个文件

        Args:
            file_path: 仓库中的文件路径
            local_path: 本地保存路径
            branch: 分支名

        Returns:
            下载后的本地文件路径
        """
        # 获取文件信息
        url = f"{self.api_url}/repos/{self.owner}/{self.repo}/contents/{quote(file_path)}"
        params = {'ref': branch}

        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            file_info = response.json()
            download_url = file_info.get('download_url')

            if not download_url:
                raise Exception(f"无法获取文件下载链接: {file_path}")

            # 下载文件
            return self._download_from_url(download_url, local_path)
        except requests.RequestException as e:
            raise Exception(f"下载文件失败 {file_path}: {str(e)}")

    def _download_from_url(self, url: str, local_path: str) -> str:
        """
        从URL下载文件

        Args:
            url: 下载URL
            local_path: 本地保存路径

        Returns:
            下载后的本地文件路径
        """
        # 创建目录
        os.makedirs(os.path.dirname(local_path) if os.path.dirname(local_path) else '.', exist_ok=True)

        # 下载文件
        response = requests.get(url, stream=True, timeout=60)
        response.raise_for_status()

        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0

        with open(local_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        print(f"\r下载进度: {progress:.1f}% ({downloaded}/{total_size} bytes)", end='')

        if total_size > 0:
            print()  # 换行

        return local_path

    def get_default_branch(self) -> str:
        """
        获取仓库的默认分支

        Returns:
            默认分支名
        """
        url = f"{self.api_url}/repos/{self.owner}/{self.repo}"

        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()

            repo_info = response.json()
            return repo_info.get('default_branch', 'main')
        except requests.RequestException:
            return 'main'  # 如果获取失败，默认返回 'main'
