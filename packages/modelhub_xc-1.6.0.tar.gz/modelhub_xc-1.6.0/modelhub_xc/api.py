"""
Public API for ModelHub SDK
"""

from typing import Optional, List
from .downloader import ModelDownloader


def snapshot_download(
        model_id: str,
        local_dir: Optional[str] = None,
        api_base_url: str = "https://modelhub.org.cn/api"
) -> str:
    """
    下载完整的模型快照

    Args:
        model_id: 模型ID，例如 'mlx-community/Qwen3-8B-bf16' 或 'Tencent-Hunyuan/HY-Embodied-0.5'
        local_dir: 本地保存目录，如果为None则使用默认目录 ~/.cache/modelhub-xc/models/{model_id}
        api_base_url: API基础URL，默认为 'https://modelhub.org.cn/api'

    Returns:
        下载后的本地目录路径

    Example:
        >>> from modelhub_xc import snapshot_download
        >>> # 下载模型（自动识别来源）
        >>> model_dir = snapshot_download('mlx-community/Qwen3-8B-bf16')
        >>> model_dir = snapshot_download('Tencent-Hunyuan/HY-Embodied-0.5')
        >>> model_dir = snapshot_download('tiiuae/falcon-7b')
    """
    downloader = ModelDownloader(api_base_url)
    return downloader.download_model(model_id, local_dir=local_dir)


def download_file(
        model_id: str,
        filename: str,
        local_dir: Optional[str] = None,
        api_base_url: str = "https://modelhub.org.cn/api"
) -> str:
    """
    下载模型中的单个文件

    Args:
        model_id: 模型ID，例如 'mlx-community/Qwen3-8B-bf16'
        filename: 要下载的文件名或路径，例如 'README.md'
        local_dir: 本地保存目录，如果为None则使用当前目录
        api_base_url: API基础URL

    注意: 如果模型来源是ModelScope或HuggingFace，将下载完整仓库而非单个文件

    Returns:
        下载后的本地目录路径

    Example:
        >>> from modelhub_xc import download_file
        >>> model_dir = download_file('mlx-community/Qwen3-8B-bf16', 'README.md', local_dir='./dir')
    """
    downloader = ModelDownloader(api_base_url)

    if local_dir is None:
        local_dir = '.'

    return downloader.download_model(
        model_id,
        local_dir=local_dir,
        files=[filename]
    )
