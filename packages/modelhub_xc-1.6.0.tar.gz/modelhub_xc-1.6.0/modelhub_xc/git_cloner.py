"""
Git Cloner
Handles model cloning from different sources using git
"""

import os
import subprocess
from typing import Optional


class GitCloner:
    """Git克隆器，支持ModelScope和HuggingFace，包含Git LFS支持"""

    @staticmethod
    def clone_from_modelscope(
            model_id: str,
            local_dir: str,
            branch: str = "main"
    ) -> str:
        """
        从ModelScope克隆模型

        Args:
            model_id: 模型ID，例如 'Tencent-Hunyuan/HY-Embodied-0.5'
            local_dir: 本地保存目录
            branch: 分支名，默认为 'main'

        Returns:
            克隆后的本地目录路径
        """
        # 构建ModelScope的git URL
        git_url = f"https://www.modelscope.cn/{model_id}.git"

        print(f"从 ModelScope 克隆模型: {model_id}")
        print(f"仓库地址: {git_url}")
        print(f"目标目录: {local_dir}")

        # 确保父目录存在
        parent_dir = os.path.dirname(local_dir)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        # 构建git clone命令
        cmd = ["git", "clone"]

        # 添加分支参数
        if branch and branch != "main":
            cmd.extend(["-b", branch])

        cmd.extend([git_url, local_dir])

        # 执行git clone (Git LFS会自动处理大文件)
        try:
            print("正在克隆仓库（包含大文件）...")
            result = subprocess.run(
                cmd,
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)
            print(f"克隆完成: {local_dir}")
            return local_dir
        except subprocess.CalledProcessError as e:
            error_msg = f"克隆失败: {e.stderr}"
            raise Exception(error_msg)

    @staticmethod
    def clone_from_huggingface(
            model_id: str,
            local_dir: str,
            branch: str = "main",
            hf_token: Optional[str] = None
    ) -> str:
        """
        从HuggingFace克隆模型

        Args:
            model_id: 模型ID，例如 'tiiuae/falcon-7b'
            local_dir: 本地保存目录
            branch: 分支名，默认为 'main'
            hf_token: HuggingFace token（可选）

        Returns:
            克隆后的本地目录路径
        """
        # 构建HuggingFace的git URL（使用镜像）
        git_url = f"https://hf-mirror.com/{model_id}"

        print(f"从 HuggingFace 克隆模型: {model_id}")
        print(f"仓库地址: {git_url}")
        print(f"目标目录: {local_dir}")

        # 确保父目录存在
        parent_dir = os.path.dirname(local_dir)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        # 设置环境变量（如果提供了token）
        env = os.environ.copy()
        if hf_token:
            env["HF_TOKEN"] = hf_token
            print(f"使用 HF_TOKEN 进行认证")

        # 关键：禁用git-lfs，只使用git-xet
        # HuggingFace镜像站使用git-xet，需要禁用git-lfs避免冲突
        env["GIT_LFS_SKIP_SMUDGE"] = "1"

        # 构建git clone命令
        cmd = ["git", "clone"]

        # 添加分支参数
        if branch and branch != "main":
            cmd.extend(["-b", branch])

        cmd.extend([git_url, local_dir])

        # 执行git clone（先跳过大文件）
        try:
            print("正在克隆仓库（包含大文件，使用git-xet）...")
            result = subprocess.run(
                cmd,
                env=env,
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)

            # clone完成后，使用git checkout触发xet下载大文件
            # 需要先删除GIT_LFS_SKIP_SMUDGE环境变量，让xet filter生效
            print("正在通过 git-xet 下载大文件...")

            env_for_checkout = os.environ.copy()
            if hf_token:
                env_for_checkout["HF_TOKEN"] = hf_token
            # 不设置 GIT_LFS_SKIP_SMUDGE，让 xet filter 正常工作

            # 使用 git reset --hard 重新checkout所有文件，触发xet下载
            reset_cmd = ["git", "reset", "--hard", "HEAD"]
            result_checkout = subprocess.run(
                reset_cmd,
                cwd=local_dir,
                env=env_for_checkout,
                check=True,
                capture_output=True,
                text=True
            )
            if result_checkout.stdout:
                print(result_checkout.stdout)

            print(f"克隆完成: {local_dir}")
            return local_dir
        except subprocess.CalledProcessError as e:
            error_msg = f"克隆失败: {e.stderr}"
            raise Exception(error_msg)

    @staticmethod
    def clone_model(
            model_id: str,
            source: str,
            local_dir: str,
            branch: str = "main",
            hf_token: Optional[str] = None
    ) -> str:
        """
        根据source参数克隆模型

        Args:
            model_id: 模型ID
            source: 模型源，可选值: 'ModelScope', 'HuggingFace'
            local_dir: 本地保存目录
            branch: 分支名，默认为 'main'
            hf_token: HuggingFace token（仅在source为HuggingFace时使用）

        Returns:
            克隆后的本地目录路径
        """
        if source == "ModelScope":
            return GitCloner.clone_from_modelscope(model_id, local_dir, branch)
        elif source == "HuggingFace":
            return GitCloner.clone_from_huggingface(model_id, local_dir, branch, hf_token)
        else:
            raise ValueError(f"不支持的模型源: {source}，支持的源: ModelScope, HuggingFace")
