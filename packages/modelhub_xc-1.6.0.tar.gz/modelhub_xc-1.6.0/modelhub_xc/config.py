"""
Configuration file
Stores tokens and other sensitive information
"""

# HuggingFace token for authentication
HF_TOKEN = "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"
