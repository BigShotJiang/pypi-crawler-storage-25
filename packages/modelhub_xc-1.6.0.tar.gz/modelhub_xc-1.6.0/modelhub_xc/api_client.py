"""
ModelHub API Client
Handles API requests to modelhub-xc.org.cn
"""

import requests
from typing import Dict, Any, Optional


class ModelHubAPIClient:
    """ModelHub API客户端"""

    def __init__(self, api_base_url: str = "https://modelhub.org.cn/api"):
        self.api_base_url = api_base_url.rstrip('/')

    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        通过modelId查询模型信息

        Args:
            model_id: 模型ID，例如 'mlx-community/Qwen3-8B-bf16'

        Returns:
            模型信息字典

        Raises:
            Exception: 当API请求失败时
        """
        url = f"{self.api_base_url}/computility/models/getByModelId/vo"
        params = {'modelId': model_id}

        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            data = response.json()
            if data.get('code') != 0:
                raise Exception(f"API返回错误: {data.get('message', 'Unknown error')}")

            return data.get('data', {})
        except requests.RequestException as e:
            raise Exception(f"查询模型信息失败: {str(e)}")

    def get_gitea_url(self, model_id: str) -> Optional[str]:
        """
        获取模型的Gitea URL

        Args:
            model_id: 模型ID

        Returns:
            Gitea URL或None
        """
        model_info = self.get_model_info(model_id)
        return model_info.get('giteaUrl')

    def get_model_source(self, model_id: str) -> Optional[str]:
        """
        获取模型的source信息

        Args:
            model_id: 模型ID

        Returns:
            source字符串（如 'ModelScope', 'HuggingFace'）或None
        """
        model_info = self.get_model_info(model_id)
        return model_info.get('source')
