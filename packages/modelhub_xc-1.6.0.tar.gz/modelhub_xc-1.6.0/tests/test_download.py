#!/usr/bin/env python
"""
测试脚本 - 验证不同source的下载功能
"""

from modelhub_xc import snapshot_download

def test_modelscope():
    """测试ModelScope下载"""
    print("=" * 50)
    print("测试 ModelScope 下载")
    print("=" * 50)
    try:
        model_dir = snapshot_download(
            model_id='Tencent-Hunyuan/HY-Embodied-0.5',
            local_dir='./test_models/modelscope_test'
        )
        print(f"\n✓ ModelScope 测试成功: {model_dir}")
    except Exception as e:
        print(f"\n✗ ModelScope 测试失败: {e}")

def test_huggingface():
    """测试HuggingFace下载"""
    print("\n" + "=" * 50)
    print("测试 HuggingFace 下载")
    print("=" * 50)
    try:
        model_dir = snapshot_download(
            model_id='tiiuae/falcon-7b',
            local_dir='./test_models/huggingface_test'
        )
        print(f"\n✓ HuggingFace 测试成功: {model_dir}")
    except Exception as e:
        print(f"\n✗ HuggingFace 测试失败: {e}")

def test_modelhub():
    """测试ModelHub下载"""
    print("\n" + "=" * 50)
    print("测试 ModelHub 下载")
    print("=" * 50)
    try:
        model_dir = snapshot_download(
            model_id='mlx-community/Qwen3-8B-bf16',
            local_dir='./test_models/modelhub_test'
        )
        print(f"\n✓ ModelHub 测试成功: {model_dir}")
    except Exception as e:
        print(f"\n✗ ModelHub 测试失败: {e}")

if __name__ == '__main__':
    print("开始测试 modelhub-xc 的多源下载功能\n")

    # 注意：实际测试前请确保：
    # 1. API返回的数据中包含正确的source字段
    # 2. git命令可用
    # 3. 网络连接正常

    # 可以根据需要注释掉不想测试的部分
    # test_modelscope()
    # test_huggingface()
    test_modelhub()

    print("\n" + "=" * 50)
    print("测试完成")
    print("=" * 50)
