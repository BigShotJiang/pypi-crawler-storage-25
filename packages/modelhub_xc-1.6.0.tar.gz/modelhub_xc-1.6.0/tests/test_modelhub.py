"""
Test cases for ModelHub SDK
"""

import os
import pytest
from unittest.mock import Mock, patch, MagicMock


class TestAPIClient:
    """测试API客户端"""

    @patch('modelhub_xc.api_client.requests.get')
    def test_get_model_info_success(self, mock_get):
        """测试成功获取模型信息"""
        from modelhub_xc.api_client import ModelHubAPIClient

        # 模拟API响应
        mock_response = Mock()
        mock_response.json.return_value = {
            'code': 0,
            'data': {
                'modelId': 'test/model',
                'giteaUrl': 'https://dev.modelhub.org.cn/test/model'
            }
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        client = ModelHubAPIClient()
        result = client.get_model_info('test/model')

        assert result['modelId'] == 'test/model'
        assert result['giteaUrl'] == 'https://dev.modelhub.org.cn/test/model'

    @patch('modelhub_xc.api_client.requests.get')
    def test_get_model_info_api_error(self, mock_get):
        """测试API返回错误"""
        from modelhub_xc.api_client import ModelHubAPIClient

        # 模拟API错误响应
        mock_response = Mock()
        mock_response.json.return_value = {
            'code': 1,
            'message': 'Model not found'
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        client = ModelHubAPIClient()
        with pytest.raises(Exception, match='API返回错误'):
            client.get_model_info('test/model')


class TestGiteaClient:
    """测试Gitea客户端"""

    def test_init(self):
        """测试初始化"""
        from modelhub_xc.gitea_client import GiteaClient

        client = GiteaClient('https://dev.modelhub.org.cn/test/model')
        assert client.owner == 'test'
        assert client.repo == 'model'

    @patch('modelhub_xc.gitea_client.requests.get')
    def test_list_files(self, mock_get):
        """测试列出文件"""
        from modelhub_xc.gitea_client import GiteaClient

        # 模拟Gitea API响应
        mock_response = Mock()
        mock_response.json.return_value = [
            {
                'name': 'README.md',
                'path': 'README.md',
                'type': 'file',
                'size': 1024,
                'download_url': 'https://dev.modelhub.org.cn/test/model/raw/main/README.md'
            }
        ]
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        client = GiteaClient('https://dev.modelhub.org.cn/test/model')
        files = client.list_files()

        assert len(files) == 1
        assert files[0]['name'] == 'README.md'
        assert files[0]['type'] == 'file'


class TestDownloader:
    """测试下载器"""

    @patch('modelhub_xc.downloader.ModelHubAPIClient')
    @patch('modelhub_xc.downloader.GiteaClient')
    def test_download_model(self, mock_gitea_class, mock_api_class):
        """测试下载模型"""
        from modelhub_xc.downloader import ModelDownloader

        # 模拟API客户端
        mock_api = Mock()
        mock_api.get_model_info.return_value = {
            'giteaUrl': 'https://dev.modelhub.org.cn/test/model'
        }
        mock_api_class.return_value = mock_api

        # 模拟Gitea客户端
        mock_gitea = Mock()
        mock_gitea.list_all_files.return_value = [
            {
                'name': 'README.md',
                'path': 'README.md',
                'type': 'file',
                'size': 1024
            }
        ]
        mock_gitea.download_file = Mock()
        mock_gitea.get_default_branch.return_value = 'main'
        mock_gitea_class.return_value = mock_gitea

        downloader = ModelDownloader()
        result = downloader.download_model('test/model', local_dir='/tmp/test')

        assert result == '/tmp/test'
        mock_api.get_model_info.assert_called_once_with('test/model')
        mock_gitea.list_all_files.assert_called_once()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
