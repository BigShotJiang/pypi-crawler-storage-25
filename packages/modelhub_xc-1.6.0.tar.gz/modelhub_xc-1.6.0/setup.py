import os
from setuptools import setup, find_packages

PACKAGE = 'modelhub_xc'
NAME = 'modelhub-xc'
DESCRIPTION = 'ModelHub XC Community SDK - Python library for downloading models'
AUTHOR = 'ModelHub XC Team'
AUTHOR_EMAIL = 'noreply@modelhub-xc.org.cn'
URL = 'https://modelhub.org.cn'
VERSION = '1.6.0'
REQUIRES = [
    'requests>=2.25.0',
]

LONG_DESCRIPTION = ''
if os.path.exists('./README.md'):
    with open('README.md', encoding='utf-8') as fp:
        LONG_DESCRIPTION = fp.read()

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    long_description_content_type='text/markdown',
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    license='Apache License 2.0',
    url=URL,
    keywords=['modelhub-xc', 'model', 'download', 'xc', 'ai'],
    packages=find_packages(exclude=['tests*']),
    include_package_data=True,
    platforms='any',
    install_requires=REQUIRES,
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'modelhub-xc=modelhub_xc.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: Apache Software License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
    ],
)
