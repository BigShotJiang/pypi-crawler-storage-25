from typing import Any

from fastapi import APIRouter, Depends

from pypi_tea.cache import Cache
from pypi_tea.deps import get_cache

router = APIRouter()


@router.get("/stats")
async def get_stats(
    cache: Cache = Depends(get_cache),
) -> Any:
    return await cache.get_stats()


@router.get("/stats/timeseries")
async def get_stats_timeseries(
    cache: Cache = Depends(get_cache),
) -> Any:
    return await cache.get_stats_timeseries()


@router.get("/stats/usage")
async def get_usage_stats(
    cache: Cache = Depends(get_cache),
) -> Any:
    return await cache.get_usage_stats()


@router.get("/stats/invalid-sboms")
async def get_invalid_sboms(
    cache: Cache = Depends(get_cache),
) -> Any:
    return await cache.get_invalid_sboms()
