from django.core.exceptions import ValidationError

# Names users should not be able to claim. Mirrors the spirit of
# django_registration's ReservedNameValidator. Projects can extend this
# via the UNREST_RESERVED_USERNAMES setting (which is appended to this list).
RESERVED_USERNAMES = frozenset({
    'admin', 'administrator', 'root', 'sysadmin',
    'support', 'help', 'info', 'contact', 'feedback',
    'about', 'news', 'blog', 'faq', 'terms', 'privacy', 'security',
    'abuse', 'postmaster', 'hostmaster', 'webmaster', 'noreply',
    'api', 'app', 'web', 'www', 'mail', 'email', 'ftp', 'ssh',
    'login', 'logout', 'register', 'signup', 'signin', 'signout',
    'auth', 'oauth', 'password', 'reset', 'token',
    'account', 'accounts', 'user', 'users', 'me', 'you',
    'profile', 'profiles', 'settings', 'preferences',
    'system', 'server', 'client', 'host', 'localhost',
    'anonymous', 'guest', 'staff',
    'null', 'undefined', 'true', 'false', 'none',
})


def validate_reserved_username(value):
    from django.conf import settings
    extra = {n.lower() for n in getattr(settings, 'UNREST_RESERVED_USERNAMES', [])}
    if value and value.lower() in (RESERVED_USERNAMES | extra):
        raise ValidationError(f'"{value}" is reserved and cannot be used as a username.')
