from zoneinfo import available_timezones

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models


def validate_timezone(value):
    if value not in available_timezones():
        raise ValidationError(f'Unknown timezone: {value}')


class AbstractUserSettings(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='settings',
    )
    timezone = models.CharField(max_length=64, default='UTC', validators=[validate_timezone])
    theme = models.CharField(max_length=32, default='indigo-dark')

    class Meta:
        abstract = True
