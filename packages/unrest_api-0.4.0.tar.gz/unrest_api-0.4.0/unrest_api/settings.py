"""Helpers for project settings.py.

Usage:
    from unrest_api.settings import get_secret_key
    SECRET_KEY = get_secret_key(BASE_DIR)
"""

import os

from django.core.management.utils import get_random_secret_key


def get_secret_key(base_dir, filename='.secret_key'):
    """Return the SECRET_KEY stored in BASE_DIR/.secret_key, generating one if missing."""
    path = os.path.join(str(base_dir), filename)
    if os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    key = get_random_secret_key()
    with open(path, 'w') as f:
        f.write(key)
    os.chmod(path, 0o600)
    print(f'wrote secret key to {path}')
    return key
