from django.urls import path

from . import views
from .settings_view import settings_view

urlpatterns = [
    path('register', views.register_view),
    path('login', views.login_view),
    path('logout', views.logout_view),
    path('guest', views.guest_view),
    path('me', views.me_view),
    path('settings', settings_view),
]
