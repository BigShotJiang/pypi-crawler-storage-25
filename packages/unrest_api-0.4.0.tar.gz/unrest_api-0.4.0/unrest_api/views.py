from django.contrib.auth import authenticate, get_user_model, login, logout
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from django.views.decorators.http import require_GET, require_POST

from .conf import get_guest_username, get_user_data
from .signals import guest_created, user_registered
from .validators import validate_reserved_username


@csrf_exempt
@require_POST
def register_view(request):
    User = get_user_model()
    username = request.json.get('username', '').strip()
    password = request.json.get('password', '')
    if not username or not password:
        return JsonResponse({'error': 'Username and password required'}, status=400)
    try:
        validate_reserved_username(username)
    except DjangoValidationError as exc:
        return JsonResponse({'error': exc.message}, status=400)
    if User.objects.filter(username=username).exists():
        return JsonResponse({'error': 'Username already taken'}, status=409)
    user = User.objects.create_user(username=username, password=password)
    login(request, user)
    user_registered.send(sender=User, user=user, request=request, data=request.json)
    return JsonResponse(get_user_data(user), status=201)


@csrf_exempt
@require_POST
def login_view(request):
    user = authenticate(
        request,
        username=request.json.get('username', ''),
        password=request.json.get('password', ''),
    )
    if user is None:
        return JsonResponse({'error': 'Invalid credentials'}, status=401)
    login(request, user)
    return JsonResponse(get_user_data(user))


@csrf_exempt
@require_POST
def logout_view(request):
    logout(request)
    return JsonResponse({'ok': True})


@csrf_exempt
@require_POST
def guest_view(request):
    User = get_user_model()
    for _ in range(10):
        username = get_guest_username()
        if not User.objects.filter(username=username).exists():
            break
    else:
        return JsonResponse({'error': 'Could not generate unique guest name'}, status=503)
    user = User.objects.create_user(username=username, password=None)
    user.set_unusable_password()
    user.save()
    login(request, user)
    guest_created.send(sender=User, user=user, request=request, data=request.json)
    return JsonResponse(get_user_data(user), status=201)


@ensure_csrf_cookie
@require_GET
def me_view(request):
    if request.user.is_authenticated:
        return JsonResponse(get_user_data(request.user))
    return JsonResponse({'user': None})
