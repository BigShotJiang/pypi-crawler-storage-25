from django.urls import path

from .views import schema_form

urlpatterns = [
    path('<form_class>/', schema_form),
    path('<form_class>/<int:object_id>/', schema_form),
]
