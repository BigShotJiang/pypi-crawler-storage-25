import re

FORMS = {}


def clean_form_name(name):
    name = re.sub(r'(?<!^)(?=[A-Z])', '-', name).lower()
    return re.sub(r'-form$', '', name)


def register(form=None, name=None):
    """Register a ModelForm for schema_form endpoints.

    Can be used as a plain call or as a decorator:
        register(MyForm)
        register(MyForm, name='custom-name')

        @register
        class MyForm(ModelForm): ...

        @register('custom-name')
        class MyForm(ModelForm): ...
    """
    if form is None:
        # @register() with no args
        return lambda f: register(f, name=name)
    if isinstance(form, str):
        # @register('custom-name') — form is actually the name
        return lambda f: register(f, name=form)

    form_name = clean_form_name(name or form.__name__)
    existing = FORMS.get(form_name)
    if existing is not None and existing is not form:
        raise ValueError(
            f"Cannot register {form!r} as '{form_name}': "
            f"already registered to {existing!r}"
        )
    FORMS[form_name] = form
    return form


def unregister(name):
    FORMS.pop(clean_form_name(name), None)
