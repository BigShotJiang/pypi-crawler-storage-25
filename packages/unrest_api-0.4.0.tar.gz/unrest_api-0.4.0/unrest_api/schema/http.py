from django.conf import settings
from django.core.serializers.json import DjangoJSONEncoder
from django.forms.models import ModelChoiceIteratorValue
from django.http import JsonResponse as _JsonResponse

try:
    from django.contrib.gis.geos import Point as _GISPoint
except ImportError:
    _GISPoint = None


class JsonEncoder(DjangoJSONEncoder):
    def default(self, obj):
        if isinstance(obj, ModelChoiceIteratorValue):
            return obj.value
        if _GISPoint is not None and isinstance(obj, _GISPoint):
            return list(obj)
        for type_name in getattr(settings, 'UNREST_STRING_TYPES', []):
            if obj.__class__.__name__ == type_name:
                return str(obj)
        return super().default(obj)


def JsonResponse(*args, **kwargs):
    kwargs['encoder'] = JsonEncoder
    return _JsonResponse(*args, **kwargs)
