from django import forms


class UnrestForm(forms.ModelForm):
    """ModelForm base that receives the request via constructor kwarg.

    `schema_form` always passes `request=request` when instantiating a form,
    so `self.request` is available inside `__init__` (e.g. for filtering a
    ForeignKey's queryset by user) and from `clean`/`save`.
    """

    def __init__(self, *args, request=None, **kwargs):
        self.request = request
        super().__init__(*args, **kwargs)
