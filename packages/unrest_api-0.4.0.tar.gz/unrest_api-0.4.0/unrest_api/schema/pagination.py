import math


def paginate(queryset, per_page=25, process=None, query_dict=None):
    query_dict = query_dict or {}
    page = int(query_dict.get('page', 1))
    if 'per_page' in query_dict:
        per_page = int(query_dict['per_page'])
    if per_page <= 0:
        per_page = 10**9

    total = queryset.count()
    offset = (page - 1) * per_page
    items = queryset[offset:offset + per_page]
    if process is not None:
        items = [process(i) for i in items]
    else:
        items = list(items)

    return {
        'items': items,
        'page': page,
        'pages': math.ceil(total / per_page) if per_page else 1,
        'total': total,
        'next_page': page + 1 if offset + per_page < total else None,
        'prev_page': page - 1 if page > 1 else None,
    }
