from django import forms
from django.db.models.fields.files import ImageFieldFile


FIELD_TYPE_MAP = {
    'IntegerField': 'number',
    'FloatField': 'number',
    'DecimalField': 'number',
    'BooleanField': 'checkbox',
    'NullBooleanField': 'checkbox',
    'DateField': 'date',
    'DateTimeField': 'datetime-local',
    'EmailField': 'email',
    'URLField': 'url',
    'JSONField': 'textarea',
    'SlugField': 'text',
    'FileField': 'file',
    'ImageField': 'image',
}


def field_to_formkit(name, field):
    field_type = field.__class__.__name__
    out = {'name': name, 'label': field.label or name}

    if field.help_text:
        out['help'] = str(field.help_text)

    # Choice fields
    if hasattr(field, 'choices') and field.choices:
        out['type'] = 'select'
        out['options'] = [
            {'value': value, 'label': str(label)}
            for value, label in field.choices
            if value != ''  # skip empty choice
        ]
        if not field.required:
            out['options'].insert(0, {'value': '', 'label': '---'})
        if field_type == 'TypedChoiceField':
            sample = field.coerce('1')
            if isinstance(sample, (int, float)):
                out['number'] = True
        if field_type in ('ModelChoiceField', 'TypedChoiceField'):
            out['number'] = True
        if field_type == 'ModelMultipleChoiceField':
            out['multiple'] = True
        return out

    # Widget overrides
    if isinstance(field.widget, forms.PasswordInput):
        out['type'] = 'password'
        return out
    if isinstance(field.widget, forms.HiddenInput):
        out['type'] = 'hidden'
        return out
    if isinstance(field.widget, forms.Textarea):
        out['type'] = 'textarea'
        return out

    out['type'] = FIELD_TYPE_MAP.get(field_type, 'text')

    if out['type'] == 'number':
        out['number'] = True
        if hasattr(field, 'min_value') and field.min_value is not None:
            out['min'] = field.min_value
        if hasattr(field, 'max_value') and field.max_value is not None:
            out['max'] = field.max_value

    if hasattr(field, 'max_length') and field.max_length is not None:
        out['maxlength'] = field.max_length

    return out


def form_to_schema(form):
    """Convert a Django form instance to a FormKit-compatible schema."""
    properties = {}
    required = []

    for name, field in form.fields.items():
        properties[name] = field_to_formkit(name, field)
        if field.required:
            required.append(name)

    # Populate defaults from instance
    if getattr(form, 'instance', None) and form.instance.pk:
        for name in properties:
            if name in getattr(form, 'ignore_fields', []):
                continue
            value = _get_instance_value(form, name)
            if value is not None:
                properties[name]['value'] = value

    schema = {'properties': properties, 'required': required}

    if hasattr(form, 'form_title'):
        schema['title'] = form.form_title

    if hasattr(form, 'prep_schema'):
        form.prep_schema(schema)

    return schema


def _get_instance_value(form, name):
    field = form.fields[name]
    field_type = field.__class__.__name__

    if field_type == 'ModelChoiceField':
        return getattr(form.instance, name + '_id', None)

    value = getattr(form.instance, name, None)
    if value is None:
        return None

    if isinstance(value, ImageFieldFile):
        return value.url if value else None
    if hasattr(value, 'pk'):
        return value.pk
    if field_type == 'ModelMultipleChoiceField':
        return [obj.id for obj in value.all()]

    return value
