import base64
import json

from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.forms.models import model_to_dict
from django.http import Http404

from .http import JsonResponse
from .pagination import paginate
from .registry import FORMS
from .utils import form_to_schema


_STRTOBOOL = {'true': True, '1': True, 'yes': True, 'false': False, '0': False, 'no': False}


def _strtobool(val):
    return _STRTOBOOL[str(val).lower()]


def schema_form(request, form_class, object_id=None, method=None, content_type=None, model=None):
    if isinstance(form_class, str):
        if form_class not in FORMS:
            raise Http404(f"Form '{form_class}' is not registered.")
        form_class = FORMS[form_class]

    method = method or request.method
    content_type = content_type or request.headers.get('Content-Type', '')
    _meta = getattr(form_class, 'Meta', None)
    if _meta is not None and hasattr(_meta, 'model'):
        model = _meta.model

    kwargs = {}
    if object_id is not None:
        if hasattr(form_class, 'get_one'):
            kwargs['instance'] = form_class.get_one(object_id)
        else:
            kwargs['instance'] = model.objects.get(id=object_id)

    if getattr(form_class, 'user_can_GET', None) == 'SELF' or getattr(form_class, 'user_can_PUT', None) == 'SELF':
        kwargs['instance'] = request.user

    def build_form(*args, **form_kwargs):
        return form_class(*args, request=request, **form_kwargs)

    def check_permission(permission):
        if request.user.is_superuser:
            return True
        instance = kwargs.get('instance')
        f = getattr(form_class, 'user_can_' + permission, None)
        if f == 'ALL':
            return True
        if f == 'AUTH':
            return request.user.is_authenticated
        if instance is None:
            return True
        if f == 'SELF':
            return request.user == instance
        if f == 'OWN':
            return request.user == instance.user
        if callable(f):
            return f(instance, request.user)
        return False

    def serialize(instance):
        if hasattr(instance, 'to_dict'):
            try:
                return instance.to_dict(request=request)
            except TypeError:
                return instance.to_dict()
        out = {'id': instance.id}
        form = build_form(instance=instance)
        for field_name in form.Meta.fields:
            value = getattr(instance, field_name, None)
            if hasattr(value, 'pk'):
                value = value.pk
            elif hasattr(value, 'all'):
                value = [obj.id for obj in value.all()]
            out[field_name] = value
        for field_name in getattr(form, 'readonly_fields', []):
            out[field_name] = getattr(instance, field_name)
        return out

    # --- POST / PUT ---
    if method in ('POST', 'PUT'):
        if kwargs.get('instance') is not None and not check_permission('PUT'):
            return JsonResponse({'error': 'You cannot edit this resource.'}, status=403)
        if kwargs.get('instance') is None and not check_permission('POST'):
            return JsonResponse({'error': 'You cannot create this resource.'}, status=403)
        if 'application/json' in content_type:
            data = json.loads(request.body.decode('utf-8') or '{}')
            files = {}
            for key in list(data.keys()):
                val = data[key]
                if isinstance(val, dict) and 'dataUrl' in val:
                    header, encoded = val['dataUrl'].split(',', 1)
                    files[key] = ContentFile(base64.b64decode(encoded), name=val.get('name', key))
                    del data[key]
            instance = kwargs.get('instance')
            if method == 'PUT' and instance is not None and getattr(instance, 'pk', None):
                fields = list(getattr(form_class.Meta, 'fields', []) or [])
                merged = model_to_dict(instance, fields=fields) if fields else {}
                merged.update(data)
                data = merged
            form = build_form(data, files or None, **kwargs)
        else:
            data = request.POST
            form = build_form(request.POST, request.FILES, **kwargs)
        if form.is_valid():
            instance = form.save()
            if instance is None:
                return JsonResponse({})
            return JsonResponse(serialize(instance))
        errors = {k: v[0] for k, v in form.errors.get_json_data().items()}
        return JsonResponse({'errors': errors}, status=400)

    # --- DELETE ---
    if method == 'DELETE':
        if kwargs.get('instance') is not None and check_permission('DELETE'):
            kwargs['instance'].delete()
            return JsonResponse({})
        return JsonResponse({'error': 'You cannot delete this resource.'}, status=403)

    # --- GET schema ---
    if request.GET.get('schema'):
        schema = form_to_schema(build_form(**kwargs))
        return JsonResponse({'schema': schema})

    # --- GET detail ---
    if kwargs.get('instance') is not None:
        if not check_permission('GET'):
            return JsonResponse({'error': 'You do not have access to this resource.'}, status=403)
        return JsonResponse(serialize(kwargs['instance']))

    # --- GET list ---
    if not check_permission('LIST'):
        return JsonResponse({'error': 'You do not have access to this resource.'}, status=403)
    if model.__name__ == 'User':
        model = get_user_model()

    queryset = model.objects.all()
    form = build_form()
    if hasattr(form, 'get_queryset'):
        queryset = form.get_queryset(request)

    # OWN filtering before pagination
    permission = getattr(form_class, 'user_can_LIST', None)
    if permission == 'OWN':
        queryset = queryset.filter(user=request.user)

    # Explicit filter_fields only
    for field_name in getattr(form_class, 'filter_fields', []):
        if field_name in request.GET:
            value = request.GET[field_name]
            if field_name.endswith('__isnull'):
                value = _strtobool(value)
            if field_name.endswith('__in'):
                value = request.GET.getlist(field_name)
            queryset = queryset.filter(**{field_name: value})

    return JsonResponse(paginate(queryset, process=serialize, query_dict=request.GET))
