from django.dispatch import Signal

user_registered = Signal()
guest_created = Signal()
