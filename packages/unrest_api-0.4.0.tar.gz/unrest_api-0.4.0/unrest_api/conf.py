import random

from django.conf import settings
from django.utils.module_loading import import_string

_user_data_fn = None
_guest_username_fn = None
_settings_form = None


def _default_user_data(user):
    return {'id': user.id, 'username': user.username}


def _default_guest_username():
    return f'guest-{random.randint(100000, 999999)}'


def get_user_data(user):
    global _user_data_fn
    if _user_data_fn is None:
        path = getattr(settings, 'UNREST_USER_DATA', None)
        _user_data_fn = import_string(path) if path else _default_user_data
    return _user_data_fn(user)


def get_settings_form():
    global _settings_form
    if _settings_form is None:
        path = getattr(settings, 'UNREST_USER_SETTINGS_FORM', None)
        _settings_form = import_string(path) if path else False
    return _settings_form or None


def get_guest_username():
    global _guest_username_fn
    if _guest_username_fn is None:
        path = getattr(settings, 'UNREST_GUEST_USERNAME', None)
        _guest_username_fn = import_string(path) if path else _default_guest_username
    return _guest_username_fn()
