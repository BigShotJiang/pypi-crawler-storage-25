from django.apps import AppConfig


class UnrestConfig(AppConfig):
    name = 'unrest_api'
    default_auto_field = 'django.db.models.BigAutoField'

    def ready(self):
        from django.core.management import get_commands
        get_commands()['runserver'] = 'unrest_api'
