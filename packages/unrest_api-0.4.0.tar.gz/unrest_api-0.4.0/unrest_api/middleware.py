import json

from django.conf import settings
from django.http import Http404, JsonResponse


def JsonBodyMiddleware(get_response):
    def middleware(request):
        if request.content_type == 'application/json' and request.body:
            try:
                request.json = json.loads(request.body)
            except json.JSONDecodeError:
                return JsonResponse({'error': 'Invalid JSON'}, status=400)
        else:
            request.json = {}
        return get_response(request)
    return middleware


class Json404Middleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_exception(self, request, exception):
        if not isinstance(exception, Http404):
            return None
        prefix = getattr(settings, 'UNREST_JSON_404_PREFIX', '/api/')
        if not request.path.startswith(prefix):
            return None
        return JsonResponse({'error': str(exception) or 'Not found'}, status=404)
