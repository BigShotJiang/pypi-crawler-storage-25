from django.conf import settings
from django.core.management import CommandError

try:
    from daphne.management.commands.runserver import Command as BaseCommand
except ImportError:
    try:
        from django.contrib.staticfiles.management.commands.runserver import (
            Command as BaseCommand,
        )
    except ImportError:
        from django.core.management.commands.runserver import (
            Command as BaseCommand,
        )


class Command(BaseCommand):
    default_addr = '0.0.0.0'

    @property
    def default_port(self):
        port = getattr(settings, 'UNREST_DEV_PORT', None)
        if port is None:
            raise CommandError(
                'UNREST_DEV_PORT is not set. Add UNREST_DEV_PORT = <port> to settings.py.'
            )
        return str(port)
