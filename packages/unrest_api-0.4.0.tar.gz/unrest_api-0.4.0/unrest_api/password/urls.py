from django.urls import path

from . import views

urlpatterns = [
    path(
        'reset-confirm/<uidb64>/<token>/',
        views.reset_confirm_view,
        name='password_reset_confirm',
    ),
]
