from django.apps import AppConfig


class PasswordConfig(AppConfig):
    name = 'unrest_api.password'
    label = 'unrest_api_password'
    default_auto_field = 'django.db.models.BigAutoField'

    def ready(self):
        # Import side-effect: registers PasswordResetForm and SetPasswordForm
        # with the schema registry so they're reachable via schema_form.
        from . import forms  # noqa: F401
