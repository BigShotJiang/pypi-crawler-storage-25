from django.http import HttpResponseRedirect
from django.views.decorators.http import require_GET

from .forms import get_reset_user


@require_GET
def reset_confirm_view(request, uidb64, token):
    """Validate reset link, stash token in session, redirect to SPA reset page.

    The frontend then POSTs to schema/set-password/ with the new password,
    where SetPasswordForm reads the stashed token from the session.
    """
    if not get_reset_user(uidb64, token):
        return HttpResponseRedirect('/#/reset-unsuccessful/')
    request.session['reset-uidb64'] = uidb64
    request.session['reset-token'] = token
    return HttpResponseRedirect('/#/reset/')
