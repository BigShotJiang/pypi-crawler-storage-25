from django import forms
from django.contrib.auth import get_user_model, login
from django.contrib.auth.forms import PasswordResetForm as DjangoPasswordResetForm
from django.contrib.auth.forms import SetPasswordForm as DjangoSetPasswordForm
from django.contrib.auth.tokens import default_token_generator
from django.core.exceptions import ValidationError
from django.utils.http import urlsafe_base64_decode

from ..schema import register


def get_reset_user(uidb64, token):
    User = get_user_model()
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist, ValidationError):
        return None
    if default_token_generator.check_token(user, token):
        return user
    return None


@register
class PasswordResetForm(DjangoPasswordResetForm):
    user_can_POST = 'ALL'

    def __init__(self, *args, request=None, **kwargs):
        self.request = request
        super().__init__(*args, **kwargs)

    def save(self, *args, **kwargs):
        kwargs.setdefault('request', self.request)
        return super().save(*args, **kwargs)


@register
class SetPasswordForm(DjangoSetPasswordForm):
    user_can_POST = 'ALL'

    def __init__(self, *args, request=None, **kwargs):
        self.request = request
        super().__init__(None, *args, **kwargs)
        self.fields['new_password1'].help_text = None

    def clean(self):
        uidb64 = self.request.session.get('reset-uidb64', '')
        token = self.request.session.get('reset-token', '')
        self.user = get_reset_user(uidb64, token)
        if not self.user:
            raise forms.ValidationError('This password reset token has expired.')
        return super().clean()

    def save(self, commit=True):
        user = super().save(commit)
        self.request.session.pop('reset-uidb64', None)
        self.request.session.pop('reset-token', None)
        login(self.request, user, backend='django.contrib.auth.backends.ModelBackend')
        # Return None so schema_form short-circuits to JsonResponse({}) instead
        # of trying to re-serialize via build_form(instance=user) — this form
        # is a plain forms.Form, not a ModelForm, and would reject `instance`.
        return None
