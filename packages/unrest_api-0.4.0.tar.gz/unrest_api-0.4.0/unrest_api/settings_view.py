from django.contrib.auth import get_user_model, login
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import JsonResponse

from .conf import get_settings_form
from .decorators import login_required_json
from .validators import validate_reserved_username

User = get_user_model()


def _get_settings_data(form_class, user):
    if not form_class:
        return {}, None
    obj, _ = form_class.Meta.model.objects.get_or_create(user=user)
    fields = [f for f in form_class.Meta.fields if f != 'user']
    return {f: getattr(obj, f) for f in fields}, obj


@login_required_json
def settings_view(request):
    user = request.user
    form_class = get_settings_form()

    if request.method == 'GET':
        settings_data, _ = _get_settings_data(form_class, user)
        return JsonResponse({'username': user.username, 'email': user.email, **settings_data})

    if request.method == 'PUT':
        data = request.json
        errors = {}

        if 'username' in data:
            new_username = data['username'].strip()
            if new_username and new_username != user.username:
                try:
                    validate_reserved_username(new_username)
                except DjangoValidationError as exc:
                    errors['username'] = exc.message
                else:
                    if User.objects.filter(username=new_username).exclude(pk=user.pk).exists():
                        errors['username'] = 'Username already taken'
                    else:
                        user.username = new_username
                        user.save(update_fields=['username'])

        if 'email' in data:
            new_email = data['email'].strip()
            if new_email and new_email != user.email:
                if User.objects.filter(email=new_email).exclude(pk=user.pk).exists():
                    errors['email'] = 'Another account already has that email.'
                else:
                    user.email = new_email
                    user.save(update_fields=['email'])

        if 'password' in data:
            if not user.check_password(data.get('current_password', '')):
                errors['current_password'] = 'Current password is incorrect'
            elif data['password'] != data.get('confirm_password', ''):
                errors['confirm_password'] = 'Passwords do not match'
            else:
                user.set_password(data['password'])
                user.save()
                login(request, user)

        settings_data, settings_obj = _get_settings_data(form_class, user)
        if form_class and settings_obj:
            fields = [f for f in form_class.Meta.fields if f != 'user']
            changed = [f for f in fields if f in data]
            if changed:
                for f in changed:
                    setattr(settings_obj, f, data[f])
                settings_obj.save(update_fields=changed)
                settings_data = {f: getattr(settings_obj, f) for f in fields}

        if errors:
            return JsonResponse({'errors': errors}, status=400)
        return JsonResponse({'username': user.username, 'email': user.email, **settings_data})

    return JsonResponse({'error': 'Method not allowed'}, status=405)
