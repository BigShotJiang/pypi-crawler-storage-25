from django.apps import AppConfig


class NopassConfig(AppConfig):
    name = 'unrest_api.nopass'
    label = 'nopass'
    default_auto_field = 'django.db.models.BigAutoField'
