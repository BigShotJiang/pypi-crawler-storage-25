import random

from django.contrib.auth import get_user_model, login
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.tokens import default_token_generator
from django.core.exceptions import ValidationError
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.urls import reverse
from django.utils.http import urlsafe_base64_decode
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST


def _get_user(uidb64):
    User = get_user_model()
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        return User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist, ValidationError):
        return None


@require_GET
def bad_token(request):
    message = 'The link you are using is invalid or expired. Please try again.'
    return HttpResponse(f'<h1>Bad Token</h1><p>{message}</p>')


@csrf_exempt
@require_POST
def create(request):
    User = get_user_model()
    email = request.json.get('email') or None
    if email and User.objects.filter(email=email).exists():
        return JsonResponse({'error': 'An account with that email already exists.'}, status=409)
    username = email
    while not username or User.objects.filter(username=username).exists():
        _hash = '{:032x}'.format(random.getrandbits(128))
        username = f'guest-{_hash[:8]}'
        email = f'{username}@example.com'
    user = User.objects.create(username=username, email=email)
    user.set_unusable_password()
    user.save()
    user.backend = 'django.contrib.auth.backends.ModelBackend'
    login(request, user)
    return JsonResponse({'status': 'ok'})


@csrf_exempt
@require_POST
def change_email(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required'}, status=401)
    email = request.json.get('email')
    if not email:
        return JsonResponse({'error': 'Email is required'}, status=400)
    User = get_user_model()
    if User.objects.exclude(id=request.user.id).filter(email=email).exists():
        return JsonResponse({'error': 'Another account already has that email.'}, status=400)
    user = request.user
    user.email = user.username = email
    user.save()
    return JsonResponse({'success': 'Email address updated'})


@csrf_exempt
@require_POST
def send(request):
    form = PasswordResetForm(request.json)
    if form.is_valid():
        form.save(
            request=request,
            subject_template_name='email/nopass/subject.txt',
            email_template_name='email/nopass/body.txt',
        )
        return JsonResponse({'success': 'Please check your email for a login link.'})
    return JsonResponse({'errors': {k: v[0] for k, v in form.errors.get_json_data().items()}}, status=400)


@require_GET
def complete_login(request, uidb64, token):
    redirect_url = '/'
    if request.user.is_authenticated:
        return HttpResponseRedirect(redirect_url)
    user = _get_user(uidb64)
    if user and default_token_generator.check_token(user, token):
        user.backend = 'django.contrib.auth.backends.ModelBackend'
        login(request, user)
        # forces password change on next login attempt
        user.set_unusable_password()
        user.save()
    else:
        redirect_url = reverse('nopass_bad_token')
    return HttpResponseRedirect(redirect_url)
