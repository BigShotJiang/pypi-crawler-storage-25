# unrest_api

Lightweight Django utilities for building JSON APIs - schema-driven form views, auth endpoints, user-settings scaffolding, and helpful middleware.

## Install

```bash
pip install unrest_api
```

Add to `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # ...
    "unrest_api",
]
```

## Features

- **`unrest_api.schema.schema_form`** — turn a `ModelForm` into a JSON CRUD endpoint (GET schema, POST create, PUT partial update, DELETE).
- **`unrest_api.schema.UnrestForm`** — `ModelForm` base that exposes `self.request` so `__init__`, `clean`, and `save` can scope querysets and defaults to the current user.
- **`unrest_api.urls`** — drop-in auth routes (`login`, `logout`, `register`, `settings`).
- **`unrest_api.models.AbstractUserSettings`** — abstract base providing `timezone` and `theme` plus the `OneToOneField` to `AUTH_USER_MODEL` (`related_name='settings'`).
- **`unrest_api.middleware.Json404Middleware`** — converts `Http404` raised under an API prefix into `JsonResponse({'error': ...}, status=404)`.

## Quick start

```python
# urls.py
from django.urls import include, path

urlpatterns = [
    path("api/auth/", include("unrest_api.urls")),
]
```

```python
# forms.py
from unrest_api.schema import UnrestForm, register
from .models import Widget

@register
class WidgetForm(UnrestForm):
    class Meta:
        model = Widget
        fields = ["name", "color"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # self.request is available here
```

## Settings

| Setting | Default | Description |
| --- | --- | --- |
| `UNREST_USER_SETTINGS_FORM` | `None` | Dotted path to a `ModelForm` for project-specific fields exposed by the unified `settings` endpoint. |
| `UNREST_JSON_404_PREFIX` | `"/api/"` | URL prefix under which `Json404Middleware` converts `Http404` to JSON. |

## Compatibility

- Python 3.11+
- Django 5.2+

## Changelog

See [CHANGELOG.md](CHANGELOG.md).

## License

MIT
