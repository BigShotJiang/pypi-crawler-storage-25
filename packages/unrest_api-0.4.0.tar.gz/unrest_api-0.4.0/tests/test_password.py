import json

from django.core import mail
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode

from unrest_api.password.forms import get_reset_user


def test_get_reset_user_valid(user):
    uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    assert get_reset_user(uidb64, token) == user


def test_get_reset_user_bad_token(user):
    uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
    assert get_reset_user(uidb64, 'bogus') is None


def test_get_reset_user_unknown_uid():
    assert get_reset_user('!!bad!!', 'x') is None


class TestResetConfirmView:
    def test_valid_link_stashes_session_and_redirects(self, anon_client, user):
        uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        response = anon_client.get(f'/api/password/reset-confirm/{uidb64}/{token}/')
        assert response.status_code == 302
        assert response['Location'] == '/#/reset/'
        assert anon_client.session['reset-uidb64'] == uidb64
        assert anon_client.session['reset-token'] == token

    def test_bad_link_redirects_to_unsuccessful(self, anon_client, user):
        uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
        response = anon_client.get(f'/api/password/reset-confirm/{uidb64}/bad/')
        assert response.status_code == 302
        assert response['Location'] == '/#/reset-unsuccessful/'


class TestPasswordResetSchemaForm:
    """End-to-end through the schema registry: schema/password-reset/ + schema/set-password/."""

    def test_reset_request_sends_email(self, anon_client, user):
        response = anon_client.post(
            '/api/schema/password-reset/',
            json.dumps({'email': user.email}),
            content_type='application/json',
        )
        assert response.status_code == 200
        assert len(mail.outbox) == 1
        assert user.email in mail.outbox[0].to

    def test_reset_request_invalid_email(self, anon_client):
        response = anon_client.post(
            '/api/schema/password-reset/',
            json.dumps({'email': 'not-an-email'}),
            content_type='application/json',
        )
        assert response.status_code == 400

    def test_set_password_with_valid_token(self, anon_client, user):
        uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        anon_client.get(f'/api/password/reset-confirm/{uidb64}/{token}/')
        response = anon_client.post(
            '/api/schema/set-password/',
            json.dumps({'new_password1': 'newpw98765', 'new_password2': 'newpw98765'}),
            content_type='application/json',
        )
        assert response.status_code == 200, response.content
        user.refresh_from_db()
        assert user.check_password('newpw98765')
        assert 'reset-uidb64' not in anon_client.session

    def test_set_password_without_session_token(self, anon_client):
        response = anon_client.post(
            '/api/schema/set-password/',
            json.dumps({'new_password1': 'newpw98765', 'new_password2': 'newpw98765'}),
            content_type='application/json',
        )
        assert response.status_code == 400
