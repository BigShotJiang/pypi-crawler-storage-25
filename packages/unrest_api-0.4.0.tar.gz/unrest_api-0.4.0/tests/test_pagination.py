import pytest

from tests.testapp.models import Widget
from unrest_api.pagination import paginate


@pytest.fixture
def widgets(db, django_user_model):
    owner = django_user_model.objects.create_user(username='o', password='p')
    return [Widget.objects.create(name=f'w{i}', owner=owner) for i in range(7)]


def test_default_page(widgets):
    result = paginate(Widget.objects.order_by('id'))
    assert result['total'] == 7
    assert result['page'] == 1
    assert result['pages'] == 1
    assert result['next_page'] is None
    assert result['prev_page'] is None
    assert len(result['items']) == 7


def test_per_page_and_paging(widgets):
    p1 = paginate(Widget.objects.order_by('id'), query_dict={'per_page': '3'})
    assert p1['pages'] == 3
    assert p1['next_page'] == 2
    assert p1['prev_page'] is None
    assert len(p1['items']) == 3

    p2 = paginate(Widget.objects.order_by('id'), query_dict={'per_page': '3', 'page': '2'})
    assert p2['next_page'] == 3
    assert p2['prev_page'] == 1

    p3 = paginate(Widget.objects.order_by('id'), query_dict={'per_page': '3', 'page': '3'})
    assert p3['next_page'] is None
    assert p3['prev_page'] == 2
    assert len(p3['items']) == 1


def test_process_callback(widgets):
    result = paginate(Widget.objects.order_by('id'), query_dict={'per_page': '2'}, process=lambda w: w.name)
    assert result['items'] == ['w0', 'w1']


def test_per_page_zero_returns_everything(widgets):
    result = paginate(Widget.objects.order_by('id'), query_dict={'per_page': '0'})
    assert result['total'] == 7
    assert len(result['items']) == 7
    assert result['next_page'] is None
