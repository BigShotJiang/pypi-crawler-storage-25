import pytest
from django import forms

from unrest_api.schema.registry import FORMS, clean_form_name, register, unregister


def test_clean_form_name_strips_form_suffix_and_kebab_cases():
    assert clean_form_name('WidgetForm') == 'widget'
    assert clean_form_name('MyCoolThing') == 'my-cool-thing'
    assert clean_form_name('PasswordResetForm') == 'password-reset'


def test_register_decorator_adds_to_FORMS():
    class TempForm(forms.Form):
        pass
    register(TempForm)
    try:
        assert FORMS['temp'] is TempForm
    finally:
        unregister('temp')
        assert 'temp' not in FORMS


def test_register_with_custom_name():
    class XForm(forms.Form):
        pass
    register(XForm, name='custom-x')
    try:
        assert FORMS['custom-x'] is XForm
    finally:
        unregister('custom-x')


def test_register_decorator_with_string_arg():
    @register('aliased-thing')
    class YForm(forms.Form):
        pass
    try:
        assert FORMS['aliased-thing'] is YForm
    finally:
        unregister('aliased-thing')


def test_register_collision_raises():
    class A(forms.Form):
        pass

    class B(forms.Form):
        pass
    register(A, name='dup')
    try:
        with pytest.raises(ValueError):
            register(B, name='dup')
    finally:
        unregister('dup')


def test_register_idempotent_on_same_class():
    class Z(forms.Form):
        pass
    register(Z, name='z-once')
    try:
        register(Z, name='z-once')  # should not raise
        assert FORMS['z-once'] is Z
    finally:
        unregister('z-once')
