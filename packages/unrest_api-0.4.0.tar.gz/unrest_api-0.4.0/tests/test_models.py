import pytest
from django.core.exceptions import ValidationError

from unrest_api.models import validate_timezone


def test_validate_timezone_accepts_iana_name():
    validate_timezone('America/New_York')
    validate_timezone('UTC')


def test_validate_timezone_rejects_unknown():
    with pytest.raises(ValidationError):
        validate_timezone('Mars/OlympusMons')
