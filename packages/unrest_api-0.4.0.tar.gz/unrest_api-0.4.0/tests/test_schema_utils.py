from django import forms

from tests.testapp.models import Widget, WidgetWithUser
from unrest_api.schema.forms import UnrestForm
from unrest_api.schema.utils import field_to_formkit, form_to_schema


class _PlainForm(forms.Form):
    name = forms.CharField(max_length=20, label='Name', help_text='your name')
    age = forms.IntegerField(min_value=0, max_value=120, required=False)
    bio = forms.CharField(widget=forms.Textarea, required=False)
    secret = forms.CharField(widget=forms.PasswordInput)
    hidden = forms.CharField(widget=forms.HiddenInput)
    color = forms.ChoiceField(choices=[('r', 'Red'), ('b', 'Blue')], required=False)
    score = forms.TypedChoiceField(choices=[('1', 'one'), ('2', 'two')], coerce=int)
    is_on = forms.BooleanField(required=False)


def test_field_to_formkit_text_with_maxlength_and_help():
    out = field_to_formkit('name', _PlainForm().fields['name'])
    assert out == {'name': 'name', 'label': 'Name', 'help': 'your name', 'type': 'text', 'maxlength': 20}


def test_field_to_formkit_number_min_max():
    out = field_to_formkit('age', _PlainForm().fields['age'])
    assert out['type'] == 'number'
    assert out['number'] is True
    assert out['min'] == 0 and out['max'] == 120


def test_field_to_formkit_textarea():
    assert field_to_formkit('bio', _PlainForm().fields['bio'])['type'] == 'textarea'


def test_field_to_formkit_password():
    assert field_to_formkit('secret', _PlainForm().fields['secret'])['type'] == 'password'


def test_field_to_formkit_hidden():
    assert field_to_formkit('hidden', _PlainForm().fields['hidden'])['type'] == 'hidden'


def test_field_to_formkit_choices_inserts_blank_when_optional():
    out = field_to_formkit('color', _PlainForm().fields['color'])
    assert out['type'] == 'select'
    assert out['options'][0] == {'value': '', 'label': '---'}
    assert {o['value'] for o in out['options']} == {'', 'r', 'b'}


def test_field_to_formkit_typed_choice_coerces_to_number():
    out = field_to_formkit('score', _PlainForm().fields['score'])
    assert out['type'] == 'select'
    assert out['number'] is True


def test_field_to_formkit_boolean():
    out = field_to_formkit('is_on', _PlainForm().fields['is_on'])
    assert out['type'] == 'checkbox'


class _WidgetForm(UnrestForm):
    form_title = 'Widget Editor'
    ignore_fields = ['note']

    class Meta:
        model = Widget
        fields = ['name', 'owner', 'is_public', 'note']


def test_form_to_schema_lists_required(db):
    schema = form_to_schema(_WidgetForm())
    assert set(schema['properties'].keys()) == {'name', 'owner', 'is_public', 'note'}
    assert 'name' in schema['required']
    assert 'owner' in schema['required']
    assert 'is_public' not in schema['required']  # BooleanField is optional


def test_form_to_schema_includes_form_title(db):
    assert form_to_schema(_WidgetForm())['title'] == 'Widget Editor'


def test_form_to_schema_populates_instance_values(db, user):
    widget = Widget.objects.create(name='hello', owner=user, is_public=True, note='n')
    schema = form_to_schema(_WidgetForm(instance=widget))
    props = schema['properties']
    assert props['name']['value'] == 'hello'
    assert props['is_public']['value'] is True
    # ModelChoiceField returns the FK pk
    assert props['owner']['value'] == user.pk
    # ignore_fields skipped
    assert 'value' not in props['note']


def test_form_to_schema_calls_prep_schema_hook(db):
    class _F(_WidgetForm):
        def prep_schema(self, schema):
            schema['custom'] = 'yes'

    assert form_to_schema(_F())['custom'] == 'yes'


class _MultiForm(UnrestForm):
    class Meta:
        model = WidgetWithUser
        fields = ['name', 'user']


def test_form_to_schema_modelchoice_marked_number(db):
    schema = form_to_schema(_MultiForm())
    assert schema['properties']['user']['type'] == 'select'
    assert schema['properties']['user']['number'] is True
