import json

from django.contrib.auth.tokens import default_token_generator
from django.core import mail
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode


class TestCreate:
    def test_create_with_email(self, anon_client, db, User):
        response = anon_client.post('/api/nopass/create/', json.dumps({'email': 'fresh@x.com'}), content_type='application/json')
        assert response.status_code == 200
        assert User.objects.filter(email='fresh@x.com').exists()

    def test_create_without_email_generates_guest(self, anon_client, db, User):
        response = anon_client.post('/api/nopass/create/', json.dumps({}), content_type='application/json')
        assert response.status_code == 200
        assert User.objects.filter(username__startswith='guest-').exists()

    def test_create_dedup_email_returns_409(self, anon_client, user):
        response = anon_client.post('/api/nopass/create/', json.dumps({'email': user.email}), content_type='application/json')
        assert response.status_code == 409


class TestChangeEmail:
    def test_anon_401(self, anon_client):
        response = anon_client.post('/api/nopass/change_email/', json.dumps({'email': 'x@y.com'}), content_type='application/json')
        assert response.status_code == 401

    def test_authed_updates(self, auth_client, user):
        response = auth_client.post('/api/nopass/change_email/', json.dumps({'email': 'new@x.com'}), content_type='application/json')
        assert response.status_code == 200
        user.refresh_from_db()
        assert user.email == 'new@x.com'

    def test_missing_email_400(self, auth_client):
        response = auth_client.post('/api/nopass/change_email/', json.dumps({}), content_type='application/json')
        assert response.status_code == 400

    def test_taken_email_400(self, auth_client, other_user):
        response = auth_client.post('/api/nopass/change_email/', json.dumps({'email': other_user.email}), content_type='application/json')
        assert response.status_code == 400


class TestSend:
    def test_sends_email(self, anon_client, user):
        response = anon_client.post('/api/nopass/send/', json.dumps({'email': user.email}), content_type='application/json')
        assert response.status_code == 200
        assert len(mail.outbox) == 1
        assert user.email in mail.outbox[0].to

    def test_invalid_email_400(self, anon_client):
        response = anon_client.post('/api/nopass/send/', json.dumps({'email': 'not-an-email'}), content_type='application/json')
        assert response.status_code == 400


class TestCompleteLogin:
    def test_valid_token_logs_in(self, anon_client, user):
        uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        response = anon_client.get(f'/api/nopass/{uidb64}/{token}/')
        assert response.status_code == 302
        assert response['Location'] == '/'

    def test_bad_token_redirects_to_bad_token_view(self, anon_client, user):
        uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
        response = anon_client.get(f'/api/nopass/{uidb64}/bad-token/')
        assert response.status_code == 302
        assert 'bad_token' in response['Location']

    def test_bad_token_view(self, anon_client):
        response = anon_client.get('/api/nopass/bad_token/')
        assert response.status_code == 200
        assert b'Bad Token' in response.content
