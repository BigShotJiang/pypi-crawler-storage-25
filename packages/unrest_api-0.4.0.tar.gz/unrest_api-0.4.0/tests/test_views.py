import json

import pytest
from django.test import override_settings


def post(client, path, body):
    return client.post(path, json.dumps(body), content_type='application/json')


class TestRegister:
    def test_creates_user_and_logs_in(self, anon_client, db, User):
        response = post(anon_client, '/api/auth/register', {'username': 'newbie', 'password': 'pw12345'})
        assert response.status_code == 201
        assert User.objects.filter(username='newbie').exists()
        # logged in: subsequent /me returns the user
        me = anon_client.get('/api/auth/me')
        assert me.json()['username'] == 'newbie'

    def test_missing_fields_400(self, anon_client, db):
        assert post(anon_client, '/api/auth/register', {}).status_code == 400
        assert post(anon_client, '/api/auth/register', {'username': 'x'}).status_code == 400
        assert post(anon_client, '/api/auth/register', {'password': 'p'}).status_code == 400

    def test_reserved_username_400(self, anon_client, db):
        response = post(anon_client, '/api/auth/register', {'username': 'admin', 'password': 'pw'})
        assert response.status_code == 400
        assert 'reserved' in response.json()['error'].lower()

    def test_dup_username_409(self, anon_client, user):
        response = post(anon_client, '/api/auth/register', {'username': user.username, 'password': 'pw'})
        assert response.status_code == 409


class TestLogin:
    def test_valid_credentials(self, anon_client, user):
        response = post(anon_client, '/api/auth/login', {'username': user.username, 'password': 'pw'})
        assert response.status_code == 200
        assert response.json()['username'] == user.username

    def test_bad_credentials_401(self, anon_client, user):
        response = post(anon_client, '/api/auth/login', {'username': user.username, 'password': 'wrong'})
        assert response.status_code == 401


class TestLogout:
    def test_logout_clears_session(self, auth_client):
        response = post(auth_client, '/api/auth/logout', {})
        assert response.status_code == 200
        me = auth_client.get('/api/auth/me')
        assert me.json() == {'user': None}


class TestGuest:
    def test_creates_guest_user(self, anon_client, db, User):
        before = User.objects.count()
        response = post(anon_client, '/api/auth/guest', {})
        assert response.status_code == 201
        assert User.objects.count() == before + 1
        # logged in
        assert anon_client.get('/api/auth/me').json()['id'] == response.json()['id']


class TestMe:
    def test_anon(self, anon_client):
        assert anon_client.get('/api/auth/me').json() == {'user': None}

    def test_authed(self, auth_client, user):
        data = auth_client.get('/api/auth/me').json()
        assert data['username'] == user.username

    def test_sets_csrf_cookie(self, anon_client):
        response = anon_client.get('/api/auth/me')
        assert 'csrftoken' in response.cookies


def _custom_user_data(user):
    return {'id': user.id, 'is_staff': user.is_staff, 'flagged': True}


class TestUserDataOverride:
    @pytest.fixture(autouse=True)
    def _reset_conf(self):
        from unrest_api import conf
        conf._user_data_fn = None
        yield
        conf._user_data_fn = None

    @override_settings(UNREST_USER_DATA='tests.test_views._custom_user_data')
    def test_uses_configured_user_data(self, auth_client, user):
        data = auth_client.get('/api/auth/me').json()
        assert data['flagged'] is True
        assert 'username' not in data
