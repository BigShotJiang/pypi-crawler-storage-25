import json

from django.contrib.auth.models import AnonymousUser
from django.http import JsonResponse
from django.test import RequestFactory

from unrest_api.decorators import login_required_json


@login_required_json
def view(request):
    return JsonResponse({'ok': True})


def test_anon_returns_401():
    request = RequestFactory().get('/')
    request.user = AnonymousUser()
    response = view(request)
    assert response.status_code == 401
    assert json.loads(response.content) == {'error': 'Authentication required'}


def test_authed_passes_through(db, django_user_model):
    user = django_user_model.objects.create_user(username='x', password='p')
    request = RequestFactory().get('/')
    request.user = user
    response = view(request)
    assert response.status_code == 200
    assert json.loads(response.content) == {'ok': True}
