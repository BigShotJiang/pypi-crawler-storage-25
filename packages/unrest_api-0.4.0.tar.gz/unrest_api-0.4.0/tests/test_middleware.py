import json

import pytest
from django.http import Http404, JsonResponse
from django.test import RequestFactory, override_settings

from unrest_api.middleware import Json404Middleware, JsonBodyMiddleware


@pytest.fixture
def rf():
    return RequestFactory()


def _ok(request):
    return JsonResponse({'json': getattr(request, 'json', None)})


class TestJsonBodyMiddleware:
    def test_parses_json_body(self, rf):
        mw = JsonBodyMiddleware(_ok)
        request = rf.post('/x', data=json.dumps({'a': 1}), content_type='application/json')
        response = mw(request)
        assert response.status_code == 200
        assert json.loads(response.content) == {'json': {'a': 1}}

    def test_invalid_json_returns_400(self, rf):
        mw = JsonBodyMiddleware(_ok)
        request = rf.post('/x', data='{bad', content_type='application/json')
        response = mw(request)
        assert response.status_code == 400
        assert json.loads(response.content) == {'error': 'Invalid JSON'}

    def test_non_json_sets_empty_dict(self, rf):
        mw = JsonBodyMiddleware(_ok)
        request = rf.post('/x', data={'a': 1})
        response = mw(request)
        assert json.loads(response.content) == {'json': {}}

    def test_empty_json_body_sets_empty_dict(self, rf):
        mw = JsonBodyMiddleware(_ok)
        request = rf.post('/x', data='', content_type='application/json')
        response = mw(request)
        assert json.loads(response.content) == {'json': {}}


class TestJson404Middleware:
    def test_converts_http404_under_api_prefix(self, rf):
        mw = Json404Middleware(_ok)
        request = rf.get('/api/missing')
        response = mw.process_exception(request, Http404('gone'))
        assert response.status_code == 404
        assert json.loads(response.content) == {'error': 'gone'}

    def test_default_message_when_blank(self, rf):
        mw = Json404Middleware(_ok)
        request = rf.get('/api/missing')
        response = mw.process_exception(request, Http404())
        assert json.loads(response.content) == {'error': 'Not found'}

    def test_skips_non_api_paths(self, rf):
        mw = Json404Middleware(_ok)
        request = rf.get('/admin/missing')
        assert mw.process_exception(request, Http404()) is None

    def test_skips_non_http404(self, rf):
        mw = Json404Middleware(_ok)
        request = rf.get('/api/x')
        assert mw.process_exception(request, ValueError('x')) is None

    @override_settings(UNREST_JSON_404_PREFIX='/v1/')
    def test_custom_prefix(self, rf):
        mw = Json404Middleware(_ok)
        assert mw.process_exception(rf.get('/v1/x'), Http404()).status_code == 404
        assert mw.process_exception(rf.get('/api/x'), Http404()) is None
