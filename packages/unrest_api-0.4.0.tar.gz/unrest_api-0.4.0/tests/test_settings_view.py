import json

from tests.testapp.models import UserSettings


class TestGet:
    def test_anon_401(self, anon_client):
        response = anon_client.get('/api/auth/settings')
        assert response.status_code == 401

    def test_returns_user_and_settings(self, auth_client, user):
        response = auth_client.get('/api/auth/settings')
        assert response.status_code == 200
        data = response.json()
        assert data['username'] == user.username
        assert data['email'] == user.email
        assert data['timezone'] == 'UTC'
        assert data['theme'] == 'indigo-dark'
        assert data['nickname'] == ''
        assert UserSettings.objects.filter(user=user).exists()


class TestPut:
    def test_update_username(self, auth_client, user):
        response = auth_client.put('/api/auth/settings', json.dumps({'username': 'alice2'}), content_type='application/json')
        assert response.status_code == 200, response.content
        user.refresh_from_db()
        assert user.username == 'alice2'

    def test_reserved_username_rejected(self, auth_client, user):
        response = auth_client.put('/api/auth/settings', json.dumps({'username': 'admin'}), content_type='application/json')
        assert response.status_code == 400
        assert 'username' in response.json()['errors']

    def test_taken_username_rejected(self, auth_client, user, other_user):
        response = auth_client.put('/api/auth/settings', json.dumps({'username': other_user.username}), content_type='application/json')
        assert response.status_code == 400
        assert response.json()['errors']['username'] == 'Username already taken'

    def test_update_email(self, auth_client, user):
        response = auth_client.put('/api/auth/settings', json.dumps({'email': 'new@x.com'}), content_type='application/json')
        assert response.status_code == 200
        user.refresh_from_db()
        assert user.email == 'new@x.com'

    def test_taken_email_rejected(self, auth_client, user, other_user):
        response = auth_client.put('/api/auth/settings', json.dumps({'email': other_user.email}), content_type='application/json')
        assert response.status_code == 400
        assert 'email' in response.json()['errors']

    def test_password_change_happy(self, auth_client, user):
        body = {'password': 'newpw123', 'confirm_password': 'newpw123', 'current_password': 'pw'}
        response = auth_client.put('/api/auth/settings', json.dumps(body), content_type='application/json')
        assert response.status_code == 200
        user.refresh_from_db()
        assert user.check_password('newpw123')

    def test_password_wrong_current(self, auth_client, user):
        body = {'password': 'newpw123', 'confirm_password': 'newpw123', 'current_password': 'WRONG'}
        response = auth_client.put('/api/auth/settings', json.dumps(body), content_type='application/json')
        assert response.status_code == 400
        assert 'current_password' in response.json()['errors']

    def test_password_mismatch(self, auth_client, user):
        body = {'password': 'a', 'confirm_password': 'b', 'current_password': 'pw'}
        response = auth_client.put('/api/auth/settings', json.dumps(body), content_type='application/json')
        assert response.status_code == 400
        assert 'confirm_password' in response.json()['errors']

    def test_update_settings_field(self, auth_client, user):
        body = {'nickname': 'Ali', 'theme': 'sunset'}
        response = auth_client.put('/api/auth/settings', json.dumps(body), content_type='application/json')
        assert response.status_code == 200
        s = UserSettings.objects.get(user=user)
        assert s.nickname == 'Ali'
        assert s.theme == 'sunset'

    def test_method_not_allowed(self, auth_client):
        response = auth_client.delete('/api/auth/settings')
        assert response.status_code == 405
