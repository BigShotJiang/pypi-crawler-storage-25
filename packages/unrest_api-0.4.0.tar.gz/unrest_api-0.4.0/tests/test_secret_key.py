import os
import stat

from unrest_api.settings import get_secret_key


def test_generates_and_writes_key(tmp_path, capsys):
    key = get_secret_key(tmp_path)
    assert isinstance(key, str)
    assert len(key) >= 50
    written = (tmp_path / '.secret_key').read_text().strip()
    assert written == key
    # printed notice on first generation
    assert '.secret_key' in capsys.readouterr().out


def test_reads_existing_key(tmp_path):
    (tmp_path / '.secret_key').write_text('existing-key\n')
    assert get_secret_key(tmp_path) == 'existing-key'


def test_custom_filename(tmp_path):
    get_secret_key(tmp_path, filename='.other')
    assert (tmp_path / '.other').exists()


def test_chmod_600(tmp_path):
    get_secret_key(tmp_path)
    mode = stat.S_IMODE(os.stat(tmp_path / '.secret_key').st_mode)
    assert mode == 0o600
