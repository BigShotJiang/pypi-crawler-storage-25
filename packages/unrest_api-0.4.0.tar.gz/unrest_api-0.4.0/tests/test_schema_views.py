import json

import pytest

from tests.testapp.models import Widget, WidgetWithUser


@pytest.fixture
def widget(user):
    return Widget.objects.create(name='hello', owner=user, is_public=True)


class TestGet:
    def test_get_schema(self, anon_client, widget):
        response = anon_client.get('/api/schema/widget/', {'schema': '1'})
        assert response.status_code == 200
        data = response.json()
        assert 'schema' in data
        assert {p['name'] for p in data['schema']['properties'].values()} == {'name', 'owner', 'is_public', 'note'}

    def test_get_detail(self, anon_client, widget):
        response = anon_client.get(f'/api/schema/widget/{widget.id}/')
        assert response.status_code == 200
        data = response.json()
        assert data['id'] == widget.id
        assert data['name'] == 'hello'
        assert data['is_public'] is True

    def test_get_list(self, anon_client, user):
        Widget.objects.create(name='a', owner=user, is_public=True)
        Widget.objects.create(name='b', owner=user, is_public=False)
        response = anon_client.get('/api/schema/widget/')
        data = response.json()
        assert data['total'] == 2
        assert {item['name'] for item in data['items']} == {'a', 'b'}

    def test_filter_fields_bool(self, anon_client, user):
        Widget.objects.create(name='pub', owner=user, is_public=True)
        Widget.objects.create(name='priv', owner=user, is_public=False)
        response = anon_client.get('/api/schema/widget/', {'is_public': 'True'})
        items = response.json()['items']
        assert {i['name'] for i in items} == {'pub'}

    def test_filter_fields_in(self, anon_client, user):
        for n in ['a', 'b', 'c']:
            Widget.objects.create(name=n, owner=user)
        response = anon_client.get('/api/schema/widget/?name__in=a&name__in=c')
        names = {i['name'] for i in response.json()['items']}
        assert names == {'a', 'c'}

    def test_filter_fields_isnull(self, anon_client, user):
        Widget.objects.create(name='blank', owner=user, note='')
        Widget.objects.create(name='filled', owner=user, note='x')
        # note is TextField — '' is not null in DB; verify the parameter parses without error
        response = anon_client.get('/api/schema/widget/', {'note__isnull': 'true'})
        assert response.status_code == 200


class TestCreate:
    def test_post_create_json(self, auth_client, user):
        body = {'name': 'new', 'owner': user.id, 'is_public': False, 'note': ''}
        response = auth_client.post('/api/schema/widget/', json.dumps(body), content_type='application/json')
        assert response.status_code == 200, response.content
        data = response.json()
        assert data['name'] == 'new'
        assert Widget.objects.filter(id=data['id']).exists()

    def test_post_form_encoded(self, auth_client, user):
        response = auth_client.post('/api/schema/widget/', {'name': 'fe', 'owner': user.id, 'is_public': '', 'note': ''})
        assert response.status_code == 200, response.content
        assert Widget.objects.filter(name='fe').exists()

    def test_post_validation_errors(self, auth_client):
        response = auth_client.post('/api/schema/widget/', json.dumps({}), content_type='application/json')
        assert response.status_code == 400
        assert 'errors' in response.json()

    def test_post_anon_forbidden(self, anon_client, user):
        body = {'name': 'x', 'owner': user.id}
        response = anon_client.post('/api/schema/widget/', json.dumps(body), content_type='application/json')
        assert response.status_code == 403


class TestUpdate:
    def test_put_partial_merge(self, auth_client, widget):
        # send only `name`; required `owner` should be filled from instance
        response = auth_client.put(
            f'/api/schema/widget/{widget.id}/',
            json.dumps({'name': 'renamed'}),
            content_type='application/json',
        )
        assert response.status_code == 200, response.content
        widget.refresh_from_db()
        assert widget.name == 'renamed'

    def test_put_anon_forbidden(self, anon_client, widget):
        response = anon_client.put(
            f'/api/schema/widget/{widget.id}/',
            json.dumps({'name': 'x'}),
            content_type='application/json',
        )
        assert response.status_code == 403


class TestDelete:
    def test_delete(self, auth_client, widget):
        response = auth_client.delete(f'/api/schema/widget/{widget.id}/')
        assert response.status_code == 200
        assert not Widget.objects.filter(id=widget.id).exists()

    def test_delete_anon_forbidden(self, anon_client, widget):
        response = anon_client.delete(f'/api/schema/widget/{widget.id}/')
        assert response.status_code == 403
        assert Widget.objects.filter(id=widget.id).exists()


class TestPermissions:
    def test_unknown_form_404s(self, anon_client):
        response = anon_client.get('/api/schema/no-such-form/')
        assert response.status_code == 404

    def test_own_permission_filters_list(self, user, other_user, auth_client):
        WidgetWithUser.objects.create(name='mine', user=user)
        WidgetWithUser.objects.create(name='theirs', user=other_user)
        response = auth_client.get('/api/schema/own-widget/')
        names = {i['name'] for i in response.json()['items']}
        assert names == {'mine'}

    def test_own_permission_blocks_other_users_object(self, user, other_user, auth_client):
        theirs = WidgetWithUser.objects.create(name='theirs', user=other_user)
        response = auth_client.get(f'/api/schema/own-widget/{theirs.id}/')
        assert response.status_code == 403

    def test_self_permission_returns_request_user(self, auth_client, user):
        response = auth_client.get('/api/schema/self-user/')
        assert response.status_code == 200
        data = response.json()
        assert data['username'] == user.username

    def test_superuser_bypasses_permissions(self, super_client, other_user):
        theirs = WidgetWithUser.objects.create(name='t', user=other_user)
        response = super_client.delete(f'/api/schema/own-widget/{theirs.id}/')
        assert response.status_code == 200

    def test_all_permission_lets_anon_create(self, anon_client, user):
        body = {'name': 'free', 'owner': user.id, 'is_public': True}
        response = anon_client.post('/api/schema/public-widget/', json.dumps(body), content_type='application/json')
        assert response.status_code == 200
