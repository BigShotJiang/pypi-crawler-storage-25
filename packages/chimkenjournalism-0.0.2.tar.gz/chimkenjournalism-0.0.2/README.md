# Chimkenjournalism

This module was made to be use in ChikenMuziks and ohter simple use-case





**step to load env:**
- python -m venv .venv
- source .venv/bin/activate.fish
- pip install -r requirements.txt
