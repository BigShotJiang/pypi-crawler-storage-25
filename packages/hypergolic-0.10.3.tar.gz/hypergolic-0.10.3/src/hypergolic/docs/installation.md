# Installation

## Requirements

- **Python 3.14+**
- **macOS** (primary support; Linux may work but is untested)
- [uv](https://docs.astral.sh/uv/) — fast Python package manager and tool installer
- [ripgrep](https://github.com/BurntSushi/ripgrep) (`rg`) — *optional*, speeds up `search_files` (a Python fallback is used when not installed)

## Install Dependencies

```bash
# uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh

# ripgrep (optional, for faster file search)
brew install ripgrep
```

## Install Hypergolic

```bash
uv tool install hypergolic
```

This installs the `h` command globally.

## Set Environment Variables

Hypergolic needs an API key and base URL for an Anthropic-compatible API:

```bash
export HYPERGOLIC_API_KEY="your-api-key"
export HYPERGOLIC_BASE_URL="https://api.anthropic.com"
```

You can get an API key at [console.anthropic.com](https://console.anthropic.com/).

Add these to your shell profile (`~/.zshrc`, `~/.bashrc`, etc.) so they persist across sessions.

## Verify Installation

```bash
h --version
```

## Updating

```bash
h update
```

This checks PyPI for the latest version and upgrades in place.

## Development Installation

To work on Hypergolic itself:

```bash
git clone https://github.com/your-org/hypergolic.git
cd hypergolic
uv sync
```

Run in dev mode (rebuilds UI from source on each launch):

```bash
HYPERGOLIC_DEV_MODE=true uv run h
```
