# Workflow Config Reference

Complete reference for all workflow configuration fields.

## WorkflowConfig

Top-level workflow definition. Placed in `"workflows"` array of your config JSON.

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `id` | string | ✅ | — | Unique identifier (kebab-case). Used for activation and override resolution. |
| `name` | string | ✅ | — | Human-readable name displayed in the UI. |
| `description` | string | ✅ | — | Description shown to the agent and in the workflow selector. |
| `prompt_path` | string | ❌ | `null` | Path to a markdown file with workflow-level prompt context. Injected in every state. |
| `initial_state` | string | ✅ | — | ID of the first state when the workflow is activated. Must match a state `id`. |
| `states` | array | ❌ | `[]` | Array of `WorkflowStateConfig` objects. |

```json
{
  "id": "feature-development",
  "name": "Feature Development",
  "description": "End-to-end feature development",
  "prompt_path": ".agents/workflows/feature-development.md",
  "initial_state": "requirements",
  "states": []
}
```

## WorkflowStateConfig

Defines a single state within a workflow.

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `id` | string | ✅ | — | Unique identifier within the workflow. Referenced by `initial_state` and `next_state`. |
| `name` | string | ✅ | — | Human-readable name shown in the UI and transition markers. |
| `prompt_path` | string | ❌ | `null` | Path to a markdown file with state-specific prompt. |
| `skills` | array of string | ❌ | `[]` | Skill IDs to activate in this state. Additive to session skills. Deactivated when leaving (unless provided by another mechanism). |
| `tools` | array of CustomToolConfig | ❌ | `[]` | Custom tools available only in this state. Same schema as project/user tools. |
| `truncate_on_entry` | boolean | ❌ | `false` | If `true`, truncates conversation on entering this state and injects only specified artifacts. |
| `include_artifacts` | array of string | ❌ | `[]` | Artifact IDs from prior states to inject as prompt context. Only used when `truncate_on_entry` is `true`. |
| `output_schemas` | array of WorkflowOutputSchema | ❌ | `[]` | Defines the possible exits from this state. Each generates a transition tool. |

```json
{
  "id": "planning",
  "name": "Implementation Planning",
  "prompt_path": ".agents/workflows/feature-development/planning.md",
  "skills": [],
  "tools": [],
  "truncate_on_entry": true,
  "include_artifacts": ["prd"],
  "output_schemas": []
}
```

## WorkflowOutputSchema

Defines one possible exit from a state. Each generates a `workflow_transition_{outcome}` tool.

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `outcome` | `"success"` \| `"failure"` \| `"suppressed"` | ✅ | — | The outcome type. Determines the generated tool name. |
| `artifact_id` | string | ❌ | `null` | Logical name for the persisted artifact. Referenced by `include_artifacts` in later states. |
| `requires_approval` | boolean | ❌ | `false` | If `true`, user must approve before the transition completes. Triggers the artifact review UI. |
| `display` | object | ❌ | `null` | Maps schema property names to render types for human-facing display. Valid types: `"markdown"`, `"list"`, `"badge"`, `"text"`. Keys must match schema properties. |
| `schema` | object (JSON Schema) | ✅ | — | JSON Schema defining the structured output. Must be `"type": "object"`. |
| `next_state` | string \| null | ❌ | `null` | ID of the state to transition to. `null` means exit the workflow (terminal). |

```json
{
  "outcome": "success",
  "artifact_id": "prd",
  "requires_approval": true,
  "display": {
    "document": "markdown",
    "key_files": "list",
    "open_questions": "list"
  },
  "schema": {
    "type": "object",
    "properties": {
      "document": { "type": "string", "description": "The PRD" },
      "key_files": { "type": "array", "items": { "type": "string" } },
      "open_questions": { "type": "array", "items": { "type": "string" } }
    },
    "required": ["document", "key_files"]
  },
  "next_state": "planning"
}
```

Fields listed in `display` are rendered in the approval UI with the specified component. Fields not in `display` are omitted from the rendered view but remain accessible via the raw JSON inspector. This is intentional — unlisted fields are for the LLM's benefit, not human review.

## Outcome Semantics

| Outcome | Meaning | Typical Use |
|---------|---------|-------------|
| `success` | Work completed, move forward | Main path through the workflow |
| `failure` | Attempted but couldn't complete | Loop back for retry (e.g., review → implementation) |
| `suppressed` | Determined it shouldn't proceed | Graceful exit or loop back with concerns |

## Tool Generation

For each `output_schema`, a tool is generated:

- **Tool name:** `workflow_transition_{outcome}`
- **Input schema:** From the `schema` field
- **Approval:** From `requires_approval`
- **Display:** From `display` field mapping

If a state has `success` and `failure` outcomes, the agent sees:
- `workflow_transition_success`
- `workflow_transition_failure`

## Artifact Lifecycle

1. Agent calls a transition tool with structured output
2. If `artifact_id` is set, the output is persisted to the database
3. Later states reference the artifact via `include_artifacts`
4. On entry to a state with `truncate_on_entry`, artifacts are injected as prompt context
5. Artifacts persist beyond workflow completion and are browsable in the Knowledge panel

## Prompt Injection Order

Workflow prompts are injected after other prompt sources:

```
Role → User → Project → User-project → Session context → Active skills → Workflow prompt → State prompt → Artifact content
```

Workflow context comes last for maximum influence over agent behavior.

## Config Layering

Workflows follow the same override pattern as other config:

1. **User config** (`~/.agents/config.json` → `workflows`)
2. **Project config** (`<repo>/.agents/config.json` → `workflows`)
3. **User-project config** (`~/.agents/config.json` → `projects[].workflows`)

Later definitions with the same `id` override earlier ones.

## Complete Example

See the [sample config](https://github.com/your-repo/docs/prd/workflows/sample-config.json) for complete feature-development and debug workflow definitions.

```json
{
  "workflows": [
    {
      "id": "my-workflow",
      "name": "My Workflow",
      "description": "Description for the agent",
      "prompt_path": ".agents/workflows/my-workflow.md",
      "initial_state": "start",
      "states": [
        {
          "id": "start",
          "name": "Starting Phase",
          "prompt_path": ".agents/workflows/my-workflow/start.md",
          "truncate_on_entry": false,
          "output_schemas": [
            {
              "outcome": "success",
              "artifact_id": "start_output",
              "requires_approval": true,
              "display": { "document": "markdown" },
              "schema": {
                "type": "object",
                "properties": {
                  "document": { "type": "string" }
                },
                "required": ["document"]
              },
              "next_state": "finish"
            }
          ]
        },
        {
          "id": "finish",
          "name": "Finish",
          "truncate_on_entry": true,
          "include_artifacts": ["start_output"],
          "output_schemas": [
            {
              "outcome": "success",
              "schema": {
                "type": "object",
                "properties": {
                  "summary": { "type": "string" }
                },
                "required": ["summary"]
              },
              "next_state": null
            }
          ]
        }
      ]
    }
  ]
}
```
