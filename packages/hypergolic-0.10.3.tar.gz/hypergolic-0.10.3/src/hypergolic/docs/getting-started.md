# Getting Started

## Launch

`cd` into a git repository and run:

```bash
h
```

This runs database migrations, seeds default knowledge tags, detects the current git project, starts the local server on port 54321, and opens the native desktop window.

## The Interface

Hypergolic is a two-panel layout:

- **Left sidebar** — Tabbed panels for Source Control, File Explorer, Knowledge Graph, Terminal, Projects, Help, and Config.
- **Main area** — The chat conversation. Messages stream in real time, including tool calls and their results.

## Your First Conversation

1. **Ask it something.** Try: *"Read the README and summarize what this project does."* The assistant will use its tools to explore your repo.
2. **Watch it work.** You’ll see tool calls (file reads, searches, git operations) stream in real time. Each tool call is expandable to see inputs and outputs.
3. **Approve when needed.** If the assistant needs to run a shell command or write/edit files, you’ll be prompted to approve. Read the command before approving, especially for destructive operations.
4. **Correct it.** If it does something you don’t like, say so. It will store the correction in the knowledge graph and apply it in future sessions.

## Tool Approval

When the assistant wants to execute a potentially dangerous operation (shell commands, file writes), an approval prompt appears with keyboard shortcuts:

| Key | Action |
|-----|--------|
| `Y` | Approve |
| `N` | Deny |
| `D` | Deny with a message |
| `C` | Configure an auto-approval rule |

You can configure auto-approval rules to skip the prompt for trusted patterns (e.g., always approve `ruff check`).

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `⌘/Ctrl + 1` | Source Control panel |
| `⌘/Ctrl + 2` | File Explorer panel |
| `⌘/Ctrl + 3` | Knowledge Graph panel |
| `⌘/Ctrl + 4` | Terminal panel |
| `⌘/Ctrl + 5` | Projects panel |
| `⌘/Ctrl + 6` | Help panel |
| `⌘/Ctrl + 7` | Config panel |
| `⌘/Ctrl + /` | Focus chat input |
| `⌘/Ctrl + N` | New session |

## File Attachments

Drag files or images into the chat input. The assistant can read images (screenshots, diagrams, error messages) and use them as context.

## Sessions

Conversations are persistent. Each session has its own context and history. Use `⌘/Ctrl + N` to start a fresh session. Previous sessions are listed in the right sidebar and can be resumed.

## Next Steps

- [Configuration](configuration.md) — Set up your personal and project-level prompts and config
- [Tools](tools.md) — Understand what the assistant can do
- [Advanced Usage](advanced-usage.md) — Custom tools, MCP servers, skills, and roles
