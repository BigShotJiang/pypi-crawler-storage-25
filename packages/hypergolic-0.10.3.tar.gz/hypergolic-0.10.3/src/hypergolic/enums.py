from enum import Enum


class ModelTier(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class SessionStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    STREAMING = "streaming"
    TOOL_USE = "tool_use"
    TRUNCATING = "truncating"
    AWAITING_APPROVAL = "awaiting_approval"
    ERROR = "error"


class KnowledgeScope(str, Enum):
    UNIVERSAL = "universal"
    USER = "user"
    PROJECT = "project"
    SESSION = "session"


class WorkflowOutcome(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    SUPPRESSED = "suppressed"


class KnowledgeRelationType(str, Enum):
    RELATES_TO = "relates_to"
    DEPENDS_ON = "depends_on"
    CONTRADICTS = "contradicts"
    SUPERSEDES = "supersedes"
    REFINES = "refines"
    EXAMPLE_OF = "example_of"
