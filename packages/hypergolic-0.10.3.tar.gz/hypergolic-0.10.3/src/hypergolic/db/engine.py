from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session

_engine: Engine | None = None


def _get_engine() -> Engine:
    global _engine
    if _engine is None:
        from hypergolic.config.settings import settings

        _engine = create_engine(settings.DATABASE_URL)
    return _engine


@contextmanager
def get_db() -> Iterator[Session]:
    with Session(_get_engine()) as session:
        with session.begin():
            yield session
