import logging
from pathlib import Path

from sqlalchemy import select

from hypergolic.config.schemas import WorkflowConfig
from hypergolic.config.settings import (
    _load_user_config,
    load_project_config,
    load_user_project_config,
)
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionWorkflow
from hypergolic.workflows.builtins import BUILT_IN_WORKFLOWS

logger = logging.getLogger(__name__)


def resolve_workflows(project_path: Path | None = None) -> list[WorkflowConfig]:
    seen_ids: set[str] = set()
    workflows: list[WorkflowConfig] = []

    for wf in BUILT_IN_WORKFLOWS:
        workflows.append(wf)
        seen_ids.add(wf.id)

    user_config = _load_user_config()
    for wf in user_config.workflows:
        if wf.id in seen_ids:
            workflows = [w for w in workflows if w.id != wf.id]
        workflows.append(wf)
        seen_ids.add(wf.id)

    if project_path:
        project_config = load_project_config(project_path)
        for wf in project_config.workflows:
            if wf.id in seen_ids:
                workflows = [w for w in workflows if w.id != wf.id]
            workflows.append(wf)
            seen_ids.add(wf.id)

        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for wf in user_project_config.workflows:
                if wf.id in seen_ids:
                    workflows = [w for w in workflows if w.id != wf.id]
                workflows.append(wf)
                seen_ids.add(wf.id)

    return workflows


def get_workflow_config(
    workflow_id: str, project_path: Path | None = None
) -> WorkflowConfig | None:
    for wf in resolve_workflows(project_path):
        if wf.id == workflow_id:
            return wf
    return None


def get_session_workflow(session_id: str) -> tuple[str, str] | None:
    with get_db() as db:
        row = db.execute(
            select(DBSessionWorkflow)
            .where(DBSessionWorkflow.session_id == session_id)
            .where(DBSessionWorkflow.deleted_at.is_(None))
        ).scalar_one_or_none()
        if row is None:
            return None
        return (row.workflow_id, row.current_state_id)
