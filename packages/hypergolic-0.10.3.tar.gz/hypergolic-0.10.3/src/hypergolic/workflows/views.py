from pathlib import Path

from fastapi import APIRouter, HTTPException, Query

from hypergolic.config.schemas import WorkflowConfig
from hypergolic.sessions.operations import load_session
from hypergolic.workflows.resolver import resolve_workflows
from hypergolic.workflows.schemas import PromptContentResponse

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


def _collect_prompt_paths(workflows: list[WorkflowConfig]) -> set[str]:
    paths: set[str] = set()
    for wf in workflows:
        if wf.prompt_path:
            paths.add(wf.prompt_path)
        for state in wf.states:
            if state.prompt_path:
                paths.add(state.prompt_path)
    return paths


@router.get("/prompt-content", response_model=PromptContentResponse)
def get_prompt_content(
    path: str = Query(..., description="Absolute path to prompt file"),
    session_id: str | None = Query(None, description="Session ID for project context"),
):
    project_path: Path | None = None
    if session_id:
        session = load_session(session_id)
        project_path = session.working_directory()

    workflows = resolve_workflows(project_path)
    allowed = _collect_prompt_paths(workflows)

    if path not in allowed:
        raise HTTPException(status_code=404, detail="Prompt path not found in any workflow")

    file_path = Path(path)
    if not file_path.is_file():
        raise HTTPException(status_code=404, detail="Prompt file not found on disk")

    return PromptContentResponse(path=path, content=file_path.read_text())
