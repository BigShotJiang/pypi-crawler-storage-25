from hypergolic.config.schemas import (
    WorkflowConfig,
    WorkflowOutputSchema,
    WorkflowStateConfig,
)
from hypergolic.config.settings import PROMPTS_DIR

_P = PROMPTS_DIR / "workflows"

DEBUG_WORKFLOW = WorkflowConfig(
    id="debug",
    name="Debug",
    description="Structured debugging from investigation through resolution and validation",
    prompt_path=str(_P / "debug.md"),
    initial_state="investigation",
    states=[
        WorkflowStateConfig(
            id="investigation",
            name="Investigation",
            prompt_path=str(_P / "debug" / "investigation.md"),
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="investigation",
                    requires_approval=True,
                    display={
                        "analysis": "markdown",
                        "reproduced": "badge",
                        "steps_to_reproduce": "text",
                        "root_cause": "text",
                        "affected_files": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "analysis": {"type": "string", "description": "Analysis of the bug: what, where, why"},
                            "reproduced": {"type": "boolean", "description": "Whether the bug was successfully reproduced"},
                            "steps_to_reproduce": {"type": "string"},
                            "error_output": {"type": "string"},
                            "root_cause": {"type": "string"},
                            "affected_files": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["analysis", "reproduced", "steps_to_reproduce"],
                    },
                    next_state="resolving",
                ),
                WorkflowOutputSchema(
                    outcome="suppressed",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "information_needed": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["reason"],
                    },
                    next_state=None,
                ),
            ],
        ),
        WorkflowStateConfig(
            id="resolving",
            name="Resolving",
            prompt_path=str(_P / "debug" / "resolving.md"),
            truncate_on_entry=True,
            include_artifacts=["investigation"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="fix_summary",
                    display={
                        "summary": "markdown",
                        "files_changed": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "summary": {"type": "string"},
                            "files_changed": {"type": "array", "items": {"type": "string"}},
                            "fix_description": {"type": "string"},
                        },
                        "required": ["summary", "files_changed"],
                    },
                    next_state="validating",
                ),
                WorkflowOutputSchema(
                    outcome="suppressed",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "partial_progress": {"type": "string"},
                        },
                        "required": ["reason"],
                    },
                    next_state="investigation",
                ),
            ],
        ),
        WorkflowStateConfig(
            id="validating",
            name="Validating",
            prompt_path=str(_P / "debug" / "validating.md"),
            truncate_on_entry=True,
            include_artifacts=["investigation", "fix_summary"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="validation_result",
                    display={
                        "summary": "markdown",
                        "tests_passed": "badge",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "summary": {"type": "string"},
                            "tests_passed": {"type": "boolean"},
                            "validation_evidence": {"type": "string"},
                        },
                        "required": ["summary", "tests_passed"],
                    },
                    next_state=None,
                ),
                WorkflowOutputSchema(
                    outcome="failure",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "failing_tests": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["reason"],
                    },
                    next_state="resolving",
                ),
            ],
        ),
    ],
)
