from hypergolic.config.schemas import WorkflowOutputSchema, WorkflowStateConfig
from hypergolic.config.settings import PROMPTS_DIR

_P = PROMPTS_DIR / "workflows"

_SUPPRESSED_SCHEMA = {
    "type": "object",
    "properties": {"reason": {"type": "string"}},
    "required": ["reason"],
}


def _suppressed(next_state: str | None = None) -> WorkflowOutputSchema:
    return WorkflowOutputSchema(
        outcome="suppressed",
        schema=_SUPPRESSED_SCHEMA,
        next_state=next_state,
    )


DISCOVERY = WorkflowStateConfig(
    id="discovery",
    name="Discovery",
    prompt_path=str(_P / "optimize-config" / "discovery.md"),
    skills=["hypergolic-expertise"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="discovery",
            requires_approval=True,
            display={
                "summary": "markdown",
                "project_config": "text",
                "user_goals": "list",
                "known_preferences": "list",
            },
            schema={
                "type": "object",
                "properties": {
                    "summary": {"type": "string", "description": "Understanding of the user, project, and goals"},
                    "project_config": {"type": "string", "description": "Summary of current configuration state"},
                    "user_goals": {"type": "array", "items": {"type": "string"}, "description": "What the user wants the agent to do well"},
                    "known_preferences": {"type": "array", "items": {"type": "string"}, "description": "Preferences from knowledge graph"},
                },
                "required": ["summary", "project_config", "user_goals"],
            },
            next_state="audit-prompts",
        ),
        _suppressed(None),
    ],
)

AUDIT_PROMPTS = WorkflowStateConfig(
    id="audit-prompts",
    name="Audit Prompts",
    prompt_path=str(_P / "optimize-config" / "audit-prompts.md"),
    skills=["hypergolic-expertise"],
    truncate_on_entry=True,
    include_artifacts=["discovery"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="prompt_audit",
            display={"findings": "markdown"},
            schema={
                "type": "object",
                "properties": {
                    "findings": {"type": "string", "description": "Markdown audit report of all prompt layers"},
                    "recommendations": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "location": {"type": "string"},
                                "issue": {"type": "string"},
                                "recommendation": {"type": "string"},
                                "priority": {"type": "string"},
                            },
                        },
                    },
                },
                "required": ["findings"],
            },
            next_state="audit-tools",
        ),
        _suppressed("audit-tools"),
    ],
)

AUDIT_TOOLS = WorkflowStateConfig(
    id="audit-tools",
    name="Audit Tools",
    prompt_path=str(_P / "optimize-config" / "audit-tools.md"),
    skills=["hypergolic-expertise", "tool-builder"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "prompt_audit"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="tool_audit",
            display={"findings": "markdown"},
            schema={
                "type": "object",
                "properties": {
                    "findings": {"type": "string", "description": "Audit report of all tools"},
                    "tools_to_add": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "name": {"type": "string"},
                                "description": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                    "tools_to_modify": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "changes": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                    "tools_to_remove": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                },
                "required": ["findings"],
            },
            next_state="audit-skills-roles",
        ),
        _suppressed("audit-skills-roles"),
    ],
)

AUDIT_SKILLS_ROLES = WorkflowStateConfig(
    id="audit-skills-roles",
    name="Audit Skills & Roles",
    prompt_path=str(_P / "optimize-config" / "audit-skills-roles.md"),
    skills=["hypergolic-expertise", "tool-builder"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "prompt_audit", "tool_audit"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="skills_roles_audit",
            display={"findings": "markdown"},
            schema={
                "type": "object",
                "properties": {
                    "findings": {"type": "string", "description": "Audit report of skills and roles"},
                    "skills_recommendations": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "action": {"type": "string"},
                                "id": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                    "roles_recommendations": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "action": {"type": "string"},
                                "id": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                },
                "required": ["findings"],
            },
            next_state="audit-workflows",
        ),
        _suppressed("audit-workflows"),
    ],
)

AUDIT_WORKFLOWS = WorkflowStateConfig(
    id="audit-workflows",
    name="Audit Workflows",
    prompt_path=str(_P / "optimize-config" / "audit-workflows.md"),
    skills=["hypergolic-expertise"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "prompt_audit", "tool_audit", "skills_roles_audit"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="workflow_audit",
            display={"findings": "markdown"},
            schema={
                "type": "object",
                "properties": {
                    "findings": {"type": "string", "description": "Audit report of workflows"},
                    "workflow_recommendations": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "action": {"type": "string"},
                                "id": {"type": "string"},
                                "description": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                },
                "required": ["findings"],
            },
            next_state="cross-project-review",
        ),
        _suppressed("cross-project-review"),
    ],
)

CROSS_PROJECT_REVIEW = WorkflowStateConfig(
    id="cross-project-review",
    name="Cross-Project Review",
    prompt_path=str(_P / "optimize-config" / "cross-project-review.md"),
    skills=["hypergolic-expertise"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "prompt_audit", "tool_audit", "skills_roles_audit", "workflow_audit"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="cross_project_review",
            display={"findings": "markdown"},
            schema={
                "type": "object",
                "properties": {
                    "findings": {"type": "string", "description": "Cross-project review findings"},
                    "user_level_recommendations": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "type": {"type": "string"},
                                "description": {"type": "string"},
                                "rationale": {"type": "string"},
                            },
                        },
                    },
                    "knowledge_graph_recommendations": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "action": {"type": "string"},
                                "content": {"type": "string"},
                                "scope": {"type": "string"},
                                "tags": {"type": "string"},
                            },
                        },
                    },
                },
                "required": ["findings"],
            },
            next_state="propose",
        ),
        _suppressed("propose"),
    ],
)

PROPOSE = WorkflowStateConfig(
    id="propose",
    name="Propose",
    prompt_path=str(_P / "optimize-config" / "propose.md"),
    skills=["hypergolic-expertise", "tool-builder"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "prompt_audit", "tool_audit", "skills_roles_audit", "workflow_audit", "cross_project_review"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="proposal",
            requires_approval=True,
            display={"plan": "markdown"},
            schema={
                "type": "object",
                "properties": {
                    "plan": {"type": "string", "description": "Full markdown proposal of all changes"},
                    "changes": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "category": {"type": "string"},
                                "action": {"type": "string"},
                                "target": {"type": "string"},
                                "description": {"type": "string"},
                                "priority": {"type": "string"},
                            },
                        },
                    },
                    "estimated_changes_count": {"type": "integer"},
                },
                "required": ["plan", "changes", "estimated_changes_count"],
            },
            next_state="implement",
        ),
        WorkflowOutputSchema(
            outcome="failure",
            schema=_SUPPRESSED_SCHEMA,
            next_state=None,
        ),
        _suppressed("discovery"),
    ],
)

IMPLEMENT = WorkflowStateConfig(
    id="implement",
    name="Implement",
    prompt_path=str(_P / "optimize-config" / "implement.md"),
    skills=["hypergolic-expertise", "tool-builder"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "proposal"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="implementation_summary",
            display={
                "summary": "markdown",
                "changes_made": "list",
                "changes_skipped": "list",
                "issues_encountered": "list",
            },
            schema={
                "type": "object",
                "properties": {
                    "summary": {"type": "string", "description": "Summary of what was implemented"},
                    "changes_made": {"type": "array", "items": {"type": "string"}},
                    "changes_skipped": {"type": "array", "items": {"type": "string"}},
                    "issues_encountered": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["summary", "changes_made"],
            },
            next_state="summarize",
        ),
        WorkflowOutputSchema(
            outcome="failure",
            schema={
                "type": "object",
                "properties": {
                    "reason": {"type": "string"},
                    "partial_progress": {"type": "string"},
                },
                "required": ["reason"],
            },
            next_state="implement",
        ),
    ],
)

SUMMARIZE = WorkflowStateConfig(
    id="summarize",
    name="Summarize",
    prompt_path=str(_P / "optimize-config" / "summarize.md"),
    skills=["hypergolic-expertise"],
    truncate_on_entry=True,
    include_artifacts=["discovery", "proposal", "implementation_summary"],
    output_schemas=[
        WorkflowOutputSchema(
            outcome="success",
            artifact_id="optimization_summary",
            schema={
                "type": "object",
                "properties": {
                    "summary": {"type": "string", "description": "Complete optimization summary"},
                    "preferences_recorded": {"type": "array", "items": {"type": "string"}},
                    "follow_up_items": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["summary"],
            },
            next_state=None,
        ),
    ],
)
