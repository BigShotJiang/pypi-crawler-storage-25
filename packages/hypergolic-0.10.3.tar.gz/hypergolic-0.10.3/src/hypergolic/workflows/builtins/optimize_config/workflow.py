from hypergolic.config.schemas import WorkflowConfig
from hypergolic.config.settings import PROMPTS_DIR

from hypergolic.workflows.builtins.optimize_config.states import (
    DISCOVERY,
    AUDIT_PROMPTS,
    AUDIT_TOOLS,
    AUDIT_SKILLS_ROLES,
    AUDIT_WORKFLOWS,
    CROSS_PROJECT_REVIEW,
    PROPOSE,
    IMPLEMENT,
    SUMMARIZE,
)

_P = PROMPTS_DIR / "workflows"

OPTIMIZE_CONFIG_WORKFLOW = WorkflowConfig(
    id="optimize-config",
    name="Optimize Configuration",
    description="Improve Hypergolic's configuration for this project \u2014 audit prompts, tools, skills, workflows, and roles, then propose and implement changes",
    prompt_path=str(_P / "optimize-config.md"),
    initial_state="discovery",
    states=[
        DISCOVERY,
        AUDIT_PROMPTS,
        AUDIT_TOOLS,
        AUDIT_SKILLS_ROLES,
        AUDIT_WORKFLOWS,
        CROSS_PROJECT_REVIEW,
        PROPOSE,
        IMPLEMENT,
        SUMMARIZE,
    ],
)
