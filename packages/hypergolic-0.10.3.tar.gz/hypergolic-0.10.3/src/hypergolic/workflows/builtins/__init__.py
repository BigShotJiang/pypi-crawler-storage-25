from hypergolic.workflows.builtins.feature_development import FEATURE_DEVELOPMENT_WORKFLOW
from hypergolic.workflows.builtins.debug import DEBUG_WORKFLOW
from hypergolic.workflows.builtins.optimize_config.workflow import OPTIMIZE_CONFIG_WORKFLOW

from hypergolic.config.schemas import WorkflowConfig

BUILT_IN_WORKFLOWS: list[WorkflowConfig] = [
    FEATURE_DEVELOPMENT_WORKFLOW,
    DEBUG_WORKFLOW,
    OPTIMIZE_CONFIG_WORKFLOW,
]
