from hypergolic.config.schemas import (
    WorkflowConfig,
    WorkflowOutputSchema,
    WorkflowStateConfig,
)
from hypergolic.config.settings import PROMPTS_DIR

_P = PROMPTS_DIR / "workflows"

FEATURE_DEVELOPMENT_WORKFLOW = WorkflowConfig(
    id="feature-development",
    name="Feature Development",
    description="End-to-end feature development from requirements through implementation and review",
    prompt_path=str(_P / "feature-development.md"),
    initial_state="requirements",
    states=[
        WorkflowStateConfig(
            id="requirements",
            name="Requirements Gathering",
            prompt_path=str(_P / "feature-development" / "requirements.md"),
            skills=["product-management"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="prd",
                    requires_approval=True,
                    display={
                        "document": "markdown",
                        "key_files": "list",
                        "open_questions": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "document": {"type": "string", "description": "The full PRD in markdown"},
                            "key_files": {"type": "array", "items": {"type": "string"}, "description": "Files the implementer should read or modify"},
                            "open_questions": {"type": "array", "items": {"type": "string"}, "description": "Unresolved questions (ideally empty)"},
                        },
                        "required": ["document", "key_files"],
                    },
                    next_state="planning",
                ),
                WorkflowOutputSchema(
                    outcome="failure",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "blockers": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["reason"],
                    },
                    next_state=None,
                ),
                WorkflowOutputSchema(
                    outcome="suppressed",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "missing_information": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["reason"],
                    },
                    next_state=None,
                ),
            ],
        ),
        WorkflowStateConfig(
            id="planning",
            name="Implementation Planning",
            prompt_path=str(_P / "feature-development" / "planning.md"),
            truncate_on_entry=True,
            include_artifacts=["prd"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="plan",
                    requires_approval=True,
                    display={
                        "plan": "markdown",
                        "estimated_complexity": "badge",
                        "risk_areas": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "plan": {"type": "string", "description": "Step-by-step implementation plan in markdown"},
                            "estimated_complexity": {"type": "string", "enum": ["trivial", "small", "medium", "large", "complex"]},
                            "risk_areas": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["plan"],
                    },
                    next_state="implementation",
                ),
                WorkflowOutputSchema(
                    outcome="suppressed",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "questions_for_user": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["reason"],
                    },
                    next_state="requirements",
                ),
            ],
        ),
        WorkflowStateConfig(
            id="implementation",
            name="Implementation",
            prompt_path=str(_P / "feature-development" / "implementation.md"),
            truncate_on_entry=True,
            include_artifacts=["prd", "plan"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="implementation_summary",
                    display={
                        "summary": "markdown",
                        "files_changed": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "summary": {"type": "string", "description": "Summary of changes made"},
                            "files_changed": {"type": "array", "items": {"type": "string"}},
                            "test_results": {"type": "string"},
                            "notes": {"type": "string"},
                        },
                        "required": ["summary", "files_changed"],
                    },
                    next_state="review",
                ),
                WorkflowOutputSchema(
                    outcome="suppressed",
                    schema={
                        "type": "object",
                        "properties": {
                            "reason": {"type": "string"},
                            "partial_progress": {"type": "string"},
                            "proposed_plan_changes": {"type": "string"},
                        },
                        "required": ["reason"],
                    },
                    next_state="planning",
                ),
            ],
        ),
        WorkflowStateConfig(
            id="review",
            name="Review",
            prompt_path=str(_P / "feature-development" / "review.md"),
            truncate_on_entry=True,
            include_artifacts=["prd", "plan", "implementation_summary"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="review_result",
                    requires_approval=True,
                    display={
                        "verdict": "badge",
                        "notes": "markdown",
                        "validation_steps_completed": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "verdict": {"type": "string", "enum": ["pass", "pass_with_notes"]},
                            "notes": {"type": "string"},
                            "validation_steps_completed": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["verdict"],
                    },
                    next_state="summarize",
                ),
                WorkflowOutputSchema(
                    outcome="failure",
                    artifact_id="review_feedback",
                    requires_approval=True,
                    schema={
                        "type": "object",
                        "properties": {
                            "summary": {"type": "string"},
                            "feedback": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "priority": {"type": "string", "enum": ["critical", "high", "medium", "low"]},
                                        "ref": {"type": "string", "description": "File path or location reference"},
                                        "comment": {"type": "string"},
                                    },
                                    "required": ["priority", "comment"],
                                },
                            },
                        },
                        "required": ["summary", "feedback"],
                    },
                    next_state="implementation",
                ),
            ],
        ),
        WorkflowStateConfig(
            id="summarize",
            name="Summarize",
            prompt_path=str(_P / "feature-development" / "summarize.md"),
            truncate_on_entry=True,
            include_artifacts=["prd", "plan", "implementation_summary", "review_result"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="feature_summary",
                    display={
                        "summary": "markdown",
                        "artifacts_produced": "list",
                    },
                    schema={
                        "type": "object",
                        "properties": {
                            "summary": {"type": "string", "description": "Complete feature development summary"},
                            "artifacts_produced": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["summary"],
                    },
                    next_state=None,
                ),
            ],
        ),
    ],
)
