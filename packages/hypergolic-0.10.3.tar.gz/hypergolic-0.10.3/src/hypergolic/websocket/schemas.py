from typing import Any, Literal

from pydantic import BaseModel, Field

from hypergolic.enums import ModelTier


class ConnectMessage(BaseModel):
    type: Literal["chat"] = "chat"
    message: str = Field(..., min_length=1)
    model_tier: ModelTier = Field(default=ModelTier.HIGH)
    session_id: str | None = None
    project_id: str | None = None
    content_blocks: list[dict[str, Any]] | None = None
    workflow_id: str | None = None


class AnnotationPayload(BaseModel):
    highlighted_text: str
    comment: str


class ApprovalResponseMessage(BaseModel):
    type: Literal["tool_approval_response"] = "tool_approval_response"
    tool_use_id: str
    approved: bool
    denial_reason: str | None = None
    annotations: list[AnnotationPayload] | None = None


WsClientMessage = ConnectMessage | ApprovalResponseMessage


def parse_client_message(raw: dict[str, Any]) -> WsClientMessage:
    msg_type = raw.get("type", "chat")
    if msg_type == "tool_approval_response":
        return ApprovalResponseMessage.model_validate(raw)
    return ConnectMessage.model_validate(raw)
