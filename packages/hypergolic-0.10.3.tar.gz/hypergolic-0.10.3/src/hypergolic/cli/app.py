import typer
from rich.console import Console

from hypergolic.cli.version import get_version
from hypergolic.cli.launch import launch
from hypergolic.cli.update import update
from hypergolic.cli.config_cmd import config

app = typer.Typer(
    name="h",
    help="Hypergolic \u2014 AI-powered coding assistant.",
    invoke_without_command=True,
    no_args_is_help=False,
)
console = Console()


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"hypergolic [bold cyan]{get_version()}[/]")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    if ctx.invoked_subcommand is None:
        ctx.invoke(launch)


app.command()(launch)
app.command()(update)
app.command()(config)
