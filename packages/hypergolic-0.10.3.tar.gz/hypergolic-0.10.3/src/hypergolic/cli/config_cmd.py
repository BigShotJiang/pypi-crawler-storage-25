from rich.console import Console
from rich.table import Table

from hypergolic.cli.version import get_version
from hypergolic.config.settings import USER_CONFIG_PATH, _load_user_config

console = Console()


def config() -> None:
    """Display current configuration."""

    console.print("\n[bold]Version[/]")
    console.print(f"  {get_version()}")

    console.print("\n[bold]User Config[/]")
    console.print(f"  Path: {USER_CONFIG_PATH}")
    if not USER_CONFIG_PATH.exists():
        console.print("  [yellow]File not found[/]")
        return

    user_config = _load_user_config()

    console.print(f"  Database: {user_config.db_path}")
    console.print(f"  Prompt: {user_config.prompt_path}")

    if user_config.mcp_servers:
        console.print("\n[bold]MCP Servers (user-level)[/]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Name")
        table.add_column("Transport")
        table.add_column("Command / URL")
        for name, server in user_config.mcp_servers.items():
            target = server.url or f"{server.command} {' '.join(server.args)}".strip()
            table.add_row(name, server.transport, target)
        console.print(table)

    if user_config.tools:
        console.print("\n[bold]Custom Tools (user-level)[/]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("ID")
        table.add_column("Name")
        table.add_column("Command")
        for tool in user_config.tools:
            table.add_row(tool.id, tool.name, tool.command)
        console.print(table)

    if user_config.skills:
        console.print("\n[bold]Skills (user-level)[/]")
        for skill in user_config.skills:
            tools_str = f" (tools: {', '.join(t.id for t in skill.tools)})" if skill.tools else ""
            console.print(f"  {skill.id}: {skill.name}{tools_str}")

    if user_config.roles:
        console.print("\n[bold]Roles (user-level)[/]")
        for role in user_config.roles:
            console.print(f"  {role.id}: {role.name}")

    if user_config.projects:
        console.print("\n[bold]Projects[/]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Name")
        table.add_column("Git Root")
        table.add_column("MCP Servers")
        table.add_column("Tools")
        table.add_column("Skills")
        for project in user_config.projects:
            tools_display = ", ".join(t.id for t in project.tools) if project.tools else "\u2014"
            skills_display = ", ".join(project.skills) if project.skills else "\u2014"
            table.add_row(
                project.name,
                project.git_root,
                str(len(project.mcp_servers)),
                tools_display,
                skills_display,
            )
        console.print(table)

    console.print()
