import subprocess

import typer
from rich.console import Console

from hypergolic.cli.version import get_version

console = Console()


def update() -> None:
    """Update Hypergolic to the latest version."""
    current = get_version()
    console.print(f"Current version: [bold cyan]{current}[/]")
    console.print("Checking for updates...")

    try:
        result = subprocess.run(
            ["uv", "pip", "index", "versions", "hypergolic"],
            capture_output=True,
            text=True,
        )
        latest: str | None = None
        if result.returncode == 0:
            first_line = result.stdout.strip().split("\n")[0]
            if "(" in first_line and ")" in first_line:
                latest = first_line.split("(")[1].split(")")[0].strip()
    except FileNotFoundError:
        console.print("[red]Error:[/] uv is not installed.")
        raise typer.Exit(1)

    if latest is None:
        console.print("[yellow]Could not determine latest version.[/]")
        raise typer.Exit(1)

    if latest == current:
        console.print("[green]Already up to date.[/]")
        raise typer.Exit()

    console.print(f"Latest version: [bold cyan]{latest}[/]")
    console.print(f"Upgrading [bold]{current}[/] \u2192 [bold]{latest}[/]...")

    upgrade = subprocess.run(
        ["uv", "tool", "upgrade", "hypergolic"],
        capture_output=True,
        text=True,
    )
    output = (upgrade.stdout + upgrade.stderr).strip()

    if upgrade.returncode == 0:
        console.print(f"[green]\u2713 Updated to {latest}.[/]")
    else:
        console.print(f"[red]Update failed:[/] {output}")
        raise typer.Exit(1)
