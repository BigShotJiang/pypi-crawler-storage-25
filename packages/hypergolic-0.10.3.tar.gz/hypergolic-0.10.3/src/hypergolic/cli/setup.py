import shutil
import subprocess
from pathlib import Path

import typer
from alembic import command as alembic_command
from alembic.config import Config as AlembicConfig
from rich.console import Console
from sqlalchemy import select

from hypergolic.config.settings import _load_user_config
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBTag

console = Console()


def _package_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _ui_dist_dir() -> Path:
    return _package_root() / "ui_dist"


def _find_ui_source_dir() -> Path | None:
    cwd = Path.cwd()
    candidates = [
        cwd / "ui",
        _package_root().parent.parent / "ui",
    ]
    for candidate in candidates:
        if (candidate / "package.json").exists():
            return candidate
    return None


def sync_docs() -> None:
    """Copy docs from repo root into package for serving."""
    pkg_docs = _package_root() / "docs"
    pkg_docs.mkdir(exist_ok=True)

    repo_root = _package_root().parent.parent
    readme = repo_root / "README.md"
    docs_dir = repo_root / "docs"

    if readme.is_file():
        shutil.copy2(readme, pkg_docs / "README.md")
    if docs_dir.is_dir():
        for md in docs_dir.glob("*.md"):
            shutil.copy2(md, pkg_docs / md.name)


def build_ui() -> None:
    ui_dir = _find_ui_source_dir()
    if ui_dir is None:
        console.print(
            "[red]Error:[/] Cannot find ui/ directory with package.json. "
            "Run from the hypergolic repo root, or ensure the UI is pre-built.",
        )
        raise typer.Exit(1)

    console.print(f"Building UI from {ui_dir}...")
    result = subprocess.run(["pnpm", "install", "--frozen-lockfile"], cwd=str(ui_dir))
    if result.returncode != 0:
        console.print("[red]Error:[/] pnpm install failed.")
        raise typer.Exit(1)

    result = subprocess.run(["pnpm", "run", "build"], cwd=str(ui_dir))
    if result.returncode != 0:
        console.print("[red]Error:[/] UI build failed.")
        raise typer.Exit(1)
    console.print("[green]UI build complete.[/]")


def run_migrations() -> None:
    root = _package_root()
    alembic_ini = root / "alembic.ini"
    alembic_cfg = AlembicConfig(str(alembic_ini))
    alembic_cfg.set_main_option("script_location", str(root / "alembic"))
    alembic_command.upgrade(alembic_cfg, "head")


DEFAULT_TAGS = [
    "code-style",
    "tooling",
    "architecture",
    "domain",
    "team",
    "workflow",
    "debugging",
    "preference",
    "correction",
]


def seed_tags() -> None:
    with get_db() as db:
        existing = {row.name for row in db.execute(select(DBTag)).scalars().all()}
        for tag_name in DEFAULT_TAGS:
            if tag_name not in existing:
                db.add(DBTag(name=tag_name))


def register_config_projects() -> None:
    user_config = _load_user_config()
    if not user_config.projects:
        return

    with get_db() as db:
        for project in user_config.projects:
            resolved = str(Path(project.git_root).resolve())
            existing = db.execute(
                select(DBProject).where(DBProject.path == resolved)
            ).scalar_one_or_none()
            if existing:
                if existing.name != project.name:
                    existing.name = project.name
                continue
            db.add(DBProject(name=project.name, path=resolved))
