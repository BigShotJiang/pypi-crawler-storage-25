import os
import threading
import time
import urllib.request
import urllib.error
from typing import Annotated

import typer
import uvicorn
import webview
from rich.console import Console

from hypergolic.auth import init_bootstrap_token
from hypergolic.logging import setup_error_logging
from hypergolic.cli.setup import (
    _ui_dist_dir,
    build_ui,
    sync_docs,
    run_migrations,
    seed_tags,
    register_config_projects,
)

console = Console()


def _wait_for_server(host: str, port: int, timeout: float = 30.0) -> bool:
    health_url = f"http://{host}:{port}/api/health"
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with urllib.request.urlopen(health_url, timeout=1) as response:
                if response.status == 200:
                    return True
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
            pass
        time.sleep(0.1)
    return False


def launch(
    host: Annotated[
        str, typer.Option(help="Host to bind the server to.")
    ] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Port to bind the server to.")] = 54321,
) -> None:
    setup_error_logging()

    if os.environ.get("HYPERGOLIC_DEV_MODE", "").lower() in ("1", "true", "yes"):
        build_ui()
    elif not _ui_dist_dir().exists():
        console.print(
            "[red]Error:[/] UI has not been built. Use [bold]h launch --dev[/] "
            "to build automatically, or pre-build with "
            "[bold]cd ui && pnpm run build[/].",
        )
        raise typer.Exit(1)

    sync_docs()
    run_migrations()
    seed_tags()
    register_config_projects()
    bootstrap_token = init_bootstrap_token()

    url = f"http://{host}:{port}?token={bootstrap_token}"

    server_thread = threading.Thread(
        target=uvicorn.run,
        kwargs={
            "app": "hypergolic.api:app",
            "host": str(host),
            "port": int(port),
            "log_level": "info",
        },
        daemon=True,
    )
    server_thread.start()

    if not _wait_for_server(host, port):
        console.print("[red]Error:[/] Server failed to start within timeout.")
        raise typer.Exit(1)

    largest_screen = max(webview.screens, key=lambda s: s.width * s.height)
    window = webview.create_window(
        "Hypergolic",
        url,
        screen=largest_screen,
        background_color="#0a0a0f",
        maximized=True,
        text_select=True,
    )

    def _maximize_on_largest_screen() -> None:
        if window is None:
            return
        window.move(0, 0)
        window.resize(largest_screen.width, largest_screen.height)

    webview.start(func=_maximize_on_largest_screen, debug=False)
