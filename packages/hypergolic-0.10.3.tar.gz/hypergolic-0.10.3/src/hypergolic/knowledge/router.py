from fastapi import APIRouter, HTTPException
from sqlalchemy import select, delete as sa_delete
from sqlalchemy import func as sa_func

from hypergolic.db.engine import get_db
from hypergolic.db.models import (
    DBKnowledge,
    DBKnowledgeRelationship,
    DBKnowledgeTag,
    DBTag,
)
from hypergolic.db.utils import to_iso_utc
from hypergolic.knowledge.schemas import (
    CreateKnowledgeRequest,
    CreateRelationshipRequest,
    CreateTagRequest,
    KnowledgeItemResponse,
    KnowledgeRelationshipResponse,
    TagResponse,
)
from hypergolic.knowledge.serializers import serialize_knowledge_item, serialize_relationship

router = APIRouter(tags=["knowledge"])

RELATION_TYPES = [
    "relates_to", "depends_on", "contradicts", "supersedes", "refines", "example_of"
]


# --- Knowledge CRUD ---

@router.get("/api/knowledge", response_model=list[KnowledgeItemResponse])
def list_knowledge(
    scope: str | None = None,
    tag: str | None = None,
    query: str | None = None,
):
    with get_db() as db:
        stmt = select(DBKnowledge)
        if scope:
            stmt = stmt.where(DBKnowledge.scope == scope)
        if query:
            stmt = stmt.where(DBKnowledge.content.contains(query))
        if tag:
            stmt = stmt.where(
                DBKnowledge.id.in_(
                    select(DBKnowledgeTag.knowledge_id)
                    .join(DBTag, DBKnowledgeTag.tag_id == DBTag.id)
                    .where(DBTag.name == tag)
                )
            )
        stmt = stmt.order_by(DBKnowledge.created_at.desc()).limit(200)
        items = db.execute(stmt).scalars().all()
        return [serialize_knowledge_item(db, item) for item in items]


@router.post("/api/knowledge", response_model=KnowledgeItemResponse)
def create_knowledge(req: CreateKnowledgeRequest):
    with get_db() as db:
        item = DBKnowledge(
            content=req.content,
            scope=req.scope,
            source=req.source,
            project_id=req.project_id,
            session_id=req.session_id,
        )
        db.add(item)
        db.flush()

        for tag_name in req.tags:
            tag = db.execute(
                select(DBTag).where(DBTag.name == tag_name)
            ).scalar_one_or_none()
            if not tag:
                tag = DBTag(name=tag_name)
                db.add(tag)
                db.flush()
            db.add(DBKnowledgeTag(knowledge_id=item.id, tag_id=tag.id))
        db.flush()

        return serialize_knowledge_item(db, item)


@router.delete("/api/knowledge/{knowledge_id}")
def delete_knowledge(knowledge_id: str):
    with get_db() as db:
        item = db.execute(
            select(DBKnowledge).where(DBKnowledge.id == knowledge_id)
        ).scalar_one_or_none()
        if not item:
            raise HTTPException(status_code=404, detail="Knowledge item not found")
        db.execute(sa_delete(DBKnowledgeTag).where(DBKnowledgeTag.knowledge_id == knowledge_id))
        db.execute(sa_delete(DBKnowledgeRelationship).where(
            (DBKnowledgeRelationship.source_id == knowledge_id)
            | (DBKnowledgeRelationship.target_id == knowledge_id)
        ))
        db.delete(item)
    return {"status": "deleted"}


# --- Tags ---

@router.get("/api/tags", response_model=list[TagResponse])
def list_tags():
    count_col = sa_func.count(DBKnowledgeTag.id).label("item_count")
    with get_db() as db:
        rows = db.execute(
            select(
                DBTag.id,
                DBTag.name,
                DBTag.created_at,
                count_col,
            )
            .outerjoin(DBKnowledgeTag, DBKnowledgeTag.tag_id == DBTag.id)
            .group_by(DBTag.id)
            .order_by(DBTag.name)
        ).all()
        return [
            TagResponse(id=r[0], name=r[1], count=r[3], created_at=to_iso_utc(r[2]))
            for r in rows
        ]


@router.post("/api/tags", response_model=TagResponse)
def create_tag(req: CreateTagRequest):
    with get_db() as db:
        existing = db.execute(
            select(DBTag).where(DBTag.name == req.name)
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(status_code=409, detail=f"Tag '{req.name}' already exists")
        tag = DBTag(name=req.name)
        db.add(tag)
        db.flush()
        return TagResponse(id=tag.id, name=tag.name, count=0, created_at=to_iso_utc(tag.created_at))


@router.delete("/api/tags/{tag_id}")
def delete_tag(tag_id: str):
    with get_db() as db:
        tag = db.execute(
            select(DBTag).where(DBTag.id == tag_id)
        ).scalar_one_or_none()
        if not tag:
            raise HTTPException(status_code=404, detail="Tag not found")
        db.execute(sa_delete(DBKnowledgeTag).where(DBKnowledgeTag.tag_id == tag_id))
        db.delete(tag)
    return {"status": "deleted"}


# --- Relationships ---

@router.get(
    "/api/knowledge/{knowledge_id}/relationships",
    response_model=list[KnowledgeRelationshipResponse],
)
def list_relationships(knowledge_id: str):
    with get_db() as db:
        rels = db.execute(
            select(DBKnowledgeRelationship).where(
                (DBKnowledgeRelationship.source_id == knowledge_id)
                | (DBKnowledgeRelationship.target_id == knowledge_id)
            ).order_by(DBKnowledgeRelationship.created_at.desc())
        ).scalars().all()
        results = []
        for rel in rels:
            if rel.target_id == knowledge_id and rel.source_id != knowledge_id:
                flipped = DBKnowledgeRelationship(
                    id=rel.id,
                    source_id=rel.target_id,
                    target_id=rel.source_id,
                    relation_type=rel.relation_type,
                    created_at=rel.created_at,
                    updated_at=rel.updated_at,
                )
                results.append(serialize_relationship(db, flipped))
            else:
                results.append(serialize_relationship(db, rel))
        return results


@router.post("/api/knowledge/relationships", response_model=KnowledgeRelationshipResponse)
def create_relationship(req: CreateRelationshipRequest):
    if req.relation_type not in RELATION_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid relation type. Must be one of: {RELATION_TYPES}")
    if req.source_id == req.target_id:
        raise HTTPException(status_code=400, detail="Cannot create a relationship to itself")
    with get_db() as db:
        for kid in [req.source_id, req.target_id]:
            exists = db.execute(
                select(DBKnowledge).where(DBKnowledge.id == kid)
            ).scalar_one_or_none()
            if not exists:
                raise HTTPException(status_code=404, detail=f"Knowledge item '{kid}' not found")

        existing = db.execute(
            select(DBKnowledgeRelationship).where(
                DBKnowledgeRelationship.source_id == req.source_id,
                DBKnowledgeRelationship.target_id == req.target_id,
                DBKnowledgeRelationship.relation_type == req.relation_type,
            )
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(status_code=409, detail="Relationship already exists")

        rel = DBKnowledgeRelationship(
            source_id=req.source_id,
            target_id=req.target_id,
            relation_type=req.relation_type,
        )
        db.add(rel)
        db.flush()
        return serialize_relationship(db, rel)


@router.delete("/api/knowledge/relationships/{relationship_id}")
def delete_relationship(relationship_id: str):
    with get_db() as db:
        rel = db.execute(
            select(DBKnowledgeRelationship).where(DBKnowledgeRelationship.id == relationship_id)
        ).scalar_one_or_none()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")
        db.delete(rel)
    return {"status": "deleted"}


@router.get("/api/knowledge/relationship-types")
def list_relationship_types():
    return RELATION_TYPES


