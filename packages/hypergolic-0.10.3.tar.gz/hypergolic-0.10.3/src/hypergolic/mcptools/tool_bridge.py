import logging
from typing import Any

from mcp.types import Tool as MCPTool
from pydantic import BaseModel, create_model, Field

from hypergolic.mcptools.client import get_mcp_manager
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput

logger = logging.getLogger(__name__)

JSON_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
}


def _build_mcp_input_model(server_name: str, mcp_tool: MCPTool) -> type[BaseModel]:
    schema = mcp_tool.inputSchema
    properties = schema.get("properties", {})
    required_fields = set(schema.get("required", []))

    if not properties:
        return create_model(f"mcp_{server_name}__{mcp_tool.name}_Input")

    field_definitions: dict[str, Any] = {}
    for prop_name, prop_schema in properties.items():
        prop_type = prop_schema.get("type", "string")
        description = prop_schema.get("description", "")

        if prop_type == "array":
            python_type: Any = list
        elif prop_type == "object":
            python_type = dict
        else:
            python_type = JSON_TYPE_MAP.get(prop_type, str)

        if prop_name in required_fields:
            field_definitions[prop_name] = (
                python_type,
                Field(description=description) if description else ...,
            )
        else:
            default = prop_schema.get("default")
            field_definitions[prop_name] = (
                python_type | None,
                Field(default=default, description=description),
            )

    return create_model(
        f"mcp_{server_name}__{mcp_tool.name}_Input",
        **field_definitions,
    )


async def _noop_call_tool(input: BaseModel, ctx: ToolContext) -> ToolOutput:
    return ToolOutput(
        content=[{"type": "text", "text": "MCP tools must be called via async handler."}],
        is_error=True,
    )


def parse_mcp_tool_id(tool_id: str) -> tuple[str, str] | None:
    if not tool_id.startswith("mcp_"):
        return None
    remainder = tool_id[4:]
    if "__" not in remainder:
        return None
    server_name, tool_name = remainder.split("__", 1)
    return server_name, tool_name


async def execute_mcp_tool(tool_id: str, raw_input: dict[str, Any]) -> ToolOutput:
    parsed = parse_mcp_tool_id(tool_id)
    if not parsed:
        return ToolOutput(
            content=[{"type": "text", "text": f"Invalid MCP tool id: {tool_id}"}],
            is_error=True,
        )

    server_name, tool_name = parsed
    manager = get_mcp_manager()

    try:
        result = await manager.call_tool(server_name, tool_name, raw_input)
        return ToolOutput(
            content=result["content"],
            is_error=result.get("is_error", False),
        )
    except Exception as e:
        logger.error("MCP tool '%s' failed: %s", tool_id, e, exc_info=True)
        return ToolOutput(
            content=[{"type": "text", "text": f"MCP tool error: {e}"}],
            is_error=True,
        )


def build_mcp_tool(server_name: str, mcp_tool: MCPTool) -> Tool:
    tool_id = f"mcp_{server_name}__{mcp_tool.name}"
    input_model = _build_mcp_input_model(server_name, mcp_tool)
    description = mcp_tool.description or f"MCP tool '{mcp_tool.name}' from server '{server_name}'"

    return Tool(
        id=tool_id,
        name=f"{server_name}: {mcp_tool.name}",
        description=description,
        strict=False,
        input=input_model,
        call_tool=_noop_call_tool,
    )


def get_mcp_tools_for_session(enabled_servers: set[str]) -> list[Tool]:
    manager = get_mcp_manager()
    tools: list[Tool] = []
    for server_name, server in manager.get_all_connected().items():
        if server_name not in enabled_servers:
            continue
        for mcp_tool in server.tools:
            tools.append(build_mcp_tool(server_name, mcp_tool))
    return tools
