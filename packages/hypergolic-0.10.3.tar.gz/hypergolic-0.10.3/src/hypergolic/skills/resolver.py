import logging
from pathlib import Path
from typing import Any

from sqlalchemy import select

from hypergolic.config.settings import PROMPTS_DIR
from hypergolic.config.schemas import CustomToolConfig
from hypergolic.config.settings import _load_user_config, load_project_config, load_user_project_config
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill

logger = logging.getLogger(__name__)

BUILT_IN_SKILLS: list[dict[str, Any]] = [
    {
        "id": "tool-builder",
        "name": "Tool & Skill Building",
        "description": "Build and improve custom tools, skills, and roles. Use whenever the user wants to create or refine an artifact, or when you notice a workflow that could be automated or a gap in the agent's capabilities.",
        "prompt_path": str(PROMPTS_DIR / "skills" / "tool-builder.md"),
        "tools": [],
        "source": "built-in",
    },
    {
        "id": "hypergolic-expertise",
        "name": "Hypergolic Expertise",
        "description": "Navigate Hypergolic internals, advise on configuration, and proactively improve the user's setup over time",
        "prompt_path": str(PROMPTS_DIR / "skills" / "hypergolic-expertise.md"),
        "tools": [],
        "source": "built-in",
    },
    {
        "id": "product-management",
        "name": "Product Management",
        "description": "Collaborate on requirements, challenge assumptions, define scope, and produce a PRD before implementation begins",
        "prompt_path": str(PROMPTS_DIR / "skills" / "product-management.md"),
        "tools": [],
        "source": "built-in",
    },
]

DEFAULT_ROLES: list[dict[str, Any]] = [
    {
        "id": "default",
        "name": "Default",
        "prompt_path": str(PROMPTS_DIR / "base_prompt.md"),
        "tools": [],
        "skills": [],
        "source": "built-in",
    },
    {
        "id": "reviewer",
        "name": "Code Review",
        "prompt_path": str(PROMPTS_DIR / "roles" / "reviewer.md"),
        "tools": [],
        "skills": [],
        "source": "built-in",
    },
]


def resolve_custom_tools(
    project_path: Path | None = None,
    active_skill_ids: set[str] | None = None,
) -> dict[str, CustomToolConfig]:
    """Collect all custom tools that should be available for this session.

    Availability is determined by where the tool is defined:
    - UserConfig.tools: always available (all sessions)
    - ProjectConfig.tools: available for that project's sessions
    - UserProjectConfig.tools: available for that specific project's sessions
    - SkillConfig.tools (any location): available only when that skill is active

    Later definitions with the same ID override earlier ones.
    """
    tools: dict[str, CustomToolConfig] = {}
    sources: dict[str, str] = {}
    skill_gated: dict[str, set[str]] = {}  # tool_id -> set of skill_ids that gate it

    user_config = _load_user_config()
    for tool in user_config.tools:
        tools[tool.id] = tool
        sources[tool.id] = "user"

    for skill in user_config.skills:
        for tool in skill.tools:
            tools[tool.id] = tool
            sources[tool.id] = "user"
            skill_gated.setdefault(tool.id, set()).add(skill.id)

    if project_path:
        project_config = load_project_config(project_path)
        for tool in project_config.tools:
            tools[tool.id] = tool
            sources[tool.id] = "project"

        for skill in project_config.skills:
            for tool in skill.tools:
                tools[tool.id] = tool
                sources[tool.id] = "project"
                skill_gated.setdefault(tool.id, set()).add(skill.id)

        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for tool in user_project_config.tools:
                tools[tool.id] = tool
                sources[tool.id] = "user-project"

    if skill_gated:
        active = active_skill_ids or set()
        for tool_id, required_skills in skill_gated.items():
            if not (required_skills & active):
                tools.pop(tool_id, None)
                sources.pop(tool_id, None)

    return tools


def resolve_custom_tool_sources(
    project_path: Path | None = None,
    active_skill_ids: set[str] | None = None,
) -> dict[str, str]:
    """Return a mapping of custom tool ID -> source level.

    Sources: 'user', 'project', 'user-project'.
    """
    sources: dict[str, str] = {}
    skill_gated: dict[str, set[str]] = {}

    user_config = _load_user_config()
    for tool in user_config.tools:
        sources[tool.id] = "user"

    for skill in user_config.skills:
        for tool in skill.tools:
            sources[tool.id] = "user"
            skill_gated.setdefault(tool.id, set()).add(skill.id)

    if project_path:
        project_config = load_project_config(project_path)
        for tool in project_config.tools:
            sources[tool.id] = "project"

        for skill in project_config.skills:
            for tool in skill.tools:
                sources[tool.id] = "project"
                skill_gated.setdefault(tool.id, set()).add(skill.id)

        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for tool in user_project_config.tools:
                sources[tool.id] = "user-project"

    if skill_gated:
        active = active_skill_ids or set()
        for tool_id, required_skills in skill_gated.items():
            if not (required_skills & active):
                sources.pop(tool_id, None)

    return sources


def resolve_roles(project_path: Path | None = None) -> list[dict[str, Any]]:
    seen_ids: set[str] = set()
    roles: list[dict[str, Any]] = []

    for role in DEFAULT_ROLES:
        roles.append(role)
        seen_ids.add(role["id"])

    user_config = _load_user_config()
    for role in user_config.roles:
        if role.id not in seen_ids:
            roles.append({
                "id": role.id,
                "name": role.name,
                "prompt_path": str(Path(role.prompt_path).expanduser()),
                "tools": list(role.tools),
                "skills": list(role.skills),
                "source": "user",
            })
            seen_ids.add(role.id)

    if project_path:
        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for role in user_project_config.roles:
                if role.id not in seen_ids:
                    roles.append({
                        "id": role.id,
                        "name": role.name,
                        "prompt_path": str(Path(role.prompt_path).expanduser()),
                        "tools": list(role.tools),
                        "skills": list(role.skills),
                        "source": "user-project",
                    })
                    seen_ids.add(role.id)

        project_config = load_project_config(project_path)
        for role in project_config.roles:
            if role.id not in seen_ids:
                roles.append({
                    "id": role.id,
                    "name": role.name,
                    "prompt_path": str((project_path / role.prompt_path).resolve()),
                    "tools": list(role.tools),
                    "skills": list(role.skills),
                    "source": "project",
                })
                seen_ids.add(role.id)

    return roles


def resolve_skills(project_path: Path | None = None) -> list[dict[str, Any]]:
    seen_ids: set[str] = set()
    skills: list[dict[str, Any]] = []

    for skill in BUILT_IN_SKILLS:
        skills.append(skill)
        seen_ids.add(skill["id"])

    user_config = _load_user_config()
    for skill in user_config.skills:
        if skill.id not in seen_ids:
            skills.append({
                "id": skill.id,
                "name": skill.name,
                "description": skill.description,
                "prompt_path": str(Path(skill.prompt_path).expanduser()),
                "tools": [t.id for t in skill.tools],
                "source": "user",
            })
            seen_ids.add(skill.id)

    if project_path:
        project_config = load_project_config(project_path)
        for skill in project_config.skills:
            if skill.id not in seen_ids:
                skills.append({
                    "id": skill.id,
                    "name": skill.name,
                    "description": skill.description,
                    "prompt_path": str((project_path / skill.prompt_path).resolve()),
                    "tools": [t.id for t in skill.tools],
                    "source": "project",
                })
                seen_ids.add(skill.id)

        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for skill_id in user_project_config.skills:
                if skill_id not in seen_ids:
                    logger.warning("User-project references unknown skill '%s'", skill_id)

    return skills


def get_skill_prompt_content(skill_id: str, project_path: Path | None = None) -> tuple[str, str | None] | None:
    """Returns (name, prompt_content) for a skill, or None if not found.

    If the skill exists but its prompt file is missing, returns (name, None).
    """
    for skill in resolve_skills(project_path):
        if skill["id"] == skill_id:
            prompt_path = Path(skill["prompt_path"])
            if prompt_path.exists():
                content = prompt_path.read_text()
                return skill["name"], content
            return skill["name"], None
    return None


def get_active_skill_ids(session_id: str) -> set[str]:
    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill.skill_id)
            .where(DBSessionSkill.session_id == session_id)
        ).scalars().all()
    return set(rows)


def get_active_skill_prompts(session_id: str, project_path: Path | None = None) -> list[tuple[str, str]]:
    with get_db() as db:
        active_ids = list(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
                .order_by(DBSessionSkill.created_at)
            ).scalars().all()
        )

    if not active_ids:
        return []

    all_skills = {s["id"]: s for s in resolve_skills(project_path)}
    results: list[tuple[str, str]] = []
    for sid in active_ids:
        skill = all_skills.get(sid)
        if not skill:
            continue
        prompt_path = Path(skill["prompt_path"])
        if prompt_path.exists():
            results.append((skill["name"], prompt_path.read_text()))
    return results
