import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, ValidationError

from hypergolic.config.schemas import ProjectConfig, UserConfig, UserProjectConfig
from hypergolic.config.settings import USER_CONFIG_PATH
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput


class EditConfigInput(BaseModel):
    target: Literal["user", "project", "user-project"] = Field(
        description="Which config to edit: 'user' for ~/.agents/config.json, 'project' for .agents/config.json, 'user-project' to upsert a project entry in ~/.agents/config.json (content must include git_root).",
    )
    content: str = Field(
        description="The full JSON content for the config file.",
    )


async def edit_config(input: EditConfigInput, ctx: ToolContext) -> ToolOutput:
    try:
        data = json.loads(input.content)
    except json.JSONDecodeError as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Invalid JSON: {e}"}],
            is_error=True,
        )

    if input.target == "user-project":
        return _edit_user_project(data)

    schema_class = UserConfig if input.target == "user" else ProjectConfig
    try:
        schema_class.model_validate(data)
    except ValidationError as e:
        return _validation_error(e)

    if input.target == "user":
        config_path = USER_CONFIG_PATH
    else:
        config_path = ctx.session.working_directory() / ".agents" / "config.json"

    config_path.parent.mkdir(parents=True, exist_ok=True)

    formatted = json.dumps(data, indent=2) + "\n"
    config_path.write_text(formatted, encoding="utf-8")

    return ToolOutput(
        content=[{"type": "text", "text": f"Successfully wrote {config_path}"}],
    )


def _validation_error(e: ValidationError) -> ToolOutput:
    error_lines = ["Schema validation failed:", ""]
    for err in e.errors():
        loc = " → ".join(str(part) for part in err["loc"])
        error_lines.append(f"  {loc}: {err['msg']}")
    return ToolOutput(
        content=[{"type": "text", "text": "\n".join(error_lines)}],
        is_error=True,
    )


def _edit_user_project(data: dict) -> ToolOutput:
    try:
        UserProjectConfig.model_validate(data)
    except ValidationError as e:
        return _validation_error(e)

    git_root = data.get("git_root", "")
    if not git_root:
        return ToolOutput(
            content=[{"type": "text", "text": "user-project content must include 'git_root'."}],
            is_error=True,
        )

    config_path = USER_CONFIG_PATH
    if config_path.exists():
        try:
            user_data = json.loads(config_path.read_text())
        except (json.JSONDecodeError, OSError):
            user_data = {}
    else:
        user_data = {}

    projects = user_data.get("projects", [])
    resolved_root = str(Path(git_root).resolve())
    replaced = False
    for i, proj in enumerate(projects):
        if str(Path(proj.get("git_root", "")).resolve()) == resolved_root:
            projects[i] = data
            replaced = True
            break
    if not replaced:
        projects.append(data)

    user_data["projects"] = projects

    try:
        UserConfig.model_validate(user_data)
    except ValidationError as e:
        return _validation_error(e)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    formatted = json.dumps(user_data, indent=2) + "\n"
    config_path.write_text(formatted, encoding="utf-8")

    action = "Updated" if replaced else "Added"
    return ToolOutput(
        content=[{"type": "text", "text": f"{action} project '{git_root}' in {config_path}"}],
    )


EditConfigTool = Tool(
    id="edit_config",
    name="Edit Config",
    description="Edit a Hypergolic config file. Validates against the schema before writing. See 'target' field for options.",
    strict=True,
    input=EditConfigInput,
    call_tool=edit_config,
)
