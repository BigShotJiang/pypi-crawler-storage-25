from pydantic import BaseModel, Field

from hypergolic.tools.paths import resolve_path
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput


class WriteFileEntry(BaseModel):
    path: str = Field(
        description="File path to write.",
    )
    content: str = Field(
        description="Complete file contents (replaces existing).",
    )


class WriteFilesInput(BaseModel):
    files: list[WriteFileEntry] = Field(
        description="Files to write.",
    )


async def write_files(input: WriteFilesInput, ctx: ToolContext) -> ToolOutput:
    results = []
    has_error = False

    for entry in input.files:
        path = resolve_path(entry.path, ctx.session)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            created = not path.exists()
            path.write_text(entry.content, encoding="utf-8")
            verb = "Created" if created else "Updated"
            results.append({"type": "text", "text": f"{verb} {entry.path}"})
        except PermissionError:
            results.append(
                {
                    "type": "text",
                    "text": f"Error writing {entry.path}: Permission denied",
                }
            )
            has_error = True
        except Exception as e:
            results.append(
                {"type": "text", "text": f"Error writing {entry.path}: {str(e)}"}
            )
            has_error = True

    if not results:
        return ToolOutput(content=[{"type": "text", "text": "No files provided to write."}])

    return ToolOutput(content=results, is_error=has_error)


WriteFilesTool = Tool(
    id="write_files",
    name="Write Files",
    description="Write content to one or more files. Creates parent directories as needed.",
    strict=True,
    input=WriteFilesInput,
    call_tool=write_files,
)
