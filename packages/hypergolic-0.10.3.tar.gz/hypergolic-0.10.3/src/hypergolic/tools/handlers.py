from dataclasses import dataclass
from typing import Any, Callable, Awaitable

from anthropic.types import MessageParam, ToolResultBlockParam, ToolUseBlock
from anthropic.types.message import Message

from hypergolic.mcptools.tool_bridge import execute_mcp_tool
from hypergolic.messages.types import BroadcastFn
from hypergolic.tools.approval import (
    RuleAction,
    get_effective_action,
)
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput

import logging

from anthropic.types.tool_result_block_param import Content

logger = logging.getLogger(__name__)

MAX_TOOL_OUTPUT_CHARS = 80_000


def _result_block(tool_use_id: str, output: ToolOutput) -> ToolResultBlockParam:
    return ToolResultBlockParam(
        tool_use_id=tool_use_id,
        type="tool_result",
        content=output.content,
        is_error=output.is_error,
    )


def _truncate_tool_output(output: ToolOutput, limit: int = MAX_TOOL_OUTPUT_CHARS) -> ToolOutput:
    total_chars = 0
    for block in output.content:
        if isinstance(block, dict) and block.get("type") == "text":
            total_chars += len(block.get("text", ""))

    if total_chars <= limit:
        return output

    truncated_content: list[Content] = []
    remaining = limit

    for block in output.content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text", "")
            if len(text) <= remaining:
                truncated_content.append(block)
                remaining -= len(text)
            elif remaining > 0:
                truncated_content.append({"type": "text", "text": text[:remaining]})
                remaining = 0
        else:
            truncated_content.append(block)

    truncated_content.append({
        "type": "text",
        "text": f"\n\n[Output truncated: {total_chars:,} chars exceeded {limit:,} char limit. Request smaller ranges or more specific queries.]",
    })

    logger.warning("Tool output truncated: %s chars -> %s char limit", total_chars, limit)

    return ToolOutput(content=truncated_content, is_error=output.is_error)


@dataclass
class ToolUseResult:
    message: MessageParam
    should_truncate: bool = False


@dataclass
class DisplayBlock:
    field: str
    type: str
    label: str
    value: Any


@dataclass
class ApprovalRequest:
    tool_use_id: str
    tool_name: str
    tool_input: dict[str, Any]
    display_blocks: list[DisplayBlock] | None = None


@dataclass
class AnnotationItem:
    highlighted_text: str
    comment: str


@dataclass
class ApprovalResponse:
    approved: bool
    denial_reason: str | None = None
    annotations: list[AnnotationItem] | None = None


ApprovalCallback = Callable[[ApprovalRequest], Awaitable[ApprovalResponse]]


async def _execute_tool(tool: Tool, raw_input: Any, ctx: ToolContext) -> ToolOutput:
    try:
        parsed_input = tool.input.model_validate(raw_input)
        return await tool.call_tool(parsed_input, ctx)
    except Exception as e:
        logger.error("Tool '%s' failed: %s", tool.id, e, exc_info=True)
        return ToolOutput(
            content=[{"type": "text", "text": f"Error with tool call: {e}"}],
            is_error=True,
        )


async def handle_tool_use(
    agent_message: Message,
    tools: list[Tool],
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None = None,
) -> ToolUseResult:
    tool_map = {tool.id: tool for tool in tools}
    tool_result_blocks: list[ToolResultBlockParam] = []
    trigger_truncation = False

    for content in agent_message.content:
        if not isinstance(content, ToolUseBlock):
            continue

        tool = tool_map.get(content.name)
        if tool is None:
            logger.error("Tool '%s' not found in tool_map (available: %s)", content.name, list(tool_map.keys()))
            block = ToolResultBlockParam(
                tool_use_id=content.id,
                type="tool_result",
                content=f"Tool '{content.name}' is not available. Check active skills and available tools.",
                is_error=True,
            )
            tool_result_blocks.append(block)
            continue

        tool_input = content.input if isinstance(content.input, dict) else {}
        action = get_effective_action(
            content.name, tool_input,
            project_id=session.project_id,
            session_id=session.id,
            project_path=session.project_path,
        )

        if action == RuleAction.DENY:
            tool_result_blocks.append(_result_block(content.id, ToolOutput(
                content=[{"type": "text", "text": "Tool call denied by approval rule."}],
                is_error=True,
            )))
            continue

        if tool.requires_approval:
            action = RuleAction.REQUIRE_APPROVAL

        approved_annotations: list[AnnotationItem] | None = None
        if action == RuleAction.REQUIRE_APPROVAL:
            if approval_callback:
                display_blocks = None
                if tool.display:
                    display_blocks = [
                        DisplayBlock(
                            field=fname,
                            type=rtype,
                            label=fname.replace("_", " ").title(),
                            value=tool_input.get(fname),
                        )
                        for fname, rtype in tool.display.items()
                        if tool_input.get(fname) is not None
                    ]
                request = ApprovalRequest(
                    tool_use_id=content.id,
                    tool_name=content.name,
                    tool_input=tool_input,
                    display_blocks=display_blocks,
                )
                response = await approval_callback(request)

                if not response.approved:
                    denial_text = "User denied tool call."
                    if response.denial_reason:
                        denial_text += f" Reason: {response.denial_reason}"
                    if response.annotations:
                        denial_text += "\n\nUser annotations:\n"
                        for ann in response.annotations:
                            denial_text += f"- \"{ann.highlighted_text}\": {ann.comment}\n"
                    tool_result_blocks.append(_result_block(content.id, ToolOutput(
                        content=[{"type": "text", "text": denial_text}],
                        is_error=True,
                    )))
                    continue

                approved_annotations = response.annotations

        if content.name.startswith("mcp_"):
            raw = content.input if isinstance(content.input, dict) else {}
            output = await execute_mcp_tool(content.name, raw)
        else:
            ctx = ToolContext(
                session=session,
                broadcast=broadcast,
                tool_id=tool.id,
            )
            output = await _execute_tool(tool, content.input, ctx)

        output = _truncate_tool_output(output)

        if (tool.should_truncate or output.should_truncate) and not output.is_error:
            trigger_truncation = True

        if approved_annotations and not output.is_error:
            annotation_text = "\n\nUser feedback on this artifact:\n"
            for ann in approved_annotations:
                annotation_text += f"- \"{ann.highlighted_text}\": {ann.comment}\n"
            output = ToolOutput(
                content=[*output.content, {"type": "text", "text": annotation_text}],
                is_error=output.is_error,
                should_truncate=output.should_truncate,
            )

        tool_result_blocks.append(_result_block(content.id, output))

    return ToolUseResult(
        message=MessageParam(role="user", content=tool_result_blocks),
        should_truncate=trigger_truncation,
    )
