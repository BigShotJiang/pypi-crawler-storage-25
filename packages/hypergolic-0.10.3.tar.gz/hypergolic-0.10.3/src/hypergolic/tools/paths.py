from pathlib import Path

from hypergolic.schemas import Session


def resolve_path(path: str, session: Session) -> Path:
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    return p
