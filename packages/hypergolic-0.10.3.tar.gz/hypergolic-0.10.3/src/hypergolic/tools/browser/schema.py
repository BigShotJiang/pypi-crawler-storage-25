from typing import Literal, Optional

from pydantic import BaseModel, Field

BROWSER_COMMANDS = Literal[
    "start",
    "stop",
    "status",
    "help",
    "open",
    "back",
    "forward",
    "reload",
    "clear_cache",
    "url",
    "title",
    "text",
    "html",
    "attr",
    "pdf",
    "js",
    "click",
    "input",
    "clear",
    "file",
    "select",
    "submit",
    "hover",
    "focus",
    "wait",
    "waitload",
    "waitstable",
    "waitidle",
    "sleep",
    "screenshot",
    "screenshot_element",
    "pages",
    "page",
    "newpage",
    "closepage",
    "exists",
    "count",
    "visible",
    "assert",
    "ax_tree",
    "ax_find",
    "ax_node",
    "download",
]


class BrowserInput(BaseModel):
    command: BROWSER_COMMANDS = Field(
        description="The browser command to execute.",
    )
    url: Optional[str] = Field(
        default=None,
        description="URL to navigate to.",
    )
    selector: Optional[str] = Field(
        default=None,
        description="CSS selector for element targeting.",
    )
    expression: Optional[str] = Field(
        default=None,
        description="JavaScript expression (for 'js', 'assert').",
    )
    text: Optional[str] = Field(
        default=None,
        description="Text to type, value to select, or expected value for assert.",
    )
    attribute: Optional[str] = Field(
        default=None,
        description="Attribute name to read (for 'attr').",
    )
    file_path: Optional[str] = Field(
        default=None,
        description="File path for screenshots, pdf, file input, or download.",
    )
    width: Optional[int] = Field(
        default=None,
        description="Viewport width in pixels (for 'screenshot').",
    )
    height: Optional[int] = Field(
        default=None,
        description="Viewport height in pixels (for 'screenshot').",
    )
    tab_index: Optional[int] = Field(
        default=None,
        description="Tab index (for 'page', 'closepage').",
    )
    hard: bool = Field(
        default=False,
        description="Bypass cache on reload.",
    )
    seconds: Optional[float] = Field(
        default=None,
        description="Number of seconds (for 'sleep').",
    )
    role: Optional[str] = Field(
        default=None,
        description="Accessibility role filter (for 'ax_find').",
    )
    name: Optional[str] = Field(
        default=None,
        description="Accessible name filter (for 'ax_find').",
    )
    depth: Optional[int] = Field(
        default=None,
        description="Tree depth limit (for 'ax_tree').",
    )
    json_output: bool = Field(
        default=False,
        description="Output as JSON (for 'ax_tree', 'ax_find', 'ax_node').",
    )
    message: Optional[str] = Field(
        default=None,
        description="Custom failure message (for 'assert').",
    )
    insecure: bool = Field(
        default=False,
        description="Ignore TLS errors (for 'start').",
    )
    use_local: bool = Field(
        default=True,
        description="Use directory-scoped session. False for global.",
    )
