from hypergolic.tools.browser.schema import BrowserInput

COMMAND_TO_RODNEY = {
    "clear_cache": "clear-cache",
    "screenshot_element": "screenshot-el",
    "ax_tree": "ax-tree",
    "ax_find": "ax-find",
    "ax_node": "ax-node",
}


def build_args(inp: BrowserInput) -> list[str]:
    rodney_cmd = COMMAND_TO_RODNEY.get(inp.command, inp.command)
    args = [rodney_cmd]

    if inp.command == "start":
        if inp.insecure:
            args.append("--insecure")
        return args

    if inp.command == "open":
        if not inp.url:
            return []
        args.append(inp.url)
        return args

    if inp.command == "reload":
        if inp.hard:
            args.append("--hard")
        return args

    if inp.command in ("click", "clear", "submit", "hover", "focus", "wait"):
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "input":
        if inp.selector:
            args.append(inp.selector)
        if inp.text is not None:
            args.append(inp.text)
        return args

    if inp.command == "text":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "html":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "attr":
        if inp.selector:
            args.append(inp.selector)
        if inp.attribute:
            args.append(inp.attribute)
        return args

    if inp.command == "js":
        if inp.expression:
            args.append(inp.expression)
        return args

    if inp.command == "assert":
        if inp.expression:
            args.append(inp.expression)
        if inp.text is not None:
            args.append(inp.text)
        if inp.message:
            args.extend(["--message", inp.message])
        return args

    if inp.command == "select":
        if inp.selector:
            args.append(inp.selector)
        if inp.text is not None:
            args.append(inp.text)
        return args

    if inp.command == "file":
        if inp.selector:
            args.append(inp.selector)
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "download":
        if inp.selector:
            args.append(inp.selector)
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "screenshot":
        if inp.width:
            args.extend(["-w", str(inp.width)])
        if inp.height:
            args.extend(["-h", str(inp.height)])
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "screenshot_element":
        if inp.selector:
            args.append(inp.selector)
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "pdf":
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "page":
        if inp.tab_index is not None:
            args.append(str(inp.tab_index))
        return args

    if inp.command == "newpage":
        if inp.url:
            args.append(inp.url)
        return args

    if inp.command == "closepage":
        if inp.tab_index is not None:
            args.append(str(inp.tab_index))
        return args

    if inp.command == "sleep":
        if inp.seconds is not None:
            args.append(str(inp.seconds))
        return args

    if inp.command == "exists":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "count":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "visible":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "ax_tree":
        if inp.depth is not None:
            args.extend(["--depth", str(inp.depth)])
        if inp.json_output:
            args.append("--json")
        return args

    if inp.command == "ax_find":
        if inp.role:
            args.extend(["--role", inp.role])
        if inp.name:
            args.extend(["--name", inp.name])
        if inp.json_output:
            args.append("--json")
        return args

    if inp.command == "ax_node":
        if inp.selector:
            args.append(inp.selector)
        if inp.json_output:
            args.append("--json")
        return args

    return args
