import base64
import shutil
import subprocess
from pathlib import Path

from hypergolic.tools.browser.args import build_args
from hypergolic.tools.browser.schema import BrowserInput
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.tools.subprocess_util import run_subprocess

RODNEY_BIN = "rodney"

SCREENSHOT_MEDIA_TYPES: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _read_screenshot_block(file_path: str | None, default: str = "screenshot.png") -> dict | None:
    path = Path(file_path or default)
    if not path.is_file():
        return None
    media_type = SCREENSHOT_MEDIA_TYPES.get(path.suffix.lower())
    if not media_type:
        return None
    data = base64.standard_b64encode(path.read_bytes()).decode("ascii")
    return {
        "type": "image",
        "source": {
            "type": "base64",
            "media_type": media_type,
            "data": data,
        },
    }


async def run_browser(inp: BrowserInput, ctx: ToolContext) -> ToolOutput:
    rodney = shutil.which(RODNEY_BIN)
    if not rodney:
        return ToolOutput(
            content=[{"type": "text", "text": f"'{RODNEY_BIN}' is not installed or not found in PATH. Install it with: uv tool install rodney"}],
            is_error=True,
        )

    sub_args = build_args(inp)
    if not sub_args:
        return ToolOutput(
            content=[{"type": "text", "text": f"Missing required parameters for command '{inp.command}'."}],
            is_error=True,
        )

    cmd = [rodney]
    if inp.use_local:
        cmd.append("--local")
    else:
        cmd.append("--global")
    cmd.extend(sub_args)

    if inp.command == "help":
        cmd = [rodney, "--help"]
        try:
            result = await run_subprocess(cmd, timeout=10)
            text = result.stdout.strip() or result.stderr.strip() or "(no output)"
            return ToolOutput(content=[{"type": "text", "text": text}])
        except Exception as e:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error getting help: {e}"}],
                is_error=True,
            )

    timeout = 60 if inp.command in ("start", "stop", "screenshot", "screenshot_element", "pdf", "waitload", "waitstable", "waitidle", "download") else 30

    cwd = str(ctx.session.working_directory())

    try:
        result = await run_subprocess(
            cmd,
            timeout=timeout,
            cwd=cwd,
        )

        output_parts = []
        if result.stdout:
            output_parts.append(result.stdout.rstrip())
        if result.stderr:
            output_parts.append(f"STDERR: {result.stderr.rstrip()}")

        text = "\n".join(output_parts) if output_parts else "(no output)"

        is_error = result.returncode >= 2

        content: list = [{"type": "text", "text": text}]

        if not is_error and inp.command in ("screenshot", "screenshot_element"):
            image_block = _read_screenshot_block(inp.file_path)
            if image_block:
                content.append(image_block)

        return ToolOutput(
            content=content,
            is_error=is_error,
        )

    except subprocess.TimeoutExpired:
        return ToolOutput(
            content=[{"type": "text", "text": f"Browser command '{inp.command}' timed out after {timeout} seconds."}],
            is_error=True,
        )
    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error running browser command: {e}"}],
            is_error=True,
        )


BrowserTool = Tool(
    id="browser",
    name="Browser",
    description="Control a headless Chrome browser via rodney CLI. Call 'start' before other commands, 'help' for usage details.",
    strict=True,
    input=BrowserInput,
    call_tool=run_browser,
)
