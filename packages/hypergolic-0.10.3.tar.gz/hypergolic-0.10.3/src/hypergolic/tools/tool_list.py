import logging
from copy import deepcopy

from anthropic.types import ToolUnionParam
from hypergolic.mcptools.tool_bridge import get_mcp_tools_for_session
from hypergolic.schemas import Session
from hypergolic.tools.browser.tool import BrowserTool
from hypergolic.tools.command import CommandTool
from hypergolic.tools.config import EditConfigTool
from hypergolic.tools.custom import build_custom_tool
from hypergolic.tools.delete_files import DeleteFilesTool
from hypergolic.tools.edit_file import EditFilesTool
from hypergolic.tools.list_files import ListFilesTool
from hypergolic.tools.make_directory import MakeDirectoryTool
from hypergolic.tools.manage_mcp import ManageMCPTool, get_enabled_servers
from hypergolic.tools.read_files import ReadFilesTool
from hypergolic.tools.search_files import SearchFilesTool
from hypergolic.tools.write_file import WriteFilesTool
from hypergolic.tools.history import HistoryTool
from hypergolic.tools.knowledge import KnowledgeTool
from hypergolic.tools.git import GitTool
from hypergolic.tools.schemas import Tool
from hypergolic.tools.skills import build_skills_tool
from hypergolic.tools.summarize import SummarizeTool
from hypergolic.skills.resolver import get_active_skill_ids, resolve_custom_tools, resolve_custom_tool_sources
from hypergolic.tools.activate_workflow import build_activate_workflow_tool
from hypergolic.workflows.tools import build_workflow_tools

logger = logging.getLogger(__name__)

STANDARD_TOOLS: list[Tool] = [
    ListFilesTool,
    ReadFilesTool,
    SearchFilesTool,
    CommandTool,
    WriteFilesTool,
    EditFilesTool,
    MakeDirectoryTool,
    DeleteFilesTool,
    KnowledgeTool,
    HistoryTool,
    ManageMCPTool,
    BrowserTool,
    GitTool,
    SummarizeTool,
]

SKILL_TOOLS: dict[str, list[Tool]] = {
    "hypergolic-expertise": [EditConfigTool],
    "tool-builder": [EditConfigTool],
}


class BuildToolsResult:
    __slots__ = ("tools", "custom_sources")

    def __init__(self, tools: list[Tool], custom_sources: dict[str, str]):
        self.tools = tools
        self.custom_sources = custom_sources


def build_tools(session: Session) -> BuildToolsResult:
    tools: list[Tool] = list(STANDARD_TOOLS)
    tool_ids = {t.id for t in tools}

    active_skills = get_active_skill_ids(session.id)
    for skill_id in active_skills:
        for tool in SKILL_TOOLS.get(skill_id, []):
            if tool.id not in tool_ids:
                tools.append(tool)
                tool_ids.add(tool.id)

    project_path = session.working_directory()
    custom_tools = resolve_custom_tools(project_path, active_skills)
    custom_sources = resolve_custom_tool_sources(project_path, active_skills)

    for config in custom_tools.values():
        if config.id in tool_ids:
            logger.warning("Custom tool '%s' conflicts with a built-in tool, skipping", config.id)
            continue
        tools.append(build_custom_tool(config))
        tool_ids.add(config.id)

    skills_tool = build_skills_tool(project_path)
    if skills_tool:
        tools.append(skills_tool)

    workflow_tool = build_activate_workflow_tool(project_path, session.id)
    if workflow_tool:
        tools.append(workflow_tool)

    enabled_servers = get_enabled_servers(session.id)
    if enabled_servers:
        mcp_tools = get_mcp_tools_for_session(enabled_servers)
        tools.extend(mcp_tools)

    workflow_tools = build_workflow_tools(session)
    for wt in workflow_tools:
        if wt.id not in tool_ids:
            tools.append(wt)
            tool_ids.add(wt.id)

    return BuildToolsResult(tools, custom_sources)


def _all_builtin_tool_ids() -> set[str]:
    ids = {t.id for t in STANDARD_TOOLS}
    for skill_tools in SKILL_TOOLS.values():
        ids.update(t.id for t in skill_tools)
    return ids


def get_tool_source(tool_id: str, custom_sources: dict[str, str] | None = None) -> str:
    if tool_id in _all_builtin_tool_ids() or tool_id == "skills":
        return "standard"
    if tool_id.startswith("mcp_"):
        return "mcp"
    if custom_sources and tool_id in custom_sources:
        return custom_sources[tool_id]
    return "user"


def get_tool_schemas(tools: list[Tool]) -> list[ToolUnionParam]:
    return [t.to_param() for t in tools]


def set_tools_cache_breakpoint(
    tool_schemas: list[ToolUnionParam],
) -> list[ToolUnionParam]:
    schemas = deepcopy(tool_schemas)
    schemas[-1]["cache_control"] = {"type": "ephemeral"}
    return schemas
