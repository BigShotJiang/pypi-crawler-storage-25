import os
import subprocess
from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.tools.subprocess_util import run_subprocess


class CommandInput(BaseModel):
    command: str = Field(
        description="Command to execute",
    )
    reason: str = Field(
        description="A detailed explanation of: (1) why none of the existing tools (file operations, search, git, browser, knowledge, etc.) can accomplish this task, (2) what specific capability is missing, and (3) a concrete recommendation for a new tool or enhancement to an existing tool that would eliminate the need to run this command in the future",
    )
    working_directory: Optional[str] = Field(
        default=None,
        description="Working dir. Defaults to session dir",
    )
    timeout: Optional[int] = Field(
        default=10,
        description="Max seconds to wait",
    )
    env: Optional[dict[str, str]] = Field(
        default=None,
        description="Extra environment variables, merged with current env",
    )


async def run_command(input: CommandInput, ctx: ToolContext) -> ToolOutput:
    env = os.environ.copy()
    if input.env:
        env.update(input.env)

    cwd = input.working_directory or str(ctx.session.working_directory())

    try:
        result = await run_subprocess(
            input.command,
            shell=True,
            timeout=input.timeout,
            cwd=cwd,
            env=env,
        )

        output_parts = []

        if result.stdout:
            output_parts.append(f"STDOUT:\n{result.stdout}")

        if result.stderr:
            output_parts.append(f"STDERR:\n{result.stderr}")

        output_parts.append(f"Exit code: {result.returncode}")

        text = "\n\n".join(output_parts)
        return ToolOutput(
            content=[{"type": "text", "text": text}],
            is_error=result.returncode != 0,
        )

    except subprocess.TimeoutExpired:
        return ToolOutput(
            content=[
                {
                    "type": "text",
                    "text": f"Command timed out after {input.timeout} seconds.",
                }
            ],
            is_error=True,
        )
    except FileNotFoundError:
        return ToolOutput(
            content=[{"type": "text", "text": f"Working directory not found: {cwd}"}],
            is_error=True,
        )
    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error executing command: {str(e)}"}],
            is_error=True,
        )


CommandTool = Tool(
    id="command",
    name="Command",
    description="Execute a shell command as a last resort when no existing tool can accomplish the task. Requires user approval. In the 'reason' parameter, you MUST explain in detail: which tools you considered and why they fall short, what capability gap exists, and how the tooling could be improved (new tool or enhancement) so this command would not need to be used for this purpose again.",
    strict=True,
    input=CommandInput,
    call_tool=run_command,
)
