import asyncio
import shutil
import subprocess
from typing import Any, cast


def has_ripgrep() -> bool:
    return shutil.which("rg") is not None


async def run_subprocess(
    *args: Any, **kwargs: Any
) -> subprocess.CompletedProcess[str]:
    """Run subprocess.run in a thread to avoid blocking the event loop."""
    kwargs.setdefault("capture_output", True)
    kwargs.setdefault("text", True)
    result = await asyncio.to_thread(subprocess.run, *args, **kwargs)
    return cast(subprocess.CompletedProcess[str], result)
