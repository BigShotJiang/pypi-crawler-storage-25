import asyncio
import subprocess
from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.tools.paths import resolve_path
from hypergolic.tools.python_search import PythonSearchParams, python_search
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.tools.subprocess_util import has_ripgrep, run_subprocess

MAX_LINE_LENGTH = 1000


class SearchFilesInput(BaseModel):
    pattern: str = Field(
        description="Search pattern. Regex by default.",
    )
    directory: Optional[str] = Field(
        default=".",
        description="Directory to search within.",
    )
    file_glob: Optional[str] = Field(
        default=None,
        description="Glob pattern to filter files (e.g., '*.py').",
    )
    case_sensitive: bool = Field(
        default=True,
        description="Case-sensitive matching.",
    )
    fixed_string: bool = Field(
        default=False,
        description="Treat pattern as literal string, not regex.",
    )
    include_hidden: bool = Field(
        default=False,
        description="Include hidden files/directories.",
    )
    context_lines: Optional[int] = Field(
        default=0,
        description="Context lines before/after each match.",
    )
    max_results: Optional[int] = Field(
        default=100,
        description="Max matching lines to return.",
    )
    max_depth: Optional[int] = Field(
        default=None,
        description="Max directory depth to search.",
    )
    invert_match: bool = Field(
        default=False,
        description="Return non-matching lines.",
    )
    files_only: bool = Field(
        default=False,
        description="Return only file paths, not matched lines.",
    )
    multiline: bool = Field(
        default=False,
        description="Match across multiple lines.",
    )


def _truncate_line(line: str, limit: int = MAX_LINE_LENGTH) -> str:
    if len(line) <= limit or line == "--":
        return line
    return line[:limit] + " … [line truncated]"


def _format_result(result: subprocess.CompletedProcess, input: SearchFilesInput) -> ToolOutput:
    if result.returncode == 1 and not result.stderr:
        return ToolOutput(
            content=[{"type": "text", "text": f"No matches found for pattern: {input.pattern}"}],
        )

    if result.returncode > 1 and result.stderr:
        return ToolOutput(
            content=[{"type": "text", "text": f"Search error: {result.stderr.strip()}"}],
            is_error=True,
        )

    output = result.stdout.strip()
    if not output:
        return ToolOutput(
            content=[{"type": "text", "text": f"No matches found for pattern: {input.pattern}"}],
        )

    lines = output.split("\n")
    if not input.files_only:
        lines = [_truncate_line(line) for line in lines]
    non_context_lines = [line for line in lines if line and not line.startswith("--")]
    match_count = len(non_context_lines)

    truncated_output = "\n".join(lines)
    summary = f"Found {match_count} matching {'files' if input.files_only else 'lines'}:\n\n"
    return ToolOutput(content=[{"type": "text", "text": summary + truncated_output}])


async def _search_with_rg(input: SearchFilesInput, directory: str) -> subprocess.CompletedProcess:
    cmd = ["rg"]

    if input.fixed_string:
        cmd.append("--fixed-strings")
    if not input.case_sensitive:
        cmd.append("--ignore-case")
    if input.invert_match:
        cmd.append("--invert-match")
    if input.files_only:
        cmd.append("--files-with-matches")
    if input.multiline:
        cmd.append("--multiline")
    if input.file_glob:
        cmd.extend(["-g", input.file_glob])
    if input.include_hidden:
        cmd.append("--hidden")
    if input.max_depth is not None:
        cmd.extend(["--max-depth", str(input.max_depth)])
    if input.context_lines is not None and input.context_lines > 0 and not input.files_only:
        cmd.extend(["-C", str(input.context_lines)])
    if input.max_results is not None:
        cmd.extend(["--max-count", str(input.max_results)])
    if not input.files_only:
        cmd.append("--line-number")

    cmd.append("--color=never")
    cmd.append(input.pattern)
    cmd.append(directory)

    return await run_subprocess(cmd, timeout=30)


async def _search_with_python(input: SearchFilesInput, directory: str) -> subprocess.CompletedProcess:
    params = PythonSearchParams(
        pattern=input.pattern,
        directory=directory,
        fixed_string=input.fixed_string,
        case_sensitive=input.case_sensitive,
        include_hidden=input.include_hidden,
        file_glob=input.file_glob,
        max_depth=input.max_depth,
        context_lines=input.context_lines or 0,
        max_results=input.max_results,
        invert_match=input.invert_match,
        files_only=input.files_only,
        multiline=input.multiline,
        show_line_numbers=not input.files_only,
    )
    return await asyncio.to_thread(python_search, params)


async def search_files(input: SearchFilesInput, ctx: ToolContext) -> ToolOutput:
    directory = str(resolve_path(input.directory or ".", ctx.session))

    try:
        if has_ripgrep():
            result = await _search_with_rg(input, directory)
        else:
            result = await _search_with_python(input, directory)
        return _format_result(result, input)

    except subprocess.TimeoutExpired:
        return ToolOutput(
            content=[{"type": "text", "text": "Search timed out after 30 seconds. Try narrowing the search with a more specific pattern, file_glob, or directory."}],
            is_error=True,
        )
    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error during search: {str(e)}"}],
            is_error=True,
        )


SearchFilesTool = Tool(
    id="search_files",
    name="Search Files",
    description="Search file contents with ripgrep. Regex by default.",
    strict=True,
    input=SearchFilesInput,
    call_tool=search_files,
)
