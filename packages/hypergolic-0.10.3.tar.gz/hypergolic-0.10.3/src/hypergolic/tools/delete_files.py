from pydantic import BaseModel, Field

from hypergolic.tools.paths import resolve_path
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput


class DeleteFilesInput(BaseModel):
    paths: list[str] = Field(
        description="File paths to delete.",
    )


async def delete_files(input: DeleteFilesInput, ctx: ToolContext) -> ToolOutput:
    results = []
    has_error = False

    for file_path in input.paths:
        path = resolve_path(file_path, ctx.session)
        try:
            if not path.exists():
                results.append({"type": "text", "text": f"File not found: {file_path}"})
                has_error = True
            elif path.is_dir():
                results.append({"type": "text", "text": f"Is a directory (use rmdir instead): {file_path}"})
                has_error = True
            else:
                path.unlink()
                results.append({"type": "text", "text": f"Deleted {file_path}"})
        except PermissionError:
            results.append({"type": "text", "text": f"Permission denied: {file_path}"})
            has_error = True
        except Exception as e:
            results.append({"type": "text", "text": f"Error deleting {file_path}: {e}"})
            has_error = True

    if not results:
        return ToolOutput(content=[{"type": "text", "text": "No file paths provided."}])

    return ToolOutput(content=results, is_error=has_error)


DeleteFilesTool = Tool(
    id="delete_files",
    name="Delete Files",
    description="Delete files by path.",
    strict=True,
    input=DeleteFilesInput,
    call_tool=delete_files,
)
