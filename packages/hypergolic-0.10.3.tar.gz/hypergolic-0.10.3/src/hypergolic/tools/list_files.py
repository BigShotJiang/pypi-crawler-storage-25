import fnmatch
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.tools.paths import resolve_path
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.tools.subprocess_util import has_ripgrep
from hypergolic.tools.subprocess_util import run_subprocess


class ListFilesInput(BaseModel):
    directory: str = Field(
        description="Directory to list.",
    )
    pattern: Optional[str] = Field(
        default=None,
        description="Glob pattern to filter files.",
    )
    max_depth: Optional[int] = Field(
        default=None,
        description="Max depth to traverse.",
    )
    include_hidden: bool = Field(
        default=False,
        description="Include hidden files/directories.",
    )


def _python_list_files(directory: Path, input: ListFilesInput) -> list[str]:
    files: list[str] = []
    for path in sorted(directory.rglob("*")):
        if not path.is_file():
            continue

        rel = path.relative_to(directory)

        if not input.include_hidden and any(p.startswith(".") for p in rel.parts):
            continue

        if input.max_depth is not None:
            if len(rel.parts) > input.max_depth:
                continue

        if input.pattern and not fnmatch.fnmatch(rel.name, input.pattern):
            continue

        files.append(str(rel))
    return files


async def _rg_list_files(directory: Path, input: ListFilesInput) -> list[str]:
    cmd = ["rg", "--files"]

    if input.max_depth is not None:
        cmd.extend(["--max-depth", str(input.max_depth)])
    if input.include_hidden:
        cmd.append("--hidden")
    if input.pattern:
        cmd.extend(["-g", input.pattern])

    cmd.append(str(directory))

    result = await run_subprocess(cmd, timeout=30)

    if result.returncode != 0 and result.stderr:
        if "No files were searched" in result.stderr:
            return []
        raise RuntimeError(result.stderr)

    return sorted(result.stdout.strip().split("\n")) if result.stdout.strip() else []


async def list_files(input: ListFilesInput, ctx: ToolContext) -> ToolOutput:
    directory = resolve_path(input.directory, ctx.session)

    if not directory.exists():
        return ToolOutput(
            content=[{"type": "text", "text": f"Error: directory '{input.directory}' does not exist."}],
            is_error=True,
        )
    if not directory.is_dir():
        return ToolOutput(
            content=[{"type": "text", "text": f"Error: '{input.directory}' is not a directory."}],
            is_error=True,
        )

    try:
        if has_ripgrep():
            files = await _rg_list_files(directory, input)
        else:
            files = _python_list_files(directory, input)

        if not files:
            return ToolOutput(
                content=[{"type": "text", "text": "No files found in the specified directory."}],
            )

        return ToolOutput(content=[{"type": "text", "text": "\n".join(files)}])

    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error listing files: {str(e)}"}],
            is_error=True,
        )


ListFilesTool = Tool(
    id="list_files",
    name="List Files",
    description="List files in a directory.",
    strict=True,
    input=ListFilesInput,
    call_tool=list_files,
)
