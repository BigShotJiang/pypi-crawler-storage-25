from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.workflows.resolver import resolve_workflows, get_session_workflow, get_workflow_config


async def _handle_activate_workflow(inp: BaseModel, ctx: ToolContext) -> ToolOutput:
    workflow_id = inp.workflow_id  # type: ignore[attr-defined]
    session = ctx.session
    project_path = session.working_directory()

    existing = get_session_workflow(session.id)
    if existing is not None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Session already has active workflow '{existing[0]}'. Deactivate it first."}],
            is_error=True,
        )

    wf = get_workflow_config(workflow_id, project_path)
    if wf is None:
        return ToolOutput(
            content=[{"type": "text", "text": f"Workflow '{workflow_id}' not found."}],
            is_error=True,
        )

    from hypergolic.workflows.engine import activate_workflow, WorkflowError

    try:
        await activate_workflow(session, workflow_id, ctx.broadcast)
    except WorkflowError as e:
        return ToolOutput(
            content=[{"type": "text", "text": str(e)}],
            is_error=True,
        )

    initial_state = None
    for s in wf.states:
        if s.id == wf.initial_state:
            initial_state = s
            break

    state_desc = ""
    if initial_state:
        state_desc = f"\n\nInitial state: {initial_state.name} ({initial_state.id})"
        if initial_state.prompt_path:
            state_desc += "\nState prompt will be injected into system prompt."

    return ToolOutput(
        content=[{"type": "text", "text": f"Workflow '{wf.name}' activated.{state_desc}"}],
    )


def _build_workflow_description(workflows: list[dict[str, Any]]) -> str:
    desc = "Activate a workflow to enter a structured multi-phase process.\n\nAvailable workflows:\n"
    for wf in workflows:
        desc += f"- `{wf['id']}`: {wf['description']}\n"
    return desc.rstrip()


def build_activate_workflow_tool(project_path: Path | None = None, session_id: str | None = None) -> Tool | None:
    if session_id and get_session_workflow(session_id) is not None:
        return None

    workflows = resolve_workflows(project_path)
    if not workflows:
        return None

    wf_dicts = [{"id": wf.id, "name": wf.name, "description": wf.description} for wf in workflows]
    wf_ids = [wf.id for wf in workflows]
    WorkflowIdEnum = Enum("WorkflowIdEnum", {wid: wid for wid in wf_ids}, type=str)

    class ActivateWorkflowInput(BaseModel):
        workflow_id: WorkflowIdEnum

    return Tool(
        id="activate_workflow",
        name="Activate Workflow",
        description=_build_workflow_description(wf_dicts),
        strict=False,
        input=ActivateWorkflowInput,
        call_tool=_handle_activate_workflow,
    )
