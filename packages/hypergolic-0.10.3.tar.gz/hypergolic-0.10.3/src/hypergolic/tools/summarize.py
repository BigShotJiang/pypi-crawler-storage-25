import asyncio
import logging
from pathlib import Path

from anthropic import APIConnectionError, APIStatusError
from anthropic.types import Message, MessageParam, TextBlockParam
from pydantic import BaseModel
from hypergolic.config.settings import PROMPTS_DIR
from hypergolic.messages.persistence import load_session_messages
from hypergolic.providers import create_client, tier_to_model_id
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput

logger = logging.getLogger(__name__)

RETRY_BASE_DELAY = 1.0
MAX_RETRIES = 1
TOOL_RESULT_MAX_CHARS = 2000
SUMMARIZE_PROMPT_PATH = PROMPTS_DIR / "summarize_prompt.md"


class SummarizeInput(BaseModel):
    pass


def _truncate_tool_result(text: str, max_chars: int = TOOL_RESULT_MAX_CHARS) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n\u2026 (content truncated for brevity)"


def _build_conversation_transcript(messages: list[MessageParam]) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", [])

        if isinstance(content, str):
            if content.strip():
                blocks.append({"type": "text", "text": f"[{role}]: {content}"})
            continue

        text_parts: list[str] = []
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                text = block.get("text", "")
                if text.strip():
                    text_parts.append(text)
            elif btype == "tool_use":
                name = block.get("name", "unknown")
                inp = block.get("input", {})
                text_parts.append(f"[Tool call: {name}({inp})]")
            elif btype == "tool_result":
                tool_content = block.get("content", [])
                is_error = block.get("is_error", False)
                prefix = "Tool error" if is_error else "Tool result"
                if isinstance(tool_content, str):
                    text_parts.append(f"[{prefix}: {_truncate_tool_result(tool_content)}]")
                elif isinstance(tool_content, list):
                    for sub in tool_content:
                        if isinstance(sub, dict) and sub.get("type") == "text":
                            text_parts.append(
                                f"[{prefix}: {_truncate_tool_result(sub.get('text', ''))}]"
                            )

        if text_parts:
            combined = "\n".join(text_parts)
            blocks.append({"type": "text", "text": f"[{role}]: {combined}"})

    return blocks


def _build_system_prompt(session: Session) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    if SUMMARIZE_PROMPT_PATH.exists():
        blocks.append({"type": "text", "text": SUMMARIZE_PROMPT_PATH.read_text()})

    user_prompt_path = Path.home() / ".agents" / "SUMMARIZE_PROMPT.md"
    if user_prompt_path.exists():
        blocks.append({
            "type": "text",
            "text": f"# User Summarization Guidance\n\n{user_prompt_path.read_text()}",
        })

    project_path = session.working_directory()
    project_prompt_path = project_path / ".agents" / "SUMMARIZE_PROMPT.md"
    if project_prompt_path.exists():
        blocks.append({
            "type": "text",
            "text": f"# Project Summarization Guidance\n\n{project_prompt_path.read_text()}",
        })

    return blocks


def extract_summary_text(response: Message) -> str:
    summary_text = ""
    for block in response.content:
        if getattr(block, "type", None) == "text":
            summary_text += getattr(block, "text", "")

    if not summary_text.strip():
        raise ValueError("Summarization model returned empty response.")

    return summary_text


async def _call_summarization_model(
    session: Session,
    messages: list[MessageParam],
) -> Message:
    client = create_client()
    model_id = tier_to_model_id(session.model_tier)
    system_prompt = _build_system_prompt(session)

    transcript_blocks = _build_conversation_transcript(messages)
    if not transcript_blocks:
        raise ValueError("No message content to summarize after flattening.")

    transcript_blocks.append({
        "type": "text",
        "text": "Please summarize this conversation now.",
    })

    summarize_messages: list[MessageParam] = [
        {"role": "user", "content": transcript_blocks},
    ]

    max_attempts = 1 + MAX_RETRIES
    for attempt in range(max_attempts):
        try:
            response = await client.messages.create(
                max_tokens=8192,
                model=model_id,
                messages=summarize_messages,
                system=system_prompt,
            )

            extract_summary_text(response)
            return response

        except (APIConnectionError, APIStatusError) as exc:
            if attempt < max_attempts - 1:
                delay = RETRY_BASE_DELAY * (2 ** attempt)
                logger.warning(
                    "Summarization attempt %d failed (%s), retrying in %.1fs",
                    attempt + 1, exc, delay,
                )
                await asyncio.sleep(delay)
            else:
                raise

    raise RuntimeError("Unreachable: all summarization attempts exhausted")


async def run_summarize(input: SummarizeInput, ctx: ToolContext) -> ToolOutput:
    session = ctx.session
    messages = load_session_messages(session.id)
    if not messages:
        return ToolOutput(
            content=[{"type": "text", "text": "No messages to summarize."}],
            is_error=True,
        )

    try:
        response = await _call_summarization_model(
            session=session,
            messages=messages,
        )
        summary = extract_summary_text(response)
    except Exception as exc:
        return ToolOutput(
            content=[{"type": "text", "text": f"Summarization failed: {exc}"}],
            is_error=True,
        )

    return ToolOutput(
        content=[{"type": "text", "text": summary}],
        should_truncate=True,
    )


SummarizeTool = Tool(
    id="summarize",
    name="Summarize",
    description="Summarize the current session's conversation history",
    strict=False,
    input=SummarizeInput,
    call_tool=run_summarize,
)
