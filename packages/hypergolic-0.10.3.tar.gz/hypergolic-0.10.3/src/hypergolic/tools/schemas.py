from dataclasses import dataclass, field
from typing import Awaitable, Callable, Generic, TypeVar, Type

from anthropic.types import ToolUnionParam
from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel

from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session

T = TypeVar("T", bound=BaseModel)

ToolContent = list[Content]


@dataclass
class ToolContext:
    session: Session
    broadcast: BroadcastFn
    tool_id: str


@dataclass
class ToolOutput:
    content: list[Content] = field(default_factory=list)
    is_error: bool = False
    should_truncate: bool = False


class Tool(BaseModel, Generic[T]):
    id: str
    name: str
    description: str
    strict: bool
    input: Type[T]
    call_tool: Callable[[T, ToolContext], Awaitable[ToolOutput]]
    should_truncate: bool = False
    requires_approval: bool = False
    display: dict[str, str] | None = None

    model_config = {"arbitrary_types_allowed": True}

    def to_param(self) -> ToolUnionParam:
        schema = self.input.model_json_schema()
        schema["additionalProperties"] = False

        return {
            "name": self.id,
            "description": self.description,
            "input_schema": schema,
        }
