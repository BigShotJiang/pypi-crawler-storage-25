from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from sqlalchemy import delete as sa_delete, select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBToolApprovalRule
from hypergolic.skills.resolver import resolve_custom_tools


class RuleAction(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"


class ConditionOperator(str, Enum):
    EQUALS = "equals"
    STARTS_WITH = "starts_with"
    CONTAINS = "contains"
    MATCHES_GLOB = "matches_glob"
    MATCHES_REGEX = "matches_regex"


@dataclass
class RuleCondition:
    field: str
    operator: ConditionOperator
    value: str

    def _matches_value(self, actual_str: str) -> bool:
        if self.operator == ConditionOperator.EQUALS:
            return actual_str == self.value
        if self.operator == ConditionOperator.STARTS_WITH:
            return actual_str.startswith(self.value)
        if self.operator == ConditionOperator.CONTAINS:
            return self.value in actual_str
        if self.operator == ConditionOperator.MATCHES_GLOB:
            return fnmatch.fnmatch(actual_str, self.value)
        if self.operator == ConditionOperator.MATCHES_REGEX:
            try:
                return bool(re.search(self.value, actual_str))
            except re.error:
                return False
        return False

    def matches(self, tool_input: dict[str, Any]) -> bool:
        actual = tool_input.get(self.field)
        if actual is None:
            return False
        if isinstance(actual, list):
            return any(self._matches_value(str(item)) for item in actual)
        return self._matches_value(str(actual))


@dataclass
class ApprovalRule:
    id: str | None  # None for built-in rules
    tool_name: str
    action: RuleAction
    conditions: list[RuleCondition] = field(default_factory=list)
    priority: int = 0
    project_id: str | None = None
    session_id: str | None = None
    is_builtin: bool = False

    def matches(self, tool_name: str, tool_input: dict[str, Any],
                project_id: str | None = None, session_id: str | None = None) -> bool:
        if self.tool_name != "*" and self.tool_name != tool_name:
            return False
        if self.project_id and self.project_id != project_id:
            return False
        if self.session_id and self.session_id != session_id:
            return False
        return all(c.matches(tool_input) for c in self.conditions)


def _builtin_rules() -> list[ApprovalRule]:
    rules: list[ApprovalRule] = []
    # Git: read-only commands are allowed
    for cmd in ("status", "diff", "log", "show", "branch_list", "stash_list"):
        rules.append(ApprovalRule(
            id=None, tool_name="git", action=RuleAction.ALLOW, is_builtin=True,
            priority=100,
            conditions=[RuleCondition(field="command", operator=ConditionOperator.EQUALS, value=cmd)],
        ))
    # Git: mutating commands require approval
    rules.append(ApprovalRule(
        id=None, tool_name="git", action=RuleAction.REQUIRE_APPROVAL, is_builtin=True,
        priority=50,
    ))
    # Command tool always requires approval
    rules.append(ApprovalRule(
        id=None, tool_name="command", action=RuleAction.REQUIRE_APPROVAL, is_builtin=True,
        priority=50,
    ))
    # Edit config requires approval
    rules.append(ApprovalRule(
        id=None, tool_name="edit_config", action=RuleAction.REQUIRE_APPROVAL, is_builtin=True,
        priority=50,
    ))
    # Browser tool always requires approval
    rules.append(ApprovalRule(
        id=None, tool_name="browser", action=RuleAction.REQUIRE_APPROVAL, is_builtin=True,
        priority=50,
    ))
    # MCP tools require approval (matched via * with a condition check in evaluate)
    # We handle MCP as a fallback in get_effective_action since tool_name patterns aren't supported yet

    # All other tools: default allow (lowest priority)
    rules.append(ApprovalRule(
        id=None, tool_name="*", action=RuleAction.ALLOW, is_builtin=True,
        priority=-1000,
    ))
    return rules


def _custom_tool_rules() -> list[ApprovalRule]:
    rules: list[ApprovalRule] = []
    for config in resolve_custom_tools().values():
        if config.requires_approval:
            rules.append(ApprovalRule(
                id=None, tool_name=config.id, action=RuleAction.REQUIRE_APPROVAL,
                is_builtin=True, priority=50,
            ))
    return rules


def _db_rules_to_approval_rules(rows: list[DBToolApprovalRule]) -> list[ApprovalRule]:
    rules: list[ApprovalRule] = []
    for row in rows:
        conditions = [
            RuleCondition(
                field=c["field"],
                operator=ConditionOperator(c["operator"]),
                value=c["value"],
            )
            for c in (row.conditions or [])
        ]
        rules.append(ApprovalRule(
            id=row.id,
            tool_name=row.tool_name,
            action=RuleAction(row.action),
            conditions=conditions,
            priority=row.priority,
            project_id=row.project_id,
            session_id=row.session_id,
            is_builtin=False,
        ))
    return rules


def load_all_rules() -> list[ApprovalRule]:
    with get_db() as db:
        rows = db.execute(
            select(DBToolApprovalRule).order_by(DBToolApprovalRule.priority.desc())
        ).scalars().all()
        db_rules = _db_rules_to_approval_rules(list(rows))

    all_rules = db_rules + _builtin_rules() + _custom_tool_rules()
    all_rules.sort(key=lambda r: r.priority, reverse=True)
    return all_rules


READ_ONLY_FILE_TOOLS = frozenset({"read_files", "list_files", "search_files"})

_AGENTS_DIR = str(Path.home() / ".agents")

_FILE_TOOL_PATH_EXTRACTORS: dict[str, Callable[[dict[str, Any]], list[str]]] = {
    "read_files": lambda inp: inp.get("paths", []),
    "write_files": lambda inp: [f["path"] for f in inp.get("files", []) if isinstance(f, dict)],
    "edit_files": lambda inp: [f["path"] for f in inp.get("files", []) if isinstance(f, dict)],
    "delete_files": lambda inp: inp.get("paths", []),
    "list_files": lambda inp: [inp["directory"]] if inp.get("directory") else [],
    "make_directory": lambda inp: ([inp["path"]] if inp.get("path") else []) + (inp.get("paths") or []),
    "search_files": lambda inp: [inp["directory"]] if inp.get("directory") else [],
}


def _has_paths_outside_project(
    tool_id: str, tool_input: dict[str, Any], project_path: str,
    allowed_paths: list[str] | None = None,
) -> bool:
    extractor = _FILE_TOOL_PATH_EXTRACTORS.get(tool_id)
    if not extractor:
        return False

    raw_paths = extractor(tool_input)
    if not raw_paths:
        return False

    project_root = Path(project_path).resolve()
    resolved_allowed = [Path(p).resolve() for p in (allowed_paths or [])]

    for raw in raw_paths:
        if not isinstance(raw, str):
            continue
        p = Path(raw).expanduser()
        if not p.is_absolute():
            p = project_root / p
        resolved = p.resolve()
        try:
            resolved.relative_to(project_root)
            continue
        except ValueError:
            pass
        if any(_is_within(resolved, allowed) for allowed in resolved_allowed):
            continue
        return True
    return False


def _is_within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def get_effective_action(
    tool_id: str,
    tool_input: dict[str, Any],
    project_id: str | None = None,
    session_id: str | None = None,
    project_path: str | None = None,
) -> RuleAction:
    rules = load_all_rules()

    # MCP tools default to require_approval if no explicit rule matches
    is_mcp = tool_id.startswith("mcp_")

    action = RuleAction.REQUIRE_APPROVAL
    matched_rule: ApprovalRule | None = None
    for rule in rules:
        if rule.matches(tool_id, tool_input, project_id, session_id):
            # The wildcard fallback rule should not auto-allow MCP tools
            if rule.tool_name == "*" and rule.action == RuleAction.ALLOW and is_mcp:
                continue
            action = rule.action
            matched_rule = rule
            break

    # Only enforce project boundary for builtin allow rules.
    # User-created DB rules are explicit overrides and should be respected.
    if (
        action == RuleAction.ALLOW
        and project_path
        and (matched_rule is None or matched_rule.is_builtin)
    ):
        allowed = [_AGENTS_DIR] if tool_id in READ_ONLY_FILE_TOOLS else None
        if _has_paths_outside_project(tool_id, tool_input, project_path, allowed):
            return RuleAction.REQUIRE_APPROVAL

    return action


def get_rules_for_tool(tool_name: str) -> list[ApprovalRule]:
    all_rules = load_all_rules()
    return [
        r for r in all_rules
        if r.tool_name == tool_name or r.tool_name == "*"
    ]


def save_rule(
    tool_name: str,
    action: RuleAction,
    conditions: list[dict[str, str]],
    priority: int = 0,
    project_id: str | None = None,
    session_id: str | None = None,
) -> DBToolApprovalRule:
    with get_db() as db:
        rule = DBToolApprovalRule(
            tool_name=tool_name,
            action=action.value,
            conditions=conditions,
            priority=priority,
            project_id=project_id,
            session_id=session_id,
        )
        db.add(rule)
        db.flush()
        return rule


def update_rule_priority(rule_id: str, priority: int) -> None:
    with get_db() as db:
        rule = db.execute(
            select(DBToolApprovalRule).where(DBToolApprovalRule.id == rule_id)
        ).scalar_one()
        rule.priority = priority


def delete_rule(rule_id: str) -> None:
    with get_db() as db:
        db.execute(
            sa_delete(DBToolApprovalRule).where(DBToolApprovalRule.id == rule_id)
        )
