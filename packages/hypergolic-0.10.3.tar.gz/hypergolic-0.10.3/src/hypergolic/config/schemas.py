from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class MCPAuthConfig(BaseModel):
    type: Literal["none", "token", "oauth"] = "none"
    token_env_var: str | None = None
    token_header: str = "Authorization"
    token_prefix: str = "Bearer"


class MCPServerConfig(BaseModel):
    transport: Literal["stdio", "streamable_http", "sse"] = "stdio"
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    url: str | None = None
    auth: MCPAuthConfig = Field(default_factory=MCPAuthConfig)


class CustomToolParam(BaseModel):
    name: str
    type: Literal["string", "integer", "boolean"] = "string"
    description: str = ""
    required: bool = True
    default: Any = None


class CustomToolConfig(BaseModel):
    id: str
    name: str
    description: str
    command: str
    working_directory: str | None = None
    timeout: int = 30
    requires_approval: bool = False
    parameters: list[CustomToolParam] = Field(default_factory=list)


class SkillConfig(BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str
    tools: list[CustomToolConfig] = Field(default_factory=list)


VALID_DISPLAY_TYPES = {"markdown", "list", "badge", "text"}


class WorkflowOutputSchema(BaseModel):
    outcome: Literal["success", "failure", "suppressed"]
    artifact_id: str | None = None
    requires_approval: bool = False
    display: dict[str, str] | None = None
    schema_def: dict[str, Any] = Field(alias="schema")
    next_state: str | None = None

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def validate_display(self) -> "WorkflowOutputSchema":
        if self.display is None:
            return self
        schema_props = set(self.schema_def.get("properties", {}).keys())
        for field_name, render_type in self.display.items():
            if field_name not in schema_props:
                raise ValueError(
                    f"display key '{field_name}' not found in schema properties: {sorted(schema_props)}"
                )
            if render_type not in VALID_DISPLAY_TYPES:
                raise ValueError(
                    f"display type '{render_type}' for field '{field_name}' is invalid. "
                    f"Valid types: {sorted(VALID_DISPLAY_TYPES)}"
                )
        return self


class WorkflowStateConfig(BaseModel):
    id: str
    name: str
    prompt_path: str | None = None
    skills: list[str] = Field(default_factory=list)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    truncate_on_entry: bool = False
    include_artifacts: list[str] = Field(default_factory=list)
    output_schemas: list[WorkflowOutputSchema] = Field(default_factory=list)


class WorkflowConfig(BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str | None = None
    initial_state: str
    states: list[WorkflowStateConfig] = Field(default_factory=list)


class RoleConfig(BaseModel):
    id: str
    name: str
    prompt_path: str
    tools: list[str] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)


class UserProjectConfig(BaseModel):
    git_root: str
    name: str
    prompt_path: str | None = None
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    roles: list[RoleConfig] = Field(default_factory=list)
    workflows: list[WorkflowConfig] = Field(default_factory=list)


class UserConfig(BaseModel):
    db_path: Path = Path.home() / ".agents" / "hypergolicV4.db"
    prompt_path: Path = Path.home() / ".agents" / "PROMPT.md"
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    skills: list[SkillConfig] = Field(default_factory=list)
    roles: list[RoleConfig] = Field(default_factory=list)
    workflows: list[WorkflowConfig] = Field(default_factory=list)
    projects: list[UserProjectConfig] = Field(default_factory=list)


class ProjectConfig(BaseModel):
    name: str = ""
    prompt_path: str = ".agents/PROMPT.md"
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    skills: list[SkillConfig] = Field(default_factory=list)
    roles: list[RoleConfig] = Field(default_factory=list)
    workflows: list[WorkflowConfig] = Field(default_factory=list)
