import asyncio
import fcntl
import json
import logging
import os
import pty
import select
import struct
import termios
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from hypergolic.auth import verify_token

logger = logging.getLogger(__name__)

router = APIRouter()


def _open_pty(cols: int = 80, rows: int = 24) -> tuple[int, int]:
    master_fd, slave_fd = pty.openpty()
    winsize = struct.pack("HHHH", rows, cols, 0, 0)
    fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, winsize)
    return master_fd, slave_fd


def _spawn_shell(slave_fd: int) -> int:
    shell = os.environ.get("SHELL", "/bin/zsh")
    pid = os.fork()
    if pid == 0:
        os.setsid()
        os.dup2(slave_fd, 0)
        os.dup2(slave_fd, 1)
        os.dup2(slave_fd, 2)
        os.close(slave_fd)
        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        os.execvpe(shell, [shell, "-l"], env)
    return pid


async def _read_pty(master_fd: int, ws: WebSocket, stop_event: asyncio.Event) -> None:
    loop = asyncio.get_event_loop()
    while not stop_event.is_set():
        try:
            ready = await loop.run_in_executor(
                None, lambda: select.select([master_fd], [], [], 0.1)[0]
            )
            if ready:
                data = os.read(master_fd, 4096)
                if not data:
                    break
                await ws.send_text(data.decode("utf-8", errors="replace"))
        except OSError:
            break
        except Exception:
            logger.debug("PTY read error", exc_info=True)
            break


@router.websocket("/ws/terminal")
async def terminal_websocket(ws: WebSocket) -> None:
    token = ws.cookies.get("h_token", "")
    if not verify_token(token):
        await ws.close(code=4003, reason="Unauthorized")
        return
    await ws.accept()
    master_fd: int | None = None
    child_pid: int | None = None
    stop_event = asyncio.Event()
    reader_task: asyncio.Task[Any] | None = None

    try:
        master_fd, slave_fd = _open_pty()
        child_pid = _spawn_shell(slave_fd)
        os.close(slave_fd)

        reader_task = asyncio.create_task(_read_pty(master_fd, ws, stop_event))

        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break

            if "text" in msg:
                text = msg["text"]
                try:
                    payload = json.loads(text)
                    if isinstance(payload, dict) and payload.get("type") == "resize":
                        cols = payload.get("cols", 80)
                        rows = payload.get("rows", 24)
                        winsize = struct.pack("HHHH", rows, cols, 0, 0)
                        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, winsize)
                        continue
                except (json.JSONDecodeError, ValueError):
                    pass
                os.write(master_fd, text.encode("utf-8"))

    except WebSocketDisconnect:
        logger.info("Terminal WebSocket disconnected")
    except Exception:
        logger.error("Terminal WebSocket error", exc_info=True)
    finally:
        stop_event.set()
        if reader_task:
            reader_task.cancel()
            try:
                await reader_task
            except (asyncio.CancelledError, Exception):
                pass
        if master_fd is not None:
            try:
                os.close(master_fd)
            except OSError:
                pass
        if child_pid is not None:
            try:
                os.kill(child_pid, 9)
                os.waitpid(child_pid, 0)
            except (OSError, ChildProcessError):
                pass
