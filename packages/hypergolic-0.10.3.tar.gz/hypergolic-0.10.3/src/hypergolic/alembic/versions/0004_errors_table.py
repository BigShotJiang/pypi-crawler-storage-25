"""Add errors table

Revision ID: 0004
Revises: 0003
Create Date: 2025-07-19 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0004"
down_revision: Union[str, Sequence[str], None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "errors",
        sa.Column("id", sa.String(), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("session_id", sa.String(), sa.ForeignKey("sessions.id", name="fk_errors_sessions", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("error_type", sa.String(), nullable=False),
        sa.Column("message", sa.String(), nullable=False),
        sa.Column("traceback", sa.String(), nullable=True),
    )


def downgrade() -> None:
    op.drop_table("errors")
