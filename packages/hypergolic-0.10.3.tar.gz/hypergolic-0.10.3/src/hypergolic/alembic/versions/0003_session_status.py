"""Add status column to sessions

Revision ID: 0003
Revises: 0002
Create Date: 2025-07-16 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0003"
down_revision: Union[str, Sequence[str], None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "sessions",
        sa.Column("status", sa.String(), nullable=False, server_default="idle"),
    )


def downgrade() -> None:
    op.drop_column("sessions", "status")
