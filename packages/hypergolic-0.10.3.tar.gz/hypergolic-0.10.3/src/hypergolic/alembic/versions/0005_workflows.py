"""Add session_workflows and artifacts tables

Revision ID: 0005
Revises: 0004
Create Date: 2025-07-21 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0005"
down_revision: Union[str, Sequence[str], None] = "0004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "session_workflows",
        sa.Column("id", sa.String(), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("session_id", sa.String(), sa.ForeignKey("sessions.id", name="fk_session_workflows_sessions", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("workflow_id", sa.String(), nullable=False),
        sa.Column("current_state_id", sa.String(), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_table(
        "artifacts",
        sa.Column("id", sa.String(), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("session_id", sa.String(), sa.ForeignKey("sessions.id", name="fk_artifacts_sessions", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("workflow_id", sa.String(), nullable=False),
        sa.Column("state_id", sa.String(), nullable=False),
        sa.Column("outcome", sa.String(), nullable=False),
        sa.Column("artifact_id", sa.String(), nullable=False, index=True),
        sa.Column("content", sa.JSON(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("artifacts")
    op.drop_table("session_workflows")
