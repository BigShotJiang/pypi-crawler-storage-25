"""initial

Revision ID: 0001
Revises:
Create Date: 2025-06-14 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0001"
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "projects",
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("path", sa.String(), nullable=False),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("path"),
    )
    op.create_index(op.f("ix_projects_created_at"), "projects", ["created_at"], unique=False)

    op.create_table(
        "sessions",
        sa.Column("model_tier", sa.String(), nullable=False),
        sa.Column("system_prompt", sa.JSON(), nullable=False),
        sa.Column("role", sa.String(), nullable=False, server_default="default"),
        sa.Column("project_id", sa.String(), nullable=False),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], name="fk_sessions_projects"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_sessions_created_at"), "sessions", ["created_at"], unique=False)
    op.create_index(op.f("ix_sessions_project_id"), "sessions", ["project_id"], unique=False)

    op.create_table(
        "messages",
        sa.Column("content", sa.JSON(), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("model", sa.String(), nullable=True),
        sa.Column("role", sa.String(), nullable=False),
        sa.Column("stop_reason", sa.String(), nullable=True),
        sa.Column("stop_sequence", sa.String(), nullable=True),
        sa.Column("usage", sa.JSON(), nullable=True),
        sa.Column("truncated", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["session_id"], ["sessions.id"], name="fk_messages_sessions"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_messages_created_at"), "messages", ["created_at"], unique=False)
    op.create_index(op.f("ix_messages_session_id"), "messages", ["session_id"], unique=False)

    op.create_table(
        "session_skills",
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("skill_id", sa.String(), nullable=False),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["session_id"], ["sessions.id"],
            name="fk_session_skills_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_session_skills_created_at"), "session_skills", ["created_at"], unique=False)
    op.create_index(op.f("ix_session_skills_session_id"), "session_skills", ["session_id"], unique=False)

    op.create_table(
        "tags",
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )
    op.create_index(op.f("ix_tags_created_at"), "tags", ["created_at"], unique=False)

    op.create_table(
        "knowledge",
        sa.Column("content", sa.String(), nullable=False),
        sa.Column("scope", sa.String(), nullable=False),
        sa.Column("source", sa.String(), nullable=True),
        sa.Column("project_id", sa.String(), nullable=True),
        sa.Column("session_id", sa.String(), nullable=True),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], name="fk_knowledge_projects"),
        sa.ForeignKeyConstraint(["session_id"], ["sessions.id"], name="fk_knowledge_sessions"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_knowledge_created_at"), "knowledge", ["created_at"], unique=False)
    op.create_index(op.f("ix_knowledge_project_id"), "knowledge", ["project_id"], unique=False)
    op.create_index(op.f("ix_knowledge_session_id"), "knowledge", ["session_id"], unique=False)

    op.create_table(
        "knowledge_tags",
        sa.Column("knowledge_id", sa.String(), nullable=False),
        sa.Column("tag_id", sa.String(), nullable=False),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["knowledge_id"], ["knowledge.id"], name="fk_knowledge_tags_knowledge"),
        sa.ForeignKeyConstraint(["tag_id"], ["tags.id"], name="fk_knowledge_tags_tags"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("knowledge_id", "tag_id", name="uq_knowledge_tag"),
    )
    op.create_index(op.f("ix_knowledge_tags_created_at"), "knowledge_tags", ["created_at"], unique=False)
    op.create_index(op.f("ix_knowledge_tags_knowledge_id"), "knowledge_tags", ["knowledge_id"], unique=False)
    op.create_index(op.f("ix_knowledge_tags_tag_id"), "knowledge_tags", ["tag_id"], unique=False)

    op.create_table(
        "knowledge_relationships",
        sa.Column("source_id", sa.String(), nullable=False),
        sa.Column("target_id", sa.String(), nullable=False),
        sa.Column("relation_type", sa.String(), nullable=False),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["source_id"], ["knowledge.id"], name="fk_knowledge_rel_source"),
        sa.ForeignKeyConstraint(["target_id"], ["knowledge.id"], name="fk_knowledge_rel_target"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("source_id", "target_id", "relation_type", name="uq_knowledge_relationship"),
    )
    op.create_index(op.f("ix_knowledge_relationships_created_at"), "knowledge_relationships", ["created_at"], unique=False)
    op.create_index(op.f("ix_knowledge_relationships_source_id"), "knowledge_relationships", ["source_id"], unique=False)
    op.create_index(op.f("ix_knowledge_relationships_target_id"), "knowledge_relationships", ["target_id"], unique=False)

    op.create_table(
        "tool_auto_approvals",
        sa.Column("tool_name", sa.String(), nullable=False),
        sa.Column("tool_input_hash", sa.String(), nullable=True),
        sa.Column("tool_input_snapshot", sa.JSON(), nullable=True),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_tool_auto_approvals_created_at"), "tool_auto_approvals", ["created_at"], unique=False)
    op.create_index(op.f("ix_tool_auto_approvals_tool_name"), "tool_auto_approvals", ["tool_name"], unique=False)


def downgrade() -> None:
    op.drop_table("tool_auto_approvals")
    op.drop_table("knowledge_relationships")
    op.drop_table("knowledge_tags")
    op.drop_table("knowledge")
    op.drop_table("tags")
    op.drop_table("session_skills")
    op.drop_table("messages")
    op.drop_table("sessions")
    op.drop_table("projects")
