"""Replace tool_auto_approvals with tool_approval_rules

Revision ID: 0002
Revises: 0001
Create Date: 2025-07-12 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0002"
down_revision: Union[str, Sequence[str], None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_table("tool_auto_approvals")

    op.create_table(
        "tool_approval_rules",
        sa.Column("tool_name", sa.String(), nullable=False),
        sa.Column("action", sa.String(), nullable=False),
        sa.Column("conditions", sa.JSON(), nullable=False, server_default="[]"),
        sa.Column("priority", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("project_id", sa.String(), nullable=True),
        sa.Column("session_id", sa.String(), nullable=True),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], name="fk_tool_approval_rules_projects"),
        sa.ForeignKeyConstraint(["session_id"], ["sessions.id"], name="fk_tool_approval_rules_sessions"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_tool_approval_rules_created_at"), "tool_approval_rules", ["created_at"], unique=False)
    op.create_index(op.f("ix_tool_approval_rules_tool_name"), "tool_approval_rules", ["tool_name"], unique=False)
    op.create_index(op.f("ix_tool_approval_rules_project_id"), "tool_approval_rules", ["project_id"], unique=False)
    op.create_index(op.f("ix_tool_approval_rules_session_id"), "tool_approval_rules", ["session_id"], unique=False)


def downgrade() -> None:
    op.drop_table("tool_approval_rules")

    op.create_table(
        "tool_auto_approvals",
        sa.Column("tool_name", sa.String(), nullable=False),
        sa.Column("tool_input_hash", sa.String(), nullable=True),
        sa.Column("tool_input_snapshot", sa.JSON(), nullable=True),
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_tool_auto_approvals_created_at"), "tool_auto_approvals", ["created_at"], unique=False)
    op.create_index(op.f("ix_tool_auto_approvals_tool_name"), "tool_auto_approvals", ["tool_name"], unique=False)
