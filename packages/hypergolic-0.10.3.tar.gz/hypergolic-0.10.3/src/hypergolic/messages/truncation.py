import logging

from anthropic.types import MessageParam, TextBlockParam
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.enums import SessionStatus
from hypergolic.messages.persistence import (
    load_session_messages,
    persist_agent_message,
    persist_user_message,
)
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.schemas import Session
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.tools.summarize import _call_summarization_model, extract_summary_text
from hypergolic.workflows.resolver import get_session_workflow, get_workflow_config
from hypergolic.workflows.engine import load_artifacts
from hypergolic.workflows.rendering import render_artifact_text

logger = logging.getLogger(__name__)

TRUNCATE_TOKEN_THRESHOLD = 100_000


def should_truncate(session_id: str) -> bool:
    with get_db() as db:
        row = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .where(DBMessage.role == "assistant")
            .order_by(DBMessage.created_at.desc())
            .limit(1)
        ).scalar_one_or_none()

        if row is None or row.usage is None:
            return False

        input_tokens = (
            row.usage.get("input_tokens", 0)
            + row.usage.get("cache_read_input_tokens", 0)
            + row.usage.get("cache_creation_input_tokens", 0)
        )
        return input_tokens > TRUNCATE_TOKEN_THRESHOLD


def _build_workflow_summary(session: Session) -> str | None:
    wf_state = get_session_workflow(session.id)
    if not wf_state:
        return None

    state_name = "unknown"
    artifact_blocks: list[str] = []

    workflow_id, current_state_id = wf_state
    wf = get_workflow_config(workflow_id, session.working_directory())
    if wf:
        for s in wf.states:
            if s.id == current_state_id:
                state_name = s.name
                if s.include_artifacts:
                    artifacts = load_artifacts(session.id, s.include_artifacts)
                    for artifact_id, content, created_at in artifacts:
                        artifact_blocks.append(
                            render_artifact_text(artifact_id, content, created_at)
                        )
                break

    parts = [f"[Workflow transition — now in state: {state_name}]"]
    if artifact_blocks:
        parts.append("\nThe following artifacts from prior states are the source of truth for this state:\n")
        parts.extend(artifact_blocks)

    return "\n".join(parts)


async def truncate_conversation(
    session: Session, broadcast: BroadcastFn
) -> None:
    logger.info("Truncating conversation for session %s", session.id)

    await set_session_status_and_broadcast(
        session.id, SessionStatus.TRUNCATING, broadcast
    )

    messages = load_session_messages(session.id)

    workflow_summary = _build_workflow_summary(session)
    if workflow_summary:
        summary_text = workflow_summary
    else:
        if not messages:
            return
        response = await _call_summarization_model(session=session, messages=messages)
        await persist_agent_message(session_id=session.id, message=response)
        summary_text = f"[Conversation Summary]\n\n{extract_summary_text(response)}"

    with get_db() as db:
        db.execute(
            update(DBMessage)
            .where(DBMessage.session_id == session.id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .values(truncated=True)
        )

    summary_message = MessageParam(
        role="user",
        content=[
            TextBlockParam(
                type="text",
                text=summary_text,
            )
        ],
    )
    await persist_user_message(session_id=session.id, message=summary_message)

    logger.info("Conversation truncated for session %s", session.id)

    await broadcast(
        BroadcastEvent(
            type="truncated",
            role="system",
            content=[],
            session_id=session.id,
        )
    )
