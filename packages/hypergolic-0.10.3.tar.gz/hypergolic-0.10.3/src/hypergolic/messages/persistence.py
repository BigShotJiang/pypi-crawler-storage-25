import json
import logging
from typing import Any, Literal, cast

from anthropic.types import Message, MessageParam
from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages.types import EXCLUDED_CONTENT_FIELDS, EXCLUDED_FIELDS

logger = logging.getLogger(__name__)


def _try_parse_json_string(value: str) -> list | dict | None:
    """Attempt to parse a string as a JSON array or object, stripping trailing garbage if needed."""
    try:
        parsed = json.loads(value)
        if isinstance(parsed, (list, dict)):
            return parsed
    except (json.JSONDecodeError, ValueError):
        pass

    closing = "]" if value.lstrip().startswith("[") else "}"
    last_close = value.rfind(closing)
    if last_close > 0:
        try:
            parsed = json.loads(value[: last_close + 1])
            if isinstance(parsed, (list, dict)):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass

    return None


def sanitize_tool_input(input_dict: dict[str, Any]) -> dict[str, Any]:
    """Fix tool input values that the API returned as JSON strings instead of parsed objects."""
    result = {}
    for key, value in input_dict.items():
        if isinstance(value, str) and value and value.lstrip()[:1] in ("[", "{"):
            parsed = _try_parse_json_string(value)
            if parsed is not None:
                logger.warning(
                    "Sanitized tool input key '%s': parsed string as %s",
                    key,
                    type(parsed).__name__,
                )
                result[key] = parsed
                continue
        result[key] = value
    return result


def strip_excluded_fields(content: list[Any]) -> list[Any]:
    cleaned = []
    for block in content:
        if isinstance(block, dict):
            cleaned.append(
                {k: v for k, v in block.items() if k not in EXCLUDED_CONTENT_FIELDS}
            )
        else:
            cleaned.append(block)
    return cleaned


def _extract_tool_use_ids(msg: MessageParam) -> list[str]:
    content: Any = msg.get("content", [])
    if isinstance(content, str):
        return []
    return [
        str(block.get("id"))
        for block in content
        if isinstance(block, dict) and block.get("type") == "tool_use" and block.get("id")
    ]


def _make_error_tool_results(tool_use_ids: list[str]) -> MessageParam:
    results: list[Any] = [
        {
            "type": "tool_result",
            "tool_use_id": tid,
            "content": [{"type": "text", "text": "Error: tool execution was interrupted by a prior failure"}],
            "is_error": True,
        }
        for tid in tool_use_ids
    ]
    return MessageParam(role="user", content=results)


def _to_block_list(content: Any) -> list[Any]:
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    return list(content)


def _repair_message_sequence(messages: list[MessageParam]) -> list[MessageParam]:
    """Fix broken message sequences that would cause Claude API errors.

    Handles two cases:
    1. Assistant tool_use message followed by another assistant message (no tool_results)
       → inserts synthetic error tool_results between them
    2. Assistant tool_use message at the end with no following tool_results
       → appends synthetic error tool_results
    """
    if not messages:
        return messages

    repaired: list[MessageParam] = []
    for msg in messages:
        if repaired and msg["role"] == "assistant" and repaired[-1]["role"] == "assistant":
            prev_tool_ids = _extract_tool_use_ids(repaired[-1])
            if prev_tool_ids:
                logger.warning(
                    "Repairing broken message sequence: inserting synthetic tool_results for %s",
                    prev_tool_ids,
                )
                repaired.append(_make_error_tool_results(prev_tool_ids))
            else:
                logger.warning(
                    "Repairing broken message sequence: merging consecutive assistant messages"
                )
                merged = _to_block_list(repaired[-1].get("content", [])) + _to_block_list(msg.get("content", []))
                repaired[-1] = MessageParam(role="assistant", content=merged)
                continue

        if repaired and msg["role"] == "user" and repaired[-1]["role"] == "user":
            logger.warning(
                "Repairing broken message sequence: merging consecutive user messages"
            )
            merged = _to_block_list(repaired[-1].get("content", [])) + _to_block_list(msg.get("content", []))
            repaired[-1] = MessageParam(role="user", content=merged)
            continue

        repaired.append(msg)

    if repaired and repaired[-1]["role"] == "assistant":
        last_tool_ids = _extract_tool_use_ids(repaired[-1])
        if last_tool_ids:
            logger.warning(
                "Repairing broken message sequence: appending synthetic tool_results for trailing tool_use %s",
                last_tool_ids,
            )
            repaired.append(_make_error_tool_results(last_tool_ids))

    return repaired


def load_session_messages(session_id: str) -> list[MessageParam]:
    with get_db() as db:
        rows = (
            db.execute(
                select(DBMessage)
                .where(DBMessage.session_id == session_id)
                .where(DBMessage.truncated == False)  # noqa: E712
                .order_by(DBMessage.created_at)
            )
            .scalars()
            .all()
        )
        messages = [
            MessageParam(
                role=cast(Literal["user", "assistant"], row.role),
                content=strip_excluded_fields(row.content),
            )
            for row in rows
        ]
        return _repair_message_sequence(messages)


async def persist_agent_message(session_id: str, message: Message):
    content = []
    for block in message.content:
        if isinstance(block, BaseModel):
            dumped = block.model_dump(mode="json", exclude=EXCLUDED_FIELDS)
            if dumped.get("type") == "tool_use" and isinstance(dumped.get("input"), dict):
                dumped["input"] = sanitize_tool_input(dumped["input"])
            content.append(dumped)
        else:
            content.append(block)

    usage = message.usage.model_dump(mode="json") if message.usage else None

    with get_db() as db:
        db_message = DBMessage(
            id=message.id,
            session_id=session_id,
            content=content,
            model=message.model,
            role=message.role,
            stop_reason=message.stop_reason,
            stop_sequence=message.stop_sequence,
            usage=usage,
        )
        db.add(db_message)


async def persist_user_message(session_id: str, message: MessageParam):
    content = message.get("content", [])

    if isinstance(content, str):
        content = [{"type": "text", "text": content}]
    else:
        normalized_content = []
        for block in content:
            if isinstance(block, BaseModel):
                normalized_content.append(block.model_dump(mode="json"))
            else:
                normalized_content.append(block)
        content = normalized_content

    with get_db() as db:
        db_message = DBMessage(
            session_id=session_id,
            content=content,
            model=None,
            role=message.get("role", "user"),
            stop_reason=None,
            stop_sequence=None,
            usage=None,
        )
        db.add(db_message)


def parse_agent_message(message: Message) -> MessageParam:
    content = []
    for c in message.content:
        if isinstance(c, BaseModel):
            dumped = c.model_dump(mode="json", exclude=EXCLUDED_FIELDS)
            if dumped.get("type") == "tool_use" and isinstance(dumped.get("input"), dict):
                dumped["input"] = sanitize_tool_input(dumped["input"])
            content.append(dumped)
        else:
            content.append(c)
    return {
        "content": content,
        "role": "assistant",
    }
