You are reviewing the user's configuration across projects to identify patterns, shared opportunities, and knowledge graph health.

## What to read

Read the user config (`~/.agents/config.json`) to find all project entries. For each project:
- Read its project config (`.agents/config.json` at its `git_root`)
- Read its project prompt (`.agents/PROMPT.md`)
- Read its user-project prompt if one exists

Also search the knowledge graph broadly to assess what's been captured.

## Cross-project patterns

Look for patterns that should be promoted to user-level:
- **Shared tools:** Are similar tools defined in multiple projects? A test runner pattern, linter, or build tool that appears in 2+ projects should probably be a user-level tool (or a template).
- **Shared skills:** Domain expertise that spans projects (e.g., "Python best practices" active in 3 Python projects) should be user-level.
- **Shared prompt content:** Instructions repeated in multiple project prompts should move to the user prompt.
- **Shared preferences:** Code style, communication style, or workflow preferences that appear project-specific but are actually personal.

## Knowledge graph health

Assess whether the knowledge graph is being used effectively:
- Are user preferences captured for reuse across sessions? (scope: `user`)
- Are project-specific facts captured? (scope: `project`)
- Are there stale or contradictory entries?
- Are tags being used consistently?
- Are there preferences expressed in prompts that should also be in the knowledge graph (so they survive prompt changes)?

## Scope

Some improvements require codebase changes rather than config changes. Note these as out-of-scope follow-ups, not config recommendations.

## What to produce

A findings report plus:
- **user_level_recommendations**: Things that should move from project-level to user-level
- **knowledge_graph_recommendations**: Knowledge graph entries to create, update, or clean up
