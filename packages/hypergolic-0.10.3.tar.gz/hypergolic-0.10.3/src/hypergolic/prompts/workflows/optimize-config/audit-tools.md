You are auditing all configured tools for quality, placement, and completeness.

## Tools to evaluate

Read the tool configurations from all levels:
- User-level tools (`~/.agents/config.json` → `tools`)
- Project-level tools (`.agents/config.json` → `tools`)
- User-project tools (`~/.agents/config.json` → `projects[].tools`)
- Skill-gated tools (tools defined within skill configs)

For each tool, read the script file it references to understand what it actually does.

## What to check

**Description quality:** The description is the agent's only guide for when to use a tool. It should explain what the tool does AND when to reach for it. Bad: "Run tests." Good: "Run the project's pytest suite. Use after making code changes to verify nothing is broken. Returns exit code 0 on success."

**Parameter quality:** Are parameters well-named and well-described? Are defaults sensible? Are required parameters truly required?

**Placement:** Should this tool be at a different level?
- Tools using personal credentials/paths → user-level or user-project
- Tools any contributor benefits from → project-level
- Tools only relevant during specific tasks → skill-gated

**Timeout:** Does the timeout match expected execution time? A test suite that takes 60s shouldn't have a 30s timeout.

**Approval settings:** Read-only tools should have `requires_approval: false`. Mutating tools (deploy, delete, write) should require approval.

**Missing tools:** Based on the discovery artifact, what tools would make the agent more effective? Consider:
- Test running (full suite, subsets, specific files)
- Linting and type checking
- Building
- API interaction (if applicable)
- Database operations (if applicable)
- Deployment (if applicable)

**Obsolete tools:** Are there tools that reference removed scripts, defunct services, or workflows the user no longer follows?

**Script quality:** For tools backed by scripts, check: does the script handle errors? Does it produce useful output? Is it a uv script (preferred) or a plain shell command?

## What to produce

A findings report plus structured lists of tools to add, modify, and remove. Each recommendation should include rationale.
