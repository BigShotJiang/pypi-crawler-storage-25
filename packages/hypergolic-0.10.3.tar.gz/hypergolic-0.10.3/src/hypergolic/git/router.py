from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject
from hypergolic.git.operations import (
    get_git_status,
    get_git_diff,
    git_stage,
    git_unstage,
    git_discard,
    git_commit,
    git_push,
    git_pull,
    get_git_log,
    get_git_commit_detail,
)
from hypergolic.git.schemas import (
    GitStatusResponse,
    GitDiffResponse,
    GitLogResponse,
    GitCommitDetailResponse,
)

router = APIRouter(prefix="/api/git", tags=["git"])


def _resolve_project_path(project_id: str | None) -> Path | None:
    if not project_id:
        return None
    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        return Path(project.path)


class GitDiffRequest(BaseModel):
    path: str | None = None
    staged: bool = False


class GitPathsRequest(BaseModel):
    paths: list[str]


class GitCommitRequest(BaseModel):
    message: str


@router.get("/status", response_model=GitStatusResponse)
def get_git_status_endpoint(project_id: str | None = None):
    return get_git_status(repo=_resolve_project_path(project_id))


@router.post("/diff", response_model=GitDiffResponse)
def get_git_diff_endpoint(req: GitDiffRequest, project_id: str | None = None):
    return get_git_diff(req.path, req.staged, repo=_resolve_project_path(project_id))


@router.post("/stage")
def git_stage_endpoint(req: GitPathsRequest, project_id: str | None = None):
    git_stage(req.paths, repo=_resolve_project_path(project_id))
    return {"status": "ok"}


@router.post("/unstage")
def git_unstage_endpoint(req: GitPathsRequest, project_id: str | None = None):
    git_unstage(req.paths, repo=_resolve_project_path(project_id))
    return {"status": "ok"}


@router.post("/discard")
def git_discard_endpoint(req: GitPathsRequest, project_id: str | None = None):
    git_discard(req.paths, repo=_resolve_project_path(project_id))
    return {"status": "ok"}


@router.post("/commit")
def git_commit_endpoint(req: GitCommitRequest, project_id: str | None = None):
    output = git_commit(req.message, repo=_resolve_project_path(project_id))
    return {"output": output}


@router.post("/push")
def git_push_endpoint(project_id: str | None = None):
    output = git_push(repo=_resolve_project_path(project_id))
    return {"output": output}


@router.post("/pull")
def git_pull_endpoint(project_id: str | None = None):
    output = git_pull(repo=_resolve_project_path(project_id))
    return {"output": output}


@router.get("/log", response_model=GitLogResponse)
def get_git_log_endpoint(count: int = 50, project_id: str | None = None):
    return get_git_log(count, repo=_resolve_project_path(project_id))


@router.get("/show/{commit_hash}", response_model=GitCommitDetailResponse)
def get_git_commit_detail_endpoint(commit_hash: str, project_id: str | None = None):
    return get_git_commit_detail(commit_hash, repo=_resolve_project_path(project_id))
