import subprocess
from pathlib import Path

from hypergolic.git.schemas import (
    ChangedFile,
    GitCommitDetailResponse,
    GitDiffResponse,
    GitLogEntry,
    GitLogResponse,
    GitStatusResponse,
)


def git_repo_root() -> Path:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return Path.cwd()


def _run_git(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    repo = cwd or git_repo_root()
    return subprocess.run(
        ["git", *args],
        capture_output=True,
        text=True,
        cwd=repo,
    )


def _parse_numstat(repo: Path, staged: bool) -> dict[str, tuple[int, int]]:
    args = ["diff", "--numstat"]
    if staged:
        args.append("--cached")
    result = _run_git(*args, cwd=repo)
    stats: dict[str, tuple[int, int]] = {}
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) == 3:
            adds = int(parts[0]) if parts[0] != "-" else 0
            dels = int(parts[1]) if parts[1] != "-" else 0
            filepath = parts[2]
            stats[filepath] = (adds, dels)
    return stats


def get_git_status(repo: Path | None = None) -> GitStatusResponse:
    repo = repo or git_repo_root()

    branch_result = _run_git("branch", "--show-current", cwd=repo)
    branch = branch_result.stdout.strip() or "HEAD"

    ahead = 0
    behind = 0
    ab_result = _run_git("rev-list", "--left-right", "--count", "@{upstream}...HEAD", cwd=repo)
    if ab_result.returncode == 0:
        parts = ab_result.stdout.strip().split()
        if len(parts) == 2:
            behind = int(parts[0])
            ahead = int(parts[1])

    status_result = _run_git("status", "--porcelain", "-uall", cwd=repo)

    staged_stats = _parse_numstat(repo, staged=True)
    unstaged_stats = _parse_numstat(repo, staged=False)

    staged: list[ChangedFile] = []
    unstaged: list[ChangedFile] = []
    untracked: list[str] = []

    for line in status_result.stdout.splitlines():
        if len(line) < 4:
            continue
        index_status = line[0]
        worktree_status = line[1]
        filepath = line[3:].strip()
        if " -> " in filepath:
            filepath = filepath.split(" -> ", 1)[1]

        if index_status == "?" and worktree_status == "?":
            untracked.append(filepath)
            continue

        if index_status not in (" ", "?"):
            adds, dels = staged_stats.get(filepath, (0, 0))
            staged.append(ChangedFile(
                path=filepath,
                status=index_status,
                staged=True,
                additions=adds,
                deletions=dels,
            ))

        if worktree_status not in (" ", "?"):
            adds, dels = unstaged_stats.get(filepath, (0, 0))
            unstaged.append(ChangedFile(
                path=filepath,
                status=worktree_status,
                staged=False,
                additions=adds,
                deletions=dels,
            ))

    return GitStatusResponse(
        branch=branch,
        ahead=ahead,
        behind=behind,
        staged=staged,
        unstaged=unstaged,
        untracked=untracked,
    )


def get_git_diff(path: str | None, staged: bool, repo: Path | None = None) -> GitDiffResponse:
    repo = repo or git_repo_root()
    args = ["diff"]
    if staged:
        args.append("--cached")
    if path:
        args.append("--")
        args.append(path)
    result = _run_git(*args, cwd=repo)
    diff_text = result.stdout
    if path and not diff_text and not staged:
        new_result = _run_git("diff", "--no-index", "/dev/null", path, cwd=repo)
        diff_text = new_result.stdout
    return GitDiffResponse(path=path or "", diff=diff_text)


def git_stage(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    _run_git("add", "--", *paths, cwd=repo)


def git_unstage(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    _run_git("reset", "HEAD", "--", *paths, cwd=repo)


def git_discard(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    _run_git("checkout", "--", *paths, cwd=repo)


def git_commit(message: str, repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    result = _run_git("commit", "-m", message, cwd=repo)
    return result.stdout.strip() or result.stderr.strip()


def git_push(repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    result = _run_git("push", cwd=repo)
    if result.returncode != 0 and "no upstream branch" in result.stderr:
        branch_result = _run_git("branch", "--show-current", cwd=repo)
        branch = branch_result.stdout.strip() or "HEAD"
        result = _run_git("push", "--set-upstream", "origin", branch, cwd=repo)
    return result.stdout.strip() or result.stderr.strip()


def git_pull(repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    result = _run_git("pull", cwd=repo)
    return result.stdout.strip() or result.stderr.strip()


def get_git_commit_detail(commit_hash: str, repo: Path | None = None) -> GitCommitDetailResponse:
    repo = repo or git_repo_root()
    sep = "\x1f"
    fmt = sep.join(["%H", "%h", "%an", "%aI", "%s"])
    result = _run_git("log", f"--format={fmt}", "-1", "--end-of-options", commit_hash, cwd=repo)
    parts = result.stdout.strip().split(sep)
    if len(parts) != 5:
        return GitCommitDetailResponse(
            hash=commit_hash, short_hash=commit_hash[:7],
            author="", date="", message="", diff="",
        )
    diff_result = _run_git("diff-tree", "-p", "--no-commit-id", "--end-of-options", commit_hash, cwd=repo)
    return GitCommitDetailResponse(
        hash=parts[0], short_hash=parts[1],
        author=parts[2], date=parts[3], message=parts[4],
        diff=diff_result.stdout,
    )


def get_git_log(count: int = 50, repo: Path | None = None) -> GitLogResponse:
    repo = repo or git_repo_root()
    sep = "\x1f"
    fmt = sep.join(["%H", "%h", "%an", "%aI", "%s", "%D"])
    result = _run_git("log", f"--format={fmt}", f"-{count}", cwd=repo)
    entries: list[GitLogEntry] = []
    for line in result.stdout.splitlines():
        parts = line.split(sep)
        if len(parts) != 6:
            continue
        entries.append(GitLogEntry(
            hash=parts[0],
            short_hash=parts[1],
            author=parts[2],
            date=parts[3],
            message=parts[4],
            refs=parts[5],
        ))
    return GitLogResponse(entries=entries)
