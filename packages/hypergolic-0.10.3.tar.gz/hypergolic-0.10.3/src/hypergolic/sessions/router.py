from pathlib import Path

from fastapi import APIRouter, HTTPException
from sqlalchemy import select, delete as sa_delete, func

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBArtifact, DBError, DBSession, DBMessage, DBProject, DBSessionSkill, DBSessionWorkflow
from hypergolic.db.utils import to_iso_utc
from hypergolic.mcptools.tool_bridge import parse_mcp_tool_id
from hypergolic.prompts.builder import build_prompt_blocks
from hypergolic.sessions.operations import create_session, load_session
from hypergolic.sessions.schemas import (
    CreateSessionRequest,
    MessageResponse,
    PromptPartInfo,
    RoleInfo,
    SessionResponse,
    SkillInfo,
    ToolInfo,
)
from hypergolic.skills.resolver import resolve_roles, resolve_skills
from hypergolic.tools.approval import get_effective_action, RuleAction
from hypergolic.tools.tool_list import build_tools, get_tool_source
from hypergolic.workflows.resolver import get_session_workflow, get_workflow_config, resolve_workflows
from hypergolic.workflows.schemas import WorkflowDetailResponse, WorkflowStateDetail, WorkflowToolDetail, WorkflowOutputSchemaDetail

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


def _session_response(
    row: DBSession,
    project_name: str,
    message_count: int = 0,
    project_path: str | None = None,
) -> SessionResponse:
    workflow_id = None
    workflow_name = None
    workflow_state_id = None
    workflow_state_name = None

    wf_state = get_session_workflow(row.id)
    if wf_state:
        workflow_id, workflow_state_id = wf_state
        pp = Path(project_path) if project_path else None
        wf = get_workflow_config(workflow_id, pp)
        if wf:
            workflow_name = wf.name
            for s in wf.states:
                if s.id == workflow_state_id:
                    workflow_state_name = s.name
                    break

    return SessionResponse(
        id=row.id,
        model_tier=row.model_tier,
        project_id=row.project_id,
        project_name=project_name,
        role=row.role,
        status=row.status,
        created_at=to_iso_utc(row.created_at),
        updated_at=to_iso_utc(row.updated_at),
        message_count=message_count,
        workflow_id=workflow_id,
        workflow_name=workflow_name,
        workflow_state_id=workflow_state_id,
        workflow_state_name=workflow_state_name,
    )


@router.get("", response_model=list[SessionResponse])
def list_sessions(project_id: str | None = None):
    with get_db() as db:
        msg_count_subq = (
            select(
                DBMessage.session_id,
                func.count(DBMessage.id).label("msg_count"),
            )
            .group_by(DBMessage.session_id)
            .subquery()
        )
        stmt = (
            select(DBSession, DBProject.name, DBProject.path, msg_count_subq.c.msg_count)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .outerjoin(msg_count_subq, DBSession.id == msg_count_subq.c.session_id)
            .order_by(
                (func.coalesce(msg_count_subq.c.msg_count, 0) == 0).desc(),
                DBSession.updated_at.desc(),
            )
        )
        if project_id:
            stmt = stmt.where(DBSession.project_id == project_id)
        rows = db.execute(stmt).all()
        return [
            _session_response(session, project_name, msg_count or 0, project_path=project_path)
            for session, project_name, project_path, msg_count in rows
        ]


@router.post("", response_model=SessionResponse)
def create_session_endpoint(req: CreateSessionRequest):
    session = create_session(project_id=req.project_id, model_tier=req.model_tier, role=req.role)
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.name, DBProject.path)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session.id)
        ).one()
        return _session_response(row[0], row[1], project_path=row[2])


@router.get("/roles", response_model=list[RoleInfo])
def list_roles(project_id: str | None = None):
    project_path: Path | None = None
    if project_id:
        with get_db() as db:
            project = db.execute(
                select(DBProject).where(DBProject.id == project_id)
            ).scalar_one_or_none()
            if project:
                project_path = Path(project.path)

    roles = resolve_roles(project_path)
    return [RoleInfo(id=r["id"], name=r["name"], source=r["source"]) for r in roles]


@router.delete("/{session_id}")
def delete_session_endpoint(session_id: str):
    with get_db() as db:
        db.execute(
            sa_delete(DBError).where(DBError.session_id == session_id)
        )
        db.execute(
            sa_delete(DBArtifact).where(DBArtifact.session_id == session_id)
        )
        db.execute(
            sa_delete(DBSessionWorkflow).where(DBSessionWorkflow.session_id == session_id)
        )
        db.execute(
            sa_delete(DBSessionSkill).where(DBSessionSkill.session_id == session_id)
        )
        db.execute(
            sa_delete(DBMessage).where(DBMessage.session_id == session_id)
        )
        db.execute(
            sa_delete(DBSession).where(DBSession.id == session_id)
        )
    return {"status": "deleted"}


@router.get("/{session_id}/messages", response_model=list[MessageResponse])
def get_session_messages(session_id: str):
    with get_db() as db:
        rows = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .order_by(DBMessage.created_at)
        ).scalars().all()
        return [
            MessageResponse(
                id=r.id,
                session_id=r.session_id,
                role=r.role,
                content=r.content,
                model=r.model,
                stop_reason=r.stop_reason,
                usage=r.usage,
                truncated=r.truncated,
                created_at=to_iso_utc(r.created_at),
            )
            for r in rows
        ]



@router.get("/{session_id}/tools", response_model=list[ToolInfo])
def get_session_tools(session_id: str):
    session = load_session(session_id)

    build_result = build_tools(session=session)
    result = []
    for t in build_result.tools:
        mcp_parsed = parse_mcp_tool_id(t.id)
        action = get_effective_action(
            t.id, {}, project_id=session.project_id,
            session_id=session.id, project_path=session.project_path,
        )
        try:
            raw = t.to_param().get("input_schema")
            schema = dict(raw) if raw else None
        except Exception:
            schema = None
        result.append(ToolInfo(
            id=t.id,
            name=t.name,
            description=t.description,
            source=get_tool_source(t.id, build_result.custom_sources),
            requires_approval=action != RuleAction.ALLOW,
            mcp_server=mcp_parsed[0] if mcp_parsed else None,
            input_schema=schema,
        ))
    return result


@router.get("/{session_id}/prompt", response_model=list[PromptPartInfo])
def get_session_prompt(session_id: str):
    session = load_session(session_id)

    blocks = build_prompt_blocks(session)

    return [
        PromptPartInfo(
            source=block.source,
            content=block.text,
            token_estimate=len(block.text) // 4,
        )
        for block in blocks
    ]


@router.post("/{session_id}/skills/{skill_id}/activate")
def activate_skill(session_id: str, skill_id: str):
    session = load_session(session_id)
    project_path = session.working_directory()

    all_skills = {s["id"]: s for s in resolve_skills(project_path)}
    if skill_id not in all_skills:
        raise HTTPException(status_code=404, detail=f"Skill '{skill_id}' not found")

    with get_db() as db:
        already = db.execute(
            select(DBSessionSkill)
            .where(DBSessionSkill.session_id == session_id)
            .where(DBSessionSkill.skill_id == skill_id)
        ).scalar_one_or_none()
        if not already:
            db.add(DBSessionSkill(session_id=session_id, skill_id=skill_id))

    return {"status": "activated"}


@router.post("/{session_id}/skills/{skill_id}/deactivate")
def deactivate_skill(session_id: str, skill_id: str):
    with get_db() as db:
        db.execute(
            sa_delete(DBSessionSkill)
            .where(DBSessionSkill.session_id == session_id)
            .where(DBSessionSkill.skill_id == skill_id)
        )
    return {"status": "deactivated"}


@router.get("/{session_id}/workflows", response_model=list[WorkflowDetailResponse])
def get_session_workflows(session_id: str):
    session = load_session(session_id)
    project_path = session.working_directory()
    workflows = resolve_workflows(project_path)
    return [
        WorkflowDetailResponse(
            id=wf.id,
            name=wf.name,
            description=wf.description or "",
            prompt_path=wf.prompt_path,
            initial_state=wf.initial_state,
            states=[
                WorkflowStateDetail(
                    id=s.id,
                    name=s.name,
                    prompt_path=s.prompt_path,
                    skills=s.skills,
                    tools=[
                        WorkflowToolDetail(id=t.id, name=t.name, description=t.description)
                        for t in s.tools
                    ],
                    truncate_on_entry=s.truncate_on_entry,
                    include_artifacts=s.include_artifacts,
                    output_schemas=[
                        WorkflowOutputSchemaDetail(
                            outcome=o.outcome,
                            next_state=o.next_state,
                            artifact_id=o.artifact_id,
                            requires_approval=o.requires_approval,
                            display=o.display,
                            schema_def=o.schema_def,
                        )
                        for o in s.output_schemas
                    ],
                )
                for s in wf.states
            ],
        )
        for wf in workflows
    ]


@router.get("/{session_id}/skills", response_model=list[SkillInfo])
def get_session_skills(session_id: str):
    session = load_session(session_id)
    project_path = session.working_directory()

    with get_db() as db:
        active_skill_ids = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
            ).scalars().all()
        )

    all_skills = resolve_skills(project_path)
    return [
        SkillInfo(
            id=s["id"],
            name=s["name"],
            description=s["description"],
            source=s["source"],
            active=s["id"] in active_skill_ids,
        )
        for s in all_skills
    ]

