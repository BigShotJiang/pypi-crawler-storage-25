from sqlalchemy import update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.enums import SessionStatus
from hypergolic.messages.types import BroadcastEvent, BroadcastFn


def set_session_status(session_id: str, status: SessionStatus) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(status=status)
        )


async def set_session_status_and_broadcast(
    session_id: str,
    status: SessionStatus,
    broadcast: BroadcastFn,
) -> None:
    set_session_status(session_id, status)
    await broadcast(
        BroadcastEvent(
            type="session_status_change",
            role="system",
            content=[{"status": status.value}],
            session_id=session_id,
        )
    )
