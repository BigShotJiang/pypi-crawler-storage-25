from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from hypergolic.messages.truncation import TRUNCATE_TOKEN_THRESHOLD, should_truncate


class TestTruncateTokenThreshold:
    def test_threshold_is_positive(self):
        assert TRUNCATE_TOKEN_THRESHOLD > 0

    def test_threshold_is_100k(self):
        assert TRUNCATE_TOKEN_THRESHOLD == 100_000


class TestShouldTruncate:
    """Tests for should_truncate using the DB ordering."""

    def _make_row(self, *, msg_id: str, created_at: datetime, input_tokens: int):
        row = MagicMock()
        row.id = msg_id
        row.created_at = created_at
        row.usage = {
            "input_tokens": input_tokens,
            "cache_read_input_tokens": 0,
            "cache_creation_input_tokens": 0,
        }
        return row

    @patch("hypergolic.messages.truncation.get_db")
    def test_returns_false_when_no_messages(self, mock_get_db):
        db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        db.execute.return_value.scalar_one_or_none.return_value = None

        assert should_truncate("session-1") is False

    @patch("hypergolic.messages.truncation.get_db")
    def test_returns_false_when_under_threshold(self, mock_get_db):
        db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        db.execute.return_value.scalar_one_or_none.return_value = self._make_row(
            msg_id="msg_1",
            created_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
            input_tokens=50_000,
        )

        assert should_truncate("session-1") is False

    @patch("hypergolic.messages.truncation.get_db")
    def test_returns_true_when_over_threshold(self, mock_get_db):
        db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        db.execute.return_value.scalar_one_or_none.return_value = self._make_row(
            msg_id="msg_1",
            created_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
            input_tokens=150_000,
        )

        assert should_truncate("session-1") is True

    @patch("hypergolic.messages.truncation.get_db")
    def test_returns_false_when_usage_is_none(self, mock_get_db):
        db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        row = MagicMock()
        row.usage = None
        db.execute.return_value.scalar_one_or_none.return_value = row

        assert should_truncate("session-1") is False

    @patch("hypergolic.messages.truncation.get_db")
    def test_sums_all_token_types(self, mock_get_db):
        db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        row = MagicMock()
        row.usage = {
            "input_tokens": 40_000,
            "cache_read_input_tokens": 40_000,
            "cache_creation_input_tokens": 40_000,
        }
        db.execute.return_value.scalar_one_or_none.return_value = row

        assert should_truncate("session-1") is True

    @patch("hypergolic.messages.truncation.get_db")
    def test_query_orders_by_created_at_not_id(self, mock_get_db):
        """Verify the query uses created_at ordering (not id, which is non-chronological)."""
        db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        db.execute.return_value.scalar_one_or_none.return_value = None

        should_truncate("session-1")

        call_args = db.execute.call_args[0][0]
        compiled = str(call_args.compile(compile_kwargs={"literal_binds": True}))
        assert "ORDER BY" in compiled
        assert "created_at" in compiled
        assert "messages.id" not in compiled.split("ORDER BY")[1]
