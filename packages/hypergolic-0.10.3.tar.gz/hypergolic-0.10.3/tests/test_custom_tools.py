from hypergolic.config.schemas import CustomToolConfig, CustomToolParam
from hypergolic.tools.custom import _build_input_model, _interpolate_command


class TestBuildInputModel:
    def test_no_parameters(self):
        config = CustomToolConfig(
            id="test", name="Test", description="d", command="echo hi"
        )
        model = _build_input_model(config)
        instance = model()
        assert instance.model_dump() == {}

    def test_required_string_param(self):
        config = CustomToolConfig(
            id="test", name="Test", description="d", command="echo",
            parameters=[CustomToolParam(name="msg", type="string", description="message")],
        )
        model = _build_input_model(config)
        instance = model(msg="hello")
        assert instance.model_dump() == {"msg": "hello"}

    def test_optional_param_with_default(self):
        config = CustomToolConfig(
            id="test", name="Test", description="d", command="echo",
            parameters=[
                CustomToolParam(name="count", type="integer", required=False, default=5, description="n"),
            ],
        )
        model = _build_input_model(config)
        instance = model()
        assert instance.model_dump() == {"count": 5}

    def test_boolean_param(self):
        config = CustomToolConfig(
            id="test", name="Test", description="d", command="cmd",
            parameters=[
                CustomToolParam(name="verbose", type="boolean", description="v"),
            ],
        )
        model = _build_input_model(config)
        instance = model(verbose=True)
        assert instance.model_dump() == {"verbose": True}

    def test_multiple_params(self):
        config = CustomToolConfig(
            id="test", name="Test", description="d", command="cmd",
            parameters=[
                CustomToolParam(name="name", type="string", description="n"),
                CustomToolParam(name="count", type="integer", description="c"),
                CustomToolParam(name="dry", type="boolean", required=False, default=False, description="d"),
            ],
        )
        model = _build_input_model(config)
        instance = model(name="test", count=3)
        data = instance.model_dump()
        assert data["name"] == "test"
        assert data["count"] == 3
        assert data["dry"] is False


class TestInterpolateCommand:
    def test_simple_substitution(self):
        from pydantic import BaseModel

        class Input(BaseModel):
            name: str

        result = _interpolate_command("echo {{name}}", Input(name="hello"))
        assert result == "echo hello"

    def test_multiple_substitutions(self):
        from pydantic import BaseModel

        class Input(BaseModel):
            a: str
            b: str

        result = _interpolate_command("cmd {{a}} --flag {{b}}", Input(a="x", b="y"))
        assert result == "cmd x --flag y"

    def test_missing_param_removed(self):
        from pydantic import BaseModel

        class Input(BaseModel):
            name: str | None = None

        result = _interpolate_command("echo {{name}} done", Input())
        assert "done" in result

    def test_special_chars_quoted(self):
        from pydantic import BaseModel

        class Input(BaseModel):
            msg: str

        result = _interpolate_command("echo {{msg}}", Input(msg="hello world"))
        assert "'hello world'" in result or '"hello world"' in result
