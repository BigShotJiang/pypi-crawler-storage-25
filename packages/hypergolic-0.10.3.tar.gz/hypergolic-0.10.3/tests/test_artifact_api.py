from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from hypergolic.workflows.router import list_artifacts, get_artifact


def _make_artifact_row(**overrides):
    row = MagicMock()
    row.id = overrides.get("id", "art-1")
    row.session_id = overrides.get("session_id", "sess-1")
    row.workflow_id = overrides.get("workflow_id", "feature-dev")
    row.state_id = overrides.get("state_id", "requirements")
    row.outcome = overrides.get("outcome", "success")
    row.artifact_id = overrides.get("artifact_id", "prd")
    row.content = overrides.get("content", {"document": "# PRD"})
    row.created_at = overrides.get(
        "created_at", datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
    )
    return row


def _mock_db(rows=None, scalar=None):
    mock_get_db = MagicMock()
    mock_db = MagicMock()
    if rows is not None:
        mock_db.execute.return_value.scalars.return_value.all.return_value = rows
    if scalar is not None:
        mock_db.execute.return_value.scalar_one_or_none.return_value = scalar
    mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
    mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
    return mock_get_db


class TestListArtifacts:
    @patch("hypergolic.workflows.router.get_db")
    def test_empty(self, mock_get_db):
        mock_get_db.side_effect = _mock_db(rows=[]).side_effect
        mock_get_db.return_value = _mock_db(rows=[]).return_value

        result = list_artifacts(
            session_id=None, workflow_id=None, state_id=None,
            outcome=None, artifact_id=None, limit=50, offset=0,
        )
        assert result == []

    @patch("hypergolic.workflows.router.get_db")
    def test_returns_artifacts(self, mock_get_db):
        rows = [_make_artifact_row(), _make_artifact_row(id="art-2", artifact_id="plan")]
        mock_get_db.return_value = _mock_db(rows=rows).return_value

        result = list_artifacts(
            session_id=None, workflow_id=None, state_id=None,
            outcome=None, artifact_id=None, limit=50, offset=0,
        )
        assert len(result) == 2
        assert result[0].id == "art-1"
        assert result[0].artifact_id == "prd"
        assert result[1].id == "art-2"
        assert result[1].artifact_id == "plan"

    @patch("hypergolic.workflows.router.get_db")
    def test_response_fields(self, mock_get_db):
        row = _make_artifact_row()
        mock_get_db.return_value = _mock_db(rows=[row]).return_value

        result = list_artifacts(
            session_id=None, workflow_id=None, state_id=None,
            outcome=None, artifact_id=None, limit=50, offset=0,
        )
        art = result[0]
        assert art.session_id == "sess-1"
        assert art.workflow_id == "feature-dev"
        assert art.state_id == "requirements"
        assert art.outcome == "success"
        assert art.content == {"document": "# PRD"}
        assert "2025" in art.created_at


class TestGetArtifact:
    @patch("hypergolic.workflows.router.get_db")
    def test_found(self, mock_get_db):
        row = _make_artifact_row()
        mock_get_db.return_value = _mock_db(scalar=row).return_value

        result = get_artifact("art-1")
        assert result.id == "art-1"
        assert result.artifact_id == "prd"

    @patch("hypergolic.workflows.router.get_db")
    def test_not_found(self, mock_get_db):
        mock_db = MagicMock()
        mock_db.execute.return_value.scalar_one_or_none.return_value = None
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        from fastapi import HTTPException
        with pytest.raises(HTTPException) as exc_info:
            get_artifact("nonexistent")
        assert exc_info.value.status_code == 404
