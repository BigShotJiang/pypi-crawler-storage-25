import ast
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parent.parent / "src" / "hypergolic"

ALLOWED_INLINE_IMPORTS: set[tuple[str, str]] = {
    # Circular import guards
    ("tools/activate_workflow.py", "hypergolic.workflows.engine"),
    ("workflows/engine.py", "hypergolic.skills.resolver"),
    ("workflows/tools.py", "hypergolic.workflows.engine"),
    # Lazy init to avoid eager DB connection at import time
    ("db/engine.py", "hypergolic.config.settings"),
}


def _find_inline_imports() -> list[tuple[str, int, str]]:
    violations: list[tuple[str, int, str]] = []

    for py_file in sorted(SRC_DIR.rglob("*.py")):
        source = py_file.read_text()
        try:
            tree = ast.parse(source, filename=str(py_file))
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for child in ast.walk(node):
                if isinstance(child, ast.Import):
                    for alias in child.names:
                        rel = str(py_file.relative_to(SRC_DIR))
                        key = (rel, alias.name)
                        if key not in ALLOWED_INLINE_IMPORTS:
                            violations.append(
                                (rel, child.lineno, f"import {alias.name}")
                            )
                elif isinstance(child, ast.ImportFrom):
                    module = child.module or ""
                    rel = str(py_file.relative_to(SRC_DIR))
                    key = (rel, module)
                    if key not in ALLOWED_INLINE_IMPORTS:
                        names = ", ".join(a.name for a in child.names)
                        violations.append(
                            (rel, child.lineno, f"from {module} import {names}")
                        )

    return violations


def test_no_inline_imports():
    violations = _find_inline_imports()
    if violations:
        lines = ["Inline imports found (move to top of file):"]
        for path, lineno, stmt in violations:
            lines.append(f"  {path}:{lineno} — {stmt}")
        raise AssertionError("\n".join(lines))
