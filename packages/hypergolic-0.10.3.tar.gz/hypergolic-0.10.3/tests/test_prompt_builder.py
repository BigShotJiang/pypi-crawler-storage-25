import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from hypergolic.prompts.builder import _build_session_context, _detect_uv_tools_dir


@pytest.fixture
def session():
    s = MagicMock()
    s.id = "test-session-id"
    s.working_directory.return_value = Path("/tmp/test-project")
    return s


class TestDetectUvToolsDir:
    @patch("hypergolic.prompts.builder.subprocess.run")
    def test_returns_path_on_success(self, mock_run):
        mock_run.return_value = MagicMock(
            stdout="/home/user/.local/share/uv/tools\n",
            returncode=0,
        )
        assert _detect_uv_tools_dir() == "/home/user/.local/share/uv/tools"

    @patch("hypergolic.prompts.builder.subprocess.run")
    def test_returns_none_on_failure(self, mock_run):
        mock_run.side_effect = FileNotFoundError
        assert _detect_uv_tools_dir() is None

    @patch("hypergolic.prompts.builder.subprocess.run")
    def test_returns_none_on_nonzero_exit(self, mock_run):
        mock_run.side_effect = subprocess.CalledProcessError(1, "uv")
        assert _detect_uv_tools_dir() is None


class TestSessionContext:
    @patch("hypergolic.prompts.builder._detect_uv_tools_dir", return_value="/home/user/.local/share/uv/tools")
    @patch("hypergolic.prompts.builder._git_branch", return_value="main")
    @patch("hypergolic.prompts.builder._get_config_paths", return_value=[])
    def test_includes_uv_tools_dir(self, _config, _git, _uv, session):
        context = _build_session_context(session)
        assert "/home/user/.local/share/uv/tools" in context
        assert "UV Tools" in context

    @patch("hypergolic.prompts.builder._detect_uv_tools_dir", return_value=None)
    @patch("hypergolic.prompts.builder._git_branch", return_value=None)
    @patch("hypergolic.prompts.builder._get_config_paths", return_value=[])
    def test_omits_uv_tools_dir_when_not_found(self, _config, _git, _uv, session):
        context = _build_session_context(session)
        assert "UV Tools" not in context
