import asyncio

import pytest
from pathlib import Path

from tests.helpers import text_of, make_ctx

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.read_files import ReadFilesInput, read_files


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


class TestReadFiles:
    def test_read_single_file(self, tmp_path: Path, session: Session):
        f = tmp_path / "hello.txt"
        f.write_text("hello world")
        result = asyncio.run(read_files(ReadFilesInput(paths=[str(f)]), make_ctx(session)))
        assert result.is_error is False
        assert "hello world" in text_of(result.content[0])
        assert "hello.txt" in text_of(result.content[0])

    def test_file_not_found(self, tmp_path: Path, session: Session):
        result = asyncio.run(read_files(
            ReadFilesInput(paths=[str(tmp_path / "nope.txt")]), make_ctx(session)
        ))
        assert result.is_error is True
        assert "not found" in text_of(result.content[0]).lower()

    def test_not_a_file(self, tmp_path: Path, session: Session):
        d = tmp_path / "adir"
        d.mkdir()
        result = asyncio.run(read_files(ReadFilesInput(paths=[str(d)]), make_ctx(session)))
        assert result.is_error is True
        assert "Not a file" in text_of(result.content[0])

    def test_multiple_files(self, tmp_path: Path, session: Session):
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        f1.write_text("aaa")
        f2.write_text("bbb")
        result = asyncio.run(read_files(
            ReadFilesInput(paths=[str(f1), str(f2)]), make_ctx(session)
        ))
        assert result.is_error is False
        assert len(result.content) == 2
        assert "aaa" in text_of(result.content[0])
        assert "bbb" in text_of(result.content[1])

    def test_empty_paths(self, session: Session):
        result = asyncio.run(read_files(ReadFilesInput(paths=[]), make_ctx(session)))
        assert "No files provided" in text_of(result.content[0])

    def test_binary_file(self, tmp_path: Path, session: Session):
        f = tmp_path / "binary.bin"
        f.write_bytes(b"\x80\x81\x82")
        result = asyncio.run(read_files(ReadFilesInput(paths=[str(f)]), make_ctx(session)))
        assert result.is_error is True
        assert "UTF-8" in text_of(result.content[0])

    def test_relative_path(self, tmp_path: Path, session: Session):
        f = tmp_path / "rel.txt"
        f.write_text("content")
        result = asyncio.run(read_files(ReadFilesInput(paths=["rel.txt"]), make_ctx(session)))
        assert result.is_error is False
        assert "content" in text_of(result.content[0])

    def test_mixed_success_and_error(self, tmp_path: Path, session: Session):
        f = tmp_path / "good.txt"
        f.write_text("good")
        result = asyncio.run(read_files(
            ReadFilesInput(paths=[str(f), str(tmp_path / "bad.txt")]),
            make_ctx(session),
        ))
        assert result.is_error is True
        assert "good" in text_of(result.content[0])
        assert "not found" in text_of(result.content[1]).lower()
