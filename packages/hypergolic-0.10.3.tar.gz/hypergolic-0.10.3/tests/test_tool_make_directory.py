import asyncio

import pytest
from pathlib import Path

from tests.helpers import text_of, make_ctx

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.make_directory import MakeDirectoryInput, make_directory, _make_single_directory


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


class TestMakeSingleDirectory:
    def test_create_new_directory(self, tmp_path: Path, session: Session):
        msg, err = _make_single_directory(str(tmp_path / "new"), session)
        assert "Created" in msg
        assert err is False
        assert (tmp_path / "new").is_dir()

    def test_already_exists(self, tmp_path: Path, session: Session):
        d = tmp_path / "existing"
        d.mkdir()
        msg, err = _make_single_directory(str(d), session)
        assert "already exists" in msg
        assert err is False

    def test_nested_creation(self, tmp_path: Path, session: Session):
        deep = tmp_path / "a" / "b" / "c"
        msg, err = _make_single_directory(str(deep), session)
        assert "Created" in msg
        assert deep.is_dir()

    def test_relative_path(self, tmp_path: Path, session: Session):
        msg, err = _make_single_directory("reldir", session)
        assert "Created" in msg
        assert (tmp_path / "reldir").is_dir()


class TestMakeDirectory:
    def test_single_path(self, tmp_path: Path, session: Session):
        result = asyncio.run(make_directory(
            MakeDirectoryInput(path=str(tmp_path / "new")), make_ctx(session)
        ))
        assert result.is_error is False
        assert "Created" in text_of(result.content[0])

    def test_batch_paths(self, tmp_path: Path, session: Session):
        result = asyncio.run(make_directory(
            MakeDirectoryInput(paths=[
                str(tmp_path / "dir1"),
                str(tmp_path / "dir2"),
            ]),
            make_ctx(session),
        ))
        assert result.is_error is False
        assert len(result.content) == 2
        assert (tmp_path / "dir1").is_dir()
        assert (tmp_path / "dir2").is_dir()

    def test_no_path_or_paths_error(self, session: Session):
        result = asyncio.run(make_directory(MakeDirectoryInput(), make_ctx(session)))
        assert result.is_error is True
        assert "required" in text_of(result.content[0])

    def test_paths_takes_precedence_over_path(self, tmp_path: Path, session: Session):
        result = asyncio.run(make_directory(
            MakeDirectoryInput(
                path=str(tmp_path / "single"),
                paths=[str(tmp_path / "batch1"), str(tmp_path / "batch2")],
            ),
            make_ctx(session),
        ))
        assert len(result.content) == 2
        assert (tmp_path / "batch1").is_dir()
        assert (tmp_path / "batch2").is_dir()
