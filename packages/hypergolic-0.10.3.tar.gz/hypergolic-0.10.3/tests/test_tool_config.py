import asyncio
import json

import pytest
from pathlib import Path

from tests.helpers import text_of, make_ctx

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.config import (
    EditConfigInput,
    edit_config,
)


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


@pytest.fixture
def user_agents_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    agents_dir = tmp_path / "home" / ".agents"
    agents_dir.mkdir(parents=True)
    monkeypatch.setattr(
        "hypergolic.tools.config.USER_CONFIG_PATH", agents_dir / "config.json"
    )
    return agents_dir


class TestEditConfig:
    def test_write_valid_user_config(self, session: Session, user_agents_dir: Path):
        content = json.dumps({"tools": [], "skills": []})
        result = asyncio.run(
            edit_config(EditConfigInput(target="user", content=content), make_ctx(session))
        )
        assert result.is_error is False
        assert "Successfully wrote" in text_of(result.content[0])

        written = json.loads((user_agents_dir / "config.json").read_text())
        assert written["tools"] == []
        assert written["skills"] == []

    def test_write_valid_project_config(self, tmp_path: Path, session: Session, user_agents_dir: Path):
        content = json.dumps({"name": "MyProject", "tools": []})
        result = asyncio.run(
            edit_config(EditConfigInput(target="project", content=content), make_ctx(session))
        )
        assert result.is_error is False

        config_path = tmp_path / ".agents" / "config.json"
        assert config_path.exists()
        written = json.loads(config_path.read_text())
        assert written["name"] == "MyProject"

    def test_invalid_json(self, session: Session, user_agents_dir: Path):
        result = asyncio.run(
            edit_config(EditConfigInput(target="user", content="{not json}"), make_ctx(session))
        )
        assert result.is_error is True
        assert "Invalid JSON" in text_of(result.content[0])

    def test_schema_validation_error_user(self, session: Session, user_agents_dir: Path):
        content = json.dumps({"tools": "not a list"})
        result = asyncio.run(
            edit_config(EditConfigInput(target="user", content=content), make_ctx(session))
        )
        assert result.is_error is True
        assert "Schema validation failed" in text_of(result.content[0])
        assert "tools" in text_of(result.content[0])

    def test_schema_validation_error_project(self, session: Session, user_agents_dir: Path):
        content = json.dumps({"mcp_servers": "wrong"})
        result = asyncio.run(
            edit_config(EditConfigInput(target="project", content=content), make_ctx(session))
        )
        assert result.is_error is True
        assert "Schema validation failed" in text_of(result.content[0])

    def test_does_not_write_on_validation_error(
        self, session: Session, user_agents_dir: Path
    ):
        content = json.dumps({"tools": "bad"})
        asyncio.run(
            edit_config(EditConfigInput(target="user", content=content), make_ctx(session))
        )
        assert not (user_agents_dir / "config.json").exists()

    def test_creates_parent_directories(
        self, tmp_path: Path, session: Session, user_agents_dir: Path
    ):
        project_agents = tmp_path / ".agents"
        assert not project_agents.exists()

        content = json.dumps({"name": "New"})
        result = asyncio.run(
            edit_config(EditConfigInput(target="project", content=content), make_ctx(session))
        )
        assert result.is_error is False
        assert (project_agents / "config.json").exists()

    def test_overwrites_existing_config(
        self, session: Session, user_agents_dir: Path
    ):
        config_path = user_agents_dir / "config.json"
        config_path.write_text(json.dumps({"tools": []}))

        new_content = json.dumps({
            "tools": [{
                "id": "test",
                "name": "Test",
                "description": "A test tool",
                "command": "echo hi",
            }]
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user", content=new_content), make_ctx(session))
        )
        assert result.is_error is False

        written = json.loads(config_path.read_text())
        assert len(written["tools"]) == 1
        assert written["tools"][0]["id"] == "test"

    def test_output_is_formatted(self, session: Session, user_agents_dir: Path):
        content = json.dumps({"name": "Fmt"})
        asyncio.run(
            edit_config(EditConfigInput(target="project", content=content), make_ctx(session))
        )
        # edit_config writes to project path, but we check user for this test
        # Actually let's check the project one
        config_path = Path(session.project_path) / ".agents" / "config.json"
        raw = config_path.read_text()
        assert raw.startswith("{\n")
        assert raw.endswith("\n")

    def test_write_user_project_new_project(self, session: Session, user_agents_dir: Path):
        """Writing user-project when no projects exist creates the entry."""
        (user_agents_dir / "config.json").write_text(json.dumps({"tools": []}))

        content = json.dumps({
            "git_root": session.project_path,
            "name": "TestProject",
            "tools": [{
                "id": "lint",
                "name": "Lint",
                "description": "Run linter",
                "command": "ruff check .",
            }],
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user-project", content=content), make_ctx(session))
        )
        assert result.is_error is False

        written = json.loads((user_agents_dir / "config.json").read_text())
        assert len(written["projects"]) == 1
        assert written["projects"][0]["name"] == "TestProject"
        assert written["tools"] == []

    def test_write_user_project_updates_existing(self, session: Session, user_agents_dir: Path):
        """Writing user-project for an existing git_root replaces that entry."""
        existing = {
            "tools": [],
            "projects": [{
                "git_root": session.project_path,
                "name": "OldName",
            }],
        }
        (user_agents_dir / "config.json").write_text(json.dumps(existing))

        content = json.dumps({
            "git_root": session.project_path,
            "name": "NewName",
            "skills": ["my-skill"],
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user-project", content=content), make_ctx(session))
        )
        assert result.is_error is False

        written = json.loads((user_agents_dir / "config.json").read_text())
        assert len(written["projects"]) == 1
        assert written["projects"][0]["name"] == "NewName"

    def test_write_user_project_preserves_other_projects(self, session: Session, user_agents_dir: Path):
        """Updating one project entry doesn't touch others."""
        existing = {
            "tools": [],
            "projects": [
                {"git_root": "/other/project", "name": "Other"},
                {"git_root": session.project_path, "name": "Mine"},
            ],
        }
        (user_agents_dir / "config.json").write_text(json.dumps(existing))

        content = json.dumps({
            "git_root": session.project_path,
            "name": "Updated",
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user-project", content=content), make_ctx(session))
        )
        assert result.is_error is False

        written = json.loads((user_agents_dir / "config.json").read_text())
        assert len(written["projects"]) == 2
        names = {p["name"] for p in written["projects"]}
        assert names == {"Other", "Updated"}

    def test_write_user_project_validation_error(self, session: Session, user_agents_dir: Path):
        (user_agents_dir / "config.json").write_text(json.dumps({"tools": []}))

        content = json.dumps({
            "git_root": session.project_path,
            "name": "Test",
            "mcp_servers": "not a dict",
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user-project", content=content), make_ctx(session))
        )
        assert result.is_error is True
        assert "Schema validation failed" in text_of(result.content[0])

    def test_write_user_project_creates_user_config_if_missing(self, session: Session, user_agents_dir: Path):
        """If no user config exists yet, creates one with just the project entry."""
        content = json.dumps({
            "git_root": session.project_path,
            "name": "Brand New",
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user-project", content=content), make_ctx(session))
        )
        assert result.is_error is False

        written = json.loads((user_agents_dir / "config.json").read_text())
        assert len(written["projects"]) == 1
        assert written["projects"][0]["name"] == "Brand New"

    def test_valid_full_user_config(self, session: Session, user_agents_dir: Path):
        content = json.dumps({
            "mcp_servers": {
                "test-server": {
                    "transport": "stdio",
                    "command": "test-cmd",
                    "args": ["--flag"],
                }
            },
            "tools": [{
                "id": "my-tool",
                "name": "My Tool",
                "description": "Does things",
                "command": "do-thing",
                "timeout": 60,
                "requires_approval": True,
                "parameters": [{
                    "name": "arg1",
                    "type": "string",
                    "description": "First arg",
                    "required": True,
                }],
            }],
            "skills": [{
                "id": "my-skill",
                "name": "My Skill",
                "description": "A skill",
                "prompt_path": "~/.agents/skills/my-skill.md",
            }],
        })
        result = asyncio.run(
            edit_config(EditConfigInput(target="user", content=content), make_ctx(session))
        )
        assert result.is_error is False
