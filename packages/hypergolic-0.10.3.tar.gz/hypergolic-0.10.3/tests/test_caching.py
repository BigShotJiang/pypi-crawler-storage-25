from copy import deepcopy

from anthropic.types import MessageParam

from hypergolic.messages.caching import _strip_cache_control, set_message_cache_breakpoint


def _text_block(text: str, cached: bool = False) -> dict:
    block: dict = {"type": "text", "text": text}
    if cached:
        block["cache_control"] = {"type": "ephemeral"}
    return block


def _msg(role: str, blocks: list[dict]) -> MessageParam:
    return MessageParam(role=role, content=blocks)  # type: ignore[arg-type]


class TestStripCacheControl:
    def test_removes_cache_control_from_blocks(self):
        messages = [_msg("user", [_text_block("hello", cached=True)])]
        _strip_cache_control(messages)
        assert "cache_control" not in messages[0]["content"][0]  # type: ignore[index]

    def test_leaves_other_fields_intact(self):
        messages = [_msg("user", [_text_block("hello", cached=True)])]
        _strip_cache_control(messages)
        assert messages[0]["content"][0]["text"] == "hello"  # type: ignore[index]

    def test_noop_when_no_cache_control(self):
        messages = [_msg("user", [_text_block("hello")])]
        _strip_cache_control(messages)
        assert messages[0]["content"][0]["text"] == "hello"  # type: ignore[index]

    def test_handles_string_content(self):
        messages: list[MessageParam] = [{"role": "user", "content": "plain string"}]
        _strip_cache_control(messages)
        assert messages[0]["content"] == "plain string"

    def test_handles_empty_messages(self):
        _strip_cache_control([])


class TestSetMessageCacheBreakpoint:
    def test_adds_cache_to_second_to_last_message(self):
        messages = [
            _msg("user", [_text_block("first")]),
            _msg("assistant", [_text_block("second")]),
            _msg("user", [_text_block("third")]),
        ]
        result = set_message_cache_breakpoint(messages)
        assert result[-2]["content"][-1]["cache_control"] == {"type": "ephemeral"}  # type: ignore[index]
        assert "cache_control" not in result[-1]["content"][-1]  # type: ignore[index]

    def test_single_message_caches_that_message(self):
        messages = [_msg("user", [_text_block("only")])]
        result = set_message_cache_breakpoint(messages)
        assert result[0]["content"][-1]["cache_control"] == {"type": "ephemeral"}  # type: ignore[index]

    def test_strips_existing_cache_control_first(self):
        messages = [
            _msg("user", [_text_block("first", cached=True)]),
            _msg("assistant", [_text_block("second")]),
        ]
        result = set_message_cache_breakpoint(messages)
        assert result[0]["content"][0]["cache_control"] == {"type": "ephemeral"}  # type: ignore[index]
        assert "cache_control" not in result[1]["content"][0]  # type: ignore[index]

    def test_does_not_mutate_original(self):
        messages = [_msg("user", [_text_block("hello")])]
        original = deepcopy(messages)
        set_message_cache_breakpoint(messages)
        assert messages == original

    def test_multi_block_message_caches_last_block(self):
        messages = [
            _msg("user", [_text_block("a"), _text_block("b")]),
            _msg("assistant", [_text_block("c")]),
        ]
        result = set_message_cache_breakpoint(messages)
        assert "cache_control" not in result[0]["content"][0]  # type: ignore[index]
        assert result[0]["content"][1]["cache_control"] == {"type": "ephemeral"}  # type: ignore[index]
