from typing import Any, cast

from pydantic import BaseModel, Field

from hypergolic.tools.schemas import Tool, ToolOutput


class DummyInput(BaseModel):
    name: str = Field(description="Name")
    count: int = Field(default=1, description="Count")


async def dummy_handler(input: DummyInput, session: Any) -> ToolOutput:
    return ToolOutput(content=[{"type": "text", "text": "ok"}])


class TestToolToParam:
    def test_basic_structure(self):
        tool = Tool(
            id="test_tool",
            name="Test Tool",
            description="A test tool",
            strict=True,
            input=DummyInput,
            call_tool=dummy_handler,
        )
        param = cast(dict[str, Any], tool.to_param())
        assert param["name"] == "test_tool"
        assert param["description"] == "A test tool"
        assert "input_schema" in param

    def test_additional_properties_false(self):
        tool = Tool(
            id="t", name="T", description="d", strict=True,
            input=DummyInput, call_tool=dummy_handler,
        )
        param = cast(dict[str, Any], tool.to_param())
        assert param["input_schema"]["additionalProperties"] is False

    def test_schema_has_properties(self):
        tool = Tool(
            id="t", name="T", description="d", strict=True,
            input=DummyInput, call_tool=dummy_handler,
        )
        param = cast(dict[str, Any], tool.to_param())
        schema = param["input_schema"]
        assert "name" in schema["properties"]
        assert "count" in schema["properties"]


class TestToolShouldTruncate:
    def test_defaults_to_false(self):
        tool = Tool(
            id="t", name="T", description="d", strict=True,
            input=DummyInput, call_tool=dummy_handler,
        )
        assert tool.should_truncate is False

    def test_can_set_true(self):
        tool = Tool(
            id="t", name="T", description="d", strict=True,
            input=DummyInput, call_tool=dummy_handler,
            should_truncate=True,
        )
        assert tool.should_truncate is True


class TestToolOutput:
    def test_defaults(self):
        output = ToolOutput()
        assert output.content == []
        assert output.is_error is False

    def test_with_content(self):
        output = ToolOutput(
            content=[{"type": "text", "text": "hello"}],
            is_error=True,
        )
        assert len(output.content) == 1
        assert output.is_error is True
