import asyncio
from unittest.mock import AsyncMock

from anthropic.types import (
    RawContentBlockDeltaEvent,
    RawContentBlockStartEvent,
    TextBlock,
    TextDelta,
    InputJSONDelta,
    ToolUseBlock,
)
from anthropic.lib.streaming._types import ParsedContentBlockStopEvent

from hypergolic.messages.streaming import handle_streaming_event


SESSION_ID = "test-session-123"


def _make_block_stop(index: int) -> ParsedContentBlockStopEvent:
    return ParsedContentBlockStopEvent.model_construct(
        type="content_block_stop",
        index=index,
        content_block=TextBlock(type="text", text=""),
    )


class TestHandleStreamingEvent:
    def test_text_block_start(self):
        broadcast = AsyncMock()
        event = RawContentBlockStartEvent(
            type="content_block_start",
            index=0,
            content_block=TextBlock(type="text", text=""),
        )
        asyncio.run(handle_streaming_event(event, broadcast, SESSION_ID))
        broadcast.assert_called_once()
        call_arg = broadcast.call_args[0][0]
        assert call_arg.type == "content_block_start"
        assert call_arg.content[0]["type"] == "text"
        assert call_arg.content[0]["index"] == 0
        assert call_arg.session_id == SESSION_ID

    def test_tool_use_block_start(self):
        broadcast = AsyncMock()
        event = RawContentBlockStartEvent(
            type="content_block_start",
            index=1,
            content_block=ToolUseBlock(type="tool_use", id="tool_1", name="read_files", input={}),
        )
        asyncio.run(handle_streaming_event(event, broadcast, SESSION_ID))
        call_arg = broadcast.call_args[0][0]
        assert call_arg.content[0]["type"] == "tool_use"
        assert call_arg.content[0]["id"] == "tool_1"
        assert call_arg.content[0]["name"] == "read_files"

    def test_text_delta(self):
        broadcast = AsyncMock()
        event = RawContentBlockDeltaEvent(
            type="content_block_delta",
            index=0,
            delta=TextDelta(type="text_delta", text="hello"),
        )
        asyncio.run(handle_streaming_event(event, broadcast, SESSION_ID))
        call_arg = broadcast.call_args[0][0]
        assert call_arg.type == "content_block_delta"
        assert call_arg.content[0]["text"] == "hello"

    def test_input_json_delta(self):
        broadcast = AsyncMock()
        event = RawContentBlockDeltaEvent(
            type="content_block_delta",
            index=1,
            delta=InputJSONDelta(type="input_json_delta", partial_json='{"key":'),
        )
        asyncio.run(handle_streaming_event(event, broadcast, SESSION_ID))
        call_arg = broadcast.call_args[0][0]
        assert call_arg.content[0]["partial_json"] == '{"key":'

    def test_block_stop(self):
        broadcast = AsyncMock()
        event = _make_block_stop(2)
        asyncio.run(handle_streaming_event(event, broadcast, SESSION_ID))
        call_arg = broadcast.call_args[0][0]
        assert call_arg.type == "content_block_stop"
        assert call_arg.content[0]["index"] == 2

    def test_all_events_set_role_to_assistant(self):
        broadcast = AsyncMock()
        events = [
            RawContentBlockStartEvent(
                type="content_block_start",
                index=0,
                content_block=TextBlock(type="text", text=""),
            ),
            RawContentBlockDeltaEvent(
                type="content_block_delta",
                index=0,
                delta=TextDelta(type="text_delta", text="x"),
            ),
            _make_block_stop(0),
        ]
        for event in events:
            asyncio.run(handle_streaming_event(event, broadcast, SESSION_ID))

        for call in broadcast.call_args_list:
            assert call[0][0].role == "assistant"
