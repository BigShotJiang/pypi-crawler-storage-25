import asyncio

import pytest
from pathlib import Path

from tests.helpers import text_of, make_ctx

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.write_file import WriteFileEntry, WriteFilesInput, write_files


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


class TestWriteFiles:
    def test_create_new_file(self, tmp_path: Path, session: Session):
        result = asyncio.run(write_files(
            WriteFilesInput(files=[WriteFileEntry(path=str(tmp_path / "new.txt"), content="hello")]),
            make_ctx(session),
        ))
        assert "Created" in text_of(result.content[0])
        assert (tmp_path / "new.txt").read_text() == "hello"
        assert result.is_error is False

    def test_update_existing_file(self, tmp_path: Path, session: Session):
        f = tmp_path / "existing.txt"
        f.write_text("old")
        result = asyncio.run(write_files(
            WriteFilesInput(files=[WriteFileEntry(path=str(f), content="new")]),
            make_ctx(session),
        ))
        assert "Updated" in text_of(result.content[0])
        assert f.read_text() == "new"

    def test_creates_parent_directories(self, tmp_path: Path, session: Session):
        deep = tmp_path / "a" / "b" / "c" / "file.txt"
        result = asyncio.run(write_files(
            WriteFilesInput(files=[WriteFileEntry(path=str(deep), content="deep")]),
            make_ctx(session),
        ))
        assert "Created" in text_of(result.content[0])
        assert deep.read_text() == "deep"

    def test_multiple_files(self, tmp_path: Path, session: Session):
        result = asyncio.run(write_files(
            WriteFilesInput(files=[
                WriteFileEntry(path=str(tmp_path / "a.txt"), content="aaa"),
                WriteFileEntry(path=str(tmp_path / "b.txt"), content="bbb"),
            ]),
            make_ctx(session),
        ))
        assert len(result.content) == 2
        assert (tmp_path / "a.txt").read_text() == "aaa"
        assert (tmp_path / "b.txt").read_text() == "bbb"

    def test_empty_files_list(self, session: Session):
        result = asyncio.run(write_files(WriteFilesInput(files=[]), make_ctx(session)))
        assert "No files provided" in text_of(result.content[0])

    def test_relative_path(self, tmp_path: Path, session: Session):
        result = asyncio.run(write_files(
            WriteFilesInput(files=[WriteFileEntry(path="rel.txt", content="data")]),
            make_ctx(session),
        ))
        assert "Created" in text_of(result.content[0])
        assert (tmp_path / "rel.txt").read_text() == "data"
