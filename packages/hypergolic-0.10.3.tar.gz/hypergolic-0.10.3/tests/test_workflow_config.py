import pytest
from pydantic import ValidationError

from hypergolic.config.schemas import (
    ProjectConfig,
    UserConfig,
    UserProjectConfig,
    WorkflowConfig,
    WorkflowOutputSchema,
    WorkflowStateConfig,
)


class TestWorkflowOutputSchema:
    def test_minimal(self):
        s = WorkflowOutputSchema(
            outcome="success",
            schema={"type": "object", "properties": {}},
        )
        assert s.outcome == "success"
        assert s.artifact_id is None
        assert s.requires_approval is False
        assert s.display is None
        assert s.next_state is None

    def test_full(self):
        s = WorkflowOutputSchema(
            outcome="failure",
            artifact_id="review_feedback",
            requires_approval=True,
            display={"summary": "markdown"},
            schema={"type": "object", "properties": {"summary": {"type": "string"}}},
            next_state="implementation",
        )
        assert s.outcome == "failure"
        assert s.artifact_id == "review_feedback"
        assert s.requires_approval is True
        assert s.display == {"summary": "markdown"}
        assert s.next_state == "implementation"

    def test_invalid_outcome_rejected(self):
        with pytest.raises(ValidationError):
            WorkflowOutputSchema(
                outcome="invalid",  # type: ignore[arg-type]
                schema={"type": "object"},
            )

    def test_schema_alias(self):
        data = {"outcome": "success", "schema": {"type": "object"}, "next_state": "planning"}
        s = WorkflowOutputSchema.model_validate(data)
        assert s.schema_def == {"type": "object"}

    def test_schema_by_field_name(self):
        data = {"outcome": "success", "schema_def": {"type": "object"}}
        s = WorkflowOutputSchema.model_validate(data)
        assert s.schema_def == {"type": "object"}

    def test_display_valid(self):
        s = WorkflowOutputSchema(
            outcome="success",
            display={"doc": "markdown", "items": "list", "status": "badge", "note": "text"},
            schema={"type": "object", "properties": {
                "doc": {"type": "string"},
                "items": {"type": "array"},
                "status": {"type": "string"},
                "note": {"type": "string"},
            }},
        )
        assert s.display == {"doc": "markdown", "items": "list", "status": "badge", "note": "text"}

    def test_display_invalid_field_rejected(self):
        with pytest.raises(ValidationError, match="display key 'nonexistent'"):
            WorkflowOutputSchema(
                outcome="success",
                display={"nonexistent": "markdown"},
                schema={"type": "object", "properties": {"doc": {"type": "string"}}},
            )

    def test_display_invalid_type_rejected(self):
        with pytest.raises(ValidationError, match="display type 'chart'"):
            WorkflowOutputSchema(
                outcome="success",
                display={"doc": "chart"},
                schema={"type": "object", "properties": {"doc": {"type": "string"}}},
            )


class TestWorkflowStateConfig:
    def test_minimal(self):
        s = WorkflowStateConfig(id="impl", name="Implementation")
        assert s.prompt_path is None
        assert s.skills == []
        assert s.tools == []
        assert s.truncate_on_entry is False
        assert s.include_artifacts == []
        assert s.output_schemas == []

    def test_full(self):
        s = WorkflowStateConfig(
            id="planning",
            name="Planning",
            prompt_path="/prompts/planning.md",
            skills=["product-management"],
            truncate_on_entry=True,
            include_artifacts=["prd"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="plan",
                    schema={"type": "object"},
                    next_state="implementation",
                ),
            ],
        )
        assert s.skills == ["product-management"]
        assert s.truncate_on_entry is True
        assert len(s.output_schemas) == 1


class TestWorkflowConfig:
    def test_minimal(self):
        w = WorkflowConfig(
            id="test",
            name="Test",
            description="A test workflow",
            initial_state="start",
        )
        assert w.prompt_path is None
        assert w.states == []

    def test_full(self):
        w = WorkflowConfig(
            id="feature-dev",
            name="Feature Development",
            description="End-to-end feature dev",
            prompt_path="/prompts/feature.md",
            initial_state="requirements",
            states=[
                WorkflowStateConfig(id="requirements", name="Requirements"),
                WorkflowStateConfig(id="implementation", name="Implementation"),
            ],
        )
        assert len(w.states) == 2
        assert w.initial_state == "requirements"



class TestWorkflowsOnConfigModels:
    def test_user_config_has_workflows(self):
        c = UserConfig()
        assert c.workflows == []

    def test_project_config_has_workflows(self):
        c = ProjectConfig()
        assert c.workflows == []

    def test_user_project_config_has_workflows(self):
        c = UserProjectConfig(git_root="/tmp/p", name="P")
        assert c.workflows == []

    def test_user_config_with_workflow(self):
        c = UserConfig(
            workflows=[
                WorkflowConfig(
                    id="test",
                    name="Test",
                    description="d",
                    initial_state="start",
                )
            ]
        )
        assert len(c.workflows) == 1
        assert c.workflows[0].id == "test"
