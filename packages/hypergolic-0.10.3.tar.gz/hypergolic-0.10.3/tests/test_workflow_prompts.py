from unittest.mock import patch

from hypergolic.config.schemas import (
    WorkflowConfig,
    WorkflowOutputSchema,
    WorkflowStateConfig,
)
from hypergolic.enums import ModelTier
from hypergolic.prompts.builder import _build_workflow_prompt_blocks
from hypergolic.schemas import Session


def _make_session() -> Session:
    return Session(
        id="test-session",
        model_tier=ModelTier.HIGH,
        project_id="test-project",
        project_path="/tmp/test",
        role="default",
    )


def _make_workflow(**overrides) -> WorkflowConfig:
    return WorkflowConfig(
        id=overrides.get("id", "test-wf"),
        name=overrides.get("name", "Test Workflow"),
        description=overrides.get("description", "A test workflow"),
        initial_state="start",
        prompt_path=overrides.get("prompt_path"),
        states=overrides.get("states", [
            WorkflowStateConfig(
                id="start",
                name="Start",
                prompt_path=overrides.get("state_prompt_path"),
                include_artifacts=overrides.get("include_artifacts", []),
                output_schemas=[
                    WorkflowOutputSchema(
                        outcome="success",
                        schema={"type": "object"},
                        next_state=None,
                    ),
                ],
            ),
        ]),
    )


class TestBuildWorkflowPromptBlocks:
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_no_active_workflow(self, mock_get_session_wf):
        mock_get_session_wf.return_value = None
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        assert blocks == []

    @patch("hypergolic.prompts.builder.get_workflow_config")
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_workflow_config_not_found(self, mock_get_session_wf, mock_get_wf):
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = None
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        assert blocks == []

    @patch("hypergolic.prompts.builder.get_workflow_config")
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_workflow_prompt_path(self, mock_get_session_wf, mock_get_wf, tmp_path):
        prompt_file = tmp_path / "wf_prompt.md"
        prompt_file.write_text("# Workflow Prompt\nDo the thing.")

        wf = _make_workflow(prompt_path=str(prompt_file))
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = wf
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        assert any("Workflow Prompt" in b.text for b in blocks)
        assert any(b.source == "Workflow: Test Workflow" for b in blocks)

    @patch("hypergolic.prompts.builder.get_workflow_config")
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_state_prompt_path(self, mock_get_session_wf, mock_get_wf, tmp_path):
        prompt_file = tmp_path / "state_prompt.md"
        prompt_file.write_text("# State Instructions")

        wf = _make_workflow(state_prompt_path=str(prompt_file))
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = wf
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        assert any("State Instructions" in b.text for b in blocks)
        assert any(b.source == "Workflow State: Start" for b in blocks)

    @patch("hypergolic.prompts.builder.load_artifacts")
    @patch("hypergolic.prompts.builder.get_workflow_config")
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_include_artifacts(self, mock_get_session_wf, mock_get_wf, mock_load_artifacts):
        wf = _make_workflow(include_artifacts=["my_artifact"])
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = wf
        mock_load_artifacts.return_value = [
            ("my_artifact", {"key": "value"}, "2025-01-01T00:00:00"),
        ]
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        assert any(b.source == "Artifact: my_artifact (2025-01-01T00:00:00)" for b in blocks)
        assert any("value" in b.text for b in blocks)

    @patch("hypergolic.prompts.builder.load_artifacts")
    @patch("hypergolic.prompts.builder.get_workflow_config")
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_no_artifacts_when_empty_list(self, mock_get_session_wf, mock_get_wf, mock_load_artifacts):
        wf = _make_workflow()
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = wf
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        artifact_blocks = [b for b in blocks if b.source.startswith("Artifact:")]
        assert artifact_blocks == []
        mock_load_artifacts.assert_not_called()

    @patch("hypergolic.prompts.builder.get_workflow_config")
    @patch("hypergolic.prompts.builder.get_session_workflow")
    def test_state_not_found_returns_empty(self, mock_get_session_wf, mock_get_wf):
        wf = _make_workflow()
        mock_get_session_wf.return_value = ("test-wf", "nonexistent")
        mock_get_wf.return_value = wf
        session = _make_session()
        blocks = _build_workflow_prompt_blocks(session)
        assert blocks == []
