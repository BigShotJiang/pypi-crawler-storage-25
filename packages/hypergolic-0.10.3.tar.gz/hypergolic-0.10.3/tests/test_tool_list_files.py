import asyncio
from pathlib import Path
from unittest.mock import patch

import pytest

from tests.helpers import text_of, make_ctx
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.list_files import ListFilesInput, list_files


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


@pytest.fixture
def populated_dir(tmp_path: Path) -> Path:
    (tmp_path / "a.py").write_text("a")
    (tmp_path / "b.txt").write_text("b")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "c.py").write_text("c")
    (sub / "deep").mkdir()
    (sub / "deep" / "d.py").write_text("d")
    (tmp_path / ".hidden").write_text("h")
    return tmp_path


def _run(coro):
    return asyncio.run(coro)


class TestListFilesPythonFallback:
    """All tests force Python fallback by mocking has_ripgrep -> False."""

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_lists_all_files(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(ListFilesInput(directory=str(populated_dir)), make_ctx(session)))
        output = text_of(result.content[0])
        assert "a.py" in output
        assert "b.txt" in output
        assert "c.py" in output
        assert "d.py" in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_excludes_hidden_by_default(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(ListFilesInput(directory=str(populated_dir)), make_ctx(session)))
        output = text_of(result.content[0])
        assert ".hidden" not in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_includes_hidden(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(
            ListFilesInput(directory=str(populated_dir), include_hidden=True), make_ctx(session)
        ))
        output = text_of(result.content[0])
        assert ".hidden" in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_max_depth(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(
            ListFilesInput(directory=str(populated_dir), max_depth=1), make_ctx(session)
        ))
        output = text_of(result.content[0])
        assert "a.py" in output
        assert "b.txt" in output
        # depth 1 = direct children only
        assert "c.py" not in output
        assert "d.py" not in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_max_depth_2(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(
            ListFilesInput(directory=str(populated_dir), max_depth=2), make_ctx(session)
        ))
        output = text_of(result.content[0])
        assert "a.py" in output
        assert "c.py" in output
        assert "d.py" not in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_glob_pattern(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(
            ListFilesInput(directory=str(populated_dir), pattern="*.py"), make_ctx(session)
        ))
        output = text_of(result.content[0])
        assert "a.py" in output
        assert "c.py" in output
        assert "b.txt" not in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_empty_directory(self, _mock, tmp_path: Path, session: Session):
        empty = tmp_path / "empty"
        empty.mkdir()
        result = _run(list_files(ListFilesInput(directory=str(empty)), make_ctx(session)))
        output = text_of(result.content[0])
        assert "No files found" in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_nonexistent_directory(self, _mock, tmp_path: Path, session: Session):
        result = _run(list_files(
            ListFilesInput(directory=str(tmp_path / "nope")), make_ctx(session)
        ))
        assert result.is_error is True

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_relative_path(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(ListFilesInput(directory="."), make_ctx(session)))
        output = text_of(result.content[0])
        assert "a.py" in output

    @patch("hypergolic.tools.list_files.has_ripgrep", return_value=False)
    def test_results_are_sorted(self, _mock, populated_dir: Path, session: Session):
        result = _run(list_files(ListFilesInput(directory=str(populated_dir)), make_ctx(session)))
        output = text_of(result.content[0])
        lines = output.strip().split("\n")
        assert lines == sorted(lines)
