import asyncio
from unittest.mock import AsyncMock, patch, MagicMock

from hypergolic.enums import ModelTier
from hypergolic.messages.truncation import truncate_conversation, _build_workflow_summary
from hypergolic.schemas import Session


def _make_session() -> Session:
    return Session(
        id="test-session",
        model_tier=ModelTier.HIGH,
        project_id="test-project",
        project_path="/tmp/test",
        role="default",
    )


def _make_mock_response(text: str) -> MagicMock:
    block = MagicMock()
    block.type = "text"
    block.text = text
    response = MagicMock()
    response.content = [block]
    response.model = "test-model"
    response.role = "assistant"
    response.id = "msg-123"
    response.stop_reason = "end_turn"
    response.stop_sequence = None
    usage = MagicMock()
    usage.model_dump.return_value = {"input_tokens": 100, "output_tokens": 50}
    response.usage = usage
    return response


class TestBuildWorkflowSummary:
    @patch("hypergolic.messages.truncation.load_artifacts")
    @patch("hypergolic.messages.truncation.get_workflow_config")
    @patch("hypergolic.messages.truncation.get_session_workflow")
    def test_returns_none_when_no_workflow(self, mock_get_session_wf, mock_get_wf, mock_load_artifacts):
        mock_get_session_wf.return_value = None
        session = _make_session()
        assert _build_workflow_summary(session) is None

    @patch("hypergolic.messages.truncation.load_artifacts")
    @patch("hypergolic.messages.truncation.get_workflow_config")
    @patch("hypergolic.messages.truncation.get_session_workflow")
    def test_includes_state_name(self, mock_get_session_wf, mock_get_wf, mock_load_artifacts):
        from hypergolic.config.schemas import WorkflowConfig, WorkflowOutputSchema, WorkflowStateConfig

        mock_get_session_wf.return_value = ("test-wf", "implementation")
        mock_get_wf.return_value = WorkflowConfig(
            id="test-wf",
            name="Test",
            description="Test",
            initial_state="planning",
            states=[
                WorkflowStateConfig(
                    id="implementation",
                    name="Implementation",
                    output_schemas=[WorkflowOutputSchema(outcome="success", schema={"type": "object"}, next_state=None)],
                ),
            ],
        )
        mock_load_artifacts.return_value = []

        result = _build_workflow_summary(_make_session())
        assert result is not None
        assert "Implementation" in result

    @patch("hypergolic.messages.truncation.load_artifacts")
    @patch("hypergolic.messages.truncation.get_workflow_config")
    @patch("hypergolic.messages.truncation.get_session_workflow")
    def test_includes_artifacts(self, mock_get_session_wf, mock_get_wf, mock_load_artifacts):
        from hypergolic.config.schemas import WorkflowConfig, WorkflowOutputSchema, WorkflowStateConfig

        mock_get_session_wf.return_value = ("test-wf", "implementation")
        mock_get_wf.return_value = WorkflowConfig(
            id="test-wf",
            name="Test",
            description="Test",
            initial_state="planning",
            states=[
                WorkflowStateConfig(
                    id="implementation",
                    name="Implementation",
                    include_artifacts=["requirements_doc", "plan_doc"],
                    output_schemas=[WorkflowOutputSchema(outcome="success", schema={"type": "object"}, next_state=None)],
                ),
            ],
        )
        mock_load_artifacts.return_value = [
            ("requirements_doc", {"goal": "build thing"}, "2025-01-01"),
            ("plan_doc", {"steps": ["step1"]}, "2025-01-01"),
        ]

        result = _build_workflow_summary(_make_session())
        assert result is not None
        assert "requirements_doc (2025-01-01)" in result
        assert "plan_doc (2025-01-01)" in result
        assert "build thing" in result


class TestTruncateConversation:
    @patch("hypergolic.messages.truncation.get_db")
    @patch("hypergolic.messages.truncation.persist_user_message", new_callable=AsyncMock)
    @patch("hypergolic.messages.truncation._build_workflow_summary")
    @patch("hypergolic.messages.truncation.load_session_messages")
    @patch("hypergolic.messages.truncation.set_session_status_and_broadcast", new_callable=AsyncMock)
    def test_workflow_summary_persists_single_user_message(
        self, mock_status, mock_load_msgs, mock_build_wf,
        mock_persist_user, mock_get_db
    ):
        mock_load_msgs.return_value = []
        mock_build_wf.return_value = "[Workflow transition \u2014 now in state: Implementation]"
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(truncate_conversation(session, broadcast))

        assert mock_persist_user.call_count == 1
        msg = mock_persist_user.call_args_list[0][1]["message"]
        assert msg["role"] == "user"
        assert "Implementation" in msg["content"][0]["text"]

    @patch("hypergolic.messages.truncation.get_db")
    @patch("hypergolic.messages.truncation.persist_user_message", new_callable=AsyncMock)
    @patch("hypergolic.messages.truncation.persist_agent_message", new_callable=AsyncMock)
    @patch("hypergolic.messages.truncation._build_workflow_summary")
    @patch("hypergolic.messages.truncation._call_summarization_model", new_callable=AsyncMock)
    @patch("hypergolic.messages.truncation.load_session_messages")
    @patch("hypergolic.messages.truncation.set_session_status_and_broadcast", new_callable=AsyncMock)
    def test_summarization_persists_agent_message_for_cost_tracking(
        self, mock_status, mock_load_msgs, mock_summarize, mock_build_wf,
        mock_persist_agent, mock_persist_user, mock_get_db
    ):
        mock_load_msgs.return_value = [{"role": "user", "content": "hello"}]
        mock_build_wf.return_value = None
        mock_response = _make_mock_response("Summary of conversation")
        mock_summarize.return_value = mock_response
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(truncate_conversation(session, broadcast))

        mock_persist_agent.assert_called_once_with(
            session_id=session.id, message=mock_response
        )
        assert mock_persist_user.call_count == 1
        msg = mock_persist_user.call_args_list[0][1]["message"]
        assert msg["role"] == "user"
        assert "Summary of conversation" in msg["content"][0]["text"]

    @patch("hypergolic.messages.truncation.get_db")
    @patch("hypergolic.messages.truncation.persist_user_message", new_callable=AsyncMock)
    @patch("hypergolic.messages.truncation._build_workflow_summary")
    @patch("hypergolic.messages.truncation.load_session_messages")
    @patch("hypergolic.messages.truncation.set_session_status_and_broadcast", new_callable=AsyncMock)
    def test_broadcasts_truncated_event(
        self, mock_status, mock_load_msgs, mock_build_wf,
        mock_persist_user, mock_get_db
    ):
        mock_load_msgs.return_value = []
        mock_build_wf.return_value = "[Workflow transition]"
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(truncate_conversation(session, broadcast))

        truncated_events = [c for c in broadcast.call_args_list if c[0][0].type == "truncated"]
        assert len(truncated_events) == 1

    @patch("hypergolic.messages.truncation.get_db")
    @patch("hypergolic.messages.truncation.persist_user_message", new_callable=AsyncMock)
    @patch("hypergolic.messages.truncation._build_workflow_summary")
    @patch("hypergolic.messages.truncation.load_session_messages")
    @patch("hypergolic.messages.truncation.set_session_status_and_broadcast", new_callable=AsyncMock)
    def test_truncates_all_existing_messages(
        self, mock_status, mock_load_msgs, mock_build_wf,
        mock_persist_user, mock_get_db
    ):
        mock_load_msgs.return_value = []
        mock_build_wf.return_value = "[Workflow transition]"
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(truncate_conversation(session, broadcast))

        update_call = mock_db.execute.call_args_list[0]
        stmt = update_call[0][0]
        assert "truncated" in str(stmt)
