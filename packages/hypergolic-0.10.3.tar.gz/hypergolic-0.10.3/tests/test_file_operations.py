from pathlib import Path

from hypergolic.files.operations import _build_tree, _dir_aggregate_status


class TestDirAggregateStatus:
    def test_no_files_in_dir(self):
        assert _dir_aggregate_status("src", {}) is None

    def test_no_matching_prefix(self):
        assert _dir_aggregate_status("src", {"lib/foo.py": "M"}) is None

    def test_modified_takes_precedence(self):
        status_map = {"src/a.py": "A", "src/b.py": "M"}
        assert _dir_aggregate_status("src", status_map) == "M"

    def test_mm_counts_as_modified(self):
        assert _dir_aggregate_status("src", {"src/x.py": "MM"}) == "M"

    def test_am_counts_as_modified(self):
        assert _dir_aggregate_status("src", {"src/x.py": "AM"}) == "M"

    def test_added_only(self):
        assert _dir_aggregate_status("src", {"src/new.py": "A"}) == "A"

    def test_untracked_only(self):
        assert _dir_aggregate_status("src", {"src/new.py": "??"}) == "??"

    def test_added_before_untracked(self):
        status_map = {"src/a.py": "??", "src/b.py": "A"}
        assert _dir_aggregate_status("src", status_map) == "A"

    def test_nested_files_included(self):
        status_map = {"src/sub/deep.py": "M"}
        assert _dir_aggregate_status("src", status_map) == "M"

    def test_dir_name_prefix_not_confused(self):
        status_map = {"src-old/a.py": "M"}
        assert _dir_aggregate_status("src", status_map) is None

    def test_fallback_to_first_status(self):
        status_map = {"src/a.py": "D"}
        assert _dir_aggregate_status("src", status_map) == "D"


class TestBuildTree:
    def test_empty_directory(self, tmp_path: Path):
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert nodes == []

    def test_files_sorted_case_insensitive(self, tmp_path: Path):
        (tmp_path / "Zebra.txt").touch()
        (tmp_path / "apple.txt").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert [n.name for n in nodes] == ["apple.txt", "Zebra.txt"]

    def test_dirs_before_files(self, tmp_path: Path):
        (tmp_path / "file.txt").touch()
        (tmp_path / "adir").mkdir()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert nodes[0].is_dir is True
        assert nodes[1].is_dir is False

    def test_hidden_files_excluded(self, tmp_path: Path):
        (tmp_path / ".hidden").touch()
        (tmp_path / "visible.txt").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert len(nodes) == 1
        assert nodes[0].name == "visible.txt"

    def test_node_modules_excluded(self, tmp_path: Path):
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "src").mkdir()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert len(nodes) == 1
        assert nodes[0].name == "src"

    def test_pycache_excluded(self, tmp_path: Path):
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / "main.py").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert len(nodes) == 1
        assert nodes[0].name == "main.py"

    def test_git_status_applied_to_files(self, tmp_path: Path):
        (tmp_path / "changed.py").touch()
        (tmp_path / "clean.py").touch()
        status_map = {"changed.py": "M"}
        nodes = _build_tree(tmp_path, tmp_path, status_map, set())
        by_name = {n.name: n for n in nodes}
        assert by_name["changed.py"].git_status == "M"
        assert by_name["clean.py"].git_status is None

    def test_ignored_file_gets_ignored_status(self, tmp_path: Path):
        (tmp_path / "build.log").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, {"build.log"})
        assert nodes[0].git_status == "ignored"

    def test_ignored_dir_gets_ignored_status(self, tmp_path: Path):
        d = tmp_path / "dist"
        d.mkdir()
        (d / "bundle.js").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, {"dist"})
        assert nodes[0].git_status == "ignored"

    def test_nested_directory_recursion(self, tmp_path: Path):
        sub = tmp_path / "src"
        sub.mkdir()
        (sub / "main.py").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert nodes[0].is_dir is True
        assert nodes[0].children is not None
        assert len(nodes[0].children) == 1
        assert nodes[0].children[0].name == "main.py"

    def test_dir_aggregate_status_propagated(self, tmp_path: Path):
        sub = tmp_path / "src"
        sub.mkdir()
        (sub / "a.py").touch()
        status_map = {"src/a.py": "M"}
        nodes = _build_tree(tmp_path, tmp_path, status_map, set())
        assert nodes[0].git_status == "M"

    def test_relative_paths_correct(self, tmp_path: Path):
        sub = tmp_path / "pkg"
        sub.mkdir()
        (sub / "mod.py").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, set())
        assert nodes[0].path == "pkg"
        assert nodes[0].children[0].path == "pkg/mod.py"  # type: ignore[index]

    def test_file_inside_ignored_dir_prefix(self, tmp_path: Path):
        sub = tmp_path / "vendor"
        sub.mkdir()
        (sub / "lib.py").touch()
        nodes = _build_tree(tmp_path, tmp_path, {}, {"vendor"})
        assert nodes[0].git_status == "ignored"
        assert nodes[0].children[0].git_status == "ignored"  # type: ignore[index]
