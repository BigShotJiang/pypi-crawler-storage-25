import hypergolic


def test_package_imports():
    assert hypergolic is not None
