from typing import Any

from anthropic.types import Message, TextBlock, ToolUseBlock, Usage

from hypergolic.messages.persistence import (
    sanitize_tool_input,
    strip_excluded_fields,
    parse_agent_message,
)
from hypergolic.messages.types import EXCLUDED_CONTENT_FIELDS


def _content(result: Any) -> list[Any]:
    return list(result["content"])


class TestStripExcludedFields:
    def test_removes_excluded_fields(self):
        content = [{"type": "text", "text": "hello", "parsed_output": "x"}]
        result = strip_excluded_fields(content)
        assert result == [{"type": "text", "text": "hello"}]

    def test_preserves_allowed_fields(self):
        content = [{"type": "text", "text": "hello"}]
        result = strip_excluded_fields(content)
        assert result == [{"type": "text", "text": "hello"}]

    def test_non_dict_blocks_pass_through(self):
        content: list[Any] = ["plain string", 42]
        result = strip_excluded_fields(content)
        assert result == ["plain string", 42]

    def test_empty_list(self):
        assert strip_excluded_fields([]) == []

    def test_multiple_blocks(self):
        content = [
            {"type": "text", "text": "a", "caller": "fn"},
            {"type": "text", "text": "b"},
        ]
        result = strip_excluded_fields(content)
        assert result == [
            {"type": "text", "text": "a"},
            {"type": "text", "text": "b"},
        ]

    def test_all_excluded_fields_removed(self):
        block: dict[str, Any] = {"type": "text"}
        for field in EXCLUDED_CONTENT_FIELDS:
            block[field] = "value"
        result = strip_excluded_fields([block])
        for field in EXCLUDED_CONTENT_FIELDS:
            assert field not in result[0]


class TestParseAgentMessage:
    def test_text_content(self):
        msg = Message(
            id="msg_1",
            type="message",
            role="assistant",
            model="claude-sonnet-4-20250514",
            content=[TextBlock(type="text", text="Hello world")],
            stop_reason="end_turn",
            stop_sequence=None,
            usage=Usage(input_tokens=10, output_tokens=5),
        )
        result = parse_agent_message(msg)
        assert result["role"] == "assistant"
        blocks = _content(result)
        assert len(blocks) == 1
        assert blocks[0]["type"] == "text"
        assert blocks[0]["text"] == "Hello world"

    def test_tool_use_content(self):
        msg = Message(
            id="msg_2",
            type="message",
            role="assistant",
            model="claude-sonnet-4-20250514",
            content=[
                TextBlock(type="text", text="Let me check"),
                ToolUseBlock(type="tool_use", id="tu_1", name="read_files", input={"paths": ["x.py"]}),
            ],
            stop_reason="tool_use",
            stop_sequence=None,
            usage=Usage(input_tokens=10, output_tokens=5),
        )
        result = parse_agent_message(msg)
        blocks = _content(result)
        assert len(blocks) == 2
        assert blocks[1]["type"] == "tool_use"
        assert blocks[1]["name"] == "read_files"

    def test_excluded_fields_stripped(self):
        msg = Message(
            id="msg_3",
            type="message",
            role="assistant",
            model="claude-sonnet-4-20250514",
            content=[TextBlock(type="text", text="hi")],
            stop_reason="end_turn",
            stop_sequence=None,
            usage=Usage(input_tokens=10, output_tokens=5),
        )
        result = parse_agent_message(msg)
        for block in _content(result):
            if isinstance(block, dict):
                for excluded in ("parsed_output", "caller"):
                    assert excluded not in block


class TestSanitizeToolInput:
    def test_normal_input_unchanged(self):
        inp = {"files": [{"path": "a.py", "content": "x"}], "flag": True}
        assert sanitize_tool_input(inp) == inp

    def test_string_value_parsed_as_json_array(self):
        inp = {"files": '[{"path": "a.py"}]'}
        result = sanitize_tool_input(inp)
        assert result == {"files": [{"path": "a.py"}]}

    def test_string_value_parsed_as_json_object(self):
        inp = {"data": '{"key": "val"}'}
        result = sanitize_tool_input(inp)
        assert result == {"data": {"key": "val"}}

    def test_trailing_xml_tag_stripped(self):
        inp = {"files": '[{"path": "a.py"}]</invoke>'}
        result = sanitize_tool_input(inp)
        assert result == {"files": [{"path": "a.py"}]}

    def test_trailing_garbage_stripped(self):
        inp = {"files": '[{"path": "a.py"}]some random garbage'}
        result = sanitize_tool_input(inp)
        assert result == {"files": [{"path": "a.py"}]}

    def test_trailing_garbage_on_object(self):
        inp = {"data": '{"key": "val"}extra stuff'}
        result = sanitize_tool_input(inp)
        assert result == {"data": {"key": "val"}}

    def test_plain_string_value_left_alone(self):
        inp = {"pattern": "hello world", "directory": "."}
        assert sanitize_tool_input(inp) == inp

    def test_non_json_string_left_alone(self):
        inp = {"command": "ls -la"}
        assert sanitize_tool_input(inp) == inp

    def test_empty_input(self):
        assert sanitize_tool_input({}) == {}

    def test_nested_string_not_recursed(self):
        inp = {"files": [{"content": '{"not": "parsed"}'}]}
        assert sanitize_tool_input(inp) == inp

    def test_does_not_mutate_original(self):
        original = {"files": '[{"path": "a.py"}]'}
        sanitize_tool_input(original)
        assert isinstance(original["files"], str)

    def test_completely_invalid_json_left_alone(self):
        inp = {"files": '[{invalid json that cannot be recovered'}
        assert sanitize_tool_input(inp) == inp

    def test_number_and_bool_values_unchanged(self):
        inp = {"count": 5, "flag": True, "name": "test"}
        assert sanitize_tool_input(inp) == inp
