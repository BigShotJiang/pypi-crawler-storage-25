from pathlib import Path

import pytest

from hypergolic.tools.python_search import python_search, PythonSearchParams


@pytest.fixture
def search_dir(tmp_path: Path) -> Path:
    (tmp_path / "hello.py").write_text("def hello():\n    print('Hello World')\n    return True\n")
    (tmp_path / "data.txt").write_text("line one\nline two\nline three\nline four\n")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "nested.py").write_text("import hello\nhello.hello()\n")
    (tmp_path / ".hidden").write_text("secret\n")
    (tmp_path / ".hiddendir").mkdir()
    (tmp_path / ".hiddendir" / "file.txt").write_text("hidden dir file\n")
    return tmp_path


class TestBasicSearch:
    def test_literal_match(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="Hello World", directory=str(search_dir), fixed_string=True,
        ))
        assert result.returncode == 0
        assert "Hello World" in result.stdout
        assert "hello.py" in result.stdout

    def test_regex_match(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern=r"def \w+\(", directory=str(search_dir),
        ))
        assert result.returncode == 0
        assert "hello.py" in result.stdout

    def test_no_matches(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="nonexistent_xyz", directory=str(search_dir),
        ))
        assert result.returncode == 1
        assert result.stdout == ""

    def test_case_insensitive(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hello world", directory=str(search_dir),
            fixed_string=True, case_sensitive=False,
        ))
        assert result.returncode == 0
        assert "Hello World" in result.stdout

    def test_case_sensitive_no_match(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hello world", directory=str(search_dir),
            fixed_string=True, case_sensitive=True,
        ))
        assert result.returncode == 1


class TestLineNumbers:
    def test_line_numbers_present(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="line", directory=str(search_dir), fixed_string=True,
            show_line_numbers=True,
        ))
        assert result.returncode == 0
        lines = result.stdout.strip().split("\n")
        assert any(":1:" in line for line in lines)
        assert any(":2:" in line for line in lines)


class TestContextLines:
    def test_context_lines(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="line two", directory=str(search_dir), fixed_string=True,
            context_lines=1, show_line_numbers=True,
        ))
        assert result.returncode == 0
        assert "line one" in result.stdout
        assert "line two" in result.stdout
        assert "line three" in result.stdout


class TestFiltering:
    def test_file_glob(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hello", directory=str(search_dir),
            fixed_string=True, case_sensitive=False,
            file_glob="*.py",
        ))
        assert result.returncode == 0
        assert "data.txt" not in result.stdout

    def test_hidden_excluded_by_default(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="secret", directory=str(search_dir), fixed_string=True,
        ))
        assert result.returncode == 1

    def test_hidden_included(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="secret", directory=str(search_dir),
            fixed_string=True, include_hidden=True,
        ))
        assert result.returncode == 0
        assert "secret" in result.stdout

    def test_hidden_dir_excluded_by_default(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hidden dir file", directory=str(search_dir), fixed_string=True,
        ))
        assert result.returncode == 1

    def test_hidden_dir_included(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hidden dir file", directory=str(search_dir),
            fixed_string=True, include_hidden=True,
        ))
        assert result.returncode == 0

    def test_max_depth(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hello", directory=str(search_dir),
            fixed_string=True, case_sensitive=False, max_depth=1,
        ))
        assert result.returncode == 0
        assert "nested.py" not in result.stdout

    def test_max_results(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="line", directory=str(search_dir), fixed_string=True,
            max_results=2, show_line_numbers=True,
        ))
        assert result.returncode == 0
        non_context = [ln for ln in result.stdout.strip().split("\n") if ln and not ln.startswith("--")]
        assert len(non_context) <= 2


class TestInvertMatch:
    def test_invert(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="line", directory=str(search_dir),
            fixed_string=True, invert_match=True,
        ))
        assert result.returncode == 0
        assert "line one" not in result.stdout
        assert "hello" in result.stdout.lower() or "def" in result.stdout


class TestFilesOnly:
    def test_files_only(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern="hello", directory=str(search_dir),
            fixed_string=True, case_sensitive=False, files_only=True,
        ))
        assert result.returncode == 0
        lines = [ln for ln in result.stdout.strip().split("\n") if ln]
        for line in lines:
            assert ":" not in line or line.endswith(".py")


class TestMultiline:
    def test_multiline_match(self, search_dir: Path):
        result = python_search(PythonSearchParams(
            pattern=r"def hello.*?return True", directory=str(search_dir),
            multiline=True,
        ))
        assert result.returncode == 0
        assert "hello.py" in result.stdout
