from datetime import datetime, timezone, timedelta

from hypergolic.db.utils import to_iso_utc


class TestToIsoUtc:
    def test_naive_datetime_gets_utc_tag(self):
        dt = datetime(2024, 6, 15, 12, 30, 0)
        result = to_iso_utc(dt)
        assert result == "2024-06-15T12:30:00+00:00"

    def test_aware_utc_datetime_preserved(self):
        dt = datetime(2024, 6, 15, 12, 30, 0, tzinfo=timezone.utc)
        result = to_iso_utc(dt)
        assert result == "2024-06-15T12:30:00+00:00"

    def test_aware_non_utc_preserved(self):
        eastern = timezone(timedelta(hours=-5))
        dt = datetime(2024, 6, 15, 12, 30, 0, tzinfo=eastern)
        result = to_iso_utc(dt)
        assert result == "2024-06-15T12:30:00-05:00"

    def test_microseconds_included(self):
        dt = datetime(2024, 1, 1, 0, 0, 0, 123456)
        result = to_iso_utc(dt)
        assert "123456" in result
        assert result.endswith("+00:00")
