import asyncio

import pytest
from pathlib import Path

from tests.helpers import text_of, make_ctx

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.edit_file import EditFileEntry, EditFilesInput, edit_files, _edit_single_file


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


class TestEditSingleFile:
    def test_successful_edit(self, tmp_path: Path, session: Session):
        f = tmp_path / "test.py"
        f.write_text("hello world")
        entry = EditFileEntry(path=str(f), old_string="hello", new_string="goodbye")
        result = _edit_single_file(entry, session)
        assert "Edited" in text_of(result)
        assert f.read_text() == "goodbye world"

    def test_file_not_found(self, tmp_path: Path, session: Session):
        entry = EditFileEntry(path=str(tmp_path / "nope.py"), old_string="x", new_string="y")
        result = _edit_single_file(entry, session)
        assert "does not exist" in text_of(result)

    def test_not_a_file(self, tmp_path: Path, session: Session):
        d = tmp_path / "adir"
        d.mkdir()
        entry = EditFileEntry(path=str(d), old_string="x", new_string="y")
        result = _edit_single_file(entry, session)
        assert "not a file" in text_of(result)

    def test_old_string_not_found(self, tmp_path: Path, session: Session):
        f = tmp_path / "test.py"
        f.write_text("hello world")
        entry = EditFileEntry(path=str(f), old_string="missing", new_string="y")
        result = _edit_single_file(entry, session)
        assert "not found" in text_of(result)

    def test_old_string_appears_multiple_times(self, tmp_path: Path, session: Session):
        f = tmp_path / "test.py"
        f.write_text("aaa")
        entry = EditFileEntry(path=str(f), old_string="a", new_string="b")
        result = _edit_single_file(entry, session)
        assert "3 times" in text_of(result)

    def test_delete_via_empty_new_string(self, tmp_path: Path, session: Session):
        f = tmp_path / "test.py"
        f.write_text("line1\nline2\nline3")
        entry = EditFileEntry(path=str(f), old_string="\nline2", new_string="")
        result = _edit_single_file(entry, session)
        assert "Edited" in text_of(result)
        assert f.read_text() == "line1\nline3"

    def test_relative_path_resolved(self, tmp_path: Path, session: Session):
        f = tmp_path / "rel.txt"
        f.write_text("old")
        entry = EditFileEntry(path="rel.txt", old_string="old", new_string="new")
        result = _edit_single_file(entry, session)
        assert "Edited" in text_of(result)
        assert f.read_text() == "new"


class TestEditFiles:
    def test_empty_files_list(self, session: Session):
        result = asyncio.run(edit_files(EditFilesInput(files=[]), make_ctx(session)))
        assert text_of(result.content[0]) == "No edits provided."

    def test_has_error_flag_set(self, tmp_path: Path, session: Session):
        result = asyncio.run(edit_files(
            EditFilesInput(files=[
                EditFileEntry(path=str(tmp_path / "nope"), old_string="x", new_string="y"),
            ]),
            make_ctx(session),
        ))
        assert result.is_error is True

    def test_mixed_success_and_error(self, tmp_path: Path, session: Session):
        f = tmp_path / "good.txt"
        f.write_text("old text")
        result = asyncio.run(edit_files(
            EditFilesInput(files=[
                EditFileEntry(path=str(f), old_string="old", new_string="new"),
                EditFileEntry(path=str(tmp_path / "bad"), old_string="x", new_string="y"),
            ]),
            make_ctx(session),
        ))
        assert result.is_error is True
        assert "Edited" in text_of(result.content[0])
        assert "Error" in text_of(result.content[1])
