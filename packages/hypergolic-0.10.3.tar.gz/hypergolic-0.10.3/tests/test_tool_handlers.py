import asyncio
from typing import Any
from unittest.mock import MagicMock

from anthropic.types import Message, ToolUseBlock, Usage
from pydantic import BaseModel, Field

from tests.helpers import text_of

from hypergolic.tools.handlers import ToolUseResult, _truncate_tool_output, handle_tool_use
from hypergolic.tools.schemas import Tool, ToolOutput


class TestTruncateToolOutput:
    def test_no_truncation_when_under_limit(self):
        output = ToolOutput(content=[{"type": "text", "text": "short"}])
        result = _truncate_tool_output(output, limit=100)
        assert result.content == [{"type": "text", "text": "short"}]
        assert result.is_error is False

    def test_truncation_when_over_limit(self):
        output = ToolOutput(content=[{"type": "text", "text": "a" * 200}])
        result = _truncate_tool_output(output, limit=50)
        assert len(result.content) == 2
        assert text_of(result.content[0]) == "a" * 50
        assert "truncated" in text_of(result.content[1]).lower()

    def test_truncation_preserves_is_error(self):
        output = ToolOutput(content=[{"type": "text", "text": "a" * 200}], is_error=True)
        result = _truncate_tool_output(output, limit=50)
        assert result.is_error is True

    def test_truncation_multiple_blocks(self):
        output = ToolOutput(content=[
            {"type": "text", "text": "a" * 30},
            {"type": "text", "text": "b" * 30},
        ])
        result = _truncate_tool_output(output, limit=40)
        assert text_of(result.content[0]) == "a" * 30
        assert text_of(result.content[1]) == "b" * 10
        assert "truncated" in text_of(result.content[2]).lower()

    def test_non_text_blocks_preserved(self):
        content: list = [
            {"type": "image", "data": "abc"},
            {"type": "text", "text": "a" * 200},
        ]
        output = ToolOutput(content=content)
        result = _truncate_tool_output(output, limit=50)
        assert result.content[0] == {"type": "image", "data": "abc"}
        assert text_of(result.content[1]) == "a" * 50

    def test_exact_limit_no_truncation(self):
        output = ToolOutput(content=[{"type": "text", "text": "a" * 100}])
        result = _truncate_tool_output(output, limit=100)
        assert len(result.content) == 1
        assert text_of(result.content[0]) == "a" * 100

    def test_empty_content(self):
        output = ToolOutput(content=[])
        result = _truncate_tool_output(output, limit=100)
        assert result.content == []

    def test_truncation_message_includes_char_counts(self):
        output = ToolOutput(content=[{"type": "text", "text": "a" * 1000}])
        result = _truncate_tool_output(output, limit=100)
        msg = text_of(result.content[-1])
        assert "1,000" in msg
        assert "100" in msg


class TestToolUseResultShouldTruncate:
    def test_defaults_to_false(self):
        result = ToolUseResult(message={"role": "user", "content": []})
        assert result.should_truncate is False

    def test_can_set_true(self):
        result = ToolUseResult(message={"role": "user", "content": []}, should_truncate=True)
        assert result.should_truncate is True


class DummyInput(BaseModel):
    value: str = Field(default="test", description="A value")


async def _dummy_handler(input: DummyInput, ctx: Any) -> ToolOutput:
    return ToolOutput(content=[{"type": "text", "text": "ok"}])


def _make_agent_message(tool_names: list[str]) -> Message:
    content: list[Any] = [
        ToolUseBlock(type="tool_use", id=f"tu_{i}", name=name, input={})
        for i, name in enumerate(tool_names)
    ]
    return Message(
        id="msg_1", type="message", role="assistant", model="claude-sonnet-4-20250514",
        content=content, stop_reason="tool_use", stop_sequence=None,
        usage=Usage(input_tokens=10, output_tokens=5),
    )


def _make_session() -> Any:
    session = MagicMock()
    session.id = "test-session"
    session.project_id = "test-project"
    session.project_path = "/tmp/test"
    return session


async def _noop_broadcast(event: Any) -> None:
    pass


class TestHandleToolUseShouldTruncate:
    def test_no_truncation_for_normal_tool(self):
        tool = Tool(
            id="normal", name="Normal", description="d", strict=True,
            input=DummyInput, call_tool=_dummy_handler,
        )
        msg = _make_agent_message(["normal"])
        result = asyncio.run(handle_tool_use(
            agent_message=msg, tools=[tool], session=_make_session(),
            broadcast=_noop_broadcast,
        ))
        assert result.should_truncate is False

    def test_truncation_when_tool_has_should_truncate(self):
        tool = Tool(
            id="truncating", name="Truncating", description="d", strict=True,
            input=DummyInput, call_tool=_dummy_handler,
            should_truncate=True,
        )
        msg = _make_agent_message(["truncating"])
        result = asyncio.run(handle_tool_use(
            agent_message=msg, tools=[tool], session=_make_session(),
            broadcast=_noop_broadcast,
        ))
        assert result.should_truncate is True

    def test_truncation_when_any_tool_has_should_truncate(self):
        normal_tool = Tool(
            id="normal", name="Normal", description="d", strict=True,
            input=DummyInput, call_tool=_dummy_handler,
        )
        truncating_tool = Tool(
            id="truncating", name="Truncating", description="d", strict=True,
            input=DummyInput, call_tool=_dummy_handler,
            should_truncate=True,
        )
        msg = _make_agent_message(["normal", "truncating"])
        result = asyncio.run(handle_tool_use(
            agent_message=msg, tools=[normal_tool, truncating_tool],
            session=_make_session(), broadcast=_noop_broadcast,
        ))
        assert result.should_truncate is True

    def test_no_truncation_when_tool_not_found(self):
        msg = _make_agent_message(["missing"])
        result = asyncio.run(handle_tool_use(
            agent_message=msg, tools=[], session=_make_session(),
            broadcast=_noop_broadcast,
        ))
        assert result.should_truncate is False

    def test_no_truncation_when_tool_errors(self):
        async def _error_handler(input: DummyInput, ctx: Any) -> ToolOutput:
            raise RuntimeError("boom")

        tool = Tool(
            id="erroring", name="Erroring", description="d", strict=True,
            input=DummyInput, call_tool=_error_handler,
            should_truncate=True,
        )
        msg = _make_agent_message(["erroring"])
        result = asyncio.run(handle_tool_use(
            agent_message=msg, tools=[tool], session=_make_session(),
            broadcast=_noop_broadcast,
        ))
        assert result.should_truncate is False
