from pathlib import Path

from hypergolic.tools.approval import (
    READ_ONLY_FILE_TOOLS,
    ApprovalRule,
    ConditionOperator,
    RuleAction,
    RuleCondition,
    _builtin_rules,
    _has_paths_outside_project,
)


class TestRuleConditionMatchesValue:
    def test_equals_match(self):
        c = RuleCondition(field="command", operator=ConditionOperator.EQUALS, value="status")
        assert c._matches_value("status") is True

    def test_equals_no_match(self):
        c = RuleCondition(field="command", operator=ConditionOperator.EQUALS, value="status")
        assert c._matches_value("diff") is False

    def test_starts_with(self):
        c = RuleCondition(field="path", operator=ConditionOperator.STARTS_WITH, value="/home")
        assert c._matches_value("/home/user/file.txt") is True
        assert c._matches_value("/etc/config") is False

    def test_contains(self):
        c = RuleCondition(field="cmd", operator=ConditionOperator.CONTAINS, value="rm")
        assert c._matches_value("rm -rf /") is True
        assert c._matches_value("ls -la") is False

    def test_matches_glob(self):
        c = RuleCondition(field="path", operator=ConditionOperator.MATCHES_GLOB, value="*.py")
        assert c._matches_value("main.py") is True
        assert c._matches_value("main.ts") is False

    def test_matches_regex(self):
        c = RuleCondition(field="cmd", operator=ConditionOperator.MATCHES_REGEX, value=r"^(rm|del)")
        assert c._matches_value("rm file") is True
        assert c._matches_value("ls file") is False

    def test_matches_regex_invalid_pattern(self):
        c = RuleCondition(field="cmd", operator=ConditionOperator.MATCHES_REGEX, value="[invalid")
        assert c._matches_value("anything") is False


class TestRuleConditionMatches:
    def test_missing_field_returns_false(self):
        c = RuleCondition(field="command", operator=ConditionOperator.EQUALS, value="status")
        assert c.matches({}) is False

    def test_field_present_and_matches(self):
        c = RuleCondition(field="command", operator=ConditionOperator.EQUALS, value="status")
        assert c.matches({"command": "status"}) is True

    def test_non_string_value_coerced(self):
        c = RuleCondition(field="timeout", operator=ConditionOperator.EQUALS, value="30")
        assert c.matches({"timeout": 30}) is True

    def test_list_value_any_match(self):
        c = RuleCondition(field="paths", operator=ConditionOperator.CONTAINS, value="secret")
        assert c.matches({"paths": ["/home/secret", "/public"]}) is True

    def test_list_value_no_match(self):
        c = RuleCondition(field="paths", operator=ConditionOperator.CONTAINS, value="secret")
        assert c.matches({"paths": ["/home/user", "/public"]}) is False


class TestApprovalRuleMatches:
    def test_wildcard_matches_any_tool(self):
        rule = ApprovalRule(id=None, tool_name="*", action=RuleAction.ALLOW)
        assert rule.matches("anything", {}) is True

    def test_specific_tool_match(self):
        rule = ApprovalRule(id=None, tool_name="git", action=RuleAction.ALLOW)
        assert rule.matches("git", {}) is True
        assert rule.matches("command", {}) is False

    def test_project_scope(self):
        rule = ApprovalRule(id=None, tool_name="*", action=RuleAction.ALLOW, project_id="p1")
        assert rule.matches("git", {}, project_id="p1") is True
        assert rule.matches("git", {}, project_id="p2") is False

    def test_session_scope(self):
        rule = ApprovalRule(id=None, tool_name="*", action=RuleAction.ALLOW, session_id="s1")
        assert rule.matches("git", {}, session_id="s1") is True
        assert rule.matches("git", {}, session_id="s2") is False

    def test_conditions_all_must_match(self):
        rule = ApprovalRule(
            id=None, tool_name="git", action=RuleAction.ALLOW,
            conditions=[
                RuleCondition(field="command", operator=ConditionOperator.EQUALS, value="push"),
                RuleCondition(field="path", operator=ConditionOperator.EQUALS, value="main"),
            ],
        )
        assert rule.matches("git", {"command": "push", "path": "main"}) is True
        assert rule.matches("git", {"command": "push", "path": "dev"}) is False
        assert rule.matches("git", {"command": "pull", "path": "main"}) is False


class TestBuiltinRules:
    def test_git_read_commands_allowed(self):
        rules = _builtin_rules()
        read_cmds = {"status", "diff", "log", "show", "branch_list", "stash_list"}
        for cmd in read_cmds:
            matching = [
                r for r in rules
                if r.tool_name == "git" and r.matches("git", {"command": cmd})
            ]
            assert matching, f"No rule matched git {cmd}"
            assert matching[0].action == RuleAction.ALLOW

    def test_git_mutating_commands_require_approval(self):
        rules = _builtin_rules()
        rules.sort(key=lambda r: r.priority, reverse=True)
        for cmd in ("push", "merge", "rebase"):
            for r in rules:
                if r.matches("git", {"command": cmd}):
                    assert r.action == RuleAction.REQUIRE_APPROVAL
                    break

    def test_command_requires_approval(self):
        rules = _builtin_rules()
        matching = [r for r in rules if r.tool_name == "command"]
        assert matching[0].action == RuleAction.REQUIRE_APPROVAL

    def test_wildcard_fallback_allows(self):
        rules = _builtin_rules()
        wildcard = [r for r in rules if r.tool_name == "*"]
        assert wildcard
        assert wildcard[0].action == RuleAction.ALLOW
        assert wildcard[0].priority == -1000


class TestHasPathsOutsideProject:
    def test_paths_inside_project(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "read_files", {"paths": [str(project / "src" / "main.py")]}, str(project)
        ) is False

    def test_paths_outside_project(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "read_files", {"paths": ["/etc/passwd"]}, str(project)
        ) is True

    def test_relative_paths_resolve_inside(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "read_files", {"paths": ["src/main.py"]}, str(project)
        ) is False

    def test_relative_path_escaping_via_dotdot(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "read_files", {"paths": ["../../etc/passwd"]}, str(project)
        ) is True

    def test_write_files_extracts_paths(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "write_files",
            {"files": [{"path": str(project / "ok.txt")}, {"path": "/etc/bad"}]},
            str(project),
        ) is True

    def test_edit_files_extracts_paths(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "edit_files",
            {"files": [{"path": str(project / "ok.txt")}]},
            str(project),
        ) is False

    def test_delete_files(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "delete_files", {"paths": ["/tmp/nope"]}, str(project)
        ) is True

    def test_list_files_directory(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "list_files", {"directory": str(project / "src")}, str(project)
        ) is False
        assert _has_paths_outside_project(
            "list_files", {"directory": "/etc"}, str(project)
        ) is True

    def test_search_files_directory(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "search_files", {"directory": str(project)}, str(project)
        ) is False

    def test_make_directory_both_params(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "make_directory",
            {"path": str(project / "new"), "paths": [str(project / "other")]},
            str(project),
        ) is False
        assert _has_paths_outside_project(
            "make_directory",
            {"path": "/tmp/bad", "paths": [str(project / "ok")]},
            str(project),
        ) is True

    def test_unknown_tool_returns_false(self, tmp_path: Path):
        assert _has_paths_outside_project(
            "unknown_tool", {"paths": ["/etc/passwd"]}, str(tmp_path)
        ) is False

    def test_empty_paths(self, tmp_path: Path):
        assert _has_paths_outside_project(
            "read_files", {"paths": []}, str(tmp_path)
        ) is False

    def test_no_paths_key(self, tmp_path: Path):
        assert _has_paths_outside_project(
            "read_files", {}, str(tmp_path)
        ) is False

    def test_allowed_paths_bypass_outside_check(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        allowed = tmp_path / "allowed_dir"
        allowed.mkdir()
        assert _has_paths_outside_project(
            "read_files",
            {"paths": [str(allowed / "config.json")]},
            str(project),
            allowed_paths=[str(allowed)],
        ) is False

    def test_allowed_paths_mixed_with_disallowed(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        allowed = tmp_path / "allowed_dir"
        allowed.mkdir()
        assert _has_paths_outside_project(
            "read_files",
            {"paths": [str(allowed / "ok.json"), "/etc/passwd"]},
            str(project),
            allowed_paths=[str(allowed)],
        ) is True

    def test_allowed_paths_empty_list(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        assert _has_paths_outside_project(
            "read_files",
            {"paths": ["/etc/passwd"]},
            str(project),
            allowed_paths=[],
        ) is True

    def test_allowed_paths_does_not_allow_parent_traversal(self, tmp_path: Path):
        project = tmp_path / "myproject"
        project.mkdir()
        allowed = tmp_path / "allowed_dir" / "subdir"
        allowed.mkdir(parents=True)
        assert _has_paths_outside_project(
            "read_files",
            {"paths": [str(tmp_path / "allowed_dir" / "subdir" / ".." / ".." / "secret")]},
            str(project),
            allowed_paths=[str(allowed)],
        ) is True


class TestReadOnlyToolAllowlist:
    def test_read_only_tools_include_expected(self):
        assert "read_files" in READ_ONLY_FILE_TOOLS
        assert "list_files" in READ_ONLY_FILE_TOOLS
        assert "search_files" in READ_ONLY_FILE_TOOLS

    def test_write_tools_not_in_read_only(self):
        assert "write_files" not in READ_ONLY_FILE_TOOLS
        assert "edit_files" not in READ_ONLY_FILE_TOOLS
        assert "delete_files" not in READ_ONLY_FILE_TOOLS
        assert "make_directory" not in READ_ONLY_FILE_TOOLS
