from pathlib import Path
from unittest.mock import patch

import pytest

from hypergolic.config.schemas import CustomToolConfig
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.tool_list import build_tools, STANDARD_TOOLS, SKILL_TOOLS


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


def tool_ids(tools) -> set[str]:
    return {t.id for t in tools}


def _make_tool(tool_id: str, **kwargs) -> CustomToolConfig:
    return CustomToolConfig(id=tool_id, name=tool_id, description="d", command="echo", **kwargs)


def _patch_sources(return_value=None):
    return patch(
        "hypergolic.tools.tool_list.resolve_custom_tool_sources",
        return_value=return_value or {},
    )


@pytest.fixture(autouse=True)
def _patch_workflow_tools():
    with (
        patch("hypergolic.tools.tool_list.build_workflow_tools", return_value=[]),
        patch("hypergolic.tools.tool_list.build_activate_workflow_tool", return_value=None),
    ):
        yield


class TestSkillGatedTools:
    def test_edit_config_not_in_standard_tools(self):
        standard_ids = {t.id for t in STANDARD_TOOLS}
        assert "edit_config" not in standard_ids

    def test_edit_config_in_skill_tools_map(self):
        for skill_id in ("hypergolic-expertise", "tool-builder"):
            assert skill_id in SKILL_TOOLS
            skill_tool_ids = {t.id for t in SKILL_TOOLS[skill_id]}
            assert "edit_config" in skill_tool_ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set())
    @patch("hypergolic.tools.tool_list.resolve_custom_tools", return_value={})
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    def test_no_edit_config_without_skill(self, _servers, _skills_tool, _custom, _skill_ids, session):
        with _patch_sources():
            result = build_tools(session)
        ids = tool_ids(result.tools)
        assert "edit_config" not in ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value={"hypergolic-expertise"})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools", return_value={})
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    def test_edit_config_included_with_skill(self, _servers, _skills_tool, _custom, _skill_ids, session):
        with _patch_sources():
            result = build_tools(session)
        ids = tool_ids(result.tools)
        assert "edit_config" in ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value={"tool-builder"})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools", return_value={})
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    def test_tool_builder_grants_edit_config(self, _servers, _skills_tool, _custom, _skill_ids, session):
        with _patch_sources():
            result = build_tools(session)
        ids = tool_ids(result.tools)
        assert "edit_config" in ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value={"hypergolic-expertise", "tool-builder"})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools", return_value={})
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    def test_multiple_skills_no_duplicate_tools(self, _servers, _skills_tool, _custom, _skill_ids, session):
        with _patch_sources():
            result = build_tools(session)
        ids = [t.id for t in result.tools]
        assert ids.count("edit_config") == 1

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value={"hypergolic-expertise"})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools", return_value={})
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    def test_standard_tools_always_present(self, _servers, _skills_tool, _custom, _skill_ids, session):
        with _patch_sources():
            result = build_tools(session)
        ids = tool_ids(result.tools)
        for standard_tool in STANDARD_TOOLS:
            assert standard_tool.id in ids


class TestCustomToolScoping:
    """Custom tools appear based on where they're defined, resolved by resolve_custom_tools."""

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set())
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools")
    def test_resolved_tools_included(self, mock_custom, _servers, _skills_tool, _skill_ids, session):
        mock_custom.return_value = {
            "tool_a": _make_tool("tool_a"),
        }
        with _patch_sources({"tool_a": "user"}):
            result = build_tools(session)
        ids = tool_ids(result.tools)
        assert "tool_a" in ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set())
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools", return_value={})
    def test_empty_custom_tools(self, _custom, _servers, _skills_tool, _skill_ids, session):
        with _patch_sources():
            result = build_tools(session)
        ids = tool_ids(result.tools)
        for standard_tool in STANDARD_TOOLS:
            assert standard_tool.id in ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set())
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools")
    def test_standard_tools_unaffected(self, mock_custom, _servers, _skills_tool, _skill_ids, session):
        mock_custom.return_value = {"tool_a": _make_tool("tool_a")}
        with _patch_sources({"tool_a": "user"}):
            result = build_tools(session)
        ids = tool_ids(result.tools)
        for standard_tool in STANDARD_TOOLS:
            assert standard_tool.id in ids

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set())
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools")
    def test_custom_tool_conflicting_with_builtin_skipped(self, mock_custom, _servers, _skills_tool, _skill_ids, session):
        mock_custom.return_value = {"list_files": _make_tool("list_files")}
        with _patch_sources({"list_files": "user"}):
            result = build_tools(session)
        ids = [t.id for t in result.tools]
        assert ids.count("list_files") == 1

    @patch("hypergolic.tools.tool_list.get_active_skill_ids", return_value=set())
    @patch("hypergolic.tools.tool_list.build_skills_tool", return_value=None)
    @patch("hypergolic.tools.tool_list.get_enabled_servers", return_value={})
    @patch("hypergolic.tools.tool_list.resolve_custom_tools")
    def test_custom_sources_tracked(self, mock_custom, _servers, _skills_tool, _skill_ids, session):
        mock_custom.return_value = {"tool_a": _make_tool("tool_a")}
        with _patch_sources({"tool_a": "user-project"}):
            result = build_tools(session)
        assert result.custom_sources.get("tool_a") == "user-project"
