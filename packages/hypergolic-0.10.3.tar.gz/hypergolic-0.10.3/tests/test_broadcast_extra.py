from hypergolic.messages.types import BroadcastEvent
from hypergolic.websocket.helpers import serialize_event
from hypergolic.tools.schemas import ToolOutput


class TestSerializeEventWorkflowStateChange:
    def test_workflow_data_in_content(self):
        event = BroadcastEvent(
            type="workflow_state_change",
            role="system",
            content=[{
                "workflow_id": "test-wf",
                "workflow_name": "Test Workflow",
                "workflow_state_id": "planning",
                "workflow_state_name": "Planning",
            }],
            session_id="sess-1",
        )
        payload = serialize_event(event)
        assert payload["type"] == "workflow_state_change"
        assert payload["content"][0]["workflow_id"] == "test-wf"
        assert payload["content"][0]["workflow_name"] == "Test Workflow"
        assert payload["content"][0]["workflow_state_id"] == "planning"
        assert payload["content"][0]["workflow_state_name"] == "Planning"

    def test_no_extra_field_in_payload(self):
        event = BroadcastEvent(
            type="text",
            role="assistant",
            content=[{"type": "text", "text": "hello"}],
            session_id="sess-1",
        )
        payload = serialize_event(event)
        assert "extra" not in payload
        assert payload["type"] == "text"

    def test_empty_content(self):
        event = BroadcastEvent(
            type="text",
            role="assistant",
            content=[],
        )
        payload = serialize_event(event)
        assert payload == {"type": "text", "role": "assistant", "content": []}

    def test_null_workflow_state_in_content(self):
        event = BroadcastEvent(
            type="workflow_state_change",
            role="system",
            content=[{
                "workflow_id": None,
                "workflow_name": None,
                "workflow_state_id": None,
                "workflow_state_name": None,
            }],
            session_id="sess-1",
        )
        payload = serialize_event(event)
        assert payload["content"][0]["workflow_id"] is None
        assert payload["content"][0]["workflow_name"] is None
        assert payload["content"][0]["workflow_state_id"] is None


class TestToolOutputNoPostEvents:
    def test_no_post_events_attribute(self):
        output = ToolOutput(content=[])
        assert not hasattr(output, "post_events")
