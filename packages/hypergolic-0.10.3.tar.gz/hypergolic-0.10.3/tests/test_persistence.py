from unittest.mock import MagicMock

from pydantic import BaseModel

from hypergolic.messages.persistence import strip_excluded_fields, parse_agent_message
from hypergolic.messages.types import EXCLUDED_FIELDS


class TestStripExcludedFields:
    def test_removes_excluded_keys_from_dicts(self):
        content = [
            {"type": "text", "text": "hello", "parsed_output": "junk", "caller": "x"},
        ]
        result = strip_excluded_fields(content)
        assert result == [{"type": "text", "text": "hello"}]

    def test_preserves_non_excluded_keys(self):
        content = [{"type": "tool_use", "id": "t1", "name": "read", "input": {}}]
        result = strip_excluded_fields(content)
        assert result == content

    def test_passes_through_non_dict_blocks(self):
        content = ["plain string", 42]
        result = strip_excluded_fields(content)
        assert result == ["plain string", 42]

    def test_empty_list(self):
        assert strip_excluded_fields([]) == []

    def test_mixed_dict_and_non_dict(self):
        content = [
            {"type": "text", "text": "hi", "parsed_output": "x"},
            "raw",
        ]
        result = strip_excluded_fields(content)
        assert result == [{"type": "text", "text": "hi"}, "raw"]

    def test_does_not_mutate_original(self):
        original = [{"type": "text", "parsed_output": "val"}]
        strip_excluded_fields(original)
        assert "parsed_output" in original[0]


class TestParseAgentMessage:
    def _make_message(self, content_blocks):
        msg = MagicMock()
        msg.content = content_blocks
        return msg

    def test_dict_blocks_passed_through(self):
        msg = self._make_message([{"type": "text", "text": "hello"}])
        result = parse_agent_message(msg)
        assert result["role"] == "assistant"
        assert result["content"] == [{"type": "text", "text": "hello"}]

    def test_pydantic_blocks_serialized(self):
        class FakeBlock(BaseModel):
            type: str = "text"
            text: str = "hi"
            parsed_output: str = "should_be_excluded"

        msg = self._make_message([FakeBlock()])
        result = parse_agent_message(msg)
        content = result["content"]
        assert len(content) == 1  # type: ignore[arg-type]
        block = content[0]  # type: ignore[index]
        for excluded in EXCLUDED_FIELDS:
            assert excluded not in block
        assert block["text"] == "hi"  # type: ignore[index]

    def test_empty_content(self):
        msg = self._make_message([])
        result = parse_agent_message(msg)
        assert result["content"] == []
        assert result["role"] == "assistant"
