"""Tests for message integrity — ensuring load_session_messages never returns
sequences that violate the Claude API contract.

Key invariant: every user message containing tool_result blocks must be
immediately preceded by an assistant message whose tool_use blocks include
all referenced tool_use_ids.
"""

import asyncio
from typing import Any

import pytest
from anthropic.types import MessageParam

from hypergolic.messages.persistence import (
    _repair_message_sequence,
    load_session_messages,
)


def validate_tool_pairing(messages: list[MessageParam]) -> list[str]:
    """Check that every tool_result references a tool_use in the preceding assistant message.
    Returns a list of error descriptions (empty = valid).
    """
    errors = []
    for i, msg in enumerate(messages):
        if msg["role"] != "user":
            continue
        content = msg.get("content", [])
        if isinstance(content, str):
            continue

        tool_result_ids = set()
        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_result":
                tool_result_ids.add(block.get("tool_use_id"))

        if not tool_result_ids:
            continue

        if i == 0:
            errors.append(
                f"Message {i}: tool_result blocks {tool_result_ids} with no preceding assistant message"
            )
            continue

        prev = messages[i - 1]
        if prev["role"] != "assistant":
            errors.append(
                f"Message {i}: tool_result blocks preceded by role={prev['role']}, not assistant"
            )
            continue

        prev_content = prev.get("content", [])
        if isinstance(prev_content, str):
            prev_tool_use_ids = set()
        else:
            prev_tool_use_ids = {
                block.get("id")
                for block in prev_content
                if isinstance(block, dict) and block.get("type") == "tool_use"
            }

        orphaned = tool_result_ids - prev_tool_use_ids
        if orphaned:
            errors.append(
                f"Message {i}: tool_result ids {orphaned} not found in preceding assistant tool_use ids {prev_tool_use_ids}"
            )

    return errors


def validate_alternation(messages: list[MessageParam]) -> list[str]:
    """Check that messages strictly alternate between user and assistant roles."""
    errors = []
    for i in range(1, len(messages)):
        if messages[i]["role"] == messages[i - 1]["role"]:
            errors.append(
                f"Messages {i-1} and {i}: consecutive {messages[i]['role']} messages"
            )
    return errors


class TestValidateToolPairing:
    def test_valid_tool_use_result_pair(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "do something"}]},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "read_files", "input": {}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "file contents"},
                ],
            },
        ]
        assert validate_tool_pairing(messages) == []

    def test_orphaned_tool_result(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "do something"}]},
            {
                "role": "assistant",
                "content": [{"type": "text", "text": "thinking..."}],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_ORPHAN", "content": "result"},
                ],
            },
        ]
        errors = validate_tool_pairing(messages)
        assert len(errors) == 1
        assert "tu_ORPHAN" in errors[0]

    def test_tool_result_after_error_message(self):
        """Simulates: assistant(tool_use) persisted, then error assistant message
        inserted, then tool_result. The tool_result's preceding message is the
        error, not the tool_use."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "do something"}]},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "cmd", "input": {}},
                ],
            },
            {
                "role": "assistant",
                "content": [{"type": "text", "text": "API error occurred"}],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "result"},
                ],
            },
        ]
        errors = validate_tool_pairing(messages)
        assert len(errors) == 1
        assert "tu_1" in errors[0]

    def test_tool_result_with_no_preceding_message(self):
        messages: list[MessageParam] = [
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "result"},
                ],
            },
        ]
        errors = validate_tool_pairing(messages)
        assert len(errors) == 1

    def test_partial_match(self):
        """Assistant has tool_use tu_1 but tool_result references tu_1 and tu_2."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "cmd", "input": {}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "ok"},
                    {"type": "tool_result", "tool_use_id": "tu_2", "content": "bad"},
                ],
            },
        ]
        errors = validate_tool_pairing(messages)
        assert len(errors) == 1
        assert "tu_2" in errors[0]


class TestValidateAlternation:
    def test_valid_alternation(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
            {"role": "user", "content": "bye"},
        ]
        assert validate_alternation(messages) == []

    def test_consecutive_assistant_messages(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "response 1"},
            {"role": "assistant", "content": "error message"},
        ]
        errors = validate_alternation(messages)
        assert len(errors) == 1
        assert "consecutive assistant" in errors[0]


class TestRepairMessageSequence:
    """Tests for _repair_message_sequence which fixes broken DB states."""

    def test_empty_messages(self):
        assert _repair_message_sequence([]) == []

    def test_valid_sequence_unchanged(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "hello"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
            {"role": "user", "content": [{"type": "text", "text": "bye"}]},
        ]
        result = _repair_message_sequence(messages)
        assert result == messages

    def test_valid_tool_use_pair_unchanged(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "tu_1", "name": "cmd", "input": {}}],
            },
            {
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": "tu_1", "content": "ok"}],
            },
        ]
        result = _repair_message_sequence(messages)
        assert result == messages

    def test_consecutive_assistant_with_tool_use_inserts_error_results(self):
        """assistant(tool_use) + assistant(error) → inserts synthetic tool_results."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "tu_1", "name": "cmd", "input": {}}],
            },
            {
                "role": "assistant",
                "content": [{"type": "text", "text": "error occurred"}],
            },
        ]
        result = _repair_message_sequence(messages)

        assert len(result) == 4
        assert validate_alternation(result) == []
        assert validate_tool_pairing(result) == []

        synthetic = result[2]
        assert synthetic["role"] == "user"
        content: list[Any] = list(synthetic["content"])
        assert len(content) == 1
        assert content[0]["type"] == "tool_result"
        assert content[0]["tool_use_id"] == "tu_1"
        assert content[0]["is_error"] is True

    def test_consecutive_assistant_without_tool_use_merges(self):
        """Two text-only assistant messages get merged."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "part 1"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "part 2"}]},
        ]
        result = _repair_message_sequence(messages)

        assert len(result) == 2
        assert validate_alternation(result) == []
        content: list[Any] = list(result[1]["content"])
        assert len(content) == 2
        texts = [b["text"] for b in content]
        assert "part 1" in texts
        assert "part 2" in texts

    def test_consecutive_user_messages_merged(self):
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "hello"}]},
            {"role": "user", "content": [{"type": "text", "text": "world"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
        ]
        result = _repair_message_sequence(messages)

        assert len(result) == 2
        assert validate_alternation(result) == []
        content: list[Any] = list(result[0]["content"])
        texts = [b["text"] for b in content]
        assert "hello" in texts
        assert "world" in texts

    def test_trailing_assistant_tool_use_gets_results(self):
        """Assistant tool_use at end of messages gets synthetic results appended."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "cmd", "input": {}},
                    {"type": "tool_use", "id": "tu_2", "name": "read", "input": {}},
                ],
            },
        ]
        result = _repair_message_sequence(messages)

        assert len(result) == 3
        assert validate_alternation(result) == []
        assert validate_tool_pairing(result) == []

        content_list: list[Any] = list(result[2]["content"])
        result_ids = {b["tool_use_id"] for b in content_list}
        assert result_ids == {"tu_1", "tu_2"}

    def test_trailing_assistant_text_only_no_change(self):
        """Assistant text-only at end doesn't get synthetic results."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "done"}]},
        ]
        result = _repair_message_sequence(messages)
        assert result == messages

    def test_multiple_tool_use_followed_by_error(self):
        """assistant(tool_use tu_1, tu_2) + assistant(error) → results for both."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "go"}]},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "a", "input": {}},
                    {"type": "tool_use", "id": "tu_2", "name": "b", "input": {}},
                ],
            },
            {
                "role": "assistant",
                "content": [{"type": "text", "text": "error"}],
            },
        ]
        result = _repair_message_sequence(messages)

        assert len(result) == 4
        assert validate_alternation(result) == []
        assert validate_tool_pairing(result) == []

        content_list: list[Any] = list(result[2]["content"])
        result_ids = {b["tool_use_id"] for b in content_list}
        assert result_ids == {"tu_1", "tu_2"}

    def test_error_after_tool_use_then_user_resume(self):
        """The full broken scenario: tool_use, error, user retry."""
        messages: list[MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": "do something"}]},
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "tu_1", "name": "cmd", "input": {}}],
            },
            {
                "role": "assistant",
                "content": [{"type": "text", "text": "Something failed"}],
            },
            {"role": "user", "content": [{"type": "text", "text": "try again"}]},
        ]
        result = _repair_message_sequence(messages)

        assert validate_alternation(result) == []
        assert validate_tool_pairing(result) == []
        assert len(result) == 5
        assert result[0]["role"] == "user"
        assert result[1]["role"] == "assistant"  # tool_use
        assert result[2]["role"] == "user"  # synthetic tool_results
        assert result[3]["role"] == "assistant"  # error
        assert result[4]["role"] == "user"  # retry

    def test_string_content_handling(self):
        """Consecutive messages with string content get merged properly."""
        messages: list[MessageParam] = [
            {"role": "user", "content": "hello"},
            {"role": "user", "content": "world"},
        ]
        result = _repair_message_sequence(messages)

        assert len(result) == 1
        assert result[0]["role"] == "user"
        content: list[Any] = list(result[0]["content"])
        assert len(content) == 2


class TestLoadSessionMessagesRepairIntegration:
    """Integration tests verifying load_session_messages returns valid sequences
    even when the DB contains broken state."""

    @pytest.fixture
    def db_session(self, tmp_path):
        import os
        os.environ.setdefault("HYPERGOLIC_SECRET", "test-secret")

        from sqlalchemy import create_engine
        from sqlalchemy.orm import Session as SASession
        from hypergolic.db.models import Base
        from unittest.mock import patch
        from contextlib import contextmanager

        engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(engine)

        @contextmanager
        def mock_get_db():
            session = SASession(engine)
            try:
                yield session
                session.commit()
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()

        with patch("hypergolic.messages.persistence.get_db", mock_get_db), \
             patch("hypergolic.websocket.helpers.get_db", mock_get_db):
            yield mock_get_db

    def test_error_after_tool_use_repaired_on_load(self, db_session):
        """Broken DB state (tool_use + error assistant) is repaired by load_session_messages."""
        from hypergolic.db.models import DBMessage
        from hypergolic.websocket.helpers import persist_error_message

        session_id = "test-session"

        with db_session() as db:
            db.add(DBMessage(
                session_id=session_id,
                content=[{"type": "text", "text": "do something"}],
                model=None, role="user",
                stop_reason=None, stop_sequence=None, usage=None,
            ))

        with db_session() as db:
            db.add(DBMessage(
                id="msg_tool_use",
                session_id=session_id,
                content=[{"type": "tool_use", "id": "tu_1", "name": "command", "input": {"command": "ls"}}],
                model="claude-sonnet-4-20250514", role="assistant",
                stop_reason="tool_use", stop_sequence=None,
                usage={"input_tokens": 100, "output_tokens": 50},
            ))

        persist_error_message(session_id, "AI provider error (HTTP 400): something broke")

        messages = load_session_messages(session_id)

        assert validate_alternation(messages) == []
        assert validate_tool_pairing(messages) == []
        assert len(messages) == 4
        assert messages[2]["role"] == "user"
        content_list: list[Any] = list(messages[2]["content"])
        assert content_list[0]["type"] == "tool_result"
        assert content_list[0]["tool_use_id"] == "tu_1"

    def test_error_after_tool_use_then_resume_repaired(self, db_session):
        """Broken state + user retry is fully repaired."""
        from hypergolic.db.models import DBMessage
        from hypergolic.messages.persistence import persist_user_message
        from hypergolic.websocket.helpers import persist_error_message

        session_id = "test-session-2"

        with db_session() as db:
            db.add(DBMessage(
                session_id=session_id,
                content=[{"type": "text", "text": "do something"}],
                model=None, role="user",
                stop_reason=None, stop_sequence=None, usage=None,
            ))

        with db_session() as db:
            db.add(DBMessage(
                id="msg_tool_use_2",
                session_id=session_id,
                content=[{"type": "tool_use", "id": "tu_1", "name": "command", "input": {"command": "ls"}}],
                model="claude-sonnet-4-20250514", role="assistant",
                stop_reason="tool_use", stop_sequence=None,
                usage={"input_tokens": 100, "output_tokens": 50},
            ))

        persist_error_message(session_id, "Something failed")

        asyncio.run(
            persist_user_message(
                session_id=session_id,
                message={"role": "user", "content": [{"type": "text", "text": "try again"}]},
            )
        )

        messages = load_session_messages(session_id)

        assert validate_alternation(messages) == []
        assert validate_tool_pairing(messages) == []

    def test_interrupt_during_tool_use_valid(self, db_session):
        """UserInterrupt + _persist_interrupt_tool_results produces valid sequence."""
        from hypergolic.db.models import DBMessage
        from hypergolic.messages.persistence import persist_user_message

        session_id = "test-session-3"

        with db_session() as db:
            db.add(DBMessage(
                session_id=session_id,
                content=[{"type": "text", "text": "run a command"}],
                model=None, role="user",
                stop_reason=None, stop_sequence=None, usage=None,
            ))

        with db_session() as db:
            db.add(DBMessage(
                id="msg_tool_3",
                session_id=session_id,
                content=[
                    {"type": "tool_use", "id": "tu_1", "name": "command", "input": {"command": "ls"}},
                    {"type": "tool_use", "id": "tu_2", "name": "read_files", "input": {"paths": []}},
                ],
                model="claude-sonnet-4-20250514", role="assistant",
                stop_reason="tool_use", stop_sequence=None,
                usage={"input_tokens": 100, "output_tokens": 50},
            ))

        asyncio.run(
            persist_user_message(
                session_id=session_id,
                message={
                    "role": "user",
                    "content": [
                        {"type": "tool_result", "tool_use_id": "tu_1", "content": "Interrupted by user", "is_error": True},
                        {"type": "tool_result", "tool_use_id": "tu_2", "content": "Interrupted by user", "is_error": True},
                    ],
                },
            )
        )

        messages = load_session_messages(session_id)

        assert len(messages) == 3
        assert validate_alternation(messages) == []
        assert validate_tool_pairing(messages) == []
