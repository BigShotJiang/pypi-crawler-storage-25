from pathlib import Path
from unittest.mock import patch

from hypergolic.config.schemas import (
    CustomToolConfig,
    ProjectConfig,
    RoleConfig,
    SkillConfig,
    UserConfig,
    UserProjectConfig,
)
from hypergolic.skills.resolver import (
    resolve_custom_tools,
    resolve_roles,
    resolve_skills,
)


def _tool(tool_id: str, **kwargs) -> CustomToolConfig:
    return CustomToolConfig(id=tool_id, name=tool_id, description="d", command="echo", **kwargs)


def _empty_user_config() -> UserConfig:
    return UserConfig(tools=[], skills=[], roles=[], projects=[])


def _empty_project_config() -> ProjectConfig:
    return ProjectConfig(tools=[], skills=[], roles=[])


class TestResolveCustomTools:
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_empty_configs(self, mock_user):
        mock_user.return_value = _empty_user_config()
        result = resolve_custom_tools()
        assert result == {}

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_tools_always_available(self, mock_user):
        mock_user.return_value = UserConfig(tools=[_tool("mytool")])
        result = resolve_custom_tools()
        assert "mytool" in result

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_project_tools_available(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        mock_user.return_value = _empty_user_config()
        mock_project.return_value = ProjectConfig(tools=[_tool("proj_tool")])
        mock_upc.return_value = None
        result = resolve_custom_tools(tmp_path)
        assert "proj_tool" in result

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_project_tools_available(self, mock_user, mock_project, mock_upc, tmp_path: Path):
        mock_user.return_value = _empty_user_config()
        mock_project.return_value = _empty_project_config()
        mock_upc.return_value = UserProjectConfig(
            git_root=str(tmp_path), name="p", tools=[_tool("up_tool")],
        )
        result = resolve_custom_tools(tmp_path)
        assert "up_tool" in result

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_project_overrides_user(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        user_tool = CustomToolConfig(id="shared", name="shared", description="d", command="user_cmd")
        proj_tool = CustomToolConfig(id="shared", name="shared", description="d", command="proj_cmd")
        mock_user.return_value = UserConfig(tools=[user_tool])
        mock_project.return_value = ProjectConfig(tools=[proj_tool])
        mock_upc.return_value = None
        result = resolve_custom_tools(tmp_path)
        assert len(result) == 1
        assert result["shared"].command == "proj_cmd"

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_and_project_tools_merged(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        mock_user.return_value = UserConfig(tools=[_tool("user_only")])
        mock_project.return_value = ProjectConfig(tools=[_tool("proj_only")])
        mock_upc.return_value = None
        result = resolve_custom_tools(tmp_path)
        assert set(result.keys()) == {"user_only", "proj_only"}

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_skill_tools_excluded_when_skill_inactive(self, mock_user):
        mock_user.return_value = UserConfig(
            skills=[SkillConfig(
                id="my-skill", name="S", description="d",
                prompt_path="~/.agents/skill.md",
                tools=[_tool("skill_tool")],
            )],
        )
        result = resolve_custom_tools()
        assert "skill_tool" not in result

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_skill_tools_included_when_skill_active(self, mock_user):
        mock_user.return_value = UserConfig(
            skills=[SkillConfig(
                id="my-skill", name="S", description="d",
                prompt_path="~/.agents/skill.md",
                tools=[_tool("skill_tool")],
            )],
        )
        result = resolve_custom_tools(active_skill_ids={"my-skill"})
        assert "skill_tool" in result

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_project_skill_tools_gated(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        mock_user.return_value = _empty_user_config()
        mock_project.return_value = ProjectConfig(
            skills=[SkillConfig(
                id="proj-skill", name="PS", description="d",
                prompt_path=".agents/skill.md",
                tools=[_tool("gated")],
            )],
        )
        mock_upc.return_value = None
        assert "gated" not in resolve_custom_tools(tmp_path)
        assert "gated" in resolve_custom_tools(tmp_path, active_skill_ids={"proj-skill"})

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_tools_not_gated_by_skills(self, mock_user):
        """Tools in UserConfig.tools are always available, even without skills."""
        mock_user.return_value = UserConfig(tools=[_tool("free_tool")])
        result = resolve_custom_tools()
        assert "free_tool" in result


class TestResolveRoles:
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_builtin_roles_always_present(self, mock_user):
        mock_user.return_value = _empty_user_config()
        roles = resolve_roles()
        ids = [r["id"] for r in roles]
        assert "default" in ids
        assert "reviewer" in ids

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_roles_added(self, mock_user):
        mock_user.return_value = UserConfig(
            roles=[RoleConfig(id="custom", name="Custom", prompt_path="~/.agents/custom.md")]
        )
        roles = resolve_roles()
        ids = [r["id"] for r in roles]
        assert "custom" in ids

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_role_does_not_override_builtin(self, mock_user):
        mock_user.return_value = UserConfig(
            roles=[RoleConfig(id="default", name="My Default", prompt_path="~/my.md")]
        )
        roles = resolve_roles()
        default_roles = [r for r in roles if r["id"] == "default"]
        assert len(default_roles) == 1
        assert default_roles[0]["source"] == "built-in"

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_project_roles_added(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        mock_user.return_value = _empty_user_config()
        mock_upc.return_value = None
        mock_project.return_value = ProjectConfig(
            roles=[RoleConfig(id="projrole", name="Proj", prompt_path=".agents/role.md")]
        )
        roles = resolve_roles(tmp_path)
        ids = [r["id"] for r in roles]
        assert "projrole" in ids
        proj_role = [r for r in roles if r["id"] == "projrole"][0]
        assert proj_role["source"] == "project"

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_project_roles_added(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        mock_user.return_value = _empty_user_config()
        mock_upc.return_value = UserProjectConfig(
            git_root=str(tmp_path), name="p",
            roles=[RoleConfig(id="uprole", name="UP", prompt_path="~/.agents/up.md")],
        )
        mock_project.return_value = _empty_project_config()
        roles = resolve_roles(tmp_path)
        ids = [r["id"] for r in roles]
        assert "uprole" in ids


class TestResolveSkills:
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_builtin_skills_always_present(self, mock_user):
        mock_user.return_value = _empty_user_config()
        skills = resolve_skills()
        ids = [s["id"] for s in skills]
        assert "tool-builder" in ids
        assert "hypergolic-expertise" in ids

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_skills_added(self, mock_user):
        mock_user.return_value = UserConfig(
            skills=[SkillConfig(
                id="custom-skill", name="Custom", description="d",
                prompt_path="~/.agents/skill.md",
            )]
        )
        skills = resolve_skills()
        ids = [s["id"] for s in skills]
        assert "custom-skill" in ids

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_user_skill_does_not_override_builtin(self, mock_user):
        mock_user.return_value = UserConfig(
            skills=[SkillConfig(
                id="tool-builder", name="Mine", description="d",
                prompt_path="~/mine.md",
            )]
        )
        skills = resolve_skills()
        tb = [s for s in skills if s["id"] == "tool-builder"]
        assert len(tb) == 1
        assert tb[0]["source"] == "built-in"

    @patch("hypergolic.skills.resolver.load_project_config")
    @patch("hypergolic.skills.resolver.load_user_project_config")
    @patch("hypergolic.skills.resolver._load_user_config")
    def test_project_skills_added(self, mock_user, mock_upc, mock_project, tmp_path: Path):
        mock_user.return_value = _empty_user_config()
        mock_upc.return_value = None
        mock_project.return_value = ProjectConfig(
            skills=[SkillConfig(
                id="proj-skill", name="PS", description="d",
                prompt_path=".agents/skill.md",
            )]
        )
        skills = resolve_skills(tmp_path)
        ids = [s["id"] for s in skills]
        assert "proj-skill" in ids
        ps = [s for s in skills if s["id"] == "proj-skill"][0]
        assert ps["source"] == "project"

    @patch("hypergolic.skills.resolver._load_user_config")
    def test_skill_tools_serialized_as_ids(self, mock_user):
        mock_user.return_value = UserConfig(
            skills=[SkillConfig(
                id="my-skill", name="S", description="d",
                prompt_path="~/.agents/skill.md",
                tools=[CustomToolConfig(id="t1", name="T1", description="d", command="echo")],
            )]
        )
        skills = resolve_skills()
        my_skill = [s for s in skills if s["id"] == "my-skill"][0]
        assert my_skill["tools"] == ["t1"]
