from unittest.mock import patch, MagicMock
from pathlib import Path

from hypergolic.git.operations import (
    _parse_numstat,
    get_git_status,
    get_git_diff,
    get_git_log,
    get_git_commit_detail,
    git_push,
)


def _make_result(stdout: str = "", stderr: str = "", returncode: int = 0):
    r = MagicMock()
    r.stdout = stdout
    r.stderr = stderr
    r.returncode = returncode
    return r


class TestParseNumstat:
    @patch("hypergolic.git.operations._run_git")
    def test_basic_numstat(self, mock_run):
        mock_run.return_value = _make_result("10\t3\tsrc/main.py\n5\t0\tREADME.md\n")
        stats = _parse_numstat(Path("/repo"), staged=False)
        assert stats == {"src/main.py": (10, 3), "README.md": (5, 0)}

    @patch("hypergolic.git.operations._run_git")
    def test_binary_file_dashes(self, mock_run):
        mock_run.return_value = _make_result("-\t-\timage.png\n")
        stats = _parse_numstat(Path("/repo"), staged=True)
        assert stats == {"image.png": (0, 0)}

    @patch("hypergolic.git.operations._run_git")
    def test_empty_output(self, mock_run):
        mock_run.return_value = _make_result("")
        stats = _parse_numstat(Path("/repo"), staged=False)
        assert stats == {}

    @patch("hypergolic.git.operations._run_git")
    def test_malformed_lines_skipped(self, mock_run):
        mock_run.return_value = _make_result("10\t3\tgood.py\nbadline\n")
        stats = _parse_numstat(Path("/repo"), staged=False)
        assert stats == {"good.py": (10, 3)}

    @patch("hypergolic.git.operations._run_git")
    def test_staged_flag_passed(self, mock_run):
        mock_run.return_value = _make_result("")
        _parse_numstat(Path("/repo"), staged=True)
        args = mock_run.call_args[0]
        assert "--cached" in args

    @patch("hypergolic.git.operations._run_git")
    def test_unstaged_no_cached_flag(self, mock_run):
        mock_run.return_value = _make_result("")
        _parse_numstat(Path("/repo"), staged=False)
        args = mock_run.call_args[0]
        assert "--cached" not in args


class TestGetGitStatus:
    @patch("hypergolic.git.operations._parse_numstat")
    @patch("hypergolic.git.operations._run_git")
    def test_clean_repo(self, mock_run, mock_numstat):
        mock_run.side_effect = [
            _make_result("main\n"),       # branch
            _make_result("0\t0\n"),       # rev-list
            _make_result(""),              # status --porcelain
        ]
        mock_numstat.return_value = {}
        result = get_git_status(Path("/repo"))
        assert result.branch == "main"
        assert result.ahead == 0
        assert result.behind == 0
        assert result.staged == []
        assert result.unstaged == []
        assert result.untracked == []

    @patch("hypergolic.git.operations._parse_numstat")
    @patch("hypergolic.git.operations._run_git")
    def test_modified_and_untracked(self, mock_run, mock_numstat):
        porcelain = "M  src/app.py\n?? new_file.txt\n"
        mock_run.side_effect = [
            _make_result("feature\n"),
            _make_result("2\t3\n"),
            _make_result(porcelain),
        ]
        mock_numstat.side_effect = [
            {"src/app.py": (5, 2)},  # staged
            {},                       # unstaged
        ]
        result = get_git_status(Path("/repo"))
        assert result.branch == "feature"
        assert result.ahead == 3
        assert result.behind == 2
        assert len(result.staged) == 1
        assert result.staged[0].path == "src/app.py"
        assert result.staged[0].additions == 5
        assert result.staged[0].deletions == 2
        assert result.untracked == ["new_file.txt"]

    @patch("hypergolic.git.operations._parse_numstat")
    @patch("hypergolic.git.operations._run_git")
    def test_rename_extracts_new_path(self, mock_run, mock_numstat):
        porcelain = "R  old.py -> new.py\n"
        mock_run.side_effect = [
            _make_result("main\n"),
            _make_result("0\t0\n"),
            _make_result(porcelain),
        ]
        mock_numstat.return_value = {}
        result = get_git_status(Path("/repo"))
        assert result.staged[0].path == "new.py"

    @patch("hypergolic.git.operations._parse_numstat")
    @patch("hypergolic.git.operations._run_git")
    def test_no_upstream(self, mock_run, mock_numstat):
        mock_run.side_effect = [
            _make_result("main\n"),
            _make_result(stderr="fatal: no upstream", returncode=128),
            _make_result(""),
        ]
        mock_numstat.return_value = {}
        result = get_git_status(Path("/repo"))
        assert result.ahead == 0
        assert result.behind == 0

    @patch("hypergolic.git.operations._parse_numstat")
    @patch("hypergolic.git.operations._run_git")
    def test_worktree_modified(self, mock_run, mock_numstat):
        porcelain = " M src/lib.py\n"
        mock_run.side_effect = [
            _make_result("main\n"),
            _make_result("0\t0\n"),
            _make_result(porcelain),
        ]
        mock_numstat.side_effect = [
            {},
            {"src/lib.py": (1, 1)},
        ]
        result = get_git_status(Path("/repo"))
        assert len(result.staged) == 0
        assert len(result.unstaged) == 1
        assert result.unstaged[0].path == "src/lib.py"
        assert result.unstaged[0].staged is False

    @patch("hypergolic.git.operations._parse_numstat")
    @patch("hypergolic.git.operations._run_git")
    def test_short_lines_skipped(self, mock_run, mock_numstat):
        porcelain = "ab\nM  valid.py\n"
        mock_run.side_effect = [
            _make_result("main\n"),
            _make_result("0\t0\n"),
            _make_result(porcelain),
        ]
        mock_numstat.return_value = {}
        result = get_git_status(Path("/repo"))
        assert len(result.staged) == 1


class TestGetGitDiff:
    @patch("hypergolic.git.operations._run_git")
    def test_basic_diff(self, mock_run):
        mock_run.return_value = _make_result("+new line\n-old line\n")
        result = get_git_diff("file.py", staged=False, repo=Path("/repo"))
        assert result.path == "file.py"
        assert "+new line" in result.diff

    @patch("hypergolic.git.operations._run_git")
    def test_staged_diff(self, mock_run):
        mock_run.return_value = _make_result("staged diff")
        get_git_diff("file.py", staged=True, repo=Path("/repo"))
        args = mock_run.call_args[0]
        assert "--cached" in args

    @patch("hypergolic.git.operations._run_git")
    def test_untracked_file_fallback(self, mock_run):
        mock_run.side_effect = [
            _make_result(""),
            _make_result("+new file content"),
        ]
        result = get_git_diff("new.py", staged=False, repo=Path("/repo"))
        assert result.diff == "+new file content"

    @patch("hypergolic.git.operations._run_git")
    def test_no_path_diff(self, mock_run):
        mock_run.return_value = _make_result("full diff")
        result = get_git_diff(None, staged=False, repo=Path("/repo"))
        assert result.path == ""
        assert result.diff == "full diff"


class TestGetGitLog:
    @patch("hypergolic.git.operations._run_git")
    def test_parses_log_entries(self, mock_run):
        sep = "\x1f"
        line = sep.join(["abc123", "abc", "Author", "2024-01-01", "msg", "HEAD -> main"])
        mock_run.return_value = _make_result(line + "\n")
        result = get_git_log(count=10, repo=Path("/repo"))
        assert len(result.entries) == 1
        assert result.entries[0].hash == "abc123"
        assert result.entries[0].author == "Author"
        assert result.entries[0].refs == "HEAD -> main"

    @patch("hypergolic.git.operations._run_git")
    def test_skips_malformed_lines(self, mock_run):
        sep = "\x1f"
        good = sep.join(["abc", "ab", "A", "2024", "msg", "refs"])
        mock_run.return_value = _make_result(f"{good}\nbadline\n")
        result = get_git_log(repo=Path("/repo"))
        assert len(result.entries) == 1

    @patch("hypergolic.git.operations._run_git")
    def test_empty_log(self, mock_run):
        mock_run.return_value = _make_result("")
        result = get_git_log(repo=Path("/repo"))
        assert result.entries == []


class TestGetGitCommitDetail:
    @patch("hypergolic.git.operations._run_git")
    def test_parses_commit(self, mock_run):
        sep = "\x1f"
        info = sep.join(["abc123full", "abc123", "Author", "2024-01-01", "fix bug"])
        mock_run.side_effect = [
            _make_result(info),
            _make_result("+line\n-old\n"),
        ]
        result = get_git_commit_detail("abc123full", repo=Path("/repo"))
        assert result.hash == "abc123full"
        assert result.author == "Author"
        assert result.message == "fix bug"
        assert "+line" in result.diff

    @patch("hypergolic.git.operations._run_git")
    def test_malformed_returns_fallback(self, mock_run):
        mock_run.return_value = _make_result("bad output")
        result = get_git_commit_detail("abc", repo=Path("/repo"))
        assert result.hash == "abc"
        assert result.author == ""
        assert result.diff == ""


class TestGitPush:
    @patch("hypergolic.git.operations._run_git")
    def test_push_success(self, mock_run):
        mock_run.return_value = _make_result("Everything up-to-date")
        result = git_push(repo=Path("/repo"))
        assert "up-to-date" in result

    @patch("hypergolic.git.operations._run_git")
    def test_push_sets_upstream_on_failure(self, mock_run):
        mock_run.side_effect = [
            _make_result(stderr="no upstream branch", returncode=1),
            _make_result("main\n"),
            _make_result("Branch pushed"),
        ]
        result = git_push(repo=Path("/repo"))
        assert "Branch pushed" in result
