import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from hypergolic.config.schemas import (
    WorkflowConfig,
    WorkflowOutputSchema,
    WorkflowStateConfig,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.workflows.engine import (
    WorkflowError,
    activate_workflow,
    handle_workflow_transition,
)
from hypergolic.workflows.builtins import BUILT_IN_WORKFLOWS
from hypergolic.workflows.resolver import resolve_workflows, get_workflow_config, get_session_workflow
from hypergolic.workflows.tools import build_workflow_tools, _json_schema_to_pydantic_fields

from typing import Any


def _make_workflow(**overrides: Any) -> WorkflowConfig:
    states = overrides.pop("states", [
        WorkflowStateConfig(
            id="start",
            name="Start",
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="start_output",
                    schema={"type": "object", "properties": {"result": {"type": "string"}}, "required": ["result"]},
                    next_state="middle",
                ),
                WorkflowOutputSchema(
                    outcome="failure",
                    schema={"type": "object", "properties": {"reason": {"type": "string"}}, "required": ["reason"]},
                    next_state=None,
                ),
            ],
        ),
        WorkflowStateConfig(
            id="middle",
            name="Middle",
            truncate_on_entry=True,
            include_artifacts=["start_output"],
            output_schemas=[
                WorkflowOutputSchema(
                    outcome="success",
                    artifact_id="middle_output",
                    schema={"type": "object", "properties": {"data": {"type": "string"}}, "required": ["data"]},
                    next_state=None,
                ),
            ],
        ),
    ])
    return WorkflowConfig(
        id=overrides.get("id", "test-wf"),
        name=overrides.get("name", "Test Workflow"),
        description=overrides.get("description", "A test workflow"),
        initial_state=overrides.get("initial_state", "start"),
        states=states,
    )


def _make_session() -> Session:
    return Session(
        id="test-session",
        model_tier=ModelTier.HIGH,
        project_id="test-project",
        project_path="/tmp/test",
        role="default",
    )


BUILT_IN_IDS = {"feature-development", "debug", "optimize-config"}


class TestBuiltInWorkflows:
    def test_all_built_in_ids(self):
        ids = {w.id for w in BUILT_IN_WORKFLOWS}
        assert ids == BUILT_IN_IDS

    @pytest.mark.parametrize("wf", BUILT_IN_WORKFLOWS, ids=lambda w: w.id)
    def test_initial_state_exists(self, wf):
        state_ids = {s.id for s in wf.states}
        assert wf.initial_state in state_ids

    @pytest.mark.parametrize("wf", BUILT_IN_WORKFLOWS, ids=lambda w: w.id)
    def test_next_states_are_valid(self, wf):
        state_ids = {s.id for s in wf.states}
        for state in wf.states:
            for schema in state.output_schemas:
                if schema.next_state is not None:
                    assert schema.next_state in state_ids, (
                        f"{wf.id}/{state.id}: next_state '{schema.next_state}' not in states"
                    )

    @pytest.mark.parametrize("wf", BUILT_IN_WORKFLOWS, ids=lambda w: w.id)
    def test_prompt_files_exist(self, wf):
        if wf.prompt_path:
            assert Path(wf.prompt_path).exists(), f"Workflow prompt missing: {wf.prompt_path}"
        for state in wf.states:
            if state.prompt_path:
                assert Path(state.prompt_path).exists(), f"State prompt missing: {state.prompt_path}"

    @pytest.mark.parametrize("wf", BUILT_IN_WORKFLOWS, ids=lambda w: w.id)
    def test_every_state_has_output_schemas(self, wf):
        for state in wf.states:
            assert len(state.output_schemas) > 0, f"{wf.id}/{state.id} has no output schemas"

    @pytest.mark.parametrize("wf", BUILT_IN_WORKFLOWS, ids=lambda w: w.id)
    def test_at_least_one_terminal_state(self, wf):
        has_terminal = any(
            schema.next_state is None
            for state in wf.states
            for schema in state.output_schemas
        )
        assert has_terminal, f"{wf.id} has no terminal transitions"


class TestResolveWorkflows:
    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_builtins_always_present(self, mock_user):
        from hypergolic.config.schemas import UserConfig
        mock_user.return_value = UserConfig()
        result = resolve_workflows()
        ids = {w.id for w in result}
        assert BUILT_IN_IDS <= ids

    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_user_workflows(self, mock_user):
        from hypergolic.config.schemas import UserConfig
        wf = _make_workflow()
        mock_user.return_value = UserConfig(workflows=[wf])
        result = resolve_workflows()
        ids = {w.id for w in result}
        assert "test-wf" in ids
        assert BUILT_IN_IDS <= ids

    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_user_overrides_builtin(self, mock_user):
        from hypergolic.config.schemas import UserConfig
        wf = _make_workflow(id="feature-development", name="Custom FD")
        mock_user.return_value = UserConfig(workflows=[wf])
        result = resolve_workflows()
        fd = next(w for w in result if w.id == "feature-development")
        assert fd.name == "Custom FD"

    @patch("hypergolic.workflows.resolver.load_project_config")
    @patch("hypergolic.workflows.resolver.load_user_project_config")
    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_project_overrides_user(self, mock_user, mock_upc, mock_project, tmp_path):
        from hypergolic.config.schemas import UserConfig, ProjectConfig
        user_wf = _make_workflow(name="User Version")
        proj_wf = _make_workflow(name="Project Version")
        mock_user.return_value = UserConfig(workflows=[user_wf])
        mock_project.return_value = ProjectConfig(workflows=[proj_wf])
        mock_upc.return_value = None
        result = resolve_workflows(tmp_path)
        test_wf = next(w for w in result if w.id == "test-wf")
        assert test_wf.name == "Project Version"

    @patch("hypergolic.workflows.resolver.load_project_config")
    @patch("hypergolic.workflows.resolver.load_user_project_config")
    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_user_project_overrides_project(self, mock_user, mock_upc, mock_project, tmp_path):
        from hypergolic.config.schemas import UserConfig, ProjectConfig, UserProjectConfig
        user_wf = _make_workflow(name="User")
        proj_wf = _make_workflow(name="Project")
        up_wf = _make_workflow(name="User-Project")
        mock_user.return_value = UserConfig(workflows=[user_wf])
        mock_project.return_value = ProjectConfig(workflows=[proj_wf])
        mock_upc.return_value = UserProjectConfig(
            git_root=str(tmp_path), name="p", workflows=[up_wf]
        )
        result = resolve_workflows(tmp_path)
        test_wf = next(w for w in result if w.id == "test-wf")
        assert test_wf.name == "User-Project"

    @patch("hypergolic.workflows.resolver.load_project_config")
    @patch("hypergolic.workflows.resolver.load_user_project_config")
    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_different_ids_merged(self, mock_user, mock_upc, mock_project, tmp_path):
        from hypergolic.config.schemas import UserConfig, ProjectConfig
        wf1 = _make_workflow(id="wf1", name="WF1")
        wf2 = _make_workflow(id="wf2", name="WF2")
        mock_user.return_value = UserConfig(workflows=[wf1])
        mock_project.return_value = ProjectConfig(workflows=[wf2])
        mock_upc.return_value = None
        result = resolve_workflows(tmp_path)
        ids = {w.id for w in result}
        assert {"wf1", "wf2"} <= ids
        assert BUILT_IN_IDS <= ids

    @patch("hypergolic.workflows.resolver.load_project_config")
    @patch("hypergolic.workflows.resolver.load_user_project_config")
    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_project_overrides_builtin(self, mock_user, mock_upc, mock_project, tmp_path):
        from hypergolic.config.schemas import UserConfig, ProjectConfig
        proj_wf = _make_workflow(id="debug", name="Custom Debug")
        mock_user.return_value = UserConfig()
        mock_project.return_value = ProjectConfig(workflows=[proj_wf])
        mock_upc.return_value = None
        result = resolve_workflows(tmp_path)
        debug_wf = next(w for w in result if w.id == "debug")
        assert debug_wf.name == "Custom Debug"


class TestGetWorkflowConfig:
    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_found(self, mock_user):
        from hypergolic.config.schemas import UserConfig
        wf = _make_workflow()
        mock_user.return_value = UserConfig(workflows=[wf])
        result = get_workflow_config("test-wf")
        assert result is not None
        assert result.id == "test-wf"

    @patch("hypergolic.workflows.resolver._load_user_config")
    def test_not_found(self, mock_user):
        from hypergolic.config.schemas import UserConfig
        mock_user.return_value = UserConfig()
        assert get_workflow_config("nonexistent") is None


class TestGetSessionWorkflow:
    @patch("hypergolic.workflows.resolver.get_db")
    def test_no_active_workflow(self, mock_get_db):
        mock_db = MagicMock()
        mock_db.execute.return_value.scalar_one_or_none.return_value = None
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        result = get_session_workflow("session-1")
        assert result is None

    @patch("hypergolic.workflows.resolver.get_db")
    def test_active_workflow(self, mock_get_db):
        mock_row = MagicMock()
        mock_row.workflow_id = "test-wf"
        mock_row.current_state_id = "start"
        mock_db = MagicMock()
        mock_db.execute.return_value.scalar_one_or_none.return_value = mock_row
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)
        result = get_session_workflow("session-1")
        assert result == ("test-wf", "start")


class TestActivateWorkflow:
    @patch("hypergolic.workflows.engine.get_db")
    @patch("hypergolic.workflows.engine.get_session_workflow")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_activate_success(self, mock_get_wf, mock_get_session_wf, mock_get_db):
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_get_session_wf.return_value = None
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(activate_workflow(session, "test-wf", broadcast))

        mock_db.add.assert_called_once()
        broadcast.assert_called_once()
        event = broadcast.call_args[0][0]
        assert event.type == "workflow_state_change"
        assert event.content[0]["workflow_id"] == "test-wf"
        assert event.content[0]["workflow_name"] == "Test Workflow"
        assert event.content[0]["workflow_state_id"] == "start"

    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_activate_unknown_workflow(self, mock_get_wf):
        mock_get_wf.return_value = None
        broadcast = AsyncMock()
        session = _make_session()
        with pytest.raises(WorkflowError, match="not found"):
            asyncio.run(activate_workflow(session, "nonexistent", broadcast))

    @patch("hypergolic.workflows.engine.get_session_workflow")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_activate_already_active(self, mock_get_wf, mock_get_session_wf):
        mock_get_wf.return_value = _make_workflow()
        mock_get_session_wf.return_value = ("test-wf", "start")
        broadcast = AsyncMock()
        session = _make_session()
        with pytest.raises(WorkflowError, match="already has active"):
            asyncio.run(activate_workflow(session, "test-wf", broadcast))


class TestHandleWorkflowTransition:
    @patch("hypergolic.workflows.engine.get_db")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_transition_success(self, mock_get_wf, mock_get_db):
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        session = _make_session()
        result = asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="start",
            outcome="success",
            output={"result": "done"},
        ))

        assert not result.is_error
        assert "Middle" in result.content[0]["text"]  # type: ignore[index]
        assert result.should_truncate is True

    @patch("hypergolic.workflows.engine.get_db")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_transition_success_broadcasts(self, mock_get_wf, mock_get_db):
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="start",
            outcome="success",
            output={"result": "done"},
            broadcast=broadcast,
        ))

        broadcast.assert_called_once()
        event = broadcast.call_args[0][0]
        assert event.type == "workflow_state_change"
        assert event.content[0]["workflow_id"] == "test-wf"
        assert event.content[0]["workflow_name"] == "Test Workflow"
        assert event.content[0]["workflow_state_id"] == "middle"
        assert event.content[0]["workflow_state_name"] == "Middle"

    @patch("hypergolic.workflows.engine.deactivate_workflow", new_callable=AsyncMock)
    @patch("hypergolic.workflows.engine._deactivate_state_skills")
    @patch("hypergolic.workflows.engine.get_db")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_transition_to_terminal(self, mock_get_wf, mock_get_db, mock_deact_skills, mock_deact_wf):
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        session = _make_session()
        result = asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="start",
            outcome="failure",
            output={"reason": "blocked"},
        ))

        assert not result.is_error
        assert "completed" in result.content[0]["text"]  # type: ignore[index]
        mock_deact_wf.assert_called_once_with(session.id)

    @patch("hypergolic.workflows.engine.deactivate_workflow", new_callable=AsyncMock)
    @patch("hypergolic.workflows.engine._deactivate_state_skills")
    @patch("hypergolic.workflows.engine.get_db")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_terminal_transition_broadcasts_null_state(self, mock_get_wf, mock_get_db, mock_deact_skills, mock_deact_wf):
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        broadcast = AsyncMock()
        session = _make_session()
        asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="start",
            outcome="failure",
            output={"reason": "blocked"},
            broadcast=broadcast,
        ))

        broadcast.assert_called_once()
        event = broadcast.call_args[0][0]
        assert event.type == "workflow_state_change"
        assert event.content[0]["workflow_id"] is None
        assert event.content[0]["workflow_name"] is None
        assert event.content[0]["workflow_state_id"] is None
        assert event.content[0]["workflow_state_name"] is None

    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_error_does_not_broadcast(self, mock_get_wf):
        mock_get_wf.return_value = None
        broadcast = AsyncMock()
        session = _make_session()
        result = asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="bad",
            from_state_id="start",
            outcome="success",
            output={},
            broadcast=broadcast,
        ))
        assert result.is_error
        broadcast.assert_not_called()

    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_transition_unknown_workflow(self, mock_get_wf):
        mock_get_wf.return_value = None
        session = _make_session()
        result = asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="bad",
            from_state_id="start",
            outcome="success",
            output={},
        ))
        assert result.is_error

    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_transition_unknown_state(self, mock_get_wf):
        mock_get_wf.return_value = _make_workflow()
        session = _make_session()
        result = asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="nonexistent",
            outcome="success",
            output={},
        ))
        assert result.is_error

    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_transition_unknown_outcome(self, mock_get_wf):
        mock_get_wf.return_value = _make_workflow()
        session = _make_session()
        result = asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="start",
            outcome="suppressed",
            output={},
        ))
        assert result.is_error

    @patch("hypergolic.workflows.engine.get_db")
    @patch("hypergolic.workflows.engine.get_workflow_config")
    def test_artifact_persisted(self, mock_get_wf, mock_get_db):
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_db = MagicMock()
        mock_get_db.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_get_db.return_value.__exit__ = MagicMock(return_value=False)

        session = _make_session()
        asyncio.run(handle_workflow_transition(
            session=session,
            workflow_id="test-wf",
            from_state_id="start",
            outcome="success",
            output={"result": "my artifact data"},
        ))

        add_calls = mock_db.add.call_args_list
        assert len(add_calls) == 1
        artifact = add_calls[0][0][0]
        assert artifact.artifact_id == "start_output"
        assert artifact.content == {"result": "my artifact data"}


class TestJsonSchemaToPydanticFields:
    def test_string_required(self):
        fields = _json_schema_to_pydantic_fields({
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        })
        assert "name" in fields
        assert fields["name"] == (str, ...)

    def test_string_optional(self):
        fields = _json_schema_to_pydantic_fields({
            "type": "object",
            "properties": {"name": {"type": "string"}},
        })
        assert "name" in fields
        python_type, default = fields["name"]
        assert default is None

    def test_integer(self):
        fields = _json_schema_to_pydantic_fields({
            "type": "object",
            "properties": {"count": {"type": "integer"}},
            "required": ["count"],
        })
        assert fields["count"] == (int, ...)

    def test_boolean(self):
        fields = _json_schema_to_pydantic_fields({
            "type": "object",
            "properties": {"flag": {"type": "boolean"}},
            "required": ["flag"],
        })
        assert fields["flag"] == (bool, ...)

    def test_array(self):
        fields = _json_schema_to_pydantic_fields({
            "type": "object",
            "properties": {"items": {"type": "array", "items": {"type": "string"}}},
            "required": ["items"],
        })
        assert "items" in fields

    def test_empty_schema(self):
        fields = _json_schema_to_pydantic_fields({"type": "object"})
        assert fields == {}


class TestBuildWorkflowTools:
    @patch("hypergolic.workflows.tools.get_workflow_config")
    @patch("hypergolic.workflows.tools.get_session_workflow")
    def test_no_active_workflow(self, mock_get_session_wf, mock_get_wf):
        mock_get_session_wf.return_value = None
        session = _make_session()
        tools = build_workflow_tools(session)
        assert tools == []

    @patch("hypergolic.workflows.tools.get_workflow_config")
    @patch("hypergolic.workflows.tools.get_session_workflow")
    def test_tools_generated_for_state(self, mock_get_session_wf, mock_get_wf):
        wf = _make_workflow()
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = wf
        session = _make_session()
        tools = build_workflow_tools(session)
        assert len(tools) == 2
        tool_ids = {t.id for t in tools}
        assert tool_ids == {"workflow_transition_success", "workflow_transition_failure"}

    @patch("hypergolic.workflows.tools.get_workflow_config")
    @patch("hypergolic.workflows.tools.get_session_workflow")
    def test_tool_has_correct_schema(self, mock_get_session_wf, mock_get_wf):
        wf = _make_workflow()
        mock_get_session_wf.return_value = ("test-wf", "start")
        mock_get_wf.return_value = wf
        session = _make_session()
        tools = build_workflow_tools(session)
        success_tool = next(t for t in tools if t.id == "workflow_transition_success")
        schema = success_tool.input.model_json_schema()
        assert "result" in schema["properties"]
        assert "result" in schema["required"]

    @patch("hypergolic.workflows.tools.get_workflow_config")
    @patch("hypergolic.workflows.tools.get_session_workflow")
    def test_tools_for_middle_state(self, mock_get_session_wf, mock_get_wf):
        wf = _make_workflow()
        mock_get_session_wf.return_value = ("test-wf", "middle")
        mock_get_wf.return_value = wf
        session = _make_session()
        tools = build_workflow_tools(session)
        assert len(tools) == 1
        assert tools[0].id == "workflow_transition_success"

    @patch("hypergolic.workflows.tools.get_workflow_config")
    @patch("hypergolic.workflows.tools.get_session_workflow")
    def test_requires_approval_propagated(self, mock_get_session_wf, mock_get_wf):
        wf = WorkflowConfig(
            id="wf",
            name="WF",
            description="d",
            initial_state="s",
            states=[
                WorkflowStateConfig(
                    id="s",
                    name="S",
                    output_schemas=[
                        WorkflowOutputSchema(
                            outcome="success",
                            requires_approval=True,
                            schema={"type": "object", "properties": {"doc": {"type": "string"}}, "required": ["doc"]},
                            next_state=None,
                        ),
                        WorkflowOutputSchema(
                            outcome="failure",
                            schema={"type": "object", "properties": {"reason": {"type": "string"}}},
                            next_state=None,
                        ),
                    ],
                ),
            ],
        )
        mock_get_session_wf.return_value = ("wf", "s")
        mock_get_wf.return_value = wf
        session = _make_session()
        tools = build_workflow_tools(session)
        success_tool = next(t for t in tools if t.id == "workflow_transition_success")
        failure_tool = next(t for t in tools if t.id == "workflow_transition_failure")
        assert success_tool.requires_approval is True
        assert failure_tool.requires_approval is False

    @patch("hypergolic.workflows.tools.get_workflow_config")
    @patch("hypergolic.workflows.tools.get_session_workflow")
    def test_display_propagated(self, mock_get_session_wf, mock_get_wf):
        wf = WorkflowConfig(
            id="wf",
            name="WF",
            description="d",
            initial_state="s",
            states=[
                WorkflowStateConfig(
                    id="s",
                    name="S",
                    output_schemas=[
                        WorkflowOutputSchema(
                            outcome="success",
                            display={"document": "markdown"},
                            schema={"type": "object", "properties": {"document": {"type": "string"}}, "required": ["document"]},
                            next_state=None,
                        ),
                    ],
                ),
            ],
        )
        mock_get_session_wf.return_value = ("wf", "s")
        mock_get_wf.return_value = wf
        session = _make_session()
        tools = build_workflow_tools(session)
        assert tools[0].display == {"document": "markdown"}
