from pathlib import Path

from pydantic import ValidationError
import pytest

from hypergolic.config.schemas import (
    CustomToolConfig,
    CustomToolParam,
    MCPAuthConfig,
    MCPServerConfig,
    ProjectConfig,
    RoleConfig,
    SkillConfig,
    UserConfig,
    UserProjectConfig,
)


class TestMCPAuthConfig:
    def test_defaults(self):
        c = MCPAuthConfig()
        assert c.type == "none"
        assert c.token_env_var is None
        assert c.token_header == "Authorization"
        assert c.token_prefix == "Bearer"

    def test_oauth_type(self):
        c = MCPAuthConfig(type="oauth")
        assert c.type == "oauth"

    def test_invalid_type_rejected(self):
        with pytest.raises(ValidationError):
            MCPAuthConfig(type="bad")  # type: ignore[arg-type]


class TestMCPServerConfig:
    def test_stdio_defaults(self):
        c = MCPServerConfig()
        assert c.transport == "stdio"
        assert c.command is None
        assert c.args == []
        assert c.env == {}
        assert c.url is None
        assert c.auth.type == "none"

    def test_http_with_url(self):
        c = MCPServerConfig(transport="streamable_http", url="http://localhost:8080")
        assert c.transport == "streamable_http"
        assert c.url == "http://localhost:8080"

    def test_invalid_transport_rejected(self):
        with pytest.raises(ValidationError):
            MCPServerConfig(transport="grpc")  # type: ignore[arg-type]


class TestCustomToolParam:
    def test_defaults(self):
        p = CustomToolParam(name="file")
        assert p.type == "string"
        assert p.description == ""
        assert p.required is True
        assert p.default is None

    def test_integer_type(self):
        p = CustomToolParam(name="count", type="integer", default=5)
        assert p.type == "integer"
        assert p.default == 5


class TestCustomToolConfig:
    def test_minimal(self):
        c = CustomToolConfig(id="lint", name="Lint", description="Run linter", command="ruff check .")
        assert c.timeout == 30
        assert c.requires_approval is False
        assert c.parameters == []
        assert c.working_directory is None

    def test_with_params(self):
        c = CustomToolConfig(
            id="deploy", name="Deploy", description="Deploy app", command="deploy.sh",
            requires_approval=True,
            parameters=[CustomToolParam(name="env", type="string", required=True)],
        )
        assert c.requires_approval is True
        assert len(c.parameters) == 1


class TestSkillConfig:
    def test_defaults(self):
        s = SkillConfig(id="debug", name="Debugger", description="Debug code", prompt_path="/prompts/debug.md")
        assert s.tools == []

    def test_with_tool_configs(self):
        tool = CustomToolConfig(id="lint", name="Lint", description="d", command="echo")
        s = SkillConfig(id="debug", name="Debugger", description="d", prompt_path="/p.md", tools=[tool])
        assert len(s.tools) == 1
        assert s.tools[0].id == "lint"


class TestRoleConfig:
    def test_defaults(self):
        r = RoleConfig(id="dev", name="Developer", prompt_path="/prompts/dev.md")
        assert r.tools == []
        assert r.skills == []


class TestUserProjectConfig:
    def test_minimal(self):
        c = UserProjectConfig(git_root="/home/user/project", name="My Project")
        assert c.prompt_path is None
        assert c.mcp_servers == {}
        assert c.tools == []
        assert c.skills == []
        assert c.roles == []

    def test_with_mcp_server(self):
        c = UserProjectConfig(
            git_root="/project", name="P",
            mcp_servers={"gh": MCPServerConfig(command="gh-mcp")},
        )
        assert "gh" in c.mcp_servers
        assert c.mcp_servers["gh"].command == "gh-mcp"


class TestUserConfig:
    def test_defaults(self):
        c = UserConfig()
        assert c.db_path == Path.home() / ".agents" / "hypergolicV4.db"
        assert c.prompt_path == Path.home() / ".agents" / "PROMPT.md"
        assert c.mcp_servers == {}
        assert c.tools == []
        assert c.skills == []
        assert c.roles == []
        assert c.projects == []

    def test_custom_db_path(self):
        c = UserConfig(db_path=Path("/tmp/test.db"))
        assert c.db_path == Path("/tmp/test.db")


class TestProjectConfig:
    def test_defaults(self):
        c = ProjectConfig()
        assert c.name == ""
        assert c.prompt_path == ".agents/PROMPT.md"
        assert c.mcp_servers == {}
        assert c.tools == []
        assert c.skills == []
        assert c.roles == []

    def test_round_trip_from_dict(self):
        data = {
            "name": "hypergolic",
            "tools": [{
                "id": "validate",
                "name": "Validate",
                "description": "Run checks",
                "command": "bin/validate",
            }],
        }
        c = ProjectConfig.model_validate(data)
        assert c.name == "hypergolic"
        assert len(c.tools) == 1
        assert c.tools[0].id == "validate"
