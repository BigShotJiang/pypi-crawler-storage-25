import json
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session as SASession

from hypergolic.analytics.router import _compute_cost
from hypergolic.db.models import Base


class TestComputeCost:
    def test_high_tier(self):
        cost = _compute_cost(1_000_000, 1_000_000, 1_000_000, 1_000_000, "High")
        expected = 5.0 + 25.0 + 6.25 + 0.50
        assert cost == pytest.approx(expected)

    def test_low_tier(self):
        cost = _compute_cost(1_000_000, 1_000_000, 0, 0, "Low")
        expected = 1.0 + 5.0
        assert cost == pytest.approx(expected)

    def test_medium_tier(self):
        cost = _compute_cost(2_000_000, 500_000, 0, 0, "Medium")
        expected = (2_000_000 / 1_000_000) * 3.0 + (500_000 / 1_000_000) * 15.0
        assert cost == pytest.approx(expected)

    def test_unknown_tier_defaults_to_high(self):
        cost = _compute_cost(1_000_000, 0, 0, 0, "Unknown")
        assert cost == pytest.approx(5.0)

    def test_zero_tokens(self):
        cost = _compute_cost(0, 0, 0, 0, "High")
        assert cost == 0.0


def _create_test_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return engine


def _seed_data(engine, now=None):
    if now is None:
        now = datetime.now(timezone.utc)
    with engine.connect() as conn:
        conn.execute(text(
            "INSERT INTO projects (id, name, path, created_at, updated_at) VALUES (:id, :name, :path, :ca, :ua)"
        ), {"id": "proj1", "name": "TestProject", "path": "/tmp/test", "ca": now.isoformat(), "ua": now.isoformat()})

        conn.execute(text(
            "INSERT INTO projects (id, name, path, created_at, updated_at) VALUES (:id, :name, :path, :ca, :ua)"
        ), {"id": "proj2", "name": "OtherProject", "path": "/tmp/other", "ca": now.isoformat(), "ua": now.isoformat()})

        conn.execute(text(
            "INSERT INTO sessions (id, model_tier, system_prompt, role, status, project_id, created_at, updated_at) "
            "VALUES (:id, :tier, :sp, :role, :status, :pid, :ca, :ua)"
        ), {
            "id": "s1", "tier": "High", "sp": "[]", "role": "default",
            "status": "idle", "pid": "proj1",
            "ca": now.isoformat(), "ua": now.isoformat(),
        })

        yesterday = now - timedelta(days=1)
        conn.execute(text(
            "INSERT INTO sessions (id, model_tier, system_prompt, role, status, project_id, created_at, updated_at) "
            "VALUES (:id, :tier, :sp, :role, :status, :pid, :ca, :ua)"
        ), {
            "id": "s2", "tier": "Low", "sp": "[]", "role": "default",
            "status": "idle", "pid": "proj1",
            "ca": yesterday.isoformat(), "ua": yesterday.isoformat(),
        })

        conn.execute(text(
            "INSERT INTO sessions (id, model_tier, system_prompt, role, status, project_id, created_at, updated_at) "
            "VALUES (:id, :tier, :sp, :role, :status, :pid, :ca, :ua)"
        ), {
            "id": "s3", "tier": "Medium", "sp": "[]", "role": "default",
            "status": "idle", "pid": "proj2",
            "ca": now.isoformat(), "ua": now.isoformat(),
        })

        usage1 = json.dumps({
            "input_tokens": 1000, "output_tokens": 500,
            "cache_creation_input_tokens": 200, "cache_read_input_tokens": 100,
        })
        content_with_tool = json.dumps([
            {"type": "text", "text": "hello"},
            {"type": "tool_use", "id": "t1", "name": "read_files", "input": {}},
            {"type": "tool_use", "id": "t2", "name": "search_files", "input": {}},
        ])
        conn.execute(text(
            "INSERT INTO messages (id, content, session_id, model, role, usage, truncated, created_at, updated_at) "
            "VALUES (:id, :content, :sid, :model, :role, :usage, :trunc, :ca, :ua)"
        ), {
            "id": "m1", "content": content_with_tool, "sid": "s1",
            "model": "claude-3", "role": "assistant", "usage": usage1, "trunc": False,
            "ca": now.isoformat(), "ua": now.isoformat(),
        })

        usage2 = json.dumps({
            "input_tokens": 500, "output_tokens": 250,
            "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        })
        conn.execute(text(
            "INSERT INTO messages (id, content, session_id, model, role, usage, truncated, created_at, updated_at) "
            "VALUES (:id, :content, :sid, :model, :role, :usage, :trunc, :ca, :ua)"
        ), {
            "id": "m2", "content": '[]', "sid": "s2",
            "model": "claude-3", "role": "assistant", "usage": usage2, "trunc": False,
            "ca": yesterday.isoformat(), "ua": yesterday.isoformat(),
        })

        content_tool2 = json.dumps([
            {"type": "tool_use", "id": "t3", "name": "read_files", "input": {}},
        ])
        conn.execute(text(
            "INSERT INTO messages (id, content, session_id, model, role, usage, truncated, created_at, updated_at) "
            "VALUES (:id, :content, :sid, :model, :role, :usage, :trunc, :ca, :ua)"
        ), {
            "id": "m3", "content": content_tool2, "sid": "s3",
            "model": "claude-3", "role": "assistant", "usage": usage2, "trunc": False,
            "ca": now.isoformat(), "ua": now.isoformat(),
        })

        # user message (should not count for tool usage)
        conn.execute(text(
            "INSERT INTO messages (id, content, session_id, model, role, usage, truncated, created_at, updated_at) "
            "VALUES (:id, :content, :sid, :model, :role, :usage, :trunc, :ca, :ua)"
        ), {
            "id": "m4", "content": '[{"type": "text", "text": "hi"}]', "sid": "s1",
            "model": None, "role": "user", "usage": None, "trunc": False,
            "ca": now.isoformat(), "ua": now.isoformat(),
        })

        conn.commit()
    return now


@contextmanager
def _mock_db(engine):
    with SASession(engine) as session:
        with session.begin():
            yield session


class TestSummaryEndpoint:
    def test_all_projects(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_summary
            result = get_summary(project_id=None, days=None)

        assert result.total_sessions == 3
        assert result.total_messages == 3
        assert result.total_input_tokens == 2000
        assert result.total_output_tokens == 1000
        assert result.total_cache_write_tokens == 200
        assert result.total_cache_read_tokens == 100
        assert result.total_cost > 0

    def test_filter_by_project(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_summary
            result = get_summary(project_id="proj1", days=None)

        assert result.total_sessions == 2
        assert result.total_messages == 2
        assert result.total_input_tokens == 1500

    def test_filter_by_days(self):
        engine = _create_test_db()
        now = datetime.now(timezone.utc)
        _seed_data(engine, now)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_summary
            # sessions created within last 0.5 days (should exclude yesterday's session)
            result = get_summary(project_id=None, days=0)

        assert result.total_sessions == 0

    def test_empty_db(self):
        engine = _create_test_db()

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_summary
            result = get_summary(project_id=None, days=None)

        assert result.total_sessions == 0
        assert result.total_cost == 0.0


class TestTimeseriesEndpoint:
    def test_daily_granularity(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_timeseries
            result = get_timeseries(project_id=None, days=None, granularity="day")

        assert len(result) >= 1
        total_sessions = sum(pt.sessions for pt in result)
        assert total_sessions == 3

    def test_weekly_granularity(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_timeseries
            result = get_timeseries(project_id=None, days=None, granularity="week")

        assert len(result) >= 1

    def test_monthly_granularity(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_timeseries
            result = get_timeseries(project_id=None, days=None, granularity="month")

        assert len(result) >= 1

    def test_filter_by_project(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_timeseries
            result = get_timeseries(project_id="proj2", days=None, granularity="day")

        total_sessions = sum(pt.sessions for pt in result)
        assert total_sessions == 1


class TestToolUsageEndpoint:
    def test_returns_tool_counts(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_tool_usage
            result = get_tool_usage(project_id=None, days=None)

        by_name = {tc.tool_name: tc.count for tc in result}
        assert by_name["read_files"] == 2
        assert by_name["search_files"] == 1

    def test_filter_by_project(self):
        engine = _create_test_db()
        _seed_data(engine)

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_tool_usage
            result = get_tool_usage(project_id="proj1", days=None)

        by_name = {tc.tool_name: tc.count for tc in result}
        assert by_name.get("read_files") == 1
        assert by_name.get("search_files") == 1

    def test_empty_db(self):
        engine = _create_test_db()

        with patch("hypergolic.analytics.router.get_db", lambda: _mock_db(engine)):
            from hypergolic.analytics.router import get_tool_usage
            result = get_tool_usage(project_id=None, days=None)

        assert result == []
