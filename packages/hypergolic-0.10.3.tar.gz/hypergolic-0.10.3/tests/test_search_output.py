import subprocess

from tests.helpers import text_of

from hypergolic.tools.search_files import SearchFilesInput, _format_result, MAX_LINE_LENGTH


def _make_result(stdout: str, returncode: int = 0) -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(args=["rg"], returncode=returncode, stdout=stdout, stderr="")


def _default_input(**kwargs) -> SearchFilesInput:
    return SearchFilesInput(pattern="test", **kwargs)


class TestSearchLineTruncation:
    def test_short_lines_unchanged(self):
        stdout = "file.py:1:short line\nfile.py:2:another"
        output = _format_result(_make_result(stdout), _default_input())
        text = text_of(output.content[0])
        assert "short line" in text
        assert "another" in text
        assert "truncated" not in text.lower()

    def test_long_line_gets_truncated(self):
        long_line = "file.py:1:" + "x" * (MAX_LINE_LENGTH + 100)
        output = _format_result(_make_result(long_line), _default_input())
        text = text_of(output.content[0])
        lines = text.strip().split("\n")
        result_line = [ln for ln in lines if ln.startswith("file.py")][0]
        assert len(result_line) < len(long_line)
        assert "line truncated" in result_line.lower()

    def test_truncation_preserves_file_path_and_line_number(self):
        long_line = "src/app.js:42:" + "a" * (MAX_LINE_LENGTH + 500)
        output = _format_result(_make_result(long_line), _default_input())
        text = text_of(output.content[0])
        assert "src/app.js:42:" in text

    def test_mixed_short_and_long_lines(self):
        short = "file.py:1:normal line"
        long = "file.py:2:" + "z" * (MAX_LINE_LENGTH + 200)
        stdout = f"{short}\n{long}"
        output = _format_result(_make_result(stdout), _default_input())
        text = text_of(output.content[0])
        assert "normal line" in text
        assert "line truncated" in text.lower()

    def test_context_separator_not_truncated(self):
        stdout = "file.py:1:short\n--\nfile.py:5:other"
        output = _format_result(_make_result(stdout), _default_input())
        text = text_of(output.content[0])
        assert "--" in text

    def test_files_only_lines_not_truncated(self):
        long_path = "a/" * 300 + "file.py"
        output = _format_result(_make_result(long_path), _default_input(files_only=True))
        text = text_of(output.content[0])
        assert long_path in text

    def test_no_matches_not_affected(self):
        result = subprocess.CompletedProcess(args=["rg"], returncode=1, stdout="", stderr="")
        output = _format_result(result, _default_input())
        text = text_of(output.content[0])
        assert "No matches" in text
