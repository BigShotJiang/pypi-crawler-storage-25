import asyncio

import pytest
from pathlib import Path

from tests.helpers import text_of, make_ctx

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.delete_files import DeleteFilesInput, delete_files


@pytest.fixture
def session(tmp_path: Path) -> Session:
    return Session(
        id="s1", model_tier=ModelTier.HIGH,
        project_id="p1", project_path=str(tmp_path), role="default",
    )


class TestDeleteFiles:
    def test_delete_existing_file(self, tmp_path: Path, session: Session):
        f = tmp_path / "doomed.txt"
        f.write_text("bye")
        result = asyncio.run(delete_files(DeleteFilesInput(paths=[str(f)]), make_ctx(session)))
        assert "Deleted" in text_of(result.content[0])
        assert not f.exists()
        assert result.is_error is False

    def test_file_not_found(self, tmp_path: Path, session: Session):
        result = asyncio.run(delete_files(
            DeleteFilesInput(paths=[str(tmp_path / "nope.txt")]), make_ctx(session)
        ))
        assert "not found" in text_of(result.content[0]).lower()
        assert result.is_error is True

    def test_directory_rejected(self, tmp_path: Path, session: Session):
        d = tmp_path / "adir"
        d.mkdir()
        result = asyncio.run(delete_files(DeleteFilesInput(paths=[str(d)]), make_ctx(session)))
        assert "directory" in text_of(result.content[0]).lower()
        assert result.is_error is True

    def test_multiple_files(self, tmp_path: Path, session: Session):
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        f1.write_text("a")
        f2.write_text("b")
        result = asyncio.run(delete_files(
            DeleteFilesInput(paths=[str(f1), str(f2)]), make_ctx(session)
        ))
        assert len(result.content) == 2
        assert not f1.exists()
        assert not f2.exists()

    def test_empty_paths(self, session: Session):
        result = asyncio.run(delete_files(DeleteFilesInput(paths=[]), make_ctx(session)))
        assert "No file paths" in text_of(result.content[0])

    def test_mixed_success_and_error(self, tmp_path: Path, session: Session):
        f = tmp_path / "good.txt"
        f.write_text("x")
        result = asyncio.run(delete_files(
            DeleteFilesInput(paths=[str(f), str(tmp_path / "bad.txt")]),
            make_ctx(session),
        ))
        assert result.is_error is True
        assert "Deleted" in text_of(result.content[0])
        assert "not found" in text_of(result.content[1]).lower()

    def test_relative_path(self, tmp_path: Path, session: Session):
        f = tmp_path / "rel.txt"
        f.write_text("x")
        result = asyncio.run(delete_files(DeleteFilesInput(paths=["rel.txt"]), make_ctx(session)))
        assert "Deleted" in text_of(result.content[0])
        assert not f.exists()
