import asyncio
from unittest.mock import patch

from pydantic import BaseModel

from hypergolic.config.schemas import (
    WorkflowConfig,
    WorkflowOutputSchema,
    WorkflowStateConfig,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.activate_workflow import (
    _handle_activate_workflow,
    build_activate_workflow_tool,
)
from hypergolic.tools.schemas import ToolContext
from tests.helpers import make_ctx


def _make_workflow(**overrides) -> WorkflowConfig:
    return WorkflowConfig(
        id=overrides.get("id", "test-wf"),
        name=overrides.get("name", "Test Workflow"),
        description=overrides.get("description", "A test workflow"),
        initial_state="start",
        states=[
            WorkflowStateConfig(
                id="start",
                name="Start",
                output_schemas=[
                    WorkflowOutputSchema(
                        outcome="success",
                        schema={"type": "object", "properties": {"result": {"type": "string"}}},
                        next_state=None,
                    ),
                ],
            ),
        ],
    )


def _make_session() -> Session:
    return Session(
        id="test-session",
        model_tier=ModelTier.HIGH,
        project_id="test-project",
        project_path="/tmp/test",
        role="default",
    )


class TestBuildActivateWorkflowTool:
    @patch("hypergolic.tools.activate_workflow.resolve_workflows")
    def test_returns_none_when_no_workflows(self, mock_resolve):
        mock_resolve.return_value = []
        result = build_activate_workflow_tool()
        assert result is None

    @patch("hypergolic.tools.activate_workflow.resolve_workflows")
    def test_returns_tool_with_enum_input(self, mock_resolve):
        mock_resolve.return_value = [_make_workflow(), _make_workflow(id="wf2", name="WF2", description="Second")]
        tool = build_activate_workflow_tool()
        assert tool is not None
        assert tool.id == "activate_workflow"
        schema = tool.input.model_json_schema()
        assert "workflow_id" in schema["properties"]

    @patch("hypergolic.tools.activate_workflow.resolve_workflows")
    def test_description_lists_workflows(self, mock_resolve):
        mock_resolve.return_value = [_make_workflow()]
        tool = build_activate_workflow_tool()
        assert tool is not None
        assert "test-wf" in tool.description
        assert "A test workflow" in tool.description

    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_hidden_when_workflow_active(self, mock_get_session_wf):
        mock_get_session_wf.return_value = ("test-wf", "start")
        result = build_activate_workflow_tool(session_id="session-1")
        assert result is None

    @patch("hypergolic.tools.activate_workflow.resolve_workflows")
    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_shown_when_no_active_workflow(self, mock_get_session_wf, mock_resolve):
        mock_get_session_wf.return_value = None
        mock_resolve.return_value = [_make_workflow()]
        result = build_activate_workflow_tool(session_id="session-1")
        assert result is not None


class TestHandleActivateWorkflow:
    @patch("hypergolic.workflows.engine.activate_workflow")
    @patch("hypergolic.tools.activate_workflow.get_workflow_config")
    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_success(self, mock_get_session_wf, mock_get_wf, mock_activate):
        mock_get_session_wf.return_value = None
        wf = _make_workflow()
        mock_get_wf.return_value = wf
        mock_activate.return_value = None  # coroutine

        class FakeInput(BaseModel):
            workflow_id: str

        session = _make_session()
        result = asyncio.run(_handle_activate_workflow(FakeInput(workflow_id="test-wf"), make_ctx(session)))
        assert not result.is_error
        assert "activated" in result.content[0]["text"]  # type: ignore[index]

    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_already_active(self, mock_get_session_wf):
        mock_get_session_wf.return_value = ("existing-wf", "some-state")

        class FakeInput(BaseModel):
            workflow_id: str

        session = _make_session()
        result = asyncio.run(_handle_activate_workflow(FakeInput(workflow_id="test-wf"), make_ctx(session)))
        assert result.is_error
        assert "already has active" in result.content[0]["text"]  # type: ignore[index]

    @patch("hypergolic.tools.activate_workflow.get_workflow_config")
    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_not_found(self, mock_get_session_wf, mock_get_wf):
        mock_get_session_wf.return_value = None
        mock_get_wf.return_value = None

        class FakeInput(BaseModel):
            workflow_id: str

        session = _make_session()
        result = asyncio.run(_handle_activate_workflow(FakeInput(workflow_id="nope"), make_ctx(session)))
        assert result.is_error
        assert "not found" in result.content[0]["text"]  # type: ignore[index]

    @patch("hypergolic.workflows.engine.activate_workflow")
    @patch("hypergolic.tools.activate_workflow.get_workflow_config")
    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_broadcast_called_on_activation(self, mock_get_session_wf, mock_get_wf, mock_activate):
        mock_get_session_wf.return_value = None
        wf = _make_workflow()
        mock_get_wf.return_value = wf

        from unittest.mock import AsyncMock
        from hypergolic.messages.types import BroadcastEvent

        broadcast = AsyncMock()

        async def _fake_activate(session, wf_id, bc):
            await bc(BroadcastEvent(
                type="workflow_state_change",
                role="system",
                content=[{
                    "workflow_id": "test-wf",
                    "workflow_state_id": "start",
                    "workflow_state_name": "Start",
                }],
                session_id=session.id,
            ))

        mock_activate.side_effect = _fake_activate

        class FakeInput(BaseModel):
            workflow_id: str

        session = _make_session()
        ctx = ToolContext(session=session, broadcast=broadcast, tool_id="activate_workflow")
        result = asyncio.run(_handle_activate_workflow(FakeInput(workflow_id="test-wf"), ctx))
        assert not result.is_error
        broadcast.assert_called_once()
        event = broadcast.call_args[0][0]
        assert event.content[0]["workflow_id"] == "test-wf"
        assert event.content[0]["workflow_state_id"] == "start"

    @patch("hypergolic.workflows.engine.activate_workflow")
    @patch("hypergolic.tools.activate_workflow.get_workflow_config")
    @patch("hypergolic.tools.activate_workflow.get_session_workflow")
    def test_workflow_error_returns_error_output(self, mock_get_session_wf, mock_get_wf, mock_activate):
        mock_get_session_wf.return_value = None
        wf = _make_workflow()
        mock_get_wf.return_value = wf

        from hypergolic.workflows.engine import WorkflowError
        mock_activate.side_effect = WorkflowError("initial state not found")

        class FakeInput(BaseModel):
            workflow_id: str

        session = _make_session()
        result = asyncio.run(_handle_activate_workflow(FakeInput(workflow_id="test-wf"), make_ctx(session)))
        assert result.is_error
        assert "initial state not found" in result.content[0]["text"]  # type: ignore[index]
