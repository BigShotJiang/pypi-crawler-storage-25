import pytest
from typing import Any
from unittest.mock import MagicMock

from anthropic.types import (
    Message,
    TextBlock,
    ToolUseBlock,
    Usage,
)
from anthropic import APIStatusError

from hypergolic.messages.conversation import (
    _build_interrupt_tool_results,
    _is_retryable_status,
)
from hypergolic.messages.types import UserInterrupt


def _content(result: Any) -> list[Any]:
    return list(result["content"])


class TestBuildInterruptToolResults:
    def _make_message(self, content: list[Any]) -> Message:
        return Message(
            id="msg_1",
            type="message",
            role="assistant",
            model="claude-sonnet-4-20250514",
            content=content,
            stop_reason="tool_use",
            stop_sequence=None,
            usage=Usage(input_tokens=10, output_tokens=5),
        )

    def test_no_tool_blocks_returns_none(self):
        msg = self._make_message([TextBlock(type="text", text="hello")])
        assert _build_interrupt_tool_results(msg) is None

    def test_single_tool_block(self):
        msg = self._make_message([
            ToolUseBlock(type="tool_use", id="tu_1", name="read_files", input={}),
        ])
        result = _build_interrupt_tool_results(msg)
        assert result is not None
        assert result["role"] == "user"
        blocks = _content(result)
        assert len(blocks) == 1
        assert blocks[0]["tool_use_id"] == "tu_1"
        assert blocks[0]["is_error"] is True

    def test_multiple_tool_blocks(self):
        msg = self._make_message([
            TextBlock(type="text", text="doing stuff"),
            ToolUseBlock(type="tool_use", id="tu_1", name="read_files", input={}),
            ToolUseBlock(type="tool_use", id="tu_2", name="write_files", input={}),
        ])
        result = _build_interrupt_tool_results(msg)
        assert result is not None
        blocks = _content(result)
        assert len(blocks) == 2
        assert blocks[0]["tool_use_id"] == "tu_1"
        assert blocks[1]["tool_use_id"] == "tu_2"

    def test_interrupt_content_says_interrupted(self):
        msg = self._make_message([
            ToolUseBlock(type="tool_use", id="tu_1", name="cmd", input={}),
        ])
        result = _build_interrupt_tool_results(msg)
        assert result is not None
        blocks = _content(result)
        inner_content = list(blocks[0]["content"])
        text = inner_content[0]["text"]
        assert "interrupted" in text.lower()


class TestIsRetryableStatus:
    @pytest.mark.parametrize("status_code", [429, 500, 502, 503, 529])
    def test_retryable_codes(self, status_code: int):
        exc = MagicMock(spec=APIStatusError)
        exc.status_code = status_code
        assert _is_retryable_status(exc) is True

    @pytest.mark.parametrize("status_code", [400, 401, 403, 404, 422])
    def test_non_retryable_codes(self, status_code: int):
        exc = MagicMock(spec=APIStatusError)
        exc.status_code = status_code
        assert _is_retryable_status(exc) is False


class TestUserInterrupt:
    def test_default_no_partial_text(self):
        exc = UserInterrupt()
        assert exc.partial_text is None

    def test_with_partial_text(self):
        exc = UserInterrupt(partial_text="partial response")
        assert exc.partial_text == "partial response"
