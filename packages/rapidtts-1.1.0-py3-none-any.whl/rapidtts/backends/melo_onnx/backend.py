# -*- encoding: utf-8 -*-
# @Author: SWHL
# @Contact: liekkaskono@163.com
from pathlib import Path
from typing import Any, Dict, Optional, Union

import numpy as np

from ...common.errors import BackendNotLoadedError
from ...core.backend import BaseTTSBackend
from ...core.request import SynthesisRequest
from ...core.response import SynthesisResponse
from ...core.typings import TextNormalizerType, TTSLanguage
from .model import MeloONNXConfig, MeloONNXModel
from .postprocess import MeloONNXPostprocessor
from .preprocess import MeloONNXPreprocessor
from .typings import MeloONNXInput


class MeloONNXBackend(BaseTTSBackend):
    def __init__(
        self,
        model_root_dir: Union[str, Path],
        device: str = "cpu",
        request_defaults: Optional[Dict[str, Any]] = None,
        text_normalizer_type: str = "wetext",
    ) -> None:
        self.request_defaults = request_defaults or {}

        self.model_root_dir = Path(model_root_dir)
        tts_model_path = self.model_root_dir / "tts_model.onnx"
        self.model = MeloONNXModel(
            MeloONNXConfig(model_path=str(tts_model_path), device=device)
        )

        self.preprocessor = MeloONNXPreprocessor(
            self.model_root_dir,
            text_normalizer_type=TextNormalizerType(text_normalizer_type),
        )
        self.postprocessor = MeloONNXPostprocessor()

    def infer(self, model_inputs: list[MeloONNXInput]) -> list[np.ndarray]:
        return self.model.speak(model_inputs)

    def preprocess(self, request: SynthesisRequest):
        if self.preprocessor is None:
            raise BackendNotLoadedError("MeloONNXBackend is not loaded")

        if request.language is None:
            request.language = self.language

        return self.preprocessor.run(request)

    def postprocess(self, audio_list, sample_rate, speed) -> SynthesisResponse:
        if self.postprocessor is None:
            raise BackendNotLoadedError("MeloONNXBackend is not loaded")

        return self.postprocessor.run(audio_list, sample_rate, speed)

    def synthesize(self, request: SynthesisRequest) -> SynthesisResponse:
        request = self.normalize_request(request)
        return super().synthesize(request)

    def normalize_request(self, request: SynthesisRequest) -> SynthesisRequest:
        defaults = self.request_defaults
        extras = {
            "sdp_ratio": defaults["sdp_ratio"],
            "noise_scale": defaults["noise_scale"],
            "noise_scale_w": defaults["noise_scale_w"],
            **request.extras,
        }

        return SynthesisRequest(
            text=request.text,
            language=request.language or TTSLanguage(defaults["language"]),
            speed=request.speed if request.speed is not None else defaults["speed"],
            sample_rate=(
                request.sample_rate
                if request.sample_rate is not None
                else defaults["sample_rate"]
            ),
            audio_format=request.audio_format or defaults["audio_format"],
            extras=extras,
        )
