import getpass
import os
import re
import sys
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any

from rich.console import Console, Group
from rich.control import Control
from rich.live import Live
from rich.markup import escape
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TextColumn,
    TimeElapsedColumn,
)
from rich.rule import Rule
from rich.syntax import Syntax
from rich.text import Text

from . import task_db
from .proc import Proc
from .types import FAILED_STATES, SUCCEEDED_STATES, LogIssueRule, ProcState


@dataclass
class LogChunk:
    """Represents a chunk of log output with line number information."""

    content: str  # The actual log content (may contain newlines)
    start_line: int  # Line number where chunk starts (1-indexed)
    end_line: int  # Line number where chunk ends (1-indexed)


class Displayable:
    def __init__(self, proc: Proc):
        self.proc = proc
        self.chunks: list[LogChunk] = []  # Log chunks to display for proc
        self.completed = False
        self.start_time: float | None = None
        self.task_id: TaskID | None = None  # Rich Progress task ID
        self.execution_time: str = ""  # Execution time string for completed tasks
        self.expected_duration: float | None = None  # Seconds; set when task DB has history

    # Get number of lines to display for item
    def height(self) -> int:
        return 1 + sum(chunk.end_line - chunk.start_line + 1 for chunk in self.chunks)


# Match ANSI SGR sequences (e.g. \x1b[31m or \033[1;31m)
_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[;\d]*[A-Za-z]")


def _has_ansi_color(text: str) -> bool:
    """Return True if text contains ANSI color/formatting escape sequences."""
    return bool(_ANSI_ESCAPE_RE.search(text))


def _get_error_type_message(disp: Displayable) -> str:
    """Short message for error type when task failed; empty when succeeded or still running."""
    if disp.proc.state == ProcState.SKIPPED:
        return " skipped"
    if disp.proc.state == ProcState.UP_TO_DATE:
        return " up-to-date"
    if disp.proc.state in SUCCEEDED_STATES:
        return ""
    if disp.proc.state == ProcState.FAILED_DEP:
        return " dependency failed"
    if disp.proc.state not in FAILED_STATES:
        return ""  # IDLE, WANTED, RUNNING: no error message
    # ProcState.FAILED with error code
    err = getattr(disp.proc, "error", None)
    if err == Proc.ERROR_TIMEOUT:
        return " timeout"
    if err == Proc.ERROR_EXCEPTION:
        return " exception"
    if err == Proc.ERROR_FAILED:
        return " failed"
    if err == Proc.ERROR_NOT_PICKLEABLE:
        return " not pickleable"
    if err == Proc.ERROR_OUTPUTS_NOT_REFRESHED:
        return " outputs not refreshed"
    return " failed"


def _proc_name_markup(proc: Proc) -> str:
    """Escaped proc name with terminal file link when *log_filename* is set."""
    name_escaped = escape(proc.name or "")
    if proc.log_filename:
        abs_path = os.path.abspath(proc.log_filename)
        return f"[link=file://{abs_path}]{name_escaped}[/link]"
    return name_escaped


def _format_completed_line_markup(disp: Displayable) -> str:
    """Return markup string for one completed task line (for live area or print)."""
    if disp.proc.state == ProcState.UP_TO_DATE:
        status = "[bold green]↷[/bold green]"  # up-to-date (auto-skipped)
    elif disp.proc.state == ProcState.SKIPPED:
        status = "[bold yellow]⊘[/bold yellow]"  # skipped
    elif disp.proc.state == ProcState.SUCCEEDED:
        status = "[bold green]✓[/bold green]"
    elif disp.proc.state == ProcState.FAILED_DEP:
        status = "[bold red]🚫[/bold red]"
    else:
        status = "[bold red]✗[/bold red]"
    name_part = _proc_name_markup(disp.proc)
    time_escaped = escape(disp.execution_time)
    err_msg = _get_error_type_message(disp)
    err_escaped = escape(err_msg)
    return f"{status} {name_part}{time_escaped}{err_escaped}"


# Base class for terminal display. Use TermSimple or TermDynamic.
class Term:

    updatePeriod = 0.1  # Seconds between each update
    context_lines = 2  # Number of lines before and after keyword matches to include

    def __init__(self) -> None:
        self.active: OrderedDict[Proc, Displayable] = OrderedDict()
        self.inactive: list[Displayable] = []
        self.last_update: float = 0.0
        self.console = Console()
        self.progress: Progress | None = None
        self.live: Live | None = None
        self.show_full_log_on_failure = False

    def clear(self) -> None:
        """Reset display state (e.g. when ProcManager.clear() starts a new session)."""
        if self.live is not None:
            self.live.stop()
            self.live = None
        self.progress = None
        self.active = OrderedDict()
        self.inactive = []

    def cleanup_on_interrupt(self) -> None:
        """Restore terminal state on SIGINT/SIGTERM (e.g. show cursor, stop Live). Override in TermDynamic."""

    def start_proc(self, p: Proc) -> None:
        """Called when a process starts. Override in subclasses."""
        raise NotImplementedError

    def end_proc(self, p: Proc) -> None:
        """Called when a process ends. Override in subclasses."""
        raise NotImplementedError

    def _ensure_progress(self) -> None:
        """Initialize Progress and Live display if needed. No-op in TermSimple."""

    def update(self, force: bool = False) -> None:
        """Refresh display. Override in subclasses."""

    def get_input(self, message: str, password: bool) -> str:
        """Get input from user. Override in subclasses."""
        self.console.print(message)
        if password:
            return getpass.getpass()
        return sys.stdin.readline()

    def event(self, message: str) -> None:
        """Print a watch/runtime event line to console output."""
        self.console.print(f'[bold cyan]![/bold cyan] {message}')

    def _get_description(self, proc: Proc) -> str:
        """Rich markup for progress row: linked proc name (same as completed lines) plus optional more_info."""
        base = _proc_name_markup(proc)
        if proc.more_info:
            return f"{base} - {escape(proc.more_info)}"
        return base

    def completed_proc(self, p: Proc) -> None:
        self.start_proc(p)
        self.end_proc(p)

    def _print_completed_task(self, disp: Displayable) -> None:
        """Print a single completed task to the console (scrollback). Not part of the live update area."""
        self.console.print(_format_completed_line_markup(disp))
        self._print_completed_task_log_panels([disp])

    def _log_panel_for_disp(self, disp: Displayable) -> Any:
        """Build the log panel renderable for a displayable that has chunks. Returns None if no chunks.
        Uses top/bottom rules only (no side borders) so the block stretches full width and wraps on resize.
        If content contains ANSI color codes, renders with those colors; otherwise uses Syntax highlighting.
        """
        if not disp.chunks:
            return None
        chunk_parts = [chunk.content for chunk in disp.chunks]
        log_content_str = "\n\n".join(chunk_parts)
        is_bug = disp.proc.state in FAILED_STATES
        border_style = "red" if is_bug else "yellow"
        link_bg_style = "bold white on dark_red" if is_bug else "bold black on yellow"
        log_content: Any
        if _has_ansi_color(log_content_str):
            log_content = Text.from_ansi(log_content_str)
        else:
            lexer = "python" if disp.proc.state in FAILED_STATES else "text"
            log_content = Syntax(
                log_content_str,
                lexer=lexer,
                theme="monokai",
                line_numbers=False,
                word_wrap=True,
                background_color="default",
            )
        parts: list[Any] = [
            Rule(style=border_style),
            log_content,
            Rule(style=border_style),
        ]
        if disp.proc.log_filename:
            abs_path = os.path.abspath(disp.proc.log_filename)
            filename_escaped = escape(disp.proc.log_filename)
            title = Text.from_markup(f"[link=file://{abs_path} {link_bg_style}]{filename_escaped}[/link]")
            parts.insert(1, title)
        return Group(*parts)

    def _print_completed_task_log_panels(self, disps: list[Displayable]) -> None:
        """Print log panels for displayables that have chunks (failed task output). Skipped/up-to-date tasks get no panel."""
        for disp in disps:
            if disp.proc.state in (ProcState.SKIPPED, ProcState.UP_TO_DATE):
                continue
            panel = self._log_panel_for_disp(disp)
            if panel is not None:
                self.console.print(panel)

    def _render_display(self) -> Any:
        """Render only the live-updated area. Override in TermDynamic."""
        return ""

    def _render_proc_static(self, disp: Displayable) -> None:
        """Render a process in static (non-dynamic) mode."""
        if disp.proc.state == ProcState.UP_TO_DATE:
            status = "[bold green]↷[/bold green]"  # up-to-date
        elif disp.proc.state == ProcState.SKIPPED:
            status = "[bold yellow]⊘[/bold yellow]"  # skipped
        elif disp.proc.state == ProcState.SUCCEEDED:
            status = "[bold green]✓[/bold green]"
        elif disp.proc.state == ProcState.FAILED_DEP:
            status = "[bold red]🚫[/bold red]"
        elif disp.proc.state in FAILED_STATES:
            status = "[bold red]✗[/bold red]"
        else:
            status = "[yellow]•[/yellow]"

        more_info = disp.proc.more_info
        if disp.proc.state in FAILED_STATES:
            if more_info == '':
                more_info = f'logfile: {disp.proc.log_filename}'

        if more_info != '':
            more_info = ' - ' + more_info

        err_msg = _get_error_type_message(disp)
        line = f'{status} {_proc_name_markup(disp.proc)}{escape(more_info)}{escape(err_msg)}'
        self.console.print(Text.from_markup(line))

        if disp.chunks:
            for chunk in disp.chunks:
                self.console.print(f'  --- lines {chunk.start_line}-{chunk.end_line} ---')
                for line in chunk.content.split('\n'):
                    self.console.print(f'  {line}')

    @staticmethod
    def _active_log_ignore_patterns(
        log_ignore: list[str | LogIssueRule] | None, *, task_succeeded: bool
    ) -> list[re.Pattern[str]]:
        if not log_ignore:
            return []
        active_patterns: list[re.Pattern[str]] = []
        for rule in log_ignore:
            if isinstance(rule, str):
                active_patterns.append(re.compile(rule))
                continue
            if rule.applies(task_succeeded=task_succeeded):
                active_patterns.append(re.compile(rule.pattern))
        return active_patterns

    @staticmethod
    def _line_is_ignored(line: str, patterns: list[re.Pattern[str]]) -> bool:
        return any(pattern.search(line) for pattern in patterns)

    @staticmethod
    def _filter_text_lines(text: str, patterns: list[re.Pattern[str]]) -> str:
        if not patterns:
            return text
        filtered_lines = [line for line in text.split('\n') if not Term._line_is_ignored(line, patterns)]
        return '\n'.join(filtered_lines)

    @staticmethod
    def extract_error_log(
        text: str,
        task_failed: bool,
        full_log_on_failure: bool = False,
        log_ignore: list[str | LogIssueRule] | None = None,
        task_succeeded: bool = False,
    ) -> list[LogChunk]:
        """
        Extract relevant log chunks from text.

        Args:
            text: The full log text
            task_failed: Whether the task failed (if True, MUST return at least one chunk)
            log_ignore: Optional regex-based line ignore rules applied before extraction.
            task_succeeded: Whether the task ended in a success state (used by conditional ignore rules).

        Returns:
            List of LogChunk objects with content and line number ranges
        """
        lines = text.split('\n')
        total_lines = len(lines)
        chunks: list[LogChunk] = []
        ignore_patterns = Term._active_log_ignore_patterns(log_ignore, task_succeeded=task_succeeded)

        if task_failed and full_log_on_failure:
            filtered_text = Term._filter_text_lines(text, ignore_patterns)
            if filtered_text.strip():
                return [LogChunk(content=filtered_text, start_line=1, end_line=total_lines)]
            return [LogChunk(content=text, start_line=1, end_line=total_lines)]

        # If task failed, try parsers first
        if task_failed:
            parsers = [
                (
                    'python.sh-full',  # For when e.stderr is available
                    re.compile(r'^.*(RAN:.*STDOUT:.*STDERR:).*STDERR_FULL:(.*)$', re.DOTALL),
                    lambda m: f'  {m.group(1)}{m.group(2)}',
                ),
                ('python.sh', re.compile(r'^.*(RAN:.*STDOUT:.*STDERR:.*)$', re.DOTALL), lambda m: f'  {m.group(1)}'),
            ]

            # Find the matching parser
            for _, reg, output in parsers:
                m = re.match(reg, text)
                if m:
                    # Match with parser - return as single chunk
                    content = Term._filter_text_lines(output(m), ignore_patterns)
                    if not content.strip():
                        break
                    # Estimate line numbers (approximate based on content position)
                    # For parser matches, we'll use the full range since we matched the whole text
                    return [LogChunk(content=content, start_line=1, end_line=total_lines)]

        # Search for keywords in the log (convert to lowercase for matching)
        keywords = ['exception', 'error', 'warning', 'notice', 'deprecated', 'deprecation']
        visible_lines = [
            (line_idx, line)
            for line_idx, line in enumerate(lines, start=1)
            if not Term._line_is_ignored(line, ignore_patterns)
        ]

        # Find line numbers where keywords appear
        cutout_ranges: list[tuple[int, int]] = []  # List of (start_line, end_line) ranges

        for keyword in keywords:
            for line_idx, line in visible_lines:
                if keyword in line.lower():
                    # Add range: line number ± context_lines
                    start = max(1, line_idx - Term.context_lines)
                    end = min(total_lines, line_idx + Term.context_lines)
                    cutout_ranges.append((start, end))

        # Merge overlapping ranges
        if cutout_ranges:
            # Sort by start line
            cutout_ranges.sort(key=lambda x: x[0])
            merged: list[tuple[int, int]] = []
            for start, end in cutout_ranges:
                if merged and start <= merged[-1][1] + 1:  # Overlapping or adjacent
                    # Merge with previous range
                    merged[-1] = (merged[-1][0], max(merged[-1][1], end))
                else:
                    merged.append((start, end))
            cutout_ranges = merged

        # Extract chunks from cutout ranges
        if cutout_ranges:
            for start, end in cutout_ranges:
                # Extract lines (convert back to 0-indexed for list access)
                chunk_lines = [
                    line
                    for line_idx, line in enumerate(lines[start - 1 : end], start=start)
                    if not Term._line_is_ignored(line, ignore_patterns)
                ]
                if not chunk_lines:
                    continue
                content = '\n'.join(chunk_lines)
                chunks.append(LogChunk(content=content, start_line=start, end_line=end))
        elif task_failed:
            # If task failed but no keywords found, grab bottom 16 lines
            # (MUST output something if task failed)
            visible_tail = visible_lines[-16:]
            if visible_tail:
                start = visible_tail[0][0]
                end = visible_tail[-1][0]
                content = '\n'.join(line for _, line in visible_tail)
                chunks.append(LogChunk(content=content, start_line=start, end_line=end))
            else:
                # Fallback: avoid rendering an empty panel when all lines were ignored.
                start = max(1, total_lines - 15)  # -15 because we want 16 lines total
                end = total_lines
                chunk_lines = lines[start - 1 : end]
                content = '\n'.join(chunk_lines)
                chunks.append(LogChunk(content=content, start_line=start, end_line=end))
        # If task didn't fail and no keywords found, return empty list

        return chunks


class TermSimple(Term):
    """Static terminal display: one line per task, no live updates."""

    def start_proc(self, p: Proc) -> None:
        disp = Displayable(p)
        disp.start_time = time.time()
        self.active[p] = disp
        self._render_proc_static(disp)

    def end_proc(self, p: Proc) -> None:
        if p not in self.active:
            return
        disp = self.active[p]
        disp.completed = True
        if disp.proc.log_filename != '':
            with open(disp.proc.log_filename, encoding='utf-8') as f:
                log_text = f.read()
            task_failed = disp.proc.state in FAILED_STATES and disp.proc.state != ProcState.SKIPPED
            disp.chunks = Term.extract_error_log(
                log_text,
                task_failed,
                full_log_on_failure=self.show_full_log_on_failure,
                log_ignore=disp.proc.log_ignore,
                task_succeeded=disp.proc.state in SUCCEEDED_STATES,
            )
        self._render_proc_static(disp)
        del self.active[p]


class TermDynamic(Term):
    """Dynamic terminal display: live progress bars and in-place updates."""

    def _start_live(self) -> None:
        """Create and start a new Live display for the current progress state."""
        self.live = Live(
            self._render_display(),
            refresh_per_second=10,
            console=self.console,
            vertical_overflow="visible",
            transient=True,
        )
        self.live.start()

    def _stop_live(self) -> None:
        """Stop the Live display if running."""
        if self.live is not None:
            self.live.stop()
            self.live = None

    def _ensure_progress(self) -> None:
        if self.progress is None:
            self.progress = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TimeElapsedColumn(),
                console=self.console,
                transient=False,
            )
            self._start_live()

    def start_proc(self, p: Proc) -> None:
        disp = Displayable(p)
        disp.start_time = time.time()
        self.active[p] = disp
        self._ensure_progress()
        if self.progress is not None:
            description = self._get_description(p)
            expected = task_db.get_expected_duration(p.name) if task_db.get_current() and p.name is not None else None
            if expected is not None and expected > 0:
                disp.expected_duration = expected
                task_id = self.progress.add_task(description, total=expected)
            else:
                disp.expected_duration = None
                task_id = self.progress.add_task(description, total=None)
            disp.task_id = task_id
            if self.live is not None:
                self.live.update(self._render_display())

    def end_proc(self, p: Proc) -> None:
        if p not in self.active:
            return
        disp = self.active[p]
        disp.completed = True
        if disp.proc.log_filename != '':
            with open(disp.proc.log_filename, encoding='utf-8') as f:
                log_text = f.read()
            task_failed = disp.proc.state in FAILED_STATES and disp.proc.state != ProcState.SKIPPED
            disp.chunks = Term.extract_error_log(
                log_text,
                task_failed,
                full_log_on_failure=self.show_full_log_on_failure,
                log_ignore=disp.proc.log_ignore,
                task_succeeded=disp.proc.state in SUCCEEDED_STATES,
            )
        if disp.start_time is not None:
            elapsed = time.time() - disp.start_time
            disp.execution_time = f" ({elapsed:.2f}s)"
        else:
            disp.execution_time = ""
        if self.progress is not None and disp.task_id is not None:
            self.progress.remove_task(disp.task_id)
        del self.active[p]
        # Print completed task while Live is active. Rich's render hook
        # atomically positions the text above the live area, so no
        # blank-line artifacts from stop/restart cycles.
        # Don't stop Live here even if active is empty -- more tasks may
        # start (deps now met) before the next update() call. update()
        # handles the final cleanup.
        self._print_completed_task(disp)

    def update(self, force: bool = False) -> None:
        if force or time.time() - self.last_update > Term.updatePeriod:
            self.last_update = time.time()
            if self.progress is not None:
                for proc, disp in self.active.items():
                    if disp.task_id is not None and not disp.completed:
                        description = self._get_description(proc)
                        if disp.expected_duration is not None and disp.start_time is not None:
                            elapsed = time.time() - disp.start_time
                            # Cap at 99% while running so we never show "stuck at 100%"
                            # when a task runs longer than its expected duration
                            completed = min(elapsed, disp.expected_duration * 0.99)
                            self.progress.update(
                                disp.task_id,
                                description=description,
                                completed=completed,
                                refresh=True,
                            )
                        else:
                            self.progress.update(disp.task_id, description=description, refresh=True)
            if self.live is not None:
                if len(self.active) > 0:
                    self.live.update(self._render_display())
                else:
                    self.progress = None
                    self._stop_live()
            elif len(self.active) > 0:
                self._ensure_progress()

    def get_input(self, message: str, password: bool) -> str:
        self._stop_live()
        self.console.print(message)
        if password:
            result = getpass.getpass()
        else:
            result = sys.stdin.readline()
        if len(self.active) > 0:
            if self.progress is None:
                self._ensure_progress()
            else:
                self._start_live()
        return result

    def cleanup_on_interrupt(self) -> None:
        """Restore terminal state on SIGINT/SIGTERM: stop Live and show cursor."""
        self._stop_live()
        self.console.print(Control.show_cursor(True))

    def _render_display(self) -> Any:
        # Completed lines (inactive) + their log panels + progress bar (active tasks) in one live area
        parts: list[Any] = []
        for disp in self.inactive:
            parts.append(Text.from_markup(_format_completed_line_markup(disp)))
            panel = self._log_panel_for_disp(disp)
            if panel is not None:
                parts.append(panel)
        if self.progress is not None:
            parts.append(self.progress)
        if not parts:
            return ""
        return Group(*parts)
