from setuptools import setup; setup(name='pinterest-teletraan', version='0.0.1')
