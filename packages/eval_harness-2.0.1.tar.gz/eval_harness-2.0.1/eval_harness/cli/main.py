from __future__ import annotations

import click

from eval_harness.cli.commands.compare import compare as compare_command
from eval_harness.cli.commands.drift import drift as drift_command
from eval_harness.cli.commands.inspect import inspect as inspect_command
from eval_harness.cli.commands.promote import promote as promote_command
from eval_harness.cli.commands.re_evaluate import re_evaluate as re_evaluate_command
from eval_harness.cli.commands.run import run as run_command


@click.group()
@click.version_option(package_name="eval-harness", prog_name="evalh")
def cli() -> None:
    """evalh — config-driven harness for evaluating AI systems."""


cli.add_command(run_command)
cli.add_command(inspect_command)
cli.add_command(re_evaluate_command)
cli.add_command(compare_command)
cli.add_command(promote_command)
cli.add_command(drift_command)


if __name__ == "__main__":
    cli()
