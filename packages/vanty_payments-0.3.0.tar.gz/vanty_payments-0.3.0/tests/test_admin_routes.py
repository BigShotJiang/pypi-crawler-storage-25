from __future__ import annotations

from decimal import Decimal
from typing import Any

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient, Response

from vanty_payments.db.models import BillingAccount, ProductConfig, StripeProduct

pytestmark = pytest.mark.integration


class _StubRegistry:
    def __init__(self, payments_app):
        self._app = payments_app

    def has(self, label: str) -> bool:
        return label == "payments"

    def get(self, label: str):
        if label != "payments":
            raise KeyError(label)
        return self._app


def build_admin_app(payments_app) -> FastAPI:
    app = FastAPI()
    app.include_router(payments_app.admin_router, prefix="/admin")
    app.state.registry = _StubRegistry(payments_app)
    return app


async def api_request(app: FastAPI, method: str, path: str, **kwargs: Any) -> Response:
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        return await client.request(method, path, **kwargs)


async def seed_product(payments_app, stripe_id: str = "prod_ar_1"):
    await payments_app.sync_service.sync_product(
        {
            "id": stripe_id,
            "object": "product",
            "name": "Admin Route Product",
            "active": True,
            "description": "Test product",
            "default_price": None,
            "livemode": False,
            "created": 1_700_000_800,
            "metadata": {},
        }
    )
    return await StripeProduct.filter(stripe_id=stripe_id).first()


# ------------------------------------------------------------------
# Product config routes
# ------------------------------------------------------------------


async def test_list_products_empty(payments_app):
    app = build_admin_app(payments_app)
    response = await api_request(app, "GET", "/admin/products")
    assert response.status_code == 200
    assert response.json() == []


async def test_list_products_with_config(payments_app):
    app = build_admin_app(payments_app)
    product = await seed_product(payments_app)
    await ProductConfig.create(product=product, show_in_ui=True)
    response = await api_request(app, "GET", "/admin/products")
    assert response.status_code == 200
    assert len(response.json()) == 1


async def test_update_product_config_route(payments_app):
    app = build_admin_app(payments_app)
    product = await seed_product(payments_app, stripe_id="prod_ar_upd")
    config = await ProductConfig.create(product=product, show_in_ui=False, weight=1)
    response = await api_request(
        app, "POST", f"/admin/products/{config.pk}",
        json={"show_in_ui": True, "weight": 8},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["show_in_ui"] is True
    assert data["weight"] == 8


async def test_update_product_config_not_found(payments_app):
    import uuid

    app = build_admin_app(payments_app)
    response = await api_request(
        app, "POST", f"/admin/products/{uuid.uuid4()}",
        json={"show_in_ui": True},
    )
    assert response.status_code == 404


async def test_sync_products_from_stripe_route(payments_app, monkeypatch):
    app = build_admin_app(payments_app)
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "list_objects",
        lambda object_type, **kw: [
            {
                "id": "prod_ar_sync",
                "object": "product",
                "name": "Synced",
                "active": True,
                "description": "",
                "default_price": None,
                "livemode": False,
                "created": 1_700_000_801,
                "metadata": {},
            }
        ],
    )
    response = await api_request(app, "POST", "/admin/products/sync-from-stripe")
    assert response.status_code == 200
    assert response.json()["total"] == 1


# ------------------------------------------------------------------
# Meter routes
# ------------------------------------------------------------------


async def test_meter_crud_routes(payments_app):
    app = build_admin_app(payments_app)

    create_resp = await api_request(
        app, "POST", "/admin/meters",
        json={
            "event_name": "route_meter",
            "display_name": "Route Meter",
            "pricing_strategy": "margin",
            "margin_multiplier": "1.5",
        },
    )
    assert create_resp.status_code == 200
    meter_id = create_resp.json()["id"]

    list_resp = await api_request(app, "GET", "/admin/meters")
    assert list_resp.status_code == 200
    assert any(m["id"] == meter_id for m in list_resp.json())

    get_resp = await api_request(app, "GET", f"/admin/meters/{meter_id}")
    assert get_resp.status_code == 200
    assert get_resp.json()["event_name"] == "route_meter"

    patch_resp = await api_request(
        app, "PATCH", f"/admin/meters/{meter_id}",
        json={"display_name": "Updated"},
    )
    assert patch_resp.status_code == 200
    assert patch_resp.json()["display_name"] == "Updated"

    del_resp = await api_request(app, "DELETE", f"/admin/meters/{meter_id}")
    assert del_resp.status_code == 200
    assert del_resp.json()["message"] == "Meter deleted"


async def test_get_meter_not_found(payments_app):
    import uuid

    app = build_admin_app(payments_app)
    response = await api_request(app, "GET", f"/admin/meters/{uuid.uuid4()}")
    assert response.status_code == 404


# ------------------------------------------------------------------
# Credit grant route
# ------------------------------------------------------------------


async def test_admin_credit_grant_route(payments_app):
    app = build_admin_app(payments_app)
    account = await BillingAccount.create(
        user_reference="user_ar_credits",
        organization_reference="org_ar_credits",
    )
    response = await api_request(
        app, "POST", "/admin/credits/grant",
        json={
            "billing_account_id": str(account.pk),
            "amount": "250.00",
            "description": "Admin route grant",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["entry_type"] == "admin_grant"
    assert Decimal(data["amount"]) == Decimal("250.00")


# ------------------------------------------------------------------
# Integration status route
# ------------------------------------------------------------------


async def test_integration_status_route(payments_app):
    app = build_admin_app(payments_app)
    response = await api_request(app, "GET", "/admin/integration-status")
    assert response.status_code == 200
    data = response.json()
    assert data["stripe_configured"] is True
