import pytest

from vanty_payments.settings import PaymentsSettings

pytestmark = pytest.mark.unit


def test_settings_default_to_test_mode():
    settings = PaymentsSettings()

    assert settings.stripe_mode == "test"
    assert settings.livemode is False


def test_settings_prefers_live_key_in_live_mode():
    settings = PaymentsSettings(
        stripe_mode="live",
        stripe_test_secret_key="sk_test_example",
        stripe_live_secret_key="sk_live_example",
    )

    assert settings.livemode is True
    assert settings.stripe_secret_key == "sk_live_example"


def test_settings_falls_back_to_live_key_when_test_key_missing():
    settings = PaymentsSettings(
        stripe_mode="test",
        stripe_test_secret_key="",
        stripe_live_secret_key="sk_live_example",
    )

    assert settings.stripe_secret_key == "sk_live_example"


def test_settings_billing_config_defaults():
    settings = PaymentsSettings()

    assert settings.billing_usage_mode == "internal"
    assert settings.billing_credits_enabled is False
    assert settings.credit_factor == 100
    assert settings.stripe_trial_period_days == 14
    assert settings.stripe_automatic_tax_enabled is True
    assert settings.stripe_cancel_at_period_end is True
    assert settings.billing_event_routing == {}
