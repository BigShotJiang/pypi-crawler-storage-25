from __future__ import annotations

from datetime import UTC, datetime

import pytest

from vanty_payments.core.utils import as_dict, stripe_id_from, ts_to_datetime, utcnow

pytestmark = pytest.mark.unit


class RecursiveObject:
    def to_dict_recursive(self) -> dict[str, str]:
        return {"id": "recursive"}


class PlainObject:
    def to_dict(self) -> dict[str, str]:
        return {"id": "plain"}


class IdObject:
    id = "object_id"


def test_utcnow_returns_timezone_aware_datetime():
    assert utcnow().tzinfo == UTC


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (None, {}),
        ({"id": "dict"}, {"id": "dict"}),
        (RecursiveObject(), {"id": "recursive"}),
        (PlainObject(), {"id": "plain"}),
        ([("id", "pairs")], {"id": "pairs"}),
    ],
)
def test_as_dict_handles_supported_inputs(value, expected):
    assert as_dict(value) == expected


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (None, None),
        ("cus_123", "cus_123"),
        ({"id": "cus_dict"}, "cus_dict"),
        (IdObject(), "object_id"),
    ],
)
def test_stripe_id_from_handles_supported_inputs(value, expected):
    assert stripe_id_from(value) == expected


def test_ts_to_datetime_handles_none_and_empty_string():
    assert ts_to_datetime(None) is None
    assert ts_to_datetime("") is None


def test_ts_to_datetime_handles_datetime_variants_and_timestamps():
    naive = datetime(2024, 1, 1, 12, 0, 0)
    aware = datetime(2024, 1, 1, 12, 0, 0, tzinfo=UTC)

    assert ts_to_datetime(naive) == naive.replace(tzinfo=UTC)
    assert ts_to_datetime(aware) == aware
    assert ts_to_datetime(1_700_000_000) == datetime.fromtimestamp(1_700_000_000, tz=UTC)
    assert ts_to_datetime("invalid") is None
