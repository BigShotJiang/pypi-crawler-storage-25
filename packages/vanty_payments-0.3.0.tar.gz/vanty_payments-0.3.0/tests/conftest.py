from __future__ import annotations

from pathlib import Path

import pytest_asyncio
from fastapi import FastAPI
from vanty_core.apps import AppRegistry

from vanty_payments.apps import PaymentsApp
from vanty_payments.settings import PaymentsSettings


@pytest_asyncio.fixture
async def payments_setup(tmp_path: Path):
    settings = PaymentsSettings(
        stripe_test_secret_key="sk_test_example",
        stripe_webhook_secret="whsec_example",
    )
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'payments.db'}")
    app = registry.install(PaymentsApp(settings=settings))
    fake = FastAPI()
    async with registry.lifespan(fake):
        yield registry, app


@pytest_asyncio.fixture
async def payments_app(payments_setup):
    _, app = payments_setup
    yield app


@pytest_asyncio.fixture
async def payments_registry(payments_setup):
    registry, _ = payments_setup
    yield registry
