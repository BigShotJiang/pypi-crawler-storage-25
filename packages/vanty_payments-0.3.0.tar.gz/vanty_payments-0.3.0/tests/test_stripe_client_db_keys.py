from __future__ import annotations

import pytest

from vanty_payments.core.stripe_client import StripeClient
from vanty_payments.settings import PaymentsSettings

pytestmark = pytest.mark.unit


def make_client(**overrides) -> StripeClient:
    settings = PaymentsSettings(
        stripe_test_secret_key="sk_test_env",
        stripe_live_secret_key="sk_live_env",
        stripe_webhook_secret="whsec_env",
        **overrides,
    )
    return StripeClient(settings)


def test_resolve_uses_env_when_no_db_keys():
    client = make_client(stripe_mode="test")
    assert client._resolve_secret_key() == "sk_test_env"

    client_live = make_client(stripe_mode="live")
    assert client_live._resolve_secret_key() == "sk_live_env"


def test_db_keys_take_precedence_over_env():
    client = make_client(stripe_mode="test")
    client.load_db_keys({"stripe_test_secret_key": "sk_test_db"})

    assert client._resolve_secret_key() == "sk_test_db"


def test_db_live_key_precedence_in_live_mode():
    client = make_client(stripe_mode="live")
    client.load_db_keys({"stripe_live_secret_key": "sk_live_db"})

    assert client._resolve_secret_key() == "sk_live_db"


def test_explicit_livemode_override():
    client = make_client(stripe_mode="test")
    client.load_db_keys({
        "stripe_test_secret_key": "sk_test_db",
        "stripe_live_secret_key": "sk_live_db",
    })

    assert client._resolve_secret_key(livemode=True) == "sk_live_db"
    assert client._resolve_secret_key(livemode=False) == "sk_test_db"


def test_fallback_when_db_key_empty():
    client = make_client(stripe_mode="test")
    client.load_db_keys({"stripe_test_secret_key": ""})

    assert client._resolve_secret_key() == "sk_test_env"


def test_webhook_secret_db_first():
    client = make_client()
    assert client._resolve_webhook_secret() == "whsec_env"

    client.load_db_keys({"stripe_webhook_secret": "whsec_db"})
    assert client._resolve_webhook_secret() == "whsec_db"


def test_load_db_keys_replaces_previous():
    client = make_client(stripe_mode="test")
    client.load_db_keys({"stripe_test_secret_key": "sk_first"})
    assert client._resolve_secret_key() == "sk_first"

    client.load_db_keys({"stripe_test_secret_key": "sk_second"})
    assert client._resolve_secret_key() == "sk_second"


def test_request_kwargs_uses_resolved_key():
    client = make_client(stripe_mode="test")
    client.load_db_keys({"stripe_test_secret_key": "sk_test_db"})

    kwargs = client._request_kwargs()
    assert kwargs["api_key"] == "sk_test_db"
