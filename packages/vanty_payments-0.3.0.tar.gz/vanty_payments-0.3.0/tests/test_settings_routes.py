from __future__ import annotations

from typing import Any

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient, Response

pytestmark = pytest.mark.integration


class _StubRegistry:
    def __init__(self, payments_app):
        self._app = payments_app

    def has(self, label: str) -> bool:
        return label == "payments"

    def get(self, label: str):
        if label != "payments":
            raise KeyError(label)
        return self._app


def build_admin_app(payments_app) -> FastAPI:
    app = FastAPI()
    app.include_router(payments_app.admin_router, prefix="/admin")
    app.state.registry = _StubRegistry(payments_app)
    return app


async def api_request(app: FastAPI, method: str, path: str, **kwargs: Any) -> Response:
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        return await client.request(method, path, **kwargs)


async def test_list_settings_empty(payments_app):
    app = build_admin_app(payments_app)
    response = await api_request(app, "GET", "/admin/settings")
    assert response.status_code == 200
    assert response.json() == []


async def test_upsert_and_list_settings(payments_app):
    app = build_admin_app(payments_app)

    put_resp = await api_request(
        app, "PUT", "/admin/settings",
        json={"key": "stripe_test_secret_key", "value": "sk_test_abc123xyz"},
    )
    assert put_resp.status_code == 200
    data = put_resp.json()
    assert data["key"] == "stripe_test_secret_key"
    assert data["is_secret"] is True
    assert data["value"] == "sk_t...3xyz"

    list_resp = await api_request(app, "GET", "/admin/settings")
    assert list_resp.status_code == 200
    assert len(list_resp.json()) == 1


async def test_get_setting_by_key(payments_app):
    app = build_admin_app(payments_app)
    await payments_app.settings_service.upsert_setting("stripe_publishable_key", "pk_test_vis")

    resp = await api_request(app, "GET", "/admin/settings/stripe_publishable_key")
    assert resp.status_code == 200
    data = resp.json()
    assert data["value"] == "pk_test_vis"
    assert data["is_secret"] is False


async def test_get_setting_not_found(payments_app):
    app = build_admin_app(payments_app)
    resp = await api_request(app, "GET", "/admin/settings/nonexistent")
    assert resp.status_code == 404


async def test_delete_setting_route(payments_app):
    app = build_admin_app(payments_app)
    await payments_app.settings_service.upsert_setting("stripe_test_secret_key", "sk_test_del")

    resp = await api_request(app, "DELETE", "/admin/settings/stripe_test_secret_key")
    assert resp.status_code == 200
    assert resp.json()["message"] == "Setting deleted"

    resp2 = await api_request(app, "DELETE", "/admin/settings/stripe_test_secret_key")
    assert resp2.status_code == 404


async def test_upsert_reloads_stripe_client_keys(payments_app):
    app = build_admin_app(payments_app)
    assert payments_app.context.stripe_client._db_keys.get("stripe_test_secret_key") is None

    await api_request(
        app, "PUT", "/admin/settings",
        json={"key": "stripe_test_secret_key", "value": "sk_test_reloaded"},
    )
    assert payments_app.context.stripe_client._db_keys.get("stripe_test_secret_key") == "sk_test_reloaded"


async def test_test_connection_no_key(payments_app):
    from vanty_payments.settings import PaymentsSettings

    kit_no_key = payments_app
    kit_no_key.settings = PaymentsSettings(
        stripe_test_secret_key="",
        stripe_live_secret_key="",
    )
    kit_no_key.context.stripe_client.settings = kit_no_key.settings
    kit_no_key.context.stripe_client._db_keys = {}

    app = build_admin_app(kit_no_key)
    resp = await api_request(app, "POST", "/admin/settings/test-connection")
    assert resp.status_code == 200
    data = resp.json()
    assert data["valid"] is False
    assert "No Stripe secret key" in data["error"]
