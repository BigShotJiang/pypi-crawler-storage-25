from __future__ import annotations

import pytest
from fastapi import FastAPI
from vanty_core.apps import AppRegistry

pytestmark = pytest.mark.integration


async def test_reload_db_keys_populates_stripe_client(payments_app):
    await payments_app.settings_service.upsert_setting("stripe_test_secret_key", "sk_test_reload")
    await payments_app.reload_db_keys()

    assert payments_app.context.stripe_client._db_keys["stripe_test_secret_key"] == "sk_test_reload"


async def test_registry_startup_loads_db_keys(tmp_path):
    from vanty_payments.apps import PaymentsApp
    from vanty_payments.settings import PaymentsSettings

    settings = PaymentsSettings(stripe_test_secret_key="sk_test_env")
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'init_test.db'}")
    payments_app = registry.install(PaymentsApp(settings=settings))
    fake = FastAPI()
    async with registry.lifespan(fake):
        await payments_app.settings_service.upsert_setting("stripe_test_secret_key", "sk_test_from_db")
        await payments_app.reload_db_keys()

        assert payments_app.context.stripe_client._resolve_secret_key() == "sk_test_from_db"


async def test_reload_db_keys_returns_empty_when_no_setting_present(tmp_path):
    from vanty_payments.apps import PaymentsApp
    from vanty_payments.settings import PaymentsSettings

    settings = PaymentsSettings(stripe_test_secret_key="sk_test_env")
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'noop.db'}")
    payments_app = registry.install(PaymentsApp(settings=settings))
    fake = FastAPI()
    async with registry.lifespan(fake):
        assert payments_app.context.stripe_client._db_keys == {}
