from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


async def test_subscription_sync_backfills_missing_customer(payments_app, monkeypatch):
    def fake_retrieve_object(object_type: str, stripe_id: str):
        if object_type == "subscription":
            return {
                "id": stripe_id,
                "object": "subscription",
                "customer": "cus_missing",
                "status": "active",
                "currency": "usd",
                "items": {"data": []},
                "livemode": False,
                "created": 1_700_000_300,
                "metadata": {},
            }
        if object_type == "customer":
            return {
                "id": stripe_id,
                "object": "customer",
                "email": "backfill@example.com",
                "name": "Backfill Customer",
                "invoice_settings": {"default_payment_method": None},
                "livemode": False,
                "created": 1_700_000_301,
                "metadata": {},
            }
        raise AssertionError(f"unexpected retrieve_object call: {object_type} {stripe_id}")

    monkeypatch.setattr(payments_app.context.stripe_client, "retrieve_object", fake_retrieve_object)

    subscription = await payments_app.sync_object("subscription", "sub_backfill")
    customer = await payments_app.get_customer(stripe_customer_id="cus_missing")

    assert subscription is not None
    assert customer is not None
    assert subscription.customer_stripe_id == customer.stripe_id
