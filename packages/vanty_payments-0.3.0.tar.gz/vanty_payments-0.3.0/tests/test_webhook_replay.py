from __future__ import annotations

from uuid import UUID

import pytest
from fastapi import HTTPException

from vanty_payments.db.models import StripeWebhookDelivery

pytestmark = pytest.mark.integration


async def test_webhook_replay_reconstructs_event_when_event_record_is_missing(payments_app, monkeypatch):
    event = {
        "id": "evt_replay",
        "object": "event",
        "type": "customer.created",
        "api_version": "2020-08-27",
        "livemode": False,
        "created": 1_700_000_401,
        "request": {"id": "req_replay", "idempotency_key": "idem_replay"},
        "data": {
            "object": {
                "id": "cus_replay",
                "object": "customer",
                "email": "replay@example.com",
                "name": "Replay User",
                "invoice_settings": {"default_payment_method": None},
                "livemode": False,
                "created": 1_700_000_402,
                "metadata": {},
            }
        },
        "metadata": {},
    }

    monkeypatch.setattr(payments_app.context.stripe_client, "construct_event", lambda **kwargs: event)

    delivery = await StripeWebhookDelivery.create(
        signature="t=1,v1=replay",
        headers={"stripe-signature": "t=1,v1=replay"},
        body="{}",
    )

    replayed = await payments_app.replay_webhook(delivery.id)
    customer = await payments_app.get_customer(stripe_customer_id="cus_replay")

    assert replayed.valid is True
    assert replayed.processed is True
    assert replayed.webhook_event_stripe_id is not None
    assert customer is not None
    assert payments_app.events.list()[-1].name == "payments.webhook.replayed"


async def test_webhook_replay_raises_404_for_missing_delivery(payments_app):
    with pytest.raises(HTTPException) as exc_info:
        await payments_app.replay_webhook(UUID("d479c198-f4b2-4b1f-8e65-a9ea58b1d0b7"))

    assert exc_info.value.status_code == 404
    assert exc_info.value.detail == "Webhook delivery not found"


async def test_webhook_replay_uses_stored_webhook_event_when_present(payments_app):
    event = {
        "id": "evt_stored",
        "object": "event",
        "type": "customer.created",
        "api_version": "2020-08-27",
        "livemode": False,
        "created": 1_700_000_500,
        "request": {"id": "req_stored", "idempotency_key": "idem_stored"},
        "data": {
            "object": {
                "id": "cus_stored",
                "object": "customer",
                "email": "stored@example.com",
                "name": "Stored User",
                "invoice_settings": {"default_payment_method": None},
                "livemode": False,
                "created": 1_700_000_501,
                "metadata": {},
            }
        },
        "metadata": {},
    }
    webhook_event = await payments_app.sync_service.sync_event(event)
    delivery = await StripeWebhookDelivery.create(
        signature="t=1,v1=stored",
        headers={"stripe-signature": "t=1,v1=stored"},
        body="{}",
        valid=True,
        processed=True,
        webhook_event_stripe_id=webhook_event.stripe_id,
    )

    replayed = await payments_app.replay_webhook(delivery.id)

    assert replayed.valid is True
    assert replayed.processed is True
    assert replayed.webhook_event_stripe_id == webhook_event.stripe_id
