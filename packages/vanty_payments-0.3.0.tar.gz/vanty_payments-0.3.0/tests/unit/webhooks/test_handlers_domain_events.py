"""WebhookHandlerRegistry publishes domain events for Stripe payloads."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from vanty_payments.db.models import StripeCustomer
from vanty_payments.webhooks.handlers import WebhookHandlerRegistry

pytestmark = pytest.mark.unit


async def _customer(organization_id, stripe_id: str):
    return await StripeCustomer.create(
        stripe_id=stripe_id,
        email="buyer@example.com",
        organization_reference=str(organization_id),
    )


@pytest.mark.asyncio
@patch("vanty_payments.webhooks.handlers.publish", new_callable=AsyncMock)
async def test_checkout_completed_publishes(mock_pub, payments_app):
    oid = uuid4()
    await _customer(oid, "cus_co")
    reg = WebhookHandlerRegistry(payments_app.sync_service, billing_service=payments_app.billing_service)
    payload = {
        "id": "cs_test_123",
        "object": "checkout.session",
        "customer": "cus_co",
        "amount_total": 2500,
        "currency": "usd",
        "metadata": {},
        "subscription": "sub_1",
    }
    await reg._handle_checkout_completed(payload)  # noqa: SLF001
    mock_pub.assert_awaited()


@pytest.mark.asyncio
@patch("vanty_payments.webhooks.handlers.publish", new_callable=AsyncMock)
async def test_subscription_handlers_publish(mock_pub, payments_app):
    oid = uuid4()
    await _customer(oid, "cus_sub")
    reg = WebhookHandlerRegistry(payments_app.sync_service, billing_service=payments_app.billing_service)
    sub_payload = {
        "id": "sub_test1",
        "object": "subscription",
        "customer": "cus_sub",
        "status": "active",
        "items": {"data": [{"price": "price_123"}]},
    }
    await reg._handle_subscription_created(sub_payload)  # noqa: SLF001
    await reg._handle_subscription_updated(sub_payload)  # noqa: SLF001
    await reg._handle_subscription_deleted(sub_payload)  # noqa: SLF001
    assert mock_pub.await_count >= 3


@pytest.mark.asyncio
@patch("vanty_payments.webhooks.handlers.publish", new_callable=AsyncMock)
async def test_invoice_handlers_publish(mock_pub, payments_app):
    oid = uuid4()
    await _customer(oid, "cus_inv")
    reg = WebhookHandlerRegistry(payments_app.sync_service, billing_service=payments_app.billing_service)
    inv = {
        "id": "in_123",
        "object": "invoice",
        "customer": "cus_inv",
        "amount_paid": 1000,
        "amount_due": 0,
        "currency": "usd",
        "billing_reason": "subscription_cycle",
    }
    await reg._handle_invoice_paid(inv)  # noqa: SLF001
    failed = {
        **inv,
        "amount_due": 999,
        "last_payment_error": {"message": "card_declined"},
    }
    await reg._handle_invoice_payment_failed(failed)  # noqa: SLF001
    assert mock_pub.await_count >= 2
