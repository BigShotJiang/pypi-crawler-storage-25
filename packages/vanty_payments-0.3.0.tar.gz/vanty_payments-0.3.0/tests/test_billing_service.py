from __future__ import annotations

from decimal import Decimal

import pytest

from vanty_payments.billing.constants import SubscriptionLifecycleState
from vanty_payments.db.models import BillingAccount, CreditLedgerEntry, Meter

pytestmark = pytest.mark.integration


async def seed_customer(payments_app, *, stripe_id: str, user_reference: str, organization_reference: str):
    return await payments_app.sync_service.sync_customer(
        {
            "id": stripe_id,
            "object": "customer",
            "email": f"{stripe_id}@example.com",
            "name": stripe_id,
            "livemode": False,
            "created": 1_700_000_300,
            "metadata": {},
            "invoice_settings": {"default_payment_method": None},
        },
        user_reference=user_reference,
        organization_reference=organization_reference,
    )


async def seed_subscription(payments_app, customer, *, sub_id: str = "sub_test"):
    return await payments_app.sync_service.sync_subscription(
        {
            "id": sub_id,
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {
                "data": [
                    {
                        "id": "si_item1",
                        "object": "subscription_item",
                        "price": {
                            "id": "price_old",
                            "object": "price",
                            "product": "prod_test",
                            "currency": "usd",
                            "unit_amount": 2900,
                            "type": "recurring",
                            "recurring": {"interval": "month", "interval_count": 1},
                            "active": True,
                            "livemode": False,
                            "created": 1_700_000_301,
                            "metadata": {},
                        },
                        "quantity": 1,
                        "livemode": False,
                        "created": 1_700_000_301,
                        "metadata": {},
                    }
                ]
            },
            "livemode": False,
            "created": 1_700_000_301,
            "metadata": {},
        }
    )


# ------------------------------------------------------------------
# Config
# ------------------------------------------------------------------


async def test_get_billing_config(payments_app):
    config = payments_app.billing_service.get_billing_config()
    assert config["billing_usage_mode"] == "internal"
    assert config["billing_credits_enabled"] is False
    assert config["credit_factor"] == 100


# ------------------------------------------------------------------
# Billing account resolution
# ------------------------------------------------------------------


async def test_resolve_billing_account_creates_new(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference="user_resolve_1",
        organization_reference="org_resolve_1",
    )
    assert account.state == SubscriptionLifecycleState.NOT_SUBSCRIBED.value
    assert account.organization_reference == "org_resolve_1"


async def test_resolve_billing_account_returns_existing(payments_app):
    a1 = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_resolve_2",
    )
    a2 = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_resolve_2",
    )
    assert a1.pk == a2.pk


# ------------------------------------------------------------------
# Summary
# ------------------------------------------------------------------


async def test_get_billing_summary_no_subscription(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_summary",
    )
    summary = await payments_app.billing_service.get_billing_summary(account)
    assert summary["is_active"] is False
    assert summary["has_subscription"] is False
    assert summary["subscription"] is None


async def test_get_billing_summary_with_subscription(payments_app):
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_summary",
        user_reference="user_summary",
        organization_reference="org_summary_sub",
    )
    await seed_subscription(payments_app, customer)
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_summary_sub",
        customer=customer,
    )
    account.state = SubscriptionLifecycleState.ACTIVE.value
    await account.save()

    summary = await payments_app.billing_service.get_billing_summary(account)
    assert summary["is_active"] is True
    assert summary["has_subscription"] is True
    assert summary["subscription"] is not None


# ------------------------------------------------------------------
# Checkout confirm
# ------------------------------------------------------------------


async def test_confirm_checkout_session(payments_app, monkeypatch):
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "retrieve_checkout_session",
        lambda session_id: {
            "id": session_id,
            "customer": "cus_confirm",
            "status": "complete",
            "payment_status": "paid",
            "subscription": "sub_from_checkout",
            "amount_total": 5000,
        },
    )
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_confirm",
    )
    result = await payments_app.billing_service.confirm_checkout_session("cs_test_confirm", account)
    assert result["state"] == "active"
    assert result["subscription_stripe_id"] == "sub_from_checkout"

    refreshed = await BillingAccount.get(pk=account.pk)
    assert refreshed.state == "active"
    assert refreshed.current_plan == "sub_from_checkout"


# ------------------------------------------------------------------
# Mutations
# ------------------------------------------------------------------


async def test_change_subscription_price(payments_app, monkeypatch):
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_change",
        user_reference="user_change",
        organization_reference="org_change",
    )
    await seed_subscription(payments_app, customer, sub_id="sub_change")
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_change",
        customer=customer,
    )

    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "modify_subscription",
        lambda sub_id, **kw: {"status": "active", "id": sub_id},
    )

    result = await payments_app.billing_service.change_subscription_price(account, "price_new")
    assert result["new_price_id"] == "price_new"
    assert result["status"] == "active"


async def test_cancel_subscription(payments_app, monkeypatch):
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_cancel",
        user_reference="user_cancel",
        organization_reference="org_cancel",
    )
    await seed_subscription(payments_app, customer, sub_id="sub_cancel")
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_cancel",
        customer=customer,
    )

    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "modify_subscription",
        lambda sub_id, **kw: {"status": "active", "cancel_at_period_end": True, "id": sub_id},
    )

    result = await payments_app.billing_service.cancel_subscription(account)
    assert result["cancel_at_period_end"] is True


async def test_reactivate_subscription(payments_app, monkeypatch):
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_reactivate",
        user_reference="user_reactivate",
        organization_reference="org_reactivate",
    )
    await seed_subscription(payments_app, customer, sub_id="sub_reactivate")
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_reactivate",
        customer=customer,
    )
    account.state = SubscriptionLifecycleState.CANCELED.value
    await account.save()

    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "modify_subscription",
        lambda sub_id, **kw: {"status": "active", "cancel_at_period_end": False, "id": sub_id},
    )

    result = await payments_app.billing_service.reactivate_subscription(account)
    assert result["cancel_at_period_end"] is False

    refreshed = await BillingAccount.get(pk=account.pk)
    assert refreshed.state == "active"


async def test_create_setup_intent(payments_app, monkeypatch):
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_setup",
        user_reference="user_setup",
        organization_reference="org_setup",
    )
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_setup",
        customer=customer,
    )

    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "create_setup_intent",
        lambda **kw: {"client_secret": "seti_secret_123", "id": "seti_123"},
    )

    result = await payments_app.billing_service.create_setup_intent(account)
    assert result["client_secret"] == "seti_secret_123"
    assert result["setup_intent_id"] == "seti_123"


# ------------------------------------------------------------------
# Usage metering
# ------------------------------------------------------------------


async def test_record_usage_without_meter(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_usage_1",
    )
    event = await payments_app.billing_service.record_usage(
        account,
        event_name="unknown_event",
        value=5,
    )
    assert event.event_name == "unknown_event"
    assert event.value == 5
    assert event.credit_cost == Decimal(0)


async def test_record_usage_with_meter(payments_app):
    await Meter.create(
        event_name="llm_call",
        display_name="LLM Call",
        pricing_strategy="fixed_per_event",
        fixed_amount=Decimal("0.05"),
    )
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_usage_2",
    )
    event = await payments_app.billing_service.record_usage(
        account,
        event_name="llm_call",
        value=3,
    )
    assert event.credit_cost == Decimal("0.15")


async def test_get_usage_summary(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_usage_summary",
    )
    await Meter.get_or_create(
        event_name="api_call",
        defaults={
            "display_name": "API Call",
            "pricing_strategy": "fixed_per_event",
            "fixed_amount": Decimal("1.0"),
        },
    )
    await payments_app.billing_service.record_usage(account, event_name="api_call", value=2)
    await payments_app.billing_service.record_usage(account, event_name="api_call", value=3)

    summary = await payments_app.billing_service.get_usage_summary(account)
    assert summary["total_events"] == 2
    assert summary["total_credit_cost"] == Decimal("5.0")


async def test_list_usage_records(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_usage_list",
    )
    await payments_app.billing_service.record_usage(account, event_name="evt_a", value=1)
    await payments_app.billing_service.record_usage(account, event_name="evt_b", value=2)

    records = await payments_app.billing_service.list_usage_records(account)
    assert len(records) == 2


# ------------------------------------------------------------------
# Credits
# ------------------------------------------------------------------


async def test_grant_credits(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_credits_1",
    )
    entry = await payments_app.billing_service.grant_credits(
        account,
        amount=Decimal("100"),
        description="Welcome credits",
        reference_id="welcome_org_credits_1",
    )
    assert entry.amount == Decimal("100")
    assert entry.entry_type == "admin_grant"


async def test_grant_credits_idempotent(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_credits_idem",
    )
    e1 = await payments_app.billing_service.grant_credits(
        account,
        amount=Decimal("50"),
        reference_id="idem_ref",
    )
    e2 = await payments_app.billing_service.grant_credits(
        account,
        amount=Decimal("50"),
        reference_id="idem_ref",
    )
    assert e1.pk == e2.pk


async def test_get_credit_balance(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_credits_balance",
    )
    await payments_app.billing_service.grant_credits(
        account, amount=Decimal("200"), reference_id="bal_1"
    )
    await CreditLedgerEntry.create(
        billing_account=account,
        entry_type="adjustment",
        amount=Decimal("-30"),
        description="Usage deduction",
    )
    balance = await payments_app.billing_service.get_credit_balance(account)
    assert balance["total_granted"] == Decimal("200")
    assert balance["total_consumed"] == Decimal("30")
    assert balance["net_balance"] == Decimal("170")


async def test_list_credit_ledger(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_credits_ledger",
    )
    await payments_app.billing_service.grant_credits(
        account, amount=Decimal("10"), reference_id="ledger_1"
    )
    await payments_app.billing_service.grant_credits(
        account, amount=Decimal("20"), reference_id="ledger_2"
    )
    entries = await payments_app.billing_service.list_credit_ledger(account)
    assert len(entries) == 2


# ------------------------------------------------------------------
# Entitlement
# ------------------------------------------------------------------


async def test_resolve_entitlement_not_subscribed(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_entitlement_1",
    )
    result = await payments_app.billing_service.resolve_entitlement(account)
    assert result["is_active"] is False
    assert result["has_subscription"] is False


async def test_record_usage_with_credits_enabled(payments_app):
    """When credits are enabled, recording usage should debit the credit ledger."""
    payments_app.settings.billing_credits_enabled = True
    try:
        await Meter.get_or_create(
            event_name="credit_usage_event",
            defaults={
                "display_name": "Credit Usage",
                "pricing_strategy": "fixed_per_event",
                "fixed_amount": Decimal("2.0"),
            },
        )
        account = await payments_app.billing_service.resolve_billing_account(
            organization_reference="org_credit_usage",
        )
        await payments_app.billing_service.grant_credits(
            account, amount=Decimal("100"), reference_id="credit_pre_usage"
        )
        event = await payments_app.billing_service.record_usage(
            account, event_name="credit_usage_event", value=5,
        )
        assert event.credit_cost == Decimal("10.0")

        balance = await payments_app.billing_service.get_credit_balance(account)
        assert balance["net_balance"] == Decimal("90.0")
    finally:
        payments_app.settings.billing_credits_enabled = False


async def test_record_usage_with_margin_strategy(payments_app):
    await Meter.get_or_create(
        event_name="margin_event",
        defaults={
            "display_name": "Margin Event",
            "pricing_strategy": "margin",
            "margin_multiplier": Decimal("2.0"),
            "cost_dimension_key": "total_cost",
        },
    )
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_margin",
    )
    event = await payments_app.billing_service.record_usage(
        account,
        event_name="margin_event",
        value=1,
        dimensions={"total_cost": "5.0"},
    )
    assert event.credit_cost == Decimal("10.0")


async def test_record_usage_with_per_unit_strategy(payments_app):
    await Meter.get_or_create(
        event_name="per_unit_event",
        defaults={
            "display_name": "Per Unit Event",
            "pricing_strategy": "per_unit",
            "unit_price": Decimal("0.001"),
        },
    )
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_per_unit",
    )
    event = await payments_app.billing_service.record_usage(
        account,
        event_name="per_unit_event",
        value=100,
    )
    assert event.credit_cost == Decimal("0.1")


async def test_record_usage_stripe_emission(payments_app, monkeypatch):
    """When billing_usage_mode is not internal, usage is emitted to Stripe."""
    payments_app.settings.billing_usage_mode = "stripe_payg"
    emitted = []
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "create_stripe_meter_event",
        lambda **kw: emitted.append(kw) or {},
    )
    try:
        customer = await seed_customer(
            payments_app,
            stripe_id="cus_emit",
            user_reference="user_emit",
            organization_reference="org_emit",
        )
        account = await payments_app.billing_service.resolve_billing_account(
            organization_reference="org_emit",
            customer=customer,
        )
        event = await payments_app.billing_service.record_usage(
            account, event_name="emit_event", value=1,
        )
        assert len(emitted) == 1
        assert event.emission_status == "sent"
    finally:
        payments_app.settings.billing_usage_mode = "internal"


async def test_record_usage_stripe_emission_failure(payments_app, monkeypatch):
    """When Stripe emission fails, event should be marked as failed."""
    payments_app.settings.billing_usage_mode = "stripe_payg"
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "create_stripe_meter_event",
        lambda **kw: (_ for _ in ()).throw(RuntimeError("Stripe error")),
    )
    try:
        customer = await seed_customer(
            payments_app,
            stripe_id="cus_emit_fail",
            user_reference="user_emit_fail",
            organization_reference="org_emit_fail",
        )
        account = await payments_app.billing_service.resolve_billing_account(
            organization_reference="org_emit_fail",
            customer=customer,
        )
        event = await payments_app.billing_service.record_usage(
            account, event_name="emit_fail_event", value=1,
        )
        assert event.emission_status == "failed"
        assert event.stripe_sync_attempts == 1
    finally:
        payments_app.settings.billing_usage_mode = "internal"


async def test_confirm_checkout_with_credits(payments_app, monkeypatch):
    payments_app.settings.billing_credits_enabled = True
    try:
        monkeypatch.setattr(
            payments_app.context.stripe_client,
            "retrieve_checkout_session",
            lambda sid: {
                "id": sid,
                "customer": "cus_confirm_credits",
                "status": "complete",
                "payment_status": "paid",
                "subscription": "sub_credits",
                "amount_total": 10000,
            },
        )
        account = await payments_app.billing_service.resolve_billing_account(
            organization_reference="org_confirm_credits",
        )
        await payments_app.billing_service.confirm_checkout_session("cs_credits", account)

        balance = await payments_app.billing_service.get_credit_balance(account)
        assert balance["total_granted"] == Decimal("100")
    finally:
        payments_app.settings.billing_credits_enabled = False


async def test_resolve_billing_account_by_user_reference(payments_app):
    a1 = await payments_app.billing_service.resolve_billing_account(
        user_reference="user_by_ref",
    )
    a2 = await payments_app.billing_service.resolve_billing_account(
        user_reference="user_by_ref",
    )
    assert a1.pk == a2.pk


async def test_resolve_billing_account_by_customer(payments_app):
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_by_cust",
        user_reference="user_by_cust",
        organization_reference="org_by_cust",
    )
    a1 = await payments_app.billing_service.resolve_billing_account(customer=customer)
    a2 = await payments_app.billing_service.resolve_billing_account(customer=customer)
    assert a1.pk == a2.pk


async def test_cancel_subscription_immediate(payments_app, monkeypatch):
    payments_app.settings.stripe_cancel_at_period_end = False
    try:
        customer = await seed_customer(
            payments_app,
            stripe_id="cus_cancel_imm",
            user_reference="user_cancel_imm",
            organization_reference="org_cancel_imm",
        )
        await seed_subscription(payments_app, customer, sub_id="sub_cancel_imm")
        account = await payments_app.billing_service.resolve_billing_account(
            organization_reference="org_cancel_imm",
            customer=customer,
        )
        monkeypatch.setattr(
            payments_app.context.stripe_client,
            "cancel_subscription",
            lambda sid, at_period_end=True: {"status": "canceled", "cancel_at_period_end": False, "id": sid},
        )
        result = await payments_app.billing_service.cancel_subscription(account)
        assert result["cancel_at_period_end"] is False
        refreshed = await BillingAccount.get(pk=account.pk)
        assert refreshed.state == SubscriptionLifecycleState.CANCELED.value
    finally:
        payments_app.settings.stripe_cancel_at_period_end = True


async def test_require_subscription_no_customer_raises(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_no_cust_sub",
    )
    with pytest.raises(ValueError, match="no linked customer"):
        await payments_app.billing_service._require_subscription(account)


async def test_require_customer_no_customer_raises(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_no_cust_req",
    )
    with pytest.raises(ValueError, match="no linked customer"):
        await payments_app.billing_service._require_customer(account)


async def test_resolve_entitlement_active(payments_app):
    account = await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_entitlement_2",
    )
    account.state = SubscriptionLifecycleState.ACTIVE.value
    account.current_plan = "sub_active_plan"
    await account.save()

    result = await payments_app.billing_service.resolve_entitlement(account)
    assert result["is_active"] is True
    assert result["has_subscription"] is True
    assert result["plan"] == "sub_active_plan"
