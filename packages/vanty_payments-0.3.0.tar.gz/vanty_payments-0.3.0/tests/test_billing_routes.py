from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient, Response

pytestmark = pytest.mark.integration

IdentityResolver = Callable[[Any], dict[str, str] | None]


class _StubRegistry:
    def __init__(self, payments_app):
        self._app = payments_app

    def has(self, label: str) -> bool:
        return label == "payments"

    def get(self, label: str):
        if label != "payments":
            raise KeyError(label)
        return self._app


def build_app(payments_app, resolver: IdentityResolver | None = None) -> FastAPI:
    app = FastAPI()
    app.include_router(payments_app.router)
    app.state.registry = _StubRegistry(payments_app)
    app.state.payments_identity_resolver = resolver
    return app


async def api_request(app: FastAPI, method: str, path: str, **kwargs: Any) -> Response:
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        return await client.request(method, path, **kwargs)


async def seed_customer(payments_app, *, stripe_id: str, user_reference: str, organization_reference: str):
    return await payments_app.sync_service.sync_customer(
        {
            "id": stripe_id,
            "object": "customer",
            "email": f"{stripe_id}@example.com",
            "name": stripe_id,
            "livemode": False,
            "created": 1_700_000_700,
            "metadata": {},
            "invoice_settings": {"default_payment_method": None},
        },
        user_reference=user_reference,
        organization_reference=organization_reference,
    )


def IDENTITY(_r):
    return {
    "user_reference": "user_route_billing",
    "organization_reference": "org_route_billing",
}


async def test_billing_config_route(payments_app):
    app = build_app(payments_app)
    response = await api_request(app, "GET", "/payments/billing/config")
    assert response.status_code == 200
    data = response.json()
    assert data["billing_usage_mode"] == "internal"
    assert data["billing_credits_enabled"] is False


async def test_billing_summary_route(payments_app):
    app = build_app(payments_app, resolver=IDENTITY)
    response = await api_request(app, "GET", "/payments/billing/summary")
    assert response.status_code == 200
    data = response.json()
    assert data["is_active"] is False
    assert data["state"] == "not_subscribed"


async def test_checkout_confirm_route(payments_app, monkeypatch):
    app = build_app(payments_app, resolver=IDENTITY)
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "retrieve_checkout_session",
        lambda sid: {
            "id": sid,
            "customer": "cus_confirm_route",
            "status": "complete",
            "payment_status": "paid",
            "subscription": "sub_confirm_route",
            "amount_total": 2900,
        },
    )
    response = await api_request(app, "POST", "/payments/checkout/sessions/cs_route_1/confirm")
    assert response.status_code == 200
    data = response.json()
    assert data["state"] == "active"
    assert data["subscription_stripe_id"] == "sub_confirm_route"


async def test_change_plan_route(payments_app, monkeypatch):
    app = build_app(payments_app, resolver=IDENTITY)
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_route_change",
        user_reference="user_route_billing",
        organization_reference="org_route_billing",
    )
    await payments_app.sync_service.sync_subscription(
        {
            "id": "sub_route_change",
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {"data": []},
            "livemode": False,
            "created": 1_700_000_701,
            "metadata": {},
        }
    )
    await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_route_billing",
        customer=customer,
    )
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "modify_subscription",
        lambda sid, **kw: {"status": "active", "id": sid},
    )
    response = await api_request(
        app, "POST", "/payments/billing/change-plan",
        json={"new_price_id": "price_new_route"},
    )
    assert response.status_code == 200
    assert response.json()["new_price_id"] == "price_new_route"


async def test_cancel_subscription_route(payments_app, monkeypatch):
    def resolver(_r):
        return {
            "user_reference": "user_route_cancel",
            "organization_reference": "org_route_cancel",
        }
    app = build_app(payments_app, resolver=resolver)
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_route_cancel",
        user_reference="user_route_cancel",
        organization_reference="org_route_cancel",
    )
    await payments_app.sync_service.sync_subscription(
        {
            "id": "sub_route_cancel",
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {"data": []},
            "livemode": False,
            "created": 1_700_000_702,
            "metadata": {},
        }
    )
    await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_route_cancel",
        customer=customer,
    )
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "modify_subscription",
        lambda sid, **kw: {"status": "active", "cancel_at_period_end": True, "id": sid},
    )
    response = await api_request(app, "POST", "/payments/billing/cancel-subscription")
    assert response.status_code == 200
    assert response.json()["cancel_at_period_end"] is True


async def test_reactivate_subscription_route(payments_app, monkeypatch):
    def resolver(_r):
        return {
            "user_reference": "user_route_react",
            "organization_reference": "org_route_react",
        }
    app = build_app(payments_app, resolver=resolver)
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_route_react",
        user_reference="user_route_react",
        organization_reference="org_route_react",
    )
    await payments_app.sync_service.sync_subscription(
        {
            "id": "sub_route_react",
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {"data": []},
            "livemode": False,
            "created": 1_700_000_703,
            "metadata": {},
        }
    )
    await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_route_react",
        customer=customer,
    )
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "modify_subscription",
        lambda sid, **kw: {"status": "active", "cancel_at_period_end": False, "id": sid},
    )
    response = await api_request(app, "POST", "/payments/billing/reactivate-subscription")
    assert response.status_code == 200
    assert response.json()["cancel_at_period_end"] is False


async def test_setup_payment_method_route(payments_app, monkeypatch):
    def resolver(_r):
        return {
            "user_reference": "user_route_seti",
            "organization_reference": "org_route_seti",
        }
    app = build_app(payments_app, resolver=resolver)
    customer = await seed_customer(
        payments_app,
        stripe_id="cus_route_seti",
        user_reference="user_route_seti",
        organization_reference="org_route_seti",
    )
    await payments_app.billing_service.resolve_billing_account(
        organization_reference="org_route_seti",
        customer=customer,
    )
    monkeypatch.setattr(
        payments_app.context.stripe_client,
        "create_setup_intent",
        lambda **kw: {"client_secret": "seti_route_secret", "id": "seti_route_1"},
    )
    response = await api_request(app, "POST", "/payments/billing/setup-payment-method")
    assert response.status_code == 200
    assert response.json()["client_secret"] == "seti_route_secret"


async def test_usage_record_route(payments_app):
    def resolver(_r):
        return {
            "user_reference": "user_route_usage",
            "organization_reference": "org_route_usage",
        }
    app = build_app(payments_app, resolver=resolver)
    response = await api_request(
        app, "POST", "/payments/billing/usage/record",
        json={"event_name": "route_event", "value": 3},
    )
    assert response.status_code == 200
    assert response.json()["event_name"] == "route_event"
    assert response.json()["value"] == 3


async def test_usage_summary_route(payments_app):
    def resolver(_r):
        return {
            "user_reference": "user_route_usm",
            "organization_reference": "org_route_usm",
        }
    app = build_app(payments_app, resolver=resolver)
    response = await api_request(app, "GET", "/payments/billing/usage/summary")
    assert response.status_code == 200
    assert "total_events" in response.json()


async def test_usage_records_route(payments_app):
    def resolver(_r):
        return {
            "user_reference": "user_route_usr",
            "organization_reference": "org_route_usr",
        }
    app = build_app(payments_app, resolver=resolver)
    response = await api_request(app, "GET", "/payments/billing/usage/records")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_credit_balance_route(payments_app):
    def resolver(_r):
        return {
            "user_reference": "user_route_cbal",
            "organization_reference": "org_route_cbal",
        }
    app = build_app(payments_app, resolver=resolver)
    response = await api_request(app, "GET", "/payments/billing/credits/balance")
    assert response.status_code == 200
    data = response.json()
    assert "net_balance" in data


async def test_credit_ledger_route(payments_app):
    def resolver(_r):
        return {
            "user_reference": "user_route_cled",
            "organization_reference": "org_route_cled",
        }
    app = build_app(payments_app, resolver=resolver)
    response = await api_request(app, "GET", "/payments/billing/credits/ledger")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
