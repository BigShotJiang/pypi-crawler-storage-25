from __future__ import annotations

from types import SimpleNamespace

import pytest

from vanty_payments.core.identity import IdentityContext, resolve_request_identity

pytestmark = pytest.mark.unit


async def test_identity_resolver_supports_host_app_adapter():
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                payments_identity_resolver=lambda _: {
                    "user_reference": "user_host",
                    "organization_reference": "org_host",
                }
            )
        )
    )

    identity = await resolve_request_identity(request)

    assert identity.user_reference == "user_host"
    assert identity.organization_reference == "org_host"


async def test_identity_resolver_supports_async_resolver():
    async def resolver(_request):
        return IdentityContext(user_reference="user_async", organization_reference="org_async")

    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(payments_identity_resolver=resolver)))

    identity = await resolve_request_identity(request)

    assert identity == IdentityContext(user_reference="user_async", organization_reference="org_async")


async def test_identity_resolver_returns_empty_context_for_none():
    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(payments_identity_resolver=lambda _: None)))

    identity = await resolve_request_identity(request)

    assert identity == IdentityContext()


async def test_identity_resolver_raises_for_invalid_type():
    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(payments_identity_resolver=lambda _: "bad")))

    with pytest.raises(TypeError, match="payments_identity_resolver must return IdentityContext, dict, or None"):
        await resolve_request_identity(request)
