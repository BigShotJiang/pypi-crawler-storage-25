from __future__ import annotations

import pytest

from vanty_payments.db.models import PaymentsSetting

pytestmark = pytest.mark.integration


async def test_upsert_creates_setting(payments_app):
    svc = payments_app.settings_service
    setting = await svc.upsert_setting("stripe_test_secret_key", "sk_test_abc123")

    assert setting.key == "stripe_test_secret_key"
    assert setting.value == "sk_test_abc123"
    assert setting.is_secret is True
    assert setting.description == "Stripe test-mode secret key"


async def test_upsert_updates_existing_setting(payments_app):
    svc = payments_app.settings_service
    await svc.upsert_setting("stripe_test_secret_key", "sk_test_old")
    updated = await svc.upsert_setting("stripe_test_secret_key", "sk_test_new")

    assert updated.value == "sk_test_new"
    assert await PaymentsSetting.filter(key="stripe_test_secret_key").count() == 1


async def test_list_settings(payments_app):
    svc = payments_app.settings_service
    await svc.upsert_setting("stripe_test_secret_key", "sk_test_1")
    await svc.upsert_setting("stripe_publishable_key", "pk_test_1")

    settings = await svc.list_settings()
    keys = [s.key for s in settings]
    assert "stripe_publishable_key" in keys
    assert "stripe_test_secret_key" in keys


async def test_get_setting(payments_app):
    svc = payments_app.settings_service
    await svc.upsert_setting("stripe_webhook_secret", "whsec_db_123")

    found = await svc.get_setting("stripe_webhook_secret")
    assert found is not None
    assert found.value == "whsec_db_123"

    missing = await svc.get_setting("nonexistent_key")
    assert missing is None


async def test_delete_setting(payments_app):
    svc = payments_app.settings_service
    await svc.upsert_setting("stripe_test_secret_key", "sk_test_del")

    assert await svc.delete_setting("stripe_test_secret_key") is True
    assert await svc.delete_setting("stripe_test_secret_key") is False


async def test_get_db_stripe_keys(payments_app):
    svc = payments_app.settings_service
    await svc.upsert_setting("stripe_test_secret_key", "sk_test_db")
    await svc.upsert_setting("stripe_live_secret_key", "sk_live_db")
    await svc.upsert_setting("custom_setting", "custom_val")

    keys = await svc.get_db_stripe_keys()
    assert keys["stripe_test_secret_key"] == "sk_test_db"
    assert keys["stripe_live_secret_key"] == "sk_live_db"
    assert "custom_setting" not in keys


async def test_upsert_unknown_key_uses_defaults(payments_app):
    svc = payments_app.settings_service
    setting = await svc.upsert_setting("custom_key", "custom_value")

    assert setting.is_secret is False
    assert setting.description == ""
