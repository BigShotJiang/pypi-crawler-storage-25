# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-04-06

### Changed

- Replaced UUID primary keys with ULID (time-sortable, lexicographically ordered) across all models. Removed local `TimestampedModel`; all models now inherit from `vanty_core.db.models.TimestampedModel`.
- Adds `vanty-core>=0.1.0` as a dependency.

### Breaking

- All model primary keys are now ULID-formatted UUID strings. Existing databases with UUID PKs are incompatible and require a fresh schema.

## [0.1.1] - 2026-04-06

### Added

- `PaymentsSetting` model for storing Stripe API keys and configuration in the
  database instead of (or in addition to) environment variables.
- `SettingsService` with CRUD operations and a `test_stripe_connection` helper
  that validates a secret key against the Stripe API.
- Admin endpoints for settings management:
  - `GET /settings` -- list all settings (secret values masked).
  - `GET /settings/{key}` -- retrieve a single setting.
  - `PUT /settings` -- create or update a setting; reloads keys on the
    `StripeClient` immediately.
  - `DELETE /settings/{key}` -- remove a setting.
  - `POST /settings/test-connection` -- validate the currently active Stripe
    secret key.
- `StripeClient.load_db_keys()` and `_resolve_secret_key()` for database-first
  key resolution with environment-variable fallback.
- `PaymentsApp.reload_db_keys()` to refresh the `StripeClient` key cache from
  the database. Called automatically during `init_orm()` and after every
  settings write.

### Changed

- `StripeClient._request_kwargs` now delegates to `_resolve_secret_key` which
  checks DB-stored keys before falling back to `PaymentsSettings`.
- `StripeClient.construct_event` now uses `_resolve_webhook_secret()` so a
  DB-stored webhook secret takes precedence over the environment variable.

## [0.1.0] - 2026-04-05

### Added

- Initial release with Stripe sync, checkout, billing, webhooks, metering,
  credits, admin service, catalog, and identity integration.
