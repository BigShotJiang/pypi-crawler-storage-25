"""Typer CLI for vanty-payments (`vanty payments …`)."""

from __future__ import annotations

import asyncio
import os

import typer
from vanty_core.apps import AppRegistry

from vanty_payments.apps import PaymentsApp
from vanty_payments.settings import PaymentsSettings

app = typer.Typer(name="payments", help="Stripe and billing commands")


async def _sync_stripe() -> None:
    db_url = os.environ.get("DATABASE_URL")
    if not db_url:
        raise SystemExit("DATABASE_URL is not set (add .env or export it).")
    settings = PaymentsSettings(
        base_url=os.environ.get("API_BASE_URL", "http://127.0.0.1:8000"),
        stripe_test_secret_key=os.environ.get("STRIPE_TEST_SECRET_KEY", ""),
        stripe_webhook_secret=os.environ.get("STRIPE_WEBHOOK_SECRET", ""),
        billing_credits_enabled=True,
        debug_expose_secrets=True,
    )
    registry = AppRegistry(database_url=db_url)
    payments_app = registry.install(PaymentsApp(settings=settings))
    from fastapi import FastAPI

    fake = FastAPI()
    async with registry.lifespan(fake):
        result = await payments_app.admin_service.sync_products_from_stripe()
        typer.echo(result)


@app.command("sync-stripe")
def sync_stripe() -> None:
    """Import Stripe products/prices into ProductConfig rows."""
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass
    asyncio.run(_sync_stripe())
