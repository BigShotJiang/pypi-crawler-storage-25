from importlib.metadata import PackageNotFoundError, version

from vanty_payments import events
from vanty_payments.apps import PaymentsApp
from vanty_payments.core.identity import IdentityContext
from vanty_payments.settings import PaymentsSettings

try:
    __version__ = version("vanty-payments")
except PackageNotFoundError:
    __version__ = "1.0.0"

__all__ = [
    "IdentityContext",
    "PaymentsApp",
    "PaymentsSettings",
    "__version__",
    "events",
]
