from __future__ import annotations

from enum import StrEnum


class BillingUsageMode(StrEnum):
    INTERNAL = "internal"
    STRIPE_FIXED_OVERAGE = "stripe_fixed_overage"
    STRIPE_PAYG = "stripe_payg"
    STRIPE_CREDITS = "stripe_credits"


class SubscriptionPricingModel(StrEnum):
    FLAT_RATE = "flat_rate"
    PER_SEAT = "per_seat"
    USAGE_BASED = "usage_based"


class SubscriptionLifecycleState(StrEnum):
    NOT_SUBSCRIBED = "not_subscribed"
    TRIAL_REQUESTED = "trial_requested"
    TRIALING = "trialing"
    PROCESSING_PAYMENT = "processing_payment"
    PAYMENT_PROCESSED = "payment_processed"
    PAYMENT_PENDING = "payment_pending"
    PAYMENT_FAILED = "payment_failed"
    INCOMPLETE = "incomplete"
    INCOMPLETE_EXPIRED = "incomplete_expired"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    UNPAID = "unpaid"


class EmissionStatus(StrEnum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    SKIPPED = "skipped"


class MeterPricingStrategy(StrEnum):
    MARGIN = "margin"
    FIXED_PER_EVENT = "fixed_per_event"
    PER_UNIT = "per_unit"


class CreditLedgerEntryType(StrEnum):
    SUBSCRIPTION_GRANT = "subscription_grant"
    PURCHASE = "purchase"
    ADMIN_GRANT = "admin_grant"
    ADJUSTMENT = "adjustment"
    REFUND = "refund"
    EXPIRY = "expiry"


class CheckoutSessionMode(StrEnum):
    PAYMENT = "payment"
    SUBSCRIPTION = "subscription"
    SETUP = "setup"
