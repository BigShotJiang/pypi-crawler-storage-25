from __future__ import annotations

from uuid import UUID

from pydantic import AliasPath, BaseModel, ConfigDict, Field, computed_field


class ReplayWebhookRequest(BaseModel):
    delivery_id: UUID


class WebhookProcessResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    delivery_id: UUID = Field(validation_alias="id")
    valid: bool
    processed: bool
    event_type: str | None = Field(default=None, validation_alias=AliasPath("webhook_event", "type"))

    @computed_field
    @property
    def message(self) -> str:
        return "Webhook processed" if self.processed else "Webhook recorded"
