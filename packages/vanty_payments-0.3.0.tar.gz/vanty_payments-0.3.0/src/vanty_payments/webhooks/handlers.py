from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from vanty_core.events import publish

from vanty_payments.billing.constants import SubscriptionLifecycleState
from vanty_payments.billing.services import BillingService
from vanty_payments.core.utils import stripe_id_from, ts_to_datetime
from vanty_payments.db.models import BillingAccount, StripeCustomer
from vanty_payments.events import (
    CheckoutCompleted,
    InvoiceFailed,
    InvoicePaid,
    SubscriptionCancelled,
    SubscriptionCreated,
    SubscriptionUpdated,
)
from vanty_payments.sync.services import SyncService

logger = logging.getLogger(__name__)


def _stripe_customer_id(payload: dict[str, Any]) -> str | None:
    c = payload.get("customer")
    if isinstance(c, dict):
        return c.get("id")
    if isinstance(c, str):
        return c
    return None


def _org_id_from_customer(customer: StripeCustomer | None) -> UUID | None:
    if customer is None or not customer.organization_reference:
        return None
    try:
        return UUID(str(customer.organization_reference))
    except ValueError:
        return None


async def _load_customer(payload: dict[str, Any]) -> StripeCustomer | None:
    cid = _stripe_customer_id(payload)
    if not cid:
        return None
    return await StripeCustomer.filter(stripe_id=cid).first()


def _subscription_plan_hint(payload: dict[str, Any]) -> str | None:
    items = ((payload.get("items") or {}).get("data")) or []
    if not items:
        return None
    first = items[0] or {}
    price = first.get("price")
    return stripe_id_from(price)


class WebhookHandlerRegistry:
    def __init__(
        self,
        sync_service: SyncService,
        billing_service: BillingService | None = None,
    ) -> None:
        self.sync_service = sync_service
        self.billing_service = billing_service

    async def handle_event(self, event: dict[str, Any]) -> object | None:
        payload = event.get("data", {}).get("object", {})
        if not isinstance(payload, dict) or not payload.get("object"):
            return None

        synced = await self.sync_service.sync_stripe_object(payload)

        event_type = event.get("type", "")
        if self.billing_service is not None:
            await self._dispatch_billing_event(event_type, payload)

        return synced

    async def _dispatch_billing_event(self, event_type: str, payload: dict[str, Any]) -> None:
        handlers: dict[str, Any] = {
            "checkout.session.completed": self._handle_checkout_completed,
            "checkout.session.async_payment_succeeded": self._handle_checkout_completed,
            "checkout.session.async_payment_failed": self._handle_checkout_payment_failed,
            "invoice.paid": self._handle_invoice_paid,
            "invoice.payment_failed": self._handle_invoice_payment_failed,
            "customer.subscription.created": self._handle_subscription_created,
            "customer.subscription.updated": self._handle_subscription_updated,
            "customer.subscription.deleted": self._handle_subscription_deleted,
            "setup_intent.succeeded": self._handle_setup_intent_succeeded,
        }
        handler = handlers.get(event_type)
        if handler:
            try:
                await handler(payload)
            except Exception:  # noqa: BLE001
                logger.exception("Error handling billing event %s", event_type)

    async def _resolve_billing_account(self, payload: dict[str, Any]) -> BillingAccount | None:
        if self.billing_service is None:
            return None

        customer_id = payload.get("customer")
        if isinstance(customer_id, dict):
            customer_id = customer_id.get("id")
        if not customer_id:
            return None

        customer = await StripeCustomer.filter(stripe_id=customer_id).first()
        if customer is None:
            return None

        return await self.billing_service.resolve_billing_account(
            user_reference=customer.user_reference,
            organization_reference=customer.organization_reference,
            customer=customer,
        )

    async def _handle_checkout_completed(self, payload: dict[str, Any]) -> None:
        account = await self._resolve_billing_account(payload)
        customer = await _load_customer(payload)
        oid = _org_id_from_customer(customer)
        if oid is not None:
            md = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
            await publish(
                CheckoutCompleted(
                    organization_id=oid,
                    session_id=str(payload.get("id") or ""),
                    customer_id=customer.stripe_id if customer else None,
                    amount_total=payload.get("amount_total"),
                    currency=payload.get("currency"),
                    metadata=dict(md),
                )
            )

        if account is None:
            return

        subscription_id = payload.get("subscription")
        account.state = SubscriptionLifecycleState.ACTIVE.value
        if subscription_id:
            account.current_plan = subscription_id
        await account.save()

        if self.billing_service and self.billing_service.context.settings.billing_credits_enabled:
            await self.billing_service._grant_credits_for_checkout(account, payload)

    async def _handle_checkout_payment_failed(self, payload: dict[str, Any]) -> None:
        account = await self._resolve_billing_account(payload)
        if account is None:
            return
        account.state = SubscriptionLifecycleState.PAYMENT_FAILED.value
        await account.save()

    async def _handle_invoice_paid(self, payload: dict[str, Any]) -> None:
        customer = await _load_customer(payload)
        oid = _org_id_from_customer(customer)
        if oid is not None:
            await publish(
                InvoicePaid(
                    organization_id=oid,
                    invoice_id=str(payload.get("id") or ""),
                    amount_paid=int(payload.get("amount_paid") or 0),
                    currency=str(payload.get("currency") or "usd"),
                )
            )

        if self.billing_service is None:
            return
        billing_reason = payload.get("billing_reason", "")
        if billing_reason not in ("subscription_cycle", "subscription_create"):
            return

        account = await self._resolve_billing_account(payload)
        if account is None:
            return

        if not self.billing_service.context.settings.billing_credits_enabled:
            return

        ref = f"invoice_{payload.get('id', '')}"
        amount_paid = payload.get("amount_paid", 0)
        from decimal import Decimal

        credits = Decimal(amount_paid) / Decimal(self.billing_service.context.settings.credit_factor)
        if credits > 0:
            await self.billing_service.grant_credits(
                account,
                amount=credits,
                entry_type="subscription_grant",
                description=f"Renewal credits for invoice {payload.get('id', '')}",
                reference_id=ref,
            )

    async def _handle_subscription_created(self, payload: dict[str, Any]) -> None:
        customer = await _load_customer(payload)
        oid = _org_id_from_customer(customer)
        if oid is None:
            return
        cid = _stripe_customer_id(payload) or ""
        await publish(
            SubscriptionCreated(
                organization_id=oid,
                subscription_id=str(payload.get("id") or ""),
                customer_id=cid,
                plan=_subscription_plan_hint(payload),
                status=str(payload.get("status") or ""),
            )
        )

    async def _handle_subscription_updated(self, payload: dict[str, Any]) -> None:
        customer = await _load_customer(payload)
        oid = _org_id_from_customer(customer)
        if oid is None:
            return
        await publish(
            SubscriptionUpdated(
                organization_id=oid,
                subscription_id=str(payload.get("id") or ""),
                plan=_subscription_plan_hint(payload),
                status=str(payload.get("status") or ""),
            )
        )

    async def _handle_invoice_payment_failed(self, payload: dict[str, Any]) -> None:
        customer = await _load_customer(payload)
        oid = _org_id_from_customer(customer)
        if oid is None:
            return
        failure = payload.get("last_payment_error") or {}
        reason = None
        if isinstance(failure, dict):
            reason = failure.get("message") or failure.get("code")
        await publish(
            InvoiceFailed(
                organization_id=oid,
                invoice_id=str(payload.get("id") or ""),
                amount_due=int(payload.get("amount_due") or 0),
                currency=str(payload.get("currency") or "usd"),
                failure_reason=reason,
            )
        )

    async def _handle_subscription_deleted(self, payload: dict[str, Any]) -> None:
        customer = await _load_customer(payload)
        oid = _org_id_from_customer(customer)
        if oid is not None:
            await publish(
                SubscriptionCancelled(
                    organization_id=oid,
                    subscription_id=str(payload.get("id") or ""),
                    cancelled_at=ts_to_datetime(payload.get("canceled_at")),
                )
            )
        account = await self._resolve_billing_account(payload)
        if account is None:
            return
        account.state = SubscriptionLifecycleState.CANCELED.value
        account.current_plan = None
        await account.save()

    async def _handle_setup_intent_succeeded(self, payload: dict[str, Any]) -> None:
        customer_id = payload.get("customer")
        if isinstance(customer_id, dict):
            customer_id = customer_id.get("id")
        if not customer_id:
            return

        payment_method = payload.get("payment_method")
        if isinstance(payment_method, dict):
            payment_method = payment_method.get("id")
        if not payment_method:
            return

        customer = await StripeCustomer.filter(stripe_id=customer_id).first()
        if customer:
            customer.default_payment_method_id = payment_method
            await customer.save()
