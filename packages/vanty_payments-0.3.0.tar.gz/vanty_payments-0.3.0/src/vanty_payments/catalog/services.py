from __future__ import annotations

from vanty_payments.db.models import StripePrice, StripeProduct
from vanty_payments.sync.services import SyncService


class CatalogService:
    def __init__(self, sync_service: SyncService) -> None:
        self.sync_service = sync_service

    async def bootstrap_catalog(self, *, limit: int = 100):
        return await self.sync_service.bootstrap(["product", "price"], limit=limit)

    async def list_products(self) -> list[StripeProduct]:
        return await StripeProduct.all().order_by("name")

    async def list_prices(self) -> list[StripePrice]:
        return await StripePrice.all().order_by("currency", "unit_amount")
