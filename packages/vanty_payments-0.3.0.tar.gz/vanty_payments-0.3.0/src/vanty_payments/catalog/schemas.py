from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ProductResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    name: str
    active: bool
    description: str | None = None
    default_price_id: str | None = None
    subscription_model: str = "flat_rate"
    min_quantity: int = 1
    max_quantity: int = 1
    editable_quantity: bool = False
    unit_of_measure: str | None = None
    marketing_features: list = []
    show_in_price_table: bool = True


class PriceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    product_stripe_id: str | None = None
    currency: str
    unit_amount: int | None = None
    active: bool
    price_type: str
    recurring_interval: str | None = None
    recurring_interval_count: int | None = None


class CatalogResponse(BaseModel):
    products: list[ProductResponse]
    prices: list[PriceResponse]
