from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass(slots=True)
class RecordedEvent:
    name: str
    payload: dict[str, Any]
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))


class EventRecorder:
    def __init__(self) -> None:
        self._events: list[RecordedEvent] = []

    def record(self, name: str, payload: dict[str, Any] | None = None) -> None:
        self._events.append(RecordedEvent(name=name, payload=payload or {}))

    def list(self) -> list[RecordedEvent]:
        return list(self._events)
