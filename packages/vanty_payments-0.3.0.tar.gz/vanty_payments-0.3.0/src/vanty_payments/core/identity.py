from __future__ import annotations

import inspect
from dataclasses import dataclass

from fastapi import Request


@dataclass(slots=True)
class IdentityContext:
    user_reference: str | None = None
    organization_reference: str | None = None


def resolve_identity_refs(
    payload_user_reference: str | None,
    payload_organization_reference: str | None,
    identity: IdentityContext,
) -> tuple[str | None, str | None]:
    return (
        payload_user_reference or identity.user_reference,
        payload_organization_reference or identity.organization_reference,
    )


async def resolve_request_identity(request: Request) -> IdentityContext:
    resolver = getattr(request.app.state, "payments_identity_resolver", None)
    if resolver is None:
        return IdentityContext()

    result = resolver(request)
    if inspect.isawaitable(result):
        result = await result

    if result is None:
        return IdentityContext()
    if isinstance(result, IdentityContext):
        return result
    if isinstance(result, dict):
        return IdentityContext(
            user_reference=result.get("user_reference"),
            organization_reference=result.get("organization_reference"),
        )
    raise TypeError("payments_identity_resolver must return IdentityContext, dict, or None")
