from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class MessageResponse(BaseModel):
    message: str
    debug: dict[str, Any] | None = None
