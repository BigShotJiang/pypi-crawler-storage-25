from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from vanty_payments.billing.schemas import (
    BillingConfigResponse,
    BillingPublicConfigResponse,
    BillingSummaryResponse,
    CancelSubscriptionResponse,
    ChangePlanRequest,
    ChangePlanResponse,
    CheckoutConfirmResponse,
    CreditBalanceResponse,
    CreditLedgerEntryResponse,
    InvoiceResponse,
    InvoicesResponse,
    PaymentMethodResponse,
    PaymentMethodsResponse,
    RecordUsageRequest,
    SetupIntentResponse,
    SubscriptionResponse,
    UsageRecordResponse,
    UsageSummaryResponse,
)
from vanty_payments.catalog.schemas import CatalogResponse, PriceResponse, ProductResponse
from vanty_payments.checkout.schemas import (
    BillingPortalSessionResponse,
    CheckoutSessionResponse,
    CreateBillingPortalSessionRequest,
    CreateCheckoutSessionRequest,
)
from vanty_payments.core.identity import IdentityContext, resolve_identity_refs
from vanty_payments.core.schemas import MessageResponse
from vanty_payments.customers.schemas import (
    CustomerBootstrapRequest,
    CustomerResponse,
    CustomersResponse,
)
from vanty_payments.db.models import ProductConfig
from vanty_payments.fastapi.dependencies import get_identity_context, get_payments_app
from vanty_payments.sync.schemas import BootstrapSyncRequest, SyncObjectRequest, SyncRunResponse
from vanty_payments.webhooks.schemas import ReplayWebhookRequest, WebhookProcessResponse

if TYPE_CHECKING:
    from vanty_payments.apps import PaymentsApp


router = APIRouter(prefix="/payments", tags=["payments"])


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------


@router.post("/customer/bootstrap", response_model=CustomerResponse)
async def bootstrap_customer(
    payload: CustomerBootstrapRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CustomerResponse:
    user_ref, org_ref = resolve_identity_refs(payload.user_reference, payload.organization_reference, identity)
    customer = await payments_app.bootstrap_customer(
        email=payload.email,
        name=payload.name,
        user_reference=user_ref,
        organization_reference=org_ref,
        stripe_customer_id=payload.stripe_customer_id,
        metadata=payload.metadata,
    )
    return CustomerResponse.model_validate(customer)


@router.get("/customer", response_model=CustomerResponse)
async def get_customer(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CustomerResponse:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    customer = await payments_app.get_customer(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    if customer is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")
    return CustomerResponse.model_validate(customer)


@router.get("/customers", response_model=CustomersResponse)
async def list_customers(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CustomersResponse:
    customers = await payments_app.list_customers()
    return CustomersResponse(customers=[CustomerResponse.model_validate(c) for c in customers])


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


@router.get("/catalog", response_model=CatalogResponse)
async def catalog(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CatalogResponse:
    products, prices = await payments_app.catalog()
    configs = {
        config.product_stripe_id: config
        for config in await ProductConfig.all()
        if config.product_stripe_id
    }
    product_payloads = []
    for product in products:
        config = configs.get(product.stripe_id)
        payload = ProductResponse.model_validate(product).model_dump()
        if config is not None:
            payload.update(
                {
                    "subscription_model": config.subscription_model,
                    "min_quantity": config.min_quantity,
                    "max_quantity": config.max_quantity,
                    "editable_quantity": config.editable_quantity,
                    "unit_of_measure": config.unit_of_measure,
                    "marketing_features": config.marketing_features,
                    "show_in_price_table": config.show_in_price_table,
                }
            )
        product_payloads.append(ProductResponse(**payload))
    return CatalogResponse(
        products=product_payloads,
        prices=[PriceResponse.model_validate(p) for p in prices],
    )


# ---------------------------------------------------------------------------
# Checkout
# ---------------------------------------------------------------------------


@router.post("/checkout/sessions", response_model=CheckoutSessionResponse)
async def create_checkout_session(
    payload: CreateCheckoutSessionRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CheckoutSessionResponse:
    user_ref, org_ref = resolve_identity_refs(payload.user_reference, payload.organization_reference, identity)
    session = await payments_app.create_checkout_session(
        email=payload.email,
        name=payload.name,
        stripe_customer_id=payload.stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
        metadata=payload.metadata,
        mode=payload.mode,
        line_items=payload.line_items,
        success_url=payload.success_url,
        cancel_url=payload.cancel_url,
        client_reference_id=payload.client_reference_id,
    )
    return CheckoutSessionResponse.model_validate(session)


async def _confirm_checkout_session_for_identity(
    session_id: str,
    identity: IdentityContext,
    payments_app: PaymentsApp,
) -> CheckoutConfirmResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_app.billing_service.confirm_checkout_session(session_id, account)
    return CheckoutConfirmResponse(**result)


@router.post("/checkout/sessions/{session_id}/confirm", response_model=CheckoutConfirmResponse)
async def confirm_checkout_session_post(
    session_id: str,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CheckoutConfirmResponse:
    return await _confirm_checkout_session_for_identity(session_id, identity, payments_app)


@router.get("/checkout/sessions/{session_id}/confirm", response_model=CheckoutConfirmResponse)
async def confirm_checkout_session(
    session_id: str,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CheckoutConfirmResponse:
    return await _confirm_checkout_session_for_identity(session_id, identity, payments_app)


# ---------------------------------------------------------------------------
# Billing portal
# ---------------------------------------------------------------------------


@router.post("/billing-portal/sessions", response_model=BillingPortalSessionResponse)
async def create_billing_portal_session(
    payload: CreateBillingPortalSessionRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> BillingPortalSessionResponse:
    user_ref, org_ref = resolve_identity_refs(payload.user_reference, payload.organization_reference, identity)
    url = await payments_app.create_billing_portal_session(
        stripe_customer_id=payload.stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
        return_url=payload.return_url,
    )
    return BillingPortalSessionResponse(url=url)


# ---------------------------------------------------------------------------
# Billing reads
# ---------------------------------------------------------------------------


@router.get("/billing/config", response_model=BillingConfigResponse)
async def get_billing_config(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> BillingConfigResponse:
    return BillingConfigResponse(**payments_app.billing_service.get_billing_config())


@router.get("/billing/public-config", response_model=BillingPublicConfigResponse)
async def get_billing_public_config(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> BillingPublicConfigResponse:
    db_keys = await payments_app.settings_service.get_db_stripe_keys()
    gate_setting = await payments_app.settings_service.get_setting("app_billing_gate_mode")
    signup_setting = await payments_app.settings_service.get_setting("app_signup_flow")
    config = payments_app.billing_service.get_billing_config()
    return BillingPublicConfigResponse(
        stripe_publishable_key=(
            db_keys.get("stripe_publishable_key")
            or payments_app.context.settings.stripe_publishable_key
        ),
        billing_usage_mode=config["billing_usage_mode"],
        billing_credits_enabled=config["billing_credits_enabled"],
        app_billing_gate_mode=gate_setting.value if gate_setting else None,
        app_signup_flow=signup_setting.value if signup_setting else None,
        app_credits_gated=payments_app.context.settings.app_credits_gated,
    )


@router.get("/billing/summary", response_model=BillingSummaryResponse)
async def get_billing_summary(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> BillingSummaryResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    summary = await payments_app.billing_service.get_billing_summary(account)
    sub = summary.pop("subscription", None)
    if sub:
        summary["subscription"] = SubscriptionResponse.model_validate(sub)
    return BillingSummaryResponse(**summary)


@router.get("/subscription", response_model=SubscriptionResponse | None)
async def get_subscription(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> SubscriptionResponse | None:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    subscription = await payments_app.get_subscription(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    if subscription is None:
        return None
    return SubscriptionResponse.model_validate(subscription)


@router.get("/invoices", response_model=InvoicesResponse)
async def list_invoices(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> InvoicesResponse:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    invoices = await payments_app.list_invoices(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    return InvoicesResponse(invoices=[InvoiceResponse.model_validate(inv) for inv in invoices])


@router.get("/payment-methods", response_model=PaymentMethodsResponse)
async def list_payment_methods(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> PaymentMethodsResponse:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    payment_methods = await payments_app.list_payment_methods(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    return PaymentMethodsResponse(
        payment_methods=[PaymentMethodResponse.model_validate(pm) for pm in payment_methods]
    )


# ---------------------------------------------------------------------------
# Subscription lifecycle
# ---------------------------------------------------------------------------


@router.post("/billing/change-plan", response_model=ChangePlanResponse)
async def change_plan(
    payload: ChangePlanRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> ChangePlanResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_app.billing_service.change_subscription_price(account, payload.new_price_id)
    return ChangePlanResponse(**result)


@router.post("/billing/cancel-subscription", response_model=CancelSubscriptionResponse)
async def cancel_subscription(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CancelSubscriptionResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_app.billing_service.cancel_subscription(account)
    return CancelSubscriptionResponse(**result)


@router.post("/billing/reactivate-subscription", response_model=CancelSubscriptionResponse)
async def reactivate_subscription(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CancelSubscriptionResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_app.billing_service.reactivate_subscription(account)
    return CancelSubscriptionResponse(**result)


@router.post("/billing/setup-payment-method", response_model=SetupIntentResponse)
async def setup_payment_method(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> SetupIntentResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_app.billing_service.create_setup_intent(account)
    return SetupIntentResponse(**result)


# ---------------------------------------------------------------------------
# Usage metering
# ---------------------------------------------------------------------------


@router.post("/billing/usage/record", response_model=UsageRecordResponse)
async def record_usage(
    payload: RecordUsageRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> UsageRecordResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    event = await payments_app.billing_service.record_usage(
        account,
        event_name=payload.event_name,
        value=payload.value,
        dimensions=payload.dimensions,
        enforce_credit_balance=payload.enforce_credit_balance,
    )
    return UsageRecordResponse.model_validate(event)


@router.get("/billing/usage/summary", response_model=UsageSummaryResponse)
async def get_usage_summary(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> UsageSummaryResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    summary = await payments_app.billing_service.get_usage_summary(account)
    return UsageSummaryResponse(**summary)


@router.get("/billing/usage/records", response_model=list[UsageRecordResponse])
async def list_usage_records(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[UsageRecordResponse]:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    records = await payments_app.billing_service.list_usage_records(account)
    return [UsageRecordResponse.model_validate(r) for r in records]


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------


@router.get("/billing/credits/balance", response_model=CreditBalanceResponse)
async def get_credit_balance(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CreditBalanceResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    balance = await payments_app.billing_service.get_credit_balance(account)
    return CreditBalanceResponse(**balance)


@router.get("/billing/credits/ledger", response_model=list[CreditLedgerEntryResponse])
async def list_credit_ledger(
    identity: IdentityContext = Depends(get_identity_context),
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[CreditLedgerEntryResponse]:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_app.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    entries = await payments_app.billing_service.list_credit_ledger(account)
    return [CreditLedgerEntryResponse.model_validate(e) for e in entries]


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------


@router.post("/webhooks/stripe", response_model=WebhookProcessResponse)
async def process_webhook(
    request: Request,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> WebhookProcessResponse:
    payload = await request.body()
    signature = request.headers.get("stripe-signature")
    delivery = await payments_app.process_webhook(
        payload=payload,
        signature=signature,
        headers=dict(request.headers),
        remote_ip=request.client.host if request.client else None,
    )
    if not delivery.valid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=delivery.exception or "Invalid webhook")
    return WebhookProcessResponse.model_validate(delivery)


@router.post("/webhooks/reprocess", response_model=WebhookProcessResponse)
async def replay_webhook(
    payload: ReplayWebhookRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> WebhookProcessResponse:
    delivery = await payments_app.replay_webhook(payload.delivery_id)
    return WebhookProcessResponse.model_validate(delivery)


# ---------------------------------------------------------------------------
# Sync
# ---------------------------------------------------------------------------


@router.post("/sync/bootstrap", response_model=SyncRunResponse)
async def bootstrap_sync(
    payload: BootstrapSyncRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> SyncRunResponse:
    sync_run = await payments_app.bootstrap_sync(payload.object_types, limit=payload.limit)
    return SyncRunResponse.model_validate(sync_run)


@router.post("/sync/object", response_model=MessageResponse)
async def sync_object(
    payload: SyncObjectRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MessageResponse:
    instance = await payments_app.sync_object(payload.object_type, payload.stripe_id)
    if instance is None:
        return MessageResponse(
            message="No-op",
            debug={"object_type": payload.object_type, "stripe_id": payload.stripe_id},
        )
    return MessageResponse(
        message="Object synced",
        debug={"object_type": payload.object_type, "stripe_id": payload.stripe_id},
    )
