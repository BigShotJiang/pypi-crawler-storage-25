from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Request

from vanty_payments.core.identity import IdentityContext, resolve_request_identity

if TYPE_CHECKING:
    from vanty_payments.apps import PaymentsApp


def get_payments_app(request: Request) -> PaymentsApp:
    """Return the installed ``PaymentsApp`` from the registry on the request app."""
    registry = getattr(request.app.state, "registry", None)
    if registry is None:
        raise RuntimeError(
            "No AppRegistry is mounted on app.state. "
            "Construct AppRegistry(...) and call registry.mount(app) before serving traffic."
        )
    return registry.get("payments")


async def get_identity_context(request: Request) -> IdentityContext:
    return await resolve_request_identity(request)
