"""Domain events published by vanty-payments.

These map onto Stripe lifecycle moments (and the credits/usage layer that
sits on top), but they are framework-agnostic: any payments backend can
publish the same shapes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from uuid import UUID

from vanty_core.events import event


@event("payments.customer.created")
@dataclass(frozen=True)
class CustomerCreated:
    organization_id: UUID
    customer_id: str
    email: str | None = None


@event("payments.subscription.created")
@dataclass(frozen=True)
class SubscriptionCreated:
    organization_id: UUID
    subscription_id: str
    customer_id: str
    plan: str | None = None
    status: str | None = None


@event("payments.subscription.updated")
@dataclass(frozen=True)
class SubscriptionUpdated:
    organization_id: UUID
    subscription_id: str
    plan: str | None = None
    status: str | None = None


@event("payments.subscription.cancelled")
@dataclass(frozen=True)
class SubscriptionCancelled:
    organization_id: UUID
    subscription_id: str
    cancelled_at: datetime | None = None


@event("payments.checkout.completed")
@dataclass(frozen=True)
class CheckoutCompleted:
    organization_id: UUID
    session_id: str
    customer_id: str | None = None
    amount_total: int | None = None
    currency: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@event("payments.invoice.paid")
@dataclass(frozen=True)
class InvoicePaid:
    organization_id: UUID
    invoice_id: str
    amount_paid: int
    currency: str


@event("payments.invoice.failed")
@dataclass(frozen=True)
class InvoiceFailed:
    organization_id: UUID
    invoice_id: str
    amount_due: int
    currency: str
    failure_reason: str | None = None


@event("payments.usage.recorded")
@dataclass(frozen=True)
class UsageRecorded:
    organization_id: UUID
    meter: str
    quantity: int
    metadata: dict[str, Any] = field(default_factory=dict)


@event("payments.credits.granted")
@dataclass(frozen=True)
class CreditsGranted:
    organization_id: UUID
    amount: int
    reason: str | None = None
    granted_by_user_id: UUID | None = None


@event("payments.credits.consumed")
@dataclass(frozen=True)
class CreditsConsumed:
    organization_id: UUID
    amount: int
    reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
