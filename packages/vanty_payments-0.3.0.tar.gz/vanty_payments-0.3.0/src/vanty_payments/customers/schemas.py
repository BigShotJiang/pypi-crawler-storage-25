from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class CustomerBootstrapRequest(BaseModel):
    email: str
    name: str | None = None
    user_reference: str | None = None
    organization_reference: str | None = None
    stripe_customer_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class CustomerResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    email: str | None = None
    name: str | None = None
    user_reference: str | None = None
    organization_reference: str | None = None
    default_payment_method_id: str | None = None
    livemode: bool


class CustomersResponse(BaseModel):
    customers: list[CustomerResponse]
