from __future__ import annotations

from uuid import UUID

from fastapi import HTTPException, status
from vanty_core.events import publish

from vanty_payments.core.context import ServiceContext
from vanty_payments.db.models import StripeCustomer
from vanty_payments.events import CustomerCreated
from vanty_payments.sync.services import SyncService


class CustomerService:
    def __init__(self, context: ServiceContext, sync_service: SyncService) -> None:
        self.context = context
        self.sync_service = sync_service

    async def resolve_customer(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeCustomer | None:
        if stripe_customer_id:
            return await StripeCustomer.get_or_none(stripe_id=stripe_customer_id)
        if user_reference and organization_reference:
            customer = await StripeCustomer.get_or_none(
                user_reference=user_reference,
                organization_reference=organization_reference,
            )
            if customer:
                return customer
        if user_reference:
            customer = await StripeCustomer.get_or_none(user_reference=user_reference)
            if customer:
                return customer
        if organization_reference:
            return await StripeCustomer.get_or_none(organization_reference=organization_reference)
        return None

    async def require_customer(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeCustomer:
        customer = await self.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        if customer is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")
        return customer

    async def bootstrap_customer(
        self,
        *,
        email: str,
        name: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        stripe_customer_id: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> StripeCustomer:
        existing = await self.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        if existing is not None:
            return existing

        if stripe_customer_id:
            customer = await self.sync_service.sync_by_type_and_id("customer", stripe_customer_id)
        else:
            payload_metadata = dict(metadata or {})
            if user_reference:
                payload_metadata.setdefault(self.context.settings.customer_metadata_user_key, user_reference)
            if organization_reference:
                payload_metadata.setdefault(self.context.settings.customer_metadata_org_key, organization_reference)
            customer_data = self.context.stripe_client.create_customer(
                email=email,
                name=name,
                metadata=payload_metadata,
            )
            customer = await self.sync_service.sync_customer(
                customer_data,
                user_reference=user_reference,
                organization_reference=organization_reference,
            )
        if user_reference and customer.user_reference != user_reference:
            customer.user_reference = user_reference
        if organization_reference and customer.organization_reference != organization_reference:
            customer.organization_reference = organization_reference
        await customer.save()
        self.context.events.record(
            "payments.customer.bootstrapped",
            {
                "customer_stripe_id": customer.stripe_id,
                "user_reference": customer.user_reference,
                "organization_reference": customer.organization_reference,
            },
        )
        org_id: UUID | None = None
        if customer.organization_reference:
            try:
                org_id = UUID(str(customer.organization_reference))
            except ValueError:
                org_id = None
        if org_id is not None:
            await publish(
                CustomerCreated(
                    organization_id=org_id,
                    customer_id=customer.stripe_id,
                    email=customer.email,
                )
            )
        return customer

    async def list_customers(self) -> list[StripeCustomer]:
        return await StripeCustomer.all().order_by("email")
