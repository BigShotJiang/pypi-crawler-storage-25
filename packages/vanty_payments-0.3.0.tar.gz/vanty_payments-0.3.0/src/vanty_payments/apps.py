"""``PaymentsApp`` — vanty-payments's AppConfig.

Composition root and registration entry. Wires every Stripe service and
declares the static metadata so ``AppRegistry`` can mount the router,
aggregate the models, eagerly import events, and drive the lifecycle.

Install via the registry::

    registry.install("vanty_payments")
    # or
    registry.install(PaymentsApp(settings=PaymentsSettings(stripe_test_secret_key=...)))
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any
from uuid import UUID

from fastapi import APIRouter
from tortoise import connections
from vanty_core.apps import AppConfig

from vanty_payments.admin.router import admin_router
from vanty_payments.admin.schemas import MeterDefault
from vanty_payments.admin.services import AdminService
from vanty_payments.admin.settings_service import SettingsService
from vanty_payments.billing import BillingService
from vanty_payments.catalog import CatalogService
from vanty_payments.checkout import CheckoutService
from vanty_payments.checkout.schemas import CheckoutLineItem
from vanty_payments.core.context import ServiceContext
from vanty_payments.core.events import EventRecorder
from vanty_payments.core.stripe_client import StripeClient
from vanty_payments.customers import CustomerService
from vanty_payments.db.models import (
    CreditLedgerEntry,
    InternalMeterEvent,
    ProductConfig,
    StripeCheckoutSession,
    StripeCustomer,
    StripeInvoice,
    StripePaymentMethod,
    StripePrice,
    StripeProduct,
    StripeSubscription,
    StripeSyncRun,
    StripeWebhookDelivery,
)
from vanty_payments.fastapi.router import router as payments_router
from vanty_payments.settings import PaymentsSettings
from vanty_payments.sync import SyncService
from vanty_payments.webhooks import WebhookService

if TYPE_CHECKING:
    from vanty_core.apps import AppRegistry


class PaymentsApp(AppConfig):
    """vanty-payments AppConfig: Stripe customers, catalog, checkout, billing, webhooks, sync."""

    name = "vanty_payments"
    label = "payments"
    version = "0.3.0"
    depends_on = ()
    models_module = "vanty_payments.db.models"
    router_attr = "vanty_payments.fastapi.router:router"
    admin_router_attr = "vanty_payments.admin.router:admin_router"
    events_module = "vanty_payments.events"
    cli_app_attr = "vanty_payments.cli:app"

    def __init__(self, settings: PaymentsSettings | None = None) -> None:
        super().__init__(settings=settings or PaymentsSettings())
        self.context = ServiceContext(
            settings=self.settings,
            stripe_client=StripeClient(self.settings),
            events=EventRecorder(),
        )
        self.sync_service = SyncService(self.context)
        self.customer_service = CustomerService(self.context, self.sync_service)
        self.catalog_service = CatalogService(self.sync_service)
        self.checkout_service = CheckoutService(self.context, self.customer_service, self.sync_service)
        self.billing_service = BillingService(self.context, self.customer_service)
        self.admin_service = AdminService(self.context, self.sync_service, self.billing_service)
        self.settings_service = SettingsService()
        self.webhook_service = WebhookService(self.context, self.sync_service, self.billing_service)
        self.router: APIRouter = payments_router
        self._admin_router: APIRouter = admin_router
        self.identity_resolver: Any = None

    @property
    def admin_router(self) -> APIRouter:
        return self._admin_router

    @property
    def events(self) -> EventRecorder:
        return self.context.events

    # ------------------------------------------------------------------
    # AppConfig lifecycle
    # ------------------------------------------------------------------

    async def on_startup(self, registry: AppRegistry) -> None:
        if "postgresql" in registry.database_url:
            from vanty_payments.db.views import create_pg_views

            await create_pg_views()
        await self._ensure_compatible_schema(registry.database_url)
        await self.reload_db_keys()

    async def _ensure_compatible_schema(self, database_url: str) -> None:
        conn = connections.get("default")
        if database_url.startswith(("postgres://", "postgresql://")):
            table = await self._find_product_config_table(conn)
            if not table:
                return
            await conn.execute_script(
                f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS subscription_model VARCHAR(32) DEFAULT 'flat_rate';"
            )
            return
        table = ProductConfig._meta.db_table or "productconfig"
        try:
            columns = await conn.execute_query_dict(f"PRAGMA table_info({table})")
        except Exception:
            return
        if not any(row.get("name") == "subscription_model" for row in columns):
            await conn.execute_script(
                f"ALTER TABLE {table} ADD COLUMN subscription_model VARCHAR(32) DEFAULT 'flat_rate';"
            )

    async def _find_product_config_table(self, conn: Any) -> str | None:
        rows = await conn.execute_query_dict(
            """
            SELECT table_name
            FROM information_schema.columns
            WHERE column_name IN ('product_stripe_id', 'show_in_price_table')
            GROUP BY table_name
            HAVING COUNT(DISTINCT column_name) = 2
            """
        )
        for row in rows:
            name = row.get("table_name")
            if name:
                return str(name)
        return ProductConfig._meta.db_table or None

    async def reload_db_keys(self) -> None:
        db_keys = await self.settings_service.get_db_stripe_keys()
        self.context.stripe_client.load_db_keys(db_keys)
        runtime = await self.settings_service.get_runtime_settings()
        for key, value in runtime.items():
            if not hasattr(self.settings, key):
                continue
            current = getattr(self.settings, key)
            if isinstance(current, bool):
                setattr(self.settings, key, value.lower() in {"1", "true", "yes", "on"})
            elif isinstance(current, int):
                try:
                    setattr(self.settings, key, int(value))
                except ValueError:
                    continue
            else:
                setattr(self.settings, key, value)

    # ------------------------------------------------------------------
    # Customer facade
    # ------------------------------------------------------------------

    async def bootstrap_customer(
        self,
        *,
        email: str,
        name: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        stripe_customer_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> StripeCustomer:
        return await self.customer_service.bootstrap_customer(
            email=email,
            name=name,
            user_reference=user_reference,
            organization_reference=organization_reference,
            stripe_customer_id=stripe_customer_id,
            metadata=metadata,
        )

    async def get_customer(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeCustomer | None:
        return await self.customer_service.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def list_customers(self) -> list[StripeCustomer]:
        return await self.customer_service.list_customers()

    # ------------------------------------------------------------------
    # Catalog facade
    # ------------------------------------------------------------------

    async def catalog(self) -> tuple[list[StripeProduct], list[StripePrice]]:
        return await self.catalog_service.list_products(), await self.catalog_service.list_prices()

    # ------------------------------------------------------------------
    # Checkout facade
    # ------------------------------------------------------------------

    async def create_checkout_session(
        self,
        *,
        email: str | None = None,
        name: str | None = None,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        metadata: dict[str, Any] | None = None,
        mode: str = "subscription",
        line_items: list[CheckoutLineItem] | None = None,
        success_url: str | None = None,
        cancel_url: str | None = None,
        client_reference_id: str | None = None,
    ) -> StripeCheckoutSession:
        stripe_line_items = [
            {"price": item.price_id, "quantity": item.quantity} for item in (line_items or [])
        ]
        return await self.checkout_service.create_checkout_session(
            email=email,
            name=name,
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
            metadata=metadata or {},
            mode=mode,
            line_items=stripe_line_items,
            success_url=success_url,
            cancel_url=cancel_url,
            client_reference_id=client_reference_id,
        )

    async def create_billing_portal_session(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        return_url: str | None = None,
    ) -> str:
        return await self.checkout_service.create_billing_portal_session(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
            return_url=return_url,
        )

    # ------------------------------------------------------------------
    # Billing facade
    # ------------------------------------------------------------------

    async def get_subscription(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeSubscription | None:
        return await self.billing_service.get_subscription(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def list_invoices(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> list[StripeInvoice]:
        return await self.billing_service.list_invoices(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def list_payment_methods(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> list[StripePaymentMethod]:
        return await self.billing_service.list_payment_methods(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def confirm_checkout(
        self,
        session_id: str,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> dict[str, Any]:
        account = await self.billing_service.resolve_billing_account(
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        return await self.billing_service.confirm_checkout_session(session_id, account)

    async def record_usage(
        self,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        event_name: str,
        value: int = 1,
        dimensions: dict[str, str] | None = None,
        enforce_credit_balance: bool = False,
    ) -> InternalMeterEvent:
        account = await self.billing_service.resolve_billing_account(
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        return await self.billing_service.record_usage(
            account,
            event_name=event_name,
            value=value,
            dimensions=dimensions,
            enforce_credit_balance=enforce_credit_balance,
        )

    async def grant_credits(
        self,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        amount: Decimal,
        description: str = "",
        reference_id: str | None = None,
    ) -> CreditLedgerEntry:
        account = await self.billing_service.resolve_billing_account(
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        return await self.billing_service.grant_credits(
            account,
            amount=amount,
            description=description,
            reference_id=reference_id,
        )

    async def load_default_meters(self, defaults: list[MeterDefault]) -> int:
        return await self.admin_service.load_default_meters(defaults)

    # ------------------------------------------------------------------
    # Webhooks facade
    # ------------------------------------------------------------------

    async def process_webhook(
        self,
        *,
        payload: bytes,
        signature: str | None,
        headers: dict[str, object],
        remote_ip: str | None,
    ) -> StripeWebhookDelivery:
        return await self.webhook_service.ingest(
            payload=payload,
            signature=signature,
            headers=headers,
            remote_ip=remote_ip,
        )

    async def replay_webhook(self, delivery_id: UUID) -> StripeWebhookDelivery:
        return await self.webhook_service.replay(delivery_id)

    # ------------------------------------------------------------------
    # Sync facade
    # ------------------------------------------------------------------

    async def bootstrap_sync(self, object_types: list[str], *, limit: int = 100) -> StripeSyncRun:
        return await self.sync_service.bootstrap(object_types, limit=limit)

    async def sync_object(self, object_type: str, stripe_id: str) -> object | None:
        return await self.sync_service.sync_by_type_and_id(object_type, stripe_id)

    def set_identity_resolver(self, resolver: object) -> None:
        self.identity_resolver = resolver
