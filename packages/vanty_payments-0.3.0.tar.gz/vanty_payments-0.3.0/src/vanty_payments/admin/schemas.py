from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ProductConfigResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    product_stripe_id: str | None = None
    show_in_ui: bool
    show_in_price_table: bool
    subscription_model: str
    weight: int
    min_quantity: int
    max_quantity: int
    editable_quantity: bool
    unit_of_measure: str | None = None
    marketing_features: list
    pricing_page_price_ids: list
    product: dict | None = None
    prices: list[dict] = []


class ProductConfigUpdateRequest(BaseModel):
    show_in_ui: bool | None = None
    show_in_price_table: bool | None = None
    subscription_model: str | None = None
    weight: int | None = None
    min_quantity: int | None = None
    max_quantity: int | None = None
    editable_quantity: bool | None = None
    unit_of_measure: str | None = None
    marketing_features: list | None = None
    pricing_page_price_ids: list | None = None


class ProductCreateRequest(BaseModel):
    name: str
    description: str | None = None
    active: bool = True
    metadata: dict[str, str] = {}
    show_in_ui: bool = True
    show_in_price_table: bool = True


class PriceCreateRequest(BaseModel):
    product_stripe_id: str
    currency: str = "usd"
    unit_amount: int
    recurring_interval: str | None = None
    recurring_interval_count: int | None = None
    nickname: str | None = None
    active: bool = True


class MeterResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    event_name: str
    display_name: str
    description: str
    is_active: bool
    pricing_strategy: str
    margin_multiplier: Decimal
    fixed_amount: Decimal
    unit_price: Decimal
    cost_dimension_key: str


class MeterCreateRequest(BaseModel):
    event_name: str
    display_name: str
    description: str = ""
    pricing_strategy: str = "margin"
    margin_multiplier: Decimal = Decimal("1.5")
    fixed_amount: Decimal = Decimal("0")
    unit_price: Decimal = Decimal("0")
    cost_dimension_key: str = "total_cost"


class MeterUpdateRequest(BaseModel):
    display_name: str | None = None
    description: str | None = None
    is_active: bool | None = None
    pricing_strategy: str | None = None
    margin_multiplier: Decimal | None = None
    fixed_amount: Decimal | None = None
    unit_price: Decimal | None = None
    cost_dimension_key: str | None = None


class MeterDefault(BaseModel):
    event_name: str
    display_name: str
    description: str = ""
    pricing_strategy: str = "margin"
    margin_multiplier: Decimal = Decimal("1.5")
    fixed_amount: Decimal = Decimal("0")
    unit_price: Decimal = Decimal("0")
    cost_dimension_key: str = "total_cost"


class AdminCreditGrantRequest(BaseModel):
    billing_account_id: UUID
    amount: Decimal
    description: str = "Admin credit grant"
    reference_id: str | None = None
    expires_at: datetime | None = None


class IntegrationStatusResponse(BaseModel):
    stripe_configured: bool
    stripe_mode: str
    webhook_secret_set: bool
    products_synced: int
    prices_synced: int = 0
    meters_configured: int
    billing_accounts: int
    last_sync: dict | None = None


class AdminInvoiceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    number: str | None = None
    status: str | None = None
    currency: str | None = None
    total: int
    amount_due: int
    amount_paid: int
    customer_stripe_id: str | None = None
    subscription_stripe_id: str | None = None
    hosted_invoice_url: str | None = None
    invoice_pdf: str | None = None
    paid_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class CostSummaryBucket(BaseModel):
    key: str
    label: str
    provider_cost: Decimal
    recovered_credits: Decimal
    margin: Decimal
    events: int


class CostSummaryResponse(BaseModel):
    provider_cost: Decimal
    recovered_credits: Decimal
    margin: Decimal
    events: int
    by_provider: list[CostSummaryBucket]
    by_meter: list[CostSummaryBucket]


class CostEventResponse(BaseModel):
    id: UUID
    event_name: str
    meter_id: UUID | None = None
    meter_name: str | None = None
    provider: str | None = None
    service: str | None = None
    model: str | None = None
    value: int
    provider_cost: Decimal
    recovered_credits: Decimal
    dimensions: dict
    occurred_at: datetime


class SettingResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    key: str
    value: str
    is_secret: bool
    description: str
    created_at: datetime
    updated_at: datetime

    def mask_value(self) -> SettingResponse:
        if self.is_secret and self.value:
            masked = self.value[:4] + "..." + self.value[-4:] if len(self.value) > 8 else "****"
            return self.model_copy(update={"value": masked})
        return self


class SettingUpsertRequest(BaseModel):
    key: str
    value: str


class StripeConnectionTestResponse(BaseModel):
    valid: bool
    account_id: str | None = None
    display_name: str | None = None
    livemode: bool | None = None
    error: str | None = None
