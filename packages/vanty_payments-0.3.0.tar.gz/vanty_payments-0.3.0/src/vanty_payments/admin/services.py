from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from vanty_payments.admin.schemas import MeterDefault
from vanty_payments.billing.constants import SubscriptionPricingModel
from vanty_payments.billing.services import BillingService
from vanty_payments.core.context import ServiceContext
from vanty_payments.db.models import (
    BillingAccount,
    CreditLedgerEntry,
    InternalMeterEvent,
    Meter,
    ProductConfig,
    StripeInvoice,
    StripePrice,
    StripeProduct,
    StripeSyncRun,
)
from vanty_payments.sync.services import SyncService


class AdminService:
    def __init__(
        self,
        context: ServiceContext,
        sync_service: SyncService,
        billing_service: BillingService,
    ) -> None:
        self.context = context
        self.sync_service = sync_service
        self.billing_service = billing_service

    # ------------------------------------------------------------------
    # Product config
    # ------------------------------------------------------------------

    async def list_product_configs(self) -> list[ProductConfig]:
        return await ProductConfig.all().order_by("weight", "product_stripe_id")

    async def list_product_config_payloads(self) -> list[dict[str, Any]]:
        configs = await self.list_product_configs()
        return [await self._product_config_payload(config) for config in configs]

    async def get_product_config(self, config_id: UUID) -> ProductConfig | None:
        return await ProductConfig.get_or_none(pk=config_id)

    async def get_product_config_payload(self, config_id: UUID) -> dict[str, Any] | None:
        config = await self.get_product_config(config_id)
        return await self._product_config_payload(config) if config else None

    async def update_product_config(
        self,
        config_id: UUID,
        updates: dict[str, Any],
    ) -> ProductConfig | None:
        config = await ProductConfig.get_or_none(pk=config_id)
        if config is None:
            return None
        valid_models = {model.value for model in SubscriptionPricingModel}
        for key, val in updates.items():
            if val is not None:
                if key == "subscription_model" and val not in valid_models:
                    val = SubscriptionPricingModel.FLAT_RATE.value
                setattr(config, key, val)
        await config.save()
        return config

    async def create_stripe_product(self, data: dict[str, Any]) -> dict[str, Any]:
        product_data = self.context.stripe_client.create_object(
            "product",
            name=data["name"],
            description=data.get("description"),
            active=data.get("active", True),
            metadata=data.get("metadata") or {},
        )
        product = await self.sync_service.sync_product(product_data)
        config = await ProductConfig.filter(product_stripe_id=product.stripe_id).first()
        if config is None:
            config = await ProductConfig.create(
                product_stripe_id=product.stripe_id,
                show_in_ui=data.get("show_in_ui", True),
                show_in_price_table=data.get("show_in_price_table", True),
            )
        else:
            config.show_in_ui = data.get("show_in_ui", config.show_in_ui)
            config.show_in_price_table = data.get("show_in_price_table", config.show_in_price_table)
            await config.save()
        return await self._product_config_payload(config)

    async def create_stripe_price(self, data: dict[str, Any]) -> StripePrice:
        recurring_interval = data.get("recurring_interval")
        payload: dict[str, Any] = {
            "product": data["product_stripe_id"],
            "currency": data.get("currency") or self.context.settings.default_currency,
            "unit_amount": data["unit_amount"],
            "active": data.get("active", True),
        }
        if data.get("nickname"):
            payload["nickname"] = data["nickname"]
        if recurring_interval:
            payload["recurring"] = {
                "interval": recurring_interval,
                "interval_count": data.get("recurring_interval_count") or 1,
            }
        price_data = self.context.stripe_client.create_object("price", **payload)
        return await self.sync_service.sync_price(price_data)

    async def sync_products_from_stripe(self) -> dict[str, int]:
        products = self.context.stripe_client.list_objects("product")
        prices = self.context.stripe_client.list_objects("price")
        created = 0
        updated = 0
        for product_data in products:
            await self.sync_service.sync_product(product_data)
            stripe_product = await StripeProduct.filter(stripe_id=product_data["id"]).first()
            if stripe_product:
                existing = await ProductConfig.filter(product_stripe_id=stripe_product.stripe_id).first()
                if existing:
                    updated += 1
                else:
                    await ProductConfig.create(product_stripe_id=stripe_product.stripe_id)
                    created += 1
        for price_data in prices:
            await self.sync_service.sync_price(price_data)
        return {"created": created, "updated": updated, "total": created + updated}

    async def _product_config_payload(self, config: ProductConfig) -> dict[str, Any]:
        product = None
        prices: list[dict[str, Any]] = []
        if config.product_stripe_id:
            product_row = await StripeProduct.filter(stripe_id=config.product_stripe_id).first()
            if product_row:
                product = {
                    "stripe_id": product_row.stripe_id,
                    "name": product_row.name,
                    "active": product_row.active,
                    "description": product_row.description,
                    "default_price_id": product_row.default_price_id,
                    "product_type": product_row.product_type,
                    "created_at": product_row.created_at,
                    "updated_at": product_row.updated_at,
                    "metadata": product_row.metadata_json,
                }
                price_rows = await StripePrice.filter(
                    product_stripe_id=product_row.stripe_id
                ).order_by("unit_amount", "stripe_id")
                prices = [
                    {
                        "stripe_id": price.stripe_id,
                        "currency": price.currency,
                        "unit_amount": price.unit_amount,
                        "active": price.active,
                        "price_type": price.price_type,
                        "recurring_interval": price.recurring_interval,
                        "recurring_interval_count": price.recurring_interval_count,
                        "nickname": price.nickname,
                        "created_at": price.created_at,
                        "updated_at": price.updated_at,
                    }
                    for price in price_rows
                ]
        return {
            "id": config.id,
            "product_stripe_id": config.product_stripe_id,
            "show_in_ui": config.show_in_ui,
            "show_in_price_table": config.show_in_price_table,
            "subscription_model": config.subscription_model,
            "weight": config.weight,
            "min_quantity": config.min_quantity,
            "max_quantity": config.max_quantity,
            "editable_quantity": config.editable_quantity,
            "unit_of_measure": config.unit_of_measure,
            "marketing_features": config.marketing_features,
            "pricing_page_price_ids": config.pricing_page_price_ids,
            "product": product,
            "prices": prices,
        }

    # ------------------------------------------------------------------
    # Meter CRUD
    # ------------------------------------------------------------------

    async def list_meters(self) -> list[Meter]:
        return await Meter.all().order_by("event_name")

    async def create_meter(self, data: dict[str, Any]) -> Meter:
        return await Meter.create(**data)

    async def get_meter(self, meter_id: UUID) -> Meter | None:
        return await Meter.get_or_none(pk=meter_id)

    async def update_meter(self, meter_id: UUID, updates: dict[str, Any]) -> Meter | None:
        meter = await Meter.get_or_none(pk=meter_id)
        if meter is None:
            return None
        for key, val in updates.items():
            if val is not None:
                setattr(meter, key, val)
        await meter.save()
        return meter

    async def delete_meter(self, meter_id: UUID) -> bool:
        meter = await Meter.get_or_none(pk=meter_id)
        if meter is None:
            return False
        await meter.delete()
        return True

    async def load_default_meters(self, defaults: list[MeterDefault]) -> int:
        loaded = 0
        for d in defaults:
            existing = await Meter.filter(event_name=d.event_name).first()
            if existing:
                continue
            await Meter.create(
                event_name=d.event_name,
                display_name=d.display_name,
                description=d.description,
                pricing_strategy=d.pricing_strategy,
                margin_multiplier=d.margin_multiplier,
                fixed_amount=d.fixed_amount,
                unit_price=d.unit_price,
                cost_dimension_key=d.cost_dimension_key,
            )
            loaded += 1
        return loaded

    # ------------------------------------------------------------------
    # Admin credit grants
    # ------------------------------------------------------------------

    async def grant_credits(
        self,
        billing_account_id: UUID,
        *,
        amount: Decimal,
        description: str = "Admin credit grant",
        reference_id: str | None = None,
        expires_at: Any = None,
    ) -> CreditLedgerEntry:
        account = await BillingAccount.get(pk=billing_account_id)
        return await self.billing_service.grant_credits(
            account,
            amount=amount,
            entry_type="admin_grant",
            description=description,
            reference_id=reference_id,
            expires_at=expires_at,
        )

    # ------------------------------------------------------------------
    # Integration status
    # ------------------------------------------------------------------

    async def get_integration_status(self) -> dict[str, Any]:
        s = self.context.settings
        last_sync = await StripeSyncRun.all().order_by("-started_at").first()
        return {
            "stripe_configured": bool(s.stripe_secret_key),
            "stripe_mode": s.stripe_mode,
            "webhook_secret_set": bool(s.stripe_webhook_secret),
            "products_synced": await ProductConfig.all().count(),
            "prices_synced": await StripePrice.all().count(),
            "meters_configured": await Meter.all().count(),
            "billing_accounts": await BillingAccount.all().count(),
            "last_sync": {
                "id": str(last_sync.id),
                "mode": last_sync.mode,
                "object_types": last_sync.object_types_json,
                "counts": last_sync.counts_json,
                "failures": last_sync.failures_json,
                "started_at": last_sync.started_at,
                "finished_at": last_sync.finished_at,
                "succeeded": last_sync.succeeded,
            }
            if last_sync
            else None,
        }

    async def list_invoices(self, *, limit: int = 100) -> list[StripeInvoice]:
        return await StripeInvoice.all().order_by("-paid_at", "-created_at").limit(limit)

    # ------------------------------------------------------------------
    # Cost reporting
    # ------------------------------------------------------------------

    async def cost_summary(self) -> dict[str, Any]:
        events = await InternalMeterEvent.all().prefetch_related("meter")
        total_cost = Decimal("0")
        total_recovered = Decimal("0")
        by_provider: dict[str, dict[str, Any]] = {}
        by_meter: dict[str, dict[str, Any]] = {}
        for event in events:
            provider_cost = self._event_provider_cost(event)
            recovered = Decimal(str(event.credit_cost or 0))
            provider = str(event.dimensions.get("provider") or event.dimensions.get("vendor") or "unknown")
            meter_key = event.meter.event_name if event.meter else event.event_name
            meter_label = event.meter.display_name if event.meter else event.event_name
            total_cost += provider_cost
            total_recovered += recovered
            self._accumulate_cost_bucket(by_provider, provider, provider, provider_cost, recovered)
            self._accumulate_cost_bucket(by_meter, meter_key, meter_label, provider_cost, recovered)
        return {
            "provider_cost": total_cost,
            "recovered_credits": total_recovered,
            "margin": total_recovered - total_cost,
            "events": len(events),
            "by_provider": list(by_provider.values()),
            "by_meter": list(by_meter.values()),
        }

    async def cost_events(self, *, limit: int = 100) -> list[dict[str, Any]]:
        events = await (
            InternalMeterEvent.all()
            .prefetch_related("meter")
            .order_by("-occurred_at")
            .limit(limit)
        )
        return [
            {
                "id": event.id,
                "event_name": event.event_name,
                "meter_id": event.meter.id if event.meter else None,
                "meter_name": event.meter.display_name if event.meter else None,
                "provider": event.dimensions.get("provider") or event.dimensions.get("vendor"),
                "service": event.dimensions.get("service"),
                "model": event.dimensions.get("model"),
                "value": event.value,
                "provider_cost": self._event_provider_cost(event),
                "recovered_credits": Decimal(str(event.credit_cost or 0)),
                "dimensions": event.dimensions,
                "occurred_at": event.occurred_at,
            }
            for event in events
        ]

    def _event_provider_cost(self, event: InternalMeterEvent) -> Decimal:
        key = event.meter.cost_dimension_key if event.meter else "total_cost"
        return Decimal(str(event.dimensions.get(key, event.dimensions.get("total_cost", "0")) or "0"))

    def _accumulate_cost_bucket(
        self,
        buckets: dict[str, dict[str, Any]],
        key: str,
        label: str,
        provider_cost: Decimal,
        recovered: Decimal,
    ) -> None:
        bucket = buckets.setdefault(
            key,
            {
                "key": key,
                "label": label,
                "provider_cost": Decimal("0"),
                "recovered_credits": Decimal("0"),
                "margin": Decimal("0"),
                "events": 0,
            },
        )
        bucket["provider_cost"] += provider_cost
        bucket["recovered_credits"] += recovered
        bucket["margin"] = bucket["recovered_credits"] - bucket["provider_cost"]
        bucket["events"] += 1
