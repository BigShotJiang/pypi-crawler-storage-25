from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from vanty_payments.admin.schemas import (
    AdminCreditGrantRequest,
    AdminInvoiceResponse,
    CostEventResponse,
    CostSummaryResponse,
    IntegrationStatusResponse,
    MeterCreateRequest,
    MeterResponse,
    MeterUpdateRequest,
    PriceCreateRequest,
    ProductConfigResponse,
    ProductConfigUpdateRequest,
    ProductCreateRequest,
    SettingResponse,
    SettingUpsertRequest,
    StripeConnectionTestResponse,
)
from vanty_payments.billing.schemas import CreditLedgerEntryResponse
from vanty_payments.core.schemas import MessageResponse
from vanty_payments.fastapi.dependencies import get_payments_app


class ProductSyncResponse(BaseModel):
    created: int = 0
    updated: int = 0
    total: int = 0

if TYPE_CHECKING:
    from vanty_payments.apps import PaymentsApp

admin_router = APIRouter(tags=["admin"])


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------


@admin_router.get("/products", response_model=list[ProductConfigResponse])
async def list_product_configs(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[ProductConfigResponse]:
    configs = await payments_app.admin_service.list_product_config_payloads()
    return [ProductConfigResponse.model_validate(c) for c in configs]


@admin_router.post("/products/sync-from-stripe", response_model=ProductSyncResponse)
async def sync_products_from_stripe(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> dict:
    result = await payments_app.admin_service.sync_products_from_stripe()
    return result


@admin_router.get("/products/{config_id}", response_model=ProductConfigResponse)
async def get_product_config(
    config_id: UUID,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> ProductConfigResponse:
    config = await payments_app.admin_service.get_product_config_payload(config_id)
    if config is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product config not found")
    return ProductConfigResponse.model_validate(config)


@admin_router.post("/products", response_model=ProductConfigResponse)
async def create_product(
    payload: ProductCreateRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> ProductConfigResponse:
    config = await payments_app.admin_service.create_stripe_product(payload.model_dump())
    return ProductConfigResponse.model_validate(config)


@admin_router.post("/prices")
async def create_price(
    payload: PriceCreateRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> dict:
    price = await payments_app.admin_service.create_stripe_price(payload.model_dump())
    return {
        "id": str(price.id),
        "stripe_id": price.stripe_id,
        "product_stripe_id": price.product_stripe_id,
        "currency": price.currency,
        "unit_amount": price.unit_amount,
        "active": price.active,
        "price_type": price.price_type,
        "recurring_interval": price.recurring_interval,
        "recurring_interval_count": price.recurring_interval_count,
        "nickname": price.nickname,
    }


@admin_router.post("/products/{config_id}", response_model=ProductConfigResponse)
async def update_product_config(
    config_id: UUID,
    payload: ProductConfigUpdateRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> ProductConfigResponse:
    config = await payments_app.admin_service.update_product_config(
        config_id,
        payload.model_dump(exclude_none=True),
    )
    if config is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product config not found")
    config_payload = await payments_app.admin_service.get_product_config_payload(config_id)
    return ProductConfigResponse.model_validate(config_payload)


# ---------------------------------------------------------------------------
# Meters
# ---------------------------------------------------------------------------


@admin_router.get("/meters", response_model=list[MeterResponse])
async def list_meters(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[MeterResponse]:
    meters = await payments_app.admin_service.list_meters()
    return [MeterResponse.model_validate(m) for m in meters]


@admin_router.post("/meters", response_model=MeterResponse)
async def create_meter(
    payload: MeterCreateRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MeterResponse:
    meter = await payments_app.admin_service.create_meter(payload.model_dump())
    return MeterResponse.model_validate(meter)


@admin_router.post("/meters/load-defaults", response_model=MessageResponse)
async def load_default_meters(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MessageResponse:
    return MessageResponse(message="Use kit.load_default_meters() from code to load meter defaults")


@admin_router.get("/meters/{meter_id}", response_model=MeterResponse)
async def get_meter(
    meter_id: UUID,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MeterResponse:
    meter = await payments_app.admin_service.get_meter(meter_id)
    if meter is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Meter not found")
    return MeterResponse.model_validate(meter)


@admin_router.patch("/meters/{meter_id}", response_model=MeterResponse)
async def update_meter(
    meter_id: UUID,
    payload: MeterUpdateRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MeterResponse:
    meter = await payments_app.admin_service.update_meter(
        meter_id,
        payload.model_dump(exclude_none=True),
    )
    if meter is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Meter not found")
    return MeterResponse.model_validate(meter)


@admin_router.delete("/meters/{meter_id}", response_model=MessageResponse)
async def delete_meter(
    meter_id: UUID,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MessageResponse:
    deleted = await payments_app.admin_service.delete_meter(meter_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Meter not found")
    return MessageResponse(message="Meter deleted")


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------


@admin_router.post("/credits/grant", response_model=CreditLedgerEntryResponse)
async def grant_credits(
    payload: AdminCreditGrantRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CreditLedgerEntryResponse:
    entry = await payments_app.admin_service.grant_credits(
        payload.billing_account_id,
        amount=payload.amount,
        description=payload.description,
        reference_id=payload.reference_id,
        expires_at=payload.expires_at,
    )
    return CreditLedgerEntryResponse.model_validate(entry)


# ---------------------------------------------------------------------------
# Integration status
# ---------------------------------------------------------------------------


@admin_router.get("/integration-status", response_model=IntegrationStatusResponse)
async def get_integration_status(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> IntegrationStatusResponse:
    status_data = await payments_app.admin_service.get_integration_status()
    return IntegrationStatusResponse(**status_data)


@admin_router.get("/invoices", response_model=list[AdminInvoiceResponse])
async def list_admin_invoices(
    limit: int = 100,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[AdminInvoiceResponse]:
    return [
        AdminInvoiceResponse.model_validate(row)
        for row in await payments_app.admin_service.list_invoices(limit=limit)
    ]


@admin_router.get("/costs/summary", response_model=CostSummaryResponse)
async def get_cost_summary(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> CostSummaryResponse:
    return CostSummaryResponse(**await payments_app.admin_service.cost_summary())


@admin_router.get("/costs/events", response_model=list[CostEventResponse])
async def list_cost_events(
    limit: int = 100,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[CostEventResponse]:
    return [
        CostEventResponse.model_validate(row)
        for row in await payments_app.admin_service.cost_events(limit=limit)
    ]


# ---------------------------------------------------------------------------
# Settings (Stripe key management)
# ---------------------------------------------------------------------------


@admin_router.get("/settings", response_model=list[SettingResponse])
async def list_settings(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> list[SettingResponse]:
    rows = await payments_app.settings_service.list_settings()
    return [SettingResponse.model_validate(r).mask_value() for r in rows]


@admin_router.get("/settings/{key}", response_model=SettingResponse)
async def get_setting(
    key: str,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> SettingResponse:
    setting = await payments_app.settings_service.get_setting(key)
    if setting is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Setting not found")
    return SettingResponse.model_validate(setting).mask_value()


@admin_router.put("/settings", response_model=SettingResponse)
async def upsert_setting(
    payload: SettingUpsertRequest,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> SettingResponse:
    setting = await payments_app.settings_service.upsert_setting(payload.key, payload.value)
    await payments_app.reload_db_keys()
    return SettingResponse.model_validate(setting).mask_value()


@admin_router.delete("/settings/{key}", response_model=MessageResponse)
async def delete_setting(
    key: str,
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> MessageResponse:
    deleted = await payments_app.settings_service.delete_setting(key)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Setting not found")
    await payments_app.reload_db_keys()
    return MessageResponse(message="Setting deleted")


@admin_router.post("/settings/test-connection", response_model=StripeConnectionTestResponse)
async def test_stripe_connection(
    payments_app: PaymentsApp = Depends(get_payments_app),
) -> StripeConnectionTestResponse:
    secret_key = payments_app.context.stripe_client._resolve_secret_key()
    if not secret_key:
        return StripeConnectionTestResponse(valid=False, error="No Stripe secret key configured")
    result = await payments_app.settings_service.test_stripe_connection(secret_key)
    return StripeConnectionTestResponse(**result)
