from __future__ import annotations

from typing import Any

from vanty_payments.core.utils import as_dict
from vanty_payments.db.models import PaymentsSetting

KNOWN_KEYS = {
    "stripe_test_secret_key": {"is_secret": True, "description": "Stripe test-mode secret key"},
    "stripe_live_secret_key": {"is_secret": True, "description": "Stripe live-mode secret key"},
    "stripe_publishable_key": {"is_secret": False, "description": "Stripe publishable key"},
    "stripe_webhook_secret": {"is_secret": True, "description": "Stripe webhook signing secret"},
    "billing_usage_mode": {"is_secret": False, "description": "Usage billing mode"},
    "billing_credits_enabled": {"is_secret": False, "description": "Enable credit ledger features"},
    "credit_factor": {"is_secret": False, "description": "Checkout amount-to-credit scaling factor"},
    "stripe_trial_period_days": {"is_secret": False, "description": "Default Stripe trial period days"},
    "stripe_automatic_tax_enabled": {"is_secret": False, "description": "Enable Stripe automatic tax"},
    "stripe_cancel_at_period_end": {"is_secret": False, "description": "Cancel subscriptions at period end"},
    "app_billing_gate_mode": {"is_secret": False, "description": "Frontend access gate mode"},
    "app_signup_flow": {"is_secret": False, "description": "Signup routing mode"},
    "app_credits_gated": {"is_secret": False, "description": "Reject protected actions when credits are exhausted"},
}


class SettingsService:
    async def list_settings(self) -> list[PaymentsSetting]:
        return await PaymentsSetting.all().order_by("key")

    async def get_setting(self, key: str) -> PaymentsSetting | None:
        return await PaymentsSetting.get_or_none(key=key)

    async def upsert_setting(self, key: str, value: str) -> PaymentsSetting:
        defaults = KNOWN_KEYS.get(key, {"is_secret": False, "description": ""})
        setting = await PaymentsSetting.get_or_none(key=key)
        if setting is None:
            setting = await PaymentsSetting.create(
                key=key,
                value=value,
                is_secret=defaults["is_secret"],
                description=defaults["description"],
            )
        else:
            setting.value = value
            await setting.save()
        return setting

    async def delete_setting(self, key: str) -> bool:
        setting = await PaymentsSetting.get_or_none(key=key)
        if setting is None:
            return False
        await setting.delete()
        return True

    async def get_db_stripe_keys(self) -> dict[str, str]:
        """Return a dict of stripe key settings from the database."""
        keys: dict[str, str] = {}
        for row in await PaymentsSetting.filter(
            key__in=[
                "stripe_test_secret_key",
                "stripe_live_secret_key",
                "stripe_publishable_key",
                "stripe_webhook_secret",
            ],
        ):
            if row.value:
                keys[row.key] = row.value
        return keys

    async def get_runtime_settings(self) -> dict[str, str]:
        rows = await PaymentsSetting.filter(key__in=list(KNOWN_KEYS))
        return {row.key: row.value for row in rows if row.value}

    async def test_stripe_connection(self, secret_key: str) -> dict[str, Any]:
        """Validate a Stripe key by making a lightweight API call."""
        try:
            import stripe

            account = as_dict(stripe.Account.retrieve(api_key=secret_key))
            return {
                "valid": True,
                "account_id": account.get("id"),
                "display_name": account.get("settings", {}).get("dashboard", {}).get("display_name"),
                "livemode": account.get("livemode", False),
            }
        except Exception as exc:
            return {"valid": False, "error": str(exc)}
