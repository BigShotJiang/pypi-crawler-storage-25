from vanty_payments.admin.services import AdminService

__all__ = ["AdminService"]
