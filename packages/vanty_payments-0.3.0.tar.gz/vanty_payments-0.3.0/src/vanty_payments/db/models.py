from __future__ import annotations

from tortoise import fields
from vanty_core.db.models import TimestampedModel


class StripeRecordModel(TimestampedModel):
    stripe_id = fields.CharField(max_length=255, unique=True)
    livemode = fields.BooleanField(default=False)
    stripe_created_at = fields.DatetimeField(null=True)
    last_synced_at = fields.DatetimeField(null=True)
    metadata_json = fields.JSONField(default=dict)
    stripe_data_json = fields.JSONField(default=dict)

    class Meta:
        abstract = True


class StripeSyncModel(StripeRecordModel):
    sync_status = fields.CharField(max_length=32, default="synced")

    class Meta:
        abstract = True


class StripeWorkflowModel(StripeRecordModel):
    workflow_origin = fields.CharField(max_length=32, default="app")
    workflow_state = fields.CharField(max_length=32, default="created")

    class Meta:
        abstract = True


class StripeCustomer(StripeSyncModel):
    user_reference = fields.CharField(max_length=255, null=True, db_index=True)
    organization_reference = fields.CharField(max_length=255, null=True, db_index=True)
    email = fields.CharField(max_length=320, null=True)
    name = fields.CharField(max_length=255, null=True)
    default_payment_method_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    delinquent = fields.BooleanField(default=False)


class StripeProduct(StripeSyncModel):
    name = fields.CharField(max_length=255)
    active = fields.BooleanField(default=True)
    description = fields.TextField(null=True)
    default_price_id = fields.CharField(max_length=255, null=True)
    product_type = fields.CharField(max_length=64, null=True)


class StripePrice(StripeSyncModel):
    product_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    currency = fields.CharField(max_length=12)
    unit_amount = fields.BigIntField(null=True)
    active = fields.BooleanField(default=True)
    price_type = fields.CharField(max_length=32, default="one_time")
    recurring_interval = fields.CharField(max_length=32, null=True)
    recurring_interval_count = fields.IntField(null=True)
    nickname = fields.CharField(max_length=255, null=True)


class StripePaymentMethod(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    type = fields.CharField(max_length=64, null=True)
    brand = fields.CharField(max_length=64, null=True)
    last4 = fields.CharField(max_length=8, null=True)
    exp_month = fields.IntField(null=True)
    exp_year = fields.IntField(null=True)
    fingerprint = fields.CharField(max_length=255, null=True)


class StripePaymentIntent(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    payment_method_stripe_id = fields.CharField(max_length=255, null=True)
    amount = fields.BigIntField(default=0)
    amount_received = fields.BigIntField(default=0)
    currency = fields.CharField(max_length=12, null=True)
    status = fields.CharField(max_length=64, null=True)
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    client_secret = fields.CharField(max_length=255, null=True)


class StripeSubscription(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    default_payment_method_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    current_period_start = fields.DatetimeField(null=True)
    current_period_end = fields.DatetimeField(null=True)
    cancel_at_period_end = fields.BooleanField(default=False)
    cancel_at = fields.DatetimeField(null=True)
    canceled_at = fields.DatetimeField(null=True)
    price_ids_json = fields.JSONField(default=list)


class StripeSubscriptionItem(StripeSyncModel):
    subscription_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    price_stripe_id = fields.CharField(max_length=255, null=True)
    quantity = fields.IntField(default=1)


class StripeInvoice(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)
    number = fields.CharField(max_length=128, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    subtotal = fields.BigIntField(default=0)
    total = fields.BigIntField(default=0)
    amount_due = fields.BigIntField(default=0)
    amount_paid = fields.BigIntField(default=0)
    hosted_invoice_url = fields.TextField(null=True)
    invoice_pdf = fields.TextField(null=True)
    period_start = fields.DatetimeField(null=True)
    period_end = fields.DatetimeField(null=True)
    paid_at = fields.DatetimeField(null=True)


class StripeInvoiceLine(StripeSyncModel):
    invoice_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    stripe_price_id = fields.CharField(max_length=255, null=True)
    description = fields.TextField(null=True)
    quantity = fields.IntField(default=1)
    amount = fields.BigIntField(default=0)
    currency = fields.CharField(max_length=12, null=True)
    period_start = fields.DatetimeField(null=True)
    period_end = fields.DatetimeField(null=True)
    subscription_item_stripe_id = fields.CharField(max_length=255, null=True)


class StripeCheckoutSession(StripeWorkflowModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    mode = fields.CharField(max_length=32, default="subscription")
    status = fields.CharField(max_length=64, null=True)
    payment_status = fields.CharField(max_length=64, null=True)
    url = fields.TextField(null=True)
    success_url = fields.TextField(null=True)
    cancel_url = fields.TextField(null=True)
    client_reference_id = fields.CharField(max_length=255, null=True)
    line_items_json = fields.JSONField(default=list)
    completed_at = fields.DatetimeField(null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)


class StripeWebhookEndpoint(TimestampedModel):
    stripe_id = fields.CharField(max_length=255, unique=True, null=True)
    livemode = fields.BooleanField(default=False)
    url = fields.TextField()
    secret = fields.CharField(max_length=255)
    enabled_events = fields.JSONField(default=list)
    api_version = fields.CharField(max_length=64, null=True)
    active = fields.BooleanField(default=True)


class StripeWebhookEvent(StripeSyncModel):
    type = fields.CharField(max_length=255)
    api_version = fields.CharField(max_length=64, null=True)
    data_json = fields.JSONField(default=dict)
    request_id = fields.CharField(max_length=255, null=True)
    idempotency_key = fields.CharField(max_length=255, null=True)
    processed = fields.BooleanField(default=False)
    processing_error = fields.TextField(null=True)


class StripeWebhookDelivery(TimestampedModel):
    signature = fields.TextField(null=True)
    remote_ip = fields.CharField(max_length=64, null=True)
    headers = fields.JSONField(default=dict)
    body = fields.TextField()
    valid = fields.BooleanField(default=False)
    processed = fields.BooleanField(default=False)
    exception = fields.CharField(max_length=255, null=True)
    traceback = fields.TextField(null=True)
    webhook_event_stripe_id = fields.CharField(max_length=255, null=True)


class StripeSyncRun(TimestampedModel):
    mode = fields.CharField(max_length=32, default="bootstrap")
    object_types_json = fields.JSONField(default=list)
    counts_json = fields.JSONField(default=dict)
    failures_json = fields.JSONField(default=list)
    started_at = fields.DatetimeField(auto_now_add=True)
    finished_at = fields.DatetimeField(null=True)
    succeeded = fields.BooleanField(default=False)


class PaymentsSetting(TimestampedModel):
    key = fields.CharField(max_length=255, unique=True, db_index=True)
    value = fields.TextField(default="")
    is_secret = fields.BooleanField(default=False)
    description = fields.CharField(max_length=512, default="")

    class Meta:
        table = "payments_setting"


class BillingAccount(TimestampedModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    user_reference = fields.CharField(max_length=255, null=True, db_index=True)
    organization_reference = fields.CharField(max_length=255, null=True, db_index=True)
    state = fields.CharField(max_length=64, default="not_subscribed")
    current_plan = fields.CharField(max_length=255, null=True)
    admin_approved = fields.BooleanField(default=False)


class ProductConfig(TimestampedModel):
    product_stripe_id = fields.CharField(max_length=255, null=True, db_index=True)
    show_in_ui = fields.BooleanField(default=False)
    show_in_price_table = fields.BooleanField(default=False)
    subscription_model = fields.CharField(max_length=32, default="flat_rate")
    weight = fields.IntField(default=1)
    min_quantity = fields.IntField(default=1)
    max_quantity = fields.IntField(default=1)
    editable_quantity = fields.BooleanField(default=False)
    unit_of_measure = fields.CharField(max_length=64, null=True)
    marketing_features = fields.JSONField(default=list)
    pricing_page_price_ids = fields.JSONField(default=list)


class Meter(TimestampedModel):
    event_name = fields.CharField(max_length=255, unique=True, db_index=True)
    display_name = fields.CharField(max_length=255)
    description = fields.TextField(default="")
    is_active = fields.BooleanField(default=True)
    pricing_strategy = fields.CharField(max_length=32, default="margin")
    margin_multiplier = fields.DecimalField(max_digits=6, decimal_places=3, default=1.5)
    fixed_amount = fields.DecimalField(max_digits=12, decimal_places=6, default=0)
    unit_price = fields.DecimalField(max_digits=12, decimal_places=8, default=0)
    cost_dimension_key = fields.CharField(max_length=100, default="total_cost")


class InternalMeterEvent(TimestampedModel):
    billing_account = fields.ForeignKeyField(
        "models.BillingAccount",
        related_name="meter_events",
        on_delete=fields.CASCADE,
    )
    meter = fields.ForeignKeyField(
        "models.Meter",
        related_name="events",
        null=True,
        on_delete=fields.SET_NULL,
    )
    event_name = fields.CharField(max_length=255, db_index=True)
    value = fields.IntField()
    credit_cost = fields.DecimalField(max_digits=12, decimal_places=6, default=0)
    dimensions = fields.JSONField(default=dict)
    occurred_at = fields.DatetimeField(auto_now_add=True)
    emission_status = fields.CharField(max_length=32, default="pending")
    stripe_customer_id = fields.CharField(max_length=255, null=True)
    stripe_identifier = fields.CharField(max_length=255, null=True, unique=True)
    stripe_synced_at = fields.DatetimeField(null=True)
    stripe_sync_error = fields.TextField(null=True)
    stripe_sync_attempts = fields.IntField(default=0)


class CreditLedgerEntry(TimestampedModel):
    billing_account = fields.ForeignKeyField(
        "models.BillingAccount",
        related_name="credit_entries",
        on_delete=fields.CASCADE,
    )
    entry_type = fields.CharField(max_length=32, db_index=True)
    amount = fields.DecimalField(max_digits=12, decimal_places=6)
    description = fields.TextField(default="")
    effective_at = fields.DatetimeField(auto_now_add=True)
    expires_at = fields.DatetimeField(null=True)
    reference_id = fields.CharField(max_length=255, null=True)


class StripeAccount(StripeSyncModel):
    email = fields.CharField(max_length=320, null=True)
    country = fields.CharField(max_length=8, null=True)
    default_currency = fields.CharField(max_length=12, null=True)
    business_type = fields.CharField(max_length=64, null=True)
    charges_enabled = fields.BooleanField(default=False)
    payouts_enabled = fields.BooleanField(default=False)
    details_submitted = fields.BooleanField(default=False)


class StripeApiKey(StripeRecordModel):
    key_type = fields.CharField(max_length=32)
    name = fields.CharField(max_length=255, null=True)
    secret_redacted = fields.CharField(max_length=255)
    owner_account_stripe_id = fields.CharField(max_length=255, null=True)


class StripeIdempotencyKey(TimestampedModel):
    key = fields.CharField(max_length=255, unique=True)
    action = fields.CharField(max_length=255)
    livemode = fields.BooleanField(default=False)


class StripeCoupon(StripeSyncModel):
    name = fields.CharField(max_length=255, null=True)
    duration = fields.CharField(max_length=32, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount_off = fields.BigIntField(null=True)
    percent_off = fields.FloatField(null=True)
    valid = fields.BooleanField(default=True)


class StripePromotionCode(StripeSyncModel):
    coupon_stripe_id = fields.CharField(max_length=255, null=True)
    code = fields.CharField(max_length=255)
    active = fields.BooleanField(default=True)
    customer_stripe_id = fields.CharField(max_length=255, null=True)


class StripeDiscount(StripeSyncModel):
    coupon_stripe_id = fields.CharField(max_length=255, null=True)
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    start_at = fields.DatetimeField(null=True)
    end_at = fields.DatetimeField(null=True)


class StripeInvoiceItem(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    price_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    quantity = fields.IntField(null=True)
    description = fields.TextField(null=True)


class StripeLineItem(StripeSyncModel):
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    checkout_session_stripe_id = fields.CharField(max_length=255, null=True)
    price_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    quantity = fields.IntField(null=True)
    description = fields.TextField(null=True)


class StripePlan(StripeSyncModel):
    product_stripe_id = fields.CharField(max_length=255, null=True)
    nickname = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    interval = fields.CharField(max_length=32, null=True)
    interval_count = fields.IntField(null=True)
    active = fields.BooleanField(default=True)


class StripeSubscriptionSchedule(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    released_subscription_stripe_id = fields.CharField(max_length=255, null=True)
    current_phase_json = fields.JSONField(default=dict)


class StripeShippingRate(StripeSyncModel):
    display_name = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    fixed_amount = fields.BigIntField(null=True)
    active = fields.BooleanField(default=True)
    delivery_estimate_json = fields.JSONField(default=dict)


class StripeTaxCode(StripeSyncModel):
    name = fields.CharField(max_length=255, null=True)
    description = fields.TextField(null=True)


class StripeTaxId(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    country = fields.CharField(max_length=8, null=True)
    type = fields.CharField(max_length=64, null=True)
    value = fields.CharField(max_length=255, null=True)
    verification_json = fields.JSONField(default=dict)


class StripeTaxRate(StripeSyncModel):
    display_name = fields.CharField(max_length=255, null=True)
    jurisdiction = fields.CharField(max_length=255, null=True)
    country = fields.CharField(max_length=8, null=True)
    state = fields.CharField(max_length=64, null=True)
    percentage = fields.FloatField(null=True)
    inclusive = fields.BooleanField(default=False)
    active = fields.BooleanField(default=True)


class StripeUpcomingInvoice(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    total = fields.BigIntField(null=True)
    amount_due = fields.BigIntField(null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeBalanceTransaction(StripeSyncModel):
    source_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    fee = fields.BigIntField(null=True)
    net = fields.BigIntField(null=True)
    type = fields.CharField(max_length=64, null=True)
    reporting_category = fields.CharField(max_length=64, null=True)


class StripeCharge(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)
    dispute_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    amount_refunded = fields.BigIntField(null=True)
    status = fields.CharField(max_length=64, null=True)
    paid = fields.BooleanField(default=False)
    refunded = fields.BooleanField(default=False)


class StripeDispute(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    reason = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeEvent(StripeSyncModel):
    event_type = fields.CharField(max_length=255)
    api_version = fields.CharField(max_length=64, null=True)
    request_id = fields.CharField(max_length=255, null=True)
    idempotency_key = fields.CharField(max_length=255, null=True)
    pending_webhooks = fields.IntField(null=True)


class StripeFile(StripeSyncModel):
    filename = fields.CharField(max_length=255, null=True)
    purpose = fields.CharField(max_length=128, null=True)
    file_type = fields.CharField(max_length=128, null=True)
    size = fields.BigIntField(null=True)
    url = fields.TextField(null=True)


class StripeFileLink(StripeSyncModel):
    file_stripe_id = fields.CharField(max_length=255, null=True)
    url = fields.TextField(null=True)
    expired = fields.BooleanField(default=False)
    expires_at = fields.DatetimeField(null=True)


class StripeFileUpload(StripeSyncModel):
    filename = fields.CharField(max_length=255, null=True)
    purpose = fields.CharField(max_length=128, null=True)
    file_type = fields.CharField(max_length=128, null=True)
    size = fields.BigIntField(null=True)
    url = fields.TextField(null=True)


class StripeMandate(StripeSyncModel):
    customer_acceptance_json = fields.JSONField(default=dict)
    payment_method_stripe_id = fields.CharField(max_length=255, null=True)
    mandate_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeRefund(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    reason = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeSetupIntent(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    payment_method_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    usage = fields.CharField(max_length=64, null=True)
    client_secret = fields.CharField(max_length=255, null=True)


class StripePayout(StripeSyncModel):
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    arrival_date = fields.DatetimeField(null=True)
    payout_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeGenericPaymentMethod(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    method_type = fields.CharField(max_length=64, null=True)
    billing_details_json = fields.JSONField(default=dict)


class StripeBankAccount(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    bank_name = fields.CharField(max_length=255, null=True)
    country = fields.CharField(max_length=8, null=True)
    currency = fields.CharField(max_length=12, null=True)
    last4 = fields.CharField(max_length=8, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeCard(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    brand = fields.CharField(max_length=64, null=True)
    country = fields.CharField(max_length=8, null=True)
    exp_month = fields.IntField(null=True)
    exp_year = fields.IntField(null=True)
    funding = fields.CharField(max_length=64, null=True)
    last4 = fields.CharField(max_length=8, null=True)


class StripeSource(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    source_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeSourceTransaction(StripeSyncModel):
    source_stripe_id = fields.CharField(max_length=255, null=True)
    source_transaction_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeApplicationFee(StripeSyncModel):
    account_stripe_id = fields.CharField(max_length=255, null=True)
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    amount_refunded = fields.BigIntField(null=True)


class StripeApplicationFeeRefund(StripeSyncModel):
    application_fee_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeCountrySpec(StripeSyncModel):
    default_currency = fields.CharField(max_length=12, null=True)
    supported_bank_account_currencies_json = fields.JSONField(default=dict)
    supported_payment_currencies_json = fields.JSONField(default=list)
    supported_payment_methods_json = fields.JSONField(default=list)


class StripeTransfer(StripeSyncModel):
    destination_account_stripe_id = fields.CharField(max_length=255, null=True)
    destination_payment_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    reversed = fields.BooleanField(default=False)


class StripeTransferReversal(StripeSyncModel):
    transfer_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeFeature(StripeSyncModel):
    feature_name = fields.CharField(max_length=255, null=True)
    lookup_key = fields.CharField(max_length=255, null=True)
    active = fields.BooleanField(default=True)


class StripeProductFeature(StripeSyncModel):
    product_stripe_id = fields.CharField(max_length=255, null=True)
    feature_stripe_id = fields.CharField(max_length=255, null=True)


class StripeActiveEntitlement(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    lookup_key = fields.CharField(max_length=255, null=True)
    feature_stripe_id = fields.CharField(max_length=255, null=True)


class StripeVerificationSession(StripeSyncModel):
    client_secret = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    verification_type = fields.CharField(max_length=64, null=True)
    url = fields.TextField(null=True)


class StripeVerificationReport(StripeSyncModel):
    verification_session_stripe_id = fields.CharField(max_length=255, null=True)
    report_type = fields.CharField(max_length=64, null=True)
    document_json = fields.JSONField(default=dict)
    selfie_json = fields.JSONField(default=dict)


class StripeIssuingAuthorization(StripeSyncModel):
    card_stripe_id = fields.CharField(max_length=255, null=True)
    cardholder_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    approved = fields.BooleanField(default=False)
    status = fields.CharField(max_length=64, null=True)


class StripeIssuingCardholder(StripeSyncModel):
    email = fields.CharField(max_length=320, null=True)
    name = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    cardholder_type = fields.CharField(max_length=64, null=True)


class StripeIssuingCard(StripeSyncModel):
    brand = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    exp_month = fields.IntField(null=True)
    exp_year = fields.IntField(null=True)
    last4 = fields.CharField(max_length=8, null=True)
    status = fields.CharField(max_length=64, null=True)
    cardholder_stripe_id = fields.CharField(max_length=255, null=True)


class StripeIssuingDispute(StripeSyncModel):
    transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeIssuingTransaction(StripeSyncModel):
    card_stripe_id = fields.CharField(max_length=255, null=True)
    cardholder_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    transaction_type = fields.CharField(max_length=64, null=True)


class StripeEarlyFraudWarning(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    actionable = fields.BooleanField(default=False)
    fraud_type = fields.CharField(max_length=64, null=True)


class StripeReview(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    open = fields.BooleanField(default=False)
    reason = fields.CharField(max_length=255, null=True)
    closed_reason = fields.CharField(max_length=255, null=True)


class StripeScheduledQueryRun(StripeSyncModel):
    file_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    title = fields.CharField(max_length=255, null=True)


class StripePricingTable(StripeSyncModel):
    active = fields.BooleanField(default=True)
    pricing_table_json = fields.JSONField(default=dict)


__models__ = [
    StripeCustomer,
    StripeProduct,
    StripePrice,
    StripePaymentMethod,
    StripePaymentIntent,
    StripeSubscription,
    StripeSubscriptionItem,
    StripeInvoice,
    StripeInvoiceLine,
    StripeCheckoutSession,
    StripeWebhookEndpoint,
    StripeWebhookEvent,
    StripeWebhookDelivery,
    StripeSyncRun,
    PaymentsSetting,
    BillingAccount,
    ProductConfig,
    Meter,
    InternalMeterEvent,
    CreditLedgerEntry,
    StripeAccount,
    StripeApiKey,
    StripeIdempotencyKey,
    StripeCoupon,
    StripePromotionCode,
    StripeDiscount,
    StripeInvoiceItem,
    StripeLineItem,
    StripePlan,
    StripeSubscriptionSchedule,
    StripeShippingRate,
    StripeTaxCode,
    StripeTaxId,
    StripeTaxRate,
    StripeUpcomingInvoice,
    StripeBalanceTransaction,
    StripeCharge,
    StripeDispute,
    StripeEvent,
    StripeFile,
    StripeFileLink,
    StripeFileUpload,
    StripeMandate,
    StripeRefund,
    StripeSetupIntent,
    StripePayout,
    StripeGenericPaymentMethod,
    StripeBankAccount,
    StripeCard,
    StripeSource,
    StripeSourceTransaction,
    StripeApplicationFee,
    StripeApplicationFeeRefund,
    StripeCountrySpec,
    StripeTransfer,
    StripeTransferReversal,
    StripeFeature,
    StripeProductFeature,
    StripeActiveEntitlement,
    StripeVerificationSession,
    StripeVerificationReport,
    StripeIssuingAuthorization,
    StripeIssuingCard,
    StripeIssuingCardholder,
    StripeIssuingDispute,
    StripeIssuingTransaction,
    StripeEarlyFraudWarning,
    StripeReview,
    StripeScheduledQueryRun,
    StripePricingTable,
]
