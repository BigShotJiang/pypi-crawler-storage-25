from __future__ import annotations

import logging

from tortoise import Tortoise

logger = logging.getLogger(__name__)

CREDIT_BALANCE_MONTHLY_VIEW = """\
CREATE OR REPLACE VIEW credit_balance_monthly_view AS
SELECT
    billing_account_id,
    date_trunc('month', effective_at) AS month,
    SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS granted,
    SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END) AS consumed,
    SUM(amount) AS net
FROM creditledgerentry
GROUP BY billing_account_id, date_trunc('month', effective_at);
"""


async def create_pg_views() -> None:
    conn = Tortoise.get_connection("default")
    str(getattr(conn, "filename", "") or getattr(conn, "_pool", ""))

    try:
        await conn.execute_query(CREDIT_BALANCE_MONTHLY_VIEW)
        logger.info("Created credit_balance_monthly_view")
    except Exception:  # noqa: BLE001
        logger.debug("Skipping DB views (not Postgres or view already exists)")
