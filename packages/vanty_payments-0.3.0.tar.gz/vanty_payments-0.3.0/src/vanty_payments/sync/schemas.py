from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from vanty_payments.sync.stripe_sync import STRIPE_SYNC_OBJECT_TYPES

SUPPORTED_SYNC_OBJECT_TYPES = {
    "checkout.session",
    "customer",
    "invoice",
    "payment_intent",
    "price",
    "product",
    "subscription",
} | STRIPE_SYNC_OBJECT_TYPES


class BootstrapSyncRequest(BaseModel):
    object_types: list[str] = Field(default_factory=lambda: ["product", "price", "coupon", "charge"])
    limit: int = 100

    @field_validator("object_types")
    @classmethod
    def validate_object_types(cls, value: list[str]) -> list[str]:
        invalid = sorted(set(value) - SUPPORTED_SYNC_OBJECT_TYPES)
        if invalid:
            raise ValueError(f"Unsupported sync object types: {', '.join(invalid)}")
        return value


class SyncObjectRequest(BaseModel):
    object_type: str
    stripe_id: str

    @field_validator("object_type")
    @classmethod
    def validate_object_type(cls, value: str) -> str:
        if value not in SUPPORTED_SYNC_OBJECT_TYPES:
            raise ValueError(f"Unsupported sync object type: {value}")
        return value


class SyncRunResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    mode: str
    object_types: list[str] = Field(validation_alias="object_types_json")
    counts: dict[str, int] = Field(validation_alias="counts_json")
    failures: list[dict[str, Any]] = Field(validation_alias="failures_json")
    started_at: datetime
    finished_at: datetime | None = None
    succeeded: bool
