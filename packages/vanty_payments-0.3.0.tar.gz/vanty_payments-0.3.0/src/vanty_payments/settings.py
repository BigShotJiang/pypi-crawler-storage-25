from __future__ import annotations

from functools import cached_property
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class PaymentsSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="PAYMENTS_",
        env_file=".env",
        env_nested_delimiter="__",
        extra="ignore",
    )

    app_name: str = "vanty-payments"
    base_url: str = "http://localhost:8000"
    stripe_mode: Literal["test", "live"] = "test"
    stripe_api_version: str = "2020-08-27"
    stripe_test_secret_key: str = ""
    stripe_live_secret_key: str = ""
    stripe_publishable_key: str | None = None
    stripe_webhook_secret: str = ""
    default_currency: str = "usd"
    checkout_success_url: str = "http://localhost:8000/payments/success"
    checkout_cancel_url: str = "http://localhost:8000/payments/cancel"
    billing_portal_return_url: str = "http://localhost:8000/settings/billing"
    webhook_tolerance_seconds: int = 300
    debug_expose_secrets: bool = False
    customer_metadata_user_key: str = "vanty_user_reference"
    customer_metadata_org_key: str = "vanty_organization_reference"

    billing_usage_mode: str = "internal"
    billing_event_routing: dict[str, str] = {}
    billing_credits_enabled: bool = False
    credit_factor: int = 100
    stripe_trial_period_days: int = 14
    stripe_automatic_tax_enabled: bool = True
    stripe_cancel_at_period_end: bool = True
    app_billing_gate_mode: str = "free_access"
    app_signup_flow: str = "free"
    app_credits_gated: bool = False

    @property
    def livemode(self) -> bool:
        return self.stripe_mode == "live"

    @cached_property
    def stripe_secret_key(self) -> str:
        if self.livemode:
            return self.stripe_live_secret_key or self.stripe_test_secret_key
        return self.stripe_test_secret_key or self.stripe_live_secret_key
