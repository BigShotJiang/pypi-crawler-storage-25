"""
Fee Costs tools — management fees, carried interest, and other fund expenses (CRU).

No delete support — fee records are immutable once created.
"""

from typing import Literal

from ..server import mcp
from ..client import v7

# Match Zod schemas: feeCostTypeEnum, frequencyEnum
FeeCostType = Literal["MANAGEMENT", "PERFORMANCE", "SETUP", "ADMINISTRATIVE", "LEGAL", "AUDIT", "CUSTODIAN", "OTHER"]
Frequency = Literal["ONE_TIME", "MONTHLY", "QUARTERLY", "ANNUAL"]


# ==========================================
# Fee Costs
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_fee_costs() -> str:
    """List all fee cost entries."""
    result = await v7.get("/api/assetmanager/portfolio/fee-costs")
    items = result.get("data", [])

    if not items:
        return "No fee costs found."

    lines = [f"Fee Costs ({len(items)}):"]
    for f in items:
        lines.append(
            f"  - id={f['id']} | type={f.get('feeCostType', '—')} | "
            f"fund_id={f.get('fundId', '—')} | amount={f.get('amount', '—')} | "
            f"frequency={f.get('frequency', '—')} | date={f.get('date', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_fee_cost(fee_cost_id: int) -> str:
    """Get details of a specific fee cost entry by ID."""
    result = await v7.get(f"/api/assetmanager/portfolio/fee-costs/{fee_cost_id}")
    f = result.get("data")

    if not f:
        return f"Fee cost {fee_cost_id} not found."

    return (
        f"Fee Cost (id={f['id']})\n"
        f"  Fee Cost Type: {f.get('feeCostType', '—')}\n"
        f"  Fund ID: {f.get('fundId', '—')}\n"
        f"  Amount: {f.get('amount', '—')}\n"
        f"  Frequency: {f.get('frequency', '—')}\n"
        f"  Date: {f.get('date', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_fee_cost(
    fee_cost_type: FeeCostType,
    fund_id: int,
    amount: float,
    frequency: Frequency,
    date: str,
) -> str:
    """Create a new fee cost entry. Date format: YYYY-MM-DD. All fields required."""
    payload: dict = {
        "feeCostType": fee_cost_type,
        "fundId": fund_id,
        "amount": amount,
        "frequency": frequency,
        "date": date,
    }

    result = await v7.post("/api/assetmanager/portfolio/fee-costs", payload)
    f = result["data"]
    return f"Fee cost created (id={f['id']}, type={f.get('feeCostType')}, amount={f.get('amount')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_fee_cost(
    fee_cost_id: int,
    fee_cost_type: FeeCostType | None = None,
    fund_id: int | None = None,
    amount: float | None = None,
    frequency: Frequency | None = None,
    date: str | None = None,
) -> str:
    """Update an existing fee cost entry by ID. Date format: YYYY-MM-DD."""
    payload: dict = {}
    if fee_cost_type is not None:
        payload["feeCostType"] = fee_cost_type
    if fund_id is not None:
        payload["fundId"] = fund_id
    if amount is not None:
        payload["amount"] = amount
    if frequency is not None:
        payload["frequency"] = frequency
    if date is not None:
        payload["date"] = date

    result = await v7.put(f"/api/assetmanager/portfolio/fee-costs/{fee_cost_id}", payload)
    f = result["data"]
    return f"Fee cost updated (id={f['id']}, type={f.get('feeCostType')}, amount={f.get('amount')})."
