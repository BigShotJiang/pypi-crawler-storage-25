"""
Audit Trail tools — read-only access to the audit log.

Supports filtering by table name, action type, and date range.
"""

from ..server import mcp
from ..client import v7


# ==========================================
# Audit Logs
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_audit_logs(
    table_name: str | None = None,
    action: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
) -> str:
    """List audit log entries with optional filters. Date format: YYYY-MM-DD."""
    params: dict = {}
    if table_name is not None:
        params["tableName"] = table_name
    if action is not None:
        params["action"] = action
    if date_from is not None:
        params["dateFrom"] = date_from
    if date_to is not None:
        params["dateTo"] = date_to

    result = await v7.get("/api/assetmanager/audit", params=params)
    items = result.get("data", [])

    if not items:
        return "No audit log entries found."

    lines = [f"Audit Logs ({len(items)}):"]
    for a in items:
        lines.append(
            f"  - id={a.get('id', '—')} | table={a.get('tableName', '—')} | "
            f"action={a.get('action', '—')} | date={a.get('createdAt', '—')} | "
            f"user={a.get('userId', '—')}"
        )

    return "\n".join(lines)
