"""
Companies tools — companies, income statements, balance sheets, cash flow statements,
financial metrics, KPI definitions, KPI values.

CRU operations (create, read, update — no delete via MCP).
"""

from typing import Literal

from ..server import mcp
from ..client import v7


# ==========================================
# Companies
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_companies() -> str:
    """List all companies."""
    result = await v7.get("/api/assetmanager/companies/companies")
    items = result.get("data", [])

    if not items:
        return "No companies found."

    lines = [f"Companies ({len(items)}):"]
    for c in items:
        lines.append(f"  - {c['name']} (id={c['id']}, currency={c.get('currency', '—')}, country={c.get('country', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_company(company_id: int) -> str:
    """Get details of a specific company by ID."""
    result = await v7.get(f"/api/assetmanager/companies/companies/{company_id}")
    c = result.get("data")

    if not c:
        return f"Company {company_id} not found."

    return (
        f"Company: {c['name']} (id={c['id']})\n"
        f"  Country: {c.get('country', '—')}\n"
        f"  Website: {c.get('website', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_company(
    name: str,
    currency: str = "EUR",
    website: str | None = None,
    country: str | None = None,
) -> str:
    """Create a new company. Currency defaults to EUR."""
    payload: dict = {"name": name, "currency": currency}
    if website:
        payload["website"] = website
    if country:
        payload["country"] = country

    result = await v7.post("/api/assetmanager/companies/companies", payload)
    c = result["data"]
    return f"Company created: {c['name']} (id={c['id']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_company(
    company_id: int,
    name: str | None = None,
    currency: str | None = None,
    website: str | None = None,
    country: str | None = None,
) -> str:
    """Update an existing company by ID."""
    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if website is not None:
        payload["website"] = website
    if currency is not None:
        payload["currency"] = currency
    if country is not None:
        payload["country"] = country

    result = await v7.put(f"/api/assetmanager/companies/companies/{company_id}", payload)
    c = result["data"]
    return f"Company updated: {c['name']} (id={c['id']})."


# ==========================================
# Income Statements
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_income_statements() -> str:
    """List all income statements."""
    result = await v7.get("/api/assetmanager/companies/income-statements")
    items = result.get("data", [])

    if not items:
        return "No income statements found."

    lines = [f"Income Statements ({len(items)}):"]
    for i in items:
        lines.append(
            f"  - id={i['id']} | company_id={i['companyId']} | year={i['year']} | "
            f"scenario={i.get('scenario', '—')} | revenue={i.get('revenue', '—')} | "
            f"netIncome={i.get('netIncome', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_income_statement(income_statement_id: int) -> str:
    """Get details of a specific income statement by ID."""
    result = await v7.get(f"/api/assetmanager/companies/income-statements/{income_statement_id}")
    i = result.get("data")

    if not i:
        return f"Income statement {income_statement_id} not found."

    return (
        f"Income Statement (id={i['id']}, company_id={i['companyId']}, year={i['year']})\n"
        f"  Scenario: {i.get('scenario', '—')}\n"
        f"  Semester: {i.get('semester', '—')} | Quarter: {i.get('quarter', '—')} | Month: {i.get('month', '—')}\n"
        f"  Period: {i.get('periodStart', '—')} to {i.get('periodEnd', '—')}\n"
        f"  Revenue: {i.get('revenue', '—')}\n"
        f"  Cost of Goods: {i.get('costOfGoods', '—')}\n"
        f"  Gross Profit: {i.get('grossProfit', '—')}\n"
        f"  R&D: {i.get('researchAndDevelopment', '—')}\n"
        f"  SG&A: {i.get('sellingGeneralAndAdministrative', '—')}\n"
        f"  Operating Income: {i.get('operatingIncome', '—')}\n"
        f"  Pretax Income: {i.get('pretaxIncome', '—')}\n"
        f"  Income Tax: {i.get('incomeTax', '—')}\n"
        f"  Net Income: {i.get('netIncome', '—')}\n"
        f"  EBITDA: {i.get('ebitda', '—')}\n"
        f"  EPS Basic: {i.get('epsBasic', '—')} | EPS Diluted: {i.get('epsDiluted', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_income_statement(
    company_id: int,
    year: int,
    scenario: Literal["Actual", "Forecast", "Budget"] = "Actual",
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    period_start: str | None = None,
    period_end: str | None = None,
    revenue: float | None = None,
    cost_of_goods: float | None = None,
    gross_profit: float | None = None,
    research_and_development: float | None = None,
    selling_general_and_administrative: float | None = None,
    other_operating_expenses: float | None = None,
    operating_income: float | None = None,
    non_operating_interest_income: float | None = None,
    non_operating_interest_expense: float | None = None,
    other_income_expense: float | None = None,
    pretax_income: float | None = None,
    income_tax: float | None = None,
    net_income: float | None = None,
    eps_basic: float | None = None,
    eps_diluted: float | None = None,
    basic_shares_outstanding: float | None = None,
    diluted_shares_outstanding: float | None = None,
    ebitda: float | None = None,
    net_income_continuous_operations: float | None = None,
    minority_interests: float | None = None,
    preferred_stock_dividends: float | None = None,
) -> str:
    """Create a new income statement. Date format: YYYY-MM-DD."""
    payload: dict = {"companyId": company_id, "year": year, "scenario": scenario}
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if period_start is not None:
        payload["periodStart"] = period_start
    if period_end is not None:
        payload["periodEnd"] = period_end
    if revenue is not None:
        payload["revenue"] = revenue
    if cost_of_goods is not None:
        payload["costOfGoods"] = cost_of_goods
    if gross_profit is not None:
        payload["grossProfit"] = gross_profit
    if research_and_development is not None:
        payload["researchAndDevelopment"] = research_and_development
    if selling_general_and_administrative is not None:
        payload["sellingGeneralAndAdministrative"] = selling_general_and_administrative
    if other_operating_expenses is not None:
        payload["otherOperatingExpenses"] = other_operating_expenses
    if operating_income is not None:
        payload["operatingIncome"] = operating_income
    if non_operating_interest_income is not None:
        payload["nonOperatingInterestIncome"] = non_operating_interest_income
    if non_operating_interest_expense is not None:
        payload["nonOperatingInterestExpense"] = non_operating_interest_expense
    if other_income_expense is not None:
        payload["otherIncomeExpense"] = other_income_expense
    if pretax_income is not None:
        payload["pretaxIncome"] = pretax_income
    if income_tax is not None:
        payload["incomeTax"] = income_tax
    if net_income is not None:
        payload["netIncome"] = net_income
    if eps_basic is not None:
        payload["epsBasic"] = eps_basic
    if eps_diluted is not None:
        payload["epsDiluted"] = eps_diluted
    if basic_shares_outstanding is not None:
        payload["basicSharesOutstanding"] = basic_shares_outstanding
    if diluted_shares_outstanding is not None:
        payload["dilutedSharesOutstanding"] = diluted_shares_outstanding
    if ebitda is not None:
        payload["ebitda"] = ebitda
    if net_income_continuous_operations is not None:
        payload["netIncomeContinuousOperations"] = net_income_continuous_operations
    if minority_interests is not None:
        payload["minorityInterests"] = minority_interests
    if preferred_stock_dividends is not None:
        payload["preferredStockDividends"] = preferred_stock_dividends

    result = await v7.post("/api/assetmanager/companies/income-statements", payload)
    s = result["data"]
    return f"Income statement created (id={s['id']}, company_id={s['companyId']}, year={s['year']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_income_statement(
    income_statement_id: int,
    company_id: int | None = None,
    year: int | None = None,
    scenario: Literal["Actual", "Forecast", "Budget"] | None = None,
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    period_start: str | None = None,
    period_end: str | None = None,
    revenue: float | None = None,
    cost_of_goods: float | None = None,
    gross_profit: float | None = None,
    research_and_development: float | None = None,
    selling_general_and_administrative: float | None = None,
    other_operating_expenses: float | None = None,
    operating_income: float | None = None,
    non_operating_interest_income: float | None = None,
    non_operating_interest_expense: float | None = None,
    other_income_expense: float | None = None,
    pretax_income: float | None = None,
    income_tax: float | None = None,
    net_income: float | None = None,
    eps_basic: float | None = None,
    eps_diluted: float | None = None,
    basic_shares_outstanding: float | None = None,
    diluted_shares_outstanding: float | None = None,
    ebitda: float | None = None,
    net_income_continuous_operations: float | None = None,
    minority_interests: float | None = None,
    preferred_stock_dividends: float | None = None,
) -> str:
    """Update an existing income statement by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if year is not None:
        payload["year"] = year
    if scenario is not None:
        payload["scenario"] = scenario
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if period_start is not None:
        payload["periodStart"] = period_start
    if period_end is not None:
        payload["periodEnd"] = period_end
    if revenue is not None:
        payload["revenue"] = revenue
    if cost_of_goods is not None:
        payload["costOfGoods"] = cost_of_goods
    if gross_profit is not None:
        payload["grossProfit"] = gross_profit
    if research_and_development is not None:
        payload["researchAndDevelopment"] = research_and_development
    if selling_general_and_administrative is not None:
        payload["sellingGeneralAndAdministrative"] = selling_general_and_administrative
    if other_operating_expenses is not None:
        payload["otherOperatingExpenses"] = other_operating_expenses
    if operating_income is not None:
        payload["operatingIncome"] = operating_income
    if non_operating_interest_income is not None:
        payload["nonOperatingInterestIncome"] = non_operating_interest_income
    if non_operating_interest_expense is not None:
        payload["nonOperatingInterestExpense"] = non_operating_interest_expense
    if other_income_expense is not None:
        payload["otherIncomeExpense"] = other_income_expense
    if pretax_income is not None:
        payload["pretaxIncome"] = pretax_income
    if income_tax is not None:
        payload["incomeTax"] = income_tax
    if net_income is not None:
        payload["netIncome"] = net_income
    if eps_basic is not None:
        payload["epsBasic"] = eps_basic
    if eps_diluted is not None:
        payload["epsDiluted"] = eps_diluted
    if basic_shares_outstanding is not None:
        payload["basicSharesOutstanding"] = basic_shares_outstanding
    if diluted_shares_outstanding is not None:
        payload["dilutedSharesOutstanding"] = diluted_shares_outstanding
    if ebitda is not None:
        payload["ebitda"] = ebitda
    if net_income_continuous_operations is not None:
        payload["netIncomeContinuousOperations"] = net_income_continuous_operations
    if minority_interests is not None:
        payload["minorityInterests"] = minority_interests
    if preferred_stock_dividends is not None:
        payload["preferredStockDividends"] = preferred_stock_dividends

    result = await v7.put(f"/api/assetmanager/companies/income-statements/{income_statement_id}", payload)
    s = result["data"]
    return f"Income statement updated (id={s['id']}, company_id={s['companyId']}, year={s['year']})."


# ==========================================
# Balance Sheets
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_balance_sheets() -> str:
    """List all balance sheets."""
    result = await v7.get("/api/assetmanager/companies/balance-sheets")
    items = result.get("data", [])

    if not items:
        return "No balance sheets found."

    lines = [f"Balance Sheets ({len(items)}):"]
    for b in items:
        lines.append(
            f"  - id={b['id']} | company_id={b['companyId']} | year={b['year']} | "
            f"scenario={b.get('scenario', '—')} | totalAssets={b.get('totalAssets', '—')} | "
            f"totalLiabilities={b.get('totalLiabilities', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_balance_sheet(balance_sheet_id: int) -> str:
    """Get details of a specific balance sheet by ID."""
    result = await v7.get(f"/api/assetmanager/companies/balance-sheets/{balance_sheet_id}")
    b = result.get("data")

    if not b:
        return f"Balance sheet {balance_sheet_id} not found."

    return (
        f"Balance Sheet (id={b['id']}, company_id={b['companyId']}, year={b['year']})\n"
        f"  Scenario: {b.get('scenario', '—')}\n"
        f"  Semester: {b.get('semester', '—')} | Quarter: {b.get('quarter', '—')} | Month: {b.get('month', '—')}\n"
        f"  Date: {b.get('date', '—')}\n"
        f"  -- Current Assets --\n"
        f"  Cash & Equivalents: {b.get('cashAndCashEquivalents', '—')}\n"
        f"  Accounts Receivable: {b.get('accountsReceivable', '—')}\n"
        f"  Inventory: {b.get('inventory', '—')}\n"
        f"  Total Current Assets: {b.get('totalCurrentAssets', '—')}\n"
        f"  -- Non-current Assets --\n"
        f"  Goodwill: {b.get('goodwill', '—')}\n"
        f"  Intangible Assets: {b.get('intangibleAssets', '—')}\n"
        f"  Total Non-current Assets: {b.get('totalNonCurrentAssets', '—')}\n"
        f"  Total Assets: {b.get('totalAssets', '—')}\n"
        f"  -- Current Liabilities --\n"
        f"  Accounts Payable: {b.get('accountsPayable', '—')}\n"
        f"  Short-term Debt: {b.get('shortTermDebt', '—')}\n"
        f"  Total Current Liabilities: {b.get('totalCurrentLiabilities', '—')}\n"
        f"  -- Non-current Liabilities --\n"
        f"  Long-term Debt: {b.get('longTermDebt', '—')}\n"
        f"  Total Non-current Liabilities: {b.get('totalNonCurrentLiabilities', '—')}\n"
        f"  Total Liabilities: {b.get('totalLiabilities', '—')}\n"
        f"  -- Equity --\n"
        f"  Common Stock: {b.get('commonStock', '—')}\n"
        f"  Retained Earnings: {b.get('retainedEarnings', '—')}\n"
        f"  Total Stakeholders Equity: {b.get('totalStakeholdersEquity', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_balance_sheet(
    company_id: int,
    year: int,
    scenario: Literal["Actual", "Forecast", "Budget"] = "Actual",
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    date: str | None = None,
    # Current Assets
    cash: float | None = None,
    cash_equivalents: float | None = None,
    cash_and_cash_equivalents: float | None = None,
    other_short_term_investments: float | None = None,
    accounts_receivable: float | None = None,
    other_receivables: float | None = None,
    inventory: float | None = None,
    prepaid_assets: float | None = None,
    restricted_cash: float | None = None,
    assets_held_for_sale: float | None = None,
    hedging_assets: float | None = None,
    other_current_assets: float | None = None,
    total_current_assets: float | None = None,
    # Non-current Assets
    properties: float | None = None,
    land_and_improvements: float | None = None,
    machinery_furniture_equipment: float | None = None,
    construction_in_progress: float | None = None,
    leases: float | None = None,
    accumulated_depreciation: float | None = None,
    goodwill: float | None = None,
    investment_properties: float | None = None,
    financial_assets: float | None = None,
    intangible_assets: float | None = None,
    investments_and_advances: float | None = None,
    other_non_current_assets: float | None = None,
    total_non_current_assets: float | None = None,
    # Total Assets
    total_assets: float | None = None,
    # Current Liabilities
    accounts_payable: float | None = None,
    accrued_expenses: float | None = None,
    short_term_debt: float | None = None,
    deferred_revenue: float | None = None,
    tax_payable: float | None = None,
    pensions: float | None = None,
    other_current_liabilities: float | None = None,
    total_current_liabilities: float | None = None,
    # Non-current Liabilities
    long_term_provisions: float | None = None,
    long_term_debt: float | None = None,
    provision_for_risks_and_charges: float | None = None,
    deferred_liabilities: float | None = None,
    derivative_product_liabilities: float | None = None,
    other_non_current_liabilities: float | None = None,
    total_non_current_liabilities: float | None = None,
    # Total Liabilities
    total_liabilities: float | None = None,
    # Shareholders' Equity
    common_stock: float | None = None,
    retained_earnings: float | None = None,
    other_stakeholders_equity: float | None = None,
    total_stakeholders_equity: float | None = None,
    additional_paid_in_capital: float | None = None,
    treasury_stock: float | None = None,
    minority_interest: float | None = None,
) -> str:
    """Create a new balance sheet. Date format: YYYY-MM-DD."""
    payload: dict = {"companyId": company_id, "year": year, "scenario": scenario}
    # Period fields
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if date is not None:
        payload["date"] = date
    # Current Assets
    if cash is not None:
        payload["cash"] = cash
    if cash_equivalents is not None:
        payload["cashEquivalents"] = cash_equivalents
    if cash_and_cash_equivalents is not None:
        payload["cashAndCashEquivalents"] = cash_and_cash_equivalents
    if other_short_term_investments is not None:
        payload["otherShortTermInvestments"] = other_short_term_investments
    if accounts_receivable is not None:
        payload["accountsReceivable"] = accounts_receivable
    if other_receivables is not None:
        payload["otherReceivables"] = other_receivables
    if inventory is not None:
        payload["inventory"] = inventory
    if prepaid_assets is not None:
        payload["prepaidAssets"] = prepaid_assets
    if restricted_cash is not None:
        payload["restrictedCash"] = restricted_cash
    if assets_held_for_sale is not None:
        payload["assetsHeldForSale"] = assets_held_for_sale
    if hedging_assets is not None:
        payload["hedgingAssets"] = hedging_assets
    if other_current_assets is not None:
        payload["otherCurrentAssets"] = other_current_assets
    if total_current_assets is not None:
        payload["totalCurrentAssets"] = total_current_assets
    # Non-current Assets
    if properties is not None:
        payload["properties"] = properties
    if land_and_improvements is not None:
        payload["landAndImprovements"] = land_and_improvements
    if machinery_furniture_equipment is not None:
        payload["machineryFurnitureEquipment"] = machinery_furniture_equipment
    if construction_in_progress is not None:
        payload["constructionInProgress"] = construction_in_progress
    if leases is not None:
        payload["leases"] = leases
    if accumulated_depreciation is not None:
        payload["accumulatedDepreciation"] = accumulated_depreciation
    if goodwill is not None:
        payload["goodwill"] = goodwill
    if investment_properties is not None:
        payload["investmentProperties"] = investment_properties
    if financial_assets is not None:
        payload["financialAssets"] = financial_assets
    if intangible_assets is not None:
        payload["intangibleAssets"] = intangible_assets
    if investments_and_advances is not None:
        payload["investmentsAndAdvances"] = investments_and_advances
    if other_non_current_assets is not None:
        payload["otherNonCurrentAssets"] = other_non_current_assets
    if total_non_current_assets is not None:
        payload["totalNonCurrentAssets"] = total_non_current_assets
    # Total Assets
    if total_assets is not None:
        payload["totalAssets"] = total_assets
    # Current Liabilities
    if accounts_payable is not None:
        payload["accountsPayable"] = accounts_payable
    if accrued_expenses is not None:
        payload["accruedExpenses"] = accrued_expenses
    if short_term_debt is not None:
        payload["shortTermDebt"] = short_term_debt
    if deferred_revenue is not None:
        payload["deferredRevenue"] = deferred_revenue
    if tax_payable is not None:
        payload["taxPayable"] = tax_payable
    if pensions is not None:
        payload["pensions"] = pensions
    if other_current_liabilities is not None:
        payload["otherCurrentLiabilities"] = other_current_liabilities
    if total_current_liabilities is not None:
        payload["totalCurrentLiabilities"] = total_current_liabilities
    # Non-current Liabilities
    if long_term_provisions is not None:
        payload["longTermProvisions"] = long_term_provisions
    if long_term_debt is not None:
        payload["longTermDebt"] = long_term_debt
    if provision_for_risks_and_charges is not None:
        payload["provisionForRisksAndCharges"] = provision_for_risks_and_charges
    if deferred_liabilities is not None:
        payload["deferredLiabilities"] = deferred_liabilities
    if derivative_product_liabilities is not None:
        payload["derivativeProductLiabilities"] = derivative_product_liabilities
    if other_non_current_liabilities is not None:
        payload["otherNonCurrentLiabilities"] = other_non_current_liabilities
    if total_non_current_liabilities is not None:
        payload["totalNonCurrentLiabilities"] = total_non_current_liabilities
    # Total Liabilities
    if total_liabilities is not None:
        payload["totalLiabilities"] = total_liabilities
    # Shareholders' Equity
    if common_stock is not None:
        payload["commonStock"] = common_stock
    if retained_earnings is not None:
        payload["retainedEarnings"] = retained_earnings
    if other_stakeholders_equity is not None:
        payload["otherStakeholdersEquity"] = other_stakeholders_equity
    if total_stakeholders_equity is not None:
        payload["totalStakeholdersEquity"] = total_stakeholders_equity
    if additional_paid_in_capital is not None:
        payload["additionalPaidInCapital"] = additional_paid_in_capital
    if treasury_stock is not None:
        payload["treasuryStock"] = treasury_stock
    if minority_interest is not None:
        payload["minorityInterest"] = minority_interest

    result = await v7.post("/api/assetmanager/companies/balance-sheets", payload)
    b = result["data"]
    return f"Balance sheet created (id={b['id']}, company_id={b['companyId']}, year={b['year']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_balance_sheet(
    balance_sheet_id: int,
    company_id: int | None = None,
    year: int | None = None,
    scenario: Literal["Actual", "Forecast", "Budget"] | None = None,
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    date: str | None = None,
    # Current Assets
    cash: float | None = None,
    cash_equivalents: float | None = None,
    cash_and_cash_equivalents: float | None = None,
    other_short_term_investments: float | None = None,
    accounts_receivable: float | None = None,
    other_receivables: float | None = None,
    inventory: float | None = None,
    prepaid_assets: float | None = None,
    restricted_cash: float | None = None,
    assets_held_for_sale: float | None = None,
    hedging_assets: float | None = None,
    other_current_assets: float | None = None,
    total_current_assets: float | None = None,
    # Non-current Assets
    properties: float | None = None,
    land_and_improvements: float | None = None,
    machinery_furniture_equipment: float | None = None,
    construction_in_progress: float | None = None,
    leases: float | None = None,
    accumulated_depreciation: float | None = None,
    goodwill: float | None = None,
    investment_properties: float | None = None,
    financial_assets: float | None = None,
    intangible_assets: float | None = None,
    investments_and_advances: float | None = None,
    other_non_current_assets: float | None = None,
    total_non_current_assets: float | None = None,
    # Total Assets
    total_assets: float | None = None,
    # Current Liabilities
    accounts_payable: float | None = None,
    accrued_expenses: float | None = None,
    short_term_debt: float | None = None,
    deferred_revenue: float | None = None,
    tax_payable: float | None = None,
    pensions: float | None = None,
    other_current_liabilities: float | None = None,
    total_current_liabilities: float | None = None,
    # Non-current Liabilities
    long_term_provisions: float | None = None,
    long_term_debt: float | None = None,
    provision_for_risks_and_charges: float | None = None,
    deferred_liabilities: float | None = None,
    derivative_product_liabilities: float | None = None,
    other_non_current_liabilities: float | None = None,
    total_non_current_liabilities: float | None = None,
    # Total Liabilities
    total_liabilities: float | None = None,
    # Shareholders' Equity
    common_stock: float | None = None,
    retained_earnings: float | None = None,
    other_stakeholders_equity: float | None = None,
    total_stakeholders_equity: float | None = None,
    additional_paid_in_capital: float | None = None,
    treasury_stock: float | None = None,
    minority_interest: float | None = None,
) -> str:
    """Update an existing balance sheet by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if year is not None:
        payload["year"] = year
    if scenario is not None:
        payload["scenario"] = scenario
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if date is not None:
        payload["date"] = date
    # Current Assets
    if cash is not None:
        payload["cash"] = cash
    if cash_equivalents is not None:
        payload["cashEquivalents"] = cash_equivalents
    if cash_and_cash_equivalents is not None:
        payload["cashAndCashEquivalents"] = cash_and_cash_equivalents
    if other_short_term_investments is not None:
        payload["otherShortTermInvestments"] = other_short_term_investments
    if accounts_receivable is not None:
        payload["accountsReceivable"] = accounts_receivable
    if other_receivables is not None:
        payload["otherReceivables"] = other_receivables
    if inventory is not None:
        payload["inventory"] = inventory
    if prepaid_assets is not None:
        payload["prepaidAssets"] = prepaid_assets
    if restricted_cash is not None:
        payload["restrictedCash"] = restricted_cash
    if assets_held_for_sale is not None:
        payload["assetsHeldForSale"] = assets_held_for_sale
    if hedging_assets is not None:
        payload["hedgingAssets"] = hedging_assets
    if other_current_assets is not None:
        payload["otherCurrentAssets"] = other_current_assets
    if total_current_assets is not None:
        payload["totalCurrentAssets"] = total_current_assets
    # Non-current Assets
    if properties is not None:
        payload["properties"] = properties
    if land_and_improvements is not None:
        payload["landAndImprovements"] = land_and_improvements
    if machinery_furniture_equipment is not None:
        payload["machineryFurnitureEquipment"] = machinery_furniture_equipment
    if construction_in_progress is not None:
        payload["constructionInProgress"] = construction_in_progress
    if leases is not None:
        payload["leases"] = leases
    if accumulated_depreciation is not None:
        payload["accumulatedDepreciation"] = accumulated_depreciation
    if goodwill is not None:
        payload["goodwill"] = goodwill
    if investment_properties is not None:
        payload["investmentProperties"] = investment_properties
    if financial_assets is not None:
        payload["financialAssets"] = financial_assets
    if intangible_assets is not None:
        payload["intangibleAssets"] = intangible_assets
    if investments_and_advances is not None:
        payload["investmentsAndAdvances"] = investments_and_advances
    if other_non_current_assets is not None:
        payload["otherNonCurrentAssets"] = other_non_current_assets
    if total_non_current_assets is not None:
        payload["totalNonCurrentAssets"] = total_non_current_assets
    # Total Assets
    if total_assets is not None:
        payload["totalAssets"] = total_assets
    # Current Liabilities
    if accounts_payable is not None:
        payload["accountsPayable"] = accounts_payable
    if accrued_expenses is not None:
        payload["accruedExpenses"] = accrued_expenses
    if short_term_debt is not None:
        payload["shortTermDebt"] = short_term_debt
    if deferred_revenue is not None:
        payload["deferredRevenue"] = deferred_revenue
    if tax_payable is not None:
        payload["taxPayable"] = tax_payable
    if pensions is not None:
        payload["pensions"] = pensions
    if other_current_liabilities is not None:
        payload["otherCurrentLiabilities"] = other_current_liabilities
    if total_current_liabilities is not None:
        payload["totalCurrentLiabilities"] = total_current_liabilities
    # Non-current Liabilities
    if long_term_provisions is not None:
        payload["longTermProvisions"] = long_term_provisions
    if long_term_debt is not None:
        payload["longTermDebt"] = long_term_debt
    if provision_for_risks_and_charges is not None:
        payload["provisionForRisksAndCharges"] = provision_for_risks_and_charges
    if deferred_liabilities is not None:
        payload["deferredLiabilities"] = deferred_liabilities
    if derivative_product_liabilities is not None:
        payload["derivativeProductLiabilities"] = derivative_product_liabilities
    if other_non_current_liabilities is not None:
        payload["otherNonCurrentLiabilities"] = other_non_current_liabilities
    if total_non_current_liabilities is not None:
        payload["totalNonCurrentLiabilities"] = total_non_current_liabilities
    # Total Liabilities
    if total_liabilities is not None:
        payload["totalLiabilities"] = total_liabilities
    # Shareholders' Equity
    if common_stock is not None:
        payload["commonStock"] = common_stock
    if retained_earnings is not None:
        payload["retainedEarnings"] = retained_earnings
    if other_stakeholders_equity is not None:
        payload["otherStakeholdersEquity"] = other_stakeholders_equity
    if total_stakeholders_equity is not None:
        payload["totalStakeholdersEquity"] = total_stakeholders_equity
    if additional_paid_in_capital is not None:
        payload["additionalPaidInCapital"] = additional_paid_in_capital
    if treasury_stock is not None:
        payload["treasuryStock"] = treasury_stock
    if minority_interest is not None:
        payload["minorityInterest"] = minority_interest

    result = await v7.put(f"/api/assetmanager/companies/balance-sheets/{balance_sheet_id}", payload)
    b = result["data"]
    return f"Balance sheet updated (id={b['id']}, company_id={b['companyId']}, year={b['year']})."


# ==========================================
# Cash Flow Statements
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_cash_flow_statements() -> str:
    """List all cash flow statements."""
    result = await v7.get("/api/assetmanager/companies/cash-flow-statements")
    items = result.get("data", [])

    if not items:
        return "No cash flow statements found."

    lines = [f"Cash Flow Statements ({len(items)}):"]
    for c in items:
        lines.append(
            f"  - id={c['id']} | company_id={c['companyId']} | year={c['year']} | "
            f"scenario={c.get('scenario', '—')} | operatingCF={c.get('operatingCashFlow', '—')} | "
            f"freeCF={c.get('freeCashFlow', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_cash_flow_statement(cash_flow_statement_id: int) -> str:
    """Get details of a specific cash flow statement by ID."""
    result = await v7.get(f"/api/assetmanager/companies/cash-flow-statements/{cash_flow_statement_id}")
    c = result.get("data")

    if not c:
        return f"Cash flow statement {cash_flow_statement_id} not found."

    return (
        f"Cash Flow Statement (id={c['id']}, company_id={c['companyId']}, year={c['year']})\n"
        f"  Scenario: {c.get('scenario', '—')}\n"
        f"  Semester: {c.get('semester', '—')} | Quarter: {c.get('quarter', '—')} | Month: {c.get('month', '—')}\n"
        f"  Period: {c.get('periodStart', '—')} to {c.get('periodEnd', '—')}\n"
        f"  -- Operating Activities --\n"
        f"  Net Income: {c.get('netIncome', '—')}\n"
        f"  Depreciation: {c.get('depreciation', '—')}\n"
        f"  Stock-based Compensation: {c.get('stockBasedCompensation', '—')}\n"
        f"  Operating Cash Flow: {c.get('operatingCashFlow', '—')}\n"
        f"  -- Investing Activities --\n"
        f"  Capital Expenditures: {c.get('capitalExpenditures', '—')}\n"
        f"  Net Acquisitions: {c.get('netAcquisitions', '—')}\n"
        f"  Investing Cash Flow: {c.get('investingCashFlow', '—')}\n"
        f"  -- Financing Activities --\n"
        f"  Long-term Debt Issuance: {c.get('longTermDebtIssuance', '—')}\n"
        f"  Common Dividends: {c.get('commonDividends', '—')}\n"
        f"  Financing Cash Flow: {c.get('financingCashFlow', '—')}\n"
        f"  -- Summary --\n"
        f"  End Cash Position: {c.get('endCashPosition', '—')}\n"
        f"  Free Cash Flow: {c.get('freeCashFlow', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_cash_flow_statement(
    company_id: int,
    year: int,
    scenario: Literal["Actual", "Forecast", "Budget"] = "Actual",
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    period_start: str | None = None,
    period_end: str | None = None,
    # Operating activities
    net_income: float | None = None,
    depreciation: float | None = None,
    deferred_taxes: float | None = None,
    stock_based_compensation: float | None = None,
    other_non_cash_items: float | None = None,
    accounts_receivable: float | None = None,
    accounts_payable: float | None = None,
    other_assets_liabilities: float | None = None,
    operating_cash_flow: float | None = None,
    # Investing activities
    capital_expenditures: float | None = None,
    net_intangibles: float | None = None,
    net_acquisitions: float | None = None,
    purchase_of_investments: float | None = None,
    sale_of_investments: float | None = None,
    other_investing_activity: float | None = None,
    investing_cash_flow: float | None = None,
    # Financing activities
    long_term_debt_issuance: float | None = None,
    long_term_debt_payments: float | None = None,
    short_term_debt_issuance: float | None = None,
    common_stock_issuance: float | None = None,
    common_stock_repurchase: float | None = None,
    common_dividends: float | None = None,
    other_financing_charges: float | None = None,
    financing_cash_flow: float | None = None,
    # Summary
    end_cash_position: float | None = None,
    income_tax_paid: float | None = None,
    interest_paid: float | None = None,
    free_cash_flow: float | None = None,
) -> str:
    """Create a new cash flow statement. Date format: YYYY-MM-DD."""
    payload: dict = {"companyId": company_id, "year": year, "scenario": scenario}
    # Period fields
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if period_start is not None:
        payload["periodStart"] = period_start
    if period_end is not None:
        payload["periodEnd"] = period_end
    # Operating activities
    if net_income is not None:
        payload["netIncome"] = net_income
    if depreciation is not None:
        payload["depreciation"] = depreciation
    if deferred_taxes is not None:
        payload["deferredTaxes"] = deferred_taxes
    if stock_based_compensation is not None:
        payload["stockBasedCompensation"] = stock_based_compensation
    if other_non_cash_items is not None:
        payload["otherNonCashItems"] = other_non_cash_items
    if accounts_receivable is not None:
        payload["accountsReceivable"] = accounts_receivable
    if accounts_payable is not None:
        payload["accountsPayable"] = accounts_payable
    if other_assets_liabilities is not None:
        payload["otherAssetsLiabilities"] = other_assets_liabilities
    if operating_cash_flow is not None:
        payload["operatingCashFlow"] = operating_cash_flow
    # Investing activities
    if capital_expenditures is not None:
        payload["capitalExpenditures"] = capital_expenditures
    if net_intangibles is not None:
        payload["netIntangibles"] = net_intangibles
    if net_acquisitions is not None:
        payload["netAcquisitions"] = net_acquisitions
    if purchase_of_investments is not None:
        payload["purchaseOfInvestments"] = purchase_of_investments
    if sale_of_investments is not None:
        payload["saleOfInvestments"] = sale_of_investments
    if other_investing_activity is not None:
        payload["otherInvestingActivity"] = other_investing_activity
    if investing_cash_flow is not None:
        payload["investingCashFlow"] = investing_cash_flow
    # Financing activities
    if long_term_debt_issuance is not None:
        payload["longTermDebtIssuance"] = long_term_debt_issuance
    if long_term_debt_payments is not None:
        payload["longTermDebtPayments"] = long_term_debt_payments
    if short_term_debt_issuance is not None:
        payload["shortTermDebtIssuance"] = short_term_debt_issuance
    if common_stock_issuance is not None:
        payload["commonStockIssuance"] = common_stock_issuance
    if common_stock_repurchase is not None:
        payload["commonStockRepurchase"] = common_stock_repurchase
    if common_dividends is not None:
        payload["commonDividends"] = common_dividends
    if other_financing_charges is not None:
        payload["otherFinancingCharges"] = other_financing_charges
    if financing_cash_flow is not None:
        payload["financingCashFlow"] = financing_cash_flow
    # Summary
    if end_cash_position is not None:
        payload["endCashPosition"] = end_cash_position
    if income_tax_paid is not None:
        payload["incomeTaxPaid"] = income_tax_paid
    if interest_paid is not None:
        payload["interestPaid"] = interest_paid
    if free_cash_flow is not None:
        payload["freeCashFlow"] = free_cash_flow

    result = await v7.post("/api/assetmanager/companies/cash-flow-statements", payload)
    c = result["data"]
    return f"Cash flow statement created (id={c['id']}, company_id={c['companyId']}, year={c['year']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_cash_flow_statement(
    cash_flow_statement_id: int,
    company_id: int | None = None,
    year: int | None = None,
    scenario: Literal["Actual", "Forecast", "Budget"] | None = None,
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    period_start: str | None = None,
    period_end: str | None = None,
    # Operating activities
    net_income: float | None = None,
    depreciation: float | None = None,
    deferred_taxes: float | None = None,
    stock_based_compensation: float | None = None,
    other_non_cash_items: float | None = None,
    accounts_receivable: float | None = None,
    accounts_payable: float | None = None,
    other_assets_liabilities: float | None = None,
    operating_cash_flow: float | None = None,
    # Investing activities
    capital_expenditures: float | None = None,
    net_intangibles: float | None = None,
    net_acquisitions: float | None = None,
    purchase_of_investments: float | None = None,
    sale_of_investments: float | None = None,
    other_investing_activity: float | None = None,
    investing_cash_flow: float | None = None,
    # Financing activities
    long_term_debt_issuance: float | None = None,
    long_term_debt_payments: float | None = None,
    short_term_debt_issuance: float | None = None,
    common_stock_issuance: float | None = None,
    common_stock_repurchase: float | None = None,
    common_dividends: float | None = None,
    other_financing_charges: float | None = None,
    financing_cash_flow: float | None = None,
    # Summary
    end_cash_position: float | None = None,
    income_tax_paid: float | None = None,
    interest_paid: float | None = None,
    free_cash_flow: float | None = None,
) -> str:
    """Update an existing cash flow statement by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if year is not None:
        payload["year"] = year
    if scenario is not None:
        payload["scenario"] = scenario
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if period_start is not None:
        payload["periodStart"] = period_start
    if period_end is not None:
        payload["periodEnd"] = period_end
    # Operating activities
    if net_income is not None:
        payload["netIncome"] = net_income
    if depreciation is not None:
        payload["depreciation"] = depreciation
    if deferred_taxes is not None:
        payload["deferredTaxes"] = deferred_taxes
    if stock_based_compensation is not None:
        payload["stockBasedCompensation"] = stock_based_compensation
    if other_non_cash_items is not None:
        payload["otherNonCashItems"] = other_non_cash_items
    if accounts_receivable is not None:
        payload["accountsReceivable"] = accounts_receivable
    if accounts_payable is not None:
        payload["accountsPayable"] = accounts_payable
    if other_assets_liabilities is not None:
        payload["otherAssetsLiabilities"] = other_assets_liabilities
    if operating_cash_flow is not None:
        payload["operatingCashFlow"] = operating_cash_flow
    # Investing activities
    if capital_expenditures is not None:
        payload["capitalExpenditures"] = capital_expenditures
    if net_intangibles is not None:
        payload["netIntangibles"] = net_intangibles
    if net_acquisitions is not None:
        payload["netAcquisitions"] = net_acquisitions
    if purchase_of_investments is not None:
        payload["purchaseOfInvestments"] = purchase_of_investments
    if sale_of_investments is not None:
        payload["saleOfInvestments"] = sale_of_investments
    if other_investing_activity is not None:
        payload["otherInvestingActivity"] = other_investing_activity
    if investing_cash_flow is not None:
        payload["investingCashFlow"] = investing_cash_flow
    # Financing activities
    if long_term_debt_issuance is not None:
        payload["longTermDebtIssuance"] = long_term_debt_issuance
    if long_term_debt_payments is not None:
        payload["longTermDebtPayments"] = long_term_debt_payments
    if short_term_debt_issuance is not None:
        payload["shortTermDebtIssuance"] = short_term_debt_issuance
    if common_stock_issuance is not None:
        payload["commonStockIssuance"] = common_stock_issuance
    if common_stock_repurchase is not None:
        payload["commonStockRepurchase"] = common_stock_repurchase
    if common_dividends is not None:
        payload["commonDividends"] = common_dividends
    if other_financing_charges is not None:
        payload["otherFinancingCharges"] = other_financing_charges
    if financing_cash_flow is not None:
        payload["financingCashFlow"] = financing_cash_flow
    # Summary
    if end_cash_position is not None:
        payload["endCashPosition"] = end_cash_position
    if income_tax_paid is not None:
        payload["incomeTaxPaid"] = income_tax_paid
    if interest_paid is not None:
        payload["interestPaid"] = interest_paid
    if free_cash_flow is not None:
        payload["freeCashFlow"] = free_cash_flow

    result = await v7.put(f"/api/assetmanager/companies/cash-flow-statements/{cash_flow_statement_id}", payload)
    c = result["data"]
    return f"Cash flow statement updated (id={c['id']}, company_id={c['companyId']}, year={c['year']})."


# ==========================================
# Financial Metrics
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_financial_metrics() -> str:
    """List all financial metrics snapshots."""
    result = await v7.get("/api/assetmanager/companies/financial-metrics")
    items = result.get("data", [])

    if not items:
        return "No financial metrics found."

    lines = [f"Financial Metrics ({len(items)}):"]
    for m in items:
        lines.append(
            f"  - id={m['id']} | company_id={m['companyId']} | year={m['year']} | "
            f"scenario={m.get('scenario', '—')} | periodEnd={m.get('periodEnd', '—')} | "
            f"arr={m.get('arr', '—')} | burnRate={m.get('burnRate', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_financial_metrics(financial_metrics_id: int) -> str:
    """Get details of a specific financial metrics snapshot by ID."""
    result = await v7.get(f"/api/assetmanager/companies/financial-metrics/{financial_metrics_id}")
    m = result.get("data")

    if not m:
        return f"Financial metrics {financial_metrics_id} not found."

    return (
        f"Financial Metrics (id={m['id']}, company_id={m['companyId']}, year={m['year']})\n"
        f"  Scenario: {m.get('scenario', '—')} | Period End: {m.get('periodEnd', '—')}\n"
        f"  Semester: {m.get('semester', '—')} | Quarter: {m.get('quarter', '—')} | Month: {m.get('month', '—')}\n"
        f"  -- Liquidity Ratios --\n"
        f"  Current Ratio: {m.get('currentRatio', '—')} | Quick Ratio: {m.get('quickRatio', '—')}\n"
        f"  -- Profitability Ratios --\n"
        f"  Gross Profit Margin: {m.get('grossProfitMargin', '—')} | Net Profit Margin: {m.get('netProfitMargin', '—')}\n"
        f"  ROA: {m.get('returnOnAssets', '—')} | ROE: {m.get('returnOnEquity', '—')}\n"
        f"  -- Revenue Metrics --\n"
        f"  ARR: {m.get('arr', '—')} | MRR: {m.get('mrr', '—')}\n"
        f"  Revenue Growth Rate: {m.get('revenueGrowthRate', '—')}\n"
        f"  Net Revenue Retention: {m.get('netRevenueRetention', '—')}\n"
        f"  -- Customer Metrics --\n"
        f"  Total Customers: {m.get('totalCustomers', '—')} | CAC: {m.get('cac', '—')} | LTV: {m.get('ltv', '—')}\n"
        f"  -- Operational Metrics --\n"
        f"  Burn Rate: {m.get('burnRate', '—')} | Runway (months): {m.get('runwayMonths', '—')}\n"
        f"  Rule of 40: {m.get('ruleOf40', '—')} | Burn Multiple: {m.get('burnMultiple', '—')}\n"
        f"  -- Team Metrics --\n"
        f"  Total Employees: {m.get('totalEmployees', '—')} | Staff Costs Total: {m.get('staffCostsTotal', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_financial_metrics(
    company_id: int,
    year: int,
    scenario: Literal["Actual", "Forecast", "Budget"] = "Actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    semester: Literal["H1", "H2"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    full_year: bool = False,
    period_end: str | None = None,
    # Ratios: liquidity
    current_ratio: float | None = None,
    quick_ratio: float | None = None,
    cash_ratio: float | None = None,
    operating_cash_flow_ratio: float | None = None,
    # Ratios: solvency
    debt_to_equity_ratio: float | None = None,
    debt_to_assets_ratio: float | None = None,
    interest_coverage_ratio: float | None = None,
    debt_service_coverage_ratio: float | None = None,
    # Ratios: profitability
    gross_profit_margin: float | None = None,
    operating_profit_margin: float | None = None,
    net_profit_margin: float | None = None,
    ebitda_margin: float | None = None,
    return_on_assets: float | None = None,
    return_on_equity: float | None = None,
    return_on_invested_capital: float | None = None,
    # Ratios: efficiency
    asset_turnover_ratio: float | None = None,
    inventory_turnover_ratio: float | None = None,
    receivables_turnover_ratio: float | None = None,
    days_sales_outstanding: float | None = None,
    days_inventory_outstanding: float | None = None,
    days_payables_outstanding: float | None = None,
    # Ratios: investment
    earnings_per_share: float | None = None,
    price_earnings_ratio: float | None = None,
    dividend_yield: float | None = None,
    dividend_payout_ratio: float | None = None,
    book_value_per_share: float | None = None,
    # Revenue metrics
    recurring_revenue: float | None = None,
    non_recurring_revenue: float | None = None,
    revenue_growth_rate: float | None = None,
    existing_customer_existing_seats_revenue: float | None = None,
    existing_customer_additional_seats_revenue: float | None = None,
    new_customer_new_seats_revenue: float | None = None,
    discounts_and_refunds: float | None = None,
    arr: float | None = None,
    mrr: float | None = None,
    average_revenue_per_customer: float | None = None,
    average_contract_value: float | None = None,
    revenue_churn_rate: float | None = None,
    net_revenue_retention: float | None = None,
    gross_revenue_retention: float | None = None,
    growth_rate_cohort_1: float | None = None,
    growth_rate_cohort_2: float | None = None,
    growth_rate_cohort_3: float | None = None,
    # Customer metrics
    total_customers: float | None = None,
    new_customers: float | None = None,
    churned_customers: float | None = None,
    total_users: float | None = None,
    active_users: float | None = None,
    total_monthly_active_client_users: float | None = None,
    existing_customer_existing_seats_users: float | None = None,
    existing_customer_additional_seats_users: float | None = None,
    new_customer_new_seats_users: float | None = None,
    user_growth_rate: float | None = None,
    new_customer_total_addressable_seats: float | None = None,
    new_customer_new_seats_percent_signed: float | None = None,
    new_customer_total_addressable_seats_remaining: float | None = None,
    existing_customer_count: float | None = None,
    existing_customer_expansion_count: float | None = None,
    new_customer_count: float | None = None,
    customer_growth_rate: float | None = None,
    cac: float | None = None,
    ltv: float | None = None,
    ltv_cac_ratio: float | None = None,
    payback_period: float | None = None,
    customer_churn_rate: float | None = None,
    customer_acquisition_efficiency: float | None = None,
    sales_efficiency: float | None = None,
    # Operational metrics
    burn_rate: float | None = None,
    runway_months: float | None = None,
    runway_gross: float | None = None,
    runway_net: float | None = None,
    burn_multiple: float | None = None,
    rule_of_40: float | None = None,
    gross_margin: float | None = None,
    contribution_margin: float | None = None,
    revenue_per_employee: float | None = None,
    profit_per_employee: float | None = None,
    capital_efficiency: float | None = None,
    cash_conversion_cycle: float | None = None,
    capex: float | None = None,
    ebitda: float | None = None,
    total_costs: float | None = None,
    # Team metrics
    total_employees: float | None = None,
    full_time_employees: float | None = None,
    part_time_employees: float | None = None,
    contractors: float | None = None,
    number_of_management: float | None = None,
    number_of_sales_marketing_staff: float | None = None,
    number_of_research_development_staff: float | None = None,
    number_of_customer_service_support_staff: float | None = None,
    number_of_general_staff: float | None = None,
    employee_growth_rate: float | None = None,
    employee_turnover_rate: float | None = None,
    average_tenure_months: float | None = None,
    management_costs: float | None = None,
    sales_marketing_staff_costs: float | None = None,
    research_development_staff_costs: float | None = None,
    customer_service_support_staff_costs: float | None = None,
    general_staff_costs: float | None = None,
    staff_costs_total: float | None = None,
    # Notes
    notes: str | None = None,
) -> str:
    """Create a new financial metrics snapshot. Date format: YYYY-MM-DD."""
    payload: dict = {"companyId": company_id, "year": year, "scenario": scenario, "fullYear": full_year}
    # Period fields
    if quarter is not None:
        payload["quarter"] = quarter
    if semester is not None:
        payload["semester"] = semester
    if month is not None:
        payload["month"] = month
    if period_end is not None:
        payload["periodEnd"] = period_end
    # Ratios: liquidity
    if current_ratio is not None:
        payload["currentRatio"] = current_ratio
    if quick_ratio is not None:
        payload["quickRatio"] = quick_ratio
    if cash_ratio is not None:
        payload["cashRatio"] = cash_ratio
    if operating_cash_flow_ratio is not None:
        payload["operatingCashFlowRatio"] = operating_cash_flow_ratio
    # Ratios: solvency
    if debt_to_equity_ratio is not None:
        payload["debtToEquityRatio"] = debt_to_equity_ratio
    if debt_to_assets_ratio is not None:
        payload["debtToAssetsRatio"] = debt_to_assets_ratio
    if interest_coverage_ratio is not None:
        payload["interestCoverageRatio"] = interest_coverage_ratio
    if debt_service_coverage_ratio is not None:
        payload["debtServiceCoverageRatio"] = debt_service_coverage_ratio
    # Ratios: profitability
    if gross_profit_margin is not None:
        payload["grossProfitMargin"] = gross_profit_margin
    if operating_profit_margin is not None:
        payload["operatingProfitMargin"] = operating_profit_margin
    if net_profit_margin is not None:
        payload["netProfitMargin"] = net_profit_margin
    if ebitda_margin is not None:
        payload["ebitdaMargin"] = ebitda_margin
    if return_on_assets is not None:
        payload["returnOnAssets"] = return_on_assets
    if return_on_equity is not None:
        payload["returnOnEquity"] = return_on_equity
    if return_on_invested_capital is not None:
        payload["returnOnInvestedCapital"] = return_on_invested_capital
    # Ratios: efficiency
    if asset_turnover_ratio is not None:
        payload["assetTurnoverRatio"] = asset_turnover_ratio
    if inventory_turnover_ratio is not None:
        payload["inventoryTurnoverRatio"] = inventory_turnover_ratio
    if receivables_turnover_ratio is not None:
        payload["receivablesTurnoverRatio"] = receivables_turnover_ratio
    if days_sales_outstanding is not None:
        payload["daysSalesOutstanding"] = days_sales_outstanding
    if days_inventory_outstanding is not None:
        payload["daysInventoryOutstanding"] = days_inventory_outstanding
    if days_payables_outstanding is not None:
        payload["daysPayablesOutstanding"] = days_payables_outstanding
    # Ratios: investment
    if earnings_per_share is not None:
        payload["earningsPerShare"] = earnings_per_share
    if price_earnings_ratio is not None:
        payload["priceEarningsRatio"] = price_earnings_ratio
    if dividend_yield is not None:
        payload["dividendYield"] = dividend_yield
    if dividend_payout_ratio is not None:
        payload["dividendPayoutRatio"] = dividend_payout_ratio
    if book_value_per_share is not None:
        payload["bookValuePerShare"] = book_value_per_share
    # Revenue metrics
    if recurring_revenue is not None:
        payload["recurringRevenue"] = recurring_revenue
    if non_recurring_revenue is not None:
        payload["nonRecurringRevenue"] = non_recurring_revenue
    if revenue_growth_rate is not None:
        payload["revenueGrowthRate"] = revenue_growth_rate
    if existing_customer_existing_seats_revenue is not None:
        payload["existingCustomerExistingSeatsRevenue"] = existing_customer_existing_seats_revenue
    if existing_customer_additional_seats_revenue is not None:
        payload["existingCustomerAdditionalSeatsRevenue"] = existing_customer_additional_seats_revenue
    if new_customer_new_seats_revenue is not None:
        payload["newCustomerNewSeatsRevenue"] = new_customer_new_seats_revenue
    if discounts_and_refunds is not None:
        payload["discountsAndRefunds"] = discounts_and_refunds
    if arr is not None:
        payload["arr"] = arr
    if mrr is not None:
        payload["mrr"] = mrr
    if average_revenue_per_customer is not None:
        payload["averageRevenuePerCustomer"] = average_revenue_per_customer
    if average_contract_value is not None:
        payload["averageContractValue"] = average_contract_value
    if revenue_churn_rate is not None:
        payload["revenueChurnRate"] = revenue_churn_rate
    if net_revenue_retention is not None:
        payload["netRevenueRetention"] = net_revenue_retention
    if gross_revenue_retention is not None:
        payload["grossRevenueRetention"] = gross_revenue_retention
    if growth_rate_cohort_1 is not None:
        payload["growthRateCohort1"] = growth_rate_cohort_1
    if growth_rate_cohort_2 is not None:
        payload["growthRateCohort2"] = growth_rate_cohort_2
    if growth_rate_cohort_3 is not None:
        payload["growthRateCohort3"] = growth_rate_cohort_3
    # Customer metrics
    if total_customers is not None:
        payload["totalCustomers"] = total_customers
    if new_customers is not None:
        payload["newCustomers"] = new_customers
    if churned_customers is not None:
        payload["churnedCustomers"] = churned_customers
    if total_users is not None:
        payload["totalUsers"] = total_users
    if active_users is not None:
        payload["activeUsers"] = active_users
    if total_monthly_active_client_users is not None:
        payload["totalMonthlyActiveClientUsers"] = total_monthly_active_client_users
    if existing_customer_existing_seats_users is not None:
        payload["existingCustomerExistingSeatsUsers"] = existing_customer_existing_seats_users
    if existing_customer_additional_seats_users is not None:
        payload["existingCustomerAdditionalSeatsUsers"] = existing_customer_additional_seats_users
    if new_customer_new_seats_users is not None:
        payload["newCustomerNewSeatsUsers"] = new_customer_new_seats_users
    if user_growth_rate is not None:
        payload["userGrowthRate"] = user_growth_rate
    if new_customer_total_addressable_seats is not None:
        payload["newCustomerTotalAddressableSeats"] = new_customer_total_addressable_seats
    if new_customer_new_seats_percent_signed is not None:
        payload["newCustomerNewSeatsPercentSigned"] = new_customer_new_seats_percent_signed
    if new_customer_total_addressable_seats_remaining is not None:
        payload["newCustomerTotalAddressableSeatsRemaining"] = new_customer_total_addressable_seats_remaining
    if existing_customer_count is not None:
        payload["existingCustomerCount"] = existing_customer_count
    if existing_customer_expansion_count is not None:
        payload["existingCustomerExpansionCount"] = existing_customer_expansion_count
    if new_customer_count is not None:
        payload["newCustomerCount"] = new_customer_count
    if customer_growth_rate is not None:
        payload["customerGrowthRate"] = customer_growth_rate
    if cac is not None:
        payload["cac"] = cac
    if ltv is not None:
        payload["ltv"] = ltv
    if ltv_cac_ratio is not None:
        payload["ltvCacRatio"] = ltv_cac_ratio
    if payback_period is not None:
        payload["paybackPeriod"] = payback_period
    if customer_churn_rate is not None:
        payload["customerChurnRate"] = customer_churn_rate
    if customer_acquisition_efficiency is not None:
        payload["customerAcquisitionEfficiency"] = customer_acquisition_efficiency
    if sales_efficiency is not None:
        payload["salesEfficiency"] = sales_efficiency
    # Operational metrics
    if burn_rate is not None:
        payload["burnRate"] = burn_rate
    if runway_months is not None:
        payload["runwayMonths"] = runway_months
    if runway_gross is not None:
        payload["runwayGross"] = runway_gross
    if runway_net is not None:
        payload["runwayNet"] = runway_net
    if burn_multiple is not None:
        payload["burnMultiple"] = burn_multiple
    if rule_of_40 is not None:
        payload["ruleOf40"] = rule_of_40
    if gross_margin is not None:
        payload["grossMargin"] = gross_margin
    if contribution_margin is not None:
        payload["contributionMargin"] = contribution_margin
    if revenue_per_employee is not None:
        payload["revenuePerEmployee"] = revenue_per_employee
    if profit_per_employee is not None:
        payload["profitPerEmployee"] = profit_per_employee
    if capital_efficiency is not None:
        payload["capitalEfficiency"] = capital_efficiency
    if cash_conversion_cycle is not None:
        payload["cashConversionCycle"] = cash_conversion_cycle
    if capex is not None:
        payload["capex"] = capex
    if ebitda is not None:
        payload["ebitda"] = ebitda
    if total_costs is not None:
        payload["totalCosts"] = total_costs
    # Team metrics
    if total_employees is not None:
        payload["totalEmployees"] = total_employees
    if full_time_employees is not None:
        payload["fullTimeEmployees"] = full_time_employees
    if part_time_employees is not None:
        payload["partTimeEmployees"] = part_time_employees
    if contractors is not None:
        payload["contractors"] = contractors
    if number_of_management is not None:
        payload["numberOfManagement"] = number_of_management
    if number_of_sales_marketing_staff is not None:
        payload["numberOfSalesMarketingStaff"] = number_of_sales_marketing_staff
    if number_of_research_development_staff is not None:
        payload["numberOfResearchDevelopmentStaff"] = number_of_research_development_staff
    if number_of_customer_service_support_staff is not None:
        payload["numberOfCustomerServiceSupportStaff"] = number_of_customer_service_support_staff
    if number_of_general_staff is not None:
        payload["numberOfGeneralStaff"] = number_of_general_staff
    if employee_growth_rate is not None:
        payload["employeeGrowthRate"] = employee_growth_rate
    if employee_turnover_rate is not None:
        payload["employeeTurnoverRate"] = employee_turnover_rate
    if average_tenure_months is not None:
        payload["averageTenureMonths"] = average_tenure_months
    if management_costs is not None:
        payload["managementCosts"] = management_costs
    if sales_marketing_staff_costs is not None:
        payload["salesMarketingStaffCosts"] = sales_marketing_staff_costs
    if research_development_staff_costs is not None:
        payload["researchDevelopmentStaffCosts"] = research_development_staff_costs
    if customer_service_support_staff_costs is not None:
        payload["customerServiceSupportStaffCosts"] = customer_service_support_staff_costs
    if general_staff_costs is not None:
        payload["generalStaffCosts"] = general_staff_costs
    if staff_costs_total is not None:
        payload["staffCostsTotal"] = staff_costs_total
    # Notes
    if notes is not None:
        payload["notes"] = notes

    result = await v7.post("/api/assetmanager/companies/financial-metrics", payload)
    m = result["data"]
    return f"Financial metrics created (id={m['id']}, company_id={m['companyId']}, year={m['year']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_financial_metrics(
    financial_metrics_id: int,
    company_id: int | None = None,
    year: int | None = None,
    scenario: Literal["Actual", "Forecast", "Budget"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    semester: Literal["H1", "H2"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    full_year: bool | None = None,
    period_end: str | None = None,
    # Ratios: liquidity
    current_ratio: float | None = None,
    quick_ratio: float | None = None,
    cash_ratio: float | None = None,
    operating_cash_flow_ratio: float | None = None,
    # Ratios: solvency
    debt_to_equity_ratio: float | None = None,
    debt_to_assets_ratio: float | None = None,
    interest_coverage_ratio: float | None = None,
    debt_service_coverage_ratio: float | None = None,
    # Ratios: profitability
    gross_profit_margin: float | None = None,
    operating_profit_margin: float | None = None,
    net_profit_margin: float | None = None,
    ebitda_margin: float | None = None,
    return_on_assets: float | None = None,
    return_on_equity: float | None = None,
    return_on_invested_capital: float | None = None,
    # Ratios: efficiency
    asset_turnover_ratio: float | None = None,
    inventory_turnover_ratio: float | None = None,
    receivables_turnover_ratio: float | None = None,
    days_sales_outstanding: float | None = None,
    days_inventory_outstanding: float | None = None,
    days_payables_outstanding: float | None = None,
    # Ratios: investment
    earnings_per_share: float | None = None,
    price_earnings_ratio: float | None = None,
    dividend_yield: float | None = None,
    dividend_payout_ratio: float | None = None,
    book_value_per_share: float | None = None,
    # Revenue metrics
    recurring_revenue: float | None = None,
    non_recurring_revenue: float | None = None,
    revenue_growth_rate: float | None = None,
    existing_customer_existing_seats_revenue: float | None = None,
    existing_customer_additional_seats_revenue: float | None = None,
    new_customer_new_seats_revenue: float | None = None,
    discounts_and_refunds: float | None = None,
    arr: float | None = None,
    mrr: float | None = None,
    average_revenue_per_customer: float | None = None,
    average_contract_value: float | None = None,
    revenue_churn_rate: float | None = None,
    net_revenue_retention: float | None = None,
    gross_revenue_retention: float | None = None,
    growth_rate_cohort_1: float | None = None,
    growth_rate_cohort_2: float | None = None,
    growth_rate_cohort_3: float | None = None,
    # Customer metrics
    total_customers: float | None = None,
    new_customers: float | None = None,
    churned_customers: float | None = None,
    total_users: float | None = None,
    active_users: float | None = None,
    total_monthly_active_client_users: float | None = None,
    existing_customer_existing_seats_users: float | None = None,
    existing_customer_additional_seats_users: float | None = None,
    new_customer_new_seats_users: float | None = None,
    user_growth_rate: float | None = None,
    new_customer_total_addressable_seats: float | None = None,
    new_customer_new_seats_percent_signed: float | None = None,
    new_customer_total_addressable_seats_remaining: float | None = None,
    existing_customer_count: float | None = None,
    existing_customer_expansion_count: float | None = None,
    new_customer_count: float | None = None,
    customer_growth_rate: float | None = None,
    cac: float | None = None,
    ltv: float | None = None,
    ltv_cac_ratio: float | None = None,
    payback_period: float | None = None,
    customer_churn_rate: float | None = None,
    customer_acquisition_efficiency: float | None = None,
    sales_efficiency: float | None = None,
    # Operational metrics
    burn_rate: float | None = None,
    runway_months: float | None = None,
    runway_gross: float | None = None,
    runway_net: float | None = None,
    burn_multiple: float | None = None,
    rule_of_40: float | None = None,
    gross_margin: float | None = None,
    contribution_margin: float | None = None,
    revenue_per_employee: float | None = None,
    profit_per_employee: float | None = None,
    capital_efficiency: float | None = None,
    cash_conversion_cycle: float | None = None,
    capex: float | None = None,
    ebitda: float | None = None,
    total_costs: float | None = None,
    # Team metrics
    total_employees: float | None = None,
    full_time_employees: float | None = None,
    part_time_employees: float | None = None,
    contractors: float | None = None,
    number_of_management: float | None = None,
    number_of_sales_marketing_staff: float | None = None,
    number_of_research_development_staff: float | None = None,
    number_of_customer_service_support_staff: float | None = None,
    number_of_general_staff: float | None = None,
    employee_growth_rate: float | None = None,
    employee_turnover_rate: float | None = None,
    average_tenure_months: float | None = None,
    management_costs: float | None = None,
    sales_marketing_staff_costs: float | None = None,
    research_development_staff_costs: float | None = None,
    customer_service_support_staff_costs: float | None = None,
    general_staff_costs: float | None = None,
    staff_costs_total: float | None = None,
    # Notes
    notes: str | None = None,
) -> str:
    """Update an existing financial metrics snapshot by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if year is not None:
        payload["year"] = year
    if scenario is not None:
        payload["scenario"] = scenario
    if quarter is not None:
        payload["quarter"] = quarter
    if semester is not None:
        payload["semester"] = semester
    if month is not None:
        payload["month"] = month
    if full_year is not None:
        payload["fullYear"] = full_year
    if period_end is not None:
        payload["periodEnd"] = period_end
    # Ratios: liquidity
    if current_ratio is not None:
        payload["currentRatio"] = current_ratio
    if quick_ratio is not None:
        payload["quickRatio"] = quick_ratio
    if cash_ratio is not None:
        payload["cashRatio"] = cash_ratio
    if operating_cash_flow_ratio is not None:
        payload["operatingCashFlowRatio"] = operating_cash_flow_ratio
    # Ratios: solvency
    if debt_to_equity_ratio is not None:
        payload["debtToEquityRatio"] = debt_to_equity_ratio
    if debt_to_assets_ratio is not None:
        payload["debtToAssetsRatio"] = debt_to_assets_ratio
    if interest_coverage_ratio is not None:
        payload["interestCoverageRatio"] = interest_coverage_ratio
    if debt_service_coverage_ratio is not None:
        payload["debtServiceCoverageRatio"] = debt_service_coverage_ratio
    # Ratios: profitability
    if gross_profit_margin is not None:
        payload["grossProfitMargin"] = gross_profit_margin
    if operating_profit_margin is not None:
        payload["operatingProfitMargin"] = operating_profit_margin
    if net_profit_margin is not None:
        payload["netProfitMargin"] = net_profit_margin
    if ebitda_margin is not None:
        payload["ebitdaMargin"] = ebitda_margin
    if return_on_assets is not None:
        payload["returnOnAssets"] = return_on_assets
    if return_on_equity is not None:
        payload["returnOnEquity"] = return_on_equity
    if return_on_invested_capital is not None:
        payload["returnOnInvestedCapital"] = return_on_invested_capital
    # Ratios: efficiency
    if asset_turnover_ratio is not None:
        payload["assetTurnoverRatio"] = asset_turnover_ratio
    if inventory_turnover_ratio is not None:
        payload["inventoryTurnoverRatio"] = inventory_turnover_ratio
    if receivables_turnover_ratio is not None:
        payload["receivablesTurnoverRatio"] = receivables_turnover_ratio
    if days_sales_outstanding is not None:
        payload["daysSalesOutstanding"] = days_sales_outstanding
    if days_inventory_outstanding is not None:
        payload["daysInventoryOutstanding"] = days_inventory_outstanding
    if days_payables_outstanding is not None:
        payload["daysPayablesOutstanding"] = days_payables_outstanding
    # Ratios: investment
    if earnings_per_share is not None:
        payload["earningsPerShare"] = earnings_per_share
    if price_earnings_ratio is not None:
        payload["priceEarningsRatio"] = price_earnings_ratio
    if dividend_yield is not None:
        payload["dividendYield"] = dividend_yield
    if dividend_payout_ratio is not None:
        payload["dividendPayoutRatio"] = dividend_payout_ratio
    if book_value_per_share is not None:
        payload["bookValuePerShare"] = book_value_per_share
    # Revenue metrics
    if recurring_revenue is not None:
        payload["recurringRevenue"] = recurring_revenue
    if non_recurring_revenue is not None:
        payload["nonRecurringRevenue"] = non_recurring_revenue
    if revenue_growth_rate is not None:
        payload["revenueGrowthRate"] = revenue_growth_rate
    if existing_customer_existing_seats_revenue is not None:
        payload["existingCustomerExistingSeatsRevenue"] = existing_customer_existing_seats_revenue
    if existing_customer_additional_seats_revenue is not None:
        payload["existingCustomerAdditionalSeatsRevenue"] = existing_customer_additional_seats_revenue
    if new_customer_new_seats_revenue is not None:
        payload["newCustomerNewSeatsRevenue"] = new_customer_new_seats_revenue
    if discounts_and_refunds is not None:
        payload["discountsAndRefunds"] = discounts_and_refunds
    if arr is not None:
        payload["arr"] = arr
    if mrr is not None:
        payload["mrr"] = mrr
    if average_revenue_per_customer is not None:
        payload["averageRevenuePerCustomer"] = average_revenue_per_customer
    if average_contract_value is not None:
        payload["averageContractValue"] = average_contract_value
    if revenue_churn_rate is not None:
        payload["revenueChurnRate"] = revenue_churn_rate
    if net_revenue_retention is not None:
        payload["netRevenueRetention"] = net_revenue_retention
    if gross_revenue_retention is not None:
        payload["grossRevenueRetention"] = gross_revenue_retention
    if growth_rate_cohort_1 is not None:
        payload["growthRateCohort1"] = growth_rate_cohort_1
    if growth_rate_cohort_2 is not None:
        payload["growthRateCohort2"] = growth_rate_cohort_2
    if growth_rate_cohort_3 is not None:
        payload["growthRateCohort3"] = growth_rate_cohort_3
    # Customer metrics
    if total_customers is not None:
        payload["totalCustomers"] = total_customers
    if new_customers is not None:
        payload["newCustomers"] = new_customers
    if churned_customers is not None:
        payload["churnedCustomers"] = churned_customers
    if total_users is not None:
        payload["totalUsers"] = total_users
    if active_users is not None:
        payload["activeUsers"] = active_users
    if total_monthly_active_client_users is not None:
        payload["totalMonthlyActiveClientUsers"] = total_monthly_active_client_users
    if existing_customer_existing_seats_users is not None:
        payload["existingCustomerExistingSeatsUsers"] = existing_customer_existing_seats_users
    if existing_customer_additional_seats_users is not None:
        payload["existingCustomerAdditionalSeatsUsers"] = existing_customer_additional_seats_users
    if new_customer_new_seats_users is not None:
        payload["newCustomerNewSeatsUsers"] = new_customer_new_seats_users
    if user_growth_rate is not None:
        payload["userGrowthRate"] = user_growth_rate
    if new_customer_total_addressable_seats is not None:
        payload["newCustomerTotalAddressableSeats"] = new_customer_total_addressable_seats
    if new_customer_new_seats_percent_signed is not None:
        payload["newCustomerNewSeatsPercentSigned"] = new_customer_new_seats_percent_signed
    if new_customer_total_addressable_seats_remaining is not None:
        payload["newCustomerTotalAddressableSeatsRemaining"] = new_customer_total_addressable_seats_remaining
    if existing_customer_count is not None:
        payload["existingCustomerCount"] = existing_customer_count
    if existing_customer_expansion_count is not None:
        payload["existingCustomerExpansionCount"] = existing_customer_expansion_count
    if new_customer_count is not None:
        payload["newCustomerCount"] = new_customer_count
    if customer_growth_rate is not None:
        payload["customerGrowthRate"] = customer_growth_rate
    if cac is not None:
        payload["cac"] = cac
    if ltv is not None:
        payload["ltv"] = ltv
    if ltv_cac_ratio is not None:
        payload["ltvCacRatio"] = ltv_cac_ratio
    if payback_period is not None:
        payload["paybackPeriod"] = payback_period
    if customer_churn_rate is not None:
        payload["customerChurnRate"] = customer_churn_rate
    if customer_acquisition_efficiency is not None:
        payload["customerAcquisitionEfficiency"] = customer_acquisition_efficiency
    if sales_efficiency is not None:
        payload["salesEfficiency"] = sales_efficiency
    # Operational metrics
    if burn_rate is not None:
        payload["burnRate"] = burn_rate
    if runway_months is not None:
        payload["runwayMonths"] = runway_months
    if runway_gross is not None:
        payload["runwayGross"] = runway_gross
    if runway_net is not None:
        payload["runwayNet"] = runway_net
    if burn_multiple is not None:
        payload["burnMultiple"] = burn_multiple
    if rule_of_40 is not None:
        payload["ruleOf40"] = rule_of_40
    if gross_margin is not None:
        payload["grossMargin"] = gross_margin
    if contribution_margin is not None:
        payload["contributionMargin"] = contribution_margin
    if revenue_per_employee is not None:
        payload["revenuePerEmployee"] = revenue_per_employee
    if profit_per_employee is not None:
        payload["profitPerEmployee"] = profit_per_employee
    if capital_efficiency is not None:
        payload["capitalEfficiency"] = capital_efficiency
    if cash_conversion_cycle is not None:
        payload["cashConversionCycle"] = cash_conversion_cycle
    if capex is not None:
        payload["capex"] = capex
    if ebitda is not None:
        payload["ebitda"] = ebitda
    if total_costs is not None:
        payload["totalCosts"] = total_costs
    # Team metrics
    if total_employees is not None:
        payload["totalEmployees"] = total_employees
    if full_time_employees is not None:
        payload["fullTimeEmployees"] = full_time_employees
    if part_time_employees is not None:
        payload["partTimeEmployees"] = part_time_employees
    if contractors is not None:
        payload["contractors"] = contractors
    if number_of_management is not None:
        payload["numberOfManagement"] = number_of_management
    if number_of_sales_marketing_staff is not None:
        payload["numberOfSalesMarketingStaff"] = number_of_sales_marketing_staff
    if number_of_research_development_staff is not None:
        payload["numberOfResearchDevelopmentStaff"] = number_of_research_development_staff
    if number_of_customer_service_support_staff is not None:
        payload["numberOfCustomerServiceSupportStaff"] = number_of_customer_service_support_staff
    if number_of_general_staff is not None:
        payload["numberOfGeneralStaff"] = number_of_general_staff
    if employee_growth_rate is not None:
        payload["employeeGrowthRate"] = employee_growth_rate
    if employee_turnover_rate is not None:
        payload["employeeTurnoverRate"] = employee_turnover_rate
    if average_tenure_months is not None:
        payload["averageTenureMonths"] = average_tenure_months
    if management_costs is not None:
        payload["managementCosts"] = management_costs
    if sales_marketing_staff_costs is not None:
        payload["salesMarketingStaffCosts"] = sales_marketing_staff_costs
    if research_development_staff_costs is not None:
        payload["researchDevelopmentStaffCosts"] = research_development_staff_costs
    if customer_service_support_staff_costs is not None:
        payload["customerServiceSupportStaffCosts"] = customer_service_support_staff_costs
    if general_staff_costs is not None:
        payload["generalStaffCosts"] = general_staff_costs
    if staff_costs_total is not None:
        payload["staffCostsTotal"] = staff_costs_total
    # Notes
    if notes is not None:
        payload["notes"] = notes

    result = await v7.put(f"/api/assetmanager/companies/financial-metrics/{financial_metrics_id}", payload)
    m = result["data"]
    return f"Financial metrics updated (id={m['id']}, company_id={m['companyId']}, year={m['year']})."


# ==========================================
# KPI Definitions
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_kpis() -> str:
    """List all KPI definitions."""
    result = await v7.get("/api/assetmanager/companies/kpis")
    items = result.get("data", [])

    if not items:
        return "No KPI definitions found."

    lines = [f"KPI Definitions ({len(items)}):"]
    for k in items:
        lines.append(
            f"  - {k['name']} (id={k['id']}, company_id={k['companyId']}, "
            f"dataType={k.get('dataType', '—')}, isCalculated={k.get('isCalculated', False)})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_kpi(kpi_id: int) -> str:
    """Get details of a specific KPI definition by ID."""
    result = await v7.get(f"/api/assetmanager/companies/kpis/{kpi_id}")
    k = result.get("data")

    if not k:
        return f"KPI {kpi_id} not found."

    return (
        f"KPI: {k['name']} (id={k['id']}, company_id={k['companyId']})\n"
        f"  Data Type: {k.get('dataType', '—')}\n"
        f"  Description: {k.get('description', '—')}\n"
        f"  Is Calculated: {k.get('isCalculated', False)}\n"
        f"  Formula: {k.get('formula', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_kpi(
    company_id: int,
    name: str,
    data_type: Literal["DECIMAL", "INTEGER", "STRING"] = "DECIMAL",
    description: str | None = None,
    is_calculated: bool = False,
    formula: str | None = None,
) -> str:
    """Create a new KPI definition."""
    payload: dict = {"companyId": company_id, "name": name, "dataType": data_type, "isCalculated": is_calculated}
    if description:
        payload["description"] = description
    if formula:
        payload["formula"] = formula

    result = await v7.post("/api/assetmanager/companies/kpis", payload)
    k = result["data"]
    return f"KPI created: {k['name']} (id={k['id']}, company_id={k['companyId']}, dataType={k['dataType']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_kpi(
    kpi_id: int,
    company_id: int | None = None,
    name: str | None = None,
    data_type: Literal["DECIMAL", "INTEGER", "STRING"] | None = None,
    description: str | None = None,
    is_calculated: bool | None = None,
    formula: str | None = None,
) -> str:
    """Update an existing KPI definition by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if name is not None:
        payload["name"] = name
    if data_type is not None:
        payload["dataType"] = data_type
    if description is not None:
        payload["description"] = description
    if is_calculated is not None:
        payload["isCalculated"] = is_calculated
    if formula is not None:
        payload["formula"] = formula

    result = await v7.put(f"/api/assetmanager/companies/kpis/{kpi_id}", payload)
    k = result["data"]
    return f"KPI updated: {k['name']} (id={k['id']})."


# ==========================================
# KPI Values
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_kpi_values() -> str:
    """List all KPI values."""
    result = await v7.get("/api/assetmanager/companies/kpi-values")
    items = result.get("data", [])

    if not items:
        return "No KPI values found."

    lines = [f"KPI Values ({len(items)}):"]
    for v in items:
        lines.append(
            f"  - id={v['id']} | kpi_id={v['kpiId']} | date={v['date']} | year={v['year']} | "
            f"value={v.get('value', '—')} | scenario={v.get('scenario', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_kpi_value(kpi_value_id: int) -> str:
    """Get details of a specific KPI value by ID."""
    result = await v7.get(f"/api/assetmanager/companies/kpi-values/{kpi_value_id}")
    v = result.get("data")

    if not v:
        return f"KPI value {kpi_value_id} not found."

    return (
        f"KPI Value (id={v['id']}, kpi_id={v['kpiId']})\n"
        f"  Date: {v['date']} | Year: {v['year']}\n"
        f"  Semester: {v.get('semester', '—')} | Quarter: {v.get('quarter', '—')} | Month: {v.get('month', '—')}\n"
        f"  Full Year: {v.get('fullYear', False)} | Scenario: {v.get('scenario', '—')}\n"
        f"  Value: {v.get('value', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_kpi_value(
    kpi_id: int,
    date: str,
    year: int,
    value: float | None = None,
    scenario: Literal["Actual", "Forecast", "Budget"] = "Actual",
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    full_year: bool = False,
    calculated_at: str | None = None,
) -> str:
    """Create a new KPI value. Date format: YYYY-MM-DD."""
    payload: dict = {"kpiId": kpi_id, "date": date, "year": year, "scenario": scenario, "fullYear": full_year}
    if value is not None:
        payload["value"] = value
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if calculated_at is not None:
        payload["calculatedAt"] = calculated_at

    result = await v7.post("/api/assetmanager/companies/kpi-values", payload)
    v = result["data"]
    return f"KPI value created (id={v['id']}, kpi_id={v['kpiId']}, date={v['date']}, value={v.get('value', '—')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_kpi_value(
    kpi_value_id: int,
    kpi_id: int | None = None,
    date: str | None = None,
    year: int | None = None,
    value: float | None = None,
    scenario: Literal["Actual", "Forecast", "Budget"] | None = None,
    semester: Literal["H1", "H2"] | None = None,
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    month: Literal["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] | None = None,
    full_year: bool | None = None,
    calculated_at: str | None = None,
) -> str:
    """Update an existing KPI value by ID."""
    payload: dict = {}
    if kpi_id is not None:
        payload["kpiId"] = kpi_id
    if date is not None:
        payload["date"] = date
    if year is not None:
        payload["year"] = year
    if value is not None:
        payload["value"] = value
    if scenario is not None:
        payload["scenario"] = scenario
    if semester is not None:
        payload["semester"] = semester
    if quarter is not None:
        payload["quarter"] = quarter
    if month is not None:
        payload["month"] = month
    if full_year is not None:
        payload["fullYear"] = full_year
    if calculated_at is not None:
        payload["calculatedAt"] = calculated_at

    result = await v7.put(f"/api/assetmanager/companies/kpi-values/{kpi_value_id}", payload)
    v = result["data"]
    return f"KPI value updated (id={v['id']}, kpi_id={v['kpiId']}, value={v.get('value', '—')})."
