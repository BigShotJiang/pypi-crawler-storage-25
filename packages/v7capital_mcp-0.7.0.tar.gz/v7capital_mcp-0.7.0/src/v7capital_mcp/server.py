"""
V7 Capital MCP Server

FastMCP instance with all tools registered.
Entrypoint: v7capital-mcp (stdio transport for Claude Desktop/Code/Cursor)
"""

from fastmcp import FastMCP

mcp = FastMCP(
    "V7 Capital",
    instructions=(
        "V7 Capital Asset Manager — manage cap tables, portfolio investments, companies, and financials through conversation.\n\n"
        "IMPORTANT: Before using any tools, the user must have run 'v7capital-cli login' in their terminal.\n\n"
        "This is a single-organization platform (V7 Capital). No context switching needed — all tools operate on V7 Capital data directly.\n\n"
        "Domains:\n"
        "- Cap Table: funds, rounds, stakeholders, securities, transactions, commitments\n"
        "- Companies: company profiles + financial statements (income, balance, cash flow, metrics, KPIs)\n"
        "- Portfolio: deal pipeline, investments, cash flows, performance\n"
        "- Fund Admin: fee costs\n"
        "- Audit: view change history"
    ),
    mask_error_details=True,
)

# Register all tools by importing tool modules
from .tools import captable  # noqa: F401, E402
from .tools import companies  # noqa: F401, E402
from .tools import portfolio  # noqa: F401, E402
from .tools import fees  # noqa: F401, E402
from .tools import audit  # noqa: F401, E402


def main():
    """Entrypoint for v7capital-mcp command. Runs stdio transport for Claude Desktop/Code/Codex."""
    mcp.run()


def main_http():
    """Entrypoint for v7capital-mcp-http command. Runs Streamable HTTP transport for ChatGPT / remote clients."""
    mcp.run(transport="http", host="0.0.0.0", port=8811)
