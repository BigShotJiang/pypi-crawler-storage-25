"""
V7 Capital MCP Server — HTTP Client

Async httpx wrapper that handles:
- JWT authentication (from ~/.v7capital/credentials.json)
- Automatic token refresh on 401 via /api/auth/refresh
- No org/entity context needed (single-org platform)
"""

import httpx

from .config import API_BASE_URL, REQUEST_TIMEOUT
from .credentials import load_credentials, save_credentials


class V7Client:
    """HTTP client for V7 Capital API with JWT auth and auto-refresh."""

    def __init__(self) -> None:
        self.base_url = API_BASE_URL

    def _get_credentials(self) -> dict:
        """Load credentials or raise descriptive error."""
        creds = load_credentials()
        if not creds or not creds.get("access_token"):
            raise RuntimeError(
                "Not authenticated. Please run 'v7capital-cli login' in your terminal first."
            )
        return creds

    @property
    def _headers(self) -> dict:
        """Auth headers from stored credentials."""
        creds = self._get_credentials()
        return {"Authorization": f"Bearer {creds['access_token']}"}

    async def _refresh_token(self) -> bool:
        """Attempt to refresh JWT via /api/auth/refresh. Returns True if successful."""
        creds = load_credentials()
        if not creds or not creds.get("refresh_token"):
            return False

        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
                r = await http.post(
                    f"{self.base_url}/api/auth/refresh",
                    json={"refresh_token": creds["refresh_token"]},
                )
                if r.status_code == 200:
                    data = r.json()
                    creds["access_token"] = data["access_token"]
                    creds["refresh_token"] = data["refresh_token"]
                    save_credentials(creds)
                    return True
        except httpx.HTTPError:
            pass
        return False

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make HTTP request with auto-refresh on 401."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.request(
                method,
                f"{self.base_url}{path}",
                headers=self._headers,
                **kwargs,
            )

            # Auto-refresh on 401
            if r.status_code == 401:
                refreshed = await self._refresh_token()
                if refreshed:
                    r = await http.request(
                        method,
                        f"{self.base_url}{path}",
                        headers=self._headers,
                        **kwargs,
                    )
                else:
                    raise RuntimeError(
                        "Session expired. Please run 'v7capital-cli login' again."
                    )

            r.raise_for_status()
            return r.json()

    async def get(self, path: str, **kwargs) -> dict:
        """GET request to V7 Capital API."""
        return await self._request("GET", path, **kwargs)

    async def post(self, path: str, data: dict) -> dict:
        """POST request to V7 Capital API."""
        return await self._request("POST", path, json=data)

    async def put(self, path: str, data: dict) -> dict:
        """PUT request to V7 Capital API."""
        return await self._request("PUT", path, json=data)

    async def delete(self, path: str) -> dict:
        """DELETE request to V7 Capital API."""
        return await self._request("DELETE", path)


# Singleton instance — shared across all tools
v7 = V7Client()
