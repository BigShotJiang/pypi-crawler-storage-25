# V7 Capital MCP Server

AI-powered asset management through conversation. Manage cap tables, portfolio investments, companies, and financials via Claude Desktop, Claude Code, or any MCP client.

## Installation

```bash
uv tool install v7capital-mcp
```

## Authentication

```bash
v7capital-cli login
```

## Usage

### Claude Code
```bash
claude mcp add v7capital -- v7capital-mcp
```

### Claude Desktop
Add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "v7capital": {
      "command": "v7capital-mcp"
    }
  }
}
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `V7_API_URL` | `https://www.v7capital.ro` | API base URL |

## Tools (~53)

- **Cap Table**: list/create funds, rounds, stakeholders, securities, transactions; get cap table; list commitments
- **Companies**: list/create/update companies, income statements, balance sheets, cash flow statements, financial metrics, KPIs, KPI values
- **Portfolio**: deal pipeline (CRUD), investments (CRU), cash flows (CRU), performance (CRU)
- **Fund Admin**: list/create/update fee costs
- **Audit**: list audit logs
