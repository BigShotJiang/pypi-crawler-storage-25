import json
from pathlib import Path

from pymultirole_plugins.v1.schema import Document

from pyprocessors_tag2segment.tag2segment import (
    Tag2SegmentParameters,
    Tag2SegmentProcessor,
)


def test_model():
    model = Tag2SegmentProcessor.get_model()
    assert model is Tag2SegmentParameters


def test_tag2segment():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/news_fr.json")
    with source.open("r") as fin:
        doc = json.load(fin)
        original_doc = Document(**doc)
    segmentation_annots = [a for a in original_doc.annotations if a.labelName == "bos"]
    processor = Tag2SegmentProcessor()
    parameters = Tag2SegmentParameters(segmentation_labels=["bos"], remove_segmentation_annotations=False)
    docs = processor.process([Document(**doc)], parameters)
    tag2segmented: Document = docs[0]
    assert len(tag2segmented.sentences) == len(segmentation_annots)
    for i, a in enumerate(segmentation_annots):
        assert a.start == tag2segmented.sentences[i].start

    parameters = Tag2SegmentParameters(
        segmentation_labels=["bos"], remove_segmentation_annotations=True, annotations_as_metadata=True
    )
    docs = processor.process([Document(**doc)], parameters)
    tag2segmented: Document = docs[0]
    assert len(tag2segmented.sentences) == len(segmentation_annots)
    assert len(tag2segmented.sentences[0].metadata) == 1
    assert len(original_doc.annotations) > len(tag2segmented.annotations)


def test_tag2segment_no_annotations():
    """Test that a document with no annotations gets a single sentence spanning the whole text."""
    doc = Document(text="Hello world, this is a test document.")
    processor = Tag2SegmentProcessor()
    parameters = Tag2SegmentParameters()
    docs = processor.process([doc], parameters)
    assert len(docs[0].sentences) == 1
    assert docs[0].sentences[0].start == 0
    assert docs[0].sentences[0].end == len(doc.text)


def test_tag2segment_empty_labels():
    """Test that empty segmentation_labels uses all annotations as segment boundaries."""
    testdir = Path(__file__).parent
    source = Path(testdir, "data/news_fr.json")
    with source.open("r") as fin:
        doc = json.load(fin)
    processor = Tag2SegmentProcessor()
    parameters = Tag2SegmentParameters(segmentation_labels=[])
    docs = processor.process([Document(**doc)], parameters)
    # All non-KO annotations should be used as segment boundaries
    original = Document(**doc)
    all_annots = [a for a in original.annotations if a.status != "KO"]
    if all_annots:
        assert len(docs[0].sentences) > 0


def test_tag2segment_remove_annotations():
    """Test that remove_segmentation_annotations removes the matching annotations."""
    testdir = Path(__file__).parent
    source = Path(testdir, "data/news_fr.json")
    with source.open("r") as fin:
        doc = json.load(fin)
        original_doc = Document(**doc)
    processor = Tag2SegmentProcessor()
    parameters = Tag2SegmentParameters(segmentation_labels=["bos"], remove_segmentation_annotations=True)
    docs = processor.process([Document(**doc)], parameters)
    result_doc = docs[0]
    # All "bos" annotations should have been removed
    bos_annots = [a for a in result_doc.annotations if a.labelName == "bos"]
    assert len(bos_annots) == 0
    # Non-bos annotations should still be present
    original_non_bos = [a for a in original_doc.annotations if a.labelName != "bos"]
    result_non_bos = [a for a in result_doc.annotations if a.labelName != "bos"]
    assert len(result_non_bos) == len(original_non_bos)


def test_tag2segment_multiple_documents():
    """Test processing multiple documents at once."""
    doc1 = Document(text="First document text.")
    doc2 = Document(text="Second document text.")
    processor = Tag2SegmentProcessor()
    parameters = Tag2SegmentParameters()
    docs = processor.process([doc1, doc2], parameters)
    assert len(docs) == 2
    for doc in docs:
        assert len(doc.sentences) == 1
        assert doc.sentences[0].start == 0
        assert doc.sentences[0].end == len(doc.text)
