"""Sherpa Consolidation processor"""

__version__ = "1.6.29"
