# pyprocessors_tag2segment

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_tag2segment)](https://github.com/oterrier/pyprocessors_tag2segment/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_tag2segment/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_tag2segment/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_tag2segment)](https://codecov.io/gh/oterrier/pyprocessors_tag2segment)
[![docs](https://img.shields.io/readthedocs/pyprocessors_tag2segment)](https://pyprocessors_tag2segment.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_tag2segment)](https://pypi.org/project/pyprocessors_tag2segment/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_tag2segment)](https://pypi.org/project/pyprocessors_tag2segment/)

Create segments from annotations

## Installation

You can simply `pip install pyprocessors_tag2segment`.

## Developing

### Pre-requisites

You will need to install `uv` (for package management and building):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_tag2segment
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
