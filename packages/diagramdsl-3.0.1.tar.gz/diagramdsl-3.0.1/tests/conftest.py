"""Shared pytest fixtures for the diagramdsl test suite."""

from __future__ import annotations
import pytest
from diagramdsl._auth import generate_token


@pytest.fixture(scope="session")
def auth_token() -> str:
    """A single valid UUID v4 token reused across the test session."""
    return generate_token()


@pytest.fixture()
def simple_steps() -> dict:
    return {"1": {"node": "box", "label": "Hello"}}


@pytest.fixture()
def full_steps() -> dict:
    return {
        "1": {
            "node": "circle", "label": "Start",
            "attributes": {"background": "#fff7ed", "borderColor": "#e37502"},
            "specifics":  {"radius": 36},
        },
        "2": {
            "node": "box", "label": "Process",
            "connect": {"from": "1", "direction": "right", "label": "go"},
        },
        "3": {
            "node": "diamond", "label": "Done?",
            "connect": {"from": "2", "direction": "right"},
        },
        "4": {
            "node": "cylinder", "label": "DB",
            "connect": {"from": "3", "direction": "down", "label": "yes"},
        },
        "e1": {
            "edge": True, "from": "4", "to": "2",
            "direction": "up", "label": "result",
        },
    }
