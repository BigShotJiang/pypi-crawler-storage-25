"""
Client tests — verify render(), save() hook, info(), docs(), and error handling.
Uses respx to mock httpx requests without a real server.
"""

from __future__ import annotations

import httpx
import pytest
import respx

from diagramdsl._auth import generate_token
from diagramdsl.client import DiagramDSL
from diagramdsl.exceptions import AuthError, ValidationError

TOKEN = generate_token()

SIMPLE_STEPS = {"1": {"node": "box", "label": "Hello"}}
PNG_BYTES    = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100


class _CaptureTool(DiagramDSL):
    """Subclass that captures PNG bytes instead of discarding them."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.captured: bytes | None = None

    def save(self, png_bytes: bytes) -> str:
        self.captured = png_bytes
        return "captured"


@pytest.fixture()
def tool():
    return _CaptureTool(host="http://localhost:8421", auth=TOKEN)


# ── render + save() ───────────────────────────────────────────────────

@respx.mock
def test_render_calls_save_and_returns_result(tool):
    respx.post("http://localhost:8421/render").mock(
        return_value=httpx.Response(
            200, content=PNG_BYTES, headers={"content-type": "image/png"}
        )
    )
    result = tool.render(SIMPLE_STEPS)
    assert result == "captured"
    assert tool.captured == PNG_BYTES


def test_default_save_returns_none():
    base = DiagramDSL(host="http://localhost:8421", auth=TOKEN)
    assert base.save(b"anything") is None


# ── auth errors ───────────────────────────────────────────────────────

@respx.mock
def test_render_raises_auth_error_on_401(tool):
    respx.post("http://localhost:8421/render").mock(
        return_value=httpx.Response(401, json={"error": "Unauthorized"})
    )
    with pytest.raises(AuthError):
        tool.render(SIMPLE_STEPS)


# ── validation errors ─────────────────────────────────────────────────

@respx.mock
def test_render_raises_validation_error_on_422(tool):
    respx.post("http://localhost:8421/render").mock(
        return_value=httpx.Response(
            422,
            json={"ok": False, "errors": ['Step "1": missing required key "node"']},
        )
    )
    with pytest.raises(ValidationError) as exc_info:
        tool.render(SIMPLE_STEPS)
    assert "node" in str(exc_info.value)


# ── info / docs ───────────────────────────────────────────────────────

@respx.mock
def test_info_returns_dict(tool):
    respx.get("http://localhost:8421/info").mock(
        return_value=httpx.Response(200, json={"version": "3"})
    )
    result = tool.info()
    assert result["version"] == "3"


@respx.mock
def test_docs_with_type(tool):
    respx.get("http://localhost:8421/docs/circle").mock(
        return_value=httpx.Response(200, json={"node": "circle"})
    )
    result = tool.docs("circle")
    assert result["node"] == "circle"


@respx.mock
def test_docs_overview(tool):
    respx.get("http://localhost:8421/docs").mock(
        return_value=httpx.Response(200, json={"shapes": ["circle", "box"]})
    )
    result = tool.docs()
    assert "shapes" in result


# ── token validation at init ──────────────────────────────────────────

def test_invalid_token_raises_at_init():
    from diagramdsl.exceptions import InvalidTokenError
    with pytest.raises(InvalidTokenError):
        DiagramDSL(host="http://localhost:8421", auth="not-a-uuid")
