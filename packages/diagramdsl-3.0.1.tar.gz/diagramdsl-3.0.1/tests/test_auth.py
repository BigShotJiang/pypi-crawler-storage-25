"""Tests for auth token validation."""

import pytest

from diagramdsl._auth import generate_token, tokens_match, validate_token_format
from diagramdsl.exceptions import InvalidTokenError


def test_valid_uuid4_accepted():
    token = generate_token()
    assert validate_token_format(token) == token.lower()


def test_snake_case_rejected():
    with pytest.raises(InvalidTokenError):
        validate_token_format("not-a-uuid")


def test_uuid1_rejected():
    # UUID v1 — version nibble is 1, not 4
    with pytest.raises(InvalidTokenError):
        validate_token_format("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


def test_empty_string_rejected():
    with pytest.raises(InvalidTokenError):
        validate_token_format("")


def test_tokens_match_case_insensitive():
    token = generate_token()
    assert tokens_match(token.upper(), token.lower())


def test_tokens_mismatch():
    assert not tokens_match(generate_token(), generate_token())
