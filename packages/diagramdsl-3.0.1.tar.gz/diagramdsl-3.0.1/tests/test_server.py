"""
Server endpoint tests.
Uses FastAPI's test client with a mocked BrowserManager so Playwright
is not required to run the unit tests.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from fastapi.testclient import TestClient

from diagramdsl._auth import generate_token
from diagramdsl._browser import BrowserManager
from diagramdsl.server import _build_app

AUTH_TOKEN = generate_token()
BAD_TOKEN  = generate_token()

MOCK_INFO = {
    "version": "3",
    "casing":  "camelCase",
    "shapes":  ["circle", "box"],
}

SIMPLE_STEPS = {
    "1": {"node": "box", "label": "Hello"},
}


@pytest.fixture()
def mock_browser():
    browser = AsyncMock(spec=BrowserManager)
    browser.info.return_value         = MOCK_INFO
    browser.docs.return_value         = {"shapes": ["circle"]}
    browser.render.return_value       = b"\x89PNG\r\n\x1a\n"  # minimal PNG header
    browser.validate.return_value     = {"ok": True, "errors": []}
    return browser


@pytest.fixture()
def client(mock_browser):
    app = _build_app(mock_browser, AUTH_TOKEN)
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


def auth_header(token: str = AUTH_TOKEN) -> dict:
    return {"Authorization": f"Bearer {token}"}


# ── Auth ──────────────────────────────────────────────────────────────

def test_missing_auth_returns_401(client):
    resp = client.get("/info")
    assert resp.status_code == 401


def test_wrong_token_returns_401(client):
    resp = client.get("/info", headers=auth_header(BAD_TOKEN))
    assert resp.status_code == 401


def test_correct_token_accepted(client):
    resp = client.get("/info", headers=auth_header())
    assert resp.status_code == 200


def test_health_requires_no_auth(client):
    resp = client.get("/health")
    assert resp.status_code == 200


# ── /info ─────────────────────────────────────────────────────────────

def test_info_returns_json(client):
    resp = client.get("/info", headers=auth_header())
    assert resp.json()["version"] == "3"


# ── /render ───────────────────────────────────────────────────────────

def test_render_returns_png(client):
    resp = client.post("/render", headers=auth_header(), json=SIMPLE_STEPS)
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "image/png"


def test_render_invalid_json_returns_400(client):
    resp = client.post(
        "/render",
        headers={**auth_header(), "Content-Type": "application/json"},
        content=b"not json",
    )
    assert resp.status_code == 400


def test_render_validation_failure_returns_422(client, mock_browser):
    mock_browser.render.side_effect = __import__(
        "diagramdsl.exceptions", fromlist=["ValidationError"]
    ).ValidationError(["Step \"1\": missing required key \"node\""])

    resp = client.post("/render", headers=auth_header(), json={"1": {}})
    assert resp.status_code == 422
    body = resp.json()
    assert body["ok"] is False
    assert len(body["errors"]) > 0
