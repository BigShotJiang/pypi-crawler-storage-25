"""
scripts/generate_renderer.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Extracts the DiagramDSL JS class from diagram-dsl-v3.html and writes
diagramdsl/_renderer.html — the headless browser bundle used by the server.

Run this whenever the upstream JS is updated:

    python scripts/generate_renderer.py --source path/to/diagram-dsl-v3.html

The generated file is committed to the repo so the package ships
self-contained without requiring Node.js or a build step.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def extract_js(source: Path) -> str:
    """Pull the DiagramDSL class block from the HTML file."""
    html = source.read_text(encoding="utf-8")

    start = html.find("'use strict';")
    if start == -1:
        raise ValueError("Could not find \"'use strict';\" marker in source HTML.")

    end = html.find("</script>", start)
    if end == -1:
        raise ValueError("Could not find closing </script> after JS block.")

    return html[start:end].strip()


def build_renderer_html(js: str) -> str:
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body>
<canvas id="diagram-canvas"></canvas>
<script>
{js}

// ── Headless bridge ─────────────────────────────────────────────────
// Exposes DiagramDSL methods to Playwright via page.evaluate().
// This file is an internal implementation detail — do not edit manually.
// Regenerate with: python scripts/generate_renderer.py

window.__dsl    = new DiagramDSL();
window.__canvas = document.getElementById('diagram-canvas');

window.__render = function(steps) {{
  try {{
    const result = window.__dsl.render(window.__canvas, steps);
    return {{ ok: true, state: result.state }};
  }} catch (e) {{
    return {{ ok: false, error: e.message }};
  }}
}};

window.__validate  = function(steps) {{ return window.__dsl.validate(steps); }};
window.__info      = function()       {{ return window.__dsl.info(); }};
window.__docs      = function(type)   {{ return window.__dsl.docs(type || undefined); }};
window.__toDataURL = function()       {{ return window.__dsl.toDataURL(window.__canvas); }};
</script>
</body>
</html>"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Regenerate diagramdsl/_renderer.html")
    parser.add_argument(
        "--source",
        type=Path,
        default=Path(__file__).parent.parent.parent / "diagram-dsl-v3.html",
        help="Path to diagram-dsl-v3.html (default: ../../diagram-dsl-v3.html)",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(__file__).parent.parent / "diagramdsl" / "_renderer.html",
        help="Output path (default: diagramdsl/_renderer.html)",
    )
    args = parser.parse_args()

    if not args.source.exists():
        print(f"Error: source file not found: {args.source}", file=sys.stderr)
        sys.exit(1)

    print(f"Reading  {args.source}")
    js      = extract_js(args.source)
    html    = build_renderer_html(js)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(html, encoding="utf-8")
    print(f"Written  {args.out}  ({len(html):,} bytes)")


if __name__ == "__main__":
    main()
