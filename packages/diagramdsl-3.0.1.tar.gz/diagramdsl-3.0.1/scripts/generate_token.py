"""
scripts/generate_token.py
~~~~~~~~~~~~~~~~~~~~~~~~~

Print a fresh UUID v4 auth token to stdout.
Use this if you don't have the CLI installed yet.

Usage:
    python scripts/generate_token.py
"""

import uuid

if __name__ == "__main__":
    print(uuid.uuid4())
