"""
scripts/start_server.py
~~~~~~~~~~~~~~~~~~~~~~~

Convenience script to start the DiagramDSL server.
Reads configuration from environment variables with sensible defaults.

Usage:
    python scripts/start_server.py

Environment variables:
    DIAGRAMDSL_AUTH_TOKEN   Required. UUID v4 auth token.
    DIAGRAMDSL_HOST         Bind address. Default: 127.0.0.1
    DIAGRAMDSL_PORT         Port. Default: 8421
    DIAGRAMDSL_LOG_LEVEL    Log level. Default: info
"""

import os
import sys

# Allow running from the project root without installing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from diagramdsl import DiagramDSLServer  # noqa: E402

auth = os.environ.get("DIAGRAMDSL_AUTH_TOKEN")
if not auth:
    print(
        "Error: DIAGRAMDSL_AUTH_TOKEN environment variable is not set.\n"
        "Generate a token with:  diagramdsl token",
        file=sys.stderr,
    )
    sys.exit(1)

server = DiagramDSLServer(
    host      =os.environ.get("DIAGRAMDSL_HOST",      "127.0.0.1"),
    port      =int(os.environ.get("DIAGRAMDSL_PORT",  "8421")),
    auth      =auth,
    log_level =os.environ.get("DIAGRAMDSL_LOG_LEVEL", "info"),
)

if __name__ == "__main__":
    server.start()
