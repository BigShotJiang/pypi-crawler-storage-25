"""
scripts/install_browser.py
~~~~~~~~~~~~~~~~~~~~~~~~~~

Post-install helper that downloads the Playwright Chromium browser.

Run once after installing the package:

    python scripts/install_browser.py

Or via the CLI shortcut:

    diagramdsl install-browser
"""

import subprocess
import sys


def main() -> None:
    print("Installing Playwright Chromium browser...")
    result = subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        check=False,
    )
    if result.returncode != 0:
        print(
            "\nPlaywright browser install failed.\n"
            "Try running manually:\n\n"
            "    playwright install chromium\n",
            file=sys.stderr,
        )
        sys.exit(result.returncode)
    print("Chromium installed successfully.")


if __name__ == "__main__":
    main()
