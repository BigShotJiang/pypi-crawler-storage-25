"""
scripts/start.py
~~~~~~~~~~~~~~~~

Production startup script for the DiagramDSL server.

Reads configuration from environment variables with sane defaults.
Run directly:

    python scripts/start.py

Or via the CLI:

    diagramdsl serve

Environment variables:
    DIAGRAMDSL_AUTH_TOKEN   Required. UUID v4 auth token.
    DIAGRAMDSL_HOST         Bind address. Default: 127.0.0.1
    DIAGRAMDSL_PORT         Port. Default: 8421
    DIAGRAMDSL_LOG_LEVEL    Log level. Default: info
"""

from __future__ import annotations

import logging
import os
import sys

logging.basicConfig(
    level   =logging.INFO,
    format  ="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt ="%Y-%m-%dT%H:%M:%S",
)

log = logging.getLogger("diagramdsl.start")


def main() -> None:
    auth = os.environ.get("DIAGRAMDSL_AUTH_TOKEN")
    if not auth:
        log.error(
            "DIAGRAMDSL_AUTH_TOKEN is not set.\n"
            "Generate a token with:  diagramdsl token\n"
            "Then set it:            export DIAGRAMDSL_AUTH_TOKEN=<token>"
        )
        sys.exit(1)

    host      = os.environ.get("DIAGRAMDSL_HOST",      "127.0.0.1")
    port      = int(os.environ.get("DIAGRAMDSL_PORT",  "8421"))
    log_level = os.environ.get("DIAGRAMDSL_LOG_LEVEL", "info")

    log.info("Starting DiagramDSL server on %s:%s", host, port)

    from diagramdsl import DiagramDSLServer

    server = DiagramDSLServer(
        host      =host,
        port      =port,
        auth      =auth,
        log_level =log_level,
    )
    server.start()


if __name__ == "__main__":
    main()
