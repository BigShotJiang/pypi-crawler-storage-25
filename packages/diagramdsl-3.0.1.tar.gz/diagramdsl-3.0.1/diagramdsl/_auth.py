"""
diagramdsl._auth
~~~~~~~~~~~~~~~~

Auth token validation helpers shared by the server and CLI.
"""

import re
import uuid

from diagramdsl.exceptions import InvalidTokenError

# Strict UUID v4 pattern — 8-4-4-4-12 hex, version nibble must be 4,
# variant nibble must be 8, 9, a, or b.
_UUID4_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


def validate_token_format(token: str) -> str:
    """
    Validate that *token* is a well-formed UUID v4 string.

    Returns the token (lowercased) if valid.
    Raises :class:`~diagramdsl.exceptions.InvalidTokenError` otherwise.
    """
    if not _UUID4_RE.match(token):
        raise InvalidTokenError(
            "auth token must be a valid UUID v4 string "
            "(e.g. f47ac10b-58cc-4372-a567-0e02b2c3d479). "
            "Generate one with: python -c \"import uuid; print(uuid.uuid4())\""
        )
    return token.lower()


def generate_token() -> str:
    """Return a fresh UUID v4 token string."""
    return str(uuid.uuid4())


def tokens_match(provided: str, expected: str) -> bool:
    """Constant-time comparison to guard against timing attacks."""
    import hmac
    return hmac.compare_digest(provided.lower(), expected.lower())
