"""
diagramdsl.exceptions
~~~~~~~~~~~~~~~~~~~~~

All exceptions raised by the diagramdsl package.
"""


class DiagramDSLError(Exception):
    """Base exception for all diagramdsl errors."""


class ValidationError(DiagramDSLError):
    """
    Raised when a steps object fails schema validation.

    Attributes:
        errors: List of human-readable error messages from the validator.
    """

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__("Validation failed:\n" + "\n".join(f"  • {e}" for e in errors))


class RenderError(DiagramDSLError):
    """Raised when the renderer fails to produce a diagram."""


class AuthError(DiagramDSLError):
    """Raised when a request carries an invalid or missing auth token."""


class InvalidTokenError(DiagramDSLError):
    """
    Raised at server startup when the provided auth token
    is not a valid UUID v4 string.
    """
