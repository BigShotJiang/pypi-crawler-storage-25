"""
diagramdsl.client
~~~~~~~~~~~~~~~~~

Python client for the DiagramDSL HTTP server.

Subclass :class:`DiagramDSL` and override :meth:`save` to control what
happens with each rendered PNG. The return value of ``save()`` is passed
back to the caller of ``render()``.

Example::

    from diagramdsl import DiagramDSL
    from uuid import uuid4

    class FileDiagramTool(DiagramDSL):
        def save(self, png_bytes: bytes) -> str:
            path = f"/tmp/{uuid4()}.png"
            with open(path, "wb") as f:
                f.write(png_bytes)
            return path

    tool   = FileDiagramTool(host="http://localhost:8421", auth="<token>")
    result = tool.render(steps)   # → "/tmp/abc123.png"
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from diagramdsl._auth import validate_token_format
from diagramdsl.exceptions import AuthError, RenderError, ValidationError

log = logging.getLogger(__name__)


class DiagramDSL:
    """
    Python client for the DiagramDSL server.

    Subclass this and override :meth:`save` to handle rendered PNG bytes.
    The return value of :meth:`save` is returned to the caller of :meth:`render`.

    Args:
        host: Base URL of the DiagramDSL server. Default: ``"http://localhost:8421"``.
        auth: UUID v4 auth token matching the server's token.
        timeout: HTTP request timeout in seconds. Default: ``30``.

    Example — S3 upload::

        import boto3
        from uuid import uuid4
        from diagramdsl import DiagramDSL

        class S3DiagramTool(DiagramDSL):
            def __init__(self, bucket: str, **kwargs):
                super().__init__(**kwargs)
                self.bucket = bucket
                self.s3     = boto3.client("s3")

            def save(self, png_bytes: bytes) -> str:
                key = f"diagrams/{uuid4()}.png"
                self.s3.put_object(
                    Bucket=self.bucket,
                    Key=key,
                    Body=png_bytes,
                    ContentType="image/png",
                )
                return f"https://{self.bucket}.s3.amazonaws.com/{key}"

        tool = S3DiagramTool(
            bucket = "my-diagrams",
            host   = "http://localhost:8421",
            auth   = os.environ["DIAGRAMDSL_AUTH_TOKEN"],
        )
        url = tool.render(steps)  # → "https://my-diagrams.s3.amazonaws.com/..."
    """

    def __init__(
        self,
        *,
        host:    str   = "http://localhost:8421",
        auth:    str,
        timeout: float = 30.0,
    ) -> None:
        self._host    = host.rstrip("/")
        self._auth    = validate_token_format(auth)
        self._timeout = timeout
        self._headers = {
            "Authorization": f"Bearer {self._auth}",
            "Content-Type":  "application/json",
        }

    # ═══════════════════════════════════════════════════════════════════
    # Core methods
    # ═══════════════════════════════════════════════════════════════════

    def render(self, steps: dict[str, Any]) -> Any:
        """
        Render *steps* and pass the resulting PNG bytes to :meth:`save`.

        Returns whatever :meth:`save` returns — ``None`` by default.

        Raises:
            ValidationError: steps failed schema validation.
            RenderError:     renderer threw during drawing.
            AuthError:       server rejected the auth token.

        Args:
            steps: DiagramDSL steps object.
                   Keys are step ids, values are step dicts.
        """
        png_bytes = self._post_render(steps)
        return self.save(png_bytes)

    def validate(self, steps: dict[str, Any]) -> dict:
        """
        Validate *steps* against the DSL schema without rendering.

        Returns:
            ``{ "ok": bool, "errors": list[str] }``
        """
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self._host}/render",
                headers={**self._headers, "X-Validate-Only": "true"},
                json=steps,
            )
        self._raise_for_auth(resp)

        if resp.status_code == 422:
            data = resp.json()
            return {"ok": False, "errors": data.get("errors", [])}

        return {"ok": True, "errors": []}

    def info(self) -> dict:
        """
        Return the DiagramDSL rules and schema object.

        Inject the return value into an agent system prompt so it
        understands how to construct valid step objects.
        """
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(f"{self._host}/info", headers=self._headers)
        self._raise_for_auth(resp)
        resp.raise_for_status()
        return resp.json()

    def docs(self, type_: str | None = None) -> dict:
        """
        Return schema documentation for a specific shape, ``"edge"``,
        or ``"direction"``.  Called with no argument → overview of all types.

        Args:
            type_: Shape name (``"circle"``, ``"box"``…), ``"edge"``,
                   ``"direction"``, or ``None`` for the overview.
        """
        url = f"{self._host}/docs" + (f"/{type_}" if type_ else "")
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(url, headers=self._headers)
        self._raise_for_auth(resp)
        resp.raise_for_status()
        return resp.json()

    # ═══════════════════════════════════════════════════════════════════
    # Override this
    # ═══════════════════════════════════════════════════════════════════

    def save(self, png_bytes: bytes) -> Any:
        """
        Called with the raw PNG bytes after a successful render.

        Override this method to control what happens with the PNG.
        The return value is passed back to the caller of :meth:`render`.

        Default implementation returns ``None``.

        Args:
            png_bytes: Raw PNG image data.

        Returns:
            Anything — the return value is forwarded from :meth:`render`.
            Common choices: a file path ``str``, a URL ``str``,
            or the raw ``bytes`` themselves.
        """
        return None

    # ═══════════════════════════════════════════════════════════════════
    # Async variants
    # ═══════════════════════════════════════════════════════════════════

    async def render_async(self, steps: dict[str, Any]) -> Any:
        """Async variant of :meth:`render`. Uses ``httpx.AsyncClient``."""
        png_bytes = await self._post_render_async(steps)
        result    = self.save(png_bytes)
        # Support async save() overrides transparently
        if hasattr(result, "__await__"):
            return await result
        return result

    async def info_async(self) -> dict:
        """Async variant of :meth:`info`."""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(f"{self._host}/info", headers=self._headers)
        self._raise_for_auth(resp)
        resp.raise_for_status()
        return resp.json()

    async def docs_async(self, type_: str | None = None) -> dict:
        """Async variant of :meth:`docs`."""
        url = f"{self._host}/docs" + (f"/{type_}" if type_ else "")
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(url, headers=self._headers)
        self._raise_for_auth(resp)
        resp.raise_for_status()
        return resp.json()

    # ═══════════════════════════════════════════════════════════════════
    # Internal
    # ═══════════════════════════════════════════════════════════════════

    def _post_render(self, steps: dict) -> bytes:
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self._host}/render",
                headers=self._headers,
                json=steps,
            )
        self._raise_for_auth(resp)

        if resp.status_code == 422:
            data = resp.json()
            raise ValidationError(data.get("errors", []))

        if resp.status_code != 200:
            raise RenderError(f"Server returned {resp.status_code}: {resp.text}")

        return resp.content   # raw PNG bytes

    async def _post_render_async(self, steps: dict) -> bytes:
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._host}/render",
                headers=self._headers,
                json=steps,
            )
        self._raise_for_auth(resp)

        if resp.status_code == 422:
            data = resp.json()
            raise ValidationError(data.get("errors", []))

        if resp.status_code != 200:
            raise RenderError(f"Server returned {resp.status_code}: {resp.text}")

        return resp.content

    @staticmethod
    def _raise_for_auth(resp: httpx.Response) -> None:
        if resp.status_code == 401:
            raise AuthError(
                "Server rejected the auth token. "
                "Check that the token matches the server's --auth value."
            )
