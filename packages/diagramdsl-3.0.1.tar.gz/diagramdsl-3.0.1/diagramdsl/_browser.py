"""
diagramdsl._browser
~~~~~~~~~~~~~~~~~~~~

Manages a single shared Playwright Chromium instance for the server.

The browser is launched once when the server starts and is reused for
all render requests. A new page is created per request and closed
immediately after, keeping memory usage low.
"""

from __future__ import annotations

import base64
import logging
from pathlib import Path
from typing import Any

from playwright.async_api import Browser, Playwright, async_playwright

from diagramdsl.exceptions import RenderError, ValidationError

log = logging.getLogger(__name__)

# Path to the bundled headless renderer HTML (ships inside the package)
_RENDERER_HTML = Path(__file__).parent / "_renderer.html"


class BrowserManager:
    """
    Async context manager that owns a Playwright browser instance.

    Usage::

        manager = BrowserManager()
        await manager.start()
        ...
        await manager.stop()

    Or via async context manager::

        async with BrowserManager() as manager:
            png = await manager.render(steps)
    """

    def __init__(self) -> None:
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._renderer_url = _RENDERER_HTML.as_uri()

    # ── Lifecycle ──────────────────────────────────────────────────────

    async def start(self) -> None:
        """Launch Chromium headless. Call once at server startup."""
        log.info("Starting Playwright Chromium...")
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",  # important in Docker
            ],
        )
        log.info("Browser ready.")

    async def stop(self) -> None:
        """Close the browser and Playwright. Call at server shutdown."""
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        log.info("Browser stopped.")

    async def __aenter__(self) -> "BrowserManager":
        await self.start()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.stop()

    # ── Public operations ──────────────────────────────────────────────

    async def validate(self, steps: dict) -> dict:
        """
        Run DiagramDSL.validate() in the browser.

        Returns { ok: bool, errors: list[str] }.
        """
        return await self._evaluate("window.__validate(arg)", arg=steps)

    async def render(self, steps: dict) -> bytes:
        """
        Render *steps* in the browser and return raw PNG bytes.

        Renders and captures toDataURL() in a single page session so the
        canvas state is preserved between the draw call and the export.

        Raises:
            ValidationError: if the steps object is invalid.
            RenderError:     if the renderer throws during drawing.
        """
        assert self._browser, "Browser not started. Call start() first."

        page = await self._browser.new_page()
        try:
            await page.goto(self._renderer_url)

            # Run validate + render + toDataURL all in one page session.
            # Playwright only supports a single serialisable argument, so we
            # pass everything as one dict and destructure inside the JS fn.
            result: dict = await page.evaluate(
                """(steps) => {
                    const validation = window.__validate(steps);
                    if (!validation.ok) {
                        return { ok: false, errors: validation.errors, dataURL: null };
                    }
                    const renderResult = window.__render(steps);
                    if (!renderResult.ok) {
                        return { ok: false, errors: [renderResult.error], dataURL: null };
                    }
                    return {
                        ok:      true,
                        errors:  [],
                        state:   renderResult.state,
                        dataURL: window.__toDataURL(),
                    };
                }""",
                steps,
            )

        finally:
            await page.close()

        if not result.get("ok"):
            errors = result.get("errors", [])
            if errors:
                raise ValidationError(errors)
            raise RenderError("Render failed with no error message.")

        data_url: str = result["dataURL"]
        _header, b64 = data_url.split(",", 1)
        return base64.b64decode(b64)

    async def info(self) -> dict:
        """Return DiagramDSL.info() — the machine-readable rules object."""
        return await self._evaluate("window.__info()")

    async def docs(self, type_: str | None = None) -> dict:
        """Return DiagramDSL.docs(type?) for a shape, 'edge', or 'direction'."""
        if type_:
            return await self._evaluate("window.__docs(arg)", arg=type_)
        return await self._evaluate("window.__docs()")

    # ── Internal ───────────────────────────────────────────────────────

    async def _evaluate(self, expression: str, **kwargs: Any) -> Any:
        """
        Open a fresh page, load the renderer, run *expression*, then close.

        Accepts at most one keyword argument (Playwright only serialises
        a single value). Pass it as ``arg=<value>`` and reference it as
        ``arg`` inside *expression*.

        Example::

            await self._evaluate("window.__validate(arg)", arg=steps)
        """
        assert self._browser, "Browser not started. Call start() first."

        page = await self._browser.new_page()
        try:
            await page.goto(self._renderer_url)

            if kwargs:
                if len(kwargs) > 1:
                    raise ValueError("_evaluate accepts at most one keyword argument")
                arg = next(iter(kwargs.values()))
                result = await page.evaluate(f"(arg) => {expression}", arg)
            else:
                result = await page.evaluate(f"() => {expression}")

            return result
        finally:
            await page.close()
