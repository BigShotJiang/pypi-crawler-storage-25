"""
diagramdsl
~~~~~~~~~~

Step-based diagram renderer for AI agents.

    from diagramdsl import DiagramDSL, DiagramDSLServer

Quickstart (server)::

    from diagramdsl import DiagramDSLServer
    import os

    server = DiagramDSLServer(
        port=8421,
        host="127.0.0.1",
        auth=os.environ["DIAGRAMDSL_AUTH_TOKEN"],
    )
    server.start()

Quickstart (client / tool)::

    from diagramdsl import DiagramDSL

    class MyTool(DiagramDSL):
        def save(self, png_bytes: bytes) -> str:
            path = f"/tmp/{uuid4()}.png"
            with open(path, "wb") as f:
                f.write(png_bytes)
            return path

    tool = MyTool(host="http://localhost:8421", auth="<your-token>")
    url  = tool.render(steps)
"""

from diagramdsl.client import DiagramDSL
from diagramdsl.server import DiagramDSLServer

__all__ = ["DiagramDSL", "DiagramDSLServer"]
__version__ = "3.0.0"
