"""
diagramdsl.server
~~~~~~~~~~~~~~~~~

FastAPI-based HTTP server that wraps the headless DiagramDSL renderer.

Endpoints:
    GET  /info          → DiagramDSL.info() as JSON
    POST /render        → Accepts steps JSON, returns PNG image

All requests must carry a matching Bearer token in the Authorization header.
The token must be a valid UUID v4 string.

Usage::

    from diagramdsl import DiagramDSLServer
    import os

    server = DiagramDSLServer(
        port=8421,
        host="127.0.0.1",
        auth=os.environ["DIAGRAMDSL_AUTH_TOKEN"],
    )
    server.start()    # blocking
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator

import uvicorn
from fastapi import FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from diagramdsl._auth import tokens_match, validate_token_format
from diagramdsl._browser import BrowserManager
from diagramdsl.exceptions import InvalidTokenError, RenderError, ValidationError

log = logging.getLogger(__name__)


def _build_app(browser: BrowserManager, auth_token: str) -> FastAPI:
    """Construct and configure the FastAPI application."""

    # ── Lifespan ───────────────────────────────────────────────────────

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncGenerator[None, None]:
        await browser.start()
        yield
        await browser.stop()

    app = FastAPI(
        title="DiagramDSL Server",
        description="Step-based diagram renderer for AI agents.",
        version="3.0.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url=None,
    )

    # ── CORS (adjust origins in production) ────────────────────────────

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Authorization", "Content-Type"],
    )

    # ── Auth middleware ────────────────────────────────────────────────

    @app.middleware("http")
    async def require_auth(request: Request, call_next: Any) -> Response:
        """
        Validate the Bearer token on every request.
        Skips auth for /docs and /openapi.json (API explorer).
        """
        if request.url.path in {"/docs", "/openapi.json", "/health"}:
            return await call_next(request)

        authorization = request.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"error": "Unauthorized", "detail": "Missing Bearer token."},
                headers={"WWW-Authenticate": "Bearer"},
            )

        provided = authorization[len("Bearer ") :].strip()
        if not tokens_match(provided, auth_token):
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"error": "Unauthorized", "detail": "Invalid token."},
                headers={"WWW-Authenticate": "Bearer"},
            )

        return await call_next(request)

    # ── Routes ─────────────────────────────────────────────────────────

    @app.api_route("/health", methods=["GET", "HEAD"], include_in_schema=False)
    async def health() -> dict:
        """Health check — no auth required."""
        return {"status": "ok", "version": "3.0.0"}

    @app.get(
        "/info",
        summary="DSL schema and rules",
        description="Returns the full DiagramDSL rules object. "
        "Inject this into an agent system prompt so it knows how to use the DSL.",
        response_model=None,
    )
    async def info() -> JSONResponse:
        result = await browser.info()
        return JSONResponse(content=result)

    @app.get(
        "/docs/{type_}",
        summary="Shape / edge / direction documentation",
        description=(
            "Returns detailed schema for a specific shape, 'edge', or 'direction'. "
            "Omit the path segment to get an overview of all types."
        ),
        response_model=None,
    )
    async def docs_type(type_: str) -> JSONResponse:
        result = await browser.docs(type_)
        return JSONResponse(content=result)

    @app.get("/docs", summary="DSL docs overview", response_model=None)
    async def docs_overview() -> JSONResponse:
        result = await browser.docs()
        return JSONResponse(content=result)

    @app.post(
        "/render",
        summary="Render a diagram",
        description=(
            "Accepts a DiagramDSL steps object as JSON. "
            "Returns a PNG image on success, or a JSON error object on validation failure."
        ),
    )
    async def render(request: Request) -> Response:
        try:
            steps = await request.json()
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Request body must be valid JSON.",
            )

        try:
            png_bytes = await browser.render(steps)
        except ValidationError as exc:
            return JSONResponse(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                content={"ok": False, "errors": exc.errors},
            )
        except RenderError as exc:
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"ok": False, "error": str(exc)},
            )

        return Response(content=png_bytes, media_type="image/png")

    return app


class DiagramDSLServer:
    """
    Headless DiagramDSL HTTP server.

    All requests require a UUID v4 Bearer token matching *auth*.

    Args:
        port:  TCP port to listen on. Default: ``8421``.
        host:  Bind address. Default: ``"127.0.0.1"`` (localhost only).
               Use ``"0.0.0.0"`` to accept external connections.
        auth:  UUID v4 auth token. **Required.**
               Every request must send ``Authorization: Bearer <auth>``.
        log_level: Uvicorn log level. Default: ``"info"``.

    Example::

        import os
        from diagramdsl import DiagramDSLServer

        server = DiagramDSLServer(
            port      = 8421,
            host      = "127.0.0.1",
            auth      = os.environ["DIAGRAMDSL_AUTH_TOKEN"],
            log_level = "warning",
        )
        server.start()   # blocking — runs until interrupted
    """

    def __init__(
        self,
        *,
        port: int = 8421,
        host: str = "127.0.0.1",
        auth: str,
        log_level: str = "info",
    ) -> None:
        try:
            self._auth = validate_token_format(auth)
        except InvalidTokenError as exc:
            raise InvalidTokenError(str(exc)) from exc

        self._port = port
        self._host = host
        self._log_level = log_level
        self._browser = BrowserManager()
        self._app = _build_app(self._browser, self._auth)

    # ── Public ─────────────────────────────────────────────────────────

    def start(self) -> None:
        """
        Start the server. **Blocking** — runs until interrupted (Ctrl-C).

        For async usage (e.g. inside an existing event loop), use
        :meth:`start_async` instead.
        """
        log.info("DiagramDSL server starting on %s:%s", self._host, self._port)
        uvicorn.run(
            self._app,
            host=self._host,
            port=self._port,
            log_level=self._log_level,
        )

    async def start_async(self) -> None:
        """
        Start the server inside an existing asyncio event loop.

        Useful when embedding the server inside a larger async application.
        """
        config = uvicorn.Config(
            self._app,
            host=self._host,
            port=self._port,
            log_level=self._log_level,
        )
        server = uvicorn.Server(config)
        await server.serve()

    @property
    def app(self) -> FastAPI:
        """The underlying FastAPI application (for testing or mounting)."""
        return self._app
