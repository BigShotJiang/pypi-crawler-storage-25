"""
diagramdsl.cli
~~~~~~~~~~~~~~

Command-line interface for DiagramDSL.

Commands:
    diagramdsl serve   — start the HTTP server
    diagramdsl token   — generate a fresh UUID v4 auth token
    diagramdsl info    — print the DSL rules to stdout
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys


def _cmd_serve(args: argparse.Namespace) -> None:
    """Start the DiagramDSL HTTP server."""
    # Resolve auth — CLI flag → env var → error
    auth = args.auth or os.environ.get("DIAGRAMDSL_AUTH_TOKEN")
    if not auth:
        print(
            "Error: auth token is required.\n"
            "  Pass it via --auth or set the DIAGRAMDSL_AUTH_TOKEN environment variable.\n"
            "  Generate a token: diagramdsl token",
            file=sys.stderr,
        )
        sys.exit(1)

    from diagramdsl.server import DiagramDSLServer

    server = DiagramDSLServer(
        port      =args.port,
        host      =args.host,
        auth      =auth,
        log_level =args.log_level,
    )
    server.start()


def _cmd_token(_args: argparse.Namespace) -> None:
    """Print a fresh UUID v4 token."""
    from diagramdsl._auth import generate_token
    print(generate_token())


def _cmd_info(args: argparse.Namespace) -> None:
    """Print DSL info / docs to stdout (queries a running server)."""
    auth = args.auth or os.environ.get("DIAGRAMDSL_AUTH_TOKEN")
    if not auth:
        print("Error: --auth or DIAGRAMDSL_AUTH_TOKEN required.", file=sys.stderr)
        sys.exit(1)

    from diagramdsl.client import DiagramDSL

    client = DiagramDSL(host=args.host, auth=auth)

    if args.type:
        result = client.docs(args.type)
    else:
        result = client.info()

    print(json.dumps(result, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(
        prog       ="diagramdsl",
        description="DiagramDSL — step-based diagram renderer for AI agents.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ── serve ──────────────────────────────────────────────────────────
    serve_p = sub.add_parser("serve", help="Start the DiagramDSL HTTP server.")
    serve_p.add_argument("--port",      type=int, default=8421,         help="Port (default: 8421)")
    serve_p.add_argument("--host",      type=str, default="127.0.0.1",  help="Bind address (default: 127.0.0.1)")
    serve_p.add_argument("--auth",      type=str, default=None,         help="UUID v4 auth token (or set DIAGRAMDSL_AUTH_TOKEN)")
    serve_p.add_argument("--log-level", type=str, default="info",       help="Log level (default: info)", dest="log_level")
    serve_p.set_defaults(func=_cmd_serve)

    # ── token ──────────────────────────────────────────────────────────
    token_p = sub.add_parser("token", help="Generate a fresh UUID v4 auth token.")
    token_p.set_defaults(func=_cmd_token)

    # ── info ───────────────────────────────────────────────────────────
    info_p = sub.add_parser("info", help="Print DSL rules / docs from a running server.")
    info_p.add_argument("--host", type=str, default="http://localhost:8421", help="Server URL")
    info_p.add_argument("--auth", type=str, default=None, help="Auth token")
    info_p.add_argument("type",   type=str, nargs="?",   help="Shape / 'edge' / 'direction' (optional)")
    info_p.set_defaults(func=_cmd_info)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
