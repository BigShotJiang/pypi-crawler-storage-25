"""
Example 05 — async usage.

For applications already running an asyncio event loop
(FastAPI, Starlette, async agent frameworks).
"""

import asyncio
import os
from diagramdsl import DiagramDSL


class AsyncFileTool(DiagramDSL):
    async def save(self, png_bytes: bytes) -> str:
        # async save() is supported — just make it a coroutine
        path = "/tmp/diagramdsl_async.png"
        with open(path, "wb") as f:
            f.write(png_bytes)
        return path


async def main():
    tool = AsyncFileTool(
        host=os.environ.get("DIAGRAMDSL_HOST", "http://localhost:8421"),
        auth=os.environ["DIAGRAMDSL_AUTH_TOKEN"],
    )

    steps = {
        "1": {"node": "box",    "label": "Async task A"},
        "2": {"node": "box",    "label": "Async task B",
              "connect": {"from": "1", "direction": "right"}},
        "3": {"node": "circle", "label": "Done",
              "connect": {"from": "2", "direction": "right"},
              "specifics": {"radius": 28}},
    }

    path = await tool.render_async(steps)
    print(f"Saved: {path}")

    # Also works for info / docs
    rules = await tool.info_async()
    print(f"DSL version: {rules['version']}")


if __name__ == "__main__":
    asyncio.run(main())
