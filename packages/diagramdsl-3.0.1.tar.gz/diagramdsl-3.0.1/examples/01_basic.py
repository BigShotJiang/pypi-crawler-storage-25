"""
Example 01 — basic usage.

Renders a simple three-node flow and saves the PNG to /tmp/basic.png.
Start the server before running this example:
    diagramdsl serve
"""

import os
from diagramdsl import DiagramDSL


class FileTool(DiagramDSL):
    """Saves each rendered PNG to a local file."""

    def save(self, png_bytes: bytes) -> str:
        path = "/tmp/diagramdsl_basic.png"
        with open(path, "wb") as f:
            f.write(png_bytes)
        print(f"Saved: {path}")
        return path


tool = FileTool(
    host=os.environ.get("DIAGRAMDSL_HOST", "http://localhost:8421"),
    auth=os.environ["DIAGRAMDSL_AUTH_TOKEN"],
)

steps = {
    "1": {
        "node":  "circle",
        "label": "Start",
        "attributes": {"background": "#fff7ed", "borderColor": "#e37502"},
        "specifics": {"radius": 36},
    },
    "2": {
        "node":    "box",
        "label":   "Process",
        "connect": {"from": "1", "direction": "right", "label": "begin"},
    },
    "3": {
        "node":  "circle",
        "label": "End",
        "attributes": {"background": "#f0fdf4", "borderColor": "#86efac"},
        "specifics": {"radius": 36},
        "connect": {"from": "2", "direction": "right", "label": "done"},
    },
}

path = tool.render(steps)
