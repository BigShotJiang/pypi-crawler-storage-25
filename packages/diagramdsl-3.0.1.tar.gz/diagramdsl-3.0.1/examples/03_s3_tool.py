"""
Example 03 — custom save() that uploads to S3.

Requires: pip install boto3
Set AWS credentials in environment before running.
"""

import os
from uuid import uuid4

import boto3
from diagramdsl import DiagramDSL


class S3DiagramTool(DiagramDSL):
    """
    Renders a diagram and uploads the PNG to S3.
    Returns the public URL.
    """

    def __init__(self, bucket: str, **kwargs):
        super().__init__(**kwargs)
        self.bucket = bucket
        self.s3     = boto3.client("s3")

    def save(self, png_bytes: bytes) -> str:
        key = f"diagrams/{uuid4()}.png"
        self.s3.put_object(
            Bucket=self.bucket,
            Key=key,
            Body=png_bytes,
            ContentType="image/png",
        )
        url = f"https://{self.bucket}.s3.amazonaws.com/{key}"
        print(f"Uploaded: {url}")
        return url


tool = S3DiagramTool(
    bucket=os.environ["S3_BUCKET"],
    host  =os.environ.get("DIAGRAMDSL_HOST", "http://localhost:8421"),
    auth  =os.environ["DIAGRAMDSL_AUTH_TOKEN"],
)

steps = {
    "1": {"node": "box", "label": "API"},
    "2": {
        "node":    "cylinder",
        "label":   "S3",
        "attributes": {"background": "#fff7ed", "borderColor": "#e37502"},
        "connect": {"from": "1", "direction": "right", "label": "upload"},
    },
}

url = tool.render(steps)
# → "https://my-bucket.s3.amazonaws.com/diagrams/abc123.png"
