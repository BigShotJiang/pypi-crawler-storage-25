"""
Example 02 — flowchart with decision branching.

Demonstrates diamond nodes, dashed edges, and styled error paths.
"""

import os
from diagramdsl import DiagramDSL


class FileTool(DiagramDSL):
    def save(self, png_bytes: bytes) -> str:
        path = "/tmp/diagramdsl_flowchart.png"
        with open(path, "wb") as f:
            f.write(png_bytes)
        print(f"Saved: {path}")
        return path


tool = FileTool(
    host=os.environ.get("DIAGRAMDSL_HOST", "http://localhost:8421"),
    auth=os.environ["DIAGRAMDSL_AUTH_TOKEN"],
)

steps = {
    "1": {
        "node":  "pill",
        "label": "Request arrives",
        "attributes": {"background": "#f0f9ff", "borderColor": "#7dd3fc"},
    },
    "2": {
        "node":    "box",
        "label":   "Parse & validate",
        "connect": {"from": "1", "direction": "right"},
    },
    "3": {
        "node":    "diamond",
        "label":   "Authenticated?",
        "attributes": {"background": "#fefce8", "borderColor": "#fde047"},
        "connect": {"from": "2", "direction": "right"},
    },
    "4": {
        "node":    "box",
        "label":   "Handle request",
        "attributes": {"background": "#f0fdf4"},
        "connect": {"from": "3", "direction": "down", "label": "yes"},
    },
    "5": {
        "node":  "pill",
        "label": "Return 401",
        "attributes": {
            "background": "#fff1f2",
            "color":      "#9f1239",
            "borderColor":"#fda4af",
        },
        "connect": {
            "from":        "3",
            "direction":   "right",
            "label":       "no",
            "strokeColor": "#fda4af",
            "dashed":      True,
        },
    },
    "6": {
        "node":    "cylinder",
        "label":   "Write to DB",
        "attributes": {"background": "#f0fdf4", "borderColor": "#86efac"},
        "connect": {"from": "4", "direction": "right", "label": "persist"},
    },
    "7": {
        "node":  "pill",
        "label": "Return 200",
        "attributes": {"background": "#f0fdf4", "borderColor": "#86efac"},
        "connect": {"from": "6", "direction": "right"},
    },
}

tool.render(steps)
