"""
Example 04 — minimal agent loop.

Shows how an AI agent can iteratively build a diagram:
  1. Ask the LLM to emit a steps object
  2. Validate it
  3. Render it and send the PNG + state back to the agent
  4. Repeat

Requires: pip install openai
"""

import json
import os
from diagramdsl import DiagramDSL


# ── Tool setup ────────────────────────────────────────────────────────


class AgentDiagramTool(DiagramDSL):
    """Returns raw PNG bytes so the loop can handle them directly."""

    def save(self, png_bytes: bytes) -> bytes:
        return png_bytes


tool = AgentDiagramTool(
    host=os.environ.get("DIAGRAMDSL_HOST", "http://localhost:8421"),
    auth=os.environ["DIAGRAMDSL_AUTH_TOKEN"],
)

# ── System prompt ─────────────────────────────────────────────────────

DSL_RULES = json.dumps(tool.info(), indent=2)
SYSTEM_PROMPT = f"""
You are a diagram agent. You produce diagrams by emitting JSON step objects.

DiagramDSL rules:
{DSL_RULES}

After each render you will receive:
- The full canvas state: {{ "1": {{ x, y, w, h, cx, cy }}, ... }}

Use the state to decide where to place the next step.
Add 1-3 steps per turn. When the diagram is complete, say "DONE".

Respond with ONLY a JSON object of new steps. No explanation, no markdown.
""".strip()


# ── Agent loop ────────────────────────────────────────────────────────


def run_agent(user_request: str, max_turns: int = 8) -> bytes:
    """
    Run an iterative diagram-building loop.
    Returns the final PNG bytes.
    """
    import openai

    client = openai.OpenAI()
    steps = {}
    state = {}
    history = [{"role": "system", "content": SYSTEM_PROMPT}]
    last_png: bytes = b""

    for turn in range(max_turns):
        # Build the user message for this turn
        user_content = (
            user_request
            if turn == 0
            else (f"Current state:{json.dumps(state, indent=2)}Continue the diagram.")
        )
        history.append({"role": "user", "content": user_content})

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=history,
            response_format={"type": "json_object"},
        )

        raw = response.choices[0].message.content.strip()

        if "DONE" in raw:
            print(f"Agent finished after {turn + 1} turns.")
            break

        # Parse and merge new steps
        try:
            new_steps = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"Turn {turn + 1}: JSON parse error — {e}")
            break

        steps.update(new_steps)
        history.append({"role": "assistant", "content": raw})

        # Validate before render
        validation = tool.validate(steps)
        if not validation["ok"]:
            error_msg = "Validation errors:" + "".join(validation["errors"])
            print(f"Turn {turn + 1}: {error_msg}")
            history.append({"role": "user", "content": error_msg + "Fix these errors."})
            continue

        # Render
        from diagramdsl.exceptions import RenderError, ValidationError

        try:
            png_bytes = tool.render(steps)
            last_png = png_bytes
            print(f"Turn {turn + 1}: rendered {len(steps)} steps.")
        except (ValidationError, RenderError) as e:
            print(f"Turn {turn + 1}: render error — {e}")
            history.append(
                {"role": "user", "content": f"Render error: {e}Fix the steps."}
            )

    return last_png


if __name__ == "__main__":
    png = run_agent(
        "Draw a system architecture diagram for a Django web app with PostgreSQL and Redis."
    )

    with open("/tmp/agent_diagram.png", "wb") as f:
        f.write(png)
    print("Final diagram saved to /tmp/agent_diagram.png")
