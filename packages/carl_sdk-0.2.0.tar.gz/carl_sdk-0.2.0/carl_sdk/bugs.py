from __future__ import annotations

from typing import TYPE_CHECKING

from .types import BugConversation

if TYPE_CHECKING:
    from .http import AsyncHttpClient, HttpClient


class BugClient:
    def __init__(self, http: HttpClient, default_user_id: str | None = None):
        self._http = http
        self._default_user_id = default_user_id

    def start(self, description: str, user_id: str | None = None) -> BugConversation:
        data = self._http.post("/v1/bugs/conversations", {
            "message": description,
            "userId": user_id or self._default_user_id,
        })
        return BugConversation.from_dict(data)

    def reply(self, conversation_id: str, message: str) -> BugConversation:
        data = self._http.post(
            f"/v1/bugs/conversations/{conversation_id}/messages",
            {"message": message},
        )
        return BugConversation.from_dict(data)

    def get(self, conversation_id: str) -> BugConversation:
        data = self._http.get(f"/v1/bugs/conversations/{conversation_id}")
        return BugConversation.from_dict(data)


class AsyncBugClient:
    def __init__(self, http: AsyncHttpClient, default_user_id: str | None = None):
        self._http = http
        self._default_user_id = default_user_id

    async def start(self, description: str, user_id: str | None = None) -> BugConversation:
        data = await self._http.post("/v1/bugs/conversations", {
            "message": description,
            "userId": user_id or self._default_user_id,
        })
        return BugConversation.from_dict(data)

    async def reply(self, conversation_id: str, message: str) -> BugConversation:
        data = await self._http.post(
            f"/v1/bugs/conversations/{conversation_id}/messages",
            {"message": message},
        )
        return BugConversation.from_dict(data)

    async def get(self, conversation_id: str) -> BugConversation:
        data = await self._http.get(f"/v1/bugs/conversations/{conversation_id}")
        return BugConversation.from_dict(data)
