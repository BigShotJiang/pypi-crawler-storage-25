from __future__ import annotations

import asyncio
import os
from dataclasses import asdict

from ..client import AsyncCarl


def _require_env(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        raise RuntimeError(f"{name} environment variable is required")
    return val


def create_server():
    from mcp.server import Server

    server = Server("carl")
    client: AsyncCarl | None = None

    def get_client() -> AsyncCarl:
        nonlocal client
        if client is None:
            client = AsyncCarl(
                api_key=_require_env("CARL_API_KEY"),
                repo=_require_env("CARL_REPO"),
                base_url=os.environ.get("CARL_BASE_URL", "https://api.carl.szns.dev"),
            )
        return client

    @server.list_tools()
    async def list_tools():
        from mcp.types import Tool

        return [
            Tool(
                name="create_pod",
                description="Create a new pod to run a task",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "task": {"type": "string", "description": "Task description for the pod"},
                        "user_id": {"type": "string", "description": "User ID (optional)"},
                    },
                    "required": ["task"],
                },
            ),
            Tool(
                name="list_pods",
                description="List all pods",
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="get_pod",
                description="Get details of a specific pod",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pod_id": {"type": "string", "description": "Pod ID"},
                    },
                    "required": ["pod_id"],
                },
            ),
            Tool(
                name="delete_pod",
                description="Delete a pod",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pod_id": {"type": "string", "description": "Pod ID"},
                    },
                    "required": ["pod_id"],
                },
            ),
            Tool(
                name="get_pod_logs",
                description="Get logs from a pod (streams all available log lines)",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pod_id": {"type": "string", "description": "Pod ID"},
                    },
                    "required": ["pod_id"],
                },
            ),
            Tool(
                name="send_pod_message",
                description="Send a chat message to a running pod and get a response",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pod_id": {"type": "string", "description": "Pod ID"},
                        "message": {"type": "string", "description": "Message to send"},
                    },
                    "required": ["pod_id", "message"],
                },
            ),
            Tool(
                name="stream_pod_activity",
                description="Stream activity events from a running pod",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pod_id": {"type": "string", "description": "Pod ID"},
                    },
                    "required": ["pod_id"],
                },
            ),
            Tool(
                name="start_bug",
                description="Start a bug report conversation",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "description": {"type": "string", "description": "Bug description"},
                        "user_id": {"type": "string", "description": "User ID (optional)"},
                    },
                    "required": ["description"],
                },
            ),
            Tool(
                name="reply_to_bug",
                description="Reply to an active bug conversation",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "conversation_id": {"type": "string", "description": "Conversation ID"},
                        "message": {"type": "string", "description": "Reply message"},
                    },
                    "required": ["conversation_id", "message"],
                },
            ),
            Tool(
                name="get_bug",
                description="Get details of a bug conversation",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "conversation_id": {"type": "string", "description": "Conversation ID"},
                    },
                    "required": ["conversation_id"],
                },
            ),
            Tool(
                name="get_pod_config",
                description="Get the current pod configuration",
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="set_pod_config",
                description="Update pod configuration",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "setup_script": {"type": "string", "description": "Shell command(s) run after pod setup, before Claude session"},
                        "env_vars": {
                            "type": "object",
                            "description": "Environment variables",
                            "additionalProperties": {"type": "string"},
                        },
                        "claude_md": {"type": "string", "description": "CLAUDE.md content for pods"},
                    },
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        from mcp.types import TextContent

        carl = get_client()

        if name == "create_pod":
            pod = await carl.pods.create(arguments["task"], arguments.get("user_id"))
            return [TextContent(type="text", text=str(asdict(pod)))]

        if name == "list_pods":
            pods = await carl.pods.list()
            return [TextContent(type="text", text=str([asdict(p) for p in pods]))]

        if name == "get_pod":
            pod = await carl.pods.get(arguments["pod_id"])
            return [TextContent(type="text", text=str(asdict(pod)))]

        if name == "delete_pod":
            await carl.pods.delete(arguments["pod_id"])
            return [TextContent(type="text", text="Pod deleted")]

        if name == "get_pod_logs":
            lines: list[str] = []
            async for line in await carl.pods.logs(arguments["pod_id"]):
                lines.append(line)
            return [TextContent(type="text", text="\n".join(lines))]

        if name == "send_pod_message":
            resp = await carl.pods.chat(arguments["pod_id"], arguments["message"])
            return [TextContent(type="text", text=str(asdict(resp)))]

        if name == "stream_pod_activity":
            events: list[str] = []
            async for event in await carl.pods.activity(arguments["pod_id"]):
                events.append(event)
                if len(events) >= 100:
                    break
            return [TextContent(type="text", text="\n".join(events))]

        if name == "start_bug":
            conv = await carl.bugs.start(arguments["description"], arguments.get("user_id"))
            return [TextContent(type="text", text=str(asdict(conv)))]

        if name == "reply_to_bug":
            conv = await carl.bugs.reply(arguments["conversation_id"], arguments["message"])
            return [TextContent(type="text", text=str(asdict(conv)))]

        if name == "get_bug":
            conv = await carl.bugs.get(arguments["conversation_id"])
            return [TextContent(type="text", text=str(asdict(conv)))]

        if name == "get_pod_config":
            config = await carl.config.get()
            return [TextContent(type="text", text=str(asdict(config)))]

        if name == "set_pod_config":
            config = await carl.config.set(
                setup_script=arguments.get("setup_script"),
                env_vars=arguments.get("env_vars"),
                claude_md=arguments.get("claude_md"),
            )
            return [TextContent(type="text", text=str(asdict(config)))]

        raise ValueError(f"Unknown tool: {name}")

    return server


def main():
    from mcp.server.stdio import stdio_server

    server = create_server()

    async def run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(run())
