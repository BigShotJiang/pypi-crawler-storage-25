from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Message:
    role: str
    content: str

    @classmethod
    def from_dict(cls, data: dict) -> Message:
        return cls(role=data["role"], content=data["content"])


@dataclass
class BugSpec:
    title: str
    description: str
    priority: str
    repo_url: str

    @classmethod
    def from_dict(cls, data: dict) -> BugSpec:
        return cls(
            title=data["title"],
            description=data["description"],
            priority=data["priority"],
            repo_url=data["repo_url"],
        )


@dataclass
class BugConversation:
    id: str
    state: str
    response: str
    messages: list[Message] = field(default_factory=list)
    result: BugSpec | None = None

    @classmethod
    def from_dict(cls, data: dict) -> BugConversation:
        messages = [Message.from_dict(m) for m in data.get("messages") or []]
        result = BugSpec.from_dict(data["result"]) if data.get("result") else None
        return cls(
            id=data["id"],
            state=data["state"],
            response=data.get("response", ""),
            messages=messages,
            result=result,
        )


@dataclass
class Pod:
    id: str
    name: str
    status: str
    task: str
    repo: str
    created_at: str
    region: str | None = None
    user_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> Pod:
        return cls(
            id=data["id"],
            name=data.get("name") or data.get("pod_name", ""),
            status=data["status"],
            task=data.get("task", ""),
            repo=data.get("repo", ""),
            created_at=data.get("createdAt") or data.get("created_at", ""),
            region=data.get("region"),
            user_id=data.get("user_id"),
        )


@dataclass
class ChatResponse:
    response: str
    status: str
    cost_usd: float | None = None
    duration_ms: int | None = None
    num_turns: int | None = None

    @classmethod
    def from_dict(cls, data: dict) -> ChatResponse:
        return cls(
            response=data.get("response", ""),
            status=data.get("status", ""),
            cost_usd=data.get("cost_usd"),
            duration_ms=data.get("duration_ms"),
            num_turns=data.get("num_turns"),
        )


@dataclass
class PodConfig:
    setup_script: str | None = None
    env_vars: dict[str, str] | None = None
    claude_md: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> PodConfig:
        return cls(
            setup_script=data.get("setup_script"),
            env_vars=data.get("env_vars"),
            claude_md=data.get("claude_md"),
        )

    def to_dict(self) -> dict:
        d: dict = {}
        if self.setup_script is not None:
            d["setup_script"] = self.setup_script
        if self.env_vars is not None:
            d["env_vars"] = self.env_vars
        if self.claude_md is not None:
            d["claude_md"] = self.claude_md
        return d
