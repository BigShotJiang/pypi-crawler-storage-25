from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Any

import httpx

from .errors import AuthError, CarlError, NotFoundError, RateLimitError, ValidationError

_ERROR_MAP: dict[int, type[CarlError]] = {
    401: AuthError,
    403: AuthError,
    404: NotFoundError,
    422: ValidationError,
    429: RateLimitError,
}


def _extract_message(response: httpx.Response) -> str:
    try:
        body = response.json()
        return body.get("message") or body.get("error") or response.reason_phrase
    except Exception:
        return response.reason_phrase


def _handle_error(response: httpx.Response) -> None:
    message = _extract_message(response)
    error_cls = _ERROR_MAP.get(response.status_code)
    if error_cls:
        raise error_cls(message)
    raise CarlError(message, response.status_code, "api_error")


class HttpClient:
    def __init__(self, api_key: str, repo: str, base_url: str):
        if not api_key or not api_key.strip():
            raise ValueError("api_key must not be empty")
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "X-Carl-Repo": repo,
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(600, connect=10),
        )

    def close(self) -> None:
        self._client.close()

    def get(self, path: str) -> Any:
        r = self._client.get(path)
        if r.status_code >= 400:
            _handle_error(r)
        return r.json()

    def post(self, path: str, body: Any = None) -> Any:
        r = self._client.post(path, json=body)
        if r.status_code >= 400:
            _handle_error(r)
        return r.json()

    def put(self, path: str, body: Any = None) -> Any:
        r = self._client.put(path, json=body)
        if r.status_code >= 400:
            _handle_error(r)
        return r.json()

    def delete(self, path: str) -> None:
        r = self._client.delete(path)
        if r.status_code >= 400:
            _handle_error(r)

    def stream(self, path: str) -> Iterator[str]:
        with self._client.stream(
            "GET",
            path,
            headers={"Accept": "text/event-stream"},
        ) as r:
            if r.status_code >= 400:
                r.read()
                _handle_error(r)
            try:
                for line in r.iter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            return
                        yield data
            except httpx.RemoteProtocolError:
                return


class AsyncHttpClient:
    def __init__(self, api_key: str, repo: str, base_url: str):
        if not api_key or not api_key.strip():
            raise ValueError("api_key must not be empty")
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "X-Carl-Repo": repo,
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(600, connect=10),
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def get(self, path: str) -> Any:
        r = await self._client.get(path)
        if r.status_code >= 400:
            _handle_error(r)
        return r.json()

    async def post(self, path: str, body: Any = None) -> Any:
        r = await self._client.post(path, json=body)
        if r.status_code >= 400:
            _handle_error(r)
        return r.json()

    async def put(self, path: str, body: Any = None) -> Any:
        r = await self._client.put(path, json=body)
        if r.status_code >= 400:
            _handle_error(r)
        return r.json()

    async def delete(self, path: str) -> None:
        r = await self._client.delete(path)
        if r.status_code >= 400:
            _handle_error(r)

    async def stream(self, path: str) -> AsyncIterator[str]:
        async with self._client.stream(
            "GET",
            path,
            headers={"Accept": "text/event-stream"},
        ) as r:
            if r.status_code >= 400:
                await r.aread()
                _handle_error(r)
            try:
                async for line in r.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            return
                        yield data
            except httpx.RemoteProtocolError:
                return
