from __future__ import annotations

from .bugs import AsyncBugClient, BugClient
from .config import AsyncConfigClient, ConfigClient
from .http import AsyncHttpClient, HttpClient
from .pods import AsyncPodClient, PodClient

DEFAULT_BASE_URL = "https://api.carl.szns.dev"


class Carl:
    def __init__(
        self,
        api_key: str,
        repo: str,
        *,
        default_user_id: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if not repo:
            raise ValueError("repo is required")

        http = HttpClient(api_key, repo, base_url)
        self.bugs = BugClient(http, default_user_id)
        self.pods = PodClient(http, default_user_id)
        self.config = ConfigClient(http)
        self._http = http

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Carl:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncCarl:
    def __init__(
        self,
        api_key: str,
        repo: str,
        *,
        default_user_id: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if not repo:
            raise ValueError("repo is required")

        http = AsyncHttpClient(api_key, repo, base_url)
        self.bugs = AsyncBugClient(http, default_user_id)
        self.pods = AsyncPodClient(http, default_user_id)
        self.config = AsyncConfigClient(http)
        self._http = http

    async def close(self) -> None:
        await self._http.close()

    async def __aenter__(self) -> AsyncCarl:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
