class CarlError(Exception):
    def __init__(self, message: str, status: int, code: str | None = None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code


class AuthError(CarlError):
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, 401, "auth_error")


class NotFoundError(CarlError):
    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, 404, "not_found")


class ValidationError(CarlError):
    def __init__(self, message: str = "Validation error"):
        super().__init__(message, 422, "validation_error")


class RateLimitError(CarlError):
    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, 429, "rate_limit_error")
