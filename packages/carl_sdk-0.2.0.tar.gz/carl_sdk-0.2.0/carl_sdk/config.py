from __future__ import annotations

from typing import TYPE_CHECKING

from .types import PodConfig

if TYPE_CHECKING:
    from .http import AsyncHttpClient, HttpClient


class ConfigClient:
    def __init__(self, http: HttpClient):
        self._http = http

    def get(self) -> PodConfig:
        data = self._http.get("/v1/pod-config")
        return PodConfig.from_dict(data)

    def set(
        self,
        *,
        setup_script: str | None = None,
        env_vars: dict[str, str] | None = None,
        claude_md: str | None = None,
    ) -> PodConfig:
        config = PodConfig(setup_script=setup_script, env_vars=env_vars, claude_md=claude_md)
        data = self._http.put("/v1/pod-config", config.to_dict())
        return PodConfig.from_dict(data)


class AsyncConfigClient:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def get(self) -> PodConfig:
        data = await self._http.get("/v1/pod-config")
        return PodConfig.from_dict(data)

    async def set(
        self,
        *,
        setup_script: str | None = None,
        env_vars: dict[str, str] | None = None,
        claude_md: str | None = None,
    ) -> PodConfig:
        config = PodConfig(setup_script=setup_script, env_vars=env_vars, claude_md=claude_md)
        data = await self._http.put("/v1/pod-config", config.to_dict())
        return PodConfig.from_dict(data)
