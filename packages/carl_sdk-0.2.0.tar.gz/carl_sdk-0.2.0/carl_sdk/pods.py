from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING

from .types import ChatResponse, Pod

if TYPE_CHECKING:
    from .http import AsyncHttpClient, HttpClient


class PodClient:
    def __init__(self, http: HttpClient, default_user_id: str | None = None):
        self._http = http
        self._default_user_id = default_user_id

    def create(self, task: str, user_id: str | None = None) -> Pod:
        data = self._http.post("/v1/pods", {
            "task": task,
            "userId": user_id or self._default_user_id,
        })
        return Pod.from_dict(data)

    def list(self) -> list[Pod]:
        data = self._http.get("/v1/pods")
        return [Pod.from_dict(p) for p in data]

    def get(self, pod_id: str) -> Pod:
        data = self._http.get(f"/v1/pods/{pod_id}")
        return Pod.from_dict(data)

    def chat(self, pod_id: str, message: str) -> ChatResponse:
        data = self._http.post(f"/v1/pods/{pod_id}/messages", {"message": message})
        return ChatResponse.from_dict(data)

    def activity(self, pod_id: str) -> Iterator[str]:
        return self._http.stream(f"/v1/pods/{pod_id}/activity")

    def logs(self, pod_id: str) -> Iterator[str]:
        return self._http.stream(f"/v1/pods/{pod_id}/logs")

    def delete(self, pod_id: str) -> None:
        self._http.delete(f"/v1/pods/{pod_id}")


class AsyncPodClient:
    def __init__(self, http: AsyncHttpClient, default_user_id: str | None = None):
        self._http = http
        self._default_user_id = default_user_id

    async def create(self, task: str, user_id: str | None = None) -> Pod:
        data = await self._http.post("/v1/pods", {
            "task": task,
            "userId": user_id or self._default_user_id,
        })
        return Pod.from_dict(data)

    async def list(self) -> list[Pod]:
        data = await self._http.get("/v1/pods")
        return [Pod.from_dict(p) for p in data]

    async def get(self, pod_id: str) -> Pod:
        data = await self._http.get(f"/v1/pods/{pod_id}")
        return Pod.from_dict(data)

    async def chat(self, pod_id: str, message: str) -> ChatResponse:
        data = await self._http.post(f"/v1/pods/{pod_id}/messages", {"message": message})
        return ChatResponse.from_dict(data)

    async def activity(self, pod_id: str) -> AsyncIterator[str]:
        return self._http.stream(f"/v1/pods/{pod_id}/activity")

    async def logs(self, pod_id: str) -> AsyncIterator[str]:
        return self._http.stream(f"/v1/pods/{pod_id}/logs")

    async def delete(self, pod_id: str) -> None:
        await self._http.delete(f"/v1/pods/{pod_id}")
