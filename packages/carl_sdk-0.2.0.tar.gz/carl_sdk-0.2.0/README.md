# carl-sdk (Python)

Python SDK for the [Carl](https://carl.szns.dev) API. Includes sync and async clients, plus an MCP server.

## Install

```bash
pip install carl-sdk
```

For MCP server support:

```bash
pip install carl-sdk[mcp]
```

## Usage

```python
from carl_sdk import Carl

carl = Carl(api_key="your-api-key", repo="org/repo")

# Pods
pod = carl.pods.create("fix the login bug")
pods = carl.pods.list()

# Chat with a pod
response = carl.pods.chat(pod.id, "What files did you change?")
print(response.response)    # assistant's reply
print(response.status)      # "ok" or "error"
print(response.cost_usd)    # cost in USD
print(response.duration_ms) # response time
print(response.num_turns)   # number of agent turns

# Stream activity events (tool calls, results, text)
for event in carl.pods.activity(pod.id):
    print(event)  # JSON string: {"type": "text", "text": "...", "ts": ...}

# Stream pod logs
for chunk in carl.pods.logs(pod.id):
    print(chunk)

carl.pods.delete(pod.id)

# Bug reports
conv = carl.bugs.start("app crashes on login")
conv = carl.bugs.reply(conv.id, "it happens every time")
conv = carl.bugs.get(conv.id)  # fetch with full message history

# Pod config
config = carl.config.get()
carl.config.set(setup_script="npm install", env_vars={"DEBUG": "1"})
```

### Pod Configuration

Configure defaults applied to every new pod created for your tenant:

```python
carl.config.set(
    env_vars={"NODE_ENV": "staging"},
    claude_md="# Project rules\nAlways run tests before committing.",
    setup_script="cd /workspace/my-repo && npm install",
)
```

- **`env_vars`** — custom environment variables available in the pod and to Claude
- **`claude_md`** — instructions appended to CLAUDE.md; Claude reads these at session start
- **`setup_script`** — shell command(s) run after pod setup, before the Claude session. Workspace is at `/workspace`. Repos specified via SDK are cloned there. Has access to git credentials and installed tools. Non-fatal on failure.

### Async

```python
from carl_sdk import AsyncCarl

async with AsyncCarl(api_key="...", repo="org/repo") as carl:
    pod = await carl.pods.create("fix the login bug")
    response = await carl.pods.chat(pod.id, "What did you find?")
    print(response.response)

    async for event in carl.pods.activity(pod.id):
        print(event)

    await carl.pods.delete(pod.id)
```

## MCP Server

Configure in Claude Code's `settings.json`:

```json
{
  "mcpServers": {
    "carl": {
      "command": "carl-mcp",
      "env": {
        "CARL_API_KEY": "your-api-key",
        "CARL_REPO": "org/repo"
      }
    }
  }
}
```

Or run directly:

```bash
CARL_API_KEY=... CARL_REPO=... carl-mcp
```
