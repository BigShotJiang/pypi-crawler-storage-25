import httpx

from carl_sdk import Carl


def test_get_config(mock_api, carl):
    mock_api.get("/v1/pod-config").mock(return_value=httpx.Response(200, json={
        "setup_script": "python main.py",
        "env_vars": {"FOO": "bar"},
        "claude_md": "# Instructions",
    }))
    config = carl.config.get()
    assert config.setup_script == "python main.py"
    assert config.env_vars == {"FOO": "bar"}
    assert config.claude_md == "# Instructions"


def test_set_config(mock_api, carl):
    mock_api.put("/v1/pod-config").mock(return_value=httpx.Response(200, json={
        "setup_script": "node index.js",
    }))
    config = carl.config.set(setup_script="node index.js")
    assert config.setup_script == "node index.js"


def test_set_config_partial(mock_api, carl):
    mock_api.put("/v1/pod-config").mock(return_value=httpx.Response(200, json={
        "env_vars": {"KEY": "val"},
    }))
    config = carl.config.set(env_vars={"KEY": "val"})
    assert config.env_vars == {"KEY": "val"}
    request = mock_api.calls[0].request
    import json
    body = json.loads(request.content)
    assert "setup_script" not in body
