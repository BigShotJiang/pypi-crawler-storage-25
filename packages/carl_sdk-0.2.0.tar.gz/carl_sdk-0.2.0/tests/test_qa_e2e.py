"""E2E QA tests against the live Carl API.

These tests hit the real API and verify actual behavior.
"""

import pytest

pytestmark = pytest.mark.live

from carl_sdk import Carl, AsyncCarl, ChatResponse, Pod, BugConversation, PodConfig
from carl_sdk.errors import AuthError, NotFoundError

API_URL = "http://10.100.34.237:8080"
API_KEY = "carl_sk_e8b8d5196aecb82620d5e2b88f84cf3cff40b9e9b7bf737082dfd42f59f8fd9f"
REPO = "nam-szns/carl-sdk"
USER_ID = "100141784824449620964"


@pytest.fixture
def carl():
    with Carl(api_key=API_KEY, repo=REPO, base_url=API_URL) as c:
        yield c


@pytest.fixture
async def async_carl():
    async with AsyncCarl(api_key=API_KEY, repo=REPO, base_url=API_URL) as c:
        yield c


# Track created resources for cleanup
_created_pods: list[str] = []
_created_conversations: list[str] = []


@pytest.fixture(autouse=True)
def cleanup(carl):
    yield
    for pod_id in _created_pods:
        try:
            carl.pods.delete(pod_id)
        except Exception:
            pass
    _created_pods.clear()


# ============================================================
# Pods
# ============================================================


class TestPodsE2E:
    def test_list_pods(self, carl):
        pods = carl.pods.list()
        assert isinstance(pods, list)

    def test_create_and_get_pod(self, carl):
        pod = carl.pods.create("QA test task - Python SDK", user_id=USER_ID)
        _created_pods.append(pod.id)
        assert isinstance(pod, Pod)
        assert pod.id
        assert pod.name  # pod_name from API
        assert pod.status in ("creating", "running", "succeeded", "failed")

        # Verify GET returns same pod
        fetched = carl.pods.get(pod.id)
        assert fetched.id == pod.id
        assert fetched.status == pod.status

    def test_create_and_delete_pod(self, carl):
        pod = carl.pods.create("QA test delete - Python SDK", user_id=USER_ID)
        carl.pods.delete(pod.id)
        # After deletion, get should 404
        with pytest.raises(NotFoundError):
            carl.pods.get(pod.id)

    def test_get_nonexistent_pod(self, carl):
        with pytest.raises(NotFoundError):
            carl.pods.get("nonexistent-pod-id-12345")

    def test_delete_nonexistent_pod(self, carl):
        with pytest.raises(NotFoundError):
            carl.pods.delete("nonexistent-pod-id-12345")

    def test_create_pod_with_task_and_chat(self, carl):
        """Create a pod with a task, wait for readiness, then send a follow-up message."""
        import time
        pod = carl.pods.create("echo 'hello from chat test'", user_id=USER_ID)
        _created_pods.append(pod.id)
        assert pod.id

        # Wait for pod to be ready (task is auto-sent as first message)
        time.sleep(60)

        resp = carl.pods.chat(pod.id, "What did the previous task output?")
        assert isinstance(resp, ChatResponse)
        assert resp.response
        assert resp.cost_usd is not None

    def test_chat_pod_not_found(self, carl):
        with pytest.raises(NotFoundError):
            carl.pods.chat("nonexistent-pod-id-12345", "hello")

    def test_activity_stream(self, carl):
        """Subscribe to activity SSE during task processing."""
        pod = carl.pods.create("echo 'activity test'", user_id=USER_ID)
        _created_pods.append(pod.id)

        import time
        time.sleep(30)

        events = []
        for event in carl.pods.activity(pod.id):
            events.append(event)
            if len(events) >= 1:
                break
        assert len(events) >= 1


# ============================================================
# Bugs
# ============================================================


class TestBugsE2E:
    def test_start_bug_conversation(self, carl):
        conv = carl.bugs.start("QA test: login page crash", user_id=USER_ID)
        _created_conversations.append(conv.id)
        assert isinstance(conv, BugConversation)
        assert conv.id
        assert conv.state in ("active", "complete")
        assert conv.response

    def test_get_nonexistent_conversation(self, carl):
        with pytest.raises(NotFoundError):
            carl.bugs.get("nonexistent-conv-id-12345")


# ============================================================
# Config
# ============================================================


class TestConfigE2E:
    def test_get_default_config(self, carl):
        config = carl.config.get()
        assert isinstance(config, PodConfig)
        assert config.env_vars is None or isinstance(config.env_vars, dict)

    def test_set_and_get_config(self, carl):
        config = carl.config.set(
            setup_script="echo qa-test",
            env_vars={"QA_TEST": "1"},
            claude_md="# QA test instructions",
        )
        assert isinstance(config, PodConfig)
        assert config.setup_script == "echo qa-test"
        assert config.env_vars["QA_TEST"] == "1"
        assert config.claude_md == "# QA test instructions"

        fetched = carl.config.get()
        assert fetched.setup_script == "echo qa-test"
        assert fetched.env_vars["QA_TEST"] == "1"
        assert fetched.claude_md == "# QA test instructions"

    def test_partial_update_preserves_fields(self, carl):
        carl.config.set(setup_script="echo base", env_vars={"A": "1"})
        carl.config.set(claude_md="# Updated")
        config = carl.config.get()
        assert config.setup_script == "echo base"
        assert config.claude_md == "# Updated"


# ============================================================
# Auth
# ============================================================


class TestAuthE2E:
    def test_invalid_key_rejected(self):
        carl = Carl(
            api_key="carl_sk_0000000000000000000000000000000000000000000000000000000000000000",
            repo=REPO,
            base_url=API_URL,
        )
        with pytest.raises(AuthError):
            carl.pods.list()

    def test_wrong_repo_still_lists_pods(self):
        """Repo header is not validated on list — only on create.
        The API returns pods regardless of X-Carl-Repo value."""
        carl = Carl(api_key=API_KEY, repo="some/other-repo", base_url=API_URL)
        pods = carl.pods.list()
        assert isinstance(pods, list)


# ============================================================
# Async Client
# ============================================================


class TestAsyncE2E:
    @pytest.mark.asyncio
    async def test_async_list_pods(self, async_carl):
        pods = await async_carl.pods.list()
        assert isinstance(pods, list)

    @pytest.mark.asyncio
    async def test_async_bug_start(self, async_carl):
        conv = await async_carl.bugs.start("QA async test", user_id=USER_ID)
        assert isinstance(conv, BugConversation)
        assert conv.id
        assert conv.response

    @pytest.mark.asyncio
    async def test_async_config_get(self, async_carl):
        config = await async_carl.config.get()
        assert isinstance(config, PodConfig)
