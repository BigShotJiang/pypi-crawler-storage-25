import httpx
import respx

from carl_sdk import Carl


def test_start_bug(mock_api, carl):
    mock_api.post("/v1/bugs/conversations").mock(return_value=httpx.Response(200, json={
        "id": "conv-1",
        "state": "active",
        "response": "Tell me more",
        "messages": [
            {"role": "user", "content": "app crashes"},
            {"role": "assistant", "content": "Tell me more"},
        ],
    }))
    conv = carl.bugs.start("app crashes")
    assert conv.id == "conv-1"
    assert conv.state == "active"
    assert len(conv.messages) == 2


def test_start_bug_with_user_id(mock_api, carl):
    mock_api.post("/v1/bugs/conversations").mock(return_value=httpx.Response(200, json={
        "id": "conv-2",
        "state": "active",
        "response": "ok",
    }))
    conv = carl.bugs.start("crash", user_id="user-42")
    assert conv.id == "conv-2"
    request = mock_api.calls[0].request
    assert b'"userId": "user-42"' in request.content or b'"userId":"user-42"' in request.content


def test_reply(mock_api, carl):
    mock_api.post("/v1/bugs/conversations/conv-1/messages").mock(return_value=httpx.Response(200, json={
        "id": "conv-1",
        "state": "complete",
        "response": "Got it",
        "result": {
            "title": "App crash on login",
            "description": "Crashes when clicking login",
            "priority": "high",
            "repo_url": "https://github.com/test/repo",
        },
    }))
    conv = carl.bugs.reply("conv-1", "it happens on login")
    assert conv.state == "complete"
    assert conv.result is not None
    assert conv.result.title == "App crash on login"


def test_get(mock_api, carl):
    mock_api.get("/v1/bugs/conversations/conv-1").mock(return_value=httpx.Response(200, json={
        "id": "conv-1",
        "state": "active",
        "response": "hi",
    }))
    conv = carl.bugs.get("conv-1")
    assert conv.id == "conv-1"
