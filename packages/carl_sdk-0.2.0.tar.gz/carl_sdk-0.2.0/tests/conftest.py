import pytest
import respx

from carl_sdk import Carl


@pytest.fixture
def mock_api():
    with respx.mock(base_url="https://api.carl.szns.dev") as router:
        yield router


@pytest.fixture
def carl():
    return Carl(api_key="test-key", repo="test/repo")
