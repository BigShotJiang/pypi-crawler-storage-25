import pytest

from carl_sdk import Carl, AsyncCarl
from carl_sdk.bugs import BugClient
from carl_sdk.pods import PodClient
from carl_sdk.config import ConfigClient


def test_requires_api_key():
    with pytest.raises(ValueError, match="api_key"):
        Carl(api_key="", repo="test/repo")


def test_requires_repo():
    with pytest.raises(ValueError, match="repo"):
        Carl(api_key="test-key", repo="")


def test_sub_clients_wired():
    c = Carl(api_key="test-key", repo="test/repo")
    assert isinstance(c.bugs, BugClient)
    assert isinstance(c.pods, PodClient)
    assert isinstance(c.config, ConfigClient)


def test_context_manager():
    with Carl(api_key="test-key", repo="test/repo") as c:
        assert c is not None


def test_async_requires_api_key():
    with pytest.raises(ValueError, match="api_key"):
        AsyncCarl(api_key="", repo="test/repo")
