import httpx

from carl_sdk import Carl


def test_create_pod(mock_api, carl):
    mock_api.post("/v1/pods").mock(return_value=httpx.Response(200, json={
        "id": "pod-1",
        "name": "task-pod",
        "status": "creating",
        "task": "fix the bug",
        "repo": "test/repo",
        "createdAt": "2026-03-15T00:00:00Z",
    }))
    pod = carl.pods.create("fix the bug")
    assert pod.id == "pod-1"
    assert pod.status == "creating"


def test_list_pods(mock_api, carl):
    mock_api.get("/v1/pods").mock(return_value=httpx.Response(200, json=[
        {
            "id": "pod-1",
            "name": "p1",
            "status": "running",
            "task": "t1",
            "repo": "test/repo",
            "createdAt": "2026-03-15T00:00:00Z",
        },
        {
            "id": "pod-2",
            "name": "p2",
            "status": "succeeded",
            "task": "t2",
            "repo": "test/repo",
            "createdAt": "2026-03-15T01:00:00Z",
        },
    ]))
    pods = carl.pods.list()
    assert len(pods) == 2
    assert pods[1].status == "succeeded"


def test_get_pod(mock_api, carl):
    mock_api.get("/v1/pods/pod-1").mock(return_value=httpx.Response(200, json={
        "id": "pod-1",
        "name": "p1",
        "status": "running",
        "task": "t1",
        "repo": "test/repo",
        "createdAt": "2026-03-15T00:00:00Z",
    }))
    pod = carl.pods.get("pod-1")
    assert pod.name == "p1"


def test_delete_pod(mock_api, carl):
    mock_api.delete("/v1/pods/pod-1").mock(return_value=httpx.Response(204))
    carl.pods.delete("pod-1")


def test_logs(mock_api, carl):
    sse = "data: log line 1\ndata: log line 2\ndata: [DONE]\n"
    mock_api.get("/v1/pods/pod-1/logs").mock(return_value=httpx.Response(200, text=sse))
    lines = list(carl.pods.logs("pod-1"))
    assert lines == ["log line 1", "log line 2"]


def test_chat(mock_api, carl):
    mock_api.post("/v1/pods/pod-1/messages").mock(return_value=httpx.Response(200, json={
        "response": "There are 5 files in the root.",
        "status": "ok",
        "cost_usd": 0.03,
        "duration_ms": 4500,
        "num_turns": 2,
    }))
    resp = carl.pods.chat("pod-1", "What files are in the repo?")
    assert resp.response == "There are 5 files in the root."
    assert resp.status == "ok"
    assert resp.cost_usd == 0.03
    assert resp.num_turns == 2


def test_activity(mock_api, carl):
    sse = 'data: {"type": "text", "text": "hello"}\ndata: {"type": "result"}\ndata: [DONE]\n'
    mock_api.get("/v1/pods/pod-1/activity").mock(return_value=httpx.Response(200, text=sse))
    events = list(carl.pods.activity("pod-1"))
    assert len(events) == 2
    assert '"text"' in events[0]
