import httpx
import pytest
import respx

from carl_sdk.errors import AuthError, CarlError, NotFoundError, RateLimitError, ValidationError
from carl_sdk.http import HttpClient


@pytest.fixture
def http():
    return HttpClient("test-key", "test/repo", "https://api.carl.szns.dev")


@pytest.fixture
def mock_api():
    with respx.mock(base_url="https://api.carl.szns.dev") as router:
        yield router


def test_401_raises_auth_error(http, mock_api):
    mock_api.get("/test").mock(return_value=httpx.Response(401, json={"message": "bad token"}))
    with pytest.raises(AuthError, match="bad token"):
        http.get("/test")


def test_403_raises_auth_error(http, mock_api):
    mock_api.get("/test").mock(return_value=httpx.Response(403, json={"message": "forbidden"}))
    with pytest.raises(AuthError, match="forbidden"):
        http.get("/test")


def test_404_raises_not_found(http, mock_api):
    mock_api.get("/test").mock(return_value=httpx.Response(404, json={"message": "gone"}))
    with pytest.raises(NotFoundError, match="gone"):
        http.get("/test")


def test_422_raises_validation_error(http, mock_api):
    mock_api.post("/test").mock(return_value=httpx.Response(422, json={"message": "invalid"}))
    with pytest.raises(ValidationError, match="invalid"):
        http.post("/test", {"x": 1})


def test_429_raises_rate_limit(http, mock_api):
    mock_api.get("/test").mock(return_value=httpx.Response(429, json={"message": "slow down"}))
    with pytest.raises(RateLimitError, match="slow down"):
        http.get("/test")


def test_500_raises_carl_error(http, mock_api):
    mock_api.get("/test").mock(return_value=httpx.Response(500, json={"error": "boom"}))
    with pytest.raises(CarlError, match="boom") as exc_info:
        http.get("/test")
    assert exc_info.value.status == 500


def test_sse_parsing(http, mock_api):
    sse_body = "data: line1\ndata: line2\ndata: [DONE]\ndata: ignored\n"
    mock_api.get("/stream").mock(return_value=httpx.Response(200, text=sse_body))
    lines = list(http.stream("/stream"))
    assert lines == ["line1", "line2"]
