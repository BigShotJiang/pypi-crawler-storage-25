# AI-Engine - AngelMC

**AI Engine** — это библиотека для создания игровых ИИ-агентов на Python. Она позволяет не просто общаться с нейросетью, а строить персонажей с симуляцией жизни: здоровьем, голодом, действиями и реакцией на события. Библиотека работает поверх [Ollama](https://ollama.com) и использует любые языковые модели.

Установка:
```bash
pip install ai-engine-angelmc
```

---

## 📁 Структура библиотеки

Библиотека состоит из трёх модулей:

| Модуль | Файл | Назначение |
|--------|------|------------|
| **Core** | `core.py` | Базовые классы `AI` и `GameAgent` — мозг и тело персонажа. |
| **Simulation** | `simulation.py` | Состояния (`State`), действия (`Action`), менеджер (`ManagerSA`). |
| **Utils** | `utils.py` | Вспомогательные классы: цвета, таймер, ввод, проверки. |

---

## 🧠 Core (ядро)

### Класс `AI`

Базовый класс для общения с моделью Ollama. Хранит историю диалога, отправляет запросы и получает ответы. Может использоваться самостоятельно для простых чат-ботов.

#### Основные методы
```python
bot = AI('Бот', model='qwen2.5:3b')
answer = bot.Chat('Привет!')          # Отправить сообщение и получить ответ
print(bot.Format(answer))             # Цветной вывод в консоль
bot.SetSystemPrompt('Ты — мудрец.')   # Сменить системный промпт
bot.ClearHistory()                    # Очистить историю (оставив промпт)
bot.SaveHistory('saves/chat.json')    # Сохранить историю в файл
bot.LoadHistory('saves/chat.json')    # Загрузить историю из файла
```

#### Простой чат-бот
```python
from AIEngine.core import AI
bot = AI('МойБот', model='qwen2.5:3b')
while True:
    user = input('Вы: ')
    if user == 'exit': break
    print(bot.Format(bot.Chat(user)))
```

---

### Класс `GameAgent`

Наследует `AI` и добавляет **систему состояний, действий и колбэков**. Это основа для создания персонажей с симуляцией жизни.

#### Отличие от `AI`
`GameAgent` не просто общается — он «живёт»: его сытость падает со временем, он может заболеть, умереть, выполнить действие. Всё это управляется встроенным менеджером (`ManagerSA`).

#### Основные методы
```python
agent = GameAgent('TSAI', model='qwen2.5:3b', isDebug=True)

# Состояния
hp = agent.CreateState('Health', 100)              # Создать состояние «здоровье»
hunger = agent.CreateState('Hunger', 100, time=5)  # Сытость, обновляется каждые 5 сек

# Действия
eat = agent.CreateAction('Eat', 'ActEat', 'поел: +value', 20, {hunger.name: hunger}, time=0)

# Колбэки
cb = agent.BuildCallbacks(on_min=(0, None))
agent.BindCallbacks({hp: {'OnMin': agent.LambdaCallback(
    message='умер', modes=['Message-sim', 'Message-to']
)}})

# Игровой цикл
while True:
    user = input('Вы: ')
    if user == 'exit': break
    answer = agent.Chat(user)
    agent.Update(answer)                     # Обновить состояния и проверить колбэки
    print(agent.Format(answer))
```

#### Особенности `GameAgent`
- **Автоматические обновления.** Состояния с заданным интервалом (`time`) меняются сами (например, сытость падает каждые 5 секунд).
- **Колбэки.** Функции срабатывают при достижении порогов (`OnMin`, `OnBelow` и т.д.).
- **Действия.** Команды вроде `Eat` в ответах модели автоматически выполняются и меняют состояния.
- **Отладка.** Флаг `isDebug=True` включает вывод в консоль всех срабатываний колбэков и действий.

#### Фабрики `LambdaCallback` и `LambdaAction`
Упрощают создание функций для колбэков и действий. Позволяют описать изменения и сообщения в одну строку.

```python
# Колбэк: при голоде отнимает здоровье и уведомляет
hunger_cb = agent.LambdaCallback(
    changes=[{'target': 'Health', 'delta': -5}],
    message='Голодаю! HP: {Health}',
    modes=['Message-to']
)

# Действие: поесть +20 сытости
eat.Function = agent.LambdaAction(
    changes=[{'target': 'Hunger', 'delta': 20}],
    message='Съел: +{value} к сытости',
    modes=['Message-to']
)
```

Плейсхолдеры в сообщениях:
- `{delta}` — суммарное изменение
- `{состояние}` — текущее значение любого состояния (например, `{Health}`)
- `{self_value}` — значение текущего состояния (для колбэков)
- `{value}` — сила действия (для действий, подставляется через `GetReplaceValue()`)

---

## 🧪 Simulation (симуляция)

Модуль отвечает за механику жизни персонажа: состояния, действия и их связь. Состоит из трёх классов.

### `State` (состояние)

Числовая характеристика персонажа: здоровье, сытость, мана и т.д. Может автоматически изменяться со временем и вызывать колбэки при достижении порогов.

```python
from AIEngine.simulation import State, Timer

hp = State(belongs=agent, name='Health', value=100, max_value=100)

# Автообновление: функция будет вызываться каждые 5 сек
hunger = State(agent, 'Hunger', 100, time=5)
hunger.Function = hunger.CreateFunction(
    changes=[{'target': 'self', 'delta': -1}]
)
```

**Основные методы:**
- `Set(value, clamped=True)` — установить новое значение (с ограничением по `max_value`).
- `ShowValue()` — вернуть текущее значение.
- `GetReplacementValue(message)` — заменить `'value'` в строке на `self.value`.
- `CreateFunction(changes, texts)` — фабрика для `State.Function` (см. ниже).

**Колбэки** (вызываются автоматически менеджером):
- `OnMin()` — значение достигло 0.
- `OnMax()` — значение достигло максимума.
- `OnBelow()` — значение стало ниже порога.
- `OnAbove()` — значение стало выше порога.
- `OnChange()` — значение изменилось (после проверки всех порогов).

Колбэки настраиваются через `GameAgent.BuildCallbacks` и `BindCallbacks`, или вручную.
У каждого колбэка есть свой таймер проверки.

#### `CreateFunction(changes, texts)` — фабрика для автообновлений

Создаёт функцию, которую можно присвоить `state.Function`. Позволяет менять значения и выводить/возвращать сообщения без написания `def`.

**Параметры:**
- `changes` — список действий со значениями. Каждый элемент:
  - `'target'`: `'self'` или ключ из `self.states`.
  - `'delta'`: на сколько изменить.
  - `'mode'` (опционально): `'return'` — вернуть результат `(текущее, цель, дельта)`.
- `texts` — список сообщений. Каждый элемент:
  - `'text'`: строка с плейсхолдерами (`{delta}`, `{Health}`, `{self_value}`).
  - `'mode'`: `'print'`, `'return'` или `'debug'` (только при `isDebug=True`).

**Примеры:**

```python
# Просто уменьшать сытость каждые 5 сек
hunger.Function = hunger.CreateFunction(
    changes=[{'target': 'self', 'delta': -1}]
)

# Уменьшать и возвращать новое значение
hunger.Function = hunger.CreateFunction(
    changes=[{'target': 'self', 'delta': -1, 'mode': 'return'}]
)  # вернёт (текущее, цель, дельта)

# Уменьшать сытость, печатать и возвращать сообщение
hunger.Function = hunger.CreateFunction(
    changes=[{'target': 'self', 'delta': -1}],
    texts=[
        {'text': 'Голод уменьшился до {self_value}', 'mode': 'print'},
        {'text': 'Сытость упала', 'mode': 'return'}
    ]
)

# Изменить связанное состояние и вывести дебаг-сообщение
poison.Function = poison.CreateFunction(
    changes=[{'target': 'Health', 'delta': -5}],
    texts=[{'text': 'Poison: HP → {Health}', 'mode': 'debug'}]
)
```

---

### `Action` (действие)

Команда, которую персонаж может выполнить сам или по просьбе игрока. При выполнении меняет одно или несколько состояний.

```python
from AIEngine.simulation import Action

eat = Action(
    name='Eat',
    id='ActEat',                    # команда в тексте: \ActEat\
    message='поел: +value сытости', # {value} заменится на self.value
    value=20,
    states={'Hunger': hunger},      # целевое состояние
    time=0                          # кулдаун (0 — без кулдауна)
)
```

**Основные методы:**
- `GetReplacementValue()` — вернуть сообщение с подставленным значением.
- `Execute()` — принудительно выполнить действие (если позволяет таймер).

---

### `ManagerSA` (менеджер)

Связывает всё воедино. Каждый `GameAgent` создаёт своего менеджера автоматически. Менеджер обновляет состояния, проверяет колбэки, ищет команды в ответах модели и выполняет действия.

Обычно пользователь не создаёт менеджер вручную — он уже встроен в `GameAgent`.

**Что делает менеджер каждый игровой цикл (`Update`):**
1. Для каждого состояния с таймером: вызывает `Function` (например, уменьшает сытость).
2. Проверяет колбэки (`OnMin`, `OnBelow` и т.д.) и при срабатывании отправляет сообщения агенту или всем.
3. Ищет в ответе модели команды действий (`\ActEat\`, `\ShowStates\`) и выполняет их.
4. Обрезает все значения состояний по `0..max_value`.

**Режимы отправки сообщений (modes):**
- `'Message-to'`  — отправить сообщение только агенту-владельцу.
- `'Message-sim'` – отправить всем агентам, кроме отправителя.
- `'Message-all'` – отправить всем, включая отправителя.

---

## 📊 Полный пример: персонаж с голодом и здоровьем

```python
from AIEngine.core import GameAgent
from AIEngine.utils import IM, Color

# 1. Создаём агента
tsai = GameAgent('TSAI', model='qwen2.5:3b', isDebug=True)

# 2. Колбэки (пороги)
cb = tsai.BuildCallbacks(
    on_min=(0, None),          # OnMin без таймера
    on_below=(30, 3)           # OnBelow: порог 30, проверка раз в 3 сек
)

# 3. Состояния
hp = tsai.CreateState('Health', 100, callbacks=cb)
hunger = tsai.CreateState('Hunger', 100, time=5)

# 4. Действие
eat = tsai.CreateAction('Eat', 'ActEat', 'поел: +value сытости', 20, {hunger.name: hunger}, 0)

# 5. Привязываем функции к колбэкам
tsai.BindCallbacks({
    hp: {
        'OnMin': tsai.LambdaCallback(
            message='умер', modes=['Message-sim', 'Message-to']
        )
    },
    hunger: {
        'OnBelow': tsai.LambdaCallback(
            changes=[{'target': 'Health', 'delta': -5}],
            message='Голод! HP: {Health}', modes=['Message-to']
        )
    }
})

# 6. Функция автообновления сытости (каждые 5 сек -1)
hunger.Function = hunger.CreateFunction(
    changes=[{'target': 'self', 'delta': -1}]
)

# 7. Функция действия
eat.Function = tsai.LambdaAction(
    changes=[{'target': 'Hunger', 'delta': eat.value}],
    message='поел: +{value} сытости', modes=['Message-to']
)

# 8. Игровой цикл
im = IM('Вы: ', Color.MAGENTA)
while True:
    user = im.Read()
    if im.IsExit(user): break
    answer = tsai.Chat(user)
    tsai.Update(answer)
    print(tsai.Format(answer))
```

## 🛠️ Utils (инструменты)

Вспомогательные классы, которые используются внутри `core` и `simulation`, но могут пригодиться и напрямую.

### `Color`
Константы ANSI-цветов для консольного вывода. Используются в `AI.Format` и `IM`.
```python
from AIEngine.utils import Color
print(Color.RED + "Красный текст" + Color.RESET)
Color.List()  # выведет все доступные цвета
```

### `Guard`
Внутренний класс для проверки типов. Выбрасывает понятные ошибки, если пользователь передал неверные аргументы. Обычно используется внутри библиотеки, но можно вызывать и в своём коде:
```python
from AIEngine.utils import Guard
guard = Guard('MyClass')
guard.check_type(x, int, 'x', 'my_method')  # вызовет TypeError, если x не int
guard.check_in(y, ['a', 'b'], 'y', 'my_method')  # вызовет ValueError, если y не в списке
```

### `Timer`
Таймер для периодических событий. Используется в `State`, `Action` и колбэках.
```python
from AIEngine.utils import Timer
timer = Timer('MyTimer', 5.0)   # интервал 5 секунд
if timer.Check():               # True, когда прошло 5 сек
    print('Тик!')
timer.Force()     # принудительно вернуть True и сбросить
timer.Reset()     # сбросить отсчёт
timer.Remaining() # сколько секунд осталось до следующего True
```

### `IM`
Интерфейс ввода с цветным приглашением и поддержкой команд выхода.
```python
from AIEngine.utils import IM, Color
im = IM('Игрок: ', Color.MAGENTA)
user_input = im.Read()              # вывод приглашения и чтение
if im.IsExit(user_input):           # True, если введён символ выхода
    break
im.SetPrompt('Новый текст: ')       # сменить приглашение
im.AddExitSymbol('quit')            # добавить слово для выхода
```

По умолчанию символ выхода — `'\e'` (Escape). Добавляйте свои команды через `AddExitSymbol`.

### `Logging`
Заглушка для логирования (будет реализована в следующих версиях).
```