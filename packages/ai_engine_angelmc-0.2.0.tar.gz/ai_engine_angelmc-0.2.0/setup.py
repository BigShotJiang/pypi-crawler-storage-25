from setuptools import setup, find_packages

setup(
    name="ai-engine-angelmc",
    version="0.2.0",
    description="Библиотека для создания игровых ИИ-агентов (AngelMC Engine)",
    packages=find_packages(),
    install_requires=["ollama"],
    python_requires=">=3.10",
)