"""outworx CLI — entry point.

Currently the only command is ``forward``. We dispatch on argv[1] so adding
future commands (e.g. ``outworx events tail``) doesn't change the entry
point registered in pyproject.toml.
"""
from __future__ import annotations

import sys

from .forward import run_forward

HELP = """outworx — Outworx Hooks CLI

USAGE
  outworx forward <local-url> [--api-key=<key>] [--endpoint=<url>]
  outworx --help

COMMANDS
  forward    Open a tunnel from a public URL to your local server.

ENV
  OUTWORX_API_KEY   Project API key. Required unless --api-key is given.
  OUTWORX_ENDPOINT  Override the Outworx server (default: https://hooks.outworx.io).
"""


def main() -> None:
    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help"):
        print(HELP)
        sys.exit(0 if argv else 1)

    cmd = argv[0]
    if cmd == "forward":
        run_forward(argv[1:])
        return

    print(f'outworx: unknown command "{cmd}"\n', file=sys.stderr)
    print(HELP, file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
