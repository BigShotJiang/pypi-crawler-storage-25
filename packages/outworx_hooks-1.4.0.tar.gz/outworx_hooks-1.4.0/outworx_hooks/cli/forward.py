"""``outworx forward <local-url>`` — open a tunnel and replay inbound
requests to the local URL.

Mirrors the JS CLI: creates a session against the Outworx API, prints the
public URL, then long-polls for inbound events and replays each one to the
user's local server. The local response is shipped back to Outworx, which
relays it to the original caller.
"""
from __future__ import annotations

import os
import re
import signal
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

import httpx

POLL_RETRY_S = 1.5
POLL_TIMEOUT_S = 30.0


@dataclass
class Args:
    local_url: str
    api_key: str
    endpoint: str


# ANSI helpers — gated so non-TTY output stays clean (CI logs, tee, etc.).
_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def _c(code: str, s: str) -> str:
    return f"\x1b[{code}m{s}\x1b[0m" if _COLOR else s


def _dim(s: str) -> str:
    return _c("2", s)


def _bold(s: str) -> str:
    return _c("1", s)


def _green(s: str) -> str:
    return _c("32", s)


def _red(s: str) -> str:
    return _c("31", s)


def _yellow(s: str) -> str:
    return _c("33", s)


def _cyan(s: str) -> str:
    return _c("36", s)


def _status_color(status: int) -> "callable[[str], str]":
    if status >= 500:
        return _red
    if status >= 400:
        return _yellow
    if status >= 300:
        return _cyan
    return _green


def _parse_args(argv: List[str]) -> Args:
    local_url: Optional[str] = None
    api_key = os.environ.get("OUTWORX_API_KEY", "")
    endpoint = os.environ.get(
        "OUTWORX_ENDPOINT", "https://hooks.outworx.io"
    ).rstrip("/")

    for arg in argv:
        if arg.startswith("--api-key="):
            api_key = arg[len("--api-key="):]
        elif arg.startswith("--endpoint="):
            endpoint = arg[len("--endpoint="):].rstrip("/")
        elif arg.startswith("--"):
            raise SystemExit(f"outworx forward: unknown flag: {arg}")
        elif local_url is None:
            local_url = arg
        else:
            raise SystemExit(
                f"outworx forward: unexpected positional argument: {arg}"
            )

    if not local_url:
        raise SystemExit(
            "outworx forward: missing local URL.\n"
            "  usage: outworx forward <local-url> [--api-key=<key>]"
        )
    if not api_key:
        raise SystemExit(
            "outworx forward: missing API key. "
            "Set OUTWORX_API_KEY or pass --api-key=<key>."
        )

    # Normalize: accept "localhost:3000" and "3000" as shorthand.
    if re.fullmatch(r"\d+", local_url):
        local_url = f"http://localhost:{local_url}"
    elif not re.match(r"^https?://", local_url):
        local_url = f"http://{local_url}"
    local_url = local_url.rstrip("/")

    return Args(local_url=local_url, api_key=api_key, endpoint=endpoint)


def _create_session(client: httpx.Client, args: Args) -> Dict[str, Any]:
    res = client.post(
        f"{args.endpoint}/api/forward/sessions",
        json={"destination_url": args.local_url},
        headers={"Authorization": f"Bearer {args.api_key}"},
    )
    if res.status_code >= 400:
        raise SystemExit(
            f"outworx forward: failed to create tunnel session "
            f"({res.status_code}): {res.text}"
        )
    return res.json()


def _close_session(client: httpx.Client, args: Args, session_id: str) -> None:
    try:
        client.delete(
            f"{args.endpoint}/api/forward/sessions/{session_id}",
            headers={"Authorization": f"Bearer {args.api_key}"},
            timeout=5.0,
        )
    except Exception:
        # Best-effort cleanup. The server expires sessions on its own.
        pass


def _poll_once(
    client: httpx.Client, args: Args, session_id: str
) -> List[Dict[str, Any]]:
    res = client.get(
        f"{args.endpoint}/api/forward/poll",
        params={"session": session_id},
        headers={"Authorization": f"Bearer {args.api_key}"},
        timeout=POLL_TIMEOUT_S,
    )
    if res.status_code >= 400:
        raise RuntimeError(
            f"poll failed ({res.status_code}): {res.text or res.reason_phrase}"
        )
    return res.json().get("events", [])


def _deliver_to_local(
    client: httpx.Client, args: Args, event: Dict[str, Any]
) -> Dict[str, Any]:
    path = event.get("path") or "/"
    qs = event.get("query_string")
    target = f"{args.local_url}{path}"
    if qs:
        target = f"{target}?{qs}"

    # Strip headers httpx will set itself — sending them through verbatim
    # makes the request fail or hang.
    fwd: Dict[str, str] = {}
    for key, value in (event.get("request_headers") or {}).items():
        if key.lower() in ("host", "content-length"):
            continue
        fwd[key] = value

    method = event.get("method", "POST")
    body = (
        None
        if method in ("GET", "HEAD")
        else event.get("request_body")
    )

    start = time.time()
    res = client.request(
        method=method,
        url=target,
        headers=fwd,
        content=body,
        follow_redirects=False,
        timeout=20.0,
    )
    duration_ms = int((time.time() - start) * 1000)

    return {
        "status": res.status_code,
        "headers": dict(res.headers),
        "body": res.text,
        "durationMs": duration_ms,
    }


def _report_response(
    client: httpx.Client,
    args: Args,
    event_id: str,
    result: Dict[str, Any],
) -> None:
    res = client.post(
        f"{args.endpoint}/api/forward/responses",
        json={"eventId": event_id, **result},
        headers={"Authorization": f"Bearer {args.api_key}"},
        timeout=10.0,
    )
    if res.status_code >= 400:
        raise RuntimeError(
            f"failed to report response ({res.status_code}): {res.text}"
        )


def _handle_event(
    client: httpx.Client, args: Args, event: Dict[str, Any]
) -> None:
    label = f"{event.get('method', '?')} {event.get('path') or '/'}"
    timestamp = datetime.now().strftime("%H:%M:%S")
    try:
        result = _deliver_to_local(client, args, event)
        color = _status_color(result["status"])
        duration = _dim(f"{result['durationMs']}ms")
        print(
            f"{_dim(timestamp)}  {_bold(label)}  "
            f"{color(str(result['status']))}  {duration}",
            flush=True,
        )
        _report_response(client, args, event["id"], result)
    except Exception as err:  # noqa: BLE001 — show any failure clearly
        msg = str(err)
        print(
            f"{_dim(timestamp)}  {_bold(label)}  {_red('ERR')}  {_dim(msg)}",
            flush=True,
        )
        # Fail fast on the held public request so the caller doesn't
        # wait the full hold window.
        try:
            _report_response(
                client,
                args,
                event["id"],
                {
                    "status": 502,
                    "headers": {"content-type": "text/plain"},
                    "body": f"outworx forward: local handler unreachable ({msg})",
                    "durationMs": 0,
                },
            )
        except Exception:
            pass


def run_forward(argv: List[str]) -> None:
    args = _parse_args(argv)

    stop = threading.Event()

    def _shutdown(_signum: int, _frame: object) -> None:
        stop.set()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    with httpx.Client() as client:
        session = _create_session(client, args)

        print()
        print(
            f"  {_bold('outworx forward')}  {_dim('→')}  {args.local_url}"
        )
        print(
            f"  {_dim('Public URL:')}  "
            f"{_cyan(_bold(session['ingressUrl']))}"
        )
        print(f"  {_dim('Expires:')}    {session['expiresAt']}")
        print(f"  {_dim('Press Ctrl+C to stop.')}")
        print()

        executor = ThreadPoolExecutor(max_workers=8)
        try:
            while not stop.is_set():
                try:
                    events = _poll_once(client, args, session["sessionId"])
                except Exception as err:  # noqa: BLE001
                    if stop.is_set():
                        break
                    print(
                        _red(f"  poll error: {err}"),
                        file=sys.stderr,
                        flush=True,
                    )
                    stop.wait(POLL_RETRY_S)
                    continue

                # Concurrent local POSTs — slow handlers don't serialize.
                for evt in events:
                    executor.submit(_handle_event, client, args, evt)
        finally:
            executor.shutdown(wait=False, cancel_futures=True)
            print(_dim("\n  Closing tunnel…"))
            _close_session(client, args, session["sessionId"])
