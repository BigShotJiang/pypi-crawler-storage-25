"""Tests for ``outworx forward`` argument parsing.

We don't exercise the network paths here — those need a live server.
The arg-parse layer is the bit that's most likely to silently regress
when someone reorders flags or refactors `_parse_args`.
"""
from __future__ import annotations

import os
import unittest

from outworx_hooks.cli.forward import _parse_args


class TestForwardArgs(unittest.TestCase):
    def setUp(self) -> None:
        # Each test starts from a clean env so OUTWORX_API_KEY in the
        # developer's shell can't mask a missing-key bug.
        self._saved_env: dict[str, str | None] = {
            "OUTWORX_API_KEY": os.environ.pop("OUTWORX_API_KEY", None),
            "OUTWORX_ENDPOINT": os.environ.pop("OUTWORX_ENDPOINT", None),
        }

    def tearDown(self) -> None:
        for key, value in self._saved_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    def test_local_url_full(self) -> None:
        args = _parse_args(["http://localhost:3000", "--api-key=k1"])
        self.assertEqual(args.local_url, "http://localhost:3000")
        self.assertEqual(args.api_key, "k1")

    def test_local_url_port_only_shorthand(self) -> None:
        args = _parse_args(["3000", "--api-key=k1"])
        self.assertEqual(args.local_url, "http://localhost:3000")

    def test_local_url_host_port_shorthand(self) -> None:
        args = _parse_args(["localhost:8080", "--api-key=k1"])
        self.assertEqual(args.local_url, "http://localhost:8080")

    def test_local_url_strips_trailing_slash(self) -> None:
        args = _parse_args(["http://example.com/", "--api-key=k1"])
        self.assertEqual(args.local_url, "http://example.com")

    def test_api_key_from_env(self) -> None:
        os.environ["OUTWORX_API_KEY"] = "env-key"
        args = _parse_args(["3000"])
        self.assertEqual(args.api_key, "env-key")

    def test_api_key_flag_overrides_env(self) -> None:
        os.environ["OUTWORX_API_KEY"] = "env-key"
        args = _parse_args(["3000", "--api-key=flag-key"])
        self.assertEqual(args.api_key, "flag-key")

    def test_endpoint_default(self) -> None:
        args = _parse_args(["3000", "--api-key=k1"])
        self.assertEqual(args.endpoint, "https://hooks.outworx.io")

    def test_endpoint_strips_trailing_slash(self) -> None:
        args = _parse_args(
            ["3000", "--api-key=k1", "--endpoint=http://staging.example.com/"]
        )
        self.assertEqual(args.endpoint, "http://staging.example.com")

    def test_missing_local_url_exits(self) -> None:
        with self.assertRaises(SystemExit):
            _parse_args(["--api-key=k1"])

    def test_missing_api_key_exits(self) -> None:
        with self.assertRaises(SystemExit):
            _parse_args(["3000"])

    def test_unknown_flag_exits(self) -> None:
        with self.assertRaises(SystemExit):
            _parse_args(["3000", "--api-key=k1", "--bogus=1"])

    def test_extra_positional_exits(self) -> None:
        with self.assertRaises(SystemExit):
            _parse_args(["3000", "extra", "--api-key=k1"])


if __name__ == "__main__":
    unittest.main()
