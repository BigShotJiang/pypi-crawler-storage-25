"""omega-obsidian: Persistent semantic memory MCP server for Obsidian vaults."""

__version__ = "0.1.0"
