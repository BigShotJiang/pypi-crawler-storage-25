"""Configuration for omega-obsidian."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


@dataclass
class Config:
    """Configuration for the omega-obsidian server."""

    vault_path: str = ""
    db_path: str = str(Path.home() / ".omega-obsidian" / "index.db")
    excluded_folders: List[str] = field(
        default_factory=lambda: [".obsidian", ".trash"]
    )

    @classmethod
    def from_env(cls) -> "Config":
        """Load configuration from environment variables."""
        vault_path = os.environ.get("OBSIDIAN_VAULT_PATH", "")
        db_path = os.environ.get(
            "OBSIDIAN_DB_PATH",
            str(Path.home() / ".omega-obsidian" / "index.db"),
        )
        excluded = os.environ.get("OBSIDIAN_EXCLUDED_FOLDERS", ".obsidian,.trash")
        excluded_folders = [f.strip() for f in excluded.split(",") if f.strip()]

        return cls(
            vault_path=vault_path,
            db_path=db_path,
            excluded_folders=excluded_folders,
        )

    def validate(self) -> None:
        """Validate the configuration. Raises ValueError if invalid."""
        if not self.vault_path:
            raise ValueError(
                "vault_path is required. Set OBSIDIAN_VAULT_PATH or pass --vault-path."
            )
        vault = Path(self.vault_path)
        if not vault.exists():
            raise ValueError(f"Vault path does not exist: {self.vault_path}")
        if not vault.is_dir():
            raise ValueError(f"Vault path is not a directory: {self.vault_path}")
