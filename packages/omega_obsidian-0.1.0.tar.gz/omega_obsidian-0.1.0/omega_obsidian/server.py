"""omega-obsidian MCP server: persistent semantic memory for Obsidian vaults."""

import argparse
import asyncio
import json
import logging
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from omega_obsidian.config import Config
from omega_obsidian.vault_indexer import VaultIndexer

logger = logging.getLogger("omega-obsidian")

app = Server("omega-obsidian")

# Module-level state, initialized in main()
_indexer: VaultIndexer | None = None


def _get_indexer() -> VaultIndexer:
    if _indexer is None:
        raise RuntimeError("Indexer not initialized. Vault path may be missing.")
    return _indexer


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="vault_search",
            description=(
                "Semantic search across all indexed Obsidian vault notes. "
                "Returns matching notes ranked by relevance with scores and snippets."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query (natural language or keywords)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return",
                        "default": 5,
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="vault_read",
            description=(
                "Read a specific note from the Obsidian vault by its path. "
                "Returns the full note content including frontmatter, tags, and wikilinks."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the note, relative to the vault root (e.g. 'Projects/my-note.md')",
                    },
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="vault_remember",
            description=(
                "Store a new memory or note into the Obsidian vault from agent context. "
                "Creates a markdown file with frontmatter and indexes it immediately."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "The note content (markdown)",
                    },
                    "title": {
                        "type": "string",
                        "description": "Title for the note (used as filename)",
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Tags for the note",
                    },
                    "folder": {
                        "type": "string",
                        "description": "Folder within the vault to create the note in (optional)",
                    },
                },
                "required": ["content", "title", "tags"],
            },
        ),
        Tool(
            name="vault_graph",
            description=(
                "Get notes related to a given note via backlinks, wikilinks, and shared tags. "
                "Useful for exploring the knowledge graph around a topic."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the note, relative to the vault root",
                    },
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="vault_index",
            description=(
                "Reindex the Obsidian vault. Rebuilds embeddings for new or modified files. "
                "Run this after making changes to the vault outside the agent."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="vault_recent",
            description=(
                "Get recently modified notes from the Obsidian vault, "
                "sorted by modification time (newest first)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return",
                        "default": 10,
                    },
                },
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    try:
        indexer = _get_indexer()

        if name == "vault_search":
            query = arguments["query"]
            limit = arguments.get("limit", 5)
            results = indexer.search(query, limit=limit)
            return [TextContent(type="text", text=json.dumps(results, indent=2))]

        elif name == "vault_read":
            path = arguments["path"]
            result = indexer.read_note(path)
            if result is None:
                return [TextContent(type="text", text=f"Note not found: {path}")]
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "vault_remember":
            content = arguments["content"]
            title = arguments["title"]
            tags = arguments.get("tags", [])
            folder = arguments.get("folder")
            created_path = indexer.remember(content, title, tags, folder=folder)
            return [
                TextContent(
                    type="text",
                    text=json.dumps(
                        {"status": "created", "path": created_path}, indent=2
                    ),
                )
            ]

        elif name == "vault_graph":
            path = arguments["path"]
            related = indexer.get_related(path)
            return [TextContent(type="text", text=json.dumps(related, indent=2))]

        elif name == "vault_index":
            stats = indexer.index(force=True)
            return [TextContent(type="text", text=json.dumps(stats, indent=2))]

        elif name == "vault_recent":
            limit = arguments.get("limit", 10)
            results = indexer.get_recent(limit=limit)
            return [TextContent(type="text", text=json.dumps(results, indent=2))]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        logger.exception("Error in tool %s", name)
        return [TextContent(type="text", text=f"Error: {e}")]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    global _indexer

    parser = argparse.ArgumentParser(
        description="omega-obsidian: Persistent semantic memory MCP server for Obsidian vaults"
    )
    parser.add_argument(
        "--vault-path",
        help="Path to the Obsidian vault directory (or set OBSIDIAN_VAULT_PATH)",
    )
    parser.add_argument(
        "--db-path",
        help="Path to the index database (default: ~/.omega-obsidian/index.db)",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging"
    )
    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    # Build config
    config = Config.from_env()
    if args.vault_path:
        config.vault_path = args.vault_path
    if args.db_path:
        config.db_path = args.db_path

    config.validate()

    # Initialize indexer and auto-index on startup
    _indexer = VaultIndexer(config)
    logger.info("Indexing vault at %s ...", config.vault_path)
    stats = _indexer.index()
    logger.info(
        "Startup indexing complete: %d notes indexed, %d skipped (%.1fs)",
        stats["indexed"],
        stats["skipped"],
        stats["elapsed_seconds"],
    )

    # Run MCP server on stdio
    async def _run() -> None:
        async with stdio_server() as (read, write):
            await app.run(read, write, app.create_initialization_options())

    asyncio.run(_run())


if __name__ == "__main__":
    main()
