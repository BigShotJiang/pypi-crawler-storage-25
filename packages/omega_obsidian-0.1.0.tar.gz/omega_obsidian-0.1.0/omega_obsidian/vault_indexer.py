"""Obsidian vault indexer with semantic embedding and SQLite storage."""

import hashlib
import json
import logging
import math
import os
import re
import sqlite3
import time
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from omega_obsidian.config import Config

logger = logging.getLogger("omega-obsidian")

# ---------------------------------------------------------------------------
# Markdown / Obsidian parsing
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_WIKILINK_RE = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]")
_TAG_RE = re.compile(r"(?:^|\s)#([a-zA-Z0-9_/][a-zA-Z0-9_/-]*)")


def parse_frontmatter(content: str) -> Tuple[Dict[str, Any], str]:
    """Extract YAML frontmatter and body from a markdown file.

    Returns (metadata_dict, body_text). If no frontmatter is found,
    returns an empty dict and the full content.
    """
    match = _FRONTMATTER_RE.match(content)
    if not match:
        return {}, content

    raw_yaml = match.group(1)
    body = content[match.end() :]

    # Minimal YAML-like parser (avoids PyYAML dependency).
    # Handles single-level key: value pairs and simple lists.
    meta: Dict[str, Any] = {}
    current_key: Optional[str] = None
    current_list: Optional[List[str]] = None

    for line in raw_yaml.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        # List item under a key
        if stripped.startswith("- ") and current_key is not None:
            if current_list is None:
                current_list = []
            current_list.append(stripped[2:].strip().strip("\"'"))
            meta[current_key] = current_list
            continue

        # Key: value
        if ":" in stripped:
            if current_list is not None:
                current_list = None
            key, _, value = stripped.partition(":")
            key = key.strip()
            value = value.strip().strip("\"'")
            current_key = key
            if value:
                meta[key] = value
                current_list = None
            else:
                # Next lines might be a list
                current_list = []
                meta[key] = current_list

    # Clean up empty lists
    for k, v in list(meta.items()):
        if isinstance(v, list) and len(v) == 0:
            meta[k] = ""

    return meta, body


def extract_wikilinks(content: str) -> List[str]:
    """Extract all [[wikilink]] targets from content."""
    return _WIKILINK_RE.findall(content)


def extract_tags(content: str) -> List[str]:
    """Extract all #tags from content."""
    return _TAG_RE.findall(content)


# ---------------------------------------------------------------------------
# Embedding backends
# ---------------------------------------------------------------------------


def _try_omega_embedding(text: str) -> Optional[List[float]]:
    """Try to generate embedding using OMEGA's engine."""
    try:
        from omega.embedding import generate_embedding

        return generate_embedding(text)
    except Exception:
        return None


def _try_omega_embeddings_batch(texts: List[str]) -> Optional[List[List[float]]]:
    """Try to generate embeddings in batch using OMEGA's engine."""
    try:
        from omega.embedding import generate_embeddings_batch

        return generate_embeddings_batch(texts)
    except Exception:
        return None


class TfIdfEmbedder:
    """Lightweight TF-IDF fallback when OMEGA embeddings are unavailable.

    Produces deterministic 384-dim vectors via hashed term frequencies,
    weighted by inverse document frequency estimated from the corpus.
    """

    def __init__(self, dimension: int = 384):
        self.dimension = dimension
        self._doc_freq: Counter = Counter()
        self._num_docs: int = 0

    def fit(self, documents: List[str]) -> None:
        """Build IDF statistics from a corpus."""
        self._num_docs = len(documents)
        self._doc_freq.clear()
        for doc in documents:
            tokens = set(self._tokenize(doc))
            for t in tokens:
                self._doc_freq[t] += 1

    def embed(self, text: str) -> List[float]:
        """Generate a 384-dim embedding for a single text."""
        tokens = self._tokenize(text)
        vec = [0.0] * self.dimension
        tf = Counter(tokens)
        for token, count in tf.items():
            idf = math.log(
                (self._num_docs + 1) / (self._doc_freq.get(token, 0) + 1)
            )
            weight = count * idf
            # Hash token to bucket
            bucket = int(hashlib.md5(token.encode()).hexdigest(), 16) % self.dimension
            vec[bucket] += weight

        # Normalize
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        return [self.embed(t) for t in texts]

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """Basic whitespace + punctuation tokenizer."""
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        return [w for w in text.split() if len(w) > 1]


def cosine_similarity(a: List[float], b: List[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# SQLite schema and VaultIndexer
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS notes (
    path TEXT PRIMARY KEY,
    title TEXT,
    content TEXT,
    frontmatter TEXT,
    tags TEXT,
    wikilinks TEXT,
    mtime REAL,
    content_hash TEXT,
    embedding BLOB,
    indexed_at REAL
);

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_notes_mtime ON notes(mtime);
"""


class VaultIndexer:
    """Indexes an Obsidian vault into a SQLite database with embeddings."""

    def __init__(self, config: Config):
        self.config = config
        self.vault_path = Path(config.vault_path).resolve()
        self.db_path = Path(config.db_path)
        self._conn: Optional[sqlite3.Connection] = None
        self._tfidf: Optional[TfIdfEmbedder] = None
        self._use_omega: Optional[bool] = None

    # -- DB lifecycle --

    def _ensure_db(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA_SQL)
        return self._conn

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # -- Embedding --

    def _detect_embedding_backend(self) -> bool:
        """Returns True if OMEGA embeddings are available."""
        if self._use_omega is not None:
            return self._use_omega
        result = _try_omega_embedding("test")
        self._use_omega = result is not None
        if self._use_omega:
            logger.info("Using OMEGA embedding engine (bge-small-en-v1.5 via ONNX)")
        else:
            logger.info("OMEGA not available, using TF-IDF fallback embeddings")
        return self._use_omega

    def _embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a list of texts."""
        if not texts:
            return []

        if self._detect_embedding_backend():
            result = _try_omega_embeddings_batch(texts)
            if result is not None:
                return result
            # Fall through to TF-IDF if batch failed
            self._use_omega = False
            logger.warning("OMEGA batch embedding failed, falling back to TF-IDF")

        if self._tfidf is None:
            self._tfidf = TfIdfEmbedder()
            # Fit on all existing note content for better IDF
            conn = self._ensure_db()
            rows = conn.execute("SELECT content FROM notes").fetchall()
            corpus = [r["content"] for r in rows if r["content"]]
            corpus.extend(texts)
            self._tfidf.fit(corpus)

        return self._tfidf.embed_batch(texts)

    def _embed_single(self, text: str) -> List[float]:
        """Generate embedding for a single text."""
        if self._detect_embedding_backend():
            result = _try_omega_embedding(text)
            if result is not None:
                return result
            self._use_omega = False

        if self._tfidf is None:
            self._tfidf = TfIdfEmbedder()
            conn = self._ensure_db()
            rows = conn.execute("SELECT content FROM notes").fetchall()
            corpus = [r["content"] for r in rows if r["content"]]
            corpus.append(text)
            self._tfidf.fit(corpus)

        return self._tfidf.embed(text)

    # -- Vault scanning --

    def _scan_vault(self) -> List[Path]:
        """Walk the vault and return all markdown files, respecting exclusions."""
        files = []
        excluded = set(self.config.excluded_folders)
        for root, dirs, filenames in os.walk(self.vault_path):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in excluded]
            for fname in filenames:
                if fname.endswith(".md"):
                    files.append(Path(root) / fname)
        return files

    def _relative_path(self, filepath: Path) -> str:
        """Get path relative to vault root."""
        return str(filepath.relative_to(self.vault_path))

    def _content_hash(self, content: str) -> str:
        return hashlib.md5(content.encode()).hexdigest()

    # -- Indexing --

    def index(self, force: bool = False) -> Dict[str, Any]:
        """Index the vault. Returns stats about the indexing run.

        If force=True, reindexes all files regardless of modification time.
        Otherwise, only indexes new or modified files (incremental).
        """
        start_time = time.time()
        conn = self._ensure_db()

        md_files = self._scan_vault()
        total_files = len(md_files)
        indexed = 0
        skipped = 0
        errors = 0

        # Gather files that need indexing
        to_index: List[Tuple[Path, str, str]] = []  # (path, rel_path, content)

        for filepath in md_files:
            rel_path = self._relative_path(filepath)
            try:
                stat = filepath.stat()
                mtime = stat.st_mtime

                if not force:
                    row = conn.execute(
                        "SELECT mtime, content_hash FROM notes WHERE path = ?",
                        (rel_path,),
                    ).fetchone()
                    if row and row["mtime"] >= mtime:
                        skipped += 1
                        continue

                content = filepath.read_text(encoding="utf-8", errors="replace")
                to_index.append((filepath, rel_path, content))
            except Exception as e:
                logger.warning("Error reading %s: %s", rel_path, e)
                errors += 1

        # Generate embeddings in batch
        if to_index:
            texts_for_embedding = []
            for _, rel_path, content in to_index:
                meta, body = parse_frontmatter(content)
                title = meta.get("title", Path(rel_path).stem)
                # Embed title + first ~2000 chars of body for relevance
                embed_text = f"{title}\n{body[:2000]}"
                texts_for_embedding.append(embed_text)

            embeddings = self._embed_texts(texts_for_embedding)

            for i, (filepath, rel_path, content) in enumerate(to_index):
                try:
                    meta, body = parse_frontmatter(content)
                    title = meta.get("title", filepath.stem)
                    # Merge frontmatter tags and inline #tags, deduplicated
                    fm_tags = meta.get("tags", [])
                    if isinstance(fm_tags, str):
                        fm_tags = [fm_tags] if fm_tags else []
                    inline_tags = extract_tags(content)
                    tags = list(dict.fromkeys(fm_tags + inline_tags))
                    wikilinks = extract_wikilinks(content)
                    chash = self._content_hash(content)
                    mtime = filepath.stat().st_mtime
                    embedding = embeddings[i] if i < len(embeddings) else []

                    conn.execute(
                        """INSERT OR REPLACE INTO notes
                           (path, title, content, frontmatter, tags, wikilinks,
                            mtime, content_hash, embedding, indexed_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            rel_path,
                            title,
                            content,
                            json.dumps(meta),
                            json.dumps(tags),
                            json.dumps(wikilinks),
                            mtime,
                            chash,
                            json.dumps(embedding),
                            time.time(),
                        ),
                    )
                    indexed += 1
                except Exception as e:
                    logger.warning("Error indexing %s: %s", rel_path, e)
                    errors += 1

            conn.commit()

        # Remove notes for deleted files
        existing_paths = {self._relative_path(f) for f in md_files}
        db_paths = {
            r["path"] for r in conn.execute("SELECT path FROM notes").fetchall()
        }
        removed = db_paths - existing_paths
        if removed:
            conn.executemany(
                "DELETE FROM notes WHERE path = ?", [(p,) for p in removed]
            )
            conn.commit()

        elapsed = time.time() - start_time

        # Store metadata
        backend = "omega" if self._use_omega else "tfidf"
        conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("last_index_time", str(time.time())),
        )
        conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("embedding_backend", backend),
        )
        conn.commit()

        stats = {
            "total_files": total_files,
            "indexed": indexed,
            "skipped": skipped,
            "removed": len(removed),
            "errors": errors,
            "elapsed_seconds": round(elapsed, 2),
            "embedding_backend": backend,
        }
        logger.info("Indexing complete: %s", stats)
        return stats

    # -- Search --

    def search(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Semantic search across all indexed notes.

        Returns a list of matches with path, title, score, and a content snippet.
        """
        conn = self._ensure_db()
        query_embedding = self._embed_single(query)

        rows = conn.execute(
            "SELECT path, title, content, embedding FROM notes"
        ).fetchall()

        scored: List[Tuple[float, Dict[str, Any]]] = []
        for row in rows:
            try:
                note_embedding = json.loads(row["embedding"])
                if not note_embedding:
                    continue
                score = cosine_similarity(query_embedding, note_embedding)
                # Extract a snippet (first 300 chars of body)
                _, body = parse_frontmatter(row["content"] or "")
                snippet = body.strip()[:300]
                scored.append(
                    (
                        score,
                        {
                            "path": row["path"],
                            "title": row["title"],
                            "score": round(score, 4),
                            "snippet": snippet,
                        },
                    )
                )
            except Exception:
                continue

        scored.sort(key=lambda x: x[0], reverse=True)
        return [item for _, item in scored[:limit]]

    # -- Read --

    def read_note(self, path: str) -> Optional[Dict[str, Any]]:
        """Read a specific note by its vault-relative path."""
        conn = self._ensure_db()
        row = conn.execute(
            "SELECT path, title, content, frontmatter, tags, wikilinks, mtime "
            "FROM notes WHERE path = ?",
            (path,),
        ).fetchone()

        if not row:
            # Try fuzzy match (filename without extension)
            stem = Path(path).stem
            row = conn.execute(
                "SELECT path, title, content, frontmatter, tags, wikilinks, mtime "
                "FROM notes WHERE path LIKE ?",
                (f"%{stem}%",),
            ).fetchone()

        if not row:
            return None

        return {
            "path": row["path"],
            "title": row["title"],
            "content": row["content"],
            "frontmatter": json.loads(row["frontmatter"] or "{}"),
            "tags": json.loads(row["tags"] or "[]"),
            "wikilinks": json.loads(row["wikilinks"] or "[]"),
            "modified": row["mtime"],
        }

    # -- Remember (create note) --

    def remember(
        self,
        content: str,
        title: str,
        tags: List[str],
        folder: Optional[str] = None,
    ) -> str:
        """Create a new note in the vault from agent context.

        Returns the relative path of the created file.
        """
        # Sanitize title for filename
        safe_title = re.sub(r'[<>:"/\\|?*]', "", title).strip()
        if not safe_title:
            safe_title = f"note-{int(time.time())}"

        if folder:
            target_dir = self.vault_path / folder
        else:
            target_dir = self.vault_path

        target_dir.mkdir(parents=True, exist_ok=True)
        filepath = target_dir / f"{safe_title}.md"

        # Handle collision
        counter = 1
        while filepath.exists():
            filepath = target_dir / f"{safe_title}-{counter}.md"
            counter += 1

        # Build note content with frontmatter
        lines = ["---"]
        lines.append(f"title: \"{title}\"")
        if tags:
            lines.append("tags:")
            for tag in tags:
                lines.append(f"  - {tag}")
        lines.append(f"created: {time.strftime('%Y-%m-%dT%H:%M:%S')}")
        lines.append("source: omega-obsidian")
        lines.append("---")
        lines.append("")
        lines.append(content)

        filepath.write_text("\n".join(lines), encoding="utf-8")
        rel_path = self._relative_path(filepath)

        # Index the new note immediately
        full_content = filepath.read_text(encoding="utf-8")
        meta, body = parse_frontmatter(full_content)
        embedding = self._embed_single(f"{title}\n{body[:2000]}")
        wikilinks = extract_wikilinks(full_content)
        # Merge frontmatter tags and inline #tags, deduplicated
        fm_tags = meta.get("tags", [])
        if isinstance(fm_tags, str):
            fm_tags = [fm_tags] if fm_tags else []
        inline_tags = extract_tags(full_content)
        note_tags = list(dict.fromkeys(fm_tags + inline_tags))

        conn = self._ensure_db()
        conn.execute(
            """INSERT OR REPLACE INTO notes
               (path, title, content, frontmatter, tags, wikilinks,
                mtime, content_hash, embedding, indexed_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                rel_path,
                title,
                full_content,
                json.dumps(meta),
                json.dumps(note_tags),
                json.dumps(wikilinks),
                filepath.stat().st_mtime,
                self._content_hash(full_content),
                json.dumps(embedding),
                time.time(),
            ),
        )
        conn.commit()

        return rel_path

    # -- Graph (related notes) --

    def get_related(self, path: str) -> List[Dict[str, Any]]:
        """Get notes related to the given path via backlinks, wikilinks, and shared tags."""
        conn = self._ensure_db()
        row = conn.execute(
            "SELECT tags, wikilinks FROM notes WHERE path = ?", (path,)
        ).fetchone()

        if not row:
            return []

        note_tags = set(json.loads(row["tags"] or "[]"))
        note_wikilinks = set(json.loads(row["wikilinks"] or "[]"))
        stem = Path(path).stem

        related: Dict[str, Dict[str, Any]] = {}

        all_rows = conn.execute(
            "SELECT path, title, tags, wikilinks FROM notes WHERE path != ?",
            (path,),
        ).fetchall()

        for r in all_rows:
            r_path = r["path"]
            r_tags = set(json.loads(r["tags"] or "[]"))
            r_wikilinks = set(json.loads(r["wikilinks"] or "[]"))
            r_stem = Path(r_path).stem
            relationships = []

            # Check if this note links to our note (backlink)
            if stem in r_wikilinks or path in r_wikilinks:
                relationships.append("backlink")

            # Check if our note links to this note (wikilink)
            if r_stem in note_wikilinks or r_path in note_wikilinks:
                relationships.append("wikilink")

            # Check shared tags
            shared = note_tags & r_tags
            if shared:
                relationships.append("shared-tag")

            if relationships:
                related[r_path] = {
                    "path": r_path,
                    "title": r["title"],
                    "relationships": relationships,
                    "shared_tags": list(shared) if note_tags & r_tags else [],
                }

        return list(related.values())

    # -- Recent --

    def get_recent(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recently modified notes."""
        conn = self._ensure_db()
        rows = conn.execute(
            "SELECT path, title, mtime FROM notes ORDER BY mtime DESC LIMIT ?",
            (limit,),
        ).fetchall()

        return [
            {
                "path": r["path"],
                "title": r["title"],
                "modified": r["mtime"],
            }
            for r in rows
        ]
