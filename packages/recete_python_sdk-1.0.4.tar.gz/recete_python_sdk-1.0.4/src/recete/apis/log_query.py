import logging, jsonpickle, json
from http import HTTPMethod

from fmconsult.utils.url import UrlUtil

from recete.api import ReceteApi

class LogQueryApi(ReceteApi):
    def __init__(self):
        super().__init__()
        self.endpoint_url = UrlUtil().make_url(self.base_url, ['logquery'])
    
    def get_search_grid(self, search_term, skip=0, limit=10, sort='-startAt'):
        try:
            params = {
                'skip': skip,
                'limit': limit,
                'sort': sort
            }
            payload = {
                'term': search_term
            }
            res = self.call_request(
                http_method=HTTPMethod.POST, 
                request_url=self.endpoint_url, 
                params=params, 
                payload=payload
            )
            res = jsonpickle.decode(res)
            return res
        except:
            raise