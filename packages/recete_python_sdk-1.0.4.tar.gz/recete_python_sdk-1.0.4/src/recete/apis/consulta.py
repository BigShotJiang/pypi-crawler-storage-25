import logging, jsonpickle, json
from http import HTTPMethod

from fmconsult.utils.url import UrlUtil

from recete.api import ReceteApi

class ConsultaApi(ReceteApi):
    def __init__(self):
        super().__init__()
        self.endpoint_url = UrlUtil().make_url(self.base_url, ['consulta'])
    
    def get_fd_scpc_person_type(self, person_type, document_number):
        try:
            payload = { person_type: document_number }
            res = self.call_request(HTTPMethod.POST, self.endpoint_url, None, payload=payload)
            res = jsonpickle.decode(res)
            return res
        except:
            raise