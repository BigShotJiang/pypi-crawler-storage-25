import os, jsonpickle
from http import HTTPMethod

from fmconsult.http.api import ApiBase
from fmconsult.utils.url import UrlUtil

class ReceteApi(ApiBase):

  def __init__(self):
    try:
      self.api_domain = os.environ['recete.api.domain']
      self.api_email = os.environ['recete.api.email']
      self.api_pass = os.environ['recete.api.pass']

      self.base_url = 'https://o61rua0rna.execute-api.eu-central-1.amazonaws.com/main'
      self.headers = {}

      self.__login()
    except:
      raise
  def __login(self):
    try:
      res = self.call_request(
        http_method = HTTPMethod.POST, 
        request_url = UrlUtil().make_url(self.base_url, ['user','login']), 
        payload = {
          'domain': self.api_domain,
          'email': self.api_email, 
          'pass': self.api_pass,
          'neverExpires': True
        }
      )
      res = jsonpickle.decode(res)
      if not res.get('error'):
        self.api_token = res.get('token')
        self.headers['Authorization'] = self.api_token
      else:
        raise Exception(res['message'])
    except:
      raise