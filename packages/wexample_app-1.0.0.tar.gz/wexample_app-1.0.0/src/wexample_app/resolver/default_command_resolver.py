from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_app.resolver.abstract_command_resolver import AbstractCommandResolver

if TYPE_CHECKING:
    from wexample_app.common.command_request import CommandRequest


class DefaultCommandResolver(AbstractCommandResolver):
    @classmethod
    def get_pattern(cls) -> str:
        return r"^([\w_-]+)/([\w_-]+)$"

    @classmethod
    def get_type(cls) -> str:
        return "default"

    def build_command_function_name(self, request: CommandRequest) -> str | None:
        import re

        return re.sub(r"[^a-zA-Z0-9_]", "", request.name.replace("/", "__"))

    def build_command_path(self, request: CommandRequest, extension: str) -> str | None:
        base_path = getattr(self.kernel, "command_base_path", None)
        if base_path is None:
            base_path = self.kernel.workdir.get_path() / "src/commands"
        return base_path / f"{request.name}.{extension}"
