from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_helpers.exception.undefined_exception import UndefinedException

if TYPE_CHECKING:
    from wexample_app.common.abstract_kernel import AbstractKernel


class AppRuntimeException(UndefinedException):
    """Base exception for expected runtime errors in the application.

    This exception class is used for errors that are part of normal application
    flow and should not display a full traceback. These are business logic errors
    that should be handled gracefully and displayed to the user in a friendly way.

    Examples include:
    - Command not found
    - Invalid configuration
    - Missing required resources

    Subclasses of this exception can be caught specifically to provide
    custom error handling without showing technical stack traces.
    """

    error_code: str = "APP_RUNTIME_ERROR"

    def format_error_with_kernel(self, kernel: AbstractKernel) -> None:
        """Format and display the exception using the kernel's error system.

        In verbose mode (-vvv), includes the full traceback.
        Otherwise, displays a friendly message with a hint to use -vvv.

        Args:
            kernel: The kernel instance to use for error display and logging
        """
        from wexample_prompt.enums.verbosity_level import VerbosityLevel

        is_verbose = kernel.io.default_context_verbosity >= VerbosityLevel.MAXIMUM
        message = f"[{self.error_code}] {self.message}"

        if is_verbose:
            kernel.io.error(message=message, exception=self)
        else:
            kernel.io.error(message=message)

            if self.data:
                for key, value in self.data.items():
                    kernel.io.log(message=f"  {key}: {value}", indentation=1)

            kernel.io.log(message="Run with -vvv for the full traceback.")
