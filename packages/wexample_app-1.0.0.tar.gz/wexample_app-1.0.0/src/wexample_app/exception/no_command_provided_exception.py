from __future__ import annotations

from wexample_app.exception.app_runtime_exception import AppRuntimeException


class NoCommandProvidedException(AppRuntimeException):
    error_code: str = "NO_COMMAND_PROVIDED"
    message: str = "No command provided. Run 'wex --help' to see available commands."
