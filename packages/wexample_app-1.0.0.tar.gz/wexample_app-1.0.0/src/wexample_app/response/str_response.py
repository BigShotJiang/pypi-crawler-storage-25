from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_helpers.classes.field import public_field
from wexample_helpers.decorator.base_class import base_class

from wexample_app.response.abstract_response import AbstractResponse

if TYPE_CHECKING:
    from wexample_app.const.types import ResponsePrintable


@base_class
class StrResponse(AbstractResponse):
    content: str = public_field(description="String content of the response")

    def __attrs_post_init__(self) -> None:
        from wexample_app.exception.response_invalid_content_type_exception import (
            ResponseInvalidContentTypeException,
        )

        self._execute_super_attrs_post_init_if_exists()

        if not isinstance(self.content, str):
            raise ResponseInvalidContentTypeException(
                content=self.content, allowed_content_types=[str]
            )

    def get_printable(self) -> ResponsePrintable:
        return self.content
