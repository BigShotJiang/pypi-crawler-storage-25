from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from wexample_helpers.classes.field import public_field
from wexample_helpers.decorator.base_class import base_class

from wexample_app.response.abstract_response import AbstractResponse

if TYPE_CHECKING:
    from wexample_app.const.types import ResponsePrintable


@base_class
class FunctionResponse(AbstractResponse):
    """Defers execution of a callable that returns a response.

    Useful when you want to return a response lazily — e.g. as a step
    inside a QueuedCollectionResponse.
    """

    content: Callable[[], AbstractResponse] = public_field(
        description="Callable that returns an AbstractResponse when invoked"
    )

    def __attrs_post_init__(self) -> None:
        self._execute_super_attrs_post_init_if_exists()
        self._inner_response: AbstractResponse | None = None

    def get_formatted(self, output_format: str) -> str:
        return self._get_inner_response().get_formatted(output_format)

    def get_printable(self) -> ResponsePrintable:
        return self._get_inner_response().get_printable()

    def _get_inner_response(self) -> AbstractResponse:
        if self._inner_response is None:
            self._inner_response = self.content()
        return self._inner_response
