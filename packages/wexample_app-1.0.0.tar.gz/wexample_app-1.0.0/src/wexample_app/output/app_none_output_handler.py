from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_helpers.decorator.base_class import base_class

from wexample_app.common.command_request import CommandRequest
from wexample_app.output.abstract_app_output_handler import (
    AbstractAppOutputHandler,
)

if TYPE_CHECKING:
    from wexample_app.response.abstract_response import AbstractResponse


@base_class
class AppNoneOutputHandler(AbstractAppOutputHandler):
    """Don't return the output."""

    def get_target_name(self) -> str:
        from wexample_app.const.output import OUTPUT_TARGET_NONE

        return OUTPUT_TARGET_NONE

    def print(self, request: CommandRequest, response: AbstractResponse) -> str | None:
        # Suppress all output including io.print_response() side effects
        return None

    def _write_output(self, request: CommandRequest, content: str) -> str | None:
        pass
