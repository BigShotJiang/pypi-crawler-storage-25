from __future__ import annotations

from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    CONNECTION_FAILED = "CONNECTION_FAILED"
    AUTH_FAILED = "AUTH_FAILED"
    CONNECTION_TIMEOUT = "CONNECTION_TIMEOUT"
    QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
    VOICE_NOT_SUPPORTED = "VOICE_NOT_SUPPORTED"
    VOICE_ALREADY_ACTIVE = "VOICE_ALREADY_ACTIVE"
    VOICE_NOT_ACTIVE = "VOICE_NOT_ACTIVE"
    VOICE_START_FAILED = "VOICE_START_FAILED"
    LIVEKIT_UNAVAILABLE = "LIVEKIT_UNAVAILABLE"
    NOT_CONNECTED = "NOT_CONNECTED"
    REST_ERROR = "REST_ERROR"
    UNKNOWN = "UNKNOWN"


class EstuaryError(Exception):
    def __init__(
        self,
        message: str,
        code: ErrorCode = ErrorCode.UNKNOWN,
        details: Any = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.details = details

    def __repr__(self) -> str:
        return f"EstuaryError({self.code.value}: {self})"
