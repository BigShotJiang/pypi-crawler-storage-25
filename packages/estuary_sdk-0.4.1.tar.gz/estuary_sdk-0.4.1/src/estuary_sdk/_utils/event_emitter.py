from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any, Callable

logger = logging.getLogger("estuary_sdk")

Callback = Callable[..., Any]


class AsyncEventEmitter:
    """Typed async event emitter. Callbacks can be sync or async functions."""

    def __init__(self) -> None:
        self._listeners: dict[str, list[Callback]] = defaultdict(list)
        self._once_listeners: set[Callback] = set()

    def on(self, event: str, callback: Callback) -> None:
        """Register a listener for an event."""
        self._listeners[event].append(callback)

    def off(self, event: str, callback: Callback) -> None:
        """Remove a specific listener for an event."""
        listeners = self._listeners.get(event)
        if listeners:
            try:
                listeners.remove(callback)
            except ValueError:
                pass
            self._once_listeners.discard(callback)

    def once(self, event: str, callback: Callback) -> None:
        """Register a one-time listener that auto-removes after first call."""
        self._listeners[event].append(callback)
        self._once_listeners.add(callback)

    async def emit(self, event: str, *args: Any) -> None:
        """Emit an event, calling all registered listeners."""
        listeners = list(self._listeners.get(event, []))
        for cb in listeners:
            if cb in self._once_listeners:
                self._once_listeners.discard(cb)
                try:
                    self._listeners[event].remove(cb)
                except ValueError:
                    pass
            try:
                result = cb(*args)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                logger.exception("Error in event listener for '%s'", event)

    def remove_all_listeners(self, event: str | None = None) -> None:
        """Remove all listeners, optionally for a specific event."""
        if event is not None:
            for cb in self._listeners.pop(event, []):
                self._once_listeners.discard(cb)
        else:
            self._listeners.clear()
            self._once_listeners.clear()
