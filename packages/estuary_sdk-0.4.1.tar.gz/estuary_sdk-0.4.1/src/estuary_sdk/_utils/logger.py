from __future__ import annotations

import logging


def get_logger(debug: bool = False) -> logging.Logger:
    """Get the estuary_sdk logger, configuring level based on debug flag."""
    log = logging.getLogger("estuary_sdk")
    if debug:
        log.setLevel(logging.DEBUG)
        if not log.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("[%(name)s] %(levelname)s: %(message)s"))
            log.addHandler(handler)
    else:
        log.setLevel(logging.WARNING)
    return log
