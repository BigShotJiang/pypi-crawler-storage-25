from __future__ import annotations

from typing import Any, Optional

from estuary_sdk.rest.rest_client import RestClient


class SharesClient:
    """Client for the unified Estuary Shares REST API.

    As of migration 053 (quick-260415-sg5), share_tokens and share_anchors
    are merged into a single ``/api/v1/share`` endpoint family. Permanent
    shares (formerly "anchors") are created with ``permanent=True``.

    Authentication matrix:
      - ``create_share``            — mixed auth. The SDK injects
        ``Authorization: Bearer {api_key}`` as a per-request header
        because the backend's ``_resolve_mixed_auth`` only reads the
        Bearer header and does not fall back to ``X-API-Key``.
      - ``revoke_share_token``      — mixed auth. Same Bearer-header
        pattern as ``create_share``. API keys may only revoke shares
        they created (scoped by ``created_via_api_key_id``); Firebase
        may revoke any owned share.
      - ``open_share``              — unauthenticated.
      - ``exchange_share_token``    — unauthenticated.
      - All other methods           — require a Firebase ID token on the
        backend. They are implemented for API completeness and will
        raise ``EstuaryError`` (HTTP 401) if called with only an
        ``est_`` API key.
    """

    def __init__(self, rest: RestClient) -> None:
        self._rest = rest
        self._base = "/api/v1/share"

    # ── Unified Share Methods ─────────────────────────────────

    async def create_share(
        self,
        character_id: str,
        permanent: bool = False,
        ttl: str = "7d",
        memory_sharing: str = "isolated",
        max_exchanges: int = 5,
        max_interactions: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a share link (temporary or permanent).

        When ``permanent=True``, the backend ignores ttl and max_exchanges.
        Supports mixed auth (API key or Firebase).

        Args:
            character_id: Owning character id.
            permanent: When True, creates a never-expiring link.
            ttl: Lifetime for temporary shares: "24h", "7d", "30d", "90d".
            memory_sharing: "isolated" or "shared".
            max_exchanges: Max recipients for temporary shares (1-100).
            max_interactions: Optional per-session interaction cap.

        Returns:
            ``{"token": str, "shareUrl": str, "expiresAt": str|None}``.
            When permanent: also includes ``"anchorUrl": str``.
        """
        body: dict[str, Any] = {
            "characterId": character_id,
            "permanent": permanent,
            "memorySharing": memory_sharing,
        }
        if not permanent:
            body["ttl"] = ttl
            body["maxExchanges"] = max_exchanges
        if max_interactions is not None:
            body["maxInteractions"] = max_interactions
        # Bearer header workaround for mixed auth.
        headers = {"Authorization": f"Bearer {self._rest.api_key}"}
        return await self._rest.post(self._base, body=body, headers=headers)

    async def open_share(self, share_id: str) -> dict[str, Any]:
        """Redeem a permanent share for a session token. Unauthenticated."""
        return await self._rest.post(f"{self._base}/{share_id}/open")

    async def bulk_revoke_by_api_key(self, api_key_id: str) -> dict[str, Any]:
        """Bulk-revoke all shares created via a given API key. Requires Firebase auth."""
        return await self._rest.delete(f"{self._base}/by-api-key/{api_key_id}")

    # ── Unchanged Token Methods ───────────────────────────────

    async def exchange_share_token(
        self, token: str, recipient_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Exchange a share token for a session token.

        Unauthenticated endpoint. ``recipient_id`` is required when the
        underlying share is in isolated mode; for shared mode it may be
        omitted.

        Args:
            token: The share token string.
            recipient_id: Client-provided recipient identifier for
                isolated shares.

        Returns:
            ``{"sessionToken", "characterId", "playerId", "serverUrl",
            "character"}``.
        """
        body: dict[str, Any] = {}
        if recipient_id is not None:
            body["recipientId"] = recipient_id
        return await self._rest.post(
            f"{self._base}/{token}/exchange", body=body
        )

    async def list_character_shares(
        self, character_id: str
    ) -> dict[str, Any]:
        """List active (non-revoked, non-expired) shares for a character.

        Returns both permanent and expiring shares in a single response.
        Requires Firebase auth -- will 401 with api_key only.

        Returns:
            ``{"shares": [ShareToken.to_dict(), ...]}``.
        """
        return await self._rest.get(
            f"{self._base}/character/{character_id}"
        )

    async def revoke_share_token(
        self, share_token_id: str
    ) -> dict[str, Any]:
        """Revoke a share by its DB row id (not the token string).

        Mixed auth: API key may revoke only shares it created (scoped by
        ``created_via_api_key_id``); Firebase may revoke any owned share.

        Returns:
            ``{"revoked": bool, "killedSessions": int,
            "removedSessionBlobs": int}``.
        """
        headers = {"Authorization": f"Bearer {self._rest.api_key}"}
        return await self._rest.delete(
            f"{self._base}/{share_token_id}", headers=headers
        )
