from __future__ import annotations

from typing import Any

from estuary_sdk.rest.rest_client import RestClient
from estuary_sdk.types import (
    CoreFactsResponse,
    MemoryDeleteResponse,
    MemoryGraph,
    MemoryListResponse,
    MemorySearchResponse,
    MemoryStats,
    MemoryTimeline,
)


class MemoryClient:
    """Client for the Estuary Memory REST API.

    Base path: /api/agents/{agent_id}/players/{player_id}/memories
    """

    def __init__(self, rest: RestClient, agent_id: str, player_id: str) -> None:
        self._rest = rest
        self._base = f"/api/agents/{agent_id}/players/{player_id}/memories"

    async def get_memories(
        self,
        memory_type: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
        sort_by: str | None = None,
        sort_order: str | None = None,
    ) -> MemoryListResponse:
        """List player memories with optional filtering and pagination."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if memory_type is not None:
            params["memory_type"] = memory_type
        if status is not None:
            params["status"] = status
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        data = await self._rest.get(self._base, params=params)
        return MemoryListResponse.from_dict(data)

    async def get_timeline(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        group_by: str | None = None,
    ) -> MemoryTimeline:
        """Get memory timeline grouped by time period."""
        params: dict[str, Any] = {}
        if start_date is not None:
            params["start_date"] = start_date
        if end_date is not None:
            params["end_date"] = end_date
        if group_by is not None:
            params["group_by"] = group_by
        data = await self._rest.get(f"{self._base}/timeline", params=params)
        return MemoryTimeline.from_dict(data)

    async def get_stats(self) -> MemoryStats:
        """Get memory statistics."""
        data = await self._rest.get(f"{self._base}/stats")
        return MemoryStats.from_dict(data)

    async def get_core_facts(self) -> CoreFactsResponse:
        """Get core facts derived from memories."""
        data = await self._rest.get(f"{self._base}/core-facts")
        return CoreFactsResponse.from_dict(data)

    async def get_graph(
        self,
        include_entities: bool | None = None,
        include_character_memories: bool | None = None,
    ) -> MemoryGraph:
        """Get memory knowledge graph."""
        params: dict[str, Any] = {}
        if include_entities is not None:
            params["include_entities"] = include_entities
        if include_character_memories is not None:
            params["include_character_memories"] = include_character_memories
        data = await self._rest.get(f"{self._base}/graph", params=params)
        return MemoryGraph.from_dict(data)

    async def search(self, query: str, limit: int | None = None) -> MemorySearchResponse:
        """Search memories by semantic similarity."""
        params: dict[str, Any] = {"q": query}
        if limit is not None:
            params["limit"] = limit
        data = await self._rest.get(f"{self._base}/search", params=params)
        return MemorySearchResponse.from_dict(data)

    async def delete_all(self, confirm: bool = True) -> MemoryDeleteResponse:
        """Delete all memories for this player.

        Args:
            confirm: Must be True to actually delete. Safety guard.
        """
        data = await self._rest.delete(self._base, params={"confirm": confirm})
        return MemoryDeleteResponse.from_dict(data)
