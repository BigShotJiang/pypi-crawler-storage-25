from __future__ import annotations

from typing import Any

from estuary_sdk.rest.rest_client import RestClient
from estuary_sdk.types import Character, CharacterListResponse


class CharactersClient:
    """Client for the Estuary Characters REST API.

    Base path: /api/v1/characters
    """

    def __init__(self, rest: RestClient, player_id: str) -> None:
        self._rest = rest
        self._player_id = player_id
        self._base = "/api/v1/characters"

    async def create(
        self,
        name: str,
        *,
        tagline: str | None = None,
        personality: str | None = None,
        background: str | None = None,
        system_prompt: str | None = None,
        llm_provider: str | None = None,
        llm_model: str | None = None,
        llm_temperature: float | None = None,
        llm_max_tokens: int | None = None,
        llm_verbosity: str | None = None,
        tts_provider: str | None = None,
        tts_model: str | None = None,
        tts_voice: str | None = None,
        tts_speed: float | None = None,
        stt_provider: str | None = None,
        stt_language: str | None = None,
        vad_sensitivity: float | None = None,
        vad_min_speech_duration_ms: int | None = None,
        vlm_model: str | None = None,
        avatar: str | None = None,
        text_only: bool | None = None,
        verbose: bool = False,
        actions: list[dict[str, Any]] | None = None,
        is_public: bool = False,
    ) -> Character:
        """Create a new character."""
        body: dict[str, Any] = {}

        # Persona
        persona: dict[str, Any] = {"name": name}
        if tagline is not None:
            persona["tagline"] = tagline
        if personality is not None:
            persona["personality"] = personality
        if background is not None:
            persona["background"] = background
        if system_prompt is not None:
            persona["system_prompt"] = system_prompt
        body["persona"] = persona

        # LLM
        llm: dict[str, Any] = {}
        if llm_provider is not None:
            llm["provider"] = llm_provider
        if llm_model is not None:
            llm["model"] = llm_model
        if llm_temperature is not None:
            llm["temperature"] = llm_temperature
        if llm_max_tokens is not None:
            llm["max_tokens"] = llm_max_tokens
        if llm_verbosity is not None:
            llm["verbosity"] = llm_verbosity
        if llm:
            body["llm"] = llm

        # TTS
        tts: dict[str, Any] = {}
        if tts_provider is not None:
            tts["provider"] = tts_provider
        if tts_model is not None:
            tts["model"] = tts_model
        if tts_voice is not None:
            tts["voice"] = tts_voice
        if tts_speed is not None:
            tts["speed"] = tts_speed
        if tts:
            body["tts"] = tts

        # STT
        stt: dict[str, Any] = {}
        if stt_provider is not None:
            stt["provider"] = stt_provider
        if stt_language is not None:
            stt["language"] = stt_language
        if stt:
            body["stt"] = stt

        # VAD
        vad: dict[str, Any] = {}
        if vad_sensitivity is not None:
            vad["sensitivity"] = vad_sensitivity
        if vad_min_speech_duration_ms is not None:
            vad["min_speech_duration_ms"] = vad_min_speech_duration_ms
        if vad:
            body["vad"] = vad

        # VLM
        if vlm_model is not None:
            body["vlm"] = {"model": vlm_model}

        # Other top-level fields
        if avatar is not None:
            body["avatar"] = avatar
        if text_only is not None:
            body["text_only"] = text_only
        body["verbose"] = verbose
        if actions is not None:
            body["actions"] = actions
        body["is_public"] = is_public

        data = await self._rest.post(self._base, body=body)
        return Character.from_dict(data)

    async def list(self, limit: int = 20, offset: int = 0) -> CharacterListResponse:
        """List characters."""
        data = await self._rest.get(
            self._base,
            params={"limit": limit, "offset": offset},
            headers={"X-Player-Id": self._player_id},
        )
        return CharacterListResponse.from_dict(data)

    async def get(self, character_id: str) -> Character:
        """Get a character by ID."""
        data = await self._rest.get(f"{self._base}/{character_id}")
        return Character.from_dict(data)

    async def update(self, character_id: str, **kwargs: Any) -> Character:
        """Update a character. Accepts the same kwargs as create()."""
        body: dict[str, Any] = {}

        # Persona fields
        persona: dict[str, Any] = {}
        for key in ("name", "tagline", "personality", "background", "system_prompt"):
            if key in kwargs:
                persona[key] = kwargs.pop(key)
        if persona:
            body["persona"] = persona

        # LLM fields
        llm: dict[str, Any] = {}
        llm_map = {
            "llm_provider": "provider",
            "llm_model": "model",
            "llm_temperature": "temperature",
            "llm_max_tokens": "max_tokens",
            "llm_verbosity": "verbosity",
        }
        for kwarg_key, body_key in llm_map.items():
            if kwarg_key in kwargs:
                llm[body_key] = kwargs.pop(kwarg_key)
        if llm:
            body["llm"] = llm

        # TTS fields
        tts: dict[str, Any] = {}
        tts_map = {
            "tts_provider": "provider",
            "tts_model": "model",
            "tts_voice": "voice",
            "tts_speed": "speed",
        }
        for kwarg_key, body_key in tts_map.items():
            if kwarg_key in kwargs:
                tts[body_key] = kwargs.pop(kwarg_key)
        if tts:
            body["tts"] = tts

        # STT fields
        stt: dict[str, Any] = {}
        stt_map = {"stt_provider": "provider", "stt_language": "language"}
        for kwarg_key, body_key in stt_map.items():
            if kwarg_key in kwargs:
                stt[body_key] = kwargs.pop(kwarg_key)
        if stt:
            body["stt"] = stt

        # VAD fields
        vad: dict[str, Any] = {}
        vad_map = {
            "vad_sensitivity": "sensitivity",
            "vad_min_speech_duration_ms": "min_speech_duration_ms",
        }
        for kwarg_key, body_key in vad_map.items():
            if kwarg_key in kwargs:
                vad[body_key] = kwargs.pop(kwarg_key)
        if vad:
            body["vad"] = vad

        # VLM
        if "vlm_model" in kwargs:
            body["vlm"] = {"model": kwargs.pop("vlm_model")}

        # Top-level fields
        for key in ("avatar", "text_only", "verbose", "actions", "is_public"):
            if key in kwargs:
                body[key] = kwargs.pop(key)

        data = await self._rest.put(f"{self._base}/{character_id}", body=body)
        return Character.from_dict(data)

    async def delete(self, character_id: str) -> dict[str, Any]:
        """Delete a character."""
        return await self._rest.delete(f"{self._base}/{character_id}")
