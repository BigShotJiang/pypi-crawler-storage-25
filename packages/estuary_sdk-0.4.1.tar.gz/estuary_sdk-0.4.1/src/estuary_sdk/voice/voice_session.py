"""VoiceSession -- high-level voice conversation wrapper.

Owns the lifecycle of AudioPlayer, AudioRecorder, and their event handlers.
The caller provides a connected EstuaryClient instance.

Usage::

    async with VoiceSession(client, mode=VoiceMode.CONTINUOUS) as session:
        # Voice is active; player and recorder are wired up.
        ...

Or manually::

    session = VoiceSession(client, mode=VoiceMode.PUSH_TO_TALK)
    await session.start()
    await session.start_recording()
    ...
    await session.stop_recording()
    await session.stop()
"""

from __future__ import annotations

import logging
from types import TracebackType
from typing import TYPE_CHECKING, Callable

from estuary_sdk.types import BotVoice, VoiceMode

if TYPE_CHECKING:
    from estuary_sdk.audio.player import AudioPlayer
    from estuary_sdk.audio.recorder import AudioRecorder
    from estuary_sdk.client import EstuaryClient

logger = logging.getLogger("estuary_sdk")


class VoiceSession:
    """High-level voice session managing player, recorder, and event wiring.

    Does NOT create the EstuaryClient -- the caller provides one. This makes
    VoiceSession composable and testable.
    """

    def __init__(
        self,
        client: EstuaryClient,
        mode: VoiceMode = VoiceMode.CONTINUOUS,
        *,
        sample_rate: int = 24000,
        on_playback_event: Callable[[str, str | None], None] | None = None,
        volume: float = 1.0,
    ) -> None:
        self._client = client
        self._mode = mode
        self._sample_rate = sample_rate
        self._on_playback_event = on_playback_event
        self._volume = max(0.0, min(1.0, volume))
        self._player: AudioPlayer | None = None
        self._recorder: AudioRecorder | None = None
        self._started = False
        self._registered_handlers: list[tuple[str, Callable]] = []

    @property
    def client(self) -> EstuaryClient:
        return self._client

    @property
    def is_started(self) -> bool:
        return self._started

    @property
    def volume(self) -> float:
        """Output volume (0.0 to 1.0)."""
        if self._player is not None:
            return self._player.volume
        return self._volume

    @volume.setter
    def volume(self, value: float) -> None:
        """Set output volume (0.0 to 1.0). Takes effect immediately."""
        self._volume = max(0.0, min(1.0, value))
        if self._player is not None:
            self._player.volume = self._volume

    async def start(self) -> None:
        """Start voice session: create player/recorder, start voice, wire handlers."""
        if self._started:
            return

        from estuary_sdk.audio.player import AudioPlayer
        from estuary_sdk.audio.recorder import AudioRecorder

        # Determine playback event callback: user-supplied or default
        playback_callback = self._on_playback_event

        if playback_callback is None:
            def playback_callback(event: str, message_id: str | None) -> None:
                if event == "complete" and message_id:
                    self._client.notify_audio_playback_complete(message_id)

        if self._player is None:
            self._player = AudioPlayer(
                sample_rate=self._sample_rate,
                on_playback_event=playback_callback,
                volume=self._volume,
            )
            # Pre-open the output stream in a thread to avoid blocking
            # the event loop when the first audio chunk arrives.
            await self._player.start()

        # Create recorder wired to client.send_audio
        if self._recorder is None:
            self._recorder = AudioRecorder(
                sample_rate=self._sample_rate,
                on_audio=self._client.send_audio,
            )

        # Wire handlers for bot audio
        async def on_bot_voice(voice: BotVoice) -> None:
            if self._player is not None and not voice.is_livekit:
                self._player.enqueue(voice)

        async def on_audio_received(audio: bytes) -> None:
            if self._player is not None:
                self._player.play_raw(audio)

        handlers: list[tuple[str, Callable]] = [
            ("bot_voice", on_bot_voice),
            ("audio_received", on_audio_received),
        ]
        for event_name, handler_fn in handlers:
            self._client.on(event_name, handler_fn)
        self._registered_handlers = handlers

        # Start voice on the client
        await self._client.start_voice(mode=self._mode)
        self._started = True

        # If continuous mode, start recording immediately
        if self._mode == VoiceMode.CONTINUOUS:
            await self._client.start_recording()
            await self._recorder.start()

        logger.info(
            "VoiceSession started (mode=%s, rate=%d)",
            self._mode.value,
            self._sample_rate,
        )

    async def start_recording(self) -> None:
        """Begin recording (for PTT mode)."""
        if self._player is not None:
            self._player.clear()
        self._client.interrupt()

        await self._client.start_recording()
        if self._recorder is not None:
            await self._recorder.start()

    async def stop_recording(self) -> None:
        """Stop recording (for PTT mode). Drains in-flight audio."""
        if self._recorder is not None:
            await self._recorder.drain()
        await self._client.stop_recording()

    async def stop(self) -> None:
        """Stop voice session: drain recorder, stop voice, dispose player."""
        if not self._started:
            return

        # Deregister event handlers
        for event_name, handler_fn in self._registered_handlers:
            try:
                self._client.off(event_name, handler_fn)
            except Exception:
                logger.debug("Failed to deregister handler for %s", event_name)
        self._registered_handlers.clear()

        # Stop recorder
        recorder = self._recorder
        self._recorder = None
        if recorder is not None:
            try:
                await recorder.drain()
            except Exception:
                logger.debug("Recorder drain failed during stop", exc_info=True)
            try:
                await recorder.stop()
            except Exception:
                logger.debug("Recorder stop failed during stop", exc_info=True)

        # Stop voice
        try:
            await self._client.stop_voice()
        except Exception:
            logger.debug("stop_voice failed during stop", exc_info=True)

        # Dispose player
        player = self._player
        self._player = None
        if player is not None:
            try:
                await player.dispose()
            except Exception:
                logger.debug("Player dispose failed during stop", exc_info=True)

        self._started = False
        logger.info("VoiceSession stopped")

    async def __aenter__(self) -> VoiceSession:
        await self.start()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.stop()
