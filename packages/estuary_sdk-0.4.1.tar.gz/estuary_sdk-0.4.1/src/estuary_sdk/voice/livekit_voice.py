from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable

from estuary_sdk.connection.socket_manager import SocketManager
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import LiveKitTokenResponse, VoiceMode

logger = logging.getLogger("estuary_sdk")

try:
    from livekit import rtc as livekit_rtc

    HAS_LIVEKIT = True
except ImportError:
    HAS_LIVEKIT = False


class LiveKitVoiceManager:
    """Voice manager that uses LiveKit WebRTC for low-latency audio.

    Supports sending microphone audio to the server and receiving TTS audio
    back via LiveKit audio tracks.

    Requires the `livekit` optional dependency:
        pip install estuary-sdk[livekit]
    """

    def __init__(
        self,
        socket_manager: SocketManager,
        sample_rate: int = 24000,
        voice_mode: VoiceMode = VoiceMode.CONTINUOUS,
        start_timeout: float = 10.0,
        on_audio_received: Callable[[bytes], Awaitable[None]] | None = None,
        livekit_token: LiveKitTokenResponse | None = None,
        apm_echo_cancellation: bool = True,
        apm_noise_suppression: bool = True,
        apm_auto_gain_control: bool = False,
        apm_high_pass_filter: bool = True,
    ) -> None:
        if not HAS_LIVEKIT:
            raise EstuaryError(
                "livekit package not installed. Install with: pip install estuary-sdk[livekit]",
                ErrorCode.LIVEKIT_UNAVAILABLE,
            )
        self._socket = socket_manager
        self._sample_rate = sample_rate
        self._voice_mode = voice_mode
        self._start_timeout = start_timeout
        self._on_audio_received = on_audio_received
        self._livekit_token = livekit_token
        self._apm_echo_cancellation = apm_echo_cancellation
        self._apm_noise_suppression = apm_noise_suppression
        self._apm_auto_gain_control = apm_auto_gain_control
        self._apm_high_pass_filter = apm_high_pass_filter
        self._active = False
        self._muted = False
        self._recording = False
        self._room: Any = None
        self._audio_source: Any = None
        self._track: Any = None
        self._audio_stream_task: asyncio.Task[None] | None = None
        self._apm: Any = None
        self._apm_buffer: bytes = b""

    @property
    def is_muted(self) -> bool:
        return self._muted

    @property
    def is_active(self) -> bool:
        return self._active

    async def start(self) -> None:
        """Start LiveKit voice: get token, connect to room, publish audio track, wait for ready."""
        if self._active:
            logger.warning("LiveKit voice already active")
            return

        # Step 1: Get token — use embedded or request from server
        if self._livekit_token:
            token_resp = self._livekit_token
        else:
            token_future: asyncio.Future[LiveKitTokenResponse] = (
                asyncio.get_event_loop().create_future()
            )

            def on_token(data: LiveKitTokenResponse) -> None:
                if not token_future.done():
                    token_future.set_result(data)

            self._socket.once("livekit_token", on_token)
            self._socket.emit_event("livekit_token")

            try:
                token_resp = await asyncio.wait_for(token_future, timeout=self._start_timeout)
            except asyncio.TimeoutError as e:
                raise EstuaryError(
                    "Timed out waiting for LiveKit token",
                    ErrorCode.LIVEKIT_UNAVAILABLE,
                ) from e

        # Step 2: Connect to LiveKit room (register track handler BEFORE connect
        # so we don't miss tracks the bot already published)
        self._room = livekit_rtc.Room()
        self._room.on("track_subscribed", self._on_track_subscribed)
        await self._room.connect(token_resp.url, token_resp.token)

        # Create standalone APM for echo cancellation, noise suppression, etc.
        self._apm = livekit_rtc.AudioProcessingModule(
            echo_cancellation=self._apm_echo_cancellation,
            noise_suppression=self._apm_noise_suppression,
            auto_gain_control=self._apm_auto_gain_control,
            high_pass_filter=self._apm_high_pass_filter,
        )
        self._apm_buffer = b""
        self._apm.set_stream_delay_ms(0)  # Required when echo_cancellation is enabled

        # Catch tracks already subscribed during connect
        for participant in self._room.remote_participants.values():
            for pub in participant.track_publications.values():
                if pub.track and pub.subscribed:
                    self._on_track_subscribed(pub.track, pub, participant)

        # Step 3: Create and publish audio track
        self._audio_source = livekit_rtc.AudioSource(self._sample_rate, 1)
        self._track = livekit_rtc.LocalAudioTrack.create_audio_track(
            "microphone", self._audio_source
        )
        options = livekit_rtc.TrackPublishOptions()
        options.source = livekit_rtc.TrackSource.SOURCE_MICROPHONE
        await self._room.local_participant.publish_track(self._track, options)

        # Step 4: Emit livekit_join and wait for livekit_ready or livekit_error
        loop = asyncio.get_event_loop()
        ready_future: asyncio.Future[str] = loop.create_future()
        error_future: asyncio.Future[str] = loop.create_future()

        def on_ready(room_name: str) -> None:
            if not ready_future.done():
                ready_future.set_result(room_name)

        def on_error(msg: str) -> None:
            if not error_future.done():
                error_future.set_result(msg)

        self._socket.once("livekit_ready", on_ready)
        self._socket.once("livekit_error", on_error)

        self._socket.emit_event("livekit_join")

        done, _ = await asyncio.wait(
            [
                asyncio.ensure_future(ready_future),
                asyncio.ensure_future(error_future),
            ],
            timeout=self._start_timeout,
            return_when=asyncio.FIRST_COMPLETED,
        )

        # Clean up whichever listener didn't fire
        if not ready_future.done():
            self._socket.off("livekit_ready", on_ready)
        if not error_future.done():
            self._socket.off("livekit_error", on_error)

        if error_future.done():
            await self._room.disconnect()
            self._room = None
            self._audio_source = None
            self._track = None
            raise EstuaryError(
                f"LiveKit start failed: {error_future.result()}",
                ErrorCode.LIVEKIT_UNAVAILABLE,
            )

        if ready_future.done():
            self._active = True
            logger.debug("LiveKit voice started (room=%s)", token_resp.room)
            return

        # Timeout
        await self._room.disconnect()
        self._room = None
        self._audio_source = None
        self._track = None
        raise EstuaryError(
            "Timed out waiting for livekit_ready confirmation",
            ErrorCode.LIVEKIT_UNAVAILABLE,
        )

    def _on_track_subscribed(
        self,
        track: Any,
        publication: Any,
        participant: Any,
    ) -> None:
        """Handle remote audio track subscription (bot's TTS audio)."""
        if track.kind == livekit_rtc.TrackKind.KIND_AUDIO:
            if self._audio_stream_task and not self._audio_stream_task.done():
                return  # Already receiving audio
            self._audio_stream_task = asyncio.ensure_future(self._receive_audio(track))

    async def _receive_audio(self, track: Any) -> None:
        """Receive audio frames from a remote track and forward to callback."""
        stream = livekit_rtc.AudioStream(
            track,
            sample_rate=self._sample_rate,
            num_channels=1,
        )
        try:
            async for frame_event in stream:
                frame = frame_event.frame
                audio_bytes = frame.data.tobytes()
                if self._apm:
                    self._process_reverse_with_apm(audio_bytes)
                if self._on_audio_received:
                    asyncio.ensure_future(self._on_audio_received(audio_bytes))
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Error in LiveKit audio receive loop")
        finally:
            await stream.aclose()

    async def stop(self) -> None:
        """Leave LiveKit room and clean up."""
        if not self._active:
            return

        if self._recording:
            await self.stop_recording()

        self._active = False
        self._socket.emit_event("livekit_leave")

        # Cancel audio receive task
        if self._audio_stream_task and not self._audio_stream_task.done():
            self._audio_stream_task.cancel()
            try:
                await self._audio_stream_task
            except asyncio.CancelledError:
                pass
            self._audio_stream_task = None

        # Close audio source
        if self._audio_source:
            await self._audio_source.aclose()
            self._audio_source = None

        # Clean up APM
        self._apm = None
        self._apm_buffer = b""

        if self._room:
            await self._room.disconnect()
            self._room = None
        self._track = None
        logger.debug("LiveKit voice stopped")

    async def start_recording(self) -> None:
        """Begin streaming audio (PTT mode). Unmutes the audio track.

        The caller (VoiceSession) is responsible for emitting
        client_interrupt before calling this method.
        """
        if not self._active:
            logger.warning("Cannot start recording: voice not active")
            return
        if self._voice_mode == VoiceMode.CONTINUOUS:
            return
        if self._recording:
            return

        self._recording = True
        # No need to emit start_voice — livekit_join already established Deepgram.
        # send_audio() gates on self._recording, so audio starts flowing now.
        logger.debug("LiveKit PTT recording started")

    async def stop_recording(self) -> None:
        """Stop streaming audio (PTT mode). Mutes the audio track.

        After stopping, flushes any remaining APM buffer and sends ~500ms of
        silence to the AudioSource so Deepgram detects end-of-turn reliably.
        """
        if not self._active or not self._recording:
            return
        if self._voice_mode == VoiceMode.CONTINUOUS:
            return

        self._recording = False

        # Flush any remaining APM buffer remnants by padding to a full 10ms chunk
        if self._apm and self._apm_buffer and self._audio_source:
            chunk_size = (self._sample_rate // 100) * 2  # 10ms of PCM16 (bytes)
            pad_len = chunk_size - len(self._apm_buffer)
            if pad_len > 0:
                self._apm_buffer += b"\x00" * pad_len
            processed = self._process_with_apm(self._apm_buffer)
            if processed:
                frame = livekit_rtc.AudioFrame(
                    data=processed,
                    sample_rate=self._sample_rate,
                    num_channels=1,
                    samples_per_channel=len(processed) // 2,
                )
                await self._audio_source.capture_frame(frame)

        # Send silence so Deepgram's VAD detects end-of-turn
        await self._flush_silence()

        logger.debug("LiveKit PTT recording stopped")

    def _process_with_apm(self, audio: bytes) -> bytes:
        """Process outgoing audio through APM in 10ms chunks.

        Buffers partial frames and returns processed bytes (may be empty
        if not enough data has accumulated for a full 10ms chunk).
        """
        chunk_size = (self._sample_rate // 100) * 2  # 10ms of PCM16 (bytes)
        self._apm_buffer += audio
        result = b""
        while len(self._apm_buffer) >= chunk_size:
            chunk = self._apm_buffer[:chunk_size]
            self._apm_buffer = self._apm_buffer[chunk_size:]
            frame = livekit_rtc.AudioFrame(
                data=chunk,
                sample_rate=self._sample_rate,
                num_channels=1,
                samples_per_channel=chunk_size // 2,
            )
            self._apm.process_stream(frame)
            result += bytes(frame.data)
        return result

    def _process_reverse_with_apm(self, audio_data: bytes) -> None:
        """Feed incoming far-end audio through APM reverse stream for echo modelling.

        Processes in 10ms chunks; any trailing bytes that don't fill a
        complete chunk are discarded.
        """
        chunk_size = (self._sample_rate // 100) * 2  # 10ms of PCM16 (bytes)
        offset = 0
        while offset + chunk_size <= len(audio_data):
            chunk = audio_data[offset : offset + chunk_size]
            frame = livekit_rtc.AudioFrame(
                data=chunk,
                sample_rate=self._sample_rate,
                num_channels=1,
                samples_per_channel=chunk_size // 2,
            )
            self._apm.process_reverse_stream(frame)
            offset += chunk_size

    async def _flush_silence(self) -> None:
        """Send ~500ms of silence to AudioSource for Deepgram end-of-turn detection.

        Bypasses the ``_recording`` gate entirely since it writes directly to
        ``_audio_source``.  If APM is active, flushes any remaining buffer and
        processes the silence through APM before sending.
        """
        if not self._audio_source:
            return

        silence_duration = 0.5
        num_samples = int(self._sample_rate * silence_duration)
        silence = b"\x00" * (num_samples * 2)  # PCM16 = 2 bytes/sample

        if self._apm:
            # Flush any remaining APM buffer by padding to a full 10ms chunk
            if self._apm_buffer:
                chunk_size = (self._sample_rate // 100) * 2
                pad_len = chunk_size - len(self._apm_buffer)
                if pad_len > 0:
                    self._apm_buffer += b"\x00" * pad_len
                flushed = self._process_with_apm(self._apm_buffer)
                if flushed:
                    flush_frame = livekit_rtc.AudioFrame(
                        data=flushed,
                        sample_rate=self._sample_rate,
                        num_channels=1,
                        samples_per_channel=len(flushed) // 2,
                    )
                    await self._audio_source.capture_frame(flush_frame)
            # Process silence through APM
            silence = self._process_with_apm(silence)
            if not silence:
                return

        frame = livekit_rtc.AudioFrame(
            data=silence,
            sample_rate=self._sample_rate,
            num_channels=1,
            samples_per_channel=len(silence) // 2,
        )
        await self._audio_source.capture_frame(frame)
        logger.debug(
            "Flushed %ss silence to AudioSource for Deepgram end-of-turn",
            silence_duration,
        )

    async def send_audio(self, audio: bytes) -> None:
        """Send raw PCM16 audio frames to LiveKit.

        Args:
            audio: Raw PCM16 audio bytes (16-bit signed integer, mono).
        """
        if not self._active or self._muted:
            return
        if self._voice_mode == VoiceMode.PUSH_TO_TALK and not self._recording:
            return
        if not self._audio_source:
            return

        # Process through APM if available (echo cancellation, noise suppression, etc.)
        if self._apm:
            audio = self._process_with_apm(audio)
            if not audio:
                return  # Buffered but not enough for a full 10ms chunk yet

        # Convert bytes to AudioFrame
        frame = livekit_rtc.AudioFrame(
            data=audio,
            sample_rate=self._sample_rate,
            num_channels=1,
            samples_per_channel=len(audio) // 2,
        )
        await self._audio_source.capture_frame(frame)

    def toggle_mute(self) -> None:
        """Toggle audio mute state using track-level muting."""
        self._muted = not self._muted
        if self._room and self._track:
            asyncio.ensure_future(
                self._room.local_participant.set_microphone_enabled(not self._muted)
            )
        logger.debug("LiveKit mute toggled: %s", self._muted)

    async def dispose(self) -> None:
        """Clean up LiveKit resources."""
        await self.stop()
