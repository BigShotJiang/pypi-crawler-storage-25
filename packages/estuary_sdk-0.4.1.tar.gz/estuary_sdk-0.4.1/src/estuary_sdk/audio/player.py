from __future__ import annotations

import asyncio
import base64
import logging
import threading
from collections import deque
from typing import Callable

from estuary_sdk.types import BotVoice

logger = logging.getLogger("estuary_sdk")

try:
    import sounddevice as sd

    HAS_AUDIO = True
except (ImportError, OSError):
    HAS_AUDIO = False

import array
import struct


class AudioPlayer:
    """Plays bot voice audio through the speakers.

    Uses a persistent PortAudio output stream with a callback-based pull model
    for gapless playback. Incoming audio is appended to a contiguous byte buffer
    and consumed by the audio callback without reopening the stream per chunk.

    Requires the `audio` optional dependency:
        pip install estuary-sdk[audio]
    """

    # Stop the stream after this many consecutive silent callback invocations.
    _SILENCE_TIMEOUT_FRAMES = 50  # ~1s at blocksize=sample_rate//50

    def __init__(
        self,
        sample_rate: int = 24000,
        on_playback_event: Callable[[str, str | None], None] | None = None,
        volume: float = 1.0,
    ) -> None:
        """
        Args:
            sample_rate: Audio sample rate in Hz.
            on_playback_event: Callback(event, message_id) for "started" / "complete".
            volume: Output volume from 0.0 (silent) to 1.0 (full volume). Default 1.0.
        """
        if not HAS_AUDIO:
            raise ImportError(
                "sounddevice and numpy are required for audio playback. "
                "Install with: pip install estuary-sdk[audio]"
            )
        self._sample_rate = sample_rate
        self._on_event = on_playback_event
        self._volume = max(0.0, min(1.0, volume))

        # Shared state protected by _lock (accessed from asyncio + PortAudio threads)
        self._lock = threading.Lock()
        self._buffer = bytearray()
        self._bytes_written = 0
        self._bytes_consumed = 0
        # Each marker: (byte_offset_after_chunk, message_id, is_final)
        self._markers: deque[tuple[int, str, bool]] = deque()

        self._stream: sd.RawOutputStream | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._silence_frames = 0
        self._current_message_id: str | None = None

    @property
    def volume(self) -> float:
        """Output volume (0.0 to 1.0)."""
        return self._volume

    @volume.setter
    def volume(self, value: float) -> None:
        """Set output volume (0.0 to 1.0). Takes effect immediately."""
        self._volume = max(0.0, min(1.0, value))

    def enqueue(self, voice: BotVoice) -> None:
        """Add a voice chunk to the playback queue."""
        audio_bytes = base64.b64decode(voice.audio)
        if not audio_bytes:
            return

        with self._lock:
            self._buffer.extend(audio_bytes)
            self._bytes_written += len(audio_bytes)
            self._markers.append(
                (self._bytes_written, voice.message_id, voice.is_final)
            )

        self._ensure_stream()

    def clear(self) -> None:
        """Clear the playback buffer and stop the stream immediately."""
        with self._lock:
            self._buffer.clear()
            self._markers.clear()
            self._bytes_written = 0
            self._bytes_consumed = 0
            self._silence_frames = 0
            self._current_message_id = None

        # Stop stream outside lock to avoid holding lock during PortAudio teardown
        self._stop_stream()

    def play_raw(self, audio: bytes) -> None:
        """Play raw PCM16 audio bytes directly (e.g. from LiveKit audio track)."""
        if not audio:
            return
        with self._lock:
            self._buffer.extend(audio)
            self._bytes_written += len(audio)

        self._ensure_stream()

    async def start(self) -> None:
        """Pre-open the output stream in a background thread.

        Call this during session setup so that the first enqueue() or
        play_raw() does not block the event loop with ALSA initialization.
        If not called, _ensure_stream() still works as a synchronous
        fallback (backward-compatible).
        """
        if self._stream is not None:
            return
        await asyncio.to_thread(self._ensure_stream)

    async def dispose(self) -> None:
        """Clean up playback resources."""
        with self._lock:
            self._buffer.clear()
            self._markers.clear()
            self._bytes_written = 0
            self._bytes_consumed = 0
            self._silence_frames = 0
            self._current_message_id = None
        if self._stream is not None:
            await asyncio.to_thread(self._stop_stream)

    # -- Internal -----------------------------------------------------------------

    def _ensure_stream(self) -> None:
        """Start the output stream if it isn't already running."""
        if self._stream is not None:
            return

        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = None

        blocksize = self._sample_rate // 50  # 20ms frames
        self._silence_frames = 0

        self._stream = sd.RawOutputStream(
            samplerate=self._sample_rate,
            channels=1,
            dtype="int16",
            blocksize=blocksize,
            callback=self._audio_callback,
        )
        self._stream.start()
        logger.debug("Audio player stream started (rate=%d)", self._sample_rate)

    def _stop_stream(self) -> None:
        """Abort and close the output stream."""
        stream = self._stream
        self._stream = None
        if stream is not None:
            try:
                stream.abort()
                stream.close()
            except Exception:
                logger.exception("Error closing audio stream")
            logger.debug("Audio player stream stopped")

    def _audio_callback(
        self,
        outdata: memoryview,
        frames: int,
        time_info: object,
        status: object,
    ) -> None:
        """Called by PortAudio from the audio thread — must be fast & non-blocking."""
        needed = frames * 2  # 16-bit mono = 2 bytes per frame
        events_to_fire: list[tuple[str, str | None]] = []

        with self._lock:
            available = len(self._buffer)
            vol = self._volume
            if available >= needed:
                chunk = bytes(self._buffer[:needed])
                del self._buffer[:needed]
                self._bytes_consumed += needed
                self._silence_frames = 0
                outdata[:needed] = self._apply_volume(chunk, vol)
            elif available > 0:
                chunk = bytes(self._buffer[:available])
                self._bytes_consumed += available
                self._buffer.clear()
                self._silence_frames = 0
                outdata[:available] = self._apply_volume(chunk, vol)
                # Zero-fill the remainder
                outdata[available:needed] = b"\x00" * (needed - available)
            else:
                # No data — output silence
                outdata[:needed] = b"\x00" * needed
                self._silence_frames += 1

            # Check markers
            while self._markers and self._markers[0][0] <= self._bytes_consumed:
                _, msg_id, is_final = self._markers.popleft()
                if msg_id != self._current_message_id:
                    if self._current_message_id is not None and self._on_event:
                        events_to_fire.append(("complete", self._current_message_id))
                    self._current_message_id = msg_id
                    if self._on_event:
                        events_to_fire.append(("started", msg_id))
                if is_final and self._on_event:
                    events_to_fire.append(("complete", msg_id))
                    if self._current_message_id == msg_id:
                        self._current_message_id = None

            should_stop = self._silence_frames >= self._SILENCE_TIMEOUT_FRAMES

        # Fire events outside the lock
        if events_to_fire and self._loop is not None:
            for ev_type, ev_id in events_to_fire:
                self._loop.call_soon_threadsafe(self._fire_event, ev_type, ev_id)

        if should_stop:
            # Schedule stream stop in a thread to avoid blocking the event loop
            if self._loop is not None:
                self._loop.call_soon_threadsafe(self._schedule_stop)
            else:
                self._stop_stream()

    def _schedule_stop(self) -> None:
        """Schedule stream stop in a worker thread to avoid blocking the event loop."""
        asyncio.ensure_future(asyncio.to_thread(self._stop_stream))

    @staticmethod
    def _apply_volume(data: bytes, vol: float) -> bytes:
        """Scale PCM16 audio bytes by a volume factor.

        Fast path: returns *data* unchanged when vol == 1.0.
        """
        if vol >= 1.0:
            return data
        if vol <= 0.0:
            return b"\x00" * len(data)
        # Unpack int16 samples, scale, clamp, repack
        n_samples = len(data) // 2
        samples = struct.unpack(f"<{n_samples}h", data[:n_samples * 2])
        scaled = array.array("h", (
            max(-32768, min(32767, int(s * vol))) for s in samples
        ))
        return scaled.tobytes()

    def _fire_event(self, event: str, message_id: str | None) -> None:
        """Dispatch a playback event on the asyncio thread."""
        if self._on_event:
            try:
                self._on_event(event, message_id)
            except Exception:
                logger.exception("Error in playback event handler")
