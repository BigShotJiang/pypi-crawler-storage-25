"""Tests for SocketManager (unit tests without live server)."""

import pytest
from estuary_sdk.connection.socket_manager import SocketManager
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import ConnectionState, EstuaryConfig


@pytest.fixture
def config() -> EstuaryConfig:
    return EstuaryConfig(
        server_url="http://localhost:4001",
        api_key="est_test",
        character_id="char-1",
        player_id="player-1",
        auto_reconnect=False,
    )


class TestSocketManagerInit:
    def test_initial_state(self, config: EstuaryConfig) -> None:
        sm = SocketManager(config)
        assert sm.state == ConnectionState.DISCONNECTED
        assert not sm.is_connected
        assert sm.session is None

    @pytest.mark.asyncio
    async def test_connect_fails_bad_url(self, config: EstuaryConfig) -> None:
        config.server_url = "http://localhost:1"  # Nothing listening
        sm = SocketManager(config)
        with pytest.raises(EstuaryError) as exc_info:
            await sm.connect()
        assert exc_info.value.code == ErrorCode.CONNECTION_FAILED
        assert sm.state == ConnectionState.ERROR

    @pytest.mark.asyncio
    async def test_disconnect_when_not_connected(self, config: EstuaryConfig) -> None:
        sm = SocketManager(config)
        await sm.disconnect()  # Should not raise
        assert sm.state == ConnectionState.DISCONNECTED

    def test_emit_event_when_not_connected(self, config: EstuaryConfig) -> None:
        sm = SocketManager(config)
        # Should log warning but not raise
        sm.emit_event("test", {"data": "value"})
