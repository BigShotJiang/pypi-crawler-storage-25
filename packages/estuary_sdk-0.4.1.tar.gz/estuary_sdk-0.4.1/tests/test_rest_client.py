"""Tests for RestClient HTTP methods."""

from __future__ import annotations

from typing import Any
from unittest.mock import ANY, AsyncMock, MagicMock

import pytest
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.rest.rest_client import RestClient


def _make_response(status: int = 200, json_data: dict[str, Any] | None = None) -> MagicMock:
    """Create a mock aiohttp response with async context manager support."""
    resp = MagicMock()
    resp.status = status
    resp.json = AsyncMock(return_value=json_data or {})
    resp.text = AsyncMock(return_value="error body")
    return resp


def _make_session(response: MagicMock) -> MagicMock:
    """Create a mock aiohttp.ClientSession that returns the given response."""
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=response)
    ctx.__aexit__ = AsyncMock(return_value=False)

    session = MagicMock()
    session.closed = False
    session.request = MagicMock(return_value=ctx)
    return session


class TestRestClientGet:
    @pytest.mark.asyncio
    async def test_get_success(self) -> None:
        resp = _make_response(200, {"key": "value"})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.get("/api/test", params={"q": "hello"})

        assert result == {"key": "value"}
        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"q": "hello"},
            json=None,
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_get_error_raises(self) -> None:
        resp = _make_response(404)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.get("/api/missing")
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientPost:
    @pytest.mark.asyncio
    async def test_post_success(self) -> None:
        resp = _make_response(201, {"id": "new-1"})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.post("/api/items", body={"name": "test"})

        assert result == {"id": "new-1"}
        session.request.assert_called_once_with(
            "POST",
            "http://localhost:4001/api/items",
            params=None,
            json={"name": "test"},
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_post_error_raises(self) -> None:
        resp = _make_response(500)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.post("/api/items", body={})
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientPut:
    @pytest.mark.asyncio
    async def test_put_success(self) -> None:
        resp = _make_response(200, {"id": "1", "updated": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.put("/api/items/1", body={"name": "updated"})

        assert result == {"id": "1", "updated": True}
        session.request.assert_called_once_with(
            "PUT",
            "http://localhost:4001/api/items/1",
            params=None,
            json={"name": "updated"},
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_put_error_raises(self) -> None:
        resp = _make_response(400)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.put("/api/items/1", body={})
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientPatch:
    @pytest.mark.asyncio
    async def test_patch_success(self) -> None:
        resp = _make_response(200, {"id": "1", "name": "patched"})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.patch("/api/items/1", body={"name": "patched"})

        assert result == {"id": "1", "name": "patched"}
        session.request.assert_called_once_with(
            "PATCH",
            "http://localhost:4001/api/items/1",
            params=None,
            json={"name": "patched"},
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_patch_error_raises(self) -> None:
        resp = _make_response(422)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.patch("/api/items/1", body={})
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientDelete:
    @pytest.mark.asyncio
    async def test_delete_success(self) -> None:
        resp = _make_response(200, {"deleted": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.delete("/api/items/1")

        assert result == {"deleted": True}
        session.request.assert_called_once_with(
            "DELETE",
            "http://localhost:4001/api/items/1",
            params=None,
            json=None,
            timeout=ANY,
        )


class TestRestClientParamSanitization:
    @pytest.mark.asyncio
    async def test_sanitizes_bool_true_to_string(self) -> None:
        resp = _make_response(200, {"ok": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"flag": True})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"flag": "true"},
            json=None,
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_sanitizes_bool_false_to_string(self) -> None:
        resp = _make_response(200, {"ok": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"flag": False})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"flag": "false"},
            json=None,
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_non_bool_params_unchanged(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"q": "hello", "limit": 10})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"q": "hello", "limit": 10},
            json=None,
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_mixed_params_converts_only_bools(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"flag": True, "q": "test", "n": 5})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"flag": "true", "q": "test", "n": 5},
            json=None,
            timeout=ANY,
        )

    @pytest.mark.asyncio
    async def test_none_params_pass_through(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params=None)

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params=None,
            json=None,
            timeout=ANY,
        )


class TestRestClientBaseUrl:
    @pytest.mark.asyncio
    async def test_strips_trailing_slash(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001/", "test-key")
        client._session = session

        await client.get("/api/test")

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params=None,
            json=None,
            timeout=ANY,
        )


class TestRestClientRetryLogic:
    """Tests for RetryConfig integration in RestClient._request."""

    @pytest.mark.asyncio
    async def test_retries_on_5xx_then_succeeds(self) -> None:
        """Retry on 503 then succeed on second attempt."""
        from estuary_sdk.types import RetryConfig

        resp_503 = _make_response(503)
        resp_200 = _make_response(200, {"ok": True})

        call_count = 0

        def make_ctx() -> MagicMock:
            nonlocal call_count
            call_count += 1
            ctx = MagicMock()
            if call_count == 1:
                ctx.__aenter__ = AsyncMock(return_value=resp_503)
            else:
                ctx.__aenter__ = AsyncMock(return_value=resp_200)
            ctx.__aexit__ = AsyncMock(return_value=False)
            return ctx

        session = MagicMock()
        session.closed = False
        session.request = MagicMock(side_effect=lambda *a, **kw: make_ctx())

        rc = RetryConfig(max_retries=2, backoff_factor=0.001)
        client = RestClient("http://localhost:4001", "test-key", retry_config=rc)
        client._session = session

        result = await client.get("/api/test")
        assert result == {"ok": True}
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_exhausts_retries_then_raises(self) -> None:
        """All attempts return 500, should raise after max retries."""
        from estuary_sdk.types import RetryConfig

        resp_500 = _make_response(500)
        ctx = MagicMock()
        ctx.__aenter__ = AsyncMock(return_value=resp_500)
        ctx.__aexit__ = AsyncMock(return_value=False)

        session = MagicMock()
        session.closed = False
        session.request = MagicMock(return_value=ctx)

        rc = RetryConfig(max_retries=2, backoff_factor=0.001)
        client = RestClient("http://localhost:4001", "test-key", retry_config=rc)
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.get("/api/test")
        assert exc_info.value.code == ErrorCode.REST_ERROR
        # Should have been called 3 times (1 initial + 2 retries)
        assert session.request.call_count == 3

    @pytest.mark.asyncio
    async def test_no_retry_on_4xx(self) -> None:
        """4xx errors should NOT be retried even with RetryConfig."""
        from estuary_sdk.types import RetryConfig

        resp_404 = _make_response(404)
        ctx = MagicMock()
        ctx.__aenter__ = AsyncMock(return_value=resp_404)
        ctx.__aexit__ = AsyncMock(return_value=False)

        session = MagicMock()
        session.closed = False
        session.request = MagicMock(return_value=ctx)

        rc = RetryConfig(max_retries=3, backoff_factor=0.001)
        client = RestClient("http://localhost:4001", "test-key", retry_config=rc)
        client._session = session

        with pytest.raises(EstuaryError):
            await client.get("/api/test")
        # Should only be called once — no retry for 404
        assert session.request.call_count == 1

    @pytest.mark.asyncio
    async def test_no_retry_without_config(self) -> None:
        """Without RetryConfig, 500 should fail immediately."""
        resp_500 = _make_response(500)
        ctx = MagicMock()
        ctx.__aenter__ = AsyncMock(return_value=resp_500)
        ctx.__aexit__ = AsyncMock(return_value=False)

        session = MagicMock()
        session.closed = False
        session.request = MagicMock(return_value=ctx)

        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError):
            await client.get("/api/test")
        assert session.request.call_count == 1


class TestRestClientTimeout:
    def test_default_timeout(self) -> None:
        client = RestClient("http://localhost:4001", "test-key")
        assert client._timeout == 15.0

    def test_custom_timeout(self) -> None:
        client = RestClient("http://localhost:4001", "test-key", timeout=30.0)
        assert client._timeout == 30.0


class TestRestClientClose:
    @pytest.mark.asyncio
    async def test_close_existing_session(self) -> None:
        client = RestClient("http://localhost:4001", "test-key")
        mock_session = MagicMock()
        mock_session.closed = False
        mock_session.close = AsyncMock()
        client._session = mock_session

        await client.close()
        mock_session.close.assert_called_once()
        assert client._session is None

    @pytest.mark.asyncio
    async def test_close_no_session(self) -> None:
        client = RestClient("http://localhost:4001", "test-key")
        await client.close()  # should not raise

    @pytest.mark.asyncio
    async def test_close_already_closed_session(self) -> None:
        client = RestClient("http://localhost:4001", "test-key")
        mock_session = MagicMock()
        mock_session.closed = True
        client._session = mock_session

        await client.close()  # should not call close again


class TestRestClientGetSession:
    @pytest.mark.asyncio
    async def test_creates_session_on_first_call(self) -> None:
        client = RestClient("http://localhost:4001", "test-key")
        assert client._session is None
        session = client._get_session()
        assert session is not None
        await session.close()

    @pytest.mark.asyncio
    async def test_reuses_open_session(self) -> None:
        client = RestClient("http://localhost:4001", "test-key")
        s1 = client._get_session()
        s2 = client._get_session()
        assert s1 is s2
        await s1.close()
