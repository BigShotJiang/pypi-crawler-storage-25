"""Tests for WebSocketVoiceManager."""

import asyncio

import pytest
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import VoiceMode
from estuary_sdk.voice.websocket_voice import WebSocketVoiceManager
from helpers import FakeSocketManager


def _make_vm(
    sock: FakeSocketManager,
    mode: VoiceMode = VoiceMode.CONTINUOUS,
    start_timeout: float = 1.0,
) -> WebSocketVoiceManager:
    return WebSocketVoiceManager(
        sock, voice_mode=mode, start_timeout=start_timeout  # type: ignore[arg-type]
    )


async def _start_vm(vm: WebSocketVoiceManager, sock: FakeSocketManager) -> None:
    """Start the VM with a background task that simulates voice_started."""

    async def confirm() -> None:
        await asyncio.sleep(0)  # Yield so start() registers listeners
        await sock.simulate_event("voice_started")

    task = asyncio.create_task(confirm())
    await vm.start()
    await task


class TestWebSocketVoiceContinuous:
    @pytest.mark.asyncio
    async def test_start_emits_start_voice(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        await _start_vm(vm, socket)
        assert ("start_voice", None) in socket.emitted
        assert vm.is_active

    @pytest.mark.asyncio
    async def test_stop_emits_stop_voice(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        await _start_vm(vm, socket)
        socket.emitted.clear()
        await vm.stop()
        assert ("stop_voice", None) in socket.emitted
        assert not vm.is_active

    @pytest.mark.asyncio
    async def test_send_audio_base64(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        await _start_vm(vm, socket)
        socket.emitted.clear()
        await vm.send_audio(b"\x01\x02\x03")
        assert len(socket.emitted) == 1
        event, data = socket.emitted[0]
        assert event == "stream_audio"
        assert data == {"audio": "AQID"}  # base64 of \x01\x02\x03

    @pytest.mark.asyncio
    async def test_send_audio_when_muted(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        await _start_vm(vm, socket)
        vm.toggle_mute()
        socket.emitted.clear()
        await vm.send_audio(b"\x01\x02")
        assert len(socket.emitted) == 0

    @pytest.mark.asyncio
    async def test_send_audio_when_not_active(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        await vm.send_audio(b"\x01")
        assert len(socket.emitted) == 0

    @pytest.mark.asyncio
    async def test_start_raises_on_voice_error(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)

        async def send_error() -> None:
            await asyncio.sleep(0)
            await socket.simulate_event("voice_error", "Deepgram init failed")

        task = asyncio.create_task(send_error())
        with pytest.raises(EstuaryError) as exc_info:
            await vm.start()
        await task
        assert exc_info.value.code == ErrorCode.VOICE_START_FAILED
        assert "Deepgram init failed" in str(exc_info.value)
        assert not vm.is_active

    @pytest.mark.asyncio
    async def test_start_raises_on_timeout(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, start_timeout=0.1)
        with pytest.raises(EstuaryError) as exc_info:
            await vm.start()
        assert exc_info.value.code == ErrorCode.VOICE_START_FAILED
        assert "timed out" in str(exc_info.value).lower()
        assert not vm.is_active


class TestWebSocketVoicePTT:
    @pytest.mark.asyncio
    async def test_ptt_flow(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, VoiceMode.PUSH_TO_TALK)
        await _start_vm(vm, socket)
        socket.emitted.clear()

        # Audio should not send before start_recording
        await vm.send_audio(b"\x01")
        assert len(socket.emitted) == 0

        # Start recording
        await vm.start_recording()
        assert ("start_voice", None) in socket.emitted

        # Now audio should send
        socket.emitted.clear()
        await vm.send_audio(b"\x01\x02")
        assert len(socket.emitted) == 1
        assert socket.emitted[0][0] == "stream_audio"

        # Stop recording triggers end-of-turn
        socket.emitted.clear()
        await vm.stop_recording()
        assert ("stop_voice", None) in socket.emitted

    @pytest.mark.asyncio
    async def test_ptt_audio_blocked_after_stop(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, VoiceMode.PUSH_TO_TALK)
        await _start_vm(vm, socket)
        await vm.start_recording()
        await vm.stop_recording()
        socket.emitted.clear()
        await vm.send_audio(b"\x01")
        assert len(socket.emitted) == 0

    @pytest.mark.asyncio
    async def test_toggle_mute(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        assert not vm.is_muted
        vm.toggle_mute()
        assert vm.is_muted
        vm.toggle_mute()
        assert not vm.is_muted

    @pytest.mark.asyncio
    async def test_dispose(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket)
        await _start_vm(vm, socket)
        await vm.dispose()
        assert not vm.is_active
