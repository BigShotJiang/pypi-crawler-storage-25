"""Tests for AsyncEventEmitter."""

import asyncio

import pytest
from estuary_sdk._utils.event_emitter import AsyncEventEmitter


@pytest.fixture
def emitter() -> AsyncEventEmitter:
    return AsyncEventEmitter()


class TestAsyncEventEmitter:
    @pytest.mark.asyncio
    async def test_on_and_emit(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []

        def handler(val: str) -> None:
            results.append(val)

        emitter.on("test", handler)
        await emitter.emit("test", "hello")
        assert results == ["hello"]

    @pytest.mark.asyncio
    async def test_async_handler(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []

        async def handler(val: str) -> None:
            await asyncio.sleep(0)
            results.append(val)

        emitter.on("test", handler)
        await emitter.emit("test", "async_val")
        assert results == ["async_val"]

    @pytest.mark.asyncio
    async def test_off(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []

        def handler(val: str) -> None:
            results.append(val)

        emitter.on("test", handler)
        emitter.off("test", handler)
        await emitter.emit("test", "should_not_appear")
        assert results == []

    @pytest.mark.asyncio
    async def test_once(self, emitter: AsyncEventEmitter) -> None:
        results: list[int] = []

        def handler(val: int) -> None:
            results.append(val)

        emitter.once("test", handler)
        await emitter.emit("test", 1)
        await emitter.emit("test", 2)
        assert results == [1]

    @pytest.mark.asyncio
    async def test_multiple_listeners(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []

        emitter.on("test", lambda v: results.append(f"a:{v}"))
        emitter.on("test", lambda v: results.append(f"b:{v}"))
        await emitter.emit("test", "x")
        assert results == ["a:x", "b:x"]

    @pytest.mark.asyncio
    async def test_remove_all_listeners_specific(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []
        emitter.on("a", lambda: results.append("a"))
        emitter.on("b", lambda: results.append("b"))
        emitter.remove_all_listeners("a")
        await emitter.emit("a")
        await emitter.emit("b")
        assert results == ["b"]

    @pytest.mark.asyncio
    async def test_remove_all_listeners_global(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []
        emitter.on("a", lambda: results.append("a"))
        emitter.on("b", lambda: results.append("b"))
        emitter.remove_all_listeners()
        await emitter.emit("a")
        await emitter.emit("b")
        assert results == []

    @pytest.mark.asyncio
    async def test_emit_no_listeners(self, emitter: AsyncEventEmitter) -> None:
        # Should not raise
        await emitter.emit("nonexistent", "data")

    @pytest.mark.asyncio
    async def test_handler_exception_doesnt_break_others(self, emitter: AsyncEventEmitter) -> None:
        results: list[str] = []

        def bad_handler(v: str) -> None:
            raise ValueError("boom")

        def good_handler(v: str) -> None:
            results.append(v)

        emitter.on("test", bad_handler)
        emitter.on("test", good_handler)
        await emitter.emit("test", "val")
        assert results == ["val"]
