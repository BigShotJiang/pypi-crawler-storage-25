"""Tests for SharesClient."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from estuary_sdk.rest.shares_client import SharesClient


@pytest.fixture
def mock_rest() -> AsyncMock:
    """Mock RestClient with get/post/delete async-mocked and a stub api_key."""
    rest = AsyncMock()
    rest.get = AsyncMock()
    rest.post = AsyncMock()
    rest.delete = AsyncMock()
    rest.api_key = "est_test_key"  # read by SharesClient.create_anchor
    return rest


@pytest.fixture
def client(mock_rest: AsyncMock) -> SharesClient:
    return SharesClient(mock_rest)


# ── Share Anchors ──────────────────────────────────────────


class TestCreateAnchor:
    @pytest.mark.asyncio
    async def test_create_anchor_minimal_injects_bearer_header(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {
            "id": "a" * 32,
            "anchorUrl": "https://share.estuary-ai.com/sa/" + "a" * 32,
        }

        result = await client.create_anchor("char-1")

        assert result["id"] == "a" * 32
        mock_rest.post.assert_awaited_once()
        path = mock_rest.post.call_args[0][0]
        assert path == "/api/v1/share-anchors"
        body = mock_rest.post.call_args[1]["body"]
        assert body["characterId"] == "char-1"
        assert body["memorySharing"] == "isolated"
        assert "maxInteractions" not in body
        # Critical: Bearer header injection (auth workaround for
        # backend _resolve_mixed_auth ignoring X-API-Key).
        headers = mock_rest.post.call_args[1]["headers"]
        assert headers == {"Authorization": "Bearer est_test_key"}

    @pytest.mark.asyncio
    async def test_create_anchor_with_max_interactions(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {"id": "x", "anchorUrl": "..."}

        await client.create_anchor("char-1", max_interactions=50)

        body = mock_rest.post.call_args[1]["body"]
        assert body["maxInteractions"] == 50
        assert body["characterId"] == "char-1"
        assert body["memorySharing"] == "isolated"

    @pytest.mark.asyncio
    async def test_create_anchor_with_shared_memory_sharing(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {"id": "x", "anchorUrl": "..."}

        await client.create_anchor("char-2", memory_sharing="shared")

        body = mock_rest.post.call_args[1]["body"]
        assert body["memorySharing"] == "shared"
        assert "maxInteractions" not in body


class TestOpenAnchor:
    @pytest.mark.asyncio
    async def test_open_anchor(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {
            "sessionToken": "sst_" + "x" * 60,
            "characterId": "char-1",
            "playerId": "anchor:12345678:abc",
            "serverUrl": "https://api.estuary-ai.com",
            "character": {"id": "char-1", "name": "Bot"},
            "memorySharing": "isolated",
        }

        result = await client.open_anchor("anc-123")

        assert result["sessionToken"].startswith("sst_")
        mock_rest.post.assert_awaited_once_with(
            "/api/v1/share-anchors/anc-123/open"
        )


class TestListAnchors:
    @pytest.mark.asyncio
    async def test_list_anchors_no_filter(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.get.return_value = {"anchors": []}

        result = await client.list_anchors()

        assert result == {"anchors": []}
        mock_rest.get.assert_awaited_once()
        path = mock_rest.get.call_args[0][0]
        assert path == "/api/v1/share-anchors"
        assert mock_rest.get.call_args[1]["params"] is None

    @pytest.mark.asyncio
    async def test_list_anchors_with_character_filter(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.get.return_value = {"anchors": [{"id": "a1"}]}

        result = await client.list_anchors(character_id="char-1")

        assert result["anchors"][0]["id"] == "a1"
        path = mock_rest.get.call_args[0][0]
        assert path == "/api/v1/share-anchors"
        assert mock_rest.get.call_args[1]["params"] == {"character_id": "char-1"}


class TestRevokeAnchor:
    @pytest.mark.asyncio
    async def test_revoke_anchor(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.delete.return_value = {
            "revoked": True,
            "killedSessions": 2,
            "removedSessionBlobs": 2,
        }

        result = await client.revoke_anchor("anc-123")

        assert result["revoked"] is True
        mock_rest.delete.assert_awaited_once_with(
            "/api/v1/share-anchors/anc-123"
        )


class TestBulkRevokeAnchorsByApiKey:
    @pytest.mark.asyncio
    async def test_bulk_revoke(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.delete.return_value = {
            "revoked": 5,
            "killedSessions": 7,
            "removedSessionBlobs": 7,
        }

        api_key_id = "11111111-2222-3333-4444-555555555555"
        result = await client.bulk_revoke_anchors_by_api_key(api_key_id)

        assert result["revoked"] == 5
        mock_rest.delete.assert_awaited_once_with(
            f"/api/v1/share-anchors/by-api-key/{api_key_id}"
        )


# ── Share Tokens ───────────────────────────────────────────


class TestCreateShareToken:
    @pytest.mark.asyncio
    async def test_create_share_token_defaults(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {
            "token": "tok-abc",
            "shareUrl": "https://share.estuary-ai.com/?share=tok-abc",
            "expiresAt": "2026-04-22T00:00:00Z",
        }

        result = await client.create_share_token("char-1")

        assert result["token"] == "tok-abc"
        path = mock_rest.post.call_args[0][0]
        assert path == "/api/v1/share"
        body = mock_rest.post.call_args[1]["body"]
        assert body == {
            "characterId": "char-1",
            "ttl": "7d",
            "memorySharing": "isolated",
            "maxExchanges": 5,
        }

    @pytest.mark.asyncio
    async def test_create_share_token_custom(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {
            "token": "tok",
            "shareUrl": "...",
            "expiresAt": "...",
        }

        await client.create_share_token(
            "char-2",
            ttl="24h",
            memory_sharing="shared",
            max_exchanges=10,
        )

        body = mock_rest.post.call_args[1]["body"]
        assert body["ttl"] == "24h"
        assert body["memorySharing"] == "shared"
        assert body["maxExchanges"] == 10


class TestExchangeShareToken:
    @pytest.mark.asyncio
    async def test_exchange_without_recipient(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {
            "sessionToken": "sst_xyz",
            "characterId": "char-1",
            "playerId": "share:12345678:hash",
            "serverUrl": "https://api.estuary-ai.com",
            "character": {"id": "char-1", "name": "Bot"},
        }

        result = await client.exchange_share_token("tok-abc")

        assert result["sessionToken"] == "sst_xyz"
        path = mock_rest.post.call_args[0][0]
        assert path == "/api/v1/share/tok-abc/exchange"
        body = mock_rest.post.call_args[1]["body"]
        assert body == {}

    @pytest.mark.asyncio
    async def test_exchange_with_recipient(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = {"sessionToken": "sst_xyz"}

        await client.exchange_share_token("tok-abc", recipient_id="rcp-1")

        path = mock_rest.post.call_args[0][0]
        assert path == "/api/v1/share/tok-abc/exchange"
        body = mock_rest.post.call_args[1]["body"]
        assert body == {"recipientId": "rcp-1"}


class TestListCharacterShares:
    @pytest.mark.asyncio
    async def test_list_character_shares(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.get.return_value = {"shares": [{"id": "s1"}]}

        result = await client.list_character_shares("char-1")

        assert result["shares"][0]["id"] == "s1"
        mock_rest.get.assert_awaited_once_with(
            "/api/v1/share/character/char-1"
        )


class TestRevokeShareToken:
    @pytest.mark.asyncio
    async def test_revoke_share_token_injects_bearer_header(
        self, client: SharesClient, mock_rest: AsyncMock
    ) -> None:
        """After quick-260416-mc0, ``revoke_share_token`` is mixed-auth
        (API key or Firebase) and MUST inject the ``Authorization:
        Bearer {api_key}`` header per-request — mirroring ``create_share``
        — because the backend's ``_resolve_mixed_auth`` only reads
        the Bearer header, not the session-default ``X-API-Key``.
        """
        mock_rest.delete.return_value = {
            "revoked": True,
            "killedSessions": 1,
            "removedSessionBlobs": 1,
        }

        result = await client.revoke_share_token("share-row-1")

        assert result["revoked"] is True
        mock_rest.delete.assert_awaited_once()
        path = mock_rest.delete.call_args[0][0]
        assert path == "/api/v1/share/share-row-1"
        # Critical: Bearer header injection (auth workaround).
        headers = mock_rest.delete.call_args[1]["headers"]
        assert headers == {"Authorization": "Bearer est_test_key"}
