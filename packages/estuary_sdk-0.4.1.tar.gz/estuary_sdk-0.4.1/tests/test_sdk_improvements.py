"""Tests for the 6 SDK improvements:

1. send_text_and_wait()
2. RetryConfig + REST timeout/retry
3. Agent-to-agent types and methods
4. wait_for_model()
5. AudioRecorder resilience (device fallback, drain)
6. VoiceSession
"""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from estuary_sdk import EstuaryClient, EstuaryConfig
from estuary_sdk.types import (
    AgentConversationComplete,
    AgentTurnComplete,
    AgentTurnText,
    AgentTurnVoice,
    BotResponse,
    ConnectionState,
    ModelStatus,
    RetryConfig,
    VoiceMode,
)


@pytest.fixture
def config() -> EstuaryConfig:
    return EstuaryConfig(
        server_url="http://localhost:4001",
        api_key="est_test_key",
        character_id="test-char-id",
        player_id="test-player",
    )


def _make_connected_client(config: EstuaryConfig) -> EstuaryClient:
    """Create an EstuaryClient and pretend it is connected."""
    client = EstuaryClient(config)
    client._socket._state = ConnectionState.CONNECTED
    client._socket.emit_event = MagicMock()
    return client


# ---------------------------------------------------------------------------
# 1. send_text_and_wait
# ---------------------------------------------------------------------------


class TestSendTextAndWait:
    @pytest.mark.asyncio
    async def test_returns_final_bot_response(self, config: EstuaryConfig) -> None:
        """send_text_and_wait returns a BotResponse when is_final=True."""
        client = _make_connected_client(config)

        async def simulate_response() -> None:
            await asyncio.sleep(0.05)
            response = BotResponse(
                text="Hello there!", is_final=True, message_id="msg-1"
            )
            await client.emit("bot_response", response)

        task = asyncio.create_task(simulate_response())
        result = await client.send_text_and_wait("hello", timeout=5.0)
        await task
        assert result.text == "Hello there!"
        assert result.is_final is True

    @pytest.mark.asyncio
    async def test_timeout_raises(self, config: EstuaryConfig) -> None:
        """send_text_and_wait raises TimeoutError if no final response."""
        client = _make_connected_client(config)

        with pytest.raises(asyncio.TimeoutError):
            await client.send_text_and_wait("hello", timeout=0.1)

    @pytest.mark.asyncio
    async def test_text_only_flag(self, config: EstuaryConfig) -> None:
        """send_text_and_wait with text_only=True sends textOnly in payload."""
        client = _make_connected_client(config)

        async def simulate_response() -> None:
            await asyncio.sleep(0.05)
            response = BotResponse(text="Hi!", is_final=True, message_id="msg-2")
            await client.emit("bot_response", response)

        task = asyncio.create_task(simulate_response())
        result = await client.send_text_and_wait("hello", text_only=True, timeout=5.0)
        await task

        # Verify textOnly was set in the emit
        emit_calls = client._socket.emit_event.call_args_list
        assert len(emit_calls) >= 1
        event_name, payload = emit_calls[0][0]
        assert event_name == "text"
        assert payload.get("textOnly") is True


# ---------------------------------------------------------------------------
# 2. RetryConfig + REST timeout/retry
# ---------------------------------------------------------------------------


class TestRetryConfig:
    def test_dataclass_defaults(self) -> None:
        rc = RetryConfig()
        assert rc.max_retries == 3
        assert rc.backoff_factor == 1.0
        assert rc.retry_on_status == (500, 502, 503, 504)

    def test_custom_values(self) -> None:
        rc = RetryConfig(max_retries=5, backoff_factor=0.5, retry_on_status=(503,))
        assert rc.max_retries == 5
        assert rc.backoff_factor == 0.5
        assert rc.retry_on_status == (503,)

    @pytest.mark.asyncio
    async def test_rest_client_timeout(self) -> None:
        """RestClient._request uses configurable timeout."""
        from estuary_sdk.rest.rest_client import RestClient

        client = RestClient("http://localhost:9999", "key", timeout=0.001)
        # Should timeout almost immediately since nothing is listening
        with pytest.raises(Exception):
            await client.get("/nonexistent")
        await client.close()

    @pytest.mark.asyncio
    async def test_rest_client_retry_config(self) -> None:
        """RestClient with RetryConfig retries on 5xx errors."""
        from estuary_sdk.rest.rest_client import RestClient

        rc = RetryConfig(max_retries=2, backoff_factor=0.01)
        client = RestClient("http://localhost:9999", "key", retry_config=rc)
        # Should attempt request multiple times then fail
        with pytest.raises(Exception):
            await client.get("/nonexistent")
        await client.close()


# ---------------------------------------------------------------------------
# 3. Agent-to-agent types
# ---------------------------------------------------------------------------


class TestAgentToAgentTypes:
    def test_agent_turn_text_from_dict(self) -> None:
        data = {
            "agent_id": "agent-1",
            "text": "I attack!",
            "chunk_index": 2,
            "turn_number": 3,
            "is_final": True,
        }
        result = AgentTurnText.from_dict(data)
        assert result.agent_id == "agent-1"
        assert result.text == "I attack!"
        assert result.chunk_index == 2
        assert result.turn_number == 3
        assert result.is_final is True

    def test_agent_turn_voice_from_dict(self) -> None:
        data = {
            "agent_id": "agent-2",
            "audio": "base64data==",
            "chunk_index": 0,
            "turn_number": 1,
            "is_final": False,
        }
        result = AgentTurnVoice.from_dict(data)
        assert result.agent_id == "agent-2"
        assert result.audio == "base64data=="
        assert result.chunk_index == 0
        assert result.turn_number == 1
        assert result.is_final is False

    def test_agent_turn_complete_from_dict(self) -> None:
        data = {"agent_id": "agent-1", "text": "Full turn text", "turn_number": 5}
        result = AgentTurnComplete.from_dict(data)
        assert result.agent_id == "agent-1"
        assert result.text == "Full turn text"
        assert result.turn_number == 5

    def test_agent_conversation_complete_from_dict(self) -> None:
        data = {
            "winner_agent_id": "agent-2",
            "reason": "Knockout",
            "total_turns": 8,
        }
        result = AgentConversationComplete.from_dict(data)
        assert result.winner_agent_id == "agent-2"
        assert result.reason == "Knockout"
        assert result.total_turns == 8

    def test_from_dict_defaults(self) -> None:
        result = AgentTurnText.from_dict({})
        assert result.agent_id == ""
        assert result.text == ""
        assert result.chunk_index == 0
        assert result.turn_number == 0
        assert result.is_final is False


# ---------------------------------------------------------------------------
# 3b. Agent-to-agent client methods
# ---------------------------------------------------------------------------


class TestAgentToAgentMethods:
    def test_start_agent_conversation_emits_event(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)

        client.start_agent_conversation(
            agent_a_id="agent-A",
            agent_b_id="agent-B",
            conversation_context="Battle!",
            max_turns=10,
            timeout_seconds=120,
        )

        client._socket.emit_event.assert_called_once()
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "start_agent_conversation"
        assert payload["agent_a_id"] == "agent-A"
        assert payload["agent_b_id"] == "agent-B"
        assert payload["conversation_context"] == "Battle!"
        assert payload["max_turns"] == 10
        assert payload["timeout_seconds"] == 120

    def test_stop_agent_conversation_emits_event(self, config: EstuaryConfig) -> None:
        client = _make_connected_client(config)

        client.stop_agent_conversation()

        client._socket.emit_event.assert_called_once()
        event, payload = client._socket.emit_event.call_args[0]
        assert event == "stop_agent_conversation"
        assert payload == {}


# ---------------------------------------------------------------------------
# 4. wait_for_model
# ---------------------------------------------------------------------------


class TestWaitForModel:
    @pytest.mark.asyncio
    async def test_poll_completes_on_completed_status(self) -> None:
        from estuary_sdk.rest.generate_client import GenerateClient

        mock_rest = MagicMock()
        gen = GenerateClient(mock_rest, "player-1")

        # First call returns pending, second returns completed
        gen.get_model_status = AsyncMock(
            side_effect=[
                ModelStatus(model_status="pending", progress=50),
                ModelStatus(model_status="completed", progress=100, model_url="http://model.glb"),
            ]
        )

        result = await gen.wait_for_model("agent-1", poll_interval=0.01, timeout=5.0)
        assert result.model_status == "completed"
        assert result.model_url == "http://model.glb"

    @pytest.mark.asyncio
    async def test_timeout_raises(self) -> None:
        from estuary_sdk.rest.generate_client import GenerateClient

        mock_rest = MagicMock()
        gen = GenerateClient(mock_rest, "player-1")

        gen.get_model_status = AsyncMock(
            return_value=ModelStatus(model_status="pending", progress=10)
        )

        with pytest.raises(asyncio.TimeoutError):
            await gen.wait_for_model("agent-1", poll_interval=0.01, timeout=0.05)

    @pytest.mark.asyncio
    async def test_on_progress_callback(self) -> None:
        from estuary_sdk.rest.generate_client import GenerateClient

        mock_rest = MagicMock()
        gen = GenerateClient(mock_rest, "player-1")

        progress_calls: list[ModelStatus] = []

        gen.get_model_status = AsyncMock(
            side_effect=[
                ModelStatus(model_status="pending", progress=30),
                ModelStatus(model_status="completed", progress=100),
            ]
        )

        await gen.wait_for_model(
            "agent-1",
            poll_interval=0.01,
            timeout=5.0,
            on_progress=lambda ms: progress_calls.append(ms),
        )

        assert len(progress_calls) == 2
        assert progress_calls[0].progress == 30
        assert progress_calls[1].progress == 100

    @pytest.mark.asyncio
    async def test_failed_status_returns_immediately(self) -> None:
        from estuary_sdk.rest.generate_client import GenerateClient

        mock_rest = MagicMock()
        gen = GenerateClient(mock_rest, "player-1")

        gen.get_model_status = AsyncMock(
            return_value=ModelStatus(model_status="failed", progress=0)
        )

        result = await gen.wait_for_model("agent-1", poll_interval=0.01, timeout=5.0)
        assert result.model_status == "failed"


# ---------------------------------------------------------------------------
# 5. AudioRecorder resilience (device fallback, drain)
# ---------------------------------------------------------------------------


class TestAudioRecorderResilience:
    """Tests for AudioRecorder device fallback and drain().

    These tests mock sounddevice to avoid PortAudio dependency.
    """

    def _make_recorder(self) -> Any:
        """Create an AudioRecorder instance with mocked sounddevice."""
        import importlib
        import threading

        import estuary_sdk.audio.recorder as mod

        # Save originals
        orig_has = mod.HAS_AUDIO

        # Patch
        mod.HAS_AUDIO = True
        mock_sd = MagicMock()
        mod.sd = mock_sd  # type: ignore[attr-defined]

        recorder = mod.AudioRecorder.__new__(mod.AudioRecorder)
        recorder._target_rate = 16000
        recorder._device_rate = 16000
        recorder._on_audio = None
        recorder._stream = None
        recorder._recording = False
        recorder._loop = None
        recorder._in_flight_count = 0
        recorder._in_flight_lock = threading.Lock()
        recorder._drain_event = None

        # Return recorder and cleanup function
        def cleanup() -> None:
            mod.HAS_AUDIO = orig_has

        return recorder, mock_sd, cleanup

    @pytest.mark.asyncio
    async def test_drain_method_exists(self) -> None:
        """AudioRecorder has a drain() method."""
        import estuary_sdk.audio.recorder as mod

        assert hasattr(mod.AudioRecorder, "drain")

    @pytest.mark.asyncio
    async def test_drain_stops_recording(self) -> None:
        """drain() sets _recording to False and cleans up."""
        recorder, _, cleanup = self._make_recorder()
        try:
            recorder._recording = True
            recorder._loop = asyncio.get_event_loop()
            await recorder.drain(timeout=0.1)
            assert recorder._recording is False
        finally:
            cleanup()

    @pytest.mark.asyncio
    async def test_device_fallback_candidates(self) -> None:
        """AudioRecorder._candidate_input_devices returns a list of candidates."""
        recorder, mock_sd, cleanup = self._make_recorder()
        try:
            mock_sd.default.device = (0, 1)
            mock_sd.query_devices.return_value = [
                {"name": "Mic1", "max_input_channels": 2},
                {"name": "Speakers", "max_input_channels": 0},
            ]
            candidates = recorder._candidate_input_devices()
            assert None in candidates  # always includes None (system default)
        finally:
            cleanup()


# ---------------------------------------------------------------------------
# 6. VoiceSession
# ---------------------------------------------------------------------------


class TestVoiceSession:
    def test_init(self, config: EstuaryConfig) -> None:
        """VoiceSession can be instantiated."""
        from estuary_sdk.voice.voice_session import VoiceSession

        client = EstuaryClient(config)
        session = VoiceSession(client, mode=VoiceMode.PUSH_TO_TALK)
        assert session._started is False
        assert session._client is client

    def test_async_context_manager_protocol(self) -> None:
        """VoiceSession has __aenter__ and __aexit__."""
        from estuary_sdk.voice.voice_session import VoiceSession

        assert hasattr(VoiceSession, "__aenter__")
        assert hasattr(VoiceSession, "__aexit__")

    @pytest.mark.asyncio
    async def test_voice_session_mode(self, config: EstuaryConfig) -> None:
        """VoiceSession stores the requested mode."""
        from estuary_sdk.voice.voice_session import VoiceSession

        client = EstuaryClient(config)
        session = VoiceSession(client, mode=VoiceMode.CONTINUOUS)
        assert session._mode == VoiceMode.CONTINUOUS

    @pytest.mark.asyncio
    async def test_stop_before_start_is_safe(self, config: EstuaryConfig) -> None:
        """stop() before start() does not raise."""
        from estuary_sdk.voice.voice_session import VoiceSession

        client = EstuaryClient(config)
        session = VoiceSession(client, mode=VoiceMode.PUSH_TO_TALK)
        await session.stop()  # should not raise
