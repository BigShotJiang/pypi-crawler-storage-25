"""Example Tier 1 ability -- simplest possible. No Phoenix knowledge needed."""

import uuid

from phoenix.abilities import ability


@ability(name="uuid_gen", description="Generate a random UUID")
def uuid_gen() -> str:
    """Generate a random UUID v4 string."""
    return str(uuid.uuid4())
