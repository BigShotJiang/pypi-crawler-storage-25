"""Example Tier 2 ability -- stateful tool with SQLite backend.

This demonstrates how a community contributor would build a database-backed
ability. The interceptor handles approval for destructive operations externally.
"""

import os
import sqlite3
import time

from phoenix.abilities import ability

_DB_PATH = os.path.expanduser("~/.phoenix/todo.db")


def _get_conn() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            status TEXT DEFAULT 'todo',
            priority TEXT DEFAULT 'medium',
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            completed_at TEXT
        )
    """)
    conn.commit()
    return conn


@ability(name="todo", description="Manage tasks -- add, list, complete, remove")
def todo(action: str, args: str = "") -> str:
    """Task management with local SQLite storage.

    Args:
        action: One of: add, list, done, remove, clear_done
        args: Task title (for add), task ID (for done/remove)
    """
    conn = _get_conn()

    if action == "add":
        if not args:
            return "Error: provide a task title"
        conn.execute("INSERT INTO tasks (title) VALUES (?)", (args,))
        conn.commit()
        return f"Added: {args}"

    if action == "list":
        rows = conn.execute(
            "SELECT id, title, status, priority, created_at FROM tasks "
            "WHERE status != 'done' ORDER BY id"
        ).fetchall()
        if not rows:
            return "No active tasks."
        lines = []
        for r in rows:
            lines.append(f"  #{r['id']} [{r['status']}] {r['title']} ({r['priority']})")
        return "\n".join(lines)

    if action == "done":
        if not args:
            return "Error: provide task ID"
        conn.execute(
            "UPDATE tasks SET status = 'done', completed_at = datetime('now', 'localtime') "
            "WHERE id = ?", (int(args),)
        )
        conn.commit()
        return f"Marked #{args} as done."

    if action == "remove":
        if not args:
            return "Error: provide task ID"
        conn.execute("DELETE FROM tasks WHERE id = ?", (int(args),))
        conn.commit()
        return f"Removed #{args}."

    if action == "clear_done":
        conn.execute("DELETE FROM tasks WHERE status = 'done'")
        conn.commit()
        return "Cleared completed tasks."

    return f"Unknown action: {action}. Use: add, list, done, remove, clear_done"
