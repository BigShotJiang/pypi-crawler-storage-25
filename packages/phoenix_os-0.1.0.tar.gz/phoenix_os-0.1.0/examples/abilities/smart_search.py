"""Example Tier 3 ability -- uses PhoenixContext for memory access.

This demonstrates how an ability can leverage Phoenix internals (memory, config)
by declaring ctx: PhoenixContext as a parameter. The registry detects this at
registration time and injects the context at call time.
"""

import subprocess

from phoenix.abilities import ability, PhoenixContext


@ability(name="smart_search", description="Search codebase informed by memory context")
async def smart_search(ctx: PhoenixContext, query: str, path: str = ".") -> str:
    """Search codebase using grep, enhanced with memory context.

    First checks memory for relevant context about the query topic,
    then uses that to refine the search pattern.

    Args:
        query: What to search for.
        path: Directory to search in. Defaults to current directory.
    """
    # Get memory context (what Phoenix remembers about this topic)
    memory_hint = ""
    if ctx.memory:
        try:
            memories = ctx.memory.pre_turn(query)
            if memories:
                memory_hint = f" (memory context: {memories[:200]})"
                ctx.log(f"smart_search: found memory context for '{query}'")
        except Exception:
            pass

    # Run the actual grep
    try:
        result = subprocess.run(
            ["grep", "-r", "-n", "-i", "--include=*.py", query, path],
            capture_output=True, text=True, timeout=30,
        )
        output = result.stdout.strip()
        if not output:
            return f"No results for '{query}' in {path}.{memory_hint}"

        lines = output.splitlines()[:20]
        header = f"[{len(lines)} matches for '{query}']"
        if memory_hint:
            header += memory_hint
        return header + "\n" + "\n".join(lines)

    except subprocess.TimeoutExpired:
        return "Search timed out."
    except Exception as e:
        return f"Search error: {e}"
