"""Tests for personality/parser.py."""

from pathlib import Path

from phoenix.personality.parser import (
    AgentConfig,
    build_agent_prompt,
    build_system_prompt,
    load_defaults,
    merge_config,
    parse_agent,
)


def test_load_defaults():
    defaults = load_defaults()
    assert defaults.identity.name == "Phoenix"
    assert len(defaults.rules) > 0


def test_parse_brain_agent():
    agents_dir = Path(__file__).parent.parent / "phoenix" / "personality" / "agents"
    config = parse_agent(agents_dir / "brain.yaml")
    assert config.name == "brain"
    assert len(config.rules) > 0
    assert "ask_user" in config.abilities


def test_parse_worker_agent():
    agents_dir = Path(__file__).parent.parent / "phoenix" / "personality" / "agents"
    config = parse_agent(agents_dir / "worker.yaml")
    assert config.name == "worker"
    assert "bash" in config.abilities
    assert "claude_code" in config.abilities
    assert config.behaviors.delegation is False


def test_merge_config_fills_defaults():
    defaults = load_defaults()
    agent = AgentConfig(name="test")
    merged = merge_config(defaults, agent)
    assert len(merged.rules) > 0
    assert len(merged.tone) > 0


def test_merge_config_preserves_overrides():
    defaults = load_defaults()
    agent = AgentConfig(
        name="test",
        tone=["sharp", "terse"],
        rules=["custom rule"],
    )
    merged = merge_config(defaults, agent)
    assert "sharp" in merged.tone
    assert "custom rule" in merged.rules


def test_build_system_prompt():
    config = AgentConfig(
        name="test",
        role="Test agent",
        tone=["direct"],
        rules=["Be concise"],
    )
    prompt = build_system_prompt(config)
    assert "Phoenix" in prompt
    assert "Test agent" in prompt
    assert "Be concise" in prompt
    assert "direct" in prompt


def test_build_agent_prompt():
    prompt = build_agent_prompt("brain")
    assert "Phoenix" in prompt
    assert len(prompt) > 100


def test_build_agent_prompt_nonexistent():
    try:
        build_agent_prompt("nonexistent_agent_xyz")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass
