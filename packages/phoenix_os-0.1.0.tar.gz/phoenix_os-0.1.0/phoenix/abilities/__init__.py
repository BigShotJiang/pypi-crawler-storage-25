"""Abilities framework -- @ability decorator, registry, and PhoenixContext."""

import inspect
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass
class AbilityInfo:
    name: str
    description: str
    func: Callable
    is_async: bool
    needs_context: bool


@dataclass
class PhoenixContext:
    """Injected into abilities that declare a ctx: PhoenixContext parameter."""

    config: dict = field(default_factory=dict)
    memory: Any = None
    log: Callable = field(default_factory=lambda: print)
    agent_name: str = ""
    work_dir: Path = field(default_factory=Path.cwd)


_ABILITY_REGISTRY: dict[str, AbilityInfo] = {}


def ability(name: str, description: str):
    """Register a function as a Phoenix ability.

    The decorator stores metadata and returns the function unchanged.
    Pydantic-ai reads function signatures and docstrings natively.

    Usage:
        @ability(name="bash", description="Execute shell commands")
        async def bash(command: str) -> str:
            ...
    """

    def decorator(func: Callable) -> Callable:
        sig = inspect.signature(func)
        needs_ctx = any(
            p.annotation is PhoenixContext or p.annotation == "PhoenixContext"
            for p in sig.parameters.values()
        )

        _ABILITY_REGISTRY[name] = AbilityInfo(
            name=name,
            description=description,
            func=func,
            is_async=inspect.iscoroutinefunction(func),
            needs_context=needs_ctx,
        )
        return func

    return decorator


def get_ability_registry() -> dict[str, AbilityInfo]:
    return _ABILITY_REGISTRY
