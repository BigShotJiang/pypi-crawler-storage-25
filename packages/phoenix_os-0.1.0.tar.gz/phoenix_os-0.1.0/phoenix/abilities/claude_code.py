"""Claude Code CLI integration -- delegates coding tasks to Claude Code."""

import asyncio
import json
import os
import shutil
import time

from phoenix.abilities import ability


def _find_claude() -> str | None:
    return shutil.which("claude")


@ability(name="claude_code", description="Delegate complex coding tasks to Claude Code CLI")
async def claude_code(prompt: str, workdir: str = "") -> str:
    """Delegate a coding task to Claude Code CLI with full codebase context.

    Use this for substantial coding work: generating files, editing code,
    refactoring, debugging, building projects. Give a detailed prompt
    describing exactly what you want built/fixed/changed.

    Args:
        prompt: Detailed task description for Claude Code.
        workdir: Working directory. Defaults to current directory.
    """
    claude_bin = _find_claude()
    if not claude_bin:
        return (
            "Error: 'claude' CLI not found. Install with: npm install -g @anthropic-ai/claude-code"
        )

    from phoenix.core.interceptor import get_approval_backend

    backend = get_approval_backend()
    first_line = prompt.strip().splitlines()[0][:100]
    approved = await backend.request_approval(
        "claude_code",
        f"Run Claude Code: {first_line}",
        {"prompt": prompt.strip(), "workdir": workdir or os.getcwd()},
    )
    if not approved:
        return "Cancelled by user."

    cwd = workdir or os.getcwd()
    cmd = [
        claude_bin,
        "-p",
        "--output-format",
        "json",
        "--dangerously-skip-permissions",
        "--max-turns",
        "25",
        prompt,
    ]

    preview = prompt.strip().splitlines()[0][:80]
    print("  \033[36mClaude Code running...\033[0m", flush=True)
    print(f"  \033[2m  cwd: {cwd}\033[0m", flush=True)
    print(f"  \033[2m  prompt: {preview}...\033[0m", flush=True)

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
            start_new_session=True,
        )

        start_time = time.time()

        async def _spin():
            chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
            i = 0
            while True:
                elapsed = int(time.time() - start_time)
                mins, secs = divmod(elapsed, 60)
                ts = f"{mins}:{secs:02d}" if mins else f"{secs}s"
                print(
                    f"\r  \033[2m{chars[i % len(chars)]} working... [{ts}]\033[0m",
                    end="",
                    flush=True,
                )
                i += 1
                await asyncio.sleep(0.5)

        spinner = asyncio.create_task(_spin())
        try:
            stdout, stderr = await proc.communicate()
        finally:
            spinner.cancel()
            elapsed = int(time.time() - start_time)
            mins, secs = divmod(elapsed, 60)
            ts = f"{mins}m{secs}s" if mins else f"{secs}s"
            print("\r\033[K", end="", flush=True)

        output = stdout.decode("utf-8", errors="replace").strip()
        err_output = stderr.decode("utf-8", errors="replace").strip()

        if not output and proc.returncode != 0:
            return f"Error: Claude Code exited with code {proc.returncode}. {err_output}"

        try:
            data = json.loads(output)
            result_text = data.get("result", "")
            session_id = data.get("session_id", "")
            cost = data.get("cost_usd", "")

            meta = []
            if session_id:
                meta.append(f"session: {session_id}")
            if cost:
                meta.append(f"cost: ${cost}")
            meta.append(ts)
            print(f"  \033[2mClaude Code done [{', '.join(meta)}]\033[0m", flush=True)

            return result_text or output
        except json.JSONDecodeError:
            print(f"  \033[2mClaude Code done [{ts}]\033[0m", flush=True)
            return output or f"(no output, exit code {proc.returncode})"

    except FileNotFoundError:
        return "Error: 'claude' binary not found"
    except Exception as e:
        return f"Error running Claude Code: {e}"
