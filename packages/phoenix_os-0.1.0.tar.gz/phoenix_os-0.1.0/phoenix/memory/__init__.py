"""Phoenix Memory System -- persistent episodic memory.

MemorySystem is the main orchestrator. It hooks into the conversation loop
via pre_turn() and post_turn(), managing extraction, gating, storage,
recall, feedback, decay, and consolidation automatically.
"""

import hashlib
import logging
import time

from .classifier import build_classifiers
from .config import CATEGORY_IMPORTANCE, MemoryParams
from .consolidation import ConsolidationEngine
from .embeddings import EmbeddingService
from .extractor import extract_facts
from .gate import NoveltyGate, is_self_identity
from .recall import RecallEngine
from .store import MemoryStore

log = logging.getLogger(__name__)


class MemorySystem:
    """Orchestrates the full memory pipeline. Injected into engine, not a global."""

    def __init__(self, config: MemoryParams | None = None):
        self.config = config or MemoryParams()
        self.embedder = EmbeddingService(self.config)
        self.store = MemoryStore(self.config)
        self._gate: NoveltyGate | None = None
        self._recall: RecallEngine | None = None
        self._consolidation: ConsolidationEngine | None = None
        self._cat_clf = None
        self._dim_clf = None
        self._intent_clf = None
        self._turn_count = 0
        self._last_fingerprint: str = ""
        self._last_fingerprint_time: float = 0.0

    def _ensure_initialized(self):
        """Lazy-init classifiers and engines on first use."""
        if self._cat_clf is not None:
            return
        self._cat_clf, self._dim_clf, self._intent_clf = build_classifiers(
            self.config, self.embedder.embed
        )
        self._gate = NoveltyGate(self.config, self.embedder, self.store)
        self._recall = RecallEngine(self.config, self.embedder, self.store)
        self._consolidation = ConsolidationEngine(self.config, self.embedder, self.store)
        log.info("Memory system initialized (db: %s)", self.config.db_path)

    def pre_turn(self, user_input: str, namespace: str = "global") -> str:
        """Called before the AI responds. Recalls relevant memories."""
        self._ensure_initialized()

        if len(user_input.strip()) < 10:
            return ""

        self._recall.update_context(user_input)
        memories = self._recall.recall(user_input, namespace=namespace)

        if not memories:
            return ""

        return self._recall.format_for_prompt(memories)

    def post_turn(
        self,
        user_input: str,
        ai_output: str,
        session_id: str = "",
        namespace: str = "global",
    ):
        """Called after the AI responds. Extracts, gates, stores, and learns."""
        self._ensure_initialized()
        self._turn_count += 1

        # Fingerprint dedup
        fingerprint = hashlib.sha256(f"{user_input}:{ai_output}".encode()).hexdigest()[:16]
        now = time.time()
        if (
            fingerprint == self._last_fingerprint
            and now - self._last_fingerprint_time < self.config.dedup_window_seconds
        ):
            return
        self._last_fingerprint = fingerprint
        self._last_fingerprint_time = now

        # Episode logging
        self.store.add_episode(
            user_input=user_input,
            ai_output=ai_output,
            namespace=namespace,
            session_id=session_id,
            turn_number=self._turn_count,
        )

        # Fact extraction
        facts = extract_facts(
            user_input=user_input,
            ai_output=ai_output,
            embedder=self.embedder,
            classifier=self._cat_clf,
            intent_classifier=self._intent_clf,
        )

        stored = 0
        contradicted = 0
        strengthened = 0

        for fact in facts:
            embedding = fact["embedding"]
            category = fact["category"]
            intent = fact.get("intent")

            # Dimension classification
            dimension, _ = self._dim_clf.classify(embedding)

            # Novelty gate
            result = self._gate.evaluate(
                content=fact["content"],
                embedding=embedding,
                namespace=namespace,
                ai_output_text=ai_output,
            )

            action = result["action"]

            if action == "contradict":
                self._gate.handle_contradiction(
                    old_id=result["old_id"],
                    new_content=fact["content"],
                    embedding=embedding,
                    category=category,
                    namespace=namespace,
                    intent=intent,
                    dimension=dimension,
                )
                contradicted += 1

            elif action == "store":
                importance = CATEGORY_IMPORTANCE.get(category, 1.0)
                strength = self.config.initial_strength * importance * result.get("gate", 1.0)

                mid = self.store.add(
                    content=fact["content"],
                    category=category,
                    namespace=namespace,
                    embedding=embedding,
                    strength=strength,
                    source_session=session_id,
                    intent=intent,
                    dimension=dimension,
                )

                if category == "entity" and is_self_identity(fact["content"]):
                    self.store.set_pinned(mid)

                self._build_edges(mid, embedding, namespace)
                stored += 1

            elif action == "strengthen":
                strengthened += 1

        # Response-alignment feedback
        feedback = self._recall.feedback(ai_output)

        # Edge decay
        self.store.decay_edges(self.config.edge_decay_rate, self.config.edge_weight_min)

        # Periodic consolidation
        if self._turn_count % self.config.consolidate_every == 0:
            clusters = self._consolidation.consolidate(namespace)
            if clusters:
                log.info("Consolidated %d clusters", len(clusters))

        if stored or contradicted:
            log.debug(
                "Memory post_turn: stored=%d contradicted=%d strengthened=%d feedback=%s",
                stored,
                contradicted,
                strengthened,
                feedback,
            )

    def recall_for_agent(self, task: str, agent_name: str) -> str:
        """Scoped recall for delegation context."""
        self._ensure_initialized()
        memories = self._recall.recall(task, namespace=agent_name)
        return self._recall.format_for_prompt(memories)

    def stats(self, namespace: str | None = None) -> dict:
        return self.store.stats(namespace)

    def close(self):
        self.store.close()

    def _build_edges(self, memory_id: str, embedding, namespace: str):
        """Connect new memory to similar existing ones."""
        ids, matrix = self.store.get_all_embeddings(namespace)
        if len(ids) == 0:
            return
        sims = EmbeddingService.cosine_similarity_matrix(embedding, matrix)
        for i, sim in enumerate(sims):
            if sim >= self.config.edge_threshold and ids[i] != memory_id:
                self.store.add_edge(memory_id, ids[i], float(sim))
