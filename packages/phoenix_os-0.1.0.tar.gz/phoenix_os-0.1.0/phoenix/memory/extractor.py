"""Fact extraction -- equation-based, zero-LLM, scale-invariant."""

import math
import re

import numpy as np

from .classifier import AnchorClassifier, IntentClassifier
from .embeddings import EmbeddingService


def sigmoid(x: float) -> float:
    if x < -500:
        return 0.0
    if x > 500:
        return 1.0
    return 1.0 / (1.0 + math.exp(-x))


# Sentence splitting pattern
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")

# First-person patterns
_FIRST_PERSON = re.compile(r"^(I|my|we|our|I'm|I've|I'll|I'd|I was)\b", re.IGNORECASE)

# Copula (linking verbs)
_COPULA = re.compile(r"\b(is|are|was|were|am)\b", re.IGNORECASE)

# Possessive markers
_POSSESSIVE = re.compile(r"\b(name|boss|friend|partner|wife|husband|'s)\b", re.IGNORECASE)

# Question starters
_QUESTION_START = re.compile(
    r"^(what|how|why|when|where|who|which|can|could|would|should|do|does|did|is|are)\b",
    re.IGNORECASE,
)

# Imperative starters
_IMPERATIVE_START = re.compile(
    r"^(please|help|show|tell|find|create|make|run|build|fix|write|read|list|check)\b",
    re.IGNORECASE,
)

# Declarative lambda weight
_DECLARATIVE_LAMBDA = 0.3

# Extraction threshold
_EXTRACT_THRESHOLD = 0.15


def _declarative_signal(sentence: str) -> float:
    """Pure syntax analysis. No embeddings. Returns [0, 1]."""
    score = 0.0
    if _FIRST_PERSON.match(sentence):
        score += 2.0
    if _COPULA.search(sentence):
        score += 1.0
    if _POSSESSIVE.search(sentence):
        score += 1.0
    if len(sentence) > 15:
        score += 0.5
    if _QUESTION_START.match(sentence):
        score -= 3.0
    if _IMPERATIVE_START.match(sentence):
        score -= 3.0
    if sentence.rstrip().endswith("?"):
        score -= 2.0
    if len(sentence) < 10:
        score -= 1.0
    return sigmoid(score - 1.0)


def _semantic_score(
    embedding: np.ndarray,
    classifier: AnchorClassifier,
) -> float:
    """Prominence + entropy scoring against category centroids."""
    scores = classifier.get_scores(embedding)
    if not scores:
        return 0.0

    values = list(scores.values())
    mean_val = sum(values) / len(values)
    std_val = (sum((v - mean_val) ** 2 for v in values) / len(values)) ** 0.5
    peak = max(values)

    # Prominence (z-score of peak)
    prominence = (peak - mean_val) / (std_val + 1e-9)
    prominence_gate = sigmoid(prominence - 0.5)

    # Entropy (classification confidence)
    temperature = 5.0
    exp_vals = [math.exp(v * temperature) for v in values]
    exp_sum = sum(exp_vals)
    probs = [e / exp_sum for e in exp_vals]
    entropy = -sum(p * math.log(p + 1e-12) for p in probs)
    max_entropy = math.log(len(values))
    entropy_norm = entropy / max_entropy if max_entropy > 0 else 0.0

    return prominence_gate * (1.0 - entropy_norm)


def _split_sentences(text: str) -> list[str]:
    """Split text into sentences."""
    sentences = _SENTENCE_SPLIT.split(text.strip())
    result = []
    for s in sentences:
        s = s.strip()
        if len(s) > 150 and ";" in s:
            result.extend(part.strip() for part in s.split(";") if part.strip())
        elif s:
            result.append(s)
    return result


def extract_facts(
    user_input: str,
    ai_output: str,
    embedder: EmbeddingService,
    classifier: AnchorClassifier,
    intent_classifier: IntentClassifier | None = None,
) -> list[dict]:
    """Extract facts from user input using dual-path scoring.

    Semantic path: category prominence + entropy gating
    Declarative path: first-person syntax features

    Only extracts from user_input (not AI output).
    """
    sentences = _split_sentences(user_input)
    if not sentences:
        return []

    facts = []
    for sentence in sentences:
        if len(sentence) < 8:
            continue

        embedding = embedder.embed(sentence)

        # Dual-path scoring
        sem_score = _semantic_score(embedding, classifier)
        decl_score = _declarative_signal(sentence)
        final_score = max(sem_score, _DECLARATIVE_LAMBDA * decl_score)

        if final_score < _EXTRACT_THRESHOLD:
            continue

        # Classify
        category, confidence = classifier.classify(embedding)

        # Intent (optional)
        intent = None
        if intent_classifier:
            intent, _ = intent_classifier.classify(embedding)

        facts.append(
            {
                "content": sentence,
                "category": category,
                "confidence": round(final_score, 3),
                "intent": intent,
                "embedding": embedding,
            }
        )

    return facts
