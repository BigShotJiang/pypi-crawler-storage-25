"""Embedding service -- local vectors with FastEmbed or TF-IDF fallback."""

import hashlib
import logging
import math
import os
import re
from collections import Counter

import numpy as np

from .config import MemoryParams

log = logging.getLogger(__name__)


class EmbeddingService:
    """Compute text embeddings locally. FastEmbed if available, else TF-IDF."""

    def __init__(self, config: MemoryParams | None = None):
        self.config = config or MemoryParams()
        self._model = None
        self._cache: dict[str, np.ndarray] = {}
        self._use_fastembed = self.config.use_fastembed

    def embed(self, text: str) -> np.ndarray:
        """Embed a single text. Returns (dim,) unit-normalized vector."""
        key = self._cache_key(text)
        if key in self._cache:
            return self._cache[key]
        vec = self._compute_batch([text])[0]
        self._cache[key] = vec
        return vec

    def embed_batch(self, texts: list[str]) -> list[np.ndarray]:
        """Embed multiple texts with cache."""
        results: list[np.ndarray | None] = []
        uncached_texts = []
        uncached_indices = []

        for i, t in enumerate(texts):
            key = self._cache_key(t)
            if key in self._cache:
                results.append(self._cache[key])
            else:
                results.append(None)
                uncached_texts.append(t)
                uncached_indices.append(i)

        if uncached_texts:
            vecs = self._compute_batch(uncached_texts)
            for idx, vec in zip(uncached_indices, vecs):
                key = self._cache_key(texts[idx])
                self._cache[key] = vec
                results[idx] = vec

        return results  # type: ignore

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        dot = float(np.dot(a, b))
        na = float(np.linalg.norm(a))
        nb = float(np.linalg.norm(b))
        if na < 1e-9 or nb < 1e-9:
            return 0.0
        return dot / (na * nb)

    @staticmethod
    def cosine_similarity_matrix(query: np.ndarray, keys: np.ndarray) -> np.ndarray:
        """Cosine similarity of query against each row in keys. Returns (n,)."""
        if keys.shape[0] == 0:
            return np.array([])
        norms = np.linalg.norm(keys, axis=1)
        norms = np.maximum(norms, 1e-9)
        qnorm = max(float(np.linalg.norm(query)), 1e-9)
        return (keys @ query) / (norms * qnorm)

    @property
    def dim(self) -> int:
        return self.config.embedding_dim

    # -- Internals --

    def _cache_key(self, text: str) -> str:
        return hashlib.md5(text.encode()).hexdigest()

    def _compute_batch(self, texts: list[str]) -> list[np.ndarray]:
        if self._use_fastembed:
            return self._fastembed_batch(texts)
        return self._tfidf_batch(texts)

    def _get_model(self):
        if self._model is not None:
            return self._model
        try:
            from pathlib import Path

            from fastembed import TextEmbedding

            cache_dir = str(Path.home() / ".cache" / "fastembed")
            os.environ.setdefault("HF_HUB_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
            os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
            os.environ.setdefault("TQDM_DISABLE", "1")
            for name in ("fastembed", "huggingface_hub", "onnxruntime"):
                logging.getLogger(name).setLevel(logging.WARNING)
            try:
                self._model = TextEmbedding(
                    model_name=self.config.embedding_model,
                    cache_dir=cache_dir,
                )
            except Exception:
                os.environ.pop("HF_HUB_OFFLINE", None)
                os.environ.pop("TQDM_DISABLE", None)
                os.environ.pop("HF_HUB_DISABLE_PROGRESS_BARS", None)
                self._model = TextEmbedding(
                    model_name=self.config.embedding_model,
                    cache_dir=cache_dir,
                )
            self._use_fastembed = True
            log.info("Embedding: fastembed (%s)", self.config.embedding_model)
        except (ImportError, Exception) as e:
            log.info("Embedding: TF-IDF fallback (%s)", e)
            self._use_fastembed = False
            self._model = "tfidf"
        return self._model

    def _fastembed_batch(self, texts: list[str]) -> list[np.ndarray]:
        model = self._get_model()
        if model == "tfidf":
            return self._tfidf_batch(texts)
        embeddings = list(model.embed(texts))
        return [self._normalize(np.array(e, dtype=np.float32)) for e in embeddings]

    def _tfidf_batch(self, texts: list[str]) -> list[np.ndarray]:
        dim = self.config.embedding_dim
        results = []
        for text in texts:
            tokens = self._tokenize(text)
            if not tokens:
                results.append(np.zeros(dim, dtype=np.float32))
                continue
            tf = Counter(tokens)
            vec = np.zeros(dim, dtype=np.float32)
            for token, count in tf.items():
                h = int(hashlib.md5(token.encode()).hexdigest(), 16)
                idx = h % dim
                sign = 1.0 if (h // dim) % 2 == 0 else -1.0
                vec[idx] += sign * (1.0 + math.log(count))
            results.append(self._normalize(vec))
        return results

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        text = text.lower().strip()
        tokens = re.findall(r"[a-z0-9]+(?:[-'][a-z0-9]+)*", text)
        stop = {
            "the",
            "a",
            "an",
            "is",
            "are",
            "was",
            "were",
            "be",
            "been",
            "to",
            "of",
            "in",
            "for",
            "on",
            "with",
            "at",
            "by",
            "it",
            "this",
            "that",
            "and",
            "or",
            "but",
            "not",
            "no",
            "do",
            "does",
            "did",
            "has",
            "have",
            "had",
            "will",
            "would",
            "can",
            "could",
            "should",
        }
        return [t for t in tokens if len(t) > 1 and t not in stop]

    @staticmethod
    def _normalize(v: np.ndarray) -> np.ndarray:
        norm = float(np.linalg.norm(v))
        if norm < 1e-9:
            return v
        return v / norm
