"""Recall engine -- semantic + strength + recency + graph + context + tension."""

import logging
import math
import time
from collections import deque
from datetime import datetime

import numpy as np

from .config import CATEGORY_IMPORTANCE, MemoryParams
from .embeddings import EmbeddingService
from .extractor import sigmoid
from .store import MemoryStore

log = logging.getLogger(__name__)


class RecallEngine:
    """Retrieves and ranks memories using composite scoring."""

    def __init__(self, config: MemoryParams, embedder: EmbeddingService, store: MemoryStore):
        self.config = config
        self.embedder = embedder
        self.store = store
        self._context_vector: np.ndarray | None = None
        self._last_recalled: list[dict] = []
        self._adaptive_importance: dict[str, float] = {}

    def update_context(self, user_input: str):
        """Update EMA context vector from user input."""
        emb = self.embedder.embed(user_input)
        lam = self.config.context_lambda
        if self._context_vector is None:
            self._context_vector = emb.copy()
        else:
            self._context_vector = lam * self._context_vector + (1 - lam) * emb
            norm = float(np.linalg.norm(self._context_vector))
            if norm > 1e-9:
                self._context_vector = self._context_vector / norm

    def recall(
        self,
        query: str,
        namespace: str = "global",
        top_k: int | None = None,
    ) -> list[dict]:
        """Full recall pipeline."""
        top_k = top_k or self.config.top_k
        query_emb = self.embedder.embed(query)
        ids, matrix = self.store.get_all_embeddings(namespace)
        if len(ids) == 0:
            self._last_recalled = []
            return []

        # Context blending
        effective_query = self._get_effective_query(query_emb, matrix)

        # Semantic similarities
        sims = EmbeddingService.cosine_similarity_matrix(effective_query, matrix)

        # Composite scoring
        now = time.time()
        scores = np.zeros(len(ids))
        id_to_meta: dict[str, dict] = {}

        for i, mid in enumerate(ids):
            sem = float(sims[i])
            if sem < self.config.min_relevance:
                continue

            mem = self.store.get(mid)
            if not mem:
                continue

            # Strength compression (BM25-style)
            strength = mem.get("strength", 1.0)
            compressed = strength**self.config.strength_compression
            access_bonus = 1.0 + 0.1 * math.log1p(mem.get("access_count", 0))

            # Recency
            age = max(now - (mem.get("created_at", now)), 1.0)
            recency = math.exp(-age * math.log(2) / self.config.recency_halflife)

            # Adaptive importance
            cat = mem.get("category", "fact")
            importance = self._adaptive_importance.get(cat, CATEGORY_IMPORTANCE.get(cat, 1.0))

            score = sem * compressed * access_bonus * importance
            score = score * (1 - self.config.recency_weight + self.config.recency_weight * recency)
            scores[i] = score
            id_to_meta[mid] = mem

        # Spreading activation (multi-hop BFS)
        scores = self._spread_activation(ids, scores)

        # Rank
        ranked_indices = np.argsort(-scores)
        results = []
        seen = set()

        for idx in ranked_indices:
            if scores[idx] < self.config.min_relevance:
                break
            mid = ids[idx]
            if mid in seen:
                continue
            seen.add(mid)
            mem = id_to_meta.get(mid) or self.store.get(mid)
            if not mem:
                continue
            mem["relevance"] = round(float(scores[idx]), 3)
            results.append(mem)
            self.store.increment_access(mid)
            if len(results) >= top_k * 3:
                break

        # Pinned memories always included
        pinned = self.store.get_pinned(namespace)
        for p in pinned:
            if p["id"] not in seen:
                p["relevance"] = 1.0
                p["pinned"] = True
                results.append(p)
                seen.add(p["id"])

        # Tension detection
        self._detect_tensions(results)

        # Relevance gate (direct query-to-content)
        gated = []
        for mem in results:
            if mem.get("pinned"):
                gated.append(mem)
                continue
            if mem.get("embedding") is not None:
                direct = EmbeddingService.cosine_similarity(query_emb, mem["embedding"])
                if direct >= self.config.relevance_gate_threshold:
                    mem["direct_relevance"] = round(direct, 3)
                    gated.append(mem)

        # Sort by relevance and limit
        gated.sort(key=lambda m: m.get("relevance", 0), reverse=True)
        self._last_recalled = gated[:top_k]
        return self._last_recalled

    def recall_objective(
        self,
        query: str,
        namespace: str = "global",
        top_k: int | None = None,
    ) -> list[dict]:
        """Recall without preferences or emotional intents. For anti-sycophancy."""
        results = self.recall(query, namespace, top_k=(top_k or self.config.top_k) * 2)
        return [
            m
            for m in results
            if m.get("category") not in ("preference",)
            and m.get("intent") not in ("venting", "excited")
        ][: top_k or self.config.top_k]

    def feedback(self, ai_output: str) -> dict:
        """Strengthen memories the AI actually used in its response."""
        if not self._last_recalled or not ai_output:
            return {"strengthened": 0}

        ai_emb = self.embedder.embed(ai_output[:500])
        strengthened = 0
        co_used = []

        for mem in self._last_recalled:
            if mem.get("embedding") is None:
                continue
            alignment = EmbeddingService.cosine_similarity(ai_emb, mem["embedding"])
            if alignment >= self.config.feedback_align_threshold:
                current = mem.get("strength", 1.0)
                new_strength = min(current + self.config.feedback_strengthen_rate, 2.0)
                self.store.update_strength(mem["id"], new_strength)
                self.store.increment_access(mem["id"])
                strengthened += 1
                co_used.append(mem["id"])

                # Update adaptive weights
                cat = mem.get("category", "fact")
                old = self._adaptive_importance.get(cat, CATEGORY_IMPORTANCE.get(cat, 1.0))
                self._adaptive_importance[cat] = (
                    self.config.adaptive_ema * old + (1 - self.config.adaptive_ema) * alignment
                )

        # Boost edges between co-used memories
        edges_boosted = 0
        for i in range(len(co_used)):
            for j in range(i + 1, len(co_used)):
                self.store.add_edge(
                    co_used[i],
                    co_used[j],
                    weight=self.config.feedback_edge_boost,
                    reinforce_amount=self.config.feedback_edge_boost,
                )
                edges_boosted += 1

        return {"strengthened": strengthened, "edges_boosted": edges_boosted}

    def format_for_prompt(self, memories: list[dict], max_tokens: int | None = None) -> str:
        """Format recalled memories for system prompt injection."""
        max_tokens = max_tokens or self.config.max_inject_tokens
        if not memories:
            return ""

        char_budget = max_tokens * 4
        now = time.time()
        lines = [f"[Memory Context -- {len(memories)} entries from previous sessions]"]
        lines.append(f"Current time: {datetime.now().strftime('%A, %B %d, %Y at %I:%M %p')}")
        chars_used = sum(len(line) for line in lines)

        for mem in memories:
            content = mem.get("content", "")[:200]
            category = mem.get("category", "fact")
            strength = mem.get("strength", 1.0)
            access = mem.get("access_count", 0)
            created = mem.get("created_at", now)
            age = now - created

            if age < 3600:
                age_str = f"{int(age / 60)}m ago"
            elif age < 86400:
                age_str = f"{int(age / 3600)}h ago"
            else:
                age_str = f"{int(age / 86400)}d ago"

            flags = []
            if mem.get("pinned"):
                flags.append("PINNED")
            if mem.get("tension_with"):
                flags.append("CONFLICTING")
            if mem.get("intent"):
                flags.append(f"intent:{mem['intent']}")

            flag_str = f" [{', '.join(flags)}]" if flags else ""
            prior = ""
            if mem.get("prior_value"):
                prior_age = ""
                if mem.get("prior_date"):
                    pd = now - mem["prior_date"]
                    prior_age = f" {int(pd / 86400)}d ago" if pd > 86400 else ""
                prior = f" (was: '{mem['prior_value'][:60]}'{prior_age})"

            line = (
                f"- {content} ({age_str}, str:{strength:.2f}, "
                f"used:{access}x, type:{category}{flag_str}){prior}"
            )

            if chars_used + len(line) > char_budget:
                break
            lines.append(line)
            chars_used += len(line)

        lines.append("[End Memory Context]")
        return "\n".join(lines)

    # -- Internal --

    def _get_effective_query(self, query_emb: np.ndarray, matrix: np.ndarray) -> np.ndarray:
        """Blend query with context vector based on self-sufficiency."""
        if self._context_vector is None or matrix.shape[0] == 0:
            return query_emb

        sims = EmbeddingService.cosine_similarity_matrix(query_emb, matrix)
        sigma_self = float(np.max(sims)) if len(sims) > 0 else 0.0

        blend = self.config.context_blend_beta * (sigma_self - self.config.context_blend_theta)
        alpha = sigmoid(blend)
        q_eff = alpha * query_emb + (1.0 - alpha) * self._context_vector
        norm = float(np.linalg.norm(q_eff))
        if norm > 1e-9:
            q_eff = q_eff / norm
        return q_eff

    def _spread_activation(self, ids: list[str], scores: np.ndarray) -> np.ndarray:
        """Multi-hop BFS through memory graph."""
        if self.config.n_hops == 0:
            return scores

        id_to_idx = {mid: i for i, mid in enumerate(ids)}
        seeds = [(i, scores[i]) for i in range(len(ids)) if scores[i] >= self.config.min_relevance]
        seeds.sort(key=lambda x: x[1], reverse=True)
        seeds = seeds[: self.config.top_k * 2]

        boosted = scores.copy()

        for seed_idx, seed_score in seeds:
            seed_id = ids[seed_idx]
            queue = deque([(seed_id, 0, 1.0)])
            visited = {seed_id}

            paths_found = 0
            while queue and paths_found < self.config.bfs_max_paths:
                current_id, depth, coherence = queue.popleft()
                if depth >= self.config.n_hops:
                    continue

                neighbors = self.store.get_neighbors(current_id)
                neighbors.sort(key=lambda x: x[1], reverse=True)

                for neighbor_id, weight in neighbors[: self.config.bfs_max_branch]:
                    if neighbor_id in visited:
                        continue
                    path_coherence = coherence * weight
                    if path_coherence < self.config.path_coherence_min:
                        continue

                    visited.add(neighbor_id)
                    paths_found += 1

                    if neighbor_id in id_to_idx:
                        target_idx = id_to_idx[neighbor_id]
                        n_neighbors = max(len(neighbors), 1)
                        boost = (
                            seed_score
                            * path_coherence
                            * (self.config.spread_factor ** (depth + 1))
                            / n_neighbors
                        )
                        boosted[target_idx] = max(boosted[target_idx], boosted[target_idx] + boost)

                    queue.append((neighbor_id, depth + 1, path_coherence))

        return boosted

    def _detect_tensions(self, memories: list[dict]):
        """Find contradicting pairs among recalled memories."""
        for i in range(len(memories)):
            for j in range(i + 1, len(memories)):
                a = memories[i]
                b = memories[j]
                if a.get("category") != b.get("category"):
                    continue
                if a.get("embedding") is None or b.get("embedding") is None:
                    continue
                sim = EmbeddingService.cosine_similarity(a["embedding"], b["embedding"])
                if 0.5 < sim < 0.85:
                    if "tension_with" not in a:
                        a["tension_with"] = []
                    if "tension_with" not in b:
                        b["tension_with"] = []
                    a["tension_with"].append(b["id"])
                    b["tension_with"].append(a["id"])
