"""Memory system configuration -- frozen internal parameters.

These values are tuned together as a system. Do NOT expose them as user config.
Changing one threshold without understanding the interactions will break the pipeline.
User-facing config is in config/memory.yaml (db_path, embedding_model, top_k, max_inject_tokens).
"""

import os
from dataclasses import dataclass
from pathlib import Path

_PHOENIX_DIR = os.environ.get("PHOENIX_DIR", str(Path.home() / ".phoenix"))


@dataclass(frozen=True)
class MemoryParams:
    # Storage
    db_path: str = os.environ.get("PHOENIX_MEMORY_DB", os.path.join(_PHOENIX_DIR, "memory.db"))
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_dim: int = 384
    use_fastembed: bool = True

    # Novelty gate
    theta_gate: float = 0.35
    beta_gate: float = 6.0
    output_overlap_ceiling: float = 0.90
    output_overlap_weight: float = 0.3

    # Strength dynamics
    initial_strength: float = 1.0
    decay_rate: float = 0.995
    reinforce_amount: float = 0.1
    strength_compression: float = 0.3

    # Contradiction detection
    contradiction_key_threshold: float = 0.70
    contradiction_value_threshold: float = 0.50
    contradiction_weaken_factor: float = 0.5

    # Context vector
    context_lambda: float = 0.7
    context_blend_beta: float = 8.0
    context_blend_theta: float = 0.4

    # Recall
    top_k: int = 4
    min_relevance: float = 0.10
    relevance_gate_threshold: float = 0.15
    recency_weight: float = 0.2
    recency_halflife: float = 86400.0

    # Graph
    edge_threshold: float = 0.3
    edge_reinforce_amount: float = 0.1
    edge_decay_rate: float = 0.02
    edge_weight_min: float = 0.01
    n_hops: int = 2
    spread_factor: float = 0.3
    bfs_max_branch: int = 5
    bfs_max_paths: int = 50
    path_coherence_min: float = 0.1

    # Tension detection
    tension_threshold: float = 0.3

    # Feedback
    feedback_strengthen_rate: float = 0.08
    feedback_align_threshold: float = 0.20
    feedback_edge_boost: float = 0.05

    # Consolidation
    consolidate_every: int = 20
    consolidate_sim_threshold: float = 0.30
    consolidate_min_cluster: int = 3
    consolidate_max_clusters: int = 5

    # Adaptive weights
    adaptive_weights: bool = True
    adaptive_lr: float = 0.05
    adaptive_ema: float = 0.9

    # Injection
    max_inject_tokens: int = 500

    # Dedup
    dedup_window_seconds: float = 10.0

    # Dimension classification threshold
    dimension_threshold: float = 0.15

    # Intent classification threshold
    intent_threshold: float = 0.25


# Anchor examples for classification -- frozen dicts via module constants

CATEGORY_ANCHORS: dict[str, list[str]] = {
    "fact": [
        "The project uses Python 3.12",
        "The database runs on PostgreSQL",
        "The API endpoint is /api/v2/users",
        "The deployment target is AWS Lambda",
    ],
    "preference": [
        "I prefer dark mode",
        "Always use TypeScript instead of JavaScript",
        "I like concise responses",
        "Use tabs not spaces",
    ],
    "skill": [
        "I know React and Next.js",
        "I'm experienced with Docker and Kubernetes",
        "I work with machine learning models",
    ],
    "context": [
        "I'm working on a todo app right now",
        "The current sprint focuses on authentication",
        "We're migrating from monolith to microservices",
    ],
    "entity": [
        "John is the tech lead on this project",
        "The company uses GitHub for version control",
        "Our team uses Slack for communication",
    ],
}

DIMENSION_ANCHORS: dict[str, list[str]] = {
    "body": [
        "I went to the gym today",
        "need to fix my sleep schedule",
        "feeling tired, need rest and recovery",
        "morning run completed, 5k",
    ],
    "mind": [
        "reading a book about systems thinking",
        "learned about mental models today",
        "journaling helps me think clearly",
        "studying distributed systems concepts",
    ],
    "craft": [
        "shipped the new feature to production",
        "building a side project this weekend",
        "debugging the authentication module",
        "writing clean code and refactoring",
    ],
    "people": [
        "had a great conversation with my family",
        "meeting with the team went really well",
        "mentoring a junior developer at work",
        "spending time with friends tonight",
    ],
    "legacy": [
        "open source contribution got merged",
        "writing a blog post to share what I learned",
        "building something that will outlast me",
        "teaching someone a skill they'll carry forward",
    ],
}

INTENT_ANCHORS: dict[str, list[str]] = {
    "planning": [
        "I need to finish this by Friday",
        "tomorrow I'll work on the database",
        "let's schedule that for next week",
    ],
    "venting": [
        "I'm so frustrated with this bug",
        "nothing is working today",
        "this is really annoying me",
    ],
    "reflecting": [
        "I think I've learned a lot from this",
        "looking back, I should have done it differently",
        "that approach worked really well actually",
    ],
    "excited": [
        "this is amazing, it actually works!",
        "I love how this turned out",
        "wow that was so much easier than expected",
    ],
    "requesting": [
        "can you help me with this",
        "I need you to fix this bug",
        "show me how to do this",
    ],
}

CATEGORY_IMPORTANCE: dict[str, float] = {
    "entity": 1.3,
    "preference": 1.2,
    "skill": 1.1,
    "context": 1.0,
    "fact": 1.0,
}
