"""SQLite storage layer for Phoenix memory."""

import os
import sqlite3
import time
import uuid

import numpy as np

from .config import MemoryParams

_SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    category TEXT DEFAULT 'fact',
    namespace TEXT DEFAULT 'global',
    embedding BLOB,
    strength REAL DEFAULT 1.0,
    access_count INTEGER DEFAULT 0,
    pinned INTEGER DEFAULT 0,
    superseded_by TEXT,
    source_session TEXT,
    created_at REAL,
    last_accessed REAL,
    intent TEXT,
    prior_value TEXT,
    prior_date REAL,
    dimension TEXT
);

CREATE TABLE IF NOT EXISTS memory_graph (
    source_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    weight REAL DEFAULT 0.5,
    PRIMARY KEY (source_id, target_id)
);

CREATE TABLE IF NOT EXISTS episodes (
    id TEXT PRIMARY KEY,
    user_input TEXT NOT NULL,
    ai_output TEXT NOT NULL,
    namespace TEXT DEFAULT 'global',
    session_id TEXT,
    turn_number INTEGER DEFAULT 0,
    summary TEXT,
    created_at REAL
);

CREATE INDEX IF NOT EXISTS idx_mem_category ON memories(category);
CREATE INDEX IF NOT EXISTS idx_mem_namespace ON memories(namespace);
CREATE INDEX IF NOT EXISTS idx_mem_strength ON memories(strength DESC);
CREATE INDEX IF NOT EXISTS idx_mem_created ON memories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mem_pinned ON memories(pinned);
CREATE INDEX IF NOT EXISTS idx_graph_source ON memory_graph(source_id);
CREATE INDEX IF NOT EXISTS idx_graph_target ON memory_graph(target_id);
CREATE INDEX IF NOT EXISTS idx_ep_namespace ON episodes(namespace);
CREATE INDEX IF NOT EXISTS idx_ep_session ON episodes(session_id);
"""


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


class MemoryStore:
    """SQLite-backed persistent memory store with namespace and graph support."""

    def __init__(self, config: MemoryParams | None = None):
        self.config = config or MemoryParams()
        self._conn: sqlite3.Connection | None = None

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            os.makedirs(os.path.dirname(self.config.db_path), exist_ok=True)
            self._conn = sqlite3.connect(self.config.db_path)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()
        return self._conn

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    # -- Memory CRUD --

    def add(
        self,
        content: str,
        category: str = "fact",
        namespace: str = "global",
        embedding: np.ndarray | None = None,
        strength: float | None = None,
        source_session: str = "",
        intent: str | None = None,
        prior_value: str | None = None,
        prior_date: float | None = None,
        dimension: str | None = None,
    ) -> str:
        conn = self._get_conn()
        mid = _new_id()
        now = time.time()
        emb_blob = embedding.astype(np.float32).tobytes() if embedding is not None else None
        strength = strength if strength is not None else self.config.initial_strength

        conn.execute(
            "INSERT INTO memories (id, content, category, namespace, embedding, strength, "
            "access_count, source_session, created_at, last_accessed, intent, "
            "prior_value, prior_date, dimension) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)",
            (
                mid,
                content,
                category,
                namespace,
                emb_blob,
                strength,
                source_session,
                now,
                now,
                intent,
                prior_value,
                prior_date,
                dimension,
            ),
        )
        conn.commit()
        return mid

    def get(self, memory_id: str) -> dict | None:
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM memories WHERE id = ?", (memory_id,)).fetchone()
        return self._row_to_dict(row) if row else None

    def update_strength(self, memory_id: str, new_strength: float):
        conn = self._get_conn()
        conn.execute(
            "UPDATE memories SET strength = ?, last_accessed = ? WHERE id = ?",
            (new_strength, time.time(), memory_id),
        )
        conn.commit()

    def increment_access(self, memory_id: str):
        conn = self._get_conn()
        conn.execute(
            "UPDATE memories SET access_count = access_count + 1, last_accessed = ? WHERE id = ?",
            (time.time(), memory_id),
        )
        conn.commit()

    def set_pinned(self, memory_id: str, pinned: bool = True):
        conn = self._get_conn()
        conn.execute("UPDATE memories SET pinned = ? WHERE id = ?", (1 if pinned else 0, memory_id))
        conn.commit()

    def get_pinned(self, namespace: str | None = None) -> list[dict]:
        conn = self._get_conn()
        if namespace:
            rows = conn.execute(
                "SELECT * FROM memories WHERE pinned = 1 "
                "AND (namespace = ? OR namespace = 'global') AND superseded_by IS NULL",
                (namespace,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM memories WHERE pinned = 1 AND superseded_by IS NULL"
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def supersede(self, old_id: str, new_id: str, weaken_factor: float = 0.5):
        conn = self._get_conn()
        conn.execute(
            "UPDATE memories SET superseded_by = ?, strength = strength * ? WHERE id = ?",
            (new_id, weaken_factor, old_id),
        )
        conn.commit()

    def count(self, namespace: str | None = None) -> int:
        conn = self._get_conn()
        if namespace:
            return conn.execute(
                "SELECT COUNT(*) FROM memories WHERE namespace = ?", (namespace,)
            ).fetchone()[0]
        return conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]

    def stats(self, namespace: str | None = None) -> dict:
        conn = self._get_conn()
        ns_filter = " WHERE namespace = ?" if namespace else ""
        params = (namespace,) if namespace else ()
        total = conn.execute(f"SELECT COUNT(*) FROM memories{ns_filter}", params).fetchone()[0]
        if total == 0:
            return {
                "total": 0,
                "by_category": {},
                "by_namespace": {},
                "avg_strength": 0,
                "edge_count": 0,
                "episodes": 0,
                "clusters": 0,
                "pinned": 0,
            }

        cats = conn.execute(
            f"SELECT category, COUNT(*) FROM memories{ns_filter} GROUP BY category", params
        ).fetchall()
        nss = conn.execute("SELECT namespace, COUNT(*) FROM memories GROUP BY namespace").fetchall()
        avg_str = conn.execute(
            f"SELECT AVG(strength) FROM memories{ns_filter}",
            params,
        ).fetchone()[0]
        edges = conn.execute("SELECT COUNT(*) FROM memory_graph").fetchone()[0]
        episodes = conn.execute("SELECT COUNT(*) FROM episodes").fetchone()[0]
        clusters = conn.execute(
            "SELECT COUNT(*) FROM memories"
            " WHERE content LIKE '[consolidated]%'"
            " AND superseded_by IS NULL"
        ).fetchone()[0]
        ns_clause = " AND namespace = ?" if namespace else ""
        pinned = conn.execute(
            f"SELECT COUNT(*) FROM memories WHERE pinned = 1{ns_clause}",
            params,
        ).fetchone()[0]
        return {
            "total": total,
            "by_category": {r[0]: r[1] for r in cats},
            "by_namespace": {r[0]: r[1] for r in nss},
            "avg_strength": round(avg_str or 0, 3),
            "edge_count": edges,
            "episodes": episodes,
            "clusters": clusters,
            "pinned": pinned,
        }

    # -- Decay --

    def decay_edges(self, decay_rate: float = 0.02, min_weight: float = 0.01):
        conn = self._get_conn()
        conn.execute("UPDATE memory_graph SET weight = weight - ?", (decay_rate,))
        conn.execute("DELETE FROM memory_graph WHERE weight < ?", (min_weight,))
        conn.commit()

    # -- Graph --

    def add_edge(
        self, source_id: str, target_id: str, weight: float, reinforce_amount: float = 0.1
    ):
        conn = self._get_conn()
        a, b = (source_id, target_id) if source_id < target_id else (target_id, source_id)
        conn.execute(
            "INSERT INTO memory_graph (source_id, target_id, weight) VALUES (?, ?, ?) "
            "ON CONFLICT(source_id, target_id) DO UPDATE SET weight = MIN(weight + ?, 1.0)",
            (a, b, weight, reinforce_amount),
        )
        conn.commit()

    def get_neighbors(self, memory_id: str) -> list[tuple[str, float]]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT source_id, target_id, weight FROM memory_graph "
            "WHERE source_id = ? OR target_id = ?",
            (memory_id, memory_id),
        ).fetchall()
        return [
            (r["target_id"] if r["source_id"] == memory_id else r["source_id"], r["weight"])
            for r in rows
        ]

    # -- Embeddings --

    def get_all_embeddings(self, namespace: str | None = None) -> tuple[list[str], np.ndarray]:
        conn = self._get_conn()
        if namespace:
            rows = conn.execute(
                "SELECT id, embedding FROM memories WHERE embedding IS NOT NULL "
                "AND (namespace = ? OR namespace = 'global') "
                "AND superseded_by IS NULL ORDER BY strength DESC",
                (namespace,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, embedding FROM memories WHERE embedding IS NOT NULL "
                "AND superseded_by IS NULL ORDER BY strength DESC"
            ).fetchall()
        if not rows:
            return [], np.array([]).reshape(0, self.config.embedding_dim)

        ids = []
        vecs = []
        dim = self.config.embedding_dim
        for r in rows:
            ids.append(r["id"])
            vecs.append(np.frombuffer(r["embedding"], dtype=np.float32).reshape(dim))
        return ids, np.stack(vecs)

    # -- Episodes --

    def add_episode(
        self,
        user_input: str,
        ai_output: str,
        namespace: str = "global",
        session_id: str = "",
        turn_number: int = 0,
    ) -> str:
        conn = self._get_conn()
        eid = _new_id()
        conn.execute(
            "INSERT INTO episodes (id, user_input, ai_output, namespace, session_id, "
            "turn_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (eid, user_input, ai_output[:500], namespace, session_id, turn_number, time.time()),
        )
        conn.commit()
        return eid

    def get_episode_timestamps(self, limit: int = 200) -> list[float]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT created_at FROM episodes ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [r[0] for r in rows if r[0]]

    # -- Internal --

    def _row_to_dict(self, row: sqlite3.Row) -> dict:
        d = dict(row)
        if d.get("embedding"):
            d["embedding"] = np.frombuffer(
                d["embedding"],
                dtype=np.float32,
            ).reshape(self.config.embedding_dim)
        return d
