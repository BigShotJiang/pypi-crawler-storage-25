"""Slash commands for the Phoenix shell."""

from dataclasses import dataclass, field
from typing import Any, Callable

from phoenix.shell.display import BOLD, CYAN, DIM, GREEN, RED, RESET, YELLOW


@dataclass
class CommandContext:
    history: list
    turn_count: int = 0
    usage_total: dict = field(default_factory=lambda: {"input": 0, "output": 0})
    save_fn: Callable | None = None
    engine: Any = None


def cmd_help(args: str, ctx: CommandContext) -> str:
    return (
        f"{BOLD}Phoenix Commands{RESET}\n"
        f"  /help       Show this help\n"
        f"  /bye        Exit Phoenix\n"
        f"  /clear      Clear conversation history\n"
        f"  /history    Show message count\n"
        f"  /model      Show or switch model (/model openai:gpt-4o)\n"
        f"  /cost       Show token usage for this session\n"
        f"  /tools      List available abilities\n"
        f"  /agents     List available agents\n"
        f"  /sessions   List saved sessions\n"
        f"  /mode       Show or switch approval mode (safe/auto/yolo)\n"
    )


def cmd_clear(args: str, ctx: CommandContext) -> str:
    ctx.history.clear()
    ctx.turn_count = 0
    return f"{GREEN}History cleared.{RESET}"


def cmd_history(args: str, ctx: CommandContext) -> str:
    return f"{len(ctx.history)} messages in history, {ctx.turn_count} turns."


def cmd_model(args: str, ctx: CommandContext) -> str:
    from phoenix.config.settings import get_model, get_provider, set_model

    if not args:
        model = get_model()
        return f"Current model: {BOLD}{model}{RESET} (provider: {get_provider()})"
    set_model(args.strip())
    return f"Model switched to: {BOLD}{args.strip()}{RESET}"


def cmd_cost(args: str, ctx: CommandContext) -> str:
    inp = ctx.usage_total.get("input", 0)
    out = ctx.usage_total.get("output", 0)
    total = inp + out
    return (
        f"Session tokens: {total:,}\n"
        f"  Input:  {inp:,}\n"
        f"  Output: {out:,}\n"
        f"  Turns:  {ctx.turn_count}"
    )


def cmd_tools(args: str, ctx: CommandContext) -> str:
    if not ctx.engine:
        return "Engine not available."
    abilities = ctx.engine.registry.list_abilities()
    if not abilities:
        return "No abilities discovered."
    lines = [f"{BOLD}Abilities ({len(abilities)}){RESET}"]
    for name in abilities:
        info = ctx.engine.registry.get_ability(name)
        desc = info.description if info else ""
        lines.append(f"  {CYAN}{name}{RESET} {DIM}{desc}{RESET}")
    return "\n".join(lines)


def cmd_agents(args: str, ctx: CommandContext) -> str:
    if not ctx.engine:
        return "Engine not available."
    agents = ctx.engine.registry.list_agents()
    if not agents:
        return "No agents discovered."
    lines = [f"{BOLD}Agents ({len(agents)}){RESET}"]
    for name in agents:
        config = ctx.engine.registry.get_agent_config(name)
        role = config.role if config else ""
        lines.append(f"  {CYAN}{name}{RESET} {DIM}{role}{RESET}")
    return "\n".join(lines)


def cmd_sessions(args: str, ctx: CommandContext) -> str:
    from phoenix.shell.session import SessionManager

    sessions = SessionManager.list_sessions()
    if not sessions:
        return "No saved sessions."
    lines = [f"{BOLD}Recent sessions{RESET}"]
    for s in sessions[:10]:
        sid = s.get("session_id", "?")[:12]
        count = s.get("message_count", 0)
        active = s.get("last_active", "?")[:19]
        lines.append(f"  {CYAN}{sid}{RESET}  {count:>4} msgs  {DIM}{active}{RESET}")
    if len(sessions) > 10:
        lines.append(f"  {DIM}... and {len(sessions) - 10} more{RESET}")
    return "\n".join(lines)


def cmd_mode(args: str, ctx: CommandContext) -> str:
    from phoenix.core.interceptor import (
        AutoApprovalBackend,
        CLIApprovalBackend,
        get_approval_backend,
        set_approval_backend,
    )

    if not args:
        backend = get_approval_backend()
        if isinstance(backend, AutoApprovalBackend):
            mode = backend.mode
        else:
            mode = "safe"
        color = RED if mode == "yolo" else YELLOW if mode == "auto" else GREEN
        return f"Approval mode: {color}{mode}{RESET}"

    mode = args.strip().lower()
    if mode == "safe":
        set_approval_backend(CLIApprovalBackend())
    elif mode in ("auto", "yolo"):
        set_approval_backend(AutoApprovalBackend(mode))
    else:
        return f"Unknown mode '{mode}'. Use: safe, auto, yolo"
    color = RED if mode == "yolo" else YELLOW if mode == "auto" else GREEN
    return f"Switched to: {color}{mode}{RESET}"


def cmd_memory(args: str, ctx: CommandContext) -> str:
    if not ctx.engine or not ctx.engine._memory:
        return "Memory system not available."
    stats = ctx.engine._memory.stats()
    lines = [f"{BOLD}Memory Stats{RESET}"]
    lines.append(f"  Total memories: {stats['total']}")
    lines.append(f"  Pinned: {stats['pinned']}")
    lines.append(f"  Clusters: {stats['clusters']}")
    lines.append(f"  Graph edges: {stats['edge_count']}")
    lines.append(f"  Episodes: {stats['episodes']}")
    lines.append(f"  Avg strength: {stats['avg_strength']}")
    if stats.get("by_category"):
        cats = ", ".join(f"{k}:{v}" for k, v in stats["by_category"].items())
        lines.append(f"  Categories: {cats}")
    if stats.get("by_namespace"):
        nss = ", ".join(f"{k}:{v}" for k, v in stats["by_namespace"].items())
        lines.append(f"  Namespaces: {nss}")
    return "\n".join(lines)


def cmd_ambient(args: str, ctx: CommandContext) -> str:
    return f"{DIM}Ambient daemon runs in background. Status available at startup.{RESET}"


def cmd_voice(args: str, ctx: CommandContext) -> str:
    msg = "Voice requires --voice flag at startup. Install: pip install phoenix-os[voice]"
    return f"{DIM}{msg}{RESET}"


COMMANDS: dict[str, Callable] = {
    "/help": cmd_help,
    "/clear": cmd_clear,
    "/history": cmd_history,
    "/model": cmd_model,
    "/cost": cmd_cost,
    "/tools": cmd_tools,
    "/agents": cmd_agents,
    "/sessions": cmd_sessions,
    "/mode": cmd_mode,
    "/memory": cmd_memory,
    "/ambient": cmd_ambient,
    "/voice": cmd_voice,
}

ALIASES = {"quit": "/bye", "exit": "/bye", "clear": "/clear", "history": "/history"}


def handle_command(user_input: str, ctx: CommandContext) -> str | None:
    """Handle a slash command. Returns output string, or None if not a command."""
    stripped = user_input.strip()

    if stripped in ALIASES:
        stripped = ALIASES[stripped]

    if not stripped.startswith("/"):
        return None

    parts = stripped.split(None, 1)
    cmd_name = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""

    if cmd_name in ("/bye", "/quit", "/exit"):
        return "__EXIT__"

    handler = COMMANDS.get(cmd_name)
    if handler:
        return handler(args, ctx)

    return f"Unknown command: {cmd_name}. Type /help for available commands."
