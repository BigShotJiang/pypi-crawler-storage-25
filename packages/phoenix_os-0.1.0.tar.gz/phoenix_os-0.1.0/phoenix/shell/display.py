"""Display formatting -- colors, banner, tool calls, usage, safety indicators."""

import shutil
import sys
import time

# ANSI codes
DIM = "\033[2m"
BOLD = "\033[1m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
GREEN = "\033[32m"
RED = "\033[31m"
MAGENTA = "\033[35m"
WHITE = "\033[37m"
BRIGHT_BLACK = "\033[90m"
RESET = "\033[0m"

# Box drawing characters
BOX_H = "\u2500"  # horizontal
BOX_V = "\u2502"  # vertical
BOX_TL = "\u256d"  # top-left
BOX_TR = "\u256e"  # top-right
BOX_BL = "\u2570"  # bottom-left
BOX_BR = "\u256f"  # bottom-right
BOX_THICK_V = "\u2503"  # thick vertical

# Status icons
ICON_OK = "\u2713"  # checkmark
ICON_FAIL = "\u2717"  # x mark
ICON_ARROW = "\u25b8"  # right triangle
ICON_DOT = "\u2022"  # bullet
ICON_BOLT = "\u26a1"  # lightning


def _term_width() -> int:
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return 80


def truncate(text: str, max_len: int = 120) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


# ---------------------------------------------------------------------------
# Safety mode indicator
# ---------------------------------------------------------------------------

_MODE_COLORS = {"safe": GREEN, "auto": YELLOW, "yolo": RED}
_MODE_LABELS = {"safe": "safe", "auto": "auto", "yolo": "YOLO"}


def get_mode_color() -> str:
    from phoenix.core.interceptor import AutoApprovalBackend, get_approval_backend

    backend = get_approval_backend()
    if isinstance(backend, AutoApprovalBackend):
        return _MODE_COLORS.get(backend.mode, GREEN)
    return GREEN


def get_mode_name() -> str:
    from phoenix.core.interceptor import AutoApprovalBackend, get_approval_backend

    backend = get_approval_backend()
    if isinstance(backend, AutoApprovalBackend):
        return _MODE_LABELS.get(backend.mode, "safe")
    return "safe"


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------


def get_prompt() -> str:
    """Build the input prompt with safety color."""
    color = get_mode_color()
    return f"{color}{BOLD}>{RESET} "


# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------


def print_banner(
    model: str,
    abilities: list[str],
    agents: list[str],
    memory_stats: dict | None = None,
    ambient_active: bool = False,
):
    w = min(_term_width(), 72)
    line = BOX_H * (w - 2)

    print()
    print(f"  {DIM}{BOX_TL}{line}{BOX_TR}{RESET}")
    header = f"  {BOLD}Phoenix{RESET}  {DIM}{BOX_V}{RESET}  {BRIGHT_BLACK}{model}{RESET}"
    print(f"  {DIM}{BOX_V}{RESET}{header}")
    print(f"  {DIM}{BOX_V}{RESET}")

    if abilities:
        ab_str = f"{DIM}Abilities:{RESET} {CYAN}{', '.join(abilities)}{RESET}"
        print(f"  {DIM}{BOX_V}{RESET}  {ab_str}")

    if agents:
        ag_str = f"{DIM}Agents:{RESET} {CYAN}{', '.join(a for a in agents if a != 'brain')}{RESET}"
        print(f"  {DIM}{BOX_V}{RESET}  {ag_str}")

    # Status line
    status_parts = []
    mode = get_mode_name()
    mode_color = get_mode_color()
    status_parts.append(f"Mode: {mode_color}{mode}{RESET}")

    if memory_stats and memory_stats.get("total", 0) > 0:
        total = memory_stats["total"]
        pinned = memory_stats.get("pinned", 0)
        status_parts.append(f"Memory: {total} facts ({pinned} pinned)")

    if ambient_active:
        status_parts.append(f"Ambient: {GREEN}active{RESET}")

    if status_parts:
        print(f"  {DIM}{BOX_V}{RESET}  {DIM}{' | '.join(status_parts)}{RESET}")

    print(f"  {DIM}{BOX_V}{RESET}")
    help_text = "/help for commands | multiline: end with \\\\ | /bye to exit"
    print(f"  {DIM}{BOX_V}{RESET}  {BRIGHT_BLACK}{help_text}{RESET}")
    print(f"  {DIM}{BOX_BL}{line}{BOX_BR}{RESET}")
    print()


# ---------------------------------------------------------------------------
# Thinking / streaming
# ---------------------------------------------------------------------------

_SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
_spinner_idx = 0
_thinking_start: float = 0


def print_thinking():
    global _thinking_start
    _thinking_start = time.time()
    sys.stdout.write(f"  {DIM}⠋ thinking...{RESET}")
    sys.stdout.flush()


def clear_thinking():
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()


def print_text(text: str):
    sys.stdout.write(text)
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Tool call display
# ---------------------------------------------------------------------------


def print_tool_call(tool_name: str, args: dict | None = None):
    """Display a tool call with icon and formatted args."""
    args_str = ""
    if args and isinstance(args, dict):
        items = []
        for k, v in args.items():
            v_str = truncate(str(v).replace("\n", " "), 60)
            items.append(f"{BRIGHT_BLACK}{k}={RESET}{v_str}")
        args_str = ", ".join(items)

    print(f"  {YELLOW}{ICON_ARROW}{RESET} {CYAN}{tool_name}{RESET}({args_str})")


def print_tool_result(tool_name: str, result: str, success: bool = True):
    """Display a tool result with status icon."""
    icon = f"{GREEN}{ICON_OK}{RESET}" if success else f"{RED}{ICON_FAIL}{RESET}"
    content = truncate(result.replace("\n", " "), 100)
    print(f"  {icon} {BRIGHT_BLACK}{content}{RESET}")


def print_tool_calls(messages: list):
    """Display tool calls from pydantic-ai message history."""
    try:
        from pydantic_ai.messages import (
            ModelRequest,
            ModelResponse,
            ToolCallPart,
            ToolReturnPart,
        )
    except ImportError:
        return

    for msg in messages:
        if isinstance(msg, ModelResponse):
            tool_parts = [p for p in msg.parts if isinstance(p, ToolCallPart)]
            if len(tool_parts) > 1:
                print(f"  {YELLOW}{ICON_BOLT} {len(tool_parts)} parallel calls{RESET}")
            for part in tool_parts:
                args = part.args if isinstance(part.args, dict) else {}
                print_tool_call(part.tool_name, args)

        elif isinstance(msg, ModelRequest):
            for part in msg.parts:
                if isinstance(part, ToolReturnPart):
                    content = str(part.content)
                    is_error = content.startswith("Error") or content.startswith("(")
                    print_tool_result(part.tool_name, content, success=not is_error)


# ---------------------------------------------------------------------------
# Usage / tokens
# ---------------------------------------------------------------------------


def print_usage(input_tokens: int, output_tokens: int, turn_count: int = 0):
    total = input_tokens + output_tokens
    elapsed = time.time() - _thinking_start if _thinking_start else 0
    elapsed_str = f" {elapsed:.1f}s" if elapsed > 0.5 else ""

    parts = [f"{total:,} tokens ({input_tokens:,} in, {output_tokens:,} out)"]
    if elapsed_str:
        parts.append(elapsed_str)

    print(f"  {BRIGHT_BLACK}{' '.join(parts)}{RESET}")


def print_session_usage(usage_total: dict, turn_count: int):
    total = usage_total.get("input", 0) + usage_total.get("output", 0)
    print(f"  {BRIGHT_BLACK}Session: {total:,} tokens, {turn_count} turns{RESET}")


# ---------------------------------------------------------------------------
# Status / error / notifications
# ---------------------------------------------------------------------------


def print_error(message: str):
    print(f"\n  {RED}{ICON_FAIL} Error:{RESET} {message}")


def print_status(message: str):
    print(f"  {BRIGHT_BLACK}{message}{RESET}")


def print_notification(message: str):
    print(f"  {CYAN}{ICON_BOLT} {message}{RESET}")


def print_separator():
    w = min(_term_width(), 72)
    print(f"  {BRIGHT_BLACK}{BOX_H * (w - 4)}{RESET}")
