"""Input handling -- single line, multiline, paste detection."""

import select
import sys


def _drain_paste() -> list[str]:
    """Read remaining buffered lines from paste operations."""
    lines = []
    timeout = 0.15
    try:
        while True:
            ready, _, _ = select.select([sys.stdin], [], [], timeout)
            if not ready:
                break
            line = sys.stdin.readline()
            if not line:
                break
            lines.append(line.rstrip("\n"))
            timeout = 0.05
    except Exception:
        pass
    return lines


def read_input(prompt_str: str = "> ") -> str:
    """Read user input with multiline and paste support.

    Three modes:
    1. Single line: type + Enter
    2. Paste: auto-detected via stdin buffering
    3. Manual multiline: end line with \\\\ to continue
    """
    try:
        first_line = input(prompt_str)
    except (KeyboardInterrupt, EOFError):
        return ""

    extra = _drain_paste()
    if extra:
        all_lines = [first_line] + extra
        preview = all_lines[0][:80]
        count = len(all_lines)
        print(f"  \033[90m[Pasted {count} lines: {preview}...]\033[0m")
        try:
            input("  \033[90mPress Enter to send, Ctrl+C to cancel\033[0m")
        except (KeyboardInterrupt, EOFError):
            return ""
        return "\n".join(all_lines)

    if first_line.endswith("\\"):
        lines = [first_line[:-1]]
        print("  \033[90m(multiline -- empty line to send)\033[0m")
        while True:
            try:
                line = input("\033[90m...\033[0m ")
            except (KeyboardInterrupt, EOFError):
                break
            if not line:
                break
            if line.endswith("\\"):
                lines.append(line[:-1])
            else:
                lines.append(line)
                break
        return "\n".join(lines)

    return first_line


def read_input_safe(prompt_str: str = "> ") -> str | None:
    """Wrapper that returns None on interrupt."""
    try:
        return read_input(prompt_str)
    except (KeyboardInterrupt, EOFError):
        return None
