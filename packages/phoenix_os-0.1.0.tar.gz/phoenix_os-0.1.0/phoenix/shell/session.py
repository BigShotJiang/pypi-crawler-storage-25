"""Session persistence -- save/load conversation history."""

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from phoenix.config.settings import PHOENIX_DIR

SESSIONS_DIR = PHOENIX_DIR / "sessions"


class SessionManager:
    def __init__(self, session_id: str | None = None):
        self.session_id = session_id or uuid.uuid4().hex[:12]
        self.session_dir = SESSIONS_DIR / self.session_id
        self._meta_path = self.session_dir / "meta.json"
        self._messages_path = self.session_dir / "messages.json"

    def save(self, messages: list):
        """Save message history and metadata."""
        try:
            self.session_dir.mkdir(parents=True, exist_ok=True)

            meta = self._load_meta()
            meta.update(
                {
                    "session_id": self.session_id,
                    "last_active": datetime.now(timezone.utc).isoformat(),
                    "working_dir": str(Path.cwd()),
                    "message_count": len(messages),
                }
            )
            if "created" not in meta:
                meta["created"] = meta["last_active"]

            self._meta_path.write_text(json.dumps(meta, indent=2))

            from pydantic_ai.messages import ModelMessagesTypeAdapter

            raw = ModelMessagesTypeAdapter.dump_json(messages, indent=2)
            self._messages_path.write_bytes(raw)
        except Exception as e:
            print(f"\033[31mWarning: failed to save session: {e}\033[0m")

    def load(self) -> list:
        """Load message history. Returns empty list if not found."""
        if not self._messages_path.exists():
            return []
        try:
            from pydantic_ai.messages import ModelMessagesTypeAdapter

            raw = self._messages_path.read_bytes()
            return list(ModelMessagesTypeAdapter.validate_json(raw))
        except Exception:
            return []

    def _load_meta(self) -> dict:
        if self._meta_path.exists():
            try:
                return json.loads(self._meta_path.read_text())
            except Exception:
                pass
        return {}

    @staticmethod
    def list_sessions() -> list[dict]:
        """List all saved sessions, newest first."""
        if not SESSIONS_DIR.is_dir():
            return []
        sessions = []
        for d in SESSIONS_DIR.iterdir():
            if not d.is_dir():
                continue
            meta_path = d / "meta.json"
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text())
                    sessions.append(meta)
                except Exception:
                    pass
        sessions.sort(key=lambda s: s.get("last_active", ""), reverse=True)
        return sessions

    @staticmethod
    def get_latest_session_id() -> str | None:
        sessions = SessionManager.list_sessions()
        return sessions[0]["session_id"] if sessions else None
