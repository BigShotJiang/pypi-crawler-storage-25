"""Chat loop -- the main conversation interface."""

from phoenix.config.settings import get_model
from phoenix.core.engine import PhoenixEngine
from phoenix.shell import display
from phoenix.shell.commands import CommandContext, handle_command
from phoenix.shell.input import read_input_safe
from phoenix.shell.session import SessionManager


async def run_loop(
    engine: PhoenixEngine,
    session: SessionManager,
    history: list | None = None,
    ambient=None,
    voice_queue=None,
    voice_daemon=None,
    hook_runner=None,
):
    """Run the main Phoenix chat loop."""
    history = history or []
    turn_count = 0
    usage_total = {"input": 0, "output": 0}

    mem_stats = engine._memory.stats() if engine._memory else None

    display.print_banner(
        model=get_model(),
        abilities=engine.registry.list_abilities(),
        agents=engine.registry.list_agents(),
        memory_stats=mem_stats,
        ambient_active=bool(ambient and ambient.is_enabled),
    )

    if history:
        display.print_status(f"Restored {len(history)} messages from session {session.session_id}")

    cmd_ctx = CommandContext(
        history=history,
        turn_count=turn_count,
        usage_total=usage_total,
        save_fn=session.save,
        engine=engine,
    )

    while True:
        # Display ambient notifications
        if ambient:
            for note in ambient.get_notifications():
                display.print_notification(note)

        # Get input with safety-colored prompt
        prompt_str = display.get_prompt()
        user_input = read_input_safe(prompt_str)

        if user_input is None:
            print("\nBye, Boss.")
            session.save(history)
            break

        if not user_input.strip():
            continue

        # Record input for ambient idle detection
        if ambient:
            ambient.record_input()

        # Handle slash commands
        result = handle_command(user_input, cmd_ctx)
        if result is not None:
            if result == "__EXIT__":
                print("Bye, Boss.")
                session.save(history)
                break
            print(result)
            history = cmd_ctx.history
            turn_count = cmd_ctx.turn_count
            continue

        # Pre-turn hooks
        if hook_runner and hook_runner.has_hooks:
            from phoenix.hooks.runner import HookContext, HookEvent

            hr = await hook_runner.run(
                HookEvent.PRE_TURN,
                HookContext(event=HookEvent.PRE_TURN, user_input=user_input, turn_count=turn_count),
            )
            if hr.feedback:
                display.print_status(hr.feedback.strip())
            if not hr.allow:
                display.print_status("(blocked by hook)")
                continue

        # Run agent turn
        try:
            display.print_thinking()
            first = True
            chunks = []

            async for text in engine.run_stream(user_input, history):
                if first:
                    display.clear_thinking()

                    # Show tool calls from the stream
                    if hasattr(engine, "_last_history") and engine._last_history:
                        display.print_tool_calls(engine._last_history[-10:])

                    first = False
                display.print_text(text)
                chunks.append(text)

            print()  # newline after streaming
            history = engine.last_history
            turn_count += 1
            cmd_ctx.history = history
            cmd_ctx.turn_count = turn_count

            # Show token usage
            try:
                result_obj = engine.agent.last_run
                if hasattr(result_obj, "usage") and callable(result_obj.usage):
                    usage = result_obj.usage()
                    if usage:
                        inp = getattr(usage, "input_tokens", 0) or 0
                        out = getattr(usage, "output_tokens", 0) or 0
                        usage_total["input"] += inp
                        usage_total["output"] += out
                        display.print_usage(inp, out, turn_count)
            except Exception:
                pass

            # Post-turn hooks
            if hook_runner and hook_runner.has_hooks:
                from phoenix.hooks.runner import HookContext, HookEvent

                hr = await hook_runner.run(
                    HookEvent.POST_TURN,
                    HookContext(
                        event=HookEvent.POST_TURN,
                        user_input=user_input,
                        turn_count=turn_count,
                    ),
                )
                if hr.feedback:
                    display.print_status(hr.feedback.strip())

            session.save(history)

        except KeyboardInterrupt:
            display.clear_thinking()
            print("\n(cancelled)")
        except Exception as e:
            display.clear_thinking()
            display.print_error(str(e))
            session.save(history)
