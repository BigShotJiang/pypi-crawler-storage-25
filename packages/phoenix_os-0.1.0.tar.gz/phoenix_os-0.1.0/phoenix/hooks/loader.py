"""Hook loader -- loads shell command hooks from JSON config."""

import asyncio
import json
import logging
import os
from pathlib import Path

from .runner import HookCallback, HookContext, HookEvent, HookResult, HookRunner

log = logging.getLogger(__name__)


def _make_shell_hook(command: str, action: str = "log", match: str | None = None) -> HookCallback:
    """Create a hook callback that runs a shell command."""

    async def hook(ctx: HookContext) -> HookResult | None:
        if match and ctx.tool_name and match != ctx.tool_name:
            return None

        env = os.environ.copy()
        env["PHOENIX_EVENT"] = ctx.event.value
        if ctx.tool_name:
            env["PHOENIX_TOOL"] = ctx.tool_name
        if ctx.user_input:
            env["PHOENIX_INPUT"] = ctx.user_input[:500]
        env["PHOENIX_TURN"] = str(ctx.turn_count)

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
        except asyncio.TimeoutError:
            return HookResult(feedback=f"Hook timed out: {command}")
        except Exception as e:
            return HookResult(feedback=f"Hook failed: {e}")

        output = stdout.decode().strip() if stdout else ""

        if action == "approve_or_deny":
            allowed = proc.returncode == 0
            return HookResult(
                allow=allowed,
                feedback=output or (None if allowed else f"Hook denied: {command}"),
            )

        if output:
            return HookResult(feedback=output)
        return None

    return hook


def load_hooks_config(
    config_path: str | Path | None = None,
    runner: HookRunner | None = None,
) -> HookRunner:
    """Load hooks from a JSON config file.

    Config format:
    {
      "hooks": {
        "pre_tool": [
          {"command": "echo hello", "action": "log"},
          {"match": "bash", "command": "lint.sh", "action": "approve_or_deny"}
        ],
        "post_turn": [
          {"command": "notify-send 'done'"}
        ]
      }
    }
    """
    runner = runner or HookRunner()

    if config_path is None:
        config_path = Path("hooks_config.json")
    config_path = Path(config_path)

    if not config_path.is_file():
        return runner

    try:
        with open(config_path) as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return runner

    hooks_section = data.get("hooks", {})
    event_map = {e.value: e for e in HookEvent}

    count = 0
    for event_name, entries in hooks_section.items():
        event = event_map.get(event_name)
        if not event:
            continue
        for entry in entries:
            command = entry.get("command")
            if not command:
                continue
            action = entry.get("action", "log")
            match = entry.get("match")
            runner.register(event, _make_shell_hook(command, action, match))
            count += 1

    if count:
        log.info("Loaded %d hooks from %s", count, config_path)
    return runner
