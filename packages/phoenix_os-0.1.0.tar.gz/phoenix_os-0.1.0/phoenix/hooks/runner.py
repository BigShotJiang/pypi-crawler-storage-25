"""Hook runner -- lifecycle events with async callbacks."""

import enum
import logging
from dataclasses import dataclass
from typing import Awaitable, Callable

log = logging.getLogger(__name__)


class HookEvent(enum.Enum):
    PRE_TOOL = "pre_tool"
    POST_TOOL = "post_tool"
    PRE_TURN = "pre_turn"
    POST_TURN = "post_turn"
    ON_ERROR = "on_error"


@dataclass
class HookContext:
    event: HookEvent
    tool_name: str | None = None
    tool_args: dict | None = None
    tool_result: str | None = None
    user_input: str | None = None
    turn_count: int = 0
    session_id: str = ""


@dataclass
class HookResult:
    allow: bool = True
    modified_args: dict | None = None
    feedback: str | None = None


HookCallback = Callable[[HookContext], Awaitable[HookResult | None]]


class HookRunner:
    """Registry and executor for lifecycle hooks."""

    def __init__(self):
        self._hooks: dict[HookEvent, list[HookCallback]] = {e: [] for e in HookEvent}

    def register(self, event: HookEvent, callback: HookCallback):
        self._hooks[event].append(callback)

    def clear(self, event: HookEvent | None = None):
        if event:
            self._hooks[event] = []
        else:
            self._hooks = {e: [] for e in HookEvent}

    async def run(self, event: HookEvent, context: HookContext) -> HookResult:
        """Run all hooks for an event. Returns merged result."""
        result = HookResult()
        for callback in self._hooks[event]:
            try:
                r = await callback(context)
                if r is not None:
                    if not r.allow:
                        result.allow = False
                    if r.modified_args is not None:
                        result.modified_args = r.modified_args
                    if r.feedback:
                        result.feedback = (result.feedback or "") + r.feedback + "\n"
            except Exception as e:
                result.feedback = (result.feedback or "") + f"Hook error: {e}\n"
        return result

    @property
    def has_hooks(self) -> bool:
        return any(bool(cbs) for cbs in self._hooks.values())

    def event_count(self, event: HookEvent) -> int:
        return len(self._hooks[event])
