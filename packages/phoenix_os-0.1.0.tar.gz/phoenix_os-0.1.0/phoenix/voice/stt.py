"""Speech-to-text -- Groq Whisper (cloud) + faster-whisper (local) fallback."""

import asyncio
import io
import logging
import tempfile
import time
import wave

import numpy as np

from .audio import AudioFilter
from .config import VoiceConfig

log = logging.getLogger(__name__)


class SpeechToText:
    """Records audio and transcribes to text."""

    def __init__(self, config: VoiceConfig):
        self._config = config
        self._audio_filter = AudioFilter(aggressiveness=2)
        self._local_model = None

    async def listen_and_transcribe(self) -> str | None:
        """Record audio, clean, transcribe. Returns text or None."""
        wav_bytes = await asyncio.to_thread(self._record_audio)
        if not wav_bytes:
            return None

        wav_bytes = self._clean_audio(wav_bytes)
        if not wav_bytes:
            return None

        if self._config.stt_backend == "groq" and self._config.groq_api_key:
            text = await asyncio.to_thread(self._transcribe_groq, wav_bytes)
        else:
            text = await asyncio.to_thread(self._transcribe_local, wav_bytes)

        return text.strip() if text else None

    def _record_audio(self) -> bytes | None:
        """Record from microphone until silence detected."""
        try:
            import sounddevice as sd
        except ImportError:
            log.error("sounddevice not installed")
            return None

        sr = self._config.sample_rate
        chunk = self._config.chunk_size
        threshold = self._config.silence_threshold
        max_seconds = self._config.command_max_seconds
        silence_limit = self._config.silence_duration

        frames = []
        speech_detected = False
        silence_start = None
        start_time = None

        try:
            with sd.InputStream(
                samplerate=sr,
                channels=1,
                dtype="int16",
                blocksize=chunk,
                latency="low",
            ) as stream:
                start_time = time.time()
                initial_timeout = 3.0

                while True:
                    data, _ = stream.read(chunk)
                    pcm = data[:, 0] if data.ndim > 1 else data
                    elapsed = time.time() - start_time

                    amplitude = int(np.max(np.abs(pcm)))
                    is_loud = amplitude >= threshold
                    is_voice = self._audio_filter.is_speech(pcm, sr) if is_loud else False

                    if is_voice:
                        speech_detected = True
                        silence_start = None
                        frames.append(pcm.copy())
                    elif speech_detected:
                        frames.append(pcm.copy())
                        if silence_start is None:
                            silence_start = time.time()
                        elif time.time() - silence_start >= silence_limit:
                            break

                    if not speech_detected and elapsed >= initial_timeout:
                        return None
                    if elapsed >= max_seconds:
                        break

        except Exception as e:
            log.debug("Recording error: %s", e)
            return None

        if not frames:
            return None

        audio = np.concatenate(frames)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(audio.astype(np.int16).tobytes())
        return buf.getvalue()

    def _clean_audio(self, wav_bytes: bytes) -> bytes | None:
        try:
            buf = io.BytesIO(wav_bytes)
            with wave.open(buf, "rb") as wf:
                sr = wf.getframerate()
                pcm = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16)

            cleaned = self._audio_filter.clean_audio(pcm, sr)

            out = io.BytesIO()
            with wave.open(out, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(cleaned.tobytes())
            return out.getvalue()
        except Exception:
            return wav_bytes

    def _transcribe_groq(self, wav_bytes: bytes) -> str | None:
        try:
            import groq

            client = groq.Client(api_key=self._config.groq_api_key)
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(wav_bytes)
                f.flush()
                result = client.audio.transcriptions.create(
                    model=self._config.groq_model,
                    file=open(f.name, "rb"),
                    language="en",
                    temperature=0.0,
                    response_format="json",
                )
            import os

            os.unlink(f.name)
            return result.text
        except Exception as e:
            log.warning("Groq transcription failed: %s", e)
            return self._transcribe_local(wav_bytes)

    def _transcribe_local(self, wav_bytes: bytes) -> str | None:
        try:
            if self._local_model is None:
                from faster_whisper import WhisperModel

                self._local_model = WhisperModel(
                    self._config.local_whisper_model,
                    device="cpu",
                    compute_type="int8",
                )
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(wav_bytes)
                f.flush()
                segments, _ = self._local_model.transcribe(f.name, language="en")
                text = " ".join(seg.text for seg in segments)
            import os

            os.unlink(f.name)
            return text
        except ImportError:
            log.error("faster-whisper not installed. pip install phoenix-os[voice]")
            return None
        except Exception as e:
            log.warning("Local transcription failed: %s", e)
            return None
