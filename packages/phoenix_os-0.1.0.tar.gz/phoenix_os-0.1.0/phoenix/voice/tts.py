"""Text-to-speech -- Kokoro (local neural) + macOS say + ElevenLabs."""

import asyncio
import logging
import os
import re
import subprocess
import tempfile

from .config import VoiceConfig

log = logging.getLogger(__name__)


class TextToSpeech:
    """Multi-backend TTS with smart response handling."""

    def __init__(self, config: VoiceConfig):
        self._config = config
        self._enabled = config.tts_backend != "off"
        self._kokoro = None
        self._kokoro_failed = False
        self._elevenlabs_client = None

    async def speak(self, text: str):
        """Speak the given text. Strips code blocks, summarizes if too long."""
        if not self._enabled or not text.strip():
            return

        text = self._strip_code_blocks(text)
        if not text.strip():
            return

        words = text.split()
        if len(words) > self._config.tts_max_words:
            text = self._extract_summary(text)

        try:
            if self._config.tts_backend == "kokoro" and not self._kokoro_failed:
                await asyncio.to_thread(self._speak_kokoro, text)
            elif self._config.tts_backend == "elevenlabs" and self._config.elevenlabs_api_key:
                await asyncio.to_thread(self._speak_elevenlabs, text)
            else:
                await asyncio.to_thread(self._speak_say, text)
        except Exception as e:
            log.debug("TTS failed, falling back to say: %s", e)
            try:
                await asyncio.to_thread(self._speak_say, text)
            except Exception:
                pass

    def _speak_kokoro(self, text: str):
        if self._kokoro is None:
            try:
                import kokoro_onnx
                import numpy as np

                self._kokoro = kokoro_onnx.Kokoro(
                    os.path.expanduser("~/.phoenix/kokoro/onnx/model.onnx"),
                    os.path.expanduser("~/.phoenix/kokoro/voices-v1.0.bin"),
                )
            except (ImportError, Exception) as e:
                log.warning("Kokoro init failed: %s", e)
                self._kokoro_failed = True
                self._speak_say(text)
                return

        try:
            import numpy as np

            samples, sr = self._kokoro.create(
                text,
                voice=self._config.kokoro_voice,
                speed=self._config.kokoro_speed,
            )
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                import wave

                with wave.open(f, "wb") as wf:
                    wf.setnchannels(1)
                    wf.setsampwidth(2)
                    wf.setframerate(sr)
                    wf.writeframes((samples * 32767).astype(np.int16).tobytes())
                tmp_path = f.name

            subprocess.run(["afplay", tmp_path], timeout=30, capture_output=True)
            os.unlink(tmp_path)
        except Exception as e:
            log.debug("Kokoro speak failed: %s", e)
            self._speak_say(text)

    def _speak_say(self, text: str):
        """macOS native TTS via `say` command."""
        clean = text.replace('"', '\\"')[:500]
        try:
            subprocess.run(
                ["say", "-v", self._config.tts_voice, clean],
                timeout=30,
                capture_output=True,
            )
        except Exception:
            pass

    def _speak_elevenlabs(self, text: str):
        try:
            from elevenlabs import ElevenLabs
            from elevenlabs import stream as el_stream

            if self._elevenlabs_client is None:
                self._elevenlabs_client = ElevenLabs(api_key=self._config.elevenlabs_api_key)

            audio_stream = self._elevenlabs_client.generate(
                text=text[:500],
                voice=self._config.elevenlabs_voice_id,
                model="eleven_multilingual_v2",
                stream=True,
            )
            el_stream(audio_stream)
        except ImportError:
            self._speak_say(text)
        except Exception as e:
            log.debug("ElevenLabs failed: %s", e)
            self._speak_say(text)

    @staticmethod
    def _strip_code_blocks(text: str) -> str:
        return re.sub(r"```[\s\S]*?```", "", text).strip()

    @staticmethod
    def _extract_summary(text: str) -> str:
        sentences = re.split(r"(?<=[.!?])\s+", text)
        if sentences:
            summary = sentences[0]
            if len(summary.split()) < 20 and len(sentences) > 1:
                summary += " " + sentences[1]
            return summary
        return text[:200]

    def mute(self):
        self._enabled = False

    def unmute(self):
        self._enabled = self._config.tts_backend != "off"

    @property
    def is_muted(self) -> bool:
        return not self._enabled
