"""Reasoning utilities -- query classification and objective reasoning (zero LLM cost)."""

import enum
import re


class QueryType(str, enum.Enum):
    CHAT = "chat"
    FACTUAL_SIMPLE = "factual_simple"
    OPINION = "opinion"
    RECOMMENDATION = "recommendation"
    COMPLEX_REASONING = "complex_reasoning"


_CHAT_PATTERNS = re.compile(
    r"^(hi|hello|hey|thanks|thank you|bye|goodbye|good morning|good night|gm|gn)\b",
    re.IGNORECASE,
)

_RECOMMENDATION_PATTERNS = re.compile(
    r"(should i|recommend|best option|which one|advice|pros and cons|worth it|"
    r"choose between|prefer|better to|what would you suggest|which is better)",
    re.IGNORECASE,
)

_OPINION_PATTERNS = re.compile(
    r"(what do you think|your opinion|do you agree|how do you feel|your take)",
    re.IGNORECASE,
)

_COMPLEX_PATTERNS = re.compile(
    r"(explain why|compare|analyze|trade-offs|tradeoffs|why does|evaluate|"
    r"critically|debate|break down|what are the implications)",
    re.IGNORECASE,
)

_STAKES_KEYWORDS = [
    "assignment",
    "exam",
    "grade",
    "thesis",
    "dissertation",
    "interview",
    "job",
    "career",
    "medical",
    "health",
    "legal",
    "contract",
    "investment",
    "financial",
    "money",
    "deadline",
]


def classify_query(text: str) -> QueryType:
    """Classify user input into query type. Zero LLM cost (regex only)."""
    stripped = text.strip()

    if len(stripped.split()) <= 3 and _CHAT_PATTERNS.match(stripped):
        return QueryType.CHAT

    if _RECOMMENDATION_PATTERNS.search(stripped):
        return QueryType.RECOMMENDATION

    if _OPINION_PATTERNS.search(stripped):
        return QueryType.OPINION

    if _COMPLEX_PATTERNS.search(stripped):
        return QueryType.COMPLEX_REASONING

    return QueryType.FACTUAL_SIMPLE


def detect_stakes(text: str) -> str | None:
    """Detect high-stakes context. Returns caveat string or None."""
    lower = text.lower()
    if any(kw in lower for kw in _STAKES_KEYWORDS):
        return (
            "Note: This touches on an important decision. "
            "I have reasoned through this objectively, but verify "
            "critical details independently before acting."
        )
    return None


def get_reasoning_instruction(query_type: QueryType) -> str | None:
    """Return a prompt instruction for objective reasoning. None if not needed."""
    if query_type in (QueryType.CHAT, QueryType.FACTUAL_SIMPLE):
        return None

    return (
        "[Reasoning mode: For this query, reason objectively first. "
        "Consider multiple perspectives and trade-offs before forming "
        "a recommendation. Do not let user preferences bias your analysis. "
        "Present honest trade-offs, then personalize your recommendation.]"
    )
