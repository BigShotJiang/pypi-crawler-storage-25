"""Delegate -- the brain's tool for routing tasks to specialized agents."""

import logging

from pydantic_ai import RunContext

from phoenix.core.factory import build_agent
from phoenix.core.registry import get_registry

log = logging.getLogger(__name__)


async def delegate(ctx: RunContext, task: str, agent: str = "worker") -> str:
    """Delegate a task to a specialized agent.

    Each agent runs in a fresh context window with its own tools.
    The result is returned as a string to the brain.

    Args:
        task: Description of what needs to be done.
        agent: Agent name (worker, explorer, planner, etc.).
    """
    registry = get_registry()

    if agent not in registry.list_agents():
        available = ", ".join(registry.list_agents())
        return f"Unknown agent '{agent}'. Available agents: {available}"

    if agent == "brain":
        return "Cannot delegate to self. Choose a specialized agent."

    log.info("Delegating to '%s': %s", agent, task[:100])

    try:
        subagent = build_agent(
            agent_name=agent,
            registry=registry,
            project_context="",
        )
        result = await subagent.run(task)
        output = str(result.output)
        log.info("Delegate '%s' returned %d chars", agent, len(output))
        return output
    except Exception as e:
        log.error("Delegation to '%s' failed: %s", agent, e)
        return f"Delegation to '{agent}' failed: {e}"
