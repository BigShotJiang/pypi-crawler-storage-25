"""Factory -- builds pydantic-ai Agent instances from YAML personality configs."""

import logging

from pydantic_ai import Agent
from pydantic_ai.settings import ModelSettings

from phoenix.abilities import PhoenixContext
from phoenix.config.settings import resolve_model
from phoenix.core.interceptor import Interceptor
from phoenix.core.registry import Registry
from phoenix.personality.parser import (
    build_system_prompt,
    load_defaults,
    merge_config,
)

log = logging.getLogger(__name__)


def build_agent(
    agent_name: str,
    registry: Registry,
    project_context: str = "",
    extra_tools: list | None = None,
    phoenix_context: PhoenixContext | None = None,
    model_override: str | None = None,
    hook_runner=None,
) -> Agent:
    """Build a pydantic-ai Agent from a YAML personality config.

    1. Reads AgentConfig from registry
    2. Merges with phoenix.yaml defaults
    3. Builds system prompt
    4. Resolves abilities, wraps with interceptor
    5. Returns configured pydantic_ai.Agent
    """
    config = registry.get_agent_config(agent_name)
    if config is None:
        raise ValueError(f"Unknown agent '{agent_name}'. Available: {registry.list_agents()}")

    defaults = load_defaults()
    merged = merge_config(defaults, config)
    prompt = build_system_prompt(merged, defaults, project_context)

    model = resolve_model(model_override or merged.model)

    interceptor = Interceptor(hook_runner=hook_runner)
    tools = []

    for ability_info in registry.get_agent_abilities(agent_name):
        wrapped = interceptor.wrap(ability_info, context=phoenix_context)
        tools.append(wrapped)

    if extra_tools:
        tools.extend(extra_tools)

    log.info(
        "Built agent '%s' with %d tools, model=%s",
        agent_name,
        len(tools),
        model if isinstance(model, str) else type(model).__name__,
    )

    return Agent(
        model,
        instructions=prompt,
        tools=tools,
        model_settings=ModelSettings(parallel_tool_calls=True),
    )
