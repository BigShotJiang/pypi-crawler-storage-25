"""Engine -- the central orchestrator that boots and runs Phoenix."""

import logging
from typing import Any

from pydantic_ai import Agent

from phoenix.abilities import PhoenixContext
from phoenix.config.settings import PHOENIX_DIR, get_model
from phoenix.core.context import scan_project
from phoenix.core.delegate import delegate
from phoenix.core.factory import build_agent
from phoenix.core.reasoning import classify_query, detect_stakes, get_reasoning_instruction
from phoenix.core.registry import Registry, get_registry

log = logging.getLogger(__name__)


class PhoenixEngine:
    """Central orchestrator -- boots the system, manages the agent lifecycle."""

    def __init__(self):
        self._registry: Registry | None = None
        self._agent: Agent | None = None
        self._project_context: str = ""
        self._memory: Any = None

    async def boot(self, memory: Any = None, hook_runner=None):
        """Initialize the engine: discover plugins, build brain agent."""
        self._memory = memory
        self._hook_runner = hook_runner
        self._registry = get_registry()
        self._registry.discover_all()

        self._project_context = scan_project()

        context = PhoenixContext(
            config={"phoenix_dir": str(PHOENIX_DIR), "model": get_model()},
            memory=self._memory,
            agent_name="brain",
        )

        self._agent = build_agent(
            agent_name="brain",
            registry=self._registry,
            project_context=self._project_context,
            extra_tools=[delegate],
            phoenix_context=context,
            hook_runner=hook_runner,
        )

        abilities = self._registry.list_abilities()
        agents = self._registry.list_agents()
        log.info("Phoenix booted: %d abilities, %d agents", len(abilities), len(agents))

    @property
    def agent(self) -> Agent:
        if self._agent is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._agent

    @property
    def registry(self) -> Registry:
        if self._registry is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._registry

    async def run_turn(
        self,
        user_input: str,
        history: list | None = None,
    ) -> tuple[str, list]:
        """Execute a single conversation turn.

        Returns (ai_output_text, updated_history).
        """
        history = history or []

        # Memory pre-turn (stub until Phase 3)
        memory_context = ""
        if self._memory and hasattr(self._memory, "pre_turn"):
            try:
                memory_context = self._memory.pre_turn(user_input)
            except Exception as e:
                log.warning("Memory pre_turn failed: %s", e)

        # Query classification + reasoning instruction (zero LLM cost)
        query_type = classify_query(user_input)
        reasoning = get_reasoning_instruction(query_type)
        stakes = detect_stakes(user_input)

        # Build final prompt
        prompt_parts = []
        if memory_context:
            prompt_parts.append(memory_context)
        if reasoning:
            prompt_parts.append(reasoning)
        prompt_parts.append(user_input)
        prompt = "\n\n".join(prompt_parts)

        # Run agent
        result = await self.agent.run(prompt, message_history=history)
        output = str(result.output)

        if stakes:
            output = f"{stakes}\n\n{output}"

        updated_history = result.all_messages()

        # Memory post-turn (stub until Phase 3)
        if self._memory and hasattr(self._memory, "post_turn"):
            try:
                self._memory.post_turn(
                    user_input=user_input,
                    ai_output=output,
                )
            except Exception as e:
                log.warning("Memory post_turn failed: %s", e)

        return output, updated_history

    async def run_stream(
        self,
        user_input: str,
        history: list | None = None,
    ):
        """Execute a turn with streaming. Yields text deltas.

        Returns (full_output, updated_history) after stream completes.
        """
        history = history or []

        memory_context = ""
        if self._memory and hasattr(self._memory, "pre_turn"):
            try:
                memory_context = self._memory.pre_turn(user_input)
            except Exception as e:
                log.warning("Memory pre_turn failed: %s", e)

        query_type = classify_query(user_input)
        reasoning = get_reasoning_instruction(query_type)

        prompt_parts = []
        if memory_context:
            prompt_parts.append(memory_context)
        if reasoning:
            prompt_parts.append(reasoning)
        prompt_parts.append(user_input)
        prompt = "\n\n".join(prompt_parts)

        async with self.agent.run_stream(prompt, message_history=history) as stream:
            chunks = []
            async for text in stream.stream_text(delta=True):
                chunks.append(text)
                yield text

            full_output = "".join(chunks)
            updated_history = stream.all_messages()

        stakes = detect_stakes(user_input)
        if stakes:
            full_output = f"{stakes}\n\n{full_output}"

        if self._memory and hasattr(self._memory, "post_turn"):
            try:
                self._memory.post_turn(user_input=user_input, ai_output=full_output)
            except Exception as e:
                log.warning("Memory post_turn failed: %s", e)

        self._last_output = full_output
        self._last_history = updated_history

    @property
    def last_output(self) -> str:
        return getattr(self, "_last_output", "")

    @property
    def last_history(self) -> list:
        return getattr(self, "_last_history", [])
