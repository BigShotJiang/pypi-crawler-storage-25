# Phoenix

A modular AI agent operating system. Persistent memory, multi-agent delegation,
background intelligence, voice I/O -- built for extensibility.

Phoenix is not a chatbot. It is an autonomous agent that thinks, remembers,
delegates, and acts. Add abilities by dropping a Python file. Add agents by
dropping a YAML file. No wiring, no registration, no boilerplate.

## Install

```bash
# Clone and install
git clone https://github.com/harshalmore31/phoenix-os.git
cd phoenix-os
pip install -e .

# Copy env template and add your API key
cp .env.example .env
# Edit .env with your API key
```

Optional extras:

```bash
pip install -e ".[embeddings]"  # FastEmbed for memory (recommended)
pip install -e ".[voice]"       # Wake word + STT + TTS
pip install -e ".[browser]"     # Web automation
pip install -e ".[pdf]"         # PDF text extraction
pip install -e ".[all]"         # Everything
```

Or install from PyPI:

```bash
pip install phoenix-os
```

## Quick Start

```bash
# Set your model and API key
export PHOENIX_MODEL=anthropic:claude-sonnet-4-20250514
export ANTHROPIC_API_KEY=sk-...

# Run
phoenix
```

## Supported Models

Phoenix works with any model provider supported by pydantic-ai:

| Provider | Example | Env Variable |
|----------|---------|-------------|
| Anthropic | `anthropic:claude-sonnet-4-20250514` | `ANTHROPIC_API_KEY` |
| OpenAI | `openai:gpt-4o` | `OPENAI_API_KEY` |
| Google Gemini | `google-gla:gemini-2.0-flash` | `GEMINI_API_KEY` |
| Groq | `groq:llama-3.3-70b-versatile` | `GROQ_API_KEY` |
| Mistral | `mistral:mistral-large-latest` | `MISTRAL_API_KEY` |
| DeepSeek | `deepseek:deepseek-chat` | `DEEPSEEK_API_KEY` |
| Ollama (local, free) | `ollama:llama3:8b` | None needed |
| OpenRouter | `openrouter:...` | `OPENROUTER_API_KEY` |

```bash
# Anthropic
phoenix --model anthropic:claude-sonnet-4-20250514

# OpenAI
phoenix --model openai:gpt-4o

# Ollama (local, free -- no API key)
phoenix --model ollama:llama3:8b

# Groq (fast inference)
phoenix --model groq:llama-3.3-70b-versatile
```

## Usage

```
phoenix                     # Start new session
phoenix --continue          # Resume last session
phoenix --resume SESSION_ID # Resume specific session
phoenix --sessions          # List saved sessions
phoenix --model openai:gpt-4o  # Override model
phoenix --auto              # Auto-approve file edits
phoenix --yolo              # Auto-approve everything
phoenix --voice             # Enable voice I/O
```

### Shell Commands

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/tools` | List available abilities |
| `/agents` | List available agents |
| `/memory` | Show memory stats |
| `/model` | Show or switch model |
| `/mode` | Show or switch approval mode (safe/auto/yolo) |
| `/cost` | Show token usage |
| `/sessions` | List saved sessions |
| `/clear` | Clear conversation history |
| `/bye` | Exit |

## Architecture

```
src/phoenix/
    core/           # Engine -- builds agents, routes delegation, discovers plugins
    abilities/      # What Phoenix can do -- each file is one pluggable capability
    memory/         # What Phoenix remembers -- episodic persistence across sessions
    personality/    # Who Phoenix is -- YAML agent definitions + prompt generation
    ambient/        # What Phoenix watches -- background intelligence, zero-token
    voice/          # How Phoenix speaks/listens -- wake word, STT, TTS
    shell/          # How users interact -- CLI loop, commands, sessions
    hooks/          # How Phoenix extends -- lifecycle event hooks
    config/         # How Phoenix is configured -- env, models, paths
```

### Adding an Ability

Drop a Python file in `abilities/` with the `@ability` decorator:

```python
# abilities/weather.py
from phoenix.abilities import ability

@ability(name="weather", description="Get current weather")
async def weather(city: str) -> str:
    """Fetch weather for a city."""
    # your implementation
    return f"Weather in {city}: sunny, 22C"
```

Then add `weather` to any agent's YAML abilities list. Done.

**Three tiers:**

1. **Simple** -- function with `@ability`. No Phoenix knowledge needed.
2. **With approval** -- same function. Interceptor handles permissions externally.
3. **With context** -- add `ctx: PhoenixContext` parameter for memory, config, logging.

```python
from phoenix.abilities import ability, PhoenixContext

@ability(name="smart_search", description="Search with memory context")
async def smart_search(ctx: PhoenixContext, query: str) -> str:
    """Search informed by what Phoenix remembers."""
    past = ctx.memory.pre_turn(query) if ctx.memory else ""
    # use past context to refine search
    return f"Results for: {query}"
```

### Adding an Agent

Drop a YAML file in `personality/agents/`:

```yaml
# personality/agents/researcher.yaml
name: researcher
role: "Deep research and analysis"
tone:
  - thorough
  - analytical

rules:
  - "Always cite sources"
  - "Cross-reference multiple sources"

abilities:
  - read_file
  - grep
  - bash

meta:
  category: community
```

No Python changes needed. Phoenix auto-discovers it at startup.

### Memory System

Phoenix remembers across sessions. Every conversation:

1. **Extract** -- equation-based fact extraction from user input (zero LLM cost)
2. **Gate** -- novelty filtering, contradiction detection, output-aware gating
3. **Store** -- SQLite with graph edges connecting related memories
4. **Recall** -- semantic similarity + strength + recency + graph activation
5. **Feedback** -- memories the AI actually uses get stronger

Memory is what makes Phoenix alive. It learns preferences, tracks contradictions,
consolidates raw facts into patterns, and adapts over time.

### Ambient Intelligence

Background daemon monitors system state (battery, disk, session length, time)
and selectively nudges when genuinely useful. Zero tokens until something
is worth saying. Token-budgeted (5000/day with emergency reserve).

### Voice

Optional. Say "Phoenix" to activate, speak naturally, get spoken responses.
Supports Groq Whisper (cloud STT), Kokoro (local TTS), with macOS say fallback.

```bash
pip install phoenix-os[voice]
phoenix --voice
```

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `PHOENIX_MODEL` | `anthropic:claude-sonnet-4-20250514` | Model to use |
| `PHOENIX_DIR` | `~/.phoenix` | Data directory |
| `PHOENIX_LOG_LEVEL` | `WARNING` | Logging level |
| `ANTHROPIC_API_KEY` | -- | Anthropic API key |
| `OPENAI_API_KEY` | -- | OpenAI API key |
| `GROQ_API_KEY` | -- | Groq API key (for voice STT) |
| `PICOVOICE_ACCESS_KEY` | -- | Picovoice key (for wake word) |

## Hooks

Create `hooks_config.json` in your project root:

```json
{
  "hooks": {
    "pre_turn": [
      {"command": "echo 'User said something'", "action": "log"}
    ],
    "pre_tool": [
      {"match": "bash", "command": "./approve.sh", "action": "approve_or_deny"}
    ]
  }
}
```

Events: `pre_tool`, `post_tool`, `pre_turn`, `post_turn`, `on_error`.

## License

Apache 2.0
