# Changelog

All notable changes to the `sportscore` Python client will be documented here.
Format loosely follows [Keep a Changelog](https://keepachangelog.com/).

## [0.2.0] — 2026-04-24

### Added
- Opt-out install-ping beacon on first `SportScoreClient()` instantiation.
  One fire-and-forget POST to `/api/mcp/ping/` on a daemon thread with
  `{client, version, transport, host, python}`. Opt out with
  `SPORTSCORE_NO_TELEMETRY=1`.
- Two new tests verifying opt-out and once-per-process semantics.

## [0.1.0] — 2026-04-24

First public release. Mirrors the 8 tools exposed by the
[sportscore-mcp](https://github.com/Backspace-me/sportscore-mcp) MCP server,
but as plain sync + async Python methods.

### Added
- `SportScoreClient` (sync, `httpx.Client`-backed)
- `AsyncSportScoreClient` (async, `httpx.AsyncClient`-backed)
- 8 methods each: `get_matches`, `get_match_detail`, `get_team_schedule`,
  `get_standings`, `get_top_scorers`, `get_player`, `get_bracket`,
  `get_tracker`
- `SportScoreError` exception type for non-2xx responses
- Built-in attribution helper: `client.attribution_line()` and
  `client.attribution_html()` so the free-tier dofollow backlink is one line
  of code to surface in your UI
- Context-manager support (`with SportScoreClient() as c: ...`) for both sync
  and async variants
- Typed public API (`py.typed` marker included)
