"""Python client for the free SportScore sports-data API.

Quickstart
----------
.. code-block:: python

    from sportscore import SportScoreClient

    with SportScoreClient() as sc:
        matches = sc.get_matches("football", limit=5)
        for m in matches["data"]:
            print(m["home_team"], m["score"], m["away_team"])
        print(sc.attribution_line())  # "Powered by SportScore — https://sportscore.com/"

Async variant:

.. code-block:: python

    from sportscore import AsyncSportScoreClient

    async with AsyncSportScoreClient() as sc:
        matches = await sc.get_matches("football", limit=5)

Attribution
-----------
The remote API is governed by
https://sportscore.com/developers/terms/ — the free tier requires a
visible "Powered by SportScore" dofollow backlink on pages that render the
returned data. Use :meth:`SportScoreClient.attribution_html` (or the badge
gallery at https://sportscore.com/developers/#badges) to drop that link
in.
"""
from ._version import __version__
from .client import (
    AsyncSportScoreClient,
    SportScoreClient,
    SportScoreError,
)

__all__ = [
    "AsyncSportScoreClient",
    "SportScoreClient",
    "SportScoreError",
    "__version__",
]
