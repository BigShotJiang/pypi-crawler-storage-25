"""SportScore HTTP client — sync and async variants on top of ``httpx``.

Mirrors the 8-tool surface exposed by ``sportscore-mcp`` (see
https://github.com/Backspace-me/sportscore-mcp) one-to-one so documentation
transfers between the two.

All methods return the parsed JSON body from the SportScore API. On non-2xx
responses a :class:`SportScoreError` is raised with the status code and the
decoded body available as attributes for structured error handling.
"""
from __future__ import annotations

import os
import platform
import sys
import threading
from types import TracebackType
from typing import Any, Literal, Optional

import httpx

from ._version import __version__

Sport = Literal["football", "basketball", "cricket", "tennis"]
ScorerStat = Literal["goals", "assists"]

DEFAULT_API_BASE = "https://sportscore.com"
DEFAULT_USER_AGENT = f"sportscore-py/{__version__} (+https://sportscore.com/developers/)"
DEFAULT_TIMEOUT = 15.0

ATTRIBUTION_LINE = "Powered by SportScore — https://sportscore.com/"
ATTRIBUTION_HTML = (
    '<a href="https://sportscore.com/" rel="dofollow" '
    'title="Sports data by SportScore">Powered by SportScore</a>'
)

_SPORTS: tuple[Sport, ...] = ("football", "basketball", "cricket", "tennis")

# --- Opt-out install-ping beacon -------------------------------------------
#
# Fires ONCE per process (first client instantiation) in a daemon thread so
# it never blocks. Sends {client, version, transport, host, python}. No user
# id, no IP, no cookies. Opt out with SPORTSCORE_NO_TELEMETRY=1.
_PING_SENT = False
_PING_LOCK = threading.Lock()


def _send_install_ping(api_base: str, user_agent: str) -> None:
    """Best-effort fire-and-forget install beacon. Never raises."""
    global _PING_SENT
    if os.environ.get("SPORTSCORE_NO_TELEMETRY") == "1":
        return
    with _PING_LOCK:
        if _PING_SENT:
            return
        _PING_SENT = True

    def _worker() -> None:
        try:
            payload = {
                "client": "sportscore-py",
                "version": __version__,
                "transport": "python",
                "host": sys.platform,
                "python": platform.python_version(),
            }
            httpx.post(
                f"{api_base.rstrip('/')}/api/mcp/ping/",
                json=payload,
                headers={"User-Agent": user_agent},
                timeout=3.0,
            )
        except Exception:
            # Telemetry is strictly best-effort.
            pass

    t = threading.Thread(target=_worker, name="sportscore-install-ping", daemon=True)
    t.start()


class SportScoreError(Exception):
    """Raised when the API returns a non-2xx status code.

    Attributes
    ----------
    status_code:
        HTTP status code from the upstream response.
    body:
        Decoded response body (JSON if parseable, otherwise a ``{"raw": str}``
        dict with the raw text).
    url:
        Final URL that produced the error (with query string).
    """

    def __init__(self, status_code: int, body: Any, url: str) -> None:
        self.status_code = status_code
        self.body = body
        self.url = url
        super().__init__(f"SportScore API returned {status_code} for {url}: {body!r}")


def _validate_sport(sport: str) -> None:
    if sport not in _SPORTS:
        raise ValueError(
            f"sport must be one of {_SPORTS!r}, got {sport!r}"
        )


def _params(**kwargs: Any) -> dict[str, Any]:
    """Drop keys whose value is ``None`` — httpx sends everything else as-is."""
    return {k: v for k, v in kwargs.items() if v is not None}


def _handle_response(response: httpx.Response) -> Any:
    """Parse JSON, raise :class:`SportScoreError` on non-2xx."""
    try:
        body: Any = response.json()
    except ValueError:
        body = {"raw": response.text}
    if response.status_code >= 400:
        raise SportScoreError(response.status_code, body, str(response.request.url))
    return body


class _BaseClient:
    """Shared config + helpers between sync and async variants."""

    def __init__(
        self,
        *,
        api_base: str = DEFAULT_API_BASE,
        user_agent: str = DEFAULT_USER_AGENT,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_base = api_base.rstrip("/")
        self.user_agent = user_agent
        self.timeout = timeout

    @property
    def headers(self) -> dict[str, str]:
        return {"Accept": "application/json", "User-Agent": self.user_agent}

    @staticmethod
    def attribution_line() -> str:
        """Return the plain-text attribution line ready for display."""
        return ATTRIBUTION_LINE

    @staticmethod
    def attribution_html() -> str:
        """Return a ready-to-embed HTML snippet with ``rel="dofollow"``.

        See the full badge gallery (6 pre-built variants — dark pill, light
        pill, minimal, tiny circle, amber accent, stat-block footer) at
        https://sportscore.com/developers/#badges.
        """
        return ATTRIBUTION_HTML


class SportScoreClient(_BaseClient):
    """Synchronous client. Thread-safe enough for typical web-app use."""

    def __init__(
        self,
        *,
        api_base: str = DEFAULT_API_BASE,
        user_agent: str = DEFAULT_USER_AGENT,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(api_base=api_base, user_agent=user_agent, timeout=timeout)
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(
            base_url=self.api_base,
            timeout=self.timeout,
            headers=self.headers,
        )
        _send_install_ping(self.api_base, self.user_agent)

    def __enter__(self) -> "SportScoreClient":
        return self

    def __exit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    # --- Low-level ---------------------------------------------------------

    def _get(self, path: str, params: dict[str, Any]) -> Any:
        response = self._client.get(path, params=params)
        return _handle_response(response)

    # --- Tool methods (mirror sportscore-mcp) ------------------------------

    def get_matches(self, sport: Sport, *, limit: int = 10) -> Any:
        """List live and recent matches for a sport.

        Good default for "what's happening in football right now?".
        """
        _validate_sport(sport)
        return self._get("/api/widget/matches/", _params(sport=sport, limit=limit))

    def get_match_detail(self, sport: Sport, slug: str) -> Any:
        """Get detailed data for a single match by slug."""
        _validate_sport(sport)
        return self._get("/api/widget/match/", _params(sport=sport, slug=slug))

    def get_team_schedule(self, sport: Sport, slug: str, *, limit: int = 10) -> Any:
        """Get a team's past and upcoming fixtures by team slug."""
        _validate_sport(sport)
        return self._get(
            "/api/widget/team/", _params(sport=sport, slug=slug, limit=limit)
        )

    def get_standings(self, sport: Sport, slug: str) -> Any:
        """Get the current standings table for a league or competition."""
        _validate_sport(sport)
        return self._get("/api/widget/standings/", _params(sport=sport, slug=slug))

    def get_top_scorers(
        self,
        sport: Sport,
        slug: str,
        *,
        limit: int = 20,
        stat: ScorerStat = "goals",
    ) -> Any:
        """Get top scorers (or assisters) for a competition."""
        _validate_sport(sport)
        return self._get(
            "/api/widget/topscorers/",
            _params(sport=sport, slug=slug, limit=limit, stat=stat),
        )

    def get_player(self, sport: Sport, slug: str) -> Any:
        """Get player statistics and metadata by player slug."""
        _validate_sport(sport)
        return self._get("/api/widget/player/", _params(sport=sport, slug=slug))

    def get_bracket(self, sport: Sport, slug: str) -> Any:
        """Get the knockout bracket for a tournament."""
        _validate_sport(sport)
        return self._get("/api/widget/bracket/", _params(sport=sport, slug=slug))

    def get_tracker(self, sport: Sport, match_id: str) -> Any:
        """Get live match tracker data by numeric match id. Football only."""
        _validate_sport(sport)
        return self._get("/api/widget/tracker/", _params(sport=sport, id=match_id))


class AsyncSportScoreClient(_BaseClient):
    """Asynchronous client. Drop-in async twin of :class:`SportScoreClient`."""

    def __init__(
        self,
        *,
        api_base: str = DEFAULT_API_BASE,
        user_agent: str = DEFAULT_USER_AGENT,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(api_base=api_base, user_agent=user_agent, timeout=timeout)
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient(
            base_url=self.api_base,
            timeout=self.timeout,
            headers=self.headers,
        )
        _send_install_ping(self.api_base, self.user_agent)

    async def __aenter__(self) -> "AsyncSportScoreClient":
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    # --- Low-level ---------------------------------------------------------

    async def _get(self, path: str, params: dict[str, Any]) -> Any:
        response = await self._client.get(path, params=params)
        return _handle_response(response)

    # --- Tool methods ------------------------------------------------------

    async def get_matches(self, sport: Sport, *, limit: int = 10) -> Any:
        """List live and recent matches for a sport."""
        _validate_sport(sport)
        return await self._get("/api/widget/matches/", _params(sport=sport, limit=limit))

    async def get_match_detail(self, sport: Sport, slug: str) -> Any:
        """Get detailed data for a single match by slug."""
        _validate_sport(sport)
        return await self._get("/api/widget/match/", _params(sport=sport, slug=slug))

    async def get_team_schedule(self, sport: Sport, slug: str, *, limit: int = 10) -> Any:
        """Get a team's past and upcoming fixtures."""
        _validate_sport(sport)
        return await self._get(
            "/api/widget/team/", _params(sport=sport, slug=slug, limit=limit)
        )

    async def get_standings(self, sport: Sport, slug: str) -> Any:
        """Get the current standings table."""
        _validate_sport(sport)
        return await self._get("/api/widget/standings/", _params(sport=sport, slug=slug))

    async def get_top_scorers(
        self,
        sport: Sport,
        slug: str,
        *,
        limit: int = 20,
        stat: ScorerStat = "goals",
    ) -> Any:
        """Get top scorers (or assisters) for a competition."""
        _validate_sport(sport)
        return await self._get(
            "/api/widget/topscorers/",
            _params(sport=sport, slug=slug, limit=limit, stat=stat),
        )

    async def get_player(self, sport: Sport, slug: str) -> Any:
        """Get player statistics and metadata by player slug."""
        _validate_sport(sport)
        return await self._get("/api/widget/player/", _params(sport=sport, slug=slug))

    async def get_bracket(self, sport: Sport, slug: str) -> Any:
        """Get the knockout bracket for a tournament."""
        _validate_sport(sport)
        return await self._get("/api/widget/bracket/", _params(sport=sport, slug=slug))

    async def get_tracker(self, sport: Sport, match_id: str) -> Any:
        """Get live match tracker data by numeric match id. Football only."""
        _validate_sport(sport)
        return await self._get("/api/widget/tracker/", _params(sport=sport, id=match_id))
