"""Git worktree management for Synapse.

Provides agent-agnostic worktree isolation so that any CLI agent
(Claude, Gemini, Codex, OpenCode, Copilot) can work in its own
checkout without file conflicts.

Worktrees are placed under ``.synapse/worktrees/<name>/`` with a
branch named ``worktree-<name>``.
"""

from __future__ import annotations

import filecmp
import json
import logging
import random
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

_GH_PR_LIST_TIMEOUT_SECS = 5

logger = logging.getLogger(__name__)

# ============================================================
# Data
# ============================================================


@dataclass
class WorktreeInfo:
    """Metadata for a created worktree."""

    name: str  # e.g., "bright-falcon"
    path: Path  # e.g., /repo/.synapse/worktrees/bright-falcon
    branch: str  # e.g., "worktree-bright-falcon"
    base_branch: str  # e.g., "origin/main"
    created_at: float


# ============================================================
# Name generation (adjective-noun)
# ============================================================

_ADJECTIVES = [
    "bold",
    "brave",
    "bright",
    "calm",
    "cool",
    "crisp",
    "dark",
    "deep",
    "fair",
    "fast",
    "firm",
    "glad",
    "gold",
    "grand",
    "keen",
    "kind",
    "late",
    "lean",
    "live",
    "long",
    "mild",
    "neat",
    "nice",
    "pale",
    "pure",
    "rare",
    "rich",
    "safe",
    "slim",
    "soft",
    "sure",
    "tall",
    "thin",
    "true",
    "vast",
    "warm",
    "wide",
    "wild",
    "wise",
    "young",
]

_NOUNS = [
    "ant",
    "bat",
    "bear",
    "bird",
    "bull",
    "cat",
    "colt",
    "crow",
    "deer",
    "dove",
    "duck",
    "fawn",
    "fish",
    "fox",
    "frog",
    "goat",
    "hare",
    "hawk",
    "jay",
    "lark",
    "lion",
    "lynx",
    "mole",
    "moth",
    "newt",
    "owl",
    "puma",
    "ram",
    "seal",
    "swan",
    "toad",
    "vole",
    "wasp",
    "wolf",
    "wren",
    "yak",
    "ape",
    "elk",
    "emu",
    "koi",
]


def generate_worktree_name() -> str:
    """Generate a random adjective-noun name for a worktree."""
    adj = random.choice(_ADJECTIVES)
    noun = random.choice(_NOUNS)
    return f"{adj}-{noun}"


# ============================================================
# Git helpers
# ============================================================


def get_git_root() -> Path:
    """Return the root directory of the current git repository.

    Note:
        Inside a git worktree this returns the *worktree's* toplevel,
        not the original repo root. For worktree creation use
        :func:`get_main_repo_root` instead so that nested worktrees do
        not accumulate (issue #546).

    Raises:
        RuntimeError: If not inside a git repository.
    """
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError("Not a git repository")
    return Path(result.stdout.strip())


def get_main_repo_root() -> Path:
    """Return the original repo root, even when called from a worktree.

    Uses ``git rev-parse --git-common-dir`` to locate the *main*
    ``.git`` directory (which is shared across all worktrees) and
    returns its parent. This guarantees that worktree creation always
    targets ``<main-repo>/.synapse/worktrees/<name>`` rather than a
    nested path under another worktree (issue #546).

    Raises:
        RuntimeError: If not inside a git repository.
    """
    result = subprocess.run(
        ["git", "rev-parse", "--git-common-dir"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError("Not a git repository")
    common_dir = Path(result.stdout.strip())
    if not common_dir.is_absolute():
        # Git returns ``.git`` relative to the current working directory
        # for the main checkout. Anchor it before stripping the suffix.
        common_dir = (Path.cwd() / common_dir).resolve()
    return common_dir.parent


def is_path_in_worktree(path: Path) -> bool:
    """Return True if ``path`` is inside a git worktree (not the main checkout).

    Uses the canonical git convention: a worktree's ``.git`` is a text
    file (``gitdir: ...``); the main repo's ``.git`` is a directory.
    Pure-Python — no subprocess.
    """
    git_marker = path / ".git"
    return git_marker.is_file()


def sync_worktree_agents_to_main(worktree_path: Path, main_root: Path) -> list[Path]:
    """Copy saved worktree agent definitions back to the main repo.

    Main-repo files win on collisions. Identical collisions are ignored;
    differing collisions are logged so users can reconcile manually.
    """
    agents_dir = worktree_path / ".synapse" / "agents"
    if not agents_dir.is_dir():
        return []

    sources = sorted(agents_dir.glob("*.agent"))
    if not sources:
        return []

    target_dir = main_root / ".synapse" / "agents"
    target_dir.mkdir(parents=True, exist_ok=True)

    copied: list[Path] = []
    for source in sources:
        destination = target_dir / source.name
        try:
            if destination.exists():
                if filecmp.cmp(source, destination, shallow=False):
                    continue
                logger.warning(
                    "event=worktree_agent_sync_collision source=%s destination=%s",
                    source,
                    destination,
                )
                continue
            shutil.copy2(source, destination)
        except OSError:
            logger.warning(
                "event=worktree_agent_sync_failed source=%s destination=%s",
                source,
                destination,
                exc_info=True,
            )
            continue
        copied.append(destination)
    return copied


def _ref_exists(ref: str) -> bool:
    """Check if a git ref exists locally."""
    result = subprocess.run(
        ["git", "rev-parse", "--verify", ref],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def get_default_remote_branch() -> str:
    """Detect the default remote branch (e.g., ``origin/main``).

    Falls back through: symbolic-ref → ``origin/main`` → ``HEAD``.
    Each candidate is verified to exist locally before returning.
    """
    # Try symbolic-ref first
    result = subprocess.run(
        ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        # "refs/remotes/origin/main" -> "origin/main"
        ref = result.stdout.strip().replace("refs/remotes/", "")
        if _ref_exists(ref):
            return ref

    # Fallback to origin/main
    if _ref_exists("origin/main"):
        return "origin/main"

    # Last resort: use current HEAD
    return "HEAD"


# ============================================================
# Worktree lifecycle
# ============================================================


_WORKTREE_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")
_WORKTREE_NAME_MAX_LEN = 100
MAX_AUTO_NAME_ATTEMPTS = 8


def _validate_worktree_name(name: str) -> str:
    """Validate and return a safe worktree name.

    Raises:
        ValueError: If the name contains unsafe characters.
    """
    name = name.strip()
    if not name:
        raise ValueError("Worktree name must not be empty")
    if len(name) > _WORKTREE_NAME_MAX_LEN:
        raise ValueError(
            f"Worktree name too long ({len(name)} chars, max {_WORKTREE_NAME_MAX_LEN})"
        )
    if not _WORKTREE_NAME_RE.match(name):
        raise ValueError(
            f"Invalid worktree name '{name}': "
            "only alphanumerics, hyphens, dots, and underscores are allowed"
        )
    return name


def _worktree_name_exhausted_error() -> RuntimeError:
    return RuntimeError(
        "Could not allocate a unique worktree name after "
        f"{MAX_AUTO_NAME_ATTEMPTS} attempts. "
        "This usually means stale worktree directories or branches have "
        "accumulated under .synapse/worktrees/. "
        "Run 'git worktree list' to inspect, then prune stale worktrees with "
        "'git worktree remove <path>' or 'git worktree prune'."
    )


def _worktree_directory_exists_error(worktree_dir: Path) -> RuntimeError:
    return RuntimeError(
        f"Worktree directory already exists: {worktree_dir}. "
        f"Run 'git worktree remove {worktree_dir}' to clean it up, "
        "or pass a different --name."
    )


def _worktree_branch_exists_error(branch_name: str) -> RuntimeError:
    return RuntimeError(
        f"Worktree branch already exists: {branch_name}. "
        f"Run 'git branch -D {branch_name}' to delete it, "
        "or pass a different --name."
    )


# Substrings git emits in stderr when `git worktree add` fails because the
# target path or branch ref is already in use. These map to the same
# collision conditions _allocate_worktree_name pre-checks against, so
# encountering them after a successful pre-check signals a TOCTOU race
# (e.g. a parallel spawn raced ahead between the check and the add).
_WORKTREE_ADD_COLLISION_MARKERS = (
    "already exists",  # "fatal: '<path>' already exists"
    "already checked out",  # "fatal: '<branch>' is already checked out"
    "already used by worktree",  # "fatal: '<branch>' is already used by worktree"
)


def _is_worktree_add_collision(stderr: str) -> bool:
    return any(marker in stderr for marker in _WORKTREE_ADD_COLLISION_MARKERS)


def _allocate_worktree_name(git_root: Path, name: str | None) -> tuple[str, Path, str]:
    """Return a validated unique worktree name, directory, and branch."""
    worktrees_dir = git_root / ".synapse" / "worktrees"

    if name is not None:
        validated_name = _validate_worktree_name(name)
        worktree_dir = worktrees_dir / validated_name
        branch_name = f"worktree-{validated_name}"
        if worktree_dir.exists():
            raise _worktree_directory_exists_error(worktree_dir)
        if _ref_exists(branch_name):
            raise _worktree_branch_exists_error(branch_name)
        return validated_name, worktree_dir, branch_name

    for _ in range(MAX_AUTO_NAME_ATTEMPTS):
        candidate = generate_worktree_name()
        worktree_dir = worktrees_dir / candidate
        branch_name = f"worktree-{candidate}"
        if worktree_dir.exists() or _ref_exists(branch_name):
            continue
        return candidate, worktree_dir, branch_name

    raise _worktree_name_exhausted_error()


def create_worktree(
    name: str | None = None,
    base_branch: str | None = None,
) -> WorktreeInfo:
    """Create a new git worktree under ``.synapse/worktrees/``.

    Args:
        name: Worktree name. Auto-generated if None.
        base_branch: Git ref to base the worktree on (e.g. a remote branch).
            Defaults to ``get_default_remote_branch()`` when None.

    Returns:
        WorktreeInfo with path, branch, and metadata.

    Raises:
        RuntimeError: If not in a git repo, directory exists, or git fails.
        ValueError: If the provided name contains unsafe characters.
    """
    # Always anchor new worktrees to the *main* repo root. When the
    # caller is itself running inside a worktree, ``get_git_root``
    # would return the worktree's toplevel and cause nested
    # ``.synapse/worktrees/...`` paths to accumulate (issue #546).
    git_root = get_main_repo_root()
    if base_branch is not None:
        base_branch = base_branch.strip()
        if not base_branch:
            raise ValueError("base_branch must not be empty")
        if base_branch.startswith("-"):
            raise ValueError(
                f"Invalid base_branch '{base_branch}': must not start with '-'"
            )
    else:
        base_branch = get_default_remote_branch()

    requested_name = name
    name, worktree_dir, branch_name = _allocate_worktree_name(git_root, name)

    # Ensure parent directory exists
    worktree_dir.parent.mkdir(parents=True, exist_ok=True)

    # When name is auto-generated, the pre-checks in _allocate_worktree_name
    # are advisory only — a parallel `synapse spawn --worktree` can still
    # race in between the check and `git worktree add`. Retry the full
    # allocate-then-add cycle when git fails with a collision marker so
    # one losing racer falls back to a fresh candidate instead of dying.
    # User-specified names propagate the failure as before; the caller
    # picked a specific name and we do not silently substitute another.
    auto_attempts_left = MAX_AUTO_NAME_ATTEMPTS - 1 if requested_name is None else 0
    while True:
        result = subprocess.run(
            [
                "git",
                "worktree",
                "add",
                str(worktree_dir),
                "-b",
                branch_name,
                base_branch,
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            break
        if (
            requested_name is None
            and auto_attempts_left > 0
            and _is_worktree_add_collision(result.stderr)
        ):
            auto_attempts_left -= 1
            name, worktree_dir, branch_name = _allocate_worktree_name(git_root, None)
            worktree_dir.parent.mkdir(parents=True, exist_ok=True)
            continue
        raise RuntimeError(
            f"Failed to create worktree '{name}': {result.stderr.strip()}"
        )

    logger.info(
        "event=worktree_created name=%s path=%s branch=%s base=%s",
        name,
        worktree_dir,
        branch_name,
        base_branch,
    )

    return WorktreeInfo(
        name=name,
        path=worktree_dir,
        branch=branch_name,
        base_branch=base_branch,
        created_at=time.time(),
    )


def remove_worktree(path: Path, branch: str, force: bool = False) -> bool:
    """Remove a worktree and its branch.

    Args:
        path: Worktree directory path.
        branch: Branch name to delete.
        force: If True, use ``--force`` for removal and ``-D`` for branch.

    Returns:
        True if removal succeeded, False otherwise.
    """
    force_flag = ["--force"] if force else []
    result = subprocess.run(
        ["git", "worktree", "remove", *force_flag, str(path)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.warning(
            "event=worktree_remove_failed path=%s error=%s",
            path,
            result.stderr.strip(),
        )
        return False

    # Delete the branch
    branch_flag = "-D" if force else "-d"
    branch_result = subprocess.run(
        ["git", "branch", branch_flag, branch],
        capture_output=True,
        text=True,
    )
    if branch_result.returncode != 0:
        logger.warning(
            "event=worktree_branch_delete_failed branch=%s error=%s",
            branch,
            branch_result.stderr.strip(),
        )
        # Worktree was removed, branch deletion is best-effort
    else:
        logger.info("event=worktree_removed path=%s branch=%s", path, branch)

    return True


def has_uncommitted_changes(path: Path) -> bool:
    """Check if a worktree directory has uncommitted changes.

    Returns True on subprocess failure to avoid accidental cleanup.
    """
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            cwd=str(path),
        )
    except OSError:
        logger.warning("git status failed for %s", path, exc_info=True)
        return True
    if result.returncode != 0:
        logger.warning(
            "git status returned %d for %s: %s",
            result.returncode,
            path,
            result.stderr.strip(),
        )
        return True
    return bool(result.stdout.strip())


def has_new_commits(path: Path, base_branch: str) -> bool:
    """Check if a worktree branch has commits beyond the base branch.

    Returns True on subprocess failure to avoid accidental cleanup.
    """
    if not base_branch:
        logger.warning("Missing base_branch for %s, treating as modified", path)
        return True
    try:
        result = subprocess.run(
            ["git", "log", f"{base_branch}..HEAD", "--oneline"],
            capture_output=True,
            text=True,
            cwd=str(path),
        )
    except OSError:
        logger.warning("git log failed for %s", path, exc_info=True)
        return True
    if result.returncode != 0:
        logger.warning(
            "git log returned %d for %s: %s",
            result.returncode,
            path,
            result.stderr.strip(),
        )
        return True
    return bool(result.stdout.strip())


def has_worktree_changes(info: WorktreeInfo) -> bool:
    """Check if a worktree has uncommitted changes OR new commits.

    This matches Claude Code's behavior: cleanup prompts when there are
    either uncommitted changes or commits beyond the base branch.
    """
    return has_uncommitted_changes(info.path) or has_new_commits(
        info.path, info.base_branch
    )


def _branch_has_open_pr(branch: str) -> int | None:
    """Return the number of an open GitHub PR whose head is ``branch``, else None.

    Uses ``gh pr list --head <branch> --state open --json number`` so we can
    skip local auto-merge for branches already managed by a PR (issue #714).

    Fail-open contract: any failure mode (gh missing, timeout, non-zero exit,
    malformed JSON) returns ``None`` so that callers fall back to the existing
    merge behaviour rather than blocking ``synapse kill`` on a remote check.
    """
    try:
        result = subprocess.run(
            [
                "gh",
                "pr",
                "list",
                "--head",
                branch,
                "--state",
                "open",
                "--json",
                "number",
            ],
            capture_output=True,
            text=True,
            timeout=_GH_PR_LIST_TIMEOUT_SECS,
        )
        if result.returncode != 0:
            logger.debug(
                "gh pr list returncode=%d for %s: %s",
                result.returncode,
                branch,
                result.stderr.strip(),
            )
            return None
        prs = json.loads(result.stdout)
        number = prs[0]["number"]
        if not isinstance(number, int):
            return None
        return number
    except (
        FileNotFoundError,
        subprocess.TimeoutExpired,
        OSError,
        json.JSONDecodeError,
        KeyError,
        IndexError,
        TypeError,
    ):
        logger.debug("gh pr list unavailable for %s", branch, exc_info=True)
        return None


def merge_worktree(
    info: WorktreeInfo,
    auto_commit_wip: bool = True,
    *,
    _has_uncommitted: bool | None = None,
    _has_commits: bool | None = None,
) -> bool:
    """Merge a worktree branch into the current branch.

    Args:
        info: WorktreeInfo for the worktree to merge.
        auto_commit_wip: If True, auto-commit uncommitted changes before merge.
        _has_uncommitted: Pre-computed result from has_uncommitted_changes().
            If None, will be checked. Used by cleanup_worktree to avoid
            redundant subprocess calls.
        _has_commits: Pre-computed result from has_new_commits().
            If None, will be checked.
    """
    uncommitted = (
        _has_uncommitted
        if _has_uncommitted is not None
        else has_uncommitted_changes(info.path)
    )
    commits = (
        _has_commits
        if _has_commits is not None
        else has_new_commits(info.path, info.base_branch)
    )

    if auto_commit_wip and uncommitted:
        add_result = subprocess.run(
            ["git", "add", "-u"],
            capture_output=True,
            text=True,
            cwd=str(info.path),
        )
        if add_result.returncode != 0:
            logger.warning(
                "git add failed for %s: %s",
                info.path,
                add_result.stderr.strip(),
            )
            return False

        commit_result = subprocess.run(
            [
                "git",
                "commit",
                "-m",
                f"wip: uncommitted changes from {info.name}",
            ],
            capture_output=True,
            text=True,
            cwd=str(info.path),
        )
        if commit_result.returncode != 0:
            logger.warning(
                "git commit failed for %s: %s",
                info.path,
                commit_result.stderr.strip(),
            )
            return False
        # After WIP commit, there are now new commits to merge
        commits = True

    if not commits:
        return True

    pr_number = _branch_has_open_pr(info.branch)
    if pr_number is not None:
        print(
            f"[Synapse] Skipping local merge for {info.branch} "
            f"(managed by PR #{pr_number})."
        )
        print(f"  Merge will happen via GitHub when PR #{pr_number} is approved.")
        print("  Branch preserved locally for reference.")
        logger.info(
            "event=worktree_merge_skipped branch=%s pr=%d",
            info.branch,
            pr_number,
        )
        return True

    git_root = get_git_root()
    merge_result = subprocess.run(
        ["git", "merge", info.branch, "--no-edit"],
        capture_output=True,
        text=True,
        cwd=str(git_root),
    )
    if merge_result.returncode == 0:
        return True

    abort_result = subprocess.run(
        ["git", "merge", "--abort"],
        capture_output=True,
        text=True,
        cwd=str(git_root),
    )
    if abort_result.returncode != 0:
        logger.warning("git merge --abort failed: %s", abort_result.stderr.strip())
    print(f"[Synapse] Merge conflict for {info.branch}.")
    print(f"  Branch preserved: {info.branch}")
    print(f"  Resolve manually: git merge {info.branch}")
    logger.warning(
        "Merge conflict for %s: %s",
        info.branch,
        merge_result.stderr.strip(),
    )
    return False


def worktree_info_from_registry(
    worktree_path: str,
    worktree_branch: str,
    worktree_base_branch: str = "",
) -> WorktreeInfo:
    """Reconstruct a WorktreeInfo from registry metadata.

    Used when cleaning up worktrees for killed or exiting agents,
    where only the path, branch, and base branch are available from
    registry data.
    """
    return WorktreeInfo(
        name=Path(worktree_path).name,
        path=Path(worktree_path),
        branch=worktree_branch,
        base_branch=worktree_base_branch,
        created_at=0,
    )


def cleanup_worktree(
    info: WorktreeInfo,
    interactive: bool = False,
    merge: bool = False,
) -> bool:
    """Clean up a worktree, optionally prompting the user.

    - If no uncommitted changes or new commits: auto-remove.
    - If changes/commits exist and interactive: prompt user.
    - If changes/commits exist and non-interactive: keep worktree.

    Args:
        info: WorktreeInfo for the worktree to clean up.
        interactive: Whether to prompt the user.
        merge: If True, merge the worktree branch before removal.

    Returns:
        True if worktree was removed, False if kept.
    """
    try:
        main_root: Path | None = get_main_repo_root()
    except (RuntimeError, FileNotFoundError):
        logger.debug("Skipping worktree agent sync: main repo root unavailable")
        main_root = None

    uncommitted = has_uncommitted_changes(info.path)
    commits = has_new_commits(info.path, info.base_branch)

    if not uncommitted and not commits:
        if main_root is not None:
            sync_worktree_agents_to_main(info.path, main_root)
        return remove_worktree(info.path, info.branch, force=False)

    if merge:
        if merge_worktree(info, _has_uncommitted=uncommitted, _has_commits=commits):
            if main_root is not None:
                sync_worktree_agents_to_main(info.path, main_root)
            return remove_worktree(info.path, info.branch, force=False)
        return False

    # Changes or new commits exist
    if not interactive:
        logger.info(
            "event=worktree_kept_dirty name=%s path=%s",
            info.name,
            info.path,
        )
        print(
            f"\x1b[33m[Synapse]\x1b[0m Worktree '{info.name}' has unsaved work."
            f"\n  Path: {info.path}"
            f"\n  Branch: {info.branch}"
        )
        return False

    # Interactive: ask user
    try:
        answer = (
            input(
                f"Worktree '{info.name}' has unsaved work.\n"
                f"  Path: {info.path}\n"
                f"  Branch: {info.branch}\n"
                f"Remove anyway? [y/N]: "
            )
            .strip()
            .lower()
        )
        if answer == "y":
            if main_root is not None:
                sync_worktree_agents_to_main(info.path, main_root)
            return remove_worktree(info.path, info.branch, force=True)
    except (EOFError, KeyboardInterrupt):
        pass

    return False


# ============================================================
# Prune orphan worktrees
# ============================================================


def _parse_prunable_worktrees(
    porcelain_output: str, synapse_wt_prefix: str
) -> list[str]:
    """Parse ``git worktree list --porcelain`` and return prunable synapse worktree names."""
    prunable: list[str] = []
    current_path: str | None = None
    is_prunable = False

    for line in porcelain_output.splitlines():
        if line.startswith("worktree "):
            current_path = line[len("worktree ") :]
            is_prunable = False
        elif line.startswith("prunable"):
            is_prunable = True
        elif line == "":
            if (
                is_prunable
                and current_path
                and current_path.startswith(synapse_wt_prefix)
            ):
                name = current_path[len(synapse_wt_prefix) :]
                if name:
                    prunable.append(name)
            current_path = None
            is_prunable = False

    return prunable


def prune_worktrees() -> list[str]:
    """Remove orphan worktrees under ``.synapse/worktrees/``.

    Detects worktrees that git marks as *prunable* (directory missing),
    runs ``git worktree prune`` to clean up git's internal references,
    and deletes the corresponding ``worktree-<name>`` branches.

    Returns:
        List of pruned worktree names.
    """
    git_root = get_git_root()
    synapse_wt_prefix = str(git_root / ".synapse" / "worktrees") + "/"

    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.warning("git worktree list failed: %s", result.stderr.strip())
        return []

    prunable = _parse_prunable_worktrees(result.stdout, synapse_wt_prefix)
    if not prunable:
        return []

    # Prunable worktrees are already gone from disk, so saved-agent sync
    # is impossible here.
    prune_result = subprocess.run(
        ["git", "worktree", "prune"],
        capture_output=True,
        text=True,
    )
    if prune_result.returncode != 0:
        logger.warning("git worktree prune failed: %s", prune_result.stderr.strip())
        return []

    # Best-effort batch branch cleanup
    branches = [f"worktree-{name}" for name in prunable]
    branch_result = subprocess.run(
        ["git", "branch", "-d", *branches],
        capture_output=True,
        text=True,
    )
    if branch_result.returncode != 0:
        logger.warning(
            "event=prune_branch_delete_failed error=%s",
            branch_result.stderr.strip(),
        )

    logger.info("event=worktrees_pruned count=%d names=%s", len(prunable), prunable)
    return prunable
