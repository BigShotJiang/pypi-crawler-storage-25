import requests
from dataclasses import dataclass
from typing import Optional

@dataclass
class ScanResult:
    url: str
    score: int
    recommendation: str
    summary: Optional[str]
    blocked: bool
    
    def __repr__(self):
        return f"ScanResult(url={self.url}, score={self.score}, recommendation={self.recommendation}, blocked={self.blocked})"

class AgentSafe:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.agentsafe.app"
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def check(self, url: str, action: str = "browse") -> ScanResult:
        """
        Check if a URL is safe for an AI agent to interact with.
        
        Args:
            url: The URL to check
            action: The action the agent intends to take (browse, payment, login, download)
        
        Returns:
            ScanResult with score, recommendation, and blocked status
        
        Raises:
            Exception: If the URL is blocked or an error occurs
        """
        response = self.session.post(
            f"{self.base_url}/api/check",
            json={"url": url, "action": action}
        )
        response.raise_for_status()
        data = response.json()
        
        recommendation = data.get("recommendation", "UNKNOWN")
        blocked = recommendation == "RISKY"
        
        return ScanResult(
            url=url,
            score=data.get("score", 0),
            recommendation=recommendation,
            summary=data.get("summary"),
            blocked=blocked
        )
    
    def check_or_raise(self, url: str, action: str = "browse") -> ScanResult:
        """
        Check a URL and raise an exception if it is blocked.
        
        Args:
            url: The URL to check
            action: The action the agent intends to take
            
        Returns:
            ScanResult if safe
            
        Raises:
            Exception: If the URL is blocked
        """
        result = self.check(url, action)
        if result.blocked:
            raise Exception(f"AgentSafe blocked unsafe destination: {url} (score: {result.score})")
        return result


def check(url: str, action: str = "browse", api_key: str = None) -> ScanResult:
    """
    Quick check function for simple use cases.
    Set AGENTSAFE_API_KEY environment variable or pass api_key directly.
    """
    import os
    key = api_key or os.environ.get("AGENTSAFE_API_KEY")
    if not key:
        raise Exception("No API key provided. Set AGENTSAFE_API_KEY environment variable or pass api_key parameter.")
    client = AgentSafe(key)
    return client.check(url, action)