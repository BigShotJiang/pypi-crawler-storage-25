from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="agentsafe-sdk",
    version="0.1.0",
    author="AegisLayer",
    author_email="support@agentsafe.app",
    description="Real-time URL trust scoring for AI agents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://agentsafe.app",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: Internet",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
)