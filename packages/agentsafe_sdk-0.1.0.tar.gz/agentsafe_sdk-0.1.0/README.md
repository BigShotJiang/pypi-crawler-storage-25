\# AgentSafe Python SDK



Real-time URL trust scoring for AI agents. Block phishing, scam sites, and malicious redirects before your agent interacts with them.



\## Installation



````pip install agentsafe```



\## Quick Start



```python

from agentsafe import AgentSafe



client = AgentSafe(api\_key="your\_api\_key")



result = client.check("https://example.com", action="payment")

print(result.score)        # 0-100

print(result.recommendation)  # TRUSTED or RISKY

print(result.blocked)      # True or False

```



\## Raise on Block



```python

from agentsafe import AgentSafe



client = AgentSafe(api\_key="your\_api\_key")



\# Raises exception if URL is blocked

client.check\_or\_raise("https://example.com", action="payment")

```



\## Environment Variable



```python

import os

from agentsafe import check



os.environ\["AGENTSAFE\_API\_KEY"] = "your\_api\_key"

result = check("https://example.com", action="payment")

```



\## LangChain Integration



```python

from agentsafe import AgentSafe



safe = AgentSafe(api\_key="your\_api\_key")



def safe\_browse(url: str) -> str:

&#x20;   safe.check\_or\_raise(url, action="browse")

&#x20;   # proceed with browsing...

&#x20;   return "Safe to proceed"

```



\## Actions



\- `browse` — general browsing

\- `payment` — making a payment

\- `login` — logging into a site  

\- `download` — downloading a file



\## Get an API Key



Visit \[agentsafe.app](https://agentsafe.app) to get your API key.



\## License



MIT

````



Save it. 👊

