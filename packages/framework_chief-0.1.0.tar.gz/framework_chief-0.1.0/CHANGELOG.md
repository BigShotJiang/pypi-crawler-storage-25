# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [Unreleased] — 2026-05-16

### Added
- Unit test suite for four pure domain modules — `checks`, `compose`, `decision_log`, `phases` — 92 tests, ~0.5 s, no subprocess, no LLM required
- `tests/unit/test_registry.py` — REGISTRY consistency tests (replaces `test_cli.py`)
- `tests/unit/test_checks.py` — prereq check logic and version string parsing (14 tests)
- `tests/unit/test_compose.py` — composition block apply, resolver logic, monkeypatched block dir (10 tests)
- `tests/unit/test_decision_log.py` — append-only log bootstrap, parse-and-append, last-stack query (12 tests)
- `tests/unit/test_phases.py` — phase checkpointing: skip / run / force / symlink (8 tests)
- `unit` CI job in `.github/workflows/ci.yml` — `uv run pytest tests/unit/ -v`, no Docker, 5 min cap
- README: "What it looks like" — concrete example interaction (classify → agree → install)
- README: "The five frameworks" — one-row mini-glossary so the routing table has grounding
- README: "Prerequisites" table (Python, uv, git, Node)
- README: "Get started" revamped as a three-step flow with per-agent wiring table and advanced CLI in `<details>`
- `CONTRIBUTING.md` — routing eval harness, test layer architecture, CI setup, development workflow
- `CHANGELOG.md` (this file)

### Changed
- `tests/unit/test_cli.py` renamed to `tests/unit/test_registry.py` — filename now matches what is tested
- README "Status" trimmed to v0 disclaimer + two seams-to-watch; eval harness details moved to `CONTRIBUTING.md`
- README "What's in the box" updated to reflect all five unit test files and the new CI job

---

## [0.1.0] — 2026-05-14 — Initial v0

### Added

**Core routing model**
- `AGENTS.md` — rubric, three-slot model, compatibility matrix, bridge descriptions, and the full classify → clarify → agree → install loop with the human gate
- Five framework adapters (`spec-kit`, `OpenSpec`, `BMAD`, `GSD-2`, `Superpowers`) covering prereqs, detection markers, install commands, and composition notes
- Composition blocks for GREEN and YELLOW hybrids: `openspec-superpowers.md`, `bmad-superpowers.md`

**CLI and Python package**
- `src/framework_chief/` — `cli.py`, `stacks.py`, `checks.py`, `compose.py`, `decision_log.py`, `phases.py`, `project.py`, `renderer.py`
- `pyproject.toml` — package definition, `chief` entry point, uv toolchain, Python 3.11+ requirement
- `scripts/chief-install.sh` — prereq check, dry-run, install, and decision-log subcommands
- `scripts/chief-sync.sh` — propagates `AGENTS.md` to `CLAUDE.md` (symlink), `.github/copilot-instructions.md`, `.codex/prompts`

**Test infrastructure**
- Mechanical tests (`tests/mechanical/run-mechanical.sh`) — bash-only, no Docker, no LLM; dry-run exit codes, check prereqs, init idempotency, log validation, sync marker count
- Integration tests (`tests/integration/`) — full install round-trips in Docker (node:20-bookworm + uv), phases 0–10 including log integrity, GSD-2 handoff seeding, and spec-kit → GSD-2 round-trip
- Demo workflow (`tests/integration/demo-workflow.sh`) — seven end-to-end scenarios (A–G): OpenSpec solo, OpenSpec + Superpowers (GREEN), BMAD + Superpowers (YELLOW), spec-kit solo, spec-kit + canon, spec-kit + fleet (CLARIFY path), BMAD + OpenSpec RED refusal
- `tests/eval/routing-cases.md` — 28 routing cases covering direct routes, CLARIFY paths, RED refusals, YELLOW pairs, edge cases, and all spec-kit extensions
- `tests/eval/eval-routing.py` — automated routing eval harness; sends each case to the Claude API, parses the `CHIEF_EVAL` sentinel, compares state + verdict against expected

**CI**
- `.github/workflows/ci.yml` — mechanical + integration + demo jobs on push/PR to main
- `.github/workflows/routing-eval.yml` — routing eval on `AGENTS.md` or routing-cases changes (requires `ANTHROPIC_API_KEY` secret)

**Documentation and design**
- ADRs 0001–0006 covering: Python registry dispatch, YAML front-matter adapters, compose subcommand, init phase pipeline, Python test seam, Claude overlay model
- Decision flow diagram (`docs/assets/decision-flow.svg`)
- `docs/context/` — domain glossary

### Fixed
- Sync tests now run unconditionally; previously skipped when `CLAUDE.md` was gitignored (meta-repo context). Replaced with temp-project approach using `mktemp -d` + `git init`.

### Changed
- Composition block templates now include `superpowers_version` (and `bmad_version` for the BMAD pair) — version mismatches surface as stale fields rather than silently ignored skill names
