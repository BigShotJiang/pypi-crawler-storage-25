# Contributing to framework-chief

## Test architecture

Four layers, each with a different scope and cost:

| Layer | Location | Requires | When to run |
|-------|----------|----------|-------------|
| Unit | `tests/unit/` | Python + uv | Always — every change |
| Mechanical | `tests/mechanical/` | bash, git | Always — no network or Docker |
| Integration | `tests/integration/` | Docker, network | Before merge — full install round-trips |
| Routing eval | `tests/eval/` | Claude API key | On routing logic changes |

### Unit tests

92 tests across five files. Cover the pure domain modules with no subprocess, no LLM, no Docker.

```bash
uv run pytest tests/unit/ -v
```

### Mechanical tests

Bash-only assertions: dry-run exit codes, prereq check, init idempotency, log validation, sync marker count.

```bash
bash tests/mechanical/run-mechanical.sh
```

### Integration tests

Full install round-trips in Docker (node:20-bookworm + uv + git). Covers phases 0–10 including log integrity, GSD-2 handoff seeding, and the full spec-kit → GSD-2 round-trip.

```bash
bash tests/integration/docker-test.sh
```

The demo workflow (seven scenarios A–G) runs in a separate Docker image:

```bash
docker build -f tests/integration/Dockerfile.demo -t framework-chief-demo .
docker run --rm framework-chief-demo
```

### Routing eval harness

`tests/eval/eval-routing.py` sends each of the 28 routing cases in `routing-cases.md` to the Claude API. It instructs the chief to append a `CHIEF_EVAL` sentinel line and parses state + verdict against the expected values.

```bash
# Parse and validate all 28 cases locally — no API calls
python3 tests/eval/eval-routing.py --dry-run

# Run a single case
python3 tests/eval/eval-routing.py --cases 1

# Full eval against the live API
ANTHROPIC_API_KEY=sk-ant-... python3 tests/eval/eval-routing.py

# Flags
#   --verbose      print full chief response per case
#   --model        override the model (default: claude-sonnet-4-6)
#   --cases N[,M]  run only case numbers N or N through M
```

The eval is intentionally kept separate from CI because it requires `ANTHROPIC_API_KEY` and incurs per-run LLM cost. The GitHub Actions workflow (`.github/workflows/routing-eval.yml`) triggers automatically when `AGENTS.md`, `routing-cases.md`, or `eval-routing.py` change on main.

## CI

Three jobs run on every push and PR to main:

| Job | What it covers | Timeout |
|-----|---------------|---------|
| `unit` | 92 unit tests via `uv run pytest` | 5 min |
| `mechanical` | bash-only shell assertions | 5 min |
| `integration` | Docker full install round-trips | 30 min |
| `demo` | Docker 7-scenario workflow demo | 30 min |

Routing eval runs separately on a fourth workflow and requires an `ANTHROPIC_API_KEY` repository secret.

## Adding a routing case

1. Add the case to `tests/eval/routing-cases.md` following the existing format (state, verdict, rationale).
2. Run `python3 tests/eval/eval-routing.py --dry-run` to verify parsing.
3. Run the eval against the live API to confirm the chief routes it correctly.
4. If the case exposes a routing gap, fix `AGENTS.md` first, then add the test case.

## Repository structure

```
framework-chief/
├── src/framework_chief/            Python package
│   ├── cli.py                      chief CLI entry point (init, sync, check, install, dry-run, log)
│   ├── stacks.py                   REGISTRY — Stack and FrameworkMeta definitions
│   ├── checks.py                   prereq check + version string parsing
│   ├── compose.py                  composition block apply + placeholder resolver
│   ├── decision_log.py             append-only decision log (bootstrap, parse, query)
│   ├── phases.py                   phase checkpointing (is_done, run, force)
│   ├── project.py                  ProjectLayout — typed paths for a user project
│   ├── renderer.py                 Rich output formatting
│   └── data/                       files bundled into the package and copied on init
│       ├── AGENTS.md               router template
│       ├── chief/
│       │   ├── adapters/           per-framework adapter templates (5 files)
│       │   ├── composition-blocks/ hybrid demotion block templates (2 files)
│       │   └── stacks.yaml         stack registry definitions
│       └── scripts/
│           ├── chief-install.sh
│           └── chief-sync.sh
├── tests/
│   ├── unit/                       pure Python, no subprocess, no LLM (92 tests)
│   ├── mechanical/                 bash-only shell assertions (no Docker, no network)
│   ├── integration/                Docker full install round-trips (node:20-bookworm + uv)
│   └── eval/                       routing eval harness (requires ANTHROPIC_API_KEY)
├── docs/
│   ├── adrs/                       Architecture Decision Records 0001–0007
│   ├── assets/                     SVG diagrams (decision flow, header)
│   └── context/                    domain glossary (CONTEXT.md)
├── .github/workflows/
│   ├── ci.yml                      unit + mechanical + integration + demo on push/PR
│   └── routing-eval.yml            routing eval on AGENTS.md / routing-cases changes
└── pyproject.toml                  package definition, chief entry point, Python 3.11+
```

## Adding a framework adapter

1. Create `.chief/adapters/<name>.md` following the existing format (prereqs table, detection markers, install commands, composition notes).
2. Register the framework in `src/framework_chief/stacks.py`.
3. Add a `FrameworkMeta` entry with the correct `slot`, `install_mode`, and `detection_marker`.
4. Add routing cases that exercise the new framework.
5. Update the compatibility matrix in `AGENTS.md` if new GREEN/YELLOW/RED combinations apply.
