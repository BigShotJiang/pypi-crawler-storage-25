#!/usr/bin/env bash
# chief-install — the mechanical half of the Framework Chief's INSTALL state.
#
# This script does ONLY deterministic, context-free work: prerequisite checks,
# existing-install detection, running install commands, appending to the decision log.
# It makes no decisions. The agent decides WHAT to install and WHETHER to proceed;
# this script only executes what was already decided and already approved at the gate.
#
# Subcommands:
#   init                   bootstrap .chief/ directory and decision.md. Run once per project.
#   check <framework>      verify prereqs + detect existing install. Exit 0 = clear to go.
#   dry-run <stack>        print the exact command sequence (feeds the AGREE gate). No mutation.
#   install <framework>    run the install commands for one framework, echoing each. MUTATES.
#   log <key=val>...       append one structured entry to .chief/decision.md.
#
# Frameworks: spec-kit | openspec | bmad | superpowers | gsd2
# Stacks:     spec-kit | openspec | bmad | gsd2
#             openspec-superpowers | bmad-superpowers | spec-kit-gsd2
#
# Usage:  scripts/chief-install.sh <subcommand> [args]   (run from project root)

set -euo pipefail

ROOT="$(pwd)"
CHIEF_DIR="$ROOT/.chief"
DECISION_LOG="$CHIEF_DIR/decision.md"

say()  { printf '%s\n' "$*"; }
ok()   { printf '  ok    %s\n' "$*"; }
miss() { printf '  MISS  %s\n' "$*" >&2; }
err()  { printf '  ERROR %s\n' "$*" >&2; }

# Run a command, printing it first. Avoids eval.
run() {
  printf '  $ %s\n' "$*"
  "$@"
}

have() { command -v "$1" >/dev/null 2>&1; }

# --- init: bootstrap .chief/ on a fresh project ----------------------------
init() {
  mkdir -p "$CHIEF_DIR/adapters" "$CHIEF_DIR/composition-blocks"
  if [[ -f "$DECISION_LOG" ]]; then
    say "init: .chief/ already exists — skipping"
    return 0
  fi
  cat > "$DECISION_LOG" <<'EOF'
# Framework Chief — Decision Log

Append-only audit log. Each entry records one install event: what stack was chosen,
why, what commands ran, and any deviations from the standard flow.

Do not edit existing entries.

---
EOF
  say "init: .chief/ bootstrapped. decision.md created."
}

# --- prerequisite + existing-install checks --------------------------------
check() {
  local fw="${1:-}"; local fail=0
  [[ -z "$fw" ]] && { say "usage: check <framework>"; exit 2; }
  say "check: $fw"

  case "$fw" in
    spec-kit)
      have python3 && ok "python3 $(python3 --version 2>&1 | awk '{print $2}')" || { miss "python3 (need 3.11+)"; fail=1; }
      if have uv; then ok "uv present"
      elif have pipx; then ok "pipx present (uv preferred but pipx works)"
      else miss "neither uv nor pipx — install uv: https://docs.astral.sh/uv/"; fail=1; fi
      have git && ok "git present" || { miss "git"; fail=1; }
      [[ -d "$ROOT/.specify" ]] && { miss "already initialized — .specify/ exists"; exit 3; }
      ;;
    openspec)
      have node && ok "node $(node --version)" || { miss "node (need 20.19+)"; fail=1; }
      have npm  && ok "npm present"            || { miss "npm"; fail=1; }
      have git  && ok "git present"            || { miss "git"; fail=1; }
      [[ -d "$ROOT/openspec" ]] && { miss "already initialized — openspec/ exists"; exit 3; }
      ;;
    bmad)
      have node && ok "node $(node --version)" || { miss "node (need 20+)"; fail=1; }
      have git  && ok "git present"            || { miss "git"; fail=1; }
      { [[ -d "$ROOT/_bmad" ]] || [[ -d "$ROOT/.bmad" ]]; } && { miss "already installed — _bmad/ or .bmad/ exists"; exit 3; }
      ;;
    superpowers)
      have git && ok "git present" || { miss "git"; fail=1; }
      say "  note  Superpowers installs per-harness via plugin marketplace — see .chief/adapters/superpowers.md"
      say "  note  install LAST in a hybrid, after the composition block is written to AGENTS.md"
      ;;
    gsd2)
      have node && ok "node $(node --version)" || { miss "node (need 20.6+)"; fail=1; }
      [[ -d "$ROOT/.gsd" ]] && { miss "GSD-2 already manages this project — .gsd/ exists"; fail=1; }
      say "  note  GSD-2 is recommend-only — this script will NOT auto-run its global install"
      ;;
    *) err "unknown framework: $fw"; exit 2 ;;
  esac

  if [[ $fail -ne 0 ]]; then err "check: $fw — NOT clear. Stop and report to the user."; exit 1; fi
  say "check: $fw — clear."
}

# --- the command sequences (single source for dry-run and install) ---------
commands_for() {
  case "$1" in
    spec-kit)
      echo 'uv tool install specify-cli --from git+https://github.com/github/spec-kit.git'
      echo 'specify init --here --force'
      ;;
    openspec)
      echo 'npm install -g @fission-ai/openspec@latest'
      echo 'openspec init --tools claude'
      ;;
    bmad)
      echo 'npx bmad-method install'
      ;;
    superpowers)
      echo '# Claude Code:'
      echo '/plugin marketplace add obra/superpowers-marketplace'
      echo '/plugin install superpowers@superpowers-marketplace'
      echo '# Codex / Copilot CLI / others: install per-harness from the plugin marketplace'
      ;;
    gsd2)
      echo '# RECOMMEND ONLY — user runs this themselves:'
      echo 'npm install -g gsd-pi'
      echo 'gsd   # then /login'
      ;;
    *)
      err "unknown framework: $1"
      return 1
      ;;
  esac
}

# --- dry-run: print the full sequence for a stack, no mutation -------------
dry_run() {
  local stack="${1:-}"
  [[ -z "$stack" ]] && { say "usage: dry-run <stack>"; exit 2; }
  say "dry-run: $stack"
  say "the AGREE gate should show the user exactly this:"
  say ""
  case "$stack" in
    spec-kit|openspec|bmad|gsd2)
      say "[$stack]"; commands_for "$stack" | sed 's/^/  /'
      ;;
    openspec-superpowers)
      say "install order: openspec, then composition block, then superpowers"
      say "[openspec]";    commands_for openspec    | sed 's/^/  /'
      say "[composition block] write .chief/composition-blocks/openspec-superpowers.md into AGENTS.md"
      say "[superpowers]"; commands_for superpowers | sed 's/^/  /'
      ;;
    bmad-superpowers)
      say "install order: bmad, then composition block, then superpowers"
      say "[bmad]";        commands_for bmad        | sed 's/^/  /'
      say "[composition block] write .chief/composition-blocks/bmad-superpowers.md into AGENTS.md"
      say "[superpowers]"; commands_for superpowers | sed 's/^/  /'
      ;;
    spec-kit-gsd2)
      say "this is a migration handoff, not a co-running stack"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[handoff]  run spec-kit through /speckit.plan, then seed GSD-2 context from specs/ — see .chief/adapters/gsd2.md"
      say "[gsd2]";     commands_for gsd2     | sed 's/^/  /'
      ;;
    superpowers)
      say "[superpowers]"; commands_for superpowers | sed 's/^/  /'
      ;;
    spec-kit-superpowers|spec-kit-superpowers-bridge)
      say "install order: spec-kit, then superpowers-bridge extension"
      say "note: spec-kit's constitution already enforces TDD + code review natively."
      say "      this is YELLOW — use only when enforced testing discipline is explicitly needed."
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[superpowers-bridge]  specify extension add superpowers-bridge"
      ;;
    spec-kit-fleet)
      say "install order: spec-kit, then fleet extension"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[fleet extension]  specify extension add fleet"
      ;;
    spec-kit-product-forge)
      say "install order: spec-kit, then product-forge extension"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[product-forge extension]  specify extension add product-forge"
      ;;
    spec-kit-canon)
      say "install order: spec-kit, then canon extension"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[canon extension]  specify extension add canon"
      ;;
    spec-kit-brownfield)
      say "install order: spec-kit, then brownfield extension"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[brownfield extension]  specify extension add brownfield"
      ;;
    spec-kit-brownkit)
      say "install order: spec-kit, then brownkit extension"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[brownkit extension]  specify extension add brownkit"
      ;;
    spec-kit-ralph)
      say "install order: spec-kit, then ralph extension"
      say "[spec-kit]"; commands_for spec-kit | sed 's/^/  /'
      say "[ralph extension]  specify extension add ralph"
      ;;
    *) err "unknown stack: $stack"; exit 2 ;;
  esac
  say ""
  say "[log] scripts/chief-install.sh log stack=$stack date=\$(date +%Y-%m-%d) ..."
  say ""
  say "dry-run: nothing was executed."
}

# --- install: run the commands for ONE framework, echoing each ------------
install() {
  local fw="${1:-}"
  [[ -z "$fw" ]] && { say "usage: install <framework>"; exit 2; }

  if [[ "$fw" == "gsd2" ]]; then
    say "install: gsd2 — RECOMMEND ONLY. Not auto-running. Give the user:"
    commands_for gsd2 | sed 's/^/  /'
    exit 0
  fi
  if [[ "$fw" == "superpowers" ]]; then
    say "install: superpowers — per-harness plugin install, not a shell command."
    say "Give the user the marketplace steps:"
    commands_for superpowers | sed 's/^/  /'
    exit 0
  fi

  # Validate prereqs before touching anything.
  check "$fw" || { check_code=$?; err "install aborted: check failed for $fw"; exit $check_code; }

  say "install: $fw — running. Each command is echoed before it runs."
  while IFS= read -r cmd; do
    [[ "$cmd" =~ ^[[:space:]]*#.*$ || -z "$cmd" ]] && continue
    # shellcheck disable=SC2086
    run $cmd
  done < <(commands_for "$fw")
  say "install: $fw — done."
}

# --- log: append one entry to the decision log ----------------------------
log() {
  # Auto-bootstrap if needed so log never hard-errors on a fresh repo.
  if [[ ! -f "$DECISION_LOG" ]]; then
    say "log: .chief/decision.md not found — running init first"
    init
  fi
  if [[ $# -eq 0 ]]; then
    err "log: requires at least one key=value argument"
    exit 2
  fi
  local date; date="$(date +%Y-%m-%d)"
  for kv in "$@"; do
    if [[ "$kv" != *=* ]]; then
      err "log: malformed argument '$kv' — expected key=value format"
      exit 2
    fi
    local key="${kv%%=*}"
    local val="${kv#*=}"
    if [[ -z "$val" ]]; then
      err "log: empty value for key '$key'"
      exit 2
    fi
    if [[ ! "$key" =~ ^[A-Za-z0-9_-]+$ ]]; then
      err "log: invalid key '$key' — keys must match [A-Za-z0-9_-]+"
      exit 2
    fi
    if [[ "$val" == *$'\n'* ]]; then
      err "log: newline in value for key '$key'"
      exit 2
    fi
  done
  {
    echo ""
    echo "### $date — install event"
    for kv in "$@"; do echo "- **${kv%%=*}:** ${kv#*=}"; done
  } >> "$DECISION_LOG"
  say "log: appended entry to .chief/decision.md"
}

# --- dispatch --------------------------------------------------------------
case "${1:-}" in
  init)    shift; init             ;;
  check)   shift; check   "$@"    ;;
  dry-run) shift; dry_run "$@"    ;;
  install) shift; install "$@"    ;;
  log)     shift; log     "$@"    ;;
  *) cat <<'EOF'
chief-install — the mechanical half of the Chief's INSTALL state.

  init                  bootstrap .chief/ directory and decision.md (run once)
  check <framework>     verify prereqs + detect existing install
  dry-run <stack>       print the command sequence (feeds the AGREE gate)
  install <framework>   run the install commands for one framework
  log <key=val>...      append an entry to .chief/decision.md

frameworks: spec-kit openspec bmad superpowers gsd2
stacks:     spec-kit openspec bmad gsd2
            openspec-superpowers bmad-superpowers spec-kit-gsd2
EOF
     exit 2 ;;
esac
