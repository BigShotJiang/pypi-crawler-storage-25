#!/usr/bin/env bash
# chief-sync — propagate the Framework Chief router to every coding agent's expected path.
#
# AGENTS.md is the single source of truth (read natively by Codex, Copilot, Cursor, etc.).
# This script makes Claude Code and GitHub Copilot pick up the same router without
# duplicating its content.
#
# Usage:  scripts/chief-sync.sh [--ai VENDOR] [project-root]
#         VENDOR: all (default), claude, copilot, codex
#         PROJECT_ROOT defaults to the current directory.

set -euo pipefail

# --- argument parsing --------------------------------------------------------
AI="all"
POSITIONAL=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --ai) AI="$2"; shift 2 ;;
    *) POSITIONAL+=("$1"); shift ;;
  esac
done

ROOT="${POSITIONAL[0]:-$(pwd)}"

case "$AI" in
  all|claude|copilot|codex) ;;
  *)
    echo "error: --ai must be one of: all, claude, copilot, codex (got '$AI')" >&2
    exit 1
    ;;
esac

AGENTS="$ROOT/AGENTS.md"

if [[ ! -f "$AGENTS" ]]; then
  echo "error: $AGENTS not found — the chief router must exist before syncing." >&2
  exit 1
fi

echo "chief-sync: source of truth = $AGENTS  (--ai=$AI)"

# --- Claude Code: CLAUDE.md overlay + /chief slash command ------------------
if [[ "$AI" == "all" || "$AI" == "claude" ]]; then
  CLAUDE="$ROOT/CLAUDE.md"
  OVERLAY_MARKER="@AGENTS.md"
  if [[ -f "$CLAUDE" ]] && ! [[ -L "$CLAUDE" ]] && grep -qF "$OVERLAY_MARKER" "$CLAUDE" 2>/dev/null; then
    echo "  CLAUDE.md       already a real overlay file — ok"
  elif [[ -L "$CLAUDE" ]]; then
    rm "$CLAUDE"
    cat > "$CLAUDE" <<'OVERLAY'
# Framework Chief — Claude Code overlay

@AGENTS.md

<!-- Claude Code-specific additions below.
     Add tool-use hooks, memory instructions, or harness mechanics here.
     Currently empty — AGENTS.md base is sufficient for Claude Code. -->
OVERLAY
    echo "  CLAUDE.md       symlink replaced with real overlay file"
  elif [[ -e "$CLAUDE" ]]; then
    echo "  CLAUDE.md       exists without overlay marker — leaving it alone." >&2
    echo "                  (add '@AGENTS.md' to it, or rm and re-run)" >&2
  else
    cat > "$CLAUDE" <<'OVERLAY'
# Framework Chief — Claude Code overlay

@AGENTS.md

<!-- Claude Code-specific additions below.
     Add tool-use hooks, memory instructions, or harness mechanics here.
     Currently empty — AGENTS.md base is sufficient for Claude Code. -->
OVERLAY
    echo "  CLAUDE.md       overlay file written"
  fi

  mkdir -p "$ROOT/.claude/commands"
  cat > "$ROOT/.claude/commands/chief.md" <<'EOF'
---
description: Invoke the Framework Chief — decide and install the right framework stack.
---
Read AGENTS.md and act as the Framework Chief defined there. Run the loop:
classify the user's request, clarify if confidence is low, present the AGREE gate,
and only install after explicit confirmation.

User request:
$ARGUMENTS
EOF
  echo "  .claude/commands/chief.md   written"
fi

# --- GitHub Copilot: pointer file -------------------------------------------
if [[ "$AI" == "all" || "$AI" == "copilot" ]]; then
  mkdir -p "$ROOT/.github"
  COPILOT="$ROOT/.github/copilot-instructions.md"
  CHIEF_MARKER="<!-- framework-chief-block -->"

  if [[ -f "$COPILOT" ]] && grep -qF "$CHIEF_MARKER" "$COPILOT" 2>/dev/null; then
    echo "  .github/copilot-instructions.md   already contains Framework Chief block — skipping"
  elif [[ -f "$COPILOT" ]]; then
    {
      echo ""
      echo "$CHIEF_MARKER"
      echo "## Framework Chief"
      echo ""
      echo "This project uses the **Framework Chief**. The full router, rubric, compatibility"
      echo "matrix, and install protocol live in \`/AGENTS.md\` at the repository root — read it"
      echo "and follow it as the authority for any framework-selection or install request."
      echo "$CHIEF_MARKER"
    } >> "$COPILOT"
    echo "  .github/copilot-instructions.md   Framework Chief block appended (existing rules preserved)"
  else
    cat > "$COPILOT" <<EOF
# Copilot Instructions

$CHIEF_MARKER
## Framework Chief

This project uses the **Framework Chief**. The full router, rubric, compatibility
matrix, and install protocol live in \`/AGENTS.md\` at the repository root — read it
and follow it as the authority for any framework-selection or install request.
$CHIEF_MARKER

For Copilot-specific behavior, add rules below this line.
EOF
    echo "  .github/copilot-instructions.md   written"
  fi
fi

# --- Codex: prompt entry (optional slash trigger) ---------------------------
if [[ "$AI" == "all" || "$AI" == "codex" ]]; then
  mkdir -p "$ROOT/.codex/prompts"
  cat > "$ROOT/.codex/prompts/chief.md" <<'EOF'
Read AGENTS.md and act as the Framework Chief defined there. Run the classify →
clarify → agree → install loop. Do not install before the AGREE gate passes.
EOF
  echo "  .codex/prompts/chief.md   written"
fi

echo "chief-sync: done."
