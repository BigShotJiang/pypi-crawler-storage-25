"""renderer.py — Rich presentation layer for framework-chief.

All Rich console output lives here. Domain modules have no Rich dependency.
"""
from __future__ import annotations

from pathlib import Path

from rich.align import Align
from rich.console import Console, Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from framework_chief import __version__
from framework_chief.checks import CheckItem, CheckLevel
from framework_chief.phases import PhaseResult

console = Console(highlight=False)
err = Console(stderr=True, highlight=False)

_BANNER = """\
 ██████╗██╗  ██╗██╗███████╗███████╗
██╔════╝██║  ██║██║██╔════╝██╔════╝
██║     ███████║██║█████╗  █████╗
██║     ██╔══██║██║██╔══╝  ██╔══╝
╚██████╗██║  ██║██║███████╗██║
 ╚═════╝╚═╝  ╚═╝╚═╝╚══════╝╚═╝
"""

_TAGLINE = (
    f"Framework Chief v{__version__}"
    " — decide and install the right SDD stack"
)

_LEVEL_ICON: dict[CheckLevel, tuple[str, str, str]] = {
    #                      icon   icon_style   msg_style
    CheckLevel.OK:        ("✓", "green",    "dim"),
    CheckLevel.MISS_SOFT: ("?", "yellow",   ""),
    CheckLevel.MISS:      ("✗", "bold red", "bold red"),
    CheckLevel.NOTE:      ("●", "cyan",     ""),
    CheckLevel.WARN:      ("⚠", "yellow",   "yellow"),
}


# ── shared ──────────────────────────────────────────────────────────────────

def render_error(message: str) -> None:
    err.print(f"[bold red]ERROR:[/bold red] {message}")


def show_banner() -> None:
    colors = [
        "gold1", "yellow", "bright_yellow",
        "bright_yellow", "yellow", "gold1",
    ]
    art = Text()
    for i, line in enumerate(_BANNER.rstrip("\n").split("\n")):
        art.append(line + "\n", style=colors[i % len(colors)])
    console.print(Align.center(art))
    console.print(
        Align.center(Text(_TAGLINE, style="italic bright_white"))
    )
    console.print()


# ── check ───────────────────────────────────────────────────────────────────

def _build_check_grid(items: list[CheckItem]) -> Table:
    grid = Table.grid(padding=(0, 2))
    grid.add_column(width=1, no_wrap=True)
    grid.add_column()
    for item in items:
        icon, icon_style, msg_style = _LEVEL_ICON.get(
            item.level, (" ", "", "")
        )
        grid.add_row(
            Text(icon, style=icon_style),
            Text(item.message, style=msg_style),
        )
    return grid


def render_check(
    fw_name: str, items: list[CheckItem], ok: bool
) -> None:
    console.print(Panel(
        _build_check_grid(items),
        title=f"[bold]check:[/bold] {fw_name}",
        border_style="green" if ok else "red",
        padding=(0, 1),
    ))
    if ok:
        console.print(Text("  ✓  clear", style="bold green"))
    else:
        err.print(Text(
            "  ✗  prereq missing — stop and report to the user.",
            style="bold red",
        ))


# ── init ────────────────────────────────────────────────────────────────────

def _phase_grid(results: list[PhaseResult]) -> Table:
    grid = Table.grid(padding=(0, 2))
    grid.add_column(width=1, no_wrap=True)
    grid.add_column(style="bold")
    grid.add_column(style="dim")
    for r in results:
        if r.status == "done":
            grid.add_row(Text("✓", style="green"), r.phase, r.message)
        elif r.status == "skipped":
            grid.add_row(Text("–", style="dim"), r.phase, r.message)
        else:
            grid.add_row(
                Text("✗", style="bold red"),
                Text(r.phase, style="red"),
                Text(r.message, style="red"),
            )
    return grid


def render_init_status(
    results: list[PhaseResult], project: Path
) -> None:
    all_done = all(r.status == "done" for r in results)
    grid = Table.grid(padding=(0, 2))
    grid.add_column(width=1, no_wrap=True)
    grid.add_column(style="bold")
    grid.add_column(style="dim")
    for r in results:
        if r.status == "done":
            grid.add_row(Text("✓", style="green"), r.phase, r.message)
        else:
            grid.add_row(Text("○", style="dim"), r.phase, r.message)
    console.print(Panel(
        grid,
        title=f"[bold]init --status[/bold]  {project}",
        border_style="green" if all_done else "yellow",
        padding=(0, 1),
    ))


def render_init_failure(results: list[PhaseResult]) -> None:
    failed = results[-1]
    console.print(Panel(
        _phase_grid(results),
        title="[bold red]chief init — failed[/bold red]",
        border_style="red",
        padding=(0, 1),
    ))
    if failed.remediation:
        err.print(f"[dim]remediation:[/dim] {failed.remediation}")


def render_init_success(
    results: list[PhaseResult], project: Path
) -> None:
    console.print(Panel(
        _phase_grid(results),
        title="[bold]chief init[/bold]",
        border_style="green",
        padding=(0, 1),
        subtitle=str(project),
    ))
    console.print()
    console.print(
        "  [green]✓[/green]  done."
        "  In any agent, invoke [bold]/chief[/bold]"
        " and describe what you're building."
    )


# ── sync ────────────────────────────────────────────────────────────────────

def render_sync_header(ai: str, project: Path) -> None:
    console.print(Panel(
        Text(f"  $ chief-sync.sh --ai {ai}", style="dim"),
        title="[bold]chief sync[/bold]",
        subtitle=f"[dim]--ai={ai}  {project}[/dim]",
        border_style="blue",
        padding=(0, 1),
    ))


def render_sync_success() -> None:
    console.print()
    console.print(Text("  ✓  sync complete", style="bold green"))


# ── dry-run ─────────────────────────────────────────────────────────────────

def render_dry_run_refused(stack_name: str, note: str) -> None:
    err.print(Panel(
        Text(note, style="red"),
        title=f"[bold red]REFUSED:[/bold red] {stack_name}",
        border_style="red",
        padding=(0, 1),
    ))


def render_dry_run(
    stack_name: str,
    entries: list[tuple[str, str]],
    note: str,
) -> None:
    content_parts: list[Text] = []
    for kind, text in entries:
        if kind == "comment":
            content_parts.append(Text(f"# {text}", style="dim italic"))
        else:
            content_parts.append(
                Text(f"  $ {text.strip()}", style="bold bright_white")
            )
    if note:
        if content_parts:
            content_parts.append(Text(""))
        content_parts.append(Text(f"  {note}", style="dim"))
    content = (
        Group(*content_parts) if content_parts
        else Text("  (no install commands)", style="dim")
    )
    console.print(Panel(
        content,
        title=f"[bold]dry-run:[/bold] {stack_name}",
        border_style="blue",
        padding=(1, 1),
    ))
    console.print(Text("  nothing was executed.", style="dim"))


# ── log ─────────────────────────────────────────────────────────────────────

def render_log(
    pairs: list[tuple[str, str]],
    date: str,
    log_path: Path,
) -> None:
    grid = Table.grid(padding=(0, 2))
    grid.add_column(width=1, no_wrap=True)
    grid.add_column(style="dim")
    grid.add_column()
    for key, val in pairs:
        grid.add_row(
            Text("·", style="dim"), key, Text(val, style="bold")
        )
    console.print(Panel(
        grid,
        title=f"[bold]log[/bold]  {date}",
        subtitle=f"[dim]{log_path}[/dim]",
        border_style="blue",
        padding=(0, 1),
    ))
    console.print(
        Text("  ✓  appended to .chief/decision.md", style="green")
    )


def render_log_verbose(entries: str, log_path: Path) -> None:
    console.print(Panel(
        Markdown(entries),
        title="[bold]decision log[/bold]",
        subtitle=f"[dim]{log_path}[/dim]",
        border_style="dim",
        padding=(0, 1),
    ))


# ── install ─────────────────────────────────────────────────────────────────

def render_install_check_items(items: list[CheckItem]) -> None:
    console.print(_build_check_grid(items))


def render_install_recommend(
    fw_name: str, commands: list[str]
) -> None:
    console.print(
        f"install: {fw_name} — [yellow]RECOMMEND ONLY[/yellow]."
        " Give the user:"
    )
    for cmd in commands:
        console.print(f"  [bold]{cmd}[/bold]")


def render_install_running(fw_name: str) -> None:
    console.print(f"install: {fw_name} — running.")


def render_install_command(cmd_str: str) -> None:
    console.print(
        f"  [dim]$[/dim] [bold white]{cmd_str}[/bold white]"
    )


def render_install_done(fw_name: str) -> None:
    console.print(f"[green]✓[/green]  install: {fw_name} — done.")


# ── compose ─────────────────────────────────────────────────────────────────

def render_compose_already_present(stack_name: str) -> None:
    console.print(Panel(
        Text(
            "marker already present in AGENTS.md — nothing written.",
            style="dim",
        ),
        title=f"[bold yellow]compose:[/bold yellow] {stack_name}",
        border_style="yellow",
        padding=(0, 1),
    ))


def render_compose_done(stack_name: str, agents_md: Path) -> None:
    console.print(Panel(
        Text(f"written to {agents_md}", style="dim"),
        title=f"[bold]compose:[/bold] {stack_name}",
        border_style="green",
        padding=(0, 1),
    ))
    console.print(Text(
        "  ✓  composition block appended to AGENTS.md",
        style="green",
    ))
