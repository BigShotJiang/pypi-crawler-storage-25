"""compose.py — Composition block engine for framework-chief."""
from __future__ import annotations

import datetime
import os
from pathlib import Path
from typing import Callable

from framework_chief.stacks import Stack, parse_front_matter


# ── exceptions ───────────────────────────────────────────────────────────────

class CompositionError(Exception):
    """Raised when the engine cannot complete."""


class BlockAlreadyPresent(Exception):
    """Raised when the marker already exists in AGENTS.md."""


class PlaceholderError(CompositionError):
    """Raised when a required placeholder cannot be filled."""


# ── internals ────────────────────────────────────────────────────────────────

_MARKER_TPL = "<!-- chief:composition-block:{stack} -->"
_BLOCKS_DIR = (
    Path(__file__).parent / "data" / "chief" / "composition-blocks"
)


def _resolve_auto(
    _placeholder: str,
    _values: dict[str, str],
    _input_fn: Callable[[str], str],
) -> str | None:
    return datetime.date.today().isoformat()


def _resolve_required(
    placeholder: str,
    values: dict[str, str],
    input_fn: Callable[[str], str],
) -> str | None:
    key = placeholder.lower().replace(" ", "_")
    value = (
        values.get(key, "").strip()
        or os.environ.get(placeholder.upper(), "").strip()
    )
    if not value:
        try:
            value = input_fn(f"Enter {placeholder}: ").strip()
        except EOFError:
            value = ""
    if not value:
        raise PlaceholderError(
            f"{placeholder} is required"
            f" — use --request-summary"
            f" or set {placeholder.upper()} env var"
        )
    return value


def _resolve_prompt(
    placeholder: str,
    _values: dict[str, str],
    input_fn: Callable[[str], str],
) -> str | None:
    try:
        value = input_fn(
            f"Enter {placeholder} (press Enter to skip): "
        ).strip()
    except EOFError:
        print()
        value = ""
    return value or None


_RESOLVERS: dict[str, Callable] = {
    "auto": _resolve_auto,
    "required": _resolve_required,
    "prompt": _resolve_prompt,
}


# ── public interface ─────────────────────────────────────────────────────────

def apply_composition_block(
    stack: Stack,
    agents_md: Path,
    *,
    values: dict[str, str],
    input_fn: Callable[[str], str] = input,
) -> None:
    """Fill and append a composition block to agents_md.

    Raises BlockAlreadyPresent if the marker already exists.
    Raises PlaceholderError if a required placeholder cannot be filled.
    Raises CompositionError on any other failure.
    """
    block_path = _BLOCKS_DIR / f"{stack.composition_block}.md"
    if not block_path.exists():
        raise CompositionError(
            f"composition block not found: {block_path}"
        )

    text = block_path.read_text(encoding="utf-8")
    meta, block_body = parse_front_matter(text)
    if not meta:
        raise CompositionError(
            "composition block has no YAML front-matter"
        )
    placeholders: dict[str, str] = meta.get("placeholders", {})

    missing = [p for p in placeholders if f"<{p}>" not in block_body]
    if missing:
        raise CompositionError(
            f"composition block {stack.composition_block!r}:"
            f" placeholder(s) declared but no matching token in body:"
            f" {', '.join(f'<{p}>' for p in missing)}"
        )

    marker = _MARKER_TPL.format(stack=stack.name)
    if agents_md.exists() and marker in agents_md.read_text(
        encoding="utf-8"
    ):
        raise BlockAlreadyPresent(stack.name)

    filled = block_body
    for placeholder, strategy in placeholders.items():
        token = f"<{placeholder}>"
        resolver = _RESOLVERS.get(strategy)
        if resolver is None:
            raise CompositionError(
                f"unknown placeholder strategy '{strategy}'"
                f" for {placeholder}"
            )
        value = resolver(placeholder, values, input_fn)
        if value is not None:
            filled = filled.replace(token, value)

    with agents_md.open("a", encoding="utf-8") as f:
        f.write(f"\n{marker}\n")
        f.write(filled)
