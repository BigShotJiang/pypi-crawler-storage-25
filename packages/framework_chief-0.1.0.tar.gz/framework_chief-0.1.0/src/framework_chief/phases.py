"""phases.py — 5-phase init pipeline for framework-chief."""
from __future__ import annotations

import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Literal

from framework_chief.decision_log import DecisionLog
from framework_chief.project import ProjectLayout


PhaseStatus = Literal["done", "skipped", "failed"]

_SKIP_MSG = "already exists — use --force to overwrite"


def _data() -> Path:
    return Path(__file__).parent / "data"


def _bundled_phase(script: str) -> Path:
    return _data() / "scripts" / script


def _copy_tree(src: Path, dst: Path, *, force: bool = False) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.rglob("*"):
        rel = item.relative_to(src)
        target = dst / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif not target.exists() or force:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


@dataclass
class PhaseResult:
    phase: str
    status: PhaseStatus
    message: str
    remediation: str = ""


@dataclass
class Phase:
    name: str
    artifact: Callable[[ProjectLayout], Path]
    execute_fn: Callable[[ProjectLayout, bool], PhaseResult]

    def _artifact(self, project: Path) -> tuple[ProjectLayout, Path]:
        layout = ProjectLayout(project)
        return layout, self.artifact(layout)

    def is_done(self, project: Path) -> bool:
        _, p = self._artifact(project)
        return p.exists() or p.is_symlink()

    def status(self, project: Path) -> PhaseResult:
        _, p = self._artifact(project)
        rel = str(p.relative_to(project))
        if p.exists() or p.is_symlink():
            return PhaseResult(self.name, "done", f"{rel} exists")
        return PhaseResult(self.name, "failed", f"{rel} missing")

    def run(self, project: Path, force: bool) -> PhaseResult:
        layout, p = self._artifact(project)
        if (p.exists() or p.is_symlink()) and not force:
            rel = str(p.relative_to(project))
            return PhaseResult(self.name, "skipped", f"{rel} {_SKIP_MSG}")
        return self.execute_fn(layout, force)


def _exec_copy_agents(layout: ProjectLayout, _force: bool) -> PhaseResult:
    try:
        shutil.copy2(_data() / "AGENTS.md", layout.agents_md)
        return PhaseResult("copy_agents", "done", "AGENTS.md written")
    except Exception as exc:
        return PhaseResult(
            "copy_agents", "failed", str(exc),
            "Check that the data directory is intact.",
        )


def _exec_copy_chief(layout: ProjectLayout, force: bool) -> PhaseResult:
    try:
        _copy_tree(_data() / "chief", layout.chief_dir, force=force)
        return PhaseResult("copy_chief", "done", ".chief/ written")
    except Exception as exc:
        return PhaseResult(
            "copy_chief", "failed", str(exc),
            "Check disk space and permissions.",
        )


def _exec_copy_scripts(layout: ProjectLayout, force: bool) -> PhaseResult:
    try:
        _copy_tree(_data() / "scripts", layout.scripts_dir, force=force)
        for sh in layout.scripts_dir.glob("*.sh"):
            sh.chmod(sh.stat().st_mode | 0o111)
        return PhaseResult("copy_scripts", "done", "scripts/ written")
    except Exception as exc:
        return PhaseResult(
            "copy_scripts", "failed", str(exc),
            "Check disk space and permissions.",
        )


def _exec_bootstrap_log(layout: ProjectLayout, _force: bool) -> PhaseResult:
    try:
        DecisionLog(layout.decision_log).bootstrap()
        return PhaseResult("bootstrap_log", "done", ".chief/decision.md created")
    except Exception as exc:
        return PhaseResult(
            "bootstrap_log", "failed", str(exc),
            "Check that .chief/ was created successfully.",
        )


def _exec_wire_agents(layout: ProjectLayout, _force: bool) -> PhaseResult:
    try:
        ret = subprocess.run(
            ["bash", str(_bundled_phase("chief-sync.sh")),
             str(layout.root)],
            cwd=layout.root,
            stdin=sys.stdin,
        ).returncode
        if ret != 0:
            return PhaseResult(
                "wire_agents", "failed", f"chief-sync.sh exited {ret}",
                "Check bash is available and scripts/ were copied.",
            )
        return PhaseResult("wire_agents", "done", "CLAUDE.md overlay written")
    except FileNotFoundError:
        return PhaseResult(
            "wire_agents", "failed", "bash not found",
            "Install bash and ensure it is on PATH.",
        )
    except Exception as exc:
        return PhaseResult(
            "wire_agents", "failed", str(exc),
            "Check that bash and scripts/ are available.",
        )


_INIT_PHASES: list[Phase] = [
    Phase(
        "copy_agents",
        lambda layout: layout.agents_md,
        _exec_copy_agents,
    ),
    Phase(
        "copy_chief",
        lambda layout: layout.chief_dir,
        _exec_copy_chief,
    ),
    Phase(
        "copy_scripts",
        lambda layout: layout.scripts_dir / "chief-install.sh",
        _exec_copy_scripts,
    ),
    Phase(
        "bootstrap_log",
        lambda layout: layout.decision_log,
        _exec_bootstrap_log,
    ),
    Phase(
        "wire_agents",
        lambda layout: layout.claude_md,
        _exec_wire_agents,
    ),
]
