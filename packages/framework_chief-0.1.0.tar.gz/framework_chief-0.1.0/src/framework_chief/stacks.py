"""stacks.py — Registry of frameworks and stacks for framework-chief.

YAML front-matter in .chief/adapters/*.md declares per-framework facts
(slot, prerequisites, detection, install commands). Combination logic —
which frameworks compose into which stacks, verdicts, composition block
paths — is declared here in Python.

Single source of truth for the CLI, unit tests, and CI bridge test.
"""
from __future__ import annotations

import re
import warnings
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


# ── enums ────────────────────────────────────────────────────────────────────


class Slot(str, Enum):
    plan_spec = "plan_spec"
    execute = "execute"
    discipline = "discipline"


class InstallMode(str, Enum):
    run = "run"
    interactive = "interactive"
    recommend_only = "recommend_only"


class Compatibility(str, Enum):
    GREEN = "GREEN"
    YELLOW = "YELLOW"
    RED = "RED"


# ── per-framework model ──────────────────────────────────────────────────────


class FrameworkMeta(BaseModel):
    name: str
    slot: Slot
    detection_marker: str | None = None
    detection_marker_alt: str | None = None
    prerequisites: dict[str, str | None] = Field(default_factory=dict)
    prerequisite_any: list[str] = Field(default_factory=list)
    install_mode: InstallMode = InstallMode.run
    install_commands: list[str] = Field(default_factory=list)


# ── combination model ────────────────────────────────────────────────────────


@dataclass
class Stack:
    name: str
    members: list[str]
    compatibility: Compatibility
    note: str = ""
    extensions: list[str] = field(default_factory=list)
    composition_block: str | None = None


@dataclass
class Registry:
    frameworks: dict[str, FrameworkMeta] = field(default_factory=dict)
    stacks: dict[str, Stack] = field(default_factory=dict)

    def get_stack(self, name: str) -> Stack | None:
        return self.stacks.get(name)

    def is_red(self, name: str) -> bool:
        s = self.stacks.get(name)
        return s is not None and s.compatibility == Compatibility.RED



# ── registry query helpers ───────────────────────────────────────────────────


def executable_commands(fw: FrameworkMeta) -> list[str]:
    """Return runnable install commands, filtering blanks and comments."""
    if fw.install_mode == InstallMode.recommend_only:
        return []
    return [
        s for cmd in fw.install_commands
        if (s := cmd.strip()) and not s.startswith("#")
    ]


def dry_run_data(
    stack: Stack,
    frameworks: dict[str, FrameworkMeta],
) -> list[tuple[str, str]]:
    """Return (kind, text) pairs — kind is 'comment' or 'command'."""
    entries: list[tuple[str, str]] = []
    for fw_name in stack.members:
        fw = frameworks.get(fw_name)
        if fw is None:
            entries.append(("comment", f"{fw_name}: (adapter not loaded)"))
            continue
        if fw.install_mode == InstallMode.recommend_only:
            entries.append((
                "comment",
                f"{fw_name}: recommend-only — run manually:",
            ))
            for cmd in fw.install_commands:
                entries.append(("comment", f"  {cmd}"))
        else:
            for cmd in fw.install_commands:
                entries.append(("command", cmd))
    for ext in stack.extensions:
        entries.append(("command", f"specify extension add {ext}"))
    return entries


# ── YAML front-matter loader ─────────────────────────────────────────────────

_FRONTMATTER_RE = re.compile(r"^---\r?\n(.*?)\r?\n---\r?\n", re.DOTALL)


def parse_front_matter(text: str) -> tuple[dict[str, Any], str]:
    """Return (yaml_meta, body_text). meta is {} when no front-matter found."""
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    return yaml.safe_load(m.group(1)) or {}, text[m.end():]


def load_adapters(adapters_dir: Path) -> dict[str, FrameworkMeta]:
    """Scan adapters_dir for *.md files with YAML front-matter."""
    result: dict[str, FrameworkMeta] = {}
    if not adapters_dir.exists():
        return result
    for md_file in sorted(adapters_dir.glob("*.md")):
        meta, _ = parse_front_matter(md_file.read_text(encoding="utf-8"))
        if not meta or "name" not in meta:
            continue
        try:
            fw = FrameworkMeta.model_validate(meta)
            result[fw.name] = fw
        except Exception as exc:
            warnings.warn(
                f"Skipping adapter {md_file.name}: {exc}",
                stacklevel=2,
            )
    return result


# ── REGISTRY singleton ───────────────────────────────────────────────────────


def load_stacks(stacks_yaml: Path) -> dict[str, Stack]:
    """Load stack definitions from a YAML file."""
    raw: dict[str, Any] = yaml.safe_load(
        stacks_yaml.read_text(encoding="utf-8")
    ) or {}
    stacks: dict[str, Stack] = {}
    for name, entry in (raw.get("stacks") or {}).items():
        try:
            stacks[name] = Stack(
                name=name,
                members=entry.get("members", []),
                compatibility=Compatibility(entry["compatibility"]),
                note=entry.get("note", ""),
                extensions=entry.get("extensions", []),
                composition_block=entry.get("composition_block"),
            )
        except Exception as exc:
            warnings.warn(
                f"Skipping stack '{name}': {exc}", stacklevel=2
            )
    return stacks


def _build_registry() -> Registry:
    data_dir = Path(__file__).parent / "data" / "chief"
    frameworks = load_adapters(data_dir / "adapters")
    stacks = load_stacks(data_dir / "stacks.yaml")
    return Registry(frameworks=frameworks, stacks=stacks)


REGISTRY: Registry = _build_registry()
