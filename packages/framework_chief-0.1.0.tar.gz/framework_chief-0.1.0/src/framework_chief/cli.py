#!/usr/bin/env python3
"""chief — Framework Chief CLI."""
from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path

from framework_chief import __version__, compose, renderer
from framework_chief.checks import check_framework
from framework_chief.decision_log import DecisionLog, LogEntryError
from framework_chief.phases import _INIT_PHASES
from framework_chief.project import ProjectLayout
from framework_chief.stacks import (
    REGISTRY, InstallMode, executable_commands, dry_run_data,
)


def _data() -> Path:
    return Path(__file__).parent / "data"


def _bundled(script: str) -> Path:
    return _data() / "scripts" / script


# ── framework checks and install ─────────────────────────────────────────────

def _last_logged_stack(project: Path) -> str | None:
    return DecisionLog(ProjectLayout(project).decision_log).last_stack()


def _install_framework(fw_name: str, project: Path) -> int:
    fw = REGISTRY.frameworks.get(fw_name)
    if fw is None:
        renderer.render_error(f"unknown framework: {fw_name}")
        return 2

    ok, items = check_framework(
        fw, project, _last_logged_stack(project), stacks=REGISTRY.stacks
    )
    renderer.render_install_check_items(items)
    if not ok:
        renderer.render_error(
            f"prereq missing for {fw_name}"
            " — stop and report to the user."
        )
        return 1

    if fw.install_mode == InstallMode.recommend_only:
        renderer.render_install_recommend(fw_name, fw.install_commands)
        return 0

    renderer.render_install_running(fw_name)
    for cmd_str in executable_commands(fw):
        renderer.render_install_command(cmd_str)
        try:
            ret = subprocess.run(
                shlex.split(cmd_str), cwd=project, stdin=sys.stdin
            ).returncode
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            renderer.render_error(str(exc))
            return 1
        if ret != 0:
            renderer.render_error(f"command exited {ret}: {cmd_str}")
            return ret
    renderer.render_install_done(fw_name)
    return 0


# ── subcommands ──────────────────────────────────────────────────────────────

def cmd_init(args: argparse.Namespace) -> int:
    project = Path(args.project_dir).resolve()
    force: bool = args.force
    status_only: bool = getattr(args, "status", False)

    if status_only:
        results = [phase.status(project) for phase in _INIT_PHASES]
        renderer.render_init_status(results, project)
        return 0 if all(r.status == "done" for r in results) else 1

    renderer.show_banner()
    project.mkdir(parents=True, exist_ok=True)

    results = []
    for phase in _INIT_PHASES:
        r = phase.run(project, force)
        results.append(r)
        if r.status == "failed":
            renderer.render_init_failure(results)
            return 1

    renderer.render_init_success(results, project)
    return 0


def cmd_sync(args: argparse.Namespace) -> int:
    project = Path(args.project_dir).resolve()
    ai = getattr(args, "ai", "all") or "all"
    renderer.render_sync_header(ai, project)
    try:
        ret = subprocess.run(
            [
                "bash", str(_bundled("chief-sync.sh")),
                "--ai", ai, str(project),
            ],
            cwd=project,
            stdin=sys.stdin,
        ).returncode
    except FileNotFoundError:
        renderer.render_error("bash not found")
        return 127
    if ret == 0:
        renderer.render_sync_success()
    return ret


def cmd_dry_run(args: argparse.Namespace) -> int:
    stack_name = args.stack
    stack = REGISTRY.get_stack(stack_name)
    if stack is None:
        renderer.render_error(f"unknown stack: {stack_name}")
        return 2
    if REGISTRY.is_red(stack_name):
        renderer.render_dry_run_refused(stack_name, stack.note)
        return 1

    entries = dry_run_data(stack, REGISTRY.frameworks)
    renderer.render_dry_run(stack_name, entries, stack.note)
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    fw_name = args.framework
    fw = REGISTRY.frameworks.get(fw_name)
    if fw is None:
        renderer.render_error(f"unknown framework: {fw_name}")
        return 2
    project = Path(args.project_dir).resolve()
    ok, items = check_framework(
        fw, project, _last_logged_stack(project), stacks=REGISTRY.stacks
    )
    renderer.render_check(fw_name, items, ok)
    return 0 if ok else 1


def cmd_install(args: argparse.Namespace) -> int:
    return _install_framework(
        args.framework, Path(args.project_dir).resolve()
    )


def cmd_log(args: argparse.Namespace) -> int:
    project = Path(args.project_dir).resolve()
    log = DecisionLog(ProjectLayout(project).decision_log)

    try:
        parsed, date = log.parse_and_append(args.kvpairs)
    except LogEntryError as exc:
        renderer.render_error(str(exc))
        return 2

    renderer.render_log(parsed, date, log.path)

    if args.verbose:
        renderer.render_log_verbose(log.read_entries(), log.path)

    return 0


# ── compose subcommand ───────────────────────────────────────────────────────

def cmd_compose(args: argparse.Namespace) -> int:
    stack_name = args.stack
    project = Path(args.project_dir).resolve()
    agents_md = ProjectLayout(project).agents_md

    stack = REGISTRY.get_stack(stack_name)
    if stack is None:
        renderer.render_error(f"unknown stack: {stack_name}")
        return 2
    if stack.composition_block is None:
        renderer.render_error(f"{stack_name} has no composition block")
        return 2
    if not agents_md.exists():
        renderer.render_error(
            f"{agents_md} not found — run 'chief init' first"
        )
        return 1

    values = {"request_summary": args.request_summary}
    try:
        compose.apply_composition_block(stack, agents_md, values=values)
    except compose.BlockAlreadyPresent:
        renderer.render_compose_already_present(stack_name)
        return 0
    except compose.CompositionError as exc:
        renderer.render_error(str(exc))
        return 1

    renderer.render_compose_done(stack_name, agents_md)
    return 0


# ── argument parser ──────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(
        prog="chief",
        description=(
            "Framework Chief — decide and install the right "
            "spec-driven-development stack."
        ),
    )
    p.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    sub = p.add_subparsers(dest="command", metavar="<command>")

    pi = sub.add_parser(
        "init",
        help="Copy chief into a project and wire all agents",
    )
    pi.add_argument(
        "project_dir", nargs="?", default=".", metavar="PROJECT_DIR"
    )
    pi.add_argument(
        "--force", action="store_true", help="Overwrite existing files"
    )
    pi.add_argument(
        "--status", action="store_true",
        help="Check phase completion (read-only)",
    )
    pi.set_defaults(func=cmd_init)

    ps = sub.add_parser(
        "sync",
        help="Re-wire agent entry points (CLAUDE.md, copilot, codex)",
    )
    ps.add_argument(
        "project_dir", nargs="?", default=".", metavar="PROJECT_DIR"
    )
    ps.add_argument(
        "--ai",
        choices=["all", "claude", "copilot", "codex"],
        default="all",
        metavar="VENDOR",
        help=(
            "Which agent harness to wire:"
            " all (default), claude, copilot, codex"
        ),
    )
    ps.set_defaults(func=cmd_sync)

    pdr = sub.add_parser(
        "dry-run",
        help="Print install sequence for a stack (no mutation)",
    )
    pdr.add_argument("stack", metavar="STACK")
    pdr.add_argument(
        "project_dir", nargs="?", default=".", metavar="PROJECT_DIR"
    )
    pdr.set_defaults(func=cmd_dry_run)

    pch = sub.add_parser(
        "check",
        help="Verify prereqs and detect existing install",
    )
    pch.add_argument("framework", metavar="FRAMEWORK")
    pch.add_argument(
        "project_dir", nargs="?", default=".", metavar="PROJECT_DIR"
    )
    pch.set_defaults(func=cmd_check)

    pin = sub.add_parser(
        "install", help="Install one framework into the project"
    )
    pin.add_argument("framework", metavar="FRAMEWORK")
    pin.add_argument(
        "project_dir", nargs="?", default=".", metavar="PROJECT_DIR"
    )
    pin.set_defaults(func=cmd_install)

    pl = sub.add_parser(
        "log",
        help="Append a structured entry to .chief/decision.md",
    )
    pl.add_argument("kvpairs", nargs="+", metavar="key=value")
    pl.add_argument(
        "--project-dir", default=".", dest="project_dir",
        metavar="PROJECT_DIR",
    )
    pl.add_argument(
        "--verbose", "-v", action="store_true",
        help="Print full decision log history after appending",
    )
    pl.set_defaults(func=cmd_log)

    pc = sub.add_parser(
        "compose",
        help="Fill and append a composition block to AGENTS.md",
    )
    pc.add_argument("stack", metavar="STACK")
    pc.add_argument(
        "project_dir", nargs="?", default=".", metavar="PROJECT_DIR"
    )
    pc.add_argument(
        "--request-summary", default="", dest="request_summary",
        metavar="SUMMARY",
    )
    pc.set_defaults(func=cmd_compose)

    args = p.parse_args()
    if not hasattr(args, "func"):
        p.print_help()
        sys.exit(2)

    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
