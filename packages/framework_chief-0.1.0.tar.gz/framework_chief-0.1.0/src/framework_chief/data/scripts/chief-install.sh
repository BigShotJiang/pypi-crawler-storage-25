#!/usr/bin/env bash
# chief-install — thin shim: delegates all subcommands to the Python CLI.
exec python3 -m framework_chief.cli "$@"
