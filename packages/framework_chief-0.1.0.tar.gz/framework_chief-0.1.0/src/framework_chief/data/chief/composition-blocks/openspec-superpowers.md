---
stack: openspec-superpowers
placeholders:
  DATE: auto
  REQUEST_SUMMARY: required
  superpowers_version: prompt
---

# Composition Block: OpenSpec + Superpowers

**The model pair.** Paste this block into the project's `AGENTS.md` after OpenSpec is
installed and *before* Superpowers is installed for the first time.

---

## Framework Chief — Composition Block

```
installed: <DATE>
stack: openspec + superpowers (model pair)
request: <REQUEST_SUMMARY>
superpowers_version: <superpowers_version>
```

### Superpowers skill overrides — demotion block (Bridge 1)

**Context:** OpenSpec owns the Plan/Spec slot in this project. Superpowers' planning-phase
skills would conflict with OpenSpec's workflow. This block demotes them per Superpowers'
own priority rule: *user instructions in AGENTS.md outrank skills.*

**Skills DISABLED** (OpenSpec owns these phases):
- `brainstorm` — OpenSpec owns discovery and requirements gathering
- Any Superpowers skill that generates a standalone plan document or spec file

**Skills ACTIVE** (discipline subset — no conflict with OpenSpec):
- `tdd` — test-driven development enforcement
- `code-review` — structured code review protocol
- `debugging` — systematic debugging process
- `refactoring` — safe refactoring discipline
- `writing-plans` — **ACTIVE, with redirection:** reads `specs/` and `design/` from
  OpenSpec as its input. Does not generate a separate plan document; uses OpenSpec's
  artifacts as the authoritative source.

**Practical effect:** When Superpowers would normally run its brainstorm or planning
phase, defer to OpenSpec's workflow instead. Superpowers activates only for TDD,
code review, debugging, and refactoring discipline within tasks that OpenSpec has
already planned and specced.

---

### Version note

Fill in `superpowers_version` above immediately after Superpowers installs — run
`/plugin list` in Claude Code (or the equivalent in your harness) and record the
version shown for Superpowers.

If Superpowers upgrades and a skill name in the disabled or active list no longer
matches, the override is **silently ignored** — the block does not error, it simply
stops applying. After any Superpowers upgrade: diff the new skill list against the
names here and update this block. The `superpowers_version` field makes it easy to
spot when the installed version has diverged from what this block was written against.
