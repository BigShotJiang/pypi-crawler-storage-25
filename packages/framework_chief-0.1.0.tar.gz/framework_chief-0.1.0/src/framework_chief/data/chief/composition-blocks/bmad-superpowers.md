---
stack: bmad-superpowers
placeholders:
  DATE: auto
  REQUEST_SUMMARY: required
  bmad_version: prompt
  superpowers_version: prompt
---

# Composition Block: BMAD + Superpowers

**The advanced pair.** YELLOW — works, but requires surgical disabling on both sides.
Only use this when the request genuinely needs BMAD's role/process discipline AND
Superpowers' TDD enforcement. If in doubt, use OpenSpec + Superpowers instead.

Paste this block into the project's `AGENTS.md` after BMAD is installed and *before*
Superpowers is installed for the first time.

---

## Framework Chief — Composition Block

```
installed: <DATE>
stack: bmad + superpowers (advanced pair — surgical hybrid)
request: <REQUEST_SUMMARY>
bmad_version: <bmad_version>
superpowers_version: <superpowers_version>
```

### Superpowers skill overrides — demotion block (Bridge 1)

**Context:** BMAD is a full rail that owns brainstorm → plan → execute. Superpowers is
also a full rail. Composing them without this block means two brains fight for the same
phases. This block surgically disables the contended phases on each side.

**BMAD owns (Superpowers stands down from these phases):**
- Discovery and brainstorming
- Planning and spec generation
- Role assignments and multi-role handoffs
- Any phase where BMAD's workflow forces the next step

**Skills DISABLED in Superpowers** (BMAD owns these):
- `brainstorm` — BMAD owns discovery
- `writing-plans` — BMAD owns plan generation
- Any Superpowers skill that generates a spec document or role assignment

**Skills ACTIVE in Superpowers** (discipline subset — no conflict with BMAD):
- `tdd` — test-driven development enforcement
- `code-review` — structured code review protocol
- `debugging` — systematic debugging process
- `refactoring` — safe refactoring discipline

**Practical effect:** BMAD runs its full lifecycle up through task assignment. Once a
task is executing, Superpowers' discipline skills activate (TDD, review, debug). The
two rails hand off at the task-execution boundary and do not overlap.

---

### Seam to watch

BMAD forces its next phase by emitting a specific prompt pattern. If Superpowers
intercepts that prompt before BMAD's next-phase logic runs, the handoff breaks.
Monitor the first few BMAD → Superpowers transitions in a real session. If you see
Superpowers activating during a BMAD planning phase, add the specific BMAD prompt
pattern to the disabled-skills list above.

**Fresh-chat constraint (BMAD architectural requirement):** BMAD explicitly requires
each workflow phase to run in a fresh chat session to avoid context saturation. This
means the demotion block must be committed to `AGENTS.md` on disk before any BMAD
phase starts — it cannot be held only in the current session's context. If the block
exists only in an uncommitted working copy, the next BMAD phase (which opens a new
chat) will not see it and Superpowers will activate without the overrides. Always
commit `AGENTS.md` immediately after writing the composition block, before handing
off to BMAD.

---

### Version note

Fill in `bmad_version` and `superpowers_version` above immediately after each
installs — run `npx bmad-method --version` for BMAD and `/plugin list` in your
harness for Superpowers.

Both evolve their skill names independently. After any upgrade to either, diff the
new skill list against the names in this block and update accordingly. A mismatched
skill name is **silently ignored** — the override does not error, it simply stops
applying. The version fields make it easy to spot when the installed versions have
diverged from what this block was written against.
