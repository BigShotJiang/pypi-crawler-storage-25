---
name: spec-kit
slot: plan_spec
detection_marker: .specify
prerequisites:
  python3: "3.11"
  git: null
prerequisite_any:
  - uv
  - pipx
install_mode: run
install_commands:
  - "uv tool install specify-cli --from git+https://github.com/github/spec-kit.git"
  - "specify init ."
---

# Adapter: spec-kit

spec-kit (github/spec-kit) occupies the **Plan/Spec slot**. It is the right choice when
the request needs governance-grade rigor: regulatory traceability, multi-artifact specs,
or multi-stakeholder sign-off. It brings a constitution, checklists, and a structured
`specs/` tree that serves as the single source of truth.

## Prerequisites

| Tool | Minimum | Check |
|------|---------|-------|
| python3 | 3.11+ | `python3 --version` |
| uv | any | `uv --version` (preferred) |
| pipx | any | `pipx --version` (fallback if no uv) |
| git | any | `git --version` |

## Existing install detection

`.specify/` directory at project root. If present, do not re-init — report state to user.

## Install commands

```bash
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git
specify init .
```

With pipx fallback:
```bash
pipx install git+https://github.com/github/spec-kit.git
specify init .
```

## Artifacts created

| Path | Purpose |
|------|---------|
| `.specify/` | spec-kit configuration and templates |
| `specs/` | generated specification documents |
| `plan.md` | high-level plan artifact |
| `research.md` | research and discovery artifact |

## Composition notes

**spec-kit has its own discipline layer.** The constitution template includes TDD mandatory
and code review as default example principles. Native community extensions cover the same
ground as Superpowers without cross-tool friction:

| Native spec-kit extension | Covers |
|---|---|
| `Review` | Post-implementation code review with specialized agents |
| `Staff Review` | Staff-engineer-level validation against spec |
| `QA Testing` | Systematic QA with acceptance criteria validation |
| `SpecTest` | Auto-generates test scaffolds from spec requirements |
| `Multi-Model Review` | Cross-model code review and handoff |

**If the user asks about +Superpowers:** surface the above at the AGREE gate and
recommend native extensions first. If they specifically want Superpowers' exact slash
command workflow, the correct path is the community **Superpowers Bridge extension**:

```bash
specify extension add superpowers-bridge
```

Two maintained variants exist in the catalog (`RbBtSn0w` and `WangX0111`). Use one
of these — do NOT write a manual AGENTS.md demotion block for spec-kit+Superpowers.
A manual block conflicts with spec-kit's own constitution hierarchy and won't stay
current as either tool evolves.

Never compose with OpenSpec or BMAD (same Plan/Spec slot, namespace collision).

## Routing-relevant extensions

These extensions change a Framework Chief routing or composition decision. They are not
general workflow enhancements — they affect which framework to recommend or whether a
cross-framework combination is needed at all.

| Extension | ID | When it changes routing |
|---|---|---|
| **Brownfield Bootstrap** | `brownfield` | Brownfield project + governance need → spec-kit + this extension instead of OpenSpec. Discriminator: if the user needs audit traceability for an existing codebase, spec-kit+brownfield is the right call even though the project is brownfield. OpenSpec remains correct for low-ceremony brownfield features. |
| **BrownKit** | `brownkit` | Same routing as above but adds security and QA risk assessment for legacy systems. Choose BrownKit when the brownfield codebase has unknown security/quality risk surface. |
| **Canon** | `canon` | **Fills a classification gap.** Code-first and spec-drift workflows: existing code, no specs, user wants to retrofit spec coverage. Neither OpenSpec nor vanilla spec-kit handles this explicitly. Route "has working code, wants retroactive specs" here. Also covers spec-drift detection. |
| **Ralph Loop** | `ralph` | Autonomous implementation loop within spec-kit — substitutes GSD-2 for lighter automation needs. If spec-kit is already installed and the user wants some hands-off execution, Ralph Loop runs inside the AI harness (Claude Code/Cursor). GSD-2 is still the right call for overnight CLI runs with crash recovery, cost ceilings, and multi-provider routing. |
| **Fleet Orchestrator** | `fleet` | Full lifecycle orchestration within spec-kit — substitutes BMAD when the need is lifecycle structure without multi-role persona handoffs. If the user needs full lifecycle phases (planning → architecture → stories) but does NOT need BMAD's role discipline or multi-role discovery, Fleet keeps everything in spec-kit's governance model. |
| **Product Forge** | `product-forge` | Same routing as Fleet but adds portfolio management, monorepo support, and V-Model. Choose over Fleet when the request involves multiple products, a monorepo, or a formal V-Model release process. |
| **Superpowers Bridge** | `superpowers-bridge` | Bridge for spec-kit + Superpowers (see Composition notes above). Use this instead of a manual demotion block. |

Install any of the above after `specify init`:
```bash
specify extension add <id>
```

## GSD-2 handoff (spec-kit → GSD-2 migration)

When migrating to GSD-2, seed its context files from spec-kit's artifacts before running
`gsd`. See `.chief/adapters/gsd2.md` for the seeding protocol. After seeding, spec-kit
is done — it does not co-run.
