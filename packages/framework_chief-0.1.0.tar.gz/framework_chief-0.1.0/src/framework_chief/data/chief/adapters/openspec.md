---
name: openspec
slot: plan_spec
detection_marker: openspec
prerequisites:
  node: "20.19"
  npm: null
  git: null
install_mode: run
install_commands:
  - "npm install -g @fission-ai/openspec@latest"
  - "openspec init --tools claude"
---

# Adapter: openspec

OpenSpec (Fission-AI/OpenSpec) occupies the **Plan/Spec slot**. It is the right choice
for well-scoped features in brownfield repos where fast iteration and low ceremony matter
more than multi-artifact governance. It is the natural left half of the model pair
(OpenSpec + Superpowers).

## Prerequisites

| Tool | Minimum | Check |
|------|---------|-------|
| node | 20.19+ | `node --version` |
| npm | any | `npm --version` |
| git | any | `git --version` |

## Existing install detection

`openspec/` directory at project root. If present, do not re-init — report state to user.

## Install commands

```bash
npm install -g @fission-ai/openspec@latest
openspec init
```

## Artifacts created

| Path | Purpose |
|------|---------|
| `openspec/` | OpenSpec configuration |
| `specs/` | specification documents |
| `design/` | design documents |
| `tasks.md` | task breakdown (OpenSpec's planning output) |

## Expanded workflow profile

The default install uses the core profile: `propose → apply → sync → archive`. An
expanded set of commands is available by running `openspec config profile` and selecting
the extended workflow. These commands are opt-in and do not change the default flow:

| Command | When to use |
|---------|-------------|
| `/opsx:new` | Scaffold a change and generate artifacts incrementally instead of all at once |
| `/opsx:continue` | Create one artifact at a time following the dependency chain |
| `/opsx:ff` | Fast-forward through all planning artifacts in dependency order in one shot |
| `/opsx:verify` | Validate implementation before archive: CRITICAL / WARNING / SUGGESTION report |
| `/opsx:bulk-archive` | Archive multiple completed changes at once, resolving spec conflicts |
| `/opsx:onboard` | Interactive tutorial against the real codebase |

`/opsx:explore` is available in the default profile — it lets the agent think through a
problem and analyze the codebase without creating any artifacts. Useful for discovery
before `/opsx:propose`.

**Note on tool syntax**: Most harnesses use colon syntax (`/opsx:propose`). Cursor and
Windsurf use hyphens (`/opsx-propose`). Kimi and Trae use skill-based invocations
(`/skill:openspec-propose`). If authoring a demotion block for a specific harness,
use the syntax that matches the installed harness.

**Architecture note**: As of 2026, OpenSpec's internal workspace architecture is being
restructured (see `WORKSPACE_REIMPLEMENTATION_DIRECTION.md` in the repo). The external
slash command API is stable, but internal file layouts may shift across minor versions.
Pin the version in the install command if stability is required.

## Composition notes

**OpenSpec + Superpowers is the model pair (GREEN).** It is the lowest-ceremony stack that
still enforces testing discipline. A demotion block is required — see
`.chief/composition-blocks/openspec-superpowers.md`.

Key detail for the demotion block: Superpowers' `writing-plans` skill stays ON and reads
OpenSpec's `specs/` + `design/` directly. OpenSpec's `tasks.md` is not transformed into
Superpowers' plan format — the re-plan approach is used instead.

Install order: OpenSpec first → write composition block into AGENTS.md → Superpowers.
Superpowers must read the demotion block on its first run.

Never compose with spec-kit or BMAD (same Plan/Spec slot).

**Community Superpowers Bridge for OpenSpec:** A community `superpowers-bridge` schema
exists for OpenSpec (authored by @JiangWay — distinct from spec-kit's variant). It is
separate from the demotion block described above and covers harnesses where Superpowers'
plugin mechanism is the primary integration point rather than AGENTS.md. If the user is
on such a harness and explicitly wants this path, surface the schema; otherwise the
demotion block approach in `.chief/composition-blocks/openspec-superpowers.md` is the
maintained default.
