---
name: gsd2
slot: execute
detection_marker: .gsd
prerequisites:
  node: "22.0"
install_mode: recommend_only
install_commands:
  - "npm install -g gsd-pi"
  - "gsd"
---

# Adapter: gsd2

GSD-2 (gsd-build/GSD-2) occupies the **Execute slot**. It is a separate CLI tool for
long autonomous builds — the user installs it globally and runs it as a dedicated process,
not as an in-agent command. Choose GSD-2 when the user wants hands-off autonomous
execution of a large, already-specced body of work.

## Why recommend-only

GSD-2's global install modifies the user's environment, requires a login step (`gsd /login`),
and starts a persistent session. These are not reversible shell commands — they require the
user's active participation. The chief NEVER auto-runs GSD-2's install. It presents the
commands and waits for the user to run them.

## Prerequisites

| Tool | Minimum | Recommended | Check |
|------|---------|-------------|-------|
| node | 22.0+ | 24 LTS | `node --version` |

## Install — user runs these themselves

```bash
npm install -g gsd-pi
gsd        # then /login to authenticate
```

## Existing install detection

`.gsd/` directory at project root indicates GSD-2 is already managing this project.

## Artifacts created

| Path | Purpose |
|------|---------|
| `.gsd/` | Markdown projections of runtime state (human-readable, checked into git) |
| `gsd.db` | SQLite database — authoritative state (single writer, do not edit manually) |

Note: `.gsd/*.md` files are projections rendered from `gsd.db`, not the source of truth.
The database is never read from markdown at runtime unless explicitly recovered.

## Lighter alternative: Ralph Loop (spec-kit extension)

If spec-kit is already installed and the user wants *some* automation but not a full
overnight CLI run, **Ralph Loop** (`specify extension add ralph`) is a lighter alternative
that runs inside the AI harness (Claude Code, Cursor). It does not require a global
install, a separate process, or a login step.

Choose GSD-2 over Ralph Loop when:
- The build is expected to run overnight or for hours unattended
- Crash recovery and automatic restart matter
- Cost ceilings or multi-provider routing are needed

Choose Ralph Loop when spec-kit is already the Plan/Spec layer and the user wants
hands-off task execution *within* the current AI session.

## The fundamental constraint

**GSD-2 reads only its own `.gsd/` tree.** It cannot read spec-kit's `specs/`,
OpenSpec's `design/`, or any other Plan/Spec layer's artifacts directly. This is why
GSD-2 never co-runs with a Plan/Spec layer — it is always a handoff, never coexistence.

## Handoff protocol: spec-kit → GSD-2

When migrating from spec-kit to GSD-2, seed GSD-2's startup files from spec-kit's
artifacts before starting a GSD-2 session. Run once during the handoff; spec-kit is
then done.

**Architecture note:** GSD-2 is database-first. `.gsd/*.md` files are projections
rendered from SQLite (`gsd.db`), never re-imported during normal runtime. The
exception is the named startup files below — GSD-2 reads these at session start
before the database is populated, bootstrapping its initial context. After the first
`gsd` run, the database becomes authoritative and edits to these markdown files have
no effect without an explicit recovery step.

Seed the following startup files:

| spec-kit artifact | → | GSD-2 startup file | Notes |
|---|---|---|---|
| `specs/<name>.md` | → | `.gsd/REQUIREMENTS.md` | Formal requirements GSD reads before first run |
| `plan.md` | → | `.gsd/PROJECT.md` | Project description and metadata |
| `research.md` | → | `.gsd/KNOWLEDGE.md` | Rules, patterns, lessons — writable pre-DB |
| (runtime env) | → | `.gsd/RUNTIME.md` | API endpoints, env vars, service URLs |

Old path (pre-2026, now incorrect): `.gsd/context/spec.md`, `.gsd/context/plan.md`,
`.gsd/context/research.md`. Do not use — GSD-2 no longer reads these at startup.

After seeding, verify GSD-2 sees the context with `gsd status` before starting the
autonomous run.

## What the chief shows the user at the AGREE gate

```
GSD-2 is a separate CLI tool — I will not install it for you. Here are the commands
to run yourself after this session:

  npm install -g gsd-pi
  gsd          # then type /login to authenticate

Once installed and logged in, start your autonomous session with:
  gsd start
```
