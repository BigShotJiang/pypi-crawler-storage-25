# ADR-0003: `chief compose` Subcommand for Composition Block Substitution

**Status**: Accepted
**Date**: 2026-05-15

## Context

Composition blocks (demotion blocks for OpenSpec+Superpowers and BMAD+Superpowers) have
placeholder tokens that must be filled at install time: `<DATE>`, `<REQUEST SUMMARY>`,
`superpowers_version`, and (for BMAD) `bmad_version`. The AGENTS.md loop documented that
"you write the composition block" — but the substitution step had no code owner. It was a
manual task described in prose.

Three failure modes followed:
1. **Forgotten placeholders**: the filled block lands in AGENTS.md with literal `<DATE>`
   or `<REQUEST SUMMARY>` tokens. Superpowers reads the block and gets a nonsense skill
   demotion target.
2. **No idempotency**: re-running install could append the same block twice.
3. **No testability**: the substitution logic existed only in natural-language instructions.

## Decision

Add `chief compose <stack>` as a CLI subcommand. Composition block files get YAML
front-matter declaring per-placeholder fill strategies:

```yaml
---
stack: openspec-superpowers
placeholders:
  DATE: auto
  REQUEST_SUMMARY: required
  superpowers_version: prompt
---
```

Strategy semantics:
- `auto` — filled programmatically (DATE → today's ISO date). No user input needed.
- `required` — must be provided via `--request-summary` CLI arg or interactive input.
  Exits non-zero if empty.
- `prompt` — asks user interactively; leaves the placeholder token if the user skips.

Idempotency: before writing, `cmd_compose` checks for a marker comment
`<!-- chief:composition-block:<stack> -->` in AGENTS.md. If found, it reports
"already present" and exits 0 without writing.

The filled block is appended to the project's `AGENTS.md` with the marker comment
prepended.

## Consequences

**Positive:**
- Substitution is repeatable, testable, and traceable via the marker comment.
- YAML-declared strategies make the fill contract explicit — no prose to interpret.
- `auto` for DATE removes the most common placeholder mistake.

**Negative / watch points:**
- The `prompt` strategy requires a TTY. Callers in CI must use `--request-summary` or
  set `REQUEST_SUMMARY` as an environment variable (not yet implemented — acceptable for
  v0 since compose is typically a human-invoked step).
- The marker comment is a convention, not enforced by a schema. A block written outside
  `chief compose` (e.g., manually) won't have the marker and will be written again.
  Acceptable — the tool is the canonical path.

**Alternative considered and rejected:**
A `sed`-based substitution in the bash script. Rejected for the same reason as
ADR-0001: bash version comparison is fragile and untestable. Python owns substitution.
