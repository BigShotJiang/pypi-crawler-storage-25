# ADR-0004: Named 5-Phase Init Pipeline with Implicit Checkpointing

**Status**: Accepted
**Date**: 2026-05-15

## Context

`chief init` ran as a monolithic sequence: copy AGENTS.md, copy `.chief/`, copy
`scripts/`, run `chief-install.sh init`, run `chief-sync.sh`. If any step failed
mid-sequence, the project was left in an unknown partial state. There was no way to
inspect which steps had completed, no per-step recovery guidance, and re-running `init`
could clobber work that had already landed.

The `wire_agents` step (running `chief-sync.sh`) was the most likely failure point: it
depends on `bash` being on PATH, on the scripts having been copied, and on the filesystem
state being consistent. A failure there gave a generic non-zero exit with no remediation
path.

## Decision

Split `chief init` into 5 named phases executed sequentially:

| Phase | Artifact created | Checkpoint condition |
|-------|-----------------|---------------------|
| `copy_agents` | `AGENTS.md` | file exists |
| `copy_chief` | `.chief/` | directory exists |
| `copy_scripts` | `scripts/` | `scripts/chief-install.sh` exists |
| `bootstrap_log` | `.chief/decision.md` | file exists |
| `wire_agents` | `CLAUDE.md` symlink | symlink or file exists |

**Implicit checkpointing**: each phase checks its own output artifact. If the artifact
exists and `--force` is not set, the phase reports "skipped" and moves on. This makes
re-running `chief init` safe and predictable.

**Per-phase remediation**: phases that fail produce a `remediation` string guiding
recovery (e.g., "Check that bash is available and scripts/ were copied correctly.").

**`chief init --status`**: a read-only diagnostic flag. Runs all phases in check-only
mode — `_phase_status()` inspects artifacts without writing anything. Useful when
`chief init` has been run externally (e.g., by a CI setup script) and the operator
wants to verify state.

## Consequences

**Positive:**
- Re-running `chief init` after partial failure is safe. Completed phases skip; failed
  phases retry.
- `--status` provides a diagnostic without guesswork: operators see "✓ copy_agents,
  ✓ copy_chief, ○ wire_agents" and know exactly what to fix.
- Per-phase remediation messages reduce the support surface: the error message tells
  the user what to check.

**Negative / watch points:**
- Phases are sequential, not concurrent. At init scale (5 filesystem operations + 1 bash
  call) this is irrelevant.
- `wire_agents` still delegates to `chief-sync.sh` (real bash, see ADR-0001). If bash is
  absent, `wire_agents` fails with a clear remediation message.
- Implicit checkpointing means a phase that partially completed (e.g., `copy_chief`
  wrote 3 of 10 files before a disk error) may show "skipped" on re-run if the output
  directory exists. Acceptable — the `--force` flag re-runs all phases unconditionally.
