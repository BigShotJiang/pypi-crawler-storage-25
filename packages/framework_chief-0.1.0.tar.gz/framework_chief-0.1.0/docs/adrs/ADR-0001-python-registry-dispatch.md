# ADR-0001: Python Registry as Dispatch Source of Truth

**Status**: Accepted
**Date**: 2026-05-15

## Context

`chief-install.sh` was 379 lines of bash that owned all dispatch logic: prereq checking,
stack dry-runs, install command execution, and decision log appending. Adding a new stack
required edits in four places: the bash script (dispatch + prereq logic), `cli.py`
(argument wiring), `AGENTS.md` (compatibility matrix), and `tests/unit/test_cli.py`
(subprocess assertions). The four-point drift was the dominant maintenance cost.

Bash's structural weaknesses compounded this:
- No types: version comparison was ad-hoc `grep -oP` patterns with silent failures.
- No unit tests: the bash dispatch was only covered by subprocess round-trips.
- Duplicate logic: stacks known to `AGENTS.md` had to be re-declared in bash case
  statements, with no automated check for divergence.

## Decision

Create `src/framework_chief/stacks.py` as the single source of truth for all framework
and stack facts. `chief-install.sh` becomes a 3-line thin shim:

```bash
#!/usr/bin/env bash
exec python3 -m framework_chief.cli "$@"
```

Python owns:
- `check_tool(tool, min_version)` — version comparison with a clear return type `(bool, str)`.
- `_check_framework(fw, project)` — prereq + detection logic against `FrameworkMeta`.
- `_install_framework(fw, project)` — install dispatch by `install_mode`.
- `cmd_log()` — pure Python append to `.chief/decision.md`.
- `cmd_dry_run()` — looks up `REGISTRY`, refuses RED, prints sequence.

`chief-sync.sh` is explicitly excluded from this decision: it is 103 lines of filesystem
wiring (symlinks, directory creation, file copying) with no routing logic and no history
of drift. It stays real bash.

## Consequences

**Positive:**
- Adding a stack means editing one file (`stacks.py`). Tests auto-pick it up via
  `VALID_STACKS` / `RED_STACKS` parametrize lists.
- `check_tool()` handles `v20.19.0` node output, OR-groups (`uv` OR `pipx`), and
  `recommend_only` mode uniformly — replacing fragmented bash patterns.
- Pure Python unit tests against `REGISTRY` are fast (no subprocess fork per test).

**Negative / watch points:**
- Python must be available wherever `chief-install.sh` is invoked. This was already true
  for the `framework_chief` package — no new requirement.
- The thin shim adds one exec hop when callers invoke `chief-install.sh` directly.
  Integration tests cover the full round-trip; the shim itself has no testable logic.

**Not revisited by this ADR:**
`chief-sync.sh` staying bash. See rationale above. If it ever acquires routing logic,
revisit then.
