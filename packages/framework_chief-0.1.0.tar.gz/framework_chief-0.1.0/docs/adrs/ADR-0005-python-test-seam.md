# ADR-0005: Python Test Seam — REGISTRY as Primary Test Surface

**Status**: Accepted
**Date**: 2026-05-15

## Context

`tests/unit/test_cli.py` tested the `chief` entry point via subprocess. Every stack
(16 valid + 5 RED) had its own subprocess test case. Every framework (5) had a subprocess
`check` test. Each subprocess test forks a process, loads the Python interpreter, and
invokes bash, taking ~200–500ms per test. The full suite was slow.

Worse, the tests did not test Python logic directly. They tested that bash dispatched
correctly — which was the wrong seam. When the dispatch moved to Python (ADR-0001), the
subprocess tests became a slow proxy for logic that was now directly testable.

A second gap: no test verified that `AGENTS.md`'s compatibility matrix matched the
code's routing verdicts. The four-point drift problem (ADR-0001) was invisible to CI.

## Decision

**Primary test surface: `REGISTRY` directly (pure Python, no subprocess).**

1. `@pytest.mark.parametrize("stack", VALID_STACKS)` — each valid stack is in REGISTRY
   and is not RED. One assertion per stack, no process fork.
2. `@pytest.mark.parametrize("stack", RED_STACKS)` — each RED stack is RED in REGISTRY.
3. `test_registry_frameworks_loaded()` — all 5 frameworks loaded from YAML front-matter.
4. Framework-level: `test_framework_has_install_commands(fw)` — no empty command lists.

**CI bridge test: `test_registry_matrix_matches_agents_md()`.**

Checks a hardcoded mapping of compatibility pair → expected `Compatibility` enum value
against `REGISTRY.get_stack()`. If AGENTS.md is updated (compatibility verdict changes)
without updating `stacks.py`, this test fails. Catches the primary drift vector.

If `AGENTS.md` is absent (project not yet initialized), the test skips cleanly via
`pytest.skip`.

**Subprocess smoke tests: exactly 3.**

| Test | What it catches |
|------|----------------|
| `test_version_exits_0_and_contains_version_string` | CLI entry point loads, `__version__` matches |
| `test_help_exits_0_and_lists_all_subcommands` | argparse wiring correct, `compose` present |
| `test_dry_run_unknown_stack_exits_nonzero` | CLI rejects unknown stacks |

**Mechanical suite (`tests/mechanical/run-mechanical.sh`)**: slimmed to:
- Smoke: `chief --version`, `chief --help`
- Sync idempotency: `chief sync` twice, verify CLAUDE.md symlink unchanged

The mechanical suite no longer validates every stack name end-to-end. Accepted:
the shim is 3 lines with no logic, and integration tests (`tests/integration/`) cover
full install round-trips.

## Consequences

**Positive:**
- Adding a stack means one line in `stacks.py` + one line in `VALID_STACKS` or
  `RED_STACKS`. No new subprocess test required.
- Pure Python tests run in milliseconds. CI feedback loop tightens.
- CI bridge test is the automated check that AGENTS.md and REGISTRY stay in sync.

**Negative / watch points:**
- The bridge test uses a hardcoded mapping, not full AGENTS.md parsing. If AGENTS.md
  adds a new combination row without a corresponding mapping entry, the test won't
  catch it automatically. Mitigation: the mapping is reviewed when AGENTS.md is updated
  (the file is the trigger for the `routing-eval.yml` CI job).
- `test_registry_frameworks_loaded` only passes after YAML front-matter has been written
  to the adapter files. Before that, it fails with a clear message. This is intentional —
  the test is the incentive to complete ADR-0002's implementation.
