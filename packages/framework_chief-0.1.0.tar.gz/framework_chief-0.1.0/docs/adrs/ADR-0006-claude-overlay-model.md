# ADR-0006 — CLAUDE.md as a real overlay file, not a symlink

**Date:** 2026-05-15
**Status:** Accepted

---

## Context

`chief-sync.sh` wires the Framework Chief router into every agent harness present in a
user's project. For Claude Code it previously created `CLAUDE.md` as a symlink pointing
at `AGENTS.md`.

The problem: `AGENTS.md` is the vendor-neutral base — it must be readable by Codex,
GitHub Copilot, Cursor, and any LLM that natively consumes `AGENTS.md`. `CLAUDE.md` is
Claude Code-specific. Conflating the two via a symlink means Claude Code reads exactly
the same bytes every other vendor reads, with no room for Claude Code-specific mechanics
(hooks, memory instructions, harness-specific tool-use patterns).

A second problem: the `Write` tool in Claude Code's own harness refuses to write through
symlinks. During development the symlink blocked the agent from updating `CLAUDE.md`
without a manual `rm` step, creating unnecessary friction.

## Decision

`CLAUDE.md` is a **real file** (not a symlink) that uses Claude Code's `@`-include
syntax to pull in `AGENTS.md`:

```
# Framework Chief — Claude Code overlay

@AGENTS.md

<!-- Claude Code-specific additions below. -->
```

`AGENTS.md` remains the vendor-neutral canonical source. `CLAUDE.md` is the Claude
Code-specific entry point. Other harnesses get their own entry points (`.cursorrules`,
`.github/copilot-instructions.md`, `.codex/prompts/chief.md`) if needed.

`chief-sync.sh` now writes this real overlay file instead of creating a symlink. If it
finds a stale symlink from an earlier install, it replaces it automatically.

`tests/unit/test_cli.py` and `tests/eval/eval-routing.py` now point at
`src/framework_chief/data/AGENTS.md` directly — the canonical source — rather than the
root `AGENTS.md` (which is the user-repo copy deployed by `chief init`, not the
development copy).

## Alternatives considered

**Symlink (previous approach):** Simple to implement, but conflates vendor-neutral content
with Claude Code-specific delivery. Blocked tool writes. Gives no room for Claude
Code-specific overlays without breaking the symlink model.

**Copy on sync:** `chief-sync.sh` copies `AGENTS.md` → `CLAUDE.md` on each run. Rejected
because divergence between the copy and the source is silent — the copies rot.

## Consequences

- Claude Code users get `CLAUDE.md` that always reflects the live `AGENTS.md` content
  (via `@`-include at read time, not at write time), with room for Claude Code-specific
  additions below the include line.
- `chief-sync.sh` is idempotent: running it N times on a project with an existing real
  overlay file is a no-op.
- Stale symlinks from v0.x installs are migrated automatically on the next `chief-sync`.
- Other LLM vendors remain unaffected — they read `AGENTS.md` directly or via their own
  pointer files.
