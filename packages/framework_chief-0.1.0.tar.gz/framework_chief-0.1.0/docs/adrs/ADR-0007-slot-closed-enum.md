# ADR-0007 — Slot is a closed enum

**Status:** Accepted  
**Date:** 2026-05-16

## Context

`Slot` (`plan_spec`, `execute`, `discipline`) is the core invariant of the composition
model. The compatibility matrix, the routing rubric in `AGENTS.md`, the REFUSE logic, and
every Bridge description are all defined in terms of these three exact slots.

`CONTEXT.md` previously described the slot set as "open and extensible as new frameworks
emerge," which contradicted the closed `str, Enum` in `stacks.py`.

## Decision

The slot set is **closed at three members**. `Slot` remains a `str, Enum` in `stacks.py`.

Adding a fourth slot is a design change, not a configuration change: it requires updating
the compatibility matrix, the routing rubric, at least one Bridge description, and the
AGENTS.md mental model. That scope of change warrants a new ADR, not a silent enum
extension.

## Consequences

- `CONTEXT.md` updated to state the three slots are a closed design invariant.
- Any future framework that does not fit `plan_spec`, `execute`, or `discipline` must
  first open an ADR to extend the slot set.
- Pydantic validation in `FrameworkMeta` rejects any adapter YAML with an unrecognised
  `slot` value at load time — a safe, early failure.
