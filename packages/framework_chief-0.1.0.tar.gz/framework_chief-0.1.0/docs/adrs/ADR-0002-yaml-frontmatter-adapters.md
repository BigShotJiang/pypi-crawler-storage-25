# ADR-0002: YAML Front-Matter in Adapter .md Files

**Status**: Accepted
**Date**: 2026-05-15

## Context

`.chief/adapters/*.md` were documentation-only markdown files. Any code that needed
per-framework facts (prerequisites, detection markers, install commands) had to duplicate
them in bash or hardcode them in Python. The bash script had a `case` statement with
prerequisite checks that had no connection to the documentation.

Two failure modes followed from this structure:
1. **Silent drift**: updating the human-readable docs didn't update the check logic.
2. **Untestable facts**: there was no programmatic way to assert "the docs say node 20.19+
   and the code checks node 20.19+."

The `Superpowers` adapter was the clearest example: its install instructions say
"per-harness plugin step" but bash tried to run it as a shell command anyway.

## Decision

Prepend a YAML front-matter block (delimited by `---`) to each adapter file. The block
is parsed by `load_adapters(adapters_dir)` using `yaml.safe_load` and validated into a
Pydantic v2 `FrameworkMeta` model. The human-readable body below the `---` delimiter is
unchanged.

```yaml
---
name: openspec
slot: plan_spec
detection_marker: openspec
prerequisites:
  node: "20.19"
  npm: null
  git: null
install_mode: run
install_commands:
  - "npm install -g @fission-ai/openspec@latest"
  - "openspec init --tools claude"
---
```

Key schema decisions:
- `prerequisites`: dict of `{tool: min_version | null}` — null means "present, any version".
- `prerequisite_any`: list of tools — at least one must be present (OR-group, for uv/pipx).
- `install_mode`: `run | interactive | recommend_only` — governs how install_commands execute.
- `detection_marker` / `detection_marker_alt`: directory names whose presence signals
  an existing install.

Combination logic (which frameworks compose into which stacks, verdicts, composition
blocks) stays in Python in `stacks.py`. YAML encodes per-framework facts only.

## Consequences

**Positive:**
- Adapter files serve as both documentation and machine-readable config. One edit
  updates both.
- Pydantic validation at `REGISTRY` import time catches structural errors immediately
  rather than at first use.
- `install_mode: recommend_only` for Superpowers and GSD-2 is now explicit in the
  source, not a special case buried in bash.

**Negative / watch points:**
- Markdown renderers will show the YAML block as a fenced section. This is acceptable —
  it reads naturally as configuration.
- `yaml.safe_load` is added as a runtime dependency (via `pyyaml>=6.0`). Already a
  common transitive dep; adding it explicitly is low risk.

**Alternative considered and rejected:**
Separate JSON/TOML sidecar files (e.g., `openspec.json` alongside `openspec.md`).
Rejected because it requires keeping two files in sync — exactly the drift problem
this ADR is solving.
