# Framework Chief — Class Diagram

```mermaid
classDiagram
    direction TB

    %% ── stacks.py ──────────────────────────────────────────────

    class Slot {
        <<enumeration>>
        plan_spec
        execute
        discipline
    }

    class InstallMode {
        <<enumeration>>
        run
        interactive
        recommend_only
    }

    class Compatibility {
        <<enumeration>>
        GREEN
        YELLOW
        RED
    }

    class FrameworkMeta {
        <<Pydantic BaseModel>>
        +name : str
        +slot : Slot
        +detection_marker : str
        +prerequisites : dict
        +prerequisite_any : list
        +install_mode : InstallMode
        +install_commands : list~str~
    }

    class Stack {
        <<dataclass>>
        +name : str
        +members : list~str~
        +compatibility : Compatibility
        +note : str
        +extensions : list~str~
        +composition_block : str
    }

    class Registry {
        <<dataclass · singleton REGISTRY>>
        +frameworks : dict~str, FrameworkMeta~
        +stacks : dict~str, Stack~
        +get_stack(name) Stack
        +is_red(name) bool
    }

    %% ── checks.py ──────────────────────────────────────────────

    class CheckLevel {
        <<enumeration>>
        OK
        MISS_SOFT
        MISS
        NOTE
        WARN
    }

    class CheckItem {
        <<dataclass>>
        +level : CheckLevel
        +message : str
        +to_str() str
    }

    class ToolCheck {
        <<dataclass>>
        +ok : bool
        +message : str
    }

    %% ── project.py ─────────────────────────────────────────────

    class ProjectLayout {
        <<frozen dataclass>>
        +root : Path
        +agents_md : Path
        +chief_dir : Path
        +decision_log : Path
        +scripts_dir : Path
        +claude_md : Path
    }

    %% ── decision_log.py ────────────────────────────────────────

    class LogEntryError {
        <<Exception>>
    }

    class DecisionLog {
        <<dataclass>>
        +path : Path
        +bootstrap() None
        +parse_and_append(raw) tuple
        +last_stack() str
        +read_entries() str
        -_append(kvpairs) str
    }

    %% ── phases.py ──────────────────────────────────────────────

    class PhaseResult {
        <<dataclass>>
        +phase : str
        +status : str
        +message : str
        +remediation : str
    }

    class Phase {
        <<dataclass>>
        +name : str
        +artifact : Callable
        +execute_fn : Callable
        +is_done(project) bool
        +status(project) PhaseResult
        +run(project, force) PhaseResult
    }

    %% ── compose.py ─────────────────────────────────────────────

    class CompositionError {
        <<Exception>>
    }

    class BlockAlreadyPresent {
        <<Exception>>
    }

    class PlaceholderError {
        <<Exception>>
    }

    %% ── cli.py (module façade) ─────────────────────────────────

    class CLI {
        <<module · cli.py>>
        +cmd_init(args) int
        +cmd_sync(args) int
        +cmd_dry_run(args) int
        +cmd_check(args) int
        +cmd_install(args) int
        +cmd_log(args) int
        +cmd_compose(args) int
        +main() None
    }

    %% ── renderer.py (module façade) ────────────────────────────

    class Renderer {
        <<module · renderer.py>>
        +show_banner() None
        +render_error(message) None
        +render_check(fw_name, items, ok) None
        +render_init_status(results, project) None
        +render_dry_run(stack_name, entries, note) None
        +render_log(pairs, date, log_path) None
        +render_compose_done(stack_name, agents_md) None
    }

    %% ── Exception hierarchy ────────────────────────────────────

    PlaceholderError     --|> CompositionError
    CompositionError     --|> Exception
    BlockAlreadyPresent  --|> Exception
    LogEntryError        --|> Exception

    %% ── stacks composition ─────────────────────────────────────

    FrameworkMeta --> Slot         : slot
    FrameworkMeta --> InstallMode  : install_mode
    Stack         --> Compatibility: compatibility
    Registry      *-- FrameworkMeta: frameworks 0..*
    Registry      *-- Stack        : stacks 0..*

    %% ── checks associations ────────────────────────────────────

    CheckItem --> CheckLevel : level
    CheckItem --> ToolCheck  : derived from

    %% ── phases associations ────────────────────────────────────

    Phase ..> PhaseResult    : produces
    Phase ..> ProjectLayout  : resolves artifact via
    Phase ..> DecisionLog    : bootstrap_log phase uses

    %% ── CLI orchestration ──────────────────────────────────────

    CLI ..> Registry       : REGISTRY singleton
    CLI ..> ProjectLayout  : creates per command
    CLI ..> DecisionLog    : cmd_log / install
    CLI ..> Phase          : runs _INIT_PHASES (cmd_init)
    CLI ..> Stack          : resolved via Registry
    CLI ..> FrameworkMeta  : passed to executable_commands()
    CLI ..> CheckItem      : from check_framework()
    CLI ..> Renderer       : all output
    CLI ..> CompositionError : catches
    CLI ..> LogEntryError  : catches
```

## Ownership layers

| Layer | Module(s) | Role |
|---|---|---|
| Entry point | `cli.py` | Parses args, orchestrates calls, sets exit code |
| Presentation | `renderer.py` | All Rich/console output — no domain logic |
| Domain | `stacks.py`, `checks.py`, `decision_log.py`, `compose.py` | Pure logic, no I/O except file writes |
| Value objects | `ProjectLayout`, `PhaseResult`, `CheckItem`, `ToolCheck` | Immutable data carriers |
| Init pipeline | `phases.py` | 5-step sequential pipeline driven by `_INIT_PHASES` |

## Notable structural choices

- `Registry` is a module-level singleton (`REGISTRY = _build_registry()`) built once at import time from bundled YAML adapters.
- `executable_commands()` and `dry_run_data()` are free functions that take `FrameworkMeta` / `Stack` directly, testable without constructing a full `Registry`.
- `DecisionLog._append()` is private — `parse_and_append()` is the only public write path, enforcing validation before any disk write.
- `PlaceholderError` inherits from `CompositionError`, forming a two-level exception hierarchy that lets callers catch either specifically or broadly.
