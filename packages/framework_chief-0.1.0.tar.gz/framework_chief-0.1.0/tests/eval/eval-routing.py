#!/usr/bin/env python3
"""
eval-routing.py — Automated routing eval for Framework Chief.

Sends each case from routing-cases.md to the Claude API with AGENTS.md
as the system prompt. The system prompt is extended (eval-only) with a
sentinel instruction; the chief appends:

    CHIEF_EVAL: state=<STATE> verdict=<VERDICT>

to every response. The harness parses that line and compares it against
EXPECTED STATE / EXPECTED VERDICT to produce a pass/fail per case.

Usage:
    python3 tests/eval-routing.py
    python3 tests/eval-routing.py --cases CASE-01,CASE-07,CASE-11
    python3 tests/eval-routing.py --model claude-sonnet-4-6
    python3 tests/eval-routing.py --dry-run   # parse cases, no API calls
    python3 tests/eval-routing.py --verbose   # show full response on failure

Requires:
    pip install anthropic
    export ANTHROPIC_API_KEY=sk-ant-...
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AGENTS_MD = ROOT / "src" / "framework_chief" / "data" / "AGENTS.md"
CASES_MD = Path(__file__).resolve().parent / "routing-cases.md"

DEFAULT_MODEL = "claude-haiku-4-5-20251001"

# Appended to AGENTS.md at eval time only — not part of the shipped router.
EVAL_SUFFIX = """

---
<!-- EVAL MODE: automated test harness active. -->
After your complete response, output exactly one machine-readable line.
Do not skip it or omit it. No text before or after it on that line.
Format:

CHIEF_EVAL: state=<STATE> verdict=<VERDICT>

STATE is exactly one of: AGREE CLARIFY REFUSE NO_FRAMEWORK
VERDICT is the recommended stack slug or a special token:

  Stack slugs:
    openspec  openspec-superpowers  bmad  bmad-superpowers
    spec-kit  spec-kit-canon  spec-kit-fleet  spec-kit-product-forge
    spec-kit-brownfield  spec-kit-brownkit  spec-kit-ralph
    spec-kit-superpowers-bridge  gsd2

  Special tokens:
    no-framework   (when no spec-driven framework is needed)
    refuse         (when state=REFUSE)

Examples:
  CHIEF_EVAL: state=AGREE verdict=openspec-superpowers
  CHIEF_EVAL: state=REFUSE verdict=refuse
  CHIEF_EVAL: state=CLARIFY verdict=openspec
  CHIEF_EVAL: state=NO_FRAMEWORK verdict=no-framework
"""

# Slug normalization — longer / more specific entries first.
_SLUG_TABLE = [
    (["spec-kit", "superpowers-bridge"], "spec-kit-superpowers-bridge"),
    (["spec-kit", "product-forge"],      "spec-kit-product-forge"),
    (["spec-kit", "brownkit"],           "spec-kit-brownkit"),
    (["spec-kit", "brownfield"],         "spec-kit-brownfield"),
    (["spec-kit", "canon"],              "spec-kit-canon"),
    (["spec-kit", "fleet"],              "spec-kit-fleet"),
    (["spec-kit", "ralph"],              "spec-kit-ralph"),
    (["bmad", "superpowers"],            "bmad-superpowers"),
    (["openspec", "superpowers"],        "openspec-superpowers"),
    (["spec-kit", "superpowers"],        "spec-kit-superpowers"),
    (["spec-kit"],                       "spec-kit"),
    (["openspec"],                       "openspec"),
    (["bmad"],                           "bmad"),
    (["gsd-2"],                          "gsd2"),
]


# ── Markdown parser ────────────────────────────────────────────────────────────

def parse_cases(text: str) -> list[dict]:
    cases = []
    for chunk in re.split(r'(?=### CASE-\d+:)', text):
        if not chunk.strip().startswith("### CASE-"):
            continue
        m = re.match(r'### (CASE-\d+): (.+)', chunk.strip())
        if not m:
            continue

        case_id = m.group(1)
        title = m.group(2).strip()
        multi_turn = bool(re.search(r'\(two-turn\)|\(multi-turn\)', chunk))

        req_m = re.search(
            r'\*\*REQUEST(?:[^*]*):\*\*\s*((?:>.*(?:\n|$))+)', chunk
        )
        if not req_m:
            continue
        req_lines = [
            ln.lstrip("> ").strip()
            for ln in req_m.group(1).splitlines()
            if ln.strip().lstrip("> ")
        ]

        state_m = re.search(r'\*\*EXPECTED STATE:\*\*\s*(.+)', chunk)
        verdict_m = re.search(
            r'\*\*EXPECTED VERDICT(?:[^*]*):\*\*\s*(.+)', chunk
        )

        state_text = state_m.group(1).strip() if state_m else ""
        verdict_text = verdict_m.group(1).strip() if verdict_m else ""

        exp_state = _parse_state(state_text)
        exp_verdict = _parse_verdict(verdict_text, exp_state)

        cases.append({
            "id": case_id,
            "title": title,
            "multi_turn": multi_turn,
            "req_lines": req_lines,
            "state_text": state_text,
            "verdict_text": verdict_text,
            "exp_state": exp_state,
            "exp_verdict": exp_verdict,
        })
    return cases


def _parse_state(text: str) -> str:
    if "REFUSE" in text:
        return "REFUSE"
    if "CLARIFY" in text:
        return "CLARIFY"
    if re.search(r'no framework', text, re.IGNORECASE) and "AGREE" not in text:
        return "NO_FRAMEWORK"
    return "AGREE"


def _parse_verdict(text: str, state: str) -> str | None:
    if state == "REFUSE":
        return "refuse"
    low = text.lower()
    if re.search(r'no framework|bare agent', low):
        return "no-framework"
    for keywords, slug in _SLUG_TABLE:
        if all(k in low for k in keywords):
            return slug
    return None  # cannot normalize — state check only


# ── API helpers ────────────────────────────────────────────────────────────────

def load_system_prompt() -> str:
    return AGENTS_MD.read_text() + EVAL_SUFFIX


def call_api(client, system: str, case: dict, model: str) -> str:
    lines = case["req_lines"]

    if case["multi_turn"]:
        turn1: list[str] = []
        turn2: list[str] = []
        cur: list[str] | None = None
        for line in lines:
            if re.match(r"Turn 1:", line):
                cur = turn1
                rest = re.sub(r"^Turn 1:\s*", "", line)
                if rest:
                    cur.append(rest)
            elif re.match(r"Turn 2", line):
                cur = turn2
                rest = re.sub(r"^Turn 2[^:]*:\s*", "", line)
                if rest:
                    cur.append(rest)
            elif cur is not None:
                cur.append(line)

        msgs = [{"role": "user", "content": " ".join(turn1)}]
        r1 = client.messages.create(
            model=model, max_tokens=2048, system=system, messages=msgs
        )
        r1_text = r1.content[0].text
        msgs += [
            {"role": "assistant", "content": r1_text},
            {"role": "user", "content": " ".join(turn2)},
        ]
        r2 = client.messages.create(
            model=model, max_tokens=2048, system=system, messages=msgs
        )
        return r2.content[0].text

    r = client.messages.create(
        model=model,
        max_tokens=2048,
        system=system,
        messages=[{"role": "user", "content": " ".join(lines)}],
    )
    return r.content[0].text


def extract_sentinel(
    response: str,
) -> tuple[str | None, str | None, str | None]:
    m = re.search(
        r'CHIEF_EVAL:\s*state\s*=\s*(\S+)\s+verdict\s*=\s*(\S+)',
        response,
        re.IGNORECASE,
    )
    if m:
        return m.group(1).upper(), m.group(2).lower().rstrip("."), None
    raw = re.search(r'CHIEF_EVAL:.*', response, re.IGNORECASE)
    if raw:
        return None, None, f"sentinel format mismatch: {raw.group(0)!r}"
    return None, None, None


# ── Evaluation logic ───────────────────────────────────────────────────────────

def evaluate(
    actual_state: str | None,
    actual_verdict: str | None,
    case: dict,
    *,
    strict: bool = False,
) -> tuple[bool, str]:
    exp_state = case["exp_state"]
    exp_verdict = case["exp_verdict"]

    if actual_state is None:
        return False, "no CHIEF_EVAL sentinel in response"

    if actual_state != exp_state:
        return False, f"state: got {actual_state}, want {exp_state}"

    if exp_verdict == "refuse":
        return True, "state=REFUSE"

    if exp_verdict is None:
        note = f"state={actual_state} (verdict not checked — could not normalize)"
        return True, note

    if actual_verdict == exp_verdict:
        return True, f"state={actual_state} verdict={actual_verdict}"

    # Fuzzy: every slug component of exp_verdict must appear in actual.
    if not strict:
        exp_parts = set(exp_verdict.split("-"))
        act_parts = set((actual_verdict or "").split("-"))
        if exp_parts and exp_parts <= act_parts:
            note = (
                f"state={actual_state} verdict={actual_verdict}"
                f" (fuzzy match on {exp_verdict})"
            )
            return True, note

    return False, f"verdict: got {actual_verdict}, want {exp_verdict}"


# ── CLI ────────────────────────────────────────────────────────────────────────

GREEN = "\033[32m"
RED = "\033[31m"
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
SEP = "─" * 62


def main() -> None:
    ap = argparse.ArgumentParser(description="Framework Chief routing eval")
    ap.add_argument(
        "--cases",
        help="Comma-separated case IDs, e.g. CASE-01,CASE-11",
    )
    ap.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Claude model (default: {DEFAULT_MODEL})",
    )
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse and display cases; no API calls",
    )
    ap.add_argument(
        "--verbose",
        action="store_true",
        help="Show full response for every case",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
        help="Fail on fuzzy verdict matches — exact slug required",
    )
    ap.add_argument(
        "--output",
        metavar="PATH",
        help="Write JSON summary to PATH",
    )
    args = ap.parse_args()

    all_cases = parse_cases(CASES_MD.read_text())
    if args.cases:
        ids = {c.strip().upper() for c in args.cases.split(",")}
        all_cases = [c for c in all_cases if c["id"] in ids]

    if not all_cases:
        print("No cases matched.", file=sys.stderr)
        sys.exit(1)

    print(SEP)
    print("  Framework Chief — Routing Eval")
    print(f"  model:  {args.model}")
    print(f"  cases:  {len(all_cases)}")
    if args.dry_run:
        print("  mode:   dry-run (no API calls)")
    print(SEP + "\n")

    if args.dry_run:
        for c in all_cases:
            turns = "multi" if c["multi_turn"] else "single"
            verdict = c["exp_verdict"] or "(not normalized)"
            req_preview = " ".join(c["req_lines"])
            if len(req_preview) > 80:
                req_preview = req_preview[:79] + "…"
            print(f"  {BOLD}{c['id']}{RESET}  {c['title']}")
            print(f"    state:    {c['exp_state']}")
            print(f"    verdict:  {verdict}")
            print(f"    turns:    {turns}")
            print(f"    {DIM}request:  {req_preview}{RESET}")
            print()
        sys.exit(0)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("ERROR: ANTHROPIC_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    try:
        import anthropic  # noqa: PLC0415
    except ImportError:
        print("ERROR: pip install anthropic", file=sys.stderr)
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)
    system = load_system_prompt()
    passed = failed = 0
    results: list[dict] = []

    for c in all_cases:
        print(f"  {BOLD}{c['id']}{RESET}  {c['title']}")
        response = ""
        try:
            response = call_api(client, system, c, args.model)
            actual_state, actual_verdict, fmt_err = extract_sentinel(response)
            if actual_state is None and fmt_err:
                ok, note = False, fmt_err
            else:
                ok, note = evaluate(
                    actual_state, actual_verdict, c, strict=args.strict
                )
        except Exception as exc:
            ok, note = False, f"API error: {exc}"

        results.append({"id": c["id"], "title": c["title"], "passed": ok, "note": note})

        if ok:
            print(f"    {GREEN}PASS{RESET}  {note}")
            passed += 1
        else:
            print(f"    {RED}FAIL{RESET}  {note}")
            failed += 1

        if args.verbose or not ok:
            preview = response[:500].replace("\n", "\n    ")
            print(f"    {DIM}...\n    {preview}")
            if len(response) > 500:
                print(f"    [+{len(response) - 500} chars]")
            print(RESET)

    total = passed + failed
    print(f"\n{SEP}")
    print(f"  {passed}/{total} passed")
    if failed:
        print(f"  {RED}{failed} case(s) FAILED{RESET}")
    else:
        print(f"  {GREEN}all routing cases OK{RESET}")
    print(SEP)

    if args.output:
        import datetime
        import json
        summary = {
            "model": args.model,
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            "total": total,
            "passed": passed,
            "failed": failed,
            "cases": results,
        }
        Path(args.output).write_text(json.dumps(summary, indent=2))

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
