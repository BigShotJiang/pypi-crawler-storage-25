# Framework Chief — Routing Eval Cases

Each case defines a user request, the expected chief behavior, and the key signal
that should drive the verdict. Use these to verify the chief routes correctly as
AGENTS.md evolves.

**How to run:** paste the REQUEST into any agent with AGENTS.md loaded. Compare
the actual chief response against EXPECTED STATE, EXPECTED VERDICT, and (for
CLARIFY cases) EXPECTED QUESTION.

A passing case means the chief hit the right state and proposed the right stack.
A failing case means the rubric or prose needs adjustment.

---

## Section 1 — Direct routes (CLASSIFY → AGREE, no CLARIFY)

These requests have enough signal to route without asking a follow-up question.
Confidence should be HIGH on the first classify pass.

---

### CASE-01: One-line bugfix
**REQUEST:**
> There's a null check missing in the auth middleware. One file, already know the fix.

**EXPECTED STATE:** CLASSIFY → AGREE (no CLARIFY, no REFUSE)
**EXPECTED VERDICT:** No framework — bare agent
**KEY SIGNAL:** Single file, known fix, zero planning surface. No spec-driven-development
framework adds value here; all of them add ceremony.
**VERIFY:** Chief does NOT propose any framework. Explains why and offers to proceed
directly with the fix.

---

### CASE-02: Greenfield feature, TDD enforced
**REQUEST:**
> Building a real-time notification system from scratch in our Node.js app. Tests
> must be written first — the team is strict about TDD. This is a new module,
> nothing exists yet.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** OpenSpec + Superpowers (GREEN)
**KEY SIGNAL:** "From scratch" (greenfield) + "TDD enforced" (discipline needed) +
medium-sized feature (planning structure needed). OpenSpec owns Plan/Spec slot;
Superpowers adds TDD enforcement without conflict.
**VERIFY:** Chief proposes the GREEN pair, shows the demotion block requirement,
and uses `dry-run openspec-superpowers` output at the AGREE gate.

---

### CASE-03: Complex enterprise feature, multiple roles
**REQUEST:**
> We need to design a multi-tenant billing system. This involves a product manager
> defining requirements, an architect doing the data model, and separate squads for
> the API and the frontend. We need structured handoffs between roles.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** BMAD (alone)
**KEY SIGNAL:** "Multiple roles", "structured handoffs" — this is exactly BMAD's
differentiator over OpenSpec. No explicit TDD requirement, so Superpowers isn't
added; BMAD's overhead is enough.
**VERIFY:** Chief picks BMAD, explains the role/process rationale, does NOT stack
Superpowers unless the user volunteers a TDD requirement.

---

### CASE-04: Long autonomous coding run
**REQUEST:**
> I want to hand this off to an agent and let it run for hours without interruption.
> It needs to implement a full data pipeline — schema, migrations, ETL jobs, tests.
> I don't want to babysit it.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** GSD-2 (recommend-only)
**KEY SIGNAL:** "Run for hours without interruption" + "don't want to babysit" —
GSD-2's persistent-session model is the only fit. Chief must flag that this is
recommend-only and the user runs the install themselves.
**VERIFY:** Chief uses the RECOMMEND ONLY language from `dry-run gsd2`. Does not
attempt to auto-run `npm install -g gsd-pi`.

---

### CASE-05: Greenfield API, no special requirements
**REQUEST:**
> Starting a new REST API service. Need to go from idea to spec to tasks. Nothing
> fancy — no multi-role setup, no specific testing requirement.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** OpenSpec (alone)
**KEY SIGNAL:** Greenfield + planning structure needed + no discipline requirement.
OpenSpec alone is sufficient; stacking Superpowers would be over-engineered.
**VERIFY:** Chief does NOT add Superpowers. Explains that single clean rail beats
a hybrid when nothing forces the addition.

---

### CASE-06: Pure refactor, known scope
**REQUEST:**
> Rename all `userId` fields to `user_id` across the codebase and update the
> tests. About 40 files. No design decisions needed.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** No framework — bare agent
**KEY SIGNAL:** Mechanical change, no design surface, known scope. Spec-driven-development
ceremony actively slows this down.
**VERIFY:** Chief declines to install any framework. Optionally notes that a
systematic find-replace with test run is the right approach.

---

## Section 2 — CLARIFY paths

These requests have LOW confidence on first classify. Chief must ask exactly ONE
discriminating question — the one that would most change the verdict.

---

### CASE-07: Existing specs, format unknown
**REQUEST:**
> I need to add a payment flow to our existing app. We have some specs already.

**EXPECTED STATE:** CLASSIFY → CLARIFY (low confidence)
**EXPECTED VERDICT (after answer A):** If specs are in `.specify/` → spec-kit already
installed, confirm existing setup. If specs are freeform markdown → OpenSpec (absorbs them).
**EXPECTED QUESTION:** Something that asks about the FORMAT of existing specs — are they
in a spec-kit `.specify/` directory, an OpenSpec `openspec/` directory, or freeform docs?
**KEY SIGNAL:** "Have some specs" is ambiguous — it's the single biggest fork in routing.
**VERIFY:** Chief asks about spec format, NOT about team size, TDD, or anything else.
One question.

---

### CASE-08: "New feature" with no size signal
**REQUEST:**
> Add user profile management to the app.

**EXPECTED STATE:** CLASSIFY → CLARIFY (low confidence)
**EXPECTED VERDICT (after answer):** Depends on scope — a form with 3 fields is a
bare-agent task; a full identity system with roles is OpenSpec territory.
**EXPECTED QUESTION:** Something about scope/complexity — is this a small addition
or a multi-phase feature with design decisions?
**KEY SIGNAL:** No size signal, no brownfield/greenfield signal, no discipline signal.
One clarifying question should resolve it.
**VERIFY:** Chief asks ONE question. Does not propose a framework before the answer.

---

### CASE-09: "Just pick" escape mid-CLARIFY
**REQUEST (two-turn):**
> Turn 1: I want to build something but I'm not sure what framework to use.
> Turn 2 (after chief asks): just pick something, I don't care.

**EXPECTED STATE:** CLARIFY → AGREE (escape)
**EXPECTED VERDICT:** OpenSpec + Superpowers (GREEN, the default bias pair)
**KEY SIGNAL:** "Just pick" is the documented escape. Chief must not ask a second
clarifying question. Must commit to the default recommendation.
**VERIFY:** Chief picks OpenSpec + Superpowers, explains the choice briefly, shows
the AGREE gate. Does not loop back to CLARIFY.

---

### CASE-10: Ambiguous "cleanup" request
**REQUEST:**
> We need to clean up the codebase before the next release.

**EXPECTED STATE:** CLASSIFY → CLARIFY (low confidence)
**EXPECTED VERDICT (after answer):** If it's dead code removal → bare agent.
If it's a full refactor sprint with multiple work streams → OpenSpec.
**EXPECTED QUESTION:** Something about scope — is this a targeted sweep of known
issues, or a structured multi-day refactor effort?
**KEY SIGNAL:** "Clean up" is the most ambiguous verb in software — ranges from
one-file fixes to architectural overhauls.
**VERIFY:** Chief asks about scope/effort, NOT about TDD or role structure.

---

## Section 3 — REFUSE paths (RED combinations)

Chief must REFUSE immediately — no CLARIFY, no AGREE gate. Explain why and offer
the closest GREEN or YELLOW alternative.

---

### CASE-11: Same-slot collision — BMAD + OpenSpec
**REQUEST:**
> Set up BMAD and OpenSpec together. I want both planning frameworks.

**EXPECTED STATE:** CLASSIFY → REFUSE (no CLARIFY, no AGREE)
**EXPECTED VERDICT:** Refuse. Offer BMAD alone, or OpenSpec alone, or OpenSpec+Superpowers.
**KEY SIGNAL:** Both occupy the Plan/Spec slot. Namespace collision — two sets of
slash commands, two artifact conventions, no bridge can fix this.
**VERIFY:** Chief refuses in the first response. Does NOT ask "are you sure?"
Does NOT show an AGREE gate. Explains the slot collision and offers alternatives.

---

### CASE-12: Same-slot collision — spec-kit + BMAD
**REQUEST:**
> I want to use spec-kit for planning and BMAD for the role structure.

**EXPECTED STATE:** CLASSIFY → REFUSE
**EXPECTED VERDICT:** Refuse. Explain that both own the Plan/Spec slot. Offer BMAD alone
(it already handles role structure) or OpenSpec + Superpowers.
**KEY SIGNAL:** Same slot. The user's stated reason ("role structure") is a BMAD feature,
so BMAD alone satisfies the intent.
**VERIFY:** Chief refuses. Explains that BMAD alone already provides role structure without
needing spec-kit.

---

### CASE-13: Execution harness conflict — GSD-2 + Superpowers
**REQUEST:**
> Use GSD-2 and Superpowers together.

**EXPECTED STATE:** CLASSIFY → REFUSE
**EXPECTED VERDICT:** Refuse. Both own the execution harness. Offer GSD-2 alone (for
autonomous runs) or OpenSpec+Superpowers (for structured feature work with TDD).
**KEY SIGNAL:** GSD-2 and Superpowers both control how tasks execute. No bridge exists.
**VERIFY:** Chief refuses. Explains the execution-harness conflict. Does not attempt to
construct a custom bridge on the fly.

---

### CASE-14: GSD-2 co-running with a Plan/Spec layer
**REQUEST:**
> I want to use OpenSpec for planning and GSD-2 to run the tasks it produces.

**EXPECTED STATE:** CLASSIFY → REFUSE (or YELLOW with strong warning)
**EXPECTED VERDICT:** Refuse co-running. GSD-2 reads only its `.gsd/` tree — it cannot
ingest OpenSpec artifacts natively. Offer the `spec-kit → GSD-2` migration handoff
pattern instead, or OpenSpec alone.
**KEY SIGNAL:** "GSD-2 reads only its own `.gsd/` tree." The user's intent (plan then
execute) is achievable but requires the ingestion handoff, not co-running.
**VERIFY:** Chief explains the `.gsd/` constraint and proposes the handoff pattern or
OpenSpec alone, NOT a co-running install.

---

### CASE-15: Three-way collision
**REQUEST:**
> Install spec-kit, OpenSpec, and BMAD. I want all three planning frameworks.

**EXPECTED STATE:** CLASSIFY → REFUSE
**EXPECTED VERDICT:** Refuse. All three occupy the same Plan/Spec slot. Offer to pick
exactly one.
**KEY SIGNAL:** Maximum slot collision. Three Plan/Spec frameworks = three times the
namespace conflicts, three times the artifact collisions.
**VERIFY:** Chief refuses without hesitation. Offers to classify which ONE fits best
if the user describes the project.

---

## Section 4 — YELLOW pairs (warn, proceed if accepted)

Chief should warn but not refuse. Must surface the tradeoff before the AGREE gate.

---

### CASE-16: spec-kit + Superpowers (discouraged)
**REQUEST:**
> Set up spec-kit and Superpowers together.

**EXPECTED STATE:** CLASSIFY → AGREE (with YELLOW warning before gate)
**EXPECTED VERDICT:** spec-kit + Superpowers (YELLOW) — proceed only if user accepts.
**KEY SIGNAL:** spec-kit already has a built-in discipline layer. Stacking Superpowers
doubles the discipline ceremony. Chief must warn, then show the AGREE gate.
**VERIFY:** Chief warns about the overlap BEFORE the gate. Gate text must include the
YELLOW note. Chief does NOT refuse.

---

### CASE-17: BMAD + Superpowers (advanced pair)
**REQUEST:**
> We want BMAD for our multi-role workflow and Superpowers for TDD enforcement.

**EXPECTED STATE:** CLASSIFY → AGREE (YELLOW — surgical hybrid)
**EXPECTED VERDICT:** BMAD + Superpowers with demotion block required.
**KEY SIGNAL:** Both are full rails. The request is valid but requires surgical
disabling on both sides. Chief must surface this cost before the gate.
**VERIFY:** Chief mentions the demotion block requirement in the AGREE gate output.
Uses `dry-run bmad-superpowers` output. Flags the seam to watch.

---

## Section 5 — Edge cases

---

### CASE-18: Already installed framework detected
**REQUEST:**
> Set up OpenSpec for this project.

*(The project already has an `openspec/` directory.)*

**EXPECTED STATE:** CLASSIFY → AGREE, then `check openspec` exits non-zero
**EXPECTED VERDICT:** `check` reports "already initialized — openspec/ exists".
Chief surfaces this to the user before any install runs.
**KEY SIGNAL:** `scripts/chief-install.sh check openspec` exits 1 when `openspec/`
exists.
**VERIFY:** Chief calls `check` first. Does not overwrite the existing install. Asks
whether to re-init or use the existing setup.

---

### CASE-19: No framework needed, user insists on one
**REQUEST:**
> Add a missing semicolon on line 42 of app.js. But use spec-kit to manage this.

**EXPECTED STATE:** CLASSIFY → AGREE (with YELLOW warning about over-engineering)
**EXPECTED VERDICT:** Warn that the fix doesn't justify the framework overhead. If user
still confirms → proceed with spec-kit install at the AGREE gate.
**KEY SIGNAL:** Request size is trivially small. Chief should surface the mismatch
before the gate, but must not refuse — the user is the authority on what they want.
**VERIFY:** Chief warns about ceremony mismatch. Does NOT refuse. Shows AGREE gate
after the warning. Respects user's final "yes".

---

### CASE-20: Explicit "no framework" preference
**REQUEST:**
> Just write the code — don't recommend any frameworks, don't install anything.
> I know what I'm doing.

**EXPECTED STATE:** CLASSIFY → no framework, hand off immediately
**EXPECTED VERDICT:** No framework. Chief steps back.
**KEY SIGNAL:** Explicit user preference overrides the rubric. Chief's job is to
recommend and install on request — not to force a recommendation.
**VERIFY:** Chief does NOT propose a framework. Does NOT ask clarifying questions.
Acknowledges the preference and hands off to the bare agent.

---

## Section 6 — Extension routing cases

These cases verify that spec-kit's routing-relevant extensions are surfaced at the
classify stage, not as post-install add-ons. Each case should produce a specific
extension recommendation as part of the initial verdict.

---

### CASE-21: Brownfield project with audit traceability requirement
**REQUEST:**
> We have a working Rails app that's about to go through a compliance audit.
> We need to retrofit specs onto the existing codebase and maintain an audit trail.
> No greenfield work — everything exists already.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** spec-kit + brownfield extension
**KEY SIGNAL:** "Existing codebase" + "compliance audit" + "audit trail" → brownfield
governance need. OpenSpec is the usual brownfield route, but spec-kit+brownfield is
correct when audit traceability is the discriminating requirement.
**VERIFY:** Chief routes to spec-kit, proposes `specify extension add brownfield`, and
explains the OpenSpec vs spec-kit+brownfield discriminator (audit traceability is the fork).

---

### CASE-22: Brownfield codebase with unknown security risk surface
**REQUEST:**
> We inherited a legacy PHP monolith — nobody knows what's in it. We want to
> wrap it with specs before touching anything, and we're worried about security
> issues lurking in the old code.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** spec-kit + brownkit extension
**KEY SIGNAL:** "Legacy", "nobody knows what's in it", "worried about security" →
BrownKit over plain brownfield. Brownkit adds security and QA risk assessment layer
specifically for legacy systems with unknown risk surface.
**VERIFY:** Chief proposes brownkit, explains it adds security/QA assessment on top of
brownfield's governance scaffolding. Does NOT route to OpenSpec.

---

### CASE-23: Existing code, no specs, wants retroactive coverage
**REQUEST:**
> We've been shipping code for two years with no specs. Now we want to create specs
> for what exists and detect when new code drifts from them. No new features, just
> spec coverage for the existing codebase.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** spec-kit + canon extension
**KEY SIGNAL:** "Code exists, no specs" + "detect drift" → Canon fills the spec-retrofit
gap. This is the only routing that handles code-first workflows and spec drift detection
natively. Neither vanilla spec-kit nor OpenSpec covers this explicitly.
**VERIFY:** Chief proposes canon. Mentions that this fills a gap not covered by
vanilla spec-kit or OpenSpec. Uses `dry-run spec-kit-canon` output at the AGREE gate.

---

### CASE-24: Full lifecycle phases, no persona discipline needed
**REQUEST:**
> We need to go through proper planning → architecture → stories → tasks, but we're
> a small team — no separate PM, architect, or QA persona. Just developers doing
> all the roles ourselves.

**EXPECTED STATE:** CLASSIFY → AGREE (possibly CLARIFY if BMAD ambiguity is present)
**EXPECTED VERDICT:** spec-kit + fleet extension
**KEY SIGNAL:** "Full lifecycle phases" but "no separate personas/roles" → fleet over BMAD.
BMAD's differentiator is multi-role persona discipline with structured handoffs. Fleet
provides the same lifecycle structure within spec-kit without the persona layer.
**VERIFY:** Chief does NOT route to BMAD. Proposes fleet, explains that BMAD's overhead
is unnecessary without role/persona discipline. Uses `dry-run spec-kit-fleet`.

---

### CASE-25: Monorepo with multiple products, V-Model release process
**REQUEST:**
> We're building a platform with a mobile app, a web app, and a backend API as
> separate products in a monorepo. We follow a V-Model release process with formal
> verification stages.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** spec-kit + product-forge extension
**KEY SIGNAL:** "Multiple products" + "monorepo" + "V-Model" → product-forge over plain
fleet. Product-forge adds portfolio management, monorepo support, and V-Model release
process on top of fleet's lifecycle structure.
**VERIFY:** Chief proposes product-forge (not just fleet). Explains that product-forge
extends fleet for monorepos and V-Model. Uses `dry-run spec-kit-product-forge`.

---

### CASE-26: spec-kit installed, wants some in-session automation
**REQUEST:**
> We're using spec-kit. Planning is done — we have our specs/ tree. I want the
> agent to work through the tasks automatically, but I don't want to set up a
> separate CLI tool or leave it running overnight.

**EXPECTED STATE:** CLASSIFY → AGREE
**EXPECTED VERDICT:** Ralph Loop extension (not GSD-2)
**KEY SIGNAL:** "spec-kit already installed" + "automatic task execution" + "no separate
CLI" + "not overnight" → Ralph Loop. GSD-2 requires a separate process and global install;
Ralph Loop runs inside the current AI session. The GSD-2 discriminator ("overnight or for
hours unattended, crash recovery, cost ceilings") does not apply here.
**VERIFY:** Chief proposes `specify extension add ralph`. Does NOT recommend GSD-2. Explains
the Ralph Loop vs GSD-2 tradeoff (in-session automation vs separate CLI with crash recovery).

---

### CASE-27: User insists on spec-kit + Superpowers
**REQUEST:**
> I've decided I want spec-kit and Superpowers together. I know there's overlap —
> I specifically want Superpowers' TDD and code-review slash commands alongside spec-kit.

**EXPECTED STATE:** CLASSIFY → AGREE (YELLOW with bridge path)
**EXPECTED VERDICT:** spec-kit + Superpowers Bridge extension (not a manual demotion block)
**KEY SIGNAL:** User explicitly insists on spec-kit + Superpowers after the chief warns.
The correct path is `specify extension add superpowers-bridge`, not a manual AGENTS.md
demotion block. A manual block conflicts with spec-kit's constitution hierarchy.
**VERIFY:** Chief proposes `specify extension add superpowers-bridge`. Does NOT write a
manual demotion block into AGENTS.md. Notes that two maintained bridge variants exist
in the catalog (`RbBtSn0w` and `WangX0111`). Uses `dry-run spec-kit-superpowers-bridge`.

---

### CASE-28: BMAD project, testing-heavy, wants test discipline enforced
**REQUEST:**
> We're running BMAD for a multi-role project and want formal TDD enforcement —
> tests must be written before any implementation code, reviewed by a testing specialist.

**EXPECTED STATE:** CLASSIFY → AGREE (YELLOW — BMAD + Superpowers or clarify TEA)
**EXPECTED VERDICT:** BMAD + Superpowers (YELLOW, with demotion block) OR BMAD + TEA module
**KEY SIGNAL:** Testing-heavy BMAD project. Chief should surface both paths: the BMAD+TEA
module (routing-relevant — no cross-framework friction) and BMAD+Superpowers (YELLOW hybrid,
surgical disabling required). TEA is the lower-friction path when BMAD is already the frame.
**VERIFY:** Chief mentions the TEA module as the first option. If user wants Superpowers
specifically, Chief explains the demotion block requirement (YELLOW). Does not treat this
as a RED combination.
