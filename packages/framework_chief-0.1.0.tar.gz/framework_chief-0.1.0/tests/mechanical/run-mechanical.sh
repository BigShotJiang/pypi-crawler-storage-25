#!/usr/bin/env bash
# run-mechanical.sh — assert the mechanical layer of the Framework Chief.
#
# This script tests everything that can be verified without an LLM:
#   - dry-run exits 0 for every supported stack
#   - check exits 0 for every framework (prereqs present)
#   - dry-run exits non-zero for unknown/RED stacks
#   - log appends a well-formed entry
#   - init is idempotent
#   - chief-sync.sh is idempotent (marker count stays at 2)
#
# Routing correctness (does the chief pick the right stack?) requires
# running routing-cases.md against a live agent. This script covers
# everything below that layer.
#
# Usage: bash tests/run-mechanical.sh [project-root]
#        defaults to the current directory.

set -euo pipefail

ROOT="${1:-$(pwd)}"
SCRIPT="$ROOT/scripts/chief-install.sh"
SYNC="$ROOT/scripts/chief-sync.sh"
PASS=0; FAIL=0

pass() { printf '  PASS  %s\n' "$*"; ((PASS++)) || true; }
fail() { printf '  FAIL  %s\n' "$*" >&2; ((FAIL++)) || true; }

assert_exit() {
  local label="$1" want="$2"; shift 2
  local got=0; "$@" >/dev/null 2>&1 || got=$?
  [[ "$got" -eq "$want" ]] && pass "$label (exit $got)" || fail "$label (want $want, got $got)"
}

assert_output() {
  local label="$1" pattern="$2"; shift 2
  local out; out=$("$@" 2>&1)
  echo "$out" | grep -qF "$pattern" && pass "$label" || fail "$label — pattern not found: '$pattern'"
}

if [[ ! -f "$SCRIPT" ]]; then
  echo "ERROR: chief-install.sh not found at: $SCRIPT" >&2
  echo "  pass the correct project root: bash tests/run-mechanical.sh /path/to/project" >&2
  exit 1
fi

echo "mechanical: $SCRIPT"
echo ""

# ── dry-run: all supported stacks must exit 0 ────────────────────────────────
echo "dry-run — supported stacks:"
for stack in spec-kit openspec bmad gsd2 superpowers \
             openspec-superpowers bmad-superpowers spec-kit-superpowers spec-kit-gsd2 \
             spec-kit-fleet spec-kit-product-forge spec-kit-canon \
             spec-kit-brownfield spec-kit-brownkit spec-kit-ralph spec-kit-superpowers-bridge; do
  assert_exit "dry-run $stack" 0 bash "$SCRIPT" dry-run "$stack"
done

echo ""

# ── dry-run: unknown / RED stacks must exit non-zero ─────────────────────────
echo "dry-run — unknown/RED stacks (must exit non-zero):"
for stack in gsd2-openspec bmad-openspec spec-kit-openspec gsd2-superpowers openspec-bmad; do
  local_exit=0
  bash "$SCRIPT" dry-run "$stack" >/dev/null 2>&1 || local_exit=$?
  [[ "$local_exit" -ne 0 ]] && pass "dry-run $stack exits non-zero ($local_exit)" \
                             || fail "dry-run $stack should exit non-zero, got 0"
done

echo ""

# ── check: valid frameworks exit 0 (clear) or 1 (prereq missing), never 2+ ──
echo "check — all frameworks (exit 0 = clear, 1 = prereq missing, 2+ = bug):"
for fw in spec-kit openspec bmad superpowers gsd2; do
  got=0; bash "$SCRIPT" check "$fw" >/dev/null 2>&1 || got=$?
  case "$got" in
    0) pass "check $fw — prereqs present (exit 0)" ;;
    1) pass "check $fw — prereq missing on this machine (exit 1)" ;;
    3) fail "check $fw — 'already installed' in test environment (exit 3)" ;;
    *) fail "check $fw — unexpected exit code $got (want 0 or 1)" ;;
  esac
done
# Unknown framework must always exit 2.
assert_exit "check unknown-fw exits 2" 2 bash "$SCRIPT" check bogus-framework

echo ""

# ── init: idempotent ─────────────────────────────────────────────────────────
echo "init — idempotency:"
assert_exit     "init first run (or already exists)" 0 bash "$SCRIPT" init
assert_exit     "init second run" 0 bash "$SCRIPT" init
assert_output   "init skips on re-run" "already exists" bash "$SCRIPT" init

echo ""

# ── log: appends a well-formed entry ─────────────────────────────────────────
echo "log:"
LOGFILE="$ROOT/.chief/decision.md"
lines_before=$(wc -l < "$LOGFILE")
assert_exit "log appends" 0 bash "$SCRIPT" log stack=test-case date=2026-05-14 request="mechanical test"
lines_after=$(wc -l < "$LOGFILE")
[[ "$lines_after" -gt "$lines_before" ]] \
  && pass "log grew decision.md ($lines_before → $lines_after lines)" \
  || fail "log did not grow decision.md"
assert_output "log entry has stack field" "**stack:** test-case" cat "$LOGFILE"

echo ""

# ── log: rejects malformed args ───────────────────────────────────────────────
echo "log — validation:"
bad_exit=0; bash "$SCRIPT" log notakeyvaluepair >/dev/null 2>&1 || bad_exit=$?
[[ "$bad_exit" -ne 0 ]] && pass "log rejects non-key=value arg" \
                         || fail "log should reject non-key=value arg, got exit 0"

bad_exit=0; bash "$SCRIPT" log >/dev/null 2>&1 || bad_exit=$?
[[ "$bad_exit" -ne 0 ]] && pass "log rejects no args" \
                         || fail "log should reject no args, got exit 0"

bad_exit=0; bash "$SCRIPT" log stack= >/dev/null 2>&1 || bad_exit=$?
[[ "$bad_exit" -ne 0 ]] && pass "log rejects empty value (stack=)" \
                         || fail "log should reject empty value (stack=), got exit 0"

bad_exit=0; bash "$SCRIPT" log '**bad**=value' >/dev/null 2>&1 || bad_exit=$?
[[ "$bad_exit" -ne 0 ]] && pass "log rejects invalid key characters (**bad**)" \
                         || fail "log should reject invalid key characters, got exit 0"

bad_exit=0; bash "$SCRIPT" log $'stack=foo\nbar' >/dev/null 2>&1 || bad_exit=$?
[[ "$bad_exit" -ne 0 ]] && pass "log rejects newline in value" \
                         || fail "log should reject newline in value, got exit 0"

echo ""

# ── chief-sync.sh: idempotency ───────────────────────────────────────────────
# Always run sync against a fresh temp project so tests pass regardless of
# whether CLAUDE.md is gitignored in the calling directory.
if [[ -f "$SYNC" ]]; then
  echo "chief-sync.sh — idempotency (temp project):"
  sync_tmp="$(mktemp -d)"
  # shellcheck disable=SC2064
  trap "rm -rf '$sync_tmp'" EXIT
  git init -q "$sync_tmp" 2>/dev/null
  cp "$ROOT/src/framework_chief/data/AGENTS.md" "$sync_tmp/AGENTS.md"

  assert_exit "sync run 1" 0 bash "$SYNC" "$sync_tmp"
  assert_exit "sync run 2" 0 bash "$SYNC" "$sync_tmp"
  assert_exit "sync run 3" 0 bash "$SYNC" "$sync_tmp"

  CLAUDE_FILE="$sync_tmp/CLAUDE.md"
  if [[ -f "$CLAUDE_FILE" ]] && ! [[ -L "$CLAUDE_FILE" ]] && \
     grep -qF "@AGENTS.md" "$CLAUDE_FILE" 2>/dev/null; then
    pass "sync: CLAUDE.md is a real overlay file containing @AGENTS.md"
  else
    fail "sync: CLAUDE.md overlay file missing or does not contain @AGENTS.md"
  fi

  COPILOT="$sync_tmp/.github/copilot-instructions.md"
  if [[ -f "$COPILOT" ]]; then
    count=$(grep -c "framework-chief-block" "$COPILOT" 2>/dev/null || echo 0)
    [[ "$count" -eq 2 ]] \
      && pass "sync: copilot marker count = 2 after 3 syncs" \
      || fail "sync: copilot marker count = $count (want 2)"
  else
    fail "sync: copilot-instructions.md not created"
  fi
  echo ""
fi

# ── summary ──────────────────────────────────────────────────────────────────
total=$((PASS + FAIL))
echo "────────────────────────────────"
printf "  %d/%d passed\n" "$PASS" "$total"
[[ "$FAIL" -eq 0 ]] && echo "  all mechanical checks OK" || echo "  $FAIL check(s) FAILED"
[[ "$FAIL" -eq 0 ]]
