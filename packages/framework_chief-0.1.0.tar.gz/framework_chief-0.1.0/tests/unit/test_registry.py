"""test_cli.py — REGISTRY-based unit tests for framework-chief.

Primary test surface: REGISTRY directly (pure Python, no subprocess).
Subprocess smoke tests: exactly 3 (version, help, dry-run unknown stack).

Run with:
    pytest tests/unit/test_cli.py
    uv run pytest tests/unit/test_cli.py
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import pytest

from framework_chief.stacks import Compatibility, REGISTRY

ROOT = Path(__file__).resolve().parent.parent.parent

_VENV_PY = ROOT / ".venv" / "bin" / "python"
_PY = str(_VENV_PY) if _VENV_PY.exists() else sys.executable
_CHIEF = [_PY, "-m", "framework_chief.cli"]


def run(*args: str, cwd: Path = ROOT) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [*_CHIEF, *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )


# ── REGISTRY: valid stacks ───────────────────────────────────────────────

VALID_STACKS = [
    "spec-kit",
    "openspec",
    "bmad",
    "gsd2",
    "superpowers",
    "openspec-superpowers",
    "bmad-superpowers",
    "spec-kit-superpowers",
    "spec-kit-gsd2",
    "spec-kit-fleet",
    "spec-kit-product-forge",
    "spec-kit-canon",
    "spec-kit-brownfield",
    "spec-kit-brownkit",
    "spec-kit-ralph",
    "spec-kit-superpowers-bridge",
]


@pytest.mark.parametrize("stack", VALID_STACKS)
def test_valid_stack_exists_in_registry(stack: str):
    assert REGISTRY.get_stack(stack) is not None, (
        f"{stack} not in REGISTRY"
    )


@pytest.mark.parametrize("stack", VALID_STACKS)
def test_valid_stack_is_not_red(stack: str):
    s = REGISTRY.get_stack(stack)
    assert s is not None
    assert s.compatibility != Compatibility.RED, (
        f"{stack} is RED — expected non-RED"
    )


# ── REGISTRY: RED stacks ─────────────────────────────────────────────────

# Derived from REGISTRY so a new RED entry in stacks.yaml automatically
# appears in parametrize without a manual list update.
RED_STACKS = [
    name for name, s in REGISTRY.stacks.items()
    if s.compatibility == Compatibility.RED
]

# Snapshot — catches drift in both directions (new RED added, known RED removed).
_EXPECTED_RED_STACKS = {
    "gsd2-openspec",
    "gsd2-bmad",
    "bmad-openspec",
    "spec-kit-openspec",
    "gsd2-superpowers",
}


def test_red_stacks_snapshot():
    actual = {
        name for name, s in REGISTRY.stacks.items()
        if s.compatibility == Compatibility.RED
    }
    assert actual == _EXPECTED_RED_STACKS, (
        f"RED stack set drifted.\n"
        f"  Added:   {actual - _EXPECTED_RED_STACKS}\n"
        f"  Removed: {_EXPECTED_RED_STACKS - actual}"
    )


@pytest.mark.parametrize("stack", RED_STACKS)
def test_red_stack_is_red_in_registry(stack: str):
    assert REGISTRY.is_red(stack), (
        f"{stack} should be RED in REGISTRY"
    )


# ── REGISTRY: frameworks loaded ──────────────────────────────────────────

EXPECTED_FRAMEWORKS = [
    "spec-kit", "openspec", "bmad", "gsd2", "superpowers"
]


def test_registry_frameworks_loaded():
    for fw_name in EXPECTED_FRAMEWORKS:
        assert fw_name in REGISTRY.frameworks, (
            f"Framework '{fw_name}' not loaded — "
            "check YAML front-matter in .chief/adapters/"
        )
    assert len(REGISTRY.frameworks) >= len(EXPECTED_FRAMEWORKS)


@pytest.mark.parametrize("fw", EXPECTED_FRAMEWORKS)
def test_framework_has_install_commands(fw: str):
    framework = REGISTRY.frameworks.get(fw)
    if framework is None:
        pytest.skip(
            f"{fw} not loaded — add YAML front-matter to adapter file"
        )
    assert framework.install_commands, (
        f"{fw} has empty install_commands"
    )


# ── CI bridge: REGISTRY ↔ AGENTS.md compatibility matrix ────────────────

_EXPECTED_MATRIX = {
    ("openspec", "superpowers"): Compatibility.GREEN,
    ("bmad", "superpowers"): Compatibility.YELLOW,
    ("spec-kit", "superpowers"): Compatibility.YELLOW,
    ("spec-kit", "gsd2"): Compatibility.YELLOW,
    ("gsd2", "openspec"): Compatibility.RED,
    ("gsd2", "bmad"): Compatibility.RED,
    ("bmad", "openspec"): Compatibility.RED,
    ("spec-kit", "openspec"): Compatibility.RED,
    ("gsd2", "superpowers"): Compatibility.RED,
}


def test_registry_matrix_matches_agents_md():
    agents_md = ROOT / "src" / "framework_chief" / "data" / "AGENTS.md"
    if not agents_md.exists():
        pytest.skip(
            "AGENTS.md not found — check src/framework_chief/data/AGENTS.md"
        )

    for (fw_a, fw_b), expected in _EXPECTED_MATRIX.items():
        stack_name = f"{fw_a}-{fw_b}"
        stack = REGISTRY.get_stack(stack_name)
        assert stack is not None, (
            f"Stack '{stack_name}' missing from REGISTRY"
        )
        assert stack.compatibility == expected, (
            f"Stack '{stack_name}': REGISTRY says"
            f" {stack.compatibility.value},"
            f" AGENTS.md matrix expects {expected.value}"
        )


# ── subprocess smoke tests (exactly 3) ──────────────────────────────────

def test_version_exits_0_and_contains_version_string():
    init = (
        ROOT / "src" / "framework_chief" / "__init__.py"
    ).read_text()
    m = re.search(r'__version__\s*=\s*"([^"]+)"', init)
    assert m, "__version__ not found in __init__.py"
    r = run("--version")
    assert r.returncode == 0
    assert m.group(1) in r.stdout


def test_help_exits_0_and_lists_all_subcommands():
    r = run("--help")
    assert r.returncode == 0
    for sub in (
        "init", "sync", "dry-run", "check", "install", "log", "compose"
    ):
        assert sub in r.stdout, f"'{sub}' missing from --help output"


def test_dry_run_unknown_stack_exits_nonzero():
    r = run("dry-run", "totally-bogus-stack")
    assert r.returncode != 0
