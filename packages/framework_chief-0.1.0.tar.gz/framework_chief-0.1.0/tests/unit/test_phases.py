"""Unit tests for phases.py — Phase checkpointing logic."""
from __future__ import annotations

from framework_chief.phases import Phase, PhaseResult
from framework_chief.project import ProjectLayout


def _sentinel_phase(artifact_name: str) -> Phase:
    """A Phase whose execute_fn writes a sentinel file."""

    def _execute(layout: ProjectLayout, _force: bool) -> PhaseResult:
        sentinel = layout.root / artifact_name
        sentinel.write_text("done", encoding="utf-8")
        return PhaseResult("sentinel", "done", f"{artifact_name} written")

    return Phase(
        name="sentinel",
        artifact=lambda layout: layout.root / artifact_name,
        execute_fn=_execute,
    )


def test_is_done_false_when_artifact_missing(tmp_path):
    assert _sentinel_phase("marker.txt").is_done(tmp_path) is False


def test_is_done_true_when_artifact_exists(tmp_path):
    (tmp_path / "marker.txt").write_text("x", encoding="utf-8")
    assert _sentinel_phase("marker.txt").is_done(tmp_path) is True


def test_status_done_when_artifact_exists(tmp_path):
    (tmp_path / "marker.txt").write_text("x", encoding="utf-8")
    result = _sentinel_phase("marker.txt").status(tmp_path)
    assert result.status == "done"


def test_status_failed_when_artifact_missing(tmp_path):
    result = _sentinel_phase("marker.txt").status(tmp_path)
    assert result.status == "failed"


def test_run_skips_when_already_done(tmp_path):
    (tmp_path / "marker.txt").write_text("x", encoding="utf-8")
    result = _sentinel_phase("marker.txt").run(tmp_path, force=False)
    assert result.status == "skipped"


def test_run_executes_when_not_done(tmp_path):
    result = _sentinel_phase("marker.txt").run(tmp_path, force=False)
    assert result.status == "done"
    assert (tmp_path / "marker.txt").exists()


def test_run_force_overwrites_existing(tmp_path):
    (tmp_path / "marker.txt").write_text("old", encoding="utf-8")
    result = _sentinel_phase("marker.txt").run(tmp_path, force=True)
    assert result.status == "done"
    assert (tmp_path / "marker.txt").read_text(encoding="utf-8") == "done"


def test_run_skips_symlink_as_done(tmp_path):
    target = tmp_path / "real.txt"
    target.write_text("x", encoding="utf-8")
    link = tmp_path / "marker.txt"
    link.symlink_to(target)
    result = _sentinel_phase("marker.txt").run(tmp_path, force=False)
    assert result.status == "skipped"
