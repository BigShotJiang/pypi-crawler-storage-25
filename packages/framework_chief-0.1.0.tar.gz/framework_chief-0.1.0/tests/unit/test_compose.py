"""Unit tests for compose.py."""
from __future__ import annotations

import datetime

import pytest

from framework_chief import compose
from framework_chief.compose import (
    BlockAlreadyPresent,
    CompositionError,
    _resolve_auto,
    _resolve_prompt,
    _resolve_required,
    apply_composition_block,
)
from framework_chief.stacks import REGISTRY


def _noop_input(prompt: str) -> str:
    return ""


# ── resolver unit tests ──────────────────────────────────────────────────────

def test_resolve_auto_returns_today_iso():
    result = _resolve_auto("DATE", {}, _noop_input)
    assert result == datetime.date.today().isoformat()


def test_resolve_required_from_values():
    result = _resolve_required(
        "REQUEST_SUMMARY", {"request_summary": "build a thing"}, _noop_input
    )
    assert result == "build a thing"


def test_resolve_required_from_input_fn():
    result = _resolve_required(
        "REQUEST_SUMMARY", {}, lambda _: "from prompt"
    )
    assert result == "from prompt"


def test_resolve_required_raises_when_missing():
    with pytest.raises(CompositionError, match="required"):
        _resolve_required("REQUEST_SUMMARY", {}, _noop_input)


def test_resolve_prompt_returns_none_on_empty():
    assert _resolve_prompt("superpowers_version", {}, _noop_input) is None


def test_resolve_prompt_returns_value_when_given():
    result = _resolve_prompt("superpowers_version", {}, lambda _: "2.1.0")
    assert result == "2.1.0"


# ── apply_composition_block integration ──────────────────────────────────────

def test_apply_raises_when_marker_already_present(tmp_path):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    marker = f"<!-- chief:composition-block:{stack.name} -->"
    agents_md.write_text(marker, encoding="utf-8")
    with pytest.raises(BlockAlreadyPresent):
        apply_composition_block(
            stack, agents_md,
            values={"request_summary": "test"},
            input_fn=_noop_input,
        )


def test_apply_appends_marker_and_content(tmp_path):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    apply_composition_block(
        stack, agents_md,
        values={"request_summary": "test request"},
        input_fn=_noop_input,
    )
    content = agents_md.read_text(encoding="utf-8")
    assert f"<!-- chief:composition-block:{stack.name} -->" in content
    assert "test request" in content


def test_apply_is_idempotent_via_already_present(tmp_path):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    apply_composition_block(
        stack, agents_md,
        values={"request_summary": "first"},
        input_fn=_noop_input,
    )
    with pytest.raises(BlockAlreadyPresent):
        apply_composition_block(
            stack, agents_md,
            values={"request_summary": "second"},
            input_fn=_noop_input,
        )


def test_apply_raises_for_missing_block_file(tmp_path, monkeypatch):
    stack = REGISTRY.get_stack("openspec-superpowers")
    agents_md = tmp_path / "AGENTS.md"
    agents_md.write_text("# Agents\n", encoding="utf-8")
    monkeypatch.setattr(compose, "_BLOCKS_DIR", tmp_path / "no-such-dir")
    with pytest.raises(CompositionError, match="not found"):
        apply_composition_block(
            stack, agents_md,
            values={"request_summary": "test"},
            input_fn=_noop_input,
        )
