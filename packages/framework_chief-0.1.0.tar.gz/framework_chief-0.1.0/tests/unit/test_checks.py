"""Unit tests for checks.py — pure domain logic, no subprocess."""
from __future__ import annotations

import pytest

from framework_chief.checks import CheckLevel, check_framework, parse_version
from framework_chief.stacks import Compatibility, FrameworkMeta, InstallMode, Slot, Stack


@pytest.mark.parametrize("raw,expected", [
    ("v20.19.0", (20, 19)),
    ("Python 3.11.2", (3, 11)),
    ("git version 2.39.0", (2, 39)),
    ("1.2.3", (1, 2)),
    ("0.12.4", (0, 12)),
    ("V1.0.0", (1, 0)),
])
def test_parse_version_valid(raw, expected):
    assert parse_version(raw) == expected


@pytest.mark.parametrize("raw", ["no numbers here", "", "abc"])
def test_parse_version_invalid(raw):
    assert parse_version(raw) is None


def _empty_fw(name: str = "test-fw") -> FrameworkMeta:
    return FrameworkMeta(name=name, slot=Slot.plan_spec, install_mode=InstallMode.run)


def test_check_framework_no_prereqs_returns_ok(tmp_path):
    fw = _empty_fw()
    ok, items = check_framework(fw, tmp_path, None, stacks={})
    assert ok is True
    assert items == []


def test_check_framework_detection_marker_found_adds_note(tmp_path):
    (tmp_path / "_bmad").mkdir()
    fw = FrameworkMeta(name="bmad", slot=Slot.plan_spec, detection_marker="_bmad")
    ok, items = check_framework(fw, tmp_path, None, stacks={})
    assert ok is True
    assert any(i.level == CheckLevel.NOTE for i in items)


def test_check_framework_stack_mismatch_adds_warn(tmp_path):
    (tmp_path / "_bmad").mkdir()
    fw = FrameworkMeta(name="bmad", slot=Slot.plan_spec, detection_marker="_bmad")
    stack = Stack(name="openspec", members=["openspec"], compatibility=Compatibility.GREEN)
    ok, items = check_framework(fw, tmp_path, "openspec", stacks={"openspec": stack})
    assert any(i.level == CheckLevel.WARN for i in items)


def test_check_framework_no_warn_when_fw_in_logged_stack(tmp_path):
    (tmp_path / "_bmad").mkdir()
    fw = FrameworkMeta(name="bmad", slot=Slot.plan_spec, detection_marker="_bmad")
    stack = Stack(name="bmad-stack", members=["bmad"], compatibility=Compatibility.GREEN)
    ok, items = check_framework(fw, tmp_path, "bmad-stack", stacks={"bmad-stack": stack})
    assert not any(i.level == CheckLevel.WARN for i in items)


def test_check_framework_alt_marker_also_detected(tmp_path):
    (tmp_path / ".bmad").mkdir()
    fw = FrameworkMeta(
        name="bmad",
        slot=Slot.plan_spec,
        detection_marker="_bmad",
        detection_marker_alt=".bmad",
    )
    ok, items = check_framework(fw, tmp_path, None, stacks={})
    assert any(i.level == CheckLevel.NOTE for i in items)
