#!/usr/bin/env bash
# docker-test.sh — build the integration container and run the full test suite.
#
# Usage:
#   bash tests/integration/docker-test.sh           # build + run (network on)
#   bash tests/integration/docker-test.sh --no-net  # no network (skips real installs)
#
# Requires: docker

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
IMAGE="framework-chief-integration"
NO_NET=0
[[ "${1:-}" == "--no-net" ]] && NO_NET=1

echo "═══════════════════════════════════════════════════════"
echo "  Framework Chief — Docker integration test"
echo "  image:   $IMAGE"
echo "  network: $([[ $NO_NET -eq 0 ]] && echo enabled || echo disabled)"
echo "═══════════════════════════════════════════════════════"
echo ""

echo "▶  building $IMAGE ..."
docker build \
  -f "$ROOT/tests/integration/Dockerfile.integration" \
  -t "$IMAGE" \
  "$ROOT" \
  --quiet
echo "   build done"
echo ""

DOCKER_ARGS=(--rm)
[[ $NO_NET -eq 1 ]] && DOCKER_ARGS+=(--network none)

echo "▶  running tests ..."
docker run "${DOCKER_ARGS[@]}" "$IMAGE"
