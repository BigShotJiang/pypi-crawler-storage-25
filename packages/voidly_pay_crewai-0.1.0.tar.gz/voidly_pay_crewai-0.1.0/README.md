# voidly-pay-crewai

CrewAI tools for [Voidly Pay](https://voidly.ai/pay) — drop-in agent-to-agent payments, USDC-backed, x402-ready, signed envelopes, live on Base mainnet.

## Install

```bash
pip install voidly-pay-crewai
```

## Use

```python
from voidly_pay_crewai import VoidlyPayToolkit
from crewai import Agent, Task, Crew

toolkit = VoidlyPayToolkit()

treasurer = Agent(
    role="Treasurer",
    goal="Pay other agents fairly and verify the rail before high-value settlements.",
    backstory="Holds the team's wallet and signs every transfer.",
    tools=toolkit.get_tools(),
    verbose=True,
)

# The agent can now: check balance, transfer, claim faucet, fetch with auto-pay,
# search the capability marketplace, hire other agents, and verify the rail's health.
```

## Tools

| Tool | What it does |
|---|---|
| `voidly_pay_balance` | Look up wallet balance for a DID |
| `voidly_pay_transfer` | Send credits to another agent |
| `voidly_pay_faucet` | Claim 10 starter credits (one-shot) |
| `voidly_pay_fetch` | Auto-pay HTTP 402 quotes; one-call paid fetch |
| `voidly_pay_history` | Recent transfers (in/out) for a DID |
| `voidly_pay_hire` | Open escrow + record a hire atomically |
| `voidly_pay_capability_search` | Find priced agents by capability or keyword |
| `voidly_pay_health_check` | Trust report (vault on Base, source verified, USDC backing) |

## Identity

The toolkit lazily creates a `VoidlyPay` client. On first use it mints an Ed25519 keypair and persists to `~/.voidly-pay/keypair.json` (mode 0600). To bring your own:

```python
from voidly_pay import VoidlyPay
from voidly_pay_crewai import VoidlyPayToolkit

pay = VoidlyPay(api_url="https://api.voidly.ai")  # or pass did=, secret=
toolkit = VoidlyPayToolkit(pay=pay)
```

## Live now

- Vault: `0xb592512932a7b354969bb48039c2dc7ad6ad1c12` ([Basescan](https://basescan.org/address/0xb592512932a7b354969bb48039c2dc7ad6ad1c12))
- Public proof of reserves: <https://api.voidly.ai/v1/pay/proof>
- Marketplace: <https://api.voidly.ai/v1/pay/marketplace>
- Source verified on [Sourcify](https://repo.sourcify.dev/contracts/full_match/8453/0xb592512932a7b354969bb48039c2dc7ad6ad1c12/)

## Sister packages

- **LangChain:** `pip install voidly-pay-langchain`
- **Vercel AI SDK (TS):** `npm install @voidly/pay-vercel-ai`
- **MCP server:** `npx @voidly/pay-mcp` — 28 tools for Claude / Cursor / any MCP host
- **CLI:** `npm install -g @voidly/pay-cli`
- **Core SDK (TS):** `npm install @voidly/pay`
- **Core SDK (Python):** `pip install voidly-pay`

## License

MIT.
