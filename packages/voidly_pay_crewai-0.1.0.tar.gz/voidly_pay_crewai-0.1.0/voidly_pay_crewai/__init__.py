"""Voidly Pay tools for CrewAI.

Two ways to use:

    # 1) Toolkit — every Voidly Pay action as a CrewAI BaseTool, ready to attach.
    from voidly_pay_crewai import VoidlyPayToolkit
    from crewai import Agent
    tools = VoidlyPayToolkit().get_tools()
    agent = Agent(role="Treasurer", goal="...", tools=tools)

    # 2) Single tool — pay-on-402 fetch.
    from voidly_pay_crewai import VoidlyPayFetchTool
    tool = VoidlyPayFetchTool()  # auto-pays HTTP 402 quotes when calling any URL.

Both wrap the official `voidly-pay` Python SDK. Identity (DID + secret key)
is loaded by the SDK from ``~/.voidly-pay/keypair.json``; first call mints
and persists. Override with ``VoidlyPay(api_url=..., did=..., secret=...)``
and pass via ``VoidlyPayToolkit(pay=...)``.
"""

from __future__ import annotations

import json
from typing import Any, List, Optional, Type

from pydantic import BaseModel, Field, ConfigDict
from crewai.tools import BaseTool  # type: ignore[import-not-found]
from voidly_pay import VoidlyPay  # type: ignore[import-not-found]

__all__ = [
    "VoidlyPayToolkit",
    "VoidlyPayBalanceTool",
    "VoidlyPayTransferTool",
    "VoidlyPayFaucetTool",
    "VoidlyPayFetchTool",
    "VoidlyPayHistoryTool",
    "VoidlyPayHireTool",
    "VoidlyPayCapabilitySearchTool",
    "VoidlyPayHealthCheckTool",
]

# ─── Schemas ──────────────────────────────────────────────────────────────


class _BalanceArgs(BaseModel):
    did: Optional[str] = Field(
        default=None,
        description="DID to look up. Defaults to the agent's own DID.",
    )


class _TransferArgs(BaseModel):
    to: str = Field(description="Recipient DID, e.g. 'did:voidly:abc...'.")
    amount: float = Field(description="Amount in credits (e.g. 0.5 = $0.50).")
    memo: Optional[str] = Field(default=None, description="Optional memo, ≤280 chars.")


class _NoArgs(BaseModel):
    model_config = ConfigDict(extra="forbid")


class _FetchArgs(BaseModel):
    url: str = Field(
        description=(
            "HTTP URL to fetch. If it returns 402 with a Voidly Pay quote, the "
            "tool pays + retries."
        )
    )
    method: str = Field(default="GET", description="HTTP method.")
    body: Optional[Any] = Field(
        default=None, description="JSON-serializable body for POST/PUT."
    )
    max_amount_credits: float = Field(
        default=0.05,
        description="Cap (in credits) on a single auto-pay. Default 0.05 = $0.05.",
    )


class _HistoryArgs(BaseModel):
    did: Optional[str] = Field(
        default=None, description="DID to look up. Defaults to self."
    )
    limit: int = Field(default=20, description="Page size.")


class _HireArgs(BaseModel):
    capability_id: str = Field(
        description="Voidly Pay capability_id of the provider's listing."
    )
    input: Optional[str] = Field(
        default=None,
        description="Input payload to send the provider, ≤2048 chars.",
    )


class _CapabilitySearchArgs(BaseModel):
    q: Optional[str] = Field(
        default=None,
        description="Free-text query against capability name + description.",
    )
    capability: Optional[str] = Field(
        default=None,
        description="Exact capability slug, e.g. 'hash.sha256'.",
    )
    max_price_credits: Optional[float] = Field(
        default=None,
        description="Filter to listings ≤ this price.",
    )
    limit: int = Field(default=20, description="Result limit.")


def _to_str(payload: Any) -> str:
    """CrewAI's BaseTool.run() returns to the LLM as a string. Normalize."""
    if isinstance(payload, str):
        return payload
    try:
        return json.dumps(payload, indent=None, default=str)
    except (TypeError, ValueError):
        return str(payload)


# ─── Individual tools ─────────────────────────────────────────────────────


class _PayTool(BaseTool):
    """Base tool that holds a shared VoidlyPay client.

    `pay` is excluded from Pydantic schema so CrewAI's tool serialization
    doesn't try to round-trip the live client into JSON.
    """

    pay: Optional[VoidlyPay] = Field(default=None, exclude=True)
    model_config = ConfigDict(arbitrary_types_allowed=True)

    def _client(self) -> VoidlyPay:
        if self.pay is None:
            self.pay = VoidlyPay()
        return self.pay


class VoidlyPayBalanceTool(_PayTool):
    name: str = "voidly_pay_balance"
    description: str = (
        "Look up a Voidly Pay wallet balance by DID. Returns balance, locked, "
        "caps, and frozen flag. If `did` is omitted, returns the agent's own "
        "balance."
    )
    args_schema: Type[BaseModel] = _BalanceArgs

    def _run(self, did: Optional[str] = None) -> str:
        return _to_str(self._client().balance(did=did))


class VoidlyPayTransferTool(_PayTool):
    name: str = "voidly_pay_transfer"
    description: str = (
        "Send Voidly Pay credits to another agent's DID. Atomic, signed, "
        "settles in <200ms. Use this to pay for hires, tips, or any one-shot "
        "transfer. Returns transfer_id + new balances."
    )
    args_schema: Type[BaseModel] = _TransferArgs

    def _run(self, to: str, amount: float, memo: Optional[str] = None) -> str:
        return _to_str(self._client().transfer(to=to, amount=amount, memo=memo))


class VoidlyPayFaucetTool(_PayTool):
    name: str = "voidly_pay_faucet"
    description: str = (
        "Claim 10 starter credits for the agent's DID. One-shot — only works "
        "once per DID. Use immediately after registering, before any spending."
    )
    args_schema: Type[BaseModel] = _NoArgs

    def _run(self) -> str:
        return _to_str(self._client().faucet())


class VoidlyPayFetchTool(_PayTool):
    name: str = "voidly_pay_fetch"
    description: str = (
        "Fetch any URL. If the server returns HTTP 402 with a Voidly Pay quote, "
        "the tool automatically transfers the asking amount and retries. Caps "
        "the auto-pay at `max_amount_credits` (default 0.05). Use this for any "
        "paid endpoint behind an x402 paywall — including Voidly's own paid "
        "endpoints under /v1/forecast-pro, /v1/claim-verify-pro, etc."
    )
    args_schema: Type[BaseModel] = _FetchArgs

    def _run(
        self,
        url: str,
        method: str = "GET",
        body: Any = None,
        max_amount_credits: float = 0.05,
    ) -> str:
        return _to_str(
            self._client().request_with_pay(
                url=url,
                method=method,
                body=body,
                max_amount_credits=max_amount_credits,
            )
        )


class VoidlyPayHistoryTool(_PayTool):
    name: str = "voidly_pay_history"
    description: str = (
        "List recent transfers for a DID (incoming + outgoing). Useful for "
        "trust-checking a counterparty before hiring. Returns a paginated list "
        "of {transfer_id, amount, counterparty, memo, settled_at}."
    )
    args_schema: Type[BaseModel] = _HistoryArgs

    def _run(self, did: Optional[str] = None, limit: int = 20) -> str:
        return _to_str(self._client().history(did=did, limit=limit))


class VoidlyPayHireTool(_PayTool):
    name: str = "voidly_pay_hire"
    description: str = (
        "Hire another agent atomically: opens escrow + records the hire in "
        "one signed batch. Use after `voidly_pay_capability_search` finds a "
        "provider. Returns {escrow_id, hire_id} — the escrow auto-releases "
        "when the provider co-signs a delivery receipt the requester accepts."
    )
    args_schema: Type[BaseModel] = _HireArgs

    def _run(self, capability_id: str, input: Optional[str] = None) -> str:
        client = self._client()
        hire_fn = getattr(client, "hire", None)
        if callable(hire_fn):
            return _to_str(hire_fn(capability_id=capability_id, input=input))
        # Manual escrow_open as a fallback (uses capability_id as memo)
        return _to_str(
            client.open_escrow(to="", amount=0, memo=f"hire:{capability_id}")
        )


class VoidlyPayCapabilitySearchTool(_PayTool):
    name: str = "voidly_pay_capability_search"
    description: str = (
        "Search the Voidly Pay capability marketplace for priced agents. "
        "Filter by free-text, exact capability slug, or max price. Returns the "
        "providers' DIDs, capability_ids, prices, and trust stats."
    )
    args_schema: Type[BaseModel] = _CapabilitySearchArgs

    def _run(
        self,
        q: Optional[str] = None,
        capability: Optional[str] = None,
        max_price_credits: Optional[float] = None,
        limit: int = 20,
    ) -> str:
        client = self._client()
        method = getattr(client, "capability_search", None)
        if callable(method):
            return _to_str(
                method(
                    q=q,
                    capability=capability,
                    max_price_credits=max_price_credits,
                    limit=limit,
                )
            )
        # Fallback: GET /v1/pay/capability/search
        params: dict = {"limit": limit}
        if q:
            params["q"] = q
        if capability:
            params["capability"] = capability
        if max_price_credits is not None:
            params["max_price_credits"] = max_price_credits
        return _to_str(
            client._req("GET", "/v1/pay/capability/search", params=params)  # type: ignore[arg-type]
        )


class VoidlyPayHealthCheckTool(_PayTool):
    name: str = "voidly_pay_health_check"
    description: str = (
        "One-call trust report for the Voidly Pay rail. Returns {ok, stage, "
        "vault_address, vault_chain_id, system_frozen, on-chain USDC balance}. "
        "Use before relying on the rail for high-value settlements."
    )
    args_schema: Type[BaseModel] = _NoArgs

    def _run(self) -> str:
        # Compose the report from the public worker endpoints.
        import requests

        client = self._client()
        api_url = client.api_url.rstrip("/")
        out: dict = {"checks": []}
        try:
            health = requests.get(f"{api_url}/v1/pay/health", timeout=10).json()
            out["system_frozen"] = bool(health.get("system_frozen"))
            out["checks"].append({"name": "api.reachable", "ok": True})
            out["checks"].append(
                {"name": "system.not_frozen", "ok": not out["system_frozen"]}
            )
        except Exception as e:
            out["checks"].append(
                {"name": "api.reachable", "ok": False, "hint": str(e)}
            )
        try:
            manifest = requests.get(
                f"{api_url}/v1/pay/manifest.json", timeout=10
            ).json()
            bridge = manifest.get("bridge") or {}
            out["stage"] = "stage-2" if bridge.get("vault_address") else "stage-1"
            out["vault_address"] = bridge.get("vault_address")
            out["vault_chain_id"] = bridge.get("chain_id")
            out["source_verification_url"] = bridge.get("source_verification")
            out["checks"].append(
                {
                    "name": "manifest.declares_stage2_vault",
                    "ok": bool(bridge.get("vault_address")),
                    "value": bridge.get("vault_address"),
                }
            )
            out["checks"].append(
                {
                    "name": "manifest.vault_on_base_mainnet",
                    "ok": bridge.get("chain_id") == 8453,
                    "value": bridge.get("chain_id"),
                    "expected": 8453,
                }
            )
            out["checks"].append(
                {
                    "name": "manifest.source_verified_link",
                    "ok": bool(bridge.get("source_verification")),
                    "value": bridge.get("source_verification"),
                }
            )
        except Exception as e:
            out["checks"].append(
                {
                    "name": "manifest.declares_stage2_vault",
                    "ok": False,
                    "hint": str(e),
                }
            )
        try:
            proof = requests.get(f"{api_url}/v1/pay/proof", timeout=10).json()
            usdc_balance = proof.get("onchain", {}).get("vault_balance_micro")
            if usdc_balance is not None:
                out["checks"].append(
                    {
                        "name": "onchain.vault_holds_usdc",
                        "ok": usdc_balance >= 0,
                        "value": usdc_balance,
                    }
                )
        except Exception:
            pass
        out["ok"] = (
            all(c.get("ok") for c in out["checks"]) if out["checks"] else False
        )
        return _to_str(out)


# ─── Toolkit ──────────────────────────────────────────────────────────────


class VoidlyPayToolkit(BaseModel):
    """Bundle of every Voidly Pay tool, ready to attach to a CrewAI Agent.

    Example::

        from voidly_pay_crewai import VoidlyPayToolkit
        from crewai import Agent, Task, Crew

        toolkit = VoidlyPayToolkit()
        treasurer = Agent(
            role="Treasurer",
            goal="Pay other agents fairly and verify the rail before high-value settlements.",
            backstory="Holds the team's wallet and signs every transfer.",
            tools=toolkit.get_tools(),
        )
    """

    pay: Optional[VoidlyPay] = Field(default=None, exclude=True)
    model_config = ConfigDict(arbitrary_types_allowed=True)

    def model_post_init(self, __context: Any) -> None:
        if self.pay is None:
            self.pay = VoidlyPay()

    def get_tools(self) -> List[BaseTool]:
        assert self.pay is not None
        return [
            VoidlyPayBalanceTool(pay=self.pay),
            VoidlyPayTransferTool(pay=self.pay),
            VoidlyPayFaucetTool(pay=self.pay),
            VoidlyPayFetchTool(pay=self.pay),
            VoidlyPayHistoryTool(pay=self.pay),
            VoidlyPayHireTool(pay=self.pay),
            VoidlyPayCapabilitySearchTool(pay=self.pay),
            VoidlyPayHealthCheckTool(pay=self.pay),
        ]
