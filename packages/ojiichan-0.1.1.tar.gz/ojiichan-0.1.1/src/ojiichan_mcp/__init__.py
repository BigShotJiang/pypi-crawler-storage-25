"""MCP server wrapper for ojiichan diagnostics."""
