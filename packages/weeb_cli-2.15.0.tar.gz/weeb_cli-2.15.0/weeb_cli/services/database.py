import sqlite3
import json
import os
import threading
from pathlib import Path
from datetime import datetime
from contextlib import contextmanager
from typing import Optional, List, Dict, Any

DB_PATH = Path.home() / ".weeb-cli" / "weeb.db"

class Database:
    def __init__(self) -> None:
        self.db_path: Path = DB_PATH
        self._initialized: bool = False
        self._connection: Optional[sqlite3.Connection] = None
        self._lock: threading.RLock = threading.RLock()

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        self._init_db()
        self._initialized = True
        self._migrate_from_json()
    
    def _get_connection(self) -> sqlite3.Connection:
        with self._lock:
            if self._connection is None:
                self.db_path.parent.mkdir(parents=True, exist_ok=True)
                self._connection = sqlite3.connect(
                    self.db_path,
                    timeout=30,  # Increased timeout for better reliability
                    check_same_thread=False,
                    isolation_level="DEFERRED"  # Removed autocommit for safe transactions
                )
                self._connection.row_factory = sqlite3.Row
                # WAL mode for better concurrent access
                self._connection.execute('PRAGMA journal_mode=WAL')
                # NORMAL is safe with WAL mode
                self._connection.execute('PRAGMA synchronous=NORMAL')
                # Larger cache for better performance
                self._connection.execute('PRAGMA cache_size=-64000')
                # Enable foreign keys
                self._connection.execute('PRAGMA foreign_keys=ON')
                # Busy timeout for concurrent access
                self._connection.execute('PRAGMA busy_timeout=30000')
            return self._connection
    
    @contextmanager
    def _raw_conn(self):
        self._ensure_initialized()
        conn = self._get_connection()
        with self._lock:
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise

    @contextmanager
    def _conn(self):
        with self._raw_conn() as conn:
            yield conn
    
    def close(self) -> None:
        with self._lock:
            if self._connection:
                self._connection.close()
                self._connection = None
    
    def _init_db(self):
        conn = self._get_connection()
        with self._lock:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );
                
                CREATE TABLE IF NOT EXISTS progress (
                    slug TEXT PRIMARY KEY,
                    title TEXT,
                    last_watched INTEGER DEFAULT 0,
                    total_episodes INTEGER DEFAULT 0,
                    completed TEXT DEFAULT '[]',
                    last_watched_at TEXT,
                    current_time REAL DEFAULT 0,
                    duration REAL DEFAULT 0
                );
                
                CREATE TABLE IF NOT EXISTS search_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    query TEXT UNIQUE,
                    searched_at TEXT
                );
                
                CREATE TABLE IF NOT EXISTS download_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    anime_title TEXT,
                    episode_number INTEGER,
                    episode_id TEXT,
                    slug TEXT,
                    season INTEGER DEFAULT 1,
                    status TEXT DEFAULT 'pending',
                    progress INTEGER DEFAULT 0,
                    eta TEXT DEFAULT '?',
                    error TEXT,
                    added_at REAL,
                    retry_count INTEGER DEFAULT 0,
                    speed TEXT
                );
                
                CREATE TABLE IF NOT EXISTS external_drives (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE,
                    name TEXT,
                    added_at TEXT
                );
                
                CREATE TABLE IF NOT EXISTS anime_index (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT,
                    source_path TEXT,
                    source_name TEXT,
                    folder_path TEXT,
                    episode_count INTEGER DEFAULT 0,
                    indexed_at TEXT
                );
                
                CREATE TABLE IF NOT EXISTS virtual_library (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    anime_id TEXT,
                    anime_title TEXT,
                    provider_name TEXT,
                    cover_url TEXT,
                    anime_type TEXT,
                    year INTEGER,
                    added_at TEXT
                );
                
                CREATE INDEX IF NOT EXISTS idx_queue_status ON download_queue(status);
                CREATE INDEX IF NOT EXISTS idx_progress_slug ON progress(slug);
                CREATE INDEX IF NOT EXISTS idx_anime_title ON anime_index(title);
                CREATE INDEX IF NOT EXISTS idx_anime_source ON anime_index(source_path);
                CREATE INDEX IF NOT EXISTS idx_virtual_library_title ON virtual_library(anime_title);
                CREATE INDEX IF NOT EXISTS idx_virtual_library_provider ON virtual_library(provider_name);
            ''')
            conn.commit()
            
        self._migrate_columns()
    
    def _migrate_columns(self):
        conn = self._get_connection()
        with self._lock:
            try:
                conn.execute('SELECT retry_count FROM download_queue LIMIT 1')
            except sqlite3.OperationalError:
                conn.execute('ALTER TABLE download_queue ADD COLUMN retry_count INTEGER DEFAULT 0')

            try:
                conn.execute('SELECT speed FROM download_queue LIMIT 1')
            except sqlite3.OperationalError:
                conn.execute('ALTER TABLE download_queue ADD COLUMN speed TEXT')

            try:
                conn.execute('SELECT current_time FROM progress LIMIT 1')
            except sqlite3.OperationalError:
                conn.execute('ALTER TABLE progress ADD COLUMN current_time REAL DEFAULT 0')
                conn.execute('ALTER TABLE progress ADD COLUMN duration REAL DEFAULT 0')
            
            conn.commit()
    
    def _migrate_from_json(self):
        config_dir = Path.home() / ".weeb-cli"
        
        config_file = config_dir / "config.json"
        if config_file.exists():
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for key, value in data.items():
                    self.set_config(key, value)
                config_file.rename(config_file.with_suffix('.json.bak'))
            except (json.JSONDecodeError, OSError) as e:
                from weeb_cli.services.logger import debug
                debug(f"[DB] Config migration failed: {e}")
        
        progress_file = config_dir / "progress.json"
        if progress_file.exists():
            try:
                with open(progress_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for slug, info in data.items():
                    self.save_progress(
                        slug,
                        info.get("title", slug),
                        info.get("last_watched", 0),
                        info.get("total_episodes", 0),
                        info.get("completed", []),
                        info.get("last_watched_at")
                    )
                progress_file.rename(progress_file.with_suffix('.json.bak'))
            except (json.JSONDecodeError, OSError) as e:
                from weeb_cli.services.logger import debug
                debug(f"[DB] Progress migration failed: {e}")
        
        history_file = config_dir / "search_history.json"
        if history_file.exists():
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for query in reversed(data):
                    self.add_search_history(query)
                history_file.rename(history_file.with_suffix('.json.bak'))
            except (json.JSONDecodeError, OSError) as e:
                from weeb_cli.services.logger import debug
                debug(f"[DB] Search history migration failed: {e}")
        
        queue_file = config_dir / "download_queue.json"
        if queue_file.exists():
            try:
                with open(queue_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                for item in data:
                    self.add_to_queue(item)
                queue_file.rename(queue_file.with_suffix('.json.bak'))
            except (json.JSONDecodeError, OSError) as e:
                from weeb_cli.services.logger import debug
                debug(f"[DB] Download queue migration failed: {e}")
    
    def get_config(self, key, default=None):
        with self._conn() as conn:
            row = conn.execute('SELECT value FROM config WHERE key = ?', (key,)).fetchone()
            if row:
                try:
                    return json.loads(row['value'])
                except (json.JSONDecodeError, TypeError, ValueError):
                    # If JSON decode fails, return raw value
                    return row['value']
            return default
    
    def set_config(self, key, value):
        with self._conn() as conn:
            conn.execute(
                'INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)',
                (key, json.dumps(value))
            )
    
    def get_all_config(self):
        with self._conn() as conn:
            rows = conn.execute('SELECT key, value FROM config').fetchall()
            result = {}
            for row in rows:
                try:
                    result[row['key']] = json.loads(row['value'])
                except Exception:
                    result[row['key']] = row['value']
            return result
    
    def save_progress(self, slug, title, last_watched, total_episodes, completed, last_watched_at=None, current_time=0, duration=0):
        with self._conn() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO progress 
                (slug, title, last_watched, total_episodes, completed, last_watched_at, current_time, duration)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (slug, title, last_watched, total_episodes, json.dumps(completed), last_watched_at, current_time, duration))
    
    def get_progress(self, slug):
        with self._conn() as conn:
            row = conn.execute('SELECT * FROM progress WHERE slug = ?', (slug,)).fetchone()
            if row:
                return {
                    "slug": row['slug'],
                    "title": row['title'],
                    "last_watched": row['last_watched'],
                    "total_episodes": row['total_episodes'],
                    "completed": json.loads(row['completed'] or '[]'),
                    "last_watched_at": row['last_watched_at'],
                    "current_time": row['current_time'] if 'current_time' in row.keys() else 0,
                    "duration": row['duration'] if 'duration' in row.keys() else 0
                }
            return {"last_watched": 0, "completed": [], "title": "", "total_episodes": 0, "last_watched_at": None, "current_time": 0, "duration": 0}
    
    def get_all_progress(self):
        with self._conn() as conn:
            rows = conn.execute('SELECT * FROM progress').fetchall()
            result = {}
            for row in rows:
                result[row['slug']] = {
                    "title": row['title'],
                    "last_watched": row['last_watched'],
                    "total_episodes": row['total_episodes'],
                    "completed": json.loads(row['completed'] or '[]'),
                    "last_watched_at": row['last_watched_at']
                }
            return result
    
    def add_search_history(self, query: str) -> None:
        with self._conn() as conn:
            conn.execute('DELETE FROM search_history WHERE query = ?', (query,))
            conn.execute(
                'INSERT INTO search_history (query, searched_at) VALUES (?, ?)',
                (query, datetime.now().isoformat())
            )
            conn.execute('''
                DELETE FROM search_history WHERE id NOT IN (
                    SELECT id FROM search_history ORDER BY searched_at DESC LIMIT 10
                )
            ''')
    
    def get_search_history(self) -> List[str]:
        with self._conn() as conn:
            rows = conn.execute(
                'SELECT query FROM search_history ORDER BY searched_at DESC LIMIT 10'
            ).fetchall()
            return [row['query'] for row in rows]
    
    def add_to_queue(self, item: Dict[str, Any]) -> bool:
        with self._conn() as conn:
            existing = conn.execute(
                'SELECT id FROM download_queue WHERE episode_id = ? AND status IN (?, ?)',
                (item.get('episode_id'), 'pending', 'processing')
            ).fetchone()
            if existing:
                return False
            
            conn.execute('''
                INSERT INTO download_queue 
                (anime_title, episode_number, episode_id, slug, status, progress, eta, added_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                item.get('anime_title'),
                item.get('episode_number'),
                item.get('episode_id'),
                item.get('slug'),
                item.get('status', 'pending'),
                item.get('progress', 0),
                item.get('eta', '?'),
                item.get('added_at', datetime.now().timestamp())
            ))
            return True
    
    def get_queue(self) -> List[Dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute('SELECT * FROM download_queue ORDER BY added_at').fetchall()
            return [dict(row) for row in rows]
    
    def update_queue_item(self, episode_id: str, **kwargs) -> None:
        with self._conn() as conn:
            sets = ', '.join(f'{k} = ?' for k in kwargs.keys())
            values = list(kwargs.values()) + [episode_id]
            conn.execute(f'UPDATE download_queue SET {sets} WHERE episode_id = ?', values)
    
    def clear_completed_queue(self) -> None:
        with self._conn() as conn:
            conn.execute('DELETE FROM download_queue WHERE status NOT IN (?, ?)', ('pending', 'processing'))
    
    def get_external_drives(self) -> List[Dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute('SELECT * FROM external_drives ORDER BY name').fetchall()
            return [dict(row) for row in rows]
    
    def add_external_drive(self, path: str, name: Optional[str] = None) -> None:
        with self._conn() as conn:
            conn.execute(
                'INSERT OR REPLACE INTO external_drives (path, name, added_at) VALUES (?, ?, ?)',
                (path, name or os.path.basename(path), datetime.now().isoformat())
            )
    
    def remove_external_drive(self, path: str) -> None:
        with self._conn() as conn:
            conn.execute('DELETE FROM external_drives WHERE path = ?', (path,))
    
    def update_drive_name(self, path: str, name: str) -> None:
        with self._conn() as conn:
            conn.execute('UPDATE external_drives SET name = ? WHERE path = ?', (name, path))
    
    def index_anime(self, title, source_path, source_name, folder_path, episode_count):
        with self._conn() as conn:
            conn.execute('DELETE FROM anime_index WHERE folder_path = ?', (folder_path,))
            conn.execute('''
                INSERT INTO anime_index (title, source_path, source_name, folder_path, episode_count, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (title, source_path, source_name, folder_path, episode_count, datetime.now().isoformat()))
    
    def clear_source_index(self, source_path: str) -> None:
        with self._conn() as conn:
            conn.execute('DELETE FROM anime_index WHERE source_path = ?', (source_path,))
    
    def get_all_indexed_anime(self) -> List[Dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute('SELECT * FROM anime_index ORDER BY title').fetchall()
            return [dict(row) for row in rows]
    
    def search_indexed_anime(self, query):
        with self._conn() as conn:
            rows = conn.execute(
                'SELECT * FROM anime_index WHERE title LIKE ? ORDER BY title',
                (f'%{query}%',)
            ).fetchall()
            return [dict(row) for row in rows]
    
    def remove_indexed_anime(self, folder_path: str) -> None:
        with self._conn() as conn:
            conn.execute('DELETE FROM anime_index WHERE folder_path = ?', (folder_path,))
    
    def backup_database(self, backup_path: str) -> bool:
        import shutil
        try:
            shutil.copy2(self.db_path, backup_path)
            return True
        except OSError as e:
            from weeb_cli.services.logger import error as log_error
            log_error(f"[DB] Backup failed: {e}")
            return False

    def restore_database(self, backup_path: str) -> bool:
        import shutil
        try:
            if not Path(backup_path).exists():
                return False
            
            backup_temp = self.db_path.with_suffix('.db.restore_backup')
            shutil.copy2(self.db_path, backup_temp)
            
            try:
                self.close()
                shutil.copy2(backup_path, self.db_path)
                backup_temp.unlink()
                self._initialized = False
                self._ensure_initialized()
                return True
            except OSError as e:
                from weeb_cli.services.logger import error as log_error
                log_error(f"[DB] Restore failed, rolling back: {e}")
                shutil.copy2(backup_temp, self.db_path)
                backup_temp.unlink()
                self._initialized = False
                self._ensure_initialized()
                return False
        except OSError as e:
            from weeb_cli.services.logger import error as log_error
            log_error(f"[DB] Restore preparation failed: {e}")
            return False
    
    def add_to_virtual_library(self, anime_id: str, anime_title: str, provider_name: str, 
                               cover_url: str = None, anime_type: str = None, year: int = None) -> bool:
        with self._conn() as conn:
            existing = conn.execute(
                'SELECT id FROM virtual_library WHERE anime_id = ? AND provider_name = ?',
                (anime_id, provider_name)
            ).fetchone()
            if existing:
                return False
            
            conn.execute('''
                INSERT INTO virtual_library 
                (anime_id, anime_title, provider_name, cover_url, anime_type, year, added_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (anime_id, anime_title, provider_name, cover_url, anime_type, year, datetime.now().isoformat()))
            return True
    
    def remove_from_virtual_library(self, anime_id: str, provider_name: str) -> None:
        with self._conn() as conn:
            conn.execute('DELETE FROM virtual_library WHERE anime_id = ? AND provider_name = ?', 
                        (anime_id, provider_name))
    
    def get_virtual_library(self) -> List[Dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute('SELECT * FROM virtual_library ORDER BY added_at DESC').fetchall()
            return [dict(row) for row in rows]
    
    def search_virtual_library(self, query: str) -> List[Dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute(
                'SELECT * FROM virtual_library WHERE anime_title LIKE ? ORDER BY anime_title',
                (f'%{query}%',)
            ).fetchall()
            return [dict(row) for row in rows]
    
    def is_in_virtual_library(self, anime_id: str, provider_name: str) -> bool:
        with self._conn() as conn:
            row = conn.execute(
                'SELECT id FROM virtual_library WHERE anime_id = ? AND provider_name = ?',
                (anime_id, provider_name)
            ).fetchone()
            return row is not None
    
    def __del__(self) -> None:
        self.close()

db: Database = Database()
