# Copyright (c) 2021-2026, Lawrence Livermore National Security, LLC. and
# Stanford University.
# All rights reserved.
# LLNL-CODE-826307

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.

# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.

# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import numpy as np


def systematic_loss(alpha):
    """Return a loss function that adds a fractional systematic noise floor.

    The effective variance is ``var + model + (alpha * model)**2``, where
    ``alpha`` is the fractional systematic uncertainty (e.g. 0.02 = 2%).
    This caps the effective SNR per pixel, preventing unmodeled correlated
    residuals (e.g. from atmospheric fluctuations or mirror figure errors)
    from dominating the fit.

    Parameters
    ----------
    alpha : float
        Fractional systematic uncertainty.  Typical values are 0.01–0.05.

    Returns
    -------
    callable
        Loss function with signature ``(data, model, var) -> array``.
    """
    def _loss(data, model, var):
        return (data - model) / np.sqrt(var + model + (alpha * model)**2)
    return _loss


chi2_loss = systematic_loss(0)
"""Standard chi residual, equivalent to ``systematic_loss(0)``.

Assumes Gaussian read noise plus Poisson shot noise:
``(data - model) / sqrt(var + model)``.  This is the default loss function.
"""
