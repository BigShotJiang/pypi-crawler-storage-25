"""
mnemo-mcp — Standalone MCP server for the Mnemo platform.

Exposes Mnemo's memory and intelligence layer as an MCP server so any
Claude context (Claude Desktop, Claude Code, custom agents) can call into
Mnemo memory directly.

Usage:
    pip install mnemomcp
    # then add to claude_desktop_config.json — see README or Mnemo Settings

The server is a thin HTTP client over the Mnemo REST API. It has no dependency
on the Mnemo backend codebase; all it needs is MNEMO_API_URL and MNEMO_API_TOKEN.
"""

__version__ = "0.1.0"
__all__ = ["__version__"]
