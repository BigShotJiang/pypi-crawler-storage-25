from __future__ import annotations

import json
import logging
import os
import shlex
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _is_loopback_host(hostname: Optional[str]) -> bool:
    return hostname in {"localhost", "127.0.0.1", "::1"}


def resolve_api_token(initial_token: str = "") -> str:
    """Resolve API token from env, token file, or command-based provider."""
    token = (initial_token or "").strip()
    if token:
        return token

    token_file = Path.home() / ".mnemo" / "mcp_token"
    if token_file.exists():
        file_token = token_file.read_text(encoding="utf-8").strip()
        if file_token:
            return file_token

    token_cmd = (os.getenv("MNEMO_API_TOKEN_CMD", "") or "").strip()
    if token_cmd:
        try:
            completed = subprocess.run(
                shlex.split(token_cmd),
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            if completed.returncode == 0:
                cmd_token = (completed.stdout or "").strip()
                if cmd_token:
                    return cmd_token
        except Exception as exc:
            logger.warning("token command failed: %s", exc)

    # Optional compatibility env if external auth broker injects bearer.
    oauth_token = (os.getenv("MNEMO_OAUTH_ACCESS_TOKEN", "") or "").strip()
    if oauth_token:
        return oauth_token
    return ""


def enforce_transport_policy(api_url: str) -> None:
    """Block insecure non-loopback HTTP unless explicitly allowed."""
    parsed = urllib.parse.urlparse(api_url)
    allow_insecure = (os.getenv("MNEMO_ALLOW_INSECURE_HTTP", "") or "").strip() == "1"
    if parsed.scheme == "http" and not _is_loopback_host(parsed.hostname):
        if allow_insecure:
            logger.warning(
                "MNEMO_ALLOW_INSECURE_HTTP=1 set. Proceeding with insecure HTTP to %s.",
                api_url,
            )
            return
        raise RuntimeError(
            "Insecure MCP transport blocked: MNEMO_API_URL uses HTTP on a non-loopback host. "
            "Use HTTPS or set MNEMO_ALLOW_INSECURE_HTTP=1 only for controlled testing."
        )


def api_call(
    api_url: str,
    api_token: str,
    method: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
    timeout_sec: float = 10.0,
) -> Dict[str, Any]:
    """Make an authenticated API call to Mnemo backend."""
    url = f"{api_url.rstrip('/')}{path}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_token}",
    }
    data = json.dumps(body or {}).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode()
        logger.error("API %s %s -> %d: %s", method, path, exc.code, body_text[:200])
        return {"error": f"HTTP {exc.code}", "detail": body_text[:200]}
    except Exception as exc:
        logger.error("API call failed: %s", exc)
        return {"error": str(exc)}


def clip_tool_output(text: str) -> str:
    """Apply max output size guard for MCP tool results."""
    max_chars = int(os.getenv("MAX_MCP_OUTPUT_CHARS", "20000"))
    if max_chars < 1000:
        max_chars = 1000
    if len(text) <= max_chars:
        return text
    clipped = text[:max_chars]
    return (
        f"{clipped}\n\n"
        f"[output truncated to {max_chars} chars; set MAX_MCP_OUTPUT_CHARS to increase]"
    )

