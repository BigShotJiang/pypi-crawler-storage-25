"""
mnemo_mcp/server.py — Mnemo Platform MCP Server
================================================
Exposes the Mnemo platform's memory and intelligence layer as an MCP server.

This means ANY Claude conversation — Claude.ai, Claude Code, Claude in Chrome,
a custom agent, another app — can call into Mnemo's memory directly without
being in the Mnemo/Meridian frontend.

Tools exposed
-------------
  search_memory       — semantic search over user's session history
  get_open_threads    — active unresolved threads
  get_decisions       — open decisions with confidence + rationale
  get_entities        — entity graph lookup
  get_morning_brief   — structured brief of what matters right now
  log_session         — index a session from an external agent into Mnemo memory
  log_decision        — record a decision from any context
  list_projects       — list all project slugs with activity summaries
  get_project_context — one-shot retrieval of a project's full state

Setup
-----
  pip install mnemomcp

  Add to ~/claude_desktop_config.json:
  {
    "mcpServers": {
      "mnemo": {
        "command": "mnemo-mcp",
        "env": {
          "MNEMO_API_URL": "https://api.mnemomcp.com",
          "MNEMO_API_TOKEN": "<token from Mnemo Settings>",
          "MNEMO_PROFILE": "your-profile-name"
        }
      }
    }
  }

Authentication
--------------
Generate a token in Mnemo → Settings → "Connect to Claude Desktop & Claude Code".
The token is long-lived (30–365 days) and scoped to the Mnemo platform, not to
any specific app (Meridian, VitalSync Coach, etc.).

Architecture
------------
Pure thin HTTP client over the Mnemo REST API. No dependency on the Mnemo
backend codebase — just stdlib + the mcp package.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import urllib.parse
from typing import Any, Dict, List, Optional
from mnemo_mcp.core import api_call, clip_tool_output, enforce_transport_policy, resolve_api_token

logger = logging.getLogger(__name__)

# ── MCP SDK ───────────────────────────────────────────────────────────────────
try:
    import mcp.server.stdio
    from mcp.server import Server
    from mcp.types import Tool, TextContent
    _MCP_AVAILABLE = True
except ImportError:
    _MCP_AVAILABLE = False
    logger.warning(
        "[mnemo-mcp] 'mcp' package not installed. "
        "Run: pip install mnemomcp\n"
        "MCP server will not start without it."
    )

# ── Configuration (from env) ──────────────────────────────────────────────────
_API_URL = os.getenv("MNEMO_API_URL", "http://localhost:7432")
_API_TOKEN = resolve_api_token(os.getenv("MNEMO_API_TOKEN", ""))
_PROFILE = os.getenv("MNEMO_PROFILE", "")
_CLIENT_HINT = os.getenv("MNEMO_CLIENT_HINT", "unknown").strip().lower() or "unknown"


# ── HTTP client wrapper ────────────────────────────────────────────────────────

def _api_call(method: str, path: str, body: Optional[Dict] = None) -> Dict[str, Any]:
    return api_call(_API_URL, _API_TOKEN, method, path, body=body, timeout_sec=10.0)


# ── Tool definitions ──────────────────────────────────────────────────────────

MNEMO_TOOLS: List[Dict[str, Any]] = [
    {
        "name": "search_memory",
        "description": (
            "Semantically search the user's Mnemo session history. "
            "Returns the most relevant past sessions for the given query. "
            "Use this to surface relevant context from the user's working history "
            "before generating a response. Include the returned context in your prompt.\n\n"
            "INTENT SPLIT — choose the right mode based on the user's phrasing:\n"
            "• 'ask mnemo about X' / 'what does mnemo know about X' → summary mode "
            "(default: verbatim=false, n_results=5, max_tokens=1500). Fast, condensed.\n"
            "• 'ask mnemo DETAILS about X' / 'show full notes on X' / 'verbatim' → "
            "detail mode (verbatim=true, n_results=2, max_tokens=4000). "
            "Returns the complete stored output for each matched session, not just snippets."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The topic or question to search for"},
                "verbatim": {
                    "type": "boolean",
                    "description": (
                        "When true, returns the full stored key_output for each matched session "
                        "instead of the short 120-char snippet. Use when the user asks for "
                        "'details', 'full notes', or 'verbatim' content. "
                        "Automatically sets max_tokens=4000 and n_results=2 unless overridden."
                    ),
                    "default": False,
                },
                "max_tokens": {
                    "type": "integer",
                    "description": "Maximum tokens to return (default: 1500 in summary mode, 4000 in verbatim mode)",
                    "default": 1500,
                },
                "n_results": {
                    "type": "integer",
                    "description": "Number of sessions to retrieve (default: 5 in summary mode, 2 in verbatim mode)",
                    "default": 5,
                },
                "include": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Memory types to include: sessions, decisions, threads, entities",
                    "default": ["sessions", "decisions", "threads"],
                },
                "project": {
                    "type": "string",
                    "description": "Optional project slug (e.g. 'atlas'). When provided, search is scoped to that project only. Omit to search all memory.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_open_threads",
        "description": (
            "Get the user's active unresolved threads — the questions and concerns "
            "that have come up across sessions but haven't been closed. "
            "Sorted by recurrence count (most recurring first)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max threads to return (default: 10)", "default": 10},
                "status": {
                    "type": "string",
                    "enum": ["open", "deferred", "resolved", "dormant", "all"],
                    "description": "Filter by thread status (aliases: monitoring→deferred, abandoned→dormant)",
                    "default": "open",
                },
                "project": {
                    "type": "string",
                    "description": "Optional project slug. When provided, only threads from that project are returned.",
                },
            },
        },
    },
    {
        "name": "get_decisions",
        "description": (
            "Get the user's tracked strategic decisions — with confidence levels, "
            "rationale, and outcome status. Use to check what's already been decided "
            "before recommending a course of action."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["open", "resolved", "all"], "default": "open"},
                "domain": {"type": "string", "description": "Filter by domain: strategy, product, operations, etc."},
                "limit": {"type": "integer", "default": 10},
                "project": {
                    "type": "string",
                    "description": "Optional project slug. When provided, only decisions tagged to that project are returned.",
                },
            },
        },
    },
    {
        "name": "get_entities",
        "description": (
            "Look up entities the user has mentioned across sessions — people, "
            "companies, projects, topics (Meridian) or injuries, races, goals "
            "(VitalSync Coach). Returns the entity's history, mention count, and context."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Entity name to look up (partial match supported)"},
                "entity_type": {"type": "string", "description": "Filter by entity type"},
                "limit": {"type": "integer", "default": 5},
                "project": {
                    "type": "string",
                    "description": "Optional project slug. Scopes entity lookup to mentions within that project.",
                },
            },
        },
    },
    {
        "name": "get_morning_brief",
        "description": (
            "Get the user's current morning brief — a structured summary of what "
            "matters right now based on recent sessions, open decisions, and threads."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "format": {"type": "string", "enum": ["structured", "narrative"], "default": "structured"},
                "project": {
                    "type": "string",
                    "description": "Optional project slug. When provided, the brief is focused on that project only.",
                },
            },
        },
    },
    {
        "name": "log_session",
        "description": (
            "Index a session from an external context into Mnemo memory. "
            "Use when an agent has completed meaningful work that should be remembered. "
            "The session will be summarized, embedded, and retrievable in future sessions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "The task or question that was addressed"},
                "output": {"type": "string", "description": "The key output or conclusion from the session"},
                "source": {"type": "string", "description": "Source identifier (e.g. 'claude_code', 'claude_agent')", "default": "external_mcp"},
                "app_id": {"type": "string", "description": "App this session belongs to (default: meridian)", "default": "meridian"},
                "project": {
                    "type": "string",
                    "description": "Optional project slug (e.g. 'atlas'). Tags this session to a project namespace for scoped retrieval.",
                },
            },
            "required": ["task", "output"],
        },
    },
    {
        "name": "log_decision",
        "description": (
            "Record a decision in Mnemo's decision intelligence layer so it can be "
            "tracked, referenced in future sessions, and evaluated against its outcome."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The decision statement"},
                "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
                "domain": {"type": "string", "default": "strategy"},
                "rationale": {"type": "string", "description": "Why this decision was made"},
                "project": {
                    "type": "string",
                    "description": "Optional project slug. Tags this decision to a project for scoped retrieval.",
                },
            },
            "required": ["content"],
        },
    },
    {
        "name": "wrap_session",
        "description": (
            "End-of-session persistence: atomically logs the session, all decisions made, "
            "and surfaces open threads — in one call. "
            "This replicates the Meridian ExtractionCard behavior for MCP contexts "
            "(Claude Code, Cowork, agents). "
            "Call this when the user says 'persist', 'wrap up', 'we're done', or at "
            "natural session end. "
            "Before calling, scan the conversation to extract: (1) a task summary, "
            "(2) key output/conclusion, (3) any decisions made (with confidence + domain), "
            "(4) any open questions or threads that weren't resolved."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "One-sentence summary of the task or question addressed this session",
                },
                "output": {
                    "type": "string",
                    "description": "The key output, conclusion, or deliverable from this session (2-5 sentences)",
                },
                "decisions": {
                    "type": "array",
                    "description": "Decisions made during this session (max 10)",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "description": "The decision statement"},
                            "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0, "default": 0.75},
                            "domain": {"type": "string", "default": "strategy"},
                            "rationale": {"type": "string"},
                        },
                        "required": ["content"],
                    },
                    "default": [],
                },
                "open_threads": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Unresolved questions or issues surfaced during this session (max 5)",
                    "default": [],
                },
                "source": {
                    "type": "string",
                    "description": "Source of the session: 'cowork', 'claude_code', 'claude_agent', 'claude_chat'",
                    "default": "cowork",
                },
                "app_id": {
                    "type": "string",
                    "description": "App this session belongs to (default: meridian)",
                    "default": "meridian",
                },
                "project": {
                    "type": "string",
                    "description": "Optional project slug. Tags the session and all its decisions to a project namespace.",
                },
            },
            "required": ["task", "output"],
        },
    },
    {
        "name": "get_recent_changes",
        "description": (
            "List recent write activity in Mnemo (what was added or updated), "
            "including client source, timestamp, action, and summary. "
            "Use this for questions like 'what did Codex add to Mnemo?'"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "client": {
                    "type": "string",
                    "enum": ["all", "codex", "claude", "gemini", "other"],
                    "default": "all",
                },
                "action": {"type": "string"},
                "project": {"type": "string"},
                "limit": {"type": "integer", "default": 20},
                "since_days": {"type": "integer", "default": 30},
            },
        },
    },
    {
        "name": "list_projects",
        "description": (
            "List all project slugs in Mnemo memory with session and decision counts "
            "and last activity date. Use this to discover what projects exist before "
            "scoping a search or retrieval."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max projects to return (default: 20)", "default": 20},
            },
        },
    },
    {
        "name": "get_project_context",
        "description": (
            "One-shot retrieval of a project's full state: recent sessions, open decisions, "
            "open threads, and key entities — packaged for injection into an agent's context "
            "window at the start of a project session. "
            "Use this at the start of any session scoped to a specific project."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {
                    "type": "string",
                    "description": "The project slug to retrieve context for (e.g. 'atlas')",
                },
                "max_tokens": {
                    "type": "integer",
                    "description": "Max tokens to return (default: 2000)",
                    "default": 2000,
                },
            },
            "required": ["project"],
        },
    },
]

# ── Usage recording ───────────────────────────────────────────────────────────

_MAX_TOOL_LIMIT = 50
_THREAD_STATUS_ALIASES = {
    "monitoring": "deferred",
    "abandoned": "dormant",
}

def _record_mcp_usage(tool_name: str) -> Dict:
    """Fire-and-forget usage recording. Never raises."""
    try:
        return _api_call("POST", f"/profile/{_PROFILE}/usage/mcp", {"tool": tool_name, "source": "mcp"})
    except Exception:
        return {}


# ── Tool handlers ─────────────────────────────────────────────────────────────

def _handle_search_memory(args: Dict[str, Any]) -> str:
    verbatim = bool(args.get("verbatim", False))
    if verbatim:
        max_tokens = args.get("max_tokens", 4000)
        n_results = args.get("n_results", 2)
    else:
        max_tokens = args.get("max_tokens", 1500)
        n_results = args.get("n_results", 5)

    body: Dict[str, Any] = {
        "query": args.get("query", ""),
        "max_tokens": max_tokens,
        "n_memories": n_results,
        "include": args.get("include", ["sessions", "decisions", "threads"]),
        "verbatim": verbatim,
    }
    if args.get("project"):
        body["project"] = args["project"]
    result = _api_call("POST", "/api/v1/context/retrieve", body)
    if "error" in result:
        return f"Error searching memory: {result['error']}"

    context_block = result.get("context_block", "No relevant context found.")
    sources = result.get("sources", [])
    token_est = result.get("token_estimate", 0)
    output = [context_block]
    if sources:
        output.append(f"\n[{len(sources)} source(s), ~{token_est} tokens]")

    usage_resp = _record_mcp_usage("search_memory")
    if usage_resp.get("quota_exceeded"):
        output.append(
            f"\n[Usage: {usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} "
            f"MCP calls this month — upgrade at {_API_URL.rstrip('/')}/settings#upgrade]"
        )
    return "\n".join(output)


def _handle_get_open_threads(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 10)), _MAX_TOOL_LIMIT)
    requested_status = str(args.get("status", "open")).strip().lower()
    status = _THREAD_STATUS_ALIASES.get(requested_status, requested_status)
    if status not in {"open", "deferred", "resolved", "dormant", "all"}:
        return (
            "Error: status must be one of open, deferred, resolved, dormant, all "
            "(aliases: monitoring, abandoned)."
        )
    params: Dict[str, Any] = {"status": status, "limit": limit}
    if args.get("project"):
        params["project"] = args["project"]
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"/profile/{_PROFILE}/threads?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching threads: {result['error']}"
    threads = result if isinstance(result, list) else result.get("threads", [])

    usage_resp = _record_mcp_usage("get_open_threads")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not threads:
        return "No open threads found." + quota_notice
    lines = [f"Open threads ({len(threads)}):"]
    for t in threads:
        lines.append(f"• {t.get('title', '?')} — seen {t.get('recurrence_count', 1)}x, last: {t.get('last_mentioned', '?')}")
    return "\n".join(lines) + quota_notice


def _handle_get_decisions(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 10)), _MAX_TOOL_LIMIT)
    params: Dict[str, Any] = {"status": args.get("status", "open"), "limit": limit}
    if args.get("domain"):
        params["domain"] = args["domain"]
    if args.get("project"):
        params["project"] = args["project"]
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"/profile/{_PROFILE}/decisions/merged?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching decisions: {result['error']}"
    decisions = result if isinstance(result, list) else result.get("decisions", [])

    usage_resp = _record_mcp_usage("get_decisions")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not decisions:
        return "No open decisions found." + quota_notice

    def _conf_percent(value: Any) -> str:
        if isinstance(value, str):
            v = value.strip().lower()
            mapping = {"high": 0.85, "medium": 0.65, "low": 0.35}
            pct = mapping.get(v, 0.0) * 100
            return f"{pct:.0f}%"
        try:
            return f"{float(value) * 100:.0f}%"
        except Exception:
            return "0%"

    lines = [f"Active decisions ({len(decisions)}):"]
    for d in decisions:
        proj = str(d.get("project_id", "") or "").strip()
        proj_hint = f" [project:{proj}]" if proj else " [project:common]"
        lines.append(
            f"• [{d.get('domain', '?')}] ({d.get('source', 'tracked')}) "
            f"{proj_hint} {d.get('content', '?')} (confidence: {_conf_percent(d.get('confidence', 0))})"
        )
    return "\n".join(lines) + quota_notice


def _handle_get_entities(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 5)), _MAX_TOOL_LIMIT)
    params: Dict[str, Any] = {"limit": limit}
    if args.get("name"):
        params["name"] = args["name"]
    if args.get("entity_type"):
        params["type"] = args["entity_type"]
    if args.get("project"):
        params["project"] = args["project"]
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"/profile/{_PROFILE}/entities?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching entities: {result['error']}"
    entities = result if isinstance(result, list) else result.get("entities", [])

    usage_resp = _record_mcp_usage("get_entities")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not entities:
        return "No entities found." + quota_notice
    lines = [f"Entities ({len(entities)}):"]
    for e in entities:
        lines.append(
            f"• {e.get('name', '?')} [{e.get('type', '?')}] — "
            f"mentioned {len(e.get('mentions', []))}x, last: {e.get('last_seen', '?')}"
        )
    return "\n".join(lines) + quota_notice


def _handle_get_morning_brief(args: Dict[str, Any]) -> str:
    params: Dict[str, Any] = {}
    if args.get("project"):
        params["project"] = args["project"]
    qs = ("?" + urllib.parse.urlencode(params)) if params else ""
    result = _api_call("GET", f"/profile/{_PROFILE}/brief{qs}")
    if "error" in result:
        return f"Error fetching brief: {result['error']}"
    brief_items = result if isinstance(result, list) else []
    if not brief_items:
        _record_mcp_usage("get_morning_brief")
        return "Morning brief unavailable — try running a session first."
    lines = []
    for item in brief_items[:10]:
        text = item.get("text") or item.get("content") or str(item) if isinstance(item, dict) else str(item)
        lines.append(f"• {text}")
    usage_resp = _record_mcp_usage("get_morning_brief")
    output = "\n".join(lines)
    if usage_resp.get("quota_exceeded"):
        output += f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
    return output


def _handle_log_session(args: Dict[str, Any]) -> str:
    body: Dict[str, Any] = {
        "title": args.get("task", ""),
        "content": args.get("output", ""),
        "source": "custom",
        "source_client": _CLIENT_HINT,
    }
    if args.get("project"):
        body["project"] = args["project"]
        body["project_id"] = args["project"]
    result = _api_call("POST", f"/profile/{_PROFILE}/sessions/import", body)
    if "error" in result:
        _record_mcp_usage("log_session")
        detail = result.get("detail", "")
        return f"Error logging session: {result['error']} — {detail}"
    _record_mcp_usage("log_session")
    return f"Session indexed successfully. ID: {result.get('session_id', '?')}"


def _handle_log_decision(args: Dict[str, Any]) -> str:
    body: Dict[str, Any] = {
        "content": args.get("content", ""),
        "confidence": float(args.get("confidence", 0.75)),
        "domain": args.get("domain", "strategy"),
        "rationale": args.get("rationale", ""),
        "source_client": _CLIENT_HINT,
    }
    if args.get("project"):
        body["project"] = args["project"]
        body["project_id"] = args["project"]
    result = _api_call("POST", f"/profile/{_PROFILE}/decisions", body)
    if "error" in result:
        _record_mcp_usage("log_decision")
        detail = result.get("detail", "")
        return f"Error logging decision: {result['error']} — {detail}"
    _record_mcp_usage("log_decision")
    content_preview = args.get("content", "")[:80]
    return f"Decision recorded. ID: {result.get('decision_id', '?')} | {content_preview}"


def _handle_wrap_session(args: Dict[str, Any]) -> str:
    """Atomic end-of-session wrap: log session + decisions + surface threads.

    Replicates the Meridian Chat.jsx ExtractionCard flow for MCP contexts
    (Claude Code, Cowork, agents). The ExtractionCard fires on the streaming
    `done` event and lets the user save detected threads + decisions; this
    tool does the equivalent without a UI — Claude extracts them from the
    conversation and persists everything in one call.
    """
    task = args.get("task", "")
    output = args.get("output", "")
    decisions = args.get("decisions", []) or []
    open_threads = args.get("open_threads", []) or []
    source = args.get("source", "cowork")
    project = args.get("project", "")

    results: List[str] = []
    errors: List[str] = []

    if project:
        results.append(f"[project: {project}]")

    # ── 1. Index the session ───────────────────────────────────────────────────
    session_body: Dict[str, Any] = {
        "title": task,
        "content": output,
        "source": "custom",
        "source_client": _CLIENT_HINT,
    }
    if project:
        session_body["project"] = project
        session_body["project_id"] = project
    session_result = _api_call("POST", f"/profile/{_PROFILE}/sessions/import", session_body)
    if "error" in session_result:
        errors.append(f"Session log failed: {session_result['error']}")
        session_id = None
    else:
        session_id = session_result.get("session_id", "?")
        auto_decisions = session_result.get("extracted_decisions", [])
        auto_threads = session_result.get("extracted_threads", [])
        results.append(f"✓ Session indexed — ID: {session_id}")
        if auto_decisions:
            results.append(f"  └ {len(auto_decisions)} decision(s) auto-extracted from content")
        if auto_threads:
            results.append(f"  └ {len(auto_threads)} thread(s) auto-extracted from content")

    # ── 2. Log explicit decisions (cap at 10) ─────────────────────────────────
    logged_decisions: List[str] = []
    for d in decisions[:10]:
        content = (d.get("content") or "").strip()
        if not content:
            continue
        d_body: Dict[str, Any] = {
            "content": content,
            "confidence": float(d.get("confidence", 0.75)),
            "domain": d.get("domain", "strategy"),
            "rationale": d.get("rationale", ""),
        }
        if project:
            d_body["project"] = project
            d_body["project_id"] = project
        d_result = _api_call("POST", f"/profile/{_PROFILE}/decisions", d_body)
        if "error" not in d_result:
            logged_decisions.append(content[:80])
        else:
            errors.append(f"Decision failed: {d_result['error']}")

    if logged_decisions:
        results.append(f"✓ {len(logged_decisions)} decision(s) logged:")
        for dc in logged_decisions:
            results.append(f"  • {dc}")

    # ── 3. Persist open threads to the thread registry ────────────────────────
    # Previously these were only surfaced to the user (not persisted).
    # Now each thread string is written via POST /profile/{name}/threads so
    # it appears in get_open_threads, the morning brief, and debt scanning.
    # Threads that duplicate an existing title are deduplicated by the ThreadEngine
    # (recurrence_count is incremented instead of creating a duplicate record).
    logged_threads: List[str] = []
    if open_threads:
        for raw_thread in open_threads[:5]:
            title = str(raw_thread).strip()
            if not title:
                continue
            t_body: Dict[str, Any] = {"title": title, "priority": "medium"}
            if project:
                t_body["linked_project_id"] = project
            t_result = _api_call("POST", f"/profile/{_PROFILE}/threads", t_body)
            if "error" not in t_result:
                logged_threads.append(title)
            else:
                # Non-fatal: surface threads even if persistence fails
                errors.append(f"Thread persist failed: {t_result.get('error', '?')}")
                logged_threads.append(title)  # still surface it

    if logged_threads:
        results.append(f"\n✓ Open threads persisted ({len(logged_threads)}):")
        for t in logged_threads:
            results.append(f"  ◦ {t}")

    # ── 4. Record usage ───────────────────────────────────────────────────────
    usage_resp = _record_mcp_usage("wrap_session")
    if usage_resp.get("quota_exceeded"):
        results.append(
            f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} "
            f"MCP calls this month — upgrade at {_API_URL.rstrip('/')}/settings#upgrade]"
        )

    if errors:
        results.append(f"\n⚠ {len(errors)} warning(s): {'; '.join(errors)}")

    return "\n".join(results) if results else "Session wrap complete."


def _handle_list_projects(args: Dict[str, Any]) -> str:
    limit = min(int(args.get("limit", 20)), _MAX_TOOL_LIMIT)
    qs = urllib.parse.urlencode({"limit": limit})
    result = _api_call("GET", f"/profile/{_PROFILE}/projects?{qs}")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching projects: {result['error']}"
    projects = result if isinstance(result, list) else result.get("projects", [])

    usage_resp = _record_mcp_usage("list_projects")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )

    if not projects:
        return "No projects found. Tag a session or decision with a project slug to create one." + quota_notice

    lines = [f"Projects ({len(projects)}):"]
    for p in projects:
        slug = p.get("slug") or p.get("project") or p.get("name", "?")
        sessions = p.get("session_count", "?")
        decisions = p.get("decision_count", "?")
        last_active = p.get("last_active") or p.get("updated_at", "?")
        lines.append(f"• {slug} — {sessions} sessions, {decisions} decisions, last active: {last_active}")
    return "\n".join(lines) + quota_notice


def _handle_get_project_context(args: Dict[str, Any]) -> str:
    project = args.get("project", "").strip()
    if not project:
        return "Error: project slug is required."
    max_tokens = args.get("max_tokens", 2000)

    result = _api_call("GET", f"/profile/{_PROFILE}/projects/{urllib.parse.quote(project)}/context"
                       + f"?max_tokens={max_tokens}")

    if isinstance(result, dict) and "error" in result:
        # Fallback: if the dedicated endpoint doesn't exist yet, synthesise context
        # from existing tools so the caller still gets something useful.
        if result.get("error", "").startswith("HTTP 404"):
            return _synthesise_project_context(project, max_tokens)
        return f"Error fetching project context: {result['error']}"

    context_block = result.get("context_block") or result.get("content", "")
    if not context_block:
        return _synthesise_project_context(project, max_tokens)

    usage_resp = _record_mcp_usage("get_project_context")
    quota_notice = (
        f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        if usage_resp.get("quota_exceeded") else ""
    )
    return context_block + quota_notice


def _synthesise_project_context(project: str, max_tokens: int) -> str:
    """Fallback: build project context from existing tools when the dedicated
    /projects/{slug}/context endpoint is not yet available on the backend."""
    parts: List[str] = [f"# Project context: {project}\n"]

    # Recent sessions via semantic search scoped to project
    search_result = _api_call("POST", "/api/v1/context/retrieve", {
        "query": f"project {project}",
        "max_tokens": max_tokens // 2,
        "n_memories": 5,
        "include": ["sessions", "decisions", "threads"],
        "project": project,
    })
    if "error" not in search_result:
        block = search_result.get("context_block", "")
        if block:
            parts.append(block)

    # Open decisions scoped to project
    qs = urllib.parse.urlencode({"status": "open", "limit": 10, "project": project})
    d_result = _api_call("GET", f"/profile/{_PROFILE}/decisions?{qs}")
    decisions = d_result if isinstance(d_result, list) else d_result.get("decisions", [])
    if decisions:
        parts.append(f"\n## Open decisions ({len(decisions)})")
        for d in decisions:
            parts.append(f"• [{d.get('domain', '?')}] {d.get('content', '?')} ({float(d.get('confidence', 0)):.0%})")

    # Open threads scoped to project
    tqs = urllib.parse.urlencode({"status": "open", "limit": 5, "project": project})
    t_result = _api_call("GET", f"/profile/{_PROFILE}/threads?{tqs}")
    threads = t_result if isinstance(t_result, list) else t_result.get("threads", [])
    if threads:
        parts.append(f"\n## Open threads ({len(threads)})")
        for t in threads:
            parts.append(f"◦ {t.get('title', '?')} — seen {t.get('recurrence_count', 1)}x")

    _record_mcp_usage("get_project_context")
    return "\n".join(parts) if len(parts) > 1 else f"No context found for project '{project}' yet."


def _handle_get_recent_changes(args: Dict[str, Any]) -> str:
    client = str(args.get("client", "all")).strip().lower() or "all"
    action = str(args.get("action", "")).strip()
    project = str(args.get("project", "")).strip()
    limit = max(1, min(int(args.get("limit", 20)), _MAX_TOOL_LIMIT))
    since_days = max(1, min(int(args.get("since_days", 30)), 365))
    params: Dict[str, Any] = {
        "client": client,
        "limit": limit,
        "since_days": since_days,
    }
    if action:
        params["action"] = action
    if project:
        params["project"] = project
    qs = urllib.parse.urlencode(params)
    result = _api_call("GET", f"/profile/{_PROFILE}/activity/changes?{qs}")
    usage_resp = _record_mcp_usage("get_recent_changes")

    if isinstance(result, dict) and "error" in result:
        return f"Error fetching changes: {result['error']}"

    changes = result.get("changes", []) if isinstance(result, dict) else []
    if not changes:
        output = "No recent changes found for the selected filters."
        if usage_resp.get("quota_exceeded"):
            output += f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]"
        return output

    lines = [f"Recent changes ({len(changes)}):"]
    for item in changes:
        created_at = str(item.get("created_at", "?"))[:19].replace("T", " ")
        src_client = item.get("client", "other")
        action_name = item.get("action", "change")
        summary = str(item.get("summary", "")).strip() or "(no summary)"
        rid = item.get("resource_id", "")
        suffix = f" [{rid}]" if rid else ""
        lines.append(f"• {created_at} | {src_client} | {action_name}{suffix}: {summary}")
    if usage_resp.get("quota_exceeded"):
        lines.append(f"\n[{usage_resp.get('used', '?')}/{usage_resp.get('limit', '?')} MCP calls — upgrade at /settings#upgrade]")
    return "\n".join(lines)


_TOOL_HANDLERS = {
    "search_memory": _handle_search_memory,
    "get_open_threads": _handle_get_open_threads,
    "get_decisions": _handle_get_decisions,
    "get_entities": _handle_get_entities,
    "get_morning_brief": _handle_get_morning_brief,
    "log_session": _handle_log_session,
    "log_decision": _handle_log_decision,
    "wrap_session": _handle_wrap_session,
    "list_projects": _handle_list_projects,
    "get_project_context": _handle_get_project_context,
    "get_recent_changes": _handle_get_recent_changes,
}


# ── MCP server builder ────────────────────────────────────────────────────────

def build_mcp_server() -> "Server":
    if not _MCP_AVAILABLE:
        raise RuntimeError("mcp package not installed. Run: pip install mnemomcp")

    server = Server("mnemo-platform")

    @server.list_tools()
    async def list_tools():
        return [Tool(name=t["name"], description=t["description"], inputSchema=t["inputSchema"]) for t in MNEMO_TOOLS]

    @server.call_tool()
    async def call_tool(name: str, arguments: Dict[str, Any]):
        handler = _TOOL_HANDLERS.get(name)
        if handler is None:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
        if not _API_TOKEN:
            return [TextContent(type="text", text=(
                "Mnemo MCP: no API token configured.\n"
                "Set MNEMO_API_TOKEN or create ~/.mnemo/mcp_token.\n"
                "Get your token: Mnemo → Settings → Connect to Claude Desktop."
            ))]
        try:
            result = await asyncio.to_thread(handler, arguments or {})
            return [TextContent(type="text", text=clip_tool_output(result))]
        except Exception as e:
            logger.error("[mnemo-mcp] tool %s failed: %s", name, e, exc_info=True)
            return [TextContent(type="text", text=f"Error in {name}: {e}")]

    return server


# ── Main entry point ──────────────────────────────────────────────────────────

async def main():
    """Run the Mnemo MCP server over stdio."""
    if not _MCP_AVAILABLE:
        print("ERROR: mcp package not installed.\nRun: pip install mnemomcp", file=sys.stderr)
        sys.exit(1)
    if not _PROFILE:
        print("ERROR: MNEMO_PROFILE not set.\nSet MNEMO_PROFILE=<your-profile-name>.", file=sys.stderr)
        sys.exit(1)
    try:
        enforce_transport_policy(_API_URL)
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)

    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    logger.info("[mnemo-mcp] Starting Mnemo Platform MCP server (profile: %s)", _PROFILE)
    logger.info("[mnemo-mcp] Platform API: %s", _API_URL)

    server = build_mcp_server()
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())
