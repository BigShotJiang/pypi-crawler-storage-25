# mnemomcp

Standalone MCP server for the [Mnemo](https://mnemomcp.com) platform. Connects Mnemo's memory and intelligence layer to Claude Desktop, Claude Code, and any MCP-compatible client.

## Install

```bash
pip install mnemomcp
```

## Setup

**1. Get your token**

Open Mnemo → Settings → "Connect to Claude Desktop & Claude Code" → Generate Token.

**2. Add to Claude Desktop config**

Edit `~/claude_desktop_config.json` (or `~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "mnemo": {
      "command": "mnemo-mcp",
      "env": {
        "MNEMO_API_URL": "https://api.mnemomcp.com",
        "MNEMO_API_TOKEN": "your-token-here",
        "MNEMO_PROFILE": "your-profile-name"
      }
    }
  }
}
```

Restart Claude Desktop. The Mnemo tools will appear in any Claude conversation.

**3. For Claude Code**

Add the same block to `.mcp.json` in your project root.

## Tools

| Tool | What it does |
|---|---|
| `search_memory` | Semantic search over your session history |
| `get_open_threads` | Unresolved threads sorted by recurrence |
| `get_decisions` | Strategic decisions with confidence + rationale |
| `get_entities` | People, companies, projects, topics you've mentioned |
| `get_morning_brief` | Structured brief of what matters right now |
| `log_session` | Index an external session into Mnemo memory |
| `log_decision` | Record a decision from any context |

## Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `MNEMO_API_URL` | Yes | `http://localhost:7432` | URL of the Mnemo platform API |
| `MNEMO_API_TOKEN` | Yes | (reads `~/.mnemo/mcp_token`) | Long-lived platform token |
| `MNEMO_API_TOKEN_CMD` | No | — | Command that prints a bearer token (used if token/file are empty) |
| `MNEMO_OAUTH_ACCESS_TOKEN` | No | — | Optional externally-brokered access token fallback |
| `MNEMO_PROFILE` | Yes | — | Your Mnemo profile name |
| `MAX_MCP_OUTPUT_CHARS` | No | `20000` | Max characters returned per tool call before truncation |
| `MNEMO_ALLOW_INSECURE_HTTP` | No | `0` | Set `1` to allow non-loopback HTTP (testing only) |

## Security defaults

- Non-loopback `http://` API URLs are blocked by default.
- Use `https://...` for remote Mnemo backends.
- For controlled local/LAN testing only, set `MNEMO_ALLOW_INSECURE_HTTP=1`.

## How it works

`mnemo-mcp` is a thin HTTP client over the Mnemo REST API. It has no dependency on
the Mnemo backend codebase — it only requires the `mcp` package and Python stdlib.
The token is issued at the platform level (not tied to any specific Mnemo app).
