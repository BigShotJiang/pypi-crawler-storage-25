"""Pluggable auth principal models.

These describe *who* is invoking a skill. The runtime auth provider produces
an instance of the agent's declared ``auth_model`` and hands it to the
:class:`RunContext`.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class NoAuth(BaseModel):
    """Public agent: no caller identity required."""

    model_config = ConfigDict(extra="forbid", frozen=True)


class APIKeyAuth(BaseModel):
    """Caller authenticated by a long-lived API key."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    api_key_id: str
    scopes: list[str] = Field(default_factory=list)


class JWTAuth(BaseModel):
    """Caller authenticated by a JWT (typically from a user-facing login)."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    sub: str
    org_id: str | None = None
    email: str | None = None
    scopes: list[str] = Field(default_factory=list)
