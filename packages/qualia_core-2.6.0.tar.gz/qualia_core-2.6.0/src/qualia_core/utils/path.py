"""Path utilities."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from qualia_core.typing import TYPE_CHECKING

if TYPE_CHECKING:
    if sys.version_info >= (3, 11):
        from importlib.resources.abc import Traversable
    else:
        from importlib.abc import Traversable

    from importlib.readers import MultiplexedPath

logger = logging.getLogger(__name__)


def resources_to_path(resources: Path | MultiplexedPath | Traversable) -> Path:
    """Convert a (static type) Traversable to a Path if the underlying dynamic type is MultiplexedPath.

    This is useful when using :func:`importlib.resources.files` since with Python >= 3.10 it returns a
    :class:`importlib.readers.MultiplexedPath` when :class:`importlib.readers.NamespaceReader` is used as a reader,
    e.g. when used on a package available as a plain directory (not zip file). This allows getting a standard :class:`pathlib.Path`
    out of it.
    Any other situation will probably fail with ValueError.

    :param resources: An object returned by :func:`importlib.resources.files`
    :return: A standard Path object pointing to the ``resources`` path on the filesystem
    :raise ValueError: When conversion fails because ``resources`` was not a :class:`importlib.readers.MultiplexedPath` on Python
        >= 3.10 or a :class:`pathlib.Path`
    """
    if isinstance(resources, Path):  # Already Path objected, no need for hackery
        return resources

    if sys.version_info >= (3, 10):  # Python 3.10 may return MultiplexedPath
        from importlib.readers import MultiplexedPath
        if isinstance(resources, MultiplexedPath):
            return resources / '' # / operator applies to underlying Path

    logger.error('Could not convert %s to Path object: expected type Path or MultiplexedPath for Python >= 3.10, got %s',
                 resources,
                 type(resources))
    raise ValueError


def lookup_file(search_paths: list[Path], filename: Path) -> Path | None:
    for search_path in search_paths:
        file_path = search_path / Path(filename)
        if file_path.exists():
            return file_path
    return None
