# -*- coding: utf-8 -*-
"""
Unit tests for alibabacloud-agent-fs (no live API needed).

Usage:
    pytest tests/test_unit.py -v
"""
import os
import sys
import json
import time
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

from alibabacloud_agent_fs.providers.agentloop_memory.client import AgentLoopMemoryClient
from alibabacloud_agent_fs.providers.agentloop_memory.provider import MemoryProvider, _CACHE_MISS


# ===== _parse_path =====

class TestParsePath:
    @pytest.fixture
    def provider(self):
        client = MagicMock()
        return MemoryProvider(client)

    @pytest.mark.parametrize("path,expected_type", [
        ('/', 'root'),
        ('/_help.txt', 'root_help'),
        ('/stores', 'stores_dir'),
        ('/stores/_help.txt', 'stores_help'),
        ('/stores/my_store', 'store'),
        ('/stores/my_store/_info.json', 'store_info'),
        ('/stores/my_store/_add.txt', 'store_add'),
        ('/stores/my_store/_help.txt', 'store_help'),
        ('/stores/my_store/memories', 'memories_dir'),
        ('/stores/my_store/memories/_help.txt', 'memories_help'),
        ('/stores/my_store/memories/abc123.json', 'memory_item'),
        ('/stores/my_store/users', 'users_dir'),
        ('/stores/my_store/users/_help.txt', 'users_help'),
        ('/stores/my_store/users/alice', 'user_dir'),
        ('/stores/my_store/users/alice/_all.txt', 'user_all'),
        ('/stores/my_store/users/alice/_add.txt', 'user_add'),
        ('/stores/my_store/agents', 'agents_dir'),
        ('/stores/my_store/agents/bot1', 'agent_dir'),
        ('/stores/my_store/agents/bot1/_all.txt', 'agent_all'),
        ('/stores/my_store/search', 'search_dir'),
        ('/stores/my_store/search/coffee.txt', 'search_query'),
    ])
    def test_parse_known_paths(self, provider, path, expected_type):
        info = provider._parse_path(path)
        assert info['type'] == expected_type

    def test_parse_store_name(self, provider):
        info = provider._parse_path('/stores/my_store')
        assert info['store'] == 'my_store'

    def test_parse_memory_id(self, provider):
        info = provider._parse_path('/stores/s1/memories/mem123.json')
        assert info['memory_id'] == 'mem123'
        assert info['store'] == 's1'

    def test_parse_user_id(self, provider):
        info = provider._parse_path('/stores/s1/users/alice/_all.txt')
        assert info['user_id'] == 'alice'

    def test_parse_search_query_strips_txt(self, provider):
        info = provider._parse_path('/stores/s1/search/hello world.txt')
        assert info['query'] == 'hello world'

    def test_unknown_path(self, provider):
        info = provider._parse_path('/nonexistent')
        assert info['type'] == 'unknown'


# ===== _parse_input =====

class TestParseInput:
    @pytest.fixture
    def provider(self):
        client = MagicMock()
        return MemoryProvider(client)

    def test_empty_input(self, provider):
        assert provider._parse_input('') == []
        assert provider._parse_input('   ') == []

    def test_plain_text(self, provider):
        result = provider._parse_input('hello world')
        assert result == [{'role': 'user', 'content': 'hello world'}]

    def test_json_array(self, provider):
        data = [{"role": "user", "content": "hi"}]
        result = provider._parse_input(json.dumps(data))
        assert result == data

    def test_json_object(self, provider):
        data = {"role": "assistant", "content": "hello"}
        result = provider._parse_input(json.dumps(data))
        assert result == [data]

    def test_invalid_json_falls_back_to_text(self, provider):
        result = provider._parse_input('[broken json')
        assert result == [{'role': 'user', 'content': '[broken json'}]


# ===== Cache layer =====

class TestCacheLayer:
    @pytest.fixture
    def provider(self):
        client = MagicMock()
        return MemoryProvider(client)

    def test_cache_miss_returns_sentinel(self, provider):
        assert provider._cache_get('nonexistent') is _CACHE_MISS

    def test_cache_set_and_get(self, provider):
        provider._cache_set('key', 'value', ttl=10)
        assert provider._cache_get('key') == 'value'

    def test_cache_expires(self, provider):
        provider._cache_set('key', 'value', ttl=0.01)
        time.sleep(0.02)
        assert provider._cache_get('key') is _CACHE_MISS

    def test_cache_invalidate_all(self, provider):
        provider._cache_set('a', 1)
        provider._cache_set('b', 2)
        provider._cache_invalidate()
        assert provider._cache_get('a') is _CACHE_MISS
        assert provider._cache_get('b') is _CACHE_MISS

    def test_cache_invalidate_prefix(self, provider):
        provider._cache_set('stores:names', {'s1'})
        provider._cache_set('content:/stores/s1/info', b'data')
        provider._cache_invalidate('content:')
        assert provider._cache_get('stores:names') == {'s1'}
        assert provider._cache_get('content:/stores/s1/info') is _CACHE_MISS


# ===== _get_store_names (cached) =====

class TestGetStoreNames:
    def test_caches_store_list(self):
        client = MagicMock()
        client.list_memory_stores.return_value = [
            {'memoryStoreName': 'store1'}, {'memoryStoreName': 'store2'}
        ]
        provider = MemoryProvider(client)

        names = provider._get_store_names()
        assert names == {'store1', 'store2'}

        names2 = provider._get_store_names()
        assert names2 == {'store1', 'store2'}
        assert client.list_memory_stores.call_count == 1

    def test_store_exists_uses_cache(self):
        client = MagicMock()
        client.list_memory_stores.return_value = [{'memoryStoreName': 'foo'}]
        provider = MemoryProvider(client)

        assert provider._store_exists('foo') is True
        assert provider._store_exists('bar') is False
        assert client.list_memory_stores.call_count == 1


# ===== fd recycling =====

class TestFdRecycling:
    def test_fd_reuse_after_release(self):
        client = MagicMock()
        provider = MemoryProvider(client)

        fd1 = provider._next_fd()
        fd2 = provider._next_fd()
        assert fd1 != fd2

        provider._recycled_fds.append(fd1)
        fd3 = provider._next_fd()
        assert fd3 == fd1


# ===== _get_help_content =====

class TestGetHelpContent:
    @pytest.fixture
    def provider(self):
        client = MagicMock()
        return MemoryProvider(client)

    def test_root_help(self, provider):
        content = provider._get_help_content('root_help', {'store': None, 'user_id': None, 'agent_id': None})
        assert content is not None
        assert 'AgentLoop Memory' in content

    def test_unknown_type_returns_none(self, provider):
        content = provider._get_help_content('nonexistent', {})
        assert content is None

    def test_store_help_substitutes_name(self, provider):
        content = provider._get_help_content('store_help', {'store': 'my_store', 'user_id': None, 'agent_id': None})
        assert 'my_store' in content
