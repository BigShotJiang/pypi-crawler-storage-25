# -*- coding: utf-8 -*-
"""
Unit tests for AgentLoop Memory credential selection.
"""

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from alibabacloud_agent_fs.providers.agentloop_memory import client as memory_client_module
from alibabacloud_agent_fs.providers.agentloop_memory.client import (
    AgentLoopMemoryClient,
    build_memory_credential,
)


def test_build_memory_credential_prefers_sts():
    with patch.object(memory_client_module, "CredentialsConfig") as config_cls, patch.object(
        memory_client_module, "CredentialsClient"
    ) as client_cls:
        config = MagicMock()
        credential = MagicMock()
        config_cls.return_value = config
        client_cls.return_value = credential

        built, auth_mode = build_memory_credential(
            access_key_id="ak",
            access_key_secret="sk",
            security_token="token",
        )

        config_cls.assert_called_once_with(
            type="sts",
            access_key_id="ak",
            access_key_secret="sk",
            security_token="token",
        )
        client_cls.assert_called_once_with(config)
        assert built is credential
        assert auth_mode == "sts"


def test_build_memory_credential_supports_access_key():
    with patch.object(memory_client_module, "CredentialsConfig") as config_cls, patch.object(
        memory_client_module, "CredentialsClient"
    ) as client_cls:
        config = MagicMock()
        credential = MagicMock()
        config_cls.return_value = config
        client_cls.return_value = credential

        built, auth_mode = build_memory_credential(
            access_key_id="ak",
            access_key_secret="sk",
        )

        config_cls.assert_called_once_with(
            type="access_key",
            access_key_id="ak",
            access_key_secret="sk",
        )
        client_cls.assert_called_once_with(config)
        assert built is credential
        assert auth_mode == "access_key"


def test_build_memory_credential_supports_oidc():
    with patch.object(memory_client_module, "CredentialsConfig") as config_cls, patch.object(
        memory_client_module, "CredentialsClient"
    ) as client_cls:
        config = MagicMock()
        credential = MagicMock()
        config_cls.return_value = config
        client_cls.return_value = credential

        built, auth_mode = build_memory_credential(
            role_arn="acs:ram::123:role/example",
            oidc_provider_arn="acs:ram::123:oidc-provider/example",
            oidc_token_file="/tmp/token",
            role_session_name="session-name",
            region_id="cn-shanghai",
        )

        config_cls.assert_called_once_with(
            type="oidc_role_arn",
            role_arn="acs:ram::123:role/example",
            oidc_provider_arn="acs:ram::123:oidc-provider/example",
            oidc_token_file_path="/tmp/token",
            role_session_name="session-name",
            sts_endpoint="sts-vpc.cn-shanghai.aliyuncs.com",
        )
        client_cls.assert_called_once_with(config)
        assert built is credential
        assert auth_mode == "oidc_role_arn"


def test_build_memory_credential_rejects_partial_oidc():
    with pytest.raises(ValueError, match="OIDC auth requires"):
        build_memory_credential(
            role_arn="acs:ram::123:role/example",
            oidc_provider_arn="acs:ram::123:oidc-provider/example",
        )


def test_agentloop_memory_client_uses_custom_credential():
    with patch.object(memory_client_module, "Config") as tea_config_cls, patch.object(
        memory_client_module, "Client"
    ) as cms_client_cls:
        tea_config = MagicMock()
        cms_client = MagicMock()
        tea_config_cls.return_value = tea_config
        cms_client_cls.return_value = cms_client
        credential = MagicMock()

        client = AgentLoopMemoryClient(
            endpoint="cms.cn-hangzhou.aliyuncs.com",
            workspace="workspace",
            credential=credential,
        )

        tea_config_cls.assert_called_once_with(
            credential=credential,
            endpoint="cms.cn-hangzhou.aliyuncs.com",
        )
        cms_client_cls.assert_called_once_with(tea_config)
        assert client.client is cms_client
        assert client.auth_mode == "custom"
