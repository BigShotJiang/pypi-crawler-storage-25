# -*- coding: utf-8 -*-
"""
AgentLoop Memory API integration tests.

Tests Memory Store CRUD and Memory CRUD operations using:
1. CMS SDK directly (low-level API validation)
2. AgentLoopMemoryClient wrapper (package client validation)

Usage:
    pytest tests/test_memory_api.py -m integration -v -s
    python tests/test_memory_api.py
"""
import os
import sys
import time
import json

import pytest
from dotenv import load_dotenv

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.env'))

from alibabacloud_agent_fs.providers.agentloop_memory.client import AgentLoopMemoryClient

from alibabacloud_tea_openapi.models import Config
from alibabacloud_cms20240330.client import Client
from alibabacloud_cms20240330.models import (
    CreateMemoryStoreRequest,
    ListMemoryStoresRequest,
    UpdateMemoryStoreRequest,
    AddMemoriesRequest,
    AddMemoriesRequestMessages,
    SearchMemoriesRequest,
)


def _require_env():
    """Return (access_key_id, access_key_secret, endpoint, workspace) or skip."""
    ak = os.environ.get("ALIBABA_CLOUD_ACCESS_KEY_ID")
    sk = os.environ.get("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
    ws = os.environ.get("CMS_WORKSPACE")
    ep = os.environ.get("CMS_ENDPOINT", "cms.cn-hangzhou.aliyuncs.com")
    if not all([ak, sk, ws]):
        pytest.skip("Missing ALIBABA_CLOUD_ACCESS_KEY_ID / SECRET / CMS_WORKSPACE")
    return ak, sk, ep, ws


# ---------------------------------------------------------------------------
# Direct CMS SDK tests
# ---------------------------------------------------------------------------

class TestDirectSDK:
    """Direct CMS SDK Memory API tests (require live credentials)."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        ak, sk, ep, ws = _require_env()
        config = Config(access_key_id=ak, access_key_secret=sk, endpoint=ep)
        self.client = Client(config)
        self.workspace = ws

    @pytest.mark.integration
    def test_list_memory_stores(self):
        request = ListMemoryStoresRequest(max_results=100)
        response = self.client.list_memory_stores(self.workspace, request)
        assert response.body is not None
        data = response.body.to_map()
        stores = data.get('memoryStores', [])
        assert isinstance(stores, list)


# ---------------------------------------------------------------------------
# AgentLoopMemoryClient wrapper tests
# ---------------------------------------------------------------------------

class TestAgentLoopMemoryClient:
    """Tests for the AgentLoopMemoryClient wrapper."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        ak, sk, ep, ws = _require_env()
        self.client = AgentLoopMemoryClient(
            access_key_id=ak, access_key_secret=sk,
            endpoint=ep, workspace=ws,
        )

    @pytest.mark.integration
    def test_list_stores(self):
        stores = self.client.list_memory_stores()
        assert isinstance(stores, list)
        assert all('name' in s for s in stores)

    @pytest.mark.integration
    def test_get_store(self):
        stores = self.client.list_memory_stores()
        if not stores:
            pytest.skip("No stores available")
        store = self.client.get_memory_store(stores[0]['name'])
        assert store is not None
        assert 'name' in store


# ---------------------------------------------------------------------------
# Full E2E integration (long-running, run explicitly)
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.slow
def test_full_lifecycle():
    """Full create -> add -> search -> delete lifecycle."""
    ak, sk, ep, ws = _require_env()
    client = AgentLoopMemoryClient(
        access_key_id=ak, access_key_secret=sk,
        endpoint=ep, workspace=ws,
    )

    store_name = f"test_memory_{int(time.time())}"

    assert client.create_memory_store(store_name, "pytest integration test")
    try:
        time.sleep(15)

        store = client.get_memory_store(store_name)
        assert store is not None
        assert store['name'] == store_name

        result = client.add_memories(
            store_name,
            [{"role": "user", "content": "I like Python programming"}],
            user_id="pytest_user",
        )
        assert result is not None

        time.sleep(120)

        memories = client.search_memories(store_name, "Python", user_id="pytest_user")
        assert isinstance(memories, list)
    finally:
        client.delete_memory_store(store_name)


# ---------------------------------------------------------------------------
# Standalone runner (backward compatible)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s", "-m", "integration"])
