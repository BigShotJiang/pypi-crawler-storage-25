"""
AlibabaCloudAgentFS - Root FUSE filesystem dispatcher.

Mounts all registered providers under their respective top-level prefixes:

  /agentloop-memory/  → MemoryProvider  (AgentLoop Memory)
  /nacos/             → NacosProvider   (Nacos Config & Service Discovery)
  /_help.txt          → root help text

The dispatcher strips the first path component and forwards the remaining path
to the matching BaseProvider. All FUSE Operations methods are wired through the
same dispatch table so new providers can be added by registering them in __init__.
"""

import os
import time
import errno
import logging
from typing import Dict, Optional
from stat import S_IFDIR, S_IFREG

from fuse import FuseOSError, Operations

from .help_docs import HELP_ROOT
from .providers.base import BaseProvider

logger = logging.getLogger('alibabacloud-agent-fs')


class AlibabaCloudAgentFS(Operations):
    """
    FUSE Operations implementation that dispatches to registered providers.

    The root directory lists the names of all registered providers as
    subdirectories. Each FUSE call is forwarded to the provider responsible
    for the path's top-level component.
    """

    def __init__(self, providers: Dict[str, BaseProvider]):
        """
        Args:
            providers: mapping of top-level directory name → provider instance.
                       Example: {'agentloop-memory': MemoryProvider(...), 'nacos': NacosProvider(...)}
        """
        self._providers = providers
        self._help_bytes = HELP_ROOT.encode('utf-8')

    # ------------------------------------------------------------------
    # Internal routing helpers
    # ------------------------------------------------------------------

    def _dispatch(self, path: str):
        """
        Return (provider, relative_path) for the given absolute path.

        The top-level component is stripped and the rest is passed to the
        provider. Returns (None, path) when the path belongs to the root
        level (/, /_help.txt, /{provider_name}).
        """
        parts = path.lstrip('/').split('/', 1)
        prefix = parts[0]
        rest = '/' + parts[1] if len(parts) > 1 else '/'
        if prefix in self._providers:
            return self._providers[prefix], rest
        return None, path

    def _make_stat(self, is_dir: bool, size: int = 0) -> Dict:
        now = int(time.time())
        if is_dir:
            return {
                'st_mode': S_IFDIR | 0o755, 'st_nlink': 2, 'st_size': 4096,
                'st_atime': now, 'st_mtime': now, 'st_ctime': now,
                'st_uid': os.getuid(), 'st_gid': os.getgid(),
            }
        return {
            'st_mode': S_IFREG | 0o644, 'st_nlink': 1, 'st_size': size or 4096,
            'st_atime': now, 'st_mtime': now, 'st_ctime': now,
            'st_uid': os.getuid(), 'st_gid': os.getgid(),
        }

    # ------------------------------------------------------------------
    # FUSE Operations
    # ------------------------------------------------------------------

    def getattr(self, path, fh=None):
        # Root directory
        if path == '/':
            return self._make_stat(is_dir=True)

        # Root-level help file
        if path == '/_help.txt':
            return self._make_stat(is_dir=False, size=len(self._help_bytes))

        # Provider top-level directory
        parts = path.lstrip('/').split('/', 1)
        prefix = parts[0]
        if prefix in self._providers and len(parts) == 1:
            return self._make_stat(is_dir=True)

        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.ENOENT)
        return provider.getattr(rel, fh)

    def readdir(self, path, fh):
        if path == '/':
            entries = ['.', '..', '_help.txt']
            entries.extend(sorted(self._providers.keys()))
            return entries

        provider, rel = self._dispatch(path)
        if provider is None:
            return ['.', '..']
        return provider.readdir(rel, fh)

    def open(self, path, flags):
        if path == '/_help.txt':
            # Return a pseudo-fd backed by an internal read buffer
            return self._open_static(self._help_bytes)

        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.ENOENT)
        return provider.open(rel, flags)

    def read(self, path, size, offset, fh):
        if fh in self._static_fds:
            data = self._static_fds[fh]
            return data[offset:offset + size]

        provider, rel = self._dispatch(path)
        if provider is None:
            return b''
        return provider.read(rel, size, offset, fh)

    def write(self, path, data, offset, fh):
        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.EACCES)
        return provider.write(rel, data, offset, fh)

    def truncate(self, path, length, fh=None):
        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.EACCES)
        return provider.truncate(rel, length, fh)

    def release(self, path, fh):
        if fh in self._static_fds:
            del self._static_fds[fh]
            return 0

        provider, rel = self._dispatch(path)
        if provider is None:
            return 0
        return provider.release(rel, fh)

    def create(self, path, mode):
        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.EACCES)
        return provider.create(rel, mode)

    def mkdir(self, path, mode):
        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.EACCES)
        return provider.mkdir(rel, mode)

    def rmdir(self, path):
        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.EACCES)
        return provider.rmdir(rel)

    def unlink(self, path):
        provider, rel = self._dispatch(path)
        if provider is None:
            raise FuseOSError(errno.EACCES)
        return provider.unlink(rel)

    def rename(self, old, new):
        provider_old, rel_old = self._dispatch(old)
        provider_new, rel_new = self._dispatch(new)
        if provider_old is None or provider_old is not provider_new:
            raise FuseOSError(errno.EXDEV)
        return provider_old.rename(rel_old, rel_new)

    def destroy(self, path):
        """Called on filesystem unmount; give each provider a chance to clean up."""
        for provider in self._providers.values():
            try:
                provider.shutdown()
            except Exception as e:
                logger.warning(f"Provider shutdown error: {e}")

    # ------------------------------------------------------------------
    # Static fd pool (for root-level files like /_help.txt)
    # ------------------------------------------------------------------

    _static_fds: Dict[int, bytes] = {}
    _static_fd_counter = 0

    def _open_static(self, data: bytes) -> int:
        AlibabaCloudAgentFS._static_fd_counter += 1
        fd = AlibabaCloudAgentFS._static_fd_counter
        AlibabaCloudAgentFS._static_fds[fd] = data
        return fd
