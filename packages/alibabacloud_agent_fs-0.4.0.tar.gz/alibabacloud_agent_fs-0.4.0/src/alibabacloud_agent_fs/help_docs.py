"""Root-level help documentation for Alibaba Cloud Agent FS."""

HELP_ROOT = """# Alibaba Cloud Agent FS

Virtual filesystem for Alibaba Cloud cloud-native services.
Use standard shell commands (ls, cat, echo, mkdir, rm) to interact with:

  agentloop-memory/  - AgentLoop Memory (CMS)  - AI agent persistent memory
  nacos/             - Nacos                    - Config center & service registry

## Quick Start

# View available services
ls /

# AgentLoop Memory
ls agentloop-memory/stores/
cat agentloop-memory/stores/my_store/search/user preferences.txt

# Nacos Config
cat nacos/config/public/DEFAULT_GROUP/application.properties
echo "timeout=3000" > nacos/config/public/DEFAULT_GROUP/application.properties

# Nacos Services
ls nacos/services/public/DEFAULT_GROUP/
cat nacos/services/public/DEFAULT_GROUP/my-service/_info.json

## Getting Help

cat agentloop-memory/_help.txt    # Memory provider help
cat nacos/_help.txt               # Nacos provider help
cat nacos/config/_help.txt        # Config subtree help
cat nacos/services/_help.txt      # Services subtree help
"""
