"""
Alibaba Cloud Agent FS - Command Line Interface

Mounts a virtual FUSE filesystem that exposes Alibaba Cloud services as
standard directories and files. Enabled providers are determined by the
available credentials at startup:

  agentloop-memory/  - AgentLoop Memory (supports AK/SK, STS, and OIDC)
  nacos/             - Nacos Config & Service Discovery (requires NACOS_SERVER_ADDR)
"""

import argparse
import logging
import os
import sys

from dotenv import load_dotenv
from fuse import FUSE

from . import __version__
from .filesystem import AlibabaCloudAgentFS


def _build_memory_provider(args, env):
    """Construct MemoryProvider if CMS credentials are available. Returns None to skip."""
    from .providers.agentloop_memory.client import AgentLoopMemoryClient
    from .providers.agentloop_memory.provider import MemoryProvider

    access_key_id = args.access_key_id or env.get("ALIBABA_CLOUD_ACCESS_KEY_ID")
    access_key_secret = args.access_key_secret or env.get("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
    security_token = args.security_token or env.get("ALIBABA_CLOUD_SECURITY_TOKEN")
    role_arn = args.role_arn or env.get("ALIBABA_CLOUD_ROLE_ARN")
    oidc_provider_arn = args.oidc_provider_arn or env.get("ALIBABA_CLOUD_OIDC_PROVIDER_ARN")
    oidc_token_file = args.oidc_token_file or env.get("ALIBABA_CLOUD_OIDC_TOKEN_FILE")
    role_session_name = args.role_session_name or env.get("ALIBABA_CLOUD_ROLE_SESSION_NAME")
    region_id = (
        args.region_id
        or env.get("ALIBABA_CLOUD_REGION_ID")
        or env.get("HICLAW_REGION")
        or "cn-hangzhou"
    )
    endpoint = args.endpoint or env.get("CMS_ENDPOINT", "cms.cn-hangzhou.aliyuncs.com")
    workspace = args.workspace or args.project or env.get("CMS_WORKSPACE")

    has_supported_auth = (
        (access_key_id and access_key_secret)
        or (access_key_id and access_key_secret and security_token)
        or (role_arn and oidc_provider_arn and oidc_token_file)
    )
    if not workspace or not has_supported_auth:
        return None, None, None, None

    client = AgentLoopMemoryClient(
        endpoint=endpoint,
        workspace=workspace,
        access_key_id=access_key_id,
        access_key_secret=access_key_secret,
        security_token=security_token,
        role_arn=role_arn,
        oidc_provider_arn=oidc_provider_arn,
        oidc_token_file=oidc_token_file,
        role_session_name=role_session_name,
        region_id=region_id,
    )
    provider = MemoryProvider(client)
    return provider, client.auth_mode, endpoint, workspace


def _build_nacos_provider(args, env):
    """Construct NacosProvider if Nacos server address is available. Returns None to skip."""
    from .providers.nacos.client import NacosClient
    from .providers.nacos.provider import NacosProvider

    server_addr = getattr(args, "nacos_server", None) or env.get("NACOS_SERVER_ADDR")
    if not server_addr:
        return None, None

    namespace = getattr(args, "nacos_namespace", None) or env.get("NACOS_NAMESPACE", "public")
    username = getattr(args, "nacos_username", None) or env.get("NACOS_USERNAME")
    password = getattr(args, "nacos_password", None) or env.get("NACOS_PASSWORD")
    access_key = getattr(args, "nacos_access_key", None) or env.get("NACOS_ACCESS_KEY")
    secret_key = getattr(args, "nacos_secret_key", None) or env.get("NACOS_SECRET_KEY")
    use_tls = env.get("NACOS_USE_TLS", "").lower() in ("1", "true", "yes")

    client = NacosClient(
        server_addr=server_addr,
        namespace=namespace,
        username=username,
        password=password,
        access_key=access_key,
        secret_key=secret_key,
        use_tls=use_tls,
    )
    provider = NacosProvider(client)
    return provider, server_addr


def main():
    """Main entry point for alibabacloud-agent-fs command."""
    parser = argparse.ArgumentParser(
        prog="alibabacloud-agent-fs",
        description="Virtual filesystem for Alibaba Cloud cloud-native services",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Mount with AgentLoop Memory only
  alibabacloud-agent-fs /tmp/alibabacloud

  # Mount with STS credentials
  alibabacloud-agent-fs /tmp/alibabacloud \\
    --workspace my-cms-project \\
    --access-key-id sts-ak \\
    --access-key-secret sts-sk \\
    --security-token sts-token

  # Mount with OIDC / RRSA
  alibabacloud-agent-fs /tmp/alibabacloud \\
    --workspace my-cms-project \\
    --role-arn acs:ram::123456789012:role/example \\
    --oidc-provider-arn acs:ram::123456789012:oidc-provider/example \\
    --oidc-token-file /var/run/secrets/tokens/oidc-token

  # Mount with Nacos only
  alibabacloud-agent-fs /tmp/alibabacloud --nacos-server localhost:8848

Environment Variables:
  ALIBABA_CLOUD_ACCESS_KEY_ID       AK for AgentLoop Memory
  ALIBABA_CLOUD_ACCESS_KEY_SECRET   SK for AgentLoop Memory
  ALIBABA_CLOUD_SECURITY_TOKEN      STS security token for AgentLoop Memory
  ALIBABA_CLOUD_ROLE_ARN            OIDC role ARN for AgentLoop Memory
  ALIBABA_CLOUD_OIDC_PROVIDER_ARN   OIDC provider ARN for AgentLoop Memory
  ALIBABA_CLOUD_OIDC_TOKEN_FILE     OIDC token file path for AgentLoop Memory
  ALIBABA_CLOUD_ROLE_SESSION_NAME   Optional OIDC role session name
  ALIBABA_CLOUD_REGION_ID           Region for STS endpoint (default: cn-hangzhou)
  CMS_WORKSPACE                     CMS workspace name
  CMS_ENDPOINT                      CMS endpoint (default: cms.cn-hangzhou.aliyuncs.com)

  NACOS_SERVER_ADDR                 Nacos server address (host:port)
  NACOS_NAMESPACE                   Nacos default namespace (default: public)
  NACOS_USERNAME                    Nacos username (self-hosted auth)
  NACOS_PASSWORD                    Nacos password (self-hosted auth)
  NACOS_ACCESS_KEY                  Alibaba Cloud AK for MSE Nacos
  NACOS_SECRET_KEY                  Alibaba Cloud SK for MSE Nacos
  NACOS_USE_TLS                     Use HTTPS for Nacos (1/true/yes)
""",
    )

    parser.add_argument("mountpoint", help="Directory to mount the filesystem")
    parser.add_argument("--version", "-V", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--env", "-e", metavar="FILE", help="Path to .env file")

    cms_group = parser.add_argument_group("AgentLoop Memory (CMS)")
    cms_group.add_argument("--endpoint", metavar="HOST", help="CMS endpoint")
    cms_group.add_argument("--workspace", "-w", metavar="NAME", help="CMS workspace name")
    cms_group.add_argument("--project", "-p", metavar="NAME", help="Alias for --workspace")
    cms_group.add_argument("--access-key-id", metavar="ID", help="Alibaba Cloud Access Key ID")
    cms_group.add_argument("--access-key-secret", metavar="SECRET", help="Alibaba Cloud Access Key Secret")
    cms_group.add_argument("--security-token", metavar="TOKEN", help="Alibaba Cloud STS security token")
    cms_group.add_argument("--role-arn", metavar="ARN", help="OIDC role ARN for AgentLoop Memory")
    cms_group.add_argument(
        "--oidc-provider-arn",
        metavar="ARN",
        help="OIDC provider ARN for AgentLoop Memory",
    )
    cms_group.add_argument(
        "--oidc-token-file",
        metavar="FILE",
        help="OIDC token file path for AgentLoop Memory",
    )
    cms_group.add_argument(
        "--role-session-name",
        metavar="NAME",
        help="OIDC role session name (default: alibabacloud-agent-fs)",
    )
    cms_group.add_argument(
        "--region-id",
        metavar="REGION",
        help="Region used to derive the STS endpoint for OIDC auth (default: cn-hangzhou)",
    )

    nacos_group = parser.add_argument_group("Nacos")
    nacos_group.add_argument("--nacos-server", metavar="HOST:PORT", help="Nacos server address (e.g. localhost:8848)")
    nacos_group.add_argument("--nacos-namespace", metavar="NS", help="Nacos default namespace (default: public)")
    nacos_group.add_argument("--nacos-username", metavar="USER", help="Nacos username")
    nacos_group.add_argument("--nacos-password", metavar="PASS", help="Nacos password")
    nacos_group.add_argument("--nacos-access-key", metavar="AK", help="Alibaba Cloud AK for MSE Nacos")
    nacos_group.add_argument("--nacos-secret-key", metavar="SK", help="Alibaba Cloud SK for MSE Nacos")

    fuse_group = parser.add_argument_group("FUSE")
    fuse_group.add_argument("--debug", "-d", action="store_true", help="Enable debug logging")
    fuse_group.add_argument("--allow-other", action="store_true", help="Allow other users to access the filesystem")

    args = parser.parse_args()

    log_level = logging.DEBUG if args.debug else logging.WARNING
    logging.basicConfig(level=log_level, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    logging.getLogger("fuse").setLevel(logging.CRITICAL)
    logging.getLogger("urllib3").setLevel(logging.WARNING)

    load_dotenv(args.env or os.path.join(os.getcwd(), ".env"), override=False)
    env = os.environ

    providers = {}
    summary_lines = []

    try:
        memory_provider, auth_mode, cms_endpoint, workspace = _build_memory_provider(args, env)
    except ValueError as exc:
        print(f"Error: Invalid AgentLoop Memory auth configuration: {exc}", file=sys.stderr)
        sys.exit(1)

    if memory_provider is not None:
        providers["agentloop-memory"] = memory_provider
        summary_lines.append(
            f"  agentloop-memory/  → CMS AgentLoop Memory  workspace={workspace} endpoint={cms_endpoint} auth={auth_mode}"
        )
    else:
        summary_lines.append(
            "  agentloop-memory/  → DISABLED (set CMS_WORKSPACE plus AK/SK, AK/SK/token, or OIDC envs)"
        )

    nacos_provider, nacos_addr = _build_nacos_provider(args, env)
    if nacos_provider is not None:
        providers["nacos"] = nacos_provider
        summary_lines.append(f"  nacos/             → Nacos  server={nacos_addr}")
    else:
        summary_lines.append("  nacos/             → DISABLED (set NACOS_SERVER_ADDR)")

    if not providers:
        print("Error: No providers are configured. Set credentials for at least one service.", file=sys.stderr)
        print(
            "  AgentLoop Memory : CMS_WORKSPACE + (AK/SK, AK/SK/token, or OIDC role envs)",
            file=sys.stderr,
        )
        print("  Nacos            : NACOS_SERVER_ADDR", file=sys.stderr)
        sys.exit(1)

    mountpoint = os.path.abspath(args.mountpoint)
    if not os.path.exists(mountpoint):
        try:
            os.makedirs(mountpoint)
        except OSError as e:
            print(f"Error: Cannot create mountpoint '{mountpoint}': {e}", file=sys.stderr)
            sys.exit(1)
    if not os.path.isdir(mountpoint):
        print(f"Error: Mountpoint '{mountpoint}' is not a directory", file=sys.stderr)
        sys.exit(1)

    print(f"Alibaba Cloud Agent FS v{__version__}")
    print(f"Mounting at: {mountpoint}")
    print("Providers:")
    for line in summary_lines:
        print(line)
    print()
    print("Quick start:")
    print(f"  ls {mountpoint}/                            # List all providers")
    print(f"  cat {mountpoint}/_help.txt                  # View help")
    if "agentloop-memory" in providers:
        print(f"  ls {mountpoint}/agentloop-memory/stores/   # List memory stores")
    if "nacos" in providers:
        print(f"  ls {mountpoint}/nacos/config/               # List Nacos config namespaces")
    print()
    print("Press Ctrl+C to unmount")

    fs = AlibabaCloudAgentFS(providers)

    try:
        FUSE(
            fs,
            mountpoint,
            foreground=True,
            allow_other=args.allow_other,
            nothreads=True,
            debug=args.debug,
        )
    except RuntimeError as e:
        if "already mounted" in str(e).lower():
            print(f"Error: {mountpoint} is already mounted. Unmount first with:", file=sys.stderr)
            print(f"  fusermount -u {mountpoint}   # Linux", file=sys.stderr)
            print(f"  umount {mountpoint}           # macOS", file=sys.stderr)
        else:
            print(f"Error mounting filesystem: {e}", file=sys.stderr)
        sys.exit(1)


def unmount():
    """Helper to unmount the filesystem."""
    parser = argparse.ArgumentParser(
        prog="alibabacloud-agent-fs-unmount",
        description="Unmount Alibaba Cloud Agent filesystem",
    )
    parser.add_argument("mountpoint", help="Mountpoint to unmount")
    args = parser.parse_args()

    import subprocess

    try:
        if sys.platform == "darwin":
            subprocess.run(["umount", args.mountpoint], check=True)
        else:
            subprocess.run(["fusermount", "-u", args.mountpoint], check=True)
        print(f"Unmounted: {args.mountpoint}")
    except subprocess.CalledProcessError as e:
        print(f"Error: Failed to unmount: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
