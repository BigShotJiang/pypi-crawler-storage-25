"""
Base provider interface for Alibaba Cloud Agent FS providers.

Each provider handles a subtree of the virtual filesystem and implements
a subset of FUSE Operations. The root dispatcher (AlibabaCloudAgentFS) strips
the top-level path component and delegates to the matching provider.
"""

import errno
from fuse import FuseOSError


class BaseProvider:
    """
    Abstract base class for filesystem providers.

    Methods mirror the fuse.Operations interface. All methods receive paths
    relative to the provider's mount point (i.e., the /memory or /nacos
    prefix has already been stripped by the dispatcher).

    Default implementations raise ENOENT for getattr/readdir and EACCES
    for write operations, so subclasses only need to override what they support.
    """

    def getattr(self, path: str, fh=None) -> dict:
        raise FuseOSError(errno.ENOENT)

    def readdir(self, path: str, fh) -> list:
        return ['.', '..']

    def open(self, path: str, flags) -> int:
        raise FuseOSError(errno.ENOENT)

    def read(self, path: str, size: int, offset: int, fh: int) -> bytes:
        return b''

    def write(self, path: str, data: bytes, offset: int, fh: int) -> int:
        raise FuseOSError(errno.EACCES)

    def truncate(self, path: str, length: int, fh=None) -> int:
        raise FuseOSError(errno.EACCES)

    def release(self, path: str, fh: int) -> int:
        return 0

    def create(self, path: str, mode) -> int:
        raise FuseOSError(errno.EACCES)

    def mkdir(self, path: str, mode) -> int:
        raise FuseOSError(errno.EACCES)

    def rmdir(self, path: str) -> int:
        raise FuseOSError(errno.EACCES)

    def unlink(self, path: str) -> int:
        raise FuseOSError(errno.EACCES)

    def rename(self, old: str, new: str) -> int:
        raise FuseOSError(errno.EACCES)

    def shutdown(self) -> None:
        """Called when the filesystem is being unmounted. Override to clean up resources."""
        pass
