"""
AgentLoop Memory API Client (using alibabacloud_cms20240330 SDK)
"""

import functools
import logging
import time
from typing import Dict, List, Optional, Tuple

from alibabacloud_credentials.client import Client as CredentialsClient
from alibabacloud_credentials.models import Config as CredentialsConfig
from alibabacloud_tea_openapi.models import Config
from alibabacloud_cms20240330.client import Client
from alibabacloud_cms20240330.models import (
    AddMemoriesRequest,
    AddMemoriesRequestMessages,
    CreateMemoryStoreRequest,
    DeleteMemoriesRequest,
    GetMemoriesRequest,
    ListMemoryStoresRequest,
    SearchMemoriesRequest,
    UpdateMemoryRequest,
    UpdateMemoryStoreRequest,
)

logger = logging.getLogger("alibabacloud-agent-fs.memory")

DEFAULT_REGION_ID = "cn-hangzhou"
DEFAULT_ROLE_SESSION_NAME = "alibabacloud-agent-fs"


def _retry(max_retries=2, backoff=0.5):
    """Retry decorator with exponential backoff for idempotent operations."""

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except Exception as e:
                    last_exc = e
                    if attempt < max_retries:
                        time.sleep(backoff * (2 ** attempt))
                        logger.debug(f"Retry {attempt + 1}/{max_retries} for {fn.__name__}: {e}")
            logger.error(f"{fn.__name__} failed after {max_retries + 1} attempts: {last_exc}")
            raise last_exc

        return wrapper

    return decorator


def build_memory_credential(
    access_key_id: Optional[str] = None,
    access_key_secret: Optional[str] = None,
    security_token: Optional[str] = None,
    role_arn: Optional[str] = None,
    oidc_provider_arn: Optional[str] = None,
    oidc_token_file: Optional[str] = None,
    role_session_name: Optional[str] = None,
    region_id: Optional[str] = None,
) -> Tuple[Optional[CredentialsClient], Optional[str]]:
    """Build a credential client for AgentLoop Memory.

    Preference order:
      1. STS triplet (AK/SK/token)
      2. Static AK/SK
      3. OIDC role assumption (RRSA-compatible)
    """

    if access_key_id and access_key_secret and security_token:
        config = CredentialsConfig(
            type="sts",
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            security_token=security_token,
        )
        return CredentialsClient(config), "sts"

    if access_key_id and access_key_secret:
        config = CredentialsConfig(
            type="access_key",
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
        )
        return CredentialsClient(config), "access_key"

    if role_arn or oidc_provider_arn or oidc_token_file:
        if not all([role_arn, oidc_provider_arn, oidc_token_file]):
            raise ValueError(
                "OIDC auth requires role_arn, oidc_provider_arn, and oidc_token_file"
            )
        sts_region = region_id or DEFAULT_REGION_ID
        config = CredentialsConfig(
            type="oidc_role_arn",
            role_arn=role_arn,
            oidc_provider_arn=oidc_provider_arn,
            oidc_token_file_path=oidc_token_file,
            role_session_name=role_session_name or DEFAULT_ROLE_SESSION_NAME,
            sts_endpoint=f"sts-vpc.{sts_region}.aliyuncs.com",
        )
        return CredentialsClient(config), "oidc_role_arn"

    return None, None


class AgentLoopMemoryClient:
    """CMS AgentLoop Memory API client wrapper."""

    def __init__(
        self,
        endpoint: str,
        workspace: str,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        security_token: Optional[str] = None,
        role_arn: Optional[str] = None,
        oidc_provider_arn: Optional[str] = None,
        oidc_token_file: Optional[str] = None,
        role_session_name: Optional[str] = None,
        region_id: Optional[str] = None,
        credential: Optional[CredentialsClient] = None,
    ):
        if credential is None:
            credential, auth_mode = build_memory_credential(
                access_key_id=access_key_id,
                access_key_secret=access_key_secret,
                security_token=security_token,
                role_arn=role_arn,
                oidc_provider_arn=oidc_provider_arn,
                oidc_token_file=oidc_token_file,
                role_session_name=role_session_name,
                region_id=region_id,
            )
        else:
            auth_mode = "custom"

        if credential is None:
            raise ValueError(
                "Missing supported CMS credentials. Provide AK/SK, STS AK/SK/token, or OIDC role configuration."
            )

        config = Config(credential=credential, endpoint=endpoint)
        self.client = Client(config)
        self.workspace = workspace
        self.auth_mode = auth_mode

    def list_memory_stores(self) -> List[Dict]:
        try:
            return self._list_memory_stores_impl()
        except Exception as e:
            logger.error(f"list_memory_stores error: {e}")
        return []

    @_retry(max_retries=2, backoff=0.5)
    def _list_memory_stores_impl(self) -> List[Dict]:
        request = ListMemoryStoresRequest(max_results=100)
        response = self.client.list_memory_stores(self.workspace, request)
        if response.body:
            data = response.body.to_map()
            return data.get("memoryStores", [])
        return []

    def get_memory_store(self, store_name: str) -> Optional[Dict]:
        try:
            return self._get_memory_store_impl(store_name)
        except Exception as e:
            logger.error(f"get_memory_store error: {e}")
        return None

    @_retry(max_retries=2, backoff=0.5)
    def _get_memory_store_impl(self, store_name: str) -> Optional[Dict]:
        response = self.client.get_memory_store(self.workspace, store_name)
        if response.body:
            return response.body.to_map()
        return None

    def create_memory_store(self, store_name: str, description: str = "") -> bool:
        try:
            request = CreateMemoryStoreRequest(
                memory_store_name=store_name,
                description=description or "Created via alibabacloud-agent-fs",
                short_term_ttl=300,
                enable_graph=False,
            )
            self.client.create_memory_store(self.workspace, request)
            return True
        except Exception as e:
            if "MemoryStoreAlreadyExist" in str(e):
                return False
            logger.error(f"create_memory_store error: {e}")
            return False

    def delete_memory_store(self, store_name: str) -> bool:
        try:
            self.client.delete_memory_store(self.workspace, store_name)
            return True
        except Exception as e:
            logger.error(f"delete_memory_store error: {e}")
            return False

    def add_memories(
        self,
        store_name: str,
        messages: List[Dict],
        user_id: str = None,
        agent_id: str = None,
    ) -> Optional[Dict]:
        try:
            msg_objects = [
                AddMemoriesRequestMessages(
                    role=m.get("role", "user"),
                    content=m.get("content", ""),
                )
                for m in messages
            ]
            request = AddMemoriesRequest(
                messages=msg_objects,
                user_id=user_id or "default_user",
                agent_id=agent_id or "fs_agent",
                app_id="alibabacloud_agent_fs",
                infer=True,
            )
            response = self.client.add_memories(self.workspace, store_name, request)
            return response.body.to_map() if response.body else {}
        except Exception as e:
            logger.error(f"add_memories error: {e}")
            return None

    def search_memories(
        self,
        store_name: str,
        query: str,
        user_id: str = None,
        agent_id: str = None,
        top_k: int = 20,
    ) -> List[Dict]:
        try:
            return self._search_memories_impl(store_name, query, user_id, agent_id, top_k)
        except Exception as e:
            logger.error(f"search_memories error: {e}")
        return []

    @_retry(max_retries=2, backoff=0.5)
    def _search_memories_impl(self, store_name, query, user_id, agent_id, top_k):
        request = SearchMemoriesRequest(
            query=query,
            user_id=user_id,
            agent_id=agent_id,
            top_k=top_k,
        )
        response = self.client.search_memories(self.workspace, store_name, request)
        if response.body:
            data = response.body.to_map()
            return data.get("results", [])
        return []

    def get_memories(
        self,
        store_name: str,
        user_id: str = None,
        agent_id: str = None,
        page: int = 1,
        page_size: int = 100,
    ) -> List[Dict]:
        try:
            return self._get_memories_impl(store_name, user_id, agent_id, page, page_size)
        except Exception as e:
            logger.error(f"get_memories error: {e}")
        return []

    @_retry(max_retries=2, backoff=0.5)
    def _get_memories_impl(self, store_name, user_id, agent_id, page, page_size):
        request = GetMemoriesRequest(
            user_id=user_id,
            agent_id=agent_id,
            page=page,
            page_size=page_size,
        )
        response = self.client.get_memories(self.workspace, store_name, request)
        if response.body:
            data = response.body.to_map()
            return data.get("results", [])
        return []

    def get_memory(self, store_name: str, memory_id: str) -> Optional[Dict]:
        try:
            return self._get_memory_impl(store_name, memory_id)
        except Exception as e:
            logger.error(f"get_memory error: {e}")
        return None

    @_retry(max_retries=2, backoff=0.5)
    def _get_memory_impl(self, store_name, memory_id):
        response = self.client.get_memory(self.workspace, store_name, memory_id)
        if response.body:
            return response.body.to_map()
        return None

    def update_memory(
        self,
        store_name: str,
        memory_id: str,
        text: str = None,
        metadata: Dict = None,
    ) -> bool:
        try:
            request = UpdateMemoryRequest(text=text, metadata=metadata)
            self.client.update_memory(self.workspace, store_name, memory_id, request)
            return True
        except Exception as e:
            logger.error(f"update_memory error: {e}")
            return False

    def delete_memory(self, store_name: str, memory_id: str) -> bool:
        try:
            self.client.delete_memory(self.workspace, store_name, memory_id)
            return True
        except Exception as e:
            logger.error(f"delete_memory error: {e}")
            return False

    def delete_memories(
        self,
        store_name: str,
        user_id: str = None,
        agent_id: str = None,
        app_id: str = None,
    ) -> bool:
        try:
            request = DeleteMemoriesRequest(
                user_id=user_id,
                agent_id=agent_id,
                app_id=app_id,
            )
            self.client.delete_memories(self.workspace, store_name, request)
            return True
        except Exception as e:
            logger.error(f"delete_memories error: {e}")
            return False

    def update_memory_store(
        self,
        store_name: str,
        description: str = None,
        short_term_ttl: int = None,
    ) -> bool:
        try:
            request = UpdateMemoryStoreRequest(
                description=description,
                short_term_ttl=short_term_ttl,
            )
            self.client.update_memory_store(self.workspace, store_name, request)
            return True
        except Exception as e:
            logger.error(f"update_memory_store error: {e}")
            return False

    def get_memory_history(self, store_name: str, memory_id: str) -> List[Dict]:
        try:
            response = self.client.get_memory_history(self.workspace, store_name, memory_id)
            if response.body:
                data = response.body.to_map()
                return data.get("results", [])
        except Exception as e:
            logger.error(f"get_memory_history error: {e}")
        return []
