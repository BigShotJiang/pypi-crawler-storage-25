"""AgentLoop Memory provider (providers.agentloop_memory)."""
