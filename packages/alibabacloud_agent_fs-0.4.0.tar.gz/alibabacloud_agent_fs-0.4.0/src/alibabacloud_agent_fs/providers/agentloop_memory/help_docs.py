"""
Help documentation for the AgentLoop Memory provider.
Agent-friendly text explaining how to use each directory level.
"""

HELP_MEMORY_ROOT = """# AgentLoop Memory

This subtree manages AI agent memories via the CMS AgentLoop Memory API.

## Quick Start

1. List available memory stores:
   ls stores/

2. Create a new store:
   mkdir stores/my_store

3. Add memories (write-only, async processing):
   echo "User likes coffee" > stores/my_store/_add.txt

4. Wait for processing (~30-60 seconds for new memories)

5. Query memories:
   cat stores/my_store/search/coffee.txt
   cat stores/my_store/users/default_user/_all.txt

## Important Notes

- _add.txt is WRITE-ONLY: data is sent to API, not stored locally
- After writing, memories are processed asynchronously (30-60s delay)
- To view memories, use: search/{query}.txt or users/{user}/_all.txt
- Do NOT cat _add.txt to check if write succeeded

## Directory Structure

- stores/           : All memory stores
- stores/{name}/    : A specific store
- stores/{name}/users/{user}/_all.txt : View user memories (READ)
- stores/{name}/users/{user}/_add.txt : Add user memories (WRITE)
- stores/{name}/search/{query}.txt    : Semantic search (READ)
"""

HELP_STORES = """# Memory Stores

## Available Operations

1. List all stores:
   ls .

2. Create a new store:
   mkdir {store_name}

3. Delete a store:
   rmdir {store_name}

4. View store details:
   cat {store_name}/_info.json

## Naming Convention
- Use lowercase letters, numbers, and underscores
- Example: my_project_memories, user_preferences
"""

HELP_STORE = """# Memory Store: {store_name}

## Files
- _info.json  : Store configuration (READ-ONLY)
- _add.txt    : Add new memories (WRITE-ONLY, async)

## Directories
- memories/   : Individual memory items (by ID)
- users/      : User-specific memories
- agents/     : Agent-specific memories
- search/     : Semantic search

## Workflow

1. ADD memory (write to _add.txt):
   echo "User prefers dark mode" > _add.txt

2. WAIT for async processing (~30-60 seconds)

3. QUERY memories:
   cat search/preferences.txt
   cat users/default_user/_all.txt

## Important
- _add.txt is write-only: cat _add.txt returns empty
- Newly added memories need 30-60s to be searchable
"""

HELP_MEMORIES = """# Memory Items

This directory contains individual memory items.

## Operations

1. List all memory IDs:
   ls .

2. Read a specific memory:
   cat {memory_id}.json

3. Delete a memory:
   rm {memory_id}.json

## Memory Format (JSON)
{
  "id": "uuid",
  "memory": "The actual memory content",
  "userId": "user who owns this memory",
  "createdAt": "timestamp",
  "metadata": {...}
}
"""

HELP_USERS = """# User Memories

This directory organizes memories by user_id.

## File Types (per user directory)

- _add.txt  : WRITE-ONLY - Add new memories for this user
- _all.txt  : READ-ONLY  - View all memories for this user

## Workflow

1. ADD memory for a user:
   echo "Alice prefers morning meetings" > alice/_add.txt

2. WAIT ~30-60 seconds for async processing

3. VIEW memories (NOT via _add.txt!):
   cat alice/_all.txt

## Important
- _add.txt is write-only, cat returns empty
- _all.txt is read-only, shows all user memories
- User directories appear after memories are processed
"""

HELP_AGENTS = """# Agent Memories

This directory organizes memories by agent_id.

## Operations

1. List an agent's memories:
   cat {agent_id}/_all.txt

2. Add memory for an agent:
   echo "Agent learned user preference" > {agent_id}/_add.txt

## Example

# Add memory for agent "assistant"
echo "User prefers concise answers" > assistant/_add.txt

# View agent's memories
cat assistant/_all.txt
"""

HELP_SEARCH = """# Semantic Search

Search memories using natural language queries.

## Usage

cat {query}.txt

The query is the filename (without .txt extension).

## Examples

# Search for coffee-related memories
cat coffee.txt

# Search for user preferences
cat "user preferences".txt

## Output Format

# Search results: {query}
# Found N matches

[memory_id] (score:0.XX) (user_id) Memory content

## Tips
- Queries are semantic, not keyword-based
- Results are sorted by relevance (score)
- Higher score = more relevant
"""

HELP_USER_DIR = """# User: {user_id}

## Files
- _all.txt  : READ-ONLY  - All memories for this user
- _add.txt  : WRITE-ONLY - Add new memories (async processing)

## Workflow

1. ADD a memory:
   echo "User mentioned they like hiking" > _add.txt

2. WAIT ~30-60 seconds for processing

3. VIEW memories (use _all.txt, NOT _add.txt):
   cat _all.txt

## Input Formats

Plain text:
  echo "User likes hiking" > _add.txt

Conversation (JSON array):
  echo '[{"role":"user","content":"I love hiking"},{"role":"assistant","content":"Great!"}]' > _add.txt

## Important
- Do NOT cat _add.txt - it is write-only and always empty
- Use cat _all.txt to view memories after processing
- New memories take 30-60 seconds to appear
"""
