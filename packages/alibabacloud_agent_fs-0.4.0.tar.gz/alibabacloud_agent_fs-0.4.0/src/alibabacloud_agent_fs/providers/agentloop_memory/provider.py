"""
AgentLoop Memory Provider

Handles paths under /agentloop-memory/ in the virtual filesystem.
Paths received here have the /agentloop-memory prefix already stripped by the dispatcher.

Directory structure (relative paths):
/
├── _help.txt
└── stores/
    ├── _help.txt
    └── {store}/
        ├── _info.json
        ├── _add.txt
        ├── _help.txt
        ├── memories/
        │   ├── _help.txt
        │   └── {id}.json
        ├── users/
        │   ├── _help.txt
        │   └── {user_id}/
        │       ├── _all.txt
        │       └── _add.txt
        ├── agents/
        │   ├── _help.txt
        │   └── {agent_id}/
        │       ├── _all.txt
        │       └── _add.txt
        └── search/
            ├── _help.txt
            └── {query}.txt
"""

import os
import json
import time
import errno
import logging
from typing import Dict, List, Any, Optional
from stat import S_IFDIR, S_IFREG

from fuse import FuseOSError

from .client import AgentLoopMemoryClient
from .help_docs import (
    HELP_MEMORY_ROOT, HELP_STORES, HELP_STORE, HELP_MEMORIES,
    HELP_USERS, HELP_AGENTS, HELP_SEARCH, HELP_USER_DIR,
)
from ..base import BaseProvider

logger = logging.getLogger('alibabacloud-agent-fs.memory')

_CACHE_MISS = object()


class MemoryProvider(BaseProvider):
    """
    FUSE provider for CMS AgentLoop Memory API.
    Receives paths relative to /agentloop-memory/ (the /agentloop-memory prefix is stripped by the dispatcher).
    """

    STORE_LIST_TTL = 5.0
    CONTENT_TTL = 5.0

    def __init__(self, client: AgentLoopMemoryClient):
        self.client = client
        self.fd_counter = 0
        self._recycled_fds = []
        self.fd_info = {}
        self.read_cache = {}
        self.write_buffer = {}
        self._api_cache = {}

    # ========== Cache helpers ==========

    def _cache_get(self, key: str):
        entry = self._api_cache.get(key)
        if entry is not None:
            value, expire = entry
            if time.monotonic() < expire:
                return value
            del self._api_cache[key]
        return _CACHE_MISS

    def _cache_set(self, key: str, value, ttl: float = None):
        self._api_cache[key] = (value, time.monotonic() + (ttl or self.CONTENT_TTL))

    def _cache_invalidate(self, prefix: str = None):
        if prefix is None:
            self._api_cache.clear()
        else:
            for k in [k for k in self._api_cache if k.startswith(prefix)]:
                del self._api_cache[k]

    def _next_fd(self) -> int:
        if self._recycled_fds:
            return self._recycled_fds.pop()
        self.fd_counter += 1
        return self.fd_counter

    def _parse_path(self, path: str) -> Dict[str, Any]:
        """Parse path into structured type + context dict."""
        parts = [p for p in path.split('/') if p]

        result = {
            'type': 'unknown',
            'store': None,
            'user_id': None,
            'agent_id': None,
            'memory_id': None,
            'query': None,
        }

        n = len(parts)

        if n == 0:
            result['type'] = 'root'
        elif parts[0] == '_help.txt':
            result['type'] = 'root_help'
        elif parts[0] == 'stores':
            if n == 1:
                result['type'] = 'stores_dir'
            elif n == 2:
                if parts[1] == '_help.txt':
                    result['type'] = 'stores_help'
                else:
                    result['type'] = 'store'
                    result['store'] = parts[1]
            elif n >= 3:
                result['store'] = parts[1]
                subdir = parts[2]

                if subdir == '_info.json':
                    result['type'] = 'store_info'
                elif subdir == '_add.txt':
                    result['type'] = 'store_add'
                elif subdir == '_help.txt':
                    result['type'] = 'store_help'
                elif subdir == 'memories':
                    if n == 3:
                        result['type'] = 'memories_dir'
                    elif n == 4:
                        if parts[3] == '_help.txt':
                            result['type'] = 'memories_help'
                        elif parts[3].endswith('.json'):
                            result['type'] = 'memory_item'
                            result['memory_id'] = parts[3][:-5]
                elif subdir == 'users':
                    if n == 3:
                        result['type'] = 'users_dir'
                    elif n == 4:
                        if parts[3] == '_help.txt':
                            result['type'] = 'users_help'
                        else:
                            result['type'] = 'user_dir'
                            result['user_id'] = parts[3]
                    elif n == 5:
                        result['user_id'] = parts[3]
                        if parts[4] == '_all.txt':
                            result['type'] = 'user_all'
                        elif parts[4] == '_add.txt':
                            result['type'] = 'user_add'
                        elif parts[4] == '_help.txt':
                            result['type'] = 'user_help'
                elif subdir == 'agents':
                    if n == 3:
                        result['type'] = 'agents_dir'
                    elif n == 4:
                        if parts[3] == '_help.txt':
                            result['type'] = 'agents_help'
                        else:
                            result['type'] = 'agent_dir'
                            result['agent_id'] = parts[3]
                    elif n == 5:
                        result['agent_id'] = parts[3]
                        if parts[4] == '_all.txt':
                            result['type'] = 'agent_all'
                        elif parts[4] == '_add.txt':
                            result['type'] = 'agent_add'
                        elif parts[4] == '_help.txt':
                            result['type'] = 'agent_help'
                elif subdir == 'search':
                    if n == 3:
                        result['type'] = 'search_dir'
                    elif n == 4:
                        if parts[3] == '_help.txt':
                            result['type'] = 'search_help'
                        else:
                            result['type'] = 'search_query'
                            q = parts[3]
                            if q.endswith('.txt'):
                                q = q[:-4]
                            result['query'] = q

        return result

    def _make_stat(self, is_dir: bool, size: int = 0) -> Dict:
        now = int(time.time())
        if is_dir:
            return {
                'st_mode': S_IFDIR | 0o755,
                'st_nlink': 2,
                'st_size': 4096,
                'st_atime': now, 'st_mtime': now, 'st_ctime': now,
                'st_uid': os.getuid(), 'st_gid': os.getgid(),
            }
        return {
            'st_mode': S_IFREG | 0o644,
            'st_nlink': 1,
            'st_size': size or 4096,
            'st_atime': now, 'st_mtime': now, 'st_ctime': now,
            'st_uid': os.getuid(), 'st_gid': os.getgid(),
        }

    def _get_store_names(self) -> set:
        names = self._cache_get('stores:names')
        if names is _CACHE_MISS:
            stores = self.client.list_memory_stores()
            names = {s.get('memoryStoreName') for s in stores if s.get('memoryStoreName')}
            self._cache_set('stores:names', names, self.STORE_LIST_TTL)
        return names

    def _store_exists(self, store_name: str) -> bool:
        return store_name in self._get_store_names()

    def _get_help_content(self, ptype: str, info: Dict) -> Optional[str]:
        help_map = {
            'root_help': HELP_MEMORY_ROOT,
            'stores_help': HELP_STORES,
            'store_help': HELP_STORE.replace('{store_name}', info.get('store') or ''),
            'memories_help': HELP_MEMORIES,
            'users_help': HELP_USERS,
            'agents_help': HELP_AGENTS,
            'search_help': HELP_SEARCH,
            'user_help': HELP_USER_DIR.replace('{user_id}', info.get('user_id') or ''),
            'agent_help': HELP_USER_DIR.replace('{user_id}', info.get('agent_id') or ''),
        }
        return help_map.get(ptype)

    def _format_memory(self, m: Dict) -> str:
        mem_id = m.get('id', 'unknown')
        content = m.get('memory', '')
        user = m.get('userId', '')
        score = m.get('score', 0)
        if score:
            return f"[{mem_id}] (score:{score:.2f}) ({user}) {content}"
        return f"[{mem_id}] ({user}) {content}"

    def _parse_input(self, content: str) -> List[Dict]:
        content = content.strip()
        if not content:
            return []

        if content.startswith('['):
            try:
                data = json.loads(content)
                if isinstance(data, list):
                    return data
            except (json.JSONDecodeError, ValueError, TypeError):
                pass

        if content.startswith('{'):
            try:
                data = json.loads(content)
                if isinstance(data, dict):
                    return [data]
            except (json.JSONDecodeError, ValueError, TypeError):
                pass

        return [{'role': 'user', 'content': content}]

    def _get_content(self, path: str, info: Dict) -> Optional[bytes]:
        cache_key = f'content:{path}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        ptype = info['type']
        content = None

        if ptype == 'store_info':
            data = self.client.get_memory_store(info['store'])
            content = json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8') if data else b'{}'

        elif ptype in ('user_all', 'agent_all'):
            memories = self.client.get_memories(
                store_name=info['store'],
                user_id=info.get('user_id'), agent_id=info.get('agent_id'),
                page_size=100,
            )
            if memories:
                lines = [self._format_memory(m) for m in memories]
                content = '\n'.join(lines).encode('utf-8')
            else:
                content = b'# No memories found\n'

        elif ptype == 'search_query':
            query = info.get('query', '')
            if query:
                memories = self.client.search_memories(
                    store_name=info['store'], query=query, top_k=20,
                )
                if memories:
                    lines = [
                        f"# Search results: {query}",
                        f"# Found {len(memories)} matches",
                        "",
                    ]
                    for m in memories:
                        lines.append(self._format_memory(m))
                    content = '\n'.join(lines).encode('utf-8')
                else:
                    content = f'# No memories found for: {query}\n'.encode('utf-8')
            else:
                content = HELP_SEARCH.encode('utf-8')

        elif ptype == 'memory_item':
            data = self.client.get_memory(info['store'], info['memory_id'])
            if data:
                content = json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8')

        if content is not None:
            self._cache_set(cache_key, content)
        return content

    # ========== BaseProvider interface ==========

    def getattr(self, path: str, fh=None) -> Dict:
        info = self._parse_path(path)
        ptype = info['type']

        dir_types = {
            'root', 'stores_dir', 'store',
            'memories_dir', 'users_dir', 'user_dir',
            'agents_dir', 'agent_dir', 'search_dir'
        }

        if ptype in dir_types:
            if info['store'] and not self._store_exists(info['store']):
                raise FuseOSError(errno.ENOENT)
            return self._make_stat(is_dir=True)

        help_content = self._get_help_content(ptype, info)
        if help_content is not None:
            return self._make_stat(is_dir=False, size=len(help_content.encode('utf-8')))

        if ptype in ('store_add', 'user_add', 'agent_add'):
            return self._make_stat(is_dir=False, size=0)

        dynamic_types = ('store_info', 'user_all', 'agent_all', 'search_query', 'memory_item')
        if ptype in dynamic_types:
            if info['store'] and not self._store_exists(info['store']):
                raise FuseOSError(errno.ENOENT)
            content = self._get_content(path, info)
            if content is not None:
                return self._make_stat(is_dir=False, size=len(content))
            if ptype == 'memory_item':
                raise FuseOSError(errno.ENOENT)
            return self._make_stat(is_dir=False, size=32)

        raise FuseOSError(errno.ENOENT)

    def readdir(self, path: str, fh) -> List[str]:
        info = self._parse_path(path)
        ptype = info['type']

        entries = ['.', '..']

        if ptype == 'root':
            entries.extend(['_help.txt', 'stores'])

        elif ptype == 'stores_dir':
            entries.append('_help.txt')
            entries.extend(sorted(self._get_store_names()))

        elif ptype == 'store':
            entries.extend([
                '_help.txt', '_info.json', '_add.txt',
                'memories', 'users', 'agents', 'search'
            ])

        elif ptype == 'memories_dir':
            entries.append('_help.txt')
            memories = self.client.get_memories(store_name=info['store'], page_size=100)
            for m in memories:
                mem_id = m.get('id')
                if mem_id:
                    entries.append(f"{mem_id}.json")

        elif ptype == 'users_dir':
            entries.append('_help.txt')
            memories = self.client.get_memories(store_name=info['store'], page_size=100)
            user_ids = {m.get('userId') for m in memories if m.get('userId')}
            entries.extend(sorted(user_ids))

        elif ptype == 'user_dir':
            entries.extend(['_help.txt', '_all.txt', '_add.txt'])

        elif ptype == 'agents_dir':
            entries.append('_help.txt')
            memories = self.client.get_memories(store_name=info['store'], page_size=100)
            agent_ids = {m.get('agentId') for m in memories if m.get('agentId')}
            entries.extend(sorted(agent_ids))

        elif ptype == 'agent_dir':
            entries.extend(['_help.txt', '_all.txt', '_add.txt'])

        elif ptype == 'search_dir':
            entries.append('_help.txt')

        return entries

    def open(self, path: str, flags) -> int:
        info = self._parse_path(path)
        ptype = info['type']

        fd = self._next_fd()
        self.fd_info[fd] = info

        help_content = self._get_help_content(ptype, info)
        if help_content is not None:
            self.read_cache[fd] = help_content.encode('utf-8')
        elif ptype in ('store_info', 'user_all', 'agent_all', 'search_query', 'memory_item'):
            content = self._get_content(path, info)
            if content is not None:
                self.read_cache[fd] = content
            elif ptype == 'memory_item':
                self._recycled_fds.append(fd)
                raise FuseOSError(errno.ENOENT)
            else:
                self.read_cache[fd] = b''

        if ptype in ('store_add', 'user_add', 'agent_add'):
            self.write_buffer[fd] = bytearray()

        return fd

    def read(self, path: str, size: int, offset: int, fh: int) -> bytes:
        if fh in self.read_cache:
            data = self.read_cache[fh]
            return data[offset:offset + size]
        return b''

    def write(self, path: str, data: bytes, offset: int, fh: int) -> int:
        if fh in self.write_buffer:
            buf = self.write_buffer[fh]
            if offset > len(buf):
                buf.extend(b'\0' * (offset - len(buf)))
            buf[offset:offset + len(data)] = data
            return len(data)
        raise FuseOSError(errno.EBADF)

    def truncate(self, path: str, length: int, fh=None) -> int:
        if fh is not None and fh in self.write_buffer:
            buf = self.write_buffer[fh]
            if length < len(buf):
                del buf[length:]
            elif length > len(buf):
                buf.extend(b'\0' * (length - len(buf)))
        return 0

    def release(self, path: str, fh: int) -> int:
        info = self.fd_info.get(fh)

        if fh in self.write_buffer:
            content = bytes(self.write_buffer[fh]).decode('utf-8', errors='ignore').strip()

            if content and info:
                ptype = info['type']
                store = info['store']

                if ptype in ('store_add', 'user_add', 'agent_add'):
                    messages = self._parse_input(content)
                    if messages:
                        self.client.add_memories(
                            store_name=store,
                            messages=messages,
                            user_id=info.get('user_id'),
                            agent_id=info.get('agent_id'),
                        )
                        self._cache_invalidate(f'content:/stores/{store}/')

            del self.write_buffer[fh]

        self.read_cache.pop(fh, None)
        self.fd_info.pop(fh, None)
        self._recycled_fds.append(fh)
        return 0

    def create(self, path: str, mode) -> int:
        info = self._parse_path(path)
        ptype = info['type']

        if ptype in ('store_add', 'user_add', 'agent_add'):
            fd = self._next_fd()
            self.fd_info[fd] = info
            self.write_buffer[fd] = bytearray()
            return fd

        raise FuseOSError(errno.EACCES)

    def mkdir(self, path: str, mode) -> int:
        info = self._parse_path(path)

        if info['type'] == 'store' and info['store']:
            store_name = info['store']
            if self._store_exists(store_name):
                raise FuseOSError(errno.EEXIST)
            if self.client.create_memory_store(store_name):
                self._cache_invalidate('stores:')
                return 0
            raise FuseOSError(errno.EIO)

        raise FuseOSError(errno.EACCES)

    def rmdir(self, path: str) -> int:
        info = self._parse_path(path)

        if info['type'] == 'store':
            if self.client.delete_memory_store(info['store']):
                self._cache_invalidate()
                return 0
            raise FuseOSError(errno.EIO)

        raise FuseOSError(errno.EACCES)

    def unlink(self, path: str) -> int:
        info = self._parse_path(path)

        if info['type'] == 'memory_item':
            if self.client.delete_memory(info['store'], info['memory_id']):
                self._cache_invalidate(f'content:/stores/{info["store"]}/')
                return 0
            raise FuseOSError(errno.EIO)

        raise FuseOSError(errno.EACCES)
