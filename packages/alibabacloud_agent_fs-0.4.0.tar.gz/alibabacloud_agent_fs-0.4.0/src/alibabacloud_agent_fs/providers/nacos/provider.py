"""
Nacos Provider for Alibaba Cloud Agent FS.

Handles paths under /nacos/ in the virtual filesystem.
Paths received here have the /nacos prefix already stripped by the dispatcher.

Directory structure (relative paths):
/
├── _help.txt
├── config/
│   ├── _help.txt
│   └── {namespace}/
│       ├── _help.txt
│       └── {group}/
│           ├── _help.txt
│           └── {dataId}               # file: cat=get, echo>=publish, rm=remove
├── services/
│   ├── _help.txt
│   └── {namespace}/
│       ├── _help.txt
│       └── {group}/
│           ├── _help.txt
│           └── {service}/
│               ├── _info.json
│               ├── _help.txt
│               └── instances/
│                   ├── _help.txt
│                   ├── _register.json
│                   └── {ip}:{port}.json
└── skills/
    ├── _help.txt
    └── {namespace}/
        ├── _help.txt
        ├── {skillName}.zip        # WRITE: cp ZIP to upload
        └── {skillName}/
            ├── _help.txt
            ├── _info.json
            ├── SKILL.md
            └── {resource_file}
"""

import os
import io
import json
import time
import errno
import zipfile
import logging
from typing import Dict, List, Any, Optional, Tuple
from stat import S_IFDIR, S_IFREG

from fuse import FuseOSError

from .client import NacosClient
from .help_docs import (
    HELP_NACOS_ROOT, HELP_CONFIG_ROOT, HELP_CONFIG_NS, HELP_CONFIG_GROUP,
    HELP_SERVICES_ROOT, HELP_SERVICES_NS, HELP_SERVICES_GROUP,
    HELP_SERVICE_ITEM, HELP_INSTANCES,
    HELP_SKILLS_ROOT, HELP_SKILLS_NS, HELP_SKILLS_ITEM,
)
from ..base import BaseProvider

logger = logging.getLogger('alibabacloud-agent-fs.nacos')

_CACHE_MISS = object()


class NacosProvider(BaseProvider):
    """
    FUSE provider for Nacos Configuration Center, Service Registry and Skill Registry.
    Receives paths relative to /nacos/ (the /nacos prefix is stripped by the dispatcher).
    """

    CONTENT_TTL = 5.0
    SKILL_ZIP_CACHE_TTL = 30.0

    def __init__(self, client: NacosClient):
        self.client = client
        self.fd_counter = 0
        self._recycled_fds: List[int] = []
        self.fd_info: Dict[int, Dict] = {}
        self.read_cache: Dict[int, bytes] = {}
        self.write_buffer: Dict[int, bytearray] = {}
        self._content_cache: Dict[str, Any] = {}
        # Skill ZIP cache: {"ns:name": ({filename: bytes}, expiry)}
        self._skill_zip_cache: Dict[str, Tuple[Dict[str, bytes], float]] = {}

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _ccache_get(self, key: str):
        entry = self._content_cache.get(key)
        if entry:
            value, expiry = entry
            if time.monotonic() < expiry:
                return value
            del self._content_cache[key]
        return _CACHE_MISS

    def _ccache_set(self, key: str, value, ttl: float = None):
        self._content_cache[key] = (value, time.monotonic() + (ttl or self.CONTENT_TTL))

    def _next_fd(self) -> int:
        if self._recycled_fds:
            return self._recycled_fds.pop()
        self.fd_counter += 1
        return self.fd_counter

    # ------------------------------------------------------------------
    # Path parser
    # ------------------------------------------------------------------

    def _parse_path(self, path: str) -> Dict[str, Any]:
        """
        Parse path into a structured dict with 'type' and contextual fields.

        Returned keys: type, namespace, group, data_id, service, ip, port,
                       skill_name, skill_file
        """
        parts = [p for p in path.split('/') if p]
        n = len(parts)

        result: Dict[str, Any] = {
            'type': 'unknown',
            'namespace': None,
            'group': None,
            'data_id': None,
            'service': None,
            'ip': None,
            'port': None,
            'skill_name': None,
            'skill_file': None,
        }

        if n == 0:
            result['type'] = 'root'
            return result

        if parts[0] == '_help.txt':
            result['type'] = 'root_help'
            return result

        top = parts[0]

        # ---- config subtree ----
        if top == 'config':
            if n == 1:
                result['type'] = 'config_root'
            elif n == 2:
                result['type'] = 'config_root_help' if parts[1] == '_help.txt' else 'config_ns'
                if parts[1] != '_help.txt':
                    result['namespace'] = parts[1]
            elif n == 3:
                result['namespace'] = parts[1]
                if parts[2] == '_help.txt':
                    result['type'] = 'config_ns_help'
                else:
                    result['type'] = 'config_group'
                    result['group'] = parts[2]
            elif n == 4:
                result['namespace'] = parts[1]
                result['group'] = parts[2]
                if parts[3] == '_help.txt':
                    result['type'] = 'config_group_help'
                else:
                    result['type'] = 'config_item'
                    result['data_id'] = parts[3]

        # ---- services subtree ----
        elif top == 'services':
            if n == 1:
                result['type'] = 'services_root'
            elif n == 2:
                result['type'] = 'services_root_help' if parts[1] == '_help.txt' else 'services_ns'
                if parts[1] != '_help.txt':
                    result['namespace'] = parts[1]
            elif n == 3:
                result['namespace'] = parts[1]
                if parts[2] == '_help.txt':
                    result['type'] = 'services_ns_help'
                else:
                    result['type'] = 'services_group'
                    result['group'] = parts[2]
            elif n == 4:
                result['namespace'] = parts[1]
                result['group'] = parts[2]
                if parts[3] == '_help.txt':
                    result['type'] = 'services_group_help'
                else:
                    result['type'] = 'services_item'
                    result['service'] = parts[3]
            elif n == 5:
                result['namespace'] = parts[1]
                result['group'] = parts[2]
                result['service'] = parts[3]
                sub = parts[4]
                if sub == '_info.json':
                    result['type'] = 'services_item_info'
                elif sub == '_help.txt':
                    result['type'] = 'services_item_help'
                elif sub == 'instances':
                    result['type'] = 'services_instances'
            elif n == 6:
                result['namespace'] = parts[1]
                result['group'] = parts[2]
                result['service'] = parts[3]
                if parts[4] == 'instances':
                    fname = parts[5]
                    if fname == '_help.txt':
                        result['type'] = 'services_instances_help'
                    elif fname == '_register.json':
                        result['type'] = 'services_register'
                    elif fname.endswith('.json'):
                        result['type'] = 'services_instance_item'
                        key = fname[:-5]  # strip .json
                        if ':' in key:
                            ip, port_str = key.rsplit(':', 1)
                            result['ip'] = ip
                            result['port'] = int(port_str) if port_str.isdigit() else None

        # ---- skills subtree ----
        elif top == 'skills':
            if n == 1:
                result['type'] = 'skills_root'
            elif n == 2:
                if parts[1] == '_help.txt':
                    result['type'] = 'skills_root_help'
                else:
                    result['type'] = 'skills_ns'
                    result['namespace'] = parts[1]
            elif n == 3:
                result['namespace'] = parts[1]
                name = parts[2]
                if name == '_help.txt':
                    result['type'] = 'skills_ns_help'
                elif name.endswith('.zip'):
                    result['type'] = 'skills_zip_upload'
                    result['skill_name'] = name[:-4]  # strip .zip
                else:
                    result['type'] = 'skills_item'
                    result['skill_name'] = name
            elif n == 4:
                result['namespace'] = parts[1]
                result['skill_name'] = parts[2]
                fname = parts[3]
                if fname == '_help.txt':
                    result['type'] = 'skills_item_help'
                elif fname == '_info.json':
                    result['type'] = 'skills_item_info'
                else:
                    result['type'] = 'skills_item_file'
                    result['skill_file'] = fname

        return result

    # ------------------------------------------------------------------
    # Stat helpers
    # ------------------------------------------------------------------

    def _make_dir_stat(self) -> Dict:
        now = int(time.time())
        return {
            'st_mode': S_IFDIR | 0o755, 'st_nlink': 2, 'st_size': 4096,
            'st_atime': now, 'st_mtime': now, 'st_ctime': now,
            'st_uid': os.getuid(), 'st_gid': os.getgid(),
        }

    def _make_file_stat(self, size: int = 0) -> Dict:
        now = int(time.time())
        return {
            'st_mode': S_IFREG | 0o644, 'st_nlink': 1, 'st_size': size or 4096,
            'st_atime': now, 'st_mtime': now, 'st_ctime': now,
            'st_uid': os.getuid(), 'st_gid': os.getgid(),
        }

    # ------------------------------------------------------------------
    # Help content dispatch
    # ------------------------------------------------------------------

    def _get_help(self, ptype: str, info: Dict) -> Optional[str]:
        ns = info.get('namespace') or ''
        grp = info.get('group') or ''
        svc = info.get('service') or ''
        skl = info.get('skill_name') or ''
        mapping = {
            'root_help': HELP_NACOS_ROOT,
            'config_root_help': HELP_CONFIG_ROOT,
            'config_ns_help': HELP_CONFIG_NS.replace('{namespace}', ns),
            'config_group_help': HELP_CONFIG_GROUP.replace('{group}', grp),
            'services_root_help': HELP_SERVICES_ROOT,
            'services_ns_help': HELP_SERVICES_NS.replace('{namespace}', ns),
            'services_group_help': HELP_SERVICES_GROUP.replace('{group}', grp),
            'services_item_help': HELP_SERVICE_ITEM.replace('{service}', svc),
            'services_instances_help': HELP_INSTANCES,
            'skills_root_help': HELP_SKILLS_ROOT,
            'skills_ns_help': HELP_SKILLS_NS.replace('{namespace}', ns),
            'skills_item_help': HELP_SKILLS_ITEM.replace('{skill}', skl),
        }
        return mapping.get(ptype)

    # ------------------------------------------------------------------
    # Content fetch
    # ------------------------------------------------------------------

    def _get_content(self, path: str, info: Dict) -> Optional[bytes]:
        cache_key = f'content:{path}'
        cached = self._ccache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        ptype = info['type']
        content: Optional[bytes] = None

        if ptype == 'config_item':
            raw = self.client.get_config(info['namespace'], info['group'], info['data_id'])
            if raw is not None:
                content = raw.encode('utf-8') if isinstance(raw, str) else raw

        elif ptype == 'services_item_info':
            data = self.client.get_service(info['namespace'], info['group'], info['service'])
            if data:
                content = json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8')

        elif ptype == 'services_instance_item':
            instances = self.client.list_instances(
                info['namespace'], info['group'], info['service']
            )
            target_ip = info.get('ip')
            target_port = info.get('port')
            for inst in instances:
                if inst.get('ip') == target_ip and inst.get('port') == target_port:
                    content = json.dumps(inst, indent=2, ensure_ascii=False).encode('utf-8')
                    break

        if content is not None:
            self._ccache_set(cache_key, content)
        return content

    # ------------------------------------------------------------------
    # Skill helpers
    # ------------------------------------------------------------------

    def _get_skill_names(self, namespace: str) -> List[str]:
        """Return skill names for a namespace (from list API)."""
        skills = self.client.list_skills(namespace)
        return [s.get('name') for s in skills if s.get('name')]

    def _get_skill_info_json(self, namespace: str, skill_name: str) -> Optional[bytes]:
        """Return skill metadata as JSON bytes from the list cache."""
        skills = self.client.list_skills(namespace)
        for s in skills:
            if s.get('name') == skill_name:
                return json.dumps(s, indent=2, ensure_ascii=False).encode('utf-8')
        return None

    def _get_skill_files(self, namespace: str, skill_name: str) -> Dict[str, bytes]:
        """Download skill ZIP, extract in memory, return {relative_path: content} mapping."""
        cache_key = f'{namespace}:{skill_name}'
        entry = self._skill_zip_cache.get(cache_key)
        if entry:
            files_map, expiry = entry
            if time.monotonic() < expiry:
                return files_map
            del self._skill_zip_cache[cache_key]

        zip_bytes = self.client.get_skill_zip(namespace, skill_name)
        if not zip_bytes:
            return {}

        files_map: Dict[str, bytes] = {}
        try:
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                for entry_name in zf.namelist():
                    if entry_name.endswith('/'):
                        continue  # skip directories
                    # ZIP entries are like "skillName/SKILL.md" — strip first component
                    parts = entry_name.split('/', 1)
                    rel_name = parts[1] if len(parts) > 1 else parts[0]
                    if not rel_name:
                        continue
                    files_map[rel_name] = zf.read(entry_name)
        except zipfile.BadZipFile:
            logger.error(f"Invalid ZIP for skill {skill_name}")
            return {}

        self._skill_zip_cache[cache_key] = (files_map, time.monotonic() + self.SKILL_ZIP_CACHE_TTL)
        return files_map

    @staticmethod
    def _zip_from_dict(skill_name: str, files: Dict[str, bytes]) -> bytes:
        """Pack a {filename: content} dict into ZIP bytes with skillName/ prefix."""
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
            for fname, content in files.items():
                zf.writestr(f'{skill_name}/{fname}', content)
        return buf.getvalue()

    # ------------------------------------------------------------------
    # BaseProvider interface
    # ------------------------------------------------------------------

    def getattr(self, path: str, fh=None) -> Dict:
        info = self._parse_path(path)
        ptype = info['type']

        dir_types = {
            'root', 'config_root', 'config_ns', 'config_group',
            'services_root', 'services_ns', 'services_group',
            'services_item', 'services_instances',
            'skills_root', 'skills_ns', 'skills_item',
        }
        if ptype in dir_types:
            return self._make_dir_stat()

        help_text = self._get_help(ptype, info)
        if help_text is not None:
            return self._make_file_stat(size=len(help_text.encode('utf-8')))

        # Write-only files
        if ptype in ('services_register', 'skills_zip_upload'):
            return self._make_file_stat(size=0)

        # Dynamic file content (config / services)
        if ptype in ('config_item', 'services_item_info', 'services_instance_item'):
            content = self._get_content(path, info)
            if content is not None:
                return self._make_file_stat(size=len(content))
            if ptype == 'config_item':
                # Config items can be created fresh; report as zero-byte writable
                return self._make_file_stat(size=0)
            raise FuseOSError(errno.ENOENT)

        # Skill info
        if ptype == 'skills_item_info':
            data = self._get_skill_info_json(info['namespace'], info['skill_name'])
            if data is not None:
                return self._make_file_stat(size=len(data))
            raise FuseOSError(errno.ENOENT)

        # Skill file (SKILL.md or other) — read-only
        if ptype == 'skills_item_file':
            ns, name, fname = info['namespace'], info['skill_name'], info['skill_file']
            files = self._get_skill_files(ns, name)
            if fname in files:
                return self._make_file_stat(size=len(files[fname]))
            raise FuseOSError(errno.ENOENT)

        raise FuseOSError(errno.ENOENT)

    def readdir(self, path: str, fh) -> List[str]:
        info = self._parse_path(path)
        ptype = info['type']
        entries = ['.', '..']

        if ptype == 'root':
            entries.extend(['_help.txt', 'config', 'services', 'skills'])

        elif ptype == 'config_root':
            entries.append('_help.txt')
            entries.extend(self.client.list_namespace_ids())

        elif ptype == 'config_ns':
            entries.append('_help.txt')
            entries.extend(self.client.list_config_groups(info['namespace']))

        elif ptype == 'config_group':
            entries.append('_help.txt')
            entries.extend(self.client.list_configs(info['namespace'], info['group']))

        elif ptype == 'services_root':
            entries.append('_help.txt')
            entries.extend(self.client.list_namespace_ids())

        elif ptype == 'services_ns':
            entries.append('_help.txt')
            entries.extend(self.client.list_service_groups(info['namespace']))

        elif ptype == 'services_group':
            entries.append('_help.txt')
            entries.extend(self.client.list_services(info['namespace'], info['group']))

        elif ptype == 'services_item':
            entries.extend(['_help.txt', '_info.json', 'instances'])

        elif ptype == 'services_instances':
            entries.extend(['_help.txt', '_register.json'])
            instances = self.client.list_instances(
                info['namespace'], info['group'], info['service']
            )
            for inst in instances:
                ip = inst.get('ip', '')
                port = inst.get('port', '')
                if ip and port:
                    entries.append(f"{ip}:{port}.json")

        elif ptype == 'skills_root':
            entries.append('_help.txt')
            entries.extend(self.client.list_namespace_ids())

        elif ptype == 'skills_ns':
            entries.append('_help.txt')
            entries.extend(sorted(self._get_skill_names(info['namespace'])))

        elif ptype == 'skills_item':
            entries.append('_help.txt')
            entries.append('_info.json')
            ns, name = info['namespace'], info['skill_name']
            files = self._get_skill_files(ns, name)
            entries.extend(sorted(files.keys()))

        return entries

    def open(self, path: str, flags) -> int:
        info = self._parse_path(path)
        ptype = info['type']

        fd = self._next_fd()
        self.fd_info[fd] = info

        help_text = self._get_help(ptype, info)
        if help_text is not None:
            self.read_cache[fd] = help_text.encode('utf-8')
            return fd

        if ptype in ('config_item', 'services_item_info', 'services_instance_item'):
            content = self._get_content(path, info)
            self.read_cache[fd] = content if content is not None else b''

        # Write-capable files (config / services)
        if ptype in ('config_item', 'services_register'):
            self.write_buffer[fd] = bytearray()

        # Skill info (read-only)
        if ptype == 'skills_item_info':
            data = self._get_skill_info_json(info['namespace'], info['skill_name'])
            self.read_cache[fd] = data if data is not None else b'{}'

        # Skill file (read-only)
        if ptype == 'skills_item_file':
            ns, name, fname = info['namespace'], info['skill_name'], info['skill_file']
            files = self._get_skill_files(ns, name)
            self.read_cache[fd] = files.get(fname, b'')

        # ZIP upload (write-only)
        if ptype == 'skills_zip_upload':
            self.write_buffer[fd] = bytearray()

        return fd

    def read(self, path: str, size: int, offset: int, fh: int) -> bytes:
        data = self.read_cache.get(fh, b'')
        return data[offset:offset + size]

    def write(self, path: str, data: bytes, offset: int, fh: int) -> int:
        if fh in self.write_buffer:
            buf = self.write_buffer[fh]
            if offset > len(buf):
                buf.extend(b'\0' * (offset - len(buf)))
            buf[offset:offset + len(data)] = data
            return len(data)
        raise FuseOSError(errno.EBADF)

    def truncate(self, path: str, length: int, fh=None) -> int:
        if fh is not None and fh in self.write_buffer:
            buf = self.write_buffer[fh]
            if length < len(buf):
                del buf[length:]
            elif length > len(buf):
                buf.extend(b'\0' * (length - len(buf)))
        return 0

    def release(self, path: str, fh: int) -> int:
        info = self.fd_info.get(fh)

        if fh in self.write_buffer and info:
            ptype = info.get('type')
            raw_bytes = bytes(self.write_buffer[fh])

            if ptype == 'skills_zip_upload':
                # Upload ZIP directly (binary data)
                if raw_bytes:
                    ns = info['namespace']
                    name = info['skill_name']
                    ok = self.client.upload_skill_zip(ns, raw_bytes, f'{name}.zip')
                    if ok:
                        logger.info(f"Skill ZIP '{name}.zip' uploaded")
                        self._skill_zip_cache.pop(f'{ns}:{name}', None)
                    else:
                        logger.error(f"Skill ZIP '{name}.zip' upload failed")
            else:
                # Config / services: decode as text
                raw = raw_bytes.decode('utf-8', errors='ignore').strip()
                if raw:
                    self._flush_write(path, info, raw)

            del self.write_buffer[fh]

        self.read_cache.pop(fh, None)
        self.fd_info.pop(fh, None)
        self._recycled_fds.append(fh)
        return 0

    def _flush_write(self, path: str, info: Dict, raw: str):
        """Commit buffered write content to Nacos."""
        ptype = info['type']

        if ptype == 'config_item':
            ok = self.client.publish_config(
                info['namespace'], info['group'], info['data_id'], raw
            )
            if ok:
                cache_key = f'content:{path}'
                self._content_cache.pop(cache_key, None)

        elif ptype == 'services_register':
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                logger.error(f"_register.json: invalid JSON: {raw!r}")
                return

            action = payload.get('action', 'register').lower()
            ip = payload.get('ip')
            port = payload.get('port')
            if not ip or not port:
                logger.error(f"_register.json: 'ip' and 'port' are required")
                return

            ns = info['namespace']
            grp = info['group']
            svc = info['service']

            if action == 'register':
                self.client.register_instance(
                    namespace=ns, group=grp, service_name=svc,
                    ip=ip, port=int(port),
                    weight=float(payload.get('weight', 1.0)),
                    metadata=payload.get('metadata'),
                    cluster=payload.get('cluster', 'DEFAULT'),
                    ephemeral=bool(payload.get('ephemeral', True)),
                )
            elif action == 'deregister':
                self.client.deregister_instance(
                    namespace=ns, group=grp, service_name=svc,
                    ip=ip, port=int(port),
                    cluster=payload.get('cluster', 'DEFAULT'),
                    ephemeral=bool(payload.get('ephemeral', True)),
                )
            else:
                logger.error(f"_register.json: unknown action '{action}'")

    def create(self, path: str, mode) -> int:
        """Allow creating new config files and skill files."""
        info = self._parse_path(path)
        ptype = info['type']

        if ptype in ('config_item', 'skills_zip_upload'):
            fd = self._next_fd()
            self.fd_info[fd] = info
            self.write_buffer[fd] = bytearray()
            self.read_cache[fd] = b''
            return fd

        raise FuseOSError(errno.EACCES)

    def unlink(self, path: str) -> int:
        """Allow deleting config items."""
        info = self._parse_path(path)

        if info['type'] == 'config_item':
            ok = self.client.remove_config(
                info['namespace'], info['group'], info['data_id']
            )
            if ok:
                cache_key = f'content:{path}'
                self._content_cache.pop(cache_key, None)
                return 0
            raise FuseOSError(errno.EIO)

        raise FuseOSError(errno.EACCES)
