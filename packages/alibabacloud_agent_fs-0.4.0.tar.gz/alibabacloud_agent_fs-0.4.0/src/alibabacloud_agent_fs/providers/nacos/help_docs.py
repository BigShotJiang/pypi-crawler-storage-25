"""
Help documentation for the Nacos provider.
"""

HELP_NACOS_ROOT = """# Nacos - Configuration, Service Discovery & Skills

This subtree provides access to Alibaba Cloud Nacos via standard shell commands.

## Subtrees

- config/     : Nacos Configuration Center (read, write, delete configs)
- services/   : Nacos Service Registry (browse services and instances)
- skills/     : Nacos Skill Registry (browse, download, publish skills)

## Quick Start

# List namespaces
ls config/
ls services/
ls skills/

# Read a config
cat config/public/DEFAULT_GROUP/application.properties

# Write / update a config
echo "server.port=8080" > config/public/DEFAULT_GROUP/application.properties

# List services in a namespace/group
ls services/public/DEFAULT_GROUP/

# View service details
cat services/public/DEFAULT_GROUP/my-service/_info.json

# List skills
ls skills/public/

# Read a skill
cat skills/public/my-skill/SKILL.md

# Upload a skill (ZIP or directory)
cp my-skill.zip skills/public/my-skill.zip
cp -r my-skill/ skills/public/my-skill/
"""

HELP_CONFIG_ROOT = """# Nacos Config Root

Directories here represent Nacos namespaces (e.g. public, dev, prod).

## Usage

# List all namespaces
ls .

# Enter a namespace
ls public/

# Common namespaces:
# public         - default namespace (namespace id = "")
# <uuid>         - custom namespace id
"""

HELP_CONFIG_NS = """# Nacos Config Namespace: {namespace}

Directories here represent config groups within this namespace.

## Usage

# List groups
ls .

# Read a config
cat DEFAULT_GROUP/my-app.yaml

# Write a config
echo "key=value" > DEFAULT_GROUP/my-app.properties

# Delete a config
rm DEFAULT_GROUP/old-config.properties
"""

HELP_CONFIG_GROUP = """# Nacos Config Group: {group}

Files here are individual config items (dataIds).

## Operations

# List configs
ls .

# Read config
cat my-service.properties

# Create or update config
echo "timeout=3000" > my-service.properties

# Delete config
rm my-service.properties

## Notes
- File content is stored as-is (plain text, YAML, JSON, TOML, etc.)
- Changes take effect immediately on the Nacos server
- No extension required; use any name as the dataId
"""

HELP_SERVICES_ROOT = """# Nacos Service Registry Root

Directories here represent Nacos namespaces.

## Usage

# List namespaces
ls .

# Browse services in a namespace
ls public/DEFAULT_GROUP/
"""

HELP_SERVICES_NS = """# Nacos Services Namespace: {namespace}

Directories here represent service groups within this namespace.

## Usage

ls .                    # List groups
ls DEFAULT_GROUP/       # List services in a group
"""

HELP_SERVICES_GROUP = """# Nacos Services Group: {group}

Directories here represent registered services.

## Usage

# List all services
ls .

# View service info
cat my-service/_info.json

# List service instances
ls my-service/instances/
"""

HELP_SERVICE_ITEM = """# Nacos Service: {service}

## Files
- _info.json     : Service metadata (READ-ONLY)

## Directories
- instances/     : Registered instances

## Usage

cat _info.json                    # Service details (clusters, protectThreshold, etc.)
ls instances/                     # All registered instances
cat instances/10.0.0.1:8080.json  # Instance details
"""

HELP_INSTANCES = """# Service Instances

Each file represents one registered instance: {ip}:{port}.json

## Operations

# List instances
ls .

# View instance details
cat 10.0.0.1:8080.json

# Register a new instance (write JSON to _register.json)
echo '{"action":"register","ip":"10.0.0.2","port":8080}' > _register.json

# Deregister an instance
echo '{"action":"deregister","ip":"10.0.0.2","port":8080}' > _register.json

## _register.json format

Register:
  {"action": "register", "ip": "10.0.0.2", "port": 8080,
   "weight": 1.0, "cluster": "DEFAULT", "ephemeral": true,
   "metadata": {"version": "1.0"}}

Deregister:
  {"action": "deregister", "ip": "10.0.0.2", "port": 8080}
"""

# ------------------------------------------------------------------
# Skill help docs
# ------------------------------------------------------------------

HELP_SKILLS_ROOT = """# Nacos Skill Registry

Browse, download, and publish AI agent skills stored in Nacos.

Directories here represent Nacos namespaces.

## Browse

# List namespaces
ls .

# List skills in a namespace
ls public/

# Read a skill
cat public/my-skill/SKILL.md

# View skill metadata
cat public/my-skill/_info.json

## Upload / Publish

# Upload a ZIP file
cp my-skill.zip public/my-skill.zip

# Upload a directory (all files are packed and uploaded)
cp -r my-skill/ public/my-skill/

# Write a single SKILL.md
echo '---\nname: my-skill\n---\nContent...' > public/my-skill/SKILL.md
"""

HELP_SKILLS_NS = """# Nacos Skills Namespace: {namespace}

Directories here represent published skills.

## Browse

# List all skills
ls .

# Read a skill's main file
cat my-skill/SKILL.md

# View skill metadata
cat my-skill/_info.json

# List all files in a skill
ls my-skill/

## Upload

# Upload a ZIP
cp my-skill.zip ./my-skill.zip

# Upload a directory
cp -r /path/to/my-skill/ ./my-skill/
"""

HELP_SKILLS_ITEM = """# Nacos Skill: {skill}

## Files
- SKILL.md      : Main skill definition file
- _info.json    : Skill metadata (name, description) (READ-ONLY)
- Other files   : Resource files bundled with the skill

## Usage

# Read skill content
cat SKILL.md

# Read skill metadata
cat _info.json

# List all files
ls .

# Overwrite skill content (triggers re-publish)
echo 'new content' > SKILL.md
"""
