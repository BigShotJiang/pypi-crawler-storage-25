"""Nacos Config & Service Discovery provider."""
