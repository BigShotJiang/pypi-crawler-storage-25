"""
Nacos Client for Alibaba Cloud Agent FS.

Implements two access strategies:
1. HTTP API (urllib, stdlib only) - used for all listing and basic CRUD operations.
   Synchronous, supports all namespaces, no extra dependencies.
2. nacos-sdk-python (optional, async→sync bridged) - used when the SDK is available
   for advanced features such as gRPC-based config push/subscribe.

For FUSE integration we always prefer the synchronous HTTP path.
"""

import json
import time
import hmac
import hashlib
import base64
import logging
import threading
import urllib.request
import urllib.parse
import urllib.error
from typing import Dict, List, Optional, Any

logger = logging.getLogger('alibabacloud-agent-fs.nacos')

_RETRY_MAX = 2
_RETRY_BACKOFF = 0.5
_CACHE_MISS = object()


class NacosClient:
    """
    Synchronous Nacos client backed by the Nacos HTTP Open API.

    Supports:
    - Namespace listing
    - Config CRUD (get / publish / remove) and group/dataId listing
    - Service listing, instance listing, service detail
    - Instance registration and deregistration

    Authentication:
    - Username / password (self-hosted Nacos): login once to get an access token
      that is cached and renewed automatically.
    - access_key / secret_key (Alibaba Cloud MSE): SPAS HMAC-SHA1 signature
      sent via HTTP headers (Spas-AccessKey, Spas-Signature, timeStamp).
    """

    CONFIG_LIST_TTL = 10.0
    SERVICE_LIST_TTL = 10.0
    NS_LIST_TTL = 30.0

    def __init__(
        self,
        server_addr: str,
        namespace: str = 'public',
        username: str = None,
        password: str = None,
        access_key: str = None,
        secret_key: str = None,
        use_tls: bool = False,
    ):
        # Normalise server_addr: strip trailing slash, ensure no scheme prefix
        addr = server_addr.strip().rstrip('/')
        if addr.startswith(('http://', 'https://')):
            scheme, addr = addr.split('://', 1)
            use_tls = (scheme == 'https')
        self._server_addr = addr
        self._namespace = namespace
        self._username = username
        self._password = password
        self._access_key = access_key
        self._secret_key = secret_key
        self._scheme = 'https' if use_tls else 'http'

        # Auth token (username/password flow)
        self._token: Optional[str] = None
        self._token_expiry: float = 0.0
        self._token_lock = threading.Lock()

        # Simple in-process cache {key: (value, expiry_monotonic)}
        self._cache: Dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _base(self) -> str:
        return f"{self._scheme}://{self._server_addr}"

    def _get_token(self) -> Optional[str]:
        """Return a valid access token, refreshing if needed."""
        if not self._username or not self._password:
            return None
        with self._token_lock:
            if self._token and time.time() < self._token_expiry:
                return self._token
            try:
                data = urllib.parse.urlencode({
                    'username': self._username,
                    'password': self._password,
                }).encode('utf-8')
                url = f"{self._base}/nacos/v1/auth/users/login"
                req = urllib.request.Request(url, data=data, method='POST')
                with urllib.request.urlopen(req, timeout=10) as resp:
                    result = json.loads(resp.read().decode('utf-8'))
                    self._token = result.get('accessToken')
                    ttl = result.get('tokenTtl', 18000)
                    self._token_expiry = time.time() + ttl - 60
                    return self._token
            except Exception as e:
                logger.warning(f"Nacos login failed: {e}")
                return None

    def _auth_params(self) -> Dict[str, str]:
        """Build auth query parameters (token-based only, no AK/SK)."""
        params: Dict[str, str] = {}
        token = self._get_token()
        if token:
            params['accessToken'] = token
        return params

    def _spas_headers(self, tenant: str = '', group: str = '') -> Dict[str, str]:
        """Build SPAS HMAC-SHA1 signature headers for AK/SK authentication.

        Sign data format (following Nacos SPAS spec):
          tenant+group+ts  |  tenant+ts  |  group+ts  |  ts
        """
        if not self._access_key or not self._secret_key:
            return {}
        ts = str(int(time.time() * 1000))
        # Build sign payload
        if tenant:
            sign_str = f'{tenant}+{group}+{ts}' if group else f'{tenant}+{ts}'
        else:
            sign_str = f'{group}+{ts}' if group else ts
        signature = base64.b64encode(
            hmac.new(self._secret_key.encode(), sign_str.encode(),
                     digestmod=hashlib.sha1).digest()
        ).decode()
        return {
            'timeStamp': ts,
            'Spas-AccessKey': self._access_key,
            'Spas-Signature': signature,
        }

    def _apply_auth_headers(self, req: urllib.request.Request,
                            tenant: str = '', group: str = ''):
        """Apply authentication headers to a request (SPAS or Bearer)."""
        for k, v in self._spas_headers(tenant, group).items():
            req.add_header(k, v)
        token = self._get_token()
        if token:
            req.add_header('Authorization', f'Bearer {token}')

    def _get(self, path: str, params: Dict = None,
             tenant: str = '', group: str = '') -> Any:
        """GET request, returns parsed JSON or raw text."""
        all_params = dict(self._auth_params())
        if params:
            all_params.update(params)
        url = f"{self._base}{path}"
        if all_params:
            url += '?' + urllib.parse.urlencode(all_params)
        req = urllib.request.Request(url)
        self._apply_auth_headers(req, tenant, group)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = resp.read().decode('utf-8')
                try:
                    return json.loads(body)
                except json.JSONDecodeError:
                    return body
        except urllib.error.HTTPError:
            raise
        except Exception:
            raise

    def _post(self, path: str, data: Dict,
              tenant: str = '', group: str = '') -> str:
        """POST request with form-encoded body, returns raw text."""
        all_data = dict(data)
        all_data.update(self._auth_params())
        encoded = urllib.parse.urlencode(all_data).encode('utf-8')
        url = f"{self._base}{path}"
        req = urllib.request.Request(url, data=encoded, method='POST')
        self._apply_auth_headers(req, tenant, group)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode('utf-8')

    def _delete(self, path: str, params: Dict = None,
                tenant: str = '', group: str = '') -> str:
        """DELETE request, returns raw text."""
        all_params = dict(self._auth_params())
        if params:
            all_params.update(params)
        url = f"{self._base}{path}"
        if all_params:
            url += '?' + urllib.parse.urlencode(all_params)
        req = urllib.request.Request(url, method='DELETE')
        self._apply_auth_headers(req, tenant, group)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode('utf-8')

    def _cache_get(self, key: str):
        entry = self._cache.get(key)
        if entry:
            value, expiry = entry
            if time.monotonic() < expiry:
                return value
            del self._cache[key]
        return _CACHE_MISS

    def _cache_set(self, key: str, value, ttl: float):
        self._cache[key] = (value, time.monotonic() + ttl)

    def _cache_invalidate(self, prefix: str = None):
        if prefix is None:
            self._cache.clear()
        else:
            for k in list(self._cache.keys()):
                if k.startswith(prefix):
                    del self._cache[k]

    # ------------------------------------------------------------------
    # Namespace API
    # ------------------------------------------------------------------

    def list_namespaces(self) -> List[Dict]:
        """
        Return namespace list.
        Each entry has at minimum {'namespace': id, 'namespaceShowName': label}.
        Falls back to the configured default namespace on error.
        """
        cached = self._cache_get('ns:list')
        if cached is not _CACHE_MISS:
            return cached

        try:
            data = self._get('/nacos/v1/console/namespaces')
            namespaces = data.get('data', []) if isinstance(data, dict) else []
            if not namespaces:
                namespaces = [{'namespace': self._namespace,
                               'namespaceShowName': self._namespace}]
            self._cache_set('ns:list', namespaces, self.NS_LIST_TTL)
            return namespaces
        except Exception as e:
            logger.error(f"list_namespaces error: {e}")
            fallback = [{'namespace': self._namespace, 'namespaceShowName': self._namespace}]
            return fallback

    def list_namespace_ids(self) -> List[str]:
        """Return just the namespace IDs.
        MSE Nacos uses '' (empty string) for the public namespace; map it to 'public'
        so it is a valid FUSE filename.
        """
        result = []
        for ns in self.list_namespaces():
            ns_id = ns.get('namespace')
            if ns_id is None:
                continue
            result.append(ns_id if ns_id else 'public')
        return result

    def _ns_to_api(self, namespace: str) -> str:
        """Translate filesystem namespace name to Nacos API tenant value.
        MSE Nacos represents the public namespace as '' in its API.
        """
        return '' if namespace == 'public' else namespace

    # ------------------------------------------------------------------
    # Config API
    # ------------------------------------------------------------------

    def list_config_groups(self, namespace: str) -> List[str]:
        """
        Return distinct group names present in a namespace.
        Uses the blur-search endpoint with no dataId filter.
        """
        cache_key = f'config:groups:{namespace}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        try:
            ns_api = self._ns_to_api(namespace)
            data = self._get('/nacos/v1/cs/configs', {
                'tenant': ns_api, 'group': '', 'dataId': '',
                'search': 'blur', 'pageNo': 1, 'pageSize': 500,
            }, tenant=ns_api)
            groups: set = set()
            if isinstance(data, dict):
                for item in data.get('pageItems', []):
                    grp = item.get('group')
                    if grp:
                        groups.add(grp)
            result = sorted(groups) or ['DEFAULT_GROUP']
            self._cache_set(cache_key, result, self.CONFIG_LIST_TTL)
            return result
        except Exception as e:
            logger.error(f"list_config_groups error: {e}")
            return ['DEFAULT_GROUP']

    def list_configs(self, namespace: str, group: str) -> List[str]:
        """Return dataId list for a namespace+group."""
        cache_key = f'config:items:{namespace}:{group}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        try:
            ns_api = self._ns_to_api(namespace)
            data = self._get('/nacos/v1/cs/configs', {
                'tenant': ns_api, 'group': group, 'dataId': '',
                'search': 'blur', 'pageNo': 1, 'pageSize': 500,
            }, tenant=ns_api, group=group)
            items: List[str] = []
            if isinstance(data, dict):
                items = [item['dataId'] for item in data.get('pageItems', [])
                         if item.get('dataId')]
            self._cache_set(cache_key, items, self.CONFIG_LIST_TTL)
            return items
        except Exception as e:
            logger.error(f"list_configs {namespace}/{group} error: {e}")
            return []

    def get_config(self, namespace: str, group: str, data_id: str) -> Optional[str]:
        """
        Fetch raw config content.
        The Nacos v1 configs endpoint returns the raw text when a single
        dataId+group+tenant combination is requested without search=blur.
        """
        try:
            ns_api = self._ns_to_api(namespace)
            result = self._get('/nacos/v1/cs/configs', {
                'tenant': ns_api, 'group': group, 'dataId': data_id,
            }, tenant=ns_api, group=group)
            # Result is raw text (str) or a dict if Nacos wrapped it
            if isinstance(result, str):
                return result
            if isinstance(result, dict):
                return result.get('content')
            return None
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            logger.error(f"get_config {namespace}/{group}/{data_id} error: {e}")
            return None
        except Exception as e:
            logger.error(f"get_config {namespace}/{group}/{data_id} error: {e}")
            return None

    def publish_config(self, namespace: str, group: str, data_id: str, content: str) -> bool:
        """Create or update a config item."""
        try:
            ns_api = self._ns_to_api(namespace)
            self._post('/nacos/v1/cs/configs', {
                'tenant': ns_api, 'group': group,
                'dataId': data_id, 'content': content,
            }, tenant=ns_api, group=group)
            self._cache_invalidate(f'config:items:{namespace}:{group}')
            self._cache_invalidate(f'config:groups:{namespace}')
            return True
        except Exception as e:
            logger.error(f"publish_config {namespace}/{group}/{data_id} error: {e}")
            return False

    def remove_config(self, namespace: str, group: str, data_id: str) -> bool:
        """Remove a config item."""
        try:
            ns_api = self._ns_to_api(namespace)
            self._delete('/nacos/v1/cs/configs', {
                'tenant': ns_api, 'group': group, 'dataId': data_id,
            }, tenant=ns_api, group=group)
            self._cache_invalidate(f'config:items:{namespace}:{group}')
            return True
        except Exception as e:
            logger.error(f"remove_config {namespace}/{group}/{data_id} error: {e}")
            return False

    # ------------------------------------------------------------------
    # Service / Naming API
    # ------------------------------------------------------------------

    def list_service_groups(self, namespace: str) -> List[str]:
        """
        Return distinct service group names present in a namespace.
        Nacos may return service names as 'GROUP@@serviceName'; we extract
        the group prefix. Falls back to DEFAULT_GROUP if none found.
        """
        cache_key = f'svc:groups:{namespace}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        try:
            ns_api = self._ns_to_api(namespace)
            data = self._get('/nacos/v1/ns/service/list', {
                'namespaceId': ns_api, 'pageNo': 1, 'pageSize': 500,
            }, tenant=ns_api)
            groups: set = set()
            if isinstance(data, dict):
                for dom in data.get('doms', []):
                    if '@@' in dom:
                        grp = dom.split('@@', 1)[0]
                    else:
                        grp = 'DEFAULT_GROUP'
                    groups.add(grp)
            result = sorted(groups) or ['DEFAULT_GROUP']
            self._cache_set(cache_key, result, self.SERVICE_LIST_TTL)
            return result
        except Exception as e:
            logger.error(f"list_service_groups {namespace} error: {e}")
            return ['DEFAULT_GROUP']

    def list_services(self, namespace: str, group: str) -> List[str]:
        """Return service names in namespace+group."""
        cache_key = f'svc:list:{namespace}:{group}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        try:
            ns_api = self._ns_to_api(namespace)
            data = self._get('/nacos/v1/ns/service/list', {
                'namespaceId': ns_api, 'groupName': group,
                'pageNo': 1, 'pageSize': 500,
            }, tenant=ns_api, group=group)
            services: List[str] = []
            if isinstance(data, dict):
                for dom in data.get('doms', []):
                    # Strip group prefix if Nacos returns 'group@@service'
                    svc = dom.split('@@', 1)[-1] if '@@' in dom else dom
                    services.append(svc)
            self._cache_set(cache_key, services, self.SERVICE_LIST_TTL)
            return services
        except Exception as e:
            logger.error(f"list_services {namespace}/{group} error: {e}")
            return []

    def get_service(self, namespace: str, group: str, service_name: str) -> Optional[Dict]:
        """Fetch service metadata."""
        try:
            ns_api = self._ns_to_api(namespace)
            data = self._get('/nacos/v1/ns/service', {
                'namespaceId': ns_api, 'groupName': group,
                'serviceName': service_name,
            }, tenant=ns_api, group=group)
            return data if isinstance(data, dict) else None
        except Exception as e:
            logger.error(f"get_service {namespace}/{group}/{service_name} error: {e}")
            return None

    def list_instances(self, namespace: str, group: str, service_name: str) -> List[Dict]:
        """Return all instances (healthy and unhealthy) for a service."""
        try:
            ns_api = self._ns_to_api(namespace)
            data = self._get('/nacos/v1/ns/instance/list', {
                'namespaceId': ns_api, 'groupName': group,
                'serviceName': service_name,
            }, tenant=ns_api, group=group)
            if isinstance(data, dict):
                return data.get('hosts', [])
            return []
        except Exception as e:
            logger.error(f"list_instances {namespace}/{group}/{service_name} error: {e}")
            return []

    def register_instance(
        self,
        namespace: str,
        group: str,
        service_name: str,
        ip: str,
        port: int,
        weight: float = 1.0,
        metadata: Optional[Dict] = None,
        cluster: str = 'DEFAULT',
        ephemeral: bool = True,
    ) -> bool:
        """Register a service instance."""
        try:
            ns_api = self._ns_to_api(namespace)
            data: Dict[str, str] = {
                'namespaceId': ns_api, 'groupName': group,
                'serviceName': service_name, 'ip': ip, 'port': str(port),
                'weight': str(weight), 'clusterName': cluster,
                'ephemeral': str(ephemeral).lower(),
                'enabled': 'true', 'healthy': 'true',
            }
            if metadata:
                data['metadata'] = json.dumps(metadata)
            self._post('/nacos/v1/ns/instance', data, tenant=ns_api, group=group)
            self._cache_invalidate(f'svc:list:{namespace}:{group}')
            return True
        except Exception as e:
            logger.error(f"register_instance error: {e}")
            return False

    def deregister_instance(
        self,
        namespace: str,
        group: str,
        service_name: str,
        ip: str,
        port: int,
        cluster: str = 'DEFAULT',
        ephemeral: bool = True,
    ) -> bool:
        """Deregister a service instance."""
        try:
            ns_api = self._ns_to_api(namespace)
            self._delete('/nacos/v1/ns/instance', {
                'namespaceId': ns_api, 'groupName': group,
                'serviceName': service_name, 'ip': ip, 'port': str(port),
                'clusterName': cluster, 'ephemeral': str(ephemeral).lower(),
            }, tenant=ns_api, group=group)
            self._cache_invalidate(f'svc:list:{namespace}:{group}')
            return True
        except Exception as e:
            logger.error(f"deregister_instance error: {e}")
            return False

    # ------------------------------------------------------------------
    # Skill API (v3)
    # ------------------------------------------------------------------

    SKILL_LIST_TTL = 10.0
    SKILL_ZIP_TTL = 30.0

    def list_skills(self, namespace: str, skill_name: str = '',
                    page: int = 1, page_size: int = 200) -> List[Dict]:
        """Return a list of skill dicts [{name, description}, ...] via v3 admin API."""
        cache_key = f'skill:list:{namespace}:{skill_name}:{page}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        try:
            params: Dict[str, str] = {
                'namespaceId': self._ns_to_api(namespace),
                'pageNo': str(page),
                'pageSize': str(page_size),
            }
            if skill_name:
                params['skillName'] = skill_name

            data = self._v3_get('/nacos/v3/admin/ai/skills/list', params,
                               tenant=self._ns_to_api(namespace))
            items = []
            if isinstance(data, dict):
                items = data.get('pageItems', [])
            self._cache_set(cache_key, items, self.SKILL_LIST_TTL)
            return items
        except Exception as e:
            logger.error(f"list_skills error: {e}")
            return []

    def get_skill_zip(self, namespace: str, skill_name: str,
                      version: str = None, label: str = None) -> Optional[bytes]:
        """Download a skill as raw ZIP bytes via v3 client API."""
        cache_key = f'skill:zip:{namespace}:{skill_name}:{version}:{label}'
        cached = self._cache_get(cache_key)
        if cached is not _CACHE_MISS:
            return cached

        try:
            params: Dict[str, str] = {
                'namespaceId': self._ns_to_api(namespace),
                'name': skill_name,
            }
            if version:
                params['version'] = version
            if label:
                params['label'] = label

            all_params = dict(self._auth_params())
            all_params.update(params)
            url = f"{self._base}/nacos/v3/client/ai/skills"
            if all_params:
                url += '?' + urllib.parse.urlencode(all_params)

            req = urllib.request.Request(url)
            self._apply_auth_headers(req, tenant=self._ns_to_api(namespace))

            with urllib.request.urlopen(req, timeout=30) as resp:
                zip_bytes = resp.read()
                self._cache_set(cache_key, zip_bytes, self.SKILL_ZIP_TTL)
                return zip_bytes
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            logger.error(f"get_skill_zip {skill_name} error: {e}")
            return None
        except Exception as e:
            logger.error(f"get_skill_zip {skill_name} error: {e}")
            return None

    def upload_skill_zip(self, namespace: str, zip_data: bytes,
                         filename: str = 'skill.zip') -> bool:
        """Upload a skill ZIP via multipart form POST to v3 admin API."""
        try:
            import io
            import email.generator

            boundary = f'----AgentFsBoundary{id(zip_data):x}'
            body = io.BytesIO()

            # Build multipart body manually (stdlib only)
            body.write(f'--{boundary}\r\n'.encode())
            body.write(
                f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'.encode()
            )
            body.write(b'Content-Type: application/zip\r\n\r\n')
            body.write(zip_data)
            body.write(f'\r\n--{boundary}--\r\n'.encode())

            all_params = dict(self._auth_params())
            all_params['namespaceId'] = self._ns_to_api(namespace)
            url = f"{self._base}/nacos/v3/admin/ai/skills/upload"
            url += '?' + urllib.parse.urlencode(all_params)

            req = urllib.request.Request(url, data=body.getvalue(), method='POST')
            req.add_header('Content-Type', f'multipart/form-data; boundary={boundary}')
            self._apply_auth_headers(req, tenant=self._ns_to_api(namespace))

            with urllib.request.urlopen(req, timeout=60) as resp:
                resp.read()

            # Invalidate skill list cache
            self._cache_invalidate(f'skill:list:{namespace}')
            return True
        except Exception as e:
            logger.error(f"upload_skill_zip error: {e}")
            return False

    def _v3_get(self, path: str, params: Dict = None,
                 tenant: str = '', group: str = '') -> Any:
        """GET request for v3 API, unwraps V3Response envelope."""
        all_params = dict(self._auth_params())
        if params:
            all_params.update(params)
        url = f"{self._base}{path}"
        if all_params:
            url += '?' + urllib.parse.urlencode(all_params)

        req = urllib.request.Request(url)
        self._apply_auth_headers(req, tenant, group)

        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode('utf-8')
            result = json.loads(body)

        # Unwrap v3 envelope: {"code": 0, "message": "...", "data": ...}
        if isinstance(result, dict) and 'code' in result:
            code = result.get('code', -1)
            if code != 0:
                raise Exception(
                    f"v3 API error: code={code}, message={result.get('message', '')}"
                )
            return result.get('data')
        return result
