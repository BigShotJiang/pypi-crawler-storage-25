"""
Alibaba Cloud Agent FS - Virtual filesystem for Alibaba Cloud cloud-native services.

Provides a FUSE-based virtual filesystem that exposes:
- AgentLoop Memory (CMS): /agentloop-memory/stores/...
- Nacos Config & Service Discovery: /nacos/config/... and /nacos/services/...
"""

__version__ = "0.4.0"
