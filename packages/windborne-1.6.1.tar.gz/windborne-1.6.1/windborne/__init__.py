# Import key functions and classes for easier access when users import the package

# Import API request helpers
from .api_request import API_BASE_URL, make_api_request

# Import Observations API functions
from .observations_api import (
    get_observations_page,
    get_observations,

    get_super_observations_page,
    get_super_observations,

    poll_super_observations,
    poll_observations,

    get_flying_missions,
    get_mission_launch_site,
    get_predicted_path,
    get_current_location,
    get_flight_path,
    get_constellation_status,
    get_soundings,
    get_sounding
)

# Import Forecasts API functions
from .forecasts_api import (
    get_point_forecasts,
    get_point_forecasts_interpolated,
    get_initialization_times,
    get_archived_initialization_times,
    get_run_information,
    get_variables,

    get_available_stations,
    get_station_forecast,
    get_interpolated_sounding,

    get_gridded_forecast,
    get_full_gridded_forecast,

    get_tropical_cyclones,

    get_population_weighted_hdds,
    get_population_weighted_cdds,
    get_calculation_times_degree_days,

    get_analysis_available_times,
    get_analysis_variables,
    get_interpolated_analysis,
    get_gridded_analysis
)

# Define what should be available when users import *
__all__ = [
    "get_observations_page",
    "get_observations",

    "get_super_observations_page",
    "get_super_observations",

    "poll_super_observations",
    "poll_observations",

    "get_flying_missions",
    "get_mission_launch_site",
    "get_predicted_path",
    "get_current_location",
    "get_flight_path",
    "get_constellation_status",
    "get_soundings",
    "get_sounding",

    "get_point_forecasts",
    "get_point_forecasts_interpolated",
    "get_initialization_times",
    "get_archived_initialization_times",
    "get_run_information",
    "get_variables",
    
    "get_available_stations",
    "get_station_forecast",
    "get_interpolated_sounding",

    "get_gridded_forecast",
    "get_full_gridded_forecast",

    "get_tropical_cyclones",

    "get_population_weighted_hdds",
    "get_population_weighted_cdds",
    "get_calculation_times_degree_days",

    "get_analysis_available_times",
    "get_analysis_variables",
    "get_interpolated_analysis",
    "get_gridded_analysis",

    # API helpers
    "API_BASE_URL",
    "make_api_request",
]