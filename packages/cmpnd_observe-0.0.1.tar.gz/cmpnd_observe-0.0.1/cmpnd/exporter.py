"""Async batch exporter for traces and spans."""

from __future__ import annotations

import atexit
import logging
import queue
import threading
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

import httpx

from cmpnd.config import Config, get_config

if TYPE_CHECKING:
    from cmpnd.models import EvalRunBuilder, SpanBuilder, TraceBuilder
    from cmpnd.optimizers.tracker import OptimizationTracker

logger = logging.getLogger(__name__)

_exporter: BatchExporter | None = None
_exporter_lock = threading.Lock()


@dataclass
class ExportItem:
    """Item in the export queue."""

    # item_type: "trace", "span", "eval_run", "optimization_run",
    #            "optimization_start", "optimization_progress",
    #            "trace_start", or "trace_finalize"
    item_type: str
    data: TraceBuilder | SpanBuilder | EvalRunBuilder | OptimizationTracker
    timestamp: float


class BatchExporter:
    """
    Async batch exporter for traces and spans.

    Runs in a background thread, batches items, and sends them
    to the backend without blocking the main thread.

    Spans are buffered until their trace arrives, then sent together.
    """

    def __init__(self, config: Config) -> None:
        self._config = config
        self._queue: queue.Queue[ExportItem] = queue.Queue(maxsize=config.max_queue_size)
        self._shutdown = threading.Event()
        self._thread: threading.Thread | None = None
        self._client: httpx.Client | None = None

        # Buffer spans by trace_id until trace arrives
        self._pending_spans: dict[str, list[dict]] = {}
        self._pending_spans_lock = threading.Lock()

        # Stats
        self._exported_count = 0
        self._dropped_count = 0
        self._error_count = 0

    def start(self) -> None:
        """Start the background export thread."""
        if self._thread and self._thread.is_alive():
            return

        self._shutdown.clear()
        self._thread = threading.Thread(
            target=self._export_loop,
            name="cmpnd-exporter",
            daemon=True,
        )
        self._thread.start()

        # Register cleanup on exit
        atexit.register(self.shutdown)

        logger.debug("Exporter started")

    def shutdown(self, timeout: float = 5.0) -> None:
        """Gracefully shutdown the exporter."""
        self._shutdown.set()

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)

        if self._client:
            self._client.close()
            self._client = None

        logger.debug(
            f"Exporter shutdown. Exported: {self._exported_count}, "
            f"Dropped: {self._dropped_count}, Errors: {self._error_count}"
        )

    def export_trace(self, trace: TraceBuilder) -> None:
        """Queue a trace for export (non-blocking)."""
        self._enqueue(ExportItem("trace", trace, time.time()))

    def export_span(self, span: SpanBuilder) -> None:
        """Queue a span for export (non-blocking)."""
        self._enqueue(ExportItem("span", span, time.time()))

    def export_eval_run(self, eval_run: EvalRunBuilder) -> None:
        """Queue an eval run for export (non-blocking)."""
        self._enqueue(ExportItem("eval_run", eval_run, time.time()))

    def export_optimization_run(self, optimization_run: OptimizationTracker) -> None:
        """Queue an optimization run for export (non-blocking)."""
        self._enqueue(ExportItem("optimization_run", optimization_run, time.time()))

    def export_trace_start(self, trace: TraceBuilder) -> None:
        """Queue a trace start for export (non-blocking)."""
        self._enqueue(ExportItem("trace_start", trace, time.time()))

    def export_trace_finalize(self, trace: TraceBuilder) -> None:
        """Queue a trace finalization for export (non-blocking)."""
        self._enqueue(ExportItem("trace_finalize", trace, time.time()))

    def export_trace_stats(self, trace: TraceBuilder) -> None:
        """Queue trace stats for export (non-blocking)."""
        self._enqueue(ExportItem("trace_stats", trace, time.time()))

    def export_optimization_start(self, optimization_run: OptimizationTracker) -> None:
        """Queue an optimization start record for export (non-blocking).

        This creates the initial "running" record in the backend so progress
        can be tracked before optimization completes.
        """
        self._enqueue(ExportItem("optimization_start", optimization_run, time.time()))

    def export_optimization_progress(self, optimization_run: OptimizationTracker) -> None:
        """Queue an optimization progress update for export (non-blocking).

        This sends a lightweight PATCH request to update progress metrics.
        """
        self._enqueue(ExportItem("optimization_progress", optimization_run, time.time()))

    def export_optimization_complete(self, optimization_run: OptimizationTracker) -> None:
        """Queue an optimization completion update for export (non-blocking).

        This updates an existing record with final results instead of creating a new one.
        """
        self._enqueue(ExportItem("optimization_complete", optimization_run, time.time()))

    def _enqueue(self, item: ExportItem) -> None:
        """Add item to queue, dropping if full."""
        try:
            self._queue.put_nowait(item)
        except queue.Full:
            self._dropped_count += 1
            logger.warning(
                f"Export queue full, dropping {item.item_type}. "
                f"Total dropped: {self._dropped_count}"
            )

    def _export_loop(self) -> None:
        """Background loop that batches and exports items."""
        self._client = httpx.Client(
            base_url=self._config.endpoint,
            headers={
                "X-API-Key": self._config.api_key,
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

        batch: list[ExportItem] = []
        last_flush = time.time()

        while not self._shutdown.is_set():
            try:
                # Collect items with timeout
                try:
                    item = self._queue.get(timeout=0.1)
                    batch.append(item)
                except queue.Empty:
                    pass

                # Flush if batch is full or timeout reached
                should_flush = (
                    len(batch) >= self._config.batch_size
                    or (batch and time.time() - last_flush >= self._config.flush_interval_seconds)
                )

                if should_flush and batch:
                    self._flush_batch(batch)
                    batch = []
                    last_flush = time.time()

            except Exception as e:
                logger.error(f"Error in export loop: {e}")
                self._error_count += 1

        # Final flush on shutdown
        if batch:
            self._flush_batch(batch)

    def _flush_batch(self, batch: list[ExportItem]) -> None:
        """Send a batch of items to the backend."""
        if not batch or not self._client:
            return

        # Separate traces, spans, eval runs, optimization runs, and progress updates
        traces_to_send: list[dict] = []
        stats_to_send: list[dict] = []
        eval_runs_to_send: list[dict] = []
        optimization_runs_to_send: list[dict] = []
        optimization_starts_to_send: list[dict] = []
        optimization_complete_to_send: list[dict] = []  # Updates existing records
        optimization_progress_to_send: list[tuple[str, dict]] = []  # (run_id, progress_dict)
        trace_starts: list[tuple[str, dict]] = []
        trace_finalizes: list[tuple[str, dict]] = []
        spans_by_trace: dict[str, list[dict]] = {}  # For streaming path (sent directly)
        new_spans: dict[str, list[dict]] = {}  # For old buffered path

        for item in batch:
            if item.item_type == "trace":
                traces_to_send.append(item.data.to_api_dict())
            elif item.item_type == "trace_stats":
                stats_to_send.append(item.data.to_stats_dict())
            elif item.item_type == "eval_run":
                eval_runs_to_send.append(item.data.to_api_dict())
            elif item.item_type == "optimization_run":
                optimization_runs_to_send.append(item.data.to_api_dict())
            elif item.item_type == "optimization_start":
                optimization_starts_to_send.append(item.data.to_api_dict())
            elif item.item_type == "optimization_complete":
                optimization_complete_to_send.append(item.data.to_api_dict())
            elif item.item_type == "optimization_progress":
                # Store run_id and progress dict for PATCH requests
                run_id = str(item.data.optimization_run_id)
                progress_dict = item.data.to_progress_dict()
                optimization_progress_to_send.append((run_id, progress_dict))
            elif item.item_type == "trace_start":
                trace_id = str(item.data.trace_id)
                trace_starts.append((trace_id, item.data.to_start_dict()))
            elif item.item_type == "trace_finalize":
                trace_id = str(item.data.trace_id)
                trace_finalizes.append((trace_id, item.data.to_finalize_dict()))
            elif item.item_type == "span":
                span_dict = item.data.to_api_dict()
                trace_id = str(span_dict.get("trace_id") or "")
                if not trace_id:
                    logger.warning("Dropping span without trace_id")
                    continue
                # Group for direct sending (streaming path)
                spans_by_trace.setdefault(trace_id, []).append(span_dict)
                # Also buffer for old path backward compat
                if trace_id not in new_spans:
                    new_spans[trace_id] = []
                new_spans[trace_id].append(span_dict)

        # Add new spans to pending buffer
        with self._pending_spans_lock:
            for trace_id, spans in new_spans.items():
                if trace_id not in self._pending_spans:
                    self._pending_spans[trace_id] = []
                self._pending_spans[trace_id].extend(spans)

        # Attach buffered spans to traces (don't overwrite if already present from batch path)
        for trace_dict in traces_to_send:
            trace_id = str(trace_dict.get("trace_id"))
            with self._pending_spans_lock:
                buffered_spans = self._pending_spans.pop(trace_id, [])
            if buffered_spans:
                # Merge with any spans already on the trace (from _batch_spans)
                existing = trace_dict.get("spans", [])
                trace_dict["spans"] = existing + buffered_spans
            elif "spans" not in trace_dict:
                trace_dict["spans"] = []

        # Send traces in batch if multiple, otherwise single
        if traces_to_send:
            total_spans = sum(len(t.get("spans", [])) for t in traces_to_send)
            try:
                if len(traces_to_send) == 1:
                    # Single trace - use regular endpoint
                    response = self._client.post(
                        "/api/v1/traces",
                        json=traces_to_send[0],
                    )
                else:
                    # Multiple traces - use batch endpoint
                    response = self._client.post(
                        "/api/v1/traces/batch",
                        json=traces_to_send,
                    )
                response.raise_for_status()
                self._exported_count += len(traces_to_send) + total_spans
                logger.debug(f"Exported {len(traces_to_send)} traces with {total_spans} spans")
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 429:
                    logger.warning(
                        f"Server buffer full, {len(traces_to_send)} full traces dropped. "
                        "Stats were accepted separately."
                    )
                    self._dropped_count += len(traces_to_send)
                else:
                    logger.error(f"Failed to export traces batch: {e}")
                    self._error_count += len(traces_to_send)
            except Exception as e:
                logger.error(f"Failed to export traces batch: {e}")
                self._error_count += len(traces_to_send)

        # Send trace starts (streaming path)
        for trace_id, start_dict in trace_starts:
            try:
                response = self._client.post(
                    f"/api/v1/traces/{trace_id}/start",
                    json=start_dict,
                )
                response.raise_for_status()
                self._exported_count += 1
                logger.debug(f"Started trace {trace_id}")
            except Exception as e:
                logger.error(f"Failed to start trace {trace_id}: {e}")
                self._error_count += 1

        # Send spans grouped by trace_id (streaming path)
        for trace_id, span_list in spans_by_trace.items():
            try:
                response = self._client.post(
                    f"/api/v1/traces/{trace_id}/spans",
                    json={"spans": span_list},
                )
                response.raise_for_status()
                self._exported_count += len(span_list)
                logger.debug(f"Exported {len(span_list)} spans for trace {trace_id}")
            except Exception as e:
                logger.error(f"Failed to export spans for trace {trace_id}: {e}")
                self._error_count += len(span_list)

        # Send trace finalizes (streaming path)
        for trace_id, finalize_dict in trace_finalizes:
            try:
                response = self._client.post(
                    f"/api/v1/traces/{trace_id}/finalize",
                    json=finalize_dict,
                )
                response.raise_for_status()
                self._exported_count += 1
                logger.debug(f"Finalized trace {trace_id}")
            except Exception as e:
                logger.error(f"Failed to finalize trace {trace_id}: {e}")
                self._error_count += 1

        # Send trace stats
        if stats_to_send:
            try:
                response = self._client.post("/api/v1/traces/stats", json=stats_to_send)
                response.raise_for_status()
                self._exported_count += len(stats_to_send)
                logger.debug(f"Exported {len(stats_to_send)} trace stats")
            except Exception as e:
                logger.error(f"Failed to export trace stats: {e}")
                self._error_count += len(stats_to_send)

        # Send eval runs
        for eval_run_dict in eval_runs_to_send:
            eval_run_id = str(eval_run_dict.get("eval_run_id"))
            num_examples = len(eval_run_dict.get("examples", []))

            try:
                response = self._client.post(
                    "/api/v1/evals",
                    json=eval_run_dict,
                )
                response.raise_for_status()
                self._exported_count += 1 + num_examples
                logger.debug(f"Exported eval run {eval_run_id} with {num_examples} examples")
            except Exception as e:
                logger.error(f"Failed to export eval run {eval_run_id}: {e}")
                self._error_count += 1

        # Send optimization runs
        for opt_run_dict in optimization_runs_to_send:
            opt_run_id = str(opt_run_dict.get("optimization_run_id"))
            num_iterations = len(opt_run_dict.get("iterations", []))
            num_candidates = len(opt_run_dict.get("candidates", []))

            try:
                response = self._client.post(
                    "/api/v1/optimizations",
                    json=opt_run_dict,
                )
                response.raise_for_status()
                self._exported_count += 1
                logger.debug(
                    f"Exported optimization run {opt_run_id} with "
                    f"{num_iterations} iterations, {num_candidates} candidates"
                )
            except Exception as e:
                logger.error(f"Failed to export optimization run {opt_run_id}: {e}")
                self._error_count += 1

        # Send optimization start records (creates "running" state)
        for opt_run_dict in optimization_starts_to_send:
            opt_run_id = str(opt_run_dict.get("optimization_run_id"))

            try:
                response = self._client.post(
                    "/api/v1/optimizations",
                    json=opt_run_dict,
                )
                response.raise_for_status()
                self._exported_count += 1
                logger.debug(f"Exported optimization start {opt_run_id}")
            except Exception as e:
                logger.error(f"Failed to export optimization start {opt_run_id}: {e}")
                self._error_count += 1

        # Send optimization progress updates (PATCH requests)
        for opt_run_id, progress_dict in optimization_progress_to_send:
            try:
                response = self._client.patch(
                    f"/api/v1/optimizations/{opt_run_id}/progress",
                    json=progress_dict,
                )
                response.raise_for_status()
                logger.debug(
                    f"Updated optimization progress {opt_run_id}: "
                    f"{progress_dict.get('current_metric_calls')}/{progress_dict.get('max_metric_calls')}"
                )
            except Exception as e:
                logger.error(f"Failed to update optimization progress {opt_run_id}: {e}")
                self._error_count += 1

        # Send optimization completion updates (PUT requests to update existing records)
        for opt_run_dict in optimization_complete_to_send:
            opt_run_id = str(opt_run_dict.get("optimization_run_id"))
            num_iterations = len(opt_run_dict.get("iterations", []))
            num_candidates = len(opt_run_dict.get("candidates", []))

            try:
                response = self._client.put(
                    f"/api/v1/optimizations/{opt_run_id}",
                    json=opt_run_dict,
                )
                response.raise_for_status()
                self._exported_count += 1
                logger.debug(
                    f"Completed optimization run {opt_run_id} with "
                    f"{num_iterations} iterations, {num_candidates} candidates"
                )
            except httpx.HTTPStatusError as e:
                # Log detailed error info for validation failures
                error_detail = ""
                try:
                    error_detail = e.response.text
                except Exception:
                    pass
                logger.error(
                    f"Failed to complete optimization run {opt_run_id}: {e}\n"
                    f"Response body: {error_detail}"
                )
                self._error_count += 1
            except Exception as e:
                logger.error(f"Failed to complete optimization run {opt_run_id}: {e}")
                self._error_count += 1


def get_exporter() -> BatchExporter | None:
    """Get the global exporter instance."""
    return _exporter


def ensure_exporter_started() -> BatchExporter | None:
    """Ensure the exporter is started, creating it if necessary."""
    global _exporter

    with _exporter_lock:
        if _exporter is None:
            config = get_config()
            if config:
                _exporter = BatchExporter(config)
                _exporter.start()
        return _exporter


def shutdown_exporter() -> None:
    """Shutdown the global exporter."""
    global _exporter

    with _exporter_lock:
        if _exporter:
            _exporter.shutdown()
            _exporter = None
