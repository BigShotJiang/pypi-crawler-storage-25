"""Configuration management for the cmpnd SDK."""

from __future__ import annotations

import os
from contextvars import ContextVar
from dataclasses import dataclass, field

_config: ContextVar[Config | None] = ContextVar("cmpnd_config", default=None)


@dataclass
class Config:
    """SDK configuration."""

    api_key: str
    endpoint: str = "https://api.cmpnd.io"
    project: str = "default"

    # Export settings
    batch_size: int = 100
    flush_interval_seconds: float = 5.0
    max_queue_size: int = 10000

    # Feature flags
    capture_inputs: bool = True
    capture_outputs: bool = True
    capture_prompts: bool = True
    max_input_size: int = 65536
    max_output_size: int = 65536

    # Environment
    environment: str = "development"
    service_name: str | None = None
    service_version: str | None = None

    # Additional tags applied to all traces
    default_tags: dict[str, str] = field(default_factory=dict)


def configure(
    api_key: str | None = None,
    endpoint: str | None = None,
    project: str = "default",
    **kwargs: object,
) -> Config:
    """
    Configure the cmpnd SDK.

    Args:
        api_key: API key for authentication. Can also be set via CMPND_API_KEY env var.
        endpoint: Backend API endpoint. Defaults to https://api.cmpnd.io.
            Can also be set via CMPND_ENDPOINT env var.
        project: Project name for organizing traces.
        **kwargs: Additional configuration options (batch_size, flush_interval_seconds, etc.)

    Returns:
        The configuration object.

    Raises:
        ValueError: If no API key is provided.

    Example:
        >>> import cmpnd
        >>> cmpnd.configure(api_key="ct_xxx", project="my-rag-app")
    """
    resolved_api_key = api_key or os.getenv("CMPND_API_KEY")
    if not resolved_api_key:
        raise ValueError(
            "API key required. Pass api_key= or set CMPND_API_KEY environment variable."
        )

    resolved_endpoint = endpoint or os.getenv("CMPND_ENDPOINT", "https://api.cmpnd.io")

    # Resolve size limits from env vars if not provided in kwargs
    if "max_input_size" not in kwargs:
        env_max_input = os.getenv("CMPND_MAX_INPUT_SIZE")
        if env_max_input:
            kwargs["max_input_size"] = int(env_max_input)

    if "max_output_size" not in kwargs:
        env_max_output = os.getenv("CMPND_MAX_OUTPUT_SIZE")
        if env_max_output:
            kwargs["max_output_size"] = int(env_max_output)

    config = Config(
        api_key=resolved_api_key,
        endpoint=resolved_endpoint,
        project=project,
        **kwargs,  # type: ignore[arg-type]
    )
    _config.set(config)
    return config


def get_config() -> Config | None:
    """Get the current SDK configuration."""
    return _config.get()


def require_config() -> Config:
    """
    Get the current SDK configuration, raising if not configured.

    Raises:
        RuntimeError: If configure() has not been called.
    """
    config = get_config()
    if config is None:
        raise RuntimeError("cmpnd not configured. Call cmpnd.configure(api_key=...) first.")
    return config
