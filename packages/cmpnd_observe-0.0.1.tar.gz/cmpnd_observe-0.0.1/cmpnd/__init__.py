"""
cmpnd - DSPy observability SDK.

Usage:
    >>> import cmpnd
    >>> cmpnd.configure(api_key="ct_xxx", project="my-project")
    >>> cmpnd.auto_instrument()
    >>>
    >>> # Your DSPy code is now automatically traced
    >>> import dspy
    >>> cot = dspy.ChainOfThought("question -> answer")
    >>> result = cot(question="What is DSPy?")
"""

from cmpnd.callback import CmpndCallback
from cmpnd.config import configure, get_config, require_config
from cmpnd.context import (
    clear_context,
    get_current_span,
    get_current_trace,
)
from cmpnd.datasets import DatasetNotFoundError, VersionNotFoundError, load_dataset
from cmpnd.decorators import start_span, trace
from cmpnd.exporter import shutdown_exporter
from cmpnd.models import SpanBuilder, SpanType, TraceBuilder, TraceStatus

# Lazy import for optimizers (optional dependency on dspy/gepa)
def _get_tracked_gepa():
    from cmpnd.optimizers import TrackedGEPA
    return TrackedGEPA

__version__ = "0.1.0"

__all__ = [
    # Configuration
    "configure",
    "get_config",
    "require_config",
    # Main callback
    "CmpndCallback",
    # Auto-instrumentation
    "auto_instrument",
    # Manual tracing
    "trace",
    "start_span",
    # Context access
    "get_current_trace",
    "get_current_span",
    "clear_context",
    # Cleanup
    "shutdown_exporter",
    # Types
    "SpanType",
    "TraceStatus",
    "SpanBuilder",
    "TraceBuilder",
    # Datasets
    "load_dataset",
    "DatasetNotFoundError",
    "VersionNotFoundError",
    # Optimizers (import from cmpnd.optimizers)
    # "optimizers",  # Use: from cmpnd.optimizers import TrackedGEPA
]


_gepa_patched = False


def _gepa_supports_callbacks() -> bool:
    """Check if the installed gepa version supports callbacks in optimize()."""
    try:
        import inspect
        from gepa.api import optimize
        return "callbacks" in inspect.signature(optimize).parameters
    except Exception:
        return False


def _patch_gepa() -> None:
    """Monkey-patch dspy.GEPA to auto-inject CmpndGEPACallback.

    Patches both __init__ (to create callback/tracker shell) and compile
    (to enrich tracker with student/valset info before optimization runs).

    Uses a module-level flag to avoid double-patching.
    """
    global _gepa_patched
    if _gepa_patched:
        return

    import dspy

    if not hasattr(dspy, "GEPA"):
        return

    from cmpnd.context import set_current_optimization_run_id
    from cmpnd.optimizers.gepa_callback import CmpndGEPACallback
    from cmpnd.optimizers.tracker import OptimizationTracker

    has_callbacks = _gepa_supports_callbacks()

    GEPA = dspy.GEPA
    GEPA._cmpnd_original_init = GEPA.__init__
    GEPA._cmpnd_original_compile = GEPA.compile

    def _patched_init(self, *args, **kwargs):
        # Force track_stats=True so detailed_results is always available
        if "track_stats" not in kwargs:
            kwargs["track_stats"] = True

        type(self)._cmpnd_original_init(self, *args, **kwargs)

    def _patched_compile(self, student, *, trainset, teacher=None, valset=None, **kwargs):
        # Create a fresh tracker + callback for each compile() call.
        # This ensures each optimization gets its own run_id, even when
        # the same GEPA instance is reused (e.g., optimizing an already-optimized program).
        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="",
        )
        callback = CmpndGEPACallback(tracker, defer_finalize=True)

        # Swap callback in GEPA's callback list
        if has_callbacks:
            old_callback = getattr(self, "_cmpnd_gepa_callback", None)
            existing = self.gepa_kwargs.get("callbacks") or []
            if old_callback is not None:
                existing = [cb for cb in existing if cb is not old_callback]
            self.gepa_kwargs["callbacks"] = existing + [callback]

        self._cmpnd_gepa_callback = callback

        if callback is not None:
            tracker = callback._tracker

            # Enrich tracker with student info
            tracker.program_name = student.__class__.__name__

            # Detect if student is an already-optimized program (continuation)
            prev_run_id = getattr(student, "_optimization_run_id", None)
            if prev_run_id is not None:
                tracker.compiled_from_run_id = str(prev_run_id)

            # Compute hashes
            effective_valset = valset if valset is not None else trainset
            tracker.valset_hash = OptimizationTracker.compute_valset_hash(effective_valset)

            # Store valset for dataset payload building
            tracker._valset = list(effective_valset)
            # Extract input field names from valset examples
            if effective_valset and hasattr(effective_valset[0], "_input_keys"):
                tracker._valset_input_fields = set(effective_valset[0]._input_keys)
            else:
                tracker._valset_input_fields = set()

            # Component signature hash
            components = []
            if hasattr(student, "named_predictors"):
                for name, pred in student.named_predictors():
                    comp = {"name": name}
                    if hasattr(pred, "signature"):
                        sig = pred.signature
                        if hasattr(sig, "input_fields"):
                            comp["inputs"] = list(sig.input_fields.keys())
                        if hasattr(sig, "output_fields"):
                            comp["outputs"] = list(sig.output_fields.keys())
                    components.append(comp)
            tracker.component_signature_hash = OptimizationTracker.compute_signature_hash(components)

            # Program signature hash from root signature
            signature = None
            if hasattr(student, "signature"):
                signature = student.signature
            elif hasattr(student, "predict") and hasattr(student.predict, "signature"):
                signature = student.predict.signature
            if signature is not None:
                tracker.program_signature_hash = OptimizationTracker.compute_program_signature_hash(signature)

            # Model names
            try:
                lm = dspy.settings.lm
                if lm is not None and hasattr(lm, "model"):
                    tracker.model_name = lm.model or ""
            except Exception:
                pass

            reflection_lm = getattr(self, "reflection_lm", None)
            if reflection_lm is not None and hasattr(reflection_lm, "model"):
                tracker.reflection_model_name = reflection_lm.model or ""

            # Config
            config = {}
            for key in ["auto", "max_metric_calls", "max_full_evals", "seed", "log_dir"]:
                val = getattr(self, key, None)
                if val is not None:
                    config[key] = val
            if components:
                config["components"] = components
            tracker.config = config

            # Max metric calls (GEPA computes this in __init__)
            max_mc = getattr(self, "max_metric_calls", None)
            if max_mc is not None:
                tracker.max_metric_calls = max_mc

            # Start tracker to send initial "running" record
            tracker.start()

        try:
            result = type(self)._cmpnd_original_compile(self, student, trainset=trainset, teacher=teacher, valset=valset, **kwargs)

            if callback is not None:
                tracker = callback._tracker

                # If gepa doesn't support callbacks, extract results from
                # the GEPA result object (old-style capture)
                if not has_callbacks:
                    detailed = getattr(result, "detailed_results", None)
                    if detailed is not None:
                        tracker.capture_final_results(detailed)

                tracker.capture_compiled_program(result)

                # Tag compiled program with optimization run ID
                if hasattr(result, "__dict__"):
                    result._optimization_run_id = str(tracker.optimization_run_id)

                tracker.finalize()

            return result

        except Exception as e:
            if callback is not None:
                callback._tracker.set_error(e)
            raise

        finally:
            if callback is not None:
                set_current_optimization_run_id(None)

    GEPA.__init__ = _patched_init
    GEPA.compile = _patched_compile
    _gepa_patched = True


def auto_instrument() -> CmpndCallback:
    """
    One-liner to enable DSPy tracing.

    Automatically registers a CmpndCallback with DSPy's global settings
    and patches dspy.GEPA to auto-inject optimization tracking.
    Must call configure() first.

    Returns:
        The callback instance that was registered.

    Raises:
        RuntimeError: If configure() hasn't been called.
        ImportError: If dspy is not installed.

    Example:
        >>> import cmpnd
        >>> cmpnd.configure(api_key="ct_xxx")
        >>> cmpnd.auto_instrument()
        >>>
        >>> # Now all DSPy calls are traced
        >>> import dspy
        >>> cot = dspy.ChainOfThought("question -> answer")
        >>> result = cot(question="What is the meaning of life?")
    """
    # Ensure we're configured
    require_config()

    # Import dspy
    try:
        import dspy
    except ImportError as e:
        raise ImportError(
            "dspy is required for auto_instrument(). Install with: pip install dspy"
        ) from e

    # Create callback
    callback = CmpndCallback()

    # Get current callbacks and avoid duplicates
    current_callbacks = dspy.settings.get("callbacks", [])
    if not any(isinstance(cb, CmpndCallback) for cb in current_callbacks):
        dspy.configure(callbacks=[*current_callbacks, callback])

    # Patch GEPA for automatic optimization tracking
    _patch_gepa()

    return callback
