"""DSPy callback implementation for cmpnd observability."""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from cmpnd.config import get_config
from cmpnd.context import (
    get_current_eval_run,
    get_current_span,
    get_current_trace,
    pop_span,
    push_span,
    set_current_eval_run,
    set_current_trace,
)
from cmpnd.exporter import ensure_exporter_started, get_exporter
from cmpnd.identity import (
    build_signature_summary,
    compute_signature_hash,
    get_field_schema,
    get_type_string,
    hash_demo,
)
from cmpnd.models import (
    EvalExampleBuilder,
    EvalExampleStatus,
    EvalRunBuilder,
    EvalRunStatus,
    SpanBuilder,
    SpanType,
    TraceBuilder,
    TraceStatus,
    _safe_serialize,
)

logger = logging.getLogger(__name__)

# Simple cost table for common models ($/1M tokens)
# (input_cost_per_1m, output_cost_per_1m)
_MODEL_COSTS: dict[str, tuple[float, float]] = {
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.00, 30.00),
    "gpt-4": (30.00, 60.00),
    "gpt-3.5-turbo": (0.50, 1.50),
    "claude-3-5-sonnet-20241022": (3.00, 15.00),
    "claude-sonnet-4-20250514": (3.00, 15.00),
    "claude-3-5-haiku-20241022": (0.80, 4.00),
    "claude-haiku-4-5-20251001": (0.80, 4.00),
    "claude-3-opus-20240229": (15.00, 75.00),
    "claude-opus-4-20250514": (15.00, 75.00),
}

# Lazy import dspy to avoid import errors if not installed
_dspy = None
_BaseCallback = None


def _get_dspy():
    """Lazy import of dspy module."""
    global _dspy, _BaseCallback
    if _dspy is None:
        try:
            import dspy
            from dspy.utils.callback import BaseCallback

            _dspy = dspy
            _BaseCallback = BaseCallback
        except ImportError as e:
            raise ImportError(
                "dspy is required for CmpndCallback. Install with: pip install dspy"
            ) from e
    return _dspy, _BaseCallback


class CmpndCallback:
    """
    DSPy callback for cmpnd observability.

    Captures execution data from DSPy modules, LM calls, adapters,
    and tools, building a hierarchical trace structure.

    Example:
        >>> import dspy
        >>> import cmpnd
        >>>
        >>> cmpnd.configure(api_key="ct_xxx")
        >>> dspy.configure(callbacks=[cmpnd.CmpndCallback()])
    """

    # Default max size per field (64KB)
    DEFAULT_MAX_FIELD_SIZE = 65536

    def __init__(
        self,
        capture_inputs: bool = True,
        capture_outputs: bool = True,
        capture_prompts: bool = True,
        max_input_field_size: int | None = None,
        max_output_field_size: int | None = None,
    ) -> None:
        self._capture_inputs = capture_inputs
        self._capture_outputs = capture_outputs
        self._capture_prompts = capture_prompts

        # Resolve field size limits: explicit param > config > default
        config = get_config()
        if max_input_field_size is not None:
            self._max_input_field_size = max_input_field_size
        elif config and config.max_input_size:
            self._max_input_field_size = config.max_input_size
        else:
            self._max_input_field_size = self.DEFAULT_MAX_FIELD_SIZE

        if max_output_field_size is not None:
            self._max_output_field_size = max_output_field_size
        elif config and config.max_output_size:
            self._max_output_field_size = config.max_output_size
        else:
            self._max_output_field_size = self.DEFAULT_MAX_FIELD_SIZE

        # Maps DSPy call_id -> our SpanBuilder
        self._call_id_to_span: dict[str, SpanBuilder] = {}

        # Maps DSPy call_id -> module instance (for extracting info at end)
        self._call_id_to_instance: dict[str, Any] = {}

        # Track trace roots
        self._root_call_ids: set[str] = set()

        # Track spans by trace_id for metric aggregation
        self._trace_spans: dict[str, list[SpanBuilder]] = {}

        # Eval run tracking
        self._eval_call_id_to_run: dict[str, EvalRunBuilder] = {}
        self._eval_traces: dict[str, list[TraceBuilder]] = {}  # eval_run_id -> traces
        self._eval_signature_input_fields: dict[str, set[str]] = {}  # call_id -> input field names

        # Active eval run - stored on instance to work across threads
        # (contextvars are thread-local, but DSPy Evaluate runs in parallel threads)
        self._active_eval_run: EvalRunBuilder | None = None

        # Active optimization run ID - stored on instance for same thread-safety reason
        self._active_optimization_run_id: UUID | None = None

        # Token usage from LM calls without a trace context (e.g., GEPA reflection calls)
        # Accumulated during optimization and included in the finalization payload
        # Structure: {model_name: {"prompt_tokens": int, "completion_tokens": int}}
        self._orphaned_lm_usage: dict[str, dict[str, int]] = {}

        # Last eval's trace IDs - stored for optimization tracker to pick up
        self._last_eval_trace_ids: list[UUID] = []

        # RLM parent spans: trace_id_str -> SpanBuilder for RLM parent
        self._rlm_parent_spans: dict[str, SpanBuilder] = {}

        # Track which traces use streaming export (thread-safe lookup for child spans)
        self._streaming_traces: dict[str, bool] = {}

        # Ensure exporter is running
        ensure_exporter_started()

    def _compute_cost(self, model_name: str, prompt_tokens: int, completion_tokens: int) -> float:
        """Compute cost from model name and token counts."""
        if not model_name or (prompt_tokens == 0 and completion_tokens == 0):
            return 0.0
        costs = _MODEL_COSTS.get(model_name)
        if not costs:
            return 0.0
        input_cost, output_cost = costs
        return (prompt_tokens * input_cost / 1_000_000) + (completion_tokens * output_cost / 1_000_000)

    def _should_stream_span(self, span: SpanBuilder) -> bool:
        """Check if this span should be streamed individually.

        Returns True for:
        - Spans in streaming (RLM) traces
        - Orphaned spans with no trace context (they won't be batched)
        Returns False for spans in non-streaming traces (they'll be batched).
        """
        trace = get_current_trace()
        if trace is not None:
            return trace.streaming
        # Thread-safe fallback for eval threads where contextvar may differ.
        # _streaming_traces maps trace_id -> bool; missing means orphaned span.
        trace_id_str = str(span.trace_id) if span.trace_id else ""
        if trace_id_str in self._streaming_traces:
            return self._streaming_traces[trace_id_str]
        # Orphaned span (no trace created for it) — stream it individually
        return True

    # ==================== Module Callbacks ====================

    def on_module_start(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Handle DSPy module forward() start."""
        dspy, _ = _get_dspy()

        # Determine span type based on module class
        span_type = self._get_span_type_for_module(instance, dspy)

        # Check if this is a root call (no parent span)
        parent_span = get_current_span()
        is_root = parent_span is None

        if is_root:
            # Start a new trace
            self._root_call_ids.add(call_id)
            trace = self._create_trace(instance, inputs)
            set_current_trace(trace)

            # RLM traces use streaming export; everything else batches
            if span_type == SpanType.RLM:
                trace.streaming = True
            self._streaming_traces[str(trace.trace_id)] = trace.streaming

            # Only stream trace_start for streaming traces
            if trace.streaming:
                exporter = get_exporter()
                if exporter:
                    exporter.export_trace_start(trace)

        # Get trace_id from current trace
        current_trace = get_current_trace()
        trace_id = current_trace.trace_id if current_trace else uuid4()

        # Create the span
        span = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name=f"{instance.__class__.__name__}.forward",
            span_type=span_type,
            parent_span_id=parent_span.span_id if parent_span else None,
            start_time=datetime.now(timezone.utc),
        )

        # Capture DSPy-specific attributes
        self._capture_module_attributes(span, instance, dspy)

        # Capture inputs
        if self._capture_inputs:
            clean_inputs = self._clean_inputs(inputs, dspy)
            span.set_inputs(clean_inputs)

        # Store mappings
        self._call_id_to_span[call_id] = span
        self._call_id_to_instance[call_id] = instance

        # Track RLM parent spans for repl_history population
        if span_type == SpanType.RLM and span.trace_id:
            self._rlm_parent_spans[str(span.trace_id)] = span

        # RLM repl_history: when PREDICT N+1 starts, its repl_history input
        # (a REPLHistory object) contains the output from step N's code execution.
        if (
            span_type == SpanType.PREDICT
            and span.trace_id
            and parent_span
            and getattr(parent_span, "span_type", None) == SpanType.RLM
        ):
            rlm_parent = self._rlm_parent_spans.get(str(span.trace_id))
            if rlm_parent and rlm_parent.repl_history:
                # inputs may be {"kwargs": {"repl_history": ...}} or {"repl_history": ...}
                rh_input = inputs.get("repl_history") or inputs.get("kwargs", {}).get("repl_history")
                if rh_input is not None and hasattr(rh_input, "entries") and rh_input.entries:
                    last_output = rh_input.entries[-1].output
                    rlm_parent.repl_history[-1]["output"] = last_output

        # Push to context stack
        push_span(span)

    def on_module_end(
        self,
        call_id: str,
        outputs: Any | None,
        exception: Exception | None = None,
    ) -> None:
        """Handle DSPy module forward() completion."""
        dspy, _ = _get_dspy()

        span = self._call_id_to_span.pop(call_id, None)
        instance = self._call_id_to_instance.pop(call_id, None)

        if not span:
            logger.warning(f"No span found for call_id: {call_id}")
            return

        # Set end time and status
        span.end_time = datetime.now(timezone.utc)

        if exception:
            span.set_error(exception)
        else:
            span.status = TraceStatus.OK

            # Capture outputs
            if self._capture_outputs and outputs is not None:
                clean_outputs = self._clean_outputs(outputs, instance, dspy)
                span.set_outputs(clean_outputs)

                # Extract token usage if available
                self._extract_usage_from_prediction(span, outputs, dspy)

        # Pop from context stack
        pop_span()

        # RLM repl_history: append trajectory data from PREDICT children
        if span.trace_id:
            trace_id_str = str(span.trace_id)
            rlm_parent = self._rlm_parent_spans.get(trace_id_str)
            if rlm_parent and span.span_type == SpanType.PREDICT and span.parent_span_id == rlm_parent.span_id:
                # RLM PREDICT outputs have "reasoning" and "code" fields
                out = span.outputs or {}
                if "reasoning" in out or "code" in out:
                    rlm_parent.repl_history.append({
                        "turn": len(rlm_parent.repl_history),
                        "reasoning": out.get("reasoning", ""),
                        "code": out.get("code", ""),
                    })

                # Thin RLM PREDICT inputs: strip the growing
                # repl_history to avoid O(N²) data.  The trajectory is
                # captured on the parent RLM span's repl_history instead.
                # Note: these are regular predict turns, NOT subcalls.
                # Subcalls are LM_CALL spans fired by code execution.
                if span.inputs and "repl_history" in span.inputs:
                    span.inputs.pop("repl_history", None)
                    span.attributes["thinned"] = "true"
                if span.inputs and "kwargs" in span.inputs:
                    kw = span.inputs.get("kwargs")
                    if isinstance(kw, dict) and "repl_history" in kw:
                        kw.pop("repl_history", None)
                        span.attributes["thinned"] = "true"

            # When the RLM span ends, extract the last step's output from the
            # final trajectory (no subsequent PREDICT to carry it).
            # Skip "FINAL: ..." outputs — these contain the entire RLM result
            # dict and are not meaningful code cell outputs.
            if span.span_type == SpanType.RLM:
                if rlm_parent and rlm_parent.repl_history and outputs is not None:
                    try:
                        last_output = None
                        traj = outputs.trajectory if hasattr(outputs, "trajectory") else None
                        if traj and hasattr(traj, "entries") and traj.entries:
                            last_output = traj.entries[-1].output
                        elif isinstance(traj, list) and traj:
                            last_entry = traj[-1]
                            if isinstance(last_entry, dict) and "output" in last_entry:
                                last_output = last_entry["output"]
                        # Don't store FINAL outputs — they duplicate the full
                        # RLM result and would crash the notebook view.
                        if last_output and not str(last_output).startswith("FINAL:"):
                            rlm_parent.repl_history[-1]["output"] = last_output
                    except (AttributeError, IndexError, TypeError):
                        pass
                self._rlm_parent_spans.pop(trace_id_str, None)

        # Track span by trace_id for metric aggregation
        if span.trace_id:
            trace_id_str = str(span.trace_id)
            if trace_id_str not in self._trace_spans:
                self._trace_spans[trace_id_str] = []
            self._trace_spans[trace_id_str].append(span)

        # Export span (only for streaming traces)
        if self._should_stream_span(span):
            exporter = get_exporter()
            if exporter:
                exporter.export_span(span)

        # If this was a root call, finalize the trace
        if call_id in self._root_call_ids:
            self._root_call_ids.discard(call_id)
            trace = get_current_trace()
            if trace:
                trace.end_time = datetime.now(timezone.utc)
                trace.status = TraceStatus.ERROR if exception else TraceStatus.OK
                if exception:
                    trace.error_message = str(exception)

                # Set response preview
                if outputs is not None and self._capture_outputs:
                    trace.response_preview = self._create_preview(
                        self._clean_outputs(outputs, instance, dspy)
                    )

                # Aggregate span metrics into trace
                trace_id_str = str(trace.trace_id)
                trace_spans = self._trace_spans.pop(trace_id_str, [])
                logger.debug(f"Aggregating {len(trace_spans)} spans for trace {trace_id_str[:8]}")
                for ts in trace_spans:
                    trace.total_tokens += ts.total_tokens
                    trace.prompt_tokens += ts.prompt_tokens
                    trace.completion_tokens += ts.completion_tokens
                    trace.total_cost += ts.cost
                    # Propagate adapter type from adapter spans to trace
                    if ts.adapter_type and not trace.adapter_type:
                        trace.adapter_type = ts.adapter_type
                trace.span_count = len(trace_spans)
                logger.debug(f"Trace totals: {trace.total_tokens} tokens, ${trace.total_cost}")

                # Link trace to optimization run if we're inside one
                # Try instance var first (thread-safe), fall back to contextvar
                from cmpnd.context import get_current_optimization_run_id
                opt_run_id = self._active_optimization_run_id or get_current_optimization_run_id()
                if opt_run_id:
                    trace.optimization_run_id = opt_run_id

                # If we're in an eval run, collect trace for metric correlation
                # Use instance var (thread-safe) instead of contextvar (thread-local)
                current_eval = self._active_eval_run
                if current_eval:
                    eval_run_id = str(current_eval.eval_run_id)
                    trace.eval_run_id = current_eval.eval_run_id
                    if eval_run_id in self._eval_traces:
                        self._eval_traces[eval_run_id].append(trace)
                        logger.debug(f"Added trace to eval run {eval_run_id[:8]}, total: {len(self._eval_traces[eval_run_id])}")
                        logger.debug(f"Trace collected for eval: tokens={trace.total_tokens}, cost={trace.total_cost:.4f}")

                exporter = get_exporter()
                if exporter:
                    exporter.export_trace_stats(trace)  # Stats tier (lightweight, never dropped)
                    if trace.streaming:
                        exporter.export_trace_finalize(trace)  # Finalize the streaming trace
                    else:
                        # Batch path: attach collected spans and send complete trace
                        trace._batch_spans = trace_spans
                        exporter.export_trace(trace)

                # Clean up streaming traces tracking
                self._streaming_traces.pop(trace_id_str, None)

                set_current_trace(None)

    # ==================== LM Callbacks ====================

    def on_lm_start(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Handle LM __call__ start."""
        dspy, _ = _get_dspy()

        parent_span = get_current_span()
        current_trace = get_current_trace()
        trace_id = current_trace.trace_id if current_trace else uuid4()

        span = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name=f"{instance.__class__.__name__}.__call__",
            span_type=SpanType.LM_CALL,
            parent_span_id=parent_span.span_id if parent_span else None,
            start_time=datetime.now(timezone.utc),
        )

        # Capture LM-specific attributes
        span.model_name = getattr(instance, "model", None)
        span.model_provider = self._infer_provider(instance)

        # Capture LM kwargs (exclude secrets)
        lm_kwargs = {
            k: v
            for k, v in getattr(instance, "kwargs", {}).items()
            if k not in {"api_key", "api_base", "api_secret"}
        }
        span.attributes.update(
            {
                "lm.model_type": getattr(instance, "model_type", "unknown"),
                "lm.cache": str(getattr(instance, "cache", False)),
                **{f"lm.{k}": str(v) for k, v in lm_kwargs.items()},
            }
        )

        # Detect RLM subcall: parent span is an RLM span
        if (
            parent_span
            and getattr(parent_span, "span_type", None) == SpanType.RLM
        ):
            span.attributes["rlm.subcall"] = "true"

        # Capture prompt/messages if enabled
        if self._capture_prompts:
            clean_inputs = self._clean_inputs(inputs, dspy)
            span.set_inputs(clean_inputs)

        self._call_id_to_span[call_id] = span
        # Store LM instance reference to access history for token usage
        self._call_id_to_instance[call_id] = instance
        push_span(span)

    def on_lm_end(
        self,
        call_id: str,
        outputs: dict[str, Any] | None,
        exception: Exception | None = None,
    ) -> None:
        """Handle LM __call__ completion."""
        span = self._call_id_to_span.pop(call_id, None)
        instance = self._call_id_to_instance.pop(call_id, None)
        if not span:
            return

        span.end_time = datetime.now(timezone.utc)

        if exception:
            span.set_error(exception)
        else:
            span.status = TraceStatus.OK

            # Extract token usage - try LM's history first (where DSPy stores it),
            # then fall back to outputs dict (for backwards compatibility / testing)
            usage = {}
            if instance and hasattr(instance, "history") and instance.history:
                try:
                    latest_entry = instance.history[-1]
                    usage = latest_entry.get("usage", {})
                    logger.debug(
                        f"LM history usage for {span.model_name}: "
                        f"history_len={len(instance.history)}, "
                        f"usage_type={type(usage).__name__}, "
                        f"usage={usage}"
                    )
                except (IndexError, AttributeError, TypeError) as e:
                    logger.debug(f"LM history access failed: {e}")
            else:
                logger.debug(
                    f"LM history unavailable: instance={instance is not None}, "
                    f"has_history={hasattr(instance, 'history') if instance else 'N/A'}, "
                    f"history_len={len(instance.history) if instance and hasattr(instance, 'history') else 'N/A'}"
                )

            # Fallback: check outputs dict for usage (legacy / test compatibility)
            if not usage and isinstance(outputs, dict):
                usage = outputs.get("usage", {})

            if usage:
                span.prompt_tokens = usage.get("prompt_tokens", 0)
                span.completion_tokens = usage.get("completion_tokens", 0)
                span.total_tokens = usage.get("total_tokens", 0)
                span.cost = self._compute_cost(span.model_name, span.prompt_tokens, span.completion_tokens)
                logger.debug(f"LM usage captured: {span.total_tokens} tokens")
            else:
                logger.debug(f"NO usage data for {span.model_name} (call_id={call_id})")

            # Extract finish_reason from LM history response
            if instance and hasattr(instance, "history") and instance.history:
                try:
                    latest_entry = instance.history[-1]
                    response = latest_entry.get("response")
                    if response and hasattr(response, "choices") and response.choices:
                        finish_reason = getattr(response.choices[0], "finish_reason", None)
                        if finish_reason:
                            span.set_attribute("lm.finish_reason", finish_reason)
                except (IndexError, AttributeError, TypeError):
                    pass

            # Capture response outputs (truncated)
            if outputs and self._capture_outputs:
                span.set_outputs(self._truncate_outputs(outputs))

        pop_span()

        # If this LM call has no trace context but we're in an optimization,
        # accumulate token usage for the optimization cost computation.
        # This captures GEPA reflection LM calls which run outside traced program flow.
        current_trace = get_current_trace()
        if current_trace is None and self._active_optimization_run_id is not None:
            model_name = span.model_name or "unknown"
            if model_name not in self._orphaned_lm_usage:
                self._orphaned_lm_usage[model_name] = {"prompt_tokens": 0, "completion_tokens": 0}
            self._orphaned_lm_usage[model_name]["prompt_tokens"] += span.prompt_tokens or 0
            self._orphaned_lm_usage[model_name]["completion_tokens"] += span.completion_tokens or 0
            logger.debug(
                f"Orphaned LM usage ({model_name}): "
                f"+{span.prompt_tokens}p/{span.completion_tokens}c tokens"
            )
            return  # Don't export orphaned spans (no trace to attach to)

        # Track span by trace_id for metric aggregation (LM spans have token info!)
        if span.trace_id:
            trace_id_str = str(span.trace_id)
            if trace_id_str not in self._trace_spans:
                self._trace_spans[trace_id_str] = []
            self._trace_spans[trace_id_str].append(span)

        span.thin()
        if self._should_stream_span(span):
            exporter = get_exporter()
            if exporter:
                exporter.export_span(span)

    # ==================== Adapter Callbacks ====================

    def on_adapter_format_start(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Handle adapter format() start."""
        self._start_adapter_span(call_id, instance, inputs, "format", SpanType.ADAPTER_FORMAT)

    def on_adapter_format_end(
        self,
        call_id: str,
        outputs: Any | None,
        exception: Exception | None = None,
    ) -> None:
        """Handle adapter format() completion."""
        self._end_adapter_span(call_id, outputs, exception)

    def on_adapter_parse_start(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Handle adapter parse() start."""
        self._start_adapter_span(call_id, instance, inputs, "parse", SpanType.ADAPTER_PARSE)

    def on_adapter_parse_end(
        self,
        call_id: str,
        outputs: Any | None,
        exception: Exception | None = None,
    ) -> None:
        """Handle adapter parse() completion."""
        self._end_adapter_span(call_id, outputs, exception)

    def _start_adapter_span(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
        method: str,
        span_type: SpanType,
    ) -> None:
        dspy, _ = _get_dspy()

        parent_span = get_current_span()
        current_trace = get_current_trace()
        trace_id = current_trace.trace_id if current_trace else uuid4()

        # Extract adapter type from instance class name
        adapter_type = instance.__class__.__name__  # e.g., "ChatAdapter", "JSONAdapter"

        span = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name=f"{instance.__class__.__name__}.{method}",
            span_type=span_type,
            parent_span_id=parent_span.span_id if parent_span else None,
            start_time=datetime.now(timezone.utc),
            adapter_type=adapter_type,
        )

        if self._capture_inputs:
            span.set_inputs(self._clean_inputs(inputs, dspy))

        self._call_id_to_span[call_id] = span
        push_span(span)

    def _end_adapter_span(
        self,
        call_id: str,
        outputs: Any | None,
        exception: Exception | None = None,
    ) -> None:
        span = self._call_id_to_span.pop(call_id, None)
        if not span:
            return

        span.end_time = datetime.now(timezone.utc)

        if exception:
            span.set_error(exception)
        else:
            span.status = TraceStatus.OK
            if self._capture_outputs and outputs:
                span.set_outputs(self._truncate_outputs(outputs))

        pop_span()

        # Track span by trace_id for adapter_type propagation to trace
        if span.trace_id:
            trace_id_str = str(span.trace_id)
            if trace_id_str not in self._trace_spans:
                self._trace_spans[trace_id_str] = []
            self._trace_spans[trace_id_str].append(span)

        span.thin()
        if self._should_stream_span(span):
            exporter = get_exporter()
            if exporter:
                exporter.export_span(span)

    # ==================== Tool Callbacks ====================

    def on_tool_start(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Handle tool execution start."""
        dspy, _ = _get_dspy()

        # Skip the special "finish" tool
        tool_name = getattr(instance, "name", "unknown")
        if tool_name == "finish":
            return

        parent_span = get_current_span()
        current_trace = get_current_trace()
        trace_id = current_trace.trace_id if current_trace else uuid4()

        span = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name=f"Tool.{tool_name}",
            span_type=SpanType.TOOL,
            parent_span_id=parent_span.span_id if parent_span else None,
            start_time=datetime.now(timezone.utc),
        )

        # Tool-specific attributes
        span.attributes.update(
            {
                "tool.name": tool_name,
                "tool.description": getattr(instance, "desc", ""),
            }
        )

        if self._capture_inputs:
            clean_inputs = self._clean_inputs(inputs, dspy)
            # Tools only use kwargs
            clean_inputs.pop("args", None)
            span.set_inputs(clean_inputs)

        self._call_id_to_span[call_id] = span
        push_span(span)

    def on_tool_end(
        self,
        call_id: str,
        outputs: Any | None,
        exception: Exception | None = None,
    ) -> None:
        """Handle tool execution completion."""
        span = self._call_id_to_span.pop(call_id, None)
        if not span:
            return

        span.end_time = datetime.now(timezone.utc)

        if exception:
            span.set_error(exception)
        else:
            span.status = TraceStatus.OK
            if self._capture_outputs and outputs:
                span.set_outputs(self._truncate_outputs(outputs))

        pop_span()

        # RLM repl_history: add observation from TOOL to the latest turn
        if span.trace_id:
            trace_id_str = str(span.trace_id)
            rlm_parent = self._rlm_parent_spans.get(trace_id_str)
            if rlm_parent and rlm_parent.repl_history:
                observation = str(outputs) if outputs is not None else ""
                rlm_parent.repl_history[-1]["observation"] = observation

        span.thin()
        if self._should_stream_span(span):
            exporter = get_exporter()
            if exporter:
                exporter.export_span(span)

    # ==================== Evaluation Callbacks ====================

    def on_evaluate_start(
        self,
        call_id: str,
        instance: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Handle evaluation start - creates EvalRunBuilder for tracking."""
        dspy, _ = _get_dspy()

        # Create the eval run
        eval_run = EvalRunBuilder(
            eval_run_id=uuid4(),
            start_time=datetime.now(timezone.utc),
        )

        # Link to optimization run if we're inside one
        from cmpnd.context import get_current_optimization_run_id
        optimization_run_id = get_current_optimization_run_id()
        if optimization_run_id:
            eval_run.optimization_run_id = optimization_run_id
            logger.debug(f"Linking eval run to optimization run: {optimization_run_id}")

        # Debug: log what inputs we receive
        logger.debug(f"on_evaluate_start inputs keys: {inputs.keys()}")
        logger.debug(f"on_evaluate_start instance type: {type(instance)}")
        logger.debug(f"on_evaluate_start instance attrs: {[a for a in dir(instance) if not a.startswith('_')]}")

        # Extract program info - DSPy may pass as positional arg or keyword
        program = inputs.get("program")
        # Check in args if not found directly
        if not program:
            args = inputs.get("args", ())
            if args and len(args) > 0:
                program = args[0]
        # Check in kwargs if not found
        if not program:
            kwargs = inputs.get("kwargs", {})
            program = kwargs.get("program")

        logger.debug(f"Extracted program: {program}, type: {type(program) if program else None}")

        if program:
            eval_run.program_name = program.__class__.__name__
            eval_run.program_hash = self._compute_program_hash(program)

            # Compute signature_hash for clustering - try to get signature from program
            signature = self._get_program_signature(program)
            if signature:
                eval_run.signature_hash = compute_signature_hash(signature)
                eval_run.signature_summary = build_signature_summary(signature)
                logger.debug(f"Eval run signature_hash: {eval_run.signature_hash}")

                # Extract input field names for filtering example inputs in on_evaluate_end
                if hasattr(signature, "input_fields"):
                    self._eval_signature_input_fields[call_id] = set(signature.input_fields.keys())
                    logger.debug(f"Signature input fields: {self._eval_signature_input_fields[call_id]}")

            # Try to get model info from the program's LM
            lm = getattr(dspy.settings, "lm", None)
            if lm:
                eval_run.model_name = getattr(lm, "model", None)
                eval_run.model_provider = self._infer_provider(lm)

        # Extract metric name - check multiple locations
        metric = inputs.get("metric")
        if not metric:
            kwargs = inputs.get("kwargs", {})
            metric = kwargs.get("metric")
        # Also check instance for metric
        if not metric:
            metric = getattr(instance, "metric", None)

        logger.debug(f"Extracted metric: {metric}, type: {type(metric) if metric else None}")

        if metric:
            if callable(metric):
                eval_run.metric_name = self._get_metric_name(metric)
            else:
                eval_run.metric_name = str(metric)

        # Extract devset info - check multiple locations
        devset = inputs.get("devset")
        logger.debug(f"devset from inputs.get('devset'): {type(devset)}, len={len(devset) if devset else 0}")

        if not devset:
            kwargs = inputs.get("kwargs", {})
            devset = kwargs.get("devset")
            logger.debug(f"devset from kwargs: {type(devset) if devset else None}")

        # Check instance for devset (Evaluate stores it)
        if not devset:
            devset = getattr(instance, "devset", None)
            logger.debug(f"devset from instance.devset: {type(devset) if devset else None}")

        # Also try 'dev' attribute (some DSPy versions)
        if not devset:
            devset = getattr(instance, "dev", None)
            logger.debug(f"devset from instance.dev: {type(devset) if devset else None}")

        logger.debug(f"Final devset: len={len(devset) if devset else 0}")
        logger.debug(f"Devset extraction: {type(devset)}, len={len(devset) if devset else 0}")

        if devset:
            eval_run.dataset_size = len(devset)
            # Use the same hash algorithm as the optimization path
            # so both paths produce identical hashes for the same dataset
            from cmpnd.identity import compute_valset_hash
            eval_run.dataset_hash = compute_valset_hash(devset)
            logger.debug(f"Dataset hash computed: {eval_run.dataset_hash[:16] if eval_run.dataset_hash else 'EMPTY'}")

            # Store devset reference for dataset payload building
            eval_run._devset = list(devset)  # shallow copy
            # Store input fields from signature, falling back to _input_keys on examples
            input_fields = self._eval_signature_input_fields.get(call_id, set())
            if not input_fields and devset and hasattr(devset[0], "_input_keys"):
                input_fields = set(devset[0]._input_keys)
            eval_run._input_fields = input_fields
            # Fire pre-flight check (synchronous, short timeout)
            from cmpnd.dataset_sync import check_dataset_exists

            try:
                eval_run._dataset_exists = check_dataset_exists(eval_run.dataset_hash)
            except Exception:
                eval_run._dataset_exists = None  # Will include examples as fallback

        logger.info(f"EvalRun created: program_name={eval_run.program_name}, metric_name={eval_run.metric_name}, dataset_hash={eval_run.dataset_hash}, dataset_size={eval_run.dataset_size}")

        # Store mappings
        self._eval_call_id_to_run[call_id] = eval_run
        self._eval_traces[str(eval_run.eval_run_id)] = []

        # Set current eval run context (both contextvar and instance var for thread safety)
        set_current_eval_run(eval_run)
        self._active_eval_run = eval_run

        # Also create a span for the evaluation itself
        parent_span = get_current_span()
        current_trace = get_current_trace()
        trace_id = current_trace.trace_id if current_trace else uuid4()

        span = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name="Evaluate",
            span_type=SpanType.EVALUATION,
            parent_span_id=parent_span.span_id if parent_span else None,
            start_time=datetime.now(timezone.utc),
        )

        # Capture evaluation config in span attributes
        span.attributes["eval.run_id"] = str(eval_run.eval_run_id)
        span.attributes["eval.program_name"] = eval_run.program_name or ""
        span.attributes["eval.metric_name"] = eval_run.metric_name or ""
        span.attributes["eval.dataset_size"] = str(eval_run.dataset_size)

        self._call_id_to_span[call_id] = span
        push_span(span)

    def on_evaluate_end(
        self,
        call_id: str,
        outputs: Any | None,
        exception: Exception | None = None,
    ) -> None:
        """Handle evaluation completion - finalizes and exports EvalRunBuilder."""
        dspy, _ = _get_dspy()

        # Get the eval run
        eval_run = self._eval_call_id_to_run.pop(call_id, None)

        # Handle span
        span = self._call_id_to_span.pop(call_id, None)
        if span:
            span.end_time = datetime.now(timezone.utc)
            if exception:
                span.set_error(exception)
            else:
                span.status = TraceStatus.OK
            pop_span()
            if self._should_stream_span(span):
                exporter = get_exporter()
                if exporter:
                    exporter.export_span(span)

        if not eval_run:
            logger.warning(f"No eval run found for call_id: {call_id}")
            set_current_eval_run(None)
            return

        # Extract results from outputs
        if exception:
            eval_run.set_error(exception)
        else:
            # DSPy returns EvaluationResult or (score, results) tuple
            overall_score = 0.0
            results = []

            # Try to extract from EvaluationResult
            if hasattr(outputs, "score"):
                overall_score = float(outputs.score)
            elif isinstance(outputs, (int, float)):
                overall_score = float(outputs)
            elif isinstance(outputs, tuple) and len(outputs) >= 1:
                overall_score = float(outputs[0])

            # Try to extract per-example results
            if hasattr(outputs, "results"):
                results = outputs.results  # List of (example, prediction, score)
            elif isinstance(outputs, tuple) and len(outputs) >= 2:
                results = outputs[1] if isinstance(outputs[1], list) else []

            # Get collected traces for this eval run (in execution order)
            eval_run_id = str(eval_run.eval_run_id)
            eval_traces = self._eval_traces.get(eval_run_id, [])
            # Sort traces by start_time to ensure correct ordering
            eval_traces.sort(key=lambda t: t.start_time or datetime.min.replace(tzinfo=timezone.utc))

            logger.debug(f"Collected {len(eval_traces)} traces for eval run")
            for i, t in enumerate(eval_traces[:3]):  # Show first 3
                logger.debug(f"  Trace {i}: tokens={t.total_tokens}, cost={t.total_cost}")

            # Process per-example results
            for idx, result_item in enumerate(results):
                example_builder = EvalExampleBuilder(
                    example_id=uuid4(),
                    eval_run_id=eval_run.eval_run_id,
                    example_index=idx,
                )

                # Unpack result - DSPy returns (example, prediction, score)
                if isinstance(result_item, tuple) and len(result_item) >= 3:
                    example, prediction, score = result_item[:3]

                    # Extract example as dict
                    if hasattr(example, "toDict"):
                        example_dict = example.toDict()
                    elif hasattr(example, "__dict__"):
                        example_dict = {
                            k: v
                            for k, v in example.__dict__.items()
                            if not k.startswith("_")
                        }
                    else:
                        example_dict = {}

                    # Filter to only input fields if signature is available
                    # This ensures example_hash matches backend's signature_input_hash
                    signature_input_fields = self._eval_signature_input_fields.get(call_id, set())
                    if signature_input_fields:
                        # Only include signature input fields in inputs
                        example_builder.inputs = {
                            k: v for k, v in example_dict.items()
                            if k in signature_input_fields
                        }
                        # Store remaining fields (non-input) as expected output
                        expected_output = {
                            k: v for k, v in example_dict.items()
                            if k not in signature_input_fields and not k.startswith("_")
                        }
                        if expected_output:
                            example_builder.expected_output = expected_output
                    else:
                        # Fallback: no signature available, store all fields as inputs
                        example_builder.inputs = example_dict

                    # Extract actual output from prediction
                    if hasattr(prediction, "toDict"):
                        example_builder.actual_output = prediction.toDict()
                    elif isinstance(prediction, dict):
                        example_builder.actual_output = prediction

                    # Set score - normalize to 0-100 scale to match overall run score
                    # Metric functions typically return 0-1 (e.g., 0.0, 0.5, 1.0)
                    raw_score = float(score) if score is not None else 0.0
                    example_builder.score = raw_score * 100  # Convert to percentage
                    example_builder.passed = raw_score > 0
                    example_builder.status = EvalExampleStatus.COMPLETED

                    # Compute example hash for comparability
                    example_builder.example_hash = self._compute_example_hash(
                        example_builder.inputs
                    )

                    # Match with trace to get metrics (by index - assumes sequential execution)
                    if idx < len(eval_traces):
                        trace = eval_traces[idx]
                        example_builder.trace_id = trace.trace_id

                        # Extract duration from trace
                        if trace.start_time and trace.end_time:
                            duration = trace.end_time - trace.start_time
                            example_builder.duration_ns = int(duration.total_seconds() * 1_000_000_000)

                        # Extract tokens and cost from trace
                        example_builder.total_tokens = trace.total_tokens
                        example_builder.cost = trace.total_cost

                eval_run.add_example_result(example_builder)

            # Propagate adapter type from traces to eval run
            if eval_traces and not eval_run.adapter_type:
                for trace in eval_traces:
                    if trace.adapter_type:
                        eval_run.adapter_type = trace.adapter_type
                        break

            # Finalize the eval run
            eval_run.finalize(overall_score, EvalRunStatus.COMPLETED)

            # Update span with final score
            if span:
                span.attributes["eval.score"] = str(overall_score)

        # Export the eval run
        exporter = get_exporter()
        if exporter:
            exporter.export_eval_run(eval_run)

        # Store the last eval's trace IDs before cleanup so the optimization
        # tracker can populate eval_trace_ids on iterations
        self._last_eval_trace_ids = [t.trace_id for t in eval_traces] if eval_traces else []

        # Clean up
        self._eval_traces.pop(str(eval_run.eval_run_id), None)
        self._eval_signature_input_fields.pop(call_id, None)
        set_current_eval_run(None)
        self._active_eval_run = None

    # ==================== Helper Methods ====================

    def _get_span_type_for_module(self, instance: Any, dspy: Any) -> SpanType:
        """Map DSPy module instance to span type."""
        if isinstance(instance, dspy.Retrieve):
            return SpanType.RETRIEVE
        elif isinstance(instance, getattr(dspy, 'RLM', type(None))):
            return SpanType.RLM
        elif isinstance(instance, dspy.ReAct):
            return SpanType.REACT
        elif isinstance(instance, dspy.ChainOfThought):
            return SpanType.CHAIN_OF_THOUGHT
        elif isinstance(instance, dspy.Predict):
            return SpanType.PREDICT
        elif isinstance(instance, dspy.Adapter):
            return SpanType.ADAPTER_FORMAT  # Will be refined
        else:
            return SpanType.MODULE

    def _capture_module_attributes(self, span: SpanBuilder, instance: Any, dspy: Any) -> None:
        """Capture DSPy-specific module attributes."""
        span.module_type = instance.__class__.__name__
        span.module_name = getattr(instance, "name", None) or instance.__class__.__name__

        # Capture signature info for Predict-based modules
        signature = None
        if hasattr(instance, "signature"):
            signature = instance.signature
        elif hasattr(instance, "predict") and hasattr(instance.predict, "signature"):
            signature = instance.predict.signature

        if signature:
            # Get signature name, avoiding generic "StringSignature" from DSPy optimizers
            sig_name = getattr(signature, "__name__", None)
            if not sig_name or sig_name == "StringSignature":
                # Fall back to field-based name: "input1, input2 -> output1, output2"
                sig_name = build_signature_summary(signature)
            span.signature_name = sig_name or str(signature)
            span.signature_instructions = getattr(signature, "instructions", None)

            # Extract input field info (names, types, descriptions, schemas)
            if hasattr(signature, "input_fields"):
                input_fields = signature.input_fields
                span.signature_input_fields = list(input_fields.keys())
                span.signature_input_field_types = [
                    get_type_string(field_info.annotation)
                    for field_info in input_fields.values()
                ]
                span.signature_input_field_descs = [
                    field_info.json_schema_extra.get("desc", "") if field_info.json_schema_extra else ""
                    for field_info in input_fields.values()
                ]
                # Capture schemas for complex types (Pydantic models, dataclasses)
                span.signature_input_field_schemas = [
                    get_field_schema(field_info.annotation)
                    for field_info in input_fields.values()
                ]

            # Extract output field info (names, types, descriptions, schemas)
            if hasattr(signature, "output_fields"):
                output_fields = signature.output_fields
                span.signature_output_fields = list(output_fields.keys())
                span.signature_output_field_types = [
                    get_type_string(field_info.annotation)
                    for field_info in output_fields.values()
                ]
                span.signature_output_field_descs = [
                    field_info.json_schema_extra.get("desc", "") if field_info.json_schema_extra else ""
                    for field_info in output_fields.values()
                ]
                # Capture schemas for complex types (Pydantic models, dataclasses)
                span.signature_output_field_schemas = [
                    get_field_schema(field_info.annotation)
                    for field_info in output_fields.values()
                ]

            # Compute signature_hash for span (matches trace hash for program identity)
            span.signature_hash = compute_signature_hash(signature)

            # For ChainOfThought, also capture extended signature
            if hasattr(instance, "extended_signature"):
                ext_sig = instance.extended_signature
                span.attributes["extended_signature"] = getattr(
                    ext_sig, "signature", str(ext_sig)
                )

        # Capture demo count and contents if available
        demos = getattr(instance, "demos", None)
        if demos:
            span.demo_count = len(demos)
            span.demos = [_safe_serialize(d) for d in demos]

    def _create_trace(self, instance: Any, inputs: dict[str, Any]) -> TraceBuilder:
        """Create a new trace for a root module call."""
        config = get_config()

        trace = TraceBuilder(
            trace_id=uuid4(),
            start_time=datetime.now(timezone.utc),
            program_name=instance.__class__.__name__,
        )

        # Capture signature info for the root module - this identifies the program
        signature = None
        if hasattr(instance, "signature"):
            signature = instance.signature
        elif hasattr(instance, "predict") and hasattr(instance.predict, "signature"):
            signature = instance.predict.signature

        if signature:
            # Get signature name, avoiding generic "StringSignature"
            sig_name = getattr(signature, "__name__", None)
            if not sig_name or sig_name == "StringSignature":
                sig_name = build_signature_summary(signature)
            trace.signature_name = sig_name or str(signature)

            # Extract input/output field names, types, and schemas
            if hasattr(signature, "input_fields"):
                input_fields = signature.input_fields
                trace.signature_input_fields = list(input_fields.keys())
                trace.signature_input_field_types = [
                    get_type_string(field_info.annotation)
                    for field_info in input_fields.values()
                ]
                trace.signature_input_field_schemas = [
                    get_field_schema(field_info.annotation)
                    for field_info in input_fields.values()
                ]

            if hasattr(signature, "output_fields"):
                output_fields = signature.output_fields
                trace.signature_output_fields = list(output_fields.keys())
                trace.signature_output_field_types = [
                    get_type_string(field_info.annotation)
                    for field_info in output_fields.values()
                ]
                trace.signature_output_field_schemas = [
                    get_field_schema(field_info.annotation)
                    for field_info in output_fields.values()
                ]

            # Compute signature_hash using identity module (xxhash for determinism)
            trace.signature_hash = compute_signature_hash(signature)

            # Store human-readable signature summary
            trace.signature_summary = build_signature_summary(signature)

        # Detect if this is a compiled program (from optimization)
        if hasattr(instance, "_optimization_run_id"):
            trace.compiled_from_run_id = str(instance._optimization_run_id)

        # Capture active demo IDs if available
        demos = getattr(instance, "demos", None)
        if demos:
            trace.demo_ids = [hash_demo(d) for d in demos]

        # Set request preview from inputs
        dspy, _ = _get_dspy()
        preview = self._create_preview(self._clean_inputs(inputs, dspy))
        trace.request_preview = preview

        # Apply default tags
        if config and config.default_tags:
            trace.tags.update(config.default_tags)

        return trace

    def _truncate_field(self, value: Any, max_size: int) -> Any:
        """Truncate a single field value if it exceeds max_size.

        Handles different types intelligently:
        - Strings: truncate with character count
        - Lists: truncate with item count
        - Dicts: recursively truncate values
        - Other: convert to string and truncate
        """
        if value is None:
            return None

        # For strings, check length directly
        if isinstance(value, str):
            if len(value) > max_size:
                return {
                    "_truncated": True,
                    "_type": "string",
                    "_size_chars": len(value),
                    "_preview": value[:min(1000, max_size)],
                }
            return value

        # For lists, check serialized size and truncate items if needed
        if isinstance(value, list):
            try:
                serialized = json.dumps(value, default=str)
                if len(serialized) > max_size:
                    # Find how many items fit within the limit
                    truncated_items = []
                    current_size = 2  # Account for []
                    for item in value:
                        item_serialized = json.dumps(item, default=str)
                        if current_size + len(item_serialized) + 1 > max_size:
                            break
                        truncated_items.append(self._truncate_field(item, max_size // 10))
                        current_size += len(item_serialized) + 1

                    return {
                        "_truncated": True,
                        "_type": "list",
                        "_total_items": len(value),
                        "_shown_items": len(truncated_items),
                        "_size_bytes": len(serialized),
                        "_preview": truncated_items[:10] if truncated_items else [],
                    }
            except (TypeError, ValueError):
                pass
            return value

        # For dicts, recursively truncate each value
        if isinstance(value, dict):
            result = {}
            for k, v in value.items():
                result[k] = self._truncate_field(v, max_size)
            return result

        # For other types, serialize and check size
        try:
            serialized = json.dumps(value, default=str)
            if len(serialized) > max_size:
                return {
                    "_truncated": True,
                    "_type": type(value).__name__,
                    "_size_bytes": len(serialized),
                    "_preview": serialized[:min(1000, max_size)],
                }
        except (TypeError, ValueError):
            str_value = str(value)
            if len(str_value) > max_size:
                return {
                    "_truncated": True,
                    "_type": type(value).__name__,
                    "_size_chars": len(str_value),
                    "_preview": str_value[:min(1000, max_size)],
                }

        return value

    def _clean_inputs(self, inputs: dict[str, Any], dspy: Any) -> dict[str, Any]:
        """Clean and prepare inputs for storage, with per-field truncation."""
        result = {}

        # Merge kwargs into top level
        kwargs = inputs.get("kwargs", {})
        for k, v in inputs.items():
            if k != "kwargs":
                serialized = _safe_serialize(v)
                result[k] = self._truncate_field(serialized, self._max_input_field_size)
        for k, v in kwargs.items():
            serialized = _safe_serialize(v)
            result[k] = self._truncate_field(serialized, self._max_input_field_size)

        # Remove empty args
        if "args" in result and not result["args"]:
            del result["args"]

        return result

    def _clean_outputs(self, outputs: Any, instance: Any, dspy: Any) -> dict[str, Any]:
        """Clean and prepare outputs for storage, with per-field truncation."""
        if isinstance(outputs, dspy.Prediction):
            # toDict() may return objects that need further serialization
            serialized = _safe_serialize(outputs.toDict())
        elif isinstance(outputs, dict):
            serialized = _safe_serialize(outputs)
        else:
            serialized = {"result": _safe_serialize(outputs)}

        # Apply per-field truncation
        return self._truncate_field(serialized, self._max_output_field_size)

    def _truncate_outputs(self, outputs: Any) -> Any:
        """Truncate outputs if too large (uses per-field truncation)."""
        try:
            # First ensure the outputs are serializable
            safe_outputs = _safe_serialize(outputs)
            return self._truncate_field(safe_outputs, self._max_output_field_size)
        except Exception:
            return {"_error": "Failed to serialize outputs"}

    def _extract_usage_from_prediction(
        self, span: SpanBuilder, outputs: Any, dspy: Any
    ) -> None:
        """Extract token usage from a DSPy Prediction."""
        if isinstance(outputs, dspy.Prediction):
            usage_by_model = outputs.get_lm_usage() if hasattr(outputs, "get_lm_usage") else None
            if usage_by_model:
                for model_usage in usage_by_model.values():
                    span.prompt_tokens += model_usage.get("prompt_tokens", 0)
                    span.completion_tokens += model_usage.get("completion_tokens", 0)
                    span.total_tokens += model_usage.get("total_tokens", 0)

    def _get_metric_name(self, metric: Any) -> str:
        """Extract the original metric function name, unwrapping DSPy wrappers.

        DSPy often wraps user metrics in internal functions like 'wrapped_metric'.
        This method attempts to find the original metric name by:
        1. Checking for __wrapped__ attribute (standard functools convention)
        2. Inspecting closure variables for the original metric
        3. Falling back to the wrapper's __name__
        """
        # Check for __wrapped__ (functools.wraps convention)
        if hasattr(metric, "__wrapped__"):
            return self._get_metric_name(metric.__wrapped__)

        name = getattr(metric, "__name__", None) or metric.__class__.__name__

        # If it's a DSPy wrapper, try to find the original metric in closure
        if name in ("wrapped_metric", "wrapper", "_wrapper", "inner"):
            try:
                # Check closure for the original metric
                closure = getattr(metric, "__closure__", None)
                if closure:
                    for cell in closure:
                        cell_contents = cell.cell_contents
                        if callable(cell_contents) and cell_contents is not metric:
                            inner_name = getattr(cell_contents, "__name__", None)
                            # Skip other wrapper names
                            if inner_name and inner_name not in ("wrapped_metric", "wrapper", "_wrapper", "inner"):
                                return inner_name
            except (ValueError, AttributeError):
                pass

        return name

    def _infer_provider(self, instance: Any) -> str:
        """Infer LM provider from model name."""
        model = getattr(instance, "model", "")
        if "gpt" in model or "openai" in model:
            return "openai"
        elif "claude" in model or "anthropic" in model:
            return "anthropic"
        elif "gemini" in model:
            return "google"
        elif "llama" in model or "mistral" in model:
            return "together"
        else:
            return "unknown"

    def _create_preview(self, data: dict[str, Any], max_len: int = 200) -> str:
        """Create a short preview string from data."""
        try:
            s = json.dumps(data, default=str)
            return s[:max_len] + "..." if len(s) > max_len else s
        except Exception:
            return str(data)[:max_len]

    # ==================== Eval Hash Methods ====================

    def _compute_program_hash(self, program: Any) -> str:
        """Compute a hash of the program's predictors and instructions.

        This allows comparing program versions - if the hash changes,
        the program structure or instructions have changed.
        """
        try:
            hasher = hashlib.sha256()

            # Hash the program class name
            hasher.update(program.__class__.__name__.encode())

            # Hash predictor names and their signatures/instructions
            predictors = getattr(program, "predictors", None)
            if predictors and callable(predictors):
                for name, predictor in predictors():
                    hasher.update(name.encode())

                    # Hash signature info
                    sig = getattr(predictor, "signature", None)
                    if sig:
                        sig_name = getattr(sig, "__name__", str(sig))
                        hasher.update(sig_name.encode())

                        instructions = getattr(sig, "instructions", "")
                        if instructions:
                            hasher.update(instructions.encode())

                        # Hash field names
                        for field_name in getattr(sig, "input_fields", {}).keys():
                            hasher.update(f"in:{field_name}".encode())
                        for field_name in getattr(sig, "output_fields", {}).keys():
                            hasher.update(f"out:{field_name}".encode())

                    # Hash demos if present
                    demos = getattr(predictor, "demos", None)
                    if demos:
                        hasher.update(f"demos:{len(demos)}".encode())

            return hasher.hexdigest()[:16]
        except Exception as e:
            logger.debug(f"Error computing program hash: {e}")
            return ""

    def _get_program_signature(self, program: Any) -> Any:
        """Extract the primary signature from a program for clustering.

        Returns the first predictor's signature, which is used to compute
        signature_hash for grouping eval runs by program structure.
        """
        try:
            # Try to get predictors from the program
            predictors = getattr(program, "predictors", None)
            if predictors and callable(predictors):
                for name, predictor in predictors():
                    sig = getattr(predictor, "signature", None)
                    if sig:
                        return sig
            # Fallback: check for direct signature attribute
            sig = getattr(program, "signature", None)
            if sig:
                return sig
        except Exception as e:
            logger.debug(f"Error getting program signature: {e}")
        return None

    def _compute_dataset_hash(self, devset: list[Any]) -> str:
        """Compute a hash of the dataset for comparability.

        Two eval runs with the same dataset hash are comparable.
        """
        try:
            hasher = hashlib.sha256()

            for example in devset:
                # Hash each example's input fields
                if hasattr(example, "toDict"):
                    example_dict = example.toDict()
                elif hasattr(example, "__dict__"):
                    example_dict = {
                        k: v
                        for k, v in example.__dict__.items()
                        if not k.startswith("_")
                    }
                else:
                    example_dict = {"value": str(example)}

                # Sort keys for consistent hashing
                for key in sorted(example_dict.keys()):
                    value = example_dict[key]
                    hasher.update(f"{key}:{value}".encode())

            return hasher.hexdigest()[:16]
        except Exception as e:
            logger.exception(f"Error computing dataset hash: {e}")
            return ""

    def _compute_example_hash(self, inputs: dict[str, Any]) -> str:
        """Compute a hash of a single example's inputs.

        Used to track the same example across different eval runs.
        This algorithm matches backend's compute_input_hash() to enable
        linking eval results to dataset examples.
        """
        try:
            from cmpnd.identity import serialize_value

            # Serialize Pydantic objects/dataclasses to dicts before hashing
            # This ensures hashes match whether inputs are Pydantic models or plain dicts
            serialized_inputs = {k: serialize_value(v) for k, v in inputs.items()}

            # Create canonical representation with sorted keys (inputs only)
            # This matches backend/app/models/dataset.py:compute_input_hash()
            content = {"inputs": serialized_inputs}
            canonical = json.dumps(content, sort_keys=True, default=str)
            return hashlib.sha256(canonical.encode()).hexdigest()[:16]
        except Exception as e:
            logger.debug(f"Error computing example hash: {e}")
            return ""
