"""Data models for spans and traces."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID


def _safe_serialize(value: Any, _stack: set | None = None) -> Any:
    """Recursively serialize a value to JSON-safe types.

    Handles DSPy types like Prediction, SignatureMeta, Example, etc.
    Also handles custom classes, dataclasses, and other objects.

    Uses a stack-based approach to detect true circular references (cycles),
    not just objects that appear multiple times in the structure.
    """
    # Track objects currently being serialized (the stack) to detect cycles
    if _stack is None:
        _stack = set()

    if value is None:
        return None

    # Primitives - JSON safe (no need to track these)
    if isinstance(value, (str, int, float, bool)):
        return value

    # UUID
    if isinstance(value, UUID):
        return str(value)

    # Datetime
    if isinstance(value, datetime):
        return value.isoformat()

    # Bytes
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except Exception:
            return f"<bytes: {len(value)} bytes>"

    # Enums
    if isinstance(value, Enum):
        return value.value

    # Types/classes (like SignatureMeta)
    if isinstance(value, type):
        return repr(value)

    # For compound types, check for cycles using object identity
    obj_id = id(value)
    if obj_id in _stack:
        # True cycle detected - we're currently serializing this object
        return f"<circular ref: {type(value).__name__}>"

    # Add to stack before recursing into compound types
    _stack.add(obj_id)

    try:
        # Sets and frozensets
        if isinstance(value, (set, frozenset)):
            return [_safe_serialize(v, _stack) for v in value]

        # Lists and tuples
        if isinstance(value, (list, tuple)):
            return [_safe_serialize(v, _stack) for v in value]

        # Dicts
        if isinstance(value, dict):
            return {str(k): _safe_serialize(v, _stack) for k, v in value.items()}

        # DSPy Prediction and similar - has toDict method
        if hasattr(value, "toDict") and callable(value.toDict):
            try:
                return _safe_serialize(value.toDict(), _stack)
            except Exception:
                pass  # Fall through to other methods

        # Dataclasses
        try:
            import dataclasses
            if dataclasses.is_dataclass(value) and not isinstance(value, type):
                return _safe_serialize(dataclasses.asdict(value), _stack)
        except Exception:
            pass

        # Pydantic models
        if hasattr(value, "model_dump") and callable(value.model_dump):
            try:
                return _safe_serialize(value.model_dump(), _stack)
            except Exception:
                pass

        # Pydantic v1 models
        if hasattr(value, "dict") and callable(value.dict) and hasattr(value, "__fields__"):
            try:
                return _safe_serialize(value.dict(), _stack)
            except Exception:
                pass

        # Objects with __dict__ (general objects, custom classes)
        if hasattr(value, "__dict__"):
            try:
                obj_dict = {
                    k: _safe_serialize(v, _stack)
                    for k, v in value.__dict__.items()
                    if not k.startswith("_")
                }
                # Add type info for clarity
                obj_dict["__type__"] = type(value).__name__
                return obj_dict
            except Exception:
                pass

        # Objects with __slots__ but no __dict__
        if hasattr(value, "__slots__"):
            try:
                obj_dict = {}
                for slot in value.__slots__:
                    if not slot.startswith("_") and hasattr(value, slot):
                        obj_dict[slot] = _safe_serialize(getattr(value, slot), _stack)
                obj_dict["__type__"] = type(value).__name__
                return obj_dict
            except Exception:
                pass

        # Final fallback - convert to string
        try:
            return str(value)
        except Exception:
            return f"<unserializable: {type(value).__name__}>"

    finally:
        # Remove from stack after we're done serializing this object
        _stack.discard(obj_id)


_MAX_FIELD_JSON_SIZE = 65536  # 64 KB


def _truncate_serialized(value: Any) -> Any:
    """Truncate serialized data if its JSON representation exceeds the size limit."""
    if not value:
        return value
    json_str = json.dumps(value)
    if len(json_str) > _MAX_FIELD_JSON_SIZE:
        return {"__truncated__": True, "size": len(json_str), "preview": json_str[:1000]}
    return value


class SpanType(str, Enum):
    """DSPy-specific span types matching backend schema."""

    UNKNOWN = "unknown"
    MODULE = "module"
    PREDICT = "predict"
    CHAIN_OF_THOUGHT = "chain_of_thought"
    REACT = "react"
    RLM = "rlm"
    RETRIEVE = "retrieve"
    LM_CALL = "lm_call"
    ADAPTER_FORMAT = "adapter_format"
    ADAPTER_PARSE = "adapter_parse"
    TOOL = "tool"
    SIGNATURE_VALIDATE = "signature_validate"
    DEMO_SELECT = "demo_select"
    OPTIMIZATION = "optimization"
    EVALUATION = "evaluation"


_THINNABLE_SPAN_TYPES = {SpanType.ADAPTER_FORMAT, SpanType.ADAPTER_PARSE, SpanType.LM_CALL}


class TraceStatus(str, Enum):
    """Trace execution status."""

    UNSET = "unset"
    OK = "ok"
    ERROR = "error"


@dataclass
class SpanBuilder:
    """Mutable span builder for collecting data during execution."""

    span_id: UUID
    name: str
    span_type: SpanType = SpanType.UNKNOWN
    parent_span_id: UUID | None = None
    trace_id: UUID | None = None

    start_time: datetime | None = None
    end_time: datetime | None = None

    status: TraceStatus = TraceStatus.UNSET
    error_message: str | None = None
    error_type: str | None = None

    # DSPy-specific: Signature info
    signature_name: str | None = None
    signature_instructions: str | None = None
    signature_input_fields: list[str] = field(default_factory=list)
    signature_output_fields: list[str] = field(default_factory=list)
    signature_input_field_types: list[str] = field(default_factory=list)
    signature_output_field_types: list[str] = field(default_factory=list)
    signature_input_field_descs: list[str] = field(default_factory=list)
    signature_output_field_descs: list[str] = field(default_factory=list)
    # Schemas for complex types (Pydantic models, dataclasses)
    # Each element is None for primitives, or {"type": "Place", "fields": {"name": "str"}} for complex types
    signature_input_field_schemas: list[dict[str, Any] | None] = field(default_factory=list)
    signature_output_field_schemas: list[dict[str, Any] | None] = field(default_factory=list)
    # Hash of input/output fields+types for program identity (xxhash64, signed)
    signature_hash: int = 0

    # DSPy-specific: Module info
    module_type: str | None = None
    module_name: str | None = None

    # DSPy-specific: LM call info
    model_name: str | None = None
    model_provider: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0

    # DSPy-specific: Demo info
    demo_count: int = 0
    demos: list[dict[str, Any]] = field(default_factory=list)
    selected_demo_ids: list[str] = field(default_factory=list)

    # Inputs/Outputs
    inputs: dict[str, Any] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)

    # Attributes and events
    attributes: dict[str, str] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)

    # REPL conversation history for RLM spans
    repl_history: list[dict[str, Any]] = field(default_factory=list)

    # Adapter type (e.g., "ChatAdapter", "JSONAdapter")
    adapter_type: str | None = None

    def set_inputs(self, inputs: dict[str, Any]) -> None:
        """Set span inputs."""
        self.inputs = inputs

    def set_outputs(self, outputs: Any) -> None:
        """Set span outputs."""
        if isinstance(outputs, dict):
            self.outputs = outputs
        else:
            self.outputs = {"result": outputs}

    def set_attribute(self, key: str, value: Any) -> None:
        """Set a span attribute."""
        self.attributes[key] = str(value)

    def set_error(self, exception: Exception) -> None:
        """Mark span as errored."""
        self.status = TraceStatus.ERROR
        self.error_message = str(exception)
        self.error_type = exception.__class__.__name__

    def add_event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        """Add an event to the span."""
        self.events.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "name": name,
            "attributes": attributes or {},
        })

    def _build_attributes(self) -> dict[str, str]:
        """Build attributes dict, injecting repl_history if present."""
        attrs = dict(self.attributes)
        if self.repl_history:
            attrs["repl_history"] = json.dumps(self.repl_history)
        return attrs

    def thin(self) -> None:
        """Strip redundant data from child spans to reduce payload size.

        ADAPTER_FORMAT and ADAPTER_PARSE: strip both inputs and outputs.
        LM_CALL: strip inputs (the formatted prompt) but keep outputs (LM response).
        RLM subcall LM_CALLs are NOT thinned — their prompt is the interesting part.
        PREDICT and MODULE spans are never thinned — they carry the canonical data.
        """
        if self.span_type not in _THINNABLE_SPAN_TYPES:
            return
        # RLM subcall LM_CALLs keep both inputs and outputs
        if self.span_type == SpanType.LM_CALL and self.attributes.get("rlm.subcall") == "true":
            return
        if self.span_type == SpanType.LM_CALL:
            self.inputs = None  # Strip inputs (formatted prompt), keep outputs (LM response)
        else:
            self.inputs = None
            self.outputs = None
        self.attributes["thinned"] = "true"

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return {
            "span_id": str(self.span_id),
            "trace_id": str(self.trace_id) if self.trace_id else None,
            "parent_span_id": str(self.parent_span_id) if self.parent_span_id else None,
            "name": self.name,
            "span_type": self.span_type.value,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "status": self.status.value,
            "error_message": self.error_message,
            "error_type": self.error_type,
            "signature_name": self.signature_name,
            "signature_instructions": self.signature_instructions,
            "signature_input_fields": self.signature_input_fields,
            "signature_output_fields": self.signature_output_fields,
            "signature_input_field_types": self.signature_input_field_types,
            "signature_output_field_types": self.signature_output_field_types,
            "signature_input_field_descs": self.signature_input_field_descs,
            "signature_output_field_descs": self.signature_output_field_descs,
            "signature_input_field_schemas": self.signature_input_field_schemas,
            "signature_output_field_schemas": self.signature_output_field_schemas,
            "signature_hash": self.signature_hash,
            "module_type": self.module_type,
            "module_name": self.module_name,
            "model_name": self.model_name,
            "model_provider": self.model_provider,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "cost": self.cost,
            "demos": _safe_serialize(self.demos),
            "demo_count": self.demo_count if self.demo_count else len(self.demos),
            "selected_demo_ids": self.selected_demo_ids,
            "inputs": _truncate_serialized(_safe_serialize(self.inputs)),
            "outputs": _truncate_serialized(_safe_serialize(self.outputs)),
            "attributes": _safe_serialize(self._build_attributes()),
            "events": _safe_serialize(self.events),
            "adapter_type": self.adapter_type,
        }


@dataclass
class TraceBuilder:
    """Mutable trace builder."""

    trace_id: UUID
    start_time: datetime | None = None
    end_time: datetime | None = None

    status: TraceStatus = TraceStatus.UNSET
    error_message: str | None = None

    program_name: str | None = None
    program_version: str | None = None

    # Signature info - identifies the program by its inputs/outputs
    signature_name: str | None = None
    signature_input_fields: list[str] = field(default_factory=list)
    signature_output_fields: list[str] = field(default_factory=list)
    signature_input_field_types: list[str] = field(default_factory=list)
    signature_output_field_types: list[str] = field(default_factory=list)
    # Schemas for complex types (Pydantic models, dataclasses)
    signature_input_field_schemas: list[dict[str, Any] | None] = field(default_factory=list)
    signature_output_field_schemas: list[dict[str, Any] | None] = field(default_factory=list)
    signature_hash: int = 0  # Hash of input/output fields+types - the true program identity
    signature_summary: str | None = None  # Human-readable: "input1, input2 -> output1, output2"

    # Optimization lineage - tracks which optimization produced this program
    compiled_from_run_id: str | None = None
    demo_ids: list[str] = field(default_factory=list)

    request_preview: str | None = None
    response_preview: str | None = None

    # Aggregate metrics (computed from spans)
    total_tokens: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_cost: float = 0.0
    span_count: int = 0

    # Run associations - link traces to eval and optimization runs
    eval_run_id: UUID | None = None
    optimization_run_id: UUID | None = None

    # Adapter type used (propagated from adapter spans)
    adapter_type: str | None = None

    # Export routing: True = stream spans individually, False = batch at completion
    streaming: bool = False
    _batch_spans: list["SpanBuilder"] = field(default_factory=list)

    tags: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, str] = field(default_factory=dict)

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return {
            "trace_id": str(self.trace_id),
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "status": self.status.value,
            "error_message": self.error_message,
            "program_name": self.program_name,
            "program_version": self.program_version,
            "signature_name": self.signature_name,
            "signature_input_fields": self.signature_input_fields,
            "signature_output_fields": self.signature_output_fields,
            "signature_input_field_types": self.signature_input_field_types,
            "signature_output_field_types": self.signature_output_field_types,
            "signature_input_field_schemas": self.signature_input_field_schemas,
            "signature_output_field_schemas": self.signature_output_field_schemas,
            "signature_hash": self.signature_hash,
            "signature_summary": self.signature_summary,
            "compiled_from_run_id": self.compiled_from_run_id,
            "demo_ids": self.demo_ids,
            "request_preview": (self.request_preview or "")[:500],
            "response_preview": (self.response_preview or "")[:500],
            "eval_run_id": str(self.eval_run_id) if self.eval_run_id else None,
            "optimization_run_id": str(self.optimization_run_id) if self.optimization_run_id else None,
            "adapter_type": self.adapter_type,
            "tags": self.tags,
            "metadata": self.metadata,
            "spans": [s.to_api_dict() for s in self._batch_spans] if self._batch_spans else [],
        }

    def to_start_dict(self) -> dict[str, Any]:
        """Lightweight payload for trace start — identity + signature only."""
        return {
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "program_name": self.program_name,
            "program_version": self.program_version,
            "signature_name": self.signature_name,
            "signature_input_fields": self.signature_input_fields,
            "signature_output_fields": self.signature_output_fields,
            "signature_input_field_types": self.signature_input_field_types,
            "signature_output_field_types": self.signature_output_field_types,
            "signature_hash": self.signature_hash,
            "signature_summary": self.signature_summary,
        }

    def to_finalize_dict(self) -> dict[str, Any]:
        """Payload for trace finalization — timing, metrics, previews."""
        return {
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "status": self.status.value,
            "error_message": self.error_message,
            "request_preview": (self.request_preview or "")[:500],
            "response_preview": (self.response_preview or "")[:500],
            "total_tokens": self.total_tokens,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_cost": self.total_cost,
            "span_count": self.span_count,
            "adapter_type": self.adapter_type,
            "compiled_from_run_id": self.compiled_from_run_id,
            "demo_ids": self.demo_ids,
            "eval_run_id": str(self.eval_run_id) if self.eval_run_id else None,
            "optimization_run_id": str(self.optimization_run_id) if self.optimization_run_id else None,
            "tags": self.tags,
            "metadata": self.metadata,
        }

    def to_stats_dict(self) -> dict[str, Any]:
        """Lightweight stats payload (~200 bytes). Never dropped."""
        return {
            "trace_id": str(self.trace_id),
            "timestamp": self.start_time.isoformat() if self.start_time else None,
            "signature_hash": self.signature_hash,
            "program_name": self.program_name or "",
            "status": self.status.value,
            "total_tokens": self.total_tokens,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_cost": self.total_cost,
            "model_name": "",
            "eval_run_id": str(self.eval_run_id) if self.eval_run_id else None,
            "optimization_run_id": str(self.optimization_run_id) if self.optimization_run_id else None,
            "span_count": self.span_count,
        }


class EvalRunStatus(str, Enum):
    """Evaluation run status."""

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EvalExampleStatus(str, Enum):
    """Evaluation example status."""

    PENDING = "pending"
    COMPLETED = "completed"
    ERROR = "error"


@dataclass
class EvalExampleBuilder:
    """Builder for individual evaluation example results."""

    example_id: UUID
    eval_run_id: UUID
    example_index: int

    trace_id: UUID | None = None
    example_hash: str | None = None

    # Input/Output
    inputs: dict[str, Any] = field(default_factory=dict)
    expected_output: dict[str, Any] = field(default_factory=dict)
    actual_output: dict[str, Any] = field(default_factory=dict)

    # Scoring
    score: float = 0.0
    passed: bool = False

    # Metrics
    duration_ns: int = 0
    total_tokens: int = 0
    cost: float = 0.0

    # Status
    status: EvalExampleStatus = EvalExampleStatus.PENDING
    error_message: str | None = None

    def set_result(
        self,
        score: float,
        passed: bool,
        actual_output: dict[str, Any],
        duration_ns: int = 0,
        total_tokens: int = 0,
        cost: float = 0.0,
    ) -> None:
        """Set the evaluation result for this example."""
        self.score = score
        self.passed = passed
        self.actual_output = actual_output
        self.duration_ns = duration_ns
        self.total_tokens = total_tokens
        self.cost = cost
        self.status = EvalExampleStatus.COMPLETED

    def set_error(self, exception: Exception) -> None:
        """Mark this example as errored."""
        self.status = EvalExampleStatus.ERROR
        self.error_message = str(exception)

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return {
            "example_id": str(self.example_id),
            "eval_run_id": str(self.eval_run_id),
            "trace_id": str(self.trace_id) if self.trace_id else None,
            "example_index": self.example_index,
            "example_hash": self.example_hash,
            "inputs": _safe_serialize(self.inputs),
            "expected_output": _safe_serialize(self.expected_output),
            "actual_output": _safe_serialize(self.actual_output),
            "score": self.score,
            "passed": self.passed,
            "duration_ns": self.duration_ns,
            "total_tokens": self.total_tokens,
            "cost": self.cost,
            "status": self.status.value,
            "error_message": self.error_message,
        }


@dataclass
class EvalRunBuilder:
    """Mutable builder for tracking evaluation runs."""

    eval_run_id: UUID
    start_time: datetime | None = None

    # Eval Identity (defines comparability)
    program_name: str | None = None
    program_hash: str | None = None
    metric_name: str | None = None
    dataset_hash: str | None = None
    dataset_size: int = 0
    signature_hash: int = 0  # xxhash64 of signature - program identity
    signature_summary: str | None = None  # Human-readable: "input1, input2 -> output1"

    # Model Configuration
    model_name: str | None = None
    model_provider: str | None = None

    # Adapter type used (propagated from traces)
    adapter_type: str | None = None

    # Optimization link (set when eval is conducted during an optimization run)
    optimization_run_id: UUID | None = None

    # Status
    status: EvalRunStatus = EvalRunStatus.RUNNING
    error_message: str | None = None
    end_time: datetime | None = None
    duration_ms: int = 0

    # Aggregate Results
    score: float = 0.0
    total_examples: int = 0
    passed_examples: int = 0
    failed_examples: int = 0
    error_examples: int = 0

    # Timing Metrics (computed at finalize)
    avg_duration_ns: int = 0
    p50_duration_ns: int = 0
    p95_duration_ns: int = 0

    # Token/Cost Aggregates
    total_tokens: int = 0
    total_cost: float = 0.0
    avg_tokens_per_example: float = 0.0
    avg_cost_per_example: float = 0.0

    # Metadata
    tags: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, str] = field(default_factory=dict)

    # Example results (built up during evaluation)
    _examples: list[EvalExampleBuilder] = field(default_factory=list)
    _example_durations: list[int] = field(default_factory=list)

    # Dataset sync fields (populated by callback for payload building)
    _devset: list[Any] = field(default_factory=list)
    _input_fields: set[str] = field(default_factory=set)
    _dataset_exists: bool | None = None  # None = not checked yet

    def add_example_result(self, example: EvalExampleBuilder) -> None:
        """Add an example result to the eval run."""
        self._examples.append(example)
        self._example_durations.append(example.duration_ns)
        self.total_tokens += example.total_tokens
        self.total_cost += example.cost

        if example.status == EvalExampleStatus.ERROR:
            self.error_examples += 1
        elif example.passed:
            self.passed_examples += 1
        else:
            self.failed_examples += 1

    def finalize(
        self,
        overall_score: float,
        status: EvalRunStatus = EvalRunStatus.COMPLETED,
        error_message: str | None = None,
    ) -> None:
        """Finalize the eval run with aggregate metrics."""
        self.end_time = datetime.now(timezone.utc)
        if self.start_time:
            self.duration_ms = int(
                (self.end_time - self.start_time).total_seconds() * 1000
            )

        self.score = overall_score
        self.status = status
        self.error_message = error_message
        self.total_examples = len(self._examples)

        # Compute timing percentiles
        if self._example_durations:
            sorted_durations = sorted(self._example_durations)
            n = len(sorted_durations)
            self.avg_duration_ns = sum(sorted_durations) // n
            self.p50_duration_ns = sorted_durations[n // 2]
            self.p95_duration_ns = sorted_durations[int(n * 0.95)]

        # Compute averages
        if self.total_examples > 0:
            self.avg_tokens_per_example = self.total_tokens / self.total_examples
            self.avg_cost_per_example = self.total_cost / self.total_examples

    def set_error(self, exception: Exception) -> None:
        """Mark the eval run as failed."""
        self.status = EvalRunStatus.FAILED
        self.error_message = str(exception)
        self.end_time = datetime.now(timezone.utc)
        if self.start_time:
            self.duration_ms = int(
                (self.end_time - self.start_time).total_seconds() * 1000
            )

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        d = {
            "eval_run_id": str(self.eval_run_id),
            "program_name": self.program_name or "",
            "program_hash": self.program_hash,
            "metric_name": self.metric_name or "",
            "dataset_hash": self.dataset_hash or "",
            "dataset_size": self.dataset_size,
            "signature_hash": self.signature_hash,
            "signature_summary": self.signature_summary,
            "model_name": self.model_name,
            "model_provider": self.model_provider,
            "adapter_type": self.adapter_type,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration_ms": self.duration_ms,
            "status": self.status.value,
            "error_message": self.error_message,
            "score": self.score,
            "total_examples": self.total_examples,
            "passed_examples": self.passed_examples,
            "failed_examples": self.failed_examples,
            "error_examples": self.error_examples,
            "avg_duration_ns": self.avg_duration_ns,
            "p50_duration_ns": self.p50_duration_ns,
            "p95_duration_ns": self.p95_duration_ns,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
            "avg_tokens_per_example": self.avg_tokens_per_example,
            "avg_cost_per_example": self.avg_cost_per_example,
            "tags": self.tags,
            "metadata": self.metadata,
            "examples": [ex.to_api_dict() for ex in self._examples],
            "optimization_run_id": str(self.optimization_run_id) if self.optimization_run_id else None,
        }

        # Only include dataset block for standalone evals (not part of optimization)
        if self.optimization_run_id is None and self._devset and self.dataset_hash:
            from cmpnd.dataset_sync import build_dataset_payload

            include_examples = not self._dataset_exists
            d["dataset"] = build_dataset_payload(
                devset=self._devset,
                dataset_hash=self.dataset_hash,
                input_fields=self._input_fields,
                include_examples=include_examples,
            )

        return d
