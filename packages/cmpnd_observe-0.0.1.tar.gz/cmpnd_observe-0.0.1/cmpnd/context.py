"""Trace and span context management using contextvars."""

from __future__ import annotations

from contextvars import ContextVar
from typing import TYPE_CHECKING
from uuid import UUID

if TYPE_CHECKING:
    from cmpnd.models import EvalRunBuilder, SpanBuilder, TraceBuilder

# Current trace context
_current_trace: ContextVar[TraceBuilder | None] = ContextVar(
    "cmpnd_current_trace", default=None
)

# Stack of active spans (for nested spans)
_span_stack: ContextVar[list[SpanBuilder] | None] = ContextVar(
    "cmpnd_span_stack", default=None
)

# Current eval run context
_current_eval_run: ContextVar[EvalRunBuilder | None] = ContextVar(
    "cmpnd_current_eval_run", default=None
)

# Current optimization run context (set during optimization, used to link evals)
_current_optimization_run_id: ContextVar[UUID | None] = ContextVar(
    "cmpnd_current_optimization_run_id", default=None
)


def get_current_trace() -> TraceBuilder | None:
    """Get the current trace."""
    return _current_trace.get()


def set_current_trace(trace: TraceBuilder | None) -> None:
    """Set the current trace."""
    _current_trace.set(trace)


def get_current_span() -> SpanBuilder | None:
    """Get the current (innermost) span."""
    stack = _span_stack.get()
    if stack is None:
        return None
    return stack[-1] if stack else None


def push_span(span: SpanBuilder) -> None:
    """Push a span onto the context stack."""
    stack = _span_stack.get()
    if stack is None:
        stack = []
        _span_stack.set(stack)
    stack.append(span)


def pop_span() -> SpanBuilder | None:
    """Pop the innermost span from the context stack."""
    stack = _span_stack.get()
    if stack:
        return stack.pop()
    return None


def get_current_eval_run() -> EvalRunBuilder | None:
    """Get the current eval run."""
    from cmpnd.models import EvalRunBuilder

    return _current_eval_run.get()


def set_current_eval_run(eval_run: EvalRunBuilder | None) -> None:
    """Set the current eval run."""
    _current_eval_run.set(eval_run)


def get_current_optimization_run_id() -> UUID | None:
    """Get the current optimization run ID (if running inside an optimization)."""
    return _current_optimization_run_id.get()


def set_current_optimization_run_id(optimization_run_id: UUID | None) -> None:
    """Set the current optimization run ID."""
    _current_optimization_run_id.set(optimization_run_id)


def clear_context() -> None:
    """Clear all trace/span context. Useful for testing."""
    _current_trace.set(None)
    _span_stack.set(None)
    _current_eval_run.set(None)
    _current_optimization_run_id.set(None)
