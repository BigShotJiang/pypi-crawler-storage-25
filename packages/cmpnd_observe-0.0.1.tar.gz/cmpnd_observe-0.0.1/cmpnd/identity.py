"""Identity and hash computation utilities for cmpnd-track.

This module provides a single source of truth for all identity-related
hash computations, ensuring consistency across the SDK.

Key functions:
- get_type_string: Convert type annotations to string representation
- compute_signature_hash: 64-bit hash for signature identity (uses xxhash)
- compute_component_hash: SHA256[:16] for model sweep grouping
- compute_valset_hash: SHA256[:16] for validation set identity
- compute_dataset_hash: SHA256[:16] for evaluation dataset identity
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

import xxhash


def get_type_string(annotation: Any) -> str:
    """Convert a type annotation to a string representation.

    Args:
        annotation: A Python type annotation (str, List[str], Optional[int], etc.)

    Returns:
        String representation of the type. Returns "str" for None annotations
        (untyped fields default to string type).
    """
    if annotation is None:
        return "str"  # Default type for untyped fields

    # Handle typing module types (List, Dict, Optional, etc.)
    if hasattr(annotation, "__origin__"):
        origin = annotation.__origin__
        args = getattr(annotation, "__args__", ())

        # Get the origin name
        origin_name = getattr(origin, "__name__", str(origin))

        if args:
            args_str = ", ".join(get_type_string(arg) for arg in args)
            return f"{origin_name}[{args_str}]"
        return origin_name

    # Handle regular types
    if hasattr(annotation, "__name__"):
        return annotation.__name__

    # Fallback to string representation, cleaning up typing module prefix
    return str(annotation).replace("typing.", "")


def get_field_schema(annotation: Any) -> dict[str, Any] | None:
    """Extract schema for complex types (Pydantic models, dataclasses).

    For composite types like Pydantic BaseModels, returns their field structure
    so that nested field paths (e.g., "place_one.name") can be used in mappings.

    Args:
        annotation: A Python type annotation

    Returns:
        None for primitive types, or a schema dict for complex types:
        {"type": "Place", "fields": {"name": "str", "address": "str"}}
    """
    if annotation is None:
        return None

    # Handle Optional[X] - unwrap and check the inner type
    if hasattr(annotation, "__origin__"):
        origin = annotation.__origin__
        # Check for Union types (Optional is Union[X, None])
        if str(origin) in ("typing.Union", "Union"):
            args = getattr(annotation, "__args__", ())
            # Filter out NoneType
            non_none_args = [a for a in args if a is not type(None)]
            if len(non_none_args) == 1:
                return get_field_schema(non_none_args[0])
        # For List[X] / Set[X], unwrap and check the inner type
        if origin in (list, set, frozenset) or str(origin) in ("typing.List", "typing.Set"):
            args = getattr(annotation, "__args__", ())
            if args:
                inner_schema = get_field_schema(args[0])
                if inner_schema:
                    wrapper = "list" if origin in (list,) or "List" in str(origin) else "set"
                    inner_schema["type"] = f"{wrapper}[{inner_schema['type']}]"
                    return inner_schema
        # For other generic types (Dict, etc.), don't expand
        return None

    # Check if it's a Pydantic v2 model
    if hasattr(annotation, "model_fields"):
        fields = {}
        for name, field_info in annotation.model_fields.items():
            field_type = get_type_string(field_info.annotation)
            fields[name] = field_type
        return {
            "type": getattr(annotation, "__name__", str(annotation)),
            "fields": fields,
        }

    # Check if it's a Pydantic v1 model
    if hasattr(annotation, "__fields__"):
        fields = {}
        for name, field_info in annotation.__fields__.items():
            field_type = get_type_string(field_info.outer_type_)
            fields[name] = field_type
        return {
            "type": getattr(annotation, "__name__", str(annotation)),
            "fields": fields,
        }

    # Check if it's a dataclass
    if hasattr(annotation, "__dataclass_fields__"):
        fields = {}
        for name, field_info in annotation.__dataclass_fields__.items():
            field_type = get_type_string(field_info.type)
            fields[name] = field_type
        return {
            "type": getattr(annotation, "__name__", str(annotation)),
            "fields": fields,
        }

    # Primitive type or unknown - no schema needed
    return None


def _unsigned_to_signed_int64(value: int) -> int:
    """Convert unsigned 64-bit int to signed 64-bit int for Postgres BIGINT."""
    if value > 0x7FFFFFFFFFFFFFFF:  # 2^63 - 1 (max signed int64)
        return value - 0x10000000000000000  # subtract 2^64
    return value


def compute_signature_hash(signature: Any) -> int:
    """Compute a deterministic 64-bit hash for a DSPy signature.

    This hash uniquely identifies a signature by its input/output field
    structure (names and types). It uses xxhash for deterministic behavior
    across Python versions and processes.

    Args:
        signature: A DSPy signature object with input_fields and output_fields

    Returns:
        Signed 64-bit int hash (compatible with Postgres BIGINT).
        Returns 0 for None signatures.

    Format:
        "name1:type1,name2:type2,->name3:type3,name4:type4"
        Fields are sorted alphabetically within inputs and outputs.
    """
    if signature is None:
        return 0

    hash_input = build_signature_string(signature)
    unsigned_hash = xxhash.xxh64(hash_input.encode()).intdigest()
    return _unsigned_to_signed_int64(unsigned_hash)


def build_signature_string(signature: Any) -> str:
    """Build the canonical string representation of a signature for hashing.

    Args:
        signature: A DSPy signature object

    Returns:
        String in format "name1:type1,name2:type2,->name3:type3,name4:type4"
    """
    hash_parts = []

    # Input fields with types (sorted by name)
    if hasattr(signature, "input_fields"):
        for name in sorted(signature.input_fields.keys()):
            field_info = signature.input_fields[name]
            type_str = get_type_string(getattr(field_info, "annotation", None))
            hash_parts.append(f"{name}:{type_str}")

    hash_parts.append("->")

    # Output fields with types (sorted by name)
    if hasattr(signature, "output_fields"):
        for name in sorted(signature.output_fields.keys()):
            field_info = signature.output_fields[name]
            type_str = get_type_string(getattr(field_info, "annotation", None))
            hash_parts.append(f"{name}:{type_str}")

    return ",".join(hash_parts)


def build_signature_summary(signature: Any) -> str:
    """Build a human-readable signature summary.

    Args:
        signature: A DSPy signature object

    Returns:
        String in format "input1, input2 -> output1, output2"
    """
    if signature is None:
        return ""

    try:
        input_fields = getattr(signature, "input_fields", {})
        output_fields = getattr(signature, "output_fields", {})

        if input_fields or output_fields:
            inputs = ", ".join(input_fields.keys())
            outputs = ", ".join(output_fields.keys())
            return f"{inputs} -> {outputs}"
    except Exception:
        pass
    return ""


def compute_component_hash(components: list[dict[str, Any]]) -> str:
    """Compute a deterministic hash from component input/output field names.

    This hash is used to group optimization runs that optimize the same
    signature structure (regardless of the class name which may become
    'StringSignature' after optimization).

    Args:
        components: List of component dicts with 'name', 'inputs', 'outputs' keys

    Returns:
        16-character hex hash of the normalized component structure
    """
    normalized = []
    for comp in sorted(components, key=lambda c: c.get("name", "")):
        inputs = sorted(comp.get("inputs", []))
        outputs = sorted(comp.get("outputs", []))
        normalized.append(f"{comp.get('name', '')}:{','.join(inputs)}->{','.join(outputs)}")
    signature_str = "|".join(normalized)
    return hashlib.sha256(signature_str.encode()).hexdigest()[:16]


def compute_valset_hash(valset: list[Any]) -> str:
    """Compute a deterministic hash from validation set examples.

    This hash identifies runs using the same validation dataset,
    enabling meaningful score comparisons across model configurations.

    Args:
        valset: List of DSPy Example objects or dicts

    Returns:
        16-character hex hash of the validation set
    """
    examples_strs = []
    for ex in valset:
        # Get inputs from the example
        if hasattr(ex, "inputs"):
            inputs_dict = dict(ex.inputs())
        elif hasattr(ex, "toDict"):
            inputs_dict = ex.toDict()
        elif isinstance(ex, dict):
            inputs_dict = ex
        else:
            inputs_dict = {}

        # Serialize to handle complex types
        serializable_dict = serialize_value(inputs_dict)
        examples_strs.append(json.dumps(serializable_dict, sort_keys=True))

    # Sort for deterministic ordering
    examples_strs.sort()
    combined = "|".join(examples_strs)
    return hashlib.sha256(combined.encode()).hexdigest()[:16]


def compute_dataset_hash(dataset: list[Any]) -> str:
    """Compute a hash of a dataset for evaluation comparability.

    Args:
        dataset: List of examples (DSPy Examples, dicts, or objects)

    Returns:
        16-character hex hash of the dataset
    """
    hasher = hashlib.sha256()

    for example in dataset:
        # Get dict representation
        if hasattr(example, "toDict"):
            example_dict = example.toDict()
        elif hasattr(example, "__dict__"):
            example_dict = {
                k: v for k, v in example.__dict__.items() if not k.startswith("_")
            }
        elif isinstance(example, dict):
            example_dict = example
        else:
            example_dict = {"value": str(example)}

        # Sort keys for consistent hashing
        for key in sorted(example_dict.keys()):
            value = example_dict[key]
            hasher.update(f"{key}:{value}".encode())

    return hasher.hexdigest()[:16]


def compute_example_hash(inputs: dict[str, Any]) -> str:
    """Compute a hash of a single example's inputs.

    Args:
        inputs: Dictionary of input field values

    Returns:
        16-character hex hash of the inputs
    """
    hasher = hashlib.sha256()

    for key in sorted(inputs.keys()):
        value = inputs[key]
        hasher.update(f"{key}:{value}".encode())

    return hasher.hexdigest()[:16]


def serialize_value(value: Any) -> Any:
    """Recursively serialize a value to JSON-compatible types.

    Handles Pydantic models, dataclasses, and other complex types.

    Args:
        value: Any Python value

    Returns:
        JSON-serializable representation of the value
    """
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [serialize_value(v) for v in value]
    if isinstance(value, dict):
        return {k: serialize_value(v) for k, v in value.items()}
    # Handle Pydantic models
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if hasattr(value, "dict"):
        return value.dict()
    # Handle dataclasses
    if hasattr(value, "__dataclass_fields__"):
        from dataclasses import asdict

        return asdict(value)
    # Fallback to string representation
    return str(value)


def hash_demo(demo: Any) -> str:
    """Create a short hash ID for a demo example.

    Args:
        demo: A DSPy Example or similar object

    Returns:
        12-character hex hash of the demo
    """
    try:
        # Try to get a dict representation
        if hasattr(demo, "toDict"):
            demo_dict = demo.toDict()
        elif hasattr(demo, "__dict__"):
            demo_dict = demo.__dict__
        else:
            demo_dict = {"value": str(demo)}

        # Create deterministic JSON string
        demo_str = json.dumps(demo_dict, sort_keys=True, default=str)
        return hashlib.sha256(demo_str.encode()).hexdigest()[:12]
    except Exception:
        return hashlib.sha256(str(demo).encode()).hexdigest()[:12]
