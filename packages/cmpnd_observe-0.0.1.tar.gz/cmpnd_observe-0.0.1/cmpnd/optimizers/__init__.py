"""
cmpnd.optimizers - Instrumented DSPy optimizers.

Provides wrappers around DSPy optimizers (GEPA, MIPROv2, etc.) that capture
detailed optimization data for analysis and debugging.

Usage:
    >>> from cmpnd.optimizers import TrackedGEPA
    >>> import dspy
    >>>
    >>> gepa = TrackedGEPA(auto="light", reflection_lm=lm)
    >>> optimized = gepa.compile(student, trainset, valset)
    >>>
    >>> # Optimization data is automatically exported to cmpnd
"""

from cmpnd.optimizers.gepa import TrackedGEPA
from cmpnd.optimizers.gepa_callback import CmpndGEPACallback
from cmpnd.optimizers.tracker import (
    CandidateData,
    IterationData,
    OptimizationTracker,
)

__all__ = [
    "TrackedGEPA",
    "CmpndGEPACallback",
    "OptimizationTracker",
    "IterationData",
    "CandidateData",
]
