"""Optimization run tracking for GEPA and other optimizers."""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from cmpnd import identity

logger = logging.getLogger(__name__)


def _sanitize_for_json(obj: Any) -> Any:
    """Recursively sanitize an object for JSON serialization.

    Handles numpy types, datetimes, UUIDs, and other common non-serializable types.
    """
    if obj is None:
        return None

    # Handle numpy types (check for numpy without importing)
    obj_type = type(obj).__name__
    obj_module = type(obj).__module__

    if obj_module.startswith('numpy'):
        # numpy scalar types
        if 'int' in obj_type.lower():
            return int(obj)
        if 'float' in obj_type.lower():
            return float(obj)
        if 'bool' in obj_type.lower():
            return bool(obj)
        if 'str' in obj_type.lower():
            return str(obj)
        # numpy arrays
        if hasattr(obj, 'tolist'):
            return _sanitize_for_json(obj.tolist())
        # Fallback for other numpy types
        return str(obj)

    # Handle standard types
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, (datetime,)):
        return obj.isoformat()
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, dict):
        return {str(k): _sanitize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sanitize_for_json(item) for item in obj]
    if isinstance(obj, set):
        return [_sanitize_for_json(item) for item in obj]

    # For unknown types, try to convert to string
    try:
        return str(obj)
    except Exception:
        return None


@dataclass
class IterationData:
    """Data captured for a single GEPA iteration.

    Each iteration represents one proposal cycle:
    1. Evaluate current candidate on a minibatch
    2. Build reflective dataset from evaluation results
    3. Use reflection LM to propose improved instructions
    """

    iteration: int
    candidate_idx: int
    components_updated: list[str] = field(default_factory=list)

    # Evaluation data
    eval_batch_size: int = 0
    eval_scores: list[float] = field(default_factory=list)
    eval_mean_score: float = 0.0
    eval_trace_ids: list[UUID] = field(default_factory=list)

    # Reflective dataset - the core GEPA data
    # Structure: {component_name: [{Inputs: ..., Generated_Outputs: ..., Feedback: ...}]}
    reflective_dataset: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # Proposal data
    parent_instructions: dict[str, str] = field(default_factory=dict)
    proposed_instructions: dict[str, str] = field(default_factory=dict)

    # Timing
    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    end_time: datetime | None = None
    duration_ms: int = 0

    # New fields from GEPA callbacks
    accepted: bool | None = None
    rejection_reason: str | None = None
    minibatch_ids: list[Any] = field(default_factory=list)
    budget_remaining: int | None = None

    # Subsample scores for rejected iterations (before = parent, after = proposed)
    subsample_score_before: float | None = None
    subsample_score_after: float | None = None

    def finalize(self) -> None:
        """Finalize iteration timing."""
        self.end_time = datetime.now(timezone.utc)
        if self.start_time:
            self.duration_ms = int(
                (self.end_time - self.start_time).total_seconds() * 1000
            )
        if self.eval_scores:
            self.eval_mean_score = sum(self.eval_scores) / len(self.eval_scores)

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return {
            "iteration_number": int(self.iteration),
            "candidate_idx": int(self.candidate_idx),
            "components_updated": list(self.components_updated) if self.components_updated else [],
            "eval_batch_size": int(self.eval_batch_size) if self.eval_batch_size else 0,
            "eval_scores": [float(s) for s in self.eval_scores] if self.eval_scores else [],
            "eval_mean_score": float(self.eval_mean_score) if self.eval_mean_score else 0.0,
            "eval_trace_ids": [str(tid) for tid in self.eval_trace_ids],
            "reflective_dataset": _sanitize_for_json(self.reflective_dataset),
            "parent_instructions": _sanitize_for_json(self.parent_instructions),
            "proposed_instructions": _sanitize_for_json(self.proposed_instructions),
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration_ms": int(self.duration_ms) if self.duration_ms else 0,
            "accepted": self.accepted,
            "rejection_reason": self.rejection_reason,
            "minibatch_ids": [_sanitize_for_json(x) for x in self.minibatch_ids] if self.minibatch_ids else [],
            "budget_remaining": self.budget_remaining,
            "subsample_score_before": self.subsample_score_before,
            "subsample_score_after": self.subsample_score_after,
        }


@dataclass
class CandidateData:
    """Data for a single optimization candidate.

    A candidate represents a specific set of instructions/prompts
    that were tested during optimization.
    """

    candidate_idx: int
    instructions: dict[str, str]  # component_name -> instruction text
    parent_idx: int | None = None
    discovery_iteration: int = 0

    # Validation scores
    val_aggregate_score: float = 0.0
    val_subscores: list[float] = field(default_factory=list)

    # Whether this candidate is in the Pareto frontier
    is_pareto_member: bool = False

    # Per-example validation scores (from on_valset_evaluated)
    val_scores_by_id: dict[str, float] = field(default_factory=dict)
    # When this candidate was displaced from the Pareto front
    displaced_from_pareto_at: int | None = None

    # Subsample scores at acceptance time (minibatch score vs full valset)
    subsample_score_before: float | None = None  # parent's subsample score
    subsample_score_after: float | None = None  # this candidate's subsample score

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary."""
        return {
            "candidate_idx": int(self.candidate_idx),
            "instructions": _sanitize_for_json(self.instructions),
            "parent_idx": int(self.parent_idx) if self.parent_idx is not None else None,
            "discovery_iteration": int(self.discovery_iteration) if self.discovery_iteration else 0,
            "val_aggregate_score": float(self.val_aggregate_score) if self.val_aggregate_score else 0.0,
            "val_subscores": [float(s) for s in self.val_subscores] if self.val_subscores else [],
            "is_pareto_member": bool(self.is_pareto_member),
            "val_scores_by_id": _sanitize_for_json(self.val_scores_by_id),
            "displaced_from_pareto_at": self.displaced_from_pareto_at,
            "subsample_score_before": self.subsample_score_before,
            "subsample_score_after": self.subsample_score_after,
        }


class OptimizationTracker:
    """Tracks a GEPA (or other optimizer) optimization run.

    Collects data throughout optimization and exports it to the cmpnd backend
    when optimization completes.

    Usage:
        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="MyProgram",
            config={"auto": "light", "seed": 42}
        )

        # During optimization, capture events:
        tracker.capture_evaluation(...)
        tracker.capture_reflective_dataset(...)
        tracker.capture_proposal_start(...)
        tracker.capture_proposal_end(...)

        # After optimization:
        tracker.capture_final_results(gepa_result)
        tracker.finalize()  # Exports to backend
    """

    def __init__(
        self,
        optimizer_type: str,
        program_name: str,
        config: dict[str, Any] | None = None,
        model_name: str = "",
        reflection_model_name: str = "",
        valset_hash: str = "",
        component_signature_hash: str = "",
        program_signature_hash: int = 0,
    ):
        self.optimization_run_id = uuid4()
        self.optimizer_type = optimizer_type
        self.program_name = program_name
        self.config = config or {}
        self.model_name = model_name
        self.reflection_model_name = reflection_model_name
        self.valset_hash = valset_hash
        self.component_signature_hash = component_signature_hash  # SHA256[:16] for model sweep grouping
        # Program signature hash - matches trace format (64-bit int from input/output fields+types)
        self.program_signature_hash = program_signature_hash
        self.start_time = datetime.now(timezone.utc)

        # Collected data
        self.iterations: list[IterationData] = []
        self.candidates: list[CandidateData] = []
        self._current_iteration: IterationData | None = None

        # Track candidate indices we've seen during evaluation
        self._candidate_instructions: dict[int, dict[str, str]] = {}

        # Status
        self.status = "running"
        self.error_message: str | None = None
        self.end_time: datetime | None = None

        # Final results
        self.best_candidate_idx: int | None = None
        self.best_score: float = 0.0
        self.total_metric_calls: int = 0
        self.pareto_frontier: list[int] = []

        # Progress tracking
        self.max_metric_calls: int = 0  # Total budget
        self.current_metric_calls: int = 0  # Running count
        self._started: bool = False  # Whether start() has been called
        self._finalized: bool = False  # Whether finalize() has been called

        # Compiled program state (JSON from dump_state)
        self.compiled_program_state: dict[str, Any] | None = None

        # Link to the optimization run whose output was used as this run's starting program
        self.compiled_from_run_id: str | None = None

        # Token usage from LM calls not captured in traces (e.g., reflection LM)
        # Structure: {model_name: {"prompt_tokens": int, "completion_tokens": int}}
        self.untraced_lm_usage: dict[str, dict[str, int]] = {}

        logger.info(
            f"OptimizationTracker started: {optimizer_type} on {program_name}, "
            f"run_id={self.optimization_run_id}"
        )

    @staticmethod
    def compute_signature_hash(components: list[dict[str, Any]]) -> str:
        """Compute a deterministic hash from component input/output field names.

        This hash is used to group optimization runs that optimize the same
        signature structure (regardless of the class name which may become
        'StringSignature' after optimization).

        Args:
            components: List of component dicts with 'name', 'inputs', 'outputs' keys

        Returns:
            16-character hex hash of the normalized signature structure
        """
        return identity.compute_component_hash(components)

    @staticmethod
    def compute_program_signature_hash(signature: Any) -> int:
        """Compute program signature hash matching trace format.

        This hash is compatible with traces.signature_hash, allowing us to
        join optimization runs to traces by program identity.

        Args:
            signature: A DSPy signature object with input_fields and output_fields

        Returns:
            64-bit unsigned int hash using xxhash for determinism
        """
        return identity.compute_signature_hash(signature)

    @staticmethod
    def compute_valset_hash(valset: list[Any]) -> str:
        """Compute a deterministic hash from validation set examples.

        This hash is used to identify runs that used the same validation set,
        enabling meaningful score comparisons across different model configurations.

        Args:
            valset: List of DSPy Example objects

        Returns:
            16-character hex hash of the validation set inputs
        """
        return identity.compute_valset_hash(valset)

    def capture_evaluation(
        self,
        iteration: int,
        candidate_idx: int,
        batch_size: int,
        scores: list[float],
        has_trajectories: bool,
        candidate_instructions: dict[str, str] | None = None,
        eval_trace_ids: list | None = None,
    ) -> None:
        """Capture an evaluation event.

        Called when DspyAdapter.evaluate() completes.
        """
        # Start new iteration if needed
        if self._current_iteration is None or self._current_iteration.iteration != iteration:
            # Finalize previous iteration if exists
            if self._current_iteration is not None:
                self._current_iteration.finalize()

            self._current_iteration = IterationData(
                iteration=iteration,
                candidate_idx=candidate_idx,
                components_updated=[],
            )
            self.iterations.append(self._current_iteration)

        self._current_iteration.eval_batch_size = batch_size
        self._current_iteration.eval_scores = scores

        # Store eval trace IDs for linking traces to this iteration
        if eval_trace_ids:
            self._current_iteration.eval_trace_ids = list(eval_trace_ids)

        # Track candidate instructions
        if candidate_instructions:
            self._candidate_instructions[candidate_idx] = candidate_instructions

        logger.debug(
            f"Captured evaluation: iteration={iteration}, candidate={candidate_idx}, "
            f"batch_size={batch_size}, mean_score={sum(scores)/len(scores) if scores else 0:.3f}"
        )

    def capture_reflective_dataset(
        self,
        iteration: int,
        candidate_idx: int,
        components: list[str],
        dataset: dict[str, list[dict[str, Any]]],
    ) -> None:
        """Capture the reflective dataset used for a proposal.

        The reflective dataset contains input/output/feedback triplets
        that GEPA uses to propose improved instructions.

        Called when DspyAdapter.make_reflective_dataset() completes.
        """
        if self._current_iteration and self._current_iteration.iteration == iteration:
            # Deep copy to avoid mutation
            self._current_iteration.reflective_dataset = json.loads(
                json.dumps(dataset, default=str)
            )
            self._current_iteration.components_updated = components

            # Count examples
            total_examples = sum(len(examples) for examples in dataset.values())
            logger.debug(
                f"Captured reflective dataset: iteration={iteration}, "
                f"components={components}, examples={total_examples}"
            )

    def capture_proposal_start(
        self,
        iteration: int,
        parent_candidate: dict[str, str],
        components: list[str],
    ) -> None:
        """Capture the start of a proposal (before calling reflection LM).

        Called before DspyAdapter.propose_new_texts().
        """
        if self._current_iteration and self._current_iteration.iteration == iteration:
            self._current_iteration.parent_instructions = parent_candidate.copy()

    def capture_proposal_end(
        self,
        iteration: int,
        new_instructions: dict[str, str],
    ) -> None:
        """Capture the result of a proposal (after calling reflection LM).

        Called after DspyAdapter.propose_new_texts() returns.
        """
        if self._current_iteration and self._current_iteration.iteration == iteration:
            self._current_iteration.proposed_instructions = new_instructions.copy()
            self._current_iteration.finalize()

            # Log instruction changes
            for component in self._current_iteration.components_updated:
                old = self._current_iteration.parent_instructions.get(component, "")
                new = new_instructions.get(component, "")
                if old != new:
                    logger.debug(
                        f"Instruction changed for {component}: "
                        f"'{old[:50]}...' -> '{new[:50]}...'"
                    )

    def capture_final_results(self, gepa_result: Any) -> None:
        """Capture final results from DspyGEPAResult.

        Called after GEPA.compile() completes with the detailed_results.
        """
        if gepa_result is None:
            logger.warning("capture_final_results called with None result")
            return

        # Debug: log all available attributes and their values
        result_attrs = [attr for attr in dir(gepa_result) if not attr.startswith("_")]
        logger.info(f"GEPA result attributes: {result_attrs}")

        # Log attribute values for score-related fields
        for attr in result_attrs:
            try:
                val = getattr(gepa_result, attr)
                if not callable(val) and val is not None:
                    # Only log if it looks like it might contain scores
                    if "score" in attr.lower() or "val" in attr.lower():
                        val_preview = str(val)[:200] if len(str(val)) > 200 else str(val)
                        logger.info(f"  {attr} = {val_preview}")
            except Exception:
                pass

        # Extract candidates - try multiple attribute names
        candidates_list = getattr(gepa_result, "candidates", None)
        if candidates_list is None:
            candidates_list = getattr(gepa_result, "candidate_programs", [])
        if not candidates_list:
            candidates_list = []

        # Extract parent indices
        parents_list = getattr(gepa_result, "parents", None)
        if parents_list is None:
            parents_list = getattr(gepa_result, "parent_indices", [])
        if not parents_list:
            parents_list = []

        # Extract scores - try multiple attribute names
        score_attr_names = [
            "val_aggregate_scores",
            "aggregate_scores",
            "scores",
            "validation_scores",
            "eval_scores",
            "candidate_scores",
            "final_scores",
        ]

        scores_list = None
        for attr_name in score_attr_names:
            val = getattr(gepa_result, attr_name, None)
            if val is not None and len(val) > 0:
                scores_list = list(val)
                logger.info(f"Found scores in '{attr_name}': {len(scores_list)} values")
                break

        if scores_list is None or len(scores_list) == 0:
            # Try to get from candidates themselves
            scores_list = []
            for c in candidates_list:
                if hasattr(c, "score"):
                    scores_list.append(c.score)
                elif hasattr(c, "aggregate_score"):
                    scores_list.append(c.aggregate_score)
                elif hasattr(c, "val_score"):
                    scores_list.append(c.val_score)
            if scores_list:
                logger.info(f"Found scores on candidates: {len(scores_list)} values")

        if not scores_list:
            # Last resort: compute scores from iteration data
            # Each iteration has candidate_idx and eval_mean_score
            # Use the best (max) score for each candidate
            if self.iterations:
                candidate_scores: dict[int, float] = {}
                for it in self.iterations:
                    idx = it.candidate_idx
                    score = it.eval_mean_score
                    if idx not in candidate_scores or score > candidate_scores[idx]:
                        candidate_scores[idx] = score

                if candidate_scores:
                    # Build scores_list in candidate order
                    max_idx = max(candidate_scores.keys()) if candidate_scores else -1
                    scores_list = [
                        candidate_scores.get(i, 0.0) for i in range(max_idx + 1)
                    ]
                    logger.info(
                        f"Computed scores from iterations: {len(scores_list)} values, "
                        f"max={max(scores_list):.3f}"
                    )

        if not scores_list:
            scores_list = []
            logger.warning("No scores found for candidates")

        # Extract subscores
        subscores_list = getattr(gepa_result, "val_subscores", None)
        if subscores_list is None:
            subscores_list = getattr(gepa_result, "subscores", [])
        if not subscores_list:
            subscores_list = []

        # Extract discovery iteration/count
        discovery_counts = getattr(gepa_result, "discovery_eval_counts", None)
        if discovery_counts is None:
            discovery_counts = getattr(gepa_result, "discovery_iterations", [])
        if not discovery_counts:
            discovery_counts = []

        per_instance_best = getattr(gepa_result, "per_val_instance_best_candidates", [])

        logger.info(
            f"GEPA final results: {len(candidates_list)} candidates, "
            f"{len(scores_list)} scores, {len(parents_list)} parents"
        )
        if scores_list:
            logger.info(f"Score values (first 10): {scores_list[:10]}")

        # Determine Pareto frontier members
        pareto_members = set()
        for item in per_instance_best:
            # Handle both single integers and sets/lists of candidate indices
            if isinstance(item, (set, list, tuple)):
                pareto_members.update(item)
            elif isinstance(item, int):
                pareto_members.add(item)
            elif item is not None:
                logger.debug(f"Unknown per_instance_best item type: {type(item)}")

        for idx, candidate in enumerate(candidates_list):
            # Extract instructions from candidate (which is a Module)
            instructions = {}
            if hasattr(candidate, "named_predictors"):
                for name, pred in candidate.named_predictors():
                    if hasattr(pred, "signature") and hasattr(pred.signature, "instructions"):
                        instructions[name] = pred.signature.instructions or ""
            elif isinstance(candidate, dict):
                instructions = candidate

            parent_idx = None
            if idx < len(parents_list):
                parent_val = parents_list[idx]
                # Handle different parent structures
                if isinstance(parent_val, (list, tuple)) and len(parent_val) > 0:
                    parent_idx = parent_val[0]
                elif isinstance(parent_val, int):
                    parent_idx = parent_val
                elif parent_val is not None:
                    logger.debug(f"Unknown parent format for candidate {idx}: {type(parent_val)} = {parent_val}")

            logger.debug(f"Candidate {idx}: parent_idx={parent_idx}")

            self.candidates.append(
                CandidateData(
                    candidate_idx=idx,
                    instructions=instructions,
                    parent_idx=parent_idx,
                    discovery_iteration=discovery_counts[idx] if idx < len(discovery_counts) else 0,
                    val_aggregate_score=scores_list[idx] if idx < len(scores_list) else 0.0,
                    val_subscores=subscores_list[idx] if idx < len(subscores_list) else [],
                    is_pareto_member=idx in pareto_members,
                )
            )

        # Store aggregate info
        self.best_candidate_idx = getattr(gepa_result, "best_idx", None)
        self.total_metric_calls = getattr(gepa_result, "total_metric_calls", 0) or 0
        self.pareto_frontier = list(pareto_members)

        # Get best score from scores_list if available
        if self.best_candidate_idx is not None and self.best_candidate_idx < len(scores_list):
            self.best_score = scores_list[self.best_candidate_idx]
        elif scores_list:
            # No best_idx but we have scores - use the max
            self.best_score = max(scores_list)
            self.best_candidate_idx = scores_list.index(self.best_score)

        # Fallback: compute best score from iterations if we still don't have it
        if self.best_score == 0.0 and self.iterations:
            max_mean_score = 0.0
            for it in self.iterations:
                if it.eval_mean_score > max_mean_score:
                    max_mean_score = it.eval_mean_score
            if max_mean_score > 0:
                self.best_score = max_mean_score
                logger.info(f"Using best score from iterations: {self.best_score:.3f}")

        logger.info(
            f"Captured final results: {len(self.candidates)} candidates, "
            f"best_idx={self.best_candidate_idx}, best_score={self.best_score:.3f}"
        )

    def capture_compiled_program(self, program: Any) -> None:
        """Capture the compiled program state.

        Called after optimization completes with the optimized program.
        Uses DSPy's dump_state() to serialize the program to JSON.
        """
        if program is None:
            return

        try:
            if hasattr(program, "dump_state"):
                self.compiled_program_state = program.dump_state(json_mode=True)
                logger.info(
                    f"Captured compiled program state: "
                    f"{len(self.compiled_program_state)} parameters"
                )
            else:
                logger.warning(
                    f"Program {type(program).__name__} does not have dump_state method"
                )
        except Exception as e:
            logger.warning(f"Failed to capture compiled program state: {e}")

    def set_error(self, exception: Exception) -> None:
        """Mark the optimization run as failed."""
        self.status = "failed"
        self.error_message = str(exception)
        self.end_time = datetime.now(timezone.utc)
        logger.error(f"Optimization failed: {exception}")

    def start(self) -> None:
        """Send initial optimization run record with status='running'.

        This creates the record in the backend so progress can be tracked
        before optimization completes.
        """
        if self._started:
            return
        self._started = True

        from cmpnd.exporter import get_exporter

        exporter = get_exporter()
        if exporter:
            exporter.export_optimization_start(self)
            logger.info(
                f"Started optimization tracking: run_id={self.optimization_run_id}, "
                f"max_metric_calls={self.max_metric_calls}"
            )
        else:
            logger.debug("No exporter available, optimization start not exported")

    def send_progress_update(self) -> None:
        """Send a progress update to the backend.

        Call this periodically during optimization to update the progress bar.
        """
        if not self._started:
            return

        from cmpnd.exporter import get_exporter

        exporter = get_exporter()
        if exporter:
            exporter.export_optimization_progress(self)
            progress_pct = 0.0
            if self.max_metric_calls > 0:
                progress_pct = (self.current_metric_calls / self.max_metric_calls) * 100
            logger.debug(
                f"Progress update: {self.current_metric_calls}/{self.max_metric_calls} "
                f"({progress_pct:.1f}%), best_score={self.best_score:.3f}"
            )

    def to_progress_dict(self) -> dict[str, Any]:
        """Convert current state to progress update dictionary."""
        elapsed_ms = 0
        if self.start_time:
            elapsed = datetime.now(timezone.utc) - self.start_time
            elapsed_ms = int(elapsed.total_seconds() * 1000)

        # Compute best score from current data
        current_best = self.best_score
        if current_best == 0.0 and self.iterations:
            for it in self.iterations:
                if it.eval_mean_score > current_best:
                    current_best = it.eval_mean_score

        return {
            "current_iteration": len(self.iterations),
            "current_metric_calls": self.current_metric_calls,
            "max_metric_calls": self.max_metric_calls,
            "best_score": current_best,
            "elapsed_ms": elapsed_ms,
        }

    def _remap_iteration_candidate_indices(self) -> None:
        """Remap iteration candidate_idx from hash-based to sequential indices.

        During optimization, iterations use hash-based candidate_idx values.
        This maps them to sequential indices (0, 1, 2, ...) by matching
        parent_instructions to candidate instructions.
        """
        if not self.iterations or not self.candidates:
            return

        # Build a mapping from instruction content to sequential candidate index
        # Use a normalized string representation of instructions for matching
        def normalize_instructions(instr: dict[str, str]) -> str:
            # Sort by key and join for consistent comparison
            return "|".join(f"{k}:{v}" for k, v in sorted(instr.items()))

        candidate_map: dict[str, int] = {}
        for c in self.candidates:
            key = normalize_instructions(c.instructions)
            candidate_map[key] = c.candidate_idx

        # Remap each iteration's candidate_idx
        remapped_count = 0
        for it in self.iterations:
            if it.parent_instructions:
                key = normalize_instructions(it.parent_instructions)
                if key in candidate_map:
                    old_idx = it.candidate_idx
                    it.candidate_idx = candidate_map[key]
                    if old_idx != it.candidate_idx:
                        remapped_count += 1

        if remapped_count > 0:
            logger.info(f"Remapped {remapped_count} iteration candidate indices")

    def finalize(self) -> None:
        """Finalize and export the optimization run."""
        if self._finalized:
            return
        self._finalized = True

        # Finalize current iteration if needed
        if self._current_iteration is not None:
            self._current_iteration.finalize()

        # Map iteration candidate_idx (hash-based) to sequential candidate indices
        # by matching parent_instructions to candidate instructions
        self._remap_iteration_candidate_indices()

        self.status = "completed"
        self.end_time = datetime.now(timezone.utc)

        duration_s = (self.end_time - self.start_time).total_seconds()
        logger.info(
            f"Optimization completed in {duration_s:.1f}s: "
            f"{len(self.iterations)} iterations, {len(self.candidates)} candidates, "
            f"best_score={self.best_score:.3f}"
        )

        # Export via cmpnd exporter
        # If we already sent a start record, update it; otherwise create new
        if self._started:
            self._export_update()
        else:
            self._export()

    def _export_update(self) -> None:
        """Update existing optimization run record."""
        from cmpnd.exporter import get_exporter

        exporter = get_exporter()
        if exporter:
            exporter.export_optimization_complete(self)
            logger.debug(f"Updated optimization run {self.optimization_run_id}")
        else:
            logger.warning("No exporter available, optimization run not updated")

    def _export(self) -> None:
        """Export optimization run to backend."""
        from cmpnd.exporter import get_exporter

        exporter = get_exporter()
        if exporter:
            exporter.export_optimization_run(self)
            logger.debug(f"Exported optimization run {self.optimization_run_id}")
        else:
            logger.warning("No exporter available, optimization run not exported")

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dictionary.

        All values are sanitized to ensure JSON serializability.
        """
        duration_ms = 0
        if self.start_time and self.end_time:
            duration_ms = int((self.end_time - self.start_time).total_seconds() * 1000)

        data = {
            "optimization_run_id": str(self.optimization_run_id),
            "optimizer_type": self.optimizer_type,
            "program_name": self.program_name,
            "config": _sanitize_for_json(self.config),
            "model_name": self.model_name,
            "reflection_model_name": self.reflection_model_name,
            "valset_hash": self.valset_hash,
            "component_signature_hash": self.component_signature_hash,
            "program_signature_hash": self.program_signature_hash,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration_ms": duration_ms,
            "status": self.status,
            "error_message": self.error_message,
            "total_iterations": len(self.iterations),
            "total_candidates": len(self.candidates),
            "total_metric_calls": int(self.total_metric_calls) if self.total_metric_calls else 0,
            "best_candidate_idx": int(self.best_candidate_idx) if self.best_candidate_idx is not None else None,
            "best_score": float(self.best_score) if self.best_score else 0.0,
            "pareto_frontier": [int(x) for x in self.pareto_frontier] if self.pareto_frontier else [],
            "max_metric_calls": int(self.max_metric_calls) if self.max_metric_calls else 0,
            "current_metric_calls": int(self.current_metric_calls) if self.current_metric_calls else 0,
            "iterations": [it.to_api_dict() for it in self.iterations],
            "candidates": [c.to_api_dict() for c in self.candidates],
            "compiled_program_state": _sanitize_for_json(self.compiled_program_state),
            "compiled_from_run_id": self.compiled_from_run_id,
            "untraced_lm_usage": self.untraced_lm_usage,
        }

        # Include dataset block if valset data is available
        if hasattr(self, "_valset") and self._valset and self.valset_hash:
            from cmpnd.dataset_sync import build_dataset_payload, check_dataset_exists

            try:
                exists = check_dataset_exists(self.valset_hash)
            except Exception:
                exists = False
            input_fields = getattr(self, "_valset_input_fields", set())
            data["dataset"] = build_dataset_payload(
                devset=self._valset,
                dataset_hash=self.valset_hash,
                input_fields=input_fields,
                include_examples=not exists,
            )

        # Verify the data is JSON-serializable before returning
        try:
            json.dumps(data)
        except (TypeError, ValueError) as e:
            logger.error(f"Data serialization check failed: {e}")
            # Log which field is problematic
            for key, value in data.items():
                try:
                    json.dumps({key: value})
                except (TypeError, ValueError):
                    logger.error(f"  Problematic field: {key}")

        return data
