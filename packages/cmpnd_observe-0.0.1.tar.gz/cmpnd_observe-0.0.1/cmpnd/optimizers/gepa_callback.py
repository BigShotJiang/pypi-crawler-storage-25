"""CmpndGEPACallback - GEPA callback that exports optimization data to cmpnd.

Implements the GEPACallback protocol to capture optimization events without
monkey-patching or wrapper classes. Replaces the monkey-patched
InstrumentedDspyAdapter approach used by TrackedGEPA.

Usage:
    tracker = OptimizationTracker(optimizer_type="GEPA", ...)
    callback = CmpndGEPACallback(tracker)
    gepa = dspy.GEPA(gepa_kwargs={"callbacks": [callback]})
"""

from __future__ import annotations

import json
import logging
from typing import Any

from cmpnd.context import set_current_optimization_run_id
from cmpnd.optimizers.tracker import CandidateData, OptimizationTracker

logger = logging.getLogger(__name__)


def _read_eval_trace_ids() -> list:
    """Read and clear eval trace IDs from CmpndCallback via dspy.settings.callbacks.

    CmpndCallback (the DSPy callback) sets _last_eval_trace_ids during
    on_evaluate_end, which fires DURING DspyAdapter.evaluate(). GEPA's
    on_evaluation_end fires AFTER evaluate() returns, so the IDs are
    available by the time we read them here.
    """
    try:
        import dspy

        for cb in getattr(dspy.settings, "callbacks", []):
            if hasattr(cb, "_last_eval_trace_ids"):
                ids = cb._last_eval_trace_ids
                cb._last_eval_trace_ids = []
                return ids
    except Exception:
        pass
    return []


class CmpndGEPACallback:
    """GEPA callback that exports optimization data to cmpnd.

    Implements the GEPACallback protocol to capture optimization events
    and forward them to an OptimizationTracker for export.

    The callback handles:
    - Setting/clearing optimization context for trace linkage
    - Capturing evaluation scores and linking eval trace IDs
    - Recording reflective datasets and proposals
    - Tracking budget consumption for progress reporting
    - Extracting final candidates from GEPAState
    - Error handling with will_continue awareness
    """

    def __init__(
        self,
        tracker: OptimizationTracker,
        defer_finalize: bool = False,
    ):
        self._tracker = tracker
        self._defer_finalize = defer_finalize
        self._valset_scores: dict[int, dict[Any, float]] = {}
        # Buffer for minibatch_ids received before iteration is created
        self._pending_minibatch_ids: dict[int, list[Any]] = {}
        # Buffer for subsample scores (old_score from rejection, new_score from acceptance)
        self._subsample_scores: dict[int, tuple[float, float]] = {}  # candidate_idx -> (before, after)

    def _get_cmpnd_callback(self):
        """Find the CmpndCallback instance from dspy.settings.callbacks."""
        try:
            import dspy

            for cb in getattr(dspy.settings, "callbacks", []):
                if hasattr(cb, "_active_optimization_run_id"):
                    return cb
        except Exception:
            pass
        return None

    def on_optimization_start(self, event: dict[str, Any]) -> None:
        """Handle optimization start: set context and start tracker."""
        try:
            set_current_optimization_run_id(self._tracker.optimization_run_id)

            # Set on CmpndCallback instance too (thread-safe, unlike ContextVar)
            cmpnd_cb = self._get_cmpnd_callback()
            if cmpnd_cb:
                cmpnd_cb._active_optimization_run_id = self._tracker.optimization_run_id

            # Extract budget info from config if available
            config = event.get("config", {})
            if config and hasattr(config, "__dict__"):
                # GEPAConfig object - try to get max_metric_calls
                max_calls = getattr(config, "max_metric_calls", None)
                if max_calls is not None:
                    self._tracker.max_metric_calls = max_calls
            elif isinstance(config, dict):
                max_calls = config.get("max_metric_calls")
                if max_calls is not None:
                    self._tracker.max_metric_calls = max_calls

            self._tracker.start()

            logger.info(
                f"Optimization started: run_id={self._tracker.optimization_run_id}, "
                f"trainset_size={event.get('trainset_size')}, "
                f"valset_size={event.get('valset_size')}"
            )
        except Exception:
            logger.exception("Error in on_optimization_start")
            raise

    def on_evaluation_end(self, event: dict[str, Any]) -> None:
        """Handle evaluation end: capture scores and trace IDs."""
        try:
            iteration = event.get("iteration", 0)
            candidate_idx = event.get("candidate_idx")
            if candidate_idx is None:
                candidate_idx = 0  # Seed evaluation has no candidate_idx
            scores = event.get("scores", [])
            has_trajectories = event.get("has_trajectories", False)

            # Read eval trace IDs from CmpndCallback
            eval_trace_ids = _read_eval_trace_ids()

            self._tracker.capture_evaluation(
                iteration=iteration,
                candidate_idx=candidate_idx,
                batch_size=len(scores),
                scores=scores,
                has_trajectories=has_trajectories,
                eval_trace_ids=eval_trace_ids,
            )

            # Apply any buffered minibatch_ids for this iteration
            if iteration in self._pending_minibatch_ids:
                it = self._get_current_iteration(iteration)
                if it is not None:
                    it.minibatch_ids = self._pending_minibatch_ids.pop(iteration)

            logger.debug(
                f"Evaluation end: iteration={iteration}, candidate={candidate_idx}, "
                f"scores={len(scores)}, trace_ids={len(eval_trace_ids)}"
            )
        except Exception:
            logger.exception("Error in on_evaluation_end")
            raise

    def on_reflective_dataset_built(self, event: dict[str, Any]) -> None:
        """Handle reflective dataset built: capture dataset for analysis."""
        try:
            iteration = event.get("iteration", 0)
            candidate_idx = event.get("candidate_idx", 0)
            components = event.get("components", [])
            dataset = event.get("dataset", {})

            # Deep copy to avoid mutation (matches tracker.py pattern)
            dataset_copy = json.loads(json.dumps(dataset, default=str))

            self._tracker.capture_reflective_dataset(
                iteration=iteration,
                candidate_idx=candidate_idx,
                components=components,
                dataset=dataset_copy,
            )
        except Exception:
            logger.exception("Error in on_reflective_dataset_built")
            raise

    def on_proposal_start(self, event: dict[str, Any]) -> None:
        """Handle proposal start: capture parent candidate info."""
        try:
            iteration = event.get("iteration", 0)
            parent_candidate = event.get("parent_candidate", {})
            components = event.get("components", [])

            self._tracker.capture_proposal_start(
                iteration=iteration,
                parent_candidate=parent_candidate,
                components=components,
            )
        except Exception:
            logger.exception("Error in on_proposal_start")
            raise

    def on_proposal_end(self, event: dict[str, Any]) -> None:
        """Handle proposal end: capture new instructions."""
        try:
            iteration = event.get("iteration", 0)
            new_instructions = event.get("new_instructions", {})

            self._tracker.capture_proposal_end(
                iteration=iteration,
                new_instructions=new_instructions,
            )
        except Exception:
            logger.exception("Error in on_proposal_end")
            raise

    def on_budget_updated(self, event: dict[str, Any]) -> None:
        """Handle budget update: track metric call consumption."""
        try:
            self._tracker.current_metric_calls = event.get("metric_calls_used", 0)

            remaining = event.get("metric_calls_remaining")
            if remaining is not None:
                # max = used + remaining
                self._tracker.max_metric_calls = (
                    self._tracker.current_metric_calls + remaining
                )

            self._tracker.send_progress_update()

            logger.debug(
                f"Budget updated: used={self._tracker.current_metric_calls}, "
                f"max={self._tracker.max_metric_calls}"
            )
        except Exception:
            logger.exception("Error in on_budget_updated")
            raise

    def on_optimization_end(self, event: dict[str, Any]) -> None:
        """Handle optimization end: extract candidates from GEPAState and finalize."""
        try:
            self._tracker.best_candidate_idx = event.get("best_candidate_idx")
            self._tracker.total_metric_calls = event.get("total_metric_calls", 0)

            # Extract candidates from final_state (GEPAState)
            final_state = event.get("final_state")
            if final_state is not None:
                self._extract_candidates_from_state(final_state)
            else:
                logger.warning("on_optimization_end: no final_state in event")

            # Set best_score from candidates if available
            if (
                self._tracker.best_candidate_idx is not None
                and self._tracker.candidates
            ):
                for c in self._tracker.candidates:
                    if c.candidate_idx == self._tracker.best_candidate_idx:
                        self._tracker.best_score = c.val_aggregate_score
                        break

            # Collect untraced LM usage (reflection calls) before clearing context
            cmpnd_cb = self._get_cmpnd_callback()
            if cmpnd_cb:
                if cmpnd_cb._orphaned_lm_usage:
                    self._tracker.untraced_lm_usage = dict(cmpnd_cb._orphaned_lm_usage)
                    logger.info(
                        f"Collected untraced LM usage: "
                        f"{sum(v['prompt_tokens'] + v['completion_tokens'] for v in cmpnd_cb._orphaned_lm_usage.values())} tokens "
                        f"across {len(cmpnd_cb._orphaned_lm_usage)} models"
                    )
                    cmpnd_cb._orphaned_lm_usage = {}
                cmpnd_cb._active_optimization_run_id = None

            # Clear optimization context
            set_current_optimization_run_id(None)

            if not self._defer_finalize:
                self._tracker.finalize()

            logger.info(
                f"Optimization ended: best_idx={self._tracker.best_candidate_idx}, "
                f"best_score={self._tracker.best_score:.3f}, "
                f"total_metric_calls={self._tracker.total_metric_calls}, "
                f"iterations={len(self._tracker.iterations)}, "
                f"candidates={len(self._tracker.candidates)}"
            )
        except Exception:
            logger.exception("Error in on_optimization_end")
            raise

    def on_error(self, event: dict[str, Any]) -> None:
        """Handle error: set error on tracker or log warning."""
        try:
            exception = event.get("exception")
            will_continue = event.get("will_continue", False)

            if will_continue:
                logger.warning(
                    f"GEPA recoverable error at iteration {event.get('iteration')}: "
                    f"{exception}"
                )
            else:
                if exception is not None:
                    self._tracker.set_error(exception)
                else:
                    self._tracker.set_error(
                        RuntimeError(f"Unknown error at iteration {event.get('iteration')}")
                    )
        except Exception:
            logger.exception("Error in on_error")
            raise

    def _get_current_iteration(self, iteration: int):
        """Find the IterationData for a given iteration number."""
        for it in self._tracker.iterations:
            if it.iteration == iteration:
                return it
        return None

    def on_candidate_accepted(self, event: dict[str, Any]) -> None:
        """Handle candidate accepted: mark iteration and capture subsample score."""
        try:
            iteration = self._get_current_iteration(event.get("iteration", 0))
            if iteration is not None:
                iteration.accepted = True

            # Store subsample score for the new candidate
            new_idx = event.get("new_candidate_idx")
            new_score = event.get("new_score")
            if new_idx is not None and new_score is not None:
                # For accepted: before = parent's score (unknown here), after = new_score
                # We'll set before from the iteration's eval of the parent (captured earlier)
                parent_score = 0.0
                if iteration is not None and iteration.eval_mean_score:
                    # The eval that happened this iteration was on the parent
                    # Actually the eval is on the NEW candidate, so new_score IS the subsample after
                    pass
                self._subsample_scores[new_idx] = (0.0, float(new_score))
        except Exception:
            logger.exception("Error in on_candidate_accepted")

    def on_candidate_rejected(self, event: dict[str, Any]) -> None:
        """Handle candidate rejected: mark iteration and capture subsample scores."""
        try:
            iteration = self._get_current_iteration(event.get("iteration", 0))
            if iteration is not None:
                iteration.accepted = False
                iteration.rejection_reason = event.get("reason", "")

                # Store subsample scores on the iteration for analysis
                old_score = event.get("old_score")
                new_score = event.get("new_score")
                if old_score is not None:
                    iteration.subsample_score_before = float(old_score)
                if new_score is not None:
                    iteration.subsample_score_after = float(new_score)
        except Exception:
            logger.exception("Error in on_candidate_rejected")

    def on_valset_evaluated(self, event: dict[str, Any]) -> None:
        """Handle valset evaluated: store per-example scores for later application."""
        try:
            candidate_idx = event.get("candidate_idx", 0)
            scores = event.get("scores_by_val_id", {})
            self._valset_scores[candidate_idx] = dict(scores)
        except Exception:
            logger.exception("Error in on_valset_evaluated")

    def on_minibatch_sampled(self, event: dict[str, Any]) -> None:
        """Handle minibatch sampled: record minibatch IDs on current iteration.

        Note: This fires BEFORE on_evaluation_end (which creates the iteration),
        so we buffer the IDs and apply them when the iteration is created.
        """
        try:
            iter_num = event.get("iteration", 0)
            ids = list(event.get("minibatch_ids", []))
            iteration = self._get_current_iteration(iter_num)
            if iteration is not None:
                iteration.minibatch_ids = ids
            else:
                # Buffer for later — iteration hasn't been created yet
                self._pending_minibatch_ids[iter_num] = ids
        except Exception:
            logger.exception("Error in on_minibatch_sampled")

    def on_pareto_front_updated(self, event: dict[str, Any]) -> None:
        """Handle Pareto front updated: mark displaced candidates."""
        try:
            displaced = event.get("displaced_candidates", [])
            iteration_num = event.get("iteration", 0)
            for candidate in self._tracker.candidates:
                if candidate.candidate_idx in displaced and candidate.displaced_from_pareto_at is None:
                    candidate.displaced_from_pareto_at = iteration_num
        except Exception:
            logger.exception("Error in on_pareto_front_updated")

    def _extract_candidates_from_state(self, state: Any) -> None:
        """Extract candidate data from GEPAState object.

        GEPAState attributes used:
        - program_candidates: list[dict[str, str]]
        - parent_program_for_candidate: list[list[ProgramIdx | None]]
        - prog_candidate_objective_scores: list[ObjectiveScores]
        - prog_candidate_val_subscores: list[dict[DataId, float]]
        - num_metric_calls_by_discovery: list[int]
        - program_at_pareto_front_valset: dict[DataId, set[ProgramIdx]]
        """
        candidates = getattr(state, "program_candidates", [])
        parents = getattr(state, "parent_program_for_candidate", [])
        objective_scores = getattr(state, "prog_candidate_objective_scores", [])
        val_subscores = getattr(state, "prog_candidate_val_subscores", [])
        discovery_counts = getattr(state, "num_metric_calls_by_discovery", [])
        pareto_front = getattr(state, "program_at_pareto_front_valset", {})

        logger.debug(
            f"Extracting candidates: {len(candidates)} programs, "
            f"{len(parents)} parents, {len(objective_scores)} obj_scores, "
            f"{len(val_subscores)} val_subscores, {len(discovery_counts)} discovery"
        )

        # Determine Pareto frontier members
        pareto_members: set[int] = set()
        for _data_id, candidate_set in pareto_front.items():
            if isinstance(candidate_set, (set, frozenset)):
                pareto_members.update(candidate_set)
            elif isinstance(candidate_set, (list, tuple)):
                pareto_members.update(candidate_set)

        self._tracker.pareto_frontier = list(pareto_members)

        for idx, instructions in enumerate(candidates):
            try:
                # Extract parent index (first non-None parent)
                parent_idx = None
                if idx < len(parents):
                    parent_list = parents[idx]
                    if isinstance(parent_list, (list, tuple)):
                        for p in parent_list:
                            if p is not None:
                                parent_idx = p
                                break
                    elif parent_list is not None:
                        parent_idx = parent_list

                # Compute aggregate score: prefer val_subscores (per-example),
                # fall back to objective_scores (per-objective)
                val_aggregate_score = 0.0
                val_subs: list[float] = []

                if idx < len(val_subscores):
                    subs = val_subscores[idx]
                    if isinstance(subs, dict) and subs:
                        val_subs = [float(v) for v in subs.values()]
                        val_aggregate_score = sum(val_subs) / len(val_subs)

                # Fall back to objective scores if val_subscores didn't yield a score
                if val_aggregate_score == 0.0 and idx < len(objective_scores):
                    obj = objective_scores[idx]
                    if isinstance(obj, dict) and obj:
                        val_aggregate_score = sum(float(v) for v in obj.values()) / len(obj)

                # Apply valset scores captured by on_valset_evaluated
                val_scores_by_id = self._valset_scores.get(idx, {})

                # Apply buffered subsample scores
                sub_before, sub_after = self._subsample_scores.get(idx, (None, None))

                self._tracker.candidates.append(
                    CandidateData(
                        candidate_idx=idx,
                        instructions=instructions if isinstance(instructions, dict) else {},
                        parent_idx=parent_idx,
                        discovery_iteration=int(discovery_counts[idx]) if idx < len(discovery_counts) else 0,
                        val_aggregate_score=val_aggregate_score,
                        val_subscores=val_subs,
                        is_pareto_member=idx in pareto_members,
                        val_scores_by_id={str(k): float(v) for k, v in val_scores_by_id.items()},
                        subsample_score_before=sub_before,
                        subsample_score_after=sub_after,
                    )
                )
            except Exception:
                logger.exception(f"Error extracting candidate {idx}")

        logger.info(
            f"Extracted {len(self._tracker.candidates)} candidates from GEPAState, "
            f"{len(pareto_members)} Pareto members"
        )
