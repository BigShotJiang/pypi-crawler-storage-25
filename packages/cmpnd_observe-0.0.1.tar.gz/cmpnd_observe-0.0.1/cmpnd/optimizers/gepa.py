"""TrackedGEPA - Instrumented GEPA optimizer for cmpnd observability."""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING, Any

from cmpnd.optimizers.gepa_callback import CmpndGEPACallback
from cmpnd.optimizers.tracker import OptimizationTracker

if TYPE_CHECKING:
    from dspy import Example, Module

logger = logging.getLogger(__name__)

# Lazy imports to avoid import errors if dspy/gepa not installed
_GEPA = None


def _get_gepa_classes():
    """Lazy import of GEPA."""
    global _GEPA

    if _GEPA is None:
        try:
            from dspy import GEPA

            _GEPA = GEPA
        except ImportError as e:
            raise ImportError(
                "dspy with GEPA support is required for TrackedGEPA. "
                "Install with: pip install dspy gepa"
            ) from e

    return _GEPA


class TrackedGEPA:
    """GEPA optimizer with full cmpnd instrumentation.

    Drop-in replacement for dspy.GEPA that captures:
    - Reflective datasets (input/output/feedback triplets)
    - Proposal prompts and results
    - Iteration-level context
    - Candidate evolution and lineage

    All optimization data is automatically exported to the cmpnd backend.

    Usage:
        >>> from cmpnd.optimizers import TrackedGEPA
        >>> import dspy
        >>>
        >>> cmpnd.configure(api_key="ct_xxx")
        >>> dspy.configure(lm=lm, callbacks=[cmpnd.CmpndCallback()])
        >>>
        >>> gepa = TrackedGEPA(auto="light", reflection_lm=reflection_lm)
        >>> optimized = gepa.compile(student, trainset, valset)
        >>>
        >>> # Optimization data is automatically exported to cmpnd

    Args:
        All arguments are passed through to dspy.GEPA.

        Key GEPA parameters:
        - auto: Budget preset ("light", "medium", "heavy")
        - max_full_evals: Number of full evaluations
        - max_metric_calls: Raw metric call budget
        - reflection_lm: LM for generating improved instructions
        - seed: Random seed for reproducibility
        - log_dir: Directory for GEPA's native logs

    See dspy.GEPA documentation for full parameter list.
    """

    def __init__(self, *args, **kwargs):
        import warnings
        warnings.warn(
            "TrackedGEPA is deprecated. Use cmpnd.auto_instrument() instead, "
            "then use dspy.GEPA directly. TrackedGEPA will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )

        GEPA = _get_gepa_classes()

        # Store kwargs for config tracking
        self._gepa_kwargs = kwargs.copy()

        # Create underlying GEPA instance
        self._gepa = GEPA(*args, **kwargs)

        # Tracker will be created when compile() is called
        self._tracker: OptimizationTracker | None = None

    @staticmethod
    def _get_valset_input_fields(valset: list[Any]) -> set[str]:
        """Extract input field names from valset examples."""
        if valset and hasattr(valset[0], "_input_keys"):
            return set(valset[0]._input_keys)
        return set()

    def compile(
        self,
        student: Module,
        *,
        trainset: list[Example],
        teacher: Module | None = None,
        valset: list[Example] | None = None,
    ) -> Module:
        """Compile the student program using GEPA optimization.

        This wraps GEPA.compile() to capture optimization data by injecting
        a CmpndGEPACallback into GEPA's callback list. The callback handles
        all event capture natively through GEPA's callback protocol.

        Args:
            student: The DSPy program to optimize
            trainset: Training examples for optimization
            teacher: Optional teacher program (passed through to GEPA)
            valset: Validation examples (defaults to trainset if not provided)

        Returns:
            Optimized DSPy program with detailed_results attribute
        """
        # Build config and extract model names
        config = self._build_config(student)
        model_name = self._get_model_name()
        reflection_model_name = self._get_reflection_model_name()

        # Compute hashes for comparison grouping
        effective_valset = valset if valset is not None else trainset
        valset_for_export = list(effective_valset)
        valset_hash = OptimizationTracker.compute_valset_hash(effective_valset)
        component_signature_hash = OptimizationTracker.compute_signature_hash(
            config.get("components", [])
        )

        # Compute program_signature_hash (trace-compatible format)
        # This allows us to join optimization runs to traces
        program_signature_hash = self._compute_program_signature_hash(student)

        # Initialize optimization tracking
        self._tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name=student.__class__.__name__,
            config=config,
            model_name=model_name,
            reflection_model_name=reflection_model_name,
            valset_hash=valset_hash,
            component_signature_hash=component_signature_hash,
            program_signature_hash=program_signature_hash,
        )

        # Store valset for dataset payload building
        self._tracker._valset = valset_for_export
        self._tracker._valset_input_fields = self._get_valset_input_fields(effective_valset)

        # Log hashes for debugging model sweep grouping
        logger.info(
            f"Optimization hashes for model sweep grouping: "
            f"component_signature_hash={component_signature_hash}, valset_hash={valset_hash}, model={model_name}"
        )

        # Compute and set max metric calls budget
        self._tracker.max_metric_calls = self._compute_max_metric_calls(
            student, trainset, valset
        )

        # Create callback with defer_finalize=True so we can capture_compiled_program
        # before finalizing
        gepa_callback = CmpndGEPACallback(self._tracker, defer_finalize=True)

        # Inject callback into GEPA's gepa_kwargs
        existing_callbacks = self._gepa.gepa_kwargs.get("callbacks") or []
        self._gepa.gepa_kwargs["callbacks"] = existing_callbacks + [gepa_callback]

        try:
            # Run optimization (trainset/valset are keyword-only in GEPA)
            result = self._gepa.compile(student, trainset=trainset, teacher=teacher, valset=valset)

            # Capture the compiled program state
            self._tracker.capture_compiled_program(result)

            # Tag the compiled program with its optimization run ID
            # This allows traces from this program to be linked back to this optimization
            if hasattr(result, "__dict__"):
                result._optimization_run_id = str(self._tracker.optimization_run_id)
                logger.debug(
                    f"Tagged compiled program with optimization_run_id={self._tracker.optimization_run_id}"
                )

            # Finalize and export (deferred from callback's on_optimization_end)
            self._tracker.finalize()

            return result

        except Exception as e:
            if self._tracker:
                self._tracker.set_error(e)
            raise

        finally:
            # Clear optimization context (in case on_optimization_end didn't fire)
            from cmpnd.context import set_current_optimization_run_id
            set_current_optimization_run_id(None)
            # Remove our callback from gepa_kwargs
            cbs = self._gepa.gepa_kwargs.get("callbacks", [])
            self._gepa.gepa_kwargs["callbacks"] = [
                cb for cb in cbs if cb is not gepa_callback
            ]

    def _build_config(self, student: Module) -> dict[str, Any]:
        """Build config dict for tracking."""
        config = {}

        # Extract key GEPA parameters
        for key in ["auto", "max_full_evals", "max_metric_calls", "seed", "log_dir"]:
            if key in self._gepa_kwargs:
                config[key] = self._gepa_kwargs[key]
            elif hasattr(self._gepa, key):
                value = getattr(self._gepa, key)
                if value is not None:
                    config[key] = value

        # Extract component/predictor names and signatures from the student module
        components = []
        if hasattr(student, "named_predictors"):
            for name, pred in student.named_predictors():
                component_info = {"name": name}
                if hasattr(pred, "signature"):
                    sig = pred.signature
                    # Get input/output field names
                    if hasattr(sig, "input_fields"):
                        component_info["inputs"] = list(sig.input_fields.keys())
                    if hasattr(sig, "output_fields"):
                        component_info["outputs"] = list(sig.output_fields.keys())
                components.append(component_info)

        if components:
            config["components"] = components

        return config

    def _get_model_name(self) -> str:
        """Extract the current model name from dspy.settings.

        Returns the model identifier string (e.g., 'openai/gpt-4o', 'anthropic/claude-3')
        or empty string if not available.
        """
        try:
            import dspy

            lm = dspy.settings.lm
            if lm is not None and hasattr(lm, "model"):
                return lm.model or ""
        except Exception:
            pass
        return ""

    def _get_reflection_model_name(self) -> str:
        """Extract the reflection LM model name from GEPA kwargs.

        Returns the model identifier string for the reflection LM
        or empty string if not available.
        """
        reflection_lm = self._gepa_kwargs.get("reflection_lm")
        if reflection_lm is not None and hasattr(reflection_lm, "model"):
            return reflection_lm.model or ""
        return ""

    def _compute_program_signature_hash(self, student: "Module") -> int:
        """Compute program signature hash matching trace format.

        Extracts the root signature from the student module and computes
        a hash that matches what traces use for program identity.

        Args:
            student: DSPy module to extract signature from

        Returns:
            64-bit unsigned int hash (0 if no signature found)
        """
        # Find the root signature (same logic as callback.py)
        signature = None
        if hasattr(student, "signature"):
            signature = student.signature
        elif hasattr(student, "predict") and hasattr(student.predict, "signature"):
            signature = student.predict.signature

        if signature is None:
            return 0

        return OptimizationTracker.compute_program_signature_hash(signature)

    def _compute_max_metric_calls(
        self, student: Module, trainset: list, valset: list | None
    ) -> int:
        """Compute the maximum metric calls budget for this optimization.

        This estimates the total number of metric calls GEPA will make based on:
        - Explicit max_metric_calls if provided
        - max_full_evals * dataset size
        - Auto preset budget computation

        Returns:
            Estimated total metric calls (0 if unknown)
        """
        # Check for explicit max_metric_calls
        if "max_metric_calls" in self._gepa_kwargs:
            return self._gepa_kwargs["max_metric_calls"]

        # Check underlying GEPA instance
        if hasattr(self._gepa, "max_metric_calls") and self._gepa.max_metric_calls:
            return self._gepa.max_metric_calls

        effective_valset = valset if valset is not None else trainset
        valset_size = len(effective_valset)
        trainset_size = len(trainset)

        # Check for max_full_evals
        max_full_evals = self._gepa_kwargs.get("max_full_evals")
        if max_full_evals is None and hasattr(self._gepa, "max_full_evals"):
            max_full_evals = self._gepa.max_full_evals

        if max_full_evals:
            # Rough estimate: full evals + trainset bootstrap + minibatch evals
            return max_full_evals * (valset_size + trainset_size)

        # Check for auto preset
        auto_setting = self._gepa_kwargs.get("auto")
        if auto_setting is None and hasattr(self._gepa, "auto"):
            auto_setting = self._gepa.auto

        if auto_setting:
            # Compute budget using GEPA's auto_budget formula (approximate)
            num_candidates = {"light": 6, "medium": 12, "heavy": 18}.get(auto_setting, 6)
            num_preds = 1
            if hasattr(student, "named_predictors"):
                num_preds = max(1, len(list(student.named_predictors())))

            minibatch_size = 35  # GEPA default

            # Approximate GEPA's num_trials calculation
            num_trials = int(max(2 * (num_preds * 2) * math.log2(num_candidates), 1.5 * num_candidates))

            # Initial eval + bootstrap + minibatch evals + periodic full evals
            budget = valset_size + num_candidates * 5 + num_trials * minibatch_size
            budget += (num_trials // 5 + 1) * valset_size  # Full eval every ~5 iterations

            return budget

        return 0  # Unknown

    # Proxy methods/attributes to underlying GEPA instance
    def __getattr__(self, name: str) -> Any:
        """Proxy attribute access to underlying GEPA instance."""
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        return getattr(self._gepa, name)

    def __repr__(self) -> str:
        return f"TrackedGEPA({self._gepa_kwargs})"
