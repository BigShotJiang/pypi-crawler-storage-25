"""Dataset sync utilities for pre-flight checks and payload building.

Functions:
- check_dataset_exists: Quick check if a dataset hash already exists on the backend
- build_dataset_payload: Build the dataset payload for eval/optimization exports
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from cmpnd.config import require_config
from cmpnd.identity import compute_example_hash

logger = logging.getLogger(__name__)


def check_dataset_exists(dataset_hash: str) -> bool:
    """Check if a dataset with this hash already exists on the backend.

    Makes a GET request to /api/v1/datasets/check/{dataset_hash}.
    Uses a short timeout (5s) since this is in the eval hot path.

    Args:
        dataset_hash: The SHA256[:16] hash of the dataset.

    Returns:
        True if the dataset exists, False otherwise (including on errors).
    """
    try:
        config = require_config()
    except RuntimeError:
        return False

    url = f"{config.endpoint}/api/v1/datasets/check/{dataset_hash}"

    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(
                url,
                headers={"Authorization": f"Bearer {config.api_key}"},
            )
            if response.status_code == 200:
                data = response.json()
                return data.get("exists", False)
            return False
    except Exception:
        logger.debug(f"Dataset existence check failed for {dataset_hash}", exc_info=True)
        return False


def build_dataset_payload(
    devset: list[Any],
    dataset_hash: str,
    input_fields: set[str],
    include_examples: bool,
) -> dict[str, Any]:
    """Build the dataset payload for API export.

    Args:
        devset: List of DSPy Example objects.
        dataset_hash: Pre-computed SHA256[:16] hash of the dataset.
        input_fields: Set of field names that are inputs (from signature).
        include_examples: Whether to include full example data.

    Returns:
        Dict with dataset_hash, dataset_size, and optionally examples.
    """
    payload: dict[str, Any] = {
        "dataset_hash": dataset_hash,
        "dataset_size": len(devset),
    }

    if not include_examples:
        return payload

    # Determine all fields from the devset to compute output_fields
    all_fields: set[str] = set()
    for ex in devset:
        if hasattr(ex, "toDict"):
            d = ex.toDict()
        elif isinstance(ex, dict):
            d = ex
        else:
            d = {}
        # Exclude internal fields (starting with _)
        all_fields.update(k for k in d.keys() if not k.startswith("_"))

    output_fields = all_fields - input_fields

    payload["input_fields"] = sorted(input_fields)
    payload["output_fields"] = sorted(output_fields)

    examples = []
    for ex in devset:
        if hasattr(ex, "toDict"):
            d = ex.toDict()
        elif isinstance(ex, dict):
            d = ex
        else:
            d = {}

        # Filter out internal fields
        d = {k: v for k, v in d.items() if not k.startswith("_")}

        inputs = {k: v for k, v in d.items() if k in input_fields}
        expected_outputs = {k: v for k, v in d.items() if k not in input_fields}

        example_hash = compute_example_hash(inputs) if inputs else ""

        examples.append({
            "inputs": inputs,
            "expected_outputs": expected_outputs,
            "example_hash": example_hash,
        })

    payload["examples"] = examples
    return payload
