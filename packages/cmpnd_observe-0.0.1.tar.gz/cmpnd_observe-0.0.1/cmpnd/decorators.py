"""Decorators and context managers for custom spans."""

from __future__ import annotations

import functools
import inspect
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable, Iterator, TypeVar
from uuid import uuid4

from cmpnd.context import get_current_span, get_current_trace, pop_span, push_span
from cmpnd.exporter import get_exporter
from cmpnd.models import SpanBuilder, SpanType, TraceStatus

F = TypeVar("F", bound=Callable[..., Any])


def trace(
    name: str | None = None,
    span_type: SpanType = SpanType.MODULE,
    capture_inputs: bool = True,
    capture_outputs: bool = True,
    tags: dict[str, str] | None = None,
) -> Callable[[F], F]:
    """
    Decorator to create a traced span around a function.

    Args:
        name: Span name. Defaults to function name.
        span_type: Type of span for categorization.
        capture_inputs: Whether to capture function arguments.
        capture_outputs: Whether to capture return value.
        tags: Additional tags for the span.

    Example:
        >>> @cmpnd.trace(name="my_retrieval", span_type=SpanType.RETRIEVE)
        ... def retrieve_docs(query: str) -> list[str]:
        ...     return search(query)
    """

    def decorator(fn: F) -> F:
        span_name = name or fn.__name__

        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                with start_span(span_name, span_type=span_type, tags=tags) as span:
                    if capture_inputs:
                        span.set_inputs(_extract_inputs(fn, args, kwargs))
                    try:
                        result = await fn(*args, **kwargs)
                        if capture_outputs:
                            span.set_outputs(result)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            return async_wrapper  # type: ignore[return-value]
        else:

            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                with start_span(span_name, span_type=span_type, tags=tags) as span:
                    if capture_inputs:
                        span.set_inputs(_extract_inputs(fn, args, kwargs))
                    try:
                        result = fn(*args, **kwargs)
                        if capture_outputs:
                            span.set_outputs(result)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            return sync_wrapper  # type: ignore[return-value]

    return decorator


@contextmanager
def start_span(
    name: str,
    span_type: SpanType = SpanType.UNKNOWN,
    parent: SpanBuilder | None = None,
    tags: dict[str, str] | None = None,
) -> Iterator[SpanBuilder]:
    """
    Context manager to create a span within the current trace.

    Args:
        name: Name of the span.
        span_type: Type of span for categorization.
        parent: Parent span (defaults to current span in context).
        tags: Additional tags for the span.

    Example:
        >>> with cmpnd.start_span("embedding_lookup") as span:
        ...     span.set_attribute("model", "text-embedding-3-small")
        ...     embeddings = get_embeddings(texts)
        ...     span.set_outputs({"count": len(embeddings)})
    """
    parent_span = parent or get_current_span()
    current_trace = get_current_trace()
    trace_id = current_trace.trace_id if current_trace else uuid4()

    span = SpanBuilder(
        span_id=uuid4(),
        trace_id=trace_id,
        name=name,
        span_type=span_type,
        parent_span_id=parent_span.span_id if parent_span else None,
        start_time=datetime.now(timezone.utc),
    )

    if tags:
        span.attributes.update(tags)

    push_span(span)

    try:
        yield span
        if span.status == TraceStatus.UNSET:
            span.status = TraceStatus.OK
    except Exception as e:
        span.set_error(e)
        raise
    finally:
        span.end_time = datetime.now(timezone.utc)
        pop_span()

        # Export the span
        exporter = get_exporter()
        if exporter:
            exporter.export_span(span)


def _extract_inputs(fn: Callable[..., Any], args: tuple, kwargs: dict) -> dict[str, Any]:
    """Extract function inputs as a dictionary."""
    try:
        sig = inspect.signature(fn)
        bound = sig.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        # Remove 'self' if present
        arguments = dict(bound.arguments)
        arguments.pop("self", None)
        return arguments
    except Exception:
        # Fallback if signature inspection fails
        return {"args": args, "kwargs": kwargs}
