"""Dataset loading functionality for the cmpnd SDK.

This module provides functions to load datasets from the cmpnd backend
and convert them to DSPy-compatible formats.
"""

from __future__ import annotations

from typing import Any

import httpx

from cmpnd.config import require_config


class DatasetNotFoundError(Exception):
    """Raised when a dataset is not found."""

    def __init__(self, name: str):
        self.name = name
        super().__init__(f"Dataset '{name}' not found")


class VersionNotFoundError(Exception):
    """Raised when a dataset version or tag is not found."""

    def __init__(self, dataset_name: str, version: str | int):
        self.dataset_name = dataset_name
        self.version = version
        super().__init__(f"Version '{version}' not found for dataset '{dataset_name}'")


def _apply_field_mapping(row: dict[str, Any], mapping: dict[str, str]) -> dict[str, Any]:
    """Transform a flat row to nested structure based on field mapping.

    For mappings like {"input_name": "place_one.name", "input_address": "place_one.address"},
    this transforms:
        {"input_name": "Foo", "input_address": "123 St", "distance": 0.5}
    to:
        {"place_one": {"name": "Foo", "address": "123 St"}, "distance": 0.5}

    Fields not in the mapping are passed through as-is.

    Args:
        row: Original flat dictionary from dataset
        mapping: Dict mapping source field -> target path (dot-notation for nested)

    Returns:
        Transformed dictionary with nested structure
    """
    if not mapping:
        return row

    result: dict[str, Any] = {}
    mapped_fields = set()

    for src_field, dst_path in mapping.items():
        if src_field not in row:
            continue

        mapped_fields.add(src_field)
        value = row[src_field]

        if "." in dst_path:
            # Nested path: "place_one.name" -> create nested dict
            parts = dst_path.split(".")
            current = result
            for part in parts[:-1]:
                if part not in current:
                    current[part] = {}
                current = current[part]
            current[parts[-1]] = value
        else:
            # Simple mapping
            result[dst_path] = value

    # Pass through unmapped fields
    for key, value in row.items():
        if key not in mapped_fields and key not in result:
            result[key] = value

    return result


def _fetch_dataset(
    name: str,
    version: str | int | None = None,
) -> dict[str, Any]:
    """Fetch dataset from the cmpnd backend API.

    Args:
        name: Name of the dataset to load
        version: Optional version number (int) or tag name (str). None = latest.

    Returns:
        Dictionary with dataset info and examples:
        {
            "name": str,
            "version": int,
            "input_fields": list[str],
            "examples": list[dict]
        }

    Raises:
        DatasetNotFoundError: If the dataset doesn't exist
        VersionNotFoundError: If the specified version doesn't exist
    """
    config = require_config()

    # Build URL with version parameter if specified
    url = f"{config.endpoint}/api/v1/datasets/load/{name}"
    params = {}
    if version is not None:
        params["version"] = str(version)

    # Make request to backend
    with httpx.Client(timeout=30.0) as client:
        response = client.get(
            url,
            params=params,
            headers={"X-API-Key": config.api_key},
        )

    # Handle errors
    if response.status_code == 404:
        # Check if it's a dataset not found or version not found
        try:
            detail = response.json().get("detail", "")
        except Exception:
            detail = ""

        if "Version" in detail or "tag" in detail.lower():
            raise VersionNotFoundError(name, version)
        raise DatasetNotFoundError(name)

    # Raise for other HTTP errors
    response.raise_for_status()

    return response.json()


def load_dataset(
    name: str,
    version: str | int | None = None,
) -> list:
    """Load a dataset from cmpnd and return as list[dspy.Example].

    This function fetches the dataset from the cmpnd backend and converts
    each example to a dspy.Example with input fields properly marked.

    Args:
        name: Name of the dataset to load
        version: Optional version number (int) or tag name (str).
            If not specified, loads the latest version.

    Returns:
        List of dspy.Example objects ready for use with DSPy evaluations
        and optimizations. Each example has .with_inputs() applied based
        on the dataset's input_fields configuration.

    Raises:
        DatasetNotFoundError: If the dataset doesn't exist
        VersionNotFoundError: If the specified version doesn't exist
        RuntimeError: If cmpnd.configure() hasn't been called

    Example:
        >>> import cmpnd
        >>> import dspy
        >>>
        >>> cmpnd.configure(api_key="ct_xxx")
        >>>
        >>> # Load latest version
        >>> trainset = cmpnd.load_dataset("my-training-set")
        >>>
        >>> # Load specific version by number
        >>> trainset = cmpnd.load_dataset("my-training-set", version=5)
        >>>
        >>> # Load by version tag
        >>> valset = cmpnd.load_dataset("my-validation-set", version="prod")
        >>>
        >>> # Use with DSPy
        >>> evaluator = dspy.Evaluate(devset=valset, metric=my_metric)
        >>> results = evaluator(my_program)
    """
    # Import dspy here to avoid requiring it at module load time
    try:
        import dspy
    except ImportError:
        raise ImportError(
            "DSPy is required for load_dataset(). "
            "Install it with: pip install dspy-ai"
        )

    # Fetch data from backend
    data = _fetch_dataset(name, version=version)

    input_fields = data.get("input_fields", [])
    examples_data = data.get("examples", [])
    field_mapping = data.get("field_mapping", {})

    # Convert to dspy.Example with inputs marked
    examples = []
    for ex_dict in examples_data:
        # Apply field mapping to transform flat data to nested structure
        # e.g., {"input_name": "Foo"} -> {"place_one": {"name": "Foo"}}
        if field_mapping:
            ex_dict = _apply_field_mapping(ex_dict, field_mapping)

        example = dspy.Example(**ex_dict)

        # Determine input fields for .with_inputs()
        # Use top-level keys from mapped fields (e.g., "place_one" not "place_one.name")
        if input_fields:
            # Extract top-level field names from potentially dotted paths
            top_level_inputs = set()
            for field in input_fields:
                top_level_inputs.add(field.split(".")[0])
            example = example.with_inputs(*list(top_level_inputs))

        examples.append(example)

    return examples
