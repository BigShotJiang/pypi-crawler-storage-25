"""Tests for SDK dataset loading functionality."""

import pytest
from unittest import mock


class TestApplyFieldMapping:
    """Tests for _apply_field_mapping() helper function."""

    def test_no_mapping_returns_original(self):
        """Empty or None mapping returns the original row."""
        from cmpnd.datasets import _apply_field_mapping

        row = {"name": "Foo", "address": "123 St"}
        assert _apply_field_mapping(row, {}) == row
        assert _apply_field_mapping(row, None) == row

    def test_simple_mapping(self):
        """Simple field renaming works."""
        from cmpnd.datasets import _apply_field_mapping

        row = {"input_name": "Foo", "output_match": True}
        mapping = {"input_name": "name", "output_match": "match"}

        result = _apply_field_mapping(row, mapping)
        assert result == {"name": "Foo", "match": True}

    def test_nested_mapping_single_level(self):
        """Dot notation creates nested dict."""
        from cmpnd.datasets import _apply_field_mapping

        row = {"input_name": "Cafe", "input_address": "123 Main St"}
        mapping = {
            "input_name": "place.name",
            "input_address": "place.address",
        }

        result = _apply_field_mapping(row, mapping)
        assert result == {
            "place": {"name": "Cafe", "address": "123 Main St"}
        }

    def test_multiple_nested_targets(self):
        """Multiple top-level nested objects work."""
        from cmpnd.datasets import _apply_field_mapping

        row = {
            "name1": "Cafe A",
            "addr1": "123 St",
            "name2": "Cafe B",
            "addr2": "456 Ave",
            "distance": 0.5,
        }
        mapping = {
            "name1": "place_one.name",
            "addr1": "place_one.address",
            "name2": "place_two.name",
            "addr2": "place_two.address",
            "distance": "distance",
        }

        result = _apply_field_mapping(row, mapping)
        assert result == {
            "place_one": {"name": "Cafe A", "address": "123 St"},
            "place_two": {"name": "Cafe B", "address": "456 Ave"},
            "distance": 0.5,
        }

    def test_deep_nesting(self):
        """Multi-level dot notation works."""
        from cmpnd.datasets import _apply_field_mapping

        row = {"city": "NYC"}
        mapping = {"city": "location.address.city"}

        result = _apply_field_mapping(row, mapping)
        assert result == {
            "location": {"address": {"city": "NYC"}}
        }

    def test_unmapped_fields_pass_through(self):
        """Fields not in mapping are preserved."""
        from cmpnd.datasets import _apply_field_mapping

        row = {"mapped_field": "value", "extra_field": "extra", "id": 123}
        mapping = {"mapped_field": "target.value"}

        result = _apply_field_mapping(row, mapping)
        assert result == {
            "target": {"value": "value"},
            "extra_field": "extra",
            "id": 123,
        }

    def test_missing_source_field_skipped(self):
        """Missing source fields in row are skipped."""
        from cmpnd.datasets import _apply_field_mapping

        row = {"present": "value"}
        mapping = {"present": "target", "missing": "other"}

        result = _apply_field_mapping(row, mapping)
        assert result == {"target": "value"}

    def test_mixed_nested_and_simple(self):
        """Mix of nested and simple mappings work together."""
        from cmpnd.datasets import _apply_field_mapping

        row = {
            "input_name": "Store",
            "input_rating": 4.5,
            "expected_match": True,
        }
        mapping = {
            "input_name": "place.name",
            "input_rating": "place.rating",
            "expected_match": "match",
        }

        result = _apply_field_mapping(row, mapping)
        assert result == {
            "place": {"name": "Store", "rating": 4.5},
            "match": True,
        }

    def test_preserves_value_types(self):
        """Different value types are preserved."""
        from cmpnd.datasets import _apply_field_mapping

        row = {
            "str_field": "text",
            "int_field": 42,
            "float_field": 3.14,
            "bool_field": True,
            "list_field": [1, 2, 3],
            "dict_field": {"nested": "value"},
            "none_field": None,
        }
        mapping = {
            "str_field": "output.str",
            "int_field": "output.int",
            "float_field": "output.float",
            "bool_field": "output.bool",
            "list_field": "output.list",
            "dict_field": "output.dict",
            "none_field": "output.none",
        }

        result = _apply_field_mapping(row, mapping)
        assert result["output"]["str"] == "text"
        assert result["output"]["int"] == 42
        assert result["output"]["float"] == 3.14
        assert result["output"]["bool"] is True
        assert result["output"]["list"] == [1, 2, 3]
        assert result["output"]["dict"] == {"nested": "value"}
        assert result["output"]["none"] is None


# Skip if dspy not installed
dspy = pytest.importorskip("dspy")


class TestLoadDataset:
    """Test cmpnd.load_dataset() function."""

    def setup_method(self):
        """Configure SDK before each test."""
        import cmpnd
        cmpnd.configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clean up after test."""
        from cmpnd.config import _config
        _config.set(None)

    def test_load_returns_list(self):
        """load_dataset returns a list."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q1", "answer": "A1"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            assert isinstance(result, list)

    def test_load_returns_dspy_examples(self):
        """Each item is a dspy.Example."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [
                {"question": "Q1", "answer": "A1"},
                {"question": "Q2", "answer": "A2"},
            ],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            for item in result:
                assert isinstance(item, dspy.Example)

    def test_examples_have_inputs_marked(self):
        """Examples have .with_inputs() applied correctly."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question", "context"],
            "examples": [{"question": "Q", "context": "C", "answer": "A"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            example = result[0]

            # Check input keys are set
            assert example._input_keys == {"question", "context"}

    def test_inputs_method_returns_correct_fields(self):
        """example.inputs() returns only input fields."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q1", "answer": "A1"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            inputs = result[0].inputs()

            assert "question" in inputs
            assert "answer" not in inputs

    def test_labels_method_returns_output_fields(self):
        """example.labels() returns expected output fields."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q1", "answer": "A1"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            labels = result[0].labels()

            assert "answer" in labels
            assert "question" not in labels

    def test_load_with_version_number(self):
        """Can load specific version by number."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 5,
            "input_fields": ["q"],
            "examples": [],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response) as mock_fetch:
            load_dataset("test", version=5)
            mock_fetch.assert_called_once_with("test", version=5)

    def test_load_with_version_tag(self):
        """Can load specific version by tag name."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 3,
            "input_fields": ["q"],
            "examples": [],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response) as mock_fetch:
            load_dataset("test", version="prod")
            mock_fetch.assert_called_once_with("test", version="prod")

    def test_load_latest_by_default(self):
        """No version parameter loads latest."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 10,
            "input_fields": ["q"],
            "examples": [],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response) as mock_fetch:
            load_dataset("test")
            mock_fetch.assert_called_once_with("test", version=None)

    def test_dataset_not_found_raises(self):
        """Non-existent dataset raises DatasetNotFoundError."""
        from cmpnd.datasets import load_dataset, DatasetNotFoundError

        with mock.patch("cmpnd.datasets._fetch_dataset", side_effect=DatasetNotFoundError("not-found")):
            with pytest.raises(DatasetNotFoundError):
                load_dataset("not-found")

    def test_version_not_found_raises(self):
        """Non-existent version raises VersionNotFoundError."""
        from cmpnd.datasets import load_dataset, VersionNotFoundError

        with mock.patch("cmpnd.datasets._fetch_dataset", side_effect=VersionNotFoundError("test", "v99")):
            with pytest.raises(VersionNotFoundError):
                load_dataset("test", version="v99")


class TestDSPyCompatibility:
    """Test that loaded datasets work with DSPy patterns."""

    def setup_method(self):
        import cmpnd
        cmpnd.configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        from cmpnd.config import _config
        _config.set(None)

    def test_example_dict_access(self):
        """Examples support dict-style access: example['field']."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q1", "answer": "A1"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            assert result[0]["question"] == "Q1"
            assert result[0]["answer"] == "A1"

    def test_example_attr_access(self):
        """Examples support attribute access: example.field."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q1", "answer": "A1"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            assert result[0].question == "Q1"
            assert result[0].answer == "A1"

    def test_example_toDict(self):
        """Examples have working toDict() method."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q1", "answer": "A1"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            d = result[0].toDict()
            assert d == {"question": "Q1", "answer": "A1"}

    def test_empty_dataset_returns_empty_list(self):
        """Empty dataset returns empty list, not error."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 0,
            "input_fields": ["question"],
            "examples": [],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            assert result == []

    def test_multiple_input_fields(self):
        """Multiple input fields are all marked as inputs."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question", "context", "history"],
            "examples": [{
                "question": "Q",
                "context": "C",
                "history": "H",
                "answer": "A"
            }],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            inputs = result[0].inputs()

            assert "question" in inputs
            assert "context" in inputs
            assert "history" in inputs
            assert "answer" not in inputs

    def test_can_iterate(self):
        """Loaded dataset can be iterated."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["q"],
            "examples": [
                {"q": "Q1", "a": "A1"},
                {"q": "Q2", "a": "A2"},
                {"q": "Q3", "a": "A3"},
            ],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            questions = [ex.q for ex in result]
            assert questions == ["Q1", "Q2", "Q3"]

    def test_can_slice(self):
        """Loaded dataset can be sliced."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["q"],
            "examples": [
                {"q": "Q1", "a": "A1"},
                {"q": "Q2", "a": "A2"},
                {"q": "Q3", "a": "A3"},
            ],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            subset = result[:2]
            assert len(subset) == 2
            assert subset[0].q == "Q1"
            assert subset[1].q == "Q2"


class TestFieldMappingIntegration:
    """Test field_mapping applied during load_dataset()."""

    def setup_method(self):
        import cmpnd
        cmpnd.configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        from cmpnd.config import _config
        _config.set(None)

    def test_nested_field_mapping_applied(self):
        """Field mapping transforms flat data to nested structure."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["place_one.name", "place_one.address"],
            "field_mapping": {
                "input_name": "place_one.name",
                "input_address": "place_one.address",
            },
            "examples": [
                {"input_name": "Cafe", "input_address": "123 Main St", "match": True}
            ],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            example = result[0]

            # Nested structure should be created
            assert hasattr(example, "place_one")
            assert example.place_one == {"name": "Cafe", "address": "123 Main St"}
            # Unmapped field passed through
            assert example.match is True

    def test_inputs_marked_at_top_level(self):
        """With nested mappings, top-level field is marked as input."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["place.name", "place.address"],
            "field_mapping": {
                "name": "place.name",
                "address": "place.address",
            },
            "examples": [
                {"name": "Store", "address": "456 Ave", "output": "result"}
            ],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            example = result[0]

            # "place" should be in input_keys (top-level of place.name)
            assert "place" in example._input_keys

    def test_multiple_nested_objects(self):
        """Multiple top-level nested objects work."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["place_one.name", "place_two.name"],
            "field_mapping": {
                "name1": "place_one.name",
                "addr1": "place_one.address",
                "name2": "place_two.name",
                "addr2": "place_two.address",
            },
            "examples": [
                {
                    "name1": "A",
                    "addr1": "1 St",
                    "name2": "B",
                    "addr2": "2 St",
                    "distance": 0.5,
                }
            ],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            example = result[0]

            assert example.place_one == {"name": "A", "address": "1 St"}
            assert example.place_two == {"name": "B", "address": "2 St"}
            assert example.distance == 0.5

    def test_no_mapping_works(self):
        """Without field_mapping, data passes through unchanged."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "examples": [{"question": "Q", "answer": "A"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            assert result[0].question == "Q"
            assert result[0].answer == "A"

    def test_empty_mapping_works(self):
        """Empty field_mapping passes data through unchanged."""
        from cmpnd.datasets import load_dataset

        mock_response = {
            "name": "test",
            "version": 1,
            "input_fields": ["question"],
            "field_mapping": {},
            "examples": [{"question": "Q", "answer": "A"}],
        }
        with mock.patch("cmpnd.datasets._fetch_dataset", return_value=mock_response):
            result = load_dataset("test")
            assert result[0].question == "Q"
            assert result[0].answer == "A"
