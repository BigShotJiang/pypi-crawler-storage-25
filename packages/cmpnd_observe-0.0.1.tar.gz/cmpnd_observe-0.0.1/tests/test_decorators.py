"""Tests for decorators and context managers."""

from unittest import mock
from uuid import uuid4

import pytest

from cmpnd.config import configure
from cmpnd.context import clear_context, get_current_span
from cmpnd.decorators import start_span, trace
from cmpnd.models import SpanType, TraceStatus


class TestStartSpan:
    """Tests for start_span context manager."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_start_span_creates_span(self):
        """Test start_span creates a span."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("test_span") as span:
                assert span.name == "test_span"
                assert span.span_type == SpanType.UNKNOWN
                assert span.start_time is not None

    def test_start_span_with_type(self):
        """Test start_span with custom span type."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("retrieval", span_type=SpanType.RETRIEVE) as span:
                assert span.span_type == SpanType.RETRIEVE

    def test_start_span_with_tags(self):
        """Test start_span with tags."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("tagged", tags={"key": "value"}) as span:
                assert span.attributes["key"] == "value"

    def test_start_span_sets_end_time(self):
        """Test start_span sets end time on exit."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("test") as span:
                assert span.end_time is None
            assert span.end_time is not None

    def test_start_span_sets_ok_status(self):
        """Test start_span sets OK status on successful exit."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("test") as span:
                pass
            assert span.status == TraceStatus.OK

    def test_start_span_sets_error_on_exception(self):
        """Test start_span sets error status on exception."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with pytest.raises(ValueError):
                with start_span("test") as span:
                    raise ValueError("test error")

            assert span.status == TraceStatus.ERROR
            assert span.error_message == "test error"
            assert span.error_type == "ValueError"

    def test_start_span_nesting(self):
        """Test nested start_span creates parent-child relationship."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("parent") as parent_span:
                assert get_current_span() is parent_span

                with start_span("child") as child_span:
                    assert get_current_span() is child_span
                    assert child_span.parent_span_id == parent_span.span_id

                # After child exits, parent is current again
                assert get_current_span() is parent_span

    def test_start_span_allows_setting_outputs(self):
        """Test can set outputs within span context."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            with start_span("test") as span:
                span.set_outputs({"result": 42})

            assert span.outputs == {"result": 42}


class TestTraceDecorator:
    """Tests for @trace decorator."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_trace_decorator_sync_function(self):
        """Test @trace decorator on sync function."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            @trace(name="my_func")
            def my_function(x, y):
                return x + y

            result = my_function(2, 3)
            assert result == 5

    def test_trace_decorator_preserves_function_name(self):
        """Test @trace preserves function metadata."""
        @trace()
        def original_function():
            """Original docstring."""
            pass

        assert original_function.__name__ == "original_function"
        assert original_function.__doc__ == "Original docstring."

    def test_trace_decorator_default_name(self):
        """Test @trace uses function name as default span name."""
        captured_span = None

        def mock_exporter():
            class MockExporter:
                def export_span(self, span):
                    nonlocal captured_span
                    captured_span = span
            return MockExporter()

        with mock.patch("cmpnd.decorators.get_exporter", mock_exporter):
            @trace()
            def my_custom_function():
                return 42

            my_custom_function()

        assert captured_span is not None
        assert captured_span.name == "my_custom_function"

    def test_trace_decorator_captures_inputs(self):
        """Test @trace captures function inputs."""
        captured_span = None

        def mock_exporter():
            class MockExporter:
                def export_span(self, span):
                    nonlocal captured_span
                    captured_span = span
            return MockExporter()

        with mock.patch("cmpnd.decorators.get_exporter", mock_exporter):
            @trace(capture_inputs=True)
            def func_with_args(name, count=10):
                return f"{name}: {count}"

            func_with_args("test", count=5)

        assert captured_span.inputs["name"] == "test"
        assert captured_span.inputs["count"] == 5

    def test_trace_decorator_captures_outputs(self):
        """Test @trace captures function outputs."""
        captured_span = None

        def mock_exporter():
            class MockExporter:
                def export_span(self, span):
                    nonlocal captured_span
                    captured_span = span
            return MockExporter()

        with mock.patch("cmpnd.decorators.get_exporter", mock_exporter):
            @trace(capture_outputs=True)
            def returning_func():
                return {"answer": 42}

            returning_func()

        assert captured_span.outputs == {"answer": 42}

    def test_trace_decorator_with_exception(self):
        """Test @trace handles exceptions."""
        captured_span = None

        def mock_exporter():
            class MockExporter:
                def export_span(self, span):
                    nonlocal captured_span
                    captured_span = span
            return MockExporter()

        with mock.patch("cmpnd.decorators.get_exporter", mock_exporter):
            @trace()
            def failing_func():
                raise RuntimeError("intentional failure")

            with pytest.raises(RuntimeError):
                failing_func()

        assert captured_span.status == TraceStatus.ERROR
        assert "intentional failure" in captured_span.error_message

    def test_trace_decorator_with_span_type(self):
        """Test @trace with custom span type."""
        captured_span = None

        def mock_exporter():
            class MockExporter:
                def export_span(self, span):
                    nonlocal captured_span
                    captured_span = span
            return MockExporter()

        with mock.patch("cmpnd.decorators.get_exporter", mock_exporter):
            @trace(span_type=SpanType.RETRIEVE)
            def retrieval_func():
                return ["doc1", "doc2"]

            retrieval_func()

        assert captured_span.span_type == SpanType.RETRIEVE


class TestTraceDecoratorAsync:
    """Tests for @trace decorator on async functions."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    @pytest.mark.asyncio
    async def test_trace_decorator_async_function(self):
        """Test @trace decorator on async function."""
        with mock.patch("cmpnd.decorators.get_exporter", return_value=None):
            @trace(name="async_func")
            async def my_async_function(x):
                return x * 2

            result = await my_async_function(5)
            assert result == 10

    @pytest.mark.asyncio
    async def test_trace_decorator_async_with_exception(self):
        """Test @trace handles async exceptions."""
        captured_span = None

        def mock_exporter():
            class MockExporter:
                def export_span(self, span):
                    nonlocal captured_span
                    captured_span = span
            return MockExporter()

        with mock.patch("cmpnd.decorators.get_exporter", mock_exporter):
            @trace()
            async def failing_async():
                raise ValueError("async error")

            with pytest.raises(ValueError):
                await failing_async()

        assert captured_span.status == TraceStatus.ERROR
