"""Integration tests for the cmpnd SDK with DSPy.

These tests require DSPy to be installed and verify end-to-end functionality.
"""

from unittest import mock

import pytest

# Skip all tests if dspy is not installed
dspy = pytest.importorskip("dspy")

from cmpnd import auto_instrument, configure, shutdown_exporter
from cmpnd.callback import CmpndCallback
from cmpnd.context import clear_context
from cmpnd.models import SpanType, TraceStatus


class TestAutoInstrument:
    """Tests for auto_instrument function."""

    def teardown_method(self):
        """Clean up after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        shutdown_exporter()
        # Reset dspy callbacks
        dspy.configure(callbacks=[])

    def test_auto_instrument_registers_callback(self):
        """Test auto_instrument registers callback with dspy."""
        configure(api_key="test_key")
        callback = auto_instrument()

        assert isinstance(callback, CmpndCallback)

        # Check callback is registered
        callbacks = dspy.settings.get("callbacks", [])
        assert any(isinstance(cb, CmpndCallback) for cb in callbacks)

    def test_auto_instrument_requires_configure(self):
        """Test auto_instrument raises if not configured."""
        with pytest.raises(RuntimeError, match="not configured"):
            auto_instrument()

    def test_auto_instrument_avoids_duplicates(self):
        """Test auto_instrument doesn't register duplicate callbacks."""
        configure(api_key="test_key")
        auto_instrument()
        auto_instrument()
        auto_instrument()

        callbacks = dspy.settings.get("callbacks", [])
        cmpnd_callbacks = [cb for cb in callbacks if isinstance(cb, CmpndCallback)]
        assert len(cmpnd_callbacks) == 1


class TestEndToEndTracing:
    """End-to-end tests for tracing DSPy programs."""

    def teardown_method(self):
        """Clean up after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        shutdown_exporter()
        dspy.configure(callbacks=[])

    def test_trace_predict_module(self):
        """Test tracing a simple Predict module."""
        exported_traces = []
        exported_spans = []

        class MockExporter:
            def export_trace_start(self, trace):
                pass

            def export_trace_finalize(self, trace):
                exported_traces.append(trace)

            def export_trace_stats(self, trace):
                pass

            def export_span(self, span):
                exported_spans.append(span)

            def export_trace(self, trace):
                exported_traces.append(trace)

        configure(api_key="test_key")

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            with mock.patch("cmpnd.callback.ensure_exporter_started"):
                callback = CmpndCallback()
                dspy.configure(callbacks=[callback])

                # Create a mock LM that returns a fixed response
                mock_lm = mock.MagicMock()
                mock_lm.return_value = {
                    "choices": [{"message": {"content": "Paris is the capital of France."}}],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 20, "total_tokens": 30},
                }

                # Simulate module call by directly invoking callbacks
                predict_instance = mock.MagicMock(spec=dspy.Predict)
                predict_instance.__class__.__name__ = "Predict"
                predict_instance.signature = None
                predict_instance.demos = None

                # Start module
                callback.on_module_start(
                    call_id="predict_1",
                    instance=predict_instance,
                    inputs={"kwargs": {"question": "What is the capital of France?"}},
                )

                # End module with output
                mock_output = mock.MagicMock(spec=dspy.Prediction)
                mock_output.toDict.return_value = {"answer": "Paris"}

                callback.on_module_end(
                    call_id="predict_1",
                    outputs=mock_output,
                )

        # Verify trace was created (batch path for Predict)
        assert len(exported_traces) == 1
        trace = exported_traces[0]
        assert trace.status == TraceStatus.OK

        # Batch path: spans are NOT individually exported, they're attached to the trace
        assert len(exported_spans) == 0
        assert len(trace._batch_spans) == 1
        span = trace._batch_spans[0]
        assert span.span_type == SpanType.PREDICT
        assert span.status == TraceStatus.OK

    def test_trace_nested_modules(self):
        """Test tracing nested module calls."""
        exported_traces = []
        exported_spans = []

        class MockExporter:
            def export_trace_start(self, trace):
                pass

            def export_trace_finalize(self, trace):
                exported_traces.append(trace)

            def export_trace_stats(self, trace):
                pass

            def export_span(self, span):
                exported_spans.append(span)

            def export_trace(self, trace):
                exported_traces.append(trace)

        configure(api_key="test_key")

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            with mock.patch("cmpnd.callback.ensure_exporter_started"):
                callback = CmpndCallback()

                # Create mock instances
                outer_instance = mock.MagicMock(spec=dspy.Module)
                outer_instance.__class__.__name__ = "Pipeline"
                outer_instance.signature = None
                outer_instance.demos = None

                inner_instance = mock.MagicMock(spec=dspy.Predict)
                inner_instance.__class__.__name__ = "Predict"
                inner_instance.signature = None
                inner_instance.demos = None

                # Start outer module (root)
                callback.on_module_start(
                    call_id="outer_1",
                    instance=outer_instance,
                    inputs={"kwargs": {"query": "test"}},
                )

                # Start inner module (nested)
                callback.on_module_start(
                    call_id="inner_1",
                    instance=inner_instance,
                    inputs={"kwargs": {"question": "nested"}},
                )

                # End inner module
                mock_inner_output = mock.MagicMock(spec=dspy.Prediction)
                mock_inner_output.toDict.return_value = {"answer": "inner result"}
                callback.on_module_end(call_id="inner_1", outputs=mock_inner_output)

                # End outer module
                mock_outer_output = mock.MagicMock(spec=dspy.Prediction)
                mock_outer_output.toDict.return_value = {"result": "outer result"}
                callback.on_module_end(call_id="outer_1", outputs=mock_outer_output)

        # Should have 1 trace; batch path attaches spans to trace
        assert len(exported_traces) == 1
        assert len(exported_spans) == 0  # Batch path: no individual span export
        batch_spans = exported_traces[0]._batch_spans
        assert len(batch_spans) == 2

        # Inner span should have outer span as parent
        outer_span = next(s for s in batch_spans if s.name == "Pipeline.forward")
        inner_span = next(s for s in batch_spans if s.name == "Predict.forward")

        assert inner_span.parent_span_id == outer_span.span_id
        assert inner_span.trace_id == outer_span.trace_id

    def test_trace_with_lm_calls(self):
        """Test tracing module with LM calls."""
        exported_traces = []

        class MockExporter:
            def export_trace_start(self, trace):
                pass

            def export_trace_finalize(self, trace):
                exported_traces.append(trace)

            def export_trace_stats(self, trace):
                pass

            def export_span(self, span):
                pass

            def export_trace(self, trace):
                exported_traces.append(trace)

        configure(api_key="test_key")

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            with mock.patch("cmpnd.callback.ensure_exporter_started"):
                callback = CmpndCallback()

                # Module instance
                module_instance = mock.MagicMock(spec=dspy.Predict)
                module_instance.__class__.__name__ = "Predict"
                module_instance.signature = None
                module_instance.demos = None

                # LM instance
                lm_instance = mock.MagicMock(spec=dspy.LM)
                lm_instance.__class__.__name__ = "LM"
                lm_instance.model = "gpt-4o-mini"
                lm_instance.model_type = "chat"
                lm_instance.cache = False
                lm_instance.kwargs = {}

                # Start module
                callback.on_module_start(
                    call_id="mod_1",
                    instance=module_instance,
                    inputs={"kwargs": {"question": "test"}},
                )

                # Start LM call (nested in module)
                callback.on_lm_start(
                    call_id="lm_1",
                    instance=lm_instance,
                    inputs={"messages": []},
                )

                # End LM call
                callback.on_lm_end(
                    call_id="lm_1",
                    outputs={
                        "choices": [{"message": {"content": "response"}}],
                        "usage": {"prompt_tokens": 50, "completion_tokens": 25, "total_tokens": 75},
                    },
                )

                # End module
                mock_output = mock.MagicMock(spec=dspy.Prediction)
                mock_output.toDict.return_value = {"answer": "test"}
                callback.on_module_end(call_id="mod_1", outputs=mock_output)

        # Batch path: spans are attached to trace, not individually exported
        assert len(exported_traces) == 1
        batch_spans = exported_traces[0]._batch_spans
        assert len(batch_spans) == 2

        module_span = next(s for s in batch_spans if s.span_type == SpanType.PREDICT)
        lm_span = next(s for s in batch_spans if s.span_type == SpanType.LM_CALL)

        # LM span should be child of module span
        assert lm_span.parent_span_id == module_span.span_id

        # LM span should have token usage
        assert lm_span.prompt_tokens == 50
        assert lm_span.completion_tokens == 25
        assert lm_span.total_tokens == 75
        assert lm_span.model_name == "gpt-4o-mini"


class TestExporterIntegration:
    """Tests for exporter integration."""

    def teardown_method(self):
        """Clean up after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        shutdown_exporter()
        dspy.configure(callbacks=[])

    def test_exporter_buffers_spans_until_trace(self):
        """Test that exporter buffers spans until trace arrives.

        With the streaming exporter, spans are sent both directly (streaming
        path) AND buffered for the old trace path. So we expect 2 POST calls:
        one to /api/v1/traces/:id/spans and one to /api/v1/traces.
        """
        from cmpnd.exporter import BatchExporter
        from cmpnd.models import SpanBuilder, TraceBuilder
        from uuid import uuid4
        from datetime import datetime, timezone

        config = mock.MagicMock()
        config.endpoint = "http://localhost:8000"
        config.api_key = "test_key"
        config.batch_size = 100
        config.flush_interval_seconds = 5.0
        config.max_queue_size = 1000

        exporter = BatchExporter(config)

        # Create trace and spans
        trace_id = uuid4()
        trace = TraceBuilder(
            trace_id=trace_id,
            start_time=datetime.now(timezone.utc),
            program_name="Test",
        )

        span1 = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name="span1",
            start_time=datetime.now(timezone.utc),
        )

        span2 = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace_id,
            name="span2",
            start_time=datetime.now(timezone.utc),
        )

        # Queue spans first (before trace)
        exporter.export_span(span1)
        exporter.export_span(span2)

        # Queue trace
        exporter.export_trace(trace)

        # Manually flush to test batching behavior
        # Get items from queue
        items = []
        while not exporter._queue.empty():
            items.append(exporter._queue.get_nowait())

        # Simulate flush
        with mock.patch.object(exporter, "_client") as mock_client:
            mock_response = mock.MagicMock()
            mock_response.raise_for_status = mock.MagicMock()
            mock_client.post.return_value = mock_response

            exporter._flush_batch(items)

            # Spans are sent via streaming path + trace picks up buffered spans
            assert mock_client.post.call_count == 2

            # Identify calls by URL
            calls_by_url = {}
            for c in mock_client.post.call_args_list:
                url = c[0][0]
                calls_by_url[url] = c

            # Old-path trace POST with embedded spans
            trace_call = calls_by_url["/api/v1/traces"]
            trace_data = trace_call[1]["json"]
            assert len(trace_data["spans"]) == 2

            # Streaming spans POST
            span_url = f"/api/v1/traces/{trace_id}/spans"
            span_call = calls_by_url[span_url]
            assert len(span_call[1]["json"]["spans"]) == 2
