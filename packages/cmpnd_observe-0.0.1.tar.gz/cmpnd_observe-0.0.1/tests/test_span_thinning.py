"""Tests for span thinning — stripping redundant data from child spans."""
import json
import pytest
from uuid import uuid4
from cmpnd.models import SpanBuilder, SpanType


class TestDemoCaptureOnPredictSpan:
    def test_predict_span_captures_demos(self):
        span = SpanBuilder(
            span_id=uuid4(),
            name="Predict.forward",
            span_type=SpanType.PREDICT,
        )
        demos = [
            {"question": "What is 2+2?", "answer": "4"},
            {"question": "What is 3+3?", "answer": "6"},
        ]
        span.demos = demos
        api_dict = span.to_api_dict()
        assert api_dict["demos"] == demos
        assert api_dict["demo_count"] == 2

    def test_predict_span_without_demos(self):
        span = SpanBuilder(
            span_id=uuid4(),
            name="Predict.forward",
            span_type=SpanType.PREDICT,
        )
        api_dict = span.to_api_dict()
        assert api_dict["demos"] == []
        assert api_dict["demo_count"] == 0


def _make_span(span_type: SpanType, name: str = "test") -> SpanBuilder:
    """Helper to create a span with realistic inputs/outputs."""
    span = SpanBuilder(
        span_id=uuid4(),
        name=name,
        span_type=span_type,
    )
    span.inputs = {
        "question": "What is the capital of France?",
        "context": "France is a country in Western Europe. Its capital is Paris.",
    }
    span.outputs = {
        "answer": "Paris",
        "confidence": 0.95,
    }
    return span


class TestSpanThinning:
    def test_adapter_format_span_is_thinned(self):
        span = _make_span(SpanType.ADAPTER_FORMAT, "ChatAdapter.format")
        span.thin()
        assert span.inputs is None
        assert span.outputs is None
        assert span.attributes["thinned"] == "true"

    def test_lm_call_span_thins_inputs_keeps_outputs(self):
        span = _make_span(SpanType.LM_CALL, "LM.__call__")
        span.model_name = "gpt-4o"
        span.prompt_tokens = 150
        span.completion_tokens = 50
        span.thin()
        assert span.inputs is None
        assert span.outputs is not None
        assert span.outputs["answer"] == "Paris"
        assert span.attributes["thinned"] == "true"

    def test_adapter_parse_span_is_thinned(self):
        span = _make_span(SpanType.ADAPTER_PARSE, "ChatAdapter.parse")
        span.thin()
        assert span.inputs is None
        assert span.outputs is None
        assert span.attributes["thinned"] == "true"

    def test_predict_span_is_not_thinned(self):
        span = _make_span(SpanType.PREDICT, "Predict.forward")
        span.thin()
        assert span.inputs is not None
        assert span.outputs is not None
        assert "thinned" not in span.attributes

    def test_module_span_is_not_thinned(self):
        span = _make_span(SpanType.MODULE, "MyModule.forward")
        span.thin()
        assert span.inputs is not None
        assert span.outputs is not None
        assert "thinned" not in span.attributes

    def test_thinned_trace_has_reduced_size(self):
        """Build 4 spans (predict + 3 children), thin the children, verify size reduction."""
        # Predict span has modest data (it's the canonical copy)
        predict = _make_span(SpanType.PREDICT, "Predict.forward")
        predict.inputs = {"question": "What is the capital of France?"}
        predict.outputs = {"answer": "Paris"}

        # Child spans carry large redundant payloads (formatted prompts, raw responses)
        adapter_format = _make_span(SpanType.ADAPTER_FORMAT, "ChatAdapter.format")
        adapter_format.inputs = {"question": "What is the capital of France?" * 50}
        adapter_format.outputs = {"formatted_prompt": "System: You are a helpful assistant..." * 100}

        lm_call = _make_span(SpanType.LM_CALL, "LM.__call__")
        lm_call.inputs = {"messages": [{"role": "user", "content": "long prompt content..." * 100}]}
        lm_call.outputs = {"response": "Paris is the capital of France." * 20}
        lm_call.model_name = "gpt-4o"
        lm_call.prompt_tokens = 500
        lm_call.completion_tokens = 100

        adapter_parse = _make_span(SpanType.ADAPTER_PARSE, "ChatAdapter.parse")
        adapter_parse.inputs = {"raw_response": "Paris is the capital of France." * 50}
        adapter_parse.outputs = {"answer": "Paris"}

        spans = [predict, adapter_format, lm_call, adapter_parse]
        unthinned_size = sum(len(json.dumps(s.to_api_dict())) for s in spans)

        # Thin the 3 child spans
        adapter_format.thin()
        lm_call.thin()
        adapter_parse.thin()

        thinned_size = sum(len(json.dumps(s.to_api_dict())) for s in spans)
        assert thinned_size < unthinned_size * 0.50, (
            f"Expected >50% reduction: {thinned_size} vs {unthinned_size}"
        )

    def test_thinned_spans_preserve_metadata(self):
        """LM_CALL keeps model_name, prompt_tokens, completion_tokens, cost after thinning."""
        span = _make_span(SpanType.LM_CALL, "LM.__call__")
        span.model_name = "gpt-4o"
        span.prompt_tokens = 500
        span.completion_tokens = 100
        span.cost = 0.0035
        span.thin()
        assert span.model_name == "gpt-4o"
        assert span.prompt_tokens == 500
        assert span.completion_tokens == 100
        assert span.cost == 0.0035

    def test_thinned_span_serializes_none_not_empty_dict(self):
        """After thinning, to_api_dict() should have None for inputs/outputs, not {}."""
        span = _make_span(SpanType.ADAPTER_FORMAT, "ChatAdapter.format")
        span.thin()
        api_dict = span.to_api_dict()
        assert api_dict["inputs"] is None
        assert api_dict["outputs"] is None
