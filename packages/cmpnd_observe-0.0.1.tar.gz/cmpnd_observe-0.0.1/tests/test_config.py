"""Tests for configuration management."""

import os
from unittest import mock

import pytest

from cmpnd.config import Config, configure, get_config, require_config


class TestConfig:
    """Tests for Config dataclass."""

    def test_config_defaults(self):
        """Test default configuration values."""
        config = Config(api_key="test_key")
        assert config.api_key == "test_key"
        assert config.endpoint == "https://api.cmpnd.io"
        assert config.project == "default"
        assert config.batch_size == 100
        assert config.flush_interval_seconds == 5.0
        assert config.capture_inputs is True
        assert config.capture_outputs is True

    def test_config_custom_values(self):
        """Test custom configuration values."""
        config = Config(
            api_key="custom_key",
            endpoint="http://localhost:8000",
            project="my-project",
            batch_size=50,
            flush_interval_seconds=2.0,
        )
        assert config.api_key == "custom_key"
        assert config.endpoint == "http://localhost:8000"
        assert config.project == "my-project"
        assert config.batch_size == 50
        assert config.flush_interval_seconds == 2.0


class TestConfigure:
    """Tests for configure() function."""

    def teardown_method(self):
        """Reset config after each test."""
        from cmpnd.config import _config
        _config.set(None)

    def test_configure_with_api_key(self):
        """Test configuration with explicit API key."""
        config = configure(api_key="ct_test123")
        assert config.api_key == "ct_test123"
        assert get_config() is config

    def test_configure_with_endpoint(self):
        """Test configuration with custom endpoint."""
        config = configure(
            api_key="ct_test123",
            endpoint="http://localhost:8000",
        )
        assert config.endpoint == "http://localhost:8000"

    def test_configure_with_project(self):
        """Test configuration with project name."""
        config = configure(
            api_key="ct_test123",
            project="my-app",
        )
        assert config.project == "my-app"

    def test_configure_from_env_var(self):
        """Test configuration from environment variable."""
        with mock.patch.dict(os.environ, {"CMPND_API_KEY": "ct_from_env"}):
            config = configure()
            assert config.api_key == "ct_from_env"

    def test_configure_endpoint_from_env_var(self):
        """Test endpoint from environment variable."""
        with mock.patch.dict(os.environ, {
            "CMPND_API_KEY": "ct_test",
            "CMPND_ENDPOINT": "http://custom:9000",
        }):
            config = configure()
            assert config.endpoint == "http://custom:9000"

    def test_configure_missing_api_key_raises(self):
        """Test that missing API key raises ValueError."""
        with mock.patch.dict(os.environ, {}, clear=True):
            # Clear any existing CMPND_API_KEY
            os.environ.pop("CMPND_API_KEY", None)
            with pytest.raises(ValueError, match="API key required"):
                configure()

    def test_configure_with_default_tags(self):
        """Test configuration with default tags."""
        config = configure(
            api_key="ct_test123",
            default_tags={"env": "test", "version": "1.0"},
        )
        assert config.default_tags == {"env": "test", "version": "1.0"}


class TestRequireConfig:
    """Tests for require_config() function."""

    def teardown_method(self):
        """Reset config after each test."""
        from cmpnd.config import _config
        _config.set(None)

    def test_require_config_when_configured(self):
        """Test require_config returns config when configured."""
        configure(api_key="ct_test123")
        config = require_config()
        assert config.api_key == "ct_test123"

    def test_require_config_when_not_configured(self):
        """Test require_config raises when not configured."""
        with pytest.raises(RuntimeError, match="not configured"):
            require_config()
