"""End-to-end integration test for the GEPA callback pipeline.

Simulates a complete GEPA optimization lifecycle through the callback,
verifying the tracker collects all expected data.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from cmpnd.optimizers.gepa_callback import CmpndGEPACallback
from cmpnd.optimizers.tracker import OptimizationTracker


class TestGEPACallbackIntegration:
    """Integration tests for the full CmpndGEPACallback -> OptimizationTracker pipeline."""

    def _make_tracker(self) -> OptimizationTracker:
        return OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
            config={"auto": "light", "seed": 42},
            model_name="openai/gpt-4o-mini",
            reflection_model_name="openai/gpt-4o",
        )

    @patch("cmpnd.exporter.get_exporter", return_value=None)
    @patch("cmpnd.optimizers.gepa_callback.set_current_optimization_run_id")
    def test_full_optimization_lifecycle(self, mock_set_ctx, mock_exporter):
        """Simulate a complete GEPA optimization and verify tracker state."""
        tracker = self._make_tracker()
        callback = CmpndGEPACallback(tracker, defer_finalize=True)

        # --- 1. on_optimization_start ---
        callback.on_optimization_start({
            "seed_candidate": {"predictor": "You are a helpful assistant."},
            "trainset_size": 100,
            "valset_size": 50,
            "config": {"max_metric_calls": 200},
        })
        assert tracker.status == "running"
        assert tracker.max_metric_calls == 200

        # --- 2. on_evaluation_end for seed (iteration 0) ---
        callback.on_evaluation_end({
            "iteration": 0,
            "candidate_idx": 0,
            "scores": [0.5, 0.6, 0.7, 0.4, 0.8],
            "is_seed_candidate": True,
            "has_trajectories": True,
        })

        # --- 3. on_budget_updated after seed eval ---
        callback.on_budget_updated({
            "metric_calls_used": 5,
            "metric_calls_remaining": 195,
        })
        assert tracker.current_metric_calls == 5
        assert tracker.max_metric_calls == 200

        # --- 4. on_evaluation_end for iteration 1 ---
        callback.on_evaluation_end({
            "iteration": 1,
            "candidate_idx": 0,
            "scores": [0.7, 0.8, 0.9, 0.6, 0.85],
            "has_trajectories": True,
        })

        # --- 5. on_minibatch_sampled for iteration 1 ---
        callback.on_minibatch_sampled({
            "iteration": 1,
            "minibatch_ids": [3, 7, 12, 25, 41],
        })

        # --- 6. on_reflective_dataset_built for iteration 1 ---
        callback.on_reflective_dataset_built({
            "iteration": 1,
            "candidate_idx": 0,
            "components": ["predictor"],
            "dataset": {
                "predictor": [
                    {"Inputs": "What is 2+2?", "Generated_Outputs": "4", "Feedback": "Correct"},
                    {"Inputs": "What is 3+3?", "Generated_Outputs": "7", "Feedback": "Incorrect, expected 6"},
                ]
            },
        })

        # --- 7. on_proposal_start for iteration 1 ---
        callback.on_proposal_start({
            "iteration": 1,
            "parent_candidate": {"predictor": "You are a helpful assistant."},
            "components": ["predictor"],
        })

        # --- 8. on_proposal_end for iteration 1 ---
        callback.on_proposal_end({
            "iteration": 1,
            "new_instructions": {"predictor": "You are a precise math tutor. Always show your work."},
        })

        # --- 9. on_candidate_accepted for iteration 1 ---
        callback.on_candidate_accepted({"iteration": 1})

        # --- 10. on_valset_evaluated for candidates 0 and 1 ---
        callback.on_valset_evaluated({
            "candidate_idx": 0,
            "scores_by_val_id": {0: 0.6, 1: 0.7, 2: 0.5},
        })
        callback.on_valset_evaluated({
            "candidate_idx": 1,
            "scores_by_val_id": {0: 0.9, 1: 0.8, 2: 0.85},
        })

        # --- 11. on_budget_updated with remaining budget ---
        callback.on_budget_updated({
            "metric_calls_used": 20,
            "metric_calls_remaining": 180,
        })
        assert tracker.current_metric_calls == 20

        # --- 12. on_optimization_end with mock GEPAState ---
        mock_state = MagicMock()
        mock_state.program_candidates = [
            {"predictor": "seed instruction"},
            {"predictor": "improved instruction"},
        ]
        mock_state.parent_program_for_candidate = [[None], [0]]
        mock_state.prog_candidate_objective_scores = [{"default": 0.6}, {"default": 0.85}]
        mock_state.prog_candidate_val_subscores = [{0: 0.6, 1: 0.7}, {0: 0.9, 1: 0.8}]
        mock_state.num_metric_calls_by_discovery = [5, 15]
        mock_state.program_at_pareto_front_valset = {0: {1}, 1: {1}}

        callback.on_optimization_end({
            "best_candidate_idx": 1,
            "total_metric_calls": 20,
            "final_state": mock_state,
        })

        # Now manually finalize since we used defer_finalize=True
        tracker.finalize()

        # === Verify tracker state ===

        # Iterations were captured
        assert len(tracker.iterations) >= 1, "Expected at least 1 iteration"

        # Find iteration 1 and verify its data
        iter1 = None
        for it in tracker.iterations:
            if it.iteration == 1:
                iter1 = it
                break
        assert iter1 is not None, "Iteration 1 not found"
        assert len(iter1.eval_scores) > 0, "Iteration 1 should have eval_scores"
        assert len(iter1.reflective_dataset) > 0, "Iteration 1 should have reflective_dataset"
        assert len(iter1.parent_instructions) > 0, "Iteration 1 should have parent_instructions"
        assert len(iter1.proposed_instructions) > 0, "Iteration 1 should have proposed_instructions"
        assert iter1.accepted is True, "Iteration 1 should be accepted"
        assert iter1.minibatch_ids == [3, 7, 12, 25, 41], "Iteration 1 should have minibatch_ids"

        # Candidates extracted from GEPAState
        assert len(tracker.candidates) == 2, f"Expected 2 candidates, got {len(tracker.candidates)}"

        # Best candidate
        assert tracker.best_candidate_idx == 1

        # Metric calls
        assert tracker.total_metric_calls > 0
        assert tracker.current_metric_calls > 0

        # Status
        assert tracker.status == "completed"

        # Candidate 1 has val_scores_by_id from on_valset_evaluated
        candidate_1 = None
        for c in tracker.candidates:
            if c.candidate_idx == 1:
                candidate_1 = c
                break
        assert candidate_1 is not None, "Candidate 1 not found"
        assert len(candidate_1.val_scores_by_id) > 0, "Candidate 1 should have val_scores_by_id"
        assert candidate_1.val_scores_by_id == {"0": 0.9, "1": 0.8, "2": 0.85}

        # Pareto frontier is populated
        assert len(tracker.pareto_frontier) > 0, "Pareto frontier should be populated"
        assert 1 in tracker.pareto_frontier, "Candidate 1 should be in Pareto frontier"

    @patch("cmpnd.exporter.get_exporter", return_value=None)
    @patch("cmpnd.optimizers.gepa_callback.set_current_optimization_run_id")
    def test_error_lifecycle(self, mock_set_ctx, mock_exporter):
        """Verify that an unrecoverable error sets tracker status to failed."""
        tracker = self._make_tracker()
        callback = CmpndGEPACallback(tracker, defer_finalize=True)

        # Start optimization
        callback.on_optimization_start({
            "seed_candidate": {"predictor": "test"},
            "trainset_size": 50,
            "valset_size": 25,
            "config": {"max_metric_calls": 100},
        })
        assert tracker.status == "running"

        # Fire error with will_continue=False
        callback.on_error({
            "exception": RuntimeError("LM provider rate limit exceeded"),
            "will_continue": False,
            "iteration": 0,
        })

        assert tracker.status == "failed"
        assert tracker.error_message is not None
        assert "rate limit" in tracker.error_message.lower()
