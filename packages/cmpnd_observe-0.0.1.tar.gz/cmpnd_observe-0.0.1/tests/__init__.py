"""Tests for the cmpnd SDK."""
