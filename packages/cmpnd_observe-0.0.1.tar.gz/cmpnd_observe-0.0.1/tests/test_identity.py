"""Tests for identity.py - schema extraction and hash utilities."""

import pytest
from dataclasses import dataclass
from typing import Optional, List, Dict


class TestGetFieldSchema:
    """Tests for get_field_schema() function."""

    def test_returns_none_for_primitives(self):
        """Primitive types return None (no schema needed)."""
        from cmpnd.identity import get_field_schema

        assert get_field_schema(str) is None
        assert get_field_schema(int) is None
        assert get_field_schema(float) is None
        assert get_field_schema(bool) is None

    def test_returns_none_for_none(self):
        """None annotation returns None."""
        from cmpnd.identity import get_field_schema

        assert get_field_schema(None) is None

    def test_returns_none_for_generic_types(self):
        """Generic types like List, Dict return None."""
        from cmpnd.identity import get_field_schema

        assert get_field_schema(List[str]) is None
        assert get_field_schema(Dict[str, int]) is None
        assert get_field_schema(List[Dict[str, str]]) is None

    def test_list_of_complex_type(self):
        """List[X] where X is a dataclass/Pydantic model should extract schema."""
        from cmpnd.identity import get_field_schema

        @dataclass
        class Place:
            name: str
            address: str

        schema = get_field_schema(List[Place])
        assert schema is not None
        assert schema["type"] == "list[Place]"
        assert schema["fields"] == {"name": "str", "address": "str"}

    def test_dataclass_schema_extraction(self):
        """Dataclass fields are extracted correctly."""
        from cmpnd.identity import get_field_schema

        @dataclass
        class Place:
            name: str
            address: str
            zip_code: int

        schema = get_field_schema(Place)
        assert schema is not None
        assert schema["type"] == "Place"
        assert schema["fields"] == {
            "name": "str",
            "address": "str",
            "zip_code": "int",
        }

    def test_dataclass_with_optional_fields(self):
        """Dataclass with Optional fields works."""
        from cmpnd.identity import get_field_schema

        @dataclass
        class Person:
            name: str
            age: Optional[int]

        schema = get_field_schema(Person)
        assert schema is not None
        assert schema["type"] == "Person"
        assert "name" in schema["fields"]
        assert "age" in schema["fields"]

    def test_optional_dataclass_unwraps(self):
        """Optional[Dataclass] unwraps and returns the dataclass schema."""
        from cmpnd.identity import get_field_schema

        @dataclass
        class Location:
            lat: float
            lng: float

        schema = get_field_schema(Optional[Location])
        assert schema is not None
        assert schema["type"] == "Location"
        assert schema["fields"] == {"lat": "float", "lng": "float"}

    def test_nested_dataclass(self):
        """Nested dataclass shows type name, not nested schema."""
        from cmpnd.identity import get_field_schema

        @dataclass
        class Address:
            street: str
            city: str

        @dataclass
        class Company:
            name: str
            address: Address

        schema = get_field_schema(Company)
        assert schema is not None
        assert schema["fields"]["name"] == "str"
        # Nested dataclass shows as type name
        assert schema["fields"]["address"] == "Address"


class TestGetFieldSchemaPydantic:
    """Tests for get_field_schema() with Pydantic models."""

    @pytest.fixture
    def pydantic_available(self):
        """Check if Pydantic is available."""
        try:
            from pydantic import BaseModel
            return True
        except ImportError:
            pytest.skip("Pydantic not installed")

    def test_pydantic_v2_schema_extraction(self, pydantic_available):
        """Pydantic v2 BaseModel fields are extracted correctly."""
        from pydantic import BaseModel
        from cmpnd.identity import get_field_schema

        class Place(BaseModel):
            name: str
            address: str
            rating: float

        schema = get_field_schema(Place)
        assert schema is not None
        assert schema["type"] == "Place"
        assert schema["fields"] == {
            "name": "str",
            "address": "str",
            "rating": "float",
        }

    def test_pydantic_with_optional(self, pydantic_available):
        """Pydantic model with Optional fields works."""
        from pydantic import BaseModel
        from cmpnd.identity import get_field_schema

        class User(BaseModel):
            name: str
            email: Optional[str] = None

        schema = get_field_schema(User)
        assert schema is not None
        assert "name" in schema["fields"]
        assert "email" in schema["fields"]

    def test_optional_pydantic_unwraps(self, pydantic_available):
        """Optional[PydanticModel] unwraps correctly."""
        from pydantic import BaseModel
        from cmpnd.identity import get_field_schema

        class Point(BaseModel):
            x: int
            y: int

        schema = get_field_schema(Optional[Point])
        assert schema is not None
        assert schema["type"] == "Point"
        assert schema["fields"] == {"x": "int", "y": "int"}

    def test_pydantic_with_list_field(self, pydantic_available):
        """Pydantic model with List field shows correct type."""
        from pydantic import BaseModel
        from cmpnd.identity import get_field_schema

        class Container(BaseModel):
            items: List[str]
            count: int

        schema = get_field_schema(Container)
        assert schema is not None
        assert schema["fields"]["count"] == "int"
        assert "list" in schema["fields"]["items"].lower()

    def test_nested_pydantic_model(self, pydantic_available):
        """Nested Pydantic model shows type name."""
        from pydantic import BaseModel
        from cmpnd.identity import get_field_schema

        class Inner(BaseModel):
            value: str

        class Outer(BaseModel):
            name: str
            inner: Inner

        schema = get_field_schema(Outer)
        assert schema is not None
        assert schema["fields"]["name"] == "str"
        assert schema["fields"]["inner"] == "Inner"


class TestSignedInt64Conversion:
    """Tests for unsigned to signed int64 conversion."""

    def test_small_value_unchanged(self):
        """Values within signed range are unchanged."""
        from cmpnd.identity import _unsigned_to_signed_int64

        assert _unsigned_to_signed_int64(0) == 0
        assert _unsigned_to_signed_int64(1000) == 1000
        assert _unsigned_to_signed_int64(0x7FFFFFFFFFFFFFFF) == 0x7FFFFFFFFFFFFFFF  # max signed

    def test_large_value_converted_to_negative(self):
        """Values above signed max become negative."""
        from cmpnd.identity import _unsigned_to_signed_int64

        # 2^63 should become -2^63
        assert _unsigned_to_signed_int64(0x8000000000000000) == -0x8000000000000000

        # Max unsigned (2^64 - 1) should become -1
        assert _unsigned_to_signed_int64(0xFFFFFFFFFFFFFFFF) == -1

    def test_problematic_hash_value(self):
        """The specific value that caused the error is converted correctly."""
        from cmpnd.identity import _unsigned_to_signed_int64

        # This was the value that caused the Postgres error
        large_hash = 16875885803926548898
        signed = _unsigned_to_signed_int64(large_hash)

        # Should be negative and within signed int64 range
        assert signed < 0
        assert signed >= -0x8000000000000000

    def test_compute_signature_hash_returns_signed(self):
        """compute_signature_hash returns values in signed int64 range."""
        from cmpnd.identity import compute_signature_hash
        from unittest.mock import MagicMock

        # Create a mock signature
        sig = MagicMock()
        sig.input_fields = {"place": MagicMock(annotation=str)}
        sig.output_fields = {"match": MagicMock(annotation=bool)}

        result = compute_signature_hash(sig)

        # Result should be within signed int64 range
        assert -0x8000000000000000 <= result <= 0x7FFFFFFFFFFFFFFF


class TestGetTypeString:
    """Tests for get_type_string() function."""

    def test_simple_types(self):
        """Simple types return their name."""
        from cmpnd.identity import get_type_string

        assert get_type_string(str) == "str"
        assert get_type_string(int) == "int"
        assert get_type_string(float) == "float"
        assert get_type_string(bool) == "bool"

    def test_none_returns_str(self):
        """None annotation defaults to 'str'."""
        from cmpnd.identity import get_type_string

        assert get_type_string(None) == "str"

    def test_list_type(self):
        """List type includes element type."""
        from cmpnd.identity import get_type_string

        result = get_type_string(List[str])
        assert "list" in result.lower()
        assert "str" in result

    def test_dict_type(self):
        """Dict type includes key and value types."""
        from cmpnd.identity import get_type_string

        result = get_type_string(Dict[str, int])
        assert "dict" in result.lower()
        assert "str" in result
        assert "int" in result

    def test_custom_class(self):
        """Custom class returns class name."""
        from cmpnd.identity import get_type_string

        @dataclass
        class MyClass:
            field: str

        assert get_type_string(MyClass) == "MyClass"


class TestHashConsistency:
    """Verify callback hash methods vs identity module equivalents.

    The callback has its own _compute_dataset_hash and _compute_example_hash.
    The refactor plan calls for replacing them with identity.py equivalents.
    These tests document whether they actually produce the same results.
    """

    def setup_method(self):
        from cmpnd.config import configure
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from unittest.mock import patch
        from cmpnd.callback import CmpndCallback
        with patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def test_dataset_hash_matches_for_todict_objects(self):
        """Both hash methods agree for objects with toDict() (the real use case)."""
        from unittest.mock import MagicMock
        from cmpnd.identity import compute_dataset_hash

        callback = self._make_callback()

        ex1 = MagicMock()
        ex1.toDict.return_value = {"question": "Q1", "answer": "A1"}
        ex2 = MagicMock()
        ex2.toDict.return_value = {"question": "Q2", "answer": "A2"}

        callback_hash = callback._compute_dataset_hash([ex1, ex2])
        identity_hash = compute_dataset_hash([ex1, ex2])

        assert callback_hash == identity_hash
        assert len(callback_hash) == 16

    def test_dataset_hash_diverges_for_plain_dicts(self):
        """BUG: Callback._compute_dataset_hash doesn't handle plain dicts properly.

        The identity module has an `isinstance(example, dict)` branch that the
        callback version is missing. For plain dicts, the callback falls through
        to the `else` branch and wraps the entire dict as {"value": str(dict)},
        producing a different hash. This is a bug but doesn't matter in practice
        because DSPy always passes Examples with toDict().

        Document this so the refactor can fix it when deduplicating hash methods.
        """
        from cmpnd.identity import compute_dataset_hash

        callback = self._make_callback()

        dataset = [
            {"question": "What is 2+2?", "answer": "4"},
        ]

        callback_hash = callback._compute_dataset_hash(dataset)
        identity_hash = compute_dataset_hash(dataset)

        # These SHOULD match but DON'T — callback is missing dict handling
        assert callback_hash != identity_hash, (
            "If these now match, the callback was fixed — "
            "update this test to assert equality"
        )

    def test_example_hash_divergence_is_documented(self):
        """Callback._compute_example_hash uses a DIFFERENT algorithm than identity.compute_example_hash.

        The callback version:
          - Serializes via serialize_value (handles Pydantic)
          - Wraps in {"inputs": ...}
          - Uses json.dumps(sort_keys=True)

        The identity version:
          - Iterates sorted keys
          - Uses f"{key}:{value}" format
          - No JSON serialization

        These produce DIFFERENT hashes for the same input. This test documents
        the divergence so the refactor doesn't accidentally swap one for the other.
        """
        from cmpnd.identity import compute_example_hash

        callback = self._make_callback()

        inputs = {"question": "What is 2+2?", "context": "math"}

        callback_hash = callback._compute_example_hash(inputs)
        identity_hash = compute_example_hash(inputs)

        # Document that these are different — DO NOT change to assertEqual
        # without verifying the backend uses the callback version
        assert callback_hash != identity_hash, (
            "If these now match, the algorithms were unified — "
            "update this test and the refactor plan"
        )

        # Both should be valid 16-char hex strings
        assert len(callback_hash) == 16
        assert len(identity_hash) == 16

    def test_example_hash_deterministic(self):
        """Same inputs always produce the same hash."""
        callback = self._make_callback()

        inputs = {"question": "What is DSPy?", "context": "ML framework"}

        hash1 = callback._compute_example_hash(inputs)
        hash2 = callback._compute_example_hash(inputs)

        assert hash1 == hash2

    def test_example_hash_order_independent(self):
        """Field order in the dict doesn't change the hash."""
        callback = self._make_callback()

        hash1 = callback._compute_example_hash({"a": "1", "b": "2"})
        hash2 = callback._compute_example_hash({"b": "2", "a": "1"})

        assert hash1 == hash2
