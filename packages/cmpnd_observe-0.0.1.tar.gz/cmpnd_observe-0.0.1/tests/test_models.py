"""Tests for data models."""

from datetime import datetime, timezone
from uuid import UUID, uuid4

import pytest

from cmpnd.models import SpanBuilder, SpanType, TraceBuilder, TraceStatus


class TestSpanType:
    """Tests for SpanType enum."""

    def test_span_type_values(self):
        """Test all span type values exist."""
        assert SpanType.UNKNOWN.value == "unknown"
        assert SpanType.MODULE.value == "module"
        assert SpanType.PREDICT.value == "predict"
        assert SpanType.CHAIN_OF_THOUGHT.value == "chain_of_thought"
        assert SpanType.REACT.value == "react"
        assert SpanType.RETRIEVE.value == "retrieve"
        assert SpanType.LM_CALL.value == "lm_call"
        assert SpanType.ADAPTER_FORMAT.value == "adapter_format"
        assert SpanType.ADAPTER_PARSE.value == "adapter_parse"
        assert SpanType.TOOL.value == "tool"
        assert SpanType.EVALUATION.value == "evaluation"


class TestTraceStatus:
    """Tests for TraceStatus enum."""

    def test_trace_status_values(self):
        """Test all trace status values exist."""
        assert TraceStatus.UNSET.value == "unset"
        assert TraceStatus.OK.value == "ok"
        assert TraceStatus.ERROR.value == "error"


class TestSpanBuilder:
    """Tests for SpanBuilder."""

    def test_span_builder_creation(self):
        """Test creating a span builder."""
        span_id = uuid4()
        span = SpanBuilder(span_id=span_id, name="test_span")

        assert span.span_id == span_id
        assert span.name == "test_span"
        assert span.span_type == SpanType.UNKNOWN
        assert span.status == TraceStatus.UNSET
        assert span.inputs == {}
        assert span.outputs == {}

    def test_span_builder_with_dspy_fields(self):
        """Test span builder with DSPy-specific fields."""
        span = SpanBuilder(
            span_id=uuid4(),
            name="ChainOfThought.forward",
            span_type=SpanType.CHAIN_OF_THOUGHT,
            signature_name="Question -> Answer",
            signature_instructions="Answer the question",
            signature_input_fields=["question"],
            signature_output_fields=["answer"],
            module_type="ChainOfThought",
            demo_count=3,
        )

        assert span.span_type == SpanType.CHAIN_OF_THOUGHT
        assert span.signature_name == "Question -> Answer"
        assert span.signature_input_fields == ["question"]
        assert span.signature_output_fields == ["answer"]
        assert span.module_type == "ChainOfThought"
        assert span.demo_count == 3

    def test_span_builder_with_lm_fields(self):
        """Test span builder with LM call fields."""
        span = SpanBuilder(
            span_id=uuid4(),
            name="LM.__call__",
            span_type=SpanType.LM_CALL,
            model_name="gpt-4o-mini",
            model_provider="openai",
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            cost=0.001,
        )

        assert span.model_name == "gpt-4o-mini"
        assert span.model_provider == "openai"
        assert span.prompt_tokens == 100
        assert span.completion_tokens == 50
        assert span.total_tokens == 150
        assert span.cost == 0.001

    def test_set_inputs(self):
        """Test setting span inputs."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        span.set_inputs({"question": "What is 2+2?"})

        assert span.inputs == {"question": "What is 2+2?"}

    def test_set_outputs_dict(self):
        """Test setting span outputs with dict."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        span.set_outputs({"answer": "4"})

        assert span.outputs == {"answer": "4"}

    def test_set_outputs_non_dict(self):
        """Test setting span outputs with non-dict wraps in result key."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        span.set_outputs("simple result")

        assert span.outputs == {"result": "simple result"}

    def test_set_attribute(self):
        """Test setting span attribute."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        span.set_attribute("custom_key", "custom_value")
        span.set_attribute("numeric", 42)

        assert span.attributes["custom_key"] == "custom_value"
        assert span.attributes["numeric"] == "42"

    def test_set_error(self):
        """Test setting span error."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        span.set_error(ValueError("something went wrong"))

        assert span.status == TraceStatus.ERROR
        assert span.error_message == "something went wrong"
        assert span.error_type == "ValueError"

    def test_add_event(self):
        """Test adding span event."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        span.add_event("cache_hit", {"key": "abc123"})

        assert len(span.events) == 1
        assert span.events[0]["name"] == "cache_hit"
        assert span.events[0]["attributes"] == {"key": "abc123"}
        assert "timestamp" in span.events[0]

    def test_to_api_dict(self):
        """Test converting span to API dictionary."""
        span_id = uuid4()
        trace_id = uuid4()
        parent_id = uuid4()
        start_time = datetime.now(timezone.utc)
        end_time = datetime.now(timezone.utc)

        span = SpanBuilder(
            span_id=span_id,
            trace_id=trace_id,
            parent_span_id=parent_id,
            name="test_span",
            span_type=SpanType.PREDICT,
            start_time=start_time,
            end_time=end_time,
            status=TraceStatus.OK,
            model_name="gpt-4",
            prompt_tokens=100,
        )
        span.set_inputs({"q": "test"})
        span.set_outputs({"a": "result"})

        api_dict = span.to_api_dict()

        assert api_dict["span_id"] == str(span_id)
        assert api_dict["trace_id"] == str(trace_id)
        assert api_dict["parent_span_id"] == str(parent_id)
        assert api_dict["name"] == "test_span"
        assert api_dict["span_type"] == "predict"
        assert api_dict["status"] == "ok"
        assert api_dict["model_name"] == "gpt-4"
        assert api_dict["prompt_tokens"] == 100
        assert api_dict["inputs"] == {"q": "test"}
        assert api_dict["outputs"] == {"a": "result"}


class TestSpanReplHistory:
    """Tests for SpanBuilder repl_history field."""

    def test_span_repl_history_default_empty(self):
        span = SpanBuilder(span_id=uuid4(), name="predict", span_type=SpanType.PREDICT)
        assert span.repl_history == []

    def test_span_repl_history_serialized_in_attributes(self):
        span = SpanBuilder(span_id=uuid4(), name="react", span_type=SpanType.REACT)
        span.repl_history = [
            {"turn": 0, "thought": "I should search", "tool_name": "search", "tool_args": {"q": "test"}, "observation": "found it"},
            {"turn": 1, "thought": "Now I know", "tool_name": "finish", "tool_args": {}, "observation": "done"},
        ]
        d = span.to_api_dict()
        # repl_history should appear in attributes
        import json
        attrs = d["attributes"]
        assert "repl_history" in attrs
        history = json.loads(attrs["repl_history"])
        assert len(history) == 2
        assert history[0]["thought"] == "I should search"

    def test_span_repl_history_not_in_attributes_when_empty(self):
        span = SpanBuilder(span_id=uuid4(), name="predict", span_type=SpanType.PREDICT)
        d = span.to_api_dict()
        attrs = d["attributes"]
        assert "repl_history" not in attrs


class TestRlmSubcallThinning:
    """Tests for RLM subcall thinning behavior."""

    def test_rlm_subcall_not_thinned(self):
        """RLM subcall LM_CALLs should NOT be thinned — their prompt is valuable."""
        span = SpanBuilder(span_id=uuid4(), name="lm_call", span_type=SpanType.LM_CALL)
        span.attributes["rlm.subcall"] = "true"
        span.inputs = {"messages": [{"role": "user", "content": "analyze this data"}]}
        span.outputs = {"response": "the answer"}

        span.thin()

        assert span.inputs == {"messages": [{"role": "user", "content": "analyze this data"}]}
        assert span.outputs == {"response": "the answer"}
        assert "thinned" not in span.attributes

    def test_regular_lm_call_still_thinned(self):
        """Non-subcall LM_CALLs should still have inputs stripped."""
        span = SpanBuilder(span_id=uuid4(), name="lm_call", span_type=SpanType.LM_CALL)
        span.inputs = {"messages": [{"role": "user", "content": "test"}]}
        span.outputs = {"response": "the answer"}

        span.thin()

        assert span.inputs is None
        assert span.outputs == {"response": "the answer"}
        assert span.attributes["thinned"] == "true"


class TestTraceBuilderStreaming:
    """Tests for TraceBuilder streaming and batch_spans fields."""

    def test_trace_builder_streaming_default(self):
        """TraceBuilder.streaming defaults to False."""
        trace = TraceBuilder(trace_id=uuid4())
        assert trace.streaming is False

    def test_trace_builder_batch_spans_serialized(self):
        """TraceBuilder.to_api_dict includes _batch_spans when present."""
        trace = TraceBuilder(trace_id=uuid4(), start_time=datetime.now(timezone.utc))
        span = SpanBuilder(
            span_id=uuid4(),
            trace_id=trace.trace_id,
            name="test",
            span_type=SpanType.PREDICT,
            start_time=datetime.now(timezone.utc),
        )
        trace._batch_spans = [span]
        d = trace.to_api_dict()
        assert "spans" in d
        assert len(d["spans"]) == 1
        assert d["spans"][0]["span_id"] == str(span.span_id)


class TestTraceBuilderRunFields:
    """Test that TraceBuilder includes run linkage fields."""

    def test_optimization_run_id_in_api_dict(self):
        opt_id = uuid4()
        trace = TraceBuilder(
            trace_id=uuid4(),
            start_time=datetime.now(timezone.utc),
            optimization_run_id=opt_id,
        )
        api = trace.to_api_dict()
        assert api["optimization_run_id"] == str(opt_id)

    def test_eval_run_id_in_api_dict(self):
        eval_id = uuid4()
        trace = TraceBuilder(
            trace_id=uuid4(),
            start_time=datetime.now(timezone.utc),
            eval_run_id=eval_id,
        )
        api = trace.to_api_dict()
        assert api["eval_run_id"] == str(eval_id)

    def test_null_run_ids_in_api_dict(self):
        trace = TraceBuilder(
            trace_id=uuid4(),
            start_time=datetime.now(timezone.utc),
        )
        api = trace.to_api_dict()
        assert api["optimization_run_id"] is None
        assert api["eval_run_id"] is None

    def test_both_run_ids_set(self):
        opt_id = uuid4()
        eval_id = uuid4()
        trace = TraceBuilder(
            trace_id=uuid4(),
            start_time=datetime.now(timezone.utc),
            optimization_run_id=opt_id,
            eval_run_id=eval_id,
        )
        api = trace.to_api_dict()
        assert api["optimization_run_id"] == str(opt_id)
        assert api["eval_run_id"] == str(eval_id)


class TestTraceBuilder:
    """Tests for TraceBuilder."""

    def test_trace_builder_creation(self):
        """Test creating a trace builder."""
        trace_id = uuid4()
        trace = TraceBuilder(trace_id=trace_id)

        assert trace.trace_id == trace_id
        assert trace.status == TraceStatus.UNSET
        assert trace.tags == {}
        assert trace.metadata == {}

    def test_trace_builder_with_fields(self):
        """Test trace builder with all fields."""
        trace = TraceBuilder(
            trace_id=uuid4(),
            start_time=datetime.now(timezone.utc),
            program_name="QAPipeline",
            program_version="1.0.0",
            request_preview='{"question": "test"}',
            tags={"env": "prod"},
            metadata={"user_id": "123"},
        )

        assert trace.program_name == "QAPipeline"
        assert trace.program_version == "1.0.0"
        assert trace.tags == {"env": "prod"}
        assert trace.metadata == {"user_id": "123"}

    def test_to_api_dict(self):
        """Test converting trace to API dictionary."""
        trace_id = uuid4()
        start_time = datetime.now(timezone.utc)

        trace = TraceBuilder(
            trace_id=trace_id,
            start_time=start_time,
            status=TraceStatus.OK,
            program_name="TestProgram",
            tags={"test": "true"},
        )

        api_dict = trace.to_api_dict()

        assert api_dict["trace_id"] == str(trace_id)
        assert api_dict["status"] == "ok"
        assert api_dict["program_name"] == "TestProgram"
        assert api_dict["tags"] == {"test": "true"}
        assert api_dict["spans"] == []  # Empty by default

    def test_to_start_dict(self):
        """to_start_dict includes identity/signature fields only."""
        trace = TraceBuilder(trace_id=uuid4())
        trace.start_time = datetime(2026, 3, 23, tzinfo=timezone.utc)
        trace.program_name = "TestProgram"
        trace.program_version = "1.0"
        trace.signature_hash = 12345
        trace.signature_name = "BasicQA"
        trace.signature_summary = "question -> answer"
        trace.signature_input_fields = ["question"]
        trace.signature_output_fields = ["answer"]

        d = trace.to_start_dict()

        assert d["start_time"] == "2026-03-23T00:00:00+00:00"
        assert d["program_name"] == "TestProgram"
        assert d["program_version"] == "1.0"
        assert d["signature_hash"] == 12345
        assert d["signature_name"] == "BasicQA"
        assert d["signature_summary"] == "question -> answer"
        assert d["signature_input_fields"] == ["question"]
        assert d["signature_output_fields"] == ["answer"]
        # Should NOT contain finalization or span fields
        assert "end_time" not in d
        assert "spans" not in d
        assert "total_tokens" not in d
        assert "status" not in d

    def test_to_finalize_dict(self):
        """to_finalize_dict includes timing, metrics, and previews only."""
        trace = TraceBuilder(trace_id=uuid4())
        trace.start_time = datetime(2026, 3, 23, tzinfo=timezone.utc)
        trace.end_time = datetime(2026, 3, 23, 0, 0, 5, tzinfo=timezone.utc)
        trace.status = TraceStatus.OK
        trace.total_tokens = 150
        trace.prompt_tokens = 100
        trace.completion_tokens = 50
        trace.total_cost = 0.002
        trace.span_count = 5
        trace.request_preview = "What is 2+2?"
        trace.response_preview = "4"
        trace.adapter_type = "chat"
        trace.tags = {"env": "test"}

        d = trace.to_finalize_dict()

        assert d["status"] == "ok"
        assert d["total_tokens"] == 150
        assert d["prompt_tokens"] == 100
        assert d["completion_tokens"] == 50
        assert d["total_cost"] == 0.002
        assert d["request_preview"] == "What is 2+2?"
        assert d["response_preview"] == "4"
        assert d["span_count"] == 5
        assert d["adapter_type"] == "chat"
        assert d["tags"] == {"env": "test"}
        assert d["start_time"] == "2026-03-23T00:00:00+00:00"
        assert d["end_time"] == "2026-03-23T00:00:05+00:00"
        # Should NOT contain identity/signature or span fields
        assert "signature_hash" not in d
        assert "spans" not in d
