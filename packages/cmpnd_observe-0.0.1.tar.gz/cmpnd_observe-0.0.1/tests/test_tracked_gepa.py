"""Tests for TrackedGEPA optimizer instrumentation."""

from unittest import mock
from uuid import UUID

import pytest

from cmpnd.config import configure
from cmpnd.context import clear_context


# Skip all tests if dspy is not installed
pytest.importorskip("dspy")


class MockLM:
    """Mock language model for testing."""

    def __init__(self, model_name: str = "openai/gpt-4o"):
        self.model = model_name


class MockSignature:
    """Mock DSPy signature for testing."""

    def __init__(self, inputs: list[str], outputs: list[str], instructions: str = ""):
        self.input_fields = {name: mock.MagicMock() for name in inputs}
        self.output_fields = {name: mock.MagicMock() for name in outputs}
        self.instructions = instructions

        # Add field types
        for name, field in self.input_fields.items():
            field.annotation = str
        for name, field in self.output_fields.items():
            field.annotation = str


class MockPredictor:
    """Mock DSPy Predict module for testing."""

    def __init__(self, signature: MockSignature):
        self.signature = signature


class MockModule:
    """Mock DSPy Module for testing."""

    def __init__(self, name: str = "TestModule", predictors: list[tuple[str, MockPredictor]] | None = None):
        self._name = name
        self._predictors = predictors or []

        # Add root signature for program_signature_hash
        if predictors:
            self.predict = predictors[0][1]
            self.signature = predictors[0][1].signature

    def named_predictors(self):
        return iter(self._predictors)

    def dump_state(self, json_mode: bool = False) -> dict:
        return {"module": self._name, "parameters": {}}

    @property
    def __class__(self):
        """Return a mock class with the correct name."""
        class_mock = type(self._name, (), {})
        return class_mock


class MockEvalResult:
    """Mock evaluation result from DspyAdapter.evaluate()."""

    def __init__(self, scores: list[float], trajectories=None):
        self.scores = scores
        self.trajectories = trajectories


class MockGEPAResult:
    """Mock result from GEPA.compile()."""

    def __init__(self, candidates: list, scores: list[float], best_idx: int = 0):
        self.candidates = candidates
        self.val_aggregate_scores = scores
        self.parents = [None] + [0] * (len(candidates) - 1)  # First candidate has no parent
        self.discovery_eval_counts = list(range(len(candidates)))
        self.per_val_instance_best_candidates = [{0}]  # First candidate is Pareto member
        self.best_idx = best_idx
        self.total_metric_calls = sum(range(len(candidates) * 10))
        self.detailed_results = self


class TestTrackedGEPACreation:
    """Tests for TrackedGEPA initialization."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_tracked_gepa_creation(self):
        """Test TrackedGEPA can be created with auto preset."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        # Mock the GEPA import
        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light", seed=42)

        assert gepa._gepa_kwargs["auto"] == "light"
        assert gepa._gepa_kwargs["seed"] == 42
        assert gepa._tracker is None  # Not created until compile()

    def test_tracked_gepa_with_reflection_lm(self):
        """Test TrackedGEPA captures reflection LM model name."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        reflection_lm = MockLM("anthropic/claude-3-5-sonnet")
        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light", reflection_lm=reflection_lm)

        assert gepa._get_reflection_model_name() == "anthropic/claude-3-5-sonnet"

    def test_tracked_gepa_repr(self):
        """Test TrackedGEPA string representation."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="medium")

        assert "TrackedGEPA" in repr(gepa)
        assert "medium" in repr(gepa)


class TestTrackedGEPAConfig:
    """Tests for TrackedGEPA configuration building."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_build_config_with_auto_preset(self):
        """Test config building captures auto preset."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="heavy", seed=123)

        sig = MockSignature(["question"], ["answer"])
        pred = MockPredictor(sig)
        student = MockModule("QA", [("predict", pred)])

        config = gepa._build_config(student)

        assert config["auto"] == "heavy"
        assert config["seed"] == 123
        assert "components" in config
        assert len(config["components"]) == 1
        assert config["components"][0]["name"] == "predict"

    def test_build_config_extracts_components(self):
        """Test config building extracts component signatures."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig1 = MockSignature(["context", "question"], ["answer"])
        sig2 = MockSignature(["answer"], ["verified"])
        pred1 = MockPredictor(sig1)
        pred2 = MockPredictor(sig2)
        student = MockModule("Pipeline", [("retriever", pred1), ("verifier", pred2)])

        config = gepa._build_config(student)

        assert len(config["components"]) == 2
        assert config["components"][0]["name"] == "retriever"
        assert config["components"][0]["inputs"] == ["context", "question"]
        assert config["components"][0]["outputs"] == ["answer"]
        assert config["components"][1]["name"] == "verifier"


class TestTrackedGEPAMetricCallsBudget:
    """Tests for max metric calls computation."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_explicit_max_metric_calls(self):
        """Test explicit max_metric_calls is used."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(max_metric_calls=500)

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])

        budget = gepa._compute_max_metric_calls(student, [1, 2, 3], None)

        assert budget == 500

    def test_max_full_evals_budget(self):
        """Test budget from max_full_evals."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock_gepa_class.return_value
        # Set max_metric_calls to None so it falls through to max_full_evals logic
        mock_gepa_instance.max_metric_calls = None
        mock_gepa_instance.max_full_evals = 10

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(max_full_evals=10)

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])

        trainset = list(range(50))
        valset = list(range(100))

        budget = gepa._compute_max_metric_calls(student, trainset, valset)

        # Should be max_full_evals * (valset_size + trainset_size)
        assert budget == 10 * (100 + 50)

    def test_auto_preset_budget_computation(self):
        """Test budget computation for auto preset."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock_gepa_class.return_value
        # Set these to None so it falls through to auto preset budget computation
        mock_gepa_instance.max_metric_calls = None
        mock_gepa_instance.max_full_evals = None
        mock_gepa_instance.auto = "light"

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])

        budget = gepa._compute_max_metric_calls(student, list(range(50)), list(range(100)))

        # Should compute a reasonable budget based on GEPA's formula
        assert budget > 0


class TestTrackedGEPACallbackInjection:
    """Tests for CmpndGEPACallback injection into gepa_kwargs."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.context import set_current_optimization_run_id
        set_current_optimization_run_id(None)
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_compile_injects_callback_into_gepa_kwargs(self):
        """Test compile() injects a CmpndGEPACallback into gepa_kwargs['callbacks']."""
        from cmpnd.optimizers.gepa import TrackedGEPA
        from cmpnd.optimizers.gepa_callback import CmpndGEPACallback

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance

        # Track what callbacks were set when compile was called
        injected_callbacks = []

        def capture_compile(*args, **kwargs):
            cbs = mock_gepa_instance.gepa_kwargs.get("callbacks", [])
            injected_callbacks.extend(cbs)
            # Return a mock result
            sig = MockSignature(["q"], ["a"])
            pred = MockPredictor(sig)
            result = MockModule("Result", [("p", pred)])
            result.detailed_results = MockGEPAResult(
                candidates=[result], scores=[0.9], best_idx=0
            )
            return result

        mock_gepa_instance.compile.side_effect = capture_compile
        mock_gepa_instance.gepa_kwargs = {}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])
        trainset = [mock.MagicMock() for _ in range(5)]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM()
                gepa.compile(student, trainset=trainset)

        # Verify a CmpndGEPACallback was injected
        assert len(injected_callbacks) == 1
        assert isinstance(injected_callbacks[0], CmpndGEPACallback)

    def test_compile_preserves_existing_callbacks(self):
        """Test compile() preserves existing callbacks in gepa_kwargs."""
        from cmpnd.optimizers.gepa import TrackedGEPA
        from cmpnd.optimizers.gepa_callback import CmpndGEPACallback

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance

        existing_callback = mock.MagicMock()
        injected_callbacks = []

        def capture_compile(*args, **kwargs):
            cbs = mock_gepa_instance.gepa_kwargs.get("callbacks", [])
            injected_callbacks.extend(cbs)
            sig = MockSignature(["q"], ["a"])
            pred = MockPredictor(sig)
            result = MockModule("Result", [("p", pred)])
            result.detailed_results = MockGEPAResult(
                candidates=[result], scores=[0.9], best_idx=0
            )
            return result

        mock_gepa_instance.compile.side_effect = capture_compile
        mock_gepa_instance.gepa_kwargs = {"callbacks": [existing_callback]}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])
        trainset = [mock.MagicMock() for _ in range(5)]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM()
                gepa.compile(student, trainset=trainset)

        # Should have both the existing callback and the CmpndGEPACallback
        assert len(injected_callbacks) == 2
        assert injected_callbacks[0] is existing_callback
        assert isinstance(injected_callbacks[1], CmpndGEPACallback)

    def test_compile_removes_callback_after_completion(self):
        """Test compile() removes CmpndGEPACallback from gepa_kwargs after completion."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance

        def mock_compile(*args, **kwargs):
            sig = MockSignature(["q"], ["a"])
            pred = MockPredictor(sig)
            result = MockModule("Result", [("p", pred)])
            result.detailed_results = MockGEPAResult(
                candidates=[result], scores=[0.9], best_idx=0
            )
            return result

        mock_gepa_instance.compile.side_effect = mock_compile
        mock_gepa_instance.gepa_kwargs = {}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])
        trainset = [mock.MagicMock() for _ in range(5)]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM()
                gepa.compile(student, trainset=trainset)

        # After compile, callbacks should be empty (our callback removed)
        assert mock_gepa_instance.gepa_kwargs["callbacks"] == []

    def test_compile_removes_callback_on_error(self):
        """Test compile() removes CmpndGEPACallback from gepa_kwargs even on error."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance
        mock_gepa_instance.compile.side_effect = ValueError("Test error")
        mock_gepa_instance.gepa_kwargs = {}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])
        trainset = [mock.MagicMock() for _ in range(5)]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM()
                with pytest.raises(ValueError):
                    gepa.compile(student, trainset=trainset)

        # After error, callbacks should be empty (our callback removed)
        assert mock_gepa_instance.gepa_kwargs["callbacks"] == []


class TestTrackedGEPACompile:
    """Tests for TrackedGEPA.compile() integration."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.context import set_current_optimization_run_id
        set_current_optimization_run_id(None)
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_compile_creates_tracker(self):
        """Test compile() creates an OptimizationTracker."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        # Create mock GEPA that returns a result
        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance

        sig = MockSignature(["question"], ["answer"])
        pred = MockPredictor(sig)
        result_module = MockModule("OptimizedQA", [("predict", pred)])
        result_module.detailed_results = MockGEPAResult(
            candidates=[result_module],
            scores=[0.85],
            best_idx=0
        )
        mock_gepa_instance.compile.return_value = result_module
        mock_gepa_instance.gepa_kwargs = {}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        # Create student module
        student = MockModule("QA", [("predict", pred)])
        trainset = [mock.MagicMock() for _ in range(10)]

        # Mock exporter
        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM("openai/gpt-4o")
                result = gepa.compile(student, trainset=trainset)

        # Verify tracker was created
        assert gepa._tracker is not None
        assert gepa._tracker.optimizer_type == "GEPA"
        assert gepa._tracker.program_name == "QA"  # Name passed to MockModule

    def test_compile_tags_result_with_optimization_id(self):
        """Test compile() tags result module with optimization run ID."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        result_module = MockModule("Result", [("p", pred)])
        result_module.detailed_results = MockGEPAResult(
            candidates=[result_module],
            scores=[0.9],
            best_idx=0
        )
        mock_gepa_instance.compile.return_value = result_module
        mock_gepa_instance.gepa_kwargs = {}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        student = MockModule("Test", [("p", pred)])
        trainset = [mock.MagicMock() for _ in range(5)]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM()
                result = gepa.compile(student, trainset=trainset)

        # Result should have optimization_run_id tag
        assert hasattr(result, "_optimization_run_id")
        assert result._optimization_run_id == str(gepa._tracker.optimization_run_id)

    def test_compile_handles_error(self):
        """Test compile() properly handles and tracks errors."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_class.return_value = mock_gepa_instance
        mock_gepa_instance.compile.side_effect = ValueError("Test error")
        mock_gepa_instance.gepa_kwargs = {}

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["q"], ["a"])
        pred = MockPredictor(sig)
        student = MockModule("Test", [("p", pred)])
        trainset = [mock.MagicMock() for _ in range(5)]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=mock.MagicMock()):
            with mock.patch("dspy.settings") as mock_settings:
                mock_settings.lm = MockLM()
                with pytest.raises(ValueError, match="Test error"):
                    gepa.compile(student, trainset=trainset)

        # Tracker should have recorded the error
        assert gepa._tracker is not None
        assert gepa._tracker.status == "failed"
        assert "Test error" in gepa._tracker.error_message


class TestTrackedGEPAHashes:
    """Tests for hash computation in TrackedGEPA."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_program_signature_hash_computation(self):
        """Test program signature hash is computed from student signature."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        sig = MockSignature(["question", "context"], ["answer"])
        pred = MockPredictor(sig)
        student = MockModule("QA", [("predict", pred)])

        # Compute hash
        hash_value = gepa._compute_program_signature_hash(student)

        # Should return a non-zero int (from xxhash)
        assert isinstance(hash_value, int)
        assert hash_value != 0

    def test_program_signature_hash_returns_zero_without_signature(self):
        """Test hash returns 0 when student has no signature."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        # Module without signature
        student = mock.MagicMock()
        del student.signature
        del student.predict
        student.named_predictors.return_value = iter([])

        hash_value = gepa._compute_program_signature_hash(student)

        assert hash_value == 0


class TestTrackedGEPAAttributeProxy:
    """Tests for attribute proxying to underlying GEPA."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_attribute_proxy(self):
        """Test attributes are proxied to underlying GEPA."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_instance.some_attribute = "test_value"
        mock_gepa_class.return_value = mock_gepa_instance

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        # Access proxied attribute
        assert gepa.some_attribute == "test_value"

    def test_private_attribute_not_proxied(self):
        """Test private attributes are not proxied."""
        from cmpnd.optimizers.gepa import TrackedGEPA

        mock_gepa_class = mock.MagicMock()
        mock_gepa_instance = mock.MagicMock()
        mock_gepa_instance._private = "should not access"
        mock_gepa_class.return_value = mock_gepa_instance

        with mock.patch("cmpnd.optimizers.gepa._get_gepa_classes") as mock_get:
            mock_get.return_value = mock_gepa_class
            gepa = TrackedGEPA(auto="light")

        # Private attributes should raise AttributeError
        with pytest.raises(AttributeError):
            _ = gepa._nonexistent_private


# ---------------------------------------------------------------------------
# Tracker eval trace ID storage
# ---------------------------------------------------------------------------

class TestTrackerEvalTraceIds:
    """Test that OptimizationTracker stores eval_trace_ids on iterations."""

    def test_capture_evaluation_with_trace_ids(self):
        from cmpnd.optimizers.tracker import OptimizationTracker
        from uuid import uuid4

        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
            config={},
        )

        trace_ids = [uuid4(), uuid4(), uuid4()]

        tracker.capture_evaluation(
            iteration=0,
            candidate_idx=0,
            batch_size=3,
            scores=[0.8, 0.7, 0.9],
            has_trajectories=False,
            eval_trace_ids=trace_ids,
        )

        assert len(tracker.iterations) == 1
        assert tracker.iterations[0].eval_trace_ids == trace_ids

    def test_capture_evaluation_without_trace_ids(self):
        from cmpnd.optimizers.tracker import OptimizationTracker
        from uuid import uuid4

        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
            config={},
        )

        tracker.capture_evaluation(
            iteration=0,
            candidate_idx=0,
            batch_size=3,
            scores=[0.8, 0.7, 0.9],
            has_trajectories=False,
        )

        assert len(tracker.iterations) == 1
        assert tracker.iterations[0].eval_trace_ids == []

    def test_eval_trace_ids_in_api_dict(self):
        from cmpnd.optimizers.tracker import IterationData
        from uuid import uuid4

        trace_ids = [uuid4(), uuid4()]
        iteration = IterationData(
            iteration=0,
            candidate_idx=0,
            eval_trace_ids=trace_ids,
        )

        api = iteration.to_api_dict()
        assert len(api["eval_trace_ids"]) == 2
        assert api["eval_trace_ids"][0] == str(trace_ids[0])
        assert api["eval_trace_ids"][1] == str(trace_ids[1])
