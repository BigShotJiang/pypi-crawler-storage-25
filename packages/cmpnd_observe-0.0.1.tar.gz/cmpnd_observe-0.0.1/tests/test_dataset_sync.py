"""Tests for dataset_sync module — pre-flight check and payload builder."""

from unittest import mock

import pytest

from cmpnd.config import configure, _config


class TestCheckDatasetExists:
    """Tests for check_dataset_exists()."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        _config.set(None)

    def test_returns_true_when_exists(self):
        """API returns 200 with exists=true."""
        from cmpnd.dataset_sync import check_dataset_exists

        mock_response = mock.MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"exists": True}

        with mock.patch("cmpnd.dataset_sync.httpx.Client") as MockClient:
            MockClient.return_value.__enter__ = mock.MagicMock(return_value=MockClient.return_value)
            MockClient.return_value.__exit__ = mock.MagicMock(return_value=False)
            MockClient.return_value.get.return_value = mock_response
            assert check_dataset_exists("abc123") is True

    def test_returns_false_when_not_exists(self):
        """API returns 200 with exists=false."""
        from cmpnd.dataset_sync import check_dataset_exists

        mock_response = mock.MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"exists": False}

        with mock.patch("cmpnd.dataset_sync.httpx.Client") as MockClient:
            MockClient.return_value.__enter__ = mock.MagicMock(return_value=MockClient.return_value)
            MockClient.return_value.__exit__ = mock.MagicMock(return_value=False)
            MockClient.return_value.get.return_value = mock_response
            assert check_dataset_exists("abc123") is False

    def test_returns_false_on_404(self):
        """API returns 404 — treat as not exists."""
        from cmpnd.dataset_sync import check_dataset_exists

        mock_response = mock.MagicMock()
        mock_response.status_code = 404

        with mock.patch("cmpnd.dataset_sync.httpx.Client") as MockClient:
            MockClient.return_value.__enter__ = mock.MagicMock(return_value=MockClient.return_value)
            MockClient.return_value.__exit__ = mock.MagicMock(return_value=False)
            MockClient.return_value.get.return_value = mock_response
            assert check_dataset_exists("abc123") is False

    def test_returns_false_on_connection_error(self):
        """Connection error — safe fallback to False."""
        from cmpnd.dataset_sync import check_dataset_exists
        import httpx

        with mock.patch("cmpnd.dataset_sync.httpx.Client") as MockClient:
            MockClient.return_value.__enter__ = mock.MagicMock(return_value=MockClient.return_value)
            MockClient.return_value.__exit__ = mock.MagicMock(return_value=False)
            MockClient.return_value.get.side_effect = httpx.ConnectError("refused")
            assert check_dataset_exists("abc123") is False

    def test_returns_false_on_timeout(self):
        """Timeout — safe fallback to False."""
        from cmpnd.dataset_sync import check_dataset_exists
        import httpx

        with mock.patch("cmpnd.dataset_sync.httpx.Client") as MockClient:
            MockClient.return_value.__enter__ = mock.MagicMock(return_value=MockClient.return_value)
            MockClient.return_value.__exit__ = mock.MagicMock(return_value=False)
            MockClient.return_value.get.side_effect = httpx.TimeoutException("timeout")
            assert check_dataset_exists("abc123") is False


class TestBuildDatasetPayload:
    """Tests for build_dataset_payload()."""

    def _make_example(self, data: dict, input_keys: set):
        """Create a mock DSPy Example."""
        ex = mock.MagicMock()
        ex.toDict.return_value = data.copy()
        ex._input_keys = input_keys
        return ex

    def test_full_payload_with_examples(self):
        """include_examples=True produces examples array with hashes."""
        from cmpnd.dataset_sync import build_dataset_payload

        devset = [
            self._make_example(
                {"question": "Q1", "answer": "A1"},
                input_keys={"question"},
            ),
            self._make_example(
                {"question": "Q2", "answer": "A2"},
                input_keys={"question"},
            ),
        ]

        result = build_dataset_payload(
            devset=devset,
            dataset_hash="abcdef1234567890",
            input_fields={"question"},
            include_examples=True,
        )

        assert result["dataset_hash"] == "abcdef1234567890"
        assert result["dataset_size"] == 2
        assert result["input_fields"] == ["question"]
        assert result["output_fields"] == ["answer"]
        assert len(result["examples"]) == 2

        # Each example has inputs, expected_outputs, example_hash
        ex0 = result["examples"][0]
        assert ex0["inputs"] == {"question": "Q1"}
        assert ex0["expected_outputs"] == {"answer": "A1"}
        assert isinstance(ex0["example_hash"], str)
        assert len(ex0["example_hash"]) == 16  # SHA256[:16]

    def test_hash_only_payload(self):
        """include_examples=False produces only hash and size."""
        from cmpnd.dataset_sync import build_dataset_payload

        devset = [
            self._make_example(
                {"question": "Q1", "answer": "A1"},
                input_keys={"question"},
            ),
        ]

        result = build_dataset_payload(
            devset=devset,
            dataset_hash="abcdef1234567890",
            input_fields={"question"},
            include_examples=False,
        )

        assert result["dataset_hash"] == "abcdef1234567890"
        assert result["dataset_size"] == 1
        assert "examples" not in result
        assert "input_fields" not in result
        assert "output_fields" not in result

    def test_multiple_input_and_output_fields_sorted(self):
        """Fields are sorted alphabetically in the payload."""
        from cmpnd.dataset_sync import build_dataset_payload

        devset = [
            self._make_example(
                {"context": "C", "question": "Q", "answer": "A", "reasoning": "R"},
                input_keys={"question", "context"},
            ),
        ]

        result = build_dataset_payload(
            devset=devset,
            dataset_hash="hash123",
            input_fields={"question", "context"},
            include_examples=True,
        )

        assert result["input_fields"] == ["context", "question"]
        assert result["output_fields"] == ["answer", "reasoning"]

    def test_internal_fields_filtered(self):
        """Fields starting with _ (like _input_keys) are excluded from examples."""
        from cmpnd.dataset_sync import build_dataset_payload

        ex = mock.MagicMock()
        # toDict might include _input_keys in some DSPy versions
        ex.toDict.return_value = {"question": "Q1", "answer": "A1", "_input_keys": {"question"}}
        ex._input_keys = {"question"}

        result = build_dataset_payload(
            devset=[ex],
            dataset_hash="hash123",
            input_fields={"question"},
            include_examples=True,
        )

        ex0 = result["examples"][0]
        assert "_input_keys" not in ex0["inputs"]
        assert "_input_keys" not in ex0["expected_outputs"]

    def test_empty_devset(self):
        """Empty devset produces valid payload."""
        from cmpnd.dataset_sync import build_dataset_payload

        result = build_dataset_payload(
            devset=[],
            dataset_hash="hash123",
            input_fields={"question"},
            include_examples=True,
        )

        assert result["dataset_hash"] == "hash123"
        assert result["dataset_size"] == 0
        assert result["examples"] == []


# ---------------------------------------------------------------------------
# Task 8: EvalRunBuilder dataset wiring tests
# ---------------------------------------------------------------------------

class TestEvalRunBuilderDatasetPayload:
    """Test that EvalRunBuilder.to_api_dict() includes dataset block."""

    def _make_example(self, data: dict, input_keys: set):
        ex = mock.MagicMock()
        ex.toDict.return_value = data.copy()
        ex._input_keys = input_keys
        return ex

    def test_standalone_eval_includes_dataset_key(self):
        """Standalone eval (no optimization_run_id) includes 'dataset' in export."""
        from uuid import uuid4
        from cmpnd.models import EvalRunBuilder

        devset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
        ]

        eval_run = EvalRunBuilder(eval_run_id=uuid4())
        eval_run.dataset_hash = "abcdef1234567890"
        eval_run._devset = devset
        eval_run._input_fields = {"question"}
        eval_run._dataset_exists = False  # Will include examples

        d = eval_run.to_api_dict()

        assert "dataset" in d
        assert d["dataset"]["dataset_hash"] == "abcdef1234567890"
        assert d["dataset"]["dataset_size"] == 1
        assert len(d["dataset"]["examples"]) == 1

    def test_optimization_linked_eval_excludes_dataset_key(self):
        """Eval linked to an optimization run does NOT include 'dataset'."""
        from uuid import uuid4
        from cmpnd.models import EvalRunBuilder

        devset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
        ]

        eval_run = EvalRunBuilder(eval_run_id=uuid4())
        eval_run.optimization_run_id = uuid4()  # Linked to optimization
        eval_run.dataset_hash = "abcdef1234567890"
        eval_run._devset = devset
        eval_run._input_fields = {"question"}
        eval_run._dataset_exists = False

        d = eval_run.to_api_dict()

        assert "dataset" not in d

    def test_dataset_exists_true_no_examples(self):
        """When _dataset_exists=True, dataset block has no 'examples' key."""
        from uuid import uuid4
        from cmpnd.models import EvalRunBuilder

        devset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
        ]

        eval_run = EvalRunBuilder(eval_run_id=uuid4())
        eval_run.dataset_hash = "abcdef1234567890"
        eval_run._devset = devset
        eval_run._input_fields = {"question"}
        eval_run._dataset_exists = True  # Already exists, skip examples

        d = eval_run.to_api_dict()

        assert "dataset" in d
        assert d["dataset"]["dataset_hash"] == "abcdef1234567890"
        assert d["dataset"]["dataset_size"] == 1
        assert "examples" not in d["dataset"]

    def test_dataset_exists_false_has_examples(self):
        """When _dataset_exists=False, dataset block has 'examples' array."""
        from uuid import uuid4
        from cmpnd.models import EvalRunBuilder

        devset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
        ]

        eval_run = EvalRunBuilder(eval_run_id=uuid4())
        eval_run.dataset_hash = "abcdef1234567890"
        eval_run._devset = devset
        eval_run._input_fields = {"question"}
        eval_run._dataset_exists = False

        d = eval_run.to_api_dict()

        assert "dataset" in d
        assert "examples" in d["dataset"]
        assert len(d["dataset"]["examples"]) == 1

    def test_no_devset_no_dataset_key(self):
        """When _devset is empty, no 'dataset' key is added."""
        from uuid import uuid4
        from cmpnd.models import EvalRunBuilder

        eval_run = EvalRunBuilder(eval_run_id=uuid4())
        eval_run.dataset_hash = "abcdef1234567890"
        eval_run._devset = []
        eval_run._input_fields = {"question"}
        eval_run._dataset_exists = False

        d = eval_run.to_api_dict()

        assert "dataset" not in d

    def test_dataset_exists_none_fallback_includes_examples(self):
        """When _dataset_exists=None (check failed), include examples as fallback."""
        from uuid import uuid4
        from cmpnd.models import EvalRunBuilder

        devset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
        ]

        eval_run = EvalRunBuilder(eval_run_id=uuid4())
        eval_run.dataset_hash = "abcdef1234567890"
        eval_run._devset = devset
        eval_run._input_fields = {"question"}
        eval_run._dataset_exists = None  # Check failed

        d = eval_run.to_api_dict()

        assert "dataset" in d
        assert "examples" in d["dataset"]


# ---------------------------------------------------------------------------
# Task 9: OptimizationTracker dataset wiring tests
# ---------------------------------------------------------------------------

class TestOptimizationTrackerDatasetPayload:
    """Test that OptimizationTracker.to_api_dict() includes dataset block."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        _config.set(None)

    def _make_example(self, data: dict, input_keys: set):
        ex = mock.MagicMock()
        ex.toDict.return_value = data.copy()
        ex._input_keys = input_keys
        return ex

    def test_optimization_export_includes_dataset_when_valset_present(self):
        """Optimization export includes 'dataset' key when _valset is set."""
        from cmpnd.optimizers.tracker import OptimizationTracker

        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
        )
        tracker.valset_hash = "abcdef1234567890"

        valset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
            self._make_example({"question": "Q2", "answer": "A2"}, {"question"}),
        ]
        tracker._valset = valset
        tracker._valset_input_fields = {"question"}

        with mock.patch("cmpnd.dataset_sync.check_dataset_exists", return_value=False):
            d = tracker.to_api_dict()

        assert "dataset" in d
        assert d["dataset"]["dataset_hash"] == "abcdef1234567890"
        assert d["dataset"]["dataset_size"] == 2
        assert len(d["dataset"]["examples"]) == 2

    def test_optimization_export_skips_examples_when_exists(self):
        """When check_dataset_exists returns True, no examples included."""
        from cmpnd.optimizers.tracker import OptimizationTracker

        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
        )
        tracker.valset_hash = "abcdef1234567890"

        valset = [
            self._make_example({"question": "Q1", "answer": "A1"}, {"question"}),
        ]
        tracker._valset = valset
        tracker._valset_input_fields = {"question"}

        with mock.patch("cmpnd.dataset_sync.check_dataset_exists", return_value=True):
            d = tracker.to_api_dict()

        assert "dataset" in d
        assert "examples" not in d["dataset"]

    def test_optimization_export_no_dataset_without_valset(self):
        """Without _valset, no 'dataset' key is added."""
        from cmpnd.optimizers.tracker import OptimizationTracker

        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
        )
        tracker.valset_hash = "abcdef1234567890"

        d = tracker.to_api_dict()

        assert "dataset" not in d

    def test_optimization_dataset_correct_input_output_split(self):
        """Dataset payload correctly splits inputs and outputs."""
        from cmpnd.optimizers.tracker import OptimizationTracker

        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
        )
        tracker.valset_hash = "hash123"

        valset = [
            self._make_example(
                {"context": "C", "question": "Q", "answer": "A"},
                {"question", "context"},
            ),
        ]
        tracker._valset = valset
        tracker._valset_input_fields = {"question", "context"}

        with mock.patch("cmpnd.dataset_sync.check_dataset_exists", return_value=False):
            d = tracker.to_api_dict()

        assert d["dataset"]["input_fields"] == ["context", "question"]
        assert d["dataset"]["output_fields"] == ["answer"]
        ex0 = d["dataset"]["examples"][0]
        assert "question" in ex0["inputs"]
        assert "context" in ex0["inputs"]
        assert "answer" in ex0["expected_outputs"]
