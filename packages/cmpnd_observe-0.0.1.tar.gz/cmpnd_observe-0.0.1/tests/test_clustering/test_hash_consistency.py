"""Tests for hash computation consistency across SDK modules.

These tests verify that signature hashes are computed consistently using
the unified identity module, and that hashes are deterministic and order-independent.

Now that callback.py and tracker.py both use cmpnd.identity, all hash computations
should be identical.
"""

import pytest
import sys
from pathlib import Path

# Add local dspy and cmpnd to path
dspy_path = Path(__file__).parents[4] / "dspy"
sys.path.insert(0, str(dspy_path))

import dspy
from cmpnd.identity import compute_signature_hash, get_type_string
from cmpnd.optimizers.tracker import OptimizationTracker


class TestSignatureHashConsistency:
    """Tests for signature hash consistency using unified identity module."""

    def test_signature_hash_simple(self, simple_signature):
        """Simple signature produces consistent hash."""
        hash1 = compute_signature_hash(simple_signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(simple_signature)

        # Both should use the same underlying function
        assert hash1 == hash2

    def test_signature_hash_complex(self, complex_signature):
        """Complex signature produces consistent hash."""
        hash1 = compute_signature_hash(complex_signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(complex_signature)

        assert hash1 == hash2

    def test_signature_hash_typed(self, typed_signature):
        """Explicitly typed signature produces consistent hash."""
        hash1 = compute_signature_hash(typed_signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(typed_signature)

        assert hash1 == hash2

    def test_signature_hash_untyped_fields_now_consistent(self):
        """Untyped inline fields now produce consistent hashes (was a bug, now fixed)."""
        sig = dspy.Signature("question -> answer")

        # Check that annotation None is handled consistently as "str"
        input_field = sig.input_fields["question"]
        annotation = getattr(input_field, "annotation", None)
        type_str = get_type_string(annotation)

        # Now unified: None annotations return "str"
        assert type_str == "str", f"Expected 'str' for None annotation, got '{type_str}'"

        # Hash should be deterministic
        hash1 = compute_signature_hash(sig)
        hash2 = compute_signature_hash(sig)
        assert hash1 == hash2


class TestSignatureHashDeterminism:
    """Tests for deterministic hash computation."""

    def test_signature_hash_deterministic(self, simple_signature):
        """Same signature should produce same hash across multiple calls."""
        hash1 = OptimizationTracker.compute_program_signature_hash(simple_signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(simple_signature)
        hash3 = OptimizationTracker.compute_program_signature_hash(simple_signature)

        assert hash1 == hash2 == hash3

    def test_signature_hash_field_order_independent(self):
        """Field order in definition should not affect hash (fields are sorted)."""
        # Create two signatures with fields in different declaration order
        class SigAlphaFirst(dspy.Signature):
            alpha: str = dspy.InputField()
            beta: str = dspy.InputField()
            result: str = dspy.OutputField()

        class SigBetaFirst(dspy.Signature):
            beta: str = dspy.InputField()
            alpha: str = dspy.InputField()
            result: str = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(SigAlphaFirst)
        hash2 = OptimizationTracker.compute_program_signature_hash(SigBetaFirst)

        assert hash1 == hash2

    def test_signature_hash_different_fields_different_hash(self):
        """Different field names should produce different hashes."""
        sig1 = dspy.Signature("question -> answer")
        sig2 = dspy.Signature("query -> response")

        hash1 = OptimizationTracker.compute_program_signature_hash(sig1)
        hash2 = OptimizationTracker.compute_program_signature_hash(sig2)

        assert hash1 != hash2

    def test_signature_hash_different_types_different_hash(self):
        """Different field types should produce different hashes."""

        class SigStr(dspy.Signature):
            data: str = dspy.InputField()
            result: str = dspy.OutputField()

        class SigList(dspy.Signature):
            data: list[str] = dspy.InputField()
            result: str = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(SigStr)
        hash2 = OptimizationTracker.compute_program_signature_hash(SigList)

        assert hash1 != hash2

    def test_inline_vs_class_signature_same_hash(self, class_based_qa_signature):
        """Inline and class-based signatures with same fields should have same hash."""
        inline_sig = dspy.Signature("question -> answer")

        hash_inline = OptimizationTracker.compute_program_signature_hash(inline_sig)
        hash_class = OptimizationTracker.compute_program_signature_hash(class_based_qa_signature)

        # Both should hash the same since they have identical field structure
        assert hash_inline == hash_class


class TestValsetHashConsistency:
    """Tests for validation set hash computation."""

    def test_valset_hash_deterministic(self, sample_valset):
        """Same valset should produce same hash across multiple calls."""
        hash1 = OptimizationTracker.compute_valset_hash(sample_valset)
        hash2 = OptimizationTracker.compute_valset_hash(sample_valset)
        hash3 = OptimizationTracker.compute_valset_hash(sample_valset)

        assert hash1 == hash2 == hash3
        assert len(hash1) == 16  # SHA256 truncated to 16 hex chars

    def test_valset_hash_order_independent(self, sample_valset, valset_different_order):
        """Valset hash should be order-independent (examples are sorted)."""
        hash1 = OptimizationTracker.compute_valset_hash(sample_valset)
        hash2 = OptimizationTracker.compute_valset_hash(valset_different_order)

        assert hash1 == hash2

    def test_valset_hash_different_content_different_hash(self, sample_valset):
        """Different valset content should produce different hash."""
        different_valset = [
            dspy.Example(question="Different", context="Different").with_inputs("question", "context"),
        ]

        hash1 = OptimizationTracker.compute_valset_hash(sample_valset)
        hash2 = OptimizationTracker.compute_valset_hash(different_valset)

        assert hash1 != hash2

    def test_valset_hash_empty_list(self):
        """Empty valset should produce consistent hash."""
        hash1 = OptimizationTracker.compute_valset_hash([])
        hash2 = OptimizationTracker.compute_valset_hash([])

        assert hash1 == hash2
        assert len(hash1) == 16

    def test_valset_hash_with_pydantic_models(self, valset_with_pydantic):
        """Valset with Pydantic models should hash correctly."""
        hash1 = OptimizationTracker.compute_valset_hash(valset_with_pydantic)
        hash2 = OptimizationTracker.compute_valset_hash(valset_with_pydantic)

        assert hash1 == hash2
        assert len(hash1) == 16

    def test_valset_hash_with_dataclass(self, valset_with_dataclass):
        """Valset with dataclass objects should hash correctly."""
        hash1 = OptimizationTracker.compute_valset_hash(valset_with_dataclass)
        hash2 = OptimizationTracker.compute_valset_hash(valset_with_dataclass)

        assert hash1 == hash2
        assert len(hash1) == 16


class TestOptimizationSignatureHash:
    """Tests for optimization signature hash (component structure)."""

    def test_component_hash_deterministic(self, sample_components):
        """Component hash should be deterministic."""
        hash1 = OptimizationTracker.compute_signature_hash(sample_components)
        hash2 = OptimizationTracker.compute_signature_hash(sample_components)

        assert hash1 == hash2
        assert len(hash1) == 16

    def test_component_hash_order_independent(self, sample_components):
        """Component order should not affect hash (sorted by name)."""
        components_reversed = list(reversed(sample_components))

        hash1 = OptimizationTracker.compute_signature_hash(sample_components)
        hash2 = OptimizationTracker.compute_signature_hash(components_reversed)

        assert hash1 == hash2

    def test_component_hash_field_order_independent(self):
        """Field order within components should not affect hash."""
        components1 = [
            {"name": "test", "inputs": ["a", "b"], "outputs": ["x", "y"]}
        ]
        components2 = [
            {"name": "test", "inputs": ["b", "a"], "outputs": ["y", "x"]}
        ]

        hash1 = OptimizationTracker.compute_signature_hash(components1)
        hash2 = OptimizationTracker.compute_signature_hash(components2)

        assert hash1 == hash2

    def test_component_hash_different_structure_different_hash(self):
        """Different component structures should produce different hashes."""
        components1 = [
            {"name": "generate", "inputs": ["q"], "outputs": ["a"]}
        ]
        components2 = [
            {"name": "generate", "inputs": ["q", "c"], "outputs": ["a"]}
        ]

        hash1 = OptimizationTracker.compute_signature_hash(components1)
        hash2 = OptimizationTracker.compute_signature_hash(components2)

        assert hash1 != hash2

    def test_component_hash_empty_list(self):
        """Empty component list should produce consistent hash."""
        hash1 = OptimizationTracker.compute_signature_hash([])
        hash2 = OptimizationTracker.compute_signature_hash([])

        assert hash1 == hash2


class TestNullSignatureHandling:
    """Tests for handling None/null signatures."""

    def test_null_signature_returns_zero(self):
        """None signature should return 0 hash."""
        result = OptimizationTracker.compute_program_signature_hash(None)
        assert result == 0

    def test_empty_fields_signature(self, empty_signature):
        """Signature with no fields should produce consistent hash."""
        hash1 = OptimizationTracker.compute_program_signature_hash(empty_signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(empty_signature)

        assert hash1 == hash2


class TestXxhashDeterminism:
    """Tests that xxhash provides deterministic results across calls."""

    def test_signature_hash_is_64bit_int(self, simple_signature):
        """Signature hash should be a signed 64-bit integer."""
        hash_val = compute_signature_hash(simple_signature)

        assert isinstance(hash_val, int)
        assert -(2**63) <= hash_val <= 2**63 - 1

    def test_hash_stable_across_recreations(self):
        """Same signature structure should hash the same when recreated."""
        sig1 = dspy.Signature("question, context -> answer")
        sig2 = dspy.Signature("question, context -> answer")

        hash1 = compute_signature_hash(sig1)
        hash2 = compute_signature_hash(sig2)

        assert hash1 == hash2
