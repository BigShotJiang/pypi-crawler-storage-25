"""Clustering and grouping behavior tests for cmpnd SDK.

These tests verify that signature hashing, type conversion, and program identity
work correctly across the SDK. Many tests are expected to fail initially,
documenting known issues from STATE_OF_CLUSTERING.md.
"""
