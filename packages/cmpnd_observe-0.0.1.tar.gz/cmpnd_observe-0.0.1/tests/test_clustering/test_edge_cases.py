"""Edge case tests for DSPy signature patterns.

These tests verify clustering behavior for the various ways DSPy signatures
and programs can be defined, including:
- Multiple Predict modules with different signatures
- ChainOfThought extending base signatures
- ReAct with dynamically appended fields
- Nested program structures
"""

import pytest
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional, Literal

dspy_path = Path(__file__).parents[4] / "dspy"
sys.path.insert(0, str(dspy_path))

import dspy
from cmpnd.optimizers.tracker import OptimizationTracker


class TestMultipleModulesSameClassName:
    """Tests for multiple modules with same class name but different signatures.

    This is critical: Two dspy.Predict instances with different signatures
    should cluster separately, not together by class name.
    """

    def test_two_predict_different_signatures_different_hash(
        self, predict_qa, predict_summarize
    ):
        """Two Predict modules with different signatures have different hashes."""
        hash_qa = OptimizationTracker.compute_program_signature_hash(
            predict_qa.signature
        )
        hash_summarize = OptimizationTracker.compute_program_signature_hash(
            predict_summarize.signature
        )

        assert hash_qa != hash_summarize, (
            "Two Predict modules with different signatures should have different hashes"
        )

    def test_same_signature_same_hash_regardless_of_module(self, predict_qa):
        """Same signature in different module instances should have same hash."""
        predict1 = dspy.Predict("question -> answer")
        predict2 = dspy.Predict("question -> answer")

        hash1 = OptimizationTracker.compute_program_signature_hash(predict1.signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(predict2.signature)

        assert hash1 == hash2


class TestChainOfThoughtSignatureExtension:
    """Tests for ChainOfThought which extends the base signature."""

    def test_cot_has_reasoning_field(self, chain_of_thought_qa):
        """ChainOfThought adds a reasoning field to the signature."""
        # ChainOfThought wraps a Predict, signature is on .predict.signature
        sig = chain_of_thought_qa.predict.signature

        # CoT should have extended the signature with reasoning
        output_fields = list(sig.output_fields.keys())

        # The signature should have been modified to include reasoning
        assert "reasoning" in output_fields, f"Expected 'reasoning' in {output_fields}"

    def test_cot_different_hash_from_base_predict(
        self, predict_qa, chain_of_thought_qa
    ):
        """ChainOfThought should have different hash from base Predict with same input sig."""
        hash_predict = OptimizationTracker.compute_program_signature_hash(
            predict_qa.signature
        )
        # ChainOfThought wraps a Predict, signature is on .predict.signature
        hash_cot = OptimizationTracker.compute_program_signature_hash(
            chain_of_thought_qa.predict.signature
        )

        # They should differ because CoT adds reasoning field
        assert hash_predict != hash_cot


class TestInlineVsClassSignatureEquivalence:
    """Tests for signature equivalence between inline and class-based definitions."""

    def test_inline_and_class_same_fields_same_hash(self, class_based_qa_signature):
        """Inline 'question -> answer' should match class-based equivalent."""
        inline_sig = dspy.Signature("question -> answer")

        hash_inline = OptimizationTracker.compute_program_signature_hash(inline_sig)
        hash_class = OptimizationTracker.compute_program_signature_hash(
            class_based_qa_signature
        )

        assert hash_inline == hash_class

    def test_signature_name_does_not_affect_hash(self):
        """Different signature names with same fields should have same hash."""

        class SigA(dspy.Signature):
            """First signature."""
            question: str = dspy.InputField()
            answer: str = dspy.OutputField()

        class SigB(dspy.Signature):
            """Second signature with different name."""
            question: str = dspy.InputField()
            answer: str = dspy.OutputField()

        hash_a = OptimizationTracker.compute_program_signature_hash(SigA)
        hash_b = OptimizationTracker.compute_program_signature_hash(SigB)

        assert hash_a == hash_b

    def test_instructions_do_not_affect_hash(self):
        """Different instructions with same fields should have same hash."""
        sig1 = dspy.Signature("question -> answer", instructions="Answer briefly.")
        sig2 = dspy.Signature("question -> answer", instructions="Answer in detail.")

        hash1 = OptimizationTracker.compute_program_signature_hash(sig1)
        hash2 = OptimizationTracker.compute_program_signature_hash(sig2)

        assert hash1 == hash2


class TestDynamicSignatureModification:
    """Tests for dynamically modified signatures (like ReAct does)."""

    def test_signature_append_changes_hash(self):
        """Appending a field to a signature changes its hash."""
        base_sig = dspy.Signature("question -> answer")
        extended_sig = base_sig.append(
            "reasoning", dspy.OutputField(), type_=str
        )

        hash_base = OptimizationTracker.compute_program_signature_hash(base_sig)
        hash_extended = OptimizationTracker.compute_program_signature_hash(extended_sig)

        assert hash_base != hash_extended

    def test_signature_prepend_changes_hash(self):
        """Prepending a field to a signature changes its hash."""
        base_sig = dspy.Signature("question -> answer")
        extended_sig = base_sig.prepend(
            "context", dspy.InputField(), type_=str
        )

        hash_base = OptimizationTracker.compute_program_signature_hash(base_sig)
        hash_extended = OptimizationTracker.compute_program_signature_hash(extended_sig)

        assert hash_base != hash_extended

    def test_multiple_modifications_stable_hash(self):
        """Multiple modifications produce consistent hash."""
        base_sig = dspy.Signature("question -> answer")
        extended = (
            base_sig
            .append("reasoning", dspy.OutputField(), type_=str)
            .prepend("context", dspy.InputField(), type_=str)
        )

        hash1 = OptimizationTracker.compute_program_signature_hash(extended)
        hash2 = OptimizationTracker.compute_program_signature_hash(extended)

        assert hash1 == hash2


class TestComplexFieldTypes:
    """Tests for signatures with complex field types."""

    def test_list_type_signature(self):
        """Signature with List[str] field hashes correctly."""

        class ListSig(dspy.Signature):
            items: List[str] = dspy.InputField()
            result: str = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(ListSig)
        hash2 = OptimizationTracker.compute_program_signature_hash(ListSig)

        assert hash1 == hash2

    def test_dict_type_signature(self):
        """Signature with Dict type hashes correctly."""

        class DictSig(dspy.Signature):
            data: Dict[str, Any] = dspy.InputField()
            result: str = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(DictSig)
        hash2 = OptimizationTracker.compute_program_signature_hash(DictSig)

        assert hash1 == hash2

    def test_optional_type_signature(self):
        """Signature with Optional field hashes correctly."""

        class OptionalSig(dspy.Signature):
            required: str = dspy.InputField()
            optional: Optional[str] = dspy.InputField()
            result: str = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(OptionalSig)
        hash2 = OptimizationTracker.compute_program_signature_hash(OptionalSig)

        assert hash1 == hash2

    def test_literal_type_signature(self):
        """Signature with Literal type hashes correctly."""

        class LiteralSig(dspy.Signature):
            question: str = dspy.InputField()
            sentiment: Literal["positive", "negative", "neutral"] = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(LiteralSig)
        hash2 = OptimizationTracker.compute_program_signature_hash(LiteralSig)

        assert hash1 == hash2

    def test_literal_order_affects_hash(self):
        """Different Literal orderings may affect hash (documenting behavior)."""

        class Lit1(dspy.Signature):
            output: Literal["a", "b", "c"] = dspy.OutputField()

        class Lit2(dspy.Signature):
            output: Literal["c", "b", "a"] = dspy.OutputField()

        hash1 = OptimizationTracker.compute_program_signature_hash(Lit1)
        hash2 = OptimizationTracker.compute_program_signature_hash(Lit2)

        # Document whether order matters (it might for Literal types)
        # This is informational - either result is acceptable as long as consistent
        if hash1 == hash2:
            pass  # Order doesn't matter - good for clustering
        else:
            pass  # Order matters - may cause over-splitting


class TestNestedProgramStructures:
    """Tests for programs with nested module structures."""

    def test_nested_module_signatures_independent(self):
        """Each module in a nested program should have its own signature hash."""

        class QAProgram(dspy.Module):
            def __init__(self):
                super().__init__()
                self.retrieve = dspy.Predict("question -> context")
                self.answer = dspy.Predict("question, context -> answer")

            def forward(self, question):
                ctx = self.retrieve(question=question)
                return self.answer(question=question, context=ctx.context)

        program = QAProgram()

        hash_retrieve = OptimizationTracker.compute_program_signature_hash(
            program.retrieve.signature
        )
        hash_answer = OptimizationTracker.compute_program_signature_hash(
            program.answer.signature
        )

        # The two modules should have different hashes
        assert hash_retrieve != hash_answer

    def test_program_with_cot_and_predict(self):
        """Program with both CoT and Predict modules clusters correctly."""

        class MixedProgram(dspy.Module):
            def __init__(self):
                super().__init__()
                self.reason = dspy.ChainOfThought("question -> analysis")
                self.answer = dspy.Predict("analysis -> answer")

            def forward(self, question):
                analysis = self.reason(question=question)
                return self.answer(analysis=analysis.analysis)

        program = MixedProgram()

        # ChainOfThought wraps a Predict, signature is on .predict.signature
        hash_reason = OptimizationTracker.compute_program_signature_hash(
            program.reason.predict.signature
        )
        hash_answer = OptimizationTracker.compute_program_signature_hash(
            program.answer.signature
        )

        assert hash_reason != hash_answer


class TestEmptyAndMinimalSignatures:
    """Tests for edge cases with empty or minimal signatures."""

    def test_empty_signature_consistent(self, empty_signature):
        """Empty signature produces consistent hash."""
        hash1 = OptimizationTracker.compute_program_signature_hash(empty_signature)
        hash2 = OptimizationTracker.compute_program_signature_hash(empty_signature)

        assert hash1 == hash2

    def test_single_input_field(self):
        """Signature with only input field hashes correctly."""
        sig = dspy.Signature("input ->")  # Only input, empty output

        hash1 = OptimizationTracker.compute_program_signature_hash(sig)
        hash2 = OptimizationTracker.compute_program_signature_hash(sig)

        assert hash1 == hash2

    def test_single_output_field(self):
        """Signature with only output field hashes correctly."""
        sig = dspy.Signature("-> output")  # Empty input, only output

        hash1 = OptimizationTracker.compute_program_signature_hash(sig)
        hash2 = OptimizationTracker.compute_program_signature_hash(sig)

        assert hash1 == hash2


class TestUnicodeFieldNames:
    """Tests for signatures with Unicode field names."""

    def test_unicode_field_names_hash_correctly(self):
        """Fields with Unicode names hash correctly."""

        class UnicodeSig(dspy.Signature):
            pregunta: str = dspy.InputField(desc="La pregunta")
            respuesta: str = dspy.OutputField(desc="La respuesta")

        hash1 = OptimizationTracker.compute_program_signature_hash(UnicodeSig)
        hash2 = OptimizationTracker.compute_program_signature_hash(UnicodeSig)

        assert hash1 == hash2

    def test_unicode_vs_ascii_different_hash(self):
        """Unicode field names produce different hash than ASCII equivalents."""
        sig_ascii = dspy.Signature("question -> answer")

        class SigUnicode(dspy.Signature):
            pregunta: str = dspy.InputField()
            respuesta: str = dspy.OutputField()

        hash_ascii = OptimizationTracker.compute_program_signature_hash(sig_ascii)
        hash_unicode = OptimizationTracker.compute_program_signature_hash(SigUnicode)

        assert hash_ascii != hash_unicode
