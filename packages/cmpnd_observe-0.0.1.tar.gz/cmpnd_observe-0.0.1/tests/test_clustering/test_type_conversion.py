"""Tests for type annotation to string conversion.

These tests verify the behavior of get_type_string in the unified identity module.
The identity module provides a single source of truth for type string conversion,
resolving the previous inconsistency between callback.py and tracker.py.
"""

import pytest
import sys
from pathlib import Path
from typing import List, Dict, Optional, Union, Any, Literal

dspy_path = Path(__file__).parents[4] / "dspy"
sys.path.insert(0, str(dspy_path))

import dspy
from pydantic import BaseModel
from cmpnd.identity import get_type_string


class TestTypeStringNoneHandling:
    """Tests for None annotation handling (now unified)."""

    def test_none_annotation_returns_str(self):
        """get_type_string returns 'str' for None annotation (default type)."""
        result = get_type_string(None)
        assert result == "str"

    def test_none_handling_is_consistent(self):
        """The None handling is now consistent (fixed bug)."""
        # Previously callback returned "None" and tracker returned "str"
        # Now unified to return "str" for None annotations
        result = get_type_string(None)
        assert result == "str", (
            f"Expected 'str' for None annotation, got '{result}'"
        )


class TestTypeStringBasicTypes:
    """Tests for basic Python type conversions."""

    def test_str_type(self):
        """str type converts correctly."""
        assert get_type_string(str) == "str"

    def test_int_type(self):
        """int type converts correctly."""
        assert get_type_string(int) == "int"

    def test_float_type(self):
        """float type converts correctly."""
        assert get_type_string(float) == "float"

    def test_bool_type(self):
        """bool type converts correctly."""
        assert get_type_string(bool) == "bool"

    def test_list_type(self):
        """list type converts correctly."""
        assert get_type_string(list) == "list"

    def test_dict_type(self):
        """dict type converts correctly."""
        assert get_type_string(dict) == "dict"


class TestTypeStringGenericTypes:
    """Tests for generic typing module types."""

    def test_list_str(self):
        """List[str] converts correctly."""
        result = get_type_string(List[str])

        assert "list" in result.lower()
        assert "str" in result

    def test_dict_str_int(self):
        """Dict[str, int] converts correctly."""
        result = get_type_string(Dict[str, int])

        assert "dict" in result.lower()
        assert "str" in result
        assert "int" in result

    def test_optional_str(self):
        """Optional[str] converts correctly."""
        result = get_type_string(Optional[str])
        # Optional[str] is Union[str, None] - should contain Union/str/NoneType
        assert result  # Non-empty result

    def test_union_str_int(self):
        """Union[str, int] converts correctly."""
        result = get_type_string(Union[str, int])
        # Should contain Union and both types
        assert result

    def test_nested_generic(self):
        """Nested generics like List[Dict[str, int]] convert correctly."""
        result = get_type_string(List[Dict[str, int]])
        assert result

    def test_any_type(self):
        """Any type converts correctly."""
        result = get_type_string(Any)
        # Any should produce some result
        assert result


class TestTypeStringLiteralTypes:
    """Tests for Literal type handling."""

    def test_literal_strings(self):
        """Literal['a', 'b'] converts consistently."""
        lit_type = Literal["a", "b"]
        result = get_type_string(lit_type)
        assert result  # Should produce some result

    def test_literal_ints(self):
        """Literal[1, 2, 3] converts consistently."""
        lit_type = Literal[1, 2, 3]
        result = get_type_string(lit_type)
        assert result


class TestTypeStringCustomTypes:
    """Tests for custom class type handling."""

    def test_pydantic_model(self):
        """Pydantic BaseModel subclass converts correctly."""

        class MyModel(BaseModel):
            name: str
            value: int

        result = get_type_string(MyModel)
        assert result == "MyModel"

    def test_custom_class(self):
        """Regular custom class converts correctly."""

        class MyClass:
            pass

        result = get_type_string(MyClass)
        assert result == "MyClass"

    def test_dspy_signature_as_type(self):
        """DSPy Signature used as a type converts correctly."""

        class QA(dspy.Signature):
            question: str = dspy.InputField()
            answer: str = dspy.OutputField()

        result = get_type_string(QA)
        assert result == "QA"


class TestTypeStringConsistencyAcrossRealSignatures:
    """Test type string consistency with real DSPy signatures."""

    def test_inline_signature_field_types(self):
        """Inline signature field types are consistent."""
        sig = dspy.Signature("question, context -> answer")

        for name, field in sig.input_fields.items():
            annotation = getattr(field, "annotation", None)
            type_str = get_type_string(annotation)

            # DSPy inline signatures may have None or str annotations
            # Our unified behavior returns "str" for None
            assert type_str == "str", (
                f"Field {name}: expected 'str' for annotation {annotation}, got '{type_str}'"
            )

    def test_class_signature_field_types(self, typed_signature):
        """Class-based signature with explicit types are consistent."""
        for name, field in typed_signature.input_fields.items():
            annotation = getattr(field, "annotation", None)
            type_str = get_type_string(annotation)

            # Explicit types should have proper type strings
            assert type_str, f"Field {name} should have a type string"


class TestTypeStringFallbackBehavior:
    """Tests for fallback behavior with unusual types."""

    def test_nonetype_class(self):
        """type(None) (NoneType) converts correctly."""
        result = get_type_string(type(None))
        assert result == "NoneType"

    def test_callable_type(self):
        """Callable types convert consistently."""
        from typing import Callable

        result = get_type_string(Callable[[str], int])
        assert result  # Should produce some result


class TestTypeStringDeterminism:
    """Tests for deterministic type string conversion."""

    def test_same_type_same_string(self):
        """Same type should always produce the same string."""
        result1 = get_type_string(List[str])
        result2 = get_type_string(List[str])
        result3 = get_type_string(List[str])

        assert result1 == result2 == result3

    def test_equivalent_types_same_string(self):
        """Equivalent type annotations should produce the same string."""
        # list[str] and List[str] should produce same result in Python 3.9+
        result1 = get_type_string(List[str])
        result2 = get_type_string(list[str])

        assert result1 == result2
