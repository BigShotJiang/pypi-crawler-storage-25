"""Pytest fixtures for clustering tests using real DSPy objects."""

import pytest
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass

# Add the local dspy to path
dspy_path = Path(__file__).parents[4] / "dspy"
sys.path.insert(0, str(dspy_path))

import dspy
from pydantic import BaseModel


# Real DSPy signatures
@pytest.fixture
def simple_signature():
    """A simple question -> answer signature."""
    return dspy.Signature("question -> answer")


@pytest.fixture
def complex_signature():
    """Signature with multiple fields."""
    return dspy.Signature("question, context, metadata -> answer, confidence, sources")


@pytest.fixture
def typed_signature():
    """Signature with explicit type annotations."""

    class TypedQA(dspy.Signature):
        """Answer questions with typed fields."""
        question: str = dspy.InputField()
        items: list[str] = dspy.InputField()
        answer: str = dspy.OutputField()
        count: int = dspy.OutputField()

    return TypedQA


@pytest.fixture
def optional_types_signature():
    """Signature with Optional/Union types."""

    class OptionalSig(dspy.Signature):
        """Signature with optional fields."""
        required: str = dspy.InputField()
        optional: Optional[str] = dspy.InputField()
        result: Union[str, int] = dspy.OutputField()

    return OptionalSig


@pytest.fixture
def empty_signature():
    """Signature with no fields (edge case)."""
    # Create minimal signature
    return dspy.Signature({})


@pytest.fixture
def sample_components():
    """Sample component list for optimization signature hash."""
    return [
        {
            "name": "generate",
            "inputs": ["question", "context"],
            "outputs": ["answer"]
        },
        {
            "name": "validate",
            "inputs": ["answer"],
            "outputs": ["is_valid", "feedback"]
        }
    ]


@pytest.fixture
def sample_valset():
    """Sample validation set using real DSPy Examples."""
    return [
        dspy.Example(question="What is 2+2?", context="Math basics").with_inputs("question", "context"),
        dspy.Example(question="Who wrote Hamlet?", context="Literature").with_inputs("question", "context"),
        dspy.Example(question="Capital of France?", context="Geography").with_inputs("question", "context"),
    ]


@pytest.fixture
def valset_different_order(sample_valset):
    """Same valset in different order."""
    return list(reversed(sample_valset))


class Document(BaseModel):
    """Pydantic model for testing complex types."""
    title: str
    content: str


@pytest.fixture
def valset_with_pydantic():
    """Validation set with Pydantic models."""
    return [
        dspy.Example(
            question="Summarize this",
            document=Document(title="Test", content="Test content")
        ).with_inputs("question", "document"),
    ]


@dataclass
class DataItem:
    """Dataclass for testing serialization."""
    name: str
    value: int


@pytest.fixture
def valset_with_dataclass():
    """Validation set with dataclass objects."""
    return [
        dspy.Example(
            question="Process this",
            data=DataItem(name="test", value=42)
        ).with_inputs("question", "data"),
    ]


@pytest.fixture
def predict_qa():
    """A Predict module with QA signature."""
    return dspy.Predict("question -> answer")


@pytest.fixture
def predict_summarize():
    """A Predict module with different signature (same class name)."""
    return dspy.Predict("text -> summary")


@pytest.fixture
def chain_of_thought_qa():
    """A ChainOfThought module with QA signature."""
    return dspy.ChainOfThought("question -> answer")


@pytest.fixture
def class_based_qa_signature():
    """Class-based signature equivalent to 'question -> answer'."""

    class QASignature(dspy.Signature):
        """Answer the question."""
        question: str = dspy.InputField()
        answer: str = dspy.OutputField()

    return QASignature
