"""Tests for the batch exporter."""

import logging
from unittest.mock import MagicMock, call, patch

import httpx
import pytest

from cmpnd.config import Config
from cmpnd.exporter import BatchExporter, ExportItem


@pytest.fixture
def config():
    return Config(api_key="test", endpoint="http://localhost:9999")


@pytest.fixture
def exporter(config):
    return BatchExporter(config)


def test_exporter_initial_counts(exporter):
    """Verify the counter fields exist and start at zero."""
    assert exporter._dropped_count == 0
    assert exporter._error_count == 0
    assert exporter._exported_count == 0


def _make_http_status_error(status_code: int) -> httpx.HTTPStatusError:
    """Create a mock HTTPStatusError with the given status code."""
    response = httpx.Response(status_code=status_code, request=httpx.Request("POST", "http://test"))
    return httpx.HTTPStatusError(
        message=f"{status_code} error",
        request=response.request,
        response=response,
    )


def _make_trace_item():
    """Create a minimal ExportItem for a trace."""
    from cmpnd.exporter import ExportItem

    mock_trace = MagicMock()
    mock_trace.to_api_dict.return_value = {
        "trace_id": "abc-123",
        "spans": [],
    }
    return ExportItem(item_type="trace", data=mock_trace, timestamp=0.0)


def test_exporter_handles_429_gracefully(exporter, caplog):
    """429 should increment dropped count, not error count."""
    exporter._client = MagicMock()
    exporter._client.post.return_value = MagicMock()
    exporter._client.post.return_value.raise_for_status.side_effect = (
        _make_http_status_error(429)
    )

    batch = [_make_trace_item()]

    with caplog.at_level(logging.WARNING):
        exporter._flush_batch(batch)

    assert exporter._dropped_count == 1
    assert exporter._error_count == 0
    assert "Server buffer full" in caplog.text
    assert "Stats were accepted separately" in caplog.text


def test_exporter_handles_other_http_errors(exporter, caplog):
    """Non-429 HTTP errors should increment error count, not dropped count."""
    exporter._client = MagicMock()
    exporter._client.post.return_value = MagicMock()
    exporter._client.post.return_value.raise_for_status.side_effect = (
        _make_http_status_error(500)
    )

    batch = [_make_trace_item()]

    with caplog.at_level(logging.ERROR):
        exporter._flush_batch(batch)

    assert exporter._error_count == 1
    assert exporter._dropped_count == 0
    assert "Failed to export traces batch" in caplog.text


def test_exporter_handles_non_http_errors(exporter, caplog):
    """Non-HTTP exceptions should increment error count."""
    exporter._client = MagicMock()
    exporter._client.post.return_value = MagicMock()
    exporter._client.post.return_value.raise_for_status.side_effect = (
        ConnectionError("connection refused")
    )

    batch = [_make_trace_item()]

    with caplog.at_level(logging.ERROR):
        exporter._flush_batch(batch)

    assert exporter._error_count == 1
    assert exporter._dropped_count == 0
    assert "Failed to export traces batch" in caplog.text


# --- Helpers for streaming exporter tests ---


def _make_span_item(trace_id="abc-123", span_id="span-1"):
    mock_span = MagicMock()
    mock_span.to_api_dict.return_value = {
        "span_id": span_id,
        "trace_id": trace_id,
        "name": "predict",
        "span_type": "predict",
        "status": "ok",
        "prompt_tokens": 10,
        "completion_tokens": 5,
        "total_tokens": 15,
    }
    return ExportItem(item_type="span", data=mock_span, timestamp=0.0)


def _make_trace_start_item(trace_id="abc-123"):
    mock_trace = MagicMock()
    mock_trace.trace_id = trace_id
    mock_trace.to_start_dict.return_value = {
        "start_time": "2026-03-23T00:00:00Z",
        "program_name": "Test",
        "signature_hash": 12345,
    }
    return ExportItem(item_type="trace_start", data=mock_trace, timestamp=0.0)


def _make_trace_finalize_item(trace_id="abc-123"):
    mock_trace = MagicMock()
    mock_trace.trace_id = trace_id
    mock_trace.to_finalize_dict.return_value = {
        "status": "ok",
        "total_tokens": 150,
        "span_count": 5,
    }
    return ExportItem(item_type="trace_finalize", data=mock_trace, timestamp=0.0)


# --- Streaming exporter tests ---


def test_exporter_sends_trace_start(exporter):
    """trace_start items should POST to /api/v1/traces/:id/start."""
    exporter._client = MagicMock()
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    exporter._client.post.return_value = resp

    batch = [_make_trace_start_item("abc-123")]
    exporter._flush_batch(batch)

    exporter._client.post.assert_called_once_with(
        "/api/v1/traces/abc-123/start",
        json={"start_time": "2026-03-23T00:00:00Z", "program_name": "Test", "signature_hash": 12345},
    )


def test_exporter_sends_spans_directly(exporter):
    """Spans should be sent to /api/v1/traces/:id/spans grouped by trace_id."""
    exporter._client = MagicMock()
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    exporter._client.post.return_value = resp

    batch = [_make_span_item("abc-123", "s1"), _make_span_item("abc-123", "s2")]
    exporter._flush_batch(batch)

    exporter._client.post.assert_called_once()
    call_args = exporter._client.post.call_args
    assert call_args[0][0] == "/api/v1/traces/abc-123/spans"
    assert len(call_args[1]["json"]["spans"]) == 2


def test_exporter_sends_trace_finalize(exporter):
    """trace_finalize items should POST to /api/v1/traces/:id/finalize."""
    exporter._client = MagicMock()
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    exporter._client.post.return_value = resp

    batch = [_make_trace_finalize_item("abc-123")]
    exporter._flush_batch(batch)

    exporter._client.post.assert_called_once_with(
        "/api/v1/traces/abc-123/finalize",
        json={"status": "ok", "total_tokens": 150, "span_count": 5},
    )


def test_exporter_old_trace_path_still_works(exporter):
    """The old trace item type should still work with pending spans."""
    exporter._client = MagicMock()
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    exporter._client.post.return_value = resp

    # Old path: manually buffer a span, then trace picks it up
    exporter._pending_spans["abc-123"] = [{"span_id": "s1", "trace_id": "abc-123"}]

    trace_item = _make_trace_item()
    batch = [trace_item]
    exporter._flush_batch(batch)

    # The trace should have picked up the buffered span
    call_args = exporter._client.post.call_args
    assert call_args[0][0] == "/api/v1/traces"
    trace_payload = call_args[1]["json"]
    assert len(trace_payload["spans"]) == 1
