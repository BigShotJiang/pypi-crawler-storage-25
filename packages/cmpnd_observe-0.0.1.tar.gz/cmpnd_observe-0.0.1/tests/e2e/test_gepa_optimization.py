"""GEPA optimization tracking tests.

Verify that running dspy.GEPA creates an optimization run
that is visible through the server API.
"""

from __future__ import annotations

import time

import dspy
import pytest

from tests.e2e.conftest import E2E_MODEL, CMPND_E2E_GROQ_KEY, flush_and_wait


pytestmark = pytest.mark.e2e


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

TRAIN_SET = [
    dspy.Example(question="What is 2+2?", answer="4").with_inputs("question"),
    dspy.Example(question="What is 3+1?", answer="4").with_inputs("question"),
    dspy.Example(question="What is 5+3?", answer="8").with_inputs("question"),
    dspy.Example(question="What is 10-7?", answer="3").with_inputs("question"),
    dspy.Example(question="What is 6*2?", answer="12").with_inputs("question"),
]

VAL_SET = [
    dspy.Example(question="What is 9-4?", answer="5").with_inputs("question"),
    dspy.Example(question="What is 7+1?", answer="8").with_inputs("question"),
    dspy.Example(question="What is 3*3?", answer="9").with_inputs("question"),
]


# ---------------------------------------------------------------------------
# Metric — GEPA requires (gold, pred, trace, pred_name, pred_trace)
# ---------------------------------------------------------------------------


def simple_metric(gold, pred, trace=None, pred_name=None, pred_trace=None):
    """Exact-match metric on the 'answer' field."""
    gold_answer = gold.get("answer") if hasattr(gold, "get") else getattr(gold, "answer", "")
    pred_answer = getattr(pred, "answer", "")
    return 1.0 if str(gold_answer).strip() == str(pred_answer).strip() else 0.0


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestGEPAOptimization:

    def test_gepa_creates_optimization_run(self, server_client, trace_capture):
        student = dspy.Predict("question -> answer")
        reflection_lm = dspy.LM(
            E2E_MODEL, api_key=CMPND_E2E_GROQ_KEY or "", max_tokens=300, cache=False,
        )
        optimizer = dspy.GEPA(
            metric=simple_metric,
            max_metric_calls=20,
            num_threads=1,
            reflection_lm=reflection_lm,
        )

        try:
            optimizer.compile(student, trainset=TRAIN_SET, valset=VAL_SET)
        except Exception:
            pass  # May error with low budget

        flush_and_wait(seconds=5)

        # Search for optimization runs
        results = server_client.search_optimizations(program_name="Predict")
        optimizations = results.get("optimization_runs") or results.get("optimizations") or results.get("data") or []
        assert len(optimizations) >= 1, (
            f"Expected at least 1 optimization run, got {len(optimizations)}"
        )

        # Verify the most recent one
        opt = optimizations[0]
        opt_id = opt.get("run_id") or opt.get("id") or opt.get("optimization_run_id")
        assert opt_id is not None

        detail = server_client.get_optimization(str(opt_id))
        # show returns the record directly (no wrapping key)
        assert detail.get("status") in ("completed", "running", "failed")

        # Iterations endpoint should work (may be empty)
        iterations_resp = server_client.get_optimization_iterations(str(opt_id))
        assert isinstance(iterations_resp, (dict, list))
