"""Multi-call and edge case tests.

Verify that sequential DSPy calls produce distinct traces and that
large inputs are handled gracefully.
"""

from __future__ import annotations

import dspy
import pytest

from tests.e2e.conftest import flush_and_wait


pytestmark = pytest.mark.e2e


class TestMultipleSequentialCalls:

    def test_sequential_calls_distinct_traces(self, server_client, trace_capture):
        predict = dspy.Predict("question -> answer")

        # First call
        predict(question="What is the tallest mountain?")
        first_trace_id = trace_capture.last_trace_id
        assert first_trace_id is not None

        # Second call
        predict(question="What is the deepest ocean?")
        second_trace_id = trace_capture.last_trace_id
        assert second_trace_id is not None

        assert first_trace_id != second_trace_id

        flush_and_wait()

        # Both traces should be on the server
        first_data = server_client.get_trace(first_trace_id)
        assert first_data["trace"]["status"] == "ok"

        second_data = server_client.get_trace(second_trace_id)
        assert second_data["trace"]["status"] == "ok"


class TestLargeInputTruncation:

    def test_large_input(self, server_client, trace_capture):
        predict = dspy.Predict("text -> summary")
        large_text = "The quick brown fox. " * 2000
        predict(text=large_text)

        flush_and_wait()

        trace_id = trace_capture.last_trace_id
        assert trace_id is not None

        data = server_client.get_trace(trace_id)
        trace = data["trace"]
        spans = data["spans"]

        assert trace["status"] == "ok"

        predict_spans = [
            s for s in spans
            if s.get("span_type") == "predict" or "predict" in s.get("name", "").lower()
        ]
        assert len(predict_spans) > 0
        assert "text" in (predict_spans[0].get("inputs") or {})
