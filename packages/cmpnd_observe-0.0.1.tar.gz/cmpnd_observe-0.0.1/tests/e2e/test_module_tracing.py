"""Core module tracing tests.

Verify that different DSPy module types produce correct traces and spans.
"""

from __future__ import annotations

import dspy
import pytest

from tests.e2e.conftest import flush_and_wait


# ---------------------------------------------------------------------------
# 1. TestPredictBasic
# ---------------------------------------------------------------------------


class TestPredictBasic:
    """Basic dspy.Predict with a simple signature."""

    def test_predict_basic(self, server_client, trace_capture):
        predict = dspy.Predict("question -> answer")
        predict(question="What is the capital of France?")

        flush_and_wait()

        trace_id = trace_capture.last_trace_id
        assert trace_id is not None, "No trace captured"

        data = server_client.get_trace(trace_id)
        trace = data["trace"]
        spans = data["spans"]

        # Span types include predict/module and lm_call
        span_types = {s["span_type"] for s in spans}
        assert span_types & {"predict", "module"}, f"Expected predict or module span, got {span_types}"
        assert "lm_call" in span_types, f"Expected lm_call span, got {span_types}"

        # signature_hash present and != 0
        assert trace.get("signature_hash") is not None
        assert trace["signature_hash"] != 0

        # total_tokens > 0
        assert trace.get("total_tokens", 0) > 0


# ---------------------------------------------------------------------------
# 2. TestChainOfThought
# ---------------------------------------------------------------------------


class TestChainOfThought:
    """dspy.ChainOfThought adds reasoning to the output."""

    def test_chain_of_thought(self, server_client, trace_capture):
        cot = dspy.ChainOfThought("question -> answer")
        cot(question="Why is the sky blue?")

        flush_and_wait()

        trace_id = trace_capture.last_trace_id
        assert trace_id is not None, "No trace captured"

        data = server_client.get_trace(trace_id)
        spans = data["spans"]

        span_types = {s["span_type"] for s in spans}
        assert "chain_of_thought" in span_types, f"Expected chain_of_thought span, got {span_types}"

        # Output fields should include reasoning or rationale
        cot_spans = [s for s in spans if s["span_type"] == "chain_of_thought"]
        output_fields = cot_spans[0].get("signature_output_fields") or []
        assert any(
            f in output_fields for f in ("reasoning", "rationale")
        ), f"Expected reasoning/rationale in output fields, got {output_fields}"


# ---------------------------------------------------------------------------
# 3. TestTypedSignature
# ---------------------------------------------------------------------------


class TestTypedSignature:
    """Predict with a Pydantic BaseModel output type."""

    def test_typed_signature(self, server_client, trace_capture):
        from pydantic import BaseModel

        class Sentiment(BaseModel):
            label: str
            score: float

        class SentimentSignature(dspy.Signature):
            """Classify the sentiment of the text."""

            text: str = dspy.InputField()
            sentiment: Sentiment = dspy.OutputField()

        predict = dspy.Predict(SentimentSignature)

        # Parsing may fail with the LLM output — we still get the trace
        try:
            predict(text="I love sunny days!")
        except Exception:
            pass

        flush_and_wait()

        trace_id = trace_capture.last_trace_id
        assert trace_id is not None, "No trace captured"

        data = server_client.get_trace(trace_id)
        spans = data["spans"]

        # Find predict/module spans and check fields
        predict_spans = [s for s in spans if s["span_type"] in ("predict", "module")]
        assert len(predict_spans) >= 1
        ps = predict_spans[0]
        assert "text" in (ps.get("signature_input_fields") or [])
        assert "sentiment" in (ps.get("signature_output_fields") or [])


# ---------------------------------------------------------------------------
# 4. TestMultiFieldSignature
# ---------------------------------------------------------------------------


class TestMultiFieldSignature:
    """Signature with multiple input and output fields."""

    def test_multi_field_signature(self, server_client, trace_capture):
        predict = dspy.Predict("context, question -> answer, confidence")
        predict(
            context="Paris is the capital of France.",
            question="What is the capital of France?",
        )

        flush_and_wait()

        trace_id = trace_capture.last_trace_id
        assert trace_id is not None, "No trace captured"

        data = server_client.get_trace(trace_id)
        spans = data["spans"]

        predict_spans = [s for s in spans if s["span_type"] in ("predict", "module")]
        assert len(predict_spans) >= 1
        ps = predict_spans[0]

        input_fields = ps.get("signature_input_fields") or []
        output_fields = ps.get("signature_output_fields") or []

        assert "context" in input_fields, f"Expected 'context' in {input_fields}"
        assert "question" in input_fields, f"Expected 'question' in {input_fields}"
        assert "answer" in output_fields, f"Expected 'answer' in {output_fields}"
        assert "confidence" in output_fields, f"Expected 'confidence' in {output_fields}"


# ---------------------------------------------------------------------------
# 5. TestCustomModule
# ---------------------------------------------------------------------------


class TestCustomModule:
    """Custom module with 2 Predict sub-modules."""

    def test_custom_module(self, server_client, trace_capture):
        class SummarizeAndAnswer(dspy.Module):
            def __init__(self):
                super().__init__()
                self.summarize = dspy.Predict("context -> summary")
                self.answer = dspy.Predict("summary, question -> answer")

            def forward(self, context: str, question: str):
                summary = self.summarize(context=context)
                return self.answer(summary=summary.summary, question=question)

        module = SummarizeAndAnswer()
        module(
            context="The Eiffel Tower is a wrought-iron lattice tower in Paris, France. "
            "It was constructed from 1887 to 1889 as the centerpiece of the 1889 World's Fair.",
            question="When was the Eiffel Tower built?",
        )

        flush_and_wait()

        trace_id = trace_capture.last_trace_id
        assert trace_id is not None, "No trace captured"

        data = server_client.get_trace(trace_id)
        spans = data["spans"]

        # At least 2 predict spans
        predict_spans = [s for s in spans if s["span_type"] in ("predict", "module")]
        assert len(predict_spans) >= 2, (
            f"Expected at least 2 predict/module spans, got {len(predict_spans)}"
        )

        # At least 2 lm_call spans
        lm_spans = [s for s in spans if s["span_type"] == "lm_call"]
        assert len(lm_spans) >= 2, f"Expected at least 2 lm_call spans, got {len(lm_spans)}"

        # All spans reference valid parent_span_ids (except root)
        span_ids = {s["span_id"] for s in spans}
        for span in spans:
            parent_id = span.get("parent_span_id")
            if parent_id:
                assert parent_id in span_ids, (
                    f"Span {span['span_id']} references invalid parent {parent_id}"
                )
