"""LM call data accuracy tests.

Verify that LM call spans contain correct token counts, cost data,
and model attribution after running a simple DSPy Predict.
"""

from __future__ import annotations

import dspy
import pytest

from tests.e2e.conftest import flush_and_wait


pytestmark = pytest.mark.e2e


def _run_predict_and_get_trace(trace_capture, server_client):
    """Run a simple Predict and return the (trace, spans) from the server."""
    predict = dspy.Predict("question -> answer")
    predict(question="What is 2+2?")

    flush_and_wait()

    trace_id = trace_capture.last_trace_id
    assert trace_id is not None, "No trace was captured"

    data = server_client.get_trace(trace_id)
    return data["trace"], data["spans"]


def _find_lm_call_spans(spans: list[dict]) -> list[dict]:
    return [s for s in spans if s.get("span_type") == "lm_call"]


# ---------------------------------------------------------------------------
# Test classes
# ---------------------------------------------------------------------------


class TestTokenCounts:
    """LM_CALL spans must report accurate token counts."""

    def test_lm_call_has_positive_prompt_tokens(self, trace_capture, server_client):
        trace, spans = _run_predict_and_get_trace(trace_capture, server_client)
        lm_spans = _find_lm_call_spans(spans)
        assert len(lm_spans) > 0, "Expected at least one lm_call span"

        for span in lm_spans:
            assert span.get("prompt_tokens", 0) > 0

    def test_lm_call_has_positive_completion_tokens(self, trace_capture, server_client):
        trace, spans = _run_predict_and_get_trace(trace_capture, server_client)
        lm_spans = _find_lm_call_spans(spans)
        assert len(lm_spans) > 0

        for span in lm_spans:
            assert span.get("completion_tokens", 0) > 0

    def test_lm_call_has_positive_total_tokens(self, trace_capture, server_client):
        trace, spans = _run_predict_and_get_trace(trace_capture, server_client)
        lm_spans = _find_lm_call_spans(spans)
        assert len(lm_spans) > 0

        for span in lm_spans:
            assert span.get("total_tokens", 0) > 0

    def test_total_equals_prompt_plus_completion(self, trace_capture, server_client):
        trace, spans = _run_predict_and_get_trace(trace_capture, server_client)
        lm_spans = _find_lm_call_spans(spans)
        assert len(lm_spans) > 0

        for span in lm_spans:
            prompt = span.get("prompt_tokens", 0)
            completion = span.get("completion_tokens", 0)
            total = span.get("total_tokens", 0)
            assert total == prompt + completion, (
                f"total_tokens ({total}) != prompt ({prompt}) + completion ({completion})"
            )


class TestCostComputation:
    """Trace-level token aggregation must reflect LM call usage."""

    def test_trace_total_tokens_positive(self, trace_capture, server_client):
        trace, spans = _run_predict_and_get_trace(trace_capture, server_client)
        assert trace.get("total_tokens", 0) > 0


class TestModelAttribution:
    """LM_CALL spans must identify which model was used."""

    def test_lm_call_has_model_name(self, trace_capture, server_client):
        trace, spans = _run_predict_and_get_trace(trace_capture, server_client)
        lm_spans = _find_lm_call_spans(spans)
        assert len(lm_spans) > 0

        for span in lm_spans:
            model = span.get("model_name") or (span.get("attributes") or {}).get("model_name")
            assert model, f"lm_call span should have a non-empty model_name, got {model!r}"
