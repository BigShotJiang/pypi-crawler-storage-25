"""End-to-end test fixtures for the cmpnd SDK.

These tests run against a live Rails backend and require:
  - CMPND_E2E_API_KEY: API key for the test server
  - CMPND_E2E_GROQ_KEY: Groq API key for LLM calls
"""

from __future__ import annotations

import os
import time

import httpx
import pytest

import cmpnd
from cmpnd.exporter import BatchExporter, get_exporter, ensure_exporter_started, shutdown_exporter

# ---------------------------------------------------------------------------
# Environment configuration
# ---------------------------------------------------------------------------

E2E_ENDPOINT = "http://localhost:3000"
CMPND_E2E_API_KEY = os.getenv("CMPND_E2E_API_KEY")
CMPND_E2E_GROQ_KEY = os.getenv("CMPND_E2E_GROQ_KEY")
E2E_MODEL = "groq/meta-llama/llama-4-scout-17b-16e-instruct"

# ---------------------------------------------------------------------------
# Skip logic — skip entire module when env vars are missing
# ---------------------------------------------------------------------------

pytestmark = pytest.mark.e2e


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "e2e: end-to-end tests requiring a live server")


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    if not CMPND_E2E_API_KEY or not CMPND_E2E_GROQ_KEY:
        skip = pytest.mark.skip(reason="CMPND_E2E_API_KEY and CMPND_E2E_GROQ_KEY env vars required")
        for item in items:
            if "e2e" in item.keywords:
                item.add_marker(skip)


# ---------------------------------------------------------------------------
# TraceCapture — intercepts exported trace IDs
# ---------------------------------------------------------------------------


class TraceCapture:
    """Records trace IDs as they pass through the exporter."""

    def __init__(self) -> None:
        self.trace_ids: list[str] = []

    def reset(self) -> None:
        self.trace_ids.clear()

    @property
    def last_trace_id(self) -> str | None:
        return self.trace_ids[-1] if self.trace_ids else None


# Module-level instance shared across all tests
_trace_capture = TraceCapture()
_original_export_trace = BatchExporter.export_trace


def _patched_export_trace(exporter_self, trace):
    """Intercept export_trace to record trace_id, then delegate."""
    _trace_capture.trace_ids.append(str(trace.trace_id))
    return _original_export_trace(exporter_self, trace)


# Apply the monkey-patch at module level so it survives exporter restarts
BatchExporter.export_trace = _patched_export_trace


# ---------------------------------------------------------------------------
# Flush helper
# ---------------------------------------------------------------------------


def flush_and_wait(seconds: float = 3.0) -> None:
    """Force-flush the exporter queue and wait for server ingestion.

    Call this in test methods AFTER running DSPy programs and BEFORE
    querying the server API.
    """
    exporter = get_exporter()
    if exporter:
        # Wait for the background thread to drain the queue into its batch
        for _ in range(100):  # up to 10s
            if exporter._queue.empty():
                break
            time.sleep(0.1)
        # Wait for one flush cycle so the batch is actually POSTed
        time.sleep(max(getattr(exporter._config, "flush_interval_seconds", 1), 1) + 0.5)
    # shutdown_exporter() sets _exporter = None so ensure_exporter_started()
    # will create a fresh one for the next test.
    shutdown_exporter()
    ensure_exporter_started()
    # Give the server time to ingest
    time.sleep(seconds)


# ---------------------------------------------------------------------------
# ServerClient — thin wrapper around the Rails API
# ---------------------------------------------------------------------------


class ServerClient:
    """HTTP client for querying the Rails API during tests."""

    def __init__(self, endpoint: str, api_key: str) -> None:
        self._client = httpx.Client(
            base_url=endpoint,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    def close(self) -> None:
        self._client.close()

    # -- Traces -------------------------------------------------------------

    def get_trace(self, trace_id: str, retries: int = 3, delay: float = 2.0) -> dict:
        for attempt in range(retries):
            resp = self._client.get(f"/api/v1/traces/{trace_id}")
            if resp.status_code == 404 and attempt < retries - 1:
                time.sleep(delay)
                continue
            resp.raise_for_status()
            return resp.json()
        resp.raise_for_status()
        return resp.json()

    def search_traces(self, **filters) -> dict:
        resp = self._client.post("/api/v1/traces/search", json=filters)
        resp.raise_for_status()
        return resp.json()

    # -- Evals --------------------------------------------------------------

    def get_eval(self, eval_id: str) -> dict:
        resp = self._client.get(f"/api/v1/evals/{eval_id}")
        resp.raise_for_status()
        return resp.json()

    def search_evals(self, **filters) -> dict:
        resp = self._client.post("/api/v1/evals/search", json=filters)
        resp.raise_for_status()
        return resp.json()

    # -- Optimizations ------------------------------------------------------

    def get_optimization(self, opt_id: str) -> dict:
        resp = self._client.get(f"/api/v1/optimizations/{opt_id}")
        resp.raise_for_status()
        return resp.json()

    def search_optimizations(self, **filters) -> dict:
        resp = self._client.post("/api/v1/optimizations/search", json=filters)
        resp.raise_for_status()
        return resp.json()

    def get_optimization_iterations(self, opt_id: str) -> dict:
        resp = self._client.get(f"/api/v1/optimizations/{opt_id}/iterations")
        resp.raise_for_status()
        return resp.json()

    def get_optimization_candidates(self, opt_id: str) -> dict:
        resp = self._client.get(f"/api/v1/optimizations/{opt_id}/candidates")
        resp.raise_for_status()
        return resp.json()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def server_client() -> ServerClient:
    client = ServerClient(endpoint=E2E_ENDPOINT, api_key=CMPND_E2E_API_KEY or "")
    yield client
    client.close()


@pytest.fixture(scope="session")
def trace_capture() -> TraceCapture:
    return _trace_capture


@pytest.fixture(scope="session", autouse=True)
def configure_cmpnd_and_dspy():
    """Configure cmpnd + dspy for the entire test session."""
    import dspy

    cmpnd.configure(
        api_key=CMPND_E2E_API_KEY or "",
        endpoint=E2E_ENDPOINT,
        project="e2e-tests",
        flush_interval_seconds=1,
    )
    cmpnd.auto_instrument()

    lm = dspy.LM(E2E_MODEL, api_key=CMPND_E2E_GROQ_KEY or "", max_tokens=300, cache=False)
    dspy.configure(lm=lm)

    yield

    shutdown_exporter()
    # Restore original export_trace
    BatchExporter.export_trace = _original_export_trace


@pytest.fixture(autouse=True)
def reset_capture(trace_capture: TraceCapture):
    """Per-test fixture: reset trace capture before each test."""
    trace_capture.reset()
    yield
