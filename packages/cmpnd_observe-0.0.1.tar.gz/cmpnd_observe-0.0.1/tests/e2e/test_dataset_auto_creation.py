"""Dataset auto-creation tests.

Verify that running dspy.Evaluate and dspy.GEPA automatically creates
datasets in the backend with correct metadata, examples, and usages.
"""

from __future__ import annotations

import dspy
import pytest

from tests.e2e.conftest import E2E_MODEL, CMPND_E2E_GROQ_KEY, flush_and_wait


pytestmark = pytest.mark.e2e


# ---------------------------------------------------------------------------
# Test datasets — unique examples to avoid collisions with other tests
# ---------------------------------------------------------------------------

EVAL_DEVSET = [
    dspy.Example(city="Reykjavik", country="Iceland").with_inputs("city"),
    dspy.Example(city="Ulaanbaatar", country="Mongolia").with_inputs("city"),
    dspy.Example(city="Thimphu", country="Bhutan").with_inputs("city"),
]

OPT_TRAIN_SET = [
    dspy.Example(animal="axolotl", habitat="freshwater").with_inputs("animal"),
    dspy.Example(animal="pangolin", habitat="forest").with_inputs("animal"),
    dspy.Example(animal="narwhal", habitat="arctic ocean").with_inputs("animal"),
    dspy.Example(animal="quokka", habitat="island").with_inputs("animal"),
    dspy.Example(animal="tardigrade", habitat="everywhere").with_inputs("animal"),
]

OPT_VAL_SET = [
    dspy.Example(animal="capybara", habitat="wetland").with_inputs("animal"),
    dspy.Example(animal="okapi", habitat="rainforest").with_inputs("animal"),
    dspy.Example(animal="fossa", habitat="Madagascar").with_inputs("animal"),
]


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


def city_metric(gold, pred, trace=None):
    expected = gold.get("country") if hasattr(gold, "get") else getattr(gold, "country", "")
    actual = getattr(pred, "country", "")
    return 1.0 if str(expected).strip().lower() in str(actual).strip().lower() else 0.0


def animal_metric(gold, pred, trace=None, pred_name=None, pred_trace=None):
    expected = gold.get("habitat") if hasattr(gold, "get") else getattr(gold, "habitat", "")
    actual = getattr(pred, "habitat", "")
    return 1.0 if str(expected).strip().lower() in str(actual).strip().lower() else 0.0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def find_dataset_by_hash(server_client, dataset_hash: str) -> dict | None:
    """Look up a dataset by its hash via the check endpoint, then fetch it."""
    resp = server_client._client.get(f"/api/v1/datasets/check/{dataset_hash}")
    if resp.status_code != 200:
        return None
    data = resp.json()
    if not data.get("exists"):
        return None
    dataset_id = data["dataset_id"]
    resp = server_client._client.get(f"/api/v1/datasets/{dataset_id}")
    resp.raise_for_status()
    return resp.json()


def get_dataset_examples(server_client, dataset_id: str) -> list[dict]:
    """Fetch examples for a dataset."""
    resp = server_client._client.get(f"/api/v1/datasets/{dataset_id}/examples")
    resp.raise_for_status()
    return resp.json().get("examples", [])


def compute_expected_hash(devset: list) -> str:
    """Compute the expected dataset hash using the SDK's algorithm."""
    from cmpnd.identity import compute_valset_hash
    return compute_valset_hash(devset)


# ---------------------------------------------------------------------------
# Tests — Eval dataset auto-creation
# ---------------------------------------------------------------------------


class TestEvalDatasetCreation:

    def test_eval_creates_dataset(self, server_client):
        """Running dspy.Evaluate should auto-create a dataset in the backend."""
        program = dspy.Predict("city -> country")
        evaluator = dspy.Evaluate(devset=EVAL_DEVSET, metric=city_metric, num_threads=1)

        try:
            evaluator(program)
        except Exception:
            pass

        flush_and_wait(seconds=5)

        expected_hash = compute_expected_hash(EVAL_DEVSET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, (
            f"No dataset found with hash {expected_hash} after eval"
        )

    def test_eval_dataset_has_correct_fields(self, server_client):
        """Auto-created dataset should have correct input/output field classification."""
        expected_hash = compute_expected_hash(EVAL_DEVSET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, "Dataset not found — test_eval_creates_dataset must run first"
        assert "city" in dataset["input_fields"], (
            f"Expected 'city' in input_fields, got {dataset['input_fields']}"
        )
        assert "country" in dataset["output_fields"], (
            f"Expected 'country' in output_fields, got {dataset['output_fields']}"
        )

    def test_eval_dataset_has_examples(self, server_client):
        """Auto-created dataset should contain all devset examples."""
        expected_hash = compute_expected_hash(EVAL_DEVSET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, "Dataset not found"

        examples = get_dataset_examples(server_client, dataset["id"])
        assert len(examples) == len(EVAL_DEVSET), (
            f"Expected {len(EVAL_DEVSET)} examples, got {len(examples)}"
        )

    def test_eval_dataset_examples_have_correct_content(self, server_client):
        """Each example should have the right inputs and expected_outputs."""
        expected_hash = compute_expected_hash(EVAL_DEVSET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, "Dataset not found"

        examples = get_dataset_examples(server_client, dataset["id"])
        input_cities = {ex["inputs"]["city"] for ex in examples}
        expected_cities = {ex.city for ex in EVAL_DEVSET}
        assert input_cities == expected_cities, (
            f"Example cities don't match: {input_cities} vs {expected_cities}"
        )

    def test_second_eval_reuses_dataset(self, server_client):
        """Running the same eval again should not create a duplicate dataset."""
        program = dspy.Predict("city -> country")
        evaluator = dspy.Evaluate(devset=EVAL_DEVSET, metric=city_metric, num_threads=1)

        try:
            evaluator(program)
        except Exception:
            pass

        flush_and_wait(seconds=5)

        # Check that only one dataset with this hash exists
        expected_hash = compute_expected_hash(EVAL_DEVSET)
        resp = server_client._client.get("/api/v1/datasets")
        resp.raise_for_status()
        all_datasets = resp.json()["datasets"]
        matching = [d for d in all_datasets if d.get("name", "").endswith(expected_hash[:4])]
        assert len(matching) == 1, (
            f"Expected exactly 1 dataset with hash prefix, got {len(matching)}: "
            f"{[d['name'] for d in matching]}"
        )


# ---------------------------------------------------------------------------
# Tests — Optimization dataset auto-creation
# ---------------------------------------------------------------------------


class TestOptimizationDatasetCreation:

    def test_optimization_creates_dataset(self, server_client):
        """Running dspy.GEPA should auto-create a dataset from the valset."""
        student = dspy.Predict("animal -> habitat")
        reflection_lm = dspy.LM(
            E2E_MODEL, api_key=CMPND_E2E_GROQ_KEY or "", max_tokens=300, cache=False,
        )
        optimizer = dspy.GEPA(
            metric=animal_metric,
            max_metric_calls=15,
            num_threads=1,
            reflection_lm=reflection_lm,
        )

        try:
            optimizer.compile(student, trainset=OPT_TRAIN_SET, valset=OPT_VAL_SET)
        except Exception:
            pass

        flush_and_wait(seconds=5)

        expected_hash = compute_expected_hash(OPT_VAL_SET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, (
            f"No dataset found with hash {expected_hash} after optimization"
        )

    def test_optimization_dataset_has_correct_fields(self, server_client):
        """Optimization-created dataset should classify fields correctly."""
        expected_hash = compute_expected_hash(OPT_VAL_SET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, "Dataset not found"
        assert "animal" in dataset["input_fields"], (
            f"Expected 'animal' in input_fields, got {dataset['input_fields']}"
        )
        assert "habitat" in dataset["output_fields"], (
            f"Expected 'habitat' in output_fields, got {dataset['output_fields']}"
        )

    def test_optimization_dataset_has_examples(self, server_client):
        """Optimization-created dataset should contain all valset examples."""
        expected_hash = compute_expected_hash(OPT_VAL_SET)
        dataset = find_dataset_by_hash(server_client, expected_hash)

        assert dataset is not None, "Dataset not found"

        examples = get_dataset_examples(server_client, dataset["id"])
        assert len(examples) == len(OPT_VAL_SET), (
            f"Expected {len(OPT_VAL_SET)} examples, got {len(examples)}"
        )


# ---------------------------------------------------------------------------
# Tests — Hash consistency between eval and optimization paths
# ---------------------------------------------------------------------------


class TestHashConsistency:

    def test_same_dataset_same_hash_across_paths(self):
        """Eval and optimization paths should produce the same hash for the same dataset."""
        from cmpnd.identity import compute_valset_hash
        from cmpnd.callback import CmpndCallback

        shared_devset = [
            dspy.Example(question="What is AI?", answer="Artificial Intelligence").with_inputs("question"),
            dspy.Example(question="What is ML?", answer="Machine Learning").with_inputs("question"),
        ]

        # Optimization path hash
        opt_hash = compute_valset_hash(shared_devset)

        # Eval callback path hash (same function now)
        eval_hash = compute_valset_hash(shared_devset)

        assert opt_hash == eval_hash, (
            f"Hash mismatch between paths: opt={opt_hash}, eval={eval_hash}"
        )


# ---------------------------------------------------------------------------
# Tests — Pre-flight check
# ---------------------------------------------------------------------------


class TestPreflightCheck:

    def test_check_returns_exists_for_known_hash(self, server_client):
        """The check endpoint should return exists=true for a dataset we created."""
        expected_hash = compute_expected_hash(EVAL_DEVSET)
        resp = server_client._client.get(f"/api/v1/datasets/check/{expected_hash}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["exists"] is True
        assert data["dataset_id"] is not None

    def test_check_returns_not_exists_for_unknown_hash(self, server_client):
        """The check endpoint should return exists=false for an unknown hash."""
        resp = server_client._client.get("/api/v1/datasets/check/0000000000000000")
        assert resp.status_code == 200
        data = resp.json()
        assert data["exists"] is False
