"""Trace structure integrity tests.

Verify that traces have correct span hierarchies, valid timing,
proper error handling, and consistent signature hashes.
"""

from __future__ import annotations

import dspy
import pytest

from tests.e2e.conftest import flush_and_wait


pytestmark = pytest.mark.e2e


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fetch_trace(server_client, trace_capture):
    """Flush, then fetch the last captured trace and its spans."""
    flush_and_wait()
    trace_id = trace_capture.last_trace_id
    assert trace_id is not None, "No trace was captured"
    data = server_client.get_trace(trace_id)
    return data["trace"], data["spans"]


# ---------------------------------------------------------------------------
# 1. Span hierarchy
# ---------------------------------------------------------------------------


class TestSpanHierarchy:

    def test_single_root_span(self, server_client, trace_capture):
        predict = dspy.Predict("question -> answer")
        predict(question="What color is the sky?")

        trace, spans = _fetch_trace(server_client, trace_capture)

        root_spans = [
            s for s in spans
            if s.get("parent_span_id") is None or s.get("parent_span_id") == ""
        ]
        assert len(root_spans) == 1, f"Expected 1 root span, got {len(root_spans)}"

    def test_all_parents_exist(self, server_client, trace_capture):
        predict = dspy.Predict("question -> answer")
        predict(question="Name a prime number.")

        trace, spans = _fetch_trace(server_client, trace_capture)

        span_ids = {s["span_id"] for s in spans}
        for span in spans:
            parent_id = span.get("parent_span_id")
            if parent_id and parent_id != "":
                assert parent_id in span_ids, (
                    f"Span {span['span_id']} references missing parent {parent_id}"
                )


# ---------------------------------------------------------------------------
# 2. Trace timing
# ---------------------------------------------------------------------------


class TestTraceTiming:

    def test_trace_time_ordering(self, server_client, trace_capture):
        predict = dspy.Predict("question -> answer")
        predict(question="What is 2+2?")

        trace, spans = _fetch_trace(server_client, trace_capture)

        assert trace["start_time"] < trace["end_time"]

    def test_span_time_ordering(self, server_client, trace_capture):
        predict = dspy.Predict("question -> answer")
        predict(question="What is the capital of France?")

        trace, spans = _fetch_trace(server_client, trace_capture)

        for span in spans:
            start = span.get("start_time")
            end = span.get("end_time")
            assert start is not None and end is not None
            assert start <= end, f"Span {span['span_id']} start ({start}) > end ({end})"


# ---------------------------------------------------------------------------
# 3. Error trace
# ---------------------------------------------------------------------------


class TestErrorTrace:

    def test_error_trace_still_recorded(self, server_client, trace_capture):
        class BadOutput(dspy.Signature):
            """Return a nested dictionary — likely to cause parse issues."""
            question: str = dspy.InputField()
            result: dict = dspy.OutputField(desc="a dictionary with nested keys")

        predict = dspy.Predict(BadOutput)
        try:
            predict(question="Give me a complex nested dictionary with 10 keys.")
        except Exception:
            pass

        flush_and_wait()

        assert len(trace_capture.trace_ids) > 0, "No trace was captured"

        trace_id = trace_capture.last_trace_id
        data = server_client.get_trace(trace_id)
        trace = data["trace"]

        assert trace["status"] in ("ok", "error")


# ---------------------------------------------------------------------------
# 4. Signature hash consistency
# ---------------------------------------------------------------------------


class TestSignatureHashConsistency:

    def test_same_signature_same_hash(self, server_client, trace_capture):
        predict = dspy.Predict("city -> population_estimate")

        # First call
        predict(city="Tokyo")
        flush_and_wait()
        first_trace_id = trace_capture.trace_ids[0]
        first_data = server_client.get_trace(first_trace_id)
        first_hash = first_data["trace"]["signature_hash"]

        # Second call — different input, same signature
        predict(city="London")
        flush_and_wait()
        second_trace_id = trace_capture.trace_ids[1]
        second_data = server_client.get_trace(second_trace_id)
        second_hash = second_data["trace"]["signature_hash"]

        assert first_hash == second_hash, (
            f"Same signature produced different hashes: {first_hash} vs {second_hash}"
        )

    def test_signature_hash_not_zero(self, server_client, trace_capture):
        predict = dspy.Predict("topic -> summary")
        predict(topic="Machine learning")

        trace, _ = _fetch_trace(server_client, trace_capture)

        assert trace["signature_hash"] != 0
        assert trace["signature_hash"] is not None
