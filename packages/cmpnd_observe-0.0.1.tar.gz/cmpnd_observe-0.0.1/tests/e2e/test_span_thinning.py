"""E2E tests for span thinning — verify thinned spans on the server after a real DSPy call."""

from __future__ import annotations

import dspy
import pytest

from tests.e2e.conftest import flush_and_wait


pytestmark = pytest.mark.e2e


def _is_thinned(value) -> bool:
    """Return True if the value is None, empty dict, empty string dict, or missing."""
    return value is None or value == {} or value == "{}" or value == ""


def _run_predict_and_get_spans(trace_capture, server_client) -> list[dict]:
    """Run a simple Predict call, flush, and return spans from the server."""
    predict = dspy.Predict("question -> answer")
    predict(question="What is the capital of France?")

    flush_and_wait()

    trace_id = trace_capture.last_trace_id
    assert trace_id is not None, "No trace was captured"

    data = server_client.get_trace(trace_id)
    spans = data["spans"]
    assert len(spans) > 0, "No spans returned from server"
    return spans


class TestAdapterSpansThinned:

    def test_adapter_spans_have_empty_inputs_and_outputs(self, server_client, trace_capture):
        spans = _run_predict_and_get_spans(trace_capture, server_client)

        adapter_spans = [
            s for s in spans
            if s.get("span_type") in ("adapter_format", "adapter_parse")
        ]
        assert len(adapter_spans) > 0, (
            f"Expected adapter spans, got types: {[s.get('span_type') for s in spans]}"
        )

        for span in adapter_spans:
            assert _is_thinned(span.get("inputs")), (
                f"{span['span_type']} should have thinned inputs"
            )
            assert _is_thinned(span.get("outputs")), (
                f"{span['span_type']} should have thinned outputs"
            )


class TestLmCallThinned:

    def test_lm_call_inputs_thinned_outputs_preserved(self, server_client, trace_capture):
        spans = _run_predict_and_get_spans(trace_capture, server_client)

        lm_spans = [s for s in spans if s.get("span_type") == "lm_call"]
        assert len(lm_spans) > 0

        for span in lm_spans:
            assert _is_thinned(span.get("inputs")), "lm_call inputs should be thinned"
            assert not _is_thinned(span.get("outputs")), "lm_call outputs should be preserved"


class TestPredictNotThinned:

    def test_predict_spans_retain_inputs_and_outputs(self, server_client, trace_capture):
        spans = _run_predict_and_get_spans(trace_capture, server_client)

        predict_spans = [s for s in spans if s.get("span_type") == "predict"]
        assert len(predict_spans) > 0

        for span in predict_spans:
            assert not _is_thinned(span.get("inputs")), "predict inputs should NOT be thinned"
            assert not _is_thinned(span.get("outputs")), "predict outputs should NOT be thinned"
