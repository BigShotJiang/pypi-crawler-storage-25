"""Tests for trace/span context management."""

from uuid import uuid4

import pytest

from cmpnd.context import (
    clear_context,
    get_current_span,
    get_current_trace,
    pop_span,
    push_span,
    set_current_trace,
)
from cmpnd.models import SpanBuilder, TraceBuilder


class TestTraceContext:
    """Tests for trace context management."""

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()

    def test_get_current_trace_when_empty(self):
        """Test getting current trace when none set."""
        assert get_current_trace() is None

    def test_set_and_get_current_trace(self):
        """Test setting and getting current trace."""
        trace = TraceBuilder(trace_id=uuid4())
        set_current_trace(trace)

        assert get_current_trace() is trace

    def test_clear_current_trace(self):
        """Test clearing current trace."""
        trace = TraceBuilder(trace_id=uuid4())
        set_current_trace(trace)
        set_current_trace(None)

        assert get_current_trace() is None


class TestSpanContext:
    """Tests for span context management."""

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()

    def test_get_current_span_when_empty(self):
        """Test getting current span when none set."""
        assert get_current_span() is None

    def test_push_and_get_span(self):
        """Test pushing and getting span."""
        span = SpanBuilder(span_id=uuid4(), name="test")
        push_span(span)

        assert get_current_span() is span

    def test_push_multiple_spans(self):
        """Test pushing multiple spans creates stack."""
        span1 = SpanBuilder(span_id=uuid4(), name="span1")
        span2 = SpanBuilder(span_id=uuid4(), name="span2")
        span3 = SpanBuilder(span_id=uuid4(), name="span3")

        push_span(span1)
        push_span(span2)
        push_span(span3)

        # Current span should be the last pushed
        assert get_current_span() is span3

    def test_pop_span(self):
        """Test popping span from stack."""
        span1 = SpanBuilder(span_id=uuid4(), name="span1")
        span2 = SpanBuilder(span_id=uuid4(), name="span2")

        push_span(span1)
        push_span(span2)

        popped = pop_span()
        assert popped is span2
        assert get_current_span() is span1

    def test_pop_span_returns_none_when_empty(self):
        """Test popping from empty stack returns None."""
        assert pop_span() is None

    def test_span_stack_behavior(self):
        """Test full span stack LIFO behavior."""
        spans = [SpanBuilder(span_id=uuid4(), name=f"span{i}") for i in range(5)]

        for span in spans:
            push_span(span)

        # Pop in reverse order
        for span in reversed(spans):
            assert get_current_span() is span
            assert pop_span() is span

        assert get_current_span() is None


class TestClearContext:
    """Tests for clear_context function."""

    def test_clear_context_clears_trace(self):
        """Test clear_context clears trace."""
        set_current_trace(TraceBuilder(trace_id=uuid4()))
        clear_context()
        assert get_current_trace() is None

    def test_clear_context_clears_spans(self):
        """Test clear_context clears span stack."""
        push_span(SpanBuilder(span_id=uuid4(), name="test"))
        push_span(SpanBuilder(span_id=uuid4(), name="test2"))
        clear_context()
        assert get_current_span() is None
