"""Tests for trace stats fast path export."""

import json
from uuid import uuid4
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from cmpnd.models import TraceBuilder, TraceStatus


def test_stats_payload_structure():
    """Stats payload should be compact with only aggregate fields."""
    trace = TraceBuilder(
        trace_id=uuid4(),
        start_time=datetime.now(timezone.utc),
        signature_hash=12345,
        program_name="QAProgram",
        status=TraceStatus.OK,
        total_tokens=150,
        total_cost=0.003,
    )
    stats = trace.to_stats_dict()

    # Must have these fields
    assert "trace_id" in stats
    assert "timestamp" in stats
    assert "signature_hash" in stats
    assert stats["signature_hash"] == 12345
    assert "total_tokens" in stats
    assert stats["total_tokens"] == 150
    assert "total_cost" in stats
    assert abs(stats["total_cost"] - 0.003) < 0.0001
    assert "status" in stats
    assert stats["status"] == "ok"
    assert "program_name" in stats
    assert stats["program_name"] == "QAProgram"

    # Must NOT have heavy fields
    assert "spans" not in stats
    assert "request_preview" not in stats
    assert "response_preview" not in stats
    assert "signature_input_fields" not in stats
    assert "signature_output_fields" not in stats
    assert "tags" not in stats
    assert "metadata" not in stats

    # Should be small
    assert len(json.dumps(stats)) < 500


def test_stats_payload_includes_eval_and_opt_run_ids():
    eval_id = uuid4()
    opt_id = uuid4()
    trace = TraceBuilder(
        trace_id=uuid4(),
        start_time=datetime.now(timezone.utc),
        eval_run_id=eval_id,
        optimization_run_id=opt_id,
    )
    stats = trace.to_stats_dict()
    assert stats["eval_run_id"] == str(eval_id)
    assert stats["optimization_run_id"] == str(opt_id)


def test_stats_payload_none_ids():
    trace = TraceBuilder(
        trace_id=uuid4(),
        start_time=datetime.now(timezone.utc),
    )
    stats = trace.to_stats_dict()
    assert stats["eval_run_id"] is None
    assert stats["optimization_run_id"] is None


def test_stats_payload_includes_token_breakdown():
    """Stats payload should include prompt and completion token counts."""
    trace = TraceBuilder(
        trace_id=uuid4(),
        start_time=datetime.now(timezone.utc),
        total_tokens=250,
        prompt_tokens=100,
        completion_tokens=150,
    )
    stats = trace.to_stats_dict()
    assert stats["prompt_tokens"] == 100
    assert stats["completion_tokens"] == 150
    assert stats["total_tokens"] == 250


def test_stats_payload_span_count():
    """Stats payload should include span_count."""
    trace = TraceBuilder(
        trace_id=uuid4(),
        start_time=datetime.now(timezone.utc),
        span_count=5,
    )
    stats = trace.to_stats_dict()
    assert stats["span_count"] == 5


def test_export_trace_stats_enqueues():
    """export_trace_stats should enqueue a trace_stats item."""
    from cmpnd.exporter import BatchExporter
    from cmpnd.config import Config

    config = Config(
        api_key="test-key",
        endpoint="http://localhost:3000",
    )
    exporter = BatchExporter(config)
    trace = TraceBuilder(
        trace_id=uuid4(),
        start_time=datetime.now(timezone.utc),
    )
    exporter.export_trace_stats(trace)

    item = exporter._queue.get_nowait()
    assert item.item_type == "trace_stats"
    assert item.data is trace
