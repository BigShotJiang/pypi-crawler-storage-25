"""Tests for payload truncation in to_api_dict() methods."""

import json
from uuid import uuid4

from cmpnd.models import TraceBuilder, SpanBuilder, TraceStatus, SpanType


def test_request_preview_truncated():
    trace = TraceBuilder(trace_id=uuid4())
    trace.request_preview = "x" * 10000
    api_dict = trace.to_api_dict()
    assert len(api_dict["request_preview"]) == 500


def test_response_preview_truncated():
    trace = TraceBuilder(trace_id=uuid4())
    trace.response_preview = "y" * 10000
    api_dict = trace.to_api_dict()
    assert len(api_dict["response_preview"]) == 500


def test_short_preview_not_truncated():
    trace = TraceBuilder(trace_id=uuid4())
    trace.request_preview = "short"
    api_dict = trace.to_api_dict()
    assert api_dict["request_preview"] == "short"


def test_none_preview_safe():
    trace = TraceBuilder(trace_id=uuid4())
    trace.request_preview = None
    api_dict = trace.to_api_dict()
    assert api_dict["request_preview"] == ""


def test_span_large_inputs_truncated():
    span = SpanBuilder(span_id=uuid4(), name="test")
    span.inputs = {"question": "x" * 100000}
    api_dict = span.to_api_dict()
    assert isinstance(api_dict["inputs"], dict)
    assert api_dict["inputs"]["__truncated__"] is True
    assert "preview" in api_dict["inputs"]
    assert "size" in api_dict["inputs"]
    assert len(api_dict["inputs"]["preview"]) == 1000


def test_span_large_outputs_truncated():
    span = SpanBuilder(span_id=uuid4(), name="test")
    span.outputs = {"answer": "y" * 100000}
    api_dict = span.to_api_dict()
    assert isinstance(api_dict["outputs"], dict)
    assert api_dict["outputs"]["__truncated__"] is True
    assert "preview" in api_dict["outputs"]
    assert "size" in api_dict["outputs"]


def test_span_small_inputs_not_truncated():
    span = SpanBuilder(span_id=uuid4(), name="test")
    span.inputs = {"question": "What is 2+2?"}
    api_dict = span.to_api_dict()
    assert api_dict["inputs"]["question"] == "What is 2+2?"


def test_span_small_outputs_not_truncated():
    span = SpanBuilder(span_id=uuid4(), name="test")
    span.outputs = {"answer": "4"}
    api_dict = span.to_api_dict()
    assert api_dict["outputs"]["answer"] == "4"


def test_span_empty_inputs_not_truncated():
    span = SpanBuilder(span_id=uuid4(), name="test")
    span.inputs = {}
    api_dict = span.to_api_dict()
    assert api_dict["inputs"] == {}


def test_span_none_inputs_not_truncated():
    """If inputs serialize to None/falsy, no truncation should occur."""
    span = SpanBuilder(span_id=uuid4(), name="test")
    span.inputs = {}
    api_dict = span.to_api_dict()
    assert api_dict["inputs"] == {}


def test_truncation_preserves_other_span_fields():
    """Truncation should not affect non-input/output fields."""
    span = SpanBuilder(span_id=uuid4(), name="test_span")
    span.span_type = SpanType.LM_CALL
    span.model_name = "gpt-4"
    span.inputs = {"question": "x" * 100000}
    api_dict = span.to_api_dict()
    assert api_dict["name"] == "test_span"
    assert api_dict["span_type"] == "lm_call"
    assert api_dict["model_name"] == "gpt-4"


def test_truncation_preserves_other_trace_fields():
    """Truncation should not affect non-preview fields."""
    trace = TraceBuilder(trace_id=uuid4())
    trace.program_name = "my_program"
    trace.request_preview = "x" * 10000
    api_dict = trace.to_api_dict()
    assert api_dict["program_name"] == "my_program"
    assert len(api_dict["request_preview"]) == 500
