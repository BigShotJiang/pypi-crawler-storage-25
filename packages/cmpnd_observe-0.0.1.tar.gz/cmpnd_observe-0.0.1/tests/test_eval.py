"""Tests for evaluation lifecycle and eval-related callback behavior.

Covers:
1. Full eval lifecycle (on_evaluate_start → trace collection → on_evaluate_end)
2. Eval example input filtering (separating input vs output fields)
3. Last eval trace ID tracking (for GEPA callback pickup)
"""

from datetime import datetime, timezone
from unittest import mock
from uuid import uuid4

import pytest

from cmpnd.config import configure
from cmpnd.context import clear_context
from cmpnd.models import TraceBuilder

# Skip all tests if dspy is not installed
pytest.importorskip("dspy")


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

class MockExporter:
    """Captures everything the callback exports."""

    def __init__(self):
        self.traces = []
        self.spans = []
        self.trace_stats = []
        self.eval_runs = []

    def export_trace(self, trace):
        self.traces.append(trace)

    def export_span(self, span):
        self.spans.append(span)

    def export_trace_stats(self, trace):
        self.trace_stats.append(trace)

    def export_eval_run(self, eval_run):
        self.eval_runs.append(eval_run)


def _make_callback():
    from cmpnd.callback import CmpndCallback
    with mock.patch("cmpnd.callback.ensure_exporter_started"):
        return CmpndCallback()


def _make_mock_signature(input_fields, output_fields):
    """Create a mock DSPy signature with named input/output fields."""
    sig = mock.MagicMock()

    input_dict = {}
    for name in input_fields:
        field = mock.MagicMock()
        field.annotation = str
        field.json_schema_extra = {"desc": ""}
        input_dict[name] = field
    sig.input_fields = input_dict

    output_dict = {}
    for name in output_fields:
        field = mock.MagicMock()
        field.annotation = str
        field.json_schema_extra = {"desc": ""}
        output_dict[name] = field
    sig.output_fields = output_dict

    sig.__name__ = "TestSignature"
    sig.instructions = "Answer the question."

    return sig


def _make_mock_program(signature):
    """Create a mock DSPy program with a signature."""
    predictor = mock.MagicMock()
    predictor.signature = signature

    program = mock.MagicMock()
    program.__class__.__name__ = "TestProgram"
    program.predictors = mock.MagicMock(return_value=[("predict", predictor)])
    return program


# ---------------------------------------------------------------------------
# 1. Full eval lifecycle
# ---------------------------------------------------------------------------

class TestEvalLifecycle:
    """Pin the full on_evaluate_start → trace collection → on_evaluate_end flow.

    Note: DSPy Evaluate runs example traces in parallel threads, each with
    their own ContextVar state. In tests we simulate this by manually creating
    traces and adding them to callback._eval_traces, which is what the parallel
    threads do via on_module_end when _active_eval_run is set.
    """

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_full_eval_lifecycle(self):
        """Start eval, simulate trace collection, end eval — verify all outputs."""
        callback = _make_callback()
        exporter = MockExporter()
        sig = _make_mock_signature(["question"], ["answer"])
        program = _make_mock_program(sig)

        # Build mock examples and results
        examples = []
        predictions = []
        scores = [1.0, 0.0, 1.0]
        for i, score in enumerate(scores):
            ex = mock.MagicMock()
            ex.toDict.return_value = {"question": f"Q{i}", "answer": f"A{i}"}
            examples.append(ex)

            pred = mock.MagicMock()
            pred.toDict.return_value = {"answer": f"Predicted{i}"}
            predictions.append(pred)

        mock_devset = examples
        mock_metric = mock.MagicMock()
        mock_metric.__name__ = "exact_match"

        mock_outputs = mock.MagicMock()
        mock_outputs.score = 66.67
        mock_outputs.results = [
            (examples[i], predictions[i], scores[i]) for i in range(3)
        ]

        call_id = "eval_lifecycle_test"

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            # Start eval
            callback.on_evaluate_start(
                call_id=call_id,
                instance=mock.MagicMock(),
                inputs={
                    "program": program,
                    "devset": mock_devset,
                    "metric": mock_metric,
                },
            )

            # Simulate traces collected by parallel threads during eval.
            # In real DSPy, each thread's on_module_end appends to _eval_traces.
            eval_run = callback._eval_call_id_to_run[call_id]
            eval_run_id = str(eval_run.eval_run_id)
            traces = []
            for i in range(3):
                trace = TraceBuilder(
                    trace_id=uuid4(),
                    start_time=datetime.now(timezone.utc),
                    end_time=datetime.now(timezone.utc),
                    total_tokens=100 * (i + 1),
                    total_cost=0.001 * (i + 1),
                )
                traces.append(trace)
            callback._eval_traces[eval_run_id] = traces

            # End eval
            callback.on_evaluate_end(
                call_id=call_id,
                outputs=mock_outputs,
            )

        # --- Assertions ---

        assert len(exporter.eval_runs) == 1
        eval_run = exporter.eval_runs[0]

        # Program metadata
        assert eval_run.program_name == "TestProgram"
        assert eval_run.metric_name == "exact_match"
        assert eval_run.dataset_size == 3

        # Score and status
        assert eval_run.score == 66.67
        assert eval_run.status.value == "completed"

        # Per-example results
        assert len(eval_run._examples) == 3

        # First example: score=1.0, passed
        ex0 = eval_run._examples[0]
        assert ex0.inputs == {"question": "Q0"}
        assert ex0.expected_output == {"answer": "A0"}
        assert ex0.actual_output == {"answer": "Predicted0"}
        assert ex0.score == 100.0  # normalized to percentage
        assert ex0.passed is True

        # Second example: score=0.0, failed
        ex1 = eval_run._examples[1]
        assert ex1.score == 0.0
        assert ex1.passed is False

        # Example hashes computed
        for ex in eval_run._examples:
            assert ex.example_hash != ""

        # Trace IDs linked to examples (by index)
        for i, ex in enumerate(eval_run._examples):
            assert ex.trace_id == traces[i].trace_id

        # Last eval trace IDs populated for GEPA callback
        assert len(callback._last_eval_trace_ids) == 3
        for i, trace in enumerate(traces):
            assert trace.trace_id in callback._last_eval_trace_ids

        # Active eval run cleared
        assert callback._active_eval_run is None

    def test_eval_lifecycle_with_exception_hits_bug(self):
        """BUG: on_evaluate_end with exception crashes on UnboundLocalError.

        When on_evaluate_end receives an exception, the else block (which
        defines eval_traces) is skipped, but line 966 references eval_traces
        unconditionally. This test documents the bug so the refactor can fix it.
        """
        callback = _make_callback()
        exporter = MockExporter()
        sig = _make_mock_signature(["question"], ["answer"])
        program = _make_mock_program(sig)

        call_id = "eval_error_test"

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_evaluate_start(
                call_id=call_id,
                instance=mock.MagicMock(),
                inputs={"program": program, "devset": []},
            )

            # This crashes with UnboundLocalError because eval_traces is only
            # defined in the else branch but referenced unconditionally after
            with pytest.raises(UnboundLocalError):
                callback.on_evaluate_end(
                    call_id=call_id,
                    outputs=None,
                    exception=RuntimeError("eval crashed"),
                )

    def test_eval_signature_hash_computed(self):
        """Eval run gets signature_hash from the program's signature."""
        callback = _make_callback()
        exporter = MockExporter()
        sig = _make_mock_signature(["question", "context"], ["answer"])
        program = _make_mock_program(sig)

        call_id = "eval_hash_test"

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_evaluate_start(
                call_id=call_id,
                instance=mock.MagicMock(),
                inputs={"program": program, "devset": []},
            )
            callback.on_evaluate_end(
                call_id=call_id,
                outputs=mock.MagicMock(score=0.5, results=[]),
            )

        eval_run = exporter.eval_runs[0]
        # signature_hash should be a non-zero int (xxhash)
        assert eval_run.signature_hash is not None
        assert isinstance(eval_run.signature_hash, int)
        assert eval_run.signature_hash != 0

    def test_eval_dataset_hash_computed(self):
        """Eval run gets dataset_hash from the devset."""
        callback = _make_callback()
        exporter = MockExporter()
        sig = _make_mock_signature(["question"], ["answer"])
        program = _make_mock_program(sig)

        ex1 = mock.MagicMock()
        ex1.toDict.return_value = {"question": "Q1", "answer": "A1"}
        ex2 = mock.MagicMock()
        ex2.toDict.return_value = {"question": "Q2", "answer": "A2"}

        call_id = "eval_dataset_hash_test"

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_evaluate_start(
                call_id=call_id,
                instance=mock.MagicMock(),
                inputs={"program": program, "devset": [ex1, ex2]},
            )
            callback.on_evaluate_end(
                call_id=call_id,
                outputs=mock.MagicMock(score=0.5, results=[]),
            )

        eval_run = exporter.eval_runs[0]
        assert eval_run.dataset_hash is not None
        assert len(eval_run.dataset_hash) == 16  # SHA256[:16]


# ---------------------------------------------------------------------------
# 2. Eval example input filtering
# ---------------------------------------------------------------------------

class TestEvalExampleInputFiltering:
    """Tests for eval example input filtering to exclude output fields."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_eval_example_filters_output_fields(self):
        """Test that eval example inputs only include signature input fields."""
        import dspy

        callback = _make_callback()

        # Create a mock signature with input and output fields
        mock_signature = mock.MagicMock()
        mock_signature.input_fields = {
            "place_one": mock.MagicMock(),
            "place_two": mock.MagicMock(),
            "distance": mock.MagicMock(),
        }
        mock_signature.output_fields = {
            "match": mock.MagicMock(),
        }

        # Create mock program that returns the signature
        mock_program = mock.MagicMock()
        mock_program.__class__.__name__ = "TestProgram"
        mock_program.predictors = mock.MagicMock(
            return_value=[("predict", mock.MagicMock(signature=mock_signature))]
        )

        # Mock example with both input and output fields (like DSPy Example.toDict())
        mock_example = mock.MagicMock()
        mock_example.toDict.return_value = {
            "place_one": {"name": "Cafe A"},
            "place_two": {"name": "Cafe B"},
            "distance": 100,
            "match": True,  # This is an OUTPUT field, should be excluded from inputs
        }

        # Mock prediction
        mock_prediction = mock.MagicMock()
        mock_prediction.toDict.return_value = {"match": True}

        # Create mock outputs (EvaluationResult)
        mock_outputs = mock.MagicMock()
        mock_outputs.score = 1.0
        mock_outputs.results = [(mock_example, mock_prediction, 1.0)]

        call_id = "test_eval_call"

        # Mock context and exporter
        with mock.patch("cmpnd.callback.get_exporter") as mock_exporter, \
             mock.patch("cmpnd.callback.get_current_span", return_value=None), \
             mock.patch("cmpnd.callback.get_current_trace", return_value=None), \
             mock.patch("cmpnd.callback.push_span"), \
             mock.patch("cmpnd.callback.pop_span"), \
             mock.patch("cmpnd.callback.compute_signature_hash", return_value=12345):
            mock_exporter.return_value.export_eval_run = mock.MagicMock()
            mock_exporter.return_value.export_span = mock.MagicMock()

            # Start eval
            callback.on_evaluate_start(
                call_id=call_id,
                instance=mock.MagicMock(),
                inputs={"program": mock_program, "devset": [mock_example]},
            )

            # Verify signature input fields were captured
            assert call_id in callback._eval_signature_input_fields
            assert callback._eval_signature_input_fields[call_id] == {
                "place_one", "place_two", "distance"
            }

            # End eval
            callback.on_evaluate_end(
                call_id=call_id,
                outputs=mock_outputs,
            )

            # Get the exported eval run
            export_call = mock_exporter.return_value.export_eval_run.call_args
            eval_run = export_call[0][0]

            # Verify the example was processed
            assert len(eval_run._examples) == 1
            example_result = eval_run._examples[0]

            # Verify inputs only contains input fields (NOT "match")
            assert "place_one" in example_result.inputs
            assert "place_two" in example_result.inputs
            assert "distance" in example_result.inputs
            assert "match" not in example_result.inputs  # Should be excluded!

            # Verify expected_output contains the output field
            assert example_result.expected_output == {"match": True}

    def test_eval_example_no_signature_fallback(self):
        """Test that without signature, all fields are stored as inputs."""
        import dspy

        callback = _make_callback()

        # Create mock program WITHOUT signature
        mock_program = mock.MagicMock()
        mock_program.__class__.__name__ = "TestProgram"
        mock_program.predictors = mock.MagicMock(return_value=[])  # No predictors
        mock_program.signature = None  # No direct signature

        # Mock example with all fields
        mock_example = mock.MagicMock()
        mock_example.toDict.return_value = {
            "question": "What is 2+2?",
            "answer": "4",  # Normally an output, but no signature to tell us
        }

        mock_prediction = mock.MagicMock()
        mock_prediction.toDict.return_value = {"answer": "4"}

        mock_outputs = mock.MagicMock()
        mock_outputs.score = 1.0
        mock_outputs.results = [(mock_example, mock_prediction, 1.0)]

        call_id = "test_eval_call_no_sig"

        with mock.patch("cmpnd.callback.get_exporter") as mock_exporter, \
             mock.patch("cmpnd.callback.get_current_span", return_value=None), \
             mock.patch("cmpnd.callback.get_current_trace", return_value=None), \
             mock.patch("cmpnd.callback.push_span"), \
             mock.patch("cmpnd.callback.pop_span"):
            mock_exporter.return_value.export_eval_run = mock.MagicMock()
            mock_exporter.return_value.export_span = mock.MagicMock()

            callback.on_evaluate_start(
                call_id=call_id,
                instance=mock.MagicMock(),
                inputs={"program": mock_program, "devset": [mock_example]},
            )

            # No signature, so no input fields captured
            assert call_id not in callback._eval_signature_input_fields

            callback.on_evaluate_end(call_id=call_id, outputs=mock_outputs)

            export_call = mock_exporter.return_value.export_eval_run.call_args
            eval_run = export_call[0][0]

            example_result = eval_run._examples[0]

            # Without signature, all fields go to inputs (fallback behavior)
            assert "question" in example_result.inputs
            assert "answer" in example_result.inputs


# ---------------------------------------------------------------------------
# 3. Last eval trace ID tracking
# ---------------------------------------------------------------------------

class TestLastEvalTraceIds:
    """Test that callback stores last eval trace IDs for tracker pickup."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_last_eval_trace_ids_initialized_empty(self):
        from cmpnd.callback import CmpndCallback

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        assert callback._last_eval_trace_ids == []

    def test_last_eval_trace_ids_populated_after_eval_end(self):
        """After on_evaluate_end, _last_eval_trace_ids should contain trace IDs."""
        from cmpnd.callback import CmpndCallback
        from cmpnd.models import EvalRunBuilder

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        # Simulate an eval run with collected traces
        eval_run = EvalRunBuilder(
            eval_run_id=uuid4(),
            start_time=datetime.now(timezone.utc),
        )
        eval_run_id = str(eval_run.eval_run_id)
        callback._eval_call_id_to_run["eval_call_1"] = eval_run
        callback._active_eval_run = eval_run

        # Simulate two traces collected during eval
        trace1 = TraceBuilder(trace_id=uuid4(), start_time=datetime.now(timezone.utc))
        trace2 = TraceBuilder(trace_id=uuid4(), start_time=datetime.now(timezone.utc))
        callback._eval_traces[eval_run_id] = [trace1, trace2]

        mock_exporter = mock.MagicMock()
        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_evaluate_end(
                call_id="eval_call_1",
                outputs=0.85,  # overall score
            )

        assert len(callback._last_eval_trace_ids) == 2
        assert trace1.trace_id in callback._last_eval_trace_ids
        assert trace2.trace_id in callback._last_eval_trace_ids
