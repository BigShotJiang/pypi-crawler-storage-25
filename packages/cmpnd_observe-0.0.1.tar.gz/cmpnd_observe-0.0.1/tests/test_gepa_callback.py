"""Tests for GEPA callback timing: validate that CmpndCallback._last_eval_trace_ids
is populated by the time a GEPA callback's on_evaluation_end fires.

This is the critical timing validation for migrating TrackedGEPA's monkey-patched
evaluate() to use GEPA's native GEPACallback protocol.

The callback ordering is:
1. CmpndCallback (DSPy callback) sets _last_eval_trace_ids during on_evaluate_end,
   which fires DURING DspyAdapter.evaluate()
2. GEPA's on_evaluation_end fires AFTER evaluate() returns
3. Therefore trace IDs should be available when a GEPA callback reads them
"""

from unittest import mock
from uuid import UUID, uuid4

import pytest

from cmpnd.config import configure
from cmpnd.context import clear_context

# Skip all tests if dspy is not installed
pytest.importorskip("dspy")


def _make_callback():
    """Create a CmpndCallback with exporter mocked out."""
    from cmpnd.callback import CmpndCallback

    with mock.patch("cmpnd.callback.ensure_exporter_started"):
        return CmpndCallback()


def _read_and_clear_trace_ids(callbacks: list) -> list[UUID]:
    """Reproduce the read-and-clear pattern from gepa.py lines 414-421.

    This is the exact pattern that a GEPA callback's on_evaluation_end
    would use to retrieve eval trace IDs from CmpndCallback.
    """
    eval_trace_ids: list[UUID] = []
    for cb in callbacks:
        if hasattr(cb, "_last_eval_trace_ids"):
            eval_trace_ids = cb._last_eval_trace_ids
            cb._last_eval_trace_ids = []
            break
    return eval_trace_ids


class TestEvalTraceIdTiming:
    """Validate that _last_eval_trace_ids can be read from CmpndCallback
    via dspy.settings.callbacks, simulating the GEPA callback timing."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()
        # Reset dspy callbacks
        import dspy
        dspy.configure(callbacks=[])

    def test_read_trace_ids_from_dspy_settings(self):
        """_last_eval_trace_ids can be read from CmpndCallback via dspy.settings.callbacks."""
        import dspy

        callback = _make_callback()
        dspy.configure(callbacks=[callback])

        # Simulate CmpndCallback setting trace IDs during on_evaluate_end
        trace_ids = [uuid4(), uuid4(), uuid4()]
        callback._last_eval_trace_ids = trace_ids

        # Simulate GEPA callback reading from dspy.settings.callbacks
        # (this is what on_evaluation_end would do)
        found_ids = _read_and_clear_trace_ids(dspy.settings.callbacks)

        assert found_ids == trace_ids
        # After read-and-clear, the callback's list should be empty
        assert callback._last_eval_trace_ids == []

    def test_no_cmpnd_callback_returns_empty(self):
        """When no CmpndCallback is registered, reading trace IDs returns empty list."""
        import dspy

        # Register some other callback that doesn't have _last_eval_trace_ids
        class OtherCallback:
            pass

        dspy.configure(callbacks=[OtherCallback()])

        found_ids = _read_and_clear_trace_ids(dspy.settings.callbacks)
        assert found_ids == []

    def test_no_callbacks_returns_empty(self):
        """When no callbacks are registered at all, returns empty list."""
        import dspy

        dspy.configure(callbacks=[])

        found_ids = _read_and_clear_trace_ids(dspy.settings.callbacks)
        assert found_ids == []

    def test_read_and_clear_pattern(self):
        """The read-and-clear pattern works: read IDs, verify cleared, second read empty."""
        callback = _make_callback()

        # Set trace IDs (simulating on_evaluate_end)
        trace_ids = [uuid4(), uuid4()]
        callback._last_eval_trace_ids = trace_ids

        # First read-and-clear
        first_read = _read_and_clear_trace_ids([callback])
        assert first_read == trace_ids
        assert callback._last_eval_trace_ids == []

        # Second read should return empty
        second_read = _read_and_clear_trace_ids([callback])
        assert second_read == []

    def test_callback_ordering_simulation(self):
        """Simulate the full callback ordering:
        1. CmpndCallback.on_evaluate_end sets _last_eval_trace_ids (during evaluate())
        2. evaluate() returns
        3. GEPA's on_evaluation_end reads the trace IDs

        This validates that the IDs survive between steps 1 and 3.
        """
        import dspy

        callback = _make_callback()
        dspy.configure(callbacks=[callback])

        # Step 1: CmpndCallback sets trace IDs (simulating on_evaluate_end)
        trace_ids = [uuid4(), uuid4(), uuid4()]
        callback._last_eval_trace_ids = trace_ids

        # Step 2: evaluate() returns (no-op, just conceptual)

        # Step 3: GEPA's on_evaluation_end fires and reads via dspy.settings
        # This simulates what CmpndGEPACallback.on_evaluation_end would do
        captured_ids = []
        for cb in dspy.settings.callbacks:
            if hasattr(cb, "_last_eval_trace_ids"):
                captured_ids = cb._last_eval_trace_ids
                cb._last_eval_trace_ids = []
                break

        assert captured_ids == trace_ids
        assert callback._last_eval_trace_ids == []

    def test_multiple_evaluations_overwrite(self):
        """Each evaluation overwrites the previous trace IDs.

        This confirms that if on_evaluation_end doesn't read before the next
        evaluation, the old IDs are lost (expected behavior).
        """
        callback = _make_callback()

        # First evaluation sets IDs
        first_ids = [uuid4()]
        callback._last_eval_trace_ids = first_ids

        # Second evaluation overwrites without reading first
        second_ids = [uuid4(), uuid4()]
        callback._last_eval_trace_ids = second_ids

        # Reader gets only the second set
        found_ids = _read_and_clear_trace_ids([callback])
        assert found_ids == second_ids

    def test_cmpnd_callback_found_among_multiple_callbacks(self):
        """CmpndCallback is found even when mixed with other callbacks."""
        import dspy

        class BeforeCallback:
            pass

        class AfterCallback:
            pass

        callback = _make_callback()
        dspy.configure(callbacks=[BeforeCallback(), callback, AfterCallback()])

        trace_ids = [uuid4()]
        callback._last_eval_trace_ids = trace_ids

        found_ids = _read_and_clear_trace_ids(dspy.settings.callbacks)
        assert found_ids == trace_ids


# ---------------------------------------------------------------------------
# Tests for CmpndGEPACallback
# ---------------------------------------------------------------------------

from cmpnd.context import get_current_optimization_run_id, set_current_optimization_run_id
from cmpnd.optimizers.gepa_callback import CmpndGEPACallback
from cmpnd.optimizers.tracker import CandidateData, OptimizationTracker


def _make_tracker(**kwargs) -> OptimizationTracker:
    """Create a tracker with exporter mocked out."""
    defaults = dict(
        optimizer_type="GEPA",
        program_name="TestProgram",
    )
    defaults.update(kwargs)
    tracker = OptimizationTracker(**defaults)
    return tracker


class _FakeGEPAState:
    """Minimal fake GEPAState for testing on_optimization_end extraction."""

    def __init__(
        self,
        program_candidates=None,
        parent_program_for_candidate=None,
        prog_candidate_objective_scores=None,
        prog_candidate_val_subscores=None,
        num_metric_calls_by_discovery=None,
        program_at_pareto_front_valset=None,
    ):
        self.program_candidates = program_candidates or []
        self.parent_program_for_candidate = parent_program_for_candidate or []
        self.prog_candidate_objective_scores = prog_candidate_objective_scores or []
        self.prog_candidate_val_subscores = prog_candidate_val_subscores or []
        self.num_metric_calls_by_discovery = num_metric_calls_by_discovery or []
        self.program_at_pareto_front_valset = program_at_pareto_front_valset or {}


class TestCmpndGEPACallbackOptimizationStart:
    """Tests for on_optimization_start."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_sets_optimization_context(self):
        """on_optimization_start sets the optimization run ID context."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "start"):
            cb.on_optimization_start({
                "seed_candidate": {"module": "initial instructions"},
                "trainset_size": 100,
                "valset_size": 50,
                "config": {},
            })

        assert get_current_optimization_run_id() == tracker.optimization_run_id

    def test_calls_tracker_start(self):
        """on_optimization_start calls tracker.start()."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "start") as mock_start:
            cb.on_optimization_start({
                "seed_candidate": {},
                "trainset_size": 10,
                "valset_size": 5,
                "config": {},
            })

        mock_start.assert_called_once()

    def test_extracts_max_metric_calls_from_dict_config(self):
        """on_optimization_start extracts max_metric_calls from dict config."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "start"):
            cb.on_optimization_start({
                "seed_candidate": {},
                "trainset_size": 10,
                "valset_size": 5,
                "config": {"max_metric_calls": 500},
            })

        assert tracker.max_metric_calls == 500

    def test_extracts_max_metric_calls_from_object_config(self):
        """on_optimization_start extracts max_metric_calls from config object."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        class FakeConfig:
            max_metric_calls = 300

        with mock.patch.object(tracker, "start"):
            cb.on_optimization_start({
                "seed_candidate": {},
                "trainset_size": 10,
                "valset_size": 5,
                "config": FakeConfig(),
            })

        assert tracker.max_metric_calls == 300


class TestCmpndGEPACallbackEvaluationEnd:
    """Tests for on_evaluation_end."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_captures_evaluation(self):
        """on_evaluation_end captures evaluation data on the tracker."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        cb.on_evaluation_end({
            "iteration": 1,
            "candidate_idx": 2,
            "scores": [0.8, 0.9, 0.7],
            "has_trajectories": True,
            "parent_ids": [],
            "outputs": [],
            "trajectories": [],
            "objective_scores": [],
            "is_seed_candidate": False,
        })

        assert len(tracker.iterations) == 1
        assert tracker.iterations[0].iteration == 1
        assert tracker.iterations[0].candidate_idx == 2
        assert tracker.iterations[0].eval_scores == [0.8, 0.9, 0.7]
        assert tracker.iterations[0].eval_batch_size == 3

    def test_candidate_idx_none_defaults_to_zero(self):
        """When candidate_idx is None (seed eval), defaults to 0."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        cb.on_evaluation_end({
            "iteration": 0,
            "candidate_idx": None,
            "scores": [0.5],
            "has_trajectories": False,
            "is_seed_candidate": True,
        })

        assert tracker.iterations[0].candidate_idx == 0

    def test_reads_eval_trace_ids(self):
        """on_evaluation_end reads trace IDs from CmpndCallback."""
        import dspy

        cmpnd_cb = _make_callback()
        dspy.configure(callbacks=[cmpnd_cb])

        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        # Simulate CmpndCallback having set trace IDs
        trace_ids = [uuid4(), uuid4()]
        cmpnd_cb._last_eval_trace_ids = trace_ids

        cb.on_evaluation_end({
            "iteration": 0,
            "candidate_idx": 0,
            "scores": [1.0],
            "has_trajectories": False,
        })

        assert tracker.iterations[0].eval_trace_ids == trace_ids
        # Verify they were cleared
        assert cmpnd_cb._last_eval_trace_ids == []

        # Cleanup
        dspy.configure(callbacks=[])


class TestCmpndGEPACallbackReflectiveDataset:
    """Tests for on_reflective_dataset_built."""

    def test_captures_reflective_dataset(self):
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        # First create an iteration via evaluation
        cb.on_evaluation_end({
            "iteration": 1,
            "candidate_idx": 0,
            "scores": [0.5],
            "has_trajectories": False,
        })

        dataset = {
            "module": [
                {"Inputs": "hello", "Generated_Outputs": "world", "Feedback": "good"},
            ]
        }

        cb.on_reflective_dataset_built({
            "iteration": 1,
            "candidate_idx": 0,
            "components": ["module"],
            "dataset": dataset,
        })

        assert tracker.iterations[0].reflective_dataset == dataset
        assert tracker.iterations[0].components_updated == ["module"]

    def test_deep_copies_dataset(self):
        """Dataset is deep-copied so mutations don't affect tracker."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        cb.on_evaluation_end({
            "iteration": 1,
            "candidate_idx": 0,
            "scores": [0.5],
            "has_trajectories": False,
        })

        dataset = {"module": [{"key": "value"}]}
        cb.on_reflective_dataset_built({
            "iteration": 1,
            "candidate_idx": 0,
            "components": ["module"],
            "dataset": dataset,
        })

        # Mutate original - should not affect tracker
        dataset["module"][0]["key"] = "mutated"
        assert tracker.iterations[0].reflective_dataset["module"][0]["key"] == "value"


class TestCmpndGEPACallbackProposals:
    """Tests for on_proposal_start and on_proposal_end."""

    def test_captures_proposal_lifecycle(self):
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        # Create iteration
        cb.on_evaluation_end({
            "iteration": 1,
            "candidate_idx": 0,
            "scores": [0.5],
            "has_trajectories": False,
        })

        parent = {"module": "original instruction"}
        cb.on_proposal_start({
            "iteration": 1,
            "parent_candidate": parent,
            "components": ["module"],
            "reflective_dataset": {},
        })

        assert tracker.iterations[0].parent_instructions == parent

        new_instructions = {"module": "improved instruction"}
        cb.on_proposal_end({
            "iteration": 1,
            "new_instructions": new_instructions,
        })

        assert tracker.iterations[0].proposed_instructions == new_instructions


class TestCmpndGEPACallbackBudget:
    """Tests for on_budget_updated."""

    def test_updates_metric_calls(self):
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "send_progress_update"):
            cb.on_budget_updated({
                "iteration": 1,
                "metric_calls_used": 50,
                "metric_calls_delta": 10,
                "metric_calls_remaining": 450,
            })

        assert tracker.current_metric_calls == 50
        assert tracker.max_metric_calls == 500  # 50 + 450

    def test_sends_progress_update(self):
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "send_progress_update") as mock_progress:
            cb.on_budget_updated({
                "iteration": 1,
                "metric_calls_used": 25,
                "metric_calls_delta": 5,
                "metric_calls_remaining": 75,
            })

        mock_progress.assert_called_once()

    def test_handles_none_remaining(self):
        """When metric_calls_remaining is None, max_metric_calls is not updated."""
        tracker = _make_tracker()
        tracker.max_metric_calls = 1000  # Pre-set
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "send_progress_update"):
            cb.on_budget_updated({
                "iteration": 1,
                "metric_calls_used": 50,
                "metric_calls_delta": 10,
                "metric_calls_remaining": None,
            })

        assert tracker.current_metric_calls == 50
        assert tracker.max_metric_calls == 1000  # Unchanged


class TestCmpndGEPACallbackOptimizationEnd:
    """Tests for on_optimization_end."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_extracts_candidates_from_state(self):
        """on_optimization_end extracts candidates from GEPAState."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        state = _FakeGEPAState(
            program_candidates=[
                {"module": "seed instruction"},
                {"module": "improved instruction"},
            ],
            parent_program_for_candidate=[
                [None],
                [0],
            ],
            prog_candidate_objective_scores=[
                {"accuracy": 0.7},
                {"accuracy": 0.9},
            ],
            prog_candidate_val_subscores=[
                {"ex1": 0.6, "ex2": 0.8},
                {"ex1": 0.9, "ex2": 0.9},
            ],
            num_metric_calls_by_discovery=[0, 50],
            program_at_pareto_front_valset={
                "ex1": {1},
                "ex2": {1},
            },
        )

        with mock.patch.object(tracker, "finalize"):
            cb.on_optimization_end({
                "best_candidate_idx": 1,
                "total_iterations": 5,
                "total_metric_calls": 100,
                "final_state": state,
            })

        assert len(tracker.candidates) == 2
        assert tracker.candidates[0].instructions == {"module": "seed instruction"}
        assert tracker.candidates[0].parent_idx is None
        assert tracker.candidates[0].discovery_iteration == 0
        assert tracker.candidates[0].val_aggregate_score == 0.7
        assert tracker.candidates[0].is_pareto_member is False

        assert tracker.candidates[1].instructions == {"module": "improved instruction"}
        assert tracker.candidates[1].parent_idx == 0
        assert tracker.candidates[1].discovery_iteration == 50
        assert tracker.candidates[1].val_aggregate_score == 0.9
        assert tracker.candidates[1].is_pareto_member is True

    def test_sets_best_candidate_and_score(self):
        """on_optimization_end sets best_candidate_idx and best_score."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        state = _FakeGEPAState(
            program_candidates=[{"m": "a"}, {"m": "b"}],
            prog_candidate_objective_scores=[{"acc": 0.6}, {"acc": 0.95}],
        )

        with mock.patch.object(tracker, "finalize"):
            cb.on_optimization_end({
                "best_candidate_idx": 1,
                "total_iterations": 3,
                "total_metric_calls": 80,
                "final_state": state,
            })

        assert tracker.best_candidate_idx == 1
        assert tracker.best_score == 0.95
        assert tracker.total_metric_calls == 80

    def test_clears_optimization_context(self):
        """on_optimization_end clears the optimization run ID context."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        # Set context first
        set_current_optimization_run_id(tracker.optimization_run_id)
        assert get_current_optimization_run_id() is not None

        with mock.patch.object(tracker, "finalize"):
            cb.on_optimization_end({
                "best_candidate_idx": 0,
                "total_iterations": 1,
                "total_metric_calls": 10,
                "final_state": _FakeGEPAState(),
            })

        assert get_current_optimization_run_id() is None

    def test_calls_finalize_by_default(self):
        """on_optimization_end calls tracker.finalize() when defer_finalize=False."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker, defer_finalize=False)

        with mock.patch.object(tracker, "finalize") as mock_finalize:
            cb.on_optimization_end({
                "best_candidate_idx": 0,
                "total_iterations": 1,
                "total_metric_calls": 10,
                "final_state": _FakeGEPAState(),
            })

        mock_finalize.assert_called_once()

    def test_defers_finalize(self):
        """on_optimization_end skips finalize when defer_finalize=True."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker, defer_finalize=True)

        with mock.patch.object(tracker, "finalize") as mock_finalize:
            cb.on_optimization_end({
                "best_candidate_idx": 0,
                "total_iterations": 1,
                "total_metric_calls": 10,
                "final_state": _FakeGEPAState(),
            })

        mock_finalize.assert_not_called()

    def test_handles_no_final_state(self):
        """on_optimization_end works when final_state is None."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        with mock.patch.object(tracker, "finalize"):
            cb.on_optimization_end({
                "best_candidate_idx": 0,
                "total_iterations": 1,
                "total_metric_calls": 10,
                "final_state": None,
            })

        assert len(tracker.candidates) == 0
        assert tracker.best_candidate_idx == 0

    def test_pareto_frontier_extracted(self):
        """Pareto frontier members are correctly identified from GEPAState."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        state = _FakeGEPAState(
            program_candidates=[{"m": "a"}, {"m": "b"}, {"m": "c"}],
            prog_candidate_objective_scores=[{"acc": 0.5}, {"acc": 0.8}, {"acc": 0.7}],
            program_at_pareto_front_valset={
                "ex1": {0, 1},
                "ex2": {1, 2},
            },
        )

        with mock.patch.object(tracker, "finalize"):
            cb.on_optimization_end({
                "best_candidate_idx": 1,
                "total_iterations": 3,
                "total_metric_calls": 60,
                "final_state": state,
            })

        assert set(tracker.pareto_frontier) == {0, 1, 2}
        assert tracker.candidates[0].is_pareto_member is True
        assert tracker.candidates[1].is_pareto_member is True
        assert tracker.candidates[2].is_pareto_member is True


class TestCmpndGEPACallbackError:
    """Tests for on_error."""

    def test_fatal_error_sets_tracker_error(self):
        """on_error with will_continue=False sets error on tracker."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        exc = ValueError("something broke")
        cb.on_error({
            "iteration": 3,
            "exception": exc,
            "will_continue": False,
        })

        assert tracker.status == "failed"
        assert "something broke" in tracker.error_message

    def test_recoverable_error_does_not_fail_tracker(self):
        """on_error with will_continue=True does not set error."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        cb.on_error({
            "iteration": 2,
            "exception": RuntimeError("transient"),
            "will_continue": True,
        })

        assert tracker.status == "running"
        assert tracker.error_message is None

    def test_fatal_error_with_no_exception(self):
        """on_error with will_continue=False and no exception creates RuntimeError."""
        tracker = _make_tracker()
        cb = CmpndGEPACallback(tracker)

        cb.on_error({
            "iteration": 5,
            "exception": None,
            "will_continue": False,
        })

        assert tracker.status == "failed"
        assert tracker.error_message is not None


class TestDoubleFinalize:
    """Verify that calling finalize() twice is safe."""

    def test_finalize_called_twice_exports_once(self):
        """Calling finalize() twice should not export twice or error."""
        tracker = OptimizationTracker(
            optimizer_type="GEPA",
            program_name="TestProgram",
        )
        tracker._started = True

        with mock.patch("cmpnd.exporter.get_exporter") as mock_get:
            mock_exporter = mock.MagicMock()
            mock_get.return_value = mock_exporter

            tracker.finalize()
            tracker.finalize()

            assert mock_exporter.export_optimization_complete.call_count == 1


# ---------------------------------------------------------------------------
# Tests for auto_instrument() GEPA patching
# ---------------------------------------------------------------------------


class _FakeSignature:
    """Minimal fake DSPy signature."""

    def __init__(self, inputs, outputs):
        self.input_fields = inputs
        self.output_fields = outputs
        self.instructions = ""


class _FakeFieldInfo:
    """Minimal fake DSPy field info."""

    def __init__(self, annotation=str):
        self.annotation = annotation


class _FakePredictor:
    """Minimal fake DSPy predictor."""

    def __init__(self, sig):
        self.signature = sig


class _FakeStudent:
    """Minimal fake DSPy module for testing compile enrichment."""

    def __init__(self):
        self.signature = _FakeSignature(
            inputs={"question": _FakeFieldInfo()},
            outputs={"answer": _FakeFieldInfo()},
        )
        self._predictors = [("predict", _FakePredictor(self.signature))]

    def named_predictors(self):
        return iter(self._predictors)

    def dump_state(self, json_mode=False):
        return {"predict": {"signature": "question -> answer"}}


class _FakeLM:
    """Minimal fake LM."""

    def __init__(self, model_name="openai/gpt-4o"):
        self.model = model_name


def _save_gepa_originals():
    """Save original GEPA methods for restoration."""
    import dspy
    return dspy.GEPA.__init__, dspy.GEPA.compile


def _restore_gepa_originals(saved):
    """Restore original GEPA methods."""
    import dspy
    dspy.GEPA.__init__, dspy.GEPA.compile = saved
    # Also clean up _cmpnd_original_* attributes if present
    for attr in ("_cmpnd_original_init", "_cmpnd_original_compile"):
        try:
            delattr(dspy.GEPA, attr)
        except AttributeError:
            pass


def _make_fake_gepa_init():
    """Create a fake GEPA.__init__ that sets expected attributes without requiring metric."""
    def fake_init(self, *args, **kwargs):
        self.auto = kwargs.get("auto")
        self.max_metric_calls = kwargs.get("max_metric_calls")
        self.max_full_evals = kwargs.get("max_full_evals")
        self.seed = kwargs.get("seed")
        self.log_dir = kwargs.get("log_dir")
        self.reflection_lm = kwargs.get("reflection_lm")
        self.gepa_kwargs = kwargs.get("gepa_kwargs") or {}
    return fake_init


class TestAutoInstrumentPatchesGEPA:
    """Tests for _patch_gepa() called from auto_instrument()."""

    def setup_method(self):
        import cmpnd
        import dspy
        self._saved = _save_gepa_originals()
        # Replace real GEPA.__init__ with a fake before patching
        # so that _patch_gepa captures a fake as the "original"
        dspy.GEPA.__init__ = _make_fake_gepa_init()
        cmpnd._gepa_patched = False
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        import cmpnd
        import dspy
        clear_context()
        cmpnd._gepa_patched = False
        _restore_gepa_originals(self._saved)
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()
        dspy.configure(callbacks=[])

    def test_auto_instrument_patches_gepa_init(self):
        """auto_instrument() patches dspy.GEPA.__init__ to inject callback."""
        import dspy

        original_init = self._saved[0]

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            import cmpnd
            cmpnd.auto_instrument()

        assert dspy.GEPA.__init__ is not original_init

    def test_patched_gepa_no_callback_after_init(self):
        """Patched GEPA.__init__ does NOT create callback (deferred to compile)."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        assert not hasattr(gepa, "_cmpnd_gepa_callback")

    def test_patched_gepa_fresh_callback_per_compile(self):
        """Each compile() creates a fresh tracker with unique run_id."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            with mock.patch("cmpnd._gepa_supports_callbacks", return_value=True):
                cmpnd._gepa_patched = False
                cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        with mock.patch.object(type(gepa), "_cmpnd_original_compile", return_value=mock.MagicMock()):
            with mock.patch("cmpnd.exporter.get_exporter", return_value=None):
                student = dspy.Predict("question -> answer")
                gepa.compile(student, trainset=[])
                cb1 = gepa._cmpnd_gepa_callback
                rid1 = cb1._tracker.optimization_run_id

                gepa.compile(student, trainset=[])
                cb2 = gepa._cmpnd_gepa_callback
                rid2 = cb2._tracker.optimization_run_id

        assert cb1 is not cb2
        assert rid1 != rid2

    def test_patched_gepa_callback_has_deferred_finalize(self):
        """Patched GEPA callback has defer_finalize=True after compile."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            with mock.patch("cmpnd._gepa_supports_callbacks", return_value=True):
                cmpnd._gepa_patched = False
                cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        with mock.patch.object(type(gepa), "_cmpnd_original_compile", return_value=mock.MagicMock()):
            with mock.patch("cmpnd.exporter.get_exporter", return_value=None):
                student = dspy.Predict("question -> answer")
                gepa.compile(student, trainset=[])
        assert gepa._cmpnd_gepa_callback._defer_finalize is True

    def test_double_patching_prevented(self):
        """Calling _patch_gepa() twice does not double-patch."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        patched_init = dspy.GEPA.__init__

        # Call again - should be a no-op
        cmpnd._patch_gepa()

        assert dspy.GEPA.__init__ is patched_init

    def test_compile_enriches_tracker_program_name(self):
        """Compile patch sets program_name from student class."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.program_name == "_FakeStudent"

    def test_compile_enriches_tracker_valset_hash(self):
        """Compile patch computes valset_hash from effective valset."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]
        valset = [{"question": "What is 3+3?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset, valset=valset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.valset_hash != ""
        assert len(tracker.valset_hash) == 16  # SHA256[:16]

    def test_compile_enriches_tracker_model_name(self):
        """Compile patch sets model_name from dspy.settings.lm."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        fake_lm = _FakeLM("openai/gpt-4o")
        old_lm = dspy.settings.lm
        try:
            dspy.configure(lm=fake_lm)
            with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
                 mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
                gepa.compile(student, trainset=trainset)
        finally:
            dspy.configure(lm=old_lm)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.model_name == "openai/gpt-4o"

    def test_compile_enriches_tracker_reflection_model(self):
        """Compile patch sets reflection_model_name from gepa.reflection_lm."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        gepa.reflection_lm = _FakeLM("anthropic/claude-3")

        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.reflection_model_name == "anthropic/claude-3"

    def test_compile_enriches_tracker_component_signature_hash(self):
        """Compile patch computes component_signature_hash from student predictors."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.component_signature_hash != ""
        assert len(tracker.component_signature_hash) == 16

    def test_compile_enriches_tracker_program_signature_hash(self):
        """Compile patch computes program_signature_hash from root signature."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.program_signature_hash != 0

    def test_compile_calls_tracker_start(self):
        """Compile patch calls tracker.start() before original compile."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker._started is True

    def test_compile_calls_finalize_after_success(self):
        """Compile patch calls tracker.finalize() after successful compile."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker._finalized is True

    def test_compile_captures_compiled_program(self):
        """Compile patch calls capture_compiled_program with compile result."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.compiled_program_state is not None

    def test_compile_sets_error_on_exception(self):
        """Compile patch calls tracker.set_error() if compile raises."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", side_effect=RuntimeError("boom")):
            with pytest.raises(RuntimeError, match="boom"):
                gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.status == "failed"
        assert "boom" in tracker.error_message

    def test_compile_uses_trainset_as_valset_when_no_valset(self):
        """When valset is None, compile uses trainset for valset_hash."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light")
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        expected_hash = OptimizationTracker.compute_valset_hash(trainset)

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)  # no valset

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert tracker.valset_hash == expected_hash

    def test_compile_builds_config_from_gepa_attrs(self):
        """Compile patch builds config dict from GEPA attributes."""
        import dspy
        import cmpnd

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            cmpnd.auto_instrument()

        gepa = dspy.GEPA(auto="light", seed=42)
        student = _FakeStudent()
        trainset = [{"question": "What is 2+2?"}]

        with mock.patch("cmpnd.exporter.get_exporter", return_value=None), \
             mock.patch.object(dspy.GEPA, "_cmpnd_original_compile", return_value=student):
            gepa.compile(student, trainset=trainset)

        tracker = gepa._cmpnd_gepa_callback._tracker
        assert "auto" in tracker.config
        assert tracker.config["auto"] == "light"
        assert "components" in tracker.config


# ---------------------------------------------------------------------------
# Tests for Task 7 & 8: New GEPA signal fields and callbacks
# ---------------------------------------------------------------------------


class TestIterationDataNewFields:
    """Test new fields on IterationData: accepted, rejection_reason, minibatch_ids, budget_remaining."""

    def test_default_values(self):
        from cmpnd.optimizers.tracker import IterationData

        it = IterationData(iteration=0, candidate_idx=0)
        assert it.accepted is None
        assert it.rejection_reason is None
        assert it.minibatch_ids == []
        assert it.budget_remaining is None

    def test_to_api_dict_includes_new_fields(self):
        from cmpnd.optimizers.tracker import IterationData

        it = IterationData(
            iteration=1,
            candidate_idx=2,
            accepted=True,
            rejection_reason=None,
            minibatch_ids=["a", "b", "c"],
            budget_remaining=50,
        )
        d = it.to_api_dict()
        assert d["accepted"] is True
        assert d["rejection_reason"] is None
        assert d["minibatch_ids"] == ["a", "b", "c"]
        assert d["budget_remaining"] == 50

    def test_to_api_dict_rejected(self):
        from cmpnd.optimizers.tracker import IterationData

        it = IterationData(
            iteration=1,
            candidate_idx=2,
            accepted=False,
            rejection_reason="score too low",
        )
        d = it.to_api_dict()
        assert d["accepted"] is False
        assert d["rejection_reason"] == "score too low"

    def test_to_api_dict_empty_minibatch(self):
        from cmpnd.optimizers.tracker import IterationData

        it = IterationData(iteration=0, candidate_idx=0)
        d = it.to_api_dict()
        assert d["minibatch_ids"] == []


class TestCandidateDataNewFields:
    """Test new fields on CandidateData: val_scores_by_id, displaced_from_pareto_at."""

    def test_default_values(self):
        from cmpnd.optimizers.tracker import CandidateData

        c = CandidateData(candidate_idx=0, instructions={"a": "do stuff"})
        assert c.val_scores_by_id == {}
        assert c.displaced_from_pareto_at is None

    def test_to_api_dict_includes_new_fields(self):
        from cmpnd.optimizers.tracker import CandidateData

        c = CandidateData(
            candidate_idx=0,
            instructions={"a": "do stuff"},
            val_scores_by_id={"ex1": 0.8, "ex2": 0.9},
            displaced_from_pareto_at=5,
        )
        d = c.to_api_dict()
        assert d["val_scores_by_id"] == {"ex1": 0.8, "ex2": 0.9}
        assert d["displaced_from_pareto_at"] == 5

    def test_to_api_dict_defaults(self):
        from cmpnd.optimizers.tracker import CandidateData

        c = CandidateData(candidate_idx=0, instructions={})
        d = c.to_api_dict()
        assert d["val_scores_by_id"] == {}
        assert d["displaced_from_pareto_at"] is None


def _make_tracker_and_callback():
    """Create a tracker + CmpndGEPACallback pair for testing."""
    from cmpnd.optimizers.gepa_callback import CmpndGEPACallback
    from cmpnd.optimizers.tracker import OptimizationTracker

    tracker = OptimizationTracker(
        optimizer_type="GEPA",
        program_name="TestProgram",
        config={"auto": "light"},
    )
    callback = CmpndGEPACallback(tracker, defer_finalize=True)
    return tracker, callback


class TestOnCandidateAccepted:
    """Test on_candidate_accepted callback."""

    def test_sets_accepted_true(self):
        tracker, callback = _make_tracker_and_callback()
        # Create an iteration via capture_evaluation
        tracker.capture_evaluation(iteration=3, candidate_idx=1, batch_size=5, scores=[0.8], has_trajectories=False)

        callback.on_candidate_accepted({
            "iteration": 3,
            "new_candidate_idx": 1,
            "new_score": 0.8,
            "parent_ids": [0],
        })

        assert tracker.iterations[0].accepted is True

    def test_noop_for_missing_iteration(self):
        tracker, callback = _make_tracker_and_callback()
        # No iteration created - should not raise
        callback.on_candidate_accepted({
            "iteration": 99,
            "new_candidate_idx": 1,
            "new_score": 0.8,
            "parent_ids": [],
        })
        assert len(tracker.iterations) == 0


class TestOnCandidateRejected:
    """Test on_candidate_rejected callback."""

    def test_sets_accepted_false_and_reason(self):
        tracker, callback = _make_tracker_and_callback()
        tracker.capture_evaluation(iteration=5, candidate_idx=2, batch_size=5, scores=[0.3], has_trajectories=False)

        callback.on_candidate_rejected({
            "iteration": 5,
            "old_score": 0.7,
            "new_score": 0.3,
            "reason": "score decreased",
        })

        it = tracker.iterations[0]
        assert it.accepted is False
        assert it.rejection_reason == "score decreased"

    def test_noop_for_missing_iteration(self):
        tracker, callback = _make_tracker_and_callback()
        callback.on_candidate_rejected({
            "iteration": 99,
            "old_score": 0.7,
            "new_score": 0.3,
            "reason": "no such iteration",
        })
        assert len(tracker.iterations) == 0


class TestOnValsetEvaluated:
    """Test on_valset_evaluated callback and application to CandidateData."""

    def test_stores_scores(self):
        tracker, callback = _make_tracker_and_callback()

        callback.on_valset_evaluated({
            "iteration": 1,
            "candidate_idx": 0,
            "candidate": {"a": "instruction"},
            "scores_by_val_id": {"ex1": 0.9, "ex2": 0.7},
            "average_score": 0.8,
            "num_examples_evaluated": 2,
            "total_valset_size": 10,
            "parent_ids": [],
            "is_best_program": False,
            "outputs_by_val_id": None,
        })

        assert callback._valset_scores[0] == {"ex1": 0.9, "ex2": 0.7}

    def test_scores_applied_to_candidates_on_extract(self):
        """Valset scores should be applied to CandidateData during _extract_candidates_from_state."""
        tracker, callback = _make_tracker_and_callback()

        # Simulate valset evaluated for candidate 0
        callback.on_valset_evaluated({
            "iteration": 1,
            "candidate_idx": 0,
            "candidate": {"a": "inst0"},
            "scores_by_val_id": {"ex1": 0.9, "ex2": 0.7},
            "average_score": 0.8,
            "num_examples_evaluated": 2,
            "total_valset_size": 10,
            "parent_ids": [],
            "is_best_program": False,
            "outputs_by_val_id": None,
        })

        # Create a fake GEPAState
        state = mock.MagicMock()
        state.program_candidates = [{"a": "inst0"}]
        state.parent_program_for_candidate = [[None]]
        state.prog_candidate_objective_scores = [{"obj1": 0.8}]
        state.prog_candidate_val_subscores = [{"ex1": 0.9, "ex2": 0.7}]
        state.num_metric_calls_by_discovery = [0]
        state.program_at_pareto_front_valset = {}

        callback._extract_candidates_from_state(state)

        assert len(tracker.candidates) == 1
        assert tracker.candidates[0].val_scores_by_id == {"ex1": 0.9, "ex2": 0.7}


class TestOnMinibatchSampled:
    """Test on_minibatch_sampled callback."""

    def test_sets_minibatch_ids(self):
        tracker, callback = _make_tracker_and_callback()
        tracker.capture_evaluation(iteration=2, candidate_idx=0, batch_size=3, scores=[0.5], has_trajectories=False)

        callback.on_minibatch_sampled({
            "iteration": 2,
            "minibatch_ids": [10, 20, 30],
            "trainset_size": 100,
        })

        assert tracker.iterations[0].minibatch_ids == [10, 20, 30]

    def test_noop_for_missing_iteration(self):
        tracker, callback = _make_tracker_and_callback()
        callback.on_minibatch_sampled({
            "iteration": 99,
            "minibatch_ids": [1, 2],
            "trainset_size": 50,
        })
        assert len(tracker.iterations) == 0


class TestOnParetoFrontUpdated:
    """Test on_pareto_front_updated callback."""

    def test_marks_displaced_candidates(self):
        from cmpnd.optimizers.tracker import CandidateData

        tracker, callback = _make_tracker_and_callback()
        # Pre-populate candidates
        tracker.candidates = [
            CandidateData(candidate_idx=0, instructions={"a": "v0"}),
            CandidateData(candidate_idx=1, instructions={"a": "v1"}),
            CandidateData(candidate_idx=2, instructions={"a": "v2"}),
        ]

        callback.on_pareto_front_updated({
            "iteration": 4,
            "new_front": [2],
            "displaced_candidates": [0, 1],
        })

        assert tracker.candidates[0].displaced_from_pareto_at == 4
        assert tracker.candidates[1].displaced_from_pareto_at == 4
        assert tracker.candidates[2].displaced_from_pareto_at is None

    def test_does_not_overwrite_existing_displacement(self):
        from cmpnd.optimizers.tracker import CandidateData

        tracker, callback = _make_tracker_and_callback()
        tracker.candidates = [
            CandidateData(candidate_idx=0, instructions={"a": "v0"}, displaced_from_pareto_at=2),
        ]

        callback.on_pareto_front_updated({
            "iteration": 5,
            "new_front": [1],
            "displaced_candidates": [0],
        })

        # Should keep the original displacement iteration
        assert tracker.candidates[0].displaced_from_pareto_at == 2

    def test_noop_for_empty_displaced(self):
        tracker, callback = _make_tracker_and_callback()
        callback.on_pareto_front_updated({
            "iteration": 1,
            "new_front": [0],
            "displaced_candidates": [],
        })
        # No error, no candidates affected


class TestGetCurrentIteration:
    """Test the _get_current_iteration helper."""

    def test_finds_matching_iteration(self):
        tracker, callback = _make_tracker_and_callback()
        tracker.capture_evaluation(iteration=3, candidate_idx=0, batch_size=1, scores=[0.5], has_trajectories=False)
        tracker.capture_evaluation(iteration=7, candidate_idx=1, batch_size=1, scores=[0.6], has_trajectories=False)

        result = callback._get_current_iteration(3)
        assert result is not None
        assert result.iteration == 3

        result = callback._get_current_iteration(7)
        assert result is not None
        assert result.iteration == 7

    def test_returns_none_for_missing(self):
        tracker, callback = _make_tracker_and_callback()
        assert callback._get_current_iteration(99) is None
