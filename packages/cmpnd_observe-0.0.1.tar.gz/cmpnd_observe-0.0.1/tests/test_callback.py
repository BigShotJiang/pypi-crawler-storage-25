"""Tests for DSPy callback — core handlers, helpers, and optimization linkage."""

from unittest import mock
from uuid import uuid4

import pytest

from cmpnd.config import configure
from cmpnd.context import (
    clear_context,
    get_current_span,
    get_current_trace,
    set_current_optimization_run_id,
)
from cmpnd.models import SpanType, TraceStatus


# Skip all tests if dspy is not installed
pytest.importorskip("dspy")


class TestCmpndCallback:
    """Tests for CmpndCallback."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_callback_creation(self):
        """Test callback can be created."""
        from cmpnd.callback import CmpndCallback

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        assert callback._capture_inputs is True
        assert callback._capture_outputs is True
        assert callback._capture_prompts is True

    def test_callback_with_options(self):
        """Test callback with custom options."""
        from cmpnd.callback import CmpndCallback

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback(
                capture_inputs=False,
                capture_outputs=False,
                capture_prompts=False,
            )

        assert callback._capture_inputs is False
        assert callback._capture_outputs is False
        assert callback._capture_prompts is False


class TestCallbackModuleHandlers:
    """Tests for module callback handlers."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_on_module_start_creates_trace_for_root(self):
        """Test on_module_start creates trace for root call."""
        from cmpnd.callback import CmpndCallback
        import dspy

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        # Create a mock Predict instance
        mock_instance = mock.MagicMock(spec=dspy.Predict)
        mock_instance.__class__.__name__ = "Predict"
        mock_instance.signature = None
        mock_instance.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=None):
            callback.on_module_start(
                call_id="test_call_1",
                instance=mock_instance,
                inputs={"question": "test?"},
            )

        # Should have created a trace (root call)
        assert get_current_trace() is not None
        assert get_current_trace().program_name == "Predict"

        # Should have created a span
        assert get_current_span() is not None
        assert get_current_span().span_type == SpanType.PREDICT

    def test_on_module_end_completes_span(self):
        """Test on_module_end completes span (Predict uses batch path)."""
        from cmpnd.callback import CmpndCallback
        import dspy

        exported_items = []

        class MockExporter:
            def export_span(self, span):
                exported_items.append(("span", span))

            def export_trace_start(self, trace):
                exported_items.append(("trace_start", trace))

            def export_trace_finalize(self, trace):
                exported_items.append(("trace_finalize", trace))

            def export_trace_stats(self, trace):
                exported_items.append(("trace_stats", trace))

            def export_trace(self, trace):
                exported_items.append(("trace", trace))

        mock_exporter = MockExporter()

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_instance = mock.MagicMock(spec=dspy.Predict)
        mock_instance.__class__.__name__ = "Predict"
        mock_instance.signature = None
        mock_instance.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="test_call",
                instance=mock_instance,
                inputs={"question": "test?"},
            )

            # Create mock Prediction output
            mock_output = mock.MagicMock(spec=dspy.Prediction)
            mock_output.toDict.return_value = {"answer": "test answer"}

            callback.on_module_end(
                call_id="test_call",
                outputs=mock_output,
                exception=None,
            )

        # Predict uses batch path: trace_stats + trace (no trace_start, no individual span export)
        types = [item[0] for item in exported_items]
        assert "trace_start" not in types
        assert "trace_finalize" not in types
        assert "trace_stats" in types
        assert "trace" in types
        trace_item = next(item for item in exported_items if item[0] == "trace")
        assert trace_item[1].status == TraceStatus.OK

    def test_on_module_end_with_exception(self):
        """Test on_module_end handles exception (batch path for Predict)."""
        from cmpnd.callback import CmpndCallback
        import dspy

        exported_items = []

        class MockExporter:
            def export_span(self, span):
                exported_items.append(("span", span))

            def export_trace_start(self, trace):
                exported_items.append(("trace_start", trace))

            def export_trace_finalize(self, trace):
                exported_items.append(("trace_finalize", trace))

            def export_trace_stats(self, trace):
                exported_items.append(("trace_stats", trace))

            def export_trace(self, trace):
                exported_items.append(("trace", trace))

        mock_exporter = MockExporter()

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_instance = mock.MagicMock(spec=dspy.Predict)
        mock_instance.__class__.__name__ = "Predict"
        mock_instance.signature = None
        mock_instance.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="test_call",
                instance=mock_instance,
                inputs={"question": "test?"},
            )

            callback.on_module_end(
                call_id="test_call",
                outputs=None,
                exception=ValueError("something failed"),
            )

        # Batch path: trace is exported via export_trace (not export_trace_finalize)
        trace_item = next(item for item in exported_items if item[0] == "trace")
        assert trace_item[1].status == TraceStatus.ERROR


class TestStreamingTraceLifecycle:
    """Tests that callback uses correct export path based on span type.

    RLM traces use streaming: trace_start -> spans -> trace_stats -> trace_finalize
    Everything else uses batch: trace_stats -> export_trace (with spans attached)
    """

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def _make_mock_predict(self):
        import dspy
        inst = mock.MagicMock(spec=dspy.Predict)
        inst.__class__.__name__ = "Predict"
        inst.signature = None
        inst.demos = None
        return inst

    def test_predict_root_does_not_call_trace_start(self):
        """Predict root does NOT call export_trace_start (batch path)."""
        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="root_1",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

        mock_exporter.export_trace_start.assert_not_called()
        # Trace should still be created
        assert get_current_trace() is not None
        assert get_current_trace().streaming is False

    def test_root_module_start_no_exporter_no_crash(self):
        """When exporter is None on module start, no crash occurs."""
        callback = self._make_callback()

        with mock.patch("cmpnd.callback.get_exporter", return_value=None):
            callback.on_module_start(
                call_id="root_2",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

        # Should have created a trace without error
        assert get_current_trace() is not None

    def test_predict_root_end_calls_export_trace(self):
        """Predict root uses batch path: export_trace (not export_trace_finalize)."""
        import dspy

        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="root_3",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

            mock_output = mock.MagicMock(spec=dspy.Prediction)
            mock_output.toDict.return_value = {"answer": "yes"}

            callback.on_module_end(
                call_id="root_3",
                outputs=mock_output,
                exception=None,
            )

        # Batch path: export_trace called, NOT export_trace_finalize
        mock_exporter.export_trace.assert_called_once()
        mock_exporter.export_trace_finalize.assert_not_called()
        mock_exporter.export_trace_stats.assert_called_once()

    def test_batch_lifecycle_order(self):
        """Verify batch lifecycle: trace_stats -> trace (no trace_start, no individual spans)."""
        import dspy

        callback = self._make_callback()
        call_order = []

        class OrderTrackingExporter:
            def export_trace_start(self, trace):
                call_order.append("trace_start")

            def export_span(self, span):
                call_order.append("span")

            def export_trace_stats(self, trace):
                call_order.append("trace_stats")

            def export_trace_finalize(self, trace):
                call_order.append("trace_finalize")

            def export_trace(self, trace):
                call_order.append("trace")

        with mock.patch("cmpnd.callback.get_exporter", return_value=OrderTrackingExporter()):
            callback.on_module_start(
                call_id="root_4",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

            mock_output = mock.MagicMock(spec=dspy.Prediction)
            mock_output.toDict.return_value = {"answer": "yes"}

            callback.on_module_end(
                call_id="root_4",
                outputs=mock_output,
                exception=None,
            )

        assert call_order == ["trace_stats", "trace"]


class TestCallbackLMHandlers:
    """Tests for LM callback handlers."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_on_lm_start_creates_span(self):
        """Test on_lm_start creates LM_CALL span."""
        from cmpnd.callback import CmpndCallback
        import dspy

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        # Create mock LM instance
        mock_lm = mock.MagicMock(spec=dspy.LM)
        mock_lm.__class__.__name__ = "LM"
        mock_lm.model = "gpt-4o-mini"
        mock_lm.model_type = "chat"
        mock_lm.cache = False
        mock_lm.kwargs = {"temperature": 0.7}

        with mock.patch("cmpnd.callback.get_exporter", return_value=None):
            callback.on_lm_start(
                call_id="lm_call_1",
                instance=mock_lm,
                inputs={"messages": [{"role": "user", "content": "Hello"}]},
            )

        span = get_current_span()
        assert span is not None
        assert span.span_type == SpanType.LM_CALL
        assert span.model_name == "gpt-4o-mini"

    def test_on_lm_end_captures_usage(self):
        """Test on_lm_end captures token usage."""
        from cmpnd.callback import CmpndCallback
        import dspy

        exported_spans = []

        class MockExporter:
            def export_span(self, span):
                exported_spans.append(span)

        mock_exporter = MockExporter()

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_lm = mock.MagicMock(spec=dspy.LM)
        mock_lm.__class__.__name__ = "LM"
        mock_lm.model = "gpt-4"
        mock_lm.model_type = "chat"
        mock_lm.cache = False
        mock_lm.kwargs = {}

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_lm_start(
                call_id="lm_call",
                instance=mock_lm,
                inputs={},
            )

            callback.on_lm_end(
                call_id="lm_call",
                outputs={
                    "choices": [{"message": {"content": "Hello!"}}],
                    "usage": {
                        "prompt_tokens": 10,
                        "completion_tokens": 5,
                        "total_tokens": 15,
                    },
                },
                exception=None,
            )

        assert len(exported_spans) == 1
        span = exported_spans[0]
        assert span.prompt_tokens == 10
        assert span.completion_tokens == 5
        assert span.total_tokens == 15


class TestCallbackFinishReason:
    """Tests for finish_reason capture from LM responses."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback_and_exporter(self):
        from cmpnd.callback import CmpndCallback
        exported_spans = []

        class MockExporter:
            def export_span(self, span):
                exported_spans.append(span)

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()
        return callback, MockExporter(), exported_spans

    def _make_mock_lm(self, history=None):
        import dspy
        mock_lm = mock.MagicMock(spec=dspy.LM)
        mock_lm.__class__.__name__ = "LM"
        mock_lm.model = "gpt-4"
        mock_lm.model_type = "chat"
        mock_lm.cache = False
        mock_lm.kwargs = {}
        if history is not None:
            mock_lm.history = history
        return mock_lm

    def test_finish_reason_captured_from_history(self):
        """finish_reason from LM history is stored as lm.finish_reason attribute."""
        callback, exporter, exported = self._make_callback_and_exporter()

        mock_response = mock.MagicMock()
        mock_response.choices = [mock.MagicMock(finish_reason="stop")]
        mock_lm = self._make_mock_lm(history=[{
            "response": mock_response,
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }])

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_lm_start(call_id="lm1", instance=mock_lm, inputs={})
            callback.on_lm_end(call_id="lm1", outputs=None, exception=None)

        assert len(exported) == 1
        assert exported[0].attributes.get("lm.finish_reason") == "stop"

    def test_finish_reason_length_captured(self):
        """finish_reason='length' (truncation) is captured."""
        callback, exporter, exported = self._make_callback_and_exporter()

        mock_response = mock.MagicMock()
        mock_response.choices = [mock.MagicMock(finish_reason="length")]
        mock_lm = self._make_mock_lm(history=[{
            "response": mock_response,
            "usage": {"prompt_tokens": 10, "completion_tokens": 500, "total_tokens": 510},
        }])

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_lm_start(call_id="lm1", instance=mock_lm, inputs={})
            callback.on_lm_end(call_id="lm1", outputs=None, exception=None)

        assert exported[0].attributes.get("lm.finish_reason") == "length"

    def test_finish_reason_missing_gracefully(self):
        """No crash when history has no response or choices."""
        callback, exporter, exported = self._make_callback_and_exporter()

        mock_lm = self._make_mock_lm(history=[{
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }])

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_lm_start(call_id="lm1", instance=mock_lm, inputs={})
            callback.on_lm_end(call_id="lm1", outputs=None, exception=None)

        assert len(exported) == 1
        assert "lm.finish_reason" not in exported[0].attributes

    def test_finish_reason_not_set_on_exception(self):
        """finish_reason not extracted when LM call raises."""
        callback, exporter, exported = self._make_callback_and_exporter()

        mock_response = mock.MagicMock()
        mock_response.choices = [mock.MagicMock(finish_reason="stop")]
        mock_lm = self._make_mock_lm(history=[{
            "response": mock_response,
            "usage": {},
        }])

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_lm_start(call_id="lm1", instance=mock_lm, inputs={})
            callback.on_lm_end(call_id="lm1", outputs=None, exception=RuntimeError("timeout"))

        assert len(exported) == 1
        assert "lm.finish_reason" not in exported[0].attributes


class TestCallbackToolHandlers:
    """Tests for tool callback handlers."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_on_tool_start_skips_finish_tool(self):
        """Test on_tool_start skips the special 'finish' tool."""
        from cmpnd.callback import CmpndCallback

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_tool = mock.MagicMock()
        mock_tool.name = "finish"

        with mock.patch("cmpnd.callback.get_exporter", return_value=None):
            callback.on_tool_start(
                call_id="tool_call",
                instance=mock_tool,
                inputs={},
            )

        # Should not have created a span
        assert get_current_span() is None

    def test_on_tool_start_creates_span(self):
        """Test on_tool_start creates TOOL span."""
        from cmpnd.callback import CmpndCallback

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_tool = mock.MagicMock()
        mock_tool.name = "search"
        mock_tool.desc = "Search the web"

        with mock.patch("cmpnd.callback.get_exporter", return_value=None):
            callback.on_tool_start(
                call_id="tool_call",
                instance=mock_tool,
                inputs={"kwargs": {"query": "test query"}},
            )

        span = get_current_span()
        assert span is not None
        assert span.span_type == SpanType.TOOL
        assert span.name == "Tool.search"
        assert span.attributes["tool.name"] == "search"


class TestSpanTypeMapping:
    """Tests for span type mapping from DSPy instances."""

    def setup_method(self):
        """Configure SDK before each test."""
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        """Clear context after each test."""
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_predict_maps_to_predict_type(self):
        """Test Predict instance maps to PREDICT span type."""
        from cmpnd.callback import CmpndCallback
        import dspy

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_instance = mock.MagicMock(spec=dspy.Predict)

        span_type = callback._get_span_type_for_module(mock_instance, dspy)
        assert span_type == SpanType.PREDICT

    def test_chain_of_thought_maps_to_cot_type(self):
        """Test ChainOfThought instance maps to CHAIN_OF_THOUGHT span type."""
        from cmpnd.callback import CmpndCallback
        import dspy

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_instance = mock.MagicMock(spec=dspy.ChainOfThought)

        span_type = callback._get_span_type_for_module(mock_instance, dspy)
        assert span_type == SpanType.CHAIN_OF_THOUGHT

    def test_react_maps_to_react_type(self):
        """Test ReAct instance maps to REACT span type."""
        from cmpnd.callback import CmpndCallback
        import dspy

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_instance = mock.MagicMock(spec=dspy.ReAct)

        span_type = callback._get_span_type_for_module(mock_instance, dspy)
        assert span_type == SpanType.REACT

    def test_retrieve_maps_to_retrieve_type(self):
        """Test Retrieve instance maps to RETRIEVE span type."""
        from cmpnd.callback import CmpndCallback
        import dspy

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        mock_instance = mock.MagicMock(spec=dspy.Retrieve)

        span_type = callback._get_span_type_for_module(mock_instance, dspy)
        assert span_type == SpanType.RETRIEVE


class TestOrphanedLMUsage:
    """Pin orphaned LM usage tracking during optimization."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def _make_mock_lm(self, model="gpt-4o-mini", history=None):
        import dspy
        lm = mock.MagicMock(spec=dspy.LM)
        lm.__class__.__name__ = "LM"
        lm.model = model
        lm.model_type = "chat"
        lm.cache = False
        lm.kwargs = {}
        if history is not None:
            lm.history = history
        return lm

    def test_orphaned_lm_usage_accumulated(self):
        """LM calls without a trace context during optimization accumulate usage."""
        callback = self._make_callback()
        exporter = mock.MagicMock()
        exporter.export_span = mock.MagicMock()

        # Simulate being inside an optimization run
        callback._active_optimization_run_id = uuid4()

        lm = self._make_mock_lm("gpt-4o", history=[{
            "usage": {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
        }])

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_lm_start(call_id="orphan_1", instance=lm, inputs={})
            callback.on_lm_end(call_id="orphan_1", outputs=None)

        # Usage should be accumulated
        assert "gpt-4o" in callback._orphaned_lm_usage
        assert callback._orphaned_lm_usage["gpt-4o"]["prompt_tokens"] == 100
        assert callback._orphaned_lm_usage["gpt-4o"]["completion_tokens"] == 50

    def test_orphaned_lm_usage_accumulates_across_calls(self):
        """Multiple orphaned LM calls to the same model sum up."""
        callback = self._make_callback()
        callback._active_optimization_run_id = uuid4()

        for i in range(3):
            lm = self._make_mock_lm("gpt-4o", history=[{
                "usage": {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
            }])
            exporter = mock.MagicMock()
            with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
                callback.on_lm_start(call_id=f"orphan_{i}", instance=lm, inputs={})
                callback.on_lm_end(call_id=f"orphan_{i}", outputs=None)

        assert callback._orphaned_lm_usage["gpt-4o"]["prompt_tokens"] == 300
        assert callback._orphaned_lm_usage["gpt-4o"]["completion_tokens"] == 150

    def test_orphaned_lm_usage_tracks_multiple_models(self):
        """Orphaned usage from different models tracked separately."""
        callback = self._make_callback()
        callback._active_optimization_run_id = uuid4()

        for model in ["gpt-4o", "claude-sonnet-4-20250514"]:
            lm = self._make_mock_lm(model, history=[{
                "usage": {"prompt_tokens": 200, "completion_tokens": 100, "total_tokens": 300},
            }])
            exporter = mock.MagicMock()
            with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
                callback.on_lm_start(call_id=f"orphan_{model}", instance=lm, inputs={})
                callback.on_lm_end(call_id=f"orphan_{model}", outputs=None)

        assert len(callback._orphaned_lm_usage) == 2
        assert "gpt-4o" in callback._orphaned_lm_usage
        assert "claude-sonnet-4-20250514" in callback._orphaned_lm_usage

    def test_no_orphaned_usage_outside_optimization(self):
        """LM calls without trace context but NOT in optimization are just exported."""
        callback = self._make_callback()

        exported_spans = []
        exporter = mock.MagicMock()
        exporter.export_span = lambda s: exported_spans.append(s)

        # NOT in optimization
        callback._active_optimization_run_id = None

        lm = self._make_mock_lm("gpt-4o-mini", history=[{
            "usage": {"prompt_tokens": 50, "completion_tokens": 25, "total_tokens": 75},
        }])

        with mock.patch("cmpnd.callback.get_exporter", return_value=exporter):
            callback.on_lm_start(call_id="normal_lm", instance=lm, inputs={})
            callback.on_lm_end(call_id="normal_lm", outputs=None)

        # No orphaned usage tracked
        assert len(callback._orphaned_lm_usage) == 0

        # Span IS exported (not orphaned)
        assert len(exported_spans) == 1


class TestCallbackOptimizationRunLinkage:
    """Test that callback sets optimization_run_id on traces."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def test_trace_gets_optimization_run_id_from_context(self):
        """When optimization_run_id is in context, traces should get it."""
        from cmpnd.callback import CmpndCallback
        import dspy

        exported_traces = []

        mock_exporter = mock.MagicMock()
        mock_exporter.export_trace = lambda t: exported_traces.append(t)

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        # Set optimization context (simulating being inside TrackedGEPA.compile)
        opt_run_id = uuid4()
        set_current_optimization_run_id(opt_run_id)

        mock_instance = mock.MagicMock(spec=dspy.Predict)
        mock_instance.__class__.__name__ = "Predict"
        mock_instance.signature = None
        mock_instance.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="test_opt_trace",
                instance=mock_instance,
                inputs={"question": "test?"},
            )
            callback.on_module_end(
                call_id="test_opt_trace",
                outputs={"answer": "yes"},
            )

        assert len(exported_traces) == 1
        assert exported_traces[0].optimization_run_id == opt_run_id

    def test_trace_no_optimization_run_id_outside_optimization(self):
        """Without optimization context, traces should have None."""
        from cmpnd.callback import CmpndCallback
        import dspy

        exported_traces = []

        mock_exporter = mock.MagicMock()
        mock_exporter.export_trace = lambda t: exported_traces.append(t)

        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()

        # Do NOT set optimization context
        set_current_optimization_run_id(None)

        mock_instance = mock.MagicMock(spec=dspy.Predict)
        mock_instance.__class__.__name__ = "Predict"
        mock_instance.signature = None
        mock_instance.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="test_no_opt",
                instance=mock_instance,
                inputs={"question": "test?"},
            )
            callback.on_module_end(
                call_id="test_no_opt",
                outputs={"answer": "yes"},
            )

        assert len(exported_traces) == 1
        assert exported_traces[0].optimization_run_id is None


# ---------------------------------------------------------------------------
# Helper methods: _get_metric_name
# ---------------------------------------------------------------------------

class TestGetMetricName:
    """Pin _get_metric_name behavior for the extraction to callback_helpers.py."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def test_regular_function(self):
        callback = self._make_callback()

        def exact_match(example, prediction, trace=None):
            return example.answer == prediction.answer

        assert callback._get_metric_name(exact_match) == "exact_match"

    def test_lambda(self):
        callback = self._make_callback()

        metric = lambda ex, pred: ex.answer == pred.answer  # noqa: E731

        assert callback._get_metric_name(metric) == "<lambda>"

    def test_callable_class(self):
        callback = self._make_callback()

        class MyMetric:
            def __call__(self, example, prediction):
                return True

        assert callback._get_metric_name(MyMetric()) == "MyMetric"

    def test_functools_wrapped(self):
        """Unwraps functools.wraps decorated functions."""
        import functools
        callback = self._make_callback()

        def original_metric(ex, pred):
            return True

        @functools.wraps(original_metric)
        def wrapper(ex, pred):
            return original_metric(ex, pred)

        assert callback._get_metric_name(wrapper) == "original_metric"

    def test_dspy_style_wrapper(self):
        """Unwraps DSPy's wrapped_metric pattern via closure inspection."""
        callback = self._make_callback()

        def my_scorer(ex, pred):
            return True

        # Simulate DSPy's wrapping pattern
        def wrapped_metric(ex, pred, trace=None):
            return my_scorer(ex, pred)

        assert callback._get_metric_name(wrapped_metric) == "my_scorer"

    def test_nested_wrapper(self):
        """Handles wrapper wrapping another wrapper name."""
        callback = self._make_callback()

        def real_metric(ex, pred):
            return True

        def inner(ex, pred):
            return real_metric(ex, pred)

        def wrapper(ex, pred):
            return inner(ex, pred)

        name = callback._get_metric_name(wrapper)
        # Accept either — the important thing is it doesn't crash
        assert name in ("real_metric", "wrapper")


# ---------------------------------------------------------------------------
# Helper methods: _infer_provider
# ---------------------------------------------------------------------------

class TestInferProvider:
    """Pin _infer_provider behavior for extraction to callback_helpers.py."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _infer(self, model_name):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            callback = CmpndCallback()
        instance = mock.MagicMock()
        instance.model = model_name
        return callback._infer_provider(instance)

    def test_openai_models(self):
        assert self._infer("gpt-4o") == "openai"
        assert self._infer("gpt-4o-mini") == "openai"
        assert self._infer("gpt-3.5-turbo") == "openai"
        assert self._infer("openai/gpt-4o") == "openai"

    def test_anthropic_models(self):
        assert self._infer("claude-3-5-sonnet-20241022") == "anthropic"
        assert self._infer("claude-sonnet-4-20250514") == "anthropic"
        assert self._infer("anthropic/claude-3-opus") == "anthropic"

    def test_google_models(self):
        assert self._infer("gemini-pro") == "google"
        assert self._infer("gemini-1.5-flash") == "google"

    def test_together_models(self):
        assert self._infer("llama-3-70b") == "together"
        assert self._infer("mistral-7b") == "together"

    def test_unknown_model(self):
        assert self._infer("some-custom-model") == "unknown"
        assert self._infer("") == "unknown"


# ---------------------------------------------------------------------------
# Helper methods: _compute_cost
# ---------------------------------------------------------------------------

class TestComputeCost:
    """Pin _compute_cost behavior for extraction to callback_helpers.py."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def test_known_model(self):
        callback = self._make_callback()
        cost = callback._compute_cost("gpt-4o-mini", prompt_tokens=1000, completion_tokens=500)
        expected = (1000 * 0.15 / 1_000_000) + (500 * 0.60 / 1_000_000)
        assert abs(cost - expected) < 1e-10

    def test_unknown_model_returns_zero(self):
        callback = self._make_callback()
        cost = callback._compute_cost("unknown-model", prompt_tokens=1000, completion_tokens=500)
        assert cost == 0.0

    def test_zero_tokens_returns_zero(self):
        callback = self._make_callback()
        cost = callback._compute_cost("gpt-4o-mini", prompt_tokens=0, completion_tokens=0)
        assert cost == 0.0

    def test_no_model_name_returns_zero(self):
        callback = self._make_callback()
        cost = callback._compute_cost("", prompt_tokens=100, completion_tokens=50)
        assert cost == 0.0

    def test_claude_model(self):
        callback = self._make_callback()
        cost = callback._compute_cost(
            "claude-sonnet-4-20250514", prompt_tokens=1000, completion_tokens=500
        )
        expected = (1000 * 3.00 / 1_000_000) + (500 * 15.00 / 1_000_000)
        assert abs(cost - expected) < 1e-10


# ---------------------------------------------------------------------------
# RLM repl_history population
# ---------------------------------------------------------------------------

class TestReplHistory:
    """Tests for repl_history population on RLM parent spans."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def _make_mock_rlm(self):
        import dspy
        inst = mock.MagicMock(spec=dspy.RLM)
        inst.__class__.__name__ = "RLM"
        inst.signature = None
        inst.demos = None
        return inst

    def _make_mock_predict(self):
        import dspy
        inst = mock.MagicMock(spec=dspy.Predict)
        inst.__class__.__name__ = "Predict"
        inst.signature = None
        inst.demos = None
        return inst

    def _make_prediction(self, fields):
        import dspy
        pred = mock.MagicMock(spec=dspy.Prediction)
        pred.toDict.return_value = fields
        return pred

    def test_two_turn_rlm_populates_repl_history(self):
        """A 2-turn RLM flow populates repl_history with reasoning, code, and output."""
        from dspy.predict.rlm import REPLHistory
        callback = self._make_callback()
        exported_spans = []

        class MockExporter:
            def export_span(self, span):
                exported_spans.append(span)
            def export_trace_start(self, trace):
                pass
            def export_trace_finalize(self, trace):
                pass
            def export_trace_stats(self, trace):
                pass

        # Build REPLHistory objects as DSPy would pass them
        empty_history = REPLHistory()
        history_after_step0 = empty_history.append(
            reasoning="I should look up the weather data",
            code="weather = get_weather('today')\nprint(weather)",
            output="Sunny, 72F",
        )
        final_history = history_after_step0.append(
            reasoning="Now I have the data, submit the answer",
            code="SUBMIT('Sunny, 72F')",
            output="FINAL: {'answer': 'Sunny, 72F'}",
        )

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            # 1. Start the RLM root module
            callback.on_module_start(
                call_id="rlm_root",
                instance=self._make_mock_rlm(),
                inputs={"question": "What is the weather?"},
            )

            # 2. Turn 0: PREDICT child (empty repl_history)
            callback.on_module_start(
                call_id="predict_0",
                instance=self._make_mock_predict(),
                inputs={"repl_history": empty_history},
            )
            callback.on_module_end(
                call_id="predict_0",
                outputs=self._make_prediction({
                    "reasoning": "I should look up the weather data",
                    "code": "weather = get_weather('today')\nprint(weather)",
                }),
            )

            # 3. Turn 1: PREDICT child (repl_history carries step 0's output)
            callback.on_module_start(
                call_id="predict_1",
                instance=self._make_mock_predict(),
                inputs={"repl_history": history_after_step0},
            )
            callback.on_module_end(
                call_id="predict_1",
                outputs=self._make_prediction({
                    "reasoning": "Now I have the data, submit the answer",
                    "code": "SUBMIT('Sunny, 72F')",
                }),
            )

            # 4. End the RLM root module (trajectory has all outputs)
            rlm_output = self._make_prediction({"answer": "Sunny, 72F"})
            rlm_output.trajectory = final_history
            callback.on_module_end(
                call_id="rlm_root",
                outputs=rlm_output,
            )

        # Find the RLM parent span
        rlm_spans = [s for s in exported_spans if s.span_type == SpanType.RLM]
        assert len(rlm_spans) == 1
        rlm_span = rlm_spans[0]

        # Should have 2 turns in repl_history
        assert len(rlm_span.repl_history) == 2

        # Turn 0: output extracted from PREDICT 1's repl_history input
        assert rlm_span.repl_history[0]["turn"] == 0
        assert rlm_span.repl_history[0]["reasoning"] == "I should look up the weather data"
        assert "get_weather" in rlm_span.repl_history[0]["code"]
        assert rlm_span.repl_history[0]["output"] == "Sunny, 72F"

        # Turn 1: FINAL output is filtered out (it contains the entire RLM
        # result dict and would crash the notebook view)
        assert rlm_span.repl_history[1]["turn"] == 1
        assert rlm_span.repl_history[1]["reasoning"] == "Now I have the data, submit the answer"
        assert "SUBMIT" in rlm_span.repl_history[1]["code"]
        assert "output" not in rlm_span.repl_history[1]

    def test_repl_history_empty_for_non_rlm_modules(self):
        """Non-RLM modules should not have repl_history populated."""
        callback = self._make_callback()
        exported_traces = []

        class MockExporter:
            def export_span(self, span):
                pass
            def export_trace_start(self, trace):
                pass
            def export_trace_finalize(self, trace):
                pass
            def export_trace_stats(self, trace):
                pass
            def export_trace(self, trace):
                exported_traces.append(trace)

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            callback.on_module_start(
                call_id="predict_root",
                instance=self._make_mock_predict(),
                inputs={"question": "test"},
            )
            callback.on_module_end(
                call_id="predict_root",
                outputs=self._make_prediction({"answer": "yes"}),
            )

        # Predict uses batch path — spans are in trace._batch_spans
        assert len(exported_traces) == 1
        predict_spans = [s for s in exported_traces[0]._batch_spans if s.span_type == SpanType.PREDICT]
        assert len(predict_spans) == 1
        assert predict_spans[0].repl_history == []

    def test_repl_history_serialized_in_attributes(self):
        """repl_history is serialized into the span's attributes dict."""
        import json
        callback = self._make_callback()
        exported_spans = []

        class MockExporter:
            def export_span(self, span):
                exported_spans.append(span)
            def export_trace_start(self, trace):
                pass
            def export_trace_finalize(self, trace):
                pass
            def export_trace_stats(self, trace):
                pass

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            # Start RLM
            callback.on_module_start(
                call_id="rlm_root",
                instance=self._make_mock_rlm(),
                inputs={"question": "test"},
            )

            # One PREDICT turn
            callback.on_module_start(
                call_id="predict_0",
                instance=self._make_mock_predict(),
                inputs={},
            )
            callback.on_module_end(
                call_id="predict_0",
                outputs=self._make_prediction({
                    "reasoning": "think about it",
                    "code": "result = search('test')",
                }),
            )

            # End RLM
            callback.on_module_end(
                call_id="rlm_root",
                outputs=self._make_prediction({"answer": "result"}),
            )

        rlm_spans = [s for s in exported_spans if s.span_type == SpanType.RLM]
        assert len(rlm_spans) == 1

        api_dict = rlm_spans[0].to_api_dict()
        attrs = api_dict["attributes"]
        assert "repl_history" in attrs
        history = json.loads(attrs["repl_history"])
        assert len(history) == 1
        assert history[0]["reasoning"] == "think about it"
        assert history[0]["code"] == "result = search('test')"

    def test_rlm_parent_cleaned_up_after_rlm_ends(self):
        """_rlm_parent_spans is cleaned up when the RLM module ends."""
        callback = self._make_callback()

        class MockExporter:
            def export_span(self, span):
                pass
            def export_trace_start(self, trace):
                pass
            def export_trace_finalize(self, trace):
                pass
            def export_trace_stats(self, trace):
                pass

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            callback.on_module_start(
                call_id="rlm_root",
                instance=self._make_mock_rlm(),
                inputs={"question": "test"},
            )

            # RLM parent should be tracked
            assert len(callback._rlm_parent_spans) == 1

            callback.on_module_end(
                call_id="rlm_root",
                outputs=self._make_prediction({"answer": "done"}),
            )

        # Should be cleaned up
        assert len(callback._rlm_parent_spans) == 0

    def test_predict_without_reasoning_code_ignored(self):
        """PREDICT outputs without reasoning/code fields don't create repl_history entries."""
        callback = self._make_callback()
        exported_spans = []

        class MockExporter:
            def export_span(self, span):
                exported_spans.append(span)
            def export_trace_start(self, trace):
                pass
            def export_trace_finalize(self, trace):
                pass
            def export_trace_stats(self, trace):
                pass

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            callback.on_module_start(
                call_id="rlm_root",
                instance=self._make_mock_rlm(),
                inputs={"question": "test"},
            )

            # PREDICT with non-RLM outputs (e.g. a plain answer)
            callback.on_module_start(
                call_id="predict_0",
                instance=self._make_mock_predict(),
                inputs={},
            )
            callback.on_module_end(
                call_id="predict_0",
                outputs=self._make_prediction({"answer": "42"}),
            )

            callback.on_module_end(
                call_id="rlm_root",
                outputs=self._make_prediction({"answer": "42"}),
            )

        rlm_spans = [s for s in exported_spans if s.span_type == SpanType.RLM]
        assert len(rlm_spans) == 1
        assert rlm_spans[0].repl_history == []

    def test_rlm_predict_inputs_thinned(self):
        """RLM PREDICT spans have repl_history stripped from inputs (O(N) not O(N²))."""
        from dspy.predict.rlm import REPLHistory
        callback = self._make_callback()
        exported_spans = []

        class MockExporter:
            def export_span(self, span):
                exported_spans.append(span)
            def export_trace_start(self, trace):
                pass
            def export_trace_finalize(self, trace):
                pass
            def export_trace_stats(self, trace):
                pass

        # Build growing REPLHistory objects
        empty_history = REPLHistory()
        history_after_step0 = empty_history.append(
            reasoning="Step 0 reasoning",
            code="x = 1",
            output="1",
        )

        with mock.patch("cmpnd.callback.get_exporter", return_value=MockExporter()):
            callback.on_module_start(
                call_id="rlm_root",
                instance=self._make_mock_rlm(),
                inputs={"question": "test"},
            )

            # Turn 0: empty repl_history
            callback.on_module_start(
                call_id="predict_0",
                instance=self._make_mock_predict(),
                inputs={"repl_history": empty_history},
            )
            callback.on_module_end(
                call_id="predict_0",
                outputs=self._make_prediction({
                    "reasoning": "Step 0 reasoning",
                    "code": "x = 1",
                }),
            )

            # Turn 1: carries step 0's history (this is the O(N²) source)
            callback.on_module_start(
                call_id="predict_1",
                instance=self._make_mock_predict(),
                inputs={"repl_history": history_after_step0},
            )
            callback.on_module_end(
                call_id="predict_1",
                outputs=self._make_prediction({
                    "reasoning": "Step 1 reasoning",
                    "code": "y = 2",
                }),
            )

            callback.on_module_end(
                call_id="rlm_root",
                outputs=self._make_prediction({"answer": "done"}),
            )

        # PREDICT spans should have repl_history stripped
        predict_spans = [s for s in exported_spans if s.span_type == SpanType.PREDICT]
        for ps in predict_spans:
            if ps.inputs:
                assert "repl_history" not in ps.inputs, \
                    f"repl_history should be thinned from PREDICT inputs but found: {list(ps.inputs.keys())}"
            assert "rlm.subcall" not in ps.attributes, \
                "PREDICT spans are trajectory steps, not subcalls"
            assert ps.attributes.get("thinned") == "true"

        # RLM parent should still have full repl_history
        rlm_spans = [s for s in exported_spans if s.span_type == SpanType.RLM]
        assert len(rlm_spans) == 1
        assert len(rlm_spans[0].repl_history) == 2


# ---------------------------------------------------------------------------
# Export routing: RLM streams, everything else batches
# ---------------------------------------------------------------------------

class TestExportRouting:
    """Verify that RLM traces use streaming export while other traces use batch."""

    def setup_method(self):
        configure(api_key="test_key", endpoint="http://localhost:8000")

    def teardown_method(self):
        clear_context()
        from cmpnd.config import _config
        _config.set(None)
        from cmpnd.exporter import shutdown_exporter
        shutdown_exporter()

    def _make_callback(self):
        from cmpnd.callback import CmpndCallback
        with mock.patch("cmpnd.callback.ensure_exporter_started"):
            return CmpndCallback()

    def _make_mock_predict(self):
        import dspy
        inst = mock.MagicMock(spec=dspy.Predict)
        inst.__class__.__name__ = "Predict"
        inst.signature = None
        inst.demos = None
        return inst

    def test_rlm_trace_is_streaming(self):
        """RLM root creates a trace with streaming=True."""
        import dspy
        if not hasattr(dspy, "RLM"):
            pytest.skip("dspy.RLM not available in this dspy version")

        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        mock_rlm = mock.MagicMock(spec=dspy.RLM)
        mock_rlm.__class__.__name__ = "RLM"
        mock_rlm.signature = None
        mock_rlm.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="rlm_root",
                instance=mock_rlm,
                inputs={"question": "solve this"},
            )

        trace = get_current_trace()
        assert trace is not None
        assert trace.streaming is True
        mock_exporter.export_trace_start.assert_called_once()

    def test_predict_trace_is_not_streaming(self):
        """Predict root creates a trace with streaming=False."""
        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="pred_root",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

        trace = get_current_trace()
        assert trace is not None
        assert trace.streaming is False

    def test_predict_trace_does_not_stream_trace_start(self):
        """export_trace_start is NOT called for Predict root traces."""
        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="pred_root",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

        mock_exporter.export_trace_start.assert_not_called()

    def test_predict_trace_does_not_stream_spans(self):
        """export_span is NOT called for spans in non-streaming (Predict) traces."""
        import dspy

        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="pred_root",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

            mock_output = mock.MagicMock(spec=dspy.Prediction)
            mock_output.toDict.return_value = {"answer": "yes"}

            callback.on_module_end(
                call_id="pred_root",
                outputs=mock_output,
            )

        # No individual span export for batch traces
        mock_exporter.export_span.assert_not_called()

    def test_predict_trace_exports_complete_trace(self):
        """Non-streaming traces call export_trace_stats + export_trace (not export_trace_finalize)."""
        import dspy

        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="pred_root",
                instance=self._make_mock_predict(),
                inputs={"question": "test?"},
            )

            mock_output = mock.MagicMock(spec=dspy.Prediction)
            mock_output.toDict.return_value = {"answer": "yes"}

            callback.on_module_end(
                call_id="pred_root",
                outputs=mock_output,
            )

        mock_exporter.export_trace_stats.assert_called_once()
        mock_exporter.export_trace.assert_called_once()
        mock_exporter.export_trace_finalize.assert_not_called()

        # The exported trace should have _batch_spans populated
        trace = mock_exporter.export_trace.call_args[0][0]
        assert len(trace._batch_spans) == 1  # The root Predict span

    def test_rlm_trace_uses_streaming_path(self):
        """RLM traces should use streaming: trace_start, export_span, trace_stats + trace_finalize."""
        import dspy

        RLM = getattr(dspy, "RLM", None)
        if RLM is None:
            pytest.skip("dspy.RLM not available")

        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        instance = mock.MagicMock(spec=RLM)
        instance.__class__.__name__ = "RLM"
        instance.signature = None
        instance.demos = None

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="call-rlm",
                instance=instance,
                inputs={"question": "solve this"},
            )
            callback.on_module_end(
                call_id="call-rlm",
                outputs=None,
            )

        # Should have used streaming path
        mock_exporter.export_trace_start.assert_called_once()
        mock_exporter.export_trace_stats.assert_called_once()
        mock_exporter.export_trace_finalize.assert_called_once()
        # Should NOT have used batch path
        mock_exporter.export_trace.assert_not_called()

    def test_streaming_traces_cleaned_up(self):
        """_streaming_traces dict is cleaned up after trace finalization."""
        import dspy

        callback = self._make_callback()
        mock_exporter = mock.MagicMock()

        instance = self._make_mock_predict()

        with mock.patch("cmpnd.callback.get_exporter", return_value=mock_exporter):
            callback.on_module_start(
                call_id="call-1",
                instance=instance,
                inputs={"question": "test?"},
            )

            # Should have an entry during execution
            assert len(callback._streaming_traces) == 1

            mock_output = mock.MagicMock(spec=dspy.Prediction)
            mock_output.toDict.return_value = {"answer": "yes"}

            callback.on_module_end(
                call_id="call-1",
                outputs=mock_output,
            )

        # Should be cleaned up after finalization
        assert len(callback._streaming_traces) == 0
