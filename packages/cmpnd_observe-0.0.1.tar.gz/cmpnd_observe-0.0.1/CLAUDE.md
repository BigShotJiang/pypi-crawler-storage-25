# Claude Code Instructions

## Running Tests & Checks

```bash
python -m pytest tests/           # all tests (excluding e2e)
python -m pytest tests/ -k "not e2e"  # skip e2e explicitly
ruff check .                      # lint
ruff format --check .             # format check
```

## Testing Philosophy

**Always default to test driven development**. Write a plan, write tests before implementing, review tests, approve tests, then turn them green.

**Use real databases, not mocks.** Tests must use actual databases to catch:
- Data type mismatches (e.g., unsigned int64 overflowing signed BIGINT)
- Constraint violations
- SQL syntax issues
- Schema mismatches between models and database columns

Mocks hide integration bugs. If a test can pass while the actual database operation fails, the test is worthless.

For values that will be stored in Postgres:
- `signature_hash` must fit in signed int64 (-2^63 to 2^63-1) for BIGINT columns
- Always validate database constraints in tests, not just Python logic

## Hash Architecture

There are two different signature hashes - don't confuse them:

| Hash | Type | Purpose | Used In |
|------|------|---------|---------|
| `signature_hash` | Signed Int64 (xxhash) | Program identity | traces, eval_runs, Program registry |
| `component_signature_hash` | String (SHA256[:16]) | Model sweep grouping | optimization_runs |

The `program_signature_hash` in optimization_runs is a signed Int64 that matches `signature_hash` for joining optimizations to traces.

**Important:** `signature_hash` uses xxhash64 converted to signed int64 at the SDK level. Both Postgres BIGINT and ClickHouse Int64 use the same signed format - no edge conversions needed. The conversion happens in `cmpnd/identity.py:_unsigned_to_signed_int64()`.

## Null Handling for Hashes

**NEVER use `0` as a null sentinel for hash values.** Use proper `NULL`/`None` instead.

Correct patterns:
```python
# Python schemas - use Optional
program_signature_hash: int | None = None  # Correct
program_signature_hash: int = 0            # Wrong
```

**Exception:** `signature_hash` in traces/spans uses `DEFAULT 0` because it's required data.

## Key Files

- `cmpnd/identity.py` - Unified hash computations (xxhash, SHA256)
- `cmpnd/callback.py` - DSPy instrumentation, signature extraction
- `cmpnd/optimizers/tracker.py` - Optimization tracking

## Release

Tag with `v*` (e.g., `git tag v0.2.0`) and push the tag to trigger PyPI publish via GitHub Actions.
