"""Tools resource -- search, execute, and lookup tools."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from mcpgateway_sdk._http import HTTPClient
from mcpgateway_sdk.models.tool import ToolExecuteResult, ToolLookup, ToolSearchResult

_ENDPOINTS = {
    "get_by_name": ("GET", "/api/v1/tools/by-name"),
    "search": ("POST", "/api/v1/tools/search"),
    "execute": ("POST", "/api/v1/tools/execute"),
}


class ToolsResource:
    """Interact with tools registered on the MCP Gateway."""

    _endpoints = _ENDPOINTS

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def get_by_name(self, name: str) -> ToolLookup:
        """Resolve a tool by its qualified name (server_name__tool_name).

        Args:
            name: Qualified tool name (e.g., "hackernews__hackernews_top_stories_get").

        Returns:
            A ToolLookup with the tool metadata and input schema.
        """
        data = await self._http.request(
            "GET",
            "/api/v1/tools/by-name",
            params={"name": name},
        )
        return ToolLookup.model_validate(data)

    async def search(
        self,
        query: str,
        limit: int = 5,
        *,
        bundle_id: str | UUID | None = None,
        agent_id: str | UUID | None = None,
        server_ids: list[str | UUID] | None = None,
    ) -> list[ToolSearchResult]:
        """Semantic search for tools matching a natural-language query.

        Args:
            query: Natural-language description of the desired capability.
            limit: Maximum number of results to return (default 5).
            bundle_id: Scope search to tools in a specific bundle.
            agent_id: Scope search to tools assigned to an agent's bundle.
            server_ids: Scope search to tools on specific servers.

        Returns:
            A list of ToolSearchResult sorted by relevance score.
        """
        body: dict[str, Any] = {"query": query, "limit": limit}
        if bundle_id is not None:
            body["bundle_id"] = str(bundle_id)
        if agent_id is not None:
            body["agent_id"] = str(agent_id)
        if server_ids is not None:
            body["server_ids"] = [str(sid) for sid in server_ids]
        data = await self._http.request("POST", "/api/v1/tools/search", json=body)
        return [ToolSearchResult.model_validate(r) for r in data.get("tools", [])]

    async def execute(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        server_id: str | UUID | None = None,
        server_name: str | None = None,
        bundle_id: str | UUID | None = None,
        agent_id: str | UUID | None = None,
    ) -> ToolExecuteResult:
        """Execute a tool by its globally unique qualified name.

        Args:
            tool_name: Qualified tool name (e.g., "hackernews__get_top_stories").
            arguments: Tool arguments. Defaults to empty dict.
            server_id: Deprecated — resolved from qualified name.
            server_name: Deprecated — resolved from qualified name.
            bundle_id: Optional bundle context.
            agent_id: Optional agent context.

        Returns:
            A ToolExecuteResult with the output and execution metadata.
        """
        body: dict[str, Any] = {
            "tool_name": tool_name,
            "arguments": arguments or {},
        }
        if server_id is not None:
            body["server_id"] = str(server_id)
        if server_name is not None:
            body["server_name"] = server_name
        if bundle_id is not None:
            body["bundle_id"] = str(bundle_id)
        if agent_id is not None:
            body["agent_id"] = str(agent_id)

        data = await self._http.request(
            "POST",
            "/api/v1/tools/execute",
            json=body,
        )
        return ToolExecuteResult.model_validate(data)
