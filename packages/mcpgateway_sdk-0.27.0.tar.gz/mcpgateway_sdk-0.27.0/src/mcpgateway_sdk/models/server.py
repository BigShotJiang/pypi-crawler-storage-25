"""Server models."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Server(BaseModel):
    """An MCP server registered with the gateway."""

    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    display_name: str = ""
    description: str | None = None
    icon_url: str | None = None
    type: str
    status: str = "unknown"
    config: dict[str, Any] = {}
    source: str = ""
    source_doc_url: str | None = None
    credential_mode: str = "none"
    exposure_mode: str = "all"
    portal_visible: bool = False
    portal_category: str | None = None
    portal_tags: list[str] = []
    tool_count: int = 0
    last_synced_at: datetime | None = None
    last_error: str | None = None
    oauth_config: dict[str, Any] | None = None
    credential_requirements: list[dict[str, Any]] = []
    created_at: datetime | None = None
    updated_at: datetime | None = None
    mcp_endpoint_url: str | None = None
