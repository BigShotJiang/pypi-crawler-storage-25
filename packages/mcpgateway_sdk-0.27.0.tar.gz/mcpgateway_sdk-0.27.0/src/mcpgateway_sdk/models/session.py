"""Pydantic model for session responses."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Session(BaseModel):
    """A gateway session with optional per-session tool scoping.

    Fields match the backend ``SessionResponse`` schema
    (see ``backend/src/mcpgateway/schemas/session.py``).
    """

    model_config = ConfigDict(extra="ignore")

    id: UUID
    server_id: UUID | None = None
    bundle_id: UUID | None = None
    process_state: dict[str, Any] = {}
    external_sessions: dict[str, str] = {}
    last_accessed_at: datetime
    expires_at: datetime
    is_active: bool = True
    is_expired: bool = False
    is_idle: bool = False
    created_at: datetime
    allowed_tool_names: list[str] | None = None
    denied_tool_names: list[str] | None = None
