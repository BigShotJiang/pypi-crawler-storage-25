"""Pydantic models for MCPGateway SDK responses."""

from mcpgateway_sdk.models.api_key import ApiKey, ApiKeyCreate
from mcpgateway_sdk.models.bundle import (
    Bundle,
    BundleDetail,
    BundleTool,
    BundleWithKey,
    ServerAssignment,
)
from mcpgateway_sdk.models.common import PaginatedResponse
from mcpgateway_sdk.models.connection import (
    BasicConnection,
    BundleConnection,
    Connection,
    ConnectionCreated,
    OAuthAuthorization,
)
from mcpgateway_sdk.models.sandbox import ExecResult, Sandbox, SandboxCreate, SandboxFile
from mcpgateway_sdk.models.server import Server
from mcpgateway_sdk.models.session import Session
from mcpgateway_sdk.models.skill import AttachResult, Skill, SkillCatalogEntry
from mcpgateway_sdk.models.tool import ToolExecuteResult, ToolLookup, ToolSearchResult

__all__ = [
    "ApiKey",
    "ApiKeyCreate",
    "AttachResult",
    "BasicConnection",
    "Bundle",
    "BundleConnection",
    "BundleDetail",
    "BundleTool",
    "BundleWithKey",
    "Connection",
    "ConnectionCreated",
    "ExecResult",
    "OAuthAuthorization",
    "PaginatedResponse",
    "Sandbox",
    "SandboxCreate",
    "SandboxFile",
    "Server",
    "ServerAssignment",
    "Session",
    "Skill",
    "SkillCatalogEntry",
    "ToolExecuteResult",
    "ToolLookup",
    "ToolSearchResult",
]
