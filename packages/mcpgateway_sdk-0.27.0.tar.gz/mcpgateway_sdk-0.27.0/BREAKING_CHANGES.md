# SDK Breaking Changes — v0.23.0

## Servers API

### `ServersResource.configure_oauth()` removed

The `configure_oauth()` method is removed. The corresponding backend endpoint
(`POST /api/v1/servers/{server_id}/oauth-config`) was never functional and has
been removed in the same release. Use the OAuth apps endpoints
(`POST /api/v1/oauth-apps` + `POST /api/v1/oauth-apps/{app_id}/servers/{server_id}`)
to link a reusable OAuth app to a server instead. (#624)

`ServersResource.get_oauth_config()` and `ServersResource.delete_oauth_config()`
are unchanged.

## Connections API

### `connections.revoke()` renamed to `connections.delete()`

The `revoke()` method has been renamed to `delete()` to reflect the new behavior:
connections are now permanently deleted from the database instead of soft-deleted.

**Before (v0.22.x):**

```python
await client.connections.revoke(connection_id)
# Connection still in DB with is_valid=False, revoked_at set
```

**After (v0.23.0):**

```python
await client.connections.delete(connection_id)
# Connection permanently removed from DB
```

### `connections.list()` parameter rename

`include_revoked` parameter renamed to `include_invalid`.

**Before:**

```python
connections = await client.connections.list(include_revoked=True)
```

**After:**

```python
connections = await client.connections.list(include_invalid=True)
```

`include_invalid=True` now returns connections that failed token refresh
(consecutive failures). Revoked connections no longer exist in the database.

### `Connection` model fields removed

The following fields have been removed from the `Connection` response model:

- `revoked_at: datetime | None` -- removed (connections are hard-deleted)
- `revoke_reason: str | None` -- removed (connections are hard-deleted)

### Multiple connections per server

The unique constraint on `(user_id, server_id)` has been removed. A user can
now have multiple connections to the same server (e.g., personal Gmail +
work Gmail). This means:

- `POST /api/v1/connections` no longer returns 409 for duplicate server
- Each connection has its own `id` -- use the `id` to manage specific connections
- Assign specific connections to bundles via the bundle connections API

### Migration guide for vivi-app

1. Replace `client.connections.revoke(id)` with `client.connections.delete(id)`
2. Replace `include_revoked=True` with `include_invalid=True` in list calls
3. Remove references to `connection.revoked_at` and `connection.revoke_reason`
4. If creating connections: no longer need to handle 409 for same-server duplicates
