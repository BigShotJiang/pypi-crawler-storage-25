from pathlib import Path

from setuptools import find_packages, setup

LONG_DESCRIPTION = (Path(__file__).parent / "deliberaide_cli" / "README.md").read_text(encoding="utf-8")


setup(
    name="deliberaide-cli",
    version="0.1.0",
    description="Stateful, agent-native CLI for the deliberAIde v2 API",
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    author="deliberAIde",
    author_email="hello@deliberaide.com",
    url="https://deliberaide.com",
    project_urls={
        "Homepage": "https://deliberaide.com",
        "Platform": "https://platform.deliberaide.com",
    },
    license="Proprietary",
    packages=find_packages(include=["deliberaide_cli", "deliberaide_cli.*"]),
    include_package_data=True,
    package_data={"deliberaide_cli": ["route_manifest.json", "README.md"]},
    install_requires=[
        "click>=8.1.7",
        "httpx>=0.28.1",
        "prompt-toolkit>=3.0.48",
        "websockets>=12.0",
    ],
    entry_points={
        "console_scripts": [
            "deliberaide-cli=deliberaide_cli.deliberaide_cli:main",
        ]
    },
    python_requires=">=3.11",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
