from __future__ import annotations

import shlex
import sys
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse
from typing import Any

import click
from websockets.sync.client import connect as websocket_connect

from deliberaide_cli import __version__
from deliberaide_cli.core.manifest import FieldSpec, OperationSpec, load_manifest
from deliberaide_cli.core.session import ProfileState, ProfileStore, normalize_base_url
from deliberaide_cli.utils.api_backend import ApiBackend, decode_response
from deliberaide_cli.utils.formatting import (
    coerce_value,
    json_dumps,
    load_json_file,
    load_text_file,
    parse_assignment,
    schema_template,
)
from deliberaide_cli.utils.repl_skin import ReplSkin


CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}
DEFAULT_PROFILE = "default"
MANIFEST = load_manifest()


@dataclass(slots=True)
class CliRuntime:
    manifest: Any
    store: ProfileStore
    profile: ProfileState
    profile_name: str
    backend: ApiBackend
    json_output: bool
    auto_refresh: bool

    def save(self) -> None:
        self.profile.base_url = normalize_base_url(self.profile.base_url)
        self.profile.cookies = self.backend.export_cookies()
        self.store.save(self.profile)

    def reset_backend(self) -> None:
        self.backend = ApiBackend(
            self.profile.base_url,
            self.profile.timeout_seconds,
            cookies=self.profile.cookies,
        )


def _coerce_generic_value(raw_value: str) -> Any:
    lowered = raw_value.strip().lower()
    if lowered in {"true", "false", "null"}:
        return {"true": True, "false": False, "null": None}[lowered]
    try:
        return load_json_value(raw_value)
    except Exception:
        return raw_value


def load_json_value(raw_value: str) -> Any:
    import json

    return json.loads(raw_value)


def _ensure_runtime(ctx: click.Context, profile_name: str, base_url: str | None, timeout_seconds: float | None, json_output: bool, auto_refresh: bool) -> CliRuntime:
    existing = ctx.obj if isinstance(ctx.obj, CliRuntime) else None
    if existing is not None:
        if base_url:
            existing.profile.base_url = normalize_base_url(base_url)
            existing.reset_backend()
        if timeout_seconds is not None:
            existing.profile.timeout_seconds = timeout_seconds
            existing.reset_backend()
        existing.json_output = json_output
        existing.auto_refresh = auto_refresh
        return existing

    store = ProfileStore()
    profile = store.load(profile_name)
    if base_url:
        profile.base_url = normalize_base_url(base_url)
    if timeout_seconds is not None:
        profile.timeout_seconds = timeout_seconds
    backend = ApiBackend(profile.base_url, profile.timeout_seconds, cookies=profile.cookies)
    runtime = CliRuntime(
        manifest=MANIFEST,
        store=store,
        profile=profile,
        profile_name=profile_name,
        backend=backend,
        json_output=json_output,
        auto_refresh=auto_refresh,
    )
    return runtime


@click.group(invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
@click.option("--profile", "profile_name", default=DEFAULT_PROFILE, show_default=True, help="Saved CLI profile to use.")
@click.option("--base-url", default=None, help="Override the saved API base URL for this run.")
@click.option("--timeout", "timeout_seconds", type=float, default=None, help="Request timeout in seconds.")
@click.option("--json", "json_output", is_flag=True, help="Emit machine-readable JSON envelopes.")
@click.option("--auto-refresh/--no-auto-refresh", default=True, show_default=True, help="Retry once after refreshing auth cookies on 401 responses.")
@click.pass_context
def cli(ctx: click.Context, profile_name: str, base_url: str | None, timeout_seconds: float | None, json_output: bool, auto_refresh: bool) -> None:
    runtime = _ensure_runtime(ctx, profile_name, base_url, timeout_seconds, json_output, auto_refresh)
    ctx.obj = runtime
    if ctx.invoked_subcommand is None:
        ctx.invoke(repl)


def _render_human(envelope: dict[str, Any]) -> None:
    request = envelope["request"]
    response = envelope["response"]
    click.echo(f"{request['method']} {request['path']} -> {response['status_code']}")
    if response.get("saved_to"):
        click.echo(f"Saved to {response['saved_to']}")
    body = response.get("body")
    body_kind = response.get("body_kind")
    if body is None:
        return
    if body_kind == "json":
        click.echo(json_dumps(body))
        return
    if body_kind == "text":
        click.echo(body)
        return
    click.echo(json_dumps(body))


def _emit_result(runtime: CliRuntime, envelope: dict[str, Any], success: bool) -> None:
    if runtime.json_output:
        click.echo(json_dumps(envelope, compact=True))
    else:
        _render_human(envelope)
    if not success:
        raise SystemExit(1)


def _binary_metadata(payload: bytes, content_type: str | None, filename: str | None, saved_to: str | None) -> dict[str, Any]:
    return {
        "content_type": content_type,
        "filename": filename,
        "size_bytes": len(payload),
        "saved_to": saved_to,
    }


def _save_binary(path_option: Path, default_name: str, payload: bytes) -> Path:
    path = path_option
    if path.exists() and path.is_dir():
        path = path / default_name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    return path


def _response_envelope(operation: OperationSpec, response: Any, decoded: Any, saved_to: str | None = None) -> dict[str, Any]:
    if decoded.kind == "json":
        body = decoded.value
    elif decoded.kind == "text":
        body = decoded.value
    else:
        body = _binary_metadata(decoded.value, decoded.content_type, decoded.filename, saved_to)

    return {
        "ok": response.is_success,
        "operation": operation.operation_key,
        "request": {
            "method": operation.method,
            "path": operation.path,
            "url": str(response.request.url),
        },
        "response": {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "body_kind": decoded.kind,
            "body": body,
            "saved_to": saved_to,
        },
    }


def _error_detail(decoded: Any) -> str:
    if decoded.kind == "json":
        if isinstance(decoded.value, dict) and "detail" in decoded.value:
            return str(decoded.value["detail"])
        return json_dumps(decoded.value)
    if decoded.kind == "text":
        return decoded.value.strip() or "Request failed"
    return f"Binary error response ({decoded.content_type or 'unknown'})"


def _value_from_runtime(runtime: CliRuntime, raw_value: Any, name: str, required: bool) -> Any:
    value = raw_value
    if value in {None, ""}:
        value = runtime.profile.defaults.get(name)
    if value in {None, ""} and required:
        raise click.ClickException(f"Missing required value: {name}")
    return value


def _build_headers(runtime: CliRuntime, operation: OperationSpec, option_values: dict[str, Any], extra_headers: tuple[str, ...]) -> dict[str, str]:
    headers: dict[str, str] = {}
    for parameter in operation.header_parameters:
        value = _value_from_runtime(runtime, option_values.get(parameter.cli_name), parameter.cli_name, parameter.required)
        if value not in {None, ""}:
            headers[parameter.name] = str(value)
    for raw_header in extra_headers:
        key, value = parse_assignment(raw_header)
        headers[key] = value
    return headers


def _build_path(runtime: CliRuntime, operation: OperationSpec, option_values: dict[str, Any]) -> str:
    path = operation.path
    for parameter in operation.path_parameters:
        value = _value_from_runtime(runtime, option_values.get(parameter.cli_name), parameter.cli_name, parameter.required)
        if value in {None, ""}:
            continue
        path = path.replace("{" + parameter.name + "}", str(value))
    return path


def _build_query(runtime: CliRuntime, operation: OperationSpec, option_values: dict[str, Any]) -> dict[str, str] | None:
    query: dict[str, str] = {}
    for parameter in operation.query_parameters:
        value = _value_from_runtime(runtime, option_values.get(parameter.cli_name), parameter.cli_name, parameter.required)
        if value in {None, ""}:
            continue
        query[parameter.name] = str(value)
    return query or None


def _extract_direct_body_values(body_bindings: dict[str, FieldSpec], option_values: dict[str, Any]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for internal_key, field in body_bindings.items():
        raw_value = option_values.get(internal_key)
        if raw_value in {None, ""} or raw_value == ():
            continue
        values[field.name] = raw_value
    return values


def _build_json_body(body_spec: Any, direct_values: dict[str, Any], raw_body: str | None, body_file: Path | None, set_values: tuple[str, ...], set_files: tuple[str, ...]) -> Any:
    if raw_body and body_file:
        raise click.ClickException("Use either --body or --body-file, not both.")

    payload = None
    if body_file is not None:
        payload = load_json_file(body_file)
    elif raw_body is not None:
        payload = load_json_value(raw_body)

    if payload is None:
        payload = {}

    if direct_values or set_values or set_files:
        if not isinstance(payload, dict):
            raise click.ClickException("Direct field flags can only be used with object JSON bodies.")
        for field in body_spec.fields:
            if field.name not in direct_values:
                continue
            payload[field.name] = coerce_value(str(direct_values[field.name]), field.schema)
        for raw_value in set_values:
            key, value = parse_assignment(raw_value)
            payload[key] = _coerce_generic_value(value)
        for raw_value in set_files:
            key, file_name = parse_assignment(raw_value)
            payload[key] = load_json_file(Path(file_name))

    if body_spec.required and payload is None:
        raise click.ClickException("This route requires a JSON request body.")
    if body_spec.required and payload == {} and not (direct_values or raw_body or body_file or set_values or set_files):
        raise click.ClickException("This route requires a JSON request body.")
    return payload


def _build_form_body(body_spec: Any, direct_values: dict[str, Any], set_values: tuple[str, ...], set_files: tuple[str, ...]) -> tuple[dict[str, str] | None, list[tuple[str, Path]] | None]:
    data: dict[str, str] = {}
    uploads: list[tuple[str, Path]] = []

    for field in body_spec.fields:
        if field.name not in direct_values:
            continue
        value = direct_values[field.name]
        if field.is_file:
            if field.allows_multiple:
                for item in value:
                    uploads.append((field.name, item))
            else:
                uploads.append((field.name, value))
            continue
        data[field.name] = str(value)

    for raw_value in set_values:
        key, value = parse_assignment(raw_value)
        data[key] = value
    for raw_value in set_files:
        key, file_name = parse_assignment(raw_value)
        data[key] = load_text_file(Path(file_name))

    if body_spec.required and not data and not uploads:
        raise click.ClickException("This route requires form fields or file uploads.")
    return data or None, uploads or None


def invoke_http_operation(runtime: CliRuntime, operation: OperationSpec, body_bindings: dict[str, FieldSpec], option_values: dict[str, Any]) -> None:
    extra_headers = option_values.pop("extra_headers", ())
    download = option_values.pop("download", None)
    raw_body = option_values.pop("body", None)
    body_file = option_values.pop("body_file", None)
    set_values = option_values.pop("set_values", ())
    set_files = option_values.pop("set_files", ())

    path = _build_path(runtime, operation, option_values)
    query = _build_query(runtime, operation, option_values)
    headers = _build_headers(runtime, operation, option_values, extra_headers)
    direct_values = _extract_direct_body_values(body_bindings, option_values)

    json_body = None
    data = None
    uploads = None
    if operation.request_body is not None:
        if operation.request_body.is_json:
            json_body = _build_json_body(operation.request_body, direct_values, raw_body, body_file, set_values, set_files)
        elif operation.request_body.is_form:
            if raw_body or body_file:
                raise click.ClickException("Use field flags or --set for form routes, not --body/--body-file.")
            data, uploads = _build_form_body(operation.request_body, direct_values, set_values, set_files)
        elif operation.request_body.required:
            raise click.ClickException("This route uses an unsupported request body content type.")
    elif raw_body or body_file or set_values or set_files or direct_values:
        raise click.ClickException("This route does not accept a request body.")

    response = runtime.backend.request(
        operation.method or "GET",
        path,
        params=query,
        headers=headers,
        json_body=json_body,
        data=data,
        uploads=uploads,
        allow_refresh=runtime.auto_refresh,
    )
    runtime.save()

    decoded = decode_response(response)
    saved_to = None
    if decoded.kind == "binary" and download is not None:
        saved_path = _save_binary(download, decoded.filename or f"{operation.command_name}.bin", decoded.value)
        saved_to = str(saved_path)
    envelope = _response_envelope(operation, response, decoded, saved_to)
    if not response.is_success:
        if not runtime.json_output:
            raise click.ClickException(_error_detail(decoded))
        _emit_result(runtime, envelope, success=False)
        return
    _emit_result(runtime, envelope, success=True)


def invoke_websocket_operation(runtime: CliRuntime, operation: OperationSpec, option_values: dict[str, Any]) -> None:
    extra_headers = option_values.pop("extra_headers", ())
    messages = option_values.pop("messages", ())
    json_messages = option_values.pop("json_messages", ())
    receive_count = option_values.pop("receive_count", 1)
    stdin_mode = option_values.pop("stdin_mode", False)

    path = _build_path(runtime, operation, option_values)
    query = _build_query(runtime, operation, option_values)
    headers = _build_headers(runtime, operation, option_values, extra_headers)

    cookie_header = "; ".join(
        f"{cookie.name}={cookie.value}" for cookie in runtime.backend.export_cookies() if cookie.value
    )
    if cookie_header and "Cookie" not in headers:
        headers["Cookie"] = cookie_header

    url = runtime.backend.build_websocket_url(path, query)
    received: list[str] = []
    with websocket_connect(url, additional_headers=headers or None, open_timeout=runtime.profile.timeout_seconds) as websocket:
        for message in messages:
            websocket.send(message)
        for raw_message in json_messages:
            websocket.send(json_dumps(load_json_value(raw_message), compact=True))
        if stdin_mode:
            for line in sys.stdin:
                websocket.send(line.rstrip("\n"))
        for _ in range(max(receive_count, 0)):
            received.append(websocket.recv())

    envelope = {
        "ok": True,
        "operation": operation.operation_key,
        "request": {
            "method": "WEBSOCKET",
            "path": operation.path,
            "url": url,
        },
        "response": {
            "status_code": 101,
            "headers": headers,
            "body_kind": "json" if runtime.json_output else "text",
            "body": {"messages": received} if runtime.json_output else "\n".join(received),
            "saved_to": None,
        },
    }
    _emit_result(runtime, envelope, success=True)


@cli.group()
@click.pass_obj
def routes(runtime: CliRuntime) -> None:
    """Inspect the generated route manifest."""


@routes.command("list")
@click.option("--group", "group_name", default=None, help="Filter by route group.")
@click.option("--kind", type=click.Choice(["http", "websocket", "all"]), default="all", show_default=True)
@click.pass_obj
def routes_list(runtime: CliRuntime, group_name: str | None, kind: str) -> None:
    rows: list[dict[str, Any]] = []
    for operation in runtime.manifest.all_operations:
        if group_name and operation.group != group_name:
            continue
        if kind != "all" and operation.kind != kind:
            continue
        rows.append(
            {
                "operation": operation.operation_key,
                "method": operation.method or "WS",
                "path": operation.path,
                "group": operation.group,
            }
        )
    if runtime.json_output:
        click.echo(json_dumps({"items": rows}, compact=True))
        return
    for row in rows:
        click.echo(f"{row['operation']:<45} {row['method']:<6} {row['path']}")


@routes.command("show")
@click.argument("operation_key")
@click.pass_obj
def routes_show(runtime: CliRuntime, operation_key: str) -> None:
    operation = runtime.manifest.find_operation(operation_key)
    if operation is None:
        raise click.ClickException(f"Unknown operation: {operation_key}")

    payload = {
        "operation": operation.operation_key,
        "kind": operation.kind,
        "group": operation.group,
        "method": operation.method,
        "path": operation.path,
        "parameters": [
            {
                "name": item.name,
                "cli_name": item.cli_name,
                "location": item.location,
                "required": item.required,
            }
            for item in operation.parameters
        ],
        "request_body": None,
    }
    if operation.request_body is not None:
        payload["request_body"] = {
            "required": operation.request_body.required,
            "content_types": list(operation.request_body.content_types),
            "fields": [
                {
                    "name": item.name,
                    "cli_name": item.cli_name,
                    "required": item.required,
                    "is_file": item.is_file,
                }
                for item in operation.request_body.fields
            ],
            "template": schema_template(operation.request_body.schema),
        }
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo(f"{operation.operation_key}\n{operation.method or 'WS'} {operation.path}")
    if payload["parameters"]:
        click.echo("Parameters:")
        for item in payload["parameters"]:
            required = "required" if item["required"] else "optional"
            click.echo(f"  --{item['cli_name'].replace('_', '-')} ({item['location']}, {required})")
    if payload["request_body"] is not None:
        click.echo("Request body:")
        click.echo(json_dumps(payload["request_body"]))


@routes.command("search")
@click.argument("term")
@click.pass_obj
def routes_search(runtime: CliRuntime, term: str) -> None:
    lowered = term.lower()
    matches = [
        operation for operation in runtime.manifest.all_operations
        if lowered in operation.operation_key.lower() or lowered in operation.path.lower()
    ]
    payload = {
        "count": len(matches),
        "items": [
            {
                "operation": operation.operation_key,
                "method": operation.method or "WS",
                "path": operation.path,
            }
            for operation in matches
        ],
    }
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    for item in payload["items"]:
        click.echo(f"{item['operation']:<45} {item['method']:<6} {item['path']}")


@cli.group()
@click.pass_obj
def profile(runtime: CliRuntime) -> None:
    """Manage saved connection profiles."""


@profile.command("show")
@click.pass_obj
def profile_show(runtime: CliRuntime) -> None:
    payload = {
        "name": runtime.profile_name,
        "base_url": runtime.profile.base_url,
        "timeout_seconds": runtime.profile.timeout_seconds,
        "defaults": runtime.profile.defaults,
        "cookie_count": len(runtime.profile.cookies),
    }
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo(json_dumps(payload))


@profile.command("list")
@click.pass_obj
def profile_list(runtime: CliRuntime) -> None:
    payload = {"items": runtime.store.list_profiles()}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    for item in payload["items"]:
        click.echo(item)


@profile.command("set-base-url")
@click.argument("base_url")
@click.pass_obj
def profile_set_base_url(runtime: CliRuntime, base_url: str) -> None:
    runtime.profile.base_url = normalize_base_url(base_url)
    runtime.reset_backend()
    runtime.save()
    payload = {"ok": True, "base_url": runtime.profile.base_url}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo(f"Base URL set to {runtime.profile.base_url}")


@profile.command("clear-cookies")
@click.pass_obj
def profile_clear_cookies(runtime: CliRuntime) -> None:
    runtime.store.clear_cookies(runtime.profile)
    runtime.reset_backend()
    runtime.save()
    payload = {"ok": True, "cookie_count": 0}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo("Saved cookies cleared.")


@cli.group()
@click.pass_obj
def context(runtime: CliRuntime) -> None:
    """Manage saved default identifiers and headers."""


@context.command("show")
@click.pass_obj
def context_show(runtime: CliRuntime) -> None:
    payload = {"defaults": runtime.profile.defaults}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo(json_dumps(payload))


@context.command("set")
@click.argument("key")
@click.argument("value")
@click.pass_obj
def context_set(runtime: CliRuntime, key: str, value: str) -> None:
    runtime.store.set_default(runtime.profile, key, value)
    runtime.save()
    payload = {"ok": True, "defaults": runtime.profile.defaults}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo(f"Saved {key}={value}")


@context.command("unset")
@click.argument("key")
@click.pass_obj
def context_unset(runtime: CliRuntime, key: str) -> None:
    runtime.store.unset_default(runtime.profile, key)
    runtime.save()
    payload = {"ok": True, "defaults": runtime.profile.defaults}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo(f"Removed {key}")


@context.command("clear")
@click.pass_obj
def context_clear(runtime: CliRuntime) -> None:
    runtime.store.clear_defaults(runtime.profile)
    runtime.save()
    payload = {"ok": True, "defaults": runtime.profile.defaults}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo("Saved defaults cleared.")


@context.command("undo")
@click.pass_obj
def context_undo(runtime: CliRuntime) -> None:
    if not runtime.store.undo_defaults(runtime.profile):
        raise click.ClickException("Nothing to undo.")
    runtime.save()
    payload = {"ok": True, "defaults": runtime.profile.defaults}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo("Restored the previous saved-default state.")


@context.command("redo")
@click.pass_obj
def context_redo(runtime: CliRuntime) -> None:
    if not runtime.store.redo_defaults(runtime.profile):
        raise click.ClickException("Nothing to redo.")
    runtime.save()
    payload = {"ok": True, "defaults": runtime.profile.defaults}
    if runtime.json_output:
        click.echo(json_dumps(payload, compact=True))
        return
    click.echo("Re-applied the next saved-default state.")


@cli.command()
@click.pass_obj
def repl(runtime: CliRuntime) -> None:
    """Start the interactive shell."""
    history_path = runtime.store.home_dir / "history" / f"{runtime.profile_name}.txt"
    skin = ReplSkin("deliberaide-cli", __version__, history_path)
    session = skin.create_prompt_session()
    skin.print_banner()
    while True:
        try:
            line = skin.get_input(session, runtime.profile_name, runtime.profile.base_url)
        except (EOFError, KeyboardInterrupt):
            break
        line = line.strip()
        if not line:
            continue
        if line in {"exit", "quit"}:
            break
        try:
            args = shlex.split(line)
            cli.main(args=args, prog_name="deliberaide-cli", standalone_mode=False, obj=runtime)
        except SystemExit as exc:
            if exc.code not in {0, None}:
                skin.error(f"Command failed with exit code {exc.code}")
        except click.ClickException as exc:
            skin.error(exc.format_message())
        except Exception as exc:
            skin.error(str(exc))
    skin.print_goodbye()


def _store_cli_auth_tokens(
    runtime: CliRuntime,
    *,
    access_cookie_name: str,
    access_token: str,
    refresh_cookie_name: str,
    refresh_token: str,
) -> None:
    hostname = urlparse(runtime.profile.base_url).hostname or ""
    runtime.backend.client.cookies.set(
        access_cookie_name,
        access_token,
        domain=hostname,
        path="/",
    )
    runtime.backend.client.cookies.set(
        refresh_cookie_name,
        refresh_token,
        domain=hostname,
        path="/",
    )
    runtime.save()


def _login_with_credentials(runtime: CliRuntime, email: str, password: str) -> None:
    response = runtime.backend.request(
        "POST",
        "/api/v1/auth/login",
        json_body={"email": email, "password": password},
        allow_refresh=False,
    )
    runtime.save()
    decoded = decode_response(response)
    if not response.is_success:
        raise click.ClickException(_error_detail(decoded))

    if runtime.json_output:
        _emit_result(
            runtime,
            _response_envelope(
                OperationSpec(
                    kind="http",
                    group="auth",
                    command_name="login",
                    operation_key="auth.login",
                    method="POST",
                    path="/api/v1/auth/login",
                    route_name="login",
                ),
                response,
                decoded,
            ),
            success=True,
        )
        return

    click.echo("Signed in successfully.")


def _login_with_browser(
    runtime: CliRuntime,
    *,
    open_browser: bool,
    timeout_seconds: float,
    poll_interval: float | None,
) -> None:
    start_response = runtime.backend.request(
        "POST",
        "/api/v1/auth/cli/sessions",
        allow_refresh=False,
    )
    start_decoded = decode_response(start_response)
    if not start_response.is_success:
        raise click.ClickException(_error_detail(start_decoded))

    payload = start_decoded.value
    verification_url = payload["verification_url"]
    poll_path = payload["poll_path"]
    interval_seconds = float(payload.get("interval_seconds") or 2)
    effective_interval = poll_interval if poll_interval is not None else interval_seconds

    if open_browser:
        webbrowser.open(verification_url, new=2)

    if not runtime.json_output:
        click.echo("Browser sign-in started.")
        click.echo(f"Open this page if it does not launch automatically: {verification_url}")

    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        poll_response = runtime.backend.request(
            "GET",
            poll_path,
            allow_refresh=False,
        )
        poll_decoded = decode_response(poll_response)
        if not poll_response.is_success:
            raise click.ClickException(_error_detail(poll_decoded))

        poll_payload = poll_decoded.value
        status_value = poll_payload["status"]
        if status_value == "approved":
            _store_cli_auth_tokens(
                runtime,
                access_cookie_name=poll_payload["access_cookie_name"],
                access_token=poll_payload["access_token"],
                refresh_cookie_name=poll_payload["refresh_cookie_name"],
                refresh_token=poll_payload["refresh_token"],
            )
            if runtime.json_output:
                click.echo(json_dumps({
                    "ok": True,
                    "status": "approved",
                    "message": poll_payload.get("message"),
                }, compact=True))
            else:
                click.echo("Browser sign-in completed.")
            return
        if status_value in {"expired", "not_found", "consumed"}:
            raise click.ClickException(poll_payload.get("message") or "Browser sign-in did not complete.")
        time.sleep(max(effective_interval, 0.2))

    raise click.ClickException("Timed out waiting for browser sign-in approval.")


def _install_custom_auth_commands() -> None:
    auth_group = cli.commands.get("auth")
    if not isinstance(auth_group, click.Group):
        return

    auth_group.commands.pop("login", None)

    @click.command("login")
    @click.option("--email", default=None, help="Direct sign-in email. If omitted, browser sign-in is used.")
    @click.option("--password", default=None, hide_input=True, help="Direct sign-in password.")
    @click.option("--open-browser/--no-open-browser", default=True, show_default=True, help="Open the verification page automatically for browser sign-in.")
    @click.option("--timeout-seconds", type=float, default=300.0, show_default=True, help="How long to wait for browser approval.")
    @click.option("--poll-interval", type=float, default=None, help="Override the server-provided poll interval in seconds.")
    @click.pass_obj
    def auth_login(
        runtime: CliRuntime,
        email: str | None,
        password: str | None,
        open_browser: bool,
        timeout_seconds: float,
        poll_interval: float | None,
    ) -> None:
        if bool(email) != bool(password):
            raise click.ClickException("Provide both --email and --password, or neither.")
        if email and password:
            _login_with_credentials(runtime, email, password)
            return
        _login_with_browser(
            runtime,
            open_browser=open_browser,
            timeout_seconds=timeout_seconds,
            poll_interval=poll_interval,
        )

    auth_group.add_command(auth_login)


def _parameter_help(parameter: Any) -> str:
    required = "required" if parameter.required else "optional"
    return f"{parameter.location} parameter ({required})"


def _field_help(field: FieldSpec) -> str:
    required = "required" if field.required else "optional"
    suffix = "file field" if field.is_file else "body field"
    return f"{suffix} ({required})"


def build_http_command(operation: OperationSpec) -> click.Command:
    params: list[click.Parameter] = []
    existing_names: set[str] = set()
    body_bindings: dict[str, FieldSpec] = {}

    for parameter in operation.parameters:
        option_name = f"--{parameter.cli_name.replace('_', '-')}"
        params.append(
            click.Option([option_name, parameter.cli_name], default=None, help=_parameter_help(parameter))
        )
        existing_names.add(parameter.cli_name)

    if operation.request_body is not None:
        for field in operation.request_body.fields:
            internal_key = field.cli_name
            option_label = field.cli_name
            if option_label in existing_names:
                internal_key = f"body__{field.cli_name}"
                option_label = f"body-{field.cli_name}"
            option_name = f"--{option_label.replace('_', '-')}"
            kwargs: dict[str, Any] = {"default": None, "help": _field_help(field)}
            if field.is_file:
                kwargs["type"] = click.Path(exists=True, dir_okay=False, path_type=Path)
            else:
                kwargs["type"] = str
            if field.allows_multiple:
                kwargs["multiple"] = True
                kwargs["default"] = ()
            params.append(click.Option([option_name, internal_key], **kwargs))
            body_bindings[internal_key] = field
            existing_names.add(option_label)

    params.extend(
        [
            click.Option(["--body", "body"], default=None, help="Raw JSON request body."),
            click.Option(["--body-file", "body_file"], type=click.Path(exists=True, dir_okay=False, path_type=Path), default=None, help="Load a JSON request body from a file."),
            click.Option(["--set", "set_values"], multiple=True, help="Set a top-level request field as KEY=VALUE."),
            click.Option(["--set-file", "set_files"], multiple=True, help="Set a top-level request field from a file as KEY=PATH."),
            click.Option(["--header", "extra_headers"], multiple=True, help="Add a request header as KEY=VALUE."),
            click.Option(["--download", "download"], type=click.Path(path_type=Path), default=None, help="Save a binary response to a file path."),
        ]
    )

    @click.pass_obj
    def callback(runtime: CliRuntime, **kwargs: Any) -> None:
        invoke_http_operation(runtime, operation, body_bindings, kwargs)

    return click.Command(
        operation.command_name,
        params=params,
        callback=callback,
        help=f"{operation.method} {operation.path}",
    )


def build_websocket_command(operation: OperationSpec) -> click.Command:
    params: list[click.Parameter] = []
    for parameter in operation.parameters:
        option_name = f"--{parameter.cli_name.replace('_', '-')}"
        params.append(
            click.Option([option_name, parameter.cli_name], default=None, help=_parameter_help(parameter))
        )

    params.extend(
        [
            click.Option(["--message", "messages"], multiple=True, help="Send a raw text message after connecting."),
            click.Option(["--message-json", "json_messages"], multiple=True, help="Send a JSON-encoded message after connecting."),
            click.Option(["--receive", "receive_count"], type=int, default=1, show_default=True, help="How many messages to read before closing."),
            click.Option(["--stdin", "stdin_mode"], is_flag=True, help="Read outgoing messages from stdin until EOF."),
            click.Option(["--header", "extra_headers"], multiple=True, help="Add a WebSocket header as KEY=VALUE."),
        ]
    )

    @click.pass_obj
    def callback(runtime: CliRuntime, **kwargs: Any) -> None:
        invoke_websocket_operation(runtime, operation, kwargs)

    return click.Command(
        operation.command_name,
        params=params,
        callback=callback,
        help=f"WS {operation.path}",
    )


def register_dynamic_commands(root: click.Group) -> None:
    groups: dict[str, click.Group] = {}
    for operation in MANIFEST.http_operations:
        group = groups.setdefault(operation.group, click.Group(operation.group))
        group.add_command(build_http_command(operation))
    ws_group = click.Group("ws")
    for operation in MANIFEST.websocket_operations:
        ws_group.add_command(build_websocket_command(operation))
    groups["ws"] = ws_group
    for name, group in sorted(groups.items()):
        if name not in root.commands:
            root.add_command(group)


register_dynamic_commands(cli)
_install_custom_auth_commands()


def main() -> None:
    cli.main(prog_name="deliberaide-cli")


if __name__ == "__main__":
    main()
