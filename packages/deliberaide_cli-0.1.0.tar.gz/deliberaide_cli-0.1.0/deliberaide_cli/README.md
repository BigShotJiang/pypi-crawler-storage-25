# deliberaide-cli

`deliberaide-cli` is a stateful command-line harness for the DeliberAIde v2 API.
It wraps the running FastAPI server over HTTP and WebSockets, keeps a saved profile,
and exposes every discovered route through generated command groups.

## What it supports

- One-shot commands for the current HTTP route surface
- One-shot commands for the current WebSocket route surface
- Interactive shell mode when you run `deliberaide-cli` with no subcommand
- Browser-based CLI sign-in through the DeliberAIde web app
- Saved base URLs, cookies, and default IDs per profile
- Machine-readable output with `--json`
- Binary downloads with `--download`

## Install

From the repository root:

```powershell
python -m pip install -e .\agent-harness
```

If you prefer a project virtual environment, run the same command with that Python executable instead.

## Basic usage

```powershell
deliberaide-cli --help
deliberaide-cli routes list
deliberaide-cli auth login
deliberaide-cli users get-current-user-info
deliberaide-cli context set org_id 11111111-1111-1111-1111-111111111111
deliberaide-cli projects create-project --name "Pilot workspace"
```

## Sign in from the browser

By default, `auth login` starts a CLI approval session, opens your browser, and waits for approval:

```powershell
deliberaide-cli --base-url http://127.0.0.1:8000 auth login
```

If the browser does not open automatically, copy the URL printed in the terminal into any browser on the same machine.
After you sign in and approve the request, the CLI saves the returned cookies in your active profile.

You can still fall back to direct credentials when needed:

```powershell
deliberaide-cli --base-url http://127.0.0.1:8000 auth login --email you@example.com --password secret
```

## JSON request bodies

Use direct field flags for simple object bodies:

```powershell
deliberaide-cli projects create-project --name "Pilot workspace" --description "CLI-created"
```

Use raw JSON for richer payloads:

```powershell
deliberaide-cli projects create-project --body '{"name":"Pilot workspace","target_language":"en"}'
```

Or load JSON from a file:

```powershell
deliberaide-cli projects create-project --body-file .\payload.json
```

## Multipart uploads

```powershell
deliberaide-cli upload upload-audio --file .\meeting.mp3 --discussion-id 22222222-2222-2222-2222-222222222222 --config '{"language":"en"}'
```

```powershell
deliberaide-cli upload upload-bulk --files .\a.wav --files .\b.wav --session-id 33333333-3333-3333-3333-333333333333
```

## Binary responses

```powershell
deliberaide-cli qr get-session-qr-codes-zip --session-id 44444444-4444-4444-4444-444444444444 --download .\session-qr.zip
```

## Profiles and saved defaults

```powershell
deliberaide-cli profile show
deliberaide-cli profile set-base-url http://127.0.0.1:8000
deliberaide-cli context set discussion_id 55555555-5555-5555-5555-555555555555
deliberaide-cli context show
deliberaide-cli context undo
```

## Interactive shell

Run with no subcommand to enter the shell:

```powershell
deliberaide-cli
```

Inside the shell, enter the same commands you would run normally, for example:

```text
routes list
auth login
users get-current-user-info
exit
```

## Tests

```powershell
python -m pytest .\agent-harness\deliberaide_cli\tests -v
```
