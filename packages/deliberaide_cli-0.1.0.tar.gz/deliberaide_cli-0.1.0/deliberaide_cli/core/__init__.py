"""Core helpers for deliberaide-cli."""
