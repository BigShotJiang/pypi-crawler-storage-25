from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


DEFAULT_BASE_URL = "http://127.0.0.1:8000"
DEFAULT_TIMEOUT_SECONDS = 30.0
HOME_ENV_VAR = "DELIBERAIDE_CLI_HOME"
UNDO_LIMIT = 20


@dataclass(slots=True)
class CookieRecord:
    name: str
    value: str
    domain: str
    path: str
    secure: bool = False
    expires: int | None = None


@dataclass(slots=True)
class ProfileState:
    name: str
    base_url: str = DEFAULT_BASE_URL
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS
    defaults: dict[str, str] = field(default_factory=dict)
    cookies: list[CookieRecord] = field(default_factory=list)
    undo_stack: list[dict[str, str]] = field(default_factory=list)
    redo_stack: list[dict[str, str]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ProfileState":
        return cls(
            name=payload["name"],
            base_url=payload.get("base_url", DEFAULT_BASE_URL),
            timeout_seconds=float(payload.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS)),
            defaults=dict(payload.get("defaults", {})),
            cookies=[CookieRecord(**item) for item in payload.get("cookies", [])],
            undo_stack=[dict(item) for item in payload.get("undo_stack", [])],
            redo_stack=[dict(item) for item in payload.get("redo_stack", [])],
        )

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["base_url"] = normalize_base_url(payload["base_url"])
        return payload


class ProfileStore:
    def __init__(self, home_dir: Path | None = None) -> None:
        base_dir = home_dir or _default_home_dir()
        self.home_dir = base_dir
        self.profiles_dir = self.home_dir / "profiles"
        self.profiles_dir.mkdir(parents=True, exist_ok=True)

    def profile_path(self, profile_name: str) -> Path:
        return self.profiles_dir / f"{profile_name}.json"

    def load(self, profile_name: str) -> ProfileState:
        path = self.profile_path(profile_name)
        if not path.exists():
            return ProfileState(name=profile_name)
        payload = json.loads(path.read_text(encoding="utf-8"))
        return ProfileState.from_dict(payload)

    def save(self, profile: ProfileState) -> None:
        path = self.profile_path(profile.name)
        path.write_text(json.dumps(profile.to_dict(), indent=2), encoding="utf-8")

    def list_profiles(self) -> list[str]:
        return sorted(path.stem for path in self.profiles_dir.glob("*.json"))

    def set_default(self, profile: ProfileState, key: str, value: str) -> bool:
        if profile.defaults.get(key) == value:
            return False
        _push_undo_snapshot(profile)
        profile.defaults[key] = value
        return True

    def unset_default(self, profile: ProfileState, key: str) -> bool:
        if key not in profile.defaults:
            return False
        _push_undo_snapshot(profile)
        profile.defaults.pop(key, None)
        return True

    def clear_defaults(self, profile: ProfileState) -> bool:
        if not profile.defaults:
            return False
        _push_undo_snapshot(profile)
        profile.defaults.clear()
        return True

    def undo_defaults(self, profile: ProfileState) -> bool:
        if not profile.undo_stack:
            return False
        profile.redo_stack.append(dict(profile.defaults))
        profile.defaults = profile.undo_stack.pop()
        return True

    def redo_defaults(self, profile: ProfileState) -> bool:
        if not profile.redo_stack:
            return False
        profile.undo_stack.append(dict(profile.defaults))
        profile.defaults = profile.redo_stack.pop()
        return True

    def clear_cookies(self, profile: ProfileState) -> bool:
        if not profile.cookies:
            return False
        profile.cookies.clear()
        return True


def normalize_base_url(url: str | None) -> str:
    value = (url or DEFAULT_BASE_URL).strip()
    if not value:
        return DEFAULT_BASE_URL
    return value.rstrip("/")


def _default_home_dir() -> Path:
    override = os.environ.get(HOME_ENV_VAR)
    if override:
        return Path(override).expanduser().resolve()
    return Path.home() / ".deliberaide-cli"


def _push_undo_snapshot(profile: ProfileState) -> None:
    snapshot = dict(profile.defaults)
    if profile.undo_stack and profile.undo_stack[-1] == snapshot:
        return
    profile.undo_stack.append(snapshot)
    profile.undo_stack = profile.undo_stack[-UNDO_LIMIT:]
    profile.redo_stack.clear()
