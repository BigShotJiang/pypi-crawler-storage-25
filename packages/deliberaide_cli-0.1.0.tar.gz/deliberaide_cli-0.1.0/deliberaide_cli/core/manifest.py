from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache
from importlib.resources import files
from typing import Any


@dataclass(slots=True)
class FieldSpec:
    name: str
    cli_name: str
    required: bool
    description: str | None = None
    schema: dict[str, Any] = field(default_factory=dict)
    is_file: bool = False
    allows_multiple: bool = False

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "FieldSpec":
        return cls(
            name=payload["name"],
            cli_name=payload["cli_name"],
            required=payload["required"],
            description=payload.get("description"),
            schema=payload.get("schema") or {},
            is_file=payload.get("is_file", False),
            allows_multiple=payload.get("allows_multiple", False),
        )


@dataclass(slots=True)
class ParameterSpec:
    name: str
    cli_name: str
    location: str
    required: bool
    description: str | None = None
    schema: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ParameterSpec":
        return cls(
            name=payload["name"],
            cli_name=payload["cli_name"],
            location=payload["location"],
            required=payload["required"],
            description=payload.get("description"),
            schema=payload.get("schema") or {},
        )


@dataclass(slots=True)
class RequestBodySpec:
    required: bool
    content_types: tuple[str, ...] = ()
    schema: dict[str, Any] = field(default_factory=dict)
    fields: tuple[FieldSpec, ...] = ()

    @classmethod
    def from_dict(cls, payload: dict[str, Any] | None) -> "RequestBodySpec | None":
        if payload is None:
            return None
        return cls(
            required=payload.get("required", False),
            content_types=tuple(payload.get("content_types", [])),
            schema=payload.get("schema") or {},
            fields=tuple(FieldSpec.from_dict(item) for item in payload.get("fields", [])),
        )

    @property
    def is_json(self) -> bool:
        return any(item.endswith("/json") or item == "application/json" for item in self.content_types)

    @property
    def is_form(self) -> bool:
        return any(item in {"multipart/form-data", "application/x-www-form-urlencoded"} for item in self.content_types)


@dataclass(slots=True)
class OperationSpec:
    kind: str
    group: str
    command_name: str
    operation_key: str
    path: str
    route_name: str
    method: str | None = None
    summary: str | None = None
    description: str | None = None
    parameters: tuple[ParameterSpec, ...] = ()
    request_body: RequestBodySpec | None = None
    response_content_types: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "OperationSpec":
        return cls(
            kind=payload["kind"],
            group=payload["group"],
            command_name=payload["command_name"],
            operation_key=payload["operation_key"],
            method=payload.get("method"),
            path=payload["path"],
            route_name=payload["route_name"],
            summary=payload.get("summary"),
            description=payload.get("description"),
            parameters=tuple(ParameterSpec.from_dict(item) for item in payload.get("parameters", [])),
            request_body=RequestBodySpec.from_dict(payload.get("request_body")),
            response_content_types=tuple(payload.get("response_content_types", [])),
        )

    @property
    def path_parameters(self) -> tuple[ParameterSpec, ...]:
        return tuple(item for item in self.parameters if item.location == "path")

    @property
    def query_parameters(self) -> tuple[ParameterSpec, ...]:
        return tuple(item for item in self.parameters if item.location == "query")

    @property
    def header_parameters(self) -> tuple[ParameterSpec, ...]:
        return tuple(item for item in self.parameters if item.location == "header")


@dataclass(slots=True)
class RouteManifest:
    generated_at: str
    source_path: str
    http_operations: tuple[OperationSpec, ...]
    websocket_operations: tuple[OperationSpec, ...]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "RouteManifest":
        return cls(
            generated_at=payload["generated_at"],
            source_path=payload["source_path"],
            http_operations=tuple(
                OperationSpec.from_dict(item) for item in payload.get("http_operations", [])
            ),
            websocket_operations=tuple(
                OperationSpec.from_dict(item) for item in payload.get("websocket_operations", [])
            ),
        )

    @property
    def all_operations(self) -> tuple[OperationSpec, ...]:
        return (*self.http_operations, *self.websocket_operations)

    def find_operation(self, operation_key: str) -> OperationSpec | None:
        for operation in self.all_operations:
            if operation.operation_key == operation_key:
                return operation
        return None


@lru_cache
def load_manifest() -> RouteManifest:
    manifest_path = files("deliberaide_cli").joinpath("route_manifest.json")
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    return RouteManifest.from_dict(payload)
