from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, urljoin, urlparse, urlunparse

import httpx

from deliberaide_cli.core.session import CookieRecord


@dataclass(slots=True)
class DecodedResponse:
    kind: str
    content_type: str | None
    value: Any
    filename: str | None = None


class ApiBackend:
    def __init__(
        self,
        base_url: str,
        timeout_seconds: float,
        cookies: list[CookieRecord] | None = None,
    ) -> None:
        self.client = httpx.Client(
            base_url=base_url,
            timeout=timeout_seconds,
            follow_redirects=True,
        )
        for cookie in cookies or []:
            self.client.cookies.set(
                cookie.name,
                cookie.value,
                domain=cookie.domain,
                path=cookie.path,
            )

    def export_cookies(self) -> list[CookieRecord]:
        records: list[CookieRecord] = []
        for cookie in self.client.cookies.jar:
            records.append(
                CookieRecord(
                    name=cookie.name,
                    value=cookie.value,
                    domain=cookie.domain or "",
                    path=cookie.path or "/",
                    secure=bool(cookie.secure),
                    expires=cookie.expires,
                )
            )
        return records

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        json_body: Any = None,
        data: dict[str, Any] | None = None,
        uploads: list[tuple[str, Path]] | None = None,
        allow_refresh: bool = True,
    ) -> httpx.Response:
        file_handles = []
        files = []
        try:
            for field_name, file_path in uploads or []:
                handle = open(file_path, "rb")
                file_handles.append(handle)
                files.append((field_name, (file_path.name, handle, "application/octet-stream")))
            response = self.client.request(
                method,
                path,
                params=params,
                headers=headers,
                json=json_body,
                data=data,
                files=files or None,
            )
            if response.status_code == 401 and allow_refresh and path != "/api/v1/auth/refresh":
                if any(cookie.name.endswith("refresh") or "refresh" in cookie.name for cookie in self.export_cookies()):
                    refresh_response = self.client.post("/api/v1/auth/refresh")
                    if refresh_response.is_success:
                        response = self.client.request(
                            method,
                            path,
                            params=params,
                            headers=headers,
                            json=json_body,
                            data=data,
                            files=files or None,
                        )
            return response
        finally:
            for handle in file_handles:
                handle.close()

    def build_websocket_url(self, path: str, query: dict[str, Any] | None = None) -> str:
        base = urlparse(str(self.client.base_url))
        scheme = "wss" if base.scheme == "https" else "ws"
        url = urljoin(str(self.client.base_url), path.lstrip("/"))
        parsed = urlparse(url)
        params = {key: value for key, value in (query or {}).items() if value is not None}
        return urlunparse(
            (
                scheme,
                parsed.netloc,
                parsed.path,
                "",
                urlencode(params),
                "",
            )
        )


def decode_response(response: httpx.Response) -> DecodedResponse:
    content_type = response.headers.get("content-type", "").split(";", 1)[0].strip() or None
    if content_type and "json" in content_type:
        return DecodedResponse(kind="json", content_type=content_type, value=response.json())
    if content_type and (content_type.startswith("text/") or content_type in {"application/xml", "application/javascript"}):
        return DecodedResponse(kind="text", content_type=content_type, value=response.text)
    if not content_type:
        try:
            return DecodedResponse(kind="json", content_type=None, value=response.json())
        except Exception:
            return DecodedResponse(kind="text", content_type=None, value=response.text)
    filename = None
    disposition = response.headers.get("content-disposition", "")
    for part in disposition.split(";"):
        part = part.strip()
        if part.startswith("filename="):
            filename = part.split("=", 1)[1].strip('"')
            break
    return DecodedResponse(kind="binary", content_type=content_type, value=response.content, filename=filename)
