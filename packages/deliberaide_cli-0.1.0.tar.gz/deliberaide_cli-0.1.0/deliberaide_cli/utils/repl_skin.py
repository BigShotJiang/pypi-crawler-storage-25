from __future__ import annotations

from pathlib import Path

import click
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory


class ReplSkin:
    def __init__(self, app_name: str, version: str, history_path: Path) -> None:
        self.app_name = app_name
        self.version = version
        self.history_path = history_path
        self.history_path.parent.mkdir(parents=True, exist_ok=True)

    def print_banner(self) -> None:
        click.echo(f"{self.app_name} {self.version}")
        click.echo("Interactive mode. Type 'help' to list commands or 'exit' to leave.")

    def print_goodbye(self) -> None:
        click.echo("Session closed.")

    def create_prompt_session(self) -> PromptSession[str]:
        return PromptSession(history=FileHistory(str(self.history_path)))

    def get_input(self, session: PromptSession[str], profile_name: str, base_url: str) -> str:
        prompt = HTML(
            f"<ansicyan>{self.app_name}</ansicyan> "
            f"<ansigreen>{profile_name}</ansigreen> "
            f"<ansiyellow>{base_url}</ansiyellow> "
            "<ansiblue>&gt;</ansiblue> "
        )
        return session.prompt(prompt)

    def success(self, message: str) -> None:
        click.echo(message)

    def error(self, message: str) -> None:
        click.secho(message, fg="red", err=True)

    def info(self, message: str) -> None:
        click.echo(message)
