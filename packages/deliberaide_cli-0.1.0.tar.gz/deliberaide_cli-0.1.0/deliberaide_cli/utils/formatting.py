from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def parse_assignment(raw_value: str) -> tuple[str, str]:
    if "=" not in raw_value:
        raise ValueError(f"Expected KEY=VALUE, got: {raw_value}")
    key, value = raw_value.split("=", 1)
    key = key.strip()
    if not key:
        raise ValueError(f"Expected KEY=VALUE, got: {raw_value}")
    return key, value


def load_json_file(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def parse_json_text(raw_value: str) -> Any:
    return json.loads(raw_value)


def coerce_value(raw_value: str, schema: dict[str, Any] | None) -> Any:
    schema = schema or {}
    field_type = schema.get("type")

    if field_type == "boolean":
        lowered = raw_value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
        raise ValueError(f"Expected a boolean value, got: {raw_value}")

    if field_type == "integer":
        return int(raw_value)

    if field_type == "number":
        return float(raw_value)

    if field_type in {"array", "object"}:
        return json.loads(raw_value)

    return raw_value


def json_dumps(payload: Any, compact: bool = False) -> str:
    if compact:
        return json.dumps(payload, separators=(",", ":"), ensure_ascii=True)
    return json.dumps(payload, indent=2, ensure_ascii=True)


def schema_template(schema: dict[str, Any]) -> Any:
    schema_type = schema.get("type")
    if schema_type == "object" or schema.get("properties"):
        template: dict[str, Any] = {}
        for key, value in schema.get("properties", {}).items():
            template[key] = schema_template(value)
        return template
    if schema_type == "array":
        return [schema_template(schema.get("items", {}))]
    if "enum" in schema:
        return schema["enum"][0]
    if schema_type == "boolean":
        return False
    if schema_type == "integer":
        return 0
    if schema_type == "number":
        return 0.0
    if schema.get("format") == "binary":
        return "<path-to-file>"
    return ""


def pretty_lines(rows: list[tuple[str, str]]) -> str:
    if not rows:
        return ""
    width = max(len(key) for key, _ in rows)
    return "\n".join(f"{key.ljust(width)}  {value}" for key, value in rows)
