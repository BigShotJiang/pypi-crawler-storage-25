from deliberaide_cli.deliberaide_cli import main


if __name__ == "__main__":
    main()
