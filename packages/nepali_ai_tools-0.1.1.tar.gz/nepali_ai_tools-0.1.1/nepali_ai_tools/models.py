
import random

# Try to import google.generativeai, but handle it gracefully if missing
try:
    import google.generativeai as genai
    GOOGLE_AI_AVAILABLE = True
except ImportError:
    GOOGLE_AI_AVAILABLE = False

# Dynamic replies list
DYNAMIC_REPLIES = [
    "Namaste! Kasto chha? 😊",
    "Sanchai ho? Malai pani thikai chha. 👍",
    "Eh, ho ra? Bhanera k garnu. 😂",
    "K gardai ho ni sathi? 🤔",
    "La la, ramro kura ho. 👏",
    "Malai thaha chhaina hai sathi. 🤷‍♂️",
    "Huss, hunchha. 🆗",
    "Kasto ramro kura gareko! 😍",
    "Arey waah! Kada ho sathi. 🔥",
    "Dherai dherai dhanyabaad! 🙏",
    "Malai ta dar lagyo baa. 😨",
    "Hahahaha, kasto hasayeko. 😂",
    "Pakkai ho ta? 🤨",
    "Ali pachi kura garam la? ⏲️",
    "Wow, khatra! 🚀",
    "Keep it up! 👏",
    "Don't worry, everything will be fine. ✨",
    "You're doing great! 💪",
    "That's awesome news! 🎉",
    "I'm here for you. 🤗",
    "Life is beautiful, enjoy it! 🌸",
    "Stay positive! 🌈",
    "Believe in yourself. ✨",
    "You've got this! 🎯",
    "Success is yours! 🏆",
    "Namaste from Nepal! 🇳🇵",
    "Nepal is beautiful, isn't it? ❤️",
    "Missing the mountains... 🏔️",
    "Dal Bhat Power 24 Hour! 🍚",
    "Keep calm and love Nepal. 🇳🇵",
    "Gham lagyo hai aaj ta. ☀️",
    "Khana khanu bhayo? 🍚",
    "Yo ta ali bhayena ki? 😅",
    "Ramro sanga basa la. 👋",
    "See you soon! 👋"
]

def generate_ai_reply(message, api_key):
    """Generates a reply using Google Gemini AI."""
    if not GOOGLE_AI_AVAILABLE:
        return "AI Error: 'google-generativeai' package is not installed. Install it with 'pip install nepali-ai-tools[ai]' to use this feature."
    
    if not api_key:
        return "Error: API Key is required for AI mode."
    
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content(f"Reply to this message in a friendly Nepali/English hybrid style: {message}")
        return response.text.strip()
    except Exception as e:
        return f"AI Error: {str(e)}"

def generate_reply(message, mode="hybrid", api_key=None):
    """Main reply generator function."""
    msg_lower = message.lower()
    
    # Basic keyword detection
    if any(greet in msg_lower for greet in ["hi", "hello", "namaste", "hey"]):
        return random.choice(["Namaste! 🙏", "Hello! How can I help you today? 😊", "Hi there! 👋"])
    
    if "how are you" in msg_lower or "kasto chha" in msg_lower:
        return random.choice(["I'm doing great, thank you! How about you? 😊", "Sanchai chhu, tapailai kasto chha? 👍"])

    if mode == "dynamic":
        return random.choice(DYNAMIC_REPLIES)
    
    elif mode == "ai":
        return generate_ai_reply(message, api_key)
    
    elif mode == "hybrid":
        if GOOGLE_AI_AVAILABLE and api_key:
            reply = generate_ai_reply(message, api_key)
            if "AI Error" not in reply:
                return reply
        return random.choice(DYNAMIC_REPLIES)
    
    else:
        return "Invalid mode. Choose 'dynamic', 'ai', or 'hybrid'."
