
import random

def generate_personality(name):
    personalities = [
        f"Hey {name}, you're a total rockstar! Keep shining bright! ✨",
        f"{name}, your vibe is infectious! Never stop being you! 😄",
        f"The world needs more people like {name} – creative and kind! 💖",
        f"{name}, you're a true original, a trendsetter in every way! 🔥",
        f"With {name}'s charm, who needs superpowers? You've got it all! 😎"
    ]
    return random.choice(personalities)

def generate_motivation(mood):
    motivations = {
        "sad": [
            "It's okay to feel down, but remember, tough times don't last, tough people do! 💪",
            "Sending you a virtual hug! You're stronger than you think. 🤗",
            "Every setback is a setup for a comeback. You got this! ✨"
        ],
        "tired": [
            "Rest up, champion! Even superheroes need a break. 😴",
            "A little break goes a long way. Recharge and conquer! 🔋",
            "You've worked hard, now it's time to relax and re-energize. 🌟"
        ],
        "stressed": [
            "Take a deep breath. You're doing great, and everything will be alright. 🧘‍♀️",
            "Don't let stress win! You're in control. Breathe, focus, achieve. 🎯",
            "One step at a time. Break it down, and you'll conquer it all. 🚀"
        ],
        "happy": [
            "Keep that smile going! Your happiness is contagious! 😄",
            "Awesome! Spread that joy around like confetti! 🎉",
            "Shine bright like a diamond! You deserve all the happiness! 💎"
        ]
    }
    return random.choice(motivations.get(mood.lower(), [
        "Keep pushing forward! Great things are on their way! 🚀",
        "Believe in yourself and all that you are. You are amazing! ✨",
        "The only way to do great work is to love what you do. ❤️"
    ]))

def generate_meme_idea():
    meme_ideas = [
        "When you try to explain a meme to your parents... 🤦‍♀️",
        "My face when the Wi-Fi suddenly drops during an important meeting. 😱",
        "Me trying to adult vs. my inner child wanting snacks. 🤷‍♂️",
        "That moment you realize you've been talking to yourself for 5 minutes. 😅",
        "The struggle is real when you're trying to save money but see a sale. 💸"
    ]
    return random.choice(meme_ideas)

def generate_caption(topic):
    captions = {
        "food": [
            "Food is my favorite F word. 🍔🍟",
            "Stressed spelled backward is desserts. Coincidence? I think not! 🍰",
            "Eating good, feeling good. 😋"
        ],
        "travel": [
            "Wander often, wonder always. ✈️🌍",
            "Collecting moments, not things. 📸",
            "Adventure awaits! Let's go! 🗺️"
        ],
        "friends": [
            "Good times + crazy friends = amazing memories! 👯‍♀️",
            "Friends are like stars, you don't always see them but you know they're always there. ✨",
            "Squad goals achieved! 🤩"
        ]
    }
    return random.choice(captions.get(topic.lower(), [
        "Making memories and living my best life! ✨",
        "Good vibes only. ✌️",
        "Simply enjoying the moment. 😊"
    ]))

def generate_gamer_tag(name):
    gamer_tags = [
        f"PixelProwler{name}",
        f"{name}TheDestroyer",
        f"NoobSlayer{name}XD",
        f"GamingGuru{name}",
        f"CtrlAltDefeat{name}"
    ]
    return random.choice(gamer_tags)

def generate_roast():
    roasts = [
        "Is your brain made of sponges? Because it absorbs nothing. 😂",
        "I've had funnier conversations with a brick wall. 🧱",
        "You're not a snack, you're a whole meal... of disappointment. 😬",
        "I'm not saying you're dumb, I'm just saying you have bad luck with smart thoughts. 🧠",
        "Were you born on a highway? Because that's where most accidents happen. 🚗"
    ]
    return random.choice(roasts)

def generate_excuse():
    excuses = [
        "My pet unicorn ate my homework. 🦄",
        "I was abducted by aliens and they needed my help with a cosmic puzzle. 👽",
        "My alarm clock turned into a waffle maker and I couldn't resist. 🧇",
        "A flock of geese stole my car keys. 🦢",
        "I accidentally joined a flash mob and couldn't escape. 🕺"
    ]
    return random.choice(excuses)

def generate_pickup_line():
    pickup_lines = [
        "Are you a parking ticket? Because you've got FINE written all over you. 😉",
        "Do you believe in love at first sight, or should I walk by again? 👀",
        "Is your name Google? Because you have everything I've been searching for. 🔍",
        "Aside from being gorgeous, what do you do for a living? 🤩",
        "Do you have a map? I keep getting lost in your eyes. ✨"
    ]
    return random.choice(pickup_lines)
