
from .models import generate_reply, generate_ai_reply
from .generators import (
    generate_personality,
    generate_motivation,
    generate_meme_idea,
    generate_caption,
    generate_gamer_tag,
    generate_roast,
    generate_excuse,
    generate_pickup_line
)

__version__ = "0.1.0"
__author__ = "@gunpark_xd"
