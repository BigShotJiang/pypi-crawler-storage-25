
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="nepali_ai_tools",
    version="0.1.1",
    author="@gunpark_xd",
    author_email="your.email@example.com",
    description="A simple, clean, and powerful Python package named \"nepali\" that acts like a mini Nepali AI assistant.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/nepali_ai_tools",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[], # No mandatory heavy dependencies
    extras_require={
        "ai": ["google-generativeai>=0.3.0"], # Optional AI support
    },
)
