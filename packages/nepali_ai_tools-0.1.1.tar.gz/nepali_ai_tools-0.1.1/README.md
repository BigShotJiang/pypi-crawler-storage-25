# Nepali AI Tools

A simple, clean, and powerful Python package named "nepali" that acts like a mini Nepali AI assistant for generating smart replies, fun content, and viral outputs. Designed to be beginner-friendly and easy to use.

## Installation

For a lightweight version (recommended for mobile/Pydroid3):
```bash
pip install nepali-ai-tools
```

For full version with AI (Google Gemini) support:
```bash
pip install "nepali-ai-tools[ai]"
```

## Usage

```python
import nepali_ai_tools as ai

# Reply Generator
print(ai.generate_reply("hi"))
# Output: Namaste! 🙏 (or similar dynamic reply)

print(ai.generate_reply("How are you doing today?", mode="ai", api_key="YOUR_GEMINI_API_KEY"))
# Output: AI-generated reply

# Fun Content Generators
print(ai.generate_personality("Gunpark"))
print(ai.generate_motivation("sad"))
print(ai.generate_meme_idea())
print(ai.generate_caption("travel"))
print(ai.generate_gamer_tag("PlayerOne"))
print(ai.generate_roast())
print(ai.generate_excuse())
print(ai.generate_pickup_line())
```

## Features

### 1. Reply Generator (`generate_reply`)

-   **`generate_reply(message, mode="hybrid", api_key=None)`**
    -   **`mode="dynamic"`**: Generates 30-35 random Nepali + English replies.
    -   **`mode="ai"`**: Uses Google Gemini API for smart replies. Requires `api_key`.
    -   **`mode="hybrid"` (default)**: Tries AI generation first; if an error occurs or `api_key` is not provided, falls back to dynamic replies.
    -   Includes basic keyword detection for greetings like "hi", "hello", "how are you".

### 2. AI Integration (`generate_ai_reply`)

-   Uses the `google-generativeai` library.
-   Handles errors safely, returning an error message if AI generation fails.

### 3. Extra Generators

All these functions use random logic and return simple strings.

-   **`generate_personality(name)`**: Generates a fun personality description.
-   **`generate_motivation(mood)`**: Provides motivational messages based on mood.
-   **`generate_meme_idea()`**: Comes up with a random meme idea.
-   **`generate_caption(topic)`**: Generates a caption for a given topic.
-   **`generate_gamer_tag(name)`**: Creates a unique gamer tag.
-   **`generate_roast()`**: Generates a light, non-harmful roast.
-   **`generate_excuse()`**: Creates a funny excuse.
-   **`generate_pickup_line()`**: Generates a clean pickup line.

## Developer Credit

Made with ❤️ by @gunpark_xd
