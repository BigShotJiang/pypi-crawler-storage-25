"""RunAgents MCP Server for the RunAgents platform API.

Uses ``runagents.client.Client`` rather than duplicating HTTP logic so the
assistant-facing MCP surface can grow with the public SDK and CLI.
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
import json

from mcp.server.fastmcp import FastMCP

from runagents.client import Client, APIError

# ---------------------------------------------------------------------------
# Lazy client — instantiated on first tool call
# ---------------------------------------------------------------------------

_client: Client | None = None


def _get_client() -> Client:
    global _client
    if _client is None:
        _client = Client()
    return _client


def _safe_call(fn) -> str:
    """Call fn, return JSON on success or error dict on failure."""
    try:
        result = fn()
        return json.dumps(_jsonable(result), indent=2, default=str)
    except APIError as e:
        return json.dumps({"error": f"HTTP {e.status}", "detail": e.detail}, indent=2)
    except ConnectionError as e:
        return json.dumps({"error": str(e)}, indent=2)


def _jsonable(value):
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    return value


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "RunAgents",
    instructions=(
        "RunAgents platform server. Use these tools to deploy AI agents, "
        "manage tools, monitor runs, configure governance resources, and handle approvals. "
        "Read tools are safe to call anytime. Mutate tools change platform state."
    ),
)


# --- Read tools ---


@mcp.tool()
def list_agents() -> str:
    """List all deployed agents with their status, namespace, and required tools."""
    return _safe_call(lambda: _get_client().agents.list())


@mcp.tool()
def get_agent(namespace: str, name: str) -> str:
    """Get detailed information about a specific agent.

    Args:
        namespace: Agent namespace (e.g., "default", "agent-system")
        name: Agent name
    """
    def _call():
        return _get_client().agents.get(namespace, name)
    return _safe_call(_call)


@mcp.tool()
def list_tools() -> str:
    """List all registered tools with their base URLs, auth types, and access control settings."""
    return _safe_call(lambda: _get_client().tools.list())


@mcp.tool()
def list_models() -> str:
    """List all model providers with their supported models and status."""
    return _safe_call(lambda: _get_client().models.list())


@mcp.tool()
def list_runs(
    agent: str = "",
    status: str = "",
    user: str = "",
    conversation: str = "",
    limit: int = 20,
) -> str:
    """List agent runs with the same filter surface exposed by the CLI.

    Args:
        agent: Filter by agent name (optional)
        status: Filter by run status (optional)
        user: Filter by user id (optional)
        conversation: Filter by conversation id (optional)
        limit: Maximum number of runs to return (default 20)
    """
    def _call():
        return _get_client().runs.list(
            agent=agent,
            status=status,
            user=user,
            conversation=conversation,
            limit=limit,
        )
    return _safe_call(_call)


@mcp.tool()
def get_run(run_id: str) -> str:
    """Get details for a specific run."""

    return _safe_call(lambda: _get_client().runs.get(run_id))


@mcp.tool()
def get_run_events(run_id: str, event_type: str = "", limit: int = 0) -> str:
    """Get run events, optionally narrowed by event type or tail limit.

    Args:
        run_id: The run ID
        event_type: Optional event type filter
        limit: Optional max number of events to return
    """
    def _call():
        return _get_client().runs.events(run_id, event_type=event_type, limit=limit)
    return _safe_call(_call)


@mcp.tool()
def get_run_timeline(run_id: str) -> str:
    """Build an operator-friendly timeline for a run from its event stream."""

    return _safe_call(lambda: _get_client().runs.timeline(run_id))


@mcp.tool()
def wait_for_run(run_id: str, timeout_seconds: int = 300, interval_seconds: int = 2) -> str:
    """Wait until a run reaches a terminal status."""

    return _safe_call(
        lambda: _get_client().runs.wait(
            run_id,
            timeout_seconds=timeout_seconds,
            interval_seconds=interval_seconds,
        )
    )


@mcp.tool()
def export_run(run_id: str) -> str:
    """Export a run together with its events and synthesized timeline."""

    return _safe_call(lambda: _get_client().runs.export(run_id))


@mcp.tool()
def list_catalog_agents(
    search: str = "",
    categories: list[str] | None = None,
    tags: list[str] | None = None,
    integrations: list[str] | None = None,
    governance: list[str] | None = None,
    page: int = 1,
    page_size: int = 24,
) -> str:
    """List catalog agents, with optional search and governance/integration filters."""

    def _call():
        return _get_client().catalog.list(
            search=search,
            categories=categories,
            tags=tags,
            integrations=integrations,
            governance=governance,
            page=page,
            page_size=page_size,
        )

    return _safe_call(_call)


@mcp.tool()
def get_catalog_agent(agent_id: str, version: str = "") -> str:
    """Get a catalog manifest by id, optionally for a specific published version."""

    return _safe_call(lambda: _get_client().catalog.get(agent_id, version=version))


@mcp.tool()
def list_catalog_versions(agent_id: str) -> str:
    """List published versions for a catalog agent."""

    return _safe_call(lambda: _get_client().catalog.versions(agent_id))


@mcp.tool()
def list_policies() -> str:
    """List governance policies in the current workspace."""

    return _safe_call(lambda: _get_client().policies.list())


@mcp.tool()
def get_policy(name: str) -> str:
    """Get a single policy including readiness and bound-agent usage."""

    return _safe_call(lambda: _get_client().policies.get(name))


@mcp.tool()
def translate_policy(text: str) -> str:
    """Translate natural-language policy intent into structured policy rules."""

    return _safe_call(lambda: {"rules": _get_client().policies.translate(text)})


@mcp.tool()
def list_approval_connectors() -> str:
    """List approval delivery connectors configured in the current workspace."""

    return _safe_call(lambda: _get_client().approval_connectors.list())


@mcp.tool()
def get_approval_connector(connector_id: str) -> str:
    """Get a single approval connector by id."""

    return _safe_call(lambda: _get_client().approval_connectors.get(connector_id))


@mcp.tool()
def get_approval_connector_defaults() -> str:
    """Get workspace defaults for approval connector delivery behavior."""

    return _safe_call(lambda: _get_client().approval_connectors.defaults_get())


@mcp.tool()
def list_approval_connector_activity(limit: int = 50) -> str:
    """List recent approval connector activity events for the current workspace."""

    return _safe_call(lambda: _get_client().approval_connectors.activity(limit=limit))


@mcp.tool()
def list_identity_providers() -> str:
    """List end-user identity providers configured in the workspace."""

    return _safe_call(lambda: _get_client().identity_providers.list())


@mcp.tool()
def get_identity_provider(name: str) -> str:
    """Get a single identity provider by name."""

    return _safe_call(lambda: _get_client().identity_providers.get(name))


@mcp.tool()
def export_context() -> str:
    """Export the full workspace context — agents, tools, models, policies, approvals, and drafts."""
    return _safe_call(lambda: _get_client().export_context())


@mcp.tool()
def analyze_code(files: dict[str, str]) -> str:
    """Analyze source code to detect tool calls, LLM usage, secrets, and requirements.

    Args:
        files: Map of filename to source code content (e.g., {"agent.py": "import openai\\n..."})
    """
    def _call():
        return _get_client().analyze(files).__dict__
    return _safe_call(_call)


# --- Mutate tools ---


@mcp.tool()
def deploy_agent(
    agent_name: str,
    source_files: dict[str, str] | None = None,
    image: str | None = None,
    system_prompt: str = "",
    required_tools: list[str] | None = None,
    tools_to_create: list[dict] | None = None,
    llm_configs: list[dict] | None = None,
    requirements: str = "",
    entry_point: str = "",
    framework: str = "",
    policies: list[str] | None = None,
    identity_provider: str = "",
    draft_id: str = "",
    artifact_id: str = "",
) -> str:
    """Deploy an agent from source code, a pre-built image, a draft, or an artifact.

    Args:
        agent_name: Unique name for the agent
        source_files: Map of filename to source code (e.g., {"agent.py": "..."})
        image: Pre-built container image URI (alternative to source_files)
        system_prompt: System prompt for the agent's LLM context
        required_tools: Names of existing tools the agent needs
        tools_to_create: New tools to register (list of {name, base_url, description, auth_type})
        llm_configs: LLM configurations (list of {provider, model, role})
        requirements: Python pip requirements (newline-separated)
        entry_point: Entry point filename
        framework: Framework hint for source deploys
        policies: Policies to bind at deploy time
        identity_provider: Identity provider to bind at deploy time
        draft_id: Deploy from an existing draft
        artifact_id: Deploy from an existing artifact
    """
    def _call():
        return _get_client().agents.deploy(
            name=agent_name,
            source_files=source_files,
            image=image,
            system_prompt=system_prompt,
            required_tools=required_tools,
            tools_to_create=tools_to_create,
            llm_configs=llm_configs,
            requirements=requirements,
            entry_point=entry_point,
            framework=framework,
            policies=policies,
            identity_provider=identity_provider,
            draft_id=draft_id,
            artifact_id=artifact_id,
        )
    return _safe_call(_call)


@mcp.tool()
def deploy_catalog_agent(
    agent_id: str,
    version: str = "",
    name: str = "",
    tools: list[str] | None = None,
    model: str = "",
    policies: list[str] | None = None,
    identity_provider: str = "",
) -> str:
    """Deploy an agent directly from a published catalog manifest."""

    def _call():
        return _get_client().catalog.deploy(
            agent_id,
            version=version,
            name=name,
            tools=tools,
            model=model,
            policies=policies,
            identity_provider=identity_provider,
        )

    return _safe_call(_call)


@mcp.tool()
def create_tool(
    name: str,
    base_url: str,
    description: str = "",
    auth_type: str = "None",
    port: int = 443,
    scheme: str = "HTTPS",
) -> str:
    """Register a new tool (external API) on the platform.

    Args:
        name: Unique tool name (e.g., "stripe-api")
        base_url: Tool endpoint URL (e.g., "https://api.stripe.com")
        description: What the tool does
        auth_type: Authentication type — "None", "APIKey", or "OAuth2"
        port: Target port (default 443)
        scheme: Protocol — "HTTPS" or "HTTP"
    """
    def _call():
        return _get_client().tools.create(
            name=name, base_url=base_url, description=description,
            auth_type=auth_type, port=port, scheme=scheme,
        )
    return _safe_call(_call)


@mcp.tool()
def validate_plan(plan: dict) -> str:
    """Validate an action plan before applying it. Returns validation errors if any.

    Args:
        plan: The action plan object to validate
    """
    return _safe_call(lambda: _get_client().post("/api/actions/validate", plan))


@mcp.tool()
def apply_plan(plan: dict) -> str:
    """Apply a validated action plan to the platform. Creates/updates resources.

    Args:
        plan: The action plan object to apply
    """
    return _safe_call(lambda: _get_client().post("/api/actions/apply", plan))


@mcp.tool()
def approve_request(request_id: str, scope: str = "", duration: str = "") -> str:
    """Approve a pending access request with optional scope and duration.

    Args:
        request_id: The access request ID
        scope: Approval scope (`once`, `run`, or `window`)
        duration: Optional duration for `window` scope (for example `1h` or `4h`)
    """
    return _safe_call(lambda: _get_client().approvals.approve(request_id, scope=scope, duration=duration))


@mcp.tool()
def apply_policy(policy: dict, name: str = "") -> str:
    """Create or update a policy from a structured policy document."""

    return _safe_call(lambda: _get_client().policies.apply(policy, name=name))


@mcp.tool()
def delete_policy(name: str) -> str:
    """Delete a policy by name."""

    return _safe_call(lambda: _get_client().policies.delete(name))


@mcp.tool()
def apply_approval_connector(connector: dict) -> str:
    """Create or update an approval connector from a structured connector document."""

    return _safe_call(lambda: _get_client().approval_connectors.apply(connector))


@mcp.tool()
def apply_identity_provider(identity_provider: dict, name: str = "") -> str:
    """Create or update an identity provider from a structured document."""

    return _safe_call(lambda: _get_client().identity_providers.apply(identity_provider, name=name))


@mcp.tool()
def delete_identity_provider(name: str) -> str:
    """Delete an identity provider by name."""

    return _safe_call(lambda: _get_client().identity_providers.delete(name))


@mcp.tool()
def delete_approval_connector(connector_id: str) -> str:
    """Delete an approval connector by id."""

    return _safe_call(lambda: _get_client().approval_connectors.delete(connector_id))


@mcp.tool()
def test_approval_connector(connector_id: str) -> str:
    """Replay a connector's current configuration through the approval connector test API."""

    return _safe_call(lambda: _get_client().approval_connectors.test(connector_id))


@mcp.tool()
def set_approval_connector_defaults(
    delivery_mode: str | None = None,
    fallback_to_ui: bool | None = None,
    timeout_seconds: int | None = None,
) -> str:
    """Update workspace defaults used when approval policies omit connector delivery behavior."""

    return _safe_call(
        lambda: _get_client().approval_connectors.defaults_set(
            delivery_mode=delivery_mode,
            fallback_to_ui=fallback_to_ui,
            timeout_seconds=timeout_seconds,
        )
    )


@mcp.tool()
def seed_starter_kit() -> str:
    """Create demo starter resources (echo-tool and playground-llm). Idempotent — safe to call multiple times."""
    return _safe_call(lambda: _get_client().seed_starter_kit())


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    """Run the MCP server on stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
