"""
AIBrain Python SDK — connect any AI agent to AIBrain.

Works with Claude, GPT, Gemini, local LLMs, LangChain, AutoGPT,
or any custom agent framework. No vendor lock-in.

Usage:
    from aibrain_sdk import AIBrain

    aos = AIBrain("http://localhost:8001")

    # Store a memory
    aos.remember("user prefers dark mode", tags=["preference", "ui"])

    # Search memories
    results = aos.recall("dark mode")

    # Send a chat message
    aos.say("Task complete: deployed v2.1")

    # Request human approval
    item = aos.request_approval("Deploy to production", detail="v2.1 release")
    # ... later check if approved
    decision = aos.check_approval(item["id"])

    # Log activity
    aos.log_activity("deployed", "Deployed v2.1 to production")
"""

import json
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime
from typing import Optional


class AIBrainError(Exception):
    """Raised when an AIBrain API call fails."""
    pass


class AIBrain:
    """
    Python SDK for AIBrain — the portable AI brain.

    Connects any AI agent to AIBrain memory, scheduler, approval queue,
    chat, webhooks, and activity log via REST API.
    """

    def __init__(self, base_url: str = "http://localhost:8001", agent_name: str = "agent"):
        self.base_url = base_url.rstrip("/")
        self.api = f"{self.base_url}/api/agent"
        self.agent_name = agent_name

    # ------------------------------------------------------------------
    # Internal HTTP helpers (stdlib only — no requests dependency)
    # ------------------------------------------------------------------

    def _request(self, method: str, path: str, data: dict = None, params: dict = None) -> dict:
        url = f"{self.api}/{path.lstrip('/')}" if not path.startswith("http") else path  # noqa:PATH_STARTSWITH
        if path.startswith("/"):  # noqa:PATH_STARTSWITH
            url = f"{self.base_url}{path}"

        if params:
            url += "?" + urllib.parse.urlencode(params)

        body = json.dumps(data).encode() if data else None
        headers = {"Content-Type": "application/json"} if body else {}

        req = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else str(e)
            raise AIBrainError(f"{method} {url} → {e.code}: {error_body}")
        except urllib.error.URLError as e:
            raise AIBrainError(f"Cannot reach AIBrain at {self.base_url}: {e.reason}")

    def _get(self, path: str, **params) -> dict:
        return self._request("GET", path, params={k: v for k, v in params.items() if v is not None})

    def _post(self, path: str, data: dict = None) -> dict:
        return self._request("POST", path, data=data or {})

    def _put(self, path: str, data: dict) -> dict:
        return self._request("PUT", path, data=data)

    def _delete(self, path: str) -> dict:
        return self._request("DELETE", path)

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def health(self) -> dict:
        """Check if AIBrain is running."""
        return self._request("GET", "/health")

    def is_alive(self) -> bool:
        """Returns True if AIBrain is reachable."""
        try:
            h = self.health()
            return h.get("status") == "ok"
        except AIBrainError:
            return False

    # ------------------------------------------------------------------
    # Memory — the agent's persistent brain
    # ------------------------------------------------------------------

    def remember(self, content: str, name: str = None, type: str = "reference",
                 tags: list[str] = None, importance: int = None) -> dict:
        """
        Store a memory. This is the primary way an agent persists knowledge.

        Args:
            content: The information to remember
            name: Short name/title (auto-generated from content if omitted)
            type: Memory type — reference, project, feedback, user, pattern, decision
            tags: List of tags for categorization
            importance: Priority level 1-10 (higher = more important)
        """
        if not name:
            name = content[:80].replace("\n", " ")
        payload = {
            "name": name,
            "content": content,
            "type": type,
            "tags": ",".join(tags) if tags else "",
        }
        if importance is not None:
            payload["importance"] = importance
        return self._post("memories", payload)

    def recall(self, query: str, limit: int = 10) -> list[dict]:
        """
        Search memories using full-text search.
        Returns matching memories ranked by relevance.
        """
        result = self._get("memories/search", q=query, limit=limit)
        return result.get("results", result.get("memories", []))

    def get_memory(self, memory_id: int) -> dict:
        """Get a specific memory by ID."""
        return self._get(f"memories/{memory_id}")

    def update_memory(self, memory_id: int, **fields) -> dict:
        """Update a memory. Pass any of: content, name, type, tags."""
        return self._put(f"memories/{memory_id}", fields)

    def delete_memory(self, memory_id: int) -> dict:
        """Delete a memory."""
        return self._delete(f"memories/{memory_id}")

    def list_memories(self, type: str = None, tag: str = None, limit: int = 50) -> list[dict]:
        """List memories with optional filtering."""
        result = self._get("memories", type=type, tag=tag, limit=limit)
        return result.get("memories", [])

    def memory_summary(self) -> dict:
        """Get memory counts by type."""
        return self._get("memories/summary")

    def export_brain(self) -> dict:
        """Export entire memory database as JSON."""
        return self._get("memories/export")

    def import_brain(self, data: dict) -> dict:
        """Import memories from JSON export."""
        return self._post("memories/import", data)

    # ------------------------------------------------------------------
    # Chat — real-time communication
    # ------------------------------------------------------------------

    def say(self, message: str, role: str = "agent") -> dict:
        """
        Send a chat message. Visible in the dashboard chat panel.
        Use this to communicate status, results, or ask questions.
        """
        return self._post("chat/send", {"content": message, "role": role})

    def chat_history(self, limit: int = 50) -> list[dict]:
        """Get recent chat messages."""
        result = self._get("chat/history", limit=limit)
        return result.get("messages", [])

    # ------------------------------------------------------------------
    # Approval Queue — human-in-the-loop
    # ------------------------------------------------------------------

    def request_approval(self, title: str, detail: str = "",
                         category: str = "general", payload: dict = None) -> dict:
        """
        Request human approval before taking an action.
        Returns the approval item with its ID. Check status later with check_approval().
        """
        body = {"title": title, "detail": detail, "category": category}
        if payload:
            body["payload"] = payload
        return self._post("approvals", body)

    def check_approval(self, item_id: int) -> dict:
        """Check the status of an approval request."""
        return self._get(f"approvals/{item_id}")

    def list_approvals(self, status: str = None, category: str = None) -> list[dict]:
        """List approval items. Filter by status (pending/approved/rejected) or category."""
        result = self._get("approvals", status=status, category=category)
        return result.get("items", [])

    def pending_approvals(self) -> list[dict]:
        """Get all pending approval requests."""
        return self.list_approvals(status="pending")

    # ------------------------------------------------------------------
    # Activity — timeline logging
    # ------------------------------------------------------------------

    def log_activity(self, action: str, detail: str = "", source: str = None) -> dict:
        """
        Log an activity event. Appears in the Activity timeline in the dashboard.
        """
        return self._post("activity", {
            "action": action,
            "detail": detail,
            "source": source or self.agent_name,
            "timestamp": datetime.now().isoformat(),
        })

    def get_activity(self, limit: int = 50) -> list[dict]:
        """Get recent activity entries."""
        return self._get("activity", limit=limit)

    # ------------------------------------------------------------------
    # Workflows — trigger automation
    # ------------------------------------------------------------------

    def list_workflows(self) -> list[dict]:
        """List all available workflows."""
        result = self._get("workflows")
        return result.get("workflows", [])

    def run_workflow(self, name: str) -> dict:
        """Trigger a workflow to run immediately."""
        return self._post(f"workflows/{name}/run")

    def enable_workflow(self, name: str) -> dict:
        """Enable a workflow's scheduled execution."""
        return self._post(f"workflows/{name}/enable")

    def disable_workflow(self, name: str) -> dict:
        """Disable a workflow."""
        return self._post(f"workflows/{name}/disable")

    # ------------------------------------------------------------------
    # Scheduler — cron job management
    # ------------------------------------------------------------------

    def scheduler_status(self) -> dict:
        """Get scheduler health and job count."""
        return self._get("scheduler/status")

    def list_jobs(self) -> list[dict]:
        """List all scheduled jobs."""
        result = self._get("crons")
        return result.get("jobs", [])

    # ------------------------------------------------------------------
    # Agent Mesh — multi-agent communication
    # ------------------------------------------------------------------

    def list_peers(self) -> list[dict]:
        """List registered peer agents."""
        result = self._get("peers")
        return result.get("peers", [])

    def register_peer(self, name: str, url: str, capabilities: list[str] = None) -> dict:
        """Register a peer agent."""
        return self._post("peers", {
            "name": name,
            "url": url,
            "capabilities": capabilities or [],
        })

    def send_to_peer(self, to: str, message: str) -> dict:
        """Send a message through the broker to another agent."""
        return self._post("broker/send", {"to": to, "msg": message, "from": self.agent_name})

    def receive_messages(self) -> list[dict]:
        """Receive messages from the broker."""
        result = self._get("broker/recv")
        return result.get("messages", [])

    # ------------------------------------------------------------------
    # Webhooks
    # ------------------------------------------------------------------

    def list_webhooks(self) -> list[dict]:
        """List registered webhooks."""
        result = self._request("GET", "/webhooks")
        return result.get("webhooks", [])

    # ------------------------------------------------------------------
    # Skills
    # ------------------------------------------------------------------

    def list_skills(self) -> list[dict]:
        """List installed agent skills."""
        result = self._get("skills")
        return result.get("skills", [])

    def get_skill(self, name: str) -> dict:
        """Get skill details."""
        return self._get(f"skills/{name}")

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict:
        """Get agent status and system info."""
        return self._get("status")

    # ------------------------------------------------------------------
    # Convenience methods
    # ------------------------------------------------------------------

    def think(self, thought: str) -> dict:
        """Store an internal thought/reasoning step as a memory."""
        return self.remember(thought, type="pattern", tags=["thought", "reasoning"])

    def learn(self, lesson: str, tags: list[str] = None) -> dict:
        """Store a lesson learned."""
        all_tags = ["lesson"] + (tags or [])
        return self.remember(lesson, type="feedback", tags=all_tags)

    def decide(self, decision: str, reasoning: str = "") -> dict:
        """Record a decision with reasoning."""
        content = decision
        if reasoning:
            content += f"\n\nReasoning: {reasoning}"
        return self.remember(content, type="decision", tags=["decision"])

    def wait_for_approval(self, title: str, detail: str = "",
                          poll_interval: int = 10, timeout: int = 3600) -> dict:
        """
        Request approval and block until decided or timeout.
        Returns the approval item with status 'approved' or 'rejected'.
        """
        import time
        item = self.request_approval(title, detail)
        item_id = item["id"]
        elapsed = 0
        while elapsed < timeout:
            result = self.check_approval(item_id)
            if result.get("status") != "pending":
                return result
            time.sleep(poll_interval)
            elapsed += poll_interval
        raise AIBrainError(f"Approval {item_id} timed out after {timeout}s")

    def __repr__(self):
        return f"AIBrain('{self.base_url}', agent='{self.agent_name}')"
