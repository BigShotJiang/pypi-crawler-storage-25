"""
aibrain.tools — Starter tool library for AIBrain agents.

Provides 15 built-in tools that agents can use for file I/O, web access,
memory operations, shell commands, and data processing.

Usage:
    from aibrain.tools import get_tool, list_tools, BUILTIN_TOOLS

    tool = get_tool("read_file")
    result = tool(path="/tmp/data.txt")
"""

from aibrain.tools.builtin import (
    BaseTool,
    BUILTIN_TOOLS,
    get_tool,
    list_tools,
    ReadFileTool,
    WriteFileTool,
    ListDirectoryTool,
    SearchFilesTool,
    WebSearchTool,
    WebFetchTool,
    ShellTool,
    PythonREPLTool,
    MemorySearchTool,
    MemoryStoreTool,
    JSONParseTool,
    CSVReadTool,
    CalculatorTool,
    DateTimeTool,
    TextSummaryTool,
)

__all__ = [
    "BaseTool",
    "BUILTIN_TOOLS",
    "get_tool",
    "list_tools",
    "ReadFileTool",
    "WriteFileTool",
    "ListDirectoryTool",
    "SearchFilesTool",
    "WebSearchTool",
    "WebFetchTool",
    "ShellTool",
    "PythonREPLTool",
    "MemorySearchTool",
    "MemoryStoreTool",
    "JSONParseTool",
    "CSVReadTool",
    "CalculatorTool",
    "DateTimeTool",
    "TextSummaryTool",
]
