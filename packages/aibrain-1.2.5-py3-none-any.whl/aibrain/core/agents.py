"""
agents.py — Agent/Task/Team composition system for AIBrain.

Typed agents execute validated tasks in structured workflows (sequential
or hierarchical). Every task execution flows through the universal harness,
memories are injected when enabled, and all state changes emit DomainEvents.

Usage:
    from aibrain.core.agents import Agent, Task, Team

    researcher = Agent(role="Researcher", goal="Find relevant data")
    writer = Agent(role="Writer", goal="Produce clear prose")

    research_task = Task(
        description="Research AI agent frameworks",
        expected_output="A list of 10 frameworks with pros/cons",
        agent=researcher,
    )
    write_task = Task(
        description="Write a summary article",
        expected_output="800-word article in markdown",
        agent=writer,
        context=[research_task],
    )

    team = Team(
        name="content_team",
        agents=[researcher, writer],
        tasks=[research_task, write_task],
    )
    result = team.kickoff()
"""

from __future__ import annotations

import asyncio
import json
import logging
import secrets
import time
from typing import Any, Callable, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

log = logging.getLogger("aibrain.teams")


# ---------------------------------------------------------------------------
# Output models
# ---------------------------------------------------------------------------

class TaskOutput(BaseModel):
    """Result from a single task execution."""
    task_id: str = ""
    raw: str = ""
    json_dict: dict | None = None
    agent_role: str = ""
    quality: float = 0.0


class TeamOutput(BaseModel):
    """Aggregate result from a full team run."""
    team_name: str = ""
    task_outputs: list[TaskOutput] = Field(default_factory=list)
    total_tokens: int = 0
    total_cost: float = 0.0
    success: bool = True


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

class Agent(BaseModel):
    """A typed agent with a role, goal, and optional tools/memory."""
    id: str = Field(default_factory=lambda: secrets.token_urlsafe(8))
    role: str
    goal: str
    backstory: str = ""
    tools: list[str] = Field(default_factory=list)
    llm: str | None = None
    memory: bool = True
    max_iter: int = 25
    allow_delegation: bool = False
    guardrail: Optional[Callable] = None
    verbose: bool = False

    model_config = {"arbitrary_types_allowed": True}

    def _build_system_prompt(self) -> str:
        """Assemble the system prompt from agent attributes."""
        parts = [
            f"You are a {self.role}.",
            f"Your goal: {self.goal}",
        ]
        if self.backstory:
            parts.append(f"Background: {self.backstory}")
        if self.tools:
            parts.append(f"Available tools: {', '.join(self.tools)}")
        return "\n".join(parts)


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------

class Task(BaseModel):
    """A unit of work assigned to an agent."""
    id: str = Field(default_factory=lambda: secrets.token_urlsafe(8))
    description: str
    expected_output: str
    agent: Agent | None = None
    context: list[Task] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    output_type: str = "text"      # "text", "json", "pydantic"
    guardrail: Optional[Callable] = None
    guardrail_max_retries: int = 3
    async_execution: bool = False
    human_input: bool = False

    model_config = {"arbitrary_types_allowed": True}


# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------

class Team(BaseModel):
    """Orchestrates agents executing tasks in sequence or hierarchy.

    Teams are the execution primitive — they compose agents and tasks
    into a runnable unit. Think of a team as a project group that the
    brain assembles to accomplish a specific goal.
    """
    name: str = "team"
    agents: list[Agent]
    tasks: list[Task]
    process: str = "sequential"   # "sequential" | "hierarchical"
    memory: bool = True
    manager_llm: str | None = None
    verbose: bool = False

    model_config = {"arbitrary_types_allowed": True}

    # ── public API ────────────────────────────────────────────────

    def kickoff(self, inputs: dict | None = None) -> TeamOutput:
        """Execute all tasks synchronously."""
        inputs = inputs or {}
        if self.process == "hierarchical":
            return self._run_hierarchical(inputs)
        return self._run_sequential(inputs)

    async def kickoff_async(self, inputs: dict | None = None) -> TeamOutput:
        """Execute all tasks asynchronously."""
        inputs = inputs or {}
        if self.process == "hierarchical":
            return await asyncio.to_thread(self._run_hierarchical, inputs)
        return await asyncio.to_thread(self._run_sequential, inputs)

    # ── sequential execution ──────────────────────────────────────

    def _run_sequential(self, inputs: dict) -> TeamOutput:
        output = TeamOutput(team_name=self.name)
        _emit_event("team.kickoff", self.name, {"process": self.process, "task_count": len(self.tasks)})

        durable = _get_durable_workflow(f"team-{self.name}-{secrets.token_urlsafe(4)}")
        previous_outputs: dict[str, TaskOutput] = {}

        for task in self.tasks:
            agent = task.agent or (self.agents[0] if self.agents else None)
            if agent is None:
                task_output = TaskOutput(task_id=task.id, raw="ERROR: no agent assigned", quality=0.0)
                output.task_outputs.append(task_output)
                output.success = False
                continue

            task_output = self._execute_task(task, agent, inputs, previous_outputs, durable)
            previous_outputs[task.id] = task_output
            output.task_outputs.append(task_output)
            output.total_tokens += 0  # updated when LLM returns token counts
            if task_output.quality == 0.0 and "ERROR" in task_output.raw:
                output.success = False

        _emit_event("team.complete", self.name, {"success": output.success, "tasks": len(output.task_outputs)})
        return output

    # ── hierarchical execution ────────────────────────────────────

    def _run_hierarchical(self, inputs: dict) -> TeamOutput:
        """Manager agent delegates tasks to workers."""
        output = TeamOutput(team_name=self.name)
        _emit_event("team.kickoff", self.name, {"process": "hierarchical", "task_count": len(self.tasks)})

        durable = _get_durable_workflow(f"team-{self.name}-{secrets.token_urlsafe(4)}")
        previous_outputs: dict[str, TaskOutput] = {}

        # Manager picks best agent for each task based on role match
        for task in self.tasks:
            agent = task.agent  # explicit assignment wins
            if agent is None:
                agent = self._pick_agent(task)

            task_output = self._execute_task(task, agent, inputs, previous_outputs, durable)
            previous_outputs[task.id] = task_output
            output.task_outputs.append(task_output)
            if task_output.quality == 0.0 and "ERROR" in task_output.raw:
                output.success = False

        _emit_event("team.complete", self.name, {"success": output.success, "tasks": len(output.task_outputs)})
        return output

    def _pick_agent(self, task: Task) -> Agent:
        """Simple heuristic: pick the agent whose role best matches the task description."""
        if not self.agents:
            raise ValueError("Team has no agents")
        desc_lower = task.description.lower()
        scored = []
        for agent in self.agents:
            score = 0
            for word in agent.role.lower().split():
                if word in desc_lower:
                    score += 1
            if agent.goal:
                for word in agent.goal.lower().split():
                    if word in desc_lower:
                        score += 1
            scored.append((score, agent))
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1]

    # ── single task execution ─────────────────────────────────────

    def _execute_task(
        self,
        task: Task,
        agent: Agent,
        inputs: dict,
        previous_outputs: dict[str, TaskOutput],
        durable: Any,
    ) -> TaskOutput:
        """Execute one task through the harness with memory, guardrails, and events."""
        _emit_event("task.start", task.id, {"agent": agent.role, "description": task.description[:200]})

        # Build the prompt
        prompt = self._build_prompt(task, agent, inputs, previous_outputs)

        # Map agent LLM to harness task type
        task_type = _agent_llm_to_task_type(agent.llm)

        # Wrap LLM call in a callable for the harness
        def _action():
            return _call_llm(prompt, agent, task_type)

        # Execute through harness
        from aibrain.core.harness import execute as harness_execute, HarnessConfig

        config = HarnessConfig(
            task_type=task_type,
            authority="standard",
            max_retries=0,
            actor=f"agent:{agent.role}",
            tags=[f"team:{self.name}", f"task:{task.id}"],
        )

        harness_result = harness_execute(
            task=f"team.{self.name}.{task.id}",
            action=_action,
            config=config,
        )

        raw_output = str(harness_result.output) if harness_result.output else ""
        quality = harness_result.quality

        # Guardrail loop (task-level first, then agent-level)
        guardrail = task.guardrail or agent.guardrail
        if guardrail and raw_output:
            retries = 0
            while retries < task.guardrail_max_retries:
                try:
                    guard_result = guardrail(raw_output)
                except Exception as e:
                    log.warning("Guardrail raised: %s", e)
                    break

                # guardrail returns True/False, or (bool, feedback)
                if isinstance(guard_result, tuple):
                    passed, feedback = guard_result
                elif isinstance(guard_result, bool):
                    passed = guard_result
                    feedback = ""
                else:
                    break

                if passed:
                    break

                # Retry with feedback injected
                retries += 1
                log.info("Guardrail failed (attempt %d/%d): %s",
                         retries, task.guardrail_max_retries, feedback)
                retry_prompt = (
                    f"{prompt}\n\n"
                    f"[Previous attempt was rejected. Feedback: {feedback}]\n"
                    f"Please try again, addressing the feedback."
                )

                def _retry_action(p=retry_prompt):
                    return _call_llm(p, agent, task_type)

                harness_result = harness_execute(
                    task=f"team.{self.name}.{task.id}.retry{retries}",
                    action=_retry_action,
                    config=config,
                )
                raw_output = str(harness_result.output) if harness_result.output else ""
                quality = harness_result.quality

        # Parse JSON if requested
        json_dict = None
        if task.output_type == "json" and raw_output:
            try:
                json_dict = json.loads(raw_output)
            except (json.JSONDecodeError, ValueError):
                # Try extracting JSON from markdown fences
                stripped = raw_output.strip()
                if stripped.startswith("```"):
                    stripped = stripped.split("\n", 1)[-1]
                    if stripped.endswith("```"):
                        stripped = stripped[:-3].strip()
                    try:
                        json_dict = json.loads(stripped)
                    except (json.JSONDecodeError, ValueError):
                        pass

        task_output = TaskOutput(
            task_id=task.id,
            raw=raw_output,
            json_dict=json_dict,
            agent_role=agent.role,
            quality=quality,
        )

        _emit_event("task.complete", task.id, {
            "agent": agent.role,
            "quality": quality,
            "success": harness_result.success,
        })

        return task_output

    def _build_prompt(
        self,
        task: Task,
        agent: Agent,
        inputs: dict,
        previous_outputs: dict[str, TaskOutput],
    ) -> str:
        """Assemble the full prompt for a task execution."""
        parts: list[str] = []

        # System context
        parts.append(agent._build_system_prompt())

        # Memory injection
        if (self.memory or agent.memory) and task.description:
            memories = _search_memory(task.description, agent_id=agent.id)
            if memories:
                parts.append("\n--- Relevant memories ---")
                for mem in memories[:5]:
                    parts.append(f"- {mem}")
                parts.append("--- End memories ---\n")

        # Context from previous tasks
        if task.context:
            parts.append("\n--- Context from previous tasks ---")
            for ctx_task in task.context:
                prev = previous_outputs.get(ctx_task.id)
                if prev:
                    parts.append(f"[{prev.agent_role} output]: {prev.raw[:2000]}")
            parts.append("--- End context ---\n")

        # Delegation tools description
        if agent.allow_delegation and len(self.agents) > 1:
            other_agents = [a for a in self.agents if a.id != agent.id]
            parts.append("\n--- Delegation ---")
            parts.append("You can delegate work to these team members:")
            for a in other_agents:
                parts.append(f"  - {a.role}: {a.goal}")
            parts.append("To delegate, include: [DELEGATE TO {role}]: {sub-task description}")
            parts.append("To ask a question, include: [ASK {role}]: {question}")
            parts.append("--- End delegation ---\n")

        # Input variables
        if inputs:
            parts.append("\n--- Inputs ---")
            for k, v in inputs.items():
                parts.append(f"{k}: {v}")
            parts.append("--- End inputs ---\n")

        # The task itself
        parts.append(f"\nTask: {task.description}")
        parts.append(f"Expected output: {task.expected_output}")

        return "\n".join(parts)


# ---------------------------------------------------------------------------
# Companies bridge
# ---------------------------------------------------------------------------

def team_from_company(company_id: str) -> 'Team':
    """Create a Team from an existing company in companies.py.

    Reads company agents and active tasks from the DB and maps them
    to Agent/Task instances. This bridges the dashboard company system
    with the execution layer — companies define the org chart, teams
    execute the work.
    """
    from aibrain.core.companies import get_company, list_agents, list_tasks

    company = get_company(company_id)
    if not company:
        raise ValueError(f"Company not found: {company_id}")

    # Map DB agents to Agent instances
    db_agents = list_agents(company_id)
    agent_map: dict[str, Agent] = {}
    agents: list[Agent] = []
    for db_agent in db_agents:
        agent = Agent(
            id=db_agent["id"],
            role=db_agent.get("role", "general"),
            goal=db_agent.get("title", db_agent.get("name", "")),
            llm=db_agent.get("model", "auto"),
            backstory=db_agent.get("capabilities", ""),
        )
        agents.append(agent)
        agent_map[db_agent["id"]] = agent

    # Map DB tasks to Task instances
    db_tasks = list_tasks(company_id, status="todo")
    db_tasks += list_tasks(company_id, status="in_progress")
    tasks: list[Task] = []
    for db_task in db_tasks:
        assignee = agent_map.get(db_task.get("assignee_agent_id", ""))
        task = Task(
            id=db_task["id"],
            description=db_task.get("title", ""),
            expected_output=db_task.get("description", "Complete the task successfully"),
            agent=assignee,
        )
        tasks.append(task)

    return Team(
        name=company.get("name", "company"),
        agents=agents,
        tasks=tasks,
        memory=True,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _call_llm(prompt: str, agent: Agent, task_type: str) -> str:
    """Call the LLM via llm_router, falling back gracefully.

    Runs before_llm and after_llm hooks around the actual LLM call.
    """
    # Run before_llm hooks — may modify the prompt
    try:
        from aibrain.core.hooks import run_before_llm, run_after_llm
        from aibrain.core.events import emit, Events
        prompt = run_before_llm(prompt, agent)
        emit(Events.HOOK_BEFORE_LLM, agent.role)
    except ImportError:
        run_after_llm = None
    except Exception as e:
        run_after_llm = None
        log.debug("before_llm hooks failed (non-fatal): %s", e)

    try:
        from backend.llm_router import complete

        system = agent._build_system_prompt()
        # Map agent.llm to a category or specific model
        model = None
        category = task_type
        if agent.llm and agent.llm != "auto":
            # Check if it's an adapter name or a full model string
            if "/" in agent.llm or "claude" in agent.llm or "gpt" in agent.llm:
                model = agent.llm
                category = None
            else:
                # Adapter name — resolve to model
                try:
                    from aibrain.core.adapters import get_model_for_agent
                    _, resolved = get_model_for_agent(agent.llm)
                    if resolved and resolved != "auto":
                        model = resolved
                        category = None
                except Exception:
                    pass

        result = complete(
            prompt=prompt,
            model=model,
            category=category,
            system=system,
            max_tokens=4096,
        )
        content = result.get("content", "")

        # Run after_llm hooks — may modify the response
        if run_after_llm is not None:
            try:
                content = run_after_llm(content, agent)
                emit(Events.HOOK_AFTER_LLM, agent.role)
            except Exception as e2:
                log.debug("after_llm hooks failed (non-fatal): %s", e2)

        return content
    except Exception as e:
        log.warning("LLM call failed: %s — returning prompt echo", e)
        return f"[LLM unavailable: {e}] Task prompt was: {prompt[:500]}"


def _agent_llm_to_task_type(llm: str | None) -> str:
    """Map an agent's LLM setting to a harness task type string."""
    if not llm or llm == "auto":
        return "judgment"
    llm_lower = llm.lower()
    if "opus" in llm_lower:
        return "complex"
    if "haiku" in llm_lower or "mini" in llm_lower or "local" in llm_lower or "ollama" in llm_lower:
        return "simple"
    if "sonnet" in llm_lower or "gpt-4o" in llm_lower:
        return "judgment"
    return "judgment"


def _search_memory(query: str, agent_id: str = None) -> list[str]:
    """Search brain memory for context relevant to a task."""
    try:
        from aibrain.core.memory_api import Brain
        brain = Brain()
        results = brain.search(query, agent_id=agent_id, limit=5)
        return [r.get("memory", "") for r in results if r.get("memory")]
    except Exception as e:
        log.debug("Memory search failed (non-fatal): %s", e)
        return []


def _emit_event(event_type: str, key: str, metadata: dict | None = None):
    """Emit a DomainEvent via centralized events.emit(). Fire-and-forget."""
    try:
        from aibrain.core.events import emit
        emit(event_type, key, domain="aibrain.teams", source_agent="team", **(metadata or {}))
    except Exception as e:
        log.debug("Event emission failed (non-fatal): %s", e)


def _get_durable_workflow(workflow_id: str):
    """Get a DurableWorkflow instance for crash-recovery. Returns None if unavailable."""
    try:
        from backend.durable_workflow import DurableWorkflow
        return DurableWorkflow(workflow_id)
    except Exception:
        return None
