"""
ingest.py — Document ingestion system for AIBrain.

The brain's mouth: point it at a PDF, CSV, Excel file, JSON, or directory
and it chunks, embeds, and stores everything in the existing brain memory.

    brain = Brain()
    brain.ingest("report.pdf")
    brain.ingest("data.csv", collection="sales")
    brain.ingest("/path/to/docs/", collection="knowledge_base")

Pipeline: Source -> Load -> Chunk -> Enrich -> Embed -> Store
"""

import csv
import hashlib
import json
import logging
import os
import re
import sqlite3
import sys
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Union

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Ensure project root is importable
# ---------------------------------------------------------------------------
_project_root = Path(__file__).resolve().parent.parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))


# ---------------------------------------------------------------------------
# Result model
# ---------------------------------------------------------------------------

class IngestionResult(BaseModel):
    """Result of an ingestion operation."""
    source: str = ""
    chunks_created: int = 0
    memories_stored: int = 0
    errors: list[str] = Field(default_factory=list)
    duration_seconds: float = 0.0
    source_hash: str = ""
    skipped_unchanged: bool = False


# ---------------------------------------------------------------------------
# Sentence-aware chunking
# ---------------------------------------------------------------------------

# Regex: split on sentence-ending punctuation followed by whitespace,
# or on double newlines (paragraph breaks).
_SENTENCE_SPLIT_RE = re.compile(r'(?<=[.!?])\s+|(?:\n\n+)')


def chunk_text(
    text: str,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
    metadata_base: Optional[dict] = None,
) -> list[dict]:
    """Split text on sentence boundaries respecting chunk_size.

    Algorithm:
    1. Split text into sentences (on '. ', '? ', '! ', paragraph breaks)
    2. Accumulate sentences until chunk_size reached
    3. Overlap: carry back sentences from end of previous chunk
    4. Each chunk gets metadata: {chunk_index, char_start, char_end}
    """
    if not text or not text.strip():
        return []

    sentences = _SENTENCE_SPLIT_RE.split(text)
    sentences = [s.strip() for s in sentences if s and s.strip()]

    if not sentences:
        return []

    chunks = []
    current_sentences: list[str] = []
    current_len = 0
    char_pos = 0  # Track position in original text

    def _flush(sents: list[str], start_pos: int) -> dict:
        content = " ".join(sents)
        meta = dict(metadata_base or {})
        meta.update({
            "chunk_index": len(chunks),
            "char_start": start_pos,
            "char_end": start_pos + len(content),
        })
        return {"content": content, "metadata": meta}

    for sentence in sentences:
        sent_len = len(sentence)

        # If adding this sentence exceeds chunk_size and we have content, flush
        if current_len + sent_len + 1 > chunk_size and current_sentences:
            chunks.append(_flush(current_sentences, char_pos))

            # Overlap: carry back sentences from end to fill ~chunk_overlap chars
            overlap_sents: list[str] = []
            overlap_len = 0
            for s in reversed(current_sentences):
                if overlap_len + len(s) + 1 > chunk_overlap:
                    break
                overlap_sents.insert(0, s)
                overlap_len += len(s) + 1

            char_pos += current_len - overlap_len
            current_sentences = overlap_sents
            current_len = overlap_len

        current_sentences.append(sentence)
        current_len += sent_len + 1  # +1 for joining space

    # Flush remaining
    if current_sentences:
        chunks.append(_flush(current_sentences, char_pos))

    return chunks


# ---------------------------------------------------------------------------
# Base knowledge source
# ---------------------------------------------------------------------------

class BaseKnowledgeSource(ABC):
    """Base class for all knowledge sources."""

    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    @abstractmethod
    def load(self) -> list[str]:
        """Load and return raw text content segments."""

    def chunk(self, text: str, metadata_base: Optional[dict] = None) -> list[dict]:
        """Chunk text with sentence-aware splitting and metadata."""
        return chunk_text(
            text,
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            metadata_base=metadata_base,
        )

    def source_path(self) -> str:
        """Return the source file path (for hashing / logging)."""
        return ""

    def file_hash(self) -> str:
        """SHA256 of the source file for change detection."""
        path = self.source_path()
        if not path or not Path(path).is_file():
            return ""
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for block in iter(lambda: f.read(8192), b""):
                h.update(block)
        return h.hexdigest()

    def load_and_chunk(self) -> list[dict]:
        """Load content and produce all chunks with metadata."""
        raise NotImplementedError("Subclasses should implement this")


# ---------------------------------------------------------------------------
# TextSource
# ---------------------------------------------------------------------------

class TextSource(BaseKnowledgeSource):
    """Plain text file or raw string."""

    def __init__(self, path: str = None, content: str = None,
                 chunk_size: int = 1000, chunk_overlap: int = 200):
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self._path = path
        self._content = content

    def source_path(self) -> str:
        return self._path or ""

    def load(self) -> list[str]:
        if self._content is not None:
            return [self._content]
        if self._path:
            with open(self._path, "r", encoding="utf-8", errors="replace") as f:
                return [f.read()]
        return []

    def load_and_chunk(self) -> list[dict]:
        texts = self.load()
        all_chunks = []
        for text in texts:
            meta = {"source": self._path or "<string>"}
            all_chunks.extend(self.chunk(text, metadata_base=meta))
        return all_chunks


# ---------------------------------------------------------------------------
# PDFSource
# ---------------------------------------------------------------------------

class PDFSource(BaseKnowledgeSource):
    """PDF file. Uses pdfplumber (lightweight, no Java)."""

    def __init__(self, path: str, chunk_size: int = 1000, chunk_overlap: int = 200):
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self._path = path

    def source_path(self) -> str:
        return self._path

    def load(self) -> list[str]:
        try:
            import pdfplumber
        except ImportError:
            raise ImportError(
                "pdfplumber is required for PDF ingestion. "
                "Install it with: pip install pdfplumber"
            )
        pages = []
        with pdfplumber.open(self._path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ""
                pages.append(text)
        return pages

    def load_and_chunk(self) -> list[dict]:
        pages = self.load()
        all_chunks = []
        for page_num, page_text in enumerate(pages, start=1):
            if not page_text.strip():
                continue
            meta = {"source": self._path, "page_number": page_num}
            all_chunks.extend(self.chunk(page_text, metadata_base=meta))
        return all_chunks


# ---------------------------------------------------------------------------
# CSVSource
# ---------------------------------------------------------------------------

class CSVSource(BaseKnowledgeSource):
    """CSV file. Each row becomes a memory."""

    def __init__(self, path: str, text_columns: list[str] = None,
                 chunk_size: int = 1000, chunk_overlap: int = 200):
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self._path = path
        self._text_columns = text_columns

    def source_path(self) -> str:
        return self._path

    def load(self) -> list[str]:
        rows = []
        with open(self._path, "r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if self._text_columns:
                    parts = [str(row.get(col, "")) for col in self._text_columns if row.get(col)]
                    rows.append(" ".join(parts))
                else:
                    parts = [f"{k}: {v}" for k, v in row.items() if v]
                    rows.append(", ".join(parts))
        return rows

    def load_and_chunk(self) -> list[dict]:
        """For CSV, each row is its own chunk (no sentence splitting)."""
        raw_rows = []
        with open(self._path, "r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.DictReader(f)
            for idx, row in enumerate(reader):
                if self._text_columns:
                    parts = [str(row.get(col, "")) for col in self._text_columns if row.get(col)]
                    content = " ".join(parts)
                else:
                    parts = [f"{k}: {v}" for k, v in row.items() if v]
                    content = ", ".join(parts)
                if content.strip():
                    raw_rows.append({
                        "content": content,
                        "metadata": {
                            "source": self._path,
                            "chunk_index": idx,
                            "original_row": idx + 1,
                            "char_start": 0,
                            "char_end": len(content),
                        },
                    })
        return raw_rows


# ---------------------------------------------------------------------------
# ExcelSource
# ---------------------------------------------------------------------------

class ExcelSource(BaseKnowledgeSource):
    """Excel file. Each sheet processed, each row becomes a memory."""

    def __init__(self, path: str, sheets: list[str] = None,
                 chunk_size: int = 1000, chunk_overlap: int = 200):
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self._path = path
        self._sheets = sheets

    def source_path(self) -> str:
        return self._path

    def load(self) -> list[str]:
        try:
            import openpyxl
        except ImportError:
            raise ImportError(
                "openpyxl is required for Excel ingestion. "
                "Install it with: pip install openpyxl"
            )
        wb = openpyxl.load_workbook(self._path, read_only=True, data_only=True)
        rows = []
        sheet_names = self._sheets or wb.sheetnames
        for sheet_name in sheet_names:
            if sheet_name not in wb.sheetnames:
                continue
            ws = wb[sheet_name]
            headers = None
            for row in ws.iter_rows(values_only=True):
                if headers is None:
                    headers = [str(c) if c else f"col_{i}" for i, c in enumerate(row)]
                    continue
                parts = [f"{headers[i]}: {v}" for i, v in enumerate(row) if v is not None and i < len(headers)]
                if parts:
                    rows.append(", ".join(parts))
        wb.close()
        return rows

    def load_and_chunk(self) -> list[dict]:
        try:
            import openpyxl
        except ImportError:
            raise ImportError(
                "openpyxl is required for Excel ingestion. "
                "Install it with: pip install openpyxl"
            )
        wb = openpyxl.load_workbook(self._path, read_only=True, data_only=True)
        all_chunks = []
        sheet_names = self._sheets or wb.sheetnames
        chunk_idx = 0
        for sheet_name in sheet_names:
            if sheet_name not in wb.sheetnames:
                continue
            ws = wb[sheet_name]
            headers = None
            row_num = 0
            for row in ws.iter_rows(values_only=True):
                if headers is None:
                    headers = [str(c) if c else f"col_{i}" for i, c in enumerate(row)]
                    continue
                row_num += 1
                parts = [f"{headers[i]}: {v}" for i, v in enumerate(row) if v is not None and i < len(headers)]
                content = ", ".join(parts)
                if content.strip():
                    all_chunks.append({
                        "content": content,
                        "metadata": {
                            "source": self._path,
                            "chunk_index": chunk_idx,
                            "sheet_name": sheet_name,
                            "original_row": row_num,
                            "char_start": 0,
                            "char_end": len(content),
                        },
                    })
                    chunk_idx += 1
        wb.close()
        return all_chunks


# ---------------------------------------------------------------------------
# JSONSource
# ---------------------------------------------------------------------------

class JSONSource(BaseKnowledgeSource):
    """JSON file. Recursively flatten to key-value text."""

    def __init__(self, path: str, text_keys: list[str] = None,
                 chunk_size: int = 1000, chunk_overlap: int = 200):
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self._path = path
        self._text_keys = text_keys

    def source_path(self) -> str:
        return self._path

    @staticmethod
    def _flatten(obj: Any, prefix: str = "") -> list[tuple[str, str]]:
        """Recursively flatten a JSON object to (key, value) pairs."""
        pairs = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                new_key = f"{prefix}.{k}" if prefix else k
                if isinstance(v, (dict, list)):
                    pairs.extend(JSONSource._flatten(v, new_key))
                else:
                    pairs.append((new_key, str(v)))
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                new_key = f"{prefix}[{i}]"
                if isinstance(item, (dict, list)):
                    pairs.extend(JSONSource._flatten(item, new_key))
                else:
                    pairs.append((new_key, str(item)))
        else:
            pairs.append((prefix, str(obj)))
        return pairs

    def load(self) -> list[str]:
        with open(self._path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read().strip()

        # Handle JSONL (one JSON object per line)
        if self._path.endswith(".jsonl"):
            records = []
            for line in content.split("\n"):
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        else:
            data = json.loads(content)
            records = data if isinstance(data, list) else [data]

        texts = []
        for record in records:
            if self._text_keys:
                parts = []
                for key in self._text_keys:
                    val = record.get(key) if isinstance(record, dict) else None
                    if val is not None:
                        parts.append(str(val))
                if parts:
                    texts.append(" ".join(parts))
            else:
                pairs = self._flatten(record)
                texts.append(", ".join(f"{k}: {v}" for k, v in pairs))
        return texts

    def load_and_chunk(self) -> list[dict]:
        texts = self.load()
        all_chunks = []
        for idx, text in enumerate(texts):
            if not text.strip():
                continue
            # Short records stay as single chunks; long ones get sentence-split
            if len(text) <= self.chunk_size:
                all_chunks.append({
                    "content": text,
                    "metadata": {
                        "source": self._path,
                        "chunk_index": len(all_chunks),
                        "original_row": idx + 1,
                        "char_start": 0,
                        "char_end": len(text),
                    },
                })
            else:
                meta = {"source": self._path, "original_row": idx + 1}
                chunks = self.chunk(text, metadata_base=meta)
                all_chunks.extend(chunks)
        return all_chunks


# ---------------------------------------------------------------------------
# DirectorySource
# ---------------------------------------------------------------------------

class DirectorySource(BaseKnowledgeSource):
    """Directory of files. Auto-detect type by extension."""

    def __init__(self, path: str, glob: str = "**/*", recursive: bool = True,
                 chunk_size: int = 1000, chunk_overlap: int = 200):
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self._path = path
        self._glob = glob
        self._recursive = recursive

    def source_path(self) -> str:
        return self._path

    def load(self) -> list[str]:
        # DirectorySource delegates to per-file sources
        return []

    def iter_sources(self) -> list[tuple[Path, BaseKnowledgeSource]]:
        """Yield (file_path, source) for each supported file in the directory."""
        base = Path(self._path)
        sources = []
        for file_path in sorted(base.glob(self._glob)):
            if not file_path.is_file():
                continue
            ext = file_path.suffix.lower()
            source_cls = SOURCE_MAP.get(ext)
            if source_cls is None:
                continue
            try:
                src = source_cls(
                    path=str(file_path),
                    chunk_size=self.chunk_size,
                    chunk_overlap=self.chunk_overlap,
                )
                sources.append((file_path, src))
            except Exception as e:
                logger.warning("Could not create source for %s: %s", file_path, e)
        return sources

    def load_and_chunk(self) -> list[dict]:
        all_chunks = []
        for file_path, src in self.iter_sources():
            try:
                all_chunks.extend(src.load_and_chunk())
            except Exception as e:
                logger.warning("Error loading %s: %s", file_path, e)
        return all_chunks


# ---------------------------------------------------------------------------
# Source auto-detection
# ---------------------------------------------------------------------------

SOURCE_MAP: dict[str, type] = {
    ".txt": TextSource,
    ".md": TextSource,
    ".log": TextSource,
    ".rst": TextSource,
    ".pdf": PDFSource,
    ".csv": CSVSource,
    ".xlsx": ExcelSource,
    ".xls": ExcelSource,
    ".json": JSONSource,
    ".jsonl": JSONSource,
}


def detect_source(path: str, **kwargs) -> BaseKnowledgeSource:
    """Auto-detect source type from file path (extension or directory)."""
    p = Path(path)
    if p.is_dir():
        return DirectorySource(path=path, **kwargs)
    ext = p.suffix.lower()
    source_cls = SOURCE_MAP.get(ext)
    if source_cls is None:
        raise ValueError(
            f"Unsupported file type: {ext}. "
            f"Supported: {', '.join(sorted(SOURCE_MAP.keys()))}"
        )
    return source_cls(path=path, **kwargs)


# ---------------------------------------------------------------------------
# Ingestion log table (change detection)
# ---------------------------------------------------------------------------

_INGESTION_LOG_DDL = """
CREATE TABLE IF NOT EXISTS ingestion_log (
    source_path TEXT PRIMARY KEY,
    source_hash TEXT NOT NULL,
    chunks_created INTEGER DEFAULT 0,
    collection TEXT DEFAULT 'default',
    ingested_at TEXT NOT NULL
);
"""


def _ensure_ingestion_log(db: sqlite3.Connection):
    """Create ingestion_log table if missing."""
    db.executescript(_INGESTION_LOG_DDL)


def _check_source_hash(db: sqlite3.Connection, source_path: str, current_hash: str) -> bool:
    """Return True if source is unchanged (same hash)."""
    try:
        row = db.execute(
            "SELECT source_hash FROM ingestion_log WHERE source_path = ?",
            (source_path,),
        ).fetchone()
        if row and row[0] == current_hash:
            return True
    except Exception:
        pass
    return False


def _record_ingestion(db: sqlite3.Connection, source_path: str, source_hash: str,
                      chunks_created: int, collection: str):
    """Record ingestion in the log for change detection."""
    db.execute(
        "INSERT OR REPLACE INTO ingestion_log (source_path, source_hash, chunks_created, collection, ingested_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (source_path, source_hash, chunks_created, collection,
         datetime.now(timezone.utc).isoformat()),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Event emission (best-effort, never blocks ingestion)
# ---------------------------------------------------------------------------

def _emit_event(event_type: str, key: str, value: Any = None, metadata: dict = None):
    """Fire-and-forget event via centralized events.emit()."""
    try:
        from aibrain.core.events import emit
        emit(event_type, key, value=value, **(metadata or {}))
    except Exception:
        pass  # Never crash on event emission


# ---------------------------------------------------------------------------
# Storage enricher (optional)
# ---------------------------------------------------------------------------

def _try_enrich(content: str) -> str:
    """Run storage enricher if available, return enriched content or original."""
    try:
        from storage_enricher import StorageEnricher
        enricher = StorageEnricher()
        result = enricher.enrich(content)
        return result.enriched_content or content
    except Exception:
        return content


# ---------------------------------------------------------------------------
# Ingestion pipeline
# ---------------------------------------------------------------------------

class IngestionPipeline:
    """Orchestrates the full ingestion flow.

    Pipeline: Source -> Load -> Chunk -> Enrich -> Embed -> Store
    """

    def __init__(self, brain=None):
        # Lazy import to avoid circular dependency
        if brain is None:
            from aibrain.core.memory_api import Brain
            brain = Brain()
        self.brain = brain

    def ingest(
        self,
        source: Union[str, BaseKnowledgeSource],
        collection: str = "default",
        metadata: Optional[dict] = None,
        skip_enrichment: bool = False,
    ) -> IngestionResult:
        """Ingest a source into the brain.

        Args:
            source: file path (auto-detected) or BaseKnowledgeSource instance
            collection: namespace for this ingestion (maps to memory type)
            metadata: extra metadata attached to all chunks
            skip_enrichment: skip storage enrichment step

        Returns:
            IngestionResult with counts and any errors
        """
        start = time.time()
        result = IngestionResult()

        # Resolve source
        if isinstance(source, str):
            try:
                src = detect_source(source)
            except ValueError as e:
                result.errors.append(str(e))
                result.duration_seconds = time.time() - start
                return result
        else:
            src = source

        source_path = src.source_path() or str(source)
        result.source = source_path

        # Change detection
        source_hash = src.file_hash()
        result.source_hash = source_hash

        if source_hash:
            try:
                import aibrain_db
                db = aibrain_db.get_db()
                _ensure_ingestion_log(db)
                if _check_source_hash(db, source_path, source_hash):
                    result.skipped_unchanged = True
                    result.duration_seconds = time.time() - start
                    logger.info("Skipping unchanged source: %s", source_path)
                    return result
            except Exception as e:
                logger.debug("Change detection check failed: %s", e)

        # Emit start event
        _emit_event("ingestion_start", key=source_path,
                     metadata={"collection": collection})

        # Load and chunk
        try:
            chunks = src.load_and_chunk()
        except Exception as e:
            result.errors.append(f"Load/chunk failed: {e}")
            result.duration_seconds = time.time() - start
            return result

        result.chunks_created = len(chunks)

        # Store each chunk
        stored = 0
        for i, chunk_data in enumerate(chunks):
            try:
                content = chunk_data["content"]
                chunk_meta = chunk_data.get("metadata", {})

                # Merge user metadata
                if metadata:
                    chunk_meta.update(metadata)
                chunk_meta["collection"] = collection

                # Enrich if enabled
                if not skip_enrichment:
                    content = _try_enrich(content)

                # Store via brain.add() — this triggers FTS5, embeddings, dedup
                add_result = self.brain.add(
                    content,
                    metadata=chunk_meta,
                    infer=False,  # No LLM extraction for document chunks
                )
                for r in add_result:
                    if r.get("event") in ("ADD", "UPDATE"):
                        stored += 1

                # Progress event every 100 chunks
                if (i + 1) % 100 == 0:
                    _emit_event(
                        "ingestion_progress",
                        key=source_path,
                        value=i + 1,
                        metadata={"total": len(chunks), "collection": collection},
                    )

            except Exception as e:
                result.errors.append(f"Chunk {i}: {e}")
                logger.warning("Failed to store chunk %d from %s: %s", i, source_path, e)

        result.memories_stored = stored
        result.duration_seconds = time.time() - start

        # Record in ingestion log
        if source_hash:
            try:
                import aibrain_db
                db = aibrain_db.get_db()
                _ensure_ingestion_log(db)
                _record_ingestion(db, source_path, source_hash, stored, collection)
            except Exception as e:
                logger.debug("Failed to record ingestion: %s", e)

        # Emit completion event
        _emit_event(
            "ingestion_complete",
            key=source_path,
            value=stored,
            metadata={
                "collection": collection,
                "chunks": len(chunks),
                "stored": stored,
                "errors": len(result.errors),
                "duration": result.duration_seconds,
            },
        )

        logger.info(
            "Ingested %s: %d chunks, %d stored, %d errors in %.1fs",
            source_path, len(chunks), stored, len(result.errors),
            result.duration_seconds,
        )

        return result

    def ingest_directory(
        self,
        path: str,
        glob: str = "**/*",
        collection: str = "default",
        metadata: Optional[dict] = None,
    ) -> IngestionResult:
        """Ingest all supported files in a directory.

        Never crashes on a single bad file — logs error and continues.
        """
        start = time.time()
        combined = IngestionResult(source=path)

        dir_source = DirectorySource(path=path, glob=glob)
        file_sources = dir_source.iter_sources()

        if not file_sources:
            combined.errors.append(f"No supported files found in {path}")
            combined.duration_seconds = time.time() - start
            return combined

        for file_path, src in file_sources:
            try:
                result = self.ingest(
                    src, collection=collection, metadata=metadata,
                )
                combined.chunks_created += result.chunks_created
                combined.memories_stored += result.memories_stored
                combined.errors.extend(result.errors)
            except Exception as e:
                combined.errors.append(f"{file_path}: {e}")
                logger.warning("Failed to ingest %s: %s", file_path, e)

        combined.duration_seconds = time.time() - start
        return combined
