"""
memory_api.py — Standard-compatible Brain API for AIBrain.

Provides a simple, zero-config memory interface that matches and surpasses
the standard memory API while leveraging AIBrain's existing storage, FTS5, and embeddings.

Usage:
    from aibrain import Brain

    brain = Brain()  # zero config, works locally
    brain.add("I love playing tennis on weekends", user_id="alice")
    results = brain.search("What does Alice like?", user_id="alice")
    all_mems = brain.get_all(user_id="alice")
"""

import json
import logging
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Union

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Ensure aibrain_db is importable (flat-file at project root)
# ---------------------------------------------------------------------------
_project_root = Path(__file__).resolve().parent.parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

import aibrain_db


# ---------------------------------------------------------------------------
# History table migration
# ---------------------------------------------------------------------------

_HISTORY_DDL = """
CREATE TABLE IF NOT EXISTS memory_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    old_content TEXT,
    new_content TEXT,
    changed_by TEXT,
    created_at TEXT NOT NULL
);
"""


def _ensure_history_table(db: sqlite3.Connection):
    """Create memory_history table if it doesn't exist."""
    db.executescript(_HISTORY_DDL)


def _ensure_user_id_column(db: sqlite3.Connection):
    """Add user_id and agent_id columns to memories if missing."""
    cols = {row[1] for row in db.execute("PRAGMA table_info(memories)").fetchall()}
    if "user_id" not in cols:
        db.execute("ALTER TABLE memories ADD COLUMN user_id TEXT DEFAULT ''")
    if "agent_id" not in cols:
        db.execute("ALTER TABLE memories ADD COLUMN agent_id TEXT DEFAULT ''")
    db.commit()


def _record_history(db: sqlite3.Connection, memory_id: int, action: str,
                    old_content: str = None, new_content: str = None,
                    changed_by: str = None):
    """Write a row to memory_history."""
    db.execute(
        "INSERT INTO memory_history (memory_id, action, old_content, new_content, changed_by, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (memory_id, action, old_content, new_content, changed_by,
         datetime.now(timezone.utc).isoformat()),
    )
    db.commit()


# ---------------------------------------------------------------------------
# LLM fact extraction helpers
# ---------------------------------------------------------------------------

def _try_extract_facts(text: str) -> list[str]:
    """Use llm_router.complete() to extract structured facts from text.

    Returns a list of fact strings, or [text] if extraction fails/unavailable.
    """
    try:
        from backend.llm_router import complete

        prompt = (
            "Extract key facts from this text. Return ONLY valid JSON with no "
            'markdown formatting: {"facts": ["fact1", "fact2"]}\n\n'
            f"Text: {text}"
        )
        result = complete(prompt, category="simple", max_tokens=512)
        content = result.get("content", "")
        # Strip markdown code fences if present
        content = content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[-1]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
        data = json.loads(content)
        facts = data.get("facts", [])
        if facts and isinstance(facts, list):
            return [str(f) for f in facts if f]
    except Exception as exc:
        logger.debug("Fact extraction unavailable or failed: %s", exc)
    return [text]


# ---------------------------------------------------------------------------
# Deduplication helpers
# ---------------------------------------------------------------------------

class DedupeAction:
    ADD = "ADD"
    UPDATE = "UPDATE"
    SKIP = "SKIP"


def _cosine_similarity_fts(db: sqlite3.Connection, text: str,
                           user_id: str = None, limit: int = 5) -> list[dict]:
    """Find similar memories using FTS5 ranking (proxy for semantic similarity)."""
    safe_q = aibrain_db._sanitize_fts5(text)
    sql = (
        "SELECT m.*, rank AS fts_score "
        "FROM memories m JOIN memories_fts f ON m.id = f.rowid "
        "WHERE memories_fts MATCH ? AND m.active = 1"
    )
    params: list[Any] = [safe_q]
    if user_id:
        sql += " AND m.user_id = ?"
        params.append(user_id)
    sql += " ORDER BY rank LIMIT ?"
    params.append(limit)
    try:
        return [dict(r) for r in db.execute(sql, params).fetchall()]
    except Exception:
        return []


def _vec_similarity(db: sqlite3.Connection, text: str,
                    user_id: str = None, limit: int = 5,
                    threshold: float = 0.85) -> list[dict]:
    """Find similar memories using sqlite-vec embeddings if available.

    Returns list of dicts with 'vec_distance' key (lower = more similar for L2,
    but sqlite-vec MATCH returns cosine distance where lower = closer).
    """
    try:
        # Import embedding helpers from mcp_server (same process-safe pattern)
        from mcp_server import _vec_enabled, _embed
        if not _vec_enabled:
            return []

        query_emb = _embed(text)
        rows = db.execute(
            "SELECT v.memory_id, v.distance FROM memories_vec v "
            "WHERE v.embedding MATCH ? AND k = ?",
            (query_emb, limit),
        ).fetchall()

        results = []
        for row in rows:
            # sqlite-vec cosine distance: 0 = identical, 2 = opposite
            # Convert to similarity: sim = 1 - distance/2
            sim = 1.0 - (row[1] / 2.0)
            if sim < threshold:
                continue
            mem = db.execute(
                "SELECT * FROM memories WHERE id = ? AND active = 1", (row[0],)
            ).fetchone()
            if mem:
                d = dict(mem)
                if user_id and d.get("user_id", "") != user_id:
                    continue
                d["similarity"] = sim
                results.append(d)
        return results
    except Exception:
        return []


def _deduplicate(db: sqlite3.Connection, new_fact: str,
                 user_id: str = None, threshold: float = 0.85) -> tuple[str, Optional[dict]]:
    """Compare new fact against existing memories for same user.

    Returns (action, existing_memory_or_None):
        - ("ADD", None) — new fact, no close match
        - ("UPDATE", existing) — should merge with existing
        - ("SKIP", existing) — near-duplicate, skip
    """
    # Try vector similarity first (more accurate)
    candidates = _vec_similarity(db, new_fact, user_id=user_id,
                                 limit=3, threshold=threshold)

    # Fall back to FTS if no vector matches
    if not candidates:
        candidates = _cosine_similarity_fts(db, new_fact, user_id=user_id, limit=3)
        # FTS rank is negative (more negative = better match)
        # We can't easily convert to a 0-1 similarity, so only skip exact matches
        for c in candidates:
            if c.get("content", "").strip().lower() == new_fact.strip().lower():
                return DedupeAction.SKIP, c
        # No exact match via FTS — treat as new
        return DedupeAction.ADD, None

    # Vector candidates have similarity scores
    best = candidates[0]
    sim = best.get("similarity", 0)

    if sim >= 0.95:
        # Near-exact duplicate
        return DedupeAction.SKIP, best
    elif sim >= threshold:
        # Similar enough to merge
        return DedupeAction.UPDATE, best
    else:
        return DedupeAction.ADD, None


# ---------------------------------------------------------------------------
# Brain class — Standard-compatible API
# ---------------------------------------------------------------------------

class Brain:
    """Standard-compatible memory API for AIBrain.

    Zero-config local memory with semantic search, fact extraction,
    deduplication, and full history tracking.

    Usage:
        brain = Brain()
        brain.add("User prefers dark mode", user_id="alice")
        results = brain.search("preferences", user_id="alice")
    """

    def __init__(self, db_path: Optional[str] = None):
        """Initialize Brain with optional custom DB path.

        Args:
            db_path: Path to SQLite DB. If None, auto-discovers aibrain.db.
        """
        if db_path:
            os.environ["AIBRAIN_DB"] = str(db_path)
            # Update module-level path and reset connection so get_db() reinits
            aibrain_db.DB_PATH = Path(db_path)
            if aibrain_db._conn is not None:
                try:
                    aibrain_db._conn.close()
                except Exception:
                    pass
                aibrain_db._conn = None

        self._db = aibrain_db.get_db()
        _ensure_history_table(self._db)
        _ensure_user_id_column(self._db)

    # -- Core API (Standard-compatible) ------------------------------------------

    def add(
        self,
        messages: Union[str, list[dict]],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        metadata: Optional[dict] = None,
        infer: bool = True,
    ) -> list[dict]:
        """Add memories from text or conversation messages.

        Args:
            messages: Raw text or list of chat messages [{"role": ..., "content": ...}].
            user_id: Scope memories to a user.
            agent_id: Scope memories to an agent.
            metadata: Extra metadata to store in tags as JSON.
            infer: If True, extract facts via LLM before storing.

        Returns:
            List of dicts with 'id', 'memory', 'event' keys for each stored fact.
        """
        # Normalize input to plain text
        if isinstance(messages, list):
            text = "\n".join(
                m.get("content", str(m)) if isinstance(m, dict) else str(m)
                for m in messages
            )
        else:
            text = str(messages)

        # Extract facts or use raw text
        if infer:
            facts = _try_extract_facts(text)
        else:
            facts = [text]

        # Build tags
        tag_parts = []
        if metadata:
            tag_parts.append(json.dumps(metadata))

        results = []
        for fact in facts:
            # Deduplicate via canonical function (fast vec-table lookup)
            dedup_result = aibrain_db.canonical_dedup(
                fact, threshold=0.92, merge_threshold=0.85,
            )

            if dedup_result and dedup_result["action"] in ("dedup", "reinforce"):
                # Near-exact duplicate — skip
                results.append({
                    "id": dedup_result["id"],
                    "memory": fact,
                    "event": "SKIP",
                })
                continue

            # Also check user-scoped dedup via local helper as fallback
            action, existing = _deduplicate(
                self._db, fact, user_id=user_id
            )

            if action == DedupeAction.SKIP:
                results.append({
                    "id": existing["id"],
                    "memory": existing.get("content", ""),
                    "event": "SKIP",
                })
                continue

            if dedup_result and dedup_result["action"] == "merge":
                # Merge via canonical dedup
                existing = aibrain_db.get_memory(dedup_result["id"])
                if existing:
                    action = DedupeAction.UPDATE

            if action == DedupeAction.UPDATE and existing:
                # Merge: append new info to existing
                merged = existing["content"] + " | " + fact
                aibrain_db.update_memory(existing["id"], content=merged)
                _record_history(
                    self._db, existing["id"], "updated",
                    old_content=existing["content"],
                    new_content=merged,
                    changed_by=user_id or agent_id,
                )
                results.append({
                    "id": existing["id"],
                    "memory": merged,
                    "event": "UPDATE",
                })
                continue

            # ADD — new memory
            tags_str = ",".join(tag_parts) if tag_parts else ""
            mem_id = aibrain_db.create_memory(
                name=fact[:120],
                mem_type="user" if user_id else "project",
                content=fact,
                tags=tags_str,
            )

            # Set user_id / agent_id directly
            sets, vals = [], []
            if user_id:
                sets.append("user_id = ?")
                vals.append(user_id)
            if agent_id:
                sets.append("agent_id = ?")
                vals.append(agent_id)
            _ALLOWED_COLS = frozenset({"user_id", "agent_id"})
            if sets:
                vals.append(mem_id)
                set_clause = ", ".join(s for s in sets if s.split(" = ")[0] in _ALLOWED_COLS)  # noqa:SQL-WHITELIST
                self._db.execute(
                    "UPDATE memories SET " + set_clause + " WHERE id = ?", vals  # noqa:SQL-FSTRING
                )
                self._db.commit()

            _record_history(
                self._db, mem_id, "created",
                new_content=fact,
                changed_by=user_id or agent_id,
            )

            results.append({
                "id": mem_id,
                "memory": fact,
                "event": "ADD",
            })

        return results

    def search(
        self,
        query: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: int = 10,
    ) -> list[dict]:
        """Semantic search over memories using the canonical SelRoute pipeline.

        Delegates to aibrain_db.search_memories() which provides:
        - Full SelRoute fusion strategies (rrf, consensus, interleave, etc.)
        - Passage-level re-ranking
        - Temporal date filtering
        - Preference edge boosting
        - Salience scoring (FTS + vec + importance + recency + access count)
        - Explainable recall (reason + score_breakdown on every result)

        Args:
            query: Natural language search query.
            user_id: Filter to this user's memories.
            agent_id: Filter to this agent's memories.
            limit: Max results to return.

        Returns:
            List of memory dicts with id, memory, metadata, score,
            reason, and score_breakdown fields.
        """
        # Use canonical search (with full SelRoute pipeline)
        raw = aibrain_db.search_memories(query, limit=limit * 2)

        # Apply user_id / agent_id filtering
        filtered = []
        for r in raw:
            if user_id and r.get("user_id", "") != user_id:
                continue
            if agent_id and r.get("agent_id", "") != agent_id:
                continue
            filtered.append(r)

        return [
            {
                "id": r["id"],
                "memory": r.get("content", ""),
                "user_id": r.get("user_id", ""),
                "agent_id": r.get("agent_id", ""),
                "score": r.get("score_breakdown", {}).get("combined", 0),
                "created_at": r.get("created", ""),
                "updated_at": r.get("updated", ""),
                "metadata": {"tags": r.get("tags", ""), "type": r.get("type", "")},
                "reason": r.get("reason", ""),
                "score_breakdown": r.get("score_breakdown", {}),
            }
            for r in filtered[:limit]
        ]

    def get(self, memory_id: int) -> Optional[dict]:
        """Get a single memory by ID.

        Returns:
            Memory dict or None if not found (including soft-deleted).
        """
        mem = aibrain_db.get_memory(memory_id)
        if not mem or not mem.get("active", 1):
            return None
        return {
            "id": mem["id"],
            "memory": mem.get("content", ""),
            "user_id": mem.get("user_id", ""),
            "agent_id": mem.get("agent_id", ""),
            "created_at": mem.get("created", ""),
            "updated_at": mem.get("updated", ""),
            "metadata": {"tags": mem.get("tags", ""), "type": mem.get("type", "")},
        }

    def get_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict]:
        """List all memories, optionally filtered by user_id/agent_id.

        Returns:
            List of memory dicts.
        """
        db = self._db
        sql = "SELECT * FROM memories WHERE active = 1"
        params: list[Any] = []
        if user_id:
            sql += " AND user_id = ?"
            params.append(user_id)
        if agent_id:
            sql += " AND agent_id = ?"
            params.append(agent_id)
        sql += " ORDER BY updated DESC LIMIT ?"
        params.append(limit)

        rows = [dict(r) for r in db.execute(sql, params).fetchall()]
        return [
            {
                "id": r["id"],
                "memory": r.get("content", ""),
                "user_id": r.get("user_id", ""),
                "agent_id": r.get("agent_id", ""),
                "created_at": r.get("created", ""),
                "updated_at": r.get("updated", ""),
                "metadata": {"tags": r.get("tags", ""), "type": r.get("type", "")},
            }
            for r in rows
        ]

    def update(
        self,
        memory_id: int,
        data: str,
        metadata: Optional[dict] = None,
    ) -> Optional[dict]:
        """Update a memory's content.

        Args:
            memory_id: ID of memory to update.
            data: New content text.
            metadata: Optional new metadata (stored in tags).

        Returns:
            Updated memory dict, or None if not found.
        """
        old = aibrain_db.get_memory(memory_id)
        if not old:
            return None

        kwargs: dict[str, Any] = {"content": data, "name": data[:120]}
        if metadata is not None:
            kwargs["tags"] = json.dumps(metadata)

        aibrain_db.update_memory(memory_id, **kwargs)

        _record_history(
            self._db, memory_id, "updated",
            old_content=old.get("content", ""),
            new_content=data,
            changed_by=old.get("user_id") or old.get("agent_id"),
        )

        return self.get(memory_id)

    def delete(self, memory_id: int) -> bool:
        """Soft-delete a single memory.

        Returns:
            True if deleted, False if not found.
        """
        old = aibrain_db.get_memory(memory_id)
        if not old:
            return False

        _record_history(
            self._db, memory_id, "deleted",
            old_content=old.get("content", ""),
            changed_by=old.get("user_id") or old.get("agent_id"),
        )
        return aibrain_db.delete_memory(memory_id)

    def delete_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> int:
        """Bulk soft-delete memories for a user/agent.

        Args:
            user_id: Delete all memories for this user.
            agent_id: Delete all memories for this agent.

        Returns:
            Number of memories deleted.
        """
        if not user_id and not agent_id:
            raise ValueError("Must specify user_id or agent_id for delete_all")

        db = self._db
        sql = "SELECT id, content FROM memories WHERE active = 1"
        params: list[Any] = []
        if user_id:
            sql += " AND user_id = ?"
            params.append(user_id)
        if agent_id:
            sql += " AND agent_id = ?"
            params.append(agent_id)

        rows = db.execute(sql, params).fetchall()
        count = 0
        for row in rows:
            aibrain_db.delete_memory(row[0])
            _record_history(
                db, row[0], "deleted",
                old_content=row[1],
                changed_by=user_id or agent_id,
            )
            count += 1
        return count

    def history(self, memory_id: int) -> list[dict]:
        """Get change history for a memory.

        Returns:
            List of history entries ordered newest-first.
        """
        rows = self._db.execute(
            "SELECT * FROM memory_history WHERE memory_id = ? ORDER BY created_at DESC",
            (memory_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def count(self, user_id: Optional[str] = None) -> int:
        """Count active memories, optionally scoped to a user.

        Returns:
            Integer count.
        """
        sql = "SELECT COUNT(*) FROM memories WHERE active = 1"
        params: list[Any] = []
        if user_id:
            sql += " AND user_id = ?"
            params.append(user_id)
        return self._db.execute(sql, params).fetchone()[0]

    def smart_search(
        self,
        query: str,
        limit: int = 10,
        sufficiency_threshold: float = 0.85,
    ) -> dict:
        """Tiered retrieval: summaries first, then memories, then satellites.

        Uses category summaries for cheap initial lookups, falling through
        to full memory search and federated search as needed.

        Args:
            query: Natural language search query.
            limit: Max results to return.
            sufficiency_threshold: Score threshold for early stopping at tier 1.

        Returns:
            Dict with 'results', 'tier_used', 'tokens_saved', 'reason'.
        """
        return aibrain_db.tiered_search(
            query=query,
            limit=limit,
            sufficiency_threshold=sufficiency_threshold,
            db=self._db,
        )

    def ingest(self, source: str, collection: str = "default", **kwargs):
        """Ingest a document, file, or directory into the brain.

        Supports PDF, CSV, Excel, JSON, JSONL, text, and directories.

        Usage:
            brain = Brain()
            brain.ingest("report.pdf")
            brain.ingest("data.csv", collection="sales")
            brain.ingest("/path/to/docs/", collection="knowledge_base")

        Args:
            source: File path or directory. Type auto-detected from extension.
            collection: Namespace for this ingestion (stored in metadata).
            **kwargs: Passed through to IngestionPipeline.ingest()
                (e.g., metadata=dict, skip_enrichment=bool).

        Returns:
            IngestionResult with counts and any errors.
        """
        from aibrain.core.ingest import IngestionPipeline
        pipeline = IngestionPipeline(brain=self)
        return pipeline.ingest(source, collection=collection, **kwargs)

    def reset(self, confirm: bool = False) -> bool:
        """Delete ALL memories (hard delete). Requires confirm=True.

        Returns:
            True if reset completed.
        """
        if not confirm:
            raise ValueError(
                "Pass confirm=True to reset all memories. This is irreversible."
            )
        db = self._db
        db.execute("DELETE FROM memory_history")
        db.execute("DELETE FROM memories")
        # Rebuild FTS index
        try:
            db.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
        except Exception:
            pass
        db.commit()
        return True
