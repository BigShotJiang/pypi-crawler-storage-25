"""
adapters.py — Agent adapter registry for multi-provider LLM support.

Each company agent can be configured to use a specific LLM provider/model.
Adapters handle the provider-specific API differences.

Supported providers:
  - claude (Anthropic Claude via API)
  - openai (GPT-4o, GPT-4o-mini via OpenAI API)
  - gemini (Google Gemini via API)
  - ollama (Local models — qwen, llama, gemma, etc.)
  - groq (Groq-hosted models — fast inference)
  - together (Together AI — open source models)
  - deepseek (DeepSeek models)
  - local (Any OpenAI-compatible local server)

Usage:
    from aibrain.core.adapters import get_adapter, list_adapters, register_adapter

    adapter = get_adapter("claude")
    response = adapter.complete("What is 2+2?", model="claude-sonnet-4-20250514")

    # Agents reference adapters by name
    agent.model = "claude"  # uses Claude adapter
    agent.model = "ollama"  # uses local Ollama adapter
"""

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class AdapterConfig:
    """Configuration for an LLM adapter."""
    name: str
    provider: str
    display_name: str
    models: list[str]
    api_key_env: str = ""
    base_url: str = ""
    default_model: str = ""
    supports_streaming: bool = True
    supports_tools: bool = True
    max_context: int = 128000
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    status: str = "available"
    installed: bool = False


# Built-in adapter registry
ADAPTERS: dict[str, AdapterConfig] = {
    "claude": AdapterConfig(
        name="claude",
        provider="anthropic",
        display_name="Anthropic Claude",
        models=["claude-opus-4-20250514", "claude-sonnet-4-20250514", "claude-haiku-4-5-20251001"],
        api_key_env="ANTHROPIC_API_KEY",
        default_model="claude-sonnet-4-20250514",
        max_context=200000,
        cost_per_1k_input=0.003,
        cost_per_1k_output=0.015,
    ),
    "openai": AdapterConfig(
        name="openai",
        provider="openai",
        display_name="OpenAI GPT",
        models=["gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "o3-mini"],
        api_key_env="OPENAI_API_KEY",
        default_model="gpt-4o-mini",
        max_context=128000,
        cost_per_1k_input=0.0025,
        cost_per_1k_output=0.01,
    ),
    "gemini": AdapterConfig(
        name="gemini",
        provider="google",
        display_name="Google Gemini",
        models=["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
        api_key_env="GOOGLE_API_KEY",
        default_model="gemini-2.5-flash",
        max_context=1000000,
        cost_per_1k_input=0.00015,
        cost_per_1k_output=0.0006,
    ),
    "ollama": AdapterConfig(
        name="ollama",
        provider="ollama",
        display_name="Ollama (Local)",
        models=["qwen2.5:7b-instruct", "qwen3:8b", "llama3.1:8b", "gemma3:4b", "deepseek-r1:8b"],
        base_url="http://localhost:11434",
        default_model="qwen2.5:7b-instruct",
        max_context=32000,
        cost_per_1k_input=0.0,
        cost_per_1k_output=0.0,
        supports_tools=False,
    ),
    "groq": AdapterConfig(
        name="groq",
        provider="groq",
        display_name="Groq (Fast)",
        models=["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"],
        api_key_env="GROQ_API_KEY",
        default_model="llama-3.3-70b-versatile",
        max_context=128000,
        cost_per_1k_input=0.00059,
        cost_per_1k_output=0.00079,
    ),
    "together": AdapterConfig(
        name="together",
        provider="together_ai",
        display_name="Together AI",
        models=["meta-llama/Llama-3.3-70B-Instruct-Turbo", "Qwen/Qwen2.5-72B-Instruct-Turbo"],
        api_key_env="TOGETHER_API_KEY",
        default_model="meta-llama/Llama-3.3-70B-Instruct-Turbo",
        max_context=131072,
        cost_per_1k_input=0.00088,
        cost_per_1k_output=0.00088,
    ),
    "deepseek": AdapterConfig(
        name="deepseek",
        provider="deepseek",
        display_name="DeepSeek",
        models=["deepseek-chat", "deepseek-reasoner"],
        api_key_env="DEEPSEEK_API_KEY",
        default_model="deepseek-chat",
        max_context=64000,
        cost_per_1k_input=0.00014,
        cost_per_1k_output=0.00028,
    ),
    "local": AdapterConfig(
        name="local",
        provider="openai",
        display_name="Local Server (OpenAI-compatible)",
        models=["default"],
        base_url="http://localhost:8080/v1",
        default_model="default",
        max_context=32000,
        cost_per_1k_input=0.0,
        cost_per_1k_output=0.0,
        supports_tools=False,
    ),
}


def get_adapter(name: str) -> AdapterConfig | None:
    """Get an adapter by name."""
    return ADAPTERS.get(name)


def list_adapters() -> list[dict]:
    """List all adapters with availability status."""
    result = []
    for name, adapter in ADAPTERS.items():
        # Check if the adapter is usable
        available = False
        if adapter.api_key_env:
            available = bool(os.environ.get(adapter.api_key_env))
        elif adapter.provider == "ollama":
            # Check if Ollama is running
            try:
                import urllib.request
                urllib.request.urlopen(f"{adapter.base_url}/api/tags", timeout=2)
                available = True
            except Exception:
                available = False
        elif adapter.provider == "openai" and adapter.name == "local":
            try:
                import urllib.request
                urllib.request.urlopen(f"{adapter.base_url}/models", timeout=2)
                available = True
            except Exception:
                available = False

        entry = {
            "name": adapter.name,
            "display_name": adapter.display_name,
            "provider": adapter.provider,
            "models": adapter.models,
            "default_model": adapter.default_model,
            "max_context": adapter.max_context,
            "cost_input": adapter.cost_per_1k_input,
            "cost_output": adapter.cost_per_1k_output,
            "supports_streaming": adapter.supports_streaming,
            "supports_tools": adapter.supports_tools,
            "available": available,
            "status": "connected" if available else "not configured",
        }
        result.append(entry)
    return result


def register_adapter(name: str, config: dict) -> AdapterConfig:
    """Register a custom adapter."""
    adapter = AdapterConfig(
        name=name,
        provider=config.get("provider", "openai"),
        display_name=config.get("display_name", name),
        models=config.get("models", ["default"]),
        api_key_env=config.get("api_key_env", ""),
        base_url=config.get("base_url", ""),
        default_model=config.get("default_model", "default"),
        max_context=config.get("max_context", 32000),
        cost_per_1k_input=config.get("cost_per_1k_input", 0.0),
        cost_per_1k_output=config.get("cost_per_1k_output", 0.0),
    )
    ADAPTERS[name] = adapter
    return adapter


def get_model_for_agent(agent_model: str) -> tuple[str, str]:
    """Resolve an agent's model setting to (provider_prefix, model_id).

    agent_model can be:
      - "auto" → use default routing
      - "claude" → use Claude adapter's default model
      - "claude/claude-sonnet-4-20250514" → specific model
      - "ollama/qwen2.5:7b-instruct" → specific local model
    """
    if agent_model == "auto" or not agent_model:
        return ("", "auto")

    if "/" in agent_model:
        parts = agent_model.split("/", 1)
        return (parts[0], parts[1])

    adapter = get_adapter(agent_model)
    if adapter:
        prefix = f"{adapter.provider}/" if adapter.provider != "anthropic" else ""
        return (adapter.name, f"{prefix}{adapter.default_model}")

    # Unknown adapter name — treat as literal model ID
    return ("", agent_model)
