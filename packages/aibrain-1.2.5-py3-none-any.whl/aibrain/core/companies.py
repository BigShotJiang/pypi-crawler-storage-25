"""
companies.py — Companies feature for AIBrain.

Create and manage AI agent teams that learn and improve over time.
Multi-agent orchestration backed by persistent brain memory.

Usage:
    from aibrain.core.companies import create_company, hire_agent, create_task

    company = create_company("Marketing Team", mission="Scale content to 1M reach")
    ceo = hire_agent(company["id"], "CEO", role="ceo")
    task = create_task(company["id"], "Write 5 LinkedIn posts", assignee=ceo["id"])
"""

import json
import logging
import secrets
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.companies")


def _get_db():
    """Get database connection."""
    import os
    root = Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain"))
    db_path = root / "aibrain.db"
    if not db_path.exists():
        # Try project directory
        db_path = Path("aibrain.db")
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


# ---------------------------------------------------------------------------
# Companies
# ---------------------------------------------------------------------------

def create_company(name: str, mission: str = "") -> dict:
    """Create a new company."""
    db = _get_db()
    company_id = secrets.token_urlsafe(8)

    # Check tier limits
    try:
        from aibrain_licensing import get_license
        lic = get_license()
        existing = db.execute("SELECT COUNT(*) FROM companies WHERE status='active'").fetchone()[0]
        limits = json.loads(db.execute("SELECT value FROM config WHERE key='companies_tier_limits'").fetchone()[0])
        max_companies = limits.get(f"{lic.tier}_companies", 1)
        if existing >= max_companies:
            db.close()
            return {"error": f"Company limit reached ({existing}/{max_companies}). Upgrade to Pro for unlimited companies."}
    except Exception:
        pass

    db.execute(
        "INSERT INTO companies (id, name, mission) VALUES (?, ?, ?)",
        (company_id, name, mission)
    )
    db.commit()

    result = dict(db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone())
    db.close()

    log.info("Company created: %s (%s)", name, company_id)
    return result


def list_companies(status: str = None) -> list:
    """List all companies."""
    db = _get_db()
    if status:
        rows = db.execute("SELECT * FROM companies WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM companies ORDER BY created_at DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_company(company_id: str) -> Optional[dict]:
    """Get company details with agent count and task stats."""
    db = _get_db()
    company = db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        db.close()
        return None

    result = dict(company)
    result["agent_count"] = db.execute(
        "SELECT COUNT(*) FROM company_agents WHERE company_id=? AND status != 'terminated'",
        (company_id,)
    ).fetchone()[0]
    result["active_tasks"] = db.execute(
        "SELECT COUNT(*) FROM company_issues WHERE company_id=? AND status IN ('todo','in_progress','in_review')",
        (company_id,)
    ).fetchone()[0]
    result["completed_tasks"] = db.execute(
        "SELECT COUNT(*) FROM company_issues WHERE company_id=? AND status='done'",
        (company_id,)
    ).fetchone()[0]

    db.close()
    return result


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def hire_agent(company_id: str, name: str, role: str = "general",
               title: str = "", reports_to: str = None,
               model: str = "auto", capabilities: str = "") -> dict:
    """Hire a new agent for a company."""
    db = _get_db()
    agent_id = secrets.token_urlsafe(8)

    # Check tier limits
    try:
        from aibrain_licensing import get_license
        lic = get_license()
        existing = db.execute(
            "SELECT COUNT(*) FROM company_agents WHERE company_id=? AND status != 'terminated'",
            (company_id,)
        ).fetchone()[0]
        limits = json.loads(db.execute("SELECT value FROM config WHERE key='companies_tier_limits'").fetchone()[0])
        max_agents = limits.get(f"{lic.tier}_agents_per_company", 2)
        if existing >= max_agents:
            db.close()
            return {"error": f"Agent limit reached ({existing}/{max_agents}). Upgrade to Pro for more agents."}
    except Exception:
        pass

    # Map role to harness task type and authority
    role_config = {
        "ceo": {"task_type": "complex", "authority": "admin"},
        "manager": {"task_type": "judgment", "authority": "elevated"},
        "general": {"task_type": "simple", "authority": "standard"},
    }
    config = role_config.get(role, role_config["general"])

    db.execute("""
        INSERT INTO company_agents
        (id, company_id, name, role, title, reports_to, model, task_type, authority, capabilities)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (agent_id, company_id, name, role, title or name, reports_to, model,
          config["task_type"], config["authority"], capabilities))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_agents WHERE id=?", (agent_id,)).fetchone())
    db.close()

    log.info("Agent hired: %s (%s) for company %s", name, role, company_id)
    return result


def list_agents(company_id: str, status: str = None) -> list:
    """List all agents in a company."""
    db = _get_db()
    if status:
        rows = db.execute(
            "SELECT * FROM company_agents WHERE company_id=? AND status=? ORDER BY role, name",
            (company_id, status)
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM company_agents WHERE company_id=? AND status != 'terminated' ORDER BY role, name",
            (company_id,)
        ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_agent(agent_id: str) -> Optional[dict]:
    """Get agent details."""
    db = _get_db()
    agent = db.execute("SELECT * FROM company_agents WHERE id=?", (agent_id,)).fetchone()
    db.close()
    return dict(agent) if agent else None


# ---------------------------------------------------------------------------
# Tasks / Issues
# ---------------------------------------------------------------------------

def create_task(company_id: str, title: str, description: str = "",
                assignee_agent_id: str = None, priority: str = "medium",
                parent_id: str = None, project: str = "") -> dict:
    """Create a task/issue for a company."""
    db = _get_db()
    task_id = secrets.token_urlsafe(8)

    # Get next issue number for this company
    max_num = db.execute(
        "SELECT COALESCE(MAX(issue_number), 0) FROM company_issues WHERE company_id=?",
        (company_id,)
    ).fetchone()[0]
    issue_number = max_num + 1

    db.execute("""
        INSERT INTO company_issues
        (id, company_id, parent_id, title, description, assignee_agent_id, priority, project, issue_number)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (task_id, company_id, parent_id, title, description,
          assignee_agent_id, priority, project, issue_number))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()

    log.info("Task created: #%d %s (company %s)", issue_number, title, company_id)
    return result


def list_tasks(company_id: str, status: str = None, assignee: str = None) -> list:
    """List tasks for a company."""
    db = _get_db()
    sql = "SELECT * FROM company_issues WHERE company_id=?"
    params = [company_id]

    if status:
        sql += " AND status=?"
        params.append(status)
    if assignee:
        sql += " AND assignee_agent_id=?"
        params.append(assignee)

    sql += " ORDER BY priority, created_at DESC"
    rows = db.execute(sql, params).fetchall()
    db.close()
    return [dict(r) for r in rows]


def checkout_task(task_id: str, agent_id: str) -> dict:
    """Atomically claim a task. Returns 409-equivalent if already claimed."""
    db = _get_db()
    task = db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone()

    if not task:
        db.close()
        return {"error": "Task not found"}

    if task["status"] == "in_progress" and task["assignee_agent_id"] != agent_id:
        db.close()
        return {"error": "Task already claimed by another agent", "claimed_by": task["assignee_agent_id"]}

    db.execute("""
        UPDATE company_issues
        SET status='in_progress', assignee_agent_id=?, started_at=datetime('now'), updated_at=datetime('now')
        WHERE id=? AND status IN ('backlog', 'todo', 'blocked')
    """, (agent_id, task_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()
    return result


def complete_task(task_id: str, quality_score: float = None, cost_cents: int = 0) -> dict:
    """Mark a task as done."""
    db = _get_db()
    db.execute("""
        UPDATE company_issues
        SET status='done', completed_at=datetime('now'), updated_at=datetime('now'),
            quality_score=?, cost_cents=?
        WHERE id=?
    """, (quality_score, cost_cents, task_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()
    return result


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------

def request_approval(company_id: str, approval_type: str,
                     agent_id: str, payload: dict) -> dict:
    """Request board approval for an action."""
    db = _get_db()
    approval_id = secrets.token_urlsafe(8)

    db.execute("""
        INSERT INTO company_approvals (id, company_id, type, requested_by_agent_id, payload)
        VALUES (?, ?, ?, ?, ?)
    """, (approval_id, company_id, approval_type, agent_id, json.dumps(payload)))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    db.close()

    log.info("Approval requested: %s (company %s)", approval_type, company_id)
    return result


def approve(approval_id: str, note: str = "") -> dict:
    """Approve a pending request."""
    db = _get_db()
    db.execute("""
        UPDATE company_approvals
        SET status='approved', decision_note=?, decided_at=datetime('now')
        WHERE id=? AND status IN ('pending', 'revision_requested')
    """, (note, approval_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    db.close()
    return result


def reject(approval_id: str, note: str = "") -> dict:
    """Reject a pending request."""
    db = _get_db()
    db.execute("""
        UPDATE company_approvals
        SET status='rejected', decision_note=?, decided_at=datetime('now')
        WHERE id=? AND status IN ('pending', 'revision_requested')
    """, (note, approval_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    db.close()
    return result


def pending_approvals(company_id: str) -> list:
    """List pending approvals for a company."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_approvals WHERE company_id=? AND status IN ('pending','revision_requested') ORDER BY created_at",
        (company_id,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_main(args: list):
    """Handle company CLI commands."""
    if not args:
        print("Usage:")
        print("  aibrain company create <name> [--mission <text>]")
        print("  aibrain company list")
        print("  aibrain company status <name_or_id>")
        print("  aibrain agent hire <name> --company <id> [--role ceo|manager|general]")
        print("  aibrain agent list --company <id>")
        print("  aibrain task create <title> --company <id> [--assign <agent_id>]")
        print("  aibrain task list --company <id>")
        print("  aibrain inbox --company <id>")
        print("  aibrain approve <approval_id>")
        print("  aibrain reject <approval_id>")
        return

    subcmd = args[0]

    if subcmd == "create":
        name = args[1] if len(args) > 1 else input("Company name: ")
        mission = ""
        if "--mission" in args:
            idx = args.index("--mission")
            mission = args[idx + 1] if idx + 1 < len(args) else ""
        result = create_company(name, mission)
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Company '{name}' created (ID: {result['id']})")

    elif subcmd == "list":
        companies = list_companies()
        if not companies:
            print("No companies. Create one: aibrain company create <name>")
        else:
            print(f"\n{'Name':<25} {'Status':<10} {'Agents':>7} {'ID'}")
            print("-" * 55)
            for c in companies:
                db = _get_db()
                agents = db.execute("SELECT COUNT(*) FROM company_agents WHERE company_id=?", (c['id'],)).fetchone()[0]
                db.close()
                print(f"{c['name']:<25} {c['status']:<10} {agents:>7} {c['id']}")

    elif subcmd == "status":
        company_ref = args[1] if len(args) > 1 else ""
        db = _get_db()
        company = db.execute("SELECT * FROM companies WHERE id=? OR name=?", (company_ref, company_ref)).fetchone()
        db.close()
        if not company:
            print(f"Company '{company_ref}' not found")
            return
        info = get_company(company["id"])
        print(f"\n  {info['name']} ({info['status']})")
        print(f"  Mission: {info.get('mission', '-')}")
        print(f"  Agents: {info['agent_count']}")
        print(f"  Active tasks: {info['active_tasks']}")
        print(f"  Completed: {info['completed_tasks']}")

    else:
        print(f"Unknown company command: {subcmd}")


# ---------------------------------------------------------------------------
# Teams
# ---------------------------------------------------------------------------

def _ensure_teams_table():
    """Create teams table if missing."""
    db = _get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            name TEXT NOT NULL,
            agent_ids TEXT DEFAULT '[]',
            task_ids TEXT DEFAULT '[]',
            process TEXT DEFAULT 'sequential',
            status TEXT DEFAULT 'ready',
            last_run TEXT,
            last_result TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (company_id) REFERENCES companies(id)
        )
    """)
    db.commit()
    db.close()


_ensure_teams_table()


def create_team(company_id: str, name: str, agent_ids: list = None,
                task_ids: list = None, process: str = "sequential") -> dict:
    """Create a team within a company from selected agents and tasks.

    If agent_ids is None, uses all company agents.
    If task_ids is None, uses all pending/todo tasks.
    """
    db = _get_db()

    # Verify company exists
    company = db.execute("SELECT id FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        db.close()
        return {"error": "Company not found"}

    # Resolve agent IDs — default to all company agents
    if agent_ids is None:
        rows = db.execute(
            "SELECT id FROM company_agents WHERE company_id=? AND status != 'terminated'",
            (company_id,)
        ).fetchall()
        agent_ids = [r["id"] for r in rows]

    # Resolve task IDs — default to all pending/todo tasks
    if task_ids is None:
        rows = db.execute(
            "SELECT id FROM company_issues WHERE company_id=? AND status IN ('backlog','todo','in_progress')",
            (company_id,)
        ).fetchall()
        task_ids = [r["id"] for r in rows]

    team_id = secrets.token_urlsafe(8)
    now = datetime.now().isoformat()

    db.execute("""
        INSERT INTO teams (id, company_id, name, agent_ids, task_ids, process, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (team_id, company_id, name, json.dumps(agent_ids), json.dumps(task_ids), process, now))
    db.commit()

    result = dict(db.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone())
    db.close()

    # Parse JSON fields for the response
    result["agent_ids"] = json.loads(result.get("agent_ids") or "[]")
    result["task_ids"] = json.loads(result.get("task_ids") or "[]")

    log.info("Team created: %s (%s) for company %s", name, team_id, company_id)
    return result


def list_teams(company_id: str) -> list:
    """List all teams for a company."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM teams WHERE company_id=? ORDER BY created_at DESC",
        (company_id,)
    ).fetchall()
    db.close()
    teams = []
    for r in rows:
        t = dict(r)
        t["agent_ids"] = json.loads(t.get("agent_ids") or "[]")
        t["task_ids"] = json.loads(t.get("task_ids") or "[]")
        teams.append(t)
    return teams


def get_team(team_id: str) -> Optional[dict]:
    """Get team details including agent and task info."""
    db = _get_db()
    row = db.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone()
    if not row:
        db.close()
        return None

    result = dict(row)
    result["agent_ids"] = json.loads(result.get("agent_ids") or "[]")
    result["task_ids"] = json.loads(result.get("task_ids") or "[]")

    # Enrich with agent details
    agents = []
    for aid in result["agent_ids"]:
        agent = db.execute("SELECT id, name, role, title, status FROM company_agents WHERE id=?", (aid,)).fetchone()
        if agent:
            agents.append(dict(agent))
    result["agents"] = agents

    # Enrich with task details
    tasks = []
    for tid in result["task_ids"]:
        task = db.execute("SELECT id, title, status, priority, quality_score FROM company_issues WHERE id=?", (tid,)).fetchone()
        if task:
            tasks.append(dict(task))
    result["tasks"] = tasks

    # Parse last_result if present
    if result.get("last_result"):
        try:
            result["last_result"] = json.loads(result["last_result"])
        except (json.JSONDecodeError, TypeError):
            pass

    db.close()
    return result


def delete_team(team_id: str) -> bool:
    """Delete a team."""
    db = _get_db()
    existing = db.execute("SELECT id FROM teams WHERE id=?", (team_id,)).fetchone()
    if not existing:
        db.close()
        return False
    db.execute("DELETE FROM teams WHERE id=?", (team_id,))
    db.commit()
    db.close()
    log.info("Team deleted: %s", team_id)
    return True


def run_team(company_id: str, team_id: str, inputs: dict = None) -> dict:
    """Execute a team — assembles Agent/Task objects, creates Team, calls kickoff().

    Stores results back to the company tasks (updates status, stores output).
    """
    db = _get_db()
    team_row = db.execute(
        "SELECT * FROM teams WHERE id=? AND company_id=?",
        (team_id, company_id)
    ).fetchone()
    if not team_row:
        db.close()
        return {"error": "Team not found"}

    team_data = dict(team_row)
    agent_ids = json.loads(team_data.get("agent_ids") or "[]")
    task_ids = json.loads(team_data.get("task_ids") or "[]")
    process = team_data.get("process", "sequential")

    # Mark team as running
    db.execute("UPDATE teams SET status='running' WHERE id=?", (team_id,))
    db.commit()
    db.close()

    try:
        from aibrain.core.agents import Agent, Task, Team

        # Build Agent objects from DB
        agent_map = {}
        agents = []
        for aid in agent_ids:
            db_agent = get_agent(aid)
            if not db_agent:
                continue
            agent = Agent(
                id=db_agent["id"],
                role=db_agent.get("role", "general"),
                goal=db_agent.get("title", db_agent.get("name", "")),
                llm=db_agent.get("model", "auto"),
                backstory=db_agent.get("capabilities", ""),
            )
            agents.append(agent)
            agent_map[aid] = agent

        # Build Task objects from DB
        tasks = []
        for tid in task_ids:
            db2 = _get_db()
            db_task = db2.execute("SELECT * FROM company_issues WHERE id=?", (tid,)).fetchone()
            db2.close()
            if not db_task:
                continue
            db_task = dict(db_task)
            assignee = agent_map.get(db_task.get("assignee_agent_id", ""))
            task = Task(
                id=db_task["id"],
                description=db_task.get("title", ""),
                expected_output=db_task.get("description", "Complete the task successfully"),
                agent=assignee,
            )
            tasks.append(task)

        if not agents:
            db = _get_db()
            db.execute("UPDATE teams SET status='failed', last_run=datetime('now') WHERE id=?", (team_id,))
            db.commit()
            db.close()
            return {"error": "No valid agents found for this team"}

        if not tasks:
            db = _get_db()
            db.execute("UPDATE teams SET status='failed', last_run=datetime('now') WHERE id=?", (team_id,))
            db.commit()
            db.close()
            return {"error": "No valid tasks found for this team"}

        # Create and run the Team
        company = get_company(company_id)
        team = Team(
            name=company.get("name", "team") + "/" + team_data.get("name", "team"),
            agents=agents,
            tasks=tasks,
            process=process,
            memory=True,
        )

        team_output = team.kickoff(inputs=inputs or {})

        # Store results back
        result_dict = team_output.model_dump()
        db = _get_db()

        # Update task statuses with quality scores
        for task_out in team_output.task_outputs:
            if task_out.task_id:
                db.execute("""
                    UPDATE company_issues
                    SET status='done', quality_score=?, completed_at=datetime('now'), updated_at=datetime('now')
                    WHERE id=?
                """, (task_out.quality, task_out.task_id))

        # Update team record
        db.execute("""
            UPDATE teams SET status='completed', last_run=datetime('now'), last_result=?
            WHERE id=?
        """, (json.dumps(result_dict), team_id))
        db.commit()
        db.close()

        log.info("Team run completed: %s (success=%s)", team_id, team_output.success)
        return result_dict

    except Exception as e:
        log.error("Team run failed: %s — %s", team_id, e)
        db = _get_db()
        db.execute("""
            UPDATE teams SET status='failed', last_run=datetime('now'),
            last_result=? WHERE id=?
        """, (json.dumps({"error": str(e)}), team_id))
        db.commit()
        db.close()
        return {"error": str(e), "success": False}
