"""
heartbeat.py — Agent heartbeat scheduler for Companies feature.

Wakes agents on their configured schedule, runs them through the harness,
and records the results. Each heartbeat follows the 9-step protocol:

1. Wake → check AIBrain memory for context
2. Check inbox → pending tasks, approvals, mentions
3. Claim highest-priority task (atomic checkout)
4. Execute task through harness
5. Evaluate quality (0.0-1.0)
6. Store learnings to brain memory
7. Update task status + comments
8. Delegate subtasks if manager/CEO
9. Sleep until next heartbeat

Usage:
    from aibrain.core.heartbeat import run_heartbeat, check_due_heartbeats

    # Run a single agent's heartbeat
    result = run_heartbeat(agent_id)

    # Check and run all due heartbeats
    results = check_due_heartbeats()
"""

import json
import logging
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from aibrain.core.harness import execute, HarnessConfig, HarnessResult

log = logging.getLogger("aibrain.heartbeat")


def _get_db():
    """Get database connection."""
    import os
    root = Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain"))
    db_path = root / "aibrain.db"
    if not db_path.exists():
        db_path = Path("aibrain.db")
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


def _try_delegation(agent: dict, company_id: str, db) -> str:
    """CEO/Manager behavior: look at company goals, create and delegate tasks to idle workers."""

    # Find idle workers that report to this agent
    workers = db.execute("""
        SELECT * FROM company_agents
        WHERE company_id=? AND reports_to=? AND status IN ('idle', 'active')
    """, (company_id, agent["id"])).fetchall()

    if not workers:
        return ""

    # Check if workers already have pending tasks
    idle_workers = []
    for w in workers:
        pending = db.execute("""
            SELECT COUNT(*) FROM company_issues
            WHERE assignee_agent_id=? AND status IN ('backlog', 'todo', 'in_progress')
        """, (w["id"],)).fetchone()[0]
        if pending == 0:
            idle_workers.append(dict(w))

    if not idle_workers:
        # Check if there are pending hire approvals to follow up on
        pending_hires = db.execute("""
            SELECT * FROM company_approvals
            WHERE company_id=? AND type='hire_agent' AND status='approved'
            AND requested_by_agent_id=?
        """, (company_id, agent["id"])).fetchall()

        for hire in pending_hires:
            try:
                payload = json.loads(hire["payload"]) if hire["payload"] else {}
                # Create the approved agent
                from aibrain.core.companies import hire_agent
                new_agent = hire_agent(
                    company_id,
                    payload.get("name", "New Agent"),
                    role=payload.get("role", "general"),
                    reports_to=agent["id"],
                    capabilities=payload.get("capabilities", ""),
                )
                if "error" not in new_agent:
                    # Mark approval as processed
                    db.execute(
                        "UPDATE company_approvals SET status='approved', decision_note='Agent created' WHERE id=?",
                        (hire["id"],)
                    )
                    db.commit()
                    return f"Hired approved agent: {new_agent['name']}"
            except Exception as e:
                log.warning("Failed to process hire approval: %s", e)

        return ""

    # Ask the CEO/Manager to create tasks for idle workers
    worker_names = ", ".join(w["name"] for w in idle_workers)
    prompt = (
        f"You are {agent['name']}, {agent['role']} at {agent.get('company_name', 'the company')}.\n"
        f"Company mission: {agent.get('company_mission', 'Not specified')}\n\n"
        f"These team members are idle and need work:\n"
    )
    for w in idle_workers:
        prompt += f"- {w['name']} ({w.get('capabilities', 'general')})\n"

    prompt += (
        f"\nCreate ONE specific, actionable task for each idle worker. "
        f"Each task should advance the company mission.\n\n"
        f"Respond in this exact format for each worker:\n"
        f"TASK: [worker name] | [task title] | [priority: high/medium/low] | [brief description]\n"
    )

    try:
        import sys as _sys
        _sys.path.insert(0, str(Path(__file__).parent.parent.parent / "backend"))
        from llm_router import complete

        result = complete(
            prompt=prompt,
            category="judgment",
            max_tokens=512,
            workflow_id=f"delegation:{agent['name']}",
        )

        output = result.get("content", "")
        tasks_created = 0

        # Parse TASK lines
        import secrets as _secrets
        for line in output.splitlines():
            if line.strip().startswith("TASK:"):
                parts = line.replace("TASK:", "").strip().split("|")
                if len(parts) >= 3:
                    worker_name = parts[0].strip()
                    title = parts[1].strip()
                    priority = parts[2].strip().lower()
                    description = parts[3].strip() if len(parts) > 3 else ""

                    if priority not in ("critical", "high", "medium", "low"):
                        priority = "medium"

                    # Find the worker
                    worker = next((w for w in idle_workers if w["name"].lower() in worker_name.lower()), None)
                    if worker:
                        task_id = _secrets.token_urlsafe(8)
                        max_num = db.execute(
                            "SELECT COALESCE(MAX(issue_number), 0) FROM company_issues WHERE company_id=?",
                            (company_id,)
                        ).fetchone()[0]

                        db.execute("""
                            INSERT INTO company_issues
                            (id, company_id, title, description, assignee_agent_id,
                             priority, issue_number, origin, request_depth)
                            VALUES (?, ?, ?, ?, ?, ?, ?, 'delegation', 1)
                        """, (task_id, company_id, title, description,
                              worker["id"], priority, max_num + 1))
                        tasks_created += 1

        if tasks_created > 0:
            db.commit()
            return f"Delegated {tasks_created} task(s) to {worker_names}"

    except Exception as e:
        log.warning("Delegation failed: %s", e)

    return ""


def _execute_agent_task(agent: dict, task: dict, context_memories: list = None) -> dict:
    """Execute a task using the LLM router with agent context.

    Builds a prompt from: company mission + agent role + task details + memory context.
    Routes to the appropriate model based on agent's task_type.
    Returns dict with: success, output, summary, quality, cost_cents.
    """
    # Build system prompt with agent personality
    system = f"""You are {agent['name']}, {agent['title'] or agent['role']} at {agent['company_name']}.

Company mission: {agent['company_mission'] or 'Not specified'}

Your capabilities: {agent.get('capabilities', 'General purpose')}

{agent.get('instructions', '')}

You are executing a task during a heartbeat. Be concise and focused.
Complete the task fully. Report what you did."""

    # Build user prompt with task + context
    prompt_parts = [f"## Task #{task['issue_number']}: {task['title']}"]
    if task.get("description"):
        prompt_parts.append(f"\n{task['description']}")

    if context_memories:
        prompt_parts.append("\n## Relevant Context from Memory")
        for mem in context_memories[:5]:  # limit to 5 most relevant
            if isinstance(mem, dict):
                prompt_parts.append(f"- {mem.get('name', '')}: {mem.get('content', '')[:200]}")

    prompt_parts.append("\n## Instructions\nComplete this task. Be specific about what you produced. Output the actual deliverable, not just a description of it.")

    prompt = "\n".join(prompt_parts)

    # Route to LLM
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent / "backend"))
        from llm_router import complete

        # Map agent task_type to LLM category
        category = agent.get("task_type", "judgment")
        if category == "complex":
            category = "complex"
        elif category == "simple":
            category = "simple"
        else:
            category = "judgment"  # default for agents

        result = complete(
            prompt=prompt,
            category=category,
            system=system,
            max_tokens=1024,
            workflow_id=f"heartbeat:{agent['name']}",
        )

        output = result.get("content", "")
        model = result.get("model", "unknown")
        cost = result.get("cost_usd", 0)

        # Basic quality assessment
        quality = 0.5
        if len(output) > 100:
            quality = 0.7
        if len(output) > 500:
            quality = 0.8
        if any(word in output.lower() for word in ["here", "created", "wrote", "completed", "produced"]):
            quality += 0.1
        quality = min(1.0, quality)

        return {
            "success": True,
            "output": output,
            "summary": output[:200].replace("\n", " "),
            "quality": quality,
            "cost_cents": int(cost * 100),
            "model": model,
        }

    except Exception as e:
        log.error("LLM execution failed for %s: %s", agent["name"], e)
        return {
            "success": False,
            "error": str(e),
            "output": "",
            "summary": f"LLM error: {str(e)[:100]}",
            "quality": 0.0,
            "cost_cents": 0,
        }


def check_due_heartbeats() -> list:
    """Find agents whose heartbeat is due and run them."""
    db = _get_db()

    # Find agents where last_heartbeat + interval < now
    agents = db.execute("""
        SELECT a.*, c.name as company_name, c.mission as company_mission
        FROM company_agents a
        JOIN companies c ON a.company_id = c.id
        WHERE a.status IN ('idle', 'active')
        AND c.status = 'active'
        AND (
            a.last_heartbeat_at IS NULL
            OR datetime(a.last_heartbeat_at, '+' || a.heartbeat_interval_seconds || ' seconds') <= datetime('now')
        )
    """).fetchall()

    db.close()

    results = []
    for agent in agents:
        log.info("Heartbeat due: %s (%s) in %s",
                agent["name"], agent["role"], agent["company_name"])
        result = run_heartbeat(agent["id"])
        results.append(result)

    if not results:
        log.debug("No heartbeats due")

    return results


def run_heartbeat(agent_id: str) -> dict:
    """Run a single agent's heartbeat through the harness."""
    db = _get_db()
    agent = db.execute(
        "SELECT a.*, c.name as company_name, c.mission as company_mission "
        "FROM company_agents a JOIN companies c ON a.company_id = c.id "
        "WHERE a.id = ?",
        (agent_id,)
    ).fetchone()

    if not agent:
        db.close()
        return {"error": f"Agent {agent_id} not found"}

    # Convert Row to dict so it works in nested functions
    agent = dict(agent)
    run_id = secrets.token_urlsafe(8)
    company_id = agent["company_id"]

    # Create heartbeat run record
    db.execute("""
        INSERT INTO company_heartbeat_runs
        (id, company_id, agent_id, status, trigger_source, started_at)
        VALUES (?, ?, ?, 'running', 'timer', datetime('now'))
    """, (run_id, company_id, agent_id))

    # Update agent status
    db.execute("UPDATE company_agents SET status='running' WHERE id=?", (agent_id,))
    db.commit()

    # Build the heartbeat task
    def _heartbeat_work():
        """The actual work an agent does during a heartbeat."""
        work_db = _get_db()
        summary_parts = []

        # Step 1: Check memory for context
        try:
            from aibrain_db import search_memories
            context = search_memories(f"company {agent['company_name']} recent decisions")
            if context:
                summary_parts.append(f"Loaded {len(context)} relevant memories")
        except Exception:
            pass

        # QA Lead special behavior: review tasks in 'in_review' status
        if agent.get("title") and "quality" in agent.get("title", "").lower():
            review_tasks = work_db.execute("""
                SELECT i.*, a.name as worker_name FROM company_issues i
                LEFT JOIN company_agents a ON i.assignee_agent_id = a.id
                WHERE i.company_id=? AND i.status='in_review'
                ORDER BY i.created_at
            """, (company_id,)).fetchall()

            if review_tasks:
                for rt in review_tasks[:3]:  # review up to 3 per heartbeat
                    rt = dict(rt)
                    q = rt.get("quality_score", 0)
                    if q >= 0.8:
                        work_db.execute("UPDATE company_issues SET status='done', updated_at=datetime('now') WHERE id=?", (rt["id"],))
                        summary_parts.append(f"QA approved #{rt['issue_number']} (q={q:.1f})")
                    elif q >= 0.5:
                        # Send back to worker for improvement
                        work_db.execute("UPDATE company_issues SET status='todo', updated_at=datetime('now') WHERE id=?", (rt["id"],))
                        summary_parts.append(f"QA sent back #{rt['issue_number']} for rework (q={q:.1f})")
                    else:
                        # Escalate to CEO
                        from aibrain.core.companies import request_approval
                        request_approval(company_id, "quality_escalation", agent["id"],
                                        {"task_id": rt["id"], "title": rt["title"], "quality": q,
                                         "worker": rt.get("worker_name", "?")})
                        summary_parts.append(f"QA escalated #{rt['issue_number']} to CEO (q={q:.1f})")
                work_db.commit()

        # Step 2: Check inbox — pending tasks assigned to this agent
        # Also pick up in_progress tasks that might have been interrupted
        tasks = work_db.execute("""
            SELECT * FROM company_issues
            WHERE company_id=? AND assignee_agent_id=? AND status IN ('backlog', 'todo', 'in_progress')
            ORDER BY
                CASE status WHEN 'in_progress' THEN 0 WHEN 'todo' THEN 1 ELSE 2 END,
                CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
                created_at
        """, (company_id, agent_id)).fetchall()

        # Step 3: Claim highest priority task
        if tasks:
            task = dict(tasks[0])
            work_db.execute("""
                UPDATE company_issues
                SET status='in_progress', started_at=datetime('now'), updated_at=datetime('now')
                WHERE id=? AND status IN ('backlog', 'todo')
            """, (task["id"],))
            work_db.commit()
            summary_parts.append(f"Claimed task #{task['issue_number']}: {task['title']}")

            # Step 4: Execute task via LLM router
            ctx_mems = context if 'context' in dir() and context else []
            task_output = _execute_agent_task(agent, task, context_memories=ctx_mems)

            if task_output.get("success"):
                summary_parts.append(f"Completed: {task_output.get('summary', 'done')[:100]}")

                # Step 5: Store learnings to brain memory
                try:
                    from aibrain_db import store_memory
                    store_memory(
                        name=f"Task #{task['issue_number']} completed by {agent['name']}",
                        mem_type="completion",
                        content=f"Agent {agent['name']} ({agent['role']}) completed: {task['title']}\n\nOutput: {task_output.get('output', '')[:500]}",
                        importance=0.6,
                        tags=f"company,{agent['company_name']},{agent['name']}"
                    )
                except Exception as e:
                    log.debug("Failed to store learning: %s", e)

                # Route based on quality: high → done, medium → QA review, low → escalate
                quality = task_output.get("quality", 0.5)
                if quality >= 0.8:
                    new_status = "done"  # auto-approved by harness
                    summary_parts.append("(auto-approved, q >= 0.8)")
                else:
                    new_status = "in_review"  # QA Lead reviews on next heartbeat
                    summary_parts.append(f"(sent to QA review, q={quality:.1f})")

                work_db.execute("""
                    UPDATE company_issues
                    SET status=?, completed_at=datetime('now'), updated_at=datetime('now'),
                        quality_score=?, cost_cents=?
                    WHERE id=?
                """, (new_status, quality, task_output.get("cost_cents", 0), task["id"]))
                work_db.commit()
            else:
                summary_parts.append(f"Task failed: {task_output.get('error', 'unknown')[:100]}")
                work_db.execute("""
                    UPDATE company_issues
                    SET status='blocked', updated_at=datetime('now')
                    WHERE id=?
                """, (task["id"],))
                work_db.commit()
        else:
            # Step 8: CEO/Manager delegation — if no personal tasks, delegate to workers
            if agent["role"] in ("ceo", "manager"):
                delegation_result = _try_delegation(agent, company_id, work_db)
                if delegation_result:
                    summary_parts.append(delegation_result)
                else:
                    summary_parts.append("No pending tasks — idle heartbeat")
            else:
                summary_parts.append("No pending tasks — idle heartbeat")

        # Step 6: Check pending approvals
        approvals = work_db.execute("""
            SELECT COUNT(*) FROM company_approvals
            WHERE company_id=? AND status='pending'
        """, (company_id,)).fetchone()[0]

        if approvals > 0:
            summary_parts.append(f"{approvals} pending approval(s)")

        work_db.close()
        return {"summary": ". ".join(summary_parts), "tasks_found": len(tasks)}

    # Run through harness
    config = HarnessConfig(
        task_type=agent["task_type"] or "judgment",
        authority=agent["authority"] or "standard",
        max_cost_cents=100,
        timeout_seconds=300,
        quality_threshold=0.3,
        actor=f"agent:{agent['name']}",
        tags=["heartbeat", agent["name"], agent["company_name"]],
    )

    result = execute(
        task=f"heartbeat.{agent['name']}",
        action=_heartbeat_work,
        config=config,
    )

    # Update heartbeat run record
    status = "succeeded" if result.success else "failed"
    summary = ""
    if result.output and isinstance(result.output, dict):
        summary = result.output.get("summary", "")

    db = _get_db()
    db.execute("""
        UPDATE company_heartbeat_runs
        SET status=?, finished_at=datetime('now'), duration_ms=?,
            quality_score=?, cost_cents=?, model_used=?, error=?, summary=?
        WHERE id=?
    """, (status, result.duration_ms, result.quality, result.cost_cents,
          result.model_used, result.error, summary, run_id))

    # Update agent status and last heartbeat time
    db.execute("""
        UPDATE company_agents
        SET status='idle', last_heartbeat_at=datetime('now')
        WHERE id=?
    """, (agent_id,))

    db.commit()
    db.close()

    log.info("Heartbeat %s for %s: %s (q=%.2f, %dms)",
            status, agent["name"], summary[:100], result.quality, result.duration_ms)

    return {
        "run_id": run_id,
        "agent": agent["name"],
        "status": status,
        "summary": summary,
        "quality": result.quality,
        "duration_ms": result.duration_ms,
    }


if __name__ == "__main__":
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Agent heartbeat scheduler")
    parser.add_argument("--check", action="store_true", help="Check and run all due heartbeats")
    parser.add_argument("--agent", help="Run heartbeat for specific agent ID")
    parser.add_argument("--list", action="store_true", help="List agents and heartbeat status")

    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if args.check:
        results = check_due_heartbeats()
        for r in results:
            print(f"  {r['agent']}: {r['status']} — {r['summary'][:80]}")
        if not results:
            print("No heartbeats due.")

    elif args.agent:
        result = run_heartbeat(args.agent)
        print(f"  {result['agent']}: {result['status']}")
        print(f"  Summary: {result['summary']}")
        print(f"  Quality: {result['quality']:.2f} | Duration: {result['duration_ms']}ms")

    elif args.list:
        db = _get_db()
        agents = db.execute("""
            SELECT a.name, a.role, a.status, a.heartbeat_interval_seconds,
                   a.last_heartbeat_at, c.name as company
            FROM company_agents a
            JOIN companies c ON a.company_id = c.id
            WHERE a.status != 'terminated'
            ORDER BY c.name, a.role
        """).fetchall()
        db.close()

        print(f"\n{'Company':<20} {'Agent':<20} {'Role':<10} {'Status':<8} {'Interval':>10} {'Last Beat'}")
        print("-" * 85)
        for a in agents:
            interval = f"{a['heartbeat_interval_seconds']//3600}h"
            last = a["last_heartbeat_at"] or "never"
            print(f"{a['company']:<20} {a['name']:<20} {a['role']:<10} {a['status']:<8} {interval:>10} {last}")
    else:
        parser.print_help()
