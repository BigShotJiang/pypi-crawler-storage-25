"""
hooks.py — Tool and LLM call interceptors for AIBrain.

Register callables that run before/after tool calls and LLM calls.
Hooks can filter by tool name or agent role and can block execution
or modify results.

Usage:
    from aibrain.core.hooks import before_tool_call, after_tool_call

    @before_tool_call(tools=["web_search"])
    def log_search(tool_name, args, agent):
        print(f"Searching: {args}")

    @after_tool_call(tools=["web_search"])
    def cache_result(tool_name, result, agent):
        cache[tool_name] = result
        return result  # returning a value replaces the result

    @before_tool_call()
    def block_dangerous(tool_name, args, agent):
        if "rm -rf" in str(args):
            return False  # blocks execution

    @before_llm_call(agents=["Researcher"])
    def inject_context(prompt, agent):
        return prompt + "\\n\\nAlways cite sources."

    @after_llm_call()
    def sanitize(response, agent):
        return response.replace("CONFIDENTIAL", "[REDACTED]")
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional

log = logging.getLogger("aibrain.hooks")

# ---------------------------------------------------------------------------
# Hook registry
# ---------------------------------------------------------------------------

_hooks: dict[str, list[dict]] = {
    "before_tool": [],
    "after_tool": [],
    "before_llm": [],
    "after_llm": [],
}


def clear_hooks() -> None:
    """Remove all registered hooks. Mainly for testing."""
    for key in _hooks:
        _hooks[key].clear()


def get_hooks(hook_type: str) -> list[dict]:
    """Return registered hooks for a given type."""
    return list(_hooks.get(hook_type, []))


# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------

def before_tool_call(
    tools: Optional[list[str]] = None,
    agents: Optional[list[str]] = None,
) -> Callable:
    """Decorator. Runs before a tool is called.

    The decorated function receives (tool_name: str, args: dict, agent: Any).
    Returning False explicitly blocks execution.
    Returning a dict replaces the args passed to the tool.
    """
    def decorator(fn: Callable) -> Callable:
        _hooks["before_tool"].append({
            "fn": fn,
            "tools": tools,
            "agents": agents,
        })
        return fn
    return decorator


def after_tool_call(
    tools: Optional[list[str]] = None,
    agents: Optional[list[str]] = None,
) -> Callable:
    """Decorator. Runs after a tool call completes.

    The decorated function receives (tool_name: str, result: Any, agent: Any).
    Returning a non-None value replaces the result.
    """
    def decorator(fn: Callable) -> Callable:
        _hooks["after_tool"].append({
            "fn": fn,
            "tools": tools,
            "agents": agents,
        })
        return fn
    return decorator


def before_llm_call(
    agents: Optional[list[str]] = None,
) -> Callable:
    """Decorator. Runs before an LLM call.

    The decorated function receives (prompt: str, agent: Any).
    Returning a string replaces the prompt.
    """
    def decorator(fn: Callable) -> Callable:
        _hooks["before_llm"].append({
            "fn": fn,
            "agents": agents,
        })
        return fn
    return decorator


def after_llm_call(
    agents: Optional[list[str]] = None,
) -> Callable:
    """Decorator. Runs after an LLM call completes.

    The decorated function receives (response: str, agent: Any).
    Returning a string replaces the response.
    """
    def decorator(fn: Callable) -> Callable:
        _hooks["after_llm"].append({
            "fn": fn,
            "agents": agents,
        })
        return fn
    return decorator


# ---------------------------------------------------------------------------
# Execution helpers — called from agents.py
# ---------------------------------------------------------------------------

def _matches_filter(
    hook: dict,
    tool_name: Optional[str] = None,
    agent_role: Optional[str] = None,
) -> bool:
    """Check if a hook matches the current tool/agent filters."""
    # Tool filter
    if hook.get("tools") and tool_name:
        if tool_name not in hook["tools"]:
            return False
    elif hook.get("tools") and not tool_name:
        return False

    # Agent filter
    if hook.get("agents") and agent_role:
        if agent_role not in hook["agents"]:
            return False
    elif hook.get("agents") and not agent_role:
        return False

    return True


def run_before_tool(tool_name: str, args: dict, agent: Any = None) -> tuple[bool, dict]:
    """Run all matching before_tool hooks.

    Returns:
        (allow, args) — allow is False if any hook blocked execution,
        args may be modified by hooks.
    """
    agent_role = _get_agent_role(agent)
    current_args = dict(args) if args else {}

    for hook in _hooks["before_tool"]:
        if not _matches_filter(hook, tool_name=tool_name, agent_role=agent_role):
            continue
        try:
            result = hook["fn"](tool_name, current_args, agent)
            if result is False:
                log.info("Hook %s blocked tool %s", hook["fn"].__name__, tool_name)
                return False, current_args
            if isinstance(result, dict):
                current_args = result
        except Exception as e:
            log.warning("before_tool hook %s raised: %s", hook["fn"].__name__, e)

    return True, current_args


def run_after_tool(tool_name: str, result: Any, agent: Any = None) -> Any:
    """Run all matching after_tool hooks. Returns (possibly modified) result."""
    agent_role = _get_agent_role(agent)
    current_result = result

    for hook in _hooks["after_tool"]:
        if not _matches_filter(hook, tool_name=tool_name, agent_role=agent_role):
            continue
        try:
            hook_result = hook["fn"](tool_name, current_result, agent)
            if hook_result is not None:
                current_result = hook_result
        except Exception as e:
            log.warning("after_tool hook %s raised: %s", hook["fn"].__name__, e)

    return current_result


def run_before_llm(prompt: str, agent: Any = None) -> str:
    """Run all matching before_llm hooks. Returns (possibly modified) prompt."""
    agent_role = _get_agent_role(agent)
    current_prompt = prompt

    for hook in _hooks["before_llm"]:
        if not _matches_filter(hook, agent_role=agent_role):
            continue
        try:
            hook_result = hook["fn"](current_prompt, agent)
            if isinstance(hook_result, str):
                current_prompt = hook_result
        except Exception as e:
            log.warning("before_llm hook %s raised: %s", hook["fn"].__name__, e)

    return current_prompt


def run_after_llm(response: str, agent: Any = None) -> str:
    """Run all matching after_llm hooks. Returns (possibly modified) response."""
    agent_role = _get_agent_role(agent)
    current_response = response

    for hook in _hooks["after_llm"]:
        if not _matches_filter(hook, agent_role=agent_role):
            continue
        try:
            hook_result = hook["fn"](current_response, agent)
            if isinstance(hook_result, str):
                current_response = hook_result
        except Exception as e:
            log.warning("after_llm hook %s raised: %s", hook["fn"].__name__, e)

    return current_response


def _get_agent_role(agent: Any) -> Optional[str]:
    """Extract agent role string from an agent object."""
    if agent is None:
        return None
    if isinstance(agent, str):
        return agent
    return getattr(agent, "role", None)
