"""
archive.py — Smart archive system for AIBrain.

Never delete, always archive. Tracks access to archived items and resets
the 30-day countdown when something gets used — preventing accidental
deletion of things you still need.

Like the Windows Recycle Bin but smarter:
- Tracks WHAT got accessed from archive
- Resets timer on access
- Notifies user when archived items are referenced
- Auto-purges after 30 days untouched

Usage:
    from aibrain.core.archive import archive_item, restore_item, purge_expired

    archive_item("/path/to/file.py", reason="Replaced by new version")
    restore_item("file.py")
    purge_expired()  # removes items untouched for 30 days
"""

import json
import logging
import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.archive")

ARCHIVE_DIR = Path.home() / ".aibrain" / "archive"
DEFAULT_HOLD_DAYS = 30


def _get_db():
    """Get database connection."""
    root = Path(os.environ.get("AIBRAIN_ROOT", Path.home() / "aibrain"))
    db_path = root / "aibrain.db"
    if not db_path.exists():
        db_path = Path("aibrain.db")
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")

    # Create archive tracking table
    db.execute("""
        CREATE TABLE IF NOT EXISTS archive_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_path TEXT NOT NULL,
            archive_path TEXT NOT NULL,
            reason TEXT,
            archived_by TEXT DEFAULT 'system',
            archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            access_count INTEGER DEFAULT 0,
            last_accessed_at TIMESTAMP,
            last_access_reason TEXT,
            status TEXT DEFAULT 'archived' CHECK(status IN ('archived','restored','purged')),
            notified INTEGER DEFAULT 0
        )
    """)
    db.execute("CREATE INDEX IF NOT EXISTS idx_archive_status ON archive_items(status)")
    db.commit()
    return db


def archive_item(
    path: str,
    reason: str = "",
    archived_by: str = "system",
    hold_days: int = DEFAULT_HOLD_DAYS,
    force_delete: bool = False,
) -> dict:
    """
    Archive a file or directory instead of deleting it.

    Returns dict with archive info. If force_delete=True, deletes immediately
    (but still logs it in the archive table for audit trail).
    """
    source = Path(path)
    if not source.exists():
        return {"error": f"Path not found: {path}"}

    if force_delete:
        # User overrode archive — delete but log it
        if source.is_dir():
            shutil.rmtree(str(source))
        else:
            source.unlink()

        db = _get_db()
        db.execute("""
            INSERT INTO archive_items (original_path, archive_path, reason, archived_by, status)
            VALUES (?, 'FORCE_DELETED', ?, ?, 'purged')
        """, (str(source), f"Force deleted: {reason}", archived_by))
        db.commit()
        db.close()

        log.warning("Force deleted (no archive): %s — %s", path, reason)
        return {"status": "force_deleted", "path": str(source)}

    # Create archive directory with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_subdir = ARCHIVE_DIR / timestamp
    archive_subdir.mkdir(parents=True, exist_ok=True)

    # Move to archive
    dest = archive_subdir / source.name
    if source.is_dir():
        shutil.copytree(str(source), str(dest))
        shutil.rmtree(str(source))
    else:
        shutil.copy2(str(source), str(dest))
        source.unlink()

    # Calculate expiry
    from datetime import timedelta
    expires_at = datetime.now() + timedelta(days=hold_days)

    # Record in database
    db = _get_db()
    db.execute("""
        INSERT INTO archive_items
        (original_path, archive_path, reason, archived_by, expires_at)
        VALUES (?, ?, ?, ?, ?)
    """, (str(source), str(dest), reason, archived_by, expires_at.isoformat()))
    db.commit()
    db.close()

    log.info("Archived: %s → %s (expires %s)", path, dest, expires_at.strftime("%Y-%m-%d"))
    return {
        "status": "archived",
        "original": str(source),
        "archive": str(dest),
        "expires": expires_at.isoformat(),
        "hold_days": hold_days,
    }


def record_access(original_path: str, access_reason: str = "referenced") -> Optional[dict]:
    """
    Record that an archived item was accessed/referenced.

    Resets the 30-day timer and notifies the user that they almost
    deleted something they still need.
    """
    db = _get_db()
    item = db.execute(
        "SELECT * FROM archive_items WHERE original_path=? AND status='archived'",
        (original_path,)
    ).fetchone()

    if not item:
        db.close()
        return None  # Not archived, nothing to track

    from datetime import timedelta
    new_expires = datetime.now() + timedelta(days=DEFAULT_HOLD_DAYS)

    db.execute("""
        UPDATE archive_items
        SET access_count = access_count + 1,
            last_accessed_at = datetime('now'),
            last_access_reason = ?,
            expires_at = ?,
            notified = 0
        WHERE id = ?
    """, (access_reason, new_expires.isoformat(), item["id"]))
    db.commit()

    result = {
        "warning": f"You almost deleted '{original_path}' — it was just accessed!",
        "access_count": item["access_count"] + 1,
        "timer_reset": True,
        "new_expires": new_expires.isoformat(),
    }

    log.warning("Archived item accessed! %s (count: %d) — timer reset to %s",
               original_path, result["access_count"], new_expires.strftime("%Y-%m-%d"))

    db.close()
    return result


def restore_item(original_path: str) -> dict:
    """Restore an archived item to its original location."""
    db = _get_db()
    item = db.execute(
        "SELECT * FROM archive_items WHERE original_path=? AND status='archived' ORDER BY archived_at DESC LIMIT 1",
        (original_path,)
    ).fetchone()

    if not item:
        db.close()
        return {"error": f"No archived item found for: {original_path}"}

    source = Path(item["archive_path"])
    dest = Path(item["original_path"])

    if not source.exists():
        db.close()
        return {"error": f"Archive file missing: {source}"}

    # Restore
    dest.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(str(source), str(dest))
        shutil.rmtree(str(source))
    else:
        shutil.copy2(str(source), str(dest))
        source.unlink()

    db.execute("UPDATE archive_items SET status='restored' WHERE id=?", (item["id"],))
    db.commit()
    db.close()

    log.info("Restored: %s → %s", source, dest)
    return {"status": "restored", "path": str(dest)}


def purge_expired() -> dict:
    """Remove archived items that have been untouched for 30+ days."""
    db = _get_db()
    expired = db.execute("""
        SELECT * FROM archive_items
        WHERE status='archived' AND expires_at < datetime('now')
    """).fetchall()

    purged = 0
    for item in expired:
        archive_path = Path(item["archive_path"])
        if archive_path.exists():
            if archive_path.is_dir():
                shutil.rmtree(str(archive_path))
            else:
                archive_path.unlink()
            purged += 1

        db.execute("UPDATE archive_items SET status='purged' WHERE id=?", (item["id"],))

    db.commit()
    db.close()

    if purged:
        log.info("Purged %d expired archive items", purged)

    return {"purged": purged, "total_expired": len(expired)}


def list_archived() -> list:
    """List all currently archived items."""
    db = _get_db()
    items = db.execute("""
        SELECT original_path, archive_path, reason, archived_at, expires_at,
               access_count, last_accessed_at, status
        FROM archive_items
        WHERE status='archived'
        ORDER BY archived_at DESC
    """).fetchall()
    db.close()
    return [dict(i) for i in items]
