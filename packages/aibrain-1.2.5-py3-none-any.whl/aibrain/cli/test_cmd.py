"""
aibrain test -n <iterations> — Automated quality evaluation.

Runs workflow(s) N times, scores each run via harness quality eval,
compares against baseline, and prints a summary table.
"""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional


def run_test(workflows: list[str] = None, iterations: int = 3,
             actor: str = "tester", save_baseline: bool = False):
    """Run automated quality evaluation on workflows.

    Args:
        workflows: List of workflow names to test. If None, tests all registered.
        iterations: Number of runs per workflow.
        actor: Who is running the test.
        save_baseline: If True, save results as new baseline.
    """
    try:
        from aibrain.core.workflow_runner import run_workflow, WORKFLOW_REGISTRY
    except ImportError:
        print("Error: workflow_runner not available", file=sys.stderr)
        return 1

    if not workflows:
        # Default to a few safe deterministic workflows
        workflows = [w for w, meta in WORKFLOW_REGISTRY.items()
                     if meta.get("task_type") == "deterministic"][:5]

    if not workflows:
        print("No workflows to test.")
        return 1

    print(f"\n  AIBrain Quality Test")
    print(f"  ────────────────────────")
    print(f"  Workflows: {len(workflows)}")
    print(f"  Iterations: {iterations}\n")

    # Load existing baseline
    baseline = _load_baseline()

    results_table = []

    for wf_name in workflows:
        scores = []
        durations = []
        successes = 0

        for i in range(iterations):
            result = run_workflow(wf_name, actor=actor)
            scores.append(result.quality)
            durations.append(result.duration_ms)
            if result.success:
                successes += 1

        avg_q = sum(scores) / len(scores) if scores else 0
        min_q = min(scores) if scores else 0
        max_q = max(scores) if scores else 0
        avg_dur = sum(durations) / len(durations) if durations else 0

        # Compare against baseline
        regression = ""
        if wf_name in baseline:
            bl_avg = baseline[wf_name].get("avg_quality", 0)
            diff = avg_q - bl_avg
            if diff < -0.1:
                regression = f"REGRESSION ({diff:+.2f})"
            elif diff > 0.1:
                regression = f"IMPROVED ({diff:+.2f})"
            else:
                regression = "stable"

        results_table.append({
            "workflow": wf_name,
            "runs": iterations,
            "success": successes,
            "avg_quality": avg_q,
            "min_quality": min_q,
            "max_quality": max_q,
            "avg_duration_ms": avg_dur,
            "regression": regression,
        })

    # Print summary table
    print(f"  {'Workflow':<30} {'Avg Q':>6} {'Min':>5} {'Max':>5} {'OK':>4} {'Dur':>8} {'Status'}")
    print(f"  {'─' * 30} {'─' * 6} {'─' * 5} {'─' * 5} {'─' * 4} {'─' * 8} {'─' * 15}")

    for r in results_table:
        wf = r["workflow"][:30]
        print(f"  {wf:<30} {r['avg_quality']:>5.2f} {r['min_quality']:>5.2f} "
              f"{r['max_quality']:>5.2f} {r['success']:>3}/{r['runs']} "
              f"{r['avg_duration_ms']:>7.0f}ms {r['regression']}")

    # Save baseline if requested
    if save_baseline:
        new_baseline = {}
        for r in results_table:
            new_baseline[r["workflow"]] = {
                "avg_quality": r["avg_quality"],
                "min_quality": r["min_quality"],
                "max_quality": r["max_quality"],
                "runs": r["runs"],
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            }
        _save_baseline(new_baseline)
        print(f"\n  Baseline saved ({len(new_baseline)} workflows)")

    print()
    return 0


def _baseline_path() -> Path:
    """Get the path to the baseline file."""
    root = os.environ.get("AIBRAIN_ROOT", str(Path.home() / "aibrain"))
    return Path(root) / ".test_baseline.json"


def _load_baseline() -> dict:
    """Load existing baseline from disk."""
    path = _baseline_path()
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_baseline(data: dict):
    """Save baseline to disk."""
    path = _baseline_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
