"""
aibrain.mcp — Universal MCP client for connecting to ANY MCP server.

Gives the brain hands: discover tools, call them, bridge them into AIBrain's
harness for audit/eval/routing.

Uses raw JSON-RPC 2.0 over stdio/HTTP/SSE — no external MCP SDK dependency.

Usage:
    from aibrain.mcp import MCPServerRegistry, MCPServerStdio, MCPServerHTTP

    registry = MCPServerRegistry()
    registry.register("github", MCPServerStdio(command="npx", args=["@github/mcp-server"]))
    tools = await registry.get_tools("github")
    result = await registry.call_tool("github", "search_repos", {"query": "aibrain"})
"""

from aibrain.mcp.config import (
    MCPServerStdio,
    MCPServerHTTP,
    MCPServerSSE,
    MCPServerConfig,
)
from aibrain.mcp.client import MCPClient
from aibrain.mcp.registry import MCPServerRegistry
from aibrain.mcp.tool_bridge import MCPTool

__all__ = [
    "MCPServerStdio",
    "MCPServerHTTP",
    "MCPServerSSE",
    "MCPServerConfig",
    "MCPClient",
    "MCPServerRegistry",
    "MCPTool",
]
