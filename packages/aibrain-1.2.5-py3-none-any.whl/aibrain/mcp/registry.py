"""
registry.py — Central MCP server registry.

Manages all MCP server connections, persists configuration to SQLite,
and provides a unified interface for tool discovery and execution.

Usage:
    registry = MCPServerRegistry()
    registry.register("github", MCPServerStdio(command="npx", args=["@github/mcp-server"]))
    tools = await registry.get_tools("github")
    result = await registry.call_tool("github", "search_repos", {"query": "aibrain"})
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from typing import Any, Optional

from aibrain.mcp.config import MCPServerConfig, MCPServerStdio, MCPServerHTTP, MCPServerSSE
from aibrain.mcp.client import MCPClient

log = logging.getLogger("aibrain.mcp.registry")


def _config_to_dict(config: MCPServerConfig) -> dict:
    """Serialize config to a JSON-safe dict."""
    return config.model_dump()


def _dict_to_config(data: dict) -> MCPServerConfig:
    """Deserialize config from dict."""
    transport = data.get("transport", "stdio")
    if transport == "stdio":
        return MCPServerStdio(**data)
    elif transport == "http":
        return MCPServerHTTP(**data)
    elif transport == "sse":
        return MCPServerSSE(**data)
    raise ValueError(f"Unknown transport: {transport}")


class MCPServerRegistry:
    """Manages all MCP server connections.

    Servers are registered by name. Configs persist in SQLite so they
    survive restarts. Clients are created lazily on first use.
    """

    def __init__(self, db_path: str = "aibrain.db"):
        self._servers: dict[str, MCPServerConfig] = {}
        self._clients: dict[str, MCPClient] = {}
        self._tool_cache_db: dict[str, tuple[float, list[dict]]] = {}
        self._db_path = db_path
        self._ensure_tables()
        self.load_from_db()

    # --- Schema ---

    def _ensure_tables(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS mcp_servers (
                    name TEXT PRIMARY KEY,
                    config_json TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS mcp_tool_cache (
                    server_name TEXT NOT NULL,
                    tool_name TEXT NOT NULL,
                    tool_schema TEXT NOT NULL,
                    cached_at REAL NOT NULL,
                    PRIMARY KEY (server_name, tool_name)
                )
            """)

    # --- Registration ---

    def register(self, name: str, config: MCPServerConfig) -> None:
        """Register an MCP server by name. Persists to DB."""
        self._servers[name] = config
        # Evict stale client if re-registering
        if name in self._clients:
            self._clients.pop(name)
        self._save_server(name, config)
        log.info("Registered MCP server: %s (%s)", name, config.__class__.__name__)

    def unregister(self, name: str) -> None:
        """Remove a server registration."""
        self._servers.pop(name, None)
        self._clients.pop(name, None)
        self._tool_cache_db.pop(name, None)
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("DELETE FROM mcp_servers WHERE name = ?", (name,))
            conn.execute("DELETE FROM mcp_tool_cache WHERE server_name = ?", (name,))
        log.info("Unregistered MCP server: %s", name)

    def list_servers(self) -> dict[str, MCPServerConfig]:
        """Return all registered servers."""
        return dict(self._servers)

    # --- Tool discovery ---

    async def get_tools(self, server_name: str) -> list[dict]:
        """Get tools from a server (connects lazily, uses cache)."""
        if server_name not in self._servers:
            raise KeyError(f"Unknown MCP server: {server_name}")

        client = await self._get_client(server_name)
        tools = await client.list_tools()
        self._cache_tools_to_db(server_name, tools)
        return tools

    async def get_all_tools(self) -> dict[str, list[dict]]:
        """Get tools from all registered servers."""
        result: dict[str, list[dict]] = {}
        for name in self._servers:
            try:
                result[name] = await self.get_tools(name)
            except Exception as exc:
                log.warning("Failed to get tools from %s: %s", name, exc)
                # Fall back to cached tools from DB
                cached = self._load_cached_tools(name)
                if cached:
                    result[name] = cached
        return result

    # --- Tool execution ---

    async def call_tool(self, server_name: str, tool_name: str, args: dict = None) -> Any:
        """Call a tool on a specific server."""
        if server_name not in self._servers:
            raise KeyError(f"Unknown MCP server: {server_name}")
        client = await self._get_client(server_name)
        return await client.call_tool(tool_name, args or {})

    # --- Client management ---

    async def _get_client(self, server_name: str) -> MCPClient:
        """Get or create a connected client for the server."""
        if server_name in self._clients:
            client = self._clients[server_name]
            if client.transport.connected:
                return client

        config = self._servers[server_name]
        client = MCPClient(config)
        await client.connect()
        self._clients[server_name] = client
        return client

    async def cleanup(self) -> None:
        """Disconnect all clients."""
        for name, client in list(self._clients.items()):
            try:
                await client.disconnect()
            except Exception as exc:
                log.warning("Error disconnecting %s: %s", name, exc)
        self._clients.clear()

    # --- Persistence ---

    def save_to_db(self) -> None:
        """Save all server configs to SQLite."""
        for name, config in self._servers.items():
            self._save_server(name, config)

    def _save_server(self, name: str, config: MCPServerConfig) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO mcp_servers (name, config_json, updated_at) "
                "VALUES (?, ?, datetime('now'))",
                (name, json.dumps(_config_to_dict(config))),
            )

    def load_from_db(self) -> None:
        """Load all server configs from SQLite."""
        try:
            with sqlite3.connect(self._db_path) as conn:
                rows = conn.execute("SELECT name, config_json FROM mcp_servers").fetchall()
            for name, config_json in rows:
                try:
                    data = json.loads(config_json)
                    self._servers[name] = _dict_to_config(data)
                except Exception as exc:
                    log.warning("Failed to load MCP server %s: %s", name, exc)
        except sqlite3.OperationalError:
            # Table might not exist yet on first run
            pass

    def _cache_tools_to_db(self, server_name: str, tools: list[dict]) -> None:
        """Cache tool schemas in SQLite for restart survival."""
        now = time.time()
        try:
            with sqlite3.connect(self._db_path) as conn:
                conn.execute("DELETE FROM mcp_tool_cache WHERE server_name = ?", (server_name,))
                for tool in tools:
                    conn.execute(
                        "INSERT INTO mcp_tool_cache (server_name, tool_name, tool_schema, cached_at) "
                        "VALUES (?, ?, ?, ?)",
                        (server_name, tool.get("name", ""), json.dumps(tool), now),
                    )
        except Exception as exc:
            log.warning("Failed to cache tools for %s: %s", server_name, exc)

    def _load_cached_tools(self, server_name: str) -> list[dict]:
        """Load cached tool schemas from SQLite."""
        try:
            with sqlite3.connect(self._db_path) as conn:
                rows = conn.execute(
                    "SELECT tool_schema FROM mcp_tool_cache WHERE server_name = ?",
                    (server_name,),
                ).fetchall()
            return [json.loads(row[0]) for row in rows]
        except Exception:
            return []
