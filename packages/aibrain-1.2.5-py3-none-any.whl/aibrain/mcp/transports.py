"""
transports.py — JSON-RPC 2.0 transport implementations for MCP.

Three transports, zero external dependencies:
  - StdioTransport: spawn subprocess, JSON-RPC over stdin/stdout
  - HTTPTransport: POST JSON-RPC to HTTP endpoint
  - SSETransport: SSE for streaming, POST for calls

Each transport implements connect/disconnect/send and handles the wire format.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import ssl
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from typing import Any, Optional

log = logging.getLogger("aibrain.mcp.transports")


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class MCPTransportError(Exception):
    """Base transport error."""


class MCPAuthError(MCPTransportError):
    """Authentication/authorization failure — do NOT retry."""


class MCPNetworkError(MCPTransportError):
    """Transient network error — safe to retry."""


class MCPProtocolError(MCPTransportError):
    """JSON-RPC protocol violation."""


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class BaseTransport(ABC):
    """Abstract transport for MCP JSON-RPC communication."""

    def __init__(self):
        self._msg_id = 0
        self._connected = False

    def _next_id(self) -> int:
        self._msg_id += 1
        return self._msg_id

    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def disconnect(self) -> None: ...

    @abstractmethod
    async def send(self, message: dict) -> dict: ...

    @property
    def connected(self) -> bool:
        return self._connected


# ---------------------------------------------------------------------------
# Stdio
# ---------------------------------------------------------------------------

class StdioTransport(BaseTransport):
    """Spawn a subprocess, communicate via stdin/stdout JSON-RPC."""

    def __init__(self, command: str, args: list[str] = None, env: dict[str, str] = None):
        super().__init__()
        self.command = command
        self.args = args or []
        self.env = env or {}
        self._process: Optional[asyncio.subprocess.Process] = None
        self._read_lock = asyncio.Lock()

    async def connect(self) -> None:
        if self._connected:
            return
        merged_env = {**os.environ, **self.env}
        try:
            self._process = await asyncio.create_subprocess_exec(
                self.command, *self.args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=merged_env,
            )
            self._connected = True
            log.info("Stdio transport connected: %s %s", self.command, " ".join(self.args))
        except FileNotFoundError as exc:
            raise MCPTransportError(f"Command not found: {self.command}") from exc
        except OSError as exc:
            raise MCPNetworkError(f"Failed to spawn process: {exc}") from exc

    async def disconnect(self) -> None:
        if self._process and self._process.returncode is None:
            self._process.stdin.close()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self._process.kill()
                await self._process.wait()
        self._connected = False
        self._process = None

    async def send(self, message: dict) -> dict:
        if not self._connected or not self._process:
            raise MCPTransportError("Not connected")

        payload = json.dumps(message) + "\n"
        async with self._read_lock:
            try:
                self._process.stdin.write(payload.encode("utf-8"))
                await self._process.stdin.drain()
            except (BrokenPipeError, ConnectionError) as exc:
                self._connected = False
                raise MCPNetworkError(f"Write failed: {exc}") from exc

            try:
                line = await asyncio.wait_for(
                    self._process.stdout.readline(), timeout=30.0
                )
            except asyncio.TimeoutError as exc:
                raise MCPNetworkError("Timeout waiting for response") from exc

            if not line:
                self._connected = False
                raise MCPNetworkError("Process closed stdout")

            try:
                return json.loads(line.decode("utf-8"))
            except json.JSONDecodeError as exc:
                raise MCPProtocolError(f"Invalid JSON response: {line!r}") from exc


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

class HTTPTransport(BaseTransport):
    """HTTP POST for JSON-RPC calls (Streamable-HTTP transport)."""

    def __init__(self, url: str, headers: dict[str, str] = None):
        super().__init__()
        self.url = url
        self.headers = headers or {}

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def send(self, message: dict) -> dict:
        if not self._connected:
            raise MCPTransportError("Not connected")

        payload = json.dumps(message).encode("utf-8")
        req_headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            **self.headers,
        }
        req = urllib.request.Request(
            self.url,
            data=payload,
            headers=req_headers,
            method="POST",
        )

        # Run blocking urllib in thread to stay async
        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(None, self._do_request, req)
            return response
        except MCPTransportError:
            raise
        except Exception as exc:
            raise MCPNetworkError(f"HTTP request failed: {exc}") from exc

    @staticmethod
    def _do_request(req: urllib.request.Request) -> dict:
        try:
            ctx = ssl.create_default_context()
            with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
                body = resp.read().decode("utf-8")
                try:
                    return json.loads(body)
                except json.JSONDecodeError as exc:
                    raise MCPProtocolError(f"Invalid JSON: {body[:200]}") from exc
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                raise MCPAuthError(f"Auth failed (HTTP {exc.code})") from exc
            raise MCPNetworkError(f"HTTP {exc.code}: {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise MCPNetworkError(f"URL error: {exc.reason}") from exc


# ---------------------------------------------------------------------------
# SSE
# ---------------------------------------------------------------------------

class SSETransport(BaseTransport):
    """SSE for streaming events, HTTP POST for JSON-RPC calls.

    The SSE stream is used for server-pushed notifications.
    Actual tool calls go through HTTP POST (same as HTTPTransport).
    """

    def __init__(self, url: str, headers: dict[str, str] = None):
        super().__init__()
        self.url = url
        self.headers = headers or {}
        # POST endpoint: same base URL but for RPC calls
        # SSE servers typically accept POST at the same or /message endpoint
        self._post_url = url.rstrip("/")
        if not self._post_url.endswith("/message"):
            self._post_url = self._post_url + "/message"
        self._http = HTTPTransport(self._post_url, headers)

    async def connect(self) -> None:
        await self._http.connect()
        self._connected = True

    async def disconnect(self) -> None:
        await self._http.disconnect()
        self._connected = False

    async def send(self, message: dict) -> dict:
        if not self._connected:
            raise MCPTransportError("Not connected")
        return await self._http.send(message)
