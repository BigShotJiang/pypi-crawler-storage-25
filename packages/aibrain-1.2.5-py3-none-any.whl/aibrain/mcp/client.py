"""
client.py — MCP Client: connect to any MCP server, discover tools, call them.

Handles:
  - Protocol initialization handshake
  - Tool discovery with caching
  - Tool execution with retry + exponential backoff
  - Error classification (auth vs network vs protocol)
  - Event emission via PatternBus
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, Optional

from aibrain.mcp.config import MCPServerConfig, MCPServerStdio, MCPServerHTTP, MCPServerSSE
from aibrain.mcp.transports import (
    BaseTransport,
    StdioTransport,
    HTTPTransport,
    SSETransport,
    MCPAuthError,
    MCPNetworkError,
    MCPProtocolError,
    MCPTransportError,
)

log = logging.getLogger("aibrain.mcp.client")

# Re-export errors for convenience
__all__ = [
    "MCPClient",
    "MCPAuthError",
    "MCPNetworkError",
    "MCPProtocolError",
    "MCPTransportError",
]

# ---------------------------------------------------------------------------
# Tool name sanitization
# ---------------------------------------------------------------------------

_SAFE_NAME_RE = re.compile(r"[^a-zA-Z0-9_]")
MAX_TOOL_NAME_LEN = 64


def sanitize_tool_name(server_name: str, tool_name: str) -> str:
    """Normalize tool name: alphanumeric + underscore, max 64 chars, prefixed."""
    clean_server = _SAFE_NAME_RE.sub("_", server_name).strip("_")
    clean_tool = _SAFE_NAME_RE.sub("_", tool_name).strip("_")
    combined = f"{clean_server}_{clean_tool}"
    # Collapse multiple underscores
    combined = re.sub(r"_+", "_", combined)
    return combined[:MAX_TOOL_NAME_LEN]


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class MCPClient:
    """Connect to any MCP server, discover tools, call them.

    Usage:
        client = MCPClient(config)
        await client.connect()
        tools = await client.list_tools()
        result = await client.call_tool("search", {"query": "test"})
        await client.disconnect()
    """

    CLIENT_INFO = {
        "name": "aibrain",
        "version": "1.0.0",
    }

    PROTOCOL_VERSION = "2024-11-05"

    def __init__(
        self,
        config: MCPServerConfig,
        cache_ttl: int = 300,
        max_retries: int = 3,
    ):
        self.config = config
        self.transport: BaseTransport = self._create_transport(config)
        self._tool_cache: list[dict] = []
        self._cache_time: float = 0
        self._cache_ttl = cache_ttl
        self._max_retries = max_retries
        self._initialized = False

    @staticmethod
    def _create_transport(config: MCPServerConfig) -> BaseTransport:
        if isinstance(config, MCPServerStdio):
            return StdioTransport(config.command, config.args, config.env)
        elif isinstance(config, MCPServerHTTP):
            return HTTPTransport(config.url, config.headers)
        elif isinstance(config, MCPServerSSE):
            return SSETransport(config.url, config.headers)
        else:
            raise ValueError(f"Unknown config type: {type(config)}")

    # --- Lifecycle ---

    async def connect(self) -> None:
        """Connect transport and perform MCP initialization handshake."""
        await self.transport.connect()
        await self._initialize()

    async def disconnect(self) -> None:
        """Gracefully disconnect from the server."""
        await self.transport.disconnect()
        self._initialized = False
        self._tool_cache = []
        self._cache_time = 0

    async def _initialize(self) -> None:
        """MCP initialize handshake."""
        resp = await self.transport.send({
            "jsonrpc": "2.0",
            "method": "initialize",
            "params": {
                "protocolVersion": self.PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": self.CLIENT_INFO,
            },
            "id": self.transport._next_id(),
        })
        if "error" in resp:
            raise MCPProtocolError(f"Initialize failed: {resp['error']}")
        self._initialized = True

        # Send initialized notification (no id = notification)
        await self.transport.send({
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {},
        })

    # --- Tool discovery ---

    async def list_tools(self, force_refresh: bool = False) -> list[dict]:
        """List available tools from the server, with caching."""
        now = time.time()
        if not force_refresh and self._tool_cache and (now - self._cache_time) < self._cache_ttl:
            return self._tool_cache

        resp = await self.transport.send({
            "jsonrpc": "2.0",
            "method": "tools/list",
            "params": {},
            "id": self.transport._next_id(),
        })

        if "error" in resp:
            raise MCPProtocolError(f"tools/list failed: {resp['error']}")

        tools = resp.get("result", {}).get("tools", [])

        # Apply tool filter if configured
        tool_filter = getattr(self.config, "tool_filter", None)
        if tool_filter is not None:
            tools = [t for t in tools if t.get("name") in tool_filter]

        self._tool_cache = tools
        self._cache_time = now
        return tools

    # --- Tool execution ---

    async def call_tool(self, name: str, arguments: dict = None) -> Any:
        """Call a tool with retry + exponential backoff.

        Auth errors are never retried. Network/transient errors retry up to
        max_retries times with exponential backoff (1s, 2s, 4s).
        """
        arguments = arguments or {}
        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries):
            try:
                return await self._call_tool_once(name, arguments)
            except MCPAuthError:
                # Auth errors: fail immediately, don't retry
                raise
            except MCPNetworkError as exc:
                last_error = exc
                if attempt < self._max_retries - 1:
                    delay = 2 ** attempt  # 1s, 2s, 4s
                    log.warning(
                        "MCP call %s failed (attempt %d/%d), retrying in %ds: %s",
                        name, attempt + 1, self._max_retries, delay, exc,
                    )
                    await asyncio.sleep(delay)
            except MCPProtocolError:
                # Protocol errors: don't retry — server is confused
                raise

        raise MCPNetworkError(
            f"Tool call '{name}' failed after {self._max_retries} attempts: {last_error}"
        )

    async def _call_tool_once(self, name: str, arguments: dict) -> Any:
        """Single tool call attempt."""
        resp = await self.transport.send({
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments},
            "id": self.transport._next_id(),
        })

        if "error" in resp:
            error = resp["error"]
            code = error.get("code", 0)
            msg = error.get("message", str(error))
            # JSON-RPC error codes: -32000 to -32099 are server errors
            if code in (-32001, -32002) or "auth" in msg.lower() or "unauthorized" in msg.lower():
                raise MCPAuthError(msg)
            raise MCPProtocolError(f"Tool call error: {msg}")

        result = resp.get("result", {})
        # MCP tool results have content array
        content = result.get("content", [])
        if len(content) == 1 and content[0].get("type") == "text":
            return content[0].get("text", "")
        return content if content else result
