"""
config.py — MCP server configuration models.

Three transport types supported:
  - Stdio: subprocess with JSON-RPC over stdin/stdout
  - HTTP: Streamable-HTTP POST for JSON-RPC
  - SSE: Server-Sent Events for streaming + HTTP POST for calls
"""

from __future__ import annotations

from typing import Optional, Union

from pydantic import BaseModel, Field


class MCPServerStdio(BaseModel):
    """MCP server via subprocess (stdio transport)."""
    transport: str = Field(default="stdio", frozen=True)
    command: str           # "python", "node", "npx", "uvx"
    args: list[str] = []
    env: dict[str, str] = {}
    tool_filter: Optional[list[str]] = None  # allowed tool names, None=all


class MCPServerHTTP(BaseModel):
    """MCP server via HTTP/Streamable-HTTP."""
    transport: str = Field(default="http", frozen=True)
    url: str
    headers: dict[str, str] = {}
    tool_filter: Optional[list[str]] = None


class MCPServerSSE(BaseModel):
    """MCP server via Server-Sent Events."""
    transport: str = Field(default="sse", frozen=True)
    url: str
    headers: dict[str, str] = {}
    tool_filter: Optional[list[str]] = None


MCPServerConfig = Union[MCPServerStdio, MCPServerHTTP, MCPServerSSE]
