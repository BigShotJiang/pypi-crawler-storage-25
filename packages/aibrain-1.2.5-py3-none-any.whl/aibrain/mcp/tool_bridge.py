"""
tool_bridge.py — Bridge MCP tools into AIBrain's execution ecosystem.

Wraps MCP tools as callables that:
  - Flow through the harness for audit/eval
  - Emit DomainEvents on discovery, call, and error
  - Convert to OpenAI/Anthropic function-calling format
"""

from __future__ import annotations

import logging
from typing import Any, TYPE_CHECKING

from aibrain.mcp.client import sanitize_tool_name

if TYPE_CHECKING:
    from aibrain.mcp.registry import MCPServerRegistry

log = logging.getLogger("aibrain.mcp.tool_bridge")


class MCPTool:
    """Wraps an MCP tool as a callable that flows through the harness.

    Usage:
        tool = MCPTool("github", "search_repos", schema, registry)
        result = await tool(query="aibrain")
        spec = tool.to_llm_tool_spec()  # for function-calling APIs
    """

    def __init__(
        self,
        server_name: str,
        tool_name: str,
        tool_schema: dict,
        registry: "MCPServerRegistry",
    ):
        self.server_name = server_name
        self.raw_name = tool_name
        self.name = sanitize_tool_name(server_name, tool_name)
        self.description = tool_schema.get("description", "")
        self.input_schema = tool_schema.get("inputSchema", {})
        self._registry = registry

    async def __call__(self, **kwargs: Any) -> Any:
        """Execute the tool via the registry, optionally through the harness."""
        try:
            result = await self._registry.call_tool(
                self.server_name, self.raw_name, kwargs
            )
            self._emit_event("tool_call", {
                "server": self.server_name,
                "tool": self.raw_name,
                "success": True,
            })
            return result
        except Exception as exc:
            self._emit_event("tool_error", {
                "server": self.server_name,
                "tool": self.raw_name,
                "error": str(exc),
            })
            raise

    async def call_harnessed(self, **kwargs: Any) -> Any:
        """Execute through AIBrain's harness for audit/eval/routing."""
        try:
            from aibrain.core.harness import execute, HarnessConfig

            result = execute(
                task=f"mcp_tool:{self.name}",
                action=lambda: _run_async(self(**kwargs)),
                config=HarnessConfig(
                    task_type="deterministic",
                    authority="standard",
                    actor="mcp_client",
                    tags=["mcp", self.server_name, self.raw_name],
                ),
            )
            return result
        except ImportError:
            log.warning("Harness not available, calling tool directly")
            return await self(**kwargs)

    def to_llm_tool_spec(self) -> dict:
        """Convert to OpenAI/Anthropic function-calling format.

        Returns a dict compatible with both:
          - OpenAI: {"type": "function", "function": {...}}
          - Anthropic: {"name": ..., "description": ..., "input_schema": ...}
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description or f"MCP tool: {self.server_name}/{self.raw_name}",
                "parameters": self.input_schema or {"type": "object", "properties": {}},
            },
        }

    def to_anthropic_spec(self) -> dict:
        """Convert to Anthropic-native tool spec."""
        return {
            "name": self.name,
            "description": self.description or f"MCP tool: {self.server_name}/{self.raw_name}",
            "input_schema": self.input_schema or {"type": "object", "properties": {}},
        }

    def _emit_event(self, event_type: str, metadata: dict) -> None:
        """Fire-and-forget event emission via centralized events.emit()."""
        try:
            from aibrain.core.events import emit
            emit(event_type, self.name, domain="mcp", source_agent="mcp_client", **metadata)
        except Exception:
            # Event emission is fire-and-forget
            pass

    def __repr__(self) -> str:
        return f"MCPTool({self.server_name}/{self.raw_name} -> {self.name})"


def _run_async(coro):
    """Run an async coroutine from sync context (for harness integration)."""
    import asyncio
    try:
        loop = asyncio.get_running_loop()
        # Already in async context — create a task
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, coro).result(timeout=30)
    except RuntimeError:
        return asyncio.run(coro)


async def bridge_all_tools(registry: "MCPServerRegistry") -> list[MCPTool]:
    """Discover all tools from all servers and return as MCPTool instances.

    Usage:
        tools = await bridge_all_tools(registry)
        specs = [t.to_llm_tool_spec() for t in tools]
    """
    all_tools: list[MCPTool] = []
    server_tools = await registry.get_all_tools()

    for server_name, tools in server_tools.items():
        for tool_schema in tools:
            tool_name = tool_schema.get("name", "unknown")
            mcp_tool = MCPTool(server_name, tool_name, tool_schema, registry)
            all_tools.append(mcp_tool)

    # Emit discovery event
    try:
        from aibrain.core.events import emit
        emit("tools_discovered", "bridge_all_tools", value=len(all_tools),
             domain="mcp", source_agent="mcp_client",
             servers=list(server_tools.keys()))
    except Exception:
        pass

    return all_tools
