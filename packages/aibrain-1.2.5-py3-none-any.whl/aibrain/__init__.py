"""
aibrain — AI agent brain with memory, teams, flows, ingestion, and MCP.

Your agent, but better every day.

Core modules:
    from aibrain import AIBrain, Brain, Agent, Task, Team
    from aibrain.core.flow import Flow, start, listen, router
    from aibrain.mcp import MCPServerRegistry, MCPServerStdio, MCPServerHTTP
"""

__version__ = "1.2.5"

import os
import sys
from pathlib import Path

# Fix Windows console encoding — prevents UnicodeEncodeError with non-ASCII memory content
if sys.platform == "win32" and not os.environ.get("PYTHONUTF8"):
    os.environ["PYTHONUTF8"] = "1"
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")

# Add project root to sys.path so flat-file imports work
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

# Re-export core classes from flat files
from aibrain_db import get_db, DB_PATH, AIBRAIN_ROOT  # noqa: E402, F401
from aibrain_sdk import AIBrain, AIBrainError  # noqa: E402, F401
from aibrain.core.memory_api import Brain  # noqa: E402, F401
from aibrain.core.agents import Agent, Task, Team, TeamOutput, TaskOutput  # noqa: E402, F401

__all__ = [
    "__version__",
    "AIBrain",
    "AIBrainError",
    "Brain",
    "Agent",
    "Task",
    "Team",
    "TeamOutput",
    "TaskOutput",
    "get_db",
    "DB_PATH",
    "AIBRAIN_ROOT",
]
