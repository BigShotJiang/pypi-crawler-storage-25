"""
CLI entry point for aibrain.

Global flags:
    --path <dir>              — override AIBRAIN_ROOT (brain data directory)

Usage:
    aibrain setup             — first-time setup wizard (--auto / --defaults for no prompts)
    aibrain init              — initialize database
    aibrain summary           — dashboard stats
    aibrain search "query"    — cross-table FTS search
    aibrain browse            — open memory browser in browser
    aibrain forget "topic"    — preview what would be deleted
    aibrain forget "topic" --confirm  — permanently delete
    aibrain skills            — show skill inventory
    aibrain workflows list    — list all workflows + status
    aibrain workflows enable <n>  — enable (+ auto-enable deps)
    aibrain workflows disable <n> — disable a workflow
    aibrain workflows enable --recommended — starter set
    aibrain workflows sync    — create OS scheduled tasks
    aibrain workflows sync --dry-run — preview changes
    aibrain workflows run <n> — run immediately
    aibrain workflows deps    — show dependency map
    aibrain audit [N]          — show last N execution audit entries (default 20)
    aibrain health             — brain health report (memories, quality, tier usage)
    aibrain license            — show license status + tier
    aibrain license activate <k> — activate license key
    aibrain license tiers     — show pricing tiers
    aibrain marketplace package --name "Brain" — package brain for sale
    aibrain marketplace validate <f> — validate .brain file
    aibrain marketplace publish <f>  — publish to marketplace
    aibrain marketplace search "q"   — search marketplace
    aibrain marketplace install <id> — install a brain
    aibrain marketplace revenue      — revenue dashboard
    aibrain mesh status       — show mesh agent status
    aibrain mesh register <n> <db> — register agent in mesh
    aibrain mesh merge        — merge all agents (consensus)
    aibrain mesh distribute   — push merged brain to all agents
    aibrain mesh swarm create <type> -n 100 — create training swarm
    aibrain mesh swarm harvest <type> — merge swarm back
    aibrain history snapshot "msg" — snapshot current brain state
    aibrain history list      — list all snapshots
    aibrain history rollback <id> — roll back to snapshot
    aibrain history branch <name> — branch brain for experiments
    aibrain history diff <a> [b]  — compare versions
    aibrain scale stats       — brain health report
    aibrain scale compact     — archive stale memories
    aibrain scale analyze     — shard recommendations
    aibrain brain export      — export brain to JSON
    aibrain brain import <f>  — import brain from JSON
    aibrain brain merge <src> — merge from git URL or path
    aibrain brain stats       — brain statistics
    aibrain config get <key>  — read config
    aibrain config set <k> <v> — write config
    aibrain attack build      — download ATT&CK STIX + build graph
    aibrain attack search "q" — search techniques, malware, tools
    aibrain attack technique T1566  — full technique info
    aibrain attack mitigations T1566 — mitigations for technique
    aibrain attack tactic initial-access — techniques by tactic
    aibrain attack chain T1566 T1059 — find paths between nodes
    aibrain attack stats      — graph statistics
    aibrain packs             — browse available brain packs (domain bundles)
    aibrain packs activate <n> — activate a pack (enables its workflows)
    aibrain packs active      — show currently active packs
    aibrain start             — restore stack + start services (like rebooting your OS)
    aibrain status            — show current stack (crons, hooks, services)
    aibrain stack save [name] — save named stack snapshot
    aibrain stack restore [n] — restore from last (or named) snapshot
    aibrain stack rollback    — roll back to previous snapshot (keeps last 3)
    aibrain stack rollback 2  — roll back 2 steps
    aibrain stack set-default — save current state as your default stack
    aibrain stack list        — list saved snapshots
    aibrain update            — safe self-update (backup, pull, validate, auto-config)
    aibrain create <name>     — scaffold a new AIBrain project
    aibrain chat              — interactive conversational mode with the brain
    aibrain train <wf> -n N   — training loop: run workflow N times with feedback
    aibrain test -n N [wfs..] — automated quality evaluation
    aibrain tools             — list available built-in tools
    aibrain serve             — start everything (API + dashboard + open browser)
    aibrain server            — start FastAPI server only
    aibrain mcp               — start MCP server (stdio)
    aibrain version           — print version
"""

import os
import sys
from pathlib import Path

# Ensure project root is importable
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))


_QUICK_START = """
Quick Start:
  pip install aibrain
  aibrain setup              # First-time setup (use --auto for no prompts)
  aibrain chat               # Interactive memory chat
  aibrain create myproject   # Scaffold a new project
  aibrain serve              # Launch dashboard (requires: pip install aibrain[api])
"""

_SUBCOMMAND_HELP = {
    "setup": "First-time setup wizard.\n\nUsage:\n  aibrain setup           Interactive wizard (11 steps)\n  aibrain setup --auto    Fully automatic, no prompts, discovers env vars\n  aibrain setup --defaults Same as --auto\n  aibrain setup --config path.json  Use a pre-filled config file",
    "chat": "Interactive conversational mode with the brain.\n\nUsage:\n  aibrain chat             Start chatting with your brain\n  aibrain chat --db path   Use a specific database\n\nCommands inside chat:\n  remember: <text>  Store a new memory\n  quit / exit       Leave chat",
    "create": "Scaffold a new AIBrain project.\n\nUsage:\n  aibrain create <name>    Create project directory with boilerplate",
    "serve": "Start API backend + dashboard UI.\n\nUsage:\n  aibrain serve\n\nRequires: pip install aibrain[api]\nDashboard docs: https://myaibrain.org/docs/dashboard",
    "server": "Start FastAPI server only (no dashboard).\n\nUsage:\n  aibrain server\n\nRequires: pip install aibrain[api]",
    "init": "Initialize the brain database.\n\nUsage:\n  aibrain init",
    "search": "Full-text search across all brain tables.\n\nUsage:\n  aibrain search \"query\"",
    "train": "Training loop: run workflow N times with feedback.\n\nUsage:\n  aibrain train <workflow> [-n iterations]",
    "test": "Automated quality evaluation.\n\nUsage:\n  aibrain test [-n iterations] [workflow_names...] [--save-baseline]",
    "workflows": "Manage workflows.\n\nUsage:\n  aibrain workflows list\n  aibrain workflows enable <n>\n  aibrain workflows disable <n>\n  aibrain workflows enable --recommended\n  aibrain workflows sync [--dry-run]\n  aibrain workflows run <n>\n  aibrain workflows deps",
    "brain": "Brain import/export/merge.\n\nUsage:\n  aibrain brain export\n  aibrain brain import <file>\n  aibrain brain merge <source>\n  aibrain brain stats",
    "version": "Print the installed aibrain version.",
    "mcp": "Start MCP server (stdio mode).\n\nRequires: pip install aibrain[mcp]",
    "packs": "Browse and activate brain packs (life-domain bundles).\n\nUsage:\n  aibrain packs              List available packs\n  aibrain packs activate <n> Activate a pack",
}


def _is_setup_complete():
    """Check if setup has been run (config.json or DB exists)."""
    import os as _os
    root = Path(_os.environ.get("AIBRAIN_ROOT", str(Path.home() / "aibrain")))
    return (root / "config.json").exists() or (root / "aibrain.db").exists()


def main():
    args = sys.argv[1:]

    # Issue #7: --path flag to override AIBRAIN_ROOT (avoids picking up dev DB)
    if "--path" in args:
        idx = args.index("--path")
        if idx + 1 < len(args):
            os.environ["AIBRAIN_ROOT"] = args[idx + 1]
            args = args[:idx] + args[idx + 2:]  # strip --path <val> from args
            sys.argv = [sys.argv[0]] + args

    if not args or args[0] in ("-h", "--help"):
        print(_QUICK_START.strip())
        print()
        print(__doc__.strip())
        return

    cmd = args[0]

    # --- Issue #8: aibrain help <command> ---
    if cmd == "help":
        if len(args) > 1:
            subcmd = args[1]
            if subcmd in _SUBCOMMAND_HELP:
                print(f"\n  aibrain {subcmd}")
                print(f"  {'─' * 40}")
                print(f"  {_SUBCOMMAND_HELP[subcmd]}")
                print()
            else:
                print(f"  No help available for '{subcmd}'. Run 'aibrain --help' for all commands.")
        else:
            print(_QUICK_START.strip())
            print()
            print(__doc__.strip())
        return

    if cmd == "version":
        from aibrain import __version__
        print(f"aibrain {__version__}")

    elif cmd == "create":
        from aibrain.cli.create import create_project
        name = args[1] if len(args) > 1 else ""
        if not name:
            print("Usage: aibrain create <project_name>")
            return
        sys.exit(create_project(name))

    elif cmd == "chat":
        # Issue #9: check setup before running interactive commands
        if not _is_setup_complete():
            print("Run 'aibrain setup' first to initialize your brain.")
            print("  Quick start: aibrain setup --auto")
            sys.exit(1)
        from aibrain.cli.chat import run_chat
        db = None
        if "--db" in args:
            idx = args.index("--db")
            db = args[idx + 1] if idx + 1 < len(args) else None
        sys.exit(run_chat(db_path=db))

    elif cmd == "train":
        from aibrain.cli.train import run_train
        if len(args) < 2:
            print("Usage: aibrain train <workflow> [-n iterations]")
            return
        workflow = args[1]
        n = 3
        if "-n" in args:
            idx = args.index("-n")
            try:
                n = int(args[idx + 1])
            except (IndexError, ValueError):
                pass
        sys.exit(run_train(workflow, iterations=n))

    elif cmd == "test":
        from aibrain.cli.test_cmd import run_test
        n = 3
        if "-n" in args:
            idx = args.index("-n")
            try:
                n = int(args[idx + 1])
            except (IndexError, ValueError):
                pass
        save_bl = "--save-baseline" in args
        # Remaining args that don't start with - are workflow names
        wfs = [a for a in args[1:] if not a.startswith("-") and a not in (str(n),)]
        # Remove the number that follows -n from workflows list
        if "-n" in args:
            idx = args.index("-n")
            if idx + 1 < len(args):
                try:
                    int(args[idx + 1])
                    nval = args[idx + 1]
                    wfs = [w for w in wfs if w != nval]
                except ValueError:
                    pass
        sys.exit(run_test(workflows=wfs or None, iterations=n, save_baseline=save_bl))

    elif cmd == "tools":
        from aibrain.tools import list_tools, BUILTIN_TOOLS
        print(f"\n  AIBrain Built-in Tools ({len(BUILTIN_TOOLS)})")
        print(f"  ────────────────────────")
        for name in list_tools():
            tool = BUILTIN_TOOLS[name]
            print(f"  {name:<20} {tool.description[:60]}")
        print()

    elif cmd == "browse":
        import os
        from memory_browser import browse
        db = args[1] if len(args) > 1 and not args[1].startswith("-") else None
        output = None
        if "--output" in args:
            idx = args.index("--output")
            output = args[idx + 1] if idx + 1 < len(args) else None
        browse(db, output)

    elif cmd == "forget":
        if len(args) < 2:
            print("Usage: aibrain forget <query> [--confirm]")
            return
        query = " ".join(a for a in args[1:] if a != "--confirm")
        confirm = "--confirm" in args
        import os
        from memory_lifecycle import MemoryLifecycle
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        ml = MemoryLifecycle(db_path)
        result = ml.forget(query, dry_run=not confirm)
        if not confirm:
            print(f"DRY RUN — would delete:")
            print(f"  Memories:     {result.get('memories', 0)}")
            print(f"  Passages:     {result.get('passages', 0)}")
            print(f"  Facts:        {result.get('facts', 0)}")
            print(f"  Entity links: {result.get('entity_links', 0)}")
            print(f"  Embeddings:   {result.get('embeddings', 0)}")
            if result.get('memory_names'):
                print(f"\n  Matching memories:")
                for name in result['memory_names'][:10]:
                    print(f"    - {name}")
            print(f"\nRun with --confirm to execute: aibrain forget \"{query}\" --confirm")
        else:
            print(f"DELETED:")
            for k, v in result.items():
                if k not in ('deleted', 'dry_run'):
                    print(f"  {k}: {v}")

    elif cmd == "mesh":
        import os
        from brain_mesh import cli_mesh
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        sys.exit(cli_mesh(args[1:], db_path))

    elif cmd == "history":
        import os
        from brain_versioning import cli_versioning
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        sys.exit(cli_versioning(args[1:], db_path))

    elif cmd == "scale":
        import os
        from brain_versioning import cli_scale
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        sys.exit(cli_scale(args[1:], db_path))

    elif cmd == "license":
        from aibrain_licensing import cli_license
        sys.exit(cli_license(args[1:]))

    elif cmd == "marketplace":
        import os
        from brain_marketplace import cli_marketplace
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        sys.exit(cli_marketplace(args[1:], db_path))

    elif cmd == "workflows":
        import os
        from workflow_scheduler import cli_workflows
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        cli_workflows(args[1:], db_path)

    elif cmd == "skills":
        import os
        from skill_memory import SkillMemory
        db_path = os.environ.get("AIBRAIN_DB", str(Path.home() / "aibrain" / "aibrain.db"))
        sm = SkillMemory(db_path)
        profiles = sm.get_all_profiles()
        stats = sm.stats()
        print(f"=== Skill Inventory ===")
        print(f"  Episodes: {stats['total_episodes']}")
        print(f"  Active principles: {stats['total_principles']}")
        print(f"  Task types: {stats['task_types']}")
        if profiles:
            print(f"\n  Skills:")
            for p in profiles:
                trend = p.get('trend', 'stable')
                print(f"    {p['task_type']}: {p['total_episodes']} episodes, "
                      f"{p['avg_outcome']:.0%} avg, {trend}")

    elif cmd == "setup":
        import os
        # Default AIBRAIN_ROOT to ~/aibrain if not set and running from site-packages
        if "AIBRAIN_ROOT" not in os.environ:
            if "site-packages" in str(_root):
                default_root = Path.home() / "aibrain"
                default_root.mkdir(parents=True, exist_ok=True)
                os.environ["AIBRAIN_ROOT"] = str(default_root)
                print(f"  Data directory: {default_root}")
        from setup_wizard import run_wizard
        run_wizard(args[1:])  # pass remaining args (--auto, --config, etc.)

    elif cmd == "brain":
        # Delegate brain subcommands to aibrain_db
        import aibrain_db
        sys.argv = ["aibrain_db"] + args
        aibrain_db.main() if hasattr(aibrain_db, "main") else _run_db_cli(args)

    elif cmd == "server":
        import os
        if "AIBRAIN_ROOT" not in os.environ and "site-packages" in str(_root):
            os.environ["AIBRAIN_ROOT"] = str(Path.home() / "aibrain")
        try:
            import uvicorn
        except ImportError:
            print("Error: FastAPI deps not installed. Run: pip install aibrain[api]", file=sys.stderr)
            sys.exit(1)
        uvicorn.run("backend.main:app", host="127.0.0.1", port=8001, reload=False)

    elif cmd == "serve":
        # Single command: starts API backend + dashboard UI
        import os
        import subprocess
        import threading
        import webbrowser
        import time

        if "AIBRAIN_ROOT" not in os.environ and "site-packages" in str(_root):
            os.environ["AIBRAIN_ROOT"] = str(Path.home() / "aibrain")

        # Issue #3: check for uvicorn BEFORE printing the banner
        try:
            import uvicorn  # noqa: F401
        except ImportError:
            print("Dashboard requires: pip install aibrain[api]")
            sys.exit(1)

        api_port = 8001
        dash_port = 3000
        dashboard_dir = _root / "dashboard"

        from aibrain import __version__
        print(f"\n  AIBrain v{__version__}")
        print(f"  ─────────────────────────")

        # Start API backend in background thread
        def run_api():
            import uvicorn as _uv
            _uv.run("backend.main:app", host="127.0.0.1", port=api_port, reload=False, log_level="warning")

        api_thread = threading.Thread(target=run_api, daemon=True)
        api_thread.start()
        print(f"  API server starting on http://localhost:{api_port}")

        # Start dashboard if it exists and has node_modules
        dash_process = None
        if dashboard_dir.exists() and (dashboard_dir / "node_modules").exists():
            dash_process = subprocess.Popen(
                ["npx", "next", "start", "-p", str(dash_port)],
                cwd=str(dashboard_dir),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            print(f"  Dashboard starting on http://localhost:{dash_port}")
        elif dashboard_dir.exists():
            print(f"  Dashboard found but node_modules missing — run: cd dashboard && npm install && npm run build")
        else:
            # Issue #6: helpful message instead of error-looking output
            print(f"  Dashboard available at: https://myaibrain.org/docs/dashboard")
            print(f"  Or run from source: see https://myaibrain.org/docs/dashboard for setup instructions")
            print(f"  Running in API-only mode.")

        print(f"  ─────────────────────────")
        print(f"  Press Ctrl+C to stop\n")

        # Open browser after short delay
        def open_browser():
            time.sleep(3)
            url = f"http://localhost:{dash_port}" if dash_process else f"http://localhost:{api_port}"
            webbrowser.open(url)

        threading.Thread(target=open_browser, daemon=True).start()

        try:
            api_thread.join()
        except KeyboardInterrupt:
            print("\n  Shutting down...")
            if dash_process:
                dash_process.terminate()
            print("  Done.")

    elif cmd == "attack":
        # ATT&CK knowledge graph — search techniques, mitigations, chains
        import attack_graph
        sys.argv = ["attack_graph"] + args[1:]
        attack_graph.main()

    elif cmd == "packs":
        _handle_packs(args[1:])

    elif cmd == "start":
        # Like rebooting your OS — restore stack, start services, ready to go
        print("AIBrain starting up...")
        import subprocess

        # Step 1: Restore stack (prompts if last != default)
        stack_script = _root / "stack_snapshot.py"
        if stack_script.exists():
            print("\n  Restoring stack...")
            subprocess.run(
                [sys.executable, str(stack_script), "startup"],
                cwd=str(_root), timeout=30,
            )
        else:
            print("  No stack_snapshot.py found, skipping restore")

        # Step 2: Auto-config free tier (ensures all free workflows enabled)
        print("\n  Configuring free-tier workflows...")
        try:
            from aibrain_update import auto_config_free_tier
            enabled, added = auto_config_free_tier()
            if enabled or added:
                print(f"  Configured: {enabled} enabled, {added} added")
            else:
                print("  All free-tier workflows already configured")
        except ImportError:
            pass

        # Step 3: Sync agent hooks
        print("\n  Syncing agent hooks...")
        try:
            from aibrain_update import sync_agent_hooks
            sync_agent_hooks()
        except ImportError:
            pass

        # Step 4: Start API server (background)
        print("\n  Starting API server on :8001...")
        try:
            import uvicorn  # noqa: F401
            subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "backend.main:app",
                 "--host", "127.0.0.1", "--port", "8001"],
                cwd=str(_root),
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            print("  API server started")
        except ImportError:
            print("  Skipped (install with: pip install aibrain[api])")

        # Step 5: Save fresh snapshot
        if stack_script.exists():
            subprocess.run(
                [sys.executable, str(stack_script), "auto"],
                cwd=str(_root), capture_output=True, timeout=15,
            )

        print("\n  AIBrain is ready.")

    elif cmd == "status":
        import subprocess
        stack_script = _root / "stack_snapshot.py"
        if stack_script.exists():
            r = subprocess.run(
                [sys.executable, str(stack_script), "current"],
                cwd=str(_root), timeout=15,
            )
        else:
            print("No stack_snapshot.py found")

    elif cmd == "stack":
        import subprocess
        stack_script = _root / "stack_snapshot.py"
        if not stack_script.exists():
            print("Error: stack_snapshot.py not found", file=sys.stderr)
            sys.exit(1)
        sub_args = args[1:] if len(args) > 1 else ["list"]
        subprocess.run(
            [sys.executable, str(stack_script)] + sub_args,
            cwd=str(_root),
        )

    elif cmd == "update":
        import subprocess
        update_script = _root / "aibrain_update.py"
        if update_script.exists():
            subprocess.run(
                [sys.executable, str(update_script)] + args[1:],
                cwd=str(_root),
            )
        else:
            print("Error: aibrain_update.py not found", file=sys.stderr)
            sys.exit(1)

    elif cmd == "encrypt":
        import subprocess
        encrypt_script = _root / "aibrain_encryption.py"
        if encrypt_script.exists():
            subprocess.run(
                [sys.executable, str(encrypt_script)] + args[1:],
                cwd=str(_root),
            )
        else:
            print("Error: aibrain_encryption.py not found", file=sys.stderr)
            sys.exit(1)

    elif cmd == "mcp":
        import asyncio
        try:
            from mcp_server import main as mcp_main
        except ImportError:
            print("Error: MCP deps not installed. Run: pip install aibrain[mcp]", file=sys.stderr)
            sys.exit(1)
        asyncio.run(mcp_main())

    elif cmd == "company":
        from aibrain.core.companies import cli_main as company_cli
        company_cli(args[1:])

    elif cmd == "agent":
        from aibrain.core.companies import hire_agent, list_agents, get_agent
        subcmd = args[1] if len(args) > 1 else ""
        if subcmd == "list":
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            if not company_id:
                print("Usage: aibrain agent list --company <id>")
            else:
                agents = list_agents(company_id)
                for a in agents:
                    print(f"  {a['role']:<10} {a['name']:<20} {a['status']:<8} model={a.get('model','auto')} id={a['id']}")
        elif subcmd == "hire":
            name = args[2] if len(args) > 2 else ""
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            role = args[args.index("--role") + 1] if "--role" in args else "general"
            if not name or not company_id:
                print("Usage: aibrain agent hire <name> --company <id> [--role ceo|manager|general]")
            else:
                result = hire_agent(company_id, name, role=role)
                if "error" in result:
                    print(f"Error: {result['error']}")
                else:
                    print(f"Hired: {result['name']} ({result['role']}) id={result['id']}")
        elif subcmd == "heartbeat":
            agent_id = args[2] if len(args) > 2 else ""
            if not agent_id:
                print("Usage: aibrain agent heartbeat <agent_id>")
            else:
                from aibrain.core.heartbeat import run_heartbeat
                result = run_heartbeat(agent_id)
                summary = result.get('summary', '').encode('ascii', 'replace').decode()
                print(f"  {result.get('agent','?')}: {result['status']} (q={result.get('quality',0):.2f})")
                print(f"  {summary[:200]}")
        else:
            print("Usage: aibrain agent [list|hire|heartbeat] ...")

    elif cmd == "task":
        from aibrain.core.companies import create_task, list_tasks
        subcmd = args[1] if len(args) > 1 else ""
        if subcmd == "create":
            title = args[2] if len(args) > 2 else ""
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            assign = args[args.index("--assign") + 1] if "--assign" in args else None
            if not title or not company_id:
                print("Usage: aibrain task create <title> --company <id> [--assign <agent_id>]")
            else:
                result = create_task(company_id, title, assignee_agent_id=assign)
                print(f"Task #{result['issue_number']}: {result['title']} [{result['status']}]")
        elif subcmd == "list":
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            if not company_id:
                print("Usage: aibrain task list --company <id>")
            else:
                tasks = list_tasks(company_id)
                for t in tasks:
                    print(f"  #{t['issue_number']} [{t['status']}] {t['title']}")
        else:
            print("Usage: aibrain task [create|list] ...")

    elif cmd == "inbox":
        from aibrain.core.companies import pending_approvals
        company_id = args[args.index("--company") + 1] if "--company" in args else (args[1] if len(args) > 1 else "")
        if not company_id:
            print("Usage: aibrain inbox --company <id>")
        else:
            approvals = pending_approvals(company_id)
            if not approvals:
                print("No pending approvals.")
            else:
                for a in approvals:
                    print(f"  [{a['type']}] {a.get('payload', '')[:60]} — {a['status']}")
                    print(f"    ID: {a['id']}  |  aibrain approve {a['id']}")

    elif cmd == "approve":
        approval_id = args[1] if len(args) > 1 else ""
        note = args[args.index("--note") + 1] if "--note" in args else ""
        if not approval_id:
            print("Usage: aibrain approve <approval_id> [--note <text>]")
        else:
            from aibrain.core.companies import approve
            result = approve(approval_id, note)
            print(f"Approved: {result['id']} — {result.get('decision_note', '')}")

    elif cmd == "reject":
        approval_id = args[1] if len(args) > 1 else ""
        note = args[args.index("--note") + 1] if "--note" in args else ""
        if not approval_id:
            print("Usage: aibrain reject <approval_id> [--note <text>]")
        else:
            from aibrain.core.companies import reject
            result = reject(approval_id, note)
            print(f"Rejected: {result['id']} — {result.get('decision_note', '')}")

    elif cmd == "audit":
        # Show recent execution audit trail
        try:
            import os as _os
            import sqlite3
            db_path = Path(_os.environ.get("AIBRAIN_ROOT", str(Path.home() / "aibrain"))) / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            limit = 20
            if args:
                try:
                    limit = int(args[0])
                except (ValueError, IndexError):
                    pass
            rows = db.execute(
                "SELECT action, success, quality_score, model_used, cost_cents, "
                "duration_ms, task_type, authority, retries, created_at "
                "FROM execution_log ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
            if not rows:
                print("No audit entries yet. Run workflows through the harness to generate data.")
                print("Example: python -m aibrain.core.workflow_runner heartbeat")
            else:
                print(f"\n{'Action':<35} {'Q':>4} {'OK':>3} {'Model':<12} {'Cost':>6} {'Time':>7} {'Type':<15}")
                print("-" * 90)
                for r in rows:
                    q = f"{r['quality_score']:.1f}" if r['quality_score'] is not None else "?"
                    ok = "Y" if r['success'] else "N"
                    cost = f"${r['cost_cents']/100:.2f}" if r['cost_cents'] else "$0"
                    ms = f"{r['duration_ms']}ms"
                    print(f"{r['action']:<35} {q:>4} {ok:>3} {r['model_used'] or '?':<12} {cost:>6} {ms:>7} {r['task_type'] or '?':<15}")
                print(f"\nTotal: {len(rows)} entries. Use `aibrain audit 50` for more.")
            db.close()
        except Exception as e:
            print(f"Audit error: {e}")

    elif cmd == "health":
        # Show brain health summary
        try:
            import os as _os
            import sqlite3
            db_path = Path(_os.environ.get("AIBRAIN_ROOT", str(Path.home() / "aibrain"))) / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row

            memories = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
            by_type = db.execute("SELECT type, COUNT(*) as cnt FROM memories WHERE active=1 GROUP BY type ORDER BY cnt DESC LIMIT 5").fetchall()

            # Audit stats
            try:
                total_execs = db.execute("SELECT COUNT(*) FROM execution_log").fetchone()[0]
                success_rate = db.execute("SELECT AVG(success) FROM execution_log").fetchone()[0] or 0
                avg_quality = db.execute("SELECT AVG(quality_score) FROM execution_log WHERE success=1").fetchone()[0] or 0
            except Exception:
                total_execs, success_rate, avg_quality = 0, 0, 0

            # License
            try:
                from aibrain_licensing import get_license, get_tier_status
                lic = get_license()
                tier = lic.tier
                tier_status = get_tier_status()
            except Exception:
                tier = "unknown"
                tier_status = {}

            print(f"\n  AIBrain Health Report")
            print(f"  {'='*40}")
            print(f"  Tier:           {tier}")
            print(f"  Memories:       {memories} active")
            print(f"  Top types:      {', '.join(f'{r[0]}({r[1]})' for r in by_type)}")
            print(f"  Executions:     {total_execs} total")
            print(f"  Success rate:   {success_rate*100:.0f}%")
            print(f"  Avg quality:    {avg_quality:.2f}")

            # Resource limits
            resources = tier_status.get("resources", {})
            if resources:
                print(f"\n  Resource Usage:")
                for res, info in resources.items():
                    current = info.get("current", 0)
                    limit = info.get("limit")
                    remaining = info.get("remaining")
                    if limit:
                        pct = (current / limit * 100) if limit else 0
                        bar = "#" * int(pct / 5) + "-" * (20 - int(pct / 5))
                        print(f"    {res:<20} [{bar}] {current}/{limit}")
                    else:
                        print(f"    {res:<20} {current} (unlimited)")

            print()
            db.close()
        except Exception as e:
            print(f"Health check error: {e}")

    else:
        # Delegate to aibrain_db.py CLI (init, summary, search, config, etc.)
        import aibrain_db
        # Re-inject the sub-args so aibrain_db sees them as sys.argv[1:]
        sys.argv = ["aibrain_db"] + args
        aibrain_db.main() if hasattr(aibrain_db, "main") else _run_db_cli(args)


def run_server():
    """Entry point for `aibrain-server` console script."""
    try:
        import uvicorn
    except ImportError:
        print("Error: FastAPI deps not installed. Run: pip install aibrain[api]", file=sys.stderr)
        sys.exit(1)
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8001, reload=False)


def _run_db_cli(args):
    """Fallback: call aibrain_db as a script if it has no main()."""
    import subprocess
    result = subprocess.run(
        [sys.executable, str(_root / "aibrain_db.py")] + args,
        cwd=str(_root),
    )
    sys.exit(result.returncode)


def _handle_packs(args):
    """Browse and activate brain packs (life-domain bundles)."""
    import json

    packs_path = _root / "brain_packs.json"
    if not packs_path.exists():
        print("Error: brain_packs.json not found", file=sys.stderr)
        sys.exit(1)

    data = json.loads(packs_path.read_text(encoding="utf-8"))
    packs = data.get("packs", {})

    subcmd = args[0] if args else "list"

    if subcmd in ("list", "browse"):
        print("AIBrain Packs — pick what fits your life\n")
        for key, pack in packs.items():
            tier_badge = "" if pack.get("tier") == "free" else " [Pro]"
            wf_count = len(pack.get("workflows", []))
            print(f"  {key:20s} {pack['name']}{tier_badge}")
            print(f"  {'':20s} {pack['tagline']}")
            print(f"  {'':20s} {wf_count} workflows")
            print()
        print("Activate a pack:  aibrain packs activate <name>")
        print("Example:          aibrain packs activate productivity")

    elif subcmd == "activate":
        if len(args) < 2:
            print("Usage: aibrain packs activate <pack_name>")
            print(f"Available: {', '.join(packs.keys())}")
            return

        pack_name = args[1]
        if pack_name not in packs:
            print(f"Unknown pack: {pack_name}")
            print(f"Available: {', '.join(packs.keys())}")
            return

        pack = packs[pack_name]
        pack_workflows = set(pack.get("workflows", []))

        # Load scheduled_jobs.json and enable pack workflows
        jobs_path = _root / "scheduled_jobs.json"
        if not jobs_path.exists():
            print("Error: scheduled_jobs.json not found", file=sys.stderr)
            sys.exit(1)

        jobs_data = json.loads(jobs_path.read_text(encoding="utf-8"))
        jobs = jobs_data.get("jobs", [])
        existing_names = {j["name"] for j in jobs}

        enabled_count = 0
        for job in jobs:
            if job["name"] in pack_workflows and not job.get("enabled", False):
                job["enabled"] = True
                enabled_count += 1

        # Add missing workflows with defaults from free-tier defaults or basic template
        try:
            from aibrain_update import FREE_TIER_JOB_DEFAULTS
        except ImportError:
            FREE_TIER_JOB_DEFAULTS = {}

        added_count = 0
        for wf_name in sorted(pack_workflows):
            if wf_name not in existing_names:
                defaults = FREE_TIER_JOB_DEFAULTS.get(wf_name, {})
                new_job = {
                    "name": wf_name,
                    "script": defaults.get("script", f"run_workflow.py {wf_name}"),
                    "cron": defaults.get("cron", "0 8 * * *"),
                    "enabled": True,
                    "group": defaults.get("group", "pack"),
                    "pack": pack_name,
                    "description": defaults.get("description", f"From {pack['name']} pack"),
                }
                jobs.append(new_job)
                added_count += 1

        jobs_data["jobs"] = jobs
        jobs_data["_updated"] = __import__("datetime").datetime.now().strftime("%Y-%m-%d")
        jobs_path.write_text(json.dumps(jobs_data, indent=2), encoding="utf-8")

        # Track active packs in config
        config_path = _root / "config.json"
        if config_path.exists():
            try:
                cfg = json.loads(config_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                cfg = {}
        else:
            cfg = {}
        active_packs = set(cfg.get("active_packs", []))
        active_packs.add(pack_name)
        cfg["active_packs"] = sorted(active_packs)
        config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

        print(f"\n  Activated: {pack['name']}")
        print(f"  {pack['description']}")
        print(f"  Enabled {enabled_count} workflows, added {added_count} new")
        print(f"\n  Workflows in this pack:")
        for wf in sorted(pack_workflows):
            print(f"    - {wf}")

        # Inject seed memories
        seeds = pack.get("seed_memories", [])
        if seeds:
            try:
                from aibrain_db import get_db
                db = get_db()
                for seed in seeds:
                    db.execute(
                        "INSERT OR IGNORE INTO memories (name, content, type, importance, created_at, updated_at) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
                        (seed["name"], seed["content"], seed.get("type", "reference"), seed.get("importance", 0.5)),
                    )
                db.commit()
                print(f"  Added {len(seeds)} seed memories")
            except Exception:
                pass

        # Inject skill profiles
        skills = pack.get("skills", [])
        if skills:
            try:
                from skill_memory import SkillMemory
                import os
                db_path = os.environ.get("AIBRAIN_DB", str(_root / "aibrain.db"))
                sm = SkillMemory(db_path)
                for skill in skills:
                    for principle in skill.get("principles", []):
                        sm.add_principle(
                            task_type=skill["task_type"],
                            principle=principle,
                            source=f"pack:{pack_name}",
                        )
                print(f"  Loaded {len(skills)} skill profiles ({sum(len(s.get('principles',[])) for s in skills)} principles)")
            except Exception:
                pass

        # Apply stack config (cron overrides)
        stack_cfg = pack.get("stack", {})
        cron_overrides = stack_cfg.get("cron_overrides", {})
        if cron_overrides:
            override_count = 0
            for job in jobs_data.get("jobs", []):
                if job["name"] in cron_overrides:
                    job["cron"] = cron_overrides[job["name"]]
                    override_count += 1
            if override_count:
                jobs_path.write_text(json.dumps(jobs_data, indent=2), encoding="utf-8")
                print(f"  Applied {override_count} cron schedule overrides")

        # Save stack snapshot for this pack
        import subprocess
        stack_script = _root / "stack_snapshot.py"
        if stack_script.exists():
            subprocess.run(
                [sys.executable, str(stack_script), "save", f"pack_{pack_name}"],
                cwd=str(_root), capture_output=True, timeout=15,
            )
            print(f"  Saved stack snapshot: pack_{pack_name}")

        # Store agent config
        agent_cfg = pack.get("agent_config", {})
        if agent_cfg:
            cfg["agent_focus"] = agent_cfg.get("focus_areas", [])
            cfg["agent_personality"] = agent_cfg.get("personality", "")
            cfg["system_prompt_addition"] = agent_cfg.get("system_prompt_addition", "")
            config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
            print(f"  Agent specialisation configured: {', '.join(agent_cfg.get('focus_areas', []))}")

        # Note satellite DBs needed
        sat_dbs = pack.get("satellite_dbs", [])
        if sat_dbs:
            print(f"\n  Satellite DBs ({len(sat_dbs)}):")
            for sdb in sat_dbs:
                print(f"    - {sdb['name']}: {sdb['description']}")
            print(f"  Run 'aibrain brain import' to populate these with domain knowledge")

    elif subcmd == "active":
        config_path = _root / "config.json"
        if config_path.exists():
            try:
                cfg = json.loads(config_path.read_text(encoding="utf-8"))
                active = cfg.get("active_packs", [])
                if active:
                    print("Active packs:")
                    for p in active:
                        pack = packs.get(p, {})
                        print(f"  {p:20s} {pack.get('name', p)} — {len(pack.get('workflows', []))} workflows")
                else:
                    print("No packs activated. Run: aibrain packs activate <name>")
            except (json.JSONDecodeError, OSError):
                print("No packs activated.")
        else:
            print("No config.json found. Run: aibrain setup")

    else:
        print(f"Unknown packs command: {subcmd}")
        print("Usage: aibrain packs [list|activate <name>|active]")


if __name__ == "__main__":
    main()
