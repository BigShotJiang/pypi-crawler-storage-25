"""
AIBrain LLM Router — unified multi-model routing with LiteLLM.

Provides:
  - complete(prompt, model, category) — smart model routing with fallback chains
  - Cost tracking to SQLite (model, tokens, cost, latency per call)
  - get_cost_summary(), get_cost_by_model(), get_cost_by_workflow(), get_daily_costs()
  - list_models(), test_model() — model discovery and health checks

Graceful degradation: works without litellm installed by falling back to
the existing chat_responder provider chain.
"""

import json
import logging
import os
import sqlite3
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
CONFIG_FILE = AIBRAIN_ROOT / "config.json"
COST_DB_PATH = AIBRAIN_ROOT / "cost_tracking.db"

# ---------------------------------------------------------------------------
# Optional LiteLLM import
# ---------------------------------------------------------------------------
try:
    import litellm
    litellm.drop_params = True  # ignore unsupported params per-provider
    LITELLM_AVAILABLE = True
except ImportError:
    LITELLM_AVAILABLE = False

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


# Default routing table — which models to try for each category
# Categories align with harness task types:
#   deterministic = no LLM needed (code only, $0)
#   simple = cheap model for formatting/parsing
#   judgment = capable model for reasoning/analysis
#   complex = most capable model for architecture/novel problems
DEFAULT_ROUTING = {
    "deterministic": [],  # No LLM — handled by code. complete() returns early.
    "simple": [
        # Local models first (FREE) — try each until one responds
        "ollama/qwen2.5:7b-instruct",  # installed, 4.7GB, good for formatting
        "ollama/qwen3:8b",              # installed, 5.2GB, newer
        "ollama/gemma3:4b",             # small, fast, if installed
        # Cloud fallbacks (cheap)
        "claude-haiku-4-5-20251001",     # ~$0.001 per call
        "gpt-4o-mini",                   # ~$0.001 per call
    ],
    "judgment": [
        "claude-sonnet-4-20250514",      # primary — strong reasoning
        "gpt-4o",                        # fallback
        "ollama/qwen2.5:7b-instruct",   # local fallback if APIs down
    ],
    "complex": [
        "claude-opus-4-20250514",        # strongest available
        "claude-sonnet-4-20250514",      # fallback
        "gpt-4o",                        # last resort
    ],
    "creative": [
        "claude-sonnet-4-20250514",
        "gpt-4o",
        "ollama/qwen3:8b",
    ],
    "default": [
        "claude-sonnet-4-20250514",
        "gpt-4o-mini",
        "ollama/qwen2.5:7b-instruct",
    ],
}

# ---------------------------------------------------------------------------
# Cost Tracking DB
# ---------------------------------------------------------------------------

def _get_cost_db() -> sqlite3.Connection:
    db = sqlite3.connect(str(COST_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS llm_costs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            model TEXT NOT NULL,
            category TEXT DEFAULT 'default',
            tokens_in INTEGER DEFAULT 0,
            tokens_out INTEGER DEFAULT 0,
            cost_usd REAL DEFAULT 0.0,
            latency_ms INTEGER DEFAULT 0,
            workflow_id TEXT DEFAULT '',
            success INTEGER DEFAULT 1,
            error_msg TEXT DEFAULT ''
        )
    """)
    db.execute("""
        CREATE INDEX IF NOT EXISTS idx_llm_costs_timestamp ON llm_costs(timestamp)
    """)
    db.execute("""
        CREATE INDEX IF NOT EXISTS idx_llm_costs_model ON llm_costs(model)
    """)
    db.commit()
    return db


def _log_cost(
    model: str,
    category: str,
    tokens_in: int,
    tokens_out: int,
    cost_usd: float,
    latency_ms: int,
    workflow_id: str = "",
    success: bool = True,
    error_msg: str = "",
):
    db = None
    try:
        db = _get_cost_db()
        db.execute(
            """INSERT INTO llm_costs
               (timestamp, model, category, tokens_in, tokens_out, cost_usd, latency_ms, workflow_id, success, error_msg)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                datetime.now().isoformat(),
                model, category, tokens_in, tokens_out,
                cost_usd, latency_ms, workflow_id,
                1 if success else 0, error_msg,
            ),
        )
        db.commit()
    except Exception:
        logger.warning("Failed to log LLM cost for model=%s", model, exc_info=True)
    finally:
        if db:
            db.close()


# ---------------------------------------------------------------------------
# Model routing helpers
# ---------------------------------------------------------------------------

def _get_routing_table() -> dict:
    """Get routing table from config or defaults."""
    cfg = _load_config()
    return cfg.get("llm_routing", DEFAULT_ROUTING)


def _get_model_chain(category: Optional[str] = None) -> list[str]:
    """Get ordered list of models to try for a given category."""
    routing = _get_routing_table()
    cat = category or "default"
    return routing.get(cat, routing.get("default", DEFAULT_ROUTING["default"]))


def _set_provider_keys():
    """Push API keys from config.json into env vars for litellm."""
    cfg = _load_config()
    if cfg.get("anthropic_api_key") and not os.environ.get("ANTHROPIC_API_KEY"):
        os.environ["ANTHROPIC_API_KEY"] = cfg["anthropic_api_key"]
    if cfg.get("openai_api_key") and not os.environ.get("OPENAI_API_KEY"):
        os.environ["OPENAI_API_KEY"] = cfg["openai_api_key"]
    ollama_url = cfg.get("ollama_url", "http://localhost:11434")
    if not os.environ.get("OLLAMA_API_BASE"):
        os.environ["OLLAMA_API_BASE"] = ollama_url


# ---------------------------------------------------------------------------
# Main completion function
# ---------------------------------------------------------------------------

def complete(
    prompt: str,
    model: Optional[str] = None,
    category: Optional[str] = None,
    system: Optional[str] = None,
    history: Optional[list] = None,
    max_tokens: int = 1024,
    workflow_id: str = "",
) -> dict:
    """
    Send a completion request with automatic model routing and fallback.

    Args:
        prompt: The user message / prompt text.
        model: Specific model to use (skips routing). e.g. "claude-sonnet-4-20250514"
        category: Task category for routing: "simple", "complex", "creative", or None.
        system: System prompt. Optional.
        history: Chat history as list of {"role": "user"|"assistant", "content": "..."}.
        max_tokens: Max response tokens.
        workflow_id: Optional workflow identifier for cost tracking.

    Returns:
        dict with keys: content, model, tokens_in, tokens_out, cost_usd, latency_ms, provider
    """
    # Deterministic tasks skip LLM entirely — zero tokens, zero cost
    if category == "deterministic":
        logger.debug("Deterministic task — skipping LLM, returning prompt as-is")
        return {
            "content": prompt,
            "model": "code_only",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "latency_ms": 0,
            "provider": "none",
        }

    if not LITELLM_AVAILABLE:
        return _fallback_complete(prompt, model, category, system, history, max_tokens, workflow_id)

    _set_provider_keys()

    # Build model chain
    if model:
        models_to_try = [model]
    else:
        models_to_try = _get_model_chain(category)

    # Build messages
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    if history:
        messages.extend(history[-10:])
    # Ensure the prompt is the final user message
    if not messages or messages[-1].get("role") != "user" or messages[-1].get("content") != prompt:
        messages.append({"role": "user", "content": prompt})

    last_error = None
    for m in models_to_try:
        t0 = time.time()
        try:
            response = litellm.completion(
                model=m,
                messages=messages,
                max_tokens=max_tokens,
            )
            latency_ms = int((time.time() - t0) * 1000)

            content = response.choices[0].message.content or ""
            usage = response.usage or type("U", (), {"prompt_tokens": 0, "completion_tokens": 0})()
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0
            tokens_out = getattr(usage, "completion_tokens", 0) or 0

            # litellm tracks cost via response_cost
            cost_usd = 0.0
            try:
                cost_usd = litellm.completion_cost(completion_response=response) or 0.0
            except Exception:
                logger.warning("Failed to calculate completion cost for model=%s", m, exc_info=True)

            _log_cost(m, category or "default", tokens_in, tokens_out, cost_usd, latency_ms, workflow_id)

            return {
                "content": content,
                "model": m,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "cost_usd": round(cost_usd, 6),
                "latency_ms": latency_ms,
                "provider": "litellm",
            }

        except Exception as e:
            latency_ms = int((time.time() - t0) * 1000)
            last_error = str(e)
            _log_cost(m, category or "default", 0, 0, 0.0, latency_ms, workflow_id, success=False, error_msg=last_error[:500])
            continue

    # All models failed — try fallback without litellm
    result = _fallback_complete(prompt, model, category, system, history, max_tokens, workflow_id)
    if result.get("content"):
        return result

    return {
        "content": f"All models failed. Last error: {last_error or 'unknown'}",
        "model": "none",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost_usd": 0.0,
        "latency_ms": 0,
        "provider": "error",
    }


# ---------------------------------------------------------------------------
# Fallback: use existing chat_responder providers when litellm is not installed
# ---------------------------------------------------------------------------

def _fallback_complete(
    prompt: str,
    model: Optional[str] = None,
    category: Optional[str] = None,
    system: Optional[str] = None,
    history: Optional[list] = None,
    max_tokens: int = 1024,
    workflow_id: str = "",
) -> dict:
    """Fallback to direct provider calls when litellm is unavailable."""
    cfg = _load_config()
    system_ctx = system or ""

    # Build history in chat format
    hist = []
    if history:
        for msg in history[-10:]:
            hist.append(msg)

    t0 = time.time()
    content = None
    used_model = "unknown"

    provider = cfg.get("llm_provider", "auto")

    # Try providers in order
    providers_to_try = []
    if provider == "auto":
        providers_to_try = ["claude", "openai", "ollama"]
    else:
        providers_to_try = [provider]
        # Add fallbacks
        for p in ["claude", "openai", "ollama"]:
            if p not in providers_to_try:
                providers_to_try.append(p)

    for prov in providers_to_try:
        try:
            if prov == "claude" and (cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY")):
                import anthropic
                api_key = cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")
                client = anthropic.Anthropic(api_key=api_key)
                msgs = []
                for m in hist:
                    role = "user" if m.get("role") == "user" else "assistant"
                    msgs.append({"role": role, "content": m.get("content", "")})
                if not msgs or msgs[-1]["role"] != "user":
                    msgs.append({"role": "user", "content": prompt})
                resp = client.messages.create(
                    model=cfg.get("anthropic_model", "claude-sonnet-4-20250514"),
                    max_tokens=max_tokens,
                    system=system_ctx,
                    messages=msgs,
                )
                content = resp.content[0].text
                used_model = cfg.get("anthropic_model", "claude-sonnet-4-20250514")
                break

            elif prov == "openai" and (cfg.get("openai_api_key") or os.environ.get("OPENAI_API_KEY")):
                import openai
                api_key = cfg.get("openai_api_key") or os.environ.get("OPENAI_API_KEY", "")
                client = openai.OpenAI(api_key=api_key)
                msgs = [{"role": "system", "content": system_ctx}] if system_ctx else []
                for m in hist:
                    role = "user" if m.get("role") == "user" else "assistant"
                    msgs.append({"role": role, "content": m.get("content", "")})
                if not msgs or msgs[-1]["role"] != "user":
                    msgs.append({"role": "user", "content": prompt})
                resp = client.chat.completions.create(
                    model=cfg.get("openai_model", "gpt-4o-mini"),
                    messages=msgs,
                    max_tokens=max_tokens,
                )
                content = resp.choices[0].message.content
                used_model = cfg.get("openai_model", "gpt-4o-mini")
                break

            elif prov == "ollama":
                import urllib.request
                ollama_url = cfg.get("ollama_url", "http://localhost:11434")
                # Try each Ollama model from the routing table for this category
                routing = _get_routing_table()
                cat = category or "default"
                ollama_models = [m.replace("ollama/", "") for m in routing.get(cat, routing.get("default", [])) if m.startswith("ollama/")]
                if not ollama_models:
                    ollama_models = [cfg.get("ollama_model", "qwen2.5:7b-instruct")]
                msgs = [{"role": "system", "content": system_ctx}] if system_ctx else []
                for m in hist:
                    role = "user" if m.get("role") == "user" else "assistant"
                    msgs.append({"role": role, "content": m.get("content", "")})
                if not msgs or msgs[-1]["role"] != "user":
                    msgs.append({"role": "user", "content": prompt})
                for ollama_model in ollama_models:
                    try:
                        req = urllib.request.Request(
                            ollama_url + "/api/chat",
                            data=json.dumps({"model": ollama_model, "messages": msgs, "stream": False}).encode(),
                            headers={"Content-Type": "application/json"},
                        )
                        with urllib.request.urlopen(req, timeout=60) as resp:
                            data = json.loads(resp.read())
                            content = data.get("message", {}).get("content", "")
                            used_model = "ollama/" + ollama_model
                        if content:
                            break
                    except Exception:
                        logger.debug("Ollama model %s failed, trying next", ollama_model)
                        continue
                if content:
                    break

        except Exception:
            logger.warning("Fallback provider %s failed", prov, exc_info=True)
            continue

    latency_ms = int((time.time() - t0) * 1000)

    if content:
        _log_cost(used_model, category or "default", 0, 0, 0.0, latency_ms, workflow_id)
        return {
            "content": content,
            "model": used_model,
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "latency_ms": latency_ms,
            "provider": "fallback",
        }

    return {
        "content": "",
        "model": "none",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost_usd": 0.0,
        "latency_ms": latency_ms,
        "provider": "none",
    }


# ---------------------------------------------------------------------------
# Cost query functions
# ---------------------------------------------------------------------------

def get_cost_summary(days: int = 30) -> dict:
    """Total spend, token counts, and call counts for the last N days."""
    db = _get_cost_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()
    row = db.execute("""
        SELECT
            COUNT(*) as total_calls,
            SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful_calls,
            SUM(tokens_in) as total_tokens_in,
            SUM(tokens_out) as total_tokens_out,
            SUM(cost_usd) as total_cost_usd,
            AVG(latency_ms) as avg_latency_ms
        FROM llm_costs
        WHERE timestamp >= ?
    """, (cutoff,)).fetchone()
    db.close()
    return {
        "period_days": days,
        "total_calls": row["total_calls"] or 0,
        "successful_calls": row["successful_calls"] or 0,
        "total_tokens_in": row["total_tokens_in"] or 0,
        "total_tokens_out": row["total_tokens_out"] or 0,
        "total_cost_usd": round(row["total_cost_usd"] or 0.0, 6),
        "avg_latency_ms": int(row["avg_latency_ms"] or 0),
    }


def get_cost_by_model(days: int = 30) -> list[dict]:
    """Breakdown of costs per model."""
    db = _get_cost_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()
    rows = db.execute("""
        SELECT
            model,
            COUNT(*) as calls,
            SUM(tokens_in) as tokens_in,
            SUM(tokens_out) as tokens_out,
            SUM(cost_usd) as cost_usd,
            AVG(latency_ms) as avg_latency_ms
        FROM llm_costs
        WHERE timestamp >= ? AND success = 1
        GROUP BY model
        ORDER BY cost_usd DESC
    """, (cutoff,)).fetchall()
    db.close()
    return [
        {
            "model": r["model"],
            "calls": r["calls"],
            "tokens_in": r["tokens_in"] or 0,
            "tokens_out": r["tokens_out"] or 0,
            "cost_usd": round(r["cost_usd"] or 0.0, 6),
            "avg_latency_ms": int(r["avg_latency_ms"] or 0),
        }
        for r in rows
    ]


def get_cost_by_workflow(days: int = 30) -> list[dict]:
    """Breakdown of costs per workflow."""
    db = _get_cost_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()
    rows = db.execute("""
        SELECT
            CASE WHEN workflow_id = '' THEN 'chat' ELSE workflow_id END as workflow,
            COUNT(*) as calls,
            SUM(tokens_in) as tokens_in,
            SUM(tokens_out) as tokens_out,
            SUM(cost_usd) as cost_usd,
            AVG(latency_ms) as avg_latency_ms
        FROM llm_costs
        WHERE timestamp >= ? AND success = 1
        GROUP BY workflow
        ORDER BY cost_usd DESC
    """, (cutoff,)).fetchall()
    db.close()
    return [
        {
            "workflow": r["workflow"],
            "calls": r["calls"],
            "tokens_in": r["tokens_in"] or 0,
            "tokens_out": r["tokens_out"] or 0,
            "cost_usd": round(r["cost_usd"] or 0.0, 6),
            "avg_latency_ms": int(r["avg_latency_ms"] or 0),
        }
        for r in rows
    ]


def get_daily_costs(days: int = 30) -> list[dict]:
    """Daily cost data for charting."""
    db = _get_cost_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()
    rows = db.execute("""
        SELECT
            DATE(timestamp) as day,
            COUNT(*) as calls,
            SUM(tokens_in) as tokens_in,
            SUM(tokens_out) as tokens_out,
            SUM(cost_usd) as cost_usd
        FROM llm_costs
        WHERE timestamp >= ? AND success = 1
        GROUP BY DATE(timestamp)
        ORDER BY day
    """, (cutoff,)).fetchall()
    db.close()
    return [
        {
            "day": r["day"],
            "calls": r["calls"],
            "tokens_in": r["tokens_in"] or 0,
            "tokens_out": r["tokens_out"] or 0,
            "cost_usd": round(r["cost_usd"] or 0.0, 6),
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Model discovery and health
# ---------------------------------------------------------------------------

def list_models() -> list[dict]:
    """List all configured models with availability status."""
    cfg = _load_config()
    routing = _get_routing_table()

    # Collect all unique models from routing table
    all_models = set()
    for chain in routing.values():
        all_models.update(chain)

    models = []
    for m in sorted(all_models):
        info = {"model": m, "status": "unknown", "provider": _guess_provider(m)}

        # Check if provider credentials exist
        if info["provider"] == "anthropic":
            info["status"] = "configured" if (cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY")) else "no_api_key"
        elif info["provider"] == "openai":
            info["status"] = "configured" if (cfg.get("openai_api_key") or os.environ.get("OPENAI_API_KEY")) else "no_api_key"
        elif info["provider"] == "ollama":
            info["status"] = "local"

        # Check which categories use this model
        categories = [cat for cat, chain in routing.items() if m in chain]
        info["categories"] = categories

        models.append(info)

    return models


def _guess_provider(model: str) -> str:
    """Guess the provider from a model name."""
    m = model.lower()
    if m.startswith("ollama/"):
        return "ollama"
    if "claude" in m or "anthropic" in m:
        return "anthropic"
    if "gpt" in m or "o1" in m or "o3" in m:
        return "openai"
    if "gemini" in m:
        return "google"
    if "mistral" in m or "mixtral" in m:
        return "mistral"
    return "unknown"


def test_model(model: str) -> dict:
    """Test connectivity to a specific model with a tiny prompt."""
    result = complete(
        prompt="Say 'ok' and nothing else.",
        model=model,
        max_tokens=10,
        workflow_id="_test",
    )
    return {
        "model": model,
        "success": result["provider"] != "error" and bool(result["content"]),
        "latency_ms": result["latency_ms"],
        "response": result["content"][:100] if result["content"] else "",
        "provider": result["provider"],
    }
