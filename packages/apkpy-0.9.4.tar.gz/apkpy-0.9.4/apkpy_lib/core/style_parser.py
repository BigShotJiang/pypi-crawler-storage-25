import re

def parse_css(css_text):
    styles = {}
    keyframes = {}
    
    # Extrair blocos @keyframes
    # Suporta 1 nível de nesting, ex: @keyframes name { from {...} to {...} }
    kf_blocks = re.findall(r'@keyframes\s+(\w+)\s*\{((?:[^{}]*\{[^{}]*\})*[^{}]*)\}', css_text)
    for name, content in kf_blocks:
        kf_dict = {}
        stages = re.findall(r'([a-zA-Z0-9%]+)\s*\{([^{}]*)\}', content)
        for stage, props_str in stages:
            props = {}
            lines = re.findall(r'([\w-]+)\s*:\s*(.*?);', props_str)
            for key, value in lines:
                props[key.strip()] = value.strip()
            kf_dict[stage.strip()] = props
        keyframes[name.strip()] = kf_dict
        
    # Remover blocos @keyframes para não confundir o parser de estilos normais
    clean_css = re.sub(r'@keyframes\s+\w+\s*\{(?:[^{}]*\{[^{}]*\})*[^{}]*\}', '', css_text)

    # Procura blocos tipo: .nome { propriedades } ou nome { propriedades }
    # O ponto (.) é opcional — suporta seletores de classe CSS
    blocks = re.findall(r'\.?([a-zA-Z0-9_-]+)\s*\{([^{}]*)\}', clean_css)
    
    for name, content in blocks:
        props = {}
        # Procura cada linha tipo: color: red;
        lines = re.findall(r'([\w-]+)\s*:\s*(.*?);', content)
        for key, value in lines:
            props[key.strip()] = value.strip()
        styles[name.strip()] = props
        
    return styles, keyframes