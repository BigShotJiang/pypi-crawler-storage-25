import tkinter as tk
import re
import os
import __main__

# Dicionário global para guardar os estilos processados
global_styles = {}
global_keyframes = {}


def _parse_keyframes_internal(css_text):
    """Extrai blocos @keyframes do texto CSS e devolve um dict com as propriedades from/to."""
    keyframes = {}
    kf_blocks = re.findall(r'@keyframes\s+(\w+)\s*\{((?:[^{}]*\{[^{}]*\})*[^{}]*)\}', css_text)
    for name, content in kf_blocks:
        kf_dict = {}
        stages = re.findall(r'([a-zA-Z0-9%]+)\s*\{([^{}]*)\}', content)
        for stage, props_str in stages:
            props = {}
            lines = re.findall(r'([\w-]+)\s*:\s*(.*?);', props_str)
            for key, value in lines:
                props[key.strip()] = value.strip()
            kf_dict[stage.strip()] = props
        keyframes[name.strip()] = kf_dict
    return keyframes


def parse_css_internal(css_text):
    """Lógica para transformar o texto CSS num dicionário Python"""
    styles = {}
    
    # Remover blocos @keyframes para não confundir o parser
    clean_css = re.sub(r'@keyframes\s+\w+\s*\{(?:[^{}]*\{[^{}]*\})*[^{}]*\}', '', css_text)

    # Suporta seletores de classe CSS (.nome) e IDs simples (nome)
    blocks = re.findall(r'\.?([a-zA-Z0-9_-]+)\s*\{([^{}]*)\}', clean_css)
    for name, content in blocks:
        props = {}
        lines = re.findall(r'([\w-]+)\s*:\s*(.*?);', content)
        for key, value in lines:
            props[key.strip()] = value.strip()
        styles[name.strip()] = props
    return styles


def load_styles_now():
    """Procura a variável 'style' no ficheiro writehere.py e carrega-a (sempre recarrega)."""
    global global_styles, global_keyframes
    if hasattr(__main__, 'style'):
        global_styles = parse_css_internal(__main__.style)
        global_keyframes = _parse_keyframes_internal(__main__.style)


def _get_body_style():
    """Devolve o dicionário de estilos do seletor global 'body', ou {} se não definido."""
    return global_styles.get('body', {})


def _merge_with_body(comp_id):
    """
    Funde os estilos do 'body' (base global) com os do ID específico.
    As propriedades do ID específico sobrescrevem sempre as do body.
    Se comp_id for None ou não existir nos estilos, devolve apenas o body.
    """
    body = _get_body_style()
    specific = global_styles.get(comp_id, {}) if comp_id else {}
    return {**body, **specific}


def _get_style_bg(style_dict):
    """Lê a cor de fundo; suporta 'background-color' e 'backgroundcolor' (sem hífen)."""
    return style_dict.get('background-color') or style_dict.get('backgroundcolor')


def _get_style_fg(style_dict):
    """Lê a cor do texto."""
    return style_dict.get('color')

def _get_style_pressed_color(style_dict):
    """Lê a cor de fundo ao pressionar o botão."""
    return style_dict.get('pressed-color')

def _get_style_border_color(style_dict):
    """Lê a cor da borda, ou 'none'."""
    val = style_dict.get('border-color')
    if val and val.lower() == 'none':
        return ""
    return val

def _get_style_focus_border_color(style_dict):
    val = style_dict.get('focus-border-color') or style_dict.get('focus-color')
    if val and val.lower() == 'none':
        return ""
    return val

def _parse_radius(style_dict):
    """Extrai o valor numérico de border-radius (ex: '15px' -> 15)."""
    raw = style_dict.get('border-radius', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _parse_border_width(style_dict):
    """Extrai a largura da borda (ex: '2px' -> 2)."""
    raw = style_dict.get('border-width', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _parse_margin(style_dict):
    """Devolve (top, right, bottom, left) em pixels a partir das propriedades de margin CSS."""
    def _px(val):
        cleaned = re.sub(r'[^0-9.]', '', str(val))
        try:
            return int(float(cleaned))
        except (ValueError, TypeError):
            return 0

    base = _px(style_dict.get('margin', 0))
    top    = _px(style_dict['margin-top'])    if 'margin-top'    in style_dict else base
    right  = _px(style_dict['margin-right'])  if 'margin-right'  in style_dict else base
    bottom = _px(style_dict['margin-bottom']) if 'margin-bottom' in style_dict else base
    left   = _px(style_dict['margin-left'])   if 'margin-left'   in style_dict else base
    return top, right, bottom, left


def _get_flex_orientation(style_dict):
    """
    Determina a orientação de flex a partir das propriedades CSS.

    - display:flex + flex-direction:column  → 'column'  (pack side=TOP)
    - display:flex + flex-direction:row     → 'row'     (pack side=LEFT)
    - display:flex sem flex-direction       → 'row'     (CSS default)
    - sem display:flex                      → 'column'  (stack vertical normal)
    """
    display  = style_dict.get('display', '').strip().lower()
    flex_dir = style_dict.get('flex-direction', '').strip().lower()
    if display == 'flex':
        return 'column' if flex_dir == 'column' else 'row'
    # Legado: apenas flex-direction
    return 'row' if flex_dir == 'row' else 'column'


# ── Typography helpers ────────────────────────────────────────────────────────

def get_native_font(css_family):
    """
    Mapeia uma CSS font-family genérica para a fonte nativa do sistema,
    garantindo fidelidade visual com o Android (Roboto ≈ Segoe UI no Windows).
    """
    is_win = os.name == 'nt'
    mapping = {
        'sans-serif': 'Segoe UI'    if is_win else 'Helvetica',
        'serif':      'Times New Roman',
        'monospace':  'Consolas'    if is_win else 'Courier',
    }
    if not css_family:
        return 'Segoe UI' if is_win else 'Helvetica'
    css_lower = css_family.strip().lower()
    for key, val in mapping.items():
        if key in css_lower:
            return val
    # Devolve o valor literal (ex: 'Roboto') como fallback
    return css_family.strip()


def _parse_font_size(style_dict, default=14):
    """Extrai font-size em px. Devolve 'default' se não definido."""
    raw = style_dict.get('font-size', '')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return default


def _parse_font_weight_tk(style_dict):
    """
    Devolve os modificadores de fonte Tkinter ('bold', 'italic', ou ambos).
    Retorna uma lista de strings para uso em font=(family, size, *modifiers).
    """
    weight = style_dict.get('font-weight', '').strip().lower()
    style  = style_dict.get('font-style',  '').strip().lower()
    mods = []
    if weight in ('bold', '700', '800', '900'):
        mods.append('bold')
    if style == 'italic':
        mods.append('italic')
    return mods


def _build_tk_font(style_dict, default_size=14):
    """
    Constrói uma tupla de fonte Tkinter a partir de um dicionário de estilos CSS.
    O tamanho é passado como NEGATIVO para que o Tkinter o interprete em píxeis
    (tamanho positivo = pontos; a 96 DPI 1pt = 1.333px, logo os textos ficam ~33%
    maiores do que o valor CSS indica). Com valor negativo ficamos 1 CSS-px = 1px
    no ecrã, igual ao dp no Android Studio.
    Ex: ('Segoe UI', -18, 'bold')  → 18 px exactos
    """
    family = get_native_font(style_dict.get('font-family', ''))
    size   = _parse_font_size(style_dict, default=default_size)
    mods   = _parse_font_weight_tk(style_dict)
    return (family, -size, *mods)  # negativo = píxeis exactos


def _create_rounded_rect(canvas, x1, y1, x2, y2, r, **kwargs):
    """Desenha retângulo com cantos arredondados no Canvas."""
    r = max(0, min(r, (x2 - x1) // 2, (y2 - y1) // 2))
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r,
        x1, y1 + r, x1, y1, x1 + r, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)


# ─── Animação Engine (Tkinter) ────────────────────────────────────────

def _hex_to_rgb(hex_color):
    """Converte cor hex (#RRGGBB) para tupla (r, g, b)."""
    hex_color = hex_color.strip('#')
    if len(hex_color) == 3:
        hex_color = ''.join(c*2 for c in hex_color)
    try:
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    except Exception:
        return (33, 33, 33)  # fallback


def _rgb_to_hex(r, g, b):
    """Converte (r, g, b) para string hex #RRGGBB."""
    return f'#{int(r):02x}{int(g):02x}{int(b):02x}'


def _lerp(a, b, t):
    """Interpola linearmente entre a e b com t em [0, 1]."""
    return a + (b - a) * t


def _parse_anim_val(raw, default=0.0):
    """Extrai valor numérico de uma string CSS (ex: '50px' -> 50.0)."""
    try:
        return float(re.sub(r'[^0-9.-]', '', str(raw)))
    except (ValueError, TypeError):
        return default


def _animate_widget(root, widget, style_dict, spacer=None, canvas=None,
                    fill_color=None, text_color=None):
    """
    Motor de animação para a preview Tkinter.
    Lê 'animation-name' e 'animation-duration' do style_dict,
    procura o @keyframes correspondente no global_keyframes
    e interpola os valores frame a frame usando root.after().

    Propriedades animadas:
      - opacity: interpola a cor do texto/fill de bg para a cor alvo.
      - margin-top: anima a altura do spacer (frame acima do widget).
    """
    anim_name = style_dict.get('animation-name')
    if not anim_name:
        return
    frames = global_keyframes.get(anim_name)
    if not frames:
        return

    from_dict = frames.get('from', frames.get('0%', {}))
    to_dict   = frames.get('to',   frames.get('100%', {}))

    # Duração em ms
    duration_str = style_dict.get('animation-duration', '600ms')
    duration_ms  = _parse_anim_val(duration_str, 600)
    frame_ms     = 16  # ~60 fps
    total_frames = max(1, int(duration_ms / frame_ms))

    # ─ opacity ─────────────────────────────────────────
    do_opacity = 'opacity' in from_dict or 'opacity' in to_dict
    f_opacity  = _parse_anim_val(from_dict.get('opacity', 1.0), 1.0)
    t_opacity  = _parse_anim_val(to_dict.get('opacity',   1.0), 1.0)

    # Cor alvo real (text ou fill)
    bg_rgb  = _hex_to_rgb('#ffffff')  # fundo sempre branco na preview
    if text_color:
        real_fg_rgb = _hex_to_rgb(text_color)
    else:
        try:
            if canvas:
                actual_fg = fill_color or '#e0e0e0'
            else:
                actual_fg = widget.cget('fg')
            real_fg_rgb = _hex_to_rgb(actual_fg)
        except Exception:
            real_fg_rgb = (33, 33, 33)

    # ─ margin-top ──────────────────────────────────────
    do_margin = spacer is not None and ('margin-top' in from_dict or 'margin-top' in to_dict)
    f_margin  = _parse_anim_val(from_dict.get('margin-top', 0), 0)
    t_margin  = _parse_anim_val(to_dict.get('margin-top',   0), 0)

    def _step(frame_idx):
        t = frame_idx / total_frames  # progresso 0.0 → 1.0
        # Ease-out cúbia: mais natural
        t_eased = 1 - (1 - t) ** 3

        # Animar opacidade simulada (interpola cor de bg para cor real)
        if do_opacity:
            cur_opacity = _lerp(f_opacity, t_opacity, t_eased)  # 0.0 → 1.0
            if canvas:
                # Para canvas (botões): interpola fill entre bg e fill_color
                fr  = _hex_to_rgb(fill_color or '#e0e0e0')
                cur = _rgb_to_hex(
                    _lerp(bg_rgb[0], fr[0], cur_opacity),
                    _lerp(bg_rgb[1], fr[1], cur_opacity),
                    _lerp(bg_rgb[2], fr[2], cur_opacity),
                )
                try:
                    canvas.itemconfig('body', fill=cur)
                except Exception:
                    pass
            else:
                # Para labels/widgets: interpola a cor do texto
                cur_rgb = (
                    _lerp(bg_rgb[0], real_fg_rgb[0], cur_opacity),
                    _lerp(bg_rgb[1], real_fg_rgb[1], cur_opacity),
                    _lerp(bg_rgb[2], real_fg_rgb[2], cur_opacity),
                )
                try:
                    widget.config(fg=_rgb_to_hex(*cur_rgb))
                except Exception:
                    pass

        # Animar margem superior via spacer
        if do_margin:
            cur_margin = int(_lerp(f_margin, t_margin, t_eased))
            try:
                spacer.config(height=max(0, cur_margin))
            except Exception:
                pass

        if frame_idx < total_frames:
            root.after(frame_ms, lambda: _step(frame_idx + 1))
        else:
            # Garantir valores finais exactos
            if do_opacity and not canvas:
                try:
                    widget.config(fg=text_color or _rgb_to_hex(*real_fg_rgb))
                except Exception:
                    pass
            if do_margin:
                try:
                    spacer.config(height=max(0, int(t_margin)))
                except Exception:
                    pass

    _step(0)


# ─── ComponentDef ─────────────────────────────────────────────────────────────

class ComponentDef:
    """
    Representa um componente de forma declarativa (antes de ser renderizado).
    Ao chamar button(..., screen=x) ou inputs(..., screen=x), é devolvido um
    ComponentDef que podes passar ao on_click_navigate().
    """
    def __init__(self, comp_type, **kwargs):
        self.comp_type = comp_type   # 'button' | 'inputs' | 'label' | 'container'
        self.kwargs = kwargs         # Inclui 'comp_id' para resolver estilos no render
        self.widget = None           # widget Tkinter (preenchido ao renderizar)
        self.nav_target = None       # Screen de destino (definido por on_click_navigate)
        self.children = []           # Filhos se for um container


# ─── Screen ───────────────────────────────────────────────────────────────────

class Screen:
    """
    Container que agrupa componentes num ecrã.
    Cada Screen gera uma Activity separada no Android.

    Exemplo:
        login = Screen(id="login")
        label("Bem-vindo", screen=login)
        btn = button("Entrar", screen=login)
        login.on_click_navigate(button=btn, to=dashboard)
        run(start_screen=login)
    """

    def __init__(self, id, background_image=None):
        self.id = id
        self.background_image = background_image
        self.components = []   # lista de ComponentDef

    def _add(self, comp_def):
        self.components.append(comp_def)
        return comp_def

    def on_click_navigate(self, button, to):
        """
        Define que ao clicar em 'button' neste ecrã, a app navega para 'to'.
        - No Android: gera um Intent Java.
        - No preview Tkinter: troca os componentes visíveis.
        """
        button.nav_target = to


# ─── AppPreview ───────────────────────────────────────────────────────────────

class AppPreview:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("APKPy Preview")
        # Pixel 9: 1080x2424 @ ~420dpi → 411x914 dp (resolução lógica)
        self.root.geometry("411x914")
        self.root.resizable(False, False)
        self.root.configure(bg="#ffffff")

        # ── Barra de status ──────────────────────────────────────────────────
        status = tk.Frame(self.root, bg="#1a1a1a", height=24)
        status.pack(fill="x", side="top")
        status.pack_propagate(False)
        tk.Label(status, text="6:18", bg="#1a1a1a", fg="white",
                 font=("Arial", 10, "bold")).pack(side="left", padx=8)
        tk.Label(status, text="▮▮▮  ▲  ▮▮▮", bg="#1a1a1a", fg="white",
                 font=("Arial", 8)).pack(side="right", padx=8)



        # ── Corpo sem scroll ─────────────────────────────────────────────────
        body = tk.Frame(self.root, bg="#ffffff")
        body.pack(fill="both", expand=True)
        self.layout = tk.Frame(body, bg="#ffffff")
        self.layout.pack(fill="both", expand=True)
        self.canvas = None  # Não usamos canvas quando sem scroll

        # Initialize flex state
        self._is_flex = False
        self._flex_frame = None
        self._flex_side = tk.TOP
        self._flex_bg = "#ffffff"

    # ── Multi-Screen ──────────────────────────────────────────────────────────

    def clear(self):
        """Remove todos os widgets do frame principal."""
        for widget in self.layout.winfo_children():
            widget.destroy()

    def render_screen(self, screen):
        """Limpa o ecrã e renderiza todos os componentes de um Screen."""
        self.clear()

        # Ler estilos do ecrã (identificado pelo screen.id)
        load_styles_now()
        # Fundir estilos do body com os do ecrã específico
        screen_style = _merge_with_body(screen.id)

        # Cor de fundo do ecrã: ID específico > body > branco
        body_bg = _get_style_bg(_get_body_style())
        screen_bg_css = _get_style_bg(global_styles.get(screen.id, {})) or body_bg or '#ffffff'
        screen_bg_tk  = screen_bg_css if screen_bg_css.startswith('#') else '#ffffff'
        self.layout.configure(bg=screen_bg_tk)
        if self.canvas:
            self.canvas.configure(bg=screen_bg_tk)

        # Determinar orientação flex
        flex_dir = _get_flex_orientation(screen_style)  # 'row' | 'column'
        is_flex  = screen_style.get('display', '').strip().lower() == 'flex'

        if is_flex:
            # Container flex: um Frame horizontal ou vertical
            pack_side = tk.LEFT if flex_dir == 'row' else tk.TOP
            flex_frame = tk.Frame(self.layout, bg=screen_bg_tk)
            flex_frame.pack(fill='both', expand=True, padx=8, pady=8)
            # Guardar referencia para os _render_* usarem como parent
            self._flex_frame  = flex_frame
            self._flex_side   = pack_side
            self._flex_bg     = screen_bg_tk
            self._is_flex     = True
        else:
            # Layout normal: scroll vertical
            tk.Frame(self.layout, bg=screen_bg_tk, height=12).pack(fill='x')
            self._flex_frame  = None
            self._flex_side   = None
            self._flex_bg     = screen_bg_tk
            self._is_flex     = False

        # Loop raiz
        for comp in screen.components:
            self._render_comp(comp, self._container, getattr(self, '_is_flex', False), getattr(self, '_flex_side', tk.TOP), self._bg)

    def _render_comp(self, comp, parent_widget, is_flex, pack_side, bg_color):
        if comp.comp_type == 'button':
            self._render_button(comp, parent_widget, is_flex, pack_side, bg_color)
        elif comp.comp_type == 'inputs':
            self._render_input(comp, parent_widget, is_flex, pack_side, bg_color)
        elif comp.comp_type == 'label':
            self._render_label(comp, parent_widget, is_flex, pack_side, bg_color)
        elif comp.comp_type == 'container':
            self._render_container(comp, parent_widget, is_flex, pack_side, bg_color)

    def _render_container(self, comp, parent_widget, parent_is_flex, parent_pack_side, parent_bg):
        comp_id = comp.kwargs.get('comp_id')
        # Fundir body + estilos específicos do container
        style = _merge_with_body(comp_id)
        
        bg = _get_style_bg(style) or parent_bg
        flex_dir = _get_flex_orientation(style)
        is_flex = style.get('display', '').strip().lower() == 'flex'
        pack_side = tk.LEFT if flex_dir == 'row' else tk.TOP
        mt, mr, mb, ml = _parse_margin(style)
        radius = _parse_radius(style)
        bc = _get_style_border_color(style)
        bw = _parse_border_width(style)
        
        # O container é um frame
        outer = tk.Frame(parent_widget, bg=parent_bg)
        
        if parent_is_flex:
            outer.pack(side=parent_pack_side, padx=(ml, mr), pady=(mt, mb))
        else:
            outer.pack(fill='x', padx=(ml, mr), pady=(mt, mb))
            
        inner_frame = tk.Frame(outer, bg=bg)
        if radius > 0 or bw > 0:
            # Tkinter rounded corners hack for containers is complex, 
            # so we just use the inner frame and a highlight if border exists.
            inner_frame.configure(highlightbackground=bc if bc else bg, highlightcolor=bc if bc else bg, highlightthickness=bw)
            
        inner_frame.pack(fill='both', expand=True)
        comp.widget = inner_frame
        
        for child in comp.children:
            self._render_comp(child, inner_frame, is_flex, pack_side, bg)

    @property
    def _container(self):
        """Devolve o frame pai correto: flex_frame (modo flex) ou layout (modo normal)."""
        return self._flex_frame if getattr(self, '_is_flex', False) and self._flex_frame else self.layout

    @property
    def _pack_side(self):
        """Lado do pack para widgets em modo flex."""
        return getattr(self, '_flex_side', tk.TOP) or tk.TOP

    @property
    def _bg(self):
        """Cor de fundo activa do ecrã."""
        return getattr(self, '_flex_bg', '#ffffff') or '#ffffff'

    def _render_label(self, comp, parent_widget, is_flex, pack_side, bg_color):
        text    = comp.kwargs.get('text', '')
        comp_id = comp.kwargs.get('comp_id')
        # Fundir body + estilos específicos do componente
        style   = _merge_with_body(comp_id)
        body_fg = _get_style_fg(_get_body_style())
        fg      = _get_style_fg(style) or body_fg or '#212121'
        mt, mr, mb, ml = _parse_margin(style)
        font    = _build_tk_font(style, default_size=14)
        parent  = parent_widget
        bg      = bg_color

        # Se há animação de margin-top, começa do offset do @keyframes
        anim_name = style.get('animation-name')
        frames    = global_keyframes.get(anim_name, {}) if anim_name else {}
        from_mt   = _parse_anim_val(frames.get('from', {}).get('margin-top', mt), mt)
        spacer_h  = int(from_mt) if frames else mt

        if is_flex:
            # Em modo flex não usamos spacer — a margem é padding lateral
            lbl = tk.Label(
                parent, text=text, font=font,
                fg=fg, bg=bg, anchor='center', padx=8 + ml, pady=4 + mt
            )
            lbl.pack(side=pack_side, padx=(2, 2), pady=(2 + mt, 2 + mb))
            comp.widget = lbl
            _animate_widget(_app.root, lbl, style, text_color=fg)
        else:
            # Modo normal: spacer animado acima do label
            spacer = tk.Frame(parent, bg=bg, height=spacer_h)
            spacer.pack(fill='x')
            spacer.pack_propagate(False)

            lbl = tk.Label(
                parent, text=text, font=font,
                fg=fg, bg=bg, anchor='w', padx=16 + ml
            )
            lbl.pack(pady=(2, 2 + mb), fill='x')
            comp.widget = lbl

            _animate_widget(
                _app.root, lbl, style,
                spacer=spacer if frames else None,
                text_color=fg,
            )

    def _draw_material_button(self, text, bg, fg, radius, command, nav_target, comp=None,
                               border_color=None, border_width=0, pressed_color=None,
                               margin=(0, 0, 0, 0), font=None, parent=None, pack_side=None, bg_color=None):
        """Botão Material Design: cinza claro, texto uppercase, flat."""
        fill_color = bg if bg else "#e0e0e0"
        p_color    = pressed_color if pressed_color else "#bdbdbd"
        text_color = fg if fg else "#212121"
        outline_c  = border_color if border_color else ""
        outline_w  = border_width if border_width > 0 else (1 if outline_c else 0)
        display    = text.upper()
        mt, mr, mb, ml = margin
        btn_font   = font if font else ("Segoe UI" if os.name == 'nt' else "Helvetica", 11, "bold")
        parent     = parent if parent is not None else self.layout
        bg_frame   = bg_color if bg_color is not None else self._bg
        is_flex    = pack_side is not None

        if is_flex:
            # Modo flex: botão compacto, empacotado lateralmente
            outer = tk.Frame(parent, bg=bg_frame)
            outer.pack(side=pack_side, padx=(4 + ml, 4 + mr), pady=(4 + mt, 4 + mb))
            canvas = tk.Canvas(outer, width=120, height=40, bg=bg_frame,
                               highlightthickness=0, bd=0, cursor="hand2")
            canvas.pack()
        else:
            outer = tk.Frame(parent, bg=bg_frame)
            outer.pack(padx=(16 + ml, 16 + mr), pady=(2 + mt, 2 + mb), fill="x")
            canvas = tk.Canvas(outer, height=40, bg=bg_frame,
                               highlightthickness=0, bd=0, cursor="hand2")
            canvas.pack(fill="x", expand=True)

        def _redraw(event=None, _fill=None):
            canvas.delete("all")
            w = canvas.winfo_width() or (event.width if event else 320)
            h = canvas.winfo_height() or 40
            cur_fill = _fill if _fill is not None else fill_color
            if radius > 0:
                _create_rounded_rect(canvas, 0, 0, w, h, radius, fill=cur_fill,
                                     outline=outline_c, width=outline_w, tags='body')
            else:
                canvas.create_rectangle(0, 0, w, h, fill=cur_fill,
                                        outline=outline_c, width=outline_w, tags='body')
            canvas.create_text(w // 2, h // 2, text=display,
                               fill=text_color, font=btn_font, tags='label')
            canvas._current_fill = cur_fill

        def _on_press(event):
            canvas.delete("all")
            w, h = canvas.winfo_width(), canvas.winfo_height()
            if radius > 0:
                _create_rounded_rect(canvas, 0, 0, w, h, radius, fill=p_color,
                                     outline=outline_c, width=outline_w)
            else:
                canvas.create_rectangle(0, 0, w, h, fill=p_color,
                                        outline=outline_c, width=outline_w)
            canvas.create_text(w // 2, h // 2, text=display,
                               fill=text_color, font=btn_font)

        def _on_release(event):
            _redraw()
            if command: command()
            if nav_target: self.render_screen(nav_target)

        canvas.bind("<Configure>", lambda e: _redraw())
        canvas.bind("<ButtonPress-1>", _on_press)
        canvas.bind("<ButtonRelease-1>", _on_release)
        if comp is not None: comp.widget = canvas
        return canvas

    def _render_button(self, comp, parent_widget, is_flex, pack_side, bg_color):
        text       = comp.kwargs.get('text', '')
        comp_id    = comp.kwargs.get('comp_id')
        # Fundir body + estilos específicos do componente
        style      = _merge_with_body(comp_id)
        body_style = _get_body_style()
        bg         = _get_style_bg(style)
        fg         = _get_style_fg(style) or _get_style_fg(body_style)
        pressed_bg = _get_style_pressed_color(style)
        radius     = _parse_radius(style)
        bc         = _get_style_border_color(style)
        bw         = _parse_border_width(style)
        margins    = _parse_margin(style)
        font       = _build_tk_font(style, default_size=11)
        user_cmd   = comp.kwargs.get('command')
        nav_target = comp.nav_target
        parent     = parent_widget

        if is_flex:
            # Modo flex: sem spacer, pack lateral
            canvas = self._draw_material_button(
                text, bg, fg, radius, user_cmd, nav_target,
                comp, bc, bw, pressed_bg,
                margin=(margins[0], margins[1], margins[2], margins[3]),
                font=font, parent=parent, pack_side=pack_side, bg_color=bg_color
            )
            fill_color = bg if bg else '#e0e0e0'
            _animate_widget(_app.root, None, style, canvas=canvas,
                            fill_color=fill_color, text_color=fg)
        else:
            # Modo normal: spacer animado acima do botão
            anim_name = style.get('animation-name')
            frames    = global_keyframes.get(anim_name, {}) if anim_name else {}
            mt = margins[0]
            from_mt   = _parse_anim_val(frames.get('from', {}).get('margin-top', mt), mt)
            spacer_h  = int(from_mt) if frames else mt
            spacer = tk.Frame(parent, bg=bg_color, height=spacer_h)
            spacer.pack(fill='x')
            spacer.pack_propagate(False)

            canvas = self._draw_material_button(
                text, bg, fg, radius, user_cmd, nav_target,
                comp, bc, bw, pressed_bg,
                margin=(0, margins[1], margins[2], margins[3]),
                font=font, parent=parent, bg_color=bg_color
            )

            fill_color = bg if bg else '#e0e0e0'
            _animate_widget(
                _app.root, None, style,
                spacer=spacer if frames else None,
                canvas=canvas,
                fill_color=fill_color,
                text_color=fg,
            )

    def _render_input(self, comp, parent_widget, is_flex, pack_side, bg_color):
        """Resolve estilos no momento do render e delega ao add_input."""
        comp_id = comp.kwargs.get('comp_id')
        # Fundir body + estilos específicos do componente
        style   = _merge_with_body(comp_id)
        margin  = _parse_margin(style)

        # Se há animação de margin-top, criar spacer animado acima do input
        anim_name = style.get('animation-name')
        frames    = global_keyframes.get(anim_name, {}) if anim_name else {}
        mt        = margin[0]
        from_mt   = _parse_anim_val(frames.get('from', {}).get('margin-top', mt), mt)
        spacer_h  = int(from_mt) if frames else mt

        if not is_flex:
            spacer = tk.Frame(parent_widget, bg=bg_color, height=spacer_h)
            spacer.pack(fill='x')
            spacer.pack_propagate(False)
        else:
            spacer = None

        self.add_input(
            placeholder=comp.kwargs.get('placeholder', ''),
            input_type=comp.kwargs.get('input_type', 'text'),
            bg=_get_style_bg(style),
            fg=_get_style_fg(style),
            radius=_parse_radius(style),
            border_color=_get_style_border_color(style),
            border_width=_parse_border_width(style),
            focus_border_color=_get_style_focus_border_color(style),
            margin=(0, margin[1], margin[2], margin[3]),
            font=_build_tk_font(style, default_size=13),
            parent=parent_widget,
            bg_color=bg_color
        )

        # Animação de margem (o widget de input em si não tem fg, usa‑se um label “fantasma”)
        _animate_widget(
            _app.root, None, style,
            spacer=spacer if frames else None,
        )

    # ── Legacy (sem Screen) ───────────────────────────────────────────────────

    def add_label(self, text, fg=None, font=None):
        lbl = tk.Label(
            self.layout, text=text,
            font=font if font else ("Segoe UI" if os.name == 'nt' else "Helvetica", 14),
            fg=fg if fg else "#212121", bg="#ffffff", anchor="w", padx=16
        )
        lbl.pack(pady=(4, 2), fill="x")

    def add_button(self, text, command=None, bg=None, fg=None, radius=0,
                   border_color=None, border_width=0, pressed_color=None, font=None):
        self._draw_material_button(text, bg, fg, radius, command, None,
                                   border_color=border_color,
                                   border_width=border_width,
                                   pressed_color=pressed_color,
                                   font=font)

    def add_input(self, placeholder="", input_type="text", bg=None, fg=None,
                  radius=0, border_color=None, border_width=0, focus_border_color=None,
                  margin=(0, 0, 0, 0), font=None, parent=None, bg_color=None):
        """Input com visual Material Design: linha cinza em baixo, verde ao focar."""
        mt, mr, mb, ml = margin
        parent = parent if parent is not None else self.layout
        bg_frame = bg_color if bg_color is not None else (self._bg if hasattr(self, '_flex_bg') else "#ffffff")

        # ── TEXT / PASSWORD / SEARCH ──────────────────────────────────────────
        if input_type in ("text", "password", "search"):
            outer = tk.Frame(parent, bg=bg_frame)
            outer.pack(padx=(16 + ml, 16 + mr), pady=(4 + mt, 4 + mb), fill="x")

            show_char   = "*" if input_type == "password" else ""
            text_color  = fg if fg else "#212121"
            idle_line   = border_color if border_color else "#bdbdbd"
            focus_line  = focus_border_color if focus_border_color else "#4caf50"
            input_font  = font if font else ("Segoe UI" if os.name == 'nt' else "Helvetica", 13)
            box_bg      = bg if bg else "#ffffff"

            if radius > 0 or border_width > 0:
                canvas = tk.Canvas(outer, height=44, bg=bg_frame, highlightthickness=0)
                canvas.pack(fill="x", expand=True)
                
                entry = tk.Entry(
                    canvas, font=input_font, show=show_char,
                    bg=box_bg, fg="#9e9e9e", relief="flat", bd=0,
                    highlightthickness=0, insertbackground=text_color
                )
                entry_win = canvas.create_window(12, 22, window=entry, anchor="w")
                
                outline_w = border_width if border_width > 0 else 1
                
                def _redraw(event=None, outline_c=idle_line, lw=outline_w):
                    canvas.delete("bg_shape")
                    w = canvas.winfo_width() or (event.width if event else 320)
                    h = canvas.winfo_height() or 44
                    if radius > 0:
                        _create_rounded_rect(canvas, 1, 1, w-1, h-1, radius, fill=box_bg, outline=outline_c, width=lw, tags="bg_shape")
                    else:
                        canvas.create_rectangle(1, 1, w-1, h-1, fill=box_bg, outline=outline_c, width=lw, tags="bg_shape")
                    canvas.tag_lower("bg_shape")
                    
                    if input_type == "search":
                        canvas.itemconfig(entry_win, width=w-40)
                    else:
                        canvas.itemconfig(entry_win, width=w-24)

                canvas.bind("<Configure>", lambda e: _redraw(e))
                
                def on_focus_in(e):
                    _redraw(outline_c=focus_line, lw=max(2, outline_w))
                    if entry.get() == placeholder:
                        entry.delete(0, tk.END)
                        entry.config(fg=text_color)
                
                def on_focus_out(e):
                    _redraw(outline_c=idle_line, lw=outline_w)
                    if entry.get() == "":
                        entry.insert(0, placeholder)
                        entry.config(fg="#9e9e9e")

                entry.bind("<FocusIn>",  on_focus_in)
                entry.bind("<FocusOut>", on_focus_out)
                
                if input_type == "search":
                    def clear_entry():
                        entry.delete(0, tk.END)
                        entry.insert(0, placeholder)
                        entry.config(fg="#9e9e9e")
                    btn_clear = tk.Button(
                        canvas, text="✕", font=("Arial", 10), command=clear_entry,
                        relief="flat", bg=box_bg, fg="#9e9e9e", cursor="hand2", bd=0, highlightthickness=0
                    )
                    clear_win = canvas.create_window(300, 22, window=btn_clear, anchor="e")
                    def _update_clear_pos(e):
                        w = e.width
                        canvas.itemconfig(clear_win, x=w-16)
                    canvas.bind("<Configure>", lambda e: (_redraw(e), _update_clear_pos(e)), add="+")
                    
                entry.insert(0, placeholder)
            else:
                entry = tk.Entry(
                    outer, font=input_font, show=show_char,
                    bg=box_bg, fg="#9e9e9e", relief="flat", bd=0,
                    highlightthickness=0, insertbackground=text_color
                )
                entry.pack(fill="x", ipady=5)

                line = tk.Frame(outer, bg=idle_line, height=1)
                line.pack(fill="x")

                entry.insert(0, placeholder)

                def on_focus_in(e, ent=entry, ph=placeholder, ln=line):
                    ln.config(bg=focus_line, height=2)
                    if ent.get() == ph:
                        ent.delete(0, tk.END)
                        ent.config(fg=text_color)

                def on_focus_out(e, ent=entry, ph=placeholder, ln=line):
                    ln.config(bg=idle_line, height=1)
                    if ent.get() == "":
                        ent.insert(0, ph)
                        ent.config(fg="#9e9e9e")

                entry.bind("<FocusIn>",  on_focus_in)
                entry.bind("<FocusOut>", on_focus_out)

                if input_type == "search":
                    def clear_entry(ent=entry, ph=placeholder):
                        ent.delete(0, tk.END)
                        ent.insert(0, ph)
                        ent.config(fg="#9e9e9e")
                    tk.Button(
                        outer, text="✕", font=("Arial", 10), command=clear_entry,
                        relief="flat", bg=box_bg, fg="#9e9e9e", cursor="hand2", bd=0
                    ).pack(side="right", padx=(2, 0))

        # ── CHECKBOX ──────────────────────────────────────────────────────────
        elif input_type == "checkbox":
            var = tk.BooleanVar()
            tk.Checkbutton(
                parent, text=placeholder, variable=var,
                font=("Arial", 12), bg=bg_frame,
                fg=fg if fg else "#212121", activebackground=bg_frame, anchor="w"
            ).pack(pady=(6 + mt, 6 + mb), padx=(16 + ml, 16 + mr), fill="x")

        # ── RANGE (slider) ────────────────────────────────────────────────────
        elif input_type == "range":
            frame = tk.Frame(parent, bg=bg_frame)
            frame.pack(pady=(6 + mt, 6 + mb), padx=(16 + ml, 16 + mr), fill="x")
            tk.Label(
                frame, text=placeholder if placeholder else "Range",
                font=("Arial", 11), bg=bg_frame, fg=fg if fg else "#212121"
            ).pack(anchor="w")
            tk.Scale(
                frame, from_=0, to=100, orient="horizontal",
                font=("Arial", 10), bg=bg_frame, fg=fg if fg else "#212121",
                highlightthickness=0, troughcolor="#e0e0e0", activebackground="#4caf50"
            ).pack(fill="x")

        # ── RADIO ─────────────────────────────────────────────────────────────
        elif input_type == "radio":
            options = [o.strip() for o in placeholder.split("|")] if placeholder else ["Opção 1", "Opção 2"]
            var = tk.StringVar(value=options[0])
            frame = tk.Frame(parent, bg=bg_frame)
            frame.pack(pady=(6 + mt, 6 + mb), padx=(16 + ml, 16 + mr), fill="x")
            for opt in options:
                tk.Radiobutton(
                    frame, text=opt, variable=var, value=opt,
                    font=("Arial", 12), bg=bg_frame,
                    fg=fg if fg else "#212121", activebackground=bg_frame, anchor="w"
                ).pack(fill="x")

    def run(self):
        self.root.mainloop()


# Instância única da interface
_app = AppPreview()


# ─── Public API ───────────────────────────────────────────────────────────────

_declared_permissions = []

def declare_permissions(perms):
    """
    Declara permissões (ex: "CAMERA", "INTERNET") que o compilador irá
    adicionar ao AndroidManifest.xml.
    """
    global _declared_permissions
    _declared_permissions.extend(perms)

class PermissionsAPI:
    def __init__(self):
        self._granted = set()

    def has(self, perm):
        """No ambiente Tkinter, verifica se o utilizador já concedeu esta permissão localmente."""
        return perm in self._granted
    
    def request(self, perm, on_response=None):
        """Simula o pedido de permissão com um popup de sistema de Tkinter."""
        import tkinter.messagebox as messagebox
        # Se houver root ativo, tenta centralizar, caso contrário, usa janela base
        res = messagebox.askyesno(
            "Emulated Permission Request", 
            f"The ApkPy application is requesting permission to use: {perm}\n\nGrant permission (Emulation)?"
        )
        if res:
            self._granted.add(perm)
            
        if on_response:
            on_response(res)

permissions = PermissionsAPI()

def container(id=None, screen=None, parent=None):
    """
    Cria um contentor (caixa) para agrupar outros componentes (ex: Note Card, Header).
    Pode ser adicionado à raiz do ecrã (screen) ou a outro contentor (parent).
    """
    comp = ComponentDef('container', comp_id=id)
    if parent is not None:
        parent.children.append(comp)
    elif screen is not None:
        screen._add(comp)
    return comp

def label(text, id=None, screen=None, parent=None):
    """
    Adiciona um texto/título à interface.

    Args:
        text:   O texto a mostrar.
        id:     ID para aplicar estilos CSS (ex: style = \"\"\"meu_label { color: red; }\"\"\").
        screen: Screen ao qual pertence (modo multi-ecrã).
        parent: Container pai ao qual pertence (para aninhamento).
    """
    if parent is not None:
        comp = ComponentDef('label', text=text, comp_id=id)
        parent.children.append(comp)
        return comp
    elif screen is not None:
        # Estilos resolvidos no render (dentro de run()), não aqui
        comp = ComponentDef('label', text=text, comp_id=id)
        return screen._add(comp)
    else:
        # Modo legado: resolve estilos imediatamente
        load_styles_now()
        style = global_styles.get(id, {})
        fg    = _get_style_fg(style)
        font  = _build_tk_font(style, default_size=14)
        _app.add_label(text, fg=fg, font=font)
        return None


def button(text, id=None, command=None, screen=None, parent=None):
    """
    Adiciona um botão à interface.

    Args:
        text:    O texto do botão.
        id:      ID para aplicar estilos CSS.
                 ex: style = \"\"\"meu_botao { background-color: blue; color: white; }\"\"\"
        command: Função a chamar ao clicar (modo legado sem Screen).
        screen:  Screen ao qual pertence (modo multi-ecrã).
        parent:  Container pai ao qual pertence (para aninhamento).

    Returns:
        ComponentDef se screen ou parent for definido — usa-o em on_click_navigate().
    """
    if parent is not None:
        comp = ComponentDef('button', text=text, command=command, comp_id=id)
        parent.children.append(comp)
        return comp
    elif screen is not None:
        # Estilos resolvidos no render (dentro de run()), não aqui
        comp = ComponentDef('button', text=text, command=command, comp_id=id)
        return screen._add(comp)
    else:
        # Modo legado: resolve estilos imediatamente
        load_styles_now()
        style      = global_styles.get(id, {})
        bg         = _get_style_bg(style)
        fg         = _get_style_fg(style)
        pressed_bg = _get_style_pressed_color(style)
        radius     = _parse_radius(style)
        bc         = _get_style_border_color(style)
        bw         = _parse_border_width(style)
        font       = _build_tk_font(style, default_size=11)
        _app.add_button(text, command, bg, fg, radius=radius, border_color=bc, border_width=bw, pressed_color=pressed_bg, font=font)
        return None


def inputs(placeholder="", id=None, type="text", screen=None, parent=None):
    """
    Adiciona um campo de input à interface.

    Tipos suportados:
      - "text"      → caixa de texto normal
      - "password"  → texto escondido com ●●●
      - "search"    → caixa de texto com botão ✕ para limpar
      - "checkbox"  → caixinha com visto (✓)
      - "range"     → slider/barra deslizante (0-100)
      - "radio"     → botões de escolha; separa opções com | no placeholder
                      ex: inputs("Sim|Não|Talvez", type="radio")

    Args:
        id:     ID para aplicar estilos CSS.
                Suporta 'background-color' e 'backgroundcolor' (sem hífen).
        screen: Screen ao qual pertence (modo multi-ecrã).
        parent: Container pai ao qual pertence (para aninhamento).
    """
    if parent is not None:
        comp = ComponentDef('inputs', placeholder=placeholder, input_type=type, comp_id=id)
        parent.children.append(comp)
        return comp
    elif screen is not None:
        # Estilos resolvidos no render (dentro de run()), não aqui
        comp = ComponentDef('inputs', placeholder=placeholder, input_type=type, comp_id=id)
        return screen._add(comp)
    else:
        # Modo legado: resolve estilos imediatamente
        load_styles_now()
        style  = global_styles.get(id, {})
        bg     = _get_style_bg(style)
        fg     = _get_style_fg(style)
        radius = _parse_radius(style)
        bc     = _get_style_border_color(style)
        bw     = _parse_border_width(style)
        fc     = _get_style_focus_border_color(style)
        font   = _build_tk_font(style, default_size=13)
        _app.add_input(placeholder=placeholder, input_type=type, bg=bg, fg=fg, radius=radius, border_color=bc, border_width=bw, focus_border_color=fc, font=font)
        return None


# Alias para quem preferir este nome
input_field = inputs


def run(start_screen=None):
    """
    Inicia a janela de preview.

    Args:
        start_screen: Screen inicial a mostrar (modo multi-ecrã).
                      Se None, mostra os componentes adicionados diretamente
                      (modo legado compatível).
    """
    load_styles_now()
    if start_screen is not None:
        _app.render_screen(start_screen)
    try:
        _app.run()
    except KeyboardInterrupt:
        pass

def toast(message):
    """Exibe uma mensagem flutuante temporária na interface."""
    lbl = tk.Label(
        _app.root, text=message, bg="#333333", fg="white",
        font=("Arial", 11), padx=15, pady=8
    )
    lbl.place(relx=0.5, rely=0.85, anchor="s")
    _app.root.after(2000, lbl.destroy)