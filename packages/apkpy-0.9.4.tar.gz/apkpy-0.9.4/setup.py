from setuptools import setup, find_packages

setup(
    name='apkpy',
    version='0.9.4', # change this version when updating
    author='Martim',
    description='A simple framework to build Android apps using Python and CSS-like styling',
    long_description=open('README.md', encoding='utf-8').read(), # ADICIONA O ENCODING AQUI
    long_description_content_type='text/markdown',
    url='https://github.com/teu-usuario/apkpy', # Se tiveres GitHub
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'click', # Dependências que a tua lib precisa
    ],
    entry_points={
        'console_scripts': [
            'apkpy=apkpy_lib.cli:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)