import unittest
from pathlib import Path

import tdir

from old.vl8.dsp.data import File
from old.vl8.dsp.grain import Grain
from old.vl8.functions.stripe import Stripe

from ..assert_files_equal import assert_files_equal

DIR = Path(__file__).parents[1] / "dsp/sources"
FILES = tuple(DIR / f"{i}.wav" for i in range(1, 4))
assert len(FILES) == 3

SAMPLE_RATE = 11025


@tdir
class TestStripe(unittest.TestCase):
    def DONT_test_123_simple(self):
        sources = [File(f) for f in FILES]
        result = Stripe(grain=Grain(duration="10ms"))(*sources)
        assert_files_equal("stripe-123.wav", result, SAMPLE_RATE)
