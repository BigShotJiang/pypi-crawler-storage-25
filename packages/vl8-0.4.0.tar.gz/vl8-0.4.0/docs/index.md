# 🔉: `vl8`: Perturbed audio 🔉

::: vl8

## More info

* [ Code ]( https://github.com/rec/vl8 )
* [ Me ]( https://github.com/rec )
* [ Sponsors ]( https://github.com/sponsors/rec )
