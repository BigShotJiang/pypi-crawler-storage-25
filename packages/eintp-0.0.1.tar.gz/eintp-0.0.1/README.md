# eintp

Einfuehrung in die neutestamentliche Philologie — Dachprojekt fuer das
Triptychon **tosion** (Engine), **horev** (Heimat) und **otzar** (Speicher).

Dies ist eine Namensreservierung. Eine inhaltliche Veroeffentlichung
folgt zu einem spaeteren Zeitpunkt.
