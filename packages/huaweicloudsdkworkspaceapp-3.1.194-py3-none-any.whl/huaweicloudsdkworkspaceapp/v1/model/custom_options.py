# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CustomOptions:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'custom_configuration1_rule': 'str',
        'rail_transparent_config': 'RailTransparentConfig'
    }

    attribute_map = {
        'custom_configuration1_rule': 'custom_configuration1_rule',
        'rail_transparent_config': 'rail_transparent_config'
    }

    def __init__(self, custom_configuration1_rule=None, rail_transparent_config=None):
        r"""CustomOptions

        The model defined in huaweicloud sdk

        :param custom_configuration1_rule: 配置项1内容。
        :type custom_configuration1_rule: str
        :param rail_transparent_config: 
        :type rail_transparent_config: :class:`huaweicloudsdkworkspaceapp.v1.RailTransparentConfig`
        """
        
        

        self._custom_configuration1_rule = None
        self._rail_transparent_config = None
        self.discriminator = None

        if custom_configuration1_rule is not None:
            self.custom_configuration1_rule = custom_configuration1_rule
        if rail_transparent_config is not None:
            self.rail_transparent_config = rail_transparent_config

    @property
    def custom_configuration1_rule(self):
        r"""Gets the custom_configuration1_rule of this CustomOptions.

        配置项1内容。

        :return: The custom_configuration1_rule of this CustomOptions.
        :rtype: str
        """
        return self._custom_configuration1_rule

    @custom_configuration1_rule.setter
    def custom_configuration1_rule(self, custom_configuration1_rule):
        r"""Sets the custom_configuration1_rule of this CustomOptions.

        配置项1内容。

        :param custom_configuration1_rule: The custom_configuration1_rule of this CustomOptions.
        :type custom_configuration1_rule: str
        """
        self._custom_configuration1_rule = custom_configuration1_rule

    @property
    def rail_transparent_config(self):
        r"""Gets the rail_transparent_config of this CustomOptions.

        :return: The rail_transparent_config of this CustomOptions.
        :rtype: :class:`huaweicloudsdkworkspaceapp.v1.RailTransparentConfig`
        """
        return self._rail_transparent_config

    @rail_transparent_config.setter
    def rail_transparent_config(self, rail_transparent_config):
        r"""Sets the rail_transparent_config of this CustomOptions.

        :param rail_transparent_config: The rail_transparent_config of this CustomOptions.
        :type rail_transparent_config: :class:`huaweicloudsdkworkspaceapp.v1.RailTransparentConfig`
        """
        self._rail_transparent_config = rail_transparent_config

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CustomOptions):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
