"""Stdlib replacement for networkx's narrow API surface.

2026-04-28 license cleanup: replaced ``networkx`` (BSD-3) with this 200-line
in-house module. We use only a tiny slice of networkx's API — Graph + DiGraph
constructors, ~12 graph methods, plus :func:`shortest_path` for SPO traversal
queries. The full networkx wheel is ~30 MB of code we don't run.

API parity with networkx (the bits we use):

* :class:`Graph` — undirected graph with adjacency-dict storage. Edge attrs
  are stored as a SHARED dict between the two adjacency entries, so
  ``g.edges[u, v]["weight"] = 5`` is visible via ``g.edges[v, u]["weight"]``.
* :class:`DiGraph` — directed graph with separate forward + reverse adjacency.
* :func:`shortest_path` — unweighted BFS shortest path. Raises
  :class:`NodeNotFound` on missing source/target, :class:`NetworkXError`
  when no path exists.
* Both graph classes expose a ``nodes`` view and an ``edges`` view that
  support iteration AND ``g.nodes[name]`` indexing AND ``g.nodes(data=True)``
  callable-form-with-attrs. This is networkx's idiom; our :class:`_NodeView`
  and :class:`_EdgeView` mirror it.

Locked by the existing :mod:`agntspace.memory.graph` test suite — running
the memory tests against this module without other changes is the
canonical regression check.

NOT supported (we don't use them, by design):

* MultiGraph / MultiDiGraph — parallel edges
* Weighted shortest paths (Dijkstra / Bellman-Ford / A*)
* Graph algorithms beyond BFS (PageRank, centrality, components)
* Reading from / writing to file formats (GraphML, GEXF, etc.)
* Subgraph / induced subgraph / disjoint union

If you find yourself needing one of these, that's a signal — either pull
in a focused MIT graph library or extend this module. Don't reach for
networkx.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Iterator
from copy import deepcopy
from typing import Any


class NetworkXError(Exception):
    """Base error matching ``networkx.NetworkXError`` shape."""


class NodeNotFound(NetworkXError):
    """Raised by :func:`shortest_path` when source or target is missing."""


class _NodeView:
    """View object backing both ``g.nodes`` iteration AND ``g.nodes[name]``
    attr lookup AND ``g.nodes(data=True)`` callable form.

    networkx packs all three behaviors into one object — we mirror that
    so call-site code reads identically.
    """

    __slots__ = ("_parent",)

    def __init__(self, parent: Graph) -> None:
        self._parent = parent

    def __iter__(self) -> Iterator[str]:
        return iter(self._parent._node_attrs)

    def __contains__(self, name: object) -> bool:
        return name in self._parent._node_attrs

    def __len__(self) -> int:
        return len(self._parent._node_attrs)

    def __getitem__(self, name: str) -> dict[str, Any]:
        attrs = self._parent._node_attrs.get(name)
        if attrs is None:
            raise KeyError(name)
        return attrs

    def __call__(self, data: bool = False) -> Any:
        if data:
            return [(n, attrs) for n, attrs in self._parent._node_attrs.items()]
        return list(self._parent._node_attrs)


class _EdgeView:
    """View object backing ``g.edges`` iteration AND ``g.edges[u, v]``
    indexing AND ``g.edges(data=True)`` callable form AND
    ``g.edges.get((u, v), default)`` get-with-default.

    For undirected graphs, ``g.edges[u, v]`` and ``g.edges[v, u]`` return
    the SAME dict (set during ``add_edge``). For DiGraph, ``g.edges[u, v]``
    looks up the forward edge only.
    """

    __slots__ = ("_parent",)

    def __init__(self, parent: Graph) -> None:
        self._parent = parent

    def __iter__(self) -> Iterator[tuple[str, str]]:
        return self._parent._iter_edges()

    def __getitem__(self, key: tuple[str, str]) -> dict[str, Any]:
        u, v = key
        attrs = self._parent._lookup_edge_attrs(u, v)
        if attrs is None:
            raise KeyError(key)
        return attrs

    def get(self, key: tuple[str, str], default: Any = None) -> Any:
        u, v = key
        attrs = self._parent._lookup_edge_attrs(u, v)
        return default if attrs is None else attrs

    def __call__(self, data: bool = False) -> Any:
        if data:
            out: list[tuple[str, str, dict[str, Any]]] = []
            for u, v in self._parent._iter_edges():
                attrs = self._parent._lookup_edge_attrs(u, v)
                out.append((u, v, attrs if attrs is not None else {}))
            return out
        return list(self._parent._iter_edges())


class Graph:
    """Undirected graph with adjacency-dict storage.

    Edge attrs are stored as a single dict referenced by both
    ``_adj[u][v]`` and ``_adj[v][u]`` so updates via either direction are
    visible from the other. Matches networkx's behavior exactly.
    """

    def __init__(self) -> None:
        # node → attrs dict
        self._node_attrs: dict[str, dict[str, Any]] = {}
        # node → {neighbor: shared_attrs_dict}
        self._adj: dict[str, dict[str, dict[str, Any]]] = {}
        self.nodes = _NodeView(self)
        self.edges = _EdgeView(self)

    def __contains__(self, name: object) -> bool:
        return name in self._node_attrs

    def __len__(self) -> int:
        return len(self._node_attrs)

    def __getitem__(self, name: str) -> dict[str, dict[str, Any]]:
        """Return ``g[node]`` adjacency map → ``{neighbor: edge_attrs}``.

        networkx exposes this so call sites can chain
        ``g[u][v]["weight"]`` to read or mutate edge attrs without going
        through ``g.edges[u, v]``. We return the live adjacency dict —
        mutations propagate, matching networkx's view semantics.
        """
        adj = self._adj.get(name)
        if adj is None:
            raise KeyError(name)
        return adj

    def add_node(self, name: str, **attrs: Any) -> None:
        if name in self._node_attrs:
            self._node_attrs[name].update(attrs)
        else:
            self._node_attrs[name] = dict(attrs)
            self._adj[name] = {}

    def add_edge(self, u: str, v: str, **attrs: Any) -> None:
        if u not in self._node_attrs:
            self.add_node(u)
        if v not in self._node_attrs:
            self.add_node(v)
        if v in self._adj[u]:
            self._adj[u][v].update(attrs)
        else:
            shared = dict(attrs)
            self._adj[u][v] = shared
            self._adj[v][u] = shared  # same reference — undirected

    def has_node(self, name: str) -> bool:
        return name in self._node_attrs

    def has_edge(self, u: str, v: str) -> bool:
        adj_u = self._adj.get(u)
        return adj_u is not None and v in adj_u

    def remove_node(self, name: str) -> None:
        if name not in self._node_attrs:
            raise NetworkXError(f"node {name!r} not in graph")
        # Remove this node from every neighbor's adjacency
        for neighbor in list(self._adj[name]):
            del self._adj[neighbor][name]
        del self._adj[name]
        del self._node_attrs[name]

    def neighbors(self, name: str) -> Iterator[str]:
        if name not in self._adj:
            raise NetworkXError(f"node {name!r} not in graph")
        return iter(self._adj[name])

    def degree(self, name: str) -> int:
        adj = self._adj.get(name)
        return len(adj) if adj is not None else 0

    def number_of_nodes(self) -> int:
        return len(self._node_attrs)

    def number_of_edges(self) -> int:
        # Each undirected edge appears twice in adjacency; halve.
        return sum(len(adj) for adj in self._adj.values()) // 2

    def get_edge_data(self, u: str, v: str) -> dict[str, Any] | None:
        adj_u = self._adj.get(u)
        if adj_u is None:
            return None
        return adj_u.get(v)

    def copy(self) -> Graph:
        new = type(self)()
        for n, attrs in self._node_attrs.items():
            new.add_node(n, **deepcopy(attrs))
        # Iterate edges in canonical (u≤v) form so each is added once.
        for u, v in self._iter_edges():
            attrs = self._adj[u][v]
            new.add_edge(u, v, **deepcopy(attrs))
        return new

    def clear(self) -> None:
        self._node_attrs.clear()
        self._adj.clear()

    # ── Internal helpers used by views + shortest_path ────────────

    def _iter_edges(self) -> Iterator[tuple[str, str]]:
        """Yield each undirected edge exactly once.

        Canonicalizes by string-sorting the endpoints so both
        ``(a, b)`` and ``(b, a)`` collapse to ``(a, b)``.
        """
        seen: set[tuple[str, str]] = set()
        for u, adj in self._adj.items():
            for v in adj:
                key = (u, v) if u <= v else (v, u)
                if key in seen:
                    continue
                seen.add(key)
                yield key

    def _lookup_edge_attrs(self, u: str, v: str) -> dict[str, Any] | None:
        adj_u = self._adj.get(u)
        if adj_u is None:
            return None
        return adj_u.get(v)


class DiGraph(Graph):
    """Directed graph — separate forward (`_adj`) and reverse (`_pred`) maps.

    Edge attrs are stored once and shared between ``_adj[u][v]`` and
    ``_pred[v][u]`` so updates via either path are visible. Forward-edge
    iteration is the canonical direction.
    """

    def __init__(self) -> None:
        super().__init__()
        # predecessor adjacency: node → {predecessor: shared_attrs_dict}
        self._pred: dict[str, dict[str, dict[str, Any]]] = {}

    def add_node(self, name: str, **attrs: Any) -> None:
        if name in self._node_attrs:
            self._node_attrs[name].update(attrs)
        else:
            self._node_attrs[name] = dict(attrs)
            self._adj[name] = {}
            self._pred[name] = {}

    def add_edge(self, u: str, v: str, **attrs: Any) -> None:
        if u not in self._node_attrs:
            self.add_node(u)
        if v not in self._node_attrs:
            self.add_node(v)
        if v in self._adj[u]:
            self._adj[u][v].update(attrs)
        else:
            shared = dict(attrs)
            self._adj[u][v] = shared
            self._pred[v][u] = shared

    def has_edge(self, u: str, v: str) -> bool:
        adj_u = self._adj.get(u)
        return adj_u is not None and v in adj_u

    def remove_node(self, name: str) -> None:
        if name not in self._node_attrs:
            raise NetworkXError(f"node {name!r} not in graph")
        # Forward edges out of `name`: remove from each successor's _pred
        for v in list(self._adj[name]):
            del self._pred[v][name]
        # Reverse edges into `name`: remove from each predecessor's _adj
        for u in list(self._pred[name]):
            del self._adj[u][name]
        del self._adj[name]
        del self._pred[name]
        del self._node_attrs[name]

    def neighbors(self, name: str) -> Iterator[str]:
        # networkx semantics: DiGraph.neighbors == successors
        if name not in self._adj:
            raise NetworkXError(f"node {name!r} not in graph")
        return iter(self._adj[name])

    def number_of_edges(self) -> int:
        # Directed: count once per forward edge — no halving.
        return sum(len(adj) for adj in self._adj.values())

    def to_undirected(self) -> Graph:
        """Return an undirected :class:`Graph` with the same nodes + edges.

        When both u→v and v→u exist with different attrs, the FIRST one
        seen wins (matches networkx's default `as_view=False` behavior).
        """
        g = Graph()
        for n, attrs in self._node_attrs.items():
            g.add_node(n, **deepcopy(attrs))
        for u, adj in self._adj.items():
            for v, attrs in adj.items():
                if not g.has_edge(u, v):
                    g.add_edge(u, v, **deepcopy(attrs))
        return g

    def copy(self) -> DiGraph:
        new = DiGraph()
        for n, attrs in self._node_attrs.items():
            new.add_node(n, **deepcopy(attrs))
        for u, adj in self._adj.items():
            for v, attrs in adj.items():
                new.add_edge(u, v, **deepcopy(attrs))
        return new

    def clear(self) -> None:
        self._node_attrs.clear()
        self._adj.clear()
        self._pred.clear()

    def _iter_edges(self) -> Iterator[tuple[str, str]]:
        """Yield each forward edge exactly once."""
        for u, adj in self._adj.items():
            for v in adj:
                yield (u, v)


def shortest_path(graph: Graph, source: str, target: str) -> list[str]:
    """Unweighted BFS shortest path between ``source`` and ``target``.

    Returns a list of nodes from source to target inclusive. Raises
    :class:`NodeNotFound` when source or target is missing, and
    :class:`NetworkXError` when no path exists. Mirrors the
    ``networkx.shortest_path`` behavior we use in
    :mod:`agntspace.memory.graph`.
    """
    if source not in graph._node_attrs:
        raise NodeNotFound(f"source node {source!r} not in graph")
    if target not in graph._node_attrs:
        raise NodeNotFound(f"target node {target!r} not in graph")
    if source == target:
        return [source]

    # Predecessor map for path reconstruction. Visiting `source` first
    # marks it with predecessor None to terminate the walk-back.
    visited: dict[str, str | None] = {source: None}
    queue: deque[str] = deque([source])
    while queue:
        node = queue.popleft()
        for neighbor in graph._adj.get(node, {}):
            if neighbor in visited:
                continue
            visited[neighbor] = node
            if neighbor == target:
                # Reconstruct path by walking the predecessor chain.
                path: list[str] = [target]
                cur: str | None = node
                while cur is not None:
                    path.append(cur)
                    cur = visited[cur]
                path.reverse()
                return path
            queue.append(neighbor)
    raise NetworkXError(f"no path between {source!r} and {target!r}")
