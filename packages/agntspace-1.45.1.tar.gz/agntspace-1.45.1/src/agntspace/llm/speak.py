"""Chat-facing text-to-speech synthesis.

Lightweight audio-output path for the chat UI's "play this reply" button.
Routes through :func:`agntspace.video.tts.synthesize_scene` (piper-tts → pyttsx3
chain — both MIT/MPL-licensed) to a temp directory, then reads the produced
MP3 back as bytes for streaming to the client.

2026-04-28 cleanup: removed the direct ``edge_tts`` (GPL-3.0) dependency. The
chat TTS surface now uses the same MIT/MPL-licensed providers as video TTS,
so chat works wherever video works (no extra deps).
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import uuid

from agntspace.infra.config import get_settings
from agntspace.video.tts import (
    TTSProviderUnavailable,
    sanitize_for_tts,
    synthesize_scene,
)

log = logging.getLogger(__name__)

# Synthesis hard cap. piper-tts can handle far more, but ~4 KB of text is
# already ~30 seconds of audio — anything bigger is almost always a
# pasted document, not a chat reply, and we'd rather refuse fast than
# burn time generating audio nobody listens to all the way through.
MAX_TEXT_CHARS = 4000

# 25 second per-call timeout — typical replies generate in <2s; anything
# beyond 25s indicates the upstream is wedged and we should fail fast so
# the UI can surface the error.
SYNTHESIS_TIMEOUT_SECONDS = 25.0

# Default voice — neutral logical name resolved by styles.yaml's voice map
# (piper voice "liam" → en_US-ryan-high). Callers may pass any voice label
# the active provider knows about.
DEFAULT_VOICE = "liam"


class TTSUnavailable(RuntimeError):
    """Raised when no TTS provider can satisfy the request.

    The route handler maps this to a 503 with a concrete remediation hint
    (e.g. ``pip install agntspace[video]`` for piper-tts).
    """

    def __init__(self, message: str, *, install_hint: str = "") -> None:
        super().__init__(message)
        self.install_hint = install_hint


async def synthesize(text: str, *, voice: str = DEFAULT_VOICE) -> bytes:
    """Synthesize ``text`` to MP3 bytes using the first available provider.

    Returns the full MP3 payload as bytes (callers can stream it). Raises
    :class:`TTSUnavailable` when no provider is installed or the upstream
    refuses the request. Sanitization (em-dash, AGNT, AI → A.I., …) is
    applied before the provider sees the text.
    """
    cleaned = sanitize_for_tts(text or "").strip()
    if not cleaned:
        raise TTSUnavailable("Empty text after sanitization")
    if len(cleaned) > MAX_TEXT_CHARS:
        cleaned = cleaned[:MAX_TEXT_CHARS]
    try:
        return await asyncio.wait_for(
            _synthesize_via_video_tts(cleaned, voice=voice),
            timeout=SYNTHESIS_TIMEOUT_SECONDS,
        )
    except TimeoutError as exc:
        raise TTSUnavailable("TTS synthesis timed out") from exc


async def _synthesize_via_video_tts(text: str, *, voice: str) -> bytes:
    """Run text through video.tts.synthesize_scene to a temp dir, return bytes.

    Provider chain (piper-tts → pyttsx3) is loaded from the video-producer
    skill's styles.yaml — same source of truth as video voice-over. Cleans
    up the temp file regardless of outcome.
    """
    # Per-call temp dir under the app cache so concurrent requests don't
    # clobber each other. UUID4 keeps collisions effectively impossible.
    cache_root = get_settings().app_dir / "cache" / "tts"
    scene_dir = cache_root / uuid.uuid4().hex
    try:
        result = await synthesize_scene(
            scene_id="chat",
            text=text,
            voice=voice,
            output_dir=scene_dir,
            skill_loader=None,  # falls back to FALLBACK_CHAIN
        )
    except TTSProviderUnavailable as exc:
        # Surface install hint pointing at the [video] extra (which now
        # includes piper-tts as the MIT-licensed primary provider).
        raise TTSUnavailable(
            "TTS unavailable — install 'pip install agntspace[video]' for piper-tts",
            install_hint="pip install agntspace[video]",
        ) from exc
    except Exception as exc:
        # Map every other failure to TTSUnavailable so the route handler
        # returns a single shape — "TTS failed: <reason>" — that the UI
        # can render as a single error path.
        raise TTSUnavailable(f"TTS synthesis failed: {exc}") from exc

    if result.provider_used == "empty" or not result.path or not result.path.exists():
        # synthesize_scene returns an empty result for empty text (we already
        # rejected above) or a None-path provider miss. Either way: no audio.
        raise TTSUnavailable("TTS synthesis produced no audio")

    try:
        return result.path.read_bytes()
    finally:
        # Best-effort cleanup. Failures here are benign — the whole tree
        # is in the app cache and will be reaped on next boot.
        try:
            if scene_dir.exists():
                shutil.rmtree(scene_dir, ignore_errors=True)
        except Exception:
            log.debug("temp-dir cleanup failed for %s", scene_dir, exc_info=True)
