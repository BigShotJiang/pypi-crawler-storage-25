"""Deployment mode — the user-facing 3-value picker for cloud/hybrid/local.

The system has two underlying knobs that control where LLM calls go:

  - ``[llm] mode = "cloud" | "local"`` in config.toml — picks the default
    provider for top-tier work.
  - ``routing.cloud_use_local_for_tiers: list[str]`` in models.yaml — even
    when ``mode=cloud``, sends specific tiers to local Ollama (cost saver).

Combined, three sensible user-facing modes emerge:

  - ``pure_cloud`` — mode=cloud, routing list empty. Every call goes cloud.
  - ``hybrid``     — mode=cloud, routing list has at least "fast". Background
                     fast-tier calls (briefings, journal compactions, titles)
                     run on local Ollama; capable+reasoning stay cloud.
  - ``pure_local`` — mode=local. Every call goes to local Ollama regardless
                     of routing list (routing is moot in local mode).

This module is the ONE place that maps between the two underlying knobs and
the user-facing 3-value picker. The Settings UI calls ``set_deployment_mode``;
the API surfaces ``deployment_mode_from_settings`` so the UI can render the
current pill state.

Power users editing models.yaml directly can still write any tier list they
want (e.g. ``["fast", "capable"]``); the derivation falls through to ``hybrid``
for any non-empty list — we don't try to round-trip arbitrary lists through
the 3-pill picker.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


# arch:deterministic — the three user-facing modes are an architectural set,
# not a tunable strategy. Adding a fourth would require UI + API + docs work
# AND a fourth distinct combination of (mode, routing) that produces a
# meaningfully different UX.
PURE_CLOUD = "pure_cloud"
HYBRID = "hybrid"
PURE_LOCAL = "pure_local"
VALID_MODES: frozenset[str] = frozenset({PURE_CLOUD, HYBRID, PURE_LOCAL})

# Default hybrid tier set — what gets routed to local when the user picks
# ``hybrid``. Mirrors the bundled models.yaml default. Adding more tiers here
# would push more work to local — generally a bad idea given local 7B models'
# weak classification quality. ``fast`` is the safe baseline.
HYBRID_DEFAULT_TIERS: tuple[str, ...] = ("fast",)


def deployment_mode_from_settings(
    llm_mode: str,
    cloud_use_local_for_tiers: list[str] | tuple[str, ...] | frozenset[str] | None,
) -> str:
    """Derive the user-facing deployment_mode from the two underlying knobs.

    >>> deployment_mode_from_settings("local", [])
    'pure_local'
    >>> deployment_mode_from_settings("local", ["fast"])
    'pure_local'
    >>> deployment_mode_from_settings("cloud", [])
    'pure_cloud'
    >>> deployment_mode_from_settings("cloud", None)
    'pure_cloud'
    >>> deployment_mode_from_settings("cloud", ["fast"])
    'hybrid'
    >>> deployment_mode_from_settings("cloud", ["fast", "capable"])
    'hybrid'
    """
    if (llm_mode or "").strip().lower() == "local":
        return PURE_LOCAL
    tiers = cloud_use_local_for_tiers or []
    return HYBRID if list(tiers) else PURE_CLOUD


def hybrid_tiers_for_mode(mode: str) -> list[str]:
    """Return the routing tier list to write for a given deployment_mode.

    ``hybrid`` writes the default tier set. ``pure_cloud`` writes empty.
    ``pure_local`` writes empty (routing is moot in local mode but we
    normalize the file so a later switch back to cloud doesn't inherit
    a stale list).

    >>> hybrid_tiers_for_mode("pure_cloud")
    []
    >>> hybrid_tiers_for_mode("hybrid")
    ['fast']
    >>> hybrid_tiers_for_mode("pure_local")
    []
    """
    if mode == HYBRID:
        return list(HYBRID_DEFAULT_TIERS)
    return []


def llm_mode_for_deployment(mode: str) -> str:
    """Map deployment_mode → underlying ``[llm] mode`` value.

    >>> llm_mode_for_deployment("pure_cloud")
    'cloud'
    >>> llm_mode_for_deployment("hybrid")
    'cloud'
    >>> llm_mode_for_deployment("pure_local")
    'local'
    """
    return "local" if mode == PURE_LOCAL else "cloud"


def write_routing_to_models_yaml(
    skills_dir: Path,
    tiers: list[str],
    *,
    honor_prefer_local: bool | None = None,
) -> bool:
    """Write the routing block to ``<skills_dir>/_meta/model-routing/config/models.yaml``.

    Reads the existing file, updates ONLY the ``routing:`` block (preserves
    profiles, capabilities, comments at the top of the file are lost — the
    pyyaml round-trip strips them). Creates parent directories if missing
    so a freshly-installed vault without the override file gets one.

    Returns True on success, False on any failure (caller decides whether
    a failed write should surface to the user — typically a UI toast).

    The honor_prefer_local flag is preserved when not explicitly passed —
    we don't want one Settings change to silently flip it.
    """
    try:
        import yaml
    except Exception:
        log.error("PyYAML not available — cannot write routing config")
        return False

    if not skills_dir:
        log.warning("No skills_dir provided — cannot write routing config")
        return False

    models_path = skills_dir / "_meta" / "model-routing" / "config" / "models.yaml"
    data: dict[str, Any] = {}

    if models_path.is_file():
        try:
            data = yaml.safe_load(models_path.read_text(encoding="utf-8")) or {}
        except Exception as e:
            log.error("Failed to read existing models.yaml: %s — refusing to overwrite", e)
            return False

    routing = data.get("routing", {}) or {}
    routing["cloud_use_local_for_tiers"] = list(tiers)
    if honor_prefer_local is not None:
        routing["honor_prefer_local"] = bool(honor_prefer_local)
    data["routing"] = routing

    try:
        models_path.parent.mkdir(parents=True, exist_ok=True)
        # default_flow_style=False keeps the file in human-readable block form,
        # not the inline "{a: 1, b: 2}" YAML that's hard to diff.
        models_path.write_text(
            yaml.safe_dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        log.info("Wrote routing config to %s: tiers=%s", models_path, tiers)
        return True
    except Exception as e:
        log.error("Failed to write models.yaml at %s: %s", models_path, e)
        return False


def read_routing_tiers(skills_dir: Path) -> list[str]:
    """Read the current routing tier list from models.yaml.

    Returns [] when the file is missing, malformed, or has no routing block.
    Always returns a list, never raises.
    """
    if not skills_dir:
        return []

    try:
        import yaml
    except Exception:
        return []

    models_path = skills_dir / "_meta" / "model-routing" / "config" / "models.yaml"
    if not models_path.is_file():
        return []

    try:
        data = yaml.safe_load(models_path.read_text(encoding="utf-8")) or {}
        routing = data.get("routing", {}) or {}
        tiers = routing.get("cloud_use_local_for_tiers", []) or []
        return [str(t).strip().lower() for t in tiers if t]
    except Exception:
        return []
