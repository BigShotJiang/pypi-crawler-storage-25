"""Taxonomy orphan-cluster detector — proactive proposal of missing L2/L3
nodes when articles cluster on undeclared paths.

**The gap this closes**: AgntSpace's philosopher agent has the *mouth*
to propose taxonomy nodes (``update_taxonomy(propose_node, ...)``) but
no *eyes* to detect when a proposal is warranted. Articles can drift to
``taxonomy_path`` values that no YAML tree node owns
(e.g. ``knowledge/general``, ``knowledge/risk-safety``) — those articles
become invisible in the wiki tree count even though their files are on
disk and fully classified.

Without a detector, the user has to spot the discrepancy AND ask the
agent to propose; this module closes the eyes-mouth loop so the agent
surfaces clusters automatically.

**How it works**:

1. Walk every wiki article's ``taxonomy_path`` frontmatter.
2. For each path, find the *deepest* segment that the YAML tree owns,
   then identify the FIRST orphan segment after it.
   - ``knowledge/general/dam-safety`` with YAML having
     ``knowledge/<no general>`` → orphan = ``knowledge/general``
   - ``knowledge/engineering/hydrology`` (full match in YAML) → no orphan
3. Group articles by their orphan-bearing path prefix.
4. Clusters with ≥ ``min_cluster_size`` articles become proposals.
5. Each proposal carries a deterministic id keyed by the orphan path,
   so re-running this detector idempotently overwrites prior proposals
   (no proposal pile-up).

**Engine vs strategy split** (Rule 12):

The thresholds, cooldown, and skill metadata live in
``defaults/skills/_meta/taxonomy-orphan-detect/config/orphan.yaml``.
This module is pure mechanics — the YAML decides when to fire.

**Heartbeat integration**: ``automation/heartbeat.py`` calls
``TaxonomyOrphanDetector.detect_and_propose()`` daily (cadence from
YAML). Pure frontmatter scan — no LLM, no expensive ops.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agntspace.kb.taxonomy import (
    FIXED_L1_SLUGS,
    LEGACY_L1_ALIASES,
    flatten_taxonomy,
)
from agntspace.kb.taxonomy_proposals import (
    _stable_proposal_id,
    list_pending,
    write_proposal,
)

log = logging.getLogger(__name__)


@dataclass
class OrphanCluster:
    """One cluster of articles that all share an undeclared
    ``taxonomy_path`` prefix.

    ``path`` is the proposal target — the orphan segment chain *under* a
    known ancestor (e.g. ``knowledge/general`` when knowledge is in the
    tree but general isn't). ``parent_in_tree`` is the deepest YAML node
    above the orphan ("knowledge" in the example above).
    """

    path: str  # the proposed-node path, e.g. "knowledge/general"
    parent_in_tree: str  # deepest YAML node above orphan, e.g. "knowledge"
    article_count: int
    sample_titles: list[str] = field(default_factory=list)

    def proposed_name(self) -> str:
        """Human-friendly name from the orphan slug."""
        last = self.path.split("/")[-1]
        # "risk-safety" → "Risk Safety"; "general" → "General"
        return last.replace("-", " ").replace("_", " ").title()

    def proposed_description(self) -> str:
        return (
            f"Auto-detected from {self.article_count} articles already classified "
            f"at this path. Detected by the taxonomy orphan-cluster detector."
        )

    def proposed_rationale(self) -> str:
        sample = ", ".join(f'"{t}"' for t in self.sample_titles[:3])
        return (
            f"{self.article_count} articles in your vault already classify "
            f"into ``{self.path}``, but this node is not declared in the "
            f"taxonomy YAML. Approving makes those articles visible in the "
            f"wiki tree under ``{self.parent_in_tree}``. Examples: {sample}."
        )


# ── Pure helpers (testable in isolation) ──────────────────────────────


def _build_known_path_set(flat_nodes: list[dict]) -> set[str]:
    """Collect every full slug-path the YAML tree declares (any depth)."""
    paths: set[str] = set()
    for n in flat_nodes:
        full = (n.get("path") or "").strip("/")
        if full:
            paths.add(full)
    return paths


def _normalize_taxonomy_path(value: str) -> str:
    """Apply LEGACY_L1_ALIASES + strip leading/trailing slashes so the
    orphan detector treats the post-migration form for legacy paths.

    A pre-migration article with ``taxonomy_path: sources/articles/news``
    is already considered as ``digests/articles/news`` for orphan scan
    purposes — otherwise we'd churn proposals for legacy paths the
    migration is about to rewrite anyway.
    """
    clean = (value or "").strip().strip("/").replace("\\", "/")
    if not clean:
        return ""
    head = clean.split("/", 1)[0]
    new_head = LEGACY_L1_ALIASES.get(head)
    if new_head:
        tail = clean[len(head):]  # includes leading "/"
        return new_head + tail
    return clean


def find_orphan_clusters(
    articles: list[dict],
    flat_nodes: list[dict],
    *,
    min_cluster_size: int = 5,
    sample_titles_count: int = 3,
) -> list[OrphanCluster]:
    """Group articles by their orphan-bearing taxonomy_path prefix.

    Args:
        articles: list of dicts with at least ``taxonomy_path`` and
            ``title`` keys (typically from the wiki article cache).
        flat_nodes: result of ``flatten_taxonomy(load_taxonomy(...))``.
        min_cluster_size: clusters with fewer articles are dropped.
        sample_titles_count: how many example titles to attach per cluster
            for the rationale.

    Returns:
        Newest first: clusters sorted by ``article_count`` descending.
        Each cluster has a deterministic identity (its ``path``).
    """
    known_paths = _build_known_path_set(flat_nodes)
    # The L1 slugs are always known (they're in flat_nodes by definition).
    # Belt + braces.
    known_paths.update(FIXED_L1_SLUGS)

    # path -> [titles]
    cluster_titles: dict[str, list[str]] = {}
    cluster_parents: dict[str, str] = {}

    for art in articles:
        raw_tp = art.get("taxonomy_path", "")
        if not isinstance(raw_tp, str) or not raw_tp.strip():
            continue
        tp = _normalize_taxonomy_path(raw_tp)
        if not tp or "/" not in tp:
            # Single-segment paths (just an L1) are never orphans —
            # the L1 set is locked + always present in the tree.
            continue

        # Walk segments, find the first orphan
        segments = tp.split("/")
        if segments[0] not in FIXED_L1_SLUGS:
            # Path starts with something not in the locked L1 set. The
            # rewriter or repair step should normalize this; orphan
            # detector ignores it (proposing a new L1 isn't allowed).
            continue

        # Build candidate ancestor paths and find deepest known.
        deepest_known_idx = 0
        candidate = segments[0]
        for i, seg in enumerate(segments[1:], start=1):
            candidate = f"{candidate}/{seg}"
            if candidate in known_paths:
                deepest_known_idx = i
            else:
                break

        # Orphan starts at deepest_known_idx + 1
        if deepest_known_idx >= len(segments) - 1:
            # Whole path is in tree — not orphan.
            continue

        # The proposal target: parent + first orphan segment (L2 or L3).
        # We propose ONE level at a time — always at depth (deepest_known_idx + 1).
        proposal_path = "/".join(segments[: deepest_known_idx + 2])
        parent_path = "/".join(segments[: deepest_known_idx + 1])

        # taxonomy_proposals.validate_proposal_path enforces ≤3 segments.
        # Don't propose an L4+ here — the immediate L2/L3 is enough.
        if proposal_path.count("/") >= 3:
            # 3+ slashes means 4+ segments, not allowed
            continue

        cluster_titles.setdefault(proposal_path, [])
        cluster_parents[proposal_path] = parent_path
        title = (art.get("title") or art.get("slug") or "").strip()
        if title and len(cluster_titles[proposal_path]) < sample_titles_count:
            cluster_titles[proposal_path].append(title)
        # Always increment count regardless of whether we kept a sample title.

    # Now count + filter
    clusters: list[OrphanCluster] = []
    # Re-walk to count properly (above only added title sample, didn't
    # tally count yet).
    cluster_counts: dict[str, int] = {}
    for art in articles:
        raw_tp = art.get("taxonomy_path", "")
        if not isinstance(raw_tp, str) or not raw_tp.strip():
            continue
        tp = _normalize_taxonomy_path(raw_tp)
        if not tp or "/" not in tp:
            continue
        segments = tp.split("/")
        if segments[0] not in FIXED_L1_SLUGS:
            continue
        deepest_known_idx = 0
        candidate = segments[0]
        for i, seg in enumerate(segments[1:], start=1):
            candidate = f"{candidate}/{seg}"
            if candidate in known_paths:
                deepest_known_idx = i
            else:
                break
        if deepest_known_idx >= len(segments) - 1:
            continue
        proposal_path = "/".join(segments[: deepest_known_idx + 2])
        if proposal_path.count("/") >= 3:
            continue
        cluster_counts[proposal_path] = cluster_counts.get(proposal_path, 0) + 1

    for path, count in cluster_counts.items():
        if count < min_cluster_size:
            continue
        clusters.append(OrphanCluster(
            path=path,
            parent_in_tree=cluster_parents.get(path, path.rsplit("/", 1)[0]),
            article_count=count,
            sample_titles=cluster_titles.get(path, []),
        ))

    clusters.sort(key=lambda c: c.article_count, reverse=True)
    return clusters


# ── Service ─────────────────────────────────────────────────────────


class TaxonomyOrphanDetector:
    """Heartbeat-driven detector. Construct once at boot, call
    ``detect_and_propose()`` periodically.

    Each call:
        1. Loads the current wiki article list (caller-supplied loader)
        2. Loads the YAML taxonomy
        3. Finds orphan clusters above ``min_cluster_size``
        4. Writes a proposal per cluster (deterministic id → idempotent
           overwrite of stale proposals)
        5. Skips if a pending proposal already exists with the same id
           AND ``skip_if_pending=True`` (default)

    **Stateless** — no in-process state to worry about. Re-running with
    no changes is a no-op.
    """

    def __init__(
        self,
        vault_dir: Path,
        skills_dir: Path,
        article_loader,  # callable: () -> list[dict]
        *,
        config: dict | None = None,
    ):
        self._vault_dir = Path(vault_dir)
        self._skills_dir = Path(skills_dir)
        self._article_loader = article_loader
        self._config = dict(config or {})
        self._activity = None  # set externally
        self._decisions = None  # set externally

    # ── public API ──────────────────────────────────────────────────

    @property
    def min_cluster_size(self) -> int:
        return int(self._config.get("min_cluster_size", 5))

    @property
    def sample_titles_count(self) -> int:
        return int(self._config.get("sample_titles_count", 3))

    @property
    def skip_if_pending(self) -> bool:
        return bool(self._config.get("skip_if_pending", True))

    @property
    def cadence_hours(self) -> int:
        return int(self._config.get("cadence_hours", 24))

    @property
    def enabled(self) -> bool:
        return bool(self._config.get("enabled", True))

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan. Returns a structured report.

        The implementation is sync at heart but async-friendly so it can
        be awaited from the heartbeat loop without blocking other
        detectors.
        """
        if not self.enabled:
            return {
                "skipped": "disabled",
                "scanned": 0,
                "clusters_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        from agntspace.kb.taxonomy import load_taxonomy

        try:
            articles = self._article_loader() or []
        except Exception as exc:
            log.exception("orphan detector: article loader failed: %s", exc)
            return {
                "error": f"article_loader: {exc}",
                "scanned": 0, "clusters_found": 0,
                "proposals_written": 0, "skipped_dedup": 0,
            }

        try:
            tree = load_taxonomy(self._skills_dir, vault_dir=self._vault_dir)
        except Exception as exc:
            log.exception("orphan detector: taxonomy load failed: %s", exc)
            return {
                "error": f"load_taxonomy: {exc}",
                "scanned": len(articles), "clusters_found": 0,
                "proposals_written": 0, "skipped_dedup": 0,
            }

        flat_nodes = flatten_taxonomy(tree)
        clusters = find_orphan_clusters(
            articles, flat_nodes,
            min_cluster_size=self.min_cluster_size,
            sample_titles_count=self.sample_titles_count,
        )

        # Existing pending proposals — for dedup
        existing_ids: set[str] = set()
        if self.skip_if_pending:
            try:
                for p in list_pending(self._vault_dir):
                    existing_ids.add(p.proposal_id)
            except Exception:
                # If we can't read pending, fall through and write —
                # write_proposal's atomic-replace handles overwrite.
                pass

        proposals_written = 0
        skipped_dedup = 0
        proposal_records: list[dict] = []
        write_errors: list[dict] = []

        for cluster in clusters:
            stable_id = _stable_proposal_id(cluster.path)
            if self.skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue
            proposal, err = write_proposal(
                self._vault_dir,
                path=cluster.path,
                name=cluster.proposed_name(),
                description=cluster.proposed_description(),
                rationale=cluster.proposed_rationale(),
                proposed_by="taxonomy-orphan-detector",
                examples=list(cluster.sample_titles),
            )
            if proposal is None:
                write_errors.append({
                    "path": cluster.path,
                    "article_count": cluster.article_count,
                    "error": err,
                })
                continue
            proposals_written += 1
            proposal_records.append({
                "path": cluster.path,
                "article_count": cluster.article_count,
                "proposal_id": proposal.proposal_id,
                "name": proposal.name,
            })

        # Activity event (Rule #13).
        if self._activity is not None and (proposals_written or skipped_dedup):
            try:
                await self._activity.log(
                    category="knowledge",
                    action="taxonomy_orphan_proposals",
                    summary=(
                        f"Detected {len(clusters)} orphan cluster(s); "
                        f"wrote {proposals_written} proposal(s), "
                        f"skipped {skipped_dedup} already-pending."
                    ),
                    details={
                        "scanned_articles": len(articles),
                        "clusters_found": len(clusters),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "min_cluster_size": self.min_cluster_size,
                        "proposals": proposal_records[:20],  # cap event size
                        "write_errors": write_errors[:5],
                    },
                    importance="medium" if proposals_written else "low",
                )
            except Exception:
                pass  # never break the loop

        return {
            "scanned": len(articles),
            "clusters_found": len(clusters),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "proposals": proposal_records,
            "write_errors": write_errors,
        }
