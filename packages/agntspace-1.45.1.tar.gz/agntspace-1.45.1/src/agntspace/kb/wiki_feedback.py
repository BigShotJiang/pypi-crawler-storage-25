"""Per-article wiki feedback queue.

Phase 8 (2026-04-30) closes the gap between "user flags an article wrong"
and "agent learns + addresses the gap on next regeneration." Three
correction paths now coexist (none replace the others):

  1. Manual edit → VaultEditWatcher fires ``wiki_manually_edited`` →
     agent sees the result on next prompt context. Captures the WHAT.
  2. Reject (existing) → flips ``status: rejected``, sledgehammer for
     "this whole article needs rework or deletion."
  3. Feedback queue (THIS module) → user flags the gap without doing
     the work; agent reads the user's REASONING on next regeneration.
     Captures the WHY.

Feedback rows live in ``wiki_feedback`` SQLite table. ``compile_wiki``,
``synthesize``, and ``research_kb`` query open feedback for the article(s)
they're about to regenerate; the LLM prompt includes the user's notes.
The fact-checker daily pass also reads open feedback to prioritize
verification. Once the agent (or user) addresses the feedback, it's
marked resolved.

Architectural rule: feedback is signal, not authority. A wrong feedback
note CAN mis-direct the agent. The strict frontmatter normalizer +
fact-checker daily pass catch gross mistakes (organization-vs-person,
broken citations). Subjective feedback is up to user judgment.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import aiosqlite

    from agntspace.activity.logger import ActivityLogger
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# arch:deterministic — closed enum tied to the feedback substrate.
# Adding a new kind requires updating both this set AND the SKILL.md
# documentation so the user-facing labels stay consistent.
_VALID_KINDS: frozenset[str] = frozenset({  # arch:deterministic — closed enum
    "factual_error",        # specific claim is wrong
    "wrong_classification", # entity_type / taxonomy_path mistake
    "missing_info",         # article is incomplete
    "outdated",             # was correct, no longer is
    "unclear",              # ambiguous / poorly written
    "other",                # catch-all when none of the above fit
})

# arch:deterministic — severity ordering for UI sort + fact-checker priority.
_VALID_SEVERITIES: frozenset[str] = frozenset({"low", "medium", "high"})  # arch:deterministic — closed enum

# arch:deterministic — feedback lifecycle states.
_VALID_STATUSES: frozenset[str] = frozenset({"open", "resolved", "dismissed"})  # arch:deterministic — closed enum


# Skill-loaded fallback config — used when the wiki-feedback substrate
# YAML is missing or malformed.
# arch:deterministic per Rule 12.
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing
    "enabled": True,
    "max_note_chars": 2000,
    "auto_resolve_on_regenerate": False,  # safer default — user closes
    "agent_prompt_template": (
        "User flagged this article on {date}: {note}\n"
        "Kind: {kind} (severity: {severity}). Address this in your regeneration."
    ),
}


# ── Enums + DTOs ───────────────────────────────────────────────────


FeedbackKind = Literal[
    "factual_error", "wrong_classification", "missing_info",
    "outdated", "unclear", "other",
]
FeedbackSeverity = Literal["low", "medium", "high"]
FeedbackStatus = Literal["open", "resolved", "dismissed"]


@dataclass
class FeedbackRow:
    """One feedback record."""

    id: int = 0
    slug: str = ""
    kb: str = ""
    kind: FeedbackKind = "other"
    severity: FeedbackSeverity = "medium"
    note: str = ""
    status: FeedbackStatus = "open"
    created_at: str = ""
    resolved_at: str = ""
    resolved_by: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "slug": self.slug,
            "kb": self.kb,
            "kind": self.kind,
            "severity": self.severity,
            "note": self.note,
            "status": self.status,
            "created_at": self.created_at,
            "resolved_at": self.resolved_at,
            "resolved_by": self.resolved_by,
        }


# ── Skill-config helper ────────────────────────────────────────────


def resolve_feedback_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Read tuning from ``_meta/wiki-feedback/config/feedback.yaml``.

    Falls back to ``_FALLBACK_CONFIG`` on missing / malformed / non-dict.
    Never raises.
    """
    cfg = dict(_FALLBACK_CONFIG)
    if skill_loader is None:
        return cfg
    try:
        loaded = skill_loader.load_skill_config_file(
            "wiki-feedback", "feedback.yaml",
        )
    except Exception:
        log.debug("wiki-feedback: failed to load feedback.yaml", exc_info=True)
        return cfg
    if not isinstance(loaded, dict):
        return cfg

    if "enabled" in loaded:
        cfg["enabled"] = bool(loaded["enabled"])

    if "max_note_chars" in loaded:
        try:
            v = int(loaded["max_note_chars"])
            if 100 <= v <= 50000:
                cfg["max_note_chars"] = v
        except (TypeError, ValueError):
            pass

    if "auto_resolve_on_regenerate" in loaded:
        cfg["auto_resolve_on_regenerate"] = bool(loaded["auto_resolve_on_regenerate"])

    if isinstance(loaded.get("agent_prompt_template"), str):
        # Validate placeholders — must include {note} at minimum.
        tmpl = loaded["agent_prompt_template"]
        if "{note}" in tmpl:
            cfg["agent_prompt_template"] = tmpl

    return cfg


# ── Service ────────────────────────────────────────────────────────


class WikiFeedbackService:
    """SQLite-backed feedback queue for wiki articles.

    Defensive contract:
      - ``enabled=False`` → submit / resolve become no-ops; reads return [].
        Master kill switch via YAML.
      - DB connection missing → in-memory fallback (test fixtures).
      - Activity logger missing → silent (events optional).
      - Submit MUST validate kind + severity against the closed enum.
        Unknown values raise ``ValueError`` so callers see the contract
        instead of silently coercing.
      - Note > max_note_chars truncated with ``…`` suffix (preserves intent
        without flooding the LLM context with novellas).
    """

    def __init__(
        self,
        db: aiosqlite.Connection | None,
        *,
        skill_loader: SkillLoader | None = None,
        activity_logger: ActivityLogger | None = None,
    ) -> None:
        self._db = db
        self._skill_loader = skill_loader
        self._activity = activity_logger
        # In-memory fallback for tests + minimal installs.
        self._fallback_rows: list[FeedbackRow] = []
        self._fallback_next_id: int = 1

    @property
    def config(self) -> dict[str, Any]:
        return resolve_feedback_config(self._skill_loader)

    @property
    def is_enabled(self) -> bool:
        return bool(self.config.get("enabled", True))

    # ── Schema ──

    async def init_schema(self) -> None:
        """Create the ``wiki_feedback`` table. Idempotent — re-run safe.

        Indexed on slug + status (the two filter axes hit on every read).
        """
        if self._db is None:
            return
        try:
            await self._db.executescript("""
                CREATE TABLE IF NOT EXISTS wiki_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    slug TEXT NOT NULL,
                    kb TEXT NOT NULL DEFAULT '',
                    kind TEXT NOT NULL DEFAULT 'other',
                    severity TEXT NOT NULL DEFAULT 'medium',
                    note TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'open',
                    created_at TEXT NOT NULL,
                    resolved_at TEXT NOT NULL DEFAULT '',
                    resolved_by TEXT NOT NULL DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS idx_wf_slug ON wiki_feedback(slug);
                CREATE INDEX IF NOT EXISTS idx_wf_status ON wiki_feedback(status);
                CREATE INDEX IF NOT EXISTS idx_wf_slug_status
                    ON wiki_feedback(slug, status);
            """)
            await self._db.commit()
        except Exception:
            log.exception("wiki_feedback: init_schema failed; using in-memory fallback")

    # ── Write ──

    async def submit(
        self,
        slug: str,
        *,
        kind: FeedbackKind = "other",
        severity: FeedbackSeverity = "medium",
        note: str = "",
        kb: str = "",
    ) -> FeedbackRow:
        """Submit a new feedback row.

        Raises ``ValueError`` on invalid kind/severity. Truncates note to
        ``max_note_chars`` (configurable). When ``enabled=False``, returns
        a stub row without persisting (caller can detect via id == 0).
        """
        if kind not in _VALID_KINDS:
            raise ValueError(
                f"Invalid feedback kind {kind!r}. Valid: {sorted(_VALID_KINDS)}"
            )
        if severity not in _VALID_SEVERITIES:
            raise ValueError(
                f"Invalid feedback severity {severity!r}. Valid: {sorted(_VALID_SEVERITIES)}"
            )
        if not slug:
            raise ValueError("slug is required")

        if not self.is_enabled:
            return FeedbackRow(slug=slug, kind=kind, severity=severity, note=note)

        cfg = self.config
        max_chars = int(cfg.get("max_note_chars", 2000))
        if len(note) > max_chars:
            note = note[: max_chars - 1] + "…"

        now = datetime.now(UTC).isoformat()

        if self._db is None:
            row = FeedbackRow(
                id=self._fallback_next_id,
                slug=slug, kb=kb, kind=kind, severity=severity,
                note=note, status="open", created_at=now,
            )
            self._fallback_next_id += 1
            self._fallback_rows.append(row)
            self._emit_event(
                action="wiki_feedback_submitted",
                summary=f"User flagged wiki article '{slug}': {kind} ({severity})",
                details={"id": row.id, "slug": slug, "kind": kind, "severity": severity, "kb": kb},
                importance="medium",
            )
            return row

        try:
            async with self._db.execute(
                """INSERT INTO wiki_feedback
                   (slug, kb, kind, severity, note, status, created_at)
                   VALUES (?, ?, ?, ?, ?, 'open', ?)""",
                (slug, kb, kind, severity, note, now),
            ) as cursor:
                row_id = cursor.lastrowid
            await self._db.commit()
        except Exception:
            log.exception("wiki_feedback: INSERT failed for slug=%s", slug)
            return FeedbackRow(slug=slug, kind=kind, severity=severity, note=note)

        row = FeedbackRow(
            id=row_id, slug=slug, kb=kb, kind=kind, severity=severity,
            note=note, status="open", created_at=now,
        )
        self._emit_event(
            action="wiki_feedback_submitted",
            summary=f"User flagged wiki article '{slug}': {kind} ({severity})",
            details={"id": row_id, "slug": slug, "kind": kind, "severity": severity, "kb": kb},
            importance="medium",
        )
        return row

    async def resolve(
        self,
        feedback_id: int,
        *,
        resolved_by: str = "user",
        new_status: FeedbackStatus = "resolved",
    ) -> bool:
        """Close a feedback row. Returns True iff the row was open and
        flipped to ``resolved`` (or ``dismissed``).

        ``resolved_by`` defaults to "user" but can be set to "agent",
        "compile_wiki", "fact_checker", etc. so we know who closed it.
        """
        if new_status not in _VALID_STATUSES:
            raise ValueError(
                f"Invalid feedback status {new_status!r}. Valid: {sorted(_VALID_STATUSES)}"
            )
        if new_status == "open":
            raise ValueError("Cannot 'resolve' to status='open' — use submit() instead")

        if not self.is_enabled:
            return False

        now = datetime.now(UTC).isoformat()

        if self._db is None:
            for row in self._fallback_rows:
                if row.id == feedback_id and row.status == "open":
                    row.status = new_status
                    row.resolved_at = now
                    row.resolved_by = resolved_by
                    self._emit_resolve_event(row)
                    return True
            return False

        try:
            async with self._db.execute(
                """UPDATE wiki_feedback
                   SET status = ?, resolved_at = ?, resolved_by = ?
                   WHERE id = ? AND status = 'open'""",
                (new_status, now, resolved_by, feedback_id),
            ) as cursor:
                rows_affected = cursor.rowcount
            await self._db.commit()
        except Exception:
            log.exception("wiki_feedback: UPDATE failed for id=%d", feedback_id)
            return False

        if rows_affected > 0:
            # Re-read for the event payload
            row = await self._fetch_one(feedback_id)
            if row:
                self._emit_resolve_event(row)
            return True
        return False

    # ── Read ──

    async def list_for_article(
        self, slug: str, *, status_filter: FeedbackStatus | None = "open",
    ) -> list[FeedbackRow]:
        """All feedback rows for one article. Default returns OPEN only —
        callers wanting closed-too pass ``status_filter=None``."""
        if self._db is None:
            return [
                r for r in self._fallback_rows
                if r.slug == slug
                and (status_filter is None or r.status == status_filter)
            ]

        sql = "SELECT * FROM wiki_feedback WHERE slug = ?"
        params: list[Any] = [slug]
        if status_filter is not None:
            sql += " AND status = ?"
            params.append(status_filter)
        sql += " ORDER BY id DESC"

        try:
            async with self._db.execute(sql, params) as cursor:
                rows = await cursor.fetchall()
        except Exception:
            log.debug("wiki_feedback: list_for_article failed", exc_info=True)
            return []

        return [self._row_from_sql(r) for r in rows]

    async def list_open(self, *, limit: int = 100) -> list[FeedbackRow]:
        """All open feedback across every article. Used by the
        fact-checker daily pass to prioritize verification."""
        if self._db is None:
            return [r for r in self._fallback_rows if r.status == "open"][:limit]

        try:
            async with self._db.execute(
                """SELECT * FROM wiki_feedback
                   WHERE status = 'open'
                   ORDER BY
                     CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END,
                     id DESC
                   LIMIT ?""",
                (limit,),
            ) as cursor:
                rows = await cursor.fetchall()
        except Exception:
            log.debug("wiki_feedback: list_open failed", exc_info=True)
            return []

        return [self._row_from_sql(r) for r in rows]

    async def count_open(self, slug: str) -> int:
        """Cheap count for the UI badge on each article."""
        if self._db is None:
            return sum(
                1 for r in self._fallback_rows
                if r.slug == slug and r.status == "open"
            )
        try:
            async with self._db.execute(
                "SELECT COUNT(*) FROM wiki_feedback WHERE slug = ? AND status = 'open'",
                (slug,),
            ) as cursor:
                row = await cursor.fetchone()
            return int(row[0]) if row else 0
        except Exception:
            return 0

    async def count_open_total(self) -> int:
        """Cheap count for the global feedback badge."""
        if self._db is None:
            return sum(1 for r in self._fallback_rows if r.status == "open")
        try:
            async with self._db.execute(
                "SELECT COUNT(*) FROM wiki_feedback WHERE status = 'open'",
            ) as cursor:
                row = await cursor.fetchone()
            return int(row[0]) if row else 0
        except Exception:
            return 0

    # ── Agent context injection ──

    async def render_agent_prompt(self, slug: str) -> str:
        """Render open feedback for a slug as a single string for inclusion
        in an LLM system prompt. Empty string when no open feedback OR
        feature disabled (caller injects unconditionally; empty injection
        is a no-op)."""
        if not self.is_enabled:
            return ""

        open_rows = await self.list_for_article(slug, status_filter="open")
        if not open_rows:
            return ""

        cfg = self.config
        template = cfg.get("agent_prompt_template", _FALLBACK_CONFIG["agent_prompt_template"])

        lines: list[str] = []
        lines.append(f"# User feedback on this article ({len(open_rows)} open)")
        for row in open_rows:
            try:
                rendered = template.format(
                    date=row.created_at[:10] if row.created_at else "",
                    note=row.note or "(no note)",
                    kind=row.kind,
                    severity=row.severity,
                )
            except (KeyError, ValueError):
                # Malformed template — fall back to a safe shape
                rendered = (
                    f"User flagged ({row.kind}, {row.severity}): "
                    f"{row.note or '(no note)'}"
                )
            lines.append(f"- {rendered}")

        return "\n".join(lines)

    # ── Helpers ──

    async def _fetch_one(self, feedback_id: int) -> FeedbackRow | None:
        if self._db is None:
            for row in self._fallback_rows:
                if row.id == feedback_id:
                    return row
            return None
        try:
            async with self._db.execute(
                "SELECT * FROM wiki_feedback WHERE id = ?",
                (feedback_id,),
            ) as cursor:
                row = await cursor.fetchone()
        except Exception:
            return None
        return self._row_from_sql(row) if row else None

    @staticmethod
    def _row_from_sql(row: Any) -> FeedbackRow:
        """Coerce a sqlite3.Row / tuple into a FeedbackRow."""
        # Schema column order: id, slug, kb, kind, severity, note, status,
        # created_at, resolved_at, resolved_by
        return FeedbackRow(
            id=int(row[0]),
            slug=str(row[1] or ""),
            kb=str(row[2] or ""),
            kind=str(row[3] or "other"),  # type: ignore[arg-type]
            severity=str(row[4] or "medium"),  # type: ignore[arg-type]
            note=str(row[5] or ""),
            status=str(row[6] or "open"),  # type: ignore[arg-type]
            created_at=str(row[7] or ""),
            resolved_at=str(row[8] or ""),
            resolved_by=str(row[9] or ""),
        )

    def _emit_event(
        self, *, action: str, summary: str, details: dict[str, Any], importance: str,
    ) -> None:
        if self._activity is None:
            return
        try:
            self._activity.log(  # type: ignore[attr-defined]
                category="knowledge",
                action=action,
                summary=summary,
                details=details,
                importance=importance,
            )
        except Exception:
            log.debug("wiki_feedback: activity event failed", exc_info=True)

    def _emit_resolve_event(self, row: FeedbackRow) -> None:
        self._emit_event(
            action="wiki_feedback_resolved",
            summary=(
                f"Feedback closed on '{row.slug}' "
                f"({row.kind}, {row.severity}, by={row.resolved_by})"
            ),
            details={
                "id": row.id, "slug": row.slug, "kind": row.kind,
                "severity": row.severity, "resolved_by": row.resolved_by,
            },
            importance="low",  # closure is routine; submission is the signal
        )


__all__ = [
    "FeedbackKind",
    "FeedbackRow",
    "FeedbackSeverity",
    "FeedbackStatus",
    "WikiFeedbackService",
    "resolve_feedback_config",
]
