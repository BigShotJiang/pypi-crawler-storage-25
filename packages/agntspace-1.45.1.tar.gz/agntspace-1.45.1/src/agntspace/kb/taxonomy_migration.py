"""Taxonomy v1 → v2 migration helpers.

Maps the legacy 9-category taxonomy slugs (people-organizations, science-technology,
business-strategy, projects-products, processes-methods, culture-society,
events-timeline, sources, general) onto the new 7-fixed-L1 v2 tree without
touching the wiki article content. Only the ``taxonomy_path`` frontmatter
field is rewritten.

Two-tier confidence:
  - ``"deterministic"`` — the old path has a clean, unambiguous v2 home.
  - ``"ambiguous"``    — the v1 slug spanned multiple v2 axes; we picked the
                          most defensible default but a human review is
                          recommended. The preview surface flags these.

The migration is **read-only** at this layer. Applying changes is gated to a
separate caller that walks the vault and rewrites frontmatter under user
approval. See ``api/routes/wiki.py:taxonomy_migration_*``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Literal

log = logging.getLogger(__name__)


Confidence = Literal["deterministic", "ambiguous", "unclassified", "unmapped"]


# ── v1 → v2 mapping table ────────────────────────────────────────────
#
# Format: v1_slug_path → (v2_slug_path, confidence, reason)
#
# Confidence:
#   deterministic — clean, unambiguous v2 home; no human review needed
#   ambiguous     — multiple plausible v2 targets, picked the closest match
#   unclassified  — old "general" / empty path → maps to "" (Unclassified)
#
# arch:deterministic — this is a frozen one-time migration table tied to
# the v1 → v2 rewrite. Adding new entries requires bumping the v2 schema
# version, which is itself a deliberate architectural change.
_V1_TO_V2: dict[str, tuple[str, Confidence, str]] = {

    # ─── People & Organizations ──────────────────────────────────────
    "people-organizations":           ("entities",                        "deterministic", "v1 L1 collapses into entities/* L2"),
    "people-organizations/people":    ("entities/people",                 "deterministic", "direct path remap"),
    "people-organizations/organizations": ("entities/organizations",      "deterministic", "direct path remap"),
    "people-organizations/teams-groups":  ("entities/organizations/communities", "ambiguous", "v1 'teams-groups' best fits v2 'communities' L3"),

    # ─── Science & Technology ────────────────────────────────────────
    "science-technology":                          ("knowledge",                              "deterministic", "v1 L1 collapses into knowledge/* L2"),
    "science-technology/ai-machine-learning":      ("knowledge/technology/ai",                "deterministic", "AI is a knowledge/technology L3"),
    "science-technology/computer-science":         ("knowledge/engineering/software-engineering", "ambiguous", "CS spans engineering/SWE; users may prefer knowledge/technology"),
    "science-technology/mathematics-statistics":   ("knowledge/science/mathematics",          "deterministic", "math is a knowledge/science L3"),
    "science-technology/engineering":              ("knowledge/engineering",                  "deterministic", "engineering is a knowledge L2"),
    "science-technology/natural-sciences":         ("knowledge/science",                      "deterministic", "natural sciences map to knowledge/science L2"),
    "science-technology/health-medicine":          ("knowledge/science/biology",              "ambiguous", "health/medicine has no direct v2 leaf; biology is closest"),

    # ─── Business & Strategy ─────────────────────────────────────────
    "business-strategy":                            ("knowledge/business",                     "ambiguous", "v1 mixed strategy concepts and personal business; default to knowledge"),
    "business-strategy/strategy-planning":          ("knowledge/business/strategy",            "deterministic", "direct path remap"),
    "business-strategy/finance-economics":          ("knowledge/society/economics",            "ambiguous", "v1 mixed personal finance + econ theory; defaulting to society/economics"),
    "business-strategy/marketing-growth":           ("knowledge/business/marketing",           "deterministic", "direct path remap"),
    "business-strategy/management-leadership":      ("reference/principles/leadership-principles", "ambiguous", "v1 management-leadership best fits reference/principles in v2"),
    "business-strategy/legal-compliance":           ("areas/legal-admin/compliance",           "ambiguous", "v1 legal-compliance is ongoing user concern in v2 (areas, not knowledge)"),

    # ─── Projects & Products ─────────────────────────────────────────
    "projects-products":                            ("projects",                               "deterministic", "v1 L1 collapses into v2 projects L1"),
    "projects-products/active-projects":            ("projects",                               "deterministic", "v2 projects L1 is active by definition; status field tracks lifecycle"),
    "projects-products/products-services":          ("entities/products",                      "deterministic", "products are first-class entities in v2"),
    "projects-products/tools-platforms":            ("entities/products/tools",                "deterministic", "v2 entities/products/tools matches"),
    "projects-products/archives":                   ("projects",                               "ambiguous", "v2 has no Archive L1 (deliberate); use status=completed/archived on the project page"),

    # ─── Processes & Methods ─────────────────────────────────────────
    "processes-methods":                            ("workflows",                              "deterministic", "v1 processes-methods L1 maps to v2 workflows L1"),
    "processes-methods/workflows":                  ("workflows",                              "deterministic", "direct path remap to L1"),
    "processes-methods/frameworks-methods":         ("reference/methods",                      "deterministic", "frameworks/methods are reusable tools in v2"),
    "processes-methods/best-practices":             ("reference/principles",                   "deterministic", "best practices are reusable principles in v2"),
    "processes-methods/standards-specs":            ("digests/documents/standards",            "ambiguous", "standards are source documents in v2; if user authored their own, reference/methods is also valid"),

    # ─── Culture & Society ───────────────────────────────────────────
    "culture-society":                              ("knowledge/humanities",                   "deterministic", "v1 L1 collapses into knowledge/humanities"),
    "culture-society/philosophy-ethics":            ("knowledge/humanities/philosophy",        "deterministic", "direct path remap"),
    "culture-society/arts-media":                   ("areas/creativity",                       "ambiguous", "v1 arts-media spans personal creative practice (areas) and consumed media (sources); defaulting to creativity"),
    "culture-society/education-learning":           ("areas/learning",                         "deterministic", "education-learning is ongoing learning practice in v2"),
    "culture-society/history-politics":             ("knowledge/society/politics",             "ambiguous", "v1 mixed history + politics; politics is closer to most user content"),

    # ─── Events & Timeline ───────────────────────────────────────────
    "events-timeline":                              ("entities/events",                        "deterministic", "events are first-class entities in v2"),
    "events-timeline/milestones":                   ("entities/events/launches",               "ambiguous", "milestones best fit launches L3"),
    "events-timeline/incidents-issues":             ("entities/events/incidents",              "deterministic", "direct path remap"),
    "events-timeline/meetings-conferences":         ("entities/events/meetings",               "ambiguous", "v1 mixed meetings + conferences; conferences may belong at entities/events/conferences instead"),

    # ─── Sources → Digests (L1 renamed 2026-04-27) ──────────────────
    # The L1 bucket renamed from `sources` (v1 + early-v2) to `digests`
    # to align with the entity_type rename source_summary → digest. The
    # mapping covers both the legacy `sources/...` v1 paths AND any
    # interim early-v2 paths a vault may have accumulated before the
    # rename landed.
    "sources":                                      ("digests",                                "deterministic", "L1 renamed sources→digests"),
    "sources/articles-blog-posts":                  ("digests/articles/blog-posts",            "deterministic", "L1 renamed + v1 collapsed L2 split"),
    "sources/papers-research":                      ("digests/articles/papers",                "deterministic", "L1 renamed + v1 collapsed L2 split"),
    "sources/books-long-form":                      ("digests/books",                          "ambiguous", "L1 renamed + v1 mixed books + long-form essays"),
    "sources/media-recordings":                     ("digests/media",                          "deterministic", "L1 renamed + L2 matches"),
    "sources/data-datasets":                        ("digests/documents",                      "ambiguous", "L1 renamed + v2 has no direct datasets node"),

    # ─── General catch-all → unclassified ────────────────────────────
    "general":                                      ("",                                       "unclassified", "v1 'general' had no real meaning; v2 uses empty path for unclassified"),
}


@dataclass(frozen=True)
class MigrationMapping:
    """One row of the migration plan: an article's old path, new path, and
    a confidence flag explaining whether human review is recommended."""

    old_path: str
    new_path: str
    confidence: Confidence
    reason: str

    @property
    def changed(self) -> bool:
        """True iff the path actually moves under migration."""
        return self.old_path != self.new_path


def map_v1_path(old_path: str) -> MigrationMapping:
    """Resolve a single v1 taxonomy_path to its v2 target.

    Returns ``MigrationMapping`` with one of four confidence outcomes:
      - ``deterministic``  — clean remap, no review needed.
      - ``ambiguous``      — multiple plausible targets; preview should flag.
      - ``unclassified``   — old path was a v1 sentinel (``general``); maps to "".
      - ``unmapped``       — old path is unknown to the v1 vocabulary; preserved
                              as-is so the migration is non-destructive on
                              already-v2 paths or hand-edited values.
    """
    cleaned = (old_path or "").strip()
    if not cleaned:
        return MigrationMapping("", "", "unclassified", "empty path → unclassified")
    if cleaned in _V1_TO_V2:
        new_path, confidence, reason = _V1_TO_V2[cleaned]
        return MigrationMapping(cleaned, new_path, confidence, reason)
    return MigrationMapping(
        cleaned, cleaned, "unmapped",
        "path not in v1 vocabulary — preserving (may already be v2 or hand-edited)",
    )


def get_mapping_table() -> dict[str, tuple[str, Confidence, str]]:
    """Return the full v1→v2 mapping for inspection. Read-only — copy if mutating."""
    return dict(_V1_TO_V2)


def summarize_articles(articles: list[dict]) -> dict[str, dict]:
    """Build a per-old-path summary of how many articles would migrate where.

    Input: ``articles`` is a list of dicts with at least ``slug`` and
    ``taxonomy_path`` keys. Output: ``{old_path: {new_path, confidence,
    count, sample_slugs}}`` for the UI / CLI dry-run display.
    """
    buckets: dict[str, dict] = {}
    for art in articles:
        old = (art.get("taxonomy_path") or "").strip()
        mapping = map_v1_path(old)
        bucket = buckets.setdefault(
            old or "(empty)",
            {
                "old_path": old,
                "new_path": mapping.new_path,
                "confidence": mapping.confidence,
                "reason": mapping.reason,
                "count": 0,
                "sample_slugs": [],
                "changed": mapping.changed,
            },
        )
        bucket["count"] += 1
        if len(bucket["sample_slugs"]) < 5:
            slug = art.get("slug", "")
            if slug:
                bucket["sample_slugs"].append(slug)
    return buckets


def plan_migration(articles: list[dict]) -> dict:
    """Produce a structured dry-run plan over a list of articles.

    Returns ``{total, changed, deterministic, ambiguous, unclassified,
              unmapped, by_old_path: {...}, by_confidence: {...}}``.
    """
    by_old = summarize_articles(articles)
    by_conf: dict[str, int] = {
        "deterministic": 0, "ambiguous": 0, "unclassified": 0, "unmapped": 0,
    }
    changed = 0
    for bucket in by_old.values():
        by_conf[bucket["confidence"]] = by_conf.get(bucket["confidence"], 0) + bucket["count"]
        if bucket["changed"]:
            changed += bucket["count"]
    return {
        "total": sum(b["count"] for b in by_old.values()),
        "changed": changed,
        "by_confidence": by_conf,
        "by_old_path": by_old,
    }


def apply_migration(
    articles: list[dict],
    update_callback,
    *,
    confidence_filter: set[str] | None = None,
) -> dict:
    """Walk articles and rewrite ``taxonomy_path`` via the caller-supplied
    update_callback. The callback is invoked as
    ``update_callback(slug, new_path)`` for every article that should change.

    Pure with respect to filesystem: this function does no I/O of its own —
    the callback owns the write path so the route can use the KB service's
    ``update_article`` (which respects contract + auto-versioning + the
    runtime guard).

    Args:
        articles: list of dicts with at least ``slug`` and ``taxonomy_path``.
        update_callback: ``(slug, new_path) -> None`` writer. Exceptions are
            caught and recorded as failures; one bad article never aborts
            the rest.
        confidence_filter: optional set restricting which mappings apply
            (e.g. ``{"deterministic"}`` to skip ambiguous + unclassified).
            None = apply every change regardless of confidence.

    Returns:
        ``{migrated: int, skipped: int, failed: int,
           migrated_items: [...], skipped_items: [...], failed_items: [...]}``
        where each item carries slug, old_path, new_path, and confidence (or
        an error string for failures).
    """
    migrated: list[dict] = []
    skipped: list[dict] = []
    failed: list[dict] = []

    for art in articles:
        slug = art.get("slug", "")
        if not slug:
            continue
        old = (art.get("taxonomy_path") or "").strip()
        mapping = map_v1_path(old)

        if not mapping.changed:
            skipped.append({
                "slug": slug, "old_path": old, "new_path": mapping.new_path,
                "confidence": mapping.confidence, "reason": "no_change",
            })
            continue
        if confidence_filter is not None and mapping.confidence not in confidence_filter:
            skipped.append({
                "slug": slug, "old_path": old, "new_path": mapping.new_path,
                "confidence": mapping.confidence,
                "reason": f"confidence_excluded:{mapping.confidence}",
            })
            continue

        try:
            update_callback(slug, mapping.new_path)
        except Exception as exc:  # noqa: BLE001 — bulk migration: log + continue, never abort
            log.warning(
                "Migration failed for %s (%s → %s): %s",
                slug, old, mapping.new_path, exc,
            )
            failed.append({
                "slug": slug, "old_path": old, "new_path": mapping.new_path,
                "confidence": mapping.confidence,
                "error": f"{type(exc).__name__}: {exc}",
            })
        else:
            migrated.append({
                "slug": slug, "old_path": old, "new_path": mapping.new_path,
                "confidence": mapping.confidence, "reason": mapping.reason,
            })

    return {
        "migrated": len(migrated),
        "skipped": len(skipped),
        "failed": len(failed),
        "migrated_items": migrated,
        "skipped_items": skipped,
        "failed_items": failed,
    }
