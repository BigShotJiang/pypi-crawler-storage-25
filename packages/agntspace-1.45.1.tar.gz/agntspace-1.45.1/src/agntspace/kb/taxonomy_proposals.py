"""Taxonomy proposal pipeline — agent-proposed L2/L3 nodes that await user approval.

Proposals land as one JSON file per proposal under:
  <vault>/agntspace/memory/pending/taxonomy-proposals/<proposal_id>.json

Approve = merge the proposed node into the vault override file at:
  <vault>/agntspace/system/skills/_meta/knowledge-taxonomy/config/taxonomy.yaml

Reject = remove the pending file. Both actions emit activity events upstream.

The L1 lock from ``kb/taxonomy.py:FIXED_L1_SLUGS`` applies here too — proposals
that target a Level-1 slug not in the fixed set are refused at write time.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from agntspace.kb.taxonomy import FIXED_L1_SLUGS, _validate_slug

log = logging.getLogger(__name__)


# ── Paths ────────────────────────────────────────────────────────────


def _pending_dir(vault_dir: Path) -> Path:
    return Path(vault_dir) / "agntspace" / "memory" / "pending" / "taxonomy-proposals"


def _override_path(vault_dir: Path) -> Path:
    return (
        Path(vault_dir)
        / "agntspace"
        / "system"
        / "skills"
        / "_meta"
        / "knowledge-taxonomy"
        / "config"
        / "taxonomy.yaml"
    )


# ── Models ───────────────────────────────────────────────────────────


@dataclass
class TaxonomyProposal:
    """A single proposed node addition awaiting user approval.

    ``path`` is the slug-based 2- or 3-segment path the agent wants to add
    (e.g. ``"knowledge/technology/robotics"``). The first segment MUST be
    one of ``FIXED_L1_SLUGS``. Adding a Level-1 (single-segment path) is
    rejected unconditionally.
    """

    proposal_id: str
    path: str
    name: str
    description: str
    rationale: str
    proposed_by: str = "agent"
    created_at: str = ""
    examples: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "path": self.path,
            "name": self.name,
            "description": self.description,
            "rationale": self.rationale,
            "proposed_by": self.proposed_by,
            "created_at": self.created_at,
            "examples": list(self.examples),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaxonomyProposal:
        return cls(
            proposal_id=str(data.get("proposal_id", "")),
            path=str(data.get("path", "")),
            name=str(data.get("name", "")),
            description=str(data.get("description", "")),
            rationale=str(data.get("rationale", "")),
            proposed_by=str(data.get("proposed_by", "agent")),
            created_at=str(data.get("created_at", "")),
            examples=list(data.get("examples", []) or []),
        )


# ── Validation helpers ───────────────────────────────────────────────


def validate_proposal_path(path: str) -> tuple[bool, str]:
    """Return (ok, reason). Rejects empty, single-segment (L1), >3 segments,
    invalid slugs, or paths starting with a slug outside FIXED_L1_SLUGS.
    """
    if not path or "/" not in path:
        return False, "path must have at least 2 segments (e.g. 'knowledge/technology')"
    segments = path.split("/")
    if len(segments) > 3:
        return False, "path cannot exceed 3 levels"
    if len(segments) < 2:
        return False, "Level-1 categories cannot be added — only L2/L3 may be proposed"
    for seg in segments:
        if not _validate_slug(seg):
            return False, f"invalid slug segment: {seg!r}"
    if segments[0] not in FIXED_L1_SLUGS:
        return False, f"Level-1 must be one of {list(FIXED_L1_SLUGS)} — got {segments[0]!r}"
    return True, ""


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _stable_proposal_id(path: str) -> str:
    """Deterministic id from the path so duplicate proposals collide and
    overwrite rather than accumulate."""
    digest = hashlib.sha256(path.encode("utf-8")).hexdigest()[:10]
    return f"prop-{digest}"


# ── Persistence ──────────────────────────────────────────────────────


def list_pending(vault_dir: Path) -> list[TaxonomyProposal]:
    """Return every pending taxonomy proposal, newest first by created_at."""
    pdir = _pending_dir(vault_dir)
    if not pdir.is_dir():
        return []
    out: list[TaxonomyProposal] = []
    for f in sorted(pdir.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            log.warning("Skipping unparseable taxonomy proposal: %s", f, exc_info=True)
            continue
        if isinstance(data, dict):
            out.append(TaxonomyProposal.from_dict(data))
    out.sort(key=lambda p: p.created_at, reverse=True)
    return out


def write_proposal(
    vault_dir: Path,
    *,
    path: str,
    name: str,
    description: str,
    rationale: str,
    proposed_by: str = "agent",
    examples: list[str] | None = None,
) -> tuple[TaxonomyProposal | None, str]:
    """Persist a new proposal. Returns (proposal, error_or_empty)."""
    ok, reason = validate_proposal_path(path)
    if not ok:
        return None, reason
    if not name.strip():
        return None, "name is required"
    if not description.strip():
        return None, "description is required"

    proposal = TaxonomyProposal(
        proposal_id=_stable_proposal_id(path),
        path=path,
        name=name.strip(),
        description=description.strip(),
        rationale=rationale.strip(),
        proposed_by=proposed_by or "agent",
        created_at=_now_iso(),
        examples=list(examples or []),
    )
    pdir = _pending_dir(vault_dir)
    pdir.mkdir(parents=True, exist_ok=True)
    target = pdir / f"{proposal.proposal_id}.json"
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(proposal.to_dict(), indent=2), encoding="utf-8")
    tmp.replace(target)
    return proposal, ""


def get_proposal(vault_dir: Path, proposal_id: str) -> TaxonomyProposal | None:
    """Look up a single proposal by id."""
    target = _pending_dir(vault_dir) / f"{proposal_id}.json"
    if not target.is_file():
        return None
    try:
        return TaxonomyProposal.from_dict(json.loads(target.read_text(encoding="utf-8")))
    except Exception:
        log.warning("Failed to read proposal %s", proposal_id, exc_info=True)
        return None


def reject_proposal(vault_dir: Path, proposal_id: str) -> bool:
    """Delete a pending proposal. Returns True iff a file was removed."""
    target = _pending_dir(vault_dir) / f"{proposal_id}.json"
    if not target.is_file():
        return False
    try:
        target.unlink()
        return True
    except OSError:
        log.warning("Failed to remove proposal %s", proposal_id, exc_info=True)
        return False


# ── Override-file merge on approval ──────────────────────────────────


def _read_override(vault_dir: Path) -> dict:
    path = _override_path(vault_dir)
    if not path.is_file():
        return {"taxonomy": []}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {"taxonomy": []}
    try:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            return {"taxonomy": []}
        if not isinstance(data.get("taxonomy"), list):
            data["taxonomy"] = []
        return data
    except Exception:
        log.warning("Override taxonomy.yaml is unparseable — refusing to overwrite", exc_info=True)
        raise


def _ensure_segment(parent_children: list[dict], slug: str) -> dict:
    """Find or create a child node with the given slug under parent_children.
    Returns the node (mutable reference)."""
    for n in parent_children:
        if isinstance(n, dict) and n.get("slug") == slug:
            return n
    new_node = {"slug": slug, "children": []}
    parent_children.append(new_node)
    return new_node


def _set_node_fields(node: dict, *, name: str, description: str) -> None:
    if name:
        node["name"] = name
    if description:
        node["description"] = description


def approve_proposal(vault_dir: Path, proposal_id: str) -> tuple[bool, str]:
    """Merge a proposal into the vault override file, then delete the pending
    file. Returns (ok, message_or_error).

    Idempotent — re-running on an already-approved (and now deleted) proposal
    is a no-op returning ``(False, "not_found")``. Re-applying a proposal whose
    target node already exists in the override is a successful no-op
    (description/name updated only if non-empty).
    """
    proposal = get_proposal(vault_dir, proposal_id)
    if proposal is None:
        return False, "not_found"

    ok, reason = validate_proposal_path(proposal.path)
    if not ok:
        return False, f"invalid_path: {reason}"

    try:
        data = _read_override(vault_dir)
    except Exception:
        return False, "override_unparseable"

    segments = proposal.path.split("/")
    l1_slug = segments[0]

    tree: list[dict] = data.setdefault("taxonomy", [])

    # L1 stub if missing — we DON'T add an L1 node, but we need a parent
    # entry in the override file to attach the L2/L3 to. The loader's L1
    # lock means even adding a new L1 in the override is filtered out, so
    # the entry only exists to host children.
    l1_node = None
    for n in tree:
        if isinstance(n, dict) and n.get("slug") == l1_slug:
            l1_node = n
            break
    if l1_node is None:
        l1_node = {"slug": l1_slug, "children": []}
        tree.append(l1_node)
    if not isinstance(l1_node.get("children"), list):
        l1_node["children"] = []

    if len(segments) == 2:
        # Add or update L2 directly under L1
        target = _ensure_segment(l1_node["children"], segments[1])
        _set_node_fields(target, name=proposal.name, description=proposal.description)
    else:  # len == 3
        l2 = _ensure_segment(l1_node["children"], segments[1])
        if not isinstance(l2.get("children"), list):
            l2["children"] = []
        target = _ensure_segment(l2["children"], segments[2])
        _set_node_fields(target, name=proposal.name, description=proposal.description)

    override_path = _override_path(vault_dir)
    override_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = override_path.with_suffix(".yaml.tmp")
    tmp.write_text(
        yaml.safe_dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    tmp.replace(override_path)

    reject_proposal(vault_dir, proposal_id)
    return True, f"merged into {override_path.relative_to(vault_dir)}"


# ── Status reports ───────────────────────────────────────────────────


def proposal_stats(vault_dir: Path) -> dict[str, Any]:
    """Aggregate stats for the agent / status endpoint."""
    pending = list_pending(vault_dir)
    return {
        "pending_count": len(pending),
        "by_l1": _bucket_pending_by_l1(pending),
        "newest": pending[0].to_dict() if pending else None,
    }


def _bucket_pending_by_l1(pending: list[TaxonomyProposal]) -> dict[str, int]:
    out: dict[str, int] = {}
    for p in pending:
        l1 = p.path.split("/", 1)[0] if p.path else ""
        if l1:
            out[l1] = out.get(l1, 0) + 1
    return out
