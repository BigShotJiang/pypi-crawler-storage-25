"""Source resolver for ``agntspace skill-import``.

Phase 5 of [tasks/plan-agentskills-compliance.md](../../../../tasks/plan-agentskills-compliance.md).

Resolves a user-supplied ``source`` string into a local on-disk skill
folder containing ``SKILL.md``. The folder is returned inside a context
manager that tears down any temporary clone or extraction on exit.

Source types accepted:

* **Local path** — directory containing ``SKILL.md`` OR a ``SKILL.md``
  file directly. Pure copy; no temp dir.
* **Zip URL** — ``http(s)://...zip``. Downloaded to a temp file,
  extracted to a temp dir. The first directory containing ``SKILL.md``
  inside the archive becomes the resolved folder.
* **Git URL** — ``https://...git`` OR ``git@...:...git`` OR a GitHub
  shorthand (``github:owner/repo``, ``owner/repo`` if it matches the
  shape, ``https://github.com/owner/repo``). Shallow-cloned to a temp
  dir via ``git clone --depth=1``. Repos hosting a single skill at the
  root are picked up automatically; repos with the skill in a subpath
  use the trailing fragment after ``#`` (``...repo.git#path/to/skill``).
* **GitHub URL** — convenience: ``https://github.com/owner/repo[/tree/<ref>/<path>]``
  resolves to the right git URL + subpath without the user thinking
  about it.

Total contract: every public function is fail-open (raises
``SkillImportError`` with a clear message; never bare exceptions).
Tests stub ``subprocess.run`` and ``urllib.request.urlopen``.
"""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
import tempfile
import urllib.parse
import urllib.request
import zipfile
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)


# ── Public types ────────────────────────────────────────────────────────────

class SkillImportError(Exception):
    """Raised when a source can't be resolved into a skill folder.

    Carries a human-readable message; UI/CLI surface it verbatim.
    """


@dataclass(frozen=True)
class ResolvedSource:
    """The outcome of resolving one ``source`` string.

    folder      Path to the local directory containing ``SKILL.md``.
                Lifetime is bounded by the enclosing context manager
                (cleaned up on exit unless ``kind == "local"``).
    kind        ``"local"`` / ``"zip"`` / ``"git"`` / ``"github"``.
    canonical   Stable identifier for provenance tracking
                (resolved URL, absolute local path, etc.). Goes into
                ``metadata.imported_from`` of the imported skill.
    """

    folder: Path
    kind: str
    canonical: str


# ── URL detection ───────────────────────────────────────────────────────────

# A GitHub shorthand looks like ``owner/repo`` (no scheme, no slashes
# beyond the one separator). We accept this as the most concise form a
# user might type. Resolved to ``https://github.com/owner/repo`` when
# the resolver runs.
_GITHUB_SHORTHAND = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*$")

# Explicit GitHub URL form. Optional ``/tree/<ref>/<path...>`` suffix
# means "this skill is at <path> inside the repo at <ref>".
_GITHUB_URL = re.compile(
    r"^https?://github\.com/(?P<owner>[A-Za-z0-9._-]+)/(?P<repo>[A-Za-z0-9._-]+)"
    r"(?:/tree/(?P<ref>[A-Za-z0-9._/-]+?)/(?P<path>.+))?/?$"
)


def detect_source_kind(source: str) -> str:
    """Classify a source string. Pure function — no I/O.

    Returns one of ``"local" | "zip" | "git" | "github"``.

    Order of precedence:
      1. Strings that resolve to a local path on disk → ``"local"``.
      2. ``http(s)://...zip`` → ``"zip"``.
      3. GitHub-shaped URL or shorthand → ``"github"``.
      4. ``http(s)://...git`` or ``git@...:...git`` → ``"git"``.
      5. Anything else with a scheme — best-effort ``"git"``.
      6. Otherwise ``"local"`` (lets the resolver fail with a clear
         FileNotFoundError if the path really doesn't exist).
    """
    s = source.strip()

    # Local path takes priority — even if a string LOOKS URL-y, an
    # actual directory wins.
    p = Path(s)
    if p.exists():
        return "local"

    if "://" in s:
        scheme, rest = s.split("://", 1)
        scheme = scheme.lower()
        if scheme in {"http", "https"}:
            if rest.lower().endswith(".zip"):
                return "zip"
            if _GITHUB_URL.match(s):
                return "github"
            if rest.lower().endswith(".git") or "/git/" in rest.lower():
                return "git"
            # Default for unknown HTTPS sources: treat as git so a
            # bare GitLab/Bitbucket repo URL works.
            return "git"
        # ssh-style git URLs use 'git' / no scheme; the prefix below
        # catches them.
        return "git"

    # SCP-style git: git@github.com:owner/repo.git
    if s.startswith("git@") or s.startswith("git+"):
        return "git"

    # Explicit github: prefix (e.g. ``github:owner/repo`` or
    # ``github:owner/repo/path/to/skill``).
    if s.startswith("github:"):
        return "github"

    # Bare GitHub shorthand
    if _GITHUB_SHORTHAND.match(s):
        return "github"

    return "local"


# ── GitHub URL parsing ──────────────────────────────────────────────────────

@dataclass(frozen=True)
class _GitHubTarget:
    """Parsed GitHub source: clone URL + optional subpath inside repo."""

    clone_url: str
    ref: str | None
    subpath: str | None


def _parse_github(source: str) -> _GitHubTarget:
    """Translate any accepted GitHub-shape into a clone URL + subpath."""
    s = source.strip()

    if _GITHUB_SHORTHAND.match(s):
        return _GitHubTarget(clone_url=f"https://github.com/{s}.git", ref=None, subpath=None)

    if s.startswith("github:"):
        # "github:owner/repo" or "github:owner/repo/path/to/skill"
        rest = s[len("github:"):]
        parts = rest.split("/", 2)
        if len(parts) < 2:
            raise SkillImportError(f"Invalid github shorthand: {source!r}")
        owner, repo = parts[0], parts[1]
        subpath = parts[2] if len(parts) == 3 and parts[2] else None
        return _GitHubTarget(
            clone_url=f"https://github.com/{owner}/{repo}.git",
            ref=None,
            subpath=subpath,
        )

    m = _GITHUB_URL.match(s)
    if m:
        owner = m.group("owner")
        repo = m.group("repo")
        # Strip trailing .git from repo name in URL form.
        if repo.endswith(".git"):
            repo = repo[:-4]
        return _GitHubTarget(
            clone_url=f"https://github.com/{owner}/{repo}.git",
            ref=m.group("ref") or None,
            subpath=m.group("path") or None,
        )

    raise SkillImportError(f"Not a recognizable GitHub source: {source!r}")


# ── Zip download + extract ──────────────────────────────────────────────────

# Hard caps so a malicious URL can't exhaust disk or memory. These are
# generous — a typical SKILL folder is <500 KB; 50 MB covers any
# reasonable bundled assets directory.
_ZIP_MAX_BYTES = 50 * 1024 * 1024  # 50 MB
_ZIP_MAX_FILES = 1000
_DOWNLOAD_TIMEOUT_SECONDS = 60


def _download_zip(url: str, dest_zip: Path) -> None:
    """Download ``url`` to ``dest_zip``. Caps at 50 MB."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "agntspace-skill-import/1"})
        with urllib.request.urlopen(req, timeout=_DOWNLOAD_TIMEOUT_SECONDS) as resp:  # noqa: S310 — controlled URLs only
            content_length = resp.headers.get("Content-Length")
            if content_length is not None:
                try:
                    if int(content_length) > _ZIP_MAX_BYTES:
                        raise SkillImportError(
                            f"Zip too large: {content_length} bytes (max {_ZIP_MAX_BYTES})"
                        )
                except ValueError:
                    pass  # malformed Content-Length — fall through to streaming check

            written = 0
            with open(dest_zip, "wb") as f:
                while True:
                    chunk = resp.read(64 * 1024)
                    if not chunk:
                        break
                    written += len(chunk)
                    if written > _ZIP_MAX_BYTES:
                        raise SkillImportError(
                            f"Zip exceeded {_ZIP_MAX_BYTES} bytes during download"
                        )
                    f.write(chunk)
    except SkillImportError:
        raise
    except Exception as exc:
        raise SkillImportError(f"Failed to download {url}: {exc}") from exc


def _extract_zip(zip_path: Path, dest_dir: Path) -> None:
    """Extract ``zip_path`` into ``dest_dir`` with path-traversal guards."""
    try:
        with zipfile.ZipFile(zip_path) as z:
            members = z.namelist()
            if len(members) > _ZIP_MAX_FILES:
                raise SkillImportError(
                    f"Zip contains {len(members)} entries (max {_ZIP_MAX_FILES})"
                )
            dest_resolved = dest_dir.resolve()
            for member in members:
                # Reject entries that would escape dest_dir via .. or
                # absolute paths. zipfile's extract has its own guards
                # but we add an explicit one for defense-in-depth.
                target = (dest_dir / member).resolve()
                if not str(target).startswith(str(dest_resolved)):
                    raise SkillImportError(f"Zip entry escapes target dir: {member!r}")
            z.extractall(dest_dir)
    except SkillImportError:
        raise
    except zipfile.BadZipFile as exc:
        raise SkillImportError(f"Not a valid zip file: {exc}") from exc
    except Exception as exc:
        raise SkillImportError(f"Failed to extract zip: {exc}") from exc


def _find_skill_root(extracted_dir: Path) -> Path:
    """Find the directory containing SKILL.md inside an extracted tree.

    Most public skill repos extract as a single top-level folder
    (``repo-main/``) with ``SKILL.md`` either at the root OR one level
    deep. We pick the SHALLOWEST SKILL.md to avoid picking up references/.
    """
    candidates = sorted(extracted_dir.rglob("SKILL.md"), key=lambda p: len(p.parts))
    if not candidates:
        raise SkillImportError(f"No SKILL.md found in {extracted_dir}")
    return candidates[0].parent


# ── Git clone ──────────────────────────────────────────────────────────────

def _clone_git(clone_url: str, dest_dir: Path, ref: str | None = None) -> None:
    """Shallow-clone ``clone_url`` into ``dest_dir``.

    Uses ``git clone --depth=1`` to keep the operation fast and small.
    When ``ref`` is provided, fetches that branch/tag/commit only.
    """
    git = shutil.which("git")
    if not git:
        raise SkillImportError(
            "git is not installed or not on PATH; cannot clone "
            f"{clone_url}. Install git, or use a zip URL instead."
        )

    cmd = [git, "clone", "--depth=1"]
    if ref:
        cmd += ["--branch", ref]
    cmd += [clone_url, str(dest_dir)]

    try:
        result = subprocess.run(  # noqa: S603 — args list, no shell
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise SkillImportError(f"git clone timed out after 120s: {clone_url}") from exc
    except Exception as exc:
        raise SkillImportError(f"git clone failed: {exc}") from exc

    if result.returncode != 0:
        # Trim stderr — git can be verbose; the first line is usually the cause.
        stderr = (result.stderr or result.stdout or "").strip().splitlines()
        first = stderr[0] if stderr else "(no output)"
        raise SkillImportError(f"git clone failed: {first}")


# ── Public resolver ─────────────────────────────────────────────────────────

@contextmanager
def resolve_source(source: str) -> Generator[ResolvedSource, None, None]:
    """Resolve ``source`` to a local skill folder, with cleanup.

    Use as a context manager::

        with resolve_source("github:owner/repo") as resolved:
            shutil.copytree(resolved.folder, dest)

    On exit, any temporary directory created (zip extraction or git
    clone) is removed. Local-path sources are NOT touched on exit
    since the folder belongs to the user.

    Raises:
        SkillImportError: when the source can't be fetched or doesn't
            contain a SKILL.md. The message is suitable for surfacing
            verbatim to the user.
    """
    s = source.strip()
    if not s:
        raise SkillImportError("source is empty")

    kind = detect_source_kind(s)

    if kind == "local":
        p = Path(s).resolve()
        if not p.exists():
            raise SkillImportError(f"Local path not found: {s}")
        # Accept either a folder containing SKILL.md, or a SKILL.md file
        if p.is_file() and p.name == "SKILL.md":
            p = p.parent
        if not p.is_dir():
            raise SkillImportError(f"Path is not a directory: {s}")
        if not (p / "SKILL.md").is_file():
            raise SkillImportError(f"No SKILL.md found in {s}")
        # Local sources don't need cleanup — yield directly.
        yield ResolvedSource(folder=p, kind="local", canonical=str(p))
        return

    # All remote kinds use a temp directory we clean up on exit.
    tmpdir = Path(tempfile.mkdtemp(prefix="agntspace-skill-import-"))
    try:
        if kind == "zip":
            zip_path = tmpdir / "source.zip"
            _download_zip(s, zip_path)
            extract_dir = tmpdir / "extracted"
            extract_dir.mkdir()
            _extract_zip(zip_path, extract_dir)
            try:
                zip_path.unlink()
            except OSError:
                pass
            folder = _find_skill_root(extract_dir)
            yield ResolvedSource(folder=folder, kind="zip", canonical=s)
            return

        if kind == "github":
            target = _parse_github(s)
            clone_dir = tmpdir / "clone"
            _clone_git(target.clone_url, clone_dir, ref=target.ref)
            base = clone_dir
            if target.subpath:
                # Reject paths that escape the clone via .. or absolutes.
                candidate = (clone_dir / target.subpath).resolve()
                if not str(candidate).startswith(str(clone_dir.resolve())):
                    raise SkillImportError(
                        f"GitHub subpath escapes clone root: {target.subpath!r}"
                    )
                if not candidate.is_dir():
                    raise SkillImportError(
                        f"GitHub subpath does not exist in repo: {target.subpath!r}"
                    )
                base = candidate
            folder = _find_skill_root(base)
            yield ResolvedSource(
                folder=folder,
                kind="github",
                canonical=target.clone_url + (f"#{target.subpath}" if target.subpath else ""),
            )
            return

        if kind == "git":
            clone_dir = tmpdir / "clone"
            _clone_git(s, clone_dir)
            folder = _find_skill_root(clone_dir)
            yield ResolvedSource(folder=folder, kind="git", canonical=s)
            return

        raise SkillImportError(f"Unknown source kind: {kind}")
    finally:
        # Best-effort cleanup. shutil.rmtree on Windows can fail when a
        # subprocess (git) hasn't released a handle; we swallow the
        # error so the caller doesn't get a misleading exception
        # AFTER a successful import.
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception as exc:  # pragma: no cover — best-effort
            log.debug("Failed to remove %s: %s", tmpdir, exc)


# ── Default category inference ──────────────────────────────────────────────

def default_category_for(kind: str) -> str:
    """Pick the right skill tier for a given source kind.

    * Local imports → ``private`` (user-authored, never shipped).
    * Remote imports (zip, git, github) → ``community`` (ecosystem-imported,
      hash-gated by SkillSync).

    Callers that want to override pass an explicit ``category`` arg.
    """
    if kind in {"zip", "git", "github"}:
        return "community"
    return "private"
