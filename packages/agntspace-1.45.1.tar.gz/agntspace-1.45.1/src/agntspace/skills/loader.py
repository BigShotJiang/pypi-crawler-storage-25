"""Skill loader: discovers, loads, and matches SKILL.md files.

Skill folder structure:
  system/skills/{category}/{name}/
  ├── SKILL.md           ← required: frontmatter (name, triggers, etc.) + instructions
  ├── templates/         ← optional: reusable templates (email, report, etc.)
  ├── examples/          ← optional: few-shot examples for the LLM
  ├── references/        ← optional: background docs the skill can reference
  └── config.md          ← optional: skill-specific settings
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import frontmatter

log = logging.getLogger(__name__)


@dataclass
class Skill:
    """A loaded skill definition."""

    name: str
    title: str
    description: str
    triggers: list[str] = field(default_factory=list)
    category: str = ""
    status: str = "active"
    body: str = ""
    path: str = ""
    # Additional files in the skill folder
    files: list[str] = field(default_factory=list)
    # Extended fields
    author: str = ""
    tools_granted: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    priority: int = 0
    model_tier: str = ""  # "reasoning", "capable", "fast", or "" (inherit)
    examples: list[dict] = field(default_factory=list)  # [{input, output}]
    output_format: str = ""
    # ── Versioning + provenance (spec follow-up) ──
    # Semver-style version string ("1.0.0"). Skills without a version
    # default to "0.0.0". Used by skill school and by user-visible
    # version-history queries.
    version: str = "0.0.0"
    # Optional signature blob (e.g. sha256:... of the canonicalized body).
    # Future work: verify against a trusted signer on load. Present now
    # so skill files can start carrying the field without a schema migration.
    signature: str = ""
    # Optional publisher identity (email, handle, or "user"). Default "user"
    # means the skill was authored in this vault and has no external origin.
    publisher: str = "user"
    # Content hash — sha256 of the skill body computed on load. Used to
    # detect tampering: if the stored `signature` doesn't match this hash,
    # the skill has been modified since signing.
    content_hash: str = ""
    # Arbitrary YAML config blocks (e.g., language, filters, thresholds)
    # — opaque to the loader, read by the owning service.
    config: dict = field(default_factory=dict)
    # Filesystem mtime of SKILL.md, epoch seconds. Populated on load. Used
    # by the UI to sort by "latest imported/edited" and to surface recently
    # touched skills. Zero when unavailable (unlikely).
    modified_at: float = 0.0
    # ── Semantic retrieval cache (Voyager-style, 2026-04-24) ──
    # Opaque embedding vector for `{description} {triggers}`. Populated
    # by SkillLoader.set_embedder() when a VaultEmbeddings provider is
    # wired; consumed by find_matching_skills() for cosine similarity.
    # Stored as a plain list[float] (not numpy.ndarray) so the Skill
    # dataclass stays serializable and numpy stays an optional dep.
    embedding: list[float] | None = None


class SkillLoader:
    """Discovers and loads SKILL.md files from the skills directory."""

    def __init__(self, skills_dir: Path) -> None:
        self._skills_dir = skills_dir
        self._skills: dict[str, Skill] = {}
        self._loaded = False
        self._full_prompt_cache: str | None = None
        # Semantic-retrieval support (Voyager-style, 2026-04-24). Set
        # post-init via `set_embedder()` once VaultEmbeddings is wired.
        # When None, `find_matching_skills()` returns `[]` (fail-open)
        # and no skill embeddings are computed.
        self._embedder: object | None = None

    def load_all(self) -> dict[str, Skill]:
        """Scan skills directory and load all SKILL.md files."""
        self._skills.clear()
        self._full_prompt_cache = None

        if not self._skills_dir.is_dir():
            log.info("Skills directory not found: %s", self._skills_dir)
            self._loaded = True
            return self._skills

        for skill_file in self._skills_dir.rglob("SKILL.md"):
            try:
                self._load_skill(skill_file)
            except Exception:
                log.warning("Failed to load skill: %s", skill_file)

        self._loaded = True
        # Validate depends_on references
        for sname, skill in self._skills.items():
            for dep in skill.depends_on:
                if dep not in self._skills:
                    log.warning("Skill '%s' depends on unknown skill '%s'", sname, dep)
        log.debug("Loaded %d skills from %s", len(self._skills), self._skills_dir)
        return self._skills

    @property
    def skills(self) -> dict[str, Skill]:
        if not self._loaded:
            self.load_all()
        return self._skills

    def get_skill(self, name: str) -> Skill | None:
        """Get a skill by name."""
        return self.skills.get(name)

    def get_system_prompt(self, skill_name: str) -> str | None:
        """Get the System Prompt section from a skill's body.

        Skills define LLM prompts in a ``## System Prompt`` section.
        Returns the content of that section, or the full body as fallback.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.body:
            return None

        # Try to extract ## System Prompt section
        marker = "## System Prompt"
        idx = skill.body.find(marker)
        if idx == -1:
            # Fallback: use entire body as the prompt
            return skill.body.strip()

        # Extract from marker to next ## heading or end
        content = skill.body[idx + len(marker):]
        # Find next ## heading (not a subsection)
        next_heading = content.find("\n## ")
        if next_heading != -1:
            content = content[:next_heading]
        return content.strip()

    def get_skill_section(self, skill_name: str, section: str) -> str | None:
        """Get a named section (e.g. '## Week') from a skill's body.

        Returns content between the heading and the next same-level heading,
        or None if not found.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.body:
            return None

        marker = f"## {section}"
        idx = skill.body.find(marker)
        if idx == -1:
            return None

        content = skill.body[idx + len(marker):]
        next_heading = content.find("\n## ")
        if next_heading != -1:
            content = content[:next_heading]
        return content.strip()

    def get_skill_config(self, skill_name: str, block: str) -> dict:
        """Get a YAML config block, falling back from frontmatter to ``config/<block>.yaml``.

        Resolution order (2026-04-28 unified fix — preserves
        backwards compat while closing the silent-failure trap that
        affected 6 production call sites):

        1. **Frontmatter** ``block:`` key under the SKILL.md
           ``---`` fence. This was the only path the original
           implementation supported. Still wins on conflict.

        2. **`config/<block>.yaml`** sibling file. When the frontmatter
           lookup is empty, the loader reads the matching config file
           via :py:meth:`load_skill_config_file`. Two shapes are
           recognized:

           a. **Wrapped** — the file's top level has a ``<block>:`` key
              whose value is a dict (the ``themes.yaml`` shape). The
              wrapped value is returned.
           b. **Flat** — the file is a dict whose top-level keys are
              themselves the configuration (the ``pacing.yaml``,
              ``retrieval.yaml``, ``audit.yaml``, ``pricing.yaml``
              shape). The whole dict is returned.

        Examples::

            # SKILL.md frontmatter form (legacy):
            #   ---
            #   language:
            #     output_policy: source
            #   ---
            cfg = loader.get_skill_config("kb-ingest", "language")
            cfg["output_policy"]  # "source"

            # config/<block>.yaml flat form:
            #   ─ defaults/.../heartbeat-pulse/config/pacing.yaml
            #     enabled: false
            #     quiet_hours:
            #       start: "22:00"
            cfg = loader.get_skill_config("heartbeat-pulse", "pacing")
            cfg["enabled"]  # False

            # config/<block>.yaml wrapped form:
            #   ─ defaults/.../presentation-themes/config/themes.yaml
            #     themes:
            #       minimalist: ...
            cfg = loader.get_skill_config("presentation-themes", "themes")
            cfg["minimalist"]  # ...

        Returns an empty dict if neither path yields a dict. Never raises.

        Why the unified fallback exists: before this fix, six unrelated
        consumers (skill-retrieval, reflexion-protocol, heartbeat-pulse,
        transaction-audit, transaction-categorize, model-routing) were
        calling ``get_skill_config(name, block)`` expecting it to read
        their YAML strategy files. It silently returned ``{}`` for
        every one — every consumer fell back to hardcoded defaults.
        Tests passed because each test stubbed the loader. Production
        users editing YAML saw zero effect. This fallback is the
        architectural fix that closes the entire class of bug at once.
        """
        skill = self.get_skill(skill_name)
        if not skill:
            return {}
        # Path 1: frontmatter — original behavior, wins on conflict.
        cfg = skill.config.get(block)
        if isinstance(cfg, dict):
            return cfg
        # Path 2: config/<block>.yaml fall-through. Never raises —
        # broken file or missing dir returns the original empty dict.
        try:
            doc = self.load_skill_config_file(skill_name, f"{block}.yaml")
        except Exception:
            return {}
        if not isinstance(doc, dict):
            return {}
        # Wrapped shape: file's top level has a key matching block.
        wrapped = doc.get(block)
        if isinstance(wrapped, dict):
            return wrapped
        # Flat shape: the entire file IS the block.
        return doc

    def load_skill_config_file(self, skill_name: str, filename: str) -> object:
        """Load a YAML file from a skill's ``config/`` directory.

        This is the Rule 12 strategy loader — services call it to read
        their strategy YAML without knowing how skills are laid out on
        disk. Search order mirrors how the rest of the skill system
        resolves files:

          1. ``{skill.path}/config/{filename}``  — the skill's own config dir,
             which lives next to SKILL.md. Users editing their vault copy
             override the bundled default transparently because the
             skills directory itself is already vault-first.

        Returns the parsed YAML contents (usually dict or list), or
        ``None`` if the file doesn't exist or can't be parsed. Never raises.

        Example::

            # defaults/skills/core/kb-ingest/config/junk-patterns.yaml
            en:
              - "none mentioned"
              - "tbd"
            sv:
              - "inget nämnt"

            # in Python:
            data = loader.load_skill_config_file("kb-ingest", "junk-patterns.yaml")
            # → {"en": ["none mentioned", "tbd"], "sv": ["inget nämnt"]}

        Services that need a flat multilingual keyword list should
        continue to use ``infra.language_patterns.load_keywords`` which
        already knows how to flatten ``{lang: [...]}`` into a single
        lowercased tuple. This helper is the generic counterpart for
        everything that isn't a keyword list — thresholds, tables,
        rules, templates, decision trees.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.path:
            return None
        # `skill.path` is relative to `self._skills_dir` and points at the
        # SKILL.md file itself — e.g. ``core/kb-ingest/SKILL.md``. We resolve
        # the sibling ``config/`` dir by taking the parent and joining back
        # under the skills directory root.
        skill_rel = Path(skill.path)
        if skill_rel.name == "SKILL.md":
            skill_rel = skill_rel.parent
        config_path = self._skills_dir / skill_rel / "config" / filename
        if not config_path.is_file():
            return None
        try:
            import yaml  # type: ignore
        except ImportError:
            log.warning("PyYAML not installed — cannot load %s", config_path)
            return None
        try:
            with open(config_path, encoding="utf-8") as f:
                return yaml.safe_load(f)
        except Exception as e:
            log.warning("Failed to load skill config %s: %s", config_path, e)
            return None

    def resolve_skill_language(
        self,
        skill_name: str,
        source_text: str,
        *,
        source_meta: dict | None = None,
        global_policy: str | None = None,
        user_locale: str = "en",
    ) -> tuple[str, str, str, str, str]:
        """Resolve the three-language chain for any skill that has a `language:` block.

        Spec §19 item 2 — per-skill language config for skills outside of
        kb-ingest (memory-consolidate, daily-reflection, weekly-reflection,
        journal generation, etc.). Returns (content_lang, output_lang,
        effective_policy, policy_source, directive) so services can inject
        the directive into their system prompt without reimplementing the
        chain.

        Falls back gracefully if the skill has no language block: returns
        the detected source language with policy="source" and a matching
        directive.

        Never raises.
        """
        from agntspace.infra.language import (
            build_language_directive,
            resolve_languages,
        )
        skill_cfg = self.get_skill_config(skill_name, "language")
        try:
            content_lang, output_lang, policy, policy_source = resolve_languages(
                source_text,
                source_meta=source_meta,
                skill_config=skill_cfg,
                kb_schema=None,
                global_policy=global_policy,
                user_locale=user_locale,
            )
            directive = build_language_directive(content_lang, output_lang)
            return content_lang, output_lang, policy, policy_source, directive
        except Exception:
            # Never break the caller on a language-resolution failure
            return "en", "en", "source", "default", ""

    def get_skill_rules(self, skill_name: str) -> str:
        """Get the Quality Rules and Rules sections from a skill body.

        These are appended to LLM prompts as additional constraints.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.body:
            return ""

        rules_parts: list[str] = []
        for section in ("## Quality Rules", "## Rules"):
            idx = skill.body.find(section)
            if idx != -1:
                content = skill.body[idx:]
                # Find next ## heading that isn't a subsection
                lines = content.split("\n")
                end = len(lines)
                for i, line in enumerate(lines[1:], 1):
                    if line.startswith("## ") and not line.startswith("### "):
                        end = i
                        break
                rules_parts.append("\n".join(lines[:end]).strip())

        return "\n\n".join(rules_parts)

    def match_skills(self, text: str) -> list[Skill]:
        """Find skills that match user input based on triggers."""
        lower = text.lower()
        matches = []
        for skill in self.skills.values():
            if skill.status != "active":
                continue
            for trigger in skill.triggers:
                if trigger.lower() in lower:
                    matches.append(skill)
                    break
        return matches

    # ─── Semantic retrieval (Voyager-style, 2026-04-24) ───

    def set_embedder(self, embedder: object | None) -> None:
        """Wire an embedding provider and compute skill embeddings in bulk.

        The provider must expose a `_get_model()` method returning an
        object with ``.embed(list[str]) -> iterable[iterable[float]]``
        (mirrors the VaultEmbeddings shape — OllamaEmbedModel today,
        any fastembed-compatible stub in tests). Passing ``None`` clears
        the embedder and any cached skill embeddings.

        Never raises — any provider failure (Ollama unreachable, model
        not pulled, network hiccup) leaves all skill embeddings at
        ``None`` and the loader falls back to priority-ordered
        non-semantic paths exactly as before.
        """
        self._embedder = embedder
        if embedder is None:
            for skill in self._skills.values():
                skill.embedding = None
            return
        self._compute_skill_embeddings()

    def _skill_embedding_text(self, skill: Skill) -> str:
        """Assemble the text we embed for a skill.

        Description is the load-bearing signal (authored to describe what
        the skill DOES), triggers are secondary but helpful for short
        task queries ("run wiki job" → matches a skill whose description
        is vague but trigger is exact). Title adds diversity.

        Category is deliberately EXCLUDED — it's metadata (``core`` /
        ``_meta`` / ``creative``), not a semantic descriptor. A skill
        that only has a category and nothing else returns ``""`` so the
        caller skips embedding it entirely — matching against "core"
        would be noise, not signal.
        """
        parts = [skill.title, skill.description]
        if skill.triggers:
            parts.append(" ".join(skill.triggers))
        return " ".join(p for p in parts if p).strip()

    def _compute_skill_embeddings(self) -> None:
        """Batch-embed every active skill's descriptor text. Fail-open."""
        if self._embedder is None:
            return
        try:
            model = self._embedder._get_model()  # noqa: SLF001 — mirrors VaultEmbeddings shape
        except Exception:
            log.debug("SkillLoader: embedder model unavailable", exc_info=True)
            return

        active = [s for s in self._skills.values() if s.status == "active"]
        # Skip empty descriptors — embedding an empty string is wasteful
        # and most embedding models return zero vectors or error on them.
        indexed = [(i, s) for i, s in enumerate(active) if self._skill_embedding_text(s)]
        if not indexed:
            return

        texts = [self._skill_embedding_text(s) for _, s in indexed]
        try:
            vectors = list(model.embed(texts))
        except Exception:
            log.debug("SkillLoader: batch embed failed", exc_info=True)
            return

        if len(vectors) != len(indexed):
            log.warning(
                "SkillLoader: embedder returned %d vectors for %d skills — skipping cache",
                len(vectors), len(indexed),
            )
            return

        for (_, skill), vec in zip(indexed, vectors, strict=False):
            try:
                # Coerce to plain list[float] for dataclass serializability
                # (cache file, /api/skills). Works for both Ollama's
                # list[float] and any fastembed-shaped numpy ndarray in tests.
                skill.embedding = [float(x) for x in vec]
            except Exception:
                skill.embedding = None

    def find_matching_skills(
        self,
        task_text: str,
        top_k: int = 5,
        scope: list[str] | None = None,
        min_score: float = 0.0,
    ) -> list[tuple[str, float]]:
        """Return the top_k skills most semantically related to ``task_text``.

        Args:
            task_text: free-form task description or user message.
            top_k: maximum number of matches to return.
            scope: optional allowlist of skill names; when provided, only
                these are considered. Useful when a subagent has a fixed
                skill set and we want top-k within that set.
            min_score: cosine-similarity floor; hits below this are dropped.
                Defaults to 0 so NO filtering — callers set a threshold
                when they care about quality over quantity.

        Returns:
            List of ``(skill_name, cosine_score)`` tuples, sorted score-
            descending. Empty list when the embedder is not wired, the
            query embed fails, or no skills have cached embeddings.
            Fail-open throughout — callers should treat empty as "fall
            back to priority-ordered everything."
        """
        if not task_text or not task_text.strip():
            return []
        if self._embedder is None:
            return []
        try:
            model = self._embedder._get_model()  # noqa: SLF001
        except Exception:
            return []

        try:
            query_vec = list(model.embed([task_text]))
            if not query_vec:
                return []
            qv = query_vec[0]
            # Normalize once — bge-m3 vectors are already L2-normalized,
            # but we defensive-normalize in case a different model is
            # swapped in (nomic-embed-text, multilingual-e5, etc.).
            qnorm = sum(float(x) * float(x) for x in qv) ** 0.5 or 1.0
            qv_norm = [float(x) / qnorm for x in qv]
        except Exception:
            log.debug("SkillLoader: query embed failed", exc_info=True)
            return []

        scope_set = set(scope) if scope else None
        results: list[tuple[str, float]] = []
        for skill in self._skills.values():
            if skill.status != "active":
                continue
            if scope_set is not None and skill.name not in scope_set:
                continue
            if not skill.embedding:
                continue
            # Cosine = dot product when both vectors are L2-normalized.
            # Skill vectors may have drifted from unit length if the
            # model returned unnormalized output — normalize defensively.
            sv = skill.embedding
            snorm = sum(x * x for x in sv) ** 0.5 or 1.0
            dot = sum(float(a) * float(b) for a, b in zip(qv_norm, sv, strict=False)) / snorm
            if dot < min_score:
                continue
            results.append((skill.name, dot))

        results.sort(key=lambda t: t[1], reverse=True)
        return results[:top_k]

    def get_metadata_summary(self) -> str:
        """Get a compact summary of available skills for the system prompt."""
        active = [s for s in self.skills.values() if s.status == "active"]
        active.sort(key=lambda s: s.priority, reverse=True)
        lines = []
        for skill in active:
            triggers_str = ", ".join(skill.triggers[:3]) if skill.triggers else "manual"
            extras = ""
            if skill.priority > 0:
                extras += f" [P{skill.priority}]"
            if skill.files:
                extras += f" [+{len(skill.files)} files]"
            lines.append(
                f"- **{skill.title}** ({skill.name}): {skill.description} "
                f"[triggers: {triggers_str}]{extras}"
            )
        return "\n".join(lines) if lines else "No skills loaded."

    # arch:deterministic — fallback char caps when no YAML override.
    # Sensible defaults: brand-guide.md is ~1.2 KB; even 5 reference
    # files at 8 KB each cap at 40 KB per skill section, plenty of
    # headroom under the system prompt budget.
    _MAX_REFERENCE_CHARS_PER_FILE = 8000
    _MAX_REFERENCE_CHARS_PER_SKILL = 32000
    _REFERENCE_TEXT_EXTS = (".md", ".txt", ".rst")  # arch:deterministic — text-file extensions for skill reference-file loading; structural to the loader, not strategy

    def _load_reference_files(self, skill: Skill) -> list[tuple[str, str, bool]]:
        """Read every text file under the skill's ``references/`` subdir.

        Returns ``[(rel_path, content, truncated), ...]`` capped at
        the per-file char limit. Files outside ``references/``, or
        with non-text extensions (config YAML, JSON), are skipped —
        config files are read by services at runtime, not by the LLM.

        2026-04-28 fix (`archer-presentation` regression): the skill
        body said "Read @references/brand-guide.md for full company
        details" but the loader never inlined the content, so the
        agent had no way to satisfy the directive. Solved by reading
        the file at load time and appending under a ``### References``
        subsection in the prompt.
        """
        out: list[tuple[str, str, bool]] = []
        if not skill.path or not skill.files:
            return out
        # ``skill.path`` is RELATIVE to ``self._skills_dir`` (see the
        # ``path=str(path.relative_to(self._skills_dir))`` write site
        # in ``_load_skill``). Resolve against ``_skills_dir`` to get
        # the absolute skill directory.
        skill_dir = (self._skills_dir / Path(skill.path).parent).resolve()
        if not skill_dir.is_dir():
            return out
        cap_per_file = int(self._MAX_REFERENCE_CHARS_PER_FILE)
        for rel in skill.files:
            # Only inline files explicitly under ``references/``.
            # Config YAML, JSON, and other non-reference files are
            # excluded — they're for engines, not the LLM.
            if not rel.startswith("references/"):
                continue
            ext = Path(rel).suffix.lower()
            if ext not in self._REFERENCE_TEXT_EXTS:
                continue
            full = skill_dir / rel
            try:
                content = full.read_text(encoding="utf-8")
            except Exception:
                # Unreadable file (binary, permission, etc.) — skip
                # silently. The skill still loads.
                continue
            truncated = False
            if len(content) > cap_per_file:
                content = content[:cap_per_file] + "\n\n[truncated]"
                truncated = True
            out.append((rel, content, truncated))
        return out

    def get_full_prompt_section(self) -> str:
        """Get full skill instructions for the system prompt (cached after first build).

        Includes the complete body of every active skill so the agent
        can actually follow the instructions, not just know names.
        Skills ordered by priority (higher first).

        2026-04-28 (archer-presentation regression fix): also inlines
        the contents of every file under ``<skill>/references/`` with
        a ``.md`` / ``.txt`` / ``.rst`` extension, so skill bodies can
        legitimately reference brand guides, style sheets, glossaries,
        etc., and the LLM actually sees them. Per-file char cap +
        per-skill total cap prevent prompt bloat on skills with very
        large reference material.
        """
        if self._full_prompt_cache is not None:
            return self._full_prompt_cache

        active = [
            s for s in self.skills.values()
            if s.status == "active" and s.body.strip()
        ]
        if not active:
            return "No skills loaded."

        active.sort(key=lambda s: s.priority, reverse=True)
        sections = []
        for skill in active:
            triggers_str = ", ".join(skill.triggers) if skill.triggers else "always active"
            parts = [
                f"## {skill.title} ({skill.name})",
                f"*Triggers: {triggers_str}*\n",
                skill.body.strip(),
            ]
            if skill.examples:
                parts.append("\n### Examples")
                for ex in skill.examples:
                    inp = ex.get("input", "")
                    out = ex.get("output", "")
                    parts.append(f"**Input:** {inp}\n**Output:** {out}\n")
            if skill.output_format:
                parts.append(f"\n### Expected Output Format\n{skill.output_format}")

            # Inline reference files. Skills authored with `@references/X`
            # directives in their bodies can finally have those
            # directives satisfied — the LLM sees the content directly.
            ref_files = self._load_reference_files(skill)
            if ref_files:
                cap_total = int(self._MAX_REFERENCE_CHARS_PER_SKILL)
                total = 0
                ref_parts: list[str] = ["\n### References"]
                listed_only: list[str] = []
                for rel, content, truncated in ref_files:
                    block_size = len(content) + len(rel) + 16
                    if total + block_size > cap_total:
                        listed_only.append(rel)
                        continue
                    suffix = " (truncated)" if truncated else ""
                    ref_parts.append(f"\n#### {rel}{suffix}\n\n{content}\n")
                    total += block_size
                if listed_only:
                    ref_parts.append(
                        "\n#### Additional reference files (not inlined — exceeded skill budget):\n"
                        + "\n".join(f"- {r}" for r in listed_only)
                    )
                parts.extend(ref_parts)

            sections.append("\n".join(parts))
        result = "\n\n---\n\n".join(sections)
        self._full_prompt_cache = result
        return result

    def list_skills(self) -> list[dict]:
        """List all skills with metadata (for API/UI)."""
        return [
            {
                "name": s.name,
                "title": s.title,
                "description": s.description,
                "category": s.category,
                "status": s.status,
                "triggers": s.triggers,
                "path": s.path,
                "files": s.files,
                "author": s.author,
                "tools_granted": s.tools_granted,
                "depends_on": s.depends_on,
                "priority": s.priority,
                "model_tier": s.model_tier,
                "examples": s.examples,
                "output_format": s.output_format,
                "modified_at": s.modified_at,
            }
            for s in self.skills.values()
        ]

    def get_skill_file(self, skill_name: str, filename: str) -> str | None:
        """Read an additional file from a skill folder."""
        skill = self.get_skill(skill_name)
        if not skill:
            return None
        skill_dir = self._skills_dir / Path(skill.path).parent
        file_path = skill_dir / filename
        if file_path.is_file() and file_path.resolve().is_relative_to(self._skills_dir.resolve()):
            return file_path.read_text(encoding="utf-8")
        return None

    @staticmethod
    def _stat_mtime(path: Path) -> float:
        """Return mtime of `path` in epoch seconds, 0.0 on failure."""
        try:
            return path.stat().st_mtime
        except OSError:
            return 0.0

    @staticmethod
    def _read_field(meta: dict, key: str, default: object = None) -> object:
        """Read a field from the legacy flat form OR a spec-form ``metadata:`` block.

        Phase 2 dual-read (agentskills.io spec compliance, 2026-04-27):
        existing skills carry behavioral fields at the top level; ecosystem
        skills (Goose / Letta / Cursor / Copilot) move them under ``metadata:``
        per the spec. The loader accepts either layout.

        Resolution order: top-level wins on conflict — top-level is the
        legacy form and remains the authoritative source for AgntSpace's
        own skills. ``metadata:`` is consulted only when the field is
        absent at the top level.

        Returns ``default`` when neither location contains ``key``.
        """
        if key in meta:
            return meta[key]
        nested = meta.get("metadata")
        if isinstance(nested, dict) and key in nested:
            return nested[key]
        return default

    @staticmethod
    def _read_tools_granted(meta: dict) -> list[str]:
        """Resolve tool grants from either form (Phase 2 dual-read).

        Two accepted shapes:

        * Legacy: ``tools_granted: [read_inbox, query_knowledge]`` (YAML list)
        * Spec:   ``allowed-tools: "read_inbox query_knowledge"`` (space-separated)

        Either may appear at the top level OR under ``metadata:``. When both
        are present anywhere in the file, the legacy list wins — it's the
        closer match to AgntSpace's internal model and avoids the
        permission-predicate string format (``Bash(git:*)``) which our tool
        registry doesn't understand. Predicates pass through verbatim;
        ecosystem clients that consume the export will see them intact.

        Returns ``[]`` when no grants are declared anywhere.
        """
        legacy = SkillLoader._read_field(meta, "tools_granted")
        if isinstance(legacy, list):
            return [str(t) for t in legacy if t]

        spec = SkillLoader._read_field(meta, "allowed-tools")
        if isinstance(spec, str):
            return [t for t in spec.split() if t]

        return []

    def _load_skill(self, path: Path) -> None:
        """Load a single skill file and discover additional files."""
        raw = path.read_text(encoding="utf-8")
        # Tolerate UTF-8 BOM prefix — some editors (e.g. Windows Notepad, a few
        # PKM tools) write BOM'd files. Without this strip, frontmatter.loads
        # fails to recognise the leading `---` fence and returns empty metadata,
        # which makes the skill load under `path.stem` ("SKILL") with no title,
        # triggers, or description.
        if raw.startswith("\ufeff"):
            raw = raw.lstrip("\ufeff")
        post = frontmatter.loads(raw)
        meta = post.metadata

        # Fall back to the folder name when metadata is missing — `path.stem`
        # for SKILL.md is the literal string "SKILL", which is never what the
        # user means. Skills live at `.../skills/<category>/<slug>/SKILL.md`,
        # so `path.parent.name` is the slug the user recognises.
        default_name = path.parent.name if path.name == "SKILL.md" else path.stem
        name = meta.get("name", default_name)
        if name in self._skills:
            return

        # Discover additional files in the skill folder
        skill_dir = path.parent
        extra_files: list[str] = []
        if skill_dir.is_dir():
            for f in sorted(skill_dir.rglob("*")):
                if not f.is_file():
                    continue
                if f.name in ("SKILL.md", ".gitkeep"):
                    continue
                try:
                    rel = str(f.relative_to(skill_dir)).replace("\\", "/")
                    extra_files.append(rel)
                except ValueError:
                    pass

        # Parse priority safely (Phase 2 dual-read: top-level OR metadata:).
        try:
            priority = int(self._read_field(meta, "priority", 0))
        except (ValueError, TypeError):
            priority = 0

        # Pull structured YAML blocks that are neither known Skill fields
        # nor prompt text. These live under the `config` dict so services
        # can read them (e.g. kb-ingest reads `language.output_policy`).
        #
        # Phase 2: spec-defined top-level keys (`license`, `compatibility`,
        # `metadata`, `allowed-tools`) are added so they don't pollute
        # `config_blocks`. The `metadata` key is the spec home for
        # extensions and we already drained behavioral fields from it via
        # `_read_field`; treating it as a config block would double-count.
        _KNOWN_META = {
            # spec mandatory + optional
            "name", "description", "license", "compatibility",
            "metadata", "allowed-tools",
            # AgntSpace flat extensions
            "title", "triggers", "category", "status", "author",
            "tools_granted", "depends_on", "priority", "model_tier",
            "examples", "output_format",
            "version", "signature", "publisher",
        }
        config_blocks: dict = {}
        # Top-level config blocks (legacy form: `language: {...}` etc.)
        for k, v in meta.items():
            if k in _KNOWN_META:
                continue
            if isinstance(v, dict):
                config_blocks[k] = v
        # Spec-form config blocks (under `metadata:`). Top-level wins on
        # name conflict — the legacy author was explicit; the spec-form
        # entry is the back-compat fallback.
        nested_meta = meta.get("metadata")
        if isinstance(nested_meta, dict):
            for k, v in nested_meta.items():
                if k in _KNOWN_META or k in config_blocks:
                    continue
                if isinstance(v, dict):
                    config_blocks[k] = v

        # Compute content hash for tamper detection (skill body only — meta
        # is allowed to change without invalidating a signature).
        import hashlib
        content_hash = hashlib.sha256(post.content.encode("utf-8")).hexdigest()

        # Signature verification (gap #8 — signed-skill runtime).
        # Status / signature / publisher are dual-read so a spec-form skill
        # can carry these under `metadata:` without breaking signing.
        from agntspace.skills.signing import verify_signature
        raw_status = str(self._read_field(meta, "status", "active"))
        raw_signature = str(self._read_field(meta, "signature", ""))
        raw_publisher = str(self._read_field(meta, "publisher", "user"))
        sig_status, sig_reason = verify_signature(
            post.content, raw_signature, publisher=raw_publisher,
        )
        effective_status = raw_status
        if sig_status in ("invalid", "untrusted_publisher"):
            # Tampered or unverifiable signed skill — quarantine to keep it
            # out of the agent's system prompt until the user rewrites,
            # re-signs, or adds the publisher to the trust store.
            effective_status = "quarantined"
            log.warning(
                "Skill '%s' has a %s signature (%s) and was quarantined",
                name, sig_status, sig_reason,
            )

        # Phase 2 dual-read: every behavioral field reads from top-level
        # OR `metadata:`. `name` and `description` stay top-level-only per
        # spec (the spec mandates them at the top level).
        self._skills[name] = Skill(
            name=name,
            title=self._read_field(meta, "title", name),
            description=meta.get("description", ""),
            triggers=self._read_field(meta, "triggers", []),
            category=self._read_field(
                meta, "category",
                path.parent.parent.name if path.name == "SKILL.md" else path.parent.name,
            ),
            status=effective_status,
            body=post.content,
            path=str(path.relative_to(self._skills_dir)),
            files=extra_files,
            author=self._read_field(meta, "author", ""),
            tools_granted=self._read_tools_granted(meta),
            depends_on=self._read_field(meta, "depends_on", []),
            priority=priority,
            model_tier=self._read_field(meta, "model_tier", ""),
            examples=self._read_field(meta, "examples", []),
            output_format=self._read_field(meta, "output_format", ""),
            version=str(self._read_field(meta, "version", "0.0.0")),
            signature=raw_signature,
            publisher=str(self._read_field(meta, "publisher", "user")),
            content_hash=content_hash,
            config=config_blocks,
            modified_at=self._stat_mtime(path),
        )
