"""Validator for the agentskills.io specification.

Targets the spec at https://agentskills.io/specification (snapshot 2026-04-27).

The validator is pure and never raises. Callers receive a ValidationReport
with structured issues. Each issue has a stable error code so callers can
build UI labels, CI guards, or fix-it tools without parsing free-text.

Spec summary (full text in docs/agentskills-spec.md when that ships):

REQUIRED frontmatter:
    name         max 64 chars, lowercase alphanumeric + hyphens, no leading
                 or trailing hyphen, no consecutive hyphens, must match the
                 parent-directory name.
    description  1-1024 chars, non-empty after trim. Should describe what
                 the skill does AND when to use it.

OPTIONAL frontmatter:
    license       string (e.g. "Apache-2.0", license name, or LICENSE.txt ref)
    compatibility 1-500 chars (environment requirements, intended product, etc.)
    metadata      arbitrary key-value mapping for client-specific extensions
    allowed-tools space-separated string of pre-approved tools (experimental)

BODY: any markdown content; spec recommends <500 lines / <5000 tokens.

Anything outside this set is a warning (not an error) — the spec is silent
on extra top-level keys, ecosystem clients tolerate them, but they're
flagged so authors can deliberately choose between leaving them flat or
moving them under metadata:.

Lessons applied:
- Strip UTF-8 BOM before parsing (some editors prefix files with \\ufeff;
  YAML parsers silently return empty metadata otherwise).
- Never raise. Internal exceptions (PyYAML, IO) become E_INTERNAL issues
  so the validator is safe to call inside CI loops, request handlers,
  and prompt builders without try/except wrappers.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path

import yaml

# ── Spec constants (snapshot 2026-04-27) ────────────────────────────────────

NAME_MAX_LEN = 64
DESCRIPTION_MAX_LEN = 1024
COMPATIBILITY_MAX_LEN = 500

# Per spec: "May only contain unicode lowercase alphanumeric characters
# (a-z) and hyphens. Must not start or end with a hyphen. Must not
# contain consecutive hyphens." Spec's "(a-z)" parenthetical is just
# clarifying "lowercase letters"; "alphanumeric" admits 0-9 and that
# matches ecosystem behavior (Goose, Letta, Cursor accept digits).
NAME_PATTERN = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

# Spec-defined top-level frontmatter keys. Anything else is a warning.
SPEC_TOP_LEVEL_KEYS: frozenset[str] = frozenset({
    "name",
    "description",
    "license",
    "compatibility",
    "metadata",
    "allowed-tools",
})

# AgntSpace-specific top-level extensions we deliberately keep flat.
# The validator treats these as warnings just like any other unknown
# field — but they're documented here so the warning suppression list
# is reviewable. (Phase 3 migration may move some to metadata; until
# then, the warning is informational, not blocking.)
AGNTSPACE_KNOWN_EXTRAS: frozenset[str] = frozenset({
    "title",
    "category",
    "status",
    "author",
    "triggers",
    "priority",
    "model_tier",
    "tools_granted",
    "depends_on",
    "examples",
    "output_format",
    "version",
    "signature",
    "publisher",
    "content_hash",
    "language",
    "agent",
    "scraping",
    "quality",
    "relevance",
    "images",
})


# ── Result types ────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ValidationIssue:
    """One structured finding from validation.

    code      stable identifier (e.g. ``E_NAME_TOO_LONG``); UIs and CI
              loops switch on this rather than parsing ``message``.
    severity  ``"error"`` blocks compliance; ``"warning"`` is informational.
    field     ``"name"`` / ``"description"`` / ``"_frontmatter"`` etc.
              ``""`` for whole-file issues.
    message   human-readable explanation.
    """

    code: str
    severity: str
    field: str
    message: str


@dataclass
class ValidationReport:
    """Result of validating one SKILL.md file or text."""

    path: str = ""
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def valid(self) -> bool:
        """True iff no errors (warnings are tolerated)."""
        return not any(i.severity == "error" for i in self.issues)

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "valid": self.valid,
            "errors": [
                {"code": i.code, "field": i.field, "message": i.message}
                for i in self.errors
            ],
            "warnings": [
                {"code": i.code, "field": i.field, "message": i.message}
                for i in self.warnings
            ],
        }

    def add_error(self, code: str, field_name: str, message: str) -> None:
        self.issues.append(
            ValidationIssue(code=code, severity="error", field=field_name, message=message)
        )

    def add_warning(self, code: str, field_name: str, message: str) -> None:
        self.issues.append(
            ValidationIssue(code=code, severity="warning", field=field_name, message=message)
        )


# ── Helpers ─────────────────────────────────────────────────────────────────

def _strip_bom(text: str) -> str:
    """Strip UTF-8 BOM if present.

    Some editors (Windows Notepad, certain PKM tools) prefix files
    with \\ufeff. PyYAML and python-frontmatter silently return empty
    metadata when the BOM is present, so the validator must strip it
    before parsing. Documented in tasks/lessons.md (2026-04-18).
    """
    if text.startswith("﻿"):
        return text.lstrip("﻿")
    return text


def _split_frontmatter(text: str) -> tuple[str | None, str]:
    """Return ``(frontmatter_yaml, body)`` or ``(None, original_text)``.

    Frontmatter must start with a line of exactly ``---`` and end with
    another line of exactly ``---``. The middle is YAML; everything
    after is the body. If the structure isn't valid, we return None
    for the frontmatter so the caller can issue a single E_NO_FRONTMATTER
    error rather than a confusing chain of YAML parse errors.
    """
    text = _strip_bom(text)
    if not text.startswith("---"):
        return None, text

    # Split on the SECOND occurrence of a line starting with `---`.
    # Use splitlines and re-find rather than regex so we handle CRLF
    # and trailing whitespace consistently across platforms.
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].strip() != "---":
        return None, text

    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            fm_yaml = "".join(lines[1:i])
            body = "".join(lines[i + 1:])
            return fm_yaml, body

    # No closing fence — malformed.
    return None, text


def _parse_yaml_safely(yaml_text: str) -> tuple[dict | None, str | None]:
    """Parse YAML, returning ``(value, error_message)``.

    Returns ``(None, "...")`` on any failure (including empty result that
    isn't a mapping). Never raises.
    """
    try:
        loaded = yaml.safe_load(yaml_text)
    except yaml.YAMLError as exc:
        # Compact error message — yaml errors include line/column info
        # which we expose verbatim so users can find the problem.
        return None, str(exc).strip().splitlines()[0] if str(exc).strip() else "invalid YAML"
    except Exception as exc:  # noqa: BLE001 — the loader is total.
        return None, f"unexpected parse error: {type(exc).__name__}"

    if loaded is None:
        # Empty frontmatter — not a parse error per se, but the spec
        # requires `name` and `description`, so we surface this as a
        # caller-visible empty case (callers turn this into E_NAME_MISSING
        # and E_DESCRIPTION_MISSING by checking the empty dict).
        return {}, None

    if not isinstance(loaded, dict):
        return None, f"frontmatter must be a YAML mapping, got {type(loaded).__name__}"

    return loaded, None


# ── Field validators ────────────────────────────────────────────────────────

def _validate_name(report: ValidationReport, value: object, parent_dir_name: str | None) -> None:
    """Validate the required `name` field per spec rules."""
    if value is None or (isinstance(value, str) and not value):
        report.add_error("E_NAME_MISSING", "name", "name field is required")
        return

    if not isinstance(value, str):
        report.add_error(
            "E_NAME_NOT_STRING",
            "name",
            f"name must be a string (got {type(value).__name__})",
        )
        return

    if len(value) > NAME_MAX_LEN:
        report.add_error(
            "E_NAME_TOO_LONG",
            "name",
            f"name is {len(value)} chars (max {NAME_MAX_LEN})",
        )

    if not NAME_PATTERN.fullmatch(value):
        # Decompose the failure to give actionable feedback.
        if value.startswith("-"):
            report.add_error("E_NAME_LEADING_HYPHEN", "name",
                             "name must not start with a hyphen")
        elif value.endswith("-"):
            report.add_error("E_NAME_TRAILING_HYPHEN", "name",
                             "name must not end with a hyphen")
        elif "--" in value:
            report.add_error("E_NAME_CONSECUTIVE_HYPHENS", "name",
                             "name must not contain consecutive hyphens")
        else:
            report.add_error(
                "E_NAME_INVALID_CHARS",
                "name",
                "name may only contain lowercase letters, digits, and hyphens",
            )

    # Parent-directory match is only checked when we know the parent
    # (i.e. validate_skill_path was used, not validate_skill_text alone).
    if parent_dir_name is not None and value != parent_dir_name:
        report.add_error(
            "E_NAME_PARENT_MISMATCH",
            "name",
            f"name '{value}' does not match parent directory '{parent_dir_name}'",
        )


def _validate_description(report: ValidationReport, value: object) -> None:
    """Validate the required `description` field per spec rules."""
    if value is None:
        report.add_error("E_DESCRIPTION_MISSING", "description",
                         "description field is required")
        return

    if not isinstance(value, str):
        report.add_error(
            "E_DESCRIPTION_NOT_STRING",
            "description",
            f"description must be a string (got {type(value).__name__})",
        )
        return

    trimmed_len = len(value.strip())
    if trimmed_len < 1:
        report.add_error("E_DESCRIPTION_EMPTY", "description",
                         "description must be non-empty")
        return

    if len(value) > DESCRIPTION_MAX_LEN:
        report.add_error(
            "E_DESCRIPTION_TOO_LONG",
            "description",
            f"description is {len(value)} chars (max {DESCRIPTION_MAX_LEN})",
        )


def _validate_compatibility(report: ValidationReport, value: object) -> None:
    """Validate the optional `compatibility` field."""
    if not isinstance(value, str):
        report.add_error(
            "E_COMPATIBILITY_NOT_STRING",
            "compatibility",
            f"compatibility must be a string (got {type(value).__name__})",
        )
        return

    if len(value) > COMPATIBILITY_MAX_LEN:
        report.add_error(
            "E_COMPATIBILITY_TOO_LONG",
            "compatibility",
            f"compatibility is {len(value)} chars (max {COMPATIBILITY_MAX_LEN})",
        )


def _validate_license(report: ValidationReport, value: object) -> None:
    """Validate the optional `license` field."""
    if not isinstance(value, str):
        report.add_error(
            "E_LICENSE_NOT_STRING",
            "license",
            f"license must be a string (got {type(value).__name__})",
        )


def _validate_metadata(report: ValidationReport, value: object) -> None:
    """Validate the optional `metadata` field.

    Spec: "A map from string keys to string values."

    We enforce mapping-shape strictly (errors on non-mapping) but only
    warn on non-string values, because ecosystem usage routinely puts
    nested structures here (versions as floats, lists of authors, etc.)
    and a strict reading would create friction without a real interop
    benefit.
    """
    if not isinstance(value, dict):
        report.add_error(
            "E_METADATA_NOT_MAPPING",
            "metadata",
            f"metadata must be a YAML mapping (got {type(value).__name__})",
        )
        return

    for k, v in value.items():
        if not isinstance(k, str):
            report.add_error(
                "E_METADATA_KEY_NOT_STRING",
                "metadata",
                f"metadata keys must be strings (got {type(k).__name__})",
            )
        if not isinstance(v, str):
            # Soft warning — see docstring rationale.
            report.add_warning(
                "W_METADATA_VALUE_NOT_STRING",
                f"metadata.{k}",
                f"spec recommends string values; got {type(v).__name__}",
            )


def _validate_allowed_tools(report: ValidationReport, value: object) -> None:
    """Validate the optional `allowed-tools` field."""
    if not isinstance(value, str):
        report.add_error(
            "E_ALLOWED_TOOLS_NOT_STRING",
            "allowed-tools",
            "allowed-tools must be a space-separated string "
            f"(got {type(value).__name__})",
        )


def _validate_unknown_keys(report: ValidationReport, frontmatter: dict) -> None:
    """Warn on every top-level key outside the spec set.

    The spec is silent on extra top-level keys; ecosystem clients
    tolerate them. Warnings exist so authors can deliberately decide
    whether to keep extensions flat or move them under `metadata:`.
    AgntSpace-known extras get a more specific warning code so they
    can be filtered in CI without losing visibility on truly novel keys.
    """
    for key in frontmatter:
        if key in SPEC_TOP_LEVEL_KEYS:
            continue
        if key in AGNTSPACE_KNOWN_EXTRAS:
            report.add_warning(
                "W_AGNTSPACE_EXTENSION",
                key,
                f"'{key}' is an AgntSpace extension; ecosystem clients ignore it",
            )
        else:
            report.add_warning(
                "W_UNKNOWN_TOP_LEVEL_KEY",
                key,
                f"'{key}' is not a spec field; consider moving under metadata:",
            )


def _validate_body(report: ValidationReport, body: str) -> None:
    """Soft checks on the body content. Always warnings, never errors."""
    stripped = body.strip()
    if not stripped:
        report.add_warning("W_BODY_EMPTY", "_body",
                           "skill body is empty; agents have no instructions to follow")
        return

    line_count = body.count("\n") + 1
    if line_count > 500:
        report.add_warning(
            "W_BODY_TOO_LONG",
            "_body",
            f"body is {line_count} lines; spec recommends <500. "
            "Consider moving detail to references/.",
        )


# ── Public API ──────────────────────────────────────────────────────────────

def validate_skill_text(text: str, parent_dir_name: str | None = None,
                        path: str = "") -> ValidationReport:
    """Validate a SKILL.md given its raw text.

    Args:
        text: The full file contents (frontmatter + body).
        parent_dir_name: Name of the parent directory (for the
            `name` field's parent-match rule). Pass None to skip the
            check (useful for ad-hoc text validation in tests).
        path: Optional path string for the report's identifier.

    Returns:
        A ``ValidationReport``. Inspect ``.valid`` for compliance,
        ``.errors`` for blocking issues, ``.warnings`` for advisory.
    """
    report = ValidationReport(path=path)

    if not isinstance(text, str):
        report.add_error("E_INTERNAL", "",
                         f"validator received {type(text).__name__}, expected str")
        return report

    fm_yaml, body = _split_frontmatter(text)
    if fm_yaml is None:
        report.add_error("E_NO_FRONTMATTER", "_frontmatter",
                         "file must start with a '---' fence and contain YAML "
                         "frontmatter terminated by another '---' fence")
        return report

    frontmatter, parse_err = _parse_yaml_safely(fm_yaml)
    if frontmatter is None:
        report.add_error("E_BAD_YAML", "_frontmatter",
                         f"frontmatter is not valid YAML: {parse_err}")
        return report

    # Required fields.
    _validate_name(report, frontmatter.get("name"), parent_dir_name)
    _validate_description(report, frontmatter.get("description"))

    # Optional spec fields — only validate when present.
    if "compatibility" in frontmatter:
        _validate_compatibility(report, frontmatter["compatibility"])
    if "license" in frontmatter:
        _validate_license(report, frontmatter["license"])
    if "metadata" in frontmatter:
        _validate_metadata(report, frontmatter["metadata"])
    if "allowed-tools" in frontmatter:
        _validate_allowed_tools(report, frontmatter["allowed-tools"])

    _validate_unknown_keys(report, frontmatter)
    _validate_body(report, body)

    return report


def validate_skill_path(path: str | Path) -> ValidationReport:
    """Validate the SKILL.md file at the given path.

    Path may point to either:
        * a SKILL.md file directly (parent-dir name is taken from
          the file's parent directory), OR
        * a skill folder containing SKILL.md (the path's name is the
          folder name; we read SKILL.md inside it).

    Returns a ValidationReport. Returns an E_FILE_NOT_FOUND error if
    no SKILL.md is found.
    """
    p = Path(path)
    report = ValidationReport(path=str(p))

    skill_md: Path
    parent_dir_name: str

    if p.is_dir():
        skill_md = p / "SKILL.md"
        parent_dir_name = p.name
    else:
        skill_md = p
        parent_dir_name = p.parent.name if p.parent.name else ""

    if not skill_md.is_file():
        report.add_error("E_FILE_NOT_FOUND", "",
                         f"SKILL.md not found at {skill_md}")
        return report

    try:
        text = skill_md.read_text(encoding="utf-8")
    except OSError as exc:
        report.add_error("E_INTERNAL", "",
                         f"could not read {skill_md}: {exc}")
        return report

    file_report = validate_skill_text(text, parent_dir_name=parent_dir_name,
                                      path=str(skill_md))
    # Preserve the path we resolved (might differ from the original arg).
    file_report.path = str(skill_md)
    return file_report


def validate_skill_directory(skills_dir: str | Path) -> list[ValidationReport]:
    """Validate every SKILL.md under a skills directory tree.

    Walks the tree (e.g. ``defaults/skills/`` or
    ``<vault>/agntspace/system/skills/``), validates every SKILL.md,
    returns one report per file. Empty list if the directory doesn't exist.
    Order is sorted by path for deterministic CI output.
    """
    root = Path(skills_dir)
    if not root.is_dir():
        return []

    reports: list[ValidationReport] = []
    for skill_md in sorted(root.rglob("SKILL.md")):
        reports.append(validate_skill_path(skill_md))
    return reports


def summarize_reports(reports: Iterable[ValidationReport]) -> dict:
    """Aggregate a sequence of reports into a single summary dict.

    Useful for CI output, dashboard cards, and the API endpoint.
    Returns total counts by severity and a list of failing-skill names.
    """
    reports_list = list(reports)
    total = len(reports_list)
    valid = sum(1 for r in reports_list if r.valid)
    error_count = sum(len(r.errors) for r in reports_list)
    warning_count = sum(len(r.warnings) for r in reports_list)
    failing = [r.path for r in reports_list if not r.valid]
    return {
        "total": total,
        "valid": valid,
        "invalid": total - valid,
        "errors": error_count,
        "warnings": warning_count,
        "failing_paths": failing,
    }
