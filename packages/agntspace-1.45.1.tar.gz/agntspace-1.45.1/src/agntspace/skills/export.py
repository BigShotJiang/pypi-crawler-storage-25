"""Phase 6 — ``skill-export`` writers.

Counterpart to ``import_source.py`` (Phase 5). Lets a vault skill
travel to another agentskills.io-compatible client (Goose, Letta,
Cursor, Codex, Copilot, OpenCode, etc.) by emitting a spec-canonical
SKILL.md + optional auxiliary files into a target directory or a
streamable tarball.

Two output forms (caller chooses):

* **Round-trip** (default): keeps AgntSpace flat extras
  (``title`` / ``category`` / ``status`` / ``author``) AND keeps every
  ``metadata:`` field intact (triggers, priority, model_tier, examples,
  language, scraping, … plus provenance from a prior import). Result
  is spec-valid (validator passes) AND survives ``skill-import`` to
  reproduce the same Skill object.
* **Pure-spec** (``strip_metadata=True``): keeps ONLY spec-defined
  top-level fields (``name``, ``description``, ``license``,
  ``compatibility``, ``allowed-tools``) plus a minimal ``metadata:``
  carrying ``imported_from`` if present. Drops AgntSpace flat extras
  + behavioral fields. Result is what a stranger using only
  agentskills.io specification would expect.

Plan: tasks/plan-agentskills-compliance.md (Phase 6).
"""

from __future__ import annotations

import io
import shutil
import tarfile
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import frontmatter
import yaml

# ── Spec-defined top-level fields (Phase 6 invariant: ALWAYS keep) ──────────

# These survive both export modes — they ARE the agentskills.io spec.
_SPEC_TOP_LEVEL: tuple[str, ...] = (  # arch:deterministic — verbatim list of agentskills.io spec-defined top-level keys; structural to the spec, not strategy
    "name",
    "description",
    "license",
    "compatibility",
    "allowed-tools",
)

# AgntSpace flat extras — kept top-level in round-trip mode, dropped in
# pure-spec mode. Synced with `Phase 0 Decision 2` in
# tasks/plan-agentskills-compliance.md.
_AGNTSPACE_FLAT_EXTRAS: tuple[str, ...] = (  # arch:deterministic — locked Decision 2 in tasks/plan-agentskills-compliance.md; UI consumers depend on these being top-level
    "title",
    "category",
    "status",
    "author",
)

# Files we exclude when copying the skill folder. SKILL.md is rewritten
# separately from frontmatter; bookkeeping files are noise.
_SKIP_FILES: frozenset[str] = frozenset({  # arch:deterministic — universal filesystem-noise filenames (BOM, OS metadata)
    "SKILL.md",
    ".gitkeep",
    ".DS_Store",
    "Thumbs.db",
})

# Skip these dirs entirely during the recursive copy.
_SKIP_DIRS: frozenset[str] = frozenset({  # arch:deterministic — universal version-control/cache/snapshot dirs
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".history",
    ".archive",
})


# ── Result types ────────────────────────────────────────────────────────────

class SkillExportError(Exception):
    """Raised when a skill can't be exported (missing source, unwritable
    dest, etc.). Always carries a message suitable for surfacing verbatim."""


@dataclass(frozen=True)
class ExportResult:
    """Outcome of writing one skill to disk.

    Files in ``copied_files`` are relative to the exported skill root
    (e.g. ``["scripts/extract.py", "references/REFERENCE.md"]``); the
    rewritten ``SKILL.md`` is always present and accounted for via
    ``skill_md_written``.
    """

    slug: str
    dest_dir: str
    skill_md_written: bool
    copied_files: list[str]
    pure_spec: bool


# ── Spec-form frontmatter builder ───────────────────────────────────────────

def _build_export_frontmatter(meta: dict, *, strip_metadata: bool) -> dict:
    """Produce the frontmatter dict to write to the exported SKILL.md.

    Inputs are the loaded metadata dict (post-import, post-Phase-3 — so
    ``allowed-tools`` is canonical and behavioral fields live under
    ``metadata:``). If a caller passes a legacy-form skill (with
    ``tools_granted: [list]``) we translate it on the fly so export
    is robust to either input shape.
    """
    out: dict = {}

    # 1. Spec required fields first (canonical order for diff readability).
    for k in ("name", "description"):
        if k in meta:
            out[k] = meta[k]

    # 2. Spec optional fields (kept regardless of strip_metadata)
    for k in ("license", "compatibility"):
        if k in meta:
            out[k] = meta[k]

    # 3. allowed-tools — handle both legacy `tools_granted: [list]` and
    #    canonical `allowed-tools: "..."` inputs.
    existing_allowed = meta.get("allowed-tools")
    if isinstance(existing_allowed, str) and existing_allowed.strip():
        out["allowed-tools"] = existing_allowed
    else:
        legacy = meta.get("tools_granted")
        if isinstance(legacy, list) and legacy:
            joined = " ".join(str(t).strip() for t in legacy if str(t).strip())
            if joined:
                out["allowed-tools"] = joined

    # 4. AgntSpace flat extras — only in round-trip mode
    if not strip_metadata:
        for k in _AGNTSPACE_FLAT_EXTRAS:
            if k in meta:
                out[k] = meta[k]

    # 5. metadata: block — preserve in round-trip mode; minimize in pure-spec
    metadata_block = meta.get("metadata")
    if not isinstance(metadata_block, dict):
        metadata_block = None

    if strip_metadata:
        # Pure-spec: drop everything from metadata EXCEPT optional
        # provenance (imported_from / imported_kind / imported_at) which
        # is genuinely useful for tracking origin across ecosystems.
        if metadata_block:
            preserved = {}
            for k in ("imported_from", "imported_kind", "imported_at"):
                if k in metadata_block:
                    preserved[k] = metadata_block[k]
            if preserved:
                out["metadata"] = preserved
    else:
        # Round-trip: keep the metadata block as-is. If a behavioral field
        # was somehow at the top level (legacy-pre-Phase-3 input), we DON'T
        # auto-migrate it here — that's the migration script's job, not
        # the export's. The export just reflects current state.
        if metadata_block:
            out["metadata"] = metadata_block

    # 6. Stamp export provenance under metadata:. Useful for debugging
    #    "where did this skill come from?" across re-imports.
    md = out.get("metadata")
    if not isinstance(md, dict):
        md = {}
    md["exported_at"] = datetime.now(UTC).isoformat()
    md["exported_by"] = "agntspace"
    out["metadata"] = md

    return out


# ── Auxiliary file copy ─────────────────────────────────────────────────────

def _iter_skill_files(skill_dir: Path) -> Iterable[Path]:
    """Yield every file in the skill folder we want to carry along
    (skipping bookkeeping files + dot-dirs)."""
    for p in skill_dir.rglob("*"):
        if not p.is_file():
            continue
        if p.name in _SKIP_FILES:
            continue
        rel_parts = p.relative_to(skill_dir).parts
        if rel_parts and any(part in _SKIP_DIRS for part in rel_parts):
            continue
        yield p


# ── Public API: export to a directory ───────────────────────────────────────

def export_skill_to_dir(
    skill_dir: Path | str,
    dest_dir: Path | str,
    *,
    strip_metadata: bool = False,
    overwrite: bool = False,
) -> ExportResult:
    """Write a spec-canonical copy of one skill to ``dest_dir/<slug>/``.

    Args:
        skill_dir: Path to the source skill folder (must contain SKILL.md).
            Typically ``<vault>/agntspace/system/skills/<category>/<slug>/``.
        dest_dir: Output directory. The skill lands at ``dest_dir/<slug>/``.
            Created if missing.
        strip_metadata: When ``True``, emit pure-spec form (no AgntSpace
            flat extras, no behavioral metadata). Default keeps everything.
        overwrite: When ``True``, replace ``dest_dir/<slug>/`` if present.
            Default raises if it already exists.

    Returns:
        ``ExportResult`` summarising what landed.

    Raises:
        SkillExportError: source missing, dest collision (without
            overwrite), or any I/O failure with a clear message.
    """
    src = Path(skill_dir)
    dest = Path(dest_dir)

    if not src.is_dir():
        raise SkillExportError(f"Source skill folder not found: {src}")
    skill_md = src / "SKILL.md"
    if not skill_md.is_file():
        raise SkillExportError(f"No SKILL.md in source folder: {src}")

    # Load + parse the source
    try:
        raw = skill_md.read_text(encoding="utf-8")
        if raw.startswith("﻿"):
            raw = raw.lstrip("﻿")
        post = frontmatter.loads(raw)
    except Exception as exc:
        raise SkillExportError(f"Failed to parse {skill_md}: {exc}") from exc

    meta = post.metadata or {}
    slug = str(meta.get("name") or src.name)
    if not slug:
        raise SkillExportError(f"Could not derive slug from {src}")

    target = dest / slug
    if target.exists():
        if not overwrite:
            raise SkillExportError(
                f"Destination already exists: {target}. "
                "Pass overwrite=True to replace it."
            )
        try:
            shutil.rmtree(target)
        except Exception as exc:
            raise SkillExportError(f"Could not clear {target}: {exc}") from exc

    target.mkdir(parents=True, exist_ok=False)

    # Build the export frontmatter
    new_meta = _build_export_frontmatter(meta, strip_metadata=strip_metadata)

    # Re-emit SKILL.md with stable YAML formatting
    yaml_text = yaml.safe_dump(
        new_meta,
        sort_keys=False,
        default_flow_style=False,
        allow_unicode=True,
        width=200,
    )
    full_text = f"---\n{yaml_text}---\n{post.content}"
    (target / "SKILL.md").write_text(full_text, encoding="utf-8")

    # Copy auxiliary files
    copied: list[str] = []
    for f in _iter_skill_files(src):
        rel = f.relative_to(src)
        target_path = target / rel
        target_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(f, target_path)
            copied.append(str(rel).replace("\\", "/"))
        except Exception:
            # Best-effort — one bad file doesn't break the export.
            continue

    return ExportResult(
        slug=slug,
        dest_dir=str(target),
        skill_md_written=True,
        copied_files=copied,
        pure_spec=strip_metadata,
    )


# ── Public API: export to a tarball stream ──────────────────────────────────

def export_skill_to_tarball(
    skill_dir: Path | str,
    *,
    strip_metadata: bool = False,
) -> bytes:
    """Build an in-memory ``.tar.gz`` containing the exported skill.

    Returns the tarball as bytes — the API route streams it directly.
    For large skills with many auxiliary files, callers may prefer
    ``export_skill_to_dir`` then bundling on disk; today every shipped
    skill is well under a few MB so the in-memory approach is fine.

    The tar contains a single top-level directory ``<slug>/`` with the
    skill's spec-canonical SKILL.md + auxiliary files.
    """
    src = Path(skill_dir)
    if not src.is_dir():
        raise SkillExportError(f"Source skill folder not found: {src}")
    skill_md = src / "SKILL.md"
    if not skill_md.is_file():
        raise SkillExportError(f"No SKILL.md in source folder: {src}")

    # Parse to derive slug + new frontmatter
    try:
        raw = skill_md.read_text(encoding="utf-8")
        if raw.startswith("﻿"):
            raw = raw.lstrip("﻿")
        post = frontmatter.loads(raw)
    except Exception as exc:
        raise SkillExportError(f"Failed to parse {skill_md}: {exc}") from exc

    meta = post.metadata or {}
    slug = str(meta.get("name") or src.name)
    if not slug:
        raise SkillExportError(f"Could not derive slug from {src}")

    new_meta = _build_export_frontmatter(meta, strip_metadata=strip_metadata)
    yaml_text = yaml.safe_dump(
        new_meta,
        sort_keys=False,
        default_flow_style=False,
        allow_unicode=True,
        width=200,
    )
    skill_md_text = f"---\n{yaml_text}---\n{post.content}"

    # Build tarball in memory
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        # Rewritten SKILL.md
        skill_md_bytes = skill_md_text.encode("utf-8")
        info = tarfile.TarInfo(name=f"{slug}/SKILL.md")
        info.size = len(skill_md_bytes)
        info.mtime = int(datetime.now().timestamp())
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(skill_md_bytes))

        # Auxiliary files
        for f in _iter_skill_files(src):
            rel = f.relative_to(src)
            tar.add(str(f), arcname=f"{slug}/{str(rel).replace(chr(92), '/')}")

    return buf.getvalue()
