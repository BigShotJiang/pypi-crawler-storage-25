"""Personal Wiki API — unified access to all knowledge bases.

Unified view across all KBs: articles, people, categories, search, recent changes.
The wiki is maintained by the agent — user reads, agent writes.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import UTC, datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/wiki", tags=["wiki"])


def _to_logical(vault, physical_path: Path) -> str:
    """Convert a physical path to a logical vault-relative path."""
    if hasattr(vault, "paths") and vault.paths:
        return vault.paths.to_logical(physical_path)
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    return str(physical_path.relative_to(vault_dir)).replace("\\", "/")

# In-memory article cache (avoids re-reading 700+ files on every request)
_article_cache: dict = {
    "articles": [],
    "built_at": 0.0,
    "ttl": 60.0,
    "rebuilding": False,
    # Inverted index: { target_key -> [{slug, title, kb, snippet, source_path}, ...] }
    # target_key is one of: lowercased title, slug, kebab-normalised title.
    # All three are populated so a [[Display Name]] / [[slug]] / [[slug|alias]]
    # match in another article's content lands the same article on lookup.
    # Built once per cache rebuild — turns the previous O(N) per-click vault
    # walk in /article/{slug}/backlinks into O(1) dict lookup.
    "backlinks_index": {},
}

# Single-flight lock for the cold-cache build path. Without it, a startup
# warm thread + a concurrent /api/wiki/article click both see articles==[]
# and EACH run the full _build_article_list independently — under the GIL
# that doubles the wall-clock build time (measured 7.6 s instead of ~3 s
# for the warm-thread-alone case). With this lock, the second caller waits
# on the first, then returns immediately seeing the populated cache.
import threading as _threading  # noqa: E402, PLC0415

_article_cache_build_lock: _threading.Lock = _threading.Lock()


def _try_open_obsidian(path: Path) -> bool:
    """If *path* lives inside an Obsidian vault, open it via the
    ``obsidian://`` URI scheme. Works on Windows, macOS and Linux because
    the Obsidian desktop app registers the scheme on every platform it
    ships for. Returns True on success, False otherwise.

    **Refuses files inside dot-prefixed segments** (``.quarantine/``,
    ``.unsupported/``, ``.history/``, ``.archives/``, ``.obsidian/``) —
    Obsidian excludes hidden directories from its vault index, so firing
    an ``obsidian://open`` URI for such a file would land on Obsidian's
    own "File not found" error even though the file exists on disk.
    Returning False here lets the caller fall through to the OS default
    editor, which will actually open the file.
    """
    import subprocess
    import sys

    check = path.parent
    for _ in range(10):
        if (check / ".obsidian").is_dir():
            try:
                from urllib.parse import quote

                rel = path.relative_to(check)
                # If any segment between the vault root and the file starts
                # with a dot, Obsidian won't have indexed it. Skip and let
                # the OS default editor handle it.
                if any(part.startswith(".") for part in rel.parts):
                    return False
                rel_posix = str(rel).replace("\\", "/")
                obsidian_uri = (
                    f"obsidian://open?vault={quote(check.name)}&file={quote(rel_posix)}"
                )
                if sys.platform == "win32":
                    import os

                    os.startfile(obsidian_uri)  # type: ignore[attr-defined]
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", obsidian_uri])
                else:
                    subprocess.Popen(["xdg-open", obsidian_uri])
                return True
            except Exception:
                return False
        if check.parent == check:
            break
        check = check.parent
    return False


def _build_article_list(vault) -> tuple[list[dict], dict[str, list[dict]]]:
    """Read all wiki files and build the article list + backlinks index.

    CPU-bound, runs in thread. Returns ``(articles, backlinks_index)``.

    The backlinks index is the inverted view of wikilinks: for every
    ``[[X]]`` we find inside an article's body, the SOURCE article is
    recorded under multiple lookup keys for X — slug (when resolvable
    via the title-map), lowercased raw text, and kebab-normalised text —
    so a click on any article finds its backlinks via O(1) dict lookup.
    The previous backlinks endpoint re-walked the whole wiki tree per
    click; on a 1700-article vault that was 2.7-4.8 s every time.

    Snippets (~160 chars around the first ``[[X]]`` match per source)
    are captured here once, not per-click, so the response is free.
    """
    import os

    # Pass 1 — walk every file once, capture article record + raw
    # wikilinks + per-link snippet. Defer index building until we have
    # the title-map (which needs the full article list).
    raw_records: list[tuple[dict, list[tuple[str, str]]]] = []
    for f in _list_wiki_files(vault):
        result = _read_article_safe(vault, f)
        if not result:
            continue
        rel, meta, content = result
        content_text = content.strip()
        excerpt = content_text[:200].split("\n\n")[0] if content_text else ""
        raw_links = re.findall(r"\[\[([^\]]+)\]\]", content_text)
        links = [lnk.split("|")[0].strip() for lnk in raw_links]

        # First-occurrence snippet per unique link target. Cap at 160 chars
        # (80 on each side) — same shape the original endpoint produced.
        per_target: dict[str, str] = {}
        for raw_link in raw_links:
            target_raw = raw_link.split("|")[0].strip()
            if not target_raw or target_raw in per_target:
                continue
            for needle in (f"[[{target_raw}]]", f"[[{raw_link}]]"):
                idx = content_text.find(needle)
                if idx >= 0:
                    start = max(0, idx - 80)
                    end = min(len(content_text), idx + len(needle) + 80)
                    per_target[target_raw] = (
                        content_text[start:end].replace("\n", " ").strip()
                    )
                    break

        try:
            mtime = os.path.getmtime(f)
        except OSError:
            mtime = 0.0

        record = {
            "slug": meta.get("slug") or re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-"),
            "title": meta.get("title", f.stem),
            "category": meta.get("category", ""),
            "taxonomy_path": meta.get("taxonomy_path", ""),
            "entity_type": meta.get("entity_type", ""),
            "provenance": meta.get("provenance", ""),
            "status": meta.get("status", ""),
            "excerpt": excerpt,
            "links": links[:10],
            "sources": meta.get("sources", []),
            "path": rel,
            "kb": _extract_kb_slug(rel),
            "mtime": mtime,
        }
        raw_records.append((record, list(per_target.items())))

    articles = [rec for rec, _ in raw_records]
    articles.sort(key=lambda a: a["title"])

    # Title-map for resolving "[[Display Name]]" → canonical slug.
    title_to_slug: dict[str, str] = {}
    for a in articles:
        title_to_slug[a["title"].lower()] = a["slug"]
        derived = re.sub(r"[^a-z0-9]+", "-", a["title"].lower()).strip("-")
        if derived:
            title_to_slug[derived] = a["slug"]

    # Pass 2 — build the inverted index from raw_records (which preserve
    # the source/target snippet pairs we collected in pass 1, so we don't
    # re-read any files).
    backlinks_index: dict[str, list[dict]] = {}
    for source, target_snippets in raw_records:
        for target_raw, snippet in target_snippets:
            target_lc = target_raw.lower()
            target_kebab = re.sub(r"[^a-z0-9]+", "-", target_lc).strip("-")
            target_slug = (
                title_to_slug.get(target_lc)
                or title_to_slug.get(target_kebab)
                or target_kebab
            )
            entry = {
                "slug": source["slug"],
                "title": source["title"],
                "kb": source["kb"],
                "snippet": snippet,
                "source_path": source["path"],
            }
            # Index under every lookup key so /backlinks?slug=foo,
            # /backlinks?slug=Foo Bar, and /backlinks?slug=foo-bar all hit.
            # Dedup at lookup time, not here.
            for key in {target_slug, target_lc, target_kebab}:
                if key:
                    backlinks_index.setdefault(key, []).append(entry)

    return articles, backlinks_index


def _get_cached_articles(vault) -> list[dict]:
    """Return cached article list. Stale cache triggers background rebuild — never blocks."""
    import threading  # noqa: PLC0415
    import time  # noqa: PLC0415

    now = time.time()
    if _article_cache["articles"] and (now - _article_cache["built_at"]) < _article_cache["ttl"]:
        return _article_cache["articles"]

    # Stale — if we have old data, return it and rebuild in background
    if _article_cache["articles"] and not _article_cache["rebuilding"]:
        _article_cache["rebuilding"] = True

        def _rebuild():
            try:
                articles, backlinks_index = _build_article_list(vault)
                _article_cache["articles"] = articles
                _article_cache["backlinks_index"] = backlinks_index
                _article_cache["built_at"] = time.time()
            finally:
                _article_cache["rebuilding"] = False

        threading.Thread(target=_rebuild, daemon=True).start()
        return _article_cache["articles"]  # return stale while rebuilding

    # No cached data — single-flight rebuild. The lock prevents the
    # startup warm thread + a concurrent first-click from both running
    # _build_article_list in parallel (GIL contention doubles wall time).
    # The first caller acquires the lock and builds; subsequent callers
    # wait on the lock, then re-check the cache and return the freshly
    # built result without redoing the work.
    with _article_cache_build_lock:
        # Re-check after acquiring the lock — another thread may have
        # populated the cache while we were waiting.
        if _article_cache["articles"]:
            return _article_cache["articles"]
        articles, backlinks_index = _build_article_list(vault)
        _article_cache["articles"] = articles
        _article_cache["backlinks_index"] = backlinks_index
        _article_cache["built_at"] = time.time()
        return articles


def _get_cached_backlinks_index(vault) -> dict[str, list[dict]]:
    """Return the backlinks inverted index. Triggers article-cache build
    if needed (the index is built alongside articles in the same pass).
    """
    # Force-touch the article cache to ensure the index is populated.
    _get_cached_articles(vault)
    return _article_cache.get("backlinks_index") or {}


def warm_article_cache(vault) -> None:
    """Pre-warm the article cache at server startup. Call from lifespan.

    Uses the same single-flight lock as the cold-cache fast path so an
    early-arriving request that hits the cache while warming is in
    flight doesn't kick off a duplicate parallel build (which would
    double wall-clock time under GIL contention — measured 7.6 s vs
    3 s on a 1700-article vault).
    """
    import threading
    import time

    def _warm():
        with _article_cache_build_lock:
            # If a request beat us to the build, skip — cache is fresh.
            if _article_cache["articles"]:
                return
            articles, backlinks_index = _build_article_list(vault)
            _article_cache["articles"] = articles
            _article_cache["backlinks_index"] = backlinks_index
            _article_cache["built_at"] = time.time()
            log.debug(
                "Wiki article cache warmed: %d articles, %d backlink keys",
                len(articles),
                len(backlinks_index),
            )

    threading.Thread(target=_warm, daemon=True).start()


def invalidate_article_cache():
    """Call after any write operation that changes wiki articles.

    Clears cached articles + backlinks index so the next request rebuilds
    synchronously instead of returning stale data.
    """
    _article_cache["built_at"] = 0.0
    _article_cache["articles"] = []
    _article_cache["backlinks_index"] = {}
    # Phase 0.2 (2026-05-04) — `wiki_stats` aggregates over the article
    # cache (via `list_kbs`); when articles change, stats change too.
    invalidate_wiki_stats_cache()


# arch:short-ttl-cache — Phase 0.2 (2026-05-04). The `wiki_stats`
# endpoint is hit by every dashboard tile + every wiki page nav. With
# Phase 0.1's `list_kbs()` cache the underlying cost is already cheap,
# but a dedicated 30 s response cache (a) saves the sum + dict-build
# per call, (b) gives us a single response-level invalidation hook the
# UI can rely on, (c) protects against a future change that would make
# the aggregate compute heavier. The TTL is short and explicit
# invalidation wins immediately on any ingest/compile completion.
_wiki_stats_cache: dict = {
    "value": None,  # cached response dict, or None when invalidated
    "built_at": 0.0,
    "ttl": 30.0,
}


def invalidate_wiki_stats_cache():
    """Drop the cached wiki_stats response.

    Called from `invalidate_article_cache` automatically (article changes
    → stats change), and explicitly from kb_service mutation paths via
    `invalidate_kb_list_cache()` which fires this through the article-
    cache invalidation chain.
    """
    _wiki_stats_cache["value"] = None
    _wiki_stats_cache["built_at"] = 0.0


def _classify_and_enrich_articles(all_articles: list[dict], flat_nodes: list) -> list[dict]:
    """Shared helper: auto-classify every article that lacks a taxonomy_path,
    then project the subset of fields the tree + article endpoints need."""
    from agntspace.kb.taxonomy import classify_article

    out: list[dict] = []
    for a in all_articles:
        tp = a.get("taxonomy_path", "")
        if not tp:
            tp = classify_article(
                entity_type=a.get("entity_type", ""),
                category=a.get("category", ""),
                title=a.get("title", ""),
                flat_nodes=flat_nodes,
            )
        out.append({
            "slug": a["slug"],
            "title": a["title"],
            "taxonomy_path": tp,
            "category": a.get("category", ""),
            "entity_type": a.get("entity_type", ""),
            "provenance": a.get("provenance", ""),
            "kb": a.get("kb", ""),
        })
    return out


@router.get("/taxonomy")
async def get_taxonomy(request: Request, lite: bool = False) -> dict:
    """Return the knowledge taxonomy tree annotated with article counts.

    Query params:
        lite: when true, omit the inline ``articles`` list per node. The
            response still carries ``letter_counts`` so the client can
            render letter folders without fetching article payloads. The
            client is expected to lazy-fetch articles via
            ``/api/wiki/taxonomy/articles`` on demand. Cuts the payload
            dramatically at large article counts.

    Lite is the recommended mode for the UI tree at scale (10k+ articles);
    full mode is preserved for backward compatibility with any caller
    that still reads ``node.articles`` directly.
    """
    from agntspace.kb.taxonomy import (
        build_taxonomy_tree_with_counts,
        flatten_taxonomy,
        load_taxonomy,
    )

    skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
    if not skills_dir:
        return {"tree": [], "flat": []}

    vault = request.app.state.vault
    vault_dir = getattr(vault, "vault_dir", None) if vault else None

    tree = load_taxonomy(skills_dir, vault_dir=vault_dir)
    flat_nodes = flatten_taxonomy(tree)

    # Phase 0.3 (2026-05-04) — off-loop. _get_cached_articles holds a
    # lock and runs _build_article_list synchronously on cold cache (the
    # 5-7 s FS walk on a 1700-article vault). Without to_thread it
    # starves the event loop and every concurrent request stalls.
    import asyncio  # noqa: PLC0415
    all_articles = await asyncio.to_thread(_get_cached_articles, vault)

    articles = _classify_and_enrich_articles(all_articles, flat_nodes)
    annotated_tree = build_taxonomy_tree_with_counts(tree, articles, lite=lite)
    return {"tree": annotated_tree, "lite": lite}


@router.get("/taxonomy/articles")
async def get_taxonomy_articles(
    request: Request,
    path: str,
    letter: str | None = None,
    offset: int = 0,
    limit: int = 200,
) -> dict:
    """Paginated article list for a single taxonomy path.

    Matches ``article.taxonomy_path == path`` EXACTLY. For descendant-
    inclusive filtering, the existing ``/api/wiki/articles?taxonomy_path=``
    endpoint is the right tool.

    Query params:
        path: exact taxonomy_path. ``"unclassified"`` matches articles
            with no taxonomy_path AND no category.
        letter: optional first-letter bucket (``"A"``-``"Z"`` or ``"#"``
            for non-letters). Mirror of the ``letter_counts`` keys on the
            taxonomy tree response.
        offset: pagination offset, 0-based.
        limit: max rows. Hard cap at 1000.

    Pairs with ``/taxonomy?lite=true`` — the client renders the letter
    folders from ``letter_counts`` and fetches each bucket's articles
    from this endpoint on demand.
    """
    from agntspace.kb.taxonomy import (
        articles_for_path,
        flatten_taxonomy,
        load_taxonomy,
    )

    skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
    if not skills_dir:
        return {"articles": [], "total": 0, "offset": offset, "limit": limit, "has_more": False}

    vault = request.app.state.vault
    # Phase 0.3 (2026-05-04) — off-loop, see /taxonomy handler comment.
    import asyncio  # noqa: PLC0415
    all_articles = await asyncio.to_thread(_get_cached_articles, vault)

    tree = load_taxonomy(skills_dir)
    flat_nodes = flatten_taxonomy(tree)
    articles = _classify_and_enrich_articles(all_articles, flat_nodes)

    return articles_for_path(
        articles,
        path=path,
        letter=letter,
        offset=offset,
        limit=limit,
    )


@router.get("/taxonomy/slugs")
async def get_taxonomy_slugs(
    request: Request, path: str,
) -> dict:
    """Return every article slug under a taxonomy path (node + descendants).

    Replaces the client-side ``_collectTaxonomySlugs`` helper that used to
    walk the inline ``articles`` list of the full-mode tree. In lite mode
    the client no longer has that list, so this endpoint owns the
    prefix-match walk.

    Returns ``{slugs: [...], count: N}``.
    """
    from agntspace.kb.taxonomy import (
        flatten_taxonomy,
        load_taxonomy,
    )

    skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
    if not skills_dir:
        return {"slugs": [], "count": 0}

    vault = request.app.state.vault
    # Phase 0.3 (2026-05-04) — off-loop, see /taxonomy handler comment.
    import asyncio  # noqa: PLC0415
    all_articles = await asyncio.to_thread(_get_cached_articles, vault)

    vault_dir = getattr(vault, "vault_dir", None) if vault else None
    tree = load_taxonomy(skills_dir, vault_dir=vault_dir)
    flat_nodes = flatten_taxonomy(tree)
    articles = _classify_and_enrich_articles(all_articles, flat_nodes)

    slugs: list[str] = []
    path = path.strip()
    for art in articles:
        tp = art.get("taxonomy_path") or art.get("category") or ""
        if path == "unclassified":
            if tp == "":
                slugs.append(art.get("slug", ""))
        elif tp == path or tp.startswith(path + "/"):
            slugs.append(art.get("slug", ""))

    return {"slugs": [s for s in slugs if s], "count": len([s for s in slugs if s])}


# ── Taxonomy customization: pending proposals ────────────────────────


class _TaxonomyProposalRequest(BaseModel):
    path: str
    name: str
    description: str
    rationale: str = ""
    examples: list[str] | None = None


@router.get("/taxonomy/proposals")
async def list_taxonomy_proposals(request: Request) -> dict:
    """Return every pending agent-proposed taxonomy node, newest-first."""
    from agntspace.kb.taxonomy_proposals import list_pending, proposal_stats

    vault = request.app.state.vault
    vault_dir = getattr(vault, "vault_dir", None) if vault else None
    if not vault_dir:
        return {"proposals": [], "stats": {"pending_count": 0, "by_l1": {}, "newest": None}}
    return {
        "proposals": [p.to_dict() for p in list_pending(Path(vault_dir))],
        "stats": proposal_stats(Path(vault_dir)),
    }


@router.post("/taxonomy/proposals")
async def create_taxonomy_proposal(
    request: Request, body: _TaxonomyProposalRequest,
) -> dict:
    """Create a new pending taxonomy proposal (user-initiated path).

    Mirrors the agent tool's ``propose_node`` action so the user can submit
    proposals from the UI without going through chat. Always lands as
    ``proposed_by="user"`` so the audit trail is honest.
    """
    from agntspace.kb.taxonomy import flatten_taxonomy, is_valid_path, load_taxonomy
    from agntspace.kb.taxonomy_proposals import write_proposal

    vault = request.app.state.vault
    vault_dir = getattr(vault, "vault_dir", None) if vault else None
    if not vault_dir:
        raise HTTPException(status_code=503, detail="vault unavailable")

    skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
    if skills_dir:
        try:
            tree = load_taxonomy(skills_dir, vault_dir=Path(vault_dir))
            if is_valid_path(body.path, flatten_taxonomy(tree)):
                raise HTTPException(
                    status_code=409,
                    detail=f"node already exists: {body.path}",
                )
        except HTTPException:
            raise
        except Exception:
            log.exception("taxonomy validation failed")

    proposal, err = write_proposal(
        Path(vault_dir),
        path=body.path,
        name=body.name,
        description=body.description,
        rationale=body.rationale,
        proposed_by="user",
        examples=list(body.examples or []),
    )
    if err or proposal is None:
        raise HTTPException(status_code=400, detail=err or "failed to write proposal")
    return {"proposal": proposal.to_dict()}


@router.post("/taxonomy/proposals/{proposal_id}/approve")
async def approve_taxonomy_proposal(request: Request, proposal_id: str) -> dict:
    """Merge a pending proposal into the vault override file."""
    from agntspace.kb.taxonomy_proposals import approve_proposal

    vault = request.app.state.vault
    vault_dir = getattr(vault, "vault_dir", None) if vault else None
    if not vault_dir:
        raise HTTPException(status_code=503, detail="vault unavailable")

    ok, msg = approve_proposal(Path(vault_dir), proposal_id)
    if not ok:
        if msg == "not_found":
            raise HTTPException(status_code=404, detail="proposal not found")
        raise HTTPException(status_code=400, detail=msg)
    return {"approved": proposal_id, "message": msg}


@router.post("/taxonomy/proposals/{proposal_id}/reject")
async def reject_taxonomy_proposal(request: Request, proposal_id: str) -> dict:
    """Reject and remove a pending proposal."""
    from agntspace.kb.taxonomy_proposals import reject_proposal

    vault = request.app.state.vault
    vault_dir = getattr(vault, "vault_dir", None) if vault else None
    if not vault_dir:
        raise HTTPException(status_code=503, detail="vault unavailable")

    if not reject_proposal(Path(vault_dir), proposal_id):
        raise HTTPException(status_code=404, detail="proposal not found")
    return {"rejected": proposal_id}


# ── Taxonomy v1 → v2 migration (read-only preview) ───────────────────


@router.get("/taxonomy/migration/preview")
async def preview_taxonomy_migration(request: Request) -> dict:
    """Dry-run report — what every wiki article's taxonomy_path would become
    under the v1 → v2 migration. **Read-only**. No frontmatter is rewritten;
    no files are touched. Used by the UI / CLI to show the user what the
    apply step would do before they consent.

    Response shape:
        {total, changed, by_confidence: {deterministic, ambiguous,
         unclassified, unmapped}, by_old_path: {old: {new_path, confidence,
         reason, count, sample_slugs, changed}}}
    """
    from agntspace.kb.taxonomy_migration import plan_migration

    vault = request.app.state.vault
    if not vault:
        return {"total": 0, "changed": 0, "by_confidence": {}, "by_old_path": {}}

    # Phase 0.3 (2026-05-04) — off-loop, see /taxonomy handler comment.
    import asyncio  # noqa: PLC0415
    all_articles = await asyncio.to_thread(_get_cached_articles, vault)

    # plan_migration only needs slug + taxonomy_path, so the cached projection
    # is sufficient — no extra reads.
    return plan_migration(all_articles)


class _ApplyTaxonomyMigrationBody(BaseModel):
    confirm: bool = False
    confidence_filter: list[str] | None = None


@router.post("/taxonomy/migration/apply")
async def apply_taxonomy_migration(
    request: Request, body: _ApplyTaxonomyMigrationBody,
) -> dict:
    """**Destructive** — rewrites ``taxonomy_path`` frontmatter on every
    changed wiki article using the v1 → v2 mapping table.

    Requires ``confirm=true`` in the body. Use the preview endpoint first.
    Optional ``confidence_filter`` restricts which mappings apply (e.g.
    ``["deterministic"]`` skips ambiguous + unclassified).

    Per-article failures are collected and returned, never abort the batch.
    The wiki article cache is invalidated once at the end so the UI sees
    fresh paths on the next request.
    """
    from agntspace.kb.taxonomy_migration import apply_migration

    if not body.confirm:
        raise HTTPException(
            status_code=400,
            detail="set confirm=true to apply (destructive — rewrites article frontmatter)",
        )

    vault = request.app.state.vault
    kb_service = getattr(request.app.state, "kb_service", None)
    if not vault or not kb_service:
        raise HTTPException(status_code=503, detail="vault unavailable")

    # Don't trust the cache for a destructive op — read fresh from disk.
    # Phase 0.3 (2026-05-04) — off-loop so the migration's prep doesn't
    # starve the event loop for the 5-7 s the FS walk takes on a 1700-
    # article vault. The destructive part downstream is what actually
    # writes; the prep is read-only.
    import asyncio  # noqa: PLC0415
    all_articles, _ = await asyncio.to_thread(_build_article_list, vault)

    confidence_filter: set[str] | None = None
    if body.confidence_filter:
        confidence_filter = {c.strip() for c in body.confidence_filter if c.strip()}

    def _update(slug: str, new_path: str) -> None:
        # Pass content=None + metadata-only so kb_service.update_article
        # preserves the body and only rewrites frontmatter.
        kb_service.update_article(slug, None, {"taxonomy_path": new_path})

    result = apply_migration(
        all_articles, _update, confidence_filter=confidence_filter,
    )
    invalidate_article_cache()
    return result


@router.get("/articles")
async def list_articles(
    request: Request,
    category: str | None = None,
    taxonomy_path: str | None = None,
    sort: str = "title",
    limit: int = 500,
    offset: int = 0,
) -> dict:
    """List wiki articles across all KBs (paginated).

    Returns ``{articles, total, has_more}``. ``total`` is the post-filter count;
    ``has_more`` is True when ``offset + len(articles) < total``. Callers that
    need every article should loop with ``offset += limit`` until ``has_more``
    flips to False (or use the safety cap of 50 pages = 25k articles by default).

    Filter by category (legacy) or taxonomy_path (hierarchical).
    taxonomy_path matches prefix — "science-technology" includes all children.
    Auto-classifies articles that lack taxonomy_path in frontmatter.
    """
    from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy

    vault = request.app.state.vault
    # Phase 0.3 (2026-05-04) — off-loop, see /taxonomy handler comment.
    import asyncio  # noqa: PLC0415
    all_articles = await asyncio.to_thread(_get_cached_articles, vault)

    # Apply taxonomy auto-classification if filtering by taxonomy
    flat_nodes: list | None = None
    if taxonomy_path:
        skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
        if skills_dir:
            tree = load_taxonomy(skills_dir)
            flat_nodes = flatten_taxonomy(tree)

    # Filter
    filtered = []
    for a in all_articles:
        tp = a.get("taxonomy_path", "")
        if not tp and flat_nodes:
            tp = classify_article(
                entity_type=a.get("entity_type", ""),
                category=a.get("category", ""),
                title=a.get("title", ""),
                flat_nodes=flat_nodes,
            )
        if category and a.get("category", "") != category:
            continue
        if taxonomy_path and not (tp == taxonomy_path or tp.startswith(taxonomy_path + "/")):
            continue
        filtered.append(a)

    # Sort
    if sort == "recent":
        filtered.sort(key=lambda a: a.get("mtime", 0), reverse=True)
    elif sort == "links":
        filtered.sort(key=lambda a: len(a.get("links", [])), reverse=True)
    # default: already sorted by title from cache

    total = len(filtered)
    safe_offset = max(0, offset)
    safe_limit = max(1, limit)
    sliced = filtered[safe_offset : safe_offset + safe_limit]
    return {
        "articles": sliced,
        "total": total,
        "has_more": safe_offset + len(sliced) < total,
    }


@router.get("/article/{slug}")
async def get_article(request: Request, slug: str) -> dict:
    """Get a single wiki article by slug. Searches across all KBs.

    The body runs in a worker thread (``asyncio.to_thread``) because every
    step underneath is synchronous filesystem I/O — disk reads, frontmatter
    parses, library globs, bibliography lookups. Without the thread hop,
    one slow article (cache miss → kb_service fallback that re-globs the
    whole vault) blocks the asyncio event loop for 5-10 seconds, starving
    every concurrent request behind it. Symptom in the UI: clicking
    article B while article A is still loading freezes the WHOLE wiki page.
    """
    import asyncio  # noqa: PLC0415

    return await asyncio.to_thread(_get_article_sync, request, slug)


def _get_article_sync(request: Request, slug: str) -> dict:
    """Synchronous body of get_article. See get_article for the threading
    rationale. All filesystem I/O lives here."""
    vault = request.app.state.vault

    # Find article by slug: check article cache first. The cache is built
    # from frontmatter ``slug`` (or kebab-of-stem fallback) for every wiki
    # file in the vault and is the canonical index. On cache miss we 404
    # directly — both previous fallbacks (wiki-route wide-glob AND
    # ``kb_svc._find_article_by_slug``) globbed every wiki file and read
    # frontmatter from each, costing 5-15 s per miss on large vaults AND
    # blocking every concurrent request behind them.
    #
    # Trade-off: a freshly created article isn't queryable until the
    # cache rebuilds (60 s TTL with stale-while-revalidate). Acceptable;
    # the user can hard-refresh or wait. The previous "always glob on
    # miss" behaviour was effectively a self-DoS at vault scale.
    articles = _get_cached_articles(vault)
    cached = next((a for a in articles if a["slug"] == slug), None)
    if not cached:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    f = vault.vault_dir / cached["path"]
    result = _read_article_safe(vault, f)
    if not result:
        # File listed in cache but no longer readable on disk (deleted
        # since the cache was built). Treat as 404 — caller should retry
        # after the cache TTL expires.
        raise HTTPException(status_code=404, detail=f"Article not readable: {slug}")
    rel, meta, content = result

    raw_links = re.findall(r"\[\[([^\]]+)\]\]", content)
    links = [lnk.split("|")[0].strip() for lnk in raw_links]

    # Resolve display-name links to canonical wiki slugs.
    # Build a case-insensitive title→slug map from the article cache.
    link_slugs: dict[str, str] = {}
    if links:
        _title_to_slug: dict[str, str] = {}
        for a in articles:
            _title_to_slug[a["title"].lower()] = a["slug"]
            # Also map slug-derived form (lowercase, spaces→hyphens)
            derived = re.sub(r"[^a-z0-9]+", "-", a["title"].lower()).strip("-")
            _title_to_slug[derived] = a["slug"]
        for display_name in links:
            key = display_name.lower()
            resolved = _title_to_slug.get(key)
            if not resolved:
                # Try kebab-case form
                derived_key = re.sub(r"[^a-z0-9]+", "-", key).strip("-")
                resolved = _title_to_slug.get(derived_key)
            link_slugs[display_name] = resolved or re.sub(r"[^a-z0-9]+", "-", key).strip("-")

    source_file = meta.get("source_file", "")
    library_path = meta.get("library_path", "")
    kb_slug = _extract_kb_slug(rel)

    # Derive source_url — web URL from frontmatter, or local library path
    source_url = meta.get("source_url", "")
    image_url = ""
    # Local file path for vault/library sources
    local_source = ""
    if source_file:
        if library_path:
            clean = library_path.replace("../../", "")
            local_source = f"knowledge/{kb_slug}/{clean}" if not clean.startswith("knowledge/") else clean
        else:
            try:
                found = vault.list_files(f"knowledge/{kb_slug}/library", f"**/{source_file}")
                if found:
                    local_source = _kb_relative_path(found[0], vault)
            except Exception:
                pass

        file_path = local_source or source_url
        if file_path and re.search(r"\.(png|jpg|jpeg|gif|webp|svg)$", source_file, re.I):
            image_url = file_path

    # Scan content for inline image references
    content_images: list[str] = []
    for img_match in re.finditer(r"!\[[^\]]*\]\(([^)]+)\)", content):
        img_path = img_match.group(1)
        if img_path.startswith("../../"):
            img_path = f"knowledge/{kb_slug}/{img_path[6:]}"
        elif img_path.startswith("library/"):
            img_path = f"knowledge/{kb_slug}/{img_path}"
        if re.search(r"\.(png|jpg|jpeg|gif|webp|svg)$", img_path, re.I):
            content_images.append(img_path)

    if not image_url and content_images:
        image_url = content_images[0]

    # Resolve vault paths for all source files
    source_paths = _resolve_source_paths(request, meta.get("sources", []), kb_slug)

    # Build structured references from bibliography (proper data, no regex needed on client)
    _FAKE_DOMAINS = {"example.com", "localhost", "placeholder", "fake.com", "test.test"}

    def _is_fake(url: str) -> bool:
        return any(d in url.lower() for d in _FAKE_DOMAINS) if url else False

    references: list[dict] = []
    bib_svc = getattr(request.app.state, "bibliography_service", None)
    source_list = meta.get("sources", [])
    if bib_svc and source_list:
        for fname in source_list:
            bib = bib_svc.find_by_source(fname, kb_slug)
            ref: dict = {"source_file": fname}
            if bib:
                ref["title"] = bib.get("title", fname)
                ref["authors"] = bib.get("authors", [])
                ref["date"] = bib.get("date", "")
                ref["publisher"] = bib.get("publisher", "") if not _is_fake(bib.get("publisher", "")) else ""
                url = bib.get("url", "")
                ref["url"] = url if not _is_fake(url) else ""
            else:
                ref["title"] = fname
                ref["authors"] = []
                ref["date"] = ""
                ref["publisher"] = ""
                ref["url"] = ""
            # Resolve local vault path for the source file
            ref["local_path"] = ""
            vault_path = source_paths.get(fname, "")
            if vault_path:
                m = vault_path.replace("\\", "/")
                idx = m.find("agntspace-knowledge/")
                if idx >= 0:
                    ref["local_path"] = "knowledge/" + m[idx + len("agntspace-knowledge/"):]
            ref["is_local"] = bool(not ref["url"])
            references.append(ref)

    return {
        "slug": slug,
        "title": meta.get("title", slug.replace("-", " ").title()),
        "category": meta.get("category", ""),
        "taxonomy_path": meta.get("taxonomy_path", ""),
        "entity_type": meta.get("entity_type", ""),
        "provenance": meta.get("provenance", ""),
        "content": content,
        "links": links,
        "link_slugs": link_slugs,
        "related": meta.get("related", []),
        "sources": meta.get("sources", []),
        "source_paths": source_paths,
        "references": references,
        "source_file": source_file,
        "library_path": library_path,
        "vault_source": _resolve_vault_source(request, meta, kb_slug),
        "created_reason": meta.get("created_reason", ""),
        "source_url": source_url,
        "image_url": image_url,
        "images": content_images,
        "path": rel,
        "kb": kb_slug,
        "date_created": meta.get("date_created", meta.get("date", "")),
        "date_updated": meta.get("date_updated", ""),
        "author": meta.get("author", ""),
        "agent": meta.get("agent", ""),
        # Three-language architecture v1.1 audit fields (source_summary pages)
        "content_language": meta.get("content_language", ""),
        "output_language": meta.get("output_language", ""),
        "language_policy": meta.get("language_policy", ""),
        "language_policy_source": meta.get("language_policy_source", ""),
        "language_adherence": meta.get("language_adherence", ""),
        "secondary_output_language": meta.get("secondary_output_language", ""),
        # Phase 4.5 — extractor provenance (source_summary pages). Empty
        # on legacy pre-4.5 sources; the UI uses presence to decide
        # whether to offer a "re-ingest with {tier}" button.
        "type_name": meta.get("type_name", ""),
        "extractor_id": meta.get("extractor_id", ""),
        "extractor_version": meta.get("extractor_version", ""),
    }


@router.get("/categories")
async def list_categories(request: Request) -> list[dict]:
    """List all categories with article counts."""
    vault = request.app.state.vault
    categories: dict[str, int] = {}

    for f in _list_wiki_files(vault):
        result = _read_article_safe(vault, f)
        if not result:
            continue
        _rel, meta, _content = result
        cat = meta.get("category", "uncategorized")
        categories[cat] = categories.get(cat, 0) + 1

    return [{"name": name, "count": count} for name, count in sorted(categories.items())]


@router.get("/people")
async def list_people(request: Request) -> list[dict]:
    """List all person entities in the wiki (articles with entity_type: person)."""
    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)
    people = []
    for a in articles:
        if a.get("entity_type") == "person":
            people.append({
                "name": a["title"],
                "slug": a["slug"],
                "excerpt": a.get("excerpt", ""),
                "kb": a.get("kb", ""),
                "links": len(a.get("links", [])),
            })
    return sorted(people, key=lambda p: p["name"])


def _query_tokens(q: str) -> list[str]:
    """Lowercase Unicode word tokens. Matches FTS5's tokenizer."""
    return [t.lower() for t in re.findall(r"\w+", q, re.UNICODE)]


def _title_word_match(title: str, query_tokens: list[str]) -> bool:
    """True iff every query token appears as a WHOLE WORD in the title.

    Critical for relevance: substring match would boost "Damascus" for query
    "dam". Word-boundary match means "dam" boosts "Teton Dam Failure" only.
    """
    if not query_tokens:
        return False
    title_tokens = {t.lower() for t in re.findall(r"\w+", title, re.UNICODE)}
    return all(t in title_tokens for t in query_tokens)


def _is_wiki_article_path(path_str: str) -> bool:
    """True iff the path is a real wiki article (not history / archive / hidden)."""
    norm = path_str.replace("\\", "/")
    if "/wiki/" not in norm:
        return False
    # Exclude any dot-prefixed segment (.history/, .archives/, .pytest_cache/, etc.).
    if any(part.startswith(".") for part in norm.split("/") if part):
        return False
    # Exclude index/catalog files.
    base = norm.rsplit("/", 1)[-1]
    if base.startswith("_") or base in {"_index.md", "_concepts.md"}:
        return False
    return True


@router.get("/search")
async def search_wiki(request: Request, q: str, limit: int = 20, offset: int = 0) -> dict:
    """Full-text search across all wiki articles.

    Two-tier engine:

    1. **FTS5 via VaultSearch** — proper word-boundary tokenization + BM25
       ranking. Restricted to wiki paths via post-filter. Title matches get
       a word-boundary boost so "dam" prefers "Teton Dam Failure" over
       "Damascus" or "damaged".
    2. **Substring fallback** — when FTS5 is unavailable (vault_search not
       wired), returns 0 hits, OR raises, the legacy substring scan keeps
       working. Same behavior as before for fresh vaults.

    Returns ``{items, total, has_more}`` per CLAUDE.md Rule 20 — counts never
    silently cap. ``total`` is the post-filter, post-sort count.
    """
    vault = request.app.state.vault
    vault_search = getattr(request.app.state, "vault_search", None)

    q_stripped = q.strip()
    query_tokens = _query_tokens(q_stripped)
    if not q_stripped or not query_tokens:
        return {"items": [], "total": 0, "has_more": False}

    # Tier 1: FTS5 with BM25 + word-boundary title boost.
    fts_items: list[dict] = []
    if vault_search is not None:
        try:
            # Over-fetch — wiki articles are a subset of all vault files,
            # so we filter post-hoc and need headroom.
            raw = await vault_search.search(q_stripped, limit=max(200, (limit + offset) * 4))
        except Exception:
            log.exception("Wiki FTS5 search failed; falling back to substring")
            raw = []

        articles = await asyncio.to_thread(_get_cached_articles, vault)
        articles_by_path = {a["path"]: a for a in articles}

        for r in raw:
            path = r.get("path") or ""
            if not _is_wiki_article_path(path):
                continue
            cached = articles_by_path.get(path)
            if not cached:
                continue
            title = cached.get("title", r.get("title", ""))
            # FTS5 BM25 ranks are negative (lower = better match). Convert
            # to a positive score so the rest of the pipeline can rank
            # uniformly: higher = better.
            base_score = -float(r.get("score", 0.0) or 0.0)
            # Word-boundary title boost. Substring would mis-fire on
            # "Damascus" / "damaged"; tokenized match is precise.
            if _title_word_match(title, query_tokens):
                base_score += 10.0
            snippet = r.get("snippet") or cached.get("excerpt", "")[:200]
            fts_items.append({
                "slug": cached["slug"],
                "title": title,
                "category": cached.get("category", ""),
                "snippet": snippet,
                "score": base_score,
                "kb": cached.get("kb", ""),
            })

    if fts_items:
        fts_items.sort(key=lambda x: x["score"], reverse=True)
        total = len(fts_items)
        safe_offset = max(0, offset)
        safe_limit = max(1, limit)
        sliced = fts_items[safe_offset : safe_offset + safe_limit]
        return {
            "items": sliced,
            "total": total,
            "has_more": safe_offset + len(sliced) < total,
            "engine": "fts5",
        }

    # Tier 2: legacy substring fallback (fresh vault / FTS5 returned nothing).
    # Word-boundary tokenized so we don't regress to "Damascus" matching "dam".
    query_lower = q_stripped.lower()
    results: list[dict] = []
    articles = await asyncio.to_thread(_get_cached_articles, vault)

    for a in articles:
        path = a.get("path", "")
        if not _is_wiki_article_path(path):
            continue
        title = a.get("title", "")
        excerpt = a.get("excerpt", "")

        score = 0.0
        if _title_word_match(title, query_tokens):
            score += 10.0
        if query_lower in excerpt.lower():
            score += 3.0

        # Always read body for content occurrences — title/excerpt match
        # alone shouldn't suppress a deep body match's contribution.
        f = vault.vault_dir / path
        file_result = _read_article_safe(vault, f)
        content = file_result[2] if file_result else excerpt
        content_lower = content.lower()

        # Count whole-word occurrences of every query token in body.
        body_tokens = re.findall(r"\w+", content_lower, re.UNICODE)
        body_token_set = set(body_tokens)
        body_token_count = sum(1 for t in body_tokens if t in query_tokens)
        if all(t in body_token_set for t in query_tokens):
            score += min(body_token_count, 8)

        if score == 0:
            continue

        # Snippet from body match if present, else excerpt.
        first_token = query_tokens[0]
        idx = content_lower.find(first_token)
        if idx >= 0:
            start = max(0, idx - 80)
            end = min(len(content), idx + 120)
            snippet = content[start:end].strip()
            if start > 0:
                snippet = "..." + snippet
            if end < len(content):
                snippet += "..."
        else:
            snippet = excerpt

        results.append({
            "slug": a["slug"],
            "title": title,
            "category": a.get("category", ""),
            "snippet": snippet,
            "score": score,
            "kb": a.get("kb", ""),
        })

    results.sort(key=lambda r: r["score"], reverse=True)
    total = len(results)
    safe_offset = max(0, offset)
    safe_limit = max(1, limit)
    sliced = results[safe_offset : safe_offset + safe_limit]
    return {
        "items": sliced,
        "total": total,
        "has_more": safe_offset + len(sliced) < total,
        "engine": "substring",
    }


@router.get("/recent")
async def recent_changes(request: Request, limit: int = 20, offset: int = 0) -> dict:
    """Recently modified wiki articles. Returns ``{items, total, has_more}``."""
    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)

    result = [
        {
            "slug": a["slug"],
            "title": a["title"],
            "modified": datetime.fromtimestamp(a.get("mtime", 0), tz=UTC).isoformat(),
            "kb": a.get("kb", ""),
        }
        for a in articles if a.get("mtime", 0) > 0 and a.get("entity_type") != "source_summary"
    ]
    result.sort(key=lambda a: a["modified"], reverse=True)
    total = len(result)
    safe_offset = max(0, offset)
    safe_limit = max(1, limit)
    sliced = result[safe_offset : safe_offset + safe_limit]
    return {
        "items": sliced,
        "total": total,
        "has_more": safe_offset + len(sliced) < total,
    }


@router.get("/popular")
async def popular_articles(request: Request, limit: int = 10, offset: int = 0) -> dict:
    """Most linked articles — articles that appear in the most [[links]] across the wiki.

    Returns ``{items, total, has_more}``.
    """
    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)
    link_counts: dict[str, int] = {}
    slug_titles: dict[str, str] = {}

    # Slugs to exclude from ranking (index/catalog files, not real articles).
    # `sources` retained as legacy alias during the 2026-04-27 sources→digests
    # L1 rename transition.
    _META_SLUGS = {"digests", "sources", "links", "index", "concepts", "catalog", "decisions"}

    for a in articles:
        slug = a["slug"]
        # Skip source summary articles and meta-articles from being counted as sources of links
        entity_type = a.get("entity_type", "")
        if entity_type == "source_summary" or slug in _META_SLUGS:
            continue
        slug_titles[slug] = a["title"]
        for link in a.get("links", []):
            link_slug = link.split("/")[-1].lower().replace(" ", "-")
            # Don't count references to meta-articles
            if link_slug not in _META_SLUGS:
                link_counts[link_slug] = link_counts.get(link_slug, 0) + 1

    ranked = [
        (slug, count) for slug, count in sorted(link_counts.items(), key=lambda x: x[1], reverse=True)
        if slug not in _META_SLUGS
    ]
    materialised = [
        {"slug": slug, "title": slug_titles.get(slug, slug.replace("-", " ").title()), "link_count": count}
        for slug, count in ranked
    ]
    total = len(materialised)
    safe_offset = max(0, offset)
    safe_limit = max(1, limit)
    sliced = materialised[safe_offset : safe_offset + safe_limit]
    return {
        "items": sliced,
        "total": total,
        "has_more": safe_offset + len(sliced) < total,
    }


@router.get("/featured")
async def featured_article(request: Request) -> dict:
    """Featured article — the most recently compiled article with the most links."""

    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)

    best = None
    best_score = -1.0
    for a in articles:
        link_count = len(a.get("links", []))
        excerpt_len = len(a.get("excerpt", ""))
        score = link_count + excerpt_len / 100
        if score > best_score and excerpt_len > 50:
            best_score = score
            best = {
                "slug": a["slug"],
                "title": a["title"],
                "category": a.get("category", ""),
                "excerpt": a.get("excerpt", ""),
                "link_count": link_count,
                "kb": a.get("kb", ""),
            }

    return {"article": best}


@router.get("/stats")
async def wiki_stats(request: Request) -> dict:
    """Overall wiki statistics.

    Body runs in a worker thread because ``kb_service.list_kbs()`` walks
    every KB folder and reads index frontmatter — synchronous filesystem
    I/O measured at ~1 s on a 3-KB / 1700-article vault. Without the
    thread hop this blocks the asyncio event loop for the whole call,
    starving every concurrent request behind it.

    arch:short-ttl-cache — Phase 0.2 (2026-05-04). Response is cached for
    `_wiki_stats_cache["ttl"]` (30 s) and invalidated by
    `invalidate_wiki_stats_cache()` (which is fired automatically by
    `invalidate_article_cache()` on every wiki write). Mutations win
    immediately; the TTL is the safety net for missed invalidations.
    """
    import asyncio  # noqa: PLC0415
    import time as _time  # noqa: PLC0415

    # Fast path — cached response within TTL.
    cached = _wiki_stats_cache["value"]
    if cached is not None and (_time.time() - _wiki_stats_cache["built_at"]) < _wiki_stats_cache["ttl"]:
        return cached

    kb_service = request.app.state.kb_service

    def _compute() -> dict:
        kbs = kb_service.list_kbs()
        total_articles = sum(kb.get("articles", 0) for kb in kbs)
        total_sources = sum(kb.get("sources", 0) for kb in kbs)
        return {
            "knowledge_bases": len(kbs),
            "total_articles": total_articles,
            "total_sources": total_sources,
            "kbs": kbs,
        }

    result = await asyncio.to_thread(_compute)
    _wiki_stats_cache["value"] = result
    _wiki_stats_cache["built_at"] = _time.time()
    return result


@router.get("/ingested")
async def recent_ingestions(request: Request, limit: int = 15, offset: int = 0) -> dict:
    """Recently ingested sources — shows what the agent has processed.

    Body runs in a worker thread because the underlying step (glob the
    wiki/digests + wiki/sources subtrees + read frontmatter from every
    matching file) is synchronous filesystem I/O measured at ~6.7 s on a
    1700-article vault. Without the thread hop this blocks the asyncio
    event loop for the whole call, starving every concurrent request
    behind it — exactly the "I clicked an article and it took 3 s"
    symptom on the wiki page bootstrap.

    Returns ``{items, total, has_more}``.
    """
    import asyncio  # noqa: PLC0415

    return await asyncio.to_thread(_recent_ingestions_sync, request, limit, offset)


def _recent_ingestions_sync(request: Request, limit: int, offset: int) -> dict:
    """Synchronous body of ``recent_ingestions``. All filesystem I/O lives here."""
    vault = request.app.state.vault
    items: list[dict] = []

    try:
        # Glob covers both the new `wiki/digests/` (post-rename, 2026-04-27)
        # and legacy `wiki/sources/` paths during the transition. Either
        # subdir layout is accepted; deduplicated via the slug check below.
        files = vault.list_files("knowledge", "**/wiki/digests/**/*.md")
        legacy = vault.list_files("knowledge", "**/wiki/sources/*.md")
        files = list(files) + list(legacy)
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")]
    except Exception:
        log.exception("Failed to list ingested sources")
        return {"items": [], "total": 0, "has_more": False}

    for f in files:
        if f.name.startswith(("_", ".")):
            continue
        result = _read_article_safe(vault, f)
        if not result:
            continue
        rel, meta, content = result
        date_created = meta.get("date_created", "")
        excerpt = ""
        for line in content.split("\n"):
            line = line.strip()
            if line and not line.startswith("#") and not line.startswith("-") and not line.startswith(">"):
                excerpt = line[:200]
                break
        items.append({
            "slug": meta.get("slug") or re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-"),
            "title": meta.get("source_file", f.stem.replace("-", " ").title()),
            "category": meta.get("category", ""),
            "date": date_created,
            "excerpt": excerpt,
            "kb": _extract_kb_slug(rel),
        })

    items.sort(key=lambda a: a.get("date", ""), reverse=True)
    total = len(items)
    safe_offset = max(0, offset)
    safe_limit = max(1, limit)
    sliced = items[safe_offset : safe_offset + safe_limit]
    return {
        "items": sliced,
        "total": total,
        "has_more": safe_offset + len(sliced) < total,
    }


@router.get("/stale")
async def list_stale_articles(request: Request) -> list[dict]:
    """List all stale articles (source was deleted)."""
    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)
    return [
        {"slug": a["slug"], "title": a["title"], "path": a.get("path", ""), "kb": a.get("kb", "")}
        for a in articles if a.get("status") == "stale"
    ]


class CreateArticleBody(BaseModel):
    kb_slug: str
    title: str
    content: str = ""
    entity_type: str = "concept"
    subdir: str | None = None


class UpdateArticleBody(BaseModel):
    content: str | None = None
    metadata: dict | None = None


class RenameArticleBody(BaseModel):
    new_title: str


@router.post("/article")
async def create_article(request: Request, body: CreateArticleBody) -> dict:
    """Create a new wiki article in a specific KB."""
    kb_service = request.app.state.kb_service
    try:
        result = kb_service.create_article(
            body.kb_slug, body.title, body.content, body.entity_type, body.subdir,
        )
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e)) from e

    invalidate_article_cache()
    return result


@router.put("/article/{slug}")
async def update_article(request: Request, slug: str, body: UpdateArticleBody) -> dict:
    """Update a wiki article's content and/or metadata."""
    if body.content is None and body.metadata is None:
        raise HTTPException(status_code=400, detail="Provide content and/or metadata to update")

    kb_service = request.app.state.kb_service
    try:
        result = kb_service.update_article(slug, body.content, body.metadata)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    invalidate_article_cache()
    return result


# ── Stage E2 — inline AI actions in the wiki editor ────────────────────


class AiActionBody(BaseModel):
    """Payload for the inline ``/ai`` slash-menu commands. Caller sends:

      action:    one of the actions declared in
                 `wiki-ai-actions/config/actions.yaml` (summarize / extend /
                 translate / extract-actions / rephrase or any user-added
                 entry)
      selection: the text the user has highlighted in the editor
      context:   the surrounding article body (truncated server-side)
      params:    action-specific dict — e.g. `{target_lang: "Spanish"}`
                 for translate; ignored when the action declares no
                 `requires_param`.

    The endpoint is read-only — it returns the LLM output but does NOT
    write to the article. The frontend decides whether to insert.
    """
    action: str
    selection: str = ""
    context: str = ""
    params: dict | None = None


@router.post("/article/{slug}/ai-action")
async def ai_action(request: Request, slug: str, body: AiActionBody) -> dict:
    """Run a wiki inline AI action against a piece of selected text.

    Reads the action's prompt template + model tier + max_tokens from
    ``wiki-ai-actions/config/actions.yaml``. Substitutes ``{selection}``,
    ``{context}``, and any required params, dispatches via
    ``agent.process_task(model_tier=...)``, returns the result.

    Returns 400 if the action is not declared, 422 if a required param
    is missing. Truncates selection / context per the YAML limits with
    a ``truncated`` flag.
    """
    if not body.action.strip():
        raise HTTPException(status_code=400, detail="action is required")
    if not body.selection.strip():
        raise HTTPException(status_code=400, detail="selection is required")

    skill_loader = getattr(request.app.state, "skill_loader", None)
    agent = getattr(request.app.state, "agent", None)
    if skill_loader is None or agent is None:
        raise HTTPException(status_code=503, detail="Agent not configured")

    # Verify article exists (don't proceed if slug is bogus).
    kb_service = request.app.state.kb_service
    try:
        article = kb_service.get_article(slug) if hasattr(kb_service, "get_article") else None
    except Exception:
        article = None
    # Don't fail-hard on missing article — the action is read-only and
    # the caller may have a stale slug. Just don't load context.
    article_metadata = (article or {}).get("metadata", {}) if article else {}

    # Load the action definitions from skill YAML.
    try:
        cfg = skill_loader.load_skill_config_file(
            "wiki-ai-actions", "actions.yaml",
        ) or {}
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to load wiki-ai-actions config: {e}",
        ) from e

    actions = (cfg.get("actions") or {})
    action_def = actions.get(body.action)
    if action_def is None:
        available = sorted(actions.keys())
        raise HTTPException(
            status_code=400,
            detail=f"Unknown action '{body.action}'. Available: {available}",
        )

    # Required params validation.
    requires_param = action_def.get("requires_param")
    params = body.params or {}
    required_list = (
        [requires_param] if isinstance(requires_param, str)
        else list(requires_param) if isinstance(requires_param, list)
        else []
    )
    missing = [p for p in required_list if not (params.get(p) or "").strip()]
    if missing:
        raise HTTPException(
            status_code=422,
            detail=f"Missing required params for {body.action}: {missing}",
        )

    # Truncation per YAML limits.
    max_sel = int(cfg.get("max_selection_chars", 16000))
    max_ctx = int(cfg.get("max_context_chars", 4000))
    selection = body.selection
    context_text = body.context
    truncated = False
    if len(selection) > max_sel:
        selection = selection[:max_sel]
        truncated = True
    if len(context_text) > max_ctx:
        context_text = context_text[:max_ctx]
        truncated = True

    # Resolve template + model tier with global defaults.
    defaults = cfg.get("defaults") or {}
    model_tier = action_def.get("model_tier") or defaults.get("model_tier", "fast")
    max_tokens = int(action_def.get("max_tokens") or defaults.get("max_tokens", 400))

    template = action_def.get("prompt_template") or ""
    if not template.strip():
        raise HTTPException(
            status_code=500,
            detail=f"Action '{body.action}' has no prompt_template",
        )

    # Format the prompt — defensive .format_map so missing placeholders
    # don't crash with a KeyError on the LLM call.
    try:
        format_args = {
            "selection": selection,
            "context": context_text,
            **{k: str(v) for k, v in params.items()},
        }
        prompt = template.format_map(_DefaultFormatDict(format_args))
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Template format failed: {e}",
        ) from e

    # Dispatch via process_task. max_tokens is informational — most
    # tiers honor LLM-side max_tokens via the provider config; we don't
    # thread it directly but the prompt asks for brevity.
    try:
        result_text = await agent.process_task(
            task=prompt,
            context="",
            model_tier=model_tier,
        )
    except Exception as e:  # noqa: BLE001
        log.exception("wiki ai-action %s failed: %s", body.action, e)
        raise HTTPException(
            status_code=500,
            detail=f"AI action failed: {e}",
        ) from e

    # Activity event so the agent sees inline-AI usage in its world model.
    try:
        activity = getattr(request.app.state, "activity_logger", None)
        if activity is not None:
            await activity.log(
                category="user",
                action="wiki_ai_action",
                summary=f"User ran /{body.action} on '{slug}'",
                details={
                    "slug": slug,
                    "action": body.action,
                    "selection_length": len(selection),
                    "context_length": len(context_text),
                    "truncated": truncated,
                    "result_length": len(result_text or ""),
                    "model_tier": model_tier,
                },
                importance="low",
            )
    except Exception:
        pass

    return {
        "action": body.action,
        "result": result_text or "",
        "model_tier": model_tier,
        "max_tokens": max_tokens,
        "truncated": truncated,
        "article_title": article_metadata.get("title", slug),
    }


class _DefaultFormatDict(dict):
    """``str.format_map`` variant that returns ``{key}`` for missing keys
    instead of raising KeyError — makes templates robust to extra
    placeholders the YAML defines but the caller didn't supply."""
    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


@router.post("/article/{slug}/rename")
async def rename_article(request: Request, slug: str, body: RenameArticleBody) -> dict:
    """Rename a wiki article — updates file, slug, and all backlinks."""
    if not body.new_title.strip():
        raise HTTPException(status_code=400, detail="new_title is required")

    kb_service = request.app.state.kb_service
    try:
        result = kb_service.rename_article(slug, body.new_title.strip())
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e)) from e

    invalidate_article_cache()
    return result


@router.get("/article/{slug}/backlinks")
async def get_backlinks(request: Request, slug: str, include_list: bool = False) -> dict:
    """Count how many articles link to this slug/title. O(1) via cached
    inverted index built alongside the article cache.

    Pass ?include_list=true to also return the list of backlinking articles.

    The previous implementation re-walked the entire wiki tree per click
    (~1700 file reads on this vault) and took 2.7-4.8 s every time the
    user opened an article. The cached index is built once per article-
    cache TTL window and hit in <1 ms.
    """
    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)
    cached = next((a for a in articles if a["slug"] == slug), None)
    title = cached["title"] if cached else slug.replace("-", " ").title()

    # Phase 0.3 (2026-05-04) — also off-loop. _get_cached_backlinks_index
    # touches _get_cached_articles internally; if that's cold-cache it
    # blocks the event loop. The to_thread above primes the cache so
    # this call hits the warm path, but the wrap is defensive (in case
    # of a TTL boundary or invalidation racing in between).
    index = await asyncio.to_thread(_get_cached_backlinks_index, vault)

    # Look up under every possible key shape: slug, title-lowercased,
    # kebab-of-title. The index was populated under all three. Dedup by
    # source_path because a single article can link to a target via
    # multiple keys (e.g. one [[Title]] AND one [[slug]] in the same body).
    keys = {
        slug,
        slug.lower(),
        title.lower(),
        re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-"),
    }
    seen_paths: set[str] = set()
    items: list[dict] = []
    cached_path = cached.get("path") if cached else None
    for key in keys:
        for entry in index.get(key, ()):
            sp = entry.get("source_path", "")
            if sp == cached_path:  # ignore self-links
                continue
            if sp in seen_paths:
                continue
            seen_paths.add(sp)
            # Strip the index-only `source_path` field from the response
            # shape so the wire contract stays identical to the previous
            # implementation.
            items.append({
                "slug": entry["slug"],
                "title": entry["title"],
                "kb": entry["kb"],
                "snippet": entry.get("snippet", ""),
            })

    result: dict = {"slug": slug, "backlink_count": len(items)}
    if include_list:
        result["backlinks"] = items
    return result


@router.get("/article/{slug}/mentions")
async def get_article_mentions(
    request: Request,
    slug: str,
    context_type: str = "",
    limit: int = 100,
    offset: int = 0,
) -> dict:
    """Return narrative-source mentions of this entity.

    Phase 1 second-brain integration. Reads the SPO graph for triples
    where ``predicate=references`` and ``object=<entity_slug>``. Each
    triple's ``situational_context`` carries a snippet, the source-side
    context type (``journal_user``, ``eod_report``, ``decision``, etc.),
    and the offset of the match — the UI groups by ``context_type`` and
    renders snippets with deep links back to the source.

    Optional filters:

    - ``context_type`` — return only mentions tagged with this label
      (case-sensitive). Empty = all types.
    - ``limit`` / ``offset`` — paginate by recency (newest first).

    Returns ``{slug, total, has_more, items: [...], by_type: {...}}``
    where ``by_type`` is a count map for the panel badge UI.
    """
    graph = getattr(request.app.state, "knowledge_graph", None)
    if graph is None:
        return {
            "slug": slug,
            "total": 0,
            "has_more": False,
            "items": [],
            "by_type": {},
        }

    # The article slug is the canonical entity slug for wiki articles —
    # references triples are keyed on that. The query is straightforward
    # because we only care about object=<slug>.
    triples_for_obj: list = []
    try:
        for triple in graph._triples:  # noqa: SLF001 — read-only snapshot
            if not isinstance(triple, dict):
                continue
            if triple.get("predicate") != "references":
                continue
            if triple.get("object") != slug:
                continue
            # Skip retracted/superseded — those shouldn't surface.
            if triple.get("epistemic_status") in {"retracted", "superseded"}:
                continue
            sc = triple.get("situational_context") or {}
            if not isinstance(sc, dict):
                sc = {}
            ctx = sc.get("context_type", "")
            if context_type and ctx != context_type:
                continue
            triples_for_obj.append({
                "source_path": triple.get("subject", ""),
                "context_type": ctx,
                "snippet": sc.get("snippet", ""),
                "matched_text": sc.get("matched_text", ""),
                "offset": int(sc.get("offset", 0) or 0),
                "when": sc.get("when") or triple.get("source_date") or triple.get("first_seen") or "",
                "pass_name": sc.get("pass_name", ""),
                "confidence": float(triple.get("confidence", 0.0) or 0.0),
                "epistemic_status": triple.get("epistemic_status", ""),
            })
    except Exception:  # noqa: BLE001
        log.debug("graph triple scan failed in get_article_mentions", exc_info=True)
        triples_for_obj = []

    # Newest first.
    triples_for_obj.sort(key=lambda x: x.get("when", ""), reverse=True)

    # Build by_type counts BEFORE pagination so the UI badges reflect
    # totals, not just the current page (Rule 20 — counts never lie).
    by_type: dict[str, int] = {}
    for entry in triples_for_obj:
        ctx = entry.get("context_type", "") or "(unknown)"
        by_type[ctx] = by_type.get(ctx, 0) + 1

    total = len(triples_for_obj)
    if offset < 0:
        offset = 0
    if limit < 0:
        limit = 100
    page = triples_for_obj[offset : offset + limit]
    has_more = (offset + limit) < total

    return {
        "slug": slug,
        "total": total,
        "has_more": has_more,
        "items": page,
        "by_type": by_type,
    }


@router.delete("/article/{slug}")
async def delete_article(request: Request, slug: str) -> dict:
    """Delete a wiki article across all KBs.

    Idempotent on the file axis: if the underlying ``.md`` was already
    removed out-of-band (manual delete in Obsidian / file explorer / git
    checkout), still scrub stale ``_index.md`` references and retract
    matching graph triples instead of returning a confusing 404. The
    user's intent is "make this article go away" — honour it by cleaning
    every trace we can find. Only return 404 when there are NO traces
    anywhere (real wrong slug).
    """
    vault = request.app.state.vault
    kb_service = request.app.state.kb_service
    knowledge_graph = getattr(request.app.state, "knowledge_graph", None)

    # Capture backlinks BEFORE we mutate so the caller can warn about broken links.
    # find_backlinks() already returns [] when the article file is gone, so it
    # stays cheap on the phantom path.
    broken_backlinks = kb_service.find_backlinks(slug)

    # 1) Find on-disk files matching slug (filename or frontmatter).
    try:
        files = vault.list_files("knowledge", f"**/wiki/**/{slug}.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")]
    except Exception:
        files = []

    if not files:
        found = kb_service._find_article_by_slug(slug)
        if found:
            _kb, _sd, fpath, _meta, _content = found
            files = [fpath]

    # 2) Delete the files we found. Track logical paths for graph cleanup.
    deleted: list[str] = []
    deleted_logical: list[str] = []
    for f in files:
        try:
            rel = _kb_relative_path(f, vault)
            full = f if f.is_absolute() else vault._resolve(rel)
            if full.exists():
                full.unlink()
                deleted.append(str(f.name))
                deleted_logical.append(rel.replace("\\", "/"))
        except Exception:
            log.exception("Failed to unlink wiki article file %s", f)
            continue

    # 3) Discover phantom traces in the graph: triples whose only source is a
    # path that LOOKS like this slug's wiki file (slug derived from filename
    # stem matches). Catches the "user deleted the .md externally, graph still
    # has the entity + triples" case.
    slug_lower = slug.lower()
    phantom_paths: set[str] = set()
    if knowledge_graph is not None:
        try:
            for triple in getattr(knowledge_graph, "_triples", []):
                if triple.get("status") != "active":
                    continue
                for src in triple.get("source_files") or []:
                    src_norm = str(src).replace("\\", "/")
                    if "/wiki/" not in src_norm:
                        continue
                    stem = Path(src_norm).stem.lower()
                    derived = re.sub(r"[^a-z0-9]+", "-", stem).strip("-")
                    if derived == slug_lower and src_norm not in deleted_logical:
                        phantom_paths.add(src_norm)
        except Exception:
            log.exception("Failed scanning graph for phantom traces of %s", slug)

    # 4) Scrub `_index.md` references in every KB we touched (real or phantom).
    paths_for_scrub = list(deleted_logical) + sorted(phantom_paths)
    seen_kbs: set[str] = set()
    vault_writer = getattr(request.app.state, "vault_writer", None)
    for rel in paths_for_scrub:
        kb_slug_val = _extract_kb_slug(rel)
        if not kb_slug_val or kb_slug_val in seen_kbs:
            continue
        seen_kbs.add(kb_slug_val)
        idx_rel = f"knowledge/{kb_slug_val}/wiki/_index.md"
        try:
            doc = vault.read(idx_rel)
            new_lines = [
                line for line in doc.raw.split("\n")
                if f"[[{slug}]]" not in line and f"[{slug}]" not in line
            ]
            if vault_writer:
                vault_writer.write(
                    idx_rel,
                    "\n".join(new_lines),
                    trust_reason="wiki_delete_index_scrub",
                )
        except Exception:
            # _index.md may not exist for some KBs — that's fine.
            pass

    # 5) Retract triples whose only source was a deleted/phantom file. Idempotent;
    # `_retract_file_contributions` is the same primitive the incremental graph
    # build uses for delete-deltas.
    retracted = 0
    if knowledge_graph is not None and (deleted_logical or phantom_paths):
        try:
            for path in [*deleted_logical, *phantom_paths]:
                retracted += knowledge_graph._retract_file_contributions(path)
            if retracted:
                knowledge_graph.save()
        except Exception:
            log.exception("Failed to retract graph triples for %s", slug)

    # 6) Detect cache-only phantom: the article cache (TTL 60s) may still
    # list the slug even though no file or graph trace remains. The user's
    # browser is showing it; honour the delete by clearing the cache.
    cache_phantom = False
    try:
        cached = list(_article_cache.get("articles") or [])
        cache_phantom = any(a.get("slug") == slug for a in cached)
    except Exception:
        cache_phantom = False

    # 7) Always invalidate the article cache so the next read rebuilds.
    invalidate_article_cache()

    if deleted:
        return {
            "deleted": True,
            "slug": slug,
            "files": deleted,
            "phantom": False,
            "phantom_paths": sorted(phantom_paths),
            "broken_backlinks": [{"article": bl["slug"], "kb": bl["kb"]} for bl in broken_backlinks],
            "graph_triples_retracted": retracted,
        }

    if phantom_paths or retracted or cache_phantom:
        # Article file was already gone but graph/index/cache still referenced
        # it. Idempotent cleanup succeeded — return 200 so the UI clears it
        # rather than showing a misleading 404 for something the user can see.
        return {
            "deleted": True,
            "slug": slug,
            "files": [],
            "phantom": True,
            "phantom_paths": sorted(phantom_paths),
            "cache_phantom": cache_phantom,
            "broken_backlinks": [{"article": bl["slug"], "kb": bl["kb"]} for bl in broken_backlinks],
            "graph_triples_retracted": retracted,
        }

    raise HTTPException(status_code=404, detail=f"Article not found: {slug}")


@router.get("/article/{slug}/history")
async def article_history(request: Request, slug: str) -> dict:
    """List version history for a wiki article."""
    vault = request.app.state.vault
    writer = getattr(request.app.state, "vault_writer", None)
    if not writer:
        return {"versions": [], "slug": slug}

    # Find the article file across all KBs
    try:
        files = vault.list_files("knowledge", f"**/wiki/**/{slug}.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")
                 and "/.history/" not in str(f).replace("\\", "/")]
    except Exception:
        files = []

    if not files:
        # Fallback: search by frontmatter slug (display-name files)
        kb_svc = getattr(request.app.state, "kb_service", None)
        found = kb_svc._find_article_by_slug(slug) if kb_svc else None
        if found:
            files = [found[2]]  # filepath

    if not files:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    # Get relative path
    relative = _to_logical(vault, files[0])
    versions = writer.list_versions(relative)

    return {"slug": slug, "path": relative, "versions": versions}


@router.get("/article/{slug}/version/{version}")
async def article_version(request: Request, slug: str, version: str) -> dict:
    """Read a specific version of a wiki article."""
    vault = request.app.state.vault
    writer = getattr(request.app.state, "vault_writer", None)
    if not writer:
        raise HTTPException(status_code=404, detail="No writer available")

    try:
        files = vault.list_files("knowledge", f"**/wiki/**/{slug}.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")
                 and "/.history/" not in str(f).replace("\\", "/")]
    except Exception:
        files = []

    if not files:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    relative = _to_logical(vault, files[0])
    content = writer.read_version(relative, version)

    if content is None:
        raise HTTPException(status_code=404, detail=f"Version not found: {version}")

    return {"slug": slug, "version": version, "content": content}


@router.post("/reclassify")
async def reclassify_all(request: Request) -> dict:
    """Re-run taxonomy classification on all articles. Call after taxonomy changes."""
    kb_service = request.app.state.kb_service
    return kb_service.reclassify_articles()


@router.post("/reclassify/{kb_slug}")
async def reclassify_kb(request: Request, kb_slug: str) -> dict:
    """Re-run taxonomy classification on a specific KB's articles."""
    kb_service = request.app.state.kb_service
    return kb_service.reclassify_articles(kb_slug)


@router.delete("/reset")
async def reset_all_wikis(request: Request) -> dict:
    """Reset ALL wiki articles across all KBs. Keeps library/inbox sources intact."""
    kb_service = request.app.state.kb_service
    return kb_service.reset_all_wikis()


@router.delete("/reset/{kb_slug}")
async def reset_kb_wiki(request: Request, kb_slug: str) -> dict:
    """Reset all wiki articles for a specific KB. Keeps library/inbox sources intact."""
    kb_service = request.app.state.kb_service
    return kb_service.reset_wiki(kb_slug)




@router.delete("/stale")
async def delete_all_stale(request: Request) -> dict:
    """Delete all stale articles at once."""
    stale = await list_stale_articles(request)
    vault = request.app.state.vault
    deleted = []
    for article in stale:
        try:
            full = vault._resolve(article["path"])
            if full.exists():
                full.unlink()
                deleted.append(article["slug"])
        except Exception:
            continue
    return {"deleted": deleted, "count": len(deleted)}


@router.get("/file/{file_path:path}")
@router.get("/image/{file_path:path}")
async def serve_file(request: Request, file_path: str):
    """Serve a file from the vault (images, documents, any source file)."""
    from fastapi.responses import FileResponse

    vault = request.app.state.vault
    full_path = vault._resolve(file_path)

    if not full_path.exists() or not full_path.is_file():
        raise HTTPException(status_code=404, detail=f"Image not found: {file_path}")

    # Security: ensure path is within vault (check all content roots + internals)
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    root_dir = vault.paths.root_dir if (hasattr(vault, "paths") and vault.paths) else vault_dir
    try:
        full_path.resolve().relative_to(root_dir.resolve())
    except ValueError as e:
        raise HTTPException(status_code=403, detail="Access denied") from e

    return FileResponse(str(full_path))


@router.post("/open-file")
async def open_local_file(request: Request) -> dict:
    """Open a local file with the OS default handler (like double-clicking it).

    This is a local-only app — this endpoint only works on the host machine.
    """
    import subprocess
    import sys

    try:
        body = await request.json()
    except Exception:
        raw = await request.body()
        import json as _json
        body = _json.loads(raw.decode("utf-8", errors="replace"))
    file_path = body.get("path", "")

    if not file_path:
        raise HTTPException(status_code=400, detail="No path provided")

    # Decode any URL-encoded characters (spaces, unicode, etc.)
    from urllib.parse import unquote
    file_path = unquote(file_path)

    from pathlib import Path as P
    path = P(file_path)
    # Resolve vault-relative logical paths (e.g., "knowledge/general/library/...")
    # through VaultPaths so short-form prefixes map to the real physical layout.
    if not path.is_absolute() and hasattr(request.app.state, "vault"):
        path = request.app.state.vault._resolve(file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")

    try:
        import shutil

        method = "default"

        # 1. If the file is inside an Obsidian vault, jump straight there.
        #    Works on Windows (os.startfile), macOS (open) and Linux (xdg-open)
        #    because all three honour the obsidian:// URI scheme registered
        #    by the Obsidian desktop app.
        if _try_open_obsidian(path):
            return {"opened": True, "path": file_path, "method": "obsidian"}

        # 2. Platform-native open
        if sys.platform == "win32":
            import os
            import winreg

            ext = path.suffix.lower()
            has_association = False
            try:
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, ext) as key:
                    val = winreg.QueryValueEx(key, "")[0]
                    has_association = bool(val)
            except OSError:
                pass

            if has_association:
                os.startfile(str(path))  # type: ignore[attr-defined]
                method = "os"
            else:
                code = shutil.which("code")
                if code:
                    subprocess.Popen([code, str(path)])
                    method = "vscode"
                else:
                    subprocess.Popen(["notepad.exe", str(path)])
                    method = "notepad"
        elif sys.platform == "darwin":
            # macOS: `open` honours LaunchServices for .md and every other
            # registered extension, so the user's preferred editor is used.
            subprocess.Popen(["open", str(path)])
            method = "os"
        else:
            # Linux: xdg-open is the standard. Fall back to a known editor
            # if xdg-utils is not installed (slim containers, minimal WMs).
            opener = shutil.which("xdg-open")
            if opener:
                subprocess.Popen([opener, str(path)])
                method = "os"
            else:
                editor = shutil.which("code") or shutil.which("gedit") or shutil.which("nano")
                if not editor:
                    raise HTTPException(
                        status_code=500,
                        detail="No file opener available. Install xdg-utils or set $EDITOR.",
                    )
                subprocess.Popen([editor, str(path)])
                method = Path(editor).name
        return {"opened": True, "path": file_path, "method": method}
    except Exception as e:
        log.exception("Failed to open file: %s", file_path)
        raise HTTPException(status_code=500, detail=f"Failed to open: {e}") from e


def _kb_relative_path(file_path: Path, vault) -> str:
    """Get vault-relative path for a KB file."""
    if hasattr(vault, "paths") and vault.paths:
        return vault.paths.to_logical(file_path)
    vault_dir = vault.vault_dir
    try:
        return str(file_path.relative_to(vault_dir)).replace("\\", "/")
    except ValueError:
        # Absolute path not under vault_dir — use as-is
        return str(file_path).replace("\\", "/")


def _extract_kb_slug(path: str) -> str:
    """Extract KB slug from a path like 'knowledge/ai-safety/wiki/article.md'."""
    parts = path.replace("\\", "/").split("/")
    try:
        kb_idx = parts.index("knowledge")
        return parts[kb_idx + 1]
    except (ValueError, IndexError):
        return ""


def _resolve_vault_source(request: Request, meta: dict, kb_slug: str) -> str:
    """Resolve the original vault path for an article.

    Priority:
    1. Article's own vault_source frontmatter
    2. Compile state sources dict (fast lookup)
    3. Source summary page's vault_source frontmatter (fallback for pre-tracking data)
    """
    direct = meta.get("vault_source", "")
    if direct:
        return direct

    source_files = meta.get("sources", [])
    if not source_files or not kb_slug:
        return ""

    try:
        kb_service = request.app.state.kb_service
        vault = request.app.state.vault

        # Try compile state first
        state = kb_service._read_compile_state(kb_slug)
        sources = state.get("sources", {})
        for fname in source_files:
            if fname in sources:
                vs = sources[fname].get("vault_source", "")
                if vs:
                    return vs

        # Fallback: read the source summary page's frontmatter
        for fname in source_files:
            slug = fname.lower().replace(" ", "-").replace(".md", "")
            source_path = f"knowledge/{kb_slug}/wiki/sources/{slug}.md"
            if vault.exists(source_path):
                try:
                    doc = vault.read(source_path)
                    vs = doc.metadata.get("vault_source", "")
                    if vs:
                        return vs
                except Exception:
                    pass
    except Exception:
        pass

    return ""


def _resolve_source_paths(request: Request, source_files: list[str], kb_slug: str) -> dict[str, str]:
    """Resolve each source filename to its vault path (absolute on disk).

    Returns a dict mapping source filename → absolute file path.
    Sources live in the KB library folder; we also check compile state for vault_source.
    """
    if not source_files or not kb_slug:
        return {}

    result: dict[str, str] = {}
    try:
        vault = request.app.state.vault
        kb_service = request.app.state.kb_service

        # Load compile state once for all sources
        state = kb_service._read_compile_state(kb_slug)
        sources_state = state.get("sources", {})

        for fname in source_files:
            # 1. Check compile state for vault_source (original file outside vault)
            if fname in sources_state:
                vs = sources_state[fname].get("vault_source", "")
                if vs and Path(vs).is_file():
                    result[fname] = vs
                    continue

            # 2. Try to find in KB library folder
            try:
                found = vault.list_files(f"knowledge/{kb_slug}/library", f"**/{fname}")
                if found:
                    result[fname] = str(found[0])
                    continue
            except Exception:
                pass

            # 3. Try inbox
            try:
                found = vault.list_files(f"knowledge/{kb_slug}/inbox", f"**/{fname}")
                if found:
                    result[fname] = str(found[0])
            except Exception:
                pass
    except Exception:
        pass

    return result


def _list_wiki_files(vault) -> list[Path]:
    """List all wiki article .md files across all KBs.

    Filters out:
      * Files whose name starts with ``_`` or ``.`` (``_index.md``,
        ``.gitkeep``, ``.hidden.md``).
      * Any file whose path contains a dot-prefixed segment (``.history/``,
        ``.archives/``, ``.pytest_cache/``, ``.git/``, ``.venv/``,
        ``.obsidian/`` etc.). The dot-prefix convention for hidden / system
        directories is universal across Unix, Git, Python, Node, and editor
        toolchains — a generic rule is mechanically safer than chasing
        each new dot-dir one at a time. Mirrors the same predicate used in
        ``can_open_in_obsidian`` above and ``automation/fs_events.py``.
    """
    try:
        files = vault.list_files("knowledge", "**/wiki/**/*.md")
    except Exception:
        log.exception("Failed to list wiki files")
        return []

    def _ok(f: Path) -> bool:
        if f.name.startswith(("_", ".")):
            return False
        norm = str(f).replace("\\", "/")
        return not any(part.startswith(".") for part in norm.split("/") if part)

    return [f for f in files if _ok(f)]


def _read_article_safe(vault, file_path: Path) -> tuple[str, dict, str] | None:
    """Read a wiki article, returning (rel_path, metadata, content) or None on error."""
    try:
        rel = _kb_relative_path(file_path, vault)
        doc = vault.read(rel)
        return rel, doc.metadata, doc.content
    except Exception as e:
        log.debug("Skipped article with bad frontmatter: %s (%s)", file_path.name, e.__class__.__name__)
        return None


# ── Gap 1: Curate — draft review queue + verify flow ──


@router.get("/drafts")
async def list_drafts(request: Request) -> list[dict]:
    """List all draft articles needing human review (status != verified)."""
    articles = await asyncio.to_thread(_get_cached_articles, request.app.state.vault)
    drafts = []
    for a in articles:
        status = a.get("status", "draft")
        if status not in ("verified", "active"):
            drafts.append({
                "slug": a.get("slug", ""),
                "title": a.get("title", ""),
                "path": a.get("path", ""),
                "entity_type": a.get("entity_type", ""),
                "status": status,
                "kb": a.get("kb", ""),
                "date_created": a.get("date_created", a.get("date", "")),
                "author": a.get("author", ""),
                "agent": a.get("agent", ""),
            })
    return drafts


@router.post("/article/{slug}/verify")
async def verify_article(request: Request, slug: str) -> dict:
    """Mark a draft article as verified (human-reviewed)."""
    vault = request.app.state.vault
    writer = request.app.state.vault_writer

    # Find the article
    articles = await asyncio.to_thread(_get_cached_articles, vault)
    match = next((a for a in articles if a.get("slug") == slug), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    path = match["path"]
    doc = vault.read(path)
    raw = doc.raw

    # Update status in frontmatter
    if "status:" in raw:
        import re as _re
        updated = _re.sub(r"status:\s*\S+", "status: verified", raw, count=1)
    else:
        # Add status to frontmatter
        updated = raw.replace("---\n", "---\nstatus: verified\n", 1)

    writer.write(path, updated)
    invalidate_article_cache()
    return {"slug": slug, "status": "verified"}


@router.post("/article/{slug}/reject")
async def reject_article(request: Request, slug: str, reason: str = "") -> dict:
    """Mark a draft article as rejected (needs rework or deletion)."""
    vault = request.app.state.vault
    writer = request.app.state.vault_writer

    articles = await asyncio.to_thread(_get_cached_articles, vault)
    match = next((a for a in articles if a.get("slug") == slug), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    path = match["path"]
    doc = vault.read(path)
    raw = doc.raw

    import re as _re
    if "status:" in raw:
        updated = _re.sub(r"status:\s*\S+", "status: rejected", raw, count=1)
    else:
        updated = raw.replace("---\n", "---\nstatus: rejected\n", 1)

    if reason:
        updated += f"\n\n> **Rejected**: {reason}\n"

    writer.write(path, updated)
    invalidate_article_cache()
    return {"slug": slug, "status": "rejected", "reason": reason}


# ── Phase 8 (2026-04-30) — wiki feedback queue ─────────────────────
# Per-article structured feedback. User flags an article wrong with a
# kind + severity + note; agent reads the note on next regeneration via
# the LLM prompt. Coexists with existing verify/reject (sledgehammer
# status flips) AND VaultEditWatcher's manual-edit detection — three
# correction paths, none replaces the others.


class _FeedbackSubmitBody(BaseModel):
    """POST body for ``/api/wiki/article/{slug}/feedback``."""

    kind: str = "other"
    severity: str = "medium"
    note: str = ""
    kb: str = ""


@router.post("/article/{slug}/feedback")
async def submit_article_feedback(
    request: Request, slug: str, body: _FeedbackSubmitBody,
) -> dict:
    """Submit user feedback on a wiki article.

    The feedback is read into the LLM prompt the next time
    ``compile_wiki(slug)``, ``synthesize``, or ``research_kb`` regenerates
    this article — so the agent's regeneration ADDRESSES the user's note
    instead of producing the same wrong content.

    Validates ``kind`` and ``severity`` against closed enums (raises 422
    on invalid values via Pydantic) — see SKILL.md for the valid set.
    """
    svc = getattr(request.app.state, "wiki_feedback", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Wiki feedback service not initialized")

    # Verify the article exists (the slug must resolve to a real wiki
    # article — feedback on phantom slugs would be agent-noise).
    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)
    match = next((a for a in articles if a.get("slug") == slug), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    kb = body.kb or str(match.get("kb") or "")
    try:
        row = await svc.submit(
            slug,
            kind=body.kind,
            severity=body.severity,
            note=body.note,
            kb=kb,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"feedback": row.to_dict()}


@router.get("/article/{slug}/feedback")
async def list_article_feedback(
    request: Request, slug: str, status: str = "open",
) -> dict:
    """List feedback rows for an article. Default ``status=open``;
    pass ``status=all`` to include resolved + dismissed.

    Rule 20 shape: ``{items, total, has_more}`` — the open queue is
    bounded by domain (a single article is unlikely to accumulate many
    open items in practice) so ``has_more`` always False here, but the
    shape stays consistent with the rest of the wiki API."""
    svc = getattr(request.app.state, "wiki_feedback", None)
    if svc is None:
        return {"items": [], "total": 0, "has_more": False, "available": False}

    status_filter = None if status == "all" else status
    if status_filter is not None and status_filter not in ("open", "resolved", "dismissed"):
        raise HTTPException(
            status_code=422,
            detail="status must be one of: open / resolved / dismissed / all",
        )

    rows = await svc.list_for_article(slug, status_filter=status_filter)  # type: ignore[arg-type]
    items = [r.to_dict() for r in rows]
    return {
        "items": items,
        "total": len(items),
        "has_more": False,
        "available": True,
    }


@router.get("/feedback/open")
async def list_all_open_feedback(request: Request, limit: int = 100) -> dict:
    """Cross-article view of open feedback. Sorted by severity desc.

    Drives the ``/feedback`` browse page (future) + the fact-checker daily
    pass (which prioritizes open feedback as verification targets).
    """
    svc = getattr(request.app.state, "wiki_feedback", None)
    if svc is None:
        return {"items": [], "total": 0, "has_more": False, "available": False}

    rows = await svc.list_open(limit=max(1, min(500, int(limit))))
    items = [r.to_dict() for r in rows]
    total = await svc.count_open_total()
    return {
        "items": items,
        "total": total,
        "has_more": total > len(items),
        "available": True,
    }


class _FeedbackResolveBody(BaseModel):
    """POST body for ``/api/wiki/feedback/{id}/resolve``."""

    new_status: str = "resolved"  # or "dismissed"
    resolved_by: str = "user"


@router.post("/feedback/{feedback_id}/resolve")
async def resolve_feedback(
    request: Request, feedback_id: int, body: _FeedbackResolveBody | None = None,
) -> dict:
    """Close a feedback row.

    ``new_status``: ``resolved`` (default — agent fixed it OR user
    re-reviewed and is satisfied) or ``dismissed`` (user re-reviewed and
    decided their original feedback was wrong / out of scope).
    """
    svc = getattr(request.app.state, "wiki_feedback", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Wiki feedback service not initialized")

    body_obj = body or _FeedbackResolveBody()
    try:
        ok = await svc.resolve(
            feedback_id,
            new_status=body_obj.new_status,
            resolved_by=body_obj.resolved_by,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    if not ok:
        # Either the row doesn't exist OR it's already non-open.
        # Caller can distinguish via a follow-up GET; route stays simple.
        raise HTTPException(
            status_code=404,
            detail=f"Feedback {feedback_id} not found or already closed",
        )
    return {"resolved": True, "id": feedback_id, "status": body_obj.new_status}


# ── Gap 2: Export — wiki article export ──


@router.get("/export")
async def export_wiki(request: Request, kb: str = "", format: str = "markdown") -> dict:
    """Export wiki articles as downloadable archive.

    Formats: markdown (default), json
    Optional kb filter.
    """

    vault = request.app.state.vault
    articles = await asyncio.to_thread(_get_cached_articles, vault)

    if kb:
        articles = [a for a in articles if a.get("kb") == kb]

    if format == "json":
        export = []
        for a in articles:
            try:
                doc = vault.read(a["path"])
                export.append({
                    "slug": a.get("slug", ""),
                    "title": a.get("title", ""),
                    "entity_type": a.get("entity_type", ""),
                    "status": a.get("status", "draft"),
                    "kb": a.get("kb", ""),
                    "metadata": doc.metadata,
                    "content": doc.content,
                })
            except Exception:
                continue
        return {"format": "json", "count": len(export), "articles": export}

    # Markdown format — return file list with content
    export = []
    for a in articles:
        try:
            doc = vault.read(a["path"])
            export.append({
                "path": a["path"],
                "title": a.get("title", ""),
                "raw": doc.raw,  # Full markdown with frontmatter
            })
        except Exception:
            continue
    return {"format": "markdown", "count": len(export), "articles": export}


# ── Gap 3: Wiki Health Metrics ──


@router.get("/health")
async def wiki_health(request: Request) -> dict:
    """Aggregate wiki health score and metrics across all KBs.

    Health score (0.0-1.0) based on:
    - Article quality (source coverage, TODO density, link density)
    - Freshness (recency of updates)
    - Structural integrity (orphans, broken links)
    - Source-to-article ratio
    """
    vault = request.app.state.vault
    kb_service = request.app.state.kb_service

    articles = await asyncio.to_thread(_get_cached_articles, vault)
    kbs = kb_service.list_kbs()

    total_articles = len(articles)
    total_sources = sum(kb.get("sources", 0) for kb in kbs)

    if total_articles == 0:
        return {
            "score": 0.0, "status": "empty",
            "metrics": {}, "issues": ["No articles in wiki"],
        }

    # Metrics collection
    draft_count = 0
    verified_count = 0
    rejected_count = 0
    stale_count = 0
    todo_articles = 0
    orphan_count = 0
    total_links = 0
    total_todos = 0
    source_summary_count = 0
    days_since_update: list[float] = []

    now = datetime.now(UTC)
    for a in articles:
        status = a.get("status", "draft")
        if status == "draft":
            draft_count += 1
        elif status == "verified":
            verified_count += 1
        elif status == "rejected":
            rejected_count += 1
        elif status == "stale":
            stale_count += 1

        etype = a.get("entity_type", "")
        if etype == "source_summary":
            source_summary_count += 1
            continue  # Don't count source summaries in quality metrics

        # Read content for quality checks
        try:
            doc = vault.read(a["path"])
            content = doc.content

            # TODO density
            todos = content.count("[TODO:")
            total_todos += todos
            if todos > 0:
                todo_articles += 1

            # Link density
            import re as _re
            links = len(_re.findall(r"\[\[.+?\]\]", content))
            total_links += links
            if links == 0:
                orphan_count += 1

            # Freshness
            date_str = doc.metadata.get("date_updated", doc.metadata.get("date_created", doc.metadata.get("date", "")))
            if date_str:
                try:
                    from datetime import datetime as _dt
                    d = _dt.strptime(str(date_str)[:10], "%Y-%m-%d")
                    days_since_update.append((now - d).days)
                except (ValueError, TypeError):
                    pass
        except Exception:
            continue

    # Content articles (excluding source summaries)
    content_articles = total_articles - source_summary_count

    # Calculate health score components (0-1 each)
    # 1. Verification coverage: what % are verified?
    verification_score = verified_count / max(content_articles, 1)

    # 2. TODO density: lower is better (0 TODOs = 1.0)
    todo_ratio = todo_articles / max(content_articles, 1)
    todo_score = max(0.0, 1.0 - todo_ratio)

    # 3. Link density: articles should have cross-references
    orphan_ratio = orphan_count / max(content_articles, 1)
    link_score = max(0.0, 1.0 - orphan_ratio)

    # 4. Freshness: median days since update (< 30 days = 1.0, > 365 = 0.0)
    if days_since_update:
        import statistics
        median_age = statistics.median(days_since_update)
        freshness_score = max(0.0, min(1.0, 1.0 - (median_age - 30) / 335))
    else:
        freshness_score = 0.5

    # 5. Source coverage: source-to-article ratio (>= 1.0 means well-sourced)
    source_ratio = total_sources / max(content_articles, 1)
    source_score = min(1.0, source_ratio)

    # 6. Staleness: stale articles drag down health
    stale_ratio = stale_count / max(content_articles, 1)
    stale_score = max(0.0, 1.0 - stale_ratio * 5)  # 20% stale = 0.0

    # Weighted aggregate
    score = (
        verification_score * 0.15
        + todo_score * 0.15
        + link_score * 0.20
        + freshness_score * 0.20
        + source_score * 0.15
        + stale_score * 0.15
    )

    status = "healthy" if score >= 0.7 else "degraded" if score >= 0.4 else "critical"

    # Build issues list
    issues: list[str] = []
    if draft_count > content_articles * 0.5:
        issues.append(f"{draft_count} articles still in draft (review needed)")
    if todo_articles > content_articles * 0.3:
        issues.append(f"{todo_articles} articles have [TODO:] gaps")
    if orphan_count > content_articles * 0.2:
        issues.append(f"{orphan_count} articles have no cross-references (orphans)")
    if stale_count > 0:
        issues.append(f"{stale_count} articles marked stale (source deleted)")
    if rejected_count > 0:
        issues.append(f"{rejected_count} articles rejected (need rework or deletion)")
    if total_sources == 0:
        issues.append("No sources ingested yet")

    return {
        "score": round(score, 3),
        "status": status,
        "metrics": {
            "total_articles": total_articles,
            "content_articles": content_articles,
            "source_summaries": source_summary_count,
            "total_sources": total_sources,
            "draft": draft_count,
            "verified": verified_count,
            "rejected": rejected_count,
            "stale": stale_count,
            "todo_articles": todo_articles,
            "total_todos": total_todos,
            "orphan_articles": orphan_count,
            "total_links": total_links,
            "avg_links_per_article": round(total_links / max(content_articles, 1), 1),
            "source_to_article_ratio": round(source_ratio, 2),
            "median_age_days": round(statistics.median(days_since_update), 0) if days_since_update else None,
            "verification_pct": round(verification_score * 100, 1),
        },
        "component_scores": {
            "verification": round(verification_score, 3),
            "completeness": round(todo_score, 3),
            "cross_references": round(link_score, 3),
            "freshness": round(freshness_score, 3),
            "source_coverage": round(source_score, 3),
            "staleness": round(stale_score, 3),
        },
        "issues": issues,
    }
