"""POST /api/clip — receive web clips from the AgntSpace web-clipper browser
extension and write them into ``agntspace-inbox/clip-<timestamp>.md``.

Captured payload (all optional except url):
    url:         the page URL (required)
    title:       the page title
    note:        user-supplied annotation
    selection:   the text the user had selected when clipping
    content:     the readable body extracted in-page (markdown-ish)
    captured_at: ISO-8601 timestamp from the extension

Output frontmatter:
    title, source_url, clipped_at, clipper, note

The file lands in the global vault inbox; the inbox watcher picks it up
within ~30s and routes it through the standard ingest pipeline → main
KB by default.

Stage E4 (v3.5 — 2026-04-27 night).
"""
from __future__ import annotations

import logging
import re
from datetime import UTC, datetime

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)

router = APIRouter(prefix="/clip", tags=["web-clipper"])


# Regex pulled out of the request body so a malicious page can't smuggle
# YAML frontmatter into the file via title/note injection.
_FRONTMATTER_BREAK_RE = re.compile(r"^[\s]*---[\s]*$", re.MULTILINE)


class ClipRequest(BaseModel):
    url: str = Field(..., min_length=1, max_length=4096)
    title: str = Field("", max_length=512)
    note: str = Field("", max_length=4096)
    selection: str = Field("", max_length=20_000)
    content: str = Field("", max_length=200_000)
    captured_at: str = Field("", max_length=64)


def _safe_yaml_string(value: str) -> str:
    """Render a value as a YAML double-quoted string, escaping ``"`` and
    ``\\``. Newlines collapse to single spaces (frontmatter strings stay
    on one line).

    Web-clipper input is untrusted — a hostile page could craft a title
    like ``"\\n---\\nexec: rm -rf"`` to break out of the frontmatter
    block. This locks the value to a quoted form regardless of content.
    """
    if not value:
        return '""'
    cleaned = value.replace("\\", "\\\\").replace('"', '\\"')
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return f'"{cleaned}"'


def _strip_frontmatter_breaks(text: str) -> str:
    """Defang any inline ``---`` lines in clipped content so they can't
    accidentally close the file's frontmatter block.

    Replaces standalone ``---`` lines with ``— —`` (em-dashes) — visually
    similar but unambiguous to the YAML parser. Conservative: only
    matches lines that are EXACTLY ``---`` (with optional whitespace).
    """
    return _FRONTMATTER_BREAK_RE.sub("— —", text)


def _format_clip(body: ClipRequest) -> tuple[str, str]:
    """Return ``(filename, file_content)`` for a clip.

    Filename: ``clip-<YYYYmmdd-HHMMSS>.md`` in UTC. Stable, sortable,
    timezone-agnostic.
    """
    now_utc = datetime.now(UTC)
    timestamp_compact = now_utc.strftime("%Y%m%d-%H%M%S")
    filename = f"clip-{timestamp_compact}.md"

    # Frontmatter — every field gets the safe-yaml-string treatment.
    title = body.title or _hostname_fallback(body.url)
    captured = body.captured_at.strip() or now_utc.isoformat().replace("+00:00", "Z")

    fm_lines = [
        "---",
        f"title: {_safe_yaml_string(title)}",
        f"source_url: {body.url}",
        f"clipped_at: {captured}",
        "clipper: web-extension",
    ]
    if body.note:
        fm_lines.append(f"note: {_safe_yaml_string(body.note)}")
    fm_lines.append("---")
    fm_lines.append("")

    # Body — note first (user's intent for saving), then full content,
    # then selection block. Each section is a clearly-labeled markdown
    # heading so downstream parsers / users can navigate.
    body_parts: list[str] = []
    if body.note:
        body_parts.append(_strip_frontmatter_breaks(body.note))
        body_parts.append("")
    if body.content:
        body_parts.append(_strip_frontmatter_breaks(body.content))
        body_parts.append("")
    if body.selection:
        body_parts.append("## Selection")
        body_parts.append("")
        body_parts.append(
            "> "
            + _strip_frontmatter_breaks(body.selection).replace("\n", "\n> ")
        )
        body_parts.append("")
    if not body_parts:
        # No content captured — the link itself is still useful.
        body_parts.append(f"_Saved {captured} from <{body.url}>._")
        body_parts.append("")

    return filename, "\n".join(fm_lines) + "\n".join(body_parts)


def _hostname_fallback(url: str) -> str:
    """Cheap title fallback when the page didn't supply one — uses the
    URL's hostname + path so the user can see where it came from in the
    inbox listing."""
    m = re.match(r"https?://([^/]+)(/[^?#]*)?", url)
    if not m:
        return url[:120]
    host = m.group(1)
    path = (m.group(2) or "").rstrip("/")
    return f"{host}{path}"[:120] or host


@router.post("")
async def clip(body: ClipRequest, request: Request) -> dict:
    """Receive a clip and write it to the vault inbox.

    Idempotent within a second resolution: re-posting the same clip
    inside one second produces a filename collision; we add a numeric
    suffix to keep both. Re-clipping after a second naturally produces
    a new file.
    """
    # Resolve the inbox path via VaultPaths so this works whether vault
    # is at ``~/Vault1`` or any user-chosen location.
    writer = getattr(request.app.state, "vault_writer", None)
    reader = getattr(request.app.state, "vault_reader", None)
    if writer is None or reader is None:
        raise HTTPException(status_code=503, detail="Vault not configured")

    filename, content = _format_clip(body)

    # Collision-safe — append numeric suffix if a same-second clip lands.
    target_path = f"inbox/{filename}"
    if reader.exists(target_path):
        suffix = 1
        while True:
            stem = filename[:-3]  # strip .md
            alt = f"inbox/{stem}-{suffix}.md"
            if not reader.exists(alt):
                target_path = alt
                break
            suffix += 1
            if suffix > 100:
                # Pathological — bail out rather than spin forever.
                raise HTTPException(
                    status_code=409,
                    detail="Inbox collision suffix exhausted",
                )

    try:
        writer.write(
            target_path, content, trust_reason="web_clipper",
        )
    except Exception as exc:  # noqa: BLE001
        log.exception("clip write failed: %s", exc)
        raise HTTPException(
            status_code=500, detail=f"Failed to save clip: {exc}",
        ) from exc

    # Activity event for Rule #13 — agent sees that a user clipped a
    # page in its world model.
    try:
        activity = getattr(request.app.state, "activity_logger", None)
        if activity is not None:
            await activity.log(
                category="user",
                action="web_clipped",
                summary=f"Clipped: {body.title or _hostname_fallback(body.url)}",
                details={
                    "url": body.url,
                    "path": target_path,
                    "note_length": len(body.note),
                    "content_length": len(body.content),
                    "selection_length": len(body.selection),
                },
                importance="low",
            )
    except Exception:  # noqa: BLE001
        pass  # never break the clip path on a broken activity logger

    return {
        "ok": True,
        "path": target_path,
        "filename": target_path.split("/")[-1],
    }
