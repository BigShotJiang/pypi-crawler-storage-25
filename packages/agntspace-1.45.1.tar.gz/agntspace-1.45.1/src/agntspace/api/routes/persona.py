"""Persona switching for the main agent — Option A (2026-05-06).

Endpoints:

  GET    /api/persona            — current active + list of available variants
  GET    /api/persona/{name}     — body of the named variant (preview)
  POST   /api/persona/switch     — body: {"name": "<variant>"} — switch active
  POST   /api/persona/reset      — clear active_personality (back to base)

All endpoints are user-initiated; activity middleware classifies the two
mutating routes as ``user`` / ``persona_switched`` / ``persona_reset``. The
SOUL.md write goes through VaultWriter with ``trust_reason="persona_switch"``
so the runtime guard accepts it without a contract gate.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from agntspace.agent.persona import PersonaError, PersonaService

router = APIRouter(prefix="/persona", tags=["persona"])


def _get_service(request: Request) -> PersonaService:
    svc = getattr(request.app.state, "persona", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="persona service not wired")
    return svc


class _SwitchBody(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)


@router.get("")
async def persona_state(request: Request) -> dict:
    """Return the current active variant + the list of declared variants.

    Shape: ``{active: str, available: [str], base_in_effect: bool}``.
    ``base_in_effect`` is True iff no variant is active.
    """
    svc = _get_service(request)
    state = svc.state()
    return {
        "active": state.active,
        "available": state.available,
        "base_in_effect": not state.active,
    }


@router.get("/{name}")
async def persona_preview(request: Request, name: str) -> dict:
    """Preview a variant's body without switching to it.

    Returns 404 if the variant doesn't exist. Empty body case (variant
    declared with no content) returns ``{name, body: ""}``.
    """
    svc = _get_service(request)
    body = svc.get_variant_body(name)
    if body is None:
        raise HTTPException(status_code=404, detail=f"persona variant '{name}' not found")
    return {"name": name, "body": body}


@router.post("/switch")
async def persona_switch(request: Request, body: _SwitchBody) -> dict:
    """Set ``active_personality: <name>`` in SOUL.md frontmatter.

    422 on empty / missing body (Pydantic). 400 on unknown variant.
    503 if SOUL.md is missing or PersonaService isn't wired.
    """
    svc = _get_service(request)
    try:
        state = svc.switch(body.name)
    except PersonaError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="SOUL.md not found in vault") from exc
    return {
        "switched": True,
        "active": state.active,
        "available": state.available,
        "message": f"Active personality is now '{state.active}'. The change takes effect on the next chat turn (SOUL.md mtime watcher rebuilds the prompt).",
    }


@router.post("/reset")
async def persona_reset(request: Request) -> dict:
    """Clear ``active_personality`` from SOUL.md frontmatter — fall back to base."""
    svc = _get_service(request)
    try:
        state = svc.reset()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="SOUL.md not found in vault") from exc
    return {
        "reset": True,
        "active": state.active,
        "available": state.available,
        "message": "Reverted to base personality (SOUL.md `## Personality` section). The change takes effect on the next chat turn.",
    }
