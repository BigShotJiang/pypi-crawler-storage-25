"""News watcher API — configure and tick per-KB news watchers.

Routes:
  GET    /api/kb/{slug}/news-watch          — current config (raw + effective)
  PUT    /api/kb/{slug}/news-watch          — overwrite config; re-registers cron
  POST   /api/kb/{slug}/news-watch/tick     — fire one tick now (manual)
  GET    /api/news-watch/overview           — all configured watchers (read-only)

Per-KB config lives in `knowledge/{slug}/SCHEMA.md` frontmatter under
`news_watch:`. The PUT endpoint rewrites that YAML field while
preserving the body of SCHEMA.md (description, focus questions,
agent notes, etc.).

Contract: PUT + tick are gated by `news_watch` (default: allow).
GET + overview are read-only and bypass the contract layer.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(tags=["news-watch"])


# ── Schema ────────────────────────────────────────────────────────────────


class NewsTopicConfig(BaseModel):
    name: str
    enabled: bool = True
    query_variants: list[str] = []
    cadence_cron: str = ""
    max_search_results: int = 0
    max_reviewed_per_tick: int = 0
    relevance_threshold: float | None = None
    search_time_window: str | None = None
    max_age_days: int = 0
    require_publish_date: bool | None = None


class NewsWatchConfig(BaseModel):
    enabled: bool = True
    topics: list[NewsTopicConfig] = []


# ── Helpers ────────────────────────────────────────────────────────────────


def _topic_to_dict(t: NewsTopicConfig) -> dict[str, Any]:
    """Strip empty / None fields so SCHEMA.md stays clean."""
    out: dict[str, Any] = {"name": t.name, "enabled": t.enabled}
    if t.query_variants:
        out["query_variants"] = t.query_variants
    if t.cadence_cron:
        out["cadence_cron"] = t.cadence_cron
    if t.max_search_results:
        out["max_search_results"] = t.max_search_results
    if t.max_reviewed_per_tick:
        out["max_reviewed_per_tick"] = t.max_reviewed_per_tick
    if t.relevance_threshold is not None:
        out["relevance_threshold"] = t.relevance_threshold
    if t.search_time_window:
        out["search_time_window"] = t.search_time_window
    if t.max_age_days:
        out["max_age_days"] = t.max_age_days
    if t.require_publish_date is not None:
        out["require_publish_date"] = t.require_publish_date
    return out


def _write_news_watch_to_schema(
    vault_writer: Any,
    vault_reader: Any,
    slug: str,
    config: dict[str, Any],
) -> None:
    """Write `news_watch:` into SCHEMA.md frontmatter.

    Reads the existing SCHEMA, replaces or inserts the news_watch field
    in the YAML frontmatter, preserves the body. If SCHEMA.md doesn't
    exist, creates a minimal one.
    """
    rel_path = f"knowledge/{slug}/SCHEMA.md"
    body = ""
    metadata: dict[str, Any] = {}
    if vault_reader.exists(rel_path):
        try:
            doc = vault_reader.read(rel_path)
            metadata = dict(getattr(doc, "metadata", None) or {})
            body = getattr(doc, "content", "") or ""
        except Exception:
            log.debug("news-watch: SCHEMA read failed for %s", slug, exc_info=True)
            body = ""
            metadata = {}
    if config:
        metadata["news_watch"] = config
    else:
        metadata.pop("news_watch", None)
    # Write through the vault writer with a trust_reason so the runtime
    # guard accepts the write. This is contract-authorized at the route
    # entry by `news_watch` (the activity middleware records the action).
    vault_writer.write(
        rel_path,
        body,
        metadata=metadata,
        trust_reason="news_watch_config",
    )


# ── Routes ─────────────────────────────────────────────────────────────────


@router.get("/kb/{slug}/news-watch")
async def get_news_watch(request: Request, slug: str) -> dict[str, Any]:
    """Read the current news_watch config for a KB."""
    vault = request.app.state.vault
    rel_path = f"knowledge/{slug}/SCHEMA.md"
    if not vault.exists(rel_path):
        # KB exists but no SCHEMA.md yet — return empty config.
        return {"slug": slug, "config": {"enabled": False, "topics": []}, "exists": False}
    try:
        doc = vault.read(rel_path)
        meta = dict(getattr(doc, "metadata", None) or {})
    except Exception:
        log.debug("news-watch GET: SCHEMA read failed for %s", slug, exc_info=True)
        meta = {}
    raw = meta.get("news_watch") or {}
    if not isinstance(raw, dict):
        raw = {}
    return {"slug": slug, "config": raw, "exists": True}


# workflow:trivial — SCHEMA.md config write + cron re-registration. The user-facing news-watch workflow chain (config → cron tick → article ingest → wiki) is exercised by the news_watcher engine tests in tests/unit/automation/test_news_watcher.py.
@router.put("/kb/{slug}/news-watch")
async def put_news_watch(
    request: Request,
    slug: str,
    body: NewsWatchConfig,
) -> dict[str, Any]:
    """Overwrite the news_watch config; re-register cron jobs.

    Validates the structure, writes to SCHEMA.md, then asks the engine
    to rescan + re-register so the new topics take effect immediately
    (without a server restart). Idempotent on repeated calls.
    """
    vault = request.app.state.vault
    writer = request.app.state.vault_writer

    # Verify KB exists
    kb_root = f"knowledge/{slug}"
    if not (vault.paths.resolve(kb_root)).is_dir():
        raise HTTPException(status_code=404, detail=f"KB '{slug}' not found")

    # Build the YAML-shaped dict (strip empties).
    cfg: dict[str, Any] = {"enabled": body.enabled}
    cfg["topics"] = [_topic_to_dict(t) for t in body.topics]

    try:
        _write_news_watch_to_schema(writer, vault, slug, cfg)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to write SCHEMA: {e}") from e

    # Re-discover topics across all KBs so cron lines up with new config.
    summary: dict[str, Any] = {"reregistered": False}
    engine = getattr(request.app.state, "news_watcher", None)
    if engine is not None:
        try:
            summary = await engine.discover_and_register()
            summary["reregistered"] = True
        except Exception:
            log.exception("news-watch: rediscover failed after PUT %s", slug)

    return {"slug": slug, "config": cfg, "summary": summary}


# workflow:trivial — manual trigger for the same tick path the cron uses. The full chain (tick → news_watcher engine → ingest → wiki) is locked by the engine unit tests in tests/unit/automation/test_news_watcher.py.
@router.post("/kb/{slug}/news-watch/tick")
async def tick_news_watch(
    request: Request,
    slug: str,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Manually fire one news watch tick for a (KB, topic) pair.

    Body: ``{"topic": "<topic name>"}`` — required. The topic must
    already exist + be enabled in the KB's SCHEMA news_watch block.
    """
    engine = getattr(request.app.state, "news_watcher", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="news watcher engine not wired")
    body = body or {}
    topic = (body.get("topic") or "").strip()
    if not topic:
        raise HTTPException(status_code=400, detail="missing 'topic' in request body")
    result = await engine.tick(slug, topic)
    return {
        "slug": slug,
        "topic": topic,
        "started_at": result.started_at,
        "finished_at": result.finished_at,
        "success": result.success,
        "error": result.error,
        "skipped_reason": result.skipped_reason,
        "query_used": result.query_used,
        "searched": result.searched,
        "filtered_in": result.filtered_in,
        "cooldown_hits": result.cooldown_hits,
        "scraped": result.scraped,
        "skipped_quality": result.skipped_quality,
        "skipped_relevance": result.skipped_relevance,
        "skipped_age": result.skipped_age,
        "reviewed": result.reviewed,
        "kept": result.kept,
        "rejected": result.rejected,
        "review_errors": result.review_errors,
        "keepers": result.keepers,
    }


@router.get("/news-watch/overview")
async def news_watch_overview(request: Request) -> dict[str, Any]:
    """List every configured news watcher across all KBs.

    Read-only. Used by the Settings → News Watcher overview page so
    the user can see all watchers in one place without browsing each
    KB's SCHEMA.
    """
    from agntspace.automation.news_watcher import (
        load_global_config,
        load_kb_news_block,
        resolve_topics,
    )

    skill_loader = getattr(request.app.state, "skills", None) or getattr(
        request.app.state, "skill_loader", None
    )
    vault = getattr(request.app.state, "vault", None)
    if vault is None:
        raise HTTPException(status_code=503, detail="vault not wired")

    global_cfg = load_global_config(skill_loader)
    items: list[dict[str, Any]] = []

    try:
        knowledge_dir = vault.paths.resolve("knowledge")
    except Exception:
        knowledge_dir = None
    if knowledge_dir and knowledge_dir.is_dir():
        for child in sorted(knowledge_dir.iterdir()):
            if not child.is_dir() or child.name.startswith(".") or child.name.startswith("_"):
                continue
            kb_slug = child.name
            block = load_kb_news_block(vault, kb_slug)
            if not block:
                continue
            topics = resolve_topics(kb_slug, block, global_cfg)
            for t in topics:
                items.append({
                    "kb_slug": t.kb_slug,
                    "name": t.name,
                    "enabled": t.enabled,
                    "cadence_cron": t.cadence_cron,
                    "query_variants": t.query_variants,
                    "max_search_results": t.max_search_results,
                    "max_reviewed_per_tick": t.max_reviewed_per_tick,
                    "relevance_threshold": t.relevance_threshold,
                    "search_time_window": t.search_time_window,
                    "max_age_days": t.max_age_days,
                    "require_publish_date": t.require_publish_date,
                    "cron_job_name": t.cron_job_name,
                })

    return {
        "items": items,
        "total": len(items),
        "has_more": False,
        "global_enabled": bool(global_cfg.get("enabled", True)),
        # Full default surface so the UI can render "Default: X" hints next
        # to every override field. Single source of truth — UI does NOT
        # mirror these constants.
        "defaults": {
            "cadence_cron": global_cfg.get("default_cadence_cron"),
            "max_search_results": global_cfg.get("default_max_search_results"),
            "max_reviewed_per_tick": global_cfg.get("default_max_reviewed_per_tick"),
            "search_time_window": global_cfg.get("default_search_time_window"),
            "max_age_days": global_cfg.get("default_max_age_days"),
            "relevance_threshold": global_cfg.get("relevance_threshold"),
            "require_publish_date": global_cfg.get("require_publish_date"),
            "llm_tier": global_cfg.get("llm_tier"),
            "reviewer_agent": global_cfg.get("reviewer_agent"),
        },
        # Backward-compatible duplicates of the two old top-level keys.
        "default_cadence_cron": global_cfg.get("default_cadence_cron"),
        "default_relevance_threshold": global_cfg.get("relevance_threshold"),
    }
