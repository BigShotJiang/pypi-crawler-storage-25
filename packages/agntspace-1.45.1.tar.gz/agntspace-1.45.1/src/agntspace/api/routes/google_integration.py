"""HTTP routes for the Phase 5 Google Calendar + Contacts integration.

User flow:

1. POST /api/integrations/google/configure — paste client_id + client_secret
2. POST /api/integrations/google/oauth/start — returns auth URL + state
3. User opens URL, grants consent, Google redirects to /oauth/callback
4. GET /api/integrations/google/oauth/callback — exchange code for tokens
5. POST /api/integrations/google/sync — manual sync trigger (cron also fires daily)
6. GET /api/integrations/google/status — connection state, last sync stats
7. POST /api/integrations/google/disconnect — remove tokens

Plus the contact-proposal review queue:
- GET /api/contacts/pending
- GET /api/contacts/pending/{id}
- POST /api/contacts/pending/{id}/approve
- POST /api/contacts/pending/{id}/reject
"""

from __future__ import annotations

import logging
import time

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger(__name__)

router = APIRouter(tags=["google-integration"])

# In-memory CSRF state store. Single-user vault → no concurrency concerns.
# Maps state token → (created_at, redirect_target_for_ui).
_STATE_STORE: dict[str, tuple[float, str]] = {}
_STATE_TTL_SECONDS = 600  # 10 minutes


def _prune_state_store() -> None:
    now = time.time()
    expired = [s for s, (ts, _) in _STATE_STORE.items() if now - ts > _STATE_TTL_SECONDS]
    for s in expired:
        _STATE_STORE.pop(s, None)


def _get_oauth(request: Request):
    oauth = getattr(request.app.state, "google_oauth", None)
    if oauth is None:
        raise HTTPException(status_code=503, detail="Google OAuth not wired")
    return oauth


def _get_sync_engine(request: Request):
    engine = getattr(request.app.state, "google_sync_engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Google sync engine not wired")
    return engine


def _get_contact_proposer(request: Request):
    proposer = getattr(request.app.state, "contact_proposer", None)
    if proposer is None:
        raise HTTPException(status_code=503, detail="Contact proposer not wired")
    return proposer


# ── OAuth + sync ─────────────────────────────────────────────────────


# workflow:trivial — admin-only OAuth credential paste (client_id + client_secret). Pure store via the encrypted CredentialStore; the actual user-facing workflow is the OAuth consent flow which lives in /oauth/start + /oauth/callback.
@router.post("/integrations/google/configure")
async def configure_oauth_client(request: Request) -> dict:
    """Paste Google Cloud OAuth client_id + client_secret. Stored
    encrypted via the existing CredentialStore."""
    oauth = _get_oauth(request)
    body = await request.json()
    client_id = str(body.get("client_id", "")).strip()
    client_secret = str(body.get("client_secret", "")).strip()
    if not client_id or not client_secret:
        raise HTTPException(status_code=400, detail="client_id and client_secret required")
    try:
        oauth.configure_client(client_id, client_secret)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"configure failed: {exc}") from exc
    return {"status": "configured"}


# workflow:trivial — returns the consent URL string the user opens in the browser. The OAuth round-trip's user-visible state change happens at /oauth/callback (a GET — not subject to Rule 19); this POST is a pure URL synthesis, no state mutation beyond ephemeral state-token caching.
@router.post("/integrations/google/oauth/start")
async def oauth_start(request: Request) -> dict:
    """Return the Google consent URL the user opens in their browser."""
    oauth = _get_oauth(request)
    if not oauth.is_client_configured():
        raise HTTPException(
            status_code=400,
            detail="Google OAuth client not configured. POST /configure first.",
        )
    try:
        url, state = oauth.authorization_url()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"auth URL failed: {exc}") from exc
    _prune_state_store()
    _STATE_STORE[state] = (time.time(), "")
    return {"auth_url": url, "state": state}


@router.get("/integrations/google/oauth/callback")
async def oauth_callback(request: Request) -> dict:
    """Google calls back here with ``?code=...&state=...``. Exchange the
    code for tokens and persist to the encrypted store."""
    oauth = _get_oauth(request)
    code = request.query_params.get("code", "")
    state = request.query_params.get("state", "")
    error = request.query_params.get("error", "")

    if error:
        raise HTTPException(status_code=400, detail=f"OAuth error: {error}")
    if not code or not state:
        raise HTTPException(status_code=400, detail="missing code or state")

    _prune_state_store()
    if state not in _STATE_STORE:
        raise HTTPException(status_code=400, detail="unknown or expired state token")
    _STATE_STORE.pop(state, None)

    try:
        await oauth.exchange_code(code)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"token exchange failed: {exc}") from exc

    return {"status": "connected"}


@router.get("/integrations/google/status")
async def get_status(request: Request) -> dict:
    """Connection state + last-sync counters."""
    oauth = _get_oauth(request)
    return {
        "client_configured": oauth.is_client_configured(),
        "connected": oauth.is_connected(),
    }


# workflow:trivial — manual trigger for the same sync path the daily cron uses. The user-facing workflow chain (OAuth → sync → contact proposals → graph triples) is exercised by tests/unit/integrations/test_google_sync.py and tests/unit/integrations/test_contact_proposals.py covering the underlying engine + proposer.
@router.post("/integrations/google/sync")
async def manual_sync(request: Request) -> dict:
    """Manually trigger a calendar+contacts sync. The same path the
    daily cron uses. Returns aggregated counts."""
    engine = _get_sync_engine(request)
    return await engine.sync_all()


# workflow:trivial — token wipe via the encrypted CredentialStore. Idempotent. No user-facing workflow chain beyond the deletion itself.
@router.post("/integrations/google/disconnect")
async def disconnect(request: Request) -> dict:
    """Remove stored tokens. Client credentials remain so a re-connect
    doesn't require re-pasting them."""
    oauth = _get_oauth(request)
    oauth.disconnect()
    return {"status": "disconnected"}


# ── Contact proposal queue ───────────────────────────────────────────


@router.get("/contacts/pending")
async def list_pending_contacts(request: Request, limit: int = 100) -> dict:
    """Newest-first list of contacts awaiting user approval."""
    proposer = _get_contact_proposer(request)
    items = proposer.list_pending(limit=max(1, min(int(limit), 500)))
    return {
        "items": items,
        "total": len(items),
        "has_more": len(items) >= limit,
    }


@router.get("/contacts/pending/{proposal_id}")
async def get_pending_contact(request: Request, proposal_id: str) -> dict:
    proposer = _get_contact_proposer(request)
    item = proposer.get(proposal_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Proposal not found")
    return item


@router.post("/contacts/pending/{proposal_id}/approve")
async def approve_pending_contact(request: Request, proposal_id: str) -> dict:
    """Register the contact as a `person` entity in the registry."""
    proposer = _get_contact_proposer(request)
    result = proposer.approve(proposal_id)
    if result.get("status") == "not_found":
        raise HTTPException(status_code=404, detail="Proposal not found")
    if result.get("status") in {"no_graph", "no_registry"}:
        raise HTTPException(status_code=503, detail=f"Approval not available: {result.get('status')}")
    if result.get("status") == "invalid":
        raise HTTPException(status_code=400, detail=f"Invalid proposal: {result.get('reason')}")
    return result


@router.post("/contacts/pending/{proposal_id}/reject")
async def reject_pending_contact(request: Request, proposal_id: str) -> dict:
    """Discard the proposal AND drop a marker so future syncs don't
    re-propose the same contact."""
    proposer = _get_contact_proposer(request)
    body: dict = {}
    try:
        body = await request.json()
    except Exception:
        body = {}
    reason = str(body.get("reason", ""))[:500]
    result = proposer.reject(proposal_id, reason=reason)
    if result.get("status") == "not_found":
        raise HTTPException(status_code=404, detail="Proposal not found")
    return result
