"""System-load surface — the small honest signal under the logo.

``GET /api/system/busy`` is the lightweight endpoint the UI's
``<SystemLoadIndicator>`` polls every 5 seconds. Returns one of four levels
(calm / working / busy / overloaded) plus a list of what's actually
running, so the user gets ambient feedback the system is alive and doing
work — instead of staring at a slow UI assuming it's broken.

**Architectural rule** (from ``tasks/plan-architecture-restructure.md``):
this endpoint must NEVER walk the filesystem. Reads only from in-memory
state objects (work_queue counts, orchestrator active dispatches,
decision-logger health, watcher status). Cached 2 seconds so high-frequency
polling from multiple browser tabs is cheap. If this endpoint is slow,
the indicator that's supposed to show "system is busy" becomes the very
thing making it busy.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import APIRouter, Request

log = logging.getLogger(__name__)
router = APIRouter()


# ── Pure-function level classifier (testable, no I/O) ──────────────


def classify_load_level(
    *,
    active_dispatches: int,
    queue_running_live: int,
    queue_running_orphan: int,
    queue_pending: int,
    recent_lock_errors: int,
    longest_op_seconds: float,
    decision_failure_rate: float,
) -> str:
    """Map raw signals to one of {calm, working, busy, overloaded}.

    Pure function. Engine-only — strategy lives here intentionally
    because the thresholds are deterministic UX-feel decisions, not
    user-tunable strategy. If a future maintainer wants to tweak them,
    edit the constants below.
    """
    # OVERLOADED: hard signals the system is stretched beyond healthy
    if recent_lock_errors >= 3:
        return "overloaded"
    if decision_failure_rate > 0.10:
        return "overloaded"
    if queue_running_orphan > 0 and queue_running_orphan >= 3:
        return "overloaded"
    if longest_op_seconds > 180:
        return "overloaded"

    # BUSY: noticeable concurrent load — user should expect latency
    total_active = active_dispatches + queue_running_live
    if total_active >= 4:
        return "busy"
    if longest_op_seconds > 30:
        return "busy"
    if queue_pending >= 10:
        return "busy"

    # WORKING: normal background activity — give it a few seconds
    if total_active >= 1 or queue_pending >= 1:
        return "working"

    # CALM: nothing happening
    return "calm"


# ── 2-second cache so polling is cheap ─────────────────────────────


_cache: dict[str, Any] = {"ts": 0.0, "payload": None}
_CACHE_TTL_SECONDS = 2.0


def _now_seconds() -> float:
    return time.time()


# ── Endpoint ───────────────────────────────────────────────────────


@router.get("/system/busy")
async def system_busy(request: Request) -> dict:
    """Live system-load snapshot. Cached 2 seconds.

    Returns:
        ``{level, summary, active_dispatches, queue, operations,
           decision_logger, recent_lock_errors, longest_op_seconds,
           generated_at}``

    Where:
        - ``level``: "calm" | "working" | "busy" | "overloaded"
        - ``summary``: one-line human-readable status
        - ``operations``: list of `{kind, target, elapsed_s}` for each
          active op so the tooltip can list them
    """
    # Cache check
    now = _now_seconds()
    cached = _cache.get("payload")
    if cached and (now - _cache["ts"]) < _CACHE_TTL_SECONDS:
        return cached  # type: ignore[return-value]

    state = request.app.state
    operations: list[dict[str, Any]] = []
    longest_op_seconds = 0.0

    # Active orchestrator dispatches (in-memory dict)
    active_dispatches: dict[str, Any] = {}
    try:
        orch = getattr(state, "orchestrator", None)
        if orch is not None:
            active_dispatches = orch.get_active_dispatches() or {}
    except Exception:
        log.debug("orchestrator.get_active_dispatches failed", exc_info=True)

    for key, info in active_dispatches.items():
        if not isinstance(info, dict):
            continue
        started_at = info.get("started_at")
        elapsed = 0.0
        if started_at:
            try:
                from datetime import UTC, datetime
                if isinstance(started_at, str):
                    parsed = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
                    if parsed.tzinfo is None:
                        parsed = parsed.replace(tzinfo=UTC)
                    elapsed = (datetime.now(UTC) - parsed).total_seconds()
            except Exception:
                elapsed = 0.0
        longest_op_seconds = max(longest_op_seconds, elapsed)
        operations.append({
            "kind": info.get("task_summary") or info.get("agent") or "dispatch",
            "agent": info.get("agent") or key,
            "target": info.get("target", ""),
            "elapsed_s": round(elapsed, 1),
        })

    # Work queue snapshot (in-memory aggregation, fast)
    queue_status: dict[str, Any] = {
        "pending": 0, "retrying": 0,
        "running_live": 0, "running_orphan": 0,
        "completed": 0, "dead_letter": 0,
    }
    try:
        wq = getattr(state, "work_queue", None)
        if wq is not None:
            wq_status = await wq.get_status()
            counts = wq_status.get("counts", {}) if isinstance(wq_status, dict) else {}
            for k in queue_status:
                queue_status[k] = int(counts.get(k, 0))
    except Exception:
        log.debug("work_queue.get_status failed", exc_info=True)

    # Decision logger health (lock errors, failure rate)
    decision_health: dict[str, Any] = {
        "attempts": 0, "failures": 0, "rate": 0.0,
        "last_error": "", "last_error_age_s": None,
    }
    recent_lock_errors = 0
    try:
        dec = getattr(state, "decisions", None)
        if dec is not None:
            h = dec.health()
            decision_health["attempts"] = int(h.get("record_attempts", 0))
            decision_health["failures"] = int(h.get("record_failures", 0))
            decision_health["rate"] = (
                decision_health["failures"] / max(1, decision_health["attempts"])
            )
            decision_health["last_error"] = str(h.get("last_error", ""))[:160]
            last_err_ts = h.get("last_error_ts", "")
            if last_err_ts:
                try:
                    from datetime import UTC, datetime
                    parsed = datetime.fromisoformat(last_err_ts.replace("Z", "+00:00"))
                    if parsed.tzinfo is None:
                        parsed = parsed.replace(tzinfo=UTC)
                    age_s = (datetime.now(UTC) - parsed).total_seconds()
                    decision_health["last_error_age_s"] = round(age_s, 0)
                    # Count as "recent" if within last 60 seconds
                    if age_s < 60 and "locked" in decision_health["last_error"].lower():
                        recent_lock_errors = 1
                except Exception:
                    pass
    except Exception:
        log.debug("decisions.health failed", exc_info=True)

    # Classify
    level = classify_load_level(
        active_dispatches=len(active_dispatches),
        queue_running_live=queue_status["running_live"],
        queue_running_orphan=queue_status["running_orphan"],
        queue_pending=queue_status["pending"] + queue_status["retrying"],
        recent_lock_errors=recent_lock_errors,
        longest_op_seconds=longest_op_seconds,
        decision_failure_rate=decision_health["rate"],
    )

    # Human summary — what to show in the tooltip top line
    if level == "calm":
        summary = "Idle"
    elif level == "working":
        bits = []
        if active_dispatches:
            bits.append(f"{len(active_dispatches)} agent(s) working")
        if queue_status["pending"] + queue_status["retrying"] > 0:
            bits.append(
                f"{queue_status['pending'] + queue_status['retrying']} job(s) queued",
            )
        summary = " · ".join(bits) if bits else "Background work in progress"
    elif level == "busy":
        if longest_op_seconds > 30:
            summary = f"Heavy operation in flight ({int(longest_op_seconds)}s)"
        else:
            summary = f"{len(active_dispatches) + queue_status['running_live']} ops running"
    else:  # overloaded
        if recent_lock_errors:
            summary = "Database contention detected"
        elif decision_health["rate"] > 0.10:
            summary = f"Elevated error rate ({decision_health['rate']:.0%})"
        elif queue_status["running_orphan"] >= 3:
            summary = f"{queue_status['running_orphan']} stuck workers"
        else:
            summary = "System under heavy load"

    payload = {
        "level": level,
        "summary": summary,
        "active_dispatches": len(active_dispatches),
        "queue": queue_status,
        "operations": operations,
        "decision_logger": decision_health,
        "recent_lock_errors": recent_lock_errors,
        "longest_op_seconds": round(longest_op_seconds, 1),
        "generated_at": now,
    }
    _cache["ts"] = now
    _cache["payload"] = payload
    return payload
