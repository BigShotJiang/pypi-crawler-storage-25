"""HTTP routes for the Phase 3 email-mention approval queue.

User reviews pending email-mention proposals at the unified `/proposals`
page (or directly via these endpoints). Approve emits ``references``
triples; reject discards. Both record activity events for Rule #13
awareness — the agent sees the user's decisions.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger(__name__)

router = APIRouter(prefix="/email", tags=["email-proposals"])


def _get_proposer(request: Request):
    proposer = getattr(request.app.state, "email_mention_proposer", None)
    if proposer is None:
        raise HTTPException(status_code=503, detail="Email mention proposer not wired")
    return proposer


@router.get("/pending-mentions")
async def list_pending_mentions(request: Request, limit: int = 100) -> dict:
    """Return all pending email-mention proposals (newest first).

    Returns ``{items, total, has_more}`` per Rule 20 — never a bare list.
    """
    proposer = _get_proposer(request)
    items = proposer.list_pending(limit=max(1, min(int(limit), 500)))
    return {
        "items": items,
        "total": len(items),
        "has_more": len(items) >= limit,
    }


@router.get("/pending-mentions/{proposal_id}")
async def get_pending_mention(request: Request, proposal_id: str) -> dict:
    proposer = _get_proposer(request)
    item = proposer.get(proposal_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Proposal not found")
    return item


@router.post("/pending-mentions/{proposal_id}/approve")
async def approve_pending_mention(request: Request, proposal_id: str) -> dict:
    """Emit ``references`` triples for every detected mention and remove
    the pending file. Returns ``{status, recorded}``."""
    proposer = _get_proposer(request)
    result = proposer.approve(proposal_id)
    if result.get("status") == "not_found":
        raise HTTPException(status_code=404, detail="Proposal not found")
    if result.get("status") in {"no_indexer", "no_registry"}:
        raise HTTPException(status_code=503, detail=f"Approval not available: {result.get('status')}")
    return result


@router.post("/pending-mentions/{proposal_id}/reject")
async def reject_pending_mention(request: Request, proposal_id: str) -> dict:
    """Discard the pending proposal — no triples emitted."""
    proposer = _get_proposer(request)
    body: dict = {}
    try:
        body = await request.json()
    except Exception:
        body = {}
    reason = str(body.get("reason", ""))[:500]
    result = proposer.reject(proposal_id, reason=reason)
    if result.get("status") == "not_found":
        raise HTTPException(status_code=404, detail="Proposal not found")
    return result
