"""Admin endpoints — observability layer configuration + health.

Surfaces the knobs that power the accountability layer so a user can
monitor and tune them without editing code. Meant for the /admin page:

    GET  /api/admin/overview       — one-shot snapshot: decisions health,
                                      rate-limit snapshot, retention config
    GET  /api/admin/rate-limits    — status of every configured rate-limit scope
    POST /api/admin/rate-limits/reset — clear tracked buckets for a scope
    GET  /api/admin/adoption       — maintainer-only adoption dashboard
                                      (proxies agntspace.com/api/admin-stats with
                                      the encrypted maintainer token; 404 if no
                                      token is configured locally)

These are read-mostly. Mutating rate-limit policies at runtime is
deliberately NOT supported — the policies live in code so a user can't
accidentally raise their own limit on a sensitive endpoint from the UI.
If you need a new policy, ship it in `rate_limit.get_limiter()`.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agntspace.infra.rate_limit import get_limiter

log = logging.getLogger(__name__)

# Service key under which the encrypted maintainer token lives in CredentialStore.
# Only the maintainer (you) sets this; absence means the local app silently hides
# the adoption card on /admin instead of revealing a hidden feature.
MAINTAINER_STATS_SERVICE = "maintainer_stats"
MAINTAINER_STATS_URL = "https://agntspace.com/api/admin-stats"

router = APIRouter(prefix="/admin", tags=["admin"])


class _ResetRequest(BaseModel):
    scope: str
    caller: str | None = None


class _MaintainerTokenRequest(BaseModel):
    """Body for ``POST /api/admin/maintainer-token``."""

    token: str
    url: str | None = None  # optional override of the upstream maintainer-stats URL


def _token_preview(token: str) -> str:
    """Render a non-revealing preview of a stored token.

    8+ chars  → ``abcd…wxyz``
    Shorter   → ``(short)``  — never leak raw value
    """
    t = token.strip()
    if len(t) >= 8:
        return f"{t[:4]}…{t[-4:]}"
    return "(short)"


@router.get("/overview")
async def admin_overview(request: Request) -> dict:
    """One-shot snapshot combining decision health + rate-limit state + retention."""
    decisions = getattr(request.app.state, "decisions", None)
    evolution = getattr(request.app.state, "evolution", None)
    limiter = get_limiter()

    health = decisions.health() if decisions is not None else {"status": "unavailable"}
    evolution_health = (
        evolution.health() if evolution is not None and hasattr(evolution, "health")
        else {"initialized": False, "status": "unavailable"}
    )

    rate_limits: list[dict] = []
    for scope in ("privacy_forget", "privacy_export", "decisions_prune"):
        rate_limits.append(limiter.snapshot(scope))

    return {
        "decision_health": health,
        "evolution_health": evolution_health,
        "rate_limits": rate_limits,
    }


@router.get("/rate-limits")
async def rate_limit_status(request: Request) -> dict:
    """Return the configured rate-limit policies + active bucket counts."""
    limiter = get_limiter()
    scopes = sorted(limiter._policies.keys())  # noqa: SLF001
    return {
        "scopes": [limiter.snapshot(s) for s in scopes],
    }


@router.post("/rate-limits/reset")
async def rate_limit_reset(request: Request, body: _ResetRequest) -> dict:
    """Clear tracked buckets for a scope (and optionally a single caller).

    Use case: the user got themselves locked out during a misconfigured
    script test and wants to reset without restarting the server.
    """
    limiter = get_limiter()
    limiter.reset(scope=body.scope, caller=body.caller)
    return {"ok": True, "scope": body.scope, "caller": body.caller or "all"}


@router.get("/adoption")
async def adoption_dashboard(request: Request) -> dict:
    """Maintainer-only adoption proxy.

    Reads the maintainer token from the encrypted CredentialStore under service
    key ``maintainer_stats``. If absent → 404 (silent absence; the React card
    just doesn't render). If present → proxies the call to
    ``https://agntspace.com/api/admin-stats`` with ``Authorization: Bearer``.

    The endpoint never persists any of the response — it is a thin pass-through
    so the maintainer's local /admin page can render the dashboard without
    embedding the token in the browser.
    """
    creds = getattr(request.app.state, "credential_store", None)
    if creds is None:
        # Credential store not wired (test environment, broken init) — silent 404
        raise HTTPException(status_code=404, detail="adoption_unavailable")

    record = creds.get(MAINTAINER_STATS_SERVICE)
    if not record or not isinstance(record, dict):
        raise HTTPException(status_code=404, detail="maintainer_token_not_set")

    token = record.get("token")
    if not isinstance(token, str) or not token.strip():
        raise HTTPException(status_code=404, detail="maintainer_token_not_set")

    # Allow override for self-hosted maintainer dashboards / testing
    upstream = record.get("url") if isinstance(record.get("url"), str) else None
    target_url = upstream or MAINTAINER_STATS_URL

    import httpx

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                target_url,
                headers={"Authorization": f"Bearer {token.strip()}"},
            )
    except httpx.HTTPError as err:
        log.warning("Adoption proxy upstream call failed: %s", err)
        raise HTTPException(status_code=502, detail="upstream_unreachable") from err

    if resp.status_code == 401:
        # Token rejected by upstream — surface honestly so the maintainer knows
        # to rotate. Don't 404 here (would hide the auth failure).
        raise HTTPException(status_code=401, detail="upstream_rejected_token")
    if resp.status_code == 503:
        raise HTTPException(status_code=503, detail="upstream_maintainer_token_not_configured")
    if resp.status_code != 200:
        raise HTTPException(
            status_code=502,
            detail=f"upstream_status_{resp.status_code}",
        )

    try:
        data = resp.json()
    except ValueError as err:
        raise HTTPException(status_code=502, detail="upstream_bad_json") from err

    if not isinstance(data, dict):
        raise HTTPException(status_code=502, detail="upstream_bad_shape")

    return data


# ─────────────────────────────────────────────────────────────────────────────
# Maintainer-token CRUD — feeds the /admin Adoption section's input form
#
# Three thin helpers around CredentialStore so the React Adoption card can
# configure the upstream-stats token from the UI instead of forcing a CLI
# round-trip. All three go through the encrypted store (Rule 7); none ever
# return the raw token in a response — only a redacted ``preview`` string.
# ─────────────────────────────────────────────────────────────────────────────


@router.get("/maintainer-token-status")
async def maintainer_token_status(request: Request) -> dict:
    """Report whether a maintainer token is configured locally.

    Never returns the raw token — only ``configured: bool`` plus a short
    preview the UI can show to confirm "yes, that's the value I set".
    """
    creds = getattr(request.app.state, "credential_store", None)
    if creds is None:
        return {"configured": False, "preview": "", "url": "", "reason": "credential_store_unavailable"}

    record = creds.get(MAINTAINER_STATS_SERVICE)
    if not record or not isinstance(record, dict):
        return {"configured": False, "preview": "", "url": ""}

    token = record.get("token")
    if not isinstance(token, str) or not token.strip():
        return {"configured": False, "preview": "", "url": ""}

    upstream = record.get("url") if isinstance(record.get("url"), str) else ""
    return {
        "configured": True,
        "preview": _token_preview(token),
        "url": upstream or "",
    }


# workflow:trivial — admin-only credential CRUD (POST sets, DELETE clears). Pure store/retrieve via the encrypted CredentialStore; no user-facing workflow chain.
@router.post("/maintainer-token")
async def maintainer_token_set(request: Request, body: _MaintainerTokenRequest) -> dict:
    """Persist the maintainer token via the encrypted CredentialStore.

    Rule 7: every long-lived secret routes through ``CredentialStore.set``,
    never through ``config.toml`` or any other plaintext surface.
    """
    creds = getattr(request.app.state, "credential_store", None)
    if creds is None:
        raise HTTPException(status_code=503, detail="credential_store_unavailable")

    token = body.token.strip()
    if not token:
        raise HTTPException(status_code=400, detail="token_empty")

    record: dict = {"token": token}
    if body.url and body.url.strip():
        record["url"] = body.url.strip()

    creds.set(MAINTAINER_STATS_SERVICE, record)
    return {
        "ok": True,
        "configured": True,
        "preview": _token_preview(token),
        "url": record.get("url", ""),
    }


# workflow:trivial — admin-only credential CRUD (DELETE clears). Pure store/retrieve via the encrypted CredentialStore; no user-facing workflow chain.
@router.delete("/maintainer-token")
async def maintainer_token_clear(request: Request) -> dict:
    """Remove the maintainer token. Idempotent — never raises on missing."""
    creds = getattr(request.app.state, "credential_store", None)
    if creds is None:
        raise HTTPException(status_code=503, detail="credential_store_unavailable")

    creds.delete(MAINTAINER_STATS_SERVICE)
    return {"ok": True, "configured": False}
