"""Unified proposal inbox — aggregates EVERY substrate's pending agent
proposals into ONE feed so the user has a single triage surface.

Implements **Rule 21**: every gap the agent observes becomes a
user-reviewable proposal. Without a unified inbox, proposals scatter
across 8+ different review pages (taxonomy / skills sync / skill drafts
/ memory dream-review / reflection / relationship / trust domains /
agent action plan), each requiring the user to know it exists.

This module READS from each substrate's existing review surface and
returns a uniform-shape ``Proposal`` dict per item. Approve / reject
remain on the per-substrate endpoints — the inbox is a discoverability
layer, not a duplicate write path.

**Uniform proposal shape** (``Proposal`` dict):

    {
        "id": "<substrate>:<inner_id>",
        "kind": "taxonomy" | "skill_draft" | "skill_sync" |
                "dream_belief" | "rejected_belief" | "reflection_pending" |
                "relationship_pending" | "trust_domain" | "memory_pending"
                | "agent_action_plan",
        "title": "Human-readable one-liner",
        "summary": "Longer description / rationale",
        "severity": "low" | "medium" | "high",
        "created_at": "<iso8601>",
        "approve_url": "POST /api/.../approve",
        "reject_url":  "POST /api/.../reject" | "",
        "deep_link":   "/wiki/taxonomy/proposals" (UI route to deep view),
        "payload": { ... substrate-specific raw object ... },
    }

The kinds field maps onto the Rule 21 capability table 1:1.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger(__name__)

router = APIRouter(prefix="/proposals", tags=["proposals"])


# ── Helper: each loader returns list[Proposal]. Failure of one loader
#    must NOT block the rest — Rule 17/21 substrate independence.


def _safe_iso(value: Any) -> str:
    if isinstance(value, str) and value:
        return value
    return ""


def _load_taxonomy_proposals(vault_dir: Path) -> list[dict[str, Any]]:
    """Pending taxonomy node proposals. ``taxonomy_proposals`` already
    persists these to disk so this is a cheap directory scan."""
    try:
        from agntspace.kb.taxonomy_proposals import list_pending
    except Exception:
        return []
    try:
        items = list_pending(vault_dir)
    except Exception:
        log.debug("taxonomy proposals load failed", exc_info=True)
        return []
    out: list[dict[str, Any]] = []
    for p in items:
        article_count = 0
        # Auto-detected proposals from the orphan detector carry their
        # article count in the rationale prefix; parse defensively.
        try:
            import re as _re
            m = _re.search(r"^(\d+) articles", p.rationale or "")
            if m:
                article_count = int(m.group(1))
        except Exception:
            pass
        title = (
            f"Add taxonomy node: {p.path}"
            + (f" ({article_count} articles)" if article_count else "")
        )
        severity = "high" if article_count >= 50 else (
            "medium" if article_count >= 5 else "low"
        )
        out.append({
            "id": f"taxonomy:{p.proposal_id}",
            "kind": "taxonomy",
            "title": title,
            "summary": (p.rationale or p.description or "")[:600],
            "severity": severity,
            "created_at": _safe_iso(p.created_at),
            "approve_url": f"/api/wiki/taxonomy/proposals/{p.proposal_id}/approve",
            "reject_url":  f"/api/wiki/taxonomy/proposals/{p.proposal_id}/reject",
            "deep_link":   "/wiki",
            "payload": p.to_dict(),
        })
    return out


def _load_skill_drafts(vault_dir: Path) -> list[dict[str, Any]]:
    """Pending skill drafts that the healer agent created. Lives at
    ``<vault>/agntspace/system/skills/pending/<slug>/SKILL.md``."""
    out: list[dict[str, Any]] = []
    pending_dir = vault_dir / "agntspace" / "system" / "skills" / "pending"
    if not pending_dir.is_dir():
        return out
    for skill_dir in sorted(pending_dir.iterdir()):
        if not skill_dir.is_dir():
            continue
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.is_file():
            continue
        try:
            text = skill_md.read_text(encoding="utf-8")
        except Exception:
            continue
        # Pull title from frontmatter (or fall back to dirname).
        title_match = ""
        for line in text.splitlines()[:30]:
            if line.startswith("title:"):
                title_match = line.split(":", 1)[1].strip().strip('"').strip("'")
                break
        try:
            mtime = datetime.fromtimestamp(
                skill_md.stat().st_mtime, UTC,
            ).isoformat()
        except Exception:
            mtime = ""
        out.append({
            "id": f"skill_draft:{skill_dir.name}",
            "kind": "skill_draft",
            "title": f"New skill draft: {title_match or skill_dir.name}",
            "summary": (
                "Healer agent drafted a new skill. Approve to promote "
                "from pending/ to active vault skills."
            ),
            "severity": "medium",
            "created_at": mtime,
            "approve_url": "/api/orchestrator/simulate/proposals/approve-skill",
            "reject_url":  "/api/orchestrator/simulate/proposals/reject-skill",
            "deep_link":   "/agents",
            "payload": {
                "slug": skill_dir.name,
                "title": title_match,
                "path": str(skill_md.relative_to(vault_dir)).replace("\\", "/"),
            },
        })
    return out


def _load_skill_sync_pending(vault_dir: Path) -> list[dict[str, Any]]:
    """Pending skill upgrade decisions from the hybrid defaults sync.
    Each entry is a per-file change waiting for accept/keep-mine."""
    out: list[dict[str, Any]] = []
    pending_path = (
        vault_dir / "agntspace" / "system" / "skills" / ".pending-upgrades.json"
    )
    if not pending_path.is_file():
        return out
    try:
        import json
        data = json.loads(pending_path.read_text(encoding="utf-8")) or {}
    except Exception:
        log.debug("skill-sync pending load failed", exc_info=True)
        return out
    if not isinstance(data, dict):
        return out
    for path, entry in data.items():
        if not isinstance(entry, dict):
            continue
        classification = entry.get("classification") or "behavior"
        vault_edited = bool(entry.get("vault_edited"))
        severity = "low" if classification == "additive" else "medium"
        if classification == "safety":
            severity = "high"
        out.append({
            "id": f"skill_sync:{path}",
            "kind": "skill_sync",
            "title": f"Skill upgrade pending: {path}",
            "summary": (
                f"Classification: {classification}"
                + (" — your local edits will be overwritten if accepted"
                   if vault_edited else "")
            ),
            "severity": severity,
            "created_at": entry.get("detected_at") or "",
            "approve_url": "/api/skills/sync/accept",
            "reject_url":  "/api/skills/sync/keep-mine",
            "deep_link":   "/skills/sync",
            "payload": {
                "path": path,
                "classification": classification,
                "vault_edited": vault_edited,
            },
        })
    return out


def _load_dream_review(graph) -> list[dict[str, Any]]:
    """High-importance auto-extracted memory beliefs awaiting user
    review. Reads from ``KnowledgeGraph.dream_review_queue()``."""
    if graph is None or not hasattr(graph, "dream_review_queue"):
        return []
    try:
        items = graph.dream_review_queue(min_effective_weight=0.5, limit=50)
    except Exception:
        log.debug("dream review queue load failed", exc_info=True)
        return []
    out: list[dict[str, Any]] = []
    for triple in items:
        if not isinstance(triple, dict):
            continue
        triple_id = triple.get("id")
        if triple_id is None:
            continue
        s = triple.get("subject_display") or triple.get("subject") or "?"
        p = triple.get("predicate") or "?"
        o = triple.get("object_display") or triple.get("object") or "?"
        weight = float(triple.get("effective_weight", 0.0))
        severity = "high" if weight >= 0.85 else "medium"
        out.append({
            "id": f"dream_belief:{triple_id}",
            "kind": "dream_belief",
            "title": f"New belief: {s} {p} {o}",
            "summary": (
                f"Effective weight: {weight:.2f}. Auto-extracted by the "
                f"dream consolidation phase. Approve to mark verified."
            ),
            "severity": severity,
            "created_at": triple.get("last_verified") or triple.get("source_date") or "",
            "approve_url": f"/api/memory/dream-review/{triple_id}/confirm",
            "reject_url":  f"/api/memory/dream-review/{triple_id}/reject",
            "deep_link":   "/memory",
            "payload": triple,
        })
    return out


def _load_rejected_beliefs(graph) -> list[dict[str, Any]]:
    """Beliefs the REM dream phase rejected — user can restore if they
    disagree with the rejection."""
    if graph is None or not hasattr(graph, "list_rejected_hypotheses"):
        return []
    try:
        items = graph.list_rejected_hypotheses(limit=20)
    except Exception:
        log.debug("rejected hypotheses load failed", exc_info=True)
        return []
    out: list[dict[str, Any]] = []
    for triple in items:
        if not isinstance(triple, dict):
            continue
        triple_id = triple.get("id")
        if triple_id is None:
            continue
        s = triple.get("subject_display") or triple.get("subject") or "?"
        p = triple.get("predicate") or "?"
        o = triple.get("object_display") or triple.get("object") or "?"
        reason = (triple.get("rejection_reason") or "")[:160]
        out.append({
            "id": f"rejected_belief:{triple_id}",
            "kind": "rejected_belief",
            "title": f"Rejected belief: {s} {p} {o}",
            "summary": f"Rejected because: {reason}" if reason else "Rejected by REM dream",
            "severity": "low",
            "created_at": triple.get("last_verified") or "",
            "approve_url": f"/api/memory/counterfactual/{triple_id}/restore",
            "reject_url":  "",
            "deep_link":   "/memory",
            "payload": triple,
        })
    return out


def _load_reflection_pending(vault_dir: Path) -> list[dict[str, Any]]:
    """Pending daily/weekly reflections awaiting user approval. Read
    from the same vault path the reflection routes use."""
    pending_path = vault_dir / "agntspace" / "memory" / "pending"
    if not pending_path.is_dir():
        return []
    out: list[dict[str, Any]] = []
    for f in sorted(pending_path.glob("daily-reflection*.md")) + \
             sorted(pending_path.glob("weekly-reflection*.md")):
        kind_label = "daily" if "daily" in f.name else "weekly"
        try:
            mtime = datetime.fromtimestamp(f.stat().st_mtime, UTC).isoformat()
        except Exception:
            mtime = ""
        out.append({
            "id": f"reflection_pending:{f.stem}",
            "kind": "reflection_pending",
            "title": f"{kind_label.title()} reflection awaiting approval",
            "summary": (
                f"The agent drafted a {kind_label} reflection from your "
                f"recent activity. Approve to move it to your journal."
            ),
            "severity": "medium",
            "created_at": mtime,
            "approve_url": "/api/reflection/pending/approve",
            "reject_url":  "/api/reflection/pending/reject",
            "deep_link":   "/journal",
            "payload": {
                "filename": f.name,
                "kind": kind_label,
            },
        })
    return out


def _load_relationship_pending(vault_dir: Path) -> list[dict[str, Any]]:
    """Pending RELATIONSHIP.md evolution proposal."""
    f = vault_dir / "agntspace" / "memory" / "pending" / "relationship-evolution.md"
    if not f.is_file():
        return []
    try:
        mtime = datetime.fromtimestamp(f.stat().st_mtime, UTC).isoformat()
    except Exception:
        mtime = ""
    return [{
        "id": "relationship_pending:evolution",
        "kind": "relationship_pending",
        "title": "Relationship insights awaiting approval",
        "summary": (
            "Weekly evolution drafted updates to RELATIONSHIP.md based "
            "on observed activity patterns. Review + approve to apply."
        ),
        "severity": "medium",
        "created_at": mtime,
        "approve_url": "/api/relationship/pending/approve",
        "reject_url":  "/api/relationship/pending/reject",
        "deep_link":   "/control/relationship",
        "payload": {"filename": f.name},
    }]


def _load_memory_pending(vault_dir: Path) -> list[dict[str, Any]]:
    """Pending memory consolidations awaiting approval. Read directly
    so this stays cheap (no DB hit)."""
    pending = vault_dir / "agntspace" / "memory" / "pending"
    if not pending.is_dir():
        return []
    out: list[dict[str, Any]] = []
    for f in sorted(pending.glob("memory_*.md")):
        try:
            mtime = datetime.fromtimestamp(f.stat().st_mtime, UTC).isoformat()
        except Exception:
            mtime = ""
        out.append({
            "id": f"memory_pending:{f.stem}",
            "kind": "memory_pending",
            "title": f"Memory consolidation: {f.stem.replace('memory_', '')}",
            "summary": (
                "Daily memory consolidation drafted from journal + chat. "
                "Approve to apply, reject to discard."
            ),
            "severity": "low",
            "created_at": mtime,
            "approve_url": "/api/memory/pending/approve",
            "reject_url":  "/api/memory/pending/reject",
            "deep_link":   "/memory",
            "payload": {"filename": f.name},
        })
    return out


def _load_capability_proposals(vault_dir: Path, kind: str) -> list[dict[str, Any]]:
    """Generic loader for capability-gap proposals (Rule 21 closure).

    Reads from ``capability_proposals.list_pending(vault_dir, kind)`` and
    maps each entry into the unified-inbox shape. The three sibling
    detectors (missing-tool / missing-agent / missing-contract-action)
    all share this loader — only the ``kind`` discriminator changes.
    """
    try:
        from agntspace.automation.capability_proposals import list_pending
    except Exception:
        return []
    try:
        items = list_pending(vault_dir, kind)
    except Exception:
        log.debug("capability proposals (%s) load failed", kind, exc_info=True)
        return []

    inbox_kind, deep_link, approve_path, reject_path = {
        "tool": (
            "missing_tool",
            "/proposals?kind=missing_tool",
            "/api/tools/proposals/{id}/approve",
            "/api/tools/proposals/{id}/reject",
        ),
        "agent": (
            "missing_agent",
            "/proposals?kind=missing_agent",
            "/api/agents/proposals/{id}/approve",
            "/api/agents/proposals/{id}/reject",
        ),
        "contract-action": (
            "missing_contract_action",
            "/proposals?kind=missing_contract_action",
            "/api/contract-actions/proposals/{id}/approve",
            "/api/contract-actions/proposals/{id}/reject",
        ),
        "skill-completeness": (
            "skill_completeness",
            "/proposals?kind=skill_completeness",
            "/api/skill-completeness/proposals/{id}/approve",
            "/api/skill-completeness/proposals/{id}/reject",
        ),
    }.get(
        kind,
        ("unknown", "/proposals", "", ""),
    )

    out: list[dict[str, Any]] = []
    for p in items:
        # Severity heuristic: how many call sites reference the missing
        # thing. The detectors stamp this in payload — fall back to 1.
        ref_count = 0
        if kind == "tool":
            ref_count = int(p.payload.get("granting_skill_count", 0) or 0)
        elif kind == "contract-action":
            ref_count = int(p.payload.get("using_count", 0) or 0)
        # agent kind has no count — orphans are 0/1 by definition.

        severity = "high" if ref_count >= 5 else (
            "medium" if ref_count >= 2 else "low"
        )
        # Agent orphans default to medium (silent runtime breakage).
        if kind == "agent":
            severity = "medium"
        # Skill-completeness severity tracks gap_count: 2 missing
        # surfaces (no triggers AND no tools_granted) is the worst-case
        # archer-presentation shape and ships as medium so the user
        # sees it prominently in the unified inbox.
        if kind == "skill-completeness":
            gap_count = int(p.payload.get("gap_count", 0) or 0)
            severity = "medium" if gap_count >= 2 else "low"

        approve_url = approve_path.replace("{id}", p.proposal_id)
        reject_url = reject_path.replace("{id}", p.proposal_id) if reject_path else ""

        out.append({
            "id": f"{inbox_kind}:{p.proposal_id}",
            "kind": inbox_kind,
            "title": p.title or f"{kind} proposal: {p.target}",
            "summary": (p.description or p.rationale or "")[:600],
            "severity": severity,
            "created_at": _safe_iso(p.created_at),
            "approve_url": approve_url,
            "reject_url": reject_url,
            "deep_link": deep_link,
            "payload": p.to_dict(),
        })
    return out


def _load_dispatch_failures(dispatch_state) -> list[dict[str, Any]]:  # type: ignore[no-untyped-def]
    """Phase 6 (2026-04-30) — Rule 21 closure for dispatch state machine.

    Surfaces dormant per-KB dispatch states as user-actionable proposals.
    A KB lands here when 3 consecutive zero-effects in active → escalating
    → 3 more zero-effects → dormant. The user must explicitly approve retry
    (resets state, gives the next dispatch a fresh chance) OR dismiss
    (sets a cooldown so the dormant row stops surfacing for N days).

    Escalating rows are NOT surfaced — they're the system's "trying harder"
    interim state, not yet user-actionable. Cooldown-active dormant rows
    are filtered out so dismissed proposals don't immediately re-appear.

    Defensive: ``dispatch_state`` service may be None (older deploy /
    minimal install). Returns [] without raising.
    """
    if dispatch_state is None:
        return []
    try:
        # Accessing the in-memory _fallback_rows OR running list_non_active_states
        # — both are async, but we're in a sync loader. Use the runtime asyncio
        # adapter. The aggregator's parent is async; we wrap in a coroutine
        # marker the caller will recognize. Simpler: read from the service's
        # ``_fallback_rows`` for synchronous access OR call sync method. The
        # service IS async, so we have to await — meaning this loader has to be
        # async too OR the aggregator must support async loaders.
        #
        # Pattern: the existing _load_capability_proposals etc. are sync and
        # read from filesystem. dispatch_state lives in SQLite. Use a
        # `run_until_complete`-style sync bridge OR refactor the aggregator
        # to support async. The cleanest answer is async loaders — but that's
        # an aggregator-wide change. Defer: read directly from the SQLite
        # connection that backs the service, sync.
        # The service uses aiosqlite over an in-memory or file-backed DB.
        # For Phase 6, we route through a public helper that returns a
        # snapshot without awaiting — added below.
        snapshot = getattr(dispatch_state, "snapshot_non_active", None)
        if not callable(snapshot):
            return []
        rows = snapshot() or []
    except Exception:
        log.debug("dispatch_failures loader failed", exc_info=True)
        return []

    out: list[dict[str, Any]] = []
    for row in rows:
        # Only surface DORMANT (give-up) rows. Escalating is the system
        # trying harder — not yet user-actionable.
        state = row.get("state") if isinstance(row, dict) else getattr(row, "state", "")
        if state != "dormant":
            continue

        # Skip rows under active cooldown (user dismissed).
        cooldown_active = (
            row.get("cooldown_active") if isinstance(row, dict)
            else (callable(getattr(row, "cooldown_active", None))
                  and row.cooldown_active())
        )
        if cooldown_active:
            continue

        slug = row.get("slug") if isinstance(row, dict) else getattr(row, "slug", "")
        scope = row.get("scope") if isinstance(row, dict) else getattr(row, "scope", "watcher_ingest")
        last_error = (
            row.get("last_error_preview") if isinstance(row, dict)
            else getattr(row, "last_error_preview", "")
        )
        last_change = (
            row.get("last_state_change_iso") if isinstance(row, dict)
            else getattr(row, "last_state_change_iso", "")
        )
        consecutive = int(
            row.get("consecutive_escalation_failures") if isinstance(row, dict)
            else getattr(row, "consecutive_escalation_failures", 0)
        )

        approve_url = f"/api/pipeline/dispatch-state/{slug}/reset?scope={scope}"
        reject_url = f"/api/pipeline/dispatch-state/{slug}/cooldown"

        out.append({
            "id": f"dispatch_failure:{slug}:{scope}",
            "kind": "dispatch_failure",
            "title": f"KB '{slug}' is stuck (dormant)",
            "summary": (
                f"After {consecutive} consecutive escalation failures, dispatch is paused for this KB. "
                f"Last error: {last_error or '(none captured)'}. "
                f"Approve retry to reset and try again, or dismiss to silence for {7} days."
            ),
            "severity": "high",  # dormant means the user MUST act
            "created_at": last_change or "",
            "approve_url": approve_url,
            "reject_url": reject_url,
            "deep_link": "/pipeline",
            "payload": {
                "slug": slug,
                "scope": scope,
                "state": state,
                "consecutive_escalation_failures": consecutive,
                "last_error_preview": last_error,
                "last_state_change_iso": last_change,
            },
        })
    return out


def _load_email_mention_proposals(vault_dir: Path) -> list[dict[str, Any]]:
    """Phase 3 second-brain — pending email-mention review proposals.

    Each pending file at ``<vault>/agntspace/memory/pending/email-mentions/<id>.json``
    is one email body whose Title-Case scan surfaced known entities.
    User reviews subject + sender + per-mention snippet; approve emits
    ``references`` triples, reject discards. Privacy-sensitive: email
    content NEVER auto-flows into the graph without explicit approval.
    """
    out: list[dict[str, Any]] = []
    pending_dir = vault_dir / "agntspace" / "memory" / "pending" / "email-mentions"
    if not pending_dir.is_dir():
        return out
    try:
        files = sorted(
            pending_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
    except Exception:
        return out
    import json as _json
    for f in files:
        try:
            data = _json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        pid = data.get("id") or ""
        if not pid:
            continue
        mentions = data.get("mentions") or []
        count = len(mentions) if isinstance(mentions, list) else 0
        subject = data.get("subject") or "(no subject)"
        sender = data.get("sender") or "(unknown sender)"
        # Severity follows mention count: 5+ entities is high (lots of
        # data flowing into the graph), 2+ medium, 1 low.
        severity = "high" if count >= 5 else ("medium" if count >= 2 else "low")
        title = (
            f"Email mentions: \"{subject[:80]}\""
            + (f" ({count} entit{'ies' if count != 1 else 'y'})" if count else "")
        )
        summary = f"From {sender}: {(data.get('body_preview') or '')[:240]}"
        out.append({
            "id": f"email_mentions:{pid}",
            "kind": "email_mentions",
            "title": title,
            "summary": summary,
            "severity": severity,
            "created_at": data.get("detected_at") or "",
            "approve_url": f"/api/email/pending-mentions/{pid}/approve",
            "reject_url":  f"/api/email/pending-mentions/{pid}/reject",
            "deep_link":   "/email",
            "payload": data,
        })
    return out


def _load_contact_proposals(vault_dir: Path) -> list[dict[str, Any]]:
    """Phase 5 second-brain — pending contact-approval proposals.

    Each pending file at ``<vault>/agntspace/memory/pending/contact-proposals/<id>.json``
    is one Google contact whose name didn't resolve to an existing
    entity. User reviews; approve registers the contact as a `person`
    entity; reject drops a marker so future syncs don't re-propose.
    """
    out: list[dict[str, Any]] = []
    pending_dir = vault_dir / "agntspace" / "memory" / "pending" / "contact-proposals"
    if not pending_dir.is_dir():
        return out
    try:
        files = sorted(
            (f for f in pending_dir.glob("*.json") if not f.name.startswith(".")),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
    except Exception:
        return out
    import json as _json
    for f in files:
        # Skip rejection markers (subdirectory) — only top-level pending files
        if f.parent.name != "contact-proposals":
            continue
        try:
            data = _json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        pid = data.get("id") or ""
        if not pid:
            continue
        display_name = data.get("display_name") or "(unknown)"
        emails = data.get("email_addresses") or []
        orgs = data.get("organizations") or []
        # Severity follows email count + org presence: contacts with
        # multiple emails or orgs are likely meaningful (someone you
        # actively interact with) — bumped to medium. Bare-name-only
        # contacts often look like address-book bloat — low severity.
        if len(emails) >= 2 or orgs:
            severity = "medium"
        else:
            severity = "low"
        title = f"New contact: {display_name}"
        if orgs:
            title += f" ({orgs[0]})"
        summary_parts: list[str] = []
        if emails:
            summary_parts.append(f"Emails: {', '.join(emails[:3])}")
        if orgs:
            summary_parts.append(f"Org: {orgs[0]}")
        if data.get("phone_numbers"):
            summary_parts.append(f"Phone: {data['phone_numbers'][0]}")
        summary = " · ".join(summary_parts) or "(no details)"
        out.append({
            "id": f"contact:{pid}",
            "kind": "contact",
            "title": title,
            "summary": summary,
            "severity": severity,
            "created_at": data.get("detected_at") or "",
            "approve_url": f"/api/contacts/pending/{pid}/approve",
            "reject_url":  f"/api/contacts/pending/{pid}/reject",
            "deep_link":   "/contacts",
            "payload": data,
        })
    return out


def _load_action_plan(vault_dir: Path) -> list[dict[str, Any]]:
    """Healer-generated agent fix proposals from the action plan."""
    plan_path = (
        vault_dir / "agntspace" / "system" / "logs" / "simulation" / "action-plan.json"
    )
    if not plan_path.is_file():
        return []
    try:
        import json
        data = json.loads(plan_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return []
    items = data.get("items") if isinstance(data, dict) else data
    if not isinstance(items, list):
        return []
    out: list[dict[str, Any]] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        if it.get("status") in ("verified", "rejected", "applied"):
            continue
        what = it.get("what") or it.get("title") or "Agent fix"
        out.append({
            "id": f"agent_action_plan:{it.get('id','')}",
            "kind": "agent_action_plan",
            "title": f"Agent fix: {what}",
            "summary": (it.get("why") or "") or "Agent health check found an issue",
            "severity": "medium",
            "created_at": it.get("created_at") or "",
            "approve_url": "/api/orchestrator/simulate/plan/heal",
            "reject_url":  "/api/orchestrator/simulate/plan/reject",
            "deep_link":   "/agents",
            "payload": it,
        })
    return out


# ── Aggregator route ────────────────────────────────────────────────


def _resolve_vault_root(vault) -> Path | None:
    """``app.state.vault.vault_dir`` returns the ``agntspace/`` SUBDIR
    (e.g. ``<root>/agntspace``), but the loaders below need the vault
    ROOT (e.g. ``<root>``). The root is the subdir's parent. Callers
    using the wiki taxonomy proposals route hit the same gotcha — so
    we centralize the resolution here.
    """
    vd = getattr(vault, "vault_dir", None)
    if vd is None:
        return None
    p = Path(vd)
    return p.parent if p.name == "agntspace" else p


@router.get("")  # GET /api/proposals
async def list_proposals(request: Request) -> dict[str, Any]:
    """Aggregate every substrate's pending proposals into one feed.

    Returns ``{items, total, by_kind, has_more}``. Each item carries a
    ``kind`` discriminator + per-substrate ``approve_url``/``reject_url``.
    The UI dispatches the action against those URLs.

    Rule 20: ``total`` is a true count, not ``len(items)`` after slicing.
    Rule 21: this is the unified inbox surface for all proposal types.
    """
    vault = getattr(request.app.state, "vault", None)
    vault_dir = _resolve_vault_root(vault)
    if vault_dir is None:
        return {"items": [], "total": 0, "by_kind": {}, "has_more": False}

    graph = getattr(request.app.state, "knowledge_graph", None)
    dispatch_state = getattr(request.app.state, "dispatch_state", None)

    items: list[dict[str, Any]] = []

    # Each loader is wrapped in try/except so a single broken substrate
    # doesn't blank the whole inbox.
    for loader_name, loader_call in [
        ("taxonomy", lambda: _load_taxonomy_proposals(vault_dir)),
        ("skill_drafts", lambda: _load_skill_drafts(vault_dir)),
        ("skill_sync", lambda: _load_skill_sync_pending(vault_dir)),
        ("dream_review", lambda: _load_dream_review(graph)),
        ("rejected_beliefs", lambda: _load_rejected_beliefs(graph)),
        ("reflection_pending", lambda: _load_reflection_pending(vault_dir)),
        ("relationship_pending", lambda: _load_relationship_pending(vault_dir)),
        ("memory_pending", lambda: _load_memory_pending(vault_dir)),
        ("action_plan", lambda: _load_action_plan(vault_dir)),
        # Rule 21 follow-throughs — capability-gap proposals
        ("missing_tool", lambda: _load_capability_proposals(vault_dir, "tool")),
        ("missing_agent", lambda: _load_capability_proposals(vault_dir, "agent")),
        ("missing_contract_action", lambda: _load_capability_proposals(vault_dir, "contract-action")),
        ("skill_completeness", lambda: _load_capability_proposals(vault_dir, "skill-completeness")),
        # Phase 3 second-brain — email mention approval queue (privacy gate)
        ("email_mentions", lambda: _load_email_mention_proposals(vault_dir)),
        # Phase 5 second-brain — Google Contacts approval queue (privacy gate)
        ("contact", lambda: _load_contact_proposals(vault_dir)),
        # Phase 6 (2026-04-30) — dispatch-failure proposals (Rule 21 closure
        # for the dispatch state machine). Dormant per-KB rows surface as
        # "KB stuck — approve retry or dismiss for cooldown" actions.
        ("dispatch_failure", lambda: _load_dispatch_failures(dispatch_state)),
    ]:
        try:
            results = loader_call() or []
            items.extend(results)
        except Exception as e:
            log.debug("proposals loader %s failed: %s", loader_name, e)

    # Sort newest-first; missing created_at sorts to the end.
    items.sort(key=lambda x: (x.get("created_at") or ""), reverse=True)

    # Group counts (always true counts, no slicing — Rule 20).
    by_kind: dict[str, int] = {}
    by_severity: dict[str, int] = {"high": 0, "medium": 0, "low": 0}
    for it in items:
        k = it.get("kind") or "unknown"
        by_kind[k] = by_kind.get(k, 0) + 1
        sev = it.get("severity") or "low"
        if sev in by_severity:
            by_severity[sev] += 1

    return {
        "items": items,
        "total": len(items),
        "by_kind": by_kind,
        "by_severity": by_severity,
        "has_more": False,  # bounded by domain — not paginated
    }


# ── Unified refresh-all (2026-04-29 noise-reduction follow-through) ──


# Detector attribute → capability-proposals kind. Taxonomy uses its own
# pending module (predates capability_proposals) and is handled out-of-band.
_CAPABILITY_DETECTORS: tuple[tuple[str, str], ...] = (
    ("missing_tool_detector", "tool"),
    ("missing_agent_detector", "agent"),
    ("missing_contract_action_detector", "contract-action"),
    ("skill_completeness_detector", "skill-completeness"),
)


@router.post("/refresh-all")
async def refresh_all_proposals(request: Request) -> dict[str, Any]:
    """Wipe stale capability-gap pendings + re-run every detector NOW.

    Useful after a noise-reduction config change (raising a threshold
    floor, extending an exemption list) — the YAML edit only affects
    NEW proposals, but the user wants the EXISTING pile cleared
    immediately, not after the next 24h heartbeat scan.

    Runs every wired detector in sequence:
      * taxonomy_orphan_detector (own pending dir)
      * missing_tool_detector / missing_agent_detector /
        missing_contract_action_detector / skill_completeness_detector
        (capability_proposals module)

    For each detector, clears every pending of its kind, then calls
    ``detect_and_propose()`` so the queue regenerates with current
    YAML thresholds.

    Body: none. Returns aggregate report::

        {
            "cleared_total": N,
            "written_total": M,
            "by_kind": {
                "tool":            {"cleared": .., "written": ..},
                "agent":           {"cleared": .., "written": ..},
                "contract-action": {"cleared": .., "written": ..},
                "skill-completeness": {"cleared": .., "written": ..},
                "taxonomy":        {"cleared": .., "written": ..},
            },
            "errors": [{"kind": "...", "error": "..."}],
        }

    Per-kind ``"cleared"`` counts proposals removed BEFORE re-detection.
    Per-kind ``"written"`` counts proposals emitted by the fresh run.
    Net change for the unified inbox is approximately ``written - cleared``;
    if the noise floor was raised, expect ``written << cleared``.
    """
    vault = getattr(request.app.state, "vault", None)
    vault_dir = _resolve_vault_root(vault)
    if vault_dir is None:
        raise HTTPException(503, detail="vault unavailable")

    state = request.app.state

    by_kind: dict[str, dict[str, Any]] = {}
    cleared_total = 0
    written_total = 0
    errors: list[dict[str, str]] = []

    # ── Capability-proposal detectors ─────────────────────────────────
    from agntspace.automation.capability_proposals import (
        list_pending as cap_list_pending,
    )
    from agntspace.automation.capability_proposals import (
        reject_proposal as cap_reject,
    )
    for attr, kind in _CAPABILITY_DETECTORS:
        detector = getattr(state, attr, None)
        if detector is None:
            errors.append({"kind": kind, "error": "detector_unavailable"})
            continue

        cleared = 0
        try:
            for p in cap_list_pending(vault_dir, kind):
                if cap_reject(vault_dir, kind, p.proposal_id):
                    cleared += 1
        except Exception as exc:
            errors.append({"kind": kind, "error": f"clear_failed: {exc}"})

        written = 0
        report: dict[str, Any] = {}
        try:
            report = await detector.detect_and_propose() or {}
            written = int(report.get("proposals_written") or 0)
        except Exception as exc:
            errors.append({"kind": kind, "error": f"detect_failed: {exc}"})

        # Strip the heavy "proposals" array from the per-kind summary
        # (full payloads are still on disk; the user reads them via
        # GET /api/proposals).
        slim_report = {k: v for k, v in report.items() if k != "proposals"}
        by_kind[kind] = {
            "cleared": cleared,
            "written": written,
            **slim_report,
        }
        cleared_total += cleared
        written_total += written

    # ── Taxonomy orphan detector (own pending module) ────────────────
    taxonomy = getattr(state, "taxonomy_orphan_detector", None)
    if taxonomy is not None:
        cleared = 0
        try:
            from agntspace.kb.taxonomy_proposals import (
                list_pending as tax_list,
            )
            from agntspace.kb.taxonomy_proposals import (
                reject_proposal as tax_reject,
            )
            for p in tax_list(vault_dir):
                if tax_reject(vault_dir, p.proposal_id):
                    cleared += 1
        except Exception as exc:
            errors.append({"kind": "taxonomy", "error": f"clear_failed: {exc}"})

        written = 0
        report = {}
        try:
            report = await taxonomy.detect_and_propose() or {}
            written = int(report.get("proposals_written") or 0)
        except Exception as exc:
            errors.append({"kind": "taxonomy", "error": f"detect_failed: {exc}"})

        slim_report = {k: v for k, v in report.items() if k != "proposals"}
        by_kind["taxonomy"] = {
            "cleared": cleared,
            "written": written,
            **slim_report,
        }
        cleared_total += cleared
        written_total += written

    # ── High-importance activity event so /activity surfaces the sweep ──
    activity = getattr(state, "activity_logger", None)
    if activity is not None:
        try:
            await activity.log(
                category="agent",
                action="proposals_refresh_all",
                summary=(
                    f"User cleared {cleared_total} stale proposal(s) and "
                    f"re-ran every detector → {written_total} fresh "
                    f"proposal(s) under current thresholds."
                ),
                details={
                    "cleared_total": cleared_total,
                    "written_total": written_total,
                    "by_kind": by_kind,
                    "errors": errors[:5],
                },
                importance="high",
            )
        except Exception:
            pass

    return {
        "cleared_total": cleared_total,
        "written_total": written_total,
        "by_kind": by_kind,
        "errors": errors,
    }
