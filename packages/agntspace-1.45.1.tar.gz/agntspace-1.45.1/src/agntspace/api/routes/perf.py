"""Performance telemetry — Tier 1 (event-loop block detector).

Read-only endpoints surfacing the EventLoopTracker's ring buffer + rollup
stats. The dashboard uses these to render a traffic-light health pill +
a recent-blocks list with stack snapshots.

  GET /api/perf/summary  → rollup stats (blocks_last_minute, max_block_ms, …)
  GET /api/perf/blocks   → newest-first list of recent block events
  GET /api/perf/health   → traffic-light: green / amber / red

All three endpoints are pure reads of in-memory state. No SQLite, no IO.
Safe to poll every few seconds. Degrade gracefully when the tracker
isn't wired (returns ``running: false`` shape).
"""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(prefix="/perf", tags=["perf"])


def _get_tracker(request: Request):
    """Best-effort lookup; returns None when tracker isn't wired."""
    return getattr(request.app.state, "perf_tracker", None)


@router.get("/summary")
async def perf_summary(request: Request) -> dict:
    """Rollup stats. Pure read."""
    tracker = _get_tracker(request)
    if tracker is None:
        return {
            "running": False,
            "reason": "perf tracker not wired",
            "total_blocks": 0,
            "blocks_last_minute": 0,
            "blocks_over_500ms_last_minute": 0,
            "blocks_over_5s_last_minute": 0,
        }
    return tracker.summary()


@router.get("/blocks")
async def perf_blocks(request: Request, limit: int = 50) -> dict:
    """Newest-first recent block events.

    Returns ``{items, total, has_more}`` per Rule 20. ``limit`` clamped
    by the tracker; ``has_more`` is True iff the buffer holds more than
    ``limit`` events.
    """
    tracker = _get_tracker(request)
    if tracker is None:
        return {"items": [], "total": 0, "has_more": False, "available": False}
    items = tracker.recent_blocks(limit=limit)
    s = tracker.summary()
    total = int(s.get("total_blocks", 0))
    return {
        "items": items,
        "total": total,
        "has_more": total > len(items),
        "available": True,
    }


@router.get("/health")
async def perf_health(request: Request) -> dict:
    """Traffic-light state + a one-line reason. Drives the dashboard pill."""
    tracker = _get_tracker(request)
    if tracker is None:
        return {"state": "green", "reason": "perf tracker not wired", "available": False}
    out = tracker.health()
    out["available"] = True
    return out
