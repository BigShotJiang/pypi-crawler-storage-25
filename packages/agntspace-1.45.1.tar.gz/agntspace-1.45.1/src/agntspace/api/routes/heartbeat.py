"""Heartbeat API — pulse history, status, and deviations for the cardiogram UI."""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(prefix="/heartbeat", tags=["heartbeat"])


@router.get("/status")
async def heartbeat_status(request: Request) -> dict:
    """Get current heartbeat status (running, last pulse, totals)."""
    return await request.app.state.heartbeat.get_status()


@router.get("/history")
async def heartbeat_history(request: Request, hours: int = 24, limit: int = 200) -> dict:
    """Get heartbeat pulse history for the cardiogram chart.

    Returns ``{items, total, has_more, history}`` per CLAUDE.md Rule 20. The
    legacy bare-list shape is preserved via the ``history`` alias on the
    response. ``total`` is an honest lower bound (items in this page); when
    ``has_more`` is True, pulses older than ``hours``-window or beyond
    ``limit`` exist. ``hours`` is a time-window filter, not pagination.
    """
    rows = await request.app.state.heartbeat.get_history(hours=hours, limit=limit + 1)
    has_more = len(rows) > limit
    items = rows[:limit]
    return {
        "items": items,
        "total": len(items),
        "has_more": has_more,
        # Legacy alias.
        "history": items,
    }


@router.get("/deviations")
async def heartbeat_deviations(request: Request, limit: int = 50) -> dict:
    """Get recent deviations (non-normal pulses) with details.

    Returns ``{items, total, has_more, deviations}`` per CLAUDE.md Rule 20.
    """
    rows = await request.app.state.heartbeat.get_deviations(limit=limit + 1)
    has_more = len(rows) > limit
    items = rows[:limit]
    return {
        "items": items,
        "total": len(items),
        "has_more": has_more,
        # Legacy alias.
        "deviations": items,
    }


@router.post("/pulse")
async def trigger_pulse(request: Request) -> dict:
    """Manually trigger a heartbeat pulse."""
    observations = await request.app.state.heartbeat.run_once()
    return {"observations": observations, "count": len(observations)}
