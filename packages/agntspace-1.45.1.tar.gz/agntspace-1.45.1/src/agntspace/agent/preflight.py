"""Chat-turn pre-flight: detect structural-gap skill matches BEFORE
the LLM generates output, so the agent can surface gaps to the user
honestly instead of producing a generic fallback.

**The gap this closes**: the main agent loads every active skill body
into the system prompt and has the orchestrator's semantic skill
retrieval primitive available. But neither path proactively WARNS the
agent "this user input matches a skill that's structurally incomplete
— don't pretend you can execute it."

The 2026-04-28 archer-presentation case: user typed "archer futura
presentation style", `archer-presentation` skill was active in the
prompt with brand specs, the agent built a generic deck because the
skill had no `tools_granted` and no theme registered.

This pre-flight runs at the top of every chat turn:

1. Find skills that match the user's input (semantic + lexical).
2. For each match, classify: **executable** (triggers + tools_granted
   + every granted tool registered) / **structurally_incomplete**
   (missing triggers / tools_granted) / **broken_grants** (tools_granted
   references unregistered tools).
3. When the top match has structural gaps, inject a system-message
   hint into the chat history naming the gap + concrete fix
   instructions. The agent reads the hint, surfaces it to the user,
   and the user gets "I see archer-presentation matches but it has no
   tools_granted; here's exactly what to add" instead of a generic
   deck.

The hint is a **system-role message** prepended to the per-turn
history — NOT modified into the base system prompt. This preserves
prompt caching (no per-turn cache invalidation) and keeps the hint
scoped to the turn that detected the gap.

**Engine vs strategy split** (Rule 12): the matching thresholds + the
"do we instrument this" toggle live in
``defaults/skills/_meta/preflight-structural-gap/config/preflight.yaml``.
The hint TEMPLATE is also YAML so users can tune the agent's
phrasing without code changes.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)


# Conservative defaults — every knob is overridable via the
# `_meta/preflight-structural-gap` skill config (Rule 12 substrate).
_FALLBACK_CONFIG = {  # arch:deterministic — degraded-mode fallback when YAML absent; canonical knobs live in defaults/skills/_meta/preflight-structural-gap/config/preflight.yaml
    "enabled": True,
    "lexical_max_matches": 3,
    "semantic_top_k": 5,
    "semantic_min_score": 0.55,
    "max_hints_per_turn": 1,
    "min_user_input_chars": 10,
    "hint_template": (
        "[Pre-flight skill match] The user's input matches the skill "
        "`{skill_name}`. Structural gaps detected: {gap_summary}. "
        "PROCEED with the request using the skill body's content as "
        "your best-effort blueprint — gaps mean the skill lacks one-"
        "click automation wiring, NOT that you should refuse. Pick "
        "reasonable defaults for unspecified detail; ask at most ONE "
        "sharp clarifying question, only if a true blocker. In your "
        "reply, briefly note what would need adding to the skill for "
        "full automation next time (e.g. `triggers:`, `tools_granted:`, "
        "register the missing theme). Best-effort execution + "
        "transparent gap disclosure — never silent fallback, never "
        "false refusal."
    ),
}


@dataclass
class StructuralMatch:
    """One matched skill with its structural classification."""

    skill_name: str
    title: str
    classification: str  # "executable" | "structurally_incomplete" | "broken_grants"
    match_kind: str       # "lexical" | "semantic"
    score: float
    missing_triggers: bool = False
    missing_tools_granted: bool = False
    unregistered_tools: list[str] = field(default_factory=list)

    @property
    def has_gaps(self) -> bool:
        return self.classification != "executable"

    @property
    def gap_summary(self) -> str:
        bits: list[str] = []
        if self.missing_triggers:
            bits.append("no triggers")
        if self.missing_tools_granted:
            bits.append("no tools_granted")
        if self.unregistered_tools:
            sample = ", ".join(self.unregistered_tools[:3])
            bits.append(f"granted tools not in registry ({sample})")
        return "; ".join(bits) if bits else "none"


# ── Pure helpers ────────────────────────────────────────────────────


def _resolve_config(skill_loader) -> dict:
    """Load preflight tuning knobs. Falls back to defaults on every
    failure mode (no loader, no skill, malformed YAML)."""
    cfg = dict(_FALLBACK_CONFIG)
    if skill_loader is None or not hasattr(skill_loader, "load_skill_config_file"):
        return cfg
    try:
        block = skill_loader.load_skill_config_file(
            "preflight-structural-gap", "preflight.yaml",
        )
    except Exception:
        return cfg
    if isinstance(block, dict):
        for k, v in block.items():
            if k in cfg and v is not None:
                cfg[k] = v
    return cfg


def _classify_skill(skill, registry) -> tuple[str, bool, bool, list[str]]:
    """Classify one skill's structural completeness.

    Returns a tuple of:
        (classification, missing_triggers, missing_tools_granted,
         unregistered_tools_list)

    Engine substrates (`_meta/*`) are always classified executable —
    they don't need user-facing surfaces.
    """
    cat = getattr(skill, "category", "") or ""
    if cat == "_meta":
        return "executable", False, False, []

    triggers = getattr(skill, "triggers", None) or []
    granted = getattr(skill, "tools_granted", None) or []

    missing_t = not (
        isinstance(triggers, list)
        and any(isinstance(t, str) and t.strip() for t in triggers)
    )
    missing_g = not (
        isinstance(granted, list)
        and any(isinstance(t, str) and t.strip() for t in granted)
    )

    if missing_t or missing_g:
        return "structurally_incomplete", missing_t, missing_g, []

    # Both triggers + tools_granted present — check that every granted
    # tool actually exists in the registry. Missing registry → no
    # check; we don't penalize a skill if we can't verify.
    unregistered: list[str] = []
    if registry is not None and hasattr(registry, "list_tools"):
        try:
            registered = {
                e.get("name") for e in (registry.list_tools() or [])
                if isinstance(e, dict) and isinstance(e.get("name"), str)
            }
            for tool in granted:
                if not isinstance(tool, str):
                    continue
                tn = tool.strip()
                if tn and tn not in registered:
                    unregistered.append(tn)
        except Exception:
            pass

    if unregistered:
        return "broken_grants", False, False, unregistered

    return "executable", False, False, []


def _lexical_matches(skill_loader, text: str, max_matches: int) -> list[tuple[str, float]]:
    """Run trigger-based match; return (skill_name, 1.0) tuples."""
    if skill_loader is None or not hasattr(skill_loader, "match_skills"):
        return []
    try:
        matches = skill_loader.match_skills(text)
    except Exception:
        return []
    out: list[tuple[str, float]] = []
    for s in matches[:max_matches]:
        name = getattr(s, "name", None)
        if isinstance(name, str) and name:
            out.append((name, 1.0))
    return out


def _semantic_matches(
    skill_loader, text: str, top_k: int, min_score: float,
) -> list[tuple[str, float]]:
    """Run Voyager semantic match; return (skill_name, score) tuples.

    Fail-open: no embedder, no fastembed, broken model → empty list,
    caller proceeds with lexical only.
    """
    if skill_loader is None or not hasattr(skill_loader, "find_matching_skills"):
        return []
    try:
        return skill_loader.find_matching_skills(
            text, top_k=top_k, min_score=min_score,
        ) or []
    except Exception:
        return []


def detect_structural_gaps(
    user_input: str,
    skill_loader,
    registry,
    *,
    config: dict | None = None,
) -> list[StructuralMatch]:
    """Pure analysis — find skills matching the user's input AND
    classify their structural completeness.

    Returns matches sorted with structural-gap matches FIRST so the
    caller surfaces gaps before passing through to executable matches.
    Within each group, sorted by descending score.

    Empty list when:
    * input is empty / too short
    * skill loader is None
    * config disables the pre-flight
    """
    cfg = config if isinstance(config, dict) else _resolve_config(skill_loader)
    if not cfg.get("enabled", True):
        return []
    if not isinstance(user_input, str):
        return []
    text = user_input.strip()
    if len(text) < int(cfg.get("min_user_input_chars", 10)):
        return []
    if skill_loader is None:
        return []

    skills_dict: dict[str, Any] = {}
    try:
        skills_dict = skill_loader.skills or {}
    except Exception:
        return []

    # Run both match paths and merge by skill name (best score wins).
    raw: dict[str, tuple[str, float]] = {}
    for name, score in _lexical_matches(
        skill_loader, text, int(cfg.get("lexical_max_matches", 3)),
    ):
        raw[name] = ("lexical", score)
    for name, score in _semantic_matches(
        skill_loader, text,
        int(cfg.get("semantic_top_k", 5)),
        float(cfg.get("semantic_min_score", 0.55)),
    ):
        prev = raw.get(name)
        if prev is None or score > prev[1]:
            raw[name] = ("semantic" if prev is None else prev[0], score)

    out: list[StructuralMatch] = []
    for name, (kind, score) in raw.items():
        skill = skills_dict.get(name)
        if skill is None:
            continue
        if getattr(skill, "status", "active") != "active":
            continue
        cls, mt, mg, unreg = _classify_skill(skill, registry)
        out.append(StructuralMatch(
            skill_name=name,
            title=getattr(skill, "title", name) or name,
            classification=cls,
            match_kind=kind,
            score=float(score),
            missing_triggers=mt,
            missing_tools_granted=mg,
            unregistered_tools=unreg,
        ))

    # Gaps first (lexicographic on classification ensures
    # broken_grants and structurally_incomplete come before
    # executable). Within a classification, descending score.
    def sort_key(m: StructuralMatch) -> tuple[int, float]:
        return (
            0 if m.has_gaps else 1,
            -m.score,
        )

    out.sort(key=sort_key)
    return out


def render_hint(match: StructuralMatch, template: str) -> str:
    """Render the system-message hint from the YAML template."""
    return template.format(
        skill_name=match.skill_name,
        skill_title=match.title,
        gap_summary=match.gap_summary,
        match_kind=match.match_kind,
        score=match.score,
    )


def build_preflight_hints(
    user_input: str,
    skill_loader,
    registry,
    *,
    config: dict | None = None,
) -> list[str]:
    """High-level: produce up to N hint strings for the agent to read
    before generating output. Empty list when nothing matters.

    The returned strings are ready to inject as system-role messages.
    """
    cfg = config if isinstance(config, dict) else _resolve_config(skill_loader)
    if not cfg.get("enabled", True):
        return []
    matches = detect_structural_gaps(
        user_input, skill_loader, registry, config=cfg,
    )
    template = str(cfg.get("hint_template") or _FALLBACK_CONFIG["hint_template"])
    cap = int(cfg.get("max_hints_per_turn", 1))
    hints: list[str] = []
    for m in matches:
        if not m.has_gaps:
            break  # Once we hit executable, nothing past needs surfacing.
        hints.append(render_hint(m, template))
        if len(hints) >= cap:
            break
    return hints
