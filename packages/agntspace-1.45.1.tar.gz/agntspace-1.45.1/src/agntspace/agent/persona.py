"""Persona switching for the main agent (Option A, 2026-05-06).

SOUL.md may declare an ``active_personality:`` frontmatter field pointing at a
named ``## Personality (<name>)`` section. When set, the agent's prompt
builder substitutes the variant section's body for the base ``## Personality``
section. The base section is the always-available fallback.

This module is the read/list/switch/reset surface for that feature. It
operates entirely on SOUL.md — no separate config file. The user can edit
SOUL.md by hand to add new variants; this service just toggles which one is
active.

Wire-up: constructed in main.py as ``app.state.persona`` after the vault is
ready. Routes mount under ``/api/persona/*``. CLI mounts at
``agntspace persona``. The agent's hot-reload picks up SOUL.md mtime changes
automatically (existing IDENTITY_PATHS watcher), so a switch surfaces in the
next chat turn without an explicit refresh call.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import frontmatter

from agntspace.llm.prompt import list_personality_variants

if TYPE_CHECKING:
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)


_SOUL_PATH = "system/identity/SOUL.md"
_FRONTMATTER_KEY = "active_personality"
_TRUST_REASON = "persona_switch"  # passes the VaultWriter runtime guard


class PersonaError(ValueError):
    """Raised on invalid persona switch (unknown variant)."""


@dataclass
class PersonaState:
    """Snapshot of the persona system's current state."""

    active: str  # "" when no variant active (base personality is in effect)
    available: list[str]  # variant names declared in SOUL.md (excluding base)


class PersonaService:
    """Read/list/switch/reset the agent's active personality.

    All operations are idempotent + total — never raises on missing SOUL.md
    (returns empty state) and never silently fails on a bad write (raises so
    the caller surfaces it). Switching to a name that doesn't exist as a
    section raises PersonaError so the user can pick a valid name.
    """

    def __init__(self, reader: VaultReader, writer: VaultWriter | None = None) -> None:
        self._reader = reader
        self._writer = writer

    # ── Read paths ───────────────────────────────────────────────────────

    def state(self) -> PersonaState:
        """Return the current active variant + the list of declared variants."""
        active = ""
        available: list[str] = []
        try:
            doc = self._reader.read(_SOUL_PATH)
        except FileNotFoundError:
            return PersonaState(active="", available=[])
        active = str(doc.metadata.get(_FRONTMATTER_KEY) or "").strip()
        available = list_personality_variants(doc.content)
        return PersonaState(active=active, available=available)

    def get_variant_body(self, name: str) -> str | None:
        """Return the body of ``## Personality (<name>)`` if it exists, else None.

        Used by /api/persona to preview a variant's content. Pure read.
        """
        if not name or not name.strip():
            return None
        try:
            doc = self._reader.read(_SOUL_PATH)
        except FileNotFoundError:
            return None
        from agntspace.llm.prompt import resolve_active_personality  # local import: avoid cycle

        # Trick: resolve produces a SOUL with the variant body in the BASE
        # section, then we extract the base section body. Cheap + reuses
        # the resolver logic so this stays in sync.
        resolved = resolve_active_personality(doc.content, name)
        if resolved == doc.content:
            return None  # variant didn't exist
        # Extract the body of the (now-substituted) base section.
        import re
        m = re.search(r"^##\s+Personality\s*$", resolved, flags=re.MULTILINE)
        if m is None:
            return None
        body_start = m.end()
        next_h2 = re.search(r"^##\s+", resolved[body_start:], flags=re.MULTILINE)
        end = body_start + next_h2.start() if next_h2 else len(resolved)
        return resolved[body_start:end].strip()

    # ── Write paths ──────────────────────────────────────────────────────

    def switch(self, name: str) -> PersonaState:
        """Set ``active_personality: <name>`` in SOUL.md frontmatter.

        Validates the variant exists. Writes via VaultWriter with
        ``trust_reason="persona_switch"`` so the runtime guard accepts the
        write without forcing a contract action gate (user-initiated +
        already authorized at the API/CLI boundary).

        Raises:
          PersonaError: if ``name`` doesn't match a declared variant.
          FileNotFoundError: if SOUL.md doesn't exist.
          RuntimeError: if no VaultWriter was wired.
        """
        target = (name or "").strip()
        if not target:
            raise PersonaError("persona name is empty")

        doc = self._reader.read(_SOUL_PATH)  # raises FileNotFoundError if missing
        available = list_personality_variants(doc.content)
        # Case-insensitive match for user-friendliness; preserve declared casing.
        canonical: str | None = None
        for v in available:
            if v.lower() == target.lower():
                canonical = v
                break
        if canonical is None:
            raise PersonaError(
                f"unknown persona '{target}'. Declared variants: {', '.join(available) or '(none)'}"
            )

        self._write_active(doc, canonical)
        return PersonaState(active=canonical, available=available)

    def reset(self) -> PersonaState:
        """Clear the ``active_personality`` field — fall back to base personality.

        Idempotent: a SOUL.md without the field is already in the reset state
        and the write is a no-op (we still touch the file so the agent's
        mtime watcher picks it up).
        """
        doc = self._reader.read(_SOUL_PATH)
        available = list_personality_variants(doc.content)
        self._write_active(doc, "")
        return PersonaState(active="", available=available)

    # ── Internal ─────────────────────────────────────────────────────────

    def _write_active(self, doc, value: str) -> None:
        """Rewrite SOUL.md with the new ``active_personality`` value.

        Empty value REMOVES the field entirely (cleaner than ``: ""``).
        Uses python-frontmatter for round-trip — preserves comments and
        ordering of other fields.
        """
        if self._writer is None:
            raise RuntimeError("PersonaService: no VaultWriter wired")

        post = frontmatter.loads(doc.raw)
        if value:
            post[_FRONTMATTER_KEY] = value
        else:
            # frontmatter.Post supports dict-style del
            try:
                del post[_FRONTMATTER_KEY]
            except KeyError:
                pass  # already absent — idempotent

        new_content = frontmatter.dumps(post)
        # Persist via VaultWriter so the write is observed (audit trail) and
        # passes the runtime guard via trust_reason.
        self._writer.write(
            _SOUL_PATH,
            new_content,
            trust_reason=_TRUST_REASON,
        )
        log.info(
            "PersonaService: %s active_personality (%s)",
            "set" if value else "cleared",
            value or "<base>",
        )
