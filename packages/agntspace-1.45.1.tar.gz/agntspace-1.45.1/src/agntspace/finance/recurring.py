"""Recurring transaction detection.

Walks the verified transaction history, groups by merchant, and identifies
subscriptions / repeated charges with a stable cadence and amount.

Pure function — no I/O. Caller supplies the transaction list.

Algorithm (deliberately simple, no ML):
  1. Group by ``merchant_slug``. Skip merchants with < ``min_occurrences``.
  2. Sort each merchant's txns by date. Compute consecutive-interval days.
  3. Median interval → frequency classification:
       - 25-35 days → monthly
       - 84-96 → quarterly
       - 175-190 → semiannual
       - 350-380 → yearly
       - 6-9 → weekly
       - else → irregular
  4. Stable interval iff stdev(intervals) ≤ ``day_tolerance`` (default 5).
  5. Stable amount iff every charge is within ±10% of the mean.
  6. Predicted next charge = last_date + median_interval.
  7. Estimated annual cost = mean_amount × (365 / median_interval).

The detector is deliberately conservative on `min_occurrences`: 3 is the
floor below which a "pattern" is just two coincidences. Users with
sparse history (one receipt per year) won't see false positives.

Used by:
  - ``GET /api/finance/recurring`` — surfaces detected charges
  - The dashboard's "Recurring charges" section
  - A future follow-up detector ``recurring_due_soon`` (next due ≤ 7 days)
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any


def _parse_date(s: str) -> date | None:
    """Parse YYYY-MM-DD; tolerate missing/junk by returning None."""
    if not s:
        return None
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def _classify_frequency(median_interval_days: float) -> str:
    """Map a median interval (days) to a human-readable cadence label.

    Bands chosen to absorb realistic month-length variance (28-31) and
    leap-year drift on annual charges. Anything outside the named bands
    falls through to "irregular".
    """
    n = median_interval_days
    if 6 <= n <= 9:
        return "weekly"
    if 13 <= n <= 16:
        return "biweekly"
    if 25 <= n <= 35:
        return "monthly"
    if 55 <= n <= 70:
        return "bimonthly"
    if 84 <= n <= 96:
        return "quarterly"
    if 175 <= n <= 190:
        return "semiannual"
    if 350 <= n <= 380:
        return "yearly"
    if n < 6:
        return "very_frequent"
    return "irregular"


def _annual_multiplier(frequency: str, median_interval_days: float) -> float:
    """How many times per year does a charge at this cadence fire?

    Maps the frequency label to a year-equivalent multiplier so we can
    compute "estimated annual cost" without relying on the raw interval
    (which may be noisy on small samples). Falls back to interval math
    for "irregular" patterns where labels don't apply.
    """
    table = {
        "weekly": 52.0,
        "biweekly": 26.0,
        "monthly": 12.0,
        "bimonthly": 6.0,
        "quarterly": 4.0,
        "semiannual": 2.0,
        "yearly": 1.0,
    }
    if frequency in table:
        return table[frequency]
    if median_interval_days <= 0:
        return 0.0
    return 365.0 / median_interval_days


@dataclass
class RecurringCharge:
    """One detected recurring pattern. Returned to the API caller as a dict."""
    merchant_slug: str
    frequency: str          # weekly / biweekly / monthly / quarterly / yearly / irregular / etc
    occurrences: int
    median_interval_days: float
    interval_stable: bool   # stdev(intervals) ≤ day_tolerance
    average_amount: str     # decimal string
    amount_stable: bool     # all amounts within ±10% of mean
    currency: str
    first_date: str         # YYYY-MM-DD
    last_date: str          # YYYY-MM-DD
    predicted_next_date: str    # last + median_interval
    estimated_annual_cost: str  # decimal string
    confidence: float       # 0.0 - 1.0; combines interval + amount stability + occurrences

    def to_dict(self) -> dict[str, Any]:
        return {
            "merchant_slug": self.merchant_slug,
            "frequency": self.frequency,
            "occurrences": self.occurrences,
            "median_interval_days": self.median_interval_days,
            "interval_stable": self.interval_stable,
            "average_amount": self.average_amount,
            "amount_stable": self.amount_stable,
            "currency": self.currency,
            "first_date": self.first_date,
            "last_date": self.last_date,
            "predicted_next_date": self.predicted_next_date,
            "estimated_annual_cost": self.estimated_annual_cost,
            "confidence": self.confidence,
        }


def detect_recurring_charges(
    transactions: list[Any],
    *,
    min_occurrences: int = 3,
    day_tolerance: int = 5,
) -> list[RecurringCharge]:
    """Identify recurring merchant charges from a transaction list.

    Filters out everything but verified status (caller is expected to
    pre-filter, but we double-check). Returns charges sorted by estimated
    annual cost (highest first) so the UI can lead with biggest spend.

    Returns ``[]`` when no merchant has ≥ ``min_occurrences`` and there's
    no meaningful pattern to surface — better silence than false signals.
    """
    by_merchant: dict[str, list[Any]] = {}
    for t in transactions:
        if getattr(t, "status", "") and t.status != "verified":
            continue
        slug = getattr(t, "merchant_slug", "")
        if not slug:
            continue
        if not getattr(t, "txn_date", None):
            continue
        by_merchant.setdefault(slug, []).append(t)

    out: list[RecurringCharge] = []
    for slug, txns in by_merchant.items():
        if len(txns) < min_occurrences:
            continue

        # Sort by date ascending. Drop entries with unparseable dates.
        with_dates: list[tuple[date, Any]] = []
        for t in txns:
            d = _parse_date(t.txn_date)
            if d:
                with_dates.append((d, t))
        if len(with_dates) < min_occurrences:
            continue
        with_dates.sort(key=lambda p: p[0])

        # Compute consecutive intervals (days).
        intervals: list[int] = []
        for i in range(1, len(with_dates)):
            intervals.append((with_dates[i][0] - with_dates[i - 1][0]).days)
        if not intervals:
            continue
        median_interval = float(statistics.median(intervals))
        # stdev only meaningful with ≥2 intervals
        stdev = float(statistics.stdev(intervals)) if len(intervals) > 1 else 0.0
        interval_stable = stdev <= day_tolerance

        frequency = _classify_frequency(median_interval)

        # Amount aggregation across all sampled charges.
        amounts: list[Decimal] = []
        for _, t in with_dates:
            try:
                amounts.append(Decimal(t.total or "0.00"))
            except Exception:
                continue
        if not amounts:
            continue
        avg_amount = sum(amounts, Decimal("0")) / Decimal(len(amounts))
        if avg_amount > 0:
            amount_stable = all(
                abs(a - avg_amount) / avg_amount < Decimal("0.10") for a in amounts
            )
        else:
            amount_stable = False

        first_date = with_dates[0][0]
        last_date = with_dates[-1][0]
        predicted_next = last_date + timedelta(days=int(median_interval))

        annual_mult = _annual_multiplier(frequency, median_interval)
        estimated_annual = (avg_amount * Decimal(str(annual_mult))).quantize(Decimal("0.01"))

        # Confidence — combines interval stability, amount stability, and
        # sample size into [0, 1]. Tuned so 3 occurrences with stable
        # interval+amount = ~0.75; 5+ stable = 0.95; irregular = ≤0.4.
        size_factor = min(1.0, len(with_dates) / 6.0)  # caps at 6 occurrences
        stability_factor = (
            (0.5 if interval_stable else 0.2)
            + (0.4 if amount_stable else 0.15)
        )
        confidence = round(0.1 + stability_factor * size_factor, 2)
        confidence = min(1.0, confidence)

        last_currency = getattr(with_dates[-1][1], "currency", "") or ""

        out.append(RecurringCharge(
            merchant_slug=slug,
            frequency=frequency,
            occurrences=len(with_dates),
            median_interval_days=median_interval,
            interval_stable=interval_stable,
            average_amount=f"{avg_amount:.2f}",
            amount_stable=amount_stable,
            currency=last_currency.upper(),
            first_date=first_date.isoformat(),
            last_date=last_date.isoformat(),
            predicted_next_date=predicted_next.isoformat(),
            estimated_annual_cost=str(estimated_annual),
            confidence=confidence,
        ))

    # Filter out low-confidence noise — a "recurring charge" needs either
    # a stable interval OR a stable amount. Three receipts at 200/170 day
    # intervals with varying amounts isn't a subscription; it's irregular
    # spend. Keeping it in the list creates false signals for the
    # "subscription detected" insight.
    out = [
        r for r in out
        if (r.interval_stable or r.amount_stable) and r.confidence >= 0.4
    ]

    out.sort(key=lambda r: Decimal(r.estimated_annual_cost), reverse=True)
    return out


def days_until(target_date_iso: str, today: date | None = None) -> int:
    """Days from today to ``target_date_iso``. Negative if past. ``None`` → 9999.

    Used by the follow-up detector to flag "due soon" recurring charges.
    """
    target = _parse_date(target_date_iso)
    if not target:
        return 9999
    ref = today or datetime.now().date()
    return (target - ref).days
