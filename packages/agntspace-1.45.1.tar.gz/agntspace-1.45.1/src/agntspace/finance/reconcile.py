"""Boot-time reconciliation: recover pending drafts orphaned by silent DB failures.

Closes the silent-failure class identified 2026-04-29 (BAUHAUS receipt — Telegram
photo intercept wrote markdown to ``agntspace-finance/pending/`` and moved the
original to ``library/`` BUT every database write failed with ``OperationalError:
database is locked`` because the KB compile pipeline was holding the lock for
longer than the 5s ``busy_timeout``).

The receipt pipeline catches DB errors and logs them, then continues — by design,
because the user already saw a successful Telegram bot reply and the markdown is
intact on disk. The cost is that ``/api/finance/pending`` reads from the ledger,
so a draft with no ledger row is invisible.

This module is the safety net: at every boot, scan ``finance/pending/*.md`` and
upsert any draft whose ``draft_id`` has no row in ``finance_transactions``. The
ledger's ``commit_transaction`` is itself idempotent on ``content_hash``, so
running this against a fully-reconciled vault is a no-op. Bounded by
``max_drafts`` so a pathological backlog can't block boot.

Architectural notes:

- **Pure function-with-deps** — accepts ``VaultReader``, ``FinanceLedger``, and
  optional ``MerchantResolver`` / ``ActivityLogger``. Stub-friendly. The
  caller (main.py lifespan) owns wiring.
- **Never raises** — failure to read a single draft logs + skips; failure to
  insert a single row logs + counts as ``skipped`` and moves on. A vault
  with one corrupt frontmatter doesn't block reconciliation of the others.
- **Idempotent at every layer** — ``commit_transaction`` dedups on
  content_hash; this module skips drafts already in the ledger before even
  attempting the write. Re-running is cheap.
- **Honest activity event** — emits ``finance/draft_reconciled`` per recovered
  row at *medium* importance so Rule #13 sees the agent's world model
  catching up. Aggregate ``finance/reconcile_pass_completed`` at the end.
"""

from __future__ import annotations

import logging
from typing import Any

from agntspace.finance.storage import list_drafts, read_draft
from agntspace.finance.types import Transaction, TransactionStatus

log = logging.getLogger(__name__)


_MAX_DRAFTS_DEFAULT = 200


async def reconcile_pending_drafts(
    *,
    reader: Any,
    ledger: Any,
    merchants: Any | None = None,
    activity_logger: Any | None = None,
    max_drafts: int = _MAX_DRAFTS_DEFAULT,
) -> dict[str, Any]:
    """Recover orphan drafts: markdown on disk but no ledger row.

    Returns a result dict with counters: ``scanned`` (pending markdown found),
    ``already_in_ledger`` (skipped, no work needed), ``recovered`` (inserted
    successfully), ``failed`` (insert raised — most likely transient DB lock,
    will heal on next boot or manual retry), ``unreadable`` (corrupt
    frontmatter), ``ids_recovered`` (list of draft_ids inserted this pass).

    Never raises. Per-draft failures degrade to counters + logs.
    """
    scanned = 0
    already_in_ledger = 0
    recovered = 0
    failed = 0
    unreadable = 0
    ids_recovered: list[str] = []

    try:
        draft_ids = list_drafts(reader)
    except Exception:
        log.exception("Finance reconcile: failed to list pending drafts")
        return {
            "scanned": 0,
            "already_in_ledger": 0,
            "recovered": 0,
            "failed": 0,
            "unreadable": 0,
            "ids_recovered": [],
            "error": "list_drafts_failed",
        }

    for draft_id in draft_ids[:max_drafts]:
        scanned += 1
        # Cheap pre-check — skip drafts already in the ledger so a healthy
        # vault is a no-op.
        try:
            existing = await ledger.get_transaction(draft_id)
        except Exception:
            log.debug(
                "Finance reconcile: get_transaction failed for %s — assuming missing",
                draft_id,
                exc_info=True,
            )
            existing = None
        if existing is not None:
            already_in_ledger += 1
            continue

        # Read the draft markdown
        try:
            draft = read_draft(reader, draft_id)
        except Exception:
            log.exception("Finance reconcile: read_draft crashed for %s", draft_id)
            unreadable += 1
            continue
        if draft is None:
            unreadable += 1
            log.warning(
                "Finance reconcile: draft %s present in list_drafts but read_draft "
                "returned None (corrupt frontmatter or missing file)",
                draft_id,
            )
            continue

        # Best-effort merchant alias re-recording — not load-bearing for the
        # ledger row; if the resolver is unwired or the alias is already
        # canonical, this is silently no-op'd.
        if merchants is not None and draft.merchant_slug and draft.merchant_raw:
            try:
                raw = draft.merchant_raw.strip()
                # No need to fail the whole reconcile on a merchant alias hiccup
                if raw:
                    await merchants.add_alias(draft.merchant_slug, raw)
            except Exception:
                log.debug(
                    "Finance reconcile: alias add failed for %s (non-fatal)",
                    draft.merchant_slug,
                    exc_info=True,
                )

        # Build the Transaction at status=draft and commit
        txn = Transaction(
            txn_id=draft.draft_id,
            txn_date=draft.txn_date,
            merchant_slug=draft.merchant_slug,
            currency=draft.currency,
            total=draft.total,
            tax=draft.tax,
            project_slug=draft.project_slug,
            status=TransactionStatus.DRAFT,
            items=draft.items,
            payment_method=draft.payment_method,
            source_file=draft.source_file,
            content_hash=draft.content_hash,
            correlation_id=draft.correlation_id,
            notes=draft.notes,
            receipt_number=draft.receipt_number,
            document_type=draft.document_type,
            subtotal=draft.subtotal,
            vendor_tax_id=draft.vendor_tax_id,
            vendor_address=draft.vendor_address,
            due_date=draft.due_date,
            discount_total=draft.discount_total,
            discount_description=draft.discount_description,
            tip=draft.tip,
            tax_breakdown=draft.tax_breakdown,
            buyer_tax_id=draft.buyer_tax_id,
            reverse_charge=draft.reverse_charge,
            audit_flags=draft.audit_flags,
        )
        try:
            await ledger.commit_transaction(txn)
            recovered += 1
            ids_recovered.append(draft.draft_id)
            log.info(
                "Finance reconcile: recovered draft %s (%s %s %s)",
                draft.draft_id,
                draft.merchant_raw or draft.merchant_slug or "?",
                draft.total,
                draft.currency,
            )
            if activity_logger is not None:
                try:
                    activity_logger.log(
                        category="finance",
                        action="draft_reconciled",
                        summary=(
                            f"Recovered orphan draft {draft.draft_id} "
                            f"({draft.merchant_raw or '?'} {draft.total} {draft.currency})"
                        ),
                        details={
                            "draft_id": draft.draft_id,
                            "merchant_raw": draft.merchant_raw,
                            "total": draft.total,
                            "currency": draft.currency,
                            "txn_date": draft.txn_date,
                            "source_file": draft.source_file,
                        },
                        importance="medium",
                    )
                except Exception:
                    log.debug(
                        "Finance reconcile: activity_logger.log raised (non-fatal)",
                        exc_info=True,
                    )
        except Exception:
            log.exception(
                "Finance reconcile: commit_transaction failed for %s "
                "(will retry on next boot)",
                draft.draft_id,
            )
            failed += 1

    summary = {
        "scanned": scanned,
        "already_in_ledger": already_in_ledger,
        "recovered": recovered,
        "failed": failed,
        "unreadable": unreadable,
        "ids_recovered": ids_recovered,
    }

    # Aggregate event so the user sees the catch-up pass without scrolling
    # through per-draft events.
    if activity_logger is not None and (recovered or failed or unreadable):
        try:
            activity_logger.log(
                category="finance",
                action="reconcile_pass_completed",
                summary=(
                    f"Reconciled finance pending: scanned={scanned} "
                    f"recovered={recovered} skipped={already_in_ledger} "
                    f"failed={failed} unreadable={unreadable}"
                ),
                details=summary,
                # High when something needed recovery (real silent-failure
                # event) — low when nothing did.
                importance="high" if recovered else "medium",
            )
        except Exception:
            log.debug(
                "Finance reconcile: aggregate activity log failed (non-fatal)",
                exc_info=True,
            )

    return summary


__all__ = ["reconcile_pending_drafts"]
