"""SuggestionEngine — auto-suggest categories + project for a draft.

Two layers, deterministic-first:

**Layer A (no LLM, instant, no cost):**
  - Per-line categorize: apply ``merchant.default_category`` to every line
    item that doesn't already have one. Stamps ``category_source="merchant_default"``.
  - Project attribution: if the merchant has ≥``min_history`` prior verified
    transactions AND ≥``history_threshold`` of them attribute to the same
    project, suggest that project at high confidence. Stamps
    ``project_source="merchant_history"``.

**Layer B (LLM, ~5-15s, ~$0.01-0.05):**
  - Per-line categorize: when Layer A didn't fill a line and the line has a
    description, ask the LLM to pick a category from the taxonomy. Stamps
    ``category_source="llm"``. Skipped per-line when ``transaction-categorize``'s
    ``dont_autoclassify`` list matches the description.
  - Project attribution: ONLY fires when Layer A produced no suggestion AND
    the user has projects whose name/slug matches a substring in any line
    item description OR the merchant's canonical name. Conservative — when
    no signal is strong, leaves empty rather than fabricating.

Design choices:

- **Idempotent**: re-running on the same draft is a no-op when slugs are
  already populated (or the source is ``"user"`` — never overwrite a user
  decision). Safe to call from manual re-trigger AND auto-fire after edit.
- **Never raises**: every layer has its own try/except. A categorize-LLM
  crash doesn't stop attribution; a project-history lookup failure doesn't
  stop categorization. Failures are logged.
- **Fire-and-forget compatible**: ``suggest_all()`` is async and safe to
  spawn via ``asyncio.create_task``. The caller doesn't await the result;
  the UI's auto-poll picks up the ledger updates when they land.
- **Skill-driven taxonomy**: the categorize taxonomy and the
  ``dont_autoclassify`` list both come from
  ``defaults/skills/finance/transaction-categorize/config/categories.yaml``.
  Adding a category is a YAML edit, not a Python change.

This module does NOT open a correlation scope or check the contract.
That's the caller's responsibility — the ingest path opens a scope and
authorizes ``ingest_receipt``; the manual re-trigger route uses its own
``ingest_receipt`` authorization.
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter
from typing import TYPE_CHECKING

from agntspace.finance.types import (
    LineItem,
    Transaction,
    TransactionStatus,
)

if TYPE_CHECKING:
    from agntspace.finance.ledger import FinanceLedger
    from agntspace.finance.merchants import MerchantResolver
    from agntspace.llm.base import LLMProvider
    from agntspace.projects.service import ProjectService
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# Layer-A defaults — engine internals, not user strategy. These three
# constants are the Bayesian-style consensus threshold the engine uses
# to decide "do we have enough history to suggest a project". They are
# already configurable per-vault by passing kwargs to the constructor in
# main.py; users who want to tune them edit that line. They encode WHAT
# COUNTS AS ENOUGH EVIDENCE (statistical convergence), not WHICH project
# fits which receipt (user-facing strategy — that lives in the project
# matcher's keyword logic + per-skill YAML).
_DEFAULT_MIN_HISTORY = 3       # arch:deterministic — engine convergence floor (need ≥3 priors before any signal counts)
_DEFAULT_HISTORY_THRESHOLD = 0.66  # arch:deterministic — engine convergence threshold (≥2/3 consensus to act)
_DEFAULT_HISTORY_LOOKBACK = 50     # arch:deterministic — engine recency window cap (LRU-style bound on history scan)


# Layer-B LLM categorize prompt. Skill YAML can override per-vault.
_LLM_CATEGORIZE_FALLBACK = (
    "You are a transaction categorizer. Given a list of line item "
    "descriptions and a fixed taxonomy, return ONLY a JSON object mapping "
    "each item index (zero-based) to its best category slug from the "
    "taxonomy. If no category fits a line, omit it from the output (do "
    "NOT use 'other' as a default). Return {} if nothing fits.\n\n"
    "Schema: {\"<index>\": \"<slug>\", ...}\n"
    "Rules:\n"
    "- Use ONLY slugs from the taxonomy.\n"
    "- A grocery-store receipt's 'engine oil' line is automotive, not groceries.\n"
    "- A coffee-shop receipt's 'tip' line is restaurants (matches the meal).\n"
    "- Never invent slugs. Better to omit than guess wrong.\n"
)


# Tier-2 substring match for project attribution. Multi-word project slugs
# get split on hyphens; we look for any token of length ≥4 in any item
# description (case-insensitive). This is the LAST resort before "leave
# empty" — keeps Layer B from fabricating attributions on sparse signals.
_MIN_PROJECT_KEYWORD_LEN = 4


class SuggestionEngine:
    """Compute + apply category + project suggestions for a draft.

    Construction:
        engine = SuggestionEngine(
            ledger=finance_ledger,
            merchants=merchant_resolver,
            project_service=project_service,  # may be None — disables project layer
            llm=llm,                          # may be None — disables Layer B
            skill_loader=skill_loader,        # may be None — uses fallback prompt + taxonomy
        )

    Lifecycle:
        await engine.suggest_all(draft_id)  # idempotent; safe to re-run
    """

    def __init__(
        self,
        *,
        ledger: FinanceLedger,
        merchants: MerchantResolver,
        project_service: ProjectService | None = None,
        llm: LLMProvider | None = None,
        skill_loader: SkillLoader | None = None,
        min_history: int = _DEFAULT_MIN_HISTORY,
        history_threshold: float = _DEFAULT_HISTORY_THRESHOLD,
        history_lookback: int = _DEFAULT_HISTORY_LOOKBACK,
    ) -> None:
        self._ledger = ledger
        self._merchants = merchants
        self._projects = project_service
        self._llm = llm
        self._skills = skill_loader
        self._min_history = max(1, int(min_history))
        self._history_threshold = float(history_threshold)
        self._history_lookback = max(self._min_history, int(history_lookback))

    # ────────────────────────────────────────────────────────────────────
    # Public API
    # ────────────────────────────────────────────────────────────────────
    async def suggest_all(self, draft_id: str) -> dict:
        """Run Layer A (deterministic) then Layer B (LLM, when needed).

        Returns a result dict for tests + manual re-trigger callers:
            {
                "draft_id": str,
                "category_suggestions": [{"item_id", "category_slug", "source"}, ...],
                "project_suggestion": {"project_slug": str, "source": str} | None,
                "skipped_reasons": list[str],  # e.g. "no_merchant", "all_assigned"
            }
        Never raises — failure modes return an empty result with a reason.
        """
        result = {
            "draft_id": draft_id,
            "category_suggestions": [],
            "project_suggestion": None,
            "skipped_reasons": [],
        }

        try:
            txn = await self._ledger.get_transaction(draft_id)
        except Exception:
            log.exception("suggest_all: failed to load draft %s", draft_id)
            result["skipped_reasons"].append("load_failed")
            return result

        if txn is None:
            result["skipped_reasons"].append("not_found")
            return result
        if txn.status != TransactionStatus.DRAFT:
            # Only operate on drafts. Verified/rejected/archived already
            # carry final user decisions; suggesting against them is a bug.
            result["skipped_reasons"].append(f"status_{txn.status.value}")
            return result

        # ── Layer A — categorize from merchant default ──
        try:
            cat_suggestions = await self._suggest_categories_from_merchant(txn)
            result["category_suggestions"].extend(cat_suggestions)
        except Exception:
            log.exception("suggest_all: layer-A categorize failed for %s", draft_id)
            result["skipped_reasons"].append("layer_a_categorize_failed")

        # ── Layer A — project from merchant history ──
        try:
            proj = await self._suggest_project_from_history(txn)
            if proj is not None:
                result["project_suggestion"] = proj
        except Exception:
            log.exception("suggest_all: layer-A project failed for %s", draft_id)
            result["skipped_reasons"].append("layer_a_project_failed")

        # Re-fetch the draft so Layer B sees Layer A's mutations. Without
        # this, the LLM categorize would re-process lines that Layer A
        # already filled.
        try:
            txn = await self._ledger.get_transaction(draft_id)
        except Exception:
            log.exception("suggest_all: refetch failed for %s", draft_id)
            return result
        if txn is None:
            return result

        # ── Layer B — LLM categorize ──
        if self._llm is not None:
            try:
                llm_cat = await self._suggest_categories_via_llm(txn)
                result["category_suggestions"].extend(llm_cat)
            except Exception:
                log.exception("suggest_all: layer-B categorize failed for %s", draft_id)
                result["skipped_reasons"].append("layer_b_categorize_failed")

        # ── Layer B — keyword-match project (only if Layer A didn't suggest) ──
        if (
            result["project_suggestion"] is None
            and self._projects is not None
        ):
            try:
                proj = await self._suggest_project_from_keywords(txn)
                if proj is not None:
                    result["project_suggestion"] = proj
            except Exception:
                log.exception("suggest_all: layer-B project failed for %s", draft_id)
                result["skipped_reasons"].append("layer_b_project_failed")

        return result

    # ────────────────────────────────────────────────────────────────────
    # Layer A — deterministic
    # ────────────────────────────────────────────────────────────────────
    async def _suggest_categories_from_merchant(
        self, draft: Transaction,
    ) -> list[dict]:
        """Apply merchant.default_category to unassigned line items.

        Returns the list of {item_id, category_slug, source} entries that
        were applied. Skipped lines (already categorized, source=user, no
        merchant default) are not in the return.
        """
        if not draft.merchant_slug:
            return []
        merchant = await self._merchants.get(draft.merchant_slug)
        if merchant is None or not merchant.default_category:
            return []
        applied: list[dict] = []
        for item in draft.items:
            # Skip lines the user already touched OR that have any slug.
            if item.category_source == "user":
                continue
            if item.category_slug:
                continue
            ok = await self._ledger.update_line_item(
                item.item_id,
                category_slug=merchant.default_category,
                category_source="merchant_default",
            )
            if ok:
                applied.append({
                    "item_id": item.item_id,
                    "category_slug": merchant.default_category,
                    "source": "merchant_default",
                })
        return applied

    async def _suggest_project_from_history(
        self, draft: Transaction,
    ) -> dict | None:
        """If ≥history_threshold of recent verified txns from this merchant
        attribute to the same project, suggest it at high confidence.

        Returns ``{project_slug, source}`` on hit, ``None`` on no signal
        OR when the txn already has a transaction-level project_slug set.
        """
        if not draft.merchant_slug:
            return None
        # Don't override existing transaction-level project
        if draft.project_slug:
            return None
        try:
            history = await self._ledger.list_transactions(
                merchant_slug=draft.merchant_slug,
                status=TransactionStatus.VERIFIED.value,
                limit=self._history_lookback,
            )
        except Exception:
            log.exception("project_history: list_transactions failed")
            return None
        if len(history) < self._min_history:
            return None
        # Count project_slug occurrences (skip empties)
        counter: Counter[str] = Counter()
        total = 0
        for txn in history:
            if txn.txn_id == draft.txn_id:
                continue  # don't count draft against itself
            if txn.project_slug:
                counter[txn.project_slug] += 1
                total += 1
        if total < self._min_history:
            return None
        top_slug, top_count = counter.most_common(1)[0]
        if top_count / total < self._history_threshold:
            return None
        # Confirmed signal — apply it
        ok = await self._ledger.update_transaction_meta(
            draft.txn_id,
            project_slug=top_slug,
            project_source="merchant_history",
        )
        if not ok:
            return None
        return {"project_slug": top_slug, "source": "merchant_history"}

    # ────────────────────────────────────────────────────────────────────
    # Layer B — LLM
    # ────────────────────────────────────────────────────────────────────
    def _load_taxonomy(self) -> tuple[list[str], list[str]]:
        """Return (category_slugs, dont_autoclassify_phrases) from skill YAML.

        ``categories.yaml`` lives at ``config/categories.yaml`` next to
        SKILL.md — separate file, NOT frontmatter. Use
        ``load_skill_config_file`` (NOT ``get_skill_config``, which reads
        frontmatter blocks). Pre-fix this call silently returned ``({}, [])``
        because the SKILL.md frontmatter has no ``categories:`` block, so
        Layer B LLM categorization never fired since Phase 2 shipped.
        """
        if self._skills is None:
            return ([], [])
        try:
            cfg = self._skills.load_skill_config_file(
                "transaction-categorize", "categories.yaml",
            )
        except Exception:
            return ([], [])
        if not isinstance(cfg, dict):
            return ([], [])
        cats = cfg.get("categories") or {}
        slugs = list(cats.keys()) if isinstance(cats, dict) else []
        skip = cfg.get("dont_autoclassify") or []
        skip_list = [str(s).lower() for s in skip if s]
        return (slugs, skip_list)

    async def _suggest_categories_via_llm(
        self, draft: Transaction,
    ) -> list[dict]:
        """Per-line LLM classify for items Layer A didn't fill.

        Returns the list of {item_id, category_slug, source="llm"} entries
        that were applied. Skips items in the ``dont_autoclassify`` list
        and items with no description.
        """
        slugs, skip_phrases = self._load_taxonomy()
        if not slugs:
            return []  # No taxonomy → no suggestions; safe default
        # Filter to lines that need classification
        candidates: list[tuple[int, LineItem]] = []
        for idx, item in enumerate(draft.items):
            if item.category_slug:
                continue
            if item.category_source == "user":
                continue
            desc = (item.description or "").strip().lower()
            if not desc:
                continue
            if any(phrase in desc for phrase in skip_phrases):
                continue
            candidates.append((idx, item))
        if not candidates:
            return []

        # Build a compact prompt: numbered items + taxonomy list
        lines = [
            f"{i}. {item.description}"
            for i, (_, item) in enumerate(candidates)
        ]
        items_block = "\n".join(lines)
        taxonomy_block = ", ".join(slugs)
        merchant_hint = (
            f"\nMerchant: {draft.merchant_slug}" if draft.merchant_slug else ""
        )

        # Use skill's prompt body if available, else the engine fallback.
        system = self._llm_categorize_prompt()
        user = (
            f"Taxonomy slugs: {taxonomy_block}\n"
            f"Currency: {draft.currency}{merchant_hint}\n\n"
            f"Line items:\n{items_block}\n\n"
            "Return ONLY the JSON object."
        )

        # LLM exceptions bubble up to ``suggest_all``'s outer try/except
        # so the call registers in ``skipped_reasons`` for observability.
        # Layer A's prior writes are already persisted — a Layer B crash
        # never invalidates them.
        from agntspace.llm.base import Message
        resp = await self._llm.complete(
            messages=[Message(role="user", content=user)],
            system=system,
            max_tokens=512,
            temperature=0.0,
        )

        mapping = _parse_index_to_slug_json(resp.content if resp else "")
        if not mapping:
            return []

        valid_slugs = set(slugs)
        applied: list[dict] = []
        for prompt_idx, slug in mapping.items():
            if slug not in valid_slugs:
                continue  # LLM hallucinated a slug; skip silently
            if prompt_idx < 0 or prompt_idx >= len(candidates):
                continue
            _, item = candidates[prompt_idx]
            ok = await self._ledger.update_line_item(
                item.item_id,
                category_slug=slug,
                category_source="llm",
            )
            if ok:
                applied.append({
                    "item_id": item.item_id,
                    "category_slug": slug,
                    "source": "llm",
                })
        return applied

    def _llm_categorize_prompt(self) -> str:
        """Return the system prompt for the LLM categorize call.

        Skill YAML override: ``transaction-categorize.categories.llm_prompt``
        (a string). Falls back to the engine constant when missing.
        """
        if self._skills is None:
            return _LLM_CATEGORIZE_FALLBACK
        try:
            cfg = self._skills.get_skill_config("transaction-categorize", "categories")
        except Exception:
            return _LLM_CATEGORIZE_FALLBACK
        if not isinstance(cfg, dict):
            return _LLM_CATEGORIZE_FALLBACK
        prompt = cfg.get("llm_prompt")
        if isinstance(prompt, str) and prompt.strip():
            return prompt
        return _LLM_CATEGORIZE_FALLBACK

    async def _suggest_project_from_keywords(
        self, draft: Transaction,
    ) -> dict | None:
        """Match item descriptions / merchant name against project slugs.

        Conservative: requires a token of ≥4 chars from the project slug
        to appear in some signal text. Single-token weak matches are
        skipped (would attribute every "data" line to a "data-pipeline"
        project). Returns the highest-scoring match or None.
        """
        if self._projects is None:
            return None
        # Don't override transaction-level project that's already set
        if draft.project_slug:
            return None
        try:
            projects = self._projects.list_projects(status_filter="active")
        except Exception:
            log.exception("project_keywords: list_projects failed")
            return None
        if not projects:
            return None

        signal = " ".join([
            draft.merchant_slug or "",
            *(item.description or "" for item in draft.items),
        ]).lower()
        if not signal.strip():
            return None

        # Score each project by counting keyword hits. Multi-word slugs
        # get more chances to match.
        scores: list[tuple[str, int]] = []
        for proj in projects:
            slug = (proj.get("slug") or proj.get("name") or "").lower().strip()
            if not slug:
                continue
            tokens = [
                t for t in re.split(r"[-_\s]+", slug)
                if len(t) >= _MIN_PROJECT_KEYWORD_LEN
            ]
            if not tokens:
                continue
            hits = sum(1 for t in tokens if t in signal)
            if hits == 0:
                continue
            scores.append((slug, hits))

        if not scores:
            return None
        # Highest hits wins; tie → first one
        scores.sort(key=lambda x: -x[1])
        top_slug, top_hits = scores[0]
        # Require at least one token hit; keyword-only attribution is
        # speculative so we DON'T mark it high-confidence — the UI will
        # still show the chip with a "suggested" badge, and the user can
        # accept or override before approval.
        ok = await self._ledger.update_transaction_meta(
            draft.txn_id,
            project_slug=top_slug,
            project_source="llm",
        )
        if not ok:
            return None
        return {"project_slug": top_slug, "source": "llm", "hits": top_hits}


# ────────────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────────────
def _parse_index_to_slug_json(text: str) -> dict[int, str]:
    """Parse the LLM's {"<index>": "<slug>", ...} reply.

    Robust to: leading/trailing prose, markdown fences, non-integer keys
    (skipped), non-string values (skipped).
    """
    if not text:
        return {}
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start == -1 or end == -1 or end < start:
        return {}
    try:
        parsed = json.loads(cleaned[start : end + 1])
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    out: dict[int, str] = {}
    for key, value in parsed.items():
        try:
            idx = int(key)
        except (TypeError, ValueError):
            continue
        if not isinstance(value, str):
            continue
        slug = value.strip().lower()
        if slug:
            out[idx] = slug
    return out


__all__ = ["SuggestionEngine"]
