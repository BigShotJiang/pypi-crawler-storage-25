"""Anomaly detection runtime engine.

Phase 2 declared 5 default rules in
[anomaly-detect/config/rules.yaml] but never wired the Python evaluator.
This module closes that gap.

Design — engine vs strategy split (Rule 12):

- Strategy lives entirely in YAML (rule names, predicates, params,
  severities, reason templates, cooldowns, scan window). YAML edits
  reshape behaviour without touching Python.
- This file is the engine: 5 deterministic predicate functions, a
  daily-sweep service, per-(txn_id, rule_name) cooldown, and the
  activity-event emit. Predicates are pure functions taking the txn
  + params + light "history provider" callbacks — testable without
  standing up the full ledger.

Rule semantics:

- ``amount_multiple``     — txn total > N× merchant's median over last K txns
- ``calendar_window``     — txn time-of-day inside [hour_min, hour_max)
- ``currency_surprise``   — txn currency unseen in last N days
- ``category_jump``       — single txn's category amount > prior month total
- ``weekday``             — txn day-of-week matches the listed days
                            (optionally only deductible txns)

Each rule fires INDEPENDENTLY — a single transaction can collect multiple
flags on one scan. Flags are surfaced as ``transaction_anomaly_flagged``
activity events; importance is derived from the rule's ``severity``.
**Read-only on the ledger** — never mutates txn rows. Audit-trail-only.

Cooldown — per (txn_id, rule_name) for ``cooldown_hours`` (default
168 = one week). Stops the same flag from re-firing every day if the
user hasn't yet reviewed it.

Heartbeat — daily cadence (gated by ``heartbeat.enabled`` in YAML). The
sweep walks verified txns within ``window_days`` and evaluates every
enabled rule. First sweep after restart re-evaluates everything (no
persistent cooldown across restarts) — accepted cost: a quiet
re-baseline rather than a stale state file.

This is engine substrate (Rule 12), not strategy. Tuning rules is a
YAML edit. Adding a NEW predicate kind requires extending
``_PREDICATE_FUNCS`` here AND declaring it in the YAML schema —
both happen together because that's a real shape change.
"""

from __future__ import annotations

import calendar
import logging
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.activity.logger import ActivityLogger
    from agntspace.finance.ledger import FinanceLedger
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────
# Pure predicate functions
# ────────────────────────────────────────────────────────────────────
# Each predicate takes:
#   txn:    Transaction object (has txn_id, txn_date, total, currency,
#           merchant_slug, items, etc.)
#   params: rule.params dict from YAML
#   ctx:    dict of optional helpers per predicate kind:
#             - history: callable(merchant_slug) -> list[Decimal]
#             - currency_history: callable(lookback_days) -> set[str]
#             - category_total: callable(category, since, until) -> Decimal
#
# Returns:
#   {"reason_fields": dict, "match": True}     when the predicate fires
#   None                                       when it doesn't fire
#
# A predicate that depends on a missing helper (e.g. category_jump
# without category_total) returns None — the rule silently skips for
# that txn. Keeps the engine resilient to partial wiring.


def predicate_amount_multiple(
    txn: Any,
    params: dict[str, Any],
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Flag when txn.total > multiple × merchant's median over last N PRIOR txns.

    Critical: priors EXCLUDE the txn under evaluation. Otherwise a
    one-off purchase would inflate its own baseline median.
    """
    ctx = ctx or {}
    history_fn: Callable[..., list[Decimal]] | None = ctx.get("history")
    if history_fn is None:
        return None
    multiple = float(params.get("multiple", 5.0))
    min_history = int(params.get("min_history", 3))
    min_amount = Decimal(str(params.get("min_amount", 0)))

    try:
        amount = Decimal(str(txn.total or "0"))
    except (TypeError, InvalidOperation):
        return None
    if amount < min_amount:
        return None

    try:
        # ``history`` accepts (merchant_slug, exclude_txn_id) — providers
        # that don't support the second arg can ignore it (kwargs).
        priors = history_fn(txn.merchant_slug, exclude_txn_id=txn.txn_id)
    except TypeError:
        # Older provider signature without exclude_txn_id — fall back.
        # Tests against this codepath should always use the new signature.
        try:
            priors = history_fn(txn.merchant_slug)
        except Exception:
            return None
    except Exception:
        log.debug("amount_multiple history fetch failed", exc_info=True)
        return None
    if len(priors) < min_history:
        return None

    sorted_priors = sorted(priors)
    n = len(sorted_priors)
    if n % 2 == 1:
        median = sorted_priors[n // 2]
    else:
        median = (sorted_priors[n // 2 - 1] + sorted_priors[n // 2]) / Decimal(2)
    if median <= 0:
        return None
    if amount <= median * Decimal(str(multiple)):
        return None
    return {
        "match": True,
        "reason_fields": {
            "multiple": multiple,
            "baseline": float(median),
            "amount": float(amount),
            "merchant": txn.merchant_slug or "",
            "txn_id": txn.txn_id,
            "currency": txn.currency or "",
            "date": txn.txn_date or "",
        },
    }


def predicate_calendar_window(
    txn: Any,
    params: dict[str, Any],
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Flag when txn timestamp's hour-of-day falls in [hour_min, hour_max)."""
    hour_min = int(params.get("hour_min", 0))
    hour_max = int(params.get("hour_max", 24))
    requires_time = bool(params.get("requires_time", True))

    raw = (txn.txn_date or "").strip()
    if not raw:
        return None
    if requires_time and "T" not in raw and " " not in raw:
        # Date-only receipt — most paper has no time. Skip silently.
        return None
    try:
        # ``fromisoformat`` accepts ``2026-04-25T14:30`` and ``2026-04-25``;
        # the latter parses as midnight which we just rejected via the
        # ``T not in raw`` check above when requires_time=True.
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    h = dt.hour
    in_window = (
        (hour_min <= h < hour_max)
        if hour_min <= hour_max
        # Wrap-around window like 22:00–02:00
        else (h >= hour_min or h < hour_max)
    )
    if not in_window:
        return None
    return {
        "match": True,
        "reason_fields": {
            "txn_time": dt.strftime("%H:%M"),
            "hour_min": hour_min,
            "hour_max": hour_max,
            "txn_id": txn.txn_id,
            "merchant": txn.merchant_slug or "",
            "amount": str(txn.total or ""),
            "currency": txn.currency or "",
            "date": txn.txn_date or "",
        },
    }


def predicate_currency_surprise(
    txn: Any,
    params: dict[str, Any],
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Flag when txn currency hasn't been seen in last N days."""
    ctx = ctx or {}
    currency_fn: Callable[[int], set[str]] | None = ctx.get("currency_history")
    if currency_fn is None:
        return None
    cur = (txn.currency or "").upper().strip()
    if not cur:
        return None
    lookback_days = int(params.get("lookback_days", 90))
    try:
        seen = currency_fn(lookback_days)
    except Exception:
        log.debug("currency_history fetch failed", exc_info=True)
        return None
    if cur in seen:
        return None
    return {
        "match": True,
        "reason_fields": {
            "currency": cur,
            "lookback_days": lookback_days,
            "seen_currencies": ", ".join(sorted(seen)) or "(none)",
            "txn_id": txn.txn_id,
            "merchant": txn.merchant_slug or "",
            "amount": str(txn.total or ""),
            "date": txn.txn_date or "",
        },
    }


def predicate_category_jump(
    txn: Any,
    params: dict[str, Any],
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Flag when a single txn's category amount > prior month's total."""
    ctx = ctx or {}
    category_total_fn: Callable[[str, str, str], Decimal] | None = ctx.get(
        "category_total",
    )
    if category_total_fn is None:
        return None
    lookback_months = int(params.get("lookback_months", 1))
    min_prior_total = Decimal(str(params.get("min_prior_total", 0)))
    multiple = Decimal(str(params.get("multiple", 1.0)))

    # Walk every line item, evaluate per-category. The first category
    # that flags wins (one anomaly per scan per rule per txn — keeps
    # the audit log clean).
    items = list(getattr(txn, "items", ()) or ())
    by_cat: dict[str, Decimal] = {}
    for it in items:
        cat = (getattr(it, "category_slug", "") or "").strip()
        if not cat:
            continue
        try:
            amt = Decimal(str(getattr(it, "amount", "0") or "0"))
        except (TypeError, InvalidOperation):
            continue
        by_cat[cat] = by_cat.get(cat, Decimal(0)) + amt
    if not by_cat:
        return None

    txn_date = (txn.txn_date or "").split("T")[0].split(" ")[0]
    if not txn_date:
        return None
    # Compute the prior-month window bracket
    try:
        anchor = datetime.fromisoformat(txn_date)
    except ValueError:
        return None
    until_dt = anchor.replace(day=1) - timedelta(days=1)
    since_dt = (until_dt.replace(day=1)
                - timedelta(days=(lookback_months - 1) * 31))
    since = since_dt.strftime("%Y-%m-%d")
    until = until_dt.strftime("%Y-%m-%d")

    for cat, current_amount in by_cat.items():
        try:
            prior_total = category_total_fn(cat, since, until)
        except Exception:
            log.debug(
                "category_total fetch failed for %s", cat, exc_info=True,
            )
            continue
        if prior_total < min_prior_total:
            continue
        if current_amount <= prior_total * multiple:
            continue
        return {
            "match": True,
            "reason_fields": {
                "category": cat,
                "amount": float(current_amount),
                "baseline": float(prior_total),
                "multiple": float(multiple),
                "lookback_months": lookback_months,
                "txn_id": txn.txn_id,
                "merchant": txn.merchant_slug or "",
                "currency": txn.currency or "",
                "date": txn_date,
            },
        }
    return None


def predicate_weekday(
    txn: Any,
    params: dict[str, Any],
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Flag when txn lands on the listed weekdays (e.g. Saturday/Sunday)."""
    days_param = params.get("days") or []
    days_set: set[str] = {str(d).strip().lower() for d in days_param}
    if not days_set:
        return None
    requires_deductible = bool(params.get("requires_deductible", False))

    raw = (txn.txn_date or "").split("T")[0].split(" ")[0]
    if not raw:
        return None
    try:
        d = datetime.fromisoformat(raw)
    except ValueError:
        return None
    weekday_name = calendar.day_name[d.weekday()]
    if weekday_name.lower() not in days_set:
        return None

    if requires_deductible:
        items = list(getattr(txn, "items", ()) or ())
        if not any(getattr(it, "tax_deductible", False) for it in items):
            return None

    return {
        "match": True,
        "reason_fields": {
            "weekday": weekday_name,
            "days": ", ".join(sorted(days_set)),
            "txn_id": txn.txn_id,
            "merchant": txn.merchant_slug or "",
            "amount": str(txn.total or ""),
            "currency": txn.currency or "",
            "date": raw,
        },
    }


# ────────────────────────────────────────────────────────────────────
# Predicate registry — adding a new predicate kind goes here AND in YAML
# ────────────────────────────────────────────────────────────────────
_PREDICATE_FUNCS: dict[str, Callable[..., Any]] = {
    "amount_multiple": predicate_amount_multiple,
    "calendar_window": predicate_calendar_window,
    "currency_surprise": predicate_currency_surprise,
    "category_jump": predicate_category_jump,
    "weekday": predicate_weekday,
}


def _format_reason(template: str, fields: dict[str, Any]) -> str:
    """Render the rule's reason_template against the predicate's fields.

    Format errors fall back to the template verbatim — never crash
    a scan because the YAML used a key the predicate didn't supply.
    """
    if not template:
        return ""
    try:
        return template.format(**fields)
    except (KeyError, IndexError, ValueError):
        return template


def _severity_to_importance(severity: str) -> str:
    """Map ``severity`` → ActivityLogger importance level."""
    s = (severity or "").lower()
    if s in ("low", "medium", "high"):
        return s
    return "medium"


# ────────────────────────────────────────────────────────────────────
# Service
# ────────────────────────────────────────────────────────────────────
class AnomalyDetector:
    """Daily-sweep anomaly detector — fires activity events on flags.

    Lifecycle:
        - ``scan(window_days=N)`` is the entry point. Walks verified
          txns in the trailing window, evaluates every enabled rule
          per-txn, fires activity events on new flags (gated by the
          per-(txn_id, rule_name) cooldown).
        - The heartbeat calls ``scan`` once per cadence_hours with the
          configured window from YAML.

    State — in-memory only. Restarting clears the cooldown dict; the
    next scan re-evaluates everything. Acceptable trade-off (vs a
    persistent state file): if a flag was already user-reviewed the
    user just sees it once more on the next sweep, which is honest.
    """

    def __init__(
        self,
        *,
        ledger: FinanceLedger,
        skill_loader: SkillLoader | None,
        activity_logger: ActivityLogger | None = None,
    ) -> None:
        self._ledger = ledger
        self._skills = skill_loader
        self._activity = activity_logger
        # Cooldown: (txn_id, rule_name) -> datetime fired
        self._last_flag_at: dict[tuple[str, str], datetime] = {}
        self._scan_count = 0
        self._flags_fired = 0

    def _load_config(self) -> dict[str, Any]:
        if self._skills is None:
            return {}
        try:
            cfg = self._skills.load_skill_config_file(
                "anomaly-detect", "rules.yaml",
            )
        except Exception:
            return {}
        return cfg if isinstance(cfg, dict) else {}

    async def scan(self, *, window_days: int | None = None) -> dict[str, Any]:
        """One sweep over verified txns in the window.

        Returns ``{scanned, flags, reason}``. Never raises.
        """
        self._scan_count += 1
        cfg = self._load_config()
        rules = cfg.get("rules") or []
        if not rules:
            return {"scanned": 0, "flags": 0, "reason": "no_rules"}

        hb_cfg = cfg.get("heartbeat") or {}
        if window_days is None:
            window_days = int(hb_cfg.get("window_days", 30))
        cooldown_hours = float(hb_cfg.get("cooldown_hours", 168))

        # Compute the date window for the txn query.
        until_dt = datetime.now(UTC).date()
        since_dt = until_dt - timedelta(days=int(window_days))
        try:
            txns = await self._ledger.list_transactions(
                since=since_dt.isoformat(),
                until=until_dt.isoformat(),
                status="verified",
                limit=1000,
            )
        except Exception:
            log.debug("AnomalyDetector: list_transactions failed", exc_info=True)
            return {"scanned": 0, "flags": 0, "reason": "ledger_error"}

        # Pre-fetch helper data ONCE per scan. Predicates are pure
        # synchronous functions, so anything that needs an async ledger
        # call has to be resolved up-front and handed in as a closure
        # over an in-memory cache. The currency-history preload is
        # explicitly bracketed to txns BEFORE the scan window so a
        # newly-introduced currency in the scan window flags as
        # "unseen" (instead of self-counting as already-seen).
        currency_seen = await self._preload_currency_history(
            rules, scan_since=since_dt.isoformat(),
        )
        category_totals = await self._preload_category_totals(rules, txns)
        history_lookup = self._build_merchant_history(txns)

        def _currency_lookup(window: int) -> set[str]:
            return currency_seen.get(int(window), set())

        def _category_lookup(category: str, since: str, until: str) -> Decimal:
            return category_totals.get((category, since, until), Decimal(0))

        ctx = {
            "history": history_lookup,
            "currency_history": _currency_lookup,
            "category_total": _category_lookup,
        }

        now = datetime.now(UTC)
        flags_this_pass = 0
        for txn in txns:
            for rule in rules:
                rule_name = str(rule.get("name") or "").strip()
                pred_kind = str(rule.get("predicate") or "").strip()
                if not rule_name or not pred_kind:
                    continue
                pred_fn = _PREDICATE_FUNCS.get(pred_kind)
                if pred_fn is None:
                    log.debug(
                        "AnomalyDetector: unknown predicate %r in rule %r",
                        pred_kind, rule_name,
                    )
                    continue
                params = rule.get("params") or {}
                try:
                    result = pred_fn(txn, params, ctx)
                except Exception:
                    log.debug(
                        "AnomalyDetector: predicate %r raised on %s",
                        rule_name, getattr(txn, "txn_id", "?"),
                        exc_info=True,
                    )
                    continue
                if result is None:
                    continue

                # Cooldown gate per (txn_id, rule_name)
                key = (txn.txn_id, rule_name)
                last = self._last_flag_at.get(key)
                if last is not None:
                    elapsed_hours = (now - last).total_seconds() / 3600
                    if elapsed_hours < cooldown_hours:
                        continue

                self._last_flag_at[key] = now
                flags_this_pass += 1
                self._flags_fired += 1
                self._emit_flag(txn=txn, rule=rule, result=result)

        return {
            "scanned": len(txns),
            "flags": flags_this_pass,
            "lifetime_flags": self._flags_fired,
            "lifetime_scans": self._scan_count,
            "window_days": window_days,
        }

    # ── Helper providers ────────────────────────────────────────────
    def _build_merchant_history(self, current_txns: list[Any]):
        """Per-merchant prior totals indexed by (merchant_slug, txn_id → total).

        Returns a closure that accepts ``(merchant_slug, exclude_txn_id)``
        and returns the totals for every txn at that merchant EXCEPT
        the excluded one. Critical: a one-off large purchase must NOT
        inflate its own median.
        """
        per_merchant: dict[str, list[tuple[str, Decimal]]] = {}
        for t in current_txns:
            slug = getattr(t, "merchant_slug", "") or ""
            tid = getattr(t, "txn_id", "") or ""
            if not slug or not tid:
                continue
            try:
                v = Decimal(str(getattr(t, "total", "0") or "0"))
            except (TypeError, InvalidOperation):
                continue
            per_merchant.setdefault(slug, []).append((tid, v))

        def history(merchant_slug: str, *, exclude_txn_id: str = "") -> list[Decimal]:
            return [
                v for tid, v in per_merchant.get(merchant_slug, [])
                if tid != exclude_txn_id
            ]

        return history

    async def _preload_currency_history(
        self, rules: list[dict], *, scan_since: str = "",
    ) -> dict[int, set[str]]:
        """Pre-fetch the set of currencies seen per lookback window.

        For every rule with predicate ``currency_surprise``, query the
        ledger for verified txns in the historical lookback window
        (``[scan_since - lookback_days, scan_since)``) and collect the
        distinct currency codes. Result keyed by ``lookback_days``.

        Critical: the lookback EXCLUDES the current scan window. If we
        included the scan window, every currency in the scan would
        already be in the "seen" set (because the scan-window query
        sees itself), and ``currency_surprise`` would never fire.
        Bracketing strictly BEFORE ``scan_since`` is the right semantic:
        "this currency wasn't seen in your prior history".
        """
        windows: set[int] = set()
        for rule in rules:
            if rule.get("predicate") != "currency_surprise":
                continue
            params = rule.get("params") or {}
            try:
                w = int(params.get("lookback_days", 90))
            except (TypeError, ValueError):
                continue
            if w > 0:
                windows.add(w)
        out: dict[int, set[str]] = {}
        # Lookback bracket: end one day BEFORE scan_since to avoid
        # double-counting txns from the scan window itself.
        if scan_since:
            try:
                anchor = datetime.fromisoformat(scan_since).date()
            except ValueError:
                anchor = datetime.now(UTC).date()
        else:
            anchor = datetime.now(UTC).date()
        until_dt = anchor - timedelta(days=1)
        for w in windows:
            since_dt = anchor - timedelta(days=w)
            try:
                rows = await self._ledger.list_transactions(
                    since=since_dt.isoformat(),
                    until=until_dt.isoformat(),
                    status="verified", limit=1000,
                )
            except Exception:
                log.debug(
                    "AnomalyDetector: preload currencies failed for window=%d",
                    w, exc_info=True,
                )
                out[w] = set()
                continue
            seen: set[str] = set()
            for t in rows:
                cur = (getattr(t, "currency", "") or "").upper().strip()
                if cur:
                    seen.add(cur)
            out[w] = seen
        return out

    async def _preload_category_totals(
        self, rules: list[dict], txns: list,
    ) -> dict[tuple[str, str, str], Decimal]:
        """Pre-fetch prior-period totals per (category, since, until).

        For every rule with predicate ``category_jump``, walk the txns
        in the scan window to find every (category_slug, prior-month
        bracket) combination that the predicate could be asked about,
        then query the ledger once per unique tuple.
        """
        # Find every active category_jump rule's params
        category_rules = [r for r in rules if r.get("predicate") == "category_jump"]
        if not category_rules:
            return {}

        # Build the unique (category, since, until) tuples needed by
        # walking each txn × the rule's lookback math.
        wanted: set[tuple[str, str, str]] = set()
        for rule in category_rules:
            params = rule.get("params") or {}
            try:
                lookback_months = int(params.get("lookback_months", 1))
            except (TypeError, ValueError):
                lookback_months = 1
            for txn in txns:
                txn_date = (getattr(txn, "txn_date", "") or "").split("T")[0].split(" ")[0]
                if not txn_date:
                    continue
                try:
                    anchor = datetime.fromisoformat(txn_date)
                except ValueError:
                    continue
                until_dt = anchor.replace(day=1) - timedelta(days=1)
                since_dt = (
                    until_dt.replace(day=1)
                    - timedelta(days=(lookback_months - 1) * 31)
                )
                since = since_dt.strftime("%Y-%m-%d")
                until = until_dt.strftime("%Y-%m-%d")
                # Each line item's category contributes to a unique tuple
                items = getattr(txn, "items", ()) or ()
                for it in items:
                    cat = (getattr(it, "category_slug", "") or "").strip()
                    if not cat:
                        continue
                    wanted.add((cat, since, until))

        out: dict[tuple[str, str, str], Decimal] = {}
        for category, since, until in wanted:
            try:
                rows = await self._ledger.list_transactions(
                    since=since, until=until,
                    category_slug=category,
                    status="verified", limit=1000,
                )
            except Exception:
                log.debug(
                    "AnomalyDetector: preload category total failed (%s, %s, %s)",
                    category, since, until, exc_info=True,
                )
                out[(category, since, until)] = Decimal(0)
                continue
            total = Decimal(0)
            for t in rows:
                for it in getattr(t, "items", ()) or ():
                    if (getattr(it, "category_slug", "") or "") != category:
                        continue
                    try:
                        total += Decimal(str(getattr(it, "amount", "0") or "0"))
                    except (TypeError, InvalidOperation):
                        continue
            out[(category, since, until)] = total
        return out

    # ── Activity emit ──────────────────────────────────────────────
    def _emit_flag(self, *, txn: Any, rule: dict, result: dict) -> None:
        if self._activity is None:
            return
        rule_name = rule.get("name", "")
        severity = rule.get("severity", "medium")
        importance = _severity_to_importance(str(severity))
        reason_template = rule.get("reason_template", "")
        reason = _format_reason(reason_template, result.get("reason_fields", {}))
        scope_label = self._txn_label(txn)
        summary = f"Anomaly: {rule_name} on {scope_label} — {reason}".rstrip(" —")
        try:
            self._activity.log(
                category="user",
                action="transaction_anomaly_flagged",
                summary=summary,
                details={
                    "txn_id": txn.txn_id,
                    "rule_name": rule_name,
                    "severity": severity,
                    "reason": reason,
                    "merchant_slug": getattr(txn, "merchant_slug", ""),
                    "amount": str(getattr(txn, "total", "")),
                    "currency": getattr(txn, "currency", ""),
                    "txn_date": getattr(txn, "txn_date", ""),
                    "via": "heartbeat",
                    **result.get("reason_fields", {}),
                },
                importance=importance,
            )
        except Exception:
            log.debug("AnomalyDetector: activity emit failed", exc_info=True)

    @staticmethod
    def _txn_label(txn: Any) -> str:
        merchant = getattr(txn, "merchant_slug", "") or "unknown"
        amount = getattr(txn, "total", "") or "0"
        currency = getattr(txn, "currency", "") or ""
        date = getattr(txn, "txn_date", "") or ""
        return f"{merchant} {amount} {currency} ({date})".strip()

    def get_status(self) -> dict[str, Any]:
        return {
            "tracked_flags": len(self._last_flag_at),
            "lifetime_scans": self._scan_count,
            "lifetime_flags": self._flags_fired,
        }


__all__ = [
    "AnomalyDetector",
    "predicate_amount_multiple",
    "predicate_calendar_window",
    "predicate_currency_surprise",
    "predicate_category_jump",
    "predicate_weekday",
]
