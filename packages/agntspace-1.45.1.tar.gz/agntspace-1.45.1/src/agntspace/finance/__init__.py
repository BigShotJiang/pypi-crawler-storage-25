"""Finance subsystem — receipt ingestion, ledger, budgets, reports.

See [tasks/plan-finance-feature.md](../../../../tasks/plan-finance-feature.md)
for the full architecture. Phase 1 ships the data layer (this package's
``types``, ``ledger``, ``merchants`` modules) plus the ``receipt-processing``
workflow. Phase 2 adds budgets. Phase 3 adds reports + anomaly detection.

Vault layout: ``<vault>/agntspace-finance/`` holds markdown source-of-truth.
SQLite index lives at ``<vault>/agntspace/finance.db`` (per-vault, Rule #1).
The index is rebuildable from markdown via ``agntspace finance reindex``.

Currency model: native currency stored on every transaction. Conversion to
the user's base currency happens at report time, not at write time. Amounts
are stored as strings (``Decimal``-serialised) to dodge float precision
errors that would compound across thousands of line items.
"""

from agntspace.finance.ledger import FinanceLedger
from agntspace.finance.types import (
    Budget,
    LineItem,
    Merchant,
    TaxLine,
    Transaction,
    TransactionDraft,
    TransactionStatus,
)

__all__ = [
    "Budget",
    "FinanceLedger",
    "LineItem",
    "Merchant",
    "TaxLine",
    "Transaction",
    "TransactionDraft",
    "TransactionStatus",
]
