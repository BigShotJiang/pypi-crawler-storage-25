"""Period-report generation for finance.

Aggregates verified transactions in a period (`YYYY-MM`, `YYYY-Qn`, `YYYY`,
`monthly`, `quarterly`, `yearly`) by category, merchant, project, and
currency. Writes a structured markdown file to ``finance/reports/`` with
``author: agent, agent: accountant`` provenance.

This module is the single source of truth for period-report content. Both
the agent tool (``generate_finance_report``) and the HTTP route
(``POST /api/finance/reports``) call ``generate_period_report()``.

Skill-driven layout: section presence is governed by
``defaults/skills/finance/period-report/config/format.yaml``. The render
order in this module mirrors the YAML's ``sections`` block.

Backward-compat: when called without a writer, returns the rendered
markdown without persisting — useful for previews.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.finance.ledger import FinanceLedger
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)


async def generate_period_report(
    ledger: FinanceLedger,
    writer: VaultWriter | None,
    *,
    period: str = "",
    scope: str = "all",
) -> dict[str, Any]:
    """Generate a period report and (optionally) write to ``finance/reports/``.

    Returns a dict with one of:
    - ``{ok: True, period, report_path, txn_count, totals: {currency: "0.00"}}`` on success
    - ``{ok: True, period, txn_count: 0, message}`` when no transactions match
    - ``{error: "<type>: <msg>"}`` on aggregation/write failure

    ``period`` accepts ``YYYY-MM``, ``YYYY-Qn``, ``YYYY``, or the rolling
    sentinels ``monthly``/``quarterly``/``yearly``. Defaults to current
    month when empty.

    ``scope`` is ``"all"`` (default) or ``"deductible_only"``. The
    deductible filter narrows the txn list AND adds a deductible-totals
    section to the output.

    When ``writer`` is None, the markdown is rendered but not persisted.
    The return dict includes ``report_path: ""`` and ``persisted: False``.
    """
    period = (period or "").strip()
    if not period:
        period = datetime.now(UTC).strftime("%Y-%m")
    scope = (scope or "all").strip()

    try:
        from agntspace.finance.ledger import _period_includes_date

        all_txns = await ledger.list_transactions(status="verified", limit=10000)
        txns = [t for t in all_txns if _period_includes_date(period, t.txn_date)]
        if not txns:
            return {
                "ok": True,
                "period": period,
                "txn_count": 0,
                "message": f"No verified transactions found in period {period}.",
            }

        # Aggregate
        by_currency: dict[str, Decimal] = {}
        by_category: dict[str, Decimal] = {}
        by_merchant: dict[str, Decimal] = {}
        by_project: dict[str, Decimal] = {}
        deductible_total: dict[str, Decimal] = {}

        for txn in txns:
            cur = (txn.currency or "").upper() or "—"
            try:
                total = Decimal(txn.total or "0.00")
            except Exception:
                total = Decimal("0.00")
            by_currency[cur] = by_currency.get(cur, Decimal("0")) + total
            if txn.merchant_slug:
                by_merchant[txn.merchant_slug] = by_merchant.get(txn.merchant_slug, Decimal("0")) + total
            if txn.project_slug:
                by_project[txn.project_slug] = by_project.get(txn.project_slug, Decimal("0")) + total
            for item in (txn.items or ()):
                cat = item.category_slug or "(uncategorized)"
                try:
                    amt = Decimal(item.amount or "0.00")
                except Exception:
                    amt = Decimal("0.00")
                by_category[cat] = by_category.get(cat, Decimal("0")) + amt
                if item.tax_deductible:
                    deductible_total[cur] = deductible_total.get(cur, Decimal("0")) + amt

        # Deductible-only filter narrows the transaction list AFTER
        # aggregation so the deductible_total section reflects ALL
        # deductible items in the period, not just the deductible txns.
        if scope == "deductible_only":
            txns = [t for t in txns if any(item.tax_deductible for item in (t.items or ()))]

        # Render markdown
        now = datetime.now(UTC).isoformat(timespec="seconds")
        lines: list[str] = []
        lines.append("---")
        lines.append(f'title: "Spend report — {period}"')
        lines.append("author: agent")
        lines.append("agent: accountant")
        lines.append(f'date: "{now[:10]}"')
        lines.append(f'period: "{period}"')
        lines.append(f'generated_at: "{now}"')
        lines.append(f'scope: "{scope}"')
        lines.append("---")
        lines.append("")
        lines.append(f"# Spend Report — {period}")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        for cur, total in sorted(by_currency.items()):
            lines.append(f"- Total ({cur}): {total:.2f}")
        lines.append(f"- Transaction count: {len(txns)}")
        lines.append("")

        if by_category:
            lines.append("## By category")
            lines.append("")
            lines.append("| Category | Spend |")
            lines.append("|---|---|")
            for cat, amt in sorted(by_category.items(), key=lambda kv: -kv[1]):
                lines.append(f"| {cat} | {amt:.2f} |")
            lines.append("")

        if by_merchant:
            lines.append("## Top merchants")
            lines.append("")
            top = sorted(by_merchant.items(), key=lambda kv: -kv[1])[:10]
            for n, (m, amt) in enumerate(top, 1):
                lines.append(f"{n}. {m} — {amt:.2f}")
            lines.append("")

        if by_project:
            lines.append("## Project rollup")
            lines.append("")
            lines.append("| Project | Spend |")
            lines.append("|---|---|")
            for proj, amt in sorted(by_project.items(), key=lambda kv: -kv[1]):
                lines.append(f"| {proj} | {amt:.2f} |")
            lines.append("")

        if scope == "deductible_only" and deductible_total:
            lines.append("## Tax-deductible total")
            lines.append("")
            for cur, total in sorted(deductible_total.items()):
                lines.append(f"- {cur}: {total:.2f}")
            lines.append("")

        content = "\n".join(lines)
        report_path = f"finance/reports/{period}-overview.md"

        if writer is None:
            return {
                "ok": True,
                "period": period,
                "report_path": "",
                "persisted": False,
                "content": content,
                "txn_count": len(txns),
                "totals": {cur: f"{total:.2f}" for cur, total in by_currency.items()},
            }

        try:
            writer.write(
                report_path,
                content=content,
                versioned=True,
                contract_action="daily_briefing",
                trust_reason="finance_report",
            )
        except Exception as write_exc:
            log.exception("generate_period_report: writer failed")
            return {"error": f"write failed: {write_exc}"}

        return {
            "ok": True,
            "period": period,
            "report_path": report_path,
            "persisted": True,
            "txn_count": len(txns),
            "totals": {cur: f"{total:.2f}" for cur, total in by_currency.items()},
        }
    except Exception as exc:
        log.exception("generate_period_report failed")
        return {"error": f"{type(exc).__name__}: {exc}"}
