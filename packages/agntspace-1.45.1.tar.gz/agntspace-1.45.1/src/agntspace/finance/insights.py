"""Spending insights — deterministic narrative for the dashboard.

Computes "what's interesting about my finances right now" from the verified
transaction history, returning a short list of human-readable bullets the
UI surfaces in a panel. v1 is purely deterministic — no LLM. We compute
factual diffs (this period vs prior, top movers, biggest single line,
recurring detected, spending velocity) and render them with stable wording
so the user can trust them.

LLM-assisted narrative polish is a follow-up — once we have a v1 the user
finds useful, we can run the insights set through a quick LLM rewrite for
softer prose. The deterministic facts are the source of truth; LLM is icing.

Insight types:
  - top_category_change       — biggest % delta in category vs prior period
  - largest_single_expense    — biggest single txn this period
  - unattributed_alert        — verified txns missing project + category
  - spending_velocity         — at current pace, projected month-end spend
  - recurring_subscription    — single recurring charge worth surfacing
  - recurring_total           — annual total of all recurring (when N≥3)
  - quiet_project             — a known project with no spend this period
                                (sanity check — "Personal" had 0 txns)

Each insight has:
  - kind (machine ID)
  - tone (info / warn / good)
  - headline (one short sentence)
  - detail (optional — supporting numbers)
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import UTC, date, datetime
from decimal import Decimal
from typing import Any


@dataclass
class Insight:
    """One narrative bullet for the dashboard insights panel."""
    kind: str
    tone: str          # info / warn / good
    headline: str
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "tone": self.tone,
            "headline": self.headline,
            "detail": self.detail,
        }


def _parse_date(s: str) -> date | None:
    if not s:
        return None
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def _decimal(s: str | None) -> Decimal:
    try:
        return Decimal(s or "0.00")
    except Exception:
        return Decimal("0.00")


def _format_decimal(d: Decimal) -> str:
    return f"{d:.2f}"


def _format_pct_signed(pct: float) -> str:
    """Format as +N% / -N% with no decimal place."""
    sign = "+" if pct >= 0 else ""
    return f"{sign}{int(round(pct * 100))}%"


def compute_insights(
    transactions: list[Any],
    *,
    today: date | None = None,
    recurring_charges: list[Any] | None = None,
    project_slugs_known: set[str] | None = None,
) -> list[Insight]:
    """Generate the dashboard's insights bullet list.

    ``transactions`` should be ALL verified transactions (no period filter
    — we compute the period boundaries internally so we can do current-vs-
    prior month diffs). ``recurring_charges`` is the output of
    ``detect_recurring_charges`` (or empty). ``project_slugs_known`` lets
    us flag projects that exist in the user's project list but have no
    spend this period.

    Sorted by importance: warnings first, then informational. Capped at 8
    items so the panel stays scannable.
    """
    today = today or datetime.now(UTC).date()
    this_year = today.year
    this_month = today.month
    if this_month == 1:
        prior_year, prior_month = this_year - 1, 12
    else:
        prior_year, prior_month = this_year, this_month - 1

    # Pre-bucket by month for the diffs
    this_month_txns: list[Any] = []
    prior_month_txns: list[Any] = []
    for t in transactions:
        if getattr(t, "status", "") and t.status != "verified":
            continue
        d = _parse_date(getattr(t, "txn_date", "") or "")
        if not d:
            continue
        if d.year == this_year and d.month == this_month:
            this_month_txns.append(t)
        elif d.year == prior_year and d.month == prior_month:
            prior_month_txns.append(t)

    out: list[Insight] = []

    # ── Spending velocity (this month) ────────────────────────────
    # Only fires when current month has ≥1 verified txn AND we're past
    # the 3rd of the month (otherwise the projection is too noisy).
    if this_month_txns and today.day >= 3:
        days_in_month = calendar.monthrange(this_year, this_month)[1]
        elapsed = today.day
        # Sum spend per currency for this month
        by_cur: dict[str, Decimal] = {}
        for t in this_month_txns:
            cur = (t.currency or "—").upper()
            by_cur[cur] = by_cur.get(cur, Decimal("0")) + _decimal(t.total)
        # Project end-of-month for the dominant currency
        if by_cur:
            dom = max(by_cur.items(), key=lambda kv: kv[1])
            projected = dom[1] * Decimal(days_in_month) / Decimal(elapsed)
            out.append(Insight(
                kind="spending_velocity",
                tone="info",
                headline=(
                    f"At current pace, you'll spend ~{_format_decimal(projected)} "
                    f"{dom[0]} this month (currently {_format_decimal(dom[1])} "
                    f"after {elapsed} day{'s' if elapsed != 1 else ''})."
                ),
            ))

    # ── Top category change vs prior month ────────────────────────
    cat_now: dict[str, Decimal] = {}
    cat_prior: dict[str, Decimal] = {}
    for t in this_month_txns:
        for item in (t.items or ()):
            cat = item.category_slug or "(uncategorized)"
            cat_now[cat] = cat_now.get(cat, Decimal("0")) + _decimal(item.amount)
    for t in prior_month_txns:
        for item in (t.items or ()):
            cat = item.category_slug or "(uncategorized)"
            cat_prior[cat] = cat_prior.get(cat, Decimal("0")) + _decimal(item.amount)
    # Find biggest absolute delta (not %, to avoid "from $0 → $5 = +infinity")
    biggest_change: tuple[str, Decimal, Decimal] | None = None
    for cat, now_amt in cat_now.items():
        prior_amt = cat_prior.get(cat, Decimal("0"))
        delta = now_amt - prior_amt
        if biggest_change is None or abs(delta) > abs(biggest_change[2]):
            biggest_change = (cat, now_amt, delta)
    if biggest_change is not None and biggest_change[2] != 0:
        cat, now_amt, delta = biggest_change
        prior_amt = cat_prior.get(cat, Decimal("0"))
        if prior_amt > 0:
            pct = float((now_amt - prior_amt) / prior_amt)
            pct_label = _format_pct_signed(pct)
        else:
            pct_label = "new this month"
        tone = "warn" if delta > 0 else "good"
        direction = "up" if delta > 0 else "down"
        out.append(Insight(
            kind="top_category_change",
            tone=tone,
            headline=(
                f"'{cat}' is {direction} {pct_label} "
                f"({_format_decimal(now_amt)} this month vs "
                f"{_format_decimal(prior_amt)} last)"
            ),
        ))

    # ── Largest single expense this period ────────────────────────
    if this_month_txns:
        largest = max(this_month_txns, key=lambda t: _decimal(t.total))
        amount = _decimal(largest.total)
        if amount > Decimal("0"):
            out.append(Insight(
                kind="largest_single_expense",
                tone="info",
                headline=(
                    f"Biggest single expense this month: {largest.merchant_slug} "
                    f"({_format_decimal(amount)} {largest.currency or '—'}, "
                    f"{largest.txn_date})"
                ),
            ))

    # ── Unattributed verified transactions (item OR txn level) ────
    unattr_count = 0
    for t in transactions:
        if getattr(t, "status", "") and t.status != "verified":
            continue
        has_txn_proj = bool(t.project_slug)
        has_item_proj = any(getattr(it, "project_slug", None) for it in (t.items or ()))
        has_cat = any(it.category_slug for it in (t.items or ()))
        if not has_txn_proj and not has_item_proj and not has_cat:
            unattr_count += 1
    if unattr_count > 0:
        out.append(Insight(
            kind="unattributed_alert",
            tone="warn",
            headline=(
                f"{unattr_count} verified transaction"
                f"{'s' if unattr_count != 1 else ''} need a project or category."
            ),
        ))

    # ── Recurring subscriptions ───────────────────────────────────
    if recurring_charges:
        # Top recurring by annual cost
        top = recurring_charges[0]
        annual = top.estimated_annual_cost if hasattr(top, "estimated_annual_cost") else top["estimated_annual_cost"]
        merchant = top.merchant_slug if hasattr(top, "merchant_slug") else top["merchant_slug"]
        frequency = top.frequency if hasattr(top, "frequency") else top["frequency"]
        avg = top.average_amount if hasattr(top, "average_amount") else top["average_amount"]
        cur = top.currency if hasattr(top, "currency") else top["currency"]
        out.append(Insight(
            kind="recurring_subscription",
            tone="info",
            headline=(
                f"Recurring charge detected: {merchant} ({frequency}, "
                f"~{avg} {cur} each). Estimated {annual} {cur}/year."
            ),
        ))
        # Total annual recurring cost when there are several
        if len(recurring_charges) >= 3:
            totals_by_cur: dict[str, Decimal] = {}
            for r in recurring_charges:
                cur = r.currency if hasattr(r, "currency") else r["currency"]
                annual_amt = r.estimated_annual_cost if hasattr(r, "estimated_annual_cost") else r["estimated_annual_cost"]
                try:
                    totals_by_cur[cur] = totals_by_cur.get(cur, Decimal("0")) + Decimal(annual_amt)
                except Exception:
                    continue
            top_cur, top_total = max(totals_by_cur.items(), key=lambda kv: kv[1])
            out.append(Insight(
                kind="recurring_total",
                tone="info",
                headline=(
                    f"{len(recurring_charges)} recurring charges total "
                    f"~{_format_decimal(top_total)} {top_cur}/year."
                ),
            ))

    # ── Quiet project (project with no spend this period) ─────────
    # Only fires when the user has known projects (passed in) AND there's
    # at least 1 active project this month — quiet baseline gives signal.
    if project_slugs_known and this_month_txns:
        active_this_month: set[str] = set()
        for t in this_month_txns:
            if t.project_slug:
                active_this_month.add(t.project_slug)
            for item in (t.items or ()):
                if getattr(item, "project_slug", None):
                    active_this_month.add(item.project_slug)
        # Projects active in prior month but not this one
        active_prior: set[str] = set()
        for t in prior_month_txns:
            if t.project_slug:
                active_prior.add(t.project_slug)
            for item in (t.items or ()):
                if getattr(item, "project_slug", None):
                    active_prior.add(item.project_slug)
        gone_quiet = active_prior - active_this_month
        # Restrict to known projects (no noise from one-off slugs)
        gone_quiet = gone_quiet & project_slugs_known
        for slug in sorted(gone_quiet):
            out.append(Insight(
                kind="quiet_project",
                tone="info",
                headline=f"No verified spend in '{slug}' this month (had spend last month).",
            ))
            if len(out) >= 8:
                break

    # Cap at 8. Ordering: warns first, then info, then good.
    tone_rank = {"warn": 0, "good": 1, "info": 2}
    out.sort(key=lambda i: tone_rank.get(i.tone, 3))
    return out[:8]
