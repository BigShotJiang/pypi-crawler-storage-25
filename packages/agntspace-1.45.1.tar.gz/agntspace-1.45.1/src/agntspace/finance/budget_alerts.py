"""Budget threshold alerting.

Phase 2 declared the thresholds + cooldowns in
[budget-track/config/thresholds.yaml] but never wired the loop that fires
proactive alerts when a budget transitions UP a threshold. This module
closes that gap.

Trigger model — *transitions UP only*. A budget at 78% that crosses to
82% (on_track → near_cap) fires once. Hovering at 81% does NOT re-fire
because the band hasn't changed. A refund moving the budget back from
105% to 95% (at_cap → near_cap) is silent — the user already saw the
threshold cross UP, and noise from refund alerts is the failure mode this
design specifically avoids.

Cooldown — per-budget. Once a transition fires, the same budget cannot
fire again for ``alert_cooldown_hours`` (default 24). This protects
against rapid back-and-forth on a budget hovering near a threshold.

Engine vs strategy split (Rule 12):
    - The thresholds, cooldowns, importances live in YAML.
    - This Python file is the engine that reads them, computes
      per-budget bands from ``consumed / amount``, detects upward
      transitions against the in-memory baseline, and emits activity
      events. Adding/renaming a band is a YAML edit only.

State — in-memory only. Restarting the server resets the baseline; the
first scan after restart establishes a new baseline and emits no
alerts. This is intentional: a persistent baseline would carry
stale state across LLM model swaps, vault moves, etc. The cost of
re-baselining is one quiet cycle per restart.

This is engine substrate (Rule 12), not strategy. Threshold tuning lives
in [budget-track/config/thresholds.yaml]. Service is wired into the
heartbeat in main.py; first-call baselines silently, subsequent calls
fire on transitions UP.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.activity.logger import ActivityLogger
    from agntspace.finance.ledger import FinanceLedger
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────
# Pure functions (testable without a service)
# ────────────────────────────────────────────────────────────────────
def classify_budget_band(
    percent_consumed: float, thresholds: dict[str, Any],
) -> tuple[str, dict[str, Any]]:
    """Return ``(band_name, band_config)`` for ``percent_consumed`` (0.0+).

    ``thresholds`` is the dict from ``thresholds.yaml`` whose keys are
    band names declared in ascending order (on_track → near_cap → ...).
    Each value carries ``min_pct`` (inclusive), ``max_pct`` (exclusive),
    plus ``alert`` / ``importance`` / ``label``.

    Falls through to the LAST declared band when ``percent_consumed``
    exceeds every range (deliberate: "100x over budget" should still
    classify as the most-severe band, not as None).

    Returns ``("unknown", {})`` when ``thresholds`` is empty — caller
    should treat this as a config error and skip the alert.
    """
    if not thresholds:
        return ("unknown", {})
    last_name = ""
    last_cfg: dict[str, Any] = {}
    for name, cfg in thresholds.items():
        if not isinstance(cfg, dict):
            continue
        last_name, last_cfg = name, cfg
        try:
            min_pct = float(cfg.get("min_pct", 0.0))
            max_pct = float(cfg.get("max_pct", 1.0))
        except (TypeError, ValueError):
            continue
        if min_pct <= percent_consumed < max_pct:
            return (name, cfg)
    # Fell off the top — return the last (most-severe) declared band.
    return (last_name, last_cfg) if last_name else ("unknown", {})


def is_transition_up(
    prev_band: str, current_band: str, thresholds: dict[str, Any],
) -> bool:
    """Return True iff ``current_band`` ranks higher than ``prev_band``.

    Rank is YAML-declared order (Python dicts preserve insertion order).
    Different thresholds → different ranks; same band → False; lower
    band (refund moved budget down) → False.
    """
    if not thresholds or prev_band == current_band:
        return False
    keys = list(thresholds.keys())
    try:
        prev_rank = keys.index(prev_band)
    except ValueError:
        return False  # unknown previous band — can't compare
    try:
        cur_rank = keys.index(current_band)
    except ValueError:
        return False
    return cur_rank > prev_rank


# ────────────────────────────────────────────────────────────────────
# Service
# ────────────────────────────────────────────────────────────────────
class BudgetAlerter:
    """Heartbeat-driven budget threshold alerting.

    Consumed by [automation/heartbeat.py] roughly once per tick. Service
    holds the in-memory baseline state — a fresh instance starts silent
    and fires alerts only on observed transitions.
    """

    def __init__(
        self,
        *,
        ledger: FinanceLedger,
        skill_loader: SkillLoader | None,
        activity_logger: ActivityLogger | None = None,
    ) -> None:
        self._ledger = ledger
        self._skills = skill_loader
        self._activity = activity_logger
        # Last-observed band per budget_id. None entry = never seen yet
        # (first scan establishes baseline silently).
        self._last_band: dict[str, str] = {}
        # Last alert timestamp per budget_id — feeds the cooldown gate.
        self._last_alert_at: dict[str, datetime] = {}
        # Lifetime stats (observability — can be surfaced via /api).
        self._scan_count = 0
        self._alerts_fired = 0

    def _load_config(self) -> dict[str, Any]:
        """Load ``thresholds.yaml`` from the budget-track skill.

        Returns the parsed dict or ``{}`` on any error. Skill loader
        + YAML reader both never raise per their contracts; the catch-all
        here is a defense against future refactors.
        """
        if self._skills is None:
            return {}
        try:
            cfg = self._skills.load_skill_config_file(
                "budget-track", "thresholds.yaml",
            )
        except Exception:
            return {}
        return cfg if isinstance(cfg, dict) else {}

    async def scan(self) -> dict[str, Any]:
        """One pass over all budgets. Fires alerts on transitions UP.

        Returns a dict with ``scanned`` (budget count), ``alerts`` (events
        fired this pass), and ``reason`` when nothing was scanned.
        Never raises — caller (heartbeat) doesn't have to wrap this.
        """
        self._scan_count += 1
        cfg = self._load_config()
        thresholds = cfg.get("thresholds") or {}
        cooldown_hours = float(cfg.get("alert_cooldown_hours", 24))
        if not thresholds:
            return {"scanned": 0, "alerts": 0, "reason": "no_thresholds_yaml"}

        try:
            budgets = await self._ledger.list_budgets()
        except Exception:
            log.debug("BudgetAlerter: list_budgets failed", exc_info=True)
            return {"scanned": 0, "alerts": 0, "reason": "ledger_error"}

        alerts_this_pass = 0
        now = datetime.now(UTC)
        for budget in budgets:
            try:
                amount = float(budget.amount or "0")
            except (TypeError, ValueError):
                continue
            if amount <= 0:
                continue  # nonsensical budget — skip
            try:
                consumption = await self._ledger.get_budget_consumption(
                    budget.budget_id,
                )
            except Exception:
                log.debug(
                    "BudgetAlerter: get_budget_consumption failed for %s",
                    budget.budget_id, exc_info=True,
                )
                continue
            try:
                spent = float(consumption.get("spent", "0") or "0")
            except (TypeError, ValueError):
                spent = 0.0
            pct = spent / amount

            band_name, band_cfg = classify_budget_band(pct, thresholds)
            if band_name == "unknown":
                continue

            prev_band = self._last_band.get(budget.budget_id)
            # Update baseline FIRST so subsequent calls see the latest band
            self._last_band[budget.budget_id] = band_name

            # First scan for this budget → establish baseline silently
            if prev_band is None:
                continue

            # Only transitions UP fire — refunds moving down are silent
            if not is_transition_up(prev_band, band_name, thresholds):
                continue

            # YAML can disable alerting per-band (e.g. on_track has alert: false)
            if not bool(band_cfg.get("alert", False)):
                continue

            # Cooldown — per budget, regardless of which band
            last_alert = self._last_alert_at.get(budget.budget_id)
            if last_alert is not None:
                elapsed_hours = (now - last_alert).total_seconds() / 3600
                if elapsed_hours < cooldown_hours:
                    continue

            # Fire. Cooldown + counters update inside the emit so a
            # broken activity logger still updates the cooldown — we
            # don't want to spam-retry on transient failures.
            self._last_alert_at[budget.budget_id] = now
            alerts_this_pass += 1
            self._alerts_fired += 1
            self._emit_alert(
                budget=budget,
                band_name=band_name,
                band_cfg=band_cfg,
                pct=pct,
                spent=spent,
                prev_band=prev_band,
            )

        return {
            "scanned": len(budgets),
            "alerts": alerts_this_pass,
            "lifetime_alerts": self._alerts_fired,
            "lifetime_scans": self._scan_count,
        }

    def _emit_alert(
        self,
        *,
        budget: Any,
        band_name: str,
        band_cfg: dict[str, Any],
        pct: float,
        spent: float,
        prev_band: str,
    ) -> None:
        """Emit the activity event. No-op when logger isn't wired."""
        if self._activity is None:
            return
        importance = str(band_cfg.get("importance", "medium")).lower()
        if importance not in ("low", "medium", "high"):
            importance = "medium"
        label = band_cfg.get("label", band_name)
        scope_label = self._scope_label(budget)
        summary = (
            f"Budget {scope_label} crossed UP into '{label}' "
            f"({pct * 100:.0f}% consumed, {prev_band} → {band_name})"
        )
        try:
            self._activity.log(
                category="user",
                action="budget_threshold_crossed",
                summary=summary,
                details={
                    "budget_id": budget.budget_id,
                    "period": getattr(budget, "period", ""),
                    "scope_type": getattr(budget, "scope_type", ""),
                    "scope_slug": getattr(budget, "scope_slug", ""),
                    "category_slug": getattr(budget, "category_slug", ""),
                    "amount": getattr(budget, "amount", ""),
                    "currency": getattr(budget, "currency", ""),
                    "spent": f"{spent:.2f}",
                    "percent_consumed": round(pct, 4),
                    "prev_band": prev_band,
                    "band": band_name,
                    "label": label,
                    "via": "heartbeat",
                },
                importance=importance,
            )
        except Exception:
            log.debug("BudgetAlerter: activity emit failed", exc_info=True)

    @staticmethod
    def _scope_label(budget: Any) -> str:
        """Human-readable budget identity for the activity summary."""
        scope_type = getattr(budget, "scope_type", "") or "global"
        category = getattr(budget, "category_slug", "") or ""
        scope_slug = getattr(budget, "scope_slug", "") or ""
        period = getattr(budget, "period", "") or ""
        bits: list[str] = []
        if scope_type == "project" and scope_slug:
            bits.append(f"project={scope_slug}")
        elif scope_type == "category" and category or category:
            bits.append(f"category={category}")
        else:
            bits.append("global")
        if period:
            bits.append(period)
        return " · ".join(bits)

    def get_status(self) -> dict[str, Any]:
        """Expose lifetime + baseline state for ``/api/finance/budget-alerts``
        when (if) a route surfaces it. Pure read."""
        return {
            "tracked_budgets": len(self._last_band),
            "lifetime_scans": self._scan_count,
            "lifetime_alerts": self._alerts_fired,
        }


__all__ = [
    "BudgetAlerter",
    "classify_budget_band",
    "is_transition_up",
]
