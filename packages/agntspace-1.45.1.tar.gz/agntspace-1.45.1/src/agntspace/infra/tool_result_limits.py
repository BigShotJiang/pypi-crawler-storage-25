"""Truncate oversized tool results before they enter the LLM context.

The single function ``prepare_tool_result_for_llm`` is the canonical way
to construct the ``content`` string of an ``LLMMessage(role="tool", ...)``
or any user-message that quotes a tool result.

Behaviour:

  * **Small payloads pass through unchanged**. JSON-serialize the result;
    if it's under the inline budget, return it as-is.

  * **Oversized payloads** get the full payload stashed in the
    ``ToolResultStore`` and replaced with a structured placeholder:

    .. code-block:: json

        {
          "_truncated": true,
          "_handle": "tr-abc123",
          "_preview": "first 600 chars of the original result...",
          "_full_size_bytes": 51234,
          "_tool_name": "research_scrape",
          "_hint": "Call get_tool_result with handle_id='tr-abc123' to fetch the full payload."
        }

    The LLM sees the preview + hint and can decide whether the full result
    is worth fetching. For most tool calls (search results, deep-memory
    recall) the preview is enough.

  * **Non-serializable** results pass through ``json.dumps(default=str)``
    so dataclasses, datetimes, and Path objects don't crash the path.

This module is engine substrate (Rule 12). All thresholds live in
``defaults/skills/_meta/tool-result-limits/config/limits.yaml`` and are
loaded into ``ToolResultLimitsConfig`` at runtime.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Final

from agntspace.infra.tool_result_store import ToolResultStore

log = logging.getLogger(__name__)

# arch:deterministic — conservative defaults so a fresh install never
# shoots itself in the foot. ``max_bytes_inline`` is the tightest budget
# that still admits typical structured tool replies (~4-6KB) without
# truncation; tools that legitimately return larger payloads (search
# scrapes, deep-recall results) get truncated and stored.
_DEFAULT_MAX_BYTES_INLINE: Final[int] = 8 * 1024  # 8 KB
_DEFAULT_PREVIEW_CHARS: Final[int] = 600
_DEFAULT_ENABLED: Final[bool] = True


@dataclass(frozen=True)
class ToolResultLimitsConfig:
    """Knobs that govern truncation behaviour.

    Loaded from YAML at startup; defaults baked in so callers can ship
    without configuring anything.
    """

    enabled: bool = _DEFAULT_ENABLED
    max_bytes_inline: int = _DEFAULT_MAX_BYTES_INLINE
    preview_chars: int = _DEFAULT_PREVIEW_CHARS

    @classmethod
    def from_yaml_block(cls, block: Any) -> ToolResultLimitsConfig:
        """Parse a YAML config block into a config object.

        Robust to missing / malformed input — every field falls back to
        its deterministic default when the value is missing or wrong-typed.
        """
        if not isinstance(block, dict):
            return cls()
        try:
            enabled = bool(block.get("enabled", _DEFAULT_ENABLED))
        except Exception:  # noqa: BLE001
            enabled = _DEFAULT_ENABLED
        try:
            max_inline = int(block.get("max_bytes_inline", _DEFAULT_MAX_BYTES_INLINE))
            if max_inline < 256:
                max_inline = 256  # absurd-tightness floor
        except (TypeError, ValueError):
            max_inline = _DEFAULT_MAX_BYTES_INLINE
        try:
            preview = int(block.get("preview_chars", _DEFAULT_PREVIEW_CHARS))
            if preview < 0:
                preview = 0
        except (TypeError, ValueError):
            preview = _DEFAULT_PREVIEW_CHARS
        return cls(
            enabled=enabled,
            max_bytes_inline=max_inline,
            preview_chars=preview,
        )


def _serialize(result: Any) -> str:
    """Best-effort JSON-serialize ``result``. Never raises.

    Falls back to ``default=str`` for non-JSON-native types (datetimes,
    Path, dataclasses without __dict__). If even that fails, falls through
    to ``repr(result)``.
    """
    try:
        return json.dumps(result)
    except (TypeError, ValueError):
        try:
            return json.dumps(result, default=str)
        except Exception:  # noqa: BLE001
            return json.dumps({"_unserializable": repr(result)[:1000]})


def _utf8_size(payload: str) -> int:
    return len(payload.encode("utf-8", errors="replace"))


def prepare_tool_result_for_llm(
    result: Any,
    *,
    tool_name: str = "",
    store: ToolResultStore | None = None,
    config: ToolResultLimitsConfig | None = None,
) -> str:
    """Return a JSON string suitable for ``LLMMessage(content=...)``.

    Args:
        result: Raw tool return value. Will be JSON-serialized.
        tool_name: Tool that produced the result. Captured in the
            placeholder for diagnostics + retrieval. Empty string OK.
        store: Storage backing for full payloads when truncation fires.
            When ``None``, falls back to the process-wide default via
            ``get_default_store()``. Pass a custom store in tests.
        config: Limits config. When ``None``, uses the deterministic
            defaults (8 KB inline, 600-char preview, enabled).

    Returns:
        A JSON string, never raises. Either the original payload (when
        small) or a structured placeholder JSON with handle id (when
        truncated).
    """
    cfg = config or ToolResultLimitsConfig()
    serialized = _serialize(result)

    # Kill switch: when disabled, pass through unchanged. Useful for tests
    # that need to see raw payloads.
    if not cfg.enabled:
        return serialized

    size = _utf8_size(serialized)
    if size <= cfg.max_bytes_inline:
        return serialized

    # Truncation path. Stash the full payload + return a placeholder.
    if store is None:
        from agntspace.infra.tool_result_store import get_default_store
        store = get_default_store()

    try:
        handle = store.store(serialized, tool_name=tool_name or "")
    except Exception as exc:  # noqa: BLE001
        # Store failure must NEVER break the chat path. Fall back to a
        # naive truncation with a no-handle placeholder so the LLM still
        # has SOMETHING to work with.
        log.warning(
            "ToolResultStore.store failed for tool=%s size=%dB: %s",
            tool_name, size, exc,
        )
        truncated_text = serialized[: cfg.preview_chars]
        return json.dumps({
            "_truncated": True,
            "_handle": "",
            "_preview": truncated_text,
            "_full_size_bytes": size,
            "_tool_name": tool_name or "",
            "_hint": (
                "Storage unavailable; full payload not retrievable. "
                "Re-run the tool if the preview is insufficient."
            ),
        })

    # Build the structured placeholder. Keys are underscore-prefixed so
    # they don't collide with anything a real tool might return at the
    # top level.
    preview_chars = max(0, cfg.preview_chars)
    preview_text = serialized[:preview_chars]
    placeholder = {
        "_truncated": True,
        "_handle": handle,
        "_preview": preview_text,
        "_full_size_bytes": size,
        "_tool_name": tool_name or "",
        "_hint": (
            f"Result truncated ({size} bytes). Call get_tool_result with "
            f"handle_id={handle!r} to fetch the full payload."
        ),
    }
    return json.dumps(placeholder)
