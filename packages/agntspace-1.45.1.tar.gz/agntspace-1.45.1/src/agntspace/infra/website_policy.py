"""Robots.txt enforcement for outbound scrape paths.

Fetches and caches ``/robots.txt`` per host, evaluates whether a given URL
would be permitted under the host's robots policy for our user agent, and
returns a structured allow/deny verdict.

Design choices:

  * **Fail open by default** when the robots.txt fetch itself fails (network
    error, 5xx, timeout). The alternative — refusing to scrape any host that
    momentarily can't serve robots — would block legitimate crawls on
    transient blips. Failure is logged and counted but not enforced.

  * **Explicit Disallow > implicit allow**. We use the stdlib's
    ``urllib.robotparser`` which already implements the standard
    most-specific-match semantics.

  * **Per-host TTL cache** keyed on ``(scheme, hostname, port)``. Cached
    entries are checked under a lock so two concurrent callers fetching
    the same host don't both hit the network.

  * **Pure stdlib**. No httpx dependency — robots.txt is small, the fetch
    is rare (cache hit ratio ~99% in practice), and we can use
    ``urllib.request`` which is already in scope. The 10-second timeout is
    short enough that a hung host won't stall the scrape pipeline for long.

This module is engine substrate (Rule 12). The user-tunable knobs (TTL,
user-agent string, fail-open toggle) live in
``defaults/skills/_meta/url-safety/config/safety.yaml``.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Final
from urllib.error import URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen
from urllib.robotparser import RobotFileParser

log = logging.getLogger(__name__)

# arch:deterministic — short timeout so a hung robots fetch can never block
# the scrape pipeline for long. Real robots.txt files are tiny (<10KB
# typically) and served over fast CDNs; 10s is generous.
_ROBOTS_FETCH_TIMEOUT_SECONDS: Final[float] = 10.0

# arch:deterministic — robots.txt usually changes once a year if ever. 24h
# cache is a reasonable balance between freshness and traffic to the host.
_DEFAULT_CACHE_TTL_SECONDS: Final[float] = 24 * 60 * 60

# arch:deterministic — agntspace identifies itself honestly. RFC 9309 says
# user agents should send a unique product token. ``research-scraper`` makes
# the purpose obvious to a site operator reading their access logs.
_DEFAULT_USER_AGENT: Final[str] = "agntspace-research-scraper"


@dataclass(frozen=True)
class RobotsVerdict:
    """Outcome of a robots.txt permission check.

    Attributes:
        allowed: True iff the URL is permitted under the host's robots
            policy for our user agent. ``True`` is also returned when the
            policy could not be loaded AND ``fail_open`` is enabled.
        reason: Stable code. One of: ``allowed`` (explicit allow or
            unrestricted host), ``disallowed`` (explicit Disallow match),
            ``failed_open`` (robots fetch failed, fail-open active),
            ``failed_closed`` (robots fetch failed, fail-open disabled),
            ``invalid_url`` (URL couldn't be parsed for robots-base derivation).
        url: The URL that was checked.
        user_agent: User agent string used for the policy lookup.
        detail: Human-readable elaboration. Never authoritative — ``reason``
            is the canonical code.
    """

    allowed: bool
    reason: str
    url: str
    user_agent: str
    detail: str = ""


@dataclass
class _CacheEntry:
    """Internal cache slot for a single host's robots policy.

    ``parser`` may be None when fetch failed; ``fetch_ok`` records whether
    the most recent attempt succeeded so callers can tell "no robots policy
    cached" from "policy known to be empty".
    """

    parser: RobotFileParser | None
    fetched_at: float
    fetch_ok: bool


class WebsitePolicy:
    """Cached robots.txt evaluator.

    Thread-safe. One instance per process is enough — cache state is
    in-memory, server-restart resets it, and that's fine because a fresh
    fetch is cheap relative to a blocked-by-stale-cache false negative.

    Args:
        user_agent: Token sent in the ``User-agent:`` request header AND
            used when matching against the host's robots.txt rules.
        cache_ttl_seconds: How long a cached policy stays valid before the
            next request triggers a re-fetch.
        fail_open: When True (default), a failed robots.txt fetch results
            in ``RobotsVerdict.allowed = True`` with reason ``failed_open``.
            When False, the verdict is ``allowed = False`` with reason
            ``failed_closed``. Toggle in YAML for paranoid setups.
    """

    def __init__(
        self,
        *,
        user_agent: str = _DEFAULT_USER_AGENT,
        cache_ttl_seconds: float = _DEFAULT_CACHE_TTL_SECONDS,
        fail_open: bool = True,
    ) -> None:
        self._user_agent = user_agent or _DEFAULT_USER_AGENT
        self._cache_ttl = max(60.0, float(cache_ttl_seconds))
        self._fail_open = bool(fail_open)
        self._cache: dict[str, _CacheEntry] = {}
        self._lock = threading.RLock()
        # Per-host fetch locks: when two callers ask about the same host
        # simultaneously, only one should hit the network. Reentrant so
        # check_url can safely consult cache under both the global and
        # per-host lock.
        self._host_locks: dict[str, threading.Lock] = {}

    @property
    def user_agent(self) -> str:
        return self._user_agent

    def _host_key(self, scheme: str, host: str, port: int | None) -> str:
        suffix = f":{port}" if port else ""
        return f"{scheme}://{host}{suffix}"

    def _get_host_lock(self, key: str) -> threading.Lock:
        with self._lock:
            lock = self._host_locks.get(key)
            if lock is None:
                lock = threading.Lock()
                self._host_locks[key] = lock
            return lock

    def _cache_lookup(self, key: str) -> _CacheEntry | None:
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            if (time.monotonic() - entry.fetched_at) > self._cache_ttl:
                # Stale; drop and let caller refresh.
                del self._cache[key]
                return None
            return entry

    def _cache_store(self, key: str, entry: _CacheEntry) -> None:
        with self._lock:
            self._cache[key] = entry

    def _fetch_robots(self, robots_url: str) -> tuple[RobotFileParser | None, bool]:
        """Fetch and parse robots.txt. Returns (parser, fetch_ok).

        ``fetch_ok`` is False on any error (network, HTTP non-2xx, parse
        failure). The returned parser may still be a usable empty-policy
        on a clean 404 because some sites return 404 for robots.txt and we
        treat that as "no restrictions".
        """
        try:
            req = Request(
                robots_url,
                headers={"User-Agent": self._user_agent},
            )
            with urlopen(req, timeout=_ROBOTS_FETCH_TIMEOUT_SECONDS) as resp:
                status = getattr(resp, "status", 200)
                if status == 404:
                    # No robots.txt is a clean "anything goes" signal.
                    parser = RobotFileParser()
                    parser.parse([])
                    return parser, True
                if 400 <= status < 600:
                    log.debug(
                        "robots fetch returned HTTP %s for %s — treating as fetch failure",
                        status, robots_url,
                    )
                    return None, False
                content = resp.read().decode("utf-8", errors="replace")
        except URLError as exc:
            log.debug("robots fetch URLError for %s: %s", robots_url, exc)
            return None, False
        except (OSError, TimeoutError) as exc:
            log.debug("robots fetch I/O error for %s: %s", robots_url, exc)
            return None, False
        except Exception as exc:  # noqa: BLE001 — robots fetch must never raise to caller
            log.warning("robots fetch unexpected error for %s: %s", robots_url, exc)
            return None, False

        try:
            parser = RobotFileParser()
            parser.parse(content.splitlines())
            return parser, True
        except Exception as exc:  # noqa: BLE001 — malformed robots.txt
            log.debug("robots parse failed for %s: %s", robots_url, exc)
            return None, False

    def check_url(self, url: str) -> RobotsVerdict:
        """Evaluate ``url`` against its host's robots policy.

        Pure I/O wrapper around the cache. Safe to call from any thread.
        Cooperative blocking under a per-host lock during fetch — concurrent
        callers asking about the same host serialize on one fetch.
        """
        if not isinstance(url, str) or not url.strip():
            return RobotsVerdict(
                self._fail_open, "invalid_url", url or "",
                self._user_agent, "URL is empty.",
            )

        try:
            parts = urlsplit(url.strip())
        except ValueError as exc:
            return RobotsVerdict(
                self._fail_open, "invalid_url", url,
                self._user_agent, f"URL parse error: {exc}",
            )

        scheme = (parts.scheme or "").lower()
        host = (parts.hostname or "").strip()
        if not scheme or not host:
            return RobotsVerdict(
                self._fail_open, "invalid_url", url,
                self._user_agent, "URL missing scheme or hostname.",
            )
        if scheme not in {"http", "https"}:
            # Non-HTTP schemes don't have robots.txt; this layer is fail-open
            # because url_safety should have rejected them earlier. We
            # answer "allowed" so we don't mask the real safety verdict.
            return RobotsVerdict(
                True, "allowed", url, self._user_agent,
                f"Scheme '{scheme}' has no robots.txt concept.",
            )

        port = parts.port
        key = self._host_key(scheme, host, port)
        entry = self._cache_lookup(key)
        if entry is None:
            host_lock = self._get_host_lock(key)
            with host_lock:
                # Re-check under per-host lock — another caller may have
                # populated the cache while we were waiting.
                entry = self._cache_lookup(key)
                if entry is None:
                    netloc = host if port is None else f"{host}:{port}"
                    robots_url = urlunsplit((scheme, netloc, "/robots.txt", "", ""))
                    parser, fetch_ok = self._fetch_robots(robots_url)
                    entry = _CacheEntry(
                        parser=parser,
                        fetched_at=time.monotonic(),
                        fetch_ok=fetch_ok,
                    )
                    self._cache_store(key, entry)

        if not entry.fetch_ok or entry.parser is None:
            reason = "failed_open" if self._fail_open else "failed_closed"
            return RobotsVerdict(
                self._fail_open, reason, url, self._user_agent,
                f"robots.txt fetch failed for {host}; "
                f"{'allowing under fail-open' if self._fail_open else 'refusing under fail-closed'}.",
            )

        try:
            allowed = entry.parser.can_fetch(self._user_agent, url)
        except Exception as exc:  # noqa: BLE001
            log.debug("robots parser raised on can_fetch for %s: %s", url, exc)
            reason = "failed_open" if self._fail_open else "failed_closed"
            return RobotsVerdict(
                self._fail_open, reason, url, self._user_agent,
                f"robots parser error: {exc}",
            )

        if allowed:
            return RobotsVerdict(True, "allowed", url, self._user_agent)
        return RobotsVerdict(
            False, "disallowed", url, self._user_agent,
            f"Disallowed by robots.txt for user-agent '{self._user_agent}'.",
        )

    def invalidate_host(self, scheme: str, host: str, port: int | None = None) -> None:
        """Drop the cached policy for one host. Useful for tests + admin actions."""
        key = self._host_key(scheme, host, port)
        with self._lock:
            self._cache.pop(key, None)

    def clear_cache(self) -> None:
        """Drop every cached policy. Useful for tests."""
        with self._lock:
            self._cache.clear()


# Process-wide singleton, lazily constructed via ``get_default_policy()``.
# Keeping it module-level lets the scrape entry points share one cache
# without threading an instance through every constructor.
_default_policy: WebsitePolicy | None = None
_default_lock = threading.Lock()


def get_default_policy() -> WebsitePolicy:
    """Return the process-wide default WebsitePolicy.

    Constructed lazily with the deterministic defaults. To configure with
    YAML-driven overrides, call ``set_default_policy()`` from the lifespan
    startup hook AFTER the skill loader is wired.
    """
    global _default_policy
    with _default_lock:
        if _default_policy is None:
            _default_policy = WebsitePolicy()
        return _default_policy


def set_default_policy(policy: WebsitePolicy) -> None:
    """Replace the process-wide default WebsitePolicy.

    Call from main.py during lifespan startup once skill config is
    available. Idempotent: subsequent calls replace the prior instance.
    """
    global _default_policy
    with _default_lock:
        _default_policy = policy
