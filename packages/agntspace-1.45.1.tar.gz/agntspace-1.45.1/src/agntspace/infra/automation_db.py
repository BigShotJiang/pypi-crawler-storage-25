"""Separate SQLite file for the WorkQueue.

Shipped 2026-04-30 as the second pass after the audit.db split. The
work_queue table — every job pending/running/completed/failed/dead-letter
— used to live in ``agntspace.db`` alongside conversations, dispatch_log,
canvas_items, vault_fts, FTS index updates, scope_file_writes, regression
tests and several other tables. SQLite WAL allows concurrent readers but
ONLY ONE writer per file at a time. On heavy vaults the KB compile +
entity_registry + graph saves were holding the write lock long enough that
work_queue UPDATEs timed out at the 30 s busy_timeout, and the queue
silently stopped firing jobs.

The fix: give WorkQueue its OWN file at ``<vault>/agntspace/automation.db``.
Sibling SQLite files have independent writer locks. KB pipeline contention
on agntspace.db cannot starve work_queue UPDATEs anymore.

Mirrors the audit.db split exactly — same PRAGMAs, same WAL checkpoint
discipline, same idempotent INSERT OR IGNORE keyed on the original id.
After the first successful migration every subsequent boot is a fast
no-op because the destination already has every row.
"""

from __future__ import annotations

import logging
from pathlib import Path

import aiosqlite

log = logging.getLogger(__name__)


async def get_automation_db(automation_path: Path) -> aiosqlite.Connection:
    """Open the automation.db connection with the same PRAGMAs as audit.db.

    Mirrors ``infra.decisions_db.get_decisions_db`` — symmetric configuration
    is load-bearing across the split (lesson from 2026-04-29 morning).
    Includes the WAL auto-checkpoint at 200 pages (~800 KB) and a one-time
    TRUNCATE checkpoint at open to flush any pre-existing WAL accumulation.
    """
    automation_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(automation_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA busy_timeout=30000")
    await db.execute("PRAGMA synchronous=NORMAL")
    await db.execute("PRAGMA wal_autocheckpoint=200")
    try:
        await db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        log.debug("automation.db wal_checkpoint failed (non-fatal)", exc_info=True)
    await db.commit()
    return db


# Columns expected on work_queue rows after every migration in WorkQueue
# init_schema has been applied. Used by the migration helper to build the
# INSERT statement against the destination. Mirrors the schema in
# automation/work_queue.py:init_schema.
_WORK_QUEUE_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "job_type",
    "payload",
    "status",
    "attempts",
    "max_attempts",
    "next_retry",
    "created_at",
    "updated_at",
    "started_at",
    "completed_at",
    "error",
    "result",
    "last_heartbeat_at",
    "worker_pid",
)


async def migrate_work_queue_to_automation_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of work_queue rows from agntspace.db to automation.db.

    Reads every row from ``source_db.work_queue`` and INSERT OR IGNOREs
    into ``target_db.work_queue`` keyed on ``id``. Re-running is a fast
    no-op once the destination is fully caught up.

    Conservative on edge cases — same shape as
    ``infra.decisions_db.migrate_decision_log_to_audit_db``:
    - Source table missing (fresh install) → 0 copied
    - Target schema not yet initialized → returns ``{copied: 0}`` and
      WorkQueue's own ``init_schema()`` runs first on next call
    - Per-batch failure → counted, never raised; partial progress preserved
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    # Source might not have the table yet (fresh install)
    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='work_queue'",
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("work_queue migration: failed to inspect source schema")
        return result
    if not row:
        return result

    # Target must have the schema initialized
    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='work_queue'",
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("work_queue migration: failed to inspect target schema")
        return result
    if not target_row:
        log.warning(
            "work_queue migration: target automation.db has no work_queue table yet; "
            "initialize WorkQueue first, then re-run migration",
        )
        return result

    # Count source rows
    try:
        cur = await source_db.execute("SELECT COUNT(*) FROM work_queue")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("work_queue migration: failed to count source rows")
        return result

    if result["source_total"] == 0:
        return result

    # Resolve which canonical columns the source actually has (older rows
    # may pre-date later migrations); intersect to a portable column list.
    try:
        cur = await source_db.execute("PRAGMA table_info(work_queue)")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("work_queue migration: failed to read source schema")
        return result

    cols = tuple(c for c in _WORK_QUEUE_COLUMNS if c in source_cols)
    if not cols:
        log.warning("work_queue migration: source has none of the expected columns")
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO work_queue ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM work_queue ORDER BY id ASC LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("work_queue migration: batch at offset=%d failed", offset)
            offset += batch_size  # advance past the bad batch

    return result


# Columns expected on cron_jobs after every migration in
# automation/cron.py:init_schema. Stable order for column-positional
# INSERT.
_CRON_JOBS_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "name",
    "schedule",
    "action",
    "action_args",
    "enabled",
    "last_run",
    "next_run",
    "last_result",
    "created_at",
    "deliver_to",
)


# Columns expected on cron_history. Stable order.
_CRON_HISTORY_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "job_name",
    "started_at",
    "finished_at",
    "status",
    "result",
)


# Columns expected on rate_limit_buckets. Stable order. NOTE: this
# table has a COMPOSITE primary key (scope, caller) — no surrogate id.
# INSERT OR IGNORE will dedup by the composite key.
_RATE_LIMIT_BUCKETS_COLUMNS = (  # arch:deterministic — schema column order
    "scope",
    "caller",
    "tokens",
    "last_refill",
    "updated_at",
)


async def _migrate_one_table_generic(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    table_name: str,
    canonical_columns: tuple[str, ...],
    order_clause: str = "ORDER BY id ASC",
    batch_size: int = 1000,
) -> dict:
    """Generic per-table INSERT OR IGNORE migration helper.

    Closes the duplication that crept in across decisions_db.py +
    automation_db.py + finance_db.py — every per-table migration was a
    near-clone with a different table name + column tuple. This helper
    is the shared shape; each new table's migration is a thin wrapper
    that supplies the table name + canonical columns.

    ``order_clause`` is parameterized for tables without an ``id``
    column (e.g. rate_limit_buckets has a composite primary key —
    pass ``ORDER BY scope, caller`` instead).

    Returns ``{copied, already_present, source_total, batches_failed}``.
    Conservative on every edge: missing source / missing target /
    per-batch failure all degrade gracefully.
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("%s migration: failed to inspect source schema", table_name)
        return result
    if not row:
        return result

    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("%s migration: failed to inspect target schema", table_name)
        return result
    if not target_row:
        log.warning(
            "%s migration: target has no %s table yet; "
            "initialize the owner subsystem first, then re-run migration",
            table_name, table_name,
        )
        return result

    try:
        cur = await source_db.execute(f"SELECT COUNT(*) FROM {table_name}")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("%s migration: failed to count source rows", table_name)
        return result

    if result["source_total"] == 0:
        return result

    try:
        cur = await source_db.execute(f"PRAGMA table_info({table_name})")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("%s migration: failed to read source schema", table_name)
        return result

    cols = tuple(c for c in canonical_columns if c in source_cols)
    if not cols:
        log.warning("%s migration: source has none of the expected columns", table_name)
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO {table_name} ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM {table_name} {order_clause} LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("%s migration: batch at offset=%d failed", table_name, offset)
            offset += batch_size

    return result


async def migrate_cron_jobs_to_automation_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of cron_jobs from agntspace.db to automation.db.

    Stage C.2 (shipped 2026-05-05). Mirrors the work_queue migration
    shape; uses ``_migrate_one_table_generic`` under the hood.
    Conservative on every edge.
    """
    return await _migrate_one_table_generic(
        source_db=source_db,
        target_db=target_db,
        table_name="cron_jobs",
        canonical_columns=_CRON_JOBS_COLUMNS,
        batch_size=batch_size,
    )


async def migrate_cron_history_to_automation_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of cron_history from agntspace.db to automation.db.

    Stage C.2 (shipped 2026-05-05). Companion to migrate_cron_jobs
    — both tables move together because they share the CronScheduler
    subsystem.
    """
    return await _migrate_one_table_generic(
        source_db=source_db,
        target_db=target_db,
        table_name="cron_history",
        canonical_columns=_CRON_HISTORY_COLUMNS,
        batch_size=batch_size,
    )


async def migrate_rate_limit_buckets_to_automation_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of rate_limit_buckets from agntspace.db to automation.db.

    Stage C.2 (shipped 2026-05-05). NOTE: rate_limit_buckets has a
    composite primary key (scope, caller) — no surrogate id — so the
    select uses ``ORDER BY scope, caller`` instead of ``ORDER BY id``.
    INSERT OR IGNORE dedups by the composite key.
    """
    return await _migrate_one_table_generic(
        source_db=source_db,
        target_db=target_db,
        table_name="rate_limit_buckets",
        canonical_columns=_RATE_LIMIT_BUCKETS_COLUMNS,
        order_clause="ORDER BY scope, caller",
        batch_size=batch_size,
    )
