"""SQLite-backed cross-process discovery for AgntSpace processes.

Every AgntSpace process registers itself in a single ``process_registry``
table on ``automation.db`` and refreshes a heartbeat column periodically
from a background task. Other processes (and the ``agntspace ps``
diagnostic command) read the table to answer "who's alive in this vault
right now?".

Pure async helpers — no FastAPI, no agntspace cross-imports beyond
``infra.process_lock`` (for the ``LockIdentity`` shape so registry
identity matches lock identity exactly). Safe to use from CLI commands.

Design choices and what they're defending against:

- **Per-vault scope.** The table lives on ``automation.db`` which
  already lives at ``<vault>/agntspace/automation.db``. Switching
  vaults switches registries — two AgntSpace processes attached to
  different vaults never see each other.

- **Identity is ``(pid, started_at)``, not just PID.** Mirrors
  ``process_lock`` exactly. PIDs get recycled; ``started_at``
  (ISO-8601 process creation timestamp) makes the identity unique
  across PID reuse. The composite ``process_id`` primary key is
  ``f"{pid}-{started_at}"`` so UPSERTs are idempotent.

- **Heartbeat-based liveness.** A row is "alive" iff its
  ``heartbeat_at`` is newer than ``now - STALE_THRESHOLD``.
  ``HEARTBEAT_INTERVAL`` is the cadence (10 s); the threshold is 3×
  the cadence so a single missed tick doesn't false-positive.
  Mirrors ``process_lock`` constants by design — a process whose
  lock is healthy should have a healthy registry entry too.

- **Boot-time sweep.** ``sweep_dead`` purges rows older than the
  threshold. Called once at lifespan startup so a previous abrupt
  death (no graceful unregister) doesn't leave a phantom entry
  visible until the next heartbeat tick.

- **Forward-compat metadata column.** ``metadata`` is JSON. The
  current ``singleton`` shape stores ``{port, vault}``; later when
  the process split lands, ``worker`` / ``scheduler`` rows can carry
  whatever per-kind info they need without touching the schema.

- **Schema is idempotent.** ``init_schema`` issues
  ``CREATE TABLE IF NOT EXISTS`` + ``CREATE INDEX IF NOT EXISTS``.
  Repeat calls are no-ops. Adding columns later goes through
  ``ALTER TABLE ... ADD COLUMN`` with safe defaults so pre-migration
  rows remain readable.

- **Fail-soft at every boundary.** Any DB error during heartbeat is
  logged at WARNING but never propagated; registry health is a
  diagnostic surface, not a correctness surface. Compare to
  ``process_lock`` whose heartbeat IS load-bearing (loss → graceful
  shutdown). Registry loss is informational only.

This module is intentionally narrower than the lost original night-25
file-backed implementation: SQLite from day one, async-only API,
single source of truth at one well-known table. The plan-process-split
§7 decision said "move to SQLite in Phase 1"; we land there directly.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import aiosqlite

from agntspace.infra.process_lock import (
    LockIdentity,
    _safe_hostname,
    _self_identity,
)

log = logging.getLogger(__name__)


# arch:deterministic — match process_lock constants by design. A process
# whose lock is healthy should have a healthy registry entry too; using
# different cadences for the two would create a window where one says
# "alive" and the other says "stale" for the same process.
HEARTBEAT_INTERVAL: float = 10.0  # arch:deterministic — heartbeat cadence; matches process_lock
STALE_THRESHOLD: float = 30.0      # arch:deterministic — staleness floor; matches process_lock

# arch:deterministic — kind discriminator for the existing single-process
# binary. After the process split lands, "web" / "worker" / "scheduler"
# join this set; the old binary keeps registering as "singleton" so
# old-mode discovery still works.
DEFAULT_KIND: str = "singleton"


_TABLE_DDL: str = """
CREATE TABLE IF NOT EXISTS process_registry (
    process_id      TEXT PRIMARY KEY,
    pid             INTEGER NOT NULL,
    started_at      TEXT    NOT NULL,
    kind            TEXT    NOT NULL,
    role            TEXT    NOT NULL DEFAULT '',
    host            TEXT    NOT NULL DEFAULT '',
    version         TEXT    NOT NULL DEFAULT '',
    heartbeat_at    TEXT    NOT NULL,
    registered_at   TEXT    NOT NULL,
    metadata        TEXT    NOT NULL DEFAULT '{}'
)
""".strip()

_INDEX_KIND_DDL: str = (
    "CREATE INDEX IF NOT EXISTS idx_process_registry_kind "
    "ON process_registry(kind)"
)

_INDEX_HEARTBEAT_DDL: str = (
    "CREATE INDEX IF NOT EXISTS idx_process_registry_heartbeat "
    "ON process_registry(heartbeat_at)"
)


@dataclass(frozen=True)
class ProcessRegistration:
    """Handle returned by ``register``; pass back into ``heartbeat`` /
    ``unregister`` so the writer always knows which row it owns."""

    process_id: str
    identity: LockIdentity
    kind: str
    role: str
    host: str
    version: str
    registered_at: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProcessRecord:
    """Row from ``process_registry`` enriched with computed liveness."""

    process_id: str
    pid: int
    started_at: str
    kind: str
    role: str
    host: str
    version: str
    heartbeat_at: str
    registered_at: str
    metadata: dict[str, Any]
    heartbeat_age_seconds: float    # computed at read time
    alive: bool                      # heartbeat_age <= STALE_THRESHOLD


# ─────────────────────────────────────────────────────────────────────
# Schema
# ─────────────────────────────────────────────────────────────────────


async def init_schema(db: aiosqlite.Connection) -> None:
    """Idempotently create ``process_registry`` + indexes on the given
    connection. Safe to call on every boot."""
    await db.execute(_TABLE_DDL)
    await db.execute(_INDEX_KIND_DDL)
    await db.execute(_INDEX_HEARTBEAT_DDL)
    await db.commit()


# ─────────────────────────────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────────────────────────────


async def register(
    db: aiosqlite.Connection,
    *,
    kind: str = DEFAULT_KIND,
    role: str = "",
    version: str = "",
    metadata: dict[str, Any] | None = None,
    identity: LockIdentity | None = None,
) -> ProcessRegistration:
    """Insert (or refresh) this process's row.

    Idempotent on ``process_id``: a second call with the same identity
    refreshes ``heartbeat_at`` without disturbing ``registered_at``.

    Returns the registration handle the caller passes back into
    ``heartbeat`` and ``unregister``.
    """
    ident = identity or _self_identity()
    process_id = _format_process_id(ident)
    host = _safe_hostname()
    now_iso = _now_iso()
    md = metadata or {}
    md_json = json.dumps(md, ensure_ascii=False, sort_keys=True)

    # Insert if new; refresh heartbeat + metadata + role + kind if existing
    # (lets the same process change role mid-run without re-registering).
    # DO NOT update registered_at — it's the original boot timestamp.
    await db.execute(
        """
        INSERT INTO process_registry (
            process_id, pid, started_at, kind, role, host, version,
            heartbeat_at, registered_at, metadata
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(process_id) DO UPDATE SET
            kind         = excluded.kind,
            role         = excluded.role,
            host         = excluded.host,
            version      = excluded.version,
            heartbeat_at = excluded.heartbeat_at,
            metadata     = excluded.metadata
        """,
        (
            process_id,
            ident.pid,
            ident.started_at,
            kind,
            role,
            host,
            version,
            now_iso,
            now_iso,
            md_json,
        ),
    )
    await db.commit()

    return ProcessRegistration(
        process_id=process_id,
        identity=ident,
        kind=kind,
        role=role,
        host=host,
        version=version,
        registered_at=now_iso,
        metadata=md,
    )


async def heartbeat(
    db: aiosqlite.Connection,
    registration: ProcessRegistration,
) -> bool:
    """Refresh this process's ``heartbeat_at``.

    Returns True if the row was found and updated; False if our row
    has vanished (e.g. another tool wiped the registry, or
    ``sweep_dead`` ran while we were paused). The caller's response
    to False is to call ``register`` again to re-create the row —
    registry loss is not load-bearing and shouldn't trigger shutdown.

    Fail-soft at the DB layer: any aiosqlite error is logged and
    treated as "row missing" so a transient lock contention or DB
    bounce doesn't pretend our row is healthy.
    """
    try:
        cursor = await db.execute(
            "UPDATE process_registry SET heartbeat_at = ? WHERE process_id = ?",
            (_now_iso(), registration.process_id),
        )
        rowcount = cursor.rowcount
        await cursor.close()
        await db.commit()
    except Exception:
        log.warning(
            "ProcessRegistry: heartbeat() failed for %s",
            registration.process_id,
            exc_info=True,
        )
        return False
    return rowcount > 0


async def unregister(
    db: aiosqlite.Connection,
    registration: ProcessRegistration,
) -> None:
    """Best-effort removal of our row at graceful shutdown.

    Errors are logged but not raised — a failed unregister leaves a
    stale row that the next ``sweep_dead`` will clean up within
    ``STALE_THRESHOLD`` seconds.
    """
    try:
        await db.execute(
            "DELETE FROM process_registry WHERE process_id = ?",
            (registration.process_id,),
        )
        await db.commit()
    except Exception:
        log.warning(
            "ProcessRegistry: unregister() failed for %s",
            registration.process_id,
            exc_info=True,
        )


# ─────────────────────────────────────────────────────────────────────
# Queries
# ─────────────────────────────────────────────────────────────────────


async def list_alive(
    db: aiosqlite.Connection,
    *,
    kind: str | None = None,
    stale_threshold_seconds: float = STALE_THRESHOLD,
) -> list[ProcessRecord]:
    """Return every process whose heartbeat is fresh enough to be alive.

    ``kind=None`` returns every kind. Pass a specific kind (e.g.
    ``"worker"``) to filter. Records sorted by ``heartbeat_at`` desc
    so the most-recently-active row is first.
    """
    return await _list_records(
        db,
        kind=kind,
        only_alive=True,
        stale_threshold_seconds=stale_threshold_seconds,
    )


async def list_all(
    db: aiosqlite.Connection,
    *,
    kind: str | None = None,
    stale_threshold_seconds: float = STALE_THRESHOLD,
) -> list[ProcessRecord]:
    """Return every row, alive or stale. ``alive`` flag on each record
    distinguishes which is which. Useful for diagnostic surfaces
    (``agntspace ps`` shows both)."""
    return await _list_records(
        db,
        kind=kind,
        only_alive=False,
        stale_threshold_seconds=stale_threshold_seconds,
    )


async def sweep_dead(
    db: aiosqlite.Connection,
    *,
    stale_threshold_seconds: float = STALE_THRESHOLD,
) -> int:
    """Delete every row whose heartbeat is older than the threshold.

    Returns count purged. Idempotent: re-running on a clean registry
    is a fast no-op. Should be called once at boot (to drop stale
    entries from the previous run) AND periodically (to harvest rows
    from processes that died without unregistering).
    """
    cutoff_iso = _iso_offset(-stale_threshold_seconds)
    try:
        cursor = await db.execute(
            "DELETE FROM process_registry WHERE heartbeat_at < ?",
            (cutoff_iso,),
        )
        rowcount = cursor.rowcount
        await cursor.close()
        await db.commit()
        return rowcount
    except Exception:
        log.warning(
            "ProcessRegistry: sweep_dead() failed",
            exc_info=True,
        )
        return 0


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────


def _format_process_id(identity: LockIdentity) -> str:
    """Stable composite key. Mirrors ``process_lock`` identity exactly
    so a row's ``process_id`` matches its lock file's ``(pid, started_at)``
    payload."""
    return f"{identity.pid}-{identity.started_at}"


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _iso_offset(delta_seconds: float) -> str:
    """ISO-8601 timestamp ``delta_seconds`` away from now (negative = past)."""
    return datetime.fromtimestamp(
        datetime.now(UTC).timestamp() + delta_seconds,
        tz=UTC,
    ).isoformat()


def _parse_iso(value: str) -> datetime | None:
    """Defensive ISO parse — returns None on malformed input."""
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def _heartbeat_age_seconds(heartbeat_iso: str) -> float:
    """Seconds since heartbeat_at. Returns +inf for unparseable input
    so the record falls outside any reasonable threshold (treated as
    dead). +inf JSON-serializes as ``Infinity`` which most clients
    handle; consumers that need a finite number should clamp."""
    parsed = _parse_iso(heartbeat_iso)
    if parsed is None:
        return float("inf")
    now = datetime.now(UTC)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return (now - parsed).total_seconds()


def _row_to_record(
    row: aiosqlite.Row | dict,
    *,
    stale_threshold_seconds: float,
) -> ProcessRecord:
    """Translate a row dict into a ProcessRecord with computed fields."""
    heartbeat_at = str(row["heartbeat_at"])
    age = _heartbeat_age_seconds(heartbeat_at)
    try:
        metadata = json.loads(row["metadata"]) if row["metadata"] else {}
        if not isinstance(metadata, dict):
            metadata = {}
    except (TypeError, ValueError, json.JSONDecodeError):
        metadata = {}
    return ProcessRecord(
        process_id=str(row["process_id"]),
        pid=int(row["pid"]),
        started_at=str(row["started_at"]),
        kind=str(row["kind"]),
        role=str(row["role"]) if row["role"] is not None else "",
        host=str(row["host"]) if row["host"] is not None else "",
        version=str(row["version"]) if row["version"] is not None else "",
        heartbeat_at=heartbeat_at,
        registered_at=str(row["registered_at"]),
        metadata=metadata,
        heartbeat_age_seconds=age,
        alive=age <= stale_threshold_seconds,
    )


async def _list_records(
    db: aiosqlite.Connection,
    *,
    kind: str | None,
    only_alive: bool,
    stale_threshold_seconds: float,
) -> list[ProcessRecord]:
    """Shared SELECT machinery for list_alive + list_all."""
    where_clauses: list[str] = []
    params: list[Any] = []
    if kind is not None:
        where_clauses.append("kind = ?")
        params.append(kind)
    if only_alive:
        cutoff_iso = _iso_offset(-stale_threshold_seconds)
        where_clauses.append("heartbeat_at >= ?")
        params.append(cutoff_iso)

    where_sql = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    sql = (
        "SELECT process_id, pid, started_at, kind, role, host, version, "
        "heartbeat_at, registered_at, metadata "
        "FROM process_registry"
        f"{where_sql} "
        "ORDER BY heartbeat_at DESC"
    )

    try:
        async with db.execute(sql, params) as cursor:
            rows = await cursor.fetchall()
    except Exception:
        log.warning(
            "ProcessRegistry: list query failed (kind=%s, only_alive=%s)",
            kind,
            only_alive,
            exc_info=True,
        )
        return []

    records = [
        _row_to_record(row, stale_threshold_seconds=stale_threshold_seconds)
        for row in rows
    ]

    # Post-SQL liveness filter. The WHERE clause uses lexical string
    # comparison on heartbeat_at which works for valid ISO-8601 (sorted
    # lexically === sorted by time) but FAILS on garbage values like
    # "definitely not iso" — they sort after any real timestamp and
    # leak into the result. _heartbeat_age_seconds() returns +inf for
    # unparseable input, which the alive flag turns into False; rely
    # on that here so the SQL prefilter and the Python verdict agree.
    if only_alive:
        records = [r for r in records if r.alive]

    return records


# Re-exported for callers that want to construct a registration handle
# from outside this module (rare — tests, mostly).
__all__ = [
    "DEFAULT_KIND",
    "HEARTBEAT_INTERVAL",
    "STALE_THRESHOLD",
    "ProcessRecord",
    "ProcessRegistration",
    "heartbeat",
    "init_schema",
    "list_alive",
    "list_all",
    "register",
    "sweep_dead",
    "unregister",
]
