"""Load gate — Phase 0.5 (2026-05-04).

The architecture restructure plan calls for a "request-path mutex to
refuse new heavy operations when the queue is busy". Watcher + work
queue + heartbeat + repair-classifications shouldn't all fire
simultaneously while a compile is in flight; the result is event-loop
starvation, request timeouts, and the user sees the app freeze.

This module is the smallest possible primitive that makes background
tasks back off when foreground load is high. It does NOT replace the
larger Phase 1.5 (cross-process backpressure) — that's for the
post-Phase-1 process-split world. This is the in-process version.

## Contract

`LoadGate` exposes one read (`is_busy()`) and one write (the work-queue
hook is wired during construction). Background callers consult it
before starting heavy work:

    if app.state.load_gate.is_busy():
        # defer this tick — try again later
        return

The decision is intentionally opaque to the caller: if `is_busy()`
returns True, the caller backs off without arguing. The gate's
internal heuristic can evolve (queue depth threshold, request latency
tracking, p95-aware) without changing every caller.

## Failure mode

If anything goes wrong while computing busyness — work queue not
wired, exception in the probe, async race — `is_busy()` returns False
(fail-open). Background work proceeding when uncertain is much less
costly than background work permanently halted because of a probe bug.

## Tunables (in YAML next phase; constants for now)

- ``BUSY_RUNNING_THRESHOLD`` — if more than this many work-queue jobs
  are running live, gate is busy. Default 1 (any LLM-bound job).
- ``BUSY_PENDING_THRESHOLD`` — if more than this many jobs are pending
  AND retrying, gate is busy. Default 10 (small backlog OK; large is not).
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any

log = logging.getLogger(__name__)


# arch:deterministic — Phase 0.5 thresholds. Tuning these values
# changes the back-off behavior of EVERY background task that reads
# is_busy(); they're constants here because (a) the right shape is
# obvious enough that YAML overhead isn't worth it yet, (b) they
# should change rarely. Phase 1.5 will replace this whole module
# with a cross-process load-level publisher.
_BUSY_RUNNING_THRESHOLD: int = 1  # arch:deterministic — busy if any worker is live
_BUSY_PENDING_THRESHOLD: int = 10  # arch:deterministic — backlog floor for back-off
# How long the cached "is busy" answer stays valid before we re-probe
# the work queue. Prevents N concurrent callers from hammering the
# queue's get_status() in parallel. 1 s is short enough that a freshly-
# busy queue blocks the next tick within a few hundred ms.
_PROBE_CACHE_TTL_SECONDS: float = 1.0


class LoadGate:
    """In-process load-level probe.

    Constructed once during lifespan startup; injected into every
    background task that should back off under load (heartbeat,
    watcher cycles, editor-quality-pass, repair-classifications,
    taxonomy detector).

    Reads from `WorkQueue.get_status()` and caches the result for
    `_PROBE_CACHE_TTL_SECONDS`. The cache is the contention guard —
    20 callers calling is_busy() in the same second produce ONE
    queue probe, not 20.
    """

    def __init__(self, work_queue: Any | None = None) -> None:
        self._work_queue = work_queue
        self._cached: bool | None = None
        self._cached_at: float = 0.0
        self._lock = threading.Lock()
        self._probe_in_flight = False

    def attach_work_queue(self, work_queue: Any) -> None:
        """Late-bind the work queue. Used when the gate is constructed
        before the queue is fully wired (lifespan ordering)."""
        self._work_queue = work_queue

    async def is_busy(self) -> bool:
        """Return True if the system is under enough load that
        background tasks should defer. Fail-open on any error.
        """
        import time as _time

        if self._work_queue is None:
            return False

        # Cached answer wins.
        cached = self._cached
        if cached is not None and (_time.time() - self._cached_at) < _PROBE_CACHE_TTL_SECONDS:
            return cached

        # Probe — but only ONE caller at a time. The lock is sync
        # because the thread switch is microseconds; avoiding it
        # would mean asyncio.Lock + every caller awaiting, which
        # is heavier and isn't required (the probe itself is async).
        if self._probe_in_flight:
            # Another caller is probing right now — return last cached
            # value (or False if never probed). Avoids 20 concurrent probes.
            return self._cached if self._cached is not None else False

        with self._lock:
            # Re-check under the lock.
            cached = self._cached
            if cached is not None and (_time.time() - self._cached_at) < _PROBE_CACHE_TTL_SECONDS:
                return cached
            self._probe_in_flight = True

        try:
            busy = await self._probe_busy()
        except Exception:
            log.debug("LoadGate probe raised", exc_info=True)
            busy = False  # fail-open
        finally:
            self._probe_in_flight = False

        self._cached = busy
        self._cached_at = _time.time()
        return busy

    async def _probe_busy(self) -> bool:
        """Inspect the work queue and return whether we're under load."""
        if self._work_queue is None:
            return False
        try:
            status = await self._work_queue.get_status()
        except Exception:
            log.debug("WorkQueue.get_status() raised in load probe", exc_info=True)
            return False

        counts = status.get("counts", {}) if isinstance(status, dict) else {}
        running_live = int(counts.get("running_live", 0) or 0)
        pending = int(counts.get("pending", 0) or 0)
        retrying = int(counts.get("retrying", 0) or 0)

        if running_live > _BUSY_RUNNING_THRESHOLD:
            return True
        if (pending + retrying) > _BUSY_PENDING_THRESHOLD:
            return True
        return False

    def invalidate_cache(self) -> None:
        """Drop the cached busyness state. Useful in tests or after a
        known load shift (e.g. job just completed)."""
        self._cached = None
        self._cached_at = 0.0


def is_busy_sync(gate: LoadGate | None) -> bool:
    """Sync wrapper for callers that aren't in async context.

    Schedules the async probe on the running loop (best-effort) and
    falls back to False on any error. The cached state is sync-readable
    so most calls return immediately.
    """
    if gate is None:
        return False
    # If we have a cached answer that's still valid, return it without
    # touching asyncio.
    import time as _time

    cached = gate._cached
    if cached is not None and (_time.time() - gate._cached_at) < _PROBE_CACHE_TTL_SECONDS:
        return cached

    # Otherwise we'd need to run the async probe; from sync context
    # that's awkward. Try to schedule it on the running loop if
    # there is one; otherwise fail-open.
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Can't await here. Return cached (possibly stale) or False.
            return cached if cached is not None else False
        # No running loop — run the probe synchronously.
        return loop.run_until_complete(gate.is_busy())
    except Exception:
        return False
