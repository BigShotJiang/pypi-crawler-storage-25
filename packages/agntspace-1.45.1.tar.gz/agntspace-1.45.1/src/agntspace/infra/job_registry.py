"""Generic in-process job registry for long-running async operations.

Promoted from `plugins/bundled/onenote-import/jobs.py` to a service-level
shared facility (2026-04-27 evening) so any long-running endpoint can
opt into the fire-and-forget + progress-poll pattern without locking
the FastAPI single-worker event loop.

**Usage pattern (caller):**

```python
# In a service method that does long work:
async def long_running_op(self, slug: str, *, progress: ProgressHandle | None = None) -> dict:
    progress = progress or ProgressHandle.detached()
    progress.set_phase("phase 1")
    progress.set_total(N)
    for i, item in enumerate(items):
        if progress.cancelled():
            return progress.cancelled_result(...)
        # ... do work ...
        progress.tick()
    return {...}

# In the API route:
@router.post("/long-op")
async def kickoff(request, ...):
    registry = request.app.state.job_registry
    job = await registry.create(kind="my_op", details={"slug": slug})
    asyncio.create_task(_run(registry, job, ...))  # fire-and-forget
    return {
        "job_id": job.job_id,
        "progress_url": f"/api/jobs/{job.job_id}",
    }

async def _run(registry, job, ...):
    progress = registry.handle(job.job_id)
    try:
        progress.mark_running()
        result = await self.long_running_op(..., progress=progress)
        progress.mark_completed(result)
    except Exception as exc:
        progress.mark_failed(str(exc))
```

**Why in-process / in-memory rather than persistent:**

- Job progress is a UX concern (show user a progress bar), not a correctness
  concern. The actual work writes to the vault; if the server restarts, the
  vault state is what matters and idempotent re-runs pick up where they left
  off.
- Persisting to SQLite would add a second source-of-truth that must stay
  consistent with vault state. Avoid the synchronization burden.
- ``history_limit`` keeps memory bounded; finished jobs are evicted oldest-
  first. Running jobs never get evicted.

**Concurrency model:**

- All registry mutations go through a single ``asyncio.Lock`` — race-free
  inserts/reads from the async router path.
- ``ProgressHandle`` (returned by ``registry.handle()``) is the per-job
  mutator. Workers running in ``asyncio.to_thread`` mutate ``JobState``
  fields directly. Each field is an int, str, or small list/dict; CPython
  primitive mutations are atomic enough for progress UX. Readers tolerate
  brief staleness (the API response is a snapshot).
"""

from __future__ import annotations

import asyncio
import secrets
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


def new_job_id() -> str:
    """8-char URL-safe random id. Short enough to be pasteable; long enough
    to avoid collision within a single process's lifetime."""
    return secrets.token_urlsafe(6)


def _iso_now() -> str:
    return datetime.now(UTC).isoformat()


def _elapsed_seconds(started_at: str, finished_at: str) -> float:
    """Compute elapsed seconds between two ISO-8601 timestamps. When
    finished_at is empty, uses now() (job is still running)."""
    if not started_at:
        return 0.0
    try:
        start = datetime.fromisoformat(started_at)
        end = (
            datetime.fromisoformat(finished_at)
            if finished_at else datetime.now(UTC)
        )
        return max(0.0, (end - start).total_seconds())
    except Exception:
        return 0.0


def _estimate_eta(
    *,
    total: int,
    processed: int,
    elapsed_s: float,
    running: bool,
) -> float | None:
    """Honest ETA: returns None until we have enough data points to
    extrapolate. Never lies — better silence than a wrong number."""
    if not running:
        return None
    if processed <= 0 or total <= 0 or elapsed_s < 1.0:
        return None
    if processed >= total:
        return 0.0
    rate = processed / elapsed_s  # items per second
    if rate <= 0:
        return None
    remaining = total - processed
    return round(remaining / rate, 2)


@dataclass
class JobState:
    """Generic state for a long-running async job.

    Each job kind (e.g. "kb_migrate_to_taxonomy", "kb_compile_wiki") embeds
    type-specific counters / metadata in ``details``. The top-level fields
    cover the universal lifecycle that every progress UI needs.
    """

    job_id: str
    kind: str  # e.g. "kb_migrate_to_taxonomy"
    state: str = "pending"  # pending | running | completed | failed | cancelled
    started_at: str = ""
    finished_at: str = ""

    # Universal progress shape — populated by ProgressHandle.
    phase: str = ""
    total: int = 0
    processed: int = 0

    # Terminal-state outcomes.
    error: str = ""
    result: dict = field(default_factory=dict)

    # Per-kind metadata + counters. Free-form dict the caller writes to.
    details: dict = field(default_factory=dict)

    # Cooperative cancellation flag — workers check before processing each item.
    cancel_requested: bool = False

    def to_public_dict(self) -> dict:
        """Stable snapshot for HTTP responses. Includes derived fields
        (elapsed, eta, ratio) computed at call time."""
        elapsed = _elapsed_seconds(self.started_at, self.finished_at)
        eta = _estimate_eta(
            total=self.total,
            processed=self.processed,
            elapsed_s=elapsed,
            running=(self.state == "running"),
        )
        ratio = self.processed / self.total if self.total > 0 else 0.0
        return {
            "job_id": self.job_id,
            "kind": self.kind,
            "state": self.state,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "elapsed_s": round(elapsed, 2),
            "eta_s": eta,
            "phase": self.phase,
            "total": self.total,
            "processed": self.processed,
            "progress_ratio": round(ratio, 4),
            "error": self.error,
            "result": self.result,
            "details": self.details,
            "cancel_requested": self.cancel_requested,
        }


class ProgressHandle:
    """Per-job mutator. The worker calls these methods to update state.

    A handle bound to a missing job_id (registry.handle returned None,
    never happens for normal flows) returns a no-op detached handle so
    callers can use the same code path with or without a registry wired.
    """

    __slots__ = ("_job", "_registry")

    def __init__(self, job: JobState | None, registry: JobRegistry | None) -> None:
        self._job = job
        self._registry = registry

    @classmethod
    def detached(cls) -> ProgressHandle:
        """A no-op handle for callers that don't have a registry. Lets
        the same service-method signature work for both async-job and
        synchronous-call paths."""
        return cls(None, None)

    # ── lifecycle ──────────────────────────────────────────────────

    def mark_running(self) -> None:
        if self._job is None:
            return
        self._job.state = "running"
        if not self._job.started_at:
            self._job.started_at = _iso_now()

    def mark_completed(self, result: dict | None = None) -> None:
        if self._job is None:
            return
        self._job.state = "completed"
        self._job.finished_at = _iso_now()
        if result is not None:
            self._job.result = result

    def mark_failed(self, error: str, result: dict | None = None) -> None:
        if self._job is None:
            return
        self._job.state = "failed"
        self._job.finished_at = _iso_now()
        self._job.error = error
        if result is not None:
            self._job.result = result

    def mark_cancelled(self, result: dict | None = None) -> None:
        if self._job is None:
            return
        self._job.state = "cancelled"
        self._job.finished_at = _iso_now()
        if result is not None:
            self._job.result = result

    # ── progress mutators ─────────────────────────────────────────

    def set_phase(self, phase: str) -> None:
        if self._job is None:
            return
        self._job.phase = phase

    def set_total(self, total: int) -> None:
        if self._job is None:
            return
        self._job.total = max(0, int(total))

    def tick(self, n: int = 1) -> None:
        """Increment processed counter."""
        if self._job is None:
            return
        self._job.processed += int(n)

    def set_processed(self, processed: int) -> None:
        """Set absolute processed count (use when total is unknown until late)."""
        if self._job is None:
            return
        self._job.processed = max(0, int(processed))

    def set_detail(self, key: str, value: Any) -> None:
        """Free-form per-kind detail."""
        if self._job is None:
            return
        self._job.details[key] = value

    def update_details(self, **kwargs: Any) -> None:
        """Bulk-update details."""
        if self._job is None:
            return
        self._job.details.update(kwargs)

    # ── cancellation ──────────────────────────────────────────────

    def cancelled(self) -> bool:
        """Return True when a cancel was requested. Workers check this
        between items and break out cleanly."""
        if self._job is None:
            return False
        return self._job.cancel_requested

    # ── snapshot ──────────────────────────────────────────────────

    def snapshot(self) -> dict:
        """Read-only snapshot of current state. For workers that want to
        return progress info without going back through the registry."""
        if self._job is None:
            return {"job_id": "", "state": "detached"}
        return self._job.to_public_dict()


class JobRegistry:
    """Process-wide registry of long-running jobs.

    Bounded history: retains at most ``history_limit`` finished jobs,
    oldest evicted first. Running jobs are never evicted.

    Singleton-style use via ``app.state.job_registry`` is the canonical
    pattern — wire ONCE at lifespan startup; every endpoint reads it
    from the request's app state.
    """

    def __init__(self, *, history_limit: int = 50) -> None:
        self._jobs: dict[str, JobState] = {}
        self._order: list[str] = []  # insertion order for eviction
        self._lock = asyncio.Lock()
        self._history_limit = history_limit

    async def create(
        self,
        *,
        kind: str,
        details: dict | None = None,
    ) -> JobState:
        """Register a new pending job. Returns the JobState; caller
        typically passes ``job.job_id`` back to the client and spawns
        an ``asyncio.create_task(...)`` to do the work in background."""
        job = JobState(
            job_id=new_job_id(),
            kind=kind,
            details=details or {},
        )
        async with self._lock:
            self._jobs[job.job_id] = job
            self._order.append(job.job_id)
            self._evict_old()
        return job

    async def get(self, job_id: str) -> JobState | None:
        async with self._lock:
            return self._jobs.get(job_id)

    def handle(self, job_id: str) -> ProgressHandle:
        """Return a ProgressHandle for the job. Doesn't go through the
        lock — callers cache this handle and write directly. Detached if
        the job no longer exists (was evicted)."""
        return ProgressHandle(self._jobs.get(job_id), self)

    async def list_recent(self, limit: int = 50, kind: str | None = None) -> list[JobState]:
        """Newest-first. ``kind`` filter for "show me only KB migration jobs"."""
        async with self._lock:
            ids = list(reversed(self._order))
            jobs = [self._jobs[jid] for jid in ids if jid in self._jobs]
            if kind:
                jobs = [j for j in jobs if j.kind == kind]
            return jobs[:limit]

    async def list_active(self) -> list[JobState]:
        """All jobs currently running or pending. Used by the corner-badge
        indicator + active-jobs page."""
        async with self._lock:
            return [
                self._jobs[jid] for jid in self._order
                if jid in self._jobs and self._jobs[jid].state in {"pending", "running"}
            ]

    async def request_cancel(self, job_id: str) -> bool:
        """Set the cancel flag. Workers honor it cooperatively — they
        check ``handle.cancelled()`` between items and exit cleanly."""
        async with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return False
            if job.state in {"completed", "failed", "cancelled"}:
                return False
            job.cancel_requested = True
            return True

    def _evict_old(self) -> None:
        """Drop the oldest finished jobs once history exceeds the limit.

        Running jobs never get evicted — they're by definition in-progress.
        """
        if len(self._order) <= self._history_limit:
            return
        overflow = len(self._order) - self._history_limit
        evicted = 0
        new_order: list[str] = []
        for jid in self._order:
            job = self._jobs.get(jid)
            if (
                evicted < overflow
                and job is not None
                and job.state in {"completed", "failed", "cancelled"}
            ):
                self._jobs.pop(jid, None)
                evicted += 1
                continue
            new_order.append(jid)
        self._order = new_order
