"""Rate-limit-aware pool for outbound API credentials.

Layered on top of ``CredentialStore``: the pool itself doesn't store secrets,
it borrows them from the encrypted store and adds in-memory rotation +
per-credential rate tracking on top.

The motivating problem: a single API key against a rate-limited provider
(OpenAI, Anthropic, Google) gets 429s under bursty load. Heavy users
sometimes have a paid + a free key, or two paid keys with separate quotas.
This module lets the agent rotate across them BEFORE hitting a 429
(based on observed local request counts) AND skip a credential that
just returned 429 until its retry-after window elapses.

Design choices:

  * **In-memory rate state**. Restart drops the per-credential counters.
    That's deliberate — quota windows are sliding (most providers use
    1-min / 1-hour rolling) and a stale state from yesterday's run is
    misleading. On a fresh process every credential starts "healthy"
    and we re-discover 429s if they happen.

  * **Secrets stay in CredentialStore**. The pool stores its
    *configuration* (which credentials exist, what quotas, what labels)
    in the encrypted store under service key ``pool_<provider>``; the
    actual API keys live alongside them in the same encrypted record.
    Rule 7 satisfied: no plaintext leaves the store.

  * **Optional and additive**. When a provider has no pool configured,
    callers fall through to the existing ``CredentialStore.get(provider)``
    path. Pool is opt-in via ``CredentialPool.register_pool(...)`` at
    setup-time.

  * **Pure-function classifier**. ``should_skip_credential(state, now)``
    is a pure function — easy to unit-test, no time-mocking needed in
    the hot path. The pool wraps it with a clock + lock for thread-safety.

  * **Token-bucket rate accounting** mirrors the existing
    ``TokenBucketRateLimiter`` shape but is per-credential, NOT
    per-scope. Each credential gets its own bucket; the pool picks the
    first credential with capacity.

  * **Cooldown on 429**. ``report_rate_limited(cred_id, retry_after)``
    puts the credential in cooldown until ``time.monotonic() +
    retry_after``. The pool skips it on subsequent ``acquire()`` calls
    until cooldown expires.

This is engine substrate (Rule 12). Tunable knobs (default capacity,
default refill, default cooldown) live in
``defaults/skills/_meta/credential-pool/config/pool.yaml``.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Final

log = logging.getLogger(__name__)

# arch:deterministic — conservative defaults so a fresh provider entry
# behaves sanely without any per-credential tuning. Real users override
# via the YAML config.
_DEFAULT_CAPACITY: Final[float] = 60.0  # 60 requests per refill window
_DEFAULT_REFILL_PER_SECOND: Final[float] = 1.0  # 1 request per second steady-state
_DEFAULT_COOLDOWN_ON_429: Final[float] = 30.0  # 30s before retry if no Retry-After header
_DEFAULT_CONSECUTIVE_429_THRESHOLD: Final[int] = 5  # arch:deterministic — sick threshold per credential, engine substrate
_DEFAULT_SICK_COOLDOWN: Final[float] = 300.0  # 5 minutes for a "sick" credential


@dataclass
class _CredentialState:
    """Per-credential runtime state. Kept in memory only.

    All time fields are ``time.monotonic()`` floats so they're immune
    to wall-clock jumps (NTP, DST, etc.).
    """

    cred_id: str
    capacity: float
    refill_per_second: float
    tokens: float
    last_refill: float
    cooldown_until: float = 0.0  # monotonic time when cooldown ends; 0 = no cooldown
    consecutive_429s: int = 0
    consecutive_successes: int = 0
    last_acquired_at: float = 0.0  # for LRU rotation


@dataclass(frozen=True)
class CredentialChoice:
    """The credential the pool picked for the next request.

    Returned by ``acquire()``. Contains the cred_id (so the caller can
    later ``report_success`` / ``report_rate_limited``), plus the
    decrypted credentials dict (the actual key + label).
    """

    cred_id: str
    credentials: dict[str, Any]
    provider: str


@dataclass(frozen=True)
class PoolConfig:
    """Pool-level config. Per-credential overrides override these."""

    capacity: float = _DEFAULT_CAPACITY
    refill_per_second: float = _DEFAULT_REFILL_PER_SECOND
    cooldown_on_429: float = _DEFAULT_COOLDOWN_ON_429
    consecutive_429_threshold: int = _DEFAULT_CONSECUTIVE_429_THRESHOLD
    sick_cooldown: float = _DEFAULT_SICK_COOLDOWN

    @classmethod
    def from_yaml_block(cls, block: Any) -> PoolConfig:
        """Parse a YAML config block, fail-soft on every malformed field."""
        if not isinstance(block, dict):
            return cls()

        def _flt(key: str, default: float) -> float:
            try:
                v = float(block.get(key, default))
                return v if v > 0 else default
            except (TypeError, ValueError):
                return default

        def _int(key: str, default: int) -> int:
            try:
                v = int(block.get(key, default))
                return v if v > 0 else default
            except (TypeError, ValueError):
                return default

        return cls(
            capacity=_flt("capacity", _DEFAULT_CAPACITY),
            refill_per_second=_flt("refill_per_second", _DEFAULT_REFILL_PER_SECOND),
            cooldown_on_429=_flt("cooldown_on_429", _DEFAULT_COOLDOWN_ON_429),
            consecutive_429_threshold=_int(
                "consecutive_429_threshold", _DEFAULT_CONSECUTIVE_429_THRESHOLD,
            ),
            sick_cooldown=_flt("sick_cooldown", _DEFAULT_SICK_COOLDOWN),
        )


class PoolEmpty(Exception):
    """Raised when ``acquire()`` is called on a provider with no credentials.

    Distinct from ``AllCredentialsCoolingDown`` — that's "we have keys but
    they're all rate-limited"; this is "no keys configured at all".
    """


class AllCredentialsCoolingDown(Exception):
    """Raised when every credential in the pool is in cooldown.

    Carries ``earliest_available_in`` as a hint for the caller's backoff.
    """

    def __init__(self, provider: str, earliest_available_in: float) -> None:
        super().__init__(
            f"All credentials for provider {provider!r} are in cooldown; "
            f"earliest available in {earliest_available_in:.1f}s."
        )
        self.provider = provider
        self.earliest_available_in = earliest_available_in


# ─────────────────────────────────────────────────────────────────────────────
# Pure-function classifier
# ─────────────────────────────────────────────────────────────────────────────


def should_skip_credential(state: _CredentialState, now: float) -> bool:
    """Return True iff the credential should be skipped at ``now``.

    Pure function. Zero side effects. Drives the rotation decision in
    ``acquire()`` AND is unit-testable in isolation.
    """
    if state.cooldown_until > now:
        return True
    if state.tokens <= 0.0:
        # Refill math: how many tokens would have been added since last_refill?
        # If tokens would still be ≤0, skip; else don't (we'll refill on the
        # acquire path).
        elapsed = max(0.0, now - state.last_refill)
        projected = min(
            state.capacity, state.tokens + elapsed * state.refill_per_second,
        )
        if projected <= 0.0:
            return True
    return False


def time_until_available(state: _CredentialState, now: float) -> float:
    """Return seconds until ``state`` is acquirable. 0 if available now.

    Used to rank credentials when ALL are in cooldown — the pool returns
    the cred with the soonest reset so the caller's backoff is shortest.
    """
    if state.cooldown_until > now:
        wait_cooldown = state.cooldown_until - now
    else:
        wait_cooldown = 0.0
    if state.tokens > 0:
        wait_tokens = 0.0
    else:
        # Time to refill ONE token at the configured rate.
        if state.refill_per_second <= 0:
            wait_tokens = float("inf")
        else:
            wait_tokens = max(0.0, (1.0 - state.tokens) / state.refill_per_second)
    return max(wait_cooldown, wait_tokens)


# ─────────────────────────────────────────────────────────────────────────────
# CredentialPool
# ─────────────────────────────────────────────────────────────────────────────


class CredentialPool:
    """Per-process pool that rotates across multiple credentials per provider.

    The provider's credential RECORDS (keys, labels, ids) live in the
    encrypted ``CredentialStore`` under service key ``pool_<provider>``.
    The pool reads them on registration and tracks per-credential rate
    state in memory.

    Args:
        config: Pool-level config. Per-credential overrides come from the
            credential record itself (``{"_capacity": ..., "_refill": ...}``).
    """

    def __init__(self, *, config: PoolConfig | None = None) -> None:
        self._config = config or PoolConfig()
        self._states: dict[str, dict[str, _CredentialState]] = {}  # provider -> {cred_id -> state}
        self._records: dict[str, dict[str, dict[str, Any]]] = {}  # provider -> {cred_id -> credentials_dict}
        self._lock = threading.RLock()

    # -------- Pool registration --------

    def register_pool(
        self,
        provider: str,
        credentials: list[dict[str, Any]],
    ) -> None:
        """Register (or replace) the pool for ``provider``.

        Each entry in ``credentials`` is a dict with at minimum:
          * ``id``: stable identifier (e.g. "openai-paid", "openai-free")
          * Anything else the caller wants — e.g. ``api_key``, ``label``,
            optional ``_capacity`` / ``_refill_per_second`` overrides.

        Calling ``register_pool`` again with the same provider replaces
        the old pool entirely. State for any cred_id no longer present
        is dropped.
        """
        if not provider or not isinstance(provider, str):
            raise ValueError("provider must be a non-empty string")
        if not isinstance(credentials, list) or not credentials:
            raise ValueError("credentials must be a non-empty list of dicts")

        now = time.monotonic()
        with self._lock:
            new_states: dict[str, _CredentialState] = {}
            new_records: dict[str, dict[str, Any]] = {}
            for entry in credentials:
                if not isinstance(entry, dict):
                    log.warning("Skipping non-dict pool entry: %r", entry)
                    continue
                cred_id = entry.get("id")
                if not cred_id or not isinstance(cred_id, str):
                    log.warning("Skipping pool entry without 'id' field: %r", entry)
                    continue
                # Per-credential overrides on top of pool defaults.
                cap = self._config.capacity
                refill = self._config.refill_per_second
                if isinstance(entry.get("_capacity"), int | float) and entry["_capacity"] > 0:
                    cap = float(entry["_capacity"])
                if isinstance(entry.get("_refill_per_second"), int | float) and entry["_refill_per_second"] > 0:
                    refill = float(entry["_refill_per_second"])

                # Carry over existing state if same cred_id is being re-registered.
                old = self._states.get(provider, {}).get(cred_id)
                if old is not None:
                    new_states[cred_id] = _CredentialState(
                        cred_id=cred_id,
                        capacity=cap,
                        refill_per_second=refill,
                        tokens=min(cap, old.tokens),
                        last_refill=old.last_refill,
                        cooldown_until=old.cooldown_until,
                        consecutive_429s=old.consecutive_429s,
                        consecutive_successes=old.consecutive_successes,
                        last_acquired_at=old.last_acquired_at,
                    )
                else:
                    new_states[cred_id] = _CredentialState(
                        cred_id=cred_id,
                        capacity=cap,
                        refill_per_second=refill,
                        tokens=cap,  # start full
                        last_refill=now,
                    )
                # Strip private fields (`_capacity`, `_refill_per_second`)
                # from the record handed back to callers — they're for
                # the pool, not the API client.
                new_records[cred_id] = {
                    k: v for k, v in entry.items()
                    if not k.startswith("_")
                }

            self._states[provider] = new_states
            self._records[provider] = new_records

    def unregister_pool(self, provider: str) -> bool:
        """Drop the pool for ``provider``. Returns True if it existed."""
        with self._lock:
            had = provider in self._states
            self._states.pop(provider, None)
            self._records.pop(provider, None)
            return had

    def has_pool(self, provider: str) -> bool:
        with self._lock:
            return provider in self._states and bool(self._states[provider])

    # -------- Acquire / report --------

    def acquire(self, provider: str) -> CredentialChoice:
        """Pick the next available credential for ``provider``.

        Selection rule:
          1. Skip every credential where ``should_skip_credential`` is True.
          2. Among the rest, pick the one with the OLDEST ``last_acquired_at``
             (LRU — spreads load evenly).
          3. If every credential is in cooldown, raise
             ``AllCredentialsCoolingDown`` with the soonest-available wait.

        Side effects (atomic under lock):
          * Refills tokens up to capacity based on elapsed time.
          * Decrements one token from the chosen credential.
          * Updates ``last_acquired_at`` to ``now``.
        """
        now = time.monotonic()
        with self._lock:
            states = self._states.get(provider)
            records = self._records.get(provider)
            if not states or not records:
                raise PoolEmpty(f"No pool registered for provider {provider!r}")

            # Refill all credentials based on elapsed monotonic time.
            for state in states.values():
                self._refill_locked(state, now)

            available = [s for s in states.values() if not should_skip_credential(s, now)]
            if not available:
                # Find the soonest-available cred for the error message.
                soonest = min(
                    time_until_available(s, now) for s in states.values()
                )
                raise AllCredentialsCoolingDown(provider, soonest)

            # LRU pick — tie broken by cred_id (deterministic for tests).
            chosen = min(available, key=lambda s: (s.last_acquired_at, s.cred_id))
            chosen.tokens = max(0.0, chosen.tokens - 1.0)
            chosen.last_acquired_at = now

            return CredentialChoice(
                cred_id=chosen.cred_id,
                credentials=dict(records[chosen.cred_id]),
                provider=provider,
            )

    def report_success(self, provider: str, cred_id: str) -> None:
        """Record a successful API call for ``cred_id``.

        Resets the consecutive-429 counter so a one-off 429 doesn't
        permanently shadow a credential.
        """
        with self._lock:
            state = self._states.get(provider, {}).get(cred_id)
            if state is None:
                return
            state.consecutive_429s = 0
            state.consecutive_successes += 1

    def report_rate_limited(
        self,
        provider: str,
        cred_id: str,
        *,
        retry_after: float | None = None,
    ) -> None:
        """Record a 429 from ``cred_id``.

        Args:
            retry_after: Server-supplied retry-after seconds, if any.
                When ``None``, falls back to ``cooldown_on_429``.

        After ``consecutive_429_threshold`` consecutive 429s, the
        credential gets a longer ``sick_cooldown`` to stop hammering it.
        """
        now = time.monotonic()
        cooldown = (
            float(retry_after)
            if retry_after is not None and retry_after > 0
            else self._config.cooldown_on_429
        )
        with self._lock:
            state = self._states.get(provider, {}).get(cred_id)
            if state is None:
                return
            state.consecutive_429s += 1
            state.consecutive_successes = 0
            if state.consecutive_429s >= self._config.consecutive_429_threshold:
                # Sick — back off for the long cooldown to avoid hammering.
                cooldown = max(cooldown, self._config.sick_cooldown)
            state.cooldown_until = now + cooldown
            # Drop tokens to zero so the bucket math agrees with the
            # cooldown — even after cooldown expires, the credential
            # has to refill before being acquired again.
            state.tokens = 0.0

    def report_failure(self, provider: str, cred_id: str) -> None:
        """Record a non-429 failure (timeout, 500, network).

        Does NOT trigger cooldown — those failures aren't quota-related.
        Resets the consecutive-success counter so the pool tracks
        observed reliability.
        """
        with self._lock:
            state = self._states.get(provider, {}).get(cred_id)
            if state is None:
                return
            state.consecutive_successes = 0

    # -------- Introspection --------

    def stats(self, provider: str) -> dict[str, Any] | None:
        """Return a snapshot of pool state for diagnostics. None if no pool."""
        now = time.monotonic()
        with self._lock:
            states = self._states.get(provider)
            if not states:
                return None
            self._refill_all_locked(now)
            entries = []
            for cred_id, state in states.items():
                entries.append({
                    "cred_id": cred_id,
                    "tokens": round(state.tokens, 2),
                    "capacity": state.capacity,
                    "in_cooldown": state.cooldown_until > now,
                    "cooldown_remaining": max(0.0, state.cooldown_until - now),
                    "consecutive_429s": state.consecutive_429s,
                    "consecutive_successes": state.consecutive_successes,
                })
            return {"provider": provider, "credentials": entries}

    def list_providers(self) -> list[str]:
        with self._lock:
            return list(self._states.keys())

    # -------- Internals --------

    def _refill_locked(self, state: _CredentialState, now: float) -> None:
        elapsed = now - state.last_refill
        if elapsed <= 0 or state.refill_per_second <= 0:
            state.last_refill = now
            return
        added = elapsed * state.refill_per_second
        state.tokens = min(state.capacity, state.tokens + added)
        state.last_refill = now

    def _refill_all_locked(self, now: float) -> None:
        for state_dict in self._states.values():
            for state in state_dict.values():
                self._refill_locked(state, now)


# ─────────────────────────────────────────────────────────────────────────────
# Module singleton
# ─────────────────────────────────────────────────────────────────────────────

_default_pool: CredentialPool | None = None
_default_lock = threading.Lock()


def get_default_pool() -> CredentialPool:
    """Return the process-wide default CredentialPool, lazily constructed."""
    global _default_pool
    with _default_lock:
        if _default_pool is None:
            _default_pool = CredentialPool()
        return _default_pool


def set_default_pool(pool: CredentialPool) -> None:
    """Replace the process-wide default pool. Idempotent."""
    global _default_pool
    with _default_lock:
        _default_pool = pool


def auto_register_pools_from_store(
    pool: CredentialPool,
    credential_store: object,
) -> list[str]:
    """Scan ``credential_store`` for registered pools + register on ``pool``.

    The naming convention ``pool_<provider>`` lets us discover registered
    pools generically without hardcoding provider names.

    Args:
        pool: The CredentialPool instance to register loaded pools on.
        credential_store: Anything with ``list_services()`` returning
            list[str] AND a ``get(service)`` returning dict | None.
            Avoiding a hard import on CredentialStore so this helper is
            usable from boot paths where the type isn't yet available.

    Returns:
        List of provider names whose pools were successfully loaded.
        Failures are logged at WARNING but never raised — boot must
        not be blocked by malformed pool entries on disk.
    """
    if not hasattr(credential_store, "list_services"):
        return []

    loaded: list[str] = []
    try:
        services = list(credential_store.list_services())
    except Exception:  # noqa: BLE001
        log.warning(
            "auto_register_pools_from_store: list_services failed",
            exc_info=True,
        )
        return []

    for service in services:
        if not isinstance(service, str) or not service.startswith("pool_"):
            continue
        provider_name = service[len("pool_"):]
        if not provider_name:
            continue
        try:
            record = credential_store.get(service)
        except Exception:  # noqa: BLE001
            log.warning(
                "auto_register_pools_from_store: get failed for %s",
                service, exc_info=True,
            )
            continue
        if not isinstance(record, dict):
            continue
        creds_list = record.get("credentials")
        if not isinstance(creds_list, list) or not creds_list:
            continue
        # Filter to dict entries only — defensive against on-disk corruption.
        valid = [c for c in creds_list if isinstance(c, dict) and isinstance(c.get("id"), str)]
        if not valid:
            continue
        try:
            pool.register_pool(provider_name, valid)
            loaded.append(provider_name)
        except Exception:  # noqa: BLE001
            log.warning(
                "auto_register_pools_from_store: register failed for %s",
                provider_name, exc_info=True,
            )
    return loaded
