"""Memory-snapshot monitoring for the long-running server process.

Closes chunk 4 of the 2026-05-05 reliability session: the 472 MB →
growing memory profile during graph build today suggests OOM-kill is
a plausible death mode for the user's 1700-article vault. When the
OS sends SIGKILL because the kernel decides the process is the
biggest target, NO Python code runs at all — chunk 1's atexit hook
doesn't fire, chunk 2's launcher sees an unclean exit but has no
cause, and the user is left with "the server died, no idea why".

This module addresses that class by detecting memory growth EARLY,
BEFORE the OS reaches for SIGKILL:

* **periodic snapshot** — heartbeat reads RSS each tick (~15 min) and
  logs at DEBUG. Persistent growth becomes visible in the log even
  when nothing crashes.

* **threshold crossings** log at INFO/WARNING — the user sees
  "memory crossed 1500 MB threshold" in the agent's daily summary.

* **hard ceiling** at a configurable cap — when RSS exceeds it,
  ``record_shutdown_reason("memory_ceiling_exceeded")`` is called
  AND a graceful shutdown signal (SIGINT) is sent to the process.
  uvicorn's signal handler catches it, lifespan teardown runs, and
  the launcher (chunk 2) sees a clean rc=0 exit. Better to land
  cleanly with a recorded cause than to be SIGKILLed silently.

The thresholds are deliberately conservative defaults:

* warn at 1500 MB     — typical "graph build complete on a big vault"
* alarm at 2500 MB    — "something is leaking, but not catastrophic"
* ceiling at 3500 MB  — "trip clean shutdown before the OS does it"

Most personal machines have 8-32 GB RAM; 3.5 GB is large but not
suicidal. Users on small machines (4 GB) can lower the ceiling via
the YAML config in ``defaults/skills/_meta/memory-monitor/`` (chunk
4 ships the engine; the YAML wiring lives where the heartbeat reads
its other knobs).

Design choices:

* **psutil first, fallback to resource module** — psutil is in our
  base deps. On POSIX without psutil, ``resource.getrusage`` works
  (KB on Linux, bytes on macOS — handled). On Windows without
  psutil, return None (rare; psutil is reliable).

* **stateful monitor** — first check after a threshold cross fires
  the alarm; subsequent checks at the SAME or higher level log at
  DEBUG. Avoids spamming on every heartbeat tick.

* **ceiling action is a callback, not a hard import** — the monitor
  doesn't import ``signal`` or ``os.kill`` directly. The caller
  passes a callback that does the platform-correct thing. Makes the
  module trivially unit-testable.

* **fail-soft at every layer** — if RSS can't be read, the monitor
  silently returns OK. Memory monitoring is a quality-of-life check,
  never a blocker.
"""

from __future__ import annotations

import logging
import os
import sys
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Final

log = logging.getLogger(__name__)


# arch:deterministic — conservative defaults. A 1500/2500/3500 ladder
# matches a typical personal-machine RAM budget (8-32 GB) where 3.5 GB
# is "yes that's a lot, time to recycle" without being suicidal. Users
# on smaller machines override via YAML.
_DEFAULT_WARN_MB: Final[int] = 1500
_DEFAULT_ALARM_MB: Final[int] = 2500
_DEFAULT_CEILING_MB: Final[int] = 3500


class MemoryAction(Enum):
    """What ``MemoryMonitor.check()`` decided this tick."""

    OK = "ok"
    WARN_CROSSED = "warn_crossed"  # crossed warn threshold this check
    ALARM_CROSSED = "alarm_crossed"  # crossed alarm threshold this check
    CEILING_EXCEEDED = "ceiling_exceeded"  # crossed hard ceiling — shut down
    NO_DATA = "no_data"  # RSS unreadable on this platform


@dataclass(frozen=True)
class MemorySnapshot:
    """One observation of process memory at a point in time."""

    rss_mb: float | None
    action: MemoryAction
    crossed_threshold_mb: int | None  # which threshold value was crossed


@dataclass(frozen=True)
class MemoryMonitorConfig:
    """Threshold ladder. Below warn = OK, above ceiling = shutdown.

    Validated lazily in MemoryMonitor — invalid configs (e.g. warn
    > ceiling) get clamped to the deterministic defaults rather than
    raised, because misconfiguration during boot must NEVER prevent
    the server from starting.
    """

    warn_mb: int = _DEFAULT_WARN_MB
    alarm_mb: int = _DEFAULT_ALARM_MB
    ceiling_mb: int = _DEFAULT_CEILING_MB
    enabled: bool = True

    @classmethod
    def from_yaml_block(cls, block: object) -> MemoryMonitorConfig:
        """Parse a YAML config block, fail-soft on every malformed field."""
        if not isinstance(block, dict):
            return cls()

        def _int(key: str, default: int) -> int:
            try:
                v = int(block.get(key, default))
                return v if v > 0 else default
            except (TypeError, ValueError):
                return default

        warn = _int("warn_mb", _DEFAULT_WARN_MB)
        alarm = _int("alarm_mb", _DEFAULT_ALARM_MB)
        ceiling = _int("ceiling_mb", _DEFAULT_CEILING_MB)
        enabled = bool(block.get("enabled", True))

        # Sanity check the ladder. If invariant warn < alarm < ceiling
        # is broken, fall back to defaults rather than raise — boot
        # must not fail because someone typo'd a YAML.
        if not (warn < alarm < ceiling):
            log.warning(
                "memory_monitor: invalid threshold ladder "
                "warn=%d alarm=%d ceiling=%d, using defaults",
                warn, alarm, ceiling,
            )
            return cls(enabled=enabled)

        return cls(
            warn_mb=warn,
            alarm_mb=alarm,
            ceiling_mb=ceiling,
            enabled=enabled,
        )


def get_rss_mb() -> float | None:
    """Return the current process's resident set size in MB, or None.

    Prefers ``psutil`` (our base dep). Falls back to
    ``resource.getrusage`` on POSIX (KB on Linux, bytes on macOS).
    Returns None when neither path works (Windows without psutil).

    Pure function. Never raises.
    """
    # psutil — accurate on every platform.
    try:
        import psutil  # type: ignore[import-not-found]
        return float(psutil.Process().memory_info().rss) / (1024 * 1024)
    except Exception:  # noqa: BLE001 — psutil could be missing or fail on edge platforms
        pass

    # POSIX fallback — resource module ships with stdlib.
    if sys.platform != "win32":
        try:
            import resource  # type: ignore[import-not-found]
            ru = resource.getrusage(resource.RUSAGE_SELF)
            ru_maxrss = float(ru.ru_maxrss)
            # Linux reports kilobytes; macOS reports bytes. Detect by
            # platform string — both paths are documented in the
            # resource module's __doc__.
            if sys.platform == "darwin":
                return ru_maxrss / (1024 * 1024)
            return ru_maxrss / 1024.0
        except Exception:  # noqa: BLE001
            pass

    return None


# Pure-function threshold classifier — no state, easily unit-testable.
def classify_rss(
    rss_mb: float | None,
    config: MemoryMonitorConfig,
    *,
    last_action: MemoryAction = MemoryAction.OK,
) -> MemorySnapshot:
    """Decide what action this RSS reading triggers.

    Pure function — no side effects, no I/O. The caller passes the
    last action so we can suppress repeat-warns when memory stays
    above the warn threshold for many ticks.

    Rules:
      * RSS unavailable → ``NO_DATA`` (diagnostic only).
      * Disabled config → ``OK`` (kill-switch).
      * RSS > ceiling → always ``CEILING_EXCEEDED`` (shut down).
      * RSS > alarm AND last_action != ALARM_CROSSED →
        ``ALARM_CROSSED``. Subsequent ticks above alarm but below
        ceiling collapse to OK so the log isn't spammed.
      * RSS > warn AND last_action == OK → ``WARN_CROSSED``.
      * Otherwise → ``OK``.
    """
    if rss_mb is None:
        return MemorySnapshot(rss_mb=None, action=MemoryAction.NO_DATA, crossed_threshold_mb=None)

    if not config.enabled:
        return MemorySnapshot(rss_mb=rss_mb, action=MemoryAction.OK, crossed_threshold_mb=None)

    # Ceiling is a one-way door — always trigger, regardless of
    # last_action. The caller's shutdown callback should be idempotent
    # (record_shutdown_reason is first-wins), so a duplicate trigger
    # on the next tick is harmless if the shutdown is in progress.
    if rss_mb >= config.ceiling_mb:
        return MemorySnapshot(
            rss_mb=rss_mb,
            action=MemoryAction.CEILING_EXCEEDED,
            crossed_threshold_mb=config.ceiling_mb,
        )

    if rss_mb >= config.alarm_mb:
        if last_action != MemoryAction.ALARM_CROSSED:
            return MemorySnapshot(
                rss_mb=rss_mb,
                action=MemoryAction.ALARM_CROSSED,
                crossed_threshold_mb=config.alarm_mb,
            )
        return MemorySnapshot(rss_mb=rss_mb, action=MemoryAction.OK, crossed_threshold_mb=None)

    if rss_mb >= config.warn_mb:
        if last_action == MemoryAction.OK:
            return MemorySnapshot(
                rss_mb=rss_mb,
                action=MemoryAction.WARN_CROSSED,
                crossed_threshold_mb=config.warn_mb,
            )
        return MemorySnapshot(rss_mb=rss_mb, action=MemoryAction.OK, crossed_threshold_mb=None)

    return MemorySnapshot(rss_mb=rss_mb, action=MemoryAction.OK, crossed_threshold_mb=None)


class MemoryMonitor:
    """Stateful wrapper around classify_rss for use in the heartbeat.

    Holds the last action so threshold-crossing detection works across
    ticks without the caller threading state through itself.

    Args:
        config: threshold ladder + enabled flag.
        on_ceiling_exceeded: callback invoked when RSS exceeds the
            ceiling. Should record the shutdown reason and trigger
            graceful teardown — typically by calling
            ``signal.raise_signal(signal.SIGINT)``. NEVER raises.
            Idempotent (the callback may fire on multiple consecutive
            ticks if the shutdown takes time to complete).
    """

    def __init__(
        self,
        *,
        config: MemoryMonitorConfig | None = None,
        on_ceiling_exceeded: Callable[[float], None] | None = None,
    ) -> None:
        self._config = config or MemoryMonitorConfig()
        self._on_ceiling = on_ceiling_exceeded
        self._last_action = MemoryAction.OK

    @property
    def config(self) -> MemoryMonitorConfig:
        return self._config

    def check(self) -> MemorySnapshot:
        """Read RSS, classify, fire callback if ceiling crossed.

        Returns the snapshot for the caller to log. Never raises.
        """
        rss = get_rss_mb()
        snapshot = classify_rss(
            rss, self._config, last_action=self._last_action,
        )
        # Update last_action AFTER classification so the next tick's
        # classifier sees the right context. Keep last_action at OK
        # for the NO_DATA case (don't poison subsequent ticks if RSS
        # came back).
        if snapshot.action != MemoryAction.NO_DATA:
            self._last_action = snapshot.action

        if snapshot.action == MemoryAction.CEILING_EXCEEDED and self._on_ceiling:
            try:
                self._on_ceiling(snapshot.rss_mb or 0.0)
            except Exception:  # noqa: BLE001 — callback failure must not break heartbeat
                log.exception("memory_monitor: on_ceiling_exceeded callback raised")

        return snapshot


def default_ceiling_callback(rss_mb: float) -> None:
    """Standard ceiling action: record shutdown reason + raise SIGINT.

    The agntspace lifespan signal-handler chain catches SIGINT and
    triggers graceful teardown: lifespan exit → record_shutdown_reason
    chain → atexit hook fires with the recorded reason → launcher
    (chunk 2) sees clean exit and does NOT respawn (because the
    record_shutdown_reason call here pre-empts the "lifespan_clean
    _shutdown" reason; the recorded reason is preserved through
    teardown).

    On Windows, ``signal.raise_signal(signal.SIGINT)`` is the right
    primitive (Python 3.8+). On POSIX, same primitive works.

    Idempotent — safe to call multiple times in a row. The first call
    records the reason and raises SIGINT; subsequent calls find the
    reason already set (first-wins) and try to raise SIGINT again,
    which uvicorn's handler swallows gracefully.
    """
    import signal

    try:
        from agntspace.infra.diagnostics import record_shutdown_reason
        record_shutdown_reason(f"memory_ceiling_exceeded:{rss_mb:.0f}MB")
    except Exception:  # noqa: BLE001
        log.exception("memory_monitor: failed to record shutdown reason")

    try:
        signal.raise_signal(signal.SIGINT)
    except Exception:  # noqa: BLE001 — fall back to os.kill if raise_signal is unavailable
        try:
            os.kill(os.getpid(), signal.SIGINT)
        except Exception:  # noqa: BLE001
            log.exception(
                "memory_monitor: could not signal self for graceful "
                "shutdown — process will continue running until OS "
                "intervenes (likely SIGKILL)",
            )
