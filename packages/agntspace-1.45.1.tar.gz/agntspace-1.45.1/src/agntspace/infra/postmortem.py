"""Post-mortem log analysis — surfaces WHY the server is down.

Closes chunk 5 of the 2026-05-05 reliability session. Chunks 1-4
recorded WHY each death happened; this chunk surfaces that record to
the user via ``agntspace why-down``.

Reads three independent log streams and synthesizes a narrative:

* ``supervisor.log`` (chunk 2) — JSONL events from the launcher:
  spawn / clean / crash / give-up / interrupted. Tells us what the
  launcher saw: how many times the server crashed, when it gave up.

* ``agntspace.log`` — the server's structured log. The chunk-1
  atexit hook writes a final ``Process <pid> exiting: <reason>``
  line on EVERY interpreter exit. We grep the most recent one to
  recover the last clean-shutdown reason.

* ``crash.log`` (chunk 1) — faulthandler dumps. Each session that
  exits via fatal signal leaves a traceback chunk. Latest section
  is the most recent native crash.

* lock file (process_lock.py) — current PID + heartbeat age. Tells
  us whether the server is RUNNING NOW vs DOWN.

The analyzer is a pure function for unit testability. The CLI
command ``agntspace why-down`` (in cli.py) calls it and pretty-prints.

Design choices:

* **all log reads are best-effort** — missing / unreadable / huge
  files all degrade to None, never raise. The tool's job is to be
  USEFUL on the user's worst day; refusing to run because one log
  is corrupt would be the opposite of helpful.

* **bounded reads** — we tail the last N KB of each file rather
  than reading the whole thing. Production logs grow; reading 100MB
  of agntspace.log to find the last "exiting" line is silly.

* **JSONL parsing is per-line resilient** — one corrupt line doesn't
  abort the whole supervisor.log scan.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path

log = logging.getLogger(__name__)

# arch:deterministic — bound the tail size we read from each log.
# 256 KB is comfortably more than a day's worth of typical heartbeat
# log lines and faulthandler dumps; adjust upward if a future log
# format becomes denser.
_TAIL_BYTES_DEFAULT = 256 * 1024


def _tail_bytes(path: Path | None, max_bytes: int = _TAIL_BYTES_DEFAULT) -> str:
    """Return the last ``max_bytes`` of ``path`` as a UTF-8 string.

    Empty string on any failure (missing file, permission denied,
    huge-then-truncated read). Pure read; never raises.
    """
    if path is None or not isinstance(path, Path):
        return ""
    try:
        if not path.is_file():
            return ""
        size = path.stat().st_size
        with open(path, "rb") as fh:
            if size > max_bytes:
                fh.seek(size - max_bytes)
            data = fh.read()
        return data.decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        return ""


# Match the chunk-1 atexit hook's exit line:
#   "[agntspace] Process <pid> exiting: <reason> (at <iso>)"
# OR the structured log line:
#   "Process exiting: <reason>"
_EXIT_LINE_RE = re.compile(
    r"Process(?:\s+\d+)?\s+exiting:\s*(?P<reason>[^\(]+?)(?:\s+\(at\s+(?P<ts>[^\)]+)\))?\s*$",
    re.MULTILINE,
)


def find_last_exit_record(log_text: str) -> dict | None:
    """Find the most recent ``Process exiting: <reason>`` line.

    Returns ``{"reason": str, "ts": str | None}`` or None.
    Pure function — no I/O.
    """
    if not log_text:
        return None
    last: dict | None = None
    for m in _EXIT_LINE_RE.finditer(log_text):
        reason = (m.group("reason") or "").strip()
        ts = (m.group("ts") or "").strip() or None
        if reason:
            last = {"reason": reason, "ts": ts}
    return last


def parse_supervisor_jsonl(text: str) -> list[dict]:
    """Parse a JSONL string into a list of event dicts.

    Per-line resilient: a corrupt line is skipped, not fatal. Lines
    without a recognized ``kind`` are kept verbatim — the caller
    can decide what to do with them.
    """
    events: list[dict] = []
    if not text:
        return events
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:  # noqa: BLE001
            continue
        if isinstance(obj, dict):
            events.append(obj)
    return events


def summarize_supervisor_events(
    events: list[dict],
    *,
    since_iso: str | None = None,
) -> dict:
    """Aggregate supervisor events into a summary dict.

    Returns counts by kind, the last event of each interesting kind,
    and a "recent" slice (newest 10) for printing.

    Optional ``since_iso``: if provided, only events with ``ts`` (epoch
    float) > parsed since are counted. Used to scope to "this session"
    or "today".
    """
    cutoff: float | None = None
    if since_iso:
        try:
            cutoff = datetime.fromisoformat(since_iso).timestamp()
        except Exception:  # noqa: BLE001
            cutoff = None

    counts: dict[str, int] = {}
    last_by_kind: dict[str, dict] = {}

    for ev in events:
        ts = ev.get("ts")
        if cutoff is not None and isinstance(ts, (int, float)) and ts < cutoff:
            continue
        kind = ev.get("kind", "")
        if not isinstance(kind, str) or not kind:
            continue
        counts[kind] = counts.get(kind, 0) + 1
        last_by_kind[kind] = ev

    return {
        "counts": counts,
        "last_by_kind": last_by_kind,
        "recent": events[-10:],
        "total_events": len(events),
    }


def parse_lock_state(lock_path: Path | None, *, now: datetime | None = None) -> dict:
    """Read the vault process lock file and report state.

    Returns:
        ``{"present": bool, "pid": int | None, "started_at": str | None,
           "heartbeat_at": str | None, "heartbeat_age_seconds": float | None,
           "stale": bool}``

    "stale" means the heartbeat age exceeds a typical liveness threshold
    (60 seconds — the lock heartbeat fires every 10s, so 60s is 6
    missed beats). The actual ProcessLock's stale-reclaim threshold is
    30s but we use 60s here for "is the server even alive right now"
    leniency.
    """
    if lock_path is None or not lock_path.is_file():
        return {
            "present": False,
            "pid": None,
            "started_at": None,
            "heartbeat_at": None,
            "heartbeat_age_seconds": None,
            "stale": False,
        }

    try:
        text = lock_path.read_text(encoding="utf-8")
        data = json.loads(text)
    except Exception:  # noqa: BLE001
        return {
            "present": True,
            "pid": None,
            "started_at": None,
            "heartbeat_at": None,
            "heartbeat_age_seconds": None,
            "stale": True,
            "error": "lock_unreadable",
        }

    if not isinstance(data, dict):
        return {
            "present": True,
            "pid": None,
            "started_at": None,
            "heartbeat_at": None,
            "heartbeat_age_seconds": None,
            "stale": True,
            "error": "lock_malformed",
        }

    heartbeat_at = data.get("heartbeat_at")
    age_seconds: float | None = None
    stale = False
    try:
        if heartbeat_at:
            hb_dt = datetime.fromisoformat(heartbeat_at)
            now_dt = now or datetime.now(UTC)
            # Normalize to aware datetime — the lock writes ISO with
            # tzinfo. now defaults to UTC so subtraction works.
            if hb_dt.tzinfo is None:
                hb_dt = hb_dt.replace(tzinfo=UTC)
            age_seconds = (now_dt - hb_dt).total_seconds()
            stale = age_seconds > 60.0
    except Exception:  # noqa: BLE001
        age_seconds = None
        stale = True

    return {
        "present": True,
        "pid": data.get("pid"),
        "started_at": data.get("started_at"),
        "heartbeat_at": heartbeat_at,
        "heartbeat_age_seconds": age_seconds,
        "stale": stale,
    }


def find_latest_faulthandler_section(crash_text: str) -> str | None:
    """Return the most recent faulthandler dump section, or None.

    Sections are delimited by lines like:
        ``=== faulthandler armed at 2026-05-05T08:25:06+00:00 pid=12345 ===``

    The "latest" section is everything from the last marker to EOF.
    None when no marker is found OR when the section is empty.
    """
    if not crash_text:
        return None
    marker_re = re.compile(r"^===\s+faulthandler armed at .+\s+===\s*$", re.MULTILINE)
    matches = list(marker_re.finditer(crash_text))
    if not matches:
        return None
    last = matches[-1]
    section = crash_text[last.start() :].strip()
    return section if section else None


def analyze_post_mortem(
    *,
    supervisor_log: Path | None = None,
    agntspace_log: Path | None = None,
    crash_log: Path | None = None,
    lock_file: Path | None = None,
    now: datetime | None = None,
) -> dict:
    """Synthesize a structured post-mortem report.

    All inputs are paths the caller resolves; this function does the
    bounded reads + parsing. Returns a dict suitable for both
    machine-readable consumption (e.g. ``/api/health/why-down``) and
    pretty-printing by the CLI command.

    Shape::

        {
            "lock_state": {present, pid, ...},
            "last_exit": {"reason": str, "ts": str | None} | None,
            "supervisor": {counts, last_by_kind, recent, total_events},
            "crash": {"present": bool, "section": str | None},
            "verdict": str,  # one-line human summary
            "verdict_kind": str,  # machine-friendly: "running_clean" |
                                  # "running_unhealthy" | "down_clean" |
                                  # "down_crash" | "down_unknown" |
                                  # "down_crash_loop_break"
        }
    """
    now_dt = now or datetime.now(UTC)

    sup_text = _tail_bytes(supervisor_log)
    sup_events = parse_supervisor_jsonl(sup_text)
    sup_summary = summarize_supervisor_events(sup_events)

    agnt_text = _tail_bytes(agntspace_log)
    last_exit = find_last_exit_record(agnt_text)

    crash_text = _tail_bytes(crash_log)
    crash_section = find_latest_faulthandler_section(crash_text)

    lock_state = parse_lock_state(lock_file, now=now_dt)

    verdict, verdict_kind = _build_verdict(
        lock_state=lock_state,
        last_exit=last_exit,
        supervisor=sup_summary,
        crash_present=crash_section is not None,
    )

    return {
        "lock_state": lock_state,
        "last_exit": last_exit,
        "supervisor": sup_summary,
        "crash": {
            "present": crash_section is not None,
            "section": crash_section,
        },
        "verdict": verdict,
        "verdict_kind": verdict_kind,
    }


def _build_verdict(
    *,
    lock_state: dict,
    last_exit: dict | None,
    supervisor: dict,
    crash_present: bool,
) -> tuple[str, str]:
    """Render a one-line verdict + machine-friendly kind. Pure helper."""
    sup_counts: dict[str, int] = supervisor.get("counts", {})  # type: ignore[assignment]

    # Currently running?
    running = lock_state.get("present") and not lock_state.get("stale")

    if running:
        # Live process — verdict reflects health
        crashes = sup_counts.get("child_crashed", 0)
        if crashes > 0:
            return (
                f"Server is running (pid={lock_state.get('pid')}) but the "
                f"launcher has logged {crashes} child crash(es) recently. "
                f"Check 'agntspace why-down' history.",
                "running_unhealthy",
            )
        return (
            f"Server is running cleanly (pid={lock_state.get('pid')}, "
            f"heartbeat {lock_state.get('heartbeat_age_seconds', 0):.0f}s ago).",
            "running_clean",
        )

    # Server is down. Pick the most informative reason.
    if "supervisor_crash_loop_break" in sup_counts:
        return (
            "Server is down. The launcher hit its crash-loop break — "
            "5+ unclean exits in 5 minutes. Manual intervention required.",
            "down_crash_loop_break",
        )

    if crash_present:
        return (
            "Server is down. A native crash was recorded (see crash.log "
            "for the faulthandler traceback).",
            "down_crash",
        )

    if last_exit and last_exit.get("reason"):
        reason = last_exit["reason"]
        if "lifespan_clean_shutdown" in reason or "no_reason_recorded" in reason:
            return (
                f"Server is down. Last exit was clean: {reason}.",
                "down_clean",
            )
        if "memory_ceiling_exceeded" in reason:
            return (
                f"Server is down. Last exit: {reason}. Restart to recover.",
                "down_crash",
            )
        return (
            f"Server is down. Last recorded reason: {reason}.",
            "down_crash",
        )

    return (
        "Server is down. No exit reason was recorded — likely a hard "
        "kill (SIGKILL, OOM, Task Manager, power loss). External "
        "supervisor (Task Scheduler / systemd / launchd) should restart "
        "it on the next trigger.",
        "down_unknown",
    )


def format_human_report(analysis: dict) -> str:
    """Pretty-print an analyze_post_mortem result for the CLI.

    Returns a multi-line string suitable for ``console.print`` / stdout.
    No color codes — caller can apply Rich markup if desired.
    """
    lines: list[str] = []
    lines.append(analysis.get("verdict", "(no verdict)"))
    lines.append("")

    lock = analysis.get("lock_state") or {}
    if lock.get("present"):
        age = lock.get("heartbeat_age_seconds")
        age_str = f"{age:.0f}s ago" if age is not None else "?"
        stale_str = " [STALE]" if lock.get("stale") else ""
        lines.append(
            f"  Lock file:     pid={lock.get('pid')} "
            f"started_at={lock.get('started_at') or '?'} "
            f"heartbeat={age_str}{stale_str}"
        )
    else:
        lines.append("  Lock file:     not present (server hasn't been started recently)")

    last_exit = analysis.get("last_exit")
    if last_exit:
        reason = last_exit.get("reason") or "?"
        ts = last_exit.get("ts") or "?"
        lines.append(f"  Last exit:     {reason} (at {ts})")
    else:
        lines.append("  Last exit:     no exit line found in agntspace.log")

    sup = analysis.get("supervisor") or {}
    counts: dict[str, int] = sup.get("counts") or {}  # type: ignore[assignment]
    if counts:
        crash_count = counts.get("child_crashed", 0)
        clean_count = counts.get("child_exited_clean", 0)
        spawn_count = counts.get("child_spawned", 0)
        loop_break = counts.get("supervisor_crash_loop_break", 0)
        lines.append(
            f"  Supervisor:    {spawn_count} spawn(s), {clean_count} clean exit(s), "
            f"{crash_count} crash(es), {loop_break} crash-loop break(s)"
        )
    else:
        lines.append("  Supervisor:    no events logged (launcher hasn't run, or log is empty)")

    crash = analysis.get("crash") or {}
    if crash.get("present"):
        lines.append("  Native crash:  recorded in crash.log (see file for traceback)")
    else:
        lines.append("  Native crash:  none recorded")

    # Recent supervisor events
    recent = sup.get("recent") or []
    if recent:
        lines.append("")
        lines.append("  Recent launcher events (newest last):")
        for ev in recent[-5:]:  # last 5 for compact output
            kind = ev.get("kind", "?")
            ts = ev.get("ts")
            ts_str = ""
            if isinstance(ts, (int, float)):
                try:
                    ts_str = datetime.fromtimestamp(ts, tz=UTC).strftime("%H:%M:%S")
                except Exception:  # noqa: BLE001
                    ts_str = "?"
            lines.append(f"    {ts_str:>8s}  {kind}")

    return "\n".join(lines)
