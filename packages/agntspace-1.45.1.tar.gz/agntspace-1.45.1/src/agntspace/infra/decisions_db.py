"""Separate SQLite file for the DecisionLogger audit trail.

Shipped 2026-04-30 to close the "100% decision_log write failures under
KB-pipeline lock contention" bleed. The DecisionLogger formerly shared
``agntspace.db`` with conversations, dispatch_log, canvas, FTS, regression
tests, scope_file_writes, and a dozen other tables. SQLite WAL allows
concurrent readers but only ONE writer at a time per file — when the KB
compile pipeline + entity_registry + graph saves all hammer agntspace.db,
the decision_log writer queues behind them, and on heavy vaults every
write times out at the 30s busy_timeout and gets silently swallowed.

The fix: give the DecisionLogger its OWN file at ``<vault>/agntspace/audit.db``.
Sibling SQLite files have independent writer locks. KB pipeline contention
on agntspace.db cannot starve audit.db writes.

This is a partial mitigation toward the full 4-way split documented in
``tasks/plan-db-split.md`` — picked first because every observability
surface in the app is downstream of decision_log persistence (the
dashboard's "done today" counter, the /decisions causal chain view,
SkillSchool's zero-effect detector, the trust feedback loop). When
decision_log writes fail, every accountability surface lies.

Boot-time migration: existing rows in ``agntspace.db.decision_log`` are
copied into ``audit.db.decision_log`` via ``INSERT OR IGNORE`` keyed on
the original ``id``. Idempotent — safe to re-run on every boot. After
the first successful migration, every subsequent boot is a fast no-op
because the destination already has every row.
"""

from __future__ import annotations

import logging
from pathlib import Path

import aiosqlite

log = logging.getLogger(__name__)


async def get_decisions_db(audit_path: Path) -> aiosqlite.Connection:
    """Open the audit.db connection with the same PRAGMAs as the main db.

    Symmetric configuration is load-bearing — when two SQLite connections
    share a file they must agree on busy_timeout / journal_mode / synchronous
    or one side wins the contention races against the other (lesson from
    2026-04-29 morning's session). Here the audit.db file is exclusively
    owned by this connection (DecisionLogger is the sole writer), so the
    PRAGMAs only need to be self-consistent — but we mirror the main db's
    settings anyway so the file behaves identically under stress.
    """
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(audit_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA busy_timeout=30000")
    await db.execute("PRAGMA synchronous=NORMAL")
    # WAL auto-checkpoint at 200 pages (~800 KB). Default is 1000 pages
    # (~4 MB). DecisionLogger writes are append-only and small (~2-3 KB
    # per row), so a lower threshold keeps the WAL bounded without firing
    # too often. Without an explicit threshold, the WAL grew to 2.6 MB on
    # the user's vault between sessions and every read had to walk the
    # entire WAL — measured 8 s on `/api/health`.
    await db.execute("PRAGMA wal_autocheckpoint=200")
    # One-time TRUNCATE checkpoint at open to flush any pre-existing WAL
    # accumulation. Safe — WAL is durable until checkpoint fires; the
    # checkpoint just merges it back into the main db file. After this
    # call, audit.db-wal is empty (or nearly so) and read latency drops.
    # NB: TRUNCATE is the most aggressive mode; if there are concurrent
    # readers it may downgrade to PASSIVE silently, which is fine.
    try:
        await db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        log.debug("audit.db wal_checkpoint failed (non-fatal)", exc_info=True)
    await db.commit()
    return db


# Columns we expect on decision_log rows after every migration in
# DecisionLogger._MIGRATIONS has been applied. Used by the migration helper
# to build the INSERT statement against the destination. Mirroring the
# DecisionLogger v1.4 schema documented in activity/decisions.py.
_DECISION_LOG_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "ts",
    "actor",
    "action_type",
    "action_target",
    "contract_action",
    "contract_result",
    "triggered_by",
    "context_skills",
    "rationale",
    "details",
    "context_memories",
    "correlation_id",
    "goal_id",
    "trust_level",
    "trust_domain",
    "result_status",
    "duration_ms",
    "error_type",
    "policy_id",
    "run_id",
)


async def migrate_decision_log_to_audit_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of decision_log rows from agntspace.db into audit.db.

    Reads every row from ``source_db.decision_log`` and INSERT OR IGNOREs
    into ``target_db.decision_log`` keyed on ``id``. Re-running is a fast
    no-op once the destination is fully caught up — every row collides on
    its primary key and gets skipped.

    Conservative on edge cases:
    - Source table missing (fresh install, never had a decision log) → 0 copied
    - Target schema not yet initialized → returns ``{copied: 0, skipped: 0}``
      and the DecisionLogger's own ``initialize()`` runs first on next call
    - Per-batch failure → counted, never raised; partial progress preserved
      because each batch commits independently

    Returns ``{copied, already_present, source_total, batches_failed}`` so
    the caller can log a clear migration summary.
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    # Source might not have the table yet — fresh install path.
    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='decision_log'",
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("decision_log migration: failed to inspect source schema")
        return result
    if not row:
        return result

    # Target must have the schema initialized before we can insert.
    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='decision_log'",
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("decision_log migration: failed to inspect target schema")
        return result
    if not target_row:
        # Caller forgot to initialize the DecisionLogger first. Don't try to
        # second-guess the schema — let initialize() run, then the next boot
        # picks up the migration.
        log.warning(
            "decision_log migration: target audit.db has no decision_log table yet; "
            "initialize DecisionLogger first, then re-run migration",
        )
        return result

    # Count source rows for the summary.
    try:
        cur = await source_db.execute("SELECT COUNT(*) FROM decision_log")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("decision_log migration: failed to count source rows")
        return result

    if result["source_total"] == 0:
        return result

    # Resolve which columns the source actually has (older rows may pre-date
    # later migrations); intersect with our canonical column list. Order is
    # preserved so INSERT and SELECT match positionally.
    try:
        cur = await source_db.execute("PRAGMA table_info(decision_log)")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("decision_log migration: failed to read source schema")
        return result

    cols = tuple(c for c in _DECISION_LOG_COLUMNS if c in source_cols)
    if not cols:
        log.warning("decision_log migration: source table has none of the expected columns")
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = (
        f"INSERT OR IGNORE INTO decision_log ({col_list}) VALUES ({placeholders})"
    )
    select_sql = (
        f"SELECT {col_list} FROM decision_log ORDER BY id ASC LIMIT ? OFFSET ?"
    )

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            # Capture the cumulative-changes counter before the batch so we
            # can subtract it after to get the actual insert delta. aiosqlite
            # exposes ``total_changes`` as a property on the underlying
            # connection. Per-batch commit means a partial failure preserves
            # earlier batches.
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("decision_log migration: batch at offset=%d failed", offset)
            offset += batch_size  # advance past the bad batch; don't loop forever

    return result


# Columns expected on cost_log rows after every migration in CostTracker
# init_schema has been applied. Mirrors the schema in
# infra/cost_tracker.py:init_schema. Keep order stable for column-positional
# INSERT.
_COST_LOG_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "timestamp",
    "model",
    "input_tokens",
    "output_tokens",
    "estimated_cost",
    "conversation_id",
    "action",
    "cache_read_tokens",
    "cache_write_tokens",
    "goal_id",
)


async def migrate_cost_log_to_audit_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of cost_log rows from agntspace.db to audit.db.

    Stage B.2 of the DB split (shipped 2026-05-05). Mirrors
    ``migrate_decision_log_to_audit_db`` exactly — same shape, same
    invariants, different table. cost_log moves to audit.db because LLM
    cost records are append-only audit data with the same
    contention-sensitive write profile as decision_log.

    Returns ``{copied, already_present, source_total, batches_failed}``.
    Conservative on every edge:
      - Source table missing (fresh install) → 0 copied
      - Target schema not yet initialized → 0 copied with a WARNING log;
        ``CostTracker.init_schema()`` runs first, then re-run migration
        on next boot
      - Per-batch failure → counted, never raised; partial progress
        preserved
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    # Source might not have the table — fresh install path.
    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='cost_log'",
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("cost_log migration: failed to inspect source schema")
        return result
    if not row:
        return result

    # Target must have the schema initialized.
    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='cost_log'",
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("cost_log migration: failed to inspect target schema")
        return result
    if not target_row:
        log.warning(
            "cost_log migration: target audit.db has no cost_log table yet; "
            "initialize CostTracker first, then re-run migration",
        )
        return result

    # Count source rows for the summary.
    try:
        cur = await source_db.execute("SELECT COUNT(*) FROM cost_log")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("cost_log migration: failed to count source rows")
        return result

    if result["source_total"] == 0:
        return result

    # Resolve which canonical columns the source actually has — older
    # rows may pre-date later migrations (e.g. the 2026-04 cache_token
    # additions). Intersect with the canonical list to keep the INSERT
    # portable against schema drift.
    try:
        cur = await source_db.execute("PRAGMA table_info(cost_log)")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("cost_log migration: failed to read source schema")
        return result

    cols = tuple(c for c in _COST_LOG_COLUMNS if c in source_cols)
    if not cols:
        log.warning("cost_log migration: source has none of the expected columns")
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO cost_log ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM cost_log ORDER BY id ASC LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("cost_log migration: batch at offset=%d failed", offset)
            offset += batch_size

    return result


# Columns expected on error_logs rows. Mirrors the schema in
# infra/error_logger.py:init_schema. Stable order for column-positional
# INSERT.
_ERROR_LOGS_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "timestamp",
    "level",
    "source",
    "message",
    "error_type",
    "traceback",
    "context",
    "request_method",
    "request_path",
    "status_code",
    "resolved",
    "created_at",
)


async def migrate_error_logs_to_audit_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of error_logs rows from agntspace.db to audit.db.

    Stage B.2 round 2 of the DB split (shipped 2026-05-05). Mirrors
    ``migrate_decision_log_to_audit_db`` and ``migrate_cost_log_to_audit_db``
    exactly — same shape, same invariants, different table. error_logs
    moves to audit.db because errors are append-only audit data with the
    same write profile as decision_log + cost_log.

    Returns ``{copied, already_present, source_total, batches_failed}``.
    Conservative on every edge: missing source / missing target / per-batch
    failure all degrade gracefully.
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='error_logs'",
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("error_logs migration: failed to inspect source schema")
        return result
    if not row:
        return result

    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='error_logs'",
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("error_logs migration: failed to inspect target schema")
        return result
    if not target_row:
        log.warning(
            "error_logs migration: target audit.db has no error_logs table yet; "
            "initialize ErrorLogger first, then re-run migration",
        )
        return result

    try:
        cur = await source_db.execute("SELECT COUNT(*) FROM error_logs")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("error_logs migration: failed to count source rows")
        return result

    if result["source_total"] == 0:
        return result

    try:
        cur = await source_db.execute("PRAGMA table_info(error_logs)")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("error_logs migration: failed to read source schema")
        return result

    cols = tuple(c for c in _ERROR_LOGS_COLUMNS if c in source_cols)
    if not cols:
        log.warning("error_logs migration: source has none of the expected columns")
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO error_logs ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM error_logs ORDER BY id ASC LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("error_logs migration: batch at offset=%d failed", offset)
            offset += batch_size

    return result


# Columns expected on scope_file_writes rows. Mirrors the schema in
# vault/scope_writes.py:_get_conn (the recorder now self-creates
# the table since 2026-05-05). Stable order for column-positional INSERT.
_SCOPE_FILE_WRITES_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "correlation_id",
    "path",
    "action",
    "pre_hash",
    "history_version",
    "post_hash",
    "written_at",
)


async def migrate_scope_file_writes_to_audit_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of scope_file_writes rows from agntspace.db to audit.db.

    Stage B.2 round 3 of the DB split (shipped 2026-05-05). Mirrors
    ``migrate_decision_log_to_audit_db`` /
    ``migrate_cost_log_to_audit_db`` /
    ``migrate_error_logs_to_audit_db`` exactly — same shape, different
    table. scope_file_writes moves to audit.db because the recorder is
    append-only audit data; a sibling SQLite file gives it an
    independent writer lock.

    Returns ``{copied, already_present, source_total, batches_failed}``.
    Conservative on every edge: missing source / missing target /
    per-batch failure all degrade gracefully.

    NOTE: ``ScopeWritesRecorder`` uses a sync ``sqlite3`` connection on
    its own (the live writer path doesn't go through this async
    function). This helper is ONLY for the boot-time row copy from the
    legacy agntspace.db to the new audit.db location. Both ``source_db``
    and ``target_db`` are the existing aiosqlite connections.
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='scope_file_writes'",
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("scope_file_writes migration: failed to inspect source schema")
        return result
    if not row:
        return result

    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='scope_file_writes'",
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("scope_file_writes migration: failed to inspect target schema")
        return result
    if not target_row:
        log.warning(
            "scope_file_writes migration: target audit.db has no scope_file_writes "
            "table yet; ScopeWritesRecorder creates it on first write — "
            "trigger one or re-run migration on next boot",
        )
        return result

    try:
        cur = await source_db.execute("SELECT COUNT(*) FROM scope_file_writes")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("scope_file_writes migration: failed to count source rows")
        return result

    if result["source_total"] == 0:
        return result

    try:
        cur = await source_db.execute("PRAGMA table_info(scope_file_writes)")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("scope_file_writes migration: failed to read source schema")
        return result

    cols = tuple(c for c in _SCOPE_FILE_WRITES_COLUMNS if c in source_cols)
    if not cols:
        log.warning("scope_file_writes migration: source has none of the expected columns")
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO scope_file_writes ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM scope_file_writes ORDER BY id ASC LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("scope_file_writes migration: batch at offset=%d failed", offset)
            offset += batch_size

    return result


# Columns expected on dispatch_log rows. Mirrors the schema in
# agent/orchestrator.py:init_dispatch_log_schema (the orchestrator now
# self-creates the table since 2026-05-05). Stable order for
# column-positional INSERT.
_DISPATCH_LOG_COLUMNS = (  # arch:deterministic — schema column order
    "id",
    "agent_key",
    "agent_name",
    "task",
    "context",
    "project",
    "status",
    "content",
    "input_tokens",
    "output_tokens",
    "started_at",
    "completed_at",
    "duration_ms",
    "goal_id",
)


async def migrate_dispatch_log_to_audit_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of dispatch_log rows from agntspace.db to audit.db.

    Stage B.2 round 4 of the DB split (shipped 2026-05-05) — the last
    audit-style table moves off agntspace.db. dispatch_log is append-
    only timeline data with the same write profile as decision_log /
    cost_log / error_logs / scope_file_writes; siblings on audit.db get
    independent writer locks.

    Returns ``{copied, already_present, source_total, batches_failed}``.
    Conservative on every edge: missing source / missing target /
    per-batch failure all degrade gracefully.
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    try:
        cur = await source_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='dispatch_log'",
        )
        row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("dispatch_log migration: failed to inspect source schema")
        return result
    if not row:
        return result

    try:
        cur = await target_db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='dispatch_log'",
        )
        target_row = await cur.fetchone()
        await cur.close()
    except Exception:
        log.exception("dispatch_log migration: failed to inspect target schema")
        return result
    if not target_row:
        log.warning(
            "dispatch_log migration: target audit.db has no dispatch_log table yet; "
            "call orchestrator.init_dispatch_log_schema() first, then re-run migration",
        )
        return result

    try:
        cur = await source_db.execute("SELECT COUNT(*) FROM dispatch_log")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:
        log.exception("dispatch_log migration: failed to count source rows")
        return result

    if result["source_total"] == 0:
        return result

    try:
        cur = await source_db.execute("PRAGMA table_info(dispatch_log)")
        info_rows = await cur.fetchall()
        await cur.close()
        source_cols = {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:
        log.exception("dispatch_log migration: failed to read source schema")
        return result

    cols = tuple(c for c in _DISPATCH_LOG_COLUMNS if c in source_cols)
    if not cols:
        log.warning("dispatch_log migration: source has none of the expected columns")
        return result

    col_list = ", ".join(cols)
    placeholders = ", ".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO dispatch_log ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM dispatch_log ORDER BY id ASC LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:
            result["batches_failed"] += 1
            log.exception("dispatch_log migration: batch at offset=%d failed", offset)
            offset += batch_size

    return result
