"""Crash + shutdown diagnostics for the AgntSpace server process.

Closes the "more down than up" reliability gap surfaced 2026-05-05: the
server died at 08:37 UTC with no traceback, no exit log, no shutdown
signal recorded — the heartbeat just stopped. We literally didn't know
why. Three layers fix that class of mystery:

1. **Fatal-signal traceback** — ``faulthandler.enable()`` registers
   handlers for SIGSEGV / SIGFPE / SIGABRT / SIGBUS / SIGILL that dump
   the Python traceback of EVERY thread to a dedicated crash log
   before the process aborts. Native crashes (C extensions, OOM-killed
   threads inside libraries) become visible.

2. **Shutdown-reason tracker** — a module-level ``_shutdown_reason``
   string set by signal handlers, lifespan teardown, and uncaught
   exception handlers. First non-empty reason wins. Surfaced via
   ``app.state.shutdown_reason`` and via the atexit-logged final line.

3. **`atexit` hook** — runs on ANY interpreter exit (clean shutdown,
   ``sys.exit()``, uncaught exception, normal teardown). Last chance to
   log "process exiting: <reason>" to the agntspace.log so post-mortems
   have something to grep. Print to stderr too — log handlers may have
   already torn down.

Design choices:

* **fail-soft at every layer**: if faulthandler can't open the crash
  log, log a warning and continue. Diagnostics MUST NEVER prevent the
  server from booting.

* **chain signal handlers** rather than replacing them. uvicorn's
  default SIGINT/SIGTERM handling triggers graceful lifespan teardown;
  we record the reason and call uvicorn's previous handler so teardown
  still runs.

* **deliberately no SIGTERM/SIGINT explicit handler** in the simplest
  shipping version — uvicorn already handles them, and chaining adds
  fragility. Atexit catches the final "we exited" beat regardless. If
  graceful-kill reasons need finer granularity (Task Scheduler stop vs.
  Ctrl-C), revisit.

* **threading.Lock not asyncio.Lock**: signal handlers run sync, in the
  main thread. Atexit runs sync. This is the rare case where threading
  primitives are correct.

This is engine substrate (Rule 12). Tunable knobs (path, timeout for
hang detection, etc.) live in ``defaults/skills/_meta/process-health/``
when wired into a YAML; for now defaults are deterministic and baked.
"""

from __future__ import annotations

import atexit
import faulthandler
import logging
import os
import sys
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


# arch:deterministic — module-level singletons for shutdown tracking.
# Threading lock because signal handlers + atexit run in unknown thread
# contexts (faulthandler runs from C signal context, atexit runs in
# Python finalization).
_shutdown_reason: str = ""
_shutdown_reason_lock = threading.Lock()
_install_lock = threading.Lock()
_installed: bool = False
_atexit_registered: bool = False  # separate from _installed: atexit can't be unregistered cleanly, only register once per process
_crash_log_handle: Any = None  # file handle kept open for faulthandler
_prev_sys_excepthook: Any = None  # restored on teardown for test isolation
_prev_threading_excepthook: Any = None


def record_shutdown_reason(reason: str) -> None:
    """Record why the process is exiting. First non-empty reason wins.

    Called from:
      * lifespan teardown (clean path → "lifespan_clean_shutdown")
      * signal handlers (graceful kill → "signal:SIGTERM" etc.)
      * uncaught exception handlers (crash → "uncaught_exception:...")
      * atexit hook (last-resort → "interpreter_exit_no_reason")

    Subsequent calls with a reason are ignored — we want the FIRST
    cause, not whatever cleanup code added on top.
    """
    global _shutdown_reason
    if not isinstance(reason, str) or not reason.strip():
        return
    with _shutdown_reason_lock:
        if not _shutdown_reason:
            _shutdown_reason = reason.strip()


def get_shutdown_reason() -> str:
    """Return the recorded shutdown reason, or empty string if none."""
    with _shutdown_reason_lock:
        return _shutdown_reason


def install_diagnostics(log_dir: Path) -> dict[str, Any]:
    """Install crash + shutdown diagnostics. Idempotent — safe to call twice.

    Args:
        log_dir: Directory where ``crash.log`` will live. Caller must
            ensure it exists (we mkdir defensively but don't raise on
            failure — diagnostics never block boot).

    Returns:
        Diagnostic info dict for surfacing via /api/health or similar:
        ``{"installed": bool, "crash_log": str, "errors": [...]}``.
    """
    global _installed, _crash_log_handle, _atexit_registered  # noqa: PLW0603
    global _prev_sys_excepthook, _prev_threading_excepthook  # noqa: PLW0603

    with _install_lock:
        if _installed:
            return {
                "installed": True,
                "crash_log": str(log_dir / "crash.log"),
                "errors": [],
                "already_installed": True,
            }

        errors: list[str] = []
        crash_log_path = log_dir / "crash.log"

        # ── Layer 1: faulthandler ──────────────────────────────────────
        # Captures fatal signals (SIGSEGV / SIGFPE / SIGABRT / SIGBUS /
        # SIGILL) and dumps every thread's Python traceback to the
        # crash log before the process aborts. Native-extension crashes
        # become diagnosable.
        try:
            crash_log_path.parent.mkdir(parents=True, exist_ok=True)
            # buffering=1 = line-buffered; we want every line flushed
            # immediately because the process may abort right after.
            # noqa SIM115: deliberate — handle must stay open for the
            # process lifetime so faulthandler can write to it on a
            # fatal signal. Closed by ``teardown_diagnostics``.
            handle = open(crash_log_path, "a", buffering=1, encoding="utf-8")  # noqa: SIM115
            # Stamp a session marker so successive crashes are
            # distinguishable in the log.
            handle.write(
                f"\n=== faulthandler armed at {datetime.now(UTC).isoformat()} pid={os.getpid()} ===\n"
            )
            handle.flush()
            faulthandler.enable(handle, all_threads=True)
            _crash_log_handle = handle
            log.info(
                "Diagnostic layer: faulthandler enabled, crash log at %s",
                crash_log_path,
            )
        except Exception as exc:  # noqa: BLE001
            errors.append(f"faulthandler: {exc}")
            log.warning("Failed to enable faulthandler: %s", exc)

        # ── Layer 2: sys.excepthook for uncaught exceptions ────────────
        # Python's default sys.excepthook prints to stderr but doesn't
        # record WHY in any structured form. Wrap it: record reason
        # FIRST, then call the default. Uncaught exceptions in the main
        # thread — and via threading.excepthook, in worker threads —
        # become "uncaught_exception:<type>:<msg>" reasons.
        # Save the prior hook in module state so teardown can restore it
        # (test isolation: pytest's threadexception plugin installs its
        # own hook, and chaining into pytest's hook from outside a real
        # exception path corrupts pytest's state).
        _prev_excepthook = sys.excepthook
        _prev_sys_excepthook = _prev_excepthook

        def _excepthook(exc_type, exc_value, exc_tb):
            try:
                msg = str(exc_value)[:200] if exc_value else ""
                record_shutdown_reason(
                    f"uncaught_exception:{exc_type.__name__}:{msg}",
                )
            except Exception:  # noqa: BLE001
                pass
            try:
                _prev_excepthook(exc_type, exc_value, exc_tb)
            except Exception:  # noqa: BLE001
                pass

        try:
            sys.excepthook = _excepthook
        except Exception as exc:  # noqa: BLE001
            errors.append(f"sys.excepthook: {exc}")

        # threading.excepthook covers worker-thread uncaught exceptions
        # (Python 3.8+). asyncio runs many of our background tasks;
        # exceptions inside those should be caught by their own
        # try/except, but if one slips through it lands here.
        _prev_thread_hook = getattr(threading, "excepthook", None)
        _prev_threading_excepthook = _prev_thread_hook

        def _thread_excepthook(args):
            global _shutdown_reason  # noqa: PLW0603
            try:
                exc_type = args.exc_type
                exc_value = args.exc_value
                msg = str(exc_value)[:200] if exc_value else ""
                # Don't override an existing main-thread reason —
                # worker-thread exceptions are usually downstream of a
                # main-thread cause.
                with _shutdown_reason_lock:
                    if not _shutdown_reason:
                        _shutdown_reason = (
                            f"thread_uncaught:{exc_type.__name__}:{msg}"
                        )
            except Exception:  # noqa: BLE001
                pass
            if _prev_thread_hook is not None:
                try:
                    _prev_thread_hook(args)
                except Exception:  # noqa: BLE001
                    pass

        try:
            if _prev_thread_hook is not None:
                threading.excepthook = _thread_excepthook  # type: ignore[assignment]
        except Exception as exc:  # noqa: BLE001
            errors.append(f"threading.excepthook: {exc}")

        # ── Layer 3: atexit hook ───────────────────────────────────────
        # Last line of defense. Runs on EVERY interpreter exit including:
        #  * clean shutdown (lifespan teardown)
        #  * sys.exit() from anywhere
        #  * uncaught exception (after default excepthook)
        #  * KeyboardInterrupt that escapes uvicorn
        # Does NOT run on:
        #  * fatal signals (handled by faulthandler instead)
        #  * os._exit() (deliberate — that's "abandon ship" semantics)
        #  * SIGKILL / Task Manager → End Task (no Python runs at all)
        # Register atexit ONCE per process — atexit doesn't have a
        # clean unregister API, and re-registering after teardown
        # would queue multiple "process exiting" lines on shutdown.
        if not _atexit_registered:
            try:
                atexit.register(_atexit_log_shutdown)
                _atexit_registered = True
            except Exception as exc:  # noqa: BLE001
                errors.append(f"atexit: {exc}")

        _installed = True

        return {
            "installed": True,
            "crash_log": str(crash_log_path),
            "errors": errors,
        }


def _atexit_log_shutdown() -> None:
    """Final log line on interpreter exit. Runs after lifespan teardown.

    By this point, log handlers may have been torn down — write to
    BOTH the logger (likely silent if shutdown is far enough along)
    AND stderr (always works). The log line is the load-bearing record
    for ``agntspace why-down``; the stderr line is for humans watching
    a terminal.
    """
    with _shutdown_reason_lock:
        reason = _shutdown_reason or "interpreter_exit_no_reason_recorded"
    timestamp = datetime.now(UTC).isoformat()
    line = f"[agntspace] Process {os.getpid()} exiting: {reason} (at {timestamp})"
    # Stderr first — never relies on logging being alive.
    try:
        print(line, file=sys.stderr, flush=True)
    except Exception:  # noqa: BLE001
        pass
    # Logger — may or may not work depending on shutdown phase.
    try:
        log.warning("Process exiting: %s", reason)
    except Exception:  # noqa: BLE001
        pass


def teardown_diagnostics() -> None:
    """Idempotent uninstall — closes the crash-log file handle and
    restores ``sys.excepthook`` / ``threading.excepthook`` to their
    pre-install values.

    Called from lifespan teardown for clean shutdown. The atexit hook
    fires AFTER teardown; closing the file here is fine because
    faulthandler.disable() releases the file pointer. The atexit
    registration is NOT removed (atexit has no clean unregister API)
    — see ``_atexit_registered`` for the deduplication guard.
    """
    global _crash_log_handle, _installed  # noqa: PLW0603
    global _prev_sys_excepthook, _prev_threading_excepthook  # noqa: PLW0603
    with _install_lock:
        if _crash_log_handle is not None:
            try:
                faulthandler.disable()
            except Exception:  # noqa: BLE001
                pass
            try:
                _crash_log_handle.close()
            except Exception:  # noqa: BLE001
                pass
            _crash_log_handle = None
        # Restore the pre-install hooks so test isolation works AND so
        # a clean-restart scenario doesn't leave stale wrappers
        # pointing at the old log file.
        if _prev_sys_excepthook is not None:
            try:
                sys.excepthook = _prev_sys_excepthook
            except Exception:  # noqa: BLE001
                pass
            _prev_sys_excepthook = None
        if _prev_threading_excepthook is not None:
            try:
                threading.excepthook = _prev_threading_excepthook  # type: ignore[assignment]
            except Exception:  # noqa: BLE001
                pass
            _prev_threading_excepthook = None
        _installed = False
