"""Vault freshness detection — has this vault accumulated user content yet?

Used by the daily-cycle catch-up workflow to decide whether to backfill
journal entries for past days. The previous implementation used SOUL.md
mtime as the anchor, which broke when a user copied the `agntspace/`
system folder from one vault to another (`shutil.copy2` preserves mtime,
making the new vault look weeks old, triggering a phantom backfill).

The robust signal is "has the user accumulated any content here?":
- user-authored journal entries in `journal/user/`
- user-created tasks under `projects/*/tasks/`
- user-created goals
- conversations / decisions / costs in the per-vault SQLite DB

If NONE of those exist, the vault is fresh regardless of SOUL.md mtime.
We also stamp an explicit `vault_initialized_at` ISO timestamp in SOUL.md
frontmatter when a vault is first initialized OR first adopted by this
install — this gives a precise anchor that survives file copies.

Resolution order in :func:`vault_creation_date`:

1. ``vault_initialized_at`` field in SOUL.md frontmatter — the precise
   anchor written by setup/init or adoption.
2. Presence of user content — if no user content exists, return today's
   date so catch-up never backfills.
3. ``min(ctime, mtime)`` of SOUL.md — legacy fallback for vaults that
   pre-date this fix.
"""

from __future__ import annotations

import logging
import re
from datetime import UTC, datetime
from pathlib import Path

log = logging.getLogger(__name__)


# ── User-content signals ─────────────────────────────────────────


def _has_any_files(directory: Path, *, suffix: str = ".md") -> bool:
    """Return True if `directory` contains at least one file with `suffix`.

    Walks recursively but bounded — returns on the first match. Hidden files
    (dotfiles) and `.gitkeep` placeholders are ignored.
    """
    if not directory.is_dir():
        return False
    try:
        for entry in directory.rglob(f"*{suffix}"):
            if not entry.is_file():
                continue
            name = entry.name
            if name.startswith(".") or name == ".gitkeep":
                continue
            return True
    except (OSError, PermissionError):
        log.debug("Could not scan %s for user content", directory, exc_info=True)
    return False


def has_user_content(vault_dir: Path) -> bool:
    """Return True if the vault has accumulated any user-authored content.

    Checks the canonical user-content surfaces:
    - ``agntspace-journal/user/`` — user-authored journal entries
    - ``agntspace-projects/*/tasks/`` — tasks
    - ``agntspace-goals/`` — goals

    A vault with empty knowledge / no journals / no tasks is treated as
    "fresh" — there's nothing for the daily cycle to summarise yet.
    """
    root = Path(vault_dir)

    # User journal entries — most direct signal
    if _has_any_files(root / "agntspace-journal" / "user"):
        return True

    # Projects with tasks — even one task means user is active
    projects_dir = root / "agntspace-projects"
    if projects_dir.is_dir():
        try:
            for project in projects_dir.iterdir():
                if project.is_dir() and _has_any_files(project / "tasks"):
                    return True
        except (OSError, PermissionError):
            pass

    # Goals
    if _has_any_files(root / "agntspace-goals"):
        return True

    return False


# ── SOUL.md vault_initialized_at field ────────────────────────────


# Match `vault_initialized_at: "2026-04-28T14:43:28+02:00"` (with or without quotes)
# in YAML frontmatter. Tolerates surrounding whitespace; never matches across
# the closing `---`.
_VAULT_INIT_RE = re.compile(
    r"^vault_initialized_at\s*:\s*[\"']?([^\"'\n]+?)[\"']?\s*$",
    flags=re.MULTILINE,
)


def read_vault_initialized_at(soul_path: Path) -> str | None:
    """Return the ISO timestamp from SOUL.md frontmatter, or None.

    Reads the file directly with `read_text` rather than going through the
    frontmatter library — this is intentionally robust to malformed YAML
    (a frontmatter parse error must not silently disable freshness detection).
    Only the first 4 KB of the file is scanned; frontmatter never legitimately
    extends beyond that.
    """
    try:
        if not soul_path.is_file():
            return None
        text = soul_path.read_text(encoding="utf-8", errors="replace")[:4096]
    except (OSError, PermissionError):
        log.debug("Could not read SOUL.md at %s", soul_path, exc_info=True)
        return None

    # Restrict to frontmatter block (between leading `---` and the next `---`).
    if not text.lstrip().startswith("---"):
        return None
    after_first = text.split("---", 2)
    if len(after_first) < 3:
        return None
    frontmatter_block = after_first[1]

    match = _VAULT_INIT_RE.search(frontmatter_block)
    if not match:
        return None
    value = match.group(1).strip()
    if not value or value.startswith("["):  # placeholder or empty
        return None
    return value


def stamp_vault_initialized_at(
    soul_path: Path,
    *,
    timestamp: str | None = None,
    overwrite: bool = False,
) -> bool:
    """Write `vault_initialized_at` into SOUL.md frontmatter.

    Returns True if the field was written/updated, False if no change was
    made (file missing, field already present and overwrite=False, or
    write failed). Preserves the rest of the frontmatter and body byte-for-byte.

    The stamp is the canonical "this vault began existing in THIS install at
    this moment" marker. It survives file copies because copies preserve
    content, not "creation time per install".
    """
    if not soul_path.is_file():
        return False

    if timestamp is None:
        timestamp = datetime.now(UTC).astimezone().isoformat()

    try:
        original = soul_path.read_text(encoding="utf-8")
    except (OSError, PermissionError):
        log.warning("Could not read %s to stamp vault_initialized_at", soul_path)
        return False

    if not original.lstrip().startswith("---"):
        # No frontmatter block — prepend a minimal one without disturbing body.
        new_text = f"---\nvault_initialized_at: \"{timestamp}\"\n---\n\n{original.lstrip()}"
        try:
            soul_path.write_text(new_text, encoding="utf-8")
            return True
        except (OSError, PermissionError):
            log.warning("Could not write SOUL.md to stamp vault_initialized_at")
            return False

    # Split into frontmatter and body.
    parts = original.split("---", 2)
    if len(parts) < 3:
        # Malformed frontmatter — bail rather than corrupt further.
        log.debug("SOUL.md frontmatter malformed; skipping stamp")
        return False
    leading, frontmatter_block, body = parts[0], parts[1], parts[2]

    if _VAULT_INIT_RE.search(frontmatter_block):
        if not overwrite:
            return False
        new_block = _VAULT_INIT_RE.sub(
            f'vault_initialized_at: "{timestamp}"',
            frontmatter_block,
            count=1,
        )
    else:
        # Insert before the closing `---`. Place at end of frontmatter for visibility.
        trimmed = frontmatter_block.rstrip("\n")
        new_block = trimmed + f'\nvault_initialized_at: "{timestamp}"\n'

    new_text = f"{leading}---{new_block}---{body}"
    try:
        soul_path.write_text(new_text, encoding="utf-8")
        return True
    except (OSError, PermissionError):
        log.warning("Could not write SOUL.md to stamp vault_initialized_at")
        return False


# ── Vault creation-date resolution ────────────────────────────────


def vault_creation_date(vault_dir: Path) -> str | None:
    """Return the date the vault was effectively created (YYYY-MM-DD), or None.

    Resolution order:

    1. ``vault_initialized_at`` field in SOUL.md frontmatter — the most
       precise anchor when present.
    2. If SOUL.md is missing entirely, return None (the caller treats this
       as "no creation-date constraint").
    3. If the vault has no accumulated user content, return today's date —
       there is nothing to backfill regardless of SOUL.md mtime.
    4. ``min(ctime, mtime)`` of SOUL.md — legacy fallback for vaults that
       have user content but no `vault_initialized_at` stamp.
    """
    root = Path(vault_dir)
    soul = root / "agntspace" / "system" / "identity" / "SOUL.md"

    # 1. Explicit stamp wins.
    iso = read_vault_initialized_at(soul)
    if iso:
        try:
            return datetime.fromisoformat(iso).astimezone(UTC).strftime("%Y-%m-%d")
        except ValueError:
            log.debug("Could not parse vault_initialized_at=%r as ISO", iso)
            # Fall through to other heuristics.

    # 2. No SOUL.md → no constraint (caller treats as "allow all dates").
    if not soul.is_file():
        return None

    # 3. No user content → fresh vault, anchor at today.
    if not has_user_content(root):
        return datetime.now(UTC).strftime("%Y-%m-%d")

    # 4. Legacy fallback: SOUL.md mtime.
    try:
        ts = min(soul.stat().st_ctime, soul.stat().st_mtime)
        return datetime.fromtimestamp(ts, tz=UTC).strftime("%Y-%m-%d")
    except (OSError, ValueError):
        log.debug("Could not stat SOUL.md mtime", exc_info=True)
        return None
