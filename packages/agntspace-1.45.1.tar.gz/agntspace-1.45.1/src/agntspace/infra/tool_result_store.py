"""Process-local store for full tool results that exceed the inline budget.

When a tool returns a payload larger than the per-message inline cap, the
truncator stashes the full JSON here and emits a small placeholder with a
handle id. The LLM (or a follow-up tool call) can then ``get_tool_result``
to retrieve the full payload — useful for "the search returned 50KB and I
need just the third hit" workflows without re-running the tool.

Design choices:

  * **In-memory, process-local**. Restart drops every handle. That's
    acceptable because handles are scoped to a single chat turn / tool
    loop — a stale handle a day later carries no useful information.
    Persisting to SQLite would add complexity (cleanup, schema, locks)
    for no real benefit.

  * **Bounded by total bytes AND entry count**. ``max_bytes`` (default
    50 MB) and ``max_entries`` (default 1000). LRU eviction on overflow.
    The 50 MB cap is conservative — at 50 KB / typical large result, that's
    ~1000 entries before pressure, well above any realistic concurrent-
    turn count for a personal agent.

  * **Per-handle TTL**. Default 1 hour. Long enough that a multi-step
    chat turn can fetch the full result later in the same conversation,
    short enough that a forgotten handle cleans up automatically.

  * **Thread-safe**. The chat path uses ``asyncio`` but tool execution
    routes through a thread pool. ``threading.RLock`` (reentrant — the
    same thread that's storing might be the one running cleanup).

  * **Deterministic-id generation** uses ``secrets.token_urlsafe`` so
    handles are unguessable AND collision-resistant. Prefix ``tr-`` makes
    them visually distinguishable from contract / decision / job ids.

This is engine substrate (Rule 12). Knobs live in
``defaults/skills/_meta/tool-result-limits/config/limits.yaml`` and are
applied via the ``ToolResultStore`` constructor at startup.
"""

from __future__ import annotations

import secrets
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Final

# arch:deterministic — handles use 12 url-safe random bytes (~16 chars after
# base64). Collision odds are negligible (~10^-19) at our scale.
_HANDLE_ENTROPY_BYTES: Final[int] = 12

# arch:deterministic — default caps. Tunable via YAML at runtime.
_DEFAULT_MAX_BYTES: Final[int] = 50 * 1024 * 1024  # 50 MB
_DEFAULT_MAX_ENTRIES: Final[int] = 1000
_DEFAULT_TTL_SECONDS: Final[float] = 60 * 60.0  # 1 hour


@dataclass(frozen=True)
class StoreEntry:
    """A single stored full tool result.

    ``payload`` is a JSON STRING (already serialized) — the store doesn't
    re-serialize on retrieval. ``stored_at`` is a monotonic timestamp for
    TTL math. ``tool_name`` is captured for diagnostics + future
    eviction-prioritization heuristics.
    """

    handle_id: str
    payload: str
    tool_name: str
    stored_at: float
    size_bytes: int


class ToolResultStore:
    """Bounded LRU + TTL store for tool result payloads.

    Args:
        max_bytes: Total payload size before LRU eviction. Default 50 MB.
        max_entries: Hard cap on entry count. LRU eviction past this.
            Default 1000.
        ttl_seconds: Per-handle TTL. ``retrieve`` returns ``None`` for
            expired handles AND drops them from the store. Default 3600s.
    """

    def __init__(
        self,
        *,
        max_bytes: int = _DEFAULT_MAX_BYTES,
        max_entries: int = _DEFAULT_MAX_ENTRIES,
        ttl_seconds: float = _DEFAULT_TTL_SECONDS,
    ) -> None:
        self._max_bytes = max(1024, int(max_bytes))
        self._max_entries = max(1, int(max_entries))
        self._ttl_seconds = max(1.0, float(ttl_seconds))
        # OrderedDict gives us LRU ordering: move_to_end on access, popitem
        # from the front when over budget.
        self._entries: OrderedDict[str, StoreEntry] = OrderedDict()
        self._total_bytes: int = 0
        self._lock = threading.RLock()

    # -------- Stats / introspection --------

    @property
    def total_bytes(self) -> int:
        with self._lock:
            return self._total_bytes

    @property
    def entry_count(self) -> int:
        with self._lock:
            return len(self._entries)

    def stats(self) -> dict[str, int | float]:
        with self._lock:
            return {
                "entries": len(self._entries),
                "bytes": self._total_bytes,
                "max_bytes": self._max_bytes,
                "max_entries": self._max_entries,
                "ttl_seconds": self._ttl_seconds,
            }

    # -------- Core operations --------

    def store(self, payload: str, tool_name: str) -> str:
        """Store a payload string. Returns the new handle id.

        ``payload`` should already be JSON-serialized. The store doesn't
        validate JSON — it treats ``payload`` opaquely so callers can stash
        any string they want (a binary blob's base64, a markdown excerpt,
        etc.) without re-encoding.
        """
        if not isinstance(payload, str):
            raise TypeError("payload must be a str (already-serialized JSON)")
        size = len(payload.encode("utf-8", errors="replace"))
        handle = self._new_handle()
        entry = StoreEntry(
            handle_id=handle,
            payload=payload,
            tool_name=tool_name or "",
            stored_at=time.monotonic(),
            size_bytes=size,
        )
        with self._lock:
            self._entries[handle] = entry
            self._total_bytes += size
            self._evict_if_needed()
        return handle

    def retrieve(self, handle_id: str) -> StoreEntry | None:
        """Return the full entry by handle, or ``None`` if missing/expired.

        Side effect: refreshes LRU position on hit. Drops the entry if
        expired.
        """
        if not isinstance(handle_id, str) or not handle_id:
            return None
        with self._lock:
            entry = self._entries.get(handle_id)
            if entry is None:
                return None
            if (time.monotonic() - entry.stored_at) > self._ttl_seconds:
                # Expired — drop and report miss.
                self._drop_unlocked(handle_id)
                return None
            self._entries.move_to_end(handle_id)  # LRU bump
            return entry

    def drop(self, handle_id: str) -> bool:
        """Remove a handle. Returns True if it existed."""
        with self._lock:
            return self._drop_unlocked(handle_id)

    def clear(self) -> None:
        """Drop every entry. Useful for tests + admin reset."""
        with self._lock:
            self._entries.clear()
            self._total_bytes = 0

    def prune_expired(self) -> int:
        """Drop every entry past TTL. Returns count removed.

        Called opportunistically — store/retrieve already drop expired
        entries lazily. This method is for explicit batch cleanup
        (e.g. periodic maintenance task).
        """
        now = time.monotonic()
        removed = 0
        with self._lock:
            stale = [
                h for h, e in self._entries.items()
                if (now - e.stored_at) > self._ttl_seconds
            ]
            for h in stale:
                if self._drop_unlocked(h):
                    removed += 1
        return removed

    # -------- Internals --------

    def _new_handle(self) -> str:
        # ``token_urlsafe`` is collision-resistant + unguessable.
        return f"tr-{secrets.token_urlsafe(_HANDLE_ENTROPY_BYTES)}"

    def _drop_unlocked(self, handle_id: str) -> bool:
        entry = self._entries.pop(handle_id, None)
        if entry is None:
            return False
        self._total_bytes -= entry.size_bytes
        if self._total_bytes < 0:
            # Defensive: should never happen under correct accounting.
            self._total_bytes = 0
        return True

    def _evict_if_needed(self) -> None:
        # Evict oldest until under both caps.
        while (
            self._total_bytes > self._max_bytes
            or len(self._entries) > self._max_entries
        ):
            if not self._entries:
                # Defensive — caps misconfigured to zero.
                self._total_bytes = 0
                return
            oldest_id, oldest = self._entries.popitem(last=False)
            self._total_bytes -= oldest.size_bytes
            if self._total_bytes < 0:
                self._total_bytes = 0


# Process-wide singleton, lazily constructed via ``get_default_store()``.
_default_store: ToolResultStore | None = None
_default_lock = threading.Lock()


def get_default_store() -> ToolResultStore:
    """Return the process-wide default ToolResultStore.

    Constructed lazily with deterministic defaults. To configure with
    YAML-driven overrides, call ``set_default_store()`` from the lifespan
    startup hook AFTER the skill loader is wired.
    """
    global _default_store
    with _default_lock:
        if _default_store is None:
            _default_store = ToolResultStore()
        return _default_store


def set_default_store(store: ToolResultStore) -> None:
    """Replace the process-wide default ToolResultStore. Idempotent."""
    global _default_store
    with _default_lock:
        _default_store = store
