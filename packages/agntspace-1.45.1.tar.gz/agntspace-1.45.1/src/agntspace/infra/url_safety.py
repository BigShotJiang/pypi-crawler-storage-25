"""URL safety classification for outbound scrape paths.

Classifies a URL as allowed or blocked BEFORE any network call. Checks:

  * Scheme allowlist (default: http, https). Refuses ``file://``, ``gopher://``,
    ``data:``, ``javascript:``, ``ftp://``, ``ssh://``, ``smb://``, etc.
  * Hostname presence and shape (must parse, must not be empty, must not be
    a bare IP-literal that resolves to a private/loopback range).
  * Private/loopback/link-local IPv4 + IPv6 ranges. Blocks SSRF-style probes
    that would let a malicious search result coerce the agent into hitting
    its own ``/api/admin/*`` surface.
  * Optional blocklist of hostnames (with subdomain matching) and optional
    allowlist (when set, only listed hostnames pass).

This is pure validation. It performs zero network I/O. ``robots.txt`` policy
lives in ``website_policy.py`` because it requires fetching and caching a
remote resource.

Pure functions, deterministic output, no side effects. Safe to call from
any context including hot paths and the event loop.

Engine substrate per Rule 12: every default lives here as ``arch:deterministic``;
strategy (the user-tunable blocklist + scheme set + private-IP toggle) lives
in ``defaults/skills/_meta/url-safety/config/safety.yaml``.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Final
from urllib.parse import urlsplit

# arch:deterministic — the only schemes a network scraper should follow.
# Anything else is a code smell at minimum and SSRF/local-file-read at worst.
_DEFAULT_SCHEME_ALLOWLIST: Final[frozenset[str]] = frozenset({"http", "https"})  # arch:deterministic — SSRF guard, structural

# arch:deterministic — hostname literals that are always private-side, even
# without IP resolution. Belt-and-braces alongside the IP-literal check so a
# string like "localhost" gets blocked even on hosts where DNS would resolve
# it to a non-loopback address.
_DEFAULT_HOSTNAME_BLOCKLIST: Final[frozenset[str]] = frozenset({  # arch:deterministic — SSRF guard, private-side hostnames
    "localhost",
    "ip6-localhost",
    "ip6-loopback",
    "broadcasthost",
})


class URLSafetyError(ValueError):
    """Raised when a URL fails safety classification.

    Subclass of ``ValueError`` so existing ``except ValueError:`` blocks
    keep catching it during the rollout of url-safety enforcement. New code
    can ``except URLSafetyError:`` for narrower handling.
    """


@dataclass(frozen=True)
class URLSafetyResult:
    """Outcome of a single URL classification.

    Attributes:
        allowed: True iff the URL is safe to fetch.
        reason: Stable machine-readable reason code on block, empty on allow.
            One of: ``unparseable``, ``empty_url``, ``no_scheme``,
            ``scheme_not_allowed``, ``no_hostname``, ``hostname_blocked``,
            ``hostname_not_allowed``, ``private_ip``, ``loopback_ip``,
            ``link_local_ip``.
        url: The URL that was classified (echoed back for logging).
        detail: Optional human-readable elaboration. Never authoritative —
            ``reason`` is the canonical block reason.
    """

    allowed: bool
    reason: str
    url: str
    detail: str = ""


def _is_private_or_loopback_ip(host: str) -> tuple[bool, str]:
    """Return (is_private, reason_code).

    ``host`` is the hostname extracted from the URL. Returns ``(False, "")``
    when the host is not an IP literal (i.e. resolution-based block decisions
    are NOT this function's job). Returns ``(True, reason)`` when the host
    parses as an IP literal in a private, loopback, link-local, or
    multicast range.
    """
    # Strip IPv6 brackets if present.
    candidate = host.strip("[]")
    try:
        ip = ipaddress.ip_address(candidate)
    except ValueError:
        return (False, "")

    if ip.is_loopback:
        return (True, "loopback_ip")
    if ip.is_link_local:
        return (True, "link_local_ip")
    if ip.is_private:
        return (True, "private_ip")
    if ip.is_multicast:
        return (True, "private_ip")  # multicast is not a valid scrape target
    if ip.is_unspecified:
        return (True, "private_ip")  # 0.0.0.0 / ::
    if ip.is_reserved:
        return (True, "private_ip")
    return (False, "")


def _hostname_matches(host: str, patterns) -> bool:
    """True when ``host`` exactly matches a pattern or is a subdomain of one.

    Pattern ``example.com`` matches ``example.com`` AND ``api.example.com``
    AND ``a.b.example.com``. Pattern is treated as a domain suffix; this is
    deliberately broader than exact-match so a single blocklist entry covers
    a whole org.
    """
    host_lower = host.lower().rstrip(".")
    for pattern in patterns:
        p = pattern.lower().rstrip(".")
        if not p:
            continue
        if host_lower == p:
            return True
        if host_lower.endswith("." + p):
            return True
    return False


def classify_url(
    url: str,
    *,
    scheme_allowlist=None,
    hostname_blocklist=None,
    hostname_allowlist=None,
    block_private_ips: bool = True,
) -> URLSafetyResult:
    """Classify ``url`` as allowed or blocked.

    Pure function. Performs zero network I/O. Call this BEFORE any scrape
    or fetch.

    Args:
        url: Candidate URL.
        scheme_allowlist: Schemes permitted. Defaults to ``{"http", "https"}``.
            Pass an empty set to forbid every scheme (useful for tests).
        hostname_blocklist: Hostnames or domain suffixes to refuse. Combined
            with the always-on ``_DEFAULT_HOSTNAME_BLOCKLIST`` (localhost et
            al.) — caller-supplied entries augment, never replace, the
            built-in safety floor.
        hostname_allowlist: When non-empty, ONLY listed hostnames pass.
            Disabled by default (every hostname not blocked is allowed).
            Combine with blocklist semantics: blocklist match wins over
            allowlist when both contain the same host.
        block_private_ips: When True (default), refuse URLs whose hostname
            is an IP literal in a private/loopback/link-local range. The
            user-tunable knob lives in YAML; the underlying decision logic
            stays here.

    Returns:
        ``URLSafetyResult`` with ``allowed`` bool and ``reason`` code.
    """
    if not isinstance(url, str) or not url.strip():
        return URLSafetyResult(False, "empty_url", url or "", "URL is empty.")

    try:
        parts = urlsplit(url.strip())
    except ValueError as exc:
        return URLSafetyResult(False, "unparseable", url, str(exc))

    scheme = (parts.scheme or "").lower()
    if not scheme:
        return URLSafetyResult(False, "no_scheme", url, "URL has no scheme.")

    schemes = (
        frozenset(s.lower() for s in scheme_allowlist)
        if scheme_allowlist is not None
        else _DEFAULT_SCHEME_ALLOWLIST
    )
    if scheme not in schemes:
        return URLSafetyResult(
            False, "scheme_not_allowed", url,
            f"Scheme '{scheme}' is not in the allowlist.",
        )

    # ``hostname`` strips brackets from IPv6 literals + lowercases. ``netloc``
    # may contain user:pass@host:port — we only care about the host.
    host = (parts.hostname or "").strip()
    if not host:
        return URLSafetyResult(False, "no_hostname", url, "URL has no hostname.")

    # Allowlist (if set) wins. Hostname must be in the allowlist explicitly.
    if hostname_allowlist:
        if not _hostname_matches(host, hostname_allowlist):
            return URLSafetyResult(
                False, "hostname_not_allowed", url,
                f"Hostname '{host}' is not in the allowlist.",
            )

    # Built-in blocklist always applies. User extras layer on top.
    if _hostname_matches(host, _DEFAULT_HOSTNAME_BLOCKLIST):
        return URLSafetyResult(
            False, "hostname_blocked", url,
            f"Hostname '{host}' is blocked (built-in safety floor).",
        )
    if hostname_blocklist and _hostname_matches(host, hostname_blocklist):
        return URLSafetyResult(
            False, "hostname_blocked", url,
            f"Hostname '{host}' is blocked by user blocklist.",
        )

    # IP-literal classification. DNS resolution is deliberately NOT done here —
    # this stays a pure offline check. Resolving in the safety layer would
    # mean a transient DNS failure could appear as an "unsafe URL", which is
    # the wrong semantic.
    if block_private_ips:
        is_private, ip_reason = _is_private_or_loopback_ip(host)
        if is_private:
            return URLSafetyResult(
                False, ip_reason, url,
                f"Hostname '{host}' resolves to a private/loopback range.",
            )

    return URLSafetyResult(True, "", url)


def filter_safe_urls(
    urls: list[str],
    *,
    scheme_allowlist=None,
    hostname_blocklist=None,
    hostname_allowlist=None,
    block_private_ips: bool = True,
) -> tuple[list[str], list[URLSafetyResult]]:
    """Partition a URL list into ``(allowed, blocked_results)``.

    Convenience wrapper for batch callers. Order preserved.
    """
    allowed: list[str] = []
    blocked: list[URLSafetyResult] = []
    for url in urls:
        result = classify_url(
            url,
            scheme_allowlist=scheme_allowlist,
            hostname_blocklist=hostname_blocklist,
            hostname_allowlist=hostname_allowlist,
            block_private_ips=block_private_ips,
        )
        if result.allowed:
            allowed.append(url)
        else:
            blocked.append(result)
    return allowed, blocked
