"""Separate SQLite file for the finance subsystem.

Stage D of the DB split (shipped 2026-05-05). Closes the last
write-frequency outlier still on the main agntspace.db. Five tables
move together because they share FK + index relationships:

    finance_merchants
    finance_transactions
    finance_line_items
    finance_budgets
    finance_budget_consumed

Why split now:

* Receipt ingest is bursty — Telegram photo intercept + OCR/vision LLM
  + ledger commit runs in a tight critical path. While the KB pipeline
  is mid-compile and holding the agntspace.db writer lock, the ledger
  commit was timing out at 30s busy_timeout and the receipt was
  silently lost (the canonical 2026-04-29 BAUHAUS incident).

* Sibling SQLite files have INDEPENDENT writer locks. KB pipeline
  contention on agntspace.db cannot starve finance_* writes anymore.

* The audit.db (decision_log, 2026-04-30) and automation.db (work_queue,
  2026-04-30) splits have proven the pattern. Finance is the third file.

Mirrors ``infra/automation_db.py`` exactly — same PRAGMA discipline,
same WAL checkpoint behaviour, same idempotent INSERT OR IGNORE
keyed on each table's primary key. After the first successful migration
every subsequent boot is a fast no-op.

Foreign-key enforcement stays OFF on the finance connection (matches
audit.db + automation.db convention). FinanceLedger does explicit
manual cleanup on cascading deletes — see
``FinanceLedger.delete_budget`` for the rationale.
"""

from __future__ import annotations

import logging
from pathlib import Path

import aiosqlite

log = logging.getLogger(__name__)


async def get_finance_db(finance_path: Path) -> aiosqlite.Connection:
    """Open the finance.db connection with the same PRAGMAs as audit.db.

    Symmetric configuration is load-bearing across the split (lesson
    from 2026-04-29 morning). Includes WAL auto-checkpoint at 200 pages
    (~800 KB) and a one-time TRUNCATE checkpoint at open to flush any
    pre-existing WAL accumulation.
    """
    finance_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(finance_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA busy_timeout=30000")
    await db.execute("PRAGMA synchronous=NORMAL")
    await db.execute("PRAGMA wal_autocheckpoint=200")
    try:
        await db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        log.debug("finance.db wal_checkpoint failed (non-fatal)", exc_info=True)
    await db.commit()
    return db


# Tables to migrate in dependency-safe order. Children listed AFTER
# parents in case the migration is ever run with FK enforcement on
# (currently off — see module docstring). Each entry: (table_name,
# primary_key_columns_for_dedup, comment).
_FINANCE_TABLES: tuple[tuple[str, tuple[str, ...]], ...] = (  # arch:deterministic
    # Parents first
    ("finance_merchants", ("merchant_slug",)),
    ("finance_transactions", ("txn_id",)),
    # Children of finance_transactions
    ("finance_line_items", ("item_id",)),
    # Independent parent (referenced by finance_budget_consumed)
    ("finance_budgets", ("budget_id",)),
    # Joins finance_transactions × finance_budgets
    ("finance_budget_consumed", ("budget_id", "txn_id")),
)


async def _table_exists(db: aiosqlite.Connection, table_name: str) -> bool:
    """Return True iff ``table_name`` exists in ``db``."""
    try:
        cur = await db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
        )
        row = await cur.fetchone()
        await cur.close()
        return row is not None
    except Exception:  # noqa: BLE001
        log.exception("finance migration: failed to inspect schema for %s", table_name)
        return False


async def _table_columns(db: aiosqlite.Connection, table_name: str) -> set[str]:
    """Return the column-name set for ``table_name``."""
    try:
        cur = await db.execute(f"PRAGMA table_info({table_name})")
        info_rows = await cur.fetchall()
        await cur.close()
        return {r["name"] if hasattr(r, "keys") else r[1] for r in info_rows}
    except Exception:  # noqa: BLE001
        log.exception("finance migration: failed to read schema for %s", table_name)
        return set()


async def _migrate_one_table(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    table_name: str,
    batch_size: int = 1000,
) -> dict:
    """Idempotently copy one finance_* table from source to target.

    Returns ``{copied, already_present, source_total, batches_failed}``.
    Mirrors the per-table migration in ``infra/automation_db.py`` —
    column intersection (so older sources missing newer columns still
    work), batched fetch+insert, INSERT OR IGNORE keyed on the table's
    natural primary key. Per-batch failures are counted, never raised.
    """
    result = {"copied": 0, "already_present": 0, "source_total": 0, "batches_failed": 0}

    if not await _table_exists(source_db, table_name):
        return result
    if not await _table_exists(target_db, table_name):
        log.warning(
            "finance migration: target finance.db has no %s table yet; "
            "initialize FinanceLedger first, then re-run migration",
            table_name,
        )
        return result

    # Count source rows
    try:
        cur = await source_db.execute(f"SELECT COUNT(*) FROM {table_name}")
        count_row = await cur.fetchone()
        await cur.close()
        result["source_total"] = int(count_row[0]) if count_row else 0
    except Exception:  # noqa: BLE001
        log.exception("finance migration: failed to count rows in %s", table_name)
        return result

    if result["source_total"] == 0:
        return result

    # Intersect source + target columns to a portable list. Defensive
    # against schema drift (e.g. an older vault missing a recent
    # ALTER TABLE column).
    src_cols = await _table_columns(source_db, table_name)
    tgt_cols = await _table_columns(target_db, table_name)
    common_cols = sorted(src_cols & tgt_cols)
    if not common_cols:
        log.warning(
            "finance migration: %s has no overlapping columns between source and target",
            table_name,
        )
        return result

    col_list = ", ".join(common_cols)
    placeholders = ", ".join("?" * len(common_cols))
    insert_sql = f"INSERT OR IGNORE INTO {table_name} ({col_list}) VALUES ({placeholders})"
    select_sql = f"SELECT {col_list} FROM {table_name} LIMIT ? OFFSET ?"

    offset = 0
    while offset < result["source_total"]:
        try:
            cur = await source_db.execute(select_sql, (batch_size, offset))
            batch = await cur.fetchall()
            await cur.close()
            if not batch:
                break
            payload = [tuple(row) for row in batch]
            try:
                changes_before = target_db.total_changes
            except Exception:  # noqa: BLE001
                changes_before = 0
            await target_db.executemany(insert_sql, payload)
            await target_db.commit()
            try:
                changes_after = target_db.total_changes
            except Exception:  # noqa: BLE001
                changes_after = changes_before
            inserted = max(0, changes_after - changes_before)
            result["copied"] += inserted
            result["already_present"] += max(0, len(payload) - inserted)
            offset += batch_size
        except Exception:  # noqa: BLE001
            result["batches_failed"] += 1
            log.exception(
                "finance migration: batch at offset=%d failed for %s",
                offset, table_name,
            )
            offset += batch_size  # advance past the bad batch

    return result


async def migrate_finance_to_finance_db(
    *,
    source_db: aiosqlite.Connection,
    target_db: aiosqlite.Connection,
    batch_size: int = 1000,
) -> dict:
    """Idempotent one-time copy of all finance_* rows from agntspace.db to finance.db.

    Walks ``_FINANCE_TABLES`` parents-first and copies via per-table
    INSERT OR IGNORE keyed on each table's natural primary key. Re-running
    after a successful first pass is a fast no-op (every row already
    present).

    Returns an aggregate dict with the per-table breakdown plus totals::

        {
            "tables": {
                "finance_merchants": {copied, already_present, source_total, batches_failed},
                ...
            },
            "copied": <sum>,
            "already_present": <sum>,
            "source_total": <sum>,
            "batches_failed": <sum>,
        }

    Conservative on edge cases:
    - Source table missing (fresh install) → that table contributes zeros
    - Target schema not yet initialized → skipped with a WARNING log
    - Per-table failure → counted, other tables still run
    - Per-batch failure → counted, partial progress preserved
    """
    aggregate = {
        "tables": {},
        "copied": 0,
        "already_present": 0,
        "source_total": 0,
        "batches_failed": 0,
    }

    for table_name, _pk_cols in _FINANCE_TABLES:
        per_table = await _migrate_one_table(
            source_db=source_db,
            target_db=target_db,
            table_name=table_name,
            batch_size=batch_size,
        )
        aggregate["tables"][table_name] = per_table
        aggregate["copied"] += per_table["copied"]
        aggregate["already_present"] += per_table["already_present"]
        aggregate["source_total"] += per_table["source_total"]
        aggregate["batches_failed"] += per_table["batches_failed"]

    return aggregate
