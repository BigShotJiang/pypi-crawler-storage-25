"""Capability-miss observability — surface "look up X by name → not
found → use default" silent fallthroughs as visible events + decision
rows.

**The gap this closes**: many code paths in AgntSpace do
``resolve_X_by_name → if None: fall through to default``. Examples:

* ``_resolve_presentation_theme("archer-futura")`` → None → unthemed
* workflow lookup by id → None → workflow_not_found error path
* tool dispatch by name → ``{"error": "Unknown tool"}``

Before this module, ALL of these were invisible: no activity event,
no decision row, no signal to the user OR to the SkillSchool /
capability-gap detection loops. The agent quietly produced wrong
output (e.g. archer-futura case 2026-04-28: generic deck instead of
branded deck) with no audit trail.

This module is the pure helper for instrumenting those sites.
Mirrors the ``classify_tool_result`` shape: a small, fail-safe utility
that callers fire-and-forget. Activity events fire at medium
importance (visible in dashboard background-work toaster). Decision
rows record ``contract_result="failed"`` with ``error_type=
"unknown_<kind>"`` so they surface in ``/decisions`` filters.

**Engine vs strategy split** (Rule 12): this is pure observability
plumbing. Whether a kind/target pair is a "miss" is decided by the
caller (the lookup returned None or empty). No YAML — just
deterministic recording.
"""
from __future__ import annotations

import logging
from typing import Any

from agntspace.activity.decisions import current_correlation_id

log = logging.getLogger(__name__)


def _serialize_available(available: Any) -> list[str]:
    """Coerce the available-options payload to a small, JSON-safe list.

    The caller passes whatever shape it has (list, set, dict keys, etc.)
    — we cap it at 50 entries and stringify each. Every element is
    truncated to 80 chars so a single noisy entry can't blow up the
    activity event payload.
    """
    if available is None:
        return []
    try:
        items = list(available)
    except TypeError:
        return []
    out: list[str] = []
    for item in items[:50]:
        try:
            s = str(item)
        except Exception:
            continue
        if len(s) > 80:
            s = s[:77] + "..."
        out.append(s)
    return out


async def record_capability_miss(
    activity_logger: Any,
    decision_logger: Any,
    *,
    kind: str,
    target: str,
    available: Any = None,
    requested_by: str = "",
    fallback_action: str = "",
) -> None:
    """Record a missed capability lookup at both observability layers.

    Parameters
    ----------
    activity_logger
        ``ActivityLogger`` instance, or ``None`` to skip the activity
        event.
    decision_logger
        ``DecisionLogger`` instance, or ``None`` to skip the decision
        row.
    kind
        The category of capability the caller tried to resolve, e.g.
        ``"presentation_theme"`` / ``"workflow"`` / ``"tool"``. Used
        verbatim in the action name so dashboards can filter by kind.
    target
        The specific name the caller tried to look up that wasn't
        found, e.g. ``"archer-futura"``. Goes into the
        ``action_target`` field of the decision row.
    available
        Optional iterable of names that DO exist (e.g. registered
        themes). Surfaced in the activity event details so the user
        can see "you asked for X, available are Y, Z". Capped at 50
        entries and 80 chars each.
    requested_by
        Optional caller name (e.g. ``"create_presentation"``). Goes
        into the ``actor`` field of the decision row.
    fallback_action
        Optional human-readable description of what the caller did
        instead, e.g. ``"rendered with default theme"``. Helps the
        user understand the impact of the miss.

    Both writes fail open — any exception is caught + logged, never
    raised. Calling this function during chat NEVER breaks the chat.
    """
    summary = (
        f"Capability miss: {kind!r} target {target!r} not found"
        + (f" (called by {requested_by})" if requested_by else "")
    )
    details = {
        "kind": kind,
        "target": target,
        "available": _serialize_available(available),
        "requested_by": requested_by or "",
        "fallback_action": fallback_action or "",
    }

    if activity_logger is not None:
        try:
            await activity_logger.log(
                category="capability",
                action=f"{kind}_not_found",
                summary=summary,
                details=details,
                importance="medium",
            )
        except Exception:
            log.debug("record_capability_miss: activity log failed", exc_info=True)

    if decision_logger is not None:
        try:
            await decision_logger.record(
                actor=requested_by or "engine",
                action_type=f"{kind}_lookup",
                action_target=target,
                contract_action="",
                contract_result="failed",
                rationale=(
                    f"Capability miss — {kind!r} {target!r} not registered."
                    + (f" Fallback: {fallback_action}." if fallback_action else "")
                ),
                details=details,
                correlation_id=current_correlation_id() or "",
                error_type=f"unknown_{kind}",
            )
        except Exception:
            log.debug("record_capability_miss: decision record failed", exc_info=True)


def record_capability_miss_sync(
    activity_logger: Any,
    decision_logger: Any,
    *,
    kind: str,
    target: str,
    available: Any = None,
    requested_by: str = "",
    fallback_action: str = "",
) -> None:
    """Sync wrapper for ``record_capability_miss``.

    Many capability-resolution sites are sync (e.g.
    ``_resolve_presentation_theme`` is a regular method, not async).
    This wrapper schedules the async write on the running loop via
    ``asyncio.create_task`` if one is available, else falls back to a
    direct ``loop.create_task`` on the running event loop.

    Like the async form, this is FIRE-AND-FORGET — failures never
    propagate.
    """
    import asyncio

    coro = record_capability_miss(
        activity_logger,
        decision_logger,
        kind=kind,
        target=target,
        available=available,
        requested_by=requested_by,
        fallback_action=fallback_action,
    )

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No running loop — close the coroutine to avoid the
        # "coroutine was never awaited" warning. The caller is
        # responsible for instrumentation in async paths only; sync
        # CLI paths legitimately can't record async events.
        try:
            coro.close()
        except Exception:
            pass
        return

    try:
        loop.create_task(coro)
    except Exception:
        try:
            coro.close()
        except Exception:
            pass
