"""TTS provider abstraction — MIT/MPL providers only.

Provider order (first available wins):
  1. piper-tts   — local, free, MIT, ~80MB models per voice, decent quality
  2. pyttsx3     — system voices (SAPI / NSSpeech / espeak), MPL-2.0,
                   robotic but always available, last-resort

2026-04-28 cleanup: removed `edge-tts` (GPL-3.0) and `mutagen` (GPL-2.0+) per
the no-copyleft-deps policy in CLAUDE.md Rule 6. MP3 duration is now probed
via `ffprobe` (bundled with ffmpeg, which we already require as a system dep).
The `rate` parameter is silently ignored on this code path — piper-tts has
its own rate model via voice selection, and pyttsx3 doesn't support it
uniformly across SAPI/NSSpeech/espeak. Callers should not depend on it.

All heavy imports are lazy; no-deps installation never crashes. Missing
providers are skipped silently and logged at INFO level.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class TTSResult:
    """One scene's audio output."""

    path: Path
    duration_seconds: float
    provider_used: str    # "piper-tts" / "pyttsx3" / "empty"


class TTSProviderUnavailable(RuntimeError):
    """All configured providers failed."""


# ── Public API ──────────────────────────────────────────────────

async def synthesize_scene(
    scene_id: str,
    text: str,
    *,
    voice: str,
    rate: str = "-5%",
    output_dir: Path,
    skill_loader: Any = None,
) -> TTSResult:
    """Generate a single scene's TTS clip.

    Walks the provider chain from styles.yaml (piper-tts → pyttsx3) and
    returns the first successful result. Returns an empty-path TTSResult
    (provider_used="empty") if text is empty after sanitization. Raises
    TTSProviderUnavailable only if all providers fail.
    """

    output_dir.mkdir(parents=True, exist_ok=True)
    clean = sanitize_for_tts(text)
    if not clean.strip():
        return TTSResult(path=Path(), duration_seconds=0.0, provider_used="empty")

    providers = _resolve_provider_chain(skill_loader)
    last_err: Exception | None = None

    # Log the actual chain we're walking so silent fall-throughs are
    # visible in the server log (e.g. when a provider is configured but
    # disabled, or when a provider returns None without raising).
    log.info(
        "TTS scene=%s walking chain: %s",
        scene_id,
        " → ".join(p.get("id", "?") for p in providers if p.get("enabled", True)),
    )

    for provider_cfg in providers:
        pid = provider_cfg.get("id", "")
        if not provider_cfg.get("enabled", True):
            log.info("TTS scene=%s provider=%s SKIPPED (enabled=false)", scene_id, pid)
            continue

        voice_map = provider_cfg.get("voices", {}) or {}
        try:
            result: TTSResult | None = None
            if pid == "edge-tts":
                # 2026-04-28: edge-tts removed per no-copyleft policy. Skip
                # any leftover entry in user vault styles.yaml so the chain
                # falls through to piper-tts without a hard error.
                log.info("TTS scene=%s skipping edge-tts (removed in 1.41.0 — GPL)", scene_id)
                continue
            elif pid == "piper-tts":
                resolved = voice_map.get(voice) or "en_US-ryan-high"
                log.info("TTS scene=%s trying piper-tts voice=%s", scene_id, resolved)
                result = await _try_piper(scene_id, clean,
                                          voice=resolved, output_dir=output_dir)
            elif pid == "pyttsx3":
                log.info("TTS scene=%s trying pyttsx3 (last-resort robotic OS voice)", scene_id)
                result = await _try_pyttsx3(scene_id, clean, output_dir=output_dir)
            else:
                log.warning("TTS scene=%s unknown provider %r; skipping", scene_id, pid)
                continue

            if result is not None:
                log.info("TTS %s synthesized via %s (%.1fs)",
                         scene_id, result.provider_used, result.duration_seconds)
                return result
            # Silent None-return: provider imported + ran but produced no file.
            # WARN visibly so the chain's quality drift can be diagnosed.
            log.warning(
                "TTS scene=%s provider=%s returned None (likely empty audio "
                "or zero-byte output); falling through",
                scene_id, pid,
            )
        except Exception as exc:  # noqa: BLE001 — best-effort chain
            last_err = exc
            log.warning("TTS provider %s failed for %s: %s: %s",
                        pid, scene_id, type(exc).__name__, exc)
            continue

    raise TTSProviderUnavailable(
        f"All TTS providers failed for scene {scene_id!r}; last error: {last_err}"
    )


def sanitize_for_tts(text: str) -> str:
    """Strip TTS-hostile characters per styles.yaml validation rules.

    Pure function — em-dash → comma, ellipsis → period, AGNT → Agent.
    Safe to call before queuing TTS regardless of provider.
    """

    if not text:
        return ""
    out = text
    out = out.replace("—", ", ").replace("–", ", ").replace("…", ".")
    out = out.replace("’", "'").replace("‘", "'")
    out = out.replace("“", '"').replace("”", '"')
    out = out.replace("AgntSpace", "Agent Space").replace("AGNTSPACE", "Agent Space")
    out = out.replace("AGNT", "Agent")
    out = out.replace(" AI ", " A.I. ").replace(" AI.", " A.I.")
    return out


# ── Provider chain resolution ───────────────────────────────────

_FALLBACK_CHAIN = [
    {"id": "piper-tts", "enabled": True,
     "voices": {"liam": "en_US-ryan-high"}},
    {"id": "pyttsx3", "enabled": True, "voices": {}},
]


def _resolve_provider_chain(skill_loader: Any) -> list[dict[str, Any]]:
    """Load provider chain from styles.yaml, fall back to hardcoded defaults."""

    if skill_loader is None:
        return _FALLBACK_CHAIN
    try:
        data = skill_loader.load_skill_config_file("video-producer", "styles.yaml")
        if isinstance(data, dict):
            providers = (data.get("tts") or {}).get("providers") or []
            if providers:
                return providers
    except Exception as exc:  # noqa: BLE001
        log.debug("styles.yaml provider chain load failed: %s", exc)
    return _FALLBACK_CHAIN


# ── Helpers ─────────────────────────────────────────────────────


async def _probe_mp3_duration(path: Path) -> float:
    """Probe MP3 duration in seconds via ffprobe.

    2026-04-28 replacement for ``mutagen.mp3.MP3(...)`` (mutagen is GPL-2.0+,
    removed per CLAUDE.md Rule 6). ffprobe ships with ffmpeg, which is
    already a documented system dep for the [video] extra. Returns 0.0
    on any probe failure — duration is metadata; a missing value never
    breaks the synthesis pipeline.
    """
    import shutil  # noqa: PLC0415
    ffprobe_bin = shutil.which("ffprobe")
    if not ffprobe_bin:
        log.warning("ffprobe not on PATH — duration metadata will be 0.0")
        return 0.0
    try:
        proc = await asyncio.create_subprocess_exec(
            ffprobe_bin, "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            log.warning("ffprobe %s failed: %s", path.name,
                        stderr.decode("utf-8", "replace").strip())
            return 0.0
        text = stdout.decode("utf-8", "replace").strip()
        if not text:
            return 0.0
        return round(float(text), 2)
    except Exception as exc:  # noqa: BLE001 — best-effort metadata
        log.warning("ffprobe probe of %s raised: %s", path.name, exc)
        return 0.0


# ── Provider implementations ────────────────────────────────────


async def _try_piper(
    scene_id: str,
    text: str,
    *,
    voice: str,
    output_dir: Path,
) -> TTSResult | None:
    """Local — piper-tts. Auto-downloads ~80MB voice model on first use.

    piper-tts is invoked via subprocess (piper CLI) rather than Python
    bindings because the PyPI package has unstable native bindings
    across platforms. Output is wav; we convert to mp3 via ffmpeg.
    """

    import shutil  # noqa: PLC0415

    piper_bin = shutil.which("piper")
    ffmpeg_bin = shutil.which("ffmpeg")
    if not piper_bin:
        raise ImportError("piper CLI not on PATH; install piper-tts")
    if not ffmpeg_bin:
        raise ImportError("ffmpeg not on PATH; needed for piper→mp3 conversion")

    wav_path = output_dir / f"{scene_id}.wav"
    mp3_path = output_dir / f"{scene_id}.mp3"

    proc = await asyncio.create_subprocess_exec(
        piper_bin, "--model", voice, "--output_file", str(wav_path),
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate(input=text.encode("utf-8"))
    if proc.returncode != 0:
        raise RuntimeError(f"piper exited {proc.returncode}: {stderr.decode('utf-8', 'replace')}")
    if not wav_path.exists() or wav_path.stat().st_size == 0:
        return None

    # Convert wav → mp3 via ffmpeg
    ff = await asyncio.create_subprocess_exec(
        ffmpeg_bin, "-y", "-i", str(wav_path),
        "-codec:a", "libmp3lame", "-qscale:a", "4", str(mp3_path),
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE,
    )
    _, ff_err = await ff.communicate()
    wav_path.unlink(missing_ok=True)
    if ff.returncode != 0:
        raise RuntimeError(f"ffmpeg piper→mp3 failed: {ff_err.decode('utf-8', 'replace')}")

    duration = await _probe_mp3_duration(mp3_path)
    return TTSResult(
        path=mp3_path,
        duration_seconds=duration,
        provider_used="piper-tts",
    )


async def _try_pyttsx3(
    scene_id: str,
    text: str,
    *,
    output_dir: Path,
) -> TTSResult | None:
    """System voices — last resort. SAPI / NSSpeech / espeak. Lazy import.

    pyttsx3 is sync — we run it in a thread pool to avoid blocking the
    event loop. Saves wav, then converts to mp3 via ffmpeg (same as piper).
    """

    import shutil  # noqa: PLC0415
    ffmpeg_bin = shutil.which("ffmpeg")
    if not ffmpeg_bin:
        raise ImportError("ffmpeg not on PATH; needed for pyttsx3→mp3 conversion")

    try:
        import pyttsx3  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(f"pyttsx3 not available: {exc}") from exc

    wav_path = output_dir / f"{scene_id}.wav"
    mp3_path = output_dir / f"{scene_id}.mp3"

    def _run_sync() -> None:
        engine = pyttsx3.init()
        engine.save_to_file(text, str(wav_path))
        engine.runAndWait()
        engine.stop()

    await asyncio.to_thread(_run_sync)
    if not wav_path.exists() or wav_path.stat().st_size == 0:
        return None

    ff = await asyncio.create_subprocess_exec(
        ffmpeg_bin, "-y", "-i", str(wav_path),
        "-codec:a", "libmp3lame", "-qscale:a", "4", str(mp3_path),
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE,
    )
    _, ff_err = await ff.communicate()
    wav_path.unlink(missing_ok=True)
    if ff.returncode != 0:
        raise RuntimeError(f"ffmpeg pyttsx3→mp3 failed: {ff_err.decode('utf-8', 'replace')}")

    duration = await _probe_mp3_duration(mp3_path)
    return TTSResult(
        path=mp3_path,
        duration_seconds=duration,
        provider_used="pyttsx3",
    )
