"""Video generation subsystem — narrated screen-recording pipeline.

Produces short narrated mp4 videos from any vault artifact (wiki article,
KB, project, journal entry, URL). Powers both the user-facing
`create_video` agent tool AND the AgntSpace demo pipeline (Phase 2+
migration of demos/*.mjs onto the same engine).

Architecture (3 layers):
  1. Scene runner (engine.py) — Playwright primitives: open/scroll/caption.
  2. Content adapters (adapters.py) — artifact → scene list.
  3. TTS + composer (tts.py + compose.py) — generate voiceover, compose mp4.

All heavy dependencies (playwright, piper-tts, pyttsx3, moviepy) are
lazy-imported inside the functions that use them. The package imports
cleanly without `pip install agntspace[video]`; calling `create_video()`
without the extra raises a clear, actionable error.

See `tasks/plan-video-feature.md` for the full design.
"""

from __future__ import annotations

__all__ = [
    "VideoSpec",
    "Scene",
    "RenderResult",
    "create_video",
    "VIDEO_DEPS_MISSING_MSG",
]

VIDEO_DEPS_MISSING_MSG = (
    "Video generation requires the optional 'video' extra. "
    "Install with: pip install 'agntspace[video]'"
)


# Public API re-exports — implementations live in submodules.
# These imports MUST stay at the bottom to avoid circular imports.
from .engine import RenderResult, create_video  # noqa: E402
from .specs import Scene, VideoSpec  # noqa: E402
