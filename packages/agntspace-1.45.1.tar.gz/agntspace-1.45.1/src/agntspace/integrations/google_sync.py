"""Google Calendar + Contacts sync — Phase 5 of the second-brain integration.

Read-only sync against Google Calendar v3 + People API v1 via direct
httpx calls (no google-api-python-client dep). Pulls events + contacts
on a daily cron and emits them into the knowledge graph:

- Events → register the event title as an `event` entity, emit
  ``(event:<google_id>, references, person_slug)`` triples for each
  resolvable attendee. Attendees that DON'T resolve get their email
  preserved on the event for later disambiguation.
- Contacts → register `person` entities directly when the registry
  resolves an existing match (auto-merge); queue an approval proposal
  via :class:`ContactProposer` for new ones.

Configuration in ``_meta/google-sync/config/sync.yaml``:

- ``calendar.lookback_days`` / ``calendar.lookahead_days`` — sync window
- ``calendar.calendars`` — which calendars to sync (default: ``primary``)
- ``contacts.batch_size`` — page size for People API
- ``cadence_hours`` — how often the cron fires (default 24)

The sync NEVER writes back to Google. Read-only by design.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

import httpx

log = logging.getLogger(__name__)

_CALENDAR_API = "https://www.googleapis.com/calendar/v3"
_PEOPLE_API = "https://people.googleapis.com/v1"


def _now_utc() -> datetime:
    return datetime.now(UTC)


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


@dataclass
class SyncResult:
    """Aggregate counts from one sync pass."""
    calendar_events_seen: int = 0
    calendar_events_emitted: int = 0
    calendar_attendees_resolved: int = 0
    calendar_triples_emitted: int = 0
    contacts_seen: int = 0
    contacts_auto_merged: int = 0
    contacts_proposed: int = 0
    contacts_skipped_rejected: int = 0
    error: str = ""


# ─────────────────────────────────────────────────────────────────────
# Calendar normalization (pure functions — no I/O)
# ─────────────────────────────────────────────────────────────────────

def normalize_event(raw: dict) -> dict | None:
    """Convert a Google Calendar event dict to our internal shape.

    Returns None for cancelled events / events missing the fields we
    need. Pure function: no I/O, easy to test.
    """
    if not isinstance(raw, dict):
        return None
    if raw.get("status") == "cancelled":
        return None

    google_id = raw.get("id", "")
    summary = (raw.get("summary") or "").strip()
    if not google_id or not summary:
        return None

    start = raw.get("start", {}) or {}
    end = raw.get("end", {}) or {}
    start_iso = start.get("dateTime") or start.get("date") or ""
    end_iso = end.get("dateTime") or end.get("date") or ""

    organizer = raw.get("organizer", {}) or {}
    creator = raw.get("creator", {}) or {}

    attendees: list[dict] = []
    for a in (raw.get("attendees") or []):
        if not isinstance(a, dict):
            continue
        if a.get("self"):
            continue  # the user themself
        if a.get("resource"):
            continue  # meeting room / equipment
        email = (a.get("email") or "").strip()
        name = (a.get("displayName") or "").strip()
        if not email and not name:
            continue
        attendees.append({
            "email": email,
            "name": name or email.split("@")[0] if email else "",
            "response": a.get("responseStatus", ""),
        })

    return {
        "google_id": google_id,
        "summary": summary,
        "description": (raw.get("description") or "")[:1000],
        "location": (raw.get("location") or "").strip(),
        "start": start_iso,
        "end": end_iso,
        "organizer_email": organizer.get("email", ""),
        "organizer_name": organizer.get("displayName", ""),
        "creator_email": creator.get("email", ""),
        "attendees": attendees,
        "html_link": raw.get("htmlLink", ""),
    }


def normalize_contact(raw: dict) -> dict | None:
    """Convert a Google People `Person` resource to our internal shape.

    Returns None for contacts without a usable display name.
    """
    if not isinstance(raw, dict):
        return None
    resource_id = raw.get("resourceName", "")
    if not resource_id:
        return None

    names = raw.get("names") or []
    primary_name = next((n for n in names if isinstance(n, dict) and n.get("metadata", {}).get("primary")), None)
    if primary_name is None and names:
        primary_name = names[0]
    primary_name = primary_name or {}
    display_name = (primary_name.get("displayName") or "").strip()
    if not display_name:
        return None

    given_name = (primary_name.get("givenName") or "").strip()
    family_name = (primary_name.get("familyName") or "").strip()

    emails: list[str] = []
    for e in (raw.get("emailAddresses") or []):
        if isinstance(e, dict):
            v = (e.get("value") or "").strip()
            if v and v not in emails:
                emails.append(v)

    phones: list[str] = []
    for p in (raw.get("phoneNumbers") or []):
        if isinstance(p, dict):
            v = (p.get("canonicalForm") or p.get("value") or "").strip()
            if v and v not in phones:
                phones.append(v)

    orgs: list[str] = []
    for o in (raw.get("organizations") or []):
        if isinstance(o, dict):
            v = (o.get("name") or "").strip()
            if v and v not in orgs:
                orgs.append(v)

    photos = raw.get("photos") or []
    primary_photo = next((p for p in photos if isinstance(p, dict) and p.get("metadata", {}).get("primary")), None)
    photo_url = (primary_photo or {}).get("url", "") if primary_photo else ""

    return {
        "resource_id": resource_id,
        "display_name": display_name,
        "given_name": given_name,
        "family_name": family_name,
        "email_addresses": emails[:10],
        "phone_numbers": phones[:10],
        "organizations": orgs[:5],
        "photo_url": photo_url,
    }


# ─────────────────────────────────────────────────────────────────────
# Sync engine
# ─────────────────────────────────────────────────────────────────────


class GoogleSyncEngine:
    """Read-only sync orchestrator. Construction wires every dependency
    needed for the full event/contact pipeline:

    - ``oauth`` (GoogleOAuth) — for ``ensure_access_token``
    - ``graph`` — for the EntityRegistry + add_triple
    - ``contact_proposer`` (ContactProposer) — for new-contact approval
    - ``activity_logger`` — for sync events (Rule #13)
    - ``skill_loader`` — for ``_meta/google-sync/config/sync.yaml``
    """

    def __init__(
        self,
        *,
        oauth=None,
        graph=None,
        contact_proposer=None,
        activity_logger=None,
        skill_loader=None,
        http_client_factory=None,  # for tests — returns httpx.AsyncClient
    ) -> None:
        self._oauth = oauth
        self._graph = graph
        self._proposer = contact_proposer
        self._activity = activity_logger
        self._skill_loader = skill_loader
        self._http_factory = http_client_factory or (lambda: httpx.AsyncClient(timeout=60.0))

    def _config(self) -> dict:
        """Read sync config from ``_meta/google-sync/config/sync.yaml``.
        Falls back to sensible defaults when missing."""
        defaults = {  # arch:deterministic — engine must boot without the skill
            "calendar": {
                "lookback_days": 30,
                "lookahead_days": 30,
                "calendars": ["primary"],
            },
            "contacts": {
                "batch_size": 200,
            },
            "cadence_hours": 24,
        }
        if self._skill_loader is None:
            return defaults
        try:
            loaded = self._skill_loader.load_skill_config_file("google-sync", "sync.yaml")
        except Exception:  # noqa: BLE001
            return defaults
        if not isinstance(loaded, dict):
            return defaults
        # Shallow merge — top-level keys win, nested dicts merged
        cfg = dict(defaults)
        for k, v in loaded.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                merged = dict(cfg[k])
                merged.update(v)
                cfg[k] = merged
            else:
                cfg[k] = v
        return cfg

    def _registry(self):
        if self._graph is None:
            return None
        return getattr(self._graph, "registry", None) or getattr(self._graph, "_registry", None)

    # ── Calendar ───────────────────────────────────────────────────────

    async def fetch_events(
        self,
        *,
        calendar_id: str,
        time_min: datetime,
        time_max: datetime,
    ) -> list[dict]:
        """Pull events from one Google Calendar via direct HTTP."""
        if self._oauth is None:
            return []
        try:
            access_token = await self._oauth.ensure_access_token()
        except Exception as exc:  # noqa: BLE001
            log.debug("calendar fetch token error: %s", exc)
            return []

        url = f"{_CALENDAR_API}/calendars/{calendar_id}/events"
        params = {
            "timeMin": _iso(time_min),
            "timeMax": _iso(time_max),
            "singleEvents": "true",
            "orderBy": "startTime",
            "maxResults": "250",
        }
        headers = {"Authorization": f"Bearer {access_token}"}
        items: list[dict] = []
        page_token = ""
        try:
            async with self._http_factory() as client:
                while True:
                    if page_token:
                        params["pageToken"] = page_token
                    r = await client.get(url, params=params, headers=headers)
                    r.raise_for_status()
                    payload = r.json()
                    items.extend(payload.get("items") or [])
                    page_token = payload.get("nextPageToken", "")
                    if not page_token:
                        break
        except Exception:  # noqa: BLE001
            log.debug("calendar fetch failed", exc_info=True)
            return items  # return whatever we got
        return items

    def emit_event_to_graph(self, event: dict) -> dict:
        """Register the event as an `event` entity + emit ``references``
        triples for each resolvable attendee. Returns a counts dict.

        Attendees that DON'T resolve through the registry are recorded
        on the event entity's ``situational_context`` so they're visible
        but don't pollute the graph with placeholder persons.
        """
        if self._graph is None:
            return {"emitted": 0, "attendees_resolved": 0, "triples": 0}
        registry = self._registry()
        if registry is None:
            return {"emitted": 0, "attendees_resolved": 0, "triples": 0}

        google_id = event.get("google_id", "")
        summary = event.get("summary", "")
        if not google_id or not summary:
            return {"emitted": 0, "attendees_resolved": 0, "triples": 0}

        # Register the event itself as an `event` entity. Slug derives
        # from summary; the existing fuzzy matcher dedupes recurring
        # events with the same name.
        try:
            registry.add(
                summary,
                entity_type="event",
                authority="system",
            )
        except Exception:  # noqa: BLE001
            log.debug("event entity registration failed", exc_info=True)
            return {"emitted": 0, "attendees_resolved": 0, "triples": 0}

        # For each attendee, try to resolve to a person entity. If we
        # find a match, emit a `(event_source_path, references, person)`
        # triple. Unresolved attendees get recorded but don't pollute
        # the graph.
        triples = 0
        resolved = 0
        unresolved: list[dict] = []
        source_path = f"calendar:{google_id}"

        for attendee in (event.get("attendees") or []):
            name = (attendee.get("name") or "").strip()
            email = (attendee.get("email") or "").strip()
            person_slug = None
            try:
                if name:
                    person_slug = registry.resolve(name)
                if not person_slug and email:
                    # try the email local-part as a fallback
                    local = email.split("@")[0] if "@" in email else email
                    person_slug = registry.resolve(local)
            except Exception:  # noqa: BLE001
                person_slug = None

            if person_slug:
                resolved += 1
                try:
                    tid = self._graph.add_triple(
                        subject=source_path,
                        predicate="references",
                        obj=person_slug,
                        authority="system",
                        source_file=source_path,
                        source_date=event.get("start", "") or _iso(_now_utc()),
                        confidence=0.85,
                        decay_condition="when:unaccessed:90d",
                        subject_type="event",
                        object_type="person",
                        epistemic_status="believed",
                        knowledge_type="episodic",
                        valid_from=event.get("start") or None,
                        valid_until=event.get("end") or None,
                        situational_context={
                            "context_type": "calendar",
                            "matched_text": name or email,
                            "snippet": f"{summary} — {attendee.get('response', '')}",
                            "when": event.get("start", ""),
                            "pass_name": "calendar_attendee",
                            "google_event_id": google_id,
                            "calendar_summary": summary,
                            "attendee_email": email,
                        },
                    )
                except Exception:  # noqa: BLE001
                    log.debug("attendee triple emit failed", exc_info=True)
                    continue
                if tid and tid > 0:
                    triples += 1
            else:
                if name or email:
                    unresolved.append({"name": name, "email": email})

        try:
            self._graph.save()
        except Exception:  # noqa: BLE001
            log.debug("graph save failed after event emit", exc_info=True)

        return {
            "emitted": 1,
            "attendees_resolved": resolved,
            "triples": triples,
            "unresolved_attendees": unresolved,
        }

    async def sync_calendar(self) -> dict:
        """Pull recent + upcoming events from configured calendars and
        emit them into the graph."""
        cfg = self._config()
        cal_cfg = cfg.get("calendar", {}) or {}
        lookback = int(cal_cfg.get("lookback_days", 30))
        lookahead = int(cal_cfg.get("lookahead_days", 30))
        calendars = list(cal_cfg.get("calendars") or ["primary"])

        time_min = _now_utc() - timedelta(days=lookback)
        time_max = _now_utc() + timedelta(days=lookahead)

        result = SyncResult()
        for cal_id in calendars:
            raw_events = await self.fetch_events(
                calendar_id=cal_id, time_min=time_min, time_max=time_max,
            )
            for raw in raw_events:
                result.calendar_events_seen += 1
                normalized = normalize_event(raw)
                if normalized is None:
                    continue
                emit = self.emit_event_to_graph(normalized)
                result.calendar_events_emitted += emit.get("emitted", 0)
                result.calendar_attendees_resolved += emit.get("attendees_resolved", 0)
                result.calendar_triples_emitted += emit.get("triples", 0)
        return _result_to_dict(result)

    # ── Contacts ───────────────────────────────────────────────────────

    async def fetch_contacts(self) -> list[dict]:
        """Pull all connections from Google People API. Read-only;
        paginates until the server stops returning a next-page token."""
        if self._oauth is None:
            return []
        try:
            access_token = await self._oauth.ensure_access_token()
        except Exception as exc:  # noqa: BLE001
            log.debug("contacts fetch token error: %s", exc)
            return []

        cfg = self._config()
        batch_size = int(cfg.get("contacts", {}).get("batch_size", 200))

        url = f"{_PEOPLE_API}/people/me/connections"
        params: dict[str, str] = {
            "personFields": "names,emailAddresses,phoneNumbers,organizations,photos",
            "pageSize": str(batch_size),
        }
        headers = {"Authorization": f"Bearer {access_token}"}
        items: list[dict] = []
        page_token = ""
        try:
            async with self._http_factory() as client:
                while True:
                    if page_token:
                        params["pageToken"] = page_token
                    r = await client.get(url, params=params, headers=headers)
                    r.raise_for_status()
                    payload = r.json()
                    items.extend(payload.get("connections") or [])
                    page_token = payload.get("nextPageToken", "")
                    if not page_token:
                        break
        except Exception:  # noqa: BLE001
            log.debug("contacts fetch failed", exc_info=True)
            return items
        return items

    async def sync_contacts(self) -> dict:
        """Walk all Google contacts. Auto-merge via the registry's fuzzy
        matcher when a name resolves; propose for review when not."""
        result = SyncResult()
        if self._proposer is None:
            return _result_to_dict(result)

        raw_contacts = await self.fetch_contacts()
        for raw in raw_contacts:
            result.contacts_seen += 1
            normalized = normalize_contact(raw)
            if normalized is None:
                continue
            outcome = self._proposer.propose(normalized)
            status = outcome.get("status", "")
            if status == "auto_merged":
                result.contacts_auto_merged += 1
            elif status == "proposed":
                result.contacts_proposed += 1
            elif status == "skipped" and outcome.get("reason") == "previously_rejected":
                result.contacts_skipped_rejected += 1
        return _result_to_dict(result)

    # ── Combined daily sync ────────────────────────────────────────────

    async def sync_all(self) -> dict:
        """One pass over both calendar + contacts. Designed for the
        daily cron handler. Returns aggregated counts. Never raises —
        partial failures are recorded in the ``error`` field."""
        if self._oauth is None or not self._oauth.is_connected():
            return {"error": "not_connected"}

        cal_result: dict = {}
        con_result: dict = {}
        try:
            cal_result = await self.sync_calendar()
        except Exception as exc:  # noqa: BLE001
            cal_result = {"error": f"calendar_sync_failed: {exc}"}
        try:
            con_result = await self.sync_contacts()
        except Exception as exc:  # noqa: BLE001
            con_result = {"error": f"contacts_sync_failed: {exc}"}

        merged = {**cal_result, **con_result}

        if self._activity:
            try:
                self._activity.log(
                    category="knowledge",
                    action="google_sync_completed",
                    summary=(
                        f"Google sync: {merged.get('calendar_events_emitted', 0)} events, "
                        f"{merged.get('contacts_auto_merged', 0)} contacts merged, "
                        f"{merged.get('contacts_proposed', 0)} proposed"
                    ),
                    importance="low",
                    details=merged,
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for google_sync_completed", exc_info=True)

        return merged


def _result_to_dict(r: SyncResult) -> dict:
    return {
        "calendar_events_seen": r.calendar_events_seen,
        "calendar_events_emitted": r.calendar_events_emitted,
        "calendar_attendees_resolved": r.calendar_attendees_resolved,
        "calendar_triples_emitted": r.calendar_triples_emitted,
        "contacts_seen": r.contacts_seen,
        "contacts_auto_merged": r.contacts_auto_merged,
        "contacts_proposed": r.contacts_proposed,
        "contacts_skipped_rejected": r.contacts_skipped_rejected,
        "error": r.error,
    }
