"""Contact proposals — Phase 5 of the second-brain integration push.

Closes part of gap #5 (calendar/contacts integration). When Google Contacts
sync surfaces a contact whose name doesn't resolve to an existing entity
in the registry, the contact gets queued for user approval rather than
silently auto-creating a `person` entity. Mirror of the email-mention
approval gate (Phase 3) — same pattern, different substrate.

Pending files at ``<vault>/agntspace/memory/pending/contact-proposals/<id>.json``.
Approve → register the contact as a `person` entity in the registry +
optionally write a wiki article. Reject → discard with a remembered
"don't ask again" marker.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path

log = logging.getLogger(__name__)

_PENDING_SUBDIR = "memory/pending/contact-proposals"
_REJECTED_SUBDIR = "memory/pending/contact-proposals/.rejected"


@dataclass
class ContactProposal:
    """Pending review record for a Google Contacts contact whose name
    didn't resolve to an existing entity."""

    id: str
    google_resource_id: str  # `people/c<id>` from Google People API
    display_name: str
    given_name: str = ""
    family_name: str = ""
    email_addresses: list[str] = field(default_factory=list)
    phone_numbers: list[str] = field(default_factory=list)
    organizations: list[str] = field(default_factory=list)
    photo_url: str = ""
    detected_at: str = ""


def _proposal_id(google_resource_id: str, display_name: str) -> str:
    """Deterministic id from (resource_id, display_name) so re-syncing
    the same contact is idempotent."""
    raw = f"{google_resource_id}\x00{display_name}".encode()
    return hashlib.sha256(raw).hexdigest()[:12]


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _pending_dir(vault_dir: Path) -> Path:
    return Path(vault_dir) / "agntspace" / _PENDING_SUBDIR


def _rejected_dir(vault_dir: Path) -> Path:
    return Path(vault_dir) / "agntspace" / _REJECTED_SUBDIR


def _proposal_path(vault_dir: Path, proposal_id: str) -> Path:
    return _pending_dir(vault_dir) / f"{proposal_id}.json"


def _rejected_marker_path(vault_dir: Path, proposal_id: str) -> Path:
    return _rejected_dir(vault_dir) / f"{proposal_id}.json"


# ─────────────────────────────────────────────────────────────────────


class ContactProposer:
    """Engine for the contacts-approval queue.

    Construction wires the graph (for the entity registry) + activity
    logger. All optional — degrades to no-op when missing.
    """

    def __init__(
        self,
        *,
        vault_dir: Path,
        graph=None,
        activity_logger=None,
    ) -> None:
        self._vault_dir = Path(vault_dir)
        self._graph = graph
        self._activity_logger = activity_logger

    def _registry(self):
        if self._graph is None:
            return None
        return getattr(self._graph, "registry", None) or getattr(self._graph, "_registry", None)

    def _ensure_dir(self, sub: Path) -> Path:
        sub.mkdir(parents=True, exist_ok=True)
        return sub

    def is_rejected(self, proposal_id: str) -> bool:
        """Return True if the user previously rejected this proposal —
        sync should skip re-proposing it."""
        return _rejected_marker_path(self._vault_dir, proposal_id).exists()

    def propose(self, contact: dict) -> dict:
        """Queue a contact for user approval.

        ``contact`` is the normalized dict from Google People API:
        ``{resource_id, display_name, given_name?, family_name?,
        email_addresses?, phone_numbers?, organizations?, photo_url?}``.

        Skips when:
        - contact has no display_name
        - the user previously rejected this exact contact (don't re-ask)
        - the registry already resolves the display_name to an existing
          entity (auto-merge — no proposal needed)

        Returns ``{status, id?}`` describing the outcome.
        """
        display_name = (contact.get("display_name") or "").strip()
        resource_id = (contact.get("resource_id") or "").strip()

        if not display_name:
            return {"status": "skipped", "reason": "no_display_name"}

        proposal_id = _proposal_id(resource_id, display_name)

        # Don't re-propose what the user already explicitly rejected.
        if self.is_rejected(proposal_id):
            return {"status": "skipped", "reason": "previously_rejected", "id": proposal_id}

        # Auto-merge if the registry already knows this name. The fuzzy
        # matcher handles "John Smith" / "Smith, John" / "J. Smith"
        # variants — when it resolves, we skip the proposal and let the
        # caller use the existing slug.
        registry = self._registry()
        if registry is not None:
            try:
                existing = registry.resolve(display_name)
            except Exception:  # noqa: BLE001
                existing = None
            if existing:
                return {
                    "status": "auto_merged",
                    "id": proposal_id,
                    "matched_slug": existing,
                }

        proposal = ContactProposal(
            id=proposal_id,
            google_resource_id=resource_id,
            display_name=display_name,
            given_name=str(contact.get("given_name") or "")[:200],
            family_name=str(contact.get("family_name") or "")[:200],
            email_addresses=list(contact.get("email_addresses") or [])[:10],
            phone_numbers=list(contact.get("phone_numbers") or [])[:10],
            organizations=list(contact.get("organizations") or [])[:10],
            photo_url=str(contact.get("photo_url") or "")[:500],
            detected_at=_now_iso(),
        )

        try:
            self._ensure_dir(_pending_dir(self._vault_dir))
            path = _proposal_path(self._vault_dir, proposal_id)
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(asdict(proposal), indent=2), encoding="utf-8")
            tmp.replace(path)
        except Exception:  # noqa: BLE001
            log.debug("contact proposal write failed", exc_info=True)
            return {"status": "error", "reason": "write_failed"}

        if self._activity_logger:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="contact_proposed",
                    summary=f"New contact \"{display_name}\" pending review",
                    importance="medium",
                    details={
                        "proposal_id": proposal_id,
                        "resource_id": resource_id,
                        "email_count": len(proposal.email_addresses),
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for contact_proposed", exc_info=True)

        return {"status": "proposed", "id": proposal_id}

    def list_pending(self, limit: int = 200) -> list[dict]:
        d = _pending_dir(self._vault_dir)
        if not d.exists():
            return []
        out: list[dict] = []
        for f in sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[: max(0, limit)]:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                out.append(data)
            except Exception:  # noqa: BLE001
                log.debug("failed to read contact proposal %s", f, exc_info=True)
        return out

    def get(self, proposal_id: str) -> dict | None:
        path = _proposal_path(self._vault_dir, proposal_id)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return None

    def approve(self, proposal_id: str) -> dict:
        """Register the contact as a `person` entity in the registry.

        The display_name + given_name + family_name + organizations are
        all seeded as aliases so the fuzzy matcher can resolve any of
        them. Authority = `explicit` (user confirmed). Source file points
        at the `agntspace-contacts/` mirror (Phase 5+ writes the actual
        contact card; for now we just register the entity).
        """
        proposal = self.get(proposal_id)
        if proposal is None:
            return {"status": "not_found", "id": proposal_id}

        if self._graph is None:
            return {"status": "no_graph", "id": proposal_id}

        registry = self._registry()
        if registry is None:
            return {"status": "no_registry", "id": proposal_id}

        display_name = proposal.get("display_name", "").strip()
        if not display_name:
            return {"status": "invalid", "id": proposal_id, "reason": "missing_display_name"}

        # Build the alias list — full name, individual halves, organization
        # affiliations, and any registered email local-parts.
        aliases: list[str] = []
        for raw in (
            proposal.get("given_name", ""),
            proposal.get("family_name", ""),
            *(proposal.get("organizations") or []),
        ):
            s = str(raw or "").strip()
            if s and s != display_name and s not in aliases:
                aliases.append(s)

        try:
            registry.add(
                display_name,
                entity_type="person",
                aliases=aliases,
                authority="explicit",
            )
        except Exception:  # noqa: BLE001
            log.debug("contact entity registration failed", exc_info=True)
            return {"status": "error", "id": proposal_id, "reason": "registry_write_failed"}

        # Persist registry + delete pending file
        try:
            registry.save()
        except Exception:  # noqa: BLE001
            log.debug("registry save failed after contact approval", exc_info=True)

        try:
            _proposal_path(self._vault_dir, proposal_id).unlink()
        except FileNotFoundError:
            pass
        except Exception:  # noqa: BLE001
            log.debug("failed to delete approved contact proposal", exc_info=True)

        if self._activity_logger:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="contact_approved",
                    summary=f"Approved contact \"{display_name}\" as `person` entity",
                    importance="medium",
                    details={
                        "proposal_id": proposal_id,
                        "display_name": display_name,
                        "alias_count": len(aliases),
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for contact_approved", exc_info=True)

        return {"status": "approved", "id": proposal_id, "aliases": aliases}

    def reject(self, proposal_id: str, *, reason: str = "") -> dict:
        """Discard the proposal AND drop a marker so future syncs don't
        re-propose the same contact. The marker is just an empty JSON
        file at ``.rejected/<id>.json`` — any future ``propose()`` call
        with the same proposal_id short-circuits at ``is_rejected``.
        """
        proposal = self.get(proposal_id)
        if proposal is None:
            return {"status": "not_found", "id": proposal_id}

        # Write rejection marker BEFORE deleting pending file, so we
        # never have a window where it's neither pending nor rejected.
        try:
            self._ensure_dir(_rejected_dir(self._vault_dir))
            marker = _rejected_marker_path(self._vault_dir, proposal_id)
            marker.write_text(
                json.dumps(
                    {
                        "id": proposal_id,
                        "rejected_at": _now_iso(),
                        "reason": reason or "",
                        "display_name": proposal.get("display_name", ""),
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception:  # noqa: BLE001
            log.debug("rejected marker write failed", exc_info=True)

        try:
            _proposal_path(self._vault_dir, proposal_id).unlink()
        except FileNotFoundError:
            pass
        except Exception:  # noqa: BLE001
            log.debug("failed to delete rejected proposal", exc_info=True)

        if self._activity_logger:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="contact_rejected",
                    summary=f"Rejected contact \"{proposal.get('display_name','')[:80]}\"",
                    importance="low",
                    details={
                        "proposal_id": proposal_id,
                        "reason": reason,
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for contact_rejected", exc_info=True)

        return {"status": "rejected", "id": proposal_id, "reason": reason}
