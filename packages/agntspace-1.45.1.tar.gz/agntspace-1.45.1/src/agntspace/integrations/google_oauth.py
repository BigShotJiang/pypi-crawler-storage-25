"""Google OAuth 2.0 — Phase 5 of the second-brain integration push.

Minimal OAuth 2.0 client for Google APIs (Calendar + People). Built
directly on httpx + the existing encrypted ``CredentialStore`` to avoid
pulling in ``google-auth`` / ``google-api-python-client`` (Apache-2.0,
heavy transitive tree).

User flow:

1. POST /api/integrations/google/oauth/start → returns auth URL with
   the configured client_id, redirect_uri, requested scopes, state token.
2. User opens URL in browser, grants consent, Google redirects to our
   callback with ``?code=...&state=...``.
3. GET /api/integrations/google/oauth/callback → exchanges code for
   access + refresh tokens, persists to encrypted store under
   ``service="google_oauth"``.
4. Subsequent API calls use ``ensure_access_token()`` which refreshes
   automatically when the access token is within 60 seconds of expiry.

Token storage shape (encrypted via existing CredentialStore):
    {
      "access_token": "...",
      "refresh_token": "...",
      "expires_at": "<iso8601>",
      "scopes": ["...", ...],
      "token_type": "Bearer"
    }

Configuration (one-time, from the user):
- GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET in CredentialStore under
  service="google_oauth_client". The user creates these in Google
  Cloud Console (OAuth consent screen → Credentials → Web application).
- Authorized redirect URI: http://localhost:8000/api/integrations/google/oauth/callback

Privacy note: this never leaves the user's machine — same posture as
every other AgntSpace integration. Tokens are encrypted at rest by
Fernet (AES-128) keyed off the OS-derived machine key.
"""

from __future__ import annotations

import logging
import secrets
from datetime import UTC, datetime, timedelta
from urllib.parse import urlencode

import httpx

log = logging.getLogger(__name__)

# Google OAuth endpoints. These are stable; documented at
# https://developers.google.com/identity/protocols/oauth2/web-server
_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"

# Scopes for the integration. Read-only by deliberate design — Phase 5
# scope is "ingest into the graph", never write-back to Google.
_SCOPES_CALENDAR = "https://www.googleapis.com/auth/calendar.readonly"
_SCOPES_CONTACTS = "https://www.googleapis.com/auth/contacts.readonly"
DEFAULT_SCOPES = (_SCOPES_CALENDAR, _SCOPES_CONTACTS)

# Storage keys in the CredentialStore
_CLIENT_KEY = "google_oauth_client"
_TOKEN_KEY = "google_oauth"


def _now_utc() -> datetime:
    return datetime.now(UTC)


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


class GoogleOAuthError(Exception):
    """OAuth flow error — failed token exchange, missing client config,
    no refresh token, etc."""


class GoogleOAuth:
    """Stateless wrapper over the Google OAuth 2.0 flow + token store.

    All credentials go through ``CredentialStore`` (encrypted Fernet).
    Configuration is one-time: user pastes client_id + client_secret in
    Settings → Integrations → Google → Connect, server stores them
    under ``service="google_oauth_client"``. Subsequent OAuth calls
    read from there.
    """

    def __init__(
        self,
        credential_store=None,
        *,
        redirect_uri: str = "http://localhost:8000/api/integrations/google/oauth/callback",
        scopes: tuple[str, ...] = DEFAULT_SCOPES,
        token_endpoint: str = _TOKEN_ENDPOINT,
        auth_endpoint: str = _AUTH_ENDPOINT,
    ) -> None:
        self._creds = credential_store
        self._redirect_uri = redirect_uri
        self._scopes = tuple(scopes)
        self._token_endpoint = token_endpoint
        self._auth_endpoint = auth_endpoint

    # ── Configuration ──────────────────────────────────────────────────

    def is_client_configured(self) -> bool:
        """Return True if client_id + client_secret are stored."""
        if self._creds is None:
            return False
        try:
            data = self._creds.get(_CLIENT_KEY) or {}
        except Exception:  # noqa: BLE001
            return False
        return bool(data.get("client_id") and data.get("client_secret"))

    def configure_client(self, client_id: str, client_secret: str) -> None:
        """Persist Google Cloud project credentials to the encrypted
        store. Overwrites any previous client configuration."""
        if self._creds is None:
            raise GoogleOAuthError("credential store not configured")
        self._creds.set(_CLIENT_KEY, {
            "client_id": client_id.strip(),
            "client_secret": client_secret.strip(),
        })

    def _client_credentials(self) -> tuple[str, str]:
        if self._creds is None:
            raise GoogleOAuthError("credential store not configured")
        data = self._creds.get(_CLIENT_KEY) or {}
        cid = data.get("client_id", "")
        secret = data.get("client_secret", "")
        if not cid or not secret:
            raise GoogleOAuthError(
                "Google OAuth client not configured. Set client_id + client_secret first."
            )
        return cid, secret

    # ── Connection state ───────────────────────────────────────────────

    def is_connected(self) -> bool:
        """Return True when we have a usable refresh token."""
        if self._creds is None:
            return False
        try:
            tok = self._creds.get(_TOKEN_KEY) or {}
        except Exception:  # noqa: BLE001
            return False
        return bool(tok.get("refresh_token"))

    def disconnect(self) -> None:
        """Forget tokens. Client credentials remain so a re-connect
        doesn't require re-pasting them."""
        if self._creds is None:
            return
        try:
            self._creds.delete(_TOKEN_KEY)
        except Exception:  # noqa: BLE001
            log.debug("token delete failed", exc_info=True)

    # ── Authorization URL ──────────────────────────────────────────────

    def authorization_url(self, *, state: str | None = None) -> tuple[str, str]:
        """Build the consent URL the user opens in a browser.

        Returns ``(url, state)``. The caller stores ``state`` and
        validates it when Google calls back. ``access_type=offline`` +
        ``prompt=consent`` together guarantee Google issues a refresh
        token even on re-authorization.
        """
        client_id, _ = self._client_credentials()
        state_token = state or secrets.token_urlsafe(32)
        params = {
            "client_id": client_id,
            "redirect_uri": self._redirect_uri,
            "response_type": "code",
            "scope": " ".join(self._scopes),
            "access_type": "offline",
            "prompt": "consent",
            "include_granted_scopes": "true",
            "state": state_token,
        }
        return f"{self._auth_endpoint}?{urlencode(params)}", state_token

    # ── Token exchange + refresh ───────────────────────────────────────

    async def exchange_code(self, code: str) -> dict:
        """Exchange authorization code for access + refresh tokens.
        Persists tokens to the encrypted store. Returns the token dict."""
        client_id, client_secret = self._client_credentials()
        body = {
            "code": code,
            "client_id": client_id,
            "client_secret": client_secret,
            "redirect_uri": self._redirect_uri,
            "grant_type": "authorization_code",
        }
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                r = await client.post(self._token_endpoint, data=body)
                r.raise_for_status()
                payload = r.json()
        except httpx.HTTPStatusError as exc:
            raise GoogleOAuthError(
                f"Token exchange failed: HTTP {exc.response.status_code} {exc.response.text[:200]}"
            ) from exc
        except Exception as exc:  # noqa: BLE001
            raise GoogleOAuthError(f"Token exchange failed: {exc}") from exc

        access = payload.get("access_token", "")
        refresh = payload.get("refresh_token", "")
        expires_in = int(payload.get("expires_in", 3600) or 3600)
        scope = payload.get("scope", " ".join(self._scopes))
        token_type = payload.get("token_type", "Bearer")

        if not access:
            raise GoogleOAuthError(f"Token exchange returned no access_token: {payload}")

        token = {
            "access_token": access,
            "refresh_token": refresh,  # may be empty if user re-consented; we keep the existing one in that case
            "expires_at": _iso(_now_utc() + timedelta(seconds=expires_in)),
            "scopes": scope.split(),
            "token_type": token_type,
        }

        # If the refresh_token is missing AND we already have one stored,
        # preserve the existing one (Google only issues refresh tokens
        # the first time unless prompt=consent was used).
        if not refresh and self._creds is not None:
            existing = self._creds.get(_TOKEN_KEY) or {}
            if existing.get("refresh_token"):
                token["refresh_token"] = existing["refresh_token"]

        if self._creds is not None:
            self._creds.set(_TOKEN_KEY, token)

        return token

    async def refresh_token(self) -> dict:
        """Refresh the access token using the stored refresh token.
        Persists the new access token + expiry."""
        if self._creds is None:
            raise GoogleOAuthError("credential store not configured")
        existing = self._creds.get(_TOKEN_KEY) or {}
        refresh = existing.get("refresh_token", "")
        if not refresh:
            raise GoogleOAuthError("no refresh token — user must re-authorize")

        client_id, client_secret = self._client_credentials()
        body = {
            "refresh_token": refresh,
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": "refresh_token",
        }
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                r = await client.post(self._token_endpoint, data=body)
                r.raise_for_status()
                payload = r.json()
        except httpx.HTTPStatusError as exc:
            raise GoogleOAuthError(
                f"Token refresh failed: HTTP {exc.response.status_code} {exc.response.text[:200]}"
            ) from exc
        except Exception as exc:  # noqa: BLE001
            raise GoogleOAuthError(f"Token refresh failed: {exc}") from exc

        access = payload.get("access_token", "")
        expires_in = int(payload.get("expires_in", 3600) or 3600)
        if not access:
            raise GoogleOAuthError(f"Refresh returned no access_token: {payload}")

        token = {
            **existing,
            "access_token": access,
            "expires_at": _iso(_now_utc() + timedelta(seconds=expires_in)),
        }
        self._creds.set(_TOKEN_KEY, token)
        return token

    async def ensure_access_token(self) -> str:
        """Return a valid access token, refreshing if needed."""
        if self._creds is None:
            raise GoogleOAuthError("credential store not configured")
        token = self._creds.get(_TOKEN_KEY) or {}
        if not token.get("access_token"):
            raise GoogleOAuthError("not connected — run OAuth flow first")

        # Refresh if expired or within 60 seconds of expiry
        expires_at_iso = token.get("expires_at", "")
        try:
            expires_at = datetime.fromisoformat(expires_at_iso)
        except Exception:  # noqa: BLE001
            expires_at = _now_utc()  # treat as expired

        if expires_at <= _now_utc() + timedelta(seconds=60):
            try:
                refreshed = await self.refresh_token()
                return refreshed["access_token"]
            except GoogleOAuthError:
                # Bubble up — caller decides how to surface.
                raise

        return token["access_token"]
