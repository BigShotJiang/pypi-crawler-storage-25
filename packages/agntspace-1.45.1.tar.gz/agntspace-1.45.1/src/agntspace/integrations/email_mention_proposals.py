"""Email mention proposals — Phase 3 of the second-brain integration push.

Closes gap #3 (email content into knowledge) with a USER-APPROVAL gate.
Email body content is sensitive — auto-indexing every read email would
mean private correspondence flowing into the graph silently. Instead,
when an email body produces detected entity references, we write a
pending proposal file that surfaces in the unified ``/proposals`` page.
The user reviews + clicks Approve to emit triples, or Reject to discard.

The substrate mirrors the existing taxonomy / capability proposal
patterns:

- Pending files at ``<vault>/agntspace/memory/pending/email-mentions/<id>.json``
- One file per scanned email; ``id`` is a stable hash of (uid, subject)
- Approve → emit ``(email:<uid>, references, entity_slug)`` triples
  via the existing :class:`MentionIndexer`. Reject → remove file.
- Approval / rejection emit activity events (Rule #13) so the agent
  sees the user's decision in its world model.

The engine is a pure module. The HTTP API + the unified-inbox loader
sit on top.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from agntspace.memory.mention_scanner import resolve_scan_config, scan_mentions

log = logging.getLogger(__name__)


_PENDING_SUBDIR = "memory/pending/email-mentions"


@dataclass
class EmailMentionProposal:
    """Pending review record for an email's mention scan."""

    id: str
    uid: str
    subject: str
    sender: str
    received_at: str
    body_preview: str  # first ~200 chars of body
    word_count: int
    detected_at: str
    mentions: list[dict] = field(default_factory=list)  # entity_slug, snippet, matched_text, offset
    status: str = "pending"  # pending | approved | rejected (rejected files are deleted, status is for in-flight)


def _proposal_id(uid: str, subject: str) -> str:
    """Deterministic id from (uid, subject) so re-scanning the same
    email is idempotent — second scan overwrites the same pending file."""
    raw = f"{uid}\x00{subject}".encode()
    return hashlib.sha256(raw).hexdigest()[:12]


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _pending_dir(vault_dir: Path) -> Path:
    return Path(vault_dir) / "agntspace" / _PENDING_SUBDIR


def _proposal_path(vault_dir: Path, proposal_id: str) -> Path:
    return _pending_dir(vault_dir) / f"{proposal_id}.json"


# ─────────────────────────────────────────────────────────────────────


class EmailMentionProposer:
    """Engine — scans an email body for entity references and writes a
    pending proposal file. Pure side-effects: filesystem write, no
    triples emitted (that's deferred to ``approve`` after user review).

    Construction wires the graph (for the entity registry) + the skill
    loader (for scan config) + the writer (so the pending dir's
    bookkeeping write goes through the contract trust system) +
    the activity logger. All optional — degrades to no-op when missing.
    """

    def __init__(
        self,
        *,
        vault_dir: Path,
        graph=None,
        skill_loader=None,
        activity_logger=None,
        mention_indexer=None,
    ) -> None:
        self._vault_dir = Path(vault_dir)
        self._graph = graph
        self._skill_loader = skill_loader
        self._activity_logger = activity_logger
        self._mention_indexer = mention_indexer

    def _registry(self):
        if self._graph is None:
            return None
        return getattr(self._graph, "registry", None) or getattr(self._graph, "_registry", None)

    def _ensure_dir(self) -> Path:
        d = _pending_dir(self._vault_dir)
        d.mkdir(parents=True, exist_ok=True)
        return d

    def scan(
        self,
        *,
        uid: str,
        subject: str,
        sender: str,
        body: str,
        received_at: str = "",
        min_words: int = 200,
    ) -> dict:
        """Scan an email body and write a pending proposal if any
        mentions were detected.

        Skips when:
        - graph or registry aren't wired
        - body is shorter than ``min_words``
        - no entity references survive the scan

        Returns a dict ``{status, id, mentions_count}`` describing the
        outcome. Never raises — broken proposer never breaks email reads.
        """
        if self._graph is None:
            return {"status": "skipped", "reason": "no_graph"}
        registry = self._registry()
        if registry is None:
            return {"status": "skipped", "reason": "no_registry"}
        if not body:
            return {"status": "skipped", "reason": "empty_body"}

        # Minimum word count gate — short emails (auto-replies, "ok",
        # "sounds good") rarely surface meaningful entity references
        # and aren't worth the user's review attention.
        words = len(body.split())
        if words < min_words:
            return {"status": "skipped", "reason": "too_short", "word_count": words}

        try:
            config = resolve_scan_config(self._skill_loader)
            # Use a synthetic source path for the scanner — the source
            # path written into triples on approval is `email:<uid>`.
            scan_source_path = f"email:{uid}"
            mentions = scan_mentions(
                body,
                registry,
                source_path=scan_source_path,
                context_type="email",
                config=config,
            )
        except Exception:  # noqa: BLE001
            log.debug("email scan failed for uid=%s", uid, exc_info=True)
            return {"status": "error", "reason": "scan_failed"}

        if not mentions:
            return {"status": "skipped", "reason": "no_mentions", "word_count": words}

        proposal_id = _proposal_id(uid, subject)
        proposal = EmailMentionProposal(
            id=proposal_id,
            uid=uid,
            subject=(subject or "")[:200],
            sender=(sender or "")[:200],
            received_at=received_at or "",
            body_preview=(body or "")[:240].replace("\n", " "),
            word_count=words,
            detected_at=_now_iso(),
            mentions=[
                {
                    "entity_slug": m.entity_slug,
                    "snippet": m.snippet,
                    "matched_text": m.matched_text,
                    "offset": m.offset,
                }
                for m in mentions
            ],
            status="pending",
        )

        try:
            self._ensure_dir()
            path = _proposal_path(self._vault_dir, proposal_id)
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(asdict(proposal), indent=2), encoding="utf-8")
            tmp.replace(path)
        except Exception:  # noqa: BLE001
            log.debug("email mention proposal write failed", exc_info=True)
            return {"status": "error", "reason": "write_failed"}

        if self._activity_logger:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="email_mentions_proposed",
                    summary=f"Email \"{proposal.subject}\" produced {len(mentions)} entity mention(s) for review",
                    importance="medium",
                    details={
                        "proposal_id": proposal_id,
                        "uid": uid,
                        "sender": sender,
                        "subject": subject,
                        "mentions_count": len(mentions),
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for email_mentions_proposed", exc_info=True)

        return {
            "status": "proposed",
            "id": proposal_id,
            "mentions_count": len(mentions),
        }

    def list_pending(self, limit: int = 100) -> list[dict]:
        """Return all pending proposals — newest first."""
        d = _pending_dir(self._vault_dir)
        if not d.exists():
            return []
        out: list[dict] = []
        for f in sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[: max(0, limit)]:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                out.append(data)
            except Exception:  # noqa: BLE001
                log.debug("failed to read email proposal %s", f, exc_info=True)
        return out

    def get(self, proposal_id: str) -> dict | None:
        path = _proposal_path(self._vault_dir, proposal_id)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return None

    def approve(self, proposal_id: str) -> dict:
        """User approves the proposal — emit ``references`` triples
        for every detected mention via the wired ``MentionIndexer``,
        then delete the pending file. Idempotent: re-approving an
        already-deleted proposal returns ``not_found``."""
        proposal = self.get(proposal_id)
        if proposal is None:
            return {"status": "not_found", "id": proposal_id}

        if self._mention_indexer is None:
            return {"status": "no_indexer", "id": proposal_id}

        registry = self._registry()
        if registry is None:
            return {"status": "no_registry", "id": proposal_id}

        # Reconstruct the source path used at scan time so triples land
        # in the same shape the wiki MentionsPanel expects.
        source_path = f"email:{proposal.get('uid', proposal_id)}"
        recorded = 0
        for m in proposal.get("mentions", []):
            entity_slug = m.get("entity_slug", "")
            if not entity_slug:
                continue
            try:
                # We bypass the scanner here — the user already approved
                # the mention list. We just emit the triples directly via
                # the graph (single add_triple call per entity).
                tid = self._graph.add_triple(
                    subject=source_path,
                    predicate="references",
                    obj=entity_slug,
                    authority="explicit",  # user approval upgrades to explicit
                    source_file=source_path,
                    source_date=proposal.get("detected_at", _now_iso()),
                    confidence=0.9,
                    decay_condition="when:unaccessed:90d",
                    subject_type="document",
                    object_type="concept",
                    epistemic_status="verified",  # user-confirmed
                    knowledge_type="episodic",
                    valid_from=proposal.get("detected_at") or _now_iso(),
                    situational_context={
                        "snippet": m.get("snippet", ""),
                        "context_type": "email",
                        "matched_text": m.get("matched_text", ""),
                        "offset": int(m.get("offset", 0) or 0),
                        "when": proposal.get("detected_at", _now_iso()),
                        "pass_name": "user_approved",
                        "email_uid": proposal.get("uid", ""),
                        "email_subject": proposal.get("subject", ""),
                        "email_sender": proposal.get("sender", ""),
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("triple emit failed for %s", entity_slug, exc_info=True)
                continue
            if tid and tid > 0:
                recorded += 1

        # Persist + delete pending file
        if recorded > 0:
            try:
                self._graph.save()
            except Exception:  # noqa: BLE001
                log.debug("graph.save failed after email approval", exc_info=True)

        try:
            _proposal_path(self._vault_dir, proposal_id).unlink()
        except FileNotFoundError:
            pass
        except Exception:  # noqa: BLE001
            log.debug("failed to delete approved proposal", exc_info=True)

        if self._activity_logger:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="email_mentions_approved",
                    summary=f"Approved {recorded} email mention(s) for \"{proposal.get('subject', '')[:80]}\"",
                    importance="medium",
                    details={
                        "proposal_id": proposal_id,
                        "uid": proposal.get("uid"),
                        "subject": proposal.get("subject"),
                        "recorded": recorded,
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for email_mentions_approved", exc_info=True)

        return {"status": "approved", "id": proposal_id, "recorded": recorded}

    def reject(self, proposal_id: str, *, reason: str = "") -> dict:
        """User rejects the proposal — discard the pending file with
        no triple emission. Activity event records the user_override
        for Rule #13 awareness."""
        proposal = self.get(proposal_id)
        if proposal is None:
            return {"status": "not_found", "id": proposal_id}

        try:
            _proposal_path(self._vault_dir, proposal_id).unlink()
        except FileNotFoundError:
            pass
        except Exception:  # noqa: BLE001
            log.debug("failed to delete rejected proposal", exc_info=True)

        if self._activity_logger:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="email_mentions_rejected",
                    summary=f"Rejected email mentions for \"{proposal.get('subject', '')[:80]}\"",
                    importance="low",
                    details={
                        "proposal_id": proposal_id,
                        "uid": proposal.get("uid"),
                        "reason": reason,
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity log failed for email_mentions_rejected", exc_info=True)

        return {"status": "rejected", "id": proposal_id, "reason": reason}
