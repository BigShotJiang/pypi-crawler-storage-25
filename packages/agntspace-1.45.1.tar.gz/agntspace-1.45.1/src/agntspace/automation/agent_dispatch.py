"""Agent-mediated KB ingest dispatcher.

The single place that calls ``agent.invoke_skill("kb-ingest", ...)``. Used by
the work-queue ``ingest`` handler. The watcher does NOT call this directly —
it enqueues to the work queue, which calls this helper. That separation is
the architectural commitment of Phase 1 (see
[tasks/plan-pipeline-architectural-fix.md](../../../../../tasks/plan-pipeline-architectural-fix.md)).

Behavior contract:
  - Success → return DispatchOutcome with status="success" and mutations dict.
  - SkillZeroEffect → status="zero_effect", mutations preserved, no fallback.
  - TimeoutError → status="timeout", emits HIGH-importance event, no fallback.
  - Other exception → status="error", logged.

The caller (work-queue handler) decides retry policy. This dispatcher never
re-enqueues itself — that's the queue's job.

Architectural rule: NO fallback to ``kb_service.ingest()`` direct on failure.
Per [memory: feedback_reliability_over_speed.md] (the reliability-over-speed
rule), "never skip agents for speed." The legacy fallback shape is banned by
[tests/arch/test_no_silent_agent_fallback.py](../../../../../tests/arch/test_no_silent_agent_fallback.py).
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from agntspace.activity.logger import ActivityLogger
    from agntspace.agent.agent import Agent
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# Deterministic fallbacks — used when the watcher-pipeline skill YAML is
# missing or malformed. Read by ``resolve_dispatch_config()``.
# arch:deterministic — engine substrate degraded-mode fallback per Rule 12.
_FALLBACK_TIMEOUT_SECONDS: int = 600
_FALLBACK_LONG_DISPATCH_SECONDS: int = 60


DispatchStatus = Literal["success", "zero_effect", "timeout", "error", "skipped"]


@dataclass
class DispatchOutcome:
    """Result of one ``agent.invoke_skill("kb-ingest")`` call.

    Mirrors what the legacy ``raw_watcher._ingest_via_agent`` returned so the
    work-queue handler can keep the existing decision-log + activity-event
    shape unchanged. The ``status`` field is the new dimension Phase 3 reads
    when computing dispatch state transitions.
    """

    slug: str
    status: DispatchStatus
    elapsed_seconds: float
    mutations: dict[str, Any] = field(default_factory=dict)
    error_type: str = ""
    error_message: str = ""

    @property
    def succeeded(self) -> bool:
        return self.status == "success"

    @property
    def is_zero_effect(self) -> bool:
        return self.status == "zero_effect"

    def to_handler_result(self) -> dict[str, Any]:
        """Shape returned to the work-queue handler — backwards-compatible
        with what the legacy direct-ingest path returned, so callers reading
        ``result.get("ingested", [])`` keep working."""
        return {
            "slug": self.slug,
            "via": "agent",
            "status": self.status,
            "ingested": [],  # populated via activity events, not here
            "skipped": [],
            "count": int(self.mutations.get("tool_calls", 0) or 0),
            "vault_writes": int(self.mutations.get("vault_writes", 0) or 0),
            "mutations": self.mutations,
            "elapsed_s": self.elapsed_seconds,
            "error_type": self.error_type,
            "error_message": self.error_message,
        }


def resolve_dispatch_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Read tuning knobs from ``_meta/watcher-pipeline/config/dispatch.yaml``.

    Falls back to deterministic constants when the YAML is missing, malformed,
    or returns a non-dict shape. Never raises.
    """
    cfg: dict[str, Any] = {
        "timeout_seconds": _FALLBACK_TIMEOUT_SECONDS,
        "long_dispatch_warning_seconds": _FALLBACK_LONG_DISPATCH_SECONDS,
    }
    if skill_loader is None:
        return cfg
    try:
        loaded = skill_loader.load_skill_config_file(
            "watcher-pipeline", "dispatch.yaml",
        )
    except Exception:  # noqa: BLE001 — skill loader is a black box at this layer
        log.debug("watcher-pipeline: failed to load dispatch.yaml", exc_info=True)
        return cfg
    if not isinstance(loaded, dict):
        return cfg
    dispatch_block = loaded.get("dispatch")
    if isinstance(dispatch_block, dict):
        try:
            timeout = int(dispatch_block.get("timeout_seconds", cfg["timeout_seconds"]))
            if timeout >= 60:
                cfg["timeout_seconds"] = timeout
        except (TypeError, ValueError):
            pass
        try:
            long_warning = int(
                dispatch_block.get(
                    "long_dispatch_warning_seconds",
                    cfg["long_dispatch_warning_seconds"],
                ),
            )
            if 5 <= long_warning <= 600:
                cfg["long_dispatch_warning_seconds"] = long_warning
        except (TypeError, ValueError):
            pass
    return cfg


class AgentIngestDispatcher:
    """Single-purpose dispatcher: ``agent.invoke_skill("kb-ingest", {slug})``.

    Wraps the call with:
      - Configurable hard timeout (default 600s).
      - Long-dispatch heartbeat task that emits a medium-importance event after
        N seconds so the UI shows the user the dispatch is alive.
      - Structured ``DispatchOutcome`` return shape including status + mutations
        + error details, so callers (work-queue handler today, dispatch-state
        machine in Phase 3) can branch on outcome without parsing strings.

    Failure modes are NEVER converted to silent fallbacks. The caller decides
    retry policy.
    """

    def __init__(
        self,
        agent: Agent | None,
        *,
        activity_logger: ActivityLogger | None = None,
        skill_loader: SkillLoader | None = None,
        timeout_seconds: int | None = None,
        long_dispatch_warning_seconds: int | None = None,
    ) -> None:
        self._agent = agent
        self._activity = activity_logger
        cfg = resolve_dispatch_config(skill_loader)
        self._timeout_seconds = (
            timeout_seconds if timeout_seconds is not None else cfg["timeout_seconds"]
        )
        self._long_dispatch_warning_seconds = (
            long_dispatch_warning_seconds
            if long_dispatch_warning_seconds is not None
            else cfg["long_dispatch_warning_seconds"]
        )

    @property
    def is_wired(self) -> bool:
        """True iff an agent is available to dispatch through."""
        return self._agent is not None

    async def dispatch(
        self,
        slug: str,
        *,
        caller: str = "watcher",
        agent_name: str = "librarian",
    ) -> DispatchOutcome:
        """Run ``agent.invoke_skill("kb-ingest", {"slug": slug})`` with timeout
        + heartbeat.

        Returns a DispatchOutcome; never raises (errors land in ``status`` +
        ``error_type``). The watcher / work-queue handler is responsible for
        deciding what to do with the outcome.
        """
        if self._agent is None:
            return DispatchOutcome(
                slug=slug,
                status="skipped",
                elapsed_seconds=0.0,
                error_type="no_agent",
                error_message="no agent wired — caller must use direct ingest",
            )

        # Lazy import to avoid the agent-module circular at startup.
        from agntspace.agent.agent import SkillZeroEffect

        t0 = time.monotonic()
        heartbeat_task = asyncio.create_task(
            self._long_dispatch_heartbeat(slug),
        )

        try:
            outcome = await asyncio.wait_for(
                self._agent.invoke_skill(  # type: ignore[attr-defined]
                    "kb-ingest",
                    {"slug": slug},
                    agent_name=agent_name,
                    caller=caller,
                ),
                timeout=self._timeout_seconds,
            )
            elapsed = time.monotonic() - t0
            return DispatchOutcome(
                slug=slug,
                status="success",
                elapsed_seconds=elapsed,
                mutations=dict(outcome.mutations or {}),
            )

        except SkillZeroEffect as exc:
            elapsed = time.monotonic() - t0
            log.warning(
                "kb-ingest via agent produced zero effect for %s (%.1fs, mutations=%s)",
                slug, elapsed, exc.mutations,
            )
            return DispatchOutcome(
                slug=slug,
                status="zero_effect",
                elapsed_seconds=elapsed,
                mutations=dict(exc.mutations or {}),
                error_type="skill_zero_effect",
                error_message=str(exc),
            )

        except TimeoutError:
            elapsed = time.monotonic() - t0
            log.warning(
                "kb-ingest via agent timed out for %s after %.0fs (cap %ds)",
                slug, elapsed, self._timeout_seconds,
            )
            self._emit_event(
                action="ingest_agent_timeout",
                summary=(
                    f"Ingest agent timed out on KB '{slug}' after "
                    f"{int(elapsed)}s. Work queue will retry."
                ),
                details={
                    "slug": slug,
                    "elapsed_s": int(elapsed),
                    "timeout_s": self._timeout_seconds,
                    "next_action": "work_queue_retry",
                },
                importance="high",
            )
            return DispatchOutcome(
                slug=slug,
                status="timeout",
                elapsed_seconds=elapsed,
                error_type="timeout",
                error_message=(
                    f"agent.invoke_skill timed out after {int(elapsed)}s "
                    f"(cap {self._timeout_seconds}s)"
                ),
            )

        except Exception as exc:  # noqa: BLE001 — caller decides retry policy
            elapsed = time.monotonic() - t0
            log.exception("kb-ingest via agent raised for slug=%s", slug)
            return DispatchOutcome(
                slug=slug,
                status="error",
                elapsed_seconds=elapsed,
                error_type=type(exc).__name__,
                error_message=str(exc),
            )

        finally:
            heartbeat_task.cancel()
            # Suppress the cancellation noise in the event loop.
            try:
                await heartbeat_task
            except (asyncio.CancelledError, BaseException):  # noqa: BLE001
                pass

    async def _long_dispatch_heartbeat(self, slug: str) -> None:
        """Emit a medium-importance "still working" event after the configured
        threshold so the UI shows the user the dispatch is alive."""
        try:
            await asyncio.sleep(self._long_dispatch_warning_seconds)
        except asyncio.CancelledError:
            return
        self._emit_event(
            action="ingest_agent_long_dispatch",
            summary=(
                f"Ingest agent still working on KB '{slug}' after "
                f"{self._long_dispatch_warning_seconds}s — this is normal "
                "for large batches or local LLMs."
            ),
            details={
                "slug": slug,
                "elapsed_s": self._long_dispatch_warning_seconds,
                "timeout_s": self._timeout_seconds,
            },
            importance="medium",
        )

    def _emit_event(
        self,
        *,
        action: str,
        summary: str,
        details: dict[str, Any],
        importance: str,
    ) -> None:
        if self._activity is None:
            return
        try:
            self._activity.log(  # type: ignore[attr-defined]
                category="knowledge",
                action=action,
                summary=summary,
                details=details,
                importance=importance,
            )
        except Exception:
            log.debug("agent_dispatch: activity event emit failed", exc_info=True)


__all__ = [
    "AgentIngestDispatcher",
    "DispatchOutcome",
    "DispatchStatus",
    "resolve_dispatch_config",
]
