"""Daemon installer — register AgntSpace to autostart for the current user.

**Per-user mechanism on every platform.** A LocalSystem-bound mechanism
(Windows Service via NSSM, system-level systemd unit) silently breaks the
agent: ``Path.home()`` resolves to the SYSTEM profile, so the running
process can't find the user's ``~/.agntspace/config.toml``, encrypted
credentials, vault, or anything else. The user sees "the app didn't
autostart" because even though the process IS up, it's pointing at a
phantom empty profile.

Per-user mechanisms (Task Scheduler logon task, ``systemd --user``,
launchd ``LaunchAgents``) all run as the logged-in user with the right
``Path.home()`` and the right env. They start when the user signs in,
which is what "autostart" means for a personal app on a desktop.

Backwards compatibility: at install time we detect and remove any legacy
NSSM service / system-level systemd unit so existing installs migrate
cleanly to the per-user shape on the next ``Enable autostart`` click.

| Platform | Mechanism | Location |
|----------|-----------|----------|
| Windows | Task Scheduler (logon task) | ``\\agntspace`` task |
| Linux | ``systemd --user`` | ``~/.config/systemd/user/agntspace.service`` |
| macOS | launchd ``LaunchAgents`` | ``~/Library/LaunchAgents/com.archerfutura.agntspace.plist`` |
"""

from __future__ import annotations

import getpass
import logging
import os
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

log = logging.getLogger(__name__)

SERVICE_NAME = "agntspace"
SERVICE_DISPLAY = "AgntSpace Agent"
SERVICE_DESC = "Personal AI agent that runs your life alongside you."

LAUNCHD_LABEL = f"com.archerfutura.{SERVICE_NAME}"


# ── Public dispatchers ──────────────────────────────────────────────────────


def install_daemon(
    host: str = "127.0.0.1",
    port: int = 8000,
    *,
    start_after_install: bool = True,
) -> str:
    """Install AgntSpace as a per-user autostart entry. Returns status message.

    When ``start_after_install`` is False the installer registers (and enables)
    the entry but does NOT start it. The HTTP route that triggers an install
    from the running server passes False to avoid a self-kill race: starting
    the new instance would spawn a sibling on the same host:port whose
    ``_try_reclaim_port`` boot helper kills the live process mid-response,
    making the success look like a failure to the browser.
    """
    system = platform.system()
    if system == "Windows":
        return _install_windows(host, port, start_after_install=start_after_install)
    if system == "Linux":
        return _install_linux(host, port, start_after_install=start_after_install)
    if system == "Darwin":
        return _install_macos(host, port, start_after_install=start_after_install)
    return f"Unsupported platform: {system}"


def uninstall_daemon() -> str:
    """Remove AgntSpace autostart entry. Returns status message.

    Removes BOTH the new per-user entry AND any legacy LocalSystem-scoped
    install (NSSM service on Windows, ``/etc/systemd/system/`` unit on Linux).
    """
    system = platform.system()
    if system == "Windows":
        return _uninstall_windows()
    if system == "Linux":
        return _uninstall_linux()
    if system == "Darwin":
        return _uninstall_macos()
    return f"Unsupported platform: {system}"


def daemon_status() -> dict:
    """Check whether the autostart entry is installed and running.

    Returns ``{platform, method, installed, running, scope, legacy}`` where:
      - ``scope`` is ``"user"`` for the new per-user mechanism, ``"system"``
        for a legacy LocalSystem-scoped install (we surface this so the UI
        can prompt the user to reinstall).
      - ``legacy`` is True when only a legacy install was found.
    """
    system = platform.system()
    result = {
        "platform": system,
        "installed": False,
        "running": False,
        "method": "",
        "scope": "",
        "legacy": False,
    }

    if system == "Windows":
        result["method"] = "Task Scheduler (logon task)"
        return _status_windows(result)
    if system == "Linux":
        result["method"] = "systemd --user"
        return _status_linux(result)
    if system == "Darwin":
        result["method"] = "launchd"
        return _status_macos(result)
    return result


# ── Windows (Task Scheduler logon task) ─────────────────────────────────────


def _current_windows_user_id() -> str:
    """Return ``DOMAIN\\user`` for the current logged-in user.

    Falls back to ``HOSTNAME\\<getpass.getuser()>`` if the standard env vars
    aren't set (rare on Windows but defends against weird runners).
    """
    user = os.environ.get("USERNAME") or getpass.getuser()
    domain = os.environ.get("USERDOMAIN") or socket.gethostname()
    return f"{domain}\\{user}"


def _build_logon_task_xml(host: str, port: int, *, python: str, user_id: str) -> str:
    """Render a Task Scheduler 1.2 XML for a per-user logon task.

    Settings chosen for a long-running personal-app process:
      - ``LogonTrigger`` with explicit ``UserId`` so the task only fires for
        THIS user (matters on shared machines).
      - ``InteractiveToken`` principal — runs in the user's interactive
        session with the correct ``HKEY_CURRENT_USER``, no stored password.
      - ``MultipleInstancesPolicy=IgnoreNew`` — re-login doesn't spawn a
        second instance.
      - ``ExecutionTimeLimit=PT0S`` — never auto-terminate; this is a
        long-running daemon, not a maintenance task.
      - ``RestartOnFailure`` — auto-restart up to 3 times at 1-min intervals
        if the process crashes (matches the NSSM/systemd behaviour).
      - ``DisallowStartIfOnBatteries=false`` + ``StopIfGoingOnBatteries=false``
        — laptops shouldn't lose the agent on unplug.
    """
    args = f"-m agntspace.cli start --host {host} --port {port}"
    working_dir = str(Path.home())
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>{SERVICE_DESC}</Description>
    <Author>AgntSpace</Author>
    <URI>\\{SERVICE_NAME}</URI>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <UserId>{user_id}</UserId>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{user_id}</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>3</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{python}</Command>
      <Arguments>{args}</Arguments>
      <WorkingDirectory>{working_dir}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"""


_LEGACY_NSSM_NEEDS_ADMIN_HINT = (
    f"Found a legacy NSSM service '{SERVICE_NAME}' that needs an elevated\n"
    f"  terminal to remove. Open PowerShell as Administrator and run:\n"
    f"      sc.exe delete {SERVICE_NAME}\n"
    f"  (Harmless to leave — Paused services don't run, but it'll show in\n"
    f"  services.msc next to your new logon task.)"
)


def _remove_legacy_nssm_service() -> str | None:
    """Best-effort cleanup of the pre-2026 NSSM service.

    Verifies removal by RE-RUNNING ``nssm status`` after the remove call,
    rather than trusting ``nssm remove``'s exit code. Why: ``nssm remove``
    returns rc=0 even when it prints "Administrator access is needed" to
    stderr — observed live on a non-elevated session. Trust observed
    state, not the return code.

    Possible return values:
      - ``None``: no legacy service found (NSSM not on PATH, or no
        ``agntspace`` service registered).
      - ``"Removed legacy NSSM service ..."``: cleanly removed.
      - ``_LEGACY_NSSM_NEEDS_ADMIN_HINT``: the service is still
        registered after our removal attempt; surface the elevated-shell
        command for the user.

    Never raises — legacy state is opportunistic.
    """
    nssm = shutil.which("nssm")
    if not nssm:
        return None
    if not _nssm_service_exists(nssm):
        return None

    # Best-effort stop + remove. Don't trust the return codes.
    try:
        subprocess.run([nssm, "stop", SERVICE_NAME], capture_output=True, timeout=10)
        subprocess.run(
            [nssm, "remove", SERVICE_NAME, "confirm"],
            capture_output=True, text=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        # Tool went missing mid-call or hung. Verification below decides.
        pass

    # Verify by re-checking status. If the service is still registered,
    # the remove failed silently (typically access denied).
    if _nssm_service_exists(nssm):
        return _LEGACY_NSSM_NEEDS_ADMIN_HINT
    return "Removed legacy NSSM service (LocalSystem-bound; replaced by user logon task)."


def _nssm_service_exists(nssm: str) -> bool:
    """Return True when ``nssm status agntspace`` reports the service is
    registered. False on missing service, missing nssm, timeout, or any
    error — i.e. fail-closed for "service not found"."""
    try:
        out = subprocess.run(
            [nssm, "status", SERVICE_NAME],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return out.returncode == 0


def _install_windows(host: str, port: int, *, start_after_install: bool = True) -> str:
    if not shutil.which("schtasks"):
        return (
            "schtasks not found on PATH. AgntSpace registers a Windows\n"
            "Task Scheduler logon task; schtasks.exe ships with every modern\n"
            "Windows install. If it's truly missing, your Windows install is\n"
            "non-standard — please report this."
        )

    python = sys.executable
    user_id = _current_windows_user_id()
    legacy_note = _remove_legacy_nssm_service()

    xml = _build_logon_task_xml(host, port, python=python, user_id=user_id)

    # Task Scheduler requires UTF-16 XML. Write to a tempfile so spaces in
    # the path don't break command-line parsing. ``delete=False`` because
    # schtasks reads the file AFTER the context manager exits — we own the
    # cleanup in the finally block.
    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".xml", prefix="agntspace-task-", delete=False,
    ) as tmp:
        tmp.write(xml.encode("utf-16"))
        tmp_path = tmp.name
    try:
        result = subprocess.run(
            ["schtasks", "/Create", "/TN", SERVICE_NAME, "/XML", tmp_path, "/F"],
            capture_output=True, text=True, timeout=15,
        )
    finally:
        try:
            Path(tmp_path).unlink()
        except OSError:
            pass

    if result.returncode != 0:
        err = (result.stderr or result.stdout or "").strip()
        return f"Failed to register task: {err or 'schtasks returned non-zero'}"

    prefix = f"{legacy_note}\n" if legacy_note else ""

    if start_after_install:
        subprocess.run(
            ["schtasks", "/Run", "/TN", SERVICE_NAME],
            capture_output=True, timeout=10,
        )
        return (
            f"{prefix}AgntSpace registered as scheduled task '{SERVICE_NAME}'.\n"
            f"  Runs as: {user_id} (per-user, no stored password).\n"
            f"  Auto-starts at every logon, auto-restarts on crash.\n"
            f"  Manage: schtasks /Run|/End|/Query /TN {SERVICE_NAME}\n"
            f"  Logs: ~/.agntspace/logs/"
        )

    return (
        f"{prefix}AgntSpace registered as scheduled task '{SERVICE_NAME}'.\n"
        f"  Runs as: {user_id} (per-user, no stored password).\n"
        f"  Auto-starts at next logon.\n"
        f"  To hand off now, restart this server (the task will take over port {port}).\n"
        f"  Or start manually: schtasks /Run /TN {SERVICE_NAME}\n"
        f"  Logs: ~/.agntspace/logs/"
    )


def _uninstall_windows() -> str:
    notes: list[str] = []

    # New per-user task.
    if shutil.which("schtasks"):
        result = subprocess.run(
            ["schtasks", "/Delete", "/TN", SERVICE_NAME, "/F"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            notes.append(f"Scheduled task '{SERVICE_NAME}' removed.")

    # Legacy NSSM service.
    legacy = _remove_legacy_nssm_service()
    if legacy:
        notes.append(legacy)

    if notes:
        return "\n".join(notes)
    return f"No autostart entry found for '{SERVICE_NAME}'."


def _status_windows(result: dict) -> dict:
    if shutil.which("schtasks"):
        try:
            out = subprocess.run(
                ["schtasks", "/Query", "/TN", SERVICE_NAME, "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=5,
            )
            if out.returncode == 0 and out.stdout.strip():
                result["installed"] = True
                result["scope"] = "user"
                # CSV: "TaskName","NextRunTime","Status"
                line = out.stdout.strip().splitlines()[0]
                # Defensive parse — schtasks sometimes wraps fields oddly.
                fields = [f.strip().strip('"') for f in line.split('","')]
                if len(fields) >= 3:
                    status = fields[2].rstrip('"').strip()
                    result["running"] = status.lower() == "running"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    # Surface any legacy NSSM service so the UI can prompt for re-install.
    if not result["installed"]:
        nssm = shutil.which("nssm")
        if nssm:
            try:
                out = subprocess.run(
                    [nssm, "status", SERVICE_NAME],
                    capture_output=True, text=True, timeout=5,
                )
                if out.returncode == 0:
                    result["installed"] = True
                    result["running"] = "SERVICE_RUNNING" in out.stdout
                    result["scope"] = "system"
                    result["legacy"] = True
                    result["method"] = "nssm Service (LEGACY — runs as LocalSystem; please reinstall)"
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    return result


# ── Linux (systemd --user) ──────────────────────────────────────────────────


def _user_systemd_unit_path() -> Path:
    """Per-user systemd unit at ``~/.config/systemd/user/agntspace.service``.

    Per the XDG Base Directory spec; ``systemctl --user`` reads from here
    without sudo.
    """
    return Path.home() / ".config/systemd/user" / f"{SERVICE_NAME}.service"


def _legacy_system_systemd_unit_path() -> Path:
    return Path(f"/etc/systemd/system/{SERVICE_NAME}.service")


def _build_user_systemd_unit(host: str, port: int, *, python: str) -> str:
    return f"""[Unit]
Description={SERVICE_DISPLAY}
After=default.target

[Service]
Type=simple
ExecStart={python} -m agntspace.cli start --host {host} --port {port}
Restart=always
RestartSec=5
WorkingDirectory={Path.home()}
Environment=PATH={Path(python).parent}:/usr/bin:/bin

[Install]
WantedBy=default.target
"""


def _detect_legacy_system_systemd_unit() -> str | None:
    """Return a hint to the user if a legacy ``/etc/systemd/system/`` unit
    exists. We can't safely remove it without sudo; the user must do so.
    """
    legacy = _legacy_system_systemd_unit_path()
    if not legacy.exists():
        return None
    return (
        f"Legacy system-level unit found at {legacy}.\n"
        f"  This runs as root and breaks Path.home(). Remove it with:\n"
        f"  sudo systemctl stop {SERVICE_NAME} && sudo systemctl disable {SERVICE_NAME} && sudo rm {legacy}"
    )


def _install_linux(host: str, port: int, *, start_after_install: bool = True) -> str:
    if not shutil.which("systemctl"):
        return (
            "systemctl not found. AgntSpace installs as a per-user systemd\n"
            "service. Your distro doesn't ship systemd; use a startup script\n"
            "in your shell profile or ~/.config/autostart/ instead."
        )

    python = sys.executable
    unit_path = _user_systemd_unit_path()
    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit_path.write_text(_build_user_systemd_unit(host, port, python=python))

    legacy_note = _detect_legacy_system_systemd_unit()

    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=True, capture_output=True, text=True, timeout=10,
        )
        subprocess.run(
            ["systemctl", "--user", "enable", SERVICE_NAME],
            check=True, capture_output=True, text=True, timeout=10,
        )
    except subprocess.CalledProcessError as exc:
        err = (exc.stderr or "").strip()
        return f"systemctl --user failed: {err or exc}"
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return f"systemctl --user not available: {exc}"

    # Best-effort: enable lingering so the service starts at boot, not just
    # at user login. Failure is OK — the service will still start at login.
    user = os.environ.get("USER") or getpass.getuser()
    linger_ok = False
    try:
        linger = subprocess.run(
            ["loginctl", "enable-linger", user],
            capture_output=True, text=True, timeout=10,
        )
        linger_ok = linger.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        linger_ok = False

    linger_note = (
        " (linger enabled — starts at boot)"
        if linger_ok
        else (
            f" (linger NOT enabled — starts at next login;\n"
            f"  run 'sudo loginctl enable-linger {user}' to start at boot)"
        )
    )
    legacy_prefix = f"{legacy_note}\n\n" if legacy_note else ""

    if start_after_install:
        subprocess.run(
            ["systemctl", "--user", "start", SERVICE_NAME],
            capture_output=True, timeout=10,
        )
        return (
            f"{legacy_prefix}AgntSpace installed as user systemd service '{SERVICE_NAME}'.\n"
            f"  Runs as: {user} (per-user, no sudo){linger_note}.\n"
            f"  Auto-starts on login, auto-restarts on crash.\n"
            f"  Manage: systemctl --user start|stop|restart|status {SERVICE_NAME}\n"
            f"  Logs: journalctl --user -u {SERVICE_NAME} -f"
        )

    return (
        f"{legacy_prefix}AgntSpace registered as user systemd service '{SERVICE_NAME}'.\n"
        f"  Runs as: {user} (per-user, no sudo){linger_note}.\n"
        f"  Auto-starts on next login.\n"
        f"  To hand off now, restart this server (the user service will take over port {port}).\n"
        f"  Or start manually: systemctl --user start {SERVICE_NAME}\n"
        f"  Logs: journalctl --user -u {SERVICE_NAME} -f"
    )


def _uninstall_linux() -> str:
    notes: list[str] = []
    unit_path = _user_systemd_unit_path()

    if unit_path.exists() and shutil.which("systemctl"):
        subprocess.run(
            ["systemctl", "--user", "stop", SERVICE_NAME],
            capture_output=True, timeout=10,
        )
        subprocess.run(
            ["systemctl", "--user", "disable", SERVICE_NAME],
            capture_output=True, timeout=10,
        )
        try:
            unit_path.unlink()
        except OSError:
            pass
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True, timeout=10,
        )
        notes.append(f"User service '{SERVICE_NAME}' removed.")

    # Legacy system-level unit needs sudo.
    legacy = _detect_legacy_system_systemd_unit()
    if legacy:
        notes.append(legacy)

    if notes:
        return "\n".join(notes)
    return f"No autostart entry found for '{SERVICE_NAME}'."


def _status_linux(result: dict) -> dict:
    unit_path = _user_systemd_unit_path()
    if unit_path.exists():
        result["installed"] = True
        result["scope"] = "user"
        if shutil.which("systemctl"):
            try:
                out = subprocess.run(
                    ["systemctl", "--user", "is-active", SERVICE_NAME],
                    capture_output=True, text=True, timeout=5,
                )
                result["running"] = out.stdout.strip() == "active"
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    # Surface legacy install separately.
    if not result["installed"] and _legacy_system_systemd_unit_path().exists():
        result["installed"] = True
        result["scope"] = "system"
        result["legacy"] = True
        result["method"] = "systemd /etc/systemd/system (LEGACY — please reinstall)"
        if shutil.which("systemctl"):
            try:
                out = subprocess.run(
                    ["systemctl", "is-active", SERVICE_NAME],
                    capture_output=True, text=True, timeout=5,
                )
                result["running"] = out.stdout.strip() == "active"
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    return result


# ── macOS (launchd LaunchAgents — already per-user) ─────────────────────────


def _macos_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"


def _build_macos_plist(host: str, port: int, *, python: str) -> str:
    log_dir = Path.home() / ".agntspace" / "logs"
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{LAUNCHD_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python}</string>
        <string>-m</string>
        <string>agntspace.cli</string>
        <string>start</string>
        <string>--host</string>
        <string>{host}</string>
        <string>--port</string>
        <string>{port}</string>
    </array>
    <key>WorkingDirectory</key>
    <string>{Path.home()}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/service.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/service-error.log</string>
    <key>ThrottleInterval</key>
    <integer>5</integer>
</dict>
</plist>
"""


def _install_macos(host: str, port: int, *, start_after_install: bool = True) -> str:
    python = sys.executable
    plist_path = _macos_plist_path()
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    plist_path.write_text(_build_macos_plist(host, port, python=python))

    if start_after_install:
        try:
            subprocess.run(
                ["launchctl", "load", str(plist_path)],
                check=True, capture_output=True, text=True, timeout=10,
            )
        except subprocess.CalledProcessError as exc:
            return f"launchctl load failed: {(exc.stderr or '').strip() or exc}"
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            return f"launchctl not available: {exc}"
        return (
            f"AgntSpace installed as launchd agent '{LAUNCHD_LABEL}'.\n"
            f"  Runs as: {os.environ.get('USER', getpass.getuser())} (per-user).\n"
            f"  Auto-starts on login, auto-restarts on crash.\n"
            f"  Manage: launchctl start|stop {LAUNCHD_LABEL}\n"
            f"  Logs: ~/.agntspace/logs/"
        )

    return (
        f"AgntSpace registered as launchd agent '{LAUNCHD_LABEL}'.\n"
        f"  Runs as: {os.environ.get('USER', getpass.getuser())} (per-user).\n"
        f"  Auto-starts on next login.\n"
        f"  To hand off now, restart this server (the agent will take over port {port}).\n"
        f"  Or start manually: launchctl load {plist_path}\n"
        f"  Logs: ~/.agntspace/logs/"
    )


def _uninstall_macos() -> str:
    plist_path = _macos_plist_path()
    if not plist_path.exists():
        return f"No autostart entry found for '{LAUNCHD_LABEL}'."

    try:
        subprocess.run(
            ["launchctl", "unload", str(plist_path)],
            capture_output=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    try:
        plist_path.unlink()
    except OSError:
        pass
    return f"Agent '{LAUNCHD_LABEL}' removed."


def _status_macos(result: dict) -> dict:
    plist_path = _macos_plist_path()
    if plist_path.exists():
        result["installed"] = True
        result["scope"] = "user"
        if shutil.which("launchctl"):
            try:
                out = subprocess.run(
                    ["launchctl", "list", LAUNCHD_LABEL],
                    capture_output=True, text=True, timeout=5,
                )
                result["running"] = out.returncode == 0
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
    return result
