"""Persistent Work Queue — guarantees every LLM-dependent job completes.

SQLite-backed queue that survives server restarts. When an LLM call fails
(model offline, API down, rate limit), the work is queued and retried with
exponential backoff until it succeeds. The system ALWAYS accomplishes the job.

Architecture principle: **No silent failures, no lost work.**
- Every LLM-dependent operation that fails is queued for retry.
- The queue processor checks LLM health before attempting work.
- When the LLM becomes available, all pending work is drained.
- Users are informed of queued work via heartbeat + API.

Job types map to service methods:
  ingest         → kb_service.ingest(slug)
  compile        → kb_service.compile_wiki(slug)
  reflect        → kb_service.reflect(slug)
  research       → kb_service.research(topic, query)
  lint           → kb_service.lint(slug)
  synthesize     → kb_service.synthesize(slug)
  consolidate    → kb_service.consolidate(slug)
  memory_daily   → memory_engine.generate_daily_memory()
  memory_compact → memory_engine.compact(layer)
  wiki_job       → kb_service full pipeline (ingest+compile+reflect+lint)
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import aiosqlite

if TYPE_CHECKING:
    from agntspace.automation.heartbeat import Heartbeat

log = logging.getLogger(__name__)

# Retry delays: exponential backoff capped at 5 minutes, then repeat forever
_RETRY_DELAYS = [10, 30, 60, 120, 300]  # seconds

# Max attempts before marking as dead_letter (0 = infinite)
_MAX_ATTEMPTS = 0  # Never give up by default

# How often the queue processor checks for work (seconds)
_POLL_INTERVAL = 30

# When LLM is unhealthy and there are pending jobs, re-probe every N seconds
# instead of waiting for the 15-minute heartbeat cycle.
_REPROBE_INTERVAL = 60

# Phase 2 (2026-04-30) — zombie detection threshold. A row in state='running'
# whose ``last_heartbeat_at`` is older than this many seconds is treated as
# a zombie (worker died without releasing the row). Workers ping every
# ``_HEARTBEAT_INTERVAL_SECONDS`` (default 30) so a stale heartbeat with
# this 180s threshold means the worker missed 6 consecutive pings — solid
# evidence the worker is dead, not just slow.
# arch:deterministic — engine substrate, tunable via ``WorkQueue`` constructor.
_DEFAULT_HEARTBEAT_INTERVAL_SECONDS: int = 30
_DEFAULT_ZOMBIE_STALE_THRESHOLD_SECONDS: int = 180  # arch:deterministic — 6× heartbeat interval, engine threshold

# Phase 7a (2026-04-30) — per-job hard wall-clock at the queue level.
# Defense in depth against hostage queues: even if a handler doesn't honor
# its OWN timeout (e.g. C extension blocking the GIL, awaitable that never
# yields, recursive deadlock on a contended lock), the queue itself
# force-cancels the task after this duration so the next pending job can
# run. Set generously (15 minutes) — a legit dispatch shouldn't hit it,
# but a wedged dispatch shouldn't hold the queue indefinitely.
#
# The dispatcher's own timeout (600s default in agent_dispatch.py) fires
# FIRST under healthy operation. This 900s wall clock fires only when the
# inner timeout was bypassed (a real bug or a non-cooperative await).
# arch:deterministic — engine substrate, tunable via ``WorkQueue`` constructor.
_DEFAULT_HANDLER_WALL_CLOCK_SECONDS: int = 900

# P2 Phase 1 sub-piece 2 (2026-05-05) — explicit lease semantics on top
# of the Phase 2 heartbeat-based zombie reclaim. The lease columns
# (``worker_id`` + ``lease_until``) align with the new ``ProcessRegistry``
# identity model: ``worker_id`` is the composite ``f"{pid}-{started_at}"``
# (PID-reuse safe), ``lease_until`` is the wall-clock time after which
# the lease expires and the row becomes available again.
#
# Default lease duration = 3× heartbeat interval (90s). Heartbeats
# extend the lease, so a healthy worker keeps the lease far in the
# future. A worker that misses 2 heartbeats has a stale heartbeat AND
# an expired lease — both signals point the same direction.
#
# Why both columns and not replace the legacy ones:
# - Backward compat: pre-migration rows have NULL ``worker_id`` /
#   ``lease_until``; ``reclaim_zombies`` falls back to legacy heartbeat
#   logic for those rows, so no row is left in limbo across the migration.
# - Identity safety: ``worker_pid`` (raw int) can't distinguish "PID
#   1234 from this morning's instance" from "PID 1234 belonging to a
#   recycled process." ``worker_id`` includes started_at, so identity
#   is unique across PID reuse.
# - Forward-compat for Phase 2 (extract worker process): ``worker_id``
#   maps 1:1 onto ``ProcessRegistry.process_id``; web/worker/scheduler
#   in the future split share the same identity space.
#
# arch:deterministic — engine substrate, tunable via ``WorkQueue`` constructor.
_DEFAULT_LEASE_DURATION_SECONDS: int = 90


class WorkQueue:
    """Persistent SQLite-backed work queue with guaranteed completion."""

    def __init__(
        self,
        db: aiosqlite.Connection,
        heartbeat: Heartbeat | None = None,
        *,
        heartbeat_interval_seconds: int | None = None,
        zombie_stale_threshold_seconds: int | None = None,
        handler_wall_clock_seconds: int | None = None,
        lease_duration_seconds: int | None = None,
    ) -> None:
        self._db = db
        self._heartbeat = heartbeat
        self._handlers: dict[str, Any] = {}  # job_type → async callable
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        self._llm_healthy = True
        self._active_model: str = ""
        self._drain_event = asyncio.Event()  # Signal to wake processor immediately
        self._clock: callable | None = None  # Override for testing: returns datetime
        # Optional callback fired when LLM transitions from unhealthy → healthy.
        # Used to auto-restore quarantined watcher files.
        self._restore_quarantine_cb: callable | None = None
        # Optional LLM provider for self-healing health probes.
        # When set, the work queue re-probes the LLM every _REPROBE_INTERVAL
        # seconds instead of waiting up to 15 min for the heartbeat.
        self._llm: object | None = None
        self._last_reprobe: float = 0.0  # monotonic timestamp of last probe
        # Phase 2 (2026-04-30) — zombie detection.
        # ``_heartbeat_interval_seconds`` is how often a running job updates
        # its row's ``last_heartbeat_at`` column.
        # ``_zombie_stale_threshold_seconds`` is the cutoff after which a
        # row in state='running' with a stale heartbeat is reclaimed (flipped
        # back to 'pending' OR moved to dead-letter if max attempts hit).
        self._heartbeat_interval_seconds = (
            heartbeat_interval_seconds
            if heartbeat_interval_seconds is not None
            else _DEFAULT_HEARTBEAT_INTERVAL_SECONDS
        )
        self._zombie_stale_threshold_seconds = (
            zombie_stale_threshold_seconds
            if zombie_stale_threshold_seconds is not None
            else _DEFAULT_ZOMBIE_STALE_THRESHOLD_SECONDS
        )
        # Phase 7a (2026-04-30) — per-job hard wall clock. See constant docstring.
        self._handler_wall_clock_seconds = (
            handler_wall_clock_seconds
            if handler_wall_clock_seconds is not None
            else _DEFAULT_HANDLER_WALL_CLOCK_SECONDS
        )
        # PID of the process running this queue — used to distinguish "rows
        # owned by the current process" from "rows leaked by a prior PID."
        # Captured eagerly so reclaim is correct even if os.getpid() changes
        # later (it doesn't, but defensive).
        import os
        self._worker_pid: int = os.getpid()

        # P2 Phase 1 sub-piece 2 (2026-05-05) — lease columns.
        # ``_lease_duration_seconds`` controls how far in the future
        # ``lease_until`` is set when claiming a job and on every heartbeat.
        # Default 90s = 3× heartbeat interval, so 2 missed heartbeats = stale.
        self._lease_duration_seconds = (
            lease_duration_seconds
            if lease_duration_seconds is not None
            else _DEFAULT_LEASE_DURATION_SECONDS
        )
        # ``_worker_id`` is the composite identity matching
        # ``ProcessRegistry.process_id`` — ``f"{pid}-{started_at}"``.
        # Set by main.py via ``set_worker_id`` AFTER ProcessRegistry has
        # registered so the worker_id values stamped on work_queue rows
        # match the rows in process_registry. Fallback (when not set):
        # ``f"{pid}-startup"`` — sufficient for legacy single-process mode
        # where PID-reuse-during-vault-lifetime is vanishingly rare.
        self._worker_id: str = f"{self._worker_pid}-startup"

    def _now(self) -> datetime:
        """Current time — overridable for testing."""
        if self._clock:
            return self._clock()
        return datetime.now(UTC)

    # ── Schema ──

    async def init_schema(self) -> None:
        """Create work queue tables if they don't exist + run idempotent migrations."""
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS work_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_type TEXT NOT NULL,
                payload TEXT NOT NULL DEFAULT '{}',
                status TEXT NOT NULL DEFAULT 'pending',
                attempts INTEGER NOT NULL DEFAULT 0,
                max_attempts INTEGER NOT NULL DEFAULT 0,
                next_retry TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                started_at TEXT,
                completed_at TEXT,
                error TEXT,
                result TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_wq_status ON work_queue(status);
            CREATE INDEX IF NOT EXISTS idx_wq_next_retry ON work_queue(next_retry);
            CREATE INDEX IF NOT EXISTS idx_wq_job_type ON work_queue(job_type);
        """)
        await self._db.commit()

        # ── Phase 2 (2026-04-30) — heartbeat + worker_pid columns ──
        # Idempotent migrations. Pre-Phase-2 rows have NULL for both
        # columns; ``reclaim_zombies`` treats NULL heartbeat as zombie
        # after a one-time grace period so the first reclaim sweep
        # claims them cleanly.
        for column_def in (
            "ALTER TABLE work_queue ADD COLUMN last_heartbeat_at TEXT",
            "ALTER TABLE work_queue ADD COLUMN worker_pid INTEGER",
            # P2 Phase 1 sub-piece 2 (2026-05-05) — lease columns.
            # ``worker_id`` is the composite identity ``f"{pid}-{started_at}"``
            # matching ``ProcessRegistry.process_id``. ``lease_until`` is
            # the wall-clock time the lease expires. Pre-migration rows
            # carry NULL for both; ``reclaim_zombies`` falls back to the
            # legacy heartbeat logic for those rows so no row is stranded.
            "ALTER TABLE work_queue ADD COLUMN worker_id TEXT",
            "ALTER TABLE work_queue ADD COLUMN lease_until TEXT",
        ):
            try:
                await self._db.execute(column_def)
            except Exception:
                # Column already exists — idempotent re-init is fine.
                pass
        # Index on last_heartbeat_at to make zombie reclaim sweeps fast
        # when the queue grows large.
        try:
            await self._db.execute(
                "CREATE INDEX IF NOT EXISTS idx_wq_heartbeat ON work_queue(last_heartbeat_at)",
            )
        except Exception:
            pass
        # Index on lease_until — same purpose for the new lease-aware
        # reclaim path. Lookups by lease_until are point-in-time checks
        # against ``WHERE lease_until < ?``, exactly the workload an
        # index is built for.
        try:
            await self._db.execute(
                "CREATE INDEX IF NOT EXISTS idx_wq_lease ON work_queue(lease_until)",
            )
        except Exception:
            pass
        await self._db.commit()

    # ── P2 Phase 1 sub-piece 2 — worker_id setter ──

    def set_worker_id(self, worker_id: str) -> None:
        """Set this queue's composite worker identity.

        Called by ``main.py`` lifespan AFTER ``ProcessRegistry.register``
        completes, so the value stamped on rows matches the corresponding
        ``process_registry.process_id`` row. Empty string falls back to
        the constructor default (``f"{pid}-startup"``).

        Pure setter — does not touch existing rows. Future ``_execute_job``
        calls stamp the new value; rows claimed before this call retain
        their previous ``worker_id`` (typically ``-startup``), which is
        still valid for reclaim purposes.
        """
        if worker_id:
            self._worker_id = worker_id

    @property
    def worker_id(self) -> str:
        """Read-only view of the composite worker identity."""
        return self._worker_id

    # ── Handler Registration ──

    def register_handler(self, job_type: str, handler: Any) -> None:
        """Register an async handler for a job type.

        Handler signature: async def handler(payload: dict) -> dict | None
        """
        self._handlers[job_type] = handler
        log.debug("Work queue: registered handler for '%s'", job_type)

    # ── LLM Health ──

    def set_llm_health(self, healthy: bool, model: str = "") -> None:
        """Update LLM availability status. Called by health monitor."""
        was_unhealthy = not self._llm_healthy
        self._llm_healthy = healthy
        if model:
            self._active_model = model
        # Wake the processor if LLM just came back online
        if healthy and was_unhealthy:
            log.info("Work queue: LLM available (%s) — draining pending jobs", model or self._active_model)
            self._drain_event.set()
            # Also auto-restore quarantined files so the watcher retries them.
            if self._restore_quarantine_cb:
                try:
                    self._restore_quarantine_cb()
                except Exception:
                    log.exception("Work queue: auto-restore-quarantine callback failed")

    @property
    def llm_healthy(self) -> bool:
        return self._llm_healthy

    @property
    def active_model(self) -> str:
        return self._active_model

    async def _reprobe_llm_health(self) -> bool:
        """Lightweight LLM probe when unhealthy and pending jobs exist.

        Bridges the gap between the 30s poll interval and the 15-min
        heartbeat cycle so Ollama coming online is detected within ~60s
        instead of up to 15 minutes.
        """
        import time

        now = time.monotonic()
        if now - self._last_reprobe < _REPROBE_INTERVAL:
            return False  # too soon since last probe

        self._last_reprobe = now

        if not self._llm:
            return False  # no provider to probe

        try:
            from agntspace.llm.base import Message as LLMMessage

            await asyncio.wait_for(
                self._llm.complete(  # type: ignore[union-attr]
                    messages=[LLMMessage(role="user", content="ping")],
                    system="Reply with exactly: pong",
                    max_tokens=10,
                    temperature=0,
                ),
                timeout=10,
            )
            # LLM is back — update health
            model_name = getattr(self._llm, "model_name", getattr(self._llm, "_model", ""))
            self.set_llm_health(True, model=model_name)
            log.info("Work queue: LLM reprobe succeeded — draining pending jobs")
            return True
        except Exception:
            # If Ollama mode, try auto-starting it
            _model = getattr(self._llm, "_model", "") or ""
            if _model.startswith("ollama/") or _model.startswith("ollama_chat/"):
                from agntspace.llm.ollama_discovery import ensure_ollama_running
                if ensure_ollama_running():
                    log.info("Work queue: Ollama auto-started, marking healthy")
                    model_name = getattr(self._llm, "model_name", _model)
                    self.set_llm_health(True, model=model_name)
                    return True
            log.debug("Work queue: LLM reprobe still failing")
            return False

    # ── Enqueue ──

    async def enqueue(
        self,
        job_type: str,
        payload: dict | None = None,
        max_attempts: int = _MAX_ATTEMPTS,
        deduplicate: bool = True,
    ) -> int | None:
        """Add a job to the queue. Returns job ID, or None if deduplicated.

        Args:
            job_type: Handler key (e.g., 'ingest', 'compile')
            payload: JSON-serializable dict with job parameters
            max_attempts: 0 = retry forever (default)
            deduplicate: If True, skip if identical pending job exists
        """
        payload = payload or {}
        payload_json = json.dumps(payload, sort_keys=True)
        now = self._now().isoformat()

        if deduplicate:
            # Check for existing pending/failed job with same type and payload
            async with self._db.execute(
                "SELECT id FROM work_queue WHERE job_type = ? AND payload = ? AND status IN ('pending', 'failed')",
                (job_type, payload_json),
            ) as cursor:
                existing = await cursor.fetchone()
                if existing:
                    log.debug("Work queue: dedup — %s already queued (id=%d)", job_type, existing[0])
                    return None

        async with self._db.execute(
            """INSERT INTO work_queue (job_type, payload, status, max_attempts, next_retry, created_at, updated_at)
               VALUES (?, ?, 'pending', ?, ?, ?, ?)""",
            (job_type, payload_json, max_attempts, now, now, now),
        ) as cursor:
            job_id = cursor.lastrowid
        await self._db.commit()

        log.info("Work queue: enqueued %s (id=%d, payload=%s)", job_type, job_id, payload_json[:200])

        if self._heartbeat:
            await self._heartbeat.record_pulse(
                "automation",
                f"Queued {job_type}: {self._describe_job(job_type, payload)}",
            )

        # Wake the processor
        self._drain_event.set()
        return job_id

    # ── Queue Status ──

    async def get_status(self) -> dict:
        """Get queue overview for API/UI.

        Phase 5 (2026-04-30) — Rule 20: counter honesty. The legacy
        ``counts.running`` mixed live workers with orphaned rows, lying
        when zombies accumulated. Now ``counts`` reports six distinct
        keys: ``pending``, ``retrying``, ``running_live``, ``running_orphan``,
        ``completed``, ``dead_letter``. Live + orphan never overlap.

        Backwards compat: ``counts.running`` is preserved as a deprecated
        alias = ``running_live + running_orphan`` for older UIs that
        haven't been updated yet.
        """

        counts: dict[str, int] = {
            "pending": 0,
            "retrying": 0,  # subset of "failed" with next_retry in future
            "running_live": 0,
            "running_orphan": 0,
            "completed": 0,
            "dead_letter": 0,
        }

        # Coarse pass — group by status. Splits running rows in pass 2.
        async with self._db.execute(
            "SELECT status, COUNT(*) FROM work_queue GROUP BY status",
        ) as cursor:
            raw_counts: dict[str, int] = {row[0]: row[1] for row in await cursor.fetchall()}

        counts["pending"] = raw_counts.get("pending", 0)
        # 'failed' rows are scheduled for retry — semantic alias 'retrying'
        # for UI clarity.
        counts["retrying"] = raw_counts.get("failed", 0)
        counts["completed"] = raw_counts.get("completed", 0)
        counts["dead_letter"] = raw_counts.get("dead_letter", 0)

        # Pass 2 — split running by heartbeat freshness.
        cutoff = (
            self._now() - timedelta(seconds=self._zombie_stale_threshold_seconds)
        ).isoformat()
        async with self._db.execute(
            """SELECT
                   SUM(CASE WHEN last_heartbeat_at IS NOT NULL AND last_heartbeat_at >= ? THEN 1 ELSE 0 END) AS live,
                   SUM(CASE WHEN last_heartbeat_at IS NULL OR last_heartbeat_at < ? THEN 1 ELSE 0 END) AS orphan
               FROM work_queue WHERE status = 'running'""",
            (cutoff, cutoff),
        ) as cursor:
            row = await cursor.fetchone()
        counts["running_live"] = int(row[0] or 0) if row else 0
        counts["running_orphan"] = int(row[1] or 0) if row else 0

        # Backwards-compat alias for older UIs reading counts.running.
        # = live + orphan. NEW callers should read running_live separately.
        counts["running"] = counts["running_live"] + counts["running_orphan"]

        pending_jobs: list[dict] = []
        async with self._db.execute(
            """SELECT id, job_type, payload, attempts, next_retry, error, created_at
               FROM work_queue WHERE status IN ('pending', 'failed')
               ORDER BY created_at ASC LIMIT 50""",
        ) as cursor:
            async for row in cursor:
                pending_jobs.append({
                    "id": row[0], "job_type": row[1],
                    "payload": json.loads(row[2]),
                    "attempts": row[3], "next_retry": row[4],
                    "last_error": row[5], "created_at": row[6],
                })

        return {
            "llm_healthy": self._llm_healthy,
            "active_model": self._active_model,
            "counts": counts,
            "pending_jobs": pending_jobs,
            "total_pending": counts["pending"] + counts["retrying"],
        }

    async def get_history(self, limit: int = 50) -> list[dict]:
        """Get recently completed/dead_letter jobs."""
        jobs: list[dict] = []
        async with self._db.execute(
            """SELECT id, job_type, payload, status, attempts, completed_at, error, result
               FROM work_queue WHERE status IN ('completed', 'dead_letter')
               ORDER BY completed_at DESC LIMIT ?""",
            (limit,),
        ) as cursor:
            async for row in cursor:
                jobs.append({
                    "id": row[0], "job_type": row[1],
                    "payload": json.loads(row[2]),
                    "status": row[3], "attempts": row[4],
                    "completed_at": row[5], "error": row[6],
                    "result": row[7],
                })
        return jobs

    # ── Manual Controls ──

    async def retry_job(self, job_id: int) -> bool:
        """Reset a failed/dead_letter job to pending for immediate retry."""
        now = self._now().isoformat()
        async with self._db.execute(
            """UPDATE work_queue SET status = 'pending', next_retry = ?, updated_at = ?, error = NULL
               WHERE id = ? AND status IN ('failed', 'dead_letter')""",
            (now, now, job_id),
        ) as cursor:
            if cursor.rowcount == 0:
                return False
        await self._db.commit()
        self._drain_event.set()
        return True

    async def retry_all(self) -> int:
        """Reset all failed/dead_letter jobs to pending."""
        now = self._now().isoformat()
        async with self._db.execute(
            """UPDATE work_queue SET status = 'pending', next_retry = ?, updated_at = ?, error = NULL
               WHERE status IN ('failed', 'dead_letter')""",
            (now, now),
        ) as cursor:
            count = cursor.rowcount
        await self._db.commit()
        if count:
            self._drain_event.set()
        return count

    async def cancel_job(self, job_id: int) -> bool:
        """Cancel a pending/failed job."""
        async with self._db.execute(
            """DELETE FROM work_queue WHERE id = ? AND status IN ('pending', 'failed', 'dead_letter')""",
            (job_id,),
        ) as cursor:
            if cursor.rowcount == 0:
                return False
        await self._db.commit()
        return True

    async def clear_completed(self, older_than_days: int = 7) -> int:
        """Remove completed jobs older than N days."""
        cutoff = (self._now() - timedelta(days=older_than_days)).isoformat()
        async with self._db.execute(
            "DELETE FROM work_queue WHERE status = 'completed' AND completed_at < ?",
            (cutoff,),
        ) as cursor:
            count = cursor.rowcount
        await self._db.commit()
        return count

    # ── Processing Loop ──

    def start(self) -> None:
        """Start the background queue processor."""
        if self._task and not self._task.done():
            return
        self._running = True
        self._task = asyncio.create_task(self._run())
        log.info("Work queue: processor started")

    def stop(self) -> None:
        """Stop the queue processor."""
        self._running = False
        self._drain_event.set()  # Wake to exit
        if self._task:
            self._task.cancel()
            self._task = None
        log.info("Work queue: processor stopped")

    async def _run(self) -> None:
        """Main processing loop — runs forever, drains queue when LLM is available."""
        await asyncio.sleep(5)  # Let other services initialize

        # Immediately drain any pending jobs from before shutdown
        try:
            processed = await self._process_batch()
            if processed > 0:
                log.info("Work queue: drained %d pending jobs on startup", processed)
        except Exception:
            log.debug("Work queue: startup drain failed, will retry in loop", exc_info=True)

        while self._running:
            try:
                # Wait for signal or poll interval
                try:
                    await asyncio.wait_for(self._drain_event.wait(), timeout=_POLL_INTERVAL)
                except TimeoutError:
                    pass
                self._drain_event.clear()

                if not self._running:
                    break

                # Process all ready jobs
                processed = await self._process_batch()
                if processed > 0:
                    log.info("Work queue: processed %d jobs", processed)

            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Work queue: processor error")
                await asyncio.sleep(10)

    async def _process_batch(self) -> int:
        """Process all jobs that are ready. Returns count of jobs attempted."""
        now = self._now().isoformat()
        processed = 0

        # Fetch ready jobs: pending with next_retry <= now, or NULL next_retry
        async with self._db.execute(
            """SELECT id, job_type, payload, attempts, max_attempts
               FROM work_queue
               WHERE status IN ('pending', 'failed')
                 AND (next_retry IS NULL OR next_retry <= ?)
               ORDER BY created_at ASC""",
            (now,),
        ) as cursor:
            jobs = await cursor.fetchall()

        # If LLM is unhealthy and there are pending jobs, try a quick reprobe
        # before giving up for another 30s cycle.  This closes the 15-minute
        # blind spot between heartbeat ticks.
        if jobs and not self._llm_healthy:
            await self._reprobe_llm_health()

        for row in jobs:
            if not self._running:
                break

            job_id, job_type, payload_json, attempts, max_attempts = row
            payload = json.loads(payload_json)

            # Check if handler exists
            handler = self._handlers.get(job_type)
            if not handler:
                log.warning("Work queue: no handler for job type '%s' (id=%d) — skipping", job_type, job_id)
                continue

            # Check LLM health before attempting LLM-dependent work
            if not self._llm_healthy:
                log.debug("Work queue: LLM unavailable — deferring %s (id=%d)", job_type, job_id)
                continue

            processed += 1
            await self._execute_job(job_id, job_type, payload, handler, attempts, max_attempts)

        return processed

    # ── Phase 2 (2026-04-30) — heartbeat + zombie reclaim ──

    async def _ping_heartbeat_loop(self, job_id: int) -> None:
        """Re-stamp ``last_heartbeat_at`` for a running job until cancelled.

        Runs as a background task spawned by ``_execute_job``. Cancelled when
        the job completes (success / fail / dead-letter). Sleeps the
        configured interval between pings.

        Best-effort — a transient DB error logs at debug and continues; the
        next ping still fires. Worker death cancels this task naturally
        (asyncio task is GC'd with the process), leaving the heartbeat
        stale → reclaim sweep claims the row.
        """
        try:
            while True:
                await asyncio.sleep(self._heartbeat_interval_seconds)
                try:
                    # Heartbeat extends BOTH the legacy heartbeat-at column
                    # (Phase 2) AND the new lease_until (P2 Phase 1 sub-piece
                    # 2). lease_until = now + _lease_duration_seconds — every
                    # ping pushes the expiry further into the future, so a
                    # healthy worker keeps the row's lease comfortably ahead
                    # of any reclaim sweep.
                    now_dt = self._now()
                    now_iso = now_dt.isoformat()
                    lease_until_iso = (
                        now_dt + timedelta(seconds=self._lease_duration_seconds)
                    ).isoformat()
                    await self._db.execute(
                        "UPDATE work_queue SET last_heartbeat_at = ?, lease_until = ? "
                        "WHERE id = ? AND status = 'running'",
                        (now_iso, lease_until_iso, job_id),
                    )
                    await self._db.commit()
                except Exception:
                    # Don't let a transient DB error kill the loop. Next ping retries.
                    log.debug("Work queue: heartbeat ping failed for id=%d", job_id, exc_info=True)
        except asyncio.CancelledError:
            return

    async def reclaim_zombies(self) -> dict:
        """Sweep ``state='running'`` rows whose heartbeat is stale.

        For each row found:
          - If ``attempts < max_attempts`` (or ``max_attempts == 0`` —
            infinite retry) → flip back to ``'pending'`` so the queue
            picks it up on the next cycle. Increment attempts so the
            backoff delay grows.
          - Else → flip to ``'dead_letter'`` and emit a high-importance
            heartbeat pulse so the user sees the give-up.

        Idempotent. Returns ``{"scanned": N, "reclaimed": M, "dead_lettered": K}``.
        Safe to call repeatedly — fresh heartbeats are never touched.

        ``worker_pid`` defense (single-vault): rows whose ``worker_pid``
        matches the CURRENT process AND have a stale heartbeat are STILL
        zombies — that means our own process forked a worker that crashed.
        Reclaim them anyway. The single-vault process-lock invariant means
        no two AgntSpace instances run against the same vault, so a non-
        matching pid is also definitively dead.

        P2 Phase 1 sub-piece 2 (2026-05-05) — lease-aware filter. The
        SELECT now considers a row a zombie if EITHER:
          - ``lease_until`` is set and expired (new path), OR
          - ``last_heartbeat_at`` is NULL or older than the cutoff
            (legacy path — covers pre-migration rows whose lease_until
            is NULL).
        Both signals point the same direction for healthy workers
        (heartbeat ping extends both columns); the lease path is just
        more explicit and cheaper to evaluate (a single point-in-time
        comparison vs. computing now-heartbeat).
        """
        now_dt = self._now()
        now_iso = now_dt.isoformat()
        cutoff = (now_dt - timedelta(seconds=self._zombie_stale_threshold_seconds)).isoformat()

        # Find candidates: state='running' AND any of:
        #   (a) lease_until present and expired,
        #   (b) lease_until missing AND heartbeat NULL or stale (legacy path).
        #
        # NULL lease_until is treated as "no explicit lease set" — fall
        # through to heartbeat check. Pre-migration rows OR rows claimed
        # by an older binary still get reclaimed cleanly.
        async with self._db.execute(
            """SELECT id, job_type, attempts, max_attempts, last_heartbeat_at,
                      worker_pid, worker_id, lease_until
               FROM work_queue
               WHERE status = 'running'
                 AND (
                       (lease_until IS NOT NULL AND lease_until < ?)
                    OR (lease_until IS NULL
                        AND (last_heartbeat_at IS NULL OR last_heartbeat_at < ?))
                 )""",
            (now_iso, cutoff),
        ) as cursor:
            zombies = await cursor.fetchall()

        scanned = len(zombies)
        reclaimed = 0
        dead_lettered = 0

        if not zombies:
            return {"scanned": 0, "reclaimed": 0, "dead_lettered": 0}

        for row in zombies:
            (
                job_id, job_type, attempts, max_attempts,
                last_heartbeat, worker_pid, _worker_id, lease_until,
            ) = row

            # Defensive: skip rows whose lease_until is in the future
            # (race window where a fresh stamp landed between SELECT and
            # UPDATE). Lease is the PRIMARY signal when set; heartbeat
            # is the fallback ONLY when lease_until is NULL (legacy /
            # pre-migration rows). Mixing the two would let a coincidentally
            # fresh heartbeat keep an expired-lease row alive — exactly
            # the failure mode that motivates the lease-as-explicit-expiry
            # design.
            now = self._now()

            if lease_until is not None:
                # Lease is the source of truth for this row. Re-check.
                try:
                    from datetime import datetime as _dt
                    lease_dt = _dt.fromisoformat(lease_until)
                    if lease_dt.tzinfo is None:
                        lease_dt = lease_dt.replace(tzinfo=UTC)
                    if lease_dt > now:
                        continue  # lease still valid — leave it alone
                except (ValueError, TypeError):
                    pass  # malformed lease — treat as zombie
            else:
                # Legacy fallback path: only re-check heartbeat when no
                # lease was ever set (NULL lease_until).
                if last_heartbeat is not None:
                    try:
                        from datetime import datetime as _dt
                        hb_dt = _dt.fromisoformat(last_heartbeat)
                        if hb_dt.tzinfo is None:
                            hb_dt = hb_dt.replace(tzinfo=UTC)
                        age = (now - hb_dt).total_seconds()
                        if age < self._zombie_stale_threshold_seconds:
                            continue  # got a fresh ping — leave it alone
                    except (ValueError, TypeError):
                        pass  # malformed heartbeat — treat as zombie

            if max_attempts > 0 and attempts >= max_attempts:
                # Exhausted — dead-letter via COMPARE-AND-SWAP. The
                # ``WHERE id = ? AND status = 'running'`` clause is
                # load-bearing under concurrent invocation: two writers
                # calling reclaim_zombies simultaneously must not
                # double-process the same row. The first writer's
                # UPDATE flips status from 'running' → 'dead_letter';
                # the second writer's matching UPDATE sees rowcount=0
                # (the row is no longer 'running') and we don't
                # increment our counter. Caught by the Phase 1 stress
                # test ``test_concurrent_reclaim_does_not_double_purge``.
                cursor = await self._db.execute(
                    """UPDATE work_queue
                       SET status = 'dead_letter',
                           error = COALESCE(error, '') || ' [reclaimed_zombie]',
                           updated_at = ?, last_heartbeat_at = NULL,
                           lease_until = NULL
                       WHERE id = ? AND status = 'running'""",
                    (now.isoformat(), job_id),
                )
                row_changed = cursor.rowcount
                await cursor.close()
                if row_changed > 0:
                    dead_lettered += 1
                    if self._heartbeat:
                        try:
                            await self._heartbeat.record_pulse(
                                "error",
                                f"Work queue: {job_type} (id={job_id}) zombie reclaimed → "
                                f"dead-letter (attempts={attempts}/{max_attempts})",
                            )
                        except Exception:
                            pass
            else:
                # Retry via COMPARE-AND-SWAP — flip back to pending so
                # the next cycle picks it up. Clear BOTH legacy heartbeat
                # marker AND new lease so a subsequent reclaim doesn't
                # see the row as still owned. The ``status = 'running'``
                # filter prevents double-counting under concurrent
                # invocation; see the dead-letter branch above for
                # the full rationale.
                cursor = await self._db.execute(
                    """UPDATE work_queue
                       SET status = 'pending',
                           error = COALESCE(error, '') || ' [reclaimed_zombie]',
                           next_retry = ?, updated_at = ?, last_heartbeat_at = NULL,
                           lease_until = NULL
                       WHERE id = ? AND status = 'running'""",
                    (now.isoformat(), now.isoformat(), job_id),
                )
                row_changed = cursor.rowcount
                await cursor.close()
                if row_changed > 0:
                    reclaimed += 1

        await self._db.commit()

        if reclaimed or dead_lettered:
            log.warning(
                "Work queue: zombie reclaim swept %d row(s) — %d retried, %d dead-lettered",
                scanned, reclaimed, dead_lettered,
            )
            # Wake the processor so reclaimed rows get picked up promptly
            self._drain_event.set()

        return {
            "scanned": scanned,
            "reclaimed": reclaimed,
            "dead_lettered": dead_lettered,
        }

    async def _execute_job(
        self,
        job_id: int,
        job_type: str,
        payload: dict,
        handler: Any,
        attempts: int,
        max_attempts: int,
    ) -> None:
        """Execute a single job with error handling and retry scheduling.

        Phase 2 addition (2026-04-30): stamps ``last_heartbeat_at`` and
        ``worker_pid`` at job-start, then spawns a background task that
        re-stamps ``last_heartbeat_at`` every ``_heartbeat_interval_seconds``
        until the job completes. A worker that dies mid-execution leaves a
        stale heartbeat — the next ``reclaim_zombies`` sweep finds the row
        and either retries it (attempt counter < max) or moves it to
        dead-letter. No more zombie ``state='running'`` rows that lie about
        live work.
        """
        now_dt = self._now()
        now = now_dt.isoformat()
        attempts += 1

        # Mark as running + stamp heartbeat + worker_pid + lease.
        # P2 Phase 1 sub-piece 2 (2026-05-05): also stamps the new
        # ``worker_id`` (composite identity matching ProcessRegistry)
        # and ``lease_until`` (explicit wall-clock expiry).
        # ``last_heartbeat_at`` + ``worker_pid`` are kept populated for
        # backward compat with the Phase 2 reclaim-by-heartbeat path
        # so a partial migration doesn't strand any row.
        lease_until = (
            now_dt + timedelta(seconds=self._lease_duration_seconds)
        ).isoformat()
        await self._db.execute(
            """UPDATE work_queue SET status = 'running', started_at = ?, attempts = ?,
               updated_at = ?, last_heartbeat_at = ?, worker_pid = ?,
               worker_id = ?, lease_until = ? WHERE id = ?""",
            (now, attempts, now, now, self._worker_pid,
             self._worker_id, lease_until, job_id),
        )
        await self._db.commit()

        # Spawn the heartbeat ping task. It re-stamps last_heartbeat_at
        # every N seconds so the reclaim sweep can distinguish "running"
        # from "running but worker died." Cancelled in the finally block.
        heartbeat_task = asyncio.create_task(self._ping_heartbeat_loop(job_id))

        try:
            # Phase 7a (2026-04-30) — per-job hard wall clock. The handler
            # may have its own timeout (e.g. agent_dispatch.AgentIngestDispatcher
            # has 600s) but we enforce a strictly-larger ceiling at the queue
            # level so a non-cooperative await CANNOT hold the worker
            # indefinitely. After this fires, the queue moves on; the row
            # is rescheduled like any other failure (retry with backoff,
            # then dead-letter). Hostage scenarios bounded.
            result = await asyncio.wait_for(
                handler(payload),
                timeout=self._handler_wall_clock_seconds,
            )
            result_json = json.dumps(result) if result else None

            # Success — clear heartbeat + lease markers (terminal rows
            # don't need either; clearing the lease is what tells future
            # reclaim sweeps "this row is done, not abandoned").
            completed_at = self._now().isoformat()
            await self._db.execute(
                """UPDATE work_queue
                   SET status = 'completed', completed_at = ?, result = ?, error = NULL,
                       updated_at = ?, last_heartbeat_at = NULL, lease_until = NULL
                   WHERE id = ?""",
                (completed_at, result_json, completed_at, job_id),
            )
            await self._db.commit()
            log.info("Work queue: completed %s (id=%d, attempts=%d)", job_type, job_id, attempts)

        except Exception as exc:
            error_msg = f"{type(exc).__name__}: {exc}"
            log.warning(
                "Work queue: %s failed (id=%d, attempt=%d): %s",
                job_type, job_id, attempts, error_msg,
            )

            # Check if we should give up (only if max_attempts > 0)
            if max_attempts > 0 and attempts >= max_attempts:
                await self._db.execute(
                    """UPDATE work_queue
                       SET status = 'dead_letter', error = ?, updated_at = ?,
                           last_heartbeat_at = NULL, lease_until = NULL
                       WHERE id = ?""",
                    (error_msg, self._now().isoformat(), job_id),
                )
                await self._db.commit()
                log.error("Work queue: %s exhausted max attempts (id=%d) — moved to dead letter", job_type, job_id)
                if self._heartbeat:
                    await self._heartbeat.record_pulse(
                        "error",
                        f"Work queue: {job_type} failed after {attempts} attempts: {error_msg[:200]}",
                    )
                return

            # Schedule retry with exponential backoff
            delay_idx = min(attempts - 1, len(_RETRY_DELAYS) - 1)
            delay = _RETRY_DELAYS[delay_idx]
            next_retry = (self._now() + timedelta(seconds=delay)).isoformat()

            await self._db.execute(
                """UPDATE work_queue
                   SET status = 'failed', error = ?, next_retry = ?, updated_at = ?,
                       last_heartbeat_at = NULL, lease_until = NULL
                   WHERE id = ?""",
                (error_msg, next_retry, self._now().isoformat(), job_id),
            )
            await self._db.commit()
            log.info(
                "Work queue: %s scheduled for retry in %ds (id=%d, attempt=%d)",
                job_type, delay, job_id, attempts,
            )

            # Detect LLM-specific failures and update health
            from agntspace.llm.base import LLMError
            if isinstance(exc, LLMError) and not exc.retryable:
                self._llm_healthy = False
                log.warning("Work queue: LLM marked unhealthy — %s", error_msg[:100])
                if self._heartbeat:
                    await self._heartbeat.record_pulse(
                        "error",
                        f"LLM unavailable ({self._active_model}): {error_msg[:200]}. "
                        f"Queued work will retry when service is restored.",
                    )
        finally:
            # Always cancel + drain the heartbeat task. Without this the
            # heartbeat keeps pinging a row in 'completed' or 'failed'
            # state, which is harmless but noisy.
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except (asyncio.CancelledError, BaseException):  # noqa: BLE001
                pass

    # ── Helpers ──

    @staticmethod
    def _describe_job(job_type: str, payload: dict) -> str:
        """Human-readable job description for notifications."""
        slug = payload.get("slug", "")
        if job_type == "ingest":
            return f"ingest files in KB '{slug}'"
        if job_type == "compile":
            return f"compile wiki for KB '{slug}'"
        if job_type == "reflect":
            return f"reflect on KB '{slug}'"
        if job_type == "research":
            return f"research '{payload.get('query', '')}' in '{payload.get('topic', '')}'"
        if job_type == "lint":
            return f"lint KB '{slug}'"
        if job_type == "wiki_job":
            return f"full wiki pipeline for KB '{slug}'"
        if job_type == "memory_daily":
            return "daily memory consolidation"
        if job_type == "memory_compact":
            return f"compact memory layer '{payload.get('layer', '')}'"
        return f"{job_type}: {json.dumps(payload)[:100]}"
