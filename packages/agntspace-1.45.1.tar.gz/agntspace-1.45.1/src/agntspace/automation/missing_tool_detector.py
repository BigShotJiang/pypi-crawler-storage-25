"""Missing-tool detector — proactive proposal of tool implementations
when one or more skills' ``tools_granted`` references a tool name that
is NOT present in the live ``ToolRegistry``.

**The gap this closes**: AgntSpace's skill substrate lets a SKILL.md
declare ``tools_granted: [my_tool]`` to teach the agent it has access
to ``my_tool`` for that skill's flow. But if ``my_tool`` was never
registered in Python (typo, deleted, not yet implemented, planned for
later), the agent silently gets the skill's instructions but no
working tool. The dispatch loop fails or the LLM hallucinates a
refusal — exactly the "agent refuses a capability it has" failure
mode the reply-guardrails subsystem detects in chat output.

This detector closes the gap PROACTIVELY at the bookkeeping layer:
walk every skill, collect every ``tools_granted`` entry, subtract
the live registry, and propose the missing tools for user approval
or developer follow-up.

**Engine vs strategy split** (Rule 12):

The thresholds, exclusion prefixes, and cadence live in
``defaults/skills/_meta/missing-tool-detect/config/detect.yaml``. This
module is pure mechanics — the YAML decides when to fire.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agntspace.automation.capability_proposals import (
    list_pending,
    stable_proposal_id,
    write_proposal,
)

log = logging.getLogger(__name__)


@dataclass
class MissingTool:
    """One tool name granted by ≥1 skill but not registered."""

    name: str
    granting_skills: list[str] = field(default_factory=list)

    @property
    def granting_count(self) -> int:
        return len(self.granting_skills)


# ── Pure helpers (testable in isolation) ──────────────────────────────


def _collect_registered_tool_names(registry) -> set[str]:
    """Return the set of every tool name in the live registry. Empty
    set if registry is missing — every grant becomes a proposal in that
    case (which surfaces the broken state instead of silently masking
    it).
    """
    if registry is None or not hasattr(registry, "list_tools"):
        return set()
    out: set[str] = set()
    try:
        for entry in registry.list_tools() or []:
            if isinstance(entry, dict):
                name = entry.get("name")
                if isinstance(name, str) and name:
                    out.add(name)
    except Exception:
        log.debug("registry.list_tools() failed", exc_info=True)
    return out


def _collect_granting_skills(skill_loader) -> dict[str, list[str]]:
    """Return ``{tool_name: [skill_name, ...]}`` for every skill with a
    non-empty ``tools_granted`` list.

    Skills with status NOT in {"active"} are skipped — pending drafts
    and archived skills shouldn't fire as orphans.
    """
    out: dict[str, list[str]] = {}
    if skill_loader is None:
        return out
    try:
        skills = skill_loader.skills or {}
    except Exception:
        log.debug("skill_loader.skills access failed", exc_info=True)
        return out
    for skill_name, skill in skills.items():
        status = getattr(skill, "status", "active")
        if status not in ("active",):
            continue
        granted = getattr(skill, "tools_granted", None) or []
        if not isinstance(granted, list):
            continue
        for tool in granted:
            if not isinstance(tool, str) or not tool.strip():
                continue
            out.setdefault(tool.strip(), []).append(skill_name)
    return out


def find_missing_tools(
    skill_loader,
    registry,
    *,
    min_granting_skills: int = 1,
    exclude_prefixes: list[str] | None = None,
) -> list[MissingTool]:
    """Pure analysis — return one ``MissingTool`` per dangling tool name.

    Sorted by ``granting_count`` desc + name asc for deterministic
    output. ``exclude_prefixes`` lets the caller skip families like
    ``mcp_*`` that come from external sources and aren't meant to
    surface as gaps.
    """
    grants = _collect_granting_skills(skill_loader)
    if not grants:
        return []
    registered = _collect_registered_tool_names(registry)

    excluded = tuple(p for p in (exclude_prefixes or []) if isinstance(p, str) and p)

    out: list[MissingTool] = []
    for tool_name, skill_names in grants.items():
        if tool_name in registered:
            continue
        if any(tool_name.startswith(p) for p in excluded):
            continue
        if len(skill_names) < min_granting_skills:
            continue
        out.append(MissingTool(
            name=tool_name,
            granting_skills=sorted(set(skill_names)),
        ))
    out.sort(key=lambda m: (-m.granting_count, m.name))
    return out


# ── Service ─────────────────────────────────────────────────────────


class MissingToolDetector:
    """Heartbeat-driven detector. Construct once at boot, call
    ``detect_and_propose()`` periodically.

    Each call:

    1. Walks every loaded skill's ``tools_granted``.
    2. Subtracts the live registry's tool names.
    3. Proposes the diff to the user-approval queue.
    4. Skips writing if a pending proposal already exists with the
       same stable id AND ``skip_if_pending=True`` (default).

    **Stateless** — no in-process state. Re-running with no changes
    is a no-op.
    """

    def __init__(
        self,
        vault_dir: Path,
        skill_loader,
        registry,
        *,
        config: dict | None = None,
    ):
        self._vault_dir = Path(vault_dir)
        self._skill_loader = skill_loader
        self._registry = registry
        self._config = dict(config or {})
        self._activity = None
        self._decisions = None

    @property
    def enabled(self) -> bool:
        return bool(self._config.get("enabled", True))

    @property
    def min_granting_skills(self) -> int:
        return int(self._config.get("min_granting_skills", 1))

    @property
    def skip_if_pending(self) -> bool:
        return bool(self._config.get("skip_if_pending", True))

    @property
    def cadence_hours(self) -> int:
        return int(self._config.get("cadence_hours", 24))

    @property
    def exclude_prefixes(self) -> list[str]:
        raw = self._config.get("exclude_tool_prefixes") or []
        if not isinstance(raw, list):
            return []
        return [p for p in raw if isinstance(p, str) and p]

    @property
    def max_example_skills(self) -> int:
        return int(self._config.get("max_example_skills", 5))

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan. Returns a structured report."""
        if not self.enabled:
            return {
                "skipped": "disabled",
                "skills_scanned": 0,
                "missing_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            missing = find_missing_tools(
                self._skill_loader,
                self._registry,
                min_granting_skills=self.min_granting_skills,
                exclude_prefixes=self.exclude_prefixes,
            )
        except Exception as exc:
            log.exception("missing-tool: scan failed: %s", exc)
            return {
                "error": f"scan: {exc}",
                "skills_scanned": 0,
                "missing_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            skills_count = len(self._skill_loader.skills or {}) if self._skill_loader else 0
        except Exception:
            skills_count = 0

        existing_ids: set[str] = set()
        if self.skip_if_pending:
            try:
                for p in list_pending(self._vault_dir, "tool"):
                    existing_ids.add(p.proposal_id)
            except Exception:
                pass

        proposals_written = 0
        skipped_dedup = 0
        proposal_records: list[dict] = []
        write_errors: list[dict] = []

        for entry in missing:
            stable_id = stable_proposal_id("tool", entry.name)
            if self.skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue
            example_skills = entry.granting_skills[: self.max_example_skills]
            sample = ", ".join(example_skills)
            title = f"Implement tool: {entry.name}"
            description = (
                f"{entry.granting_count} skill(s) declare tools_granted=[{entry.name!r}] "
                f"but no tool by that name is registered in the live ToolRegistry."
            )
            rationale = (
                f"The tool {entry.name!r} is referenced by: {sample}. "
                f"Without an implementation, every skill above silently "
                f"fails at runtime when the agent tries to invoke this "
                f"tool — exactly the failure mode the reply-guardrails "
                f"subsystem detects (capability_hallucinated). "
                f"Approve to acknowledge the user's wish for this tool — "
                f"a developer (or the healer agent) implements it in "
                f"server/src/agntspace/agent/tools.py and registers it "
                f"in main.py."
            )
            payload = {
                "granting_skills": list(entry.granting_skills),
                "granting_skill_count": entry.granting_count,
            }
            proposal, err = write_proposal(
                self._vault_dir,
                "tool",
                target=entry.name,
                title=title,
                description=description,
                rationale=rationale,
                proposed_by="missing-tool-detector",
                examples=example_skills,
                payload=payload,
            )
            if proposal is None:
                write_errors.append({"tool": entry.name, "error": err})
                continue
            proposals_written += 1
            proposal_records.append({
                "tool": entry.name,
                "granting_count": entry.granting_count,
                "proposal_id": proposal.proposal_id,
            })

        if self._activity is not None and (proposals_written or skipped_dedup):
            try:
                await self._activity.log(
                    category="agent",
                    action="missing_tool_proposals",
                    summary=(
                        f"Detected {len(missing)} missing tool(s); "
                        f"wrote {proposals_written} proposal(s), "
                        f"skipped {skipped_dedup} already-pending."
                    ),
                    details={
                        "skills_scanned": skills_count,
                        "missing_found": len(missing),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "min_granting_skills": self.min_granting_skills,
                        "proposals": proposal_records[:20],
                        "write_errors": write_errors[:5],
                    },
                    importance="medium" if proposals_written else "low",
                )
            except Exception:
                pass

        return {
            "skills_scanned": skills_count,
            "missing_found": len(missing),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "proposals": proposal_records,
            "write_errors": write_errors,
        }


# ── Approval handler ─────────────────────────────────────────────────


def approve_tool_proposal(
    vault_dir: Path, proposal_id: str,
) -> tuple[bool, str]:
    """Acknowledge a tool proposal. Tools require Python code, so
    approval here doesn't auto-create the tool. It records the user's
    intent + removes the pending file.

    Implementation is a separate developer / healer task. The activity
    event emitted at the route layer carries the proposal payload so
    the action plan can pick it up later.

    Returns ``(ok, message_or_error)``.
    """
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    proposal = get_proposal(vault_dir, "tool", proposal_id)
    if proposal is None:
        return False, "not_found"
    reject_proposal(vault_dir, "tool", proposal_id)
    return True, f"acknowledged tool proposal: {proposal.target}"
