"""Skill structural-completeness detector — proactive proposal of fixes
for active skills that are loaded but structurally inert.

**The gap this closes**: AgntSpace skills with ``status: active`` are
injected into the agent's system prompt verbatim. But a skill that has
no ``triggers:`` AND no ``tools_granted:`` (and no body procedural
mapping) is loaded LIKE a working capability while being unable to
ACTIVATE (no triggers means lexical match never fires) or EXECUTE (no
tools_granted means the agent has brand specs but no tool path).

This is the `archer-presentation` failure mode (2026-04-28): the skill
shipped active, the agent saw "Archer Futura Presentation Skill" in
its prompt, the user typed "archer futura presentation style", and
the agent produced a generic deck because:

1. ``match_skills("archer futura...")`` returned empty (no triggers).
2. The skill body had brand specs but didn't name a tool.
3. The agent had no procedural path to execute the skill's intent.

This detector closes that gap PROACTIVELY at the bookkeeping layer:
walk every active user-facing skill, classify each missing surface
(activation / execution / theme-binding), and propose the fix for
user approval.

**Engine vs strategy split** (Rule 12):

The thresholds, exempt categories, and cadence live in
``defaults/skills/_meta/missing-skill-completeness-detect/config/detect.yaml``.
This module is pure mechanics — the YAML decides when to fire.

**Why this is structurally distinct from missing-tool**:

* missing-tool detects ``tools_granted`` references that DON'T exist
  in the registry → propose tool implementation.
* missing-skill-completeness detects ``tools_granted`` is EMPTY or
  ``triggers:`` is EMPTY → propose adding those fields to the skill.

Different fix surface, different proposal kind, different approval
semantics.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agntspace.automation.capability_proposals import (
    list_pending,
    stable_proposal_id,
    write_proposal,
)

log = logging.getLogger(__name__)


# Categories whose skills are engine substrates and never user-activated
# directly. Engine substrates are read by code (e.g. _meta/ontology is
# read by KnowledgeGraph; _meta/skill-retrieval is read by Orchestrator).
# They don't need triggers or tools_granted because they don't activate
# via user phrasing — the engine wires them up at known call sites.
_ENGINE_SUBSTRATE_CATEGORIES = ("_meta",)


# Skills explicitly marked as "always inject, never trigger". A user-
# facing skill might legitimately want this (e.g. base persona rules).
# Such skills carry an explicit `always_active: true` in frontmatter
# OR a non-empty `body` that obviously isn't activation-dependent.
# We don't enforce that here — only the trigger absence is flagged.
# The user can opt out per-skill by adding the `triggers:` field with
# a single placeholder, or by moving the skill to `_meta/`.


@dataclass
class SkillCompletenessGap:
    """One active user-facing skill with one or more structural gaps."""

    skill_name: str
    title: str
    category: str
    missing_triggers: bool = False
    missing_tools_granted: bool = False
    extra_notes: list[str] = field(default_factory=list)

    @property
    def gap_count(self) -> int:
        n = 0
        if self.missing_triggers:
            n += 1
        if self.missing_tools_granted:
            n += 1
        n += len(self.extra_notes)
        return n

    @property
    def gap_summary(self) -> str:
        bits: list[str] = []
        if self.missing_triggers:
            bits.append("no triggers")
        if self.missing_tools_granted:
            bits.append("no tools_granted")
        bits.extend(self.extra_notes)
        return ", ".join(bits) if bits else "no gaps"


# ── Pure helpers (testable in isolation) ──────────────────────────────


def _is_engine_substrate(skill) -> bool:
    """A skill is an engine substrate if its category is _meta.

    Engine substrates are wired by code at known call sites; they don't
    need user-facing activation triggers or tool grants. Excluding them
    avoids surfacing irrelevant proposals like "ontology has no
    tools_granted" — by design.
    """
    cat = getattr(skill, "category", "") or ""
    return cat in _ENGINE_SUBSTRATE_CATEGORIES


def _has_triggers(skill) -> bool:
    triggers = getattr(skill, "triggers", None) or []
    if not isinstance(triggers, list):
        return False
    return any(isinstance(t, str) and t.strip() for t in triggers)


def _has_tools_granted(skill) -> bool:
    granted = getattr(skill, "tools_granted", None) or []
    if not isinstance(granted, list):
        return False
    return any(isinstance(t, str) and t.strip() for t in granted)


def find_incomplete_skills(
    skill_loader,
    *,
    require_triggers: bool = True,
    require_tools_granted: bool = True,
    excluded_categories: list[str] | None = None,
) -> list[SkillCompletenessGap]:
    """Pure analysis — return one ``SkillCompletenessGap`` per active
    user-facing skill with at least one structural gap.

    Sorted by ``gap_count`` desc + name asc for deterministic output.

    ``require_triggers`` / ``require_tools_granted`` let the caller
    relax the rule per-deployment (a vault that prefers semantic-only
    skill activation may tolerate skills without triggers).
    ``excluded_categories`` extends the engine-substrate exemption.
    """
    gaps: list[SkillCompletenessGap] = []
    if skill_loader is None:
        return gaps
    try:
        skills = skill_loader.skills or {}
    except Exception:
        log.debug("skill_loader.skills access failed", exc_info=True)
        return gaps

    extra_exempt = tuple(
        c for c in (excluded_categories or []) if isinstance(c, str) and c
    )

    for skill_name, skill in skills.items():
        status = getattr(skill, "status", "active")
        if status != "active":
            continue
        if _is_engine_substrate(skill):
            continue
        cat = getattr(skill, "category", "") or ""
        if cat in extra_exempt:
            continue

        missing_t = require_triggers and not _has_triggers(skill)
        missing_g = require_tools_granted and not _has_tools_granted(skill)

        if not (missing_t or missing_g):
            continue

        title = getattr(skill, "title", skill_name) or skill_name
        gaps.append(SkillCompletenessGap(
            skill_name=skill_name,
            title=title,
            category=cat,
            missing_triggers=missing_t,
            missing_tools_granted=missing_g,
        ))

    gaps.sort(key=lambda g: (-g.gap_count, g.skill_name))
    return gaps


# ── Service ─────────────────────────────────────────────────────────


class SkillCompletenessDetector:
    """Heartbeat-driven detector. Construct once at boot, call
    ``detect_and_propose()`` periodically.

    Each call walks the skill loader, classifies active user-facing
    skills as complete or incomplete, and emits one proposal per
    incomplete skill (deduped by stable id keyed on the skill name).

    **Stateless** — no in-process state. Re-running with no changes
    is a no-op.
    """

    def __init__(
        self,
        vault_dir: Path,
        skill_loader,
        *,
        config: dict | None = None,
    ):
        self._vault_dir = Path(vault_dir)
        self._skill_loader = skill_loader
        self._config = dict(config or {})
        self._activity = None
        self._decisions = None

    @property
    def enabled(self) -> bool:
        return bool(self._config.get("enabled", True))

    @property
    def require_triggers(self) -> bool:
        return bool(self._config.get("require_triggers", True))

    @property
    def require_tools_granted(self) -> bool:
        return bool(self._config.get("require_tools_granted", True))

    @property
    def excluded_categories(self) -> list[str]:
        raw = self._config.get("excluded_categories") or []
        if not isinstance(raw, list):
            return []
        return [c for c in raw if isinstance(c, str) and c]

    @property
    def skip_if_pending(self) -> bool:
        return bool(self._config.get("skip_if_pending", True))

    @property
    def cadence_hours(self) -> int:
        return int(self._config.get("cadence_hours", 24))

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan. Returns a structured report."""
        if not self.enabled:
            return {
                "skipped": "disabled",
                "skills_scanned": 0,
                "incomplete_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            gaps = find_incomplete_skills(
                self._skill_loader,
                require_triggers=self.require_triggers,
                require_tools_granted=self.require_tools_granted,
                excluded_categories=self.excluded_categories,
            )
        except Exception as exc:
            log.exception("skill-completeness: scan failed: %s", exc)
            return {
                "error": f"scan: {exc}",
                "skills_scanned": 0,
                "incomplete_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            skills_count = len(self._skill_loader.skills or {}) if self._skill_loader else 0
        except Exception:
            skills_count = 0

        existing_ids: set[str] = set()
        if self.skip_if_pending:
            try:
                for p in list_pending(self._vault_dir, "skill-completeness"):
                    existing_ids.add(p.proposal_id)
            except Exception:
                pass

        proposals_written = 0
        skipped_dedup = 0
        proposal_records: list[dict] = []
        write_errors: list[dict] = []

        for gap in gaps:
            stable_id = stable_proposal_id("skill-completeness", gap.skill_name)
            if self.skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue

            title = f"Complete skill: {gap.skill_name}"
            description = (
                f"Skill {gap.skill_name!r} is `status: active` but lacks "
                f"the structural fields needed for the agent to actually "
                f"execute it ({gap.gap_summary})."
            )

            fix_steps: list[str] = []
            if gap.missing_triggers:
                fix_steps.append(
                    "Add a `triggers:` list to the SKILL.md frontmatter "
                    "with phrases the user is likely to type "
                    "(e.g. `triggers: [archer presentation, archer futura]`)."
                )
            if gap.missing_tools_granted:
                fix_steps.append(
                    "Add a `tools_granted:` list naming the registry tools "
                    "the skill expects to call "
                    "(e.g. `tools_granted: [create_presentation]`)."
                )
            steps_text = "\n".join(f"- {s}" for s in fix_steps)
            rationale = (
                f"This skill is loaded into the agent's system prompt but "
                f"is structurally inert: "
                f"{gap.gap_summary}. Without these fields the agent reads "
                f"the skill body as documentation but cannot activate it on "
                f"user input or execute its intent. Per the "
                f"`feedback_main_agent_orchestrator.md` rule, every active "
                f"skill must be activatable AND executable, OR the agent "
                f"must surface this gap loudly. This proposal surfaces it.\n\n"
                f"To fix:\n{steps_text}"
            )

            # Resolve the SKILL.md path so the UI can deep-link the
            # user directly to the file they need to edit.
            #
            # ``Skill.path`` is stored RELATIVE to the skills_dir (see
            # `loader.py` write site). The vault layout puts skills at
            # ``<vault_root>/agntspace/system/skills/<skill.path>`` so
            # we prepend the structural prefix to land on a path the
            # /files route can resolve.
            #
            # Defensive against either form: if some installation
            # stores absolute paths instead, fall through to
            # ``relative_to(self._vault_dir)``.
            skill_path_rel = ""
            try:
                skill_obj = self._skill_loader.get_skill(gap.skill_name) if self._skill_loader else None
                raw = (getattr(skill_obj, "path", "") or "") if skill_obj is not None else ""
                if raw:
                    p = Path(raw)
                    if p.is_absolute():
                        # Some loaders may store absolute paths.
                        try:
                            skill_path_rel = str(
                                p.relative_to(self._vault_dir),
                            ).replace("\\", "/")
                        except ValueError:
                            skill_path_rel = str(p).replace("\\", "/")
                    else:
                        # Standard SkillLoader shape: relative to the
                        # skills_dir. Vault-relative = prefix +
                        # `<skill.path>`.
                        skill_path_rel = (
                            "agntspace/system/skills/"
                            + raw.replace("\\", "/")
                        )
            except Exception:
                pass

            payload = {
                "skill_name": gap.skill_name,
                "skill_title": gap.title,
                "category": gap.category,
                "missing_triggers": gap.missing_triggers,
                "missing_tools_granted": gap.missing_tools_granted,
                "gap_count": gap.gap_count,
                "gap_summary": gap.gap_summary,
                # Deep-link target for the UI. Empty when the loader
                # hasn't stamped a path (test fixtures, etc.).
                "skill_path": skill_path_rel,
            }

            proposal, err = write_proposal(
                self._vault_dir,
                "skill-completeness",
                target=gap.skill_name,
                title=title,
                description=description,
                rationale=rationale,
                proposed_by="skill-completeness-detector",
                examples=[gap.skill_name],
                payload=payload,
            )
            if proposal is None:
                write_errors.append({"skill": gap.skill_name, "error": err})
                continue
            proposals_written += 1
            proposal_records.append({
                "skill": gap.skill_name,
                "gap_count": gap.gap_count,
                "gap_summary": gap.gap_summary,
                "proposal_id": proposal.proposal_id,
            })

        if self._activity is not None and (proposals_written or skipped_dedup):
            try:
                await self._activity.log(
                    category="agent",
                    action="skill_completeness_proposals",
                    summary=(
                        f"Detected {len(gaps)} incomplete skill(s); "
                        f"wrote {proposals_written} proposal(s), "
                        f"skipped {skipped_dedup} already-pending."
                    ),
                    details={
                        "skills_scanned": skills_count,
                        "incomplete_found": len(gaps),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "proposals": proposal_records[:20],
                        "write_errors": write_errors[:5],
                    },
                    importance="medium" if proposals_written else "low",
                )
            except Exception:
                pass

        return {
            "skills_scanned": skills_count,
            "incomplete_found": len(gaps),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "proposals": proposal_records,
            "write_errors": write_errors,
        }


# ── Approval handler ─────────────────────────────────────────────────


def approve_skill_completeness_proposal(
    vault_dir: Path, proposal_id: str,
) -> tuple[bool, str, dict[str, Any]]:
    """Mark a skill-completeness proposal as "I'm taking it from here".

    **What this does NOT do**: edit the SKILL.md. Adding `triggers:`
    or `tools_granted:` requires authored content (which user phrases
    activate this skill? which tools does it actually call?) — the
    detector knows the GAP but not the right VALUES. Auto-filling
    placeholders would just create a different broken state.

    **What this does**: delete the pending proposal so the queue is
    clean while the user opens SKILL.md to fix it manually. If the
    user opens but doesn't actually edit, the next 24h scan re-detects
    the gap and re-proposes — same dismiss semantics already documented
    on the unified inbox.

    The route layer takes the returned ``skill_path`` and redirects
    the user to ``/files?path=...`` so the action is concrete: one
    click and they're staring at the file they need to edit.

    Returns ``(ok, message, details)`` where ``details`` carries the
    skill name + the vault-relative SKILL.md path for the deep-link.
    """
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    proposal = get_proposal(vault_dir, "skill-completeness", proposal_id)
    if proposal is None:
        return False, "not_found", {}
    payload = proposal.payload or {}
    skill_path = (payload.get("skill_path") or "").strip()
    skill_name = (proposal.target or "").strip()
    reject_proposal(vault_dir, "skill-completeness", proposal_id)
    return True, "opened_for_edit", {
        "skill": skill_name,
        "skill_path": skill_path,
        "missing_triggers": bool(payload.get("missing_triggers")),
        "missing_tools_granted": bool(payload.get("missing_tools_granted")),
    }
