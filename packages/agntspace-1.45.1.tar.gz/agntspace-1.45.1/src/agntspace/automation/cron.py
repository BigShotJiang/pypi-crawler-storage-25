"""Persistent cron scheduler — disk-backed jobs that survive restarts.

Jobs are stored in SQLite. The scheduler checks every minute for due jobs,
executes them, and records the result. Supports cron expressions (via croniter)
and simple interval-based schedules.

Jobs can deliver output to:
- Agent observations (default)
- A specific channel (Telegram, Discord, etc.)
- A webhook URL
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import aiosqlite

if TYPE_CHECKING:
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.journal.service import JournalService

log = logging.getLogger(__name__)


# Per-handler hard timeout. A handler that hasn't returned within this
# duration is force-cancelled. The cron tick loop is SEQUENTIAL — one
# stuck handler blocks every other due job — so an unbounded handler
# wait is a structural availability bug, not just a stylistic concern.
#
# Default 1 hour is generous for any legitimate cron handler. The
# heaviest known handler (news-watcher) takes 8-15 min on success;
# 60 min covers worst-case scrape + LLM retry + slow network. Anything
# longer is genuinely stuck and the queue health matters more than
# the hung run completing.
#
# arch:deterministic — engine substrate, tunable via CronScheduler
# constructor or skill YAML override per Rule 12.
_DEFAULT_HANDLER_TIMEOUT_SECONDS: int = 3600  # 1 hour

# Stale-run reclaim threshold. cron_history rows in 'running' state
# older than this are presumed dead (server crashed mid-handler, or
# the handler genuinely overran far past the timeout cap). Set 2× the
# handler timeout — anything in this window is unambiguously orphaned.
#
# arch:deterministic — engine substrate.
_DEFAULT_RECLAIM_THRESHOLD_SECONDS: int = 7200  # arch:deterministic — 2h staleness floor; same-shape primitive as work_queue zombie reclaim


class CronScheduler:
    """Persistent cron scheduler backed by SQLite."""

    def __init__(
        self,
        db: aiosqlite.Connection,
        journal: JournalService,
        heartbeat: Heartbeat | None = None,
        *,
        handler_timeout_seconds: int | None = None,
        reclaim_threshold_seconds: int | None = None,
    ) -> None:
        self._db = db
        self._journal = journal
        self._heartbeat = heartbeat
        self._handlers: dict[str, object] = {}
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        # Per-handler force-cancel cap (see module docstring on
        # _DEFAULT_HANDLER_TIMEOUT_SECONDS for the rationale).
        self._handler_timeout_seconds = (
            handler_timeout_seconds
            if handler_timeout_seconds is not None
            else _DEFAULT_HANDLER_TIMEOUT_SECONDS
        )
        # Stale-row reclaim cutoff (see _DEFAULT_RECLAIM_THRESHOLD_SECONDS).
        self._reclaim_threshold_seconds = (
            reclaim_threshold_seconds
            if reclaim_threshold_seconds is not None
            else _DEFAULT_RECLAIM_THRESHOLD_SECONDS
        )

    async def init_schema(self) -> None:
        """Create cron tables if they don't exist."""
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS cron_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                schedule TEXT NOT NULL,
                action TEXT NOT NULL,
                action_args TEXT NOT NULL DEFAULT '{}',
                enabled INTEGER NOT NULL DEFAULT 1,
                last_run TEXT,
                next_run TEXT,
                last_result TEXT,
                created_at TEXT NOT NULL,
                deliver_to TEXT DEFAULT 'observations'
            );

            CREATE TABLE IF NOT EXISTS cron_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_name TEXT NOT NULL,
                started_at TEXT NOT NULL,
                finished_at TEXT,
                status TEXT NOT NULL DEFAULT 'running',
                result TEXT
            );
        """)
        await self._db.commit()

    async def add_job(
        self,
        name: str,
        schedule: str,
        action: str,
        action_args: dict | None = None,
        deliver_to: str = "observations",
    ) -> dict:
        """Add or update a cron job.

        Args:
            name: Unique job identifier
            schedule: Cron expression (e.g., '0 7 * * *') or interval ('every 15m', 'every 2h')
            action: Action type ('briefing', 'eod', 'memory', 'reflection', 'custom')
            action_args: Optional arguments for the action
            deliver_to: Where to deliver output ('observations', 'channel:telegram', 'webhook:url')
        """
        now = datetime.now(UTC).isoformat()
        next_run = self._compute_next_run(schedule, now)

        await self._db.execute(
            """INSERT INTO cron_jobs (name, schedule, action, action_args, enabled, next_run, created_at, deliver_to)
               VALUES (?, ?, ?, ?, 1, ?, ?, ?)
               ON CONFLICT(name) DO UPDATE SET
                 schedule=excluded.schedule, action=excluded.action,
                 action_args=excluded.action_args, next_run=excluded.next_run,
                 deliver_to=excluded.deliver_to, enabled=1""",
            (name, schedule, action, json.dumps(action_args or {}), next_run, now, deliver_to),
        )
        await self._db.commit()
        log.info("Cron job added/updated: %s (%s) → next: %s", name, schedule, next_run)
        return {"name": name, "schedule": schedule, "next_run": next_run}

    async def remove_job(self, name: str) -> bool:
        """Remove a cron job."""
        cursor = await self._db.execute("DELETE FROM cron_jobs WHERE name = ?", (name,))
        await self._db.commit()
        removed = cursor.rowcount > 0
        if removed:
            log.info("Cron job removed: %s", name)
        return removed

    async def enable_job(self, name: str, enabled: bool = True) -> None:
        """Enable or disable a cron job."""
        await self._db.execute(
            "UPDATE cron_jobs SET enabled = ? WHERE name = ?",
            (1 if enabled else 0, name),
        )
        await self._db.commit()

    async def list_jobs(self) -> list[dict]:
        """List all cron jobs."""
        cursor = await self._db.execute(
            "SELECT name, schedule, action, enabled, last_run, next_run, deliver_to FROM cron_jobs ORDER BY name"
        )
        rows = await cursor.fetchall()
        return [
            {
                "name": row[0],
                "schedule": row[1],
                "action": row[2],
                "enabled": bool(row[3]),
                "last_run": row[4],
                "next_run": row[5],
                "deliver_to": row[6],
            }
            for row in rows
        ]

    async def get_history(self, job_name: str | None = None, limit: int = 20) -> list[dict]:
        """Get execution history."""
        if job_name:
            cursor = await self._db.execute(
                "SELECT job_name, started_at, finished_at, status, result FROM cron_history "
                "WHERE job_name = ? ORDER BY started_at DESC LIMIT ?",
                (job_name, limit),
            )
        else:
            cursor = await self._db.execute(
                "SELECT job_name, started_at, finished_at, status, result FROM cron_history "
                "ORDER BY started_at DESC LIMIT ?",
                (limit,),
            )
        rows = await cursor.fetchall()
        return [
            {"job_name": r[0], "started_at": r[1], "finished_at": r[2], "status": r[3], "result": r[4]}
            for r in rows
        ]

    def register_handler(self, action: str, handler: object) -> None:
        """Register an action handler (callable or coroutine)."""
        self._handlers[action] = handler

    def start(self) -> None:
        """Start the cron check loop (runs every 60 seconds)."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        log.debug("Cron scheduler started")

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None

    async def check_and_run(self) -> list[str]:
        """Check for due jobs and execute them. Returns list of jobs run.

        Each job runs inside a ``cron-<name>-*`` correlation scope
        (Rule #17 Tier B) so its handler's activity events, decisions,
        and vault writes share one causal chain visible in /decisions.
        """
        from agntspace.activity.decisions import (
            correlation_scope,
            new_correlation_id,
        )

        now = datetime.now(UTC).isoformat()
        cursor = await self._db.execute(
            "SELECT name, action, action_args, schedule, deliver_to FROM cron_jobs "
            "WHERE enabled = 1 AND next_run <= ?",
            (now,),
        )
        due_jobs = await cursor.fetchall()
        executed = []

        for name, action, args_json, schedule, deliver_to in due_jobs:
            with correlation_scope(new_correlation_id(f"cron-{name}")):
                args = json.loads(args_json)
                log.info("Cron executing: %s (action: %s)", name, action)

                # Record start
                started = datetime.now(UTC).isoformat()
                await self._db.execute(
                    "INSERT INTO cron_history (job_name, started_at, status) VALUES (?, ?, 'running')",
                    (name, started),
                )
                await self._db.commit()

                # Execute. Per-handler hard timeout via asyncio.wait_for
                # is load-bearing: the cron tick loop is SEQUENTIAL, so a
                # single stuck handler (e.g. news-watcher with a hung
                # scrape) blocks every other due job. Without the cap,
                # one hung run takes the whole scheduler offline forever.
                # Diagnosis on Wolf's vault 2026-05-05: dam-break run
                # from 12:01 hung for 7+ hours, and dam-failure 18:00
                # tick never fired because the loop was waiting on it.
                result_text = ""
                status = "success"
                try:
                    handler = self._handlers.get(action)
                    if handler:
                        # Python 3.14+ deprecated asyncio.iscoroutinefunction;
                        # inspect.iscoroutinefunction is the canonical
                        # replacement and works on every supported Python.
                        if inspect.iscoroutinefunction(handler):
                            result = await asyncio.wait_for(
                                handler(**args),
                                timeout=self._handler_timeout_seconds,
                            )
                        else:
                            result = handler(**args)
                        result_text = str(result) if result else "ok"
                    else:
                        result_text = f"No handler registered for action: {action}"
                        status = "error"
                except TimeoutError:
                    # asyncio.wait_for raises this on the cap. The
                    # underlying handler is force-cancelled. Mark the
                    # run as 'timeout' (a distinct terminal state from
                    # 'error') so the dashboard can surface this class
                    # of failure separately from genuine handler bugs.
                    result_text = (
                        f"handler timed out after {self._handler_timeout_seconds}s "
                        f"(force-cancelled by cron scheduler)"
                    )
                    status = "timeout"
                    log.warning(
                        "Cron job timed out: %s (cap=%ds)",
                        name, self._handler_timeout_seconds,
                    )
                except Exception as e:
                    result_text = str(e)
                    status = "error"
                    log.exception("Cron job failed: %s", name)

                # Record finish
                finished = datetime.now(UTC).isoformat()
                await self._db.execute(
                    "UPDATE cron_history SET finished_at = ?, status = ?, result = ? "
                    "WHERE job_name = ? AND started_at = ?",
                    (finished, status, result_text[:500], name, started),
                )

                # Update job: last_run, next_run
                next_run = self._compute_next_run(schedule, finished)
                await self._db.execute(
                    "UPDATE cron_jobs SET last_run = ?, next_run = ?, last_result = ? WHERE name = ?",
                    (finished, next_run, status, name),
                )
                await self._db.commit()

                # Deliver output
                if status == "success" and result_text and deliver_to == "observations":
                    self._journal.append_observation(f"Cron [{name}]: {result_text[:200]}")

                # Record pulse on cardiogram
                if self._heartbeat:
                    await self._heartbeat.record_pulse(
                        "cron", f"{name}: {status}", status="deviation" if status == "error" else "normal"
                    )

                executed.append(name)

        return executed

    async def reclaim_stale_runs(self) -> dict:
        """Sweep cron_history rows in 'running' state older than the
        reclaim threshold; mark them 'timeout' AND advance the matching
        cron_jobs.last_run/next_run so the job can fire again on its
        next scheduled boundary.

        This closes the architectural gap that produced the 2026-05-05
        Wolf-vault diagnosis: news-watcher cron handlers crashed/hung
        across server restarts, leaving cron_history rows stuck
        ``status='running'`` forever. cron_jobs.last_run/next_run never
        advanced (the only place those advance is on successful
        handler return), so the dashboard reported next_run hours in
        the past while the job was effectively dead.

        Mirrors WorkQueue.reclaim_zombies (Phase 2, 2026-04-30) but
        operates on the cron schema. Same CAS guard pattern from this
        session's stress test (2026-05-05) — both UPDATE branches
        include ``AND status='running'`` so two concurrent reclaim
        callers don't double-process the same row.

        Returns ``{"reclaimed": N, "jobs_advanced": K}``. Idempotent.
        Safe to call repeatedly (in fact called on every tick from
        ``_loop`` so a hung handler self-heals within ~60s of the
        threshold elapsing).
        """
        cutoff = (
            datetime.now(UTC)
            - timedelta(seconds=self._reclaim_threshold_seconds)
        ).isoformat()

        # Phase 1 — find stale running rows
        async with self._db.execute(
            "SELECT id, job_name, started_at FROM cron_history "
            "WHERE status = 'running' AND started_at < ?",
            (cutoff,),
        ) as cur:
            stale_rows = await cur.fetchall()

        if not stale_rows:
            return {"reclaimed": 0, "jobs_advanced": 0}

        now_iso = datetime.now(UTC).isoformat()
        reclaimed = 0
        # Track unique job_names that had any reclaim, so we can advance
        # their cron_jobs.last_run/next_run pointers in phase 3.
        affected_jobs: set[str] = set()

        # Phase 2 — flip stale rows to 'timeout' via CAS UPDATE.
        # The ``AND status = 'running'`` filter is load-bearing: two
        # concurrent reclaim callers must not double-count. A row that
        # the first caller has already flipped will see rowcount=0
        # for the second caller's UPDATE.
        for row_id, job_name, _started_at in stale_rows:
            cursor = await self._db.execute(
                "UPDATE cron_history SET finished_at = ?, status = 'timeout', "
                "result = COALESCE(result, '') || '[reclaimed_stale]' "
                "WHERE id = ? AND status = 'running'",
                (now_iso, row_id),
            )
            row_changed = cursor.rowcount
            await cursor.close()
            if row_changed > 0:
                reclaimed += 1
                affected_jobs.add(job_name)

        # Phase 3 — advance cron_jobs.last_run/next_run for each
        # job that had at least one reclaimed row. Without this,
        # cron_jobs.next_run stays in the past forever (because
        # next_run advancement happens only on the success/error
        # path of check_and_run, not on a reclaim).
        jobs_advanced = 0
        for job_name in affected_jobs:
            async with self._db.execute(
                "SELECT schedule FROM cron_jobs WHERE name = ?",
                (job_name,),
            ) as cur:
                row = await cur.fetchone()
            if row is None:
                # Cron job was removed since the run started (e.g. user
                # disabled the topic). Stale history entry is now
                # orphaned — that's fine, it's already marked timeout.
                continue
            schedule = row[0]
            try:
                next_run = self._compute_next_run(schedule, now_iso)
            except Exception:
                log.debug(
                    "Cron: failed to compute next_run for %s during reclaim",
                    job_name, exc_info=True,
                )
                continue
            cursor = await self._db.execute(
                "UPDATE cron_jobs SET last_run = ?, next_run = ?, "
                "last_result = 'timeout' WHERE name = ?",
                (now_iso, next_run, job_name),
            )
            if cursor.rowcount > 0:
                jobs_advanced += 1
            await cursor.close()

        await self._db.commit()

        if reclaimed > 0:
            log.warning(
                "Cron: reclaimed %d stale run(s) across %d job(s); "
                "next scheduled tick will pick them up",
                reclaimed, jobs_advanced,
            )

        return {"reclaimed": reclaimed, "jobs_advanced": jobs_advanced}

    async def _loop(self) -> None:
        """Main cron loop — sweeps stale runs + checks due jobs every 60 seconds."""
        while self._running:
            try:
                # Reclaim stale rows BEFORE selecting due jobs. A job
                # whose previous run timed out and got reclaimed sees
                # its next_run advance during the same tick, then
                # check_and_run picks it up on the NEXT scheduled
                # boundary (correct — we don't fire-immediately-after-
                # reclaim because that would dogpile a known-flaky job).
                await self.reclaim_stale_runs()
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Cron reclaim error")

            try:
                executed = await self.check_and_run()
                if executed:
                    log.info("Cron cycle: executed %s", ", ".join(executed))
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Cron loop error")
            await asyncio.sleep(60)

    @staticmethod
    def _compute_next_run(schedule: str, after: str) -> str:
        """Compute the next run time from a schedule expression.

        Supports:
        - Cron expressions: '0 7 * * *' (requires croniter)
        - Intervals: 'every 15m', 'every 2h', 'every 1d'
        """
        from datetime import timedelta

        after_dt = datetime.fromisoformat(after.replace("Z", "+00:00"))
        if after_dt.tzinfo is None:
            after_dt = after_dt.replace(tzinfo=UTC)

        # Interval format: 'every Nm', 'every Nh', 'every Nd'
        if schedule.startswith("every "):
            part = schedule[6:].strip()
            unit = part[-1]
            amount = int(part[:-1])
            if unit == "m":
                delta = timedelta(minutes=amount)
            elif unit == "h":
                delta = timedelta(hours=amount)
            elif unit == "d":
                delta = timedelta(days=amount)
            else:
                delta = timedelta(minutes=amount)
            return (after_dt + delta).isoformat()

        # Cron expression — use croniter if available
        try:
            from croniter import croniter

            cron = croniter(schedule, after_dt)
            return cron.get_next(datetime).isoformat()
        except ImportError:
            # Fallback: basic cron parsing without croniter.
            # Handles: fixed values, "*", and "*/N" step syntax.
            parts = schedule.split()
            if len(parts) >= 2:
                minute_str = parts[0]
                hour_str = parts[1]

                def _parse_field(field: str, current: int, max_val: int) -> tuple[int, int | None]:
                    """Return (value, step) for a cron field."""
                    if field == "*":
                        return 0, None
                    if field.startswith("*/"):
                        step = int(field[2:])
                        # Next aligned value >= current
                        aligned = ((current // step) + 1) * step
                        if aligned >= max_val:
                            aligned = 0
                        return aligned, step
                    return int(field), None

                # Handle */N in hour field (e.g. "0 */6 * * *" = every 6 hours)
                if hour_str.startswith("*/"):
                    step = int(hour_str[2:])
                    minute = int(minute_str) if minute_str != "*" else 0
                    # Find next hour that's a multiple of step
                    next_hour = ((after_dt.hour // step) + 1) * step
                    next_dt = after_dt.replace(minute=minute, second=0, microsecond=0)
                    if next_hour >= 24:
                        # Roll to next day at hour 0
                        next_dt = next_dt.replace(hour=0) + timedelta(days=1)
                    else:
                        next_dt = next_dt.replace(hour=next_hour)
                    if next_dt <= after_dt:
                        next_dt += timedelta(hours=step)
                    return next_dt.isoformat()

                minute = int(minute_str) if minute_str != "*" else 0
                hour = int(hour_str) if hour_str != "*" else 0
                next_dt = after_dt.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if next_dt <= after_dt:
                    next_dt += timedelta(days=1)
                return next_dt.isoformat()
            # Default: 1 hour from now
            return (after_dt + timedelta(hours=1)).isoformat()
