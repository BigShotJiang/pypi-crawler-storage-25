"""Finance inbox watcher — auto-ingests receipts dropped into agntspace-finance/inbox/.

Mirrors ``RawWatcher`` (the KB inbox watcher) but routes through
``ReceiptIngest`` instead of ``KnowledgeBaseService.ingest()``. Files
that are successfully drafted move themselves out of the inbox into
``finance/library/YYYY-MM/`` automatically (the ReceiptIngest engine
handles attachment), so the inbox stays empty in the happy path. Files
that fail extraction stay in the inbox until ``_MAX_RETRIES`` is
reached, after which they're quarantined to ``finance/inbox/.quarantine/``
with a ``.reason.txt`` sidecar — same shape as ``library/.quarantine/``
for KBs.

Pause flag is shared with ``RawWatcher`` (``[watcher].paused`` in
``config.toml``) — one switch covers both watchers because
"automatic ingestion" is the user's mental model, not "two separate
loops". The interval has its own knob (``[watcher].finance_interval_seconds``)
defaulting to 30s.

Activity events (Rule #13):
- ``user/receipt_ingested`` (medium) — successful draft created via watcher
- ``user/receipt_deduplicated`` (low) — file matched an existing draft
- ``user/receipt_ingest_failed`` (medium) — extraction failed (will retry)
- ``user/receipt_quarantined`` (high) — exhausted retries, parked

Correlation scope: ``finance-watcher-*`` so causally-linked events
share an ID in ``/decisions``.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.activity.logger import ActivityLogger
    from agntspace.finance.ingest import ReceiptIngest
    from agntspace.vault.paths import VaultPaths

log = logging.getLogger(__name__)


# Receipt extensions — mirrors ``finance.ingest._IMAGE_EXTS | _PDF_EXTS``.
# Single source of truth lives there; this is the watcher-side gate that
# avoids handing unsupported files to the engine. ``arch:deterministic``
# because it's the capability surface of the receipt ingest pipeline.
_SUPPORTED_EXTS: frozenset[str] = frozenset({  # arch:deterministic — receipt ingest capability surface; mirrors finance.ingest._IMAGE_EXTS | _PDF_EXTS
    ".jpg", ".jpeg", ".png", ".heic", ".webp", ".pdf",
})

# Visible name (matches the rationale in raw_watcher.QUARANTINE_DIRNAME):
# Quarantined receipts are USER content, not bookkeeping. A visible name
# means the user sees them in their file explorer and can restore manually.
_QUARANTINE_DIRNAME: str = "quarantine"


class FinanceInboxWatcher:
    """Watches ``agntspace-finance/inbox/`` for new receipts to ingest."""

    # How many failed attempts before parking a file. Same threshold as
    # ``RawWatcher._MAX_RETRIES`` — receipts and KB files share the same
    # "transient LLM failure vs. unrecoverable" mental model.
    _MAX_RETRIES = 5

    # Settle-time + size caps (mirror RawWatcher).
    _SETTLE_SECONDS = 5
    # Receipts and invoices are typically <2 MB; allow up to 50 MB to match
    # the receipt-pdf file-type spec's ``max_bytes`` (covers scanned multi-page
    # invoices). Anything bigger is almost certainly NOT a receipt and would
    # blow up the vision-LLM token budget.
    _MAX_FILE_BYTES = 50 * 1024 * 1024

    def __init__(
        self,
        vault_paths: VaultPaths,
        receipt_ingest: ReceiptIngest,
        *,
        check_interval: int = 30,
        settings_service: object | None = None,
        activity_logger: ActivityLogger | None = None,
    ) -> None:
        self._paths = vault_paths
        self._ingest = receipt_ingest
        self._interval = max(5, int(check_interval))  # floor 5s — never busy-loop
        self._settings_service = settings_service
        self._activity = activity_logger
        # Background task + run flag.
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        # File state tracking — only needed for FAILURE accounting since
        # successful files leave the inbox automatically (ReceiptIngest
        # moves them into ``finance/library/YYYY-MM/``). Without state:
        # - we'd retry the same broken file every cycle → token waste
        # - we'd never escalate to quarantine
        self._fail_counts: dict[str, int] = {}
        self._known_mtimes: dict[str, float] = {}
        # Concurrency guard — one cycle at a time (manual API call vs. loop).
        self._ingesting = False
        # Event-driven wake-up — lets fs_events / manual triggers run a cycle
        # immediately without waiting for the next interval. Mirrors
        # RawWatcher._event_drain.
        self._event_drain: asyncio.Event = asyncio.Event()
        # Observability fields (mirrors RawWatcher.get_status).
        self._last_cycle_at: float = 0.0
        self._last_cycle_ingested: int = 0
        self._last_cycle_failed: int = 0
        self._last_cycle_quarantined: int = 0
        self._last_error: str = ""
        self._cycle_count: int = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._fail_counts, self._known_mtimes = self._load_state()
        self._task = asyncio.create_task(self._run())
        log.debug(
            "Finance inbox watcher started (interval: %ds, %d failed-files tracked)",
            self._interval, len(self._fail_counts),
        )

    def stop(self) -> None:
        self._running = False
        if self._task is not None:
            self._task.cancel()
            self._task = None

    def trigger(self) -> None:
        """Wake the loop immediately. Safe to call from any thread."""
        try:
            self._event_drain.set()
        except Exception:
            log.debug("trigger: could not set drain event", exc_info=True)

    async def _run(self) -> None:
        """Initial settle + startup catchup + steady loop."""
        await asyncio.sleep(5)  # let other services initialize
        try:
            ingested = await self.check_and_ingest()
            if ingested:
                log.info(
                    "Finance inbox watcher: startup ingest processed %d receipt(s)",
                    len(ingested),
                )
        except Exception:
            log.exception("Finance inbox watcher: startup ingest failed")
        await self._loop()

    async def _loop(self) -> None:
        """Steady-state poll loop with event-drain waker."""
        while self._running:
            try:
                # Wake on either timer OR external trigger.
                try:
                    await asyncio.wait_for(
                        self._event_drain.wait(), timeout=self._interval,
                    )
                except TimeoutError:
                    pass
                else:
                    self._event_drain.clear()
                if not self._running:
                    return
                await self.check_and_ingest()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Finance inbox watcher: cycle failed")
                # Don't crash the loop — keep trying next interval.
                await asyncio.sleep(self._interval)

    # ------------------------------------------------------------------
    # Pause + state persistence
    # ------------------------------------------------------------------
    def is_paused(self) -> bool:
        """True when the user has paused automatic ingestion via Settings.

        Reads ``[watcher].paused`` — same flag as RawWatcher. One switch
        covers both watchers. Defaults False (running) when the settings
        service is missing or the key is absent.
        """
        svc = self._settings_service
        if svc is None:
            return False
        try:
            return bool(svc.get_value("watcher", "paused", False))
        except Exception:
            return False

    @property
    def _state_path(self) -> Path:
        # Vault-internal state, mirrors RawWatcher's ``.inbox-watcher-state.json``.
        # Lives under ``agntspace/system/`` so it never appears in the user's
        # Obsidian sidebar.
        try:
            return self._paths.resolve("system") / ".finance-inbox-watcher-state.json"
        except Exception:
            # Defensive fallback when paths resolver is broken — shouldn't happen
            # in production but keeps tests resilient.
            return Path(".finance-inbox-watcher-state.json")

    def _load_state(self) -> tuple[dict[str, int], dict[str, float]]:
        """Load fail counts + known mtimes. Drop entries for missing files."""
        try:
            p = self._state_path
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8"))
                fails_raw = data.get("fail_counts", {})
                mtimes_raw = data.get("known_mtimes", {})
                fails = {
                    k: int(v) for k, v in fails_raw.items()
                    if isinstance(v, (int, float)) and Path(k).exists()
                }
                mtimes = {
                    k: float(v) for k, v in mtimes_raw.items()
                    if isinstance(v, (int, float)) and k in fails
                }
                return fails, mtimes
        except Exception:
            log.debug("Could not load finance watcher state, starting fresh", exc_info=True)
        return {}, {}

    def _save_state(self) -> None:
        try:
            p = self._state_path
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(
                json.dumps({
                    "fail_counts": self._fail_counts,
                    "known_mtimes": self._known_mtimes,
                }),
                encoding="utf-8",
            )
        except Exception:
            log.debug("Could not save finance watcher state", exc_info=True)

    # ------------------------------------------------------------------
    # Observability
    # ------------------------------------------------------------------
    def get_status(self) -> dict:
        """Return current state for ``/api/finance/watcher/status`` (or merged
        into the unified pipeline status — caller decides).
        """
        now = time.time()
        state_path = self._state_path
        state_exists = state_path.is_file()
        state_mtime = state_path.stat().st_mtime if state_exists else 0
        # Count quarantined receipts.
        quarantine_count = 0
        try:
            qdir = self._paths.resolve(f"finance/inbox/{_QUARANTINE_DIRNAME}")
            if qdir.is_dir():
                quarantine_count = sum(
                    1 for entry in qdir.iterdir()
                    if entry.is_file() and not entry.name.endswith(".reason.txt")
                )
        except Exception:
            pass
        return {
            "running": self._running,
            "paused": self.is_paused(),
            "interval_seconds": self._interval,
            "fail_counts": sum(self._fail_counts.values()),
            "fail_tracked": len(self._fail_counts),
            "quarantine_count": quarantine_count,
            "cycle_count": self._cycle_count,
            "last_cycle_at": self._last_cycle_at,
            "last_cycle_seconds_ago": (now - self._last_cycle_at) if self._last_cycle_at else None,
            "last_cycle_ingested": self._last_cycle_ingested,
            "last_cycle_failed": self._last_cycle_failed,
            "last_cycle_quarantined": self._last_cycle_quarantined,
            "last_error": self._last_error,
            "state_file": str(state_path),
            "state_file_exists": state_exists,
            "state_file_mtime": state_mtime,
        }

    # ------------------------------------------------------------------
    # Scan + ingest
    # ------------------------------------------------------------------
    def _scan_inbox(self) -> list[Path]:
        """Return finance/inbox/ receipt files ready for ingest.

        Filters applied here (everything else is the engine's decision):
        - ``.gitkeep`` skipped
        - hidden files (starting with ``.``) skipped
        - quarantine subdir contents skipped
        - extension must be in _SUPPORTED_EXTS
        - 0-byte files skipped (still being written)
        - oversized files skipped (debug-logged)
        - too-young files skipped (settle-time)
        """
        try:
            inbox = self._paths.resolve("finance/inbox")
        except Exception:
            return []
        if not inbox.is_dir():
            return []
        now = time.time()
        out: list[Path] = []
        try:
            for f in inbox.iterdir():
                if not f.is_file():
                    continue
                if f.name == ".gitkeep" or f.name.startswith("."):
                    continue
                # Skip subdirs (canonical: never reached because is_file() filters,
                # but defensive against symlinks / weird FS).
                if f.suffix.lower() not in _SUPPORTED_EXTS:
                    continue
                try:
                    st = f.stat()
                except OSError:
                    continue
                if st.st_size == 0:
                    continue
                if st.st_size > self._MAX_FILE_BYTES:
                    log.debug(
                        "Finance watcher: skipping oversized file (%d bytes): %s",
                        st.st_size, f.name,
                    )
                    continue
                if now - st.st_mtime < self._SETTLE_SECONDS:
                    continue
                out.append(f)
        except OSError:
            return []
        return out

    async def check_and_ingest(self) -> list[str]:
        """Scan the finance inbox and ingest each receipt. Returns list of
        successfully drafted filenames (excluding deduplicated).
        """
        if self.is_paused():
            log.debug("Finance watcher: paused via Settings, skipping cycle")
            return []
        if self._ingesting:
            log.debug("Finance watcher: cycle already in progress, skipping")
            return []
        self._ingesting = True
        try:
            from agntspace.activity.decisions import (
                correlation_scope,
                new_correlation_id,
            )
            with correlation_scope(new_correlation_id("finance-watcher")):
                return await self._do_check_and_ingest()
        finally:
            self._ingesting = False

    async def _do_check_and_ingest(self) -> list[str]:
        """Internal cycle body — caller holds the concurrency lock."""
        # Park unsupported / oversized files BEFORE the main scan so the
        # ingest pipeline never sees them. Mirrors RawWatcher's
        # ``_quarantine_unsupported_files`` pattern. Without this step,
        # a user dropping (say) a .docx invoice or a .heic photo bigger
        # than the cap into ``finance/inbox/`` would get NO feedback —
        # the file would just sit there forever, invisibly skipped on
        # every cycle. Now it gets moved + a Rule 13 activity event fires.
        try:
            await self._park_unsupported_files()
        except Exception:
            log.exception("Finance watcher: unsupported-file park failed")

        files = self._scan_inbox()
        ingested_filenames: list[str] = []
        failed_count = 0
        quarantined_count = 0
        try:
            for path in files:
                fpath = str(path)
                # Skip files that already burned through retries — they'll
                # be quarantined below if the file is still here.
                attempts = self._fail_counts.get(fpath, 0)
                if attempts >= self._MAX_RETRIES:
                    if await self._quarantine(path, attempts):
                        quarantined_count += 1
                        # Drop from state — the file is gone now.
                        self._fail_counts.pop(fpath, None)
                        self._known_mtimes.pop(fpath, None)
                    continue

                # Run the receipt ingest — engine catches all internal errors
                # and returns them in IngestResult.error.
                result = await self._ingest.ingest(
                    path,
                    source_logical_path=f"finance/inbox/{path.name}",
                )
                if result.error:
                    failed_count += 1
                    self._fail_counts[fpath] = attempts + 1
                    try:
                        self._known_mtimes[fpath] = path.stat().st_mtime
                    except OSError:
                        pass
                    self._emit_activity(
                        action="receipt_ingest_failed",
                        summary=(
                            f"Receipt ingest failed for {path.name} "
                            f"(attempt {attempts + 1}/{self._MAX_RETRIES}): {result.error}"
                        ),
                        details={
                            "filename": path.name,
                            "error": result.error,
                            "attempt": attempts + 1,
                            "max_attempts": self._MAX_RETRIES,
                            "via": "watcher",
                        },
                        importance="medium",
                    )
                    self._last_error = result.error
                    continue

                # Success path. ReceiptIngest moved (or removed) the file
                # from finance/inbox/ — drop our state for it.
                self._fail_counts.pop(fpath, None)
                self._known_mtimes.pop(fpath, None)
                if result.deduplicated:
                    self._emit_activity(
                        action="receipt_deduplicated",
                        summary=f"Receipt {path.name} matched existing draft",
                        details={
                            "filename": path.name,
                            "via": "watcher",
                            "draft_id": getattr(result.draft, "draft_id", "") if result.draft else "",
                        },
                        importance="low",
                    )
                else:
                    ingested_filenames.append(path.name)
                    draft = result.draft
                    self._emit_activity(
                        action="receipt_ingested",
                        summary=(
                            f"Drafted receipt: {getattr(draft, 'merchant_raw', '?')} "
                            f"{getattr(draft, 'total', '0')} {getattr(draft, 'currency', '')} "
                            f"({path.name})"
                        ),
                        details={
                            "filename": path.name,
                            "draft_id": getattr(draft, "draft_id", "") if draft else "",
                            "merchant_raw": getattr(draft, "merchant_raw", "") if draft else "",
                            "total": getattr(draft, "total", "") if draft else "",
                            "currency": getattr(draft, "currency", "") if draft else "",
                            "via": "watcher",
                        },
                        importance="medium",
                    )
        finally:
            # Update observability fields + persist state every cycle (matches
            # raw_watcher behavior — survives restarts so we don't lose
            # progress on a long backlog).
            self._cycle_count += 1
            self._last_cycle_at = time.time()
            self._last_cycle_ingested = len(ingested_filenames)
            self._last_cycle_failed = failed_count
            self._last_cycle_quarantined = quarantined_count
            self._save_state()
        return ingested_filenames

    # ------------------------------------------------------------------
    # Unsupported / oversized parking
    # ------------------------------------------------------------------
    def _unsupported_reason(self, f: Path) -> str | None:
        """Return a reason string if ``f`` should be parked, else None.

        Mirrors RawWatcher._unsupported_reason but uses the receipt
        capability surface (image/pdf only). Settle-time + 0-byte are
        NOT reasons — those just defer the file. We park files the
        pipeline structurally CAN'T accept (wrong format / oversized).
        """
        try:
            st = f.stat()
        except OSError:
            return None
        if st.st_size == 0:
            return None  # not ready, not unsupported
        import time as _t
        if _t.time() - st.st_mtime < self._SETTLE_SECONDS:
            return None  # too young — let it settle
        if st.st_size > self._MAX_FILE_BYTES:
            return f"oversized:{st.st_size}"
        if f.suffix.lower() not in _SUPPORTED_EXTS:
            ext = f.suffix.lower() or "no_extension"
            return f"unsupported_type:{ext}"
        return None

    async def _park_unsupported_files(self) -> list[str]:
        """Move unsupported / oversized files to ``inbox/quarantine/unsupported/``.

        Drops a sidecar ``.reason.txt`` next to each parked file so the
        user knows WHY it was skipped. Emits a medium-importance activity
        event per file (Rule 13 — no silent user actions: dropping a
        ``.docx`` into the receipt inbox is a real action and the agent
        must surface it).

        Skips:
        - the quarantine subdir itself + its contents
        - ``.gitkeep`` and hidden dotfiles
        - files that need more time to settle (returned unchanged for
          the next cycle)

        Never raises; per-file errors logged + counted as low-importance
        activity events so the cycle keeps moving.
        """
        try:
            inbox = self._paths.resolve("finance/inbox")
        except Exception:
            return []
        if not inbox.is_dir():
            return []
        try:
            qdir = self._paths.resolve(
                f"finance/inbox/{_QUARANTINE_DIRNAME}/unsupported",
            )
        except Exception:
            return []

        parked: list[str] = []
        try:
            entries = list(inbox.iterdir())
        except OSError:
            return []
        for f in entries:
            if not f.is_file():
                continue
            if f.name == ".gitkeep" or f.name.startswith("."):
                continue
            reason = self._unsupported_reason(f)
            if not reason:
                continue
            try:
                qdir.mkdir(parents=True, exist_ok=True)
                dest = qdir / f.name
                # Suffix on collision so a previously-parked file with the
                # same name isn't clobbered.
                if dest.exists():
                    stem, ext = dest.stem, dest.suffix
                    n = 1
                    while True:
                        alt = qdir / f"{stem}.{n}{ext}"
                        if not alt.exists():
                            dest = alt
                            break
                        n += 1
                f.rename(dest)
                # Sidecar with the reason — same pattern as fail-quarantine.
                sidecar = dest.with_suffix(dest.suffix + ".reason.txt")
                try:
                    supported_list = ", ".join(sorted(_SUPPORTED_EXTS))
                    sidecar.write_text(
                        f"Receipt drop-zone parked this file because it isn't a "
                        f"format the receipt pipeline can read.\n"
                        f"Reason: {reason}\n"
                        f"Supported types: {supported_list}\n"
                        f"Restore: move this file back to finance/inbox/ to "
                        f"retry, or process it through a different pipeline.\n",
                        encoding="utf-8",
                    )
                except OSError:
                    log.debug(
                        "Could not write unsupported-park sidecar", exc_info=True,
                    )
                parked.append(f.name)
                self._emit_activity(
                    action="receipt_unsupported_parked",
                    summary=(
                        f"Parked {f.name} from receipt inbox: {reason}"
                    ),
                    details={
                        "filename": f.name,
                        "reason": reason,
                        "destination": str(dest),
                        "via": "watcher",
                    },
                    importance="medium",
                )
            except Exception:
                log.exception(
                    "Finance watcher: failed to park unsupported file %s", f.name,
                )
        return parked

    # ------------------------------------------------------------------
    # Quarantine (failed extraction after MAX_RETRIES attempts)
    # ------------------------------------------------------------------
    async def _quarantine(self, path: Path, attempts: int) -> bool:
        """Move ``path`` to ``finance/inbox/quarantine/`` with a sidecar.

        Returns True iff the move succeeded. Failure is logged + recorded
        as an activity event but never raised.
        """
        try:
            qdir = self._paths.resolve(f"finance/inbox/{_QUARANTINE_DIRNAME}")
            qdir.mkdir(parents=True, exist_ok=True)
            dest = qdir / path.name
            # If a quarantined copy already exists, suffix to avoid clobbering.
            if dest.exists():
                stem = dest.stem
                suffix = dest.suffix
                n = 1
                while True:
                    alt = qdir / f"{stem}.{n}{suffix}"
                    if not alt.exists():
                        dest = alt
                        break
                    n += 1
            path.rename(dest)
            # Sidecar with the failure reason.
            sidecar = dest.with_suffix(dest.suffix + ".reason.txt")
            try:
                sidecar.write_text(
                    f"Receipt quarantined after {attempts} failed extraction attempts.\n"
                    f"Last error: {self._last_error or 'unknown'}\n"
                    f"Restore: move this file back to finance/inbox/ to retry.\n",
                    encoding="utf-8",
                )
            except OSError:
                log.debug("Could not write quarantine sidecar", exc_info=True)
            self._emit_activity(
                action="receipt_quarantined",
                summary=(
                    f"Receipt {path.name} quarantined after {attempts} failed attempts"
                ),
                details={
                    "filename": path.name,
                    "attempts": attempts,
                    "last_error": self._last_error,
                    "destination": str(dest),
                    "via": "watcher",
                },
                importance="high",
            )
            return True
        except Exception:
            log.exception("Finance watcher: quarantine failed for %s", path.name)
            return False

    # ------------------------------------------------------------------
    # ActivityLogger plumbing
    # ------------------------------------------------------------------
    def _emit_activity(
        self,
        *,
        action: str,
        summary: str,
        details: dict,
        importance: str,
    ) -> None:
        """Emit an activity event. No-op when logger isn't wired (tests)."""
        if self._activity is None:
            return
        try:
            self._activity.log(
                category="user",
                action=action,
                summary=summary,
                details=details,
                importance=importance,
            )
        except Exception:
            log.debug("Failed to emit activity event %s", action, exc_info=True)


__all__ = ["FinanceInboxWatcher"]
