"""Per-KB dispatch state machine — Phase 3 of the pipeline architectural fix.

Tracks dispatch outcomes per ``(slug, scope)`` and escalates failures:

  active  → 3 consecutive zero-effects → escalating (retry at reasoning tier)
  escalating → 3 consecutive zero-effects → dormant (block further retries,
                                                     surface for user)
  dormant → auto-probe every 6h (reasoning tier) → success → active

The work-queue handler queries this module BEFORE dispatching. If the state is
``dormant``, the handler returns a deferred-completed marker WITHOUT invoking
the agent. The user must explicitly approve retry via
``POST /api/pipeline/dispatch-state/{slug}/reset`` (Phase 4 wires the UI button).

Architectural commitment (CLAUDE.md Rule 21): **every state machine that gives
up MUST surface as a user-actionable signal, never a silent dormant state.**

The classifier ``classify_dispatch_outcome`` is a pure function — testable
without DB or LLM. The service layer (``DispatchStateService``) handles
persistence and emits structured activity events on every transition.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import aiosqlite

    from agntspace.activity.logger import ActivityLogger
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# Deterministic fallbacks — used when the dispatch-state-machine skill YAML is
# missing or malformed. Keep these in sync with ``defaults/skills/_meta/
# dispatch-state-machine/config/state.yaml``.
# arch:deterministic — engine substrate degraded-mode fallback per Rule 12.
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing
    "enabled": True,
    "zero_effect_threshold_active": 3,
    "zero_effect_threshold_escalating": 3,
    "escalating_tier": "reasoning",
    "dormant_probe_interval_hours": 6,
    "dormant_probe_tier": "reasoning",
}


# ── Pure-function classifier ─────────────────────────────────────────


DispatchClassification = Literal["success", "zero_effect", "error"]


def classify_dispatch_outcome(
    *,
    succeeded: bool,
    decision_count_delta: int,
    raised_exception: bool = False,
) -> DispatchClassification:
    """Classify a dispatch outcome into one of three buckets.

    Pure function — no DB, no LLM. Inputs:
      - ``succeeded``: whether the agent's invoke_skill returned without raising.
      - ``decision_count_delta``: how many decision_log rows were written
        inside the dispatch's correlation scope. >0 = work happened.
      - ``raised_exception``: True iff the dispatch raised (timeout, error).

    Returns:
      - ``"success"`` — succeeded AND decision_count_delta > 0.
      - ``"zero_effect"`` — succeeded BUT decision_count_delta == 0.
        The LLM said "done!" with no verifiable work.
      - ``"error"`` — raised an exception (timeout / generic error).
    """
    if raised_exception:
        return "error"
    if not succeeded:
        return "error"
    if decision_count_delta <= 0:
        return "zero_effect"
    return "success"


def resolve_state_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Read the dispatch state machine config from the skill substrate.

    Falls back to ``_FALLBACK_CONFIG`` when the loader is missing, raises,
    returns non-dict, or omits required keys. Never raises.
    """
    cfg = dict(_FALLBACK_CONFIG)
    if skill_loader is None:
        return cfg
    try:
        loaded = skill_loader.load_skill_config_file(
            "dispatch-state-machine", "state.yaml",
        )
    except Exception:
        log.debug("dispatch-state-machine: failed to load state.yaml", exc_info=True)
        return cfg
    if not isinstance(loaded, dict):
        return cfg
    # Apply each key with type coercion + bounds check.
    if "enabled" in loaded:
        cfg["enabled"] = bool(loaded["enabled"])
    for int_key, min_val in (
        ("zero_effect_threshold_active", 1),
        ("zero_effect_threshold_escalating", 1),
        ("dormant_probe_interval_hours", 1),
    ):
        if int_key in loaded:
            try:
                v = int(loaded[int_key])
                if v >= min_val:
                    cfg[int_key] = v
            except (TypeError, ValueError):
                pass
    for str_key in ("escalating_tier", "dormant_probe_tier"):
        if str_key in loaded and isinstance(loaded[str_key], str):
            tier = loaded[str_key].strip()
            if tier in ("fast", "capable", "reasoning"):
                cfg[str_key] = tier
    return cfg


# ── State data ───────────────────────────────────────────────────────


DispatchState = Literal["active", "escalating", "dormant"]


@dataclass
class DispatchStateRow:
    """Mutable in-memory representation of one ``(slug, scope)`` row."""

    slug: str
    scope: str
    state: DispatchState = "active"
    consecutive_zero_effects: int = 0
    consecutive_escalation_failures: int = 0
    last_state_change_iso: str = ""
    last_attempt_iso: str = ""
    last_error_preview: str = ""
    # Phase 6 (2026-04-30) — when the user dismisses a dispatch-failure
    # proposal, we set this to ``now + cooldown_days`` so the dormant
    # row STAYS dormant but stops surfacing in /proposals until the
    # cooldown elapses. Empty string = no active cooldown.
    cooldown_until_iso: str = ""

    @classmethod
    def fresh(cls, slug: str, scope: str) -> DispatchStateRow:
        now = datetime.now(UTC).isoformat()
        return cls(slug=slug, scope=scope, last_state_change_iso=now)

    def cooldown_active(self) -> bool:
        """True iff the user dismissed a proposal for this row recently."""
        if not self.cooldown_until_iso:
            return False
        try:
            until = datetime.fromisoformat(self.cooldown_until_iso)
            if until.tzinfo is None:
                until = until.replace(tzinfo=UTC)
        except (ValueError, TypeError):
            return False
        return datetime.now(UTC) < until


@dataclass
class TransitionResult:
    """Returned by ``record_outcome``. Tells the caller (work-queue handler)
    what to do next."""

    new_state: DispatchState
    transitioned: bool = False  # True if state actually changed
    payload_hint: dict[str, Any] = field(default_factory=dict)  # e.g. {"escalate_tier": "reasoning"}


# ── Service layer ────────────────────────────────────────────────────


class DispatchStateService:
    """Per-KB dispatch state machine, SQLite-backed.

    One row per ``(slug, scope)`` pair. ``scope`` lets future surfaces
    (e.g. ``compile_ingest`` or ``research_ingest``) have independent state
    without sharing thresholds with the watcher path.

    Defensive contract:
      - ``enabled=False`` → all transitions become no-ops, ``record_outcome``
        always returns ``new_state="active"``. Safe kill switch.
      - DB connection missing or broken → in-memory fallback dict so tests
        don't need a DB.
      - YAML config missing/broken → ``_FALLBACK_CONFIG``.
      - Unknown ``(slug, scope)`` → row created on first ``record_outcome``
        with state=active.
    """

    DEFAULT_SCOPE: str = "watcher_ingest"

    def __init__(
        self,
        db: aiosqlite.Connection | None,
        *,
        skill_loader: SkillLoader | None = None,
        activity_logger: ActivityLogger | None = None,
    ) -> None:
        self._db = db
        self._skill_loader = skill_loader
        self._activity = activity_logger
        self._fallback_rows: dict[tuple[str, str], DispatchStateRow] = {}
        # Phase 6 (2026-04-30) — sync-readable mirror of non-active rows.
        # The DB-backed service uses aiosqlite, whose underlying sqlite3
        # Connection lives on a worker thread (sync access raises
        # ProgrammingError). Sync callers — like the proposals aggregator's
        # ``_load_dispatch_failures`` — read from this mirror instead.
        # Maintained as a write-through cache by ``_save``: every save
        # either inserts/updates the (slug, scope) entry (when state is
        # not active) or removes it (when state went back to active).
        # Hydrated on init_schema().
        self._non_active_mirror: dict[tuple[str, str], DispatchStateRow] = {}

    @property
    def config(self) -> dict[str, Any]:
        return resolve_state_config(self._skill_loader)

    @property
    def is_enabled(self) -> bool:
        return bool(self.config.get("enabled", True))

    # ── Schema ──

    async def init_schema(self) -> None:
        """Create the ``kb_dispatch_states`` table if it doesn't exist.

        Idempotent — re-running is a no-op. Pre-Phase-3 vaults: empty table,
        rows created on first dispatch attempt for each (slug, scope) pair.
        """
        if self._db is None:
            return
        try:
            await self._db.executescript("""
                CREATE TABLE IF NOT EXISTS kb_dispatch_states (
                    slug TEXT NOT NULL,
                    scope TEXT NOT NULL,
                    state TEXT NOT NULL DEFAULT 'active',
                    consecutive_zero_effects INTEGER NOT NULL DEFAULT 0,
                    consecutive_escalation_failures INTEGER NOT NULL DEFAULT 0,
                    last_state_change_iso TEXT NOT NULL DEFAULT '',
                    last_attempt_iso TEXT NOT NULL DEFAULT '',
                    last_error_preview TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (slug, scope)
                );

                CREATE INDEX IF NOT EXISTS idx_kbdsm_state
                    ON kb_dispatch_states(state);
            """)
            # Phase 6 (2026-04-30) — cooldown_until_iso column. Set by
            # ``set_cooldown()`` when the user dismisses a dispatch-failure
            # proposal in the unified inbox. The dormant row stays dormant
            # but stops surfacing as a proposal until the cooldown elapses.
            # Idempotent ALTER — re-running is a no-op.
            try:
                await self._db.execute(
                    "ALTER TABLE kb_dispatch_states ADD COLUMN cooldown_until_iso TEXT NOT NULL DEFAULT ''",
                )
            except Exception:
                # Column already exists — idempotent re-init is fine.
                pass
            await self._db.commit()

            # Phase 6 (2026-04-30) — hydrate the sync-readable non-active
            # mirror. Read every non-active row ONCE at init so existing
            # rows from prior sessions surface in /proposals immediately.
            # ``_save()`` keeps the mirror in sync from here forward.
            try:
                rows = await self.list_non_active_states()
                for row in rows:
                    self._non_active_mirror[(row.slug, row.scope)] = row
            except Exception:
                log.debug("dispatch_state: mirror hydration failed", exc_info=True)
        except Exception:
            log.exception("dispatch_state: init_schema failed (will use in-memory fallback)")

    # ── Read ──

    async def get_state(
        self, slug: str, scope: str | None = None,
    ) -> DispatchStateRow:
        scope = scope or self.DEFAULT_SCOPE
        # In-memory fallback path
        if self._db is None:
            return self._fallback_rows.get((slug, scope)) or DispatchStateRow.fresh(slug, scope)
        try:
            async with self._db.execute(
                """SELECT slug, scope, state, consecutive_zero_effects,
                          consecutive_escalation_failures, last_state_change_iso,
                          last_attempt_iso, last_error_preview, cooldown_until_iso
                   FROM kb_dispatch_states
                   WHERE slug = ? AND scope = ?""",
                (slug, scope),
            ) as cur:
                row = await cur.fetchone()
        except Exception:
            log.debug("dispatch_state: get_state SELECT failed", exc_info=True)
            return DispatchStateRow.fresh(slug, scope)
        if row is None:
            return DispatchStateRow.fresh(slug, scope)
        return self._row_from_sql(row)

    def snapshot_non_active(self) -> list[dict[str, Any]]:
        """Synchronous snapshot of non-active rows for sync callers (e.g.
        ``api/routes/proposals.py:_load_dispatch_failures``).

        Reads from ``_non_active_mirror`` — a write-through cache that
        ``_save()`` keeps in sync. We mirror because the DB-backed
        aiosqlite connection's underlying sqlite3 conn is bound to
        aiosqlite's worker thread; calling it sync from the main thread
        raises ProgrammingError. The mirror is hydrated on
        ``init_schema()`` so existing non-active rows from prior sessions
        surface immediately.

        Returns plain dicts (not DispatchStateRow) so the caller doesn't
        depend on the dataclass at import time. Includes a derived
        ``cooldown_active`` field so loaders can filter without
        re-implementing the cooldown check.
        """
        out: list[dict[str, Any]] = []
        for r in self._non_active_mirror.values():
            if r.state == "active":
                # Defensive — should never happen since _save removes
                # active rows from the mirror, but cheap to filter.
                continue
            out.append({
                "slug": r.slug, "scope": r.scope, "state": r.state,
                "consecutive_zero_effects": r.consecutive_zero_effects,
                "consecutive_escalation_failures": r.consecutive_escalation_failures,
                "last_state_change_iso": r.last_state_change_iso,
                "last_attempt_iso": r.last_attempt_iso,
                "last_error_preview": r.last_error_preview,
                "cooldown_until_iso": r.cooldown_until_iso,
                "cooldown_active": r.cooldown_active(),
            })
        # Sort newest-state-change first for stable proposal ordering.
        out.sort(key=lambda d: d.get("last_state_change_iso") or "", reverse=True)
        return out

    async def list_non_active_states(self) -> list[DispatchStateRow]:
        """Return all rows whose state is NOT active. Used by Phase 4's
        pipeline-health computation. Includes cooldown-active rows so the
        UI can still see them; callers wanting only proposable rows should
        filter by ``cooldown_active()``."""
        if self._db is None:
            return [r for r in self._fallback_rows.values() if r.state != "active"]
        try:
            async with self._db.execute(
                """SELECT slug, scope, state, consecutive_zero_effects,
                          consecutive_escalation_failures, last_state_change_iso,
                          last_attempt_iso, last_error_preview, cooldown_until_iso
                   FROM kb_dispatch_states
                   WHERE state != 'active'
                   ORDER BY last_state_change_iso DESC""",
            ) as cur:
                rows = await cur.fetchall()
        except Exception:
            log.debug("dispatch_state: list_non_active_states SELECT failed", exc_info=True)
            return []
        return [self._row_from_sql(r) for r in rows]

    @staticmethod
    def _row_from_sql(row: Any) -> DispatchStateRow:
        """Coerce a SQL row tuple into a DispatchStateRow. Handles legacy
        rows (8 cols, pre-cooldown) gracefully — the cooldown column is
        treated as empty when missing."""
        cooldown = ""
        if len(row) > 8 and row[8]:
            cooldown = str(row[8])
        return DispatchStateRow(
            slug=row[0], scope=row[1], state=row[2],
            consecutive_zero_effects=int(row[3]),
            consecutive_escalation_failures=int(row[4]),
            last_state_change_iso=row[5] or "",
            last_attempt_iso=row[6] or "",
            last_error_preview=row[7] or "",
            cooldown_until_iso=cooldown,
        )

    # ── Write ──

    async def _save(self, state_row: DispatchStateRow) -> None:
        """Persist via UPSERT. Falls back to in-memory dict if DB missing.

        Phase 6: also keeps the sync-readable ``_non_active_mirror`` in
        sync — non-active rows are inserted/updated; rows that go back to
        active are removed. The mirror is the read surface for sync
        callers (proposals aggregator) since the DB-backed aiosqlite
        connection is thread-bound."""
        # Write-through to the non-active mirror — runs for both DB and
        # no-DB paths.
        key = (state_row.slug, state_row.scope)
        if state_row.state == "active":
            self._non_active_mirror.pop(key, None)
        else:
            # Snapshot (don't hold a reference — caller may mutate)
            self._non_active_mirror[key] = DispatchStateRow(
                slug=state_row.slug, scope=state_row.scope, state=state_row.state,
                consecutive_zero_effects=state_row.consecutive_zero_effects,
                consecutive_escalation_failures=state_row.consecutive_escalation_failures,
                last_state_change_iso=state_row.last_state_change_iso,
                last_attempt_iso=state_row.last_attempt_iso,
                last_error_preview=state_row.last_error_preview,
                cooldown_until_iso=state_row.cooldown_until_iso,
            )

        if self._db is None:
            self._fallback_rows[(state_row.slug, state_row.scope)] = state_row
            return
        try:
            await self._db.execute(
                """INSERT INTO kb_dispatch_states
                   (slug, scope, state, consecutive_zero_effects,
                    consecutive_escalation_failures, last_state_change_iso,
                    last_attempt_iso, last_error_preview, cooldown_until_iso)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(slug, scope) DO UPDATE SET
                     state = excluded.state,
                     consecutive_zero_effects = excluded.consecutive_zero_effects,
                     consecutive_escalation_failures = excluded.consecutive_escalation_failures,
                     last_state_change_iso = excluded.last_state_change_iso,
                     last_attempt_iso = excluded.last_attempt_iso,
                     last_error_preview = excluded.last_error_preview,
                     cooldown_until_iso = excluded.cooldown_until_iso""",
                (
                    state_row.slug, state_row.scope, state_row.state,
                    state_row.consecutive_zero_effects,
                    state_row.consecutive_escalation_failures,
                    state_row.last_state_change_iso,
                    state_row.last_attempt_iso,
                    state_row.last_error_preview,
                    state_row.cooldown_until_iso,
                ),
            )
            await self._db.commit()
        except Exception:
            log.debug("dispatch_state: _save UPSERT failed", exc_info=True)

    # ── State machine ──

    async def record_outcome(
        self,
        slug: str,
        classification: DispatchClassification,
        *,
        scope: str | None = None,
        error_preview: str = "",
    ) -> TransitionResult:
        """Apply state transition for one dispatch outcome.

        Returns a TransitionResult describing the new state and any payload
        hints the caller (work-queue handler) should apply on retry (e.g.
        ``escalate_tier`` for retries in the escalating state).
        """
        scope = scope or self.DEFAULT_SCOPE

        # Master kill switch — every transition becomes a no-op.
        if not self.is_enabled:
            return TransitionResult(new_state="active")

        cfg = self.config
        row = await self.get_state(slug, scope)
        old_state = row.state
        now_iso = datetime.now(UTC).isoformat()
        row.last_attempt_iso = now_iso
        if error_preview:
            row.last_error_preview = error_preview[:200]

        # ── State transitions ──

        if classification == "success":
            # Reset everything. Successful dispatch heals all counters.
            new_state: DispatchState = "active"
            row.consecutive_zero_effects = 0
            row.consecutive_escalation_failures = 0

        elif classification == "zero_effect":
            if old_state == "active":
                row.consecutive_zero_effects += 1
                if row.consecutive_zero_effects >= cfg["zero_effect_threshold_active"]:
                    new_state = "escalating"
                    # Reset zero-effect counter; start counting in escalating.
                    row.consecutive_zero_effects = 0
                    row.consecutive_escalation_failures = 0
                else:
                    new_state = "active"
            elif old_state == "escalating":
                row.consecutive_escalation_failures += 1
                if (
                    row.consecutive_escalation_failures
                    >= cfg["zero_effect_threshold_escalating"]
                ):
                    new_state = "dormant"
                else:
                    new_state = "escalating"
            else:  # dormant
                # Already dormant — should not reach here from work-queue
                # (handler refuses dispatch). But if a probe runs and
                # zero-effects, stay dormant.
                new_state = "dormant"

        else:  # error
            # Treat error like zero-effect for escalation purposes — both
            # mean the dispatch didn't successfully accomplish work.
            if old_state == "active":
                row.consecutive_zero_effects += 1
                if row.consecutive_zero_effects >= cfg["zero_effect_threshold_active"]:
                    new_state = "escalating"
                    row.consecutive_zero_effects = 0
                    row.consecutive_escalation_failures = 0
                else:
                    new_state = "active"
            elif old_state == "escalating":
                row.consecutive_escalation_failures += 1
                if (
                    row.consecutive_escalation_failures
                    >= cfg["zero_effect_threshold_escalating"]
                ):
                    new_state = "dormant"
                else:
                    new_state = "escalating"
            else:
                new_state = "dormant"

        transitioned = new_state != old_state
        if transitioned:
            row.state = new_state
            row.last_state_change_iso = now_iso

        await self._save(row)

        # Build the payload hint for the caller. When state is escalating,
        # tell the work-queue handler to use the escalating tier on the
        # NEXT retry (which is queued by the queue's exponential backoff).
        payload_hint: dict[str, Any] = {}
        if new_state == "escalating":
            payload_hint["escalate_tier"] = cfg["escalating_tier"]

        # Emit transition event (only on actual transitions to keep noise low).
        if transitioned:
            self._emit_transition_event(
                slug=slug,
                scope=scope,
                from_state=old_state,
                to_state=new_state,
                row=row,
            )

        return TransitionResult(
            new_state=new_state,
            transitioned=transitioned,
            payload_hint=payload_hint,
        )

    # ── Manual reset ──

    async def reset(self, slug: str, scope: str | None = None) -> bool:
        """User-initiated reset: flip back to active, clear counters.

        Used by the ``POST /api/pipeline/dispatch-state/{slug}/reset`` route
        (Phase 4) so the user can manually approve retry of a dormant KB.

        Returns True if a reset happened, False if no row existed.
        """
        scope = scope or self.DEFAULT_SCOPE
        existing = await self.get_state(slug, scope)
        if existing.state == "active" and existing.consecutive_zero_effects == 0:
            return False  # nothing to reset

        now_iso = datetime.now(UTC).isoformat()
        old_state = existing.state
        existing.state = "active"
        existing.consecutive_zero_effects = 0
        existing.consecutive_escalation_failures = 0
        existing.last_state_change_iso = now_iso

        # Reset clears any active cooldown — user explicitly took action.
        existing.cooldown_until_iso = ""
        await self._save(existing)

        if old_state != "active":
            self._emit_transition_event(
                slug=slug, scope=scope,
                from_state=old_state, to_state="active",
                row=existing, manual_reset=True,
            )
        return True

    # ── Phase 6 (2026-04-30) — cooldown for dispatch-failure proposals ──

    async def set_cooldown(
        self, slug: str, *, scope: str | None = None, days: int = 7,
    ) -> bool:
        """User dismisses a dispatch-failure proposal — set a cooldown so
        the dormant row STAYS dormant but stops surfacing in /proposals
        until the cooldown elapses.

        Returns True iff the row existed and the cooldown was set.
        Refuses negative or zero days (use ``clear_cooldown`` to remove).
        """
        if days <= 0:
            raise ValueError("cooldown days must be > 0; use clear_cooldown to remove")
        scope = scope or self.DEFAULT_SCOPE
        existing = await self.get_state(slug, scope)
        # Only meaningful for non-active states. Setting a cooldown on an
        # active row is a no-op (no proposal would surface anyway).
        if existing.state == "active":
            return False
        from datetime import timedelta
        existing.cooldown_until_iso = (
            datetime.now(UTC) + timedelta(days=days)
        ).isoformat()
        await self._save(existing)
        # Emit a low-importance event — closure is routine; the original
        # dormant transition was the high-importance signal.
        if self._activity is not None:
            try:
                self._activity.log(  # type: ignore[attr-defined]
                    category="knowledge",
                    action="dispatch_state_cooldown_set",
                    summary=(
                        f"User dismissed dispatch-failure proposal for KB '{slug}' "
                        f"({existing.state}) — cooldown {days}d"
                    ),
                    details={
                        "slug": slug, "scope": scope,
                        "state": existing.state,
                        "cooldown_days": days,
                        "cooldown_until_iso": existing.cooldown_until_iso,
                    },
                    importance="low",
                )
            except Exception:
                log.debug("dispatch_state: cooldown event emit failed", exc_info=True)
        return True

    async def clear_cooldown(
        self, slug: str, *, scope: str | None = None,
    ) -> bool:
        """Clear an active cooldown. Returns True iff a cooldown existed
        and was cleared."""
        scope = scope or self.DEFAULT_SCOPE
        existing = await self.get_state(slug, scope)
        if not existing.cooldown_until_iso:
            return False
        existing.cooldown_until_iso = ""
        await self._save(existing)
        return True

    # ── Probe scheduler helper ──

    def is_probe_due(self, row: DispatchStateRow) -> bool:
        """Should the dormant KB attempt an auto-probe now?"""
        if row.state != "dormant":
            return False
        if not row.last_state_change_iso:
            return False
        try:
            last_change = datetime.fromisoformat(row.last_state_change_iso)
            if last_change.tzinfo is None:
                last_change = last_change.replace(tzinfo=UTC)
        except (ValueError, TypeError):
            return False
        interval_hours = int(self.config.get("dormant_probe_interval_hours", 6))
        return (datetime.now(UTC) - last_change) >= timedelta(hours=interval_hours)

    # ── Telemetry ──

    def _emit_transition_event(
        self,
        *,
        slug: str,
        scope: str,
        from_state: DispatchState,
        to_state: DispatchState,
        row: DispatchStateRow,
        manual_reset: bool = False,
    ) -> None:
        if self._activity is None:
            return
        # Importance: dormant transitions are HIGH (user must see).
        # All others are MEDIUM.
        if to_state == "dormant":
            importance = "high"
            action = "dispatch_state_dormant"
        elif manual_reset:
            importance = "medium"
            action = "dispatch_state_reset"
        else:
            importance = "medium"
            action = "dispatch_state_transition"
        try:
            self._activity.log(  # type: ignore[attr-defined]
                category="knowledge",
                action=action,
                summary=(
                    f"Dispatch state for KB '{slug}' (scope={scope}): "
                    f"{from_state} → {to_state}"
                ),
                details={
                    "slug": slug,
                    "scope": scope,
                    "from_state": from_state,
                    "to_state": to_state,
                    "consecutive_zero_effects": row.consecutive_zero_effects,
                    "consecutive_escalation_failures": row.consecutive_escalation_failures,
                    "last_error_preview": row.last_error_preview,
                    "manual_reset": manual_reset,
                },
                importance=importance,
            )
        except Exception:
            log.debug("dispatch_state: activity event emit failed", exc_info=True)


__all__ = [
    "DispatchClassification",
    "DispatchState",
    "DispatchStateRow",
    "DispatchStateService",
    "TransitionResult",
    "classify_dispatch_outcome",
    "resolve_state_config",
]
