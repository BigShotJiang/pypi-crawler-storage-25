"""Missing-contract-action detector — proactive proposal of trust-domain
mappings for contract actions that no domain in ``domains.yaml`` owns.

**The gap this closes**: AgntSpace's `domains.yaml` maps every
contract_action to a trust domain so trust-evolution can apply the
``max(global_proactivity, domain_trust)`` Bayesian gate per family of
actions. When a new tool ships with a fresh ``contract_action`` but
that action isn't added to any domain, the action falls through to
the catch-all ``general`` domain — invisible in the per-domain
posterior, never gated independently. CLAUDE.md Rule 16 explicitly
calls this out as a code smell.

This detector closes that gap: it walks the live ``ToolRegistry``,
collects every ``contract_action`` value, subtracts the union of
``contract_actions`` lists across ``domains.yaml``'s domains plus the
``routine_actions`` list, and proposes the missing actions for user
approval.

**Engine vs strategy split** (Rule 12):

The thresholds, cadence, and lexical-prefix domain hints live in
``defaults/skills/_meta/missing-contract-action-detect/config/detect.yaml``.
This module is pure mechanics — the YAML decides the suggestions
(thresholds, hint table, fallback domain).

**Heartbeat integration**: ``automation/heartbeat.py`` calls
``MissingContractActionDetector.detect_and_propose()`` daily (cadence
from YAML). Pure registry + YAML scan — no LLM, no expensive ops.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from agntspace.automation.capability_proposals import (
    list_pending,
    stable_proposal_id,
    write_proposal,
)

log = logging.getLogger(__name__)


@dataclass
class UnmappedAction:
    """One contract_action that no domain owns.

    ``using_tools`` is the list of registered tool names whose
    ``contract_action`` matches. ``suggested_domain`` is the
    lexical-prefix hint or the fallback default.
    """

    action: str
    using_tools: list[str] = field(default_factory=list)
    suggested_domain: str = ""

    @property
    def using_count(self) -> int:
        return len(self.using_tools)


# ── Pure helpers (testable in isolation) ──────────────────────────────


def _load_domains_yaml(skills_dir: Path, vault_dir: Path) -> dict[str, Any]:
    """Read the merged domains.yaml. Vault override (if present) is
    layered atop the shipped default — we keep this simple by reading
    BOTH files and merging dicts at the top level.

    For the missing-action detector's purpose we only need (a) the union
    of ``contract_actions`` across all domains, and (b) the
    ``routine_actions`` list. Vault override entries replace shipped
    entries by domain name on conflict.
    """

    def _read(path: Path) -> dict[str, Any]:
        if not path.is_file():
            return {}
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            return data if isinstance(data, dict) else {}
        except Exception:
            log.debug("could not parse domains.yaml at %s", path, exc_info=True)
            return {}

    shipped = _read(
        skills_dir / "core" / "trust-evolution" / "config" / "domains.yaml",
    )
    vault_override = _read(
        vault_dir
        / "agntspace"
        / "system"
        / "skills"
        / "core"
        / "trust-evolution"
        / "config"
        / "domains.yaml",
    )

    merged: dict[str, Any] = dict(shipped)
    # Domains from vault override REPLACE shipped on name match
    shipped_domains = (shipped.get("domains") or {})
    vault_domains = (vault_override.get("domains") or {})
    if isinstance(shipped_domains, dict) and isinstance(vault_domains, dict):
        merged_domains = dict(shipped_domains)
        merged_domains.update(vault_domains)
        merged["domains"] = merged_domains
    elif isinstance(vault_domains, dict):
        merged["domains"] = vault_domains

    # routine_actions: union, not replacement (additive)
    shipped_routine = list(shipped.get("routine_actions") or [])
    vault_routine = list(vault_override.get("routine_actions") or [])
    routine_union = list({*shipped_routine, *vault_routine})
    if routine_union:
        merged["routine_actions"] = routine_union

    return merged


def _collect_known_actions(domains_yaml: dict[str, Any]) -> set[str]:
    """Return the union of every contract_action declared across
    domains, plus every routine_action.

    Routine actions are deliberately bypass trust-gating, so we treat
    them as "known" for the purpose of orphan detection.
    """
    known: set[str] = set()
    domains = domains_yaml.get("domains") or {}
    if isinstance(domains, dict):
        for _name, body in domains.items():
            if not isinstance(body, dict):
                continue
            actions = body.get("contract_actions") or []
            if isinstance(actions, list):
                for action in actions:
                    if isinstance(action, str) and action.strip():
                        known.add(action.strip())
    routine = domains_yaml.get("routine_actions") or []
    if isinstance(routine, list):
        for a in routine:
            if isinstance(a, str) and a.strip():
                known.add(a.strip())
    return known


def _suggest_domain(
    action: str,
    *,
    hints: dict[str, str],
    default: str,
    available_domains: set[str],
) -> str:
    """Pick a suggested domain via longest-prefix match against the
    hints map. Falls back to the default if no hint matches.

    If the suggestion isn't actually in ``available_domains`` (typo in
    YAML), fall through to the default. If the default also isn't
    available, return empty string — the user picks from the dropdown.
    """
    sorted_hints = sorted(hints.items(), key=lambda kv: -len(kv[0]))
    for prefix, domain in sorted_hints:
        if action.startswith(prefix):
            if domain in available_domains:
                return domain
            break
    if default in available_domains:
        return default
    return ""


def collect_tool_actions(registry) -> dict[str, list[str]]:
    """Return ``{contract_action: [tool_name, ...]}`` for every tool
    that declares a non-empty ``contract_action``.

    Tools without a ``contract_action`` are skipped — they're a
    different gap (Rule 16 violation lint) and shipping a "missing
    domain" proposal for them would be misleading.
    """
    if registry is None or not hasattr(registry, "list_tools"):
        return {}
    out: dict[str, list[str]] = {}
    for entry in registry.list_tools() or []:
        if not isinstance(entry, dict):
            continue
        action = entry.get("contract_action") or ""
        name = entry.get("name") or ""
        if not action or not isinstance(action, str):
            continue
        if not name or not isinstance(name, str):
            continue
        out.setdefault(action, []).append(name)
    return out


def find_unmapped_actions(
    registry,
    domains_yaml: dict[str, Any],
    *,
    min_using_tools: int = 1,
    hints: dict[str, str] | None = None,
    default_domain: str = "Knowledge management",
) -> list[UnmappedAction]:
    """Pure analysis — return one ``UnmappedAction`` per orphan action.

    Sorted by ``using_count`` descending so the user sees the highest-
    blast-radius gaps first.
    """
    tool_actions = collect_tool_actions(registry)
    if not tool_actions:
        return []
    known = _collect_known_actions(domains_yaml)

    available_domains: set[str] = set()
    domains = domains_yaml.get("domains") or {}
    if isinstance(domains, dict):
        available_domains = {n for n in domains if isinstance(n, str)}

    hints = hints or {}
    out: list[UnmappedAction] = []
    for action, tools in tool_actions.items():
        if action in known:
            continue
        if len(tools) < min_using_tools:
            continue
        suggested = _suggest_domain(
            action,
            hints=hints,
            default=default_domain,
            available_domains=available_domains,
        )
        out.append(UnmappedAction(
            action=action,
            using_tools=sorted(tools),
            suggested_domain=suggested,
        ))
    out.sort(key=lambda u: (u.using_count, u.action), reverse=True)
    return out


# ── Service ─────────────────────────────────────────────────────────


class MissingContractActionDetector:
    """Heartbeat-driven detector. Construct once at boot, call
    ``detect_and_propose()`` periodically.

    Each call:

    1. Pulls the live tool registry (``registry.list_tools()``).
    2. Reads ``domains.yaml`` from skills_dir + vault override.
    3. Computes the diff and emits one capability-proposal per orphan.
    4. Skips writing if a pending proposal already exists with the
       same stable id AND ``skip_if_pending=True`` (default).

    **Stateless** — no in-process state. Re-running with no changes is
    a no-op.
    """

    def __init__(
        self,
        vault_dir: Path,
        skills_dir: Path,
        registry,  # ToolRegistry
        *,
        config: dict | None = None,
    ):
        self._vault_dir = Path(vault_dir)
        self._skills_dir = Path(skills_dir)
        self._registry = registry
        self._config = dict(config or {})
        self._activity = None
        self._decisions = None

    @property
    def enabled(self) -> bool:
        return bool(self._config.get("enabled", True))

    @property
    def min_using_tools(self) -> int:
        return int(self._config.get("min_using_tools", 1))

    @property
    def skip_if_pending(self) -> bool:
        return bool(self._config.get("skip_if_pending", True))

    @property
    def cadence_hours(self) -> int:
        return int(self._config.get("cadence_hours", 24))

    @property
    def hints(self) -> dict[str, str]:
        raw = self._config.get("domain_suggestion_hints") or {}
        if not isinstance(raw, dict):
            return {}
        return {k: v for k, v in raw.items() if isinstance(k, str) and isinstance(v, str)}

    @property
    def default_domain(self) -> str:
        return str(self._config.get("default_suggested_domain", "Knowledge management"))

    @property
    def max_example_tools(self) -> int:
        return int(self._config.get("max_example_tools", 5))

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan. Returns a structured report.

        Async-friendly so it can be awaited from the heartbeat without
        blocking other detectors.
        """
        if not self.enabled:
            return {
                "skipped": "disabled",
                "tools_scanned": 0,
                "unmapped_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            domains_yaml = _load_domains_yaml(self._skills_dir, self._vault_dir)
        except Exception as exc:
            log.exception("missing-contract-action: domains.yaml load failed: %s", exc)
            return {
                "error": f"load_domains: {exc}",
                "tools_scanned": 0,
                "unmapped_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            unmapped = find_unmapped_actions(
                self._registry,
                domains_yaml,
                min_using_tools=self.min_using_tools,
                hints=self.hints,
                default_domain=self.default_domain,
            )
        except Exception as exc:
            log.exception("missing-contract-action: scan failed: %s", exc)
            return {
                "error": f"scan: {exc}",
                "tools_scanned": 0,
                "unmapped_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        existing_ids: set[str] = set()
        if self.skip_if_pending:
            try:
                for p in list_pending(self._vault_dir, "contract-action"):
                    existing_ids.add(p.proposal_id)
            except Exception:
                pass

        available_domains_list = sorted(
            (domains_yaml.get("domains") or {}).keys()
        )

        proposals_written = 0
        skipped_dedup = 0
        proposal_records: list[dict] = []
        write_errors: list[dict] = []

        for entry in unmapped:
            stable_id = stable_proposal_id("contract-action", entry.action)
            if self.skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue
            example_tools = entry.using_tools[: self.max_example_tools]
            sample = ", ".join(example_tools)
            suggested_label = (
                f" → {entry.suggested_domain}"
                if entry.suggested_domain
                else " (no suggestion — pick a domain)"
            )
            title = f"Map contract action: {entry.action}{suggested_label}"
            description = (
                f"{entry.using_count} registered tool(s) declare "
                f"contract_action={entry.action!r} but the action is not "
                f"listed in any trust domain's contract_actions."
            )
            rationale = (
                f"The action {entry.action!r} is used by: {sample}. "
                f"Without a domain mapping, trust-evolution gates this "
                f"action under the catch-all 'general' domain — the "
                f"per-domain Bayesian posterior never applies. "
                + (
                    f"Lexical-prefix suggestion: {entry.suggested_domain}. "
                    if entry.suggested_domain
                    else "No prefix hint matched — pick a domain manually. "
                )
                + "Approving this proposal merges the mapping into your "
                + "vault domains.yaml override (idempotent)."
            )
            payload = {
                "using_tools": list(entry.using_tools),
                "using_count": entry.using_count,
                "suggested_domain": entry.suggested_domain,
                "available_domains": available_domains_list,
            }
            proposal, err = write_proposal(
                self._vault_dir,
                "contract-action",
                target=entry.action,
                title=title,
                description=description,
                rationale=rationale,
                proposed_by="missing-contract-action-detector",
                examples=example_tools,
                payload=payload,
            )
            if proposal is None:
                write_errors.append({
                    "action": entry.action,
                    "error": err,
                })
                continue
            proposals_written += 1
            proposal_records.append({
                "action": entry.action,
                "using_count": entry.using_count,
                "suggested_domain": entry.suggested_domain,
                "proposal_id": proposal.proposal_id,
            })

        # Activity event (Rule #13).
        if self._activity is not None and (proposals_written or skipped_dedup):
            try:
                await self._activity.log(
                    category="contract",
                    action="missing_contract_action_proposals",
                    summary=(
                        f"Detected {len(unmapped)} unmapped contract action(s); "
                        f"wrote {proposals_written} proposal(s), "
                        f"skipped {skipped_dedup} already-pending."
                    ),
                    details={
                        "tools_scanned": sum(
                            len(v) for v in collect_tool_actions(self._registry).values()
                        ),
                        "unmapped_found": len(unmapped),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "min_using_tools": self.min_using_tools,
                        "proposals": proposal_records[:20],
                        "write_errors": write_errors[:5],
                    },
                    importance="medium" if proposals_written else "low",
                )
            except Exception:
                pass

        return {
            "tools_scanned": sum(
                len(v) for v in collect_tool_actions(self._registry).values()
            ),
            "unmapped_found": len(unmapped),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "proposals": proposal_records,
            "write_errors": write_errors,
        }


# ── Approval handler ─────────────────────────────────────────────────


def approve_contract_action_proposal(
    vault_dir: Path,
    skills_dir: Path,
    proposal_id: str,
    *,
    domain: str | None = None,
) -> tuple[bool, str]:
    """Merge an approved contract-action proposal into the vault
    override of ``domains.yaml``.

    Args:
        vault_dir: vault root.
        skills_dir: shipped defaults dir (read for fallback when no
            vault override exists yet).
        proposal_id: id of the pending proposal.
        domain: optional override for the target domain. If None, uses
            the proposal's ``payload["suggested_domain"]``. If both are
            empty, returns an error — the user MUST pick a domain.

    Returns:
        ``(ok, message_or_error)``.
    """
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    proposal = get_proposal(vault_dir, "contract-action", proposal_id)
    if proposal is None:
        return False, "not_found"

    target_action = proposal.target.strip()
    if not target_action:
        return False, "proposal_missing_target_action"

    chosen = (domain or "").strip() or (
        proposal.payload.get("suggested_domain") or ""
    ).strip()
    if not chosen:
        return False, "no_domain_chosen"

    # Read current vault override (if any), fall back to shipped default.
    override_path = (
        Path(vault_dir)
        / "agntspace"
        / "system"
        / "skills"
        / "core"
        / "trust-evolution"
        / "config"
        / "domains.yaml"
    )
    shipped_path = (
        Path(skills_dir) / "core" / "trust-evolution" / "config" / "domains.yaml"
    )

    if override_path.is_file():
        try:
            data = yaml.safe_load(override_path.read_text(encoding="utf-8")) or {}
            if not isinstance(data, dict):
                data = {}
        except Exception:
            return False, "override_unparseable"
    elif shipped_path.is_file():
        try:
            data = yaml.safe_load(shipped_path.read_text(encoding="utf-8")) or {}
            if not isinstance(data, dict):
                data = {}
        except Exception:
            return False, "shipped_unparseable"
    else:
        data = {"domains": {}}

    domains = data.setdefault("domains", {})
    if not isinstance(domains, dict):
        return False, "domains_block_not_dict"
    domain_entry = domains.get(chosen)
    if domain_entry is None:
        # User picked a domain that doesn't exist yet — create the
        # block. This happens when the user maps to a brand-new domain
        # via the approval form.
        domain_entry = {"contract_actions": [], "trust_half_life_days": 90}
        domains[chosen] = domain_entry
    if not isinstance(domain_entry, dict):
        return False, "domain_entry_not_dict"

    actions = domain_entry.setdefault("contract_actions", [])
    if not isinstance(actions, list):
        actions = []
        domain_entry["contract_actions"] = actions

    if target_action not in actions:
        actions.append(target_action)

    override_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = override_path.with_suffix(".yaml.tmp")
    try:
        tmp.write_text(
            yaml.safe_dump(
                data, default_flow_style=False, allow_unicode=True, sort_keys=False,
            ),
            encoding="utf-8",
        )
        tmp.replace(override_path)
    except OSError as exc:
        return False, f"could_not_write_override: {exc}"

    reject_proposal(vault_dir, "contract-action", proposal_id)
    return True, f"merged into {override_path.relative_to(Path(vault_dir))}"
