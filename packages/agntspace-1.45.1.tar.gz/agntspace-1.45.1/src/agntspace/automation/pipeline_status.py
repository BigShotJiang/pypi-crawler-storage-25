"""Pipeline status aggregator — read-only view of file ingestion flow.

Composes data from existing subsystems (watcher state, work queue, activity log,
quarantine + unsupported folders) into one shape the UI can render as Kanban
columns: Queued / In flight / Completed today / Failed-quarantined.

This module never writes. It scans inbox folders, queries the activity buffer,
counts work-queue rows by job_type, and returns plain dicts. No new schema, no
new persistence — every datum already exists somewhere; this is a read aggregate.

Source-of-truth mapping:
  Queued  → inbox folders (global + per-KB) minus quarantine/unsupported/hidden
  Inflight→ work_queue.status='running' for ingest job_types
            + best-effort: known_files but not yet in completed events
  Done    → ActivityLogger events with category=knowledge, action in DONE_ACTIONS
  Failed  → inbox/quarantine/ files + library/unsupported/ + work_queue dead_letter

Quarantine canonical name is ``quarantine`` (visible). The legacy
``.quarantine`` is kept in exclusion sets and read-side enumeration so a
half-migrated vault works correctly until the boot-time migration runs
(see ``automation/raw_watcher.migrate_quarantine_dot_to_visible``).
"""

from __future__ import annotations

import logging
from datetime import UTC
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.activity.decisions import DecisionLogger
    from agntspace.activity.logger import ActivityEvent, ActivityLogger
    from agntspace.automation.work_queue import WorkQueue
    from agntspace.vault.paths import VaultPaths

log = logging.getLogger(__name__)


# Activity actions that mean "a file successfully made it through ingestion".
# Mirrors the action names emitted by KnowledgeBaseService._do_ingest_body.
#
# Critical: do NOT include ``ingest_completed`` here. That event fires once
# per batch (regardless of file count) — including empty batches when the
# work queue drains pre-queued retry jobs against a KB whose inbox is now
# empty. Counting batch-completes as "done" inflates the dashboard with
# events that didn't actually ingest anything. Use the per-file ``ingested``
# event only.
_DONE_ACTIONS: frozenset[str] = frozenset({
    "ingested",
})

# Activity actions that mean "this file did NOT enter the wiki" — used for the
# "Skipped today" sub-count under Completed. Skips are visible but separate
# from successes so the user can see "5 imported, 3 skipped (duplicate)" rather
# than a misleading 8-count.
_SKIP_ACTIONS: frozenset[str] = frozenset({  # arch:deterministic — internal ActivityLogger action identifiers tied 1:1 to ingest emitter sites
    "ingest_skipped_unchanged",
    "ingest_skipped_duplicate",
    "ingest_skipped_cross_kb",
    "ingest_skipped_unsupported",
})

# Activity actions that mean a file ended badly mid-flight. Crashes accumulate
# inside the failed bucket alongside on-disk quarantine + unsupported.
_CRASH_ACTIONS: frozenset[str] = frozenset({
    "ingest_file_crashed",
    "ingest_quarantined",
})

# Job types in the work queue that represent file-level ingest work. Other job
# types (compile, reflect, lint) operate at KB level and don't belong on this
# board — they're work AFTER files made it in.
_INGEST_JOB_TYPES: frozenset[str] = frozenset({
    "ingest",
    "wiki_job",
})

# Same exclusion rules as raw_watcher — keep the two in sync if the watcher's
# rules change. Hidden + skip-dirs match what _scan_dir_recursive does.
_HIDDEN_PREFIXES: tuple[str, ...] = (".", "_")
_SKIP_DIR_NAMES: frozenset[str] = frozenset({  # arch:deterministic — must match raw_watcher's hidden/skip dirs; structural filesystem layout, not user strategy
    ".quarantine",       # legacy hidden name (kept for half-migrated vaults)
    "quarantine",        # canonical visible name
    ".unsupported",      # legacy hidden name (kept for safety)
    "unsupported",
    "library",
})


def _is_visible_inbox_file(p: Path) -> bool:
    """Files we'd consider 'queued' — exclude hidden, system, and skip-dir entries."""
    if not p.is_file():
        return False
    if p.name.startswith(_HIDDEN_PREFIXES):
        return False
    if p.name == ".gitkeep":
        return False
    return True


def _scan_inbox_dir(inbox: Path, *, source_label: str, kb: str = "") -> list[dict[str, Any]]:
    """Yield queued-file records from one inbox directory (non-recursive)."""
    out: list[dict[str, Any]] = []
    if not inbox.is_dir():
        return out
    try:
        entries = list(inbox.iterdir())
    except OSError:
        return out
    for f in entries:
        if not _is_visible_inbox_file(f):
            continue
        try:
            st = f.stat()
        except OSError:
            continue
        out.append({
            "filename": f.name,
            "path": str(f),
            "size": st.st_size,
            "mtime": st.st_mtime,
            "kb": kb,
            "source": source_label,
            "ext": f.suffix.lower(),
        })
    return out


def list_queued_files(paths: VaultPaths) -> list[dict[str, Any]]:
    """Enumerate files currently waiting in inbox folders.

    Scans the global drop zone and every per-KB inbox. Excludes .quarantine/,
    .unsupported/, and hidden/system files. Returns newest-first.
    """
    out: list[dict[str, Any]] = []

    # Global inbox
    global_inbox = paths.resolve("inbox")
    out.extend(_scan_inbox_dir(global_inbox, source_label="global"))

    # Per-KB inboxes
    kb_root = paths.resolve("knowledge")
    if kb_root.is_dir():
        try:
            kb_entries = list(kb_root.iterdir())
        except OSError:
            kb_entries = []
        for kb in kb_entries:
            if not kb.is_dir():
                continue
            kb_inbox = kb / "inbox"
            out.extend(_scan_inbox_dir(kb_inbox, source_label=f"kb:{kb.name}", kb=kb.name))

    out.sort(key=lambda r: r["mtime"], reverse=True)
    return out


def list_quarantined_files(paths: VaultPaths) -> list[dict[str, Any]]:
    """Enumerate files in per-KB ``inbox/quarantine/`` directories.

    Reads BOTH the canonical visible name (``quarantine``) and the legacy
    dot-prefixed name (``.quarantine``) so a half-migrated vault still
    surfaces every parked file. The boot-time migration in
    ``automation/raw_watcher.migrate_quarantine_dot_to_visible`` renames
    legacy → canonical on the next start; until it runs, both are listed.

    Mirrors api/routes/watcher.py:list_quarantine but returns a richer shape
    suitable for the pipeline view (adds bucket label + ext).
    """
    out: list[dict[str, Any]] = []
    kb_root = paths.resolve("knowledge")
    if not kb_root.is_dir():
        return out
    try:
        kb_entries = list(kb_root.iterdir())
    except OSError:
        return out
    seen: set[tuple[str, str]] = set()  # (kb_name, filename) — dedup if both dirs hold the same name
    for kb in kb_entries:
        if not kb.is_dir():
            continue
        for sub in ("quarantine", ".quarantine"):
            q = kb / "inbox" / sub
            if not q.is_dir():
                continue
            try:
                files = list(q.iterdir())
            except OSError:
                continue
            for f in files:
                if not f.is_file():
                    continue
                key = (kb.name, f.name)
                if key in seen:
                    continue  # canonical wins over legacy on collision
                seen.add(key)
                try:
                    st = f.stat()
                except OSError:
                    continue
                out.append({
                    "filename": f.name,
                    "path": str(f),
                    "size": st.st_size,
                    "mtime": st.st_mtime,
                    "kb": kb.name,
                    "bucket": "quarantined",
                    "reason": "Timed out or crashed during ingest",
                    "ext": f.suffix.lower(),
                })

    out.sort(key=lambda r: r["mtime"], reverse=True)
    return out


def list_unsupported_files(paths: VaultPaths) -> list[dict[str, Any]]:
    """Enumerate files in per-KB library/unsupported/ directories.

    Reads the .reason.txt sidecar (if present) so the user sees WHY each file
    was parked. Does not recurse — sidecars sit next to their files.
    """
    out: list[dict[str, Any]] = []
    kb_root = paths.resolve("knowledge")
    if not kb_root.is_dir():
        return out
    try:
        kb_entries = list(kb_root.iterdir())
    except OSError:
        return out
    for kb in kb_entries:
        if not kb.is_dir():
            continue
        unsupported = kb / "library" / "unsupported"
        if not unsupported.is_dir():
            continue
        try:
            files = list(unsupported.iterdir())
        except OSError:
            continue
        for f in files:
            if not f.is_file() or f.suffix.lower() == ".txt" and f.name.endswith(".reason.txt"):
                # Sidecars are read alongside their parent file, not listed standalone.
                continue
            try:
                st = f.stat()
            except OSError:
                continue
            reason_file = f.with_name(f.name + ".reason.txt")
            reason = ""
            if reason_file.is_file():
                try:
                    reason = reason_file.read_text(encoding="utf-8", errors="replace").strip()
                except OSError:
                    reason = ""
            out.append({
                "filename": f.name,
                "path": str(f),
                "size": st.st_size,
                "mtime": st.st_mtime,
                "kb": kb.name,
                "bucket": "unsupported",
                "reason": reason or "Unsupported type or oversized",
                "ext": f.suffix.lower(),
            })

    out.sort(key=lambda r: r["mtime"], reverse=True)
    return out


def _local_midnight_iso() -> str:
    """Return today's local-midnight as an ISO 8601 string with local offset.

    Matches the format ``DecisionLogger`` writes (timestamps go through
    ``format_iso_local(datetime.now(UTC))``), so a lexicographic ``>=``
    comparison on a row's ``timestamp`` correctly selects rows from today
    (since local midnight) onwards.
    """
    from agntspace.infra.timezone import format_iso_local, now_local

    midnight = now_local().replace(hour=0, minute=0, second=0, microsecond=0)
    return format_iso_local(midnight)


def _decision_bucket(row: dict[str, Any]) -> str:
    """Map an ``ingest_file`` decision row to its UI bucket.

    Three lifecycle outcomes share the ``ingest_file`` action_type, distinguished
    by ``contract_result`` so a single SQL query covers everything:

    * ``"failed"`` → crashed (the file blew up mid-flight)
    * ``"skipped"`` → skipped (dedup / unsupported / oversized parked)
    * anything else (incl. ``"allowed"``) → done (ingested cleanly)
    """
    cr = row.get("contract_result") or ""
    if cr == "failed":
        return "crashed"
    if cr == "skipped":
        return "skipped"
    return "done"


def _decision_to_record(row: dict[str, Any]) -> dict[str, Any]:
    """Render a DecisionLogger row into the same shape ``_event_to_record`` produces.

    Lets buffer rows and persistent rows merge into one list with the same keys
    so the UI doesn't care which source surfaced any individual entry.
    """
    details = row.get("details") or {}
    bucket = _decision_bucket(row)
    target = row.get("action_target") or ""
    # action_target is shaped "kb/{slug}/{filename}" — pull the trailing
    # filename when details didn't carry one explicitly.
    fallback_name = target.rsplit("/", 1)[-1] if "/" in target else ""

    if bucket == "crashed":
        action_label = "ingest_file_crashed"
        importance = "high"
    elif bucket == "skipped":
        skip_reason = details.get("skip_reason") or "skipped"
        action_label = f"ingest_skipped_{skip_reason}"
        importance = "low"
    else:
        action_label = "ingested"
        importance = "medium"

    # "reason" surfaces in the UI's failure / skip explanations. For done rows
    # it stays empty; for skipped rows we prefer the skip_reason; for crashed
    # we prefer the actual error string.
    reason = ""
    if bucket == "crashed":
        reason = (
            details.get("error")
            or details.get("error_type")
            or row.get("error_type", "")
            or ""
        )
    elif bucket == "skipped":
        reason = (
            details.get("skip_reason")
            or details.get("reason")
            or ""
        )

    return {
        "filename": details.get("file") or details.get("filename") or fallback_name or "",
        "path": details.get("path", ""),
        "kb": details.get("slug") or details.get("kb") or "",
        "bucket": bucket,
        "action": action_label,
        "timestamp": row.get("timestamp", ""),
        "summary": (row.get("rationale") or "")[:200],
        "importance": importance,
        "correlation_id": row.get("correlation_id", ""),
        "reason": reason,
    }


async def count_persistent_ingest_buckets(
    decisions: DecisionLogger | None,
    *,
    since_iso: str,
) -> dict[str, int]:
    """True per-file counts for ``ingest_file`` decisions, since a timestamp.

    Source of truth for ``done_today_count`` / ``skipped_today_count`` /
    ``crashed_today_count``. Uses ``count_distinct_target_by_latest_result``
    so a file that crashed 20× and then succeeded counts as **1 done** — the
    same dedup ``_crossbucket_dedup`` already applies on the list side.
    Without this, the dashboard would lie: badge says 1300 crashed while
    the list shows 0, because every retry attempt added a row but the file
    eventually succeeded. Rule 20: a sliced-list length is not a total, AND
    a raw row count over a retry-storm is not a per-file truth either —
    the count must reflect current state of the same entity the list shows.

    Falls back to ``count_by_contract_result`` (raw row count) only when the
    logger doesn't expose the distinct method (older/stub deployments) so
    behavior degrades gracefully. Empty dict on missing logger / failed
    query so callers can fall back further.
    """
    if decisions is None:
        return {"done": 0, "skipped": 0, "crashed": 0}
    try:
        if hasattr(decisions, "count_distinct_target_by_latest_result"):
            per_result = await decisions.count_distinct_target_by_latest_result(
                action_type="ingest_file",
                since=since_iso,
            )
        elif hasattr(decisions, "count_by_contract_result"):
            # Fallback: older logger lacks the distinct counter. Better
            # to return inflated raw counts than to silently render 0.
            per_result = await decisions.count_by_contract_result(
                action_type="ingest_file",
                since=since_iso,
            )
        else:
            return {"done": 0, "skipped": 0, "crashed": 0}
    except Exception:
        log.exception("pipeline_status: distinct count query failed")
        return {"done": 0, "skipped": 0, "crashed": 0}

    done = 0
    skipped = 0
    crashed = 0
    for cr, n in per_result.items():
        if cr == "failed":
            crashed += int(n or 0)
        elif cr == "skipped":
            skipped += int(n or 0)
        else:
            # "allowed", "", and anything else map to done — same rule
            # _decision_bucket() applies on the row side.
            done += int(n or 0)
    return {"done": done, "skipped": skipped, "crashed": crashed}


async def list_persistent_ingest_decisions(
    decisions: DecisionLogger | None,
    *,
    since_iso: str,
    limit: int = 200,
) -> dict[str, list[dict[str, Any]]]:
    """Read file-level ingest decisions from the persistent log.

    Source of truth: ``decision_log`` table — every ``ingest_file`` row carries
    one of three ``contract_result`` values that map to UI buckets:

    * ``"allowed"`` (or missing/other non-special) → done
    * ``"failed"`` → crashed
    * ``"skipped"`` → skipped (unchanged / duplicate / cross_kb / unsupported)

    All three survive process restarts, unlike the in-memory ActivityLogger
    buffer.

    Returns ``{"done": [...], "skipped": [...], "crashed": [...]}`` newest-first
    within each bucket, capped at ``limit`` per bucket. Never raises — broken
    decision logger returns empty buckets so the page degrades cleanly.
    """
    if decisions is None or not hasattr(decisions, "query"):
        return {"done": [], "skipped": [], "crashed": []}

    try:
        rows = await decisions.query(
            action_type="ingest_file",
            since=since_iso,
            limit=max(limit * 4, 300),  # over-fetch so we have headroom after splitting 3 ways
        )
    except Exception:
        log.exception("pipeline_status: decision_log query failed")
        return {"done": [], "skipped": [], "crashed": []}

    done: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    crashed: list[dict[str, Any]] = []
    for row in rows:
        bucket = _decision_bucket(row)
        record = _decision_to_record(row)
        if bucket == "crashed":
            crashed.append(record)
        elif bucket == "skipped":
            skipped.append(record)
        else:
            done.append(record)

    # query() already returns newest-first (ORDER BY id DESC).
    return {
        "done": done[:limit],
        "skipped": skipped[:limit],
        "crashed": crashed[:limit],
    }


def _merge_event_lists(
    buffer_rows: list[dict[str, Any]],
    persistent_rows: list[dict[str, Any]],
    *,
    limit: int,
) -> list[dict[str, Any]]:
    """Union the two sources, dedup by (filename, kb), newest-first, capped.

    Buffer rows win on collision because they're the freshest source for the
    current process — but the persistent log fills in everything from before
    the last restart so the count never silently drops what already happened
    today.
    """
    seen: set[tuple[str, str]] = set()
    out: list[dict[str, Any]] = []
    for row in buffer_rows:  # buffer first → wins ties
        key = (row.get("filename", ""), row.get("kb", ""))
        if not key[0]:
            out.append(row)
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    for row in persistent_rows:
        key = (row.get("filename", ""), row.get("kb", ""))
        if not key[0]:
            out.append(row)
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    out.sort(key=lambda r: r.get("timestamp", ""), reverse=True)
    return out[:limit]


async def list_recent_events_unified(
    activity: ActivityLogger | None,
    decisions: DecisionLogger | None,
    *,
    limit: int = 50,
    since_iso: str | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """Authoritative read for the pipeline's done / skipped / crashed buckets.

    Returns ``{done, skipped, crashed}`` — the sliced lists ready for display.
    For TRUE per-bucket counts (Rule 20: never use ``len(<sliced>)`` as a
    total), call :func:`build_recent_events_with_totals` which wraps this
    function and adds a ``totals`` block sourced from a ``COUNT(*)`` query.

    Merges two sources, all three buckets:

    * **Persistent** (DecisionLogger SQLite table) — every ``ingest_file``
      decision row survives process restarts. The table is the source of
      truth for today's counts once data has been there for more than a
      few seconds.
    * **In-memory** (ActivityLogger buffer) — fills the small race window
      between an activity emission and its sibling decision-row commit.
      Buffer entries win on `(filename, kb)` collisions because they're
      the freshest source for the current process.

    When ``decisions`` is None this falls back to the buffer-only view so the
    function stays callable in tests / when the decision logger isn't wired.
    """
    buffer_events = list_recent_events(activity, limit=limit, since_iso=since_iso)

    if decisions is None:
        return _crossbucket_dedup(buffer_events)

    cutoff = since_iso or _local_midnight_iso()
    persistent = await list_persistent_ingest_decisions(
        decisions, since_iso=cutoff, limit=limit,
    )

    merged = {
        "done": _merge_event_lists(buffer_events["done"], persistent["done"], limit=limit),
        "skipped": _merge_event_lists(buffer_events["skipped"], persistent["skipped"], limit=limit),
        "crashed": _merge_event_lists(buffer_events["crashed"], persistent["crashed"], limit=limit),
    }
    # Cross-bucket dedup — when a file crashed earlier and later succeeded
    # (or vice versa), keep only the entry from the bucket with the
    # newest timestamp. Otherwise the historical "crashed" entry sits on
    # the dashboard forever after the user clicks Retry and the file
    # ingests cleanly. The "most recent outcome wins" rule matches the
    # user's mental model: a fixed file should disappear from Crashed
    # the moment a later success row exists.
    return _crossbucket_dedup(merged)


async def build_recent_events_with_totals(
    activity: ActivityLogger | None,
    decisions: DecisionLogger | None,
    *,
    limit: int = 50,
    since_iso: str | None = None,
) -> dict[str, Any]:
    """Wrap :func:`list_recent_events_unified` with TRUE per-bucket counts.

    Returns ``{done: [...], skipped: [...], crashed: [...], totals:
    {done: N, skipped: N, crashed: N}}``. Lists are capped at ``limit``;
    totals come from a separate ``COUNT(*)`` query against the persistent
    decision log so they reflect the real number of rows for today, not
    the post-truncation list length (Rule 20).

    Buffer-only top-up: when an activity event has been emitted but its
    sibling decision row hasn't committed yet, the buffer entry is included
    in the returned list. Cross-bucket dedup means buffer-vs-persistent
    duplicates collapse to one row, but the count of NEW filenames the
    buffer surfaces (that aren't in the persistent log yet) is added to
    the persistent totals so the user-visible count includes the in-flight
    delta. Bounded by the buffer's own retention.

    When ``decisions`` is None, totals fall back to the same lengths as
    the returned lists (this is the only honest answer when there's no
    persistent source — the buffer IS the truth).
    """
    events = await list_recent_events_unified(
        activity, decisions, limit=limit, since_iso=since_iso,
    )

    cutoff = since_iso or _local_midnight_iso()
    persistent_totals = await count_persistent_ingest_buckets(
        decisions, since_iso=cutoff,
    )

    # When `decisions` isn't wired the buffer IS the only source of truth.
    if decisions is None or not persistent_totals:
        # Buffer-only — list lengths are the honest count.
        return {
            "done": events["done"],
            "skipped": events["skipped"],
            "crashed": events["crashed"],
            "totals": {
                "done": len(events["done"]),
                "skipped": len(events["skipped"]),
                "crashed": len(events["crashed"]),
            },
        }

    # When the persistent distinct counter is wired, IT is the authoritative
    # truth — period. Per-file LATEST-outcome semantics (the same logic
    # ``_crossbucket_dedup`` applies on the list side, but applied against
    # the full row history rather than a fetch-window slice). The previous
    # ``max(persistent, len(list))`` formula was correct ONLY when
    # ``persistent`` was a raw row count (always ≥ post-dedup list length);
    # with the distinct counter the relationship inverts — the list can
    # still contain entries whose later ``allowed`` row falls outside the
    # 800-row fetch window, and using ``max()`` would re-inflate the count
    # exactly the way the 1300-quarantined bug did.
    #
    # Eventual-consistency note: there's a sub-second window between an
    # activity emit and its decision row commit where the count may be 1
    # behind the list. Acceptable trade-off — the alternative (per-file
    # reverse lookup against the decision log) costs an extra query per
    # buffer entry on every dashboard poll.
    totals = {
        "done": int(persistent_totals.get("done", 0)),
        "skipped": int(persistent_totals.get("skipped", 0)),
        "crashed": int(persistent_totals.get("crashed", 0)),
    }

    return {
        "done": events["done"],
        "skipped": events["skipped"],
        "crashed": events["crashed"],
        "totals": totals,
    }


def _crossbucket_dedup(
    buckets: dict[str, list[dict[str, Any]]],
) -> dict[str, list[dict[str, Any]]]:
    """For each ``(kb, filename)``, keep the entry from the bucket with
    the newest timestamp; drop all earlier entries across all buckets.

    Resolves the "I clicked Retry, the file succeeded, but the historical
    crashed card stays forever" problem by making the dashboard a view of
    *current outcome*, not *every outcome ever recorded*.

    Rows missing a (kb, filename) key are kept verbatim — without identity
    we can't safely dedup. Sort within each bucket is preserved (newest
    first) since the input lists are already sorted that way.
    """
    bucket_names = list(buckets.keys())
    if not bucket_names:
        return buckets

    # Walk every row, group by (kb, filename), record (timestamp, bucket, row)
    by_key: dict[tuple[str, str], list[tuple[str, str, dict[str, Any]]]] = {}
    keyless: list[tuple[str, dict[str, Any]]] = []  # (bucket, row) — kept verbatim
    for bucket_name, rows in buckets.items():
        for r in rows:
            kb = str(r.get("kb") or "")
            fn = str(r.get("filename") or "")
            if not fn:
                keyless.append((bucket_name, r))
                continue
            key = (kb, fn)
            ts = str(r.get("timestamp") or "")
            by_key.setdefault(key, []).append((ts, bucket_name, r))

    out: dict[str, list[dict[str, Any]]] = {b: [] for b in bucket_names}
    for _key, candidates in by_key.items():
        # Most recent wins; ties broken by bucket-name order (deterministic)
        candidates.sort(key=lambda t: (t[0], t[1]), reverse=True)
        _ts, winning_bucket, winning_row = candidates[0]
        out[winning_bucket].append(winning_row)
    for bucket_name, row in keyless:
        out[bucket_name].append(row)

    # Re-sort each bucket newest-first since dedup may have reshuffled
    for bucket_name in out:
        out[bucket_name].sort(key=lambda r: str(r.get("timestamp") or ""), reverse=True)
    return out


def _event_to_record(ev: ActivityEvent, *, bucket: str) -> dict[str, Any]:
    """Render an ActivityEvent into the row shape used by the pipeline UI."""
    details = ev.details or {}
    filename = (
        details.get("file")
        or details.get("filename")
        or details.get("target_file")
        or ""
    )
    kb = details.get("slug") or details.get("kb") or ""
    return {
        "filename": filename or ev.summary[:80],
        "path": details.get("path", ""),
        "kb": kb,
        "bucket": bucket,
        "action": ev.action,
        "timestamp": ev.timestamp,
        "summary": ev.summary,
        "importance": ev.importance,
        "correlation_id": ev.correlation_id,
        "reason": (
            details.get("reason")
            or details.get("error")
            or details.get("error_type")
            or ""
        ),
    }


def list_recent_events(
    activity: ActivityLogger | None,
    *,
    limit: int = 50,
    since_iso: str | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """Return today's ingest activity events split into done / skipped / crashed.

    Reads the in-memory activity buffer. Quiet on missing logger (returns empty
    lists) so the route never breaks because activity wiring failed.
    """
    if activity is None:
        return {"done": [], "skipped": [], "crashed": []}

    try:
        events = activity.get_recent_events(
            since_iso=since_iso,
            categories=["knowledge"],
            min_importance="low",
            limit=max(limit * 4, 200),  # over-fetch so we have headroom after splitting
        )
    except Exception:
        log.exception("pipeline_status: failed to read activity buffer")
        return {"done": [], "skipped": [], "crashed": []}

    done: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    crashed: list[dict[str, Any]] = []

    for ev in events:
        action = ev.action or ""
        if action in _DONE_ACTIONS:
            done.append(_event_to_record(ev, bucket="done"))
        elif action in _SKIP_ACTIONS:
            skipped.append(_event_to_record(ev, bucket="skipped"))
        elif action in _CRASH_ACTIONS:
            crashed.append(_event_to_record(ev, bucket="crashed"))

    # Newest first within each bucket (the buffer is chronological)
    done.reverse()
    skipped.reverse()
    crashed.reverse()
    return {
        "done": done[:limit],
        "skipped": skipped[:limit],
        "crashed": crashed[:limit],
    }


async def enrich_failed_with_correlation(
    files: list[dict[str, Any]],
    activity: ActivityLogger | None,
    decisions: DecisionLogger | None,
    *,
    since_iso: str | None = None,
) -> list[dict[str, Any]]:
    """Join quarantined / unsupported file entries against the decision
    log + activity buffer to attach ``correlation_id`` + a specific error
    reason.

    Without this, files that ended up parked on disk show a generic
    "Timed out or crashed during ingest" reason and have no trace link —
    the user has no path from the parked file to the actual failure
    chain. With it, every parked file links back to the causal chain in
    /decisions where the original error / traceback lives.

    Lookup keyed by ``(kb, filename)``. Decision log wins ties (it
    survives restarts; activity buffer doesn't). Returns a NEW list with
    enriched copies — never mutates the input. Best-effort: any query
    failure leaves the list unchanged so the UI degrades cleanly.
    """
    if not files:
        return files
    if decisions is None and activity is None:
        return files

    lookup: dict[tuple[str, str], dict[str, str]] = {}

    # Source 1: decision log (persistent, survives restarts) — failed
    # ingest_file decisions and explicit ingest_quarantined records.
    if decisions is not None and hasattr(decisions, "query"):
        try:
            rows = await decisions.query(
                action_type="ingest_file",
                limit=500,
                since=since_iso or "",
            )
            for row in rows:
                if row.get("contract_result") not in ("failed", "skipped"):
                    # "skipped" here covers the "ingest_skipped_unsupported"
                    # path. Failed = crashed / timed out.
                    continue
                details = row.get("details") or {}
                kb = str(details.get("slug") or "")
                fn = str(details.get("file") or details.get("filename") or "")
                if not kb or not fn:
                    target = str(row.get("action_target") or "")
                    parts = target.split("/", 2)
                    if len(parts) >= 3 and parts[0] == "kb":
                        kb = parts[1]
                        fn = parts[2]
                if not kb or not fn:
                    continue
                cid = row.get("correlation_id") or ""
                if not cid:
                    continue
                key = (kb, fn)
                if key in lookup:
                    continue  # newest-first ordering means first hit wins
                err_text = (
                    str(details.get("error") or "")
                    or str(row.get("rationale") or "")
                )
                lookup[key] = {
                    "correlation_id": cid,
                    "reason": err_text[:240],
                }
        except Exception:
            log.exception("pipeline_status: decision query for enrichment failed")

    # Source 2: in-memory activity buffer — covers the timeout path that
    # writes an `ingest_quarantined` event but no decision row, plus
    # fresh crashes from this process before any decision row was
    # committed.
    if activity is not None and hasattr(activity, "get_recent_events"):
        try:
            evs = activity.get_recent_events(
                categories=["knowledge"],
                min_importance="medium",
                limit=500,
            )
            for ev in evs:
                action = getattr(ev, "action", "") or ""
                if action not in ("ingest_quarantined", "ingest_file_crashed"):
                    continue
                d = getattr(ev, "details", None) or {}
                kb = str(d.get("slug") or "")
                fn = str(d.get("filename") or d.get("file") or "")
                if not kb or not fn:
                    continue
                cid = getattr(ev, "correlation_id", "") or ""
                if not cid:
                    continue
                key = (kb, fn)
                if key in lookup:
                    continue
                err_text = (
                    str(d.get("reason") or "")
                    or str(d.get("error") or "")
                    or str(getattr(ev, "summary", "") or "")
                )
                lookup[key] = {
                    "correlation_id": cid,
                    "reason": err_text[:240],
                }
        except Exception:
            log.exception("pipeline_status: activity scan for enrichment failed")

    if not lookup:
        return files

    out: list[dict[str, Any]] = []
    for f in files:
        key = (str(f.get("kb") or ""), str(f.get("filename") or ""))
        meta = lookup.get(key)
        if meta:
            enriched = dict(f)
            enriched["correlation_id"] = meta["correlation_id"]
            specific_reason = meta.get("reason") or ""
            if specific_reason:
                enriched["reason"] = specific_reason
            out.append(enriched)
        else:
            out.append(f)
    return out


# Reason payload keys, in priority order. The first non-empty wins. Different
# enqueue sites use different key names — the watcher's
# ``_enqueue_agent_retry`` uses ``retry_reason``, the ``_do_ingest_body``
# empty-extraction retry uses ``reason``. Reading both prevents the silent
# "(unnamed)" / "no reason" surface where the data IS in the payload but
# the UI looks under the wrong key.
_REASON_PAYLOAD_KEYS: tuple[str, ...] = (  # arch:deterministic — payload key contract shared with watcher + kb/service enqueue sites
    "retry_reason",
    "reason",
)


def _human_reason(reason: str) -> str:
    """Map machine reason codes to short human phrases for card display.

    Falls back to the raw code in ``snake_case → snake case`` form so unknown
    codes still read intelligibly. Pure function.
    """
    if not reason:
        return ""
    table = {
        "agent_dispatch_timeout": "agent dispatch timeout",
        "agent_dispatch_error": "agent dispatch error",
        "skill_zero_effect": "skill produced no effect",
        "empty_extraction": "empty extraction — escalating tier",
        "language_drift": "output language mismatch",
        "language_drift_provider": "language drift — provider fallback",
        "multiple_reasons": "multiple reasons queued",
    }
    return table.get(reason, reason.replace("_", " "))


def _build_inflight_label(job_type: str, kb: str, filename: str, reason: str) -> str:
    """Compose a human-readable label for an in-flight work-queue row.

    KB-level jobs (no ``target_file`` in payload) are NOT specific files —
    each one means "scan the entire KB inbox". Surfacing them as a generic
    ``(unnamed)`` was misleading. Now they read as
    ``"Scan main inbox · agent dispatch timeout"`` etc., which matches what
    the queue handler actually does when it picks the row up.
    """
    kb_label = kb or "(no KB)"
    if filename:
        # File-specific job — keep the filename as the primary label.
        return filename
    if job_type == "ingest":
        base = f"Scan {kb_label} inbox"
    elif job_type == "wiki_job":
        base = f"Run wiki pipeline · {kb_label}"
    else:
        base = f"{job_type} · {kb_label}"
    if reason:
        return f"{base} · {_human_reason(reason)}"
    return base


async def list_inflight_jobs(work_queue: WorkQueue | None) -> list[dict[str, Any]]:
    """Return work-queue rows for ingest-related job types currently running or pending.

    Pulls the same data the work-queue page uses, but filtered to ingest types
    so the pipeline board is about FILES, not LLM-job retries in general.

    Same-intent rows are collapsed into one card. The collapse key is
    ``(job_type, kb, target_file)`` — the actual unit of work. Variations
    in ``retry_reason`` between rows of the same key produce a single card
    whose ``coalesced_count`` reflects how many enqueue events landed for
    the same ingest target. This stops the dashboard reporting "7 files in
    flight" when the underlying work is "one KB rescan, queued 7 times for
    7 different reasons" — true count of pending work units, not raw rows.
    """
    if work_queue is None:
        return []

    try:
        status = await work_queue.get_status()
    except Exception:
        log.exception("pipeline_status: failed to read work queue status")
        return []

    grouped: dict[tuple[str, str, str], dict[str, Any]] = {}
    order: list[tuple[str, str, str]] = []

    for job in status.get("pending_jobs", []):
        job_type = job.get("job_type") or ""
        if job_type not in _INGEST_JOB_TYPES:
            continue
        payload = job.get("payload") or {}
        kb = payload.get("slug") or payload.get("kb") or ""
        filename = payload.get("target_file") or payload.get("file") or ""
        reason_code = ""
        for key in _REASON_PAYLOAD_KEYS:
            value = payload.get(key)
            if value:
                reason_code = str(value)
                break
        tier_hint = (
            payload.get("escalate_tier")
            or payload.get("empty_extraction_tier")
            or ""
        )
        key = (job_type, kb, filename)
        existing = grouped.get(key)
        if existing is None:
            entry: dict[str, Any] = {
                "id": job.get("id"),
                "job_type": job_type,
                "kb": kb,
                "filename": filename,
                "display_label": _build_inflight_label(job_type, kb, filename, reason_code),
                "attempts": job.get("attempts", 0),
                "next_retry": job.get("next_retry") or "",
                "last_error": (job.get("last_error") or "")[:240],
                "created_at": job.get("created_at") or "",
                "reason": reason_code,
                "reason_label": _human_reason(reason_code),
                "tier_hint": tier_hint,
                "coalesced_count": 1,
                "coalesced_ids": [job.get("id")] if job.get("id") is not None else [],
                "coalesced_reasons": [reason_code] if reason_code else [],
            }
            grouped[key] = entry
            order.append(key)
        else:
            existing["coalesced_count"] += 1
            jid = job.get("id")
            if jid is not None:
                existing["coalesced_ids"].append(jid)
            if reason_code and reason_code not in existing["coalesced_reasons"]:
                existing["coalesced_reasons"].append(reason_code)
            # Track maximum attempts seen across the coalesced rows so the
            # card surfaces the worst-case retry pressure, not the first
            # row's stale value.
            existing["attempts"] = max(
                int(existing.get("attempts") or 0),
                int(job.get("attempts") or 0),
            )
            # Surface the most informative last_error in the group rather
            # than dropping later ones silently.
            err = (job.get("last_error") or "")[:240]
            if err and not existing.get("last_error"):
                existing["last_error"] = err
            # Update display label + reason if we previously had no reason
            # but a coalesced sibling carries one.
            if reason_code and not existing.get("reason"):
                existing["reason"] = reason_code
                existing["reason_label"] = _human_reason(reason_code)
                existing["display_label"] = _build_inflight_label(
                    job_type, kb, filename, reason_code,
                )
            # If multiple distinct reasons coalesced, switch the label to a
            # neutral "multiple reasons" tag so we don't lie about which
            # one was the cause.
            if len(existing["coalesced_reasons"]) > 1:
                existing["display_label"] = _build_inflight_label(
                    job_type, kb, filename, "multiple_reasons",
                )
                existing["reason"] = "multiple_reasons"
                existing["reason_label"] = "multiple reasons queued"

    return [grouped[k] for k in order]


# ── Phase 4 (2026-04-30) — pipeline health surface ──────────────────


HealthState = str  # "healthy" | "degraded" | "stalled" | "dormant"


def compute_pipeline_health(
    *,
    watcher_state: dict[str, Any],
    dispatch_states: list[dict[str, Any]],
    last_successful_ingest_age_seconds: int | None,
    failed_count: int,
    crashed_today_count: int,
    queued_count: int,
    pipeline_frozen: bool,
) -> dict[str, Any]:
    """Pure-function health-state derivation. Returns the ``health`` dict.

    State priority (highest first):
      - ``dormant`` — any KB has dispatch state == 'dormant'
      - ``stalled`` — watcher running AND no successful ingest in > 1h
                      AND queued > 0 (so the user sees backlog with no progress)
      - ``frozen`` — explicit user freeze
      - ``degraded`` — any non-active dispatch state, OR failed/crashed > 0,
                       OR watcher not running but queued > 0
      - ``healthy`` — everything green

    The function is pure (no DB, no IO) so the routes can compose it from
    already-fetched data without a second pass.
    """
    # Dormant wins — manual intervention required
    has_dormant = any(s.get("state") == "dormant" for s in dispatch_states)
    if has_dormant:
        return {
            "state": "dormant",
            "reason": (
                f"{sum(1 for s in dispatch_states if s.get('state') == 'dormant')} "
                f"KB(s) blocked — user must approve retry"
            ),
        }

    if pipeline_frozen:
        return {
            "state": "frozen",
            "reason": "Pipeline frozen by user — ingest paused",
        }

    # Stalled = "watcher claims running but nothing's actually moving"
    watcher_running = bool(watcher_state.get("running", False))
    watcher_paused = bool(watcher_state.get("paused", False))
    stale_threshold_seconds = 3600  # 1 hour
    has_backlog = queued_count > 0
    # Two cases of "no successful ingest in a long time":
    #   (a) age > 3600s — last ingest was an hour+ ago.
    #   (b) age is None AND there's a backlog — never had a successful
    #       ingest today AND files are queued. This is the case Bug A
    #       (2026-04-30 production) hit: server restarted, 378 queued,
    #       0 ingested today, age=None, dashboard read "healthy."
    is_stale_ingest = (
        (last_successful_ingest_age_seconds is not None
         and last_successful_ingest_age_seconds > stale_threshold_seconds)
        or (last_successful_ingest_age_seconds is None and has_backlog)
    )

    if watcher_running and not watcher_paused and is_stale_ingest and has_backlog:
        if last_successful_ingest_age_seconds is None:
            reason = (
                f"Watcher running but no successful ingest yet "
                f"with {queued_count} file(s) queued"
            )
        else:
            reason = (
                f"Watcher running but no ingest in "
                f"{int(last_successful_ingest_age_seconds / 60)}min "
                f"with {queued_count} file(s) queued"
            )
        return {"state": "stalled", "reason": reason}

    # Degraded = "soft warnings"
    has_escalating = any(s.get("state") == "escalating" for s in dispatch_states)
    has_failures = failed_count > 0 or crashed_today_count > 0
    watcher_dead_with_backlog = (
        not watcher_running and not watcher_paused and has_backlog
    )

    if has_escalating or has_failures or watcher_dead_with_backlog:
        reasons: list[str] = []
        if has_escalating:
            reasons.append(
                f"{sum(1 for s in dispatch_states if s.get('state') == 'escalating')} "
                f"KB(s) escalating"
            )
        if has_failures:
            reasons.append(
                f"{failed_count} failed, {crashed_today_count} crashed today"
            )
        if watcher_dead_with_backlog:
            reasons.append(
                f"Watcher not running but {queued_count} file(s) queued"
            )
        return {"state": "degraded", "reason": "; ".join(reasons)}

    # Default: healthy
    return {"state": "healthy", "reason": ""}


def _last_successful_ingest_iso_from_events(
    done_events: list[dict[str, Any]],
) -> str | None:
    """Walk the ``done`` events list to find the latest timestamp.
    Used by build_summary to compute ``last_successful_ingest_age_seconds``."""
    if not done_events:
        return None
    latest: str = ""
    for e in done_events:
        ts = e.get("ts") or e.get("timestamp") or ""
        if ts and (not latest or ts > latest):
            latest = ts
    return latest or None


async def build_summary(
    *,
    paths: VaultPaths,
    activity: ActivityLogger | None,
    work_queue: WorkQueue | None,
    watcher: object | None = None,
    kb_service: object | None = None,
    decisions: DecisionLogger | None = None,
    dispatch_state_service: object | None = None,
) -> dict[str, Any]:
    """Top-level aggregate for the dashboard PipelineCard.

    Returns counts plus a small sample for each bucket. Cheap to call (single
    pass over inbox dirs, single activity-buffer scan, one work-queue status).

    When ``decisions`` is wired, the done + crashed counts come from the
    persistent decision_log so they survive server restarts — the dashboard
    no longer flips back to ``Done today: 0`` after a code-change reload.
    Falls back to buffer-only when decisions aren't wired (tests, fresh
    boots, services not yet attached).
    """
    queued = list_queued_files(paths)
    inflight = await list_inflight_jobs(work_queue)
    # True per-bucket totals via COUNT(*) — Rule 20: never use len(<sliced>)
    # as a count. The lists themselves are capped at 50 for the dashboard
    # samples; the *_count fields below come from persistent COUNT.
    events_with_totals = await build_recent_events_with_totals(
        activity, decisions, limit=50,
    )
    events = {
        "done": events_with_totals["done"],
        "skipped": events_with_totals["skipped"],
        "crashed": events_with_totals["crashed"],
    }
    event_totals = events_with_totals["totals"]
    quarantined = list_quarantined_files(paths)
    unsupported = list_unsupported_files(paths)

    # Join the parked files against the decision log + activity buffer to
    # attach correlation_id + a real error reason. Without this, the
    # "trace →" link can't render on failed cards (the row has no chain
    # to point at) and the user sees a generic "Timed out or crashed"
    # message instead of the specific failure.
    failed = await enrich_failed_with_correlation(
        quarantined + unsupported, activity, decisions,
    )

    # Watcher gives us an authoritative "running?" + "last cycle" — surface it
    # in the summary so the PipelineCard can show a traffic-light dot without
    # a second round trip.
    watcher_state: dict[str, Any] = {"running": False, "paused": False}
    if watcher is not None:
        try:
            ws = watcher.get_status()
            watcher_state = {
                "running": bool(ws.get("running", False)),
                "paused": bool(ws.get("paused", False)),
                "last_cycle_seconds_ago": ws.get("last_cycle_seconds_ago"),
                "last_cycle_ingested": ws.get("last_cycle_ingested", 0),
                "last_error": ws.get("last_error", ""),
                "interval_seconds": ws.get("interval_seconds", 0),
                "cycle_count": ws.get("cycle_count", 0),
                # fs_events bridge tells the dashboard whether we're in
                # real-time (watchdog) mode or polling-only — folded into
                # PipelineCard after WatcherHealthCard was retired.
                "fs_events": ws.get("fs_events"),
            }
        except Exception:
            log.exception("pipeline_status: failed to read watcher status")

    # Pipeline freeze — global emergency gate distinct from watcher.paused.
    # Surface here so the dashboard card + /pipeline page render an honest
    # banner without a separate round trip to /api/settings/pipeline-freeze.
    pipeline_frozen = False
    if kb_service is not None and hasattr(kb_service, "is_pipeline_frozen"):
        try:
            pipeline_frozen = bool(kb_service.is_pipeline_frozen())
        except Exception:
            log.exception("pipeline_status: failed to read freeze state")

    # ── Phase 4 — health block ──
    # Pull dispatch states (returns [] when service is unavailable).
    dispatch_state_items: list[dict[str, Any]] = []
    if dispatch_state_service is not None and hasattr(dispatch_state_service, "list_non_active_states"):
        try:
            rows = await dispatch_state_service.list_non_active_states()  # type: ignore[attr-defined]
            dispatch_state_items = [
                {
                    "slug": r.slug,
                    "scope": r.scope,
                    "state": r.state,
                    "consecutive_zero_effects": r.consecutive_zero_effects,
                    "consecutive_escalation_failures": r.consecutive_escalation_failures,
                    "last_state_change_iso": r.last_state_change_iso,
                    "last_attempt_iso": r.last_attempt_iso,
                    "last_error_preview": r.last_error_preview,
                }
                for r in rows
            ]
        except Exception:
            log.debug("pipeline_status: dispatch_state read failed", exc_info=True)

    # Compute last-successful-ingest age from the done sample (most recent
    # entry's timestamp). The done sample is already sorted newest-first
    # by build_recent_events_with_totals — we just take the head.
    last_ok_iso = _last_successful_ingest_iso_from_events(events["done"])
    last_ok_age_seconds: int | None = None
    if last_ok_iso:
        try:
            from datetime import datetime as _dt
            t = _dt.fromisoformat(last_ok_iso)
            if t.tzinfo is None:
                t = t.replace(tzinfo=UTC)
            last_ok_age_seconds = max(0, int((_dt.now(UTC) - t).total_seconds()))
        except (ValueError, TypeError):
            last_ok_age_seconds = None

    health = compute_pipeline_health(
        watcher_state=watcher_state,
        dispatch_states=dispatch_state_items,
        last_successful_ingest_age_seconds=last_ok_age_seconds,
        failed_count=len(failed),
        crashed_today_count=event_totals["crashed"],
        queued_count=len(queued),
        pipeline_frozen=pipeline_frozen,
    )
    health["last_successful_ingest_iso"] = last_ok_iso or ""
    health["last_successful_ingest_age_seconds"] = last_ok_age_seconds
    health["dispatch_states"] = dispatch_state_items
    health["stall_streak"] = int(watcher_state.get("stall_streak", 0))

    return {
        # All five *_count fields are TRUE totals — never sliced-list
        # lengths. queued/inflight/failed come from full directory + work
        # queue scans (no slicing). done/skipped/crashed come from a
        # COUNT(*) query against the persistent decision log.
        "queued_count": len(queued),
        "inflight_count": len(inflight),
        "done_today_count": event_totals["done"],
        "skipped_today_count": event_totals["skipped"],
        # Crashes that hit the per-file safety net mid-flight. Distinct from
        # ``failed_count`` (filesystem-terminal: quarantine + unsupported).
        # Both numbers can be non-zero simultaneously — a crashed batch
        # produces decision rows but doesn't move the file to quarantine
        # unless a separate timeout/quarantine path fires.
        "crashed_today_count": event_totals["crashed"],
        "failed_count": len(failed),
        "queued_sample": queued[:8],
        "inflight_sample": inflight[:8],
        "done_sample": events["done"][:8],
        "skipped_sample": events["skipped"][:5],
        "crashed_sample": events["crashed"][:5],
        "failed_sample": failed[:8],
        "watcher": watcher_state,
        "frozen": pipeline_frozen,
        # Phase 4 — health narrative for the UI traffic light.
        "health": health,
    }


async def build_full_board(
    *,
    paths: VaultPaths,
    activity: ActivityLogger | None,
    work_queue: WorkQueue | None,
    limit_per_bucket: int = 100,
    kb_service: object | None = None,
    decisions: DecisionLogger | None = None,
) -> dict[str, Any]:
    """Full Kanban-board payload for the /pipeline page.

    Same data as build_summary but unbounded (per limit) so users can scroll
    through every queued file, every inflight job, today's complete log.

    Counts always reflect the TRUE total (pre-truncation), so the dashboard
    PipelineCard and the /pipeline page header agree. The lists themselves
    are truncated to ``limit_per_bucket`` so the response stays bounded.
    The per-bucket ``truncated`` flag tells the UI when to render
    "showing first N of TOTAL".
    """
    queued_all = list_queued_files(paths)
    inflight_all = await list_inflight_jobs(work_queue)
    # True per-bucket totals via COUNT(*) — Rule 20: never use len(<sliced>)
    # as a count. The lists are capped at limit_per_bucket; the totals
    # below come from the persistent decision log.
    events_with_totals = await build_recent_events_with_totals(
        activity, decisions, limit=limit_per_bucket,
    )
    events = {
        "done": events_with_totals["done"],
        "skipped": events_with_totals["skipped"],
        "crashed": events_with_totals["crashed"],
    }
    event_totals = events_with_totals["totals"]
    quarantined = list_quarantined_files(paths)
    unsupported = list_unsupported_files(paths)
    failed_all = await enrich_failed_with_correlation(
        quarantined + unsupported, activity, decisions,
    )

    # Truncated lists for response payload (don't ship 5000 rows).
    queued = queued_all[:limit_per_bucket]
    inflight = inflight_all[:limit_per_bucket]
    failed = failed_all[:limit_per_bucket]

    pipeline_frozen = False
    if kb_service is not None and hasattr(kb_service, "is_pipeline_frozen"):
        try:
            pipeline_frozen = bool(kb_service.is_pipeline_frozen())
        except Exception:
            log.exception("pipeline_status: failed to read freeze state")

    return {
        "queued": queued,
        "inflight": inflight,
        "done": events["done"],
        "skipped": events["skipped"],
        "crashed": events["crashed"],
        "failed": failed,  # quarantine + unsupported (file-system terminal failures)
        "counts": {
            # True totals — done/skipped/crashed come from a COUNT(*) query
            # against the persistent decision log; queued/inflight/failed
            # come from the full pre-truncation collections. Never
            # ``len(<sliced>)`` (Rule 20).
            "queued": len(queued_all),
            "inflight": len(inflight_all),
            "done": event_totals["done"],
            "skipped": event_totals["skipped"],
            "crashed": event_totals["crashed"],
            "failed": len(failed_all),
        },
        "truncated": {
            "queued": len(queued_all) > len(queued),
            "inflight": len(inflight_all) > len(inflight),
            # done/skipped/crashed are also truncated when persistent total
            # exceeds the rendered list length — UI uses this to show
            # "showing N of TOTAL" so users see the cap honestly.
            "done": event_totals["done"] > len(events["done"]),
            "skipped": event_totals["skipped"] > len(events["skipped"]),
            "crashed": event_totals["crashed"] > len(events["crashed"]),
            "failed": len(failed_all) > len(failed),
        },
        "limit_per_bucket": limit_per_bucket,
        "frozen": pipeline_frozen,
    }
