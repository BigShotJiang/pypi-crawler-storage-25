"""Missing-agent detector — proactive proposal of agent-skill ownership
when a skill exists but no specialist agent declares it in their
``skills:`` list.

**The gap this closes**: AgntSpace's orchestrator dispatches work to
specialist agents. Each specialist's prompt is built from the union
of (a) the agent's personality and (b) every SKILL.md body for skills
listed in the agent's ``skills:`` frontmatter. If a skill is on disk
but no agent declares it, that skill never reaches a model — its
instructions, examples, and ``tools_granted`` contract are
structurally orphaned.

This detector closes the gap: walk every loaded skill, check whether
at least one specialist agent has it in their ``skills:`` list, and
propose a draft owner for skills that have no owner.

The "main" agent is intentionally NOT counted as a valid owner unless
``count_main_as_owner: true`` in the YAML. Main has broad fallback
access and isn't a specialist — dispatching through main loses the
tool-scoping pass that makes specialists trustworthy.

**Engine vs strategy split** (Rule 12):

The thresholds, excluded categories, owner-suggestion heuristic, and
cadence live in
``defaults/skills/_meta/missing-agent-detect/config/detect.yaml``.
This module is pure mechanics — the YAML decides the policy.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agntspace.automation.capability_proposals import (
    list_pending,
    stable_proposal_id,
    write_proposal,
)

log = logging.getLogger(__name__)


@dataclass
class OrphanSkill:
    """One skill that no specialist agent owns."""

    name: str
    category: str = ""
    priority: int = 0
    suggested_owner: str = ""
    suggested_owners: list[str] = field(default_factory=list)


# ── Pure helpers (testable in isolation) ──────────────────────────────


def _agent_skill_index(orchestrator) -> dict[str, list[str]]:
    """Return ``{skill_name: [agent_key, ...]}`` for every agent that
    declares the skill in their ``skills:`` list.

    Excludes inactive agents — orphan-detection cares about runtime
    reach, and an inactive agent doesn't dispatch.
    """
    out: dict[str, list[str]] = {}
    if orchestrator is None or not hasattr(orchestrator, "agents"):
        return out
    try:
        agents = orchestrator.agents or {}
    except Exception:
        log.debug("orchestrator.agents access failed", exc_info=True)
        return out
    for agent_key, agent_def in agents.items():
        status = getattr(agent_def, "status", "active")
        if status != "active":
            continue
        skills = getattr(agent_def, "skills", []) or []
        if not isinstance(skills, list):
            continue
        for skill_name in skills:
            if isinstance(skill_name, str) and skill_name:
                out.setdefault(skill_name, []).append(agent_key)
    return out


def _collect_loaded_skills(skill_loader) -> dict[str, dict]:
    """Return a flat dict ``{skill_name: {category, status, priority}}``
    so the detector can filter without holding the full Skill objects.
    """
    out: dict[str, dict] = {}
    if skill_loader is None:
        return out
    try:
        skills = skill_loader.skills or {}
    except Exception:
        log.debug("skill_loader.skills access failed", exc_info=True)
        return out
    for skill_name, skill in skills.items():
        out[skill_name] = {
            "category": getattr(skill, "category", "") or "",
            "status": getattr(skill, "status", "active") or "active",
            "priority": int(getattr(skill, "priority", 0) or 0),
        }
    return out


def _agent_skill_categories(skill_loader, agent_skills: list[str]) -> set[str]:
    """Resolve every agent skill to its declared category.

    Defensive: skills missing from the loader are silently skipped
    (a partially-installed agent shouldn't fail the heuristic).
    """
    out: set[str] = set()
    if skill_loader is None:
        return out
    for skill_name in agent_skills:
        if not isinstance(skill_name, str) or not skill_name:
            continue
        try:
            skill = skill_loader.get_skill(skill_name)
        except Exception:
            continue
        if skill is None:
            continue
        cat = getattr(skill, "category", "") or ""
        if cat:
            out.add(cat)
    return out


def _suggest_owners(
    *,
    orphan_skill: str,
    orphan_meta: dict,
    orchestrator,
    skill_loader=None,
    max_suggestions: int = 3,
) -> list[str]:
    """Heuristic: pick existing specialists whose current skill set
    overlaps the orphan's category.

    Ranking (descending = best fit first):

    1. **Same-category overlap count** — how many of the agent's existing
       skills are in the orphan's category. An agent with 3 ``creative/``
       skills is the strongest fit for a new ``creative/`` orphan.
    2. **Has-any-overlap boolean tier** — even if the count is 1,
       category-aware agents rank above zero-overlap agents.
    3. **Tools-granted overlap** — count of tools_granted shared between
       the agent's existing skills and the orphan. Skills using the
       same tool surface tend to belong to the same agent.
    4. **Smaller existing skill-set size** — load balance among ties.
    5. **Alphabetical** — deterministic last-resort tie-break.

    Main is excluded from the suggestion pool — orphans should land on
    specialists. Without a ``skill_loader`` the function still ranks by
    load balance + alphabetical (legacy behaviour, but logs a warning
    so the broken case is visible).

    Returns at most ``max_suggestions`` agent keys.
    """
    if orchestrator is None or not hasattr(orchestrator, "agents"):
        return []
    try:
        agents = orchestrator.agents or {}
    except Exception:
        return []

    if skill_loader is None:
        log.warning(
            "missing-agent: _suggest_owners called without skill_loader — "
            "category-overlap ranking unavailable, falling back to load-balance",
        )

    orphan_category = (orphan_meta or {}).get("category", "") or ""
    orphan_tools: set[str] = set()
    if skill_loader is not None and orphan_skill:
        try:
            o_skill = skill_loader.get_skill(orphan_skill)
            if o_skill is not None:
                tg = getattr(o_skill, "tools_granted", []) or []
                if isinstance(tg, list):
                    orphan_tools = {t for t in tg if isinstance(t, str) and t}
        except Exception:
            pass

    # candidates: (agent_key, category_overlap, tools_overlap, skills_count)
    candidates: list[tuple[str, int, int, int]] = []
    for agent_key, agent_def in agents.items():
        if agent_key == "main":
            continue
        if getattr(agent_def, "agent_type", "specialist") != "specialist":
            continue
        if getattr(agent_def, "status", "active") != "active":
            continue
        skills = getattr(agent_def, "skills", []) or []
        if not isinstance(skills, list):
            continue

        cat_overlap = 0
        tool_overlap = 0
        if skill_loader is not None and orphan_category:
            for skill_name in skills:
                if not isinstance(skill_name, str):
                    continue
                try:
                    s = skill_loader.get_skill(skill_name)
                except Exception:
                    continue
                if s is None:
                    continue
                if getattr(s, "category", "") == orphan_category:
                    cat_overlap += 1
                if orphan_tools:
                    tg = getattr(s, "tools_granted", []) or []
                    if isinstance(tg, list):
                        tool_overlap += len(orphan_tools & {
                            t for t in tg if isinstance(t, str)
                        })

        candidates.append((agent_key, cat_overlap, tool_overlap, len(skills)))

    if not candidates:
        return []

    # Sort: highest category-overlap first, then tools-overlap, then
    # smaller skill-set (load balance), then alphabetical.
    candidates.sort(key=lambda t: (-t[1], -t[2], t[3], t[0]))
    return [c[0] for c in candidates[:max_suggestions]]


def find_orphan_skills(
    skill_loader,
    orchestrator,
    *,
    excluded_categories: list[str] | None = None,
    excluded_statuses: list[str] | None = None,
    count_main_as_owner: bool = False,
    max_suggested_owners: int = 3,
) -> list[OrphanSkill]:
    """Pure analysis — return one ``OrphanSkill`` per skill that no
    specialist owns.

    Sorted by priority desc + name asc so high-priority orphans
    surface first.
    """
    skills = _collect_loaded_skills(skill_loader)
    if not skills:
        return []
    owner_index = _agent_skill_index(orchestrator)

    excluded_cats = set(excluded_categories or [])
    excluded_stats = set(excluded_statuses or [])

    out: list[OrphanSkill] = []
    for skill_name, meta in skills.items():
        if meta["category"] in excluded_cats:
            continue
        if meta["status"] in excluded_stats:
            continue
        owners = list(owner_index.get(skill_name, []))
        if not count_main_as_owner:
            owners = [a for a in owners if a != "main"]
        if owners:
            continue
        suggested = _suggest_owners(
            orphan_skill=skill_name,
            orphan_meta=meta,
            orchestrator=orchestrator,
            skill_loader=skill_loader,
            max_suggestions=max_suggested_owners,
        )
        out.append(OrphanSkill(
            name=skill_name,
            category=meta["category"],
            priority=meta["priority"],
            suggested_owner=suggested[0] if suggested else "",
            suggested_owners=list(suggested),
        ))
    out.sort(key=lambda o: (-o.priority, o.name))
    return out


# ── Service ─────────────────────────────────────────────────────────


class MissingAgentDetector:
    """Heartbeat-driven detector. Construct once at boot, call
    ``detect_and_propose()`` periodically.

    Each call:

    1. Walks every loaded skill.
    2. For each, checks whether any active specialist agent has it
       in their ``skills:`` list.
    3. Emits one capability-proposal per orphan, with a suggested
       owner picked by category-overlap heuristic.
    4. Skips writing if a pending proposal already exists with the
       same stable id AND ``skip_if_pending=True`` (default).

    **Stateless** — no in-process state. Re-running with no changes
    is a no-op.
    """

    def __init__(
        self,
        vault_dir: Path,
        skill_loader,
        orchestrator,
        *,
        config: dict | None = None,
    ):
        self._vault_dir = Path(vault_dir)
        self._skill_loader = skill_loader
        self._orchestrator = orchestrator
        self._config = dict(config or {})
        self._activity = None
        self._decisions = None

    @property
    def enabled(self) -> bool:
        return bool(self._config.get("enabled", True))

    @property
    def count_main_as_owner(self) -> bool:
        return bool(self._config.get("count_main_as_owner", False))

    @property
    def excluded_categories(self) -> list[str]:
        raw = self._config.get("excluded_categories", ["_meta"])
        if not isinstance(raw, list):
            return ["_meta"]
        return [c for c in raw if isinstance(c, str)]

    @property
    def excluded_statuses(self) -> list[str]:
        raw = self._config.get("excluded_statuses", ["pending", "archived", "draft"])
        if not isinstance(raw, list):
            return ["pending", "archived", "draft"]
        return [s for s in raw if isinstance(s, str)]

    @property
    def skip_if_pending(self) -> bool:
        return bool(self._config.get("skip_if_pending", True))

    @property
    def cadence_hours(self) -> int:
        return int(self._config.get("cadence_hours", 24))

    @property
    def max_suggested_owners(self) -> int:
        return int(self._config.get("max_suggested_owners", 3))

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan. Returns a structured report."""
        if not self.enabled:
            return {
                "skipped": "disabled",
                "skills_scanned": 0,
                "orphans_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            orphans = find_orphan_skills(
                self._skill_loader,
                self._orchestrator,
                excluded_categories=self.excluded_categories,
                excluded_statuses=self.excluded_statuses,
                count_main_as_owner=self.count_main_as_owner,
                max_suggested_owners=self.max_suggested_owners,
            )
        except Exception as exc:
            log.exception("missing-agent: scan failed: %s", exc)
            return {
                "error": f"scan: {exc}",
                "skills_scanned": 0,
                "orphans_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            skills_count = len(self._skill_loader.skills or {}) if self._skill_loader else 0
        except Exception:
            skills_count = 0

        existing_ids: set[str] = set()
        if self.skip_if_pending:
            try:
                for p in list_pending(self._vault_dir, "agent"):
                    existing_ids.add(p.proposal_id)
            except Exception:
                pass

        proposals_written = 0
        skipped_dedup = 0
        proposal_records: list[dict] = []
        write_errors: list[dict] = []

        for entry in orphans:
            stable_id = stable_proposal_id("agent", entry.name)
            if self.skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue
            suggested_label = (
                f" → suggest {entry.suggested_owner}"
                if entry.suggested_owner
                else " (no specialist fits — consider new agent)"
            )
            title = f"Skill orphan: {entry.name}{suggested_label}"
            description = (
                f"Skill {entry.name!r} (category={entry.category!r}, "
                f"priority={entry.priority}) has no specialist agent "
                f"in its skills list. Without an owner, this skill's "
                f"instructions never reach a dispatched model."
            )
            rationale = (
                "Loaded skills: every active SKILL.md should belong to "
                "at least one specialist's `skills:` frontmatter so "
                "the orchestrator can dispatch a model carrying it. "
                + (
                    f"Suggested owner(s): {', '.join(entry.suggested_owners)}. "
                    if entry.suggested_owners
                    else "No suggested owner — consider drafting a new "
                    "specialist agent definition under "
                    "<vault>/agntspace/system/agents/. "
                )
                + "Approve to acknowledge; assign manually by editing "
                "the chosen agent's frontmatter (skills:) field."
            )
            payload = {
                "orphan_skill": entry.name,
                "category": entry.category,
                "priority": entry.priority,
                "suggested_owner_agent": entry.suggested_owner or None,
                "suggested_owner_agents": list(entry.suggested_owners),
                "existing_owners": [],  # always empty — orphan-by-definition
            }
            proposal, err = write_proposal(
                self._vault_dir,
                "agent",
                target=entry.name,
                title=title,
                description=description,
                rationale=rationale,
                proposed_by="missing-agent-detector",
                examples=list(entry.suggested_owners),
                payload=payload,
            )
            if proposal is None:
                write_errors.append({"skill": entry.name, "error": err})
                continue
            proposals_written += 1
            proposal_records.append({
                "skill": entry.name,
                "category": entry.category,
                "priority": entry.priority,
                "suggested_owner": entry.suggested_owner,
                "proposal_id": proposal.proposal_id,
            })

        if self._activity is not None and (proposals_written or skipped_dedup):
            try:
                await self._activity.log(
                    category="agent",
                    action="missing_agent_proposals",
                    summary=(
                        f"Detected {len(orphans)} orphan skill(s); "
                        f"wrote {proposals_written} proposal(s), "
                        f"skipped {skipped_dedup} already-pending."
                    ),
                    details={
                        "skills_scanned": skills_count,
                        "orphans_found": len(orphans),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "count_main_as_owner": self.count_main_as_owner,
                        "proposals": proposal_records[:20],
                        "write_errors": write_errors[:5],
                    },
                    importance="medium" if proposals_written else "low",
                )
            except Exception:
                pass

        return {
            "skills_scanned": skills_count,
            "orphans_found": len(orphans),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "proposals": proposal_records,
            "write_errors": write_errors,
        }


# ── Frontmatter editor (pure helpers, testable in isolation) ─────────


def _split_frontmatter(content: str) -> tuple[list[str], int, int] | None:
    """Find the YAML frontmatter block in an agent .md file.

    Returns ``(lines, start_idx, end_idx)`` where ``start_idx`` is the
    line index of the opening ``---`` and ``end_idx`` is the closing
    ``---`` (both inclusive of the ``---`` markers themselves).

    Returns ``None`` if the file doesn't have a well-formed
    frontmatter block (must start with ``---`` on line 0 and have a
    matching closing ``---`` later).
    """
    if not content:
        return None
    # Preserve trailing newline by splitting with keepends=False — we'll
    # rejoin with explicit "\n" so the editor stays format-stable.
    lines = content.splitlines()
    if not lines or lines[0].strip() != "---":
        return None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return lines, 0, i
    return None


def _find_skills_block(
    lines: list[str], fm_start: int, fm_end: int,
) -> tuple[int, int] | None:
    """Locate the ``skills:`` block inside the frontmatter range.

    Returns ``(skills_line_idx, last_item_idx)`` where:

    * ``skills_line_idx`` is the line containing ``skills:`` (the YAML key).
    * ``last_item_idx`` is the line index of the LAST ``  - <name>``
      entry. If the block is empty (``skills: []`` inline OR
      ``skills:`` followed immediately by a non-list line), returns
      ``(skills_line_idx, skills_line_idx)`` so the caller can append
      the first list item right after the key line.

    Returns ``None`` if no ``skills:`` key is found inside the
    frontmatter range.
    """
    skills_idx: int | None = None
    for i in range(fm_start + 1, fm_end):
        line = lines[i]
        # Match "skills:" at column 0 (top-level YAML key) — agent
        # frontmatter never nests skills inside another block.
        stripped = line.lstrip()
        if stripped.startswith("skills:") and line == stripped:
            skills_idx = i
            break
    if skills_idx is None:
        return None

    # Walk forward to find the last `  - <item>` line that belongs
    # to this skills: block. A list item starts with whitespace
    # followed by `- `. Any line at column 0 (top-level key) ends
    # the block.
    last_item = skills_idx
    for j in range(skills_idx + 1, fm_end):
        line = lines[j]
        if not line.strip():
            # Blank line inside frontmatter — keep walking, blank
            # lines don't end a block in our agent files but be
            # defensive.
            continue
        # If this line is at column 0 it's a new top-level key.
        if line == line.lstrip() and not line.startswith("- "):
            break
        # Otherwise it should be indented — treat as part of skills:
        # only if it's a `- ` list item.
        ls = line.lstrip()
        if ls.startswith("- "):
            last_item = j
            continue
        # Continuation line (e.g. multi-line description on a list
        # item) — still part of this block, keep walking.
    return skills_idx, last_item


def _detect_list_indent(lines: list[str], skills_line_idx: int, last_item_idx: int) -> str:
    """Pick the indentation prefix to use for a new ``- skill`` line.

    Reads the existing last item's indent if present; otherwise
    defaults to two spaces (the AgntSpace convention).
    """
    if last_item_idx > skills_line_idx:
        existing = lines[last_item_idx]
        prefix = existing[: len(existing) - len(existing.lstrip())]
        if prefix:
            return prefix
    return "  "


def add_skill_to_agent_frontmatter(
    content: str, skill_name: str,
) -> tuple[str, str]:
    """Add ``skill_name`` to the agent's ``skills:`` YAML list.

    Pure function — no I/O. Surgical line-level insert that preserves
    comments, ordering, and blank lines elsewhere in the file.

    Returns ``(new_content, status)`` where status is one of:

    * ``"added"`` — skill was appended.
    * ``"already_present"`` — idempotent no-op (skill already listed).
    * ``"no_frontmatter"`` — file missing well-formed ``---`` block.
    * ``"no_skills_block"`` — frontmatter found but no ``skills:`` key.
      (We deliberately don't synthesise a missing block — agents
      without ``skills:`` are likely supervisors or have a different
      shape; require a manual edit.)
    * ``"empty_skill_name"`` — guard against blank input.

    The original ``content`` is returned unchanged for every non-success
    status so callers can branch safely.
    """
    if not isinstance(skill_name, str) or not skill_name.strip():
        return content, "empty_skill_name"
    skill = skill_name.strip()

    fm = _split_frontmatter(content)
    if fm is None:
        return content, "no_frontmatter"
    lines, fm_start, fm_end = fm

    # Idempotent existence check — scan the skills block for an exact
    # `- <skill>` match before we even compute the insert position.
    skills_block = _find_skills_block(lines, fm_start, fm_end)
    if skills_block is None:
        return content, "no_skills_block"
    skills_idx, last_item_idx = skills_block

    # Walk every line from `skills:` to the end of its block, looking
    # for an existing entry. Compare the trimmed-after-dash text.
    end_scan = last_item_idx if last_item_idx > skills_idx else fm_end - 1
    for k in range(skills_idx + 1, end_scan + 1):
        ls = lines[k].strip()
        if ls.startswith("- "):
            existing = ls[2:].strip()
            # Skill names can be wrapped in quotes — strip simple ones.
            if existing.startswith(("'", '"')) and existing.endswith(("'", '"')):
                existing = existing[1:-1]
            if existing == skill:
                return content, "already_present"

    indent = _detect_list_indent(lines, skills_idx, last_item_idx)
    new_line = f"{indent}- {skill}"

    # Insert AFTER the last existing item. If the block was empty
    # (`skills:` immediately followed by another top-level key), insert
    # right after the `skills:` key line.
    insert_at = last_item_idx + 1 if last_item_idx > skills_idx else skills_idx + 1

    new_lines = lines[:insert_at] + [new_line] + lines[insert_at:]

    # Preserve trailing newline iff the original had one. splitlines()
    # drops it, so we re-attach explicitly when present.
    trailing_nl = content.endswith("\n")
    new_content = "\n".join(new_lines) + ("\n" if trailing_nl else "")
    return new_content, "added"


# ── Approval handler ─────────────────────────────────────────────────


# Sentinel error codes returned by approve_agent_proposal — kept as a
# closed set so the route layer can map them to HTTP status codes
# without parsing free text.
APPROVE_ERR_NOT_FOUND = "not_found"
APPROVE_ERR_NO_OWNER = "no_owner_chosen"
APPROVE_ERR_AGENT_FILE_MISSING = "agent_file_missing"
APPROVE_ERR_AGENT_FILE_UNREADABLE = "agent_file_unreadable"
APPROVE_ERR_FRONTMATTER_MALFORMED = "frontmatter_malformed"
APPROVE_ERR_NO_SKILLS_BLOCK = "agent_has_no_skills_block"
APPROVE_ERR_WRITE_FAILED = "write_failed"


def _agent_file_path(vault_dir: Path, owner: str) -> Path:
    """Resolve the agent definition file for ``owner`` inside vault."""
    return Path(vault_dir) / "agntspace" / "system" / "agents" / f"{owner}.md"


def approve_agent_proposal(
    vault_dir: Path,
    proposal_id: str,
    *,
    chosen_owner: str | None = None,
) -> tuple[bool, str, dict[str, Any]]:
    """Add the orphan skill to the chosen agent's ``skills:`` list.

    This is the **active** approval path (Rule 21 + the contract-action
    precedent): user-confirmed structural changes via the proposal
    queue mutate the vault directly. Without an actual edit, approval
    was a hollow "queue cleared" UX — the orphan re-detected on the
    next heartbeat scan and the user couldn't tell what they were
    supposed to do.

    Args:
        vault_dir: vault root (parent of ``agntspace/`` subdir).
        proposal_id: stable id of the pending proposal.
        chosen_owner: optional override for the owner agent. When
            ``None``, falls back to ``payload["suggested_owner_agent"]``.
            Pass an empty agent set or unknown name to get a clean
            ``no_owner_chosen`` error.

    Returns:
        ``(ok, message, details)`` where ``details`` carries the
        edited file path + agent + skill so the route layer + UI can
        deep-link back to the file.
    """
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    proposal = get_proposal(vault_dir, "agent", proposal_id)
    if proposal is None:
        return False, APPROVE_ERR_NOT_FOUND, {}

    skill_name = (proposal.target or "").strip()
    payload = proposal.payload or {}

    owner = (chosen_owner or "").strip() or (
        payload.get("suggested_owner_agent") or ""
    ).strip()
    if not owner:
        return False, APPROVE_ERR_NO_OWNER, {
            "skill": skill_name,
            "suggested_owners": list(payload.get("suggested_owner_agents") or []),
        }

    agent_file = _agent_file_path(vault_dir, owner)
    if not agent_file.is_file():
        return False, APPROVE_ERR_AGENT_FILE_MISSING, {
            "skill": skill_name,
            "owner": owner,
            "agent_file": str(agent_file),
        }

    try:
        original = agent_file.read_text(encoding="utf-8")
    except OSError as exc:
        return False, f"{APPROVE_ERR_AGENT_FILE_UNREADABLE}:{exc}", {
            "skill": skill_name,
            "owner": owner,
        }

    new_content, status = add_skill_to_agent_frontmatter(original, skill_name)
    if status == "no_frontmatter":
        return False, APPROVE_ERR_FRONTMATTER_MALFORMED, {
            "skill": skill_name,
            "owner": owner,
        }
    if status == "no_skills_block":
        return False, APPROVE_ERR_NO_SKILLS_BLOCK, {
            "skill": skill_name,
            "owner": owner,
            "hint": (
                "Edit the agent file by hand to add a `skills:` YAML "
                "list — the structure is non-standard for that agent."
            ),
        }
    if status == "already_present":
        # Idempotent — clear the queue without re-writing the file.
        reject_proposal(vault_dir, "agent", proposal_id)
        return True, "already_present", {
            "skill": skill_name,
            "owner": owner,
            "agent_file": str(agent_file),
        }

    # status == "added" — write atomically (.tmp + replace) so a crash
    # mid-write can't leave half-formed YAML.
    tmp = agent_file.with_suffix(".md.tmp")
    try:
        tmp.write_text(new_content, encoding="utf-8")
        tmp.replace(agent_file)
    except OSError as exc:
        return False, f"{APPROVE_ERR_WRITE_FAILED}:{exc}", {
            "skill": skill_name,
            "owner": owner,
        }

    reject_proposal(vault_dir, "agent", proposal_id)
    return True, "added", {
        "skill": skill_name,
        "owner": owner,
        "agent_file": str(agent_file),
    }
