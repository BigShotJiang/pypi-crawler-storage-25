# BUILD-REPORT-v1.8.0.md — local clarify release readiness

Date: 2026-04-20
Builder: OpenClaw subagent execution pass
Status: SHIPPED

## What shipped locally in this pass

- Added `agentkit_cli/clarify.py` as the deterministic clarify engine on top of bundle + taskpack surfaces.
- Added `agentkit_cli/commands/clarify_cmd.py` and `agentkit clarify <path>` CLI wiring in `agentkit_cli/main.py`.
- Added focused tests in `tests/test_clarify.py`, `tests/test_clarify_cmd.py`, and `tests/test_clarify_workflow.py`.
- Updated README and CHANGELOG so the documented handoff lane now ends with `clarify` before coding-agent execution.
- Bumped local package metadata from `1.7.0` to `1.8.0` in `pyproject.toml`, `agentkit_cli/__init__.py`, and `uv.lock`.

## Validation summary

- Focused clarify workflow slice passed: `32 passed in 1.68s`, covering engine ordering, CLI rendering, output directories, full-lane integration, missing-source pauses, contradictory guidance, bundle/taskpack compatibility, and version CLI output.
- Full pytest suite passed: `4863 passed, 1 warning in 144.09s (0:02:24)` via `uv run --python 3.11 --with pytest --with fastapi --with uvicorn --with httpx pytest -q`.
- Status-conflict scan passed with no contradictory success/blocker narratives.
- Post-agent hygiene check passed with zero findings.

## Truthful release status

`agentkit-cli v1.8.0` is shipped. The focused clarify release slice and full supported pytest suite passed from the tested release commit `3ed7f140394711e5822616dbe7006a9146d92465`, annotated tag `v1.8.0` on origin peels to that same commit, and PyPI `agentkit-cli==1.8.0` is live with both the wheel (`613519` bytes) and sdist (`1100491` bytes) verified directly. The branch now carries later docs-only chronology reconciliation commits after the shipped tag so the repo surfaces stay truthful without changing the released artifact.
