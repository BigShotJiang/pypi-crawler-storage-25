import json
from datetime import datetime
from google.cloud.pubsub_v1.subscriber.message import Message
from typing import Self
from uuid import UUID
from nexo.enums.environment import Environment, EnvironmentMixin
from nexo.infra.heartbeat.schemas import Heartbeat
from nexo.schemas.mixins.identity import UUIDId
from nexo.schemas.mixins.timestamp import CreationTimestamp
from ..mixins.common import MessageId, PublishedAt, InstanceId, ServiceKey


class CreateParameter(
    Heartbeat,
    ServiceKey,
    EnvironmentMixin[Environment],
    InstanceId,
    PublishedAt,
    MessageId,
):
    @classmethod
    def from_message(cls, message: Message) -> Self:
        return cls.model_validate(
            {
                **json.loads(message.data.decode("utf-8")),
                **message.attributes,
                "message_id": message.message_id,
                "published_at": message.publish_time,
            }
        )


class HeartbeatSchema(
    CreateParameter,
    CreationTimestamp[datetime],
    UUIDId[UUID],
):
    pass
