"""
DIFP CORE - initial release (structure placeholder).
"""
