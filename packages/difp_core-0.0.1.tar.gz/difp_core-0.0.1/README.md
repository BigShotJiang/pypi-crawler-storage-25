# DIFP CORE

Initial skeleton package for DIFP CORE.
