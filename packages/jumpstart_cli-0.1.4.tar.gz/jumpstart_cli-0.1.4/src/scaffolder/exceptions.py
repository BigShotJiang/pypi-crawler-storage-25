class ScaffoldError(Exception):
    pass
