import os
import requests

class NeullerResponses:
    def __init__(self, client):
        self._client = client

    def create(self, q: str, content: bool = False):
        try:
            response = self._client.post(
                f"{self._client.base_url}/search",
                json={"q": q, "content": content}
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self._handle_error(e)

    def _handle_error(self, e):
        if e.response is not None:
            try:
                error_data = e.response.json()
                msg = error_data.get('error', e.response.reason)
            except ValueError:
                msg = e.response.text
            raise Exception(f"Neuller API Error ({e.response.status_code}): {msg}")
        raise e

class NeullerContent:
    def __init__(self, client):
        self._client = client

    def retrieve(self, url: str):
        try:
            response = self._client.post(
                f"{self._client.base_url}/search/content",
                json={"url": url}
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self._handle_error(e)

    def _handle_error(self, e):
        if e.response is not None:
            try:
                error_data = e.response.json()
                msg = error_data.get('error', e.response.reason)
            except ValueError:
                msg = e.response.text
            raise Exception(f"Neuller API Error ({e.response.status_code}): {msg}")
        raise e

class Neuller:
    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or os.environ.get("API_KEY")
        if not self.api_key:
            raise ValueError("The Neuller API Key must be provided (either via api_key or the API_KEY environment variable).")
        
        self.base_url = base_url or 'https://api.neuller.com/api/v1'
        
        self.session = requests.Session()
        self.session.headers.update({
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        })
        
        self.post = self.session.post
        
        self.responses = NeullerResponses(self)
        self.content = NeullerContent(self)
