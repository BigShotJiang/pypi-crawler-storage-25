# Neuller: Search Built for AI 🚀

The official Python SDK for the Neuller SearchCloud—a high-performance search engine built specifically for AI agents and LLMs.

## Installation

```sh
pip install neuller
```

## Usage

The primary API for interacting with the Neuller search index is the Responses API. You can generate search results with the code below.

```python
import os
from neuller import Neuller

client = Neuller(
    # This is the default and can be omitted
    api_key=os.environ.get("API_KEY"), 
)

# Fetch Search Results
response = client.responses.create(
    q='who is the ceo of google',
    content=True
)

print(response)
```

### Retrieving Specific Web Content

If you have a specific URL and want to extract its parsed content using the Neuller SearchCloud:

```python
# Fetch URL Content
content_response = client.content.retrieve(
    url='https://en.wikipedia.org/wiki/Search_engine'
)

# In Python, print() will show the full dictionary/nested lists automatically
print(content_response)
```

## Error Handling

If the Neuller API returns an error representing an invalid request (e.g. invalid API key, missing query), standard Python Exceptions will be raised.

```python
try:
    client.responses.create(q='')
except Exception as e:
    print(f"Failed: {e}")
```
