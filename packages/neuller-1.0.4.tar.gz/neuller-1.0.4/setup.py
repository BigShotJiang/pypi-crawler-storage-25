from setuptools import setup, find_packages

setup(
    name='neuller',
    version='1.0.4',
    description='Premium SearchCloud built for AI agents and LLMs',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Neuller',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
)
