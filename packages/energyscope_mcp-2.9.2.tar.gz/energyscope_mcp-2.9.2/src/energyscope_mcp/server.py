"""
EnergyScope MCP Server
======================
MCP server for AI agents to discover, query, and analyse energy market data.
17 tools: 6 data + 11 analytics.

An analyst can ask their AI assistant questions like:
  "What's the latest WTI crude oil price?"
  "Forecast WTI using crude stocks and production as predictors"
  "Are there any regime changes in WTI since 2020?"
  "Is WTI stationary? Run unit root tests."
  "What's the correlation between WTI, Brent, and jet fuel?"
  "Run a Prophet forecast on US crude stocks with US holidays"

The agent uses these tools to search, browse, fetch, and analyse the data.

Register:
    claude mcp add --scope user --transport stdio energyscope -- python "<path>/energyscope_mcp.py"

Requires:
    pip install mcp pyarrow

Env vars:
    ENERGYSCOPE_SERVER  - Flight server address (default: grpc://localhost:8815)
    ENERGYSCOPE_API_KEY - API key for authentication (optional)
"""

import os
import sys
import json
import time
from typing import Optional

import pyarrow as pa
import pyarrow.flight as flight
from mcp.server.fastmcp import FastMCP

from . import __version__ as MCP_VERSION

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SERVER_ADDRESS = os.environ.get("ENERGYSCOPE_SERVER", "grpc://localhost:8815")
API_KEY = os.environ.get("ENERGYSCOPE_API_KEY", "")

def _fetch_instructions() -> str:
    """Fetch instructions from the Flight server. Falls back to a minimal static text on error.

    Server-side instructions live in /opt/energyscope/data/mcp_instructions.md and are
    served via the get_instructions Flight action. This means new datasets / tools
    show up in the agent's catalog as soon as the server is updated — no PyPI release
    needed.
    """
    fallback = (
        f"EnergyScope MCP Server v{MCP_VERSION}. Energy Analytics Flight Server. "
        "1.4M+ time series, server-side analytics, 14 report presets.\n\n"
        f"VERSION: When the user asks which version of energyscope-mcp is running, "
        f"answer 'energyscope-mcp v{MCP_VERSION}'.\n\n"
        "Use the search tool to find series — don't guess IDs. "
        "Use the health tool to see loaded datasets. "
        "Catalog couldn't be fetched from the server (offline?) — call list_datasets() and search() to discover."
    )
    try:
        client = flight.connect(SERVER_ADDRESS)
        if API_KEY:
            token = client.authenticate_basic_token(API_KEY, "")
            opts = flight.FlightCallOptions(headers=[token])
        else:
            opts = None
        result = list(client.do_action(flight.Action("get_instructions", b""), options=opts))
        data = json.loads(result[0].body.to_pybytes().decode())
        text = data.get("instructions", "")
        if text:
            return text.replace("${VERSION}", MCP_VERSION)
    except Exception:
        pass
    return fallback


mcp = FastMCP(
    "energyscope",
    instructions=_fetch_instructions(),
)

# ---------------------------------------------------------------------------
# Flight client (singleton)
# ---------------------------------------------------------------------------

_client = None


def _call_options():
    """Build FlightCallOptions with API key auth header if configured."""
    if API_KEY:
        import base64
        token = base64.b64encode(f"{API_KEY}:".encode()).decode()
        return flight.FlightCallOptions(headers=[(b"authorization", f"Basic {token}".encode())])
    return None


def get_client() -> flight.FlightClient:
    global _client
    if _client is None:
        _client = flight.connect(SERVER_ADDRESS)
    return _client


def sparkline(values, width=20):
    """Generate ASCII sparkline from a list of numbers."""
    if not values or len(values) < 2:
        return ""
    chars = "▁▂▃▄▅▆▇█"
    mn = min(values)
    mx = max(values)
    rng = mx - mn
    if rng == 0:
        return chars[4] * width
    # Sample to width
    step = max(1, len(values) // width)
    sampled = [values[i] for i in range(0, len(values), step)][:width]
    return "".join(chars[min(7, int((v - mn) / rng * 7.99))] for v in sampled)


def do_action(action_type: str, body: str = "") -> dict:
    """Call a Flight action and return parsed JSON response."""
    client = get_client()
    action = flight.Action(action_type, body.encode() if body else b"")
    results = []
    for result in client.do_action(action, options=_call_options()):
        results.append(json.loads(result.body.to_pybytes()))
    return results[0] if len(results) == 1 else results


def do_get(series: list, start: str = None, end: str = None) -> pa.Table:
    """Fetch data via Flight do_get."""
    client = get_client()
    ticket_dict = {"series": series}
    if start:
        ticket_dict["start"] = start
    if end:
        ticket_dict["end"] = end
    ticket = flight.Ticket(json.dumps(ticket_dict).encode())
    reader = client.do_get(ticket, options=_call_options())
    return reader.read_all()


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def search(query: str, limit: int = 20) -> str:
    """Search for energy data series by keyword OR by series-ID prefix.

    KEYWORD MODE (no dot, or has spaces):
      Matches words against series_id, name, and units. Multi-word queries are
      AND-combined. Useful for "crude oil", "gasoline storage PADD 1", etc.

    PREFIX MODE (contains dot, no spaces):
      Returns all series whose series_id starts with the given string.
      Use this to browse a dataset family once you know its prefix.

    Returns series_id, name, frequency (D/W/M/A), and units.

    Examples:
      search("WTI crude oil")                      # keyword
      search("gasoline retail price")              # keyword
      search("FRED.")                              # all FRED series (prefix)
      search("ICE.BRENT")                          # Brent futures curve + dated
      search("CFTC.WTI")                           # WTI positioning (all fields)
      search("PET.WCES")                           # PET crude stock series
    """
    result = do_action("search", query)
    if isinstance(result, list) and len(result) == 0:
        return "No series found. Try broader keywords."

    # Truncate to limit
    if isinstance(result, list):
        result = result[:limit]

    lines = []
    for r in result:
        freq = r.get("f", "?")
        units = r.get("units", "")
        lines.append(f"  {r['series_id']:40s}  {freq}  {units:20s}  {r.get('name', '')}")

    header = f"Found {len(result)} series:\n"
    header += f"  {'Series ID':40s}  F  {'Units':20s}  Name\n"
    header += f"  {'-'*40}  -  {'-'*20}  {'-'*40}\n"
    return header + "\n".join(lines)


@mcp.tool()
def list_series(
    dataset: Optional[str] = None,
    prefix: Optional[str] = None,
    limit: int = 50,
) -> str:
    """List all series IDs in a dataset or matching a prefix. Discovery tool —
    browse what's available without keyword guessing. Feed the results directly
    into correlate_all() or other multi-series tools.

    Args:
        dataset: Dataset name (PET, NG, ICE, SHIP, CFTC, MACRO, OILEQ, GAS, FRED, ECB, etc.)
        prefix: Series ID prefix (e.g. "ICE.BRENT", "CFTC.WTI", "PET.WCES")
        limit: Max results (default 50)

    Examples:
      list_series(dataset="SHIP")              # all shipping series
      list_series(prefix="ICE.BRENT.M")        # all M1-M12 constant-maturity
      list_series(prefix="CFTC.WTI")           # all WTI positioning fields
      list_series(dataset="MACRO")             # all macro indicators
    """
    if dataset is None and prefix is None:
        return "Specify either `dataset` (e.g. 'SHIP') or `prefix` (e.g. 'ICE.BRENT')."
    query = prefix if prefix is not None else f"{dataset.upper()}."
    # Ensure trailing dot for dataset-level browse
    if dataset and not query.endswith("."):
        query = query + "."
    result = do_action("search", query)
    if not isinstance(result, list):
        return "Error: unexpected response"
    if len(result) == 0:
        return f"No series found for {query}"
    result = result[:limit]
    lines = [f"{len(result)} series under '{query}':", ""]
    # Group by frequency for readability
    by_freq = {}
    for r in result:
        by_freq.setdefault(r.get("f", "?"), []).append(r)
    for freq in sorted(by_freq):
        entries = by_freq[freq]
        lines.append(f"── [{freq}] {len(entries)} series ──")
        for r in entries[:30]:
            lines.append(f"  {r['series_id']:42s}  {r.get('units',''):18s}  {r.get('name', '')[:70]}")
        if len(entries) > 30:
            lines.append(f"  ... {len(entries) - 30} more")
        lines.append("")
    return "\n".join(lines)


@mcp.tool()
def upcoming_events(days: int = 14, categories: Optional[list[str]] = None) -> str:
    """Show upcoming energy market catalyst dates — EIA releases, CFTC positioning,
    Fed meetings, etc. — so you can position around them.

    Categories: "EIA" (weekly petroleum/NG, monthly STEO), "CFTC" (weekly COT),
                "API" (weekly stocks), "FED" (FOMC), "OPEC" (monthly report + meetings),
                "IEA" (monthly OMR), "MACRO" (NFP, CPI).
    Default: all categories.

    Args:
        days: Lookahead window (default 14)
        categories: Filter to subset (default all)
    """
    req = {"days": days}
    if categories:
        req["categories"] = categories
    data = do_action("upcoming_events", json.dumps(req))
    events = data.get("events", [])
    if not events:
        return f"No catalysts in the next {days} days."
    lines = [f"Upcoming catalysts (next {days} days, {len(events)} events):", ""]
    for e in events:
        d_out = e.get("days_out", 0)
        if d_out < 1:
            when = f"in {d_out*24:.0f}h"
        else:
            when = f"in {d_out:.0f}d"
        lines.append(f"  {e['date']}  [{e['category']:6s}]  {e['label']}  ({when})")
    return "\n".join(lines)


@mcp.tool()
def save_watchlist(name: str, series_ids: list[str], description: str = "") -> str:
    """Save a named basket of series IDs to reuse across tools.

    Once saved, load with get_watchlist(name) and feed into report(), correlate_all(),
    etc. Useful for recurring workflows (e.g. 'oil_daily', 'gas_dashboard', 'my_refiners').

    Args:
        name: Short identifier (letters/digits/underscore/hyphen)
        series_ids: List of series IDs to save
        description: Optional context
    """
    req = {"action": "save", "name": name, "series_ids": series_ids, "description": description}
    result = do_action("watchlist", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    return f"Saved watchlist '{name}' with {len(series_ids)} series."


@mcp.tool()
def get_watchlist(name: str) -> str:
    """Retrieve a saved watchlist by name. Returns its series IDs + description."""
    result = do_action("watchlist", json.dumps({"action": "get", "name": name}))
    if "error" in result:
        return f"Error: {result['error']}"
    sids = result.get("series_ids", [])
    lines = [f"Watchlist '{name}' ({len(sids)} series)"]
    if result.get("description"):
        lines.append(f"  {result['description']}")
    lines.append(f"  created: {result.get('created_at', '?')}")
    if result.get("updated_at") and result.get("updated_at") != result.get("created_at"):
        lines.append(f"  updated: {result['updated_at']}")
    lines.append("")
    for sid in sids:
        lines.append(f"  {sid}")
    return "\n".join(lines)


@mcp.tool()
def list_watchlists() -> str:
    """List all saved watchlists on the server."""
    result = do_action("watchlist", json.dumps({"action": "list"}))
    if "error" in result:
        return f"Error: {result['error']}"
    lists = result.get("watchlists", [])
    if not lists:
        return "No watchlists saved yet. Use save_watchlist(name, series_ids) to create one."
    lines = [f"{len(lists)} saved watchlist(s):", ""]
    for wl in lists:
        desc = wl.get('description', '')
        desc_display = desc if len(desc) <= 80 else desc[:77] + "..."
        lines.append(f"  {wl['name']:20s}  {wl['count']:>3} series  {desc_display}")
    return "\n".join(lines)


@mcp.tool()
def delete_watchlist(name: str) -> str:
    """Delete a saved watchlist by name."""
    result = do_action("watchlist", json.dumps({"action": "delete", "name": name}))
    if "error" in result:
        return f"Error: {result['error']}"
    return f"Deleted watchlist '{result.get('deleted', name)}'."


@mcp.tool()
def save_report_run(name: str, html: str, snapshot: Optional[dict] = None, prompt: Optional[str] = None) -> str:
    """Save a generated report run with HTML output, key-metric snapshot, and the prompt used.

    Use this AFTER generating a report so the next run can compare against this one and
    narrate what changed. The snapshot should contain key metrics as a flat dict (e.g.
    {"wti": 104.69, "brent": 121.88, "brent_wti_spread": -17.19, "wti_z_score": 2.1}).

    Args:
        name: Report identifier (e.g. "morning", "weekly_eia", "quarterly")
        html: The full HTML report content
        snapshot: Dict of key metrics for diff comparison (optional but recommended)
        prompt: The prompt used to generate the report (optional, for re-running)
    """
    req = {"name": name, "html": html, "snapshot": snapshot or {}, "prompt": prompt or ""}
    result = do_action("save_report_run", json.dumps(req))
    if not result.get("ok"):
        return f"Error: {result.get('error', 'unknown')}"
    return f"Saved report '{result['name']}' at {result['timestamp']} ({result['html_size']:,} bytes)"


@mcp.tool()
def previous_report(name: str, offset: int = 0) -> str:
    """Retrieve a previous report run — HTML, snapshot, prompt, and timestamp.

    Use this BEFORE generating a new report. Read the previous report to understand
    yesterday's emphasis, then narrate what changed in today's report. The snapshot
    is the easy diff target — compare each key metric.

    Args:
        name: Report identifier
        offset: 0 = most recent (default), 1 = second most recent, etc.
    """
    req = {"name": name, "offset": offset}
    result = do_action("get_previous_report", json.dumps(req))
    if not result.get("ok"):
        return f"No previous report: {result.get('error', 'unknown')}"
    snap = result.get("snapshot", {})
    snap_str = json.dumps(snap, indent=2) if snap else "(no snapshot)"
    lines = [
        f"Previous report '{result['name']}' at {result['timestamp']}",
        f"Total runs available: {result['total_runs']}",
        f"HTML size: {result['html_size']:,} bytes",
        "",
        "SNAPSHOT (use this to compute deltas):",
        snap_str,
        "",
        "PROMPT USED:",
        result.get("prompt", "(not stored)"),
        "",
        "HTML CONTENT:",
        result.get("html", ""),
    ]
    return "\n".join(lines)


@mcp.tool()
def compare_runs(name: str, lookback: int = 1, min_pct_change: Optional[float] = None) -> str:
    """Compute structured diff between two report runs (latest vs N-back).

    Returns:
      - Numeric changes (abs + pct delta) and categorical changes (before/after) for keys
      - Added/removed keys (schema evolution)
      - Signal diff: which derived_signals appeared or disappeared between runs
      - Contradiction diff: which contradictions activated or resolved

    The signal/contradiction diff is automatic — both snapshots are passed through
    derived_signals server-side and the active sets are compared. This is the "regime
    shift" detection in one tool call.

    Use this to narrate "what changed" since the last report — feed the diff into your
    new report's "Changes Since Last Brief" section.

    Args:
        name: Report identifier
        lookback: How many runs back to compare against (1 = previous run)
        min_pct_change: Suppress numeric drifts smaller than this percent (e.g. 2.0 hides changes under 2%)
    """
    req = {"name": name, "lookback": lookback}
    if min_pct_change is not None:
        req["min_pct_change"] = min_pct_change
    result = do_action("compare_runs", json.dumps(req))
    if not result.get("ok"):
        return f"Error: {result.get('error', 'unknown')}"

    # Graceful first-run / insufficient-history response
    if result.get("first_run"):
        return (
            f"Report '{result.get('name')}': {result.get('message', 'first run, no diff available yet')}\n"
            f"Runs available: {result.get('runs_available', 0)} (need {result.get('runs_needed', 2)})\n"
            "After the next save_report_run() call, compare_runs() will return a real diff."
        )

    lines = [
        f"Comparing '{result['name']}': {result['curr_timestamp']} vs {result['prev_timestamp']}",
        f"Total keys: {result['total_keys']}  unchanged: {result['unchanged_count']}  changed: {len(result['changed'])}  added: {len(result['added'])}  removed: {len(result['removed'])}",
        "",
    ]
    if result["changed"]:
        lines.append("CHANGED:")
        for c in result["changed"]:
            if c["type"] == "numeric":
                pct = f" ({c['pct_delta']:+.1f}%)" if c.get("pct_delta") is not None else ""
                lines.append(f"  {c['key']}: {c['prev']} → {c['curr']}  Δ{c['abs_delta']:+}{pct}")
            else:
                lines.append(f"  {c['key']}: {c['prev']!r} → {c['curr']!r}")
    if result["added"]:
        lines.append("")
        lines.append(f"ADDED: {', '.join(result['added'])}")
    if result["removed"]:
        lines.append("")
        lines.append(f"REMOVED: {', '.join(result['removed'])}")

    # Signal diff — v2.9.2 shape: each entry is {id, severity, score, theme, ...}
    sig_added = result.get("signals_added", [])
    sig_removed = result.get("signals_removed", [])
    con_added = result.get("contradictions_added", [])
    con_removed = result.get("contradictions_removed", [])
    con_changed = result.get("contradictions_changed", [])
    if sig_added or sig_removed or con_added or con_removed or con_changed:
        lines.append("")
        lines.append("\u2501\u2501\u2501 SIGNAL DIFF (regime shift detection) \u2501\u2501\u2501")

        def _fmt_sig(s):
            # Handle both v1 (bare strings) and v2 (dicts) for back-compat
            if isinstance(s, str):
                return s
            return f"{s['id']} ({s.get('severity','?')}, {s.get('score',0)})"

        if sig_added:
            lines.append("  + Signals activated:")
            for s in sig_added:
                lines.append(f"      {_fmt_sig(s)}")
        if sig_removed:
            lines.append("  - Signals resolved:")
            for s in sig_removed:
                lines.append(f"      {_fmt_sig(s)}")

        def _fmt_con(c):
            if isinstance(c, str):
                return c
            themes = c.get("themes") or []
            theme_tag = ""
            if themes:
                theme_tag = f" [CROSS-THEME: {','.join(themes)}]" if len(themes) > 1 else f" [{themes[0]}]"
            return f"{c['id']} ({c.get('severity','?')}, {c.get('score',0)}){theme_tag}"

        if con_added:
            lines.append("  + Contradictions activated:")
            for c in con_added:
                lines.append(f"      {_fmt_con(c)}")
                if isinstance(c, dict) and c.get("narrative"):
                    lines.append(f"        NARRATIVE: {c['narrative']}")
        if con_removed:
            lines.append("  - Contradictions cleared:")
            for c in con_removed:
                lines.append(f"      {_fmt_con(c)}")
        if con_changed:
            lines.append("  \u26a0 Contradictions score shift (continuing):")
            for c in con_changed:
                arrow = "\u2191" if c["direction"] == "intensifying" else "\u2193"
                themes = c.get("themes") or []
                theme_tag = f" [{','.join(themes)}]" if themes else ""
                lines.append(
                    f"      {arrow} {c['id']}: {c['prev_score']} \u2192 {c['curr_score']} "
                    f"(\u0394{c['score_delta']:+.3f}, {c['prev_severity']} \u2192 {c['curr_severity']}){theme_tag}"
                )
    return "\n".join(lines)


@mcp.tool()
def derived_signals(metrics: Optional[dict] = None, prev_metrics: Optional[dict] = None, schema: bool = False) -> str:
    """Classify a flat metrics dict into named boolean oil-market signals + contradictions (v2).

    Three modes:
      1. Classification (default): pass `metrics` → get back active signals + contradictions
      2. History-aware: pass `metrics` AND `prev_metrics` → get transition-enriched results
         (new_firing / stopped_firing / intensifying / easing / still_firing per signal)
      3. Schema introspection: pass `schema=True` → get back canonical key names per signal,
         the alias map, and contradiction definitions.

    v2 enriched response shape:
      - Each signal: {id, active, score 0-1, severity, basis, explanation, optional history}
      - Each contradiction: {id, active, score (avg of required scores), severity, basis
        (with per-signal breakdown, weakest_link, strongest), explanation (trigger+narrative)}
      - Active signals/contradictions sorted by transition priority (new_firing first),
        then by score descending

    Pass in your snapshot dict (the same one you'd save with save_report_run) and optionally
    the previous run's snapshot to see what changed. Contradictions ARE the headlines — use
    explanation.narrative as your prose anchor and explanation.trigger as the factual receipt.

    Key aliases: snapshots using common variations (bwet_zscore, freight_z, gasoline_pctl, etc.)
    are auto-canonicalized.

    The signal/contradiction logic is server-side — improvements to thresholds and
    contradiction definitions deploy without an MCP update.

    Args:
        metrics: Flat dict of metrics keyed by name (e.g. {"crack_321_z": 4.19, ...})
        prev_metrics: Optional previous snapshot for transition detection. If provided,
            each signal gets a history block showing what it was last run and how it changed.
        schema: If True, return the spec catalog (signals, aliases, contradictions) instead
    """
    if schema:
        result = do_action("derived_signals", json.dumps({"schema": True}))
        if not result.get("ok"):
            return f"Error: {result.get('error', 'unknown')}"
        sch = result.get("schema", {})
        aliases = result.get("aliases", {})
        contras = result.get("contradictions", [])
        lines = [
            f"DERIVED SIGNALS CATALOG ({len(sch)} signals, {len(aliases)} aliases, {len(contras)} contradictions)",
            "",
            "SIGNALS — what keys to populate in your snapshot:",
        ]
        for name, spec in sch.items():
            op = spec["op"]
            if op == "between":
                lines.append(f"  {name}: needs {spec['key']} between [low,high]")
            else:
                th = spec.get("threshold", "?")
                lines.append(f"  {name}: needs {spec['key']} {op} {th}  — {spec.get('desc','')}")
        lines.extend(["", "ALIASES (auto-canonicalized — use any of these as input keys):"])
        for alias, canonical in aliases.items():
            lines.append(f"  {alias} -> {canonical}")
        lines.extend(["", "CONTRADICTIONS (composed from signals — these are your report headlines):"])
        for c in contras:
            req_str = " AND ".join(c.get("requires", []))
            exc_str = c.get("excludes", [])
            line = f"  {c['name']}: requires [{req_str}]"
            if exc_str:
                line += f" excludes [{', '.join(exc_str)}]"
            lines.append(line)
            lines.append(f"    → {c['narrative']}")
        return "\n".join(lines)

    req = {"metrics": metrics or {}}
    if prev_metrics:
        req["prev_metrics"] = prev_metrics
    result = do_action("derived_signals", json.dumps(req))
    if not result.get("ok"):
        return f"Error: {result.get('error', 'unknown')}"

    lines = [
        f"Evaluated {result['signals_evaluated']} signals from {result['metrics_provided']} metrics",
        f"Active: {result['active_count']}",
    ]

    # Theme summary (hottest / coldest) — one-line regime card
    ts = result.get("theme_summary") or {}
    if ts.get("themes_engaged", 0) > 0:
        hot = ts.get("hottest") or {}
        parts = [f"{ts['themes_engaged']}/{ts['themes_total']} themes engaged"]
        if hot:
            parts.append(
                f"hottest: {hot['theme']} ({hot['active_count']}/{hot['evaluated_count']}, avg {hot['avg_score']}, {hot['max_severity']})"
            )
        cold = ts.get("coldest")
        if cold:
            parts.append(
                f"coldest: {cold['theme']} ({cold['active_count']}/{cold['evaluated_count']}, avg {cold['avg_score']}, {cold['max_severity']})"
            )
        lines.append("THEME SUMMARY: " + " · ".join(parts))

    # Transition summary if history was available
    transitions = result.get("transitions")
    if transitions:
        tparts = [f"{k}={v}" for k, v in transitions.items() if v]
        lines.append(f"Transitions: {', '.join(tparts)}")
    lines.append("")

    def _hist_marker(entry):
        hist = entry.get("history") or {}
        if not hist:
            return ""
        transition = hist.get("transition", "")
        delta = hist.get("score_delta", 0)
        if transition == "new_firing":
            return " [NEW]"
        if transition == "intensifying":
            return f" [\u2191 \u0394{delta:+.2f}]"
        if transition == "easing":
            return f" [\u2193 \u0394{delta:+.2f}]"
        if transition == "still_firing":
            return " [cont]"
        return ""

    # Themed rendering — group active signals by theme, sorted by max severity
    by_theme = result.get("by_theme", [])
    if by_theme and result["active"]:
        lines.append("ACTIVE SIGNALS BY THEME (themes sorted by max severity):")
        for t in by_theme:
            if t["active_count"] == 0:
                continue
            theme_name = t["theme"]
            max_sev = t["max_severity"]
            avg = t["avg_active_score"]
            lines.append(f"  [{max_sev}] {theme_name} ({t['active_count']}/{t['evaluated_count']} active, avg {avg})")
            # Sort active signals within a theme by score desc (transition-first is too noisy at section level)
            theme_actives = sorted(
                t["active"],
                key=lambda n: -result["signals"][n]["score"],
            )
            for name in theme_actives:
                sig = result["signals"][name]
                basis = sig["basis"]
                score = sig.get("score", 0)
                severity = sig.get("severity", "")
                if basis.get("op") == "between":
                    th_str = f"in [{basis.get('low')}, {basis.get('high')}]"
                else:
                    th_str = f"{basis['op']} {basis.get('threshold')}"
                trigger = sig.get("explanation", {}).get("trigger", "")
                lines.append(f"    {severity:8s} {name}: {basis['key']}={basis['value']} ({th_str}) score={score}{_hist_marker(sig)}")
                if trigger:
                    lines.append(f"             \u2192 {trigger}")
            lines.append("")
    elif result["active"]:
        # Fallback when server doesn't provide by_theme (older server) — flat list
        lines.append("ACTIVE SIGNALS (sorted by transition priority, then score):")
        for name in result["active"]:
            sig = result["signals"][name]
            basis = sig["basis"]
            score = sig.get("score", 0)
            severity = sig.get("severity", "")
            if basis.get("op") == "between":
                th_str = f"in [{basis.get('low')}, {basis.get('high')}]"
            else:
                th_str = f"{basis['op']} {basis.get('threshold')}"
            trigger = sig.get("explanation", {}).get("trigger", "")
            lines.append(f"  {severity:8s} {name}: {basis['key']}={basis['value']} ({th_str}) score={score}{_hist_marker(sig)}")
            if trigger:
                lines.append(f"           \u2192 {trigger}")

    if result["contradictions"]:
        lines.append("")
        c_count = result.get("contradiction_count", len(result["contradictions"]))
        c_total = result.get("contradiction_total", "?")
        lines.append(f"CONTRADICTIONS ({c_count}/{c_total}) — these ARE your headlines:")
        for c in result["contradictions"]:
            score = c.get("score", 0)
            severity = c.get("severity", "")
            themes = c.get("themes", [])
            theme_tag = ""
            if themes:
                if len(themes) > 1:
                    theme_tag = f" [CROSS-THEME: {','.join(themes)}]"
                else:
                    theme_tag = f" [{themes[0]}]"
            lines.append(f"  \u2605 {severity:8s} {c['id']} (score {score}){_hist_marker(c)}{theme_tag}")
            trigger = c.get("explanation", {}).get("trigger", "")
            narrative = c.get("explanation", {}).get("narrative", "")
            if trigger:
                lines.append(f"    TRIGGER: {trigger}")
            if narrative:
                lines.append(f"    NARRATIVE: {narrative}")

    # Meta-signals — patterns derived from the active set itself
    meta = result.get("meta_signals", {})
    if meta:
        lines.append("")
        lines.append("META-SIGNALS (composition-level patterns):")
        for name, m in meta.items():
            if name == "dominant_lens":
                score = m.get("score", m.get("extremeness_score", "?"))
                sev = m.get("severity", "")
                lines.append(f"  ◆ {name}: {m.get('value')} ({sev}, score {score}) — {m.get('desc','')}")
            elif "active_count" in m:
                lines.append(f"  ◆ {name}: {m.get('active_count')}/{m.get('total_count')} — {m.get('desc','')}")
            else:
                lines.append(f"  ◆ {name}: {m.get('desc','')}")

    skipped = result.get("contradictions_skipped", [])
    if skipped:
        lines.append("")
        lines.append(f"SKIPPED ({len(skipped)}) — add these signals to unlock more headlines:")
        for s in skipped:
            lines.append(f"  ☐ {s['name']}: missing {', '.join(s['missing_signals'])}")
    return "\n".join(lines)


@mcp.tool()
def list_report_runs(name: Optional[str] = None, limit: int = 20) -> str:
    """List saved report runs.

    Without name: shows all reports with run counts.
    With name: shows recent timestamps for that report.

    Args:
        name: Optional report name to filter by
        limit: Max runs to return per report (default 20)
    """
    req = {"limit": limit}
    if name:
        req["name"] = name
    result = do_action("list_report_runs", json.dumps(req))
    if not result.get("ok"):
        return f"Error: {result.get('error', 'unknown')}"
    if name:
        runs = result.get("runs", [])
        if not runs:
            return f"No runs for report '{name}'"
        lines = [f"Report '{name}' — {len(runs)} runs:"]
        for ts in runs:
            lines.append(f"  {ts}")
        return "\n".join(lines)
    reports = result.get("reports", [])
    if not reports:
        return "No saved reports yet. Use save_report_run() after generating a report."
    lines = [f"Saved reports ({len(reports)}):"]
    for r in reports:
        lines.append(f"  {r['name']:30s} {r['runs']:>4} runs  latest: {r['latest']}")
    return "\n".join(lines)


def _resolve_series(series_ids: Optional[list] = None, watchlist: Optional[str] = None) -> list:
    """Accept either an explicit series list OR a watchlist name. Returns list of series IDs."""
    if watchlist:
        r = do_action("watchlist", json.dumps({"action": "get", "name": watchlist}))
        if "error" in r:
            raise ValueError(f"watchlist '{watchlist}' not found")
        return r.get("series_ids", [])
    return series_ids or []


@mcp.tool()
def dataset_info(name: Optional[str] = None) -> str:
    """Fetch the full markdown detail page for a specific dataset.

    Returns the per-dataset reference page (tables, ID structure, flow/product/unit
    codes, use cases, notes). Data is served live from the Flight server so additions
    and corrections are visible immediately — no client release required.

    Call with no name to get the list of available datasets.

    Args:
        name: Dataset name (lowercase, e.g. "eurostat", "pet", "ng", "elec", "cftc",
              "ice", "fred", "ecb", "jodi", "worldbank", "baker_hughes", "ship",
              "intl", "pet_imports", "steo"). Omit to list available datasets.
    """
    try:
        if name is None:
            resp = do_action("dataset_info")
        else:
            resp = do_action("dataset_info", json.dumps({"name": name}))
    except Exception as e:
        return f"Error fetching dataset_info: {e}"

    if isinstance(resp, dict):
        if "markdown" in resp:
            return resp["markdown"]
        if "available" in resp and name is None:
            return "Available datasets:\n  " + "\n  ".join(resp["available"]) + \
                   "\n\nCall dataset_info(name='<dataset>') to get the full detail page."
        if "error" in resp:
            msg = resp["error"]
            if "available" in resp:
                msg += "\n\nAvailable datasets:\n  " + "\n  ".join(resp["available"])
            return msg
    return f"Unexpected response: {resp}"


@mcp.tool()
def key_series(category: Optional[str] = None) -> str:
    """Cheat sheet of the most important series IDs across all datasets.

    Many key series are hard to discover by keyword search — this tool surfaces
    them directly. The full catalog is fetched live from the Flight server
    (hot-deployable) with an in-package fallback if the server action isn't
    available. Categories typically include: crude, crude_grades, crude_imports,
    products, gas, stocks, production, refining, macro, positioning, freight,
    curve, europe_prices, europe_stocks, europe_trade, europe_balance, all.

    Args:
        category: Filter to one category (default: show all)
    """
    cheat: dict
    try:
        resp = do_action("key_series")
        if isinstance(resp, dict) and "categories" in resp:
            cheat = {k: [tuple(row) for row in v] for k, v in resp["categories"].items()}
        else:
            raise RuntimeError("unexpected key_series response shape")
    except Exception:
        cheat = _KEY_SERIES_FALLBACK

    if category and category.lower() != "all":
        cat = category.lower()
        if cat not in cheat:
            return f"Unknown category '{cat}'. Options: {', '.join(cheat.keys())}, all"
        sections = {cat: cheat[cat]}
    else:
        sections = cheat

    lines = ["Key series cheat sheet:"]
    for cat_name, entries in sections.items():
        lines.append(f"\n  {cat_name.upper()}")
        for sid, desc in entries:
            lines.append(f"    {sid:45s}  {desc}")
    lines.append(f"\nUse search(prefix) for full browse: search('PET.WCES'), search('NG.NW2'), search('CFTC.WTI')")
    return "\n".join(lines)


_KEY_SERIES_FALLBACK = {
        "crude": [
            ("PET.RWTC.D",        "WTI Cushing spot (~$100/bbl, daily)"),
            ("PET.RBRTE.D",       "Brent spot (~$120/bbl, daily)"),
            ("ICE.BRENT.M1.D",    "Brent front-month futures (~$95/bbl)"),
            ("ICE.BRENT.M12.D",   "Brent 12-month futures (~$78/bbl, backwardation)"),
            ("FRED.DCOILWTICO",   "WTI via FRED (~$114/bbl, daily)"),
            ("FRED.DCOILBRENTEU", "Brent via FRED (~$128/bbl, daily)"),
        ],
        "crude_grades": [
            ("PET.F003075773.M", "Light Louisiana Sweet (LLS) first purchase (~$62/bbl, monthly)"),
            ("PET.F003075793.M", "Mars Blend first purchase (~$60/bbl, monthly)"),
            ("PET.F003075783.M", "Heavy Louisiana Sweet first purchase (~$60/bbl, monthly)"),
            ("PET.F003048633.M", "West Texas Sour first purchase (~$57/bbl, monthly)"),
            ("PET.F003048623.M", "West Texas Intermediate first purchase (~$60/bbl, monthly)"),
            ("PET.F005071__3.M", "Alaska North Slope first purchase (~$56/bbl, monthly)"),
            ("PET.F005006143.M", "California Midway-Sunset first purchase (~$64/bbl, monthly, series lags 3-6mo)"),
            ("PET.F005006133.M", "California Kern River first purchase (stale — last ~$31/bbl 2020-03, series discontinued?)"),
            ("PET.F004056693.M", "Wyoming Sweet first purchase (~$57/bbl, monthly)"),
        ],
        "crude_imports": [
            ("PET.IMX2810004.M",   "Mexican Mayan FOB cost (~$55/bbl, monthly, typical recent)"),
            ("PET.IMX2830004.M",   "Mexican Olmeca FOB cost (STALE — last ~$80/bbl 2008-10)"),
            ("PET.I19263000004.M", "Canadian Light Sour Blend FOB cost (~$56/bbl, monthly)"),
            ("PET.ICA2410004.M",   "Canadian Lloydminster FOB cost (STALE — last ~$82/bbl 2014-04)"),
            ("PET.INI1410004.M",   "Nigerian Forcados FOB cost (STALE — last ~$60/bbl 2005-12)"),
            ("PET.I42144000004.M", "Nigerian Qua Iboe FOB cost (STALE — last ~$116/bbl 2011-11)"),
            ("PET.I36100000004.M", "Iraqi Basrah Light FOB cost (~$65/bbl, monthly, series lags ~1yr)"),
            ("PET.IAO0300004.M",   "Angolan Cabinda FOB cost (STALE — last ~$59/bbl 2006-12)"),
            ("PET.IEC0500004.M",   "Ecuadorian Oriente FOB cost (STALE — last ~$19/bbl 1996-03)"),
            ("PET.ISA4990008.M",   "Saudi Arabian Light landed cost (~$64/bbl, monthly)"),
            ("PET.ISA6990008.M",   "Saudi Arabian Medium landed cost (~$56/bbl, monthly, series lags ~4yr)"),
            ("PET.IUK4990008.M",   "UK Brent landed cost (STALE — last ~$60/bbl 2005-08)"),
            ("PET.INI1500008.M",   "Nigerian Bonny Light landed cost (STALE — last ~$114/bbl 2011-08)"),
            ("PET.I17628000008.M", "Brazilian Marlim landed cost (STALE — last ~$108/bbl 2012-08)"),
        ],
        "products": [
            ("PET.EER_EPMRU_PF4_RGC_DPG.D",    "Gulf Coast gasoline spot (~$3.40/gal, daily)"),
            ("PET.EER_EPD2DXL0_PF4_RGC_DPG.D", "Gulf Coast ULSD diesel spot (~$4.53/gal, daily)"),
            ("PET.EER_EPD2F_PF4_Y35NY_DPG.D",  "NY Harbor heating oil spot (~$4.35/gal, daily)"),
            ("PET.EER_EPJK_PF4_RGC_DPG.D",     "Gulf Coast jet fuel spot (~$4.24/gal, daily)"),
            ("PET.EER_EPD2DC_PF4_Y05LA_DPG.D", "LA CARB diesel spot (~$5.20/gal, daily)"),
        ],
        "gas": [
            ("NG.RNGWHHD.D",              "Henry Hub natural gas spot (~$3/MMBtu, daily)"),
            ("NG.NW2_EPG0_SWO_R48_BCF.W", "Lower 48 weekly gas storage (~1,880 Bcf, THE Thursday report, range ~1,200–3,800)"),
            ("NG.NW2_EPG0_SWO_R31_BCF.W", "East region gas storage (~300 Bcf, weekly)"),
            ("NG.NW2_EPG0_SWO_R32_BCF.W", "Midwest region gas storage (~375 Bcf, weekly)"),
            ("NG.NW2_EPG0_SWO_R33_BCF.W", "South Central gas storage (~750 Bcf, weekly — largest region, salt+nonsalt)"),
            ("NG.NW2_EPG0_SWO_R34_BCF.W", "Mountain region gas storage (~200 Bcf, weekly)"),
            ("NG.NW2_EPG0_SWO_R35_BCF.W", "Pacific region gas storage (~260 Bcf, weekly)"),
            ("FRED.DHHNGSP",              "Henry Hub via FRED (~$3/MMBtu, daily)"),
        ],
        "stocks": [
            ("PET.WCESTUS1.W",              "US crude oil stocks (~460K kb, weekly EIA, excl. SPR — range ~380–530K)"),
            ("PET.WGTSTUS1.W",              "US gasoline stocks (~240K kb, weekly — seasonal range ~210–260K)"),
            ("PET.WDISTUS1.W",              "US distillate stocks (~118K kb, weekly — seasonal range ~105–155K)"),
            ("PET.WCSSTUS1.W",              "SPR crude stocks (~415K kb, weekly — peaked ~695K in 2009, drawn during 2022 release)"),
            ("PET.W_EPC0_SAX_YCUOK_MBBL.W", "Cushing OK crude stocks (~31K kb, weekly — WTI delivery point, range ~20–60K)"),
        ],
        "production": [
            ("PET.WCRFPUS2.W", "US crude production (~13,660 kb/d, weekly — record highs near 13,800)"),
            ("PET.MCRFPUS2.M", "US crude production (~13,250 kb/d, monthly)"),
            ("PET.WCRIMUS2.W", "US crude imports (~6,450 kb/d, weekly)"),
            ("PET.WCREXUS2.W", "US crude exports (~3,520 kb/d, weekly — pre-2015 ban ~0)"),
        ],
        "refining": [
            ("PET.WPULEUS3.W",         "US refinery utilization % (~92.1%, weekly — healthy >90%, weak <85%)"),
            ("PET.WCRRIUS2.W",         "US refinery crude input (~16,380 kb/d, weekly)"),
            ("PET.W_NA_YUP_R30_PER.W", "Gulf Coast (PADD 3) utilization % (~97.4%, weekly — largest refining region, Texas+Louisiana)"),
        ],
        "macro": [
            ("MACRO.GSPC.D",     "S&P 500 index (~6,800, daily)"),
            ("MACRO.VIX.D",      "VIX volatility index (~19, daily — low <15, elevated >25, crisis >40)"),
            ("MACRO.TNX.D",      "US 10-Year Treasury yield (~4.3%, daily)"),
            ("MACRO.DX_Y_NYB.D", "US Dollar Index (DXY, ~98.7, daily)"),
            ("MACRO.GCF.D",      "Gold futures COMEX (~$4,790/oz, daily)"),
            ("MACRO.HGF.D",      "Copper futures COMEX (~$5.90/lb, daily)"),
            ("FRED.CPIENGNS",    "CPI Energy not seasonally adjusted (monthly, index ~300, series may lag)"),
            ("FRED.INDPRO",      "Industrial Production Index (~102.6, monthly, 2017=100 base)"),
            ("ECB.USD.D",        "EUR/USD exchange rate (~1.17, daily)"),
        ],
        "positioning": [
            ("CFTC.WTI.MM_Net",   "WTI managed money net (~+80K contracts, weekly — long bias, range -150K to +450K)"),
            ("CFTC.BRENT.MM_Net", "Brent managed money net (~-36K contracts, weekly — currently net short)"),
            ("CFTC.WTI.OI",       "WTI open interest (~2.04M contracts, weekly)"),
            ("CFTC.NG.MM_Net",    "Natural gas managed money net (~-86K contracts, weekly — typically structurally short)"),
        ],
        "freight": [
            ("SHIP.BWET.D", "Breakwave Tanker Shipping ETF (~$163, daily — tracks tanker freight futures, best free BDTI proxy)"),
            ("SHIP.BDRY.D", "Breakwave Dry Bulk ETF (~$10.70, daily — context for tanker vs dry bulk)"),
            ("SHIP.FRO.D",  "Frontline VLCC operator (~$34, daily, equity)"),
            ("SHIP.DHT.D",  "DHT Holdings VLCC operator (~$17, daily, equity)"),
        ],
        "curve": [
            ("ICE.BRENT.M1.D",  "Brent M1 (front month, ~$95)"),
            ("ICE.BRENT.M2.D",  "Brent M2 (~$90)"),
            ("ICE.BRENT.M6.D",  "Brent M6 (~$82)"),
            ("ICE.BRENT.M12.D", "Brent M12 (~$78 — current curve steeply backwardated: M1-M12 ~$17)"),
        ],
        "europe_prices": [
            ("EUROSTAT.nrg_pc_204.DE.EUR.S.KWH1000-2499.E7000.I_TAX.KWH",   "Germany electricity price — domestic, incl. tax (~€0.44/kWh, semi-annual — up from €0.34 pre-crisis)"),
            ("EUROSTAT.nrg_pc_205.DE.EUR.S.MWH20-499.E7000.I_TAX.KWH",      "Germany electricity price — industrial, incl. tax (~€0.31/kWh, semi-annual — demand destruction metric)"),
            ("EUROSTAT.nrg_pc_202.DE.EUR.S.GJ20-199.G3000.I_TAX.GJ_GCV",    "Germany gas price — domestic, incl. tax (~€34/GJ, semi-annual)"),
            ("EUROSTAT.nrg_pc_203.DE.EUR.S.GJ1000-9999.G3000.I_TAX.GJ_GCV", "Germany gas price — industrial, incl. tax (~€28/GJ, semi-annual)"),
            ("EUROSTAT.nrg_pc_204.FR.EUR.S.KWH1000-2499.E7000.I_TAX.KWH",   "France electricity price — domestic, incl. tax (~€0.30/kWh, semi-annual)"),
            ("EUROSTAT.nrg_pc_205.FR.EUR.S.MWH20-499.E7000.I_TAX.KWH",      "France electricity price — industrial, incl. tax (~€0.23/kWh, semi-annual — cheaper than DE, nuclear mix)"),
        ],
        "europe_stocks": [
            ("EUROSTAT.nrg_stk_oil.EU27_2020.A.O4000.STKCL_NAT.THS_T",  "EU27 oil stocks — national territory, closing (~154K kt, annual)"),
            ("EUROSTAT.nrg_stk_oil.DE.A.O4000.STKCL_NAT.THS_T",         "Germany oil stocks — national territory, closing (~35K kt, annual)"),
            ("EUROSTAT.nrg_stk_oil.NL.A.O4000.STKCL_NAT.THS_T",         "Netherlands oil stocks — national territory, closing (~14K kt, annual)"),
            ("EUROSTAT.nrg_stk_gas.EU27_2020.A.G3000.STKCL_NAT.MIO_M3", "EU27 gas stocks — national territory, closing (~80K million m³, annual)"),
            ("EUROSTAT.nrg_stk_gas.DE.A.G3000.STKCL_NAT.MIO_M3",        "Germany gas stocks — national territory, closing (~18K million m³, annual)"),
            ("EUROSTAT.nrg_stk_gas.NL.A.G3000.STKCL_NAT.MIO_M3",        "Netherlands gas stocks — national territory, closing (~9K million m³, annual)"),
        ],
        "europe_trade": [
            ("EUROSTAT.nrg_ti_oil.EU27_2020.A.TOTAL.O4000.THS_T",  "EU27 oil imports — all origins, all products (~793K kt, annual)"),
            ("EUROSTAT.nrg_ti_oil.DE.A.TOTAL.O4000.THS_T",         "Germany oil imports — all origins (~118K kt, annual)"),
            ("EUROSTAT.nrg_ti_oil.NL.A.TOTAL.O4000.THS_T",         "Netherlands oil imports — all origins (~138K kt, Rotterdam hub, annual)"),
            ("EUROSTAT.nrg_ti_oil.EU27_2020.A.US.O4000.THS_T",     "EU27 oil imports from United States (~97K kt, annual — largest single origin since sanctions)"),
            ("EUROSTAT.nrg_ti_oil.EU27_2020.A.NO.O4000.THS_T",     "EU27 oil imports from Norway (~72K kt, annual)"),
            ("EUROSTAT.nrg_te_oil.EU27_2020.A.TOTAL.O4000.THS_T",  "EU27 oil exports — all destinations, all products (~313K kt, annual)"),
            ("EUROSTAT.nrg_ti_gas.EU27_2020.A.TOTAL.G3000.MIO_M3", "EU27 gas imports — all origins (~330K million m³, annual)"),
            ("EUROSTAT.nrg_ti_gas.EU27_2020.A.TOTAL.G3000.TJ_GCV", "EU27 gas imports — all origins (~12.8M TJ GCV, annual, energy units)"),
            ("EUROSTAT.nrg_te_gas.EU27_2020.A.TOTAL.G3000.TJ_GCV", "EU27 gas exports — all destinations (~2.0M TJ GCV, annual)"),
        ],
        "europe_balance": [
            ("EUROSTAT.nrg_ind_ren.DE.A.REN.PC",        "Germany renewable share of gross final consumption (~22.5%, annual — up from ~15% in 2015)"),
            ("EUROSTAT.nrg_ind_ren.EU27_2020.A.REN.PC", "EU27 renewable share of gross final consumption (~25.2%, annual — up from ~17.8% in 2015)"),
            ("EUROSTAT.nrg_ind_ren.FR.A.REN.PC",        "France renewable share of gross final consumption (~23.2%, annual)"),
            ("EUROSTAT.nrg_ind_ren.ES.A.REN.PC",        "Spain renewable share of gross final consumption (~25.4%, annual)"),
        ],
}


@mcp.tool()
def get_data(
    series_ids: Optional[list[str]] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
    watchlist: Optional[str] = None,
) -> str:
    """Fetch time series data for one or more series.

    Args:
        series_ids: List of series IDs (e.g. ["PET.RWTC.D", "PET.RBRTE.D"])
        start: Start date YYYY-MM-DD (optional, defaults to all history)
        end: End date YYYY-MM-DD (optional, defaults to latest)
        watchlist: Name of a saved watchlist (alternative to series_ids)

    Returns data as a table with columns: series_id, period, value.

    Examples:
      get_data(["PET.RWTC.D"], "2024-01-01", "2024-12-31")
      get_data(["PET.RWTC.D", "PET.RBRTE.D"], "2020-01-01")
      get_data(watchlist="oil_daily")
    """
    try:
        series_ids = _resolve_series(series_ids, watchlist)
    except ValueError as e:
        return f"Error: {e}"
    if not series_ids:
        return "Error: provide series_ids or watchlist"
    table = do_get(series_ids, start, end)

    if table.num_rows == 0:
        return "No data found for the given series and date range."

    # Format as readable table
    lines = [f"{'Series ID':40s}  {'Period':12s}  {'Value':>12s}"]
    lines.append(f"{'-'*40}  {'-'*12}  {'-'*12}")

    sid_col = table.column("series_id")
    period_col = table.column("period")
    value_col = table.column("value")

    for i in range(min(table.num_rows, 500)):  # cap at 500 rows
        sid = sid_col[i].as_py()
        period = period_col[i].as_py()
        value = value_col[i].as_py()
        val_str = f"{value:>12.4f}" if value is not None else f"{'N/A':>12s}"
        lines.append(f"{sid:40s}  {period:12s}  {val_str}")

    result = f"{table.num_rows} rows returned.\n\n" + "\n".join(lines)
    if table.num_rows > 500:
        result += f"\n\n... (showing first 500 of {table.num_rows} rows)"
    return result


@mcp.tool()
def latest(
    series_ids: Optional[list[str]] = None,
    include_coverage: bool = False,
    watchlist: Optional[str] = None,
) -> str:
    """Get the latest (most recent) value for one or more series.

    Faster than get_data — returns just the last known data point per series,
    plus the series name and units.

    Args:
        series_ids: List of series IDs
        include_coverage: If True, also return the full date coverage
            (first_period → latest period + total data points). Slightly slower
            as it scans year partitions. Use when you need to know how far
            back the series goes.
        watchlist: Use a saved watchlist (alternative to series_ids)

    Examples:
      latest(["PET.RWTC.D"])  # Latest WTI crude oil price
      latest(["PET.RWTC.D", "PET.RBRTE.D"])  # Latest WTI and Brent
      latest(watchlist="oil_daily")  # Latest for all watchlist series
    """
    try:
        series_ids = _resolve_series(series_ids, watchlist)
    except ValueError as e:
        return f"Error: {e}"
    if not series_ids:
        return "Error: provide series_ids or watchlist"
    result = do_action("latest", json.dumps({"series": series_ids, "include_coverage": include_coverage}))

    lines = []
    for r in result:
        if "error" in r:
            lines.append(f"  {r['series_id']}: {r['error']}")
        else:
            val = r.get("value")
            val_str = f"{val:.4f}" if val is not None else "N/A"
            freq = r.get("frequency", "")
            date_range = ""
            if r.get("first_period"):
                date_range = f"{r['first_period']}–{r.get('period', '?')}"
            elif r.get("first_year"):
                date_range = f"{r['first_year']}–{r.get('last_year', '?')}"
            pts = r.get("data_points", "")
            meta = f" [{freq}]" if freq else ""
            meta += f" {date_range}" if date_range else ""
            meta += f" ({pts:,} pts)" if pts else ""
            lines.append(
                f"  {r['series_id']:40s}  {r.get('period', '?'):12s}  "
                f"{val_str:>12s}  {r.get('units', ''):20s}  {r.get('name', '')}{meta}"
            )

    header = f"  {'Series ID':40s}  {'Period':12s}  {'Value':>12s}  {'Units':20s}  Name\n"
    header += f"  {'-'*40}  {'-'*12}  {'-'*12}  {'-'*20}  {'-'*30}\n"
    return header + "\n".join(lines)


@mcp.tool()
def browse(category_id: Optional[int] = None) -> str:
    """Browse the EIA data category tree.

    Call with no arguments to see top-level categories.
    Call with a category_id to see its children and series.

    Use this to explore what data is available when you don't know
    the exact series ID.

    Examples:
      browse()             # Top-level categories (Petroleum, Natural Gas, etc.)
      browse(714755)       # Children of a specific category
    """
    body = json.dumps({"id": category_id}) if category_id else "{}"
    result = do_action("browse", body)

    if isinstance(result, list):
        # Top-level categories
        lines = ["Top-level categories:\n"]
        for cat in result:
            children = cat.get("children", 0)
            series = cat.get("series", 0)
            lines.append(f"  [{cat['id']}] {cat['name']}  ({children} subcategories, {series} series)")
        return "\n".join(lines)
    else:
        # Category detail
        lines = [f"Category: {result['name']} (id={result['id']})\n"]

        children = result.get("children", [])
        if children:
            lines.append(f"Subcategories ({len(children)}):")
            for cat in children:
                c = cat.get("children", 0)
                s = cat.get("series", 0)
                lines.append(f"  [{cat['id']}] {cat['name']}  ({c} subcategories, {s} series)")

        series = result.get("series", [])
        if series:
            lines.append(f"\nSeries ({len(series)}):")
            for s in series[:50]:  # cap display
                lines.append(f"  {s['series_id']:40s}  {s.get('f', '?')}  {s.get('units', ''):20s}  {s.get('name', '')}")
            if len(series) > 50:
                lines.append(f"  ... and {len(series) - 50} more")

        return "\n".join(lines)


@mcp.tool()
def datasets() -> str:
    """List available datasets and their status (loaded, rows, series count).

    Shows what data is currently available on the server.
    """
    result = do_action("list_datasets")

    lines = [f"{'Name':10s}  {'Status':10s}  {'Rows':>12s}  {'Series':>10s}"]
    lines.append(f"{'-'*10}  {'-'*10}  {'-'*12}  {'-'*10}")

    for ds in result:
        status = "loaded" if ds.get("loaded") else "available"
        rows = f"{ds.get('rows', 0):>12,}" if ds.get("loaded") else f"{'—':>12s}"
        series = f"{ds.get('series', 0):>10,}" if ds.get("loaded") else f"{'—':>10s}"
        lines.append(f"{ds['name']:10s}  {status:10s}  {rows}  {series}")

    return "\n".join(lines)


@mcp.tool()
def feedback(
    message: str,
    category: str = "general",
    context: str = "",
    user: str = "anonymous",
) -> str:
    """Submit feedback, bug report, or feature request to the EnergyScope team.

    Use this whenever you encounter an issue, have a suggestion, or want to flag
    something for improvement. Messages are written to a central feedback log on
    the server and the team is notified immediately.

    Args:
        message: The feedback text (what's wrong / what would help / what you tried).
        category: One of "bug", "feature", "data-gap", "ux", "question", "general".
        context: Optional context — tool name, series IDs, error message, etc.
        user: Identifier for who you are (e.g. "analyst-1", "david"). Optional.
    """
    try:
        result = do_action("feedback", json.dumps({
            "message": message,
            "category": category,
            "context": context,
            "user": user,
            "client_version": f"mcp-{MCP_VERSION}",
        }))
        return f"Feedback submitted at {result.get('ts', '?')} (category: {result.get('category', '?')}). Thank you!"
    except Exception as e:
        return f"Could not submit feedback: {e}"


@mcp.tool()
def health() -> str:
    """Check server health and connection status. Also reports MCP client version
    and whether a newer version is available on PyPI."""
    lines = [f"MCP client: energyscope-mcp v{MCP_VERSION}"]
    # Check for updates (best-effort, non-blocking)
    try:
        releases = do_action("mcp_releases")
        if isinstance(releases, dict) and "latest" in releases:
            latest = releases["latest"]
            if _version_cmp(latest, MCP_VERSION) > 0:
                lines.append(f"⬆ UPDATE AVAILABLE: v{latest} — run check_for_updates() for details")
            else:
                lines.append(f"✓ up to date (PyPI latest: v{latest})")
    except Exception:
        pass
    try:
        result = do_action("healthcheck")
        lines.append(f"Status: {result.get('status', '?')}")
        lines.append(f"Series: {result.get('series_count', 0):,}")
        lines.append(f"Rows: {result.get('data_rows', 0):,}")
        lines.append(f"Server: {SERVER_ADDRESS}")
        return "\n".join(lines)
    except Exception as e:
        lines.append(f"Connection failed: {e}")
        lines.append(f"Server: {SERVER_ADDRESS}")
        return "\n".join(lines)


def _version_cmp(a: str, b: str) -> int:
    """Compare semver-ish versions. Returns -1, 0, 1 like cmp."""
    def parts(v):
        return tuple(int(x) for x in v.split(".") if x.isdigit())
    pa, pb = parts(a), parts(b)
    return (pa > pb) - (pa < pb)


@mcp.tool()
def check_for_updates() -> str:
    """Check whether a newer version of energyscope-mcp is available.

    Compares the installed client version to the latest release on the server.
    Shows how many releases behind you are and how to upgrade.
    """
    try:
        releases = do_action("mcp_releases")
    except Exception as e:
        return f"Could not reach release feed: {e}"

    if not isinstance(releases, dict) or "latest" in releases and "error" in releases:
        return f"Server error: {releases.get('error', 'unknown')}"

    latest = releases.get("latest", "?")
    cmp = _version_cmp(latest, MCP_VERSION)

    lines = [f"Installed: energyscope-mcp v{MCP_VERSION}"]
    lines.append(f"Latest:    v{latest}")

    if cmp <= 0:
        lines.append("")
        lines.append("✓ You are up to date.")
        return "\n".join(lines)

    # List semver releases between installed and latest (skip server-* hot-deploy entries)
    new_releases = [r for r in releases.get("releases", [])
                    if not str(r.get("version", "")).startswith("server-")
                    and _version_cmp(r.get("version", "0.0.0"), MCP_VERSION) > 0]
    lines.append("")
    lines.append(f"⬆ {len(new_releases)} release(s) behind — call whats_new() for the changelog")
    lines.append("")
    lines.append("To update (uvx users — default install path):")
    instr = releases.get("update_instructions", {})
    for cmd in instr.get("uvx", ["uv cache prune", "# then restart Claude Code / run /mcp"]):
        lines.append(f"  {cmd}")
    lines.append("")
    lines.append("Alternative (force refresh without purging uvx cache):")
    for cmd in instr.get("uvx_alt", ["uvx --refresh energyscope-mcp"]):
        lines.append(f"  {cmd}")
    lines.append("")
    lines.append("Pip-installed users:")
    for cmd in instr.get("pip", ["pip install --upgrade energyscope-mcp"]):
        lines.append(f"  {cmd}")
    return "\n".join(lines)


@mcp.tool()
def whats_new(since: Optional[str] = None, limit: int = 5) -> str:
    """Show the changelog for recent releases of energyscope-mcp.

    Useful after updating, or to see what's in a version you don't yet have.

    Args:
        since: Show releases strictly newer than this version (default: your installed version)
        limit: Max number of releases to show (default 5)
    """
    try:
        releases = do_action("mcp_releases")
    except Exception as e:
        return f"Could not reach release feed: {e}"

    if not isinstance(releases, dict):
        return "No release feed available."

    since_ver = since if since is not None else MCP_VERSION

    # Server-side hot-deploy entries (e.g. "server-2026-04-10") are always surfaced —
    # they're not semver releases but represent live changes to the Flight server that
    # the agent should know about. Pinned to the top of the list, marked distinctly.
    all_rels = releases.get("releases", [])
    server_rels = [r for r in all_rels if str(r.get("version", "")).startswith("server-")]
    semver_rels = [r for r in all_rels
                   if not str(r.get("version", "")).startswith("server-")
                   and _version_cmp(r.get("version", "0.0.0"), since_ver) > 0]
    rels = (server_rels + semver_rels)[:limit]

    if not rels:
        return f"No releases newer than v{since_ver}. You're on the current release."

    lines = [f"Changes since v{since_ver}:"]
    for r in rels:
        lines.append("")
        ver = r.get("version", "?")
        marker = "🔧 SERVER-SIDE" if str(ver).startswith("server-") else f"v{ver}"
        lines.append(f"━━ {marker} ({r.get('date', '?')}) — {r.get('title', '')}")
        for change in r.get("changes", []):
            lines.append(f"  • {change}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Analytics Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def forecast(
    series_ids: list[str],
    target: str,
    horizon: int = 12,
    method: str = "xgboost",
    engine: str = "both",
    pinned: Optional[dict] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
    backtest: bool = False,
    backtest_splits: int = 10,
) -> str:
    """Multi-factor forecast using XGBoost/ElasticNet/Ridge/OLS regression.
    Auto-forecasts predictor series with ARIMA and/or Prophet.
    Use pinned to fix predictor values for scenario analysis.

    Args:
        series_ids: All series (target + predictors), e.g. ["PET.RWTC.D", "PET.WCESTUS1.W"]
        target: The series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        method: xgboost (default), elasticnet, ridge, ols
        engine: Predictor engine — both (default), arima, prophet
        pinned: Fix predictors at specific values for scenarios, e.g. {"PET.WCRFPUS2.W": 13660}
        start: Start date for training (YYYY-MM-DD)
        end: End date for training
        backtest: If True, also run rolling-origin out-of-sample evaluation. Returns
            honest RMSE, MAE, bias, MAPE, and skill vs naive persistence baseline.
        backtest_splits: Number of rolling cutoffs for backtest (default 10).
    """
    req = {"series": series_ids, "target": target, "horizon": horizon,
           "method": method, "predictor_engine": engine,
           "backtest": backtest, "backtest_splits": backtest_splits}
    if pinned: req["pinned"] = pinned
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("forecast", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    r_sq = result.get('r_squared', 0)
    lines = [f"ES.Forecast: {target} (R²={r_sq:.3f}, method={method}, engine={engine})"]
    lines.append(f"Observations: {result.get('observations', 0)}")
    # Warning: high in-sample R² without backtest is a classic overfitting trap
    if r_sq > 0.9 and not backtest:
        lines.append("")
        lines.append(f"⚠ WARNING: in-sample R²={r_sq:.3f} is high. Without out-of-sample validation")
        lines.append(f"  this number may be overfit. Re-run with backtest=True to verify honest skill.")
        lines.append(f"  In-sample R² is NOT a reliable forecast-quality metric.")
    lines.append("")
    for c in result.get("coefficients", []):
        sel = " *" if c.get("selected") else ""
        lines.append(f"  {c['series']}: {c['coefficient']:.4f}{sel}")
    lines.append("")
    lines.append("Forecast:")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")

    if "forecast_comparison" in result:
        lines.append("")
        lines.append("Comparison (ARIMA vs Prophet predictor engines):")
        for eng, fcs in result["forecast_comparison"].items():
            vals = ", ".join([f"${f['forecast']:.2f}" for f in fcs[:3]])
            lines.append(f"  {eng}: {vals}...")

    bt = result.get("backtest")
    if bt:
        lines.append("")
        lines.append(f"Backtest ({bt['method']}, {bt['splits']} splits):")
        lines.append(
            f"  RMSE: {bt['rmse']:.3f}   MAE: {bt['mae']:.3f}   "
            f"bias: {bt['bias']:+.3f}   MAPE: {bt.get('mape_pct', 0) or 0:.1f}%"
        )
        if bt.get('naive_rmse') is not None:
            sk = bt.get('skill_vs_naive') or 0
            lines.append(
                f"  Naive baseline RMSE: {bt['naive_rmse']:.3f}   "
                f"skill vs naive: {sk*100:+.1f}%{_skill_tag(sk)}"
            )

    return "\n".join(lines)


@mcp.tool()
def arima(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Univariate auto-ARIMA forecast with confidence intervals.

    Args:
        series_id: Series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("arima", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"ARIMA{tuple(result.get('order', []))} (AIC={result.get('aic', 0):.1f})"]
    lines.append("")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def prophet(
    series_id: str,
    horizon: int = 12,
    holidays: Optional[str] = None,
    seasonality: str = "additive",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Facebook Prophet forecast with holidays and seasonality.

    Args:
        series_id: Series to forecast, e.g. "PET.WCESTUS1.W"
        horizon: Periods ahead (default 12)
        holidays: Country code for holidays (US, UK, DE, FR)
        seasonality: additive (default) or multiplicative
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon, "seasonality_mode": seasonality}
    if holidays: req["country_holidays"] = holidays
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("prophet", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Prophet forecast ({result.get('frequency', '?')})"]
    if result.get("changepoints"):
        lines.append(f"Changepoints: {', '.join(result['changepoints'][-5:])}")
    lines.append("")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def theta(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
    backtest: bool = False,
    backtest_n: int = 10,
) -> str:
    """Theta method forecast — M3 competition winner. Fast, robust benchmark.

    Args:
        series_id: Series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
        backtest: Run 1-step rolling-origin skill check on last N points vs naive (default False)
        backtest_n: How many backtest splits (default 10)
    """
    req = {"series": series_id, "horizon": horizon, "backtest": backtest, "backtest_n": backtest_n}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("theta", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Theta forecast ({result.get('observations', 0)} obs)"]
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    bt = result.get("backtest")
    if bt:
        skill = bt.get("skill_vs_naive")
        tag = _skill_tag(skill)
        skill_str = f"{skill*100:+.1f}%" if skill is not None else "n/a"
        lines.append(f"Backtest ({bt['splits']} 1-step splits): RMSE={bt['rmse']:.2f} naive={bt['naive_rmse']:.2f} skill={skill_str}{tag}")
    return "\n".join(lines)


def _skill_tag(skill):
    """Return a visual tag for skill-vs-naive: ⚠ below naive / ≈ naive / ★ useful."""
    if skill is None:
        return ""
    if skill < -0.05:
        return " ⚠ BELOW NAIVE"
    if skill < 0.02:
        return " ≈ naive"
    if skill < 0.10:
        return " ✓ marginal"
    return " ★ useful"


@mcp.tool()
def forecast_ensemble(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Run ARIMA + Prophet + Theta on the same series and compare.

    Forecast ensemble spread is itself a signal: when methods agree, confidence
    is higher; when they disagree the uncertainty IS the finding. Shows each
    method's forecast for periods h=1,3,6,12 alongside min/median/max across methods.

    Args:
        series_id: Series to forecast
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    base_req = {"series": series_id, "horizon": horizon}
    if start: base_req["start"] = start
    if end: base_req["end"] = end

    engines = []
    for name, action_name, extra in [
        ("theta", "theta", {}),
        ("arima", "arima", {}),
        ("prophet", "prophet", {}),
    ]:
        req = dict(base_req)
        req.update(extra)
        try:
            r = do_action(action_name, json.dumps(req))
            if "error" not in r:
                engines.append((name, r.get("forecast", [])))
        except Exception:
            pass

    if not engines:
        return "Error: no engines returned a forecast"

    # Index forecasts by horizon position
    # Use the shortest forecast length across engines for alignment
    min_h = min(len(fc) for _, fc in engines)
    if min_h == 0:
        return "Error: engines returned empty forecasts"
    horizons_to_show = sorted(set([h for h in (1, 3, 6, 12) if h <= min_h] + [min_h]))

    lines = [f"forecast_ensemble({series_id}, horizon={horizon})"]
    lines.append(f"{'h':>3s}  {'period':10s}  " + "  ".join(f"{n:>10s}" for n, _ in engines) + "  " + f"{'min':>10s}  {'med':>10s}  {'max':>10s}  {'spread':>8s}")
    for h in horizons_to_show:
        i = h - 1
        vals = [fc[i]["forecast"] for _, fc in engines if i < len(fc)]
        if not vals:
            continue
        period = engines[0][1][i].get("period", "?")
        mn, mx = min(vals), max(vals)
        med = sorted(vals)[len(vals) // 2]
        spread = mx - mn
        row_vals = "  ".join(f"{v:>10.2f}" for v in vals)
        lines.append(f"{h:>3d}  {period:10s}  {row_vals}  {mn:>10.2f}  {med:>10.2f}  {mx:>10.2f}  {spread:>8.2f}")

    # Signal interpretation based on disagreement at final horizon
    final_h = horizons_to_show[-1]
    final_vals = [fc[final_h - 1]["forecast"] for _, fc in engines if final_h - 1 < len(fc)]
    if len(final_vals) >= 2:
        mn, mx = min(final_vals), max(final_vals)
        med = sorted(final_vals)[len(final_vals) // 2]
        spread_abs = mx - mn
        half_spread = spread_abs / 2.0
        mean = sum(final_vals) / len(final_vals)
        spread_pct = spread_abs / mean * 100 if mean else 0
        # Consensus + uncertainty single-line summary (analyst feedback)
        lines.append("")
        lines.append(
            f"  CONSENSUS h={final_h}: {med:.2f} ± {half_spread:.2f}  "
            f"(range {mn:.2f}–{mx:.2f}, spread {spread_pct:.1f}%)"
        )
        if spread_pct < 5:
            lines.append(f"  Models AGREE — higher confidence")
        elif spread_pct < 20:
            lines.append(f"  Models MODERATELY DISAGREE")
        else:
            lines.append(f"  Models DISAGREE — high uncertainty, the disagreement IS the finding")
    return "\n".join(lines)


@mcp.tool()
def breakpoints(
    series_id: str,
    min_shift: float = 0,
    start: Optional[str] = None,
    end: Optional[str] = None,
    annotate: bool = False,
    event_window_days: int = 14,
) -> str:
    """Detect structural breaks / regime changes in a series.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        min_shift: Minimum shift magnitude to include (e.g. 5 for $5+)
        start: Start date (YYYY-MM-DD)
        end: End date
        annotate: If True, cross-reference each breakpoint with bundled energy
            market events (OPEC cuts, Russia invasion, COVID, Fed hikes, etc.).
            Attaches the nearest event within event_window_days to each breakpoint.
        event_window_days: Max days between breakpoint and event to count (default 14)
    """
    req = {"series": series_id}
    if min_shift > 0: req["min_shift"] = min_shift
    if start: req["start"] = start
    if end: req["end"] = end
    if annotate:
        req["annotate"] = True
        req["event_window_days"] = event_window_days
    result = do_action("breakpoints", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"{result.get('n_breakpoints', 0)} breakpoints detected:"]
    for bp in result.get("breakpoints", []):
        shift = bp.get("shift", 0)
        line = f"  {bp['period']}: {'+' if shift > 0 else ''}{shift:.1f}  (before: {bp.get('mean_before', 0):.1f} → after: {bp.get('mean_after', 0):.1f})"
        ev = bp.get("event")
        if ev:
            line += f"  ← {ev['label']} ({ev['date']}, {ev['days_away']}d away, {ev['category']})"
        lines.append(line)
    return "\n".join(lines)


@mcp.tool()
def stats(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Descriptive statistics for a series.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("stats", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Stats for {series_id}:"]
    for key in ["count", "mean", "median", "std", "min", "max", "skewness", "kurtosis",
                "p5", "p25", "p75", "p95", "first_date", "last_date", "pct_change"]:
        val = result.get(key)
        if val is not None:
            lines.append(f"  {key}: {val}")
    return "\n".join(lines)


@mcp.tool()
def volatility(
    series_id: str,
    window: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Rolling + GARCH(1,1) conditional volatility, annualised.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        window: Rolling window (default 20)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("volatility", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    current = result.get("current", {})
    lines = [f"Volatility for {series_id}:"]
    lines.append(f"  Rolling vol ({window}): {current.get('rolling_vol', 0):.4f}")
    if "garch_vol" in current:
        lines.append(f"  GARCH vol: {current.get('garch_vol', 0):.4f}")
    lines.append(f"  Frequency: {current.get('frequency', '?')}")
    lines.append(f"  Annualised factor: {current.get('annualised_factor', 0)}")
    return "\n".join(lines)


@mcp.tool()
def correlation(
    series_ids: list[str],
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Pairwise correlation matrix for multiple series.

    Args:
        series_ids: List of series IDs (at least 2)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_ids}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("correlation", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    labels = result.get("labels", [])
    matrix = result.get("matrix", [])
    lines = [f"Correlation ({result.get('observations', 0)} observations):"]
    header = "".ljust(25) + "  ".join([l[:10].rjust(10) for l in labels])
    lines.append(header)
    for i, label in enumerate(labels):
        row = label[:25].ljust(25) + "  ".join([f"{matrix[i][j]:.4f}".rjust(10) for j in range(len(labels))])
        lines.append(row)
    return "\n".join(lines)


@mcp.tool()
def unit_root(
    series_id: str,
    test: str = "all",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Unit root tests — is this series stationary? (ADF, KPSS, Phillips-Perron)

    Args:
        series_id: Series to test, e.g. "PET.RWTC.D"
        test: adf, kpss, pp, or all (default)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "test": test}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("unit_root", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Unit root tests for {series_id}:"]
    lines.append(f"Consensus: {result.get('consensus', '?')}")
    for name, t in result.get("tests", {}).items():
        lines.append(f"  {name.upper()}: stat={t.get('statistic', 0):.4f}, p={t.get('p_value', 0):.4f}, stationary={t.get('stationary', '?')}")
    return "\n".join(lines)


@mcp.tool()
def cointegration(
    series_ids: list[str],
    method: str = "johansen",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Cointegration test — do these series move together long-term?

    Args:
        series_ids: List of series IDs (at least 2)
        method: johansen (default) or engle-granger
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_ids, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("cointegration", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Cointegration ({method}): {'COINTEGRATED' if result.get('cointegrated') else 'Not cointegrated'}"]
    lines.append(f"Observations: {result.get('observations', 0)}")
    if "trace_tests" in result:
        for t in result["trace_tests"]:
            lines.append(f"  {t['hypothesis']}: stat={t['trace_stat']:.2f}, cv95={t['cv_95']:.2f}, reject={t.get('reject_95', '?')}")
    return "\n".join(lines)


@mcp.tool()
def transform(
    series_id: str,
    operation: str = "diff",
    window: int = 5,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Time series transform: diff, pct, log, logdiff, lag, ma, ema, cumsum, zscore.

    Args:
        series_id: Series to transform
        operation: diff, pct, log, logdiff, lag, ma, ema, cumsum, zscore
        window: Window size for ma/ema/lag (default 5)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "operation": operation, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("transform", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"Transform: {operation} (window={result.get('window', '')})", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: {r['original']} → {r['result']}")
    return "\n".join(lines)


@mcp.tool()
def smooth(
    series_id: str,
    horizon: int = 12,
    method: str = "ets",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Exponential smoothing forecast (single, double, Holt-Winters, ETS auto).

    Args:
        series_id: Series to forecast
        horizon: Periods ahead (default 12)
        method: single, double, holt-winters, ets (default)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "horizon": horizon, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("smooth", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Smooth: {result.get('method', '?')} (AIC={result.get('aic', '?')})"]
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}")
    return "\n".join(lines)


@mcp.tool()
def hp_filter(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Boosted Hodrick-Prescott filter — trend vs cycle decomposition.

    Args:
        series_id: Series to decompose
        start: Start date
        end: End date
    """
    req = {"series": series_id, "boosted": True}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("hp_filter", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"HP Filter: lambda={result.get('lambda')}, boosted={result.get('boosted')}, iterations={result.get('iterations')}", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: observed={r['observed']}, trend={r['trend']}, cycle={r['cycle']}")
    return "\n".join(lines)


@mcp.tool()
def bandpass(
    series_id: str,
    low: int = 6,
    high: int = 32,
    method: str = "cf",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Band-pass filter — extract cycles at specific frequencies (Baxter-King or Christiano-Fitzgerald).

    Args:
        series_id: Series to filter
        low: Min cycle length in periods (default 6)
        high: Max cycle length (default 32)
        method: bk or cf (default)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "low": low, "high": high, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("bandpass", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"Band-pass: {result.get('method')} (cycle {low}–{high} periods)", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: cycle={r['cycle']}, trend={r['trend']}")
    return "\n".join(lines)


@mcp.tool()
def seasonality(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Seasonal decomposition — trend, seasonal, and residual components.

    Args:
        series_id: Series to decompose
        start: Start date
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("seasonality", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"Seasonality: {result.get('model')} (period={result.get('period')})", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: trend={r['trend']}, seasonal={r['seasonal']}, residual={r['residual']}")
    return "\n".join(lines)


@mcp.tool()
def interpolate(
    series_id: str,
    method: str = "linear",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Fill missing values using interpolation (linear, log-linear, spline, cardinal).

    Args:
        series_id: Series to interpolate
        method: linear (default), log-linear, spline, cardinal
        start: Start date
        end: End date
    """
    req = {"series": series_id, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("interpolate", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    return f"Interpolate ({result.get('method')}): {result.get('gaps_filled')} gaps filled out of {result.get('total_points')} points"


@mcp.tool()
def outliers(
    series_id: str,
    method: str = "zscore",
    threshold: float = 3.0,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Detect outliers using Z-score, IQR, or Isolation Forest.

    Args:
        series_id: Series to analyse
        method: zscore (default), iqr, isolation_forest
        threshold: Detection threshold (default 3.0)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "method": method, "threshold": threshold}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("outliers", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Outliers ({method}, threshold={threshold}): {result.get('outlier_count')} of {result.get('total_points')} ({result.get('outlier_pct', 0):.1f}%)"]
    for o in result.get("outliers", []):
        lines.append(f"  {o['period']}: {o['value']}")
    return "\n".join(lines)


@mcp.tool()
def returns(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Log returns, cumulative returns, and drawdown analysis.

    Args:
        series_id: Series to analyse
        start: Start date
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("returns", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    s = result.get("summary", {})
    lines = [
        f"Returns for {series_id}:",
        f"  Total return: {s.get('total_return_pct', 0):.2f}%",
        f"  Max drawdown: {s.get('max_drawdown_pct', 0):.2f}% ({s.get('max_drawdown_peak')} → {s.get('max_drawdown_trough')})",
        f"  Avg daily return: {s.get('avg_daily_return', 0):.6f}",
        f"  Volatility: {s.get('volatility', 0):.4f}",
        f"  Positive periods: {s.get('positive_periods', 0)}, Negative: {s.get('negative_periods', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def elastic_net(
    series_ids: list[str],
    target: str,
    alpha: float = 1.0,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Elastic net regression — variable selection for predicting a target series.

    Args:
        series_ids: All series (target + predictors)
        target: Series to predict
        alpha: Regularisation strength (default 1.0)
        start: Start date
        end: End date
    """
    req = {"series": series_ids, "target": target, "alpha": alpha, "l1_ratio": 0.5}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("elastic_net", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Elastic Net: R²={result.get('r_squared', 0):.4f}, {result.get('n_selected')}/{result.get('n_predictors')} selected"]
    for c in result.get("coefficients", []):
        sel = " *" if c.get("selected") else ""
        lines.append(f"  {c['series']}: {c['coefficient']:.4f}{sel}")
    return "\n".join(lines)


@mcp.tool()
def quantile_reg(
    series_id: str,
    lags: int = 1,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Quantile autoregression — conditional quantile estimates for tail risk analysis.

    Args:
        series_id: Series to analyse
        lags: Number of lags (default 1)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "lags": lags}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("quantile_reg", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Quantile Regression (lags={lags}, obs={result.get('observations')}):"]
    lines.append(f"  Last value: {result.get('last_value')}")
    for q, est in result.get("current_estimates", {}).items():
        lines.append(f"  Q{q}: {est}")
    return "\n".join(lines)


@mcp.tool()
def bubble_test(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """GSADF test for explosive bubbles (Phillips, Shi & Yu 2015).

    Args:
        series_id: Series to test
        start: Start date
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("bubble_test", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"GSADF: {result.get('gsadf', 0):.4f} (cv95={result.get('cv_95', 0):.4f})",
        f"Bubble detected: {result.get('bubble_detected', False)}",
        f"Episodes: {result.get('n_episodes', 0)}",
    ]
    for ep in result.get("episodes", []):
        lines.append(f"  {ep['start']} – {ep['end']} ({ep['duration']} periods)")
    return "\n".join(lines)


@mcp.tool()
def lpirf(
    series_ids: list[str],
    shock: str,
    response: str,
    horizons: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Local Projection Impulse Response (Jordà 2005) — non-parametric IRF.

    Args:
        series_ids: All series involved (shock + response + controls)
        shock: Shock series ID
        response: Response series ID
        horizons: Number of horizons (default 20)
        start: Start date
        end: End date
    """
    req = {"series": series_ids, "shock": shock, "response": response, "horizons": horizons}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("lpirf", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"LPIRF: {shock} → {response} (obs={result.get('observations')})"]
    for pt in result.get("irf", []):
        resp = pt.get('response')
        if resp is not None:
            lines.append(f"  h={pt['horizon']}: {resp:.6f}  [{pt.get('ci_lower', 0):.6f} – {pt.get('ci_upper', 0):.6f}]")
    return "\n".join(lines)


@mcp.tool()
def midas(
    low_freq_series: str,
    high_freq_series: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """MIDAS mixed-frequency volatility — use high-freq data to forecast low-freq vol.

    Args:
        low_freq_series: Low-frequency series (e.g. monthly)
        high_freq_series: High-frequency series (e.g. daily)
        start: Start date
        end: End date
    """
    req = {"low_freq_series": low_freq_series, "high_freq_series": high_freq_series}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("midas", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"MIDAS: {result.get('freq_high')} → {result.get('freq_low')}",
        f"  Current vol: {result.get('current_vol', 0):.4f}",
        f"  Forecast vol: {result.get('forecast_vol', 0):.4f}",
        f"  Observations: {result.get('observations')}",
    ]
    return "\n".join(lines)


@mcp.tool()
def var(
    series_ids: list[str],
    lags: Optional[int] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Vector Autoregression with impulse response and Granger causality.

    Args:
        series_ids: List of series IDs (at least 2)
        lags: Lag order (None = auto-select by AIC)
        start: Start date
        end: End date
    """
    req = {"series": series_ids}
    if lags: req["lags"] = lags
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("var", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"VAR: lags={result.get('lags')}, AIC={result.get('aic', 0):.1f}, obs={result.get('observations')}"]
    if result.get("granger_causality"):
        lines.append("Granger causality:")
        for pair, gc in result["granger_causality"].items():
            sig = " *" if gc.get("significant") else ""
            lines.append(f"  {pair}: p={gc.get('p_value', 0):.4f}{sig}")
    return "\n".join(lines)


@mcp.tool()
def acf(
    series_id: str,
    nlags: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Autocorrelation (ACF), partial autocorrelation (PACF), and Ljung-Box Q-stats.

    Args:
        series_id: Series to analyse
        nlags: Number of lags (default 20)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "nlags": nlags}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("acf", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"ACF/PACF ({result.get('observations')} obs, band=±{result.get('confidence_band', 0):.4f}):"]
    for r in result.get("rows", [])[:nlags + 1]:
        sig = " *" if r.get("significant") else ""
        lines.append(f"  lag {r['lag']}: ACF={r['acf']:.4f}, PACF={r.get('pacf', '')}{sig}")
    if result.get("q_stats"):
        lines.append("Ljung-Box Q:")
        for lag, qs in result["q_stats"].items():
            lines.append(f"  lag {lag}: Q={qs['q_stat']:.2f}, p={qs['p_value']:.4f}")
    return "\n".join(lines)


@mcp.tool()
def spread(
    series_a: str,
    series_b: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Spread analysis between two series — spread, z-score, percentile, half-life.

    Args:
        series_a: First series (e.g. PET.RBRTE.D for Brent)
        series_b: Second series (e.g. PET.RWTC.D for WTI)
        start: Start date
        end: End date
    """
    req = {"series_a": series_a, "series_b": series_b}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("spread", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"Spread: {series_a} - {series_b}",
        f"  Current: {result.get('current_spread', 0):.2f}",
        f"  Mean: {result.get('mean', 0):.2f}, Std: {result.get('std', 0):.2f}",
        f"  Range: {result.get('min', 0):.2f} to {result.get('max', 0):.2f}",
        f"  Z-score: {result.get('zscore', 0):.2f}",
        f"  Percentile: {result.get('percentile', 0):.1f}%",
        f"  Half-life: {result.get('half_life', 'N/A')} periods",
        f"  Observations: {result.get('observations', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def rolling_correlation(
    series_a: str,
    series_b: str,
    window: int = 52,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Rolling window correlation between two series — shows how relationships shift over time.

    Args:
        series_a: First series
        series_b: Second series
        window: Rolling window size (default 52)
        start: Start date
        end: End date
    """
    req = {"series_a": series_a, "series_b": series_b, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("rolling_correlation", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"Rolling Correlation: {series_a} vs {series_b} (window={window})",
        f"  Overall: {result.get('overall_correlation', 0):.4f}",
        f"  Current: {result.get('current_correlation', 0):.4f}",
        f"  Range: {result.get('min_correlation', 0):.4f} to {result.get('max_correlation', 0):.4f}",
        f"  Mean: {result.get('mean_correlation', 0):.4f}",
        f"  Observations: {result.get('observations', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def chart(
    series_ids: Optional[list[str]] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
    width: int = 30,
    format: str = "ascii",
    watchlist: Optional[str] = None,
) -> str:
    """Chart one or more series — ASCII sparkline (default) or SVG for reports.

    Args:
        series_ids: Series to chart
        start: Start date
        end: End date
        width: ASCII chart width / SVG width scale factor (default 30)
        format: "ascii" (default, inline text) or "svg" (embeddable vector chart)
        watchlist: Use a saved watchlist (alternative to series_ids)
    """
    try:
        series_ids = _resolve_series(series_ids, watchlist)
    except ValueError as e:
        return f"Error: {e}"
    if not series_ids:
        return "Error: provide series_ids or watchlist"
    # Gather data for all series
    series_data = []
    for sid in series_ids:
        try:
            table = do_get([sid], start, end)
            periods = [str(table.column("period")[i].as_py()) for i in range(table.num_rows)]
            values = [float(table.column("value")[i].as_py()) for i in range(table.num_rows)
                      if table.column("value")[i].as_py() is not None]
            if values:
                series_data.append({"sid": sid, "periods": periods[:len(values)], "values": values})
        except Exception as e:
            series_data.append({"sid": sid, "error": str(e)})

    if format == "svg":
        return _render_svg_chart(series_data, width_scale=width)

    # ASCII default
    lines = []
    for s in series_data:
        if "error" in s:
            lines.append(f"{s['sid']}: error ({s['error']})")
            continue
        values = s["values"]
        sid = s["sid"]
        if not values:
            lines.append(f"{sid}: no data")
            continue
        spark = sparkline(values, width)
        mn = min(values); mx = max(values); cur = values[-1]
        lines.append(f"{sid}")
        lines.append(f"  {spark}  {cur:.2f}")
        lines.append(f"  {'L:'+str(round(mn,2)):>10s}{'':>{width-20}}{'H:'+str(round(mx,2)):>10s}")
    return "\n".join(lines)


def _render_svg_chart(series_data, width_scale=30):
    """Render series_data as SVG line chart. Multi-series overlay with colour legend."""
    colours = ["#0066cc", "#dc2626", "#059669", "#d97706", "#7c3aed", "#db2777", "#65a30d"]
    W = max(600, width_scale * 20)
    H = 360
    margin_l, margin_r, margin_t, margin_b = 60, 140, 20, 40
    plot_w = W - margin_l - margin_r
    plot_h = H - margin_t - margin_b

    # Filter good series
    good = [s for s in series_data if "values" in s and s["values"]]
    if not good:
        return '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="40"><text x="10" y="25" font-family="sans-serif" font-size="14">No data</text></svg>'

    # Find global y-range across all series
    all_vals = [v for s in good for v in s["values"]]
    y_min, y_max = min(all_vals), max(all_vals)
    y_pad = (y_max - y_min) * 0.05 or 1
    y_min -= y_pad; y_max += y_pad

    # For x-axis we use index-based positioning per series (normalized)
    max_n = max(len(s["values"]) for s in good)

    def x_pos(i, n):
        return margin_l + (i / max(n - 1, 1)) * plot_w
    def y_pos(v):
        return margin_t + plot_h - (v - y_min) / (y_max - y_min) * plot_h

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="-apple-system,Segoe UI,sans-serif" font-size="11">']
    # Background + axes
    parts.append(f'<rect width="{W}" height="{H}" fill="#fff"/>')
    parts.append(f'<line x1="{margin_l}" y1="{margin_t}" x2="{margin_l}" y2="{margin_t+plot_h}" stroke="#94a3b8"/>')
    parts.append(f'<line x1="{margin_l}" y1="{margin_t+plot_h}" x2="{margin_l+plot_w}" y2="{margin_t+plot_h}" stroke="#94a3b8"/>')
    # Y axis labels (5 gridlines)
    for i in range(5):
        yv = y_min + (y_max - y_min) * (i / 4)
        yp = y_pos(yv)
        parts.append(f'<line x1="{margin_l}" y1="{yp}" x2="{margin_l+plot_w}" y2="{yp}" stroke="#e2e8f0" stroke-dasharray="2,2"/>')
        parts.append(f'<text x="{margin_l-6}" y="{yp+3}" text-anchor="end" fill="#475569">{yv:.2f}</text>')
    # X axis endpoints
    first_s = good[0]
    parts.append(f'<text x="{margin_l}" y="{margin_t+plot_h+14}" fill="#475569">{first_s["periods"][0]}</text>')
    parts.append(f'<text x="{margin_l+plot_w}" y="{margin_t+plot_h+14}" text-anchor="end" fill="#475569">{first_s["periods"][-1]}</text>')

    # Data lines
    legend_y = margin_t + 4
    for idx, s in enumerate(good):
        colour = colours[idx % len(colours)]
        n = len(s["values"])
        path_parts = []
        for i, v in enumerate(s["values"]):
            x = x_pos(i, n)
            y = y_pos(v)
            path_parts.append(f'{"M" if i == 0 else "L"}{x:.1f},{y:.1f}')
        parts.append(f'<path d="{" ".join(path_parts)}" fill="none" stroke="{colour}" stroke-width="1.6"/>')
        # Legend entry
        lx = W - margin_r + 6
        parts.append(f'<line x1="{lx}" y1="{legend_y+5}" x2="{lx+18}" y2="{legend_y+5}" stroke="{colour}" stroke-width="2"/>')
        parts.append(f'<text x="{lx+22}" y="{legend_y+8}" fill="#1e293b">{s["sid"]}</text>')
        parts.append(f'<text x="{lx+22}" y="{legend_y+20}" fill="#94a3b8" font-size="10">last: {s["values"][-1]:.2f}</text>')
        legend_y += 30

    parts.append('</svg>')
    return "".join(parts)


@mcp.tool()
def snd_balance(
    production: Optional[str] = "PET.WCRFPUS2.W",
    imports: Optional[str] = "PET.WCEIMUS2.W",
    exports: Optional[str] = "PET.WCREXUS2.W",
    refinery_input: Optional[str] = "PET.WCRRIUS2.W",
    stocks: Optional[str] = "PET.WCESTUS1.W",
    adjustments: Optional[str] = None,
    pinned: Optional[dict] = None,
    forecast_horizon: int = 4,
    start: Optional[str] = None,
) -> str:
    """US crude oil supply & demand balance with scenario analysis.

    Computes: Supply (production + imports) - Demand (refinery input + exports) = Stock Change.
    Forecasts each component with Theta, or use pinned values for scenarios.

    Args:
        production: Production series (default US weekly)
        imports: Imports series
        exports: Exports series
        refinery_input: Refinery input series (proxy for demand)
        stocks: Stocks series (for comparison)
        adjustments: Optional adjustment series
        pinned: Pin any component at a fixed value, e.g. {"production": 13660}
        forecast_horizon: Weeks ahead (default 4)
        start: Start date for historical view
    """
    components = {
        "production": production,
        "imports": imports,
        "exports": exports,
        "refinery_input": refinery_input,
        "stocks": stocks,
    }
    if adjustments:
        components["adjustments"] = adjustments

    # Get latest values for all components
    series_ids = [v for v in components.values() if v]
    latest_result = do_action("latest", json.dumps({"series": series_ids}))
    latest_map = {r["series_id"]: r for r in latest_result if "error" not in r}

    lines = []
    lines.append("US CRUDE OIL S&D BALANCE")
    lines.append("=" * 50)

    # Current balance
    lines.append("\nCURRENT (latest available):")
    vals = {}
    for name, sid in components.items():
        if sid and sid in latest_map:
            v = latest_map[sid].get("value", 0) or 0
            period = latest_map[sid].get("period", "?")
            vals[name] = float(v)
            lines.append(f"  {name:20s}  {v:>12,.0f}  ({period})  {latest_map[sid].get('units','')}")

    prod = vals.get("production", 0)
    imp = vals.get("imports", 0)
    exp = vals.get("exports", 0)
    ref = vals.get("refinery_input", 0)
    adj = vals.get("adjustments", 0)

    supply = prod + imp
    demand = ref + exp
    balance = supply - demand + adj
    lines.append(f"  {'---':20s}  {'---':>12s}")
    lines.append(f"  {'Supply (P+I)':20s}  {supply:>12,.0f}")
    lines.append(f"  {'Demand (R+E)':20s}  {demand:>12,.0f}")
    lines.append(f"  {'Balance':20s}  {balance:>+12,.0f}  {'(build)' if balance > 0 else '(draw)'}")

    # Forecast / scenario
    if pinned or forecast_horizon > 0:
        lines.append(f"\nSCENARIO ({forecast_horizon} periods ahead):")
        if pinned:
            lines.append(f"  Pinned: {pinned}")

        # Forecast each component
        fc_vals = {}
        for name, sid in components.items():
            if not sid or name == "stocks":
                continue
            if pinned and name in pinned:
                fc_vals[name] = float(pinned[name])
                lines.append(f"  {name:20s}  {fc_vals[name]:>12,.0f}  (PINNED)")
            else:
                try:
                    result = do_action("theta", json.dumps({"series": sid, "horizon": forecast_horizon}))
                    if "error" not in result and result.get("forecast"):
                        # Average of forecast values
                        avg = sum(f["forecast"] for f in result["forecast"]) / len(result["forecast"])
                        fc_vals[name] = avg
                        lines.append(f"  {name:20s}  {avg:>12,.0f}  (Theta forecast)")
                except:
                    fc_vals[name] = vals.get(name, 0)
                    lines.append(f"  {name:20s}  {fc_vals[name]:>12,.0f}  (unchanged)")

        fc_supply = fc_vals.get("production", 0) + fc_vals.get("imports", 0)
        fc_demand = fc_vals.get("refinery_input", 0) + fc_vals.get("exports", 0)
        fc_adj = fc_vals.get("adjustments", 0)
        fc_balance = fc_supply - fc_demand + fc_adj

        lines.append(f"  {'---':20s}  {'---':>12s}")
        lines.append(f"  {'Fcast Supply':20s}  {fc_supply:>12,.0f}")
        lines.append(f"  {'Fcast Demand':20s}  {fc_demand:>12,.0f}")
        lines.append(f"  {'Fcast Balance':20s}  {fc_balance:>+12,.0f}  {'(build)' if fc_balance > 0 else '(draw)'}")

        # Implied stock change
        current_stocks = vals.get("stocks", 0)
        implied_stocks = current_stocks + fc_balance * forecast_horizon
        lines.append(f"\n  Implied stocks in {forecast_horizon} periods: {implied_stocks:,.0f}")
        lines.append(f"  Stock change: {fc_balance * forecast_horizon:+,.0f}")

    lines.append(f"\n{'=' * 50}")
    return "\n".join(lines)


REPORT_PRESETS = {
    "morning":     ("Daily 8am",       "Overnight moves + catalyst preview + curve shape",
                    ["prices", "changes", "curve", "events"]),
    "eia_weekly":  ("Wed after EIA",   "Stocks seasonal + crack spreads + changes",
                    ["prices", "seasonal", "crack", "changes"]),
    "cftc_weekly": ("Fri after CFTC",  "Positioning percentile + changes",
                    ["positioning", "changes"]),
    "refining":    ("Weekly",          "Crack z-scores + seasonal product stocks + turnaround flags",
                    ["crack", "seasonal", "maintenance", "changes"]),
    "arb":         ("Daily/weekly",    "Cargo arb score + curve + Brent-WTI spread",
                    ["arb", "curve", "spreads"]),
    "grades":      ("Monthly",         "Crude grade prices + differentials (LLS, Mars, etc.)",
                    ["prices", "spreads"]),
    "macro":       ("Weekly / FOMC",   "Macro correlations + regime identification",
                    ["prices", "correlations", "changes"]),
    "quarterly":   ("Quarterly",       "Full strategy outlook — everything + arb + events",
                    ["prices", "changes", "spreads", "forecast", "volatility", "correlations",
                     "breakpoints", "seasonal", "crack", "curve", "positioning", "arb", "events"]),
    "regime":      ("Post-shock",      "Structural breaks + volatility + correlations + changes",
                    ["breakpoints", "volatility", "correlations", "changes"]),
    "storage":     ("Ad-hoc",          "Curve carry + Cushing seasonal + spreads",
                    ["curve", "seasonal", "spreads"]),
    "trader":      ("General",         "Prices + changes + spreads + crack + curve + positioning + seasonal",
                    ["prices", "changes", "spreads", "crack", "curve", "positioning", "seasonal"]),
    "analyst":     ("General",         "Prices + changes + spreads + forecast + correlations + breakpoints",
                    ["prices", "changes", "spreads", "forecast", "correlations", "breakpoints"]),
    "daily":       ("General",         "Quick briefing — prices + changes + spreads + curve",
                    ["prices", "changes", "spreads", "curve"]),
    "deep":        ("General",         "Everything — the true superset (quarterly + maintenance + macro corr)",
                    ["prices", "changes", "spreads", "forecast", "volatility", "correlations",
                     "breakpoints", "seasonal", "crack", "curve", "positioning", "arb",
                     "maintenance", "events"]),
}


@mcp.tool()
def report_presets() -> str:
    """List all available report presets with descriptions.

    Each preset bundles the right combination of analytics tools for a specific
    reporting cadence (daily morning brief, weekly EIA release, monthly crude
    grades, quarterly strategy, post-shock debrief, etc.).

    Use with: report(watchlist="my_list", preset="morning")
    """
    lines = ["Report presets:", ""]
    lines.append(f"  {'Preset':<14s}  {'When':<16s}  Description")
    lines.append(f"  {'-'*14}  {'-'*16}  {'-'*50}")
    for name, (when, desc, _sections) in REPORT_PRESETS.items():
        lines.append(f"  {name:<14s}  {when:<16s}  {desc}")
    lines.append("")
    lines.append("Usage: report(watchlist='oil_daily', preset='morning')")
    lines.append("       report(series_ids=[...], preset='regime')")
    return "\n".join(lines)


@mcp.tool()
def report(
    series_ids: Optional[list[str]] = None,
    sections: Optional[list[str]] = None,
    preset: Optional[str] = None,
    lookback_days: int = 7,
    forecast_horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
    curve_prefix: Optional[str] = "ICE.BRENT",
    positioning_series: Optional[list[str]] = None,
    watchlist: Optional[str] = None,
) -> str:
    """Generate a market report — runs a battery of analytics on the given series.

    Available sections: prices, changes, spreads, forecast, volatility, correlations,
    breakpoints, seasonal, percentile, crack, curve, positioning.

    Presets (override sections):
      General:
      - "trader": prices, changes, spreads, crack, curve, positioning, seasonal
      - "analyst": prices, changes, spreads, forecast, correlations, breakpoints
      - "daily": prices, changes, spreads, curve
      - "deep": everything

      Desk-specific (oil analyst cycle):
      - "morning": overnight moves + catalyst preview + curve shape (daily 8am)
      - "eia_weekly": stocks seasonal + S&D balance + cracks (Wed after EIA)
      - "cftc_weekly": positioning percentile + changes (Fri after CFTC)
      - "refining": cracks + seasonal product stocks + maintenance signal
      - "arb": cargo arb economics + curve + Brent-WTI
      - "grades": crude grade prices + differentials (monthly)
      - "macro": correlations + macro regime (weekly/FOMC/NFP)
      - "quarterly": full strategy outlook (everything + arb + events)
      - "regime": post-shock analysis (breakpoints + vol + correlations)
      - "storage": curve carry + Cushing seasonal + spreads

    Args:
        series_ids: Series to analyse (e.g. ["PET.RWTC.D", "PET.RBRTE.D", "PET.WCESTUS1.W"])
        sections: Which sections to include (default: all)
        preset: Named bundle of sections — see above. Overrides `sections` if set.
        lookback_days: Lookback for change detection (default 7)
        forecast_horizon: Periods for forecasts (default 12)
        start: Training window start date (YYYY-MM-DD). Applied to spread, correlation,
               volatility, breakpoints. Omitting uses full history.
        end: Training window end date (YYYY-MM-DD).
        watchlist: Use a saved watchlist (alternative to series_ids)
    """
    try:
        series_ids = _resolve_series(series_ids, watchlist)
    except ValueError as e:
        return f"Error: {e}"
    if not series_ids:
        return "Error: provide series_ids or watchlist"
    # Apply preset if set
    if preset is not None:
        if preset not in REPORT_PRESETS:
            return f"Unknown preset '{preset}'. Call report_presets() to see all options."
        sections = REPORT_PRESETS[preset][2]

    if sections is None:
        sections = ["prices", "changes", "spreads", "forecast", "volatility", "correlations", "breakpoints"]

    # Common window params for analytics sub-calls
    def _win(extra=None):
        d = dict(extra or {})
        if start: d["start"] = start
        if end: d["end"] = end
        return d

    report_parts = []
    report_parts.append(f"ENERGYSCOPE MARKET REPORT")
    report_parts.append(f"Series: {', '.join(series_ids)}")
    if start or end:
        report_parts.append(f"Window: {start or 'earliest'} → {end or 'latest'}")
    report_parts.append(f"{'='*60}")

    # Prices — latest values
    if "prices" in sections:
        try:
            result = do_action("latest", json.dumps({"series": series_ids}))
            report_parts.append("\n📊 LATEST PRICES")
            for r in result:
                if "error" not in r:
                    val = r.get("value")
                    report_parts.append(f"  {r['series_id']:40s}  {r.get('period','?'):10s}  {val if val is not None else 'N/A':>10}  {r.get('units',''):15s}  {r.get('name','')[:40]}")
        except: pass

    # Changes — what moved
    if "changes" in sections:
        try:
            result = do_action("changes", json.dumps({"series": series_ids, "lookback_days": lookback_days}))
            report_parts.append(f"\n📈 CHANGES (last {lookback_days} days)")
            for c in result.get("changes", []):
                flag = " ⚠️" if c.get("move_zscore", 0) > 2 else ""
                report_parts.append(f"  {c['series_id']:40s}  {c.get('pct_change',0):+.1f}%  (z={c.get('move_zscore',0):.1f}){flag}")
        except: pass

    # Spreads — if we have pairs
    if "spreads" in sections and len(series_ids) >= 2:
        try:
            result = do_action("spread", json.dumps(_win({"series_a": series_ids[0], "series_b": series_ids[1]})))
            if "error" not in result:
                report_parts.append(f"\n📐 SPREAD: {series_ids[0]} - {series_ids[1]}")
                report_parts.append(f"  Current: {result.get('current_spread', 0):.2f}  Mean: {result.get('mean', 0):.2f}  Z-score: {result.get('zscore', 0):.2f}  Pctl: {result.get('percentile', 0):.0f}%  ({result.get('observations', '?')} obs)")
        except: pass

    # Forecast (with backtest so the forecast isn't cited without honest skill context)
    if "forecast" in sections:
        for sid in series_ids[:3]:  # limit to 3 series
            try:
                result = do_action("theta", json.dumps({"series": sid, "horizon": forecast_horizon, "backtest": True}))
                if "error" not in result:
                    fc = result.get("forecast", [])
                    if fc:
                        report_parts.append(f"\n🔮 FORECAST: {sid} (Theta, {forecast_horizon} periods)")
                        for f in fc[:3]:
                            report_parts.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower',0):.2f} – {f.get('ci_upper',0):.2f}]")
                        if len(fc) > 3:
                            report_parts.append(f"  ... {len(fc)} total periods")
                        bt = result.get("backtest")
                        if bt:
                            skill = bt.get("skill_vs_naive")
                            skill_str = f"{skill*100:+.1f}%{_skill_tag(skill)}" if skill is not None else "n/a"
                            report_parts.append(
                                f"  backtest ({bt['splits']}-step rolling): RMSE={bt['rmse']:.2f}, "
                                f"naive={bt['naive_rmse']:.2f}, skill={skill_str}"
                            )
            except: pass

    # Volatility
    if "volatility" in sections:
        for sid in series_ids[:3]:
            try:
                result = do_action("volatility", json.dumps(_win({"series": sid, "window": 20})))
                if "error" not in result:
                    cur = result.get("current", {})
                    report_parts.append(f"\n📊 VOLATILITY: {sid}")
                    report_parts.append(f"  Rolling(20): {cur.get('rolling_vol', 0):.4f}  GARCH: {cur.get('garch_vol', 0):.4f}  ({cur.get('frequency','?')}, annualised)")
            except: pass

    # Correlations
    if "correlations" in sections and len(series_ids) >= 2:
        # If macro preset, run correlate_all against MACRO.* candidates vs first series
        macro_candidates = ["MACRO.GSPC.D", "MACRO.VIX.D", "MACRO.TNX.D",
                            "MACRO.DX_Y_NYB.D", "MACRO.GCF.D", "MACRO.HGF.D",
                            "SHIP.BWET.D"]
        if preset in ("macro",) and series_ids:
            try:
                target = series_ids[0]
                result = do_action("correlate_all", json.dumps(
                    _win({"target": target, "candidates": macro_candidates, "window": 60})))
                if "error" not in result:
                    report_parts.append(f"\n🔗 MACRO CORRELATIONS (60d rolling vs {target})")
                    for r in result.get("results", [])[:10]:
                        if r.get("current_corr") is not None:
                            report_parts.append(
                                f"  {r['series_id']:30s}  curr={r['current_corr']:+.3f}  "
                                f"mean={r['mean_corr']:+.3f}  overall={r['overall_corr']:+.3f}")
            except: pass
        else:
            try:
                result = do_action("correlation", json.dumps(_win({"series": series_ids})))
                if "error" not in result:
                    report_parts.append(f"\n🔗 CORRELATIONS ({result.get('observations', 0)} obs)")
                    labels = result.get("labels", [])
                    matrix = result.get("matrix", [])
                    for i in range(len(labels)):
                        for j in range(i+1, len(labels)):
                            report_parts.append(f"  {labels[i]} vs {labels[j]}: {matrix[i][j]:.4f}")
            except: pass

    # Breakpoints
    if "breakpoints" in sections:
        for sid in series_ids[:3]:
            try:
                result = do_action("breakpoints", json.dumps(_win({"series": sid, "min_shift": 5})))
                if "error" not in result and result.get("n_breakpoints", 0) > 0:
                    report_parts.append(f"\n⚡ BREAKPOINTS: {sid} (min_shift=$5)")
                    for bp in result.get("breakpoints", [])[-3:]:
                        report_parts.append(f"  {bp['period']}: shift {bp.get('shift',0):+.1f}")
            except: pass

    # Seasonal — current vs 5yr avg
    if "seasonal" in sections:
        for sid in series_ids[:3]:
            try:
                result = do_action("seasonal", json.dumps({"series": sid, "lookback_years": 5}))
                if "error" not in result:
                    report_parts.append(f"\n🗓️  SEASONAL: {sid} ({result['seasonal_key']})")
                    report_parts.append(
                        f"  Current: {result['current_value']:.2f}  "
                        f"5yr avg: {result['seasonal_avg']:.2f}  "
                        f"delta: {result['delta_vs_avg']:+.2f} ({result['pct_vs_avg']:+.1f}%)  "
                        f"pctl: {result['percentile']:.0f}"
                    )
            except: pass

    # Crack spread — 3-2-1 default
    if "crack" in sections:
        try:
            result = do_action("crack_spread", json.dumps(_win({"ratio": "3-2-1"})))
            if "error" not in result:
                report_parts.append(f"\n🔥 CRACK: {result.get('label', '3-2-1')}")
                report_parts.append(
                    f"  Current: {result['current']:.2f}  "
                    f"Mean: {result['mean']:.2f}  "
                    f"z: {result['zscore']:.2f}  "
                    f"range: [{result['min']:.2f}, {result['max']:.2f}]"
                )
        except: pass

    # Curve / term structure
    if "curve" in sections and curve_prefix:
        try:
            series = [f"{curve_prefix}.M{i}.D" for i in range(1, 13)]
            latest_res = do_action("latest", json.dumps({"series": series}))
            by_m = {}
            for r in (latest_res if isinstance(latest_res, list) else [latest_res]):
                if "error" in r: continue
                tail = r.get("series_id", "").replace(curve_prefix + ".", "").replace(".D", "")
                if tail.startswith("M"):
                    try:
                        m = int(tail[1:])
                        by_m[m] = r.get("value")
                    except ValueError: pass
            if by_m:
                ms = sorted(by_m)
                slope = by_m[ms[-1]] - by_m[ms[0]]
                shape = "BACKWARDATION" if slope < 0 else "CONTANGO" if slope > 0 else "FLAT"
                report_parts.append(f"\n📈 CURVE: {curve_prefix} — {shape}")
                report_parts.append(f"  M1: {by_m[ms[0]]:.2f}  M{ms[-1]}: {by_m[ms[-1]]:.2f}  slope: {slope:+.2f}")
                if 1 in by_m and 2 in by_m:
                    report_parts.append(f"  M1-M2: {by_m[2]-by_m[1]:+.2f}  M1-M12: {by_m.get(12, 0)-by_m[1]:+.2f}" if 12 in by_m else f"  M1-M2: {by_m[2]-by_m[1]:+.2f}")
        except: pass

    # Positioning — CFTC net managed money
    if "positioning" in sections:
        pos_series = positioning_series or ["CFTC.WTI.MM_Net", "CFTC.BRENT.MM_Net"]
        try:
            latest_res = do_action("latest", json.dumps({"series": pos_series}))
            pos_map = {r["series_id"]: r for r in (latest_res if isinstance(latest_res, list) else [latest_res]) if "error" not in r}
            if pos_map:
                report_parts.append(f"\n💼 POSITIONING (CFTC managed money)")
                for sid, r in pos_map.items():
                    # Get percentile too
                    try:
                        p = do_action("percentile", json.dumps({"series": sid}))
                        if "error" not in p:
                            report_parts.append(
                                f"  {sid}: {r.get('value', 0):>12,.0f} contracts  "
                                f"({r.get('period', '?')})  pctl={p['percentile']:.0f}  z={p['zscore']:.2f}"
                            )
                        else:
                            report_parts.append(f"  {sid}: {r.get('value', 0):>12,.0f} contracts  ({r.get('period', '?')})")
                    except:
                        report_parts.append(f"  {sid}: {r.get('value', 0):>12,.0f} contracts")
        except: pass

    # Upcoming events (catalyst calendar)
    if "events" in sections:
        try:
            from datetime import datetime, timedelta, timezone
            # Inline version of upcoming_events logic for the next 7 days
            now = datetime.now(timezone.utc)
            end_dt = now + timedelta(days=7)
            ev_lines = []
            d = now.date()
            for i in range(8):
                day = d + timedelta(days=i)
                wd = day.weekday()
                if wd == 2:
                    ev_lines.append(f"  {day.strftime('%a %Y-%m-%d')}  [EIA]  Weekly Petroleum Status Report")
                if wd == 3:
                    ev_lines.append(f"  {day.strftime('%a %Y-%m-%d')}  [EIA]  Weekly Natural Gas Storage")
                if wd == 4:
                    ev_lines.append(f"  {day.strftime('%a %Y-%m-%d')}  [CFTC] Commitments of Traders")
                if wd == 1:
                    ev_lines.append(f"  {day.strftime('%a %Y-%m-%d')}  [API]  Weekly Oil Stocks")
            if ev_lines:
                report_parts.append(f"\n📅 UPCOMING CATALYSTS (7 days)")
                report_parts.extend(ev_lines)
        except: pass

    # Maintenance signal
    if "maintenance" in sections:
        try:
            result = do_action("maintenance_signal", json.dumps(
                {"series": "PET.WPULEUS3.W", "mode": "trend", "scan_weeks": 26}))
            if "error" not in result:
                report_parts.append(f"\n🔧 REFINERY MAINTENANCE ({result.get('event_count', 0)} events in last 26 weeks)")
                for ev in result.get("events", []):
                    span = f"{ev['start']}" if ev['start'] == ev['end'] else f"{ev['start']} → {ev['end']}"
                    report_parts.append(
                        f"  {span} ({ev['weeks']}w): trough z={ev['trough_zscore']:.2f}")
                if not result.get("events"):
                    report_parts.append("  No significant utilization drops detected")
        except: pass

    # Arb signal
    if "arb" in sections:
        try:
            # Inline arb computation for report context
            sp = do_action("spread", json.dumps(_win({"series_a": "PET.RBRTE.D", "series_b": "PET.RWTC.D"})))
            if "error" not in sp:
                pct = sp.get("percentile", 50)
                report_parts.append(f"\n🚢 ARB ECONOMICS")
                report_parts.append(f"  Brent-WTI: ${sp.get('current_spread',0):.2f} (pctl={pct:.0f}, z={sp.get('zscore',0):.2f})")
            fp = do_action("percentile", json.dumps({"series": "SHIP.BWET.D"}))
            if "error" not in fp:
                report_parts.append(f"  Freight (BWET): pctl={fp.get('percentile',50):.0f} z={fp.get('zscore',0):.2f}")
        except: pass

    report_parts.append(f"\n{'='*60}")
    if preset:
        report_parts.append(f"Preset: {preset}")
    report_parts.append(f"Generated by EnergyScope Analytics Flight Server")
    return "\n".join(report_parts)


@mcp.tool()
def crack_spread(
    ratio: str = "3-2-1",
    crude: str = "PET.RWTC.D",
    gasoline: str = "PET.EER_EPMRU_PF4_RGC_DPG.D",
    distillate: str = "PET.EER_EPD2F_PF4_Y35NY_DPG.D",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Refining crack spread — 3-2-1, gasoline, or diesel.

    Args:
        ratio: 3-2-1 (default), gasoline, or diesel
        crude: Crude oil series (default WTI)
        gasoline: Gasoline series (default US Gulf Coast)
        distillate: Distillate series (default NY Harbor heating oil)
        start: Start date
        end: End date
    """
    req = {"crude": crude, "gasoline": gasoline, "distillate": distillate, "ratio": ratio}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("crack_spread", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"{result.get('label', ratio)} ($/bbl):",
        f"  Current: ${result.get('current', 0):.2f}",
        f"  Mean: ${result.get('mean', 0):.2f}, Std: ${result.get('std', 0):.2f}",
        f"  Range: ${result.get('min', 0):.2f} to ${result.get('max', 0):.2f}",
        f"  Z-score: {result.get('zscore', 0):.2f}",
        f"  Observations: {result.get('observations', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def percentile(
    series_id: str,
    as_of: Optional[str] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Rank the current value within the series' own history. Returns z-score,
    percentile, min/max, quartile breakdown.

    Use this when you need to answer "is this high or low?" for any series
    (CFTC positioning, stock levels, spread values, production volumes, etc.)
    without pairing it with a second series.

    Args:
        series_id: Series to evaluate
        as_of: (Optional) Evaluate the value as of this date (default: latest value)
        start: (Optional) Limit the historical reference window to start from this date
        end: (Optional) Limit the historical reference window to end at this date
    """
    req = {"series": series_id}
    if as_of: req["as_of"] = as_of
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("percentile", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    return (
        f"{series_id} — percentile rank\n"
        f"  Target ({result['target_period']}): {result['target_value']:.2f}\n"
        f"  Percentile: {result['percentile']:.1f}%  (z-score: {result['zscore']:.2f})\n"
        f"  Distribution ({result['observations']} obs, {result['first_period']}–{result['last_period']}):\n"
        f"    min:  {result['min']:.2f}\n"
        f"    p5:   {result['p5']:.2f}\n"
        f"    p25:  {result['p25']:.2f}\n"
        f"    p50:  {result['median']:.2f}\n"
        f"    p75:  {result['p75']:.2f}\n"
        f"    p95:  {result['p95']:.2f}\n"
        f"    max:  {result['max']:.2f}\n"
        f"    mean: {result['mean']:.2f}  std: {result['std']:.2f}"
    )


@mcp.tool()
def maintenance_signal(
    series_id: str = "PET.WPULEUS3.W",
    mode: str = "trend",
    trend_window: int = 12,
    lookback_years: int = 5,
    threshold_z: float = -1.5,
    scan_weeks: int = 52,
) -> str:
    """Detect likely refinery turnaround / maintenance weeks from utilization drops.

    For each of the last N weeks, computes a z-score and flags weeks below threshold_z.
    Clusters of consecutive flagged weeks are grouped as single events.

    MODES:
      - "trend" (DEFAULT): z vs trailing `trend_window`-period rolling mean.
        Best for catching UNEXPECTED drops that break the recent trajectory.
        Planned spring/fall turnarounds recur every year and wash out of the
        seasonal baseline — trend mode catches them because they break recent trend.
      - "seasonal": z vs same-week in prior N years. Good for anomaly detection
        but MISSES recurring turnarounds (they become the seasonal norm).
      - "absolute": z vs full series history.

    Default target: US refinery utilization (PET.WPULEUS3.W).

    Args:
        series_id: Target (default: US refinery utilization)
        mode: "trend" (default), "seasonal", or "absolute"
        trend_window: Trend-mode trailing window (default 12)
        lookback_years: Seasonal-mode prior years (default 5)
        threshold_z: Flag threshold (default -1.5)
        scan_weeks: How many recent periods to scan (default 52)
    """
    req = {"series": series_id, "mode": mode, "trend_window": trend_window,
           "lookback_years": lookback_years, "threshold_z": threshold_z,
           "scan_weeks": scan_weeks}
    result = do_action("maintenance_signal", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    m = result.get("mode", "trend")
    if m == "trend":
        baseline_desc = f"{result['trend_window']}-period trailing mean"
    elif m == "seasonal":
        baseline_desc = f"{result['lookback_years']}yr same-week seasonal avg"
    else:
        baseline_desc = "full-history mean"

    lines = [
        f"Maintenance signal — {series_id} (mode={m})",
        f"Scanned last {result['scan_weeks']} {result['frequency']}-periods "
        f"(baseline: {baseline_desc}, flag z≤{result['threshold_z']})",
        f"{result['flagged_count']} flagged weeks in {result['event_count']} events:",
    ]
    for ev in result.get("events", []):
        span = f"{ev['start']}" if ev['start'] == ev['end'] else f"{ev['start']} → {ev['end']}"
        lines.append(
            f"  {span} ({ev['weeks']}w): trough {ev['trough_period']} z={ev['trough_zscore']:.2f}, "
            f"avg {ev['avg_delta_vs_seasonal']:+.2f} vs baseline"
        )
    return "\n".join(lines)


@mcp.tool()
def correlate_all(
    target: str,
    candidates: Optional[list[str]] = None,
    window: int = 60,
    start: Optional[str] = None,
    end: Optional[str] = None,
    limit: int = 20,
    watchlist: Optional[str] = None,
) -> str:
    """Scan many series against a target, rank by rolling correlation.

    Discovery tool: "what tracks WTI best lately?" or "which oil equities move
    most with crude?". Computes a rolling correlation window against the target
    for each candidate, then ranks by |current_correlation|.

    Args:
        target: Reference series (e.g. "PET.RWTC.D")
        candidates: List of candidates to test (e.g. OILEQ.* tickers)
        window: Rolling correlation window (default 60)
        start: Optional window start date
        end: Optional window end date
        limit: Top N to show (default 20)
        watchlist: Use a saved watchlist for candidates (alternative)
    """
    try:
        candidates = _resolve_series(candidates, watchlist)
    except ValueError as e:
        return f"Error: {e}"
    if not candidates:
        return "Error: provide candidates or watchlist"
    req = {"target": target, "candidates": candidates, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("correlate_all", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [
        f"Rolling correlation (window={result['window']}) vs {target}:",
        f"{'Series':<30s}  {'current':>8s}  {'mean':>7s}  {'min':>7s}  {'max':>7s}  {'overall':>8s}",
    ]
    for r in result.get("results", [])[:limit]:
        if r.get("current_corr") is None:
            lines.append(f"  {r['series_id']:<30s}  (insufficient overlap: {r.get('note', '?')})")
            continue
        lines.append(
            f"  {r['series_id']:<30s}  {r['current_corr']:>+8.3f}  "
            f"{r['mean_corr']:>+7.3f}  {r['min_corr']:>+7.3f}  {r['max_corr']:>+7.3f}  "
            f"{r['overall_corr']:>+8.3f}"
        )
    return "\n".join(lines)


@mcp.tool()
def arb_signal(
    wti: str = "PET.RWTC.D",
    brent: str = "PET.RBRTE.D",
    freight_proxy: str = "SHIP.BWET.D",
    curve_prefix: str = "ICE.BRENT",
    start: Optional[str] = None,
) -> str:
    """US-Europe crude arb economics — combines spread, freight, and curve shape.

    A bullish arb for US crude exports looks like: wide Brent-WTI spread (buyers
    willing to pay up for Brent-priced crude) + low BWET tanker freight (cheap
    shipping) + contango or narrow backwardation (carry doesn't kill the trade).

    Args:
        wti: WTI crude series (default PET.RWTC.D)
        brent: Brent crude series (default PET.RBRTE.D)
        freight_proxy: Tanker freight proxy (default SHIP.BWET.D)
        curve_prefix: Futures curve prefix for structure analysis (default ICE.BRENT)
        start: Optional analysis window start
    """
    lines = []
    alerts = []
    score_components = {}  # name -> contribution to score (-1..+1)

    # Spread: Brent - WTI (bullish arb = wide spread = high pctl)
    try:
        req = {"series_a": brent, "series_b": wti}
        if start: req["start"] = start
        sp = do_action("spread", json.dumps(req))
        if "error" not in sp:
            cur = sp.get("current_spread", 0)
            pct = sp.get("percentile", 50)
            z = sp.get("zscore", 0)
            # Map percentile 0..100 → -1..+1
            score_components["spread"] = (pct - 50) / 50.0
            if abs(z) >= 2:
                alerts.append(f"⚠ SPREAD EXTREME: {brent}-{wti} at z={z:.2f} (pctl={pct:.0f})")
            lines.append(f"📐 SPREAD ({brent} - {wti}): ${cur:.2f}  pctl={pct:.0f}  z={z:.2f}")
    except Exception as e:
        lines.append(f"📐 SPREAD: error ({e})")

    # Freight percentile (bullish arb = cheap freight = low pctl → score = +1 when pctl=0)
    try:
        p = do_action("percentile", json.dumps({"series": freight_proxy}))
        if "error" not in p:
            pct = p.get("percentile", 50)
            z = p.get("zscore", 0)
            # Inverse mapping: low freight = good, so (50 - pct)/50
            score_components["freight"] = (50 - pct) / 50.0
            if abs(z) >= 2:
                alerts.append(f"⚠ FREIGHT EXTREME: {freight_proxy} at z={z:.2f} (pctl={pct:.0f})")
            lines.append(f"🚢 FREIGHT ({freight_proxy}): {p['target_value']:.2f}  pctl={pct:.0f}  z={z:.2f}")
    except Exception as e:
        lines.append(f"🚢 FREIGHT: error ({e})")

    # Curve structure (contango = bullish for export arb)
    try:
        series_list = [f"{curve_prefix}.M{i}.D" for i in [1, 2, 6, 12]]
        lr = do_action("latest", json.dumps({"series": series_list}))
        by_m = {}
        for r in (lr if isinstance(lr, list) else [lr]):
            if "error" in r: continue
            tail = r.get("series_id", "").replace(curve_prefix + ".", "").replace(".D", "")
            if tail.startswith("M"):
                try: by_m[int(tail[1:])] = r.get("value")
                except: pass
        if 1 in by_m and len(by_m) >= 2:
            last_m = max(by_m.keys())
            slope = by_m[last_m] - by_m[1]
            # Normalise slope by front-month: slope as % → -1..+1 by clamping at ±10%
            slope_pct = (slope / by_m[1]) if by_m[1] else 0
            score_components["curve"] = max(-1, min(1, slope_pct / 0.1))
            shape = "BACKWARDATION" if slope < 0 else "CONTANGO"
            lines.append(f"📈 CURVE ({curve_prefix}): M1={by_m[1]:.2f} M{last_m}={by_m[last_m]:.2f}  "
                         f"slope={slope:+.2f} ({slope_pct*100:+.1f}%)  {shape}")
    except Exception as e:
        lines.append(f"📈 CURVE: error ({e})")

    # Unified score: average components, scale to -2..+2
    header = ["Crude arb signal — US export economics", "=" * 50]
    if score_components:
        raw = sum(score_components.values()) / len(score_components)
        score = round(raw * 2, 2)  # -2..+2
        if score >= 1.0: verdict = "STRONGLY BULLISH arb"
        elif score >= 0.3: verdict = "bullish arb (tilted)"
        elif score <= -1.0: verdict = "STRONGLY BEARISH arb"
        elif score <= -0.3: verdict = "bearish arb (tilted)"
        else: verdict = "neutral"
        header.append(f"SCORE: {score:+.2f}  ({verdict})")
        header.append(f"Components: " + ", ".join(f"{k}={v:+.2f}" for k, v in score_components.items()))

    if alerts:
        header.append("")
        header.extend(alerts)
    header.append("")

    return "\n".join(header + lines + [
        "",
        "Score interpretation: +2 = wide spread + cheap freight + contango (bullish US exports)",
        "                     -2 = narrow spread + expensive freight + backwardation (bearish)",
    ])


@mcp.tool()
def seasonal(
    series_id: str,
    lookback_years: int = 5,
    start: Optional[str] = None,
) -> str:
    """Seasonal context — how does the current value compare to the same week/month
    in prior years? Essential for commodity analysis: "stocks at 462mb" means nothing
    without knowing whether that's +20mb or -10mb vs seasonal norm.

    Returns the current value, the N-year average for the same calendar position,
    min/max range, z-score, percentile, and the values from each prior year.

    Args:
        series_id: Series to evaluate (e.g. PET.WCESTUS1.W for crude stocks)
        lookback_years: Prior years to average (default 5)
        start: Optional start date to bound the historical window
    """
    req = {"series": series_id, "lookback_years": lookback_years}
    if start:
        req["start"] = start
    result = do_action("seasonal", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [
        f"{series_id} — seasonal context ({result['seasonal_key']})",
        f"  Current ({result['current_period']}): {result['current_value']:.2f}",
        f"  {result['lookback_years']}-year avg ({result['years_of_history']} yrs): "
        f"{result['seasonal_avg']:.2f}  "
        f"[{result['seasonal_min']:.2f} – {result['seasonal_max']:.2f}]",
        f"  Delta vs avg: {result['delta_vs_avg']:+.2f}  "
        f"({result['pct_vs_avg']:+.1f}%)   z={result['zscore']:.2f}   "
        f"pctl={result['percentile']:.0f}   range_pos={result['range_position']:.2f}",
        f"  History:",
    ]
    for y, v in result["history_by_year"].items():
        lines.append(f"    {y}: {v:.2f}")
    return "\n".join(lines)


@mcp.tool()
def term_structure(
    prefix: str = "ICE.BRENT",
    n_maturities: int = 12,
) -> str:
    """Futures curve structure — contango/backwardation metric, calendar spreads,
    roll yield, curve slope. Reads M1..MN constant-maturity series for the given
    prefix (default ICE.BRENT).

    Args:
        prefix: Series prefix without .M{n}.D suffix (e.g. "ICE.BRENT", "NYMEX.WTI")
        n_maturities: How many nearby contracts to include (default 12)
    """
    # Pull latest values for M1..MN
    series = [f"{prefix}.M{i}.D" for i in range(1, n_maturities + 1)]
    latest_res = do_action("latest", json.dumps({"series": series}))
    by_m = {}
    for r in latest_res if isinstance(latest_res, list) else [latest_res]:
        if "error" in r:
            continue
        sid = r.get("series_id", "")
        # Extract M number
        tail = sid.replace(prefix + ".", "").replace(".D", "")
        if tail.startswith("M"):
            try:
                m = int(tail[1:])
                by_m[m] = {"period": r.get("period"), "value": r.get("value"), "series_id": sid}
            except ValueError:
                pass

    if not by_m:
        return f"No data found for prefix '{prefix}' (expected series like {prefix}.M1.D)"

    ms = sorted(by_m.keys())
    m_front = by_m[ms[0]]["value"]
    m_back = by_m[ms[-1]]["value"]
    slope = m_back - m_front
    shape = "BACKWARDATION" if slope < 0 else "CONTANGO" if slope > 0 else "FLAT"

    # Key spreads
    spreads = {}
    for near, far in [(1, 2), (1, 3), (1, 6), (1, 12), (3, 6), (6, 12)]:
        if near in by_m and far in by_m:
            spreads[f"M{near}-M{far}"] = by_m[far]["value"] - by_m[near]["value"]

    # Annualised roll yield on front (M1→M2)
    roll_yield_ann = None
    if 1 in by_m and 2 in by_m and by_m[1]["value"]:
        m12 = by_m[2]["value"] - by_m[1]["value"]
        roll_yield_ann = (m12 / by_m[1]["value"]) * 12 * 100

    lines = [
        f"{prefix} forward curve — {shape} (slope M1→M{ms[-1]}: {slope:+.2f})",
        f"{'M':>3}  {'contract':<10} {'price':>8}",
    ]
    front = by_m[ms[0]]["value"]
    for m in ms:
        v = by_m[m]["value"]
        delta = v - front
        arrow = " " if m == ms[0] else ("v" if delta < 0 else "^")
        lines.append(f"{m:>3}  {str(by_m[m]['period']):<10} {v:>8.2f}  {arrow} {delta:+.2f}")
    lines.append("")
    lines.append("Calendar spreads:")
    for k, v in spreads.items():
        lines.append(f"  {k}: {v:+.2f}")
    if roll_yield_ann is not None:
        lines.append(f"  Front roll yield (annualised): {roll_yield_ann:+.1f}%")
    return "\n".join(lines)


@mcp.tool()
def changes(
    series_ids: Optional[list[str]] = None,
    lookback_days: int = 7,
    watchlist: Optional[str] = None,
) -> str:
    """What changed since last week? Detects significant moves across multiple series, ranked by size.

    Args:
        series_ids: List of series to check
        lookback_days: Days to look back (default 7)
        watchlist: Use a saved watchlist (alternative to series_ids)
    """
    try:
        series_ids = _resolve_series(series_ids, watchlist)
    except ValueError as e:
        return f"Error: {e}"
    if not series_ids:
        return "Error: provide series_ids or watchlist"
    req = {"series": series_ids, "lookback_days": lookback_days}
    result = do_action("changes", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Changes over last {lookback_days} days ({result.get('series_count', 0)} series):"]
    for c in result.get("changes", []):
        direction = "+" if c.get("abs_change", 0) >= 0 else ""
        zscore = c.get("move_zscore", 0)
        flag = " ⚠️" if zscore > 2 else ""
        lines.append(
            f"  {c['series_id']:40s}  {direction}{c.get('pct_change', 0):+.1f}%  "
            f"({c.get('prev_value', '?')} → {c.get('current_value', '?')})  "
            f"z={zscore:.1f}{flag}"
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
