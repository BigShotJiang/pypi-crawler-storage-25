from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.call_create import CallCreate
from ...models.http_validation_error import HTTPValidationError
from typing import cast


def _get_kwargs(
    *,
    body: CallCreate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/calls/trigger",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 202:
        response_202 = response.json()
        return response_202

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CallCreate,
) -> Response[Any | HTTPValidationError]:
    r"""Trigger Call

     Create a call record and schedule the outbound dial (async / 202).

    Returns **202 Accepted** with the Call record (``status=\"queued\"``)
    as soon as the row is persisted. The actual provider dial — which
    includes an up-to-300 s wait for TTS to become ready — runs as a
    background task so the HTTP response is never held open past the
    typical SDK timeout (30–60 s). Clients poll ``GET /calls/{id}`` for
    terminal status. On TTS-readiness failure the row is marked
    ``failed`` and ``metadata.error_message`` carries the user-facing
    explanation.

    Args:
        body (CallCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: CallCreate,
) -> Any | HTTPValidationError | None:
    r"""Trigger Call

     Create a call record and schedule the outbound dial (async / 202).

    Returns **202 Accepted** with the Call record (``status=\"queued\"``)
    as soon as the row is persisted. The actual provider dial — which
    includes an up-to-300 s wait for TTS to become ready — runs as a
    background task so the HTTP response is never held open past the
    typical SDK timeout (30–60 s). Clients poll ``GET /calls/{id}`` for
    terminal status. On TTS-readiness failure the row is marked
    ``failed`` and ``metadata.error_message`` carries the user-facing
    explanation.

    Args:
        body (CallCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CallCreate,
) -> Response[Any | HTTPValidationError]:
    r"""Trigger Call

     Create a call record and schedule the outbound dial (async / 202).

    Returns **202 Accepted** with the Call record (``status=\"queued\"``)
    as soon as the row is persisted. The actual provider dial — which
    includes an up-to-300 s wait for TTS to become ready — runs as a
    background task so the HTTP response is never held open past the
    typical SDK timeout (30–60 s). Clients poll ``GET /calls/{id}`` for
    terminal status. On TTS-readiness failure the row is marked
    ``failed`` and ``metadata.error_message`` carries the user-facing
    explanation.

    Args:
        body (CallCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CallCreate,
) -> Any | HTTPValidationError | None:
    r"""Trigger Call

     Create a call record and schedule the outbound dial (async / 202).

    Returns **202 Accepted** with the Call record (``status=\"queued\"``)
    as soon as the row is persisted. The actual provider dial — which
    includes an up-to-300 s wait for TTS to become ready — runs as a
    background task so the HTTP response is never held open past the
    typical SDK timeout (30–60 s). Clients poll ``GET /calls/{id}`` for
    terminal status. On TTS-readiness failure the row is marked
    ``failed`` and ``metadata.error_message`` carries the user-facing
    explanation.

    Args:
        body (CallCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
