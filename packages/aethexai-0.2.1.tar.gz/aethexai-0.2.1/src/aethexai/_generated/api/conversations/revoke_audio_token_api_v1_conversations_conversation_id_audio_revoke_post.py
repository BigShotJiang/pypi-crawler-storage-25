from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.audio_revoke_body import AudioRevokeBody
from ...models.http_validation_error import HTTPValidationError
from typing import cast
from uuid import UUID


def _get_kwargs(
    conversation_id: UUID,
    *,
    body: AudioRevokeBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/conversations/{conversation_id}/audio/revoke".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient,
    body: AudioRevokeBody,
) -> Response[Any | HTTPValidationError]:
    """Revoke Audio Token

     Revoke a previously-minted audio token before its natural expiry.

    Use case: a customer accidentally shares a public audio link and
    wants to invalidate it without waiting up to an hour for the TTL.
    The token's ``jti`` is added to the revocation cache (Redis +
    in-memory fallback) with a TTL matching the token's remaining
    lifetime, so memory pressure is bounded by the natural expiry
    schedule.

    Returns 204 on success; idempotent (re-revoking a revoked token is
    a no-op). 404 if the token isn't valid for THIS conversation under
    THIS tenant — same response we'd give for unauthorized cross-tenant
    access, so callers can't probe for valid tokens.

    Args:
        conversation_id (UUID):
        body (AudioRevokeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient,
    body: AudioRevokeBody,
) -> Any | HTTPValidationError | None:
    """Revoke Audio Token

     Revoke a previously-minted audio token before its natural expiry.

    Use case: a customer accidentally shares a public audio link and
    wants to invalidate it without waiting up to an hour for the TTL.
    The token's ``jti`` is added to the revocation cache (Redis +
    in-memory fallback) with a TTL matching the token's remaining
    lifetime, so memory pressure is bounded by the natural expiry
    schedule.

    Returns 204 on success; idempotent (re-revoking a revoked token is
    a no-op). 404 if the token isn't valid for THIS conversation under
    THIS tenant — same response we'd give for unauthorized cross-tenant
    access, so callers can't probe for valid tokens.

    Args:
        conversation_id (UUID):
        body (AudioRevokeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient,
    body: AudioRevokeBody,
) -> Response[Any | HTTPValidationError]:
    """Revoke Audio Token

     Revoke a previously-minted audio token before its natural expiry.

    Use case: a customer accidentally shares a public audio link and
    wants to invalidate it without waiting up to an hour for the TTL.
    The token's ``jti`` is added to the revocation cache (Redis +
    in-memory fallback) with a TTL matching the token's remaining
    lifetime, so memory pressure is bounded by the natural expiry
    schedule.

    Returns 204 on success; idempotent (re-revoking a revoked token is
    a no-op). 404 if the token isn't valid for THIS conversation under
    THIS tenant — same response we'd give for unauthorized cross-tenant
    access, so callers can't probe for valid tokens.

    Args:
        conversation_id (UUID):
        body (AudioRevokeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient,
    body: AudioRevokeBody,
) -> Any | HTTPValidationError | None:
    """Revoke Audio Token

     Revoke a previously-minted audio token before its natural expiry.

    Use case: a customer accidentally shares a public audio link and
    wants to invalidate it without waiting up to an hour for the TTL.
    The token's ``jti`` is added to the revocation cache (Redis +
    in-memory fallback) with a TTL matching the token's remaining
    lifetime, so memory pressure is bounded by the natural expiry
    schedule.

    Returns 204 on success; idempotent (re-revoking a revoked token is
    a no-op). 404 if the token isn't valid for THIS conversation under
    THIS tenant — same response we'd give for unauthorized cross-tenant
    access, so callers can't probe for valid tokens.

    Args:
        conversation_id (UUID):
        body (AudioRevokeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
            body=body,
        )
    ).parsed
