"""
polymarket-onchain — On-chain wallet intelligence for Polymarket traders.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.onchain import analyze_wallet_onchain, get_token_holders

__all__ = ["analyze_wallet_onchain", "get_token_holders"]
__version__ = "0.1.0"
