# polymarket-onchain

On-chain wallet intelligence for Polygon/DeFi. Analyzes wallet activity and smart money scoring.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-onchain
```

## Usage

```python
from polymarket_onchain import analyze_wallet_onchain
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
