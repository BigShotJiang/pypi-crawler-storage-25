from setuptools import setup, find_packages

setup(
    name="sovereign-autonomy-sdk",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    description="Deterministic, zero-dependency autonomy SDK for robotics.",
    author="Kevin Price",
    license="MIT",
)
