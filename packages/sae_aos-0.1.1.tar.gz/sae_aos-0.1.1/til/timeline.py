from collections import deque
from typing import Any, Deque, Dict, List, Optional


class Timeline:
    """
    Maintains a rolling history of organism state, actions, and safety envelopes.
    Optionally can hold predicted futures.
    """

    def __init__(self, max_length: int = 256):
        self.max_length = max_length
        self._history: Deque[Dict[str, Any]] = deque(maxlen=max_length)

    def append(self, snapshot: Dict[str, Any]) -> None:
        """
        Append a new temporal snapshot.

        Expected keys might include:
        - "t": time or tick
        - "state": world/organism state
        - "action": chosen action
        - "envelope": safety envelope status
        """
        self._history.append(snapshot)

    def window(self, n: int) -> List[Dict[str, Any]]:
        """Return the last n snapshots (or fewer if not available)."""
        if n <= 0:
            return []
        return list(self._history)[-n:]

    def all(self) -> List[Dict[str, Any]]:
        """Return the full history as a list."""
        return list(self._history)

    def last(self) -> Optional[Dict[str, Any]]:
        """Return the most recent snapshot, if any."""
        return self._history[-1] if self._history else None
