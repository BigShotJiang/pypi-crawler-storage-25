from typing import Dict, Any
from .timeline import Timeline
from .operators import TemporalOperators as TOp


class TemporalQueries:
    """
    Reusable temporal predicates built on top of TemporalOperators.
    These are semantic building blocks like "stuck", "oscillating", "idle", etc.
    """

    def __init__(self, timeline: Timeline):
        self.timeline = timeline

    def is_stuck_position(self, n: int = 10, pos_key: str = "position") -> bool:
        snapshots = self.timeline.all()
        return not TOp.changed_within_n_steps(snapshots, pos_key, n)

    def idle_for_n_steps(self, n: int = 20, action_key: str = "action") -> bool:
        snapshots = self.timeline.all()
        return TOp.holds_for_n_steps(
            snapshots,
            lambda s: s.get(action_key) == "IDLE",
            n,
        )

    def envelope_violated_recently(self, n: int = 5, env_key: str = "envelope_ok") -> bool:
        snapshots = self.timeline.all()
        return TOp.eventually(
            snapshots[-n:],
            lambda s: not s.get(env_key, True),
        )
