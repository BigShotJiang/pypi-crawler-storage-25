from typing import Callable, Dict, Any, List


class TemporalOperators:
    """
    Temporal operators over a sequence of snapshots.
    These are low-level building blocks for temporal queries and policies.
    """

    @staticmethod
    def always(snapshots: List[Dict[str, Any]], predicate: Callable[[Dict[str, Any]], bool]) -> bool:
        return all(predicate(s) for s in snapshots)

    @staticmethod
    def eventually(snapshots: List[Dict[str, Any]], predicate: Callable[[Dict[str, Any]], bool]) -> bool:
        return any(predicate(s) for s in snapshots)

    @staticmethod
    def holds_for_n_steps(snapshots: List[Dict[str, Any]], predicate: Callable[[Dict[str, Any]], bool], n: int) -> bool:
        if n <= 0:
            return False
        recent = snapshots[-n:]
        return len(recent) == n and all(predicate(s) for s in recent)

    @staticmethod
    def changed_within_n_steps(
        snapshots: List[Dict[str, Any]],
        key: str,
        n: int,
    ) -> bool:
        if n <= 1:
            return False
        recent = snapshots[-n:]
        if len(recent) < 2:
            return False
        values = [s.get(key) for s in recent]
        return len(set(values)) > 1
