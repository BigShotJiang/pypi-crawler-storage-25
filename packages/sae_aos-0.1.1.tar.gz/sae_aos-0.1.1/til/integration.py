from typing import Dict, Any
from .timeline import Timeline
from .queries import TemporalQueries
from .policies import TemporalPolicies


class TemporalInteractionLayer:
    """
    Glue between the organism/UAG loop and the temporal machinery.
    """

    def __init__(self, max_history: int = 256):
        self.timeline = Timeline(max_length=max_history)
        self.queries = TemporalQueries(self.timeline)
        self.policies = TemporalPolicies(self.queries)

    def record_snapshot(self, snapshot: Dict[str, Any]) -> None:
        """
        Record a new snapshot each control tick.
        """
        self.timeline.append(snapshot)

    def adjust_decision(self, decision: Dict[str, Any]) -> Dict[str, Any]:
        """
        Given a proposed decision (e.g., from behavior/UAG),
        return a possibly modified decision based on temporal policies.
        """
        return self.policies.evaluate(decision)
