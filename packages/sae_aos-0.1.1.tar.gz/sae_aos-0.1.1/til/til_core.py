class TemporalInteractionLayer:
    """
    Minimal, stable TIL implementation.
    Records snapshots and optionally overrides decisions.
    """

    def __init__(self):
        self.history = []

    def record_snapshot(self, snapshot):
        self.history.append(snapshot)

    def adjust_decision(self, decision):
        # No override by default — stable behavior
        return decision
