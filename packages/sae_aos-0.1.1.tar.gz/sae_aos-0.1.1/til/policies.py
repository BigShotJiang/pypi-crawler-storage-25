from typing import Dict, Any, Optional
from .queries import TemporalQueries


class TemporalPolicies:
    """
    Temporal policies that can influence behavior or safety decisions.
    These are high-level rules like:
    - "If stuck for N steps, trigger recovery behavior."
    - "If idle too long, explore."
    """

    def __init__(self, queries: TemporalQueries):
        self.queries = queries

    def evaluate(self, current_decision: Dict[str, Any]) -> Dict[str, Any]:
        """
        Take a current decision (e.g., behavior or action) and optionally modify it
        based on temporal context.
        """
        decision = dict(current_decision)

        if self.queries.is_stuck_position(n=15):
            decision["override"] = "RECOVERY"
            decision["reason"] = "stuck_position"

        elif self.queries.idle_for_n_steps(n=30):
            decision["override"] = "EXPLORE"
            decision["reason"] = "idle_too_long"

        elif self.queries.envelope_violated_recently(n=5):
            decision["override"] = "SAFE_HALT"
            decision["reason"] = "recent_envelope_violation"

        return decision
