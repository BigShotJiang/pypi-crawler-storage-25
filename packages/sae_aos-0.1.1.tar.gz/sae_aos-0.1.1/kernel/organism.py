"""
S-OS v0.4 — kernel/organism.py
Full organism: SMA-5 memory, drive system, cultural reception, social role.
"""

import random
import hashlib
import time
from typing import Dict, List, Optional, Any


class Organism:
    MAX_SENSORY_BUFFER = 20
    MAX_EPISODIC = 50
    MAX_SEMANTIC = 100
    MAX_PROCEDURAL = 30
    MAX_KERNEL_MEM = 20

    def __init__(self, organism_id: str, species: Dict, saved_state: Optional[Dict] = None):
        self.id = organism_id
        self.species = species
        self.sensory_buffer: List[Dict] = []
        self.episodic_memory: List[Dict] = []
        self.semantic_memory: List[Dict] = []
        self.procedural_memory: List[Dict] = []
        self.kernel_memory: List[Dict] = []
        self.stability: float = 0.5
        self.curiosity: float = 0.5
        self.compression_pressure: float = 0.0
        self.episodic_density: float = 0.0
        self.semantic_richness: float = 0.0
        self.procedural_complexity: float = 0.0
        self.cultural_lineage: List[Dict] = []
        self.social_role: str = "undefined"
        self.age: int = 0
        if saved_state:
            self._deserialize(saved_state)

    def step(self, world_signals: List[str], peer_views: Dict):
        self.age += 1
        self._sense(world_signals, peer_views)
        self._update_drives()
        self._episodic_rollup()
        self._semantic_formation()
        self._procedural_formation()
        self._classify_social_role()
        self._enforce_limits()

    def _sense(self, signals: List[str], peer_views: Dict):
        entry = {
            "tick": self.age,
            "signals": signals,
            "peer_count": len(peer_views),
            "peer_stability_avg": self._avg_peer_stat(peer_views, "stability"),
            "peer_curiosity_avg": self._avg_peer_stat(peer_views, "curiosity"),
            "ts": time.time(),
        }
        self.sensory_buffer.append(entry)

    def _avg_peer_stat(self, peer_views: Dict, key: str) -> float:
        vals = [v.get(key, 0.5) for v in peer_views.values()]
        return sum(vals) / len(vals) if vals else 0.5

    def _update_drives(self):
        peer_pull = self.sensory_buffer[-1].get("peer_stability_avg", self.stability) if self.sensory_buffer else self.stability
        self.stability += 0.1 * (peer_pull - self.stability) + random.gauss(0, 0.02)
        self.stability = max(0.0, min(1.0, self.stability))
        last_signals = self.sensory_buffer[-1]["signals"] if self.sensory_buffer else []
        novelty = self._signal_novelty(last_signals)
        self.curiosity += 0.15 * novelty - 0.05 * (self.curiosity - 0.3)
        self.curiosity = max(0.0, min(1.0, self.curiosity))
        self.compression_pressure = len(self.episodic_memory) / self.MAX_EPISODIC
        self.episodic_density = len(self.episodic_memory) / max(1, self.age)
        self.semantic_richness = len(self.semantic_memory) / self.MAX_SEMANTIC
        self.procedural_complexity = len(self.procedural_memory) / self.MAX_PROCEDURAL

    def _signal_novelty(self, signals: List[str]) -> float:
        known = set()
        for ep in self.episodic_memory[-10:]:
            known.update(ep.get("dominant_signals", []))
        novel = [s for s in signals if s not in known]
        return len(novel) / max(1, len(signals))

    def _episodic_rollup(self):
        if len(self.sensory_buffer) < 3:
            return
        window = self.sensory_buffer[-3:]
        all_signals = [s for e in window for s in e["signals"]]
        freq: Dict[str, int] = {}
        for s in all_signals:
            freq[s] = freq.get(s, 0) + 1
        dominant = sorted(freq, key=freq.get, reverse=True)[:3]
        episode = {
            "id": self._uid(),
            "tick": self.age,
            "dominant_signals": dominant,
            "stability_at": round(self.stability, 3),
            "curiosity_at": round(self.curiosity, 3),
            "summary": f"tick={self.age} signals={dominant} stab={self.stability:.2f}",
            "origin": self.id,
            "lineage_depth": 0,
        }
        self.episodic_memory.append(episode)

    def _semantic_formation(self):
        if len(self.episodic_memory) < 5 or self.age % 5 != 0:
            return
        recent = self.episodic_memory[-5:]
        avg_stab = sum(e["stability_at"] for e in recent) / 5
        all_sigs = [s for e in recent for s in e["dominant_signals"]]
        top = max(set(all_sigs), key=all_sigs.count) if all_sigs else "unknown"
        fact = {
            "id": self._uid(),
            "tick": self.age,
            "fact": f"High-signal pattern: '{top}' dominates when stability={avg_stab:.2f}",
            "confidence": min(1.0, 0.4 + avg_stab * 0.6),
            "origin": self.id,
            "lineage_depth": 0,
        }
        if fact["fact"] not in {s["fact"] for s in self.semantic_memory}:
            self.semantic_memory.append(fact)

    def _procedural_formation(self):
        if len(self.semantic_memory) < 3 or self.age % 10 != 0:
            return
        top_facts = sorted(self.semantic_memory, key=lambda x: x["confidence"], reverse=True)[:2]
        rule = {
            "id": self._uid(),
            "tick": self.age,
            "rule": f"IF [{top_facts[0]['fact'][:40]}] THEN increase stability bias",
            "derived_from": [f["id"] for f in top_facts],
            "origin": self.id,
            "lineage_depth": 0,
        }
        if rule["rule"] not in {r["rule"] for r in self.procedural_memory}:
            self.procedural_memory.append(rule)

    def _classify_social_role(self):
        if self.stability > 0.75 and self.curiosity < 0.4:
            self.social_role = "stabilizer"
        elif self.stability > 0.65 and self.semantic_richness > 0.5:
            self.social_role = "leader"
        elif self.curiosity > 0.7 and self.procedural_complexity < 0.3:
            self.social_role = "innovator"
        elif self.episodic_density > 0.6 and self.semantic_richness > 0.4:
            self.social_role = "cultural_hub"
        elif self.stability < 0.3 and self.curiosity < 0.3:
            self.social_role = "isolate"
        else:
            self.social_role = "follower"

    def receive_culture(self, artifact: Dict, sender_id: str, tick: int):
        lineage_depth = artifact.get("lineage_depth", 0) + 1
        artifact_copy = dict(artifact)
        artifact_copy["lineage_depth"] = lineage_depth
        artifact_copy["received_from"] = sender_id
        artifact_copy["received_tick"] = tick
        atype = artifact.get("type")
        if atype == "episodic":
            compressed = {
                "id": self._uid(), "tick": tick,
                "dominant_signals": artifact.get("dominant_signals", []),
                "stability_at": artifact.get("stability_at", 0.5),
                "curiosity_at": artifact.get("curiosity_at", 0.5),
                "summary": f"[imported] {artifact.get('summary', '')}",
                "origin": artifact.get("origin", sender_id),
                "lineage_depth": lineage_depth,
            }
            self.episodic_memory.append(compressed)
        elif atype == "semantic":
            fact = dict(artifact)
            fact["id"] = self._uid()
            fact["lineage_depth"] = lineage_depth
            if fact.get("fact") not in {s["fact"] for s in self.semantic_memory}:
                self.semantic_memory.append(fact)
        elif atype == "procedural":
            rule = dict(artifact)
            rule["id"] = self._uid()
            rule["lineage_depth"] = lineage_depth
            if rule.get("rule") not in {r["rule"] for r in self.procedural_memory}:
                self.procedural_memory.append(rule)
        self.cultural_lineage.append({
            "artifact_id": artifact_copy.get("id"),
            "from": sender_id, "type": atype,
            "lineage_depth": lineage_depth, "tick": tick,
        })
        self._enforce_limits()

    def _enforce_limits(self):
        if len(self.sensory_buffer) > self.MAX_SENSORY_BUFFER:
            self.sensory_buffer = self.sensory_buffer[-self.MAX_SENSORY_BUFFER:]
        if len(self.episodic_memory) > self.MAX_EPISODIC:
            self.episodic_memory = self.episodic_memory[-self.MAX_EPISODIC:]
        if len(self.semantic_memory) > self.MAX_SEMANTIC:
            self.semantic_memory = sorted(
                self.semantic_memory, key=lambda x: x.get("confidence", 0), reverse=True
            )[:self.MAX_SEMANTIC]
        if len(self.procedural_memory) > self.MAX_PROCEDURAL:
            self.procedural_memory = self.procedural_memory[-self.MAX_PROCEDURAL:]

    def public_state(self) -> Dict:
        return {
            "id": self.id, "age": self.age,
            "stability": round(self.stability, 4),
            "curiosity": round(self.curiosity, 4),
            "compression_pressure": round(self.compression_pressure, 4),
            "episodic_density": round(self.episodic_density, 4),
            "semantic_richness": round(self.semantic_richness, 4),
            "procedural_complexity": round(self.procedural_complexity, 4),
            "episodic_count": len(self.episodic_memory),
            "semantic_count": len(self.semantic_memory),
            "procedural_count": len(self.procedural_memory),
            "cultural_imports": len(self.cultural_lineage),
            "social_role": self.social_role,
            "top_episodic": self.episodic_memory[-1] if self.episodic_memory else None,
            "top_semantic": (
                max(self.semantic_memory, key=lambda x: x.get("confidence", 0))
                if self.semantic_memory else None
            ),
        }

    def serialize(self) -> Dict:
        return {
            "id": self.id, "age": self.age,
            "stability": self.stability, "curiosity": self.curiosity,
            "compression_pressure": self.compression_pressure,
            "episodic_density": self.episodic_density,
            "semantic_richness": self.semantic_richness,
            "procedural_complexity": self.procedural_complexity,
            "sensory_buffer": self.sensory_buffer,
            "episodic_memory": self.episodic_memory,
            "semantic_memory": self.semantic_memory,
            "procedural_memory": self.procedural_memory,
            "kernel_memory": self.kernel_memory,
            "cultural_lineage": self.cultural_lineage,
            "social_role": self.social_role,
        }

    def _deserialize(self, s: Dict):
        self.age = s.get("age", 0)
        self.stability = s.get("stability", 0.5)
        self.curiosity = s.get("curiosity", 0.5)
        self.compression_pressure = s.get("compression_pressure", 0.0)
        self.episodic_density = s.get("episodic_density", 0.0)
        self.semantic_richness = s.get("semantic_richness", 0.0)
        self.procedural_complexity = s.get("procedural_complexity", 0.0)
        self.sensory_buffer = s.get("sensory_buffer", [])
        self.episodic_memory = s.get("episodic_memory", [])
        self.semantic_memory = s.get("semantic_memory", [])
        self.procedural_memory = s.get("procedural_memory", [])
        self.kernel_memory = s.get("kernel_memory", [])
        self.cultural_lineage = s.get("cultural_lineage", [])
        self.social_role = s.get("social_role", "undefined")

    def _uid(self) -> str:
        raw = f"{self.id}-{self.age}-{random.random()}"
        return hashlib.md5(raw.encode()).hexdigest()[:10]
