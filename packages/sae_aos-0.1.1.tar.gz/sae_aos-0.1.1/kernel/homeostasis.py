"""
S-OS Layer 4 — kernel/homeostasis.py
Social Homeostasis Engine

Responsibilities:
- Role stabilization (roles persist, require sustained evidence to change)
- Social feedback loops (drives adjust based on social context)
- Threat-response coordination across the population
- Cultural load balancing (prevent overload / saturation)
- Stale culture decay
"""

import logging
from typing import Dict, List, Tuple

log = logging.getLogger("homeostasis")

# How many consecutive ticks a role must be "earned" before it locks in
ROLE_LOCK_THRESHOLD = 5

# Cultural load limits per organism
MAX_CULTURAL_IMPORTS_PER_TICK = 2
STALE_CULTURE_AGE = 30          # ticks before imported culture decays
SEMANTIC_SATURATION_LIMIT = 80  # % of MAX_SEMANTIC before redistribution kicks in


class HomeostasisEngine:
    """
    Runs after every social dynamics tick.
    Operates on the full population to enforce ecosystem-level stability.
    """

    def __init__(self):
        # role_candidate[org_id] = {role: str, streak: int}
        self.role_candidates: Dict[str, Dict] = {}

    # ----------------------------------------------------------
    def run(self, organisms: Dict, social_graph, current_tick: int):
        """
        Full homeostasis pass. Call this every culture tick.
        """
        self._stabilize_roles(organisms)
        self._social_feedback_loops(organisms, social_graph)
        self._threat_response_coordination(organisms, social_graph)
        self._cultural_load_balancing(organisms, current_tick)
        self._decay_stale_culture(organisms, current_tick)

    # ----------------------------------------------------------
    # 1. ROLE STABILIZATION
    # ----------------------------------------------------------
    def _stabilize_roles(self, organisms: Dict):
        """
        Roles require ROLE_LOCK_THRESHOLD consecutive ticks of evidence.
        Once locked, can only be displaced by equal or longer counter-streak.
        """
        for oid, org in organisms.items():
            candidate = org.social_role  # what the organism "wants" to be right now

            if oid not in self.role_candidates:
                self.role_candidates[oid] = {"role": candidate, "streak": 1, "locked": None}
                continue

            rec = self.role_candidates[oid]

            if candidate == rec["role"]:
                rec["streak"] += 1
            else:
                # Reset streak for new candidate
                rec["role"] = candidate
                rec["streak"] = 1

            # Lock the role once threshold met
            if rec["streak"] >= ROLE_LOCK_THRESHOLD:
                rec["locked"] = rec["role"]

            # Apply locked role back to organism
            if rec["locked"]:
                org.social_role = rec["locked"]

            log.debug(f"  [roles] {oid}: candidate={candidate} streak={rec['streak']} locked={rec['locked']}")

    # ----------------------------------------------------------
    # 2. SOCIAL FEEDBACK LOOPS
    # ----------------------------------------------------------
    def _social_feedback_loops(self, organisms: Dict, social_graph):
        """
        Organisms adjust their drives based on social context:
        - High local influence → stability boost
        - Isolated → curiosity spike (explore to reconnect)
        - In dense cluster → compression pressure relief
        - High cultural imports → curiosity dampening
        """
        clusters = social_graph.detect_clusters()
        cluster_map = {}
        for cluster in clusters:
            for oid in cluster:
                cluster_map[oid] = len(cluster)

        for oid, org in organisms.items():
            influence = social_graph.influence_of(oid)
            cluster_size = cluster_map.get(oid, 1)
            cultural_imports = len(org.cultural_lineage)

            # Influence → stability boost
            if influence > 0.3:
                org.stability = min(1.0, org.stability + 0.02 * influence)

            # Isolate → curiosity spike
            if cluster_size == 1:
                org.curiosity = min(1.0, org.curiosity + 0.05)

            # Dense cluster → reduce compression pressure
            if cluster_size >= 3:
                org.compression_pressure = max(0.0, org.compression_pressure - 0.05)

            # Cultural overload → dampen curiosity
            if cultural_imports > 10:
                org.curiosity = max(0.0, org.curiosity - 0.03)

            log.debug(f"  [feedback] {oid}: inf={influence:.2f} cluster={cluster_size} imports={cultural_imports}")

    # ----------------------------------------------------------
    # 3. THREAT-RESPONSE COORDINATION
    # ----------------------------------------------------------
    def _threat_response_coordination(self, organisms: Dict, social_graph):
        """
        When threat_signal is in any organism's recent sensory buffer,
        broadcast a stability correction across connected organisms.
        Leaders and stabilizers amplify; isolates are unaffected.
        """
        threat_detected = False
        threat_sources = []

        for oid, org in organisms.items():
            recent_signals = []
            for entry in org.sensory_buffer[-3:]:
                recent_signals.extend(entry.get("signals", []))
            if "threat_signal" in recent_signals:
                threat_detected = True
                threat_sources.append(oid)

        if not threat_detected:
            return

        log.info(f"  [threat] Threat detected from: {threat_sources} — coordinating response")

        for oid, org in organisms.items():
            if org.social_role in ("leader", "stabilizer"):
                # Leaders radiate calm
                org.stability = min(1.0, org.stability + 0.05)
                # Transmit stability boost to neighbors
                for neighbor_id, weight in social_graph.neighbors_weighted(oid):
                    if neighbor_id in organisms:
                        neighbor = organisms[neighbor_id]
                        boost = 0.03 * weight
                        neighbor.stability = min(1.0, neighbor.stability + boost)
                        log.debug(f"    {oid} -> {neighbor_id}: stability boost={boost:.3f}")
            elif org.social_role == "isolate":
                # Isolates spiral — slight destabilization
                org.stability = max(0.0, org.stability - 0.02)

    # ----------------------------------------------------------
    # 4. CULTURAL LOAD BALANCING
    # ----------------------------------------------------------
    def _cultural_load_balancing(self, organisms: Dict, current_tick: int):
        """
        Prevent cultural overload:
        - Cap recent cultural imports per tick
        - Redistribute excess procedural rules to underloaded organisms
        - Compress shared episodes (deduplicate across population)
        """
        # Find culturally overloaded organisms
        overloaded = []
        underloaded = []

        for oid, org in organisms.items():
            recent_imports = sum(
                1 for entry in org.cultural_lineage
                if current_tick - entry.get("tick", 0) <= 5
            )
            if recent_imports > MAX_CULTURAL_IMPORTS_PER_TICK * 5:
                overloaded.append(oid)
            elif len(org.procedural_memory) < 5 and len(org.episodic_memory) > 10:
                underloaded.append(oid)

        # Redistribute: take a procedural rule from overloaded, give to underloaded
        for oid in overloaded:
            if not underloaded:
                break
            org = organisms[oid]
            if not org.procedural_memory:
                continue
            # Move lowest-confidence procedural rule
            rule = org.procedural_memory.pop(0)
            target_id = underloaded.pop(0)
            target = organisms[target_id]
            rule["redistributed_from"] = oid
            rule["lineage_depth"] = rule.get("lineage_depth", 0) + 1
            if rule["rule"] not in {r["rule"] for r in target.procedural_memory}:
                target.procedural_memory.append(rule)
                log.info(f"  [load] Redistributed rule from {oid} -> {target_id}")

        # Semantic saturation check — trim lowest confidence facts if near limit
        for oid, org in organisms.items():
            sat = len(org.semantic_memory) / max(1, org.MAX_SEMANTIC)
            if sat > SEMANTIC_SATURATION_LIMIT / 100:
                before = len(org.semantic_memory)
                org.semantic_memory = sorted(
                    org.semantic_memory,
                    key=lambda x: x.get("confidence", 0),
                    reverse=True
                )[:int(org.MAX_SEMANTIC * 0.8)]
                after = len(org.semantic_memory)
                if before != after:
                    log.info(f"  [load] {oid}: semantic saturation trim {before} -> {after}")

    # ----------------------------------------------------------
    # 5. STALE CULTURE DECAY
    # ----------------------------------------------------------
    def _decay_stale_culture(self, organisms: Dict, current_tick: int):
        """
        Remove imported cultural artifacts older than STALE_CULTURE_AGE ticks.
        Applies to episodic and semantic memory items with lineage_depth > 0.
        """
        for oid, org in organisms.items():
            before_ep = len(org.episodic_memory)
            before_sem = len(org.semantic_memory)

            org.episodic_memory = [
                e for e in org.episodic_memory
                if e.get("lineage_depth", 0) == 0
                or (current_tick - e.get("tick", current_tick)) < STALE_CULTURE_AGE
            ]
            org.semantic_memory = [
                s for s in org.semantic_memory
                if s.get("lineage_depth", 0) == 0
                or (current_tick - s.get("tick", current_tick)) < STALE_CULTURE_AGE
            ]

            decayed_ep = before_ep - len(org.episodic_memory)
            decayed_sem = before_sem - len(org.semantic_memory)
            if decayed_ep or decayed_sem:
                log.info(f"  [decay] {oid}: decayed ep={decayed_ep} sem={decayed_sem}")
