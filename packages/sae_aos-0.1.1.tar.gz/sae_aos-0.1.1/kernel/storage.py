"""
S-OS v0.4 — kernel/storage.py
JSON-based state persistence.
"""

import json
import os
import shutil
import logging

log = logging.getLogger("storage")


class Storage:
    def load(self, path: str) -> dict:
        if not os.path.exists(path):
            log.info(f"No state file at {path}. Starting fresh.")
            return {}
        try:
            with open(path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            log.error(f"Failed to load {path}: {e}")
            return {}

    def save(self, path: str, data: dict):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2, default=str)
            shutil.move(tmp, path)
        except IOError as e:
            log.error(f"Failed to save {path}: {e}")
