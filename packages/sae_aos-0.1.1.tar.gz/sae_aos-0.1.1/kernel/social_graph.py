"""
S-OS v0.4 — kernel/social_graph.py
Dynamic Directed Social Graph with influence, decay, clusters, lineage.
"""

import random
from typing import Dict, List, Tuple, Optional, TYPE_CHECKING
from collections import defaultdict

if TYPE_CHECKING:
    from kernel.organism import Organism


class SocialGraph:
    def __init__(self, base_weight: float = 0.1):
        self.edges: Dict[str, Dict[str, float]] = defaultdict(dict)
        self.base_weight = base_weight
        self.lineage_registry: Dict[str, List[str]] = {}

    def update(self, scores: Dict[str, float], organisms: Dict):
        org_ids = list(organisms.keys())
        for sender_id, sender_score in scores.items():
            for receiver_id in org_ids:
                if receiver_id == sender_id:
                    continue
                receiver_score = scores.get(receiver_id, 0.5)
                delta = sender_score - receiver_score
                if delta <= 0:
                    continue
                current = self.edges[sender_id].get(receiver_id, self.base_weight)
                new_weight = min(1.0, current + 0.1 * delta)
                self.edges[sender_id][receiver_id] = round(new_weight, 4)

    def decay(self, factor: float = 0.95):
        to_prune = []
        for sender in list(self.edges.keys()):
            for receiver in list(self.edges[sender].keys()):
                self.edges[sender][receiver] *= factor
                if self.edges[sender][receiver] < 0.01:
                    to_prune.append((sender, receiver))
        for sender, receiver in to_prune:
            del self.edges[sender][receiver]

    def neighbors_weighted(self, sender_id: str) -> List[Tuple[str, float]]:
        return list(self.edges.get(sender_id, {}).items())

    def influence_of(self, org_id: str) -> float:
        return round(sum(self.edges.get(org_id, {}).values()), 4)

    def detect_clusters(self) -> List[List[str]]:
        adjacency: Dict[str, set] = defaultdict(set)
        for sender, receivers in self.edges.items():
            for receiver in receivers:
                adjacency[sender].add(receiver)
                adjacency[receiver].add(sender)
        visited = set()
        clusters = []
        for node in set(adjacency.keys()):
            if node in visited:
                continue
            cluster = []
            queue = [node]
            while queue:
                n = queue.pop(0)
                if n in visited:
                    continue
                visited.add(n)
                cluster.append(n)
                queue.extend(adjacency[n] - visited)
            clusters.append(sorted(cluster))
        return clusters

    def record_lineage(self, artifact_id: str, chain: List[str]):
        self.lineage_registry[artifact_id] = chain

    def lineage_of(self, artifact_id: str) -> List[str]:
        return self.lineage_registry.get(artifact_id, [])

    def snapshot(self) -> Dict:
        return {
            "edges": {s: dict(r) for s, r in self.edges.items()},
            "clusters": self.detect_clusters(),
            "influence_totals": {org: self.influence_of(org) for org in self.edges},
            "lineage_count": len(self.lineage_registry),
        }
