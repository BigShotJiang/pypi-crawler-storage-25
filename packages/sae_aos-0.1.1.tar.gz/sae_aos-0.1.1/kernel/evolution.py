"""
S-OS Layer 5 — kernel/evolution.py
Meta-Evolution Engine

The species itself evolves — not just the organisms.

Responsibilities:
- Mutate species-level parameters (drive weights, cultural bandwidth,
  role thresholds, influence decay, episodic compression)
- Ecosystem self-tuning based on stability/diversity/collapse signals
- Record evolutionary memory (past collapses, equilibria, cultural waves)
- Trigger speciation when sub-populations diverge beyond threshold
"""

import random
import copy
import logging
from typing import Dict, List, Any

log = logging.getLogger("evolution")

# How often meta-evolution runs (in culture ticks, not world ticks)
EVOLUTION_INTERVAL = 10   # every 10 culture ticks

# Divergence threshold to trigger speciation
SPECIATION_DIVERGENCE_THRESHOLD = 0.35

# Max mutations per evolution tick
MAX_MUTATIONS_PER_TICK = 3

# Evolutionary memory max entries
MAX_EVO_MEMORY = 50


class MetaEvolutionEngine:
    def __init__(self, base_species: Dict):
        self.base_species = copy.deepcopy(base_species)
        self.culture_tick_count = 0

        # Mutable species parameters
        self.species_params = {
            "drive_weights": {
                "stability_pull": 0.10,
                "curiosity_novelty": 0.15,
                "compression_relief": 0.05,
            },
            "cultural_bandwidth": 3,          # max transmissions per culture tick
            "role_lock_threshold": 5,         # ticks to lock a role
            "influence_decay_rate": 0.95,     # per culture tick
            "episodic_compression_window": 3, # sensory events per episode
            "stale_culture_age": 30,          # ticks before decay
        }

        # Evolutionary memory
        self.evo_memory: List[Dict] = []
        self.generation: int = 0

        # Speciation registry: species_id -> species_params clone
        self.species_registry: Dict[str, Dict] = {
            "alpha": copy.deepcopy(self.species_params)
        }

        # Map organism -> species assignment
        self.organism_species: Dict[str, str] = {}

    # ----------------------------------------------------------
    def run(self, organisms: Dict, social_graph, current_tick: int) -> Dict:
        """
        Called every culture tick. Returns any mutations applied.
        Full evolution pass runs every EVOLUTION_INTERVAL culture ticks.
        """
        self.culture_tick_count += 1

        if self.culture_tick_count % EVOLUTION_INTERVAL != 0:
            return {}

        self.generation += 1
        log.info(f"=== META-EVOLUTION Generation {self.generation} (tick={current_tick}) ===")

        # 1. Assess ecosystem health
        health = self._assess_ecosystem(organisms, social_graph)
        log.info(f"  Ecosystem health: {health}")

        # 2. Record evolutionary memory
        self._record_evo_memory(health, current_tick)

        # 3. Mutate species params based on health
        mutations = self._mutate_species_params(health)
        if mutations:
            log.info(f"  Mutations applied: {mutations}")

        # 4. Apply mutations to living organisms
        self._apply_mutations_to_organisms(organisms, mutations)

        # 5. Check for speciation
        self._check_speciation(organisms, social_graph, current_tick)

        return mutations

    # ----------------------------------------------------------
    # ECOSYSTEM ASSESSMENT
    # ----------------------------------------------------------
    def _assess_ecosystem(self, organisms: Dict, social_graph) -> Dict:
        stabilities = [o.stability for o in organisms.values()]
        curiosities = [o.curiosity for o in organisms.values()]
        roles = [o.social_role for o in organisms.values()]
        role_diversity = len(set(roles)) / max(1, len(roles))

        clusters = social_graph.detect_clusters()
        cluster_sizes = [len(c) for c in clusters]
        influence_totals = [social_graph.influence_of(oid) for oid in organisms]
        influence_imbalance = max(influence_totals) - min(influence_totals) if influence_totals else 0

        avg_stab = sum(stabilities) / len(stabilities)
        avg_cur = sum(curiosities) / len(curiosities)

        # Detect collapse: avg stability < 0.3
        collapse = avg_stab < 0.3

        # Detect cultural saturation: all organisms near semantic limit
        sat_scores = [
            len(o.semantic_memory) / o.MAX_SEMANTIC for o in organisms.values()
        ]
        cultural_saturation = sum(sat_scores) / len(sat_scores)

        return {
            "avg_stability": round(avg_stab, 3),
            "avg_curiosity": round(avg_cur, 3),
            "role_diversity": round(role_diversity, 3),
            "cluster_count": len(clusters),
            "influence_imbalance": round(influence_imbalance, 3),
            "cultural_saturation": round(cultural_saturation, 3),
            "collapse": collapse,
            "generation": self.generation,
        }

    # ----------------------------------------------------------
    # EVOLUTIONARY MEMORY
    # ----------------------------------------------------------
    def _record_evo_memory(self, health: Dict, tick: int):
        event_type = "equilibrium"
        if health["collapse"]:
            event_type = "collapse"
        elif health["cultural_saturation"] > 0.8:
            event_type = "cultural_wave"
        elif health["role_diversity"] > 0.8:
            event_type = "diversity_peak"

        entry = {
            "generation": self.generation,
            "tick": tick,
            "event_type": event_type,
            "snapshot": health,
        }
        self.evo_memory.append(entry)
        if len(self.evo_memory) > MAX_EVO_MEMORY:
            self.evo_memory.pop(0)

        log.info(f"  Evo memory: [{event_type}] gen={self.generation}")

    # ----------------------------------------------------------
    # SPECIES PARAMETER MUTATION
    # ----------------------------------------------------------
    def _mutate_species_params(self, health: Dict) -> Dict:
        mutations = {}

        # If collapsing: boost stability pull, reduce influence decay (slower decay = more cohesion)
        if health["collapse"]:
            delta = random.uniform(0.01, 0.03)
            self.species_params["drive_weights"]["stability_pull"] = min(
                0.30, self.species_params["drive_weights"]["stability_pull"] + delta
            )
            mutations["stability_pull"] = f"+{delta:.3f} (collapse response)"

            self.species_params["influence_decay_rate"] = min(
                0.99, self.species_params["influence_decay_rate"] + 0.01
            )
            mutations["influence_decay_rate"] = "slowed (collapse response)"

        # If culturally saturated: tighten episodic compression window
        if health["cultural_saturation"] > 0.75:
            self.species_params["episodic_compression_window"] = max(
                2, self.species_params["episodic_compression_window"] - 1
            )
            mutations["episodic_compression_window"] = "tightened (saturation)"
            self.species_params["stale_culture_age"] = max(
                10, self.species_params["stale_culture_age"] - 5
            )
            mutations["stale_culture_age"] = "shortened (saturation)"

        # If low diversity: boost curiosity novelty weight
        if health["role_diversity"] < 0.4:
            delta = random.uniform(0.01, 0.04)
            self.species_params["drive_weights"]["curiosity_novelty"] = min(
                0.40, self.species_params["drive_weights"]["curiosity_novelty"] + delta
            )
            mutations["curiosity_novelty"] = f"+{delta:.3f} (low diversity)"

        # If influence imbalance too high: increase cultural bandwidth
        if health["influence_imbalance"] > 0.5:
            self.species_params["cultural_bandwidth"] = min(
                6, self.species_params["cultural_bandwidth"] + 1
            )
            mutations["cultural_bandwidth"] = "+1 (imbalance correction)"

        # Random drift mutation (always applies at low magnitude)
        drift_key = random.choice(["role_lock_threshold", "stale_culture_age"])
        drift = random.choice([-1, 0, 1])
        if drift_key == "role_lock_threshold":
            self.species_params["role_lock_threshold"] = max(
                2, min(15, self.species_params["role_lock_threshold"] + drift)
            )
        else:
            self.species_params["stale_culture_age"] = max(
                5, min(60, self.species_params["stale_culture_age"] + drift)
            )
        if drift != 0:
            mutations[drift_key] = f"drift {drift:+d}"

        return mutations

    # ----------------------------------------------------------
    # APPLY MUTATIONS TO ORGANISMS
    # ----------------------------------------------------------
    def _apply_mutations_to_organisms(self, organisms: Dict, mutations: Dict):
        if not mutations:
            return

        sp = self.species_params
        for oid, org in organisms.items():
            # Adjust drive update dynamics based on evolved weights
            stab_pull = sp["drive_weights"]["stability_pull"]
            cur_novelty = sp["drive_weights"]["curiosity_novelty"]

            # Nudge organisms toward evolved parameter space
            # (gentle — doesn't override autonomy)
            org.stability = min(1.0, org.stability + stab_pull * 0.1)
            org.curiosity = min(1.0, org.curiosity + cur_novelty * 0.05)

    # ----------------------------------------------------------
    # SPECIATION
    # ----------------------------------------------------------
    def _check_speciation(self, organisms: Dict, social_graph, current_tick: int):
        """
        If two clusters have diverged beyond threshold in drive profile,
        fork a new species contract for the minority cluster.
        """
        clusters = social_graph.detect_clusters()
        if len(clusters) < 2:
            return

        # Compare the two largest clusters
        clusters_sorted = sorted(clusters, key=len, reverse=True)
        cluster_a = clusters_sorted[0]
        cluster_b = clusters_sorted[1]

        def cluster_avg(cluster, attr):
            vals = [getattr(organisms[oid], attr) for oid in cluster if oid in organisms]
            return sum(vals) / len(vals) if vals else 0.5

        divergence = abs(cluster_avg(cluster_a, "stability") - cluster_avg(cluster_b, "stability")) \
                   + abs(cluster_avg(cluster_a, "curiosity") - cluster_avg(cluster_b, "curiosity"))

        log.info(f"  Speciation check: divergence={divergence:.3f} (threshold={SPECIATION_DIVERGENCE_THRESHOLD})")

        if divergence >= SPECIATION_DIVERGENCE_THRESHOLD:
            # Fork a new species for cluster_b
            new_species_id = f"beta_gen{self.generation}"
            new_params = copy.deepcopy(self.species_params)

            # Minority species gets higher curiosity drive — the divergers explore
            new_params["drive_weights"]["curiosity_novelty"] = min(
                0.40, new_params["drive_weights"]["curiosity_novelty"] + 0.10
            )
            new_params["role_lock_threshold"] = max(2, new_params["role_lock_threshold"] - 1)

            self.species_registry[new_species_id] = new_params

            for oid in cluster_b:
                self.organism_species[oid] = new_species_id

            log.info(
                f"  *** SPECIATION EVENT *** gen={self.generation} tick={current_tick}\n"
                f"      New species: {new_species_id}\n"
                f"      Members: {cluster_b}\n"
                f"      Divergence: {divergence:.3f}"
            )

            # Record in evo memory
            self.evo_memory.append({
                "generation": self.generation,
                "tick": current_tick,
                "event_type": "speciation",
                "new_species": new_species_id,
                "members": cluster_b,
                "divergence": divergence,
            })

    # ----------------------------------------------------------
    # SNAPSHOT
    # ----------------------------------------------------------
    def snapshot(self) -> Dict:
        return {
            "generation": self.generation,
            "species_params": self.species_params,
            "species_registry": list(self.species_registry.keys()),
            "organism_species": self.organism_species,
            "evo_memory_count": len(self.evo_memory),
            "last_events": [e["event_type"] for e in self.evo_memory[-5:]],
        }
