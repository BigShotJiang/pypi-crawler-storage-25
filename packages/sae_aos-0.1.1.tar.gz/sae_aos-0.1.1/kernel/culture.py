"""
S-OS v0.4 — kernel/culture.py
Cultural Transmission Pipeline: influence scoring, artifact selection, transmissions.
"""

import random
from typing import Dict, List, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from kernel.organism import Organism
    from kernel.social_graph import SocialGraph


class CultureEngine:
    INFLUENCE_WEIGHTS = {
        "stability": 0.20,
        "curiosity": 0.15,
        "compression_pressure": 0.10,
        "episodic_density": 0.20,
        "semantic_richness": 0.20,
        "procedural_complexity": 0.15,
    }

    def __init__(self, max_load: int = 3):
        self.max_load = max_load

    def influence_score(self, organism) -> float:
        w = self.INFLUENCE_WEIGHTS
        score = (
            w["stability"] * organism.stability
            + w["curiosity"] * organism.curiosity
            + w["compression_pressure"] * organism.compression_pressure
            + w["episodic_density"] * organism.episodic_density
            + w["semantic_richness"] * organism.semantic_richness
            + w["procedural_complexity"] * organism.procedural_complexity
        )
        return round(min(1.0, max(0.0, score)), 4)

    def _best_artifact(self, organism) -> Dict:
        if organism.procedural_memory:
            art = organism.procedural_memory[-1]
            return {
                "type": "procedural",
                "id": art.get("id"),
                "rule": art.get("rule"),
                "summary": art.get("rule", "")[:80],
                "origin": art.get("origin", organism.id),
                "lineage_depth": art.get("lineage_depth", 0),
                "derived_from": art.get("derived_from", []),
            }
        elif organism.semantic_memory:
            art = max(organism.semantic_memory, key=lambda x: x.get("confidence", 0))
            return {
                "type": "semantic",
                "id": art.get("id"),
                "fact": art.get("fact"),
                "confidence": art.get("confidence", 0.5),
                "summary": art.get("fact", "")[:80],
                "origin": art.get("origin", organism.id),
                "lineage_depth": art.get("lineage_depth", 0),
            }
        elif organism.episodic_memory:
            art = organism.episodic_memory[-1]
            return {
                "type": "episodic",
                "id": art.get("id"),
                "dominant_signals": art.get("dominant_signals", []),
                "stability_at": art.get("stability_at", 0.5),
                "curiosity_at": art.get("curiosity_at", 0.5),
                "summary": art.get("summary", "")[:80],
                "origin": art.get("origin", organism.id),
                "lineage_depth": art.get("lineage_depth", 0),
            }
        return None

    def select_transmissions(self, organisms: Dict, social_graph, max_load: int) -> List[Tuple]:
        scores = {oid: self.influence_score(org) for oid, org in organisms.items()}
        ranked = sorted(scores, key=scores.get, reverse=True)
        transmissions = []
        used_pairs = set()

        for sender_id in ranked:
            if len(transmissions) >= max_load:
                break
            sender = organisms[sender_id]
            artifact = self._best_artifact(sender)
            if not artifact:
                continue
            if artifact.get("lineage_depth", 0) > 5:
                continue
            neighbors = social_graph.neighbors_weighted(sender_id)
            if not neighbors:
                candidates = [oid for oid in organisms if oid != sender_id]
                if not candidates:
                    continue
                receiver_id = random.choice(candidates)
            else:
                ids, weights = zip(*neighbors)
                receiver_id = random.choices(ids, weights=weights)[0]
            pair = (sender_id, receiver_id)
            if pair in used_pairs:
                continue
            used_pairs.add(pair)
            transmissions.append((sender_id, receiver_id, artifact))

        return transmissions
