"""
S-OS v0.4 + Layer 4 + Layer 5 — kernel/kernel.py
Full stack: Individual Cognition + Multi-Organism + Social Dynamics
           + Social Homeostasis + Meta-Evolution + Speciation
"""

import time
import random
import logging
from typing import Dict, List, Optional
from kernel.organism import Organism
from kernel.storage import Storage
from kernel.culture import CultureEngine
from kernel.social_graph import SocialGraph
from kernel.homeostasis import HomeostasisEngine
from kernel.evolution import MetaEvolutionEngine

logging.basicConfig(level=logging.INFO, format="[KERNEL] %(asctime)s %(message)s")
log = logging.getLogger("kernel")


class Kernel:
    def __init__(
        self,
        state_path: str = "data/organism_state.json",
        species_path: str = "data/species.json",
        max_organisms: int = 5,
        tick_interval: float = 1.0,
        culture_tick_every: int = 5,
        max_cultural_load_per_tick: int = 3,
    ):
        self.state_path = state_path
        self.species_path = species_path
        self.max_organisms = max_organisms
        self.tick_interval = tick_interval
        self.culture_tick_every = culture_tick_every
        self.max_cultural_load = max_cultural_load_per_tick

        self.storage = Storage()
        self.organisms: Dict[str, Organism] = {}
        self.world_signals: List[str] = []
        self.ticks: int = 0
        self.start_tick: int = 0

        self.culture_engine = CultureEngine(max_load=max_cultural_load_per_tick)
        self.social_graph = SocialGraph()
        self.homeostasis = HomeostasisEngine()
        self.species = {}
        self.evolution = None   # initialized after species loads

        self._boot()

    def _boot(self):
        state = self.storage.load(self.state_path)
        self.species = self.storage.load(self.species_path)
        self.ticks = state.get("ticks", 0)
        self.start_tick = state.get("start_tick", self.ticks)
        self.world_signals = state.get("world_signals", [])
        saved_orgs = state.get("organisms", {})

        self.evolution = MetaEvolutionEngine(self.species)

        if not saved_orgs:
            log.info("Bootstrapping fresh population.")
            for i in range(1, self.max_organisms + 1):
                oid = f"org{i}"
                self.organisms[oid] = Organism(oid, self.species)
        else:
            for oid, org_state in saved_orgs.items():
                self.organisms[oid] = Organism(oid, self.species, saved_state=org_state)

        log.info(f"Booted. Population={list(self.organisms.keys())} Tick={self.ticks}")

    def run(self, max_ticks: Optional[int] = None):
        log.info("Kernel running [L1+L2+L3+L4+L5 active]...")
        try:
            while True:
                self._tick()
                if max_ticks and self.ticks >= self.start_tick + max_ticks:
                    log.info(f"Reached max_ticks={max_ticks}. Halting.")
                    break
                time.sleep(self.tick_interval)
        except KeyboardInterrupt:
            log.info("Interrupted.")
        finally:
            self._persist()

    def _tick(self):
        self.ticks += 1
        signals = self._generate_world_signals()
        log.info(f"=== TICK {self.ticks} | signals={signals} ===")
        population_views = {oid: o.public_state() for oid, o in self.organisms.items()}
        for oid, organism in self.organisms.items():
            peers = {k: v for k, v in population_views.items() if k != oid}
            organism.step(signals, peers)
        if self.ticks % self.culture_tick_every == 0:
            self._run_social_dynamics()
        self._persist()
        self._log_population()

    def _run_social_dynamics(self):
        log.info(f"--- Social + Homeostasis + Evolution (tick={self.ticks}) ---")

        # L3: Cultural transmission
        scores = {oid: self.culture_engine.influence_score(org) for oid, org in self.organisms.items()}
        self.social_graph.update(scores, self.organisms)
        transmissions = self.culture_engine.select_transmissions(
            self.organisms, self.social_graph, self.max_cultural_load
        )
        for sender_id, receiver_id, artifact in transmissions:
            self.organisms[receiver_id].receive_culture(artifact, sender_id, self.ticks)
            log.info(f"  {sender_id} -> {receiver_id}: [{artifact['type']}] '{artifact['summary'][:55]}'")
        self.social_graph.decay(factor=self.evolution.species_params.get("influence_decay_rate", 0.95))

        # L4: Homeostasis
        self.homeostasis.run(self.organisms, self.social_graph, self.ticks)

        # L5: Meta-evolution
        mutations = self.evolution.run(self.organisms, self.social_graph, self.ticks)
        if mutations:
            log.info(f"  [evolution] params mutated: {list(mutations.keys())}")

    def _generate_world_signals(self) -> List[str]:
        signal_pool = [
            "resource_spike", "resource_drought", "entropy_wave",
            "stability_pulse", "anomaly_detected", "quiet",
            "knowledge_bloom", "threat_signal", "cooperation_call",
        ]
        count = random.choices([0, 1, 2], weights=[0.4, 0.4, 0.2])[0]
        signals = random.sample(signal_pool, count) if count else ["quiet"]
        self.world_signals = signals
        return signals

    def population_view(self) -> Dict:
        return {
            "ticks": self.ticks,
            "social_graph": self.social_graph.snapshot(),
            "homeostasis": {
                oid: {
                    "locked_role": self.homeostasis.role_candidates.get(oid, {}).get("locked"),
                    "role_streak": self.homeostasis.role_candidates.get(oid, {}).get("streak", 0),
                }
                for oid in self.organisms
            },
            "evolution": self.evolution.snapshot(),
            "organisms": {oid: o.public_state() for oid, o in self.organisms.items()},
        }

    def _persist(self):
        state = {
            "ticks": self.ticks,
            "start_tick": self.start_tick,
            "world_signals": self.world_signals,
            "organisms": {oid: o.serialize() for oid, o in self.organisms.items()},
        }
        self.storage.save(self.state_path, state)

    def _log_population(self):
        evo_snap = self.evolution.snapshot()
        for oid, org in self.organisms.items():
            ps = org.public_state()
            influence = self.social_graph.influence_of(oid)
            locked = self.homeostasis.role_candidates.get(oid, {}).get("locked", "-")
            species_id = evo_snap["organism_species"].get(oid, "alpha")
            log.info(
                f"  [{oid}|{species_id}] role={ps['social_role']} locked={locked} "
                f"stab={ps['stability']:.2f} cur={ps['curiosity']:.2f} inf={influence:.2f} "
                f"ep={ps['episodic_count']} sem={ps['semantic_count']} proc={ps['procedural_count']}"
            )
