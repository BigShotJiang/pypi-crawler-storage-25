# S-OS v0.4 kernel package
