class BehaviorLayer2D:
    def compute_action(self, state):
        tx, ty = state.get("target_x", 0), state.get("target_y", 0)
        x, y = state.get("x", 0), state.get("y", 0)
        ax = tx - x
        ay = ty - y
        return {"ax": ax, "ay": ay}
