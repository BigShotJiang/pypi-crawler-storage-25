import math

class SafetyLayer2D:
    def __init__(self, max_accel=2.0):
        self.max_accel = max_accel

    def apply(self, action, state):
        ax, ay = action["ax"], action["ay"]
        mag = math.sqrt(ax*ax + ay*ay)
        if mag > self.max_accel:
            ax = ax / mag * self.max_accel
            ay = ay / mag * self.max_accel
        return {"ax": ax, "ay": ay}
