class UniversalAutonomyGovernor:
    def __init__(self, behavior_layer, safety_layer, envelope_layer=None, til=None, dt=0.1):
        self.behavior = behavior_layer
        self.safety = safety_layer
        self.envelope = envelope_layer
        self.til = til
        self.dt = dt

    def decide(self, state):
        action = self.behavior.compute_action(state)
        action = self.safety.apply(action, state)
        if self.envelope:
            action = self.envelope.apply(action, state)
        if self.til:
            self.til.record_snapshot({"state": state, "action": action})
            action = self.til.adjust_decision(action)
        return action
