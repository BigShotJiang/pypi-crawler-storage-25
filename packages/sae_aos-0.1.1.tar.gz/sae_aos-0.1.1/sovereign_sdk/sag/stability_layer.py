class StabilityLayer2D:
    def stabilize(self, action):
        return action
