def organism_step(state, action, dt=0.1):
    state["x"] += action["ax"] * dt
    state["y"] += action["ay"] * dt
    return state
