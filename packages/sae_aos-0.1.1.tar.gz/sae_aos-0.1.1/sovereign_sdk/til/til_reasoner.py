from collections import defaultdict
from datetime import datetime, timezone
from til_core import load_anchors


def _parse_iso(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def find_unresolved_intentions():
    """
    Very simple heuristic:
    - Future anchors are "intentions".
    - Past/present anchors with similar titles/text may represent follow-ups.
    We don't try to be smart; we just group by rough title prefix.
    """
    anchors = load_anchors()
    if not anchors:
        return []

    # Group anchors by first few words of title
    buckets = defaultdict(list)
    for a in anchors:
        key = " ".join(a.title.lower().split()[:4])
        buckets[key].append(a)

    unresolved = []

    for key, group in buckets.items():
        futures = [a for a in group if a.perspective == "future"]
        non_futures = [a for a in group if a.perspective != "future"]

        for f in futures:
            # If there is no later non-future anchor with similar key, mark as unresolved
            f_time = _parse_iso(f.timestamp)
            later_non_futures = [
                a for a in non_futures if _parse_iso(a.timestamp) > f_time
            ]
            if not later_non_futures:
                unresolved.append(f)

    return unresolved


def summarize_by_tag():
    anchors = load_anchors()
    by_tag = defaultdict(int)
    for a in anchors:
        for t in a.tags:
            by_tag[t] += 1
    return dict(by_tag)


def recent_activity(limit: int = 10):
    anchors = load_anchors()
    anchors.sort(key=lambda a: a.timestamp, reverse=True)
    return anchors[:limit]
