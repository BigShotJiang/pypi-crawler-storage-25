class TemporalInteractionLayer:
    def __init__(self):
        self.snapshots = []

    def record_snapshot(self, data):
        self.snapshots.append(data)

    def adjust_decision(self, action):
        return action
