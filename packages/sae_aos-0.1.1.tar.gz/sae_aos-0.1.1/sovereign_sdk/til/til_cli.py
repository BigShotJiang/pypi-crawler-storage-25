import sys
import uuid
from datetime import datetime, timezone
from til_core import (
    TemporalAnchor,
    append_anchor,
    load_anchors,
    save_all,
    now_iso,
)
from til_reasoner import find_unresolved_intentions, summarize_by_tag, recent_activity


def _create_anchor(perspective: str) -> None:
    title = input("Title: ").strip()
    narrative = input("Narrative (what’s going on): ").strip()
    intention = input("Intention (what I want next): ").strip()

    anchor = TemporalAnchor(
        id=str(uuid.uuid4()),
        timestamp=now_iso(),
        perspective=perspective,
        title=title,
        narrative=narrative,
        intention=intention,
    )
    append_anchor(anchor)
    print(f"\nSaved anchor {anchor.id} [{anchor.perspective}]")


def cmd_add():
    perspective = input("Perspective [present/past/future]: ").strip() or "present"
    _create_anchor(perspective)


def cmd_add_past():
    _create_anchor("past")


def cmd_add_future():
    _create_anchor("future")


def cmd_list():
    anchors = load_anchors()
    for a in anchors[-20:]:
        print(f"{a.id[:8]}  {a.timestamp} [{a.perspective}] {a.title}")


def cmd_show(anchor_id: str):
    anchors = load_anchors()
    for a in anchors:
        if a.id.startswith(anchor_id):
            print(f"ID:         {a.id}")
            print(f"Time:       {a.timestamp}")
            print(f"Perspective:{a.perspective}")
            print(f"Title:      {a.title}")
            print(f"Narrative:  {a.narrative}")
            print(f"Intention:  {a.intention}")
            print(f"Tags:       {', '.join(a.tags) if a.tags else '(none)'}")
            print(f"Links:      {', '.join(a.links) if a.links else '(none)'}")
            return
    print("Anchor not found")


def cmd_tag(anchor_id: str, tag: str):
    anchors = load_anchors()
    for a in anchors:
        if a.id.startswith(anchor_id):
            if tag not in a.tags:
                a.tags.append(tag)
            save_all(anchors)
            print(f"Added tag '{tag}' to {a.id}")
            return
    print("Anchor not found")


def cmd_link(a_id: str, b_id: str):
    anchors = load_anchors()
    a = next((x for x in anchors if x.id.startswith(a_id)), None)
    b = next((x for x in anchors if x.id.startswith(b_id)), None)
    if not a or not b:
        print("One or both anchors not found")
        return
    if b.id not in a.links:
        a.links.append(b.id)
    save_all(anchors)
    print(f"Linked {a.id} → {b.id}")


def cmd_query_tag(tag: str):
    anchors = load_anchors()
    for a in anchors:
        if tag in a.tags:
            print(f"{a.id[:8]} [{a.perspective}] {a.title}")


def cmd_query_text(text: str):
    anchors = load_anchors()
    for a in anchors:
        blob = f"{a.title} {a.narrative} {a.intention}".lower()
        if text.lower() in blob:
            print(f"{a.id[:8]} [{a.perspective}] {a.title}")


def cmd_query_perspective(p: str):
    anchors = load_anchors()
    for a in anchors:
        if a.perspective == p:
            print(f"{a.id[:8]} {a.title}")


def cmd_review():
    print("=== Recent activity ===")
    for a in recent_activity(10):
        print(f"- {a.timestamp} [{a.perspective}] {a.title}")

    print("\n=== Unresolved future intentions ===")
    unresolved = find_unresolved_intentions()
    if not unresolved:
        print("(none)")
    else:
        for a in unresolved:
            print(f"- {a.id[:8]} [{a.perspective}] {a.title} -> {a.intention}")

    print("\n=== Tags summary ===")
    tags = summarize_by_tag()
    if not tags:
        print("(no tags yet)")
    else:
        for t, count in tags.items():
            print(f"- {t}: {count}")


def main():
    if len(sys.argv) < 2:
        print("Usage: til_cli.py [add|add_past|add_future|list|show|tag|link|query|review]")
        return

    cmd = sys.argv[1]

    if cmd == "add":
        cmd_add()
    elif cmd == "add_past":
        cmd_add_past()
    elif cmd == "add_future":
        cmd_add_future()
    elif cmd == "list":
        cmd_list()
    elif cmd == "show":
        cmd_show(sys.argv[2])
    elif cmd == "tag":
        cmd_tag(sys.argv[2], sys.argv[3])
    elif cmd == "link":
        cmd_link(sys.argv[2], sys.argv[3])
    elif cmd == "query":
        mode = sys.argv[2]
        if mode == "tag":
            cmd_query_tag(sys.argv[3])
        elif mode == "text":
            cmd_query_text(" ".join(sys.argv[3:]))
        elif mode == "perspective":
            cmd_query_perspective(sys.argv[3])
        else:
            print("Unknown query mode")
    elif cmd == "review":
        cmd_review()
    else:
        print("Unknown command")
