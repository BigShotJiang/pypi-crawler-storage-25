def low_pass(value, prev, alpha=0.2):
    return prev + alpha * (value - prev)

def rate_limit(value, prev, max_delta):
    delta = value - prev
    if abs(delta) > max_delta:
        return prev + max_delta * (1 if delta > 0 else -1)
    return value
