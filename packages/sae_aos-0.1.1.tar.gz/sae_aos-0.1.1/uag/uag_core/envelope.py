from dataclasses import dataclass
import math


@dataclass
class EnvelopeConfig:
    horizon: float = 0.8          # seconds to look ahead
    dt: float = 0.1               # rollout step
    min_clearance: float = 0.4    # meters
    hard_stop_distance: float = 0.2  # meters (absolute no-go)


class TemporalSafetyEnvelope:
    """
    Predicts near-future safety:
    - micro-horizon rollout
    - clearance checks
    - hard-stop distance

    Assumes:
        command: {"vx": ..., "vy": ..., "omega": ...}
        state["pose"]: {"x": ..., "y": ..., "theta": ...}
        state["obstacles"]: list of {"x": ..., "y": ...} (optional)
    """

    def __init__(self, config: EnvelopeConfig | None = None):
        self.cfg = config or EnvelopeConfig()

    def _rollout_pose(self, pose: dict, cmd: dict, dt: float) -> dict:
        x = pose["x"]
        y = pose["y"]
        theta = pose.get("theta", 0.0)

        vx = cmd.get("vx", 0.0)
        vy = cmd.get("vy", 0.0)
        omega = cmd.get("omega", 0.0)

        # Simple unicycle-ish integration in world frame
        dx = vx * math.cos(theta) - vy * math.sin(theta)
        dy = vx * math.sin(theta) + vy * math.cos(theta)
        x_next = x + dx * dt
        y_next = y + dy * dt
        theta_next = theta + omega * dt

        return {"x": x_next, "y": y_next, "theta": theta_next}

    def _min_distance_to_obstacles(self, pose: dict, obstacles: list) -> float:
        if not obstacles:
            return float("inf")
        px, py = pose["x"], pose["y"]
        dmin = float("inf")
        for o in obstacles:
            dx = o["x"] - px
            dy = o["y"] - py
            d = math.hypot(dx, dy)
            if d < dmin:
                dmin = d
        return dmin

    def evaluate(self, command: dict, state: dict) -> bool:
        """
        Returns True if the command is considered safe over the micro-horizon.
        """

        pose = state.get("pose")
        if pose is None:
            # No pose -> cannot evaluate, default to safe
            return True

        obstacles = state.get("obstacles", [])

        t = 0.0
        cur_pose = {"x": pose["x"], "y": pose["y"], "theta": pose.get("theta", 0.0)}

        while t < self.cfg.horizon:
            cur_pose = self._rollout_pose(cur_pose, command, self.cfg.dt)
            dmin = self._min_distance_to_obstacles(cur_pose, obstacles)

            # Hard-stop violation
            if dmin < self.cfg.hard_stop_distance:
                return False

            # Soft envelope violation
            if dmin < self.cfg.min_clearance:
                return False

            t += self.cfg.dt

        return True
