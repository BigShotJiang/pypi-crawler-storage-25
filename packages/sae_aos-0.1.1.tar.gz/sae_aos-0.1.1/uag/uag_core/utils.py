# Utility functions for UAG
