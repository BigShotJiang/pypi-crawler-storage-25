class PythonAdapter:
    """
    Simple Python function adapter for UAG.
    """

    def __init__(self, governor):
        self.gov = governor

    def step(self, command, state):
        return self.gov.process(command, state)
