from typing_extensions import Collection
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from collections import Counter, defaultdict
import asyncio

from tribulnation.sdk import SDK
from tribulnation.sdk.reporting import (
  Balance, Record, Snapshot, Snapshots as _Snapshots
)

from tribulnation.mexc.core import Mixin, wrap_exceptions

@dataclass
class Position:
  size: Decimal
  entry_price: Decimal

def merge_positions(positions: list[Position]) -> Position:
  size = sum(p.size for p in positions)
  if size == 0:
    return Position(size=Decimal(0), entry_price=Decimal(0))
  entry_price = sum(p.size * p.entry_price for p in positions) / size
  return Position(size=size, entry_price=entry_price)

@dataclass(frozen=True)
class Snapshots(_Snapshots, Mixin):
  @SDK.method
  @wrap_exceptions
  async def spot_balances(self):
    r = await self.client.spot.account.info(recv_window=self.recvWindow)
    return {
      b.get('asset') or '': Decimal(b.get('free') or '0') + Decimal(b.get('locked') or '0')
      for b in r.get('balances', [])
    }

  @SDK.method
  @wrap_exceptions
  async def futures_balances(self):
    r = await self.client.futures.account.assets()
    data = r.get('data')
    if data is None:
      raise ValueError('MEXC futures assets response did not include data')
    return {
      b.get('currency') or '': Decimal(str(b.get('availableBalance') or '0')) + Decimal(str(b.get('positionMargin') or '0'))
      for b in data
    }

  @SDK.method
  @wrap_exceptions
  async def futures_positions(self):
    response = await self.client.futures.position.open()
    data = response.get('data')
    if data is None:
      raise ValueError('MEXC futures positions response did not include data')
    out = defaultdict[str, list[Position]](list)

    for pos in data:
      symbol = pos.get('symbol')
      if symbol is None:
        continue
      contract_response = await self.client.futures.market.contract_info(symbol=symbol)
      contract = contract_response.get('data')
      if contract is None:
        raise ValueError(f'MEXC contract info response did not include data for {symbol}')
      if isinstance(contract, list):
        contract = next(c for c in contract if c.get('symbol') == symbol)
      contract_size = Decimal(str(contract.get('contractSize') or '0'))
      s = 1 if pos.get('positionType') == 1 else -1
      size = s * abs(Decimal(str(pos.get('holdVol') or '0'))) * contract_size
      out[symbol].append(Position(size=size, entry_price=Decimal(str(pos.get('openAvgPrice') or '0'))))

    return { symbol: merge_positions(positions) for symbol, positions in out.items() }
  
  @SDK.method
  async def snapshots(self, assets: Collection[str] | None = None) -> Record:
    spot_balances, future_balances, future_positions = await asyncio.gather(
      self.spot_balances(),
      self.futures_balances(),
      self.futures_positions(),
    )
    time = datetime.now(timezone.utc)
    balances: dict[str, Decimal] = Counter(spot_balances) + Counter(future_balances) # type: ignore

    return Record(
      snapshots=[Snapshot(
        time=time,
        balances={
          **{
            currency: Balance(qty=balance, kind='currency')
            for currency, balance in balances.items()
          },
          **{
            symbol: Balance(qty=p.size, avg_price=p.entry_price, kind='future')
            for symbol, p in future_positions.items()
          },
        },
      )],
      provenance={'source': 'api', 'service': 'mexc', 'endpoint': 'snapshots'},
    )
