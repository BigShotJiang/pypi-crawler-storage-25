# @pattern Command, Template Method
