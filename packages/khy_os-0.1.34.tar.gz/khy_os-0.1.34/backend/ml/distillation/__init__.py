# @pattern Template Method
