# KHY AI Fast Lane Context Pack

GeneratedAt: 2026-05-21T04:26:33.161Z
RepoRoot: /home/kodehu03/Khy-OS/backend

## Mission
Use this pack as the first read to understand KHY-OS quickly without full-repo scanning.

## Architecture in 8 lines
1. Entry command: `khy` (Python launcher in `khy_quant/cli.py`).
2. Core runtime: Node.js backend (`backend/`).
3. CLI routing: `backend/src/cli/router.js` + per-command handlers.
4. AI gateway orchestration: `backend/src/cli/handlers/gateway.js`.
5. Management backend server: `backend/src/services/aiManagementServer.js`.
6. Management daemon/session: `backend/scripts/ai-manage-daemon.js`.
7. Management frontend: `ai-frontend/` (Vue + Vite).
8. Project-level constraints: `AGENTS.md` (must read first).

## Mandatory Read Order

## Fast Task Routing
- Command parse/dispatch issues -> `backend/src/cli/router.js`
- AI provider/model/management page -> `backend/src/cli/handlers/gateway.js`
- Admin API or websocket behavior -> `backend/src/services/aiManagementServer.js`
- Management startup/timeout/auto-shutdown -> `backend/scripts/ai-manage-daemon.js`
- Management page routing/session bridge -> `ai-frontend/src/main.js`, `ai-frontend/src/router/index.js`

## Handoff Prompt Template
```text
You are maintaining KHY-OS.
Read files in this order first, then propose and implement the minimal patch:
Constraints:
- Follow AGENTS.md rules
- Keep behavior backward compatible
- Include verification commands and expected output
```

