'use strict';

/**
 * Webhooks Route — HTTP endpoints for external channel integrations.
 *
 * POST /webhooks/slack  — Slack Events API callback
 *
 * Register this router in the Express app:
 *   app.use('/webhooks', require('./routes/webhooks'));
 */

const express = require('express');
const router = express.Router();
const log = require('../utils/logger');

/**
 * Slack Events API endpoint.
 * Handles:
 *   - URL verification challenge
 *   - Event callbacks (message, app_mention)
 */
router.post('/slack', express.raw({ type: 'application/json' }), (req, res) => {
  const rawBody = req.body.toString('utf-8');
  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return res.status(400).json({ error: 'Invalid JSON' });
  }

  // URL verification challenge
  if (payload.type === 'url_verification') {
    return res.json({ challenge: payload.challenge });
  }

  // Verify signature
  const slackChannel = _getSlackChannel();
  if (slackChannel) {
    const sig = req.headers['x-slack-signature'];
    const ts = req.headers['x-slack-request-timestamp'];
    if (sig && ts && !slackChannel.verifySignature(sig, ts, rawBody)) {
      log.warn('Slack webhook signature verification failed');
      return res.status(401).json({ error: 'Invalid signature' });
    }
  }

  // Respond immediately (Slack requires < 3s response)
  res.status(200).json({ ok: true });

  // Process event asynchronously
  if (payload.type === 'event_callback' && payload.event) {
    if (slackChannel) {
      slackChannel.handleWebhookEvent(payload.event);
    } else {
      log.warn('Slack webhook received but no SlackChannel registered');
    }
  }
});

function _getSlackChannel() {
  try {
    const { getMessageRouter } = require('../services/channels/messageRouter');
    const router = getMessageRouter();
    const channels = router.getChannels();
    const slack = channels.find(ch => ch.name === 'slack');
    if (slack) {
      // Access internal channel map via router
      return router._channels?.get('slack') || null;
    }
  } catch { /* not registered */ }
  return null;
}

module.exports = router;
