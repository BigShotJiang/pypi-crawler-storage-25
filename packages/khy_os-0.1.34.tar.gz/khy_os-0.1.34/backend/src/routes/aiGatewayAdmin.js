/**
 * AI Gateway Admin REST API + SSE endpoints.
 *
 * Mounted at /api/ai-gateway-admin in the main Express app.
 *
 * Endpoints:
 *   GET  /status              — Full gateway status
 *   GET  /pool                — API key pool status per provider
 *   POST /pool/:provider/keys — Add a key
 *   DELETE /pool/:provider/keys/:keyId — Remove a key
 *   GET  /model-config        — Relay model config snapshot
 *   PUT  /model-config        — Update relay model config
 *   GET  /monitor/traces      — Query traces
 *   GET  /monitor/stats       — Aggregated stats
 *   GET  /monitor/stream      — SSE real-time trace stream
 *   GET  /oauth/status        — OAuth token status
 *   POST /oauth/:provider/refresh — Force refresh
 *   GET  /plugins             — List gateway plugins
 *   POST /plugins/:name/toggle — Enable/disable plugin
 *   GET  /tls/status          — TLS sidecar status
 *   POST /tls/start           — Start sidecar
 *   POST /tls/stop            — Stop sidecar
 *   GET  /protocols           — Supported protocols
 *   GET  /slots               — Concurrency slot status
 *   GET  /health              — Channel health snapshot (Redis-backed)
 *   GET  /health/stream       — SSE real-time channel health updates
 */
const express = require('express');
const fs = require('fs');
const path = require('path');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { parseApiKeyEntries, extractPrimaryApiKey } = require('../services/apiKeyFormat');
const router = express.Router();

// All routes require admin authentication
router.use(authenticateToken, requireAdmin);

function resolveEnvPathsForGateway() {
  const canonicalPath = process.env.KHY_ENV_FILE
    ? path.resolve(process.env.KHY_ENV_FILE)
    : path.resolve(__dirname, '../../.env'); // backend/.env
  const mirrorPath = path.resolve(__dirname, '../../../.env'); // repo root .env
  const syncMirror = String(process.env.KHY_ENV_SYNC_ROOT || 'true').toLowerCase() !== 'false';

  const targets = [canonicalPath];
  if (syncMirror && mirrorPath !== canonicalPath && (fs.existsSync(mirrorPath) || fs.existsSync(canonicalPath))) {
    targets.push(mirrorPath);
  }
  return { canonicalPath, targets };
}

function patchEnvContent(content, envMap = {}, unsetKeys = []) {
  let next = String(content || '');
  for (const [key, value] of Object.entries(envMap)) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(next)) next = next.replace(regex, line);
    else next = next.trimEnd() + '\n' + line + '\n';
  }
  for (const key of unsetKeys) {
    const regex = new RegExp(`^${key}=.*\\n?`, 'm');
    next = next.replace(regex, '');
  }
  return next;
}

function writeGatewayEnvPatch(envMap = {}, unsetKeys = []) {
  const { canonicalPath, targets } = resolveEnvPathsForGateway();
  for (const filePath of targets) {
    let content = '';
    try { content = fs.readFileSync(filePath, 'utf-8'); } catch { /* no .env yet */ }
    const patched = patchEnvContent(content, envMap, unsetKeys);
    fs.writeFileSync(filePath, patched, 'utf-8');
  }
  for (const [key, value] of Object.entries(envMap)) process.env[key] = String(value);
  for (const key of unsetKeys) delete process.env[key];
  return canonicalPath;
}

function normalizeCompatibility(raw = '') {
  const value = String(raw || '').trim().toLowerCase();
  if (!value) return 'openai';
  if (value === 'openai' || value === 'openai-compatible' || value === 'openai_compatible') return 'openai';
  if (value === 'anthropic' || value === 'anthropic-compatible' || value === 'anthropic_compatible') return 'anthropic';
  if (value === 'unknown' || value === 'auto' || value === 'detect') return 'unknown';
  return '';
}

function normalizeOpenAiLikeBaseUrl(raw = '') {
  const input = String(raw || '').trim();
  if (!input) return { ok: false, error: 'empty' };
  let parsed = null;
  try {
    parsed = new URL(input);
  } catch {
    return { ok: false, error: 'invalid-url' };
  }
  const protocol = String(parsed.protocol || '').toLowerCase();
  if (protocol !== 'http:' && protocol !== 'https:') {
    return { ok: false, error: 'invalid-protocol' };
  }

  let pathname = String(parsed.pathname || '').replace(/\/+$/g, '');
  let appendedV1 = false;
  if (!pathname) {
    pathname = '/v1';
    appendedV1 = true;
  } else if (!/\/v1$/i.test(pathname)) {
    pathname = `${pathname}/v1`;
    appendedV1 = true;
  }
  parsed.pathname = pathname;
  parsed.search = '';
  parsed.hash = '';
  return {
    ok: true,
    url: parsed.toString().replace(/\/$/, ''),
    appendedV1,
  };
}

function maskSecret(value = '') {
  const text = String(value || '').trim();
  if (!text) return '';
  if (text.length <= 8) return `${text.slice(0, 2)}****`;
  return `${text.slice(0, 4)}...${text.slice(-2)}`;
}

function getModelConfigSnapshot() {
  const baseUrl = String(process.env.RELAY_API_ENDPOINT || '').trim();
  const modelId = String(process.env.RELAY_API_MODEL || '').trim();
  const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim();
  const preferredModel = String(process.env.GATEWAY_PREFERRED_MODEL || '').trim();
  const compatibility = normalizeCompatibility(process.env.RELAY_API_COMPATIBILITY || 'openai') || 'openai';
  const apiKey = extractPrimaryApiKey(process.env.RELAY_API_KEY || '');
  return {
    baseUrl,
    modelId,
    compatibility,
    preferredAdapter,
    preferredModel,
    hasApiKey: !!apiKey,
    apiKeyMasked: apiKey ? maskSecret(apiKey) : '',
  };
}

// ── Status ──

router.get('/status', async (req, res) => {
  try {
    const gateway = require('../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();
    const statuses = gateway.getStatus();
    const active = gateway.getActiveAdapter();
    res.json({ adapters: statuses, active: active ? { name: active.name, type: active.type } : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Pool ──

router.get('/pool', (req, res) => {
  try {
    const pool = require('../services/apiKeyPool');
    pool.init();
    res.json(pool.getAllStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/pool/:provider/keys', (req, res) => {
  try {
    const pool = require('../services/apiKeyPool');
    pool.init();
    const { key, endpoint, priority, label } = req.body;
    if (!key) return res.status(400).json({ error: 'key is required' });
    pool.addKey(req.params.provider, { key, endpoint, priority: priority || 10, label: label || '' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/pool/:provider/keys/:keyId', (req, res) => {
  try {
    const pool = require('../services/apiKeyPool');
    pool.init();
    pool.removeKey(req.params.provider, req.params.keyId);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Relay Model Config ──

router.get('/model-config', (req, res) => {
  try {
    res.json({ success: true, data: getModelConfigSnapshot() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/model-config', (req, res) => {
  try {
    const baseUrlRaw = String(req.body?.baseUrl || '').trim();
    const modelId = String(req.body?.modelId || '').trim();
    const compatibilityRaw = String(req.body?.compatibility || 'openai');
    const apiKeyInput = req.body?.apiKey;
    const clearApiKey = req.body?.clearApiKey === true;

    if (!baseUrlRaw) return res.status(400).json({ error: 'baseUrl is required' });
    if (!modelId) return res.status(400).json({ error: 'modelId is required' });

    const normalizedUrl = normalizeOpenAiLikeBaseUrl(baseUrlRaw);
    if (!normalizedUrl.ok) {
      return res.status(400).json({ error: 'baseUrl must be a valid http(s) URL' });
    }
    const compatibility = normalizeCompatibility(compatibilityRaw);
    if (!compatibility) {
      return res.status(400).json({ error: 'compatibility must be openai|anthropic|unknown' });
    }

    const envMap = {
      GATEWAY_PREFERRED_ADAPTER: 'relay_api',
      GATEWAY_PREFERRED_STRICT: 'true',
      GATEWAY_PREFERRED_MODEL: modelId,
      RELAY_API_ENDPOINT: normalizedUrl.url,
      RELAY_API_MODEL: modelId,
      RELAY_API_COMPATIBILITY: compatibility,
    };
    const unsetKeys = [];
    const parsedEntries = parseApiKeyEntries(apiKeyInput);
    const primaryKey = extractPrimaryApiKey(apiKeyInput);
    const primary = String(primaryKey || (parsedEntries[0] && parsedEntries[0].key) || '').trim();

    if (clearApiKey) {
      unsetKeys.push('RELAY_API_KEY', 'RELAY_API_KEYS');
    } else if (primary) {
      envMap.RELAY_API_KEY = primary;
      if (parsedEntries.length > 1) envMap.RELAY_API_KEYS = parsedEntries.map((entry) => entry.key).join(',');
      else unsetKeys.push('RELAY_API_KEYS');
    }

    const envPath = writeGatewayEnvPatch(envMap, unsetKeys);
    res.json({
      success: true,
      data: {
        updated: true,
        appendedV1: normalizedUrl.appendedV1,
        envPath,
        config: getModelConfigSnapshot(),
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Monitor ──

router.get('/monitor/traces', (req, res) => {
  try {
    const monitor = require('../services/aiMonitor');
    const { limit, offset, provider, success, since } = req.query;
    const filter = {};
    if (limit) filter.limit = parseInt(limit, 10);
    if (offset) filter.offset = parseInt(offset, 10);
    if (provider) filter.provider = provider;
    if (success !== undefined) filter.success = success === 'true';
    if (since) filter.since = since;
    res.json(monitor.getTraces(filter));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/monitor/stats', (req, res) => {
  try {
    const monitor = require('../services/aiMonitor');
    res.json(monitor.getStats());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/monitor/stream', (req, res) => {
  const monitor = require('../services/aiMonitor');
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const events = monitor.createEventStream();
  const onTrace = (trace) => {
    res.write(`data: ${JSON.stringify(trace)}\n\n`);
  };

  events.on('trace:start', onTrace);
  events.on('trace:end', onTrace);
  events.on('trace:cascade', onTrace);

  req.on('close', () => {
    events.removeListener('trace:start', onTrace);
    events.removeListener('trace:end', onTrace);
    events.removeListener('trace:cascade', onTrace);
  });
});

// ── OAuth ──

router.get('/oauth/status', (req, res) => {
  try {
    const oauth = require('../services/gateway/oauthManager');
    oauth.init();
    res.json(oauth.getAllStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/oauth/:provider/refresh', async (req, res) => {
  try {
    const oauth = require('../services/gateway/oauthManager');
    oauth.init();
    const token = await oauth.refreshToken(req.params.provider);
    res.json({ success: !!token, token: token ? '***' : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Plugins ──

router.get('/plugins', (req, res) => {
  try {
    const chain = require('../services/gateway/pluginChain');
    res.json(chain.list());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/plugins/:name/toggle', (req, res) => {
  try {
    const chain = require('../services/gateway/pluginChain');
    const { enabled } = req.body;
    const success = chain.toggle(req.params.name, enabled !== false);
    res.json({ success });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── TLS Sidecar ──

router.get('/tls/status', (req, res) => {
  try {
    const sidecar = require('../services/gateway/tlsSidecar');
    res.json(sidecar.getStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/tls/start', async (req, res) => {
  try {
    const sidecar = require('../services/gateway/tlsSidecar');
    const result = await sidecar.start(req.body || {});
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/tls/stop', async (req, res) => {
  try {
    const sidecar = require('../services/gateway/tlsSidecar');
    await sidecar.stop();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Protocols ──

router.get('/protocols', (req, res) => {
  try {
    const converter = require('../services/gateway/protocolConverter');
    res.json({ protocols: converter.getSupportedProtocols() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Concurrency Slots ──

router.get('/slots', (req, res) => {
  try {
    const slots = require('../services/concurrencySlots');
    res.json(slots.getAllStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Channel Health (Redis-backed) ──

router.get('/health', async (req, res) => {
  try {
    const gateway = require('../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();
    const broadcaster = gateway._healthBroadcaster;
    if (!broadcaster) return res.json({ adapters: [], activity: [], timestamp: Date.now() });
    const snapshot = await broadcaster.getSnapshot();
    snapshot.activity = broadcaster.getRecentActivity();
    res.json(snapshot);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/health/stream', async (req, res) => {
  // SSE endpoint for real-time channel health updates
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const send = (event, data) => {
    try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch {}
  };

  try {
    const gateway = require('../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();
    const broadcaster = gateway._healthBroadcaster;

    if (!broadcaster) {
      send('error', { message: 'Health broadcaster not available' });
      return res.end();
    }

    // Send initial snapshot
    const snapshot = await broadcaster.getSnapshot();
    send('channel_health', snapshot);

    // Subscribe to health changes
    const onHealth = (snap) => send('channel_health', snap);
    broadcaster.onHealthChange(onHealth);

    // Keep-alive heartbeat
    const hb = setInterval(() => send('heartbeat', { ts: Date.now() }), 15000);
    if (hb.unref) hb.unref();

    req.on('close', () => {
      clearInterval(hb);
      // Remove listener (best effort — array filter)
      const idx = broadcaster._listeners.indexOf(onHealth);
      if (idx >= 0) broadcaster._listeners.splice(idx, 1);
    });
  } catch (err) {
    send('error', { message: err.message });
    res.end();
  }
});

// ─── Credential Watcher ────────────────────────────────────────────────
router.get('/credential-watcher/status', (req, res) => {
  try {
    const watcher = require('../services/credentialWatcherService');
    res.json(watcher.getStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/credential-watcher/scan', async (req, res) => {
  try {
    const watcher = require('../services/credentialWatcherService');
    const results = await watcher.triggerScanNow();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/credential-watcher/start', async (req, res) => {
  try {
    const watcher = require('../services/credentialWatcherService');
    await watcher.start();
    res.json({ ok: true, status: watcher.getStatus() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/credential-watcher/stop', (req, res) => {
  try {
    const watcher = require('../services/credentialWatcherService');
    watcher.stop();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
