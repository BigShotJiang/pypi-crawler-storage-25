/**
 * Bridge Client — connects to a bridge server for remote control.
 *
 * Used when controlling a remote KHY OS instance from another terminal.
 */
'use strict';

/**
 * Connect to a bridge server.
 * @param {string} url - WebSocket URL (e.g., ws://localhost:9222)
 * @param {string} token - Authentication token
 * @returns {Promise<BridgeConnection>}
 */
async function connect(url, token) {
  let WebSocket;
  try {
    const ws = require('ws');
    WebSocket = ws.default || ws;
  } catch {
    throw new Error('WebSocket dependency (ws) not installed. Run: npm install ws');
  }

  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    const listeners = new Map();

    ws.on('open', () => {
      // Send auth token
      ws.send(JSON.stringify({ type: 'auth', token }));
    });

    ws.on('message', (data) => {
      let msg;
      try { msg = JSON.parse(data.toString()); } catch { return; }

      if (msg.type === 'auth_ok') {
        resolve(connection);
      } else if (msg.type === 'auth_failed') {
        ws.close();
        reject(new Error(`Authentication failed: ${msg.reason}`));
      }

      // Dispatch to listeners
      const handlers = listeners.get(msg.type) || [];
      for (const handler of handlers) {
        try { handler(msg); } catch { /* ignore */ }
      }
    });

    ws.on('error', (err) => {
      reject(new Error(`Connection failed: ${err.message}`));
    });

    ws.on('close', () => {
      const handlers = listeners.get('close') || [];
      for (const handler of handlers) {
        try { handler(); } catch { /* ignore */ }
      }
    });

    const connection = {
      /** Send text input to the remote REPL */
      send(text) {
        ws.send(JSON.stringify({ type: 'input', text }));
      },

      /** Approve a pending permission request */
      approve(requestId) {
        ws.send(JSON.stringify({ type: 'approve', requestId }));
      },

      /** Deny a pending permission request */
      deny(requestId) {
        ws.send(JSON.stringify({ type: 'deny', requestId }));
      },

      /** Register event listener */
      on(event, handler) {
        if (!listeners.has(event)) listeners.set(event, []);
        listeners.get(event).push(handler);
      },

      /** Send ping */
      ping() {
        ws.send(JSON.stringify({ type: 'ping' }));
      },

      /** Close connection */
      close() {
        ws.close(1000, 'Client disconnect');
      },

      /** Check if connected */
      get connected() {
        return ws.readyState === 1; // OPEN
      },
    };

    // Connection handshake timeout (short I/O timeout, not a task timeout)
    const connectTimeoutMs = parseInt(process.env.BRIDGE_CONNECT_TIMEOUT_MS || '10000', 10);
    setTimeout(() => {
      if (ws.readyState !== 1) {
        ws.close();
        reject(new Error(`Bridge WebSocket 握手超时（${connectTimeoutMs / 1000}s 内未建立连接）`));
      }
    }, connectTimeoutMs);
  });
}

module.exports = { connect };
