'use strict';

/**
 * serviceDefaults.js — Single source of truth for external service URLs/ports.
 *
 * Every env-based default lives here so no file needs to independently
 * hardcode "localhost:XXXX".  Import from this module instead.
 */

const fs = require('fs');
const path = require('path');

/**
 * 从 runtime 文件发现 daemon 的实际 API 端口，构造 URL。
 * 若 runtime 文件不可用则返回 null，由调用方回退到默认值。
 */
function _discoverAiBackendUrl() {
  try {
    const { getDataHome } = require('../utils/dataHome');
    const file = path.join(getDataHome(), 'ai_manage_runtime.json');
    const raw = JSON.parse(fs.readFileSync(file, 'utf-8'));
    if (raw && typeof raw.apiPort === 'number') {
      return `http://localhost:${raw.apiPort}`;
    }
  } catch { /* ignore */ }
  return null;
}

const OLLAMA_HOST = process.env.OLLAMA_HOST || 'http://localhost:11434';
const INFERENCE_SERVER_PORT = parseInt(process.env.INFERENCE_SERVER_PORT || '8765', 10);
const AI_BACKEND_URL = process.env.AI_BACKEND_URL || _discoverAiBackendUrl() || 'http://localhost:9090';
const BACKEND_PORT = parseInt(process.env.PORT || '3000', 10);

// Redis gateway key prefix (shared across all gateway Redis keys)
const REDIS_KEY_PREFIX = process.env.REDIS_KEY_PREFIX || 'khy:gw:';

module.exports = {
  OLLAMA_HOST,
  INFERENCE_SERVER_PORT,
  AI_BACKEND_URL,
  BACKEND_PORT,
  REDIS_KEY_PREFIX,
};
