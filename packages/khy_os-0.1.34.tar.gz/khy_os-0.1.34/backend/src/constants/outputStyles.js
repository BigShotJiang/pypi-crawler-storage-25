'use strict';

/**
 * Output style configuration system.
 * Ported from Claude Code's outputStyles.ts architecture.
 */

const BUILT_IN_STYLES = {
  'senior-engineer': {
    name: 'senior-engineer',
    prompt: [
      'Think and respond like a senior software engineer.',
      'For technical tasks, structure output as: 1) conclusion/status, 2) concrete implementation steps, 3) verification and risk notes.',
      'Prefer concrete details (file paths, commands, constraints, measurable checks) over abstract advice.',
      'State assumptions briefly when needed, then proceed with the most practical execution path.',
      'Be concise but rigorous; avoid vague wording and generic templates.',
    ].join(' '),
    keepCodingInstructions: true,
  },
  concise: {
    name: 'concise',
    prompt: 'Be extremely concise. Respond in as few words as possible while being complete. No filler, no pleasantries.',
    keepCodingInstructions: true,
  },
  verbose: {
    name: 'verbose',
    prompt: 'Provide detailed, thorough explanations. Include context, examples, and edge cases.',
    keepCodingInstructions: true,
  },
  'code-only': {
    name: 'code-only',
    prompt: 'Respond with code only. No explanations unless explicitly asked. Use comments in code for context.',
    keepCodingInstructions: true,
  },
};

/**
 * Get output style config by name.
 * @param {string} [styleName] - Name of the output style
 * @returns {Promise<{ name: string, prompt: string, keepCodingInstructions: boolean }|null>}
 */
async function getOutputStyleConfig(styleName) {
  if (!styleName) {
    styleName = process.env.KHY_OUTPUT_STYLE || null;
  }
  if (!styleName) return null;

  const builtin = BUILT_IN_STYLES[styleName];
  if (builtin) return builtin;

  // Custom styles can be defined in .khy/output-styles/
  try {
    const fs = require('fs');
    const path = require('path');
    const os = require('os');
    const stylePath = path.join(os.homedir(), '.khy', 'output-styles', `${styleName}.md`);
    if (fs.existsSync(stylePath)) {
      const content = fs.readFileSync(stylePath, 'utf-8');
      return {
        name: styleName,
        prompt: content.trim(),
        keepCodingInstructions: true,
      };
    }
  } catch { /* ignore */ }

  return null;
}

module.exports = { getOutputStyleConfig, BUILT_IN_STYLES };
