'use strict';

/**
 * deliveryGate.js
 *
 * Post-loop delivery validation engine.
 * Scans the workspace against machine-readable acceptance criteria
 * and produces a structured report of what's present vs missing.
 *
 * This module runs in JavaScript AFTER the AI finishes — it cannot be
 * ignored or bypassed by prompt engineering.
 */

const fs = require('fs');
const path = require('path');

// ── Custom validators for response-based checks ────────────────────

const CUSTOM_VALIDATORS = {
  /** ULTRAWORK: check that AI produced a numbered execution plan */
  plan_in_response(context) {
    const text = String(context.finalResponse || '');
    // Look for numbered list pattern (1. xxx 2. xxx or 1) xxx 2) xxx)
    const numberedItems = text.match(/(?:^|\n)\s*\d+[.)]\s+\S/gm);
    return numberedItems && numberedItems.length >= 2 ? 'pass' : 'fail';
  },

  /** ANALYZE: check that AI cited file paths as evidence */
  evidence_in_response(context) {
    const text = String(context.finalResponse || '');
    // Look for file path references (e.g., src/foo.js, ./bar/baz.ts, line 42)
    const pathRefs = text.match(/(?:[\w./\\-]+\.(?:js|ts|py|java|go|rs|rb|c|cpp|h|vue|jsx|tsx|json|yml|yaml|xml|sql|sh|md))/gi);
    return pathRefs && pathRefs.length >= 1 ? 'pass' : 'fail';
  },
};

// ── Glob matching (no external dependencies) ───────────────────────

function _matchBracePattern(filename, pattern) {
  // Handle {a,b,c} brace expansion in patterns
  const braceMatch = pattern.match(/^\{([^}]+)\}$/);
  if (braceMatch) {
    const alternatives = braceMatch[1].split(',');
    return alternatives.some(alt => filename === alt.trim());
  }
  return filename === pattern;
}

function _walkDir(dir, maxDepth, depth) {
  if (depth > maxDepth) return [];
  const results = [];
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return results;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === '.git') continue;
      results.push(..._walkDir(full, maxDepth, depth + 1));
    } else {
      results.push(full);
    }
  }
  return results;
}

function _globSync(pattern, root) {
  // Handle brace patterns like {package.json,pom.xml,...}
  const braceMatch = pattern.match(/^\{([^}]+)\}$/);
  if (braceMatch) {
    const alternatives = braceMatch[1].split(',');
    return alternatives
      .map(alt => path.join(root, alt.trim()))
      .filter(p => fs.existsSync(p));
  }

  // Handle ** recursive glob: dir/**/pattern
  const parts = pattern.split('/');
  const hasRecursive = parts.includes('**');

  if (hasRecursive) {
    // e.g., unit_tests/**/* — find all files under unit_tests/
    const baseDir = parts.slice(0, parts.indexOf('**')).join('/');
    const searchRoot = baseDir ? path.join(root, baseDir) : root;
    if (!fs.existsSync(searchRoot)) return [];
    return _walkDir(searchRoot, 5, 0);
  }

  // Simple single-level pattern
  const target = path.join(root, pattern);
  return fs.existsSync(target) ? [target] : [];
}

// ── Check runners ──────────────────────────────────────────────────

function _runCheck(criterion, projectRoot, context) {
  switch (criterion.check) {
    case 'file_exists': {
      const full = path.join(projectRoot, criterion.target);
      return fs.existsSync(full) ? 'pass' : 'fail';
    }

    case 'glob_min': {
      const matches = _globSync(criterion.target, projectRoot);
      const minFiles = criterion.minFiles || 1;
      return matches.length >= minFiles ? 'pass' : 'fail';
    }

    case 'file_contains': {
      const full = path.join(projectRoot, criterion.target);
      if (!fs.existsSync(full)) return 'fail';
      try {
        const content = fs.readFileSync(full, 'utf-8').toLowerCase();
        const needles = criterion.contains || [];
        const found = needles.some(s => content.includes(s.toLowerCase()));
        return found ? 'pass' : 'fail';
      } catch {
        return 'fail';
      }
    }

    case 'custom': {
      const validator = CUSTOM_VALIDATORS[criterion.validator];
      if (!validator) return 'pass'; // Unknown validators pass by default
      try {
        return validator(context || {});
      } catch {
        return 'pass'; // Custom validator errors are non-blocking
      }
    }

    default:
      return 'pass';
  }
}

// ── Public API ──────────────────────────────────────────────────────

/**
 * Evaluate a workspace against acceptance criteria.
 *
 * @param {string} projectRoot - Absolute path to project workspace
 * @param {Array} criteria - Criterion objects from acceptanceCriteria.js
 * @param {object} [context] - { finalResponse, toolCallLog }
 * @returns {{ passed, results, missing, warnings }}
 */
function evaluateDelivery(projectRoot, criteria, context) {
  const ctx = context || {};
  const results = [];
  const missing = [];
  const warnings = [];

  for (const criterion of criteria) {
    const status = _runCheck(criterion, projectRoot, ctx);
    const result = {
      id: criterion.id,
      label: criterion.label,
      phase: criterion.phase,
      required: criterion.required,
      status,
      detail: status === 'fail'
        ? `${criterion.target || criterion.validator || criterion.id} not found`
        : '',
    };
    results.push(result);

    if (status === 'fail') {
      if (criterion.required) {
        missing.push(result);
      } else {
        warnings.push(result);
      }
    }
  }

  return {
    passed: missing.length === 0,
    results,
    missing,
    warnings,
  };
}

/**
 * Build a focused remediation prompt for the AI to fix missing deliverables.
 *
 * @param {string} originalMessage - Original user request
 * @param {Array} missing - Required items that are missing
 * @param {Array} warnings - Optional items that are missing
 * @param {number} round - Current remediation round
 * @param {number} maxRounds - Max remediation rounds
 * @returns {string}
 */
function buildRemediationPrompt(originalMessage, missing, warnings, round, maxRounds) {
  const lines = [
    `[SYSTEM: Delivery Gate — remediation round ${round}/${maxRounds}]`,
    '',
    '[Original task]',
    String(originalMessage || '').slice(0, 500),
    '',
    '[REQUIRED deliverables still missing — you MUST create these]:',
    ...missing.map((m, i) => `  ${i + 1}. ${m.label}: ${m.detail || 'not found'}`),
  ];

  if (warnings.length > 0) {
    lines.push('', '[RECOMMENDED deliverables also missing]:');
    lines.push(...warnings.map((w, i) => `  ${i + 1}. ${w.label}: ${w.detail || 'not found'}`));
  }

  lines.push(
    '',
    '[Instructions]',
    'Create ONLY the missing deliverables listed above.',
    'Do NOT recreate files that already exist.',
    'Do NOT rewrite the entire project.',
    'Use scaffoldFiles for batch creation when possible.',
    'Focus exclusively on the missing items.',
  );

  return lines.join('\n');
}

/**
 * Infer project root from tool call log.
 * Scans for scaffoldFiles or write_file calls to determine where the project lives.
 *
 * @param {Array} toolCallLog - Tool call log entries
 * @param {string} fallbackCwd - Fallback if no root found
 * @returns {string}
 */
function inferProjectRoot(toolCallLog, fallbackCwd) {
  for (const entry of (toolCallLog || [])) {
    const tool = String(entry.tool || entry.name || '');

    // scaffoldFiles has an explicit root parameter
    if (/scaffold/i.test(tool)) {
      const root = entry.params?.root || entry.params?.directory;
      if (root) return path.resolve(root);
    }

    // write_file / editFile — walk up to find project root indicators
    if (/write|edit/i.test(tool)) {
      const filePath = entry.params?.path || entry.params?.file_path || entry.params?.filePath;
      if (filePath) {
        let dir = path.dirname(path.resolve(filePath));
        // Walk up to find a config file that indicates project root
        const indicators = ['package.json', 'pom.xml', 'Cargo.toml', 'go.mod', 'requirements.txt', 'pyproject.toml', 'build.gradle'];
        for (let i = 0; i < 5 && dir !== path.dirname(dir); i++) {
          if (indicators.some(f => fs.existsSync(path.join(dir, f)))) return dir;
          dir = path.dirname(dir);
        }
      }
    }
  }

  return fallbackCwd || process.cwd();
}

/**
 * 增强交付评估: 可选对抗性验证阶段 + 自动 remediation 循环。
 *
 * 借鉴 Claude Code Verification Agent + Hermes 幻觉验证门:
 * - 静态检查 (原有逻辑)
 * - 对抗性 AI 验证 (可选)
 * - FAIL → 生成修复 prompt → 重跑 → 再验证 (最多 maxRemediationRounds 轮)
 *
 * @param {object} params
 * @param {Array} params.toolCallLog - 工具调用日志
 * @param {string} [params.cwd] - 工作目录
 * @param {string} params.mode - 'coding'|'ultrawork'|'analyze'|'goal'
 * @param {object} [params.adversarial] - 对抗性验证配置
 * @param {function} [params.adversarial.executeAI] - AI 执行函数
 * @param {string} [params.adversarial.taskDescription] - 任务描述
 * @param {number} [params.maxRemediationRounds=2] - 最大 remediation 循环次数
 * @param {function} [params.onRemediation] - (prompt, round) => Promise<toolCallLog> 执行修复
 * @returns {Promise<{ passed: boolean, staticResult: object, adversarialResult: object|null, rounds: number }>}
 */
async function evaluateDeliveryEnhanced(params) {
  const cwd = params.cwd || process.cwd();
  const maxRounds = params.maxRemediationRounds || 2;
  let toolCallLog = params.toolCallLog || [];
  let round = 0;
  let adversarialResult = null;

  while (round <= maxRounds) {
    // 静态检查
    const staticResult = evaluateDelivery({ toolCallLog, cwd, mode: params.mode });

    // 对抗性验证 (如果配置了 executeAI)
    if (params.adversarial && params.adversarial.executeAI) {
      try {
        const { adversarialVerify } = require('./verificationAgent');
        // 从工具日志提取变更文件
        const files = _extractChangedFiles(toolCallLog);
        adversarialResult = await adversarialVerify({
          files,
          cwd,
          taskDescription: params.adversarial.taskDescription || '',
          executeAI: params.adversarial.executeAI,
        });
      } catch {
        adversarialResult = { verdict: 'SKIP', summary: '对抗性验证不可用' };
      }
    }

    // 判断是否通过
    const staticPassed = staticResult.passed;
    const adversarialPassed = !adversarialResult || adversarialResult.verdict === 'PASS';

    if (staticPassed && adversarialPassed) {
      return { passed: true, staticResult, adversarialResult, rounds: round };
    }

    // 尝试 remediation
    round++;
    if (round > maxRounds || !params.onRemediation) {
      return { passed: false, staticResult, adversarialResult, rounds: round - 1 };
    }

    // 生成修复 prompt
    let remediationPrompt = '';
    if (!staticPassed) {
      remediationPrompt += buildRemediationPrompt(staticResult) + '\n\n';
    }
    if (adversarialResult && adversarialResult.verdict === 'FAIL') {
      const failedChecks = (adversarialResult.checks || [])
        .filter(c => c.result === 'FAIL')
        .map(c => `- ${c.command}: ${c.output}`)
        .join('\n');
      remediationPrompt += `对抗性验证失败:\n${failedChecks}\n请修复以上问题。`;
    }

    // 执行修复
    try {
      const newLog = await params.onRemediation(remediationPrompt, round);
      if (Array.isArray(newLog)) toolCallLog = [...toolCallLog, ...newLog];
    } catch {
      return { passed: false, staticResult, adversarialResult, rounds: round };
    }
  }

  return { passed: false, staticResult: null, adversarialResult, rounds: round };
}

/**
 * 从工具调用日志提取变更文件列表。
 * @private
 */
function _extractChangedFiles(toolCallLog) {
  const files = new Set();
  for (const entry of (toolCallLog || [])) {
    const tool = String(entry.tool || entry.name || '');
    if (/write|edit|scaffold/i.test(tool)) {
      const fp = entry.params?.path || entry.params?.file_path || entry.params?.filePath;
      if (fp) files.add(fp);
    }
  }
  return [...files];
}

module.exports = {
  evaluateDelivery,
  evaluateDeliveryEnhanced,
  buildRemediationPrompt,
  inferProjectRoot,
  _runCheck,
  _globSync,
  CUSTOM_VALIDATORS,
};
