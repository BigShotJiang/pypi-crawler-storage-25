/**
 * CLI Agent Runner — orchestrate parallel agent execution for complex tasks.
 *
 * Decomposes complex requests into sub-tasks, runs them in parallel
 * via specialized agents, and synthesizes results.
 *
 * Agent roles are configurable:
 *   ~/.khyquant/agent_roles.json — user override
 *   Built-in defaults: quant trading analysis personas
 *
 * Concurrency: max 3 parallel, 200ms stagger to avoid rate limits.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { normalizeAgentRole } = require('./claudeCompat');

let _toolRegistry; // lazy-load to avoid circular deps
function getToolRegistry() {
  if (!_toolRegistry) _toolRegistry = require('../tools');
  return _toolRegistry;
}

const MAX_CONCURRENT = 3;
const STAGGER_MS = 200;

// ── Agent Role Templates ──────────────────────────────────────────────

const DEFAULT_AGENT_ROLES = {
  fundamental: {
    name: '基本面分析师',
    systemPrompt: '你是一位专业的基本面分析师，擅长分析公司财务报表、盈利能力、估值水平和行业对比。请从基本面角度分析用户提出的问题。',
    keywords: ['基本面', '财务', '盈利', '估值', 'PE', 'ROE'],
  },
  technical: {
    name: '技术面分析师',
    systemPrompt: '你是一位专业的技术面分析师，擅长K线形态、均线系统、MACD、RSI等技术指标分析。请从技术面角度分析用户提出的问题。',
    keywords: ['技术', 'K线', '均线', 'MACD', 'RSI', '形态', '趋势'],
  },
  news: {
    name: '新闻分析师',
    systemPrompt: '你是一位专业的新闻分析师，擅长分析市场新闻、政策变化、行业动态对股价的影响。请从新闻面角度分析用户提出的问题。',
    keywords: ['新闻', '政策', '公告', '利好', '利空', '消息'],
  },
  risk: {
    name: '风控经理',
    systemPrompt: '你是一位专业的风险管理经理，擅长评估投资风险、波动率分析、仓位管理和止损策略。请从风控角度分析用户提出的问题。',
    keywords: ['风险', '止损', '仓位', '波动', '回撤'],
  },
  strategy: {
    name: '策略研究员',
    systemPrompt: '你是一位专业的量化策略研究员，擅长设计和评估交易策略、回测分析、因子研究。请从策略角度分析用户提出的问题。',
    keywords: ['策略', '回测', '因子', '信号', '交易'],
  },
  macro: {
    name: '宏观经济分析师',
    systemPrompt: '你是一位专业的宏观经济分析师，擅长分析GDP、CPI、利率、货币政策、国际贸易等宏观指标对市场的影响。请从宏观经济角度分析用户提出的问题。',
    keywords: ['宏观', 'GDP', 'CPI', '利率', '货币政策', '央行', '美联储', '贸易战', '通胀'],
  },
  sentiment: {
    name: '市场情绪分析师',
    systemPrompt: '你是一位专业的市场情绪分析师，擅长分析市场恐慌/贪婪指数、成交量异动、融资融券数据、北向资金流向、散户/机构行为差异。请从市场情绪角度分析用户提出的问题。',
    keywords: ['情绪', '恐慌', '贪婪', '成交量', '融资融券', '北向', '资金流', '散户', '机构'],
  },
  quant: {
    name: '量化因子分析师',
    systemPrompt: '你是一位专业的量化因子分析师，擅长多因子模型构建、因子挖掘、因子有效性检验、alpha因子组合优化。请从量化因子角度分析用户提出的问题。',
    keywords: ['因子', 'alpha', '多因子', '选股', '因子暴露', 'IC', 'IR', '因子收益'],
  },
  general: {
    name: '通用分析师',
    systemPrompt: '你是一位全面的分析助手。请从综合角度分析用户提出的问题，给出专业的建议。',
    keywords: [],
  },

  // ── Claude/Codex-style baseline aliases ────────────────────────────
  default: {
    name: 'Default Agent',
    systemPrompt:
      'You are a general-purpose autonomous coding agent. Solve tasks end-to-end with concise progress reporting.',
    keywords: ['default', 'agent default'],
    toolProfile: 'coding',
  },
  explorer: {
    name: 'Explorer Agent',
    systemPrompt:
      'You are an exploration agent. Search codebases quickly and report concrete findings with file paths.',
    keywords: ['explorer', 'code explorer'],
    toolProfile: 'minimal',
  },
  worker: {
    name: 'Worker Agent',
    systemPrompt:
      'You are a worker coding agent. Implement requested changes with edits and validation.',
    keywords: ['worker', 'coding worker'],
    toolProfile: 'coding',
  },

  // ── Generic software development agents ────────────────────────────
  explore: {
    name: 'Codebase Explorer',
    systemPrompt:
      'You are a fast codebase exploration agent. Search files with glob, search content with grep, read files with readFile. ' +
      'Be thorough but concise. Report file paths and key findings.',
    keywords: ['explore', 'find', 'search', 'where', 'how does', 'codebase', '查找', '搜索', '代码在哪', '哪里'],
    toolProfile: 'minimal',
  },
  planner: {
    name: 'Implementation Planner',
    systemPrompt:
      'You are a software architect agent. Read existing code to design implementation plans. ' +
      'Identify critical files, consider trade-offs, and return step-by-step plans. Do NOT write code.',
    keywords: ['plan', 'design', 'architect', 'how to implement', '计划', '设计', '架构', '怎么实现'],
    toolProfile: 'minimal',
  },
  coder: {
    name: 'Code Writer',
    systemPrompt:
      'You are a coding agent. Write clean, correct code following existing patterns. ' +
      'Read before modifying. Use editFile for targeted changes, writeFile only for new files. Run tests after changes.',
    keywords: ['write', 'implement', 'fix', 'bug', 'code', 'refactor', '写代码', '实现', '修复', '重构'],
    toolProfile: 'coding',
  },
  reviewer: {
    name: 'Code Reviewer',
    systemPrompt:
      'You are a code review agent. Read changed files, analyze code quality, correctness, security, and performance. ' +
      'Provide specific feedback with file:line references.',
    keywords: ['review', 'check', 'audit', '审查', '检查', '代码审查'],
    toolProfile: 'minimal',
  },
  implement: {
    name: 'Implementer Agent',
    systemPrompt:
      'You are a precise implementation agent. Read relevant code first, then apply targeted edits. ' +
      'Minimize changes — do not refactor beyond scope. Run a syntax check after changes.',
    keywords: ['implement', 'implementer', 'apply change', '实现', '执行变更'],
    toolProfile: 'coding',
  },
  verify: {
    name: 'Verifier Agent',
    systemPrompt:
      'You are a verification agent. Run tests, linters, type checks, and builds to validate changes. ' +
      'Report pass/fail with exact error output. Do NOT fix issues — only report findings.',
    keywords: ['verify', 'verifier', 'validate', 'test runner', '验证', '测试验收'],
    toolProfile: 'verification',
  },
  codex: {
    name: 'Codex Sub-Agent',
    systemPrompt:
      'You are a coding sub-agent routed via OpenAI Codex. Solve the assigned coding task end-to-end, ' +
      'use shell/file tools when needed, and return concise technical output.',
    keywords: ['codex', 'openai codex', 'gpt-5-codex'],
    toolProfile: 'coding',
    preferredAdapter: 'codex',
  },
  claude: {
    name: 'Claude Sub-Agent',
    systemPrompt:
      'You are a coding sub-agent routed via Claude. Solve the assigned coding task end-to-end, ' +
      'use shell/file tools when needed, and return concise technical output.',
    keywords: ['claude', 'claude code', 'anthropic'],
    toolProfile: 'coding',
    preferredAdapter: 'claude',
  },

  // ── Claude-style built-in agent templates (compat aliases) ───────────
  'general-purpose': {
    name: 'General Purpose',
    systemPrompt:
      'You are a general-purpose autonomous coding agent. Solve tasks end-to-end with clear progress updates, ' +
      'call tools when needed, and provide concise technical summaries.',
    keywords: ['general-purpose', 'general purpose', '通用代理', '综合执行'],
    toolProfile: 'coding',
  },
  Explore: {
    name: 'Explore',
    systemPrompt:
      'You are an exploration agent. Search codebases quickly using glob/grep/read tools and report concrete findings with file paths.',
    keywords: ['explore', 'exploration', 'scan codebase', '代码探索', '仓库探索'],
    toolProfile: 'minimal',
  },
  Plan: {
    name: 'Plan',
    systemPrompt:
      'You are a planning agent. Break requests into executable steps with explicit risks, dependencies, and validation strategy.',
    keywords: ['plan', 'planning', 'execution plan', '制定计划', '任务拆解'],
    toolProfile: 'minimal',
  },
  verification: {
    name: 'Verification',
    systemPrompt:
      'You are a verification agent. Validate assumptions, run checks/tests where possible, and report pass/fail with evidence.',
    keywords: ['verification', 'verify', 'validation', '检查验证', '验收'],
    toolProfile: 'minimal',
  },
  'claude-code-guide': {
    name: 'Claude Code Guide',
    systemPrompt:
      'You are a Claude Code workflow guide. Recommend tool-first execution patterns, permissions flow, and concise progress reporting.',
    keywords: ['claude-code-guide', 'claude code guide', 'claude workflow', 'claude 规范'],
    toolProfile: 'minimal',
  },
};

// Load custom agent roles from config file if available
function loadAgentRoles() {
  const customPath = path.join(os.homedir(), '.khyquant', 'agent_roles.json');
  try {
    if (fs.existsSync(customPath)) {
      const custom = JSON.parse(fs.readFileSync(customPath, 'utf-8'));
      // Merge: custom roles override defaults by key
      return { ...DEFAULT_AGENT_ROLES, ...custom };
    }
  } catch { /* fallback to defaults */ }
  return DEFAULT_AGENT_ROLES;
}

const AGENT_ROLES = loadAgentRoles();

function resolveRoleKey(roleKey) {
  const raw = String(roleKey || '').trim();
  if (!raw) return 'general';
  if (AGENT_ROLES[raw]) return raw;

  const normalized = normalizeAgentRole(raw);
  if (AGENT_ROLES[normalized]) return normalized;

  if (/^general[-_\s]?purpose$/i.test(raw) && AGENT_ROLES['general-purpose']) return 'general-purpose';
  if (/^explore$/i.test(raw) && AGENT_ROLES.Explore) return 'Explore';
  if (/^plan$/i.test(raw) && AGENT_ROLES.Plan) return 'Plan';

  return AGENT_ROLES.general ? 'general' : Object.keys(AGENT_ROLES)[0];
}

/**
 * Decompose a complex task into sub-tasks for parallel agent execution.
 * Uses keyword matching from agent role definitions.
 * @param {string} description - user's request
 * @returns {Array<{role: string, name: string, task: string}>}
 */
function decomposeTask(description) {
  const subtasks = [];
  const lower = description.toLowerCase();

  // Match agents by their keywords
  for (const [roleKey, role] of Object.entries(AGENT_ROLES)) {
    if (roleKey === 'general') continue; // general is fallback only
    if (!role.keywords || role.keywords.length === 0) continue;

    const matched = role.keywords.some(kw => lower.includes(kw.toLowerCase()));
    if (matched) {
      const resolvedRole = resolveRoleKey(roleKey);
      const resolved = AGENT_ROLES[resolvedRole] || role;
      subtasks.push({ role: resolvedRole, name: resolved.name, task: description });
    }
  }

  // Auto-compose generic dev workflows when multiple dev roles match
  const devRoles = ['explore', 'planner', 'coder', 'reviewer'];
  const matchedDev = subtasks.filter(st => devRoles.includes(st.role));
  if (matchedDev.length >= 2) {
    // Complex dev task: ensure explore runs first (then coder/planner)
    const hasExplore = matchedDev.some(st => st.role === 'explore');
    if (!hasExplore) {
      const exploreRole = resolveRoleKey('explore');
      subtasks.unshift({ role: exploreRole, name: (AGENT_ROLES[exploreRole] || AGENT_ROLES.explore).name, task: description });
    }
    return _dedupeSubtasks(subtasks);
  }

  // If no specific agents matched, or if it's a comprehensive analysis, use default set
  if (subtasks.length === 0 || /全面|综合|多角度|多智能体|complete|comprehensive/.test(lower)) {
    // Pick first 4 non-general, non-dev agents as default set (finance-oriented)
    const defaultRoles = Object.entries(AGENT_ROLES)
      .filter(([key]) => key !== 'general' && !devRoles.includes(key))
      .slice(0, 4);
    return defaultRoles.map(([key, role]) => ({
      role: key, name: role.name, task: description,
    }));
  }

  return _dedupeSubtasks(subtasks);
}

function _dedupeSubtasks(subtasks) {
  const out = [];
  const seen = new Set();
  for (const st of subtasks) {
    const roleKey = resolveRoleKey(st.role);
    if (seen.has(roleKey)) continue;
    seen.add(roleKey);
    const role = AGENT_ROLES[roleKey] || AGENT_ROLES.general;
    out.push({ ...st, role: roleKey, name: role?.name || st.name });
  }
  return out;
}

/**
 * Run multiple agents in parallel with staggered starts.
 * @param {Array<{role: string, name: string, task: string}>} subtasks
 * @param {object} opts - { ai (the ai module), onProgress(agentIndex, status, detail) }
 * @returns {Promise<Array<{role: string, name: string, status: string, result: string, toolCalls: number, tokens: number, elapsed: number}>>}
 */
async function runAgents(subtasks, opts = {}) {
  const { ai: aiModule, onProgress } = opts;
  const results = new Array(subtasks.length).fill(null);
  const preferredAdapterOverride = String(opts.preferredAdapter || '').trim();
  const preferredModelOverride = String(opts.preferredModel || opts.model || '').trim();

  // Initialize agent states
  const agentStates = subtasks.map((st, i) => ({
    role: st.role,
    name: st.name,
    status: 'pending',
    toolCalls: 0,
    tokens: 0,
    elapsed: 0,
    detail: '',
    result: '',
  }));

  // Report initial state
  if (onProgress) onProgress(agentStates);

  // Concurrency-limited parallel execution
  let running = 0;
  let nextIndex = 0;

  return new Promise((resolve) => {
    function tryStartNext() {
      while (running < MAX_CONCURRENT && nextIndex < subtasks.length) {
        const idx = nextIndex++;
        running++;

        // Stagger starts
        const delay = idx > 0 ? STAGGER_MS * idx : 0;
        setTimeout(() => executeAgent(idx), delay);
      }
    }

    async function executeAgent(idx) {
      const subtask = subtasks[idx];
      const resolvedRole = resolveRoleKey(subtask.role);
      const role = AGENT_ROLES[resolvedRole] || AGENT_ROLES.general;
      agentStates[idx].role = resolvedRole;

      agentStates[idx].status = 'running';
      agentStates[idx].detail = '分析中...';
      if (onProgress) onProgress(agentStates);

      const startTime = Date.now();
      try {
        // Build agent-specific prompt
        const agentPrompt = `${role.systemPrompt}\n\n用户请求: ${subtask.task}\n\n请简洁专业地给出你的分析（不超过 300 字）。`;

        // Get profile-filtered tool definitions for this agent
        const chatOpts = {
          _isFollowUp: true,
          effort: 'medium',
        };
        const subtaskPreferredAdapter = String(
          preferredAdapterOverride
          || subtask.preferredAdapter
          || role.preferredAdapter
          || ''
        ).trim();
        const subtaskPreferredModel = String(
          preferredModelOverride
          || subtask.preferredModel
          || role.preferredModel
          || ''
        ).trim();
        if (subtaskPreferredAdapter) chatOpts.preferredAdapter = subtaskPreferredAdapter;
        if (subtaskPreferredModel) chatOpts.preferredModel = subtaskPreferredModel;
        if (role.toolProfile) {
          try {
            chatOpts.toolDefinitions = getToolRegistry().getDefinitions(role.toolProfile);
          } catch { /* fallback: no filtering */ }
        }

        const result = await aiModule.chat(agentPrompt, chatOpts);

        const elapsed = Date.now() - startTime;
        agentStates[idx].status = 'completed';
        agentStates[idx].detail = 'Done';
        agentStates[idx].result = result.reply || '';
        agentStates[idx].tokens = result.tokenUsage?.totalTokens || 0;
        agentStates[idx].elapsed = elapsed;
        agentStates[idx].toolCalls = (result.commands || []).length;
      } catch (err) {
        agentStates[idx].status = 'error';
        agentStates[idx].detail = err.message || 'Failed';
        agentStates[idx].elapsed = Date.now() - startTime;
      }

      if (onProgress) onProgress(agentStates);

      running--;
      tryStartNext();

      // Check if all done
      if (agentStates.every(a => a.status === 'completed' || a.status === 'error')) {
        resolve(agentStates);
      }
    }

    tryStartNext();
  });
}

/**
 * Synthesize results from multiple agents into a unified response.
 * @param {Array<{name: string, result: string}>} agentResults
 * @param {string} originalRequest - the user's original request
 * @param {object} aiModule - the ai module
 * @returns {string} synthesized response
 */
async function synthesizeResults(agentResults, originalRequest, aiModule) {
  const validResults = agentResults.filter(r => r.status === 'completed' && r.result);

  if (validResults.length === 0) {
    return '所有智能体均未能返回有效结果，请稍后重试。';
  }

  if (validResults.length === 1) {
    return validResults[0].result;
  }

  // Build synthesis prompt
  const agentOutputs = validResults.map(r =>
    `### ${r.name}\n${r.result}`
  ).join('\n\n');

  const synthesisPrompt = `以下是多位专业分析师对同一问题的独立分析结果。请综合各方观点，给出一个全面、平衡的最终分析报告。

原始问题: ${originalRequest}

${agentOutputs}

请输出:
1. 综合分析（整合各方观点，标注一致性和分歧点）
2. 核心结论
3. 行动建议

注意: 这是基于技术分析的参考意见，不构成投资建议。`;

  const result = await aiModule.chat(synthesisPrompt, { _isFollowUp: true });
  return result.reply || agentOutputs;
}

/**
 * Check if a request should trigger multi-agent mode.
 * @param {string} input
 * @returns {boolean}
 */
function shouldUseMultiAgent(input) {
  return /多智能体|全面分析|多角度|综合分析|complete analysis|multi.?agent/i.test(input);
}

function listAgentTemplates() {
  return Object.entries(AGENT_ROLES).map(([key, role]) => ({
    key,
    name: role.name,
    toolProfile: role.toolProfile || 'full',
    keywordCount: Array.isArray(role.keywords) ? role.keywords.length : 0,
  }));
}

module.exports = {
  decomposeTask,
  runAgents,
  synthesizeResults,
  shouldUseMultiAgent,
  resolveRoleKey,
  listAgentTemplates,
  AGENT_ROLES,
  MAX_CONCURRENT,
};
