/**
 * Centralized auto-cleanup service for ~/.khyquant/ persistent data.
 *
 * Manages:
 *  - Security log rotation (5 MB cap, gzip, keep 2 archives)
 *  - Growth snapshots pruning (max 10)
 *  - Training interaction records trimming (10 000 lines / 50 MB)
 *  - Telemetry export pruning (max 5 files)
 *
 * Already self-cleaning (not touched here):
 *  - Conversations (MAX_SAVED_CONVERSATIONS = 20)
 *  - Command history (MAX_HISTORY = 500)
 *  - Token usage (90-day daily / 6-month monthly)
 *  - Growth strategies (500) / analysis patterns (200)
 *  - Knowledge base (200 entries)
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');

const BASE_DIR = path.join(os.homedir(), '.khyquant');
const BACKEND_ROOT = process.env.KHYQUANT_ROOT || path.resolve(__dirname, '..', '..');

// ── Limits ──────────────────────────────────────────────────────────────
const SECURITY_LOG_MAX_BYTES = 5 * 1024 * 1024;   // 5 MB
const SECURITY_LOG_KEEP_ARCHIVES = 2;
const SNAPSHOTS_MAX_KEEP = 10;
const TRAINING_MAX_LINES = 10_000;
const TRAINING_MAX_BYTES = 50 * 1024 * 1024;       // 50 MB
const TELEMETRY_MAX_FILES = 5;
const TEMP_MAX_AGE_HOURS = 24;
const LOG_MAX_AGE_HOURS = 168;  // 7 days
const LOG_MAX_FILES = 20;
const TEMP_MAX_SIZE_BYTES = 100 * 1024 * 1024;  // 100 MB
const LOG_MAX_SIZE_BYTES = 50 * 1024 * 1024;     // 50 MB
const OS_TEMP_MAX_AGE_HOURS = 1;

// Only managed prefixes are eligible for OS-temp cleanup.
// Keep this explicit to avoid touching unrelated third-party temp files.
const OS_TEMP_PREFIXES = [
  'khy_',
  'khy-',
  'khyquant_',
  'khyquant-',
];

// File extensions that are always safe to clean
const JUNK_EXTENSIONS = new Set([
  '.tmp', '.temp', '.bak', '.swp', '.swo', '.pid',
  '.log.1', '.log.2', '.log.3', '.log.4', '.log.5',
]);

let _periodicTimer = null;
let _lastCleanupReport = null;

// ── Helpers ─────────────────────────────────────────────────────────────

function safeSize(filePath) {
  try { return fs.statSync(filePath).size; } catch { return 0; }
}

function safeLs(dir) {
  try { return fs.readdirSync(dir); } catch { return []; }
}

function humanSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function atomicWriteText(filePath, content) {
  const dir = path.dirname(filePath);
  const base = path.basename(filePath);
  const tmpPath = path.join(
    dir,
    `.${base}.tmp.${process.pid}.${Date.now()}`
  );
  fs.writeFileSync(tmpPath, content, 'utf-8');
  try {
    fs.renameSync(tmpPath, filePath);
  } catch (err) {
    try { fs.unlinkSync(tmpPath); } catch { /* ignore */ }
    throw err;
  }
}

function safeTreeSize(entryPath) {
  try {
    const stat = fs.lstatSync(entryPath);
    if (stat.isFile()) return stat.size;
    if (!stat.isDirectory()) return 0;
  } catch {
    return 0;
  }

  let total = 0;
  const stack = [entryPath];
  while (stack.length > 0) {
    const cur = stack.pop();
    let entries = [];
    try {
      entries = fs.readdirSync(cur, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const fp = path.join(cur, e.name);
      try {
        if (e.isDirectory()) {
          stack.push(fp);
        } else if (e.isFile()) {
          total += fs.statSync(fp).size;
        }
      } catch { /* skip broken nodes */ }
    }
  }
  return total;
}

function isManagedOsTempEntry(name) {
  return OS_TEMP_PREFIXES.some(prefix => name.startsWith(prefix));
}

function recordCleanupTarget(metrics, name, action, extra = {}) {
  const startedAt = Date.now();
  let result;
  try {
    result = action();
  } catch (err) {
    result = { error: err.message || String(err) };
  }

  const elapsedMs = Date.now() - startedAt;
  const metric = {
    name,
    elapsedMs,
    ok: !result || !result.error,
    ...extra,
  };

  if (typeof result?.removed === 'number') metric.removed = result.removed;
  if (typeof result?.bytes === 'number') metric.bytes = result.bytes;
  if (typeof result?.kept === 'number') metric.kept = result.kept;
  if (typeof result?.rotated === 'boolean') metric.rotated = result.rotated;
  if (typeof result?.trimmed === 'boolean') metric.trimmed = result.trimmed;
  if (!metric.ok) metric.error = String(result.error || 'unknown error').slice(0, 200);

  metrics.targets.push(metric);
  if (!metric.ok) metrics.failureCount += 1;
  return result;
}

function setLastCleanupReport(trigger, results) {
  const summary = results?.summary || {};
  const metrics = results?.metrics || {};
  const targets = Array.isArray(metrics.targets)
    ? metrics.targets.map(t => ({ ...t }))
    : [];

  _lastCleanupReport = {
    at: Date.now(),
    trigger: String(trigger || 'manual'),
    freedBytes: summary.freedBytes || 0,
    freedHuman: summary.freedHuman || humanSize(summary.freedBytes || 0),
    actions: Array.isArray(summary.actions) ? [...summary.actions] : [],
    actionCount: Array.isArray(summary.actions) ? summary.actions.length : 0,
    elapsedMs: Number(metrics.elapsedMs || 0),
    targetCount: Number(metrics.targetCount || targets.length || 0),
    failureCount: Number(metrics.failureCount || 0),
    targets,
  };
}

function getLastCleanupReport() {
  if (!_lastCleanupReport) return null;
  return {
    ..._lastCleanupReport,
    actions: [...(_lastCleanupReport.actions || [])],
    targets: Array.isArray(_lastCleanupReport.targets)
      ? _lastCleanupReport.targets.map(t => ({ ...t }))
      : [],
  };
}

// ── Security log rotation ───────────────────────────────────────────────

function rotateSecurityLog() {
  const logPath = path.join(BASE_DIR, 'security.log');
  const size = safeSize(logPath);
  if (size <= SECURITY_LOG_MAX_BYTES) return { rotated: false, size };

  try {
    // Shift existing archives: .2.gz → delete, .1.gz → .2.gz
    for (let i = SECURITY_LOG_KEEP_ARCHIVES; i >= 1; i--) {
      const src = path.join(BASE_DIR, `security.log.${i}.gz`);
      if (i === SECURITY_LOG_KEEP_ARCHIVES) {
        try { fs.unlinkSync(src); } catch { /* OK */ }
      } else {
        const dst = path.join(BASE_DIR, `security.log.${i + 1}.gz`);
        try { fs.renameSync(src, dst); } catch { /* OK */ }
      }
    }

    // Compress current log → .1.gz
    const raw = fs.readFileSync(logPath);
    const compressed = zlib.gzipSync(raw);
    fs.writeFileSync(path.join(BASE_DIR, 'security.log.1.gz'), compressed);
    fs.writeFileSync(logPath, ''); // truncate
    return { rotated: true, originalSize: size, compressedSize: compressed.length };
  } catch (err) {
    return { rotated: false, error: err.message };
  }
}

// ── Growth snapshots pruning ────────────────────────────────────────────

function cleanSnapshots(maxKeep = SNAPSHOTS_MAX_KEEP) {
  const dir = path.join(BASE_DIR, 'growth', 'snapshots');
  const files = safeLs(dir).filter(f => f.endsWith('.json')).sort();

  if (files.length <= maxKeep) return { removed: 0, kept: files.length };

  const toRemove = files.slice(0, files.length - maxKeep);
  let removed = 0, bytes = 0;
  for (const f of toRemove) {
    const fp = path.join(dir, f);
    try {
      bytes += safeSize(fp);
      fs.unlinkSync(fp);
      removed++;
    } catch { /* skip */ }
  }
  return { removed, kept: files.length - removed, bytes };
}

// ── Training data trimming ──────────────────────────────────────────────

function trimTrainingData(maxLines = TRAINING_MAX_LINES) {
  const filePath = path.join(BASE_DIR, 'training', 'interaction_records.jsonl');
  const size = safeSize(filePath);
  if (size === 0) return { trimmed: false, lines: 0, size: 0 };

  // If under size cap, only trim by line count
  if (size <= TRAINING_MAX_BYTES) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const lines = content.split('\n').filter(Boolean);
      if (lines.length <= maxLines) return { trimmed: false, lines: lines.length, size };

      const kept = lines.slice(-maxLines);
      atomicWriteText(filePath, kept.join('\n') + '\n');
      return { trimmed: true, before: lines.length, after: kept.length, freedBytes: size - safeSize(filePath) };
    } catch (err) {
      return { trimmed: false, error: err.message };
    }
  }

  // Over size cap — aggressive trim
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n').filter(Boolean);
    const half = Math.min(maxLines, Math.floor(lines.length / 2));
    const kept = lines.slice(-half);
    atomicWriteText(filePath, kept.join('\n') + '\n');
    return { trimmed: true, before: lines.length, after: kept.length, freedBytes: size - safeSize(filePath) };
  } catch (err) {
    return { trimmed: false, error: err.message };
  }
}

// ── Telemetry exports pruning ───────────────────────────────────────────

function cleanTelemetry(maxFiles = TELEMETRY_MAX_FILES) {
  const dir = path.join(BASE_DIR, 'telemetry');
  const files = safeLs(dir).sort();

  if (files.length <= maxFiles) return { removed: 0, kept: files.length };

  const toRemove = files.slice(0, files.length - maxFiles);
  let removed = 0, bytes = 0;
  for (const f of toRemove) {
    const fp = path.join(dir, f);
    try {
      bytes += safeSize(fp);
      fs.unlinkSync(fp);
      removed++;
    } catch { /* skip */ }
  }
  return { removed, kept: files.length - removed, bytes };
}

// ── Storage report ──────────────────────────────────────────────────────

function getStorageReport() {
  const report = {};

  // Security log
  const logPath = path.join(BASE_DIR, 'security.log');
  report.securityLog = { size: safeSize(logPath), path: logPath };

  // Security log archives
  let archiveSize = 0;
  for (let i = 1; i <= SECURITY_LOG_KEEP_ARCHIVES; i++) {
    archiveSize += safeSize(path.join(BASE_DIR, `security.log.${i}.gz`));
  }
  report.securityLogArchives = { size: archiveSize };

  // Growth snapshots
  const snapDir = path.join(BASE_DIR, 'growth', 'snapshots');
  const snapFiles = safeLs(snapDir);
  let snapSize = 0;
  for (const f of snapFiles) snapSize += safeSize(path.join(snapDir, f));
  report.growthSnapshots = { count: snapFiles.length, size: snapSize, path: snapDir };

  // Training data
  const trainPath = path.join(BASE_DIR, 'training', 'interaction_records.jsonl');
  report.trainingData = { size: safeSize(trainPath), path: trainPath };

  // Telemetry
  const telDir = path.join(BASE_DIR, 'telemetry');
  const telFiles = safeLs(telDir);
  let telSize = 0;
  for (const f of telFiles) telSize += safeSize(path.join(telDir, f));
  report.telemetry = { count: telFiles.length, size: telSize, path: telDir };

  // Conversations
  const convoDir = path.join(BASE_DIR, 'conversations');
  const convoFiles = safeLs(convoDir);
  let convoSize = 0;
  for (const f of convoFiles) convoSize += safeSize(path.join(convoDir, f));
  report.conversations = { count: convoFiles.length, size: convoSize };

  // Total
  report.total = Object.values(report).reduce((acc, v) => acc + (v.size || 0), 0);
  report.totalHuman = humanSize(report.total);

  return report;
}

// ── Run all cleanup ─────────────────────────────────────────────────────

/**
 * Clean a backend directory by file age, count, and total size.
 */
function cleanBackendDir(relDir, { maxAgeHours = TEMP_MAX_AGE_HOURS, maxFiles = Infinity, maxSizeBytes = TEMP_MAX_SIZE_BYTES } = {}) {
  const dirPath = path.join(BACKEND_ROOT, relDir);
  let removed = 0, bytes = 0;
  if (!fs.existsSync(dirPath)) return { removed, bytes };

  try {
    const entries = fs.readdirSync(dirPath);
    const files = [];
    for (const entry of entries) {
      if (entry === '.gitkeep' || entry === '.env') continue;
      const fp = path.join(dirPath, entry);
      try {
        const stat = fs.statSync(fp);
        if (stat.isFile()) files.push({ path: fp, name: entry, size: stat.size, mtime: stat.mtimeMs });
      } catch { /* skip */ }
    }
    files.sort((a, b) => a.mtime - b.mtime); // oldest first

    // Remove old and junk files
    for (const file of files) {
      const ageH = (Date.now() - file.mtime) / (1000 * 60 * 60);
      const ext = path.extname(file.name).toLowerCase();
      if (ageH > maxAgeHours || JUNK_EXTENSIONS.has(ext)) {
        try { fs.unlinkSync(file.path); removed++; bytes += file.size; } catch { /* skip */ }
      }
    }

    // Cap file count
    const remaining = files.filter(f => fs.existsSync(f.path));
    if (remaining.length > maxFiles) {
      for (const file of remaining.slice(0, remaining.length - maxFiles)) {
        try { fs.unlinkSync(file.path); removed++; bytes += file.size; } catch { /* skip */ }
      }
    }

    // Cap total size
    let currentSize = 0;
    for (const entry of safeLs(dirPath)) {
      currentSize += safeSize(path.join(dirPath, entry));
    }
    if (currentSize > maxSizeBytes) {
      const stillExist = files.filter(f => fs.existsSync(f.path));
      for (const file of stillExist) {
        if (currentSize <= maxSizeBytes) break;
        try { fs.unlinkSync(file.path); currentSize -= file.size; removed++; bytes += file.size; } catch { /* skip */ }
      }
    }
  } catch { /* access error */ }

  return { removed, bytes };
}

/**
 * Clean khy OS specific files from OS temp directory.
 */
function cleanOsTempFiles() {
  let removed = 0, bytes = 0;
  const tmpDir = process.env.KHY_OS_TEMP_DIR || os.tmpdir();
  try {
    for (const entry of fs.readdirSync(tmpDir)) {
      if (!isManagedOsTempEntry(entry)) continue;
      const fp = path.join(tmpDir, entry);
      try {
        const stat = fs.lstatSync(fp);
        const ageH = (Date.now() - stat.mtimeMs) / (1000 * 60 * 60);
        if (ageH <= OS_TEMP_MAX_AGE_HOURS) continue;

        if (stat.isFile()) {
          const size = stat.size;
          fs.unlinkSync(fp);
          removed++;
          bytes += size;
          continue;
        }

        if (stat.isDirectory()) {
          const size = safeTreeSize(fp);
          fs.rmSync(fp, { recursive: true, force: true });
          removed++;
          bytes += size;
        }
      } catch { /* skip */ }
    }
  } catch { /* ignore */ }
  return { removed, bytes };
}

function runCleanup(options = {}) {
  const trigger = String(options.trigger || 'manual');
  const metrics = {
    startedAt: Date.now(),
    targets: [],
    failureCount: 0,
  };
  const results = {
    securityLog: recordCleanupTarget(metrics, 'security-log', () => rotateSecurityLog()),
    snapshots: recordCleanupTarget(metrics, 'growth-snapshots', () => cleanSnapshots()),
    trainingData: recordCleanupTarget(metrics, 'training-data', () => trimTrainingData()),
    telemetry: recordCleanupTarget(metrics, 'telemetry-exports', () => cleanTelemetry()),
  };

  // Clean backend temp/intermediate directories
  const backendTargets = [
    { dir: 'temp', maxAgeHours: TEMP_MAX_AGE_HOURS, maxSizeBytes: TEMP_MAX_SIZE_BYTES },
    { dir: 'logs', maxAgeHours: LOG_MAX_AGE_HOURS, maxFiles: LOG_MAX_FILES, maxSizeBytes: LOG_MAX_SIZE_BYTES },
    { dir: 'data/cache', maxAgeHours: 72, maxSizeBytes: TEMP_MAX_SIZE_BYTES },
    { dir: 'ml/data/cache', maxAgeHours: 168, maxSizeBytes: TEMP_MAX_SIZE_BYTES },
  ];

  results.backendCleanup = [];
  for (const target of backendTargets) {
    const r = recordCleanupTarget(
      metrics,
      `backend:${target.dir}`,
      () => cleanBackendDir(target.dir, target),
      { dir: target.dir }
    );
    if (r.removed > 0) results.backendCleanup.push({ dir: target.dir, ...r });
  }

  // Clean OS temp
  const osTmp = recordCleanupTarget(
    metrics,
    'backend:os-temp',
    () => cleanOsTempFiles(),
    { dir: 'os-temp' }
  );
  if (osTmp.removed > 0) results.backendCleanup.push({ dir: 'os-temp', ...osTmp });

  // Clean khy-tool-results 磁盘持久化目录（大工具结果）
  // 借鉴 Claude Code 的 Content Replacement Budget 清理策略
  const toolResultDir = path.join(os.tmpdir(), 'khy-tool-results');
  const toolResultCleanup = recordCleanupTarget(
    metrics,
    'backend:khy-tool-results',
    () => {
      if (!fs.existsSync(toolResultDir)) return { removed: 0, bytes: 0 };
      let removed = 0, bytes = 0;
      try {
        const entries = fs.readdirSync(toolResultDir);
        for (const entry of entries) {
          const fp = path.join(toolResultDir, entry);
          try {
            const stat = fs.statSync(fp);
            // 超过 1 小时的工具结果文件 → 清理
            if (stat.isFile() && (Date.now() - stat.mtimeMs) > 3600000) {
              bytes += stat.size;
              fs.unlinkSync(fp);
              removed++;
            }
          } catch { /* skip */ }
        }
      } catch { /* dir read failed */ }
      return { removed, bytes };
    },
    { dir: 'khy-tool-results' }
  );
  if (toolResultCleanup.removed > 0) results.backendCleanup.push({ dir: 'khy-tool-results', ...toolResultCleanup });

  // Calculate total freed
  let freedBytes = 0;
  if (results.securityLog.rotated) {
    freedBytes += (results.securityLog.originalSize || 0) - (results.securityLog.compressedSize || 0);
  }
  freedBytes += results.snapshots.bytes || 0;
  if (results.trainingData.trimmed) {
    freedBytes += results.trainingData.freedBytes || 0;
  }
  freedBytes += results.telemetry.bytes || 0;

  results.summary = {
    freedBytes,
    freedHuman: humanSize(freedBytes),
    actions: [],
    elapsedMs: 0,
    failureCount: 0,
    targetCount: 0,
  };

  if (results.securityLog.rotated) {
    results.summary.actions.push(`Security log rotated (${humanSize(results.securityLog.originalSize)})`);
  }
  if (results.snapshots.removed > 0) {
    results.summary.actions.push(`Removed ${results.snapshots.removed} old snapshots`);
  }
  if (results.trainingData.trimmed) {
    results.summary.actions.push(`Training data trimmed: ${results.trainingData.before} → ${results.trainingData.after} lines`);
  }
  if (results.telemetry.removed > 0) {
    results.summary.actions.push(`Removed ${results.telemetry.removed} old telemetry exports`);
  }
  for (const bc of results.backendCleanup) {
    if (bc.removed > 0) {
      results.summary.actions.push(`Cleaned ${bc.dir}: ${bc.removed} files (${humanSize(bc.bytes)})`);
      freedBytes += bc.bytes;
    }
  }
  results.summary.freedBytes = freedBytes;
  results.summary.freedHuman = humanSize(freedBytes);
  metrics.finishedAt = Date.now();
  metrics.elapsedMs = metrics.finishedAt - metrics.startedAt;
  metrics.targetCount = metrics.targets.length;
  results.metrics = metrics;
  results.summary.elapsedMs = metrics.elapsedMs;
  results.summary.failureCount = metrics.failureCount;
  results.summary.targetCount = metrics.targetCount;

  setLastCleanupReport(trigger, results);

  return results;
}

/**
 * Start periodic cleanup (every 2 hours). Non-blocking.
 */
function startPeriodicCleanup(options = {}) {
  if (_periodicTimer) return;
  const skipInitial = options && options.skipInitial === true;
  // Initial cleanup on startup
  if (!skipInitial) {
    try { runCleanup({ trigger: 'startup' }); } catch { /* ignore */ }
  }
  _periodicTimer = setInterval(() => {
    try { runCleanup({ trigger: 'periodic' }); } catch { /* ignore */ }
  }, 2 * 60 * 60 * 1000);
  _periodicTimer.unref(); // Don't block process exit
}

/**
 * Stop periodic cleanup.
 */
function stopPeriodicCleanup() {
  if (_periodicTimer) {
    clearInterval(_periodicTimer);
    _periodicTimer = null;
  }
}

module.exports = {
  runCleanup,
  startPeriodicCleanup,
  stopPeriodicCleanup,
  rotateSecurityLog,
  cleanSnapshots,
  trimTrainingData,
  cleanTelemetry,
  cleanBackendDir,
  cleanOsTempFiles,
  getLastCleanupReport,
  getStorageReport,
  humanSize,
};
