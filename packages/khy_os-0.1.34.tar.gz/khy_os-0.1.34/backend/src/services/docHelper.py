#!/usr/bin/env python3
# @pattern Template Method
# -*- coding: utf-8 -*-
"""
KHY OS Document Helper — PDF-to-Word conversion and OCR text extraction.
Called by Node.js tools via subprocess. Outputs JSON to stdout.
Dependencies: pip install khy-os[doc]
"""
import sys
import json
import os

MAX_PDF_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_IMAGE_SIZE = 20 * 1024 * 1024  # 20 MB


def _output(data):
    """Print JSON result to stdout for Node.js to parse."""
    print(json.dumps(data, ensure_ascii=False))


def check_deps():
    """Check which optional dependencies are available."""
    status = {
        "pdf2docx": False,
        "pytesseract": False,
        "pillow": False,
        "tesseract_binary": False,
    }
    try:
        import pdf2docx  # noqa: F401
        status["pdf2docx"] = True
    except ImportError:
        pass
    try:
        from PIL import Image  # noqa: F401
        status["pillow"] = True
    except ImportError:
        pass
    try:
        import pytesseract
        status["pytesseract"] = True
        # Verify tesseract binary is installed
        pytesseract.get_tesseract_version()
        status["tesseract_binary"] = True
    except ImportError:
        pass
    except Exception:
        # pytesseract installed but tesseract binary missing
        status["tesseract_binary"] = False

    _output({"success": True, "deps": status})


def pdf_to_word(input_path, output_path):
    """Convert PDF to Word (.docx) using pdf2docx."""
    try:
        from pdf2docx import Converter
    except ImportError:
        _output({
            "success": False,
            "error": "pdf2docx library not installed. Run: pip install khy-os[doc]",
        })
        return

    if not os.path.isfile(input_path):
        _output({"success": False, "error": f"File not found: {input_path}"})
        return

    size = os.path.getsize(input_path)
    if size > MAX_PDF_SIZE:
        _output({
            "success": False,
            "error": f"PDF too large: {size / (1024 * 1024):.1f}MB (max 50MB)",
        })
        return

    try:
        # Ensure output directory exists
        out_dir = os.path.dirname(output_path)
        if out_dir and not os.path.isdir(out_dir):
            os.makedirs(out_dir, exist_ok=True)

        cv = Converter(input_path)
        cv.convert(output_path)
        cv.close()

        out_size = os.path.getsize(output_path)
        _output({
            "success": True,
            "output": output_path,
            "inputSize": size,
            "outputSize": out_size,
            "message": f"Converted: {os.path.basename(output_path)} ({out_size / 1024:.0f}KB)",
        })
    except Exception as e:
        _output({"success": False, "error": f"PDF conversion failed: {str(e)}"})


def ocr_image(image_path, lang="chi_sim+eng"):
    """Extract text from image using Tesseract OCR."""
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        _output({
            "success": False,
            "error": "OCR dependencies not installed. Run: pip install khy-os[doc] and install Tesseract OCR engine",
            "needsAiFallback": True,
        })
        return

    if not os.path.isfile(image_path):
        _output({"success": False, "error": f"Image not found: {image_path}"})
        return

    size = os.path.getsize(image_path)
    if size > MAX_IMAGE_SIZE:
        _output({
            "success": False,
            "error": f"Image too large: {size / (1024 * 1024):.1f}MB (max 20MB)",
        })
        return

    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang=lang)

        # Calculate average confidence
        conf_data = pytesseract.image_to_data(
            img, lang=lang, output_type=pytesseract.Output.DICT
        )
        confs = [
            int(c)
            for c in conf_data.get("conf", [])
            if str(c).lstrip("-").isdigit() and int(c) > 0
        ]
        avg_conf = sum(confs) / len(confs) if confs else 0

        _output({
            "success": True,
            "text": text.strip(),
            "confidence": round(avg_conf, 1),
            "lang": lang,
            "needsAiFallback": avg_conf < 60,
        })
    except pytesseract.TesseractNotFoundError:
        _output({
            "success": False,
            "error": "Tesseract OCR engine not found. Install: brew install tesseract (macOS) / apt install tesseract-ocr (Linux) / choco install tesseract (Windows)",
            "needsAiFallback": True,
        })
    except Exception as e:
        _output({
            "success": False,
            "error": f"OCR failed: {str(e)}",
            "needsAiFallback": True,
        })


def text_to_docx(text, output_path):
    """Write recognized text into an editable Word (.docx) document."""
    try:
        from docx import Document
    except ImportError:
        _output({
            "success": False,
            "error": "python-docx not available. It is normally installed with pdf2docx. Run: pip install khy-os[doc]",
        })
        return

    if not text or not text.strip():
        _output({"success": False, "error": "No text to write"})
        return

    try:
        out_dir = os.path.dirname(output_path)
        if out_dir and not os.path.isdir(out_dir):
            os.makedirs(out_dir, exist_ok=True)

        doc = Document()
        for paragraph in text.split("\n"):
            doc.add_paragraph(paragraph)
        doc.save(output_path)

        out_size = os.path.getsize(output_path)
        _output({
            "success": True,
            "output": output_path,
            "outputSize": out_size,
            "message": f"Saved: {os.path.basename(output_path)} ({out_size / 1024:.0f}KB)",
        })
    except Exception as e:
        _output({"success": False, "error": f"Failed to create Word document: {str(e)}"})


if __name__ == "__main__":
    if len(sys.argv) < 2:
        _output({"success": False, "error": "Usage: docHelper.py <check|pdf2word|ocr> [args]"})
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "check":
        check_deps()
    elif cmd == "pdf2word":
        if len(sys.argv) < 4:
            _output({"success": False, "error": "Usage: docHelper.py pdf2word <input.pdf> <output.docx>"})
            sys.exit(1)
        pdf_to_word(sys.argv[2], sys.argv[3])
    elif cmd == "ocr":
        if len(sys.argv) < 3:
            _output({"success": False, "error": "Usage: docHelper.py ocr <image_path> [lang]"})
            sys.exit(1)
        lang = sys.argv[3] if len(sys.argv) > 3 else "chi_sim+eng"
        ocr_image(sys.argv[2], lang)
    elif cmd == "text2docx":
        if len(sys.argv) < 4:
            _output({"success": False, "error": "Usage: docHelper.py text2docx <text> <output.docx>"})
            sys.exit(1)
        text_to_docx(sys.argv[2], sys.argv[3])
    else:
        _output({"success": False, "error": f"Unknown command: {cmd}"})
        sys.exit(1)
