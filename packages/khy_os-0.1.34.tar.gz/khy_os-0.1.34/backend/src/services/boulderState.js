'use strict';

/**
 * boulderState.js — Cross-session checkpoint persistence for agentic harness.
 *
 * Saves/loads Ralph Loop progress to disk so an interrupted session can
 * resume from where it left off (within a 24-hour TTL window).
 *
 * Storage: <dataHome>/boulder/<md5(cwd)>.json
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SCHEMA_VERSION = 1;
const TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const MAX_USER_MESSAGE_LEN = 2000;
const MAX_TOOL_CALL_LOG_ENTRIES = 50;

function _cwdHash(cwd) {
  return crypto.createHash('md5').update(String(cwd || '')).digest('hex');
}

function _boulderDir() {
  const { getDataDir } = require('../utils/dataHome');
  return getDataDir('boulder');
}

function _boulderPath(cwd) {
  return path.join(_boulderDir(), `${_cwdHash(cwd)}.json`);
}

/**
 * Save boulder checkpoint state to disk.
 * @param {string} cwd - Working directory (used as isolation key)
 * @param {object} state - Checkpoint data
 * @param {string}  state.taskId - Unique identifier for the task
 * @param {string}  state.userMessage - Original user message (truncated to 2000 chars)
 * @param {Array}   [state.toolCallLog] - Last N tool call entries
 * @param {number}  [state.iterations] - Total iterations completed
 * @param {number}  [state.continuationRound] - Current Ralph Loop round
 * @param {string[]} [state.activatedModes] - IntentGate activated modes
 * @param {string}  [state.status] - 'in_progress' | 'completed' | 'failed'
 */
function saveBoulderState(cwd, state) {
  if (!cwd || !state) return;
  const filePath = _boulderPath(cwd);
  const record = {
    schemaVersion: SCHEMA_VERSION,
    taskId: state.taskId || _cwdHash(cwd + Date.now()),
    userMessage: String(state.userMessage || '').slice(0, MAX_USER_MESSAGE_LEN),
    toolCallLog: Array.isArray(state.toolCallLog)
      ? state.toolCallLog.slice(-MAX_TOOL_CALL_LOG_ENTRIES)
      : [],
    iterations: Number(state.iterations) || 0,
    continuationRound: Number(state.continuationRound) || 0,
    activatedModes: Array.isArray(state.activatedModes) ? state.activatedModes : [],
    status: state.status || 'in_progress',
    lastCheckpointAt: Date.now(),
  };
  try {
    fs.writeFileSync(filePath, JSON.stringify(record, null, 2), 'utf-8');
  } catch { /* best-effort — never throw */ }
}

/**
 * Load boulder checkpoint state from disk.
 * Returns null if no checkpoint exists or it has expired (24h TTL).
 * @param {string} cwd
 * @returns {object|null}
 */
function loadBoulderState(cwd) {
  if (!cwd) return null;
  const filePath = _boulderPath(cwd);
  try {
    if (!fs.existsSync(filePath)) return null;
    const raw = fs.readFileSync(filePath, 'utf-8');
    const record = JSON.parse(raw);
    if (!record || record.schemaVersion !== SCHEMA_VERSION) return null;
    // TTL check
    if (Date.now() - (record.lastCheckpointAt || 0) > TTL_MS) {
      // Expired — clean up
      try { fs.unlinkSync(filePath); } catch { /* ignore */ }
      return null;
    }
    return record;
  } catch {
    return null;
  }
}

/**
 * Clear boulder checkpoint for a given cwd.
 * @param {string} cwd
 */
function clearBoulderState(cwd) {
  if (!cwd) return;
  try {
    const filePath = _boulderPath(cwd);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch { /* ignore */ }
}

/**
 * Check whether a pending boulder checkpoint exists for the given cwd.
 * @param {string} cwd
 * @returns {boolean}
 */
function hasPendingBoulder(cwd) {
  const state = loadBoulderState(cwd);
  return !!(state && state.status === 'in_progress');
}

/**
 * Simple message similarity check — compares first N characters.
 * Used to avoid resuming a checkpoint from a completely unrelated task.
 * @param {string} current
 * @param {string} saved
 * @returns {boolean}
 */
function isSimilarMessage(current, saved) {
  if (!current || !saved) return false;
  const a = String(current).trim().slice(0, 200).toLowerCase();
  const b = String(saved).trim().slice(0, 200).toLowerCase();
  if (a === b) return true;
  // Jaccard-like word overlap (>50% overlap = similar)
  const wordsA = new Set(a.split(/\s+/).filter(Boolean));
  const wordsB = new Set(b.split(/\s+/).filter(Boolean));
  if (wordsA.size === 0 || wordsB.size === 0) return false;
  let overlap = 0;
  for (const w of wordsA) { if (wordsB.has(w)) overlap++; }
  const unionSize = new Set([...wordsA, ...wordsB]).size;
  return (overlap / unionSize) > 0.5;
}

// For tests: reset module-level state
function _resetForTest() {
  // No module-level caches to reset currently
}

module.exports = {
  saveBoulderState,
  loadBoulderState,
  clearBoulderState,
  hasPendingBoulder,
  isSimilarMessage,
  _resetForTest,
  // Expose for testing
  _boulderPath,
  _cwdHash,
  SCHEMA_VERSION,
  TTL_MS,
};
