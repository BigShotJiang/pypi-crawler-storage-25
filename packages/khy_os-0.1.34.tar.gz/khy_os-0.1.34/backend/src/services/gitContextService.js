/**
 * Git Context Service — memoized git context for system prompt injection.
 *
 * Collects git status, branch, recent log, and staged diff at session start
 * and caches the result. This mirrors Claude Code's behavior of injecting
 * git context into the system prompt rather than relying on tool calls.
 *
 * The cache is invalidated after a configurable TTL (default: 60s) or
 * when explicitly refreshed.
 */
'use strict';

const { execSync } = require('child_process');

const DEFAULT_TTL_MS = 60_000;
const MAX_DIFF_CHARS = 4000;
const MAX_LOG_ENTRIES = 15;

let _cache = null;
let _cacheTime = 0;
let _cacheCwd = null;

/**
 * @typedef {object} GitContext
 * @property {string} branch      - Current branch name
 * @property {string} mainBranch  - Detected main/master branch
 * @property {string} status      - Short git status output
 * @property {string} recentLog   - Recent commit log (oneline format)
 * @property {string} stagedDiff  - Staged diff preview (truncated)
 * @property {boolean} isDirty    - Whether working tree has uncommitted changes
 * @property {boolean} isGitRepo  - Whether cwd is inside a git repository
 */

/**
 * Run a git command and return stdout, or null on failure.
 * @param {string} cmd
 * @param {string} cwd
 * @returns {string|null}
 */
function _git(cmd, cwd) {
  try {
    return execSync(`git ${cmd}`, {
      cwd,
      encoding: 'utf-8',
      timeout: 5000,
      stdio: ['pipe', 'pipe', 'pipe'],
    }).trim();
  } catch {
    return null;
  }
}

/**
 * Detect the main branch name (main or master).
 * @param {string} cwd
 * @returns {string}
 */
function _detectMainBranch(cwd) {
  // Check remote HEAD
  const remoteHead = _git('symbolic-ref refs/remotes/origin/HEAD', cwd);
  if (remoteHead) {
    const match = remoteHead.match(/refs\/remotes\/origin\/(.+)/);
    if (match) return match[1];
  }
  // Fallback: check if main or master exists
  const branches = _git('branch --list main master', cwd);
  if (branches) {
    if (branches.includes('main')) return 'main';
    if (branches.includes('master')) return 'master';
  }
  return 'main';
}

/**
 * Collect git context for the given working directory.
 *
 * @param {string} [cwd] - Working directory (defaults to process.cwd())
 * @param {object} [options]
 * @param {number} [options.ttlMs] - Cache TTL in milliseconds
 * @param {boolean} [options.force] - Force refresh (ignore cache)
 * @returns {GitContext}
 */
function collectGitContext(cwd, options = {}) {
  cwd = cwd || process.cwd();
  const ttl = options.ttlMs || DEFAULT_TTL_MS;

  // Check cache
  if (!options.force && _cache && _cacheCwd === cwd && (Date.now() - _cacheTime) < ttl) {
    return _cache;
  }

  // Check if in a git repo
  const root = _git('rev-parse --show-toplevel', cwd);
  if (!root) {
    const empty = {
      branch: '',
      mainBranch: '',
      status: '',
      recentLog: '',
      stagedDiff: '',
      isDirty: false,
      isGitRepo: false,
    };
    _cache = empty;
    _cacheTime = Date.now();
    _cacheCwd = cwd;
    return empty;
  }

  const branch = _git('rev-parse --abbrev-ref HEAD', cwd) || '';
  const mainBranch = _detectMainBranch(cwd);
  const status = _git('status --short --branch -u', cwd) || '';
  const isDirty = status.split('\n').some(line => line.length > 0 && !line.startsWith('##'));

  const recentLog = _git(`log --oneline -${MAX_LOG_ENTRIES} --no-decorate`, cwd) || '';

  let stagedDiff = _git('diff --cached --stat', cwd) || '';
  if (stagedDiff && stagedDiff.length > MAX_DIFF_CHARS) {
    stagedDiff = stagedDiff.slice(0, MAX_DIFF_CHARS) + '\n... (truncated)';
  }

  const ctx = {
    branch,
    mainBranch,
    status: status.slice(0, 2000),
    recentLog: recentLog.slice(0, 3000),
    stagedDiff,
    isDirty,
    isGitRepo: true,
  };

  _cache = ctx;
  _cacheTime = Date.now();
  _cacheCwd = cwd;
  return ctx;
}

/**
 * Format git context as a system prompt section.
 * @param {GitContext} ctx
 * @returns {string}
 */
function formatForSystemPrompt(ctx) {
  if (!ctx || !ctx.isGitRepo) return '';

  const lines = [
    '# Git Context',
    '',
    `Branch: ${ctx.branch}`,
    `Main branch: ${ctx.mainBranch}`,
    `Dirty: ${ctx.isDirty ? 'yes' : 'no'}`,
  ];

  if (ctx.status) {
    lines.push('', '## Status', '```', ctx.status, '```');
  }

  if (ctx.recentLog) {
    lines.push('', '## Recent Commits', '```', ctx.recentLog, '```');
  }

  if (ctx.stagedDiff) {
    lines.push('', '## Staged Changes', '```', ctx.stagedDiff, '```');
  }

  return lines.join('\n');
}

/**
 * Invalidate the cached git context.
 */
function invalidateCache() {
  _cache = null;
  _cacheTime = 0;
  _cacheCwd = null;
}

module.exports = {
  collectGitContext,
  formatForSystemPrompt,
  invalidateCache,
  DEFAULT_TTL_MS,
};
