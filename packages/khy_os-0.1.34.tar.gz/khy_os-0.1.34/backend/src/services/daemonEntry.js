'use strict';

/**
 * Daemon Entry Point — runs the AI management server as a background daemon.
 *
 * This file is spawned by daemonManager.daemonStart() as a detached process.
 * It loads aiManagementServer and keeps running until SIGTERM/SIGINT.
 */
const fs = require('fs');
const path = require('path');
const { getDataHome, getLegacyDataHome } = require('../utils/dataHome');

const PORT = parseInt(process.env.KHY_DAEMON_PORT || '9090', 10);
const PID_FILE = process.env.KHY_DAEMON_PID_FILE || '';
const RUNTIME_FILE = path.join(getDataHome(), 'ai_manage_runtime.json');
const LEGACY_RUNTIME_FILE = path.join(getLegacyDataHome(), 'ai_manage_runtime.json');

function log(msg) {
  const ts = new Date().toISOString();
  process.stdout.write(`[${ts}] [daemon] ${msg}\n`);
}

// ── Startup ─────────────────────────────────────────────────────────────

log(`Starting KHY daemon on port ${PORT} (PID ${process.pid})`);

let server = null;
let _actualPort = PORT;

/**
 * 写运行时文件，供 CLI / 前端 / daemonClient 发现实际端口。
 * 格式与 ai-manage-daemon.js writeRuntime() 保持兼容。
 */
function writeRuntime() {
  const payload = {
    pid: process.pid,
    apiPort: _actualPort,
    startupAt: Date.now(),
    updatedAt: Date.now(),
    source: 'daemonEntry',
  };
  const json = JSON.stringify(payload, null, 2);
  for (const file of [RUNTIME_FILE, LEGACY_RUNTIME_FILE]) {
    try {
      const dir = path.dirname(file);
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(file, json, 'utf-8');
    } catch { /* best effort */ }
  }
}

function clearRuntime() {
  for (const file of [RUNTIME_FILE, LEGACY_RUNTIME_FILE]) {
    try { fs.unlinkSync(file); } catch { /* ignore */ }
  }
}

async function start() {
  try {
    // Try to load aiManagementServer
    const mgmtServer = require('./aiManagementServer');
    if (typeof mgmtServer.start === 'function') {
      // start(port) 接收数字参数，返回实际绑定端口（可能因端口冲突自增）
      _actualPort = await mgmtServer.start(PORT);
      if (typeof _actualPort !== 'number') _actualPort = PORT;
      log(`Management server started on port ${_actualPort}`);
    } else if (typeof mgmtServer.createServer === 'function') {
      server = mgmtServer.createServer({ port: PORT });
      _actualPort = PORT;
      log(`Management server created on port ${PORT}`);
    } else {
      // Fallback: start a simple health endpoint
      const http = require('http');
      server = http.createServer((req, res) => {
        if (req.url === '/api/health') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ status: 'ok', pid: process.pid, uptime: process.uptime() }));
        } else {
          res.writeHead(404);
          res.end('Not Found');
        }
      });
      server.listen(PORT, '127.0.0.1', () => {
        log(`Health endpoint started on port ${PORT}`);
      });
    }

    // 写运行时文件，供其他组件发现实际端口
    writeRuntime();
    log(`Runtime file written (apiPort=${_actualPort})`);

    // Restore persisted sessions
    try {
      const sessionPersistence = require('./sessionPersistence');
      const sessions = sessionPersistence.listPersistedSessions();
      log(`Found ${sessions.length} persisted sessions`);
    } catch { /* sessionPersistence not available */ }

  } catch (err) {
    log(`Failed to start: ${err.message}`);
    process.exit(1);
  }
}

// ── Signal handling ─────────────────────────────────────────────────────

function shutdown(signal) {
  log(`Received ${signal}, shutting down...`);

  if (server) {
    if (typeof server.close === 'function') {
      server.close(() => {
        log('Server closed');
        cleanup();
      });
    } else {
      cleanup();
    }
  } else {
    cleanup();
  }

  // Force exit after 5 seconds
  setTimeout(() => {
    log('Force exit after timeout');
    process.exit(0);
  }, 5000).unref();
}

function cleanup() {
  // Remove PID file
  if (PID_FILE) {
    try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
  }
  clearRuntime();
  log('Daemon stopped');
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  log(`Uncaught exception: ${err.message}`);
  log(err.stack || '');
  // Don't crash — daemon should be resilient
});
process.on('unhandledRejection', (reason) => {
  log(`Unhandled rejection: ${reason instanceof Error ? reason.message : reason}`);
});

start();
