'use strict';

/**
 * Memory Provider — 可插拔记忆系统 + 上下文围栏.
 *
 * 借鉴:
 * - Hermes Agent memory_provider.py: MemoryProvider ABC + 生命周期协议
 * - Hermes Agent memory_manager.py: StreamingContextScrubber + 上下文围栏
 * - Claude Code CLAUDE.md: 文件级持久化记忆
 *
 * 架构:
 * - MemoryProvider 基类: initialize/prefetch/syncTurn/shutdown 生命周期
 * - BuiltinProvider: 封装现有 ragRetrievalService + knowledgeTeachingService
 * - MemoryManager: 内建 + 最多 1 个外部 provider
 * - buildMemoryContextBlock(): <memory-context> XML 围栏
 * - StreamingContextScrubber: 状态机过滤跨 chunk 的围栏标签
 *
 * @module memoryProvider
 */

// ── MemoryProvider 基类 ──

/**
 * 记忆提供者抽象基类。
 * 所有记忆后端必须实现此接口。
 */
class MemoryProvider {
  /** @returns {string} 提供者名称 */
  get name() { return 'abstract'; }

  /** @returns {boolean} 是否可用 */
  isAvailable() { return false; }

  /**
   * 初始化 (每个会话调用一次)
   * @param {string} sessionId
   * @param {object} [opts]
   */
  initialize(sessionId, opts = {}) { /* 子类实现 */ }

  /**
   * 预获取与查询相关的记忆 (每轮调用)
   * @param {string} query - 用户输入
   * @param {object} [opts] - { sessionId }
   * @returns {string} 注入 prompt 的记忆文本
   */
  prefetch(query, opts = {}) { return ''; }

  /**
   * 同步本轮交互到记忆 (每轮结束调用)
   * @param {string} userContent
   * @param {string} assistantContent
   * @param {object} [opts]
   */
  syncTurn(userContent, assistantContent, opts = {}) { /* 子类实现 */ }

  /** 关闭资源 */
  shutdown() { /* 子类实现 */ }

  // ── 可选钩子 ──

  /** 会话结束时调用 */
  onSessionEnd(messages) { /* optional */ }

  /** 会话切换时调用 */
  onSessionSwitch(newSessionId, opts = {}) { /* optional */ }

  /** 上下文压缩前调用 — 返回需要保留的关键记忆 */
  onPreCompress(messages) { return ''; }

  /** 记忆写入时调用 */
  onMemoryWrite(action, target, content, metadata = null) { /* optional */ }
}

// ── BuiltinProvider ──

/**
 * 内建记忆提供者 — 封装 ragRetrievalService + knowledgeTeachingService.
 */
class BuiltinProvider extends MemoryProvider {
  constructor() {
    super();
    this._sessionId = null;
    this._rag = null;
    this._knowledge = null;
  }

  get name() { return 'builtin'; }
  isAvailable() { return true; }

  initialize(sessionId) {
    this._sessionId = sessionId;
    try {
      this._rag = require('./ragRetrievalService');
    } catch { this._rag = null; }
    try {
      this._knowledge = require('./knowledgeTeachingService');
    } catch { this._knowledge = null; }
  }

  prefetch(query, opts = {}) {
    const parts = [];

    // RAG 检索
    if (this._rag && typeof this._rag.retrieve === 'function') {
      try {
        const results = this._rag.retrieve(query, { limit: 5 });
        if (results && results.length > 0) {
          parts.push('## 相关知识\n' + results.map(r =>
            `- [${r.source || '知识库'}] ${(r.content || '').slice(0, 300)}`
          ).join('\n'));
        }
      } catch { /* non-fatal */ }
    }

    // 知识推送
    if (this._knowledge && typeof this._knowledge.getContextKnowledge === 'function') {
      try {
        const knowledge = this._knowledge.getContextKnowledge(query);
        if (knowledge) parts.push('## 教学知识\n' + knowledge);
      } catch { /* non-fatal */ }
    }

    return parts.join('\n\n');
  }

  syncTurn(userContent, assistantContent, opts = {}) {
    // 自动知识提炼
    if (this._knowledge && typeof this._knowledge.extractAndSave === 'function') {
      try {
        this._knowledge.extractAndSave(assistantContent, { sessionId: this._sessionId });
      } catch { /* non-fatal */ }
    }
  }

  shutdown() {
    this._rag = null;
    this._knowledge = null;
  }
}

// ── MemoryManager ──

/**
 * 记忆管理器 — 内建 + 最多 1 个外部 provider.
 *
 * 设计借鉴 Hermes Agent memory_manager.py:
 * - 维护 builtin provider + 最多一个 external provider
 * - add_provider 强制检查，防止 tool schema 膨胀
 * - buildMemoryContextBlock 包裹在 <memory-context> 围栏中
 */
class MemoryManager {
  constructor() {
    this._builtin = new BuiltinProvider();
    this._external = null;
    this._sessionId = null;
  }

  /**
   * 初始化管理器
   * @param {string} sessionId
   */
  initialize(sessionId) {
    this._sessionId = sessionId;
    this._builtin.initialize(sessionId);
    if (this._external) this._external.initialize(sessionId);
  }

  /**
   * 添加外部记忆提供者 (最多 1 个)
   * @param {MemoryProvider} provider
   * @throws {Error} 如果已有外部提供者
   */
  addProvider(provider) {
    if (this._external) {
      throw new Error(`已有外部记忆提供者 "${this._external.name}"，不能添加 "${provider.name}"。` +
        '为防止 tool schema 膨胀，同时最多支持 1 个外部提供者。');
    }
    if (!provider.isAvailable()) {
      throw new Error(`记忆提供者 "${provider.name}" 不可用`);
    }
    this._external = provider;
    if (this._sessionId) provider.initialize(this._sessionId);
  }

  /** 移除外部提供者 */
  removeProvider() {
    if (this._external) {
      try { this._external.shutdown(); } catch { /* ok */ }
      this._external = null;
    }
  }

  /**
   * 构建记忆上下文块 (带 XML 围栏)
   * @param {string} query
   * @param {object} [opts]
   * @returns {string} 包裹在 <memory-context> 中的记忆文本, 空则返回 ''
   */
  buildMemoryContextBlock(query, opts = {}) {
    const parts = [];

    for (const provider of this._providers()) {
      try {
        const text = provider.prefetch(query, { sessionId: this._sessionId, ...opts });
        if (text && text.trim()) parts.push(text.trim());
      } catch { /* non-fatal */ }
    }

    if (parts.length === 0) return '';

    return `<memory-context>\n${parts.join('\n---\n')}\n</memory-context>`;
  }

  /**
   * 同步本轮交互到所有 provider
   */
  syncTurn(userContent, assistantContent, opts = {}) {
    for (const provider of this._providers()) {
      try {
        provider.syncTurn(userContent, assistantContent, { sessionId: this._sessionId, ...opts });
      } catch { /* non-fatal */ }
    }
  }

  /**
   * 会话切换通知
   */
  onSessionSwitch(newSessionId, opts = {}) {
    this._sessionId = newSessionId;
    for (const provider of this._providers()) {
      try { provider.onSessionSwitch(newSessionId, opts); } catch { /* ok */ }
    }
  }

  /** 压缩前提取关键记忆 */
  onPreCompress(messages) {
    const parts = [];
    for (const provider of this._providers()) {
      try {
        const text = provider.onPreCompress(messages);
        if (text) parts.push(text);
      } catch { /* ok */ }
    }
    return parts.join('\n');
  }

  shutdown() {
    try { this._builtin.shutdown(); } catch { /* ok */ }
    if (this._external) {
      try { this._external.shutdown(); } catch { /* ok */ }
    }
  }

  /** @private */
  _providers() {
    const list = [this._builtin];
    if (this._external) list.push(this._external);
    return list;
  }
}

// ── StreamingContextScrubber ──

/**
 * 流式上下文清洗器 — 状态机过滤跨 chunk 边界的 <memory-context> 标签.
 *
 * 借鉴 Hermes Agent StreamingContextScrubber:
 * - 防止记忆围栏标签泄漏到用户看到的流式输出中
 * - 跨 chunk 边界安全 (部分标签跨两个 chunk 时正确处理)
 */
class StreamingContextScrubber {
  constructor() {
    this._state = 'normal'; // normal | inside_tag | buffering
    this._buffer = '';
  }

  /**
   * 处理一个流式 chunk.
   * @param {string} chunk
   * @returns {string} 过滤后的 chunk
   */
  process(chunk) {
    if (!chunk) return '';

    let result = '';
    const input = this._buffer + chunk;
    this._buffer = '';

    let i = 0;
    while (i < input.length) {
      if (this._state === 'normal') {
        // 查找 <memory-context> 开始标签
        const openIdx = input.indexOf('<memory-context>', i);
        if (openIdx === -1) {
          // 检查是否有部分标签在末尾
          const partialCheck = input.slice(Math.max(i, input.length - 20));
          if (partialCheck.includes('<memory') || partialCheck.includes('<mem')) {
            // 可能是跨 chunk 的部分标签 — 缓冲
            const cutPoint = input.lastIndexOf('<', input.length - 1);
            if (cutPoint >= i && input.length - cutPoint < 20) {
              result += input.slice(i, cutPoint);
              this._buffer = input.slice(cutPoint);
              return result;
            }
          }
          result += input.slice(i);
          return result;
        }

        result += input.slice(i, openIdx);
        this._state = 'inside_tag';
        i = openIdx + '<memory-context>'.length;
      } else if (this._state === 'inside_tag') {
        // 查找 </memory-context> 结束标签
        const closeIdx = input.indexOf('</memory-context>', i);
        if (closeIdx === -1) {
          // 标签内容跨 chunk — 整段丢弃，等待下个 chunk
          this._buffer = '';
          return result;
        }
        // 跳过整个 memory-context 内容
        i = closeIdx + '</memory-context>'.length;
        this._state = 'normal';
      }
    }

    return result;
  }

  /** 清空状态 */
  reset() {
    this._state = 'normal';
    this._buffer = '';
  }

  /** 返回未消费的缓冲 (flush) */
  flush() {
    const buf = this._buffer;
    this._buffer = '';
    this._state = 'normal';
    // 如果缓冲中有部分标签，全部输出 (宁可泄漏不完整标签也不丢数据)
    return buf;
  }
}

// ── Singleton ──

let _manager = null;

/** 获取全局 MemoryManager 单例 */
function getMemoryManager() {
  if (!_manager) _manager = new MemoryManager();
  return _manager;
}

/** 重置 (测试用) */
function _resetForTest() {
  if (_manager) _manager.shutdown();
  _manager = null;
}

module.exports = {
  MemoryProvider,
  BuiltinProvider,
  MemoryManager,
  StreamingContextScrubber,
  getMemoryManager,
  _resetForTest,
};
