'use strict';

/**
 * Daemon Client — lightweight client for communicating with a running KHY daemon.
 *
 * Used by CLI instances to delegate work to the daemon process.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

/**
 * 从 runtime 文件发现 daemon 的实际 API 端口。
 * @returns {number|null}
 */
function _discoverPortFromRuntime() {
  try {
    const { getDataHome } = require('../utils/dataHome');
    const file = path.join(getDataHome(), 'ai_manage_runtime.json');
    const raw = JSON.parse(fs.readFileSync(file, 'utf-8'));
    if (raw && typeof raw.apiPort === 'number') return raw.apiPort;
  } catch { /* ignore */ }
  return null;
}

class DaemonClient {
  /**
   * @param {object} [opts]
   * @param {number} [opts.port=9090]
   * @param {string} [opts.host='127.0.0.1']
   * @param {number} [opts.timeoutMs=30000]
   */
  constructor(opts = {}) {
    this.port = opts.port
      || parseInt(process.env.KHY_DAEMON_PORT, 10)
      || _discoverPortFromRuntime()
      || 9090;
    this.host = opts.host || '127.0.0.1';
    this.timeoutMs = opts.timeoutMs || 30_000;
  }

  /**
   * Check if daemon is reachable.
   * @returns {Promise<boolean>}
   */
  async isAlive() {
    try {
      await this.getStatus();
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get daemon health status.
   * @returns {Promise<object>}
   */
  async getStatus() {
    return this._get('/api/health');
  }

  /**
   * List persisted sessions.
   * @returns {Promise<Array>}
   */
  async listSessions() {
    try {
      return await this._get('/api/sessions');
    } catch {
      // Sessions endpoint may not exist — fall back to local
      const sp = require('./sessionPersistence');
      return sp.listPersistedSessions();
    }
  }

  /**
   * Send a query/prompt to the daemon.
   * @param {string} prompt
   * @param {object} [opts]
   * @returns {Promise<object>}
   */
  async query(prompt, opts = {}) {
    return this._post('/api/chat', { prompt, ...opts });
  }

  // ── HTTP helpers ──────────────────────────────────────────────────

  _get(urlPath) {
    return new Promise((resolve, reject) => {
      const req = http.get({
        hostname: this.host,
        port: this.port,
        path: urlPath,
        timeout: this.timeoutMs,
      }, (res) => {
        let body = '';
        res.on('data', (chunk) => { body += chunk; });
        res.on('end', () => {
          try { resolve(JSON.parse(body)); }
          catch { resolve(body); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    });
  }

  _post(urlPath, data) {
    const payload = JSON.stringify(data);
    return new Promise((resolve, reject) => {
      const req = http.request({
        hostname: this.host,
        port: this.port,
        path: urlPath,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
        timeout: this.timeoutMs,
      }, (res) => {
        let body = '';
        res.on('data', (chunk) => { body += chunk; });
        res.on('end', () => {
          try { resolve(JSON.parse(body)); }
          catch { resolve(body); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
      req.write(payload);
      req.end();
    });
  }
}

module.exports = { DaemonClient };
