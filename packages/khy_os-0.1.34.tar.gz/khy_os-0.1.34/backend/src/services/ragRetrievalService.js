'use strict';

/**
 * RAG Retrieval Service — lightweight hybrid retrieval for chat augmentation.
 *
 * Goals:
 * - Keep retrieval local and fast (no extra network calls)
 * - Blend structured knowledge base + session history search
 * - Return compact, source-tagged context snippets for prompt augmentation
 */

const MAX_CACHE_ENTRIES = 120;
const DEFAULT_CACHE_TTL_MS = 90_000;
const DEFAULT_KNOWLEDGE_TOPK = 4;
const DEFAULT_SESSION_TOPK = 3;
const DEFAULT_TOTAL_TOPK = 6;
const DEFAULT_MAX_CONTEXT_CHARS = 2_400;

const _cache = new Map();

function _envBool(value, fallback = false) {
  if (value === undefined || value === null || String(value).trim() === '') return fallback;
  const raw = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on', 'y'].includes(raw)) return true;
  if (['0', 'false', 'no', 'off', 'n'].includes(raw)) return false;
  return fallback;
}

function _envInt(value, fallback, min, max) {
  const n = parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n)) return fallback;
  if (typeof min === 'number' && n < min) return min;
  if (typeof max === 'number' && n > max) return max;
  return n;
}

function isEnabled() {
  return _envBool(process.env.KHY_RAG_ENABLED, true);
}

function _isGreetingLike(text = '') {
  const raw = String(text || '').trim().toLowerCase();
  return /^(hi|hello|hey|yo|你好|您好|在吗|在么|嗨)$/.test(raw);
}

function _shouldRetrieve(query = '', options = {}) {
  if (!isEnabled()) return false;
  if (options && options.isFollowUp) return false;
  const text = String(query || '').trim();
  if (!text) return false;
  if (text.startsWith('/')) return false;
  if (_isGreetingLike(text)) return false;
  if (text.length < 4 && !/[\u4e00-\u9fff]/.test(text)) return false;
  return true;
}

function _normalizeSpace(text = '') {
  return String(text || '').replace(/\s+/g, ' ').trim();
}

function _truncate(text = '', maxLen = 220) {
  const normalized = _normalizeSpace(text);
  if (normalized.length <= maxLen) return normalized;
  return `${normalized.slice(0, maxLen - 3)}...`;
}

function _tokenize(text = '') {
  const lower = String(text || '').toLowerCase();
  const parts = lower.match(/[\u4e00-\u9fff]+|[a-z0-9_]+/g) || [];
  const tokens = [];

  for (const part of parts) {
    if (/^[\u4e00-\u9fff]+$/.test(part)) {
      for (let i = 0; i < part.length; i++) {
        tokens.push(part[i]);
        if (i < part.length - 1) tokens.push(part.slice(i, i + 2));
      }
    } else {
      tokens.push(part);
      if (part.length >= 6) {
        tokens.push(part.slice(0, 4));
      }
    }
  }
  return [...new Set(tokens.filter(Boolean))];
}

function _overlapScore(queryTokens = [], text = '') {
  if (!queryTokens.length) return 0;
  const docTokens = new Set(_tokenize(text));
  if (!docTokens.size) return 0;
  let hit = 0;
  for (const token of queryTokens) {
    if (docTokens.has(token)) hit += 1;
  }
  return hit / queryTokens.length;
}

function _keywordScore(query = '', keywords = []) {
  const q = String(query || '').toLowerCase();
  if (!q || !Array.isArray(keywords) || keywords.length === 0) return 0;
  let hits = 0;
  for (const kw of keywords) {
    const k = String(kw || '').toLowerCase().trim();
    if (!k) continue;
    if (q.includes(k) || k.includes(q)) hits += 1;
  }
  const base = Math.min(4, keywords.length) || 1;
  return Math.min(1, hits / base);
}

function _knowledgeCandidates(query = '', limit = DEFAULT_KNOWLEDGE_TOPK) {
  const qTokens = _tokenize(query);
  let raw = [];

  try {
    const knowledge = require('./knowledgeTeachingService');
    if (typeof knowledge.searchKnowledge === 'function') {
      raw = knowledge.searchKnowledge(query) || [];
    }
  } catch {
    raw = [];
  }

  const scored = raw.map((entry) => {
    const title = String(entry.title || '').trim();
    const content = String(entry.content || '').trim();
    const keywords = Array.isArray(entry.keywords) ? entry.keywords : [];
    const textForScore = `${title} ${content} ${keywords.join(' ')}`;
    const overlap = _overlapScore(qTokens, textForScore);
    const kw = _keywordScore(query, keywords);
    const titleBoost = title && (title.includes(query) || query.includes(title)) ? 0.18 : 0;
    const sourceBoost = String(entry.source || '').toLowerCase() === 'learned' ? 0.04 : 0;
    const score = overlap * 0.62 + kw * 0.2 + titleBoost + sourceBoost;
    return {
      kind: 'knowledge',
      source: String(entry.source || 'builtin'),
      category: String(entry.category || '').trim(),
      level: String(entry.level || '').trim(),
      title,
      content,
      keywords,
      score,
    };
  });

  return scored
    .filter(item => item.score > 0.08 && item.content)
    .sort((a, b) => b.score - a.score)
    .slice(0, Math.max(1, limit));
}

function _sessionCandidates(query = '', limit = DEFAULT_SESSION_TOPK) {
  const qTokens = _tokenize(query);
  try {
    const index = require('./sessionSearchIndex');
    if (typeof index.init === 'function') index.init();
    if (typeof index.isAvailable === 'function' && !index.isAvailable()) return [];
    if (typeof index.searchMessages !== 'function') return [];

    const fetchLimit = Math.max(8, limit * 4);
    const rows = index.searchMessages(query, { limit: fetchLimit }) || [];
    return rows.map((row) => {
      const content = String(row.content || '').trim();
      const overlap = _overlapScore(qTokens, content);
      const rank = Number(row.rank);
      const bm25 = Number.isFinite(rank) ? (1 / (1 + Math.abs(rank))) : 0;
      const ageMs = Math.max(0, Date.now() - Number(row.timestamp || Date.now()));
      const ageDays = ageMs / (24 * 60 * 60 * 1000);
      const recency = Math.max(0, 1 - (ageDays / 45));
      const score = overlap * 0.58 + bm25 * 0.27 + recency * 0.15;
      return {
        kind: 'session',
        source: 'session_index',
        sessionId: String(row.sessionId || '').trim(),
        title: String(row.title || '').trim(),
        role: String(row.role || '').trim(),
        content,
        timestamp: Number(row.timestamp || 0),
        score,
      };
    })
      .filter(item => item.score > 0.09 && item.content)
      .sort((a, b) => b.score - a.score)
      .slice(0, Math.max(1, limit));
  } catch {
    return [];
  }
}

function _dedupeCandidates(candidates = []) {
  const seen = new Set();
  const out = [];
  for (const item of candidates) {
    const key = `${item.kind}|${String(item.title || '').slice(0, 80)}|${String(item.content || '').slice(0, 140)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

function _formatContext(candidates = [], maxChars = DEFAULT_MAX_CONTEXT_CHARS) {
  const lines = [
    '以下是检索增强上下文（RAG），仅在与当前问题相关时使用：',
  ];

  for (let i = 0; i < candidates.length; i++) {
    const item = candidates[i];
    const index = i + 1;
    if (item.kind === 'knowledge') {
      const sourceTag = item.source === 'learned' ? '学习知识' : '内置知识';
      const category = item.category || '通用';
      const level = item.level || 'unknown';
      lines.push(`${index}. [${sourceTag}|${category}|${level}] ${item.title || '无标题'}`);
      lines.push(`   ${_truncate(item.content, 220)}`);
    } else {
      const title = item.title || item.sessionId || 'untitled';
      lines.push(`${index}. [历史会话|${title}]`);
      lines.push(`   ${_truncate(item.content, 220)}`);
    }
  }

  lines.push('若上述上下文与当前问题冲突或信息不足，请明确说明不确定性并以当前问题为准。');

  let text = lines.join('\n');
  if (text.length > maxChars) {
    text = `${text.slice(0, Math.max(0, maxChars - 4))}\n...`;
  }
  return text;
}

function _cacheGet(key, ttlMs) {
  const hit = _cache.get(key);
  if (!hit) return null;
  if ((Date.now() - hit.at) > ttlMs) {
    _cache.delete(key);
    return null;
  }
  return hit.value;
}

function _cacheSet(key, value) {
  _cache.set(key, { at: Date.now(), value });
  if (_cache.size > MAX_CACHE_ENTRIES) {
    const oldestKey = _cache.keys().next().value;
    if (oldestKey) _cache.delete(oldestKey);
  }
}

/**
 * Build retrieval context for one user query.
 *
 * @param {string} query
 * @param {object} [options]
 * @param {boolean} [options.isFollowUp=false]
 * @returns {{ used:boolean, context:string, meta:object }}
 */
function buildRetrievalContext(query = '', options = {}) {
  const cleanQuery = String(query || '').trim();
  if (!_shouldRetrieve(cleanQuery, options)) {
    return {
      used: false,
      context: '',
      meta: { reason: 'skipped', selectedCount: 0, knowledgeHits: 0, sessionHits: 0, cacheHit: false },
    };
  }

  const knowledgeTopK = _envInt(process.env.KHY_RAG_KNOWLEDGE_TOPK, DEFAULT_KNOWLEDGE_TOPK, 1, 12);
  const sessionTopK = _envInt(process.env.KHY_RAG_SESSION_TOPK, DEFAULT_SESSION_TOPK, 1, 10);
  const totalTopK = _envInt(process.env.KHY_RAG_TOPK, DEFAULT_TOTAL_TOPK, 1, 16);
  const maxChars = _envInt(process.env.KHY_RAG_MAX_CONTEXT_CHARS, DEFAULT_MAX_CONTEXT_CHARS, 400, 12_000);
  const ttlMs = _envInt(process.env.KHY_RAG_CACHE_TTL_MS, DEFAULT_CACHE_TTL_MS, 2_000, 10 * 60_000);
  const cacheKey = `${cleanQuery}::${knowledgeTopK}:${sessionTopK}:${totalTopK}:${maxChars}`;

  const cached = _cacheGet(cacheKey, ttlMs);
  if (cached) {
    return {
      ...cached,
      meta: { ...(cached.meta || {}), cacheHit: true },
    };
  }

  const knowledge = _knowledgeCandidates(cleanQuery, knowledgeTopK);
  const sessions = _sessionCandidates(cleanQuery, sessionTopK);
  const merged = _dedupeCandidates([...knowledge, ...sessions])
    .sort((a, b) => b.score - a.score)
    .slice(0, totalTopK);

  if (merged.length === 0) {
    const miss = {
      used: false,
      context: '',
      meta: { reason: 'no_match', selectedCount: 0, knowledgeHits: 0, sessionHits: 0, cacheHit: false },
    };
    _cacheSet(cacheKey, miss);
    return miss;
  }

  const context = _formatContext(merged, maxChars);
  const result = {
    used: !!context,
    context,
    meta: {
      reason: 'matched',
      selectedCount: merged.length,
      knowledgeHits: knowledge.length,
      sessionHits: sessions.length,
      cacheHit: false,
      contextChars: context.length,
    },
  };
  _cacheSet(cacheKey, result);
  return result;
}

function _resetCacheForTest() {
  _cache.clear();
}

module.exports = {
  isEnabled,
  buildRetrievalContext,
  _resetCacheForTest,
};

