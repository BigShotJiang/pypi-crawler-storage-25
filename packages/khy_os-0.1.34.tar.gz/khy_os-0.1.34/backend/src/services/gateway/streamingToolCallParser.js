/**
 * StreamingToolCallParser — Incremental JSON argument parser for SSE tool calls.
 *
 * Handles fragmented JSON arguments arriving across multiple SSE chunks:
 *   - Character-by-character depth tracking (braces, brackets, strings, escapes)
 *   - Index collision detection and remapping when providers reuse indices
 *   - 3-layer parse fallback: JSON.parse → auto-close string → safeJsonParse
 *   - Truncation detection for overriding finish_reason
 *
 * Designed for OpenAI-compatible streaming format:
 *   choices[0].delta.tool_calls[i].function.arguments (partial JSON)
 *
 * Also usable for any provider that streams tool call arguments incrementally.
 *
 * Usage:
 *   const parser = new StreamingToolCallParser();
 *   // For each SSE chunk:
 *   parser.addChunk(index, argumentsChunk, toolCallId, functionName);
 *   // When stream ends:
 *   const calls = parser.getCompletedToolCalls();
 */
'use strict';

const { safeJsonParse } = require('./safeJsonParse');

class StreamingToolCallParser {
  constructor() {
    /** @type {Map<number, string>} Accumulated JSON fragments per index */
    this._buffers = new Map();
    /** @type {Map<number, number>} Current JSON nesting depth per index */
    this._depths = new Map();
    /** @type {Map<number, boolean>} Whether inside a string literal per index */
    this._inStrings = new Map();
    /** @type {Map<number, boolean>} Whether next char is escaped per index */
    this._escapes = new Map();
    /** @type {Map<number, {id?: string, name?: string}>} Tool call metadata */
    this._meta = new Map();
    /** @type {Map<string, number>} Tool call ID → actual storage index */
    this._idToIndex = new Map();
    /** @type {number} Counter for next available index on collision */
    this._nextIndex = 0;
  }

  /**
   * Process an incoming chunk of tool call arguments.
   *
   * @param {number}  index  — Provider-assigned tool call index
   * @param {string}  chunk  — Partial JSON arguments fragment
   * @param {string}  [id]   — Tool call ID (e.g. "call_abc123")
   * @param {string}  [name] — Function name (e.g. "get_weather")
   * @returns {{ complete: boolean, value?: *, repaired?: boolean, error?: Error }}
   */
  addChunk(index, chunk, id, name) {
    // ── Phase 1: Resolve actual storage index (collision detection) ────
    let actualIndex = index;

    if (id) {
      const mappedIndex = this._idToIndex.get(id);
      if (mappedIndex !== undefined) {
        // ID already mapped — use existing index
        actualIndex = mappedIndex;
      } else {
        // New ID — check if requested index is occupied by a different completed tool call
        if (this._buffers.has(index)) {
          const existingMeta = this._meta.get(index);
          const existingDepth = this._depths.get(index) || 0;
          const existingBuffer = (this._buffers.get(index) || '').trim();

          if (existingMeta && existingMeta.id && existingMeta.id !== id && existingDepth === 0 && existingBuffer) {
            // Verify existing is actually complete (parseable)
            try {
              JSON.parse(existingBuffer);
              // Complete and different ID — collision! Allocate new index.
              actualIndex = this._findNextAvailable();
            } catch {
              // Not parseable — incomplete, reuse this index
            }
          }
        }
        this._idToIndex.set(id, actualIndex);
      }
    } else {
      // No ID — try to route to the right buffer
      if (this._buffers.has(index)) {
        const existingDepth = this._depths.get(index) || 0;
        const existingBuffer = (this._buffers.get(index) || '').trim();

        // If buffer at index is complete (depth 0 and parseable), route to most recent incomplete
        if (existingDepth === 0 && existingBuffer) {
          try {
            JSON.parse(existingBuffer);
            // Complete — find most recent incomplete
            const incomplete = this._findMostRecentIncomplete();
            if (incomplete !== -1) actualIndex = incomplete;
          } catch {
            // Not parseable = incomplete, continue at this index
          }
        }
      }
    }

    // ── Phase 2: Initialize state if new index ────────────────────────
    if (!this._buffers.has(actualIndex)) {
      this._buffers.set(actualIndex, '');
      this._depths.set(actualIndex, 0);
      this._inStrings.set(actualIndex, false);
      this._escapes.set(actualIndex, false);
    }

    // ── Phase 3: Update metadata incrementally ────────────────────────
    if (!this._meta.has(actualIndex)) this._meta.set(actualIndex, {});
    const meta = this._meta.get(actualIndex);
    if (id) meta.id = id;
    if (name) meta.name = name;

    // ── Phase 4: Accumulate chunk ─────────────────────────────────────
    if (!chunk) {
      return { complete: false };
    }
    const newBuffer = this._buffers.get(actualIndex) + chunk;
    this._buffers.set(actualIndex, newBuffer);

    // ── Phase 5: Character-by-character depth tracking ────────────────
    let depth = this._depths.get(actualIndex);
    let inString = this._inStrings.get(actualIndex);
    let escape = this._escapes.get(actualIndex);

    for (let i = 0; i < chunk.length; i++) {
      const ch = chunk[i];

      if (escape) {
        escape = false;
        continue;
      }

      if (ch === '\\' && inString) {
        escape = true;
        continue;
      }

      if (ch === '"') {
        inString = !inString;
        continue;
      }

      if (!inString) {
        if (ch === '{' || ch === '[') depth++;
        else if (ch === '}' || ch === ']') depth--;
      }
    }

    this._depths.set(actualIndex, depth);
    this._inStrings.set(actualIndex, inString);
    this._escapes.set(actualIndex, escape);

    // ── Phase 6: Attempt parse when depth returns to 0 ────────────────
    if (depth === 0 && newBuffer.trim()) {
      // Layer 1: Standard JSON.parse
      try {
        const value = JSON.parse(newBuffer);
        return { complete: true, value };
      } catch (e) {
        // Layer 2: Auto-close unclosed string
        if (inString) {
          try {
            const value = JSON.parse(newBuffer + '"');
            return { complete: true, value, repaired: true };
          } catch { /* continue */ }
        }

        // Layer 3: safeJsonParse (comprehensive repair)
        const repaired = safeJsonParse(newBuffer, null);
        if (repaired !== null) {
          return { complete: true, value: repaired, repaired: true };
        }

        return { complete: false, error: e instanceof Error ? e : new Error(String(e)) };
      }
    }

    return { complete: false };
  }

  /**
   * Extract all completed tool calls (called when stream ends).
   *
   * Uses 3-layer parsing fallback for each buffer.
   *
   * @returns {Array<{ id?: string, name?: string, args: object, index: number }>}
   */
  getCompletedToolCalls() {
    const completed = [];

    for (const [index, buffer] of this._buffers.entries()) {
      const meta = this._meta.get(index);
      if (!meta || !meta.name) continue;

      const trimmed = buffer.trim();
      if (!trimmed) continue;

      // 3-layer parse
      let args = {};
      try {
        args = JSON.parse(trimmed);
      } catch {
        const inString = this._inStrings.get(index);
        if (inString) {
          try {
            args = JSON.parse(trimmed + '"');
          } catch {
            args = safeJsonParse(trimmed, {});
          }
        } else {
          args = safeJsonParse(trimmed, {});
        }
      }

      completed.push({
        id: meta.id,
        name: meta.name,
        args,
        index,
      });
    }

    return completed;
  }

  /**
   * Check if any tracked tool calls are incomplete (truncated).
   *
   * Useful to override finish_reason to 'length' when provider
   * reports 'stop' but tool call arguments were cut off.
   *
   * @returns {boolean}
   */
  hasIncompleteToolCalls() {
    for (const [index] of this._buffers.entries()) {
      const meta = this._meta.get(index);
      if (!meta || !meta.name) continue;

      const depth = this._depths.get(index) || 0;
      const inString = this._inStrings.get(index) || false;

      if (depth > 0 || inString) return true;
    }
    return false;
  }

  /**
   * Reset all parser state (for reuse across requests).
   */
  reset() {
    this._buffers.clear();
    this._depths.clear();
    this._inStrings.clear();
    this._escapes.clear();
    this._meta.clear();
    this._idToIndex.clear();
    this._nextIndex = 0;
  }

  // ── Internal helpers ──────────────────────────────────────────────────

  /**
   * Find next available index that doesn't hold a completed tool call.
   * @returns {number}
   */
  _findNextAvailable() {
    while (this._buffers.has(this._nextIndex)) {
      const buffer = (this._buffers.get(this._nextIndex) || '').trim();
      const depth = this._depths.get(this._nextIndex) || 0;
      const meta = this._meta.get(this._nextIndex);

      // Reusable if: empty, incomplete (depth > 0), or no ID
      if (!buffer || depth > 0 || !meta || !meta.id) {
        return this._nextIndex;
      }

      // Check if parseable (complete)
      try {
        JSON.parse(buffer);
        if (depth === 0) {
          this._nextIndex++;
          continue; // Complete — skip
        }
      } catch {
        return this._nextIndex; // Unparseable = incomplete = reusable
      }

      this._nextIndex++;
    }

    return this._nextIndex++;
  }

  /**
   * Find the most recent index with an incomplete buffer (depth > 0).
   * @returns {number} Index or -1 if none found
   */
  _findMostRecentIncomplete() {
    let best = -1;
    for (const [index] of this._buffers.entries()) {
      const depth = this._depths.get(index) || 0;
      if (depth > 0) best = index;
    }
    return best;
  }
}

module.exports = { StreamingToolCallParser };
