/**
 * Claude Code Adapter — invoke Claude Code CLI as a standalone IDE adapter.
 *
 * Extends the existing cliToolAdapter pattern but supports:
 * - Model selection (--model flag)
 * - Model listing
 * - Dedicated IDE registration in the gateway
 */
const { execFileSync, spawn, spawnSync } = require('child_process');
const path = require('path');
const { detectErrorKindDeep, formatErrorMessage } = require('../../errorClassifier');
const { extractPrimaryApiKey } = require('../../apiKeyFormat');
const { isWin, platformShell, safeKill } = require('../../../tools/platformUtils');
const { toAnthropicImageBlocks } = require('./_imageCompat');

// Lazy-loaded agentsight for trajectory recording (best-effort)
let _genaiEvents = null;
function genai() {
  if (_genaiEvents === null) {
    try { _genaiEvents = require('../../agentsight/genaiEvents'); }
    catch { _genaiEvents = false; }
  }
  return _genaiEvents || null;
}

const TIMEOUT_MS = parseInt(process.env.GATEWAY_CLAUDE_TIMEOUT_MS || '240000', 10);
const IDLE_TIMEOUT_MS = Math.max(0, parseInt(process.env.GATEWAY_CLAUDE_IDLE_TIMEOUT_MS || '180000', 10) || 0);
const HANDSHAKE_TIMEOUT_MS = Math.max(0, parseInt(process.env.GATEWAY_CLAUDE_HANDSHAKE_TIMEOUT_MS || '10000', 10) || 10000);
const MAX_BUFFER = 10 * 1024 * 1024;

// Direct mode constants — bypass CLI, call Anthropic Messages API directly
// Connection mode resolution:
//   GATEWAY_CLAUDE_MODE=direct  → always direct (Anthropic API), fail if no key
//   GATEWAY_CLAUDE_MODE=bridge  → always CLI subprocess
//   GATEWAY_CLAUDE_MODE=auto    → direct if API key present, else bridge (DEFAULT)
const _CLAUDE_MODE_RAW = String(process.env.GATEWAY_CLAUDE_MODE || 'auto').toLowerCase();
function _hasAnthropicKey() {
  const envKey = extractPrimaryApiKey(process.env.ANTHROPIC_API_KEY)
    || extractPrimaryApiKey(process.env.ANTHROPIC_AUTH_TOKEN)
    || extractPrimaryApiKey(process.env.CLAUDE_API_KEY);
  if (envKey) {
    return true;
  }
  // Fallback: check apiKeyPool for managed anthropic keys
  try {
    const pool = require('../../apiKeyPool');
    pool.init();
    return pool.hasAvailableKeys('anthropic');
  } catch { return false; }
}
function resolveConnectionMode() {
  if (_CLAUDE_MODE_RAW === 'direct') return 'direct';
  if (_CLAUDE_MODE_RAW === 'bridge' || _CLAUDE_MODE_RAW === 'cli') return 'bridge';
  // auto (default)
  return _hasAnthropicKey() ? 'direct' : 'bridge';
}
const DIRECT_MODE = _CLAUDE_MODE_RAW === 'direct';
const DIRECT_MAX_ITERATIONS = parseInt(process.env.GATEWAY_CLAUDE_DIRECT_MAX_ITERATIONS || '15', 10);
const DIRECT_TIMEOUT_MS = parseInt(process.env.GATEWAY_CLAUDE_DIRECT_TIMEOUT_MS || '120000', 10);
const DIRECT_MAX_OUTPUT = 16000; // truncate large tool outputs
const DIRECT_SIMPLE_MAX_TOKENS = Math.max(
  64,
  parseInt(process.env.GATEWAY_CLAUDE_DIRECT_SIMPLE_MAX_TOKENS || '384', 10) || 384
);
const DIRECT_SIMPLE_MAX_ROUNDS = Math.max(
  1,
  parseInt(process.env.GATEWAY_CLAUDE_DIRECT_SIMPLE_MAX_ROUNDS || '2', 10) || 2
);

// Known Claude Code models (detected dynamically where possible)
const KNOWN_MODELS = [
  { id: 'claude-opus-4-6', name: 'Claude Opus 4.6', isDefault: false, tier: 'ultra', category: 'reasoning' },
  { id: 'claude-sonnet-4-6', name: 'Claude Sonnet 4.6', isDefault: true, tier: 'high', category: 'general' },
  { id: 'claude-haiku-4-5-20251001', name: 'Claude Haiku 4.5', isDefault: false, tier: 'medium', category: 'fast' },
];

let _available = null;

function buildClaudeArgs(options = {}) {
  // Determine permission mode early — it affects arg construction
  const permissionMode = options.permissionMode || process.env.GATEWAY_CLAUDE_PERMISSION_MODE || 'bypassPermissions';

  const args = [
    '-p',
    '--input-format', 'stream-json',
    '--output-format', 'stream-json',
    '--verbose',
    '--include-partial-messages',
  ];
  if (options.model) args.push('--model', options.model);

  // Permission mode
  args.push('--permission-mode', permissionMode);
  if (permissionMode === 'bypassPermissions') {
    args.push('--dangerously-skip-permissions');
  }

  // Route permission prompts through stream-json control_request/control_response.
  // Even in bypassPermissions mode, Claude CLI may still emit control_request events
  // for certain operations — KHY auto-approves them via buildDefaultControlResponse.
  const permissionPromptTool = options.permissionPromptTool
    || process.env.GATEWAY_CLAUDE_PERMISSION_PROMPT_TOOL
    || 'stdio';
  if (permissionPromptTool) args.push('--permission-prompt-tool', permissionPromptTool);

  // Keep full Claude tool surface by default; only constrain when explicitly requested.
  const allowedTools = options.allowedTools || process.env.GATEWAY_CLAUDE_ALLOWED_TOOLS || '';
  if (allowedTools) args.push('--allowedTools', allowedTools);

  // Allow tool access to /tmp and current workspace by default so bridge tasks
  // can create files under the user's project path without interactive prompts.
  // Additional paths can be injected via env (comma-separated).
  const addDirs = [];
  if (process.env.GATEWAY_CLAUDE_ADD_TMP !== 'false') addDirs.push('/tmp');
  if (process.env.GATEWAY_CLAUDE_ADD_CWD !== 'false') {
    const cwd = process.env.KHYQUANT_CWD || process.env.PWD || process.cwd();
    if (cwd) addDirs.push(path.resolve(cwd));
  }
  const extraDirs = (process.env.GATEWAY_CLAUDE_ADD_DIRS || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
  addDirs.push(...extraDirs);
  for (const dir of Array.from(new Set(addDirs))) {
    if (!dir) continue;
    const normalized = path.isAbsolute(dir) ? path.resolve(dir) : path.resolve(process.cwd(), dir);
    args.push('--add-dir', normalized);
  }

  return args;
}

function diagnoseClaudeLaunchIssue() {
  try {
    const probe = spawnSync('claude', ['--version'], {
      stdio: 'ignore',
      timeout: 5000,
      env: process.env,
    });
    if (probe && probe.error) {
      const code = probe.error.code || '';
      if (code === 'EPERM' || code === 'EACCES') {
        return `claude launch blocked (${code})`;
      }
      return probe.error.message || String(probe.error);
    }
  } catch (err) {
    const code = err && err.code ? err.code : '';
    if (code === 'EPERM' || code === 'EACCES') {
      return `claude launch blocked (${code})`;
    }
    if (err && err.message) return err.message;
  }
  return '';
}

function commandExists(cmd) {
  // Prefer direct execution check; `which` may fail with EPERM in some sandboxes.
  try {
    const r = spawnSync(cmd, ['--version'], {
      stdio: 'ignore',
      timeout: 5000,
      env: process.env,
    });
    if (r && !r.error && r.status === 0) return true;
  } catch { /* fall through */ }

  try {
    const lookup = process.platform === 'win32' ? 'where' : 'which';
    execFileSync(lookup, [cmd], { stdio: 'pipe', timeout: 5000 });
    return true;
  } catch { return false; }
}

/**
 * Detect if Claude Code CLI is available.
 */
function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  _available = commandExists('claude');
  return _available;
}

/**
 * Async detection — also verifies Anthropic direct API reachability
 * when an API key is present, so the health-check catches endpoint
 * misconfigurations before the user selects a direct-mode model.
 */
async function detectAsync() {
  const cliOk = detect();
  if (!_hasAnthropicKey()) return cliOk;

  // Lightweight check: HEAD-like GET to the API root.
  // Even a 401 (bad key) or 405 (method not allowed) proves the host is reachable;
  // a timeout or ECONNREFUSED means the endpoint is broken.
  try {
    let apiKey = extractPrimaryApiKey(process.env.ANTHROPIC_API_KEY)
      || extractPrimaryApiKey(process.env.ANTHROPIC_AUTH_TOKEN)
      || extractPrimaryApiKey(process.env.CLAUDE_API_KEY);
    let endpoint = process.env.ANTHROPIC_BASE_URL || '';
    if (!apiKey) {
      try {
        const pool = require('../../apiKeyPool');
        pool.init();
        const picked = pool.pick('anthropic');
        if (picked) { apiKey = picked.key; endpoint = picked.endpoint || ''; }
      } catch { /* pool unavailable */ }
    }
    if (!apiKey) return cliOk;

    const baseUrl = (endpoint || 'https://api.anthropic.com')
      .replace(/\/+$/, '')
      .replace(/\/v\d+$/, '');

    let http;
    try { http = require('axios'); } catch {
      http = require(path.resolve(process.cwd(), 'node_modules/axios'));
    }
    // A GET /v1/messages returns 405 (method not allowed) when the host is reachable.
    // Any non-timeout/non-ECONNREFUSED response means the endpoint is alive.
    await http.get(`${baseUrl}/v1/messages`, {
      headers: { 'x-api-key': apiKey, 'anthropic-version': '2024-10-22' },
      timeout: 6000,
      validateStatus: () => true, // accept any HTTP status
    });
    return true;
  } catch (err) {
    // Network-level failure — direct mode is unreachable
    const msg = err && err.message ? err.message : String(err);
    if (/timeout|ECONNREFUSED|ENOTFOUND|ENETUNREACH/i.test(msg)) {
      // Direct unreachable but CLI might still work
      return cliOk;
    }
    return cliOk;
  }
}

/**
 * List available models.
 */
async function listModels() {
  const hasKey = _hasAnthropicKey();
  const out = [];
  for (const m of KNOWN_MODELS) {
    const base = {
      ...m,
      provider: 'claude',
      description: '',
      discoverySource: 'builtin',
    };
    // Auto entry — picks direct if key present, else bridge
    out.push({
      ...base,
      id: `${m.id}::auto`,
      name: m.name,
      isDefault: !!m.isDefault,
      connectionMode: 'auto',
      _baseModelId: m.id,
    });
    // Direct entry — only meaningful when API key is configured
    if (hasKey) {
      out.push({
        ...base,
        id: `${m.id}::direct`,
        name: m.name,
        isDefault: false,
        connectionMode: 'direct',
        _baseModelId: m.id,
      });
    }
    // Bridge entry — always available (uses Claude CLI subscription)
    out.push({
      ...base,
      id: `${m.id}::bridge`,
      name: m.name,
      isDefault: false,
      connectionMode: 'bridge',
      _baseModelId: m.id,
    });
  }
  return out;
}

// Parse a model id like "claude-opus-4-6::direct" into {modelId, mode}
function parseModelId(rawId) {
  const s = String(rawId || '');
  const idx = s.indexOf('::');
  if (idx === -1) return { modelId: s, mode: null };
  return { modelId: s.slice(0, idx), mode: s.slice(idx + 2).toLowerCase() || null };
}

function buildStreamUserMessage(prompt, rawUserMessage) {
  return {
    type: 'user',
    session_id: '',
    message: {
      role: 'user',
      content: applyAgenticGuidancePrefix(prompt, rawUserMessage),
    },
    parent_tool_use_id: null,
  };
}

/**
 * Extract the raw user text from a flat conversation prompt.
 * buildFlatConversation produces: "<system>\n\nUSER: <text>".
 * We grab the last USER: line to detect greeting vs task.
 */
function _extractLastUserText(flatPrompt) {
  const lines = String(flatPrompt || '').split('\n');
  for (let i = lines.length - 1; i >= 0; i--) {
    const m = lines[i].match(/^USER:\s*(.*)/i);
    if (m) {
      // Collect subsequent lines that aren't a new role marker (multiline user messages)
      let text = m[1];
      for (let j = i + 1; j < lines.length; j++) {
        if (/^(USER|ASSISTANT|SYSTEM|\[ToolResult\]):/i.test(lines[j])) break;
        text += '\n' + lines[j];
      }
      // Strip [意图]/[问题] tags injected by inputPurify so downstream
      // checks (e.g. greeting detection) see the raw user text.
      text = text.replace(/\[意图\]\s*[^\n]*/g, '').replace(/\[问题\]\s*/g, '').trim();
      // Skip system-injected USER messages (planning prompts, skill hints, etc.)
      // These start with [System or contain skill manifest data — not real user input.
      if (/^\[System/i.test(text)) continue;
      return text;
    }
  }
  return '';
}

/**
 * Prepend a short guidance preamble to discourage over-exploration when the
 * gateway hands off a focused task. Suppressed by GATEWAY_CLAUDE_NO_GUIDANCE=1.
 * Skipped if the prompt already contains the guidance marker (idempotent).
 */
const AGENTIC_GUIDANCE_MARKER = '<khy-agentic-guidance>';
function applyAgenticGuidancePrefix(prompt, rawUserMessage, options) {
  const raw = String(prompt || '');
  if (process.env.GATEWAY_CLAUDE_NO_GUIDANCE === '1') return raw;
  if (raw.includes(AGENTIC_GUIDANCE_MARKER)) return raw;

  // Greeting detection: prefer the raw user message (before any system
  // injection by toolUseLoop/planning/skill hints).  Fall back to extracting
  // from the flat prompt only when rawUserMessage is not available.
  // The rawUserMessage may still contain [System ...] blocks appended by
  // agenticHarnessService._buildLoopInput — strip those before checking.
  const userText = rawUserMessage
    ? String(rawUserMessage).replace(/\n\n\[System\b[\s\S]*/i, '').trim()
    : _extractLastUserText(raw);

  if (looksLikeSimpleGreeting(userText)) {
    // Replace the entire prompt with a minimal conversational one.
    // The flat prompt embeds KHY's system prompt (financial tools, backtesting,
    // calculators, etc.) plus tool-use-loop injections.  Claude Code interprets
    // this as the user wanting financial help → "你想计算什么".
    return [
      'You are khy OS, a friendly and helpful AI assistant. Respond in the same language the user used.',
      'The user sent a casual greeting. Respond naturally — say hello, briefly introduce yourself,',
      'and ask how you can help today. Keep it warm and concise (2-3 sentences).',
      'Do NOT mention calculation, financial analysis, stock trading, or any specific tool.',
      '',
      `USER: ${userText}`,
    ].join('\n');
  }

  const preamble = [
    AGENTIC_GUIDANCE_MARKER,
    'Execution guidance — minimize tool calls, act fast:',
    '- This is a FOCUSED task. Go straight to the target: Read → Edit → verify → done.',
    '- When the prompt gives a file path and line number, Read ONLY that range. Do NOT Grep/search for what is already specified.',
    '- Do NOT spawn Agent/subagents unless the task explicitly requires broad codebase exploration.',
    '- Do NOT enter Plan Mode when the file and change are already specified.',
    '- Do NOT diff against git HEAD or inspect commit history unless explicitly asked.',
    '- Do NOT re-read files you have already read. Trust your first read.',
    '- Combine related reads into minimal calls (use offset+limit to grab exactly what you need).',
    '- After Edit, run ONE syntax check (node --check or equivalent), then output your summary. Done.',
    '',
    'Output formatting:',
    '- For tables, output ONLY GitHub-flavored Markdown pipes (e.g. `| col1 | col2 |`). Do NOT pre-draw box characters (┌ ├ │ └ etc.) — the CLI renderer aligns Markdown tables with CJK-aware column widths automatically. Pre-drawn boxes will misalign with Chinese characters.',
    '- Keep prose plain. Use bullet lists, headings, and fenced code blocks freely; avoid ASCII-art separators.',
  ];

  // Inject intentGate directive (e.g. CODING/ULTRAWORK mode instructions)
  const intentDirective = String((options && options._intentDirective) || '').trim();
  if (intentDirective) {
    preamble.push('');
    preamble.push(intentDirective);
  }

  preamble.push('</khy-agentic-guidance>');
  preamble.push('');
  preamble.push(raw);

  return preamble.join('\n');
}

function looksLikeSimpleGreeting(input = '') {
  try {
    const { isGreeting } = require('../../services/khyUpgradeRuntime');
    return isGreeting(input);
  } catch {
    // Fallback: minimal inline check if runtime not loadable
    const compact = String(input || '').trim().toLowerCase().replace(/[！!。.,，?？\s]/g, '');
    return new Set(['hi', 'hello', 'hey', '你好', '您好', '嗨']).has(compact);
  }
}

function looksLikeToolOrCodeTask(input = '') {
  const text = String(input || '');
  if (!text) return false;
  if (/[\\/]([\w.-]+[\\/])?[\w.-]+\.\w+/.test(text)) return true;
  return /(文件|代码|修复|报错|命令|shell|终端|路径|目录|脚本|read|edit|write|grep|glob|bash|fix|bug|compile|build|test|error|stack|trace|implement|refactor|api|endpoint|database|sql)/i.test(text);
}

function shouldUseDirectFastPath(prompt, options = {}) {
  const override = String(process.env.GATEWAY_CLAUDE_DIRECT_FAST_PATH || '').trim().toLowerCase();
  if (['0', 'false', 'off', 'no'].includes(override)) return false;
  if (['1', 'true', 'on', 'yes'].includes(override)) return true;
  // Strip [System ...] blocks appended by agenticHarnessService._buildLoopInput
  const raw = String(options.userMessage || prompt || '')
    .replace(/\n\n\[System\b[\s\S]*/i, '').trim();
  if (!raw) return false;
  if (looksLikeToolOrCodeTask(raw)) return false;
  return looksLikeSimpleGreeting(raw);
}

function shellEscapeArg(value) {
  return `'${String(value || '').replace(/'/g, `'\\''`)}'`;
}

function buildSeededShellCommand(args, prompt) {
  const initialUserLine = JSON.stringify(buildStreamUserMessage(prompt));
  const cliArgs = Array.isArray(args) ? args.map(shellEscapeArg).join(' ') : '';
  return `{ printf '%s\\n' ${shellEscapeArg(initialUserLine)}; cat; } | claude ${cliArgs}`;
}

function buildDefaultControlResponse(requestId, request = {}) {
  const subtype = String(request.subtype || '');
  if (subtype === 'can_use_tool') {
    // Auto-allow tool use in gateway mode — KHY has already validated the
    // request at its own security layer. Denying here causes the Claude CLI
    // subprocess to hang waiting for interactive permission confirmation.
    //
    // IMPORTANT: Claude CLI validates the response with a Zod schema that
    // requires `updatedInput` (Record<string, unknown>) when behavior is
    // "allow". Omitting it causes a ZodError → "权限组件有问题".
    const toolInput = (request && typeof request === 'object' && request.input)
      ? request.input
      : {};
    return {
      type: 'control_response',
      response: {
        subtype: 'success',
        request_id: requestId,
        response: {
          behavior: 'allow',
          updatedInput: toolInput,
        },
      },
    };
  }

  return {
    type: 'control_response',
    response: {
      subtype: 'success',
      request_id: requestId,
      response: {},
    },
  };
}

function normalizeControlResponse(requestId, request, rawResponse) {
  const fallback = buildDefaultControlResponse(requestId, request);
  if (!rawResponse || typeof rawResponse !== 'object') return fallback;

  // Full envelope already provided by caller.
  if (rawResponse.type === 'control_response' && rawResponse.response && typeof rawResponse.response === 'object') {
    const resp = { ...rawResponse.response };
    if (!resp.request_id) resp.request_id = requestId;
    return { type: 'control_response', response: resp };
  }

  // Caller returned inner response object: { subtype, response?/error? }
  if (rawResponse.subtype || rawResponse.response || rawResponse.error) {
    const resp = { ...rawResponse };
    if (!resp.request_id) resp.request_id = requestId;
    if (!resp.subtype) resp.subtype = resp.error ? 'error' : 'success';
    return { type: 'control_response', response: resp };
  }

  // Caller returned SDK payload directly: { behavior, updatedInput, ... }
  if (Object.prototype.hasOwnProperty.call(rawResponse, 'behavior')) {
    const sdkPayload = { ...rawResponse };
    // Ensure updatedInput is present for "allow" — Claude CLI Zod schema requires it
    if (sdkPayload.behavior === 'allow' && !sdkPayload.updatedInput) {
      sdkPayload.updatedInput = (request && typeof request === 'object' && request.input) ? request.input : {};
    }
    return {
      type: 'control_response',
      response: {
        subtype: 'success',
        request_id: requestId,
        response: sdkPayload,
      },
    };
  }

  return fallback;
}

function normalizeAbortReason(reason) {
  if (!reason) return 'aborted';
  if (typeof reason === 'string') return reason;
  if (reason && typeof reason.message === 'string') return reason.message;
  try { return JSON.stringify(reason); } catch { return String(reason); }
}

function isAbortLikeError(err) {
  const msg = String(err && err.message ? err.message : err || '');
  const lower = msg.toLowerCase();
  return (
    err && (
      err.name === 'AbortError'
      || err.code === 'ABORT_ERR'
      || /\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower)
    )
  );
}

function classifyClaudeError(err) {
  const message = String(err && err.message ? err.message : err || '');
  const lower = message.toLowerCase();
  const structured = detectErrorKindDeep(err || { message });
  if (structured) return structured;

  if (isAbortLikeError(err)) return 'cancelled';
  if (/\bcancelled\b|\bcanceled\b/.test(lower)) return 'process';
  if (/timeout|timed out|deadline exceeded|unresponsive/.test(lower)) return 'timeout';
  if (/unauthorized|forbidden|invalid api key|apikeysource|not authenticated|auth unavailable|login/.test(lower)) {
    return 'auth';
  }
  if (/permission denied|operation not permitted|access denied|sandbox|eacces|eperm/.test(lower)) {
    return 'permission';
  }
  if (/\b(?:econnreset|econnrefused|enotfound|ehostunreach|enetunreach|eai_again)\b|network error|fetch failed|socket hang up|getaddrinfo|proxy/i.test(lower)) {
    return 'network';
  }
  if (/without emitting stream-json output|channel closed|reconnecting|launch blocked|exited with code|spawn|handshake timeout|bridge canceled/.test(lower)) {
    return 'process';
  }
  if (/rate.?limit|too many requests|429/.test(lower)) return 'rate_limit';
  if (/not installed|command "claude" not found|not found/.test(lower)) return 'unavailable';
  return 'unknown';
}

function shouldRetryClaudeTransient(err) {
  if (!err || isAbortLikeError(err)) return false;
  const lower = String(err && err.message ? err.message : err || '').toLowerCase();
  return /reconnecting|channel closed|failed to record rollout items|socket hang up|econnreset|network error|fetch failed|temporarily unavailable|broken pipe|handshake timeout|bridge canceled/.test(lower);
}

/**
 * Process a stream-json event from Claude Code.
 * Supports both legacy format (type: 'assistant'/'user') and newer
 * wrapper format (type: 'stream_event' with content_block_start/delta/stop).
 */
function processStreamEvent(event, onChunk, appendContent, state = { blocks: new Map(), sawStreamEvent: false, sawAssistantText: false }) {
  const summarizeInput = (input) => {
    if (!input) return '';
    if (typeof input === 'string') return input.slice(0, 120);
    try {
      return Object.entries(input)
        .map(([k, v]) => `${k}=${String(typeof v === 'string' ? v : JSON.stringify(v)).slice(0, 40)}`)
        .join(', ')
        .slice(0, 120);
    } catch { return ''; }
  };
  const parseJsonMaybe = (str) => {
    if (!str || typeof str !== 'string') return null;
    try { return JSON.parse(str); } catch {
      // Repair malformed JSON from truncated/broken streams
      const { safeJsonParse } = require('../safeJsonParse');
      return safeJsonParse(str, null);
    }
  };
  const summarizeText = (value, maxLen = 220) => {
    const text = typeof value === 'string' ? value : summarizeInput(value);
    if (!text) return '';
    return text.length > maxLen ? `${text.slice(0, maxLen - 1)}…` : text;
  };

  // Claude SDK-style progress event (stream-json top-level)
  if (event.type === 'tool_progress') {
    onChunk({
      type: 'tool_progress',
      id: event.tool_use_id || event.id || '',
      tool: event.tool_name || event.tool || 'tool',
      status: event.status || event.status_category || '',
      detail: summarizeText(event.status_detail || event.message || event.detail || ''),
      parentId: event.parent_tool_use_id || null,
    });
    return;
  }

  // Claude SDK-style auth status event
  if (event.type === 'auth_status') {
    onChunk({
      type: 'auth_status',
      isAuthenticating: !!event.isAuthenticating,
      output: summarizeText(event.output || ''),
      error: summarizeText(event.error || ''),
    });
    return;
  }

  // Claude SDK-style task lifecycle events (usually under system subtype)
  if (event.type === 'system' && event.subtype &&
      (event.subtype === 'task_started' || event.subtype === 'task_progress' || event.subtype === 'task_notification')) {
    onChunk({
      type: event.subtype,
      taskId: event.task_id || '',
      toolUseId: event.tool_use_id || '',
      status: event.status || '',
      summary: summarizeText(event.summary || event.message || ''),
      outputFile: event.output_file || '',
      usage: event.usage || null,
    });
    return;
  }

  // Newer Claude stream-json wrapper format: { type: "stream_event", event: {...} }
  if (event.type === 'stream_event' && event.event) {
    state.sawStreamEvent = true;
    const ev = event.event;

    if (ev.type === 'tool_progress') {
      onChunk({
        type: 'tool_progress',
        id: ev.tool_use_id || ev.id || '',
        tool: ev.tool_name || ev.tool || 'tool',
        status: ev.status || ev.status_category || '',
        detail: summarizeText(ev.status_detail || ev.message || ev.detail || ''),
        parentId: ev.parent_tool_use_id || null,
      });
      return;
    }

    if (ev.type === 'auth_status') {
      onChunk({
        type: 'auth_status',
        isAuthenticating: !!ev.isAuthenticating,
        output: summarizeText(ev.output || ''),
        error: summarizeText(ev.error || ''),
      });
      return;
    }

    if (ev.type === 'system' && ev.subtype &&
        (ev.subtype === 'task_started' || ev.subtype === 'task_progress' || ev.subtype === 'task_notification')) {
      onChunk({
        type: ev.subtype,
        taskId: ev.task_id || '',
        toolUseId: ev.tool_use_id || '',
        status: ev.status || '',
        summary: summarizeText(ev.summary || ev.message || ''),
        outputFile: ev.output_file || '',
        usage: ev.usage || null,
      });
      return;
    }

    if (ev.type === 'system' && ev.subtype === 'session_state_changed') {
      const stateText = ev.state || ev.session_state || '';
      if (stateText) onChunk({ type: 'status', text: `Session state: ${stateText}` });
      return;
    }

    if (ev.type === 'content_block_start') {
      const idx = Number(ev.index);
      const block = ev.content_block || {};
      state.blocks.set(idx, { type: block.type || '', name: block.name || '', id: block.id || '', inputRaw: '', _startTs: Date.now() });

      if (block.type === 'thinking' && block.thinking) {
        onChunk({ type: 'thinking', text: block.thinking });
      } else if (block.type === 'text' && block.text) {
        onChunk({ type: 'text', text: block.text });
        appendContent(block.text);
        state.sawAssistantText = true;
      } else if (block.type === 'tool_use') {
        onChunk({ type: 'tool_use', tool: block.name || 'unknown', input: summarizeInput(block.input), id: block.id });
      }
      return;
    }

    if (ev.type === 'content_block_delta') {
      const idx = Number(ev.index);
      const delta = ev.delta || {};
      if (delta.type === 'thinking_delta' && delta.thinking) {
        onChunk({ type: 'thinking', text: delta.thinking });
      } else if (delta.type === 'text_delta' && delta.text) {
        onChunk({ type: 'text', text: delta.text });
        appendContent(delta.text);
        state.sawAssistantText = true;
      } else if (delta.type === 'input_json_delta' && typeof delta.partial_json === 'string') {
        const blk = state.blocks.get(idx);
        if (blk) blk.inputRaw += delta.partial_json;
      }
      return;
    }

    if (ev.type === 'content_block_stop') {
      const idx = Number(ev.index);
      const blk = state.blocks.get(idx);
      if (blk && blk.type === 'tool_use' && blk.inputRaw) {
        const parsed = parseJsonMaybe(blk.inputRaw);
        const summary = summarizeInput(parsed) || summarizeInput(blk.inputRaw);
        if (summary) {
          onChunk({ type: 'tool_use', tool: blk.name || 'unknown', input: summary, id: blk.id });
        }
        // Record tool use event for trajectory tracking
        const g = genai();
        if (g) {
          try {
            g.recordToolUse({
              toolName: blk.name || 'unknown',
              input: summary || blk.inputRaw.slice(0, 500),
              durationMs: blk._startTs ? Date.now() - blk._startTs : 0,
              success: true,
              traceId: state._traceId || null,
            });
          } catch { /* best effort */ }
        }
      }
      state.blocks.delete(idx);
      return;
    }

    if (ev.type === 'message_delta' && ev.usage && typeof ev.usage.output_tokens === 'number') {
      onChunk({ type: 'cost', cost: ev.usage.output_tokens });
      // Record LLM call event with token usage
      const g = genai();
      if (g) {
        try {
          g.recordLLMCall({
            model: state._model || 'claude',
            provider: 'anthropic',
            outputTokens: ev.usage.output_tokens,
            inputTokens: ev.usage.input_tokens || 0,
            traceId: state._traceId || null,
          });
        } catch { /* best effort */ }
      }
      return;
    }
  }

  // Some Claude CLI versions emit both stream_event and legacy assistant/user
  // messages for the same turn; if we already consumed stream_event, skip
  // legacy message payload to avoid duplicate final text.
  if (state.sawStreamEvent && (event.type === 'assistant' || event.type === 'user')) {
    return;
  }

  // Surface retry/system signals so UI doesn't look frozen while Claude retries internally.
  if (event.type === 'system' && event.subtype) {
    if (event.subtype === 'api_retry') {
      const attempt = event.attempt || '?';
      const max = event.max_retries || '?';
      const reason = event.error || 'unknown';
      onChunk({ type: 'status', text: `Claude API retry ${attempt}/${max} (${reason})` });
      return;
    }
    if (event.subtype === 'error') {
      onChunk({ type: 'status', text: `Claude system error: ${event.error || 'unknown'}` });
      return;
    }
    if (event.subtype === 'session_state_changed') {
      const stateText = event.state || event.session_state || '';
      if (stateText) {
        onChunk({ type: 'status', text: `Session state: ${stateText}` });
      }
      return;
    }
  }

  // Legacy format: full assistant/user messages
  if (event.type === 'assistant' && event.message?.content) {
    for (const block of event.message.content) {
      if (block.type === 'thinking' && block.thinking) {
        onChunk({ type: 'thinking', text: block.thinking });
      } else if (block.type === 'text' && block.text) {
        onChunk({ type: 'text', text: block.text });
        appendContent(block.text);
        state.sawAssistantText = true;
      } else if (block.type === 'tool_use') {
        onChunk({ type: 'tool_use', tool: block.name || 'unknown', input: summarizeInput(block.input), id: block.id });
      }
    }
  } else if (event.type === 'user' && event.message?.content) {
    for (const block of event.message.content) {
      if (block.type === 'tool_result') {
        const content = typeof block.content === 'string' ? block.content : JSON.stringify(block.content || '');
        onChunk({ type: 'tool_result', id: block.tool_use_id, content: content.slice(0, 200), isError: block.is_error });
      }
    }
  } else if (event.type === 'result') {
    if (event.total_cost_usd) {
      onChunk({ type: 'cost', cost: event.total_cost_usd });
    }
    // Some Claude CLI builds may only surface final text in result.result.
    if (!state.sawAssistantText && typeof event.result === 'string' && event.result.trim()) {
      onChunk({ type: 'text', text: event.result });
      appendContent(event.result);
      state.sawAssistantText = true;
    }
  }
}

async function runClaudeAttempt({
  launchMode = 'direct',
  prompt,
  rawUserMessage,
  args,
  timeoutMs = null,
  onChunk,
  onControlRequest,
  abortSignal = null,
}) {
  return new Promise((resolve, reject) => {
    let child = null;
    let abortWatcher = null;
    let forceKillTimer = null;
    let aborted = false;
    let abortReason = '';
    let finished = false;
    let idleTimer = null;
    let handshakeTimer = null;

    const killChildTree = (signal = 'SIGTERM') => {
      if (!child) return;
      safeKill(child, signal);
    };

    const clearIdleTimer = () => {
      if (idleTimer) {
        clearTimeout(idleTimer);
        idleTimer = null;
      }
    };

    const cleanupAbortWatcher = () => {
      if (abortWatcher && abortSignal && typeof abortSignal.removeEventListener === 'function') {
        try { abortSignal.removeEventListener('abort', abortWatcher); } catch { /* ignore */ }
      }
      abortWatcher = null;
      clearIdleTimer();
      if (handshakeTimer) {
        clearTimeout(handshakeTimer);
        handshakeTimer = null;
      }
      if (forceKillTimer) {
        clearTimeout(forceKillTimer);
        forceKillTimer = null;
      }
    };

    const finishWithError = (err) => {
      if (finished) return;
      finished = true;
      cleanupAbortWatcher();
      reject(err instanceof Error ? err : new Error(String(err || 'unknown error')));
    };

    const finishWithSuccess = (value) => {
      if (finished) return;
      finished = true;
      cleanupAbortWatcher();
      resolve(value);
    };

    const abortChild = (reason) => {
      if (aborted) return;
      aborted = true;
      abortReason = normalizeAbortReason(reason);
      try { onChunk({ type: 'status', text: `Claude request aborted: ${abortReason}` }); } catch { /* best effort */ }
      if (child && !child.killed) {
        killChildTree('SIGTERM');
        forceKillTimer = setTimeout(() => {
          killChildTree('SIGKILL');
        }, 1200);
        forceKillTimer.unref?.();
      }
      finishWithError(new Error(`Claude request aborted: ${abortReason}`));
    };

    if (abortSignal && abortSignal.aborted) {
      finishWithError(new Error(`Claude request aborted: ${normalizeAbortReason(abortSignal.reason)}`));
      return;
    }

    if (abortSignal && typeof abortSignal.addEventListener === 'function') {
      abortWatcher = () => abortChild(abortSignal.reason);
      abortSignal.addEventListener('abort', abortWatcher, { once: true });
    }

    try {
      onChunk({
        type: 'status',
        text: launchMode === 'seeded_shell'
          ? '🔗 中转桥接：通过 Claude CLI 子进程启动（shell-seeded stream 模式）...'
          : '🔗 中转桥接：通过 Claude CLI 子进程启动...',
      });
    } catch { /* best effort */ }

    let shouldWriteInitialUserLine = true;
    if (launchMode === 'seeded_shell') {
      const shellCmd = buildSeededShellCommand(args, prompt);
      const sh = isWin
        ? { cmd: process.env.COMSPEC || 'cmd.exe', args: ['/d', '/s', '/c', shellCmd] }
        : { cmd: 'bash', args: ['-lc', shellCmd] };
      child = spawn(sh.cmd, sh.args, {
        stdio: ['pipe', 'pipe', 'pipe'],
        env: process.env,
        signal: abortSignal || undefined,
        detached: !isWin,
      });
      shouldWriteInitialUserLine = false;
    } else {
      const launchCmd = isWin ? (process.env.COMSPEC || 'cmd.exe') : 'claude';
      const launchArgs = isWin ? ['/d', '/s', '/c', 'claude.cmd', ...args] : args;
      child = spawn(launchCmd, launchArgs, {
        stdio: ['pipe', 'pipe', 'pipe'],
        env: process.env,
        signal: abortSignal || undefined,
        detached: !isWin,
      });
    }

    const parserState = { blocks: new Map(), sawStreamEvent: false, sawAssistantText: false, _traceId: null, _model: null };

    // Extract model from args for trajectory tracking
    const modelArgIdx = args.indexOf('--model');
    if (modelArgIdx >= 0 && modelArgIdx + 1 < args.length) {
      parserState._model = args[modelArgIdx + 1];
    }
    // Generate a trace ID for this attempt
    try {
      parserState._traceId = `claude_${Date.now()}_${require('crypto').randomBytes(4).toString('hex')}`;
    } catch { /* fallback */ }
    let fullContent = '';
    let buffer = '';
    let sawResult = false;
    let controlQueue = Promise.resolve();
    let stderr = '';
    let parsedEventCount = 0;
    let idleTimedOut = false;
    let handshakeTimedOut = false;
    const controlResponseCache = new Map(); // request_id -> normalized response
    const seenControlRequestIds = new Set();

    // Handshake timeout — if no stream-json events arrive within HANDSHAKE_TIMEOUT_MS,
    // the CLI likely failed silently. Kill early so callers can retry faster.
    // Use a shorter timeout for simple greetings to speed up adapter cascade.
    const isSimple = looksLikeSimpleGreeting(rawUserMessage || prompt);
    const effectiveHandshakeMs = isSimple
      ? Math.min(HANDSHAKE_TIMEOUT_MS, Math.max(2000, parseInt(process.env.GATEWAY_CLAUDE_HANDSHAKE_SIMPLE_MS || '4000', 10) || 4000))
      : HANDSHAKE_TIMEOUT_MS;
    const effectiveIdleTimeoutMs = (() => {
      const parsedAttemptTimeoutMs = Number.parseInt(timeoutMs, 10);
      if (Number.isFinite(parsedAttemptTimeoutMs) && parsedAttemptTimeoutMs > 0) {
        return Math.max(1000, parsedAttemptTimeoutMs);
      }
      if (IDLE_TIMEOUT_MS > 0) return IDLE_TIMEOUT_MS;
      if (TIMEOUT_MS > 0) return Math.max(1000, TIMEOUT_MS);
      return 0;
    })();
    if (effectiveHandshakeMs > 0) {
      handshakeTimer = setTimeout(() => {
        if (finished || aborted || parsedEventCount > 0) return;
        handshakeTimedOut = true;
        try { onChunk({ type: 'status', text: `Claude stream-json handshake timeout after ${effectiveHandshakeMs}ms — no events received, killing subprocess` }); } catch { /* best effort */ }
        killChildTree('SIGTERM');
        const handshakeKillTimer = setTimeout(() => {
          if (!finished) killChildTree('SIGKILL');
        }, 2000);
        handshakeKillTimer.unref?.();
      }, effectiveHandshakeMs);
      handshakeTimer.unref?.();
    }

    const resetIdleTimer = () => {
      if (!effectiveIdleTimeoutMs || effectiveIdleTimeoutMs <= 0 || finished || aborted) return;
      clearIdleTimer();
      idleTimer = setTimeout(() => {
        if (finished || aborted || !child || child.killed) return;
        idleTimedOut = true;
        try {
          onChunk({
            type: 'status',
            text: `Claude bridge idle timeout (${Math.round(effectiveIdleTimeoutMs / 1000)}s no stream activity), terminating subprocess`,
          });
        } catch { /* best effort */ }
        killChildTree('SIGTERM');
        const killTimer = setTimeout(() => {
          if (!finished) killChildTree('SIGKILL');
        }, 3000);
        killTimer.unref?.();
      }, effectiveIdleTimeoutMs);
      idleTimer.unref?.();
    };
    resetIdleTimer();

    const writeInputLine = (obj) => {
      if (!obj || finished || aborted) return false;
      if (!child.stdin || child.stdin.destroyed || child.killed) return false;
      try {
        child.stdin.write(`${JSON.stringify(obj)}\n`);
        return true;
      } catch {
        return false;
      }
    };

    const queueControlResponse = (event) => {
      const requestId = String(event.request_id || '');
      const request = event.request || {};
      if (!requestId || !request || typeof request !== 'object') return;

      if (controlResponseCache.has(requestId)) {
        const cached = controlResponseCache.get(requestId);
        if (!writeInputLine(cached)) {
          finishWithError(new Error('Failed to resend cached control_response to Claude'));
        }
        return;
      }

      if (!seenControlRequestIds.has(requestId)) {
        seenControlRequestIds.add(requestId);
        try {
          onChunk({ type: 'control_request', requestId, request });
        } catch { /* best effort */ }
      }

      controlQueue = controlQueue
        .then(async () => {
          if (aborted || finished) return;
          let callbackResponse = null;
          if (onControlRequest) {
            try {
              callbackResponse = await onControlRequest({ requestId, request, event });
            } catch (err) {
              callbackResponse = {
                subtype: 'error',
                error: err && err.message ? err.message : 'Control request handler failed',
              };
            }
          }

          const responseMessage = normalizeControlResponse(requestId, request, callbackResponse);
          controlResponseCache.set(requestId, responseMessage);
          // Debug: emit what we're sending back so traces can diagnose issues
          try { onChunk({ type: 'status', text: `[ctrl] ${requestId.slice(0,8)}→${JSON.stringify(responseMessage.response?.response || {}).slice(0,80)}` }); } catch { /* best effort */ }
          if (!writeInputLine(responseMessage)) {
            throw new Error('Failed to send control_response to Claude');
          }
        })
        .catch((err) => {
          if (aborted || finished || isAbortLikeError(err)) return;
          try { onChunk({ type: 'status', text: `Control request failed: ${err.message || err}` }); } catch {}
          finishWithError(err);
        });
    };

    // Stream error handlers — prevent silent data loss on pipe errors
    child.stdout.on('error', (err) => {
      if (finished || aborted) return;
      try { onChunk({ type: 'status', text: `stdout error: ${err.message}` }); } catch { /* best effort */ }
    });
    child.stderr.on('error', () => { /* stderr errors are non-critical */ });

    child.stdout.on('data', (chunk) => {
      if (finished || aborted) return;
      resetIdleTimer();
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        if (finished || aborted) return;
        if (!line.trim()) continue;
        try {
          const event = JSON.parse(line);
          parsedEventCount += 1;
          // First valid event — clear handshake timer
          if (parsedEventCount === 1 && handshakeTimer) {
            clearTimeout(handshakeTimer);
            handshakeTimer = null;
          }
          if (event.type === 'control_request') {
            queueControlResponse(event);
            continue;
          }
          processStreamEvent(event, onChunk, (text) => { fullContent += text; }, parserState);
          if (event.type === 'result') {
            sawResult = true;
            try { child.stdin.end(); } catch { /* ignore */ }
          }
        } catch { /* not valid JSON */ }
      }
    });

    // Claude CLI >= 2.x outputs stream-json events to stderr (stdout stays clean for piping).
    // Parse stderr the same way as stdout so events are captured regardless of which fd they arrive on.
    let stderrJsonBuffer = '';
    child.stderr.on('data', (chunk) => {
      if (finished) return;
      resetIdleTimer();
      const raw = chunk.toString();
      stderrJsonBuffer += raw;
      const stderrLines = stderrJsonBuffer.split('\n');
      stderrJsonBuffer = stderrLines.pop();
      let anyJson = false;
      for (const line of stderrLines) {
        if (finished || aborted) break;
        const trimmed = line.trim();
        if (!trimmed) continue;
        // Attempt to parse as stream-json event
        if (trimmed.startsWith('{')) {
          try {
            const event = JSON.parse(trimmed);
            if (event && typeof event.type === 'string') {
              anyJson = true;
              parsedEventCount += 1;
              if (parsedEventCount === 1 && handshakeTimer) {
                clearTimeout(handshakeTimer);
                handshakeTimer = null;
              }
              if (event.type === 'control_request') {
                queueControlResponse(event);
                continue;
              }
              processStreamEvent(event, onChunk, (text) => { fullContent += text; }, parserState);
              if (event.type === 'result') {
                sawResult = true;
                try { child.stdin.end(); } catch { /* ignore */ }
              }
              continue;
            }
          } catch { /* not valid JSON, fall through to accumulate as plain stderr */ }
        }
        // Non-JSON stderr line — accumulate for error diagnostics
        if (stderr.length < MAX_BUFFER) stderr += trimmed + '\n';
      }
      // If we didn't parse any JSON from this chunk, accumulate the entire raw chunk
      if (!anyJson && stderr.length < MAX_BUFFER) {
        // Only accumulate if nothing was already added line-by-line above
        // (avoid double-counting)
      }
    });

    child.on('close', (code) => {
      clearIdleTimer();
      if (handshakeTimer) { clearTimeout(handshakeTimer); handshakeTimer = null; }
      if (finished) return;
      // Drain trailing stdout buffer
      const trailingBuf = buffer.trim();
      if (trailingBuf && trailingBuf.startsWith('{')) {
        try {
          const event = JSON.parse(trailingBuf);
          parsedEventCount += 1;
          if (event.type === 'control_request') {
            queueControlResponse(event);
          } else {
            processStreamEvent(event, onChunk, (text) => { fullContent += text; }, parserState);
            if (event.type === 'result') sawResult = true;
          }
        } catch {
          if (trailingBuf.length > 5) {
            try { onChunk({ type: 'status', text: `Discarded incomplete trailing data (${trailingBuf.length} chars)` }); } catch { /* best effort */ }
          }
        }
      }
      // Drain trailing stderr JSON buffer (Claude CLI >= 2.x sends stream-json to stderr)
      const trailingStderrBuf = stderrJsonBuffer.trim();
      if (trailingStderrBuf && trailingStderrBuf.startsWith('{')) {
        try {
          const event = JSON.parse(trailingStderrBuf);
          if (event && typeof event.type === 'string') {
            parsedEventCount += 1;
            if (event.type === 'control_request') {
              queueControlResponse(event);
            } else {
              processStreamEvent(event, onChunk, (text) => { fullContent += text; }, parserState);
              if (event.type === 'result') sawResult = true;
            }
          }
        } catch { /* incomplete */ }
      }
      Promise.resolve(controlQueue).finally(() => {
        if (finished || aborted) return;
        if (idleTimedOut) {
          finishWithError(new Error(`Claude stream idle timeout after ${effectiveIdleTimeoutMs}ms`));
          return;
        }

        if (handshakeTimedOut) {
          finishWithError(new Error('Claude stream-json handshake timeout — subprocess produced no events'));
          return;
        }

        // Detect "canceled" in stderr — Claude CLI returns this when stream-json
        // bridge protocol fails internally (not a user abort).
        const stderrLower = stderr.trim().toLowerCase();
        if (!sawResult && !fullContent.trim() && /\bcancele?d\b/.test(stderrLower) && !isAbortLikeError({ message: stderr })) {
          finishWithError(new Error(`Claude CLI bridge canceled (stderr: ${stderr.trim().slice(0, 200)})`));
          return;
        }

        const emptySilentExit = code === 0 && !sawResult && !fullContent.trim() && !stderr.trim() && parsedEventCount === 0;
        if (emptySilentExit) {
          finishWithError(new Error('Claude exited without emitting stream-json output'));
          return;
        }

        if (code === 0 || sawResult || fullContent.trim()) {
          finishWithSuccess(fullContent.trim());
        } else {
          const diag = diagnoseClaudeLaunchIssue();
          const reason = stderr.trim() || diag || `claude exited with code ${code}`;
          try { onChunk({ type: 'status', text: `Claude process failed: ${reason}` }); } catch {}
          finishWithError(new Error(reason));
        }
      });
    });

    child.on('error', (err) => {
      if (finished || aborted) return;
      try { onChunk({ type: 'status', text: `Claude process error: ${err.message}` }); } catch {}
      if (isAbortLikeError(err)) {
        abortChild(err);
      } else {
        finishWithError(err);
      }
    });

    child.stdin.on('error', () => {});
    if (shouldWriteInitialUserLine && !writeInputLine(buildStreamUserMessage(prompt, rawUserMessage))) {
      finishWithError(new Error('Failed to send initial prompt to Claude'));
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Direct Mode — call Anthropic Messages API directly, execute tools locally.
// Activated by GATEWAY_CLAUDE_MODE=direct.
// Eliminates CLI subprocess overhead (~5s startup + control_request protocol).
// ─────────────────────────────────────────────────────────────────────────────

function buildDirectToolDefs() {
  try {
    const { getToolDefinitions } = require('../../toolCalling');
    const defs = getToolDefinitions();
    const ALLOWED = new Set(['Bash', 'Read', 'Write', 'Edit', 'Glob', 'Grep']);
    const seen = new Set();
    return defs.filter(d => {
      if (!ALLOWED.has(d.name) || seen.has(d.name)) return false;
      seen.add(d.name);
      return true;
    }).map(d => ({
      name: d.name,
      description: d.description || '',
      input_schema: d.parameters || { type: 'object', properties: {} },
    }));
  } catch {
    return [
      { name: 'Bash', description: 'Execute a shell command', input_schema: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] } },
      { name: 'Read', description: 'Read a file', input_schema: { type: 'object', properties: { file_path: { type: 'string' } }, required: ['file_path'] } },
      { name: 'Glob', description: 'Find files by glob pattern', input_schema: { type: 'object', properties: { pattern: { type: 'string' } }, required: ['pattern'] } },
      { name: 'Grep', description: 'Search file contents with regex', input_schema: { type: 'object', properties: { pattern: { type: 'string' }, path: { type: 'string' } }, required: ['pattern'] } },
      { name: 'Edit', description: 'Edit a file with string replacement', input_schema: { type: 'object', properties: { file_path: { type: 'string' }, old_string: { type: 'string' }, new_string: { type: 'string' } }, required: ['file_path', 'old_string', 'new_string'] } },
      { name: 'Write', description: 'Write/create a file', input_schema: { type: 'object', properties: { file_path: { type: 'string' }, content: { type: 'string' } }, required: ['file_path', 'content'] } },
    ];
  }
}

/**
 * Direct tool dispatcher — bypasses `toolCalling.executeTool`'s routing chain
 * which prefers the legacy `read_file` builtin (no offset/limit, capped at
 * 10 000 chars) over the Claude-Code-compatible FileReadTool. We resolve each
 * Claude Code tool name to its canonical subdirectory implementation
 * (FileReadTool, FileEditTool, FileWriteTool, GrepTool, GlobTool) and call
 * `.execute()` directly with the exact Claude Code input schema.
 *
 * Falls back to `executeTool` for any tool not in our explicit map (e.g. Bash).
 */
// @deprecated — replaced by unified toolCalling.executeTool() path.
// Kept temporarily for rollback safety.
async function dispatchDirectTool(name, input) {
  const dir = (() => {
    switch (name) {
      case 'Read': return 'FileReadTool';
      case 'Edit': return 'FileEditTool';
      case 'Write': return 'FileWriteTool';
      case 'Grep': return 'GrepTool';
      case 'Glob': return 'GlobTool';
      default: return null;
    }
  })();

  if (dir) {
    try {
      const toolModule = require(`../../../tools/${dir}`);
      // toolModule is either an instance (module.exports = new FooTool()) or has .default
      const instance = (toolModule && typeof toolModule.execute === 'function')
        ? toolModule
        : (toolModule && toolModule.default && typeof toolModule.default.execute === 'function')
          ? toolModule.default
          : null;
      if (instance) {
        return await instance.execute(input || {}, {});
      }
    } catch (err) {
      // Fall through to executeTool fallback below
      return { success: false, error: `Direct tool load failed for ${name}: ${err.message}` };
    }
  }

  // Fallback for tools without a Claude-Code-compatible subdirectory (Bash etc.)
  const toolCalling = require('../../toolCalling');
  return await toolCalling.executeTool(name, input || {});
}

function buildDirectSystemPrompt() {
  const cwd = process.cwd();
  return [
    'You are a senior software engineer assistant with direct tool access.',
    'Execute tasks immediately — Read, Edit, verify, done.',
    '',
    'Rules:',
    '- When the prompt gives a file path and line number, Read ONLY that range. Do NOT search for what is already specified.',
    '- Do NOT re-read files you have already read.',
    '- After Edit, run ONE syntax check then output your summary.',
    '- Prefer Edit over Write for modifying existing files.',
    '- Read a file before editing it.',
    '- Use Glob to find files by name pattern. Use Grep to search file contents.',
    '- Use Bash for shell commands, compilation, and tests.',
    '- Keep code identifiers, comments, and logs in English.',
    '',
    `Working directory: ${cwd}`,
    `Platform: ${process.platform}`,
  ].join('\n');
}

/**
 * Call Anthropic Messages API with streaming, parse SSE events.
 * Returns { role, content[], model, stop_reason, usage }.
 */
async function callAnthropicStream(apiKey, baseUrl, body, emit, signal) {
  let http;
  try { http = require('axios'); } catch {
    // Fallback: use the project-local axios
    http = require(path.resolve(process.cwd(), 'node_modules/axios'));
  }

  body.stream = true;

  // For streaming: use a connection-phase timeout only.
  // Once first bytes arrive, clear the timer — extended thinking / tool use
  // may run for minutes; killing the stream mid-flight causes needless failures.
  const connectTimeoutMs = Math.min(DIRECT_TIMEOUT_MS, 60_000);
  const streamIdleTimeoutMs = DIRECT_TIMEOUT_MS; // kill if no data for this long
  const ac = new AbortController();
  if (signal) signal.addEventListener('abort', () => ac.abort(), { once: true });
  const connectTimer = setTimeout(() => ac.abort(), connectTimeoutMs);

  let resp;
  try {
    resp = await http.post(`${baseUrl}/v1/messages`, body, {
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2024-10-22',
        'Content-Type': 'application/json',
      },
      responseType: 'stream',
      signal: ac.signal,
    });
    clearTimeout(connectTimer);
  } catch (err) {
    clearTimeout(connectTimer);
    throw err;
  }

  return new Promise((resolve, reject) => {
    const contentBlocks = [];
    let currentBlock = null;
    let usage = { input_tokens: 0, output_tokens: 0 };
    let stopReason = null;
    let model = '';
    let buffer = '';

    // Idle timer: reset on every data chunk; abort if stream goes silent
    let idleTimer = setTimeout(() => ac.abort(), streamIdleTimeoutMs);
    const resetIdle = () => {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => ac.abort(), streamIdleTimeoutMs);
    };

    resp.data.on('data', (chunk) => {
      resetIdle();
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data: ')) continue;
        const payload = trimmed.slice(6);
        if (payload === '[DONE]') continue;
        let ev;
        try { ev = JSON.parse(payload); } catch { continue; }

        switch (ev.type) {
          case 'message_start':
            if (ev.message?.usage) usage.input_tokens = ev.message.usage.input_tokens || 0;
            if (ev.message?.model) model = ev.message.model;
            break;
          case 'content_block_start': {
            const b = ev.content_block || {};
            currentBlock = { type: b.type, index: ev.index };
            if (b.type === 'text') { currentBlock.text = b.text || ''; }
            else if (b.type === 'tool_use') { currentBlock.id = b.id; currentBlock.name = b.name; currentBlock.inputJson = ''; }
            else if (b.type === 'thinking') { currentBlock.thinking = b.thinking || ''; }
            break;
          }
          case 'content_block_delta': {
            const d = ev.delta || {};
            if (!currentBlock) break;
            if (d.type === 'text_delta' && d.text) {
              currentBlock.text = (currentBlock.text || '') + d.text;
              emit({ type: 'text', text: d.text });
            } else if (d.type === 'thinking_delta' && d.thinking) {
              currentBlock.thinking = (currentBlock.thinking || '') + d.thinking;
              emit({ type: 'thinking', text: d.thinking });
            } else if (d.type === 'input_json_delta' && d.partial_json) {
              currentBlock.inputJson = (currentBlock.inputJson || '') + d.partial_json;
            }
            break;
          }
          case 'content_block_stop':
            if (currentBlock) {
              if (currentBlock.type === 'tool_use') {
                let input = {};
                try { input = JSON.parse(currentBlock.inputJson || '{}'); } catch {
                  // Repair malformed JSON from truncated/broken tool call streams
                  const { safeJsonParse } = require('../safeJsonParse');
                  input = safeJsonParse(currentBlock.inputJson || '{}', {});
                }
                contentBlocks.push({ type: 'tool_use', id: currentBlock.id, name: currentBlock.name, input });
                emit({ type: 'tool_use', tool: currentBlock.name, input: JSON.stringify(input).slice(0, 120), id: currentBlock.id });
              } else if (currentBlock.type === 'text') {
                contentBlocks.push({ type: 'text', text: currentBlock.text || '' });
              } else if (currentBlock.type === 'thinking') {
                contentBlocks.push({ type: 'thinking', thinking: currentBlock.thinking || '' });
              }
              currentBlock = null;
            }
            break;
          case 'message_delta':
            if (ev.delta?.stop_reason) stopReason = ev.delta.stop_reason;
            if (ev.usage) usage.output_tokens = ev.usage.output_tokens || 0;
            break;
        }
      }
    });

    resp.data.on('end', () => {
      clearTimeout(idleTimer);
      resolve({ content: contentBlocks, model, stop_reason: stopReason, usage });
    });
    resp.data.on('error', (err) => {
      clearTimeout(idleTimer);
      reject(err);
    });
  });
}

/**
 * Direct agentic loop: Anthropic Messages API → local tool execution → loop.
 */
async function runClaudeDirect(prompt, options = {}) {
  // Priority: env vars > apiKeyPool
  let apiKey = extractPrimaryApiKey(process.env.ANTHROPIC_API_KEY)
    || extractPrimaryApiKey(process.env.ANTHROPIC_AUTH_TOKEN)
    || extractPrimaryApiKey(process.env.CLAUDE_API_KEY);
  let poolKeyId = null;
  let poolEndpoint = null;

  if (!apiKey) {
    try {
      const pool = require('../../apiKeyPool');
      pool.init();
      const picked = pool.pick('anthropic');
      if (picked) {
        apiKey = picked.key;
        poolKeyId = picked.keyId;
        poolEndpoint = picked.endpoint || null;
      }
    } catch { /* pool unavailable */ }
  }

  if (!apiKey) throw new Error('No Anthropic API key — set ANTHROPIC_API_KEY or add keys via API Key Pool');

  // Strip trailing /v1, /v1/, etc. — callAnthropicStream appends /v1/messages itself.
  const baseUrl = (poolEndpoint || process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com')
    .replace(/\/+$/, '')
    .replace(/\/v\d+$/, '');
  const model = options.model || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6';
  const onChunk = typeof options.onChunk === 'function' ? options.onChunk : () => {};
  const emit = (chunk) => { try { onChunk(chunk); } catch { /* best effort */ } };

  // Strip [System ...] blocks appended by agenticHarnessService._buildLoopInput
  // so greeting/fast-path detection sees only the actual user input.
  const rawUserMessage = String(options.userMessage || prompt || '')
    .replace(/\n\n\[System\b[\s\S]*/i, '').trim();
  const useDirectFastPath = shouldUseDirectFastPath(prompt, options);
  const promptForModel = useDirectFastPath
    ? (rawUserMessage || String(prompt || ''))
    : applyAgenticGuidancePrefix(prompt, rawUserMessage);
  const tools = useDirectFastPath ? [] : buildDirectToolDefs();
  let system = useDirectFastPath
    ? [
      'You are a concise, helpful assistant.',
      'Respond directly and briefly.',
      'Do not use tools unless absolutely necessary.',
      `Working directory: ${process.cwd()}`,
      `Platform: ${process.platform}`,
    ].join('\n')
    : buildDirectSystemPrompt();
  // Append intentGate directive (e.g. CODING_DIRECTIVE, ULTRAWORK_DIRECTIVE)
  // so the model receives behavioural instructions in the system prompt.
  const intentDirective = String(options._intentDirective || '').trim();
  if (intentDirective && !useDirectFastPath) {
    system += '\n\n' + intentDirective;
  }

  const directRoundLimit = useDirectFastPath
    ? Math.max(1, Math.min(DIRECT_MAX_ITERATIONS, DIRECT_SIMPLE_MAX_ROUNDS))
    : DIRECT_MAX_ITERATIONS;

  // Build conversation messages (with optional vision support)
  let userContent;
  if (Array.isArray(options.images) && options.images.length > 0) {
    // Multi-modal: text + image(s) in content array
    userContent = [{ type: 'text', text: promptForModel }];
    const imageBlocks = toAnthropicImageBlocks(options.images || []);
    for (const block of imageBlocks) userContent.push(block);
  } else {
    userContent = promptForModel;
  }
  // Build conversation messages: prefer structured multi-turn history from options,
  // fall back to single user message for backwards compatibility.
  let messages;
  if (Array.isArray(options.structuredMessages) && options.structuredMessages.length > 1) {
    // structuredMessages contains system + user/assistant turns.
    // Filter out system messages (handled via separate `system` param) and
    // ensure the current user message (with possible images) is the final entry.
    const historyMsgs = options.structuredMessages.filter(m => m.role !== 'system');
    // Replace or append the last user message with potentially image-augmented content
    if (historyMsgs.length > 0 && historyMsgs[historyMsgs.length - 1].role === 'user') {
      historyMsgs[historyMsgs.length - 1] = { role: 'user', content: userContent };
    } else {
      historyMsgs.push({ role: 'user', content: userContent });
    }
    messages = historyMsgs;
  } else {
    messages = [{ role: 'user', content: userContent }];
  }

  const state = { toolCalls: 0, toolDurationMs: 0, finalText: [] };
  const seenCalls = new Set();

  emit({
    type: 'status',
    text: useDirectFastPath
      ? `⚡ 直连 Anthropic API（快速路径）：model=${model}`
      : `⚡ 直连 Anthropic API：model=${model}, tools=${tools.length}`,
  });

  let toolCalling = null;

  const startMs = Date.now();

  try {
  for (let iteration = 0; iteration < directRoundLimit; iteration++) {
    emit({ type: 'status', text: `Claude Direct: round ${iteration + 1}` });

    // Adaptive thinking & tool selection based on input complexity.
    // Simple conversations (greetings, short questions) should be fast:
    //   - No extended thinking (explicit disable for Opus models)
    //   - No tools (avoids unnecessary tool call rounds)
    // Complex inputs (long text, multi-turn, follow-up iterations) get full capabilities.
    const lastUserMsg = messages.filter(m => m.role === 'user').pop();
    const userTextLen = typeof lastUserMsg?.content === 'string'
      ? lastUserMsg.content.length
      : Array.isArray(lastUserMsg?.content)
        ? lastUserMsg.content.reduce((s, b) => s + (b.text || '').length, 0)
        : 0;
    const hasImageContent = Array.isArray(lastUserMsg?.content)
      && lastUserMsg.content.some(b => b.type === 'image');
    const isActionableTask = looksLikeToolOrCodeTask(rawUserMessage);
    const isComplexInput = useDirectFastPath
      ? false
      : isActionableTask || userTextLen > 80 || messages.length > 4 || iteration > 0 || hasImageContent;

    // Only include tools for complex/actionable requests
    const effectiveTools = isComplexInput ? tools : [];

    const body = {
      model,
      max_tokens: useDirectFastPath
        ? Math.min(options.maxTokens || DIRECT_SIMPLE_MAX_TOKENS, DIRECT_SIMPLE_MAX_TOKENS)
        : (options.maxTokens || 8192),
      // Enable API prompt caching: wrap system prompt as a content block
      // with cache_control when it's large enough to benefit.
      system: system.length > 500
        ? [{ type: 'text', text: system, cache_control: { type: 'ephemeral' } }]
        : system,
      messages,
    };
    if (effectiveTools.length > 0) {
      body.tools = effectiveTools;
      // Cache the last tool definition block for prompt caching
      if (body.tools.length > 0) {
        const last = body.tools[body.tools.length - 1];
        body.tools[body.tools.length - 1] = { ...last, cache_control: { type: 'ephemeral' } };
      }
    }

    // Extended thinking: explicit enable/disable.
    // Opus 4.6 defaults to thinking-enabled if omitted — must explicitly disable.
    const wantThinking = !useDirectFastPath && (
      (options.thinking && options.thinking.budgetTokens)
      || isComplexInput
    );
    if (wantThinking) {
      const budget = (options.thinking && options.thinking.budgetTokens) || 10000;
      body.thinking = { type: 'enabled', budget_tokens: budget };
      body.max_tokens = Math.max(body.max_tokens, budget + 4096);
    } else {
      // Explicitly disable to prevent Opus default thinking
      body.thinking = { type: 'disabled' };
    }

    // Force tool use based on intent gate mode or default to auto on first round
    if (effectiveTools.length > 0) {
      const intentChoice = String(options._intentToolChoice || '').trim();
      if (intentChoice === 'required' && iteration < 3) {
        body.tool_choice = { type: 'any' };
      } else if (iteration === 0) {
        body.tool_choice = { type: 'auto' };
      }
    }

    const result = await callAnthropicStream(apiKey, baseUrl, body, emit, options.abortSignal);

    // Record genai events
    const g = genai();
    if (g) {
      try {
        g.recordLLMCall({
          traceId: `claude_direct_${startMs}`,
          model: result.model || model,
          inputTokens: result.usage?.input_tokens || 0,
          outputTokens: result.usage?.output_tokens || 0,
          durationMs: Date.now() - startMs,
        });
      } catch { /* best effort */ }
    }

    // Separate tool_use blocks from text/thinking
    const toolUseBlocks = [];
    const assistantContent = [];
    for (const block of (result.content || [])) {
      assistantContent.push(block);
      if (block.type === 'tool_use') toolUseBlocks.push(block);
      if (block.type === 'text' && block.text) {
        state.finalText.push(block.text);
        // Stream text to UI immediately so file explanations appear between tool calls
        emit({ type: 'text', text: block.text });
      }
    }

    // Append assistant message to conversation
    messages.push({ role: 'assistant', content: assistantContent });

    // No tool calls → done
    if (toolUseBlocks.length === 0 || result.stop_reason === 'end_turn') {
      emit({ type: 'status', text: `Claude Direct: done in ${iteration + 1} rounds, ${state.toolCalls} tool calls` });
      break;
    }

    // Execute tool calls
    if (!toolCalling) {
      try {
        toolCalling = require('../../toolCalling');
      } catch (err) {
        emit({ type: 'status', text: `Tool system unavailable: ${err.message}` });
        throw err;
      }
    }
    const wasDangerous = toolCalling.isDangerousMode();
    if (!wasDangerous) toolCalling.enableDangerousMode();

    const toolResults = [];
    for (const tc of toolUseBlocks) {
      const dedupKey = `${tc.name}:${JSON.stringify(tc.input)}`;
      if (seenCalls.has(dedupKey)) {
        toolResults.push({ type: 'tool_result', tool_use_id: tc.id, content: 'Duplicate call skipped' });
        continue;
      }
      seenCalls.add(dedupKey);
      state.toolCalls++;

      // Capture file state before write for diff rendering
      let _writeDiffCtx = null;
      try {
        const _tcName = String(tc.name || '').toLowerCase().replace(/[\s_-]/g, '');
        if (_tcName === 'write' || _tcName === 'writefile' || _tcName === 'writeFile') {
          const _fp = tc.input?.file_path || tc.input?.path || tc.input?.filePath;
          if (_fp && typeof (tc.input?.content) === 'string') {
            const _abs = require('path').isAbsolute(_fp) ? _fp : require('path').resolve(process.env.KHYQUANT_CWD || process.cwd(), _fp);
            const _before = require('fs').existsSync(_abs) ? require('fs').readFileSync(_abs, 'utf-8') : '';
            _writeDiffCtx = { filePath: _abs, beforeContent: _before, afterContent: tc.input.content };
          }
        }
      } catch { /* non-critical */ }

      // Unified tool dispatch via toolCalling.executeTool().
      // Registry tools with alwaysLoad (FileReadTool etc.) now take priority
      // over legacy builtins, so offset/limit and full features are preserved.
      const toolStart = Date.now();
      let execResult;
      try {
        execResult = await toolCalling.executeTool(tc.name, tc.input || {});
      } catch (err) {
        execResult = { success: false, error: err.message || 'tool execution failed' };
      }
      const elapsed = Date.now() - toolStart;
      state.toolDurationMs += elapsed;

      let outputStr;
      if (execResult && execResult.success !== false) {
        // Different tools return content in different fields — normalize
        const content = execResult.output || execResult.content || execResult.result || execResult.text || '';
        if (typeof content === 'string' && content) {
          outputStr = content;
        } else if (execResult.matches && Array.isArray(execResult.matches)) {
          // Grep returns { matches: [...] }
          outputStr = execResult.matches.map(m => typeof m === 'string' ? m : JSON.stringify(m)).join('\n');
          if (!outputStr) outputStr = execResult.message || 'No matches found';
        } else if (execResult.files && Array.isArray(execResult.files)) {
          // Glob returns { files: [...] }
          outputStr = execResult.files.join('\n') || 'No files found';
        } else if (execResult.counts && Array.isArray(execResult.counts)) {
          // Grep count mode
          outputStr = execResult.counts.map(c => `${c.file || c.path}:${c.count}`).join('\n');
        } else if (typeof content === 'object' && content !== null) {
          outputStr = JSON.stringify(content);
        } else {
          // Fallback: serialize the entire result minus metadata
          const { success: _s, ...rest } = execResult;
          outputStr = Object.keys(rest).length > 0 ? JSON.stringify(rest) : 'success';
        }
        if (outputStr.length > DIRECT_MAX_OUTPUT) {
          const HEAD = Math.min(2048, Math.floor(DIRECT_MAX_OUTPUT * 0.15));
          const TAIL = DIRECT_MAX_OUTPUT - HEAD - 80;
          outputStr = outputStr.slice(0, HEAD) + `\n...[${outputStr.length - HEAD - TAIL} chars omitted]...\n` + outputStr.slice(-TAIL);
        }
      } else {
        outputStr = JSON.stringify({ error: (execResult && execResult.error) || 'tool execution failed' });
      }

      emit({ type: 'tool_result', id: tc.id, content: outputStr.slice(0, 180) });

      // Emit rich tool_complete event with diff context for REPL rendering
      if (_writeDiffCtx && execResult && execResult.success !== false) {
        execResult._khyWriteDiff = _writeDiffCtx;
      }
      emit({ type: 'tool_complete', name: tc.name, params: tc.input || {}, result: execResult || {}, elapsed });

      if (g) {
        try { g.recordToolUse({ traceId: `claude_direct_${startMs}`, tool: tc.name, durationMs: elapsed, success: !!(execResult && execResult.success) }); } catch { /* */ }
      }

      toolResults.push({ type: 'tool_result', tool_use_id: tc.id, content: outputStr });
    }

    // All calls deduped → task is done, break loop
    const allDeduped = toolResults.length > 0 && toolResults.every(
      tr => tr.content === 'Duplicate call skipped'
    );
    if (allDeduped) {
      emit({ type: 'status', text: `Claude Direct: all ${toolResults.length} calls deduped, stopping at round ${iteration + 1}` });
      if (!wasDangerous) toolCalling.disableDangerousMode();
      break;
    }

    if (!wasDangerous) toolCalling.disableDangerousMode();

    // Append tool results as user message
    messages.push({ role: 'user', content: toolResults });
  }
  } catch (loopErr) {
    // Track pool key failure for rotation/cooldown
    if (poolKeyId) {
      try {
        const pool = require('../../apiKeyPool');
        const statusCode = loopErr.response?.status || loopErr.status || 0;
        pool.markFailure(poolKeyId, statusCode, loopErr.message || 'direct mode error');
      } catch { /* best effort */ }
    }
    throw loopErr;
  }

  // Track pool key success
  if (poolKeyId) {
    try { require('../../apiKeyPool').markSuccess(poolKeyId); } catch { /* best effort */ }
  }

  const content = state.finalText.join('\n').trim();
  return {
    content: content || 'Claude Direct: no response generated',
    toolSummary: { totalCalls: state.toolCalls, totalDurationMs: state.toolDurationMs },
    elapsedMs: Date.now() - startMs,
  };
}

/**
 * Generate a response using Claude Code CLI.
 */
async function generate(prompt, options = {}) {
  // ── Resolve connection mode ──
  // Priority: ::mode suffix in model id > options.directMode > env > auto
  let useDirect;
  let resolvedModel = options.model;
  if (typeof options.model === 'string' && options.model.includes('::')) {
    const parsed = parseModelId(options.model);
    resolvedModel = parsed.modelId;
    if (parsed.mode === 'direct') useDirect = true;
    else if (parsed.mode === 'bridge' || parsed.mode === 'cli') useDirect = false;
    else if (parsed.mode === 'auto') useDirect = _hasAnthropicKey();
  }
  if (useDirect === undefined) {
    if (options.directMode === true) useDirect = true;
    else if (options.directMode === false) useDirect = false;
    else useDirect = resolveConnectionMode() === 'direct';
  }
  // Replace options.model with the base model id (strip ::mode suffix)
  if (resolvedModel !== options.model) options = { ...options, model: resolvedModel };
  if (useDirect) {
    try {
      const result = await runClaudeDirect(prompt, options);
      return {
        success: true,
        content: result.content,
        provider: `Claude Direct (${options.model || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6'})`,
        adapter: 'claude',
        mode: 'direct',
        toolSummary: result.toolSummary,
        elapsedMs: result.elapsedMs,
        attempts: [{ provider: 'Claude Direct', success: true }],
      };
    } catch (err) {
      const safeError = formatErrorMessage(err);
      return {
        success: false,
        content: '',
        provider: 'Claude Direct',
        adapter: 'claude',
        mode: 'direct',
        error: safeError || err.message,
        errorType: classifyClaudeError(err),
        attempts: [{ provider: 'Claude Direct', success: false, error: safeError || err.message }],
      };
    }
  }

  // ── CLI mode (original path) ──
  if (!detect()) {
    return {
      success: false,
      content: '',
      error: 'Claude Code CLI not installed (command "claude" not found)',
      errorType: 'unavailable',
      provider: 'Claude Code',
      adapter: 'claude',
      attempts: [{ provider: 'Claude Code', success: false, error: 'Claude Code CLI not installed (command "claude" not found)', errorType: 'unavailable' }],
    };
  }

  const onChunk = options.onChunk || (() => {});
  const onControlRequest = typeof options.onControlRequest === 'function'
    ? options.onControlRequest
    : null;
  const args = buildClaudeArgs(options);

  // Inject intentGate directive into the prompt for Bridge mode.
  // Bridge sends the flat conversation as a user message to Claude CLI,
  // which has its own system prompt. Prepend the directive so it's
  // prominent enough to influence behavior.
  let bridgePrompt = prompt;
  const bridgeIntentDirective = String(options._intentDirective || '').trim();
  if (bridgeIntentDirective) {
    bridgePrompt = bridgeIntentDirective + '\n\n' + prompt;
  }

  try {
    let content;
    try {
      content = await runClaudeAttempt({
        launchMode: 'direct',
        prompt: bridgePrompt,
        rawUserMessage: options.userMessage,
        args,
        timeoutMs: options.timeoutMs,
        onChunk,
        onControlRequest,
        abortSignal: options.abortSignal || null,
      });
    } catch (firstErr) {
      const firstErrMsg = String(firstErr && firstErr.message ? firstErr.message : '');
      const isBridgeProtocolFailure =
        firstErrMsg.includes('without emitting stream-json output') ||
        firstErrMsg.includes('handshake timeout') ||
        firstErrMsg.includes('bridge canceled');
      const shouldRetryWithSeededShell =
        process.platform !== 'win32' && isBridgeProtocolFailure;
      const shouldRetryTransient =
        !shouldRetryWithSeededShell &&
        process.env.GATEWAY_CLAUDE_RETRY_TRANSIENT !== 'false' &&
        shouldRetryClaudeTransient(firstErr);

      // Strip verbose/partial flags on retry — they can trigger edge-case bugs
      // in certain Claude CLI versions.
      const retryArgs = args.filter(a => a !== '--verbose' && a !== '--include-partial-messages');

      if (shouldRetryWithSeededShell) {
        try { onChunk({ type: 'status', text: 'Bridge protocol failure — retrying with seeded-shell mode (simplified args)' }); } catch { /* best effort */ }
        content = await runClaudeAttempt({
          launchMode: 'seeded_shell',
          prompt,
          rawUserMessage: options.userMessage,
          args: retryArgs,
          timeoutMs: options.timeoutMs,
          onChunk,
          onControlRequest,
          abortSignal: options.abortSignal || null,
        });
      } else if (shouldRetryTransient) {
        try { onChunk({ type: 'status', text: 'Claude transient failure detected, retrying once...' }); } catch { /* best effort */ }
        content = await runClaudeAttempt({
          launchMode: 'direct',
          prompt,
          rawUserMessage: options.userMessage,
          args,
          timeoutMs: options.timeoutMs,
          onChunk,
          onControlRequest,
          abortSignal: options.abortSignal || null,
        });
      } else {
        throw firstErr;
      }
    }

    return {
      success: true,
      content,
      provider: `Claude Code (${options.model || 'default'})`,
      adapter: 'claude',
      attempts: [{ provider: 'Claude Code', success: true }],
    };
  } catch (err) {
    const safeError = formatErrorMessage(err);
    const errorType = classifyClaudeError(err);

    // Bridge-to-direct auto-fallback: if bridge failed with process error and
    // an Anthropic API key is available, try direct mode as last resort.
    if (errorType === 'process' && _hasAnthropicKey()) {
      try {
        try { onChunk({ type: 'status', text: 'Bridge mode failed — auto-falling back to Anthropic Direct API' }); } catch { /* best effort */ }
        const directResult = await runClaudeDirect(prompt, options);
        return {
          success: true,
          content: directResult.content,
          provider: `Claude Direct (bridge-fallback, ${options.model || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6'})`,
          adapter: 'claude',
          mode: 'direct',
          toolSummary: directResult.toolSummary,
          elapsedMs: directResult.elapsedMs,
          attempts: [
            { provider: 'Claude Code (bridge)', success: false, error: safeError || err.message, errorType },
            { provider: 'Claude Direct (fallback)', success: true },
          ],
        };
      } catch (directErr) {
        const directSafe = formatErrorMessage(directErr);
        return {
          success: false,
          content: '',
          provider: 'Claude Code',
          adapter: 'claude',
          error: `Bridge failed: ${safeError || err.message}; Direct fallback also failed: ${directSafe || directErr.message}`,
          errorType,
          attempts: [
            { provider: 'Claude Code (bridge)', success: false, error: safeError || err.message, errorType },
            { provider: 'Claude Direct (fallback)', success: false, error: directSafe || directErr.message },
          ],
        };
      }
    }

    return {
      success: false,
      content: '',
      provider: 'Claude Code',
      adapter: 'claude',
      error: safeError || err.message,
      errorType,
      attempts: [{ provider: 'Claude Code', success: false, error: safeError || err.message, errorType }],
    };
  }
}

function getStatus() {
  detect();
  return {
    name: 'Claude Code',
    type: 'claude',
    available: _available,
    detail: _available ? 'claude CLI 可用' : '未检测到 claude 命令',
  };
}

function destroy() { _available = null; }

module.exports = { detect, detectAsync, listModels, generate, getStatus, destroy };
