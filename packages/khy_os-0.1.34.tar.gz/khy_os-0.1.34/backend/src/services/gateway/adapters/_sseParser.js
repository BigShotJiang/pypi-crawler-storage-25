/**
 * @pattern Iterator
 */
'use strict';

/**
 * _sseParser.js — OpenAI 兼容 SSE 流解析
 *
 * 从 traeAdapter.consumeSseText 和 windsurfAdapter.consumeSseText 中提取，
 * 两者逻辑完全一致。
 */

/**
 * 解析 OpenAI 兼容的 SSE 文本，提取 delta content 并通过 onChunk 回调发出。
 *
 * @param {string} text - SSE 原始文本（可包含多行 "data: {...}" ）
 * @param {function|null} onChunk - 流式回调 ({ type: 'text', text: string }) => void
 * @returns {string} 拼接后的完整文本
 */
function consumeSseText(text = '', onChunk = null) {
  const chunks = String(text || '').split(/\r?\n/);
  let full = '';

  for (const lineRaw of chunks) {
    const line = String(lineRaw || '').trim();
    if (!line || !line.startsWith('data:')) continue;
    const data = line.slice(5).trim();
    if (!data || data === '[DONE]') continue;
    try {
      const obj = JSON.parse(data);
      const delta = obj?.choices?.[0]?.delta?.content;
      const textPart = typeof delta === 'string'
        ? delta
        : (typeof obj?.choices?.[0]?.message?.content === 'string' ? obj.choices[0].message.content : '');
      if (!textPart) continue;
      full += textPart;
      if (typeof onChunk === 'function') onChunk({ type: 'text', text: textPart });
    } catch {
      // 容忍非 JSON 的 SSE 行
    }
  }

  return full;
}

/**
 * 增量 SSE 解析 — 处理跨 chunk 边界的 SSE 数据。
 * 适用于流式 HTTP 响应中逐 chunk 到达的场景。
 *
 * @param {{ buffer: string }} state - 持久状态对象，保存跨 chunk 未处理的文本
 * @param {string} incomingText - 新到达的文本片段
 * @param {function|null} onChunk - 流式回调
 * @returns {string} 本次调用中提取的文本（不含累计）
 */
function consumeSseIncremental(state, incomingText = '', onChunk = null) {
  state.buffer = (state.buffer || '') + incomingText;

  // 找到最后一个完整行的位置
  const lastNewline = state.buffer.lastIndexOf('\n');
  if (lastNewline < 0) return '';

  const complete = state.buffer.slice(0, lastNewline + 1);
  state.buffer = state.buffer.slice(lastNewline + 1);

  return consumeSseText(complete, onChunk);
}

module.exports = {
  consumeSseText,
  consumeSseIncremental,
};
