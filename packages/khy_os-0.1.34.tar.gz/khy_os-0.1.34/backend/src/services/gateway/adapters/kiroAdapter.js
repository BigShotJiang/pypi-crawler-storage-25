/**
 * Kiro Adapter — connect to Kiro IDE's AI models via AWS CodeWhisperer.
 *
 * Reads Kiro's auth token from ~/.aws/sso/cache/kiro-auth-token.json,
 * auto-refreshes expired tokens (Social/IdC), and calls the Q Developer
 * streaming API for chat completions.
 *
 * Token logic ported from kiro-proxy (token-reader.js + q-client.js).
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const https = require('https');
const http = require('http');
const { sanitizeOutgoingHeaders } = require('./ipAnonymizer');
const {
  buildKiroUserAgent,
  buildKiroHeaders,
  applyJitter,
  resetSession: resetFingerprintSession,
  resetAll: resetFingerprintAll,
} = require('./_fingerprint');

// Proxy change listener registered at module bottom (after state variables are declared)

const KIRO_DEBUG = String(process.env.KIRO_DEBUG || '').toLowerCase() === 'true';
function debugLog(...args) { if (KIRO_DEBUG) console.log('[kiro:debug]', ...args); }
const KIRO_LOGIN_URL = process.env.KIRO_LOGIN_URL || 'https://kiro.dev';
const KIRO_AUTO_OPEN_LOGIN = !/^(0|false|off)$/i.test(String(process.env.KIRO_AUTO_OPEN_LOGIN || '1').trim());
const KIRO_LOGIN_COOLDOWN_MS = Math.max(5_000, Number(process.env.KIRO_LOGIN_COOLDOWN_MS || 60_000) || 60_000);

// ── Token paths — multi-path scanning ───────────────────────────────────
const KIRO_TOKEN_FILE = 'kiro-auth-token.json';

const SOCIAL_REFRESH_URL = 'https://prod.us-east-1.auth.desktop.kiro.dev/refreshToken';
const REFRESH_BUFFER_MS = 5 * 60 * 1000; // 5 min pre-refresh buffer

/**
 * Return all candidate SSO cache directories.
 * On Windows, os.homedir() may differ from %USERPROFILE% when running as a
 * service or from a different user context, so we probe multiple roots.
 */
function _getSsoCacheDirs() {
  const seen = new Set();
  const dirs = [];
  const add = (d) => { const n = path.normalize(d); if (!seen.has(n)) { seen.add(n); dirs.push(n); } };
  add(path.join(os.homedir(), '.aws', 'sso', 'cache'));
  if (process.platform === 'win32') {
    const up = process.env.USERPROFILE || '';
    const hp = process.env.HOMEDRIVE && process.env.HOMEPATH
      ? path.join(process.env.HOMEDRIVE, process.env.HOMEPATH) : '';
    if (up) add(path.join(up, '.aws', 'sso', 'cache'));
    if (hp) add(path.join(hp, '.aws', 'sso', 'cache'));
  }
  return dirs;
}

/**
 * Return all candidate Kiro profile.json paths (multi-platform).
 */
function _getKiroProfilePaths() {
  const seen = new Set();
  const paths = [];
  const add = (p) => { const n = path.normalize(p); if (!seen.has(n)) { seen.add(n); paths.push(n); } };
  const gs = (...segs) => path.join(...segs, 'Kiro', 'User', 'globalStorage', 'kiro.kiroagent', 'profile.json');

  if (process.platform === 'darwin') {
    add(gs(os.homedir(), 'Library', 'Application Support'));
  }
  if (process.platform === 'linux') {
    const xdg = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
    add(gs(xdg));
  }
  if (process.platform === 'win32') {
    const appData = process.env.APPDATA || '';
    const localAppData = process.env.LOCALAPPDATA || '';
    if (appData) add(gs(appData));
    if (localAppData) add(gs(localAppData));
    // Fallback: os.homedir()\AppData\Roaming (in case %APPDATA% is unset)
    add(gs(os.homedir(), 'AppData', 'Roaming'));
  }
  return paths;
}

/**
 * Return all candidate paths where Kiro auth token might exist.
 * Covers Linux, macOS, and Windows (%APPDATA%, %LOCALAPPDATA%, %USERPROFILE%,
 * %HOMEDRIVE%%HOMEPATH%).
 * Highest priority: KIRO_TOKEN_PATH env var override.
 */
function getKiroTokenCandidatePaths() {
  const seen = new Set();
  const paths = [];
  const add = (p) => {
    const norm = path.normalize(p);
    if (!seen.has(norm)) { seen.add(norm); paths.push(norm); }
  };

  // 1. Explicit env override (highest priority)
  if (process.env.KIRO_TOKEN_PATH) add(process.env.KIRO_TOKEN_PATH);

  // 2. All SSO cache dirs (handles os.homedir() vs %USERPROFILE% mismatch)
  for (const dir of _getSsoCacheDirs()) {
    add(path.join(dir, KIRO_TOKEN_FILE));
  }

  // 3. Windows extra roots: %APPDATA%\aws\..., %LOCALAPPDATA%\aws\...
  if (process.platform === 'win32') {
    const appData = process.env.APPDATA || '';
    const localAppData = process.env.LOCALAPPDATA || '';
    if (appData) add(path.join(appData, 'aws', 'sso', 'cache', KIRO_TOKEN_FILE));
    if (localAppData) add(path.join(localAppData, 'aws', 'sso', 'cache', KIRO_TOKEN_FILE));
    // Kiro IDE auth storage on Windows
    if (appData) add(path.join(appData, 'Kiro', 'User', 'globalStorage', 'kiro.kiroagent', 'auth.json'));
    if (localAppData) add(path.join(localAppData, 'Kiro', 'User', 'globalStorage', 'kiro.kiroagent', 'auth.json'));
  }

  // 4. XDG config on Linux
  if (process.platform === 'linux') {
    const xdg = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
    add(path.join(xdg, 'Kiro', 'User', 'globalStorage', 'kiro.kiroagent', 'auth.json'));
  }

  // 5. macOS Application Support
  if (process.platform === 'darwin') {
    add(path.join(os.homedir(), 'Library', 'Application Support', 'Kiro', 'User', 'globalStorage', 'kiro.kiroagent', 'auth.json'));
  }

  return paths;
}

// ── Region → endpoint ────────────────────────────────────────────────────
const REGION_ENDPOINTS = {
  'us-east-1': 'https://q.us-east-1.amazonaws.com',
  'eu-west-1': 'https://q.eu-west-1.amazonaws.com',
  'ap-southeast-1': 'https://q.ap-southeast-1.amazonaws.com',
  'ap-northeast-1': 'https://q.ap-northeast-1.amazonaws.com',
  'eu-central-1': 'https://q.eu-central-1.amazonaws.com',
  'ap-south-1': 'https://q.ap-south-1.amazonaws.com',
  'ca-central-1': 'https://q.ca-central-1.amazonaws.com',
};
const REGION_ENDPOINTS_CN = {
  'cn-north-1': 'https://q.cn-north-1.amazonaws.com.cn',
  'cn-northwest-1': 'https://q.cn-northwest-1.amazonaws.com.cn',
};
const DEFAULT_REGION = 'us-east-1';
const KIRO_VERSION = process.env.KIRO_VERSION || '0.11.107';
const TIMEOUT_MS = 120_000;
const ACCOUNT_POOL_TYPE = 'kiro';

// Claude models visible in Kiro IDE's model picker but often missing from
// the ListAvailableModels API response. Kiro IDE hardcodes these; we inject
// them so users can select Claude through the Kiro adapter. If the Q Developer
// API rejects a model ID at generate() time, it fails gracefully.
// Model IDs use dot notation (e.g. "claude-sonnet-4.6") matching Q Developer
// format — different from Anthropic's "claude-sonnet-4-6" dash format.
// Source: kiro-proxy q-client.js + Kiro IDE v0.11 model picker
const KIRO_INJECTED_CLAUDE_MODELS = [
  { id: 'claude-sonnet-4.6', name: 'Claude Sonnet 4.6', tier: 'high', credit: '1.3x' },
  { id: 'claude-opus-4.6', name: 'Claude Opus 4.6', tier: 'ultra', credit: '1.3x' },
  { id: 'claude-haiku-4.5', name: 'Claude Haiku 4.5', tier: 'medium', credit: '0.4x' },
  { id: 'claude-sonnet-4.5', name: 'Claude Sonnet 4.5', tier: 'high', credit: '1.3x' },
  { id: 'claude-sonnet-4', name: 'Claude Sonnet 4', tier: 'high', credit: '1.3x' },
];
const KIRO_INJECT_CLAUDE = !/^(0|false|off)$/i.test(
  String(process.env.KIRO_INJECT_CLAUDE_MODELS || '1').trim()
);

// ── Kiro Proxy support ──────────────────────────────────────────────────
// When set, adapter will try kiro-proxy first for model listing and chat.
// e.g. KIRO_PROXY_URL=http://localhost:3456
const KIRO_PROXY_URL = (process.env.KIRO_PROXY_URL || '').replace(/\/+$/, '');

// ── In-memory state ──────────────────────────────────────────────────────
let _cachedToken = null;
let _cachedTokenSignature = '';
let _lastTokenProbeMs = 0;
let _refreshPromise = null;
let _refreshBackoffUntil = 0; // Backoff after failed refresh attempts
let _available = null;
let _models = [];
let _modelsFetchedAt = 0;
const MODEL_CACHE_TTL = parseInt(process.env.KIRO_MODEL_CACHE_MS || '300000', 10); // 5min
let _installDetected = false;
let _cwModule = null; // lazy-loaded ESM module
let _sdkClient = null; // cached SDK client
let _sdkClientToken = null; // token the cached client was created with
let _lastLoginPromptAt = 0;

// ── HTTP proxy support ──────────────────────────────────────────────────
// Supports HTTPS_PROXY / HTTP_PROXY / ALL_PROXY / KIRO_HTTP_PROXY for
// users behind Clash, V2Ray, or corporate proxies (common in China).

const KIRO_AUTO_PROXY = !/^(0|false|off)$/i.test(String(process.env.KIRO_AUTO_PROXY || '1').trim());
const KIRO_PROXY_RETRY_MS = Math.max(1000, Number(process.env.KIRO_PROXY_RETRY_MS || 300_000) || 300_000);
const KIRO_AUTO_PROXY_PORTS = String(process.env.KIRO_AUTO_PROXY_PORTS || '7890,7891,7892,8080,8888')
  .split(',')
  .map(v => Number.parseInt(String(v).trim(), 10))
  .filter(v => Number.isFinite(v) && v > 0 && v <= 65535);
const KIRO_PROXY_ROUTE_MODE = String(
  process.env.KIRO_PROXY_ROUTE_MODE
  || process.env.GATEWAY_PROXY_ROUTE_MODE
  || 'auto'
).trim().toLowerCase();
const KIRO_DISCOVERY_REQUIRE_PROXY = /^(1|true|yes|on)$/i.test(
  String(
    process.env.KIRO_DISCOVERY_REQUIRE_PROXY
    || process.env.KIRO_REQUIRE_PROXY_FOR_DISCOVERY
    || '0'
  ).trim()
);
const _proxyBackoffUntil = new Map();

function _parseList(raw) {
  if (Array.isArray(raw)) {
    return raw.map(v => String(v || '').trim()).filter(Boolean);
  }
  return String(raw || '')
    .split(/[\n,]/g)
    .map(v => String(v || '').trim())
    .filter(Boolean);
}

function _normalizeRouteMode(raw) {
  const mode = String(raw || '').trim().toLowerCase();
  if (['always', 'proxy', 'proxy-first'].includes(mode)) return 'always';
  if (['never', 'direct', 'direct-only', 'off'].includes(mode)) return 'never';
  return 'auto';
}

function _normalizeHostRule(raw = '') {
  let value = String(raw || '').trim().toLowerCase();
  if (!value) return '';
  if (value.includes('://')) {
    try {
      value = new URL(value).hostname.toLowerCase();
    } catch {
      return '';
    }
  }
  if (value.startsWith('*.')) value = `.${value.slice(2)}`;
  return value;
}

function _parseHostRules(raw) {
  const out = [];
  const seen = new Set();
  for (const item of _parseList(raw)) {
    const normalized = _normalizeHostRule(item);
    if (!normalized || seen.has(normalized)) continue;
    seen.add(normalized);
    out.push(normalized);
  }
  return out;
}

const KIRO_PROXY_FORCE_HOSTS = _parseHostRules(
  process.env.KIRO_PROXY_FORCE_HOSTS
  || process.env.GATEWAY_PROXY_FORCE_HOSTS
  || process.env.GATEWAY_PROXY_FORCE_DOMAINS
  || ''
);
const KIRO_PROXY_BYPASS_HOSTS = _parseHostRules(
  process.env.KIRO_PROXY_BYPASS_HOSTS
  || process.env.GATEWAY_PROXY_BYPASS_HOSTS
  || process.env.GATEWAY_PROXY_BYPASS_DOMAINS
  || ''
);

function _hostMatchesRule(host, rule) {
  const normalizedHost = String(host || '').trim().toLowerCase();
  const normalizedRule = _normalizeHostRule(rule);
  if (!normalizedHost || !normalizedRule) return false;
  if (normalizedHost === normalizedRule) return true;
  if (normalizedRule.startsWith('.')) return normalizedHost.endsWith(normalizedRule);
  return normalizedHost.endsWith(`.${normalizedRule}`);
}

function _isPrivateIpv4Host(host) {
  const text = String(host || '').trim();
  if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(text)) return false;
  const parts = text.split('.').map(v => Number.parseInt(v, 10));
  if (parts.some(v => !Number.isFinite(v) || v < 0 || v > 255)) return false;
  if (parts[0] === 10) return true;
  if (parts[0] === 127) return true;
  if (parts[0] === 192 && parts[1] === 168) return true;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  if (parts[0] === 169 && parts[1] === 254) return true;
  return false;
}

function _resolveTargetHost(targetUrl) {
  const text = String(targetUrl || '').trim();
  if (!text) return '';
  try { return new URL(text).hostname.toLowerCase(); } catch { return text.toLowerCase(); }
}

function _shouldUseProxyForTarget(targetUrl, options = {}) {
  if (options.requireProxy === true) return true;

  const mode = _normalizeRouteMode(options.routeMode || KIRO_PROXY_ROUTE_MODE);
  if (mode === 'always') return true;
  if (mode === 'never') return false;

  const host = _resolveTargetHost(targetUrl);
  if (!host) return true;

  const forceHosts = [
    ...KIRO_PROXY_FORCE_HOSTS,
    ..._parseHostRules(options.forceHosts || []),
  ];
  const bypassHosts = [
    ...KIRO_PROXY_BYPASS_HOSTS,
    ..._parseHostRules(options.bypassHosts || []),
  ];

  if (forceHosts.some(rule => _hostMatchesRule(host, rule))) return true;
  if (bypassHosts.some(rule => _hostMatchesRule(host, rule))) return false;
  if (host === 'localhost' || host === '::1' || _isPrivateIpv4Host(host)) return false;
  if (host.endsWith('.cn') || host.endsWith('.local') || host.endsWith('.lan') || host.endsWith('.internal')) return false;
  return true;
}

function _markProxyFailed(proxyUrl, err) {
  if (!proxyUrl) return;
  _proxyBackoffUntil.set(proxyUrl, Date.now() + KIRO_PROXY_RETRY_MS);
  if (err && err.message) debugLog(`proxy failed (${proxyUrl}): ${err.message}`);
}

function _markProxyHealthy(proxyUrl) {
  if (!proxyUrl) return;
  _proxyBackoffUntil.delete(proxyUrl);
}

function _isProxyInBackoff(proxyUrl) {
  if (!proxyUrl) return false;
  const until = _proxyBackoffUntil.get(proxyUrl) || 0;
  return until > Date.now();
}

function _readSavedProxyConfigUrl() {
  try {
    const cfgPath = path.join(os.homedir(), '.khyquant', 'proxy.json');
    if (!fs.existsSync(cfgPath)) return '';
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    if (!cfg || cfg.enabled !== true) return '';
    const host = String(cfg.host || '').trim();
    const port = Number.parseInt(String(cfg.port || '').trim(), 10);
    if (!host || !Number.isFinite(port) || port <= 0 || port > 65535) return '';
    const type = String(cfg.type || 'http').trim().toLowerCase();
    // This adapter currently implements HTTP CONNECT tunneling only.
    // For SOCKS-only configs, fall back to other candidates (env/local ports).
    if (type === 'socks5') return '';
    return `http://${host}:${port}`;
  } catch {
    return '';
  }
}

function _normalizeProxyCandidate(rawValue) {
  let value = String(rawValue || '').trim();
  if (!value) return '';

  // Allow "127.0.0.1:7890" style shorthand.
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(value) && /^[^/\s:]+:\d+$/.test(value)) {
    value = `http://${value}`;
  }

  try {
    const parsed = new URL(value);
    const protocol = String(parsed.protocol || '').toLowerCase();
    // Adapter currently supports HTTP CONNECT proxy only.
    if (protocol !== 'http:' && protocol !== 'https:') return '';
    return parsed.toString().replace(/\/$/, '');
  } catch {
    return '';
  }
}

function _collectProxyCandidates(_targetUrl) {
  const candidates = [];
  const seen = new Set();
  const add = (value) => {
    const v = _normalizeProxyCandidate(value);
    if (!v || seen.has(v)) return;
    seen.add(v);
    candidates.push(v);
  };

  const envKeys = ['KIRO_HTTP_PROXY', 'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY',
                    'kiro_http_proxy', 'https_proxy', 'http_proxy', 'all_proxy'];
  for (const key of envKeys) add(process.env[key]);

  if (KIRO_AUTO_PROXY) {
    // If user previously enabled proxy via `/proxy`, reuse it automatically.
    add(_readSavedProxyConfigUrl());
    // Optimistically try local Clash ports (prefer overseas route first).
    for (const port of KIRO_AUTO_PROXY_PORTS) add(`http://127.0.0.1:${port}`);
  }

  return candidates;
}

function resolveHttpProxyCandidates(targetUrl, options = {}) {
  if (!_shouldUseProxyForTarget(targetUrl, options)) return [];
  const candidates = _collectProxyCandidates(targetUrl);
  return candidates.filter(candidate => !_isProxyInBackoff(candidate));
}

function resolveHttpProxy(targetUrl, options = {}) {
  const candidates = resolveHttpProxyCandidates(targetUrl, options);
  return candidates[0] || '';
}

/**
 * Create an HTTPS CONNECT tunnel through an HTTP proxy.
 * Returns a connected socket for use as `createConnection` in https.request.
 */
function connectThroughProxy(proxyUrl, targetHost, targetPort, timeout) {
  return new Promise((resolve, reject) => {
    const proxy = new URL(proxyUrl);
    const connectReq = http.request({
      hostname: proxy.hostname,
      port: proxy.port || 7890,
      method: 'CONNECT',
      path: `${targetHost}:${targetPort}`,
      timeout,
      headers: { Host: `${targetHost}:${targetPort}` },
    });
    connectReq.on('connect', (_res, socket) => {
      if (_res.statusCode !== 200) {
        socket.destroy();
        reject(new Error(`Proxy CONNECT failed (${_res.statusCode})`));
        return;
      }
      resolve(socket);
    });
    connectReq.on('error', reject);
    connectReq.on('timeout', () => { connectReq.destroy(); reject(new Error('proxy connect timeout')); });
    connectReq.end();
  });
}

// ── Helpers: JSON fetch ──────────────────────────────────────────────────

function jsonRequest(url, { method = 'GET', body, headers = {}, timeout = 15000, requireProxy = false } = {}) {
  return new Promise(async (resolve, reject) => {
    const parsed = new URL(url);
    const isHttps = parsed.protocol === 'https:';
    const proxyCandidates = isHttps ? resolveHttpProxyCandidates(url, { requireProxy }) : [];

    const reqHeaders = sanitizeOutgoingHeaders(buildKiroHeaders({ 'Content-Type': 'application/json', ...headers }));

    const doRequest = (extraOpts = {}) => new Promise((resolveOnce, rejectOnce) => {
      const mod = isHttps ? https : http;
      const options = {
        hostname: parsed.hostname,
        port: parsed.port || (isHttps ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method,
        headers: reqHeaders,
        timeout,
        ...extraOpts,
      };

      const req = mod.request(options, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          try { resolveOnce({ status: res.statusCode, data: JSON.parse(data) }); }
          catch { resolveOnce({ status: res.statusCode, data }); }
        });
      });
      req.on('error', rejectOnce);
      req.on('timeout', () => { req.destroy(); rejectOnce(new Error('request timeout')); });
      if (body) req.write(typeof body === 'string' ? body : JSON.stringify(body));
      req.end();
    });

    try {
      if (isHttps && requireProxy && proxyCandidates.length === 0) {
        reject(new Error(`Kiro proxy required for ${parsed.hostname}, but no proxy endpoint is available`));
        return;
      }

      // Proxy-first strategy: try all proxy candidates in order, then degrade to direct.
      let lastProxyErr = null;
      if (isHttps && proxyCandidates.length > 0) {
        const targetPort = parsed.port || 443;
        for (const proxyUrl of proxyCandidates) {
          try {
            const socket = await connectThroughProxy(proxyUrl, parsed.hostname, targetPort, timeout);
            const resp = await doRequest({ socket, agent: false });
            _markProxyHealthy(proxyUrl);
            resolve(resp);
            return;
          } catch (proxyErr) {
            _markProxyFailed(proxyUrl, proxyErr);
            lastProxyErr = proxyErr;
            debugLog(`proxy candidate failed: ${proxyUrl} (${proxyErr.message})`);
          }
        }
      }
      if (isHttps && requireProxy) {
        reject(lastProxyErr || new Error(`Kiro proxy required for ${parsed.hostname}, but all proxy endpoints failed`));
        return;
      }
      const directResp = await doRequest();
      resolve(directResp);
    } catch (err) {
      reject(err);
    }
  });
}

// ── Token reading ────────────────────────────────────────────────────────

function normalizeToken(value) {
  return String(value || '').trim();
}

function hasTokenShape(value) {
  const token = normalizeToken(value);
  if (!token) return false;
  if (token.length < 20 || token.length > 4096) return false;
  if (/\s/.test(token)) return false;
  if (!/^[A-Za-z0-9._\-+/=~:]+$/.test(token)) return false;
  if (/^(null|undefined|token|access[_-]?token|bearer)$/i.test(token)) return false;
  return true;
}

function buildTokenSignature(tokenData = null) {
  if (!tokenData || !hasTokenShape(tokenData.accessToken)) return '';
  const payload = [
    normalizeToken(tokenData.accessToken),
    normalizeToken(tokenData.refreshToken),
    String(tokenData.expiresAt || ''),
    String(tokenData.profileArn || ''),
    String(tokenData.region || ''),
    String(tokenData.clientIdHash || ''),
    String(tokenData._sourcePath || ''),
  ].join('|');
  return crypto.createHash('sha1').update(payload).digest('hex');
}

function assignCachedToken(tokenData = null) {
  if (!tokenData || !hasTokenShape(tokenData.accessToken)) return null;
  const enriched = enrichWithProfile(tokenData);
  const nextSignature = buildTokenSignature(enriched);
  const tokenChanged = !!(
    _cachedTokenSignature
    && nextSignature
    && _cachedTokenSignature !== nextSignature
  );
  _cachedToken = enriched;
  _cachedTokenSignature = nextSignature;
  if (tokenChanged) {
    // Account switched or token source rotated: invalidate model+SDK cache.
    _models = [];
    _modelsFetchedAt = 0;
    _sdkClient = null;
    _sdkClientToken = null;
  }
  persistObservedToken(_cachedToken);
  return _cachedToken;
}

function firstNonEmpty(values = []) {
  for (const value of values) {
    const text = String(value ?? '').trim();
    if (text) return text;
  }
  return '';
}

function extractKiroTokenPayload(raw = {}, sourcePath = '') {
  if (!raw || typeof raw !== 'object') return null;

  const nested = [
    raw,
    raw.auth,
    raw.session,
    raw.credentials,
    raw.kiroAuth,
    raw.tokenData,
  ].filter(v => v && typeof v === 'object');

  for (const node of nested) {
    const accessToken = firstNonEmpty([
      node.accessToken,
      node.access_token,
      node.authToken,
      node.idToken,
      node.token,
      node.userJwt,
    ]);
    if (!hasTokenShape(accessToken)) continue;

    return {
      ...raw,
      ...node,
      accessToken: normalizeToken(accessToken),
      refreshToken: firstNonEmpty([node.refreshToken, node.refresh_token, raw.refreshToken, raw.refresh_token]) || null,
      expiresAt: firstNonEmpty([node.expiresAt, node.expireAt, raw.expiresAt, raw.expireAt]) || null,
      authMethod: firstNonEmpty([node.authMethod, raw.authMethod]) || null,
      provider: firstNonEmpty([node.provider, raw.provider]) || null,
      profileArn: firstNonEmpty([node.profileArn, raw.profileArn]) || null,
      region: firstNonEmpty([node.region, raw.region]) || null,
      clientIdHash: firstNonEmpty([node.clientIdHash, raw.clientIdHash]) || null,
      _sourcePath: sourcePath || raw._sourcePath || '',
    };
  }
  return null;
}

/**
 * Read Kiro token by scanning all candidate paths.
 * Returns the first valid token found (with _sourcePath annotation).
 */
function readKiroToken() {
  const candidatePaths = getKiroTokenCandidatePaths();
  debugLog('Token candidate paths:', candidatePaths);

  for (const tokenPath of candidatePaths) {
    try {
      if (!fs.existsSync(tokenPath)) {
        debugLog(`  ✗ not found: ${tokenPath}`);
        continue;
      }
      const raw = JSON.parse(fs.readFileSync(tokenPath, 'utf8'));
      const data = extractKiroTokenPayload(raw, tokenPath);
      if (data?.accessToken) {
        debugLog(`  ✓ token found: ${tokenPath}`);
        return data;
      }
      debugLog(`  ✗ no accessToken: ${tokenPath}`);
    } catch (err) {
      debugLog(`  ✗ parse error: ${tokenPath} — ${err.message}`);
    }
  }
  debugLog('  ✗ no valid token in any candidate path');
  return null;
}

function writeKiroToken(tokenData) {
  // Write to the first writable SSO cache dir (handles Windows path mismatch)
  for (const dir of _getSsoCacheDirs()) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, KIRO_TOKEN_FILE), JSON.stringify(tokenData, null, 2));
      return;
    } catch { /* try next */ }
  }
}

function readKiroProfile() {
  for (const p of _getKiroProfilePaths()) {
    try {
      if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch { /* skip */ }
  }
  return null;
}

function readClientRegistration(clientIdHash) {
  if (!clientIdHash) return null;
  // Scan all SSO cache dirs (handles os.homedir vs %USERPROFILE% mismatch)
  for (const dir of _getSsoCacheDirs()) {
    const filePath = path.join(dir, `${clientIdHash}.json`);
    try {
      if (fs.existsSync(filePath)) return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch { /* skip */ }
  }
  return null;
}

function isTokenExpired(tokenData) {
  if (!tokenData?.expiresAt) return true;
  return new Date(tokenData.expiresAt).getTime() < Date.now() + REFRESH_BUFFER_MS;
}

function enrichWithProfile(tokenData) {
  if (!tokenData.profileArn) {
    const profile = readKiroProfile();
    if (profile?.arn) tokenData.profileArn = profile.arn;
  }
  return tokenData;
}

function toPoolTokenShape(poolToken = null) {
  if (!poolToken || !hasTokenShape(poolToken.accessToken)) return null;
  const authData = poolToken.authData || {};
  return {
    accessToken: normalizeToken(poolToken.accessToken),
    refreshToken: poolToken.refreshToken ? String(poolToken.refreshToken).trim() : null,
    expiresAt: authData.expiresAt || poolToken.expiresAt || null,
    authMethod: authData.authMethod || null,
    provider: authData.provider || null,
    profileArn: authData.profileArn || null,
    region: authData.region || null,
    clientIdHash: authData.clientIdHash || null,
    _sourcePath: poolToken.sourcePath || '',
  };
}

async function getPoolActiveToken() {
  try {
    const pool = require('../../accountPool');
    await pool.init();
    const token = await pool.getActiveToken(ACCOUNT_POOL_TYPE);
    return toPoolTokenShape(token);
  } catch {
    return null;
  }
}

function persistObservedToken(tokenData = null) {
  if (!tokenData || !tokenData.accessToken) return;
  Promise.resolve().then(async () => {
    try {
      const pool = require('../../accountPool');
      await pool.init();
      await pool.saveObservedToken(ACCOUNT_POOL_TYPE, {
        accessToken: tokenData.accessToken,
        refreshToken: tokenData.refreshToken || null,
        sourcePath: tokenData._sourcePath || path.join(_getSsoCacheDirs()[0], KIRO_TOKEN_FILE),
        label: tokenData.profileArn ? `kiro:${tokenData.profileArn}` : 'kiro',
        authData: {
          authMethod: tokenData.authMethod || null,
          provider: tokenData.provider || null,
          profileArn: tokenData.profileArn || null,
          region: tokenData.region || null,
          clientIdHash: tokenData.clientIdHash || null,
          expiresAt: tokenData.expiresAt || null,
        },
      }, { activateIfNone: true });
      await pool.autoImportObservedCredentials(ACCOUNT_POOL_TYPE);
    } catch { /* ignore */ }
  });
}

function resolveKiroLaunchCandidate() {
  let installPath = null;
  try {
    const { findInstallation } = require('./ideDetector');
    installPath = findInstallation('kiro');
  } catch {
    installPath = null;
  }
  if (!installPath) return null;
  try {
    if (fs.existsSync(installPath) && fs.statSync(installPath).isFile()) {
      return installPath;
    }
  } catch { /* ignore */ }

  if (process.platform === 'win32') {
    const candidates = [
      path.join(installPath, 'Kiro.exe'),
      path.join(installPath, 'kiro.exe'),
    ];
    for (const candidate of candidates) {
      try {
        if (fs.existsSync(candidate)) return candidate;
      } catch { /* ignore */ }
    }
  } else if (process.platform === 'darwin') {
    if (installPath.endsWith('.app')) return installPath;
    const appCandidate = `${installPath}.app`;
    try {
      if (fs.existsSync(appCandidate)) return appCandidate;
    } catch { /* ignore */ }
  } else {
    const candidates = [
      path.join(installPath, 'kiro'),
      path.join(installPath, 'Kiro'),
      path.join(installPath, 'bin', 'kiro'),
      path.join(installPath, 'kiro.AppImage'),
    ];
    for (const candidate of candidates) {
      try {
        if (fs.existsSync(candidate)) return candidate;
      } catch { /* ignore */ }
    }
  }
  return installPath;
}

function maybeOpenKiroLogin(reason = '', options = {}) {
  const autoOpenLogin = options.autoOpenLogin === true;
  if (!autoOpenLogin || !KIRO_AUTO_OPEN_LOGIN) return false;

  const now = Date.now();
  if (now - _lastLoginPromptAt < KIRO_LOGIN_COOLDOWN_MS) return false;
  _lastLoginPromptAt = now;

  try {
    const { openDefault, spawnGuiApp } = require('../../../tools/platformUtils');
    const candidate = resolveKiroLaunchCandidate();
    if (candidate) {
      if (process.platform === 'darwin' && candidate.endsWith('.app')) openDefault(candidate);
      else spawnGuiApp(candidate);
      console.warn(`[kiroAdapter] Kiro login required (${reason || 'no token'}), opened Kiro IDE for login`);
      return true;
    }
    openDefault(KIRO_LOGIN_URL);
    console.warn(`[kiroAdapter] Kiro login required (${reason || 'no token'}), opened ${KIRO_LOGIN_URL}`);
    return true;
  } catch (err) {
    debugLog(`failed to open Kiro login entry: ${err.message}`);
    return false;
  }
}

// ── Token refresh ────────────────────────────────────────────────────────

async function refreshSocialToken(tokenData) {
  const res = await jsonRequest(SOCIAL_REFRESH_URL, {
    method: 'POST',
    body: { refreshToken: tokenData.refreshToken },
    timeout: 15000,
  });
  if (res.status !== 200) throw new Error(`Social token refresh failed (${res.status})`);
  const data = res.data;
  const expiresAt = new Date(Date.now() + (data.expiresIn || 3600) * 1000).toISOString();
  return {
    ...tokenData,
    accessToken: data.accessToken,
    ...(data.refreshToken && { refreshToken: data.refreshToken }),
    ...(data.profileArn && { profileArn: data.profileArn }),
    expiresAt,
  };
}

async function refreshIdCToken(tokenData) {
  const clientReg = readClientRegistration(tokenData.clientIdHash);
  if (!clientReg?.clientId || !clientReg?.clientSecret) {
    throw new Error('IdC refresh failed: no valid client registration. Please re-login in Kiro.');
  }
  const region = tokenData.region || 'us-east-1';
  const endpoint = `https://oidc.${region}.amazonaws.com/token`;

  // AWS OIDC uses both camelCase and snake_case depending on SDK version;
  // send both so the endpoint accepts whichever format it expects.
  const body = {
    clientId: clientReg.clientId,
    clientSecret: clientReg.clientSecret,
    grantType: 'refresh_token',
    grant_type: 'refresh_token',
    refreshToken: tokenData.refreshToken,
    refresh_token: tokenData.refreshToken,
  };

  const res = await jsonRequest(endpoint, {
    method: 'POST',
    body,
    timeout: 15000,
  });
  if (res.status !== 200) {
    const detail = (() => {
      if (res.data == null) return '';
      if (typeof res.data === 'string') return res.data.slice(0, 300);
      try { return JSON.stringify(res.data).slice(0, 300); } catch { return ''; }
    })();
    debugLog(`IdC refresh failed (${res.status}): ${detail}`);
    throw new Error(`IdC token refresh failed (${res.status})${detail ? `: ${detail}` : ''}`);
  }
  const data = res.data;
  const expiresAt = new Date(Date.now() + (data.expiresIn || data.expires_in || 3600) * 1000).toISOString();
  return {
    ...tokenData,
    accessToken: data.accessToken || data.access_token,
    ...(data.refreshToken || data.refresh_token ? { refreshToken: data.refreshToken || data.refresh_token } : {}),
    expiresAt,
  };
}

async function refreshToken(tokenData) {
  const method = tokenData.authMethod;
  if (method === 'social' || method === 'Social') return refreshSocialToken(tokenData);
  if (method === 'IdC' || method === 'idc') return refreshIdCToken(tokenData);
  throw new Error(`Unknown auth method: ${method}`);
}

/**
 * Get a valid access token (memory → disk → refresh).
 */
async function getAccessToken(options = {}) {
  // Probe local token periodically (every 30s) instead of every call,
  // to detect account switches without excessive disk I/O.
  const now = Date.now();
  const PROBE_INTERVAL_MS = 30000;
  let localToken;
  if (!_cachedToken || !_lastTokenProbeMs || (now - _lastTokenProbeMs) >= PROBE_INTERVAL_MS) {
    localToken = readKiroToken();
    _lastTokenProbeMs = now;
  }
  const localTokenSignature = localToken ? buildTokenSignature(localToken) : null;

  if (_cachedToken && !isTokenExpired(_cachedToken)) {
    if (localTokenSignature && localTokenSignature !== _cachedTokenSignature) {
      debugLog('Detected Kiro account/token switch on disk — refreshing cache');
      return assignCachedToken(localToken);
    }
    return _cachedToken;
  }

  const poolToken = await getPoolActiveToken();
  const poolValid = !!(poolToken?.accessToken && hasTokenShape(poolToken.accessToken));
  const localValid = !!(localToken?.accessToken && hasTokenShape(localToken.accessToken));

  let tokenData = poolValid ? poolToken : null;
  if (localValid) {
    if (!tokenData) tokenData = localToken;
    else if (isTokenExpired(tokenData) && !isTokenExpired(localToken)) tokenData = localToken;
  }
  const fallbackToken = tokenData === poolToken ? localToken : poolToken;

  if (!tokenData?.accessToken || !hasTokenShape(tokenData.accessToken)) {
    maybeOpenKiroLogin('token_not_found', options);
    throw new Error('No Kiro token found. Please login in Kiro IDE first.');
  }

  if (!isTokenExpired(tokenData)) {
    return assignCachedToken(tokenData);
  }

  // If token is only in the pre-refresh buffer (not truly expired), and we're
  // in a refresh backoff period, just use the existing token.
  const isTrulyExpired = !tokenData.expiresAt || new Date(tokenData.expiresAt).getTime() < Date.now();
  if (!isTrulyExpired && Date.now() < _refreshBackoffUntil) {
    debugLog('Token near expiry but in refresh backoff period — using existing token');
    return assignCachedToken(tokenData);
  }

  if (!tokenData.refreshToken) {
    maybeOpenKiroLogin('token_expired_no_refresh', options);
    throw new Error('Kiro token expired, no refreshToken. Please re-login in Kiro.');
  }

  // Deduplicate concurrent refreshes
  if (_refreshPromise) return _refreshPromise;

  _refreshPromise = (async () => {
    try {
      const newToken = await refreshToken(tokenData);
      const enriched = enrichWithProfile(newToken);
      writeKiroToken(enriched);
      return assignCachedToken(enriched);
    } catch (err) {
      // Set refresh backoff to avoid hammering on every request (60s cooldown)
      _refreshBackoffUntil = Date.now() + 60_000;
      // If old token not fully expired (just within buffer), use it
      if (tokenData.expiresAt && new Date(tokenData.expiresAt) > new Date()) {
        console.warn(`[kiroAdapter] Token refresh failed (${err.message}), using existing token until ${tokenData.expiresAt}`);
        return assignCachedToken(tokenData);
      }
      if (fallbackToken?.accessToken && hasTokenShape(fallbackToken.accessToken) && !isTokenExpired(fallbackToken)) {
        console.warn('[kiroAdapter] Token refresh failed, falling back to alternate token source');
        return assignCachedToken(fallbackToken);
      }
      maybeOpenKiroLogin('token_refresh_failed', options);
      throw err;
    } finally {
      _refreshPromise = null;
    }
  })();

  return _refreshPromise;
}

// ── Region helpers ───────────────────────────────────────────────────────

function regionFromArn(arn) {
  if (!arn) return null;
  const parts = arn.split(':');
  return parts.length >= 4 ? parts[3] : null;
}

function endpointForRegion(region) {
  if (REGION_ENDPOINTS[region]) return REGION_ENDPOINTS[region];
  if (REGION_ENDPOINTS_CN[region]) return REGION_ENDPOINTS_CN[region];
  if (/^cn-/i.test(String(region || ''))) return `https://q.${region}.amazonaws.com.cn`;
  return `https://q.${region}.amazonaws.com`;
}

// buildUserAgent is now delegated to _fingerprint.js (buildKiroUserAgent)
// which uses a rotating device ID instead of real os.hostname().

// ── Model listing (HTTP, no SDK) ─────────────────────────────────────────

/**
 * Fetch models via kiro-proxy's /v1/models endpoint.
 * Returns same shape as fetchModelsDirect: { models, defaultModel }.
 */
async function fetchModelsViaProxy() {
  if (!KIRO_PROXY_URL) return null;
  try {
    const url = `${KIRO_PROXY_URL}/v1/models`;
    const res = await jsonRequest(url, { timeout: 12000 });
    if (res.status !== 200 || !res.data) return null;
    const data = res.data;
    const rawModels = Array.isArray(data.data) ? data.data : Array.isArray(data.models) ? data.models : [];
    if (rawModels.length === 0) return null;
    const models = rawModels.map(m => ({
      modelId: m.id || m.modelId || '',
      modelName: m.name || m.modelName || m.id || '',
      description: m.description || '',
    })).filter(m => m.modelId);
    const defaultModel = rawModels.find(m => m.is_default) ? { modelId: rawModels.find(m => m.is_default).id } : null;
    return { models, defaultModel };
  } catch {
    return null;
  }
}

/**
 * Fetch models directly from AWS Q Developer ListAvailableModels API.
 */
async function fetchModelsDirect(tokenData) {
  await applyJitter(); // anti-fingerprint timing jitter
  const arnRegion = regionFromArn(tokenData.profileArn);
  const region = arnRegion || DEFAULT_REGION;
  const endpoint = endpointForRegion(region);

  const params = new URLSearchParams({ origin: 'AI_EDITOR' });
  if (tokenData.profileArn) params.set('profileArn', tokenData.profileArn);

  const headers = {
    'Authorization': `Bearer ${tokenData.accessToken}`,
    'User-Agent': buildKiroUserAgent(),
    'x-amzn-codewhisperer-optout': 'true',
  };
  if (tokenData.authMethod === 'external_idp') headers['TokenType'] = 'EXTERNAL_IDP';
  if (tokenData.provider === 'Internal') headers['redirect-for-internal'] = 'true';

  const allModels = [];
  let defaultModel = null;
  let nextToken;

  do {
    if (nextToken) params.set('nextToken', nextToken);
    const url = `${endpoint}/ListAvailableModels?${params}`;
    const res = await jsonRequest(url, {
      headers,
      timeout: 15000,
      requireProxy: KIRO_DISCOVERY_REQUIRE_PROXY,
    });
    if (res.status !== 200) throw new Error(`ListAvailableModels failed (${res.status})`);
    allModels.push(...(res.data.models || []));
    if (res.data.defaultModel && !defaultModel) defaultModel = res.data.defaultModel;
    nextToken = res.data.nextToken;
  } while (nextToken);

  return { models: allModels, defaultModel };
}

/**
 * Fetch models: try kiro-proxy first (if configured), then direct API.
 */
async function fetchModels(tokenData) {
  // Try kiro-proxy first (works even without local token on Windows)
  const proxyResult = await fetchModelsViaProxy();
  if (proxyResult && proxyResult.models.length > 0) return proxyResult;

  // Fall back to direct AWS API call
  return fetchModelsDirect(tokenData);
}

// ── SDK-based chat (lazy-load ESM) ───────────────────────────────────────

async function getCWModule() {
  if (_cwModule) return _cwModule;
  // @aws/codewhisperer-streaming-client is ESM-only, use dynamic import
  try {
    _cwModule = await import('@aws/codewhisperer-streaming-client');
  } catch (err) {
    throw new Error(
      'Kiro SDK not installed. Run: cd backend && npm install @aws/codewhisperer-streaming-client'
    );
  }
  return _cwModule;
}

function convertMessagesToConversation(messages, { modelId, system } = {}) {
  const history = [];
  const buildCtx = (extra = {}) => ({ modelId: modelId || undefined, editorState: {}, ...extra });

  // Inject system prompt as first user/assistant pair
  if (system) {
    const sysText = typeof system === 'string' ? system : system;
    if (sysText) {
      history.push({
        userInputMessage: {
          content: sysText,
          origin: 'AI_EDITOR',
          userInputMessageContext: buildCtx(),
        },
      });
      history.push({ assistantResponseMessage: { content: 'OK' } });
    }
  }

  for (const msg of messages) {
    if (msg.role === 'user') {
      const text = typeof msg.content === 'string' ? msg.content : '';
      history.push({
        userInputMessage: {
          content: text,
          origin: 'AI_EDITOR',
          userInputMessageContext: buildCtx(),
        },
      });
    } else if (msg.role === 'assistant') {
      const text = typeof msg.content === 'string' ? msg.content : '';
      history.push({ assistantResponseMessage: { content: text } });
    }
  }

  // Ensure ends with user message
  const last = history.at(-1);
  if (last?.assistantResponseMessage) {
    history.push({
      userInputMessage: {
        content: 'Continue.',
        origin: 'AI_EDITOR',
        userInputMessageContext: buildCtx(),
      },
    });
  }

  return {
    conversationId: crypto.randomUUID(),
    currentMessage: history.at(-1),
    history: history.slice(0, -1),
    chatTriggerType: 'MANUAL',
  };
}

/**
 * Build an HTTPS agent that tunnels through a proxy (if configured).
 * Uses the built-in http.Agent + CONNECT tunnel approach.
 */
function buildProxyHttpsAgent() {
  const proxyUrl = resolveHttpProxy('https://q.amazonaws.com');
  if (!proxyUrl) return undefined;
  try {
    // Try to use https-proxy-agent if available (most reliable)
    const { HttpsProxyAgent } = require('https-proxy-agent');
    return new HttpsProxyAgent(proxyUrl);
  } catch {
    // Package not installed — no SDK proxy support
    return undefined;
  }
}

async function createSDKClient(tokenData) {
  // Reuse cached client if token hasn't changed
  if (_sdkClient && _sdkClientToken === tokenData.accessToken) return _sdkClient;

  const { CodeWhispererStreaming } = await getCWModule();
  const arnRegion = regionFromArn(tokenData.profileArn);
  const finalRegion = arnRegion || DEFAULT_REGION;
  const finalEndpoint = endpointForRegion(finalRegion);

  const clientOpts = {
    region: finalRegion,
    endpoint: finalEndpoint,
    token: { token: tokenData.accessToken },
    customUserAgent: buildKiroUserAgent(),
  };

  // Inject proxy agent for SDK HTTP requests if configured
  const proxyAgent = buildProxyHttpsAgent();
  if (proxyAgent) {
    try {
      const { NodeHttpHandler } = await import('@smithy/node-http-handler');
      clientOpts.requestHandler = new NodeHttpHandler({ httpsAgent: proxyAgent });
    } catch {
      // @smithy/node-http-handler not available, SDK will use default handler
    }
  }

  const client = new CodeWhispererStreaming(clientOpts);

  // Add required headers via middleware + strip IP-identifying headers
  // (matches kiro-proxy: separate middleware per header for proper stacking)
  client.middlewareStack.add(
    (next) => async (args) => {
      args.request.headers = sanitizeOutgoingHeaders(buildKiroHeaders({
        ...args.request.headers,
        'x-amzn-codewhisperer-optout': 'true',
      }));
      return next(args);
    },
    { step: 'build', name: 'optOutHeader' }
  );
  client.middlewareStack.add(
    (next) => async (args) => {
      args.request.headers = {
        ...args.request.headers,
        'x-amzn-kiro-agent-mode': 'vibe',
      };
      return next(args);
    },
    { step: 'build', name: 'agentModeHeader' }
  );
  if (tokenData.authMethod === 'external_idp') {
    client.middlewareStack.add(
      (next) => async (args) => {
        args.request.headers = { ...args.request.headers, TokenType: 'EXTERNAL_IDP' };
        return next(args);
      },
      { step: 'build', name: 'tokenTypeHeader' }
    );
  }
  if (tokenData.provider === 'Internal') {
    client.middlewareStack.add(
      (next) => async (args) => {
        args.request.headers = { ...args.request.headers, 'redirect-for-internal': 'true' };
        return next(args);
      },
      { step: 'build', name: 'redirectForInternal' }
    );
  }

  _sdkClient = client;
  _sdkClientToken = tokenData.accessToken;
  return client;
}

// ── Adapter interface ────────────────────────────────────────────────────

/**
 * Detect if Kiro auth token exists.
 * Also checks for Kiro installation via ideDetector and kiro-proxy availability.
 */
function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  _installDetected = false;

  // Kiro-proxy configured — optimistic available
  if (KIRO_PROXY_URL) {
    _available = true;
    return true;
  }

  // Check token first
  const tokenData = readKiroToken();
  if (tokenData?.accessToken) {
    _available = true;
    return true;
  }

  // Fallback: check if Kiro is installed (token may appear after login)
  try {
    const { findInstallation, findDataPath } = require('./ideDetector');
    const installed = findInstallation('kiro') || findDataPath('kiro');
    _installDetected = !!installed;
  } catch {
    _installDetected = false;
  }

  _available = false;

  // Background: try pool for token (async, non-blocking)
  if (!_available) {
    getPoolActiveToken().then(poolToken => {
      if (poolToken?.accessToken && hasTokenShape(poolToken.accessToken)) {
        debugLog('Pool token found in background check — marking available');
        _cachedToken = poolToken;
        _available = true;
      }
    }).catch(() => {});
  }

  return _available;
}

/**
 * Async detection with token validation.
 * If KIRO_PROXY_URL is set, validate proxy health instead of local token.
 * Falls back to disk-based token check if getAccessToken() fails (e.g.
 * accountPool not ready during early init, or refresh returning 400).
 */
async function detectAsync() {
  if (KIRO_PROXY_URL) {
    try {
      const res = await jsonRequest(`${KIRO_PROXY_URL}/health`, { timeout: 8000 });
      _available = res.status === 200 && res.data?.status !== 'error';
      return _available;
    } catch {
      // Proxy unreachable, fall through to local token check
    }
  }
  try {
    const tokenData = await getAccessToken({ autoOpenLogin: false });
    _available = !!(tokenData?.accessToken);
    return _available;
  } catch (err) {
    debugLog(`detectAsync getAccessToken failed: ${err.message}, falling back to file check`);
    // Fallback: disk token that is structurally valid and not fully expired
    try {
      const localToken = readKiroToken();
      if (localToken?.accessToken && hasTokenShape(localToken.accessToken)) {
        const reallyExpired = localToken.expiresAt
          ? new Date(localToken.expiresAt) < new Date()
          : false;
        if (!reallyExpired) {
          assignCachedToken(localToken);
          _available = true;
          return true;
        }
        debugLog('detectAsync: disk token found but expired');
      }
    } catch { /* ignore */ }
    _available = false;
    return false;
  }
}

/**
 * List available Kiro models.
 * Tries kiro-proxy first (if configured), then direct API.
 */
async function listModels() {
  // Return cache if fresh
  if (_models.length > 0 && (Date.now() - _modelsFetchedAt) < MODEL_CACHE_TTL) {
    return _models;
  }

  let tokenData = null;
  try {
    tokenData = await getAccessToken({ autoOpenLogin: true });
  } catch {
    // No local token — if proxy is configured, proceed without it
    if (!KIRO_PROXY_URL) throw new Error('No Kiro token found. Please login in Kiro IDE first.');
  }
  let fetched;
  try {
    fetched = await fetchModels(tokenData || {});
  } catch (err) {
    if (KIRO_DISCOVERY_REQUIRE_PROXY) {
      const reason = err && err.message ? err.message : 'unknown error';
      throw new Error(`Kiro 完整模型发现需要代理，请先开启 Clash/VPN 后重试 (${reason})`);
    }
    throw err;
  }
  const { models, defaultModel } = fetched;
  _models = models.map(m => ({
    id: m.modelId,
    name: m.modelName || m.modelId,
    provider: 'kiro',
    description: m.description || '',
    isDefault: defaultModel?.modelId === m.modelId,
    discoverySource: KIRO_PROXY_URL ? 'proxy' : 'remote',
  }));

  // Inject Claude models that Kiro IDE shows but ListAvailableModels omits.
  if (KIRO_INJECT_CLAUDE) {
    const existingIds = new Set(_models.map(m => m.id.toLowerCase()));
    for (const cm of KIRO_INJECTED_CLAUDE_MODELS) {
      if (existingIds.has(cm.id.toLowerCase())) continue;
      _models.push({
        id: cm.id,
        name: `${cm.name} (${cm.credit})`,
        provider: 'kiro',
        description: `Injected — ${cm.tier} tier. Kiro IDE shows this model but API may not list it.`,
        isDefault: false,
        discoverySource: 'injected',
      });
    }
  }
  _modelsFetchedAt = Date.now();
  return _models;
}

/**
 * Generate via kiro-proxy (Anthropic-compatible /v1/messages endpoint).
 */
async function generateViaProxy(prompt, options = {}) {
  if (!KIRO_PROXY_URL) return null;
  const url = `${KIRO_PROXY_URL}/v1/chat/completions`;
  let messages = (options.messages && options.messages.length > 0)
    ? options.messages
    : [{ role: 'user', content: prompt }];

  // Attach images to messages (OpenAI vision format)
  if (Array.isArray(options.images) && options.images.length > 0) {
    try {
      const { attachImagesToOpenAIMessages } = require('./_imageCompat');
      messages = attachImagesToOpenAIMessages(messages, options.images);
    } catch { /* _imageCompat not available */ }
  }

  const body = {
    model: options.model || undefined,
    messages,
    stream: false,
  };
  try {
    const res = await jsonRequest(url, {
      method: 'POST',
      body,
      headers: { 'Content-Type': 'application/json' },
      timeout: TIMEOUT_MS,
    });
    if (res.status !== 200 || !res.data) return null;
    const text = res.data?.choices?.[0]?.message?.content || '';
    if (!text) return null;
    const model = res.data?.model || options.model || 'kiro-proxy';
    return {
      success: true,
      content: text.trim(),
      provider: `Kiro Proxy (${model})`,
      adapter: 'kiro',
      model,
      attempts: [{ provider: 'Kiro(proxy)', success: true }],
    };
  } catch {
    return null;
  }
}

/**
 * Generate a response using Kiro's Q Developer API.
 * Includes timeout protection and full event handling.
 * Falls back to kiro-proxy if SDK unavailable.
 * When images are present and proxy is unavailable, signals _visionFallback
 * so the gateway can route to a vision-capable adapter.
 */
async function generate(prompt, options = {}) {
  const hasVisionInput = Array.isArray(options.images) && options.images.length > 0;

  // Try kiro-proxy first when configured (proxy supports images via OpenAI vision format)
  if (KIRO_PROXY_URL) {
    const proxyResult = await generateViaProxy(prompt, options);
    if (proxyResult) return proxyResult;
  }

  // Q Developer SDK 不支持图像 — 如果有图像且 proxy 也失败，请求视觉回退
  if (hasVisionInput) {
    return {
      success: false,
      _visionFallback: true,
      content: '',
      provider: 'Kiro',
      adapter: 'kiro',
      error: 'Kiro Q Developer SDK 不支持图像识别，请求视觉回退到其他适配器',
      _originalPrompt: prompt,
      _originalOptions: options,
    };
  }

  try {
    // applyJitter removed here — already called in fetchModelsDirect()
    const tokenData = await getAccessToken({ autoOpenLogin: true });
    const client = await createSDKClient(tokenData);
    const { GenerateAssistantResponseCommand } = await getCWModule();

    // Build messages: prefer structured messages from options, fall back to raw prompt
    let messages;
    if (options.messages && options.messages.length > 0) {
      messages = options.messages;
    } else {
      messages = [{ role: 'user', content: prompt }];
    }
    const conversationState = convertMessagesToConversation(messages, {
      modelId: options.model,
      system: options.system,
    });

    const command = new GenerateAssistantResponseCommand({
      conversationState,
      profileArn: tokenData.profileArn,
    });

    // Wrap in timeout to prevent indefinite hangs
    const sendWithTimeout = Promise.race([
      client.send(command),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Kiro request timeout (${TIMEOUT_MS / 1000}s)`)), TIMEOUT_MS)
      ),
    ]);

    const response = await sendWithTimeout;
    if (!response.generateAssistantResponseResponse) {
      throw new Error('Empty response from Q Developer');
    }

    // Collect streaming response — consume ALL event types
    let content = '';
    let usedModelId = null;
    const onChunk = options.onChunk || (() => {});

    try {
      for await (const event of response.generateAssistantResponseResponse) {
        // Text content
        if (event.assistantResponseEvent?.content) {
          const text = event.assistantResponseEvent.content;
          content += text;
          if (event.assistantResponseEvent.modelId) {
            usedModelId = event.assistantResponseEvent.modelId;
          }
          onChunk({ type: 'text', text });
        }

        // Thinking/reasoning content
        if (event.reasoningContentEvent?.text) {
          onChunk({ type: 'thinking', text: event.reasoningContentEvent.text });
        }

        // Metering event (must consume to advance stream)
        if (event.meteringEvent) { /* consumed */ }

        // Code reference event
        if (event.codeReferenceEvent) { /* consumed */ }

        // Context usage event
        if (event.contextUsageEvent) { /* consumed */ }

        // Token usage metadata
        if (event.metadataEvent?.tokenUsage) { /* consumed */ }

        // Invalid state (error from Q Developer)
        if (event.invalidStateEvent) {
          const reason = event.invalidStateEvent.reason || 'unknown';
          const message = event.invalidStateEvent.message || '';
          throw new Error(`Q Developer error: ${reason} — ${message}`);
        }

        // Supplementary links
        if (event.supplementaryWebLinksEvent) { /* consumed */ }

        // Tool use events
        if (event.toolUseEvent) { /* consumed — tool-use not used in CLI mode */ }
      }
    } catch (streamErr) {
      // If stream interrupted but we have partial content, return what we got
      if (content.trim()) {
        const modelDisplay = usedModelId || options.model || 'default';
        return {
          success: true,
          content: content.trim(),
          provider: `Kiro (${modelDisplay})`,
          adapter: 'kiro',
          model: modelDisplay,
          attempts: [{ provider: 'Kiro', success: true, warning: 'stream_interrupted' }],
        };
      }
      throw streamErr;
    }

    const modelDisplay = usedModelId || options.model || 'default';

    return {
      success: true,
      content: content.trim(),
      provider: `Kiro (${modelDisplay})`,
      adapter: 'kiro',
      model: modelDisplay,
      attempts: [{ provider: 'Kiro', success: true }],
    };
  } catch (err) {
    // Invalidate cached client on auth errors
    if (err.message?.includes('401') || err.message?.includes('403') || err.message?.includes('expired')) {
      _sdkClient = null;
      _sdkClientToken = null;
      _cachedToken = null;
    }
    return {
      success: false,
      content: '',
      provider: 'Kiro',
      adapter: 'kiro',
      error: err.message,
      attempts: [{ provider: 'Kiro', success: false, error: err.message }],
    };
  }
}

/**
 * Get adapter status.
 */
function getStatus() {
  detect();
  let detail = '';
  if (_available) {
    detail = (KIRO_PROXY_URL ? `Proxy: ${KIRO_PROXY_URL}` : 'Token 有效') + (_models.length ? ` (${_models.length} 个模型)` : '');
    if (KIRO_DISCOVERY_REQUIRE_PROXY && resolveHttpProxyCandidates('https://q.us-east-1.amazonaws.com', { requireProxy: true }).length === 0) {
      detail += '（完整模型发现需要代理，当前未检测到本地代理）';
    }
  } else if (_installDetected) {
    detail = '检测到 Kiro 已安装，但未检测到登录 token — 请先在 Kiro IDE 登录';
    if (!KIRO_PROXY_URL) {
      detail += ' 或设置 KIRO_PROXY_URL';
    }
  } else {
    detail = '未检测到 Kiro token — 请先登录 Kiro IDE 或设置 KIRO_PROXY_URL';
  }
  return {
    name: 'Kiro IDE',
    type: 'kiro',
    available: _available,
    proxyUrl: KIRO_PROXY_URL || null,
    detail,
    refreshModels: listModels,
  };
}

/**
 * Manual refresh — clears all cached state after account switch,
 * environment cleanup, or machine code update.
 * Call this from CLI `khy gateway refresh kiro` or after account change.
 */
function manualRefresh() {
  debugLog('Manual refresh triggered — clearing all cached state');
  _cachedToken = null;
  _cachedTokenSignature = '';
  _available = null;
  _installDetected = false;
  _models = [];
  _sdkClient = null;
  _sdkClientToken = null;
  _refreshPromise = null;
  _lastLoginPromptAt = 0;
  resetFingerprintSession(); // new session → new UA version
}

function destroy() {
  _cachedToken = null;
  _cachedTokenSignature = '';
  _available = null;
  _installDetected = false;
  _models = [];
  _cwModule = null;
  _sdkClient = null;
  _sdkClientToken = null;
  _lastLoginPromptAt = 0;
  resetFingerprintSession();
}

// ── Proxy change listener (registered after state vars are declared) ────
try {
  const { proxyEvents } = require('../../proxyConfigService');
  proxyEvents.on('proxy-changed', () => {
    _models = [];
    _modelsFetchedAt = 0;
    _refreshBackoffUntil = 0;
  });
} catch { /* proxyConfigService may not be loaded yet */ }

module.exports = {
  detect, detectAsync, listModels, generate, getStatus, destroy,
  getAccessToken, createSDKClient, getCWModule,
  manualRefresh, getKiroTokenCandidatePaths,
};
