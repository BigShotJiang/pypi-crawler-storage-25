/**
 * Base Adapter — shared base class for AI gateway adapters.
 * @pattern Template Method
 *
 * Provides standardized response formatting, image handling, vision
 * fallback routing, and common utilities. Subclasses override hooks
 * (_doDetect, _doGenerate) while the base orchestrates cross-cutting
 * concerns like image normalization and capability-based routing.
 *
 * Duck-typing contract (what aiGateway.js expects):
 *   - detect([forceRefresh]) → boolean
 *   - generate(prompt, options) → { success, content, provider, model?, tokenUsage? }
 *   - name (string property)
 */

const {
  normalizeImages,
  toOpenAIVisionBlocks,
  toAnthropicImageBlocks,
  toOllamaBase64Images,
  toCodexInputImages,
  toGoogleInlineData,
  attachImagesToOpenAIMessages,
} = require('./_imageCompat');

class BaseAdapter {
  /**
   * @param {object} config
   * @param {string} config.name - Adapter display name
   * @param {string} config.type - Adapter type (e.g., 'ide', 'api', 'local', 'relay')
   * @param {number} [config.priority=99] - Lower = higher priority in cascade
   * @param {boolean} [config.supportsVision=false] - Whether this adapter natively supports images
   * @param {string} [config.imageFormat='openai'] - Target image format: 'openai' | 'anthropic' | 'ollama' | 'codex' | 'google'
   */
  constructor({ name, type, priority, supportsVision, imageFormat } = {}) {
    if (!name) throw new Error('BaseAdapter: name is required');
    this.name = name;
    this.type = type || 'unknown';
    this.priority = priority || 99;
    this._available = false;
    this._lastCheck = 0;
    this._cacheTTL = 30000; // 30s detection cache
    this.activeModel = null;
    this.supportsVision = supportsVision || false;
    this.imageFormat = imageFormat || 'openai';
  }

  /**
   * Detect whether this adapter is available.
   * Subclasses MUST override this method.
   *
   * @param {boolean} [forceRefresh=false] - Bypass cache
   * @returns {boolean}
   */
  detect(forceRefresh = false) {
    // Use cached value if fresh enough
    if (!forceRefresh && Date.now() - this._lastCheck < this._cacheTTL) {
      return this._available;
    }

    this._available = this._doDetect();
    this._lastCheck = Date.now();
    return this._available;
  }

  /**
   * Internal detection logic. Override in subclasses.
   * @returns {boolean}
   */
  _doDetect() {
    return false;
  }

  /**
   * Generate a response from the AI model.
   * Subclasses MUST override this method.
   *
   * @param {string} prompt - The prompt/conversation text
   * @param {object} [options] - Generation options
   * @param {number} [options.temperature]
   * @param {number} [options.maxTokens]
   * @param {function} [options.onChunk] - Streaming callback
   * @param {string} [options.system] - System prompt
   * @param {Array} [options.messages] - Structured messages
   * @returns {Promise<{ success: boolean, content?: string, error?: string, provider?: string, model?: string, tokenUsage?: object }>}
   */
  async generate(prompt, options = {}) {
    throw new Error(`${this.name}: generate() not implemented`);
  }

  /**
   * List available models (optional, not all adapters support this).
   * @returns {Promise<Array<{id: string, name: string}>>}
   */
  async listModels() {
    return [];
  }

  /**
   * Format a successful response.
   *
   * @param {string} content - Response text
   * @param {object} [meta] - Additional metadata
   * @returns {{ success: true, content, provider, model?, tokenUsage?, adapter? }}
   */
  _successResponse(content, meta = {}) {
    return {
      success: true,
      content,
      provider: this.name,
      adapter: this.name,
      model: meta.model || this.activeModel || undefined,
      tokenUsage: meta.tokenUsage || undefined,
      ...meta,
    };
  }

  /**
   * Format a failure response.
   *
   * @param {string|Error} error - Error message or Error object
   * @param {object} [meta] - Additional metadata
   * @returns {{ success: false, error, provider, statusCode? }}
   */
  _failureResponse(error, meta = {}) {
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
      provider: this.name,
      adapter: this.name,
      statusCode: meta.statusCode || undefined,
      ...meta,
    };
  }

  // ── 图像处理公共能力 ─────────────────────────────────────────────

  /**
   * 将 options.images 标准化为统一格式。
   * 所有适配器可直接调用，无需各自引入 _imageCompat。
   *
   * @param {Array} images - 原始图像数组
   * @returns {Array} 标准化后的图像数组
   */
  normalizeImages(images) {
    return normalizeImages(images);
  }

  /**
   * 检测 options 中是否包含有效图像。
   * @param {object} options - generate() 的 options 参数
   * @returns {boolean}
   */
  hasImages(options = {}) {
    return Array.isArray(options.images) && normalizeImages(options.images).length > 0;
  }

  /**
   * 按适配器的 imageFormat 将图像转换为目标格式。
   *
   * @param {Array} images - 原始图像数组
   * @param {string} [format] - 覆盖 this.imageFormat
   * @returns {Array} 目标格式的图像块
   */
  convertImages(images, format) {
    const fmt = format || this.imageFormat;
    const normalized = normalizeImages(images);
    if (normalized.length === 0) return [];
    switch (fmt) {
      case 'anthropic': return toAnthropicImageBlocks(normalized);
      case 'ollama':    return toOllamaBase64Images(normalized);
      case 'codex':     return toCodexInputImages(normalized);
      case 'google':    return toGoogleInlineData(normalized);
      case 'openai':
      default:          return toOpenAIVisionBlocks(normalized);
    }
  }

  /**
   * 将图像附加到 OpenAI 格式的 messages 数组中（最后一条 user 消息）。
   * 适用于所有兼容 OpenAI vision 格式的适配器。
   *
   * @param {Array} messages - 消息数组
   * @param {Array} images - 原始图像数组
   * @returns {Array} 附加图像后的消息数组
   */
  attachImagesToMessages(messages, images) {
    return attachImagesToOpenAIMessages(messages, images);
  }

  /**
   * 当适配器不支持视觉时，返回标记让 gateway 回退到视觉适配器。
   * 子类在 generate() 中检测到 images 且 supportsVision=false 时调用。
   *
   * @param {string} prompt
   * @param {object} options
   * @returns {{ success: false, _visionFallback: true, ... }}
   */
  requestVisionFallback(prompt, options) {
    return {
      success: false,
      _visionFallback: true,
      content: '',
      provider: this.name,
      adapter: this.name,
      error: `${this.name} 不支持图像识别，请求视觉回退`,
      _originalPrompt: prompt,
      _originalOptions: options,
    };
  }

  /**
   * Get adapter status for display.
   * @returns {{ name, type, available, activeModel, supportsVision }}
   */
  getStatus() {
    return {
      name: this.name,
      type: this.type,
      available: this._available,
      activeModel: this.activeModel,
      supportsVision: this.supportsVision,
    };
  }
}

module.exports = BaseAdapter;
