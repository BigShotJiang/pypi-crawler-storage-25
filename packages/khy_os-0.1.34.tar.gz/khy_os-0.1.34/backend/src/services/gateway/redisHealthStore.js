/**
 * Redis-backed Adapter Health Store
 *
 * Provides distributed, persistent circuit breaker state for the AI Gateway.
 * Gracefully degrades to an in-memory Map when Redis is unavailable.
 *
 * Features:
 * - Atomic failure counting (Redis INCR)
 * - TTL-based auto-cleanup (no manual eviction needed)
 * - Half-open circuit state with consecutive-success tracking
 * - Exponential cooldown backoff across process restarts
 */
'use strict';

const { REDIS_KEY_PREFIX } = require('../../constants/serviceDefaults');

// ── In-Memory Fallback Store ────────────────────────────────────────────────
class MemoryHealthStore {
  constructor() {
    this._failures = {};   // key → count
    this._errors = {};     // key → { record, expiresAt }
    this._cooldowns = {};  // key → expiresAt
    this._halfOk = {};     // key → { count, expiresAt }
  }

  async incrFailure(key) {
    this._failures[key] = (this._failures[key] || 0) + 1;
    return this._failures[key];
  }

  async clearFailure(key) {
    delete this._failures[key];
    delete this._errors[key];
    delete this._cooldowns[key];
    delete this._halfOk[key];
  }

  async getFailureCount(key) {
    return this._failures[key] || 0;
  }

  async recordLastError(key, record, ttlMs) {
    this._errors[key] = { record, expiresAt: Date.now() + (ttlMs || 120000) };
  }

  async getLastError(key) {
    const item = this._errors[key];
    if (!item) return null;
    if (Date.now() > item.expiresAt) {
      delete this._errors[key];
      return null;
    }
    return item.record;
  }

  async setCooldown(key, ttlMs) {
    this._cooldowns[key] = Date.now() + ttlMs;
  }

  async isInCooldown(key) {
    const exp = this._cooldowns[key];
    if (!exp) return false;
    if (Date.now() > exp) {
      delete this._cooldowns[key];
      return false;
    }
    return true;
  }

  async getCooldownRemainingMs(key) {
    const exp = this._cooldowns[key];
    if (!exp) return 0;
    const remaining = exp - Date.now();
    if (remaining <= 0) {
      delete this._cooldowns[key];
      return 0;
    }
    return remaining;
  }

  async recordSuccess(key) {
    this._halfOk[key] = {
      count: ((this._halfOk[key] || {}).count || 0) + 1,
      expiresAt: Date.now() + 120000,
    };
    return this._halfOk[key].count;
  }

  async getConsecutiveSuccesses(key) {
    const item = this._halfOk[key];
    if (!item) return 0;
    if (Date.now() > item.expiresAt) {
      delete this._halfOk[key];
      return 0;
    }
    return item.count;
  }

  async resetHalfOpen(key) {
    delete this._halfOk[key];
  }

  async getAllAdapterStates(adapterKeys) {
    const states = {};
    for (const key of adapterKeys) {
      states[key] = {
        failureCount: this._failures[key] || 0,
        lastError: (this._errors[key] && Date.now() <= this._errors[key].expiresAt)
          ? this._errors[key].record : null,
        inCooldown: await this.isInCooldown(key),
        cooldownRemainingMs: await this.getCooldownRemainingMs(key),
        consecutiveSuccesses: await this.getConsecutiveSuccesses(key),
      };
    }
    return states;
  }

  cleanup(validKeys) {
    const valid = new Set(validKeys);
    for (const k of Object.keys(this._failures)) if (!valid.has(k)) delete this._failures[k];
    for (const k of Object.keys(this._errors)) if (!valid.has(k)) delete this._errors[k];
    for (const k of Object.keys(this._cooldowns)) if (!valid.has(k)) delete this._cooldowns[k];
    for (const k of Object.keys(this._halfOk)) if (!valid.has(k)) delete this._halfOk[k];
  }
}

// ── Redis Health Store ──────────────────────────────────────────────────────
class RedisHealthStore {
  /**
   * @param {object} opts
   * @param {Function} opts.getRedisClient  — () => redis client or null
   * @param {string}  [opts.keyPrefix]      — Redis key prefix
   */
  constructor(opts = {}) {
    this._getClient = opts.getRedisClient || (() => null);
    this._prefix = opts.keyPrefix || REDIS_KEY_PREFIX;
    this._memory = new MemoryHealthStore();
    this._useRedis = false;
    this._redisErrorLogged = false;
  }

  async init() {
    try {
      const client = this._getClient();
      if (client && client.isReady) {
        await client.ping();
        this._useRedis = true;
        return;
      }
    } catch { /* fallback to memory */ }
    this._useRedis = false;
  }

  async destroy() {
    // We don't own the Redis connection (shared via cacheService), so just clean up local state
    this._useRedis = false;
  }

  isRedisAvailable() {
    if (!this._useRedis) return false;
    try {
      const client = this._getClient();
      return !!(client && client.isReady);
    } catch {
      return false;
    }
  }

  // ── Helpers ─────────────────────────────────────────────────────────────

  _key(suffix) {
    return `${this._prefix}${suffix}`;
  }

  _client() {
    if (!this._useRedis) return null;
    try {
      const c = this._getClient();
      return (c && c.isReady) ? c : null;
    } catch {
      return null;
    }
  }

  _logRedisError(method, err) {
    if (!this._redisErrorLogged) {
      this._redisErrorLogged = true;
      console.warn(`[RedisHealthStore] Redis ${method} failed, falling back to memory: ${err.message}`);
      // Reset flag after 30s to allow logging again
      setTimeout(() => { this._redisErrorLogged = false; }, 30000);
    }
  }

  // ── Failure Counting ────────────────────────────────────────────────────

  async incrFailure(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const key = this._key(`fail:${adapterKey}`);
        const count = await client.incr(key);
        await client.expire(key, 300); // 5 min TTL
        // Mirror to memory for fast reads
        this._memory._failures[adapterKey] = count;
        return count;
      } catch (err) {
        this._logRedisError('incrFailure', err);
      }
    }
    return this._memory.incrFailure(adapterKey);
  }

  async clearFailure(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        await client.del([
          this._key(`fail:${adapterKey}`),
          this._key(`err:${adapterKey}`),
          this._key(`cd:${adapterKey}`),
          this._key(`halfok:${adapterKey}`),
        ]);
      } catch (err) {
        this._logRedisError('clearFailure', err);
      }
    }
    return this._memory.clearFailure(adapterKey);
  }

  async getFailureCount(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const val = await client.get(this._key(`fail:${adapterKey}`));
        const count = val ? parseInt(val, 10) : 0;
        this._memory._failures[adapterKey] = count; // sync to memory
        return count;
      } catch (err) {
        this._logRedisError('getFailureCount', err);
      }
    }
    return this._memory.getFailureCount(adapterKey);
  }

  // ── Last Error Record ───────────────────────────────────────────────────

  async recordLastError(adapterKey, record, ttlMs = 120000) {
    const client = this._client();
    if (client) {
      try {
        const key = this._key(`err:${adapterKey}`);
        const ttlSec = Math.max(1, Math.ceil(ttlMs / 1000));
        await client.setEx(key, ttlSec, JSON.stringify(record));
      } catch (err) {
        this._logRedisError('recordLastError', err);
      }
    }
    return this._memory.recordLastError(adapterKey, record, ttlMs);
  }

  async getLastError(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const val = await client.get(this._key(`err:${adapterKey}`));
        if (val) {
          const record = JSON.parse(val);
          this._memory._errors[adapterKey] = { record, expiresAt: Date.now() + 120000 };
          return record;
        }
        return null;
      } catch (err) {
        this._logRedisError('getLastError', err);
      }
    }
    return this._memory.getLastError(adapterKey);
  }

  // ── Cooldown ────────────────────────────────────────────────────────────

  async setCooldown(adapterKey, ttlMs) {
    const client = this._client();
    if (client) {
      try {
        const key = this._key(`cd:${adapterKey}`);
        const ttlSec = Math.max(1, Math.ceil(ttlMs / 1000));
        await client.setEx(key, ttlSec, '1');
      } catch (err) {
        this._logRedisError('setCooldown', err);
      }
    }
    return this._memory.setCooldown(adapterKey, ttlMs);
  }

  async isInCooldown(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const exists = await client.exists(this._key(`cd:${adapterKey}`));
        return exists === 1;
      } catch (err) {
        this._logRedisError('isInCooldown', err);
      }
    }
    return this._memory.isInCooldown(adapterKey);
  }

  async getCooldownRemainingMs(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const ttl = await client.pTTL(this._key(`cd:${adapterKey}`));
        return ttl > 0 ? ttl : 0;
      } catch (err) {
        this._logRedisError('getCooldownRemainingMs', err);
      }
    }
    return this._memory.getCooldownRemainingMs(adapterKey);
  }

  // ── Half-Open Success Tracking ──────────────────────────────────────────

  async recordSuccess(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const key = this._key(`halfok:${adapterKey}`);
        const count = await client.incr(key);
        await client.expire(key, 120); // 2 min TTL
        return count;
      } catch (err) {
        this._logRedisError('recordSuccess', err);
      }
    }
    return this._memory.recordSuccess(adapterKey);
  }

  async getConsecutiveSuccesses(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        const val = await client.get(this._key(`halfok:${adapterKey}`));
        return val ? parseInt(val, 10) : 0;
      } catch (err) {
        this._logRedisError('getConsecutiveSuccesses', err);
      }
    }
    return this._memory.getConsecutiveSuccesses(adapterKey);
  }

  async resetHalfOpen(adapterKey) {
    const client = this._client();
    if (client) {
      try {
        await client.del(this._key(`halfok:${adapterKey}`));
      } catch (err) {
        this._logRedisError('resetHalfOpen', err);
      }
    }
    return this._memory.resetHalfOpen(adapterKey);
  }

  // ── Bulk State Query (for health dashboard) ─────────────────────────────

  async getAllAdapterStates(adapterKeys) {
    const client = this._client();
    if (!client) return this._memory.getAllAdapterStates(adapterKeys);

    const states = {};
    try {
      // Pipeline multiple reads for efficiency
      const pipeline = client.multi();
      for (const key of adapterKeys) {
        pipeline.get(this._key(`fail:${key}`));
        pipeline.get(this._key(`err:${key}`));
        pipeline.pTTL(this._key(`cd:${key}`));
        pipeline.get(this._key(`halfok:${key}`));
      }
      const results = await pipeline.exec();

      for (let i = 0; i < adapterKeys.length; i++) {
        const key = adapterKeys[i];
        const base = i * 4;
        const failCount = results[base] ? parseInt(results[base], 10) : 0;
        const errRaw = results[base + 1];
        const cdTTL = results[base + 2];
        const halfOk = results[base + 3] ? parseInt(results[base + 3], 10) : 0;

        let lastError = null;
        if (errRaw) {
          try { lastError = JSON.parse(errRaw); } catch { /* corrupted */ }
        }

        states[key] = {
          failureCount: failCount,
          lastError,
          inCooldown: cdTTL > 0,
          cooldownRemainingMs: cdTTL > 0 ? cdTTL : 0,
          consecutiveSuccesses: halfOk,
        };
      }
      return states;
    } catch (err) {
      this._logRedisError('getAllAdapterStates', err);
      return this._memory.getAllAdapterStates(adapterKeys);
    }
  }

  // ── Cleanup ─────────────────────────────────────────────────────────────

  cleanup(validKeys) {
    this._memory.cleanup(validKeys);
    // Redis keys auto-expire via TTL — no manual cleanup needed
  }
}

module.exports = { RedisHealthStore, MemoryHealthStore };
