'use strict';

/**
 * acceptanceCriteria.js
 *
 * Machine-readable acceptance criteria for each intent-gate mode.
 * Used by deliveryGate.js to validate that AI-generated projects
 * contain all required deliverables.
 *
 * Check types:
 *   file_exists  — target path must exist
 *   glob_min     — glob pattern must match >= minFiles files
 *   file_contains — target file must contain one of the strings in `contains`
 *   custom       — validator name resolved by deliveryGate at runtime
 */

const CODING_ACCEPTANCE = [
  // Phase 2 — Scaffolding: config file must exist
  { id: 'config_file', label: 'Build config file', phase: 2, required: true,
    check: 'glob_min',
    target: '{package.json,pom.xml,Cargo.toml,go.mod,requirements.txt,pyproject.toml,build.gradle,CMakeLists.txt}',
    minFiles: 1 },

  // Phase 4 — Docker Delivery
  { id: 'dockerfile', label: 'Dockerfile', phase: 4, required: true,
    check: 'file_exists', target: 'Dockerfile' },
  { id: 'docker_compose', label: 'docker-compose.yml', phase: 4, required: true,
    check: 'file_exists', target: 'docker-compose.yml' },
  { id: 'dockerignore', label: '.dockerignore', phase: 4, required: false,
    check: 'file_exists', target: '.dockerignore' },

  // Phase 5 — Testing
  { id: 'unit_tests', label: 'Unit tests directory', phase: 5, required: true,
    check: 'glob_min', target: 'unit_tests/**/*', minFiles: 1 },
  { id: 'api_tests', label: 'API tests directory', phase: 5, required: false,
    check: 'glob_min', target: 'API_tests/**/*', minFiles: 1 },
  { id: 'run_tests_sh', label: 'run_tests.sh', phase: 5, required: true,
    check: 'file_exists', target: 'run_tests.sh' },

  // Phase 6 — Documentation
  { id: 'readme', label: 'README.md', phase: 6, required: true,
    check: 'file_exists', target: 'README.md' },
  { id: 'readme_docker', label: 'README mentions docker compose', phase: 6, required: false,
    check: 'file_contains', target: 'README.md',
    contains: ['docker compose', 'docker-compose'] },
];

const ULTRAWORK_ACCEPTANCE = [
  { id: 'plan_exists', label: 'Execution plan created', phase: 1, required: true,
    check: 'custom', validator: 'plan_in_response' },
];

const ANALYZE_ACCEPTANCE = [
  { id: 'evidence_cited', label: 'Evidence with file paths', phase: 1, required: true,
    check: 'custom', validator: 'evidence_in_response' },
];

const GOAL_ACCEPTANCE = [
  { id: 'plan_executed', label: 'Execution plan created and followed', phase: 1, required: true,
    check: 'custom', validator: 'plan_in_response' },
  { id: 'evidence_cited', label: 'Evidence with file paths or tool output', phase: 2, required: true,
    check: 'custom', validator: 'evidence_in_response' },
];

const MODE_ACCEPTANCE = {
  coding: CODING_ACCEPTANCE,
  ultrawork: ULTRAWORK_ACCEPTANCE,
  analyze: ANALYZE_ACCEPTANCE,
  goal: GOAL_ACCEPTANCE,
};

module.exports = {
  CODING_ACCEPTANCE,
  ULTRAWORK_ACCEPTANCE,
  ANALYZE_ACCEPTANCE,
  GOAL_ACCEPTANCE,
  MODE_ACCEPTANCE,
};
