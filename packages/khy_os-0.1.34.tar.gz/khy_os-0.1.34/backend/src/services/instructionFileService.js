/**
 * Multi-level khy.md instruction file discovery and loading.
 *
 * Mirrors CLAUDE.md / CLAW.md pattern — discovers instruction files
 * at three levels (global, project, cwd) and merges them into a
 * single block for injection into the AI system prompt.
 *
 * Levels (all loaded, bottom-up):
 *   ~/.khyquant/khy.md        → global user instructions
 *   <git-root>/khy.md         → project-level instructions
 *   <cwd>/khy.md              → directory-level (when cwd ≠ git-root)
 *
 * Limits:
 *   - Single file: max 4000 chars (truncated with warning)
 *   - Total merged: max 12000 chars
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

const MAX_FILE_CHARS = 4000;
const MAX_TOTAL_CHARS = 12000;
const FILENAME = 'khy.md';
const RULES_DIR = '.khy/rules';
const MAX_INCLUDE_DEPTH = 3;
const MAX_INCLUDE_FILES = 10;

// ── Helpers ─────────────────────────────────────────────────────────────

function findGitRoot(from) {
  try {
    const root = execSync('git rev-parse --show-toplevel', {
      cwd: from,
      encoding: 'utf-8',
      stdio: ['pipe', 'pipe', 'pipe'],
    }).trim();
    return root || null;
  } catch {
    return null;
  }
}

function readFileSafe(filePath, maxChars = MAX_FILE_CHARS) {
  try {
    if (!fs.existsSync(filePath)) return null;
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) return null;

    let content = fs.readFileSync(filePath, 'utf-8');
    let truncated = false;
    if (content.length > maxChars) {
      content = content.slice(0, maxChars);
      truncated = true;
    }
    return { content, truncated, size: stat.size };
  } catch {
    return null;
  }
}

/**
 * Process @include directives in instruction file content.
 * Supports: @path/to/file.md (relative to the instruction file's directory)
 *
 * Recursion is bounded by MAX_INCLUDE_DEPTH and MAX_INCLUDE_FILES.
 *
 * @param {string} content - Raw content with possible @include directives
 * @param {string} baseDir - Directory of the file containing the directives
 * @param {number} [depth=0] - Current recursion depth
 * @param {Set<string>} [visited] - Already-included paths (cycle prevention)
 * @returns {string} Content with includes resolved
 */
function resolveIncludes(content, baseDir, depth = 0, visited = new Set()) {
  if (depth >= MAX_INCLUDE_DEPTH || visited.size >= MAX_INCLUDE_FILES) return content;

  // Match @path/to/file patterns on their own line
  return content.replace(/^@(\S+)\s*$/gm, (match, relPath) => {
    if (visited.size >= MAX_INCLUDE_FILES) return match;

    const absPath = path.resolve(baseDir, relPath);
    const resolved = path.resolve(absPath);

    // Security: don't allow includes outside the project tree
    if (!resolved.startsWith(baseDir) && !resolved.startsWith(os.homedir())) {
      return `<!-- @include denied: ${relPath} (outside allowed scope) -->`;
    }

    if (visited.has(resolved)) {
      return `<!-- @include cycle: ${relPath} -->`;
    }

    const included = readFileSafe(resolved, MAX_FILE_CHARS);
    if (!included) {
      return `<!-- @include not found: ${relPath} -->`;
    }

    visited.add(resolved);
    // Recurse for nested includes
    return resolveIncludes(included.content, path.dirname(resolved), depth + 1, visited);
  });
}

/**
 * Discover rule files from .khy/rules/ directory (glob *.md).
 * Mirrors CLAUDE.md's .claude/rules/*.md convention.
 *
 * @param {string} projectRoot - Git root or cwd
 * @returns {Array<{ path: string, content: string, truncated: boolean, size: number }>}
 */
function discoverRuleFiles(projectRoot) {
  const rulesDir = path.join(projectRoot, RULES_DIR);
  const results = [];

  try {
    if (!fs.existsSync(rulesDir) || !fs.statSync(rulesDir).isDirectory()) return results;

    const files = fs.readdirSync(rulesDir)
      .filter(f => f.endsWith('.md'))
      .sort(); // Deterministic order

    for (const file of files) {
      const filePath = path.join(rulesDir, file);
      const entry = readFileSafe(filePath);
      if (entry) {
        results.push({
          path: filePath,
          content: entry.content,
          truncated: entry.truncated,
          size: entry.size,
        });
      }
    }
  } catch {
    // rules directory unreadable
  }

  return results;
}

// ── Core API ────────────────────────────────────────────────────────────

/**
 * Discover all khy.md files for the given working directory.
 * @param {string} [cwd] - defaults to process.cwd()
 * @returns {Array<{ path: string, content: string, level: string, truncated: boolean, size: number }>}
 */
function discoverInstructionFiles(cwd) {
  cwd = cwd || process.cwd();
  const results = [];
  const seen = new Set();

  // 1. Global: ~/.khyquant/khy.md
  const globalPath = path.join(os.homedir(), '.khyquant', FILENAME);
  const globalFile = readFileSafe(globalPath);
  if (globalFile) {
    const content = resolveIncludes(globalFile.content, path.dirname(globalPath));
    results.push({
      path: globalPath,
      content,
      level: 'global',
      truncated: globalFile.truncated,
      size: globalFile.size,
    });
    seen.add(path.resolve(globalPath));
  }

  // 2. Project: <git-root>/khy.md
  const gitRoot = findGitRoot(cwd);
  if (gitRoot) {
    const projectPath = path.join(gitRoot, FILENAME);
    const resolved = path.resolve(projectPath);
    if (!seen.has(resolved)) {
      const projectFile = readFileSafe(projectPath);
      if (projectFile) {
        const content = resolveIncludes(projectFile.content, path.dirname(projectPath));
        results.push({
          path: projectPath,
          content,
          level: 'project',
          truncated: projectFile.truncated,
          size: projectFile.size,
        });
        seen.add(resolved);
      }
    }

    // 2b. Rules: <git-root>/.khy/rules/*.md
    const ruleFiles = discoverRuleFiles(gitRoot);
    for (const rf of ruleFiles) {
      const rfResolved = path.resolve(rf.path);
      if (!seen.has(rfResolved)) {
        const content = resolveIncludes(rf.content, path.dirname(rf.path));
        results.push({
          path: rf.path,
          content,
          level: 'rules',
          truncated: rf.truncated,
          size: rf.size,
        });
        seen.add(rfResolved);
      }
    }
  }

  // 3. CWD: <cwd>/khy.md (only if different from git root)
  const cwdPath = path.join(cwd, FILENAME);
  const cwdResolved = path.resolve(cwdPath);
  if (!seen.has(cwdResolved)) {
    const cwdFile = readFileSafe(cwdPath);
    if (cwdFile) {
      const content = resolveIncludes(cwdFile.content, path.dirname(cwdPath));
      results.push({
        path: cwdPath,
        content,
        level: 'directory',
        truncated: cwdFile.truncated,
        size: cwdFile.size,
      });
    }
  }

  return results;
}

/**
 * Load and merge all khy.md instructions into a single string.
 * Suitable for direct injection into the AI system prompt.
 *
 * @param {string} [cwd]
 * @returns {string} merged instructions (empty string if none found)
 */
function loadInstructions(cwd) {
  const files = discoverInstructionFiles(cwd);
  if (files.length === 0) return '';

  const LEVEL_LABELS = {
    global: '全局指令',
    project: '项目指令',
    rules: '规则指令',
    directory: '目录指令',
  };

  const sections = [];
  let totalChars = 0;

  for (const file of files) {
    const label = LEVEL_LABELS[file.level] || file.level;
    const header = `[${label} - ${file.path}]`;
    let content = file.content;

    // Enforce total limit
    const remaining = MAX_TOTAL_CHARS - totalChars - header.length - 2;
    if (remaining <= 0) break;
    if (content.length > remaining) {
      content = content.slice(0, remaining);
    }

    const section = `${header}\n${content}`;
    sections.push(section);
    totalChars += section.length;

    if (totalChars >= MAX_TOTAL_CHARS) break;
  }

  return sections.join('\n\n');
}

/**
 * Get a summary of loaded instruction files (for /memory command).
 * @param {string} [cwd]
 * @returns {Array<{ path: string, level: string, size: number, truncated: boolean }>}
 */
function getInstructionSummary(cwd) {
  return discoverInstructionFiles(cwd).map(({ path: p, level, size, truncated }) => ({
    path: p,
    level,
    size,
    truncated,
  }));
}

module.exports = {
  discoverInstructionFiles,
  loadInstructions,
  getInstructionSummary,
  resolveIncludes,
  discoverRuleFiles,
  MAX_FILE_CHARS,
  MAX_TOTAL_CHARS,
  MAX_INCLUDE_DEPTH,
  MAX_INCLUDE_FILES,
  RULES_DIR,
};
