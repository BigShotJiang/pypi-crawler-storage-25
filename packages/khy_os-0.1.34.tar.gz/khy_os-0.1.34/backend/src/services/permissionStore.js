/**
 * Permission Store — profile-aware, persistent permission management.
 *
 * Three permission profiles:
 *   - strict:  All tools require confirmation, including 'safe' tools
 *   - normal:  Safe tools auto-approved, everything else asks (default)
 *   - yolo:    All tools auto-approved (equivalent to --dangerous)
 *
 * Approvals persist across sessions in ~/.khyquant/permissions.json.
 * Migrates from legacy tool_permissions.json on first load.
 *
 * Inspired by Claude Code's multi-layer permission system.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const PERMISSIONS_FILE = path.join(os.homedir(), '.khyquant', 'permissions.json');
const LEGACY_FILE = path.join(os.homedir(), '.khyquant', 'tool_permissions.json');

const VALID_PROFILES = ['strict', 'normal', 'yolo'];
const VALID_SCOPES = ['once', 'session', 'forever'];

// ── In-memory state ─────────────────────────────────────────────────

let _profile = 'normal';
let _rules = {};           // { toolName: { decision, scope, since, conditions? } }
let _sessionApprovals = new Set(); // Session-only approvals (cleared on restart)
let _sessionDenials = new Set();
let _loaded = false;

// ── Persistence ─────────────────────────────────────────────────────

function _ensureDir() {
  const dir = path.dirname(PERMISSIONS_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function _load() {
  if (_loaded) return;
  _loaded = true;

  // Try loading new format first
  try {
    if (fs.existsSync(PERMISSIONS_FILE)) {
      const data = JSON.parse(fs.readFileSync(PERMISSIONS_FILE, 'utf-8'));
      _profile = VALID_PROFILES.includes(data.profile) ? data.profile : 'normal';
      _rules = data.rules || {};
      return;
    }
  } catch { /* fall through to migration */ }

  // Migrate from legacy format
  _migrateLegacy();
}

function _save() {
  try {
    _ensureDir();
    const data = {
      profile: _profile,
      rules: _rules,
      version: 2,
      updatedAt: new Date().toISOString(),
    };
    fs.writeFileSync(PERMISSIONS_FILE, JSON.stringify(data, null, 2));
  } catch { /* best effort */ }
}

/**
 * Migrate from legacy tool_permissions.json format.
 * Legacy: { approved: { toolName: true }, denied: {}, dangerousAcknowledged: bool }
 */
function _migrateLegacy() {
  try {
    if (!fs.existsSync(LEGACY_FILE)) return;

    const legacy = JSON.parse(fs.readFileSync(LEGACY_FILE, 'utf-8'));

    // Convert approved tools
    if (legacy.approved && typeof legacy.approved === 'object') {
      for (const [toolName, value] of Object.entries(legacy.approved)) {
        if (value) {
          _rules[toolName] = {
            decision: 'allow',
            scope: 'forever',
            since: new Date().toISOString(),
            migrated: true,
          };
        }
      }
    }

    // Convert denied tools
    if (legacy.denied && typeof legacy.denied === 'object') {
      for (const [toolName, value] of Object.entries(legacy.denied)) {
        if (value) {
          _rules[toolName] = {
            decision: 'deny',
            scope: 'forever',
            since: new Date().toISOString(),
            migrated: true,
          };
        }
      }
    }

    // If dangerous mode was acknowledged, set profile to normal
    // (don't auto-enable yolo — user should opt in explicitly)
    _profile = 'normal';

    // Save migrated data
    _save();
  } catch { /* migration failure is non-critical */ }
}

// ── Public API ──────────────────────────────────────────────────────

/**
 * Set the permission profile.
 * @param {'strict'|'normal'|'yolo'} profileName
 */
function setProfile(profileName) {
  _load();
  if (!VALID_PROFILES.includes(profileName)) {
    throw new Error(`Invalid profile: ${profileName}. Valid: ${VALID_PROFILES.join(', ')}`);
  }
  _profile = profileName;
  _save();
}

/**
 * Get the current permission profile.
 * @returns {string}
 */
function getProfile() {
  _load();
  return _profile;
}

/**
 * Check if a tool call should be allowed, denied, or needs to ask.
 *
 * Decision flow:
 * 1. Profile 'yolo' → always allow
 * 2. Session denial → deny
 * 3. Persistent rules → apply
 * 4. Session approval → allow
 * 5. Profile 'strict' → ask (even for safe tools)
 * 6. Profile 'normal' + safe risk → allow
 * 7. Default → ask
 *
 * @param {string} toolName
 * @param {object} [params]
 * @param {object} [options]
 * @param {string} [options.risk] - Tool risk level
 * @returns {'allow'|'deny'|'ask'}
 */
function check(toolName, params, options = {}) {
  _load();

  // Yolo mode = approve everything
  if (_profile === 'yolo') return 'allow';

  // Session denial overrides everything else
  if (_sessionDenials.has(toolName)) return 'deny';

  // Persistent rules
  const rule = _rules[toolName];
  if (rule) {
    if (rule.decision === 'allow' && rule.scope === 'forever') return 'allow';
    if (rule.decision === 'deny' && rule.scope === 'forever') return 'deny';
  }

  // Session approval
  if (_sessionApprovals.has(toolName)) return 'allow';

  // Virtual tool mapping: if a shell command maps to a known tool,
  // check that tool's permission as a transparent fallback
  if (options.virtualTool && options.virtualTool !== toolName) {
    const virtualRule = _rules[options.virtualTool];
    if (virtualRule?.decision === 'allow' && virtualRule.scope === 'forever') return 'allow';
    if (_sessionApprovals.has(options.virtualTool)) return 'allow';
  }

  // Strict mode: ask for everything
  if (_profile === 'strict') return 'ask';

  // Normal mode: auto-approve safe tools
  if (_profile === 'normal' && options.risk === 'safe') return 'allow';

  // Normal mode: auto-approve readOnly tools (behavioral declaration)
  if (_profile === 'normal' && options.isReadOnly === true) return 'allow';

  // Destructive tools require explicit approval (unless yolo or already authorized)
  if (options.isDestructive === true && _profile !== 'yolo') {
    const destructiveRule = _rules[toolName];
    if (destructiveRule?.decision === 'allow' && destructiveRule.scope === 'forever') return 'allow';
    if (_sessionApprovals.has(toolName)) return 'allow';
    return 'ask';
  }

  return 'ask';
}

/**
 * Record an approval decision.
 * @param {string} toolName
 * @param {'once'|'session'|'forever'} scope
 */
function approve(toolName, scope = 'once') {
  _load();

  if (scope === 'session') {
    _sessionApprovals.add(toolName);
    _sessionDenials.delete(toolName);
  } else if (scope === 'forever') {
    _rules[toolName] = {
      decision: 'allow',
      scope: 'forever',
      since: new Date().toISOString(),
    };
    _sessionApprovals.add(toolName);
    _sessionDenials.delete(toolName);
    _save();
  }
  // 'once' = no persistence, just allow this call
}

/**
 * Record a denial decision.
 * @param {string} toolName
 * @param {'once'|'session'|'forever'} scope
 */
function deny(toolName, scope = 'once') {
  _load();

  if (scope === 'session') {
    _sessionDenials.add(toolName);
    _sessionApprovals.delete(toolName);
  } else if (scope === 'forever') {
    _rules[toolName] = {
      decision: 'deny',
      scope: 'forever',
      since: new Date().toISOString(),
    };
    _sessionDenials.add(toolName);
    _sessionApprovals.delete(toolName);
    _save();
  }
}

/**
 * Get list of all approved tool names.
 * @returns {string[]}
 */
function getApprovedTools() {
  _load();
  const approved = new Set(_sessionApprovals);
  for (const [name, rule] of Object.entries(_rules)) {
    if (rule.decision === 'allow') approved.add(name);
  }
  return [...approved];
}

/**
 * Get list of all denied tool names.
 * @returns {string[]}
 */
function getDeniedTools() {
  _load();
  const denied = new Set(_sessionDenials);
  for (const [name, rule] of Object.entries(_rules)) {
    if (rule.decision === 'deny') denied.add(name);
  }
  return [...denied];
}

/**
 * Get all rules for display.
 * @returns {object}
 */
function getAllRules() {
  _load();
  return {
    profile: _profile,
    persistent: { ..._rules },
    sessionApproved: [..._sessionApprovals],
    sessionDenied: [..._sessionDenials],
  };
}

/**
 * Reset all permissions (profile stays, rules cleared).
 */
function reset() {
  _load();
  _rules = {};
  _sessionApprovals.clear();
  _sessionDenials.clear();
  _save();
}

/**
 * Revoke a specific tool's persistent rule.
 * @param {string} toolName
 */
function revoke(toolName) {
  _load();
  delete _rules[toolName];
  _sessionApprovals.delete(toolName);
  _sessionDenials.delete(toolName);
  _save();
}

module.exports = {
  setProfile,
  getProfile,
  check,
  approve,
  deny,
  getApprovedTools,
  getDeniedTools,
  getAllRules,
  reset,
  revoke,
  VALID_PROFILES,
};
