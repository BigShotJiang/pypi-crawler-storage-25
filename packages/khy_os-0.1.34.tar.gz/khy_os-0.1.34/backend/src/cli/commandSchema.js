'use strict';

/**
 * Command Schema — single source of truth for command metadata.
 *
 * This module centralizes:
 * - Canonical router commands
 * - Sub-command map
 * - Built-in slash command definitions
 *
 * Other modules (router, commandRegistry, tests) should derive from here
 * instead of maintaining parallel static lists.
 */

const ROUTER_COMMANDS = [
  'quote', 'data', 'cache', 'backtest', 'strategy',
  'server', 'db', 'ai', 'gateway', 'menu', 'help', 'clear', 'exit', 'quit', 'version',
  'account', 'position', 'order', 'search', 'watch', 'rank',
  'analyze', 'plugin', 'init', 'doctor', 'docs', 'profile', 'cloud',
  'kiro', 'cursor', 'claude', 'codex', 'trae', 'pool', 'proxy', 'skill', 'log',
  'cost', 'usage', 'history', 'train', 'compute', 'update',
  'growth', 'agent', 'admin', 'prompt', 'voice', 'habit', 'knowledge', 'security', 'monitor', 'services',
  'login', 'register', 'logout', 'whoami', 'passwd', 'forgot',
  'self', 'cleanup', 'memory', 'resume', 'web_search', 'subscribe', 'sub',
  'image2web',
  'app', 'model', 'models', 'khymodel', 'linux', 'shell', 'verify', 'workspace',
  'publish',
  'buddy', 'coordinator', 'assistant', 'brief', 'ultraplan', 'ulw-loop', 'bridge', 'daemon',
  'cron', 'skin', 'remote', 'arena',
  // Claude Code aligned commands
  'compact', 'config', 'context', 'diff', 'effort', 'env', 'export', 'fast',
  'files', 'hooks', 'mcp', 'session', 'share', 'stats', 'status', 'summary',
  'tasks', 'theme', 'upgrade', 'branch', 'debug', 'stickers',
];

const ROUTER_SUB_COMMANDS = {
  data: ['fetch', 'list'],
  cache: ['clear'],
  backtest: ['list'],
  strategy: ['list'],
  server: ['start', 'status'],
  db: ['init', 'seed', 'status'],
  ai: ['status', 'config', 'on', 'off', 'tools', 'dangerous', 'tech', 'owner', 'unrestricted'],
  gateway: ['status', 'config', 'relay', 'detect', 'model', 'prefer-remote', 'test', 'server', 'manage', 'protocols', 'oauth', 'discover-models', 'tune-local', 'key'],
  plugin: ['list', 'reload', 'gateway', 'init', 'dev', 'doctor', 'link', 'unlink'],
  pool: ['status', 'add', 'reset', 'list', 'import', 'use', 'api', 'delete', 'remove', 'enable', 'disable', 'scheduling', 'auto-import'],
  proxy: ['start', 'stop', 'status', 'help', 'quickstart', 'cert', 'client', 'token', 'subscription', 'sub', 'tls', 'cursor2api', 'switch-center', 'switch', 'trae-switch', 'windsurf-switch'],
  docs: ['quickstart', 'start', 'ai-fastlane', 'ai', 'fastlane', 'claude', 'gateway', 'strategy', 'faq', 'subscribe', 'sub'],
  skill: ['list', 'install', 'uninstall', 'search', 'run', 'learn', 'learned', 'forget', 'suggest', 'stats', 'curator', 'pin', 'unpin', 'archive', 'restore'],
  log: ['error', 'tail', 'clear'],
  usage: ['today', 'history', 'reset'],
  history: ['list', 'resume', 'clear'],
  train: ['start', 'cloud', 'distill', 'status', 'list', 'export', 'upload', 'data'],
  growth: ['export', 'import', 'snapshot', 'snapshots', 'restore', 'reset'],
  agent: ['task', 'status', 'memory', 'collaborate', 'list', 'templates', 'run', 'spawn'],
  prompt: ['save', 'list', 'use', 'delete', 'search', 'folder', 'dir'],
  knowledge: ['search', 'stats', 'sync', 'self'],
  habit: ['predict'],
  security: ['scan', 'monitor', 'status', 'integrity', 'profile', 'audit', 'permissions'],
  monitor: ['status', 'tail', 'clear', 'dashboard', 'tools', 'selfcheck'],
  search: ['web'],
  session: ['search', 'stats'],
  services: ['list', 'health'],
  app: ['list', 'register', 'install', 'uninstall', 'start', 'stop', 'run', 'ipc', 'exports', 'status'],
  models: ['list', 'pull', 'import', 'delete', 'set'],
  cleanup: ['status'],
  self: ['capabilities', 'boundaries', 'runtime'],
  linux: ['status', 'net', 'run', 'help'],
  shell: ['run', 'help'],
  verify: ['node', 'python', 'wasm', 'docker', 'workflow', 'wf', 'tasks', 'pipeline'],
  workspace: ['save', 'restore', 'list', 'diff', 'delete', 'cleanup', 'stats'],
  publish: [
    'check', 'build', 'pypi', 'testpypi',
    'docker-bundle', 'bundle-docker', 'docker',
    'pip-dir-bundle', 'bundle-pip', 'pip-bundle', 'pipdir',
    'npm-dir-bundle', 'bundle-npm', 'npm-bundle', 'npmdir',
    'origin-code', 'restore-origin', 'origin',
    'git-push', 'push-git', 'push',
    'self-fix', 'self-bugfix', 'autofix',
    'self-pypi', 'self-testpypi', 'self-release',
    'help',
  ],
  buddy: ['hatch', 'pet', 'card', 'mute', 'unmute'],
  coordinator: ['on', 'off', 'status'],
  assistant: ['on', 'off', 'status', 'dream', 'log', 'brief'],
  ultraplan: ['status', 'list'],
  bridge: ['start', 'stop', 'status', 'token'],
  daemon: ['start', 'stop', 'status', 'restart', 'logs', 'sessions'],
  cron: ['list', 'add', 'remove', 'enable', 'disable', 'status'],
  skin: ['set', 'list'],
  remote: ['hosts', 'connect', 'exec', 'sessions', 'disconnect'],
  config: ['set', 'get', 'list', 'show', 'openclaw', 'opencode'],
  coordinator: ['on', 'off', 'status', 'board'],
};

const CATEGORY_BY_COMMAND = {
  model: 'model',
  models: 'model',
  gateway: 'model',
  max: 'model',
  high: 'model',
  medium: 'model',
  low: 'model',

  cost: 'data',
  history: 'data',
  prompt: 'data',
  knowledge: 'data',
  growth: 'data',

  permissions: 'security',
  security: 'security',
  scan: 'security',
  login: 'security',
  register: 'security',
  logout: 'security',
  whoami: 'security',
  passwd: 'security',
  forgot: 'security',

  review: 'dev',
  doctor: 'dev',
  hardware: 'dev',
  clipboard: 'dev',
  websearch: 'dev',
  image: 'dev',
  paste: 'dev',
  image2web: 'dev',
  publish: 'dev',
  shell: 'system',

  agent: 'workflow',
  skill: 'workflow',
  plan: 'workflow',
  'ulw-loop': 'workflow',
  profile: 'workflow',
  habit: 'workflow',
  resume: 'workflow',
  memory: 'workflow',
  proxy: 'workflow',
  subscribe: 'workflow',

  linux: 'system',
  cron: 'workflow',
  skin: 'system',
  remote: 'system',
  help: 'system',
  clear: 'system',
  exit: 'system',
  update: 'system',
  cleanup: 'system',
  self: 'system',
};

const BUILTIN_SLASH_COMMANDS = [
  { cmd: '/model', label: '切换 AI 模型', desc: '选择 AI 服务提供商和模型', route: 'gateway model' },
  { cmd: '/memory', label: '查看指令文件', desc: '管理 khy.md 指令文件', route: 'memory' },
  { cmd: '/plan', label: '计划模式', desc: 'AI 制定执行计划后再操作', route: null, flag: 'plan' },
  { cmd: '/ulw-loop', label: 'ULW 循环', desc: '以 ultrawork 高强度模式执行任务', route: 'ulw-loop' },
  { cmd: '/cost', label: '查看费用', desc: '查看 Token 用量和费用统计', route: 'cost' },
  { cmd: '/permissions', label: '安全权限', desc: '查看安全状态和权限设置', route: 'security status' },
  { cmd: '/history', label: '对话历史', desc: '查看和恢复历史对话', route: 'history list' },
  { cmd: '/profile', label: '用户画像', desc: '查看使用习惯和用户画像', route: 'profile' },
  { cmd: '/growth', label: '成长档案', desc: '查看量化学习成长进度', route: 'growth' },
  { cmd: '/knowledge', label: '知识库', desc: '搜索和管理量化知识', route: 'knowledge' },
  { cmd: '/agent', label: '智能体', desc: '查看多智能体协作状态', route: 'agent status' },
  { cmd: '/skill', label: '技能管理', desc: '查看、安装和管理 Skills', route: 'skill list' },
  { cmd: '/resume', label: '恢复对话', desc: '恢复上次的 AI 对话上下文', route: 'resume' },
  { cmd: '/gateway', label: 'AI 网关', desc: '管理 AI 网关和适配器', route: 'gateway status' },
  { cmd: '/apikey', label: 'API 密钥配置', desc: '引导配置 API Key、URL 与模型', route: 'gateway config' },
  { cmd: '/prompt', label: '提示词库', desc: '管理保存的提示词模板', route: 'prompt list' },
  { cmd: '/cleanup', label: '清理存储', desc: '清理历史数据释放磁盘空间', route: 'cleanup status' },
  { cmd: '/self', label: '自我画像', desc: '查看 khy OS 完整能力、边界与运行时状态', route: 'self', category: 'system' },
  { cmd: '/proxy', label: '代理设置', desc: '配置 Clash/HTTP/SOCKS5 代理', route: null, flag: 'proxy' },
  { cmd: '/models', label: '模型管理', desc: 'Ollama/NVIDIA 模型下载管理', route: null, flag: 'models' },
  { cmd: '/image', label: '图片分析', desc: '加载图片文件进行视觉分析或网页还原', route: null, flag: 'image' },
  { cmd: '/image2web', label: '网页还原', desc: '将网页截图转为可运行 HTML 并可自动保存', route: 'image2web' },
  { cmd: '/paste', label: '粘贴图片', desc: '从剪贴板粘贴图片进行分析', route: null, flag: 'paste' },
  { cmd: '/doctor', label: '系统诊断', desc: '检查依赖、数据库、网络状态', route: 'doctor' },
  { cmd: '/publish', label: '发布工具', desc: '构建/发布 Python 包、导出 Docker/pip/npm 包、还原 origin code、自修复与自发布、推送 Git 远程', route: 'publish check' },
  { cmd: '/scan', label: '病毒扫描', desc: 'ClamAV 病毒扫描项目文件', route: null, flag: 'scan' },
  { cmd: '/security', label: '安全状态', desc: '安全状态、完整性校验、威胁扫描', route: null, flag: 'security-full' },
  { cmd: '/hardware', label: '硬件信息', desc: '查看硬件配置和本地模型推荐', route: null, flag: 'hardware' },
  { cmd: '/review', label: '代码审查', desc: 'AI 审查当前 Git 改动', route: null, flag: 'review' },
  { cmd: '/clipboard', label: '剪贴板', desc: 'Web AI 剪贴板中继 + Windows 图片粘贴桥接', route: null, flag: 'clipboard' },
  { cmd: '/websearch', label: '联网搜索', desc: '通过 Kiro 搜索网页获取最新信息', route: null, flag: 'websearch' },
  { cmd: '/linux', label: 'Linux 能力', desc: '网络诊断与基础 Linux 命令执行', route: 'linux help' },
  { cmd: '/shell', label: 'Shell 命令', desc: '执行 shell 命令（支持 --cwd/--timeout）', route: 'shell help' },
  { cmd: '/update', label: '检查更新', desc: '检查并安装最新版本', route: 'update' },
  { cmd: '/subscribe', label: '订阅指引', desc: 'AI 模型订阅与获取指南 (含国内方案)', route: null, flag: 'subscribe' },
  { cmd: '/arena', label: 'Arena 对比', desc: '多模型并行对比 (含排行榜)', route: 'arena' },
  { cmd: '/daemon', label: '守护进程', desc: '管理后台守护进程 (start/stop/status)', route: 'daemon status' },
  { cmd: '/help', label: '帮助', desc: '显示所有可用命令', route: 'help' },
  { cmd: '/clear', label: '清屏', desc: '清除终端内容', route: 'clear' },
  { cmd: '/max', label: '最高精度', desc: '切换 AI 到最高精度模式', route: null, flag: 'effort-max' },
  { cmd: '/high', label: '高精度', desc: '切换 AI 到高精度模式', route: null, flag: 'effort-high' },
  { cmd: '/medium', label: '标准精度', desc: '切换 AI 到标准精度模式', route: null, flag: 'effort-medium' },
  { cmd: '/low', label: '快速模式', desc: '切换 AI 到快速响应模式', route: null, flag: 'effort-low' },
  { cmd: '/vim', label: 'Vim Mode', desc: 'Toggle vim keybinding mode', route: null, flag: 'vim' },
  { cmd: '/voice', label: 'Voice Mode', desc: 'Toggle voice input/output', route: null, flag: 'voice' },
  { cmd: '/exit', label: '退出', desc: '保存对话并退出 khy OS', route: 'exit' },

  // Claude Code aligned slash commands
  { cmd: '/compact', label: 'Compact', desc: 'Compact conversation to save context', route: null, flag: 'compact' },
  { cmd: '/config', label: 'Config', desc: 'View/edit configuration', route: null, flag: 'config' },
  { cmd: '/context', label: 'Context', desc: 'Show current context window usage', route: null, flag: 'context' },
  { cmd: '/diff', label: 'Diff', desc: 'Show git diff of recent changes', route: null, flag: 'diff' },
  { cmd: '/effort', label: 'Effort', desc: 'Set effort level (low/medium/high)', route: null, flag: 'effort' },
  { cmd: '/env', label: 'Environment', desc: 'Show environment information', route: null, flag: 'env' },
  { cmd: '/export', label: 'Export', desc: 'Export conversation to file', route: null, flag: 'export' },
  { cmd: '/fast', label: 'Fast Mode', desc: 'Toggle fast mode for quicker responses', route: null, flag: 'fast' },
  { cmd: '/files', label: 'Files', desc: 'List files in context', route: null, flag: 'files' },
  { cmd: '/hooks', label: 'Hooks', desc: 'Manage lifecycle hooks', route: null, flag: 'hooks' },
  { cmd: '/login', label: 'Login', desc: 'Authenticate with API', route: 'login' },
  { cmd: '/logout', label: 'Logout', desc: 'Clear authentication', route: 'logout' },
  { cmd: '/mcp', label: 'MCP', desc: 'Manage MCP servers', route: null, flag: 'mcp' },
  { cmd: '/plugin', label: 'Plugins', desc: 'Manage plugins', route: 'plugin list' },
  { cmd: '/session', label: 'Session', desc: 'Session management', route: null, flag: 'session' },
  { cmd: '/share', label: 'Share', desc: 'Share conversation', route: null, flag: 'share' },
  { cmd: '/stats', label: 'Stats', desc: 'Show session statistics', route: null, flag: 'stats' },
  { cmd: '/status', label: 'Status', desc: 'Show current status', route: null, flag: 'status' },
  { cmd: '/summary', label: 'Summary', desc: 'Summarize conversation', route: null, flag: 'summary' },
  { cmd: '/tasks', label: 'Tasks', desc: 'Inspect and control runtime tasks', route: null, flag: 'tasks' },
  { cmd: '/theme', label: 'Theme', desc: 'Change color theme', route: null, flag: 'theme' },
  { cmd: '/upgrade', label: 'Upgrade', desc: 'Check for updates', route: 'update' },
  { cmd: '/usage', label: 'Usage', desc: 'Show usage statistics', route: 'usage' },
  { cmd: '/version', label: 'Version', desc: 'Show version info', route: 'version' },
  { cmd: '/branch', label: 'Branch', desc: 'Create/switch git branch', route: null, flag: 'branch' },
  { cmd: '/debug', label: 'Debug', desc: 'Debug tool call', route: null, flag: 'debug' },
  { cmd: '/stickers', label: 'Stickers', desc: 'Fun stickers', route: null, flag: 'stickers' },
];

function inferCategory(commandName = '') {
  return CATEGORY_BY_COMMAND[String(commandName || '').trim()] || 'system';
}

function _cloneArray(values) {
  return Array.isArray(values) ? [...values] : [];
}

function getRouterCommandNames() {
  return _cloneArray(ROUTER_COMMANDS);
}

function getRouterSubCommands() {
  const out = {};
  for (const [name, values] of Object.entries(ROUTER_SUB_COMMANDS)) {
    out[name] = _cloneArray(values);
  }
  return out;
}

function getBuiltinSlashCommands() {
  return BUILTIN_SLASH_COMMANDS.map((item) => {
    const cmd = String(item.cmd || '').trim();
    const name = cmd.replace(/^\/+/, '');
    return {
      ...item,
      category: item.category || inferCategory(name),
    };
  });
}

function getStaticSlashCommands() {
  return getBuiltinSlashCommands();
}

/**
 * Full canonical command schema for lint/test/introspection use.
 *
 * Shape:
 * - name: string
 * - subCommands: string[]
 * - slash: { cmd, label, desc, route, flag, category } | null
 * - aliases: string[]
 * - flags: string[]
 * - category: string
 */
function getCommandSchema() {
  const ordered = [];
  const byName = new Map();

  for (const name of ROUTER_COMMANDS) {
    const entry = {
      name,
      subCommands: _cloneArray(ROUTER_SUB_COMMANDS[name]),
      slash: null,
      aliases: [],
      flags: [],
      category: inferCategory(name),
    };
    ordered.push(name);
    byName.set(name, entry);
  }

  for (const slash of getBuiltinSlashCommands()) {
    const name = String(slash.cmd || '').replace(/^\/+/, '');
    if (!name) continue;

    let entry = byName.get(name);
    if (!entry) {
      entry = {
        name,
        subCommands: [],
        slash: null,
        aliases: [],
        flags: [],
        category: slash.category || inferCategory(name),
      };
      byName.set(name, entry);
      ordered.push(name);
    }

    entry.slash = {
      cmd: slash.cmd,
      label: slash.label,
      desc: slash.desc,
      route: slash.route ?? null,
      flag: slash.flag ?? null,
      category: slash.category || entry.category,
    };

    if (slash.flag) {
      entry.flags = [...new Set([...entry.flags, slash.flag])];
    }

    if (!entry.category || entry.category === 'system') {
      entry.category = slash.category || inferCategory(name);
    }
  }

  return ordered.map((name) => {
    const entry = byName.get(name);
    return {
      ...entry,
      subCommands: _cloneArray(entry.subCommands),
      aliases: _cloneArray(entry.aliases),
      flags: _cloneArray(entry.flags),
      slash: entry.slash ? { ...entry.slash } : null,
    };
  });
}

module.exports = {
  getCommandSchema,
  getRouterCommandNames,
  getRouterSubCommands,
  getBuiltinSlashCommands,
  getStaticSlashCommands,
  inferCategory,
};
