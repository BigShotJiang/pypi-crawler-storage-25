/**
 * Hook Runner — executes hook commands as child processes.
 *
 * Each hook receives context as JSON on stdin and can:
 *   - Exit 0: allow (pass through)
 *   - Exit 2: block (prevent the action)
 *   - Emit JSON on stdout: modify the context
 */
const { spawn } = require('child_process');
const { platformShell, safeKill } = require('../../tools/platformUtils');

/**
 * Run a single hook (command-based or function-based).
 * @param {Object} hook - Hook definition from registry
 * @param {Object} context - Event context (toolName, args, prompt, etc.)
 * @returns {Promise<{action: 'allow'|'block'|'modify', output?: Object, error?: string}>}
 */
async function runHook(hook, context) {
  // Function-based hooks: call directly
  if (hook.type === 'function' && typeof hook.handler === 'function') {
    return _runFunctionHook(hook, context);
  }

  // Command-based hooks: spawn child process
  return _runCommandHook(hook, context);
}

/**
 * Execute a function-based hook.
 * @private
 */
async function _runFunctionHook(hook, context) {
  let timer = null;
  try {
    const result = await Promise.race([
      Promise.resolve(hook.handler(context)),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('Hook function timed out')), hook.timeout || 10000);
        timer.unref?.();
      }),
    ]);
    if (timer) clearTimeout(timer);

    // Normalize return value
    if (!result || typeof result !== 'object') {
      return { action: 'allow' };
    }
    if (result.action === 'block') {
      return { action: 'block', error: result.reason || 'Blocked by function hook' };
    }
    if (result.action === 'modify') {
      const { action, ...overrides } = result;
      return { action: 'modify', output: overrides };
    }
    return { action: result.action || 'allow', output: result };
  } catch (err) {
    if (timer) clearTimeout(timer);
    return { action: 'allow', error: err.message };
  }
}

/**
 * Execute a command-based hook via child process.
 * @private
 */
async function _runCommandHook(hook, context) {
  const HOOK_MAX_BUFFER = 512 * 1024; // 512 KB max per stream
  const hookTimeoutMs = hook.timeout || 10000;
  return new Promise((resolve) => {
    const sh = platformShell(hook.command);
    const child = spawn(sh.cmd, sh.args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, HOOK_EVENT: hook.event },
    });

    let stdout = '';
    let stderr = '';
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      if (killTimer) { clearTimeout(killTimer); killTimer = null; }
      resolve(result);
    };

    // Manual timeout — spawn()'s `timeout` option is unreliable
    let killTimer = setTimeout(() => {
      if (settled) return;
      try { safeKill(child, 'SIGKILL', 0); } catch { /* ignore */ }
      finish({ action: 'allow', error: `Hook timed out after ${hookTimeoutMs}ms` });
    }, hookTimeoutMs);
    killTimer.unref?.();

    child.stdout.on('data', d => {
      if (stdout.length < HOOK_MAX_BUFFER) stdout += d;
    });
    child.stderr.on('data', d => {
      if (stderr.length < HOOK_MAX_BUFFER) stderr += d;
    });

    child.on('error', (err) => {
      finish({ action: 'allow', error: err.message });
    });

    child.on('close', (code) => {
      if (code === 2) {
        return finish({ action: 'block', error: stderr.trim() || 'Blocked by hook' });
      }

      let output;
      if (stdout.trim()) {
        try {
          output = JSON.parse(stdout.trim());
        } catch { /* not JSON, ignore */ }
      }

      finish({
        action: output ? 'modify' : 'allow',
        output,
        error: code !== 0 ? (stderr.trim() || `Hook exited with code ${code}`) : undefined,
      });
    });

    // Send context as JSON on stdin
    try {
      child.stdin.write(JSON.stringify(context));
      child.stdin.end();
    } catch { /* broken pipe is fine */ }
  });
}

// ── Hook Execution Telemetry ──────────────────────────────────────

const _hookMetrics = []; // [{hookSource, event, durationMs, action, error?}]
const HOOK_METRICS_MAX = 500;

/**
 * Fault-isolated hook runner — wraps runHook to guarantee:
 *   1. No thrown error propagates
 *   2. Malformed results are normalized to { action: 'allow' }
 *   3. Execution timing is recorded for telemetry
 * @param {Object} hook - Hook definition
 * @param {Object} context - Event context
 * @returns {Promise<{action: 'allow'|'block'|'modify', output?: Object, error?: string}>}
 */
async function safeRunHook(hook, context) {
  const start = Date.now();
  try {
    const result = await runHook(hook, context);
    const duration = Date.now() - start;
    _hookMetrics.push({ hookSource: hook.source || hook.command || 'unknown', event: hook._event || hook.event, durationMs: duration, action: result?.action || 'allow' });
    if (_hookMetrics.length > HOOK_METRICS_MAX) _hookMetrics.splice(0, _hookMetrics.length - HOOK_METRICS_MAX);
    if (!result || typeof result.action !== 'string') {
      return { action: 'allow', error: 'Hook returned invalid result' };
    }
    return result;
  } catch (err) {
    const duration = Date.now() - start;
    _hookMetrics.push({ hookSource: hook.source || hook.command || 'unknown', event: hook._event || hook.event, durationMs: duration, action: 'allow', error: err.message });
    if (_hookMetrics.length > HOOK_METRICS_MAX) _hookMetrics.splice(0, _hookMetrics.length - HOOK_METRICS_MAX);
    return { action: 'allow', error: `Hook crash: ${err.message}` };
  }
}

/**
 * Get hook execution metrics for telemetry/observability.
 * @returns {Array<{hookSource: string, event: string, durationMs: number, action: string, error?: string}>}
 */
function getHookMetrics() {
  return [..._hookMetrics];
}

/**
 * Run all hooks for an event sequentially.
 * Returns the final context (potentially modified) and whether to proceed.
 */
async function runHooks(hooks, context) {
  let ctx = { ...context };

  for (const hook of hooks) {
    const result = await safeRunHook(hook, ctx);

    if (result.action === 'block') {
      return { blocked: true, reason: result.error, context: ctx };
    }

    if (result.action === 'modify' && result.output) {
      ctx = { ...ctx, ...result.output };
    }
  }

  return { blocked: false, context: ctx };
}

module.exports = { runHook, safeRunHook, runHooks, getHookMetrics, _hookMetrics };
