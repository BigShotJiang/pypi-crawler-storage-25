/**
 * CLI Bootstrap — initialize environment and database for CLI commands.
 * Mirrors the startup sequence in server.js but without HTTP/WebSocket/cron.
 */
const path = require('path');

let _initialized = false;
let _sequelize = null;

async function bootstrap({ syncSchema = false, silent = false } = {}) {
  if (_initialized) return { sequelize: _sequelize };

  // Delegate to bootstrap pipeline if available (env, defaults, shutdown handlers)
  try {
    const { init } = require('../bootstrap/init');
    await init();
  } catch {
    // Fallback: inline env loading if bootstrap module not available
    const envPath = process.env.KHY_ENV_FILE
      ? path.resolve(process.env.KHY_ENV_FILE)
      : path.resolve(__dirname, '../../.env');
    require('dotenv').config({ path: envPath });
    const { applyEnvDefaults } = require('../config/env');
    applyEnvDefaults();
  }

  // 3. Initialize database (auto-detect PG vs SQLite)
  //    Mute database.js module-level console output in silent mode
  const origLog = console.log;
  const origWarn = console.warn;
  if (silent) {
    console.log = () => {};
    console.warn = () => {};
  }
  const db = require('../config/database');
  _sequelize = await db.initDatabase();
  if (silent) {
    console.log = origLog;
    console.warn = origWarn;
  }

  // 3.5 Auto-migrate DB schema once per app version.
  // Keeps CLI/database features healthy after upgrades without manual commands.
  try {
    const { runAutoDbMigration } = require('../bootstrap/dbAutoMigration');
    await runAutoDbMigration({ silent, reason: 'cli-bootstrap' });
  } catch {
    // Non-critical: command handlers can still run with best-effort schema.
  }

  // 4. Register all model associations
  require('../models');

  // 5. Verify connection
  try {
    await _sequelize.authenticate();
    if (!silent) {
      const mode = process.env.DB_MODE || 'unknown';
      console.log(`  Database connected (${mode})`);
    }
  } catch (err) {
    if (!silent) {
      console.error('  Database connection failed:', err.message);
    }
  }

  // 6. Sync schema if requested
  if (syncSchema) {
    try {
      await _sequelize.sync({ force: false });
      if (!silent) console.log('  Schema synchronized');
    } catch (err) {
      if (!silent) console.error('  Schema sync failed:', err.message);
    }
  }

  _initialized = true;
  return { sequelize: _sequelize };
}

function isInitialized() {
  return _initialized;
}

/**
 * Suppress database.js module-level console output during first require.
 * Call before any require() that transitively loads database.js or models.
 * Safe to call multiple times (no-op after first restore).
 */
let _muted = false;
let _origLog, _origWarn;

function muteDbLogs() {
  if (_muted) return;
  _muted = true;
  _origLog = console.log;
  _origWarn = console.warn;
  console.log = () => {};
  console.warn = () => {};
}

function restoreDbLogs() {
  if (!_muted) return;
  _muted = false;
  console.log = _origLog;
  console.warn = _origWarn;
}

module.exports = { bootstrap, isInitialized, muteDbLogs, restoreDbLogs };
