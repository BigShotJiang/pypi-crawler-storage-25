/**
 * KHY upgraded AI entry — hardened prompt, purified input, compact context,
 * NL tool gateway fallback for models without native tool calling.
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');

let _chalk, _fmt;
const chalk = () => (_chalk ??= (require('chalk').default || require('chalk')));
const fmt = () => (_fmt ??= require('./formatters'));

const runtime = require('../services/khyUpgradeRuntime');

let _service = null;
let _gateway = null;
let _chatLatencyAutoTuner = null;
let _messages = [];
let _studyMode = false;
let _gatewayPreflightDone = false;
let _gatewayPreflightInFlight = null;
let _localWarmupAttemptedAdapters = new Set();
let _localWarmupInFlight = new Map();
let _autoTuneAnnouncement = { profile: '', preset: '', at: 0 };
let _pendingTaskGuard = null;
let _activeGatewayRequestSeq = 0;
const _activeGatewayRequests = new Map();

const MAX_HISTORY = 80;
const GLOBAL_CONVO_DIR = path.join(os.homedir(), '.khyquant', 'conversations');
const MAX_SAVED_CONVERSATIONS = 50; // per-folder limit (more generous than before)
const DEFAULT_AUTO_RESUME_WINDOW_MIN = 180;
const DEFAULT_PROJECT_MEMORY_MAX_CHARS = 5000;
const PROJECT_MEMORY_CONTEXT_TAG = '[ProjectMemoryBootstrap v1]';
const DEFAULT_AUTO_RESUME_SEGMENT_MODE = 'period';
const DEFAULT_TIMEZONE = 'Asia/Shanghai';

function _registerActiveGatewayRequest(abortController, meta = {}) {
  if (!abortController || typeof abortController.abort !== 'function') return '';
  _activeGatewayRequestSeq += 1;
  const requestId = `req-${Date.now().toString(36)}-${_activeGatewayRequestSeq}`;
  _activeGatewayRequests.set(requestId, {
    abortController,
    createdAt: Date.now(),
    adapter: String(meta.adapter || '').trim(),
  });
  return requestId;
}

function _unregisterActiveGatewayRequest(requestId) {
  if (!requestId) return;
  _activeGatewayRequests.delete(requestId);
}

function cancelActiveRequest(reason = 'Interrupted by user') {
  const entries = Array.from(_activeGatewayRequests.entries());
  if (entries.length === 0) return false;
  const abortReason = reason instanceof Error ? reason : new Error(String(reason || 'Interrupted by user'));
  let cancelled = false;
  for (const [requestId, info] of entries) {
    try {
      const ctrl = info && info.abortController;
      if (ctrl && !ctrl.signal?.aborted) {
        ctrl.abort(abortReason);
        cancelled = true;
      }
    } catch { /* best effort */ }
    _activeGatewayRequests.delete(requestId);
  }
  return cancelled;
}

/**
 * Get the per-folder conversation directory.
 * Uses projectMemoryService to derive a hash-based path for the current working directory.
 * Falls back to the global directory if projectMemoryService is unavailable.
 */
function getConvoDir(cwd) {
  try {
    const { getProjectDir } = require('../services/projectMemoryService');
    const projDir = getProjectDir(cwd || process.cwd());
    const dir = path.join(projDir, 'conversations');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
  } catch {
    return GLOBAL_CONVO_DIR;
  }
}

function _generateSessionId() {
  try {
    if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch { /* fallthrough */ }
  const tsHex = Date.now().toString(16).slice(-12).padStart(12, '0');
  const rand = crypto.randomBytes(10).toString('hex'); // 20 chars
  return `${tsHex}-${rand.slice(0, 4)}-${rand.slice(4, 8)}-${rand.slice(8, 12)}-${rand.slice(12)}`;
}

function _getAutoResumeWindowMs() {
  const raw = parseInt(String(process.env.KHY_AUTO_RESUME_WINDOW_MIN || DEFAULT_AUTO_RESUME_WINDOW_MIN), 10);
  if (Number.isFinite(raw) && raw <= 0) return 0;
  const mins = Number.isFinite(raw) ? raw : DEFAULT_AUTO_RESUME_WINDOW_MIN;
  return Math.max(5, mins) * 60 * 1000;
}

function _getAutoResumeSegmentMode() {
  const raw = String(process.env.KHY_AUTO_RESUME_SEGMENT_MODE || DEFAULT_AUTO_RESUME_SEGMENT_MODE).trim().toLowerCase();
  if (!raw) return DEFAULT_AUTO_RESUME_SEGMENT_MODE;
  if (['off', 'none', 'disable', 'disabled', 'false', '0'].includes(raw)) return 'none';
  if (['ampm', 'am_pm', 'halfday', 'am-pm'].includes(raw)) return 'ampm';
  if (['period', 'daypart', 'timeslot', 'segment'].includes(raw)) return 'period';
  return DEFAULT_AUTO_RESUME_SEGMENT_MODE;
}

function _localDateKey(date) {
  const parts = _getDatePartsInTimezone(date);
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function _periodBucket(date) {
  const parts = _getDatePartsInTimezone(date);
  const h = parts.hour;
  if (h < 6) return 'late-night';
  if (h < 12) return 'morning';
  if (h < 18) return 'afternoon';
  return 'evening';
}

function _segmentKey(date, mode) {
  if (mode === 'ampm') {
    const parts = _getDatePartsInTimezone(date);
    return parts.hour < 12 ? 'am' : 'pm';
  }
  if (mode === 'period') return _periodBucket(date);
  return 'all';
}

function _getTimezoneForSession() {
  const tz = String(process.env.KHY_TIMEZONE || DEFAULT_TIMEZONE).trim();
  return tz || DEFAULT_TIMEZONE;
}

function _getDatePartsInTimezone(dateLike) {
  const date = dateLike instanceof Date ? dateLike : new Date(dateLike);
  const fallback = {
    year: String(date.getFullYear()),
    month: String(date.getMonth() + 1).padStart(2, '0'),
    day: String(date.getDate()).padStart(2, '0'),
    hour: date.getHours(),
  };

  try {
    const fmt = new Intl.DateTimeFormat('en-CA', {
      timeZone: _getTimezoneForSession(),
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      hourCycle: 'h23',
    });
    const tokens = fmt.formatToParts(date);
    const byType = {};
    for (const token of tokens) byType[token.type] = token.value;
    const hour = parseInt(String(byType.hour || fallback.hour), 10);
    return {
      year: String(byType.year || fallback.year),
      month: String(byType.month || fallback.month).padStart(2, '0'),
      day: String(byType.day || fallback.day).padStart(2, '0'),
      hour: Number.isFinite(hour) ? hour : fallback.hour,
    };
  } catch {
    return fallback;
  }
}

function _isSameAutoResumeSegment(lastDate, nowDate) {
  const mode = _getAutoResumeSegmentMode();
  if (mode === 'none') return true;
  if (_localDateKey(lastDate) !== _localDateKey(nowDate)) return false;
  return _segmentKey(lastDate, mode) === _segmentKey(nowDate, mode);
}

function _getProjectMemoryCandidates(cwd = process.cwd()) {
  const files = [];
  try {
    const { getMemoryDir, getProjectDir } = require('../services/projectMemoryService');
    const memoryDir = getMemoryDir(cwd);
    const projectDir = getProjectDir(cwd);
    files.push(path.join(memoryDir, 'memory.md'));
    files.push(path.join(memoryDir, 'MEMORY.md'));
    files.push(path.join(projectDir, 'memory.md'));
    files.push(path.join(projectDir, 'MEMORY.md'));
  } catch { /* ignore */ }
  files.push(path.join(os.homedir(), '.khy', 'memory', 'MEMORY.md'));
  return [...new Set(files)];
}

function loadProjectMemoryContext(options = {}) {
  try {
    const alreadyInjected = _messages.some((m) => (
      String(m?.role || '').toLowerCase() === 'tool'
      && String(m?.content || '').includes(PROJECT_MEMORY_CONTEXT_TAG)
    ));
    if (alreadyInjected && !options.force) {
      return { loaded: false, reason: 'already-loaded' };
    }

    const rawMaxChars = parseInt(String(process.env.KHY_PROJECT_MEMORY_MAX_CHARS || DEFAULT_PROJECT_MEMORY_MAX_CHARS), 10);
    const maxChars = Math.max(400, Number.isFinite(rawMaxChars) ? rawMaxChars : DEFAULT_PROJECT_MEMORY_MAX_CHARS);
    const cwd = options.cwd || process.cwd();
    const candidates = _getProjectMemoryCandidates(cwd);

    for (const filePath of candidates) {
      try {
        if (!fs.existsSync(filePath)) continue;
        const content = String(fs.readFileSync(filePath, 'utf-8') || '').trim();
        if (!content) continue;

        const truncated = content.length > maxChars;
        const summary = truncated ? `${content.slice(0, maxChars)}\n\n[Memory truncated for context budget]` : content;
        const payload = [
          PROJECT_MEMORY_CONTEXT_TAG,
          `source: ${filePath}`,
          'Use this memory as background context. User latest explicit instructions always win.',
          '',
          summary,
        ].join('\n');

        if (options.prepend) _messages = [{ role: 'tool', content: payload }, ..._messages];
        else _messages.push({ role: 'tool', content: payload });
        if (_messages.length > MAX_HISTORY) _messages = _messages.slice(-MAX_HISTORY);

        return {
          loaded: true,
          file: filePath,
          chars: Math.min(content.length, maxChars),
          truncated,
        };
      } catch { /* try next candidate */ }
    }
  } catch { /* ignore */ }

  return { loaded: false, reason: 'not-found' };
}
const ENV_PATH = process.env.KHY_ENV_FILE
  ? path.resolve(process.env.KHY_ENV_FILE)
  : path.resolve(__dirname, '../../.env');
const AI_UNRESTRICTED_ENV = 'KHY_AI_UNRESTRICTED';
const AI_TECH_DETAILS_ENV = 'KHY_AI_TECH_DETAILS';

const EFFORT_PRESETS = {
  max:    { temperature: 0.2, maxTokens: 16384, label: '最高精度', thinking: { budgetTokens: 10000 } },
  high:   { temperature: 0.3, maxTokens: 8192, label: '高' },
  medium: { temperature: 0.5, maxTokens: 4096, label: '标准' },
  low:    { temperature: 0.7, maxTokens: 2048, label: '快速' },
};

const MODEL_CAPABILITIES = {
  'claude-3-5-sonnet': { code: 5, reasoning: 5, creative: 4, context: 200000, label: 'Claude 3.5 Sonnet' },
  'claude-sonnet-4':   { code: 5, reasoning: 5, creative: 4, context: 200000, label: 'Claude Sonnet 4' },
  'claude-opus-4':     { code: 5, reasoning: 5, creative: 5, context: 200000, label: 'Claude Opus 4' },
  'claude-3-haiku':    { code: 3, reasoning: 3, creative: 3, context: 200000, label: 'Claude 3 Haiku' },
  'gpt-4o':            { code: 5, reasoning: 4, creative: 4, context: 128000, label: 'GPT-4o' },
  'gpt-4o-mini':       { code: 3, reasoning: 3, creative: 3, context: 128000, label: 'GPT-4o Mini' },
  'qwen-turbo':        { code: 3, reasoning: 3, creative: 3, context: 8000, label: '通义千问 Turbo' },
  'qwen-plus':         { code: 4, reasoning: 4, creative: 3, context: 32000, label: '通义千问 Plus' },
  'glm-4':             { code: 3, reasoning: 3, creative: 3, context: 128000, label: 'GLM-4' },
  'deepseek-v2':       { code: 4, reasoning: 4, creative: 3, context: 128000, label: 'DeepSeek V2' },
  'llama-3.3':         { code: 3, reasoning: 3, creative: 2, context: 128000, label: 'Llama 3.3 (Groq)' },
};

let _currentEffort = 'medium';

function _envToBool(v) {
  const s = String(v || '').trim().toLowerCase();
  return s === '1' || s === 'true' || s === 'on' || s === 'yes' || s === 'y';
}

function _onOff(v) {
  return v ? chalk().green('ON') : chalk().dim('OFF');
}

function _markFailure() {
  if (!process.exitCode || process.exitCode === 0) {
    process.exitCode = 1;
  }
}

function _setEnvVar(key, value) {
  let envContent = '';
  try { envContent = fs.readFileSync(ENV_PATH, 'utf-8'); } catch { /* no .env */ }
  const regex = new RegExp(`^${key}=.*$`, 'm');
  const line = `${key}=${value}`;
  if (regex.test(envContent)) {
    envContent = envContent.replace(regex, line);
  } else {
    envContent = envContent.trimEnd() + '\n' + line + '\n';
  }
  fs.writeFileSync(ENV_PATH, envContent, 'utf-8');
  process.env[key] = String(value);
}

function _getEnvVar(key) {
  const runtimeVal = process.env[key];
  if (runtimeVal !== undefined && String(runtimeVal).trim() !== '') {
    return String(runtimeVal).trim();
  }
  try {
    const envContent = fs.readFileSync(ENV_PATH, 'utf-8');
    const regex = new RegExp(`^${key}=(.*)$`, 'm');
    const match = envContent.match(regex);
    if (!match) return '';
    return String(match[1] || '').trim().replace(/^['"]|['"]$/g, '');
  } catch {
    return '';
  }
}

function _normalizeSwitchInput(options = {}, args = []) {
  const o = { ...options };
  const firstArg = String(args[0] || '').toLowerCase();
  if (firstArg === 'on') o.on = true;
  if (firstArg === 'off') o.off = true;
  if (firstArg === 'status') o.status = true;
  return o;
}

function _readSwitchStates() {
  const techEnabled = _envToBool(_getEnvVar(AI_TECH_DETAILS_ENV));
  const unrestrictedEnabled = _envToBool(_getEnvVar(AI_UNRESTRICTED_ENV));
  return { techEnabled, unrestrictedEnabled };
}

function _readOwnerControlStatus() {
  try {
    const owner = require('../services/ownerControlService');
    return owner.getOwnerControlStatus();
  } catch {
    return { configured: false, updatedAt: null, version: 1 };
  }
}

async function _askSecret(message) {
  const inquirer = require('inquirer');
  const { secret } = await inquirer.prompt([{
    type: 'password',
    name: 'secret',
    message,
    mask: '*',
    validate: v => String(v || '').trim().length > 0 || 'Secret cannot be empty',
  }]);
  return String(secret || '').trim();
}

async function _requireOwnerSecret(options = {}) {
  const owner = require('../services/ownerControlService');
  if (!owner.isOwnerControlConfigured()) {
    return {
      ok: false,
      error: 'Owner control is not initialized. Run: ai owner init',
    };
  }

  let secret = String(
    options.secret
      || options.key
      || options.token
      || options.ownerSecret
      || options['owner-secret']
      || ''
  ).trim();

  if (!secret && process.stdin.isTTY && process.stdout.isTTY) {
    try {
      secret = await _askSecret('Owner secret:');
    } catch {
      return { ok: false, error: 'Owner secret is required.' };
    }
  }

  if (!secret) {
    return {
      ok: false,
      error: 'Owner secret is required. Use --secret <value> or run in interactive terminal.',
    };
  }

  const verify = owner.verifyOwnerSecret(secret);
  if (!verify.ok) {
    return { ok: false, error: verify.error || 'Owner secret verification failed.' };
  }
  return { ok: true, secret };
}

function getService() {
  if (!_service) {
    const MultiFreeService = require('../services/multiFreeService');
    _service = new MultiFreeService();
  }
  return _service;
}

function getGateway() {
  if (!_gateway) {
    _gateway = require('../services/gateway/aiGateway');
  }
  return _gateway;
}

function getChatLatencyAutoTuner() {
  if (!_chatLatencyAutoTuner) {
    _chatLatencyAutoTuner = require('../services/chatLatencyAutoTuner');
  }
  return _chatLatencyAutoTuner;
}

function _isLocalAdapterKey(key) {
  const normalized = String(key || '').trim().toLowerCase();
  return normalized === 'localllm' || normalized === 'ollama';
}

function _resolveLocalWarmupTarget(gateway, preferredAdapterHint = undefined) {
  const preferred = String(
    preferredAdapterHint !== undefined
      ? preferredAdapterHint
      : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
  ).trim().toLowerCase();
  if (_isLocalAdapterKey(preferred)) return preferred;
  if (preferred && preferred !== 'auto') return '';
  try {
    const firstAvailable = String(gateway.getFirstAvailableAdapter?.() || '').trim().toLowerCase();
    if (_isLocalAdapterKey(firstAvailable)) return firstAvailable;
  } catch { /* best effort */ }
  return '';
}

function _toGatewayLocalKey(key) {
  return String(key || '').trim().toLowerCase() === 'localllm' ? 'localLLM' : 'ollama';
}

let _localAiAutoEnvCache = null;
function _getLocalAiAutoEnv() {
  if (_localAiAutoEnvCache) return _localAiAutoEnvCache;
  try {
    const hw = require('../services/hardwareProfileService');
    const tuning = hw && typeof hw.recommendLocalAiTuning === 'function'
      ? hw.recommendLocalAiTuning('auto')
      : null;
    _localAiAutoEnvCache = (tuning && tuning.env) ? tuning.env : {};
  } catch {
    _localAiAutoEnvCache = {};
  }
  return _localAiAutoEnvCache;
}

function _readIntWithAutoDefault(envKey, autoDefault, hardFallback) {
  const raw = process.env[envKey];
  if (raw !== undefined && String(raw).trim() !== '') {
    const v = parseInt(String(raw).trim(), 10);
    if (Number.isFinite(v)) return v;
  }
  const autoV = parseInt(String(autoDefault || ''), 10);
  if (Number.isFinite(autoV)) return autoV;
  return hardFallback;
}

function _resolveLocalPreferredMaxTokens(baseTokens, context = {}) {
  const normalizedBase = Math.max(64, parseInt(baseTokens, 10) || 2048);
  const isLocalPreferredAdapter = !!context.isLocalPreferredAdapter;
  const preferredAdapter = String(context.preferredAdapter || '').trim().toLowerCase();
  const localLLMStatus = context.localLLMStatus || null;
  const autoEnv = _getLocalAiAutoEnv();
  const disableCapRaw = process.env.KHY_LOCAL_DISABLE_TOKEN_CAP !== undefined
    ? process.env.KHY_LOCAL_DISABLE_TOKEN_CAP
    : autoEnv.KHY_LOCAL_DISABLE_TOKEN_CAP;
  const disableCap = String(disableCapRaw || 'false').toLowerCase() === 'true';
  if (!isLocalPreferredAdapter || disableCap) {
    return { maxTokens: normalizedBase, capped: false, cap: normalizedBase };
  }

  const fallbackWarmCap = Math.max(
    256,
    _readIntWithAutoDefault('KHY_LOCAL_WARM_MAX_TOKENS', autoEnv.KHY_LOCAL_WARM_MAX_TOKENS, 3072)
  );
  const fallbackColdCap = Math.max(
    128,
    _readIntWithAutoDefault('KHY_LOCAL_COLD_MAX_TOKENS', autoEnv.KHY_LOCAL_COLD_MAX_TOKENS, 1536)
  );
  let cap = fallbackWarmCap;
  if (preferredAdapter === 'ollama') {
    cap = Math.max(
      128,
      _readIntWithAutoDefault('KHY_OLLAMA_MAX_TOKENS', autoEnv.KHY_OLLAMA_MAX_TOKENS, fallbackWarmCap)
    );
  } else if (localLLMStatus && localLLMStatus.loaded === false) {
    cap = fallbackColdCap;
  }

  const resolved = Math.max(64, Math.min(normalizedBase, cap));
  return {
    maxTokens: resolved,
    capped: resolved < normalizedBase,
    cap,
  };
}

async function _maybeWarmupLocalPreferredOnce(options = {}) {
  const autoEnv = _getLocalAiAutoEnv();
  const warmupOnceRaw = process.env.KHY_LOCAL_WARMUP_ONCE !== undefined
    ? process.env.KHY_LOCAL_WARMUP_ONCE
    : autoEnv.KHY_LOCAL_WARMUP_ONCE;
  if (String(warmupOnceRaw || 'false').toLowerCase() === 'false') return;

  const gateway = getGateway();
  if (!gateway._initialized) await gateway.init();

  const target = _resolveLocalWarmupTarget(gateway, options.preferredAdapter);
  if (!target) return;
  if (_localWarmupAttemptedAdapters.has(target)) return;

  const existing = _localWarmupInFlight.get(target);
  if (existing) {
    await existing;
    return;
  }

  const onStatus = typeof options.onStatus === 'function' ? options.onStatus : null;
  const adapterLabel = target === 'ollama' ? 'Ollama' : '本地模型';
  const maxWaitMs = Math.max(
    1000,
    _readIntWithAutoDefault(
      target === 'ollama' ? 'KHY_OLLAMA_WARMUP_WAIT_MS' : 'KHY_LOCAL_WARMUP_WAIT_MS',
      target === 'ollama' ? autoEnv.KHY_OLLAMA_WARMUP_WAIT_MS : autoEnv.KHY_LOCAL_WARMUP_WAIT_MS,
      target === 'ollama' ? 8000 : 30000
    )
  );
  const gatewayAdapterKey = _toGatewayLocalKey(target);

  const warmupTask = (async () => {
    if (onStatus) {
      try { onStatus(`${adapterLabel} 预热中（仅首次），正在发送预热 ping...`); } catch { /* best effort */ }
    }

    const warmupRun = gateway.generateWithAdapter(gatewayAdapterKey, 'Reply with exactly: OK', {
      maxTokens: 24,
      temperature: 0,
      top_p: 1,
      timeoutMs: maxWaitMs,
      userMessage: '[warmup]',
    }).catch((err) => ({ success: false, error: err && err.message ? err.message : String(err) }));

    const timeoutToken = Symbol('warmup-timeout');
    const raced = await Promise.race([
      warmupRun,
      new Promise((resolve) => {
        const t = setTimeout(() => resolve(timeoutToken), maxWaitMs + 300);
        if (t.unref) t.unref();
      }),
    ]);

    if (raced === timeoutToken) {
      if (onStatus) {
        try {
          onStatus(`${adapterLabel} 预热仍在进行（>${Math.round(maxWaitMs / 1000)}s），将并行继续并直接发起正式请求...`);
        } catch { /* best effort */ }
      }
      return;
    }

    if (raced && raced.success) {
      if (onStatus) {
        try { onStatus(`${adapterLabel} 预热完成，开始正式请求...`); } catch { /* best effort */ }
      }
      return;
    }

    if (onStatus) {
      const reason = String((raced && (raced.error || raced.content)) || 'unknown').replace(/\s+/g, ' ').trim().slice(0, 100);
      try { onStatus(`${adapterLabel} 预热失败（${reason || 'unknown'}），将直接发起正式请求...`); } catch { /* best effort */ }
    }
  })();

  _localWarmupInFlight.set(target, warmupTask);
  try {
    await warmupTask;
  } finally {
    _localWarmupAttemptedAdapters.add(target);
    _localWarmupInFlight.delete(target);
  }
}

function getSecurityDir() {
  try {
    const { getSecurityDirective } = require('../services/securityGuardService');
    return getSecurityDirective() || '';
  } catch {
    return '';
  }
}

function saveConversation() {
  if (_messages.length === 0) return { success: false, reason: 'empty' };
  try {
    const convoDir = getConvoDir();
    if (!fs.existsSync(convoDir)) fs.mkdirSync(convoDir, { recursive: true });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const suffix = Math.random().toString(36).slice(2, 6);
    const filename = `${timestamp}-${suffix}.json`;
    const sessionId = _generateSessionId();

    // Save a compacted summary instead of raw messages so that /resume
    // loads a concise, high-value context rather than the full history.
    const snapshotMessages = _messages.slice();
    const originalCount = snapshotMessages.length;
    let savedMessages = snapshotMessages;

    if (originalCount > 6) {
      // Temporarily swap _messages to compact the snapshot without
      // mutating the live conversation (session may continue).
      const liveMessages = _messages;
      _messages = snapshotMessages;
      try {
        compactHistory({
          keepRecent: Math.min(6, Math.max(2, Math.floor(originalCount * 0.2))),
          mode: 'aggressive',
        });
        savedMessages = _messages;
      } finally {
        _messages = liveMessages;
      }
    }

    const data = {
      sessionId,
      timestamp: new Date().toISOString(),
      cwd: process.cwd(),
      messages: savedMessages,
      messageCount: savedMessages.length,
      originalMessageCount: originalCount,
    };
    const filePath = path.join(convoDir, filename);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');

    const files = fs.readdirSync(convoDir).filter(f => f.endsWith('.json')).sort();
    while (files.length > MAX_SAVED_CONVERSATIONS) {
      fs.unlinkSync(path.join(convoDir, files.shift()));
    }
    return {
      success: true,
      sessionId,
      file: filename,
      filePath,
      timestamp: data.timestamp,
      messageCount: data.messageCount,
    };
  } catch {
    return { success: false, reason: 'write_failed' };
  }
}

function loadLastConversation() {
  try {
    const convoDir = getConvoDir();
    if (!fs.existsSync(convoDir)) return null;
    const files = fs.readdirSync(convoDir).filter(f => f.endsWith('.json')).sort();
    if (files.length === 0) return null;
    const latest = fs.readFileSync(path.join(convoDir, files[files.length - 1]), 'utf-8');
    return JSON.parse(latest);
  } catch {
    return null;
  }
}

function listConversations() {
  try {
    const convoDir = getConvoDir();
    if (!fs.existsSync(convoDir)) return [];
    const files = fs.readdirSync(convoDir).filter(f => f.endsWith('.json')).sort().reverse();
    return files.map(file => {
      try {
        const data = JSON.parse(fs.readFileSync(path.join(convoDir, file), 'utf-8'));
        const sessionId = String(data.sessionId || '').trim() || String(file).replace(/\.json$/i, '');
        return {
          file,
          sessionId,
          timestamp: data.timestamp,
          messageCount: data.messageCount || data.messages?.length || 0,
        };
      } catch {
        return { file, sessionId: String(file).replace(/\.json$/i, ''), timestamp: '', messageCount: 0 };
      }
    });
  } catch {
    return [];
  }
}

function findConversationByRef(ref) {
  const key = String(ref || '').trim();
  if (!key) return null;
  const convos = listConversations();
  if (convos.length === 0) return null;

  const normalizedFile = key.endsWith('.json') ? key : `${key}.json`;
  const lower = key.toLowerCase();
  const lowerFile = normalizedFile.toLowerCase();

  let match = convos.find(c => c.file === key || c.file === normalizedFile || c.sessionId === key);
  if (match) return match;

  match = convos.find(c => {
    const sid = String(c.sessionId || '').toLowerCase();
    const file = String(c.file || '').toLowerCase();
    return sid === lower || file === lower || file === lowerFile;
  });
  if (match) return match;

  const sidPrefix = convos.filter(c => String(c.sessionId || '').toLowerCase().startsWith(lower));
  if (sidPrefix.length === 1) return sidPrefix[0];

  const filePrefix = convos.filter(c => String(c.file || '').replace(/\.json$/i, '').toLowerCase().startsWith(lower));
  if (filePrefix.length === 1) return filePrefix[0];

  return null;
}

function resumeConversation(file) {
  try {
    let data;
    if (file) {
      const convoDir = getConvoDir();
      data = JSON.parse(fs.readFileSync(path.join(convoDir, file), 'utf-8'));
    } else {
      data = loadLastConversation();
    }
    if (data && data.messages && data.messages.length > 0) {
      const rawMessages = data.messages.slice(-MAX_HISTORY);
      const originalCount = rawMessages.length;

      // Instead of restoring raw messages directly, compact them into a
      // concise summary so the new session starts clean with only the
      // essential context from the previous conversation.
      _messages = rawMessages;
      const compactResult = compactHistory({
        keepRecent: Math.min(4, Math.max(2, Math.floor(rawMessages.length * 0.15))),
        mode: 'aggressive',
      });

      return {
        success: true,
        messageCount: _messages.length,
        originalCount,
        compacted: compactResult.changed,
        timestamp: data.timestamp,
      };
    }
  } catch {}
  return { success: false };
}

function autoResumeLastSession() {
  try {
    // Per-folder session: load from current directory's conversation store
    const last = loadLastConversation();
    if (!last || !last.timestamp || !last.messages || last.messages.length === 0) return null;
    const lastAt = new Date(last.timestamp);
    if (!Number.isFinite(lastAt.getTime())) return null;
    const now = new Date();
    if (!_isSameAutoResumeSegment(lastAt, now)) return null;
    // No cwd check needed — storage is already per-folder via getConvoDir()
    const elapsed = Date.now() - lastAt.getTime();
    const maxAge = _getAutoResumeWindowMs();
    if (maxAge <= 0) return null;
    if (elapsed > maxAge) return null;
    _messages = last.messages.slice(-MAX_HISTORY);
    // A5: 标记 session 恢复，防止 contextCompressor 立即重新压缩已压缩内容
    try { require('../services/contextCompressor').markSessionResumed(); } catch {}
    return { resumed: true, messageCount: _messages.length, timestamp: last.timestamp, cwd: last.cwd };
  } catch {
    return null;
  }
}

function getAiStatus() {
  return getService().getStatus();
}

function getActiveProvider() {
  try {
    const gw = getGateway();
    const active = gw.getActiveAdapter();
    if (active) {
      const suffix = active.activeModel ? ` · ${active.activeModel}` : '';
      return `${active.name}${suffix}`;
    }
  } catch {}
  const svc = getService();
  const provider = svc.getAvailableProvider();
  return provider ? provider.name : null;
}

function _getModelInfo() {
  try {
    const gw = getGateway();
    const active = gw.getActiveAdapter();
    if (active) {
      return { model: active.activeModel || active.name, adapter: active.name };
    }
  } catch {}
  return {};
}

function _getStudyModeRuntimeMeta(preferredAdapter, preferredModel) {
  let adapter = String(preferredAdapter || '').trim();
  let model = String(preferredModel || '').trim();

  try {
    const gw = getGateway();
    const active = gw.getActiveAdapter?.();
    if (!adapter && active?.name) adapter = String(active.name).trim();
    if (!model && active?.activeModel) model = String(active.activeModel).trim();
    if (!model && active?.name) model = String(active.name).trim();
  } catch { /* best effort */ }

  return {
    adapter: adapter || null,
    model: model || null,
  };
}

function enableStudyMode() { _studyMode = true; }
function disableStudyMode() { _studyMode = false; }
function isStudyMode() { return _studyMode; }

async function handleAiStatus(options = {}) {
  const { printSuccess, printError, printInfo, withSpinner } = fmt();
  const quick = !!options.quick;
  const status = getAiStatus();
  const switchStates = _readSwitchStates();
  const ownerStatus = _readOwnerControlStatus();

  if (status.available) {
    printSuccess(`AI 服务可用 — ${status.provider}`);
    if (status.configuredProviders.length > 1) {
      printInfo(`已配置 ${status.configuredProviders.length} 个提供商: ${status.configuredProviders.join(', ')}`);
    }
    if (!quick) {
      const svc = getService();
      const test = await withSpinner('测试 AI 连接...', () => svc.testConnection());
      if (test.success) printSuccess(`连接正常 (${test.provider})`);
      else printError('连接测试失败');
    } else {
      printInfo('快速状态模式：已跳过实时连通性测试');
    }
  } else {
    printError('未配置 AI 密钥');
    printInfo('运行 ai config 配置 API 密钥');
  }

  console.log('');
  printInfo(`技术细节开关: ${_onOff(switchStates.techEnabled)}`);
  printInfo(`开放模式开关: ${_onOff(switchStates.unrestrictedEnabled)}`);
  printInfo(`Owner 控制: ${ownerStatus.configured ? chalk().green('CONFIGURED') : chalk().yellow('NOT CONFIGURED')}`);
  if (ownerStatus.updatedAt) {
    printInfo(`Owner 更新: ${new Date(ownerStatus.updatedAt).toLocaleString('zh-CN')}`);
  }
  if (!ownerStatus.configured) {
    printInfo('建议先运行 ai owner init 初始化 Owner Secret，再使用 ai tech/ai unrestricted');
  }
}

async function handleAiConfig() {
  fmt().printInfo('此命令已迁移到 khy gateway config，正在跳转...');
  const { handleGatewayConfig } = require('./handlers/gateway');
  await handleGatewayConfig();
}

function setEffort(level) {
  if (EFFORT_PRESETS[level]) {
    _currentEffort = level;
    return true;
  }
  return false;
}

function getEffort() { return _currentEffort; }
function getEffortPresets() { return EFFORT_PRESETS; }

function clearHistory() {
  _messages = [];
  _gatewayPreflightDone = false;
  _gatewayPreflightInFlight = null;
  _localWarmupAttemptedAdapters = new Set();
  _localWarmupInFlight = new Map();
  _pendingTaskGuard = null;
}

function _normalizeSummaryText(text = '', maxLen = 220) {
  const s = String(text || '')
    .replace(/\s+/g, ' ')
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/gi, '')
    .trim();
  if (!s) return '';
  if (s.length <= maxLen) return s;
  return `${s.slice(0, Math.max(16, maxLen - 1))}…`;
}

function getConversationStats() {
  const stats = {
    totalMessages: _messages.length,
    userMessages: 0,
    assistantMessages: 0,
    toolMessages: 0,
    systemMessages: 0,
    otherMessages: 0,
    effort: _currentEffort,
    studyMode: _studyMode,
  };

  for (const msg of _messages) {
    const role = String(msg?.role || '').toLowerCase();
    if (role === 'user') stats.userMessages += 1;
    else if (role === 'assistant') stats.assistantMessages += 1;
    else if (role === 'tool') stats.toolMessages += 1;
    else if (role === 'system') stats.systemMessages += 1;
    else stats.otherMessages += 1;
  }

  return stats;
}

function getConversation() {
  return _messages.map((msg) => ({ ...msg }));
}

function getContextLimit(modelHint = '') {
  const hint = String(modelHint || '').trim() || _guessModelHint();
  return _resolveModelContextLimit(hint);
}

function compactConversation(options = {}) {
  return compactHistory(options);
}

function compactHistory(options = {}) {
  const previousCount = _messages.length;
  const keepRecent = Math.max(
    4,
    Math.min(40, Number.isFinite(Number(options.keepRecent)) ? Math.floor(Number(options.keepRecent)) : 12)
  );
  const focus = _normalizeSummaryText(options.instructions || options.focus || '', 300);

  if (previousCount <= (keepRecent + 1)) {
    return {
      success: true,
      changed: false,
      previousCount,
      nextCount: previousCount,
      compactedCount: 0,
      keepRecent,
      mode: 'none',
    };
  }

  const modeConfigs = {
    light: {
      maxItems: 4,
      maxToolItems: 2,
      maxPointChars: 160,
      maxSummaryChars: 2400,
      continuityHint: 'Prefer concise continuation and ask for missing details early.',
    },
    balanced: {
      maxItems: 6,
      maxToolItems: 3,
      maxPointChars: 220,
      maxSummaryChars: 3800,
      continuityHint: 'Continue from established decisions and prioritize recent constraints.',
    },
    aggressive: {
      maxItems: 10,
      maxToolItems: 5,
      maxPointChars: 300,
      maxSummaryChars: 6200,
      continuityHint: 'Retain as much decision history as possible and avoid re-asking settled topics.',
    },
  };

  let mode = String(options.mode || 'balanced').trim().toLowerCase();
  if (mode === 'auto') {
    if (previousCount >= 60 || keepRecent <= 8) mode = 'aggressive';
    else if (previousCount >= 28) mode = 'balanced';
    else mode = 'light';
  }
  if (!modeConfigs[mode]) mode = 'balanced';
  const cfg = modeConfigs[mode];

  const boundary = Math.max(0, previousCount - keepRecent);
  const toCompact = _messages.slice(0, boundary);
  const keepTail = _messages.slice(boundary);

  const userPoints = [];
  const assistantPoints = [];
  const toolPoints = [];

  const pushUnique = (arr, text, limit) => {
    if (!text || arr.length >= limit) return;
    if (arr.includes(text)) return;
    arr.push(text);
  };

  // Prefer recent history points from the compacted segment.
  for (const msg of [...toCompact].reverse()) {
    const role = String(msg?.role || '').toLowerCase();
    const normalized = _normalizeSummaryText(msg?.content || '', cfg.maxPointChars);
    if (!normalized) continue;

    if (role === 'user') {
      pushUnique(userPoints, normalized, cfg.maxItems);
      continue;
    }
    if (role === 'assistant') {
      pushUnique(assistantPoints, normalized, cfg.maxItems);
      continue;
    }
    if (role === 'tool') {
      pushUnique(toolPoints, normalized, cfg.maxToolItems);
    }
  }

  const latestTailUser = [...keepTail].reverse().find(m => String(m?.role || '').toLowerCase() === 'user');
  const latestTailAssistant = [...keepTail].reverse().find(m => String(m?.role || '').toLowerCase() === 'assistant');

  const lines = [];
  lines.push(`[ContextCompact v2 @ ${new Date().toISOString()}]`);
  lines.push(`Mode: ${mode}. Compacted: ${toCompact.length}. Kept recent turns: ${keepTail.length}.`);
  lines.push(`Continuation rule: ${cfg.continuityHint}`);
  if (focus) lines.push(`Focus priority: ${focus}`);

  if (userPoints.length > 0) {
    lines.push('');
    lines.push('Primary user goals already discussed:');
    userPoints.forEach((item, idx) => lines.push(`${idx + 1}. ${item}`));
  }

  if (assistantPoints.length > 0) {
    lines.push('');
    lines.push('Established assistant conclusions/actions:');
    assistantPoints.forEach((item, idx) => lines.push(`${idx + 1}. ${item}`));
  }

  if (toolPoints.length > 0) {
    lines.push('');
    lines.push('Tool outcomes worth retaining:');
    toolPoints.forEach((item, idx) => lines.push(`${idx + 1}. ${item}`));
  }

  lines.push('');
  lines.push('Pending context to resume immediately:');
  if (latestTailUser) {
    lines.push(`- Latest user turn: ${_normalizeSummaryText(latestTailUser.content || '', 260)}`);
  }
  if (latestTailAssistant) {
    lines.push(`- Latest assistant turn: ${_normalizeSummaryText(latestTailAssistant.content || '', 260)}`);
  }
  if (!latestTailUser && !latestTailAssistant) {
    lines.push('- No recent tail content was available.');
  }

  lines.push('');
  lines.push('Resume instructions:');
  lines.push('1. Treat this compact block as authoritative memory for earlier turns.');
  lines.push('2. Do not re-ask solved questions unless user explicitly reopens them.');
  lines.push('3. Prioritize recent tail turns over older compacted bullets when conflicts appear.');

  let summary = lines.join('\n').trim();
  if (summary.length > cfg.maxSummaryChars) {
    summary = `${summary.slice(0, cfg.maxSummaryChars - 1)}…`;
  }

  // 修复: 压缩摘要用 user 角色，并确保与 keepTail 之间角色交替正确
  // 之前用 role:'tool' 会被 _buildStructuredMessages 转为 user，与 keepTail 首条 user 消息
  // 形成连续 user-user，导致 API 400。
  const summaryMsg = { role: 'user', content: summary };

  // 确保角色交替：如果 keepTail 第一条也是 user，插入一个 assistant 桥接
  const firstKept = keepTail[0];
  const firstKeptRole = String(firstKept?.role || '').toLowerCase();
  if (firstKeptRole === 'user') {
    _messages = [summaryMsg, { role: 'assistant', content: '好的，我已了解上下文，继续处理你的请求。' }, ...keepTail];
  } else {
    _messages = [summaryMsg, ...keepTail];
  }
  if (_messages.length > MAX_HISTORY) _messages = _messages.slice(-MAX_HISTORY);

  return {
    success: true,
    changed: true,
    previousCount,
    nextCount: _messages.length,
    compactedCount: toCompact.length,
    keepRecent,
    mode,
    summaryChars: summary.length,
  };
}


async function handleAiOwner(action = 'status', options = {}) {
  const { printSuccess, printError, printInfo } = fmt();
  const owner = require('../services/ownerControlService');
  const cmd = String(action || 'status').toLowerCase();

  if (cmd === 'status') {
    const st = owner.getOwnerControlStatus();
    printInfo(`Owner 控制: ${st.configured ? chalk().green('CONFIGURED') : chalk().yellow('NOT CONFIGURED')}`);
    if (st.updatedAt) {
      printInfo(`最近更新: ${new Date(st.updatedAt).toLocaleString('zh-CN')}`);
    }
    if (!st.configured) {
      printInfo('运行 ai owner init 初始化 Owner Secret');
    }
    return;
  }

  if (cmd === 'init') {
    if (owner.isOwnerControlConfigured()) {
      printError('Owner 控制已初始化。若要更换请使用 ai owner rotate');
      _markFailure();
      return;
    }

    let secret = String(options.secret || options.key || '').trim();
    let confirm = String(options.confirm || '').trim();
    if (!secret) secret = await _askSecret('Set owner secret (at least 8 chars):');
    if (!confirm) confirm = await _askSecret('Confirm owner secret:');
    if (secret !== confirm) {
      printError('Secret confirmation mismatch.');
      _markFailure();
      return;
    }

    const result = owner.initializeOwnerControl(secret);
    if (!result.ok) {
      printError(result.error || 'Owner control initialization failed.');
      _markFailure();
      return;
    }
    printSuccess('Owner control initialized.');
    printInfo('后续敏感开关操作需要 Owner Secret 验证。');
    return;
  }

  if (cmd === 'rotate') {
    const verify = await _requireOwnerSecret(options);
    if (!verify.ok) {
      printError(verify.error);
      _markFailure();
      return;
    }

    let nextSecret = String(options.next || options.new || '').trim();
    let confirm = String(options.confirm || '').trim();
    if (!nextSecret) nextSecret = await _askSecret('New owner secret (at least 8 chars):');
    if (!confirm) confirm = await _askSecret('Confirm new owner secret:');
    if (nextSecret !== confirm) {
      printError('New secret confirmation mismatch.');
      _markFailure();
      return;
    }

    const rotated = owner.rotateOwnerSecret(verify.secret, nextSecret);
    if (!rotated.ok) {
      printError(rotated.error || 'Owner secret rotate failed.');
      _markFailure();
      return;
    }
    printSuccess('Owner secret rotated.');
    return;
  }

  printError('用法: ai owner status | ai owner init | ai owner rotate');
  _markFailure();
}

async function handleAiTech(options = {}, args = []) {
  const { printSuccess, printError, printInfo, printWarn } = fmt();
  const opts = _normalizeSwitchInput(options, args);
  const { techEnabled } = _readSwitchStates();

  if (!!opts.on === !!opts.off) {
    if (opts.status || (!opts.on && !opts.off)) {
      printInfo(`技术细节开关当前状态: ${_onOff(techEnabled)}`);
      if (!techEnabled) {
        printInfo('开启后可回答项目架构与实现细节。');
      }
      return;
    }
    printError('用法: ai tech --on | ai tech --off | ai tech --status');
    _markFailure();
    return;
  }

  const verify = await _requireOwnerSecret(opts);
  if (!verify.ok) {
    printError(verify.error);
    _markFailure();
    return;
  }

  const nextVal = opts.on ? 'true' : 'false';
  _setEnvVar(AI_TECH_DETAILS_ENV, nextVal);
  printSuccess(`技术细节开关已${opts.on ? '开启' : '关闭'} (${AI_TECH_DETAILS_ENV}=${nextVal})`);
  if (opts.on) {
    printWarn('技术细节模式已开启，AI 可回答项目实现细节；上线发布前建议关闭。');
  } else {
    printInfo('生产发布建议：保持技术细节开关关闭。');
  }
}

async function handleAiUnrestricted(options = {}, args = []) {
  const { printSuccess, printError, printInfo, printWarn } = fmt();
  const opts = _normalizeSwitchInput(options, args);
  const { unrestrictedEnabled } = _readSwitchStates();

  if (!!opts.on === !!opts.off) {
    if (opts.status || (!opts.on && !opts.off)) {
      printInfo(`开放模式当前状态: ${_onOff(unrestrictedEnabled)}`);
      return;
    }
    printError('用法: ai unrestricted --on | ai unrestricted --off | ai unrestricted --status');
    _markFailure();
    return;
  }

  const verify = await _requireOwnerSecret(opts);
  if (!verify.ok) {
    printError(verify.error);
    _markFailure();
    return;
  }

  const nextVal = opts.on ? 'true' : 'false';
  _setEnvVar(AI_UNRESTRICTED_ENV, nextVal);
  printSuccess(`开放模式已${opts.on ? '开启' : '关闭'} (${AI_UNRESTRICTED_ENV}=${nextVal})`);
  if (opts.on) {
    printWarn('开放模式会放宽安全拦截，请仅在受控环境临时使用。');
  } else {
    printInfo('标准安全策略已恢复。');
  }
}

function _classifyTaskType(message) {
  if (!message) return 'conversation';
  const lower = message.toLowerCase();
  if (/回测|backtest|策略|strategy/.test(lower)) return 'backtest';
  if (/分析|analyze|评估|诊断/.test(lower)) return 'analysis';
  if (/数据|data|下载|fetch/.test(lower)) return 'dataFetch';
  if (/策略|strategy|signal|信号/.test(lower)) return 'strategy';
  return 'conversation';
}

function _assessTaskDifficulty(input) {
  const lower = String(input || '').toLowerCase();
  const required = { code: 1, reasoning: 1, creative: 1, contextNeeded: 0 };

  if (/重构|refactor|实现|implement|debug|修复|写代码|编码|class\s|function\s|async\s|promise/.test(lower)) required.code = 4;
  if (/分析|analyze|推理|reason|比较|对比|为什么|原因|策略设计|复杂/.test(lower)) required.reasoning = 4;
  if (/设计|design|创意|创建|generate|生成|写文章|write\s/.test(lower)) required.creative = 3;
  if (String(input || '').length > 3000 || /全部|所有文件|整个项目|complete|comprehensive/.test(lower)) {
    required.contextNeeded = String(input || '').length * 4;
  }

  return required;
}

function checkModelCapability(input) {
  let currentModel = null;
  try {
    const gw = _gateway || require('../services/gateway/aiGateway');
    const active = (gw && typeof gw.getActiveAdapter === 'function') ? gw.getActiveAdapter() : null;
    if (active) {
      currentModel = active.activeModel || active.model || active.name || null;
    }
    if (!currentModel) {
      const status = (gw && typeof gw.getStatus === 'function') ? gw.getStatus() : null;
      if (Array.isArray(status)) {
        const activeRec = status.find(s => s && (s.active || s.isActive)) || status[0];
        currentModel = activeRec?.activeModel || activeRec?.model || activeRec?.name || null;
      } else if (status && typeof status === 'object') {
        currentModel = status.activeModel || status.model || status.name || null;
      }
    }
  } catch (e) { console.error('[ai] 模型状态获取失败:', e?.message); }
  if (!currentModel) {
    currentModel = String(process.env.GATEWAY_PREFERRED_MODEL || '').trim() || null;
  }
  if (!currentModel) return null;

  const lowerModel = currentModel.toLowerCase();
  let cap = null;
  const sortedCaps = Object.entries(MODEL_CAPABILITIES)
    .sort((a, b) => String(b[0] || '').length - String(a[0] || '').length);
  for (const [key, val] of sortedCaps) {
    if (lowerModel === key || lowerModel.includes(key)) { cap = val; break; }
  }
  if (!cap) return null;

  const taskReq = _assessTaskDifficulty(input);
  const issues = [];
  if (taskReq.code > cap.code) issues.push(`代码能力不足 (需要 ${taskReq.code}/5, 当前 ${cap.code}/5)`);
  if (taskReq.reasoning > cap.reasoning) issues.push(`推理能力不足 (需要 ${taskReq.reasoning}/5, 当前 ${cap.reasoning}/5)`);
  if (taskReq.contextNeeded > cap.context * 0.8) issues.push(`上下文可能不够 (估计需要 ${Math.round(taskReq.contextNeeded / 1000)}k, 限制 ${Math.round(cap.context / 1000)}k)`);
  if (issues.length === 0) return null;

  const better = Object.entries(MODEL_CAPABILITIES)
    .filter(([key]) => !lowerModel.includes(key))
    .filter(([, m]) => m.code >= taskReq.code && m.reasoning >= taskReq.reasoning && m.context >= (taskReq.contextNeeded || 0))
    .sort((a, b) => (b[1].code + b[1].reasoning) - (a[1].code + a[1].reasoning))
    .slice(0, 3);

  return {
    issues,
    recommendations: better.map(([key, m]) => ({ key, label: m.label })),
  };
}

/**
 * Build structured messages array for adapters that support native message format.
 * This preserves role boundaries instead of flattening into a single string.
 * @param {string} systemPrompt
 * @param {Array} messages
 * @returns {Array<{role: string, content: string}>}
 */
function _buildStructuredMessages(systemPrompt, messages) {
  const result = [{ role: 'system', content: systemPrompt }];
  for (const msg of messages) {
    if (msg.role === 'system') {
      // 中间 system 消息（如 contextCompressor 摘要）转为 user 角色
      result.push({ role: 'user', content: msg.content });
    } else if (msg.role === 'tool') {
      result.push({ role: 'user', content: `[Tool Result]\n${msg.content}` });
    } else {
      result.push({ role: msg.role, content: msg.content });
    }
  }

  // A1: 统一角色交替守卫 — 一处修复，所有路径受益
  const { enforceRoleAlternation } = require('../services/contextCompressor');
  return enforceRoleAlternation(result);
}

async function _gatewayGenerate(conversationPrompt, fullSystemPrompt, messages, userMessage, opts, effortPreset) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  // top_p is locked by runtime — never allow external override
  const lockedTopP = runtime.lockTopP(userMessage);

  // Inject tool definitions so the model knows what tools are available
  let toolDefs;
  try {
    const { getToolDefinitions } = require('../services/toolCalling');
    toolDefs = getToolDefinitions();
  } catch { toolDefs = undefined; }

  // Build structured messages array for adapters that support it
  const structuredMessages = _buildStructuredMessages(fullSystemPrompt, messages);

  // Hard timeout + idle timeout with active cancellation.
  // Unlike Promise.race-only timeout, this aborts underlying adapter work so
  // stale streams cannot continue printing after fallback.
  const preferredAdapter = String(
    opts.preferredAdapter !== undefined
      ? opts.preferredAdapter
      : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
  ).trim().toLowerCase();
  // Detect if a local adapter will be used: either user explicitly preferred it,
  // or the gateway's first available adapter is local (localLLM/ollama).
  let isLocalPreferredAdapter = preferredAdapter === 'localllm' || preferredAdapter === 'ollama';
  if (!isLocalPreferredAdapter && !preferredAdapter) {
    try {
      const firstAvailable = gw.getFirstAvailableAdapter?.();
      if (firstAvailable && (firstAvailable === 'localLLM' || firstAvailable === 'ollama')) {
        isLocalPreferredAdapter = true;
      }
    } catch { /* best effort */ }
  }
  let localLLMStatus = null;
  let localHotAttached = false;
  if (isLocalPreferredAdapter && preferredAdapter !== 'ollama') {
    try {
      const localLLMService = require('../services/localLLMService');
      if (localLLMService && typeof localLLMService.tryAdoptHotRunner === 'function') {
        const adopted = await localLLMService.tryAdoptHotRunner();
        localHotAttached = !!(adopted && adopted.adopted);
      }
      if (localLLMService && typeof localLLMService.getStatus === 'function') {
        localLLMStatus = localLLMService.getStatus();
      }
    } catch { /* best effort */ }
  }

  const defaultHardTimeoutMs = isLocalPreferredAdapter ? 240000 : 300000;
  let GATEWAY_HARD_TIMEOUT_MS = parseInt(
    process.env.KHY_GATEWAY_TIMEOUT_MS || String(defaultHardTimeoutMs),
    10
  );
  const allowShortLocalHard = String(process.env.KHY_LOCAL_ALLOW_SHORT_HARD_TIMEOUT || 'false').toLowerCase() === 'true';
  let hardTimeoutAutoRaised = false;
  if (isLocalPreferredAdapter && !allowShortLocalHard) {
    const warmMinHardTimeoutMs = Math.max(
      30000,
      parseInt(process.env.KHY_LOCAL_MIN_HARD_TIMEOUT_MS || '120000', 10) || 120000
    );
    const coldMinHardTimeoutMs = Math.max(
      warmMinHardTimeoutMs,
      parseInt(process.env.KHY_LOCAL_COLD_HARD_TIMEOUT_MS || '180000', 10) || 180000
    );
    const degradedMinHardTimeoutMs = Math.max(
      coldMinHardTimeoutMs,
      parseInt(process.env.KHY_LOCAL_DEGRADED_HARD_TIMEOUT_MS || '210000', 10) || 210000
    );
    const minRequiredHardTimeoutMs = localLLMStatus?.lastError
      ? degradedMinHardTimeoutMs
      : (localLLMStatus && localLLMStatus.available && !localLLMStatus.loaded
        ? coldMinHardTimeoutMs
        : warmMinHardTimeoutMs);
    if (GATEWAY_HARD_TIMEOUT_MS < minRequiredHardTimeoutMs) {
      GATEWAY_HARD_TIMEOUT_MS = minRequiredHardTimeoutMs;
      hardTimeoutAutoRaised = true;
    }
  }
  const defaultIdleTimeoutMs = isLocalPreferredAdapter
    ? Math.min(120000, Math.max(0, GATEWAY_HARD_TIMEOUT_MS - 10000))
    : Math.min(45000, Math.max(0, GATEWAY_HARD_TIMEOUT_MS - 5000));
  const configuredIdleTimeoutMs = Math.max(
    0,
    parseInt(
      process.env.KHY_GATEWAY_IDLE_TIMEOUT_MS
      || String(defaultIdleTimeoutMs),
      10
    )
  );
  const allowShortLocalIdle = String(process.env.KHY_LOCAL_ALLOW_SHORT_IDLE || 'false').toLowerCase() === 'true';
  const baseMinLocalIdleTimeoutMs = Math.max(
    10000,
    parseInt(process.env.KHY_LOCAL_MIN_IDLE_TIMEOUT_MS || '30000', 10) || 30000
  );
  let minLocalIdleTimeoutMs = baseMinLocalIdleTimeoutMs;
  if (isLocalPreferredAdapter && !allowShortLocalIdle) {
    const coldMinIdleTimeoutMs = Math.max(
      minLocalIdleTimeoutMs,
      parseInt(process.env.KHY_LOCAL_COLD_IDLE_TIMEOUT_MS || '90000', 10) || 90000
    );
    const degradedMinIdleTimeoutMs = Math.max(
      coldMinIdleTimeoutMs,
      parseInt(process.env.KHY_LOCAL_DEGRADED_IDLE_TIMEOUT_MS || '120000', 10) || 120000
    );
    if (localLLMStatus?.lastError) {
      minLocalIdleTimeoutMs = degradedMinIdleTimeoutMs;
    } else if (localLLMStatus && localLLMStatus.available && !localLLMStatus.loaded) {
      minLocalIdleTimeoutMs = coldMinIdleTimeoutMs;
    }
  }
  let GATEWAY_IDLE_TIMEOUT_MS = isLocalPreferredAdapter && !allowShortLocalIdle && configuredIdleTimeoutMs > 0
    ? Math.min(
      Math.max(0, GATEWAY_HARD_TIMEOUT_MS - 5000),
      Math.max(configuredIdleTimeoutMs, minLocalIdleTimeoutMs)
    )
    : configuredIdleTimeoutMs;
  if (
    isLocalPreferredAdapter
    && configuredIdleTimeoutMs > 0
    && GATEWAY_IDLE_TIMEOUT_MS > configuredIdleTimeoutMs
    && typeof opts.onStatus === 'function'
  ) {
    try {
      opts.onStatus({
        phase: 'request',
        message: `检测到本地通道 idle 超时配置过短，已自动调整为 ${Math.round(GATEWAY_IDLE_TIMEOUT_MS / 1000)}s 以提升稳定性。`,
      });
    } catch { /* best effort */ }
  }
  if (hardTimeoutAutoRaised && typeof opts.onStatus === 'function') {
    try {
      opts.onStatus({
        phase: 'request',
        message: `检测到本地通道 hard 超时配置过短，已自动调整为 ${Math.round(GATEWAY_HARD_TIMEOUT_MS / 1000)}s 以提升稳定性。`,
      });
    } catch { /* best effort */ }
  }

  // Optional stability multiplier (used by recovery retry paths).
  const stabilityTimeoutMultiplierRaw = Number(
    opts._stabilityTimeoutMultiplier
      || process.env.KHY_GATEWAY_STABILITY_TIMEOUT_MULTIPLIER
      || 1
  );
  const stabilityTimeoutMultiplier = Number.isFinite(stabilityTimeoutMultiplierRaw)
    ? Math.max(1, Math.min(3, stabilityTimeoutMultiplierRaw))
    : 1;
  if (stabilityTimeoutMultiplier > 1) {
    GATEWAY_HARD_TIMEOUT_MS = Math.round(GATEWAY_HARD_TIMEOUT_MS * stabilityTimeoutMultiplier);
    if (GATEWAY_IDLE_TIMEOUT_MS > 0) {
      GATEWAY_IDLE_TIMEOUT_MS = Math.min(
        Math.max(1000, Math.round(GATEWAY_IDLE_TIMEOUT_MS * stabilityTimeoutMultiplier)),
        Math.max(0, GATEWAY_HARD_TIMEOUT_MS - 1000),
      );
    }
    if (typeof opts.onStatus === 'function') {
      try {
        opts.onStatus({
          phase: 'request',
          message: `稳定性重试已放宽超时窗口 ×${stabilityTimeoutMultiplier.toFixed(2)}（hard ${Math.round(GATEWAY_HARD_TIMEOUT_MS / 1000)}s）`,
        });
      } catch { /* best effort */ }
    }
  }

  const abortController = new AbortController();
  let settled = false;
  let lastActivityTs = Date.now();
  let lastHeartbeatSec = -1;
  let localWarmupStage = -1;
  const localWarmupLabel = preferredAdapter === 'ollama' ? 'Ollama' : '本地模型';
  if (localHotAttached && typeof opts.onStatus === 'function') {
    try {
      opts.onStatus({
        phase: 'request',
        message: `${localWarmupLabel} 检测到热启动状态，已直接复用已加载引擎。`,
      });
    } catch { /* best effort */ }
  }
  const localWarmupStages = [
    { sec: 8, message: `${localWarmupLabel} 预热中：首次加载模型约需 30-120 秒（取决于模型大小和硬件）` },
    { sec: 20, message: `${localWarmupLabel} 正在加载模型与上下文，仍在运行...` },
    { sec: 45, message: `${localWarmupLabel} 仍在推理中；若为首次运行，这个耗时是常见现象。` },
  ];

  const markActivity = () => {
    lastActivityTs = Date.now();
  };

  const guardCallback = (fn, { mark = true } = {}) => {
    if (typeof fn !== 'function') return undefined;
    return (...args) => {
      if (settled) return undefined;
      if (mark) markActivity();
      return fn(...args);
    };
  };

  const resolvedMaxTokens = _resolveLocalPreferredMaxTokens(effortPreset.maxTokens, {
    isLocalPreferredAdapter,
    preferredAdapter,
    localLLMStatus,
  });
  if (resolvedMaxTokens.capped && typeof opts.onStatus === 'function') {
    try {
      const capLabel = preferredAdapter === 'ollama' ? 'Ollama' : '本地模型';
      opts.onStatus({
        phase: 'request',
        message: `${capLabel} 已启用快速响应上限：maxTokens ${effortPreset.maxTokens} -> ${resolvedMaxTokens.maxTokens}`,
      });
    } catch { /* best effort */ }
  }

  const activeRequestId = _registerActiveGatewayRequest(abortController, {
    adapter: opts.preferredAdapter || preferredAdapter,
  });
  let generatePromise;
  try {
    generatePromise = gw.generate(conversationPrompt, {
      temperature: runtime.lockTemperature(userMessage),
      top_p: lockedTopP,
      maxTokens: resolvedMaxTokens.maxTokens,
      taskScale: opts.taskScale,
      strictPreferred: opts.strictPreferred,
      preferredAdapter: opts.preferredAdapter,
      preferredModel: opts.preferredModel,
      preferredStrict: opts.preferredStrict,
      _intentDirective: opts._intentDirective,
      userMessage,
      onChunk: guardCallback(opts.onChunk, { mark: true }),
      onControlRequest: guardCallback(opts.onControlRequest, { mark: true }),
      onFallback: guardCallback(opts.onFallback, { mark: true }),
      onWait: guardCallback(opts.onWait, { mark: false }),
      images: opts.images,
      system: fullSystemPrompt,
      messages,
      tools: toolDefs,
      structuredMessages,
      thinking: effortPreset.thinking || undefined,
      abortSignal: abortController.signal,
    });
  } catch (err) {
    _unregisterActiveGatewayRequest(activeRequestId);
    throw err;
  }

  return new Promise((resolve, reject) => {
    let hardPoll = null;
    let idlePoll = null;
    const startedAt = Date.now();
    const clearTimers = () => {
      if (hardPoll) clearInterval(hardPoll);
      hardPoll = null;
      if (idlePoll) clearInterval(idlePoll);
      idlePoll = null;
    };

    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      _unregisterActiveGatewayRequest(activeRequestId);
      clearTimers();
      fn(value);
    };

    const abortAndReject = (message) => {
      const err = message instanceof Error ? message : new Error(String(message || 'AI gateway aborted'));
      if (!abortController.signal.aborted) {
        try { abortController.abort(err); } catch { /* ignore */ }
      }
      finish(reject, err);
    };

    hardPoll = setInterval(() => {
      if (settled) return;
      const now = Date.now();
      const silentFor = now - lastActivityTs;
      const lifetime = now - startedAt;
      // B1: 绝对超时 — 无论 adapter 是否持续发心跳，5分钟后强制终止
      const GATEWAY_ABSOLUTE_TIMEOUT_MS = 300000;
      if (lifetime >= GATEWAY_ABSOLUTE_TIMEOUT_MS) {
        abortAndReject(new Error(`请求绝对超时 (${Math.round(lifetime / 1000)}s) — 已强制终止`));
        return;
      }
      if (silentFor >= GATEWAY_HARD_TIMEOUT_MS) {
        abortAndReject(new Error(`AI gateway timeout after ${Math.round(GATEWAY_HARD_TIMEOUT_MS / 1000)}s — all adapters unresponsive`));
        return;
      }
    }, 1000);
    hardPoll.unref?.();

    if (GATEWAY_IDLE_TIMEOUT_MS > 0 && GATEWAY_IDLE_TIMEOUT_MS < GATEWAY_HARD_TIMEOUT_MS) {
      idlePoll = setInterval(() => {
        if (settled) return;
        const idleFor = Date.now() - lastActivityTs;
        const idleSec = Math.floor(idleFor / 1000);
        if (idleSec >= 8 && typeof opts.onStatus === 'function') {
          if (isLocalPreferredAdapter) {
            while (
              localWarmupStage + 1 < localWarmupStages.length
              && idleSec >= localWarmupStages[localWarmupStage + 1].sec
            ) {
              localWarmupStage += 1;
              try {
                opts.onStatus({
                  phase: 'request',
                  message: localWarmupStages[localWarmupStage].message,
                  elapsed: idleFor,
                });
              } catch { /* best effort */ }
            }
          }

          const heartbeatStep = isLocalPreferredAdapter ? 3 : 5;
          const bucket = Math.floor(idleSec / heartbeatStep);
          if (bucket !== lastHeartbeatSec) {
            lastHeartbeatSec = bucket;
            try {
              opts.onStatus({
                phase: 'request',
                message: isLocalPreferredAdapter
                  ? `等待本地模型响应中... ${idleSec}s`
                  : `等待模型响应中... ${idleSec}s`,
                elapsed: idleFor,
              });
            } catch { /* best effort */ }
          }
        }
        if (idleFor >= GATEWAY_IDLE_TIMEOUT_MS) {
          const idleTimeoutSec = Math.round(GATEWAY_IDLE_TIMEOUT_MS / 1000);
          const idleTimeoutHint = isLocalPreferredAdapter
            ? ' (local model warmup may still be in progress)'
            : '';
          abortAndReject(new Error(`AI gateway idle timeout after ${idleTimeoutSec}s — stream stalled${idleTimeoutHint}`));
        }
      }, 1000);
      idlePoll.unref?.();
    }

    generatePromise
      .then((result) => finish(resolve, result))
      .catch((err) => finish(reject, err));
  });
}

async function _preflightGatewayAvailability(options = {}) {
  if (_gatewayPreflightDone) return;
  if (_gatewayPreflightInFlight) return _gatewayPreflightInFlight;
  _gatewayPreflightInFlight = (async () => {
    const gw = getGateway();
    const runtimeIsKhy = String(process.env.KHY_RUNTIME_MODE || '').trim().toLowerCase() === 'khy';
    if (!gw._initialized) await gw.init();
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : null;
    const maxBudgetMs = Math.max(
      600,
      parseInt(process.env.KHY_PREFLIGHT_MAX_MS || (runtimeIsKhy ? '1800' : '6000'), 10)
    );
    const adapterProbeTimeoutMs = Math.max(
      600,
      parseInt(process.env.KHY_PREFLIGHT_ADAPTER_TIMEOUT_MS || (runtimeIsKhy ? '900' : '3000'), 10)
    );
    const maxAutoCandidates = Math.max(
      1,
      parseInt(process.env.KHY_PREFLIGHT_MAX_CANDIDATES || (runtimeIsKhy ? '2' : '3'), 10)
    );
    const startedAt = Date.now();

    const testAdapterQuickly = async (adapterKey) => {
      try {
        return await Promise.race([
          gw.testAdapter(adapterKey, { quick: true, timeoutMs: adapterProbeTimeoutMs }),
          new Promise((resolve) => {
            const t = setTimeout(() => resolve(null), adapterProbeTimeoutMs + 120);
            if (t.unref) t.unref();
          }),
        ]);
      } catch {
        return null;
      }
    };

    // If caller already selected a preferred adapter, test its live connectivity once.
    const preferred = String(
      options.preferredAdapter !== undefined
        ? options.preferredAdapter
        : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
    ).trim();
    if (preferred && preferred !== 'auto') {
      if (onProgress) onProgress(`预检首选通道: ${preferred}`);
      const probe = await testAdapterQuickly(preferred);
      const connectivityOk = !!probe?.connectivity?.success;
      const generationOk = probe?.generation ? !!probe.generation.success : true;
      const modelsOk = probe?.models ? !!probe.models.success : true;
      // Respect explicit user selection: do not silently rewrite preferred adapter
      // during preflight. If probe fails, keep current preference and let strict
      // execution return a clear error instead of auto-switching to another path.
      if (connectivityOk && generationOk && modelsOk) return;
      return;
    }

    // Auto-pick first operational adapter, skip relay-like adapters for chat by default.
    const statuses = gw.getStatus().filter(s => s.enabled && s.available).slice(0, maxAutoCandidates);
    for (const s of statuses) {
      if (Date.now() - startedAt >= maxBudgetMs) break;
      if (['relay', 'relay_api', 'clipboard'].includes(s.type)) continue;
      if (onProgress) onProgress(`预检通道: ${s.type}`);
      const probe = await testAdapterQuickly(s.type);
      const connectivityOk = !!probe?.connectivity?.success;
      const generationOk = probe?.generation ? !!probe.generation.success : true;
      const modelsOk = probe?.models ? !!probe.models.success : true;
      if (connectivityOk && generationOk && modelsOk) {
        process.env.GATEWAY_PREFERRED_ADAPTER = s.type;
        process.env.GATEWAY_PREFERRED_STRICT = 'true';
        return;
      }
    }
  })();
  try {
    await _gatewayPreflightInFlight;
  } finally {
    _gatewayPreflightDone = true;
    _gatewayPreflightInFlight = null;
  }
}

function _isStrictPreferredFailure(result) {
  if (!result || result.success) return false;
  const msg = String(result.content || result.error || '');
  return /已选择模型通道(请求失败|不可用)/.test(msg);
}

function _shouldKeepStrictPreferred(opts = {}) {
  if (opts.strictPreferred === true) return true;
  if (opts.strictPreferred === false) return false;
  const preferredStrictRaw = opts.preferredStrict !== undefined
    ? opts.preferredStrict
    : process.env.GATEWAY_PREFERRED_STRICT;
  if (String(preferredStrictRaw).toLowerCase() === 'false') return false;
  const preferred = String(
    opts.preferredAdapter !== undefined
      ? opts.preferredAdapter
      : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
  ).trim();
  return !!(preferred && preferred !== 'auto');
}

function _isStrictPreferredEnabled(opts = {}) {
  return _shouldKeepStrictPreferred(opts);
}

/**
 * Build a user-friendly reply from collected tool results when the
 * follow-up AI generation fails (timeout, error, empty response).
 * This ensures the user always sees the tool output instead of raw
 * <tool_call> tags or an empty reply.
 */
function _buildToolFallbackReply(toolResults) {
  if (!toolResults || toolResults.length === 0) return '';
  const parts = [];
  for (const tr of toolResults) {
    const text = tr.result.replace(/^\[Tool:\S+\]\s*/, '');
    const action = String(tr.action || '').toLowerCase();
    if (tr.success) {
      // Summarize differently based on tool type
      if (action === 'grep' || action === 'glob') {
        // File list tools: show list compactly, cap at 20 entries
        const lines = text.split('\n').filter(l => l.trim());
        const header = lines[0] && /^Found \d+/.test(lines[0]) ? lines.shift() : null;
        const fileLines = lines.slice(0, 20);
        let summary = header ? header + '\n' : '';
        summary += fileLines.map(f => `- ${f.trim()}`).join('\n');
        if (lines.length > 20) summary += `\n...and ${lines.length - 20} more`;
        parts.push(summary);
      } else if (action === 'read') {
        // Read: show first 500 chars only, encourage model to analyze
        parts.push(text.length > 500 ? text.slice(0, 500) + '\n...(file content truncated)' : text);
      } else {
        parts.push(text.length > 800 ? text.slice(0, 800) + '\n...(truncated)' : text);
      }
    } else {
      parts.push(text.length > 300 ? text.slice(0, 300) + '...' : text);
    }
  }
  const raw = parts.join('\n\n').trim();
  if (!raw) return '';

  // 自明工具（open_app/shell_command 等）成功后不需要冗余汇报
  const SELF_EVIDENT_TOOLS = new Set(['open_app', 'open_url', 'open_browser', 'shell_command', 'run_command']);
  const allSelfEvident = toolResults.every(tr => tr.success && SELF_EVIDENT_TOOLS.has(String(tr.action || '').toLowerCase()));
  if (allSelfEvident) return '';

  const toolNames = [...new Set(toolResults.map(t => t.action).filter(Boolean))];
  const header = toolNames.length
    ? `执行了 ${toolNames.join('、')}，结果如下：`
    : '工具执行结果：';
  return `${header}\n\n${raw}`;
}

/**
 * Extract [Plan] line from model's initial response.
 * Returns { plan, cleaned } where plan is the extracted text (or null)
 * and cleaned is the reply with the [Plan] line removed.
 */
function _extractPlan(reply) {
  const match = reply.match(/^\[Plan\]\s*(.+)$/m);
  if (!match) return { plan: null, cleaned: reply };
  const plan = match[1].trim();
  const cleaned = reply.replace(match[0], '').trim();
  return { plan, cleaned };
}

/**
 * Build a structured work summary from collected tool results.
 * Used when the model doesn't provide its own [Summary].
 */
function _buildWorkSummary(collectedToolResults) {
  if (!collectedToolResults || collectedToolResults.length === 0) return null;
  const actions = collectedToolResults.map(t => t.action).filter(Boolean);
  const unique = [...new Set(actions)];
  const succeeded = collectedToolResults.filter(t => t.success).length;
  const failed = collectedToolResults.length - succeeded;
  let summary = `Used ${unique.join(', ')} (${succeeded} succeeded`;
  if (failed > 0) summary += `, ${failed} failed`;
  summary += ')';
  return summary;
}

/**
 * Human-readable description for a tool action being executed.
 */
function _toolProgressLabel(action, arg) {
  const a = String(action || '').toLowerCase();
  if (a === 'read') return `Reading ${arg && arg.file_path ? require('path').basename(arg.file_path) : 'file'}...`;
  if (a === 'write') return `Writing ${arg && arg.file_path ? require('path').basename(arg.file_path) : 'file'}...`;
  if (a === 'edit') return `Editing ${arg && arg.file_path ? require('path').basename(arg.file_path) : 'file'}...`;
  if (a === 'glob') return `Searching files${arg && arg.pattern ? ` (${arg.pattern})` : ''}...`;
  if (a === 'grep') return `Searching code${arg && arg.pattern ? ` (${arg.pattern})` : ''}...`;
  if (a === 'shellcommand' || a === 'bash') return `Running command...`;
  if (a === 'web_search' || a === 'websearch') {
    const query = typeof arg === 'object' ? (arg.query || '') : String(arg || '');
    return query ? `Searching web: ${query.slice(0, 60)}...` : 'Searching web...';
  }
  if (a === 'quote') {
    const symbol = typeof arg === 'object' ? (arg.symbol || '') : String(arg || '');
    return symbol ? `Fetching quote: ${symbol}` : 'Fetching quote...';
  }
  if (a === 'data_fetch') return `Fetching data...`;
  return `Executing ${action}...`;
}

async function _runNaturalToolCallWithIdleTimeout(call, options = {}) {
  const idleTimeoutMsRaw = parseInt(String(options.idleTimeoutMs || ''), 10);
  const idleTimeoutMs = Number.isFinite(idleTimeoutMsRaw) && idleTimeoutMsRaw > 0
    ? idleTimeoutMsRaw
    : 120000;
  const onActivity = typeof options.onActivity === 'function' ? options.onActivity : null;
  const onProgress = typeof options.onProgress === 'function' ? options.onProgress : null;
  let lastActivityEventAt = 0;
  const minActivityEventGapMs = Math.max(250, parseInt(String(process.env.KHY_TOOL_ACTIVITY_EVENT_GAP_MS || '1200'), 10) || 1200);

  let timeoutReject = null;
  let watchdog = null;
  try {
    const { startWatchdog } = require('../services/resourceGuard');
    watchdog = startWatchdog(
      `natural-tool:${String(call && call.action ? call.action : 'tool')}`,
      idleTimeoutMs,
      (_operationName, elapsedSec) => {
        if (!timeoutReject) return;
        const reject = timeoutReject;
        timeoutReject = null;
        reject(new Error(`Tool execution idle timeout after ${elapsedSec}s`));
      }
    );
  } catch {
    watchdog = null;
  }

  const touch = (payload) => {
    try {
      if (watchdog) watchdog.touch();
    } catch { /* non-critical */ }
    if (onActivity) {
      const now = Date.now();
      if (now - lastActivityEventAt >= minActivityEventGapMs || payload === 'start' || payload === 'done') {
        lastActivityEventAt = now;
        try { onActivity(payload); } catch { /* non-critical */ }
      }
    }
  };

  const progress = (payload) => {
    touch(payload);
    if (onProgress) {
      try { onProgress(payload); } catch { /* non-critical */ }
    }
  };

  touch('start');

  const execution = runtime.runNaturalToolCall(call, {
    onActivity: touch,
    onProgress: progress,
  });

  if (!watchdog) {
    const result = await execution;
    touch('done');
    return result;
  }

  const idleTimeoutPromise = new Promise((_, reject) => {
    timeoutReject = reject;
  });

  try {
    const result = await Promise.race([execution, idleTimeoutPromise]);
    touch('done');
    return result;
  } finally {
    timeoutReject = null;
    try {
      if (watchdog) watchdog.done();
    } catch { /* non-critical */ }
  }
}

function _formatGatewayFailureDetails(result) {
  if (!result || !Array.isArray(result.attempts) || result.attempts.length === 0) return '';
  const failed = result.attempts.filter(a => a && a.success === false);
  if (failed.length === 0) return '';

  const normalizeAdapterSig = (raw) => {
    const s = String(raw || '').trim().toLowerCase();
    if (!s) return 'adapter';
    if (s === 'localllm' || s === 'local llm' || s.includes('local (') || s.includes('本地模型')) return 'localllm';
    if (s === 'codex' || s.includes('openai codex')) return 'codex';
    if (s === 'claude' || s.includes('anthropic')) return 'claude';
    if (s === 'ollama' || s.includes('ollama')) return 'ollama';
    if (s === 'api' || s.includes('multifree')) return 'api';
    if (s === 'relay' || s.includes('relay')) return 'relay';
    return s;
  };

  const lines = [];
  const seen = new Set();
  let uniqueFailedCount = 0;
  for (const attempt of failed) {
    const adapter = String(attempt.adapterKey || attempt.provider || 'adapter').trim();
    const adapterSig = normalizeAdapterSig(attempt.adapterKey || attempt.provider || 'adapter');
    const statusCode = attempt.statusCode ? String(attempt.statusCode) : '';
    const status = statusCode ? ` (${statusCode})` : '';
    const kindCode = String(attempt.errorType || '').trim().toLowerCase();
    const kind = kindCode ? ` [${kindCode}]` : '';
    const err = String(attempt.error || 'unknown error')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 180);
    const sig = `${adapterSig}|${statusCode}|${kindCode}|${err}`;
    if (!err || seen.has(sig)) continue;
    seen.add(sig);
    uniqueFailedCount += 1;
    if (lines.length < 6) {
      lines.push(`- ${adapter}${status}${kind}: ${err}`);
    }
  }

  if (lines.length === 0) return '';
  if (uniqueFailedCount > lines.length) {
    lines.push(`- ... 还有 ${uniqueFailedCount - lines.length} 条失败记录`);
  }
  return `真实失败原因:\n${lines.join('\n')}`;
}

async function _directGenerate(conversationPrompt, userMessage, opts, effortPreset) {
  const svc = getService();
  const status = svc.getStatus();
  if (!status.available) {
    return {
      success: false,
      errorType: 'network',
      content: '所有 AI 通道不可用。',
    };
  }
  return svc.generateResponse(conversationPrompt, {
    temperature: runtime.lockTemperature(userMessage),
    top_p: runtime.lockTopP(userMessage),
    maxTokens: effortPreset.maxTokens,
    images: opts.images,
  });
}

function _createStreamToolInterceptor(onChunk, options = {}) {
  // Keep a tail long enough to catch both "【调用" (4 chars) and "<tool_call>" (11 chars)
  const PASS_TAIL = 12;
  const suppressPrefixOnToolCall = options.suppressPrefixOnToolCall === true;
  let pending = '';
  let toolCallDetected = false;
  const collectedToolUseBlocks = []; // Collect structured tool_use from API

  const safeEmit = (chunk) => {
    if (typeof onChunk === 'function') onChunk(chunk);
  };

  const pushText = (text) => {
    pending += String(text || '');
    if (!pending) return;

    if (toolCallDetected) return;

    // Check for both tool call formats
    const cnIdx = pending.indexOf('【调用');
    const xmlIdx = pending.indexOf('<tool_call>');
    const hitIdx = cnIdx >= 0 && xmlIdx >= 0
      ? Math.min(cnIdx, xmlIdx)
      : cnIdx >= 0 ? cnIdx : xmlIdx;

    if (hitIdx >= 0) {
      if (hitIdx > 0 && !suppressPrefixOnToolCall) {
        safeEmit({ type: 'text', text: pending.slice(0, hitIdx) });
      }
      pending = '';
      toolCallDetected = true;
      return;
    }

    if (pending.length > PASS_TAIL) {
      safeEmit({ type: 'text', text: pending.slice(0, -PASS_TAIL) });
      pending = pending.slice(-PASS_TAIL);
    }
  };

  const onInterceptChunk = (chunk) => {
    if (!chunk || typeof chunk !== 'object') return;

    // Collect structured tool_use blocks from adapters that emit them
    if (chunk.type === 'tool_use' && chunk.tool) {
      collectedToolUseBlocks.push({
        name: chunk.tool,
        input: chunk.input || {},
        id: chunk.id || null,
      });
      toolCallDetected = true;
    }

    // Always pass non-text events through for status/thinking/tool UI.
    if (chunk.type !== 'text') {
      safeEmit(chunk);
      return;
    }

    pushText(chunk.text || '');
  };

  const finalize = () => {
    if (!toolCallDetected && pending) {
      safeEmit({ type: 'text', text: pending });
    }
    pending = '';
  };

  const reset = () => {
    pending = '';
    toolCallDetected = false;
    collectedToolUseBlocks.length = 0;
  };

  return {
    onChunk: onInterceptChunk,
    finalize,
    reset,
    hasToolCall: () => toolCallDetected,
    getToolUseBlocks: () => collectedToolUseBlocks,
  };
}

function _classifyGatewayThrownError(err) {
  const msg = String(err && err.message ? err.message : err || '').toLowerCase();
  if (/aborted|cancelled|canceled/.test(msg)) return 'cancelled';
  if (/timeout|timed out|stream stalled|unresponsive/.test(msg)) return 'timeout';
  if (/network|econn|enotfound|socket|fetch failed|getaddrinfo|proxy/.test(msg)) return 'network';
  if (/unauthorized|forbidden|invalid api key|auth|login/.test(msg)) return 'auth';
  if (/reconnecting|channel closed|process|exited with code|adapter .* timeout/.test(msg)) return 'process';
  return 'unknown';
}

function _isFirstTokenSignalChunk(chunk) {
  if (!chunk || typeof chunk !== 'object') return false;
  const kind = String(chunk.type || '').trim().toLowerCase();
  if (!kind) return false;
  if (kind === 'status' || kind === 'cost') return false;
  if (kind === 'text' || kind === 'thinking' || kind === 'tool_use' || kind === 'tool_result' || kind === 'tool_call' || kind === 'control_request') {
    return true;
  }
  const text = String(chunk.text || chunk.content || '').trim();
  return !!text;
}

function _isTransientGatewayErrorType(type = '') {
  const t = String(type || '').toLowerCase();
  return t === 'timeout' || t === 'cancelled' || t === 'network' || t === 'process' || t === 'unknown';
}

function _resolveTaskScale(userMessage = '', opts = {}) {
  const explicit = String(opts.taskScale || '').trim().toLowerCase();
  if (explicit === 'small' || explicit === 'normal' || explicit === 'large') return explicit;

  const text = String(userMessage || '').trim();
  const len = text.length;
  const hasLineBreak = /\n/.test(text);
  const largeHint = /大型任务|大任务|完整实现|全量|全流程|端到端|深度|深入|排查全部|deep|exhaustive|end-to-end|full implementation/i.test(text);
  const smallHint = /^(你好|hi|hello|hey|帮我看下|看下|查下|状态|help|who are you|你是谁|在吗)\s*[\?？!！。]*$/i.test(text);

  if (largeHint || len >= 700 || (len >= 450 && hasLineBreak)) return 'large';
  if (smallHint || (len <= 40 && !hasLineBreak)) return 'small';
  return 'normal';
}

function _shouldInjectTaskSelfAwareness(userMessage = '', opts = {}) {
  const gate = String(process.env.KHY_TASK_SELF_AWARENESS || 'true').trim().toLowerCase();
  if (['0', 'false', 'off', 'no'].includes(gate)) return false;
  if (opts && opts.disableTaskSelfAwareness === true) return false;

  const text = String(userMessage || '').trim();
  if (!text) return false;

  const scale = _resolveTaskScale(text, opts);
  if (scale !== 'small') return true;

  // Small tasks only inject when user explicitly asks for capability-awareness.
  return /自我认知|能力边界|能力|局限|can you do|what can you|capability|limitations?/i.test(text);
}

function _buildTaskSelfAwarenessPrompt(userMessage = '', opts = {}) {
  try {
    const scale = _resolveTaskScale(userMessage, opts);
    const runtimeMeta = _getStudyModeRuntimeMeta(opts.preferredAdapter, opts.preferredModel);
    const effort = String(opts.effort || _currentEffort || 'medium').trim();
    const { getSelfAwarenessProfile } = require('../services/knowledgeTeachingService');
    const profile = getSelfAwarenessProfile({
      studyMode: _studyMode,
      adapter: runtimeMeta.adapter,
      model: runtimeMeta.model,
      effort,
    });

    const modelCheck = checkModelCapability(userMessage);
    const caps = Array.isArray(profile.capabilities) ? profile.capabilities.slice(0, 4) : [];
    const limits = Array.isArray(profile.boundaries) ? profile.boundaries.slice(0, 4) : [];
    const capsBlock = caps.map((s, i) => `${i + 1}. ${s}`).join('\n') || '1. 按当前配置执行标准任务。';
    const limitsBlock = limits.map((s, i) => `${i + 1}. ${s}`).join('\n') || '1. 未检出显著边界风险。';

    const modelRisk = modelCheck && Array.isArray(modelCheck.issues) && modelCheck.issues.length > 0
      ? modelCheck.issues.map((s, i) => `${i + 1}. ${s}`).join('\n')
      : '1. 当前模型能力未检出明显短板。';
    const modelSuggest = modelCheck && Array.isArray(modelCheck.recommendations) && modelCheck.recommendations.length > 0
      ? modelCheck.recommendations.map((r, i) => `${i + 1}. ${r.label || r.key}`).join('\n')
      : '1. 保持当前模型并优先分步执行。';

    return [
      '### KHY_TASK_SELF_AWARENESS_GUIDE',
      '你在执行任务前必须先做能力自检，并将自检结果用于执行策略。',
      '',
      '执行规范:',
      '1) 先写明本轮任务目标与完成标准。',
      '2) 输出“已知/假设/未知”，未知项不得伪装为确定事实。',
      '3) 若能力或上下文不足，优先拆分任务并先完成可验证子任务。',
      '4) 回答必须包含可验证结果（检查点、命令输出摘要或证据）。',
      '',
      `任务规模: ${scale}`,
      `当前通道: ${profile.runtime?.adapter || 'auto'} / ${profile.runtime?.model || 'auto'} / effort=${effort}`,
      '',
      '可用能力:',
      capsBlock,
      '',
      '能力边界:',
      limitsBlock,
      '',
      '模型风险自检:',
      modelRisk,
      '',
      '模型改进建议:',
      modelSuggest,
    ].join('\n');
  } catch {
    return '';
  }
}

function _taskGuardHardModeEnabled() {
  const raw = String(process.env.KHY_TASK_SELF_AWARENESS_HARD || 'true').trim().toLowerCase();
  return !['0', 'false', 'off', 'no', 'n'].includes(raw);
}

function _taskGuardTtlMs() {
  const raw = parseInt(String(process.env.KHY_TASK_SELF_AWARENESS_HARD_TTL_MS || '900000'), 10);
  if (!Number.isFinite(raw) || raw <= 0) return 900000;
  return Math.max(30000, Math.min(24 * 60 * 60 * 1000, raw));
}

function _expirePendingTaskGuard() {
  if (!_pendingTaskGuard) return;
  if (Date.now() >= Number(_pendingTaskGuard.expiresAt || 0)) {
    _pendingTaskGuard = null;
  }
}

function _createTaskGuardId() {
  return `tg-${Date.now().toString(36)}-${crypto.randomBytes(2).toString('hex')}`;
}

function _parseTaskGuardCommand(input = '') {
  const text = String(input || '').trim();
  if (!text) return { confirm: false, cancel: false, id: '' };

  const confirmMatch = text.match(/^(?:确认执行|继续执行|确认|confirm|approve|yes)(?:\s+([a-z0-9-]+))?$/i);
  if (confirmMatch) {
    return { confirm: true, cancel: false, id: String(confirmMatch[1] || '').trim().toLowerCase() };
  }

  const cancelMatch = text.match(/^(?:取消执行|取消|cancel|abort)(?:\s+([a-z0-9-]+))?$/i);
  if (cancelMatch) {
    return { confirm: false, cancel: true, id: String(cancelMatch[1] || '').trim().toLowerCase() };
  }

  return { confirm: false, cancel: false, id: '' };
}

function _buildHardGuardPlan(userMessage = '', hardIssues = [], recommendations = []) {
  const taskSummary = String(userMessage || '').replace(/\s+/g, ' ').trim().slice(0, 80) || '当前任务';
  const issues = (hardIssues || []).slice(0, 3).map((x, i) => `${i + 1}. ${x}`).join('\n') || '1. 未识别到硬性风险。';
  const recs = (recommendations || []).slice(0, 3).map((r, i) => `${i + 1}. ${r.label || r.key || '保持当前模型分步执行'}`).join('\n') || '1. 保持当前模型并严格分步验证。';

  return [
    `目标: 完成「${taskSummary}」并保持结果可验证`,
    '步骤:',
    '1. 锁定验收标准：先明确交付物、边界条件和失败定义。',
    '2. 缩小风险面：优先选择更匹配模型或把任务拆成可独立验证的小步骤。',
    '3. 先做最小可验证子任务，给出证据后再扩展。',
    '4. 每一步输出“已知/假设/未知”，避免伪确定性。',
    '',
    '当前能力风险:',
    issues,
    '',
    '建议通道/模型调整:',
    recs,
  ].join('\n');
}

function _resolveHardTaskGuard(userMessage = '', opts = {}) {
  _expirePendingTaskGuard();
  const parsedCommand = _parseTaskGuardCommand(userMessage);

  if (_pendingTaskGuard) {
    const expectedId = String(_pendingTaskGuard.id || '').toLowerCase();
    const matchesId = !parsedCommand.id || parsedCommand.id === expectedId;

    if (parsedCommand.cancel) {
      if (matchesId) {
        const oldId = _pendingTaskGuard.id;
        _pendingTaskGuard = null;
        return {
          action: 'cancelled',
          reply: `已取消受限任务（${oldId}）。如需重新执行，请重新描述任务。`,
        };
      }
      return {
        action: 'blocked',
        reply: `取消口令不匹配。当前待确认任务: ${expectedId}\n请使用: 取消执行 ${expectedId}`,
      };
    }

    if (parsedCommand.confirm) {
      if (matchesId) {
        const pending = _pendingTaskGuard;
        _pendingTaskGuard = null;
        return {
          action: 'confirmed',
          replayMessage: pending.originalUserMessage,
          guardId: pending.id,
        };
      }
      return {
        action: 'blocked',
        reply: `确认口令不匹配。当前待确认任务: ${expectedId}\n请使用: 确认执行 ${expectedId}`,
      };
    }
  }

  if (!_taskGuardHardModeEnabled()) return { action: 'none' };
  if (opts._taskGuardConfirmed || opts.disableHardTaskGuard) return { action: 'none' };

  const text = String(userMessage || '').trim();
  if (!text) return { action: 'none' };

  const scale = _resolveTaskScale(text, opts);
  if (scale === 'small' && !/实现|重构|修复|改造|端到端|完整|full|implement|refactor|fix/i.test(text)) {
    return { action: 'none' };
  }

  const modelCheck = checkModelCapability(text);
  if (!modelCheck || !Array.isArray(modelCheck.issues) || modelCheck.issues.length === 0) {
    return { action: 'none' };
  }

  const hardIssues = modelCheck.issues.filter((issue) => !/(上下文可能不够|context)/i.test(String(issue || '')));
  if (hardIssues.length === 0) return { action: 'none' };

  const hardMin = Math.max(1, parseInt(String(process.env.KHY_TASK_GUARD_HARD_ISSUES_MIN || '2'), 10) || 2);
  const complexMinIssues = Math.max(1, parseInt(String(process.env.KHY_TASK_GUARD_COMPLEX_ISSUES_MIN || '1'), 10) || 1);
  const complexMinChars = Math.max(80, parseInt(String(process.env.KHY_TASK_GUARD_COMPLEX_MIN_CHARS || '160'), 10) || 160);
  const isComplex = scale === 'large' || text.length >= complexMinChars;
  const shouldBlock = hardIssues.length >= hardMin || (isComplex && hardIssues.length >= complexMinIssues);
  if (!shouldBlock) return { action: 'none' };

  const guardId = _createTaskGuardId();
  const expiresAt = Date.now() + _taskGuardTtlMs();
  const plan = _buildHardGuardPlan(text, hardIssues, modelCheck.recommendations || []);
  _pendingTaskGuard = {
    id: guardId,
    createdAt: Date.now(),
    expiresAt,
    originalUserMessage: text,
    issues: hardIssues,
    recommendations: Array.isArray(modelCheck.recommendations) ? modelCheck.recommendations : [],
    scale,
    plan,
  };

  const expireSec = Math.max(1, Math.ceil((expiresAt - Date.now()) / 1000));
  const reply = [
    `能力硬约束触发（任务ID: ${guardId}）`,
    '原因: 当前任务需求与模型能力存在高风险不匹配，已暂停自动执行。',
    '',
    plan,
    '',
    `确认执行（将在约 ${expireSec}s 后过期）: 确认执行 ${guardId}`,
    `取消任务: 取消执行 ${guardId}`,
  ].join('\n');

  return {
    action: 'blocked',
    reply,
    guardId,
    scale,
  };
}

function _resolveModelContextLimit(modelHint = '') {
  const lower = String(modelHint || '').toLowerCase().trim();
  if (!lower) return 128000;

  for (const [key, capability] of Object.entries(MODEL_CAPABILITIES)) {
    if (key !== 'default' && lower.includes(key) && capability && Number.isFinite(capability.context)) {
      return Math.max(8000, Number(capability.context));
    }
  }

  // Extra coverage for models not listed in MODEL_CAPABILITIES
  if (/gemini-2\.(0|5)-flash|gemini.*flash/.test(lower)) return 1000000;
  if (/gemini/.test(lower)) return 200000;
  if (/qwen|wenxin|ernie|baichuan|moonshot|kimi/.test(lower)) return 128000;
  if (/ollama|llama|mistral|phi|deepseek|glm/.test(lower)) return 128000;
  return 128000;
}

function _guessModelHint(opts = {}) {
  const byOpts = String(opts.preferredModel || '').trim();
  if (byOpts) return byOpts;
  const byEnv = String(process.env.GATEWAY_PREFERRED_MODEL || '').trim();
  if (byEnv) return byEnv;
  try {
    const gw = _gateway || require('../services/gateway/aiGateway');
    const status = gw && typeof gw.getStatus === 'function' ? gw.getStatus() : null;
    const active = Array.isArray(status) ? status.find(s => s && s.active) : null;
    return String(active?.activeModel || active?.model || '').trim();
  } catch {
    return '';
  }
}

function _estimateContextTokens(messages = [], systemPrompt = '', userPrompt = '') {
  const msgTokens = (messages || []).reduce((sum, m) => sum + runtime.estimateTokens(String(m?.content || '')), 0);
  const sysTokens = runtime.estimateTokens(String(systemPrompt || ''));
  const userTokens = runtime.estimateTokens(String(userPrompt || ''));
  // A2: 移除 _estimateContextTokens 的 1.2x — 安全系数只在 contextRouter 应用一次
  return Math.ceil(msgTokens + sysTokens + userTokens);
}

function _resolveContextBudget(opts = {}, preset = EFFORT_PRESETS.medium, userMessage = '') {
  const scale = _resolveTaskScale(userMessage, opts);
  const configuredLimit = parseInt(String(process.env.KHY_CONTEXT_TOKEN_LIMIT || runtime.CONTEXT_TOKEN_LIMIT || ''), 10);
  const modelHint = _guessModelHint(opts);
  const modelLimit = _resolveModelContextLimit(modelHint);

  let contextWindow = modelLimit;
  if (Number.isFinite(configuredLimit) && configuredLimit > 0) {
    contextWindow = Math.min(contextWindow, configuredLimit);
  }

  const minBudget = Math.max(4096, parseInt(String(process.env.KHY_CONTEXT_MIN_BUDGET || '8192'), 10) || 8192);
  const baseReserve = Math.max(1024, parseInt(String(process.env.KHY_CONTEXT_OUTPUT_RESERVE_TOKENS || ''), 10) || 0);
  const presetReserve = Math.max(1024, Math.floor(Number(preset?.maxTokens || 4096)));
  const reserveTokens = Math.max(baseReserve, scale === 'large' ? presetReserve : Math.min(presetReserve, 4096));

  const safetyRatioBase = Number.parseFloat(String(process.env.KHY_CONTEXT_SAFETY_RATIO || '0.12'));
  const safetyRatio = scale === 'small'
    ? Math.min(0.4, Math.max(0.1, safetyRatioBase + 0.08))
    : (scale === 'large'
      ? Math.min(0.35, Math.max(0.08, safetyRatioBase))
      : Math.min(0.35, Math.max(0.09, safetyRatioBase + 0.03)));
  const safetyTokens = Math.max(1024, Math.floor(contextWindow * safetyRatio));

  let budget = contextWindow - reserveTokens - safetyTokens;
  if (scale === 'small') {
    const smallCap = Math.max(16000, parseInt(String(process.env.KHY_CONTEXT_SMALL_CAP_TOKENS || '65536'), 10) || 65536);
    budget = Math.min(budget, smallCap);
  }

  budget = Math.max(minBudget, budget);
  return {
    taskScale: scale,
    modelHint,
    contextWindow,
    contextBudget: budget,
    reserveTokens,
    safetyTokens,
  };
}

function _supportsImageOnAdapter(adapterKey = '') {
  const key = String(adapterKey || '').trim().toLowerCase();
  // Default strategy: assume adapter supports vision unless explicitly blacklisted.
  // This avoids premature forced channel switching (e.g. codex -> claude).
  if (!key) return true;
  const extraCapable = String(process.env.KHY_VISION_CAPABLE_ADAPTERS || '')
    .split(',')
    .map(s => s.trim().toLowerCase())
    .filter(Boolean);
  const nonVision = String(process.env.KHY_NON_VISION_ADAPTERS || 'clipboard,kiro')
    .split(',')
    .map(s => s.trim().toLowerCase())
    .filter(Boolean);
  const capable = new Set(extraCapable);
  const nonVisionSet = new Set(nonVision);
  if (capable.has(key)) return true;
  if (nonVisionSet.has(key)) return false;
  return true;
}

const DEFAULT_MULTIMODAL_ADAPTER_CAPS = Object.freeze({
  claude: ['image', 'document'],
  codex: ['image'],
  api: ['image', 'audio', 'video', 'document'],
  relay_api: ['image', 'audio', 'video', 'document'],
  relay: ['image', 'document'],
  ollama: ['image'],
  localLLM: ['image'],
  localllm: ['image'],
  kiro: ['image'],
  cursor: ['image'],
  trae: ['image'],
  windsurf: ['image'],
});

function _resolveMultimodalAdapterCaps() {
  const out = { ...DEFAULT_MULTIMODAL_ADAPTER_CAPS };
  const raw = String(process.env.KHY_MULTIMODAL_ADAPTER_CAPS || '').trim();
  if (!raw) return out;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return out;
    for (const [adapter, kinds] of Object.entries(parsed)) {
      const key = String(adapter || '').trim();
      if (!key || !Array.isArray(kinds)) continue;
      const normalizedKinds = kinds
        .map(x => String(x || '').trim().toLowerCase())
        .filter(Boolean);
      if (normalizedKinds.length > 0) out[key] = [...new Set(normalizedKinds)];
    }
  } catch { /* ignore malformed env */ }
  return out;
}

function _supportsMediaKindsOnAdapter(adapterKey = '', mediaKinds = []) {
  const key = String(adapterKey || '').trim();
  const normalizedKey = key.toLowerCase();
  const kinds = [...new Set((mediaKinds || []).map(x => String(x || '').trim().toLowerCase()).filter(Boolean))];
  if (kinds.length === 0) return true;
  if (kinds.length === 1 && kinds[0] === 'image') return _supportsImageOnAdapter(normalizedKey);
  const caps = _resolveMultimodalAdapterCaps();
  const supported = new Set(caps[key] || caps[normalizedKey] || []);
  return kinds.every(kind => supported.has(kind));
}

function _isImageActionTask(opts = {}) {
  const text = String(
    opts.userMessage
    || opts.originalUserMessage
    || opts.prompt
    || ''
  ).toLowerCase();
  if (!text) return false;
  return /(写|保存|生成|创建|制作|导出|修改|编辑|网页|页面|html|文件|桌面|双击|write|save|create|generate|build|edit|modify|html|page|file|desktop)/i.test(text);
}

function _pickMultimodalAdapter(requested = '', mediaKinds = [], preferredAdapters = []) {
  const visionFallback = String(
    process.env.KHY_VISION_PREFERRED_ADAPTERS
    || process.env.KHY_VISION_PREFERRED_ADAPTER
    || 'codex,claude,api'
  )
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
  const multimodalFallback = String(process.env.KHY_MULTIMODAL_PREFERRED_ADAPTERS || 'claude,codex,api,relay_api')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
  const ordered = [...new Set([
    ...(Array.isArray(preferredAdapters) ? preferredAdapters : []),
    ...visionFallback,
    ...multimodalFallback,
  ])];
  const requestedKey = String(requested || '').trim();
  if (requestedKey) ordered.push(requestedKey);

  try {
    const gw = getGateway();
    const statuses = typeof gw.getStatus === 'function' ? gw.getStatus() : [];
    const statusList = Array.isArray(statuses) ? statuses : [];
    const available = new Set(
      statusList
        .filter(s => s && s.available)
        .map(s => String(s.type || '').trim().toLowerCase())
        .filter(Boolean)
    );
    for (const candidate of ordered) {
      const key = String(candidate || '').trim();
      if (!key) continue;
      const lower = key.toLowerCase();
      if (!available.has(lower)) continue;
      if (_supportsMediaKindsOnAdapter(lower, mediaKinds)) return lower;
    }
    if (requestedKey && available.has(requestedKey.toLowerCase()) && _supportsMediaKindsOnAdapter(requestedKey, mediaKinds)) {
      return requestedKey.toLowerCase();
    }
    for (const candidate of available) {
      if (_supportsMediaKindsOnAdapter(candidate, mediaKinds)) return candidate;
    }
  } catch { /* gateway status best effort */ }

  return requestedKey.toLowerCase() || String(ordered[0] || 'claude').toLowerCase();
}

function _pickVisionAdapter(requested = '', preferredAdapters = []) {
  return _pickMultimodalAdapter(requested, ['image'], preferredAdapters);
}

function _applyVisionRouting(opts = {}, onStatus = null, startTime = Date.now()) {
  const mediaKinds = [...new Set((Array.isArray(opts._mediaKinds) ? opts._mediaKinds : [])
    .map(x => String(x || '').trim().toLowerCase())
    .filter(Boolean))];
  const hasImageInput = Array.isArray(opts.images) && opts.images.length > 0;
  if (hasImageInput && !mediaKinds.includes('image')) mediaKinds.push('image');
  if (!hasImageInput && mediaKinds.length === 0) return opts;

  const requested = String(opts.preferredAdapter || process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
  const actionTask = _isImageActionTask(opts);
  const toolWeakAdapters = new Set(
    String(process.env.KHY_VISION_TOOL_WEAK_ADAPTERS || 'kiro')
      .split(',')
      .map(s => s.trim().toLowerCase())
      .filter(Boolean)
  );
  const smartRouteEnabled = !['0', 'false', 'off'].includes(
    String(process.env.KHY_VISION_SMART_ROUTE || 'true').trim().toLowerCase()
  );
  const weakForActionTask = smartRouteEnabled && actionTask && toolWeakAdapters.has(requested);
  const hasNonImageMedia = mediaKinds.some(kind => kind !== 'image');

  if (!requested || (_supportsMediaKindsOnAdapter(requested, mediaKinds) && !weakForActionTask)) return opts;

  const forceRoute = ['1', 'true', 'yes', 'on'].includes(
    String(process.env.KHY_VISION_FORCE_ROUTE || 'false').trim().toLowerCase()
  );
  const shouldForceRoute = forceRoute || weakForActionTask || hasNonImageMedia;
  if (!shouldForceRoute) {
    if (typeof onStatus === 'function') {
      try {
        onStatus({
          phase: 'request',
          message: `检测到多模态输入，保持当前通道 ${requested}；若不支持将由网关自动兜底重试`,
          elapsed: Date.now() - startTime,
        });
      } catch { /* best effort */ }
    }
    return opts;
  }

  const preferredAdapters = Array.isArray(opts._multimodalPreferredAdapters)
    ? opts._multimodalPreferredAdapters
    : [];
  const visionAdapter = _pickMultimodalAdapter(requested, mediaKinds, preferredAdapters);
  if (!visionAdapter || visionAdapter === requested) return opts;
  const routed = {
    ...opts,
    preferredAdapter: visionAdapter,
    preferredStrict: false,
    strictPreferred: false,
  };
  if (typeof onStatus === 'function') {
    try {
      const from = requested || '当前通道';
      const mediaLabel = mediaKinds.length > 0 ? `（${mediaKinds.join('+')}）` : '';
      const reason = weakForActionTask ? `${mediaLabel}（图片+执行任务场景）` : mediaLabel;
      onStatus({
        phase: 'request',
        message: `检测到多模态输入，${from} 已切换到 ${visionAdapter}${reason}`,
        elapsed: Date.now() - startTime,
      });
    } catch { /* best effort */ }
  }
  return routed;
}

function _resolveGatewayRecoveryRetries(opts = {}) {
  const explicit = parseInt(String(opts._gatewayRecoveryRetries ?? ''), 10);
  if (Number.isFinite(explicit)) return Math.max(0, Math.min(3, explicit));
  const scale = String(opts.taskScale || '').trim().toLowerCase();
  if (scale === 'small') {
    const parsedSmall = parseInt(String(process.env.KHY_GATEWAY_RECOVERY_RETRIES_SMALL || '1'), 10);
    return Number.isFinite(parsedSmall) ? Math.max(0, Math.min(2, parsedSmall)) : 1;
  }
  if (scale === 'large') {
    const parsedLarge = parseInt(String(process.env.KHY_GATEWAY_RECOVERY_RETRIES_LARGE || '2'), 10);
    return Number.isFinite(parsedLarge) ? Math.max(0, Math.min(3, parsedLarge)) : 2;
  }
  const parsed = parseInt(String(process.env.KHY_GATEWAY_RECOVERY_RETRIES || '1'), 10);
  if (!Number.isFinite(parsed) || parsed < 0) return 1;
  return Math.min(3, parsed);
}

function _resolveGatewayRecoveryDelayMs(attemptIndex = 0) {
  const base = Math.max(300, parseInt(String(process.env.KHY_GATEWAY_RECOVERY_BASE_DELAY_MS || '1200'), 10) || 1200);
  const exp = Math.min(3, Math.max(0, attemptIndex));
  const jitter = Math.random() * 300;
  return Math.round(base * Math.pow(1.7, exp) + jitter);
}

async function _generateWithStreamIntercept(conversationPrompt, fullSystemPrompt, messages, userMessage, opts, preset) {
  const interceptor = _createStreamToolInterceptor(opts.onChunk, {
    suppressPrefixOnToolCall: opts.suppressPrefixOnToolCall === true,
  });
  // Wrap onFallback to clear interceptor pending buffer when adapter
  // switches, preventing duplicate text from the failed adapter's partial
  // stream being flushed alongside the successful adapter's full stream.
  const wrappedOnFallback = typeof opts.onFallback === 'function'
    ? (...args) => { interceptor.reset(); return opts.onFallback(...args); }
    : opts.onFallback;
  const wrappedOpts = { ...opts, onChunk: interceptor.onChunk, onFallback: wrappedOnFallback };

  let result;
  try {
    result = await _gatewayGenerate(conversationPrompt, fullSystemPrompt, messages, userMessage, wrappedOpts, preset);
  } catch (err) {
    let gatewayErr = String(err && err.message ? err.message : err || 'unknown gateway error')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 220);
    let gatewayErrType = _classifyGatewayThrownError(err);

    // Stability recovery: transient failures get one (configurable) retry round.
    const recoveryRetries = _resolveGatewayRecoveryRetries(wrappedOpts);
    const alreadyRetried = !!wrappedOpts._gatewayRecoveryRetried;
    const canRecover = recoveryRetries > 0 && !alreadyRetried && _isTransientGatewayErrorType(gatewayErrType);
    if (canRecover) {
      const relaxStrict = String(process.env.KHY_GATEWAY_RECOVERY_RELAX_STRICT || 'true').toLowerCase() !== 'false';
      for (let retryIdx = 0; retryIdx < recoveryRetries; retryIdx++) {
        const waitMs = _resolveGatewayRecoveryDelayMs(retryIdx);
        if (typeof wrappedOpts.onStatus === 'function') {
          try {
            wrappedOpts.onStatus({
              phase: 'request',
              message: `网关连接波动（${gatewayErrType}），正在进行稳定性重试 ${retryIdx + 1}/${recoveryRetries}...`,
            });
          } catch { /* best effort */ }
        }
        await new Promise(r => setTimeout(r, waitMs));
        try {
          const retryOpts = {
            ...wrappedOpts,
            _gatewayRecoveryRetried: true,
            _gatewayRecoveryRetries: 0,
            _stabilityTimeoutMultiplier: 1.25 + (retryIdx * 0.35),
          };
          if (relaxStrict) {
            retryOpts.strictPreferred = false;
            retryOpts.preferredStrict = false;
          }
          result = await _gatewayGenerate(
            conversationPrompt,
            fullSystemPrompt,
            messages,
            userMessage,
            retryOpts,
            preset
          );
          interceptor.finalize();
          return { result, streamToolCallDetected: interceptor.hasToolCall() };
        } catch (retryErr) {
          gatewayErr = String(retryErr && retryErr.message ? retryErr.message : retryErr || gatewayErr)
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, 220);
          gatewayErrType = _classifyGatewayThrownError(retryErr);
        }
      }
    }

    // Default: keep a direct-generate fallback for resilience, but preserve
    // the original gateway failure reason when fallback also fails.
    // Set KHY_GATEWAY_THROW_FALLBACK=false to disable fallback and fail fast.
    const strictPreferred = _isStrictPreferredEnabled(opts);
    const preferred = String(
      opts.preferredAdapter !== undefined
        ? opts.preferredAdapter
        : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
    ).trim().toLowerCase();
    const skipDirectFallback = strictPreferred
      && preferred
      && preferred !== 'auto'
      && (gatewayErrType === 'timeout' || gatewayErrType === 'cancelled');

    if (process.env.KHY_GATEWAY_THROW_FALLBACK === 'false' || skipDirectFallback) {
      result = {
        success: false,
        errorType: gatewayErrType,
        content: skipDirectFallback
          ? `AI 网关异常: ${gatewayErr}\n\n已跳过云端兜底，避免掩盖首选通道（${preferred}）故障。`
          : `AI 网关异常: ${gatewayErr}`,
      };
    } else {
      try {
        result = await _directGenerate(conversationPrompt, userMessage, wrappedOpts, preset);
        if (!result || !result.success) {
          const fallbackMsg = (result && result.content) ? String(result.content) : '所有 AI 通道不可用。';
          result = {
            success: false,
            errorType: (result && result.errorType) || gatewayErrType,
            content: `AI 网关异常: ${gatewayErr}\n\n${fallbackMsg}`,
          };
        }
      } catch (e) {
        console.error('[ai] directGenerate 回退失败:', e?.message);
        result = {
          success: false,
          errorType: gatewayErrType,
          content: `AI 网关异常: ${gatewayErr}`,
        };
      }
    }
  }

  interceptor.finalize();
  return { result, streamToolCallDetected: interceptor.hasToolCall(), toolUseBlocks: interceptor.getToolUseBlocks() };
}

async function chat(userMessage, opts = {}) {
  const startTime = Date.now();
  const onStatus = opts.onStatus || (() => {});
  const runtimeIsKhy = String(process.env.KHY_RUNTIME_MODE || '').trim().toLowerCase() === 'khy';
  const ttftProfile = runtimeIsKhy ? 'khy_chat_interactive' : 'default_chat';
  let firstTokenAt = 0;
  let firstTokenType = '';
  let latencySampleRecorded = false;
  const autoTuneStatusMinGapMs = (() => {
    const fallback = runtimeIsKhy ? 180000 : 300000;
    const parsed = Number.parseInt(String(process.env.KHY_CHAT_AUTOTUNE_STATUS_MIN_GAP_MS || fallback), 10);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.min(3600000, Math.max(20000, parsed));
  })();

  const _markFirstTokenIfNeeded = (chunk) => {
    if (firstTokenAt > 0) return;
    if (!_isFirstTokenSignalChunk(chunk)) return;
    firstTokenAt = Date.now();
    firstTokenType = String(chunk?.type || '').trim().toLowerCase() || 'unknown';
  };

  const _recordLatencySample = (meta = {}) => {
    if (latencySampleRecorded) return null;
    latencySampleRecorded = true;
    try {
      const tuner = getChatLatencyAutoTuner();
      if (!tuner || typeof tuner.recordChatFirstTokenSample !== 'function') return null;
      const hasSyntheticFirstToken = !!meta.syntheticFirstToken;
      const hasFirstToken = firstTokenAt > 0 || hasSyntheticFirstToken;
      const elapsedMs = hasFirstToken
        ? (firstTokenAt > 0 ? (firstTokenAt - startTime) : Math.max(0, Date.now() - startTime))
        : Math.max(0, Date.now() - startTime);
      return tuner.recordChatFirstTokenSample({
        profile: ttftProfile,
        elapsedMs,
        hasFirstToken,
        success: meta.success !== false,
        adapter: meta.adapter || '',
        errorType: meta.errorType || '',
        firstTokenType,
      });
    } catch {
      return null;
    }
  };

  const _maybeAnnounceAutoTune = (sampleResult) => {
    if (!sampleResult || !sampleResult.tuned) return;
    const preset = String(sampleResult.preset || '').trim().toLowerCase();
    if (!preset) return;
    const profile = String(sampleResult.profile || ttftProfile).trim() || ttftProfile;
    const now = Date.now();
    const changed = preset !== _autoTuneAnnouncement.preset || profile !== _autoTuneAnnouncement.profile;
    if (!changed && (now - _autoTuneAnnouncement.at) < autoTuneStatusMinGapMs) return;
    _autoTuneAnnouncement = { profile, preset, at: now };
    const summary = sampleResult.summary || {};
    const p50 = Math.max(0, Number.parseInt(String(summary.p50 || 0), 10) || 0);
    const p95 = Math.max(0, Number.parseInt(String(summary.p95 || 0), 10) || 0);
    const count = Math.max(0, Number.parseInt(String(summary.count || 0), 10) || 0);
    const failures = Math.max(0, Number.parseInt(String(summary.failureCount || 0), 10) || 0);
    onStatus({
      phase: 'request',
      message: `已自动优化网关参数：档位 ${preset}，首包 P50/P95=${p50}/${p95}ms，失败 ${failures}/${count}`,
      elapsed: now - startTime,
    });
  };

  onStatus({ phase: 'init', message: '初始化...', elapsed: 0 });

  const taskGuardDecision = _resolveHardTaskGuard(userMessage, opts);
  if (taskGuardDecision.action === 'blocked') {
    onStatus({
      phase: 'init',
      message: '任务硬约束: 已暂停自动执行，等待用户确认（步骤 1/1）',
      elapsed: Date.now() - startTime,
    });
    onStatus({
      phase: 'done',
      message: '等待确认',
      elapsed: Date.now() - startTime,
      ok: false,
      errorType: 'capability_guard',
    });
    return {
      reply: taskGuardDecision.reply,
      commands: [],
      errorType: 'capability_guard',
    };
  }
  if (taskGuardDecision.action === 'cancelled') {
    onStatus({
      phase: 'done',
      message: '已取消受限任务',
      elapsed: Date.now() - startTime,
      ok: true,
    });
    return {
      reply: taskGuardDecision.reply,
      commands: [],
      errorType: 'none',
    };
  }
  if (taskGuardDecision.action === 'confirmed' && taskGuardDecision.replayMessage) {
    userMessage = taskGuardDecision.replayMessage;
    onStatus({
      phase: 'init',
      message: `任务硬约束确认通过: ${taskGuardDecision.guardId || ''}，开始执行原任务（步骤 1/1）`,
      elapsed: Date.now() - startTime,
    });
  }

  // Snapshot preferred routing at request start to avoid cross-talk when
  // concurrent chats mutate process.env in the same process.
  const requestPreferredAdapter = String(
    opts.preferredAdapter !== undefined
      ? opts.preferredAdapter
      : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
  ).trim();
  const requestPreferredModel = String(
    opts.preferredModel !== undefined
      ? opts.preferredModel
      : (process.env.GATEWAY_PREFERRED_MODEL || '')
  ).trim();
  const requestPreferredStrict = opts.preferredStrict !== undefined
    ? opts.preferredStrict
    : (String(process.env.GATEWAY_PREFERRED_STRICT || '').toLowerCase() !== 'false');
  let multimodalInput = {
    images: Array.isArray(opts.images) ? [...opts.images] : [],
    mediaKinds: Array.isArray(opts.images) && opts.images.length > 0 ? ['image'] : [],
    nonImageMedia: [],
    preferredAdapters: [],
    warnings: [],
    promptAugment: '',
    detectedCount: 0,
  };
  try {
    const { prepareMultimodalInput, prepareMultimodalInputAsync } = require('../services/multimodalInputService');
    if (typeof prepareMultimodalInputAsync === 'function') {
      multimodalInput = await prepareMultimodalInputAsync(userMessage, {
        ...opts,
        onStatus,
      });
    } else {
      multimodalInput = prepareMultimodalInput(userMessage, {
        ...opts,
        onStatus,
      });
    }
    const kinds = Array.isArray(multimodalInput.mediaKinds) ? multimodalInput.mediaKinds : [];
    const nonImageCount = Array.isArray(multimodalInput.nonImageMedia) ? multimodalInput.nonImageMedia.length : 0;
    if (kinds.length > 0) {
      onStatus({
        phase: 'init',
        message: `多模态输入检测: ${kinds.join('+')}（media ${Math.max(0, nonImageCount)}/image ${Math.max(0, (multimodalInput.images || []).length)}）`,
        elapsed: Date.now() - startTime,
      });
    }
    if (Array.isArray(multimodalInput.warnings) && multimodalInput.warnings.length > 0) {
      onStatus({
        phase: 'request',
        message: `多模态输入提示: ${String(multimodalInput.warnings[0] || '').slice(0, 160)}`,
        elapsed: Date.now() - startTime,
      });
    }
  } catch { /* non-critical */ }

  const userOnChunk = typeof opts.onChunk === 'function' ? opts.onChunk : null;
  let _lastMirroredStatusText = '';
  let _lastMirroredStatusAt = 0;
  const _mirroredStatusDedupMs = (() => {
    const raw = process.env.KHY_AI_STATUS_DEDUP_MS || process.env.GATEWAY_STATUS_DEDUP_MS || '1500';
    const parsed = Number.parseInt(String(raw).trim(), 10);
    if (!Number.isFinite(parsed) || parsed < 200) return 1500;
    return parsed;
  })();
  const mirrorGatewayStatusWhenChunkHandled = String(
    process.env.KHY_MIRROR_GATEWAY_STATUS_WHEN_ONCHUNK || 'false'
  ).toLowerCase() === 'true';
  const shouldMirrorGatewayStatus = !userOnChunk || mirrorGatewayStatusWhenChunkHandled;
  const _mirrorGatewayStatusToOnStatus = (chunk) => {
    if (!shouldMirrorGatewayStatus) return;
    if (!chunk || chunk.type !== 'status' || typeof onStatus !== 'function') return;
    const text = String(chunk.text || '').trim();
    if (!text) return;
    const now = Date.now();
    // De-duplicate short-burst repeated status lines from adapter retries.
    if (text === _lastMirroredStatusText && (now - _lastMirroredStatusAt) < _mirroredStatusDedupMs) return;
    _lastMirroredStatusText = text;
    _lastMirroredStatusAt = now;
    onStatus({ phase: 'request', message: text, elapsed: now - startTime });
  };
  const baseChatOpts = {
    ...opts,
    images: Array.isArray(multimodalInput.images) ? multimodalInput.images : opts.images,
    _mediaKinds: Array.isArray(multimodalInput.mediaKinds) ? multimodalInput.mediaKinds : [],
    _multimodalPreferredAdapters: Array.isArray(multimodalInput.preferredAdapters) ? multimodalInput.preferredAdapters : [],
    preferredAdapter: requestPreferredAdapter,
    preferredModel: requestPreferredModel,
    preferredStrict: requestPreferredStrict,
    taskScale: _resolveTaskScale(userMessage, opts),
    onChunk: (chunk) => {
      _markFirstTokenIfNeeded(chunk);
      if (userOnChunk) {
        try { userOnChunk(chunk); } catch { /* best effort */ }
      }
      _mirrorGatewayStatusToOnStatus(chunk);
    },
  };
  const chatOpts = _applyVisionRouting(baseChatOpts, onStatus, startTime);
  const effectivePreferredAdapter = String(chatOpts.preferredAdapter || '').trim();

  try {
    const nonBlockingPreflight = String(
      process.env.KHY_PREFLIGHT_NON_BLOCKING || 'true'
    ).toLowerCase() === 'true';
    if (nonBlockingPreflight) {
      onStatus({ phase: 'init', message: '预检后台进行中（不阻塞本次请求）', elapsed: Date.now() - startTime });
      _preflightGatewayAvailability({
        preferredAdapter: effectivePreferredAdapter,
        onProgress: (text) => onStatus({ phase: 'init', message: String(text || '预检中...'), elapsed: Date.now() - startTime }),
      }).catch(() => {});
    } else {
      await _preflightGatewayAvailability({
        preferredAdapter: effectivePreferredAdapter,
        onProgress: (text) => onStatus({ phase: 'init', message: String(text || '预检中...'), elapsed: Date.now() - startTime }),
      });
    }
  } catch { /* best effort */ }

  try {
    const { analyzeInput } = require('../services/securityGuardService');
    const check = analyzeInput(userMessage);
    if (!check.safe) {
      return { reply: check.refusal, commands: [], provider: 'security', blocked: true };
    }
  } catch {}

  // Directive extraction: strip inline directives before purification
  let _directives = { audioAsVoice: false, replyTo: null, replyToCurrent: false };
  let cleanedUserMessage = userMessage;
  try {
    const { extractDirectives, stripDirectives } = require('../services/directiveParser');
    _directives = extractDirectives(userMessage);
    cleanedUserMessage = stripDirectives(userMessage);
  } catch { /* directiveParser not available */ }
  if (multimodalInput.promptAugment) {
    cleanedUserMessage = `${cleanedUserMessage}\n\n${multimodalInput.promptAugment}`.trim();
  }

  const purified = runtime.inputPurify(cleanedUserMessage, { isFollowUp: _messages.length > 0 });
  let processedMessage = purified.purified;
  let ragContext = '';
  let ragMeta = null;

  if (!opts._isFollowUp) {
    try {
      const rag = require('../services/ragRetrievalService');
      if (rag && typeof rag.isEnabled === 'function' && rag.isEnabled()) {
        onStatus({
          phase: 'init',
          message: 'RAG 检索: 正在召回知识库与历史会话上下文（步骤 2/3）',
          elapsed: Date.now() - startTime,
        });
        const retrieval = (typeof rag.buildRetrievalContext === 'function')
          ? rag.buildRetrievalContext(processedMessage, { isFollowUp: false })
          : null;
        ragMeta = retrieval?.meta || null;
        if (retrieval && retrieval.used && retrieval.context) {
          ragContext = String(retrieval.context || '').trim();
          onStatus({
            phase: 'init',
            message: `RAG 检索: 已注入 ${ragMeta?.selectedCount || 0} 条上下文（步骤 3/3）`,
            elapsed: Date.now() - startTime,
          });
        } else {
          onStatus({
            phase: 'init',
            message: 'RAG 检索: 未命中可用上下文（步骤 3/3）',
            elapsed: Date.now() - startTime,
          });
        }
      }
    } catch { /* RAG is non-blocking */ }
  }

  if (opts._isFollowUp) _messages.push({ role: 'tool', content: processedMessage });
  else _messages.push({ role: 'user', content: processedMessage });

  if (_messages.length > MAX_HISTORY) _messages = _messages.slice(-MAX_HISTORY);

  // Greeting shortcut: when the user sends a simple greeting, replace the
  // heavy system prompt with a minimal conversational one so ALL adapters
  // (including cliToolAdapter / Claude Code bridge) respond naturally instead
  // of assuming the user wants financial calculations.
  const _isGreeting = purified.intent === '问候' && _messages.length <= 1;
  const taskScaleForPrompt = _resolveTaskScale(userMessage, chatOpts);
  const shouldInjectTaskSelfAwareness = _shouldInjectTaskSelfAwareness(userMessage, chatOpts)
    && (!_studyMode || taskScaleForPrompt === 'large');
  const effort = chatOpts.effort || _currentEffort;
  const preset = EFFORT_PRESETS[effort] || EFFORT_PRESETS.high;
  let taskSelfAwarenessInjected = false;

  const fullSystemPrompt = (() => {
    if (_isGreeting) {
      return [
        'You are khy OS, a friendly and helpful AI assistant.',
        'Respond in the same language the user used.',
        'The user sent a casual greeting. Respond naturally — say hello,',
        'briefly introduce yourself, and ask how you can help today.',
        'Keep it warm and concise (2-3 sentences).',
        'Do NOT mention calculation, financial analysis, stock trading, or any specific tool.',
      ].join(' ');
    }
    let sp = runtime.makeSystemPrompt(getSecurityDir(), _getModelInfo());
    // Inject intentGate directives into system prompt (not user message)
    // to avoid AI treating them as prompt injection.
    const intentDirective = String(chatOpts._intentDirective || '').trim();
    if (intentDirective) {
      sp += '\n\n' + intentDirective;
    }
    if (_studyMode) {
      try {
        const { buildStudyModePromptContext } = require('../services/knowledgeTeachingService');
        const runtimeMeta = _getStudyModeRuntimeMeta(chatOpts.preferredAdapter, chatOpts.preferredModel);
        const studyPrompt = buildStudyModePromptContext({
          studyMode: true,
          adapter: runtimeMeta.adapter,
          model: runtimeMeta.model,
          effort,
        });
        if (studyPrompt) sp += '\n\n' + studyPrompt;
      } catch { /* non-blocking */ }
    }
    if (shouldInjectTaskSelfAwareness) {
      const taskPrompt = _buildTaskSelfAwarenessPrompt(userMessage, { ...chatOpts, effort });
      if (taskPrompt) {
        sp += '\n\n' + taskPrompt;
        taskSelfAwarenessInjected = true;
      }
    }
    return sp;
  })();
  if (taskSelfAwarenessInjected) {
    onStatus({
      phase: 'init',
      message: `任务自检: 已注入能力边界与执行策略（${taskScaleForPrompt}，步骤 1/1）`,
      elapsed: Date.now() - startTime,
    });
  }
  const contextPlan = _resolveContextBudget(chatOpts, preset, userMessage);
  const contextBudget = contextPlan.contextBudget;

  // Preemptive context routing (Phase 5)
  let compactMessages;
  let _wasCompacted = false;
  let _aggressiveCompacted = false;
  try {
    const { routeContextStrategy, truncateToolResults } = require('../services/contextRouter');
    const route = routeContextStrategy(_messages, fullSystemPrompt, processedMessage, contextBudget);
    if (route.route === 'fits') {
      compactMessages = [..._messages];
    } else if (route.route === 'truncate_tool_results_only') {
      compactMessages = _messages.map(m => ({ ...m }));
      truncateToolResults(compactMessages, route.overflow);
      _wasCompacted = true;
    } else if (route.route === 'compact_only') {
      compactMessages = await runtime.buildSlidingWindow(_messages, contextBudget);
      _wasCompacted = true;
    } else { // compact_then_truncate
      compactMessages = await runtime.buildSlidingWindow(_messages, contextBudget);
      truncateToolResults(compactMessages, route.overflow);
      _wasCompacted = true;
    }
  } catch (e) {
    // B4: context routing 失败日志
    console.error('[ai] context routing 异常, 回退到 slidingWindow:', e?.message);
    // Fallback: use sliding window directly
    compactMessages = await runtime.buildSlidingWindow(_messages, contextBudget);
    _wasCompacted = true;
  }

  // Hard guard: if estimation is still above budget, force a stricter second compaction pass.
  // A4: 如果已包含摘要，只允许 tool truncation，不重新 buildSlidingWindow
  try {
    const estimated = _estimateContextTokens(compactMessages, fullSystemPrompt, processedMessage);
    if (estimated > contextBudget) {
      const hasExistingSummary = compactMessages.some(m =>
        typeof m.content === 'string' && (
          m.content.includes('[Compressed context summary]') ||
          m.content.includes('[ContextCompact v2')
        )
      );
      if (hasExistingSummary) {
        // 已有摘要 — 只做 tool truncation，避免双重压缩破坏结构
        const { truncateToolResults } = require('../services/contextRouter');
        const overflow = estimated - contextBudget;
        truncateToolResults(compactMessages, overflow);
        _wasCompacted = true;
      } else {
        const strictBudget = Math.max(4096, Math.floor(contextBudget * 0.82));
        compactMessages = await runtime.buildSlidingWindow(compactMessages, strictBudget);
        _wasCompacted = true;
        _aggressiveCompacted = true;
      }
    }
  } catch { /* best effort */ }

  // Notify caller that conversation was compacted
  if (_wasCompacted) {
    onStatus({ phase: 'compacted', message: 'Conversation compacted (ctrl+o for history)' });
    if (_aggressiveCompacted) {
      onStatus({
        phase: 'compacted',
        message: `上下文接近上限，已执行强化压缩（预算 ${Math.round(contextBudget / 1000)}k）`,
      });
    }
  }

  let promptMessages = compactMessages;
  if (ragContext && compactMessages.length > 0) {
    const lastIndex = compactMessages.length - 1;
    promptMessages = compactMessages.map((msg, idx) => {
      if (idx !== lastIndex) return msg;
      const augmentedContent = [
        String(msg.content || ''),
        '',
        '[RAG_CONTEXT]',
        ragContext,
        '[/RAG_CONTEXT]',
      ].join('\n');
      return { ...msg, content: augmentedContent };
    });
  }
  const conversationPrompt = runtime.buildFlatConversation(fullSystemPrompt, promptMessages);

  try {
    await _maybeWarmupLocalPreferredOnce({
      preferredAdapter: effectivePreferredAdapter,
      onStatus: (text) => onStatus({ phase: 'init', message: String(text || '本地模型预热中...'), elapsed: Date.now() - startTime }),
    });
  } catch { /* best effort */ }

  const preferredAdapter = String(effectivePreferredAdapter || '').trim().toLowerCase();
  const localPreferred = preferredAdapter === 'localllm' || preferredAdapter === 'ollama';
  let requestMessage = localPreferred
    ? '请求 AI 服务...（本地模型首轮可能需要 30-120 秒预热）'
    : '请求 AI 服务...';
  try {
    const gw = getGateway();
    const preferredStatus = (gw.getStatus?.() || []).find(
      (s) => String(s?.type || '').trim().toLowerCase() === preferredAdapter
    );
    const remainingMs = Number(preferredStatus?.lastError?.remainingMs || 0);
    if (preferredStatus?.lastError?.coolingDown && remainingMs > 0) {
      const remainSec = Math.max(1, Math.ceil(remainingMs / 1000));
      requestMessage = localPreferred
        ? `请求 AI 服务...（本地通道处于冷却期，约 ${remainSec}s 后恢复；本次可能快速返回）`
        : `请求 AI 服务...（首选通道处于冷却期，约 ${remainSec}s 后恢复；本次可能快速返回）`;
    }
  } catch { /* best effort */ }
  if (localPreferred && !requestMessage.includes('冷却期')) {
    try {
      const localSvc = require('../services/localLLMService');
      let hotAttached = false;
      if (typeof localSvc.tryAdoptHotRunner === 'function') {
        const adopted = await localSvc.tryAdoptHotRunner();
        hotAttached = !!(adopted && adopted.adopted);
      }
      const status = localSvc.getStatus?.() || {};
      if (hotAttached || status.loaded) {
        requestMessage = '请求 AI 服务...（检测到本地模型已热启动，预计更快返回）';
      } else {
        const loopbackOk = await localSvc.canListenLoopback?.();
        if (loopbackOk === false) {
          const reason = String(status.loopbackListenError || '').replace(/\s+/g, ' ').trim().slice(0, 80);
          requestMessage = reason
            ? `请求 AI 服务...（当前运行环境限制本地监听，可能快速失败：${reason}）`
            : '请求 AI 服务...（当前运行环境限制本地监听，可能快速失败）';
        }
      }
    } catch { /* best effort */ }
  }
  onStatus({
    phase: 'request',
    message: requestMessage,
    elapsed: Date.now() - startTime,
  });

  const firstPass = await _generateWithStreamIntercept(
    conversationPrompt,
    fullSystemPrompt,
    compactMessages,
    userMessage,
    chatOpts,
    preset
  );
  let result = firstPass.result;

  // If strict preferred is explicitly disabled, allow one relaxed retry.
  // Otherwise preserve strict mode so we don't silently fall back to relay.
  if (_isStrictPreferredFailure(result) && chatOpts.strictPreferred !== false && !_shouldKeepStrictPreferred(chatOpts)) {
    onStatus({ phase: 'request', message: '首选通道失败，尝试自动回退...', elapsed: Date.now() - startTime });
    const retryPass = await _generateWithStreamIntercept(
      conversationPrompt,
      fullSystemPrompt,
      compactMessages,
      userMessage,
      { ...chatOpts, strictPreferred: false },
      preset
    );
    // Always surface the retry outcome (success or failure) so users don't get
    // stuck with the initial strict-preferred error after fallback was attempted.
    if (retryPass && retryPass.result) {
      result = retryPass.result;
    }
  }

  if (!result || !result.success) {
    const compactFailureReason = String(
      (result && (result.content || result.error || result.errorType)) || 'AI 请求失败'
    )
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 180);

    const elapsed = Date.now() - startTime;
    onStatus({
      phase: 'request',
      message: `失败原因: ${compactFailureReason || 'AI 请求失败'}`,
      elapsed,
    });
    onStatus({
      phase: 'done',
      message: '失败',
      elapsed,
      ok: false,
      errorType: (result && result.errorType) || 'unknown',
    });

    let errorMsg = (result && result.content) ? result.content : 'AI 请求失败。';
    const failureDetails = _formatGatewayFailureDetails(result);
    if (failureDetails && !/真实失败原因/.test(errorMsg)) {
      errorMsg = `${errorMsg}\n\n${failureDetails}`;
    }
    const tuneResult = _recordLatencySample({
      success: false,
      errorType: (result && result.errorType) || 'unknown',
      adapter: (result && (result.adapter || result.provider)) || 'none',
    });
    _maybeAnnounceAutoTune(tuneResult);
    return {
      reply: errorMsg,
      commands: [],
      errorType: (result && result.errorType) || 'unknown',
      failureDetails,
    };
  }

  let reply = String(result.content || '').trim();
  if (!reply && result.thinking) {
    // Model produced thinking but no content (e.g. all reasoning was in <think> block).
    // Use thinking as the reply so the user gets a response.
    reply = result.thinking.trim();
  }
  if (!reply) {
    const tuneResult = _recordLatencySample({
      success: false,
      errorType: 'empty_reply',
      adapter: (result && (result.adapter || result.provider)) || 'none',
    });
    _maybeAnnounceAutoTune(tuneResult);
    return { reply: 'AI 未返回有效回复 — 请重试或检查连接', commands: [] };
  }

  const effectiveTaskScale = _resolveTaskScale(userMessage, opts);
  if (!opts.disableNaturalToolLoop) {
    // Intent-aware inner loop boost
    let intentInnerBoost = 0;
    try {
      const { detectModes, getLoopLimitBoost } = require('../services/intentGate');
      const detected = detectModes(userMessage);
      intentInnerBoost = getLoopLimitBoost(detected.modes).innerBoost;
    } catch { /* intentGate not available */ }

    // Natural language tool gateway loop (max 5 turns, with timeout + retry)
    const TOOL_LOOP_MAX = (effectiveTaskScale === 'large'
      ? Math.max(8, parseInt(String(process.env.KHY_TOOL_LOOP_MAX_LARGE || '12'), 10) || 12)
      : (effectiveTaskScale === 'small'
        ? Math.max(3, parseInt(String(process.env.KHY_TOOL_LOOP_MAX_SMALL || '4'), 10) || 4)
        : Math.max(5, parseInt(String(process.env.KHY_TOOL_LOOP_MAX || '8'), 10) || 8))
    ) + intentInnerBoost;
    const TOOL_LOOP_TIMEOUT_MS = effectiveTaskScale === 'large'
      ? Math.max(600000, parseInt(String(process.env.KHY_TOOL_LOOP_TIMEOUT_LARGE_MS || '900000'), 10) || 900000)
      : Math.max(120000, parseInt(String(process.env.KHY_TOOL_LOOP_TIMEOUT_MS || '180000'), 10) || 180000);
    let loopCount = 0;
    let consecutiveErrors = 0;
    // Track all tool results so we can fall back to them if follow-up generation fails
    const collectedToolResults = [];
    // Dedup: prevent model from calling same tool+params repeatedly
    const seenToolCalls = new Set();

    // ── Phase 1: Plan extraction ──
    // Extract [Plan] from the model's first response before entering the tool loop
    let workPlan = null;
    {
      const planInfo = _extractPlan(reply);
      if (planInfo.plan) {
        workPlan = planInfo.plan;
        reply = planInfo.cleaned;
        onStatus({ phase: 'plan', message: `Plan: ${workPlan}`, elapsed: Date.now() - startTime });
      }
    }

    while (loopCount < TOOL_LOOP_MAX) {
      const call = runtime.extractNaturalToolCall(reply);
      if (!call) break;

      // Duplicate detection: same tool + same args = skip and force reply from results
      const callKey = JSON.stringify({ a: call.action, p: call.arg });
      if (seenToolCalls.has(callKey)) {
        // Model is repeating itself — stop the loop and summarize
        reply = _buildToolFallbackReply(collectedToolResults);
        if (!reply) reply = 'Tool loop detected a repeated call. Stopping.';
        break;
      }
      seenToolCalls.add(callKey);

      loopCount += 1;

      // ── Phase 2: Progress reporting ──
      const progressLabel = _toolProgressLabel(call.action, call.arg);
      onStatus({
        phase: 'tool_progress',
        message: `[${loopCount}/${TOOL_LOOP_MAX}] ${progressLabel}`,
        toolName: call.action,
        step: loopCount,
        elapsed: Date.now() - startTime,
      });

      let toolResult;
      let toolSuccess = false;
      try {
        const executed = await _runNaturalToolCallWithIdleTimeout(call, {
          idleTimeoutMs: TOOL_LOOP_TIMEOUT_MS,
          onActivity: () => {
            onStatus({
              phase: 'tool_progress',
              message: `[${loopCount}/${TOOL_LOOP_MAX}] ${call.action} in progress...`,
              toolName: call.action,
              step: loopCount,
              elapsed: Date.now() - startTime,
            });
          },
          onProgress: (payload) => {
            const msg = typeof payload === 'string' && payload.trim()
              ? payload.trim().slice(0, 120)
              : `${call.action} in progress`;
            onStatus({
              phase: 'tool_progress',
              message: `[${loopCount}/${TOOL_LOOP_MAX}] ${msg}`,
              toolName: call.action,
              step: loopCount,
              elapsed: Date.now() - startTime,
            });
          },
        });
        if (executed && executed.success) {
          toolResult = `[Tool:${call.action}] ${executed.text}`;
          toolSuccess = true;
          consecutiveErrors = 0;
          onStatus({
            phase: 'tool_progress',
            message: `[${loopCount}/${TOOL_LOOP_MAX}] ${call.action} ✓`,
            toolName: call.action,
            step: loopCount,
            success: true,
            elapsed: Date.now() - startTime,
          });
        } else {
          toolResult = `[Tool:${call.action}] ERROR: ${(executed && executed.text) || 'failed'}`;
          consecutiveErrors += 1;
          onStatus({
            phase: 'tool_progress',
            message: `[${loopCount}/${TOOL_LOOP_MAX}] ${call.action} ✗`,
            toolName: call.action,
            step: loopCount,
            success: false,
            elapsed: Date.now() - startTime,
          });
        }
      } catch (e) {
        toolResult = `[Tool:${call.action}] ERROR: ${e.message}`;
        consecutiveErrors += 1;
        onStatus({
          phase: 'tool_progress',
          message: `[${loopCount}/${TOOL_LOOP_MAX}] ${call.action} ✗ ${e.message.slice(0, 60)}`,
          toolName: call.action,
          step: loopCount,
          success: false,
          elapsed: Date.now() - startTime,
        });
      }

      collectedToolResults.push({ action: call.action, result: toolResult, success: toolSuccess });

      // Bail out after 2 consecutive tool errors to avoid infinite failure loops
      if (consecutiveErrors >= 2) {
        _messages.push({ role: 'tool', content: toolResult });
        reply = _buildToolFallbackReply(collectedToolResults);
        reply += `\n\n⚠️ Tool failed ${consecutiveErrors} times in a row, stopping tool loop.`;
        break;
      }

      _messages.push({ role: 'tool', content: toolResult });

      // Intent-aware nudge: if user asked to modify/edit and model only Read so far,
      // append a system hint to guide the model to call Edit next.
      if (toolSuccess && call.action === 'Read' && loopCount === 1) {
        const modifyIntent = /修改|改|编辑|添加|加一个|增加|替换|重构|重写|更新|删除|移除/i.test(userMessage)
          || /modify|edit|add|change|update|refactor|replace|remove|delete/i.test(userMessage);
        if (modifyIntent) {
          _messages.push({
            role: 'system',
            content: 'Reminder: The user asked you to MODIFY this file. You have read it — now call the Edit tool with exact old_string from the content above to make the change.',
          });
        }
      }

      // Preemptive context routing for loop path (Phase 5)
      let compactLoopMessages;
      try {
        const { routeContextStrategy, truncateToolResults } = require('../services/contextRouter');
        const loopRoute = routeContextStrategy(_messages, fullSystemPrompt, '', contextBudget);
        if (loopRoute.route === 'fits') {
          compactLoopMessages = [..._messages];
        } else if (loopRoute.route === 'truncate_tool_results_only') {
          compactLoopMessages = _messages.map(m => ({ ...m }));
          truncateToolResults(compactLoopMessages, loopRoute.overflow);
        } else if (loopRoute.route === 'compact_only') {
          compactLoopMessages = await runtime.buildSlidingWindow(_messages, contextBudget);
        } else {
          compactLoopMessages = await runtime.buildSlidingWindow(_messages, contextBudget);
          truncateToolResults(compactLoopMessages, loopRoute.overflow);
        }
      } catch {
        compactLoopMessages = await runtime.buildSlidingWindow(_messages, contextBudget);
      }

      try {
        const estimatedLoop = _estimateContextTokens(compactLoopMessages, fullSystemPrompt, '');
        if (estimatedLoop > contextBudget) {
          compactLoopMessages = await runtime.buildSlidingWindow(
            compactLoopMessages,
            Math.max(4096, Math.floor(contextBudget * 0.82))
          );
          onStatus({
            phase: 'compacted',
            message: `工具循环上下文过大，已强化压缩（预算 ${Math.round(contextBudget / 1000)}k）`,
            elapsed: Date.now() - startTime,
          });
        }
      } catch { /* best effort */ }

      if (!compactLoopMessages || compactLoopMessages.length === 0) {
        compactLoopMessages = await runtime.buildSlidingWindow(_messages, Math.max(4096, Math.floor(contextBudget * 0.82)));
      }

      const loopPrompt = runtime.buildFlatConversation(fullSystemPrompt, compactLoopMessages);

      const loopPass = await _generateWithStreamIntercept(
        loopPrompt,
        fullSystemPrompt,
        compactLoopMessages,
        userMessage,
        chatOpts,
        preset
      );
      let loopRes = loopPass.result;

      if (!loopRes || !loopRes.success) {
        // Retry once on generation failure
        try {
          loopRes = await _directGenerate(loopPrompt, userMessage, opts, preset);
        } catch {
          // Follow-up generation failed — fall back to tool results summary
          reply = _buildToolFallbackReply(collectedToolResults);
          break;
        }
        if (!loopRes || !loopRes.success) {
          reply = _buildToolFallbackReply(collectedToolResults);
          break;
        }
      }

      reply = String(loopRes.content || '').trim();
      if (!reply) {
        reply = _buildToolFallbackReply(collectedToolResults);
        break;
      }
    }

    // If loop exhausted: use collected tool results as the reply foundation
    if (loopCount >= TOOL_LOOP_MAX) {
      const hasRemainingCall = runtime.extractNaturalToolCall(reply);
      if (hasRemainingCall || !reply.trim()) {
        // Model was still trying to call tools — use accumulated results instead
        reply = _buildToolFallbackReply(collectedToolResults);
      }
    }

    // Final safety: strip any remaining raw <tool_call> tags from the reply
    reply = reply.replace(/<tool_call>[\s\S]*?<\/tool_call>/g, '').trim();
    if (!reply && collectedToolResults.length > 0) {
      reply = _buildToolFallbackReply(collectedToolResults);
    }

    // ── Phase 3: Work Summary ──
    // Extract model-provided [Summary] or generate one from tool results.
    // Emit as a status event but keep summary text in the reply if stripping
    // would leave it empty.
    if (collectedToolResults.length > 0) {
      let workSummary = null;
      const summaryMatch = reply.match(/\[Summary\]\s*(.+)$/m);
      if (summaryMatch) {
        workSummary = summaryMatch[1].trim();
        const stripped = reply.replace(summaryMatch[0], '').trim();
        // Only strip [Summary] tag from reply if there is other content left;
        // otherwise keep the summary text as the reply body (without the tag prefix).
        reply = stripped || workSummary;
      } else {
        // Model didn't provide a summary — generate one from tool results
        workSummary = _buildWorkSummary(collectedToolResults);
      }
      if (workSummary) {
        onStatus({
          phase: 'summary',
          message: `Summary: ${workSummary}`,
          plan: workPlan,
          toolCount: collectedToolResults.length,
          elapsed: Date.now() - startTime,
        });
      }
    }

    // Strip [Plan] tags from reply but preserve content if it would be empty
    {
      const planLine = reply.match(/^\[Plan\]\s*.+$/m);
      if (planLine) {
        const stripped = reply.replace(planLine[0], '').trim();
        if (stripped) reply = stripped;
        else reply = reply.replace(/^\[Plan\]\s*/, '').trim();
      }
    }

    // Detect degenerate reply: model just echoed plan steps (e.g. "1) Read 2) Edit 3) Done")
    // instead of providing actual results. Replace with tool fallback.
    if (collectedToolResults.length > 0) {
      const trimmed = reply.trim();
      const looksLikePlanEcho = /^\d\)\s/.test(trimmed) && trimmed.split('\n').length <= 4 && trimmed.length < 200;
      if (looksLikePlanEcho) {
        reply = _buildToolFallbackReply(collectedToolResults);
      }
    }

    // Incomplete action detection: if user wanted modification but model only Read
    // and never called Edit/Write, append a diagnostic hint to the reply.
    if (collectedToolResults.length > 0) {
      const actionNames = collectedToolResults.map(t => t.action).filter(Boolean);
      const onlyRead = actionNames.length > 0 && actionNames.every(a => a === 'Read');
      const modifyIntent = /修改|改[成为]|编辑|添加|加一个|增加|替换|重构|重写|更新|删除|移除/i.test(userMessage)
        || /modify|edit|add.*param|change|update|refactor|replace|remove|delete/i.test(userMessage);
      if (onlyRead && modifyIntent) {
        reply += '\n\n> Note: File was read but the modification was not applied automatically. You can ask me to retry the edit, or make the change manually based on the file content above.';
      }
    }
  }

  _messages.push({ role: 'assistant', content: reply });
  if (_messages.length > MAX_HISTORY) _messages = _messages.slice(-MAX_HISTORY);

  let safeReply = reply;
  try {
    const { sanitizeOutput } = require('../services/securityGuardService');
    safeReply = sanitizeOutput(reply);
  } catch {}

  // Local enforcement of output formatting (replaces system prompt rules R1, R10, R14)
  safeReply = runtime.postProcessOutput(safeReply);

  let tokenUsage = result.tokenUsage || null;
  try {
    const { recordUsage, estimateTokens } = require('../services/tokenUsageService');
    if (!tokenUsage) {
      tokenUsage = {
        inputTokens: estimateTokens(conversationPrompt),
        outputTokens: estimateTokens(reply),
        totalTokens: estimateTokens(conversationPrompt) + estimateTokens(reply),
      };
    }
    recordUsage(result.provider || 'unknown', result.model || '', tokenUsage.inputTokens, tokenUsage.outputTokens, 0);
  } catch {}

  try {
    const { recordConversation } = require('../services/modelTrainingService');
    recordConversation(userMessage, reply, {
      provider: result.provider,
      model: result.model || '',
      tokenCount: tokenUsage ? tokenUsage.totalTokens : 0,
      quality: 'neutral',
    });
  } catch {}

  try {
    const { recordResponseStyle } = require('../services/agentCommunicationService');
    recordResponseStyle(userMessage, reply, { provider: result.provider });
  } catch {}

  try {
    const { extractKnowledge } = require('../services/knowledgeTeachingService');
    extractKnowledge(userMessage, reply);
  } catch {}

  try {
    const { recordModelUsage, recordInteraction: recordHabit } = require('../services/usageHabitService');
    const taskType = _classifyTaskType(userMessage);
    recordModelUsage(result.adapter || result.provider, result.model || '', taskType, 1);
    recordHabit(userMessage);
  } catch {}

  const elapsed = Date.now() - startTime;

  // Synthetic lifecycle events for Codex adapter (which bypasses natural tool loop)
  if (String(result.adapter || '').toLowerCase() === 'codex' && result.toolSummary) {
    // Extract plan-like first sentence from reply
    const firstSentence = safeReply.split(/[.。!\n]/)[0]?.trim();
    if (firstSentence && firstSentence.length > 5) {
      onStatus({ phase: 'plan', message: `Plan: ${firstSentence}`, elapsed });
    }
    // Emit tool summary
    const ts = result.toolSummary;
    if (ts.totalCalls > 0) {
      const dur = ts.totalDurationMs > 0 ? ` · ${(ts.totalDurationMs / 1000).toFixed(1)}s` : '';
      onStatus({ phase: 'summary', message: `Codex executed ${ts.totalCalls} tool call(s)${dur}`, elapsed });
    }
  }

  onStatus({ phase: 'done', message: '完成', elapsed });

  try {
    const hud = require('./hudRenderer');
    if (tokenUsage?.inputTokens) {
      const limit = hud.getContextLimit(result.model || '');
      hud.setContextUsage(tokenUsage.inputTokens, limit);
    }
  } catch {}

  const tuneResult = _recordLatencySample({
    success: true,
    adapter: (result && (result.adapter || result.provider)) || 'unknown',
    errorType: '',
    syntheticFirstToken: firstTokenAt <= 0 && !!safeReply,
  });
  _maybeAnnounceAutoTune(tuneResult);

  return {
    reply: safeReply,
    thinking: result.thinking || null,
    commands: [],
    provider: result.provider,
    adapter: result.adapter,
    tokenUsage,
    toolSummary: result.toolSummary || null,
    toolUseBlocks: firstPass.toolUseBlocks || [],
    retrieval: ragMeta,
    elapsed,
    effort,
  };
}

module.exports = {
  getAiStatus,
  getActiveProvider,
  handleAiStatus,
  handleAiConfig,
  chat,
  cancelActiveRequest,
  clearHistory,
  saveConversation,
  loadLastConversation,
  listConversations,
  findConversationByRef,
  resumeConversation,
  autoResumeLastSession,
  loadProjectMemoryContext,
  setEffort,
  getEffort,
  getEffortPresets,
  getConversationStats,
  getConversation,
  getContextLimit,
  compactConversation,
  compactHistory,
  enableStudyMode,
  disableStudyMode,
  isStudyMode,
  checkModelCapability,
  handleAiOwner,
  handleAiTech,
  handleAiUnrestricted,
  EFFORT_PRESETS,
  MODEL_CAPABILITIES,
  getSystemPrompt: () => runtime.makeSystemPrompt(getSecurityDir(), _getModelInfo()),
};
