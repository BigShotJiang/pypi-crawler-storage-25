/**
 * Interactive REPL — the heart of the CLI.
 * Combines command mode, menu mode, and AI conversation mode.
 *
 * All heavy modules are lazy-loaded for fast cold start.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const { renderSideBySideDiff } = require('./ui/diffViewer');
const { createTaskMindMap, createIdleTaskMindMap, extractPlanStepsFromText } = require('./taskMindMap');
const { FeatureCapabilityMap } = require('./featureCapabilityMap');
const { LineBuffer, AdaptiveChunker } = require('./lineBuffer');

// ── Lazy module loaders (Claude-style: zero top-level heavy requires) ──
let _chalk, _inquirer, _formatters, _router, _ai, _menu, _userProfile;
const chalk = () => {
  if (_chalk) return _chalk;
  const chalkModule = require('chalk');
  _chalk = chalkModule.default || chalkModule;
  return _chalk;
};
const inquirer = () => (_inquirer ??= require('inquirer'));
const fmt = () => (_formatters ??= require('./formatters'));
const router = () => (_router ??= require('./router'));
const ai = () => (_ai ??= require('./ai'));
const menu = () => (_menu ??= require('./menu'));
const userProfile = () => (_userProfile ??= require('../services/userProfile'));

const os = require('os');
let _vimInput, _vimSettings;
const vimInput = () => (_vimInput ??= require('../vim/vimInput'));
const vimSettings = () => (_vimSettings ??= require('../vim/settings'));
const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;

// Ensure history file has secure permissions (0600)
const { safeChmod } = require('../tools/platformUtils');
try {
  if (!fs.existsSync(HISTORY_FILE)) {
    fs.writeFileSync(HISTORY_FILE, '');
  }
  safeChmod(HISTORY_FILE, 0o600);
} catch { /* best effort */ }
const VERSION = require('../../package.json').version;

// ── Terminal title (ANSI escape) ────────────────────────────────────────

function setTerminalTitle(title) {
  if (process.stdout.isTTY) {
    process.stdout.write(`\x1b]0;${title}\x07`);
  }
}

// Track the current conversation topic for dynamic title updates
let _currentTopic = '';

function updateTitleFromConversation(userMessage) {
  const topic = (userMessage || '').replace(/\n/g, ' ').slice(0, 30).trim();
  _currentTopic = topic || _currentTopic;
  setTerminalTitle(_currentTopic ? `· ${_currentTopic}` : 'khy OS');
}

/**
 * Update terminal title to reflect current work phase.
 * Claude Code style:
 *   Working: "· topic" (dot prefix indicates activity)
 *   Idle:    "· topic"
 * @param {'thinking'|'tool'|'generating'|'idle'} phase
 * @param {string} [detail] - tool name or phase detail
 */
function updateTitlePhase(phase, detail = '') {
  const topic = _currentTopic || 'khy OS';
  switch (phase) {
    case 'thinking':
      setTerminalTitle(`· ${topic}`);
      break;
    case 'tool':
      setTerminalTitle(`· ${topic}`);
      break;
    case 'generating':
      setTerminalTitle(`· ${topic}`);
      break;
    case 'idle':
    default:
      setTerminalTitle(`· ${topic}`);
      break;
  }
}

function hasToolCallTag(text = '') {
  const s = text || '';
  return /<tool_call>\s*[\s\S]*?<\/tool_call>/i.test(s)
    || /【\s*调用\s*[^】\n]{1,48}(?:[：:][^】]*)?】/.test(s);
}

function stripToolCallTags(text = '') {
  return (text || '')
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/gi, '')
    .replace(/【\s*调用\s*[^】\n]{1,48}(?:[：:][^】]*)?】/g, '')
    .replace(/<execution_plan>[\s\S]*?<\/execution_plan>/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function shouldBypassPlanMode(input = '') {
  const raw = String(input || '');
  const lower = raw.toLowerCase();
  if (!lower) return false;
  if (/\bnoplan\b|\/noplan\b/.test(lower)) return true;

  const zhPattern = /不要(?:进入)?计划|无需(?:进入)?计划|不需要(?:进入)?计划|跳过计划|直接执行|直接开始执行/;
  const enPattern = /\b(no\s*plan|skip\s*plan|direct\s*execute|execute\s*directly)\b/i;
  return zhPattern.test(raw) || enPattern.test(raw);
}

function looksLikeUiEchoInput(input = '') {
  const s = String(input || '').trim();
  if (!s) return false;
  return /^>\s*状态:\s*/.test(s)
    || /^状态:\s*(就绪|处理中)/.test(s)
    || /^>\s*(向\s*AI\s*发送请求|进入计划模式|执行计划|计划模式)/.test(s)
    || /^[-─]{10,}$/.test(s);
}

function isArrowEscapeLine(input = '') {
  const raw = String(input || '');
  const trimmed = raw.trim();
  if (!trimmed) return false;
  return trimmed === '\u001b[A'
    || trimmed === '\u001b[B'
    || trimmed === '\u001b[C'
    || trimmed === '\u001b[D'
    || /^\^\[\[[ABCD]$/.test(trimmed);
}

function mapToolToPhaseLabel(toolName = '') {
  // Claude Code style: use English tool display names
  try {
    const renderer = require('./aiRenderer');
    return renderer.getToolDisplayName(toolName);
  } catch {
    const n = String(toolName || '').toLowerCase();
    if (n.includes('read')) return 'Read';
    if (n.includes('write') || n.includes('edit')) return 'Write';
    if (n.includes('search') || n.includes('grep') || n.includes('glob')) return 'Search';
    if (n.includes('bash') || n.includes('shell') || n.includes('command')) return 'Bash';
    return toolName || 'Tool';
  }
}

function getDisplayWidthChar(ch) {
  // Use formatters.displayWidth for accurate single-char width (CJK/emoji/grapheme).
  // Fast path for common ASCII first.
  const code = ch.codePointAt(0);
  if (!code) return 1;
  if (code >= 0x20 && code < 0x7F) return 1;
  try {
    const { displayWidth } = require('./formatters');
    return displayWidth(ch);
  } catch {
    // Fallback: manual CJK detection
    if ((code >= 0x1100 && code <= 0x115F) ||
        (code >= 0x2E80 && code <= 0xA4CF) ||
        (code >= 0xAC00 && code <= 0xD7AF) ||
        (code >= 0xF900 && code <= 0xFAFF) ||
        (code >= 0xFE10 && code <= 0xFE6F) ||
        (code >= 0xFF01 && code <= 0xFF60) ||
        (code >= 0xFFE0 && code <= 0xFFE6) ||
        (code >= 0x20000 && code <= 0x2FA1F)) {
      return 2;
    }
    return 1;
  }
}

function streamThinkingChunk(text, streamState, c) {
  // Default: show thinking text in dim style (like Claude Code / LibreChat).
  // Set KHY_SHOW_THINKING_TEXT=false to hide.
  const hideThinking = String(process.env.KHY_SHOW_THINKING_TEXT || '').toLowerCase();
  if (hideThinking === 'false' || hideThinking === '0' || hideThinking === 'off') return;

  const content = String(text || '').replace(/\r/g, '');
  if (!content) return;

  // Track thinking text length for final summary
  if (!streamState._thinkingLen) streamState._thinkingLen = 0;
  streamState._thinkingLen += content.length;

  const maxCols = Math.max(24, (process.stdout.columns || 80) - 6);
  const prefix = '  ';

  if (!streamState.thinkingLineOpen) {
    process.stdout.write(prefix);
    streamState.thinkingLineOpen = true;
    streamState.thinkingCol = 0;
  }

  for (const ch of content) {
    if (ch === '\n') {
      process.stdout.write('\n');
      process.stdout.write(prefix);
      streamState.thinkingCol = 0;
      continue;
    }

    const charWidth = getDisplayWidthChar(ch);
    if (streamState.thinkingCol + charWidth > maxCols) {
      process.stdout.write('\n');
      process.stdout.write(prefix);
      streamState.thinkingCol = 0;
    }

    process.stdout.write(c.dim(ch));
    streamState.thinkingCol += charWidth;
  }
}

function closeThinkingStream(streamState) {
  if (!streamState.thinkingLineOpen) return;
  process.stdout.write('\n');
  streamState.thinkingLineOpen = false;
  streamState.thinkingCol = 0;

  // Print a summary line showing how long thinking took
  const c = () => (_chalk ??= (require('chalk').default || require('chalk')));
  const thinkingLen = streamState._thinkingLen || 0;
  if (thinkingLen > 0) {
    const elapsed = streamState._thinkingStartAt
      ? Math.round((Date.now() - streamState._thinkingStartAt) / 1000)
      : 0;
    const timeStr = elapsed > 0 ? ` ${elapsed}s` : '';
    const charStr = thinkingLen > 100 ? ` · ${thinkingLen} 字符` : '';
    console.log(c().dim(`  💭 思考完成${timeStr}${charStr}`));
    console.log('');
  }
}

/**
 * Buffer AI text during streaming with incremental rendering.
 *
 * Inspired by Claude Code's "stable prefix / unstable suffix" approach:
 * - Text is accumulated in _textBuffer
 * - On each chunk arrival, we find the last stable paragraph boundary (\n\n)
 *   or sentence boundary (。！？.\n) and render everything before it
 * - The unstable tail is kept for the next chunk
 * - Code fences (```) are never split: we wait for the closing fence
 *
 * This gives the user immediate visual feedback instead of waiting for the
 * entire response to finish before seeing any output.
 */
function bufferTextChunk(text, streamState) {
  if (!text) return;

  // G1/G2: 使用 LineBuffer + AdaptiveChunker 替代原始字符串拼接
  if (streamState._chunker) {
    streamState._lineBuffer.push(text);
    streamState._chunker.tick();
    // 同步 _textBuffer 供 flushTextBuffer 和流结束检查使用
    streamState._textBuffer = streamState._lineBuffer._pending;
    return;
  }

  // Fallback: 兼容旧路径（不应到达）
  if (!streamState._textBuffer) streamState._textBuffer = '';
  streamState._textBuffer += text;
  _tryIncrementalFlush(streamState);
}

/**
 * Find the last safe split point in the buffer and render everything before it.
 * Safe boundaries (in priority order):
 *   1. Paragraph break: \n\n
 *   2. Line break after sentence-ending punctuation: [。！？!?.]\n
 *   3. Line break: \n (only when buffer > 200 chars to avoid splitting short responses)
 * Never split inside an open code fence.
 */
function _tryIncrementalFlush(streamState) {
  const raw = streamState._textBuffer || '';
  if (!raw || raw.length < 30) return; // too short, wait for more

  // Check for open code fence — don't flush if we're inside one
  const fenceMatches = raw.match(/^```/gm);
  if (fenceMatches && fenceMatches.length % 2 !== 0) return; // odd = unclosed fence

  // Find the best split point
  let splitIdx = -1;

  // Priority 1: paragraph boundary (\n\n)
  const paraIdx = raw.lastIndexOf('\n\n');
  if (paraIdx > 0) {
    splitIdx = paraIdx + 2;
  }

  // Priority 2: sentence-end + newline
  if (splitIdx < 0) {
    const sentenceNewline = /[。！？!?.:：]\n/g;
    let m;
    while ((m = sentenceNewline.exec(raw)) !== null) {
      splitIdx = m.index + m[0].length;
    }
  }

  // Priority 3: plain newline (only for longer buffers)
  if (splitIdx < 0 && raw.length > 200) {
    const nlIdx = raw.lastIndexOf('\n');
    if (nlIdx > 0) splitIdx = nlIdx + 1;
  }

  if (splitIdx <= 0) return;

  // Don't split in the middle of a code fence block
  const beforeSplit = raw.slice(0, splitIdx);
  const fencesInBefore = beforeSplit.match(/^```/gm);
  if (fencesInBefore && fencesInBefore.length % 2 !== 0) return;

  // Don't split in the middle of a markdown table block
  // A table is a contiguous run of lines matching /^\s*\|.*\|/
  const afterSplit = raw.slice(splitIdx);
  const beforeLines = beforeSplit.trimEnd().split('\n');
  const lastLineOfBefore = beforeLines[beforeLines.length - 1] || '';
  const afterLines = afterSplit.split('\n');
  const firstLineOfAfter = (afterLines[0] || '').trim();
  // Case 1: split point is between two table rows
  if (/^\s*\|.*\|/.test(lastLineOfBefore) && /^\s*\|.*\|/.test(firstLineOfAfter)) {
    return; // still inside a table, wait for more data
  }
  // Case 2: afterSplit starts with a table row and beforeSplit recently had table rows
  // (handles tables separated by a blank line in AI output)
  if (/^\s*\|.*\|/.test(firstLineOfAfter)) {
    const recentTableLine = beforeLines.slice(-5).some(l => /^\s*\|.*\|/.test(l));
    if (recentTableLine) return; // likely a continuation of the same table
  }
  // Case 3: beforeSplit ends with a table row but afterSplit has more table rows coming
  if (/^\s*\|.*\|/.test(lastLineOfBefore) && afterLines.slice(0, 3).some(l => /^\s*\|.*\|/.test(l.trim()))) {
    return; // table continues after a gap
  }

  const toRender = beforeSplit.trim();
  streamState._textBuffer = raw.slice(splitIdx);

  if (!toRender) return;
  _renderTextBlock(toRender);
}

// Strong breakpoints for non-force streaming flush (tool call interruption).
const _TEXT_STRONG_BREAK_TAIL_RE = /[\s\n。，、；：！？.,;:!?…\u3000)\]》）】」』"'`]$/;
const _NONFORCE_MIN_VISIBLE_CHARS = 14;
const _NONFORCE_TAIL_HOLD_CHARS = 18;

function flushTextBuffer(streamState, c, force = false) {
  // G1/G2: 如果有 AdaptiveChunker，优先使用新管道
  if (streamState._chunker && force) {
    streamState._chunker.flushAll();
    streamState._textBuffer = '';
    return;
  }

  const raw = streamState._textBuffer || '';
  if (!raw) return;

  let toRender = raw;
  let remainder = '';

  // In non-force mode (tool call about to display), keep a trailing fragment
  // so sentence halves are not printed before the continuation arrives.
  if (!force && toRender.length > 0 && !_TEXT_STRONG_BREAK_TAIL_RE.test(toRender)) {
    let splitIdx = -1;
    for (let i = toRender.length - 1; i >= 0; i--) {
      const code = toRender.charCodeAt(i);
      if (code >= 0xDC00 && code <= 0xDFFF) continue;
      if (_TEXT_STRONG_BREAK_TAIL_RE.test(toRender[i])) {
        splitIdx = i + 1;
        break;
      }
    }
    if (splitIdx > 0) {
      remainder = toRender.slice(splitIdx);
      toRender = toRender.slice(0, splitIdx);
    } else if (toRender.length > _NONFORCE_MIN_VISIBLE_CHARS) {
      const holdChars = Math.min(
        _NONFORCE_TAIL_HOLD_CHARS,
        Math.max(8, Math.floor(toRender.length * 0.35))
      );
      splitIdx = Math.max(1, toRender.length - holdChars);
      remainder = toRender.slice(splitIdx);
      toRender = toRender.slice(0, splitIdx);
    } else {
      remainder = toRender;
      toRender = '';
    }
  }

  const buf = toRender.trim();
  streamState._textBuffer = remainder;
  if (!buf) return;
  _renderTextBlock(buf);
}

/**
 * Render a finalized text block with full markdown formatting.
 * Applies output limiting for very long blocks (virtual scroll substitute):
 * - Blocks under MAX_RENDER_LINES render fully
 * - Longer blocks show head + tail + fold indicator
 */
const _MAX_RENDER_LINES = 120;
const _RENDER_HEAD = 50;
const _RENDER_TAIL = 30;

function _renderTextBlock(text) {
  try {
    const renderer = require('./aiRenderer');
    const { syncWrite } = require('./syncOutput');
    const rendered = renderer.renderAiResponse(text);
    const lines = rendered.split('\n');

    if (lines.length <= _MAX_RENDER_LINES) {
      syncWrite(() => {
        lines.forEach(l => console.log(`  ${l}`));
      });
    } else {
      // Long output: head + fold + tail (virtual scroll substitute)
      const _chalk = require('chalk').default || require('chalk');
      const headLines = lines.slice(0, _RENDER_HEAD);
      const tailLines = lines.slice(-_RENDER_TAIL);
      const folded = lines.length - _RENDER_HEAD - _RENDER_TAIL;
      syncWrite(() => {
        headLines.forEach(l => console.log(`  ${l}`));
        console.log(`  ${_chalk.dim(`... +${folded} 行已折叠 (ctrl+o 查看完整)`)}`);
        tailLines.forEach(l => console.log(`  ${l}`));
      });
      // Store for ctrl+o expansion
      try {
        renderer.pushExpandableOutput({ tool: 'AI Response', detail: lines.join('\n'), paramStr: '' });
      } catch { /* best effort */ }
    }
  } catch {
    console.log(`  ${text}`);
  }
}

function closeTextStream(streamState, c) {
  flushTextBuffer(streamState, c, true);
}

function normalizePathLike(inputPath = '') {
  const p = String(inputPath || '').trim();
  if (!p) return '';
  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  return path.isAbsolute(p) ? p : path.resolve(cwd, p);
}

function maybeRenderWriteDiff(toolName, params, result, c) {
  try {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    if (name !== 'writefile' && name !== 'write' && name !== 'editfile' && name !== 'edit' && name !== 'multiedit') return;
    if (!result || !result.success) return;
    const diffCtx = result._khyWriteDiff || null;
    const absPath = normalizePathLike(diffCtx?.filePath || result.path || result.file || params?.path || params?.file_path || params?.filePath || '');
    if (!absPath) return;
    const nextContent = diffCtx && typeof diffCtx.afterContent === 'string'
      ? diffCtx.afterContent
      : String(params?.content ?? '');
    const prevContent = diffCtx && typeof diffCtx.beforeContent === 'string'
      ? diffCtx.beforeContent
      : '';
    if (prevContent === nextContent) return;

    const renderer = require('./aiRenderer');
    const relPath = path.relative(process.cwd(), absPath) || absPath;

    if (!prevContent && nextContent) {
      // New file — Claude Code style: green content preview (max 10 lines)
      const lines = nextContent.split('\n');
      const maxPreview = 10;
      const shown = lines.slice(0, maxPreview);
      for (let i = 0; i < shown.length; i++) {
        const num = String(i + 1).padStart(4);
        console.log(c.bgHex('#225C2B').hex('#FFFFFF')(`    ${num} + ${shown[i]}`));
      }
      if (lines.length > maxPreview) {
        console.log(c.dim(`    ... +${lines.length - maxPreview} lines (ctrl+o to expand)`));
      }
    } else {
      // Existing file — red/green structured diff
      const rendered = renderer.renderStructuredDiff(prevContent, nextContent, relPath);
      rendered.split('\n').forEach(line => console.log(`    ${line}`));
    }
  } catch {
    // non-critical
  }
}

function maybeRenderInlineDiffFromToolOutput(toolName, result, c) {
  try {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    if (name !== 'shellcommand' && name !== 'shell' && name !== 'bash' && name !== 'command') return;
    if (!result || !result.success) return;
    const out = String(result.output || result.content || '');
    const diffPattern = /(^|\n)(\+\+\+|---|@@|\+[^+].*|-[^-].*)/m;
    if (!diffPattern.test(out)) return;
    const rendered = require('./aiRenderer').renderDiff(out);
    rendered.split('\n').slice(0, 120).forEach(line => console.log(`    ${line}`));
  } catch {
    // non-critical
  }
}

// ── Directory tree builder for drag-and-drop directory support ──
const _DIR_SKIP = new Set(['node_modules', '.git', 'dist', 'build', '__pycache__', '.next', '.nuxt', '.cache', '.tox', '.venv', 'venv', 'env', '.eggs', '*.egg-info', 'coverage', '.nyc_output', 'bower_components', '.svn', '.hg']);
function _buildDirTree(root, opts = {}) {
  const maxDepth = opts.maxDepth || 3;
  const maxFiles = opts.maxFiles || 80;
  let fileCount = 0;
  const lines = [];

  function walk(dir, prefix, depth) {
    if (depth > maxDepth || fileCount > maxFiles) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    entries.sort((a, b) => {
      if (a.isDirectory() && !b.isDirectory()) return -1;
      if (!a.isDirectory() && b.isDirectory()) return 1;
      return a.name.localeCompare(b.name);
    });
    const filtered = entries.filter(e => !e.name.startsWith('.') || e.name === '.env.example')
      .filter(e => !_DIR_SKIP.has(e.name));
    for (let i = 0; i < filtered.length && fileCount <= maxFiles; i++) {
      const entry = filtered[i];
      const isLast = i === filtered.length - 1;
      const connector = isLast ? '└── ' : '├── ';
      const childPrefix = prefix + (isLast ? '    ' : '│   ');
      if (entry.isDirectory()) {
        lines.push(`${prefix}${connector}${entry.name}/`);
        walk(path.join(dir, entry.name), childPrefix, depth + 1);
      } else {
        lines.push(`${prefix}${connector}${entry.name}`);
        fileCount++;
      }
    }
    if (fileCount > maxFiles) {
      lines.push(`${prefix}... (truncated, >${maxFiles} files)`);
    }
  }

  lines.push(path.basename(root) + '/');
  walk(root, '', 0);
  return { text: lines.join('\n'), fileCount };
}

function extractInlineImageIntent(input = '', sceneHint = '') {
  const text = String(input || '').trim();
  if (!text) return null;

  const pathAtom = '(?:file:\\/\\/[^"\'`<>]+?\\.(?:png|jpg|jpeg|gif|webp)|(?:[A-Za-z]:[\\\\/])[^"\'`<>]+?\\.(?:png|jpg|jpeg|gif|webp)|(?:\\/|\\.\\/|\\.\\.\\/)[^"\'`<>]+?\\.(?:png|jpg|jpeg|gif|webp))';
  const quotedPattern = new RegExp(`(["'\`])(${pathAtom})\\1`, 'i');
  const unquotedPattern = new RegExp(
    '(file:\\/\\/[^\\s"\'`<>]+?\\.(?:png|jpg|jpeg|gif|webp)|(?:[A-Za-z]:[\\\\/])[^\\s"\'`<>]+?\\.(?:png|jpg|jpeg|gif|webp)|(?:\\/|\\.\\/|\\.\\.\\/)[^\\s"\'`<>]+?\\.(?:png|jpg|jpeg|gif|webp))',
    'i'
  );

  let pathText = '';
  let matchedSpan = '';
  let idx = -1;

  const quotedMatch = quotedPattern.exec(text);
  if (quotedMatch && quotedMatch[2]) {
    pathText = quotedMatch[2];
    matchedSpan = quotedMatch[0];
    idx = quotedMatch.index;
  } else {
    const unquotedMatch = unquotedPattern.exec(text);
    if (!unquotedMatch || !unquotedMatch[1]) return null;
    pathText = unquotedMatch[1];
    matchedSpan = unquotedMatch[0];
    idx = unquotedMatch.index;
  }
  if (!pathText || idx < 0) return null;

  const promptText = `${text.slice(0, idx)} ${text.slice(idx + matchedSpan.length)}`
    .replace(/\s+/g, ' ')
    .trim();

  return {
    filePath: pathText,
    prompt: buildContextualImagePrompt(promptText, `${text} ${sceneHint}`),
  };
}

function buildImageSceneHint(sceneHint = '', history = []) {
  const base = String(sceneHint || '').trim();
  if (!Array.isArray(history) || history.length === 0) return base;

  const recentHints = history
    .slice(-10)
    .map(line => String(line || '').trim())
    .filter(Boolean)
    .filter(line => !/^\/(?:status|help|trace|usage|new|clear|exit|model|think|plan|menu)\b/i.test(line))
    .filter(line => !/^(?:paste|粘贴|clipboard|剪贴板|image|图片|img)\b/i.test(line))
    .slice(-4);

  return [base, ...recentHints].filter(Boolean).join(' ');
}

function isWebRebuildIntent(text = '') {
  const s = String(text || '').toLowerCase();
  if (!s) return false;

  const zhRebuild = /(还原|复刻|重建|仿写|临摹|转成|生成|做成|转换).*(网页|页面|网站|html|web)/;
  const zhWebFirst = /(网页|页面|网站).*(还原|复刻|重建|仿写|临摹|转成|生成|做成|转换)/;
  const enRebuild = /(rebuild|recreate|replicate|clone|convert|generate).*(web|website|webpage|html|css)/;
  const screenshotToCode = /(screenshot|image|ui).*(to|into).*(html|web|website|webpage|css)/;
  const explicitTech = /(网页截图|页面截图|website screenshot|webpage screenshot|figma).*(html|css|web|网页|页面)/;

  return zhRebuild.test(s)
    || zhWebFirst.test(s)
    || enRebuild.test(s)
    || screenshotToCode.test(s)
    || explicitTech.test(s);
}

function buildWebRebuildPrompt(rawPrompt = '') {
  const userGoal = String(rawPrompt || '').trim() || '请把这张网页截图还原成可运行网页代码。';
  return [
    userGoal,
    '',
    '请按以下要求执行：',
    '1) 先简要说明页面结构分区与视觉风格（例如 header / hero / cards / footer）；',
    '2) 输出一个可直接运行的完整 HTML（必须包含 <style>，必要时可包含少量 <script>）；',
    '3) 尽量还原布局、间距、颜色、字体层级、按钮/卡片样式与阴影；',
    '4) 页面需具备响应式能力（桌面和移动端都可用）；',
    '5) 可识别文字尽量还原，不可识别处使用 [待补文案] 占位；',
    '6) 无法确定的图片/图标资源用语义化占位，并在代码注释写 TODO；',
    '7) 最后补充“还原误差说明”和“后续微调清单”。',
    '',
    '输出格式要求：先给简短说明，再给 ```html 代码块，不要省略关键样式。',
  ].join('\n');
}

function buildContextualImagePrompt(rawPrompt = '', sceneHint = '') {
  const prompt = String(rawPrompt || '').trim();
  const normalizedPrompt = prompt
    .toLowerCase()
    .replace(/[，。！？,.!?]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  const context = `${prompt} ${String(sceneHint || '')}`.toLowerCase();
  if (isWebRebuildIntent(context)) {
    return buildWebRebuildPrompt(prompt);
  }
  const genericPatterns = [
    /^请?(?:分析|看看|看下|看一下)(?:这张|这个)?(?:图片|图|截图)?$/,
    /^(?:描述|说说)(?:这张|这个)?(?:图片|图|截图)(?:的内容)?$/,
    /^(?:这|这个|这张)(?:是什么|是啥|啥)$/,
    /^analy[sz]e(?: this)? (?:image|picture|photo|screenshot)$/,
    /^describe(?: this)? (?:image|picture|photo|screenshot)$/,
    /^what(?:'s| is) this(?: image| picture| photo| screenshot)?$/,
    /^(?:look at|check)(?: this)? (?:image|picture|photo|screenshot)$/,
  ];
  const isGeneric = !prompt
    || /^(?:image|picture|photo|screenshot|图片|截图|这张图|这个图)$/.test(normalizedPrompt)
    || genericPatterns.some(pattern => pattern.test(normalizedPrompt));

  if (!isGeneric) return prompt;

  if (/(报错|错误|异常|堆栈|traceback|stack|error|exception|failed)/i.test(context)) {
    return '请先提取图片中的报错/堆栈信息，再定位可能原因，并给出可执行的修复步骤。';
  }
  if (/(界面|ui|布局|对齐|样式|css|前端|按钮|截图|页面)/i.test(context)) {
    return '请检查这张界面截图中的布局与对齐问题，指出不对称点，并给出可落地的修改建议。';
  }
  if (/(代码|终端|日志|log|command|console|diff|patch)/i.test(context)) {
    return '请识别图片里的代码/终端/日志关键信息，结合上下文判断问题，并给出下一步执行命令或改动建议。';
  }
  if (/(k线|走势|行情|图表|trading|chart|candlestick)/i.test(context)) {
    return '请分析图表中的关键趋势与风险信号，并给出清晰的操作建议。';
  }
  if (/(ocr|识别|提取文字|翻译|translate|text)/i.test(context)) {
    return '请先OCR提取图片文字，再按上下文整理要点并给出结论。';
  }

  return '请先描述图片中的关键信息，再结合当前任务上下文推断我想完成的目标，并给出下一步可执行操作。';
}

/**
 * Load command history from file.
 */
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

/**
 * Save command history to file.
 */
function saveHistory(sessionHistory) {
  try {
    // 追加当前 session 历史到文件，保留之前 session 的记录（用于 resume 等）
    const existing = loadHistory();
    const merged = [...existing, ...sessionHistory].slice(-MAX_HISTORY);
    fs.writeFileSync(HISTORY_FILE, merged.join('\n') + '\n');
  } catch { /* ignore */ }
}

/**
 * Offer interactive model selection at startup.
 * Shows a dropdown if multiple adapters/models are available.
 */
async function offerModelSelection() {
  const c = chalk();
  try {
    const aiGateway = require('../services/gateway/aiGateway');

    // Quick sync detection of available adapters
    const allStatus = aiGateway.getStatus();
    const availableAdapters = allStatus.filter(s => s.enabled && s.available);

    if (availableAdapters.length === 0) return;

    // Gather models from all available adapters via gateway.listModels
    const modelChoices = [];
    for (const adapter of availableAdapters) {
      try {
        const models = await aiGateway.listModels(adapter.type);
        if (models && models.length > 0) {
          for (const model of models) {
            modelChoices.push({
              name: `${adapter.name} → ${model.name || model.id}${model.isDefault ? ' (默认)' : ''}`,
              value: { adapter: adapter.type, model: model.id },
            });
          }
        } else {
          // Adapter without model list — add as single entry
          modelChoices.push({
            name: `${adapter.name}`,
            value: { adapter: adapter.type, model: null },
          });
        }
      } catch {
        // listModels not supported — add as single entry
        modelChoices.push({
          name: `${adapter.name}`,
          value: { adapter: adapter.type, model: null },
        });
      }
    }

    if (modelChoices.length <= 1) return; // No choice needed

    // Check if user has a saved preference — skip selection if so
    const currentAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const currentModel = process.env.GATEWAY_PREFERRED_MODEL;
    if (currentAdapter && currentModel) {
      // Already configured, show current and offer quick switch
      // Claude Code style: model info is shown in banner, not a separate line
      return;
    }

    // Show interactive selection
    const inq = inquirer();
    console.log('');
    const { selected } = await inq.prompt([{
      type: 'list',
      name: 'selected',
      message: '选择 AI 模型 (上下箭头选择，回车确认，Esc跳过):',
      choices: [
        ...modelChoices,
        { name: c.dim('────────────'), value: '__skip_sep__', disabled: true },
        { name: '跳过 (稍后用 khy gateway model 设置)', value: null },
      ],
      pageSize: 10,
    }]);

    if (selected) {
      process.env.GATEWAY_PREFERRED_ADAPTER = selected.adapter;
      process.env.GATEWAY_PREFERRED_STRICT = 'true';
      if (selected.model) process.env.GATEWAY_PREFERRED_MODEL = selected.model;
      try { await aiGateway.refreshAdapters(); } catch { /* best effort */ }
      fmt().printSuccess(`已选择: ${selected.adapter}${selected.model ? '/' + selected.model : ''}`);
    }

    // Ensure stdin is resumed after inquirer closes its readline
    // inquirer may pause stdin which prevents our readline from working
    try { process.stdin.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  } catch (e) {
    // B4: 模型选择恢复失败日志，便于诊断终端无响应
    try { console.error('[repl] 模型选择/stdin 恢复失败:', e?.message); } catch {}
    try { process.stdin.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  }
}

/**
 * Execute a menu result by mapping it back to command handlers.
 */
async function executeMenuResult(result) {
  if (!result) return;

  switch (result.action) {
    case 'quote': {
      const { handleQuote } = require('./handlers/data');
      await handleQuote(result.symbol);
      break;
    }
    case 'backtest-run': {
      const { handleBacktestRun } = require('./handlers/backtest');
      await handleBacktestRun(result.symbol, {
        strategy: result.strategy,
        start: result.start,
        end: result.end,
        capital: result.capital,
      });
      break;
    }
    case 'data-fetch': {
      const { handleDataFetch } = require('./handlers/data');
      await handleDataFetch(result.symbol);
      break;
    }
    case 'data-list': {
      const { handleDataList } = require('./handlers/data');
      await handleDataList();
      break;
    }
    case 'cache-clear': {
      const { handleCacheClear } = require('./handlers/data');
      await handleCacheClear();
      break;
    }
    case 'server-start': {
      const { handleServerStart } = require('./handlers/service');
      await handleServerStart();
      break;
    }
    case 'server-status': {
      const { handleServerStatus } = require('./handlers/service');
      await handleServerStatus();
      break;
    }
    case 'db-init': {
      const { handleDbInit } = require('./handlers/service');
      await handleDbInit();
      break;
    }
    case 'db-seed': {
      const { handleDbSeed } = require('./handlers/service');
      await handleDbSeed();
      break;
    }
    case 'db-status': {
      const { handleDbStatus } = require('./handlers/service');
      await handleDbStatus();
      break;
    }
    case 'app-list': {
      const { handleApp } = require('./handlers/app');
      await handleApp('list', [], {});
      break;
    }
    case 'app-status': {
      const { handleApp } = require('./handlers/app');
      await handleApp('status', [], {});
      break;
    }
    case 'app-start': {
      const { handleApp } = require('./handlers/app');
      await handleApp('start', [result.appName], {});
      break;
    }
    case 'app-stop': {
      const { handleApp } = require('./handlers/app');
      await handleApp('stop', [result.appName], {});
      break;
    }
    case 'ai-status':
      await ai().handleAiStatus();
      break;
    case 'ai-config':
      await ai().handleAiConfig();
      break;
    case 'doctor': {
      const { handleDoctor } = require('./handlers/init');
      await handleDoctor();
      break;
    }
    case 'gateway-status': {
      const { handleGatewayStatus } = require('./handlers/gateway');
      await handleGatewayStatus();
      break;
    }
    case 'gateway-config': {
      const { handleGatewayConfig } = require('./handlers/gateway');
      await handleGatewayConfig();
      break;
    }
    case 'gateway-relay': {
      const { handleGatewayRelay } = require('./handlers/gateway');
      await handleGatewayRelay();
      break;
    }
    case 'gateway-select-model': {
      const { handleGatewaySelectModel } = require('./handlers/gateway');
      await handleGatewaySelectModel();
      break;
    }
    case 'docs-quickstart': {
      const { handleDocsQuickstart } = require('./handlers/docs');
      await handleDocsQuickstart();
      break;
    }
    case 'docs-ai-fastlane': {
      const { handleDocsAiFastlane } = require('./handlers/docs');
      await handleDocsAiFastlane();
      break;
    }
    case 'docs-ai-fastlane-copy': {
      const { handleDocsAiFastlane } = require('./handlers/docs');
      await handleDocsAiFastlane(['copy']);
      break;
    }
    case 'docs-claude': {
      const { handleDocsClaude } = require('./handlers/docs');
      await handleDocsClaude();
      break;
    }
    case 'docs-gateway': {
      const { handleDocsGateway } = require('./handlers/docs');
      await handleDocsGateway();
      break;
    }
    case 'docs-strategy': {
      const { handleDocsStrategy } = require('./handlers/docs');
      await handleDocsStrategy();
      break;
    }
    case 'docs-faq': {
      const { handleDocsFaq } = require('./handlers/docs');
      await handleDocsFaq();
      break;
    }
  }
}

/**
 * Start the interactive REPL loop.
 */
async function startRepl(options = {}) {
  // Mark interactive REPL context so router can avoid low-level clear conflicts.
  process.env.KHY_REPL_ACTIVE = '1';
  const runtimeMode = String(options.mode || process.env.KHY_RUNTIME_MODE || 'khyquant').toLowerCase();
  const enablePluginAutoload = (
    options.enablePluginAutoload !== undefined
      ? !!options.enablePluginAutoload
      : String(process.env.KHY_PLUGIN_AUTOLOAD || 'true').toLowerCase() !== 'false'
  );
  const claudeUiEnabled = (
    options.claudeUi !== undefined
      ? !!options.claudeUi
      : String(process.env.KHY_CLAUDE_UI || 'true').toLowerCase() !== 'false'
  );
  const showGettingStarted = (
    options.showGettingStarted !== undefined
      ? !!options.showGettingStarted
      : String(
        process.env.KHY_SHOW_GETTING_STARTED
        || (claudeUiEnabled ? 'false' : 'true')
      ).toLowerCase() !== 'false'
  );
  const startupModelPickerEnabled = (
    options.startupModelPicker !== undefined
      ? !!options.startupModelPicker
      : String(process.env.KHY_STARTUP_MODEL_PICKER || 'false').toLowerCase() === 'true'
  );

  // Load formatters + chalk now (needed for REPL UI)
  const { printBanner, printError, printErrorPanel, printSuccess, printInfo, printWarn, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell, getClassicMonsterPetLines } = fmt();
  const c = chalk();
  const { parseInput, route, getCompletions } = router();
  const { compactAiErrorReply, compactGatewayStatusText } = require('./errorSummary');

  // Load renderer constants for inline use
  const { DOT_PENDING, DOT_INDICATOR, DOT_SUCCESS, DOT_ERROR } = require('./aiRenderer');
  const TREE_LAST = '└';

  // ── One-shot mode: formatted single query then return ──
  if (options.oneShot && options.prompt) {
    const renderer = require('./aiRenderer');
    const aiProvider = ai().getActiveProvider() || 'AI';
    console.log('');
    renderer.printStepLine('active', '请求 AI', aiProvider);

    let thinkingStarted = false;
    const oneShotThinkingState = { thinkingLineOpen: false, thinkingCol: 0 };
    const result = await ai().chat(options.prompt, {
      onChunk: (chunk) => {
        if (chunk.type === 'thinking' && !thinkingStarted) {
          thinkingStarted = true;
          if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
          renderer.printStepLine('success', '请求 AI', aiProvider);
          console.log('');
          console.log(c.yellow(`  ${ICON_BOT} 思考过程:`));
        }
        if (chunk.type === 'thinking') {
          streamThinkingChunk(chunk.text, oneShotThinkingState, c);
        }
      },
    });

    if (thinkingStarted) {
      closeThinkingStream(oneShotThinkingState);
      console.log('');
    } else {
      if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
    }

    if (result.reply) {
      const meta = [
        result.elapsed ? `${(result.elapsed / 1000).toFixed(1)}s` : '',
        result.tokenUsage ? `${result.tokenUsage.totalTokens} tokens` : '',
      ].filter(Boolean).join(' · ');
      renderer.printStepLine('success', 'AI 回复', result.provider || 'local', meta);
      renderer.renderAiResponse(result.reply).split('\n').forEach(l => console.log(`  ${l}`));
    } else {
      printError('AI 未返回有效回复');
    }
    console.log('');
    return;
  }

  // Set terminal window title
  setTerminalTitle('khy OS');

  function formatShortCwd() {
    const cwd = process.cwd();
    const home = os.homedir();
    if (cwd === home) return '~';
    if (cwd.startsWith(home + path.sep)) return '~' + cwd.slice(home.length);
    return cwd;
  }

  function tryPrintMascotImagePreview() {
    if (!process.stdout.isTTY) return false;
    const term = String(process.env.TERM_PROGRAM || '');
    const supportsInlineImage = term === 'iTerm.app' || term === 'WezTerm' || !!process.env.KITTY_WINDOW_ID;

    const configured = String(process.env.KHY_MASCOT_IMAGE || '').trim();
    const candidates = [];
    if (configured) candidates.push(path.resolve(configured));
    candidates.push(path.resolve(__dirname, '../../assets/mascot/xuanniao-original.jpg'));

    for (const imgPath of candidates) {
      if (!fs.existsSync(imgPath)) continue;
      if (supportsInlineImage) {
        try {
          const imageService = require('../services/imageService');
          const image = imageService.readImageFromFile(imgPath);
          imageService.printImagePreview(image);
          return true;
        } catch {
          // Try terminal text fallback (chafa) below.
        }
      }
      try {
        const { spawnSync } = require('child_process');
        const cols = process.stdout.columns || 80;
        const width = Math.max(36, Math.min(72, cols - 8));
        const height = Math.max(12, Math.min(24, Math.floor(width * 0.45)));
        const result = spawnSync('chafa', [`--size=${width}x${height}`, imgPath], {
          encoding: 'utf-8',
          stdio: ['ignore', 'pipe', 'pipe'],
        });
        if (result && result.status === 0 && String(result.stdout || '').trim()) {
          console.log('');
          console.log(String(result.stdout).trimEnd());
          return true;
        }
      } catch {
        // Try the next candidate path.
      }
    }
    return false;
  }

  function printResumeRecoveryHints(savedMeta) {
    const sessionId = String(savedMeta?.sessionId || '').trim();
    if (!sessionId) {
      let fallbackId = '';
      try {
        const latest = ai().listConversations()[0];
        fallbackId = String(latest?.sessionId || '').trim();
      } catch { /* ignore */ }
      if (fallbackId) {
        if (savedMeta && savedMeta.success === false) {
          console.log(c.dim('  未写入新的会话快照，已回退到最近可恢复会话'));
        }
        console.log(c.dim(`  恢复命令: khy resume ${fallbackId}`));
      } else {
        console.log(c.dim('  对话摘要已保存，下次输入 /resume 恢复上下文'));
      }
      return;
    }
    console.log(c.dim(`  会话已保存，恢复命令: khy resume ${sessionId}`));
  }

  let _startupHeaderRendered = false;
  function renderStartupHeader(force = false) {
    if (_startupHeaderRendered && !force) return;
    _startupHeaderRendered = true;
    const aiProvider = ai().getActiveProvider();
    if (!claudeUiEnabled) {
      printBanner(VERSION, aiProvider);
      if (showGettingStarted) {
        try {
          const gettingStarted = require('../services/gettingStartedService');
          gettingStarted.displayGettingStarted();
        } catch { /* non-critical */ }
      }
      return;
    }

    let modelName = '';
    let effortLabel = 'high effort';
    let billingType = 'API Usage Billing';
    let adapterName = '';
    try {
      const gateway = require('../services/gateway/aiGateway');
      const active = gateway.getActiveAdapter();
      modelName = active?.activeModel || '';
      adapterName = active?.name || active?.type || '';
    } catch { /* best effort */ }

    if (!modelName) modelName = process.env.GATEWAY_PREFERRED_MODEL || 'auto';
    if (!adapterName) adapterName = process.env.GATEWAY_PREFERRED_ADAPTER || aiProvider || 'auto';

    // Determine billing type
    if (/ollama|local|llama/i.test(adapterName)) billingType = 'Local Model';
    else if (/relay|web|clipboard/i.test(adapterName)) billingType = 'Relay';

    // Effort level
    try {
      const effort = ai().getEffort ? ai().getEffort() : 'high';
      const labels = { max: 'max effort', high: 'high effort', medium: 'medium effort', low: 'low effort' };
      effortLabel = labels[effort] || 'high effort';
    } catch { /* best effort */ }

    const cols = process.stdout.columns || 80;

    // Try original mascot image first (inline image or chafa fallback),
    // then keep the text UI below as stable fallback.
    const imagePreviewShown = tryPrintMascotImagePreview();

    // ── Claude Code style bordered box ──
    // Layout:
    // ╭─── khy OS vX.Y.Z ───────────────────────────╮
    // │                                               │
    // │   Welcome back!        Tips for getting started│
    // │                        Run /init to create...  │
    // │   [mascot sprite]                              │
    // │                        Recent activity         │
    // │                        No recent activity      │
    // │                                               │
    // │   Model with effort · Billing                 │
    // │       /working/directory                      │
    // ╰───────────────────────────────────────────────╯

    const boxWidth = Math.min(cols - 4, 76);
    // Inner content width: box is "  ╭...╮" where visible = 2 indent + boxWidth chars.
    // Content lines: "  │ " (4 visible) + content + " │" (2 visible) = boxWidth,
    // so content area = boxWidth - 6. But use boxWidth - 2 for border chars total.
    const contentWidth = boxWidth - 2; // between │ and │ (including padding spaces)
    const innerWidth = contentWidth - 2; // minus " " padding on each side: "│ {inner} │"
    const dim = c.dim;
    const orange = c.hex('#D77757');

    // Measure visible display width, stripping ANSI codes and accounting for CJK/emoji
    const visLen = (s) => {
      const stripped = s.replace(/\x1b\[[0-9;]*m/g, '');
      let w = 0;
      for (const ch of stripped) w += getDisplayWidthChar(ch);
      return w;
    };

    // Pad/truncate content to exact visible width
    const padLine = (content, width) => {
      const gap = Math.max(0, width - visLen(content));
      return content + ' '.repeat(gap);
    };

    // Helper: build a full box row "  │ {content padded to innerWidth} │"
    const boxRow = (content) => {
      return dim('  │ ') + padLine(content, innerWidth) + dim(' │');
    };

    // Title line
    const titleText = ` khy OS v${VERSION} `;
    const topDashes = contentWidth - titleText.length; // dashes between ╭ and ╮
    const topLeft = Math.floor(topDashes / 2);
    const topRight = topDashes - topLeft;
    console.log('');
    console.log(dim(`  ╭${'─'.repeat(Math.max(1, topLeft))}`) + dim(titleText) + dim(`${'─'.repeat(Math.max(1, topRight))}╮`));

    // Pet sprite + right-side info
    const petBronze = c.hex('#D77757');
    const petLinesFallback = typeof getClassicMonsterPetLines === 'function'
      ? getClassicMonsterPetLines(petBronze)
      : (() => {
        // Inline fallback: Chinese phoenix (Xuan Niao) single-color
        const z = petBronze;
        const d = c.dim;
        return [
          `       ${z('▄█▄')}`,
          `     ${z('▄█▀█▀█▄')}`,
          `     ${z('█▌░▀░▐█')}`,
          `      ${z('▜███▛')}`,
          `  ${z('▗▟████████▙▖')}`,
          `   ${z('▝▀▀▄██▄▀▀▘')}`,
          `       ${d('▐▌')}`,
        ];
      })();
    const petLines = imagePreviewShown
      ? Array(7).fill('')
      : petLinesFallback;

    // Left column width (pet + "Welcome back!")
    const leftColW = Math.floor(innerWidth * 0.45);
    const rightColW = innerWidth - leftColW;

    // Tips / activity section — 动态信息
    const green = c.hex('#4EBA65');

    // Auth method detection
    let authMethod = 'API Key';
    try {
      if (/relay|clipboard/i.test(adapterName)) authMethod = 'Relay';
      else if (/oauth/i.test(adapterName)) authMethod = 'OAuth';
      else if (/ollama|local/i.test(adapterName)) authMethod = 'Local';
      else if (process.env.ANTHROPIC_API_KEY || process.env.OPENAI_API_KEY) authMethod = 'API Key';
    } catch {}

    // Context window
    let ctxWindow = '';
    try {
      const contextLimit = ai().getContextLimit ? ai().getContextLimit() : 0;
      if (contextLimit > 0) ctxWindow = `${Math.round(contextLimit / 1000)}k tokens`;
    } catch {}

    // Gateway status
    let gatewayStatus = '';
    try {
      const gw = require('../services/gateway/aiGateway');
      const statuses = typeof gw.getStatus === 'function' ? gw.getStatus() : [];
      const available = statuses.filter(s => s.available);
      if (available.length > 0) {
        gatewayStatus = `${available.length} 个适配器就绪`;
      } else if (statuses.length > 0) {
        gatewayStatus = '已配置，检测中';
      } else {
        gatewayStatus = '就绪';
      }
    } catch { gatewayStatus = '就绪'; }

    // Git branch
    let gitBranch = '';
    try {
      const { execSync } = require('child_process');
      gitBranch = execSync('git rev-parse --abbrev-ref HEAD', {
        encoding: 'utf8',
        timeout: 3000,
        stdio: ['pipe', 'pipe', 'pipe'],
      }).trim();
    } catch {}

    const tipsHeader = green('System');
    const tipsBody = dim(`认证: ${authMethod}${ctxWindow ? ` · 上下文: ${ctxWindow}` : ''}`);
    const actHeader = green('Status');
    const actBody = dim(`网关: ${gatewayStatus}${gitBranch ? ` · 分支: ${gitBranch}` : ''}`);

    // Row 1: empty
    console.log(boxRow(''));

    // Row 2: "Welcome back!" + tips header
    const welcomeText = c.bold('Welcome back!');
    console.log(boxRow(padLine(`  ${welcomeText}`, leftColW) + padLine(tipsHeader, rightColW)));

    // Rows 3..N: phoenix lines + right-side intro/status
    // Spread right-side content across the 7-line sprite height
    const rightLines = ['', tipsBody, '', actHeader, actBody, '', ''];
    for (let i = 0; i < petLines.length; i++) {
      const right = rightLines[i] || '';
      console.log(boxRow(padLine(`  ${petLines[i]}`, leftColW) + padLine(right, rightColW)));
    }

    // Row 6: empty
    console.log(boxRow(''));

    // Row 7: model info
    const modelInfo = `${modelName} with ${effortLabel} · ${billingType}`;
    console.log(boxRow(`  ${dim(modelInfo)}`));

    // Row 8: working directory
    console.log(boxRow(`  ${dim(formatShortCwd())}`));

    // Bottom border
    console.log(dim(`  ╰${'─'.repeat(contentWidth)}╯`));
    console.log('');
  }

  renderStartupHeader(true);

  // Initialize proxy configuration from saved settings
  try {
    const proxyConfig = require('../services/proxyConfigService');
    proxyConfig.initFromConfig();
  } catch { /* proxy init is non-critical */ }

  // Auto-start Windows clipboard image bridge:
  // bitmap clipboard -> PNG file -> quoted file path text for Ctrl+V in CLI.
  try {
    const clipboardBridge = require('../services/windowsClipboardImg2FileService');
    const shouldAutoStart = String(process.env.KHY_CLIPBOARD_IMG2FILE_AUTO_START || 'true').toLowerCase() !== 'false';
    if (shouldAutoStart) {
      const bridgeResult = clipboardBridge.startClipboardImg2FileBridge();
      if (bridgeResult && bridgeResult.started) {
        const pollMs = bridgeResult.meta?.pollMs || 500;
        printInfo(`剪贴板桥接已启动：监听 Windows 位图剪贴板（轮询 ${pollMs}ms）并自动注入图片文件路径`);
      }
    }
  } catch {
    // Non-critical on unsupported environments.
  }

  // Initialize SDK plugin system (discovers and activates khy-* plugins)
  if (enablePluginAutoload) {
    try {
      const pluginLoader = require('../plugin-loader');
      const { createContextFactory } = require('../plugin-loader/contextFactory');
      const cmdRegistry = require('./commandRegistry');
      let aiGw = null;
      try { aiGw = require('../services/gateway/aiGateway'); } catch {}

      const contextFactory = createContextFactory({
        commandRegistry: cmdRegistry,
        toolRegistry: null,
        aiGateway: aiGw,
        logger: console,
        hostVersion: VERSION,
      });

      pluginLoader.init({
        hostVersion: VERSION,
        contextFactory,
        logger: { info: () => {}, warn: console.warn, error: console.error, debug: () => {} },
      }).catch(() => {}); // Non-blocking — don't hold up REPL
    } catch { /* plugin system is non-critical */ }
  }

  // Start periodic base self-check loop (can be disabled by KHY_SELF_CHECK_ENABLED=false)
  try {
    const selfCheck = require('../services/baseSelfCheckService');
    selfCheck.autoStartFromEnv();
  } catch { /* self-check is non-critical */ }

  // Start each session with a clean slate.
  // Previous conversations are saved on exit and can be restored explicitly
  // via /resume, which compacts and extracts key context before restoring.
  let _autoResumed = false;
  try {
    ai().clearHistory();
  } catch { /* non-critical */ }

  // ── State variables (must be before setTimeout calls and renderStatusBar) ──
  let _busy = false;
  let _busyStreaming = false; // true 当 AI 正在流式输出文本/thinking，不应重绘 prompt
  let _planMode = false;
  let _fastMode = false;
  let _effortLevel = 'medium'; // low/medium/high/max
  const _sessionStart = Date.now();
  let _ctrlCCount = 0;
  let _ctrlCTimer = null;
  let _lastTipShown = 0;
  let _recentCommands = [];
  const PATTERN_WINDOW = 5;
  let _startupTimers = [];

  // ── Deferred prefetch: all non-blocking startup tasks in one place ─────
  // Replaces 8+ individual setTimeout calls with a single managed module.
  // Falls back to empty array if the bootstrap module is not available.
  try {
    const { deferredPrefetch } = require('../bootstrap/prefetch');
    _startupTimers = deferredPrefetch({
      mode: runtimeMode === 'khy' ? 'khy' : 'khyquant',
      isBusy: () => _busy,
      onOutput: (msg) => {
        if (!_busy) {
          console.log(msg);
          try { rl.prompt(); } catch { /* ignore */ }
        }
      },
    });
  } catch {
    // Fallback: if bootstrap module unavailable, no deferred tasks.
    // This should never happen in normal operation but ensures safety.
  }

  // Startup model picker is opt-in (avoid unexpected operation prompts).
  if (startupModelPickerEnabled && process.stdin.isTTY && process.stdout.isTTY) {
    await offerModelSelection();
  }

  // Setup readline
  // 上箭头历史回放只限当前 session，不跨会话
  const _persistedHistory = loadHistory(); // 文件历史仅用于保存（追加本次输入）
  const history = [];

  // Build prompt with abbreviated working directory (like Claude Code)
  function buildCwdPrompt() {
    const cwd = process.cwd();
    const home = os.homedir();
    let display = cwd;
    if (cwd === home) {
      display = '~';
    } else if (cwd.startsWith(home + path.sep)) {
      display = '~' + cwd.slice(home.length);
    }
    // Shorten intermediate directories to first char if path is too long
    const parts = display.split(path.sep);
    if (parts.length > 3) {
      const last = parts.pop();
      const first = parts.shift();
      display = first + path.sep + parts.map(p => p[0] || p).join(path.sep) + path.sep + last;
    }
    return `${c.dim(display)} ${c.bold.cyan('>')} `;
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: buildCwdPrompt(),
    historySize: MAX_HISTORY,
    // Lower ESC ambiguity wait to improve perceived input responsiveness.
    escapeCodeTimeout: Math.max(10, parseInt(process.env.KHY_INPUT_ESCAPE_TIMEOUT_MS || '120', 10) || 120),
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });

  // readline history 只含当前 session 输入（不预填充文件历史）

  // Bottom HUD live bar mode:
  // - while user is typing: disabled (prevents input overlap)
  // - while command/AI is running: enabled
  let _liveHudEnabled = true;
  let _liveHudActive = false;
  try {
    const raw = String(process.env.KHY_LIVE_STATUS_BAR || 'true').trim().toLowerCase();
    _liveHudEnabled = !['0', 'false', 'off', 'no'].includes(raw);
  } catch { /* best effort */ }

  function _setLiveHudTypingMode() {
    if (!_liveHudEnabled || !_liveHudActive) return;
    try {
      const hud = require('./hudRenderer');
      hud.stopLiveStatusBar();
      _liveHudActive = false;
    } catch { /* non-critical */ }
  }

  function _setLiveHudWorkingMode() {
    if (!_liveHudEnabled || _liveHudActive) return;
    try {
      const hud = require('./hudRenderer');
      hud.startLiveStatusBar();
      _liveHudActive = true;
    } catch { /* non-critical */ }
  }

  // Start in typing mode to avoid covering prompt text.
  _setLiveHudTypingMode();

  // ── Intercept _ttyWrite to suppress echo during bracketed paste ──
  // Node.js readline echoes every character via _ttyWrite.  We must intercept
  // this to prevent pasted text from flooding the terminal.  The bracketed
  // paste markers (\e[200~ … \e[201~) arrive inside the raw data but readline
  // would blindly echo every byte before our `line` handler can act.

  // ── Inline slash picker state ──
  const _lowLatencyInputOpt = String(process.env.KHY_LOW_LATENCY_INPUT || '').toLowerCase();
  const _lowLatencyInputEnabled = ['1', 'true', 'yes', 'on'].includes(_lowLatencyInputOpt);
  let _slashPickerActive = false;
  let _slashFilter = '';
  let _slashMatches = [];
  let _slashSelectedIdx = 0;
  let _slashRenderedLines = 0;
  const SLASH_PICKER_MAX = 12;
  let _slashCommandsCache = null;
  let _slashRenderPending = false;  // Render throttle flag

  // ── Inline @ file picker state ──
  let _atPickerActive = false;
  let _atFilter = '';           // characters typed after '@'
  let _atMatches = [];          // filtered file/dir entries
  let _atSelectedIdx = 0;
  let _atRenderedLines = 0;
  let _atCurrentDir = '';       // absolute path of directory being browsed
  let _atAnchorCol = 0;         // cursor position in rl.line where '@' was typed
  const AT_PICKER_MAX = 14;
  let _atRenderPending = false;

  function _getSlashCommands() {
    if (_slashCommandsCache) return _slashCommandsCache;
    let cmds = [];
    try {
      const cmdReg = require('./commandRegistry');
      cmds = cmdReg.toSlashCommands();
    } catch {
      try {
        const { SLASH_COMMANDS } = router();
        cmds = SLASH_COMMANDS || [];
      } catch { /* ignore */ }
    }
    // Add extra commands not in commandRegistry (study, hud, etc.)
    const existing = new Set(cmds.map(sc => sc.cmd));
    const extras = [
      { cmd: '/study',    label: '学习模式',   desc: '学习模式开关（需密码）' },
      { cmd: '/hud',      label: 'HUD 面板',   desc: '显示 HUD 仪表盘' },
      { cmd: '/mind',     label: '思维导图',   desc: '查看 AI 当前任务节点与下一步', flag: 'mind' },
      { cmd: '/new',      label: '新会话',     desc: '新建会话（清空当前上下文）' },
      { cmd: '/reset',    label: '重置会话',   desc: '重置会话（同 /new）' },
      { cmd: '/think',    label: '思考强度',   desc: '设置思考强度 low|medium|high|max' },
      { cmd: '/trace',    label: '追踪开关',   desc: '调试追踪开关 on|off|status' },
      { cmd: '/pool',     label: 'Key 池',     desc: '查看 API Key 池状态（多账号轮询）' },
      { cmd: '/push',     label: '推送备份',   desc: '推送项目到 GitHub/Gitee 私人仓库备份' },
      { cmd: '/optimize', label: '自优化',     desc: 'AI 自我优化（分析经验并改进）' },
    ];
    for (const ex of extras) {
      if (!existing.has(ex.cmd)) {
        cmds.push(ex);
        existing.add(ex.cmd);
      }
    }
    _slashCommandsCache = cmds;
    return _slashCommandsCache;
  }

  function _filterSlashCommands(filter) {
    const cmds = _getSlashCommands();
    if (!filter || filter === '/') return cmds.slice();
    const lower = filter.toLowerCase();
    const needle = lower.slice(1); // strip leading '/'

    // Score: exact prefix > cmd substring > label/desc substring
    const scored = [];
    for (const sc of cmds) {
      const cmdLower = sc.cmd.toLowerCase();
      const labelLower = (sc.label || '').toLowerCase();
      const descLower = (sc.desc || '').toLowerCase();

      let score = 0;
      if (cmdLower.startsWith(lower)) score = 3;           // /mo → /model
      else if (cmdLower.includes(needle)) score = 2;       // sub → /subscribe
      else if (labelLower.includes(needle)) score = 1;     // 模型 → label match
      else if (descLower.includes(needle)) score = 1;      // desc match

      if (score > 0) scored.push({ sc, score });
    }

    scored.sort((a, b) => b.score - a.score);
    return scored.map(s => s.sc);
  }

  function _clearSlashPicker() {
    if (_slashRenderedLines <= 0 || !process.stdout.isTTY) return;
    const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
    const col = promptLen + fmt().displayWidth(rl.line || '');
    // Single ANSI write: down 1, col 1, clear below, up 1, restore col
    process.stdout.write(`\x1b[B\x1b[1G\x1b[J\x1b[A\x1b[${col + 1}G`);
    _slashRenderedLines = 0;
  }

  function _renderSlashPicker() {
    if (!process.stdout.isTTY) return;
    // Debounce: collapse rapid successive calls into one paint on next tick
    if (_slashRenderPending) return;
    _slashRenderPending = true;
    setImmediate(() => {
      _slashRenderPending = false;
      _renderSlashPickerNow();
    });
  }

  function _renderSlashPickerNow() {
    if (!process.stdout.isTTY) return;
    _slashMatches = _filterSlashCommands(_slashFilter);
    if (_slashMatches.length === 0) {
      _clearSlashPicker();
      return;
    }
    if (_slashSelectedIdx >= _slashMatches.length) _slashSelectedIdx = _slashMatches.length - 1;
    if (_slashSelectedIdx < 0) _slashSelectedIdx = 0;

    const visible = _slashMatches.slice(0, SLASH_PICKER_MAX);
    const cols = process.stdout.columns || 80;

    // Build picker lines with enhanced display
    const lines = [];
    const filterLower = (_slashFilter || '').toLowerCase().slice(1); // strip leading '/'
    for (let i = 0; i < visible.length; i++) {
      const sc = visible[i];
      // Highlight matching characters in command name
      let cmdDisplay = sc.cmd;
      if (filterLower) {
        const cmdLower = sc.cmd.toLowerCase();
        const matchIdx = cmdLower.indexOf(filterLower, 1); // skip '/'
        if (matchIdx > 0) {
          cmdDisplay = sc.cmd.slice(0, matchIdx)
            + `\x1b[1m${sc.cmd.slice(matchIdx, matchIdx + filterLower.length)}\x1b[22m`
            + sc.cmd.slice(matchIdx + filterLower.length);
        }
      }
      const label = sc.label ? `\x1b[36m${sc.label}\x1b[39m` : '';
      const desc = sc.desc || '';
      const cmdPad = sc.cmd.length < 16 ? ' '.repeat(16 - sc.cmd.length) : ' ';
      const labelPart = label ? ` ${label}` : '';
      const row = `  ${cmdDisplay}${cmdPad}${desc}${labelPart}`;
      const trimmedRow = row.length > cols + 20 ? row.slice(0, cols + 20) : row; // allow ANSI overhead
      if (i === _slashSelectedIdx) {
        lines.push(`\x1b[7m${trimmedRow}\x1b[27m`);
      } else {
        lines.push(`\x1b[2m${trimmedRow}\x1b[22m`);
      }
    }
    if (_slashMatches.length > SLASH_PICKER_MAX) {
      lines.push(`\x1b[2m  ... ${_slashMatches.length - SLASH_PICKER_MAX} more\x1b[22m`);
    }

    // Single write: move down, clear, content, move back up, restore col
    const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
    const col = promptLen + fmt().displayWidth(rl.line || '');
    const content = lines.join('\n');
    const up = lines.length;
    // \x1b[B = cursor down 1, \x1b[G = cursor to col 1, \x1b[J = clear below
    // After content: \x1b[{up}A = cursor up N, \x1b[{col+1}G = cursor to col
    process.stdout.write(
      `\x1b[B\x1b[1G\x1b[J${content}\x1b[${up}A\x1b[${col + 1}G`
    );
    _slashRenderedLines = lines.length;
  }

  function _acceptSlashPick() {
    const match = _slashMatches[_slashSelectedIdx];
    _clearSlashPicker();
    _slashPickerActive = false;
    if (!match) return;
    if (process.stdout.isTTY) {
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);
    }
    rl.line = '';
    rl.cursor = 0;
    // Suppress readline echo of the internal line prefix
    const savedOutput = rl.output;
    try {
      rl.output = null;
      rl.emit('line', `${INTERNAL_LINE_PREFIX}${match.cmd}`);
    } finally {
      rl.output = savedOutput;
    }
  }

  function _cancelSlashPicker() {
    _clearSlashPicker();
    _slashPickerActive = false;
    if (process.stdout.isTTY) {
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);
    }
    rl.line = '';
    rl.cursor = 0;
    rl.prompt();
  }

  // ── Inline @ file picker functions ──

  function _listAtEntries(dir, filter) {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return []; }
    const filtered = entries
      .filter(e => !_DIR_SKIP.has(e.name))
      .filter(e => !e.name.startsWith('.') || e.name === '.env.example' || e.name === '.claude')
      .sort((a, b) => {
        if (a.isDirectory() && !b.isDirectory()) return -1;
        if (!a.isDirectory() && b.isDirectory()) return 1;
        return a.name.localeCompare(b.name);
      });
    const result = filter
      ? filtered.filter(e => e.name.toLowerCase().includes(filter.toLowerCase()))
      : filtered;
    return result.map(e => ({
      name: e.name,
      display: e.isDirectory() ? `${e.name}/` : e.name,
      isDir: e.isDirectory(),
    }));
  }

  function _clearAtPicker() {
    if (_atRenderedLines <= 0 || !process.stdout.isTTY) return;
    const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
    const col = promptLen + fmt().displayWidth(rl.line || '');
    process.stdout.write(`\x1b[B\x1b[1G\x1b[J\x1b[A\x1b[${col + 1}G`);
    _atRenderedLines = 0;
  }

  function _renderAtPicker() {
    if (!process.stdout.isTTY) return;
    if (_atRenderPending) return;
    _atRenderPending = true;
    setImmediate(() => {
      _atRenderPending = false;
      _renderAtPickerNow();
    });
  }

  function _renderAtPickerNow() {
    if (!process.stdout.isTTY) return;
    _atMatches = _listAtEntries(_atCurrentDir, _atFilter);
    if (_atMatches.length === 0) { _clearAtPicker(); return; }
    if (_atSelectedIdx >= _atMatches.length) _atSelectedIdx = _atMatches.length - 1;
    if (_atSelectedIdx < 0) _atSelectedIdx = 0;

    const visible = _atMatches.slice(0, AT_PICKER_MAX);
    const cols = process.stdout.columns || 80;
    const lines = [];
    for (let i = 0; i < visible.length; i++) {
      const entry = visible[i];
      const row = `  + ${entry.display}`;
      const trimmedRow = row.length > cols - 1 ? row.slice(0, cols - 1) : row;
      if (i === _atSelectedIdx) {
        lines.push(`\x1b[7m${trimmedRow}\x1b[27m`);
      } else {
        lines.push(`\x1b[2m${trimmedRow}\x1b[22m`);
      }
    }
    if (_atMatches.length > AT_PICKER_MAX) {
      lines.push(`\x1b[2m  ... ${_atMatches.length - AT_PICKER_MAX} more\x1b[22m`);
    }

    const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
    const col = promptLen + fmt().displayWidth(rl.line || '');
    const content = lines.join('\n');
    const up = lines.length;
    process.stdout.write(`\x1b[B\x1b[1G\x1b[J${content}\x1b[${up}A\x1b[${col + 1}G`);
    _atRenderedLines = lines.length;
  }

  function _acceptAtPick() {
    const match = _atMatches[_atSelectedIdx];
    _clearAtPicker();
    if (!match) { _atPickerActive = false; return; }

    const cwd = process.env.KHYQUANT_CWD || process.cwd();

    if (match.isDir) {
      // Descend into directory
      _atCurrentDir = path.join(_atCurrentDir, match.name);
      _atFilter = '';
      _atSelectedIdx = 0;
      const relPath = path.relative(cwd, _atCurrentDir).replace(/\\/g, '/') + '/';
      const before = (rl.line || '').slice(0, _atAnchorCol);
      const after = (rl.line || '').slice(rl.cursor);
      const newLine = before + '@' + relPath + after;
      if (process.stdout.isTTY) {
        readline.clearLine(process.stdout, 0);
        readline.cursorTo(process.stdout, 0);
      }
      rl.line = newLine;
      rl.cursor = before.length + 1 + relPath.length;
      rl._refreshLine();
      _renderAtPicker();
      return;
    }

    // File selected
    _atPickerActive = false;
    const relDir = path.relative(cwd, _atCurrentDir).replace(/\\/g, '/');
    const relPath = relDir ? `${relDir}/${match.name}` : match.name;
    const before = (rl.line || '').slice(0, _atAnchorCol);
    const after = (rl.line || '').slice(rl.cursor);
    const newLine = before + '@' + relPath + ' ' + after;
    if (process.stdout.isTTY) {
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);
    }
    rl.line = newLine;
    rl.cursor = before.length + 1 + relPath.length + 1;
    rl._refreshLine();
  }

  function _cancelAtPicker() {
    _clearAtPicker();
    _atPickerActive = false;
  }

  // ── Claude Code style: raw stdin paste detection state ──
  // These must be in the outer function scope so _clearTransientInputState
  // and _flushRawPaste can access them.
  const RAW_PASTE_THRESHOLD = 40;  // chars — shorter than Claude's 800 for CJK/tables
  let _rawPasteActive = false;
  let _rawPasteBuf = [];
  let _rawPasteTimer = null;
  const RAW_PASTE_TIMEOUT_MS = 150;

  if (typeof rl._ttyWrite === 'function') {
    const _origTtyWrite = rl._ttyWrite.bind(rl);
    let _pasteBuf = [];
    let _pasteLinePrefix = '';

    // ── Claude Code style: raw stdin paste detection ──
    // When stdin delivers a chunk containing multiple newlines (>= 2) and
    // length above threshold, it is almost certainly a paste.  We set a flag
    // so _ttyWrite absorbs all subsequent keypress events into _rawPasteBuf
    // instead of forwarding them to readline.  A 150ms silence timer flushes
    // the accumulated content as a single paste.

    // Prepend so we see the raw data before readline's internal handler.
    // We cannot prevent readline from receiving the data (it has its own
    // listener), but by setting _rawPasteActive we make _ttyWrite swallow
    // all keypress events into our buffer.  The line events that readline
    // fires are empty/meaningless because _ttyWrite returns early.
    if (process.stdin.isTTY && !_lowLatencyInputEnabled) {
      process.stdin.prependListener('data', (chunk) => {
        const raw = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk || '');
        // Skip if already inside bracketed paste capture
        if (_pasteCapturing) return;
        // Skip if this is a bracketed paste (handled by _ttyWrite bracket logic)
        if (raw.includes('\x1b[200~') || raw.includes('[200~')) return;
        // Detect paste: multiple newlines + length above threshold
        const newlineCount = (raw.match(/[\r\n]/g) || []).length;
        if (raw.length >= RAW_PASTE_THRESHOLD && newlineCount >= 2) {
          _rawPasteActive = true;
          _rawPasteBuf.push(raw);
          if (_rawPasteTimer) clearTimeout(_rawPasteTimer);
          _rawPasteTimer = setTimeout(() => _flushRawPaste(), RAW_PASTE_TIMEOUT_MS);
          return;
        }
        // Continuation of an active raw paste (follow-up chunk)
        if (_rawPasteActive) {
          _rawPasteBuf.push(raw);
          if (_rawPasteTimer) clearTimeout(_rawPasteTimer);
          _rawPasteTimer = setTimeout(() => _flushRawPaste(), RAW_PASTE_TIMEOUT_MS);
        }
      });
    }

    function _flushRawPaste() {
      _rawPasteTimer = null;
      _rawPasteActive = false;
      const text = _rawPasteBuf.join('')
        .replace(/\r\n/g, '\n')
        .replace(/\r/g, '\n')
        .replace(/\x1b\[\?2004[hl]/g, '')
        .trim();
      _rawPasteBuf = [];
      if (!text) return;
      // Unified paste handling (busy or not): store as _pendingPaste,
      // inject tag into readline so user can add context before pressing Enter.
      _storePendingPaste(text, _origTtyWrite);
    }

    // ── DeepSeek-TUI style: rapid keystroke paste-burst detection ──
    // Tracks timing between consecutive keypress events.  When 3+ printable
    // characters arrive within BURST_CHAR_INTERVAL_MS, classify as paste.
    // During an active burst, Enter is converted to a buffered newline
    // instead of triggering readline submit.  After BURST_SUPPRESS_MS of
    // silence the buffer is flushed via _storePendingPaste.
    const BURST_CHAR_INTERVAL_MS = 12;  // DeepSeek uses 8ms; 12ms for Node overhead
    const BURST_MIN_CHARS = 3;
    const BURST_SUPPRESS_MS = 150;

    function _flushBurst() {
      if (_burstFlushTimer) { clearTimeout(_burstFlushTimer); _burstFlushTimer = null; }
      const wasActive = _burstActive;
      _burstActive = false;
      _burstConsecutive = 0;
      _burstLastCharAt = 0;
      _burstWindowUntil = 0;
      const text = _burstBuf.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
      _burstBuf = '';
      if (!text) return;
      if (wasActive) {
        _storePendingPaste(text, _origTtyWrite, '', false);
      }
    }

    function _resetBurstFlushTimer() {
      if (_burstFlushTimer) clearTimeout(_burstFlushTimer);
      _burstFlushTimer = setTimeout(() => _flushBurst(), BURST_SUPPRESS_MS);
    }

    rl._ttyWrite = function (s, key) {
      // When raw paste detection is active, swallow all keypress events.
      if (_rawPasteActive) return;

      const str = typeof s === 'string' ? s : (s ? s.toString() : '');
      const k = key || {};

      // ── Paste-burst detection (DeepSeek-TUI style) ──
      const isPlainChar = str.length === 1 && str >= ' ' && !k.ctrl && !k.meta;
      const isEnter = k.name === 'return' || k.name === 'enter';
      const now = Date.now();

      if (isPlainChar && !_pasteCapturing && !_slashPickerActive) {
        const elapsed = now - _burstLastCharAt;
        _burstLastCharAt = now;

        if (_burstLastCharAt > 0 && elapsed <= BURST_CHAR_INTERVAL_MS) {
          _burstConsecutive++;
          if (_burstConsecutive >= BURST_MIN_CHARS && !_burstActive) {
            _burstActive = true;
            // Retroactively grab what readline already has in its buffer
            const currentLine = String(rl.line || '');
            if (currentLine) {
              _burstBuf = currentLine;
              try { rl.write(null, { ctrl: true, name: 'u' }); } catch { rl.line = ''; rl.cursor = 0; }
            }
          }
        } else {
          _burstConsecutive = 1;
        }

        if (_burstActive) {
          _burstBuf += str;
          _burstWindowUntil = now + BURST_SUPPRESS_MS;
          _resetBurstFlushTimer();
          return; // Don't pass to readline
        }
      }

      // Enter during active burst or within suppress window → buffer as newline
      if (isEnter && !_pasteCapturing && (_burstActive || now < _burstWindowUntil)) {
        _burstBuf += '\n';
        _burstWindowUntil = now + BURST_SUPPRESS_MS;
        _resetBurstFlushTimer();
        return; // Don't let readline submit
      }

      // ── @ file picker mode — consume all keystrokes ──
      if (_atPickerActive) {
        if (k.name === 'escape' || (k.ctrl && k.name === 'c')) {
          _cancelAtPicker();
          return;
        }
        if (k.name === 'return' || k.name === 'tab') {
          _acceptAtPick();
          return;
        }
        if (k.name === 'up') {
          if (_atSelectedIdx > 0) _atSelectedIdx--;
          _renderAtPicker();
          return;
        }
        if (k.name === 'down') {
          if (_atSelectedIdx < _atMatches.length - 1) _atSelectedIdx++;
          _renderAtPicker();
          return;
        }
        if (k.name === 'backspace') {
          if (_atFilter.length <= 0) {
            _cancelAtPicker();
            _origTtyWrite(s, key);
            return;
          }
          _atFilter = _atFilter.slice(0, -1);
          _atSelectedIdx = 0;
          _origTtyWrite(s, key);
          _renderAtPicker();
          return;
        }
        if (str === '/' && _atMatches[_atSelectedIdx]?.isDir) {
          _acceptAtPick();
          return;
        }
        if (str === ' ') {
          if (_atMatches.length > 0) _acceptAtPick();
          else _cancelAtPicker();
          if (!_atPickerActive) _origTtyWrite(s, key);
          return;
        }
        if (str.length === 1 && str >= ' ') {
          _atFilter += str;
          _atSelectedIdx = 0;
          _origTtyWrite(s, key);
          _renderAtPicker();
          return;
        }
        return;
      }

      // ── Slash picker mode — consume all keystrokes ──
      if (_slashPickerActive) {
        if (k.name === 'escape' || (k.ctrl && k.name === 'c')) {
          _cancelSlashPicker();
          return;
        }
        if (k.name === 'return' || k.name === 'tab') {
          _acceptSlashPick();
          return;
        }
        if (k.name === 'up') {
          if (_slashSelectedIdx > 0) _slashSelectedIdx--;
          _renderSlashPicker();
          return;
        }
        if (k.name === 'down') {
          if (_slashSelectedIdx < _slashMatches.length - 1) _slashSelectedIdx++;
          _renderSlashPicker();
          return;
        }
        if (k.name === 'backspace') {
          if (_slashFilter.length <= 1) {
            _cancelSlashPicker();
            return;
          }
          _slashFilter = _slashFilter.slice(0, -1);
          _slashSelectedIdx = 0;
          _origTtyWrite(s, key);
          _renderSlashPicker();
          return;
        }
        if (str === ' ') {
          const exact = _slashMatches.find(sc => sc.cmd === _slashFilter);
          if (exact) {
            _clearSlashPicker();
            _slashPickerActive = false;
            _origTtyWrite(s, key);
            return;
          }
          _acceptSlashPick();
          return;
        }
        if (str.length === 1 && str >= ' ') {
          _slashFilter += str;
          _slashSelectedIdx = 0;
          _origTtyWrite(s, key);
          _renderSlashPicker();
          return;
        }
        return;
      }

      // ── Detect '/' on empty line → enter picker mode ──
      if (!_pasteCapturing && !_busy && str === '/' && (rl.line || '') === '') {
        _slashPickerActive = true;
        _slashFilter = '/';
        _slashSelectedIdx = 0;
        _origTtyWrite(s, key);
        _renderSlashPicker();
        return;
      }

      // ── Detect '@' → enter file picker mode ──
      if (!_pasteCapturing && !_busy && !_slashPickerActive && str === '@') {
        _atPickerActive = true;
        _atFilter = '';
        _atSelectedIdx = 0;
        _atCurrentDir = process.env.KHYQUANT_CWD || process.cwd();
        _atAnchorCol = (rl.line || '').length;
        _origTtyWrite(s, key);
        _renderAtPicker();
        return;
      }

      // Low-latency mode keeps slash picker but skips bracketed-paste interception
      // to avoid any extra input-path overhead.
      if (_lowLatencyInputEnabled) {
        _origTtyWrite(s, key);
        return;
      }

      // ── Start marker ──
      if (str.includes('\x1b[200~') || str.includes('[200~')) {
        _pasteCapturing = true;
        _pasteBuf = [];
        _pasteLinePrefix = String(rl.line || '');
        const afterStart = str.split(/\x1b?\[200~/)[1];
        if (afterStart) {
          const endIdx = afterStart.indexOf('\x1b[201~');
          if (endIdx !== -1) {
            // Entire paste in one chunk (small paste)
            _pasteBuf.push(afterStart.slice(0, endIdx));
            _pasteCapturing = false;
            const tail = afterStart.slice(endIdx + 6);
            _finishPasteCapture(_origTtyWrite, /[\r\n]/.test(tail));
            if (tail) _origTtyWrite(tail, key);
            return;
          }
          _pasteBuf.push(afterStart);
        }
        return; // suppress echo
      }

      // ── During capture — accumulate silently ──
      if (_pasteCapturing) {
        const endIdx = str.indexOf('\x1b[201~');
        if (endIdx !== -1) {
          if (endIdx > 0) _pasteBuf.push(str.slice(0, endIdx));
          _pasteCapturing = false;
          const tail = str.slice(endIdx + 6);
          _finishPasteCapture(_origTtyWrite, /[\r\n]/.test(tail));
          if (tail) _origTtyWrite(tail, key);
          return;
        }
        _pasteBuf.push(str);
        return; // suppress echo
      }

      // ── Normal input — pass through ──
      _origTtyWrite(s, key);
    };

    function _finishPasteCapture(writeFn, autoCommittedLine = false) {
      const text = _pasteBuf.join('')
        .replace(/\x1b\[\?2004[hl]/g, '')
        .replace(/\x1b\[(200|201)~/g, '')
        .replace(/\[(200|201)~/g, '')
        .trim();
      _pasteBuf = [];
      if (!text) return;
      // Unified: store as pending paste with tag, user adds context then Enter.
      const prefix = _pasteLinePrefix;
      _pasteLinePrefix = '';
      _storePendingPaste(text, writeFn, prefix, !!autoCommittedLine);
    }
  }

  // ── Vim mode handler ──
  let _vimHandler = null;
  try {
    if (vimSettings().isVimEnabled()) {
      _vimHandler = vimInput().createVimInputHandler(rl, {
        enabled: true,
        prompt: buildCwdPrompt(),
        onModeChange: (mode) => {
          // Status bar will pick up mode from _vimHandler.getMode()
        },
      });
    }
  } catch { /* vim not available — ignore */ }

  function bindInteractiveInputGuard(renderer) {
    if (!renderer || typeof renderer.setInteractiveGuard !== 'function') return;
    renderer.setInteractiveGuard(() => (
      _busy
      && (
        (typeof rl.line === 'string' && rl.line.length > 0)
        || Date.now() < _busyTypingUntil
      )
    ));
  }

  // ── Exit handling ──
  // IMPORTANT: Do NOT add any keypress listener on rl.input / process.stdin.
  // readline internally calls emitKeypressEvents on its input stream.
  // Adding another 'keypress' listener causes every character to echo twice
  // because the keypress event fires for both readline's internal handler
  // and our external handler, each triggering a write to stdout.
  // The SIGINT handler (Ctrl+C double-press to exit) is registered later
  // in this function, after all state variables are initialized.

  // ── Prompt Frame (Claude Code style: upper line + branch badge + lower line) ──
  let _statusBarEnabled = process.stdout.isTTY && (process.stdout.columns || 0) > 28;
  let _currentOp = '';        // Active operation name (shown during AI work)
  let _requestStart = 0;      // Timestamp when current operation started
  let _sessionTokens = 0;     // Running token count for display
  let _queryEngine = null;    // QueryEngine singleton (KHY_QUERY_ENGINE mode)
  let _intentionalExit = false; // Guard: only exit on real user request, not inquirer side-effects
  let _inquirerActive = false;  // Track inquirer stdin usage for Ctrl+D guard
  let _busyTypingUntil = 0;     // Freeze spinner updates briefly while typing/deleting
  const _slashAutoMenuEnabled = !_lowLatencyInputEnabled
    && String(process.env.KHY_SLASH_AUTOMENU || 'true').toLowerCase() !== 'false';
  let _slashAutoMenuOpening = false;
  let _slashAutoMenuCooldownUntil = 0;

  function _isEscOnlyInput(raw) {
    return raw === '\u001b';
  }

  try {
    process.stdin.on('data', (chunk) => {
      if (_busy) _busyTypingUntil = Date.now() + 900;
      const raw = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk || '');

      // Shift+Tab: cycle permission mode (default → auto → bypass)
      if (raw === '\x1b[Z' && !_busy && !_inquirerActive) {
        try {
          const perms = require('../permissions');
          const newMode = perms.cyclePermissionMode();
          // Sync permissionStore profile so _getPermissionModeState picks it up
          try {
            const permStore = require('../services/permissionStore');
            const modeToProfile = { default: 'normal', auto: 'yolo', bypass: 'strict' };
            permStore.setProfile(modeToProfile[newMode] || 'normal');
          } catch { /* ignore */ }
          // Also sync toolCalling dangerousMode
          try {
            const toolCalling = require('../services/toolCalling');
            if (newMode === 'auto' && typeof toolCalling.setDangerousMode === 'function') {
              toolCalling.setDangerousMode(true);
            } else if (newMode !== 'auto' && typeof toolCalling.setDangerousMode === 'function') {
              toolCalling.setDangerousMode(false);
            }
          } catch { /* ignore */ }
          leaveInputPromptFrame();
          rl.prompt();
        } catch { /* ignore */ }
        return;
      }

      if (_busy && !_inquirerActive && _isEscOnlyInput(raw)) {
        const cancelled = _requestRelayCancel('Interrupted by Esc');
        if (cancelled) {
          console.log(c.hex('#FFC107')('\n  Esc 已中断当前 AI 请求，正在返回控制权'));
        } else {
          console.log(c.hex('#FFC107')('\n  Esc 已请求中断，当前步骤完成后返回'));
        }
        try { rl.prompt(); } catch { /* ignore */ }
        return;
      }

      if (!_slashAutoMenuEnabled) return;
      // When the inline picker is active, skip the legacy auto-menu entirely.
      if (_slashPickerActive) return;
      if (_busy || _inquirerActive || _slashAutoMenuOpening) return;
      if ((process.stdin && process.stdin.isTTY) !== true || (process.stdout && process.stdout.isTTY) !== true) return;
      if (typeof rl?.paused === 'boolean' && rl.paused) return;
      if (Date.now() < _slashAutoMenuCooldownUntil) return;
      if (!raw.includes('/')) return;

      if (String(rl.line || '') !== '/') return;
      _slashAutoMenuOpening = true;
      _slashAutoMenuCooldownUntil = Date.now() + 700;
      setTimeout(() => {
        try {
          if (_slashPickerActive) return;
          if (_busy || _inquirerActive) return;
          if (String(rl.line || '') !== '/') return;
          try { rl.write(null, { ctrl: true, name: 'u' }); } catch { rl.line = ''; }
          rl.emit('line', '__KHY_INTERNAL_LINE__ /');
        } finally {
          _slashAutoMenuOpening = false;
        }
      }, 0);
    });
  } catch { /* best effort */ }

  // Wrapper for inquirer.prompt that sets _inquirerActive flag
  async function inqPrompt(questions) {
    _inquirerActive = true;
    try {
      return await inquirer().prompt(questions);
    } finally {
      _inquirerActive = false;
    }
  }

  // ANSI cursor helpers
  // ANSI cursor constants removed — using simple console.log for cross-platform compat

  // Rotating tips
  const TIPS = [
    '/btw 在 AI 工作时插入不打断的提示',
    '/review 自动多轮代码审查',
    '/cost 查看 AI 费用统计',
    '/model 快速切换 AI 模型',
    '/plan 生成执行计划再动手',
    '/hud 展开完整仪表盘',
    'pool list 管理 AI 账号池',
    'image <路径> 图片分析/网页还原',
  ];
  let _tipIdx = 0;
  const _tipTimer = setInterval(() => { _tipIdx = (_tipIdx + 1) % TIPS.length; }, 30000);

  function fitFrameText(text, width) {
    const str = String(text || '');
    const dw = fmt().displayWidth(str);
    if (dw <= width) return str + ' '.repeat(width - dw);
    if (width <= 1) return str.slice(0, width);
    // Truncate by display width using truncateToWidth if available, else fallback
    try {
      return fmt().truncateToWidth(str, width - 1) + '…';
    } catch {
      return str.slice(0, width - 1) + '…';
    }
  }

  function getPromptFrameWidth() {
    const cols = process.stdout.columns || 80;
    return Math.max(26, Math.min(cols - 6, 86));
  }

  function formatToolSummary(summary) {
    if (!summary || typeof summary !== 'object') return '';
    const totalCalls = Number(summary.totalCalls || 0);
    const totalDurationMs = Number(summary.totalDurationMs || 0);
    if (!Number.isFinite(totalCalls) || !Number.isFinite(totalDurationMs)) return '';
    return `${Math.max(0, totalCalls)} tool uses \u00B7 ${Math.max(0, totalDurationMs / 1000).toFixed(1)}s`;
  }

  let _lastAiErrorDetail = '';
  let _lastAiErrorSummary = '';
  let _lastAiErrorFingerprint = '';
  let _lastAiErrorAt = 0;
  let _lastAiErrorRepeat = 0;
  let _mergedErrorHintOpen = false;

  function _isVerboseErrorEnabled() {
    const raw = String(process.env.KHY_ERROR_VERBOSE || 'false').trim().toLowerCase();
    return ['1', 'true', 'on', 'yes'].includes(raw);
  }

  function _getErrorMergeWindowMs() {
    const raw = String(process.env.KHY_ERROR_MERGE_WINDOW_MS || '30000').trim();
    const parsed = Number.parseInt(raw, 10);
    if (!Number.isFinite(parsed)) return 30000;
    return Math.max(3000, Math.min(180000, parsed));
  }

  function _buildAiErrorFingerprint(compacted, text = '') {
    const parts = [];
    const summary = String(compacted?.summary || '').replace(/\s+/g, ' ').trim();
    if (summary) parts.push(summary);
    const failurePreview = Array.isArray(compacted?.failurePreview)
      ? compacted.failurePreview
      : [];
    const suggestionPreview = Array.isArray(compacted?.suggestionPreview)
      ? compacted.suggestionPreview
      : [];
    if (failurePreview.length > 0) parts.push(String(failurePreview[0] || '').replace(/\s+/g, ' ').trim());
    if (suggestionPreview.length > 0) parts.push(String(suggestionPreview[0] || '').replace(/\s+/g, ' ').trim());
    if (parts.length === 0) {
      parts.push(String(text || '').replace(/\s+/g, ' ').trim().slice(0, 200));
    }
    return parts.filter(Boolean).join(' | ').slice(0, 320);
  }

  function _flushMergedErrorHintLine() {
    if (!_mergedErrorHintOpen) return;
    try { process.stdout.write('\n'); } catch { /* ignore */ }
    _mergedErrorHintOpen = false;
  }

  function _renderMergedErrorHintLine(message = '') {
    const text = String(message || '').trim();
    if (!text) return false;
    if (!process.stdout.isTTY) {
      printInfo(text);
      return false;
    }
    const line = c.dim(`  · ${text}`);
    try {
      if (_mergedErrorHintOpen) {
        process.stdout.write(`\r\x1b[K${line}`);
      } else {
        process.stdout.write(line);
        _mergedErrorHintOpen = true;
      }
      return true;
    } catch {
      _mergedErrorHintOpen = false;
      printInfo(text);
      return false;
    }
  }

  function _rememberAiError(raw = '', summary = '') {
    _lastAiErrorDetail = String(raw || '').trim();
    _lastAiErrorSummary = String(summary || '').trim();
  }

  function _printLastAiError() {
    _flushMergedErrorHintLine();
    if (!_lastAiErrorDetail) {
      printInfo('暂无可查看的失败详情');
      return;
    }
    console.log('');
    if (_lastAiErrorSummary) {
      printInfo(`最近失败摘要: ${_lastAiErrorSummary}`);
    }
    console.log(c.dim('  ─────────────────────────────────────────'));
    console.log(_lastAiErrorDetail);
    console.log('');
  }

  function _renderAiErrorCompact(raw = '') {
    const text = String(raw || '').trim();
    if (!text) {
      _flushMergedErrorHintLine();
      printError('AI 请求失败');
      _rememberAiError('AI 请求失败', 'AI 请求失败');
      return { merged: false, inline: false };
    }
    if (_isVerboseErrorEnabled()) {
      _flushMergedErrorHintLine();
      printError(text);
      _rememberAiError(text, text.split(/\r?\n/).find(Boolean) || 'AI 请求失败');
      return { merged: false, inline: false };
    }

    const compacted = compactAiErrorReply(text, {
      maxSummaryLen: 170,
      maxSuggestionLines: 2,
      maxFailurePreview: 1,
    });

    const summary = compacted.summary || 'AI 请求失败';
    const mergeWindowMs = _getErrorMergeWindowMs();
    const now = Date.now();
    const fingerprint = _buildAiErrorFingerprint(compacted, text);
    if (
      fingerprint
      && _lastAiErrorFingerprint
      && fingerprint === _lastAiErrorFingerprint
      && (now - _lastAiErrorAt) <= mergeWindowMs
    ) {
      _lastAiErrorAt = now;
      _lastAiErrorRepeat += 1;
      _rememberAiError(text, summary);
      const inline = _renderMergedErrorHintLine(`同类失败在 ${Math.round(mergeWindowMs / 1000)}s 内已重复 ${_lastAiErrorRepeat} 次，已合并显示；输入 /err 查看完整详情`);
      return { merged: true, inline };
    }
    _flushMergedErrorHintLine();
    _lastAiErrorFingerprint = fingerprint;
    _lastAiErrorAt = now;
    _lastAiErrorRepeat = 1;

    if (compacted.hasStructuredDetails) {
      printErrorPanel({
        title: 'AI Request Failed',
        message: summary,
        reason: compacted.failurePreview[0] || '',
        suggestions: compacted.suggestionItems,
      });
    } else {
      printError(summary);
      if (compacted.suggestionPreview.length > 0) {
        printInfo(`建议下一步: ${compacted.suggestionPreview.join('；')}`);
      }
    }
    const hiddenFailure = Number(compacted.hiddenFailureCount || 0);
    const hiddenSuggest = Number(compacted.hiddenSuggestionCount || 0);
    if (!compacted.hasStructuredDetails && (hiddenFailure > 0 || hiddenSuggest > 0 || text.length > 220)) {
      printInfo('详细失败原因已折叠，输入 /err 查看完整详情（或设置 KHY_ERROR_VERBOSE=1）');
    }
    _rememberAiError(text, summary);
    return { merged: false, inline: false };
  }

  /**
   * Format tool result for ⎿ display line, per tool type.
   * Claude Code shows tool-specific summaries:
   *   Read → "Read N lines"
   *   Bash → command output summary or "Running in the background"
   *   Search/Grep → "Found N files" / "Found N matches"
   *   Write → "Wrote N lines to path"
   *   Edit → "Updated file (N lines changed)"
   */
  function _formatToolResult(toolName, result) {
    if (!result) return 'done';
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    const out = result.output || result.content || '';
    const outStr = typeof out === 'string' ? out : JSON.stringify(out);

    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      if (typeof result.lines === 'number') return `Read ${result.lines} lines`;
      const lineCount = outStr.split('\n').length;
      return `Read ${lineCount} lines`;
    }
    if (name === 'websearch' || name === 'webfetch') {
      if (Array.isArray(result.results)) return `Found ${result.results.length} web results`;
      if (result.data && Array.isArray(result.data.results)) return `Found ${result.data.results.length} web results`;
      if (typeof result.status === 'number') return `Fetched URL (HTTP ${result.status})`;
      return 'Web search completed';
    }
    if (name === 'ls') {
      if (typeof result.count === 'number') return `Listed ${result.count} entries`;
      if (Array.isArray(result.entries)) return `Listed ${result.entries.length} entries`;
      return 'Listed directory';
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      if (result._background) return 'Running in the background (\u2193 to manage)';
      const lines = outStr.trim().split('\n');
      if (lines.length <= 2) return lines.join(' ').slice(0, 80);
      return `${lines.length} lines of output`;
    }
    if (name === 'grep' || name === 'search' || name === 'searchcontent') {
      if (typeof result.count === 'number') return `Found ${result.count} matches`;
      if (Array.isArray(result.matches)) return `Found ${result.matches.length} matches`;
      const matches = outStr.split('\n').filter(Boolean).length;
      return `Found ${matches} results`;
    }
    if (name === 'glob' || name === 'find' || name === 'findfiles') {
      if (typeof result.count === 'number') return `Found ${result.count} files`;
      if (Array.isArray(result.files)) return `Found ${result.files.length} files`;
      const files = outStr.split('\n').filter(Boolean).length;
      return `Found ${files} files`;
    }
    if (name === 'write' || name === 'writefile' || name === 'createfile') {
      if (typeof result.bytes === 'number') {
        const target = result.path ? ` \u2192 ${require('path').basename(result.path)}` : '';
        return `Wrote ${result.bytes} bytes${target}`;
      }
      if (result.path) return `Wrote file: ${require('path').basename(result.path)}`;
      const lineCount = outStr ? outStr.split('\n').length : 0;
      return lineCount > 0 ? `Wrote ${lineCount} lines` : 'File written';
    }
    if (name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
      if (typeof result.editsApplied === 'number') return `Applied ${result.editsApplied} edits`;
      if (typeof result.replacements === 'number') return `Replaced ${result.replacements} occurrences`;
      return 'File updated';
    }
    if (name === 'todowrite') {
      if (typeof result.count === 'number') return `Updated ${result.count} todos`;
      return 'Todo list updated';
    }
    if (name === 'agent' || name === 'task') {
      if (result.message) return String(result.message).slice(0, 90);
      return 'Agent task completed';
    }

    // Generic
    const brief = outStr.replace(/\n/g, ' ').slice(0, 60);
    return brief || 'done';
  }

  function _toolProgressStart(toolName, params = {}) {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    if (name === 'websearch') return { label: '正在搜索', target: params.query || params.q || '' };
    if (name === 'scaffoldfiles') {
      const fileCount = Array.isArray(params.files) ? params.files.length : 0;
      const dirCount = Array.isArray(params.directories) ? params.directories.length : 0;
      return { label: `正在批量创建结构(${dirCount}目录/${fileCount}文件)`, target: params.root || '.' };
    }
    if (name === 'webfetch') return { label: 'Fetching URL', target: params.url || '' };
    if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
      return { label: 'Exploring workspace', target: params.path || params.pattern || '' };
    }
    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      return { label: 'Reading file', target: params.path || params.file_path || '' };
    }
    if (name === 'write' || name === 'writefile' || name === 'createfile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
      return { label: 'Updating file', target: params.file_path || params.filePath || params.path || '' };
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      return { label: 'Running command', target: (params.command || '').slice(0, 80) };
    }
    if (name === 'agent' || name === 'task') {
      return { label: 'Delegating to agent', target: params.role || params.subagent_type || 'general' };
    }
    return null;
  }

  function _toolProgressReason(toolName, params = {}) {
    const name = String(toolName || '').toLowerCase().replace(/[\s_-]/g, '');
    const pathHint = String(params.file_path || params.filePath || params.path || '').trim();
    const patternHint = String(params.pattern || params.query || params.q || '').trim();
    const commandHint = String(params.command || '').trim();
    const baseName = pathHint ? require('path').basename(pathHint) : '';

    // Context-aware reasons — varied phrasing, specific details
    if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
      if (patternHint && pathHint) return `在 ${baseName || pathHint} 中查找 "${patternHint}"`;
      if (patternHint) return `搜索 "${patternHint}" 的位置`;
      if (pathHint) return `查看 ${baseName} 的内容结构`;
      return '';
    }
    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      if (baseName) return `读取 ${baseName}`;
      return '';
    }
    if (name === 'write' || name === 'writefile' || name === 'createfile') {
      if (baseName) return `写入 ${baseName}`;
      return '';
    }
    if (name === 'edit' || name === 'editfile' || name === 'multiedit') {
      if (baseName) return `修改 ${baseName}`;
      return '';
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      if (commandHint) {
        const shortCmd = commandHint.length > 60 ? commandHint.slice(0, 57) + '...' : commandHint;
        return `执行 \`${shortCmd}\``;
      }
      return '';
    }
    if (name === 'websearch' || name === 'webfetch') {
      if (patternHint) return `搜索 "${patternHint}"`;
      return '查询外部信息';
    }
    if (name === 'scaffoldfiles') {
      const root = String(params.root || '.').trim();
      const dirCount = Array.isArray(params.directories) ? params.directories.length : 0;
      const fileCount = Array.isArray(params.files) ? params.files.length : 0;
      const workers = Number(params.writeConcurrency) || 4;
      return `在 ${root} 批量创建 ${dirCount} 个目录和 ${fileCount} 个文件（并行 ${workers} 路）`;
    }
    return '';
  }

  function _toolProgressDone(toolName, success, detail = '') {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    const status = success ? 'success' : 'error';
    if (name === 'websearch') return { status, label: success ? 'Searched' : 'Web search failed', detail };
    if (name === 'webfetch') return { status, label: success ? 'Fetched URL' : 'URL fetch failed', detail };
    if (name === 'scaffoldfiles') return { status, label: success ? 'Scaffolded' : 'Scaffold failed', detail };
    if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
      return { status, label: success ? 'Explored' : 'Explore failed', detail };
    }
    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      return { status, label: success ? 'Read' : 'Read failed', detail };
    }
    if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
      return { status, label: success ? 'Updated' : 'Update failed', detail };
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      return { status, label: success ? 'Ran command' : 'Command failed', detail };
    }
    if (name === 'agent' || name === 'task') {
      return { status, label: success ? 'Agent completed' : 'Agent failed', detail };
    }
    return { status, label: success ? 'Completed' : 'Failed', detail };
  }

  /**
   * Render a simple static context line above the prompt.
   * No ANSI cursor movement — just prints lines that stay in the scrollback.
   * This avoids overlap/corruption issues on Windows and non-standard terminals.
   */
  function renderPromptContext() {
    // Claude Code style: no context line above prompt — clean minimal
  }

  // Wrap rl.prompt to print context before prompt (simple, no ANSI tricks)
  const _origPrompt = rl.prompt.bind(rl);

  // Claude Code style prompt
  // IMPORTANT: keep width-stable prompt text to avoid cursor drift.
  // ANSI color codes in prompt cause readline to miscalculate display width,
  // leading to ghost characters when editing CJK text.
  const { isLegacyWinTerminal: _isLegWin } = require('../tools/platformUtils');
  const _promptChar = _isLegWin() ? '> ' : '❯ ';
  function _getPromptRaw() {
    return _promptChar;
  }
  function _getPlainPrompt() { return _promptChar; }
  const _framedPromptFn = _getPlainPrompt;
  // Claude Code style: input frame enabled by default on TTY.
  // Explicit opt-out: KHY_INPUT_FRAME=false|0|off
  const _inputFrameOpt = String(process.env.KHY_INPUT_FRAME || '').toLowerCase();
  const _inputFrameEnabled = process.stdout.isTTY
    && !(process.platform === 'win32' && _isLegWin())
    && !['false', '0', 'off'].includes(_inputFrameOpt);
  const _minFrameCols = Math.max(24, parseInt(process.env.KHY_INPUT_FRAME_MIN_COLS || '28', 10) || 28);
  const _canRenderPromptFrame = () => {
    const cols = process.stdout.columns || 80;
    return _inputFrameEnabled && cols >= _minFrameCols;
  };

  // ── Claude Code style bottom status bar ──────────────────────────────
  // Shows: [permission mode] [X% until auto-compact]
  //        [git branch right-aligned above prompt]

  function _renderBottomStatusBar() {
    if (!process.stdout.isTTY) return;
    const cols = process.stdout.columns || 80;

    try {
      const hud = require('./hudRenderer');
      hud.refreshGit();

      // 用 hudRenderer 的完整状态栏：左侧活跃工具/状态，右侧模型/tokens/git
      const statusLine = hud.renderStatusBar(cols, {
        planMode: _planMode,
      });
      if (statusLine) {
        console.log(statusLine);
        return;
      }
    } catch { /* fall through to basic */ }

    // Fallback: 基础 git branch
    try {
      const hud = require('./hudRenderer');
      const state = hud.getState();
      if (state.git && state.git.branch) {
        const branchText = ` ${state.git.branch} `;
        const branchLen = branchText.length;
        const pad = Math.max(0, cols - branchLen);
        process.stdout.write(' '.repeat(pad) + c.hex('#FFFFFF').dim(branchText) + '\n');
      }
    } catch { /* best-effort */ }
  }

  function _getPermissionModeState() {
    try {
      const toolCalling = require('../services/toolCalling');
      if (toolCalling && typeof toolCalling.isDangerousMode === 'function' && toolCalling.isDangerousMode()) {
        return { label: 'bypass permissions on', color: '#FF6B80' };
      }
    } catch { /* best effort */ }

    try {
      const permStore = require('../services/permissionStore');
      const profile = typeof permStore.getProfile === 'function'
        ? permStore.getProfile()
        : 'normal';
      if (profile === 'yolo') return { label: 'bypass permissions on', color: '#FF6B80' };
      if (profile === 'strict') return { label: 'ask before all tools on', color: '#FFFFFF' };
      return null;
    } catch {
      return null;
    }
  }

  function _renderPermissionBar() {
    if (!process.stdout.isTTY) return;
    const cols = process.stdout.columns || 80;

    // Left: mode text when non-default; fallback to shortcuts hint (Claude-style).
    const modeState = _getPermissionModeState();
    const permLeft = modeState
      ? c.hex(modeState.color || '#FFFFFF')(modeState.label)
      : c.hex('#FFFFFF').dim('(shift+tab to cycle)');

    // Right: auto-compact progress — based on session accumulated tokens vs context limit
    let compactRight = '';
    try {
      const hud = require('./hudRenderer');
      const state = hud.getState();
      const limit = state.contextWindow.limit || 200000;
      // Use session total tokens as approximate context usage
      const sessionTokens = state.sessionTokens.total || 0;
      if (sessionTokens > 0 && limit > 0) {
        const usedPct = Math.round((sessionTokens / limit) * 100);
        const remaining = Math.max(0, 100 - usedPct);
        compactRight = c.dim(`${remaining}% until auto-compact`);
      }
      // Don't show percentage when no tokens used yet (just started)
    } catch {
      // Don't show on error
    }

    const stripAnsi = (s) => s.replace(/\x1b\[[0-9;]*m/g, '');
    const truncatePlain = (s, n) => {
      const t = String(s || '');
      if (n <= 0) return '';
      if (t.length <= n) return t;
      return n <= 1 ? t.slice(0, n) : (t.slice(0, n - 1) + '…');
    };
    const plainLeft = stripAnsi(permLeft);
    const rightLen = stripAnsi(compactRight).length;
    const leftBudget = Math.max(1, cols - rightLen - 2);
    const safeLeft = plainLeft.length > leftBudget
      ? c.dim(truncatePlain(plainLeft, leftBudget))
      : permLeft;
    const leftLen = stripAnsi(safeLeft).length;
    const pad = Math.max(1, cols - leftLen - rightLen - 1);

    console.log(safeLeft + ' '.repeat(pad) + compactRight);
  }

  function _buildPermissionBarText() {
    if (!process.stdout.isTTY) return '';
    try {
      const cols = process.stdout.columns || 80;
      const stripAnsi = (s) => s.replace(/\x1b\[[0-9;]*m/g, '');
      const truncatePlain = (s, n) => {
        const text = String(s || '');
        if (n <= 0) return '';
        if (text.length <= n) return text;
        return n <= 1 ? text.slice(0, n) : `${text.slice(0, n - 1)}…`;
      };
      const modeState = _getPermissionModeState();
      const permLeft = modeState
        ? c.hex(modeState.color || '#FFFFFF')(modeState.label)
        : c.hex('#FFFFFF').dim('(shift+tab to cycle)');
      let compactRightPlain = '';
      let ctxRightPlain = '';
      try {
        const hud = require('./hudRenderer');
        const state = hud.getState();
        const limit = state.contextWindow.limit || 200000;
        const sessionTokens = state.sessionTokens.total || 0;
        const ctxUsed = state.contextWindow.used || 0;
        if (limit > 0) {
          const ctxPct = Math.max(0, Math.min(100, Math.round((ctxUsed / limit) * 100)));
          ctxRightPlain = `${ctxPct}% ctx`;
        }
        if (sessionTokens > 0 && limit > 0) {
          const usedPct = Math.round((sessionTokens / limit) * 100);
          const remaining = Math.max(0, 100 - usedPct);
          compactRightPlain = `${remaining}% until auto-compact`;
        }
      } catch { /* ignore */ }
      const rightPlainRaw = [ctxRightPlain, compactRightPlain].filter(Boolean).join(' · ');
      const maxRightLen = Math.max(0, cols - 8); // reserve room for left label + gap
      const rightPlain = truncatePlain(rightPlainRaw, maxRightLen);
      const rightText = rightPlain ? c.dim(rightPlain) : '';
      const plainLeft = stripAnsi(permLeft);
      const rightLen = stripAnsi(rightText).length;
      const leftBudget = Math.max(1, cols - rightLen - 2);
      const safeLeft = plainLeft.length > leftBudget
        ? c.dim(plainLeft.slice(0, Math.max(1, leftBudget - 1)) + '…')
        : permLeft;
      const leftLen = stripAnsi(safeLeft).length;
      const pad = Math.max(1, cols - leftLen - rightLen - 1);
      const line = safeLeft + ' '.repeat(pad) + rightText;
      // Final hard clamp: never let footer wrap to next line.
      const plainLine = stripAnsi(line);
      const maxFooterCols = Math.max(1, cols - 1);
      if (plainLine.length > maxFooterCols) {
        return c.dim(truncatePlain(plainLine, maxFooterCols));
      }
      return line;
    } catch {
      return '';
    }
  }

  let _frameRendered = false; // track whether decoration has been rendered
  let _cachedBottomRule = '';  // cached bottom rule for _refreshLine repaint
  let _cachedBottomFooter = ''; // cached footer text for _refreshLine repaint
  // Prompt footer below input is enabled by default.
  // Opt-out: KHY_PROMPT_FOOTER=0
  const _promptFooterEnabled = !['0', 'false', 'off', 'no']
    .includes(String(process.env.KHY_PROMPT_FOOTER || 'true').trim().toLowerCase());
  // Keep one blank line between input and bottom footer by default.
  const _inputFooterGapRows = Math.max(0, parseInt(process.env.KHY_INPUT_FOOTER_GAP_ROWS || '1', 10) || 1);

  // Recalculate how many terminal rows the current prompt+input occupies.
  // Needed so the _refreshLine patch can place bottom decoration correctly.
  function _inputVisualRows() {
    const cols = process.stdout.columns || 80;
    if (cols <= 0) return 1;
    const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
    const lineLen = fmt().displayWidth(rl.line || '');
    return Math.max(1, Math.ceil((promptLen + lineLen) / cols));
  }

  // Update cached decoration on terminal resize
  process.stdout.on('resize', () => {
    if (_frameRendered) {
      const width = process.stdout.columns || 80;
      if (_promptFooterEnabled) {
        _cachedBottomRule = c.hex('#D77757')('─'.repeat(width));
        _cachedBottomFooter = _buildPermissionBarText();
      } else {
        _cachedBottomRule = '';
        _cachedBottomFooter = '';
      }
    }
  });

  // Monkey-patch rl._refreshLine: readline's clearScreenDown() wipes the bottom
  // decoration lines on every keystroke.  Repaint them immediately after.
  // This is the ONLY place bottom decoration is drawn — never pre-printed.
  const _origRefreshLine = rl._refreshLine.bind(rl);
  rl._refreshLine = function () {
    _origRefreshLine();
    if (_promptFooterEnabled && _frameRendered && process.stdout.isTTY && _cachedBottomRule) {
      try {
        // Calculate how many rows below the prompt line start the cursor is.
        // For a single-line input, cursor is on row 0 relative to prompt start.
        // For wrapped input, cursor may be on row 1, 2, etc.
        const cols = process.stdout.columns || 80;
        const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
        const cursorPos = promptLen + fmt().displayWidth((rl.line || '').slice(0, rl.cursor || 0));
        const cursorRow = Math.floor(cursorPos / cols); // 0-based row within input
        const cursorCol = cursorPos % cols;
        const totalRows = _inputVisualRows();
        const rowsBelowCursor = totalRows - cursorRow - 1;
        // Relative repaint (avoid DECSC/DECRC restore issues on some terminals).
        // 1) Move to last input row.
        // 2) Paint gap rows + rule + footer.
        // 3) Move back to original input cursor row/column.
        let out = '';
        if (rowsBelowCursor > 0) out += `\x1b[${rowsBelowCursor}B`;
        for (let i = 0; i < _inputFooterGapRows; i++) {
          out += '\x1b[1B\x1b[2K\x1b[1G';
        }
        out += '\x1b[1B\x1b[2K\x1b[1G' + _cachedBottomRule;
        out += '\x1b[1B\x1b[2K\x1b[1G' + _cachedBottomFooter;

        const rowsReturn = rowsBelowCursor + _inputFooterGapRows + 2;
        if (rowsReturn > 0) out += `\x1b[${rowsReturn}A`;
        out += `\x1b[${cursorCol + 1}G`;

        process.stdout.write(out);
      } catch { /* ignore */ }
    }
  };

  function renderInputPromptFrame(args) {
    const currentPrompt = _getPlainPrompt();
    if (!_canRenderPromptFrame()) {
      rl.setPrompt(currentPrompt);
      _origPrompt(...args);
      return;
    }

    if (!_frameRendered) {
      _frameRendered = true;

      const width = process.stdout.columns || 80;
      const rule = c.hex('#D77757')('─'.repeat(width));

      // Cache for _refreshLine repaint (bottom decoration is ONLY drawn by _refreshLine)
      if (_promptFooterEnabled) {
        _cachedBottomRule = rule;
        _cachedBottomFooter = _buildPermissionBarText();
      } else {
        _cachedBottomRule = '';
        _cachedBottomFooter = '';
      }

      // Reserve terminal rows below cursor so the top rule + prompt + bottom
      // decoration all remain visible.  Without this, if the cursor sits on
      // the last visible terminal row, the '\n' characters push the top rule
      // off-screen before the user ever sees it.
      // Need: 1 (status bar) + 1 (top rule) + 1 (prompt) + gap + 1 (bottom rule) + 1 (footer) = 5+gap
      if (_promptFooterEnabled && process.stdout.isTTY) {
        const reserveRows = 4 + _inputFooterGapRows;
        process.stdout.write('\n'.repeat(reserveRows) + `\x1b[${reserveRows}A`);
      }

      // Print git branch + top rule (these scroll with content — safe)
      try { _renderBottomStatusBar(); } catch { /* ignore */ }
      process.stdout.write(rule + '\n');
    }

    // Set prompt and render — _refreshLine will paint bottom decoration
    rl.setPrompt(currentPrompt);
    _origPrompt(...args);

    // Immediately paint bottom decoration so both borders are visible before
    // the first keystroke (readline's _refreshLine only fires on input).
    if (_promptFooterEnabled && _frameRendered && process.stdout.isTTY && _cachedBottomRule) {
      try {
        const cols = process.stdout.columns || 80;
        const promptLen = (rl._prompt || '> ').replace(/\x1b\[[^m]*m/g, '').length;
        const cursorPos = promptLen + (rl.cursor || 0);
        const cursorRow = Math.floor(cursorPos / cols);
        const cursorCol = cursorPos % cols;
        const totalRows = _inputVisualRows();
        const rowsBelowCursor = totalRows - cursorRow - 1;
        let out = '';
        if (rowsBelowCursor > 0) out += `\x1b[${rowsBelowCursor}B`;
        for (let i = 0; i < _inputFooterGapRows; i++) {
          out += '\x1b[1B\x1b[2K\x1b[1G';
        }
        out += '\x1b[1B\x1b[2K\x1b[1G' + _cachedBottomRule;
        out += '\x1b[1B\x1b[2K\x1b[1G' + _cachedBottomFooter;
        const rowsReturn = rowsBelowCursor + _inputFooterGapRows + 2;
        if (rowsReturn > 0) out += `\x1b[${rowsReturn}A`;
        out += `\x1b[${cursorCol + 1}G`;
        process.stdout.write(out);
      } catch { /* ignore */ }
    }
  }

  function leaveInputPromptFrame() {
    const wasRendered = _frameRendered;
    _frameRendered = false;
    _cachedBottomRule = '';
    _cachedBottomFooter = '';
    if (!wasRendered) return;
    // Clear any residual bottom decoration below current cursor
    try {
      if (process.stdout.isTTY) {
        process.stdout.write('\x1B7');   // save cursor
        // Move past remaining input rows
        const rowsBelow = _inputVisualRows() - 1;
        if (rowsBelow > 0) process.stdout.write(`\x1b[${rowsBelow}B`);
        process.stdout.write('\x1b[1B\x1b[J'); // down 1 + clear to end of screen
        process.stdout.write('\x1B8');   // restore cursor
      }
    } catch { /* ignore */ }
  }

  rl.prompt = (...args) => {
    _setLiveHudTypingMode();
    if (_statusBarEnabled) {
      renderPromptContext();
    }
    renderInputPromptFrame(args);
  };

  // 忙碌 prompt：明确告知用户可以输入 (/s 修正, /i 中断, 直接排队)
  const _busyHintLine = c.dim('  ↳ 可输入: /s <修正> · /i <中断> · 直接输入排队');
  let _busyHintShownAt = 0; // 0 = 尚未显示，非 0 = 已显示过（本轮忙碌只显示一次）

  function showBusyInterjectPrompt() {
    if (!_busy || _busyStreaming) return;
    try {
      _setLiveHudTypingMode();
      // If frame was rendered, clear it first to prevent stale decoration
      if (_frameRendered) {
        _frameRendered = false;
        _cachedBottomRule = '';
        _cachedBottomFooter = '';
      }
      // 确保 stdin 活跃且 readline 在监听，防止输入丢失
      try { process.stdin.resume(); } catch { /* ignore */ }
      try { rl.resume(); } catch { /* ignore */ }
      try {
        if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
          process.stdin.setRawMode(true);
        }
      } catch { /* ignore */ }
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[2K\x1b[1G'); // clear line + cursor to col 1
      }
      // 本轮忙碌只显示一次操作提示
      if (_busyHintShownAt === 0) {
        _busyHintShownAt = Date.now();
        _origConsoleLog(_busyHintLine);
      }
      rl.setPrompt(_getPlainPrompt());
      _origPrompt();
    } catch { /* ignore */ }
  }

  // Keep busy-mode input visible even when many tool/status lines are printed.
  // We repaint with a small throttle to avoid flicker.
  const _busyPromptRepaintMinMs = Math.max(
    80,
    parseInt(process.env.KHY_BUSY_PROMPT_REPAINT_MS || '220', 10) || 220,
  );
  let _busyPromptRepaintAt = 0;
  let _busyPromptRepaintPending = null;
  let _busyPromptKeepalive = null; // 周期定时器，确保 busy 模式下输入框持续可见

  function _startBusyPromptKeepalive() {
    if (_busyPromptKeepalive) return;
    _busyPromptKeepalive = setInterval(() => {
      if (!_busy || _inquirerActive) { _stopBusyPromptKeepalive(); return; }
      if (_slashPickerActive || _atPickerActive || _pasteCapturing || _rawPasteActive) return;
      if (!process.stdout.isTTY || !process.stdin.isTTY) return;
      // 距上次重绘超过 400ms 才重绘（避免和 console.log 触发的重绘重复）
      if (Date.now() - _busyPromptRepaintAt < 400) return;
      _busyPromptRepaintAt = Date.now();
      showBusyInterjectPrompt();
    }, 500);
  }

  function _stopBusyPromptKeepalive() {
    if (_busyPromptKeepalive) {
      clearInterval(_busyPromptKeepalive);
      _busyPromptKeepalive = null;
    }
  }

  function _scheduleBusyPromptRepaint() {
    if (!_busy || _busyStreaming || _inquirerActive) return;
    if (_slashPickerActive || _atPickerActive || _pasteCapturing || _rawPasteActive) return;
    if (!process.stdout.isTTY || !process.stdin.isTTY) return;
    // 始终同步重绘——保证每次 console.log 后输入框可见。
    // spinner._render 被 isRaw 拦截不会画任何东西，
    // 所以 showBusyInterjectPrompt 是唯一的输入框来源。
    const now = Date.now();
    if (_busyPromptRepaintPending) {
      clearTimeout(_busyPromptRepaintPending);
      _busyPromptRepaintPending = null;
    }
    // 最小间隔防闪烁：距上次重绘不足 50ms 时延迟到 50ms
    const elapsed = now - _busyPromptRepaintAt;
    if (elapsed < 50) {
      _busyPromptRepaintPending = setTimeout(() => {
        _busyPromptRepaintPending = null;
        if (!_busy || _inquirerActive) return;
        if (_slashPickerActive || _atPickerActive || _pasteCapturing || _rawPasteActive) return;
        _busyPromptRepaintAt = Date.now();
        showBusyInterjectPrompt();
      }, 50 - elapsed);
      return;
    }
    _busyPromptRepaintAt = now;
    showBusyInterjectPrompt();
  }

  // Patch console.log once for this REPL session: whenever execution logs are
  // printed during busy mode, repaint the interjection input line below them.
  const _origConsoleLog = console.log.bind(console);
  let _consolePatched = false;
  function _installBusyPromptConsolePatch() {
    if (_consolePatched) return;
    console.log = (...args) => {
      _origConsoleLog(...args);
      _scheduleBusyPromptRepaint();
    };
    _consolePatched = true;
  }
  function _uninstallBusyPromptConsolePatch() {
    if (!_consolePatched) return;
    console.log = _origConsoleLog;
    _consolePatched = false;
  }
  _installBusyPromptConsolePatch();

  function showBusySlashMenu() {
    let commands = [];
    try {
      const cmdReg = require('./commandRegistry');
      const byCat = cmdReg.getByCategory();
      for (const items of Object.values(byCat)) {
        for (const sc of items || []) {
          if (sc && sc.cmd && sc.desc) commands.push({ cmd: sc.cmd, desc: sc.desc });
        }
      }
    } catch {
      try {
        const { SLASH_COMMANDS } = router();
        commands = (SLASH_COMMANDS || [])
          .filter(sc => sc && sc.cmd && sc.desc)
          .map(sc => ({ cmd: sc.cmd, desc: sc.desc }));
      } catch { /* ignore */ }
    }
    const preferred = ['/i', '/interrupt', '/model', '/gateway', '/status', '/help'];
    const picked = [];
    for (const key of preferred) {
      const hit = commands.find(c0 => c0.cmd === key);
      if (hit) picked.push(hit);
    }
    if (picked.length === 0) {
      commands.slice(0, 6).forEach(c0 => picked.push(c0));
    }

    console.log(c.dim('  ↳ 忙碌菜单（可继续输入，命令会排队）:'));
    for (const item of picked.slice(0, 6)) {
      console.log(c.dim(`    ${item.cmd.padEnd(12)} ${item.desc}`));
    }
    console.log(c.dim('    /i <内容> 可优先插队并尝试中断当前请求'));
    console.log(c.dim('    /s <内容> 注入方向修正（不中断，下轮生效）'));
  }

  function recoverReadlineInput() {
    // If vim is active, resume vim handler instead of readline
    if (_vimHandler && _vimHandler.getMode()) {
      _vimHandler.resume();
      return;
    }
    try { process.stdin.resume(); } catch { /* ignore */ }
    try { rl.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  }

  // Handle terminal resize
  if (process.stdout.on) {
    process.stdout.on('resize', () => {
      _statusBarEnabled = process.stdout.isTTY && (process.stdout.columns || 0) > 28;
    });
  }

  rl.prompt();

  // Enable bracketed paste mode so the terminal wraps pasted text in
  // \e[200~ ... \e[201~ markers.  Without this, multi-line paste triggers
  // one 'line' event per line and the bracket detection never fires.
  if (process.stdout.isTTY && !_lowLatencyInputEnabled) {
    try { process.stdout.write('\x1b[?2004h'); } catch { /* ignore */ }
    // Disable on exit to avoid leaking mode into the parent shell
    const _disableBracketPaste = () => {
      try { process.stdout.write('\x1b[?2004l'); } catch { /* ignore */ }
    };
    process.on('exit', _disableBracketPaste);
    process.on('SIGINT', _disableBracketPaste);
  }

  // 安全网：确保进程退出时光标始终可见
  process.on('exit', () => {
    if (process.stdout.isTTY) {
      try { process.stdout.write('\x1B[?25h'); } catch { /* ignore */ }
    }
  });

  // Track session start
  userProfile().trackSessionStart();

  // Non-blocking startup tasks (cloudSync, adminService, skillLearning,
  // securityGuard) are now handled by deferredPrefetch() above.

  // /btw hint queue — non-interrupting hints queued while AI is working
  let _btwQueue = [];
  // Queued user inputs submitted while AI is busy.
  let _queuedInputs = [];
  // Steer 队列 — 方向修正消息，注入到当前工具循环的下一轮迭代
  let _steerQueue = [];
  let _lastBusyEnterHintAt = 0;
  const INTERNAL_LINE_PREFIX = '__KHY_INTERNAL_LINE__ ';
  const INPUT_BATCH_WINDOW_MS = Math.max(20, parseInt(process.env.KHY_PASTE_MERGE_MS || '90', 10));
  // When busy, use a longer merge window — pasted lines arrive slower through
  // the readline layer because each line is a separate event.  Without bracketed
  // paste markers, this is the only way to detect paste-during-busy.
  const INPUT_BUSY_BATCH_WINDOW_MS = Math.max(INPUT_BATCH_WINDOW_MS, parseInt(process.env.KHY_BUSY_PASTE_MERGE_MS || '400', 10));
  const _inputBatchModeEnv = String(process.env.KHY_INPUT_BATCH_MODE || 'auto').toLowerCase();
  const INPUT_BATCH_MODE = _lowLatencyInputEnabled ? 'off' : _inputBatchModeEnv; // off | auto | always
  let _inputBatchTimer = null;
  let _inputBatchLines = [];
  let _pendingPaste = null;   // Buffered paste text waiting for user supplement
  let _pendingPasteTag = '';
  let _pendingPasteSkipNextEmptySubmit = false;
  let _pendingPasteHintedAt = 0;
  let _pendingPasteSetAt = 0;  // Timestamp when _pendingPaste was last set — suppresses ghost Enters
  // Archive of all pasted content by _pasteCounter, so queued [Pasted text #N] tags
  // can be expanded even after _pendingPaste is consumed or cleared.
  const _pasteArchive = new Map();
  let _pasteCapturing = false; // True while _ttyWrite is accumulating bracketed paste
  // Burst paste detection state (DeepSeek-TUI style, must be outer scope for _clearTransientInputState)
  let _burstLastCharAt = 0;
  let _burstConsecutive = 0;
  let _burstActive = false;
  let _burstBuf = '';
  let _burstWindowUntil = 0;
  let _burstFlushTimer = null;
  let _lastBusyMergeAt = 0;   // Timestamp for busy-state rapid merge
  const BUSY_QUEUE_MERGE_WINDOW_MS = Math.max(100, parseInt(process.env.KHY_BUSY_QUEUE_MERGE_MS || '150', 10));
  let _busyQueueMergeTimer = null; // Timer for deferred busy-queue flush
  let _busyQueueAccum = [];        // Lines accumulating before flush
  const PASTE_TAG_RE = /\[Pasted text #\d+(?:\s\+\d+ lines)?\]\s*/g;
  const PASTE_TAG_WITH_ID_RE = /\[Pasted text #(\d+)(?:\s\+\d+ lines)?\]/g;
  const PASTED_CONTENT_BLOCK_RE = /<pasted-content>\n([\s\S]*?)\n<\/pasted-content>/;

  /**
   * Expand any residual [Pasted text #N ...] tags in text by looking up _pasteArchive.
   * Returns the text with tags replaced by actual pasted content wrapped in <pasted-content>.
   */
  function _expandPasteTags(text) {
    if (!text || !_pasteArchive.size) return text;
    return text.replace(PASTE_TAG_WITH_ID_RE, (_m, idStr) => {
      const id = Number(idStr);
      const archived = _pasteArchive.get(id);
      if (archived) {
        return `<pasted-content>\n${archived}\n</pasted-content>`;
      }
      return _m; // No archived content found, leave as-is
    });
  }
  const _featureCapabilityMap = new FeatureCapabilityMap();
  let _taskMindMap = createIdleTaskMindMap(); // Dual maps are always available: AI navigation + user-visible map
  const _taskMindMapAutoShowEnv = String(process.env.KHY_TASK_MINDMAP_AUTO_SHOW || 'false').trim().toLowerCase();
  let _taskMindMapAutoShow = ['1', 'true', 'yes', 'on'].includes(_taskMindMapAutoShowEnv);

  function _resetCognitionMapsToStartNode() {
    _featureCapabilityMap.reset();
    _taskMindMap = createIdleTaskMindMap();
  }

  function _initTaskMindMap(inputTitle = '', finalInput = '') {
    try {
      const inferredSteps = extractPlanStepsFromText(finalInput || inputTitle, 8);
      _taskMindMap = createTaskMindMap({
        title: inputTitle,
        userInput: finalInput,
        steps: inferredSteps,
      });
    } catch {
      _taskMindMap = createTaskMindMap({ title: inputTitle || finalInput, userInput: finalInput });
    }
    return _taskMindMap;
  }

  function _renderTaskMindMap(reason = 'status') {
    const renderedAny = _renderCognitionMaps(reason);
    if (!renderedAny) printInfo('认知双图不可用');
    return renderedAny;
  }

  function _renderFeatureCapabilityMap() {
    const c = chalk();
    const lines = _featureCapabilityMap.renderLines();
    lines.forEach((line) => {
      const text = String(line || '');
      if (/^Current Feature:/i.test(text)) {
        console.log(`    ${c.blue(text)}`);
        return;
      }
      if (/^Executable:/i.test(text)) {
        const state = text.split(':').slice(1).join(':').trim().toLowerCase();
        if (state === 'completed') {
          console.log(`    ${c.green(text)}`);
          return;
        }
        if (state === 'blocked') {
          console.log(`    ${c.red(text)}`);
          return;
        }
        if (state === 'running' || state === 'ready' || state === 'delegated') {
          console.log(`    ${c.blue(text)}`);
          return;
        }
      }
      if (/^Reason:/i.test(text) && /error|failed|blocked/i.test(text)) {
        console.log(`    ${c.red(text)}`);
        return;
      }
      console.log(`    ${text}`);
    });
  }

  function _renderTaskMindMapWithColors() {
    const c = chalk();
    const lines = _taskMindMap ? _taskMindMap.renderLines() : [];
    lines.forEach((line) => {
      const text = String(line || '');
      if (/\[\>\]/.test(text) || /^Current:\s+(?!none\b)/i.test(text)) {
        console.log(`    ${c.blue(text)}`);
        return;
      }
      if (/\[x\]/.test(text)) {
        console.log(`    ${c.green(text)}`);
        return;
      }
      if (/\[\!\]/.test(text)) {
        console.log(`    ${c.red(text)}`);
        return;
      }
      console.log(`    ${text}`);
    });
  }

  function _renderCognitionMaps(reason = 'status') {
    const hasTaskMap = !!_taskMindMap;
    const hasFeatureMap = !!_featureCapabilityMap;
    if (!hasTaskMap && !hasFeatureMap) return false;

    console.log('');
    console.log(c.bold(`  认知双图 (${reason})`));
    console.log(c.dim('    AI 视角: 导航（能力图 + 任务图） | 用户视角: 地图（可随时查看）'));
    if (hasFeatureMap) {
      _renderFeatureCapabilityMap();
    }
    if (hasTaskMap) {
      _renderTaskMindMapWithColors();
    }
    console.log(c.dim('    提示: /mind show | /mind on | /mind off | /mind reset'));
    console.log('');
    return true;
  }

  function _printTaskMindMapCompact(prefix = 'Task state') {
    if (!_taskMindMap) return;
    try {
      const compact = _taskMindMap.getCompactStatus();
      console.log(c.dim(`  · ${prefix}: ${compact}`));
    } catch { /* best effort */ }
  }

  function _printFeatureCapabilityCompact(prefix = 'Feature state') {
    try {
      const compact = _featureCapabilityMap.getCompactStatus();
      console.log(c.dim(`  · ${prefix}: ${compact}`));
    } catch { /* best effort */ }
  }

  function _buildTaskMindMapSteerMessage() {
    if (!_taskMindMap) return '';
    try {
      return _taskMindMap.buildAiSteerMessage();
    } catch {
      return '';
    }
  }

  function _buildFeatureCapabilitySteerMessage() {
    try {
      return _featureCapabilityMap.buildAiSteerMessage();
    } catch {
      return '';
    }
  }

  /**
   * Queue input during busy mode with paste merge.
   * Lines arriving within BUSY_QUEUE_MERGE_WINDOW_MS of each other are merged
   * into a single <pasted-content> block instead of creating separate queue
   * entries.  This handles terminals without bracketed paste support (e.g. SSH)
   * where pasted lines arrive as individual readline events spaced >400ms apart.
   */
  function _busyQueueWithMerge(text) {
    _busyQueueAccum.push(text);
    _lastBusyMergeAt = Date.now();
    if (_busyQueueMergeTimer) clearTimeout(_busyQueueMergeTimer);
    _busyQueueMergeTimer = setTimeout(() => {
      _busyQueueMergeTimer = null;
      const lines = _busyQueueAccum;
      _busyQueueAccum = [];
      if (lines.length === 0) return;
      if (lines.length === 1) {
        // Single typed line — queue as-is (genuine single-line input during busy)
        _queuedInputs.push(lines[0]);
        const queuePreview = _summarizeQueuedInputForDisplay(lines[0], 40);
        console.log(c.dim(`  ${DOT_PENDING} 已排队: "${queuePreview}" (队列: ${_queuedInputs.length})`));
        console.log(c.dim(`    ${TREE_LAST} AI 完成当前工作后自动处理，/i <内容> 可优先处理，Ctrl+C 可中断`));
        showBusyInterjectPrompt();
      } else {
        // Multiple lines merged — detected as paste.
        // Do NOT auto-queue. Instead, inject into readline as editable tag
        // so the user can add context before pressing Enter.
        const unwrapped = lines.map(l => {
          const m = PASTED_CONTENT_BLOCK_RE.exec(l);
          return m ? m[1] : l;
        });
        const merged = unwrapped.join('\n').trim();
        _storePendingPaste(merged, null, '', false);
      }
    }, BUSY_QUEUE_MERGE_WINDOW_MS);
    // Show immediate feedback for first line
    if (_busyQueueAccum.length === 1) {
      console.log(c.dim(`  ${DOT_PENDING} 输入接收中...（等待更多行以合并粘贴）`));
    }
  }

  function _summarizeQueuedInputForDisplay(raw, maxLen = 48) {
    const text = String(raw || '');
    const pastedMatch = PASTED_CONTENT_BLOCK_RE.exec(text);
    if (pastedMatch) {
      const pastedBody = String(pastedMatch[1] || '');
      const lineCount = pastedBody ? pastedBody.split('\n').length : 0;
      const supplement = text.replace(PASTED_CONTENT_BLOCK_RE, '').trim().replace(/\s+/g, ' ');
      const suffix = supplement
        ? ` · ${supplement.slice(0, maxLen)}${supplement.length > maxLen ? '...' : ''}`
        : '';
      return `[Pasted text +${lineCount} lines]${suffix}`;
    }
    const compact = text.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
    if (compact.length <= maxLen) return compact;
    return `${compact.slice(0, maxLen)}...`;
  }

  // ── 忙碌输入 3 模式自动分类 (Hermes-style) ────────────────────────

  /**
   * 自动分类忙碌期间的用户输入为 interrupt/steer/queue。
   * @param {string} text — 用户原始输入
   * @returns {{ mode: 'interrupt'|'steer'|'queue', text: string }}
   */
  function _classifyBusyInput(text) {
    const trimmed = String(text || '').trim();
    if (!trimmed) return { mode: 'queue', text: trimmed };

    // 显式 /steer 或 /s 前缀
    const steerPrefixMatch = /^\/(?:steer|s)\s+([\s\S]+)$/i.exec(trimmed);
    if (steerPrefixMatch) return { mode: 'steer', text: steerPrefixMatch[1].trim() };

    // 显式中断关键词（完整匹配）
    if (/^(?:停[下止]?|取消|中断|abort|stop|cancel)\s*[!！.。]?\s*$/i.test(trimmed)) {
      return { mode: 'interrupt', text: trimmed };
    }

    // 长输入 > 300 字 → 新话题，排队
    if (trimmed.length > 300) return { mode: 'queue', text: trimmed };

    // Steer 语义检测
    const steerPatterns = [
      /别[用做写]/, /不要[用做那这写]/, /改[成用为]/, /换[个成一]个?(?:思路|方[法案式]|方向)?/,
      /加上/, /还[要需]/, /而且/, /但[是要]/, /另外/, /同时也/, /不如/,
      /顺便/, /(?:也|还)(?:把|将|得)/, /改改/, /调整[一下]*(?:方向|思路|方案)?/,
      /不是.*(?:而是|是)/, /(?:等等|等一下).*(?:先|别)/,
      /\b(?:don'?t|do not) (?:use|do|write|try)/i,
      /\b(?:instead|actually|wait|hold on|oh wait)/i,
      /\b(?:switch to|change to|try .* instead)/i,
      /\b(?:also |but |skip |ignore )\b/i,
      /\bnot that\b/i,
    ];
    for (const pat of steerPatterns) {
      if (pat.test(trimmed)) return { mode: 'steer', text: trimmed };
    }

    return { mode: 'queue', text: trimmed };
  }

  // ── Bracketed paste detection ──
  const BRACKETED_PASTE_START = ['\u001b[200~', '[200~', '00~'];
  const BRACKETED_PASTE_END = ['\u001b[201~', '[201~', '01~'];
  const _pasteCapture = { active: false, lines: [] };

  function _findFirstMarker(text, markers) {
    let best = null;
    for (const marker of markers) {
      const idx = text.indexOf(marker);
      if (idx === -1) continue;
      if (!best || idx < best.idx) best = { idx, marker };
    }
    return best;
  }

  function _stripBracketArtifacts(text) {
    return String(text || '')
      .replace(/\u001b\[\?2004[hl]/g, '')
      .replace(/\u001b\[(200|201)~/g, '')
      .replace(/\[(200|201)~/g, '')
      .replace(/^00~/, '')
      .replace(/01~$/, '');
  }

  function _consumeBracketedPaste(rawLine) {
    const line = _stripBracketArtifacts(String(rawLine || ''));
    if (!_pasteCapture.active) {
      const start = _findFirstMarker(line, BRACKETED_PASTE_START);
      if (!start || start.idx > 2) {
        return { state: 'normal', text: line };
      }
      const withoutStart = line.slice(0, start.idx) + line.slice(start.idx + start.marker.length);
      const inlineEnd = _findFirstMarker(withoutStart, BRACKETED_PASTE_END);
      if (inlineEnd) {
        const completed = (withoutStart.slice(0, inlineEnd.idx) + withoutStart.slice(inlineEnd.idx + inlineEnd.marker.length)).trim();
        return { state: 'completed', text: completed };
      }
      _pasteCapture.active = true;
      _pasteCapture.lines = [];
      if (withoutStart) _pasteCapture.lines.push(withoutStart);
      return { state: 'capturing', text: '' };
    }

    const end = _findFirstMarker(line, BRACKETED_PASTE_END);
    if (end) {
      const chunk = line.slice(0, end.idx) + line.slice(end.idx + end.marker.length);
      if (chunk) _pasteCapture.lines.push(chunk);
      const completed = _pasteCapture.lines.join('\n').trim();
      _pasteCapture.active = false;
      _pasteCapture.lines = [];
      return { state: 'completed', text: completed };
    }

    _pasteCapture.lines.push(line);
    return { state: 'capturing', text: '' };
  }

  let _pasteCounter = 0; // Running paste ID for display
  const SHORT_PASTE_LINE_THRESHOLD = 5; // ≤ this many lines → show content directly

  function _injectPasteIntoLine(text, rlRef) {
    _pasteCounter++;
    const lineCount = text.split('\n').length;
    // Claude Code style: [Pasted text #N +M lines] inline in the prompt
    const tag = lineCount > 1
      ? `[Pasted text #${_pasteCounter} +${lineCount} lines]`
      : `[Pasted text #${_pasteCounter}]`;
    // Write the tag into readline's line buffer so user can keep typing after it
    try { rlRef.write(tag); } catch { /* ignore */ }
    return tag;
  }

  /**
   * Store pasted text as _pendingPaste and inject a tag into the prompt.
   * Works the same whether busy or not — user can add context then press Enter.
   *
   * Short pastes (≤ SHORT_PASTE_LINE_THRESHOLD lines): show actual content in
   * readline so user can edit it directly.
   * Long pastes: fold into [Pasted text #N +M lines] tag.
   *
   * @param {string} text - The pasted content
   * @param {Function} writeFn - The _origTtyWrite function (or rl.write fallback)
   * @param {string} [prefix] - Text the user had typed before pasting
   * @param {boolean} [autoCommittedLine] - Whether a trailing newline triggered a line event
   */
  function _storePendingPaste(text, writeFn, prefix, autoCommittedLine) {
    const lineCount = text.split('\n').length;
    const isShort = lineCount <= SHORT_PASTE_LINE_THRESHOLD && text.length <= 500;

    if (isShort) {
      // Short paste — show content directly in readline for inline editing
      _pendingPaste = null; // No need for pending — content is visible
      _pendingPasteTag = '';
      _pendingPasteSkipNextEmptySubmit = false;
      _pendingPasteHintedAt = 0;
      try { rl.write(null, { ctrl: true, name: 'u' }); } catch { rl.line = ''; rl.cursor = 0; }
      if (prefix) {
        try { (writeFn || rl.write.bind(rl))(prefix, undefined); } catch { /* ignore */ }
      }
      // Write the actual paste content into readline
      const singleLine = text.replace(/\n/g, '  ');
      try { (writeFn || rl.write.bind(rl))(singleLine, undefined); } catch { /* ignore */ }
      return;
    }

    // Long paste — fold into tag (Claude Code style)
    _pendingPaste = text;
    _pendingPasteSkipNextEmptySubmit = !!autoCommittedLine;
    _pendingPasteHintedAt = 0;
    _pendingPasteSetAt = Date.now();
    _pasteCounter++;
    _pasteArchive.set(_pasteCounter, text); // Archive for later expansion
    // Prevent unbounded growth: keep only last 20 entries
    if (_pasteArchive.size > 20) {
      const oldest = _pasteArchive.keys().next().value;
      _pasteArchive.delete(oldest);
    }
    const tag = lineCount > 1
      ? `[Pasted text #${_pasteCounter} +${lineCount} lines]`
      : `[Pasted text #${_pasteCounter}]`;
    _pendingPasteTag = tag;
    try { rl.write(null, { ctrl: true, name: 'u' }); } catch { rl.line = ''; rl.cursor = 0; }
    if (prefix) {
      try { (writeFn || rl.write.bind(rl))(prefix, undefined); } catch { /* ignore */ }
    }
    try { (writeFn || rl.write.bind(rl))(tag, undefined); } catch { /* ignore */ }
    if (_busy) {
      // Show hint so user knows they can add context
      console.log(c.dim(`  ↳ 已折叠粘贴 ${lineCount} 行，输入提示词后回车发送（将排队等待处理）`));
    }
  }

  function _shouldBatchInputLine(lineText = '') {
    if (INPUT_BATCH_MODE === 'always') return true;
    if (INPUT_BATCH_MODE === 'off') return false;
    // Always batch: the 90ms (idle) / 400ms (busy) window lets us detect
    // multi-line paste before the first line gets executed.  Single lines
    // that don't receive a follow-up within the window are re-emitted as
    // normal input — the only cost is a barely perceptible 90ms delay.
    return true;
  }

  function _scheduleInputBatch(lineText, rlRef) {
    _inputBatchLines.push(String(lineText || ''));
    if (_inputBatchTimer) clearTimeout(_inputBatchTimer);
    const batchWindowMs = _busy ? INPUT_BUSY_BATCH_WINDOW_MS : INPUT_BATCH_WINDOW_MS;
    _inputBatchTimer = setTimeout(() => {
      const merged = _inputBatchLines.join('\n').trim();
      const batchCount = _inputBatchLines.length;
      _inputBatchLines = [];
      _inputBatchTimer = null;
      if (!merged) {
        try { rlRef.prompt(); } catch { /* ignore */ }
        return;
      }
      // Single short line — pass through directly (busy: queue, not busy: emit)
      if (batchCount === 1 && merged.length < 180) {
        if (_busy) {
          _busyQueueWithMerge(merged);
        } else {
          const savedOutput = rlRef.output;
          try {
            rlRef.output = null;
            rlRef.emit('line', `${INTERNAL_LINE_PREFIX}${merged}`);
          } finally {
            rlRef.output = savedOutput;
          }
        }
        return;
      }
      // Multi-line or long content — detected as paste.
      // Use _storePendingPaste: inject tag, let user add context, Enter to send.
      _storePendingPaste(merged, null, '', false);
    }, batchWindowMs);
  }

  function _clearTransientInputState(rlRef) {
    if (_inputBatchTimer) {
      clearTimeout(_inputBatchTimer);
      _inputBatchTimer = null;
    }
    _inputBatchLines = [];
    if (_busyQueueMergeTimer) {
      clearTimeout(_busyQueueMergeTimer);
      _busyQueueMergeTimer = null;
    }
    _busyQueueAccum = [];
    // Clear raw paste detection state
    _rawPasteActive = false;
    _rawPasteBuf = [];
    if (_rawPasteTimer) { clearTimeout(_rawPasteTimer); _rawPasteTimer = null; }
    // Clear burst paste detection state
    _burstActive = false;
    _burstBuf = '';
    _burstConsecutive = 0;
    _burstLastCharAt = 0;
    _burstWindowUntil = 0;
    if (_burstFlushTimer) { clearTimeout(_burstFlushTimer); _burstFlushTimer = null; }
    _pendingPaste = null;
    _pendingPasteTag = '';
    _pendingPasteSkipNextEmptySubmit = false;
    _pendingPasteHintedAt = 0;
    _pendingPasteSetAt = 0;
    _pasteCapturing = false;
    _pasteCapture.active = false;
    _pasteCapture.lines = [];
    _busyTypingUntil = 0;
    try { rlRef.write(null, { ctrl: true, name: 'u' }); } catch { rlRef.line = ''; }
  }

  function _requestRelayCancel(reason = 'Interrupted by user input') {
    let cancelled = false;
    try {
      const aiMod = ai();
      if (aiMod && typeof aiMod.cancelActiveRequest === 'function') {
        cancelled = !!aiMod.cancelActiveRequest(reason) || cancelled;
      }
    } catch { /* non-critical */ }
    try {
      const gateway = require('../services/gateway/aiGateway');
      const relay = gateway.getRelayAdapter();
      if (relay && typeof relay.cancelPending === 'function') {
        cancelled = !!relay.cancelPending(reason) || cancelled;
      }
    } catch { /* non-critical */ }
    return cancelled;
  }

  const _TASK_GROUP_BY_STATUS = Object.freeze({
    queued: 'pending',
    claimed: 'running',
    running: 'running',
    retry_wait: 'running',
    pausing: 'running',
    paused: 'paused',
    cancelling: 'running',
    succeeded: 'completed',
    failed: 'failed',
    cancelled: 'failed',
    dead_letter: 'failed',
  });
  const _TASK_STATUS_LABELS = Object.freeze({
    queued: '待执行',
    claimed: '已认领',
    running: '执行中',
    retry_wait: '重试等待',
    pausing: '暂停中',
    paused: '已暂停',
    cancelling: '取消中',
    succeeded: '已完成',
    failed: '失败',
    cancelled: '已取消',
    dead_letter: '死信',
  });
  const _TASK_FILTER_ALIASES = Object.freeze({
    all: 'all',
    '*': 'all',
    pending: 'pending',
    queued: 'pending',
    waiting: 'pending',
    running: 'running',
    active: 'running',
    in_progress: 'running',
    paused: 'paused',
    completed: 'completed',
    done: 'completed',
    success: 'completed',
    succeeded: 'completed',
    failed: 'failed',
    error: 'failed',
    cancelled: 'failed',
    canceled: 'failed',
    dead_letter: 'failed',
  });
  const _TASK_ACTION_ALIASES = Object.freeze({
    cancel: 'cancel',
    stop: 'cancel',
    kill: 'cancel',
    pause: 'pause',
    resume: 'resume',
    取消: 'cancel',
    暂停: 'pause',
    恢复: 'resume',
  });

  function _normalizeTaskToken(value = '') {
    return String(value || '').trim().toLowerCase();
  }

  function _taskStatusLabel(status = '') {
    const key = String(status || '').trim();
    return _TASK_STATUS_LABELS[key] || key || '未知';
  }

  function _taskGroup(status = '') {
    const key = String(status || '').trim();
    return _TASK_GROUP_BY_STATUS[key] || 'pending';
  }

  function _parseIsoTime(value) {
    const ts = Date.parse(String(value || ''));
    return Number.isFinite(ts) ? ts : 0;
  }

  function _sortTasksByUpdatedDesc(tasks = []) {
    return [...tasks].sort((a, b) => _parseIsoTime(b?.updated_at) - _parseIsoTime(a?.updated_at));
  }

  function _toShortTime(value) {
    const ts = _parseIsoTime(value);
    if (!ts) return '-';
    try {
      return new Date(ts).toLocaleString('zh-CN', { hour12: false });
    } catch {
      return String(value || '-');
    }
  }

  function _truncateText(value, max = 36) {
    const text = String(value || '').trim();
    if (!text) return '-';
    if (text.length <= max) return text;
    return `${text.slice(0, Math.max(0, max - 1))}…`;
  }

  function _taskSummaryText(task) {
    const payload = task?.payload_json || {};
    return _truncateText(
      payload.description
      || payload.label
      || payload.subject
      || payload.type
      || task?.type
      || '',
      42
    );
  }

  function _taskProgressText(task) {
    const pct = Number(task?.progress_pct);
    return Number.isFinite(pct) ? `${Math.round(pct)}%` : '-';
  }

  function _taskAttemptText(task) {
    const current = Number.isFinite(Number(task?.attempt_count)) ? Number(task.attempt_count) : 0;
    const max = Number.isFinite(Number(task?.max_attempts)) ? Number(task.max_attempts) : '-';
    return `${current}/${max}`;
  }

  function _printTasksUsage() {
    const lines = [
      '  /tasks 用法:',
      '    /tasks',
      '    /tasks all|pending|running|paused|completed|failed [limit]',
      '    /tasks <taskId>',
      '    /tasks cancel <taskId> [reason]',
      '    /tasks pause <taskId>',
      '    /tasks resume <taskId>',
    ];
    console.log('');
    lines.forEach((lineText) => console.log(lineText));
    console.log('');
  }

  function _printTaskList(runtimeTasks, listTitle, limit) {
    const tableRows = runtimeTasks.slice(0, limit).map((task) => [
      task.id,
      `${_taskStatusLabel(task.status)} (${task.status})`,
      _truncateText(task.type || '-', 18),
      _taskProgressText(task),
      _taskAttemptText(task),
      _toShortTime(task.updated_at),
      _taskSummaryText(task),
    ]);

    console.log('');
    console.log(c.bold(`  ${listTitle}（显示 ${tableRows.length}/${runtimeTasks.length}）`));
    fmt().printTable(['Task ID', '状态', '类型', '进度', '重试', '最近更新', '摘要'], tableRows);
    console.log('');
  }

  function _printTaskDetail(task, audit) {
    const payload = task?.payload_json || {};
    const attempts = Array.isArray(audit?.attempts) ? audit.attempts : [];
    const events = Array.isArray(audit?.events) ? audit.events : [];

    console.log('');
    console.log(c.bold(`  任务详情: ${task.id}`));
    console.log(`    状态: ${_taskStatusLabel(task.status)} (${task.status})`);
    console.log(`    类型: ${task.type || '-'}`);
    console.log(`    来源: ${payload.source || '-'}`);
    console.log(`    进度: ${_taskProgressText(task)}`);
    console.log(`    重试: ${_taskAttemptText(task)}`);
    console.log(`    创建: ${_toShortTime(task.created_at)}`);
    console.log(`    更新: ${_toShortTime(task.updated_at)}`);
    if (task.completed_at) console.log(`    完成: ${_toShortTime(task.completed_at)}`);
    if (task.next_run_at) console.log(`    下次运行: ${_toShortTime(task.next_run_at)}`);
    if (task.trace_id) console.log(`    Trace: ${task.trace_id}`);
    if (payload.description || payload.label || payload.subject) {
      console.log(`    摘要: ${payload.description || payload.label || payload.subject}`);
    }

    if (task.last_error) {
      const err = task.last_error;
      const statusCode = err.status_code !== undefined && err.status_code !== null ? ` status=${err.status_code}` : '';
      const retryable = typeof err.retryable === 'boolean' ? ` retryable=${err.retryable}` : '';
      console.log(`    最近错误: ${err.type || 'error'}${statusCode}${retryable}`);
      if (err.message) console.log(`      ${err.message}`);
    }

    if (task.last_result !== undefined && task.last_result !== null) {
      let resultText = '';
      try {
        resultText = typeof task.last_result === 'string'
          ? task.last_result
          : JSON.stringify(task.last_result);
      } catch {
        resultText = String(task.last_result);
      }
      console.log(`    最近结果: ${_truncateText(resultText, 180)}`);
    }

    if (attempts.length > 0) {
      const attemptRows = attempts.slice(-5).reverse().map((item) => [
        String(item.attempt_no ?? '-'),
        String(item.result_status || '-'),
        String(item.error_type || '-'),
        item.retry_delay_ms ? `${item.retry_delay_ms}ms` : '-',
        _toShortTime(item.ended_at || item.started_at),
      ]);
      fmt().printTable(['尝试', '结果', '错误类型', '延迟', '时间'], attemptRows);
    }

    if (events.length > 0) {
      const eventRows = events.slice(-6).reverse().map((event) => [
        String(event.event_id ?? '-'),
        `${event.state_from || '-'} -> ${event.state_to || '-'}`,
        String(event.attempt_no ?? '-'),
        _toShortTime(event.at),
      ]);
      fmt().printTable(['事件', '状态变化', '尝试', '时间'], eventRows);
    }
    console.log('');
  }

  function _parseLimitToken(tokens, index, fallback) {
    const raw = String(tokens[index] || '').trim();
    if (!raw) return fallback;
    const parsed = Number.parseInt(raw, 10);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.max(1, Math.min(100, parsed));
  }

  async function _handleTasksCommand(rawArgs = '') {
    const taskControlService = require('../services/taskControlService');
    const { runTasksControlContract } = require('./tasksControlContract');
    const argsText = String(rawArgs || '').trim();
    const tokens = argsText ? argsText.split(/\s+/).filter(Boolean) : [];
    const primary = _normalizeTaskToken(tokens[0] || '');

    if (primary === '?' || primary === 'help' || primary === 'h' || primary === '帮助') {
      _printTasksUsage();
      return;
    }

    const control = runTasksControlContract(argsText, {
      taskControlService,
      actionAliases: _TASK_ACTION_ALIASES,
      taskStatusLabel: _taskStatusLabel,
      defaultCancelReason: 'Cancelled by /tasks command',
    });
    if (control.handled) {
      for (const event of control.events) {
        if (event.level === 'success') printSuccess(event.text);
        else if (event.level === 'info') printInfo(event.text);
        else printError(event.text);
      }
      return;
    }

    const filter = primary ? _TASK_FILTER_ALIASES[primary] || null : 'all';
    if (filter) {
      const allTasks = _sortTasksByUpdatedDesc(taskControlService.listTasks());
      const summary = { total: allTasks.length, pending: 0, running: 0, paused: 0, completed: 0, failed: 0 };
      for (const item of allTasks) {
        const group = _taskGroup(item.status);
        summary[group] = (summary[group] || 0) + 1;
      }

      const filtered = filter === 'all'
        ? allTasks
        : allTasks.filter((item) => _taskGroup(item.status) === filter);
      const limit = _parseLimitToken(tokens, 1, filter === 'all' ? 12 : 20);
      printInfo(
        `任务概览 total=${summary.total} pending=${summary.pending} running=${summary.running} paused=${summary.paused} completed=${summary.completed} failed=${summary.failed}`
      );
      if (filtered.length === 0) {
        printInfo(`没有匹配任务（过滤器: ${filter}）`);
        return;
      }
      _printTaskList(filtered, `任务列表 /tasks ${filter}`, limit);
      if (tokens.length === 0) {
        printInfo('提示: /tasks <taskId> 查看详情，/tasks help 查看完整用法');
      }
      return;
    }

    const taskId = String(tokens[0] || '').trim();
    if (!taskId) {
      _printTasksUsage();
      return;
    }
    const detail = taskControlService.getTaskDetail(taskId, { includeAudit: true });
    if (!detail.ok) {
      printError(`任务不存在: ${taskId}`);
      printInfo('提示: 运行 /tasks 查看可用任务列表');
      return;
    }
    _printTaskDetail(detail.task, detail.audit);
  }

  rl.on('line', async (line) => {
    _setLiveHudWorkingMode();
    // Clean up slash picker if still rendered (safety net)
    if (_slashPickerActive || _slashRenderedLines > 0) {
      _clearSlashPicker();
      _slashPickerActive = false;
    }
    // Clean up @ file picker if still rendered (safety net)
    if (_atPickerActive || _atRenderedLines > 0) {
      _clearAtPicker();
      _atPickerActive = false;
    }
    // When input frame is active the cursor sits inside a 3-line decoration
    // (top rule → prompt → bottom rule + footer).  readline's built-in echo
    // prints the entered text at the prompt line and then moves the cursor
    // down into the decoration area.  If we only clearLine at the current
    // position, the original echo remains visible above → duplicate input.
    //
    // Fix: when the frame was rendered, move cursor to the prompt line first,
    // wipe everything from there downward (kills both the echo ghost AND the
    // decoration remnants), then reprint a clean "> {input}" line.
    const isInternalLine = typeof line === 'string' && line.startsWith(INTERNAL_LINE_PREFIX);
    const lineBody = isInternalLine ? line.slice(INTERNAL_LINE_PREFIX.length) : line;
    const shouldEchoInternalLine = isInternalLine && /^\/[^\n\r]*$/.test(String(lineBody || ''));
    const echoLineBody = (!isInternalLine || shouldEchoInternalLine) ? lineBody : '';
    if (process.stdout.isTTY && _frameRendered) {
      try {
        // Calculate how many visual rows the input + bottom decoration occupy.
        // After Enter, readline moves cursor past the prompt line. We need to
        // jump back up over prompt rows and also clear the frame's top rule,
        // so assistant output is never visually enclosed by the input frame.
        const inputRows = _inputVisualRows();
        const linesUp = Math.max(2, inputRows + 1);
        const echoLine = `${_getPlainPrompt()}${echoLineBody}`;
        process.stdout.write(`\x1b[${linesUp}A\x1b[1G\x1b[J${echoLine}\n`);
      } catch { /* ignore */ }
      _frameRendered = false;
    } else if (process.stdout.isTTY) {
      try {
        process.stdout.write('\x1b[2K\x1b[1G'); // clear line + cursor to col 1
      } catch { /* ignore */ }
    }
    line = isInternalLine ? line.slice(INTERNAL_LINE_PREFIX.length) : line;

    // Guard against nested inquirer prompts from external handlers (e.g. gateway/model).
    // Without this, Enter/leftover input can leak into the main REPL line handler.
    const _externalInquirerActive = global.__KHY_INQUIRER_ACTIVE__ === true;
    if (!isInternalLine && (_inquirerActive || _externalInquirerActive)) {
      return;
    }

    // ── Suppress ghost line events during _ttyWrite bracketed paste capture ──
    // When _ttyWrite intercepts \x1b[200~ and starts capturing, readline still
    // emits line events for each \n in the paste.  These lines are fragments
    // that must NOT be executed or queued — _ttyWrite's _finishPasteCapture
    // will handle the full paste once the end marker arrives.
    if ((_pasteCapturing || _burstActive) && !isInternalLine) {
      return;
    }

    // ── Bracketed paste detection ──
    if (!isInternalLine) {
      const pasteState = _consumeBracketedPaste(line);
      if (pasteState.state === 'capturing') return;
      if (pasteState.state === 'completed') {
        if (!pasteState.text) { rl.prompt(); return; }
        // Unified: store pending + inject tag (or show directly if short)
        _storePendingPaste(pasteState.text, null, '', true);
        return;
      }
      line = pasteState.text; // cleaned text for normal processing
    }

    const trimmed = (isInternalLine ? lineBody : line).trim();

    // ── Flush pending paste: merge with any supplement the user typed ──
    // Same flow for busy and non-busy: user can add context, then Enter to send.
    if (_pendingPaste !== null && !isInternalLine) {
      // Strip the [Pasted text ...] tag from readline's line to get only the supplement
      const supplement = trimmed.replace(PASTE_TAG_RE, '').trim();
      if (!supplement) {
        // Empty submit — auto-committed newlines from paste often arrive as
        // ghost Enter events.  Suppress any empty submit within 600ms of
        // _storePendingPaste setting the pending state.
        const msSincePaste = Date.now() - _pendingPasteSetAt;
        if (msSincePaste < 600) {
          // Ghost Enter from paste tail — suppress silently, re-inject tag
          try {
            rl.write(null, { ctrl: true, name: 'u' });
            if (_pendingPasteTag) rl.write(_pendingPasteTag);
          } catch { /* ignore */ }
          if (_busy) showBusyInterjectPrompt();
          else rl.prompt();
          return;
        }
        // User deliberately pressed Enter on empty tag — show hint once,
        // then on second press flush.
        if (_pendingPasteSkipNextEmptySubmit) {
          _pendingPasteSkipNextEmptySubmit = false;
          const now = Date.now();
          if (now - _pendingPasteHintedAt > 1200) {
            if (_busy) {
              printInfo('已折叠粘贴素材：按回车发送（排队），或补充意图后回车');
            } else {
              printInfo('已折叠粘贴素材：按回车发送，或继续补充意图后回车');
            }
            _pendingPasteHintedAt = now;
          }
          try {
            rl.write(null, { ctrl: true, name: 'u' });
            if (_pendingPasteTag) rl.write(_pendingPasteTag);
            else _pendingPasteTag = _injectPasteIntoLine(_pendingPaste, rl) || '';
          } catch { /* ignore */ }
          if (_busy) showBusyInterjectPrompt();
          else rl.prompt();
          return;
        }
      }
      const paste = _pendingPaste;
      _pendingPaste = null;
      _pendingPasteTag = '';
      _pendingPasteSkipNextEmptySubmit = false;
      _pendingPasteHintedAt = 0;
      _pendingPasteSetAt = 0;
      // Wrap paste in markers so downstream (e.g. complexity assessment) can
      // distinguish pasted context from the user's actual instruction.
      const wrappedPaste = `<pasted-content>\n${paste}\n</pasted-content>`;
      const finalText = supplement ? wrappedPaste + '\n' + supplement : wrappedPaste;
      rl.emit('line', `${INTERNAL_LINE_PREFIX}${finalText}`);
      return;
    }

    if (!isInternalLine && isArrowEscapeLine(line)) {
      rl.prompt();
      return;
    }

    // Merge rapid multi-line paste into a single request before execution.
    // Also merge when busy — pasted content should not be sent line-by-line.
    if (!isInternalLine && !trimmed.startsWith('/') && _shouldBatchInputLine(line)) {
      _scheduleInputBatch(line, rl);
      return;
    }

    if (!trimmed) {
      if (_busy) {
        const now = Date.now();
        if (now - _lastBusyEnterHintAt > 1200) {
          console.log(c.dim(`  ↳ AI 请求执行中（${ai().getActiveProvider() || 'AI'}）：输入内容后回车可排队，/i <内容> 可优先处理`));
          _lastBusyEnterHintAt = now;
        }
        showBusyInterjectPrompt();
        return;
      }
      // Empty line: just re-prompt without re-rendering decorations
      _setLiveHudTypingMode();
      rl.setPrompt(_getPlainPrompt());
      _origPrompt();
      return;
    }

    if (!_busy && /^\/(?:err|error|last-error)$/i.test(trimmed)) {
      _printLastAiError();
      rl.prompt();
      return;
    }

    // Non-empty input: clear frame so decorations re-render after processing
    if (!_busy) leaveInputPromptFrame();

    // Busy-safe slash menu: show commands without interactive dropdown, keep stream stable.
    if (_busy && trimmed === '/') {
      const now = Date.now();
      if (now - _lastBusyEnterHintAt > 1200) {
        showBusySlashMenu();
        _lastBusyEnterHintAt = now;
      }
      showBusyInterjectPrompt();
      return;
    }

    // Bare "/" — picker handles it in real-time via _ttyWrite. If user somehow
    // presses Enter on bare "/", just re-prompt.
    if (trimmed === '/' && !isInternalLine) {
      rl.prompt();
      return;
    }

    // Slash command dispatch — handles picker selections (internal lines) and
    // directly typed commands like "/plan", "/model", etc.
    if (trimmed.startsWith('/') && trimmed.length > 1 && trimmed.length <= 16 && !/^\/\w+\s/.test(trimmed)) {
      const cmds = _getSlashCommands();
      const selected = cmds.find(sc => sc.cmd === trimmed);
      if (selected) {
        try {
          if (selected.flag) {
            // Handle special flags
            if (selected.flag.startsWith('effort-')) {
              const level = selected.flag.replace('effort-', '');
              if (ai().setEffort(level)) {
                const presets = ai().getEffortPresets();
                const p = presets[level];
                printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
              }
            } else if (selected.flag === 'plan') {
              _planMode = true;
              printInfo('Plan mode enabled — AI will plan before executing');
            } else if (selected.flag === 'vim') {
              if (_vimHandler && _vimHandler.isActive()) {
                _vimHandler.disable();
                _vimHandler = null;
                vimSettings().setEditorMode('normal');
                printSuccess('Vim mode disabled');
              } else {
                if (!_vimHandler) {
                  _vimHandler = vimInput().createVimInputHandler(rl, {
                    enabled: true,
                    prompt: buildCwdPrompt(),
                  });
                } else {
                  _vimHandler.enable();
                }
                vimSettings().setEditorMode('vim');
                printSuccess('Vim mode enabled — Esc for NORMAL, i for INSERT');
              }
            } else if (selected.flag === 'voice') {
              try {
                const voiceService = require('../services/voiceService');
                const settings = voiceService.getVoiceSettings();
                if (settings.enabled) {
                  voiceService.setVoiceEnabled(false);
                  voiceService.stopSpeaking();
                  printSuccess('Voice mode disabled');
                } else {
                  const caps = voiceService.getCapabilities();
                  voiceService.setVoiceEnabled(true);
                  printSuccess(`Voice mode enabled — TTS: ${caps.tts || 'none'} | STT: ${caps.stt || 'none'}`);
                }
              } catch (err) {
                printError(`Voice service error: ${err.message}`);
              }
            } else if (selected.flag === 'image') {
              printInfo('用法: image <文件路径> <分析提示>  或  paste <分析提示>');
              printInfo('示例: image ./landing.png 还原这个网页为可运行 HTML');
            } else if (selected.flag === 'paste') {
              try {
                const imageService = require('../services/imageService');
                const renderer = require('./aiRenderer');
                const { prompt: userPrompt } = await inqPrompt([{
                  type: 'input', name: 'prompt', message: '图片分析提示:',
                  default: '请分析这张图片',
                }]);
                const readStart = Date.now();
                const image = imageService.readImageFromClipboard();
                renderer.printToolCallResult('Clipboard', 'clipboard', 'success',
                  `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
                  Date.now() - readStart
                );
                imageService.printImagePreview(image);
                _busy = true;
                _startBusyPromptKeepalive();
                const prompt = buildContextualImagePrompt(
                  userPrompt,
                  buildImageSceneHint('clipboard paste image', history),
                );
                const aiResult = await ai().chat(prompt, {
                  images: [{ base64: image.base64, mimeType: image.mimeType }],
                });
                if (aiResult.reply) {
                  renderer.printStepLine('success', 'AI response', aiResult.provider || 'vision');
                  const rendered = renderer.renderAiResponse(aiResult.reply);
                  rendered.split('\n').forEach(l => console.log(`  ${l}`));
                } else {
                  printInfo('AI returned no result — current provider may not support vision');
                }
                _busy = false;
              } catch (e) {
                _busy = false;
                printError(`Clipboard read failed: ${e.message}`);
                printInfo('Ensure clipboard contains image data');
              }
            } else if (selected.flag === 'clipboard') {
              try {
                const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');
                const status = clipAdapter.getStatus();
                if (status.available) {
                  printSuccess(status.detail);
                } else {
                  printError(status.detail);
                }
                try {
                  const clipBridge = require('../services/windowsClipboardImg2FileService');
                  const bridgeStatus = clipBridge.getClipboardImg2FileBridgeStatus();
                  if (bridgeStatus.supported) {
                    if (bridgeStatus.running) {
                      const poll = bridgeStatus.meta?.pollMs || 500;
                      printSuccess(`图片粘贴桥接运行中（轮询 ${poll}ms，PID ${bridgeStatus.pid}）`);
                    } else if (!bridgeStatus.enabled) {
                      printInfo('图片粘贴桥接已禁用（环境变量 KHY_CLIPBOARD_IMG2FILE_ENABLED=false）');
                    } else {
                      printInfo('图片粘贴桥接未启动，可运行: clipboard bridge start');
                    }
                  }
                } catch {
                  // best effort
                }
                printInfo('用法: clipboard relay <提示>  或  webai <提示>');
                printInfo('管理: clipboard relay list / set <服务> / open');
                printInfo('图片粘贴桥接: clipboard bridge [status|start|stop|restart]');
              } catch (e) {
                printError(`剪贴板中继不可用: ${e.message}`);
              }
            } else if (selected.flag === 'websearch') {
              try {
                const webSearch = require('../services/webSearchService');
                if (!webSearch.isAvailable()) printInfo('未检测到 Kiro 认证，自动使用回退搜索');
                const { query } = await inqPrompt([{
                  type: 'input', name: 'query', message: '搜索关键词:',
                  validate: v => v.trim() ? true : '请输入搜索关键词',
                }]);
                printInfo(`正在搜索: ${query}`);
                const result = await webSearch.search(query);
                if (result.success) {
                  console.log('');
                  console.log(c.bold.cyan('  Search results'));
                  console.log(c.dim('  ─'.repeat(30)));
                  for (const r of (result.results || []).slice(0, 10)) {
                    console.log('');
                    console.log(c.bold.white(`  ${r.title}`));
                    if (r.url) console.log(c.blue(`  ${r.url}`));
                    if (r.snippet) console.log(c.gray(`  ${r.snippet}`));
                    if (r.publishedDate) console.log(c.dim(`  ${r.publishedDate}`));
                  }
                  console.log('');
                } else {
                  printError(result.error || '搜索失败');
                }
              } catch (e) {
                printError(`搜索失败: ${e.message}`);
              }
            } else if (selected.flag === 'proxy') {
              try {
                const proxyConfig = require('../services/proxyConfigService');
                const status = proxyConfig.getStatus();
                if (status.active) {
                  printSuccess(`代理已启用: ${status.url}`);
                  const { action } = await inqPrompt([{
                    type: 'list', name: 'action', message: '代理操作:',
                    choices: [
                      { name: '关闭代理', value: 'off' },
                      { name: '重新检测 Clash', value: 'detect' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'off') { proxyConfig.disableProxy(); printSuccess('代理已关闭'); }
                  else if (action === 'detect') {
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  }
                } else {
                  const { action } = await inqPrompt([{
                    type: 'list', name: 'action', message: '代理设置:',
                    choices: [
                      { name: '自动检测 Clash', value: 'detect' },
                      { name: '手动配置 HTTP 代理', value: 'http' },
                      { name: '手动配置 SOCKS5 代理', value: 'socks5' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'detect') {
                    printInfo('正在检测 Clash...');
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  } else if (action === 'http' || action === 'socks5') {
                    const { port } = await inqPrompt([{
                      type: 'input', name: 'port', message: `端口 (默认 ${action === 'http' ? '7890' : '1080'}):`,
                      default: action === 'http' ? '7890' : '1080',
                    }]);
                    const r = await proxyConfig.enableProxy({ type: action, host: '127.0.0.1', port });
                    r.success ? printSuccess(`代理已启用: ${r.proxy.url}`) : printError(r.error);
                  }
                }
              } catch (e) { printError(`代理配置失败: ${e.message}`); }
            } else if (selected.flag === 'models') {
              try {
                const ollamaMgr = require('../services/ollamaModelManager');
                const running = await ollamaMgr.isOllamaRunning();
                const hw = ollamaMgr.detectHardware();

                console.log('');
                printInfo(`硬件: ${hw.totalRamGB} GB RAM · ${hw.cpuCount} CPUs` + (hw.gpu ? ` · GPU: ${hw.gpu.name} (${(hw.gpu.vramMB / 1024).toFixed(1)} GB)` : ''));
                printInfo(`硬件等级: ${hw.tier.toUpperCase()} — Ollama ${running ? c.green('运行中') : c.yellow('未运行')}`);
                console.log('');

                if (running) {
                  const models = await ollamaMgr.listModels();
                  if (models.length > 0) {
                    printSuccess(`已安装 ${models.length} 个模型:`);
                    for (const m of models) {
                      console.log(c.dim(`    ${m.name}  (${m.size}, ${m.paramSize})`));
                    }
                  } else {
                    printInfo('暂无已安装模型');
                  }
                }

                const { recommended } = ollamaMgr.getRecommendations();
                const mainChoices = [
                  { name: '下载推荐模型', value: 'pull' },
                  { name: '导入本地模型文件/目录 (GGUF / Safetensors)', value: 'import' },
                  { name: '设置默认模型', value: 'set' },
                  { name: '删除已安装模型', value: 'delete' },
                  { name: '取消', value: 'cancel' },
                ];
                const { action } = await inqPrompt([{
                  type: 'list', name: 'action', message: '模型管理操作:',
                  choices: mainChoices,
                }]);

                if (action === 'pull') {
                  console.log('');
                  printInfo(`推荐模型 (${hw.tier} 级别):`);
                  const choices = recommended.map(m => ({
                    name: `${m.name} (${m.size}) — ${m.reason}`,
                    value: m.id,
                  }));
                  choices.push({ name: '取消', value: 'cancel' });
                  const { modelId } = await inqPrompt([{
                    type: 'list', name: 'modelId', message: '选择要下载的模型:',
                    choices,
                  }]);
                  if (modelId !== 'cancel' && running) {
                    printInfo(`正在下载 ${modelId}...`);
                    await ollamaMgr.pullModel(modelId, (progress) => {
                      if (progress.total > 0 && process.stdout.isTTY) {
                        process.stdout.write(`\r  ⟳ ${progress.status} ${progress.percent}%`);
                      }
                    });
                    console.log('');
                    printSuccess(`模型 ${modelId} 下载完成!`);
                  }
                } else if (action === 'import') {
                  if (!running) {
                    printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  } else {
                    const ans = await inqPrompt([
                      { type: 'input', name: 'source', message: '本地路径 (.gguf/.safetensors/目录):' },
                      { type: 'input', name: 'name', message: '目标模型名 (可空自动生成):', default: '' },
                      { type: 'input', name: 'base', message: '若是 adapter，填写 base 模型 (如 qwen2.5:7b，可空):', default: '' },
                    ]);
                    const imported = await ollamaMgr.importModel(ans.source, ans.name, { base: ans.base || undefined });
                    if (!imported.success) {
                      printError(`导入失败: ${imported.error}`);
                    } else {
                      printSuccess(`导入成功: ${imported.model} (${imported.sourceKind})`);
                      printInfo(`运行: models set ${imported.model}`);
                    }
                  }
                } else if (action === 'set') {
                  if (!running) {
                    printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  } else {
                    const models = await ollamaMgr.listModels();
                    if (!models.length) {
                      printInfo('暂无已安装模型');
                    } else {
                      const fs = require('fs');
                      const envPath = path.resolve(__dirname, '../../.env');
                      let envContent = '';
                      try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }
                      const setEnvVar = (k, v) => {
                        const regex = new RegExp(`^${k}=.*$`, 'm');
                        const line = `${k}=${v}`;
                        if (regex.test(envContent)) envContent = envContent.replace(regex, line);
                        else envContent = envContent.trimEnd() + '\n' + line + '\n';
                        fs.writeFileSync(envPath, envContent);
                        process.env[k] = String(v);
                      };
                      const { picked } = await inqPrompt([{
                        type: 'list',
                        name: 'picked',
                        message: '选择默认 Ollama 模型:',
                        choices: models.map(m => ({ name: `${m.name} (${m.size})`, value: m.name })),
                      }]);
                      setEnvVar('GATEWAY_PREFERRED_ADAPTER', 'ollama');
                      setEnvVar('GATEWAY_PREFERRED_STRICT', 'true');
                      setEnvVar('OLLAMA_MODEL', picked);
                      try {
                        const gateway = require('../services/gateway/aiGateway');
                        await gateway.refreshAdapters();
                      } catch { /* best effort */ }
                      printSuccess(`已设置默认模型: ollama/${picked}`);
                    }
                  }
                } else if (action === 'delete') {
                  if (!running) {
                    printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  } else {
                    const models = await ollamaMgr.listModels();
                    if (!models.length) {
                      printInfo('暂无已安装模型');
                    } else {
                      const { picked } = await inqPrompt([{
                        type: 'list',
                        name: 'picked',
                        message: '选择要删除的模型:',
                        choices: [...models.map(m => ({ name: `${m.name} (${m.size})`, value: m.name })), { name: '取消', value: 'cancel' }],
                      }]);
                      if (picked !== 'cancel') {
                        const ok = await ollamaMgr.deleteModel(picked);
                        if (ok) printSuccess(`已删除模型: ${picked}`);
                        else printError(`删除失败: ${picked}`);
                      }
                    }
                  }
                }
              } catch (e) { printError(`模型管理失败: ${e.message}`); }
            } else if (selected.flag === 'scan') {
              try {
                const av = require('../services/antivirusService');
                const tools = av.detectTools();
                if (!tools.hasClamAV) {
                  printError('ClamAV 未安装');
                  const inst = av.getInstallInstructions();
                  printInfo(`安装命令: ${inst.install}`);
                } else {
                  printInfo('正在扫描项目文件...');
                  const result = av.scanProject();
                  if (result.clean) {
                    printSuccess(`扫描完成: 未发现威胁 (${(result.elapsed / 1000).toFixed(1)}s)`);
                  } else {
                    printError(`发现 ${result.infected} 个威胁!`);
                    for (const t of result.threats) {
                      console.log(c.red(`    ${t.virus} → ${t.file}`));
                    }
                    printInfo('已隔离到 ~/.khyquant/quarantine/');
                  }
                }
              } catch (e) { printError(`扫描失败: ${e.message}`); }
            } else if (selected.flag === 'security-full') {
              try {
                const secGuard = require('../services/securityGuardService');
                const integrity = require('../services/fileIntegrityService');
                const resGuard = require('../services/resourceGuard');

                console.log('');
                printInfo('文件完整性校验...');
                const intResult = integrity.verify();
                if (intResult.verified) {
                  printSuccess(`完整性: ${intResult.unchanged} 文件无改动`);
                } else {
                  printError(`完整性异常: ${intResult.modified.length} 修改, ${intResult.removed.length} 删除`);
                  for (const f of intResult.modified.slice(0, 5)) console.log(c.yellow(`    修改: ${f}`));
                  for (const f of intResult.removed.slice(0, 5)) console.log(c.red(`    删除: ${f}`));
                }
                if (intResult.added.length > 0) {
                  printInfo(`新增文件: ${intResult.added.length} (正常更新)`);
                }

                printInfo('威胁扫描...');
                const threats = secGuard.scanForThreats();
                if (threats.clean) {
                  printSuccess('威胁扫描: 未发现异常');
                } else {
                  printError(`发现 ${threats.threats.length} 个威胁:`);
                  for (const t of threats.threats) {
                    console.log(c.red(`    [${t.severity}] ${t.type}: ${t.detail}`));
                  }
                }

                const health = resGuard.systemHealthCheck();
                if (health.healthy) {
                  printSuccess('系统资源: 正常');
                } else {
                  for (const w of health.warnings) printWarn(w);
                }

                const stats = secGuard.getSecurityStats();
                if (stats.totalEvents > 0) {
                  printInfo(`安全事件: ${stats.totalEvents} 总计, ${stats.last24h} 近24小时`);
                }
                console.log('');
              } catch (e) { printError(`安全检查失败: ${e.message}`); }
            } else if (selected.flag === 'hardware') {
              try {
                const hw = require('../services/hardwareProfileService');
                const { lines, profile } = hw.getHardwareSummary();

                console.log('');
                printInfo('硬件配置:');
                for (const line of lines) console.log(c.dim(`    ${line}`));
                console.log('');

                if (profile.localModels.length > 0) {
                  printInfo('推荐本地模型:');
                  for (const m of profile.localModels) {
                    const rec = m.recommended ? c.green(' ★ 推荐') : '';
                    if (m.recommendation === 'api-only') {
                      console.log(c.yellow(`    ${m.reason}`));
                    } else {
                      console.log(c.dim(`    ${m.name} (${m.sizeGB}GB)`) + rec);
                      console.log(c.dim(`      ${m.reason}`));
                    }
                  }
                }

                console.log('');
                printInfo('资源限制:');
                const lim = profile.limits;
                console.log(c.dim(`    Node.js 堆: ${lim.nodeHeapMB}MB`));
                console.log(c.dim(`    并发数: ${lim.maxConcurrency}`));
                console.log(c.dim(`    多智能体: ${lim.enableMultiAgent ? '启用' : '禁用'}`));
                console.log(c.dim(`    本地模型: ${lim.enableLocalModel ? '启用' : '禁用'}`));
                console.log('');
              } catch (e) { printError(`硬件检测失败: ${e.message}`); }
            } else if (selected.flag === 'review') {
              try {
                const { handleReview } = require('./handlers/review');
                _busy = true;
                _startBusyPromptKeepalive();
                await handleReview();
                _busy = false;
              } catch (e) { printError(`代码审查失败: ${e.message}`); _busy = false; }
            } else if (selected.flag === 'subscribe') {
              try {
                const { handleDocsSubscription } = require('./handlers/docs');
                await handleDocsSubscription();
              } catch (e) { printError(`显示订阅指引失败: ${e.message}`); }

            // ── Claude Code aligned flag handlers ──────────────────────
            } else if (new Set([
              'compact', 'config', 'context', 'diff', 'effort', 'env',
              'export', 'fast', 'files', 'hooks', 'mcp', 'session',
              'share', 'stats', 'status', 'summary', 'tasks', 'theme',
              'branch', 'debug', 'stickers',
            ]).has(selected.flag)) {
              recoverReadlineInput();
              const cmdParsed = parseInput(selected.cmd.slice(1));
              if (cmdParsed) {
                const result = await route(cmdParsed);
                recoverReadlineInput();
                if (result === 'exit') {
                  const savedMeta = ai().saveConversation();
                  saveHistory(history);
                  setTerminalTitle('');
                  console.log('');
                  console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
                  printResumeRecoveryHints(savedMeta);
                  console.log('');
                  _uninstallBusyPromptConsolePatch();
                  _intentionalExit = true; process.exit(0);
                }
              }

            } else if (selected.flag === 'compact') {
              printInfo('Compacting conversation history...');
              try {
                ai().compactConversation && ai().compactConversation();
                printSuccess('对话已压缩');
              } catch (e) { printError(`Compact failed: ${e.message}`); }

            } else if (selected.flag === 'config') {
              const settings = (() => {
                try { return JSON.parse(fs.readFileSync(path.join(os.homedir(), '.khy', 'settings.json'), 'utf-8')); } catch { return {}; }
              })();
              console.log(c.bold('\n  Configuration:'));
              for (const [k, v] of Object.entries(settings)) {
                console.log(`    ${c.cyan(k)}: ${JSON.stringify(v)}`);
              }
              if (Object.keys(settings).length === 0) console.log(c.dim('    No custom settings'));
              console.log('');

            } else if (selected.flag === 'context') {
              try {
                const hud = require('./hudRenderer');
                const state = hud.getState();
                const pct = state.contextWindow.limit > 0
                  ? Math.round((state.contextWindow.used / state.contextWindow.limit) * 100) : 0;
                console.log(c.bold('\n  Context Window:'));
                console.log(`    Used: ${(state.contextWindow.used / 1000).toFixed(1)}k / ${(state.contextWindow.limit / 1000).toFixed(0)}k tokens (${pct}%)`);
                console.log(`    Session tokens: ↑${(state.sessionTokens.input / 1000).toFixed(1)}k ↓${(state.sessionTokens.output / 1000).toFixed(1)}k`);
                console.log(`    Requests: ${state.requestCount}`);
                console.log('');
              } catch (e) { printError(`Context info failed: ${e.message}`); }

            } else if (selected.flag === 'diff') {
              try {
                const { execSync } = require('child_process');
                const diff = execSync('git diff', { encoding: 'utf-8', timeout: 5000 }).trim();
                if (diff) {
                  renderSideBySideDiff(diff);
                } else {
                  printInfo('No uncommitted changes');
                }
              } catch (e) { printError(`Diff failed: ${e.message}`); }

            } else if (selected.flag === 'effort') {
              printInfo('Use /max, /high, /medium, or /low to set effort level');

            } else if (selected.flag === 'env') {
              console.log(c.bold('\n  Environment:'));
              console.log(`    Platform: ${process.platform} ${process.arch}`);
              console.log(`    Node: ${process.version}`);
              console.log(`    CWD: ${process.cwd()}`);
              console.log(`    Shell: ${process.env.SHELL || 'N/A'}`);
              console.log(`    Term: ${process.env.TERM || 'N/A'}`);
              try {
                const { execSync } = require('child_process');
                const branch = execSync('git rev-parse --abbrev-ref HEAD', { encoding: 'utf-8', timeout: 2000 }).trim();
                console.log(`    Git branch: ${branch}`);
              } catch { /* not a git repo */ }
              console.log('');

            } else if (selected.flag === 'export') {
              try {
                const exportPath = path.join(process.cwd(), `khy-session-${Date.now()}.json`);
                const convo = ai().getConversation ? ai().getConversation() : [];
                fs.writeFileSync(exportPath, JSON.stringify(convo, null, 2), 'utf-8');
                printSuccess(`Conversation exported to ${exportPath}`);
              } catch (e) { printError(`Export failed: ${e.message}`); }

            } else if (selected.flag === 'fast') {
              _fastMode = !_fastMode;
              printSuccess(`Fast mode ${_fastMode ? 'enabled' : 'disabled'}`);

            } else if (selected.flag === 'files') {
              try {
                const { execSync } = require('child_process');
                const files = execSync('git ls-files', { encoding: 'utf-8', timeout: 5000 }).trim().split('\n');
                console.log(c.bold(`\n  Files in repo (${files.length}):`));
                files.slice(0, 30).forEach(f => console.log(`    ${f}`));
                if (files.length > 30) console.log(c.dim(`    ... and ${files.length - 30} more`));
                console.log('');
              } catch (e) { printError(`Files listing failed: ${e.message}`); }

            } else if (selected.flag === 'hooks') {
              try {
                const hookSystem = require('./hooks/hookSystem');
                const count = hookSystem.registry.count;
                console.log(c.bold(`\n  Hooks: ${count} registered`));
                for (const ev of hookSystem.registry.events) {
                  const hooks = hookSystem.registry.getHooks(ev);
                  if (hooks.length > 0) console.log(`    ${ev}: ${hooks.length} hook(s)`);
                }
                console.log('');
              } catch (e) { printError(`Hooks info failed: ${e.message}`); }

            } else if (selected.flag === 'mcp') {
              printInfo('MCP server management. Use /mcp add <name> <command> to add a server.');

            } else if (selected.flag === 'session') {
              const elapsed = ((Date.now() - _sessionStart) / 1000 / 60).toFixed(1);
              console.log(c.bold('\n  Session Info:'));
              console.log(`    Duration: ${elapsed} min`);
              console.log(`    Version: ${VERSION}`);
              console.log('');

            } else if (selected.flag === 'share') {
              printInfo('Share is not yet supported in CLI mode.');

            } else if (selected.flag === 'stats') {
              try {
                const hud = require('./hudRenderer');
                const s = hud.getState();
                console.log(c.bold('\n  Session Stats:'));
                console.log(`    Requests: ${s.requestCount}`);
                console.log(`    Tokens: ↑${(s.sessionTokens.input/1000).toFixed(1)}k ↓${(s.sessionTokens.output/1000).toFixed(1)}k total=${(s.sessionTokens.total/1000).toFixed(1)}k`);
                console.log(`    Tools used: ${s.toolHistory.length}`);
                console.log(`    Active agents: ${s.activeAgents.length}`);
                console.log('');
              } catch (e) { printError(`Stats failed: ${e.message}`); }

            } else if (selected.flag === 'status') {
              try {
                const hud = require('./hudRenderer');
                hud.refreshGit();
                const s = hud.getState();
                console.log(c.bold('\n  Status:'));
                if (s.git.branch) console.log(`    Branch: ${s.git.branch}${s.git.dirty ? ` (${s.git.dirtyCount} changed)` : ''}`);
                if (s.activeTool) console.log(`    Active: ${s.activeTool.name}`);
                if (s.activeAgents.length > 0) console.log(`    Agents: ${s.activeAgents.map(a => a.name).join(', ')}`);
                console.log(`    Context: ${Math.round(s.contextWindow.used/1000)}k/${Math.round(s.contextWindow.limit/1000)}k`);
                console.log('');
              } catch (e) { printError(`Status failed: ${e.message}`); }

            } else if (selected.flag === 'mind') {
              _renderTaskMindMap('manual');

            } else if (selected.flag === 'summary') {
              printInfo('Generating conversation summary...');
              try {
                const convo = ai().getConversation ? ai().getConversation() : [];
                printInfo(`Conversation has ${convo.length} messages. Use AI to summarize.`);
              } catch (e) { printError(`Summary failed: ${e.message}`); }

            } else if (selected.flag === 'tasks') {
              await _handleTasksCommand('');

            } else if (selected.flag === 'theme') {
              printInfo('Themes: dark (default). Use /config to set custom theme.');

            } else if (selected.flag === 'branch') {
              try {
                const { execSync } = require('child_process');
                const branches = execSync('git branch -a', { encoding: 'utf-8', timeout: 5000 }).trim();
                console.log(c.bold('\n  Git Branches:'));
                console.log(branches.split('\n').map(b => `    ${b.trim()}`).join('\n'));
                console.log('');
              } catch (e) { printError(`Branch info failed: ${e.message}`); }

            } else if (selected.flag === 'debug') {
              printInfo('Debug mode. Use /debug <tool_name> to debug the last tool call.');

            } else if (selected.flag === 'stickers') {
              const stickers = ['(╯°□°)╯︵ ┻━┻', '┬─┬ノ( º _ ºノ)', '( •_•)>⌐■-■', '(⌐■_■)', '\\(^_^)/', '(>_<)', '(◕‿◕)', '(ノಠ益ಠ)ノ彡┻━┻'];
              console.log('\n  ' + stickers[Math.floor(Math.random() * stickers.length)] + '\n');

            } else if (selected.flag === 'effort-max') {
              _effortLevel = 'max';
              printSuccess('Effort level: MAX — AI will use maximum precision');

            }
          } else if (selected.cmd === '/study') {
            // ── /study — gated study mode toggle (Owner Secret required) ──
            try {
              const owner = require('../services/ownerControlService');
              const aiMod = ai();
              // Parse action from the trimmed text (trimmed is just "/study" from picker)
              const studyState = aiMod.isStudyMode ? aiMod.isStudyMode() : false;
              // Prompt user for action
              const { action } = await inqPrompt([{
                type: 'list', name: 'action',
                message: `学习模式: ${studyState ? c.green('ON') : c.dim('OFF')}`,
                choices: [
                  { name: studyState ? '关闭学习模式' : '开启学习模式', value: studyState ? 'off' : 'on' },
                  { name: '查看状态', value: 'status' },
                  { name: '取消', value: 'cancel' },
                ],
              }]);
              if (action === 'status') {
                printInfo(`学习模式当前状态: ${studyState ? c.green('ON') : c.dim('OFF')}`);
              } else if (action === 'on') {
                if (studyState) {
                  printInfo('学习模式已处于激活状态');
                } else {
                  // Ask for owner secret
                  let secret = '';
                  if (process.stdin.isTTY && process.stdout.isTTY) {
                    const answer = await inqPrompt([{
                      type: 'password', name: 'secret',
                      message: 'Owner secret:',
                      mask: '*',
                      validate: v => String(v || '').trim().length > 0 || 'Secret 不能为空',
                    }]);
                    secret = String(answer.secret || '').trim();
                  }
                  const verify = owner.verifyOwnerSecret(secret);
                  if (!verify.ok) {
                    printError(verify.error || 'Owner Secret 校验失败');
                  } else {
                    aiMod.enableStudyMode && aiMod.enableStudyMode();
                    console.log('');
                    printSuccess('学习模式已解锁！');
                    console.log(c.dim('  现在你可以向 AI 提问关于本项目的一切'));
                    console.log(c.dim('  建议先运行 knowledge self 查看当前能力边界与学习路径'));
                    console.log('');
                  }
                }
              } else if (action === 'off') {
                if (!studyState) {
                  printInfo('学习模式已处于关闭状态');
                } else {
                  aiMod.disableStudyMode && aiMod.disableStudyMode();
                  printSuccess('学习模式已关闭');
                }
              }
            } catch (e) { printError(`学习模式操作失败: ${e.message}`); }
          } else if (selected.route) {
            recoverReadlineInput();
            const cmdParsed = parseInput(selected.route);
            if (cmdParsed) {
              const result = await route(cmdParsed);
              recoverReadlineInput();
              if (result === 'exit') {
                const savedMeta = ai().saveConversation();
                saveHistory(history);
                setTerminalTitle('');
                console.log('');
                console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
                printResumeRecoveryHints(savedMeta);
                console.log('');
                _uninstallBusyPromptConsolePatch();
                _intentionalExit = true; process.exit(0);
              }
            }
          } else {
            // No flag/route defined — try routing the command name directly
            recoverReadlineInput();
            const cmdParsed = parseInput(selected.cmd.slice(1)); // strip leading '/'
            if (cmdParsed) {
              const result = await route(cmdParsed);
              recoverReadlineInput();
              if (result === 'exit') {
                const savedMeta = ai().saveConversation();
                saveHistory(history);
                setTerminalTitle('');
                console.log('');
                console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
                printResumeRecoveryHints(savedMeta);
                console.log('');
                _uninstallBusyPromptConsolePatch();
                _intentionalExit = true; process.exit(0);
              }
            }
          }
        } catch (e) { /* command handler error */ }
        recoverReadlineInput();
        rl.prompt();
        return;
      }
    }

    // /btw — queue hint without interrupting current AI work
    if (trimmed === '/btw' || trimmed.startsWith('/btw ')) {
      const hint = trimmed.slice(4).trim();
      if (hint) {
        _btwQueue.push(hint);
        console.log(c.dim(`  Queued hint (${_btwQueue.length} in queue)`));
      } else {
        console.log(c.dim('  Usage: /btw <hint text>'));
        console.log(c.dim('  Queue a hint while AI is working without interrupting'));
        console.log(c.dim(`  Current queue: ${_btwQueue.length} hint(s)`));
      }
      rl.prompt();
      return;
    }

    // /steer 或 /s — 方向修正，注入到当前工具循环
    if (trimmed === '/steer' || trimmed.startsWith('/steer ') ||
        (trimmed.startsWith('/s ') && trimmed.length > 3 && !/^\/s(?:kin|ession|earch|can|ecurity|ub|kill|erver)/.test(trimmed))) {
      const hint = trimmed.replace(/^\/(?:steer|s)\s*/, '').trim();
      if (!hint) {
        console.log(c.hex('#D77757')('  用法: /steer <修正内容> 或 /s <修正内容>'));
        console.log(c.dim('  在 AI 工作中注入方向修正（如"别用那个库"、"改成 TS"）'));
        console.log(c.dim(`  当前 steer 队列: ${_steerQueue.length} 条`));
      } else if (!_busy) {
        printInfo('/steer 仅在 AI 工作中可用，当前空闲请直接输入');
      } else {
        _steerQueue.push(hint);
        const preview = _summarizeQueuedInputForDisplay(hint, 40);
        console.log(c.hex('#D77757')(`  ⟳ 已注入方向修正: "${preview}"`));
        console.log(c.dim(`    └ 将在 AI 下一轮工具调用前生效`));
      }
      showBusyInterjectPrompt();
      rl.prompt();
      return;
    }

    // /study on|off|status — direct typed study mode commands (with optional --secret)
    if (/^\/study(?:\s|$)/i.test(trimmed)) {
      try {
        const owner = require('../services/ownerControlService');
        const aiMod = ai();
        const studyState = aiMod.isStudyMode ? aiMod.isStudyMode() : false;
        const args = trimmed.slice(6).trim(); // after "/study"
        const actionMatch = /^(on|off|status)/i.exec(args);
        const action = actionMatch ? actionMatch[1].toLowerCase() : 'status';
        const secretMatch = /--secret\s+(\S+)/.exec(args);

        if (action === 'status') {
          printInfo(`学习模式当前状态: ${studyState ? c.green('ON') : c.dim('OFF')}`);
        } else if (action === 'on') {
          if (studyState) {
            printInfo('学习模式已处于激活状态');
          } else {
            let secret = secretMatch ? secretMatch[1] : '';
            if (!secret && process.stdin.isTTY && process.stdout.isTTY) {
              const answer = await inqPrompt([{
                type: 'password', name: 'secret',
                message: 'Owner secret:',
                mask: '*',
                validate: v => String(v || '').trim().length > 0 || 'Secret 不能为空',
              }]);
              secret = String(answer.secret || '').trim();
            }
            const verify = owner.verifyOwnerSecret(secret);
            if (!verify.ok) {
              printError(verify.error || 'Owner Secret 校验失败');
            } else {
              aiMod.enableStudyMode && aiMod.enableStudyMode();
              console.log('');
              printSuccess('学习模式已解锁！');
              console.log(c.dim('  现在你可以向 AI 提问关于本项目的一切'));
              console.log(c.dim('  建议先运行 knowledge self 查看当前能力边界与学习路径'));
              console.log('');
            }
          }
        } else if (action === 'off') {
          if (!studyState) {
            printInfo('学习模式已处于关闭状态');
          } else {
            aiMod.disableStudyMode && aiMod.disableStudyMode();
            printSuccess('学习模式已关闭');
          }
        }
      } catch (e) { printError(`学习模式操作失败: ${e.message}`); }
      recoverReadlineInput();
      rl.prompt();
      return;
    }

    // /vim — toggle vim mode
    if (trimmed === '/vim') {
      const c = chalk();
      if (_vimHandler && _vimHandler.isActive()) {
        _vimHandler.disable();
        _vimHandler = null;
        vimSettings().setEditorMode('normal');
        console.log(c.green('  Vim mode disabled'));
      } else {
        if (!_vimHandler) {
          _vimHandler = vimInput().createVimInputHandler(rl, {
            enabled: true,
            prompt: buildCwdPrompt(),
          });
        } else {
          _vimHandler.enable();
        }
        vimSettings().setEditorMode('vim');
        console.log(c.green('  Vim mode enabled — Esc for NORMAL, i for INSERT'));
      }
      if (!_vimHandler || !_vimHandler.isActive()) {
        rl.prompt();
      }
      return;
    }

    // /voice — toggle voice mode
    if (trimmed === '/voice') {
      const c = chalk();
      try {
        const voiceService = require('../services/voiceService');
        const settings = voiceService.getVoiceSettings();
        if (settings.enabled) {
          voiceService.setVoiceEnabled(false);
          voiceService.stopSpeaking();
          console.log(c.green('  Voice mode disabled'));
        } else {
          const caps = voiceService.getCapabilities();
          voiceService.setVoiceEnabled(true);
          console.log(c.green('  Voice mode enabled'));
          console.log(c.dim(`    TTS: ${caps.tts || 'none'} | STT: ${caps.stt || 'none'}`));
          if (!caps.tts) console.log(c.yellow('    No TTS provider found. Install espeak or edge-tts.'));
          if (!caps.stt) console.log(c.yellow('    No STT provider found. Install sox or whisper.'));
        }
      } catch (err) {
        console.log(c.red(`  Voice service error: ${err.message}`));
      }
      rl.prompt();
      return;
    }

    // /fast — toggle fast mode
    if (trimmed === '/fast') {
      _fastMode = !_fastMode;
      printSuccess(`Fast mode ${_fastMode ? 'enabled' : 'disabled'}`);
      rl.prompt();
      return;
    }

    // /compact — compact conversation
    if (trimmed === '/compact') {
      printInfo('Compacting conversation...');
      try {
        ai().compactConversation && ai().compactConversation();
        printSuccess('对话已压缩');
      } catch (e) { printError(`Compact failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /context — show context window usage
    if (trimmed === '/context') {
      try {
        const hud = require('./hudRenderer');
        const s = hud.getState();
        const pct = s.contextWindow.limit > 0 ? Math.round((s.contextWindow.used / s.contextWindow.limit) * 100) : 0;
        const c = chalk();
        console.log(c.bold('\n  Context Window:'));
        console.log(`    Used: ${(s.contextWindow.used/1000).toFixed(1)}k / ${(s.contextWindow.limit/1000).toFixed(0)}k tokens (${pct}%)`);
        console.log(`    Session: ↑${(s.sessionTokens.input/1000).toFixed(1)}k ↓${(s.sessionTokens.output/1000).toFixed(1)}k`);
        console.log('');
      } catch (e) { printError(`Context failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /diff — show git diff
    if (trimmed === '/diff') {
      try {
        const { execSync } = require('child_process');
        const diff = execSync('git diff', { encoding: 'utf-8', timeout: 5000 }).trim();
        if (diff) {
          renderSideBySideDiff(diff);
        } else {
          printInfo('No uncommitted changes');
        }
      } catch (e) { printError(`Diff failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /status — show current status
    if (trimmed === '/status') {
      try {
        const hud = require('./hudRenderer');
        hud.refreshGit();
        const s = hud.getState();
        const c = chalk();
        console.log(c.bold('\n  Status:'));
        if (s.git.branch) console.log(`    Branch: ${s.git.branch}${s.git.dirty ? ` (${s.git.dirtyCount} changed)` : ''}`);
        console.log(`    Context: ${Math.round(s.contextWindow.used/1000)}k/${Math.round(s.contextWindow.limit/1000)}k`);
        console.log(`    Requests: ${s.requestCount}`);
        console.log('');
      } catch (e) { printError(`Status failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /mind — inspect AI task mind-map state
    const mindMatch = trimmed.match(/^\/mind(?:\s+(show|status|on|off|reset))?$/i);
    if (mindMatch) {
      const action = String(mindMatch[1] || 'show').toLowerCase();
      if (action === 'on') {
        _taskMindMapAutoShow = true;
        printSuccess('已开启认知双图自动展示');
      } else if (action === 'off') {
        _taskMindMapAutoShow = false;
        printSuccess('已关闭认知双图自动展示');
      } else if (action === 'reset') {
        _resetCognitionMapsToStartNode();
        printSuccess('认知双图已重置到起点');
      } else {
        _renderTaskMindMap('manual');
        printInfo(`自动展示: ${_taskMindMapAutoShow ? 'on' : 'off'}`);
      }
      rl.prompt();
      return;
    }

    // /stats — show session statistics
    if (trimmed === '/stats') {
      try {
        const hud = require('./hudRenderer');
        const s = hud.getState();
        const c = chalk();
        const elapsed = ((Date.now() - _sessionStart) / 1000 / 60).toFixed(1);
        console.log(c.bold('\n  Session Stats:'));
        console.log(`    Duration: ${elapsed} min`);
        console.log(`    Requests: ${s.requestCount}`);
        console.log(`    Tokens: ↑${(s.sessionTokens.input/1000).toFixed(1)}k ↓${(s.sessionTokens.output/1000).toFixed(1)}k`);
        console.log(`    Tools: ${s.toolHistory.length} calls`);
        console.log('');
      } catch (e) { printError(`Stats failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /env — environment info
    if (trimmed === '/env') {
      const c = chalk();
      console.log(c.bold('\n  Environment:'));
      console.log(`    Platform: ${process.platform} ${process.arch}`);
      console.log(`    Node: ${process.version}`);
      console.log(`    CWD: ${process.cwd()}`);
      console.log(`    Shell: ${process.env.SHELL || 'N/A'}`);
      console.log(`    Version: ${VERSION}`);
      console.log('');
      rl.prompt();
      return;
    }

    // /tasks — task runtime inspect & control
    const tasksCmdMatch = trimmed.match(/^\/tasks(?:\s+([\s\S]+))?$/i);
    if (tasksCmdMatch) {
      await _handleTasksCommand(tasksCmdMatch[1] || '');
      rl.prompt();
      return;
    }

    // /max, /high, /medium, /low — effort level switching
    const effortMatch = trimmed.match(/^\/(max|high|medium|low)$/);
    if (effortMatch) {
      const level = effortMatch[1];
      if (ai().setEffort(level)) {
        const presets = ai().getEffortPresets();
        const p = presets[level];
        printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
      } else {
        printError('无效的精度级别');
      }
      rl.prompt();
      return;
    }

    // ── Clipboard image bridge commands (Windows bitmap -> file path) ────
    const clipBridgeMatch = /^(?:clipboard\s+bridge|clipboard\s+img2file|剪贴板桥接)(?:\s+(.+))?$/i.exec(trimmed);
    if (clipBridgeMatch) {
      const action = String(clipBridgeMatch[1] || 'status').trim().toLowerCase();
      try {
        const bridge = require('../services/windowsClipboardImg2FileService');
        const showStatus = () => {
          const status = bridge.getClipboardImg2FileBridgeStatus();
          if (!status.supported) {
            printInfo('图片粘贴桥接仅支持 Windows 平台');
            return;
          }
          if (!status.enabled) {
            printInfo('图片粘贴桥接已禁用（设置 KHY_CLIPBOARD_IMG2FILE_ENABLED=true 可启用）');
            return;
          }
          if (status.running) {
            const pollMs = status.meta?.pollMs || 500;
            const keepFiles = status.meta?.keepFiles || 8;
            printSuccess(`图片粘贴桥接运行中：位图监听 ${pollMs}ms/次，保留最近 ${keepFiles} 张，PID ${status.pid}`);
          } else {
            printInfo('图片粘贴桥接未运行，可执行: clipboard bridge start');
          }
        };

        if (action === 'start' || action === 'on' || action === 'enable' || action === '开启') {
          const result = bridge.startClipboardImg2FileBridge();
          if (result.started) {
            const pollMs = result.meta?.pollMs || 500;
            printSuccess(`图片粘贴桥接已启动：监听位图剪贴板并注入路径文本（轮询 ${pollMs}ms）`);
          } else if (result.reason === 'already_running') {
            printInfo('图片粘贴桥接已在运行中');
          } else {
            showStatus();
          }
        } else if (action === 'stop' || action === 'off' || action === 'disable' || action === '关闭') {
          const stopped = bridge.stopClipboardImg2FileBridge();
          if (stopped) printSuccess('图片粘贴桥接已停止');
          else printInfo('图片粘贴桥接未运行');
        } else if (action === 'restart' || action === '重启') {
          bridge.stopClipboardImg2FileBridge();
          const result = bridge.startClipboardImg2FileBridge();
          if (result.started || result.reason === 'already_running') {
            printSuccess('图片粘贴桥接重启完成');
          } else {
            showStatus();
          }
        } else if (action === 'help' || action === 'h' || action === '?') {
          printInfo('用法: clipboard bridge [status|start|stop|restart]');
          printInfo('说明: 自动把剪贴板位图转换为 PNG 文件路径，便于在 CLI 中 Ctrl+V');
        } else {
          showStatus();
        }
      } catch (err) {
        printError(`图片粘贴桥接操作失败: ${err.message}`);
      }
      rl.prompt();
      return;
    }

    // ── Clipboard relay commands ──────────────────────────────────
    const clipRelayMatch = /^(?:clipboard\s+relay|剪贴板中继|webai)(?:\s+(.+))?$/i.exec(trimmed);
    if (clipRelayMatch) {
      const subCmd = (clipRelayMatch[1] || '').trim().toLowerCase();

      try {
        const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');

        // Sub-commands: service list, service set, open, or direct prompt
        if (subCmd === 'list' || subCmd === '列表') {
          const services = clipAdapter.getServices();
          const current = clipAdapter.getPreferredService();
          printInfo('可用的 Web AI 服务:');
          for (const [key, svc] of Object.entries(services)) {
            const marker = key === current ? c.green(' ← 当前') : '';
            console.log(`  ${c.cyan(key.padEnd(10))} ${svc.name.padEnd(20)} ${c.dim(svc.url)}${marker}`);
          }
        } else if (subCmd.startsWith('set ') || subCmd.startsWith('切换 ')) {
          const serviceKey = subCmd.replace(/^(set|切换)\s+/i, '').trim();
          if (clipAdapter.setService(serviceKey)) {
            const services = clipAdapter.getServices();
            printSuccess(`已切换到 ${services[serviceKey].name}`);
          } else {
            printError(`未知服务: ${serviceKey} — 运行 clipboard relay list 查看可用服务`);
          }
        } else if (subCmd === 'open' || subCmd === '打开') {
          const services = clipAdapter.getServices();
          const current = clipAdapter.getPreferredService();
          const svc = services[current];
          clipAdapter.openBrowser(svc.url);
          printInfo(`已打开 ${svc.name}: ${svc.url}`);
        } else if (subCmd === 'status' || subCmd === '状态' || !subCmd) {
          const status = clipAdapter.getStatus();
          if (status.available) {
            printSuccess(status.detail);
          } else {
            printError(status.detail);
          }
        } else {
          // Treat as a prompt to relay via clipboard
          _busy = true;
          _startBusyPromptKeepalive();
          try {
            const result = await clipAdapter.generate(subCmd);
            if (result.success) {
              const renderer = require('./aiRenderer');
              renderer.printStepLine('success', 'AI response', result.provider);
              const rendered = renderer.renderAiResponse(result.content);
              rendered.split('\n').forEach(l => console.log(`  ${l}`));
            } else {
              printError(result.content);
            }
          } finally {
            _busy = false;
          }
        }
      } catch (err) {
        printError(`剪贴板中继失败: ${err.message}`);
      }
      rl.prompt();
      return;
    }

    // Image analysis — file path or clipboard paste
    const imageMatch = trimmed.match(/^(?:image|图片|img)\s+(.+?\.(png|jpg|jpeg|gif|webp))\s*(.*)/i);
    const pasteMatch = /^(?:paste|粘贴|clipboard|剪贴板)(?:\s+(.*))?$/i.exec(trimmed);
    const sceneHint = buildImageSceneHint(trimmed, history);
    const inlineImage = (!imageMatch && !pasteMatch) ? extractInlineImageIntent(trimmed, sceneHint) : null;

    if (imageMatch || pasteMatch || inlineImage) {
      try {
        const imageService = require('../services/imageService');
        const renderer = require('./aiRenderer');
        let image, prompt;

        if (imageMatch || inlineImage) {
          // File path mode
          const filePath = imageMatch ? imageMatch[1] : inlineImage.filePath;
          prompt = imageMatch
            ? buildContextualImagePrompt(imageMatch[3] || '', sceneHint)
            : inlineImage.prompt;
          const readStart = Date.now();
          image = imageService.readImageFromFile(filePath);
          renderer.printToolCallResult('Read', { path: filePath }, 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        } else {
          // Clipboard paste mode
          prompt = buildContextualImagePrompt(
            pasteMatch[1] || '',
            buildImageSceneHint('clipboard paste image', history),
          );
          const readStart = Date.now();
          image = imageService.readImageFromClipboard();
          renderer.printToolCallResult('Clipboard', 'clipboard', 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        }

        // Show preview
        imageService.printImagePreview(image);

        // Send to AI with vision
        _busy = true;
        _startBusyPromptKeepalive();
        const aiResult = await ai().chat(prompt, {
          images: [{ base64: image.base64, mimeType: image.mimeType }],
        });

        if (aiResult.reply) {
          if (aiResult.errorType) {
            const rendered = _renderAiErrorCompact(aiResult.reply);
            if (!rendered?.merged) {
              printInfo('提示: 可用 /model 切换到支持视觉的模型后重试');
            }
          } else {
            renderer.printStepLine('success', 'AI 图片分析', aiResult.provider || 'vision');
            const rendered = renderer.renderAiResponse(aiResult.reply);
            rendered.split('\n').forEach(l => console.log(`  ${l}`));
          }
        } else {
          printInfo('AI 未返回分析结果 — 当前 AI 服务可能不支持图片分析');
        }
        console.log('');
      } catch (imgErr) {
        printError(`图片处理失败: ${imgErr.message}`);
      } finally {
        _busy = false;
      }
      rl.prompt();
      return;
    }

    // Prevent concurrent command execution
    if (_busy) {
      const busyMindMatch = trimmed.match(/^\/mind(?:\s+(show|status|on|off|reset))?$/i);
      if (busyMindMatch) {
        const action = String(busyMindMatch[1] || 'show').toLowerCase();
        if (action === 'on') {
          _taskMindMapAutoShow = true;
          printSuccess('已开启认知双图自动展示');
        } else if (action === 'off') {
          _taskMindMapAutoShow = false;
          printSuccess('已关闭认知双图自动展示');
        } else if (action === 'reset') {
          _resetCognitionMapsToStartNode();
          printSuccess('认知双图已重置到起点');
        } else {
          _renderTaskMindMap('live');
          printInfo(`自动展示: ${_taskMindMapAutoShow ? 'on' : 'off'}`);
        }
        showBusyInterjectPrompt();
        return;
      }

      // /interrupt (or /i) while busy: request cancellation and prioritize next input
      const interruptMatch = /^\/(?:interrupt|i)\s+([\s\S]+)$/i.exec(trimmed);
      if (interruptMatch) {
        const nextInput = interruptMatch[1].trim();
        if (!nextInput) {
          printInfo('用法: /interrupt <新输入> 或 /i <新输入>');
          return;
        }
        _queuedInputs.unshift(nextInput);
        const cancelled = _requestRelayCancel('Interrupted by /interrupt');
        if (cancelled) {
          console.log(c.dim('  ⚡ 已发送中断信号，完成后优先处理新输入'));
        } else {
          console.log(c.dim('  ⚡ 已记录中断请求，将在当前步骤结束后优先处理新输入'));
        }
        showBusyInterjectPrompt();
        return;
      }

      // ── 3 模式忙碌输入分流 (queue/steer/interrupt) ──────────────
      const classified = _classifyBusyInput(trimmed);
      if (classified.mode === 'steer') {
        _steerQueue.push(classified.text);
        const steerPreview = _summarizeQueuedInputForDisplay(classified.text, 40);
        console.log(c.hex('#D77757')(`  ⟳ 已注入方向修正: "${steerPreview}"`));
        console.log(c.dim(`    └ 将在 AI 下一轮工具调用前生效`));
        showBusyInterjectPrompt();
        return;
      } else if (classified.mode === 'interrupt') {
        _queuedInputs.unshift(classified.text);
        const cancelled = _requestRelayCancel('Interrupted by auto-detected interrupt');
        if (cancelled) {
          console.log(c.hex('#FF6B80')(`  ⚡ 已发送中断信号，完成后优先处理新输入`));
        } else {
          console.log(c.hex('#FF6B80')(`  ⚡ 已记录中断请求，将在当前步骤结束后优先处理新输入`));
        }
        showBusyInterjectPrompt();
        return;
      }
      // queue 模式：沿用 merge-aware 排队
      _busyQueueWithMerge(trimmed);
      return;
    }
    _busy = true;
    _busyHintShownAt = 0; // 重置 hint 计时，确保首次立即显示
    _startBusyPromptKeepalive();
    showBusyInterjectPrompt();

    // Suspend vim handler during command execution (raw mode conflicts)
    if (_vimHandler) try { _vimHandler.suspend(); } catch { /* ignore */ }

    // Save to history
    history.push(trimmed);

    // Parse and route the command
    const parsed = parseInput(trimmed);
    if (!parsed) {
      _busy = false;
      rl.prompt();
      return;
    }

    try {
      _featureCapabilityMap.markCommandParsed(parsed);
      const result = await route(parsed);
      _featureCapabilityMap.markRouteResult(result);

      // Restore stdin/readline after route handlers that may use inquirer internally.
      // Inquirer creates its own readline and may pause stdin, leaving our rl deaf.
      recoverReadlineInput();

      // Claude Code style: /clear clears screen + conversation history
      if (parsed.command === 'clear') {
        try { ai().clearHistory(); } catch {}
        if (_queryEngine) {
          try { _queryEngine.clearHistory(); } catch {}
        }
        // Reprint startup header after a hard screen reset.
        // Avoid router-level + frame-level double clear artifacts.
        try { leaveInputPromptFrame(); } catch {}
        try {
          if (process.stdout.isTTY) {
            readline.cursorTo(process.stdout, 0, 0);
            readline.clearScreenDown(process.stdout);
          } else {
            console.clear();
          }
        } catch { console.clear(); }
        _startupHeaderRendered = false;
        try { renderStartupHeader(true); } catch {}
      }

      if (result === 'exit') {
        const savedMeta = ai().saveConversation();
        saveHistory(history);
        setTerminalTitle(''); // restore terminal title
        console.log('');
        console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
        printResumeRecoveryHints(savedMeta);
        console.log('');
        _uninstallBusyPromptConsolePatch();
        _intentionalExit = true; process.exit(0);
      }

      if (result === 'menu') {
        let menuResult;
        do {
          menuResult = await menu().runMenuLoop();
          await executeMenuResult(menuResult);
        } while (menuResult !== null);
        rl.prompt();
        return;
      }

      if (result === 'ai-status') {
        await ai().handleAiStatus();
        rl.prompt();
        return;
      }

      if (result === 'ai-config') {
        await ai().handleAiConfig();
        rl.prompt();
        return;
      }

      if (result === 'ai-on' || result === 'ai-off') {
        // AI is always on — no manual toggle needed
        printInfo('AI 对话已默认开启，无需手动切换');
        rl.prompt();
        return;
      }

      if (result === true) {
        // Command was handled — track it
        if (parsed && parsed.command) userProfile().trackCommand(parsed.command);

        // Record command sequence for pattern learning
        if (parsed && parsed.command) {
          _recentCommands.push(trimmed);
          if (_recentCommands.length > PATTERN_WINDOW) _recentCommands.shift();

          // Record workflow step for habit optimization
          try {
            const { recordWorkflowStep, recordInteraction: recordHabit } = require('../services/usageHabitService');
            recordHabit(trimmed);
            if (_recentCommands.length >= 2) {
              recordWorkflowStep(_recentCommands.slice(-2));
            }
          } catch { /* best effort */ }

          // Check for patterns when we have enough commands
          if (_recentCommands.length >= 2) {
            try {
              const { recordCommandSequence } = require('../services/skillLearningService');
              const suggestion = recordCommandSequence(_recentCommands.slice(-3));
              if (suggestion && suggestion.suggest) {
                console.log('');
                console.log(c.hex('#FFC107')(`  Detected repeated operation pattern (${suggestion.count} times):`));
                console.log(c.dim(`     ${suggestion.sequence.join(' → ')}`));
                console.log(c.dim(`     输入 skill learn workflow "${suggestion.sequence.join(' → ')}" 自动化`));
                console.log('');
              }
            } catch { /* pattern learning is best-effort */ }
          }
        }

        rl.prompt();
        return;
      }

      // result.aiForward → a command generated a prompt for AI
      const aiInput = (result && result.aiForward) ? result.aiForward : trimmed;

      // Unrecognized command → auto-route to AI (always on)

      // result === false or aiForward → send to AI
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false, thinkingLineOpen: false, thinkingCol: 0, _textBuffer: '', _streamedTextLen: 0 };

      // G1/G2: 初始化 LineBuffer + AdaptiveChunker
      streamState._lineBuffer = new LineBuffer();
      streamState._chunker = new AdaptiveChunker(streamState._lineBuffer, (text) => {
        const trimmed = text.trim();
        if (trimmed) _renderTextBlock(trimmed);
      });

      // Update terminal title with user's topic immediately
      updateTitleFromConversation(aiInput);

      // Merge any queued /btw hints into the input
      let finalAiInput = aiInput;
      if (_btwQueue.length > 0) {
        const hints = _btwQueue.splice(0).join('\n');
        finalAiInput = `${aiInput}\n\n[附加提示]\n${hints}`;
      }

      // ── Resolve @path file mentions ──
      try {
        const atMentionRe = /@([\w./-]+[\w.])/g;
        const mentions = [];
        let atMatch;
        while ((atMatch = atMentionRe.exec(finalAiInput)) !== null) {
          mentions.push({ fullMatch: atMatch[0], relPath: atMatch[1], index: atMatch.index });
        }
        if (mentions.length > 0) {
          const cwd = process.env.KHYQUANT_CWD || process.cwd();
          const SENSITIVE_NAMES = new Set(['.env', '.pem', '.key', '.crt', '.pfx', '.p12',
            'id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa', 'credentials', 'secret',
            '.admin_initial_password', '.htpasswd', 'shadow', '.netrc', '.pgpass']);
          const SENSITIVE_EXTS = new Set(['.pem', '.key', '.crt', '.pfx', '.p12', '.jks', '.keystore']);
          const maxSize = 100 * 1024;
          const injections = [];

          for (const mention of mentions) {
            const resolvedPath = path.isAbsolute(mention.relPath)
              ? mention.relPath
              : path.resolve(cwd, mention.relPath);
            const basename = path.basename(resolvedPath).toLowerCase();
            const ext = path.extname(resolvedPath).toLowerCase();
            if (SENSITIVE_NAMES.has(basename) || SENSITIVE_EXTS.has(ext)) {
              printInfo(`Security: blocked reading sensitive file via @mention: ${basename}`);
              continue;
            }
            try {
              const stat = fs.statSync(resolvedPath);
              if (stat.isFile()) {
                const content = fs.readFileSync(resolvedPath, 'utf-8').slice(0, maxSize);
                const sizeInfo = stat.size > maxSize
                  ? `first 100KB of ${(stat.size / 1024).toFixed(0)}KB`
                  : `${(stat.size / 1024).toFixed(1)}KB`;
                const renderer = require('./aiRenderer');
                renderer.printStepLine('success', 'Read', mention.relPath, sizeInfo);
                injections.push({
                  match: mention.fullMatch,
                  block: `[File: ${mention.relPath}]\n\`\`\`\n${content}\n\`\`\``,
                });
              } else if (stat.isDirectory()) {
                const tree = _buildDirTree(resolvedPath, { maxDepth: 3, maxFiles: 80 });
                const renderer = require('./aiRenderer');
                renderer.printStepLine('success', 'Read', mention.relPath + '/', `${tree.fileCount} files`);
                injections.push({
                  match: mention.fullMatch,
                  block: `[Directory: ${mention.relPath}]\n${tree.text}`,
                });
              }
            } catch { /* file doesn't exist — could be email/social handle, skip */ }
          }

          if (injections.length > 0) {
            let cleanedInput = finalAiInput;
            for (const inj of injections) {
              cleanedInput = cleanedInput.replace(inj.match, inj.match.slice(1));
            }
            const contentBlocks = injections.map(inj => inj.block).join('\n\n');
            finalAiInput = `${cleanedInput}\n\n${contentBlocks}`;
          }
        }
      } catch { /* @mention resolution is best-effort */ }

      // Detect inline image paths (file:///...png, /path/to/img.jpg, etc.)
      // If found, extract image and send via vision API instead of text-only chat.
      let _inlineImageOpts = null;
      try {
        const _imgIntent = extractInlineImageIntent(finalAiInput, buildImageSceneHint(finalAiInput, history));
        if (_imgIntent) {
          const imageService = require('../services/imageService');
          const image = imageService.readImageFromFile(_imgIntent.filePath);
          _inlineImageOpts = {
            images: [{ base64: image.base64, mimeType: image.mimeType }],
          };
          finalAiInput = _imgIntent.prompt || '请分析这张图片的内容';
          const renderer = require('./aiRenderer');
          renderer.printStepLine('success', 'Read', _imgIntent.filePath,
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`);
          imageService.printImagePreview(image);
        }
      } catch (imgErr) {
        printInfo(`图片读取失败: ${imgErr.message}，将作为文本发送`);
      }

      // Detect file paths in input (drag-and-drop support)
      // Strips quotes, resolves paths. Supports files, directories, and archives.
      try {
        const fileExts = /\.(txt|js|jsx|ts|tsx|mjs|cjs|py|json|csv|md|log|yaml|yml|toml|html|css|scss|less|vue|sql|sh|bat|ps1|xml|ini|cfg|conf|java|go|rs|c|cpp|h|hpp|rb|php|swift|kt|dart|r|lua|pl|ex|exs|zig|proto|graphql)$/i;
        const archiveExts = /\.(zip|tar|tar\.gz|tgz|gz|bz2|xz)$/i;
        // Strip outer quotes, normalize path separators for Windows
        const stripped = path.normalize(
          finalAiInput.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ')
        );
        let pathCandidate;
        if (/^[A-Za-z]:[\\/]/.test(stripped)) {
          // Windows drive-letter path — match greedily up to known extension
          const extMatch = stripped.match(/^(.+?\.(?:txt|js|jsx|ts|tsx|mjs|cjs|py|json|csv|md|log|yaml|yml|toml|html|css|scss|less|vue|sql|sh|bat|ps1|xml|ini|cfg|conf|java|go|rs|c|cpp|h|hpp|rb|php|swift|kt|dart|r|lua|pl|ex|exs|zig|proto|graphql|zip|tar\.gz|tgz|tar|gz|bz2|xz|gguf|safetensors))\b/i);
          pathCandidate = extMatch ? extMatch[1] : stripped.split(/\s+/)[0];
        } else {
          // Try greedy extension match first (handles paths with spaces escaped by shell)
          const extMatch = stripped.match(/^(.+?\.(?:txt|js|jsx|ts|tsx|mjs|cjs|py|json|csv|md|log|yaml|yml|toml|html|css|scss|less|vue|sql|sh|bat|ps1|xml|ini|cfg|conf|java|go|rs|c|cpp|h|hpp|rb|php|swift|kt|dart|r|lua|pl|ex|exs|zig|proto|graphql|zip|tar\.gz|tgz|tar|gz|bz2|xz|gguf|safetensors))\b/i);
          pathCandidate = extMatch ? extMatch[1] : stripped.split(/\s+/)[0];
        }
        // WSL: convert Windows paths (C:\Users\...) to /mnt/c/Users/...
        if (/^[A-Za-z]:[\\/]/.test(pathCandidate) && process.platform === 'linux') {
          const drive = pathCandidate[0].toLowerCase();
          if (fs.existsSync(`/mnt/${drive}`) || fs.existsSync('/mnt/c')) {
            pathCandidate = `/mnt/${drive}/${pathCandidate.slice(3).replace(/\\/g, '/')}`;
          }
        }
        const BLOCKED_NAMES = ['.env', '.pem', '.key', '.crt', '.pfx', '.p12', 'id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa', 'credentials', 'secret', 'token', '.admin_initial_password', '.htpasswd', 'shadow', '.netrc', '.pgpass'];
        const BLOCKED_EXTS = ['.pem', '.key', '.crt', '.pfx', '.p12', '.jks', '.keystore'];
        const resolvedPath = path.isAbsolute(pathCandidate) ? pathCandidate : path.resolve(process.env.KHYQUANT_CWD || process.cwd(), pathCandidate);
        const basename = path.basename(resolvedPath).toLowerCase();
        const ext = path.extname(resolvedPath).toLowerCase();
        const isBlocked = BLOCKED_NAMES.some(b => basename === b || basename.startsWith(b + '.') || basename.endsWith(b)) || BLOCKED_EXTS.includes(ext);
        if (isBlocked) {
          printInfo(`Security: blocked reading sensitive file: ${basename}`);
        } else if ((() => {
          // Model path detection: ZIP/dir/.gguf that looks like a model file
          try {
            const { looksLikeModelPath } = require('../services/modelImportService');
            return looksLikeModelPath(resolvedPath);
          } catch { return false; }
        })()) {
          // Detected model file — ask user before importing
          const stat = fs.existsSync(resolvedPath) ? fs.statSync(resolvedPath) : null;
          const sizeStr = stat ? `${(stat.size / 1024 / 1024).toFixed(0)} MB` : '';
          const isDir = stat && stat.isDirectory();
          const typeStr = isDir ? '模型目录' : /\.gguf$/i.test(resolvedPath) ? 'GGUF 模型' : '模型压缩包';
          printInfo(`检测到${typeStr}: ${path.basename(resolvedPath)}${sizeStr ? ` (${sizeStr})` : ''}`);
          const answer = await new Promise(res => {
            rl.question(c.yellow('  是否导入并加载该模型? [Y/n] '), ans => res(ans.trim()));
          });
          if (!answer || /^y(es)?$/i.test(answer)) {
            printInfo('正在导入模型...');
            try {
              const modelImport = require('../services/modelImportService');
              const result = await modelImport.importModel(resolvedPath);
              if (result.success) {
                printSuccess(`模型导入成功: ${result.model || result.modelPath || ''}`);
                if (result.steps) result.steps.forEach(s => printInfo(`  ${s}`));
                // Auto-reload localLLMService
                try {
                  const llm = require('../services/localLLMService');
                  if (llm.dispose) llm.dispose();
                  if (llm.ensureLoaded) await llm.ensureLoaded();
                  printSuccess('本地模型已重新加载');
                } catch (loadErr) {
                  printWarn(`模型加载失败: ${loadErr.message}`);
                }
              } else {
                printError(`模型导入失败: ${result.error}`);
              }
            } catch (impErr) {
              printError(`导入出错: ${impErr.message}`);
            }
            _busy = false;
            rl.prompt();
            return;
          } else {
            printInfo('已跳过模型导入，作为普通文件处理');
            // Fall through to normal file/archive handling below
          }
        } else if (archiveExts.test(pathCandidate) && fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
          const stat = fs.statSync(resolvedPath);
          const sizeInfo = `${(stat.size / 1024).toFixed(1)} KB`;
          printInfo(`检测到压缩文件: ${path.basename(resolvedPath)} (${sizeInfo})`);
          const followUp = finalAiInput.slice(pathCandidate.length).trim();
          finalAiInput = `[压缩文件: ${path.basename(resolvedPath)}] (${sizeInfo})\n路径: ${resolvedPath}\n\n${followUp || '请帮我解压这个文件'}`;
        } else if (fileExts.test(pathCandidate) && fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
          const stat = fs.statSync(resolvedPath);
          const maxSize = 100 * 1024;
          const content = fs.readFileSync(resolvedPath, 'utf-8').slice(0, maxSize);
          const sizeInfo = stat.size > maxSize ? `截取前 100KB / 总 ${(stat.size / 1024).toFixed(0)}KB` : `${(stat.size / 1024).toFixed(1)} KB`;
          printInfo(`已读取文件: ${path.basename(resolvedPath)} (${sizeInfo})`);
          const followUp = finalAiInput.slice(pathCandidate.length).trim();
          const prompt = followUp || '请分析这个文件的内容';
          finalAiInput = `[文件内容: ${path.basename(resolvedPath)}]\n\`\`\`\n${content}\n\`\`\`\n\n${prompt}`;
        } else if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isDirectory()) {
          // Directory drag-and-drop: list project structure
          const tree = _buildDirTree(resolvedPath, { maxDepth: 3, maxFiles: 80 });
          printInfo(`已读取目录结构: ${path.basename(resolvedPath)} (${tree.fileCount} 个文件)`);
          const followUp = finalAiInput.slice(pathCandidate.length).trim();
          finalAiInput = `[项目结构: ${path.basename(resolvedPath)}]\n${tree.text}\n\n${followUp || '请分析这个项目的结构'}`;
        }
      } catch { /* file detection is best-effort, ignore errors */ }

      // Expand any residual [Pasted text #N] tags into actual pasted content.
      // This handles cases where paste tags survive into the AI input due to
      // timing races (e.g., busy-queue consuming the tag before _pendingPaste
      // expansion, or non-bracketed-paste terminals on Windows).
      finalAiInput = _expandPasteTags(finalAiInput);

      // Check for multi-agent trigger
      const agentRunner = require('../services/cliAgentRunner');
      if (agentRunner.shouldUseMultiAgent(finalAiInput)) {
        _currentOp = '多智能体协作';
        _requestStart = Date.now();
        const agentDisplay = require('./agentRenderer');
        const renderer = require('./aiRenderer');

        // Decompose task into sub-tasks
        const subtasks = agentRunner.decomposeTask(finalAiInput);
        let renderedLines = 0;

        // Show initial agent display
        renderedLines = agentDisplay.renderAgentDisplay(subtasks.map(st => ({
          name: st.name, status: 'pending', toolCalls: 0, tokens: 0, elapsed: 0, detail: '',
        })));

        // Run agents with progress updates
        const agentResults = await agentRunner.runAgents(subtasks, {
          ai: ai(),
          onProgress: (states) => {
            renderedLines = agentDisplay.rerenderAgentDisplay(states, renderedLines);
          },
        });

        // Show final state
        agentDisplay.rerenderAgentDisplay(agentResults, renderedLines, true);
        agentDisplay.renderAgentSummary(agentResults);

        // Synthesize results
        renderer.printToolCallStart('Synthesize', '综合分析');
        const synthStart = Date.now();
        const synthesized = await agentRunner.synthesizeResults(agentResults, finalAiInput, ai());
        renderer.printToolCallResult('Synthesize', '综合分析', 'success', '合成完成', Date.now() - synthStart);

        // Display synthesized result
        agentDisplay.renderSynthesisResult(synthesized, agentResults);
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Check for plan mode trigger
      const planService = require('../services/planModeService');
      if (looksLikeUiEchoInput(aiInput)) {
        printInfo('检测到界面状态文本，已忽略该输入');
        return;
      }
      let needsPlan = false;
      const bypassPlan = shouldBypassPlanMode(aiInput);
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        needsPlan = bypassPlan ? false : (pp.needsPlan || _planMode);
      } catch { /* best effort */ }

      if (bypassPlan && _planMode) _planMode = false;
      if (bypassPlan) {
        printInfo('Skipping plan mode, executing directly');
      }

      if (needsPlan || _planMode) {
        const renderer = require('./aiRenderer');
        _planMode = false; // Reset after use
        _currentOp = 'Planning';
        _requestStart = Date.now();

        // Step 1: Generate plan
        renderer.printStepLine('active', 'Plan mode', 'generating plan...');
        const { plan, rawResponse, provider, elapsed, errorType } = await planService.enterPlanMode(finalAiInput, ai());

        if (plan && plan.steps.length > 0) {
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[1A\r\x1b[K');
          }
          renderer.printStepLine('success', 'Plan mode', `generated ${plan.steps.length}-step plan`);

          // Step 2: Present for approval
          const approval = await planService.presentForApproval(plan, renderer, rl);

          if (approval.approved) {
            // Step 3: Execute step by step
            console.log('');
            renderer.printStepLine('active', '执行计划', `${plan.steps.filter(s => s.status !== 'skipped').length} 步骤`);

            const results = await planService.executePlanSteps(plan, {
              ai: ai(),
              renderer,
              rl,
              route,
              parseInput,
              onStepResult: ({ step, result }) => {
                const attempts = Number(result?._planAttempts || 0);
                if (step.status === 'error') {
                  const reason = String(result?.error || '未知错误');
                  renderer.printStepLine('error', `步骤 ${step.id}`, '失败', reason);
                } else {
                  renderer.printStepLine('success', `步骤 ${step.id}`, `完成${attempts > 1 ? `（${attempts} 次尝试）` : ''}`);
                }
                if (result.reply) {
                  console.log(c.dim(`  ${step.description}`));
                  const rendered = renderer.renderAiResponse(result.reply);
                  rendered.split('\n').forEach(l => console.log(`  ${l}`));
                } else if (step.status === 'error' && result?.error) {
                  console.log(c.red(`  ${String(result.error)}`));
                }
              },
            });

            if (process.stdout.isTTY) {
              process.stdout.write('\x1b[1A\r\x1b[K');
            }
            renderer.printStepLine('success', '计划执行完成', `${results.filter(r => r.step.status === 'completed').length}/${results.length} 成功`);
            renderer.renderAgentDone({
              toolCalls: results.length,
              elapsedMs: elapsed,
            });
          } else {
            printInfo('Plan cancelled');
          }
        } else {
          // Plan generation failed — fall through to normal AI
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[1A\r\x1b[K');
          }
          renderer.printStepLine('error', 'Plan mode', errorType || '', 'plan generation failed');
          if (rawResponse) {
            const renderer2 = require('./aiRenderer');
            const rendered = renderer2.renderAiResponse(rawResponse);
            rendered.split('\n').forEach(l => console.log(`  ${l}`));
          } else {
            printError('计划模式生成失败，且未返回具体错误信息');
          }
        }
        planService.reset();
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Load AI renderer for rich output
      const renderer = require('./aiRenderer');
      bindInteractiveInputGuard(renderer);
      const spinner = new renderer.DynamicSpinner();
      const tracker = new renderer.ProcessTracker();
      if (_inputFrameEnabled && typeof spinner.setPromptMode === 'function') {
        spinner.setPromptMode('framed', {
          ruleColor: '#D77757',
          footer: c.hex('#FFFFFF').dim('(shift+tab to cycle)'),
        });
      }

      // Claude Code style: no intent analysis step — go straight to AI

      // Step 1: Preprocessing — detect complexity for display
      let complexTask = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        complexTask = pp.needsPlan;
      } catch { /* best effort */ }

      if (complexTask) {
        tracker.start('Analyzing', aiInput.slice(0, 40), 'complex task detected');
        tracker.complete('AI will plan first');
      }

      // Step 2: AI request — Claude Code style: rich spinner with effort/tokens
      _currentOp = 'Requesting AI';
      _requestStart = Date.now();

      // Get current effort level for spinner display
      try {
        const aiModule = require('./ai');
        const effort = typeof aiModule.getEffort === 'function' ? aiModule.getEffort() : 'high';
        spinner.setEffort(effort);
      } catch { /* best effort */ }

      let _streamTokenCount = 0;
      const streamedToolNames = new Map(); // tool_use_id -> tool name
      const streamedTaskStatus = new Map(); // task_id -> latest status
      let _lastRuntimeStatusSig = '';

      // 统一的 status 输出 + prompt 重绘：
      // spinner._render 被 isRaw 拦截永远不执行，所以 spinner.start() 后
      // 唯一能画输入框的是 showBusyInterjectPrompt()。
      // 直接在每次输出后同步调用，不依赖 console.log patch 的间接触发。
      function _printStatusAndRepaint(status, label, target, detail) {
        spinner.stop();
        renderer.printStepLine(status, label, target, detail);
        spinner.start('request');
        showBusyInterjectPrompt();
      }

      const emitRuntimeStatus = (text = '') => {
        const msg = String(text || '').trim();
        if (!msg) return;
        const sig = `status:${msg}`;
        if (sig === _lastRuntimeStatusSig) return;
        _lastRuntimeStatusSig = sig;

        // Classify status messages for rich display
        const lower = msg.toLowerCase();
        if (lower.includes('重试') || lower.includes('retry')) {
          // Retry — prominent warning
          _printStatusAndRepaint('error', 'Retry', '', msg);
        } else if (lower.includes('responded') || lower.includes('成功')) {
          // Success — green checkmark
          spinner.stop();
          renderer.printStepLine('success', 'Connected', '', msg);
          showBusyInterjectPrompt();
        } else if (lower.includes('failed') || lower.includes('error') || lower.includes('异常') || lower.includes('失败')) {
          // Failure — red dot
          _printStatusAndRepaint('error', 'Error', '', msg);
        } else if (lower.includes('尝试通道') || lower.includes('switching') || lower.includes('首选通道') || lower.includes('preferred')) {
          // Adapter selection — active indicator
          _printStatusAndRepaint('active', 'Adapter', '', msg);
        } else if (lower.includes('探测') || lower.includes('probe') || lower.includes('检测')) {
          // Probing — detail line
          spinner.setPhase('request', msg);
        } else if (lower.includes('任务模式') || lower.includes('task mode')) {
          // Task mode — just update spinner detail
          spinner.setPhase('request', msg);
        } else {
          // General status — update spinner detail text
          spinner.setPhase(spinner._phase || 'request', msg);
        }
      };

      const handleControlRequest = async ({ request, requestId }) => {
        const subtype = String(request?.subtype || '').trim().toLowerCase();
        if (subtype !== 'can_use_tool') {
          return { subtype: 'success', response: {} };
        }

        const toolName = String(request?.tool_name || request?.tool || 'tool');
        const normalizedTool = toolName.toLowerCase().replace(/[\s_-]/g, '');
        const input = (request && typeof request.input === 'object' && request.input) ? request.input : {};

        spinner.stop();
        try {
          if (normalizedTool === 'askuserquestion') {
            const questions = Array.isArray(input.questions) ? input.questions : [];
            const answers = {};

            for (const q of questions.slice(0, 4)) {
              const questionText = String(q?.question || '').trim() || 'Please choose an option';
              const qOptions = Array.isArray(q?.options) ? q.options : [];
              const renderedOptions = qOptions
                .map(opt => ({
                  label: String(opt?.label || '').trim(),
                  description: String(opt?.description || '').trim(),
                }))
                .filter(opt => opt.label);

              if (renderedOptions.length === 0) continue;

              const selection = await renderer.askInlineQuestion(questionText, renderedOptions, {
                multiSelect: !!q?.multiSelect,
                rl,
              });

              if (selection === null || selection === undefined) {
                return {
                  subtype: 'success',
                  response: {
                    behavior: 'deny',
                    message: 'User declined to answer questions',
                  },
                };
              }

              answers[questionText] = Array.isArray(selection)
                ? selection.join(', ')
                : String(selection);
            }

            return {
              subtype: 'success',
              response: {
                behavior: 'allow',
                updatedInput: { ...input, answers },
              },
            };
          }

          const permissionChoice = await renderer.askInlineQuestion(
            `Allow ${toolName}?`,
            [
              { label: 'Allow', description: 'Approve this tool call once' },
              { label: 'Deny', description: 'Reject this tool call' },
            ],
            { rl },
          );

          if (permissionChoice === 'Allow') {
            return { subtype: 'success', response: { behavior: 'allow' } };
          }
          return {
            subtype: 'success',
            response: {
              behavior: 'deny',
              message: 'Permission denied',
            },
          };
        } finally {
          spinner.start('request');
        }
      };

      let _timerResetDone = false;
      const onChunk = (chunk) => {
          // Reset spinner timer on the first received SSE event
          if (!_timerResetDone) {
            _timerResetDone = true;
            if (spinner && typeof spinner.resetTimer === 'function') spinner.resetTimer();
          }
          if (chunk.type === 'thinking') {
            spinner.stop();
            _busyStreaming = true;
            _currentOp = 'Thinking';
            updateTitlePhase('thinking');
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState._thinkingStartAt = Date.now();
            streamState.phase = 'thinking';
              console.log('');
              console.log(c.dim(`  💭 思考中...`));
            }
            streamThinkingChunk(chunk.text, streamState, c);
          } else if (chunk.type === 'tool_use') {
            if (streamState.phase === 'thinking') {
              closeThinkingStream(streamState);
              console.log('');
              streamState.phase = 'tool';
            }
            // Flush buffered text with markdown formatting before tool output
            flushTextBuffer(streamState, c);
            spinner.stop();
            _currentOp = 'Tool use';
            updateTitlePhase('tool', chunk.tool || 'Tool');
            if (chunk.id) streamedToolNames.set(String(chunk.id), chunk.tool || 'tool');
            // Always show tool_use events from adapter streaming (Codex CLI, Claude, etc.)
            {
              const toolLabel = chunk.tool || 'tool';
              const inputHint = typeof chunk.input === 'string' ? chunk.input.slice(0, 80) : '';
              renderer.printToolCallStart(toolLabel, inputHint);
              if (_taskMindMap) {
                _taskMindMap.markToolCall(toolLabel, { command: inputHint });
                if (_taskMindMapAutoShow) {
                  _printTaskMindMapCompact('Mind map · tool call');
                }
              }
              _featureCapabilityMap.markToolCall(toolLabel, { command: inputHint });
              if (_taskMindMapAutoShow) {
                _printFeatureCapabilityCompact('Feature map · tool call');
              }
            }
          } else if (chunk.type === 'tool_result') {
            // Always show tool_result events from adapter streaming
            if (chunk.content) {
              const brief = String(chunk.content).replace(/\n/g, ' ').slice(0, 80);
              const toolLabel = streamedToolNames.get(String(chunk.id || '')) || 'tool';
              const ok = !String(chunk.content).toLowerCase().includes('error');
              renderer.printStepLine(ok ? 'success' : 'error', toolLabel, '', brief);
              if (_taskMindMap) {
                _taskMindMap.markToolResult(toolLabel, ok, brief);
                if (_taskMindMapAutoShow) {
                  _printTaskMindMapCompact('Mind map · tool result');
                }
              }
              _featureCapabilityMap.markToolResult(toolLabel, ok, brief);
              if (_taskMindMapAutoShow) {
                _printFeatureCapabilityCompact('Feature map · tool result');
              }
            }
            if (chunk.id) streamedToolNames.delete(String(chunk.id));
          } else if (chunk.type === 'tool_complete') {
            // Rich tool completion from adapter — render file diffs
            maybeRenderWriteDiff(chunk.name, chunk.params || {}, chunk.result || {}, c);
            maybeRenderInlineDiffFromToolOutput(chunk.name, chunk.result || {}, c);
          } else if (chunk.type === 'tool_progress') {
            spinner.stop();
            const toolName = chunk.tool || streamedToolNames.get(String(chunk.id || '')) || 'tool';
            const status = String(chunk.status || '').toLowerCase();
            const detail = String(chunk.detail || '').trim();
            if (status.includes('fail') || status.includes('error')) {
              renderer.printStepLine('error', toolName, '', detail || 'failed');
            } else if (status.includes('complete') || status.includes('success') || status === 'done') {
              renderer.printStepLine('success', toolName, '', detail || 'completed');
              if (chunk.id) streamedToolNames.delete(String(chunk.id));
            } else {
              renderer.printStepLine('active', toolName, '', detail || 'running');
            }
          } else if (chunk.type === 'task_started') {
            spinner.stop();
            const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
            streamedTaskStatus.set(taskId, 'running');
            renderer.printStepLine('active', 'Task started', taskId, String(chunk.summary || '').trim());
          } else if (chunk.type === 'task_progress') {
            spinner.stop();
            const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
            renderer.printStepLine('active', 'Task progress', taskId, String(chunk.summary || chunk.status || 'in progress').trim());
          } else if (chunk.type === 'task_notification') {
            spinner.stop();
            const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
            const status = String(chunk.status || '').toLowerCase();
            const ok = status === 'completed' || status === 'success';
            renderer.printStepLine(ok ? 'success' : 'error', 'Task finished', taskId, String(chunk.summary || status || 'done').trim());
            streamedTaskStatus.delete(taskId);
          } else if (chunk.type === 'auth_status') {
            spinner.stop();
            if (chunk.error) {
              renderer.printStepLine('error', 'Auth', '', String(chunk.error));
            } else if (chunk.isAuthenticating) {
              renderer.printStepLine('active', 'Auth', '', String(chunk.output || 'authenticating...'));
            } else if (chunk.output) {
              emitRuntimeStatus(`Auth: ${String(chunk.output)}`);
            }
          } else if (chunk.type === 'status') {
          emitRuntimeStatus(chunk.text || 'status update');
          } else if (chunk.type === 'control_request') {
            spinner.stop();
            const req = chunk.request || {};
            const reqSubtype = String(req.subtype || '').trim() || 'control';
            const reqTool = String(req.tool_name || req.tool || '').trim();
            if (reqSubtype === 'can_use_tool') {
              renderer.printStepLine('active', 'Permission', reqTool || 'tool', `request ${chunk.requestId || ''}`.trim());
            } else {
              renderer.printStepLine('active', 'Control request', reqSubtype, `request ${chunk.requestId || ''}`.trim());
            }
          } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            closeThinkingStream(streamState);
            console.log('');
            streamState.phase = 'text';
            spinner.setPhase('generating');
          }
          // Close any prior tool phase so text appears on a fresh line
          if (streamState.phase === 'tool') {
            streamState.phase = 'text';
          }
          // Track output tokens approximately
          if (chunk.text) {
            _streamTokenCount += Math.ceil(chunk.text.length / 4);
            spinner.setTokens(_streamTokenCount, 'output');
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            _busyStreaming = true;
            _currentOp = 'Generating';
            updateTitlePhase('generating');
            spinner.stop();
          }
          // Buffer text for formatted rendering when tool call arrives
          if (chunk.text) {
            spinner.stop();
            bufferTextChunk(chunk.text, streamState);
            streamState._streamedTextLen = (streamState._streamedTextLen || 0) + chunk.text.length;
          }
        } else if (chunk.type === 'cost') {
          streamState.cost = chunk.cost;
          if (chunk.cost?.totalTokens) _sessionTokens = chunk.cost.totalTokens;
          // Update spinner with real token counts
          if (chunk.cost?.inputTokens) spinner.setTokens(chunk.cost.inputTokens, 'input');
          if (chunk.cost?.outputTokens) spinner.setTokens(chunk.cost.outputTokens, 'output');
        }
      };

      // Start dynamic spinner
      spinner.start('request');

      let aiResult;
      let responseAlreadyRendered = false;
      let _lastMindMapSteerPayload = '';
      let _lastFeatureMapSteerPayload = '';

      _initTaskMindMap(aiInput, finalAiInput);
      _featureCapabilityMap.markAiTask(finalAiInput, true);
      if (_taskMindMapAutoShow) {
        _renderTaskMindMap('start');
      } else {
        _printFeatureCapabilityCompact('Feature map initialized');
        _printTaskMindMapCompact('Mind map initialized');
      }

      // ── QueryEngine path (KHY_QUERY_ENGINE=true) ────────────────
      let _useQueryEngine = false;
      try { _useQueryEngine = require('../services/queryEngine').isEnabled(); } catch {}

      if (_useQueryEngine) {
        try {
          const { QueryEngine } = require('../services/queryEngine');
          if (!_queryEngine) _queryEngine = new QueryEngine();
          for await (const event of _queryEngine.submitMessage(finalAiInput, {
            effort: ai().getEffort(),
          })) {
            switch (event.type) {
              case 'thinking':
                onChunk({ type: 'thinking', text: event.data });
                break;
              case 'text':
                onChunk({ type: 'text', text: event.data });
                break;
              case 'tool_call':
                spinner.stop();
                {
                  const toolName = event.data.name;
                  const activity = _toolProgressStart(toolName, event.data.params || {});
                  if (activity) {
                    renderer.printStepLine('active', activity.label, activity.target || '');
                  }
                  // Claude Code style: ⏺ ToolName(params)
                  renderer.printToolCallStart(toolName, event.data.params || {});
                  if (_taskMindMap) {
                    _taskMindMap.markToolCall(toolName, event.data.params || {});
                    if (_taskMindMapAutoShow) {
                      _printTaskMindMapCompact('Mind map · tool call');
                    }
                  }
                  _featureCapabilityMap.markToolCall(toolName, event.data.params || {});
                  if (_taskMindMapAutoShow) {
                    _printFeatureCapabilityCompact('Feature map · tool call');
                  }
                }
                spinner.start('tool');
                break;
              case 'tool_result': {
                spinner.stop();
                const ok = event.data.status ? event.data.status === 'success' : !!event.data.result?.success;
                const toolName = event.data.name;
                let progressDetail = '';
                if (ok) {
                  const detail = _formatToolResult(toolName, event.data.result || {});
                  progressDetail = detail;
                  renderer.printToolCallResult(toolName, event.data.params || {}, 'success', detail, event.data.elapsed || 0);
                } else {
                  const rawErr = event.data.result?.error || event.data.result || 'failed';
                  const errStr = (rawErr && typeof rawErr === 'object')
                    ? (rawErr.message || JSON.stringify(rawErr))
                    : String(rawErr);
                  progressDetail = String(errStr).slice(0, 120);
                  renderer.printToolCallResult(toolName, event.data.params || {}, 'error', progressDetail, event.data.elapsed || 0);
                }
                const progressDone = _toolProgressDone(toolName, ok, progressDetail);
                if (progressDone) {
                  renderer.printStepLine(progressDone.status, progressDone.label, '', progressDone.detail || '');
                }
                if (_taskMindMap) {
                  _taskMindMap.markToolResult(toolName, ok, progressDetail);
                  if (_taskMindMapAutoShow) {
                    _printTaskMindMapCompact('Mind map · tool result');
                  }
                }
                _featureCapabilityMap.markToolResult(toolName, ok, progressDetail);
                if (_taskMindMapAutoShow) {
                  _printFeatureCapabilityCompact('Feature map · tool result');
                }
                maybeRenderWriteDiff(event.data.name, event.data.params || {}, event.data.result, c);
                maybeRenderInlineDiffFromToolOutput(event.data.name, event.data.result, c);
                break;
              }
              case 'cost':
                if (event.data?.totalTokens) _sessionTokens += event.data.totalTokens;
                break;
              case 'done':
                aiResult = event.data;
                if (_taskMindMap) {
                  const success = !event.data?.errorType;
                  _taskMindMap.complete({ success, reason: success ? '' : String(event.data?.errorType || 'query engine error') });
                  if (_taskMindMapAutoShow || !success) {
                    _renderTaskMindMap(success ? 'completed' : 'incomplete');
                  } else {
                    _printTaskMindMapCompact('Mind map finalized');
                  }
                }
                _featureCapabilityMap.markAiCompletion(!event.data?.errorType, String(event.data?.errorType || 'query engine done'));
                if (_taskMindMapAutoShow || event.data?.errorType) {
                  _printFeatureCapabilityCompact('Feature map finalized');
                }
                break;
            }
          }
          spinner.stop();
        } catch (qeErr) {
          spinner.stop();
          // Fall through to legacy path on QueryEngine error
          _useQueryEngine = false;
          console.log(c.hex('#FFC107')(`  QueryEngine error: ${qeErr.message} — falling back to legacy`));
        }
      }

      if (!_useQueryEngine) {
        // ── Tool-use loop path (execution-first) ─────────────────────
        const toolUseLoop = require('../services/toolUseLoop');
        const loopManaged = toolUseLoop.isEnabled();
        _featureCapabilityMap.markAiTask(finalAiInput, loopManaged);
        if (!_taskMindMapAutoShow) {
          _printFeatureCapabilityCompact('Feature map updated');
        }
        // Claude Code: no busy-mode hint text
        showBusyInterjectPrompt();

        const chatFn = async (message, opts = {}) => {
          // Reset streaming state for each iteration
          _busyStreaming = false; // 上一轮流式输出已结束，重置
          streamState = { phase: 'idle', thinkingStarted: false, textStarted: false, thinkingLineOpen: false, thinkingCol: 0, _textBuffer: '', _streamedTextLen: 0, _inToolLoop: true };
          let _lastStatusLine = '';
          let _lastStatusLineAt = 0;
          let _lastStatusText = '';
          let _lastStatusTextAt = 0;
          let _liveStatusOpen = false;
          let _liveStatusKey = '';
          let _lastStatusNormKey = '';
          let _lastStatusNormAt = 0;
          let _lastStatusNormCount = 0;
          const _statusVerbosityPref = String(process.env.KHY_STATUS_VERBOSITY || 'auto').trim().toLowerCase();
          let _statusVerbosity = 'normal';
          let _lowValueRepeatGate = 3;
          let _toolProgressSuccessCount = 0;
          let _suppressedLowValueStatusCount = 0;
          let _suppressedToolProgressSuccessCount = 0;
          let _suppressedExactDedupCount = 0;
          let _suppressedStartWindowCount = 0;
          const _statusEscalateOnErrorEnabled = (() => {
            const raw = String(process.env.KHY_STATUS_ESCALATE_ON_ERROR || 'true').trim().toLowerCase();
            return !['0', 'false', 'off', 'no'].includes(raw);
          })();
          let _statusEscalatedToDetailed = false;
          let _statusFirstAt = 0;
          const _statusStartSilentMs = (() => {
            const raw = String(process.env.KHY_STATUS_START_SILENT_MS || '2000').trim();
            const parsed = Number.parseInt(raw, 10);
            if (!Number.isFinite(parsed)) return 2000;
            return Math.max(0, Math.min(10000, parsed));
          })();
          const _briefToolProgressEvery = (() => {
            const raw = String(process.env.KHY_BRIEF_TOOL_PROGRESS_EVERY || '4').trim();
            const parsed = Number.parseInt(raw, 10);
            if (!Number.isFinite(parsed)) return 4;
            return Math.max(2, Math.min(12, parsed));
          })();
          const _statusBriefInputLen = (() => {
            const raw = String(process.env.KHY_STATUS_BRIEF_INPUT_LEN || '220').trim();
            const parsed = Number.parseInt(raw, 10);
            if (!Number.isFinite(parsed)) return 220;
            return Math.max(80, Math.min(1200, parsed));
          })();
          const _statusDedupMs = (() => {
            const raw = process.env.KHY_AI_STATUS_DEDUP_MS || process.env.GATEWAY_STATUS_DEDUP_MS || '1500';
            const parsed = Number.parseInt(String(raw).trim(), 10);
            if (!Number.isFinite(parsed) || parsed < 200) return 1500;
            return parsed;
          })();
          const _normalizeProgressKey = (phase, text) => {
            const normalized = String(text || '')
              .replace(/（\d+s）/g, '(Xs)')
              .replace(/\b\d+s\b/g, 'Xs')
              .replace(/\.{3}\s*\d+s/gi, '... Xs')
              .trim();
            return `${phase}:${normalized}`;
          };
          const _normalizeStatusDedupKey = (phase, text) => {
            const normalized = String(text || '')
              .toLowerCase()
              .replace(/\d+(\.\d+)?s\b/g, 'Xs')
              .replace(/\b\d+ms\b/g, 'Xms')
              .replace(/约\s*\d+\s*s/g, '约 Xs')
              .replace(/cooldown\s*\d+\s*s/gi, 'cooldown Xs')
              .replace(/（[^）]*\d+s[^）]*）/g, '(X)')
              .replace(/(首选通道|预检首选通道|尝试通道|adapter)\s*[:：]\s*[^\s，,；;]+/gi, '$1:*')
              .replace(/\s+/g, ' ')
              .trim();
            return `${phase}:${normalized}`;
          };
          const _isFailureMetricOnlyStatus = (text) => {
            const raw = String(text || '').trim();
            if (!raw) return false;
            if (!/(失败|failed|error|异常)/i.test(raw)) return false;
            if (/失败率\s*0\s*%/.test(raw)) return true;
            if (/失败\s*0\s*\/\s*\d+/.test(raw)) return true;
            if (/首包\s*P50\/P95/i.test(raw) && /失败\s*\d+\s*\/\s*\d+/.test(raw)) return true;
            return false;
          };
          const _isLowValueGatewayStatus = (phase, text) => (
            phase === 'request'
            && /(首选通道|预检首选通道|尝试通道|冷却期|重试中|并行探测|fallback|切换到|switching)/i.test(String(text || ''))
          );
          const _isFailureSignalStatus = (phase, text, status = null) => {
            if (phase === 'tool_progress' && status && status.success === false) return true;
            if (_isFailureMetricOnlyStatus(text)) return false;
            return /(失败|异常|error|failed|timeout|超时|retry|重试|拒绝|denied|取消|canceled|中断|终止)/i.test(String(text || ''));
          };
          const _shouldBypassStartSilent = (phase, text, status = null) => {
            if (phase === 'done' || phase === 'summary') return true;
            if (phase === 'tool_progress' && status && status.success === false) return true;
            if (_isFailureMetricOnlyStatus(text)) return false;
            return /(失败|异常|error|failed|timeout|超时|retry|重试|拒绝|denied|终止|取消|canceled|中断)/i.test(String(text || ''));
          };
          const _resolveStatusVerbosity = (taskText = '', isLargeTask = false) => {
            if (['brief', 'normal', 'detailed'].includes(_statusVerbosityPref)) return _statusVerbosityPref;
            const len = String(taskText || '').trim().length;
            if (isLargeTask || len >= 700) return 'detailed';
            if (len <= _statusBriefInputLen) return 'brief';
            return 'normal';
          };
          const _isDynamicProgressStatus = (phase, text) => (
            phase === 'request'
            && /处理中（\d+s）|等待模型响应中\.\.\.\s*\d+s/i.test(String(text || ''))
          );
          const _flushLiveStatusLine = () => {
            if (!_liveStatusOpen) return;
            try { process.stdout.write('\n'); } catch { /* ignore */ }
            _liveStatusOpen = false;
            _liveStatusKey = '';
          };
          const _printSuppressedStatusSummary = () => {
            if (_statusVerbosity !== 'brief' && !_statusEscalatedToDetailed) return;
            const parts = [];
            if (_suppressedStartWindowCount > 0) parts.push(`启动窗口 ${_suppressedStartWindowCount} 条`);
            if (_suppressedLowValueStatusCount > 0) parts.push(`通道状态 ${_suppressedLowValueStatusCount} 条`);
            if (_suppressedToolProgressSuccessCount > 0) parts.push(`工具成功进度 ${_suppressedToolProgressSuccessCount} 条`);
            if (_suppressedExactDedupCount > 0) parts.push(`重复状态 ${_suppressedExactDedupCount} 条`);
            if (parts.length <= 0) return;
            console.log(c.dim(`  · 已折叠状态：${parts.join(' · ')}`));
          };
          const _maybeEscalateToDetailed = (phase, text, status = null) => {
            if (!_statusEscalateOnErrorEnabled) return;
            if (_statusVerbosity === 'detailed') return;
            if (!_isFailureSignalStatus(phase, text, status)) return;
            _statusVerbosity = 'detailed';
            _lowValueRepeatGate = 1;
            _statusFirstAt = 0;
            if (!_statusEscalatedToDetailed) {
              _statusEscalatedToDetailed = true;
              _flushLiveStatusLine();
              console.log(c.dim('  · 检测到失败信号：本次请求已自动切换为详细状态'));
            }
          };

          // Claude Code: just spinner, no "Requesting AI" text line
          spinner.start('request');

          let result;
          try {
            const { startWatchdog, WATCHDOG_TIMEOUT_MS } = require('../services/resourceGuard');
            const isLargeTask = (() => {
              const text = String(message || '');
              return text.length >= 700
                || /大型任务|大任务|完整实现|全量|全流程|端到端|deep|exhaustive|full implementation|end-to-end/i.test(text);
            })();
            _statusVerbosity = _resolveStatusVerbosity(message, isLargeTask);
            _lowValueRepeatGate = _statusVerbosity === 'brief'
              ? 6
              : (_statusVerbosity === 'detailed' ? 1 : 3);
            _statusFirstAt = Date.now();
            const largeTaskMinTimeoutMs = parseInt(String(process.env.KHY_AI_REQUEST_TIMEOUT_LARGE_MS || '900000'), 10) || 900000;
            const timeoutMs = Math.max(
              isLargeTask ? Math.max(300000, largeTaskMinTimeoutMs) : 300000, // large tasks get wider budget
              Number(process.env.KHY_AI_REQUEST_TIMEOUT_MS || WATCHDOG_TIMEOUT_MS),
            );
            let wd = null;
            wd = startWatchdog('ai-chat', timeoutMs, () => {
              spinner.stop();
              console.log(c.hex('#FF6B80')(`\n  AI 请求超时（超过 ${Math.round(timeoutMs / 1000)}s）`));
            });
            try {
              result = await ai().chat(message, {
                ...opts,
                disableNaturalToolLoop: loopManaged,
                onChunk: (chunk) => {
                  if (wd) wd.touch();
                  return onChunk(chunk);
                },
                onControlRequest: (...args) => {
                  if (wd) wd.touch();
                  const handler = opts.onControlRequest || handleControlRequest;
                  return handler(...args);
                },
                onStatus: (status) => {
                  if (wd) wd.touch();
                  if (status.phase === 'compacted') {
                    _flushLiveStatusLine();
                    spinner.stop();
                    console.log(`\n${c.hex('#D77757')('✻')} ${c.bold('对话已压缩')} ${c.dim('(ctrl+o 查看历史)')}`);
                    spinner.start('request');
                    showBusyInterjectPrompt();
                    return;
                  }
                const phase = String(status && status.phase ? status.phase : '').trim();
                let text = String(status && status.message ? status.message : '').replace(/\s+/g, ' ').trim();
                if (!text || phase === 'done') return;
                if (phase === 'request') {
                  if (/^建议下一步[:：]/.test(text)) return;
                  if (/真实失败原因|建议下一步|失败原因[:：]\s*真实失败原因/.test(text)) {
                    text = compactGatewayStatusText(text, { maxLen: 200 });
                  }
                }
                _maybeEscalateToDetailed(phase, text, status);
                const now = Date.now();
                if (
                  _statusVerbosity === 'brief'
                  && _statusStartSilentMs > 0
                  && _statusFirstAt > 0
                  && (now - _statusFirstAt) < _statusStartSilentMs
                  && !_shouldBypassStartSilent(phase, text, status)
                ) {
                  _suppressedStartWindowCount += 1;
                  return;
                }
                const normKey = _normalizeStatusDedupKey(phase, text);
                const normBurstWindowMs = Math.max(1200, _statusDedupMs * 2);
                if (
                  normKey
                  && _lastStatusNormKey
                  && normKey === _lastStatusNormKey
                  && (now - _lastStatusNormAt) < normBurstWindowMs
                ) {
                  _lastStatusNormAt = now;
                  _lastStatusNormCount += 1;
                  if (_isLowValueGatewayStatus(phase, text)) {
                    if (_lowValueRepeatGate > 1 && (_lastStatusNormCount % _lowValueRepeatGate) !== 0) {
                      _suppressedLowValueStatusCount += 1;
                      return;
                    }
                    text = `${text}（同类状态 ×${_lastStatusNormCount}）`;
                  }
                } else {
                  _lastStatusNormKey = normKey;
                  _lastStatusNormAt = now;
                  _lastStatusNormCount = 1;
                }
                const sig = `${phase}:${text}`;
                  if (sig === _lastStatusLine && (now - _lastStatusLineAt) < _statusDedupMs) {
                    _suppressedExactDedupCount += 1;
                    return;
                  }
                  if (text === _lastStatusText && (now - _lastStatusTextAt) < _statusDedupMs) {
                    _suppressedExactDedupCount += 1;
                    return;
                  }
                  _lastStatusLine = sig;
                  _lastStatusLineAt = now;
                  _lastStatusText = text;
                  _lastStatusTextAt = now;
                  if (_isDynamicProgressStatus(phase, text)) {
                    spinner.stop();
                    const liveKey = _normalizeProgressKey(phase, text);
                    if (!_liveStatusOpen || _liveStatusKey !== liveKey) {
                      if (_liveStatusOpen) _flushLiveStatusLine();
                      try { process.stdout.write(c.dim(`  · ${text}`)); } catch { console.log(c.dim(`  · ${text}`)); }
                      _liveStatusOpen = true;
                      _liveStatusKey = liveKey;
                    } else {
                      try { process.stdout.write(`\r\x1b[K${c.dim(`  · ${text}`)}`); } catch { /* ignore */ }
                    }
                    spinner.start('request');
                    showBusyInterjectPrompt();
                    return;
                  }
                  _flushLiveStatusLine();
                  spinner.stop();

                  // Tool progress from ai.chat() natural tool loop — show with step indicators
                  if (phase === 'tool_progress') {
                    const toolName = status.toolName || '';
                    const success = status.success;
                    if (_statusVerbosity === 'brief' && success === true) {
                      _toolProgressSuccessCount += 1;
                      if ((_toolProgressSuccessCount % _briefToolProgressEvery) !== 0) {
                        _suppressedToolProgressSuccessCount += 1;
                        spinner.start('request');
                        showBusyInterjectPrompt();
                        return;
                      }
                      text = `${text}（进度摘要 ×${_toolProgressSuccessCount}）`;
                    }
                    if (success === true) {
                      renderer.printStepLine('success', toolName || 'Tool', '', text);
                    } else if (success === false) {
                      renderer.printStepLine('error', toolName || 'Tool', '', text);
                    } else {
                      renderer.printStepLine('active', toolName || 'Tool', '', text);
                    }
                    spinner.start('request');
                    showBusyInterjectPrompt();
                    return;
                  }

                  if (phase === 'plan') {
                    renderer.printStepLine('active', 'Plan', '', text);
                    spinner.start('request');
                    showBusyInterjectPrompt();
                    return;
                  }

                  if (phase === 'summary') {
                    renderer.printStepLine('done', 'Summary', '', text);
                    spinner.start('request');
                    showBusyInterjectPrompt();
                    return;
                  }

                  // Classify onStatus messages for rich display
                  const _lower = text.toLowerCase();
                  if (_lower.includes('重试') || _lower.includes('retry')) {
                    renderer.printStepLine('error', 'Retry', '', text);
                  } else if (_lower.includes('responded') || _lower.includes('已连接')) {
                    renderer.printStepLine('success', 'Connected', '', text);
                  } else if (_isFailureMetricOnlyStatus(text)) {
                    renderer.printStepLine('active', 'Metrics', '', text);
                  } else if (_lower.includes('failed') || _lower.includes('error') || _lower.includes('异常') || _lower.includes('失败')) {
                    renderer.printStepLine('error', 'Error', '', text);
                  } else if (_lower.includes('尝试通道') || _lower.includes('switching') || _lower.includes('首选通道')) {
                    renderer.printStepLine('active', 'Adapter', '', text);
                  } else {
                    console.log(c.dim(`  · ${text}`));
                  }
                  spinner.start('request');
                  showBusyInterjectPrompt();
                },
                onWait: (adapterKey, waitMs) => {
                  if (wd) wd.touch();
                  try {
                    _flushLiveStatusLine();
                    spinner.stop();
                    const sec = Math.max(0, Number(waitMs || 0) / 1000);
                    renderer.printStepLine('active', 'Rate limit', adapterKey || 'adapter', `等待 ${sec.toFixed(1)}s`);
                    spinner.start('request');
                    showBusyInterjectPrompt();
                  } catch { /* best effort */ }
                },
                onFallback: (info) => {
                  if (wd) wd.touch();
                  _maybeEscalateToDetailed('fallback', info && info.failedError ? info.failedError : '', { success: false });
                  _flushLiveStatusLine();
                  spinner.stop();
                  // Clear text buffer accumulated from the failed adapter to
                  // prevent duplicate content when the next adapter streams
                  // the same reply.
                  streamState._textBuffer = '';
                  streamState._streamedTextLen = 0;
                  streamState.textStarted = false;
                  const statusCode = info.failedStatusCode ? ` (${info.failedStatusCode})` : '';
                  renderer.printStepLine('error', 'Fallback', info.failedAdapter || '', `${info.failedError || 'failed'}${statusCode}`);
                  if (info.nextAdapter) {
                    renderer.printStepLine('active', 'Switching', info.nextAdapter, '');
                  }
                  spinner.start('request');
                  showBusyInterjectPrompt();
                },
              });
            } finally {
              wd.done();
            }
          } catch (wdErr) {
            spinner.stop();
            if (tracker.isActive) tracker.complete();
            throw wdErr;
          }

          spinner.stop();
          _flushLiveStatusLine();

          if (streamState.phase === 'thinking') {
            closeThinkingStream(streamState);
            console.log('');
          }

          // Update context usage for auto-compact display
          if (result && result.tokenUsage) {
            try {
              const hud = require('./hudRenderer');
              const totalUsed = (result.tokenUsage.totalTokens || 0) + (hud.getState().contextWindow.used || 0);
              hud.setContextUsage(totalUsed);
              hud.updateTokens(result.tokenUsage);
            } catch { /* best-effort */ }
          }

          // Print completion summary with stats (provider, elapsed, tokens)
          if (result && result.content) {
            const elapsed = result.elapsed || result.elapsedMs || (Date.now() - (result._startTime || Date.now()));
            const elapsedSec = typeof elapsed === 'number' && elapsed > 0 ? (elapsed / 1000).toFixed(1) : null;
            const provider = result.provider || result.adapter || result.actualAdapter || '';
            const model = result.model || '';
            const tokens = result.tokenUsage;
            const parts = [];
            if (provider) parts.push(provider);
            if (model && model !== provider) parts.push(model);
            if (elapsedSec) parts.push(`${elapsedSec}s`);
            if (tokens) {
              const inT = tokens.inputTokens || tokens.promptTokens || 0;
              const outT = tokens.outputTokens || tokens.completionTokens || 0;
              if (inT || outT) {
                const fmt = (n) => n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
                parts.push(`↑${fmt(inT)} ↓${fmt(outT)}`);
              }
            }
            // Enhanced transparency: per-turn cost + model + cascade
            try {
              const turnData = {
                inputTokens: tokens?.inputTokens || tokens?.promptTokens || 0,
                outputTokens: tokens?.outputTokens || tokens?.completionTokens || 0,
                cacheReadTokens: tokens?.cacheReadTokens || 0,
                model: model || '',
                adapter: provider || '',
                durationMs: typeof elapsed === 'number' ? elapsed : 0,
              };
              // Estimate cost
              try {
                const tokenSvc = require('../services/tokenUsageService');
                turnData.costUSD = tokenSvc.estimateCost(turnData.inputTokens, turnData.outputTokens, model || provider);
              } catch { /* no cost estimation available */ }

              renderer.printTurnCost(turnData);

              // Cascade transparency (if multiple adapters were tried)
              if (result.cascade && Array.isArray(result.cascade) && result.cascade.length > 1) {
                renderer.printCascadeSteps(result.cascade);
              }

              // Quota warning check
              try {
                const tokenSvc = require('../services/tokenUsageService');
                const quota = tokenSvc.getRemainingQuota();
                renderer.printQuotaWarning(quota);
              } catch { /* ignore */ }
            } catch { /* transparency is best-effort */ }

            if (parts.length > 0 && !renderer.printTurnCost) {
              // Fallback if transparency not available
              console.log(c.dim(`  ${parts.join(' · ')}`));
            }
          }
          _printSuppressedStatusSummary();
          return result;
        };

        let loopResult;
        let loopIterations = 0;
        let _loopToolCount = 0;
        const _loopStartTime = Date.now();

        if (toolUseLoop.isEnabled()) {
          // Claude Code-style read/search collapse tracking
          const READ_SEARCH_TOOLS = new Set([
            'read_file', 'readFile', 'grep', 'glob', 'search',
            'find_files', 'findFiles', 'search_content', 'searchContent',
            'git_status', 'gitStatus', 'git_diff', 'gitDiff', 'git_log',
            'explore', 'search_codebase', 'find_code', 'codebase_search',
          ]);
          let _collapseGroup = { count: 0, searches: 0, reads: 0, files: new Set(), patterns: [] };
          const _flushCollapseGroup = () => {
            if (_collapseGroup.count <= 1) return; // Don't collapse single operations
            const parts = [];
            if (_collapseGroup.searches > 0) parts.push(`搜索 ${_collapseGroup.searches} 次`);
            if (_collapseGroup.reads > 0) parts.push(`读取 ${_collapseGroup.reads} 个文件`);
            if (parts.length > 0) {
              const summary = parts.join('，');
              renderer.printStepLine('success', 'Explored', '', `${summary} (ctrl+o 展开)`);
              const patternPreview = _collapseGroup.patterns
                .map(p => String(p || '').trim())
                .filter(Boolean)
                .slice(0, 3);
              if (patternPreview.length > 0) {
                renderer.printStepDetail(`Patterns: ${patternPreview.join(' | ')}`);
              }
              const filePreview = [..._collapseGroup.files]
                .map(f => String(f || '').trim())
                .filter(Boolean)
                .slice(0, 4);
              if (filePreview.length > 0) {
                renderer.printStepDetail(`Read: ${filePreview.join(', ')}`);
              }
            }
            _collapseGroup = { count: 0, searches: 0, reads: 0, files: new Set(), patterns: [] };
          };

          const loopMaxIterations = (() => {
            const base = parseInt(String(process.env.KHY_TOOL_LOOP_MAX_ITERATIONS || '12'), 10) || 12;
            const lengthBoost = String(finalAiInput || '').length >= 700 ? 6 : 0;
            let intentBoost = 0;
            try {
              const { detectModes, getLoopLimitBoost } = require('../services/intentGate');
              const detected = detectModes(finalAiInput);
              intentBoost = getLoopLimitBoost(detected.modes).outerBoost;
            } catch { /* intentGate not available */ }
            const maxCap = parseInt(String(process.env.KHY_INTENT_LOOP_MAX_CAP || '60'), 10) || 60;
            return Math.max(8, Math.min(maxCap, base + lengthBoost + intentBoost));
          })();
          const loopOptions = {
            chat: chatFn,
            chatOpts: _inlineImageOpts || {},
            maxIterations: loopMaxIterations,
            getSteerMessages: () => {
              const merged = [];
              const featurePayload = _buildFeatureCapabilitySteerMessage();
              if (featurePayload && featurePayload !== _lastFeatureMapSteerPayload) {
                merged.push(featurePayload);
                _lastFeatureMapSteerPayload = featurePayload;
              }
              const mindPayload = _buildTaskMindMapSteerMessage();
              if (mindPayload && mindPayload !== _lastMindMapSteerPayload) {
                merged.push(mindPayload);
                _lastMindMapSteerPayload = mindPayload;
              }
              if (_steerQueue.length > 0) {
                merged.push(..._steerQueue.splice(0));
              }
              return merged;
            },
            onCapabilityCheck: (assessment = {}) => {
              const reasons = Array.isArray(assessment.reasons) ? assessment.reasons : [];
              const warnings = Array.isArray(assessment.warnings) ? assessment.warnings : [];
              if (assessment.canProceed === false) {
                renderer.printStepLine('error', '能力预判', '未通过', reasons[0] || '任务超出当前可执行能力');
                return;
              }
              if (warnings.length > 0) {
                renderer.printStepLine('active', '能力预判', '可继续执行', warnings[0]);
              } else {
                renderer.printStepLine('success', '能力预判', '通过', '已确认可以继续执行');
              }
            },
            onDecision: (decision = {}) => {
              // 流式输出已结束，重置 streaming 标志让忙碌输入框恢复可见
              _busyStreaming = false;
              const preview = String(decision.preview || '').trim();
              const tools = Array.isArray(decision.tools) ? decision.tools : [];
              const mode = String(decision.mode || '');
              const round = `第${decision.iteration || 1}轮`;
              if (mode === 'tool') {
                renderer.printStepLine('active', '判断', round, preview || '准备执行工具调用');
                if (tools.length > 0) {
                  const list = tools.slice(0, 5).join(' -> ');
                  const suffix = tools.length > 5 ? ` +${tools.length - 5}` : '';
                  renderer.printStepDetail(`计划工具: ${list}${suffix}`);
                }
              } else if (preview) {
                renderer.printStepLine('active', '判断', round, '本轮无需工具，准备直接给出结果');
                renderer.printStepDetail(preview);
              }
              if (_taskMindMap) {
                _taskMindMap.markDecision(decision);
                if (_taskMindMapAutoShow) {
                  _printTaskMindMapCompact(`Mind map · ${round}`);
                }
              }
            },
            onIterationSummary: (summary = {}) => {
              const total = Number(summary.total || 0);
              if (total <= 0) return;
              const ok = Number(summary.succeeded || 0);
              const failed = Number(summary.failed || 0);
              const denied = Number(summary.denied || 0);
              const deduped = Number(summary.deduped || 0);
              const details = [
                `${ok}/${total} 成功`,
                failed > 0 ? `${failed} 失败` : '',
                denied > 0 ? `${denied} 拒绝` : '',
                deduped > 0 ? `${deduped} 去重` : '',
              ].filter(Boolean).join(' · ');
              renderer.printStepLine(failed > 0 || denied > 0 ? 'active' : 'success', '本轮结果', `第${summary.iteration || 1}轮`, details);
              if (_taskMindMap) {
                _taskMindMap.markIterationSummary(summary);
              }
            },
            onIteration: (iteration) => {
              loopIterations = iteration;
              // Flush collapse group between iterations (AI is about to make new decisions)
              if (iteration > 1) _flushCollapseGroup();
            },
            onToolCall: (toolName, params) => {
              // 流式输出已结束，进入工具执行 — 重置 streaming 让忙碌输入框可见
              _busyStreaming = false;
              _currentOp = 'Tool use';
              _loopToolCount++;
              spinner.stop();
              updateTitlePhase('tool', mapToolToPhaseLabel(toolName));

              const activity = _toolProgressStart(toolName, params || {});
              if (activity) {
                renderer.printStepLine('active', activity.label, activity.target || '');
                const reason = _toolProgressReason(toolName, params || {});
                if (reason) renderer.printStepDetail(reason);
              }
              if (_taskMindMap) {
                _taskMindMap.markToolCall(toolName, params || {});
                if (_taskMindMapAutoShow) {
                  _printTaskMindMapCompact('Mind map · tool call');
                }
              }
              _featureCapabilityMap.markToolCall(toolName, params || {});
              if (_taskMindMapAutoShow) {
                _printFeatureCapabilityCompact('Feature map · tool call');
              }

              const normalizedName = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
              const isReadSearch = READ_SEARCH_TOOLS.has(toolName) || READ_SEARCH_TOOLS.has(normalizedName);

              if (isReadSearch) {
                // Track in collapse group — show individual lines but track for summary
                _collapseGroup.count++;
                if (/grep|search|glob|find|explore/i.test(toolName)) {
                  _collapseGroup.searches++;
                  if (params?.pattern) _collapseGroup.patterns.push(params.pattern);
                } else {
                  _collapseGroup.reads++;
                  const filePath = params?.path || params?.file_path || params?.filePath || '';
                  if (filePath) _collapseGroup.files.add(filePath);
                }
              } else {
                // Non-read-search tool: flush any pending collapse group
                _flushCollapseGroup();
              }

              // Claude Code: ⏺ ToolName(params) — one clean line per tool
              renderer.printToolCallStart(toolName, params);

              // Agent tools get special treatment: show running header
              const normName = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
              if (normName === 'agent' || normName === 'spawnworker' || normName === 'subagent') {
                const role = params?.role || 'general';
                const prompt = (params?.prompt || '').slice(0, 50);
                renderer.renderAgentHeader(1, `${role}: ${prompt}...`);
              }
            },
            onParallelBatch: (calls) => {
              // Show parallel agent count if multiple agents spawned
              const agentCalls = calls.filter(c =>
                /^(agent|spawn_worker|sub_agent)$/i.test(String(c.name).replace(/[\s_-]/g, ''))
              );
              if (agentCalls.length >= 2) {
                renderer.renderAgentHeader(agentCalls.length, '(ctrl+o to expand)');
                const agentInfos = agentCalls.map(c => ({
                  name: `${c.params?.role || 'general'} agent`,
                  status: 'running',
                  detail: (c.params?.prompt || '').slice(0, 60),
                }));
                renderer.renderAgentProgress(agentInfos);
              }
            },
            onToolResult: (toolName, params, result, _iteration, elapsedMs) => {
              // Claude Code: overwrite tool start line with success/error dot + ⎿ result
              const status = (result && result.success) ? 'success' : 'error';
              let detail = '';
              if (result && result.denied) {
                detail = 'Permission denied';
              } else if (result && result.success) {
                detail = _formatToolResult(toolName, result);
              } else {
                const err = result && result.error;
                detail = (err && typeof err === 'object')
                  ? (err.message || JSON.stringify(err))
                  : (err || 'failed');
                detail = String(detail).slice(0, 120);
              }
              renderer.printToolCallResult(toolName, params, status, detail, elapsedMs || 0);
              const activityDone = _toolProgressDone(toolName, status === 'success', detail);
              if (activityDone) {
                renderer.printStepLine(activityDone.status, activityDone.label, '', activityDone.detail || '');
              }
              if (_taskMindMap) {
                _taskMindMap.markToolResult(toolName, status === 'success', detail);
                if (_taskMindMapAutoShow) {
                  _printTaskMindMapCompact('Mind map · tool result');
                }
              }
              _featureCapabilityMap.markToolResult(toolName, status === 'success', detail);
              if (_taskMindMapAutoShow) {
                _printFeatureCapabilityCompact('Feature map · tool result');
              }
              maybeRenderWriteDiff(toolName, params, result, c);
              maybeRenderInlineDiffFromToolOutput(toolName, result, c);
            },
          };

          const harnessEnabled = (() => {
            const raw = String(process.env.KHY_REPL_HARNESS || 'true').trim().toLowerCase();
            return !['0', 'false', 'off', 'no', 'n'].includes(raw);
          })();
          const harnessRetryAttempts = Math.max(1, parseInt(String(process.env.KHY_HARNESS_RETRY_ATTEMPTS || '2'), 10) || 2);
          const harnessRetryMinDelayMs = Math.max(100, parseInt(String(process.env.KHY_HARNESS_RETRY_MIN_DELAY_MS || '700'), 10) || 700);
          const harnessRetryMaxDelayMs = Math.max(
            harnessRetryMinDelayMs,
            parseInt(String(process.env.KHY_HARNESS_RETRY_MAX_DELAY_MS || '5000'), 10) || 5000
          );
          const harnessMaxContinuationRounds = Math.max(0, parseInt(String(process.env.KHY_HARNESS_MAX_CONTINUATION_ROUNDS || '3'), 10) || 3);

          if (harnessEnabled) {
            try {
              const { createAgenticHarness } = require('../services/agenticHarnessService');
              const harness = createAgenticHarness();
              loopResult = await harness.run({
                userMessage: finalAiInput,
                chat: chatFn,
                chatOpts: _inlineImageOpts || {},
                loopOptions,
                recentFiles: [],
                taskLabel: 'repl-tool-loop',
                retryAttempts: harnessRetryAttempts,
                retryMinDelayMs: harnessRetryMinDelayMs,
                retryMaxDelayMs: harnessRetryMaxDelayMs,
                maxContinuationRounds: harnessMaxContinuationRounds,
                onEvent: (event) => {
                  if (!event) return;
                  if (event.type === 'retry') {
                    const attempt = Number(event.attempt || 0);
                    const maxAttempts = Number(event.maxAttempts || 0);
                    const waitSec = Math.max(0, Number(event.delayMs || 0) / 1000);
                    renderer.printStepLine('active', '恢复策略', `${attempt}/${maxAttempts}`, `等待 ${waitSec.toFixed(1)}s 后重试`);
                  } else if (event.type === 'continuation') {
                    renderer.printStepLine('active', 'Ralph Loop', `${event.round}/${event.maxRounds}`, '迭代上限已达，自动续跑中...');
                  } else if (
                    (event.type === 'bugfix_regression_gate' || event.type === 'change_regression_gate')
                    && event.phase === 'baseline_completed'
                  ) {
                    const target = Array.isArray(event.requiredSteps) && event.requiredSteps.length > 0
                      ? event.requiredSteps.join('+')
                      : 'auto';
                    renderer.printStepLine('active', '回归闸门', '1/2', `基线校验已完成（目标步骤: ${target}）`);
                  } else if (
                    (event.type === 'bugfix_regression_gate' || event.type === 'change_regression_gate')
                    && event.phase === 'final_evaluation'
                  ) {
                    const status = event.passed ? 'success' : 'error';
                    const detail = String(event.summary || '').replace(/\s+/g, ' ').trim().slice(0, 140);
                    renderer.printStepLine(status, '回归闸门', '2/2', detail || (event.passed ? '无新增失败步骤' : '发现新增失败步骤'));
                  } else if (
                    event.type === 'bugfix_regression_gate_error' || event.type === 'change_regression_gate_error'
                  ) {
                    const phase = String(event.phase || 'unknown');
                    const detail = String(event.error || 'unknown error').replace(/\s+/g, ' ').trim().slice(0, 140);
                    renderer.printStepLine('error', '回归闸门', phase, detail || '门禁校验异常');
                  }
                },
              });
            } catch (harnessErr) {
              renderer.printStepLine('error', 'Harness', '回退', String(harnessErr?.message || 'unknown error'));
              loopResult = await toolUseLoop.runToolUseLoop(finalAiInput, loopOptions);
            }
          } else {
            loopResult = await toolUseLoop.runToolUseLoop(finalAiInput, loopOptions);
          }
          // Flush any remaining collapse group
          _flushCollapseGroup();
        } else {
          const r = await chatFn(finalAiInput, _inlineImageOpts || {});
          loopResult = {
            finalResponse: r.reply,
            provider: r.provider,
            tokenUsage: r.tokenUsage,
            errorType: r.errorType || null,
            iterations: 1,
            toolCallLog: [],
          };
        }

        aiResult = {
          reply: loopResult.finalResponse || '',
          provider: loopResult.provider,
          tokenUsage: loopResult.tokenUsage,
          errorType: loopResult.errorType || null,
          elapsed: 0,
        };

        if (loopIterations > 0) {
          const log = (loopResult.toolCallLog || []).filter(t => t.tool !== '_legacy_cmd');
          const toolCount = log.length;
          if (toolCount > 0) {
            const searches = log.filter(t => /grep|glob|search|find/i.test(t.tool)).length;
            const reads = log.filter(t => /read/i.test(t.tool)).length;
            const writes = log.filter(t => /write|edit/i.test(t.tool)).length;
            const bashes = log.filter(t => /bash|shell|command/i.test(t.tool)).length;
            const webSearches = log.filter(t => /websearch|webfetch/i.test(t.tool)).length;
            const agents = log.filter(t => /agent|task/i.test(t.tool)).length;
            const succeeded = log.filter(t => t.result && t.result.success).length;
            const failed = toolCount - succeeded;
            const totalElapsed = log.reduce((sum, t) => sum + (t.elapsed || 0), 0);
            const elapsedStr = totalElapsed > 1000
              ? `${(totalElapsed / 1000).toFixed(1)}s`
              : `${totalElapsed}ms`;

            // Build detailed summary parts
            const parts = [];
            if (writes > 0) parts.push(`${writes} 个文件已修改`);
            if (bashes > 0) parts.push(`${bashes} 条命令已执行`);
            if (searches > 0) parts.push(`${searches} 次搜索`);
            if (reads > 0) parts.push(`${reads} 个文件已读取`);
            if (webSearches > 0) parts.push(`${webSearches} 次网络搜索`);
            if (agents > 0) parts.push(`${agents} 个子任务`);

            // Print summary box
            console.log('');
            const summaryLine = parts.length > 0 ? parts.join(' · ') : `${toolCount} 次工具调用`;
            const statusIcon = failed === 0 ? c.hex('#4EBA65')('✓') : c.hex('#FFC107')('⚠');
            const statsStr = c.dim(`${loopIterations} 轮迭代 · ${elapsedStr} · ${succeeded}/${toolCount} 成功`);
            console.log(`  ${statusIcon} ${c.bold('任务完成')}  ${summaryLine}`);
            console.log(`    ${statsStr}`);

            // Show modified file list (if any writes)
            if (writes > 0) {
              const writtenFiles = log
                .filter(t => /write|edit/i.test(t.tool))
                .map(t => t.params?.file_path || t.params?.filePath || t.params?.path || '')
                .filter(Boolean)
                .map(f => require('path').basename(f));
              const uniqueFiles = [...new Set(writtenFiles)];
              if (uniqueFiles.length > 0 && uniqueFiles.length <= 8) {
                console.log(`    ${c.dim('修改：')}${c.cyan(uniqueFiles.join(', '))}`);
              }
            }
            console.log('');
          }
        }

        if (loopResult.consecutiveFailureBailout) {
          console.log(c.hex('#FFC107')('  连续工具调用失败，已停止重试'));
        } else if (loopResult.timeLimitReached) {
          const limitMs = Number(loopResult.maxElapsedMs || 0);
          const totalSec = Math.max(1, Math.ceil(limitMs / 1000));
          const m = Math.floor(totalSec / 60);
          const s = totalSec % 60;
          const limitText = (m > 0 && s > 0) ? `${m}m ${s}s` : (m > 0 ? `${m}m` : `${s}s`);
          console.log(c.hex('#FFC107')(`  工具循环超时 (>${limitText})，返回已收集结果`));
        } else if (loopResult.maxIterationsReached) {
          const contInfo = loopResult.continuationRounds > 0
            ? ` (含 ${loopResult.continuationRounds} 轮续跑)`
            : '';
          console.log(c.hex('#FFC107')(`  达到最大迭代次数 (${loopResult.iterations}${contInfo})，返回最后结果`));
        }
        if (_taskMindMap) {
          const completed = !(loopResult.consecutiveFailureBailout || loopResult.timeLimitReached);
          let reason = '';
          if (loopResult.consecutiveFailureBailout) reason = 'stopped after consecutive tool failures';
          else if (loopResult.timeLimitReached) reason = 'stopped by time limit';
          else if (loopResult.maxIterationsReached) reason = 'stopped by max iterations';
          _taskMindMap.complete({ success: completed, reason });
          if (_taskMindMapAutoShow || !completed) {
            _renderTaskMindMap(completed ? 'completed' : 'incomplete');
          } else {
            _printTaskMindMapCompact('Mind map finalized');
          }
          _featureCapabilityMap.markAiCompletion(completed, reason || 'tool loop done');
          if (_taskMindMapAutoShow || !completed) {
            _printFeatureCapabilityCompact('Feature map finalized');
          }
        }
      } // end if (!_useQueryEngine)

      // AI 请求完成，重置流式标志确保输入框可见
      _busyStreaming = false;

      // Close thinking block if it was still open
      if (streamState.phase === 'thinking') {
        closeThinkingStream(streamState);
        console.log('');
      }

      if (aiResult.reply && !responseAlreadyRendered) {
        if (aiResult.errorType) {
          const rendered = _renderAiErrorCompact(aiResult.reply);
          if (!rendered?.merged) {
            console.log('');
          }
        } else {
          // Update terminal title with conversation topic
          updateTitleFromConversation(aiInput);

          // Update session tokens for prompt frame display
          if (aiResult.tokenUsage?.totalTokens) {
            _sessionTokens += aiResult.tokenUsage.totalTokens;
          }

          // Build meta info line (Claude Code style)
          const elapsedSec = aiResult.elapsed ? `${(aiResult.elapsed / 1000).toFixed(1)}s` : '';
	          const tokenCount = aiResult.tokenUsage
	            ? `↑ ${aiResult.tokenUsage.totalTokens?.toLocaleString() || '?'} tokens` : '';
	          const thinkTime = streamState.thinkingStarted ? 'thought' : '';
          const toolSummaryText = formatToolSummary(aiResult.toolSummary);
	          const metaParts = [elapsedSec, tokenCount, thinkTime].filter(Boolean);
	          const metaTag = metaParts.length > 0 ? c.dim(` (${metaParts.join(' · ')})`) : '';

          // Claude Code style: no "AI response" header — just render the response text directly

          // If text was already streamed incrementally to the terminal,
          // skip the final full render to avoid duplicate output.
          // Only re-render from aiResult.reply when no streaming happened
          // (e.g. adapter cascade or non-streaming response).
          if (streamState._streamedTextLen > 0) {
            // G1/G2: 使用 AdaptiveChunker flushAll 输出剩余内容
            if (streamState._chunker) {
              streamState._chunker.flushAll();
              streamState._textBuffer = '';
            } else {
              const remaining = (streamState._textBuffer || '').trim();
              streamState._textBuffer = '';
              if (remaining) {
                _renderTextBlock(remaining);
              }
            }
          } else {
            streamState._textBuffer = '';
            if (aiResult.reply) {
              const rendered = renderer.renderAiResponse(aiResult.reply);
              const lines = rendered.split('\n');
              lines.forEach(l => console.log(`  ${l}`));
            }
          }

          // Compacting notice — only when context is actually getting large (>80% of limit)
          try {
            const hud = require('./hudRenderer');
            const state = hud.getState();
            const usedPct = state.contextWindow.limit > 0
              ? (state.sessionTokens.total / state.contextWindow.limit) * 100
              : 0;
            if (usedPct > 80) {
              renderer.printCompactingNotice({
                tokens: state.sessionTokens.total?.toLocaleString() || '?',
              });
            }
          } catch { /* best effort */ }

          // Extract and display task plan if AI response contains numbered steps
          try {
            const planPattern = /执行计划|分析步骤|操作步骤|回测计划|分步|plan|steps|implementation/i;
            if (planPattern.test(aiResult.reply) || needsPlan) {
              const planTracker = new renderer.TaskPlanTracker();
              if (planTracker.extractFromResponse(aiResult.reply)) {
                planTracker.render();
              }
            }
          } catch { /* best effort */ }

          // Claude Code style: show random Tip after AI response (throttled)
          try {
            if (!_lastTipShown || (Date.now() - _lastTipShown > 120000)) {
              const tips = [
                '输入 /clear 切换话题时清空上下文',
                '按 Ctrl+C 中断当前 AI 请求',
                '↑/↓ 方向键浏览历史命令',
                '拖拽文件到终端可附带文件内容',
                '输入 /plan 让 AI 先规划再执行复杂任务',
                '输入 /btw 在 AI 工作时补充提示',
                '输入 /resume 恢复上次对话',
              ];
              const tip = tips[Math.floor(Math.random() * tips.length)];
              console.log('');
              console.log(c.dim(`    Tip: ${tip}`));
              _lastTipShown = Date.now();
            }
          } catch { /* tips are best-effort */ }

          // Detect inline options in AI response (numbered lists ending with ?)
          // Pattern: AI asks a question with numbered options like "1. xxx\n2. xxx\n请选择"
          try {
            const optionPattern = /(?:^|\n)\s*(\d)\.\s+(.+)/g;
            const questionPattern = /请选择|你想|哪个|选哪|怎么做|如何选/;
            const hasQuestion = questionPattern.test(aiResult.reply);

            if (hasQuestion) {
              const matches = [...aiResult.reply.matchAll(optionPattern)];
              if (matches.length >= 2 && matches.length <= 6) {
                const options = matches.map(m => ({ label: m[2].trim() }));
                const selection = await renderer.askInlineQuestion(
                  'AI needs your choice:',
                  options,
                  { rl }
                );
                if (selection) {
                  _btwQueue.push(`Selected: ${Array.isArray(selection) ? selection.join(', ') : selection}`);
                  console.log(c.hex('#4EBA65')(`  Selected: ${Array.isArray(selection) ? selection.join(', ') : selection}`));
                }
              }
            }
          } catch (e) {
            // B4: AI 内联选择失败日志，便于诊断"选择无响应"问题
            try { console.error('[repl] AI 内联选择失败:', e?.message); } catch {}
          }
        }

        console.log('');
      } else if (!aiResult.reply && !responseAlreadyRendered) {
        // Truly empty reply — inform user
        printInfo('AI 未返回有效回复 — 请重试或检查连接');
        console.log('');
      }

      // Execute any embedded commands with Claude Code-style tool call display
      // Also handle <tool_call> tags via the new tool-use loop
      if (aiResult.commands && aiResult.commands.length > 0) {
        console.log('');
        const toolCallStats = { toolCalls: 0, startTime: Date.now() };
        for (const cmd of aiResult.commands) {
          const cmdParts = cmd.split(/\s+/);
          const cmdLabel = cmdParts[0] || cmd;
          const cmdTarget = cmdParts.slice(1).join(' ') || '';
          toolCallStats.toolCalls++;

          // Show Claude Code-style tool call start
          renderer.printToolCallStart(cmdLabel, cmdTarget || cmd);
          const cmdStart = Date.now();

          try {
            const cmdParsed = parseInput(cmd);
            if (cmdParsed) {
              // Capture output by temporarily redirecting console.log
              const origLog = console.log;
              const output = [];
              console.log = (...args) => {
                const line = args.map(a => typeof a === 'string' ? a : String(a)).join(' ');
                output.push(line);
              };
              try {
                await route(cmdParsed);
              } finally {
                console.log = origLog;
              }

              const cmdElapsed = Date.now() - cmdStart;

              // Show condensed result via tool call result display
              const condensed = output.filter(l => l.trim()).slice(0, 5);
              const cleanLines = condensed.map(l => l.replace(/\x1b\[[0-9;]*m/g, '').trim().slice(0, 80));
              const detail = cleanLines.length > 0 ? cleanLines[0] : `${cmdLabel} completed`;
              const moreLines = output.filter(l => l.trim()).length;

              renderer.printToolCallResult(
                cmdLabel,
                cmdTarget || cmd,
                'success',
                moreLines > 1 ? `${detail} (+${moreLines - 1} more lines)` : detail,
                cmdElapsed
              );
            } else {
              renderer.printToolCallResult(cmdLabel, cmd, 'error', 'Cannot parse command', 0);
            }
          } catch (cmdErr) {
            renderer.printToolCallResult(
              cmdLabel, cmd, 'error',
              cmdErr.message || 'Execution failed',
              Date.now() - cmdStart
            );
          }
        }
        // Show completion summary
        renderer.renderAgentDone({
          toolCalls: toolCallStats.toolCalls,
          elapsedMs: Date.now() - toolCallStats.startTime,
        });
      }

    } catch (err) {
      _featureCapabilityMap.markError(err);
      try { printError(err?.message || String(err) || '执行出错'); } catch { /* ignore */ }
    } finally {
      _busy = false;
      _busyStreaming = false;
      _busyHintShownAt = 0; // 重置 hint，下次忙碌可再次显示
      _currentOp = '';
      // Cancel any pending busy prompt repaint and keepalive
      _stopBusyPromptKeepalive();
      if (_busyPromptRepaintPending) {
        clearTimeout(_busyPromptRepaintPending);
        _busyPromptRepaintPending = null;
      }
      updateTitlePhase('idle');
      try {
        const renderer = require('./aiRenderer');
        if (typeof renderer.setInteractiveGuard === 'function') renderer.setInteractiveGuard(null);
      } catch { /* non-critical */ }
      // Ensure terminal is in a clean state after AI streaming
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[?25h'); // show cursor (in case hidden during streaming)
      }
      // Resume vim handler after command execution
      if (_vimHandler) try { _vimHandler.resume(); } catch { /* ignore */ }
      // Re-enable frame rendering so decoration lines appear on next prompt
      leaveInputPromptFrame();
      _flushMergedErrorHintLine();
      // No active task now: return cognition maps to start node (AI navigation baseline).
      _resetCognitionMapsToStartNode();
      // Flush any pending merge-queue lines before dequeuing — lines may still
      // be accumulating if the user pasted right before the AI finished.
      // B3: 每段清理独立 try-catch，确保异常不阻塞 readline 恢复
      try {
        if (_busyQueueMergeTimer) {
          clearTimeout(_busyQueueMergeTimer);
          _busyQueueMergeTimer = null;
          if (_busyQueueAccum.length > 0) {
            const lines = _busyQueueAccum;
            _busyQueueAccum = [];
            if (lines.length === 1) {
              _queuedInputs.push(lines[0]);
            } else {
              // Multi-line = paste. Don't auto-queue — let user edit first.
              const unwrapped = lines.map(l => {
                const m = PASTED_CONTENT_BLOCK_RE.exec(l);
                return m ? m[1] : l;
              });
              const merged = unwrapped.join('\n').trim();
              if (merged) _storePendingPaste(merged, null, '', false);
            }
          }
        }
      } catch (e) { try { console.error('[repl] paste queue cleanup error:', e?.message); } catch {} }
      // Also flush burst paste buffer if active
      try {
        if (_burstActive || _burstBuf) {
          if (_burstFlushTimer) { clearTimeout(_burstFlushTimer); _burstFlushTimer = null; }
          const burstText = _burstBuf.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
          _burstActive = false;
          _burstConsecutive = 0;
          _burstLastCharAt = 0;
          _burstWindowUntil = 0;
          _burstBuf = '';
          if (burstText) _storePendingPaste(burstText, null, '', false);
        }
      } catch (e) { try { console.error('[repl] burst buffer cleanup error:', e?.message); } catch {} }
      // If _pendingPaste was just set (paste waiting for user to press Enter),
      // don't dequeue anything — let the user interact with the paste first.
      if (_pendingPaste !== null) {
        recoverReadlineInput();
        try { rl.prompt(); } catch { /* readline may be destroyed */ }
        return;
      }
      // Steer 队列清理：未消费的 steer 消息转入 queue，避免丢失
      if (_steerQueue.length > 0) {
        for (const msg of _steerQueue.splice(0)) {
          _queuedInputs.push(msg);
        }
      }
      const nextQueued = _queuedInputs.shift();
      if (nextQueued) {
        try {
          const queuedPreview = _summarizeQueuedInputForDisplay(nextQueued, 48);
          console.log(c.dim(`  ↳ 继续处理排队输入: "${queuedPreview}"`));
          setImmediate(() => rl.emit('line', `${INTERNAL_LINE_PREFIX}${nextQueued}`));
          return;
        } catch { /* fallthrough to prompt */ }
      }
      recoverReadlineInput();
      try { rl.prompt(); } catch { /* readline may be destroyed */ }
    }
  });

  // Handle Ctrl+C — require double-press within 2s to exit (prevent accidental exit)
  rl.on('SIGINT', () => {
    if (_busy) {
      // Busy state: Ctrl+C should interrupt current request, not arm exit.
      _ctrlCCount = 0;
      if (_ctrlCTimer) {
        clearTimeout(_ctrlCTimer);
        _ctrlCTimer = null;
      }
      leaveInputPromptFrame();
      const cancelled = _requestRelayCancel('Interrupted by Ctrl+C');
      if (cancelled) {
        console.log(c.hex('#FFC107')('\n  Ctrl+C 已发送中断信号，当前请求将尽快停止（不会退出会话）'));
      } else {
        console.log(c.hex('#FFC107')('\n  Ctrl+C 已记录中断请求，当前步骤结束后返回输入状态（不会退出会话）'));
      }
      try { rl.prompt(); } catch { /* readline may be destroyed */ }
      return;
    }

    _ctrlCCount++;
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
    if (_ctrlCCount >= 2) {
      // Double Ctrl+C confirmed — force exit
      const savedMeta = ai().saveConversation();
      saveHistory(history);
      setTerminalTitle(''); // restore terminal title
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      printResumeRecoveryHints(savedMeta);
      console.log('');
      _uninstallBusyPromptConsolePatch();
      _intentionalExit = true; process.exit(0);
    }

    _clearTransientInputState(rl);
    leaveInputPromptFrame();
    console.log(c.hex('#FFC107')('\n  Press Ctrl+C again to exit, or type resume to continue'));
    rl.prompt();
  });

  // Handle Ctrl+D (EOF) — save and exit gracefully
  // Guard: inquirer may close stdin which triggers 'close' on our readline.
  // _intentionalExit is set by /exit and double-Ctrl+C. For Ctrl+D (real EOF),
  // we check if inquirer is active — if not, it's a genuine exit request.
  rl.on('close', () => {
    if (_intentionalExit) {
      // Already handled (e.g., /exit command triggered process.exit above)
      return;
    }
    if (_inquirerActive) {
      // Triggered by inquirer closing stdin — reopen readline
      try {
        process.stdin.resume();
        if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
          process.stdin.setRawMode(true);
        }
        rl.resume();
        rl.prompt();
      } catch { /* ignore */ }
      return;
    }
    // Real EOF (Ctrl+D) — save and exit
    for (const t of _startupTimers) clearTimeout(t);
    clearInterval(_tipTimer);
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    try { require('./hudRenderer').stopLiveStatusBar(); } catch { /* ignore */ }
    try { require('../services/resourceGuard').cancelAll(); } catch { /* ignore */ }
    const savedMeta = ai().saveConversation();
    saveHistory(history);
    setTerminalTitle('');
    // Session recap transparency
    try {
      const hud = require('./hudRenderer');
      const state = hud.getState();
      const sessionData = {
        durationMs: Date.now() - state.sessionStart,
        totalInputTokens: state.sessionTokens.input,
        totalOutputTokens: state.sessionTokens.output,
        totalCostUSD: 0,
        requestCount: state.requestCount,
        toolCallCount: state.toolHistory.length,
        topTools: [],
      };
      // Calculate cost
      try {
        const tokenSvc = require('../services/tokenUsageService');
        const cost = tokenSvc.getSessionCost();
        sessionData.totalCostUSD = cost.costUSD || 0;
      } catch { /* ignore */ }
      // Compute top tools
      const toolCounts = {};
      for (const t of state.toolHistory) {
        toolCounts[t.name] = (toolCounts[t.name] || 0) + 1;
      }
      sessionData.topTools = Object.entries(toolCounts)
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count);
      renderer.printSessionRecap(sessionData);
    } catch { /* transparency is best-effort */ }
    console.log('');
    console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
    printResumeRecoveryHints(savedMeta);
    console.log('');
    _uninstallBusyPromptConsolePatch();
    process.exit(0);
  });
}

module.exports = { startRepl };
