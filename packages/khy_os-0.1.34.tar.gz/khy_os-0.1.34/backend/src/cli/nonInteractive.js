/**
 * Non-Interactive Mode — headless JSON protocol for CI/CD, IDE, and SDK integration.
 *
 * Protocol (v1.1):
 *   Input  (stdin, one JSON per line):
 *     { "type": "prompt",  "content": "...", "requestId": "...", "options": {} }
 *     { "type": "approve", "requestId": "..." }
 *     { "type": "deny",    "requestId": "..." }
 *     { "type": "ping" }
 *     { "type": "exit" }
 *
 *   Output (stdout, one JSON per line):
 *     { "type": "ready",              "version": "1.1.0", "capabilities": [...] }
 *     { "type": "chunk",              "content": "...", "requestId": "..." }
 *     { "type": "response",           "content": "...", "requestId": "..." }
 *     { "type": "tool_call",          "name": "...", "params": {}, "callId": "...", "requestId": "..." }
 *     { "type": "tool_result",        "callId": "...", "result": ..., "isError": false, "requestId": "..." }
 *     { "type": "permission_request", "approvalId": "...", "command": "...", "risk": "...", "requestId": "..." }
 *     { "type": "done",               "requestId": "..." }
 *     { "type": "error",              "error": "...", "requestId": "..." }
 *     { "type": "pong",               "ts": 123 }
 *
 * Usage:
 *   echo '{"type":"prompt","content":"list strategies"}' | khy --non-interactive
 *   khy --non-interactive < commands.jsonl
 */
const readline = require('readline');
const crypto = require('crypto');

const PROTOCOL_VERSION = '1.1.0';
const CAPABILITIES = ['prompt', 'tool_call', 'tool_result', 'permission', 'streaming'];

// Pending approval resolvers: approvalId → { resolve, timer }
const _pendingApprovals = new Map();

/**
 * Start non-interactive session.
 * @param {Object} deps - Injected dependencies
 * @param {Function} deps.processMessage - async (message, options) => AsyncGenerator<chunk>
 * @param {Object} deps.options - Session options
 */
async function startNonInteractive(deps) {
  const { processMessage, options = {} } = deps;

  const rl = readline.createInterface({
    input: process.stdin,
    output: null, // don't echo
    terminal: false,
  });

  _emit({ type: 'ready', version: PROTOCOL_VERSION, capabilities: CAPABILITIES });

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (!trimmed) return;

    let msg;
    try {
      msg = JSON.parse(trimmed);
    } catch {
      _emit({ type: 'error', error: 'Invalid JSON input' });
      return;
    }

    switch (msg.type) {
      case 'prompt':
        await _handlePrompt(msg, processMessage, options);
        break;
      case 'approve':
        _handleApprovalResponse(msg.requestId, true);
        break;
      case 'deny':
        _handleApprovalResponse(msg.requestId, false);
        break;
      case 'ping':
        _emit({ type: 'pong', ts: Date.now() });
        break;
      case 'exit':
        _emit({ type: 'done', reason: 'client_exit' });
        process.exit(0);
        break;
      default:
        _emit({ type: 'error', error: `Unknown message type: ${msg.type}` });
    }
  });

  rl.on('close', () => {
    process.exit(0);
  });
}

async function _handlePrompt(msg, processMessage, options) {
  const { content, requestId } = msg;
  if (!content) {
    _emit({ type: 'error', error: 'Missing "content" field', requestId });
    return;
  }

  // Inject SDK event hooks so the tool pipeline can emit structured events
  const sdkHooks = {
    onToolCall(name, params, callId) {
      _emit({ type: 'tool_call', name, params, callId, requestId });
    },
    onToolResult(callId, result, isError) {
      _emit({ type: 'tool_result', callId, result, isError: !!isError, requestId });
    },
    /**
     * Request permission from the SDK client.
     * Returns a Promise that resolves to true (approved) or false (denied).
     * The promise is resolved when the client sends an approve/deny message.
     */
    requestPermission(command, risk) {
      return _createApprovalRequest(command, risk, requestId);
    },
  };

  try {
    const generator = processMessage(content, {
      ...options,
      ...msg.options,
      _sdkHooks: sdkHooks,
    });

    if (generator && typeof generator[Symbol.asyncIterator] === 'function') {
      for await (const chunk of generator) {
        // Support structured event objects from the generator
        if (chunk && typeof chunk === 'object' && chunk._sdkEvent) {
          _emit({ ...chunk._sdkEvent, requestId });
        } else {
          _emit({ type: 'chunk', content: chunk, requestId });
        }
      }
    } else if (generator && typeof generator.then === 'function') {
      const result = await generator;
      _emit({ type: 'response', content: result, requestId });
    } else {
      _emit({ type: 'response', content: String(generator), requestId });
    }

    _emit({ type: 'done', requestId });
  } catch (err) {
    _emit({ type: 'error', error: err.message, requestId });
  }
}

/**
 * Create an approval request and return a Promise that resolves when the
 * SDK client sends approve/deny.
 * @param {string} command
 * @param {string} risk
 * @param {string} [requestId]
 * @returns {Promise<boolean>}
 */
function _createApprovalRequest(command, risk, requestId) {
  const approvalId = 'apr-' + crypto.randomBytes(4).toString('hex');

  _emit({
    type: 'permission_request',
    approvalId,
    command,
    risk: risk || 'medium',
    requestId,
  });

  return new Promise((resolve) => {
    // Auto-deny after 5 minutes if no response
    const timer = setTimeout(() => {
      _pendingApprovals.delete(approvalId);
      resolve(false);
    }, 5 * 60 * 1000);
    if (timer.unref) timer.unref();

    _pendingApprovals.set(approvalId, { resolve, timer });
  });
}

/**
 * Handle an approve/deny response from the SDK client.
 * @param {string} approvalId
 * @param {boolean} approved
 */
function _handleApprovalResponse(approvalId, approved) {
  const pending = _pendingApprovals.get(approvalId);
  if (!pending) return; // expired or unknown

  clearTimeout(pending.timer);
  _pendingApprovals.delete(approvalId);
  pending.resolve(approved);
}

function _emit(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

/**
 * Emit a structured event to the SDK client (callable from other modules).
 * @param {object} event
 */
function emitSdkEvent(event) {
  _emit(event);
}

/**
 * Check if we should run in non-interactive mode.
 */
function shouldRunNonInteractive() {
  return process.argv.includes('--non-interactive')
    || process.argv.includes('--headless')
    || process.argv.includes('-H')
    || !process.stdin.isTTY;
}

module.exports = { startNonInteractive, shouldRunNonInteractive, emitSdkEvent };
