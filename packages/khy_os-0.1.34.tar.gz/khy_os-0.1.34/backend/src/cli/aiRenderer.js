/**
 * AI Output Renderer — Claude Code-style terminal output.
 *
 * 1:1 replication of Claude Code's visual system:
 *   - ⏺ dot indicators (not emoji) with exact RGB colors
 *   - English tool names: Bash, Read, Write, Search, Update
 *   - Red/green diff with word-level highlights
 *   - Tree-style collapsible tool use display
 *
 * Color reference (Claude Code dark theme):
 *   claude:    rgb(215,119,87)  — brand orange
 *   success:   rgb(78,186,101)  — green
 *   error:     rgb(255,107,128) — red/pink
 *   warning:   rgb(255,193,7)   — amber
 *   subtle:    rgb(80,80,80)    — dim gray
 *   bashBorder:rgb(253,93,177)  — pink
 *   diffAdded: rgb(34,92,43)    — deep green bg
 *   diffRemoved:rgb(122,41,54)  — deep red bg
 *   diffAddedWord: rgb(56,166,96) — bright green word highlight
 *   diffRemovedWord:rgb(179,89,107)— bright red word highlight
 */
let _chalk;
const c = () => (_chalk ??= (require('chalk').default || require('chalk')));
const { displayWidth, padToWidth, truncateToWidth } = require('./formatters');
let _interactiveGuard = null;

// ── Claude Code Theme Colors ───────────────────────────────────────────
// Theme is now data-driven via themeRegistry. THEME is a Proxy for backward compat.
const themeRegistry = require('./themeRegistry');
const THEME = new Proxy({}, {
  get(_, prop) { return themeRegistry.getTheme().colors[prop]; },
  ownKeys() { return Object.keys(themeRegistry.getTheme().colors); },
  getOwnPropertyDescriptor(_, prop) {
    const colors = themeRegistry.getTheme().colors;
    if (prop in colors) return { value: colors[prop], enumerable: true, configurable: true };
  },
  has(_, prop) { return prop in themeRegistry.getTheme().colors; },
});

function setInteractiveGuard(fn) {
  _interactiveGuard = typeof fn === 'function' ? fn : null;
}

function isInteractiveInputActive() {
  try {
    return !!(_interactiveGuard && _interactiveGuard());
  } catch {
    return false;
  }
}

// ── Dynamic Spinner (Claude Code SpinnerGlyph exact match) ────────────
// Spinner sequence adapted for Khy-OS parity:
// keep the first frame as a solid dot, then cycle sparkle glyphs.
// Animation bounces forward then reverse for smooth cycling.
function _getSpinnerCharacters() {
  const theme = themeRegistry.getTheme();
  if (theme.spinnerChars) {
    const key = process.platform === 'darwin' ? 'darwin' : 'fallback';
    if (theme.spinnerChars[key]) return theme.spinnerChars[key];
  }
  if (process.platform === 'darwin') {
    return ['●', '✢', '✳', '✶', '✻', '✽'];
  }
  return ['●', '*', '+', '×', '+', '*'];
}
const _SPINNER_CHARS = _getSpinnerCharacters();
// Bounce: forward + reverse (excluding endpoints to avoid double-pause)
const SPINNER_FRAMES = [..._SPINNER_CHARS, ..._SPINNER_CHARS.slice(1, -1).reverse()];
const SPINNER_ACTIVE_CHAR = _SPINNER_CHARS[0];
const REDUCED_MOTION_DOT = SPINNER_ACTIVE_CHAR;

// Claude Code rotates through creative verbs for the thinking phase
const THINKING_VERBS = themeRegistry.getTheme().thinkingVerbs || [
  'Thinking', 'Reasoning', 'Inferring', 'Analyzing', 'Considering',
  'Evaluating', 'Reflecting', 'Pondering', 'Processing', 'Pollinating',
];

const PHASE_LABELS = Object.assign({
  init:       '正在初始化',
  security:   '安全检查中',
  preprocess: '预处理中',
  request:    '思考中',
  thinking:   '思考中',
  analyzing:  '正在分析',
  generating: '正在生成',
  tools:      '正在执行工具',
  explore:    '正在搜索',
  reading:    '正在读取文件',
  writing:    '正在写入文件',
  tool:       '正在执行工具',
  done:       '完成',
  // 工具级细粒度标签 (G7)
  'tool:bash':       '正在执行命令',
  'tool:shell':      '正在执行命令',
  'tool:read':       '正在读取文件',
  'tool:readfile':   '正在读取文件',
  'tool:write':      '正在写入文件',
  'tool:writefile':  '正在写入文件',
  'tool:createfile': '正在创建文件',
  'tool:edit':       '正在编辑文件',
  'tool:editfile':   '正在编辑文件',
  'tool:multiedit':  '正在编辑文件',
  'tool:glob':       '正在搜索文件',
  'tool:grep':       '正在搜索代码',
  'tool:find':       '正在搜索文件',
  'tool:search':     '正在搜索',
  'tool:websearch':  '正在联网搜索',
  'tool:webfetch':   '正在抓取网页',
  'tool:agent':      '子代理执行中',
  'tool:task':       '任务执行中',
  'tool:todowrite':  '正在更新待办',
  'tool:notebookedit': '正在编辑笔记',
  'tool:ls':         '正在列出文件',
}, themeRegistry.getTheme().phaseLabels);

/**
 * Format elapsed seconds into human-readable "Xm Ys" or "Xs".
 */
function _formatElapsed(totalSec) {
  const sec = Math.floor(totalSec);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  const rem = sec % 60;
  return rem > 0 ? `${min}m ${rem}s` : `${min}m`;
}

// Map tool names to Claude Code's userFacingName
const _defaultToolNames = {
  bash:          'Bash',
  shell:         'Bash',
  shellcommand:  'Bash',
  command:       'Bash',
  read:          'Read',
  readfile:      'Read',
  write:         'Write',
  writefile:     'Write',
  createfile:    'Write',
  edit:          'Update',
  editfile:      'Update',
  multiedit:     'Update',
  notebookedit:  'Update',
  glob:          'Search',
  grep:          'Search',
  find:          'Search',
  findfiles:     'Search',
  search:        'Search',
  searchcontent: 'Search',
  websearch:     'Search',
  webfetch:      'Fetch',
  todowrite:     'Todo',
  notebookread:  'Read',
  agent:         'Agent',
  task:          'Task',
  ls:            'Search',
};
const TOOL_DISPLAY_NAMES = Object.assign({}, _defaultToolNames, themeRegistry.getTheme().toolDisplayNames);

const TOOL_KIND_ALIASES = {
  read: 'reading',
  readfile: 'reading',
  ls: 'explore',
  glob: 'explore',
  grep: 'explore',
  find: 'explore',
  findfiles: 'explore',
  search: 'explore',
  searchcontent: 'explore',
  websearch: 'explore',
  webfetch: 'explore',
  todowrite: 'tools',
  notebookread: 'reading',
  task: 'explore',
  bash: 'explore',
  shell: 'explore',
  shellcommand: 'explore',
  command: 'explore',
  write: 'writing',
  writefile: 'writing',
  createfile: 'writing',
  edit: 'writing',
  editfile: 'writing',
  multiedit: 'writing',
  notebookedit: 'writing',
};

class DynamicSpinner {
  constructor() {
    this._frame = 0;
    this._timer = null;
    this._phase = 'init';
    this._detail = '';
    this._startTime = Date.now();
    this._phaseStartTime = Date.now();
    this._inputTokens = 0;   // ↑ tokens sent
    this._outputTokens = 0;  // ↓ tokens received
    this._effort = '';        // 'low' | 'medium' | 'high' | ''
    this._blinkState = true;
    this._verbIndex = 0;
    this._verbRotateAt = 0;  // frame count when we last rotated verb
    this._tipShown = false;
    this._lastTokenAt = Date.now(); // Track last token arrival for stall detection
    this._promptShown = false;
    this._promptLines = 0;
    this._promptMode = 'plain'; // 'plain' | 'framed'
    this._promptRuleColor = THEME.claude;
    this._promptFooter = '';
    // Keep cursor on the interjection input line while spinner updates above.
    this._spinnerOffsetFromPrompt = 0;
    this._promptCursorAnchored = false;
  }

  start(phase = 'init') {
    if (this._timer) this.stop();
    this._phase = phase;
    this._phaseStartTime = Date.now();
    if (!this._startTime || phase === 'request') this._startTime = Date.now();
    this._lastTokenAt = Date.now();
    this._timer = setInterval(() => this._render(), 120); // ~8fps matching Claude Code
  }

  setPhase(phase, detail = '') {
    this._phase = phase;
    this._detail = detail;
    this._phaseStartTime = Date.now();
  }

  /**
   * Reset the elapsed timer to now. Call this when the first SSE event
   * arrives so the displayed time reflects actual processing, not TTFB.
   */
  resetTimer() {
    this._startTime = Date.now();
    this._lastTokenAt = Date.now();
  }

  setTokens(count, direction = 'output') {
    if (direction === 'input') {
      this._inputTokens = count;
    } else {
      this._outputTokens = count;
      this._lastTokenAt = Date.now(); // Reset stall timer on new tokens
    }
  }

  setEffort(level) {
    this._effort = level || '';
  }

  /**
   * Configure how interjection prompt is rendered while spinner is active.
   * @param {'plain'|'framed'} mode
   * @param {{ruleColor?: string, footer?: string}} [opts]
   */
  setPromptMode(mode = 'plain', opts = {}) {
    this._promptMode = (mode === 'framed') ? 'framed' : 'plain';
    this._promptRuleColor = String(opts.ruleColor || THEME.claude);
    this._promptFooter = String(opts.footer || '');
  }

  _getThinkingVerb() {
    // Rotate through creative verbs every ~8 seconds (67 frames at 120ms)
    if (this._frame - this._verbRotateAt >= 67) {
      this._verbIndex = (this._verbIndex + 1) % THINKING_VERBS.length;
      this._verbRotateAt = this._frame;
    }
    return THINKING_VERBS[this._verbIndex];
  }

  _render() {
    if (!process.stdout.isTTY) return;
    if (isInteractiveInputActive()) return;
    if (process.stdin.isRaw) return;

    let _sync;
    try { _sync = require('./syncOutput'); } catch { _sync = null; }
    if (_sync) _sync.beginSync();
    try {
      this._renderInner();
    } finally {
      if (_sync) _sync.endSync();
    }
  }

  _renderInner() {

    this._blinkState = !this._blinkState;
    this._frame++;

    const elapsedSec = (Date.now() - this._startTime) / 1000;
    const elapsedStr = _formatElapsed(elapsedSec);

    // Determine label — rotate verbs for thinking/request phases;
    // for tool phases, prefer tool-specific Chinese label (G7)
    let label;
    if (this._phase === 'thinking' || this._phase === 'request') {
      label = this._getThinkingVerb();
    } else if (this._detail && PHASE_LABELS[`tool:${this._detail.toLowerCase().replace(/[\s_-]/g, '')}`]) {
      label = PHASE_LABELS[`tool:${this._detail.toLowerCase().replace(/[\s_-]/g, '')}`];
    } else {
      label = PHASE_LABELS[this._phase] || this._phase;
    }

    const detail = this._detail ? ` ${this._detail}` : '';

    // Build status parts: (Xm Ys · ↑ 10.3k tokens · thinking with high effort)
    const fmtTokens = (n) => {
      if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
      return String(n);
    };
    const parts = [elapsedStr];
    if (this._inputTokens > 0) {
      parts.push(`↑ ${fmtTokens(this._inputTokens)} tokens`);
    }
    if (this._outputTokens > 0) {
      parts.push(`↓ ${fmtTokens(this._outputTokens)} tokens`);
    }
    if (this._effort && (this._effort === 'max' || this._effort === 'high')) {
      parts.push(`extended thinking · ${this._effort}`);
    } else if (this._effort) {
      parts.push(this._effort);
    }
    const statusStr = parts.join(' · ');

    // Active polling indicator: solid dot (Claude-style, no sparkle in main line)
    const spinnerChar = SPINNER_ACTIVE_CHAR;

    // Stall detection (Claude Code style): based on time since last token,
    // not phase start. 3s threshold → yellow hint, 8s → red.
    const stallSec = (Date.now() - this._lastTokenAt) / 1000;
    let charColor;
    if (stallSec > 8) {
      // Deep stall: interpolate toward error red over 12s
      const t = Math.min(1, (stallSec - 8) / 12);
      const r = Math.round(215 + (255 - 215) * t);
      const g = Math.round(119 + (107 - 119) * t);
      const b = Math.round(87 + (128 - 87) * t);
      charColor = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    } else if (stallSec > 3) {
      // Early stall: interpolate from brand to amber over 5s
      const t = Math.min(1, (stallSec - 3) / 5);
      const r = Math.round(215 + (255 - 215) * t);
      const g = Math.round(119 + (193 - 119) * t);
      const b = Math.round(87 + (7 - 87) * t);
      charColor = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    } else {
      charColor = THEME.text;
    }

    const dot = c().hex(charColor)(spinnerChar);
    const line = `${dot} ${c().hex(THEME.text)(label + '...')}${c().dim(detail)} ${c().dim(`(${statusStr})`)}`;

    if (!this._promptShown) {
      // First render: draw spinner + prompt scaffold.
      process.stdout.write(`\r\x1b[K${line}`);
      this._promptShown = true;
      if (this._promptMode === 'framed') {
        const width = process.stdout.columns || 80;
        const rule = c().hex(this._promptRuleColor)('─'.repeat(width));
        const footer = this._promptFooter ? `\n${this._promptFooter}` : '';
        process.stdout.write(`\n${rule}\n> \n${rule}${footer}`);
        this._promptLines = this._promptFooter ? 4 : 3;
        // Cursor should stay on prompt line, spinner line is 2 rows above.
        this._spinnerOffsetFromPrompt = 2;
        this._promptCursorAnchored = true;
        // Footer mode: move up 2 lines (footer -> bottom rule -> prompt).
        // No footer: move up 1 line (bottom rule -> prompt).
        process.stdout.write(`\x1b[${this._promptFooter ? 2 : 1}A`);
        process.stdout.write('\r');
        try { require('readline').cursorTo(process.stdout, 2); } catch { /* best effort */ }
      } else {
        process.stdout.write('\n> ');
        this._promptLines = 1;
        // Plain mode keeps cursor on prompt line, spinner line is 1 row above.
        this._spinnerOffsetFromPrompt = 1;
        this._promptCursorAnchored = true;
      }
    } else if (this._promptCursorAnchored && this._spinnerOffsetFromPrompt > 0) {
      // Keep user cursor on input line while updating spinner line above.
      process.stdout.write('\x1b[s');
      process.stdout.write(`\x1b[${this._spinnerOffsetFromPrompt}A`);
      process.stdout.write(`\r\x1b[K${line}`);
      process.stdout.write('\x1b[u');
    } else {
      process.stdout.write(`\r\x1b[K${line}`);
    }

    // Show tip after 5 seconds, once per spinner lifetime
    if (!this._tipShown && elapsedSec >= 5) {
      this._tipShown = true;
    }
  }

  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
    if (!isInteractiveInputActive()) {
      // Only clean up display when spinner actually rendered something.
      // When _render() was blocked (e.g. by isRaw), _promptShown stays false
      // and there is nothing to clear — blindly clearing would wipe the
      // busy interject prompt drawn by repl.js showBusyInterjectPrompt().
      if (this._promptShown) {
        if (this._promptCursorAnchored && this._spinnerOffsetFromPrompt > 0) {
          process.stdout.write(`\x1b[${this._spinnerOffsetFromPrompt}A`);
          process.stdout.write('\r\x1b[K');
          for (let i = 0; i < this._promptLines; i++) {
            process.stdout.write('\x1b[1B\r\x1b[K');
          }
          if (this._promptLines > 0) {
            process.stdout.write(`\x1b[${this._promptLines}A`);
          }
        } else {
          process.stdout.write('\r\x1b[K');
          for (let i = 0; i < this._promptLines; i++) {
            process.stdout.write('\x1b[1B\r\x1b[K');
          }
          if (this._promptLines > 0) {
            process.stdout.write(`\x1b[${this._promptLines}A`);
          }
        }
      }
      this._promptLines = 0;
      this._promptShown = false;
      this._spinnerOffsetFromPrompt = 0;
      this._promptCursorAnchored = false;
    }
  }
}

function normalizeToolKind(name = '') {
  const raw = String(name).toLowerCase().replace(/[\s_-]/g, '');
  return TOOL_KIND_ALIASES[raw] || 'tools';
}

/**
 * Map internal tool name to Claude Code's userFacingName.
 * e.g. "shell_command" → "Bash", "read_file" → "Read", "glob" → "Search"
 */
function getToolDisplayName(name = '') {
  const raw = String(name).toLowerCase().replace(/[\s_-]/g, '');
  return TOOL_DISPLAY_NAMES[raw] || name;
}

/**
 * Render a user message with gray background (Claude Code style).
 * Claude Code uses rgb(38,38,38) background for user messages.
 * @param {string} text - user message text
 */
function renderUserMessage(text) {
  // Claude Code: userMsgBg = rgb(38,38,38) — subtle dark background
  const bgColor = '#262626';
  const lines = text.split('\n');
  const maxLen = Math.max(...lines.map(l => l.length));
  console.log('');
  for (const line of lines) {
    const padded = line.padEnd(maxLen + 2);
    console.log(c().bgHex(bgColor).hex('#FFFFFF')(` ${padded}`));
  }
  console.log('');
}

function summarizeToolDetail(name = '', params = '') {
  const kind = normalizeToolKind(name);
  const text = String(params || '').trim().replace(/\s+/g, ' ');
  const short = text.length > 60 ? `${text.slice(0, 60)}...` : text;
  return { kind, short };
}

function getToolKindLabel(name = '') {
  const raw = String(name).toLowerCase().replace(/[\s_-]/g, '');
  // 优先使用 tool: 前缀的细粒度中文标签 (G7)
  if (PHASE_LABELS[`tool:${raw}`]) return PHASE_LABELS[`tool:${raw}`];
  const kind = normalizeToolKind(name);
  return PHASE_LABELS[kind] || '工具';
}

// ── Diff Renderer (Claude Code exact colors) ───────────────────────────

const DIFF_CONTEXT_LINES = 3;

/**
 * Render a unified diff with Claude Code's exact background colors.
 * Added lines: rgb(34,92,43) background
 * Removed lines: rgb(122,41,54) background
 * @@ headers: dim
 * Context lines: dim
 */
function renderDiff(diffText) {
  const lines = diffText.split('\n');
  const rendered = [];

  for (const line of lines) {
    if (line.startsWith('+++') || line.startsWith('---')) {
      rendered.push(c().bold.dim(line));
    } else if (line.startsWith('+')) {
      rendered.push(c().bgHex(THEME.diffAdded).hex('#FFFFFF')(line));
    } else if (line.startsWith('-')) {
      rendered.push(c().bgHex(THEME.diffRemoved).hex('#FFFFFF')(line));
    } else if (line.startsWith('@@')) {
      rendered.push(c().dim(line));
    } else {
      rendered.push(c().dim(line));
    }
  }

  return rendered.join('\n');
}

/**
 * Render a structured diff for file edits (Claude Code style).
 * Shows line numbers + add/remove markers with exact background colors.
 *
 * @param {string} oldContent - original file content
 * @param {string} newContent - modified file content
 * @param {string} [filePath] - file path for header
 * @returns {string} rendered diff
 */
function renderStructuredDiff(oldContent, newContent, filePath = '') {
  const oldLines = oldContent.split('\n');
  const newLines = newContent.split('\n');

  // Simple line-by-line diff (find common prefix/suffix, mark changes)
  const rendered = [];
  let i = 0, j = 0;
  const commonPrefixLen = (() => {
    let k = 0;
    while (k < oldLines.length && k < newLines.length && oldLines[k] === newLines[k]) k++;
    return k;
  })();
  const commonSuffixLen = (() => {
    let k = 0;
    while (k < (oldLines.length - commonPrefixLen) && k < (newLines.length - commonPrefixLen)
           && oldLines[oldLines.length - 1 - k] === newLines[newLines.length - 1 - k]) k++;
    return k;
  })();

  const removeStart = commonPrefixLen;
  const removeEnd = oldLines.length - commonSuffixLen;
  const addStart = commonPrefixLen;
  const addEnd = newLines.length - commonSuffixLen;

  // Context before
  const ctxStart = Math.max(0, removeStart - DIFF_CONTEXT_LINES);
  for (let k = ctxStart; k < removeStart; k++) {
    const num = String(k + 1).padStart(4);
    rendered.push(`  ${c().dim(num)}   ${c().dim(oldLines[k])}`);
  }

  // Removed lines
  for (let k = removeStart; k < removeEnd; k++) {
    const num = String(k + 1).padStart(4);
    rendered.push(c().bgHex(THEME.diffRemoved).hex('#FFFFFF')(`  ${num} - ${oldLines[k]}`));
  }

  // Added lines
  for (let k = addStart; k < addEnd; k++) {
    const num = String(k + 1).padStart(4);
    rendered.push(c().bgHex(THEME.diffAdded).hex('#FFFFFF')(`  ${num} + ${newLines[k]}`));
  }

  // Context after
  const ctxEnd = Math.min(oldLines.length, removeEnd + DIFF_CONTEXT_LINES);
  for (let k = removeEnd; k < ctxEnd; k++) {
    if (k < oldLines.length) {
      const num = String(k + 1).padStart(4);
      rendered.push(`  ${c().dim(num)}   ${c().dim(oldLines[k])}`);
    }
  }

  // Stats
  const added = addEnd - addStart;
  const removed = removeEnd - removeStart;
  const statParts = [];
  if (added > 0) statParts.push(`Added ${added} line${added !== 1 ? 's' : ''}`);
  if (removed > 0) statParts.push(`removed ${removed} line${removed !== 1 ? 's' : ''}`);
  if (statParts.length > 0) {
    rendered.push(`    ${c().dim('└')} ${c().dim(statParts.join(', '))}`);
  }

  return rendered.join('\n');
}

/**
 * Detect and render inline diffs within AI response text.
 * Looks for fenced diff blocks: ```diff ... ```
 */
function renderResponseWithDiffs(text) {
  const parts = text.split(/(```diff\n[\s\S]*?```)/g);
  const rendered = [];

  for (const part of parts) {
    if (part.startsWith('```diff\n') && part.endsWith('```')) {
      const diffContent = part.slice(8, -3);
      rendered.push(renderDiff(diffContent));
    } else {
      rendered.push(part);
    }
  }

  return rendered.join('\n');
}

// ── Inline Code Highlighting ────────────────────────────────────────────

// ── Lightweight syntax highlighting for code blocks ────────────────────────
// No external deps — regex-based keyword/string/comment/number coloring.
// Covers: JS/TS, Python, Bash, JSON, Go, Rust, SQL, CSS, HTML/XML.

const _HL_KEYWORDS_JS = new Set([
  'const','let','var','function','return','if','else','for','while','do','switch',
  'case','break','continue','new','class','extends','import','export','from','default',
  'try','catch','finally','throw','async','await','yield','typeof','instanceof','in',
  'of','this','super','null','undefined','true','false','void','delete',
]);
const _HL_KEYWORDS_PY = new Set([
  'def','class','return','if','elif','else','for','while','try','except','finally',
  'raise','import','from','as','with','pass','break','continue','yield','lambda',
  'and','or','not','in','is','None','True','False','self','async','await','global','nonlocal',
]);
const _HL_KEYWORDS_BASH = new Set([
  'if','then','else','elif','fi','for','while','do','done','case','esac','function',
  'return','exit','echo','export','source','local','readonly','declare','set','unset',
  'true','false','cd','ls','rm','cp','mv','cat','grep','sed','awk','find','sudo',
]);
const _HL_KEYWORDS_GO = new Set([
  'func','return','if','else','for','range','switch','case','break','continue','type',
  'struct','interface','map','chan','go','defer','select','import','package','var','const',
  'nil','true','false','make','append','len','cap','error','string','int','bool','byte',
]);
const _HL_KEYWORDS_RUST = new Set([
  'fn','let','mut','return','if','else','for','while','loop','match','use','mod','pub',
  'struct','enum','impl','trait','type','const','static','self','Self','where','async',
  'await','move','unsafe','extern','crate','super','true','false','None','Some','Ok','Err',
]);
const _HL_KEYWORDS_SQL = new Set([
  'select','from','where','insert','update','delete','create','drop','alter','table',
  'into','values','set','join','left','right','inner','outer','on','and','or','not',
  'null','order','by','group','having','limit','offset','as','distinct','count','sum',
  'avg','max','min','like','in','between','exists','union','index','primary','key',
]);

function _getKeywordSet(lang) {
  const l = String(lang || '').toLowerCase();
  if (l === 'js' || l === 'javascript' || l === 'ts' || l === 'typescript' || l === 'jsx' || l === 'tsx') return _HL_KEYWORDS_JS;
  if (l === 'py' || l === 'python') return _HL_KEYWORDS_PY;
  if (l === 'bash' || l === 'sh' || l === 'shell' || l === 'zsh') return _HL_KEYWORDS_BASH;
  if (l === 'go' || l === 'golang') return _HL_KEYWORDS_GO;
  if (l === 'rust' || l === 'rs') return _HL_KEYWORDS_RUST;
  if (l === 'sql') return _HL_KEYWORDS_SQL;
  // Default: JS keywords (most common in AI output)
  return _HL_KEYWORDS_JS;
}

/**
 * Highlight a single code line with lightweight syntax coloring.
 * @param {string} line - raw code line
 * @param {string} lang - language hint from code fence
 * @returns {string} ANSI-colored line
 */
function _highlightCodeLine(line, lang) {
  if (!line) return line;
  const l = String(lang || '').toLowerCase();

  // JSON: special handling (keys, strings, numbers, booleans)
  if (l === 'json' || l === 'jsonc') {
    return line
      .replace(/"([^"\\]|\\.)*"\s*:/g, (m) => c().cyan(m))       // keys
      .replace(/:\s*"([^"\\]|\\.)*"/g, (m) => c().green(m))       // string values
      .replace(/:\s*(-?\d+\.?\d*)/g, (_, n) => ': ' + c().yellow(n)) // numbers
      .replace(/:\s*(true|false|null)/g, (_, v) => ': ' + c().magenta(v)); // booleans
  }

  // HTML/XML: tag coloring
  if (l === 'html' || l === 'xml' || l === 'svg' || l === 'vue') {
    return line
      .replace(/(<\/?[\w-]+)/g, (m) => c().hex('#FF6B6B')(m))        // tags
      .replace(/([\w-]+)=/g, (_, attr) => c().cyan(attr) + '=')      // attributes
      .replace(/"([^"]*)"/g, (m) => c().green(m))                    // strings
      .replace(/<!--[\s\S]*?-->/g, (m) => c().dim(m));               // comments
  }

  // CSS: property/value coloring
  if (l === 'css' || l === 'scss' || l === 'less') {
    return line
      .replace(/([\w-]+)\s*:/g, (_, prop) => c().cyan(prop) + ':')   // properties
      .replace(/#[0-9a-fA-F]{3,8}\b/g, (m) => c().yellow(m))        // hex colors
      .replace(/\d+\.?\d*(px|em|rem|%|vh|vw|s|ms)/g, (m) => c().yellow(m)) // units
      .replace(/\/\*[\s\S]*?\*\//g, (m) => c().dim(m));              // comments
  }

  // General: keyword/string/comment/number highlighting
  const keywords = _getKeywordSet(lang);
  const isBash = l === 'bash' || l === 'sh' || l === 'shell' || l === 'zsh';
  const isPython = l === 'py' || l === 'python';

  // Tokenize with simple regex: strings → comments → numbers → keywords → rest
  let result = '';
  let i = 0;
  const src = line;

  while (i < src.length) {
    // Line comments: // or # (bash/python)
    if ((src[i] === '/' && src[i + 1] === '/') || ((isBash || isPython) && src[i] === '#')) {
      result += c().dim(src.slice(i));
      break;
    }
    // String: single or double quotes
    if (src[i] === '"' || src[i] === "'") {
      const quote = src[i];
      let j = i + 1;
      while (j < src.length && src[j] !== quote) {
        if (src[j] === '\\') j++; // skip escaped char
        j++;
      }
      j = Math.min(j + 1, src.length);
      result += c().green(src.slice(i, j));
      i = j;
      continue;
    }
    // Template literal
    if (src[i] === '`') {
      let j = i + 1;
      while (j < src.length && src[j] !== '`') {
        if (src[j] === '\\') j++;
        j++;
      }
      j = Math.min(j + 1, src.length);
      result += c().green(src.slice(i, j));
      i = j;
      continue;
    }
    // Number
    if (/\d/.test(src[i]) && (i === 0 || /[\s,([{=:+\-*/<>!&|^~%]/.test(src[i - 1]))) {
      let j = i;
      while (j < src.length && /[\d.xXoObBeEa-fA-F_]/.test(src[j])) j++;
      result += c().yellow(src.slice(i, j));
      i = j;
      continue;
    }
    // Word (potential keyword)
    if (/[a-zA-Z_$]/.test(src[i])) {
      let j = i;
      while (j < src.length && /[a-zA-Z0-9_$]/.test(src[j])) j++;
      const word = src.slice(i, j);
      if (keywords.has(word)) {
        result += c().magenta(word);
      } else {
        result += word;
      }
      i = j;
      continue;
    }
    // Operator chars
    if (/[=<>!&|+\-*/%^~?:]/.test(src[i])) {
      result += c().hex('#888888')(src[i]);
      i++;
      continue;
    }
    result += src[i];
    i++;
  }

  return result;
}

/**
 * Light markdown rendering for AI responses.
 * Handles: headers, inline code, code blocks, bold.
 */
// ── Markdown render cache (DeepSeek-style: avoid re-parsing identical blocks) ──
// LRU cache keyed by (content + terminal_width). Cache hit avoids all regex work.
const _mdCache = new Map();
const _MD_CACHE_MAX = 200;
let _mdCacheLastCols = 0;

function _mdCacheGet(text) {
  const cols = process.stdout.columns || 80;
  // Invalidate entire cache on terminal resize (width affects table/rule rendering)
  if (cols !== _mdCacheLastCols) {
    _mdCache.clear();
    _mdCacheLastCols = cols;
    return undefined;
  }
  return _mdCache.get(text);
}

function _mdCacheSet(text, rendered) {
  if (_mdCache.size >= _MD_CACHE_MAX) {
    // Evict oldest entry (first key in insertion order)
    const firstKey = _mdCache.keys().next().value;
    _mdCache.delete(firstKey);
  }
  _mdCache.set(text, rendered);
}

function renderMarkdownLite(text) {
  // Check cache first
  const cached = _mdCacheGet(text);
  if (cached !== undefined) return cached;

  const rendered = _renderMarkdownLiteInner(text);
  _mdCacheSet(text, rendered);
  return rendered;
}

// ── LaTeX to Unicode terminal-friendly conversion ──────────────────────
const _latexSymbolMap = {
  '\\times': '\u00D7', '\\cdot': '\u00B7', '\\div': '\u00F7',
  '\\pm': '\u00B1', '\\mp': '\u2213', '\\leq': '\u2264', '\\geq': '\u2265',
  '\\neq': '\u2260', '\\approx': '\u2248', '\\equiv': '\u2261',
  '\\infty': '\u221E', '\\sqrt': '\u221A',
  '\\sum': '\u2211', '\\prod': '\u220F', '\\int': '\u222B',
  '\\partial': '\u2202', '\\nabla': '\u2207',
  '\\alpha': '\u03B1', '\\beta': '\u03B2', '\\gamma': '\u03B3',
  '\\delta': '\u03B4', '\\epsilon': '\u03B5', '\\zeta': '\u03B6',
  '\\eta': '\u03B7', '\\theta': '\u03B8', '\\iota': '\u03B9',
  '\\kappa': '\u03BA', '\\lambda': '\u03BB', '\\mu': '\u03BC',
  '\\nu': '\u03BD', '\\xi': '\u03BE', '\\pi': '\u03C0',
  '\\rho': '\u03C1', '\\sigma': '\u03C3', '\\tau': '\u03C4',
  '\\upsilon': '\u03C5', '\\phi': '\u03C6', '\\chi': '\u03C7',
  '\\psi': '\u03C8', '\\omega': '\u03C9',
  '\\Delta': '\u0394', '\\Gamma': '\u0393', '\\Lambda': '\u039B',
  '\\Sigma': '\u03A3', '\\Omega': '\u03A9', '\\Pi': '\u03A0',
  '\\Theta': '\u0398', '\\Phi': '\u03A6', '\\Psi': '\u03A8',
  '\\leftarrow': '\u2190', '\\rightarrow': '\u2192',
  '\\leftrightarrow': '\u2194', '\\Rightarrow': '\u21D2',
  '\\Leftarrow': '\u21D0', '\\Leftrightarrow': '\u21D4',
  '\\forall': '\u2200', '\\exists': '\u2203',
  '\\in': '\u2208', '\\notin': '\u2209',
  '\\subset': '\u2282', '\\supset': '\u2283',
  '\\cup': '\u222A', '\\cap': '\u2229',
  '\\emptyset': '\u2205', '\\varnothing': '\u2205',
  '\\land': '\u2227', '\\lor': '\u2228', '\\neg': '\u00AC',
  '\\ldots': '\u2026', '\\cdots': '\u22EF', '\\vdots': '\u22EE',
  '\\quad': '  ', '\\qquad': '    ',
  '\\,': ' ', '\\;': ' ', '\\!': '',
  '\\text': '', '\\textbf': '', '\\mathrm': '', '\\mathbf': '',
};

// Sorted by length desc so longer commands match first
const _latexSymbolKeys = Object.keys(_latexSymbolMap).sort((a, b) => b.length - a.length);

function _latexToUnicode(latex) {
  let s = String(latex || '');
  // \frac{a}{b} -> a/b
  s = s.replace(/\\frac\{([^}]*)}\{([^}]*)}/g, '($1/$2)');
  // \sqrt{x} -> √(x)
  s = s.replace(/\\sqrt\{([^}]*)}/g, '\u221A($1)');
  // \text{...}, \textbf{...}, \mathrm{...}, \mathbf{...} -> contents
  s = s.replace(/\\(?:text|textbf|mathrm|mathbf)\{([^}]*)}/g, '$1');
  // x^{exp} -> x^exp, x_{sub} -> x_sub
  s = s.replace(/\^{([^}]*)}/g, '^$1');
  s = s.replace(/_{([^}]*)}/g, '_$1');
  // Replace known symbols
  for (const key of _latexSymbolKeys) {
    if (s.includes(key)) {
      s = s.split(key).join(_latexSymbolMap[key]);
    }
  }
  // Remove remaining braces
  s = s.replace(/[{}]/g, '');
  return s.trim();
}

function _renderLatexFormulas(text) {
  // Block formulas: $$...$$ (possibly multiline)
  text = text.replace(/\$\$([\s\S]*?)\$\$/g, (_m, formula) => {
    const rendered = _latexToUnicode(formula);
    return `\n  ${c().yellow(rendered)}\n`;
  });
  // Inline formulas: $...$ (single line, not empty, not starting with space on both sides)
  text = text.replace(/(?<!\$)\$(?!\$)([^\n$]+?)\$(?!\$)/g, (_m, formula) => {
    return c().yellow(_latexToUnicode(formula));
  });
  return text;
}

function _renderMarkdownLiteInner(text) {
  text = _normalizeListAndRuleArtifacts(text);

  // Pre-pass: render tables before other transforms
  text = _renderMarkdownTables(text);

  // Strip common AI wrapper XML tags (execution_plan, thinking, etc.)
  text = text.replace(/<\/?(?:execution_plan|thinking|plan|reasoning|steps|analysis|output)>/gi, '');

  // Render deeply nested lists as trees before bullet replacement
  text = _renderNestedListTrees(text);

  // LaTeX formulas: convert $...$ and $$...$$ to Unicode math symbols.
  // Must run before the main replace chain because $ can conflict with other patterns.
  // Code blocks are already extracted by the chain below (they get ANSI codes),
  // so we protect them by extracting ```...``` first, rendering LaTeX, then restoring.
  const _codeBlockPlaceholders = [];
  text = text.replace(/```[\s\S]*?```/g, (m) => {
    _codeBlockPlaceholders.push(m);
    return `\x00CB${_codeBlockPlaceholders.length - 1}\x00`;
  });
  text = _renderLatexFormulas(text);
  text = text.replace(/\x00CB(\d+)\x00/g, (_m, idx) => _codeBlockPlaceholders[Number(idx)]);

  return text
    // Code blocks (```...```) — syntax-highlighted, intercept mermaid mindmaps
    .replace(/```(\w*)\n([\s\S]*?)```/g, (_m, lang, code) => {
      if (lang.toLowerCase() === 'mermaid') {
        const rendered = _renderMermaidBlock(code);
        if (rendered) return rendered;
      }
      const langTag = lang ? c().dim(` ${lang}`) : '';
      const codeLines = code.split('\n').map(l => `  ${c().dim('│')} ${_highlightCodeLine(l, lang)}`).join('\n');
      return `${c().dim('  ┌──')}${langTag}\n${codeLines}\n${c().dim('  └──')}`;
    })
    // Horizontal rules (---, ***, ___)
    .replace(/^(\s*)[-*_]{3,}\s*$/gm, (_m, indent) => {
      const cols = (process.stdout.columns || 80) - 6;
      return `${indent}${c().dim('─'.repeat(Math.max(10, cols)))}`;
    })
    // Headers
    .replace(/^(#{1,3})\s+(.+)$/gm, (_m, hashes, title) => {
      return c().bold.cyan(`  ${title}`);
    })
    // Bold
    .replace(/\*\*(.+?)\*\*/g, (_m, text) => c().bold(text))
    // Italic
    .replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, (_m, text) => c().italic(text))
    // Inline code
    .replace(/`([^`]+)`/g, (_m, code) => c().cyan(code))
    // Links [text](url) — show text underlined, url dimmed
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, text, url) => {
      return `${c().hex(THEME.link).underline(text)} ${c().dim(`(${url})`)}`;
    })
    // Numbered lists (1. 2. 3.)
    .replace(/^(\s*)\d+\.\s+/gm, (_m, indent) => {
      return `${indent}${c().dim('›')} `;
    })
    // Bullet lists
    .replace(/^(\s*)[-*]\s+/gm, '$1• ')
    // Blockquotes (> text)
    .replace(/^>\s*(.*)/gm, (_m, text) => {
      return `  ${c().dim('│')} ${c().dim(text)}`;
    });
}

function _normalizeListAndRuleArtifacts(text) {
  let normalized = String(text || '');
  // Fix malformed list blocks where "-" / "1." and content are split by newline.
  normalized = normalized
    .replace(/^(\s*[-*])\s*\n\s+/gm, '$1 ')
    .replace(/^(\s*\d+\.)\s*\n\s+/gm, '$1 ');
  // Deduplicate accidentally repeated leading sentence:
  // "A。A。..." -> "A。..."
  normalized = _dedupeLeadingSentence(normalized);
  // Drop dangling half-sentences that are often emitted before a fuller line.
  normalized = _dropDanglingLeadFragments(normalized);
  // Some model outputs accidentally prefix long separators with a stray "m".
  normalized = normalized.replace(/^[mM]\s*([─-]{10,})\s*$/gm, '$1');
  return normalized;
}

function _dedupeLeadingSentence(text) {
  const src = String(text || '');
  return src.replace(
    /^([^\n。！？!?]{2,120}[。！？!?])(?:\s*\1){1,2}\s*/u,
    '$1'
  );
}

function _dropDanglingLeadFragments(text) {
  const lines = String(text || '').split('\n');
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const cur = String(lines[i] || '').trim();
    if (/^(?:好[的吧呀]?[，,]?\s*)?帮$/.test(cur)) {
      const next = String(lines[i + 1] || '').trim();
      const next2 = String(lines[i + 2] || '').trim();
      const next3 = String(lines[i + 3] || '').trim();
      if (/^帮你/.test(next) || /^帮你/.test(next2) || /^帮你/.test(next3)) {
        continue;
      }
    }
    out.push(lines[i]);
  }
  return out.join('\n');
}

/**
 * Render Markdown tables with aligned columns using Unicode box drawing.
 * Detects table blocks (lines starting with |) and replaces them with
 * aligned, box-drawn tables.
 */
function _renderMarkdownTables(text) {
  const lines = text.split('\n');
  const cols = process.stdout.columns || 80;

  // Pass 1: collect table blocks with positions
  const tableBlocks = [];
  let i = 0;
  while (i < lines.length) {
    if (/^\s*\|.*\|/.test(lines[i])) {
      const tableLines = [];
      const startIdx = i;
      while (i < lines.length) {
        if (/^\s*\|.*\|/.test(lines[i])) {
          // Check if this is a new table header (has a separator next line)
          if (tableLines.length >= 2 && i + 1 < lines.length &&
              /^\|[\s:]*[-]+[\s:]*(\|[\s:]*[-]+[\s:]*)*\|$/.test(lines[i + 1]?.trim() || '')) {
            break; // new table starts here, stop current block
          }
          tableLines.push(lines[i]);
          i++;
        } else if (lines[i].trim() === '' && i + 1 < lines.length && /^\s*\|.*\|/.test(lines[i + 1])) {
          // Blank line followed by pipe-line: check if it's a new table (has separator after)
          if (i + 2 < lines.length && /^\|[\s:]*[-]+[\s:]*(\|[\s:]*[-]+[\s:]*)*\|$/.test(lines[i + 2]?.trim() || '')) {
            break; // blank + header + separator = new table
          }
          // Otherwise it's a blank inside current table (model artifact)
          i++;
        } else {
          break;
        }
      }
      if (tableLines.length >= 2) {
        tableBlocks.push({ lines: tableLines, startIdx, endIdx: i });
      }
    } else {
      i++;
    }
  }

  if (tableBlocks.length === 0) return text;

  // Pass 2: detect pairs
  const directives = _detectAdjacentTablePairs(tableBlocks, lines);

  // Pass 3: render — rebuild output from original lines + rendered tables
  const out = [];
  let lineIdx = 0;
  for (const dir of directives) {
    if (dir.type === 'pair') {
      // Emit non-table lines before the left table
      while (lineIdx < dir.left.startIdx) { out.push(lines[lineIdx++]); }
      // Skip all lines covered by the pair (left table + gap + right table)
      lineIdx = dir.right.endIdx;

      if (cols > 120) {
        out.push(_renderSideBySideTables(dir.left.lines, dir.right.lines, undefined, undefined));
      } else {
        // Narrow terminal: unified column widths if same column count
        const leftData = _parseTableData(dir.left.lines);
        const rightData = _parseTableData(dir.right.lines);
        if (leftData.colCount === rightData.colCount && leftData.colCount > 0) {
          const unified = [];
          for (let c = 0; c < leftData.colCount; c++) {
            unified.push(Math.max(leftData.colWidths[c], rightData.colWidths[c]));
          }
          out.push(_formatTable(dir.left.lines, { overrideWidths: unified }));
          if (dir.label) out.push(dir.label);
          out.push(_formatTable(dir.right.lines, { overrideWidths: unified }));
        } else {
          out.push(_formatTable(dir.left.lines));
          if (dir.label) out.push(dir.label);
          out.push(_formatTable(dir.right.lines));
        }
      }
    } else {
      // Single table
      while (lineIdx < dir.block.startIdx) { out.push(lines[lineIdx++]); }
      lineIdx = dir.block.endIdx;
      out.push(_formatTable(dir.block.lines));
    }
  }
  // Emit remaining lines after the last table
  while (lineIdx < lines.length) { out.push(lines[lineIdx++]); }

  return out.join('\n');
}

/**
 * Parse markdown table lines into structured data.
 * @param {string[]} tableLines - raw markdown pipe-delimited lines
 * @returns {{ rows: string[][], colCount: number, colWidths: number[] }}
 */
function _parseTableData(tableLines) {
  const rows = [];
  for (let i = 0; i < tableLines.length; i++) {
    const line = tableLines[i].trim();
    if (/^\|[\s:]*[-]+[\s:]*(\|[\s:]*[-]+[\s:]*)*\|$/.test(line)) continue;
    const cells = line.split('|')
      .map(cell => cell.trim())
      .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
    rows.push(cells);
  }
  if (rows.length === 0) return { rows: [], colCount: 0, colWidths: [] };
  const colCount = Math.max(...rows.map(r => r.length));
  const colWidths = Array(colCount).fill(0);
  for (const row of rows) {
    for (let col = 0; col < colCount; col++) {
      const cell = row[col] || '';
      colWidths[col] = Math.max(colWidths[col], displayWidth(cell));
    }
  }
  for (let col = 0; col < colCount; col++) {
    colWidths[col] = Math.max(colWidths[col], 3);
  }
  return { rows, colCount, colWidths };
}

/**
 * Render parsed table data into box-drawn lines (array).
 * @param {{ rows: string[][], colCount: number, colWidths: number[] }} data
 * @returns {string[]}
 */
function _formatTableFromData(data) {
  const { rows, colCount, colWidths } = data;
  if (rows.length === 0) return [];
  const result = [];
  const dim = c().dim.bind(c());
  result.push(dim('  ╭' + colWidths.map(w => '─'.repeat(w + 2)).join('┬') + '╮'));
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    const cells = [];
    for (let col = 0; col < colCount; col++) {
      const cell = row[col] || '';
      cells.push(' ' + padToWidth(cell, colWidths[col]) + ' ');
    }
    result.push(dim('  │') + cells.join(dim('│')) + dim('│'));
    if (r === 0 && rows.length > 1) {
      result.push(dim('  ├' + colWidths.map(w => '─'.repeat(w + 2)).join('┼') + '┤'));
    }
  }
  result.push(dim('  ╰' + colWidths.map(w => '─'.repeat(w + 2)).join('┴') + '╯'));
  return result;
}

/**
 * Format a set of markdown table lines into an aligned box-drawn table.
 * @param {string[]} tableLines
 * @param {{ overrideWidths?: number[] }} [opts]
 * @returns {string}
 */
function _formatTable(tableLines, opts = {}) {
  const data = _parseTableData(tableLines);
  if (data.rows.length === 0) return tableLines.join('\n');
  if (opts.overrideWidths) {
    for (let i = 0; i < data.colWidths.length; i++) {
      data.colWidths[i] = Math.max(data.colWidths[i], opts.overrideWidths[i] || 0);
    }
  }
  return _formatTableFromData(data).join('\n');
}

/**
 * Render two tables side-by-side (when terminal is wide enough).
 * @param {string[]} leftTableLines
 * @param {string[]} rightTableLines
 * @param {string} [leftLabel]
 * @param {string} [rightLabel]
 * @returns {string}
 */
function _renderSideBySideTables(leftTableLines, rightTableLines, leftLabel, rightLabel) {
  const cols = process.stdout.columns || 80;
  const gap = '   ';
  const halfWidth = Math.floor((cols - 5) / 2);

  const leftData = _parseTableData(leftTableLines);
  const rightData = _parseTableData(rightTableLines);
  if (leftData.rows.length === 0 || rightData.rows.length === 0) {
    return _formatTable(leftTableLines) + '\n' + _formatTable(rightTableLines);
  }

  // Unify column widths if same column count
  if (leftData.colCount === rightData.colCount) {
    for (let i = 0; i < leftData.colCount; i++) {
      const unified = Math.max(leftData.colWidths[i], rightData.colWidths[i]);
      leftData.colWidths[i] = unified;
      rightData.colWidths[i] = unified;
    }
  }

  const leftLines = _formatTableFromData(leftData);
  const rightLines = _formatTableFromData(rightData);

  // Compute display width of the left table (from the first rendered line)
  const leftTableWidth = leftLines.length > 0 ? displayWidth(leftLines[0]) : 0;

  // Check if both tables fit side by side
  const rightTableWidth = rightLines.length > 0 ? displayWidth(rightLines[0]) : 0;
  if (leftTableWidth + 3 + rightTableWidth > cols) {
    // Fall back to vertical stacking
    return leftLines.join('\n') + '\n' + rightLines.join('\n');
  }

  const result = [];
  const dim = c().dim.bind(c());

  // Labels
  if (leftLabel || rightLabel) {
    const ll = leftLabel ? padToWidth('  ' + dim(leftLabel), leftTableWidth) : ' '.repeat(leftTableWidth);
    const rl = rightLabel ? '  ' + dim(rightLabel) : '';
    result.push(ll + gap + rl);
  }

  // Zip lines
  const maxRows = Math.max(leftLines.length, rightLines.length);
  const emptyLeft = ' '.repeat(leftTableWidth);
  for (let i = 0; i < maxRows; i++) {
    const left = i < leftLines.length ? padToWidth(leftLines[i], leftTableWidth) : emptyLeft;
    const right = i < rightLines.length ? rightLines[i] : '';
    result.push(left + gap + right);
  }

  return result.join('\n');
}

/**
 * Detect adjacent table pairs for side-by-side or unified-width rendering.
 * @param {Array<{ lines: string[], startIdx: number, endIdx: number }>} blocks
 * @param {string[]} allLines
 * @returns {Array<{ type: 'single'|'pair', block?: object, left?: object, right?: object, label?: string }>}
 */
function _detectAdjacentTablePairs(blocks, allLines) {
  if (blocks.length === 0) return [];
  const directives = [];
  let i = 0;
  while (i < blocks.length) {
    if (i + 1 < blocks.length) {
      const gap = allLines.slice(blocks[i].endIdx, blocks[i + 1].startIdx);
      const nonBlank = gap.filter(l => l.trim() !== '');
      const isPair = nonBlank.length === 0 ||
        (nonBlank.length === 1 && displayWidth(nonBlank[0].trim()) <= 40);
      if (isPair) {
        const label = nonBlank.length === 1 ? nonBlank[0].trim() : undefined;
        directives.push({ type: 'pair', left: blocks[i], right: blocks[i + 1], label });
        i += 2;
        continue;
      }
    }
    directives.push({ type: 'single', block: blocks[i] });
    i++;
  }
  return directives;
}

// ── Mindmap / Tree Rendering ──────────────────────────────────────────

/**
 * Parse mermaid mindmap code block into a tree structure.
 * @param {string} code - content inside ```mermaid ... ```
 * @returns {{ label: string, children: object[] } | null}
 */
function _parseMermaidMindmap(code) {
  const lines = code.replace(/\t/g, '  ').split('\n');
  let startIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (/^\s*mindmap\s*$/i.test(lines[i])) { startIdx = i + 1; break; }
  }
  if (startIdx < 0) return null;

  // Collect non-blank content lines
  const contentLines = [];
  for (let i = startIdx; i < lines.length; i++) {
    if (lines[i].trim()) contentLines.push(lines[i]);
  }
  if (contentLines.length === 0) return null;

  // Detect indent unit
  const indents = contentLines.map(l => l.match(/^(\s*)/)[1].length);
  const baseIndent = indents[0];
  let unit = 2;
  for (let i = 1; i < indents.length; i++) {
    const diff = indents[i] - baseIndent;
    if (diff > 0) { unit = diff; break; }
  }

  // Strip mermaid shape markers: id((text)), id[text], id(text), id)text(, id{{text}}
  // Only strip when the shape wraps the ENTIRE label (not content like "模型 (Ollama)")
  function cleanLabel(raw) {
    let m;
    // Double-paren: root((Central Topic))
    if ((m = raw.match(/^(\w[\w-]*)?\(\((.+)\)\)$/))) return m[2].trim();
    // Double-brace: node{{Hexagon}}
    if ((m = raw.match(/^(\w[\w-]*)?\{\{(.+)\}\}$/))) return m[2].trim();
    // Square bracket: node[Box Label]
    if ((m = raw.match(/^(\w[\w-]*)?\[(.+)\]$/))) return m[2].trim();
    // Reversed paren: node)Stadium(
    if ((m = raw.match(/^(\w[\w-]*)?\)(.+)\($/))) return m[2].trim();
    // Single paren: only strip if it looks like an identifier + shape wrapper (id(text))
    // NOT "模型 (Ollama)" which has a space before the paren
    if ((m = raw.match(/^(\w[\w-]*)\((.+)\)$/))) return m[2].trim();
    return raw.trim();
  }

  // Build tree with stack
  const root = { label: cleanLabel(contentLines[0].trim()), children: [] };
  const stack = [{ depth: 0, node: root }];

  for (let i = 1; i < contentLines.length; i++) {
    const depth = Math.round((indents[i] - baseIndent) / unit);
    const label = cleanLabel(contentLines[i].trim());
    const node = { label, children: [] };

    while (stack.length > 1 && stack[stack.length - 1].depth >= depth) stack.pop();
    stack[stack.length - 1].node.children.push(node);
    stack.push({ depth, node });
  }

  return root;
}

/**
 * Render a tree structure as ASCII art with box-drawing branch lines.
 * - Root node in bordered box (mermaid) or bold text (list tree)
 * - Depth-based color coding (cyan/green/yellow/magenta/dim)
 * - Leaf nodes marked with dim dot
 * - Stats footer for larger trees
 * @param {{ label: string, children: object[] }} root
 * @param {{ maxWidth?: number, showStats?: boolean, rootBox?: boolean }} [opts]
 * @returns {string}
 */
function _renderTree(root, opts = {}) {
  const cols = opts.maxWidth || (process.stdout.columns || 80) - 6;
  const showStats = opts.showStats !== false;
  const rootBox = opts.rootBox !== false;
  const dim = c().dim.bind(c());
  const bold = c().bold.bind(c());

  let lwt = false;
  try { lwt = require('../tools/platformUtils').isLegacyWinTerminal(); } catch { /* ignore */ }
  const T = lwt
    ? { mid: '|-', last: '`-', dash: '-- ', pipe: '|   ', blank: '    ' }
    : { mid: '├─', last: '└─', dash: '─ ', pipe: '│   ', blank: '    ' };

  // Depth color palette
  const palette = [
    c().cyan.bind(c()),
    c().green.bind(c()),
    c().yellow.bind(c()),
    c().magenta.bind(c()),
    c().dim.bind(c()),
  ];
  function clr(d) { return palette[Math.min(d, palette.length - 1)]; }

  // Stats
  let totalNodes = 0, maxDepth = 0;
  function count(n, d) { totalNodes++; if (d > maxDepth) maxDepth = d; for (const ch of n.children) count(ch, d + 1); }
  count(root, 0);

  const lines = [];

  // Root
  if (rootBox) {
    const w = Math.max(displayWidth(root.label) + 4, 12);
    lines.push(dim('  ╭') + dim('─'.repeat(w - 2)) + dim('╮'));
    lines.push(dim('  │ ') + bold(padToWidth(root.label, w - 4)) + dim(' │'));
    lines.push(dim('  ╰') + dim('┬'.repeat(1)) + dim('─'.repeat(w - 3)) + dim('╯'));
  } else {
    lines.push('  ' + bold(root.label));
  }

  function walk(node, prefix, isLast, depth) {
    const branch = isLast ? T.last : T.mid;
    const cont = isLast ? T.blank : T.pipe;
    const maxW = Math.max(10, cols - displayWidth(prefix) - 8);
    const label = truncateToWidth(node.label, maxW);
    const isLeaf = node.children.length === 0;
    const color = clr(depth);
    const branchStr = dim('  ' + prefix + branch + T.dash);

    if (isLeaf) {
      lines.push(branchStr + dim('· ') + color(label));
    } else {
      lines.push(branchStr + color(label));
    }

    for (let i = 0; i < node.children.length; i++) {
      walk(node.children[i], prefix + cont, i === node.children.length - 1, depth + 1);
    }
  }

  for (let i = 0; i < root.children.length; i++) {
    walk(root.children[i], '', i === root.children.length - 1, 0);
  }

  if (showStats && totalNodes > 3) {
    lines.push(dim(`  ── ${totalNodes} 节点 · ${maxDepth} 层深度`));
  }

  return lines.join('\n');
}

// ── Mermaid Pie Chart ─────────────────────────────────────────────────

/**
 * Parse mermaid pie chart code.
 * Syntax:
 *   pie title Budget
 *     "Rent" : 45
 *     "Food" : 25
 *     "Transport" : 15
 *     "Other" : 15
 * @param {string} code
 * @returns {{ title: string, items: {label: string, value: number}[] } | null}
 */
function _parseMermaidPie(code) {
  const lines = code.replace(/\t/g, '  ').split('\n');
  let title = '';
  const items = [];

  let found = false;
  for (const line of lines) {
    const trimmed = line.trim();
    if (!found) {
      const m = trimmed.match(/^pie\s*(title\s+(.+))?$/i);
      if (m) { found = true; title = (m[2] || '').trim(); continue; }
    }
    if (found) {
      // Match "Label" : value or 'Label' : value
      const m = trimmed.match(/^["'](.+?)["']\s*:\s*([\d.]+)/);
      if (m) items.push({ label: m[1], value: parseFloat(m[2]) });
    }
  }

  if (!found || items.length === 0) return null;
  return { title, items };
}

/**
 * Render a pie chart as horizontal stacked bar + legend.
 * @param {{ title: string, items: {label: string, value: number}[] }} data
 * @returns {string}
 */
function _renderPieChart(data) {
  const dim = c().dim.bind(c());
  const bold = c().bold.bind(c());
  const cols = (process.stdout.columns || 80) - 8;
  const barWidth = Math.min(50, Math.max(20, cols - 20));
  const total = data.items.reduce((s, it) => s + it.value, 0) || 1;

  // Color palette for segments
  const colors = [
    c().cyan.bind(c()),
    c().green.bind(c()),
    c().yellow.bind(c()),
    c().magenta.bind(c()),
    c().red.bind(c()),
    c().blue.bind(c()),
    c().white.bind(c()),
    c().dim.bind(c()),
  ];
  // Block characters for segments: use different fills for visual distinction
  const fills = ['█', '▓', '▒', '░', '▚', '▞', '╳', '·'];

  const lines = [];

  // Title
  if (data.title) {
    lines.push('  ' + bold(data.title));
    lines.push('');
  }

  // Stacked bar
  let bar = '';
  const segments = data.items.map((it, i) => {
    const pct = it.value / total;
    const w = Math.max(1, Math.round(pct * barWidth));
    const color = colors[i % colors.length];
    const fill = fills[i % fills.length];
    return { ...it, pct, w, color, fill };
  });

  // Adjust widths to sum to barWidth
  let sumW = segments.reduce((s, seg) => s + seg.w, 0);
  while (sumW > barWidth && segments.length > 0) {
    const largest = segments.reduce((a, b) => a.w > b.w ? a : b);
    largest.w--;
    sumW--;
  }
  while (sumW < barWidth && segments.length > 0) {
    const smallest = segments.reduce((a, b) => a.w < b.w ? a : b);
    smallest.w++;
    sumW++;
  }

  for (const seg of segments) {
    bar += seg.color(seg.fill.repeat(seg.w));
  }

  lines.push('  ' + dim('╭') + dim('─'.repeat(barWidth)) + dim('╮'));
  lines.push('  ' + dim('│') + bar + dim('│'));
  lines.push('  ' + dim('╰') + dim('─'.repeat(barWidth)) + dim('╯'));
  lines.push('');

  // Legend
  const maxLabel = Math.max(...segments.map(s => displayWidth(s.label)));
  for (const seg of segments) {
    const pctStr = (seg.pct * 100).toFixed(1) + '%';
    const marker = seg.color(seg.fill.repeat(2));
    const label = padToWidth(seg.label, maxLabel);
    const valStr = dim(seg.value.toString());
    lines.push(`  ${marker} ${label}  ${pctStr.padStart(6)}  ${valStr}`);
  }

  // Total
  lines.push(dim(`  ── 合计: ${total}`));

  return lines.join('\n');
}

// ── Mermaid Flowchart ─────────────────────────────────────────────────

/**
 * Parse mermaid flowchart/graph code.
 * Handles: graph TD/LR/BT/RL, flowchart TD/LR/BT/RL
 * Node shapes: A[text], A(text), A{text}, A((text)), A>text], A[/text/]
 * Edges: -->, --->, -.->. -->|text|, -- text -->
 * @param {string} code
 * @returns {{ direction: string, nodes: Map<string,{id:string,label:string}>, edges: {from:string,to:string,label:string}[] } | null}
 */
function _parseMermaidFlowchart(code) {
  const lines = code.replace(/\t/g, '  ').split('\n');
  let direction = 'TD';
  let found = false;

  const nodes = new Map();
  const edges = [];

  function ensureNode(id, label) {
    if (!nodes.has(id)) nodes.set(id, { id, label: label || id });
    else if (label && nodes.get(id).label === id) nodes.get(id).label = label;
  }

  function extractNodeLabel(raw) {
    // A[text], A(text), A{text}, A((text)), A>text], A[/text/], A[\text\]
    let m;
    if ((m = raw.match(/^([\w-]+)\(\((.+?)\)\)$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)\[\/(.+?)\/\]$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)\[\\(.+?)\\\]$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)\[(.+?)\]$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)\((.+?)\)$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)\{(.+?)\}$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)>(.+?)\]$/))) return { id: m[1], label: m[2] };
    if ((m = raw.match(/^([\w-]+)$/))) return { id: m[1], label: m[1] };
    return null;
  }

  for (const line of lines) {
    const trimmed = line.trim();
    if (!found) {
      const m = trimmed.match(/^(?:graph|flowchart)\s+(TD|TB|BT|LR|RL)\s*$/i);
      if (m) { found = true; direction = m[1].toUpperCase(); continue; }
      // Also accept bare "flowchart" or "graph" (default TD)
      if (/^(?:graph|flowchart)\s*$/i.test(trimmed)) { found = true; continue; }
    }
    if (!found) continue;
    if (!trimmed || trimmed.startsWith('%%') || trimmed.startsWith('style') ||
        trimmed.startsWith('class') || trimmed.startsWith('click') ||
        trimmed.startsWith('linkStyle') || trimmed.startsWith('subgraph') ||
        trimmed === 'end') continue;

    // Parse edge: A -->|label| B, A -- text --> B, A --> B, A -.-> B, A ==> B
    const edgeRe = /^(.+?)\s*(?:-->|==>|-\.->|---+>|--+)\s*(?:\|([^|]*)\|\s*)?(.+)$/;
    const edgeM = trimmed.match(edgeRe);
    if (edgeM) {
      let [, leftRaw, edgeLabel, rightRaw] = edgeM;
      // Check for A -- text --> B pattern
      if (!edgeLabel) {
        const textEdge = trimmed.match(/^(.+?)\s*--\s+(.+?)\s+-->\s*(.+)$/);
        if (textEdge) {
          leftRaw = textEdge[1];
          edgeLabel = textEdge[2];
          rightRaw = textEdge[3];
        }
      }
      const left = extractNodeLabel(leftRaw.trim());
      const right = extractNodeLabel(rightRaw.trim());
      if (left && right) {
        ensureNode(left.id, left.label);
        ensureNode(right.id, right.label);
        edges.push({ from: left.id, to: right.id, label: (edgeLabel || '').trim() });
      }
      continue;
    }

    // Standalone node definition
    const nodeInfo = extractNodeLabel(trimmed);
    if (nodeInfo) ensureNode(nodeInfo.id, nodeInfo.label);
  }

  if (!found || nodes.size === 0) return null;
  return { direction, nodes, edges };
}

/**
 * Render a flowchart as ASCII box-and-arrow diagram.
 * @param {{ direction: string, nodes: Map, edges: object[] }} data
 * @returns {string}
 */
function _renderFlowchart(data) {
  const dim = c().dim.bind(c());
  const bold = c().bold.bind(c());
  const cyan = c().cyan.bind(c());
  const isVertical = data.direction === 'TD' || data.direction === 'TB' || data.direction === 'BT';

  // Build adjacency for topological ordering
  const nodeList = [...data.nodes.values()];
  const adj = new Map();
  const inDeg = new Map();
  for (const n of nodeList) { adj.set(n.id, []); inDeg.set(n.id, 0); }
  for (const e of data.edges) {
    if (adj.has(e.from)) adj.get(e.from).push(e);
    if (inDeg.has(e.to)) inDeg.set(e.to, inDeg.get(e.to) + 1);
  }

  // Topological sort (Kahn's algorithm) for layer assignment
  const queue = [];
  const layers = new Map();
  for (const [id, deg] of inDeg) { if (deg === 0) { queue.push(id); layers.set(id, 0); } }
  while (queue.length > 0) {
    const cur = queue.shift();
    const curLayer = layers.get(cur);
    for (const e of (adj.get(cur) || [])) {
      const newDeg = inDeg.get(e.to) - 1;
      inDeg.set(e.to, newDeg);
      layers.set(e.to, Math.max(layers.get(e.to) || 0, curLayer + 1));
      if (newDeg === 0) queue.push(e.to);
    }
  }

  // Assign unvisited nodes to layer 0
  for (const n of nodeList) { if (!layers.has(n.id)) layers.set(n.id, 0); }

  // Group nodes by layer
  const maxLayer = Math.max(...layers.values(), 0);
  const layerGroups = Array.from({ length: maxLayer + 1 }, () => []);
  for (const n of nodeList) {
    layerGroups[layers.get(n.id)].push(n);
  }

  const lines = [];

  if (isVertical) {
    // Vertical: render layers top-down, nodes side by side in each layer
    for (let li = 0; li < layerGroups.length; li++) {
      const group = layerGroups[li];
      const boxes = group.map(n => {
        const w = Math.max(displayWidth(n.label) + 4, 8);
        const top = dim('╭') + dim('─'.repeat(w - 2)) + dim('╮');
        const mid = dim('│') + ' ' + cyan(padToWidth(n.label, w - 4)) + ' ' + dim('│');
        const bot = dim('╰') + dim('─'.repeat(w - 2)) + dim('╯');
        return { top, mid, bot, w };
      });

      // Render boxes side by side
      const gap = '  ';
      lines.push('  ' + boxes.map(b => b.top).join(gap));
      lines.push('  ' + boxes.map(b => b.mid).join(gap));
      lines.push('  ' + boxes.map(b => b.bot).join(gap));

      // Arrow to next layer
      if (li < layerGroups.length - 1) {
        // Find edges from this layer to next
        const edgeLabels = [];
        for (const e of data.edges) {
          if (layers.get(e.from) === li && layers.get(e.to) === li + 1) {
            edgeLabels.push(e.label);
          }
        }
        const arrowLabel = edgeLabels.filter(Boolean).join(', ');
        const totalWidth = boxes.reduce((s, b) => s + b.w, 0) + (boxes.length - 1) * gap.length;
        const center = Math.floor(totalWidth / 2);
        const arrowPad = ' '.repeat(Math.max(0, center));

        lines.push('  ' + arrowPad + dim('│'));
        if (arrowLabel) {
          lines.push('  ' + arrowPad + dim('│ ') + dim(arrowLabel));
        }
        lines.push('  ' + arrowPad + dim('▼'));
      }
    }
  } else {
    // Horizontal: render layers left to right, each layer is a column
    // For simplicity in terminal, render as sequential flow with arrows
    for (let li = 0; li < layerGroups.length; li++) {
      const group = layerGroups[li];
      for (let ni = 0; ni < group.length; ni++) {
        const n = group[ni];
        const w = Math.max(displayWidth(n.label) + 4, 8);
        lines.push('  ' + dim('╭') + dim('─'.repeat(w - 2)) + dim('╮'));
        lines.push('  ' + dim('│') + ' ' + cyan(padToWidth(n.label, w - 4)) + ' ' + dim('│'));
        lines.push('  ' + dim('╰') + dim('─'.repeat(w - 2)) + dim('╯'));
      }
      if (li < layerGroups.length - 1) {
        const edgeLabels = [];
        for (const e of data.edges) {
          if (layers.get(e.from) === li && layers.get(e.to) === li + 1) {
            edgeLabels.push(e.label);
          }
        }
        const arrowLabel = edgeLabels.filter(Boolean).join(', ');
        if (arrowLabel) {
          lines.push('    ' + dim('│ ') + dim(arrowLabel));
        } else {
          lines.push('    ' + dim('│'));
        }
        lines.push('    ' + dim('▼'));
      }
    }
  }

  // Stats
  lines.push(dim(`  ── ${data.nodes.size} 节点 · ${data.edges.length} 连接`));

  return lines.join('\n');
}

// ── Mermaid Sequence Diagram ──────────────────────────────────────────

/**
 * Parse mermaid sequenceDiagram code.
 * @param {string} code
 * @returns {{ participants: string[], messages: {from:string,to:string,label:string,type:string}[] } | null}
 */
function _parseMermaidSequence(code) {
  const lines = code.replace(/\t/g, '  ').split('\n');
  let found = false;
  const participantOrder = [];
  const participantSet = new Set();
  const messages = [];

  function addParticipant(name) {
    if (!participantSet.has(name)) { participantSet.add(name); participantOrder.push(name); }
  }

  for (const line of lines) {
    const trimmed = line.trim();
    if (!found) {
      if (/^sequenceDiagram\s*$/i.test(trimmed)) { found = true; continue; }
    }
    if (!found) continue;
    if (!trimmed || trimmed.startsWith('%%') || trimmed.startsWith('Note') ||
        trimmed.startsWith('activate') || trimmed.startsWith('deactivate') ||
        trimmed.startsWith('rect') || trimmed === 'end' ||
        trimmed.startsWith('loop') || trimmed.startsWith('alt') ||
        trimmed.startsWith('else') || trimmed.startsWith('opt') ||
        trimmed.startsWith('par') || trimmed.startsWith('and') ||
        trimmed.startsWith('critical') || trimmed.startsWith('break')) continue;

    // Participant/actor declaration
    const partM = trimmed.match(/^(?:participant|actor)\s+(.+?)(?:\s+as\s+(.+))?$/i);
    if (partM) { addParticipant(partM[2] || partM[1]); continue; }

    // Message: A ->> B: text, A -->> B: text, A -) B: text, A -x B: text
    const msgM = trimmed.match(/^(.+?)\s*(->>|-->>|-\)|--\)|->|-->|-x|--x)\s*(.+?):\s*(.*)$/);
    if (msgM) {
      const [, from, arrow, to, label] = msgM;
      const fromName = from.trim();
      const toName = to.trim();
      addParticipant(fromName);
      addParticipant(toName);
      const type = arrow.includes('--') ? 'dashed' : 'solid';
      messages.push({ from: fromName, to: toName, label: label.trim(), type });
      continue;
    }
  }

  if (!found || messages.length === 0) return null;
  return { participants: participantOrder, messages };
}

/**
 * Render a sequence diagram in the terminal.
 * @param {{ participants: string[], messages: object[] }} data
 * @returns {string}
 */
function _renderSequenceDiagram(data) {
  const dim = c().dim.bind(c());
  const bold = c().bold.bind(c());
  const cyan = c().cyan.bind(c());
  const cols = (process.stdout.columns || 80) - 4;

  const parts = data.participants;
  if (parts.length === 0) return null;

  // Compute column positions
  const colWidth = Math.max(12, Math.min(24, Math.floor((cols - 4) / parts.length)));
  const positions = {};
  parts.forEach((p, i) => { positions[p] = i * colWidth + Math.floor(colWidth / 2); });

  const lines = [];

  // Participant boxes
  let headerLine = '';
  for (const p of parts) {
    const pos = positions[p];
    const w = Math.max(displayWidth(p) + 4, 8);
    const start = Math.max(0, pos - Math.floor(w / 2));
    while (headerLine.length < start) headerLine += ' ';
    headerLine += dim('╭') + dim('─'.repeat(w - 2)) + dim('╮');
  }
  lines.push('  ' + headerLine);

  let labelLine = '';
  for (const p of parts) {
    const pos = positions[p];
    const w = Math.max(displayWidth(p) + 4, 8);
    const start = Math.max(0, pos - Math.floor(w / 2));
    while (labelLine.length < start) labelLine += ' ';
    labelLine += dim('│') + ' ' + bold(padToWidth(p, w - 4)) + ' ' + dim('│');
  }
  lines.push('  ' + labelLine);

  let bottomLine = '';
  for (const p of parts) {
    const pos = positions[p];
    const w = Math.max(displayWidth(p) + 4, 8);
    const start = Math.max(0, pos - Math.floor(w / 2));
    while (bottomLine.length < start) bottomLine += ' ';
    bottomLine += dim('╰') + dim('─'.repeat(w - 2)) + dim('╯');
  }
  lines.push('  ' + bottomLine);

  // Lifelines + messages
  for (const msg of data.messages) {
    const fromPos = positions[msg.from];
    const toPos = positions[msg.to];
    if (fromPos === undefined || toPos === undefined) continue;

    // Lifeline row
    let lifeline = '';
    for (const p of parts) {
      const pos = positions[p];
      while (lifeline.length < pos) lifeline += ' ';
      if (lifeline.length === pos) lifeline += dim('│');
    }
    lines.push('  ' + lifeline);

    // Arrow row
    const left = Math.min(fromPos, toPos);
    const right = Math.max(fromPos, toPos);
    const goingRight = toPos > fromPos;
    const arrowLen = right - left;

    if (arrowLen === 0) {
      // Self-message
      let arrowLine = '';
      while (arrowLine.length < fromPos) arrowLine += ' ';
      arrowLine += dim('╭──╮ ') + cyan(msg.label);
      lines.push('  ' + arrowLine);
      let returnLine = '';
      while (returnLine.length < fromPos) returnLine += ' ';
      returnLine += dim('◄──╯');
      lines.push('  ' + returnLine);
    } else {
      let arrowLine = '';
      while (arrowLine.length < left) arrowLine += ' ';
      const dashChar = msg.type === 'dashed' ? '╌' : '─';
      if (goingRight) {
        arrowLine += dim(dashChar.repeat(Math.max(1, arrowLen - 1))) + dim('▶');
      } else {
        arrowLine += dim('◀') + dim(dashChar.repeat(Math.max(1, arrowLen - 1)));
      }
      // Label above or beside the arrow
      const labelPos = left + Math.floor(arrowLen / 2) - Math.floor(displayWidth(msg.label) / 2);
      if (msg.label) {
        let labelLine2 = '';
        while (labelLine2.length < Math.max(0, labelPos)) labelLine2 += ' ';
        labelLine2 += cyan(msg.label);
        lines.push('  ' + labelLine2);
      }
      lines.push('  ' + arrowLine);
    }
  }

  // Final lifeline
  let finalLifeline = '';
  for (const p of parts) {
    const pos = positions[p];
    while (finalLifeline.length < pos) finalLifeline += ' ';
    if (finalLifeline.length === pos) finalLifeline += dim('│');
  }
  lines.push('  ' + finalLifeline);

  lines.push(dim(`  ── ${parts.length} 参与者 · ${data.messages.length} 消息`));

  return lines.join('\n');
}

// ── Mermaid Gantt Chart ───────────────────────────────────────────────

/**
 * Parse mermaid gantt chart code.
 * @param {string} code
 * @returns {{ title: string, sections: {name: string, tasks: {label:string,status:string}[]}[] } | null}
 */
function _parseMermaidGantt(code) {
  const lines = code.replace(/\t/g, '  ').split('\n');
  let found = false;
  let title = '';
  const sections = [];
  let currentSection = { name: '', tasks: [] };

  for (const line of lines) {
    const trimmed = line.trim();
    if (!found) {
      if (/^gantt\s*$/i.test(trimmed)) { found = true; continue; }
    }
    if (!found) continue;
    if (!trimmed || trimmed.startsWith('%%')) continue;

    // Title
    const titleM = trimmed.match(/^title\s+(.+)$/i);
    if (titleM) { title = titleM[1].trim(); continue; }

    // Skip dateFormat, axisFormat, excludes, etc.
    if (/^(?:dateFormat|axisFormat|excludes|todayMarker|tickInterval)\s+/i.test(trimmed)) continue;

    // Section
    const secM = trimmed.match(/^section\s+(.+)$/i);
    if (secM) {
      if (currentSection.tasks.length > 0) sections.push(currentSection);
      currentSection = { name: secM[1].trim(), tasks: [] };
      continue;
    }

    // Task: "Task Name : status, id, after, duration" or "Task Name : duration"
    const taskM = trimmed.match(/^(.+?)\s*:\s*(.*)$/);
    if (taskM) {
      const label = taskM[1].trim();
      const meta = taskM[2].trim();
      let status = 'pending';
      if (/\bdone\b/i.test(meta)) status = 'done';
      else if (/\bactive\b/i.test(meta)) status = 'active';
      else if (/\bcrit\b/i.test(meta)) status = 'critical';
      currentSection.tasks.push({ label, status });
    }
  }

  if (currentSection.tasks.length > 0) sections.push(currentSection);
  if (!found || sections.length === 0) return null;
  return { title, sections };
}

/**
 * Render gantt chart as terminal timeline.
 * @param {{ title: string, sections: object[] }} data
 * @returns {string}
 */
function _renderGanttChart(data) {
  const dim = c().dim.bind(c());
  const bold = c().bold.bind(c());
  const cols = (process.stdout.columns || 80) - 8;
  const barWidth = Math.min(30, Math.max(12, cols - 30));

  const statusStyle = {
    done: { color: c().green.bind(c()), fill: '█', icon: '✓' },
    active: { color: c().cyan.bind(c()), fill: '▓', icon: '▶' },
    critical: { color: c().red.bind(c()), fill: '█', icon: '!' },
    pending: { color: c().dim.bind(c()), fill: '░', icon: '○' },
  };

  const lines = [];

  if (data.title) {
    lines.push('  ' + bold(data.title));
    lines.push('');
  }

  let totalTasks = 0;
  const allTasks = data.sections.flatMap(s => s.tasks);
  const taskCount = allTasks.length;

  for (const section of data.sections) {
    if (section.name) {
      lines.push('  ' + bold(section.name));
    }

    const maxLabel = Math.max(...section.tasks.map(t => displayWidth(t.label)), 0);

    for (let ti = 0; ti < section.tasks.length; ti++) {
      const task = section.tasks[ti];
      totalTasks++;
      const style = statusStyle[task.status] || statusStyle.pending;

      // Proportional bar based on task position (simple timeline simulation)
      const progress = task.status === 'done' ? 1.0 :
                       task.status === 'active' ? 0.6 :
                       task.status === 'critical' ? 0.4 : 0.0;
      const filled = Math.round(progress * barWidth);
      const empty = barWidth - filled;

      const label = padToWidth(task.label, maxLabel);
      const icon = style.color(style.icon);
      const bar = style.color(style.fill.repeat(filled)) + dim('░'.repeat(empty));
      lines.push(`  ${icon} ${label}  ${bar}`);
    }

    lines.push('');
  }

  // Timeline footer
  const doneCount = allTasks.filter(t => t.status === 'done').length;
  const activeCount = allTasks.filter(t => t.status === 'active').length;
  lines.push(dim(`  ── ${taskCount} 任务 · ${doneCount} 完成 · ${activeCount} 进行中`));

  return lines.join('\n');
}


/**
 * Attempt to render a mermaid code block as terminal-friendly output.
 * Supports: mindmap, pie, flowchart/graph, sequenceDiagram, gantt.
 * Returns null if unsupported (fallback to code block).
 * @param {string} code
 * @returns {string | null}
 */
function _renderMermaidBlock(code) {
  // Mindmap
  const mindmap = _parseMermaidMindmap(code);
  if (mindmap) return _renderTree(mindmap, { rootBox: true, showStats: true });

  // Pie chart
  const pie = _parseMermaidPie(code);
  if (pie) return _renderPieChart(pie);

  // Flowchart / graph
  const flow = _parseMermaidFlowchart(code);
  if (flow) return _renderFlowchart(flow);

  // Sequence diagram
  const seq = _parseMermaidSequence(code);
  if (seq) return _renderSequenceDiagram(seq);

  // Gantt chart
  const gantt = _parseMermaidGantt(code);
  if (gantt) return _renderGanttChart(gantt);

  return null;
}

/**
 * Detect deeply nested list blocks (3+ indent levels) for tree rendering.
 * @param {string} text
 * @returns {{ startLine: number, endLine: number, root: object }[]}
 */
function _detectNestedListTree(text) {
  const lines = text.split('\n');
  const results = [];
  let i = 0;
  // Track code fences to skip lists inside them
  let inFence = false;

  while (i < lines.length) {
    if (/^```/.test(lines[i].trim())) { inFence = !inFence; i++; continue; }
    if (inFence) { i++; continue; }

    if (/^\s*[-*]\s+/.test(lines[i])) {
      const startLine = i;
      const listLines = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
        listLines.push(lines[i]);
        i++;
      }
      // Count distinct indent levels
      const indentSet = new Set(listLines.map(l => l.match(/^(\s*)/)[1].length));
      if (indentSet.size >= 3 && listLines.length >= 4) {
        // Parse into tree
        const indents = listLines.map(l => l.match(/^(\s*)/)[1].length);
        const labels = listLines.map(l => l.replace(/^\s*[-*]\s+/, '').trim());
        const minIndent = Math.min(...indents);
        const indentArr = [...indentSet].sort((a, b) => a - b);
        const unit = indentArr.length > 1 ? indentArr[1] - indentArr[0] : 2;

        const root = { label: labels[0], children: [] };
        const stack = [{ depth: 0, node: root }];

        for (let j = 1; j < listLines.length; j++) {
          const depth = Math.round((indents[j] - minIndent) / unit);
          const node = { label: labels[j], children: [] };
          while (stack.length > 1 && stack[stack.length - 1].depth >= depth) stack.pop();
          stack[stack.length - 1].node.children.push(node);
          stack.push({ depth, node });
        }

        results.push({ startLine, endLine: i, root });
      }
    } else {
      i++;
    }
  }
  return results;
}

/**
 * Replace deeply nested list blocks with tree renderings.
 * @param {string} text
 * @returns {string}
 */
function _renderNestedListTrees(text) {
  const blocks = _detectNestedListTree(text);
  if (blocks.length === 0) return text;

  const lines = text.split('\n');
  // Process in reverse to preserve indices
  for (let b = blocks.length - 1; b >= 0; b--) {
    const { startLine, endLine, root } = blocks[b];
    const tree = _renderTree(root, { rootBox: false, showStats: false });
    lines.splice(startLine, endLine - startLine, tree);
  }
  return lines.join('\n');
}

// ── Interactive Prompt ──────────────────────────────────────────────────

/**
 * Present numbered options to the user and wait for selection.
 * Returns the selected option(s) or null if cancelled.
 *
 * @param {string} question - The question to ask
 * @param {Array<{label: string, description?: string}>} options
 * @param {object} [opts]
 * @param {boolean} [opts.multiSelect=false]
 * @param {readline.Interface} [opts.rl] - existing readline to reuse
 * @returns {Promise<string|string[]|null>}
 */
async function askInlineQuestion(question, options, opts = {}) {
  const readline = require('readline');
  const stdin = process.stdin;
  const stdout = process.stdout;
  const canUseArrowMenu = !opts.multiSelect
    && Boolean(stdin && stdout && stdin.isTTY && stdout.isTTY && typeof stdin.setRawMode === 'function');

  // Claude Code style: arrow-key navigable menu for single-select
  if (canUseArrowMenu) {
    // Build choices compatible with promptChoiceMenu style
    const choices = options.map((opt, i) => ({
      label: opt.label + (opt.description ? c().dim(` — ${opt.description}`) : ''),
      value: opt.label,
      aliases: [String(i + 1)],
    }));
    // Add "Other" choice
    choices.push({
      label: c().dim('Other (free input)'),
      value: '__other__',
      aliases: [String(options.length + 1), 'o', 'other'],
    });

    const PURPLE = '#B388FF';
    return new Promise((resolve) => {
      let selected = 0;
      let typed = '';
      let renderedLines = 0;
      const wasRawMode = Boolean(stdin.isRaw);

      // Pause the REPL's readline if provided
      const rl = opts.rl;
      if (rl && typeof rl.pause === 'function') {
        try { rl.pause(); } catch { /* ignore */ }
      }

      const cleanup = (resultValue) => {
        stdin.off('data', onData);
        if (typeof stdin.setRawMode === 'function') {
          try { stdin.setRawMode(wasRawMode); } catch { /* ignore */ }
        }
        if (renderedLines > 0) {
          try { readline.moveCursor(stdout, 0, -renderedLines); } catch { /* ignore */ }
          try { readline.cursorTo(stdout, 0); } catch { /* ignore */ }
          try { readline.clearScreenDown(stdout); } catch { /* ignore */ }
        }
        const resumeMainRl = () => {
          if (rl && typeof rl.resume === 'function') {
            try { rl.resume(); } catch { /* ignore */ }
          }
        };
        // Handle "Other" — prompt for free text
        if (resultValue === '__other__') {
          // Keep main REPL paused while collecting free input.
          // Resuming it too early causes duplicate key handling.
          const rl2 = readline.createInterface({ input: stdin, output: stdout });
          rl2.question(c().dim('  Enter custom text: '), (text) => {
            rl2.close();
            try { stdin.resume(); } catch { /* ignore */ }
            resumeMainRl();
            resolve(text.trim() || null);
          });
          return;
        }
        resumeMainRl();
        resolve(resultValue);
      };

      const render = () => {
        if (renderedLines > 0) {
          try { readline.moveCursor(stdout, 0, -renderedLines); } catch { /* ignore */ }
          try { readline.cursorTo(stdout, 0); } catch { /* ignore */ }
          try { readline.clearScreenDown(stdout); } catch { /* ignore */ }
        }
        const lines = [];
        lines.push(`  ${c().hex(THEME.warning).bold(`? ${question}`)}`);
        for (let i = 0; i < choices.length; i++) {
          const marker = i === selected ? c().hex(PURPLE)('\u276F') : ' ';
          const num = `${i + 1}.`;
          const label = i === selected ? c().bold(choices[i].label) : choices[i].label;
          lines.push(`   ${marker} ${num} ${label}`);
        }
        lines.push('');
        lines.push(`  ${c().dim('Use arrow keys to navigate, Enter to select, Esc to skip')}`);
        stdout.write(`${lines.join('\n')}\n`);
        renderedLines = lines.length;
      };

      const onData = (chunk) => {
        const key = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk);
        // Esc or Ctrl+C → cancel
        if (key === '\u0003' || key === '\u001b') { cleanup(null); return; }
        // Arrow up
        if (key === '\u001b[A') { selected = (selected - 1 + choices.length) % choices.length; render(); return; }
        // Arrow down
        if (key === '\u001b[B') { selected = (selected + 1) % choices.length; render(); return; }
        // Tab
        if (key === '\t') { selected = (selected + 1) % choices.length; render(); return; }
        // Enter
        if (key === '\r' || key === '\n') { cleanup(choices[selected].value); return; }
        // Number keys for quick select
        if (key.length === 1 && key >= '1' && key <= '9') {
          const idx = parseInt(key, 10) - 1;
          if (idx >= 0 && idx < choices.length) { cleanup(choices[idx].value); return; }
        }
        // '0' → skip
        if (key === '0') { cleanup(null); return; }
      };

      try { stdin.resume(); } catch { /* ignore */ }
      try { stdin.setRawMode(true); } catch { /* ignore */ }
      stdin.on('data', onData);
      render();
    });
  }

  // Fallback for multiSelect or non-TTY: numbered list
  console.log('');
  console.log(c().hex(THEME.warning)(`  ? ${question}`));
  console.log('');

  options.forEach((opt, i) => {
    const num = c().cyan(`  [${i + 1}]`);
    const label = c().white(opt.label);
    const desc = opt.description ? c().dim(` — ${opt.description}`) : '';
    console.log(`${num} ${label}${desc}`);
  });
  console.log(c().dim(`  [${options.length + 1}] Other (free input)`));
  console.log(c().dim(`  [0] Skip`));
  console.log('');

  const rl = opts.rl || readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    const prompt = opts.multiSelect
      ? c().dim('  Select (comma-separated, e.g. 1,3): ')
      : c().dim('  Select: ');

    rl.question(prompt, (answer) => {
      if (!opts.rl) rl.close();

      const trimmed = answer.trim();
      if (!trimmed || trimmed === '0') {
        resolve(null);
        return;
      }

      const lastIdx = options.length + 1;
      if (trimmed === String(lastIdx)) {
        const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl2.question(c().dim('  Enter: '), (text) => {
          rl2.close();
          resolve(text.trim() || null);
        });
        return;
      }

      if (opts.multiSelect) {
        const indices = trimmed.split(/[,，\s]+/).map(s => parseInt(s, 10) - 1);
        const selected = indices
          .filter(i => i >= 0 && i < options.length)
          .map(i => options[i].label);
        resolve(selected.length > 0 ? selected : null);
      } else {
        const idx = parseInt(trimmed, 10) - 1;
        if (idx >= 0 && idx < options.length) {
          resolve(options[idx].label);
        } else {
          resolve(trimmed);
        }
      }
    });
  });
}

// ── AI Response Renderer ────────────────────────────────────────────────

/**
 * Wrap a line at terminal width, preserving ANSI escape codes.
 * Supports CJK character-level breaking (中文字符间可自由换行).
 * Skips lines inside code blocks (prefixed with │).
 * @param {string} line
 * @param {number} maxWidth
 * @returns {string}
 */
function wrapLine(line, maxWidth) {
  if (maxWidth <= 0) return line;
  // Strip ANSI for length measurement, use displayWidth for CJK support
  const stripped = line.replace(/\x1b\[[0-9;]*m/g, '');
  if (displayWidth(stripped) <= maxWidth) return line;

  // Don't wrap code block lines (contain │ indicator)
  if (stripped.includes('│')) return line;

  // Character-level wrapping that handles CJK properly.
  // CJK characters can break between any two characters;
  // Latin/ASCII words break at whitespace boundaries.
  const lines = [];
  let current = '';
  let currentLen = 0;

  // Helper: check if a codepoint is CJK (wide character)
  function _isCJK(cp) {
    return (
      (cp >= 0x2E80 && cp <= 0x303E) ||
      (cp >= 0x3040 && cp <= 0x33BF) ||
      (cp >= 0x3400 && cp <= 0x4DBF) ||
      (cp >= 0x4E00 && cp <= 0x9FFF) ||
      (cp >= 0xA000 && cp <= 0xA4CF) ||
      (cp >= 0xAC00 && cp <= 0xD7AF) ||
      (cp >= 0xF900 && cp <= 0xFAFF) ||
      (cp >= 0xFE30 && cp <= 0xFE6F) ||
      (cp >= 0xFF01 && cp <= 0xFF60) ||
      (cp >= 0xFFE0 && cp <= 0xFFE6) ||
      (cp >= 0x20000 && cp <= 0x2FA1F) ||
      (cp >= 0x3000 && cp <= 0x303F)    // CJK punctuation（。，！？等）
    );
  }

  const chars = Array.from(stripped);
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    const cp = ch.codePointAt(0);
    const chWidth = _isCJK(cp) ? 2 : (cp >= 0x0300 && cp <= 0x036F ? 0 : 1);

    if (currentLen + chWidth > maxWidth && current.length > 0) {
      // Need to break. For ASCII words, try to backtrack to last breakpoint.
      if (!_isCJK(cp) && ch !== ' ') {
        // We're in the middle of a Latin word — find last space or CJK char
        let breakIdx = -1;
        for (let j = current.length - 1; j > 0; j--) {
          const prevCp = current.codePointAt(j);
          if (current[j] === ' ' || _isCJK(prevCp)) {
            breakIdx = j + 1;
            break;
          }
        }
        if (breakIdx > 0 && breakIdx < current.length) {
          // Break at the found position, push remainder back
          lines.push(current.slice(0, breakIdx).trimEnd());
          const remainder = current.slice(breakIdx);
          current = remainder + ch;
          currentLen = displayWidth(remainder) + chWidth;
          continue;
        }
      }
      lines.push(current.trimEnd());
      // Skip leading space on new line
      if (ch === ' ') {
        current = '';
        currentLen = 0;
      } else {
        current = ch;
        currentLen = chWidth;
      }
    } else {
      current += ch;
      currentLen += chWidth;
    }
  }
  if (current) lines.push(current.trimEnd());

  return lines.join('\n');
}

function _stripAnsi(text = '') {
  return String(text).replace(/\x1b\[[0-9;]*m/g, '');
}

function _isUnicodeGuideEnabled() {
  const mode = String(process.env.KHY_UNICODE_GUIDE || 'auto').trim().toLowerCase();
  if (['0', 'false', 'off', 'no'].includes(mode)) return false;
  if (['1', 'true', 'on', 'yes'].includes(mode)) return true;
  // auto: only when terminal width is reasonable.
  const cols = process.stdout.columns || 80;
  return cols >= 70;
}

function _getUnicodeGuideDensity() {
  const raw = String(process.env.KHY_UNICODE_GUIDE_DENSITY || 'box').trim().toLowerCase();
  if (raw === 'light' || raw === 'box' || raw === 'heavy') return raw;
  return 'box';
}

/**
 * Decorate response lines with lightweight Unicode guide markers.
 * Goal: improve scanability without altering semantics.
 */
function _decorateResponseWithUnicode(text) {
  if (!_isUnicodeGuideEnabled()) return text;
  const density = _getUnicodeGuideDensity();
  const lines = String(text || '').split('\n');
  const calloutKinds = [
    { pattern: /^(tip|提示|提示信息)[:：]\s*(.*)$/i, icon: '✦', label: 'Tip' },
    { pattern: /^(warning|警告|注意|风险)[:：]\s*(.*)$/i, icon: '⚠', label: 'Warning' },
    { pattern: /^(next step|下一步|建议|recommendation)[:：]\s*(.*)$/i, icon: '➜', label: 'Next Step' },
    { pattern: /^(summary|总结|结果|结论|conclusion)[:：]\s*(.*)$/i, icon: '✓', label: 'Summary' },
    { pattern: /^(example|示例|例子)[:：]\s*(.*)$/i, icon: '◉', label: 'Example' },
    { pattern: /^(note|说明|备注)[:：]\s*(.*)$/i, icon: '◌', label: 'Note' },
  ];

  function wrapUnicodeText(input, width) {
    const source = String(input || '').replace(/\r/g, '');
    if (!source) return [''];
    const result = [];
    for (const paragraph of source.split('\n')) {
      if (!paragraph) {
        result.push('');
        continue;
      }
      let current = '';
      let currentWidth = 0;
      for (const ch of Array.from(paragraph)) {
        const chWidth = displayWidth(ch);
        if (current && currentWidth + chWidth > width) {
          result.push(current);
          current = ch;
          currentWidth = chWidth;
        } else {
          current += ch;
          currentWidth += chWidth;
        }
      }
      if (current) result.push(current);
    }
    return result.length > 0 ? result : [''];
  }

  function buildCalloutBox(indent, icon, label, body) {
    const cols = Math.max(40, (process.stdout.columns || 80) - 12);
    const maxInnerWidth = Math.max(18, Math.min(56, cols - 4));
    const title = `${icon} ${label}`;
    const bodyLines = wrapUnicodeText(body, maxInnerWidth);
    const widestBody = bodyLines.reduce((max, line) => Math.max(max, displayWidth(line)), 0);
    const innerWidth = Math.max(Math.min(maxInnerWidth, widestBody), displayWidth(title), 16);
    const heavy = density === 'heavy';
    const topLeft = heavy ? '┏' : '╭';
    const topRight = heavy ? '┓' : '╮';
    const bottomLeft = heavy ? '┗' : '╰';
    const bottomRight = heavy ? '┛' : '╯';
    const h = heavy ? '━' : '─';
    const v = heavy ? '┃' : '│';
    const top = `${indent}${topLeft}${h.repeat(innerWidth + 2)}${topRight}`;
    const titleLine = `${indent}${v} ${padToWidth(title, innerWidth)} ${v}`;
    const contentLines = bodyLines.map((line) => `${indent}${v} ${padToWidth(line, innerWidth)} ${v}`);
    const bottom = `${indent}${bottomLeft}${h.repeat(innerWidth + 2)}${bottomRight}`;
    return [top, titleLine, ...contentLines, bottom].join('\n');
  }

  return lines.map((line) => {
    const plain = _stripAnsi(line);
    const trimmed = plain.trim();
    if (!trimmed) return line;

    // Preserve code/diff/table box rendering lines.
    if (/^\s*[│┌└├╭╰]/.test(plain)) return line;
    if (/^\s*[-+@]{3,}/.test(trimmed)) return line;

    const indent = (plain.match(/^(\s*)/) || [])[1] || '';
    const withPrefix = (mark) => line.replace(/^(\s*)/, `$1${mark} `);

    for (const kind of calloutKinds) {
      const m = trimmed.match(kind.pattern);
      if (m) {
        const body = String(m[2] || '').trim();
        const fallbackBody = body || trimmed.replace(kind.pattern, '$2').trim() || '';
        if (density === 'light') {
          return `${indent}${kind.icon} ${kind.label}: ${fallbackBody}`;
        }
        return buildCalloutBox(indent, kind.icon, kind.label, fallbackBody);
      }
    }

    if (/^(提示|tip)[:：]/i.test(trimmed)) return withPrefix('✦');
    if (/^(注意|警告|warning|风险)[:：]/i.test(trimmed)) return withPrefix('⚠');
    if (/^(结果|结论|summary|总结)[:：]/i.test(trimmed)) return withPrefix('✓');
    if (/^(下一步|建议|next|recommendation)[:：]/i.test(trimmed)) return withPrefix('➜');
    if (/^(原因|reason)[:：]/i.test(trimmed)) return withPrefix('◉');
    if (/^(命令|command)[:：]/i.test(trimmed)) return withPrefix('⌘');

    // Upgrade list markers for better visual hierarchy.
    if (/^\s*•\s+/.test(plain)) return line.replace(/^(\s*)•\s+/, '$1▪ ');
    if (/^\s*›\s+/.test(plain)) return line.replace(/^(\s*)›\s+/, '$1▸ ');

    return line;
  }).join('\n');
}

const _TOOL_TRACE_NAMES = new Set([
  'bash', 'shell', 'shellcommand', 'command',
  'read', 'readfile', 'notebookread',
  'write', 'writefile', 'createfile',
  'edit', 'editfile', 'multiedit', 'update', 'notebookedit',
  'search', 'searchcontent', 'grep', 'glob', 'find', 'findfiles', 'ls',
  'websearch', 'webfetch', 'fetch',
  'task', 'taskoutput', 'taskresult',
  'agent', 'tool', 'todo', 'todowrite',
]);

function _escapeRegex(text) {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function _stripTracePrefix(line) {
  let result = String(line || '');
  result = result.replace(/^\s*[>│┃]+\s*/u, '');
  result = result.replace(/^\s*[├└┌┐┘┤╰╭⎿┬┴─━]+\s*/u, '');
  result = result.replace(/^\s*(?:[-*•▪▸›]|\d+[.)、]|❯)\s*/u, '');
  return result.trim();
}

function _extractParamValue(rawArgs, keys) {
  const source = String(rawArgs || '');
  for (const key of keys) {
    const re = new RegExp(`(?:^|[,{\\s])${_escapeRegex(key)}\\s*(?:=|:)\\s*(?:"((?:\\\\.|[^"\\\\])*)"|'((?:\\\\.|[^'\\\\])*)'|\\\`((?:\\\\.|[^\\\`\\\\])*)\\\`|([^,}]+))`, 'i');
    const m = source.match(re);
    if (m) {
      const value = (m[1] || m[2] || m[3] || m[4] || '').trim()
        .replace(/\\(["'`\\])/g, '$1');
      if (value) return value;
    }
  }
  return '';
}

function _truncateText(text, max = 120) {
  const source = String(text || '').replace(/\s+/g, ' ').trim();
  if (!source) return '';
  return source.length > max ? `${source.slice(0, max - 3)}...` : source;
}

function _truncateDisplayWidth(text, maxWidth) {
  const source = String(text || '').replace(/\s+/g, ' ').trim();
  if (!source) return '';
  const limit = Math.max(0, Number(maxWidth) || 0);
  if (limit <= 0) return '';

  let width = 0;
  let out = '';
  for (const ch of Array.from(source)) {
    const chWidth = displayWidth(ch);
    if (width + chWidth > limit) {
      return out ? `${out}...` : '...';
    }
    out += ch;
    width += chWidth;
  }
  return out;
}

function _truncateNaturalText(text, maxWidth = 120) {
  const clipped = _truncateDisplayWidth(String(text || ''), maxWidth);
  if (!clipped.endsWith('...')) return clipped;

  const base = clipped.slice(0, -3).trimEnd();
  if (!base) return clipped;
  const boundaryPattern = /[\s,，。;；:：!！?？)\]）】》"'`]/;
  let lastBoundary = -1;
  for (let i = 0; i < base.length; i++) {
    if (boundaryPattern.test(base[i])) lastBoundary = i;
  }
  if (lastBoundary < 0) return clipped;
  const candidate = base.slice(0, lastBoundary).trimEnd();
  if (!candidate) return clipped;
  if (candidate.length < Math.floor(base.length * 0.55)) return clipped;
  return `${candidate}...`;
}

function _sanitizeToolTableCell(value, maxWidth = 24) {
  const normalized = String(value || '')
    .replace(/\|/g, '¦')
    .replace(/\r?\n/g, ' ')
    .trim();
  return _truncateDisplayWidth(normalized, maxWidth);
}

function _extractLooseToolParams(raw = '') {
  const source = String(raw || '').replace(/\s+/g, ' ').trim();
  if (!source) return {};
  const loose = {};

  const cmd = _extractParamValue(source, ['command', 'cmd']);
  const filePath = _extractParamValue(source, ['file_path', 'filePath', 'path', 'file']);
  const pattern = _extractParamValue(source, ['pattern', 'query', 'q']);
  const url = _extractParamValue(source, ['url', 'uri', 'href']);
  const description = _extractParamValue(source, ['description', 'summary', 'message', 'content']);
  const role = _extractParamValue(source, ['role', 'subagent_type', 'agent_type']);
  const prompt = _extractParamValue(source, ['prompt']);

  if (cmd) loose.command = cmd;
  if (filePath) loose.path = filePath;
  if (pattern) loose.pattern = pattern;
  if (url) loose.url = url;
  if (description) loose.description = description;
  if (role) loose.role = role;
  if (prompt) loose.prompt = prompt;
  return loose;
}

function _coerceToolParams(params) {
  if (params && typeof params === 'object') return params;
  if (typeof params === 'string') {
    try {
      const parsed = JSON.parse(params);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch { /* not JSON */ }
    const raw = String(params || '').replace(/\s+/g, ' ').trim();
    const loose = _extractLooseToolParams(raw);
    if (Object.keys(loose).length > 0) return loose;
    return { _raw: raw };
  }
  return {};
}

function _summarizeToolTraceArgs(normalizedName, rawArgs) {
  const cleanArgs = String(rawArgs || '').trim().replace(/^\{|\}$/g, '');
  if (!cleanArgs) return '';

  if (['bash', 'shell', 'shellcommand', 'command'].includes(normalizedName)) {
    return _truncateText(_extractParamValue(cleanArgs, ['command', 'cmd']) || cleanArgs, 140);
  }

  if (['read', 'readfile', 'write', 'writefile', 'createfile', 'edit', 'editfile', 'multiedit', 'update', 'notebookread', 'notebookedit'].includes(normalizedName)) {
    return _truncateText(_extractParamValue(cleanArgs, ['file_path', 'filepath', 'path', 'file']) || cleanArgs, 120);
  }

  if (['search', 'searchcontent', 'grep', 'glob', 'find', 'findfiles', 'ls', 'websearch'].includes(normalizedName)) {
    const pattern = _extractParamValue(cleanArgs, ['pattern', 'query', 'q', 'keyword']);
    const searchPath = _extractParamValue(cleanArgs, ['path', 'file_path', 'scope']);
    if (pattern && searchPath) return _truncateText(`${pattern} @ ${searchPath}`, 120);
    return _truncateText(pattern || searchPath || cleanArgs, 120);
  }

  if (normalizedName.startsWith('task') || normalizedName === 'agent') {
    return _truncateText(
      _extractParamValue(cleanArgs, ['summary', 'description', 'message', 'prompt', 'content', 'output', 'result']) || cleanArgs,
      140
    );
  }

  return _truncateText(cleanArgs, 120);
}

function _parseToolTraceLine(line) {
  const stripped = _stripTracePrefix(line);
  if (!stripped) return null;
  if (/^```/.test(stripped)) return null;

  let m = stripped.match(/^([A-Za-z][A-Za-z0-9_ -]{1,32})\s*\((.*)\)\s*$/);
  let rawName = '';
  let rawArgs = '';

  if (m) {
    rawName = String(m[1] || '').trim();
    rawArgs = String(m[2] || '').trim();
  } else {
    m = stripped.match(/^([A-Za-z][A-Za-z0-9_ -]{1,32})\s*[:：]\s*(.+)$/);
    if (!m) return null;
    rawName = String(m[1] || '').trim();
    rawArgs = String(m[2] || '').trim();
  }

  const normalizedName = rawName.toLowerCase().replace(/[\s_-]/g, '');
  if (!_TOOL_TRACE_NAMES.has(normalizedName) && !normalizedName.startsWith('task')) {
    return null;
  }

  const displayName = getToolDisplayName(rawName) || rawName;
  const summary = _summarizeToolTraceArgs(normalizedName, rawArgs);
  return { displayName, summary };
}

function _normalizeToolTraceInPlainText(text) {
  const lines = String(text || '').split('\n');
  const out = [];
  const maxTableWidth = Math.max(
    24,
    Math.min(70, (process.stdout.columns || 80) - 10)
  );
  const toolCellWidth = Math.min(14, Math.max(8, Math.floor(maxTableWidth * 0.28)));
  const summaryCellWidth = Math.max(12, maxTableWidth - toolCellWidth - 7);
  let i = 0;

  while (i < lines.length) {
    const first = _parseToolTraceLine(lines[i]);
    if (!first) {
      out.push(lines[i]);
      i++;
      continue;
    }

    const block = [first];
    i++;
    while (i < lines.length) {
      const parsed = _parseToolTraceLine(lines[i]);
      if (!parsed) break;
      block.push(parsed);
      i++;
    }

    if (out.length > 0 && String(out[out.length - 1] || '').trim()) out.push('');
    out.push('工具步骤：');
    out.push('| 工具 | 参数摘要 |');
    out.push('| --- | --- |');
    for (const item of block) {
      const toolCell = _sanitizeToolTableCell(item.displayName, toolCellWidth);
      const summaryCell = _sanitizeToolTableCell(item.summary || '-', summaryCellWidth);
      out.push(`| ${toolCell} | ${summaryCell} |`);
    }
    if (i < lines.length && String(lines[i] || '').trim()) out.push('');
  }

  return out.join('\n');
}

function _normalizeToolTraceSections(text) {
  const source = String(text || '');
  if (!source) return source;
  const parts = source.split(/(```[\s\S]*?```)/g);
  return parts.map((part) => {
    if (part.startsWith('```')) return part;
    return _normalizeToolTraceInPlainText(part);
  }).join('');
}

/**
 * Render a complete AI response with all formatting.
 * @param {string} text - raw AI response text
 * @param {object} [opts]
 * @param {object} [opts.chalk] - chalk instance
 * @returns {string} rendered text for console output
 */
function renderAiResponse(text) {
  if (!text) return '';

  // Normalize raw tool trace lines into a consistent "steps" section first.
  let rendered = _normalizeToolTraceSections(text);

  // First handle diff blocks
  rendered = renderResponseWithDiffs(rendered);

  // Then apply markdown-lite
  rendered = renderMarkdownLite(rendered);

  // Add lightweight Unicode guidance markers where useful.
  rendered = _decorateResponseWithUnicode(rendered);

  // Word-wrap long lines to terminal width
  const cols = (process.stdout.columns || 80) - 6; // leave margin for │ prefix
  if (cols > 20) {
    rendered = rendered.split('\n').map(l => wrapLine(l, cols)).join('\n');
  }

  return rendered;
}

// ── Process Step Indicators (Claude Code style) ────────────────────────

// Match Claude Code's exact indicator symbols
// Claude Code uses ● (BLACK_CIRCLE) for all statuses, colored by state
const _isMac = process.platform === 'darwin';
const DOT_PENDING  = '○';                     // not started
const DOT_INDICATOR = '●';                    // in-progress (colored by context)
const DOT_SUCCESS  = '●';                     // completed (green)
const DOT_ERROR    = '●';                     // failed (red)
const DOT_DONE     = '●';                     // finished (dimmed)

// ── Tool Family Icons ─────────────────────────────────────────────────
// 不同工具类别用不同图标，一眼区分操作类型
// 旧版 Windows 终端 (Consolas) 缺少 ⌕⊙◐☐，降级为 ASCII
const { isLegacyWinTerminal: _isLegacyWinTerm } = require('../tools/platformUtils');
const _lwt = _isLegacyWinTerm();

const TOOL_FAMILY_ICONS = {
  bash: _lwt ? '>' : '▶',       // 执行
  shell: _lwt ? '>' : '▶',
  shellcommand: _lwt ? '>' : '▶',
  command: _lwt ? '>' : '▶',
  read: _lwt ? '>' : '▷',       // 读取
  readfile: _lwt ? '>' : '▷',
  notebookread: _lwt ? '>' : '▷',
  write: _lwt ? '+' : '◆',      // 写入
  writefile: _lwt ? '+' : '◆',
  createfile: _lwt ? '+' : '◆',
  edit: _lwt ? '~' : '◇',       // 编辑
  editfile: _lwt ? '~' : '◇',
  multiedit: _lwt ? '~' : '◇',
  notebookedit: _lwt ? '~' : '◇',
  glob: _lwt ? '?' : '⌕',       // 搜索
  grep: _lwt ? '?' : '⌕',
  find: _lwt ? '?' : '⌕',
  findfiles: _lwt ? '?' : '⌕',
  search: _lwt ? '?' : '⌕',
  searchcontent: _lwt ? '?' : '⌕',
  ls: _lwt ? '?' : '⌕',
  websearch: _lwt ? '@' : '⊙',  // 网络
  webfetch: _lwt ? '@' : '⊙',
  agent: _lwt ? '*' : '◐',      // 代理
  task: _lwt ? '*' : '◐',
  todowrite: _lwt ? '#' : '☐',  // 任务
};

/**
 * 获取工具家族图标，未匹配的返回默认 ●
 */
function getToolFamilyIcon(toolName) {
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
  return TOOL_FAMILY_ICONS[name] || DOT_INDICATOR;
}
const TREE_LAST    = _lwt ? '`-' : '⎿';                     // Claude Code uses ⎿ for tree branches
const TREE_MID     = _lwt ? '|-' : '├';

let _sparkleTimers = new Set();

/**
 * Start an animated spinner for tool call in-progress display.
 * Uses a blinking solid dot to match Claude Code active step indicator.
 *
 * @param {string} label - tool display name (e.g. "Bash", "Read")
 * @param {string} target - parameter string
 * @param {string} detail - extra detail
 * @returns {{ stop: Function }}
 */
function startSparkle(label, target = '', detail = '') {
  if (!process.stdout.isTTY) return { stop() {} };

  let frame = 0;
  const startTime = Date.now();
  const ELAPSED_SHOW_THRESHOLD = 2; // show elapsed after 2s (Qwen Code style)
  const ELAPSED_WARN_THRESHOLD = 8; // shift to red after 8s

  const timer = setInterval(() => {
    if (isInteractiveInputActive()) return;
    if (process.stdin.isRaw) return;
    frame++;
    const blinkDim = frame % 2 === 0;
    const elapsed = (Date.now() - startTime) / 1000;

    // Color: normal → red after 8s (gradual shift)
    let charColor;
    if (elapsed > ELAPSED_WARN_THRESHOLD) {
      const t = Math.min(1, (elapsed - ELAPSED_WARN_THRESHOLD) / 12);
      const r = Math.round(169 + (255 - 169) * t);
      const g = Math.round(169 + (107 - 169) * t);
      const b = Math.round(169 + (128 - 169) * t);
      charColor = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    } else {
      charColor = THEME.text;
    }
    const icon = blinkDim
      ? c().hex(charColor).dim(DOT_INDICATOR)
      : c().hex(charColor)(DOT_INDICATOR);
    const targetStr = target ? c().dim(`(${target})`) : '';
    const detailStr = detail ? c().dim(` ${detail}`) : '';

    // Elapsed time display (Qwen Code: >2s show, DeepSeek: "running (5s)")
    let elapsedStr = '';
    if (elapsed >= ELAPSED_SHOW_THRESHOLD) {
      const secs = Math.floor(elapsed);
      const elapsedText = _formatElapsed(secs);
      if (elapsed > ELAPSED_WARN_THRESHOLD) {
        elapsedStr = ` ${c().hex(THEME.error)(elapsedText)}`;
      } else {
        elapsedStr = ` ${c().dim(elapsedText)}`;
      }
    }

    const line = `  ${icon} ${c().bold(label)} ${targetStr}${detailStr}${elapsedStr}`;
    process.stdout.write(`\r\x1b[K${line}`);
  }, 120); // 120ms = ~8fps matching Claude Code

  _sparkleTimers.add(timer);

  return {
    stop() {
      clearInterval(timer);
      _sparkleTimers.delete(timer);
      if (!isInteractiveInputActive()) {
        process.stdout.write('\r\x1b[K');
      }
    },
  };
}

/**
 * Print a single process step line (Claude Code style).
 * @param {'pending'|'active'|'success'|'error'|'done'} status
 * @param {string} label - e.g. "Read", "Bash", "Write", "Search", "Update"
 * @param {string} [target] - e.g. "src/cli/repl.js", "node -c ..."
 * @param {string} [detail] - e.g. "(ctrl+o to expand)", "→ OK"
 */
function printStepLine(status, label, target = '', detail = '') {
  let dot;
  switch (status) {
    case 'active':  dot = c().hex(THEME.text)(DOT_INDICATOR); break;
    case 'success': dot = c().hex(THEME.success)(DOT_SUCCESS); break;
    case 'error':   dot = c().hex(THEME.error)(DOT_ERROR); break;
    case 'done':    dot = c().dim(DOT_DONE); break;
    default:        dot = c().dim(DOT_PENDING); break;
  }

  const targetStr = target ? c().dim(`(${target})`) : '';
  const detailStr = detail ? c().dim(` ${detail}`) : '';
  const labelColor = status === 'success' ? c().hex(THEME.success)(label)
                   : status === 'error'   ? c().hex(THEME.error)(label)
                   : status === 'active'  ? c().hex(THEME.text).bold(label)
                   : c().dim(label);

  console.log(`  ${dot} ${labelColor} ${targetStr}${detailStr}`);
}

/**
 * Print an indented detail line with tree branch character.
 * @param {string} text - detail text
 * @param {boolean} [isLast=true] - whether this is the last detail line
 */
function printStepDetail(text, isLast = true) {
  // Claude Code style: ⎿ prefix for result detail lines
  const branch = isLast ? TREE_LAST : TREE_MID;
  console.log(`  ${c().dim(branch)}  ${c().dim(text)}`);
}

/**
 * ProcessTracker — manages a sequence of process steps with live updates.
 *
 * Usage:
 *   const tracker = new ProcessTracker();
 *   tracker.start('Reading', 'src/cli/repl.js', '1 file...');
 *   // ... do work ...
 *   tracker.complete('Read 245 lines');
 *   tracker.start('Write', 'src/cli/ai.js');
 *   // ... do work ...
 *   tracker.complete('Added 3 lines');
 */
class ProcessTracker {
  constructor() {
    this._current = null;
    this._startTime = null;
    this._sparkle = null;
  }

  /**
   * Start a new step. Completes any previous in-progress step first.
   * @param {string} label - e.g. "Reading", "Write", "Bash", "AI 思考"
   * @param {string} [target] - e.g. file path, command, etc.
   * @param {string} [hint] - e.g. "1 file...", "ctrl+o to expand"
   */
  start(label, target = '', hint = '') {
    // Auto-complete previous step if still active
    if (this._current) {
      this._finishCurrent('done');
    }
    this._current = { label, target, hint };
    this._startTime = Date.now();

    // Print the initial static line, then overlay sparkle animation
    printStepLine('active', label, target, hint);
    this._sparkle = startSparkle(label, target, hint);

    // Sync to HUD
    try { require('./hudRenderer').toolStart(label, target); } catch {}
  }

  /**
   * Complete the current step — shows gray ✳ (finished, no longer active).
   * @param {string} [detail] - completion detail shown on tree line
   */
  complete(detail = '') {
    this._finishCurrent('done', detail);
  }

  /**
   * Mark the current step as failed.
   * @param {string} [detail] - error detail shown on tree line
   */
  fail(detail = '') {
    this._finishCurrent('error', detail);
  }

  /**
   * Internal: overwrite current active line with final status + detail.
   */
  _finishCurrent(status, detail = '') {
    if (!this._current) return;

    // Stop sparkle animation
    if (this._sparkle) {
      this._sparkle.stop();
      this._sparkle = null;
    }

    const elapsed = Date.now() - this._startTime;
    const elapsedStr = elapsed > 1000 ? ` (${(elapsed / 1000).toFixed(1)}s)` : '';

    // Sync to HUD
    try { require('./hudRenderer').toolEnd(this._current.label, status, elapsed); } catch {}

    if (process.stdout.isTTY && !isInteractiveInputActive()) {
      // Move cursor up to overwrite the active line
      process.stdout.write('\x1b[1A\r\x1b[K'); // up 1 line, clear
      const { label, target } = this._current;
      printStepLine(status, label, target, elapsedStr);
    } else if (process.stdout.isTTY) {
      // Keep output stable while user is typing a busy-time interjection.
      const { label, target } = this._current;
      printStepLine(status, label, target, elapsedStr);
    }
    // On non-TTY, skip rewrite — the active line stays as-is (no double output)

    if (detail) {
      printStepDetail(detail);
    }

    this._current = null;
    this._startTime = null;
  }

  /**
   * Whether a step is currently in progress.
   */
  get isActive() {
    return this._current !== null;
  }
}

// ── Task Plan Tracker (Claude Code style task list) ────────────────────

const TASK_PENDING     = '☐';
const TASK_IN_PROGRESS = '■';
const TASK_COMPLETED   = '✔';

/**
 * TaskPlanTracker — displays and updates a task checklist.
 *
 * Usage:
 *   const plan = new TaskPlanTracker();
 *   plan.addTask('Fetch market data');
 *   plan.addTask('Run backtest');
 *   plan.addTask('Generate report');
 *   plan.render();          // show all tasks
 *   plan.start(0);          // mark first as in-progress → re-render
 *   plan.complete(0);       // mark as done → re-render
 */
class TaskPlanTracker {
  constructor(options = {}) {
    this._tasks = [];
    this._renderedLines = 0; // how many lines the last render() produced
    this._rewriteInPlace = options.rewriteInPlace !== false;
  }

  /**
   * Add a task to the plan.
   * @param {string} description
   * @returns {number} task index
   */
  addTask(description) {
    this._tasks.push({ description, status: 'pending' });
    return this._tasks.length - 1;
  }

  /**
   * Mark a task as in-progress.
   */
  start(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'in_progress';
      this._rerender(index);
    }
  }

  /**
   * Mark a task as completed.
   */
  complete(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'completed';
      this._rerender(index);
    }
  }

  /**
   * Mark a task as failed.
   */
  fail(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'error';
      this._rerender(index);
    }
  }

  /**
   * Get summary line: "4 tasks (2 done, 1 in progress, 1 open)"
   */
  getSummary() {
    const done = this._tasks.filter(t => t.status === 'completed').length;
    const inProgress = this._tasks.filter(t => t.status === 'in_progress').length;
    const open = this._tasks.filter(t => t.status === 'pending').length;
    const errored = this._tasks.filter(t => t.status === 'error').length;

    const parts = [];
    if (done > 0)       parts.push(`${done} done`);
    if (inProgress > 0) parts.push(`${inProgress} in progress`);
    if (open > 0)       parts.push(`${open} open`);
    if (errored > 0)    parts.push(`${errored} failed`);

    return `${this._tasks.length} tasks (${parts.join(', ')})`;
  }

  /**
   * Render the full task list to stdout.
   */
  render() {
    console.log('');
    console.log(c().dim(`  ${this.getSummary()}`));
    for (const task of this._tasks) {
      let icon, color;
      switch (task.status) {
        case 'completed':
          icon = c().green(TASK_COMPLETED);
          color = c().strikethrough.dim;
          break;
        case 'in_progress':
          icon = c().yellow(TASK_IN_PROGRESS);
          color = c().bold.white;
          break;
        case 'error':
          icon = c().red('✗');
          color = c().red;
          break;
        default:
          icon = c().dim(TASK_PENDING);
          color = c().white;
          break;
      }
      console.log(`    ${icon} ${color(task.description)}`);
    }
    this._renderedLines = this._tasks.length + 2; // summary + blank + tasks
  }

  /**
   * Re-render by clearing previous output and printing again.
   */
  _rerender(changedIndex = -1) {
    if (!this._rewriteInPlace) {
      const task = this._tasks[changedIndex];
      if (task) {
        let icon, color;
        switch (task.status) {
          case 'completed':
            icon = c().green(TASK_COMPLETED);
            color = c().dim;
            break;
          case 'in_progress':
            icon = c().yellow(TASK_IN_PROGRESS);
            color = c().white;
            break;
          case 'error':
            icon = c().red('✗');
            color = c().red;
            break;
          default:
            icon = c().dim(TASK_PENDING);
            color = c().white;
            break;
        }
        console.log(`  ${icon} [${changedIndex + 1}/${this._tasks.length}] ${color(task.description)}`);
        console.log(c().dim(`  ${this.getSummary()}`));
      } else {
        this.render();
      }
      return;
    }

    if (this._renderedLines > 0 && process.stdout.isTTY) {
      // Move up and clear previous render
      for (let i = 0; i < this._renderedLines; i++) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
    }
    this.render();
  }

  /**
   * Extract tasks from an AI response containing a numbered plan.
   * Looks for patterns like "1. xxx\n2. xxx\n3. xxx" under a "计划"/"步骤" heading.
   * @param {string} text - AI response text
   * @returns {boolean} true if tasks were extracted
   */
  extractFromResponse(text) {
    // Look for numbered items (Chinese or English)
    const planPattern = /(?:^|\n)\s*(\d+)[.、）)]\s*(.+)/g;
    const matches = [...text.matchAll(planPattern)];

    if (matches.length >= 2) {
      for (const m of matches) {
        this.addTask(m[2].trim().slice(0, 60));
      }
      return true;
    }
    return false;
  }

  get length() { return this._tasks.length; }
  get allDone() { return this._tasks.every(t => t.status === 'completed' || t.status === 'error'); }
}

// ── Context Compaction Notice ──────────────────────────────────────────

/**
 * Print a "Compacting conversation..." notice (Claude Code style).
 * @param {object} opts - { elapsed, tokens, thought }
 */
function printCompactingNotice(opts = {}) {
  const parts = [];
  if (opts.elapsed) parts.push(opts.elapsed);
  if (opts.tokens)  parts.push(`↑ ${opts.tokens} tokens`);
  if (opts.thought) parts.push(`thought for ${opts.thought}`);

  const meta = parts.length > 0 ? c().dim(` (${parts.join(' · ')})`) : '';
  // Claude Code style: ✻ Conversation compacted
  console.log(`  ${c().hex(THEME.warning)('✻')} ${c().hex(THEME.warning).bold('Conversation compacted')}${meta}`);

  if (opts.tip) {
    printStepDetail(`Tip: ${opts.tip}`);
  }
}

// ── Legacy helpers (preserved for backward compatibility) ──────────────

function printProcessStep(icon, message, detail = '') {
  const detailStr = detail ? c().dim(` (${detail})`) : '';
  console.log(`  ${icon} ${c().white(message)}${detailStr}`);
}

function printToolCall(toolName, args = '') {
  const displayName = getToolDisplayName(toolName);
  const icon = getToolFamilyIcon(toolName);
  const targetStr = args ? c().dim(`(${args})`) : '';
  console.log(`  ${c().hex(THEME.text)(icon)} ${c().hex(THEME.text).bold(displayName)} ${targetStr}`);
}

/**
 * Print a brief description line before an action (Claude Code style).
 * Shows a dim one-liner explaining what will be done next.
 * @param {string} description - e.g. "Updating the spinner icon to use ✳"
 */
function printActionHint(description) {
  console.log(c().dim(`  ${description}`));
}

function printThinkingStep(thought) {
  const truncated = thought.length > 80 ? thought.slice(0, 80) + '...' : thought;
  console.log(`  ${c().dim(DOT_DONE)} ${c().dim(truncated)}`);
}

// ── Claude Code-style Tool Call Display ──────────────────────────────

/**
 * Print a tool call start line (Claude Code style).
/**
 * Generate a natural, conversational intent description for a tool call.
 * Prioritizes the AI-provided description; falls back to auto-generated text.
 * Returns empty string if no meaningful intent can be inferred.
 */
function _describeToolIntent(normalizedName, params = {}) {
  const p = _coerceToolParams(params);
  const filePath = String(p.file_path || p.filePath || p.path || '').trim();
  const fileName = filePath ? require('path').basename(filePath) : '';
  const command = String(p.command || p.cmd || '').trim();
  const pattern = String(p.pattern || '').trim();
  const query = String(p.query || p.q || '').trim();
  const url = String(p.url || '').trim();

  switch (normalizedName) {
    case 'read':
    case 'readfile':
    case 'notebookread':
      if (fileName) return `看看 ${fileName} 里的内容`;
      return '读取文件内容';

    case 'write':
    case 'writefile':
    case 'createfile':
      if (fileName) return `把改动写入 ${fileName}`;
      return '写入文件';

    case 'edit':
    case 'editfile':
    case 'multiedit':
      if (fileName) return `修改 ${fileName}`;
      return '编辑文件';

    case 'bash':
    case 'shell':
    case 'shellcommand':
    case 'command': {
      if (!command) return '';
      // Recognize common command patterns
      const first = command.split(/\s+/)[0].replace(/^.*\//, ''); // basename
      if (first === 'find') return '搜索文件系统，找到匹配的文件';
      if (first === 'ls') return '看看目录下有哪些文件';
      if (first === 'cat' || first === 'head' || first === 'tail') return '查看文件内容';
      if (first === 'git') {
        const sub = command.split(/\s+/)[1] || '';
        if (sub === 'status') return '看看当前 Git 状态';
        if (sub === 'log') return '查看最近的提交记录';
        if (sub === 'diff') return '对比一下改动';
        if (sub === 'clone') return '克隆仓库';
        if (sub === 'pull') return '拉取最新代码';
        if (sub === 'push') return '推送代码到远程';
        if (sub === 'checkout' || sub === 'switch') return '切换分支';
        if (sub === 'branch') return '查看或操作分支';
        if (sub === 'add') return '暂存文件改动';
        if (sub === 'commit') return '提交改动';
        if (sub === 'stash') return '暂存当前工作进度';
        return `执行 git ${sub}`;
      }
      if (first === 'npm' || first === 'yarn' || first === 'pnpm') {
        const sub = command.split(/\s+/)[1] || '';
        if (sub === 'install' || sub === 'i' || sub === 'add') return '安装依赖';
        if (sub === 'run') return '运行脚本';
        if (sub === 'test') return '跑一下测试';
        if (sub === 'build') return '构建项目';
        return `运行 ${first} ${sub}`;
      }
      if (first === 'pip' || first === 'pip3') return '管理 Python 依赖';
      if (first === 'python' || first === 'python3' || first === 'node') return '运行脚本';
      if (first === 'mkdir') return '创建目录';
      if (first === 'rm') return '删除文件';
      if (first === 'cp') return '复制文件';
      if (first === 'mv') return '移动文件';
      if (first === 'chmod') return '修改文件权限';
      if (first === 'curl' || first === 'wget') return '请求远程资源';
      if (first === 'docker') return '操作 Docker 容器';
      if (first === 'make') return '执行构建任务';
      if (first === 'grep' || first === 'rg') return '在文件中搜索内容';
      if (first === 'sed' || first === 'awk') return '处理文本';
      if (first === 'ssh') return '连接远程服务器';
      if (first === 'tar' || first === 'zip' || first === 'unzip') return '处理压缩包';
      // Generic fallback — keep it conversational
      return `执行 ${first} 命令`;
    }

    case 'grep':
    case 'search':
    case 'searchcontent':
      if (pattern && fileName) return `在 ${fileName} 里搜索 "${pattern}"`;
      if (pattern) return `搜索包含 "${pattern}" 的文件`;
      return '在代码中搜索';

    case 'glob':
    case 'find':
    case 'findfiles':
    case 'ls':
      if (pattern) return `查找匹配 ${pattern} 的文件`;
      if (filePath) return `查看 ${fileName || filePath} 的结构`;
      return '查找文件';

    case 'websearch':
      if (query) return `搜索一下: ${query.slice(0, 60)}`;
      return '搜索网络信息';

    case 'webfetch':
      if (url) return `获取网页内容`;
      return '抓取网页';

    case 'agent':
    case 'task':
    case 'spawnworker':
    case 'subagent': {
      const role = String(p.role || p.subagent_type || '').trim();
      const prompt = String(p.prompt || '').trim();
      if (prompt) return `让 ${role || '子智能体'} 去处理: ${prompt.slice(0, 50)}`;
      return '分配子任务';
    }

    default:
      break;
  }

  // Optional fallback: trust model-provided description only when explicitly enabled.
  const trustDesc = ['1', 'true', 'yes', 'on'].includes(
    String(process.env.KHY_TOOL_INTENT_TRUST_DESCRIPTION || '').trim().toLowerCase()
  );
  if (trustDesc) {
    const aiDesc = String(p.description || '').trim();
    if (aiDesc) return _truncateNaturalText(aiDesc, 88);
  }
  return '';
}

/**
 * Print a tool call start line (Claude Code style).
 * Shows: ⏺ ToolName(param: "value", path: "file.js")
 *
 * @param {string} toolName - raw tool name, auto-mapped to display name
 * @param {object|string} params - tool parameters to display
 * @returns {number} line count printed (for cursor-up later)
 */
function printToolCallStart(toolName, params = {}) {
  const normalizedParams = _coerceToolParams(params);
  const displayName = getToolDisplayName(toolName);
  const paramStr = _formatToolParams(toolName, normalizedParams);
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');

  // Show conversational intent above the tool line
  const intent = _describeToolIntent(name, normalizedParams);
  if (intent) {
    console.log(`  ${c().dim(intent)}`);
  }

  // Active state: tool family icon + bold name + params
  const icon = getToolFamilyIcon(toolName);
  console.log(`  ${c().hex(THEME.text)(icon)} ${c().hex(THEME.text).bold(displayName)}${c().dim(`(${paramStr})`)}`);

  // Box-drawn command preview for Bash tools (claw-code style)
  if ((name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') && normalizedParams) {
    const cmd = normalizedParams.command || normalizedParams.cmd || '';
    if (cmd) {
      const cols = (process.stdout.columns || 80) - 8;
      const borderColor = c().hex(THEME.bashBorder);
      console.log(`    ${borderColor('╭─')}`);
      const cmdLines = cmd.split('\n');
      for (const line of cmdLines.slice(0, 8)) {
        const display = line.length > cols ? line.slice(0, cols - 3) + '...' : line;
        console.log(`    ${borderColor('│')} ${c().dim('$')} ${c().white(display)}`);
      }
      if (cmdLines.length > 8) console.log(`    ${borderColor('│')} ${c().dim(`... +${cmdLines.length - 8} lines`)}`);
      console.log(`    ${borderColor('╰─')}`);
    }
  }

  // Write/Edit: show file path with icon
  if ((name === 'write' || name === 'writefile' || name === 'createfile') && (normalizedParams?.file_path || normalizedParams?.filePath || normalizedParams?.path)) {
    const filePath = normalizedParams.file_path || normalizedParams.filePath || normalizedParams.path;
    console.log(`    ${c().dim('✏️  Writing')} ${c().cyan(filePath)} ${c().dim(`(${_estimateLines(normalizedParams.content)} lines)`)}`);
  }
  if ((name === 'edit' || name === 'editfile' || name === 'multiedit') && normalizedParams) {
    const filePath = normalizedParams.file_path || normalizedParams.filePath || normalizedParams.path || '';
    if (filePath) {
      console.log(`    ${c().dim('📝 Editing')} ${c().cyan(filePath)}`);
    }
  }

  return 1;
}

function _estimateLines(content) {
  if (!content) return 0;
  return String(content).split('\n').length;
}

/**
 * Format tool parameters for display, tool-type-aware.
 * Claude Code shows different formats per tool:
 *   Read → file_path
 *   Bash → command (truncated to 120 chars)
 *   Search/Grep → pattern: "X", path: "Y"
 *   Write/Update → file_path
 */
function _formatToolParams(toolName, params) {
  if (!params) return '';
  if (typeof params === 'string') return _formatToolParams(toolName, _coerceToolParams(params));
  if (params && typeof params === 'object' && params._raw && Object.keys(params).length === 1) {
    return _truncateNaturalText(String(params._raw), 100);
  }
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');

  if (name === 'read' || name === 'readfile') {
    return params.file_path || params.filePath || params.path || '';
  }
  if (name === 'notebookread') {
    return params.path || params.file_path || '';
  }
  if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
    const cmd = params.command || params.cmd || '';
    if (cmd) return _truncateNaturalText(cmd, 120);
    if (params.description) return _truncateNaturalText(String(params.description), 100);
    return '';
  }
  if (name === 'websearch') {
    const q = params.query || params.q || '';
    return _truncateNaturalText(q, 120);
  }
  if (name === 'webfetch') {
    const url = params.url || params.uri || params.href || '';
    return _truncateNaturalText(url, 120);
  }
  if (name === 'grep' || name === 'search' || name === 'searchcontent') {
    const parts = [];
    if (params.pattern) parts.push(`pattern: "${params.pattern}"`);
    if (params.path) parts.push(`path: "${params.path}"`);
    return parts.join(', ') || '';
  }
  if (name === 'glob' || name === 'find' || name === 'findfiles' || name === 'ls') {
    return [params.pattern, params.path].filter(Boolean).join(', ') || params.path || '';
  }
  if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
    return params.file_path || params.filePath || params.path || '';
  }
  if (name === 'agent' || name === 'task') {
    const role = params.role || params.subagent_type || params.agent_type || '';
    const prompt = params.description || params.prompt || params.message || '';
    const rolePrefix = role ? `${role}: ` : '';
    return _truncateNaturalText(`${rolePrefix}${prompt}`.trim(), 80);
  }
  if (name === 'todowrite') {
    const count = Array.isArray(params.todos) ? params.todos.length : 0;
    return count > 0 ? `${count} todos` : 'todos';
  }

  // Generic fallback
  if (typeof params === 'object') {
    return Object.entries(params).slice(0, 3)
      .map(([k, v]) => {
        const val = typeof v === 'string'
          ? _truncateNaturalText(v, 40)
          : String(v);
        return `${k}: ${val}`;
      }).join(', ');
  }
  return '';
}

/**
 * Print a tool call result, overwriting the active line.
 * Shows: ● ToolName(params) with green/red dot + tree detail line.
 *
 * @param {string} toolName
 * @param {object|string} params - same params as start (for redraw)
 * @param {'success'|'error'} status
 * @param {string} detail - result summary, e.g. "Found 3 matches", "245 lines"
 * @param {number} elapsed - ms elapsed
 */
// Store expanded outputs for ctrl+o expansion
const _expandableOutputs = [];

function printToolCallResult(toolName, params, status, detail = '', elapsed = 0) {
  let _syncWrite;
  try { _syncWrite = require('./syncOutput').syncWrite; } catch { _syncWrite = (fn) => fn(); }
  _syncWrite(() => _printToolCallResultInner(toolName, params, status, detail, elapsed));
}

function _printToolCallResultInner(toolName, params, status, detail = '', elapsed = 0) {
  const displayName = getToolDisplayName(toolName);
  const paramStr = _formatToolParams(toolName, params);
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
  const isBash = (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command');

  // For bash tools with box preview, don't move cursor up (multiple lines rendered)
  // For other tools, overwrite the active line
  if (process.stdout.isTTY && !isBash) {
    process.stdout.write('\x1b[1A\r\x1b[K');
  }

  // 使用工具家族图标 + 状态色
  const icon = getToolFamilyIcon(toolName);
  const dot = status === 'success'
    ? c().hex(THEME.success)(icon)
    : c().hex(THEME.error)(icon);
  const elapsedStr = elapsed > 0 ? c().dim(` ${(elapsed / 1000).toFixed(1)}s`) : '';
  console.log(`  ${dot} ${c().bold(displayName)}${c().dim(`(${paramStr})`)}${elapsedStr}`);

  // Claude Code: result on next line with ⎿ prefix, collapsible
  if (detail) {
    const lines = String(detail).split('\n');
    const MAX_VISIBLE = 6;
    const HEAD_LINES = 3;
    const TAIL_LINES = 3;

    // For bash tools, show output in a bordered box
    if (isBash && lines.length > 0) {
      const cols = (process.stdout.columns || 80) - 8;
      if (lines.length > MAX_VISIBLE) {
        // Head + tail with fold (DeepSeek style)
        const headLines = lines.slice(0, HEAD_LINES);
        const tailLines = lines.slice(-TAIL_LINES);
        for (const line of headLines) {
          const display = line.length > cols ? line.slice(0, cols - 3) + '...' : line;
          console.log(`    ${c().dim('⎿')} ${c().dim(display)}`);
        }
        const remaining = lines.length - HEAD_LINES - TAIL_LINES;
        console.log(`    ${c().dim('⎿')} ${c().dim(`... +${remaining} 行`)} ${c().dim('(ctrl+o 查看完整)')}`);
        for (const line of tailLines) {
          const display = line.length > cols ? line.slice(0, cols - 3) + '...' : line;
          console.log(`    ${c().dim('⎿')} ${c().dim(display)}`);
        }
        _expandableOutputs.push({ tool: displayName, detail: lines.join('\n'), paramStr });
      } else {
        for (const line of lines) {
          const display = line.length > cols ? line.slice(0, cols - 3) + '...' : line;
          console.log(`    ${c().dim('⎿')} ${c().dim(display)}`);
        }
      }
    } else if (lines.length > MAX_VISIBLE) {
      // Head + tail with collapse hint (DeepSeek style)
      const headLines = lines.slice(0, HEAD_LINES);
      const tailLines = lines.slice(-TAIL_LINES);
      for (const line of headLines) {
        console.log(`    ${c().dim('⎿')} ${c().dim(line)}`);
      }
      const remaining = lines.length - HEAD_LINES - TAIL_LINES;
      console.log(`    ${c().dim('⎿')} ${c().dim(`... +${remaining} 行`)} ${c().dim('(ctrl+o 查看完整)')}`);
      for (const line of tailLines) {
        console.log(`    ${c().dim('⎿')} ${c().dim(line)}`);
      }
      _expandableOutputs.push({ tool: displayName, detail: lines.join('\n'), paramStr });
    } else {
      for (const line of lines) {
        console.log(`    ${c().dim('⎿')} ${c().dim(line)}`);
      }
    }
  }
}

function getLastExpandableOutput() {
  return _expandableOutputs.length > 0 ? _expandableOutputs[_expandableOutputs.length - 1] : null;
}

function pushExpandableOutput(entry) {
  if (entry && typeof entry === 'object') _expandableOutputs.push(entry);
}

/**
 * Print a file operation result with line count statistics.
 * Shows Claude Code style: "Added N lines, removed M lines"
 *
 * @param {'update'|'create'|'delete'} operation
 * @param {string} filePath - file path relative to cwd
 * @param {object} [stats] - { added: number, removed: number, total: number }
 * @param {number} [elapsed] - ms elapsed
 */
function printFileOperation(operation, filePath, stats = {}, elapsed = 0) {
  // Claude Code: Update/Create/Write use green dot, Delete uses red dot
  const opColors = {
    update: { dot: c().hex(THEME.success)(DOT_SUCCESS), label: c().hex(THEME.success)('Update'), verb: 'Updated' },
    create: { dot: c().hex(THEME.success)(DOT_SUCCESS), label: c().hex(THEME.success)('Create'), verb: 'Created' },
    write:  { dot: c().hex(THEME.success)(DOT_SUCCESS), label: c().hex(THEME.success)('Write'), verb: 'Wrote' },
    delete: { dot: c().hex(THEME.error)(DOT_ERROR), label: c().hex(THEME.error)('Delete'), verb: 'Deleted' },
  };
  const op = opColors[operation] || opColors.update;
  const elapsedStr = elapsed > 500 ? c().dim(` (${(elapsed / 1000).toFixed(1)}s)`) : '';

  console.log(`  ${op.dot} ${c().bold(op.label)}${c().dim(`(${filePath})`)}${elapsedStr}`);

  // Claude Code: result line with ⎿ prefix — "Added X lines, removed Y lines"
  const statParts = [];
  if (stats.added > 0) statParts.push(`Added ${stats.added} line${stats.added !== 1 ? 's' : ''}`);
  if (stats.removed > 0) statParts.push(`removed ${stats.removed} line${stats.removed !== 1 ? 's' : ''}`);
  if (statParts.length > 0) {
    console.log(`  ${c().dim('\u23BF')}  ${c().dim(statParts.join(', '))}`);
  }
}

/**
 * Print a diff view with line numbers and red/green coloring.
 * Includes context lines around changes.
 *
 * @param {string} filePath
 * @param {Array<{lineNum: number, type: 'add'|'remove'|'context', content: string}>} lines
 * @param {object} [stats] - { added, removed }
 */
function printInlineDiff(filePath, lines, stats = {}) {
  const maxLineNum = Math.max(...lines.map(l => l.lineNum || 0));
  const lineNumWidth = String(maxLineNum).length;

  for (const line of lines) {
    const num = String(line.lineNum || '').padStart(lineNumWidth);
    switch (line.type) {
      case 'add':
        // Claude Code: rgb(34,92,43) background for added lines
        console.log(c().bgHex(THEME.diffAdded).hex('#FFFFFF')(`  ${num} + ${line.content}`));
        break;
      case 'remove':
        // Claude Code: rgb(122,41,54) background for removed lines
        console.log(c().bgHex(THEME.diffRemoved).hex('#FFFFFF')(`  ${num} - ${line.content}`));
        break;
      default:
        console.log(`  ${c().dim(num)}   ${c().dim(line.content)}`);
        break;
    }
  }
}

/**
 * Render "Running N agents..." header.
 * @param {number} count
 * @param {string} [hint] - e.g. "(ctrl+o to expand)"
 */
function renderAgentHeader(count, hint = '') {
  const hintStr = hint ? c().dim(`  ${hint}`) : '';
  console.log(`  ${c().hex(THEME.secondaryText)(DOT_INDICATOR)} ${c().bold(`Running ${count} agents...`)}${hintStr}`);
}

/**
 * Render tree-style agent progress.
 * @param {Array<{name: string, status: 'pending'|'running'|'completed'|'error', toolCalls?: number, tokens?: number, elapsed?: string, detail?: string}>} agents
 * @returns {number} lines rendered
 */
function renderAgentProgress(agents) {
  let lines = 0;
  for (let i = 0; i < agents.length; i++) {
    const agent = agents[i];
    const isLast = i === agents.length - 1;
    const branch = isLast ? '└' : '├';

    let statusIcon, nameColor;
    switch (agent.status) {
      case 'completed':
        statusIcon = c().hex(THEME.success)(DOT_DONE);
        nameColor = c().dim;
        break;
      case 'error':
        statusIcon = c().hex(THEME.error)(DOT_ERROR);
        nameColor = c().hex(THEME.error);
        break;
      case 'running':
        statusIcon = c().hex(THEME.secondaryText)(DOT_INDICATOR);
        nameColor = c().bold;
        break;
      default:
        statusIcon = c().dim(DOT_PENDING);
        nameColor = c().dim;
        break;
    }

    // Stats string: tool calls · tokens · elapsed
    const stats = [];
    if (agent.toolCalls > 0) stats.push(`${agent.toolCalls} tool uses`);
    if (agent.tokens > 0) {
      const tokenStr = agent.tokens >= 1000
        ? `${(agent.tokens / 1000).toFixed(1)}k tokens`
        : `${agent.tokens} tokens`;
      stats.push(tokenStr);
    }
    if (agent.elapsed) stats.push(agent.elapsed);
    const statsStr = stats.length > 0 ? c().dim(` · ${stats.join(' · ')}`) : '';

    // Claude Code style: ⏺ AgentName with status-colored dot
    console.log(`    ${statusIcon} ${nameColor(agent.name)}${statsStr}`);
    lines++;

    // Detail line with ⎿ prefix
    if (agent.detail) {
      console.log(`      ${c().dim('\u23BF')}  ${c().dim(agent.detail)}`);
      lines++;
    }
  }
  return lines;
}

/**
 * Render agent/task completion summary line.
 * Shows: Done (N tool uses · X.Xk tokens · Nm NNs)
 *
 * @param {object} stats - { toolCalls, tokens, elapsedMs }
 */
function renderAgentDone(stats = {}) {
  const parts = [];
  if (stats.toolCalls > 0) parts.push(`${stats.toolCalls} tool uses`);
  if (stats.tokens > 0) {
    parts.push(`${(stats.tokens / 1000).toFixed(1)}k tokens`);
  }
  if (stats.elapsedMs > 0) {
    const sec = Math.floor(stats.elapsedMs / 1000);
    const min = Math.floor(sec / 60);
    const remSec = sec % 60;
    parts.push(min > 0 ? `${min}m ${remSec}s` : `${sec}s`);
  }

  const detail = parts.length > 0 ? ` (${parts.join(' · ')})` : '';
  // Claude Code: ⎿ Done summary
  console.log(`  ${c().dim('\u23BF')}  ${c().hex(THEME.success)('Done')}${c().dim(detail)}`);
}

/**
 * Render "(ctrl+o to expand)" hint.
 */
function renderExpandHint() {
  console.log(c().dim('  (ctrl+o to expand)'));
}

/**
 * ExpandableSection — manages collapsible output sections.
 * Stores full output but displays only a summary until expanded.
 */
class ExpandableSection {
  constructor() {
    this._sections = [];
    this._expandedIndex = -1;
  }

  /**
   * Add a collapsible section.
   * @param {string} summary - one-line summary shown when collapsed
   * @param {string[]} fullOutput - full output lines shown when expanded
   */
  add(summary, fullOutput) {
    this._sections.push({ summary, fullOutput, expanded: false });
    return this._sections.length - 1;
  }

  /**
   * Toggle expand/collapse of a section.
   */
  toggle(index) {
    if (index >= 0 && index < this._sections.length) {
      this._sections[index].expanded = !this._sections[index].expanded;
    }
  }

  /**
   * Get all sections for display.
   */
  getSections() {
    return this._sections;
  }
}

/**
 * ToolUseTracker — Claude Code-style collapsible tool-use display.
 *
 * While running, shows:
 *   ● Explore(Explore training infrastructure)
 *     ├ Bash(grep -r "train.*start" /path/to/dir)
 *     │ Running...
 *     ├ Read(backend/src/cli/router.js)
 *     │ Running...
 *     └ +12 more tool uses (ctrl+o to expand)
 *     (ctrl+b to run in background)
 *
 * When done, collapses to:
 *   ● Explore(Explore training infrastructure)
 *     └ Done (24 tool uses · 60.9k tokens · 2m 15s)
 *     (ctrl+o to expand)
 */
class ToolUseTracker {
  /**
   * @param {string} label - Top-level label (e.g. "Explore", "Agent")
   * @param {string} description - Short description (e.g. "Explore training infrastructure")
   * @param {object} [opts]
   * @param {number} [opts.maxVisible=3] - Max tool calls visible before "+N more"
   */
  constructor(label, description, opts = {}) {
    this._label = label;
    this._description = description;
    this._maxVisible = opts.maxVisible || 3;
    this._tools = [];          // [{ name, params, status, elapsed, detail }]
    this._renderedLines = 0;
    this._startTime = Date.now();
    this._totalTokens = 0;
    this._finished = false;
    this._headerPrinted = false;
  }

  /**
   * Print the header line (call once before adding tools).
   * Claude Code style: ⏺ Agent(description)
   */
  printHeader() {
    if (this._headerPrinted) return;
    this._headerPrinted = true;
    const displayName = getToolDisplayName(this._label);
    const icon = getToolFamilyIcon(this._label);
    console.log(`  ${c().hex(THEME.secondaryText)(icon)} ${c().bold(displayName)}${c().dim(`(${this._description})`)}`);
    this._renderedLines = 1;
  }

  /**
   * Record a tool call starting.
   * @param {string} name - Tool name (e.g. "Read", "Bash", "Grep")
   * @param {string} params - Brief param string
   */
  toolStart(name, params = '') {
    const summary = summarizeToolDetail(name, params);
    this._tools.push({ name, params: summary.short, kind: summary.kind, status: 'running', elapsed: 0, detail: '', startTime: Date.now() });
    this._rerender();
  }

  /**
   * Record a tool call completing.
   * @param {string} name - Tool name
   * @param {'success'|'error'} status
   * @param {string} [detail]
   * @param {number} [elapsed] - ms
   */
  toolEnd(name, status = 'success', detail = '', elapsed = 0) {
    // Find the most recent matching running tool
    for (let i = this._tools.length - 1; i >= 0; i--) {
      if (this._tools[i].name === name && this._tools[i].status === 'running') {
        this._tools[i].status = status;
        this._tools[i].detail = detail;
        this._tools[i].elapsed = elapsed || (Date.now() - this._tools[i].startTime);
        break;
      }
    }
    this._rerender();
  }

  /**
   * Add token count.
   * @param {number} tokens
   */
  addTokens(tokens) {
    this._totalTokens += tokens;
  }

  /**
   * Mark as finished and collapse to summary.
   */
  finish() {
    this._finished = true;
    this._rerender();
  }

  /**
   * Clear previously rendered lines and re-render.
   */
  _rerender() {
    if (!this._headerPrinted) this.printHeader();

    // Clear previous tool lines (not the header)
    if (process.stdout.isTTY && this._renderedLines > 1) {
      for (let i = 0; i < this._renderedLines - 1; i++) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
    }

    let lines = 0;

    if (this._finished) {
      // Replace header with green dot (Claude Code: success color)
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
      const displayName = getToolDisplayName(this._label);
      const icon = getToolFamilyIcon(this._label);
      console.log(`  ${c().hex(THEME.success)(icon)} ${c().bold(displayName)}${c().dim(`(${this._description})`)}`);
      lines++;

      // Summary line
      const elapsed = Date.now() - this._startTime;
      const parts = [];
      parts.push(`${this._tools.length} tool uses`);
      if (this._totalTokens > 0) {
        parts.push(this._totalTokens >= 1000
          ? `${(this._totalTokens / 1000).toFixed(1)}k tokens`
          : `${this._totalTokens} tokens`);
      }
      const sec = Math.floor(elapsed / 1000);
      const min = Math.floor(sec / 60);
      const remSec = sec % 60;
      parts.push(min > 0 ? `${min}m ${remSec}s` : `${sec}s`);

      // Claude Code: ⎿ summary with (ctrl+o to expand)
      console.log(`  ${c().dim('\u23BF')}  ${c().hex(THEME.success)('Done')} ${c().dim(`(${parts.join(' · ')})`)}`);
      lines++;
      console.log(c().dim('    (ctrl+o to expand)'));
      lines++;

      this._renderedLines = 1 + lines;
      return;
    }

    // Running state: show recent tools with Claude Code tree style
    const visible = this._tools.slice(-this._maxVisible);
    const hiddenCount = Math.max(0, this._tools.length - this._maxVisible);

    for (let i = 0; i < visible.length; i++) {
      const tool = visible[i];
      const displayName = getToolDisplayName(tool.name);
      const toolIcon = getToolFamilyIcon(tool.name);
      const paramStr = tool.params ? tool.params.slice(0, 80) : '';

      if (tool.status === 'running') {
        // Active tool: family icon + ToolName(params)
        console.log(`    ${c().hex(THEME.secondaryText)(toolIcon)} ${c().bold(displayName)}${paramStr ? c().dim(`(${paramStr})`) : ''}`);
        lines++;
        console.log(`      ${c().dim('Running\u2026')}`);
        lines++;
      } else if (tool.status === 'success') {
        // Completed: green family icon + ToolName(params)
        console.log(`    ${c().hex(THEME.success)(toolIcon)} ${c().bold(displayName)}${paramStr ? c().dim(`(${paramStr})`) : ''}`);
        lines++;
        if (tool.detail) {
          console.log(`      ${c().dim('\u23BF')}  ${c().dim(tool.detail)}`);
          lines++;
        }
      } else if (tool.status === 'error') {
        // Error: red family icon + ToolName(params)
        console.log(`    ${c().hex(THEME.error)(toolIcon)} ${c().bold(displayName)}${paramStr ? c().dim(`(${paramStr})`) : ''}`);
        lines++;
        const detail = tool.detail ? tool.detail : 'Failed';
        console.log(`      ${c().dim('\u23BF')}  ${c().hex(THEME.error)(detail)}`);
        lines++;
      }
    }

    if (hiddenCount > 0) {
      console.log(`    ${c().dim(`+${hiddenCount} more tool uses (ctrl+o to expand)`)}`);
      lines++;
    }

    console.log(c().dim('    (ctrl+b to run in background)'));
    lines++;

    this._renderedLines = 1 + lines;
  }

  /**
   * Get total tool count.
   */
  get toolCount() { return this._tools.length; }
  get totalTokens() { return this._totalTokens; }
  get elapsedMs() { return Date.now() - this._startTime; }
}

// ── Transparency Integration ──────────────────────────────────────────
// Wire transparencyService into the rendering pipeline.

let _transparency;
function _getTransparency() {
  if (_transparency !== undefined) return _transparency;
  try { _transparency = require('../services/transparencyService'); } catch { _transparency = null; }
  return _transparency;
}

/**
 * Print per-turn cost/token summary after an AI response.
 * Claude Code style: dim line below the response with token counts, cost, model.
 *
 * @param {object} usage - { inputTokens, outputTokens, cacheReadTokens, model, adapter, costUSD, durationMs }
 */
function printTurnCost(usage) {
  const t = _getTransparency();
  if (!t || !usage) return;
  const line = t.formatPostResponseLine(usage);
  if (line) console.log(line);
}

/**
 * Print cascade/fallback transparency when multiple adapters were tried.
 *
 * @param {Array<{adapter: string, success: boolean, error?: string, durationMs?: number}>} steps
 */
function printCascadeSteps(steps) {
  const t = _getTransparency();
  if (!t || !steps || steps.length <= 1) return;
  const line = t.formatCascadeSteps(steps);
  if (line) console.log(`  ${c().dim('cascade:')} ${line}`);
}

/**
 * Print permission tier for a shell command (inline, before execution).
 *
 * @param {object} classification - { tier, matchedRule, approved }
 */
function printPermissionTier(classification) {
  const t = _getTransparency();
  if (!t || !classification) return;
  // Only show for dangerous/critical (safe/moderate are quiet)
  if (classification.tier === 'safe' || classification.tier === 'moderate') return;
  const line = t.formatPermissionTier(classification);
  if (line) console.log(`    ${line}`);
}

/**
 * Print session recap on exit.
 *
 * @param {object} session - { durationMs, totalInputTokens, totalOutputTokens, totalCostUSD, requestCount, toolCallCount, model, topTools }
 */
function printSessionRecap(session) {
  const t = _getTransparency();
  if (!t || !session) return;
  const text = t.formatSessionRecap(session);
  if (text) process.stdout.write(text);
}

/**
 * Print a quota warning if approaching limit.
 *
 * @param {object} quota - { used, limit }
 */
function printQuotaWarning(quota) {
  const t = _getTransparency();
  if (!t || !quota) return;
  const warning = t.checkQuotaWarning(quota);
  if (warning) console.log(`  ${warning}`);
}

/**
 * Print context compaction notification.
 *
 * @param {object} compaction - { beforeTokens, afterTokens, durationMs }
 */
function printCompactionResult(compaction) {
  const t = _getTransparency();
  if (!t || !compaction) return;
  const line = t.formatCompactionNotice(compaction);
  if (line) console.log(`  ${line}`);
}

/**
 * Print edit diff preview before applying changes.
 *
 * @param {object} edit - { filePath, oldContent, newContent, lineStart }
 * @returns {boolean} true if preview was printed
 */
function printEditPreview(edit) {
  const t = _getTransparency();
  if (!t || !edit) return false;
  const preview = t.formatEditPreview(edit);
  if (!preview) return false;
  console.log(`    ${preview.header}`);
  for (const line of preview.diffLines) {
    console.log(`    ${line}`);
  }
  console.log(c().dim(`    ${preview.stats.removed} removed, ${preview.stats.added} added`));
  return true;
}

module.exports = {
  setInteractiveGuard,
  DynamicSpinner,
  ProcessTracker,
  TaskPlanTracker,
  ToolUseTracker,
  ExpandableSection,
  renderDiff,
  renderStructuredDiff,
  renderResponseWithDiffs,
  renderMarkdownLite,
  renderAiResponse,
  renderUserMessage,
  askInlineQuestion,
  printStepLine,
  printStepDetail,
  printCompactingNotice,
  printProcessStep,
  printToolCall,
  printActionHint,
  printToolCallStart,
  printToolCallResult,
  getLastExpandableOutput,
  pushExpandableOutput,
  printFileOperation,
  printInlineDiff,
  renderAgentHeader,
  renderAgentProgress,
  renderAgentDone,
  renderExpandHint,
  printThinkingStep,
  startSparkle,
  getToolDisplayName,
  getToolFamilyIcon,
  getToolKindLabel,
  normalizeToolKind,
  THEME,
  PHASE_LABELS,
  TOOL_DISPLAY_NAMES,
  TOOL_FAMILY_ICONS,
  DOT_PENDING,
  DOT_INDICATOR,
  DOT_SUCCESS,
  DOT_ERROR,
  DOT_DONE,
  TASK_PENDING,
  TASK_IN_PROGRESS,
  TASK_COMPLETED,
  // Transparency layer
  printTurnCost,
  printCascadeSteps,
  printPermissionTier,
  printSessionRecap,
  printQuotaWarning,
  printCompactionResult,
  printEditPreview,
};
