/**
 * Synchronized Output — 防止终端渲染撕裂
 *
 * 实现 "Synchronized Output" 协议 (DEC Private Mode 2026)：
 *   ESC[?2026h  — 开始同步帧（终端缓冲后续写入）
 *   ESC[?2026l  — 结束同步帧（终端一次性刷新）
 *
 * 支持终端：WezTerm, iTerm2, Kitty, foot, Contour, Windows Terminal (canary)
 * 不支持的终端会忽略这些序列（无副作用）。
 *
 * 用法：
 *   const { syncWrite, beginSync, endSync } = require('./syncOutput');
 *   syncWrite(() => {
 *     process.stdout.write(line1);
 *     process.stdout.write(line2);
 *   });
 *
 * 参考：Qwen Code synchronizedOutput.ts
 */
'use strict';

const BEGIN = '\x1b[?2026h';
const END   = '\x1b[?2026l';

let _enabled = null; // lazy detect

/**
 * Check if terminal likely supports Synchronized Output.
 * Conservative: only enable for known-good terminals.
 */
function isSupported() {
  if (_enabled !== null) return _enabled;

  // Non-TTY: no sync needed
  if (!process.stdout.isTTY) {
    _enabled = false;
    return false;
  }

  // Explicit override
  const envFlag = String(process.env.KHY_SYNC_OUTPUT || '').toLowerCase();
  if (envFlag === '0' || envFlag === 'false' || envFlag === 'off') {
    _enabled = false;
    return false;
  }
  if (envFlag === '1' || envFlag === 'true' || envFlag === 'on') {
    _enabled = true;
    return true;
  }

  // Auto-detect by TERM_PROGRAM / terminal signatures
  const term = String(process.env.TERM_PROGRAM || '').toLowerCase();
  const termExtra = String(process.env.TERMINAL_EMULATOR || '').toLowerCase();
  const wt = process.env.WT_SESSION; // Windows Terminal

  _enabled = (
    term.includes('wezterm') ||
    term.includes('iterm') ||
    term === 'kitty' ||
    term === 'foot' ||
    term === 'contour' ||
    termExtra.includes('jetbrains') ||
    !!wt
  );

  return _enabled;
}

/**
 * Write BEGIN sync frame marker.
 */
function beginSync() {
  if (isSupported()) {
    process.stdout.write(BEGIN);
  }
}

/**
 * Write END sync frame marker.
 */
function endSync() {
  if (isSupported()) {
    process.stdout.write(END);
  }
}

/**
 * Execute a function inside a synchronized frame.
 * All stdout writes within `fn` are buffered by the terminal
 * and flushed atomically on endSync().
 *
 * @param {Function} fn — sync function containing stdout writes
 */
function syncWrite(fn) {
  beginSync();
  try {
    fn();
  } finally {
    endSync();
  }
}

module.exports = { isSupported, beginSync, endSync, syncWrite };
