/**
 * Command Registry — extensible, priority-based slash command system.
 *
 * Replaces the static SLASH_COMMANDS array with a dynamic registry that
 * supports registration from multiple sources (builtin, tools, plugins, MCP).
 *
 * Higher priority sources win on collision. Categories group commands
 * for display in the `/` menu.
 *
 * Falls back gracefully — router.js keeps _STATIC_SLASH_COMMANDS as safety net.
 */

// ── Priority levels (higher wins on collision) ────────────────────

const PRIORITY = {
  builtin: 100,
  tool: 80,
  plugin: 60,
  mcp: 40,
  user: 20,
};

// ── Category definitions ──────────────────────────────────────────

const CATEGORIES = {
  model:    'AI \u6a21\u578b',     // AI 模型
  data:     '\u6570\u636e\u7ba1\u7406', // 数据管理
  security: '\u5b89\u5168',       // 安全
  dev:      '\u5f00\u53d1\u5de5\u5177', // 开发工具
  workflow: '\u5de5\u4f5c\u6d41',   // 工作流
  system:   '\u7cfb\u7edf',       // 系统
};

// ── Registry state ────────────────────────────────────────────────

const _commands = new Map(); // cmd → { cmd, label, desc, route, flag, category, priority, source }
let _categoryCache = null;   // invalidated on mutation

const { getStaticSlashCommands } = require('./commandSchema');

// ── Category assignment for builtin commands ─────────────────────

const _builtinCategories = {
  '/model': 'model', '/models': 'model', '/gateway': 'model', '/apikey': 'model',
  '/max': 'model', '/high': 'model', '/medium': 'model', '/low': 'model',

  '/cost': 'data', '/history': 'data', '/prompt': 'data',
  '/knowledge': 'data', '/growth': 'data',

  '/permissions': 'security', '/security': 'security', '/scan': 'security',
  '/login': 'security', '/logout': 'security', '/whoami': 'security',

  '/review': 'dev', '/doctor': 'dev', '/hardware': 'dev',
  '/clipboard': 'dev', '/websearch': 'dev', '/image': 'dev', '/paste': 'dev', '/image2web': 'dev',
  '/publish': 'dev',

  '/agent': 'workflow', '/skill': 'workflow', '/plan': 'workflow',
  '/ulw-loop': 'workflow', '/cron': 'workflow',
  '/profile': 'workflow', '/habit': 'workflow', '/resume': 'workflow',
  '/memory': 'workflow', '/proxy': 'workflow', '/subscribe': 'workflow',

  '/linux': 'system', '/skin': 'system',
  '/help': 'system', '/clear': 'system', '/exit': 'system',
  '/update': 'system', '/cleanup': 'system',
};

// ── Public API ────────────────────────────────────────────────────

/**
 * Register a single command definition.
 * Lower priority sources do NOT overwrite higher priority ones.
 *
 * @param {object} cmdDef - { cmd, label, desc, route?, flag?, category? }
 * @param {string} [source='user'] - Source identifier (builtin|tool|plugin|mcp|user)
 */
function register(cmdDef, source = 'user') {
  if (!cmdDef || !cmdDef.cmd) return;
  const priority = PRIORITY[source] ?? PRIORITY.user;

  const existing = _commands.get(cmdDef.cmd);
  if (existing && existing.priority > priority) return; // higher priority already registered

  _commands.set(cmdDef.cmd, {
    cmd: cmdDef.cmd,
    label: cmdDef.label || cmdDef.cmd.slice(1),
    desc: cmdDef.desc || '',
    route: cmdDef.route || null,
    flag: cmdDef.flag || null,
    category: cmdDef.category || _builtinCategories[cmdDef.cmd] || 'system',
    priority,
    source,
    // Plugin SDK fields (preserved for dispatch)
    _pluginHandler: cmdDef._pluginHandler || null,
    _pluginNamespace: cmdDef._pluginNamespace || null,
    _aliases: cmdDef._aliases || null,
    _completer: cmdDef._completer || null,
  });
  _categoryCache = null;
}

/**
 * Bulk-register commands from a single source.
 *
 * @param {Array} commands - Array of command definitions
 * @param {string} [source='builtin'] - Source identifier
 */
function registerBulk(commands, source = 'builtin') {
  if (!Array.isArray(commands)) return;
  for (const cmd of commands) {
    register(cmd, source);
  }
}

/**
 * Get all commands sorted by category then priority.
 * @returns {Array}
 */
function getAll() {
  const arr = [..._commands.values()];
  arr.sort((a, b) => {
    const catOrder = Object.keys(CATEGORIES);
    const catA = catOrder.indexOf(a.category);
    const catB = catOrder.indexOf(b.category);
    if (catA !== catB) return (catA === -1 ? 999 : catA) - (catB === -1 ? 999 : catB);
    return b.priority - a.priority;
  });
  return arr;
}

/**
 * Get commands grouped by category.
 * @returns {object} { model: [...], data: [...], ... }
 */
function getByCategory() {
  if (_categoryCache) return _categoryCache;

  const grouped = {};
  for (const cat of Object.keys(CATEGORIES)) {
    grouped[cat] = [];
  }

  for (const cmd of _commands.values()) {
    const cat = cmd.category;
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(cmd);
  }

  // Sort each group by priority desc
  for (const cat of Object.keys(grouped)) {
    grouped[cat].sort((a, b) => b.priority - a.priority);
  }

  // Remove empty categories
  for (const cat of Object.keys(grouped)) {
    if (grouped[cat].length === 0) delete grouped[cat];
  }

  _categoryCache = grouped;
  return grouped;
}

/**
 * Tab-completion: return commands matching a partial prefix.
 * @param {string} partial - e.g. '/mo'
 * @returns {string[]} - e.g. ['/model', '/models']
 */
function getCompletions(partial) {
  if (!partial) return [];
  const lower = partial.toLowerCase();
  const matches = [];
  for (const cmd of _commands.keys()) {
    if (cmd.toLowerCase().startsWith(lower)) {
      matches.push(cmd);
    }
  }
  return matches.sort();
}

/**
 * Unregister a command by name.
 * @param {string} cmd
 */
function unregister(cmd) {
  _commands.delete(cmd);
  _categoryCache = null;
}

/**
 * Convert to the legacy SLASH_COMMANDS array format for backward compatibility.
 * @returns {Array<{cmd, label, desc, route, flag}>}
 */
function toSlashCommands() {
  return getAll().map(({ cmd, label, desc, route, flag }) => ({ cmd, label, desc, route, flag }));
}

/**
 * Clear internal caches (call when tools/plugins change).
 */
function clearCache() {
  _categoryCache = null;
}

/**
 * Get the total number of registered commands.
 * @returns {number}
 */
function count() {
  return _commands.size;
}

function _seedBuiltins() {
  registerBulk(getStaticSlashCommands(), 'builtin');
}

// Lazy initialization flag
let _seeded = false;
function _ensureSeeded() {
  if (_seeded) return;
  _seeded = true;
  _seedBuiltins();
}

// Wrap public methods with lazy seeding
const _wrapped = {};
for (const fn of [getAll, getByCategory, getCompletions, toSlashCommands, count]) {
  _wrapped[fn.name] = function (...args) {
    _ensureSeeded();
    return fn(...args);
  };
}

// ── Exports ───────────────────────────────────────────────────────

module.exports = {
  register,
  registerBulk,
  getAll: _wrapped.getAll,
  getByCategory: _wrapped.getByCategory,
  getCompletions: _wrapped.getCompletions,
  toSlashCommands: _wrapped.toSlashCommands,
  count: _wrapped.count,
  unregister,
  clearCache,
  PRIORITY,
  CATEGORIES,
};
