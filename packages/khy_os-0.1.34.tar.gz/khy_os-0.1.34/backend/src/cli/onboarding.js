'use strict';

/**
 * G8 — 首次引导流程 (Onboarding Wizard)
 *
 * 从 DeepSeek-TUI app.rs OnboardingState 状态机学习：
 * Welcome → Language → ApiKey → TrustDirectory → Tips → Done
 *
 * 特点：
 * - 状态机驱动，可中断后从上次状态恢复
 * - 每个步骤独立验证
 * - 完成后标记 flag，后续启动跳过
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const ONBOARDING_FLAG = path.join(os.homedir(), '.khyquant', '.onboarding-done');

/**
 * 引导步骤枚举
 */
const OnboardingStep = {
  WELCOME: 'welcome',
  API_KEY: 'api_key',
  TRUST_DIR: 'trust_dir',
  TIPS: 'tips',
  DONE: 'done',
};

/**
 * 步骤顺序
 */
const STEP_ORDER = [
  OnboardingStep.WELCOME,
  OnboardingStep.API_KEY,
  OnboardingStep.TRUST_DIR,
  OnboardingStep.TIPS,
  OnboardingStep.DONE,
];

/**
 * 检查是否需要引导
 */
function needsOnboarding() {
  try {
    return !fs.existsSync(ONBOARDING_FLAG);
  } catch {
    return true;
  }
}

/**
 * 标记引导完成
 */
function markOnboardingDone() {
  try {
    const dir = path.dirname(ONBOARDING_FLAG);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(ONBOARDING_FLAG, JSON.stringify({
      completedAt: new Date().toISOString(),
      version: '1.0.0',
    }));
  } catch { /* best-effort */ }
}

/**
 * 判定初始步骤 — 根据已有配置跳过已完成的步骤
 */
function determineInitialStep(opts = {}) {
  // 如果已完成引导
  if (!needsOnboarding()) return OnboardingStep.DONE;

  // 已有 API Key → 跳过 api_key 步骤
  if (opts.hasApiKey) {
    // 已有信任目录 → 跳到 tips
    if (opts.hasTrustDir) return OnboardingStep.TIPS;
    return OnboardingStep.TRUST_DIR;
  }

  return OnboardingStep.WELCOME;
}

/**
 * 获取下一步骤
 */
function nextStep(current) {
  const idx = STEP_ORDER.indexOf(current);
  if (idx < 0 || idx >= STEP_ORDER.length - 1) return OnboardingStep.DONE;
  return STEP_ORDER[idx + 1];
}

/**
 * 获取步骤提示文案
 */
function getStepPrompt(step) {
  switch (step) {
    case OnboardingStep.WELCOME:
      return {
        title: '欢迎使用 KHY OS',
        message: '让我们用 30 秒完成初始配置。',
        action: '按 Enter 继续...',
      };
    case OnboardingStep.API_KEY:
      return {
        title: 'API 密钥配置',
        message: '请输入你的 AI 服务 API Key（支持 OpenAI、Anthropic、本地模型等）。\n如需稍后配置，直接按 Enter 跳过。',
        action: 'API Key: ',
      };
    case OnboardingStep.TRUST_DIR:
      return {
        title: '信任目录设置',
        message: `当前工作目录: ${process.cwd()}\n是否信任此目录？信任后 AI 可以在此目录读写文件。`,
        action: '输入 y 信任 / n 跳过: ',
      };
    case OnboardingStep.TIPS:
      return {
        title: '快速提示',
        message: [
          '• 输入自然语言提问，AI 会帮你编码、调试、搜索',
          '• /help 查看所有命令',
          '• /theme 切换主题',
          '• Ctrl+C 中断当前操作',
          '• 使用 @file.js 引用文件',
        ].join('\n'),
        action: '按 Enter 开始使用...',
      };
    case OnboardingStep.DONE:
      return { title: '', message: '', action: '' };
    default:
      return { title: '', message: '', action: '' };
  }
}

/**
 * OnboardingWizard 状态机
 */
class OnboardingWizard {
  constructor(opts = {}) {
    this.state = determineInitialStep(opts);
    this.results = {};
  }

  /**
   * 当前步骤
   */
  get currentStep() {
    return this.state;
  }

  /**
   * 是否已完成
   */
  isDone() {
    return this.state === OnboardingStep.DONE;
  }

  /**
   * 处理当前步骤的输入并推进到下一步
   * @param {string} input — 用户输入
   * @returns {{ step: string, prompt: object }|null} — 下一步的信息，null 表示完成
   */
  advance(input) {
    switch (this.state) {
      case OnboardingStep.WELCOME:
        this.state = nextStep(this.state);
        break;
      case OnboardingStep.API_KEY:
        if (input && input.trim()) {
          this.results.apiKey = input.trim();
        }
        this.state = nextStep(this.state);
        break;
      case OnboardingStep.TRUST_DIR:
        if (input && input.trim().toLowerCase() === 'y') {
          this.results.trustDir = process.cwd();
        }
        this.state = nextStep(this.state);
        break;
      case OnboardingStep.TIPS:
        this.state = OnboardingStep.DONE;
        markOnboardingDone();
        break;
      default:
        this.state = OnboardingStep.DONE;
    }

    if (this.isDone()) return null;

    return {
      step: this.state,
      prompt: getStepPrompt(this.state),
    };
  }

  /**
   * 获取当前步骤提示
   */
  getPrompt() {
    return getStepPrompt(this.state);
  }

  /**
   * 跳过引导直接完成
   */
  skip() {
    this.state = OnboardingStep.DONE;
    markOnboardingDone();
  }
}

module.exports = {
  OnboardingWizard,
  OnboardingStep,
  needsOnboarding,
  markOnboardingDone,
  determineInitialStep,
  nextStep,
  getStepPrompt,
  ONBOARDING_FLAG,
};
