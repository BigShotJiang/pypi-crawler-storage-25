/**
 * CLI Command Router — parses user input, resolves aliases & symbols,
 * dispatches to handlers or user plugins.
 *
 * All heavy modules are lazy-loaded for fast cold start.
 */
const path = require('path');
const { createRouterHandlers } = require('./routerHandlers');
const {
  getRouterCommandNames,
  getRouterSubCommands,
  getStaticSlashCommands,
} = require('./commandSchema');

// ── Levenshtein 编辑距离（G1 拼写纠错） ──
function _levenshtein(a, b) {
  const m = a.length, n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const curr = [i];
    for (let j = 1; j <= n; j++) {
      curr[j] = a[i - 1] === b[j - 1]
        ? prev[j - 1]
        : 1 + Math.min(prev[j - 1], prev[j], curr[j - 1]);
    }
    prev = curr;
  }
  return prev[n];
}

/**
 * 在已注册命令中查找与 input 编辑距离 ≤ maxDist 的最佳候选。
 * 同时搜索主命令和「主命令 子命令」组合。
 * @returns {Array<{label: string, dist: number}>} 最多 3 个，按距离升序
 */
function _findClosestCommands(input, maxDist = 2) {
  const lower = input.toLowerCase().replace(/^\//, '');
  const candidates = [];

  // 1) 主命令
  const allKeys = [...COMMANDS, ...aliases().getAllAliasKeys()];
  for (const key of new Set(allKeys)) {
    const k = key.toLowerCase().replace(/^\//, '');
    const d = _levenshtein(lower, k);
    if (d > 0 && d <= maxDist) candidates.push({ label: key, dist: d });
  }

  // 2) 「主命令 子命令」组合（仅在输入含空格或主命令无匹配时）
  const parts = lower.split(/\s+/);
  if (parts.length >= 2) {
    const cmdPart = parts[0];
    const subPart = parts.slice(1).join(' ');
    for (const [cmd, subs] of Object.entries(SUB_COMMANDS)) {
      const cmdDist = _levenshtein(cmdPart, cmd);
      if (cmdDist > maxDist) continue;
      for (const sub of subs) {
        const subDist = _levenshtein(subPart, sub);
        const total = cmdDist + subDist;
        if (total > 0 && total <= maxDist + 1) {
          candidates.push({ label: `${cmd} ${sub}`, dist: total });
        }
      }
    }
  }

  // 去重 + 排序 + 取前 3
  const seen = new Set();
  return candidates
    .sort((a, b) => a.dist - b.dist)
    .filter(c => { if (seen.has(c.label)) return false; seen.add(c.label); return true; })
    .slice(0, 3);
}

// ── Lazy module loaders ──
let _fmt, _chalk, _aliases, _symbolResolver, _plugins;
const fmt = () => (_fmt ??= require('./formatters'));
const chk = () => {
  if (_chalk) return _chalk;
  const chalkModule = require('chalk');
  _chalk = chalkModule.default || chalkModule;
  return _chalk;
};
const aliases = () => (_aliases ??= require('./aliases'));
const symResolver = () => (_symbolResolver ??= require('./symbolResolver'));
const plugins = () => (_plugins ??= require('./plugins'));
const {
  handleAccountInfo,
  handleLogCommand,
  handlePositionInfo,
  resolveArg0,
} = createRouterHandlers({ fmt, chk, symResolver });

// Canonical command list + sub-command map come from commandSchema (SSOT).
const COMMANDS = getRouterCommandNames();
const SUB_COMMANDS = getRouterSubCommands();

// In khyquant app-entry mode, system-level diagnostic/ops commands should be
// executed via `khy ...` instead of `khyquant ...`.
const KHY_ONLY_COMMANDS_IN_APP_MODE = new Set([
  'gateway', 'doctor', 'proxy', 'linux', 'shell', 'verify', 'security', 'monitor', 'services',
  'init', 'docs', 'profile', 'cloud', 'update', 'plugin', 'app', 'workspace',
  'publish',
  'model', 'models', 'khymodel', 'bridge', 'mcp',
  'config', 'context', 'diff', 'env', 'export', 'files', 'hooks',
  'session', 'share', 'stats', 'status', 'summary', 'tasks', 'theme',
  'upgrade', 'branch', 'debug', 'stickers',
]);

function _isKhyquantAppOnlyMode(context = {}) {
  const enforce = String(process.env.KHYQUANT_APP_ONLY || 'true').toLowerCase() !== 'false';
  if (!enforce) return false;
  const mode = String(context.mode || process.env.KHY_RUNTIME_MODE || '').toLowerCase();
  const invokedAs = String(process.env.KHYQUANT_INVOKED_AS || '').toLowerCase();
  return mode === 'khyquant' || invokedAs === 'khyquant';
}

function _isNumericConversationIndex(raw = '') {
  const token = String(raw || '').trim();
  return /^\d+$/.test(token);
}

function _resolveConversationTarget(aiModule, rawArg = '') {
  const convos = aiModule.listConversations();
  if (convos.length === 0) {
    return { convos, target: null, error: 'EMPTY' };
  }

  const token = String(rawArg || '').trim();
  if (!token) {
    return { convos, target: convos[0], error: null };
  }

  if (_isNumericConversationIndex(token)) {
    const idx = parseInt(token, 10) - 1;
    const target = convos[idx] || null;
    return { convos, target, error: target ? null : 'INVALID_INDEX' };
  }

  if (typeof aiModule.findConversationByRef === 'function') {
    const target = aiModule.findConversationByRef(token);
    return { convos, target, error: target ? null : 'INVALID_ID' };
  }

  const fallback = convos.find(c => c.file === token || c.file === `${token}.json`) || null;
  return { convos, target: fallback, error: fallback ? null : 'INVALID_ID' };
}

/**
 * Parse raw input into { command, subCommand, args, options }.
 * Resolves aliases before returning.
 */
function parseInput(line) {
  let parts = line.trim().split(/\s+/);
  if (/^khy(?:quant)?$/i.test(parts[0]) && parts.length > 1) {
    parts.shift();
  }
  if (parts.length === 0 || parts[0] === '') return null;

  const rawCommandToken = parts[0];
  if (parts[0].startsWith('/')) {
    const slashToken = parts[0].toLowerCase();
    let slashRoute = null;

    try {
      const cmdReg = require('./commandRegistry');
      const slashDef = cmdReg.toSlashCommands().find(sc => (
        sc && typeof sc.cmd === 'string' && sc.cmd.toLowerCase() === slashToken
      ));
      if (slashDef && slashDef.route) slashRoute = String(slashDef.route);
    } catch {
      // Fallback to static slash table when dynamic registry is unavailable.
      const slashDef = (SLASH_COMMANDS || []).find(sc => (
        sc && typeof sc.cmd === 'string' && sc.cmd.toLowerCase() === slashToken
      ));
      if (slashDef && slashDef.route) slashRoute = String(slashDef.route);
    }

    parts[0] = parts[0].slice(1);
    if (!parts[0]) return null;

    // Direct slash input should behave like selecting the same item from '/'.
    // Expand route-based slash commands (e.g. /model -> gateway model).
    if (slashRoute) {
      const routeParts = slashRoute.trim().split(/\s+/).filter(Boolean);
      if (routeParts.length > 0) {
        parts = [...routeParts, ...parts.slice(1)];
      }
    }
  }

  // Chinese input often omits spaces (e.g. "回测茅台", "行情sh600519").
  // Try splitting on known Chinese alias prefixes so they route correctly.
  // Only split for commands that actually accept Chinese positional arguments
  // (stock names, search keywords). Commands like "启动" (server start) or
  // "退出" (exit) don't take Chinese args, so "启动项目" should not be split
  // into "启动" + "项目" → server start.
  const ACCEPTS_ZH_ARG = new Set([
    'quote', 'backtest', 'data', 'search', 'analyze', 'watch', 'rank', 'order',
  ]);
  if (parts.length === 1 && !aliases().resolveAlias(parts[0])) {
    const token = parts[0];
    const { ALIAS_MAP } = aliases();
    const zhKeys = Object.keys(ALIAS_MAP).filter(k => /[\u4e00-\u9fff]/.test(k));
    // Sort longest first to match "回测" before single-char aliases
    zhKeys.sort((a, b) => b.length - a.length);
    for (const key of zhKeys) {
      if (token.startsWith(key) && token.length > key.length) {
        const remainder = token.slice(key.length);
        const aliasTarget = ALIAS_MAP[key];
        // English/pinyin/number remainder is always a valid arg (e.g. "回测sh600519")
        if (/^[a-zA-Z0-9]/.test(remainder)) {
          parts = [key, remainder];
          break;
        }
        // Chinese remainder is only valid for commands that accept Chinese args
        // (stock names like "茅台", search terms). Other commands ("启动项目",
        // "服务状态") should fall through to AI as natural language.
        if (aliasTarget && ACCEPTS_ZH_ARG.has(aliasTarget.command)
            && /^[\u4e00-\u9fff]+$/.test(remainder) && remainder.length <= 4) {
          parts = [key, remainder];
          break;
        }
      }
    }
  }

  let command = parts[0];
  const rest = parts.slice(1);

  // Parse options (--key value) and positional args
  const args = [];
  const options = {};
  for (let i = 0; i < rest.length; i++) {
    if (rest[i] === '--') {
      args.push(...rest.slice(i + 1));
      break;
    }
    if (rest[i].startsWith('--')) {
      const key = rest[i].slice(2);
      const nextVal = rest[i + 1];
      if (nextVal && !nextVal.startsWith('--')) {
        options[key] = nextVal;
        i++;
      } else {
        options[key] = true;
      }
    } else {
      args.push(rest[i]);
    }
  }

  // Resolve alias → canonical command
  const alias = aliases().resolveAlias(command);
  if (alias) {
    command = alias.command;
    // If alias implies a sub-command, prepend it
    if (alias.subCommand) {
      args.unshift(alias.subCommand);
    }
    // Inject default positional arguments for shortcut aliases
    // (e.g. "nir" -> "pool import nirvana").
    if (Array.isArray(alias.defaultPositionals) && alias.defaultPositionals.length > 0) {
      const defaults = alias.defaultPositionals
        .map(v => String(v || '').trim())
        .filter(Boolean);
      if (defaults.length > 0) {
        if (alias.subCommand && args.length > 0) {
          args.splice(1, 0, ...defaults);
        } else {
          args.unshift(...defaults);
        }
      }
    }
    // Merge default args from alias (e.g. buy → order --side buy)
    if (alias.defaultArgs) {
      Object.assign(options, alias.defaultArgs);
    }
  } else {
    command = command.toLowerCase();
  }

  // Detect sub-command
  let subCommand = null;
  if (SUB_COMMANDS[command] && args.length > 0 && SUB_COMMANDS[command].includes(args[0])) {
    subCommand = args.shift();
  }

  return {
    command,
    subCommand,
    args,
    options,
    rawInput: line.trim(),
    rawCommandToken,
  };
}

/**
 * Route parsed input to the appropriate handler.
 * Returns: true (handled), false (→ AI), 'exit', 'menu', 'ai-status', 'ai-config'
 */
async function route(parsed, context = {}) {
  const { command, subCommand, args, options } = parsed;
  const rawCommandToken = String(parsed?.rawCommandToken || '').trim().toLowerCase();
  const { printError, printHelp, printInfo, printTable, printSuccess, printWarn, withSpinner } = fmt();
  const chalk = chk();

  if (_isKhyquantAppOnlyMode(context) && KHY_ONLY_COMMANDS_IN_APP_MODE.has(command)) {
    const cmdTail = [command, subCommand, ...(args || [])].filter(Boolean).join(' ');
    printWarn('`khyquant` 仅用于启动量化应用。');
    printInfo(`请使用: khy ${cmdTail}`.trim());
    return true;
  }

  try {
    switch (command) {
      // ── Meta ──
      case 'version':
        console.log(process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version);
        return true;

      case 'resume': {
        // Shortcut for history resume [index|sessionId]
        const _ai = require('./ai');
        const _resolved = _resolveConversationTarget(_ai, args[0]);
        const _target = _resolved.target;
        if (!_target) {
          if (_resolved.error === 'EMPTY') {
            fmt().printInfo('暂无保存的对话记录');
          } else if (_resolved.error === 'INVALID_ID') {
            fmt().printError('无效会话 ID，请先运行 history list 查看');
          } else {
            fmt().printError('无效序号，请先运行 history list 查看');
          }
        } else {
          const _result = _ai.resumeConversation(_target.file);
          if (_result.success) {
            const compactNote = _result.compacted
              ? `，已压缩摘要 (${_result.originalCount} → ${_result.messageCount} 条)`
              : '';
            const sid = _target.sessionId ? ` · 会话ID ${_target.sessionId}` : '';
            fmt().printSuccess(`已恢复对话 (${new Date(_result.timestamp).toLocaleString('zh-CN')}${compactNote}${sid})`);
            fmt().printInfo('AI 已加载上次对话的关键上下文，可以继续提问');
          } else {
            fmt().printError('恢复失败');
          }
        }
        return true;
      }
      case 'help':
        if (args[0]) {
          const { printHelpTopic } = require('./formatters');
          printHelpTopic(args[0]);
        } else {
          printHelp();
        }
        return true;
      case 'clear':
        // REPL mode handles clear in a terminal-safe way (frame/hud reset).
        // Keep direct clear for non-REPL invocations.
        if (process.env.KHY_REPL_ACTIVE !== '1') {
          console.clear();
        }
        return true;
      case 'exit':
      case 'quit':
        return 'exit';
      case 'menu':
        return 'menu';

      // ── Quote ──
      case 'quote': {
        if (!args[0]) { printError('用法: quote <代码|名称>  (如: hq 茅台, quote sh600519)'); return true; }
        const sym = await resolveArg0(args);
        const { handleQuote } = require('./handlers/data');
        await handleQuote(sym);
        return true;
      }

      // ── Data ──
      case 'data': {
        const { handleDataFetch, handleDataList } = require('./handlers/data');
        if (subCommand === 'fetch') {
          if (!args[0]) { printError('用法: data fetch <代码|名称>'); return true; }
          const sym = await resolveArg0(args);
          await handleDataFetch(sym, options);
        } else if (subCommand === 'list') {
          await handleDataList();
        } else {
          printError('用法: data fetch <代码> | data list  (别名: xz, sj)');
        }
        return true;
      }

      case 'cache': {
        const { handleCacheClear } = require('./handlers/data');
        if (subCommand === 'clear') {
          await handleCacheClear();
        } else {
          printError('用法: cache clear  (别名: hc)');
        }
        return true;
      }

      // ── Backtest ──
      case 'backtest': {
        if (subCommand === 'list') {
          const { handleBacktestList } = require('./handlers/backtest');
          await handleBacktestList(options);
        } else {
          const rawSym = args[0] || subCommand;
          if (!rawSym) { printError('用法: backtest <代码|名称> [--strategy <ma_cross|rsi|macd|ID|文件> --start --end --capital --verbose]'); return true; }
          args[0] = rawSym;
          const sym = await resolveArg0(args);
          const { handleBacktestRun } = require('./handlers/backtest');
          await handleBacktestRun(sym, options);
        }
        return true;
      }

      case 'strategy': {
        if (subCommand === 'list' || !subCommand) {
          const { handleStrategyList } = require('./handlers/backtest');
          await handleStrategyList();
        } else {
          printError('用法: strategy list  (别名: cl)');
        }
        return true;
      }

      // ── Search ──
      case 'search': {
        // Web search sub-command: search web <query>
        if (subCommand === 'web' || args[0] === 'web' || args[0] === '网页') {
          const webArgs = (subCommand === 'web') ? args : args.slice(1);
          const webQuery = webArgs.join(' ');
          if (!webQuery) { printError('用法: search web <关键词>'); return true; }
          const webSearch = require('../services/webSearchService');
          if (!webSearch.isAvailable()) printInfo('未检测到 Kiro 认证，自动使用回退搜索');
          printInfo(`正在搜索: ${webQuery}`);
          const result = await webSearch.search(webQuery);
          if (result.success) {
            console.log('');
            console.log(chalk.bold.cyan('  🔍 搜索结果'));
            console.log(chalk.dim('  ─'.repeat(30)));
            for (const r of (result.results || []).slice(0, 10)) {
              console.log('');
              console.log(chalk.bold.white(`  ${r.title}`));
              if (r.url) console.log(chalk.blue(`  ${r.url}`));
              if (r.snippet) console.log(chalk.gray(`  ${r.snippet}`));
              if (r.publishedDate) console.log(chalk.dim(`  📅 ${r.publishedDate}`));
            }
            console.log('');
          } else {
            printError(result.error || '搜索失败');
          }
          return true;
        }
        if (!args[0]) { printError('用法: search <关键词>  (别名: ss, sousuo)'); return true; }
        const results = await symResolver().searchInstruments(args[0]);
        if (results.length === 0) {
          printError(`未找到匹配 "${args[0]}" 的品种`);
        } else {
          printSuccess(`找到 ${results.length} 个匹配`);
          printTable(
            ['代码', '名称', '类型', '市场'],
            results.slice(0, 20).map(i => [i.symbol, i.name || '-', i.type || '-', i.market || '-'])
          );
        }
        return true;
      }

      // ── Web Search (via Kiro InvokeMCP) ──
      case 'web_search': {
        const webQuery = args.join(' ');
        if (!webQuery) { printError('用法: web_search <关键词>'); return true; }
        const webSearch = require('../services/webSearchService');
        if (!webSearch.isAvailable()) printInfo('未检测到 Kiro 认证，自动使用回退搜索');
        const wsResult = await webSearch.search(webQuery);
        if (wsResult.success && wsResult.formatted) {
          console.log(wsResult.formatted);
        } else {
          printError(wsResult.error || '搜索失败');
        }
        return true;
      }

      // ── Screenshot to Web (image -> runnable HTML) ──
      case 'image2web': {
        const imageToWebService = require('../services/imageToWebService');
        const inputArg = String(args[0] || '').trim();
        const fromClipboard = Boolean(
          options.clipboard
          || options.paste
          || imageToWebService.isClipboardImageArg(inputArg)
        );
        if (!fromClipboard && !inputArg) {
          printError('用法: image2web <图片路径|paste> [还原要求] [--out index.html] [--overwrite]');
          printInfo('示例: image2web ./landing.png 还原这个网页为可运行 HTML --out landing.html');
          printInfo('示例: image2web paste 还原成响应式网页 --out clipboard-page.html');
          return true;
        }

        let sourcePath = '';
        let userPrompt = '';
        if (fromClipboard) {
          userPrompt = imageToWebService.isClipboardImageArg(inputArg)
            ? args.slice(1).join(' ').trim()
            : args.join(' ').trim();
        } else {
          sourcePath = inputArg;
          userPrompt = args.slice(1).join(' ').trim();
        }

        const noSave = Boolean(options.print || options.stdout || options['no-save']);
        const outRaw = String(options.out || options.output || '').trim();
        let convertResult = null;
        await withSpinner('正在还原网页代码', async () => {
          convertResult = await imageToWebService.convertImageToWeb({
            imagePath: sourcePath,
            useClipboard: fromClipboard,
            prompt: userPrompt,
            outputPath: outRaw,
            overwrite: Boolean(options.overwrite || options.force),
            save: !noSave,
            cwd: process.env.KHYQUANT_CWD || process.cwd(),
          });
        }, { muteOutput: false });

        if (!convertResult || !convertResult.success) {
          printError((convertResult && convertResult.error) || '网页还原失败');
          if (convertResult && convertResult.rawReply) {
            printWarn('AI 原始返回中未找到可用 HTML 代码块，已输出原文：');
            console.log('');
            console.log(convertResult.rawReply);
            console.log('');
          }
          return true;
        }
        if (noSave) {
          console.log(convertResult.html);
          return true;
        }

        if (convertResult.autoRenamed && convertResult.outputPath) {
          printWarn(`目标文件已存在，自动写入新文件: ${path.basename(convertResult.outputPath)}`);
        }
        printSuccess(`网页已生成: ${convertResult.outputPath}`);
        if (convertResult.provider || convertResult.model) {
          printInfo(`AI 通道: ${convertResult.provider || 'unknown'}${convertResult.model ? ` · ${convertResult.model}` : ''}`);
        }
        return true;
      }

      // ── Account / Position / Order (production placeholders) ──
      case 'account': {
        const service = require('./handlers/service');
        // Delegate to server API if running, otherwise show DB info
        await handleAccountInfo();
        return true;
      }

      case 'position': {
        await handlePositionInfo();
        return true;
      }

      case 'order': {
        printInfo('下单功能需要连接交易接口，当前为预览模式');
        printInfo('用法: order <代码> --side buy|sell --qty 100 --price 50.00');
        return true;
      }

      // ── Watch ──
      case 'watch': {
        if (!args[0]) { printError('用法: watch <代码|名称>  (别名: jk, jiankong)'); return true; }
        const sym = await resolveArg0(args);
        printInfo(`监控 ${sym} — 功能开发中，敬请期待`);
        return true;
      }

      // ── Rank ──
      case 'rank': {
        printInfo('排行功能开发中 — 将显示涨幅榜、跌幅榜、成交量榜');
        return true;
      }

      // ── Analyze (AI shortcut) ──
      case 'analyze': {
        if (!args[0]) { printError('用法: analyze <代码|名称>  (别名: fx, fenxi)'); return true; }
        const sym = await resolveArg0(args);
        // Forward to AI with a structured prompt
        return { aiForward: `分析一下 ${sym} 的走势和交易机会` };
      }

      // ── Server / DB / App ──
      case 'server': {
        const service = require('./handlers/service');
        if (subCommand === 'start') await service.handleServerStart(options);
        else if (subCommand === 'status') await service.handleServerStatus();
        else printError('用法: server start [--port N] | server status  (别名: fw)');
        return true;
      }

      case 'app': {
        const { handleApp } = require('./handlers/app');
        await handleApp(subCommand, args, options);
        return true;
      }

      case 'db': {
        const service = require('./handlers/service');
        if (subCommand === 'init') await service.handleDbInit();
        else if (subCommand === 'seed') await service.handleDbSeed();
        else if (subCommand === 'status') await service.handleDbStatus();
        else printError('用法: db init | db seed | db status  (别名: sjk)');
        return true;
      }

      // ── AI ──
      case 'ai': {
        if (subCommand === 'status') return 'ai-status';
        if (subCommand === 'config') return 'ai-config';
        if (subCommand === 'on') return 'ai-on';
        if (subCommand === 'off') return 'ai-off';
        if (subCommand === 'tech') {
          const aiHandler = require('./ai');
          await aiHandler.handleAiTech(options, args);
          return true;
        }
        if (subCommand === 'owner') {
          const aiHandler = require('./ai');
          await aiHandler.handleAiOwner(args[0] || 'status', options);
          return true;
        }
        if (subCommand === 'unrestricted') {
          const aiHandler = require('./ai');
          await aiHandler.handleAiUnrestricted(options, args);
          return true;
        }
        if (subCommand === 'dangerous') {
          const toolCalling = require('../services/toolCalling');
          if (options.off) {
            toolCalling.disableDangerousMode();
            printSuccess('危险模式已关闭 — 工具调用将请求确认');
          } else {
            const acknowledged = toolCalling.enableDangerousMode();
            if (!acknowledged) {
              printError('⚠⚠⚠ 警告: 危险模式将跳过所有工具调用确认!');
              printInfo('AI 将可以不经确认地执行文件操作、命令执行等危险操作');
              printInfo('这可能导致数据丢失或系统损坏');
              printInfo('如果确认开启，请运行: ai dangerous --confirm');
            } else {
              printSuccess('危险模式已开启 — 工具调用将不再请求确认');
              printWarn('请注意安全，随时可用 ai dangerous --off 关闭');
            }
          }
          if (options.confirm) {
            toolCalling.acknowledgeDangerousMode();
            printSuccess('已确认 — 危险模式开启');
          }
          return true;
        }
        if (subCommand === 'tools') {
          const toolCalling = require('../services/toolCalling');
          const tools = toolCalling.listTools();
          console.log('');
          printInfo(`已注册 ${tools.length} 个工具 (legacy):`);
          tools.forEach(t => {
            const riskColors = { safe: 'green', low: 'cyan', medium: 'yellow', high: 'red', critical: 'redBright' };
            const color = riskColors[t.risk] || 'dim';
            console.log(`    ${chalk[color](`[${t.risk}]`)} ${t.name} — ${t.description}`);
          });
          // Show new registry tools
          try {
            const registry = require('../tools');
            const newCount = registry.count();
            const grouped = registry.getByCategory();
            console.log('');
            printInfo(`工具注册表: ${newCount} 个工具 (按类别):`);
            for (const [cat, catTools] of Object.entries(grouped)) {
              console.log(chalk.bold(`    [${cat}]`));
              for (const t of catTools) {
                const riskColors = { safe: 'green', low: 'cyan', medium: 'yellow', high: 'red', critical: 'redBright' };
                const color = riskColors[t.risk] || 'dim';
                console.log(`      ${chalk[color](`[${t.risk}]`)} ${t.name} — ${t.description}`);
              }
            }
          } catch { /* registry not available */ }
          console.log('');
          return true;
        }
        return 'ai-status';
      }

      // ── Model (slash shortcut) ──
      case 'model': {
        const gw = require('./handlers/gateway');
        await gw.handleGatewaySelectModel(args, options);
        return true;
      }

      // ── Config (Hermes-style) ──
      case 'config': {
        const { handleConfig } = require('./handlers/config');
        await handleConfig(subCommand, args, options);
        return true;
      }

      // ── Claude Code aligned commands ──
      case 'upgrade': {
        return route({
          ...parsed,
          command: 'update',
          subCommand: null,
        }, context);
      }

      case 'compact': {
        const ai = require('./ai');
        const compactResult = typeof ai.compactConversation === 'function'
          ? ai.compactConversation({ mode: 'auto' })
          : null;
        if (!compactResult || compactResult.success === false) {
          printError('会话压缩失败');
          return true;
        }
        if (compactResult.changed === false) {
          printInfo(`无需压缩：当前消息 ${compactResult.previousCount}`);
          return true;
        }
        printSuccess(`会话已压缩：${compactResult.previousCount} -> ${compactResult.nextCount}`);
        return true;
      }

      case 'context': {
        const hud = require('./hudRenderer');
        const state = hud.getState();
        const used = Number(state?.contextWindow?.used || 0);
        const limit = Number(state?.contextWindow?.limit || 0);
        const pct = limit > 0 ? Math.round((used / limit) * 100) : 0;
        console.log(chalk.bold('\n  Context Window:'));
        console.log(`    Used: ${(used / 1000).toFixed(1)}k / ${(limit / 1000).toFixed(0)}k tokens (${pct}%)`);
        console.log(`    Session: ↑${((state?.sessionTokens?.input || 0) / 1000).toFixed(1)}k ↓${((state?.sessionTokens?.output || 0) / 1000).toFixed(1)}k`);
        console.log('');
        return true;
      }

      case 'diff': {
        try {
          const { execSync } = require('child_process');
          const { renderSideBySideDiff } = require('./ui/diffViewer');
          const diff = execSync('git diff', { encoding: 'utf-8', timeout: 5000 }).trim();
          if (!diff) {
            printInfo('没有未提交改动');
            return true;
          }
          renderSideBySideDiff(diff);
        } catch (err) {
          printError(`Diff 失败: ${err.message}`);
        }
        return true;
      }

      case 'effort': {
        const ai = require('./ai');
        if (!args[0]) {
          const current = typeof ai.getEffort === 'function' ? ai.getEffort() : 'unknown';
          printInfo(`当前精度: ${current}`);
          printInfo('用法: effort <low|medium|high|max>');
          return true;
        }
        const next = String(args[0]).toLowerCase();
        if (typeof ai.setEffort !== 'function' || !ai.setEffort(next)) {
          printError('无效精度，支持: low / medium / high / max');
          return true;
        }
        const presets = typeof ai.getEffortPresets === 'function' ? ai.getEffortPresets() : {};
        const preset = presets[next];
        if (preset) {
          printSuccess(`模型精度已切换: ${next} (${preset.label}) — temp=${preset.temperature}, maxTokens=${preset.maxTokens}`);
        } else {
          printSuccess(`模型精度已切换: ${next}`);
        }
        return true;
      }

      case 'env': {
        console.log(chalk.bold('\n  Environment:'));
        console.log(`    Platform: ${process.platform} ${process.arch}`);
        console.log(`    Node: ${process.version}`);
        console.log(`    CWD: ${process.cwd()}`);
        console.log(`    Shell: ${process.env.SHELL || 'N/A'}`);
        try {
          const { execSync } = require('child_process');
          const branch = execSync('git rev-parse --abbrev-ref HEAD', { encoding: 'utf-8', timeout: 2000 }).trim();
          console.log(`    Git branch: ${branch}`);
        } catch { /* non-git directory */ }
        console.log('');
        return true;
      }

      case 'export': {
        const fs = require('fs');
        const ai = require('./ai');
        const conversation = typeof ai.getConversation === 'function' ? ai.getConversation() : [];
        const outputPath = path.resolve(
          String(options.out || options.output || args[0] || `khy-session-${Date.now()}.json`)
        );
        fs.writeFileSync(outputPath, JSON.stringify(conversation, null, 2), 'utf-8');
        printSuccess(`会话已导出: ${outputPath}`);
        return true;
      }

      case 'fast': {
        printInfo('fast 模式是 REPL 会话级开关，请在交互模式运行 /fast');
        return true;
      }

      case 'files': {
        try {
          const { execSync } = require('child_process');
          const limitRaw = Number.parseInt(String(args[0] || '30'), 10);
          const limit = Number.isFinite(limitRaw) ? Math.max(1, Math.min(200, limitRaw)) : 30;
          const files = execSync('git ls-files', { encoding: 'utf-8', timeout: 5000 })
            .split(/\r?\n/)
            .map(line => line.trim())
            .filter(Boolean);
          printInfo(`仓库文件: ${files.length}`);
          files.slice(0, limit).forEach((file) => console.log(`    ${file}`));
          if (files.length > limit) {
            printInfo(`其余 ${files.length - limit} 个文件可用 "files ${Math.min(files.length, 200)}" 查看更多`);
          }
        } catch (err) {
          printError(`文件列表失败: ${err.message}`);
        }
        return true;
      }

      case 'hooks': {
        try {
          const hookSystem = require('./hooks/hookSystem');
          const registry = hookSystem.registry;
          const rows = [];
          for (const event of registry.events) {
            const hooks = registry.getHooks(event);
            if (hooks.length > 0) {
              rows.push([event, String(hooks.length)]);
            }
          }
          if (rows.length === 0) {
            printInfo('当前无已注册 Hooks');
            return true;
          }
          printTable(['Event', 'Count'], rows);
          printInfo(`总计: ${registry.count} hooks`);
        } catch (err) {
          printError(`Hooks 状态读取失败: ${err.message}`);
        }
        return true;
      }

      case 'mcp': {
        try {
          const mcp = require('../services/mcp');
          const config = typeof mcp.loadConfig === 'function' ? mcp.loadConfig(process.cwd()) : { mcpServers: {} };
          const servers = Object.keys((config && config.mcpServers) || {});
          const connected = typeof mcp.getConnectedServers === 'function' ? mcp.getConnectedServers() : [];
          printInfo(`MCP 配置服务器: ${servers.length}`);
          printInfo(`MCP 已连接: ${connected.length}`);
          if (servers.length > 0) {
            printTable(['Server', 'Configured', 'Connected'], servers.map((name) => [
              name,
              'yes',
              connected.includes(name) ? 'yes' : 'no',
            ]));
          }
          printInfo('提示: 高级管理请在 REPL 中使用 /mcp');
        } catch (err) {
          printError(`MCP 状态读取失败: ${err.message}`);
        }
        return true;
      }

      case 'share': {
        printInfo('share 功能暂未在 CLI 中开放');
        return true;
      }

      case 'stats': {
        const ai = require('./ai');
        const stats = typeof ai.getConversationStats === 'function' ? ai.getConversationStats() : null;
        if (!stats) {
          printError('会话统计不可用');
          return true;
        }
        printTable(
          ['Metric', 'Value'],
          [
            ['messages.total', String(stats.totalMessages || 0)],
            ['messages.user', String(stats.userMessages || 0)],
            ['messages.assistant', String(stats.assistantMessages || 0)],
            ['messages.tool', String(stats.toolMessages || 0)],
            ['effort', String(stats.effort || 'unknown')],
            ['studyMode', String(Boolean(stats.studyMode))],
          ]
        );
        return true;
      }

      case 'status': {
        try {
          const ai = require('./ai');
          const hud = require('./hudRenderer');
          hud.refreshGit();
          const state = hud.getState();
          const provider = typeof ai.getActiveProvider === 'function' ? ai.getActiveProvider() : 'unknown';
          console.log(chalk.bold('\n  Status:'));
          console.log(`    Provider: ${provider}`);
          if (state?.git?.branch) {
            console.log(`    Branch: ${state.git.branch}${state.git.dirty ? ` (${state.git.dirtyCount} changed)` : ''}`);
          }
          console.log(`    Context: ${Math.round((state?.contextWindow?.used || 0) / 1000)}k/${Math.round((state?.contextWindow?.limit || 0) / 1000)}k`);
          console.log(`    Requests: ${state?.requestCount || 0}`);
          console.log('');
        } catch (err) {
          printError(`状态读取失败: ${err.message}`);
        }
        return true;
      }

      case 'summary': {
        const ai = require('./ai');
        const stats = typeof ai.getConversationStats === 'function' ? ai.getConversationStats() : null;
        if (!stats) {
          printError('会话摘要不可用');
          return true;
        }
        printInfo(`会话摘要: 共 ${stats.totalMessages || 0} 条消息（用户 ${stats.userMessages || 0} / 助手 ${stats.assistantMessages || 0} / 工具 ${stats.toolMessages || 0}）`);
        return true;
      }

      case 'tasks': {
        const taskControlService = require('../services/taskControlService');
        const { runTasksControlContract } = require('./tasksControlContract');
        const argsText = args.join(' ').trim();
        const tokens = argsText ? argsText.split(/\s+/).filter(Boolean) : [];
        const primary = String(tokens[0] || '').trim().toLowerCase();
        const TASK_ACTION_ALIASES = {
          cancel: 'cancel',
          stop: 'cancel',
          kill: 'cancel',
          pause: 'pause',
          resume: 'resume',
          取消: 'cancel',
          暂停: 'pause',
          恢复: 'resume',
        };
        const TASK_FILTER_ALIASES = {
          all: 'all',
          a: 'all',
          pending: 'pending',
          queue: 'pending',
          queued: 'pending',
          running: 'running',
          run: 'running',
          active: 'running',
          paused: 'paused',
          pause: 'paused',
          completed: 'completed',
          done: 'completed',
          success: 'completed',
          failed: 'failed',
          fail: 'failed',
          error: 'failed',
          全部: 'all',
          待处理: 'pending',
          运行中: 'running',
          已暂停: 'paused',
          已完成: 'completed',
          失败: 'failed',
        };
        const taskStatusLabel = (status = '') => {
          const value = String(status || '').toLowerCase();
          const labels = {
            pending: '待处理',
            created: '待处理',
            queued: '待处理',
            claimed: '待处理',
            running: '执行中',
            retrying: '重试中',
            pausing: '暂停中',
            paused: '已暂停',
            succeeded: '已完成',
            success: '已完成',
            completed: '已完成',
            done: '已完成',
            failed: '失败',
            cancelled: '已取消',
            dead_letter: '失败终止',
            timeout: '超时',
          };
          return labels[value] || String(status || '未知');
        };
        const taskGroup = (status = '') => {
          const text = String(status || '').toLowerCase();
          if (['pending', 'queued', 'created', 'claimed'].includes(text)) return 'pending';
          if (['running', 'retrying', 'pausing'].includes(text)) return 'running';
          if (['paused'].includes(text)) return 'paused';
          if (['succeeded', 'success', 'completed', 'done'].includes(text)) return 'completed';
          if (['failed', 'cancelled', 'dead_letter', 'timeout'].includes(text)) return 'failed';
          return 'pending';
        };

        if (primary === '?' || primary === 'help' || primary === 'h' || primary === '帮助') {
          printInfo('用法: tasks');
          printInfo('      tasks all|pending|running|paused|completed|failed [limit]');
          printInfo('      tasks <taskId>');
          printInfo('      tasks cancel|pause|resume <taskId> [reason]');
          return true;
        }

        const control = runTasksControlContract(argsText, {
          taskControlService,
          actionAliases: TASK_ACTION_ALIASES,
          taskStatusLabel,
          defaultCancelReason: 'Cancelled by tasks command',
        });
        if (control.handled) {
          for (const event of control.events) {
            if (event.level === 'success') printSuccess(event.text);
            else if (event.level === 'info') printInfo(event.text);
            else printError(event.text);
          }
          return true;
        }

        const listedTasks = taskControlService.listTasks();
        const allTasks = Array.isArray(listedTasks) ? listedTasks : [];
        const summary = { total: allTasks.length, pending: 0, running: 0, paused: 0, completed: 0, failed: 0 };
        for (const task of allTasks) {
          summary[taskGroup(task && task.status)] += 1;
        }
        printInfo(
          `任务概览 total=${summary.total} pending=${summary.pending} running=${summary.running} paused=${summary.paused} completed=${summary.completed} failed=${summary.failed}`
        );

        const filter = primary ? (TASK_FILTER_ALIASES[primary] || null) : 'all';
        if (filter) {
          const filtered = filter === 'all'
            ? allTasks
            : allTasks.filter((item) => taskGroup(item.status) === filter);
          const rawLimit = Number.parseInt(String(tokens[1] || (filter === 'all' ? 12 : 20)), 10);
          const limit = Number.isFinite(rawLimit) ? Math.max(1, Math.min(100, rawLimit)) : (filter === 'all' ? 12 : 20);
          if (filtered.length === 0) {
            printInfo(`没有匹配任务（过滤器: ${filter}）`);
            return true;
          }
          const rows = filtered.slice(0, limit).map(task => [
            String(task.id || '-'),
            `${taskStatusLabel(task.status)} (${task.status || '-'})`,
            String(task.type || '-'),
            task.progress_pct === undefined ? '-' : `${Math.round(Number(task.progress_pct) || 0)}%`,
            `${Number.isFinite(Number(task.attempt_count)) ? Number(task.attempt_count) : 0}/${Number.isFinite(Number(task.max_attempts)) ? Number(task.max_attempts) : '-'}`,
            String(task.updated_at || task.created_at || '-').replace('T', ' ').slice(0, 19),
          ]);
          if (rows.length > 0) {
            printTable(['Task ID', '状态', '类型', '进度', '重试', 'Updated'], rows);
          }
          return true;
        }
        const taskId = String(tokens[0] || '').trim();
        if (!taskId) return true;

        const detail = taskControlService.getTaskDetail(taskId, { includeAudit: true });
        if (!detail.ok) {
          printError(detail.message || `任务不存在: ${taskId}`);
          return true;
        }
        const task = detail.task || {};
        printTable(
          ['Field', 'Value'],
          [
            ['id', String(task.id || '-')],
            ['status', String(task.status || '-')],
            ['type', String(task.type || '-')],
            ['progress', task.progress_pct === undefined ? '-' : `${task.progress_pct}%`],
            ['attempts', `${task.attempt_count || 0}/${task.max_attempts || '-'}`],
          ]
        );
        return true;
      }

      case 'theme': {
        if (args[0]) {
          return route({
            command: 'skin',
            subCommand: 'set',
            args,
            options,
            rawInput: parsed.rawInput,
            rawCommandToken: parsed.rawCommandToken,
          }, context);
        }
        return route({
          command: 'skin',
          subCommand: 'list',
          args: [],
          options: {},
          rawInput: 'skin list',
          rawCommandToken: 'skin',
        }, context);
      }

      case 'branch': {
        try {
          const { execSync } = require('child_process');
          const branches = execSync('git branch -a', { encoding: 'utf-8', timeout: 5000 }).trim();
          console.log(chalk.bold('\n  Git Branches:'));
          for (const row of branches.split(/\r?\n/).filter(Boolean)) {
            console.log(`    ${row.trim()}`);
          }
          console.log('');
        } catch (err) {
          printError(`分支读取失败: ${err.message}`);
        }
        return true;
      }

      case 'debug': {
        printInfo('debug 命令暂未提供独立子命令，请在 REPL 中使用 /debug');
        return true;
      }

      case 'stickers': {
        const stickers = ['(╯°□°)╯︵ ┻━┻', '┬─┬ノ( º _ ºノ)', '( •_•)>⌐■-■', '(⌐■_■)', '\\(^_^)/', '(>_<)', '(◕‿◕)'];
        console.log(`\n  ${stickers[Math.floor(Math.random() * stickers.length)]}\n`);
        return true;
      }

      // ── Gateway ──
      case 'gateway': {
        const gw = require('./handlers/gateway');
        const manageAliasForceDaemon = new Set([
          'guanli',
          'khyguanli',
          'aiguanli',
          'ai管理',
          '管理页',
        ]);
        const manageOptions = (
          subCommand === 'manage'
          && manageAliasForceDaemon.has(rawCommandToken)
          && typeof options.daemon === 'undefined'
        )
          ? { ...options, daemon: true }
          : options;
        if (subCommand === 'status') await gw.handleGatewayStatus(options);
        else if (subCommand === 'config') await gw.handleGatewayConfig();
        else if (subCommand === 'relay') await gw.handleGatewayRelay();
        else if (subCommand === 'detect') await gw.handleGatewayDetect();
        else if (subCommand === 'model') await gw.handleGatewaySelectModel(args, options);
        else if (subCommand === 'prefer-remote') await gw.handleGatewayPreferRemote();
        else if (subCommand === 'test') await gw.handleGatewayTest(args[0] || null);
        else if (subCommand === 'discover-models') await gw.handleGatewayDiscoverModels();
        else if (subCommand === 'tune-local') await gw.handleGatewayTuneLocal(args, options);
        else if (subCommand === 'server') await gw.handleAiServer(args[0] || 'start');
        else if (subCommand === 'manage') await gw.handleGatewayManage(args, manageOptions);
        else if (subCommand === 'protocols') gw.handleGatewayProtocols();
        else if (subCommand === 'oauth') await gw.handleGatewayOAuth(args[0] || 'status', args[1] || null);
        else if (subCommand === 'key') await gw.handleGatewayKey(args[0] || '', args.slice(1), options);
        else if (subCommand === 'add') await gw.handleGatewayAdd();
        else {
          // Default to status when no sub-command
          await gw.handleGatewayStatus(options);
        }
        return true;
      }

      // ── Init / Doctor ──
      case 'init': {
        const { handleInit } = require('./handlers/init');
        await handleInit(options);
        return true;
      }

      case 'doctor': {
        const { handleDoctor } = require('./handlers/init');
        await handleDoctor();
        return true;
      }

      case 'verify': {
        const { handleVerify } = require('./handlers/verify');
        await handleVerify(subCommand, args, options);
        return true;
      }

      case 'workspace': {
        const { handleWorkspace } = require('./handlers/workspace');
        await handleWorkspace(subCommand ? [subCommand, ...args] : args, options);
        return true;
      }

      case 'publish': {
        const { handlePublish } = require('./handlers/publish');
        await handlePublish(subCommand, args, options);
        return true;
      }

      case 'docs': {
        const docs = require('./handlers/docs');
        if (subCommand === 'quickstart' || subCommand === 'start') await docs.handleDocsQuickstart();
        else if (subCommand === 'ai-fastlane' || subCommand === 'ai' || subCommand === 'fastlane') await docs.handleDocsAiFastlane(args, options);
        else if (subCommand === 'claude') await docs.handleDocsClaude();
        else if (subCommand === 'gateway') await docs.handleDocsGateway();
        else if (subCommand === 'strategy') await docs.handleDocsStrategy();
        else if (subCommand === 'faq') await docs.handleDocsFaq();
        else if (subCommand === 'subscribe' || subCommand === 'sub') await docs.handleDocsSubscription();
        else await docs.handleDocsQuickstart(); // default to quickstart
        return true;
      }

      case 'subscribe':
      case 'sub': {
        const docs = require('./handlers/docs');
        await docs.handleDocsSubscription();
        return true;
      }

      case 'profile': {
        const userProfile = require('../services/userProfile');
        if (subCommand === 'export') {
          const json = userProfile.exportProfile();
          const outPath = args[0] || 'khy-profile.json';
          require('fs').writeFileSync(outPath, json, 'utf-8');
          printSuccess(`画像已导出到: ${outPath}`);
        } else if (subCommand === 'import') {
          const filePath = args[0];
          if (!filePath) { printError('用法: profile import <file.json>'); return true; }
          try {
            const json = require('fs').readFileSync(filePath, 'utf-8');
            userProfile.importProfile(json);
            printSuccess('画像已导入并合并');
          } catch (e) { printError(`导入失败: ${e.message}`); }
        } else if (subCommand === 'reset') {
          userProfile.resetProfile();
          printSuccess('画像已重置');
        } else {
          // Default: show profile summary
          const summary = userProfile.getProfileSummary();
          console.log('');
          console.log(chalk.cyan.bold('  📊 用户画像'));
          console.log(chalk.dim('  ' + '─'.repeat(40)));
          console.log(`  会话次数: ${chalk.bold(summary.sessions)}`);
          console.log(`  命令总数: ${chalk.bold(summary.totalCommands)}`);
          console.log(`  熟练度:   ${chalk.bold(summary.skillLevel === 'beginner' ? '新手' : summary.skillLevel === 'intermediate' ? '进阶' : '高级')}`);
          if (summary.topSymbols.length > 0)
            console.log(`  常用品种: ${chalk.green(summary.topSymbols.join(', '))}`);
          if (summary.topCommands.length > 0)
            console.log(`  常用命令: ${chalk.green(summary.topCommands.join(', '))}`);
          if (summary.favoriteSymbols.length > 0)
            console.log(`  收藏品种: ${chalk.yellow(summary.favoriteSymbols.join(', '))}`);
          console.log(chalk.dim(`  设备ID:   ${summary.deviceId}`));
          console.log('');
          printInfo('profile export — 导出画像 (跨设备同步)');
          printInfo('profile import <file> — 导入画像');
          console.log('');
        }
        return true;
      }

      case 'cloud': {
        const cloud = require('../services/cloudSync');
        if (subCommand === 'login') {
          const inquirer = require('inquirer');
          const { username, password } = await inquirer.prompt([
            { type: 'input', name: 'username', message: '用户名:', validate: v => v.trim().length >= 3 || '至少3个字符' },
            { type: 'password', name: 'password', message: '密码:', mask: '*', validate: v => v.length >= 6 || '至少6个字符' },
          ]);
          printInfo('登录中...');
          try {
            const result = await cloud.login(username, password);
            if (result.success) printSuccess(`${result.message} — 欢迎回来, ${username}!`);
            else printError(result.message);
          } catch (e) { printError(`网络错误: ${e.message}`); }
        } else if (subCommand === 'register') {
          const inquirer = require('inquirer');
          const { username, password, confirm } = await inquirer.prompt([
            { type: 'input', name: 'username', message: '设置用户名:', validate: v => v.trim().length >= 3 || '至少3个字符' },
            { type: 'password', name: 'password', message: '设置密码:', mask: '*', validate: v => v.length >= 6 || '至少6个字符' },
            { type: 'password', name: 'confirm', message: '确认密码:', mask: '*' },
          ]);
          if (password !== confirm) { printError('两次密码不一致'); return true; }
          printInfo('注册中...');
          try {
            const result = await cloud.register(username, password);
            if (result.success) printSuccess(`${result.message} — 已自动登录`);
            else printError(result.message);
          } catch (e) { printError(`网络错误: ${e.message}`); }
        } else if (subCommand === 'logout') {
          cloud.logout();
          printSuccess('已退出登录');
        } else if (subCommand === 'on' || subCommand === 'enable') {
          if (!cloud.isLoggedIn()) {
            printError('请先登录: cloud login');
            return true;
          }
          cloud.enableCloud();
          printSuccess('云同步已开启');
        } else if (subCommand === 'off' || subCommand === 'disable') {
          cloud.disableCloud();
          printSuccess('云同步已关闭');
        } else if (subCommand === 'sync') {
          if (!cloud.isLoggedIn()) { printError('请先登录: cloud login'); return true; }
          printInfo('正在同步...');
          const up = await cloud.syncUpload();
          if (up.success) printSuccess('画像已上传到云端');
          else printError(`上传失败: ${up.reason}`);
        } else if (subCommand === 'pull') {
          if (!cloud.isLoggedIn()) { printError('请先登录: cloud login'); return true; }
          printInfo('正在拉取...');
          const down = await cloud.syncDownload();
          if (down.success) printSuccess('已从云端合并画像');
          else printError(`拉取失败: ${down.reason}`);
        } else if (subCommand === 'endpoint') {
          if (args[0]) {
            cloud.setEndpoint(args[0]);
            printSuccess(`云端地址已设为: ${args[0]}`);
          } else {
            console.log(`  当前地址: ${chalk.cyan(cloud.getEndpoint())}`);
            printInfo('用法: cloud endpoint https://new-domain.com');
          }
        } else {
          // Show status
          const config = cloud.loadCloudConfig();
          console.log('');
          console.log(chalk.cyan.bold('  ☁️  云同步状态'));
          console.log(chalk.dim('  ' + '─'.repeat(40)));
          if (config.username) {
            console.log(`  账号:     ${chalk.green(config.username)} ✓`);
          } else {
            console.log(`  账号:     ${chalk.yellow('未登录')}`);
          }
          console.log(`  状态:     ${config.enabled ? chalk.green('已开启') : chalk.yellow('未开启')}`);
          console.log(`  统计上报: ${config.telemetryEnabled ? chalk.green('✓') : chalk.dim('✗')}`);
          console.log(`  画像同步: ${config.syncEnabled ? chalk.green('✓') : chalk.dim('✗')}`);
          console.log(`  端点:     ${chalk.dim(config.endpoint || 'https://api.khyquant.top')}`);
          if (config.lastSync) console.log(`  上次同步: ${chalk.dim(config.lastSync)}`);
          console.log('');
          if (!config.username) {
            printInfo('cloud register — 注册新账号');
            printInfo('cloud login — 登录已有账号');
          } else {
            printInfo('cloud sync — 上传画像 · cloud pull — 拉取画像');
            printInfo('cloud logout — 退出登录');
          }
          printInfo('cloud endpoint <url> — 修改服务器地址');
          console.log('');
        }
        return true;
      }

      // ── Plugin management ──
      case 'plugin': {
        const { getPluginList, reloadPlugins, PLUGINS_DIR } = require('./plugins');
        if (subCommand === 'list') {
          // SDK plugins (with quality status)
          const { handlePlugin } = require('./handlers/plugin-dev');
          await handlePlugin(['list', ...args]);

          // Legacy custom command plugins
          const list = getPluginList();
          if (list.length > 0) {
            printInfo(`自定义命令插件 (${list.length})`);
            printTable(
              ['命令', '别名', '说明'],
              list.map(p => [p.name, (p.aliases || []).join(', '), p.description || ''])
            );
          } else {
            printInfo(`暂无自定义命令插件，可在 ${PLUGINS_DIR}/ 添加 .js 文件`);
          }
        } else if (subCommand === 'reload') {
          reloadPlugins();
          printSuccess('插件已重新加载');
        } else if (subCommand === 'gateway') {
          const gwPlugins = require('../services/gateway/pluginChain');
          const action = args[0];
          if (action === 'list' || !action) {
            const plugins = gwPlugins.list();
            if (plugins.length === 0) {
              printInfo(`网关插件目录: ${gwPlugins.getPluginsDir()}/`);
              printInfo('暂无网关插件 — 创建 .js 文件即��加载');
            } else {
              printSuccess(`已加载 ${plugins.length} 个网关插件`);
              fmt().printTable(
                ['名称', '优先级', '状态', 'Hooks'],
                plugins.map(p => [p.name, String(p.priority), p.enabled ? chk().green('✓') : chk().dim('禁用'), p.hooks.join(', ')])
              );
            }
          } else if (action === 'reload') {
            const count = gwPlugins.reload();
            printSuccess(`网关插件已重载 (${count} 个)`);
          } else if (action === 'enable' && args[1]) {
            gwPlugins.toggle(args[1], true);
            printSuccess(`已启用: ${args[1]}`);
          } else if (action === 'disable' && args[1]) {
            gwPlugins.toggle(args[1], false);
            printSuccess(`已禁用: ${args[1]}`);
          } else if ((action === 'add' || action === 'create') && args[1]) {
            // Create new plugin from template, optionally open in editor
            const name = args[1];
            try {
              const template = gwPlugins.getTemplate().replace(
                /name:\s*'[^']*'/,
                `name: '${name}'`
              );
              gwPlugins.savePlugin(name, template);
              printSuccess(`插件已创建: ${gwPlugins.getPluginsDir()}/${name}.js`);
              // Open in editor if available
              const editor = process.env.EDITOR || process.env.VISUAL;
              if (editor && !options.noEdit) {
                const { execSync } = require('child_process');
                const pluginPath = require('path').join(gwPlugins.getPluginsDir(), `${name}.js`);
                printInfo(`正在打开编辑器: ${editor}...`);
                try {
                  execSync(`${editor} "${pluginPath}"`, { stdio: 'inherit' });
                  gwPlugins.reload();
                  printSuccess('插件已重载');
                } catch { /* editor closed or unavailable */ }
              } else {
                printInfo('使用 plugin gateway edit ' + name + ' 编辑');
              }
            } catch (e) {
              printError(e.message);
            }
          } else if (action === 'delete' && args[1]) {
            const name = args[1];
            // Confirm deletion
            const inq = require('inquirer');
            const { confirm } = await inq.prompt([{
              type: 'confirm',
              name: 'confirm',
              message: `确认删除插件 "${name}"?`,
              default: false,
            }]);
            if (confirm) {
              try {
                gwPlugins.deletePlugin(name);
                printSuccess(`插件 "${name}" 已删除`);
              } catch (e) {
                printError(e.message);
              }
            }
          } else if (action === 'edit' && args[1]) {
            const name = args[1];
            try {
              gwPlugins.getPluginCode(name); // verify it exists
              const editor = process.env.EDITOR || process.env.VISUAL || 'vi';
              const pluginPath = require('path').join(gwPlugins.getPluginsDir(), `${name}.js`);
              printInfo(`打开 ${editor}...`);
              const { execSync } = require('child_process');
              execSync(`${editor} "${pluginPath}"`, { stdio: 'inherit' });
              gwPlugins.reload();
              printSuccess('插件已重载');
            } catch (e) {
              printError(e.message);
            }
          } else if (action === 'show' && args[1]) {
            const name = args[1];
            try {
              const code = gwPlugins.getPluginCode(name);
              console.log('');
              console.log(chk().cyan(`  ─── ${name}.js ───`));
              console.log('');
              // Simple syntax highlighting with chalk
              const lines = code.split('\n');
              for (const line of lines) {
                if (line.trim().startsWith('//') || line.trim().startsWith('*') || line.trim().startsWith('/**')) {
                  console.log(chk().dim(`  ${line}`));
                } else if (line.includes('module.exports') || line.includes('require(')) {
                  console.log(chk().yellow(`  ${line}`));
                } else {
                  console.log(`  ${line}`);
                }
              }
              console.log('');
            } catch (e) {
              printError(e.message);
            }
          } else if (action === 'import' && args[1]) {
            const fs = require('fs');
            const path = require('path');
            const filePath = path.resolve(args[1]);
            if (!fs.existsSync(filePath)) {
              printError(`文件不存在: ${filePath}`);
            } else {
              try {
                const code = fs.readFileSync(filePath, 'utf-8');
                const baseName = path.basename(filePath, '.js');
                gwPlugins.savePlugin(baseName, code);
                printSuccess(`已导入插件: ${baseName}`);
              } catch (e) {
                printError(e.message);
              }
            }
          } else if (action === 'add' || action === 'create') {
            printInfo('用法: plugin gateway add <name>');
          } else {
            printInfo('用法: plugin gateway list | reload | enable <name> | disable <name> | add <name> | delete <name> | edit <name> | show <name> | import <file>');
          }
        } else if (['init', 'create', 'new', 'dev', 'develop', 'doctor', 'check', 'validate', 'link', 'unlink'].includes(subCommand)) {
          // SDK plugin development tools
          const { handlePlugin } = require('./handlers/plugin-dev');
          const optionTokens = [];
          for (const [k, v] of Object.entries(options || {})) {
            if (v === true) {
              optionTokens.push(`--${k}`);
            } else if (v !== false && v !== null && v !== undefined && String(v).length > 0) {
              optionTokens.push(`--${k}`, String(v));
            }
          }
          await handlePlugin([subCommand, ...args, ...optionTokens]);
        } else if (!subCommand || subCommand === 'help') {
          // Show combined help
          const { handlePlugin } = require('./handlers/plugin-dev');
          await handlePlugin([]);
        } else {
          printInfo(`插件目录: ${PLUGINS_DIR}/`);
          printInfo('用法: plugin list | reload | gateway | init | dev | doctor | link | unlink');
        }
        return true;
      }

      // ── IDE adapters ──
      case 'kiro':
      case 'cursor':
      case 'claude':
      case 'codex':
      case 'trae': {
        const { handleIdeCommand } = require('./handlers/ide');
        await handleIdeCommand(command, options, context);
        return true;
      }

      // ── Account Pool ──
      case 'pool': {
        const pool = require('./handlers/pool');
        if (subCommand === 'list') await pool.handlePoolList(args[0]);
        else if (subCommand === 'add') await pool.handlePoolAdd(args[0], args[1]);
        else if (subCommand === 'delete' || subCommand === 'remove') await pool.handlePoolDelete(args[0]);
        else if (subCommand === 'enable') await pool.handlePoolEnable(args[0]);
        else if (subCommand === 'disable') await pool.handlePoolDisable(args[0]);
        else if (subCommand === 'import') await pool.handlePoolImport(args[0], args[1]);
        else if (subCommand === 'use') await pool.handlePoolUse(args[0], args[1]);
        else if (subCommand === 'api') await pool.handlePoolApi(args[0]);
        else if (subCommand === 'status') await pool.handlePoolStatus();
        else if (subCommand === 'scheduling') await pool.handlePoolScheduling(args[0]);
        else if (subCommand === 'auto-import') await pool.handlePoolAutoImport(args[0], args[1], args[2]);
        else await pool.handlePoolStatus();
        return true;
      }

      // ── Proxy ──
      case 'proxy': {
        const proxy = require('./handlers/proxy');
        if (subCommand === 'start') await proxy.handleProxyStart(options);
        else if (subCommand === 'stop') await proxy.handleProxyStop();
        else if (subCommand === 'status') await proxy.handleProxyStatus();
        else if (subCommand === 'help') await proxy.handleProxyHelp();
        else if (subCommand === 'quickstart') await proxy.handleProxyQuickstart(args, options);
        else if (subCommand === 'cert') await proxy.handleProxyCert(args[0] || 'generate', args.slice(1), options);
        else if (subCommand === 'client') await proxy.handleProxyClient(args[0] || 'list', args.slice(1), options);
        else if (subCommand === 'token') await proxy.handleProxyToken(args[0] || 'status', args.slice(1), options);
        else if (subCommand === 'subscription' || subCommand === 'sub') await proxy.handleProxySubscription(args[0] || 'list', args.slice(1), options);
        else if (subCommand === 'tls') await proxy.handleProxyTls(args[0] || 'status', args[1] || null);
        else if (subCommand === 'switch-center' || subCommand === 'switch') await proxy.handleProxySwitchCenter(args[0] || 'status', args.slice(1), options);
        else if (subCommand === 'trae-switch') await proxy.handleProxyTraeSwitch(args[0] || 'status', args.slice(1), options);
        else if (subCommand === 'windsurf-switch') await proxy.handleProxyWindsurfSwitch(args[0] || 'status', args.slice(1), options);
        else if (subCommand === 'cursor2api') await proxy.handleProxyCursor2Api(args[0] || 'status', args.slice(1), options);
        else await proxy.handleProxyHelp();
        return true;
      }

      // ── Cron Scheduler ──
      case 'cron': {
        const { handleCronCommand } = require('./handlers/cron');
        await handleCronCommand(subCommand, args, options);
        return true;
      }

      // ── Skin / Theme ──
      case 'skin': {
        const tr = require('./themeRegistry');
        const chalk = require('chalk').default || require('chalk');
        if (subCommand === 'set' && args[0]) {
          const ok = tr.setTheme(args[0]);
          if (ok) console.log(chalk.green(`  Theme switched to: ${args[0]}`));
          else console.log(chalk.yellow(`  Unknown theme: ${args[0]}. Use "skin list" to see available themes.`));
        } else {
          const themes = tr.listThemes();
          console.log('');
          console.log(chalk.bold('  Available Themes'));
          console.log('');
          for (const t of themes) {
            const marker = t.active ? chalk.green(' (active)') : '';
            console.log(`  ${chalk.cyan(t.name.padEnd(16))} ${t.label}${marker}`);
            if (t.description) console.log(`  ${' '.repeat(16)} ${chalk.dim(t.description)}`);
          }
          console.log('');
          console.log(chalk.dim('  Usage: skin set <name>'));
          console.log('');
        }
        return true;
      }

      // ── Skills ──
      case 'skill': {
        const { handleSkillCommand } = require('./handlers/skill');
        await handleSkillCommand(subCommand, args, options);
        return true;
      }

      // ── Session Search ──
      case 'session': {
        const { handleSessionCommand } = require('./handlers/session');
        await handleSessionCommand(subCommand, args, options);
        return true;
      }

      // ── Log / Error Viewer ──
      case 'log': {
        await handleLogCommand(subCommand, args, options);
        return true;
      }

      case 'cost':
      case 'usage': {
        const tokenSvc = require('../services/tokenUsageService');
        if (subCommand === 'reset') {
          tokenSvc.resetUsage();
          printSuccess('Token 用量统计已重置');
        } else if (subCommand === 'today') {
          const today = tokenSvc.getTodayUsage();
          console.log(chalk.bold('\n  📊 今日用量'));
          console.log(chalk.dim(`  请求: ${today.requests} 次 · tokens: ${today.totalTokens.toLocaleString()}\n`));
        } else if (subCommand === 'history') {
          const history = tokenSvc.getUsageHistory(14);
          console.log(chalk.bold('\n  📊 近14天用量'));
          for (const day of history) {
            if (day.totalTokens === 0 && day.requests === 0) continue;
            const bar = '█'.repeat(Math.min(30, Math.ceil(day.totalTokens / 1000)));
            console.log(chalk.dim(`  ${day.date} `) + chalk.cyan(bar) + chalk.dim(` ${day.totalTokens.toLocaleString()}`));
          }
          console.log('');
        } else {
          // Default: show full cost report (like Claude's /cost)
          console.log(tokenSvc.formatCostReport());
        }
        return true;
      }

      case 'history': {
        const ai = require('./ai');
        if (subCommand === 'list' || !subCommand) {
          const convos = ai.listConversations();
          if (convos.length === 0) {
            printInfo('暂无保存的对话记录');
          } else {
            console.log(chalk.bold('\n  💬 对话历史\n'));
            convos.slice(0, 10).forEach((c, i) => {
              const date = c.timestamp ? new Date(c.timestamp).toLocaleString('zh-CN') : c.file;
              const sid = c.sessionId || String(c.file || '').replace(/\.json$/i, '');
              console.log(
                chalk.dim(`  ${i + 1}. `)
                + chalk.white(date)
                + chalk.dim(` (${c.messageCount} 条消息)`)
                + chalk.dim(` [ID: ${sid}]`)
              );
            });
            console.log(chalk.dim('\n  使用 resume <序号|会话ID> 恢复对话上下文\n'));
          }
        } else if (subCommand === 'resume') {
          const resolved = _resolveConversationTarget(ai, args[0]);
          const target = resolved.target;
          if (!target) {
            if (resolved.error === 'EMPTY') {
              printInfo('暂无保存的对话记录');
              return true;
            }
            if (resolved.error === 'INVALID_ID') {
              printError('无效会话 ID，请先运行 history list 查看');
              return true;
            }
            printError('无效序号，请先运行 history list 查看');
          } else {
            const result = ai.resumeConversation(target.file);
            if (result.success) {
              const sid = target.sessionId ? `, 会话ID ${target.sessionId}` : '';
              printSuccess(`已恢复对话 (${result.messageCount} 条消息, ${new Date(result.timestamp).toLocaleString('zh-CN')}${sid})`);
              printInfo('AI 已具有之前的对话上下文，可以继续提问');
            } else {
              printError('恢复失败');
            }
          }
        } else if (subCommand === 'clear') {
          const fs = require('fs');
          const os = require('os');
          const convoDir = path.join(os.homedir(), '.khyquant', 'conversations');
          try {
            try { ai.clearHistory(); } catch { /* non-critical */ }
            if (fs.existsSync(convoDir)) {
              const files = fs.readdirSync(convoDir).filter(f => f.endsWith('.json'));
              files.forEach(f => fs.unlinkSync(path.join(convoDir, f)));
              printSuccess(`已清除 ${files.length} 条对话记录，并重置当前会话上下文`);
            } else {
              printInfo('无对话记录需要清除，当前会话上下文已重置');
            }
          } catch { printError('清除失败'); }
        }
        return true;
      }

      case 'update': {
        const { execSync } = require('child_process');
        const packageCandidates = ['khy-os', 'khy-quant'];
        const pipCmd = process.platform === 'win32' ? 'pip' : 'pip3';

        const readInstalledVersion = (pkgName) => {
          try {
            const info = execSync(`${pipCmd} show ${pkgName}`, { encoding: 'utf-8', timeout: 5000 });
            const match = info.match(/Version:\s*([\d.]+)/);
            return match ? match[1] : '';
          } catch {
            return '';
          }
        };

        const detectInstalledPackage = () => {
          for (const pkgName of packageCandidates) {
            if (readInstalledVersion(pkgName)) return pkgName;
          }
          return packageCandidates[0];
        };

        console.log(chalk.bold('\n  🔄 khy OS 自动更新\n'));
        printInfo('检查最新版本...');
        try {
          const currentVersion = process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version;
          printInfo(`当前版本: v${currentVersion}`);
          const installedPkg = detectInstalledPackage();
          printInfo(`更新通道: ${installedPkg} (兼容 khy-quant)`);

          printInfo('正在更新到最新版本...');
          let output = '';
          let upgradedPkg = null;
          let lastError = null;

          for (const pkgName of packageCandidates) {
            try {
              output = execSync(`${pipCmd} install --upgrade ${pkgName} 2>&1`, {
                encoding: 'utf-8',
                timeout: 120000,
              });
              upgradedPkg = pkgName;
              break;
            } catch (err) {
              const detail = `${err.stdout || ''}\n${err.stderr || ''}\n${err.message || ''}`;
              lastError = err;
              if (/No matching distribution found|Could not find a version|404|not found/i.test(detail)) {
                continue;
              }
              throw err;
            }
          }
          if (!upgradedPkg) {
            throw lastError || new Error('No installable package found for upgrade');
          }

          if (output.includes('Successfully installed') || output.includes('already up-to-date') || output.includes('already satisfied')) {
            const newVersion = readInstalledVersion(upgradedPkg) || currentVersion;

            if (newVersion !== currentVersion) {
              printSuccess(`更新完成: v${currentVersion} → v${newVersion}`);
              printInfo('新版本已包含最新混淆保护。请重启 CLI 以应用更新。');
            } else {
              printSuccess('已是最新版本 ✓');
            }
          } else {
            printWarn('更新输出: ' + output.slice(0, 200));
          }
        } catch (err) {
          printError('更新失败: ' + (err.message || '').slice(0, 200));
          printInfo('手动更新: pip install --upgrade khy-os (兼容: khy-quant)');
        }
        console.log('');
        return true;
      }

      case 'compute': {
        const training = require('../services/modelTrainingService');
        const status = training.getComputeStatus();
        console.log(chalk.bold('\n  🖥️  本地算力状态\n'));
        console.log(chalk.dim('  平台: ') + chalk.white(`${status.platform} ${status.arch}`));
        console.log(chalk.dim('  CPU: ') + chalk.white(`${status.cpus} 核`));
        console.log(chalk.dim('  RAM: ') + chalk.white(`${status.freeRAM}GB / ${status.totalRAM}GB`));
        if (status.gpu) {
          console.log(chalk.dim('  GPU: ') + chalk.green(`${status.gpu.type} × ${status.gpu.count}`));
          if (status.gpu.devices) {
            status.gpu.devices.forEach(d => console.log(chalk.dim('       ') + chalk.white(`${d.name} (${d.memory})`)));
          }
        } else {
          console.log(chalk.dim('  GPU: ') + chalk.yellow('未检测到 (将使用 CPU 训练)'));
        }
        console.log(chalk.dim('  Python: ') + (status.pythonAvailable ? chalk.green('✓') : chalk.red('✗ 需安装')));
        console.log(chalk.dim('  PyTorch: ') + (status.torchAvailable ? chalk.green('✓') : chalk.red('✗ pip install torch')));
        console.log(chalk.dim('  CUDA: ') + (status.cuda ? chalk.green('✓') : chalk.dim('—')));
        console.log(chalk.dim('  MPS: ') + (status.mps ? chalk.green('✓ (Apple Metal)') : chalk.dim('—')));
        console.log('');
        return true;
      }

      case 'train': {
        const training = require('../services/modelTrainingService');

        if (!subCommand || subCommand === 'status') {
          // Show training data stats + registered models
          const stats = training.getDatasetStats();
          const models = training.listModels();
          const modelNames = Object.keys(models);
          console.log(chalk.bold('\n  🧠 模型训练系统\n'));
          console.log(chalk.dim('  训练数据: ') + chalk.white(`${stats.total} 条记录`));
          if (stats.byType && Object.keys(stats.byType).length > 0) {
            Object.entries(stats.byType).forEach(([type, count]) => {
              console.log(chalk.dim(`    ${type}: `) + chalk.white(count));
            });
          }
          console.log(chalk.dim('  已训练模型: ') + chalk.white(modelNames.length === 0 ? '无' : ''));
          modelNames.forEach(name => {
            const m = models[name];
            console.log(chalk.cyan(`    ${name}`) + chalk.dim(` (基于 ${m.basedOn}, ${m.method}, ${new Date(m.trainedAt).toLocaleDateString('zh-CN')})`));
          });
          console.log(chalk.dim('\n  命令:'));
          console.log(chalk.dim('    train start [--base qwen-3b] [--preset standard]  本地微调'));
          console.log(chalk.dim('    train cloud [--base qwen-7b]                      云端训练'));
          console.log(chalk.dim('    train distill                                     知识蒸馏'));
          console.log(chalk.dim('    train data                                        查看训练数据'));
          console.log(chalk.dim('    train export <model> [--format gguf|safetensors]   导出模型'));
          console.log(chalk.dim('    train list                                        列出已训练模型'));
          console.log(chalk.dim('    compute                                           查看算力状态'));
          console.log('');

        } else if (subCommand === 'data') {
          const stats = training.getDatasetStats();
          console.log(chalk.bold('\n  📊 训练数据统计\n'));
          console.log(chalk.dim('  总记录数: ') + chalk.white(stats.total));
          Object.entries(stats.byType || {}).forEach(([type, count]) => {
            console.log(chalk.dim(`  ${type}: `) + chalk.white(count));
          });
          if (stats.total > 0) {
            console.log(chalk.dim('\n  导出数据集: train export-data [--format alpaca|sharegpt|openai]'));
          } else {
            console.log(chalk.dim('\n  使用 AI 对话功能积累训练数据，系统自动记录高质量交互'));
          }
          console.log('');

        } else if (subCommand === 'list') {
          const models = training.listModels();
          const modelNames = Object.keys(models);
          if (modelNames.length === 0) {
            printInfo('暂无训练模型。使用 train start 开始训练');
          } else {
            console.log(chalk.bold('\n  🧠 已训练模型 (khy-xxx)\n'));
            modelNames.forEach(name => {
              const m = models[name];
              console.log(chalk.cyan(`  ${name}`));
              console.log(chalk.dim(`    基础: ${m.basedOn}`));
              console.log(chalk.dim(`    方法: ${m.method} · 数据量: ${m.datasetSize}`));
              console.log(chalk.dim(`    时间: ${new Date(m.trainedAt).toLocaleString('zh-CN')}`));
              console.log(chalk.dim(`    路径: ${m.path}`));
              console.log('');
            });
          }

        } else if (subCommand === 'start') {
          const baseModel = options.base || options.model || 'qwen-3b';
          const preset = options.preset || 'standard';
          const stats = training.getDatasetStats();

          if (stats.total < 10) {
            printWarn(`训练数据不足 (当前 ${stats.total} 条，建议 50+ 条)`);
            printInfo('继续使用 AI 对话以积累更多训练数据');
            return true;
          }

          printInfo(`准备本地微调: base=${baseModel}, preset=${preset}`);
          const dataset = training.exportDataset('alpaca', { quality: 'good' });
          printInfo(`数据集: ${dataset.count} 条 → ${dataset.path}`);

          const modelName = options.name || `khy-${training.getNextVersion()}`;
          printInfo(`开始训练 ${modelName}... (这可能需要几分钟到几小时)`);

          try {
            const result = await training.trainLocal({
              baseModel,
              datasetPath: dataset.path,
              outputName: modelName,
              preset,
              onProgress: (pct, msg) => {
                process.stdout.write(`\r  训练进度: ${pct}% ${msg || ''}`);
              },
            });
            console.log('');
            if (result.success) {
              printSuccess(`模型训练完成: ${modelName}`);
              printInfo(`路径: ${result.modelPath}`);
              printInfo('导出: train export ' + modelName + ' --format gguf');
            } else {
              printError('训练失败: ' + (result.error || '').slice(0, 200));
            }
          } catch (err) {
            printError(err.message);
          }

        } else if (subCommand === 'cloud') {
          const baseModel = options.base || 'qwen-7b';
          printInfo('提交云端训练任务...');
          try {
            const dataset = training.exportDataset('alpaca');
            const result = await training.trainCloud({ baseModel, datasetPath: dataset.path });
            if (result.success) {
              printSuccess(`训练任务已提交: ${result.jobId}`);
              printInfo('查看进度: train status ' + result.jobId);
            }
          } catch (err) { printError(err.message); }

        } else if (subCommand === 'distill') {
          printInfo('知识蒸馏: 从大模型生成训练数据，训练小模型');
          const studentBase = options.student || options.base || 'qwen-1.5b';
          // Use recorded conversation prompts
          const stats = training.getDatasetStats();
          if (stats.total < 5) {
            printWarn('需要更多交互数据用于蒸馏。请先积累对话记录');
            return true;
          }
          printInfo(`学生模型: ${studentBase}, 使用已记录的对话作为蒸馏素材`);
          printInfo('蒸馏过程较长，请耐心等待...');
          // Extract prompts from saved interactions for distillation
          printInfo('功能就绪，需要 Python 环境支持。详见: compute');

        } else if (subCommand === 'export') {
          const modelName = args[0];
          if (!modelName) { printError('用法: train export <模型名> [--format gguf|safetensors] [--password xxx]'); return true; }
          const format = options.format || 'gguf';

          // Password verification required for export
          let password = options.password || options.pwd || '';
          if (!password) {
            const readline = require('readline');
            const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
            password = await new Promise(resolve => {
              rl.question(chalk.yellow('  🔐 请输入导出密码: '), ans => { rl.close(); resolve(ans.trim()); });
            });
          }
          if (!training.verifyExportPassword(password)) {
            printError('密码错误，导出已拒绝');
            return true;
          }

          printInfo(`导出模型 ${modelName} → ${format}...`);
          try {
            if (format === 'gguf') {
              const quant = options.quant || 'q4_k_m';
              const result = await training.exportGGUF(modelName, quant, password);
              if (result.success) {
                printSuccess(`GGUF 导出完成: ${result.ggufPath}`);
                printInfo('注册到 Ollama: ollama create ' + modelName + ' -f Modelfile');
                const reg = await training.registerWithOllama(modelName, result.ggufPath);
                if (reg.success) printSuccess(reg.message);
              } else {
                printError('导出失败: ' + (result.error || '').slice(0, 200));
              }
            } else {
              const result = await training.exportSafetensors(modelName, password);
              if (result.success) {
                printSuccess(`Safetensors 导出完成: ${result.safetensorsPath}`);
                printInfo('可上传 HuggingFace: huggingface-cli upload ' + modelName + ' ' + result.safetensorsPath);
              } else {
                printError('导出失败: ' + (result.error || '').slice(0, 200));
              }
            }
          } catch (err) { printError(err.message); }

        } else if (subCommand === 'export-data') {
          const format = options.format || 'alpaca';
          try {
            const result = training.exportDataset(format);
            printSuccess(`数据集导出: ${result.count} 条 → ${result.path}`);
          } catch (err) { printError(err.message); }

        } else if (subCommand === 'upload') {
          const modelName = args[0];
          if (!modelName) { printError('用法: train upload <模型名> --platform github|gitee --repo <仓库名> [--token xxx]'); return true; }
          const platform = options.platform || options.p || 'github';
          const repo = options.repo || options.r || modelName;
          const token = options.token || process.env.GITHUB_TOKEN || process.env.GITEE_TOKEN || '';

          // Password verification
          let password = options.password || options.pwd || '';
          if (!password) {
            const readline = require('readline');
            const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
            password = await new Promise(resolve => {
              rl.question(chalk.yellow('  🔐 请输入导出密码: '), ans => { rl.close(); resolve(ans.trim()); });
            });
          }
          if (!training.verifyExportPassword(password)) {
            printError('密码错误，上传已拒绝');
            return true;
          }

          printInfo(`上传模型 ${modelName} → ${platform}/${repo}...`);
          try {
            const result = await training.uploadToGitRepo(modelName, { platform, repo, token, password, owner: options.owner });
            if (result.success) {
              printSuccess(result.message);
              printInfo(`仓库地址: ${result.url}`);
            } else {
              printError('上传失败: ' + result.message);
            }
          } catch (err) { printError(err.message); }
        }
        return true;
      }

      case 'admin': {
        // Hidden admin command — requires password
        const adminSvc = require('../services/adminService');
        let password = options.password || options.pwd || args[0] || '';

        if (!password) {
          const readline = require('readline');
          const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
          password = await new Promise(resolve => {
            rl.question(chalk.yellow('  🔐 管理密码: '), ans => { rl.close(); resolve(ans.trim()); });
          });
        }

        if (!adminSvc.verifyAdminPassword(password)) {
          printError('密码错误');
          return true;
        }

        if (!subCommand || subCommand === 'stats') {
          const result = adminSvc.getAdminStats(password);
          if (result.success) {
            console.log(chalk.bold('\n  🔧 管理面板\n'));
            const s = result.stats;
            console.log(chalk.dim('  设备哈希: ') + chalk.white(s.usageData.deviceHash));
            console.log(chalk.dim('  交互总数: ') + chalk.white(s.usageData.interactionCount || 0));
            console.log(chalk.dim('  安全事件: ') + chalk.white(s.securityEvents || 0));
            if (s.tokenUsage) {
              console.log(chalk.dim('  Token总量: ') + chalk.white(s.tokenUsage.totalTokens.toLocaleString()));
              console.log(chalk.dim('  总费用: ') + chalk.white(`$${s.tokenUsage.totalCost.toFixed(4)}`));
            }
            if (s.models) {
              const modelCount = Object.keys(s.models).length;
              console.log(chalk.dim('  训练模型数: ') + chalk.white(modelCount));
            }
            console.log('');
          }

        } else if (subCommand === 'export-data') {
          const result = adminSvc.exportTrainingData(password, { output: options.output, since: options.since });
          if (result.success) {
            printSuccess(`训练数据导出: ${result.count} 条 → ${result.path}`);
          } else {
            printError(result.error);
          }

        } else if (subCommand === 'export-growth') {
          const result = adminSvc.exportGrowthData(password);
          if (result.success) {
            printSuccess(`成长数据导出: ${result.path}`);
          } else {
            printError(result.error);
          }

        } else if (subCommand === 'sync') {
          printInfo('同步遥测数据...');
          const result = await adminSvc.syncTelemetry();
          if (result.synced) {
            printSuccess(`同步完成 (status: ${result.status})`);
          } else {
            printWarn(`同步失败: ${result.reason}`);
          }
        }
        return true;
      }

      case 'growth': {
        const growthSvc = require('../services/growthService');

        if (!subCommand) {
          // Show growth summary
          const summary = growthSvc.getGrowthSummary();
          const { getLevelProgress } = require('../services/knowledgeTeachingService');
          const level = getLevelProgress();

          console.log(chalk.bold('\n  🌱 成长档案\n'));
          console.log(chalk.dim('  知识等级: ') + chalk.cyan(`${level.levelName} (${level.xp} XP)`) + chalk.dim(level.xpToNext > 0 ? ` → 下一级还需 ${level.xpToNext} XP` : ' (已满级)'));
          console.log(chalk.dim('  已学话题: ') + chalk.white(`${level.completedTopics} / ${level.totalTopics}`));
          console.log(chalk.dim('  总交互数: ') + chalk.white(summary.totalInteractions.toLocaleString()));
          console.log(chalk.dim('  策略记录: ') + chalk.white(summary.strategyRecords));
          console.log(chalk.dim('  Agent均准确率: ') + chalk.white(`${summary.avgAgentAccuracy}%`));
          if (summary.topSymbols.length > 0) {
            console.log(chalk.dim('  常用标的: ') + chalk.white(summary.topSymbols.join(', ')));
          }
          console.log(chalk.dim('  快照数: ') + chalk.white(summary.snapshots));
          console.log(chalk.dim('  上次更新: ') + chalk.white(summary.lastModified || '—'));
          console.log(chalk.dim('\n  命令:'));
          console.log(chalk.dim('    growth export [--path ./backup.tar.gz]  导出成长档案'));
          console.log(chalk.dim('    growth import <文件>                    导入合并'));
          console.log(chalk.dim('    growth snapshot                         创建快照'));
          console.log(chalk.dim('    growth snapshots                        查看快照列表'));
          console.log(chalk.dim('    growth restore <快照ID>                 恢复到快照'));
          console.log(chalk.dim('    growth reset                            重置 (不可逆)'));
          console.log('');

        } else if (subCommand === 'export') {
          const outputPath = options.path || args[0] || null;
          const exported = growthSvc.exportGrowth(outputPath);
          printSuccess(`成长档案已导出: ${exported}`);
          printInfo('复制此文件到另一台机器，使用 growth import 导入即可迁移成长数据');

        } else if (subCommand === 'import') {
          const file = args[0];
          if (!file) { printError('用法: growth import <归档文件路径>'); return true; }
          try {
            const result = growthSvc.importGrowth(file);
            printSuccess(`导入成功: 来自 ${result.importedFrom}, 合并了 ${result.filesImported} 个文件`);
            printInfo(`原始导出时间: ${result.exportedAt}`);
          } catch (err) { printError(err.message); }

        } else if (subCommand === 'snapshot') {
          const snap = growthSvc.createSnapshot();
          printSuccess(`快照已创建: ${snap.snapshotId}`);

        } else if (subCommand === 'snapshots') {
          const snaps = growthSvc.listSnapshots();
          if (snaps.length === 0) {
            printInfo('暂无快照。使用 growth snapshot 创建');
          } else {
            console.log(chalk.bold('\n  📸 成长快照\n'));
            snaps.forEach(s => {
              console.log(chalk.dim('  ') + chalk.cyan(s.id) + chalk.dim(` (${(s.size / 1024).toFixed(1)} KB)`));
            });
            console.log('');
          }

        } else if (subCommand === 'restore') {
          const snapId = args[0];
          if (!snapId) { printError('用法: growth restore <快照ID>'); return true; }
          try {
            const result = growthSvc.restoreSnapshot(snapId);
            printSuccess(`已恢复到快照: ${result.restored} (${result.files} 个文件)`);
          } catch (err) { printError(err.message); }

        } else if (subCommand === 'reset') {
          printWarn('⚠ 这将清除所有成长数据（不可逆）');
          const readline = require('readline');
          const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
          const confirm = await new Promise(resolve => {
            rl.question(chalk.yellow('  确认重置？输入 YES: '), ans => { rl.close(); resolve(ans.trim()); });
          });
          if (confirm === 'YES') {
            growthSvc.resetGrowth();
            printSuccess('成长数据已重置');
          } else {
            printInfo('已取消');
          }
        }
        return true;
      }

      case 'agent': {
        const agentComm = require('../services/agentCommunicationService');

        if (!subCommand || subCommand === 'status') {
          const stats = agentComm.getAgentStats();
          console.log(chalk.bold('\n  🤖 智能体状态\n'));
          for (const [id, agent] of Object.entries(stats)) {
            const accColor = agent.accuracy >= 70 ? chalk.green : agent.accuracy >= 50 ? chalk.yellow : chalk.red;
            console.log(chalk.cyan(`  ${agent.name}`) + chalk.dim(` (${id})`));
            console.log(chalk.dim('    准确率: ') + accColor(`${agent.accuracy}%`) + chalk.dim(` · 预测次数: ${agent.totalPredictions}`));
            if (agent.strongDomains.length > 0) {
              console.log(chalk.dim('    强项: ') + chalk.green(agent.strongDomains.join(', ')));
            }
            if (agent.weakDomains.length > 0) {
              console.log(chalk.dim('    弱项: ') + chalk.red(agent.weakDomains.join(', ')));
            }
          }
          console.log('');

        } else if (subCommand === 'list' || subCommand === 'templates') {
          const agentRunner = require('../services/cliAgentRunner');
          const templates = agentRunner.listAgentTemplates();
          console.log(chalk.bold('\n  🤖 Agent Templates\n'));
          printTable(
            ['Role Key', 'Name', 'Tool Profile', 'Keywords'],
            templates.map(t => [t.key, t.name, t.toolProfile, String(t.keywordCount)])
          );
          console.log('');
          printInfo('Claude-compatible roles: general-purpose, Explore, Plan, verification, claude-code-guide');
          printInfo('Run one directly: agent run "<task>" --role Explore');
          printInfo('Spawn shortcut: agent spawn "<task>" --role codex|claude [--model <modelId>]');

        } else if (subCommand === 'run' || subCommand === 'spawn') {
          const prompt = args.join(' ');
          if (!prompt) {
            printError('Usage: agent run|spawn "<task>" [--role Explore|Plan|general-purpose|codex|claude] [--adapter codex|claude] [--model <modelId>]');
            return true;
          }

          const agentRunner = require('../services/cliAgentRunner');
          const roleInput = options.role || options.agent || options.type || 'general-purpose';
          const resolvedRole = agentRunner.resolveRoleKey(roleInput);
          const roleMeta = agentRunner.AGENT_ROLES[resolvedRole] || agentRunner.AGENT_ROLES.general;
          const preferredAdapter = String(options.adapter || options.provider || '').trim().toLowerCase();
          const preferredModel = String(options.model || '').trim();
          printInfo(`Running agent: ${roleMeta?.name || resolvedRole} (${resolvedRole})`);
          if (preferredAdapter) printInfo(`Preferred adapter: ${preferredAdapter}`);
          if (preferredModel) printInfo(`Preferred model: ${preferredModel}`);

          const aiModule = require('./ai');
          const states = await agentRunner.runAgents(
            [{ role: resolvedRole, name: roleMeta?.name || resolvedRole, task: prompt }],
            {
              ai: aiModule,
              preferredAdapter: preferredAdapter || undefined,
              preferredModel: preferredModel || undefined,
              onProgress: (agentStates) => {
                try {
                  const renderer = require('./aiRenderer');
                  renderer.renderAgentProgress(agentStates);
                } catch { /* best effort */ }
              },
            }
          );

          const first = states[0];
          if (!first || first.status !== 'completed') {
            printError(first?.detail || 'Agent run failed');
            return true;
          }
          printSuccess(`Agent completed in ${(first.elapsed / 1000).toFixed(1)}s`);
          console.log('');
          console.log(first.result || '');
          console.log('');

        } else if (subCommand === 'task') {
          const desc = args.join(' ');
          if (!desc) { printError('用法: agent task "分析任务描述" [--agents fundamental,technical,trader]'); return true; }
          const agentList = options.agents ? options.agents.split(',') : null;
          printInfo(`发起多智能体任务: ${desc}`);
          if (agentList) printInfo(`参与智能体: ${agentList.join(', ')}`);

          const task = await agentComm.executeCustomTask(desc, agentList, { symbol: options.symbol });
          console.log(chalk.bold('\n  📋 多智能体任务配置\n'));
          console.log(chalk.dim('  任务ID: ') + chalk.white(task.correlationId.slice(0, 8)));
          for (const [id, info] of Object.entries(task.agents)) {
            console.log(chalk.cyan(`  ${info.name}`) + chalk.dim(` · 可靠度: ${info.reliability}%`));
          }
          console.log(chalk.dim('\n  提示: AI 对话中会利用上述智能体协作分析'));
          console.log('');

        } else if (subCommand === 'memory') {
          const ctx = agentComm.getSharedContext();
          console.log(chalk.bold('\n  🧠 智能体共享记忆\n'));
          console.log(chalk.dim('  市场状态: ') + chalk.white(ctx.sharedContext?.currentMarketRegime || '未知'));
          const signals = ctx.sharedContext?.recentSignals || [];
          if (signals.length > 0) {
            console.log(chalk.dim('  近期信号:'));
            signals.slice(-5).forEach(s => {
              console.log(chalk.dim('    ') + chalk.white(`${s.type} ${s.symbol || ''} ${s.direction || ''}`));
            });
          }
          const insights = ctx.sharedContext?.crossAgentInsights || [];
          if (insights.length > 0) {
            console.log(chalk.dim('  跨Agent洞察:'));
            insights.slice(-3).forEach(i => {
              console.log(chalk.dim('    ') + chalk.white(i.content || JSON.stringify(i).slice(0, 80)));
            });
          }
          console.log(chalk.dim('  上次更新: ') + chalk.white(ctx.sharedContext?.lastUpdated || '—'));
          console.log('');

        } else if (subCommand === 'collaborate') {
          const collaborators = agentComm.getAvailableCollaborators();
          console.log(chalk.bold('\n  🔗 多IDE协作模型\n'));
          if (collaborators.length === 0) {
            printInfo('未检测到可协作的 IDE/模型');
          } else {
            collaborators.forEach(c => {
              console.log(chalk.dim('  ') + chalk.green('●') + ` ${c.name}` + chalk.dim(` (${c.type})`));
            });
            printInfo(`共 ${collaborators.length} 个模型可参与协作`);
          }
          console.log('');
        }
        return true;
      }

      case 'prompt': {
        const promptLib = require('../services/promptLibraryService');

        if (!subCommand || subCommand === 'list') {
          const folder = args[0] || null;
          const prompts = promptLib.listPrompts(folder);
          if (prompts.length === 0) {
            printInfo('暂无保存的提示词。使用 prompt save "标题" "内容" 保存');
          } else {
            console.log(chalk.bold('\n  📝 提示词库\n'));
            prompts.forEach(p => {
              const used = p.usedCount > 0 ? chalk.dim(` (使用 ${p.usedCount} 次)`) : '';
              console.log(chalk.cyan(`  [${p.id}]`) + ` ${p.title}` + used + chalk.dim(` · ${p.folder}`));
            });
            console.log(chalk.dim(`\n  共 ${prompts.length} 条 · 目录: ${promptLib.getPromptDir()}`));
            console.log('');
          }

        } else if (subCommand === 'save') {
          const title = args[0];
          const content = args.slice(1).join(' ') || options.content;
          if (!title || !content) {
            printError('用法: prompt save "标题" "提示词内容" [--folder 分类] [--tags tag1,tag2]');
            return true;
          }
          const tags = options.tags ? options.tags.split(',') : [];
          const folder = options.folder || options.f || null;
          const result = promptLib.savePrompt({ title, content, tags }, folder);
          printSuccess(`提示词已保存: ${result.title} [${result.id}]`);
          printInfo(`路径: ${result.path}`);

        } else if (subCommand === 'use') {
          const id = args[0];
          if (!id) { printError('用法: prompt use <ID>'); return true; }
          const content = promptLib.usePrompt(id);
          if (content) {
            // Forward to AI
            return { aiForward: content };
          } else {
            printError(`未找到提示词: ${id}`);
          }

        } else if (subCommand === 'delete') {
          const id = args[0];
          if (!id) { printError('用法: prompt delete <ID>'); return true; }
          if (promptLib.deletePrompt(id)) {
            printSuccess('已删除');
          } else {
            printError(`未找到: ${id}`);
          }

        } else if (subCommand === 'search') {
          const keyword = args.join(' ');
          if (!keyword) { printError('用法: prompt search <关键词>'); return true; }
          const results = promptLib.searchPrompts(keyword);
          if (results.length === 0) {
            printInfo(`未找到匹配 "${keyword}" 的提示词`);
          } else {
            results.forEach(p => {
              console.log(chalk.cyan(`  [${p.id}]`) + ` ${p.title}` + chalk.dim(` · ${p.folder}`));
            });
          }

        } else if (subCommand === 'folder') {
          const action = args[0];
          if (action === 'new' || action === 'create') {
            const name = args[1];
            if (!name) { printError('用法: prompt folder new <名称>'); return true; }
            const result = promptLib.createFolder(name);
            if (result.success) printSuccess(`文件夹已创建: ${result.path}`);
            else printError(result.error);
          } else {
            const folders = promptLib.listFolders();
            console.log(chalk.bold('\n  📂 提示词文件夹\n'));
            folders.forEach(f => console.log(chalk.dim('  ') + chalk.cyan(f)));
            console.log('');
          }

        } else if (subCommand === 'dir') {
          const newDir = args[0];
          if (newDir) {
            if (promptLib.setPromptDir(newDir)) {
              printSuccess(`提示词目录已设置: ${newDir}`);
            } else {
              printError('目录设置失败');
            }
          } else {
            printInfo(`当前提示词目录: ${promptLib.getPromptDir()}`);
            printInfo('设置新目录: prompt dir /path/to/your/folder');
          }
        }
        return true;
      }

      case 'voice': {
        // Voice control placeholder — future integration with Windows Win+H
        console.log(chalk.bold('\n  🎤 语音控制 (预览)\n'));
        printInfo('语音控制功能正在开发中...');
        console.log('');
        console.log(chalk.dim('  计划支持:'));
        console.log(chalk.dim('  • Windows Win+H 语音输入集成'));
        console.log(chalk.dim('  • 语音命令识别 → 自动执行'));
        console.log(chalk.dim('  • 语音播报分析结果'));
        console.log(chalk.dim('  • 免手操作量化交易'));
        console.log('');
        console.log(chalk.dim('  当前可用: 使用系统语音输入 (Win+H) 直接在命令行输入'));
        console.log(chalk.dim('  提示: Win+H 的语音文字会自动输入到当前终端光标位置'));
        console.log('');
        return true;
      }

      case 'knowledge': {
        const kts = require('../services/knowledgeTeachingService');

        if (subCommand === 'search') {
          const query = args.join(' ');
          if (!query) { printError('请输入搜索关键词'); return true; }
          const results = kts.searchKnowledge(query);
          if (results.length === 0) {
            printInfo(`未找到与 "${query}" 相关的知识`);
          } else {
            console.log(chalk.bold(`\n  📚 知识库搜索: "${query}" (${results.length} 条)\n`));
            for (const r of results.slice(0, 10)) {
              const src = r.source === 'builtin' ? chalk.green('内置') : r.source === 'community' ? chalk.blue('社区') : chalk.cyan('学习');
              console.log(`  ${src} ${chalk.white(r.title)} [${r.category}]`);
              console.log(`  ${chalk.dim(r.content.slice(0, 100))}${r.content.length > 100 ? '...' : ''}`);
              console.log('');
            }
          }
          return true;
        }

        if (subCommand === 'stats') {
          const stats = kts.getKnowledgeStats();
          console.log(chalk.bold('\n  📊 知识库统计\n'));
          console.log(`  内置知识:    ${chalk.bold(stats.builtinCount)} 条`);
          console.log(`  学习积累:    ${chalk.bold(stats.learnedCount)} 条`);
          console.log(`  总计:        ${chalk.bold(stats.totalCount)} 条`);
          if (Object.keys(stats.learnedCategories).length > 0) {
            console.log(chalk.dim('\n  学习知识分类:'));
            for (const [cat, count] of Object.entries(stats.learnedCategories)) {
              console.log(`    ${cat}: ${count}`);
            }
          }
          console.log('');
          return true;
        }

        if (subCommand === 'self') {
          const aiCli = require('./ai');
          const studyMode = !!(aiCli.isStudyMode && aiCli.isStudyMode());
          let runtimeAdapter = null;
          let runtimeModel = null;
          try {
            const gw = require('../services/gateway/aiGateway');
            const active = gw.getActiveAdapter?.();
            runtimeAdapter = active?.name || null;
            runtimeModel = active?.activeModel || active?.name || null;
          } catch { /* best effort */ }

          const profile = kts.getSelfAwarenessProfile({
            studyMode,
            adapter: runtimeAdapter,
            model: runtimeModel,
            effort: aiCli.getEffort ? aiCli.getEffort() : null,
          });
          const lines = kts.formatSelfAwarenessProfile(profile);

          console.log('');
          for (const line of lines) {
            console.log(`  ${line}`);
          }
          console.log('');
          printInfo('建议: 开启学习模式后提问，系统会按“能力边界→学习路径→练习检查点”方式回答');
          return true;
        }

        if (subCommand === 'sync') {
          const syncAction = args[0];

          if (syncAction === 'config') {
            const repo = args[1];
            if (!repo) {
              printError('请指定仓库地址');
              printInfo('用法: knowledge sync config <owner/repo> [--platform github|gitee|gitlab] [--token <PAT>]');
              return true;
            }
            const result = kts.configureKBSync({
              repo,
              platform: options.platform || null,
              token: options.token || null,
              isPublic: !options.private,
            });
            printSuccess(`知识库同步已配置: ${result.platform}/${result.repo}`);
            printInfo(`类型: ${result.isPublic ? '公共贡献' : '私人备份'} | 自动同步: ${result.autoSync ? '开' : '关'}`);
            return true;
          }

          if (syncAction === 'push') {
            const result = kts.syncKBToGitHub();
            if (result.success) {
              printSuccess(`知识库已同步到 ${result.platform || 'github'}/${result.repo || ''}`);
              printInfo(`文件: ${result.filename}`);
            } else {
              printError(result.error);
              if (result.hint) printInfo(result.hint);
            }
            return true;
          }

          if (syncAction === 'pull') {
            const repo = args[1] || null;
            const platform = options.platform || null;
            const result = kts.pullCommunityKnowledge(repo, platform);
            if (result.success) {
              printSuccess(`已从社区拉取 ${result.merged} 条新知识 (来自 ${result.contributors} 个贡献者)`);
              printInfo(`本地知识库现有 ${result.totalNow} 条`);
            } else {
              printError(result.error);
            }
            return true;
          }

          if (syncAction === 'status') {
            const config = kts.getKBSyncConfig();
            if (!config) {
              printInfo('未配置知识库同步');
              printInfo('使用: knowledge sync config <repo> 配置');
            } else {
              console.log(chalk.bold('\n  🔄 知识库同步状态\n'));
              console.log(`  平台:      ${config.platform}`);
              console.log(`  仓库:      ${config.repo}`);
              console.log(`  类型:      ${config.isPublic ? '公共贡献' : '私人备份'}`);
              console.log(`  自动同步:  ${config.autoSync ? '开' : '关'} (每 ${config.syncThreshold} 条)`);
              console.log(`  上次同步:  ${config.lastSync || '从未'}`);
              console.log('');
            }
            return true;
          }

          // Default sync help
          console.log(chalk.bold('\n  🔄 知识库同步\n'));
          console.log(chalk.dim('  支持平台: GitHub, Gitee, GitLab\n'));
          console.log('  knowledge sync config <repo>  — 配置同步仓库');
          console.log('  knowledge sync push           — 推送知识到远端');
          console.log('  knowledge sync pull [repo]    — 拉取社区知识');
          console.log('  knowledge sync status         — 查看同步状态');
          console.log(chalk.dim('\n  选项: --platform gitee|gitlab  --token <PAT>  --private'));
          console.log('');
          return true;
        }

        // Default: show knowledge overview
        const progress = kts.getLevelProgress();
        const stats = kts.getKnowledgeStats();
        console.log(chalk.bold('\n  📚 量化知识库\n'));
        console.log(`  等级:     ${chalk.bold(progress.levelName)} (XP: ${progress.xp})`);
        console.log(`  进度:     ${progress.progress}% → 下一级还需 ${progress.xpToNext} XP`);
        console.log(`  内置知识: ${stats.builtinCount} 条`);
        console.log(`  学习积累: ${stats.learnedCount} 条`);
        console.log(`  已完成:   ${progress.completedTopics}/${progress.totalTopics} 个话题`);
        console.log('');
        printInfo('命令: knowledge self | knowledge search <关键词> | knowledge stats | knowledge sync');
        console.log('');
        return true;
      }

      case 'security': {
        const secSvc = require('../services/securityGuardService');

        if (subCommand === 'scan') {
          console.log(chalk.bold('\n  🛡️ 安全扫描...\n'));
          const result = secSvc.scanForThreats();
          if (result.clean) {
            printSuccess('扫描完成 — 未发现威胁');
          } else {
            printError(`发现 ${result.threats.length} 个威胁!`);
            for (const t of result.threats) {
              const icon = t.severity === 'critical' ? '🔴' : t.severity === 'high' ? '🟠' : '🟡';
              console.log(`  ${icon} [${t.severity}] ${t.detail}`);
              if (t.action) console.log(chalk.dim(`     修复: ${t.action}`));
            }
          }
          if (result.recommendations.length > 0) {
            console.log(chalk.bold('\n  📋 安全建议'));
            for (const r of result.recommendations) {
              console.log(chalk.dim(`  • ${r.detail}`));
            }
          }
          console.log('');
          return true;
        }

        if (subCommand === 'monitor') {
          secSvc.startSecurityMonitor();
          printSuccess('后台安全监控已启动 (每 10 分钟扫描一次)');
          printInfo('异常事件记录到 ~/.khyquant/security.log');
          return true;
        }

        if (subCommand === 'integrity') {
          const result = secSvc.checkProcessIntegrity();
          console.log(chalk.bold('\n  🔍 进程完整性检查\n'));
          console.log(`  当前 PID:     ${result.pid}`);
          console.log(`  子进程数:     ${result.childCount}`);
          console.log(`  可疑进程:     ${result.suspicious.length}`);
          if (result.clean) {
            printSuccess('进程完整性正常');
          } else {
            printError('发现可疑子进程:');
            for (const s of result.suspicious) {
              console.log(`    PID ${s.pid}: ${s.cmd}`);
            }
          }
          console.log('');
          return true;
        }

        if (subCommand === 'status') {
          const stats = secSvc.getSecurityStats();
          console.log(chalk.bold('\n  🛡️ 安全状态\n'));
          console.log(`  总拦截事件: ${stats.totalEvents}`);
          console.log(`  24h 内:     ${stats.last24h}`);
          if (stats.byType && Object.keys(stats.byType).length > 0) {
            console.log(chalk.dim('\n  按类型:'));
            for (const [type, count] of Object.entries(stats.byType)) {
              console.log(`    ${type}: ${count}`);
            }
          }
          // Show permission profile
          try {
            const permStore = require('../services/permissionStore');
            console.log(`\n  权限模式:   ${chalk.cyan(permStore.getProfile())}`);
            console.log(`  已授权工具: ${permStore.getApprovedTools().length}`);
            console.log(`  已拒绝工具: ${permStore.getDeniedTools().length}`);
          } catch { /* permissionStore not available */ }
          console.log('');
          return true;
        }

        if (subCommand === 'profile') {
          const permStore = require('../services/permissionStore');
          const profileName = args[0];
          if (profileName) {
            try {
              permStore.setProfile(profileName);
              // Also sync dangerous mode with yolo profile
              const toolCalling = require('../services/toolCalling');
              if (profileName === 'yolo') {
                toolCalling.enableDangerousMode();
                toolCalling.acknowledgeDangerousMode();
              } else {
                toolCalling.disableDangerousMode();
              }
              printSuccess(`权限模式已设置为: ${profileName}`);
              const desc = { strict: '所有工具需确认', normal: '安全工具自动放行', yolo: '全部自动放行' };
              printInfo(desc[profileName] || '');
            } catch (err) {
              printError(err.message);
            }
          } else {
            const current = permStore.getProfile();
            console.log(chalk.bold('\n  🔒 权限模式\n'));
            for (const p of ['strict', 'normal', 'yolo']) {
              const marker = p === current ? chalk.green(' ← 当前') : '';
              const desc = { strict: '所有工具需确认 (最安全)', normal: '安全工具自动放行 (默认)', yolo: '全部自动放行 (等同 --dangerous)' };
              console.log(`  ${p === current ? chalk.green('●') : chalk.dim('○')} ${chalk.bold(p)}  ${chalk.dim(desc[p])}${marker}`);
            }
            console.log(chalk.dim('\n  用法: security profile <strict|normal|yolo>\n'));
          }
          return true;
        }

        if (subCommand === 'audit') {
          const auditLog = require('../services/auditLog');
          const toolFilter = options.tool || null;
          const limit = parseInt(options.limit) || 20;
          const entries = auditLog.queryAuditLog({ tool: toolFilter, limit });

          console.log(chalk.bold('\n  📋 工具执行审计日志\n'));
          if (entries.length === 0) {
            printInfo('暂无审计记录');
          } else {
            for (const e of entries) {
              const icon = e.result?.success ? chalk.green('✓') : chalk.red('✗');
              const time = new Date(e.timestamp).toLocaleString('zh-CN');
              const elapsed = e.elapsed ? chalk.dim(`${e.elapsed}ms`) : '';
              console.log(`  ${icon} ${chalk.dim(time)} ${chalk.cyan(e.tool)} ${elapsed} ${chalk.dim(`[${e.permission}]`)}`);
            }
            // Show stats summary
            const stats = auditLog.getAuditStats();
            console.log(chalk.dim(`\n  总计 ${stats.totalCalls} 次调用 · ${stats.errorCount} 次失败 · ${stats.deniedCount} 次拒绝 · 平均 ${stats.avgElapsed}ms`));
          }
          console.log('');
          return true;
        }

        if (subCommand === 'permissions') {
          const permStore = require('../services/permissionStore');
          const rules = permStore.getAllRules();
          console.log(chalk.bold('\n  🔑 权限规则\n'));
          console.log(`  当前模式: ${chalk.cyan(rules.profile)}`);

          const persistent = Object.entries(rules.persistent);
          if (persistent.length > 0) {
            console.log(chalk.bold('\n  持久规则:'));
            for (const [name, rule] of persistent) {
              const icon = rule.decision === 'allow' ? chalk.green('✓') : chalk.red('✗');
              console.log(`  ${icon} ${name} — ${rule.decision} (${rule.scope})${rule.migrated ? chalk.dim(' [已迁移]') : ''}`);
            }
          }
          if (rules.sessionApproved.length > 0) {
            console.log(chalk.bold('\n  会话授权:'));
            for (const name of rules.sessionApproved) {
              console.log(`  ${chalk.green('✓')} ${name}`);
            }
          }
          if (rules.sessionDenied.length > 0) {
            console.log(chalk.bold('\n  会话拒绝:'));
            for (const name of rules.sessionDenied) {
              console.log(`  ${chalk.red('✗')} ${name}`);
            }
          }
          if (persistent.length === 0 && rules.sessionApproved.length === 0 && rules.sessionDenied.length === 0) {
            printInfo('暂无自定义规则，使用默认模式');
          }
          console.log('');
          return true;
        }

        // Default: quick scan
        console.log(chalk.bold('\n  🛡️ 安全防护\n'));
        console.log('  security scan          — 完整安全扫描 (挖矿/木马/可疑进程)');
        console.log('  security monitor       — 启动后台监控 (每10分钟自动扫描)');
        console.log('  security integrity     — 进程完整性检查');
        console.log('  security status        — 查看拦截统计');
        console.log('  security profile <p>   — 设置权限模式 (strict/normal/yolo)');
        console.log('  security audit         — 查看工具执行审计日志');
        console.log('  security permissions   — 查看当前权限规则');
        console.log('');
        // Run quick integrity check
        const integrity = secSvc.checkProcessIntegrity();
        if (integrity.clean) {
          printSuccess('快速检查: 进程完整性正常');
        } else {
          printError(`快速检查: 发现 ${integrity.suspicious.length} 个可疑进程`);
        }
        console.log('');
        return true;
      }

      case 'monitor': {
        const aiMonitor = require('../services/aiMonitor');
        if (subCommand === 'selfcheck') {
          const selfCheck = require('../services/baseSelfCheckService');
          const action = (args[0] || 'status').toLowerCase();

          const colorSeverity = (severity) => {
            if (severity === 'critical') return chalk.red(severity);
            if (severity === 'degraded') return chalk.yellow(severity);
            return chalk.green(severity || 'healthy');
          };

          if (action === 'start') {
            const intervalMs = parseInt(
              options.interval || args[1] || process.env.KHY_SELF_CHECK_INTERVAL_MS || '300000',
              10
            );
            const st = selfCheck.start(intervalMs, { runImmediately: true });
            printSuccess(`循环自检已启动，间隔 ${st.intervalMs}ms`);
            if (st.lastResult) {
              printInfo(`最近结果: ${st.lastResult.severity} · score ${st.lastResult.score}`);
            }
            return true;
          }

          if (action === 'stop') {
            const st = selfCheck.stop();
            printSuccess('循环自检已停止');
            if (st.lastResult) {
              printInfo(`最后一次: ${st.lastResult.severity} · score ${st.lastResult.score}`);
            }
            return true;
          }

          if (action === 'run') {
            printInfo('执行一次底座自检...');
            const report = await selfCheck.runOnce({
              trigger: 'manual',
              forceThreatScan: true,
              forcePluginDoctor: true,
              pluginDoctorDeep: options.deep === true || options.deep === 'true',
            });

            if (report.skipped) {
              printWarn('已有自检任务在运行，跳过本次触发');
              return true;
            }

            console.log(chalk.bold('\n  🔁 自检结果\n'));
            console.log(`  严重级别: ${colorSeverity(report.severity)}`);
            console.log(`  评分:     ${report.score}/100`);
            console.log(`  耗时:     ${report.durationMs}ms`);
            console.log(`  问题数:   ${report.issues.length}`);
            const repairCount = Array.isArray(report.repairs) ? report.repairs.length : 0;
            console.log(`  修复数:   ${repairCount}`);
            if (report.issues.length > 0) {
              console.log(chalk.bold('\n  Top Issues:'));
              for (const issue of report.issues.slice(0, 8)) {
                const icon = issue.severity === 'critical'
                  ? chalk.red('✗')
                  : issue.severity === 'high'
                    ? chalk.yellow('!')
                    : chalk.dim('•');
                console.log(`  ${icon} [${issue.source}] ${issue.message}`);
              }
            }
            if (repairCount > 0) {
              console.log(chalk.bold('\n  Auto Repairs:'));
              for (const repair of report.repairs.slice(0, 8)) {
                const from = repair.from ? ` ${repair.from}` : '';
                const to = repair.to ? ` -> ${repair.to}` : '';
                const action = repair.action ? `[${repair.action}]` : '[repair]';
                console.log(`  ${chalk.green('✓')} ${action}${from}${to}`);
              }
            }
            console.log('');
            return true;
          }

          if (action === 'tail') {
            const n = Math.max(1, parseInt(options.n || args[1] || '10', 10) || 10);
            const logs = selfCheck.tail(n);
            if (logs.length === 0) {
              printInfo('暂无自检日志');
              return true;
            }
            console.log(chalk.bold(`\n  🔁 最近 ${logs.length} 条自检记录\n`));
            for (const row of logs) {
              const time = row.timestamp ? new Date(row.timestamp).toLocaleString('zh-CN') : '-';
              const sev = colorSeverity(row.severity || 'unknown');
              const score = Number.isFinite(row.score) ? row.score : '-';
              const issueCount = Number.isFinite(row.issueCount) ? row.issueCount : 0;
              const repairCount = Number.isFinite(row.repairCount) ? row.repairCount : 0;
              const dur = Number.isFinite(row.durationMs) ? `${row.durationMs}ms` : '-';
              console.log(`  ${time}  ${sev}  score=${score}  issues=${issueCount}  repairs=${repairCount}  ${dur}`);
            }
            console.log('');
            return true;
          }

          // status (default)
          const st = selfCheck.status();
          console.log(chalk.bold('\n  🔁 底座循环自检\n'));
          console.log(`  运行状态: ${st.running ? chalk.green('running') : chalk.yellow('stopped')}`);
          console.log(`  间隔:     ${st.intervalMs}ms`);
          console.log(`  运行次数: ${st.runCount}`);
          if (st.startedAt) {
            console.log(`  启动时间: ${new Date(st.startedAt).toLocaleString('zh-CN')}`);
          }
          if (st.lastResult) {
            console.log(`  最近级别: ${colorSeverity(st.lastResult.severity)} · score ${st.lastResult.score}`);
            console.log(`  最近时间: ${new Date(st.lastResult.timestamp).toLocaleString('zh-CN')}`);
            console.log(`  最近耗时: ${st.lastResult.durationMs}ms`);
            console.log(`  问题数量: ${st.lastResult.issueCount}`);
            console.log(`  修复数量: ${Number.isFinite(st.lastResult.repairCount) ? st.lastResult.repairCount : 0}`);
          } else {
            console.log(`  最近结果: ${chalk.dim('暂无')}`);
          }
          console.log(`  日志文件: ${st.logFile}`);
          console.log(chalk.dim('\n  用法: monitor selfcheck start|stop|status|run|tail [--interval ms] [--n N] [--deep]\n'));
          return true;
        }

        if (subCommand === 'dashboard') {
          // Unified telemetry dashboard
          const telemetry = require('../services/telemetryService');
          const dashboard = telemetry.createDashboardData();
          console.log(chalk.bold('\n  📊 统一监控仪表盘\n'));
          console.log(`  运行时间:     ${dashboard.summary.uptime}`);
          console.log(`  工具调用:     ${dashboard.counters.tools} (${dashboard.summary.toolCallsPerMinute}/min)`);
          console.log(`  成功率:       ${dashboard.summary.successRate}`);
          console.log(`  平均延迟:     ${dashboard.summary.avgLatency}`);
          console.log(`  智能体运行:   ${dashboard.counters.agents}`);
          console.log(`  服务调用:     ${dashboard.counters.services}`);
          console.log(`  错误数:       ${chalk.red(dashboard.counters.errors)}`);
          console.log(`  内存占用:     ${dashboard.summary.memoryUsed}`);
          if (dashboard.topTools.length > 0) {
            console.log(chalk.bold('\n  热门工具:'));
            for (const t of dashboard.topTools) {
              console.log(`    ${chalk.cyan(t.name)} — ${t.count} 次`);
            }
          }
          console.log('');
          return true;
        }

        if (subCommand === 'tools') {
          // Tool execution stats from audit log
          try {
            const auditLog = require('../services/auditLog');
            const stats = auditLog.getAuditStats();
            console.log(chalk.bold('\n  🔧 工具执行统计\n'));
            console.log(`  总调用: ${stats.totalCalls} · 错误: ${stats.errorCount} · 拒绝: ${stats.deniedCount} · 平均延迟: ${stats.avgElapsed}ms`);
            if (Object.keys(stats.byTool).length > 0) {
              console.log(chalk.bold('\n  按工具:'));
              const sorted = Object.entries(stats.byTool).sort(([, a], [, b]) => b - a);
              for (const [name, count] of sorted.slice(0, 15)) {
                const bar = '█'.repeat(Math.min(20, Math.ceil(count / Math.max(1, sorted[0][1]) * 20)));
                console.log(`    ${chalk.cyan(name.padEnd(20))} ${chalk.green(bar)} ${count}`);
              }
            }
            if (Object.keys(stats.byPermission).length > 0) {
              console.log(chalk.bold('\n  按权限:'));
              for (const [perm, count] of Object.entries(stats.byPermission)) {
                console.log(`    ${perm}: ${count}`);
              }
            }
            console.log('');
          } catch {
            printInfo('审计日志不可用');
          }
          return true;
        }

        if (subCommand === 'status' || !subCommand) {
          const stats = aiMonitor.getStats();
          console.log('');
          console.log(`  ${chalk.cyan.bold('AI Monitor 追踪')}`);
          console.log('');
          console.log(`  ${chalk.gray('总请求:')}   ${stats.total}`);
          console.log(`  ${chalk.gray('成功:')}     ${chalk.green(stats.success)}`);
          console.log(`  ${chalk.gray('失败:')}     ${chalk.red(stats.failure)}`);
          console.log(`  ${chalk.gray('成功率:')}   ${stats.successRate}`);
          console.log(`  ${chalk.gray('平均延迟:')} ${stats.avgLatencyMs}ms`);
          console.log(`  ${chalk.gray('缓冲:')}     ${stats.bufferSize}/${stats.maxBufferSize}`);
          if (Object.keys(stats.providers).length > 0) {
            console.log('');
            console.log(chalk.dim('  按 Provider:'));
            for (const [p, s] of Object.entries(stats.providers)) {
              console.log(`    ${p}: ${s.total} req, ${s.successRate}% ok, ${s.avgLatency}ms avg`);
            }
          }
          console.log('');
        } else if (subCommand === 'tail') {
          const recent = aiMonitor.getRecent(10);
          console.log('');
          console.log(`  ${chalk.cyan.bold('最近 AI 请求')}`);
          console.log('');
          for (const t of recent) {
            const icon = t.success ? chalk.green('●') : chalk.red('●');
            const time = new Date(t.startTime).toLocaleTimeString();
            console.log(`  ${icon} ${chalk.dim(time)} ${chalk.gray(t.request?.adapter || '?')} ${t.latencyMs ? t.latencyMs + 'ms' : '...'} ${chalk.dim(t.request?.prompt?.slice(0, 50) || '')}`);
          }
          if (recent.length === 0) printInfo('暂无追踪记录');
          console.log('');
        } else if (subCommand === 'clear') {
          aiMonitor.clearTraces();
          printSuccess('追踪记录已清除');
        }
        return true;
      }

      case 'services': {
        const registry = require('../services/serviceRegistry');
        if (subCommand === 'list' || !subCommand) {
          const services = registry.list();
          console.log(chalk.bold(`\n  📦 服务注册表 (${services.length} 个)\n`));
          // Group by category
          const grouped = {};
          for (const svc of services) {
            if (!grouped[svc.category]) grouped[svc.category] = [];
            grouped[svc.category].push(svc);
          }
          for (const [cat, svcs] of Object.entries(grouped).sort()) {
            console.log(chalk.bold(`  [${cat}]`));
            for (const svc of svcs) {
              const status = svc.error ? chalk.red('✗') : svc.loaded ? chalk.green('●') : chalk.dim('○');
              console.log(`    ${status} ${chalk.cyan(svc.name.padEnd(25))} ${chalk.dim(svc.description)}`);
            }
          }
          const st = registry.stats();
          console.log(chalk.dim(`\n  ${st.total} 注册 · ${st.loaded} 已加载 · ${st.errored} 错误\n`));
        } else if (subCommand === 'health') {
          printInfo('正在检查服务健康...');
          const results = await registry.healthCheck();
          console.log(chalk.bold('\n  🏥 服务健康检查\n'));
          for (const r of results) {
            const icon = r.healthy === true ? chalk.green('✓') : r.healthy === false ? chalk.red('✗') : chalk.dim('○');
            const latency = r.latency ? chalk.dim(` (${r.latency}ms)`) : '';
            const note = r.error ? chalk.red(` — ${r.error}`) : (r.note ? chalk.dim(` — ${r.note}`) : '');
            console.log(`  ${icon} ${r.name}${latency}${note}`);
          }
          console.log('');
        }
        return true;
      }

      case 'linux': {
        const { handleLinuxCommand } = require('./handlers/linux');
        await handleLinuxCommand(subCommand, args, options);
        return true;
      }

      case 'shell': {
        const showShellHelp = () => {
          console.log('');
          console.log(chalk.cyan.bold('  🖥 Shell Command'));
          console.log('');
          console.log('  shell <command...>                          执行 shell 命令');
          console.log('  shell run <command...>                      显式 run 模式');
          console.log('  shell --cwd <dir> --timeout <ms> -- <cmd>  指定目录/超时并执行命令');
          console.log('');
          console.log('  示例:');
          console.log('    shell ls -la');
          console.log('    shell run npm test');
          console.log('    shell --cwd backend --timeout 45000 -- npm run test -- --runInBand');
          console.log('');
          console.log('  说明: 若命令参数包含 --xxx，建议使用 `--` 分隔 CLI 选项和 shell 命令。');
          console.log('');
        };

        if (subCommand === 'help') {
          showShellHelp();
          return true;
        }

        const commandText = args.join(' ').trim();
        if (!commandText) {
          printError('Usage: shell <command...> [--cwd <path>] [--timeout <ms>]');
          printInfo('Tip: use `--` before shell command when it contains --flags.');
          return true;
        }

        const timeoutRaw = options.timeout ?? options.timeout_ms;
        const timeoutMs = Number(timeoutRaw);
        const payload = { command: commandText };
        if (typeof options.cwd === 'string' && options.cwd.trim()) payload.cwd = options.cwd.trim();
        if (Number.isFinite(timeoutMs) && timeoutMs > 0) payload.timeout = timeoutMs;

        const toolCalling = require('../services/toolCalling');
        const permission = await toolCalling.requestPermission('shellCommand', payload);
        if (permission === 'deny') {
          printError('User denied shell command execution');
          return true;
        }
        const toolRegistry = toolCalling.getToolRegistry();
        const shellTool = toolRegistry?.get?.('shellCommand');
        if (!shellTool || typeof shellTool.execute !== 'function') {
          printError('shellCommand tool is unavailable');
          return true;
        }
        if (typeof shellTool.validateInput === 'function') {
          const semantic = await shellTool.validateInput(payload, {});
          if (semantic && semantic.valid === false) {
            printError(semantic.message || 'Shell command validation failed');
            return true;
          }
        }
        const result = await shellTool.execute(payload, {
          traceContext: { source: 'cli-shell', role: 'user' },
          onActivity: () => {},
        });

        const output = String(result?.output || '').trimEnd();
        if (output) console.log(output);

        if (result?.success) {
          const exitCode = Number.isFinite(Number(result.exitCode)) ? Number(result.exitCode) : 0;
          printSuccess(`Shell command completed (exit ${exitCode})`);
        } else {
          let errText = '';
          if (typeof result?.error === 'string') errText = result.error.trim();
          else if (result?.error?.message) errText = String(result.error.message).trim();
          else if (result?.error) errText = JSON.stringify(result.error);
          if (!errText) {
            const exitCode = Number.isFinite(Number(result?.exitCode)) ? Number(result.exitCode) : null;
            errText = exitCode !== null
              ? `Shell command failed (exit ${exitCode})`
              : 'Shell command failed';
          }
          printError(errText);
          if (result?.hint) printInfo(`Hint: ${result.hint}`);
        }
        return true;
      }

      // ── Local models (Ollama) ──
      case 'models': {
        const mgr = require('../services/ollamaModelManager');
        const fs = require('fs');
        const envPath = path.resolve(__dirname, '../../.env');

        const setEnvVar = (key, value) => {
          let envContent = '';
          try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }
          const regex = new RegExp(`^${key}=.*$`, 'm');
          const line = `${key}=${value}`;
          if (regex.test(envContent)) envContent = envContent.replace(regex, line);
          else envContent = envContent.trimEnd() + '\n' + line + '\n';
          fs.writeFileSync(envPath, envContent);
          process.env[key] = String(value);
        };

        if (subCommand === 'list' || !subCommand) {
          const running = await mgr.isOllamaRunning();
          if (!running) { printError('Ollama 未运行。请先执行: ollama serve'); return true; }
          const models = await mgr.listModels();
          if (!models.length) { printInfo('暂无已安装模型'); return true; }
          printTable(
            ['模型', '大小', '参数量', '量化'],
            models.map(m => [m.name, m.size, m.paramSize || '-', m.quantization || '-'])
          );
          return true;
        }

        if (subCommand === 'pull') {
          const modelId = args[0];
          if (!modelId) { printError('用法: models pull <model-id>'); return true; }
          const running = await mgr.isOllamaRunning();
          if (!running) { printError('Ollama 未运行。请先执行: ollama serve'); return true; }
          printInfo(`开始下载: ${modelId}`);
          await mgr.pullModel(modelId, (progress) => {
            if (progress.total > 0 && process.stdout.isTTY) {
              process.stdout.write(`\r  ⟳ ${progress.status} ${progress.percent}%`);
            }
          });
          console.log('');
          printSuccess(`下载完成: ${modelId}`);
          return true;
        }

        if (subCommand === 'import') {
          const sourcePath = args[0];
          const modelName = args[1] || options.name || '';
          if (!sourcePath) {
            printError('用法: models import <path> [model-name] [--base qwen2.5:7b]');
            printInfo('支持: .gguf 文件 / safetensors 模型目录 / .safetensors adapter');
            return true;
          }
          const running = await mgr.isOllamaRunning();
          if (!running) { printError('Ollama 未运行。请先执行: ollama serve'); return true; }
          const result = await mgr.importModel(sourcePath, modelName, {
            base: options.base,
            systemPrompt: options.system,
            temperature: options.temperature,
            topP: options.top_p || options.topP,
            numCtx: options.num_ctx || options.numCtx,
          });
          if (!result.success) {
            printError(`导入失败: ${result.error}`);
            if (result.sourceKind === 'adapter') {
              printInfo('adapter 导入需要 --base，例如: models import ./adapter.safetensors mymodel --base qwen2.5:7b');
            }
            return true;
          }
          printSuccess(`导入成功: ${result.model} (${result.sourceKind})`);
          if (options.use || options.select) {
            setEnvVar('GATEWAY_PREFERRED_ADAPTER', 'ollama');
            setEnvVar('GATEWAY_PREFERRED_STRICT', 'true');
            setEnvVar('OLLAMA_MODEL', result.model);
            try {
              const gateway = require('../services/gateway/aiGateway');
              await gateway.refreshAdapters();
            } catch { /* best effort */ }
            printSuccess(`已切换为默认模型: ollama/${result.model}`);
          } else {
            printInfo(`可运行: models set ${result.model}`);
          }
          return true;
        }

        if (subCommand === 'set') {
          const modelId = args[0];
          if (!modelId) { printError('用法: models set <model-id>'); return true; }
          setEnvVar('GATEWAY_PREFERRED_ADAPTER', 'ollama');
          setEnvVar('GATEWAY_PREFERRED_STRICT', 'true');
          setEnvVar('OLLAMA_MODEL', modelId);
          try {
            const gateway = require('../services/gateway/aiGateway');
            await gateway.refreshAdapters();
          } catch { /* best effort */ }
          printSuccess(`已设置默认模型: ollama/${modelId}`);
          return true;
        }

        if (subCommand === 'delete') {
          const modelId = args[0];
          if (!modelId) { printError('用法: models delete <model-id>'); return true; }
          const running = await mgr.isOllamaRunning();
          if (!running) { printError('Ollama 未运行。请先执行: ollama serve'); return true; }
          const ok = await mgr.deleteModel(modelId);
          if (ok) printSuccess(`已删除模型: ${modelId}`);
          else printError(`删除失败: ${modelId}`);
          return true;
        }

        printError(`未知子命令: ${subCommand}`);
        printInfo('可用: models list|pull|import|delete|set');
        return true;
      }

      case 'khymodel': {
        const modelImport = require('../services/modelImportService');

        if (subCommand === 'list' || !subCommand) {
          printInfo('正在扫描所有模型...');
          const all = await modelImport.listAllModels();

          // KHY/Ollama imported models
          if (all.khyModels.length) {
            printSuccess(`KHY/Ollama 已导入模型 (${all.khyModels.length})`);
            printTable(
              ['模型', '大小', '架构', '量化', '来源'],
              all.khyModels.map(m => [m.name, m.size, m.family || '-', m.quantization || '-', m.source || 'ollama'])
            );
          } else {
            printInfo('KHY/Ollama 已导入模型: 无');
          }

          // Local model files
          if (all.localModels.length) {
            console.log('');
            printInfo(`本地模型文件 (${all.localModels.length})`);
            printTable(
              ['名称', '大小', '格式', '位置', '状态'],
              all.localModels.map(m => [
                m.name,
                m.sizeStr,
                m.format,
                m.location,
                m.imported ? '✓ 已导入' : '✗ 未导入',
              ])
            );
            const unimported = all.localModels.filter(m => !m.imported);
            if (unimported.length) {
              printInfo(`提示: ${unimported.length} 个模型未导入，可使用 khymodel import <序号> 或 models import <path> 导入`);
            }
          } else {
            printInfo('未发现本地模型文件');
          }

          // IDE models
          if (all.ideModels && all.ideModels.length) {
            console.log('');
            printInfo(`IDE 可用模型 (${all.ideModels.length})`);
            printTable(
              ['模型', '来源IDE', '路由地址'],
              all.ideModels.map(m => [m.name, m.source, m.route])
            );
            printInfo(`提示: 可通过 gateway proxy 将这些模型伪装为 OpenAI API (localhost:${process.env.PROXY_PORT || '9100'}/v1)`);
          }

          return true;
        }

        if (subCommand === 'import') {
          const sourcePath = args[0];
          if (!sourcePath) {
            printError('用法: khymodel import <path|url> [model-name]');
            printInfo('支持: .gguf / .safetensors / .zip / 模型目录 / 下载URL');
            return true;
          }
          printInfo(`正在导入: ${sourcePath}`);
          const result = await modelImport.importModel(sourcePath, { name: args[1] || '' });
          if (result.success) {
            printSuccess(`导入成功: ${result.model} (${result.sourceKind})`);
            if (result.steps) printInfo(`步骤: ${result.steps.join(' → ')}`);
          } else {
            printError(`导入失败: ${result.error}`);
            if (result.steps) printInfo(`步骤: ${result.steps.join(' → ')}`);
          }
          return true;
        }

        if (subCommand === 'export') {
          const modelName = args[0];
          if (!modelName) {
            printError('用法: khymodel export <ollama-model-name> [dest-dir]');
            printInfo('从 Ollama 导出模型到 KHY 本地模型目录');
            return true;
          }
          printInfo(`正在从 Ollama 导出: ${modelName}`);
          const result = await modelImport.exportFromOllama(modelName, args[1]);
          if (result.success) {
            printSuccess(`导出成功: ${result.path} (${result.sizeMB} MB)`);
          } else {
            printError(`导出失败: ${result.error}`);
          }
          return true;
        }

        if (subCommand === 'scan') {
          printInfo('正在扫描本地模型文件...');
          const localFiles = modelImport.discoverLocalModels();
          if (!localFiles.length) { printInfo('未发现模型文件'); return true; }
          printTable(
            ['名称', '大小', '格式', '位置', '路径'],
            localFiles.map(m => [
              m.name,
              m.sizeMB > 1024 ? `${(m.sizeMB / 1024).toFixed(1)} GB` : `${m.sizeMB} MB`,
              m.format,
              m.location,
              m.path.length > 60 ? '...' + m.path.slice(-57) : m.path,
            ])
          );
          return true;
        }

        printError(`未知子命令: ${subCommand}`);
        printInfo('可用: khymodel list|import|export|scan');
        return true;
      }

      case 'habit': {
        const habitSvc = require('../services/usageHabitService');

        if (subCommand === 'predict') {
          // Show predicted next commands
          const predictions = habitSvc.predictNextCommands(args.length > 0 ? args : ['help']);
          if (predictions.length === 0) {
            printInfo('暂无预测数据，继续使用系统积累更多习惯');
          } else {
            console.log(chalk.bold('\n  🔮 下一步预测'));
            for (const p of predictions) {
              const conf = Math.round(p.confidence * 100);
              console.log(`  ${chalk.cyan('→')} ${p.command} ${chalk.dim(`(${conf}% 置信度)`)}`);
            }
          }
          console.log('');
          return true;
        }

        // Default: show habit summary
        const summary = habitSvc.getHabitSummary();
        console.log(chalk.bold('\n  📊 使用习惯概况\n'));

        // Time profile
        if (summary.timeProfile.peakHours.length > 0) {
          console.log(`  活跃时段:    ${summary.timeProfile.peakHours.map(h => h + ':00').join(', ')}`);
        }
        console.log(`  平均会话:    ${summary.timeProfile.avgSession}`);
        console.log(`  总会话数:    ${summary.timeProfile.totalSessions}`);

        // Model ranking
        if (summary.modelRanking.length > 0) {
          console.log(chalk.bold('\n  🤖 模型使用排行'));
          for (const m of summary.modelRanking) {
            console.log(`  ${chalk.white(m.model)} — ${m.count} 次, 质量 ${chalk.green(m.quality)}`);
          }
        }

        // IDE usage
        if (summary.ideUsage.length > 0) {
          console.log(chalk.bold('\n  💻 IDE/适配器使用'));
          for (const ide of summary.ideUsage) {
            console.log(`  ${chalk.white(ide.ide)} — ${ide.count} 次`);
          }
        }

        // Top workflows
        if (summary.topWorkflows.length > 0) {
          console.log(chalk.bold('\n  ⚡ 常用工作流'));
          for (const w of summary.topWorkflows) {
            console.log(`  ${chalk.dim(w.workflow)} — ${w.count} 次`);
          }
        }

        // Topic focus
        if (summary.topics.length > 0) {
          console.log(chalk.bold('\n  📈 关注话题'));
          const trendIcon = { rising: '🔺', stable: '➖', declining: '🔻' };
          for (const t of summary.topics) {
            console.log(`  ${trendIcon[t.trend] || '·'} ${t.topic} — ${t.count} 次`);
          }
        }

        // Response preferences
        console.log(chalk.bold('\n  🎯 回复偏好'));
        console.log(`  长度: ${summary.responseStyle.preferredLength}  细节: ${summary.responseStyle.detailLevel}`);
        console.log(`  显示费用: ${summary.responseStyle.showCost ? '是' : '否'}  显示知识: ${summary.responseStyle.showTips ? '是' : '否'}`);

        console.log('');
        printInfo('输入 habit predict <上一个命令> 预测下一步');
        console.log('');
        return true;
      }

      // ── Cleanup ──
      case 'cleanup': {
        const cleanup = require('../services/cleanupService');
        if (subCommand === 'status') {
          const report = cleanup.getStorageReport();
          const last = typeof cleanup.getLastCleanupReport === 'function'
            ? cleanup.getLastCleanupReport()
            : null;
          console.log(chalk.bold('\n  🧹 存储空间使用\n'));
          console.log(`  安全日志:       ${chalk.white(cleanup.humanSize(report.securityLog.size))}`);
          console.log(`  日志归档:       ${chalk.white(cleanup.humanSize(report.securityLogArchives.size))}`);
          console.log(`  成长快照:       ${chalk.white(cleanup.humanSize(report.growthSnapshots.size))} (${report.growthSnapshots.count} 个)`);
          console.log(`  训练数据:       ${chalk.white(cleanup.humanSize(report.trainingData.size))}`);
          console.log(`  遥测导出:       ${chalk.white(cleanup.humanSize(report.telemetry.size))} (${report.telemetry.count} 个)`);
          console.log(`  对话记录:       ${chalk.white(cleanup.humanSize(report.conversations.size))} (${report.conversations.count} 个)`);
          console.log(chalk.dim('  ' + '─'.repeat(30)));
          console.log(`  总计:           ${chalk.bold(report.totalHuman)}`);
          if (last) {
            const triggerLabel = {
              manual: '手动执行',
              startup: '启动预取任务',
              periodic: '周期任务',
            }[String(last.trigger || '')] || String(last.trigger || 'unknown');
            console.log(chalk.bold('\n  最近一次清理\n'));
            console.log(`  触发来源:       ${chalk.white(triggerLabel)}`);
            console.log(`  处理目标:       ${chalk.white(`${last.targetCount || 0}/${last.targetCount || 0}`)} (失败 ${last.failureCount || 0})`);
            console.log(`  执行耗时:       ${chalk.white(`${last.elapsedMs || 0} ms`)}`);
            console.log(`  释放空间:       ${chalk.white(last.freedHuman || '0 B')}`);
            if (Array.isArray(last.targets) && last.targets.length > 0) {
              console.log(chalk.dim('\n  目标进度:'));
              last.targets.forEach((target, idx) => {
                const state = target.ok ? '成功' : '失败';
                const removed = typeof target.removed === 'number' ? `, 删除 ${target.removed} 项` : '';
                const reclaimed = typeof target.bytes === 'number' ? `, 释放 ${cleanup.humanSize(target.bytes)}` : '';
                const errText = target.ok ? '' : `, 错误 ${target.error || 'unknown'}`;
                console.log(`    ${idx + 1}/${last.targets.length} ${target.name}（${state}, ${target.elapsedMs || 0}ms${removed}${reclaimed}${errText}）`);
              });
            }
          }
          console.log(chalk.dim('\n  运行 cleanup 执行清理'));
          console.log('');
        } else {
          printInfo('执行存储清理（阶段 1/1，目标：安全日志、快照、训练数据、遥测、temp、logs、data/cache、ml/data/cache、系统临时目录）');
          const result = cleanup.runCleanup();
          if (result.summary.actions.length === 0) {
            printSuccess('所有数据在限额内，无需清理');
          } else {
            for (const action of result.summary.actions) {
              printSuccess(action);
            }
            printInfo(`释放空间: ${result.summary.freedHuman}`);
          }
          if (result.summary) {
            printInfo(`清理进度: ${result.summary.targetCount || 0}/${result.summary.targetCount || 0}，失败 ${result.summary.failureCount || 0}，耗时 ${result.summary.elapsedMs || 0}ms`);
          }
        }
        return true;
      }

      // ── Memory / khy.md ──
      case 'memory': {
        const instructionSvc = require('../services/instructionFileService');
        const summary = instructionSvc.getInstructionSummary();
        const LEVEL_LABELS = { global: '全局', project: '项目', directory: '目录' };

        console.log(chalk.bold('\n  📋 khy.md 指令文件\n'));
        if (summary.length === 0) {
          printInfo('未找到任何 khy.md 文件');
          console.log(chalk.dim(`\n  创建指令文件以定制 AI 行为:`));
          console.log(chalk.dim(`    ~/.khyquant/khy.md    — 全局指令 (所有项目通用)`));
          console.log(chalk.dim(`    <项目>/khy.md         — 项目级指令`));
          console.log(chalk.dim(`    <当前目录>/khy.md     — 目录级指令`));
        } else {
          for (const file of summary) {
            const label = LEVEL_LABELS[file.level] || file.level;
            const truncWarning = file.truncated ? chalk.yellow(' (截断)') : '';
            console.log(`  ${chalk.cyan(`[${label}]`)} ${file.path} ${chalk.dim(`(${file.size} 字符)`)}${truncWarning}`);
          }
          console.log(chalk.dim(`\n  限制: 单文件 ${instructionSvc.MAX_FILE_CHARS} 字符, 合计 ${instructionSvc.MAX_TOTAL_CHARS} 字符`));
        }
        console.log('');
        return true;
      }

      // ── Auth Commands ──
      case 'login': {
        const cliAuth = require('../services/cliAuthService');
        const inquirer = require('inquirer');
        const session = cliAuth.checkSession();
        const serverToken = (typeof cliAuth.getSessionAuthToken === 'function')
          ? String(cliAuth.getSessionAuthToken() || '').trim()
          : '';

        if (session.loggedIn && serverToken) {
          printInfo(`已登录: ${session.username}`);
          return true;
        }

        if (session.loggedIn && !serverToken) {
          printInfo(`当前账号 ${session.username} 为本地离线登录态。`);
          printInfo('继续执行 /login 可补充服务端登录，用于 khyguanli 自动免登录。');
        }

        const answers = await inquirer.prompt([
          {
            type: 'input',
            name: 'username',
            message: '用户名:',
            default: session.loggedIn ? (session.username || '') : '',
            validate: v => v.trim().length > 0 || '请输入用户名',
          },
          { type: 'password', name: 'password', message: '密码:', mask: '*', validate: v => v.length > 0 || '请输入密码' },
        ]);
        const result = await cliAuth.login(answers.username, answers.password);
        if (result.success) {
          const syncedToken = (typeof cliAuth.getSessionAuthToken === 'function')
            ? String(cliAuth.getSessionAuthToken() || '').trim()
            : '';
          printSuccess(`登录成功! 欢迎回来, ${result.username}`);
          if (syncedToken) {
            printInfo('已获得服务端登录态，可用于 khyguanli 自动免登录。');
          } else {
            printInfo('当前仍为本地离线登录态，管理页将进入登录页。');
          }
        } else {
          printError(result.error);
        }
        return true;
      }

      case 'register': {
        const cliAuth = require('../services/cliAuthService');
        const inquirer = require('inquirer');
        if (cliAuth.isRegistered()) {
          printInfo('本机已有注册账号。如需重置请删除 ~/.khyquant/credentials.json');
          return true;
        }
        const answers = await inquirer.prompt([
          { type: 'input', name: 'username', message: '用户名 (至少 2 字符):', validate: v => v.trim().length >= 2 || '至少 2 个字符' },
          { type: 'password', name: 'password', message: '设置密码 (至少 6 字符):', mask: '*', validate: v => v.length >= 6 || '至少 6 个字符' },
          { type: 'password', name: 'confirm', message: '确认密码:', mask: '*', validate: (v, a) => v === a.password || '两次密码不一致' },
          { type: 'input', name: 'email', message: '邮箱 (可选):', default: '' },
        ]);
        const result = await cliAuth.register(answers.username, answers.password, answers.email || undefined);
        if (result.success) printSuccess(`注册成功! 欢迎, ${result.username}`);
        else printError(result.error);
        return true;
      }

      case 'logout': {
        const cliAuth = require('../services/cliAuthService');
        cliAuth.logout();
        printSuccess('已退出登录');
        printInfo('下次启动时需要重新登录');
        return true;
      }

      // ── Self-Awareness (自知 + 他知) ──
      case 'self': {
        const selfProfileService = require('../services/selfProfile');
        const profile = selfProfileService.getFullProfile({ cwd: process.cwd() });

        if (flags.includes('--json')) {
          console.log(JSON.stringify(selfProfileService.formatForAPI(profile), null, 2));
        } else if (flags.includes('--brief')) {
          console.log('\n  ' + selfProfileService.formatBrief(profile) + '\n');
        } else if (subCommand === 'capabilities') {
          const domains = profile.capabilityDomains || {};
          console.log(chalk.cyan.bold('\n  khy OS 能力域\n'));
          for (const [key, domain] of Object.entries(domains)) {
            console.log(`  ${chalk.bold(domain.summary)}`);
            console.log(`  ${chalk.dim(domain.description)}`);
            if (domain.providers) console.log(`  ${chalk.dim('providers: ' + domain.providers.join(', '))}`);
            if (domain.features) console.log(`  ${chalk.dim('features: ' + (Array.isArray(domain.features) ? domain.features.join(', ') : domain.features))}`);
            if (domain.modes) console.log(`  ${chalk.dim('modes: ' + (Array.isArray(domain.modes) ? domain.modes.join(', ') : domain.modes))}`);
            if (domain.abis) console.log(`  ${chalk.dim('ABIs: ' + domain.abis.join(', '))}`);
            console.log('');
          }
        } else if (subCommand === 'boundaries') {
          console.log(chalk.cyan.bold('\n  khy OS 能力边界\n'));
          (profile.boundaries || []).forEach((b, i) => {
            console.log(`  ${i + 1}. ${chalk.bold(b.short)}`);
            console.log(`     ${chalk.dim(b.detail)}`);
          });
          console.log('');
        } else if (subCommand === 'runtime') {
          const rt = profile.runtime?.runtime || {};
          const gw = profile.runtime?.gateway || {};
          const llm = profile.runtime?.localLLM || {};
          console.log(chalk.cyan.bold('\n  khy OS 运行时状态\n'));
          console.log(`  平台:      ${chalk.white(rt.platform)}`);
          console.log(`  Node:      ${chalk.white(rt.nodeVersion)}`);
          console.log(`  Python:    ${chalk.white(rt.pythonVersion)}`);
          console.log(`  工作目录:  ${chalk.white(rt.cwd)}`);
          console.log(`  通道:      ${chalk.white((gw.currentAdapter || 'auto') + ' / ' + (gw.currentModel || 'auto'))}`);
          console.log(`  本地推理:  ${chalk.white(llm.status + (llm.backend ? ' (' + llm.backend + ')' : ''))}`);
          console.log(`  模式:      ${chalk.white(rt.studyMode ? '学习模式' : '普通模式')}`);
          console.log('');
        } else {
          // Default: full human-readable profile
          console.log('');
          console.log(selfProfileService.formatForHuman(profile));
          console.log('');
        }
        return true;
      }

      case 'whoami': {
        const cliAuth = require('../services/cliAuthService');
        const user = cliAuth.getCurrentUser();
        if (!user) {
          printInfo('当前未登录');
        } else {
          console.log('');
          console.log(chalk.cyan.bold('  👤 当前用户'));
          console.log(chalk.dim('  ' + '─'.repeat(30)));
          console.log(`  用户名:   ${chalk.bold(user.username)}`);
          if (user.email) console.log(`  邮箱:     ${chalk.dim(user.email)}`);
          console.log(`  注册时间: ${chalk.dim(new Date(user.registeredAt).toLocaleString('zh-CN'))}`);
          console.log(`  登录时间: ${chalk.dim(new Date(user.loginAt).toLocaleString('zh-CN'))}`);
          console.log(`  会话到期: ${chalk.dim(new Date(user.sessionExpires).toLocaleString('zh-CN'))}`);
          console.log('');
        }
        return true;
      }

      case 'passwd': {
        const cliAuth = require('../services/cliAuthService');
        const inquirer = require('inquirer');
        const answers = await inquirer.prompt([
          { type: 'password', name: 'oldPassword', message: '当前密码:', mask: '*', validate: v => v.length > 0 || '请输入当前密码' },
          { type: 'password', name: 'newPassword', message: '新密码 (至少 6 字符):', mask: '*', validate: v => v.length >= 6 || '至少 6 个字符' },
          { type: 'password', name: 'confirm', message: '确认新密码:', mask: '*', validate: (v, a) => v === a.newPassword || '两次密码不一致' },
        ]);
        const result = await cliAuth.changePassword(answers.oldPassword, answers.newPassword);
        if (result.success) printSuccess('密码修改成功');
        else printError(result.error);
        return true;
      }

      case 'forgot': {
        const cliAuth = require('../services/cliAuthService');
        const inquirer = require('inquirer');

        const { method } = await inquirer.prompt([{
          type: 'list',
          name: 'method',
          message: '选择找回方式:',
          choices: [
            { name: '密保问题找回', value: 'security_question' },
            { name: '邮箱验证码找回', value: 'email' },
            { name: '手机验证码找回', value: 'phone' },
          ],
        }]);

        if (method === 'security_question') {
          const { username } = await inquirer.prompt([
            { type: 'input', name: 'username', message: '用户名:', validate: v => v.trim().length > 0 || '请输入用户名' },
          ]);
          const qResult = await cliAuth.getSecurityQuestion(username);
          if (!qResult.success) { printError(qResult.error); return true; }

          printInfo(`密保问题: ${qResult.question}`);
          const recovery = await inquirer.prompt([
            { type: 'input', name: 'answer', message: '密保答案:', validate: v => v.trim().length > 0 || '请输入答案' },
            { type: 'password', name: 'newPassword', message: '新密码 (至少 6 字符):', mask: '*', validate: v => v.length >= 6 || '至少 6 个字符' },
            { type: 'password', name: 'confirm', message: '确认新密码:', mask: '*', validate: (v, a) => v === a.newPassword || '两次密码不一致' },
          ]);
          const resetResult = await cliAuth.resetPasswordWithSecurityAnswer(username, recovery.answer, recovery.newPassword);
          if (resetResult.success) printSuccess('密码重置成功! 请使用新密码登录');
          else printError(resetResult.error);

        } else {
          const label = method === 'phone' ? '手机号' : '邮箱';
          const { target } = await inquirer.prompt([
            { type: 'input', name: 'target', message: `注册时的${label}:`, validate: v => v.trim().length >= 3 || `请输入有效${label}` },
          ]);
          printInfo('正在发送验证码...');
          const sendResult = await cliAuth.requestVerificationCode(method, target);
          if (!sendResult.success) { printError(sendResult.error); return true; }
          printSuccess(sendResult.message);

          const recovery = await inquirer.prompt([
            { type: 'input', name: 'code', message: '验证码:', validate: v => v.trim().length >= 4 || '请输入验证码' },
            { type: 'password', name: 'newPassword', message: '新密码 (至少 6 字符):', mask: '*', validate: v => v.length >= 6 || '至少 6 个字符' },
            { type: 'password', name: 'confirm', message: '确认新密码:', mask: '*', validate: (v, a) => v === a.newPassword || '两次密码不一致' },
          ]);
          const resetResult = await cliAuth.resetPasswordWithVerificationCode(method, target, recovery.code, recovery.newPassword);
          if (resetResult.success) printSuccess('密码重置成功! 请使用新密码登录');
          else printError(resetResult.error);
        }
        return true;
      }

      // ── New Systems (Claude Code ports) ──────────────────────────
      case 'buddy': {
        const { handleBuddyCommand } = require('../buddy');
        await handleBuddyCommand(subCommand, args, options);
        return true;
      }

      case 'coordinator': {
        const coord = require('../coordinator/coordinatorMode');
        if (subCommand === 'on') { coord.activateCoordinatorMode(); printInfo('Coordinator mode activated.'); }
        else if (subCommand === 'off') { coord.deactivateCoordinatorMode(); printInfo('Coordinator mode deactivated.'); }
        else if (subCommand === 'status') { printInfo(`Coordinator mode: ${coord.isCoordinatorMode() ? 'ON' : 'OFF'}`); }
        else if (subCommand === 'board') {
          const taskBoard = require('../coordinator/taskBoard');
          const tasks = taskBoard.listTasks();
          const counts = { pending: 0, claimed: 0, completed: 0, failed: 0 };
          for (const task of tasks) {
            if (Object.prototype.hasOwnProperty.call(counts, task.status)) {
              counts[task.status] += 1;
            }
          }

          console.log(chalk.bold('\n  Coordinator Task Board'));
          console.log(`  Total:     ${tasks.length}`);
          console.log(`  Pending:   ${counts.pending}`);
          console.log(`  Claimed:   ${counts.claimed}`);
          console.log(`  Completed: ${counts.completed}`);
          console.log(`  Failed:    ${counts.failed}`);

          if (tasks.length === 0) {
            printInfo('任务板暂无任务');
          } else {
            console.log('');
            printTable(
              ['ID', '状态', '优先级', '负责人', '描述'],
              tasks.slice(0, 20).map((task) => [
                task.id || '-',
                task.status || '-',
                task.priority || 'medium',
                task.assignee || '-',
                task.description || '-',
              ])
            );
            if (tasks.length > 20) {
              printInfo(`仅显示前 20 条任务，共 ${tasks.length} 条`);
            }
          }
        } else { printInfo('Usage: coordinator [on|off|status|board]'); }
        return true;
      }

      case 'daemon': {
        const { handleDaemon } = require('./handlers/daemon');
        await handleDaemon(subCommand, { chalk: chk(), options });
        return true;
      }

      case 'arena': {
        const { handleArena } = require('./handlers/arena');
        await handleArena(subCommand, { chalk: chk(), options });
        return true;
      }

      case 'remote': {
        const { handleRemote } = require('./handlers/remote');
        await handleRemote(subCommand, { chalk: chk(), options });
        return true;
      }

      case 'assistant':
      case 'brief': {
        const { handleAssistantCommand } = require('./handlers/assistant');
        const sub = command === 'brief' ? 'brief' : subCommand;
        await handleAssistantCommand(sub, args, options);
        return true;
      }

      case 'ultraplan': {
        const { handleUltraplanCommand, handleUltraplanStatus } = require('./handlers/ultraplan');
        if (subCommand === 'status' || subCommand === 'list') {
          await handleUltraplanStatus();
        } else {
          await handleUltraplanCommand(args, options);
        }
        return true;
      }

      case 'ulw-loop': {
        const task = args.join(' ').trim();
        if (!task) {
          printInfo('用法: /ulw-loop <任务描述>');
          printInfo('示例: /ulw-loop 修复 gateway 重试逻辑并补测试');
          return true;
        }
        return {
          aiForward: `ultrawork\n\n${task}`,
        };
      }

      case 'bridge': {
        const bridgeSrv = require('../bridge/bridgeServer');
        if (subCommand === 'start') { await bridgeSrv.startBridgeServer(); }
        else if (subCommand === 'stop') { await bridgeSrv.stopBridgeServer(); }
        else if (subCommand === 'status') { bridgeSrv.printStatus(); }
        else if (subCommand === 'token') { bridgeSrv.printToken(); }
        else { printInfo('Usage: bridge [start|stop|status|token]'); }
        return true;
      }

      default: {
        // Handle /huifu shortcut for context resume
        if (command === '/huifu' || command === '/恢复' || command === '/resume') {
          const ai = require('./ai');
          const result = ai.resumeConversation();
          if (result.success) {
            printSuccess(`已恢复上次对话 (${result.messageCount} 条消息, ${new Date(result.timestamp).toLocaleString('zh-CN')})`);
            printInfo('AI 已具有之前的对话上下文，继续提问即可');
          } else {
            printInfo('暂无可恢复的对话记录');
          }
          return true;
        }

        // Handle /cost shortcut
        if (command === '/cost' || command === '/费用') {
          const tokenSvc = require('../services/tokenUsageService');
          console.log(tokenSvc.formatCostReport());
          return true;
        }

        // Handle /memory shortcut
        if (command === '/memory' || command === '/指令' || command === '/khy') {
          // Delegate to the 'memory' command
          return route({ command: 'memory', subCommand: null, args: [], options: {}, rawInput: command }, context);
        }

        // Check if input is a skill trigger (e.g., /analyze)
        const rawToken = (parsed.rawCommandToken || String(parsed.rawInput || '').split(/\s+/)[0] || '').trim();
        if (rawToken.startsWith('/')) {
          const skillRegistry = require('../services/skillRegistry');
          const skill = skillRegistry.findSkillByTrigger(rawToken);
          if (skill) {
            const result = await skillRegistry.executeSkill(skill.id, args, { options });
            if (result && result.type === 'ai-prompt') {
              return { aiForward: result.prompt };
            }
            return true;
          }
        }

        // Try SDK plugins (formal khy-* plugins registered via plugin-loader)
        const cmdRegistry = require('./commandRegistry');
        const sdkCmd = cmdRegistry.getAll().find(c =>
          c._pluginHandler && (c.cmd === `/${command}` || (c._aliases && c._aliases.includes(command)))
        );
        if (sdkCmd && sdkCmd._pluginHandler) {
          const parsedArgs = { raw: parsed.rawInput || '', positional: args, flags: options };
          const cmdContext = {
            print: (text) => console.log(text),
            printStyled: (text) => console.log(text),
            prompt: async (msg) => { const readline = require('readline'); const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return new Promise(r => rl.question(msg, a => { rl.close(); r(a); })); },
            spinner: (msg) => { const ora = require('ora'); const s = ora(msg).start(); return { update: (m) => { s.text = m; }, succeed: (m) => s.succeed(m), fail: (m) => s.fail(m), stop: () => s.stop() }; },
            cwd: process.cwd(),
          };
          try {
            await sdkCmd._pluginHandler(parsedArgs, cmdContext);
          } catch (err) {
            fmt().printError(`Plugin command error: ${err.message}`);
          }
          return true;
        }

        // Try user plugins
        const pluginHandled = await plugins().tryPlugin(command, args, options);
        if (pluginHandled) return true;

        // ── G1/G2 拼写纠错 + 模糊命令建议 ──────────────────────
        // 仅对看起来像命令的输入触发（非中文自然语言、非长句子）
        const rawForFuzzy = (parsed.rawInput || '').trim();
        const looksLikeCommand = rawForFuzzy.length <= 30
          && !/[\u4e00-\u9fff]{3,}/.test(rawForFuzzy)  // 排除中文长句
          && /^[a-zA-Z\/]/.test(rawForFuzzy);           // 以英文或 / 开头
        if (looksLikeCommand) {
          const suggestions = _findClosestCommands(rawForFuzzy);
          if (suggestions.length > 0) {
            if (suggestions.length === 1 && suggestions[0].dist <= 1) {
              // 距离 ≤1，直接提示单个候选
              printWarn(`未知命令 "${rawForFuzzy}"，你是否想执行 "${suggestions[0].label}"？`);
              try {
                const inquirer = require('inquirer');
                const { confirm } = await inquirer.prompt([{
                  type: 'confirm', name: 'confirm',
                  message: `执行 "${suggestions[0].label}"？`, default: true,
                }]);
                if (confirm) {
                  const reParsed = parseInput(suggestions[0].label + ' ' + args.join(' '));
                  if (reParsed) return route(reParsed, context);
                }
              } catch { /* 用户取消或 stdin 异常，fall through to AI */ }
            } else {
              // 多个候选，列表选择
              printWarn(`未知命令 "${rawForFuzzy}"，你是否想执行以下命令？`);
              try {
                const inquirer = require('inquirer');
                const choices = suggestions.map(s => ({ name: s.label, value: s.label }));
                choices.push({ name: '不，发送给 AI', value: '__ai__' });
                const { picked } = await inquirer.prompt([{
                  type: 'list', name: 'picked',
                  message: '选择命令:', choices,
                }]);
                if (picked !== '__ai__') {
                  const reParsed = parseInput(picked + ' ' + args.join(' '));
                  if (reParsed) return route(reParsed, context);
                }
              } catch { /* fall through to AI */ }
            }
          }
        }

        // ── G10/G8 意图预分类 + 澄清 ──────────────────────────
        // 对自然语言短输入尝试匹配命令路由
        try {
          const { matchIntentRoutes, clarifyIntent } = require('../services/inputPreprocessor');
          const intentMatches = matchIntentRoutes(rawForFuzzy);
          if (intentMatches.length === 1) {
            // 单一匹配 — 直接跳转
            printInfo(`检测到意图: ${intentMatches[0].label}，已跳转`);
            const reParsed = parseInput(intentMatches[0].route);
            if (reParsed) return route(reParsed, context);
          } else if (intentMatches.length >= 2) {
            // 多义匹配 — G8 澄清 + 超时降级
            const chosen = await clarifyIntent(intentMatches, rawForFuzzy);
            if (chosen && chosen.route) {
              const reParsed = parseInput(chosen.route);
              if (reParsed) return route(reParsed, context);
            }
            // chosen === null → 用户选择发送给 AI，fall through
          }
        } catch { /* best effort, fall through to AI */ }

        return false; // → AI
      }
    }
  } catch (err) {
    printError(err.message || '命令执行失败');
    return true;
  }
}

/**
 * Get auto-complete suggestions for partial input.
 */
function getCompletions(partial) {
  const parts = partial.split(/\s+/);
  const allKeys = [...COMMANDS, ...aliases().getAllAliasKeys()];

  // Slash command completion (delegate to commandRegistry if available)
  if (parts[0].startsWith('/')) {
    const slashPartial = parts[0].toLowerCase();
    try {
      const cmdReg = require('./commandRegistry');
      return cmdReg.getCompletions(slashPartial);
    } catch { /* fallback */ }
    return SLASH_COMMANDS
      .filter(sc => sc.cmd.startsWith(slashPartial))
      .map(sc => sc.cmd);
  }

  const unique = [...new Set(allKeys)];

  if (parts.length <= 1) {
    return unique.filter(c => c.startsWith(parts[0].toLowerCase()));
  }

  const cmd = parts[0].toLowerCase();
  // Resolve alias to find sub-commands
  const alias = aliases().resolveAlias(cmd);
  const canonicalCmd = alias ? alias.command : cmd;
  const sub = parts[1] || '';

  if (SUB_COMMANDS[canonicalCmd]) {
    return SUB_COMMANDS[canonicalCmd]
      .filter(s => s.startsWith(sub.toLowerCase()))
      .map(s => `${parts[0]} ${s}`);
  }

  return [];
}

// ── Slash Command Registry (Claude Code style) ────────────────────────

const _STATIC_SLASH_COMMANDS = getStaticSlashCommands();

// Dynamic SLASH_COMMANDS: prefer commandRegistry, fallback to static
let SLASH_COMMANDS;
try {
  const cmdReg = require('./commandRegistry');
  SLASH_COMMANDS = cmdReg.toSlashCommands();
} catch {
  SLASH_COMMANDS = _STATIC_SLASH_COMMANDS;
}

module.exports = { parseInput, route, getCompletions, COMMANDS, SLASH_COMMANDS };
