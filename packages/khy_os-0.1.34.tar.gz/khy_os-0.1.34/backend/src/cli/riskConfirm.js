/**
 * Risk Confirm — 风险分级交互确认（G3）
 *
 * 三级策略：
 *   safe/moderate/unknown → 静默放行
 *   dangerous → 单次 Y/n 确认，显示影响摘要
 *   critical  → 两步确认：摘要 + 输入确认词
 *
 * 仅在 CLI 交互模式（TTY）下使用。非 TTY 环境退化为拒绝。
 */
const chalk = require('chalk');

/**
 * 根据命令风险等级执行交互式确认。
 *
 * @param {object} params
 * @param {string} params.command   — 待执行的原始命令
 * @param {string} params.tier      — 风险等级 (safe|moderate|dangerous|critical|unknown)
 * @param {string} [params.matchedRule] — 触发的分类规则
 * @param {string} [params.impact]  — 额外的影响描述（调用方可选提供）
 * @returns {Promise<{approved: boolean, scope?: string}>}
 */
async function confirmRisk({ command, tier, matchedRule, impact }) {
  // 安全/中等/未知 → 直接放行
  if (!tier || tier === 'safe' || tier === 'moderate' || tier === 'unknown') {
    return { approved: true, scope: 'auto' };
  }

  // 非 TTY 环境不做交互，拒绝危险操作
  if (!process.stdin.isTTY) {
    return { approved: false, scope: 'non-tty' };
  }

  const cmdDisplay = String(command || '').length > 80
    ? command.slice(0, 77) + '...'
    : command;

  const ruleHint = matchedRule ? chalk.dim(` (规则: ${matchedRule})`) : '';

  if (tier === 'dangerous') {
    // ── 单次确认 ──
    console.log('');
    console.log(chalk.yellow.bold('  ⚠ 危险操作确认'));
    console.log(chalk.yellow(`  命令: ${cmdDisplay}`) + ruleHint);
    if (impact) console.log(chalk.yellow(`  影响: ${impact}`));
    console.log('');

    try {
      const inquirer = require('inquirer');
      const { ok } = await inquirer.prompt([{
        type: 'confirm',
        name: 'ok',
        message: '确认执行此命令？',
        default: false,
      }]);
      return { approved: ok, scope: 'dangerous_confirm' };
    } catch {
      return { approved: false, scope: 'cancelled' };
    }
  }

  if (tier === 'critical') {
    // ── 两步确认 ──
    console.log('');
    console.log(chalk.red.bold('  ⛔ 高危操作 — 需要两步确认'));
    console.log(chalk.red(`  命令: ${cmdDisplay}`) + ruleHint);
    if (impact) console.log(chalk.red(`  影响: ${impact}`));
    console.log(chalk.red('  此操作可能导致不可逆的系统级更改。'));
    console.log('');

    try {
      const inquirer = require('inquirer');
      // 第一步：理解风险
      const { understand } = await inquirer.prompt([{
        type: 'confirm',
        name: 'understand',
        message: '我已了解以上风险，继续？',
        default: false,
      }]);
      if (!understand) return { approved: false, scope: 'critical_step1_rejected' };

      // 第二步：输入确认词
      const confirmWord = 'CONFIRM';
      const { typed } = await inquirer.prompt([{
        type: 'input',
        name: 'typed',
        message: `请输入 "${confirmWord}" 确认执行:`,
      }]);
      const approved = typed.trim().toUpperCase() === confirmWord;
      if (!approved) {
        console.log(chalk.dim('  已取消。'));
      }
      return { approved, scope: 'critical_confirm' };
    } catch {
      return { approved: false, scope: 'cancelled' };
    }
  }

  // 兜底
  return { approved: false, scope: 'unknown_tier' };
}

module.exports = { confirmRisk };
