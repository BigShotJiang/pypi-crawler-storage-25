'use strict';

/**
 * Session Command Handler — search and manage session history.
 *
 * Commands:
 *   session search <query>    — full-text search across sessions
 *   session stats             — search index statistics
 *
 * @module handlers/session
 */
const chalk = require('chalk').default || require('chalk');
const { printInfo, printError } = require('../formatters');

async function handleSessionCommand(subCommand, args, options) {
  switch (subCommand) {
    case 'search':
      return handleSessionSearch(args, options);
    case 'stats':
      return handleSessionStats();
    case 'help':
    default:
      return _printHelp();
  }
}

function handleSessionSearch(args, options) {
  const query = args.join(' ').trim();
  if (!query) {
    printError('Usage: session search <query>');
    return;
  }

  const searchIndex = require('../../services/sessionSearchIndex');
  searchIndex.init();

  if (!searchIndex.isAvailable()) {
    printError('Search index unavailable (better-sqlite3 not installed).');
    return;
  }

  const limit = options.limit ? parseInt(options.limit, 10) : 20;
  const results = searchIndex.searchMessages(query, { limit });

  if (results.length === 0) {
    printInfo(`No results for "${query}".`);
    return;
  }

  console.log('');
  console.log(chalk.bold(`  Search Results (${results.length} matches)`));
  console.log('');

  for (const r of results) {
    const session = r.title || r.sessionId;
    const snippet = r.content.length > 120 ? r.content.slice(0, 117) + '...' : r.content;
    console.log(`  ${chalk.cyan(session)} ${chalk.dim('[' + r.role + ']')}`);
    console.log(`    ${snippet}`);
    console.log('');
  }
}

function handleSessionStats() {
  const searchIndex = require('../../services/sessionSearchIndex');
  searchIndex.init();

  const stats = searchIndex.getStats();

  console.log('');
  console.log(chalk.bold('  Session Search Index'));
  console.log('');
  console.log(`  Available  : ${stats.available ? chalk.green('yes') : chalk.dim('no')}`);
  console.log(`  Sessions   : ${stats.totalSessions}`);
  console.log(`  Messages   : ${stats.totalMessages}`);
  console.log(`  DB Size    : ${(stats.dbSizeBytes / 1024).toFixed(1)} KB`);
  console.log('');
}

function _printHelp() {
  console.log('');
  console.log(chalk.bold('  Session — Search and manage conversation history'));
  console.log('');
  console.log('  Usage:');
  console.log(chalk.dim('    session search <query>    Full-text search across sessions'));
  console.log(chalk.dim('    session stats             Search index statistics'));
  console.log('');
  console.log('  Examples:');
  console.log(chalk.dim('    session search "backtest strategy"'));
  console.log(chalk.dim('    session search 量化策略'));
  console.log('');
}

module.exports = { handleSessionCommand };
