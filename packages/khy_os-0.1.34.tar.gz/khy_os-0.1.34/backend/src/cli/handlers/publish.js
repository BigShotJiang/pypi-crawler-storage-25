'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');
const inquirer = require('inquirer');
const { findPython } = require('../../utils/pythonPath');
const {
  printError, printInfo, printSuccess, printWarn,
} = require('../formatters');

const HEARTBEAT_MS_DEFAULT = 10000;
const DIST_NAME_PATTERN = /\.whl$|\.tar\.gz$/i;
const PYPROJECT_PATH = 'pyproject.toml';
const PYTHON_INIT_PATH = path.join('khy_quant', '__init__.py');
const BACKEND_PKG_PATH = path.join('backend', 'package.json');
const DOCKER_BUNDLE_DEFAULT_OUT_DIR = path.join('dist', 'docker-bundles');
const ORIGIN_CODE_DEFAULT_OUT_DIR = path.join('dist', 'origin-code');
const DOCKER_BUNDLE_ACTIONS = new Set(['docker-bundle', 'bundle-docker', 'docker']);
const PIP_INSTALL_BUNDLE_ACTIONS = new Set(['pip-dir-bundle', 'bundle-pip', 'pip-bundle', 'pipdir']);
const NPM_INSTALL_BUNDLE_ACTIONS = new Set(['npm-dir-bundle', 'bundle-npm', 'npm-bundle', 'npmdir']);
const ORIGIN_CODE_ACTIONS = new Set(['origin-code', 'restore-origin', 'origin']);
const GIT_PUSH_ACTIONS = new Set(['git-push', 'push-git', 'push']);
const SELF_FIX_ACTIONS = new Set(['self-fix', 'self-bugfix', 'autofix']);
const SELF_PUBLISH_ACTIONS = new Set(['self-pypi', 'self-testpypi', 'self-release']);
const DOCKER_BUNDLE_SKIP_NAMES = new Set([
  'node_modules', '.git', '.khy-runtime', '.cache',
  'coverage', 'dist', 'tests', '_build', '.github', '.githooks',
  'NUL', '.DS_Store',
]);
const PIP_INSTALL_BUNDLE_SKIP_NAMES = new Set([
  ...DOCKER_BUNDLE_SKIP_NAMES,
  '__pycache__', '.pytest_cache', '.mypy_cache',
]);
const SUPPORTED_GIT_PLATFORMS = new Set(['github', 'gitee', 'gitlab']);
const SOURCE_RELEASE_SECRET_ENV_KEYS = ['KHY_SOURCE_PUBLISH_SECRET', 'KHY_OWNER_SECRET'];

function _toInt(value, fallback, min = 1) {
  const n = parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(n) || n < min) return fallback;
  return n;
}

function _formatDuration(ms) {
  const sec = Math.max(1, Math.floor(ms / 1000));
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m > 0 && s > 0) return `${m}m ${s}s`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

function _markFailure() {
  if (!process.exitCode || process.exitCode === 0) {
    process.exitCode = 1;
  }
}

function _isTruthyFlag(value) {
  return value === true || ['1', 'true', 'yes', 'on'].includes(String(value || '').trim().toLowerCase());
}

function _pickFirstNonEmpty(values = []) {
  for (const value of values) {
    const normalized = String(value || '').trim();
    if (normalized) return normalized;
  }
  return '';
}

function _readSourceReleaseSecret(options = {}) {
  const direct = _pickFirstNonEmpty([
    options.secret,
    options['owner-secret'],
    options.ownerSecret,
    options['study-secret'],
    options.studySecret,
    options.pwd,
    options.password,
  ]);
  if (direct) return direct;

  for (const key of SOURCE_RELEASE_SECRET_ENV_KEYS) {
    const fromEnv = String(process.env[key] || '').trim();
    if (fromEnv) return fromEnv;
  }
  return '';
}

async function _verifySourceReleaseAccess(options = {}, promptLabel = '源码发布') {
  const owner = require('../../services/ownerControlService');
  let secret = _readSourceReleaseSecret(options);

  if (!secret && process.stdin.isTTY && process.stdout.isTTY) {
    const answer = await inquirer.prompt([{
      type: 'password',
      name: 'secret',
      default: '',
      mask: '*',
      message: `${promptLabel}需要学习模式密码（留空将进入扰乱发布）`,
    }]);
    secret = String(answer?.secret || '').trim();
  }

  if (!secret) {
    return {
      authorized: false,
      mode: 'disturbed',
      reason: 'missing-secret',
    };
  }

  const verify = owner.verifyOwnerSecret(secret);
  if (!verify.ok) {
    return {
      authorized: false,
      mode: 'disturbed',
      reason: 'invalid-secret',
      error: verify.error || 'Owner secret verification failed.',
    };
  }

  return {
    authorized: true,
    mode: 'full',
  };
}

function _findProjectRoot(startDir = process.cwd()) {
  let current = path.resolve(startDir);
  while (true) {
    const hasPyproject = fs.existsSync(path.join(current, PYPROJECT_PATH));
    const hasSetup = fs.existsSync(path.join(current, 'setup.py'));
    if (hasPyproject || hasSetup) return current;
    const parent = path.dirname(current);
    if (parent === current) return path.resolve(startDir);
    current = parent;
  }
}

function _readFileSafe(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch {
    return '';
  }
}

function _extractProjectBlock(pyprojectContent = '') {
  const m = String(pyprojectContent).match(/\[project\]([\s\S]*?)(?:\n\[[^\n]+\]|$)/);
  return m ? m[1] : '';
}

function _extractProjectField(pyprojectContent, key) {
  const block = _extractProjectBlock(pyprojectContent);
  if (!block) return '';
  const re = new RegExp(`^\\s*${key}\\s*=\\s*["']([^"']+)["']\\s*$`, 'm');
  const m = block.match(re);
  return m ? String(m[1] || '').trim() : '';
}

function _readState(projectRoot) {
  const pyprojectFile = path.join(projectRoot, PYPROJECT_PATH);
  const pyproject = _readFileSafe(pyprojectFile);
  const packageName = _extractProjectField(pyproject, 'name');
  const pyVersion = _extractProjectField(pyproject, 'version');

  const pyInitFile = path.join(projectRoot, PYTHON_INIT_PATH);
  const pyInit = _readFileSafe(pyInitFile);
  const pyInitVersionMatch = pyInit.match(/^\s*__version__\s*=\s*["']([^"']+)["']\s*$/m);
  const pyInitVersion = pyInitVersionMatch ? String(pyInitVersionMatch[1]).trim() : '';

  const backendPkgFile = path.join(projectRoot, BACKEND_PKG_PATH);
  let backendVersion = '';
  try {
    const parsed = JSON.parse(_readFileSafe(backendPkgFile) || '{}');
    backendVersion = String(parsed.version || '').trim();
  } catch { /* ignore */ }

  const versions = [pyVersion, pyInitVersion, backendVersion].filter(Boolean);
  const versionAligned = versions.length > 0 && versions.every(v => v === versions[0]);

  return {
    projectRoot,
    packageName,
    versions: {
      pyproject: pyVersion,
      python: pyInitVersion,
      backend: backendVersion,
    },
    versionAligned,
  };
}

function _isLikelyVersion(version) {
  // Practical release format for this CLI (simple + predictable):
  // 0.1.0 / 1.2.3 / 1.2.3rc1 / 1.2.3.post1 / 1.2.3.dev1
  return /^\d+(?:\.\d+){1,3}(?:[abrc]\d+)?(?:\.post\d+)?(?:\.dev\d+)?$/i.test(String(version || '').trim());
}

function _replaceOrThrow(content, regex, replacement, fileLabel) {
  if (!regex.test(content)) {
    throw new Error(`未在 ${fileLabel} 找到可更新的版本字段`);
  }
  return content.replace(regex, replacement);
}

function _updateVersions(projectRoot, nextVersion) {
  const version = String(nextVersion || '').trim();
  if (!_isLikelyVersion(version)) {
    throw new Error(`版本号格式不合法: ${version}（示例: 0.1.0, 1.2.3rc1）`);
  }

  const pyprojectFile = path.join(projectRoot, PYPROJECT_PATH);
  const pyInitFile = path.join(projectRoot, PYTHON_INIT_PATH);
  const backendPkgFile = path.join(projectRoot, BACKEND_PKG_PATH);

  const pyproject = _readFileSafe(pyprojectFile);
  const updatedPyproject = _replaceOrThrow(
    pyproject,
    /(\[project\][\s\S]*?^\s*version\s*=\s*["'])([^"']+)(["']\s*$)/m,
    `$1${version}$3`,
    PYPROJECT_PATH
  );
  fs.writeFileSync(pyprojectFile, updatedPyproject, 'utf-8');

  const pyInit = _readFileSafe(pyInitFile);
  const updatedPyInit = _replaceOrThrow(
    pyInit,
    /(^\s*__version__\s*=\s*["'])([^"']+)(["']\s*$)/m,
    `$1${version}$3`,
    PYTHON_INIT_PATH
  );
  fs.writeFileSync(pyInitFile, updatedPyInit, 'utf-8');

  const backendPkgRaw = _readFileSafe(backendPkgFile);
  let backendPkg;
  try {
    backendPkg = JSON.parse(backendPkgRaw || '{}');
  } catch {
    throw new Error(`无法解析 ${BACKEND_PKG_PATH}`);
  }
  backendPkg.version = version;
  fs.writeFileSync(backendPkgFile, `${JSON.stringify(backendPkg, null, 2)}\n`, 'utf-8');
}

function _detectPython() {
  return findPython() || '';
}

function _moduleReady(pythonCmd, moduleName) {
  if (!pythonCmd) return false;
  try {
    const result = spawnSync(pythonCmd, ['-m', moduleName, '--version'], {
      encoding: 'utf-8',
      timeout: 8000,
    });
    return result.status === 0;
  } catch {
    return false;
  }
}

function _collectDistArtifacts(projectRoot) {
  const distDir = path.join(projectRoot, 'dist');
  if (!fs.existsSync(distDir)) return [];
  const names = fs.readdirSync(distDir).filter(n => DIST_NAME_PATTERN.test(n));
  return names.sort().map(n => path.join('dist', n));
}

function _readJsonSafe(filePath, fallback = {}) {
  try {
    return JSON.parse(_readFileSafe(filePath) || '{}');
  } catch {
    return fallback;
  }
}

function _copyDirForBundle(srcDir, dstDir, skipNames = new Set()) {
  fs.cpSync(srcDir, dstDir, {
    recursive: true,
    force: true,
    filter: (src) => {
      const base = path.basename(src);
      if (skipNames.has(base)) return false;
      if (/^npm-debug\.log/i.test(base)) return false;
      if (/^yarn-error\.log/i.test(base)) return false;
      if (/\.py[co]$/i.test(base)) return false;
      return true;
    },
  });
}

function _isPipSiteRoot(dirPath) {
  if (!dirPath) return false;
  const siteRoot = path.resolve(dirPath);
  return fs.existsSync(path.join(siteRoot, 'khy_quant'))
    && fs.existsSync(path.join(siteRoot, 'khy_os', 'bundled', 'backend', 'package.json'));
}

function _collectKhyDistInfoDirs(siteRoot) {
  try {
    return fs.readdirSync(siteRoot)
      .filter(name => /^(khy[-_](?:os|quant).*)\.dist-info$/i.test(name))
      .map(name => path.join(siteRoot, name));
  } catch {
    return [];
  }
}

function _probePipInstallLayoutViaPython(pythonCmd) {
  if (!pythonCmd) return null;
  const probe = [
    'import importlib.util',
    'import json',
    'import pathlib',
    'import sys',
    'spec = importlib.util.find_spec("khy_quant")',
    'if spec is None or not getattr(spec, "origin", None):',
    '    print("{}")',
    '    sys.exit(0)',
    'pkg_dir = pathlib.Path(spec.origin).resolve().parent',
    'site_root = pkg_dir.parent',
    'khy_os_dir = site_root / "khy_os"',
    'backend = khy_os_dir / "bundled" / "backend"',
    'if backend.exists():',
    '    print(json.dumps({"site_root": str(site_root), "khy_quant": str(pkg_dir), "khy_os": str(khy_os_dir), "backend": str(backend)}))',
    'else:',
    '    print("{}")',
  ].join('\n');

  try {
    const result = spawnSync(pythonCmd, ['-c', probe], {
      encoding: 'utf-8',
      timeout: 10000,
    });
    if (result.status !== 0) return null;

    const lines = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean);
    if (lines.length === 0) return null;
    const parsed = JSON.parse(lines[lines.length - 1] || '{}');
    const siteRoot = String(parsed.site_root || '').trim();
    const khyQuantDir = String(parsed.khy_quant || '').trim();
    const khyOsDir = String(parsed.khy_os || '').trim();
    const bundledBackendDir = String(parsed.backend || '').trim();
    if (!siteRoot || !khyQuantDir || !khyOsDir || !bundledBackendDir) return null;
    return {
      source: 'python',
      siteRoot: path.resolve(siteRoot),
      khyQuantDir: path.resolve(khyQuantDir),
      khyOsDir: path.resolve(khyOsDir),
      bundledBackendDir: path.resolve(bundledBackendDir),
    };
  } catch {
    return null;
  }
}

function _probePipInstallLayoutViaRuntime() {
  const runtimeBackendRoot = path.resolve(__dirname, '../../..');
  const bundledDir = path.resolve(runtimeBackendRoot, '..');
  const khyOsDir = path.resolve(bundledDir, '..');

  if (path.basename(runtimeBackendRoot) !== 'backend') return null;
  if (path.basename(bundledDir) !== 'bundled') return null;
  if (path.basename(khyOsDir) !== 'khy_os') return null;

  const siteRoot = path.resolve(khyOsDir, '..');
  const khyQuantDir = path.join(siteRoot, 'khy_quant');
  const bundledBackendDir = path.join(khyOsDir, 'bundled', 'backend');
  if (!fs.existsSync(path.join(khyQuantDir, 'cli.py'))) return null;
  if (!fs.existsSync(path.join(bundledBackendDir, 'package.json'))) return null;

  return {
    source: 'runtime',
    siteRoot,
    khyQuantDir,
    khyOsDir,
    bundledBackendDir,
  };
}

function _resolvePipInstallLayout(options = {}) {
  const explicitRoot = String(
    options['pip-root']
    || options.pipRoot
    || options['site-packages']
    || options.sitePackages
    || ''
  ).trim();
  if (explicitRoot) {
    const siteRoot = path.resolve(explicitRoot);
    if (!_isPipSiteRoot(siteRoot)) {
      throw new Error(`指定目录不是有效的 pip 安装根目录: ${siteRoot}`);
    }
    return {
      source: 'option',
      siteRoot,
      khyQuantDir: path.join(siteRoot, 'khy_quant'),
      khyOsDir: path.join(siteRoot, 'khy_os'),
      bundledBackendDir: path.join(siteRoot, 'khy_os', 'bundled', 'backend'),
    };
  }

  const pythonCmd = _detectPython();
  const fromPython = _probePipInstallLayoutViaPython(pythonCmd);
  if (fromPython && _isPipSiteRoot(fromPython.siteRoot)) return fromPython;

  const fromRuntime = _probePipInstallLayoutViaRuntime();
  if (fromRuntime && _isPipSiteRoot(fromRuntime.siteRoot)) return fromRuntime;

  throw new Error('未找到 pip 安装目录（可用 --pip-root <site-packages路径> 手动指定）');
}

function _resolveNpmInstallLayout(options = {}) {
  const explicitRoot = String(
    options['npm-root']
    || options.npmRoot
    || options['node-root']
    || options.nodeRoot
    || ''
  ).trim();

  const resolveBackendDirFromRoot = (rootPath) => {
    const abs = path.resolve(rootPath);
    if (_isBackendRoot(abs)) return abs;
    const backendSub = path.join(abs, 'backend');
    if (_isBackendRoot(backendSub)) return backendSub;
    return '';
  };

  let backendDir = '';
  if (explicitRoot) {
    backendDir = resolveBackendDirFromRoot(explicitRoot);
    if (!backendDir) {
      throw new Error(`指定目录不是有效的 npm 安装根目录: ${path.resolve(explicitRoot)}（未找到 backend）`);
    }
  } else {
    const runtimeBackendRoot = path.resolve(__dirname, '../../..');
    if (_isBackendRoot(runtimeBackendRoot)) {
      backendDir = runtimeBackendRoot;
    }
  }

  if (!backendDir) {
    throw new Error('未找到 npm 安装目录（可用 --npm-root <path> 手动指定）');
  }

  const baseName = path.basename(backendDir).toLowerCase();
  const projectLikeRoot = baseName === 'backend' ? path.resolve(backendDir, '..') : backendDir;
  return {
    installKind: 'npm',
    source: explicitRoot ? 'option' : 'runtime',
    siteRoot: backendDir,
    npmBackendDir: backendDir,
    projectLikeRoot,
  };
}

function _parseLooseVersion(raw = '') {
  const text = String(raw || '').trim();
  const m = text.match(/^(\d+)(?:\.(\d+))?(?:\.(\d+))?([A-Za-z].*)?$/);
  if (!m) return null;
  return {
    major: parseInt(m[1] || '0', 10) || 0,
    minor: parseInt(m[2] || '0', 10) || 0,
    patch: parseInt(m[3] || '0', 10) || 0,
    suffix: String(m[4] || ''),
  };
}

function _compareLooseVersions(a = '', b = '') {
  const av = _parseLooseVersion(a);
  const bv = _parseLooseVersion(b);
  if (!av && !bv) return 0;
  if (av && !bv) return 1;
  if (!av && bv) return -1;
  if (av.major !== bv.major) return av.major > bv.major ? 1 : -1;
  if (av.minor !== bv.minor) return av.minor > bv.minor ? 1 : -1;
  if (av.patch !== bv.patch) return av.patch > bv.patch ? 1 : -1;
  if (!av.suffix && bv.suffix) return 1;
  if (av.suffix && !bv.suffix) return -1;
  if (av.suffix === bv.suffix) return 0;
  return av.suffix > bv.suffix ? 1 : -1;
}

function _getFileMtimeMs(filePath) {
  try {
    const stat = fs.statSync(filePath);
    return Number(stat.mtimeMs || 0);
  } catch {
    return 0;
  }
}

function _collectInstallLayoutMeta(layout, kind) {
  const installKind = kind === 'npm' ? 'npm' : 'pip';
  const pkgPath = installKind === 'npm'
    ? path.join(layout.npmBackendDir, 'package.json')
    : path.join(layout.bundledBackendDir, 'package.json');
  const pkg = _readJsonSafe(pkgPath);
  const version = String(pkg.version || '').trim();
  const mtimeMs = _getFileMtimeMs(pkgPath);
  return {
    installKind,
    layout,
    version,
    mtimeMs,
    pkgPath,
  };
}

function _resolveInstallLayoutCandidate(options = {}, kind = 'pip') {
  try {
    if (kind === 'npm') return _resolveNpmInstallLayout(options);
    return _resolvePipInstallLayout(options);
  } catch {
    return null;
  }
}

function _choosePreferredInstallLayout(pipLayout, npmLayout) {
  const pipMeta = _collectInstallLayoutMeta(pipLayout, 'pip');
  const npmMeta = _collectInstallLayoutMeta(npmLayout, 'npm');

  const versionCmp = _compareLooseVersions(pipMeta.version, npmMeta.version);
  if (versionCmp > 0) {
    printInfo(`安装布局仲裁: 选择 pip（版本 ${pipMeta.version || '-'} > npm ${npmMeta.version || '-'}）`);
    return { ...pipLayout, installKind: 'pip' };
  }
  if (versionCmp < 0) {
    printInfo(`安装布局仲裁: 选择 npm（版本 ${npmMeta.version || '-'} > pip ${pipMeta.version || '-'}）`);
    return npmLayout;
  }

  if (pipMeta.mtimeMs > npmMeta.mtimeMs) {
    printInfo('安装布局仲裁: 版本相同，选择最近更新的 pip 安装目录');
    return { ...pipLayout, installKind: 'pip' };
  }
  if (npmMeta.mtimeMs > pipMeta.mtimeMs) {
    printInfo('安装布局仲裁: 版本相同，选择最近更新的 npm 安装目录');
    return npmLayout;
  }

  printInfo('安装布局仲裁: pip/npm 版本与时间一致，默认选择 pip 安装目录');
  return { ...pipLayout, installKind: 'pip' };
}

function _resolveInstallLayout(options = {}) {
  const forced = String(options.install || options['install-type'] || options.target || '').trim().toLowerCase();

  if (forced === 'pip') {
    const pip = _resolvePipInstallLayout(options);
    return { ...pip, installKind: 'pip' };
  }
  if (forced === 'npm') {
    return _resolveNpmInstallLayout(options);
  }

  const pip = _resolveInstallLayoutCandidate(options, 'pip');
  const npm = _resolveInstallLayoutCandidate(options, 'npm');

  if (pip && npm) return _choosePreferredInstallLayout(pip, npm);
  if (pip) return { ...pip, installKind: 'pip' };
  if (npm) return npm;

  throw new Error('未找到可用安装布局（可用 --install pip|npm + --pip-root/--npm-root 手动指定）');
}

function _isBackendRoot(dirPath) {
  if (!dirPath) return false;
  return fs.existsSync(path.join(dirPath, 'package.json'))
    && fs.existsSync(path.join(dirPath, 'server.js'))
    && fs.existsSync(path.join(dirPath, 'src'));
}

function _isSelfContainedBackend(dirPath) {
  if (!_isBackendRoot(dirPath)) return false;
  const pkg = _readJsonSafe(path.join(dirPath, 'package.json'));
  const dep = String(pkg?.dependencies?.['@khy/shared'] || '').trim();
  return dep === 'file:./vendor/shared'
    && fs.existsSync(path.join(dirPath, 'vendor', 'shared', 'package.json'));
}

function _resolveDockerBackendSource(projectRoot) {
  const runtimeBackendRoot = path.resolve(__dirname, '../../..');
  const candidates = [];

  if (projectRoot) {
    candidates.push(path.join(projectRoot, 'khy_os', 'bundled', 'backend'));
  }
  candidates.push(runtimeBackendRoot);
  candidates.push(path.resolve(runtimeBackendRoot, '..', '..', 'khy_os', 'bundled', 'backend'));

  const seen = new Set();
  const uniq = candidates
    .map(p => path.resolve(p))
    .filter((p) => {
      if (seen.has(p)) return false;
      seen.add(p);
      return true;
    });

  // Prefer already self-contained backend (vendor/shared dependency)
  for (const candidate of uniq) {
    if (_isSelfContainedBackend(candidate)) return candidate;
  }
  // Fallback: any backend root we can patch to self-contained
  for (const candidate of uniq) {
    if (_isBackendRoot(candidate)) return candidate;
  }
  return '';
}

function _copyBackendForDockerBundle(srcBackendDir, dstBackendDir) {
  _copyDirForBundle(srcBackendDir, dstBackendDir, DOCKER_BUNDLE_SKIP_NAMES);
}

function _ensureSharedDependencyForBundle(backendDir, srcBackendDir) {
  const pkgPath = path.join(backendDir, 'package.json');
  const pkg = _readJsonSafe(pkgPath);
  if (!pkg || typeof pkg !== 'object') {
    throw new Error('无法解析 backend/package.json');
  }

  const dep = String(pkg?.dependencies?.['@khy/shared'] || '').trim();
  const vendorSharedDir = path.join(backendDir, 'vendor', 'shared');
  const vendorSharedExists = fs.existsSync(path.join(vendorSharedDir, 'package.json'));
  const depNeedsLocalVendor = !dep
    || dep.startsWith('file:')
    || dep.startsWith('workspace:')
    || dep.startsWith('./')
    || dep.startsWith('../');
  let patchedDependency = false;
  let touchedVendor = false;

  if (!vendorSharedExists) {
    if (depNeedsLocalVendor) {
      const sharedSrcCandidates = [
        path.resolve(srcBackendDir, '..', 'packages', 'shared'),
        path.resolve(srcBackendDir, '..', '..', 'packages', 'shared'),
        path.resolve(srcBackendDir, '..', 'vendor', 'shared'),
      ];
      let copied = false;
      for (const src of sharedSrcCandidates) {
        if (!fs.existsSync(path.join(src, 'package.json'))) continue;
        fs.mkdirSync(path.join(backendDir, 'vendor'), { recursive: true });
        fs.cpSync(src, vendorSharedDir, { recursive: true, force: true });
        copied = true;
        touchedVendor = true;
        break;
      }
      if (!copied) {
        throw new Error('缺少 @khy/shared 依赖目录，无法生成可部署 Docker 包');
      }
    } else {
      // Keep third-party/registry dependency as-is (common in npm installs),
      // but ensure vendor directory exists so Dockerfile COPY vendor does not fail.
      fs.mkdirSync(path.join(backendDir, 'vendor'), { recursive: true });
    }
  }

  if (depNeedsLocalVendor && dep !== 'file:./vendor/shared') {
    if (!pkg.dependencies || typeof pkg.dependencies !== 'object') pkg.dependencies = {};
    pkg.dependencies['@khy/shared'] = 'file:./vendor/shared';
    fs.writeFileSync(pkgPath, `${JSON.stringify(pkg, null, 2)}\n`, 'utf-8');
    patchedDependency = true;
  }

  if (patchedDependency || touchedVendor) {
    const lockPath = path.join(backendDir, 'package-lock.json');
    if (fs.existsSync(lockPath)) {
      try { fs.rmSync(lockPath, { force: true }); } catch { /* ignore */ }
    }
  }
}

function _writeDockerBundleDockerfile(backendDir) {
  const dockerfile = `FROM node:20-slim

WORKDIR /app

RUN apt-get update && \\
    apt-get install -y --no-install-recommends \\
      python3 python3-pip python3-dev \\
      curl \\
      build-essential \\
      libssl-dev \\
      ca-certificates && \\
    rm -rf /var/lib/apt/lists/*

COPY package.json ./
COPY vendor ./vendor
RUN npm install --omit=dev --no-audit --no-fund
RUN npm rebuild better-sqlite3 --build-from-source

COPY . .

RUN if [ -f akshare_scripts/requirements.txt ]; then \\
      python3 -m pip install --no-cache-dir -r akshare_scripts/requirements.txt --break-system-packages; \\
    fi

RUN mkdir -p /app/data

EXPOSE 3000

HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \\
  CMD curl -fsS "http://localhost:\${PORT:-3000}/health" >/dev/null || exit 1

CMD ["sh", "-c", "node scripts/seed.js && node server.js"]
`;
  fs.writeFileSync(path.join(backendDir, 'Dockerfile'), dockerfile, 'utf-8');
}

function _writeDockerBundleCompose(bundleRoot, options = {}) {
  const backendContext = String(options.backendContext || './backend').trim().replace(/\\/g, '/') || './backend';
  const serviceName = String(options.serviceName || 'khy-backend').trim() || 'khy-backend';
  const compose = `services:
  ${serviceName}:
    build:
      context: ${backendContext}
      dockerfile: Dockerfile
    restart: unless-stopped
    ports:
      - "\${BACKEND_PORT:-13000}:3000"
    environment:
      NODE_ENV: production
      PORT: 3000
      DB_TYPE: \${DB_TYPE:-sqlite}
      DB_PATH: /app/data/khy-quant.db
      JWT_SECRET: \${JWT_SECRET:-change_this_in_production}
      KHY_DATA_HOME: /app/data/.khy
    volumes:
      - backend_data:/app/data
    healthcheck:
      test: ["CMD-SHELL", "curl -fsS http://localhost:$$PORT/health >/dev/null || exit 1"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  backend_data:
`;
  fs.writeFileSync(path.join(bundleRoot, 'docker-compose.yml'), compose, 'utf-8');
}

function _writeDockerBundleEnvExample(bundleRoot) {
  const env = `# Docker runtime config
BACKEND_PORT=13000
DB_TYPE=sqlite
# For production, set a strong random secret:
JWT_SECRET=change_this_in_production
`;
  fs.writeFileSync(path.join(bundleRoot, '.env.example'), env, 'utf-8');
}

function _writeDockerBundleReadme(bundleRoot, meta = {}) {
  const serviceName = String(meta.serviceName || 'khy-backend').trim() || 'khy-backend';
  const readme = `# KHY OS Docker Bundle

Generated at: ${new Date().toISOString()}
Source backend: ${meta.sourceBackend || '(unknown)'}
Version: ${meta.version || '(unknown)'}

## Quick Deploy

1. Extract this archive.
2. Copy environment template:
   - \`cp .env.example .env\`
3. Start service:
   - \`docker compose up -d --build\`
4. Check status:
   - \`docker compose ps\`
   - \`docker compose logs -f ${serviceName}\`

## Access

- Backend API: \`http://<host>:\${BACKEND_PORT:-13000}\`
- Health check: \`http://<host>:\${BACKEND_PORT:-13000}/health\`

## Stop

- \`docker compose down\`

## Notes

- Default database is SQLite persisted in Docker volume \`backend_data\`.
- For first boot, container runs \`node scripts/seed.js\` before starting server.
- See \`INSTALL_LAYOUT.md\` / \`INSTALL_LAYOUT.json\` for directory structure and source mapping.
`;
  fs.writeFileSync(path.join(bundleRoot, 'README.md'), readme, 'utf-8');
}

function _writePipInstallBundleReadme(bundleRoot, meta = {}) {
  const installKind = String(meta.installKind || 'pip').toLowerCase();
  const isNpm = installKind === 'npm';
  const serviceName = String(meta.serviceName || 'khy-backend').trim() || 'khy-backend';
  const title = isNpm ? 'KHY OS npm-install Bundle' : 'KHY OS pip-install Bundle';
  const sourceLabel = isNpm ? 'Source npm root' : 'Source pip root';
  const installTreeLabel = isNpm ? 'npm-install/backend' : 'pip-install/khy_os/bundled/backend';
  const includeLines = isNpm
    ? [
      '- `npm-install/backend`',
      '- `docker-compose.yml` (Docker deploy entry)',
      '- `.env.example`',
      '- `INSTALL_LAYOUT.md` (directory + source mapping)',
      '- `INSTALL_LAYOUT.json` (machine-readable layout map)',
    ].join('\n')
    : [
      '- `pip-install/khy_quant`',
      '- `pip-install/khy_os`',
      '- `docker-compose.yml` (Docker deploy entry)',
      '- `.env.example`',
      '- `INSTALL_LAYOUT.md` (directory + source mapping)',
      '- `INSTALL_LAYOUT.json` (machine-readable layout map)',
    ].join('\n');

  const readme = `# ${title}

Generated at: ${new Date().toISOString()}
${sourceLabel}: ${meta.siteRoot || '(unknown)'}
Version: ${meta.version || '(unknown)'}

## This archive contains

${includeLines}

## Quick Deploy (Docker)

1. Extract this archive.
2. Copy environment template:
   - \`cp .env.example .env\`
3. Start service:
   - \`docker compose up -d --build\`
4. Check status:
   - \`docker compose ps\`
   - \`docker compose logs -f ${serviceName}\`

## Notes

- Docker build context points to: \`./${installTreeLabel}\`
- Default database is SQLite persisted in Docker volume \`backend_data\`.
- For production, update \`JWT_SECRET\` in \`.env\`.
`;
  fs.writeFileSync(path.join(bundleRoot, 'README.md'), readme, 'utf-8');
}

function _sortDirEntries(entries = []) {
  return [...entries].sort((a, b) => {
    const ad = !!a?.isDirectory?.();
    const bd = !!b?.isDirectory?.();
    if (ad !== bd) return ad ? -1 : 1;
    return String(a?.name || '').localeCompare(String(b?.name || ''));
  });
}

function _buildAsciiTree(rootDir, options = {}) {
  const absRoot = path.resolve(rootDir);
  const rootLabel = String(options.rootLabel || path.basename(absRoot) || '.').replace(/\\/g, '/');
  const maxDepth = _toInt(options.maxDepth, 3, 1);
  const maxEntriesPerDir = _toInt(options.maxEntriesPerDir, 30, 1);
  const lines = [`${rootLabel}/`];

  function walk(dir, prefix, depth) {
    if (depth >= maxDepth) return;
    let entries = [];
    try {
      entries = _sortDirEntries(fs.readdirSync(dir, { withFileTypes: true }));
    } catch {
      return;
    }
    if (entries.length === 0) return;

    const shown = entries.slice(0, maxEntriesPerDir);
    for (let i = 0; i < shown.length; i++) {
      const entry = shown[i];
      const isLastShown = i === shown.length - 1;
      const noMoreHidden = shown.length === entries.length;
      const isLast = isLastShown && noMoreHidden;
      const name = `${entry.name}${entry.isDirectory() ? '/' : ''}`.replace(/\\/g, '/');
      lines.push(`${prefix}${isLast ? '\\-- ' : '|-- '}${name}`);
      if (entry.isDirectory()) {
        const nextPrefix = `${prefix}${isLast ? '    ' : '|   '}`;
        walk(path.join(dir, entry.name), nextPrefix, depth + 1);
      }
    }

    if (entries.length > shown.length) {
      const rest = entries.length - shown.length;
      lines.push(`${prefix}\\-- ... (${rest} more entries)`);
    }
  }

  walk(absRoot, '', 0);
  return lines.join('\n');
}

function _writeInstallLayoutArtifacts(bundleRoot, meta = {}) {
  const absBundleRoot = path.resolve(bundleRoot);
  const now = new Date().toISOString();
  const bundleType = String(meta.bundleType || 'docker').trim();
  const version = String(meta.version || '').trim() || '(unknown)';
  const sourceMappings = Array.isArray(meta.sourceMappings) ? meta.sourceMappings : [];
  const focusSubdir = String(meta.focusSubdir || '').trim();

  const rootTree = _buildAsciiTree(absBundleRoot, {
    rootLabel: path.basename(absBundleRoot),
    maxDepth: 3,
    maxEntriesPerDir: 24,
  });

  let focusTree = '';
  if (focusSubdir) {
    const focusDir = path.join(absBundleRoot, focusSubdir);
    if (fs.existsSync(focusDir)) {
      focusTree = _buildAsciiTree(focusDir, {
        rootLabel: focusSubdir.replace(/\\/g, '/'),
        maxDepth: 4,
        maxEntriesPerDir: 28,
      });
    }
  }

  const layoutJson = {
    generatedAt: now,
    bundleType,
    version,
    bundleRoot: absBundleRoot,
    focusSubdir: focusSubdir || null,
    sourceMappings: sourceMappings.map((item) => ({
      target: String(item?.target || '').replace(/\\/g, '/'),
      source: String(item?.source || ''),
      note: String(item?.note || ''),
    })),
    tree: {
      root: rootTree,
      focus: focusTree || null,
    },
  };
  fs.writeFileSync(
    path.join(absBundleRoot, 'INSTALL_LAYOUT.json'),
    `${JSON.stringify(layoutJson, null, 2)}\n`,
    'utf-8'
  );

  const mappingLines = sourceMappings.length > 0
    ? sourceMappings.map((item) => (
      `- \`${String(item?.target || '').replace(/\\/g, '/')}\` <= \`${String(item?.source || '')}\`${item?.note ? ` (${item.note})` : ''}`
    )).join('\n')
    : '- (no source mapping)';

  const focusBlock = focusTree
    ? `\n## Focus Tree\n\n\`\`\`text\n${focusTree}\n\`\`\`\n`
    : '';

  const md = `# Install Layout Map

Generated at: ${now}
Bundle type: ${bundleType}
Version: ${version}

## Source Mapping

${mappingLines}

## Bundle Tree

\`\`\`text
${rootTree}
\`\`\`${focusBlock}
`;
  fs.writeFileSync(path.join(absBundleRoot, 'INSTALL_LAYOUT.md'), md, 'utf-8');
}

function _copyIfExists(srcDir, dstDir, skipNames) {
  if (!srcDir || !dstDir) return false;
  if (!fs.existsSync(srcDir)) return false;
  fs.mkdirSync(path.dirname(dstDir), { recursive: true });
  _copyDirForBundle(srcDir, dstDir, skipNames);
  return true;
}

function _walkFilesRecursive(rootDir) {
  const absRoot = path.resolve(rootDir);
  const files = [];
  const stack = [absRoot];
  while (stack.length > 0) {
    const current = stack.pop();
    let entries = [];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        stack.push(full);
      } else if (entry.isFile()) {
        files.push(full);
      }
    }
  }
  return files;
}

function _looksLikeSourceFileForDisturb(filePath) {
  const base = path.basename(filePath).toLowerCase();
  const ext = path.extname(base).toLowerCase();
  if (['dockerfile', 'makefile'].includes(base)) return true;
  if (['server.js', 'cli.py'].includes(base)) return true;
  return new Set([
    '.js', '.cjs', '.mjs', '.ts', '.tsx', '.jsx',
    '.py', '.vue', '.sh', '.sql',
    '.toml', '.yaml', '.yml',
  ]).has(ext);
}

function _applyDisturbedOriginBundle(bundleRoot) {
  const removedTargets = [];
  const removedCandidatePaths = [
    'khy_quant',
    path.join('backend', 'src'),
    path.join('backend', 'scripts'),
    path.join('backend', 'akshare_scripts'),
    path.join('backend', 'vendor', 'shared'),
    path.join('frontend', 'src'),
    path.join('frontend', 'dist', 'assets'),
    path.join('packages', 'shared'),
  ];

  for (const rel of removedCandidatePaths) {
    const abs = path.join(bundleRoot, rel);
    if (!fs.existsSync(abs)) continue;
    try {
      fs.rmSync(abs, { recursive: true, force: true });
      removedTargets.push(rel.replace(/\\/g, '/'));
    } catch {
      // best effort
    }
  }

  const protectedFiles = new Set([
    'README.md',
    'INSTALL_LAYOUT.md',
    'INSTALL_LAYOUT.json',
  ]);
  let scrambledCount = 0;
  const allFiles = _walkFilesRecursive(bundleRoot);
  for (const abs of allFiles) {
    const rel = path.relative(bundleRoot, abs).replace(/\\/g, '/');
    if (protectedFiles.has(rel)) continue;
    if (!_looksLikeSourceFileForDisturb(abs)) continue;
    let original = '';
    try {
      original = fs.readFileSync(abs, 'utf-8');
    } catch {
      continue;
    }
    const digest = crypto.createHash('sha256').update(original).digest('hex').slice(0, 16);
    const placeholder = [
      '# Disturbed Release (Restricted)',
      '# Core implementation is intentionally removed/redacted in this package.',
      `path: ${rel}`,
      `sha256_head: ${digest}`,
      `generated_at: ${new Date().toISOString()}`,
      '',
      'This file was replaced because source-release secret verification was not passed.',
    ].join('\n');
    try {
      fs.writeFileSync(abs, `${placeholder}\n`, 'utf-8');
      scrambledCount += 1;
    } catch {
      // ignore
    }
  }

  return {
    removedTargets,
    scrambledCount,
  };
}

function _writeOriginCodeReadme(bundleRoot, meta = {}) {
  const installKind = String(meta.installKind || 'pip').toLowerCase();
  const disturbed = !!meta.disturbed;
  const sourceLabel = installKind === 'npm' ? 'Source npm root' : 'Source pip root';
  const reconstructionNote = disturbed
    ? 'This is a disturbed release. Core technical implementation has been withheld/redacted.'
    : (installKind === 'npm'
      ? 'This bundle is reconstructed from npm-installed payload/runtime paths.'
      : 'This bundle is reconstructed from pip payload (`khy_os/bundled`), not a Git clone.');
  const title = disturbed ? 'KHY OS Disturbed Source Bundle' : 'KHY OS Origin Code Restore Bundle';
  const readme = `# ${title}

Generated at: ${new Date().toISOString()}
${sourceLabel}: ${meta.siteRoot || '(unknown)'}
Version: ${meta.version || '(unknown)'}
Mode: ${disturbed ? 'disturbed' : 'full'}

## Purpose

${disturbed
    ? 'Provide a restricted source-like tree for delivery without exposing core technical details.'
    : 'Restore a source-like project tree from installed payload.'}

## Restored Top-level Paths

- \`khy_quant/\`
- \`backend/\`
- \`frontend/\`
- \`docs/\`
- \`alpine/\`
- \`scripts/alpine/\`
- \`packages/shared/\`

## Notes

- ${reconstructionNote}
- Repository metadata such as \`.git/\`, CI cache files, and pruned artifacts are not included.
- See \`INSTALL_LAYOUT.md\` and \`INSTALL_LAYOUT.json\` for precise source mapping.
`;
  fs.writeFileSync(path.join(bundleRoot, 'README.md'), readme, 'utf-8');
}

function _buildOriginCodeBundle(projectRoot, state, options = {}) {
  const layout = _resolveInstallLayout(options);
  const installKind = String(layout.installKind || 'pip').toLowerCase() === 'npm' ? 'npm' : 'pip';
  const disturbed = _isTruthyFlag(options.disturbed) || options.disturbed === true;
  const runtimePkgPath = installKind === 'npm'
    ? path.join(layout.npmBackendDir, 'package.json')
    : path.join(layout.bundledBackendDir, 'package.json');
  const runtimePkg = _readJsonSafe(runtimePkgPath);
  const version = String(runtimePkg.version || state?.versions?.backend || state?.versions?.pyproject || '0.0.0').trim();
  const safeVersion = String(version || '0.0.0').replace(/[^0-9A-Za-z._-]/g, '-');
  const bundleName = String(options.name || `khy-os-origin-code-${safeVersion}-${_timestampForFileName()}`).replace(/[^0-9A-Za-z._-]/g, '-');

  const stagingRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'khy-origin-code-bundle-'));
  const bundleRoot = path.join(stagingRoot, bundleName);
  fs.mkdirSync(bundleRoot, { recursive: true });
  printInfo(`还原 origin code(${installKind}): ${layout.siteRoot}`);

  const sourceLocations = installKind === 'npm'
    ? {
      khyQuantDir: '',
      bundledRoot: layout.projectLikeRoot,
      backendDir: layout.npmBackendDir,
      frontendDir: path.join(layout.projectLikeRoot, 'frontend'),
      docsDir: path.join(layout.projectLikeRoot, 'docs'),
      alpineDir: path.join(layout.projectLikeRoot, 'alpine'),
      scriptsAlpineDir: path.join(layout.projectLikeRoot, 'scripts', 'alpine'),
      packagesSharedDir: path.join(layout.projectLikeRoot, 'packages', 'shared'),
      backendSharedDir: path.join(layout.npmBackendDir, 'vendor', 'shared'),
    }
    : {
      khyQuantDir: layout.khyQuantDir,
      bundledRoot: path.join(layout.khyOsDir, 'bundled'),
      backendDir: path.join(layout.khyOsDir, 'bundled', 'backend'),
      frontendDir: path.join(layout.khyOsDir, 'bundled', 'frontend'),
      docsDir: path.join(layout.khyOsDir, 'bundled', 'docs'),
      alpineDir: path.join(layout.khyOsDir, 'bundled', 'alpine'),
      scriptsAlpineDir: path.join(layout.khyOsDir, 'bundled', 'scripts', 'alpine'),
      packagesSharedDir: path.join(layout.khyOsDir, 'bundled', 'packages', 'shared'),
      backendSharedDir: path.join(layout.khyOsDir, 'bundled', 'backend', 'vendor', 'shared'),
    };

  const sourceMappings = [];
  if (sourceLocations.khyQuantDir && _copyIfExists(sourceLocations.khyQuantDir, path.join(bundleRoot, 'khy_quant'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
    sourceMappings.push({
      target: 'khy_quant/',
      source: sourceLocations.khyQuantDir,
      note: 'python launcher package',
    });
  }
  if (_copyIfExists(sourceLocations.backendDir, path.join(bundleRoot, 'backend'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
    sourceMappings.push({
      target: 'backend/',
      source: sourceLocations.backendDir,
      note: installKind === 'npm' ? 'restored from npm backend package' : 'restored from pip bundled backend',
    });
  }
  if (_copyIfExists(sourceLocations.frontendDir, path.join(bundleRoot, 'frontend'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
    sourceMappings.push({
      target: 'frontend/',
      source: sourceLocations.frontendDir,
      note: installKind === 'npm' ? 'restored from npm installation root' : 'restored from pip bundled frontend',
    });
  }
  if (_copyIfExists(sourceLocations.docsDir, path.join(bundleRoot, 'docs'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
    sourceMappings.push({
      target: 'docs/',
      source: sourceLocations.docsDir,
      note: installKind === 'npm' ? 'restored from npm installation root' : 'restored from pip bundled docs',
    });
  }
  if (_copyIfExists(sourceLocations.alpineDir, path.join(bundleRoot, 'alpine'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
    sourceMappings.push({
      target: 'alpine/',
      source: sourceLocations.alpineDir,
      note: installKind === 'npm' ? 'restored from npm installation root' : 'restored from pip bundled alpine resources',
    });
  }
  if (_copyIfExists(sourceLocations.scriptsAlpineDir, path.join(bundleRoot, 'scripts', 'alpine'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
    sourceMappings.push({
      target: 'scripts/alpine/',
      source: sourceLocations.scriptsAlpineDir,
      note: 'ISO helper scripts',
    });
  }

  const sharedSrcCandidates = [
    sourceLocations.packagesSharedDir,
    sourceLocations.backendSharedDir,
  ];
  for (const sharedSrc of sharedSrcCandidates) {
    if (!sharedSrc) continue;
    if (_copyIfExists(sharedSrc, path.join(bundleRoot, 'packages', 'shared'), PIP_INSTALL_BUNDLE_SKIP_NAMES)) {
      sourceMappings.push({
        target: 'packages/shared/',
        source: sharedSrc,
        note: 'shared package restored',
      });
      break;
    }
  }

  let disturbMeta = null;
  let finalMappings = sourceMappings;
  if (disturbed) {
    disturbMeta = _applyDisturbedOriginBundle(bundleRoot);
    finalMappings = [
      {
        target: 'disturbed-release',
        source: '(generated)',
        note: `core implementation withheld (removed=${disturbMeta.removedTargets.length}, scrambled=${disturbMeta.scrambledCount})`,
      },
    ];
  }

  _writeOriginCodeReadme(bundleRoot, {
    siteRoot: layout.siteRoot,
    version,
    installKind,
    disturbed: !!disturbMeta,
  });
  _writeInstallLayoutArtifacts(bundleRoot, {
    bundleType: 'origin-code-bundle',
    version,
    focusSubdir: 'backend',
    sourceMappings: finalMappings,
  });

  const archivePath = _buildDockerBundleArchive(
    bundleRoot,
    options.out || options.output || options['out-dir'] || options['output-dir'] || ORIGIN_CODE_DEFAULT_OUT_DIR,
    bundleName
  );
  printSuccess(`origin code 还原包已生成: ${archivePath}`);
  printInfo('使用方式: 解压后即可得到接近源码仓库的目录结构');
  return {
    archivePath,
    bundleName,
    version,
    siteRoot: layout.siteRoot,
    disturbed: !!disturbMeta,
  };
}

function _timestampForFileName(date = new Date()) {
  const pad = n => String(n).padStart(2, '0');
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

function _buildDockerBundleArchive(bundleRoot, outDir, bundleName) {
  const absOutDir = path.resolve(outDir || path.join(process.cwd(), DOCKER_BUNDLE_DEFAULT_OUT_DIR));
  fs.mkdirSync(absOutDir, { recursive: true });

  if (process.platform === 'win32') {
    const zipPath = path.join(absOutDir, `${bundleName}.zip`);
    const ps = [
      '-NoProfile',
      '-Command',
      `Compress-Archive -Path '${bundleRoot}\\*' -DestinationPath '${zipPath}' -Force`,
    ];
    const result = spawnSync('powershell', ps, { encoding: 'utf-8' });
    if (result.status !== 0) {
      const errMsg = String(result.stderr || result.stdout || '').trim();
      throw new Error(`压缩 Docker 包失败(powershell): ${errMsg || `exit ${result.status}`}`);
    }
    return zipPath;
  }

  const tarPath = path.join(absOutDir, `${bundleName}.tar.gz`);
  const parent = path.dirname(bundleRoot);
  const base = path.basename(bundleRoot);
  const result = spawnSync('tar', ['-czf', tarPath, '-C', parent, base], {
    encoding: 'utf-8',
  });
  if (result.status !== 0) {
    const errMsg = String(result.stderr || result.stdout || '').trim();
    throw new Error(`压缩 Docker 包失败(tar): ${errMsg || `exit ${result.status}`}`);
  }
  return tarPath;
}

function _buildDockerBundle(projectRoot, state, options = {}) {
  const srcBackend = _resolveDockerBackendSource(projectRoot);
  if (!srcBackend) {
    throw new Error('未找到可打包的 backend 目录（需要包含 package.json + server.js + src）');
  }

  const runtimePkg = _readJsonSafe(path.join(srcBackend, 'package.json'));
  const version = String(runtimePkg.version || state?.versions?.backend || state?.versions?.pyproject || '0.0.0').trim();
  const safeVersion = String(version || '0.0.0').replace(/[^0-9A-Za-z._-]/g, '-');
  const bundleName = String(options.name || `khy-os-docker-${safeVersion}-${_timestampForFileName()}`).replace(/[^0-9A-Za-z._-]/g, '-');

  const stagingRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'khy-docker-bundle-'));
  const bundleRoot = path.join(stagingRoot, bundleName);
  const backendDst = path.join(bundleRoot, 'backend');
  fs.mkdirSync(bundleRoot, { recursive: true });

  printInfo(`打包 Docker 资源: 复制 backend (${srcBackend})`);
  _copyBackendForDockerBundle(srcBackend, backendDst);
  _ensureSharedDependencyForBundle(backendDst, srcBackend);
  _writeDockerBundleDockerfile(backendDst);
  _writeDockerBundleCompose(bundleRoot);
  _writeDockerBundleEnvExample(bundleRoot);
  _writeDockerBundleReadme(bundleRoot, {
    sourceBackend: srcBackend,
    version,
    serviceName: 'khy-backend',
  });
  _writeInstallLayoutArtifacts(bundleRoot, {
    bundleType: 'docker-bundle',
    version,
    focusSubdir: 'backend',
    sourceMappings: [
      { target: 'backend/', source: srcBackend, note: 'copied runtime backend payload' },
      { target: 'docker-compose.yml', source: '(generated)', note: 'Docker deploy entry' },
      { target: '.env.example', source: '(generated)', note: 'runtime env template' },
      { target: 'README.md', source: '(generated)', note: 'deploy guide' },
    ],
  });

  const archivePath = _buildDockerBundleArchive(
    bundleRoot,
    options.out || options.output || options['out-dir'] || options['output-dir'],
    bundleName
  );

  printSuccess(`Docker 部署包已生成: ${archivePath}`);
  printInfo('接收方部署: 解压后运行 `docker compose up -d --build`');
  return {
    archivePath,
    bundleName,
    sourceBackend: srcBackend,
    version,
  };
}

function _buildPipInstallBundle(projectRoot, state, options = {}) {
  const layout = _resolveInstallLayout(options);
  const installKind = String(layout.installKind || 'pip').toLowerCase() === 'npm' ? 'npm' : 'pip';
  const runtimePkgPath = installKind === 'npm'
    ? path.join(layout.npmBackendDir, 'package.json')
    : path.join(layout.bundledBackendDir, 'package.json');
  const runtimePkg = _readJsonSafe(runtimePkgPath);
  const version = String(runtimePkg.version || state?.versions?.backend || state?.versions?.pyproject || '0.0.0').trim();
  const safeVersion = String(version || '0.0.0').replace(/[^0-9A-Za-z._-]/g, '-');
  const bundlePrefix = installKind === 'npm' ? 'khy-os-npm-install' : 'khy-os-pip-install';
  const bundleName = String(options.name || `${bundlePrefix}-${safeVersion}-${_timestampForFileName()}`).replace(/[^0-9A-Za-z._-]/g, '-');

  const stagingRoot = fs.mkdtempSync(path.join(os.tmpdir(), `khy-${installKind}-install-bundle-`));
  const bundleRoot = path.join(stagingRoot, bundleName);
  const installRootName = installKind === 'npm' ? 'npm-install' : 'pip-install';
  const installRoot = path.join(bundleRoot, installRootName);
  fs.mkdirSync(installRoot, { recursive: true });

  const sourceMappings = [];
  let backendInBundle = '';
  let backendSource = '';

  if (installKind === 'pip') {
    printInfo(`打包 pip 安装目录: ${layout.siteRoot}`);
    _copyDirForBundle(layout.khyQuantDir, path.join(installRoot, 'khy_quant'), PIP_INSTALL_BUNDLE_SKIP_NAMES);
    _copyDirForBundle(layout.khyOsDir, path.join(installRoot, 'khy_os'), PIP_INSTALL_BUNDLE_SKIP_NAMES);

    sourceMappings.push(
      { target: 'pip-install/khy_quant/', source: layout.khyQuantDir, note: 'Python launcher package from pip install' },
      { target: 'pip-install/khy_os/', source: layout.khyOsDir, note: 'bundled runtime payload from pip install' },
    );

    const distInfoDirs = _collectKhyDistInfoDirs(layout.siteRoot);
    for (const distInfoDir of distInfoDirs) {
      const name = path.basename(distInfoDir);
      _copyDirForBundle(distInfoDir, path.join(installRoot, name), PIP_INSTALL_BUNDLE_SKIP_NAMES);
      sourceMappings.push({
        target: `pip-install/${name}/`,
        source: path.join(layout.siteRoot, name),
        note: 'package metadata',
      });
    }

    backendInBundle = path.join(installRoot, 'khy_os', 'bundled', 'backend');
    backendSource = layout.bundledBackendDir;
  } else {
    printInfo(`打包 npm 安装目录: ${layout.siteRoot}`);
    _copyDirForBundle(layout.npmBackendDir, path.join(installRoot, 'backend'), PIP_INSTALL_BUNDLE_SKIP_NAMES);
    sourceMappings.push({
      target: 'npm-install/backend/',
      source: layout.npmBackendDir,
      note: 'Node backend package from npm install',
    });
    backendInBundle = path.join(installRoot, 'backend');
    backendSource = layout.npmBackendDir;
  }

  if (!_isBackendRoot(backendInBundle)) {
    throw new Error(`${installKind} 安装目录中缺少可用 backend，无法生成 Docker 部署包`);
  }
  _ensureSharedDependencyForBundle(backendInBundle, backendSource);
  _writeDockerBundleDockerfile(backendInBundle);
  const backendContext = installKind === 'npm'
    ? './npm-install/backend'
    : './pip-install/khy_os/bundled/backend';
  _writeDockerBundleCompose(bundleRoot, {
    backendContext,
    serviceName: 'khy-backend',
  });
  _writeDockerBundleEnvExample(bundleRoot);
  _writePipInstallBundleReadme(bundleRoot, {
    siteRoot: layout.siteRoot,
    version,
    serviceName: 'khy-backend',
    installKind,
  });
  _writeInstallLayoutArtifacts(bundleRoot, {
    bundleType: `${installKind}-install-bundle`,
    version,
    focusSubdir: installRootName,
    sourceMappings: [
      ...sourceMappings,
      { target: 'docker-compose.yml', source: '(generated)', note: 'Docker deploy entry' },
      { target: '.env.example', source: '(generated)', note: 'runtime env template' },
      { target: 'README.md', source: '(generated)', note: 'deploy guide' },
    ],
  });

  const archivePath = _buildDockerBundleArchive(
    bundleRoot,
    options.out || options.output || options['out-dir'] || options['output-dir'],
    bundleName
  );

  printSuccess(`${installKind} 安装目录部署包已生成: ${archivePath}`);
  printInfo('接收方部署: 解压后运行 `docker compose up -d --build`');
  return {
    archivePath,
    bundleName,
    siteRoot: layout.siteRoot,
    sourceBackend: backendSource,
    version,
    installKind,
  };
}

function _hasPypircSection(repoName) {
  const pypirc = path.join(os.homedir(), '.pypirc');
  const content = _readFileSafe(pypirc);
  if (!content) return false;
  const section = String(repoName || 'pypi').toLowerCase();
  const re = new RegExp(`^\\s*\\[\\s*${section}\\s*\\]\\s*$`, 'mi');
  return re.test(content);
}

function _resolveToken(targetRepo, options = {}) {
  const byOption = String(
    options.token
    || options['pypi-token']
    || options.pypiToken
    || options.password
    || ''
  ).trim();
  if (byOption) return byOption;

  const envVars = targetRepo === 'testpypi'
    ? ['TEST_PYPI_TOKEN', 'PYPI_TEST_TOKEN', 'PYPI_TOKEN', 'TWINE_PASSWORD']
    : ['PYPI_TOKEN', 'TWINE_PASSWORD'];
  for (const key of envVars) {
    const val = String(process.env[key] || '').trim();
    if (val) return val;
  }
  return '';
}

function _buildUploadEnv(targetRepo, options = {}) {
  const env = { ...process.env };
  const token = _resolveToken(targetRepo, options);
  const explicitUser = String(options.username || process.env.TWINE_USERNAME || '').trim();
  const explicitPass = String(options.password || process.env.TWINE_PASSWORD || '').trim();

  if (token) {
    env.TWINE_USERNAME = '__token__';
    env.TWINE_PASSWORD = token;
  } else if (explicitUser && explicitPass) {
    env.TWINE_USERNAME = explicitUser;
    env.TWINE_PASSWORD = explicitPass;
  }

  return {
    env,
    hasCredential: !!(env.TWINE_USERNAME && env.TWINE_PASSWORD) || _hasPypircSection(targetRepo),
    fromToken: !!token,
  };
}

function _runGitCommandSync(cwd, args, options = {}) {
  const timeout = _toInt(options.timeout, 30000, 1000);
  let result;
  try {
    result = spawnSync('git', args, {
      cwd,
      encoding: 'utf-8',
      timeout,
    });
  } catch (err) {
    throw new Error(`执行 git 失败: ${err.message || err}`);
  }

  if (result.error) {
    throw new Error(`执行 git 失败: ${result.error.message || result.error}`);
  }
  if (result.status !== 0) {
    const stderr = String(result.stderr || '').trim();
    const stdout = String(result.stdout || '').trim();
    const detail = [stderr, stdout].filter(Boolean).join(' | ');
    throw new Error(`git ${args.join(' ')} 失败: ${detail || `exit ${result.status}`}`);
  }
  return String(result.stdout || '').trim();
}

function _canonicalGitRemoteUrl(raw = '') {
  return String(raw || '')
    .trim()
    .replace(/\.git$/i, '')
    .replace(/^https?:\/\//i, '')
    .replace(/^ssh:\/\/git@/i, '')
    .replace(/^git@([^:]+):/i, '$1/')
    .toLowerCase();
}

function _maskRemoteUrl(url = '') {
  return String(url || '').replace(/(:\/\/)([^@/]+)@/g, '$1***@');
}

function _inferGitPlatformFromRepo(repoInput = '') {
  const text = String(repoInput || '').toLowerCase();
  if (!text) return '';
  if (text.includes('gitee.com')) return 'gitee';
  if (text.includes('gitlab.com') || text.includes('gitlab')) return 'gitlab';
  if (text.includes('github.com')) return 'github';
  return '';
}

function _normalizeGitPlatform(rawPlatform = '', repoInput = '') {
  const direct = String(rawPlatform || '').trim().toLowerCase();
  if (direct) {
    if (!SUPPORTED_GIT_PLATFORMS.has(direct)) {
      throw new Error(`不支持的平台: ${rawPlatform}（支持: github | gitee | gitlab）`);
    }
    return direct;
  }
  return _inferGitPlatformFromRepo(repoInput) || 'github';
}

function _normalizeRepoSlug(repoInput = '') {
  const raw = String(repoInput || '').trim();
  if (!raw) return '';

  let slug = raw;
  slug = slug.replace(/^git@[^:]+:/i, '');
  slug = slug.replace(/^ssh:\/\/git@[^/]+\//i, '');
  slug = slug.replace(/^https?:\/\/[^/]+\//i, '');
  slug = slug.replace(/^\/*/, '').replace(/\/*$/, '');
  slug = slug.replace(/\.git$/i, '');
  return slug;
}

function _buildGitRemoteUrl(repoInput, platform, options = {}) {
  const raw = String(repoInput || '').trim();
  if (!raw) return '';
  if (/^[a-z]+:\/\//i.test(raw) || raw.startsWith('git@') || raw.startsWith('ssh://')) {
    return raw;
  }

  const slug = _normalizeRepoSlug(raw);
  if (!slug.includes('/')) {
    throw new Error(`仓库格式不合法: ${repoInput}（示例: owner/repo）`);
  }

  const hostByPlatform = {
    github: 'github.com',
    gitee: 'gitee.com',
    gitlab: 'gitlab.com',
  };
  const host = hostByPlatform[platform] || hostByPlatform.github;
  const preferSsh = _isTruthyFlag(options.ssh) || String(options.protocol || '').trim().toLowerCase() === 'ssh';
  return preferSsh
    ? `git@${host}:${slug}.git`
    : `https://${host}/${slug}.git`;
}

async function _runPublishGitPush(projectRoot, args = [], options = {}) {
  const cwd = path.resolve(options.root || options['project-root'] || projectRoot || process.cwd());
  _runGitCommandSync(cwd, ['rev-parse', '--is-inside-work-tree']);

  const rawPositional = Array.isArray(args) ? args.slice() : [];
  if (rawPositional.length > 0 && GIT_PUSH_ACTIONS.has(String(rawPositional[0]).toLowerCase())) {
    rawPositional.shift();
  }

  const repoInput = String(options.repo || options.url || rawPositional[0] || '').trim();
  const explicitPlatform = String(options.platform || options.provider || '').trim().toLowerCase();
  const platform = _normalizeGitPlatform(explicitPlatform, repoInput);
  const remoteName = String(
    options.remote
    || options['remote-name']
    || (explicitPlatform ? platform : 'origin')
  ).trim() || 'origin';

  const autoCommit = _isTruthyFlag(options['auto-commit']) || _isTruthyFlag(options.autocommit);
  const setUpstream = _isTruthyFlag(options['set-upstream']) || _isTruthyFlag(options.upstream) || _isTruthyFlag(options.u);
  const dryRun = _isTruthyFlag(options['dry-run']);
  const forceWithLease = _isTruthyFlag(options['force-with-lease']) || _isTruthyFlag(options['with-lease']);

  const currentBranch = _runGitCommandSync(cwd, ['rev-parse', '--abbrev-ref', 'HEAD']);
  const branch = String(options.branch || options.b || currentBranch || 'main').trim() || 'main';

  const statusBefore = _runGitCommandSync(cwd, ['status', '--porcelain']);
  if (statusBefore && !dryRun) {
    if (!autoCommit) {
      throw new Error('检测到未提交改动。请先提交，或加 --auto-commit 自动提交后推送');
    }
    const commitMessage = String(
      options['commit-message']
      || options.m
      || `chore: sync before publish push (${new Date().toISOString().slice(0, 10)})`
    ).trim();
    printInfo('检测到未提交改动，正在自动提交...');
    _runGitCommandSync(cwd, ['add', '-A']);
    _runGitCommandSync(cwd, ['commit', '-m', commitMessage], { timeout: 120000 });
    printSuccess(`已自动提交: ${commitMessage}`);
  }

  let remoteUrl = '';
  try {
    remoteUrl = _runGitCommandSync(cwd, ['remote', 'get-url', remoteName]);
  } catch {
    remoteUrl = '';
  }

  if (!remoteUrl) {
    if (!repoInput) {
      throw new Error(`远程 ${remoteName} 不存在，且未提供 --repo。示例: --repo owner/repo`);
    }
    const targetUrl = _buildGitRemoteUrl(repoInput, platform, options);
    _runGitCommandSync(cwd, ['remote', 'add', remoteName, targetUrl]);
    remoteUrl = targetUrl;
    printSuccess(`已添加远程: ${remoteName} -> ${_maskRemoteUrl(remoteUrl)}`);
  } else if (repoInput) {
    const targetUrl = _buildGitRemoteUrl(repoInput, platform, options);
    if (_canonicalGitRemoteUrl(remoteUrl) !== _canonicalGitRemoteUrl(targetUrl)) {
      const allowUpdateRemote = _isTruthyFlag(options['force-remote']) || _isTruthyFlag(options['update-remote']);
      if (!allowUpdateRemote) {
        throw new Error(`远程 ${remoteName} 已存在且地址不同。加 --force-remote 可自动更新远程地址`);
      }
      _runGitCommandSync(cwd, ['remote', 'set-url', remoteName, targetUrl]);
      remoteUrl = targetUrl;
      printWarn(`已更新远程 ${remoteName}: ${_maskRemoteUrl(remoteUrl)}`);
    }
  }

  const pushArgs = ['push'];
  if (setUpstream) pushArgs.push('-u');
  if (forceWithLease) pushArgs.push('--force-with-lease');
  pushArgs.push(remoteName, branch);

  printInfo(`准备推送: ${remoteName}/${branch} (${platform})`);
  printInfo(`远程地址: ${_maskRemoteUrl(remoteUrl || '(unknown)')}`);

  if (dryRun) {
    printInfo(`Dry run: git ${pushArgs.join(' ')}`);
    return {
      dryRun: true,
      remoteName,
      remoteUrl,
      branch,
      platform,
    };
  }

  await _runCommandLive('git', pushArgs, {
    cwd,
    activity: `推送到 ${remoteName}/${branch}`,
  });
  printSuccess(`推送完成: ${remoteName}/${branch}`);
  return {
    remoteName,
    remoteUrl,
    branch,
    platform,
  };
}

async function _runCommandLive(command, args, opts = {}) {
  const cwd = opts.cwd || process.cwd();
  const env = opts.env || process.env;
  const activity = opts.activity || `${command} ${args.join(' ')}`;
  const heartbeatMs = _toInt(
    process.env.KHY_ACTIVITY_PULSE_MS || process.env.GATEWAY_ACTIVITY_PULSE_MS,
    HEARTBEAT_MS_DEFAULT,
    3000
  );

  printInfo(`开始: ${activity}`);
  const startedAt = Date.now();

  await new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const timer = setInterval(() => {
      const elapsed = _formatDuration(Date.now() - startedAt);
      printInfo(`${activity} 进行中 (${elapsed})`);
    }, heartbeatMs);
    timer.unref?.();

    const cleanup = () => clearInterval(timer);

    child.stdout.on('data', (buf) => {
      try { process.stdout.write(String(buf)); } catch { /* ignore */ }
    });
    child.stderr.on('data', (buf) => {
      try { process.stderr.write(String(buf)); } catch { /* ignore */ }
    });
    child.on('error', (err) => {
      cleanup();
      reject(err);
    });
    child.on('close', (code) => {
      cleanup();
      if (code === 0) {
        printSuccess(`完成: ${activity}`);
        resolve();
      } else {
        reject(new Error(`${activity} 失败 (exit ${code})`));
      }
    });
  });
}

async function _runSelfBugFix(options = {}) {
  const maxRounds = _toInt(options['max-rounds'] || options.maxRounds, 5, 1);
  const autoFix = options['auto-fix'] !== false && String(options['auto-fix'] || '').toLowerCase() !== 'false';
  const autoApprove = _isTruthyFlag(options.yes) || _isTruthyFlag(options['auto-approve']) || _isTruthyFlag(options.autoApprove);

  printInfo(`自修复流程启动: review -> fix -> verify (maxRounds=${maxRounds})`);
  const { handleReview } = require('./review');
  await handleReview({
    maxRounds,
    autoFix,
    autoApprove,
    yes: autoApprove,
  });
}

async function _runSelfPipPublish(selfAction, options = {}) {
  const skipFix = _isTruthyFlag(options['skip-fix']) || _isTruthyFlag(options.skipFix);
  if (!skipFix) {
    await _runSelfBugFix(options);
  } else {
    printWarn('已跳过自修复阶段（--skip-fix）');
  }

  const targetRepo = String(selfAction || '').toLowerCase() === 'self-testpypi' ? 'testpypi' : 'pypi';
  const nextOptions = {
    ...options,
    yes: options.yes !== undefined ? options.yes : true,
  };
  delete nextOptions['skip-fix'];
  delete nextOptions.skipFix;

  printInfo(`进入自发布阶段: 发布到 ${targetRepo}`);
  return handlePublish(targetRepo, [], nextOptions);
}

function _printState(state) {
  printInfo(`项目目录: ${state.projectRoot}`);
  printInfo(`包名: ${state.packageName || '(未读取到)'}`);
  printInfo(`版本(pyproject): ${state.versions.pyproject || '-'}`);
  printInfo(`版本(khy_quant): ${state.versions.python || '-'}`);
  printInfo(`版本(backend): ${state.versions.backend || '-'}`);
  if (!state.versionAligned) {
    printWarn('版本号未对齐（pyproject / khy_quant / backend 不一致）');
    printInfo('可用 --version <x.y.z> 一键同步版本');
  }
}

function _printHelp() {
  console.log('');
  console.log('  用法:');
  console.log('    khy publish check [--root <path>]');
  console.log('    khy publish build [--root <path>] [--clean]');
  console.log('    khy publish pypi [--version <x.y.z>] [--yes] [--skip-build]');
  console.log('    khy publish testpypi [--version <x.y.z>] [--yes] [--skip-build]');
  console.log('    khy publish docker-bundle [--out <dir>] [--name <bundle-name>]');
  console.log('    khy publish pip-dir-bundle [--out <dir>] [--name <bundle-name>] [--pip-root <site-packages>]');
  console.log('    khy publish npm-dir-bundle [--out <dir>] [--name <bundle-name>] [--npm-root <path>]');
  console.log('    khy publish origin-code [--out <dir>] [--name <bundle-name>] [--pip-root <site-packages>] [--npm-root <path>]');
  console.log('    khy publish self-fix [--max-rounds <n>] [--yes]');
  console.log('    khy publish self-pypi [--version <x.y.z>] [--skip-fix] [--yes]');
  console.log('    khy publish self-testpypi [--version <x.y.z>] [--skip-fix] [--yes]');
  console.log('    khy publish git-push [<owner/repo|remote-url>] [--platform github|gitee|gitlab]');
  console.log('');
  console.log('  常用参数:');
  console.log('    --version <x.y.z>     同步 3 处版本号后再构建');
  console.log('    --yes                 跳过上传确认（CI/自动化）');
  console.log('    --token <token>       指定 PyPI token（也可用环境变量）');
  console.log('    --skip-build          直接上传 dist/*');
  console.log('    --skip-db-preflight   跳过自动迁移预检');
  console.log('    --strict-db-preflight 自动迁移预检失败时中止');
  console.log('    --root <path>         指定项目根目录');
  console.log('    --out <dir>           导出包输出目录（docker 默认 dist/docker-bundles，origin 默认 dist/origin-code）');
  console.log('    --name <bundle-name>  导出包名称（不含扩展名）');
  console.log('    --install <auto|pip|npm> 安装布局探测模式（默认 auto）');
  console.log('    --pip-root <path>     指定 pip 安装根目录(site-packages)');
  console.log('    --npm-root <path>     指定 npm 安装根目录（backend 或其上级）');
  console.log('    --repo <owner/repo>   Git 远程仓库（也支持完整 SSH/HTTPS URL）');
  console.log('    --platform <name>     github | gitee | gitlab');
  console.log('    --remote <name>       Git 远程名（默认 origin 或平台名）');
  console.log('    --branch <name>       推送分支（默认当前分支）');
  console.log('    --auto-commit         推送前自动 add+commit 所有改动');
  console.log('    --set-upstream        push 时附加 -u');
  console.log('    --force-remote        远程同名但 URL 不同，自动 set-url');
  console.log('    --dry-run             演练模式：git 仅打印推送命令；PyPI/TestPyPI 仅检查并打印上传命令，不实际上传');
  console.log('    --max-rounds <n>      自修复轮数上限（self-fix/self-pypi）');
  console.log('    --skip-fix            自发布时跳过自修复阶段');
  console.log('    --auto-approve        自修复自动确认（与 --yes 等价）');
  console.log('    --secret <value>      源码发布密钥（origin-code/git-push，缺失或错误将进入扰乱发布）');
  console.log('    --owner-secret <value> 同 --secret');
  console.log('');
  console.log('  环境变量:');
  console.log('    PYPI_TOKEN / TEST_PYPI_TOKEN / TWINE_USERNAME / TWINE_PASSWORD');
  console.log('    KHY_SOURCE_PUBLISH_SECRET / KHY_OWNER_SECRET');
  console.log('    KHY_PYTHON / KHY_ACTIVITY_PULSE_MS / KHY_PUBLISH_SKIP_DB_PREFLIGHT');
  console.log('');
}

async function _runDbMigrationPreflight(options = {}) {
  const skip = _isTruthyFlag(options['skip-db-preflight']) || _isTruthyFlag(process.env.KHY_PUBLISH_SKIP_DB_PREFLIGHT);
  if (skip) {
    printWarn('已跳过自动迁移预检');
    return { skipped: true };
  }

  const strict = _isTruthyFlag(options['strict-db-preflight']) || _isTruthyFlag(process.env.KHY_PUBLISH_STRICT_DB_PREFLIGHT);
  try {
    const { runAutoDbMigration } = require('../../bootstrap/dbAutoMigration');
    const result = await runAutoDbMigration({
      force: true,
      silent: true,
      reason: 'publish-preflight',
    });
    if (result && result.error) {
      const message = `自动迁移预检失败: ${result.error}`;
      if (strict) throw new Error(message);
      printWarn(`${message}（继续发布，可加 --strict-db-preflight 阻止发布）`);
      return { ok: false, error: result.error };
    }
    printInfo('自动迁移预检通过');
    return { ok: true };
  } catch (err) {
    const message = err && err.message ? err.message : String(err || 'unknown');
    if (strict) throw new Error(`自动迁移预检失败: ${message}`);
    printWarn(`自动迁移预检异常: ${message}（继续发布）`);
    return { ok: false, error: message };
  }
}

async function _confirmUpload(targetRepo, packageName, version, options) {
  if (options.yes || options.confirm) return true;
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    printError('非交互环境请加 --yes 确认上传');
    return false;
  }
  const answer = await inquirer.prompt([{
    type: 'confirm',
    name: 'ok',
    default: false,
    message: `确认上传 ${packageName || 'package'} ${version || ''} 到 ${targetRepo} ?`,
  }]);
  return !!answer.ok;
}

async function _runBuildAndCheck(projectRoot, pythonCmd, cleanDist) {
  if (cleanDist) {
    const distPath = path.join(projectRoot, 'dist');
    if (fs.existsSync(distPath)) {
      fs.rmSync(distPath, { recursive: true, force: true });
      printInfo('已清理 dist/');
    }
  }

  try {
    await _runCommandLive(pythonCmd, ['-m', 'build'], {
      cwd: projectRoot,
      activity: '构建 Python 包',
    });
  } catch (firstErr) {
    printWarn('隔离构建失败，尝试使用 --no-isolation 离线构建...');
    await _runCommandLive(pythonCmd, ['-m', 'build', '--no-isolation'], {
      cwd: projectRoot,
      activity: '构建 Python 包(无隔离)',
    });
  }

  const artifacts = _collectDistArtifacts(projectRoot);
  if (artifacts.length === 0) {
    throw new Error('构建完成但 dist/ 下未找到可发布产物');
  }
  printInfo(`构建产物: ${artifacts.join(', ')}`);

  await _runCommandLive(pythonCmd, ['-m', 'twine', 'check', ...artifacts], {
    cwd: projectRoot,
    activity: '校验构建产物(twine check)',
  });
  return artifacts;
}

async function handlePublish(subCommand, args = [], options = {}) {
  const fallbackAction = String(args[0] || '').toLowerCase();
  const action = String(subCommand || fallbackAction || '').toLowerCase() || 'pypi';
  if (![
    'check', 'build', 'pypi', 'testpypi', 'help',
    ...DOCKER_BUNDLE_ACTIONS,
    ...PIP_INSTALL_BUNDLE_ACTIONS,
    ...NPM_INSTALL_BUNDLE_ACTIONS,
    ...ORIGIN_CODE_ACTIONS,
    ...GIT_PUSH_ACTIONS,
    ...SELF_FIX_ACTIONS,
    ...SELF_PUBLISH_ACTIONS,
  ].includes(action)) {
    printError(`未知 publish 子命令: ${action}`);
    _printHelp();
    _markFailure();
    return false;
  }
  if (action === 'help') {
    _printHelp();
    return true;
  }

  const startDir = options.root || options['project-root'] || process.cwd();
  const projectRoot = _findProjectRoot(startDir);

  let state = _readState(projectRoot);

  if (DOCKER_BUNDLE_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      _buildDockerBundle(projectRoot, state, options);
      return true;
    } catch (err) {
      printError(`Docker 部署包生成失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  if (PIP_INSTALL_BUNDLE_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      _buildPipInstallBundle(projectRoot, state, options);
      return true;
    } catch (err) {
      printError(`pip 安装目录部署包生成失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  if (NPM_INSTALL_BUNDLE_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      _buildPipInstallBundle(projectRoot, state, {
        ...options,
        install: options.install || 'npm',
      });
      return true;
    } catch (err) {
      printError(`npm 安装目录部署包生成失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  if (ORIGIN_CODE_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      const access = await _verifySourceReleaseAccess(options, '完整源码还原发布');
      if (!access.authorized) {
        printWarn('未通过源码发布密钥校验，已自动切换为扰乱后发布（核心技术内容将移除/扰乱）');
      }
      _buildOriginCodeBundle(projectRoot, state, {
        ...options,
        disturbed: !access.authorized,
      });
      return true;
    } catch (err) {
      printError(`origin code 还原包生成失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  if (GIT_PUSH_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      const access = await _verifySourceReleaseAccess(options, '源码仓库发布');
      const nextOptions = { ...options };
      if (!access.authorized) {
        nextOptions['dry-run'] = true;
        nextOptions.dryRun = true;
        printWarn('未通过源码发布密钥校验，已切换扰乱发布模式：仅输出推送计划，不执行真实源码推送');
      }
      await _runPublishGitPush(projectRoot, args, nextOptions);
      return true;
    } catch (err) {
      printError(`Git 推送失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  if (SELF_FIX_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      await _runSelfBugFix(options);
      printSuccess('自修复流程执行完成');
      return true;
    } catch (err) {
      printError(`自修复失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  if (SELF_PUBLISH_ACTIONS.has(action)) {
    printInfo(`项目目录: ${projectRoot}`);
    try {
      const normalized = action === 'self-release' ? 'self-pypi' : action;
      const ok = await _runSelfPipPublish(normalized, options);
      return !!ok;
    } catch (err) {
      printError(`自发布失败: ${err.message || err}`);
      _markFailure();
      return false;
    }
  }

  _printState(state);

  if (options.version) {
    _updateVersions(projectRoot, options.version);
    printSuccess(`版本已同步为 ${options.version}`);
    state = _readState(projectRoot);
    _printState(state);
  }

  const pythonCmd = _detectPython();
  if (!pythonCmd) {
    printError('未找到 Python 解释器（python3/python）');
    _markFailure();
    return false;
  }
  printInfo(`Python: ${pythonCmd}`);

  if (!_moduleReady(pythonCmd, 'build')) {
    printError('未安装 build 模块');
    printInfo(`运行: ${pythonCmd} -m pip install build`);
    _markFailure();
    return false;
  }
  if (!_moduleReady(pythonCmd, 'twine')) {
    printError('未安装 twine 模块');
    printInfo(`运行: ${pythonCmd} -m pip install twine`);
    _markFailure();
    return false;
  }

  if (!state.versionAligned && !options.force) {
    printError('版本未对齐，已中止。请使用 --version <x.y.z> 同步后重试，或加 --force 跳过。');
    _markFailure();
    return false;
  }

  try {
    await _runDbMigrationPreflight(options);
  } catch (err) {
    printError(err.message || String(err));
    _markFailure();
    return false;
  }

  if (action === 'check') {
    printSuccess('发布前检查通过');
    return true;
  }

  try {
    const cleanDist = options.clean !== false && String(options.clean || '').toLowerCase() !== 'false';
    if (action === 'build') {
      await _runBuildAndCheck(projectRoot, pythonCmd, cleanDist);
      printSuccess('构建流程完成');
      return true;
    }

    const targetRepo = action === 'testpypi' ? 'testpypi' : 'pypi';
    const uploadReady = _buildUploadEnv(targetRepo, options);
    if (!uploadReady.hasCredential) {
      printError(`未检测到 ${targetRepo} 上传凭据`);
      printInfo('可用方式:');
      printInfo('  1) 设置 PYPI_TOKEN / TEST_PYPI_TOKEN');
      printInfo('  2) 或配置 ~/.pypirc');
      printInfo('  3) 或命令加 --token <token>');
      _markFailure();
      return false;
    }

    const confirmed = await _confirmUpload(
      targetRepo,
      state.packageName,
      state.versions.pyproject,
      options
    );
    if (!confirmed) {
      printWarn('已取消上传');
      _markFailure();
      return false;
    }

    let artifacts = _collectDistArtifacts(projectRoot);
    const skipBuild = options['skip-build'] === true || String(options['skip-build'] || '').toLowerCase() === 'true';
    if (!skipBuild) {
      artifacts = await _runBuildAndCheck(projectRoot, pythonCmd, cleanDist);
    } else if (artifacts.length === 0) {
      printError('指定了 --skip-build，但 dist/ 下没有可上传文件');
      _markFailure();
      return false;
    }

    const uploadArgs = ['-m', 'twine', 'upload'];
    if (targetRepo === 'testpypi') {
      uploadArgs.push('--repository', 'testpypi');
    } else {
      uploadArgs.push('--repository', 'pypi');
    }
    const skipExisting = options['skip-existing'] !== false && String(options['skip-existing'] || '').toLowerCase() !== 'false';
    if (skipExisting) uploadArgs.push('--skip-existing');
    if (options['non-interactive'] || options.nonInteractive) uploadArgs.push('--non-interactive');
    uploadArgs.push(...artifacts);

    const uploadDryRun = _isTruthyFlag(options['dry-run']) || _isTruthyFlag(options.dryRun);
    if (uploadDryRun) {
      printInfo(`Dry run: ${pythonCmd} ${uploadArgs.join(' ')}`);
      printInfo(`Dry run: 目标仓库=${targetRepo}，产物数量=${artifacts.length}`);
      printSuccess('发布演练完成（未执行上传）');
      return true;
    }

    await _runCommandLive(pythonCmd, uploadArgs, {
      cwd: projectRoot,
      env: uploadReady.env,
      activity: `上传到 ${targetRepo}`,
    });

    const ver = state.versions.pyproject || '(unknown version)';
    printSuccess(`发布完成: ${state.packageName || 'package'} ${ver} -> ${targetRepo}`);
    return true;
  } catch (err) {
    printError(`发布失败: ${err.message || err}`);
    _markFailure();
    return false;
  }
}

module.exports = {
  handlePublish,
  // Exposed for testability / reuse
  _findProjectRoot,
  _readState,
  _updateVersions,
  _detectPython,
  _runDbMigrationPreflight,
};
