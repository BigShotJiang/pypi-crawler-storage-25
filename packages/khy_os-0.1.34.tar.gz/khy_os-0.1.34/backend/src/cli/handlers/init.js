/**
 * CLI Handlers: init (setup wizard) and doctor (environment diagnostic).
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const chalk = require('chalk').default || require('chalk');
const {
  printSuccess, printError, printWarn, printInfo, printTable, withSpinner,
  MASCOT_MINI, ICON_HEART, ICON_GEAR,
} = require('../formatters');

const ROOT = path.resolve(__dirname, '../../../');
const ENV_FILE = path.join(ROOT, '.env');
const BUILTIN_SENSENOVA_KEY = 'sensenova';
const BUILTIN_SENSENOVA_ENDPOINT = 'https://token.sensenova.cn/v1';
const BUILTIN_SENSENOVA_DEFAULT_MODEL = 'sensenova-6.7-flash-lite';
const BUILTIN_SENSENOVA_MODELS = ['sensenova-6.7-flash-lite', 'sensenova-u1-fast', 'deepseek-v4-flash'];

// ── Helper: silent command execution ─────────────────────────────────────────

function runSilent(cmd, args = []) {
  try {
    return execFileSync(cmd, args, { encoding: 'utf-8', timeout: 15000, stdio: ['pipe', 'pipe', 'pipe'] }).trim();
  } catch {
    return null;
  }
}

function runProbe(cmd, args = []) {
  try {
    const output = execFileSync(cmd, args, {
      encoding: 'utf-8',
      timeout: 15000,
      stdio: ['pipe', 'pipe', 'pipe'],
    }).trim();
    return { ok: true, output };
  } catch (err) {
    const toText = (v) => {
      if (v === null || v === undefined) return '';
      if (Buffer.isBuffer(v)) return v.toString('utf-8').trim();
      return String(v).trim();
    };
    const stderr = toText(err?.stderr);
    const stdout = toText(err?.stdout);
    const message = toText(err?.message) || 'unknown error';
    const combined = `${stderr} ${stdout} ${message}`.toLowerCase();

    const code = String(err?.code || '');
    if (code === 'ENOENT') return { ok: false, reason: 'missing' };
    if (code === 'EPERM' || code === 'EACCES') return { ok: false, reason: 'blocked' };
    if (code === 'ETIMEDOUT') return { ok: false, reason: 'timeout' };
    if (/permission denied|operation not permitted|sandbox|not allowed|access denied/i.test(combined)) {
      return { ok: false, reason: 'blocked', message };
    }
    if (/timed out|timeout|etimedout/i.test(combined)) {
      return { ok: false, reason: 'timeout', message };
    }
    if (/connection refused|could not connect|econnrefused|service unavailable|host is down/i.test(combined)) {
      return { ok: false, reason: 'unavailable', message: stderr || stdout || message };
    }
    return { ok: false, reason: 'error', message: stderr || stdout || message };
  }
}

function probeFailureDetail(probe, fallback = '未安装') {
  if (!probe || probe.ok) return '';
  if (probe.reason === 'blocked') return '检测受限（权限/沙箱限制）';
  if (probe.reason === 'timeout') return '检测超时';
  if (probe.reason === 'missing') return fallback;
  if (probe.reason === 'unavailable') return probe.message ? String(probe.message).slice(0, 160) : '服务不可用';
  return probe.message ? String(probe.message).slice(0, 160) : fallback;
}

function formatLocalTime(ts) {
  const n = Number(ts || 0);
  if (!Number.isFinite(n) || n <= 0) return '';
  try {
    return new Date(n).toLocaleString('zh-CN', { hour12: false });
  } catch {
    return new Date(n).toISOString();
  }
}

function isLocalAdapterName(name = '') {
  const lower = String(name || '').toLowerCase();
  if (!lower) return false;
  return ['local', 'ollama', 'llama'].some(token => lower.includes(token));
}

function _readJsonObject(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function _readJsonArray(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function ensureBuiltinSenseNovaProvider(options = {}) {
  const force = !!options.force;
  const os = require('os');
  const dataDir = path.join(os.homedir(), '.khyquant');
  const poolFile = path.join(dataDir, 'api_keys.json');
  const registryFile = path.join(dataDir, 'custom_providers.json');

  try { fs.mkdirSync(dataDir, { recursive: true }); } catch { /* ignore */ }

  // Merge SenseNova key entry into api_keys.json without overwriting other providers.
  const poolData = _readJsonObject(poolFile);
  const rawPoolEntries = Array.isArray(poolData[BUILTIN_SENSENOVA_KEY]) ? poolData[BUILTIN_SENSENOVA_KEY] : [];
  const hasBuiltinPoolEntry = rawPoolEntries.some((entry) => (
    entry
    && typeof entry === 'object'
    && String(entry.endpoint || '').trim() === BUILTIN_SENSENOVA_ENDPOINT
  ));

  if (force || !hasBuiltinPoolEntry) {
    const nextEntries = rawPoolEntries.slice();
    if (!hasBuiltinPoolEntry) {
      nextEntries.push({
        key: 'sk-VGIvz88JG36VuWGRnvjJrtT8tMv8mgUc',
        endpoint: BUILTIN_SENSENOVA_ENDPOINT,
        priority: 10,
        label: 'built-in',
      });
    } else if (force && nextEntries.length > 0) {
      nextEntries[0] = {
        ...nextEntries[0],
        endpoint: BUILTIN_SENSENOVA_ENDPOINT,
        priority: 10,
        label: nextEntries[0].label || 'built-in',
      };
    }
    poolData[BUILTIN_SENSENOVA_KEY] = nextEntries;
    fs.writeFileSync(poolFile, JSON.stringify(poolData, null, 2), 'utf-8');
  }

  // Merge SenseNova metadata into custom_providers.json without removing others.
  const registryData = _readJsonArray(registryFile);
  const idx = registryData.findIndex((item) => (
    item
    && typeof item === 'object'
    && String(item.poolKey || '').trim().toLowerCase() === BUILTIN_SENSENOVA_KEY
  ));
  const senseNovaMeta = {
    name: 'SenseNova',
    poolKey: BUILTIN_SENSENOVA_KEY,
    endpoint: BUILTIN_SENSENOVA_ENDPOINT,
    defaultModel: BUILTIN_SENSENOVA_DEFAULT_MODEL,
    serviceType: 'openai',
    models: BUILTIN_SENSENOVA_MODELS,
  };

  if (idx >= 0) {
    if (force) {
      registryData[idx] = senseNovaMeta;
      fs.writeFileSync(registryFile, JSON.stringify(registryData, null, 2), 'utf-8');
    }
  } else {
    registryData.push(senseNovaMeta);
    fs.writeFileSync(registryFile, JSON.stringify(registryData, null, 2), 'utf-8');
  }
}

// ── khy init ─────────────────────────────────────────────────────────────────

/**
 * Interactive initialization wizard using inquirer.
 * Lighter than setup.js — assumes Node deps are already installed.
 */
async function handleInit(options = {}) {
  const inquirer = require('inquirer');

  console.log('');
  console.log(`  ${ICON_GEAR} ${chalk.cyan.bold('khy OS 初始化向导')}`);
  console.log(chalk.dim('     快速配置环境，让系统正常运行'));
  console.log('');

  // Check what needs initialization
  const checks = runDoctorChecks();
  const issues = checks.filter(c => !c.ok);

  if (issues.length === 0 && !options.force) {
    printSuccess('环境检测正常，无需初始化');
    printInfo('如需强制重新初始化，请使用 init --force');
    return;
  }

  // Show current issues
  if (issues.length > 0) {
    console.log(chalk.yellow('  发现以下问题:'));
    issues.forEach(issue => {
      console.log(chalk.red('    ✗ ') + issue.label + ': ' + issue.detail);
    });
    console.log('');
  }

  // .env configuration
  if (!fs.existsSync(ENV_FILE) || options.force) {
    const { dbType } = await inquirer.prompt([{
      type: 'list',
      name: 'dbType',
      message: '选择数据库类型:',
      choices: [
        { name: 'SQLite (零配置，推荐开发)', value: 'sqlite' },
        { name: 'PostgreSQL (生产推荐)', value: 'postgres' },
      ],
    }]);

    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: '服务端口:',
      default: '3000',
      validate: (v) => /^\d+$/.test(v) ? true : '请输入数字',
    }]);

    let pgConfig = {};
    if (dbType === 'postgres') {
      pgConfig = (await inquirer.prompt([
        { type: 'input', name: 'dbHost', message: 'PostgreSQL 地址:', default: '127.0.0.1' },
        { type: 'input', name: 'dbPort', message: 'PostgreSQL 端口:', default: '5432' },
        { type: 'input', name: 'dbName', message: '数据库名称:', default: 'quant_trading' },
        { type: 'input', name: 'dbUser', message: '数据库用户:', default: 'postgres' },
        { type: 'password', name: 'dbPassword', message: '数据库密码 (留空自动生成):' },
      ]));
    }

    // Generate secure JWT secret
    const crypto = require('crypto');
    const jwtSecret = crypto.randomBytes(32).toString('hex');
    if (!pgConfig.dbPassword) pgConfig.dbPassword = crypto.randomBytes(16).toString('hex');

    const lines = [
      '# khy OS Environment Configuration',
      `# Generated: ${new Date().toISOString()}`,
      '',
      `DB_TYPE=${dbType}`,
    ];

    if (dbType === 'postgres') {
      lines.push(`DB_HOST=${pgConfig.dbHost}`);
      lines.push(`DB_PORT=${pgConfig.dbPort}`);
      lines.push(`DB_NAME=${pgConfig.dbName}`);
      lines.push(`DB_USER=${pgConfig.dbUser}`);
      lines.push(`DB_PASSWORD=${pgConfig.dbPassword}`);
    }

    lines.push('', `PORT=${port}`, 'NODE_ENV=development', 'LOG_LEVEL=info');
    lines.push('', `JWT_SECRET=${jwtSecret}`, 'JWT_EXPIRES_IN=7d');
    lines.push('', 'ENABLE_AKSHARE=true', 'ENABLE_TUSHARE=false', 'DEFAULT_DATA_SOURCE=reliable');
    lines.push('', '# AI Providers', '# GEMINI_API_KEY=', '# GROQ_API_KEY=');
    lines.push('',
      '# ── Provider 路由配置 ──',
      '# 内置示例: SenseNova (OpenAI-compatible)',
      'GATEWAY_API_POOL_SERVICE_MAP={"sensenova":"openai"}',
      'GATEWAY_API_POOL_DEFAULT_MODEL_MAP={"sensenova":"sensenova-u1-fast"}',
      'PROXY_MODEL_ROUTE_MAP={"sensenova-6.7-flash-lite":{"target":"api:sensenova:sensenova-6.7-flash-lite","strict":true},"sensenova-u1-fast":{"target":"api:sensenova:sensenova-u1-fast","strict":true},"deepseek-v4-flash":{"target":"api:sensenova:deepseek-v4-flash","strict":true}}',
      'PROXY_PRIMARY_ADAPTER=api',
      'GATEWAY_API_POOL_PROVIDER=sensenova',
      'GATEWAY_PREFERRED_MODEL=sensenova-u1-fast',
    );

    fs.writeFileSync(ENV_FILE, lines.join('\n') + '\n');
    // Restrict .env permissions to owner only (Unix)
    if (process.platform !== 'win32') {
      try { fs.chmodSync(ENV_FILE, 0o600); } catch { /* ignore */ }
    }
    printSuccess('.env 配置文件已生成');

  } else {
    printInfo('.env 已存在，跳过');
  }

  ensureBuiltinSenseNovaProvider({ force: !!options.force });
  printSuccess('内置 AI Provider (SenseNova) 已配置');

  // Database initialization
  const { shouldInitDb } = await inquirer.prompt([{
    type: 'confirm',
    name: 'shouldInitDb',
    message: '初始化数据库结构?',
    default: true,
  }]);

  if (shouldInitDb) {
    await withSpinner('初始化数据库...', async () => {
      const { bootstrap } = require('../bootstrap');
      await bootstrap({ syncSchema: true, silent: true });
    }, { muteOutput: true });
  }

  // Seed data
  const { shouldSeed } = await inquirer.prompt([{
    type: 'confirm',
    name: 'shouldSeed',
    message: '填充示例数据（策略、品种）?',
    default: true,
  }]);

  if (shouldSeed) {
    await withSpinner('填充示例数据...', async () => {
      const { execFileSync } = require('child_process');
      execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'seed.js')], {
        cwd: ROOT,
        stdio: 'pipe',
        timeout: 60000,
      });
    }, { muteOutput: true });
  }

  // AI key configuration
  const { configAi } = await inquirer.prompt([{
    type: 'confirm',
    name: 'configAi',
    message: '现在配置 AI 密钥?',
    default: false,
  }]);

  if (configAi) {
    const { handleGatewayConfig } = require('./gateway');
    await handleGatewayConfig();
  }

  console.log('');
  printSuccess('初始化完成！输入 help 查看可用命令');
  console.log('');
}

// ── khy doctor ───────────────────────────────────────────────────────────────

/**
 * Run all environment diagnostic checks and display results.
 */
async function handleDoctor() {
  console.log('');
  console.log(`  ${ICON_HEART} ${chalk.cyan.bold('khy OS 环境诊断')}`);
  console.log(chalk.dim('     检查系统环境是否满足运行要求'));
  console.log('');

  const checks = runDoctorChecks();

  // Group by category
  const categories = {};
  checks.forEach(check => {
    if (!categories[check.category]) categories[check.category] = [];
    categories[check.category].push(check);
  });

  let totalOk = 0;
  let totalFail = 0;
  let totalWarn = 0;

  for (const [category, items] of Object.entries(categories)) {
    console.log(chalk.cyan(`  ${category}`));
    items.forEach(item => {
      const icon = item.ok ? chalk.green('✓') : (item.level === 'warn' ? chalk.yellow('⚠') : chalk.red('✗'));
      const detail = item.detail ? chalk.dim(` — ${item.detail}`) : '';
      console.log(`    ${icon} ${item.label}${detail}`);
      if (item.ok) totalOk++;
      else if (item.level === 'warn') totalWarn++;
      else totalFail++;
    });
    console.log('');
  }

  // Summary
  const summary = [];
  if (totalOk > 0) summary.push(chalk.green(`${totalOk} 通过`));
  if (totalWarn > 0) summary.push(chalk.yellow(`${totalWarn} 警告`));
  if (totalFail > 0) summary.push(chalk.red(`${totalFail} 失败`));
  console.log(`  ${chalk.bold('总计:')} ${summary.join(' · ')}`);

  if (totalFail > 0) {
    console.log('');
    printInfo('运行 khy init 修复问题');
  } else if (totalWarn > 0) {
    console.log('');
    printInfo('所有核心功能正常，部分可选功能不可用');
  } else {
    console.log('');
    printSuccess('所有检查通过，系统就绪');
  }

  const localModelBlocked = checks.find(c => c.label === '本地模型可用性' && !c.ok);
  const localListenBlocked = checks.find(c => c.label === '本地监听能力' && !c.ok);
  if (localModelBlocked || localListenBlocked) {
    printInfo('检测到当前环境限制本地模型通道，可一键执行: `khy gateway prefer-remote`');
    printInfo('也可手动使用 `khy gateway model` 切换到 API/桥接通道');
  }
  const codexHealCheck = checks.find(c => c.label === 'Codex 自愈状态');
  if (codexHealCheck && codexHealCheck.level === 'warn') {
    printWarn('检测到 Codex 通道近期异常；建议先重启 Codex CLI 会话，再执行 `khy gateway status` 复查');
  }
  console.log('');
}

/**
 * Run all diagnostic checks, return array of { category, label, ok, detail, level }.
 */
function runDoctorChecks() {
  const results = [];
  let activeAdapterName = '';

  // ── Runtime ──────────────────────────────────────────────────────────────
  const nodeVer = process.version;
  const nodeMajor = parseInt(nodeVer.slice(1), 10);
  results.push({
    category: '运行环境',
    label: 'Node.js',
    ok: nodeMajor >= 16,
    detail: `${nodeVer} ${nodeMajor >= 16 ? '(≥16)' : '(需要 ≥16)'}`,
    level: 'error',
  });

  // Python
  let pythonCmd = null;
  let pythonBlocked = false;
  for (const cmd of ['python3', 'python', 'py']) {
    const probe = runProbe(cmd, ['--version']);
    if (!probe.ok) {
      if (probe.reason === 'blocked') pythonBlocked = true;
      continue;
    }
    const ver = probe.output;
    if (ver.includes('Python 3')) {
      pythonCmd = cmd;
      const match = ver.match(/Python (\d+\.\d+\.\d+)/);
      results.push({
        category: '运行环境',
        label: 'Python',
        ok: true,
        detail: `${match ? match[1] : ver} (${cmd})`,
        level: 'warn',
      });
      break;
    }
  }
  if (!pythonCmd) {
    results.push({
      category: '运行环境',
      label: 'Python',
      ok: false,
      detail: pythonBlocked ? '检测受限（权限/沙箱限制）' : '未安装 — 数据获取功能不可用',
      level: 'warn',
    });
  }

  // Git
  const gitProbe = runProbe('git', ['--version']);
  results.push({
    category: '运行环境',
    label: 'Git',
    ok: gitProbe.ok,
    detail: gitProbe.ok ? gitProbe.output : probeFailureDetail(gitProbe, '未安装'),
    level: 'warn',
  });

  // ── Python packages ──────────────────────────────────────────────────────
  if (pythonCmd) {
    const pipCmd = `${pythonCmd} -m pip`;
    for (const pkg of ['akshare']) {
      const installed = !!runSilent(pythonCmd, ['-m', 'pip', 'show', pkg]);
      results.push({
        category: 'Python 依赖',
        label: pkg,
        ok: installed,
        detail: installed ? '已安装' : '未安装',
        level: 'warn',
      });
    }
  }

  // ── Configuration ────────────────────────────────────────────────────────
  results.push({
    category: '项目配置',
    label: '.env 文件',
    ok: fs.existsSync(ENV_FILE),
    detail: fs.existsSync(ENV_FILE) ? '已配置' : '未找到 — 运行 khy init 生成',
    level: 'error',
  });

  // Check node_modules
  const hasNodeModules = fs.existsSync(path.join(ROOT, 'node_modules'));
  results.push({
    category: '项目配置',
    label: 'Node 依赖',
    ok: hasNodeModules,
    detail: hasNodeModules ? '已安装' : '未安装 — 运行 npm install',
    level: 'error',
  });

  // ── Database ─────────────────────────────────────────────────────────────
  // Check if .env has DB_TYPE and if SQLite file exists
  if (fs.existsSync(ENV_FILE)) {
    const envContent = fs.readFileSync(ENV_FILE, 'utf-8');
    const dbType = envContent.match(/DB_TYPE=(\w+)/)?.[1] || 'auto';

    results.push({
      category: '数据库',
      label: '数据库类型',
      ok: true,
      detail: dbType,
      level: 'info',
    });

    if (dbType === 'sqlite' || dbType === 'auto') {
      // Check for SQLite file in common locations
      const sqliteLocations = [
        path.join(ROOT, 'data', 'khy-quant.db'),
        path.join(ROOT, 'khy-quant.db'),
        path.join(ROOT, 'data', 'database.sqlite'),
      ];
      const dbExists = sqliteLocations.some(p => fs.existsSync(p));
      results.push({
        category: '数据库',
        label: 'SQLite 数据文件',
        ok: dbExists,
        detail: dbExists ? '已创建' : '未创建 — 运行 khy db init',
        level: 'warn',
      });
    }
  }

  // ── Network services ─────────────────────────────────────────────────────
  // Redis check
  const redisProbe = runProbe('redis-cli', ['ping']);
  const redisOk = redisProbe.ok && /pong/i.test(String(redisProbe.output || ''));
  const redisOptional = redisProbe.reason === 'missing' || redisProbe.reason === 'blocked';
  let redisDetail = '未运行 — 将使用内存缓存';
  if (redisOk) {
    redisDetail = '运行中';
  } else if (redisProbe.reason === 'missing') {
    redisDetail = '未安装 redis-cli — 跳过服务探测，将使用内存缓存';
  } else if (redisProbe.reason === 'blocked') {
    redisDetail = '检测受限（权限/沙箱限制）— 跳过服务探测，将使用内存缓存';
  } else if (redisProbe.reason === 'timeout') {
    redisDetail = '探测超时 — 将使用内存缓存';
  } else if (redisProbe.reason === 'unavailable') {
    redisDetail = 'Redis 未响应 — 将使用内存缓存';
  }
  results.push({
    category: '可选服务',
    label: 'Redis',
    ok: redisOk || redisOptional,
    detail: redisDetail,
    level: redisOk || redisOptional ? 'info' : 'warn',
  });

  // AI provider check
  if (fs.existsSync(ENV_FILE)) {
    const envContent = fs.readFileSync(ENV_FILE, 'utf-8');
    const aiKeys = [
      'GEMINI_API_KEY', 'GROQ_API_KEY', 'OPENROUTER_API_KEY',
      'ZHIPU_API_KEY', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY',
    ];
    const hasAiKey = aiKeys.some(key => {
      const match = envContent.match(new RegExp(`^${key}=(.+)$`, 'm'));
      return match && match[1] && !match[1].startsWith('#');
    });
    results.push({
      category: '可选服务',
      label: 'AI 密钥',
      ok: hasAiKey,
      detail: hasAiKey ? '已配置' : '未配置 — 运行 khy ai config',
      level: 'warn',
    });
  }

  // ── AI Gateway & Tool Calling ─────────────────────────────────────────
  try {
    const aiGateway = require('../../services/gateway/aiGateway');
    const active = aiGateway.getActiveAdapter();
    activeAdapterName = String(active?.name || '');
    results.push({
      category: 'AI 能力',
      label: 'AI 网关',
      ok: !!active,
      detail: active ? `${active.name}${active.activeModel ? ' · ' + active.activeModel : ''}` : '无可用适配器',
      level: 'warn',
    });
  } catch {
    results.push({
      category: 'AI 能力',
      label: 'AI 网关',
      ok: false,
      detail: '加载失败',
      level: 'warn',
    });
  }
  const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '');
  const localModelExpected = isLocalAdapterName(preferredAdapter) || isLocalAdapterName(activeAdapterName);

  try {
    const codexAdapter = require('../../services/gateway/adapters/codexAdapter');
    const runtimeDiag = typeof codexAdapter.getRuntimeDiagnostics === 'function'
      ? codexAdapter.getRuntimeDiagnostics()
      : null;
    const hasRecentRecord = runtimeDiag && Number(runtimeDiag.at) > 0;
    if (!hasRecentRecord) {
      results.push({
        category: 'AI 能力',
        label: 'Codex 自愈状态',
        ok: true,
        detail: '无近期自愈记录',
        level: 'info',
      });
    } else {
      const atText = formatLocalTime(runtimeDiag.at);
      const diagnosis = String(runtimeDiag.diagnosis || '').replace(/\s+/g, ' ').trim();
      const lastError = String(runtimeDiag.lastError || '').replace(/\s+/g, ' ').trim();
      const healed = !!runtimeDiag.healed;
      const detailParts = [
        healed ? '已执行自愈（sandbox=none，仅当前进程）' : '检测到通道异常，未触发自愈',
      ];
      if (atText) detailParts.push(`时间: ${atText}`);
      if (diagnosis) detailParts.push(`自检: ${diagnosis.slice(0, 200)}`);
      if (lastError) detailParts.push(`错误: ${lastError.slice(0, 120)}`);
      results.push({
        category: 'AI 能力',
        label: 'Codex 自愈状态',
        ok: healed,
        detail: detailParts.join('；'),
        level: healed ? 'info' : 'warn',
      });
    }
  } catch {
    results.push({
      category: 'AI 能力',
      label: 'Codex 自愈状态',
      ok: true,
      detail: '诊断不可用',
      level: 'info',
    });
  }

  // Local loopback listen capability (required by local runner/python/http backends)
  const loopbackProbe = runProbe(process.execPath, [
    '-e',
    'const n=require("net");const s=n.createServer();s.once("error",e=>{console.log("ERR:"+((e&&e.message)||e));process.exit(2)});s.listen(0,"127.0.0.1",()=>{s.close(()=>{console.log("OK");process.exit(0)})});setTimeout(()=>{console.log("ERR:loopback listen probe timed out (1.2s)");process.exit(3)},1200)',
  ]);
  const loopbackBlocked = !loopbackProbe.ok;
  const loopbackDetail = loopbackProbe.ok
    ? '可监听 127.0.0.1（本地模型后端可启动）'
    : (localModelExpected
      ? `受限：${probeFailureDetail(loopbackProbe, loopbackProbe.message ? loopbackProbe.message.slice(0, 120) : 'listen 失败')}`
      : `受限：${probeFailureDetail(loopbackProbe, 'listen 失败')}（当前未启用本地模型，可忽略）`);
  results.push({
    category: 'AI 能力',
    label: '本地监听能力',
    ok: loopbackProbe.ok || !localModelExpected,
    detail: loopbackDetail,
    level: localModelExpected ? 'warn' : 'info',
  });

  // bundled ollama-runner capability
  const bundledRunnerCandidates = [
    path.resolve(__dirname, '../../../bin/ollama-runner/bin/ollama'),
    path.resolve(__dirname, '../../../bin/ollama-runner/bin/ollama.exe'),
  ];
  const bundledRunner = bundledRunnerCandidates.find(p => fs.existsSync(p)) || '';
  const bundledRunnerProbe = bundledRunner ? runProbe(bundledRunner, ['runner', '--help']) : { ok: false, reason: 'missing' };
  const systemRunnerProbe = runProbe(process.platform === 'win32' ? 'ollama.exe' : 'ollama', ['runner', '--help']);
  const runnerProbe = bundledRunnerProbe.ok ? bundledRunnerProbe : systemRunnerProbe;
  const runnerSource = bundledRunnerProbe.ok ? 'bundled' : (systemRunnerProbe.ok ? 'system' : 'none');
  const runnerBaseDetail = runnerProbe.ok
    ? (runnerSource === 'bundled' ? '可执行（内置二进制）' : '可执行（系统 ollama）')
    : (bundledRunner ? probeFailureDetail(runnerProbe, '不可执行') : '未找到二进制');
  results.push({
    category: 'AI 能力',
    label: 'ollama-runner',
    ok: runnerProbe.ok || !localModelExpected,
    detail: runnerProbe.ok
      ? runnerBaseDetail
      : (localModelExpected ? runnerBaseDetail : `${runnerBaseDetail}（当前未启用本地模型，可忽略）`),
    level: localModelExpected ? 'warn' : 'info',
  });

  // bundled llama-cpp binary capability
  const bundledLlamaRoot = path.resolve(__dirname, '../../../bin/llama-cpp');
  const bundledLlamaCandidates = [
    path.join(bundledLlamaRoot, 'llama-completion'),
    path.join(bundledLlamaRoot, 'llama-cli'),
  ];
  if (fs.existsSync(bundledLlamaRoot)) {
    try {
      const dirs = fs.readdirSync(bundledLlamaRoot, { withFileTypes: true })
        .filter(d => d.isDirectory())
        .map(d => d.name);
      for (const dir of dirs) {
        bundledLlamaCandidates.push(path.join(bundledLlamaRoot, dir, 'llama-completion'));
        bundledLlamaCandidates.push(path.join(bundledLlamaRoot, dir, 'llama-cli'));
      }
    } catch { /* ignore */ }
  }
  const bundledLlamaBin = bundledLlamaCandidates.find(p => fs.existsSync(p));
  const bundledLlamaProbe = bundledLlamaBin
    ? runProbe(bundledLlamaBin, ['--help'])
    : { ok: false, reason: 'missing' };
  const llamaBaseDetail = bundledLlamaProbe.ok
    ? '已内置（可离线推理）'
    : (bundledLlamaBin ? probeFailureDetail(bundledLlamaProbe, '不可执行') : '未找到二进制');
  results.push({
    category: 'AI 能力',
    label: 'llama-cpp binary',
    ok: bundledLlamaProbe.ok || !localModelExpected,
    detail: bundledLlamaProbe.ok
      ? llamaBaseDetail
      : (localModelExpected ? llamaBaseDetail : `${llamaBaseDetail}（当前未启用本地模型，可忽略）`),
    level: localModelExpected ? 'warn' : 'info',
  });

  // node-llama-cpp direct backend availability
  const llamaCppProbe = runProbe(process.execPath, [
    '-e',
    `require.resolve("node-llama-cpp",{paths:[${JSON.stringify(path.join(ROOT, 'backend'))}]});console.log("OK")`,
  ]);
  const hasBundledLocalBackend = runnerProbe.ok || bundledLlamaProbe.ok;
  const nodeLlamaDetail = llamaCppProbe.ok
    ? '已安装（可用进程内本地推理）'
    : (hasBundledLocalBackend
      ? '未安装（已内置 runner/llama-cpp，可正常本地推理）'
      : (localModelExpected
        ? '未安装 — 本地模型仅能依赖 runner/python/http 后端'
        : '未安装（当前未启用本地模型，可忽略）'));
  results.push({
    category: 'AI 能力',
    label: 'node-llama-cpp',
    ok: llamaCppProbe.ok || hasBundledLocalBackend || !localModelExpected,
    detail: nodeLlamaDetail,
    level: localModelExpected && loopbackBlocked && !hasBundledLocalBackend ? 'warn' : 'info',
  });

  if (localModelExpected && loopbackBlocked && !llamaCppProbe.ok && !hasBundledLocalBackend) {
    results.push({
      category: 'AI 能力',
      label: '本地模型可用性',
      ok: false,
      detail: '当前环境无法启动本地模型后端（监听受限且无 node-llama-cpp）',
      level: 'warn',
    });
  }

  // Tool calling support
  try {
    const toolCalling = require('../../services/toolCalling');
    const tools = toolCalling.listTools();
    results.push({
      category: 'AI 能力',
      label: '工具调用',
      ok: tools.length > 0,
      detail: `${tools.length} 个工具注册`,
      level: 'info',
    });

    const dangerMode = toolCalling.isDangerousMode();
    results.push({
      category: 'AI 能力',
      label: '安全模式',
      ok: !dangerMode,
      detail: dangerMode ? '⚠ 危险模式已开启 (跳过权限确认)' : '正常 (工具调用需确认)',
      level: dangerMode ? 'warn' : 'info',
    });
  } catch { /* ignore */ }

  // MCP servers
  try {
    const { loadMCPConfig } = require('../../services/mcpClient');
    const mcpConfig = loadMCPConfig();
    const serverCount = mcpConfig.servers?.length || 0;
    const enabledCount = mcpConfig.servers?.filter(s => s.enabled !== false).length || 0;
    results.push({
      category: 'AI 能力',
      label: 'MCP 服务器',
      ok: true,
      detail: serverCount > 0 ? `${enabledCount}/${serverCount} 已启用` : '未配置 — 在 ~/.khyquant/mcp.json 中添加',
      level: 'info',
    });
  } catch { /* ignore */ }

  // ── Ecosystem ─────────────────────────────────────────────────────────
  try {
    const skillRegistry = require('../../services/skillRegistry');
    const installed = skillRegistry.getInstalledSkills();
    results.push({
      category: '生态系统',
      label: 'Skills',
      ok: true,
      detail: `5 内置 + ${installed.length} 已安装`,
      level: 'info',
    });
  } catch { /* ignore */ }

  try {
    const cloudSync = require('../../services/cloudSync');
    const loggedIn = cloudSync.isLoggedIn();
    results.push({
      category: '生态系统',
      label: '云端连接',
      ok: loggedIn,
      detail: loggedIn ? `已登录 (${cloudSync.getUsername()})` : '未登录 — 可选: khy cloud login',
      level: loggedIn ? 'info' : 'warn',
    });
  } catch { /* ignore */ }

  // User profile
  try {
    const userProfile = require('../../services/userProfile');
    const profile = userProfile.getProfile();
    results.push({
      category: '生态系统',
      label: '用户画像',
      ok: true,
      detail: `等级: ${profile.skillLevel || 'beginner'} · 命令: ${profile.commandCount || 0}次`,
      level: 'info',
    });
  } catch { /* ignore */ }

  return results;
}

module.exports = { handleInit, handleDoctor, runDoctorChecks };
