/**
 * Learning & growth CLI handlers: growth, agent, prompt, voice, knowledge, habit.
 */
const chalkModule = require('chalk');
const chalk = chalkModule.default || chalkModule;
const { printSuccess, printError, printWarn, printInfo } = require('../formatters');

async function handleGrowth(subCommand, args, options) {
  const growthSvc = require('../../services/growthService');

  if (!subCommand) {
    // Show growth summary
    const summary = growthSvc.getGrowthSummary();
    const { getLevelProgress } = require('../../services/knowledgeTeachingService');
    const level = getLevelProgress();

    console.log(chalk.bold('\n  🌱 成长档案\n'));
    console.log(chalk.dim('  知识等级: ') + chalk.cyan(`${level.levelName} (${level.xp} XP)`) + chalk.dim(level.xpToNext > 0 ? ` → 下一级还需 ${level.xpToNext} XP` : ' (已满级)'));
    console.log(chalk.dim('  已学话题: ') + chalk.white(`${level.completedTopics} / ${level.totalTopics}`));
    console.log(chalk.dim('  总交互数: ') + chalk.white(summary.totalInteractions.toLocaleString()));
    console.log(chalk.dim('  策略记录: ') + chalk.white(summary.strategyRecords));
    console.log(chalk.dim('  Agent均准确率: ') + chalk.white(`${summary.avgAgentAccuracy}%`));
    if (summary.topSymbols.length > 0) {
      console.log(chalk.dim('  常用标的: ') + chalk.white(summary.topSymbols.join(', ')));
    }
    console.log(chalk.dim('  快照数: ') + chalk.white(summary.snapshots));
    console.log(chalk.dim('  上次更新: ') + chalk.white(summary.lastModified || '—'));
    console.log(chalk.dim('\n  命令:'));
    console.log(chalk.dim('    growth export [--path ./backup.tar.gz]  导出成长档案'));
    console.log(chalk.dim('    growth import <文件>                    导入合并'));
    console.log(chalk.dim('    growth snapshot                         创建快照'));
    console.log(chalk.dim('    growth snapshots                        查看快照列表'));
    console.log(chalk.dim('    growth restore <快照ID>                 恢复到快照'));
    console.log(chalk.dim('    growth reset                            重置 (不可逆)'));
    console.log('');

  } else if (subCommand === 'export') {
    const outputPath = options.path || args[0] || null;
    const exported = growthSvc.exportGrowth(outputPath);
    printSuccess(`成长档案已导出: ${exported}`);
    printInfo('复制此文件到另一台机器，使用 growth import 导入即可迁移成长数据');

  } else if (subCommand === 'import') {
    const file = args[0];
    if (!file) { printError('用法: growth import <归档文件路径>'); return; }
    try {
      const result = growthSvc.importGrowth(file);
      printSuccess(`导入成功: 来自 ${result.importedFrom}, 合并了 ${result.filesImported} 个文件`);
      printInfo(`原始导出时间: ${result.exportedAt}`);
    } catch (err) { printError(err.message); }

  } else if (subCommand === 'snapshot') {
    const snap = growthSvc.createSnapshot();
    printSuccess(`快照已创建: ${snap.snapshotId}`);

  } else if (subCommand === 'snapshots') {
    const snaps = growthSvc.listSnapshots();
    if (snaps.length === 0) {
      printInfo('暂无快照。使用 growth snapshot 创建');
    } else {
      console.log(chalk.bold('\n  📸 成长快照\n'));
      snaps.forEach(s => {
        console.log(chalk.dim('  ') + chalk.cyan(s.id) + chalk.dim(` (${(s.size / 1024).toFixed(1)} KB)`));
      });
      console.log('');
    }

  } else if (subCommand === 'restore') {
    const snapId = args[0];
    if (!snapId) { printError('用法: growth restore <快照ID>'); return; }
    try {
      const result = growthSvc.restoreSnapshot(snapId);
      printSuccess(`已恢复到快照: ${result.restored} (${result.files} 个文件)`);
    } catch (err) { printError(err.message); }

  } else if (subCommand === 'reset') {
    printWarn('⚠ 这将清除所有成长数据（不可逆）');
    const readline = require('readline');
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const confirm = await new Promise(resolve => {
      rl.question(chalk.yellow('  确认重置？输入 YES: '), ans => { rl.close(); resolve(ans.trim()); });
    });
    if (confirm === 'YES') {
      growthSvc.resetGrowth();
      printSuccess('成长数据已重置');
    } else {
      printInfo('已取消');
    }
  }
}

async function handleAgent(subCommand, args, options) {
  const agentComm = require('../../services/agentCommunicationService');

  if (!subCommand || subCommand === 'status') {
    const stats = agentComm.getAgentStats();
    console.log(chalk.bold('\n  🤖 智能体状态\n'));
    for (const [id, agent] of Object.entries(stats)) {
      const accColor = agent.accuracy >= 70 ? chalk.green : agent.accuracy >= 50 ? chalk.yellow : chalk.red;
      console.log(chalk.cyan(`  ${agent.name}`) + chalk.dim(` (${id})`));
      console.log(chalk.dim('    准确率: ') + accColor(`${agent.accuracy}%`) + chalk.dim(` · 预测次数: ${agent.totalPredictions}`));
      if (agent.strongDomains.length > 0) {
        console.log(chalk.dim('    强项: ') + chalk.green(agent.strongDomains.join(', ')));
      }
      if (agent.weakDomains.length > 0) {
        console.log(chalk.dim('    弱项: ') + chalk.red(agent.weakDomains.join(', ')));
      }
    }
    console.log('');

  } else if (subCommand === 'task') {
    const desc = args.join(' ');
    if (!desc) { printError('用法: agent task "分析任务描述" [--agents fundamental,technical,trader]'); return; }
    const agentList = options.agents ? options.agents.split(',') : null;
    printInfo(`发起多智能体任务: ${desc}`);
    if (agentList) printInfo(`参与智能体: ${agentList.join(', ')}`);

    const task = await agentComm.executeCustomTask(desc, agentList, { symbol: options.symbol });
    console.log(chalk.bold('\n  📋 多智能体任务配置\n'));
    console.log(chalk.dim('  任务ID: ') + chalk.white(task.correlationId.slice(0, 8)));
    for (const [id, info] of Object.entries(task.agents)) {
      console.log(chalk.cyan(`  ${info.name}`) + chalk.dim(` · 可靠度: ${info.reliability}%`));
    }
    console.log(chalk.dim('\n  提示: AI 对话中会利用上述智能体协作分析'));
    console.log('');

  } else if (subCommand === 'memory') {
    const ctx = agentComm.getSharedContext();
    console.log(chalk.bold('\n  🧠 智能体共享记忆\n'));
    console.log(chalk.dim('  市场状态: ') + chalk.white(ctx.sharedContext?.currentMarketRegime || '未知'));
    const signals = ctx.sharedContext?.recentSignals || [];
    if (signals.length > 0) {
      console.log(chalk.dim('  近期信号:'));
      signals.slice(-5).forEach(s => {
        console.log(chalk.dim('    ') + chalk.white(`${s.type} ${s.symbol || ''} ${s.direction || ''}`));
      });
    }
    const insights = ctx.sharedContext?.crossAgentInsights || [];
    if (insights.length > 0) {
      console.log(chalk.dim('  跨Agent洞察:'));
      insights.slice(-3).forEach(i => {
        console.log(chalk.dim('    ') + chalk.white(i.content || JSON.stringify(i).slice(0, 80)));
      });
    }
    console.log(chalk.dim('  上次更新: ') + chalk.white(ctx.sharedContext?.lastUpdated || '—'));
    console.log('');

  } else if (subCommand === 'collaborate') {
    const collaborators = agentComm.getAvailableCollaborators();
    console.log(chalk.bold('\n  🔗 多IDE协作模型\n'));
    if (collaborators.length === 0) {
      printInfo('未检测到可协作的 IDE/模型');
    } else {
      collaborators.forEach(c => {
        console.log(chalk.dim('  ') + chalk.green('●') + ` ${c.name}` + chalk.dim(` (${c.type})`));
      });
      printInfo(`共 ${collaborators.length} 个模型可参与协作`);
    }
    console.log('');
  }
}

async function handlePrompt(subCommand, args, options) {
  const promptLib = require('../../services/promptLibraryService');

  if (!subCommand || subCommand === 'list') {
    const folder = args[0] || null;
    const prompts = promptLib.listPrompts(folder);
    if (prompts.length === 0) {
      printInfo('暂无保存的提示词。使用 prompt save "标题" "内容" 保存');
    } else {
      console.log(chalk.bold('\n  📝 提示词库\n'));
      prompts.forEach(p => {
        const used = p.usedCount > 0 ? chalk.dim(` (使用 ${p.usedCount} 次)`) : '';
        console.log(chalk.cyan(`  [${p.id}]`) + ` ${p.title}` + used + chalk.dim(` · ${p.folder}`));
      });
      console.log(chalk.dim(`\n  共 ${prompts.length} 条 · 目录: ${promptLib.getPromptDir()}`));
      console.log('');
    }

  } else if (subCommand === 'save') {
    const title = args[0];
    const content = args.slice(1).join(' ') || options.content;
    if (!title || !content) {
      printError('用法: prompt save "标题" "提示词内容" [--folder 分类] [--tags tag1,tag2]');
      return;
    }
    const tags = options.tags ? options.tags.split(',') : [];
    const folder = options.folder || options.f || null;
    const result = promptLib.savePrompt({ title, content, tags }, folder);
    printSuccess(`提示词已保存: ${result.title} [${result.id}]`);
    printInfo(`路径: ${result.path}`);

  } else if (subCommand === 'use') {
    const id = args[0];
    if (!id) { printError('用法: prompt use <ID>'); return; }
    const content = promptLib.usePrompt(id);
    if (content) {
      // Forward to AI
      return { aiForward: content };
    } else {
      printError(`未找到提示词: ${id}`);
    }

  } else if (subCommand === 'delete') {
    const id = args[0];
    if (!id) { printError('用法: prompt delete <ID>'); return; }
    if (promptLib.deletePrompt(id)) {
      printSuccess('已删除');
    } else {
      printError(`未找到: ${id}`);
    }

  } else if (subCommand === 'search') {
    const keyword = args.join(' ');
    if (!keyword) { printError('用法: prompt search <关键词>'); return; }
    const results = promptLib.searchPrompts(keyword);
    if (results.length === 0) {
      printInfo(`未找到匹配 "${keyword}" 的提示词`);
    } else {
      results.forEach(p => {
        console.log(chalk.cyan(`  [${p.id}]`) + ` ${p.title}` + chalk.dim(` · ${p.folder}`));
      });
    }

  } else if (subCommand === 'folder') {
    const action = args[0];
    if (action === 'new' || action === 'create') {
      const name = args[1];
      if (!name) { printError('用法: prompt folder new <名称>'); return; }
      const result = promptLib.createFolder(name);
      if (result.success) printSuccess(`文件夹已创建: ${result.path}`);
      else printError(result.error);
    } else {
      const folders = promptLib.listFolders();
      console.log(chalk.bold('\n  📂 提示词文件夹\n'));
      folders.forEach(f => console.log(chalk.dim('  ') + chalk.cyan(f)));
      console.log('');
    }

  } else if (subCommand === 'dir') {
    const newDir = args[0];
    if (newDir) {
      if (promptLib.setPromptDir(newDir)) {
        printSuccess(`提示词目录已设置: ${newDir}`);
      } else {
        printError('目录设置失败');
      }
    } else {
      printInfo(`当前提示词目录: ${promptLib.getPromptDir()}`);
      printInfo('设置新目录: prompt dir /path/to/your/folder');
    }
  }
}

async function handleVoice() {
  // Voice control placeholder — future integration with Windows Win+H
  console.log(chalk.bold('\n  🎤 语音控制 (预览)\n'));
  printInfo('语音控制功能正在开发中...');
  console.log('');
  console.log(chalk.dim('  计划支持:'));
  console.log(chalk.dim('  • Windows Win+H 语音输入集成'));
  console.log(chalk.dim('  • 语音命令识别 → 自动执行'));
  console.log(chalk.dim('  • 语音播报分析结果'));
  console.log(chalk.dim('  • 免手操作量化交易'));
  console.log('');
  console.log(chalk.dim('  当前可用: 使用系统语音输入 (Win+H) 直接在命令行输入'));
  console.log(chalk.dim('  提示: Win+H 的语音文字会自动输入到当前终端光标位置'));
  console.log('');
}

async function handleKnowledge(subCommand, args, options) {
  const kts = require('../../services/knowledgeTeachingService');

  if (subCommand === 'search') {
    const query = args.join(' ');
    if (!query) { printError('请输入搜索关键词'); return; }
    const results = kts.searchKnowledge(query);
    if (results.length === 0) {
      printInfo(`未找到与 "${query}" 相关的知识`);
    } else {
      console.log(chalk.bold(`\n  📚 知识库搜索: "${query}" (${results.length} 条)\n`));
      for (const r of results.slice(0, 10)) {
        const src = r.source === 'builtin' ? chalk.green('内置') : r.source === 'community' ? chalk.blue('社区') : chalk.cyan('学习');
        console.log(`  ${src} ${chalk.white(r.title)} [${r.category}]`);
        console.log(`  ${chalk.dim(r.content.slice(0, 100))}${r.content.length > 100 ? '...' : ''}`);
        console.log('');
      }
    }
    return;
  }

  if (subCommand === 'stats') {
    const stats = kts.getKnowledgeStats();
    console.log(chalk.bold('\n  📊 知识库统计\n'));
    console.log(`  内置知识:    ${chalk.bold(stats.builtinCount)} 条`);
    console.log(`  学习积累:    ${chalk.bold(stats.learnedCount)} 条`);
    console.log(`  总计:        ${chalk.bold(stats.totalCount)} 条`);
    if (Object.keys(stats.learnedCategories).length > 0) {
      console.log(chalk.dim('\n  学习知识分类:'));
      for (const [cat, count] of Object.entries(stats.learnedCategories)) {
        console.log(`    ${cat}: ${count}`);
      }
    }
    console.log('');
    return;
  }

  if (subCommand === 'self') {
    const aiCli = require('../ai');
    const studyMode = !!(aiCli.isStudyMode && aiCli.isStudyMode());
    let runtimeAdapter = null;
    let runtimeModel = null;
    try {
      const gw = require('../../services/gateway/aiGateway');
      const active = gw.getActiveAdapter?.();
      runtimeAdapter = active?.name || null;
      runtimeModel = active?.activeModel || active?.name || null;
    } catch { /* best effort */ }

    const profile = kts.getSelfAwarenessProfile({
      studyMode,
      adapter: runtimeAdapter,
      model: runtimeModel,
      effort: aiCli.getEffort ? aiCli.getEffort() : null,
    });
    const lines = kts.formatSelfAwarenessProfile(profile);
    console.log('');
    for (const line of lines) {
      console.log(`  ${line}`);
    }
    console.log('');
    printInfo('建议: 开启学习模式后提问，系统会按“能力边界→学习路径→练习检查点”方式回答');
    return;
  }

  if (subCommand === 'sync') {
    const syncAction = args[0];

    if (syncAction === 'config') {
      const repo = args[1];
      if (!repo) {
        printError('请指定仓库地址');
        printInfo('用法: knowledge sync config <owner/repo> [--platform github|gitee|gitlab] [--token <PAT>]');
        return;
      }
      const result = kts.configureKBSync({
        repo,
        platform: options.platform || null,
        token: options.token || null,
        isPublic: !options.private,
      });
      printSuccess(`知识库同步已配置: ${result.platform}/${result.repo}`);
      printInfo(`类型: ${result.isPublic ? '公共贡献' : '私人备份'} | 自动同步: ${result.autoSync ? '开' : '关'}`);
      return;
    }

    if (syncAction === 'push') {
      const result = kts.syncKBToGitHub();
      if (result.success) {
        printSuccess(`知识库已同步到 ${result.platform || 'github'}/${result.repo || ''}`);
        printInfo(`文件: ${result.filename}`);
      } else {
        printError(result.error);
        if (result.hint) printInfo(result.hint);
      }
      return;
    }

    if (syncAction === 'pull') {
      const repo = args[1] || null;
      const platform = options.platform || null;
      const result = kts.pullCommunityKnowledge(repo, platform);
      if (result.success) {
        printSuccess(`已从社区拉取 ${result.merged} 条新知识 (来自 ${result.contributors} 个贡献者)`);
        printInfo(`本地知识库现有 ${result.totalNow} 条`);
      } else {
        printError(result.error);
      }
      return;
    }

    if (syncAction === 'status') {
      const config = kts.getKBSyncConfig();
      if (!config) {
        printInfo('未配置知识库同步');
        printInfo('使用: knowledge sync config <repo> 配置');
      } else {
        console.log(chalk.bold('\n  🔄 知识库同步状态\n'));
        console.log(`  平台:      ${config.platform}`);
        console.log(`  仓库:      ${config.repo}`);
        console.log(`  类型:      ${config.isPublic ? '公共贡献' : '私人备份'}`);
        console.log(`  自动同步:  ${config.autoSync ? '开' : '关'} (每 ${config.syncThreshold} 条)`);
        console.log(`  上次同步:  ${config.lastSync || '从未'}`);
        console.log('');
      }
      return;
    }

    // Default sync help
    console.log(chalk.bold('\n  🔄 知识库同步\n'));
    console.log(chalk.dim('  支持平台: GitHub, Gitee, GitLab\n'));
    console.log('  knowledge sync config <repo>  — 配置同步仓库');
    console.log('  knowledge sync push           — 推送知识到远端');
    console.log('  knowledge sync pull [repo]    — 拉取社区知识');
    console.log('  knowledge sync status         — 查看同步状态');
    console.log(chalk.dim('\n  选项: --platform gitee|gitlab  --token <PAT>  --private'));
    console.log('');
    return;
  }

  // Default: show knowledge overview
  const progress = kts.getLevelProgress();
  const stats = kts.getKnowledgeStats();
  console.log(chalk.bold('\n  📚 量化知识库\n'));
  console.log(`  等级:     ${chalk.bold(progress.levelName)} (XP: ${progress.xp})`);
  console.log(`  进度:     ${progress.progress}% → 下一级还需 ${progress.xpToNext} XP`);
  console.log(`  内置知识: ${stats.builtinCount} 条`);
  console.log(`  学习积累: ${stats.learnedCount} 条`);
  console.log(`  已完成:   ${progress.completedTopics}/${progress.totalTopics} 个话题`);
  console.log('');
  printInfo('命令: knowledge self | knowledge search <关键词> | knowledge stats | knowledge sync');
  console.log('');
}

async function handleHabit(subCommand, args, options) {
  const habitSvc = require('../../services/usageHabitService');

  if (subCommand === 'predict') {
    // Show predicted next commands
    const predictions = habitSvc.predictNextCommands(args.length > 0 ? args : ['help']);
    if (predictions.length === 0) {
      printInfo('暂无预测数据，继续使用系统积累更多习惯');
    } else {
      console.log(chalk.bold('\n  🔮 下一步预测'));
      for (const p of predictions) {
        const conf = Math.round(p.confidence * 100);
        console.log(`  ${chalk.cyan('→')} ${p.command} ${chalk.dim(`(${conf}% 置信度)`)}`);
      }
    }
    console.log('');
    return;
  }

  // Default: show habit summary
  const summary = habitSvc.getHabitSummary();
  console.log(chalk.bold('\n  📊 使用习惯概况\n'));

  // Time profile
  if (summary.timeProfile.peakHours.length > 0) {
    console.log(`  活跃时段:    ${summary.timeProfile.peakHours.map(h => h + ':00').join(', ')}`);
  }
  console.log(`  平均会话:    ${summary.timeProfile.avgSession}`);
  console.log(`  总会话数:    ${summary.timeProfile.totalSessions}`);

  // Model ranking
  if (summary.modelRanking.length > 0) {
    console.log(chalk.bold('\n  🤖 模型使用排行'));
    for (const m of summary.modelRanking) {
      console.log(`  ${chalk.white(m.model)} — ${m.count} 次, 质量 ${chalk.green(m.quality)}`);
    }
  }

  // IDE usage
  if (summary.ideUsage.length > 0) {
    console.log(chalk.bold('\n  💻 IDE/适配器使用'));
    for (const ide of summary.ideUsage) {
      console.log(`  ${chalk.white(ide.ide)} — ${ide.count} 次`);
    }
  }

  // Top workflows
  if (summary.topWorkflows.length > 0) {
    console.log(chalk.bold('\n  ⚡ 常用工作流'));
    for (const w of summary.topWorkflows) {
      console.log(`  ${chalk.dim(w.workflow)} — ${w.count} 次`);
    }
  }

  // Topic focus
  if (summary.topics.length > 0) {
    console.log(chalk.bold('\n  📈 关注话题'));
    const trendIcon = { rising: '🔺', stable: '➖', declining: '🔻' };
    for (const t of summary.topics) {
      console.log(`  ${trendIcon[t.trend] || '·'} ${t.topic} — ${t.count} 次`);
    }
  }

  // Response preferences
  console.log(chalk.bold('\n  🎯 回复偏好'));
  console.log(`  长度: ${summary.responseStyle.preferredLength}  细节: ${summary.responseStyle.detailLevel}`);
  console.log(`  显示费用: ${summary.responseStyle.showCost ? '是' : '否'}  显示知识: ${summary.responseStyle.showTips ? '是' : '否'}`);

  console.log('');
  printInfo('输入 habit predict <上一个命令> 预测下一步');
  console.log('');
}

module.exports = { handleGrowth, handleAgent, handlePrompt, handleVoice, handleKnowledge, handleHabit };
