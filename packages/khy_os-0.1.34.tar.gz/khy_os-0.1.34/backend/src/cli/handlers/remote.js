'use strict';

/**
 * CLI handler for remote SSH commands.
 *
 * Usage:
 *   /remote hosts          — List SSH hosts from ~/.ssh/config
 *   /remote connect <host> — Connect to a remote host
 *   /remote exec <cmd>     — Execute a command on the active connection
 *   /remote sessions       — List active connections
 *   /remote disconnect     — Disconnect current session
 */

async function handleRemote(input, deps) {
  const { chalk: c } = deps;
  const args = String(input || '').trim().split(/\s+/);
  const sub = (args[0] || 'hosts').toLowerCase();

  switch (sub) {
    case 'hosts':
      return _hosts(c);
    case 'connect':
      return _connect(c, args.slice(1).join(' '));
    case 'exec':
      return _exec(c, args.slice(1).join(' '));
    case 'sessions':
      return _sessions(c);
    case 'disconnect':
      return _disconnect(c);
    default:
      _help(c);
  }
}

async function _hosts(c) {
  try {
    const remote = require('../../services/remote');
    const hosts = remote.sshConfig.discoverHosts();
    if (!hosts || hosts.length === 0) {
      console.log(c.yellow('未发现 SSH 主机 (检查 ~/.ssh/config)'));
      return;
    }
    console.log(c.bold(`SSH 主机 (${hosts.length}):`));
    for (const h of hosts) {
      const label = h.alias || h.host || h.hostname;
      const detail = h.hostname ? ` → ${h.hostname}:${h.port || 22}` : '';
      console.log(`  ${c.green('●')} ${label}${c.dim(detail)}`);
    }
  } catch (err) {
    console.log(c.red(`获取主机列表失败: ${err.message}`));
  }
}

async function _connect(c, hostArg) {
  if (!hostArg) {
    console.log(c.yellow('用法: /remote connect <host>'));
    return;
  }
  try {
    const remote = require('../../services/remote');
    console.log(c.dim(`正在连接 ${hostArg}...`));
    const session = await remote.connectionManager.connect(hostArg);
    console.log(c.green(`✓ 已连接到 ${hostArg} (session: ${session.id || 'active'})`));
  } catch (err) {
    console.log(c.red(`连接失败: ${err.message}`));
  }
}

async function _exec(c, command) {
  if (!command) {
    console.log(c.yellow('用法: /remote exec <command>'));
    return;
  }
  try {
    const remote = require('../../services/remote');
    console.log(c.dim(`远程执行: ${command}`));
    const result = await remote.execService.exec(command);
    if (result.stdout) console.log(result.stdout);
    if (result.stderr) console.log(c.yellow(result.stderr));
    if (result.exitCode !== undefined && result.exitCode !== 0) {
      console.log(c.red(`退出码: ${result.exitCode}`));
    }
  } catch (err) {
    console.log(c.red(`执行失败: ${err.message}`));
  }
}

async function _sessions(c) {
  try {
    const remote = require('../../services/remote');
    const sessions = remote.connectionManager.getSessions();
    if (!sessions || sessions.length === 0) {
      console.log(c.dim('无活跃连接'));
      return;
    }
    console.log(c.bold(`活跃连接 (${sessions.length}):`));
    for (const s of sessions) {
      console.log(`  ${c.green('●')} ${s.host || s.id} — ${s.status || 'connected'}`);
    }
  } catch (err) {
    console.log(c.red(`获取会话失败: ${err.message}`));
  }
}

async function _disconnect(c) {
  try {
    const remote = require('../../services/remote');
    await remote.connectionManager.disconnectAll();
    console.log(c.green('✓ 已断开所有远程连接'));
  } catch (err) {
    console.log(c.red(`断开连接失败: ${err.message}`));
  }
}

function _help(c) {
  const lines = [
    c.bold('远程 SSH 管理'),
    '',
    `  ${c.green('hosts')}          列出 SSH 主机`,
    `  ${c.green('connect')} <host>  连接远程主机`,
    `  ${c.green('exec')} <cmd>     远程执行命令`,
    `  ${c.green('sessions')}       查看活跃连接`,
    `  ${c.green('disconnect')}     断开所有连接`,
  ];
  console.log(lines.join('\n'));
}

module.exports = { handleRemote };
