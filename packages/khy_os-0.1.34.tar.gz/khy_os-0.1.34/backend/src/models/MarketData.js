module.exports = require('@khy/shared/models/MarketData');
