module.exports = require('@khy/shared/models/UserFavorite');
