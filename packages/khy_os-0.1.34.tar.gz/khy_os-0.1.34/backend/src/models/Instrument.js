module.exports = require('@khy/shared/models/Instrument');
