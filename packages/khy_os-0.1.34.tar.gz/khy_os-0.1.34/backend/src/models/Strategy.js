module.exports = require('@khy/shared/models/Strategy');
