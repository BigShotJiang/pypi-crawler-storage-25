module.exports = require('@khy/shared/models/Trade');
