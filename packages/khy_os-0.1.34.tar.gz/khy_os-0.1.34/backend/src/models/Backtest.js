module.exports = require('@khy/shared/models/Backtest');
