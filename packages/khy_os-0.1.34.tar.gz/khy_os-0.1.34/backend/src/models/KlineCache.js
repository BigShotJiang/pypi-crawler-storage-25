module.exports = require('@khy/shared/models/KlineCache');
