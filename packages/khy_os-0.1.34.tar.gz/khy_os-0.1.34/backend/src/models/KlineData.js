module.exports = require('@khy/shared/models/KlineData');
