"""Wiggum looping plugin."""
