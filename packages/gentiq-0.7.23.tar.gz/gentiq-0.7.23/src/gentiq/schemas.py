from typing import Any

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field


class Balance(BaseModel):
    """Represents a user's balance for different resources."""

    tokens: int
    requests: int
    updated_at: AwareDatetime
    token_limit: int
    request_limit: int


class User(BaseModel):
    """Represents a Gentiq user profile and their current balance."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    phone: str
    name: str
    surname: str
    token: str
    balance: Balance | None
    created_at: AwareDatetime
    password_hash: str | None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Feedback(BaseModel):
    """Represents user feedback (sentiment) on one or more chat items."""

    thread_id: str
    item_ids: list[str]
    sentiment: str
    user_id: str
    created_at: AwareDatetime | None = None


class Admin(BaseModel):
    """Represents an administrative user with specific permissions."""

    id: str
    username: str
    password_hash: str
    name: str
    permissions: list[str]
    created_at: AwareDatetime | None = None


class TransactionChange(BaseModel):
    """Represents the change in balance for a transaction."""

    tokens: int
    requests: int


class Transaction(BaseModel):
    """Represents a balance change (recharge or usage) for a user."""

    model_config = ConfigDict(populate_by_name=True)

    user_id: str
    type_: str = Field(alias="type")
    change: TransactionChange
    balance_after: TransactionChange
    created_at: AwareDatetime
    thread_id: str | None = None
    details: dict[str, Any] | None = None


class SharedConversation(BaseModel):
    """Represents a readonly snapshot of a conversation for public sharing."""

    id: str
    title: str
    items: list[dict]
    created_at: AwareDatetime


class AppSettings(BaseModel):
    """Global application configuration and flags."""

    app_name: str = "Gentiq"
    admin_title: str | None = None
    welcome_greeting: str | None = None
    welcome_subtitle: str | None = None
    disclaimer: str | None = None
    show_tool_details: bool = True
    show_settings: bool = True
    composer_attachments: bool = True
    thread_actions_feedback: bool = True
    thread_actions_retry: bool = True
    history_enabled: bool = True
    history_show_delete: bool = True
    history_show_rename: bool = True
    history_show_share: bool = True
    history_show_pin: bool = True
    settings_general_mode: str = "editable"
    settings_profile_mode: str = "editable"
    settings_account_mode: str = "editable"
    settings_general_fields: dict[str, str] = Field(default_factory=dict)
    settings_profile_fields: dict[str, str] = Field(default_factory=dict)
    settings_account_fields: dict[str, str] = Field(default_factory=dict)
    language: str = "fa"
    translations: dict[str, Any] = Field(default_factory=dict)
    updated_at: AwareDatetime | None = None
