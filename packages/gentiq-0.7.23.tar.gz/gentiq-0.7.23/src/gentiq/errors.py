from enum import StrEnum
from typing import Any


class ErrorCode(StrEnum):
    """Standardized error codes for the Gentiq framework."""

    # Auth Errors
    UNAUTHORIZED = "unauthorized"
    INVALID_CREDENTIALS = "invalid_credentials"
    PHONE_REQUIRED = "phone_required"
    PASSWORD_REQUIRED = "password_required"
    NAME_SURNAME_REQUIRED = "name_surname_required"
    PHONE_ALREADY_EXISTS = "phone_already_exists"
    INVALID_TOKEN = "invalid_token"

    # User & Balance Errors
    USER_NOT_FOUND = "user_not_found"
    INSUFFICIENT_BALANCE = "insufficient_balance"
    ME_UPDATE_FAILED = "me_update_failed"

    # Chat & Thread Errors
    THREAD_NOT_FOUND = "thread_not_found"
    ACCESS_DENIED = "access_denied"
    FEEDBACK_SAVE_FAILED = "feedback_save_failed"
    THREAD_UPDATE_FAILED = "thread_update_failed"
    THREAD_DELETE_FAILED = "thread_delete_failed"
    ATTACHMENT_NOT_FOUND = "attachment_not_found"
    THREAD_SHARE_FAILED = "thread_share_failed"

    # Admin Errors
    ADMIN_ALREADY_EXISTS = "admin_already_exists"
    ADMIN_NOT_FOUND = "admin_not_found"
    CANNOT_DELETE_SELF = "cannot_delete_self"
    ADMIN_UPDATE_FAILED = "admin_update_failed"
    JOB_NOT_FOUND = "job_not_found"

    # System Errors
    INTERNAL_ERROR = "internal_error"
    VALIDATION_ERROR = "validation_error"
    NOT_FOUND = "not_found"


class GentiqError(Exception):
    """Base exception for all Gentiq-related errors."""

    def __init__(
        self,
        code: ErrorCode,
        message: str | None = None,
        status_code: int = 400,
        details: dict[str, Any] | None = None,
    ):
        self.code = code
        self.message = message or code.value.replace("_", " ").capitalize()
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)
