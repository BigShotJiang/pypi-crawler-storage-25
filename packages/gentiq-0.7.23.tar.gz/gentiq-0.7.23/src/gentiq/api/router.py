from fastapi import APIRouter

from .routes import admin, auth, chat, config, users


api_router = APIRouter()

api_router.include_router(auth.router)
api_router.include_router(chat.router)
api_router.include_router(users.router)
api_router.include_router(admin.router)
api_router.include_router(config.router)
