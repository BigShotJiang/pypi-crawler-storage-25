from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse, Response

from ...errors import ErrorCode, GentiqError
from ...stores import SettingsStore
from ..dependencies import get_settings_store


router = APIRouter(tags=["Config"])


@router.get("/config")
async def get_public_config(
    request: Request,
    settings_store: Annotated[SettingsStore, Depends(get_settings_store)],
) -> Response:
    """Endpoint to fetch public application configuration and flags."""
    try:
        settings = settings_store.get_settings()
        # Return the settings as the public config
        return JSONResponse(jsonable_encoder(settings), status_code=200)
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch config: {e!s}", status_code=500)
