from typing import Any

from pydantic import BaseModel

from .enums import AdminPermission


__all__ = [
    "AdminLoginInput",
    "AdminRegisterInput",
    "AdminUpdateInput",
    "AppSettingsUpdateInput",
    "LoginInput",
    "MessageFeedbackInput",
    "RegisterUserInput",
    "ThreadUpdateInput",
    "UserBalanceUpdateInput",
    "UserCreateInput",
    "UserUpdateInput",
]


# ------------------------------ #
# -------- User Inputs --------- #
# ------------------------------ #
class RegisterUserInput(BaseModel):
    phone: str
    password: str
    name: str
    surname: str
    metadata: dict | None = None


class LoginInput(BaseModel):
    phone: str
    password: str


class MessageFeedbackInput(BaseModel):
    thread_id: str
    message_id: str
    sentiment: str | None  # 'like' or 'dislike' or null to retract


class ThreadUpdateInput(BaseModel):
    title: str | None = None
    pinned: bool | None = None


# ------------------------------ #
# -------- Admin Inputs -------- #
# ------------------------------ #
class AdminRegisterInput(BaseModel):
    username: str
    password: str
    name: str
    permissions: list[AdminPermission | str]


class AdminUpdateInput(BaseModel):
    name: str | None = None
    password: str | None = None
    permissions: list[AdminPermission | str] | None = None


class AdminLoginInput(BaseModel):
    username: str
    password: str


class UserCreateInput(BaseModel):
    phone: str
    name: str
    surname: str
    metadata: dict | None = None
    balance: dict | None = None


class UserUpdateInput(BaseModel):
    phone: str | None = None
    name: str | None = None
    surname: str | None = None
    password: str | None = None
    metadata: dict | None = None


class UserBalanceUpdateInput(BaseModel):
    tokens: int
    requests: int
    token_limit: int | None = None
    request_limit: int | None = None


class AppSettingsUpdateInput(BaseModel):
    app_name: str | None = None
    admin_title: str | None = None
    welcome_greeting: str | None = None
    welcome_subtitle: str | None = None
    disclaimer: str | None = None
    show_tool_details: bool | None = None
    show_settings: bool | None = None
    composer_attachments: bool | None = None
    thread_actions_feedback: bool | None = None
    thread_actions_retry: bool | None = None
    history_enabled: bool | None = None
    history_show_delete: bool | None = None
    history_show_rename: bool | None = None
    history_show_share: bool | None = None
    history_show_pin: bool | None = None
    settings_general_mode: str | None = None
    settings_profile_mode: str | None = None
    settings_account_mode: str | None = None
    settings_general_fields: dict[str, str] | None = None
    settings_profile_fields: dict[str, str] | None = None
    settings_account_fields: dict[str, str] | None = None
    language: str | None = None
    translations: dict[str, Any] | None = None
