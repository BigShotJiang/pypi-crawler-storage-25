from enum import StrEnum


class AdminPermission(StrEnum):
    CHAT_HISTORY = "chat_history"
    ADMIN_MANAGEMENT = "admin_management"
    USER_MANAGEMENT = "user_management"
    ANALYTICS = "analytics"
    SETTINGS = "settings"

    @classmethod
    def list_all(cls) -> list[str]:
        return list(cls)
