from datetime import UTC, datetime
from typing import Any

from ..engines.base import DBEngine
from ..env import SETTINGS
from ..schemas import AppSettings


class SettingsStore:
    """Store for managing global application settings and flags.

    This store handles the persistence of a single global configuration document
    that controls the appearance and behavior of the application.

    Args:
        engine: The database engine instance for structured data.
        collection: The name of the collection/table for settings documents.
    """

    def __init__(self, engine: DBEngine, collection: str = SETTINGS):
        self.engine = engine
        self.collection = collection
        self._doc_id = "global"

    def get_settings(self) -> AppSettings | None:
        """Retrieves the current application settings.

        Returns:
            The AppSettings object if it exists in the DB,
            otherwise None.
        """
        doc = self.engine.find_one(self.collection, {"id": self._doc_id})
        if not doc:
            return None

        doc.pop("_id", None)
        return AppSettings.model_validate(doc)

    def update_settings(self, settings_data: dict[str, Any]) -> AppSettings | None:
        """Updates the application settings.

        Args:
            settings_data: Dictionary of settings to update.

        Returns:
            The updated AppSettings object.
        """
        # Ensure updated_at is always set
        settings_data["updated_at"] = datetime.now(UTC)
        settings_data["id"] = self._doc_id

        # We use upsert to ensure the document exists
        self.engine.update_one(self.collection, {"id": self._doc_id}, set_fields=settings_data, upsert=True)

        return self.get_settings()

    def delete_settings(self) -> bool:
        """Deletes the application settings.

        Returns:
            True if deleted, False otherwise.
        """
        self.engine.delete_one(self.collection, {"id": self._doc_id})
        return True
