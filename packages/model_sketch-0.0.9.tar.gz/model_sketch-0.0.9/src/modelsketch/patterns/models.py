"""Pattern data models for architecture analysis."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class RepeatedBlockPattern:
    """Detected repeated semantic block motif.

    Attributes:
        stage_name: Semantic stage where repeats were found.
        signature: Human-readable repeat signature.
        stage_block_indices: Stage-local indices of repeated blocks.
        block_refs: Deterministic references to repeated blocks in stage order.
        occurrences: Number of repeated blocks with this signature.
    """

    stage_name: str
    signature: str
    stage_block_indices: list[int] = field(default_factory=list)
    block_refs: list[str] = field(default_factory=list)
    occurrences: int = 0


@dataclass(frozen=True)
class ResidualConnectionPattern:
    """Detected residual-like skip connection.

    Attributes:
        source: Source node id of the skip edge.
        target: Target node id of the skip edge.
        alternate_path_length: Number of edges in shortest non-skip path.
    """

    source: str
    target: str
    alternate_path_length: int


@dataclass(frozen=True)
class PatternSummary:
    """Top-level pattern analysis summary for one architecture graph."""

    repeated_blocks: list[RepeatedBlockPattern] = field(default_factory=list)
    residual_connections: list[ResidualConnectionPattern] = field(default_factory=list)
