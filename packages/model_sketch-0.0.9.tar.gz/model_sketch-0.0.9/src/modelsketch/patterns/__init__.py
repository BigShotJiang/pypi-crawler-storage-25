"""Pattern detection stage for architecture analysis."""

from modelsketch.patterns.detector import detect_patterns
from modelsketch.patterns.models import (
    PatternSummary,
    RepeatedBlockPattern,
    ResidualConnectionPattern,
)

__all__ = [
    "PatternSummary",
    "RepeatedBlockPattern",
    "ResidualConnectionPattern",
    "detect_patterns",
]
