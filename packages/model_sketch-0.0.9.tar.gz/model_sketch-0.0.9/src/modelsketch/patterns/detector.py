"""Pattern detection entry points for extracted and semantic model data."""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING

from modelsketch.patterns.models import (
    PatternSummary,
    RepeatedBlockPattern,
    ResidualConnectionPattern,
)

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphSpec
    from modelsketch.semantic.models import SemanticModel


def detect_patterns(
    *,
    graph: GraphSpec,
    semantic_model: SemanticModel,
) -> PatternSummary:
    """Detect architecture motifs from graph and semantic representations."""

    repeated_blocks = _detect_repeated_blocks(semantic_model=semantic_model)
    residual_connections = _detect_residual_connections(graph=graph)
    return PatternSummary(
        repeated_blocks=repeated_blocks,
        residual_connections=residual_connections,
    )


def _detect_repeated_blocks(
    *,
    semantic_model: SemanticModel,
) -> list[RepeatedBlockPattern]:
    """Detect repeated semantic blocks by structural signature per stage."""

    patterns: list[RepeatedBlockPattern] = []

    for stage in semantic_model.stages:
        grouped: dict[tuple[int, tuple[str, ...]], list[tuple[int, str]]] = {}

        for block_index, block in enumerate(stage.blocks):
            signature_key = (block.layer_count, tuple(block.op_types))
            grouped.setdefault(signature_key, []).append(
                (block_index, f"{stage.name}/block_{block_index}:{block.name}")
            )

        for signature_key, entries in grouped.items():
            if len(entries) <= 1:
                continue

            layer_count, op_types = signature_key
            signature = f"layers={layer_count};ops={','.join(op_types)}"
            stage_block_indices = [item[0] for item in entries]
            block_refs = [item[1] for item in entries]
            patterns.append(
                RepeatedBlockPattern(
                    stage_name=stage.name,
                    signature=signature,
                    stage_block_indices=stage_block_indices,
                    block_refs=block_refs,
                    occurrences=len(block_refs),
                )
            )

    return patterns


def _detect_residual_connections(
    *,
    graph: GraphSpec,
) -> list[ResidualConnectionPattern]:
    """Detect skip edges that have an alternate path between the same endpoints."""

    patterns: list[ResidualConnectionPattern] = []
    seen_pairs: set[tuple[str, str]] = set()

    for edge_index, edge in enumerate(graph.edges):
        pair = (edge.source, edge.target)
        if pair in seen_pairs:
            continue

        alt_len = _shortest_path_length_excluding_edge(
            graph=graph,
            source=edge.source,
            target=edge.target,
            excluded_edge_index=edge_index,
        )
        if alt_len is None:
            continue

        patterns.append(
            ResidualConnectionPattern(
                source=edge.source,
                target=edge.target,
                alternate_path_length=alt_len,
            )
        )
        seen_pairs.add(pair)

    return patterns


def _shortest_path_length_excluding_edge(
    *,
    graph: GraphSpec,
    source: str,
    target: str,
    excluded_edge_index: int,
) -> int | None:
    """Return shortest path length from source to target excluding one edge."""

    adjacency: dict[str, list[str]] = {}
    for edge_index, edge in enumerate(graph.edges):
        if edge_index == excluded_edge_index:
            continue
        adjacency.setdefault(edge.source, []).append(edge.target)

    queue: deque[tuple[str, int]] = deque([(source, 0)])
    visited: set[str] = {source}

    while queue:
        node_id, distance = queue.popleft()
        for next_node in adjacency.get(node_id, []):
            next_distance = distance + 1
            if next_node == target:
                return next_distance
            if next_node in visited:
                continue
            visited.add(next_node)
            queue.append((next_node, next_distance))

    return None
