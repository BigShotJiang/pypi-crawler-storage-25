"""Semantic data models for architecture visualization."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SemanticLayer:
    """Leaf semantic layer representation.

    Attributes:
        id: Stable layer identifier.
        name: Human-readable layer display name.
        op_type: Operation category from extraction stage.
    """

    id: str
    name: str
    op_type: str


@dataclass(frozen=True)
class SemanticBlock:
    """Group of semantically related layers.

    Attributes:
        name: Human-readable block name.
        layers: Ordered list of semantic layers.
        layer_count: Number of layers represented by this block.
        op_types: Ordered operation types represented in the block.
        output_shape: Optional output shape summary, when detected.
    """

    name: str
    layers: list[SemanticLayer] = field(default_factory=list)
    layer_count: int = 0
    op_types: list[str] = field(default_factory=list)
    output_shape: str | None = None


@dataclass(frozen=True)
class SemanticStage:
    """High-level architecture stage.

    Attributes:
        name: Human-readable stage name.
        blocks: Ordered list of semantic blocks.
    """

    name: str
    blocks: list[SemanticBlock] = field(default_factory=list)


@dataclass(frozen=True)
class SemanticModel:
    """Top-level semantic model representation.

    Attributes:
        stages: Ordered list of architecture stages.
    """

    stages: list[SemanticStage] = field(default_factory=list)
