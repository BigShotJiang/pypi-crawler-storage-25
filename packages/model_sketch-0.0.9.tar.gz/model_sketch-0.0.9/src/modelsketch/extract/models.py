"""Data models for extracted computation graphs."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class GraphNode:
    """Single node in an extracted directed graph.

    Attributes:
        id: Stable node identifier.
        op_type: Operation type label.
        label: Human-readable display label.
        module_path: Optional qualified module path for call_module nodes.
    """

    id: str
    op_type: str
    label: str
    module_path: str | None = None


@dataclass(frozen=True)
class GraphEdge:
    """Directed edge connecting two graph nodes.

    Attributes:
        source: Source node identifier.
        target: Target node identifier.
    """

    source: str
    target: str


@dataclass(frozen=True)
class GraphSpec:
    """Extracted graph representation consumed by downstream stages.

    Attributes:
        nodes: Ordered list of graph nodes.
        edges: Directed edges between nodes.
    """

    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)
