"""torch.fx-backed extraction entry point for the MVP."""

from __future__ import annotations

import operator
from collections import defaultdict
from typing import TYPE_CHECKING, Any

import torch
from torch.fx.passes.shape_prop import ShapeProp

from modelsketch.extract.models import GraphEdge, GraphNode, GraphSpec

if TYPE_CHECKING:
    from collections.abc import Mapping

    from torch.fx import GraphModule, Node


def extract_graph(
    model: Any,
    *,
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
    collapse_getitem_nodes: bool = True,
) -> GraphSpec:
    """Extract a graph from a model and example inputs.

    Args:
        model: Model object that will be traced in future iterations.
        args: Example positional arguments used for tracing.
        kwargs: Example keyword arguments used for tracing.
        collapse_getitem_nodes: Whether tuple-index plumbing nodes are collapsed.

    Returns:
        Graph representation extracted from torch.fx tracing.
    """

    if not isinstance(model, torch.nn.Module):
        msg = "model must be an instance of torch.nn.Module"
        raise TypeError(msg)

    traced = torch.fx.symbolic_trace(model)
    _run_shape_propagation(traced, args=args, kwargs=kwargs)

    raw_nodes: list[GraphNode] = []
    raw_edges: list[GraphEdge] = []
    getitem_node_ids: set[str] = set()

    for node in traced.graph.nodes:
        if node.op == "output":
            continue
        raw_nodes.append(
            GraphNode(
                id=node.name,
                op_type=node.op,
                label=_node_label(node=node, graph_module=traced),
                module_path=(str(node.target) if node.op == "call_module" else None),
            ),
        )
        if node.op == "call_function" and node.target is operator.getitem:
            getitem_node_ids.add(node.name)
        for input_node in node.all_input_nodes:
            raw_edges.append(GraphEdge(source=input_node.name, target=node.name))

    if not collapse_getitem_nodes:
        return GraphSpec(nodes=raw_nodes, edges=raw_edges)

    return _collapse_getitem_nodes(
        nodes=raw_nodes,
        edges=raw_edges,
        collapsed_ids=getitem_node_ids,
    )


def _collapse_getitem_nodes(
    *,
    nodes: list[GraphNode],
    edges: list[GraphEdge],
    collapsed_ids: set[str],
) -> GraphSpec:
    """Remove plumbing getitem nodes while preserving connectivity."""

    if not collapsed_ids:
        return GraphSpec(nodes=nodes, edges=edges)

    kept_nodes = [node for node in nodes if node.id not in collapsed_ids]
    kept_ids = {node.id for node in kept_nodes}

    outgoing: dict[str, list[str]] = defaultdict(list)
    for edge in edges:
        outgoing[edge.source].append(edge.target)

    dedup_edges: dict[tuple[str, str], None] = {}
    for source in (node.id for node in kept_nodes):
        for neighbor in outgoing.get(source, []):
            for target in _resolve_collapsed_targets(
                start=neighbor,
                outgoing=outgoing,
                collapsed_ids=collapsed_ids,
            ):
                if target not in kept_ids or source == target:
                    continue
                dedup_edges[(source, target)] = None

    kept_edges = [
        GraphEdge(source=source, target=target) for source, target in dedup_edges
    ]
    return GraphSpec(nodes=kept_nodes, edges=kept_edges)


def _resolve_collapsed_targets(
    *,
    start: str,
    outgoing: dict[str, list[str]],
    collapsed_ids: set[str],
) -> list[str]:
    """Follow collapsed nodes until first non-collapsed targets are reached."""

    if start not in collapsed_ids:
        return [start]

    resolved: dict[str, None] = {}
    stack = [start]
    visited: set[str] = set()
    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        for nxt in outgoing.get(current, []):
            if nxt in collapsed_ids:
                stack.append(nxt)
                continue
            resolved[nxt] = None
    return list(resolved)


def _run_shape_propagation(
    traced: GraphModule,
    *,
    args: tuple[Any, ...],
    kwargs: Mapping[str, Any],
) -> None:
    """Best-effort shape propagation for labels.

    Shape propagation is optional because some models require runtime data or
    control flow that cannot be inferred statically.
    """

    if not args and not kwargs:
        return
    try:
        ShapeProp(traced).propagate(*args, **dict(kwargs))
    except (AssertionError, RuntimeError, TypeError, ValueError):
        return


def _node_label(*, node: Node, graph_module: GraphModule) -> str:
    """Build a concise label for a traced node."""

    if node.op == "call_module":
        submodule = graph_module.get_submodule(str(node.target))
        base = type(submodule).__name__
    elif node.op == "call_function":
        if node.target is operator.getitem:
            base = "getitem"
        else:
            base = getattr(node.target, "__name__", str(node.target))
    elif node.op in {"call_method", "placeholder"}:
        base = str(node.target)
    else:
        base = str(node.op)

    shape_suffix = _shape_suffix(node)
    return f"{base}{shape_suffix}"


def _shape_suffix(node: Node) -> str:
    """Create a compact shape suffix from fx tensor metadata when present."""

    tensor_meta = node.meta.get("tensor_meta")
    shape = _shape_from_meta_value(tensor_meta)
    if shape is None:
        shape = _shape_from_meta_value(node.meta.get("val"))
    if shape is None:
        return ""
    return f" {shape}"


def _shape_from_meta_value(value: Any) -> tuple[Any, ...] | None:
    """Best-effort extraction of first tensor-like shape from nested metadata."""

    shape = getattr(value, "shape", None)
    if shape is not None:
        return tuple(shape)

    if isinstance(value, (list, tuple)):
        for item in value:
            nested = _shape_from_meta_value(item)
            if nested is not None:
                return nested
        return None

    if isinstance(value, dict):
        for item in value.values():
            nested = _shape_from_meta_value(item)
            if nested is not None:
                return nested
        return None

    return None
