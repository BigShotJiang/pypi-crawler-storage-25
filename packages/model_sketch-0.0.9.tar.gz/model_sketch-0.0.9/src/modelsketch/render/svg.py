"""SVG rendering backend for architecture sketches."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal
from xml.sax.saxutils import escape

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphEdge, GraphSpec
    from modelsketch.layout.types import LayoutPlan, NodeBox

EdgeStyle = Literal["straight", "orthogonal"]


@dataclass(frozen=True)
class _EdgeRenderSettings:
    """Immutable settings needed while generating edge SVG elements."""

    edge_style: EdgeStyle
    marker_attr: str
    target_incoming_counts: dict[str, int]
    target_spine_x: dict[str, float]
    outer_top_y: float
    outer_bottom_y: float


def render_svg(
    *,
    graph: GraphSpec,
    layout: LayoutPlan,
    edge_style: EdgeStyle = "straight",
    arrowheads: bool = False,
) -> str:
    """Render a graph and layout plan to SVG.

    Args:
        graph: Graph to render.
        layout: Precomputed layout plan.
        edge_style: Edge rendering style.
        arrowheads: Whether to render arrowheads on edges.

    Returns:
        SVG document as a UTF-8 compatible string.
    """

    parts: list[str] = [
        (
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{layout.width:.0f}" height="{layout.height:.0f}" '
            f'viewBox="0 0 {layout.width:.0f} {layout.height:.0f}">'
        ),
        '<rect width="100%" height="100%" fill="white" />',
    ]

    if arrowheads:
        parts.extend(
            [
                "<defs>",
                (
                    '<marker id="edge-arrow" markerWidth="8" markerHeight="6" '
                    'refX="7" refY="3" orient="auto" markerUnits="strokeWidth">'
                ),
                '<path d="M0,0 L8,3 L0,6 z" fill="#333" />',
                "</marker>",
                "</defs>",
            ],
        )

    node_entries: list[tuple[NodeBox, str]] = []
    for node in graph.nodes:
        box = layout.boxes.get(node.id)
        if box is None:
            continue
        node_entries.append((box, escape(node.label)))

    # Draw node boxes before edges so edge strokes stay visible.
    for box, _label in node_entries:
        parts.append(
            (
                f'<rect x="{box.x:.1f}" y="{box.y:.1f}" '
                f'width="{box.width:.1f}" height="{box.height:.1f}" '
                'rx="10" fill="#f2f6fb" stroke="#1f2937" stroke-width="1.5" />'
            ),
        )

    source_anchor_y, target_anchor_y = _build_edge_anchors(graph=graph, layout=layout)
    target_incoming_counts = _build_target_incoming_counts(graph=graph)
    target_spine_x = _build_target_spine_x(graph=graph, layout=layout)
    edge_settings = _EdgeRenderSettings(
        edge_style=edge_style,
        marker_attr=' marker-end="url(#edge-arrow)"' if arrowheads else "",
        target_incoming_counts=target_incoming_counts,
        target_spine_x=target_spine_x,
        outer_top_y=_layout_outer_top_y(layout=layout),
        outer_bottom_y=_layout_outer_bottom_y(layout=layout),
    )

    for edge_index, edge in enumerate(graph.edges):
        source_box = layout.boxes.get(edge.source)
        target_box = layout.boxes.get(edge.target)
        if source_box is None or target_box is None:
            continue
        x1 = source_box.x + source_box.width
        y1 = source_anchor_y.get(
            edge_index,
            source_box.y + source_box.height / 2,
        )
        x2 = target_box.x
        y2 = target_anchor_y.get(
            edge_index,
            target_box.y + target_box.height / 2,
        )
        parts.append(
            _build_edge_element(
                edge=edge,
                coords=(x1, y1, x2, y2),
                settings=edge_settings,
            ),
        )

    for box, label in node_entries:
        parts.append(
            (
                f'<text x="{box.x + 12:.1f}" y="{box.y + box.height / 2 + 5:.1f}" '
                'font-family="Helvetica, Arial, sans-serif" '
                'font-size="14" fill="#111827">'
                f"{label}</text>"
            ),
        )

    parts.append("</svg>")
    return "".join(parts)


def _build_edge_element(
    *,
    edge: GraphEdge,
    coords: tuple[float, float, float, float],
    settings: _EdgeRenderSettings,
) -> str:
    """Build the SVG element string for one rendered edge."""

    x1, y1, x2, y2 = coords
    if settings.edge_style == "orthogonal":
        if abs(y2 - y1) < 0.1:
            path_d = f"M{x1:.1f},{y1:.1f} L{x2:.1f},{y2:.1f}"
        else:
            incoming_count = settings.target_incoming_counts.get(edge.target, 0)
            preferred_spine_x = settings.target_spine_x.get(edge.target)
            if incoming_count > 1 and preferred_spine_x is not None:
                bend_x = _merge_target_turn_x(
                    x1=x1,
                    x2=x2,
                    preferred_spine_x=preferred_spine_x,
                )
                if _should_route_merge_outside(x1=x1, x2=x2, y1=y1, y2=y2):
                    outer_y = (
                        settings.outer_top_y if y1 <= y2 else settings.outer_bottom_y
                    )
                    path_d = _outside_merge_path(
                        coords=(x1, y1, x2, y2),
                        bend_x=bend_x,
                        outer_y=outer_y,
                    )
                else:
                    path_d = _rounded_orthogonal_path(
                        points=[
                            (x1, y1),
                            (bend_x, y1),
                            (bend_x, y2),
                            (x2, y2),
                        ],
                        corner_radius=8.0,
                    )
            else:
                bend_x = _target_side_turn_x(x1=x1, x2=x2)
                path_d = _rounded_orthogonal_path(
                    points=[
                        (x1, y1),
                        (bend_x, y1),
                        (bend_x, y2),
                        (x2, y2),
                    ],
                    corner_radius=8.0,
                )
        return (
            f'<path d="{path_d}" '
            f'stroke="#333" stroke-width="1.6" fill="none" '
            f'stroke-linecap="round" stroke-linejoin="round"{settings.marker_attr} />'
        )

    return (
        f'<line x1="{x1:.1f}" y1="{y1:.1f}" '
        f'x2="{x2:.1f}" y2="{y2:.1f}" '
        f'stroke="#333" stroke-width="1.6" '
        f'stroke-linecap="round"{settings.marker_attr} />'
    )


def _layout_outer_top_y(*, layout: LayoutPlan) -> float:
    """Compute top outer routing corridor y-coordinate."""

    if not layout.boxes:
        return 12.0
    top = min(box.y for box in layout.boxes.values())
    return max(8.0, top - 12.0)


def _layout_outer_bottom_y(*, layout: LayoutPlan) -> float:
    """Compute bottom outer routing corridor y-coordinate."""

    if not layout.boxes:
        return max(12.0, layout.height - 8.0)
    bottom = max(box.y + box.height for box in layout.boxes.values())
    return min(max(12.0, layout.height - 8.0), bottom + 12.0)


def _should_route_merge_outside(*, x1: float, x2: float, y1: float, y2: float) -> bool:
    """Return True when a long, low-offset merge edge benefits from outside routing."""

    return (x2 - x1) >= 500.0 and y1 < y2 and abs(y2 - y1) <= 64.0


def _outside_merge_path(
    *,
    coords: tuple[float, float, float, float],
    bend_x: float,
    outer_y: float,
) -> str:
    """Build an orthogonal path that leaves the main row and returns near target."""

    x1, y1, x2, y2 = coords
    elbow_x = min(bend_x - 16.0, x1 + 16.0)
    return _rounded_orthogonal_path(
        points=[
            (x1, y1),
            (elbow_x, y1),
            (elbow_x, outer_y),
            (bend_x, outer_y),
            (bend_x, y2),
            (x2, y2),
        ],
        corner_radius=8.0,
    )


def _build_edge_anchors(
    *,
    graph: GraphSpec,
    layout: LayoutPlan,
) -> tuple[dict[int, float], dict[int, float]]:
    """Build per-edge source/target y anchors to reduce edge overlap."""

    outgoing: dict[str, list[tuple[int, float]]] = {}
    incoming: dict[str, list[tuple[int, float, float]]] = {}

    for edge_index, edge in enumerate(graph.edges):
        source_box = layout.boxes.get(edge.source)
        target_box = layout.boxes.get(edge.target)
        if source_box is None or target_box is None:
            continue

        target_center_y = target_box.y + target_box.height / 2
        source_center_y = source_box.y + source_box.height / 2

        outgoing.setdefault(edge.source, []).append((edge_index, target_center_y))
        incoming.setdefault(edge.target, []).append(
            (edge_index, source_center_y, source_box.x),
        )

    source_anchor_y: dict[int, float] = {}
    for source_id, outgoing_edges in outgoing.items():
        box = layout.boxes.get(source_id)
        if box is None:
            continue
        if len(outgoing_edges) <= 1:
            center_y = box.y + box.height / 2
            for edge_index, _ in outgoing_edges:
                source_anchor_y[edge_index] = center_y
            continue
        sorted_outgoing_edges = sorted(
            outgoing_edges,
            key=lambda item: (item[1], item[0]),
        )
        total = len(sorted_outgoing_edges)
        for slot, (edge_index, _) in enumerate(sorted_outgoing_edges, start=1):
            source_anchor_y[edge_index] = _node_port_y(box=box, slot=slot, total=total)

    target_anchor_y: dict[int, float] = {}
    for target_id, incoming_edges in incoming.items():
        box = layout.boxes.get(target_id)
        if box is None:
            continue
        # Prefer the rightmost source when source centers are equal, so
        # upper branch continuation maps to upper merge port more naturally.
        sorted_incoming_edges = sorted(
            incoming_edges,
            key=lambda item: (item[1], -item[2], item[0]),
        )
        total = len(sorted_incoming_edges)
        for slot, (edge_index, _, _) in enumerate(sorted_incoming_edges, start=1):
            target_anchor_y[edge_index] = _target_port_y(
                box=box,
                slot=slot,
                total=total,
            )

    return source_anchor_y, target_anchor_y


def _node_port_y(*, box: NodeBox, slot: int, total: int) -> float:
    """Compute deterministic y-port position for a node side."""

    if total <= 1:
        return box.y + box.height / 2

    edge_padding = min(14.0, box.height * 0.2)
    available_height = max(0.0, box.height - 2 * edge_padding)
    ratio = float(slot - 1) if total == 2 else (slot - 1) / (total - 1)
    return box.y + edge_padding + ratio * available_height


def _target_port_y(*, box: NodeBox, slot: int, total: int) -> float:
    """Compute target-side y-port with extra spacing for merge readability."""

    if total <= 1:
        return box.y + box.height / 2

    edge_padding = min(8.0, box.height * 0.12)
    available_height = max(0.0, box.height - 2 * edge_padding)
    ratio = float(slot - 1) if total == 2 else (slot - 1) / (total - 1)
    return box.y + edge_padding + ratio * available_height


def _rounded_orthogonal_path(
    *,
    points: list[tuple[float, float]],
    corner_radius: float,
) -> str:
    """Build an SVG path with rounded corners along orthogonal points."""

    if len(points) < 2:
        return ""

    commands = [f"M{points[0][0]:.1f},{points[0][1]:.1f}"]
    for index in range(1, len(points) - 1):
        prev_x, prev_y = points[index - 1]
        cur_x, cur_y = points[index]
        next_x, next_y = points[index + 1]

        dx1 = cur_x - prev_x
        dy1 = cur_y - prev_y
        dx2 = next_x - cur_x
        dy2 = next_y - cur_y
        len1 = abs(dx1) + abs(dy1)
        len2 = abs(dx2) + abs(dy2)
        radius = min(corner_radius, len1 / 2, len2 / 2)

        if radius <= 0.0:
            commands.append(f"L{cur_x:.1f},{cur_y:.1f}")
            continue

        in_x = cur_x - (radius if dx1 > 0 else -radius if dx1 < 0 else 0.0)
        in_y = cur_y - (radius if dy1 > 0 else -radius if dy1 < 0 else 0.0)
        out_x = cur_x + (radius if dx2 > 0 else -radius if dx2 < 0 else 0.0)
        out_y = cur_y + (radius if dy2 > 0 else -radius if dy2 < 0 else 0.0)

        commands.append(f"L{in_x:.1f},{in_y:.1f}")
        commands.append(f"Q{cur_x:.1f},{cur_y:.1f} {out_x:.1f},{out_y:.1f}")

    last_x, last_y = points[-1]
    commands.append(f"L{last_x:.1f},{last_y:.1f}")
    return " ".join(commands)


def _target_side_turn_x(*, x1: float, x2: float) -> float:
    """Choose an orthogonal turn x-position close to target side."""

    span = x2 - x1
    near_target = x2 - min(72.0, span * 0.35)
    return max(x1 + 12.0, near_target)


def _build_target_incoming_counts(*, graph: GraphSpec) -> dict[str, int]:
    """Count how many edges flow into each target node."""

    counts: dict[str, int] = {}
    for edge in graph.edges:
        counts[edge.target] = counts.get(edge.target, 0) + 1
    return counts


def _build_target_spine_x(*, graph: GraphSpec, layout: LayoutPlan) -> dict[str, float]:
    """Compute a shared orthogonal spine x-position for each merge target."""

    incoming_sources_right: dict[str, list[float]] = {}
    for edge in graph.edges:
        source_box = layout.boxes.get(edge.source)
        target_box = layout.boxes.get(edge.target)
        if source_box is None or target_box is None:
            continue
        source_right = source_box.x + source_box.width
        incoming_sources_right.setdefault(edge.target, []).append(source_right)

    spines: dict[str, float] = {}
    for target_id, source_rights in incoming_sources_right.items():
        if len(source_rights) <= 1:
            continue
        target_box = layout.boxes.get(target_id)
        if target_box is None:
            continue

        target_x = target_box.x
        min_gap = min(
            max(0.0, target_x - source_right) for source_right in source_rights
        )
        offset = min(72.0, max(16.0, min_gap * 0.35))
        spines[target_id] = target_x - offset

    return spines


def _merge_target_turn_x(*, x1: float, x2: float, preferred_spine_x: float) -> float:
    """Choose merge bend x while preserving a visible terminal segment."""

    min_bend_x = x1 + 18.0
    max_bend_x = x2 - 28.0

    if max_bend_x <= min_bend_x:
        return min_bend_x

    return min(max(preferred_spine_x, min_bend_x), max_bend_x)
