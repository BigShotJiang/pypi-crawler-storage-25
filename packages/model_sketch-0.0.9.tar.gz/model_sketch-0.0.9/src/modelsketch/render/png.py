"""PNG export helpers derived from SVG output."""

from __future__ import annotations

import importlib
from typing import Any, cast


def svg_to_png(*, svg: str, scale: float, background: str, dpi: int) -> bytes:
    """Convert SVG content into PNG bytes.

    Args:
        svg: SVG document to rasterize.
        scale: Rasterization scale factor.
        background: Background color applied during rasterization.
        dpi: DPI metadata for raster output when supported.

    Returns:
        PNG bytes.
    """

    try:
        cairosvg = importlib.import_module("cairosvg")
    except ImportError as exc:
        msg = (
            "CairoSVG is required for PNG export but is not available in the current "
            "environment. Install optional PNG dependencies with 'pip install "
            "model-sketch[png]'."
        )
        raise RuntimeError(msg) from exc

    payload = cast(
        "Any",
        cairosvg.svg2png(
            bytestring=svg.encode("utf-8"),
            scale=scale,
            background_color=background,
            dpi=dpi,
        ),
    )
    return cast("bytes", payload)
