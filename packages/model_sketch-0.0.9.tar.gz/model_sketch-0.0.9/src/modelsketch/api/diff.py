"""Model-to-model architecture diff helpers."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from modelsketch.api.sketch import SketchOptions, SketchResult, sketch_model
from modelsketch.extract import extract_graph
from modelsketch.patterns import PatternSummary, detect_patterns
from modelsketch.semantic import build_semantic_model

if TYPE_CHECKING:
    from collections.abc import Mapping

    from modelsketch.semantic.models import SemanticModel


@dataclass(frozen=True)
class ModelDiffSummary:
    """Summary of architecture-level differences between two model views.

    Attributes:
        added_labels: Labels present only in candidate model view.
        removed_labels: Labels present only in baseline model view.
        common_labels: Labels shared between both model views.
    """

    added_labels: list[str] = field(default_factory=list)
    removed_labels: list[str] = field(default_factory=list)
    common_labels: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ModelDiffResult:
    """Result of comparing two model architecture views.

    Attributes:
        baseline: Sketch result for baseline model.
        candidate: Sketch result for candidate model.
        summary: Label-level architecture difference summary.
    """

    baseline: SketchResult
    candidate: SketchResult
    summary: ModelDiffSummary


def diff_models(
    baseline_model: Any,
    candidate_model: Any,
    *,
    example_args: tuple[Any, ...] = (),
    example_kwargs: Mapping[str, Any] | None = None,
    options: SketchOptions | None = None,
) -> ModelDiffResult:
    """Compare two model architectures under a shared sketch configuration.

    The default comparison view uses semantic blocks with compact labels and
    repeated-block collapse enabled.

    Args:
        baseline_model: Reference model used as diff baseline.
        candidate_model: Candidate model compared against baseline.
        example_args: Example positional arguments for both model forwards.
        example_kwargs: Example keyword arguments for both model forwards.
        options: Optional sketch options shared by both runs.

    Returns:
        ModelDiffResult containing both sketches and a diff summary.
    """

    effective_options = options or SketchOptions(
        semantic_view="blocks",
        semantic_compact_block_labels=True,
        semantic_collapse_repeated_blocks=True,
        detect_patterns=True,
        edge_style="orthogonal",
    )
    normalized_kwargs = dict(example_kwargs or {})

    baseline = sketch_model(
        model=baseline_model,
        example_args=example_args,
        example_kwargs=normalized_kwargs,
        options=effective_options,
    )
    candidate = sketch_model(
        model=candidate_model,
        example_args=example_args,
        example_kwargs=normalized_kwargs,
        options=effective_options,
    )

    baseline_counter = _collect_view_labels(
        model=baseline_model,
        example_args=example_args,
        example_kwargs=normalized_kwargs,
        options=effective_options,
    )
    candidate_counter = _collect_view_labels(
        model=candidate_model,
        example_args=example_args,
        example_kwargs=normalized_kwargs,
        options=effective_options,
    )

    added_counter = candidate_counter - baseline_counter
    removed_counter = baseline_counter - candidate_counter
    common_counter = baseline_counter & candidate_counter

    summary = ModelDiffSummary(
        added_labels=_counter_to_sorted_labels(added_counter),
        removed_labels=_counter_to_sorted_labels(removed_counter),
        common_labels=_counter_to_sorted_labels(common_counter),
    )
    return ModelDiffResult(baseline=baseline, candidate=candidate, summary=summary)


def _collect_view_labels(
    *,
    model: Any,
    example_args: tuple[Any, ...],
    example_kwargs: Mapping[str, Any],
    options: SketchOptions,
) -> Counter[str]:
    """Collect label multiset for the requested semantic view configuration."""

    graph = extract_graph(model, args=example_args, kwargs=example_kwargs)
    semantic_model = build_semantic_model(graph, grouping=options.semantic_grouping)
    pattern_summary = (
        detect_patterns(graph=graph, semantic_model=semantic_model)
        if options.detect_patterns
        else PatternSummary()
    )

    if options.semantic_view == "layers":
        return Counter(node.label for node in graph.nodes)

    labels = _semantic_block_view_labels(
        semantic_model=semantic_model,
        pattern_summary=pattern_summary,
        compact_block_labels=options.semantic_compact_block_labels,
        collapse_repeated_blocks=options.semantic_collapse_repeated_blocks,
    )
    return Counter(labels)


def _semantic_block_view_labels(
    *,
    semantic_model: SemanticModel,
    pattern_summary: PatternSummary,
    compact_block_labels: bool,
    collapse_repeated_blocks: bool,
) -> list[str]:
    """Build ordered block-view labels with optional repeated motif collapse."""

    stage_groups: dict[str, dict[int, tuple[str, int]]] = {}
    if collapse_repeated_blocks:
        for pattern in pattern_summary.repeated_blocks:
            if len(pattern.stage_block_indices) <= 1:
                continue
            group_value = (pattern.signature, len(pattern.stage_block_indices))
            stage_groups.setdefault(pattern.stage_name, {})
            for block_index in pattern.stage_block_indices:
                stage_groups[pattern.stage_name][block_index] = group_value

    labels: list[str] = []
    emitted_groups: set[tuple[str, str]] = set()

    for stage in semantic_model.stages:
        for block_index, block in enumerate(stage.blocks):
            block_label = _format_block_label(
                block_name=block.name,
                output_shape=block.output_shape,
                compact=compact_block_labels,
            )
            group = stage_groups.get(stage.name, {}).get(block_index)
            if group is None:
                labels.append(block_label)
                continue

            signature, occurrences = group
            group_key = (stage.name, signature)
            if group_key in emitted_groups:
                continue
            emitted_groups.add(group_key)
            labels.append(f"Repeated x{occurrences}: {block_label}")

    return labels


def _format_block_label(
    *,
    block_name: str,
    output_shape: str | None,
    compact: bool,
) -> str:
    """Format semantic block label to match sketch block-view naming behavior."""

    name = block_name
    prefix = "Module: "
    if name.startswith(prefix):
        name = name[len(prefix) :]

    if compact:
        segments = name.split(".")
        if len(segments) > 2:
            name = ".".join(segments[-2:])

    if output_shape:
        return f"{name} {output_shape}"
    return name


def _counter_to_sorted_labels(counter: Counter[str]) -> list[str]:
    """Convert multiset into sorted user-facing labels with multiplicity."""

    labels: list[str] = []
    for label in sorted(counter):
        count = counter[label]
        if count <= 1:
            labels.append(label)
        else:
            labels.append(f"{label} (x{count})")
    return labels
