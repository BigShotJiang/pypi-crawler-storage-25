"""High-level API for generating model architecture sketches."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from modelsketch.api.notebook import display_sketch
from modelsketch.extract import GraphEdge, GraphNode, GraphSpec, extract_graph
from modelsketch.layout import plan_layout
from modelsketch.patterns import PatternSummary, detect_patterns
from modelsketch.render import render_svg, svg_to_png
from modelsketch.semantic import SemanticGrouping, build_semantic_model

if TYPE_CHECKING:
    from collections.abc import Mapping

    from modelsketch.semantic.models import SemanticModel

OutputFormat = Literal["svg", "png", "both"]
NotebookFormat = Literal["auto", "svg", "png"]
SemanticView = Literal["layers", "blocks"]
EdgeStyle = Literal["straight", "orthogonal"]


@dataclass(frozen=True)
class SketchResult:
    """Container for generated sketch outputs.

    Attributes:
        svg: SVG document string generated for the model.
        png: Optional PNG payload generated from the SVG document.
        patterns: Optional detected architecture pattern summary.
    """

    svg: str
    png: bytes | None = None
    patterns: PatternSummary = field(default_factory=PatternSummary)


@dataclass(frozen=True)
class SketchOptions:
    """Output options accepted by the sketch API.

    Attributes:
        output_format: Output format to generate.
        png_scale: Rasterization scale used for PNG conversion.
        png_background: PNG background color.
        png_dpi: PNG DPI metadata when supported by backend.
        save_svg_path: Optional filesystem path where SVG is saved.
        save_png_path: Optional filesystem path where PNG is saved.
        render_in_notebook: Whether to display the result in a notebook.
        notebook_format: Notebook display preference.
        semantic_grouping: Semantic grouping strategy for block construction.
        semantic_inter_block_gap: Extra horizontal gap between semantic blocks.
        semantic_view: Display layers directly or collapsed semantic blocks.
        semantic_compact_block_labels: Whether block labels use compact names.
        semantic_collapse_repeated_blocks: Collapse repeated blocks into motifs.
        detect_patterns: Whether semantic/graph pattern detection is performed.
        show_plumbing_ops: Whether low-level plumbing ops (for example getitem)
            are retained in rendered graphs.
        edge_style: SVG edge style used for graph links.
        edge_arrowheads: Whether SVG edges include arrowheads.
    """

    output_format: OutputFormat = "svg"
    png_scale: float = 2.0
    png_background: str = "white"
    png_dpi: int = 300
    save_svg_path: str | Path | None = None
    save_png_path: str | Path | None = None
    render_in_notebook: bool = False
    notebook_format: NotebookFormat = "auto"
    semantic_grouping: SemanticGrouping = "module_prefix"
    semantic_inter_block_gap: float = 96.0
    semantic_view: SemanticView = "layers"
    semantic_compact_block_labels: bool = False
    semantic_collapse_repeated_blocks: bool = False
    detect_patterns: bool = True
    show_plumbing_ops: bool = False
    edge_style: EdgeStyle = "straight"
    edge_arrowheads: bool = False


def sketch_model(
    model: Any,
    *,
    example_args: tuple[Any, ...] = (),
    example_kwargs: Mapping[str, Any] | None = None,
    options: SketchOptions | None = None,
) -> SketchResult:
    """Generate a model sketch using the MVP pipeline.

    Args:
        model: PyTorch model object to visualize.
        example_args: Example positional arguments for model forward execution.
        example_kwargs: Example keyword arguments for model forward execution.
        options: Output options controlling format and PNG conversion settings.

    Returns:
        SketchResult with SVG output and optional PNG bytes.
    """

    effective_options = options or SketchOptions()
    _validate_options(effective_options)

    normalized_kwargs = dict(example_kwargs or {})
    graph = extract_graph(
        model,
        args=example_args,
        kwargs=normalized_kwargs,
        collapse_getitem_nodes=not effective_options.show_plumbing_ops,
    )
    semantic_model = build_semantic_model(
        graph,
        grouping=effective_options.semantic_grouping,
    )
    detected_patterns = (
        detect_patterns(graph=graph, semantic_model=semantic_model)
        if effective_options.detect_patterns
        else PatternSummary()
    )
    if effective_options.semantic_view == "layers":
        render_graph = graph
    else:
        render_graph = _collapse_graph_to_semantic_blocks(
            graph=graph,
            semantic_model=semantic_model,
            pattern_summary=detected_patterns,
            compact_block_labels=effective_options.semantic_compact_block_labels,
            collapse_repeated_blocks=(
                effective_options.semantic_collapse_repeated_blocks
            ),
        )
    layout = plan_layout(
        render_graph,
        semantic_model=(
            semantic_model if effective_options.semantic_view == "layers" else None
        ),
        inter_block_gap=effective_options.semantic_inter_block_gap,
    )
    svg = render_svg(
        graph=render_graph,
        layout=layout,
        edge_style=effective_options.edge_style,
        arrowheads=effective_options.edge_arrowheads,
    )

    png_payload: bytes | None = None
    if effective_options.output_format in {"png", "both"}:
        png_payload = svg_to_png(
            svg=svg,
            scale=effective_options.png_scale,
            background=effective_options.png_background,
            dpi=effective_options.png_dpi,
        )

    if effective_options.save_svg_path is not None:
        _write_text_file(effective_options.save_svg_path, svg)

    if effective_options.save_png_path is not None:
        if png_payload is None:
            png_payload = svg_to_png(
                svg=svg,
                scale=effective_options.png_scale,
                background=effective_options.png_background,
                dpi=effective_options.png_dpi,
            )
        _write_binary_file(effective_options.save_png_path, png_payload)

    result = SketchResult(svg=svg, png=png_payload, patterns=detected_patterns)

    if effective_options.render_in_notebook:
        display_sketch(result, preferred_format=effective_options.notebook_format)

    return result


def _validate_options(options: SketchOptions) -> None:
    """Validate public sketch options with actionable error messages."""

    if options.output_format not in {"svg", "png", "both"}:
        msg = "output_format must be one of: 'svg', 'png', 'both'"
        raise ValueError(msg)

    if options.semantic_grouping not in {"module_prefix", "single_block"}:
        msg = "semantic_grouping must be one of: 'module_prefix', 'single_block'"
        raise ValueError(msg)

    if options.semantic_inter_block_gap < 0.0:
        msg = "semantic_inter_block_gap must be non-negative"
        raise ValueError(msg)

    if options.semantic_view not in {"layers", "blocks"}:
        msg = "semantic_view must be one of: 'layers', 'blocks'"
        raise ValueError(msg)

    if options.notebook_format not in {"auto", "svg", "png"}:
        msg = "notebook_format must be one of: 'auto', 'svg', 'png'"
        raise ValueError(msg)

    if options.edge_style not in {"straight", "orthogonal"}:
        msg = "edge_style must be one of: 'straight', 'orthogonal'"
        raise ValueError(msg)


def _write_text_file(path: str | Path, content: str) -> None:
    """Write UTF-8 text content and create parent directories when needed."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")


def _write_binary_file(path: str | Path, content: bytes) -> None:
    """Write binary content and create parent directories when needed."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(content)


@dataclass(frozen=True)
class _SemanticBlockRecord:
    """Internal semantic block record for deterministic graph conversion."""

    block_id: str
    stage_name: str
    stage_block_index: int
    label: str
    layer_ids: list[str]


def _collapse_graph_to_semantic_blocks(
    *,
    graph: GraphSpec,
    semantic_model: SemanticModel,
    pattern_summary: PatternSummary,
    compact_block_labels: bool,
    collapse_repeated_blocks: bool,
) -> GraphSpec:
    """Build block-level graph so rendering shows semantic blocks, not raw layers."""

    records = _build_semantic_block_records(
        semantic_model=semantic_model,
        compact_block_labels=compact_block_labels,
    )

    node_to_block_id: dict[str, str] = {}
    for record in records:
        for layer_id in record.layer_ids:
            node_to_block_id[layer_id] = record.block_id

    group_map = _build_block_group_map(
        records=records,
        pattern_summary=pattern_summary,
        collapse_repeated_blocks=collapse_repeated_blocks,
    )

    block_nodes = _build_group_nodes(records=records, group_map=group_map)
    dedup_edges: dict[tuple[str, str], None] = {}
    for edge in graph.edges:
        source_block = node_to_block_id.get(edge.source)
        target_block = node_to_block_id.get(edge.target)
        if source_block is None or target_block is None:
            continue
        source_group = group_map[source_block]
        target_group = group_map[target_block]
        if source_group == target_group:
            continue
        dedup_edges[(source_group, target_group)] = None

    block_edges = [
        GraphEdge(source=source, target=target) for source, target in dedup_edges
    ]
    return GraphSpec(nodes=block_nodes, edges=block_edges)


def _build_semantic_block_records(
    *,
    semantic_model: SemanticModel,
    compact_block_labels: bool,
) -> list[_SemanticBlockRecord]:
    """Build deterministic semantic block records in stage order."""

    records: list[_SemanticBlockRecord] = []
    global_index = 0
    for stage in semantic_model.stages:
        for stage_block_index, block in enumerate(stage.blocks):
            if not block.layers:
                continue
            block_id = f"semantic_block_{global_index}"
            global_index += 1
            records.append(
                _SemanticBlockRecord(
                    block_id=block_id,
                    stage_name=stage.name,
                    stage_block_index=stage_block_index,
                    label=_block_label(
                        block_name=block.name,
                        output_shape=block.output_shape,
                        compact=compact_block_labels,
                    ),
                    layer_ids=[layer.id for layer in block.layers],
                )
            )
    return records


def _build_block_group_map(
    *,
    records: list[_SemanticBlockRecord],
    pattern_summary: PatternSummary,
    collapse_repeated_blocks: bool,
) -> dict[str, str]:
    """Assign each semantic block id to itself or to a repeated motif group."""

    group_map = {record.block_id: record.block_id for record in records}
    if not collapse_repeated_blocks:
        return group_map

    indexed_records = {
        (record.stage_name, record.stage_block_index): record for record in records
    }

    for pattern_index, pattern in enumerate(pattern_summary.repeated_blocks):
        if len(pattern.stage_block_indices) <= 1:
            continue
        group_id = f"semantic_pattern_{pattern_index}"
        for stage_block_index in pattern.stage_block_indices:
            record = indexed_records.get((pattern.stage_name, stage_block_index))
            if record is None:
                continue
            group_map[record.block_id] = group_id

    return group_map


def _build_group_nodes(
    *,
    records: list[_SemanticBlockRecord],
    group_map: dict[str, str],
) -> list[GraphNode]:
    """Build semantic and motif nodes preserving deterministic stage order."""

    nodes: list[GraphNode] = []
    seen_group_ids: set[str] = set()
    grouped_records: dict[str, list[_SemanticBlockRecord]] = {}
    for record in records:
        group_id = group_map[record.block_id]
        grouped_records.setdefault(group_id, []).append(record)

    for record in records:
        group_id = group_map[record.block_id]
        if group_id in seen_group_ids:
            continue
        seen_group_ids.add(group_id)

        members = grouped_records[group_id]
        if len(members) <= 1:
            nodes.append(
                GraphNode(
                    id=group_id,
                    op_type="semantic_block",
                    label=members[0].label,
                )
            )
            continue

        nodes.append(
            GraphNode(
                id=group_id,
                op_type="semantic_motif",
                label=_collapsed_repeated_label(
                    representative_label=members[0].label,
                    occurrences=len(members),
                ),
            )
        )

    return nodes


def _collapsed_repeated_label(*, representative_label: str, occurrences: int) -> str:
    """Build label for a repeated semantic motif node."""

    return f"Repeated x{occurrences}: {representative_label}"


def _block_label(*, block_name: str, output_shape: str | None, compact: bool) -> str:
    """Build user-facing block label with optional shape summary."""

    name = _block_display_name(block_name, compact=compact)
    if output_shape:
        return f"{name} {output_shape}"
    return name


def _block_display_name(block_name: str, *, compact: bool) -> str:
    """Convert internal semantic block name into a user-facing display label."""

    prefix = "Module: "
    name = block_name[len(prefix) :] if block_name.startswith(prefix) else block_name

    if not compact:
        return name

    segments = name.split(".")
    if len(segments) <= 2:
        return name
    return ".".join(segments[-2:])
