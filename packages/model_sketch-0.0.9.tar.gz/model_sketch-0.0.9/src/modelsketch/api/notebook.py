"""Notebook display helpers for sketch outputs."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from modelsketch.api.sketch import SketchResult

NotebookFormat = Literal["auto", "svg", "png"]


def display_sketch(
    result: SketchResult,
    *,
    preferred_format: NotebookFormat,
) -> bool:
    """Render a sketch in notebook output if IPython display is available.

    Args:
        result: Sketch result containing SVG and optional PNG payloads.
        preferred_format: Display preference (auto, svg, or png).

    Returns:
        True when content was displayed, otherwise False.
    """

    try:
        ipy_display = importlib.import_module("IPython.display")
    except ImportError:
        return False

    use_png = preferred_format == "png" or (
        preferred_format == "auto" and result.png is not None
    )

    if use_png and result.png is not None:
        image = ipy_display.Image(data=result.png, format="png")
        ipy_display.display(image)
        return True

    svg = ipy_display.SVG(data=result.svg)
    ipy_display.display(svg)
    return True
