"""Simple layout planner for MVP model diagrams."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING

from modelsketch.layout.types import LayoutPlan, NodeBox

if TYPE_CHECKING:
    from modelsketch.extract.models import GraphNode, GraphSpec
    from modelsketch.semantic.models import SemanticModel


@dataclass(frozen=True)
class _LayoutConfig:
    """Internal configuration for layout planning helpers."""

    start_x: float
    start_y: float
    min_box_width: float
    box_height: float
    gap: float
    inter_block_gap: float
    lane_gap: float = 72.0


_FONT_SIZE = 14.0
_AVG_CHAR_WIDTH = _FONT_SIZE * 0.6
_TEXT_PADDING_X = 24.0


def plan_layout(
    graph: GraphSpec,
    *,
    semantic_model: SemanticModel | None = None,
    inter_block_gap: float = 96.0,
) -> LayoutPlan:
    """Plan a deterministic left-to-right layout for graph nodes.

    Args:
        graph: Extracted model graph.
        semantic_model: Optional semantic grouping used for visual spacing.
        inter_block_gap: Horizontal gap inserted between semantic blocks.

    Returns:
        Layout plan with node boxes and viewport dimensions.
    """

    start_x = 24.0
    start_y = 24.0
    min_box_width = 180.0
    box_height = 72.0
    gap = 48.0

    if inter_block_gap < 0.0:
        msg = "inter_block_gap must be non-negative"
        raise ValueError(msg)

    node_to_block = _node_to_block_mapping(semantic_model)

    config = _LayoutConfig(
        start_x=start_x,
        start_y=start_y,
        min_box_width=min_box_width,
        box_height=box_height,
        gap=gap,
        inter_block_gap=inter_block_gap,
    )
    node_widths = _node_widths(graph=graph, min_box_width=min_box_width)

    if not graph.edges or not _has_branching(graph):
        return _plan_sequential_layout(
            graph=graph,
            node_to_block=node_to_block,
            config=config,
            node_widths=node_widths,
        )

    return _plan_depth_layout(
        graph=graph,
        node_to_block=node_to_block,
        config=config,
        node_widths=node_widths,
    )


def _plan_sequential_layout(
    *,
    graph: GraphSpec,
    node_to_block: dict[str, str],
    config: _LayoutConfig,
    node_widths: dict[str, float],
) -> LayoutPlan:
    """Plan a one-row left-to-right layout."""

    boxes: dict[str, NodeBox] = {}
    cursor_x = config.start_x
    previous_block: str | None = None
    previous_width: float | None = None

    for node in graph.nodes:
        current_block = node_to_block.get(node.id)
        if boxes:
            step_gap = (
                config.inter_block_gap
                if current_block != previous_block
                else config.gap
            )
            if previous_width is None:
                previous_width = config.min_box_width
            cursor_x += previous_width + step_gap
        box_width = node_widths[node.id]
        x = cursor_x
        boxes[node.id] = NodeBox(
            x=x,
            y=config.start_y,
            width=box_width,
            height=config.box_height,
        )
        previous_block = current_block
        previous_width = box_width

    if boxes:
        width = cursor_x + (previous_width or config.min_box_width) + config.start_x
    else:
        width = config.start_x * 2
    height = config.start_y * 2 + config.box_height

    return LayoutPlan(boxes=boxes, width=width, height=height)


def _plan_depth_layout(
    *,
    graph: GraphSpec,
    node_to_block: dict[str, str],
    config: _LayoutConfig,
    node_widths: dict[str, float],
) -> LayoutPlan:
    """Plan a deterministic depth-based layout for branching graphs."""

    incoming: dict[str, list[str]] = defaultdict(list)
    for edge in graph.edges:
        incoming[edge.target].append(edge.source)

    depth_by_node: dict[str, int] = {}
    nodes_by_depth: dict[int, list[str]] = defaultdict(list)

    topo_nodes = _topological_nodes(graph)
    for node in topo_nodes:
        parent_depth = max(
            (depth_by_node.get(src, 0) for src in incoming[node.id]),
            default=-1,
        )
        depth = parent_depth + 1
        depth_by_node[node.id] = depth
        nodes_by_depth[depth].append(node.id)

    sorted_depths = sorted(nodes_by_depth)
    node_order = {node.id: index for index, node in enumerate(graph.nodes)}
    lane_index_by_node: dict[str, int] = {}
    for depth in sorted_depths:
        ordered_nodes = _order_depth_nodes(
            nodes=nodes_by_depth[depth],
            incoming=incoming,
            lane_index_by_node=lane_index_by_node,
            node_order=node_order,
        )
        nodes_by_depth[depth] = ordered_nodes
        for lane_index, node_id in enumerate(ordered_nodes):
            lane_index_by_node[node_id] = lane_index

    x_by_depth: dict[int, float] = {}
    cursor_x = config.start_x
    previous_depth_block: str | None = None

    for depth in sorted_depths:
        x_by_depth[depth] = cursor_x
        representative = nodes_by_depth[depth][0]
        current_block = node_to_block.get(representative)
        depth_width = max(node_widths[node_id] for node_id in nodes_by_depth[depth])
        step_gap = (
            config.inter_block_gap
            if previous_depth_block is not None
            and current_block != previous_depth_block
            else config.gap
        )
        cursor_x += depth_width + step_gap
        previous_depth_block = current_block

    boxes: dict[str, NodeBox] = {}
    max_lanes = 1
    for depth in sorted_depths:
        lanes = nodes_by_depth[depth]
        max_lanes = max(max_lanes, len(lanes))
        for lane_index, node_id in enumerate(lanes):
            y = config.start_y + lane_index * (config.box_height + config.lane_gap)
            if len(lanes) == 1:
                y = _singleton_depth_y(
                    node_id=node_id,
                    incoming=incoming,
                    boxes=boxes,
                    default_y=y,
                    config=config,
                )
            boxes[node_id] = NodeBox(
                x=x_by_depth[depth],
                y=y,
                width=node_widths[node_id],
                height=config.box_height,
            )

    if sorted_depths:
        last_depth = sorted_depths[-1]
        last_depth_width = max(
            node_widths[node_id] for node_id in nodes_by_depth[last_depth]
        )
        width = x_by_depth[last_depth] + last_depth_width + config.start_x
    else:
        width = config.start_x * 2

    max_bottom = max((box.y + box.height for box in boxes.values()), default=0.0)
    height = max(config.start_y * 2 + config.box_height, max_bottom + config.start_y)
    return LayoutPlan(boxes=boxes, width=width, height=height)


def _node_to_block_mapping(semantic_model: SemanticModel | None) -> dict[str, str]:
    """Create a lookup from node id to semantic block name."""

    if semantic_model is None:
        return {}

    mapping: dict[str, str] = {}
    for stage in semantic_model.stages:
        for block in stage.blocks:
            for layer in block.layers:
                mapping[layer.id] = block.name
    return mapping


def _has_branching(graph: GraphSpec) -> bool:
    """Return True when the graph includes split or merge connectivity."""

    outgoing_count: dict[str, int] = defaultdict(int)
    incoming_count: dict[str, int] = defaultdict(int)

    for edge in graph.edges:
        outgoing_count[edge.source] += 1
        incoming_count[edge.target] += 1

    return any(count > 1 for count in outgoing_count.values()) or any(
        count > 1 for count in incoming_count.values()
    )


def _topological_nodes(graph: GraphSpec) -> list[GraphNode]:
    """Return nodes in a deterministic topological order."""

    node_map = {node.id: node for node in graph.nodes}
    node_order = {node.id: index for index, node in enumerate(graph.nodes)}
    incoming_count = {node.id: 0 for node in graph.nodes}
    outgoing: dict[str, list[str]] = defaultdict(list)

    for edge in graph.edges:
        if edge.source not in node_map or edge.target not in node_map:
            continue
        outgoing[edge.source].append(edge.target)
        incoming_count[edge.target] += 1

    queue = sorted(
        [node_id for node_id, count in incoming_count.items() if count == 0],
        key=lambda node_id: node_order[node_id],
    )
    result: list[GraphNode] = []

    while queue:
        node_id = queue.pop(0)
        result.append(node_map[node_id])
        for target_id in outgoing.get(node_id, []):
            incoming_count[target_id] -= 1
            if incoming_count[target_id] == 0:
                queue.append(target_id)
        queue.sort(key=lambda item: node_order[item])

    if len(result) == len(graph.nodes):
        return result

    ordered_ids = {ordered.id for ordered in result}
    remaining = [node for node in graph.nodes if node.id not in ordered_ids]
    return result + remaining


def _singleton_depth_y(
    *,
    node_id: str,
    incoming: dict[str, list[str]],
    boxes: dict[str, NodeBox],
    default_y: float,
    config: _LayoutConfig,
) -> float:
    """Place singleton-depth node based on already placed parents."""

    parents = incoming.get(node_id, [])
    parent_centers = [
        boxes[parent].y + boxes[parent].height / 2
        for parent in parents
        if parent in boxes
    ]
    if not parent_centers:
        return default_y

    if len(parent_centers) == 1:
        parent_id = parents[0]
        if parent_id in boxes:
            return max(config.start_y, boxes[parent_id].y)
        return default_y

    min_center = min(parent_centers)
    max_center = max(parent_centers)
    centered_y = (min_center + max_center) / 2 - config.box_height / 2
    return max(config.start_y, centered_y)


def _order_depth_nodes(
    *,
    nodes: list[str],
    incoming: dict[str, list[str]],
    lane_index_by_node: dict[str, int],
    node_order: dict[str, int],
) -> list[str]:
    """Order nodes by parent lane barycenter to reduce edge crossings."""

    def sort_key(node_id: str) -> tuple[float, int]:
        parent_lanes = [
            lane_index_by_node[parent]
            for parent in incoming[node_id]
            if parent in lane_index_by_node
        ]
        if parent_lanes:
            parent_mean = sum(parent_lanes) / len(parent_lanes)
            return (parent_mean, node_order[node_id])
        return (float(node_order[node_id]), node_order[node_id])

    return sorted(nodes, key=sort_key)


def _node_widths(*, graph: GraphSpec, min_box_width: float) -> dict[str, float]:
    """Estimate per-node box width from label length with a minimum width floor."""

    widths: dict[str, float] = {}
    for node in graph.nodes:
        label_width = len(node.label) * _AVG_CHAR_WIDTH + _TEXT_PADDING_X
        widths[node.id] = max(min_box_width, label_width)
    return widths
