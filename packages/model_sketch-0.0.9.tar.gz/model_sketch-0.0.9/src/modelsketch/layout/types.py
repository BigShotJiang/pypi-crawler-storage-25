"""Data models for node layout positions."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class NodeBox:
    """Rectangular layout box for a rendered node.

    Attributes:
        x: Left coordinate in pixels.
        y: Top coordinate in pixels.
        width: Box width in pixels.
        height: Box height in pixels.
    """

    x: float
    y: float
    width: float
    height: float


@dataclass(frozen=True)
class LayoutPlan:
    """Deterministic placement map and viewport size.

    Attributes:
        boxes: Mapping from node id to layout box.
        width: Total viewport width.
        height: Total viewport height.
    """

    boxes: dict[str, NodeBox] = field(default_factory=dict)
    width: float = 0.0
    height: float = 0.0
