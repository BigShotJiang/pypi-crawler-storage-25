import pytest
import anyio
import logging
import py_aide.tokens
from fastapi.testclient import TestClient
from py_aide.servers.fastApi import FastAPIServicePortal
from py_aide.servers.gate import AuthType
from py_aide.tokens import TokenRegistry, TokenValidationResult

# Configure logging
logging.basicConfig(level=logging.DEBUG)

@pytest.fixture
def portal():
    # Force registration on the module's TokenRegistry
    def bearer_masker(val): return f"token_{val}"
    def bearer_unmasker(token):
        if token.startswith("token_"):
            return TokenValidationResult(initial_value=token[6:], is_active=True)
        return None
    
    print(f"DEBUG: Registry ID in fixture: {id(py_aide.tokens.TokenRegistry)}")
    py_aide.tokens.TokenRegistry._session_masker["bearer"] = bearer_masker
    py_aide.tokens.TokenRegistry._session_unmasker["bearer"] = bearer_unmasker
    
    p = FastAPIServicePortal(enable_websocket=True, debug=True)
    p._bind_routes()
    return p

@pytest.mark.anyio
async def test_websocket_targeted_delivery(portal):
    user_id = "user_123"
    token = portal.token_manager.create_session_token(user_id, token_type="bearer")
    
    @portal.on_event("ping", auth_required=True, auth_type=AuthType.BEARER, auth_token_key="token")
    async def handle_ping(data, sid):
        return {"status": "pong"}

    with TestClient(portal.app) as client:
        # Scenario 1: Multiple clients for the same User ID
        with client.websocket_connect("/ws") as ws1, \
             client.websocket_connect("/ws") as ws2:
            
            # Authenticate both
            ws1.send_json({"event": "ping", "data": {"token": token}})
            ws2.send_json({"event": "ping", "data": {"token": token}})
            
            res1 = ws1.receive_json()
            if res1.get("event") == "error":
                print(f"DEBUG: WS1 Error: {res1.get('data')}")
            assert res1["event"] == "ping_response"

            res2 = ws2.receive_json()
            if res2.get("event") == "error":
                print(f"DEBUG: WS2 Error: {res2.get('data')}")
            assert res2["event"] == "ping_response"
            
            # Send targeted message from server side to the User ID
            await portal.send_to_user(user_id, "alert", {"msg": "hello all"})
            
            # BOTH clients should receive it
            msg1 = ws1.receive_json()
            msg2 = ws2.receive_json()
            
            assert msg1["event"] == "alert"
            assert msg1["data"]["msg"] == "hello all"
            assert msg2["event"] == "alert"
            assert msg2["data"]["msg"] == "hello all"

@pytest.mark.anyio
async def test_websocket_group_delivery(portal):
    @portal.on_event("join", auth_required=False)
    async def handle_join(data, sid):
        group_id = data.get("group")
        await portal.join_group(sid, group_id)
        return {"status": "joined", "group": group_id}

    with TestClient(portal.app) as client:
        with client.websocket_connect("/ws") as ws1, \
             client.websocket_connect("/ws") as ws2, \
             client.websocket_connect("/ws") as ws3:
            
            ws1.send_json({"event": "join", "data": {"group": "team_alpha"}})
            ws2.send_json({"event": "join", "data": {"group": "team_alpha"}})
            ws3.send_json({"event": "join", "data": {"group": "team_beta"}})
            
            ws1.receive_json()
            ws2.receive_json()
            ws3.receive_json()
            
            await portal.send_to_group("team_alpha", "update", {"val": 42})
            
            msg1 = ws1.receive_json()
            msg2 = ws2.receive_json()
            assert msg1["event"] == "update"
            assert msg2["event"] == "update"
            
            # ws3 should NOT receive the team_alpha message
            # We check this by sending a different message to beta
            await portal.send_to_group("team_beta", "beta_only", {"ok": True})
            msg3 = ws3.receive_json()
            assert msg3["event"] == "beta_only"

@pytest.mark.anyio
async def test_websocket_cleanup(portal):
    with TestClient(portal.app) as client:
        with client.websocket_connect("/ws") as ws:
            # Small sleep to ensure connection is tracked
            await anyio.sleep(0.1)
            sid = list(portal._ws_manager._connections.keys())[0]
            await portal.join_group(sid, "temp_group")
            assert "temp_group" in portal._ws_manager._group_to_sids
            
        # Outside with block, ws is closed
        await anyio.sleep(0.1)
        assert portal._ws_manager.active_count == 0
        assert "temp_group" not in portal._ws_manager._group_to_sids
