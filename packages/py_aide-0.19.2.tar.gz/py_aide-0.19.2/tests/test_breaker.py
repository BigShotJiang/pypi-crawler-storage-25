"""
test_breaker.py — Test suite for the hardened CircuitBreaker (v2)

Covers all 9 hardening fixes applied in the v0.18.0 rewrite:
  Fix 1: sliding window failure counter
  Fix 2: thread-safe metrics (_metrics_lock)
  Fix 3: bounded thread pool for timeouts
  Fix 4: half_open_test_count reset on HALF_OPEN entry
  Fix 5: CircuitMonitor stores weakrefs
  Fix 6: call_async() for native coroutines
  Fix 7: self.logger assigned before registry block
  Fix 8: force_open() always resets _state_change_time
  Fix 9: fallback context extraction is robust
"""

import asyncio
import gc
import threading
import time
import unittest
import weakref

# Import directly from the servers subpackage so Flask / FastAPI are not needed
import importlib.util
import pathlib

spec = importlib.util.spec_from_file_location(
    "breaker",
    pathlib.Path(__file__).parent.parent / "src/py_aide/servers/breaker.py",
)
_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_mod)

CircuitBreaker     = _mod.CircuitBreaker
CircuitMonitor     = _mod.CircuitMonitor
CircuitState       = _mod.CircuitState
CircuitEvent       = _mod.CircuitEvent
CircuitOpenError   = _mod.CircuitOpenError
circuit_breaker    = _mod.circuit_breaker
create_circuit_breaker = _mod.create_circuit_breaker


# ── helpers ──────────────────────────────────────────────────────────────────

def _boom(*_a, **_kw):
    raise RuntimeError("intentional failure")

def _ok(*_a, **_kw):
    return "ok"

def _make(name="t", **kw) -> CircuitBreaker:
    """Fresh breaker with sensible test defaults."""
    defaults = dict(
        failure_threshold=3,
        recovery_timeout=0.2,
        failure_window=1.0,
        name=name,
    )
    defaults.update(kw)
    cb = CircuitBreaker(**defaults)
    return cb


def _trip(cb: CircuitBreaker, n: int | None = None):
    """Trip the circuit by failing n times (defaults to threshold)."""
    n = n if n is not None else cb.failure_threshold
    for _ in range(n):
        try:
            cb.call(_boom)
        except Exception:
            pass


# ── Fix 1: Sliding window ────────────────────────────────────────────────────

class TestSlidingWindow(unittest.TestCase):

    def test_failures_in_window_trip_circuit(self):
        cb = _make("sw1", failure_window=1.0)
        _trip(cb)
        self.assertEqual(cb.get_state(), CircuitState.OPEN)

    def test_failures_outside_window_do_not_trip(self):
        """Failures older than failure_window should not count."""
        cb = _make("sw2", failure_threshold=3, failure_window=0.3)
        # Cause 2 failures then wait for the window to expire
        for _ in range(2):
            try:
                cb.call(_boom)
            except Exception:
                pass
        time.sleep(0.4)   # window expires
        # One more failure — count should now be 1, not 3
        try:
            cb.call(_boom)
        except Exception:
            pass
        self.assertEqual(cb.get_state(), CircuitState.CLOSED,
                         "Circuit should still be CLOSED — old failures expired")

    def test_reset_clears_window(self):
        cb = _make("sw3")
        _trip(cb)
        cb.reset()
        self.assertEqual(cb._current_failure_count(), 0)
        self.assertEqual(cb.get_state(), CircuitState.CLOSED)


# ── Fix 2: Thread-safe metrics ───────────────────────────────────────────────

class TestThreadSafeMetrics(unittest.TestCase):

    def test_metrics_lock_exists(self):
        cb = _make("m1")
        self.assertIsInstance(cb._metrics_lock, type(threading.Lock()))

    def test_concurrent_calls_produce_accurate_total(self):
        cb = _make("m2", failure_threshold=100)

        def call_many():
            for _ in range(50):
                try:
                    cb.call(_ok)
                except Exception:
                    pass

        threads = [threading.Thread(target=call_many) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(cb.metrics["total_calls"], 200)


# ── Fix 3: Bounded thread pool ───────────────────────────────────────────────

class TestBoundedThreadPool(unittest.TestCase):

    def test_class_level_executor_exists(self):
        self.assertTrue(hasattr(CircuitBreaker, "_timeout_executor"))

    def test_timeout_raises_on_slow_call(self):
        cb = _make("tp1", failure_timeout=0.1)

        def slow():
            time.sleep(1.0)

        with self.assertRaises((TimeoutError, RuntimeError)):
            cb.call(slow)

    def test_successful_call_within_timeout(self):
        cb = _make("tp2", failure_timeout=1.0)
        result = cb.call(lambda: "fast")
        self.assertEqual(result, "fast")


# ── Fix 4: half_open_test_count reset on HALF_OPEN entry ─────────────────────

class TestHalfOpenCounterReset(unittest.TestCase):

    def test_count_resets_on_every_half_open_entry(self):
        cb = _make("ho1", failure_threshold=1, recovery_timeout=0.3,
                   half_open_max_requests=1)

        # First trip: CLOSED → OPEN
        try:
            cb.call(_boom)
        except Exception:
            pass
        self.assertEqual(cb.get_state(), CircuitState.OPEN)

        # First recovery: OPEN → HALF_OPEN → OPEN (fail probe)
        time.sleep(0.4)
        try:
            cb.call(_boom)
        except Exception:
            pass
        self.assertEqual(cb.get_state(), CircuitState.OPEN)

        # _half_open_test_count must be 0 now, not 1
        self.assertEqual(cb._half_open_test_count, 0,
                         "Count must be reset when tripping back to OPEN")

        # Second recovery: OPEN → HALF_OPEN → CLOSED (success probe)
        time.sleep(0.4)
        result = cb.call(_ok)
        self.assertEqual(cb.get_state(), CircuitState.CLOSED)
        self.assertEqual(result, "ok")

    def test_count_starts_at_zero_on_half_open(self):
        cb = _make("ho2", failure_threshold=1, recovery_timeout=0.1)
        try:
            cb.call(_boom)
        except Exception:
            pass
        time.sleep(0.15)
        # Trigger HALF_OPEN transition via a call
        try:
            cb.call(_ok)
        except Exception:
            pass
        # After successful probe the breaker closes; count must be 0
        self.assertEqual(cb._half_open_test_count, 0)


# ── Fix 5: CircuitMonitor weakrefs ──────────────────────────────────────────

class TestCircuitMonitorWeakrefs(unittest.TestCase):

    def test_circuits_stored_as_weakrefs(self):
        mon = CircuitMonitor()
        cb = _make("wref1")
        mon.add_circuit(cb)
        stored = list(mon._circuits.values())[0]
        self.assertIsInstance(stored, weakref.ref,
                              "CircuitMonitor must store weakref.ref, not strong ref")

    def test_dead_refs_pruned_from_report(self):
        mon = CircuitMonitor()
        cb = _make("wref2")
        mon.add_circuit(cb)
        cb.close()
        del cb
        gc.collect()
        report = mon.get_health_report()
        self.assertEqual(report["total_circuits"], 0,
                         "Dead weakrefs must be pruned from health report")


# ── Fix 6: call_async ────────────────────────────────────────────────────────

class TestCallAsync(unittest.TestCase):

    def test_async_success(self):
        cb = _make("async1")

        async def aok():
            return "async_ok"

        result = asyncio.run(cb.call_async(aok))
        self.assertEqual(result, "async_ok")

    def test_async_failure_trips_circuit(self):
        cb = _make("async2", failure_threshold=1)

        async def aboom():
            raise RuntimeError("async boom")

        for _ in range(2):
            try:
                asyncio.run(cb.call_async(aboom))
            except Exception:
                pass

        self.assertEqual(cb.get_state(), CircuitState.OPEN)

    def test_async_fallback_called_when_open(self):
        cb = _make("async3", failure_threshold=1)
        cb.set_fallback(lambda: "fallback_result")
        try:
            cb.call(_boom)
        except Exception:
            pass

        result = asyncio.run(cb.call_async(lambda: "should_not_reach"))
        self.assertEqual(result, "fallback_result")

    def test_sync_function_via_call_async(self):
        """call_async on a sync function should delegate to call()."""
        cb = _make("async4")
        result = asyncio.run(cb.call_async(_ok))
        self.assertEqual(result, "ok")


# ── Fix 7: Logger init order ─────────────────────────────────────────────────

class TestLoggerInitOrder(unittest.TestCase):

    def test_logger_assigned_before_registry_block(self):
        """self.logger must exist after __init__ with no NameError."""
        cb = _make("log1")
        self.assertTrue(hasattr(cb, "logger"))
        self.assertIsNotNone(cb.logger)

    def test_duplicate_name_warning_does_not_crash(self):
        """Registering a duplicate name should warn, not raise."""
        cb1 = _make("log2")
        try:
            cb2 = _make("log2")  # duplicate
            cb2.close()
        except Exception as exc:
            self.fail(f"Duplicate name registration raised: {exc}")
        finally:
            cb1.close()


# ── Fix 8: force_open timer reset ───────────────────────────────────────────

class TestForceOpenTimerReset(unittest.TestCase):

    def test_force_open_resets_timer_when_already_open(self):
        cb = _make("fo1", recovery_timeout=60)
        cb.force_open()
        t1 = cb._state_change_time
        time.sleep(0.05)
        cb.force_open()   # called again while already OPEN
        t2 = cb._state_change_time
        self.assertGreater(t2, t1,
                           "force_open() must reset _state_change_time even if already OPEN")

    def test_force_open_extends_recovery_window(self):
        cb = _make("fo2", recovery_timeout=0.2)
        cb.force_open()
        time.sleep(0.15)   # almost expired
        cb.force_open()    # reset timer
        # Should NOT transition to HALF_OPEN yet
        self.assertEqual(cb.get_state(), CircuitState.OPEN)
        # The call should be blocked (fallback or error)
        cb.set_fallback(lambda: "blocked")
        result = cb.call(_ok)
        self.assertEqual(result, "blocked")

    def test_force_close_clears_counters(self):
        cb = _make("fo3")
        _trip(cb)
        cb.force_close()
        self.assertEqual(cb.get_state(), CircuitState.CLOSED)
        self.assertEqual(cb._current_failure_count(), 0)


# ── Fix 9: Robust fallback context ──────────────────────────────────────────

class TestRobustFallback(unittest.TestCase):

    def test_fallback_returns_safe_value_without_context(self):
        cb = _make("fb1", failure_threshold=1)
        cb.set_fallback(lambda *a, **kw: {"safe": True})
        try:
            cb.call(_boom)
        except Exception:
            pass
        result = cb.call(_boom)
        self.assertEqual(result, {"safe": True})

    def test_fallback_called_with_original_args(self):
        captured = []

        def my_fallback(*args, **kwargs):
            captured.append((args, kwargs))
            return "fallback"

        cb = _make("fb2", failure_threshold=1)
        cb.set_fallback(my_fallback)
        try:
            cb.call(_boom)
        except Exception:
            pass
        cb.call(_boom, "arg1", key="val")
        self.assertTrue(len(captured) > 0)


# ── State machine correctness ────────────────────────────────────────────────

class TestStateMachine(unittest.TestCase):

    def test_full_lifecycle_closed_open_half_open_closed(self):
        cb = _make("sm1", failure_threshold=2, recovery_timeout=0.3)

        # CLOSED → OPEN
        _trip(cb, 2)
        self.assertEqual(cb.get_state(), CircuitState.OPEN)

        # OPEN → HALF_OPEN → CLOSED (success probe)
        time.sleep(0.4)
        result = cb.call(_ok)
        self.assertEqual(cb.get_state(), CircuitState.CLOSED)
        self.assertEqual(result, "ok")

    def test_event_callbacks_fire_on_open(self):
        events = []
        cb = _make("sm2", failure_threshold=1)
        cb.on_event(CircuitEvent.CIRCUIT_OPEN, lambda c, e, **kw: events.append("open"))
        _trip(cb, 1)
        self.assertIn("open", events)

    def test_get_metrics_snapshot_is_accurate(self):
        cb = _make("sm3", failure_threshold=5)
        cb.call(_ok)
        try:
            cb.call(_boom)
        except Exception:
            pass
        m = cb.get_metrics()
        self.assertEqual(m["total_calls"], 2)
        self.assertEqual(m["successful_calls"], 1)
        self.assertEqual(m["failed_calls"], 1)
        self.assertEqual(m["failure_count"], 1)


# ── Registry and factory helpers ─────────────────────────────────────────────

class TestRegistryAndFactory(unittest.TestCase):

    def test_get_circuit_returns_live_instance(self):
        cb = _make("reg1")
        found = CircuitBreaker.get_circuit("reg1")
        self.assertIs(found, cb)
        cb.close()

    def test_get_circuit_returns_none_after_close(self):
        cb = _make("reg2")
        cb.close()
        self.assertIsNone(CircuitBreaker.get_circuit("reg2"))

    def test_get_all_circuits_includes_live_only(self):
        cb = _make("reg3")
        all_c = CircuitBreaker.get_all_circuits()
        self.assertIn("reg3", all_c)
        cb.close()

    def test_create_circuit_breaker_factory(self):
        cb = create_circuit_breaker("factory1", failure_threshold=7)
        self.assertEqual(cb.failure_threshold, 7)
        cb.close()

    def test_decorator_factory(self):
        @circuit_breaker(failure_threshold=2, recovery_timeout=0.1, name="dec1")
        def my_func():
            return "decorated"

        self.assertEqual(my_func(), "decorated")


if __name__ == "__main__":
    unittest.main()
