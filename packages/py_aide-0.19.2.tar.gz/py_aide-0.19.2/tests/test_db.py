import pytest
import os
import shutil
from src.py_aide import database
from src.py_aide.response import Response

@pytest.fixture
def db_path(tmp_path):
    """Fixture to provide a clean test database file path."""
    db_file = tmp_path / "test_suite.db"
    return str(db_file)

@pytest.fixture
def test_tables():
    """Fixture defining the test database tables."""
    return {
        'courses': '''
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER,
            syllabus json,
            settings json
        ''',
        'assignments': '''
            id INTEGER PRIMARY KEY,
            course_id INTEGER,
            requirements json,
            submissions json
        '''
    }

@pytest.fixture
def db_instance(db_path, test_tables):
    """Fixture to provide an initialized Database Api instance."""
    # Ensure any background cleanups from previous runs are finished
    database.Api.cleanup_all()
    
    with database.Api(db_path=db_path, tables=test_tables, readonly=False) as db:
        yield db
    
    # Final cleanup
    database.Api.cleanup_all()

def test_db_initialization(db_instance, db_path):
    """Test standard database initialization and table creation."""
    assert os.path.exists(db_path)
    # Check if a simple meta query works
    result = db_instance.execute(query="SELECT name FROM sqlite_master WHERE type='table';")
    assert result.status is True
    table_names = [r["name"] for r in result.data]
    assert "courses" in table_names
    assert "assignments" in table_names

def test_insert_and_fetch(db_instance):
    """Test data insertion and complex JSON field fetching."""
    # Act: Insertion
    courses_data = [
        (1, 'Python Mastery', 101, 
         {"modules": [{"title": "Basics", "duration": 10}]}, 
         {"is_public": True})
    ]
    resp_insert = db_instance.insert(table="courses", data=courses_data)
    assert resp_insert.status is True

    # Act: Fetching with JSON path access
    # settings::is_public access
    resp_fetch = db_instance.fetch(
        table="courses", 
        columns=["title", "settings::is_public as public"]
    )
    
    # Assert
    assert resp_fetch.status is True
    assert resp_fetch.data[0]["title"] == "Python Mastery"
    # Verification of JSON expansion
    # SQLite ->> returns 1/0 for json booleans
    assert resp_fetch.data[0]["public"] == 1

def test_update_json_field(db_instance):
    """Test updating a specific field within a JSON object."""
    # Setup
    db_instance.insert(table="assignments", data=[
        (1, 10, {"allowed_formats": ["pdf"]}, {"count": 5})
    ])
    
    # Act: Update specific JSON list element (using framework's [+] syntax)
    # requirements::allowed_formats[+] should add to the list
    resp_update = db_instance.update(
        table="assignments", 
        columns=["requirements::allowed_formats[+]"],
        column_data=["docx"], 
        condition="id=?", 
        condition_data=[1]
    )
    assert resp_update.status is True

    # Assert
    resp_final = db_instance.fetch(table="assignments", columns=["requirements"], condition="id=1")
    formats = resp_final.data[0]["requirements"]
    
    # If using string-based fetch from DB, parse it.
    import json
    if isinstance(formats, str):
        formats = json.loads(formats)

    assert "pdf" in formats["allowed_formats"]
    assert "docx" in formats["allowed_formats"]

def test_transaction_rollback(db_instance):
    """Test manual transaction control and rollback on failure."""
    # This specifically targets the 'transactionMode=True' and 'commit_transaction' features
    # Cleanup previous instances for this path to avoid interference
    # Actually, fixtures already handle it, but for clarity:
    database.Api.cleanup_all()
    
    # Manually use transaction mode
    with database.Api(db_path=db_instance.db_path, transactionMode=True) as db:
        db.insert(table="courses", data=[(2, 'Failed Course', 99, {}, {})])
        
        # Simulate a partial failure (e.g., missing mandatory argument)
        # Note: Enforcer would likely catch this before db, so we use a DB-level error
        db.execute(query="INVALID SQL COMMAND")
        
        # Verify transaction fails commit if errors occurred
        resp_commit = db.commit_transaction()
        assert resp_commit.status is False
        assert "Transaction Rollback" in resp_commit.log

    # Verify no data was actually committed
    with database.Api(db_path=db_instance.db_path) as db:
        resp_check = db.fetch(table="courses", columns=["title"], condition="id=2")
        assert len(resp_check.data) == 0
