import unittest
import time
from py_aide.threading import ThreadPoolExecutor

class TestExecutorHook(unittest.TestCase):
    def test_global_error_hook(self):
        errors = []

        def on_error(func_name, payload, err, tb):
            errors.append({
                "func": func_name,
                "payload": payload,
                "error": err,
                "traceback": tb
            })

        def failing_task(x):
            return 1 / x

        with ThreadPoolExecutor(on_error=on_error) as executor:
            # This should succeed
            executor.submit(func=failing_task, args=[1])
            
            # This should fail (ZeroDivisionError)
            executor.submit(func=failing_task, args=[0])
            
            # Wait for tasks to finish
            time.sleep(1)

        self.assertEqual(len(errors), 1)
        err = errors[0]
        self.assertEqual(err["func"], "failing_task")
        self.assertEqual(err["error"], "division by zero")
        self.assertIsNotNone(err["traceback"])
        self.assertIn("ZeroDivisionError", err["traceback"])

if __name__ == "__main__":
    unittest.main()
