# test_redis_cache.py
import pytest
import sys
import json
from unittest.mock import MagicMock, patch
from py_aide.cache.core import Cache
from py_aide.enums import CacheEngine

@pytest.fixture(autouse=True)
def mock_redis():
    mock_module = MagicMock()
    class MockWatchError(Exception):
        pass
    mock_module.WatchError = MockWatchError
    with patch.dict(sys.modules, {"redis": mock_module}):
        yield mock_module

@pytest.fixture(autouse=True)
def reset_cache_multiton():
    """Reset the Cache multiton before each test."""
    Cache._instances = {}

def test_redis_cache_initialization():
    """Test that Cache can initialize the Redis engine."""
    cache = Cache(engine=CacheEngine.REDIS, host="localhost")
    assert cache.driver.__class__.__name__ == "RedisCache"

def test_redis_cache_write_mocked(mock_redis):
    """Test writing to Redis cache (mocked)."""
    mock_client = MagicMock()
    mock_redis.Redis.return_value = mock_client
    
    cache = Cache(engine=CacheEngine.REDIS)
    res = cache.write(
        shelf_path="test",
        scope="user",
        category="profile",
        data={"name": "John"}
    )
    
    assert res.status is True
    assert mock_client.hset.called
    
    # Check what was sent to hset
    args, _ = mock_client.hset.call_args
    assert args[0] == "pa:c:user"
    assert args[1] == "profile"
    assert json.loads(args[2]) == {"name": "John"}

def test_redis_cache_read_mocked(mock_redis):
    """Test reading from Redis cache (mocked)."""
    mock_client = MagicMock()
    mock_redis.Redis.return_value = mock_client
    
    # Mock hget returning JSON
    mock_client.hget.return_value = json.dumps({"name": "John"})
    
    cache = Cache(engine=CacheEngine.REDIS)
    res = cache.read(
        shelf_path="test",
        scope="user",
        category="profile"
    )
    
    assert res.status is True
    assert res.data == {"name": "John"}

def test_redis_cache_patch_mocked(mock_redis):
    """Test patching Redis cache (mocked)."""
    mock_client = MagicMock()
    mock_redis.Redis.return_value = mock_client
    
    # Mock the pipeline for WATCH/MULTI
    mock_pipe = MagicMock()
    # Handle the context manager __enter__
    mock_client.pipeline.return_value.__enter__.return_value = mock_pipe
    
    # Mock hmget returning current state
    mock_pipe.hmget.return_value = [json.dumps({"count": 10})]
    
    cache = Cache(engine=CacheEngine.REDIS)
    res = cache.patch(
        shelf_path="test",
        scope="stats",
        category="clicks",
        direct_mutations=[{"path": "count[+=]", "value": 1}]
    )
    
    assert res.status is True
    assert mock_pipe.watch.called
    assert mock_pipe.multi.called
    assert mock_pipe.hset.called
    assert mock_pipe.execute.called
    
    # Check that hset was called with updated data (10 + 1 = 11)
    args, _ = mock_pipe.hset.call_args
    assert json.loads(args[2]) == {"count": 11}
