import pytest
from src.py_aide.enforcer import enforce_requirements

@enforce_requirements
def add(a: int, b: int, /) -> float:
    """Docstring for add."""
    return float(a + b)

def test_add_success():
    """Test successful integer addition."""
    assert add(10, 5) == 15.0

def test_add_type_error_on_input():
    """Test that wrong input types raise TypeError."""
    with pytest.raises(TypeError):
        add("10", 5)

def test_add_positional_only_error():
    """Test positional-only enforcement."""
    with pytest.raises(TypeError) as excinfo:
        add(10, b=5)
    assert "POSITIONAL-ONLY" in str(excinfo.value)

@enforce_requirements
def greet(*, name: str) -> str:
    """Test keyword-only enforcement."""
    return f"Hello, {name}"

def test_greet_keyword_only_success():
    """Test successful keyword-only call."""
    assert greet(name="Alice") == "Hello, Alice"

def test_greet_positional_call_failure():
    """Test that passing keyword-only argument positionally fails."""
    with pytest.raises(TypeError) as excinfo:
        greet("Alice")
    assert "KEYWORD-ONLY" in str(excinfo.value)
