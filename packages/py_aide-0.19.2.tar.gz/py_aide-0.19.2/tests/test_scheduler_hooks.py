import unittest
import time
from py_aide.threading import run_once, run_every

class TestSchedulerHooks(unittest.TestCase):
    def test_run_once_hook(self):
        errors = []

        def on_error(name, type, err, tb):
            errors.append({"name": name, "type": type, "error": err, "tb": tb})

        def failing_task():
            raise ValueError("Scheduler Fail")

        run_once(func=failing_task, on_error=on_error)
        
        time.sleep(1)
        
        self.assertEqual(len(errors), 1)
        self.assertEqual(errors[0]["name"], "failing_task")
        self.assertEqual(errors[0]["type"], "run_once")
        self.assertEqual(errors[0]["error"], "Scheduler Fail")
        self.assertIsNotNone(errors[0]["tb"])

    def test_run_every_hook(self):
        errors = []

        def on_error(name, type, err, tb):
            errors.append({"name": name, "type": type, "error": err, "tb": tb})

        def failing_task():
            raise RuntimeError("Repeat Fail")

        stop_event = run_every(interval_seconds=0.5, func=failing_task, on_error=on_error)
        
        time.sleep(1.2) # Should trigger at least twice
        stop_event.set()
        
        self.assertTrue(len(errors) >= 2)
        self.assertEqual(errors[0]["error"], "Repeat Fail")
        self.assertIsNotNone(errors[0]["tb"])

if __name__ == "__main__":
    unittest.main()
