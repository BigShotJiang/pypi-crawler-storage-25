import unittest
import os
import time
import shutil
from py_aide.threading import DatabaseBuffer
from py_aide.database import Api

class TestDatabaseBuffer(unittest.TestCase):
    MAIN_DB = "test_storage/main_app.db"
    QUEUE_DB = "test_storage/buffer_queue.db"

    def setUp(self):
        # Ensure clean state
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")
        os.makedirs("test_storage")
        
        # Initialize main DB schema
        with Api(db_path=self.MAIN_DB, tables={"users": "id INTEGER PRIMARY KEY, name TEXT"}) as db:
            pass
            
        self.buffer = DatabaseBuffer(main_db=self.MAIN_DB, queue_db=self.QUEUE_DB)
        self.buffer.start()

    def tearDown(self):
        self.buffer.stop()
        if os.path.exists("test_storage"):
            shutil.rmtree("test_storage")

    def test_buffer_insert(self):
        # 1. Queue an insert
        res = self.buffer.insert(table="users", data=[[1, "Alice"]])
        self.assertTrue(res.status)
        
        # 2. Wait for worker to process
        # We give it some time to pop and execute
        time.sleep(2)
        
        # 3. Check if data is in main DB
        with Api(db_path=self.MAIN_DB) as db:
            fetch_res = db.fetch(table="users", columns=["name"], condition="id=?", condition_data=[1])
            self.assertEqual(fetch_res.data[0]["name"], "Alice")

    def test_buffer_multiple_ops(self):
        # Queue many ops
        for i in range(2, 12):
            self.buffer.insert(table="users", data=[[i, f"User_{i}"]])
        
        # Wait for all to finish
        time.sleep(4)
        
        with Api(db_path=self.MAIN_DB) as db:
            res = db.execute(query="SELECT COUNT(*) as count FROM users")
            self.assertEqual(res.data[0]["count"], 10) 

    def test_buffer_update_delete(self):
        # Setup data
        with Api(db_path=self.MAIN_DB, readonly=False) as db:
            res = db.insert(table="users", data=[[20, "Bob"]])
            self.assertTrue(res.status, f"Insert failed: {res.log}")
        
        # Verify it exists first
        with Api(db_path=self.MAIN_DB) as db:
            res = db.fetch(table="users", columns=["name"], condition="id=?", condition_data=[20])
            self.assertEqual(len(res.data), 1, "Record should exist before update")

        # 1. Update
        self.buffer.update(
            table="users", 
            columns=["name"], 
            column_data=["Robert"], 
            condition="id=?", 
            condition_data=[20]
        )
        
        time.sleep(3)
        
        with Api(db_path=self.MAIN_DB) as db:
            res = db.fetch(table="users", columns=["name"], condition="id=?", condition_data=[20])
            self.assertEqual(res.data[0]["name"], "Robert")
            
        # 2. Delete
        self.buffer.delete(table="users", condition="id=?", condition_data=[20])
        
        time.sleep(3)
        
        with Api(db_path=self.MAIN_DB) as db:
            res = db.fetch(table="users", columns=["name"], condition="id=?", condition_data=[20])
            self.assertEqual(len(res.data), 0)

if __name__ == "__main__":
    unittest.main()
