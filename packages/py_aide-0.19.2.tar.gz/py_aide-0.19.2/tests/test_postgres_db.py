import pytest
import sys
from unittest.mock import MagicMock, patch
from py_aide.database import Api
from py_aide.enums import DbEngine

# Create a mock psycopg2 module
mock_psycopg2 = MagicMock()
sys.modules["psycopg2"] = mock_psycopg2
sys.modules["psycopg2.extras"] = MagicMock()

@pytest.fixture(autouse=True)
def reset_db_multiton():
    """Reset the Api multiton before each test."""
    Api._thread_registries = {}

def test_postgres_initialization():
    """Test that Api can initialize the Postgres engine."""
    db = Api(engine=DbEngine.POSTGRES, host="localhost", database="test_db")
    assert db.driver.__class__.__name__ == "PostgresDriver"

def test_postgres_insert_mocked():
    """Test inserting into Postgres (mocked)."""
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_psycopg2.connect.return_value = mock_conn
    mock_conn.cursor.return_value = mock_cursor
    
    db = Api(engine=DbEngine.POSTGRES)
    with db:
        db.insert(table="users", data=[{"name": "John", "age": 30}])
    
    assert mock_cursor.executemany.called
    args, _ = mock_cursor.executemany.call_args
    # Check that it used %s placeholders for Postgres
    assert "%s" in args[0]
    assert "John" in args[1][0]

def test_postgres_fetch_mocked():
    """Test fetching from Postgres (mocked)."""
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_psycopg2.connect.return_value = mock_conn
    mock_conn.cursor.return_value = mock_cursor
    
    # Mock result
    mock_cursor.fetchall.return_value = [{"id": 1, "name": "John"}]
    
    db = Api(engine=DbEngine.POSTGRES)
    with db:
        res = db.fetch(table="users", columns=["id", "name"])
    
    assert res.status is True
    assert res.data[0]["name"] == "John"
    
    # Verify query translation (SQLite ? to Postgres %s)
    args, _ = mock_cursor.execute.call_args
    assert "%s" in args[0]
    assert "?" not in args[0]

def test_postgres_json_dsl_reads():
    """Test Postgres JSON parser reads (::)"""
    from py_aide.postgres import PostgresJSONParser
    
    # 1. Standard Column
    sql = PostgresJSONParser.parse_read_column(column_string="users")
    assert sql == "users"
    
    # 2. JSON Path
    sql = PostgresJSONParser.parse_read_column(column_string="users::settings[theme]")
    assert sql == "users #>> '{settings,theme}'"
    
    # 3. JSON Path with alias
    sql = PostgresJSONParser.parse_read_column(column_string="users::stats[clicks] AS count")
    assert sql == "users #>> '{stats,clicks}' AS count"

def test_postgres_json_dsl_writes():
    """Test Postgres JSON parser writes (+=, |=, +)"""
    from py_aide.postgres import PostgresJSONParser
    
    # 1. Update list
    cols, vals = PostgresJSONParser.parse_write_columns(
        columns=["users::tags[+]"], 
        values=[["new_tag"]]
    )
    assert 'jsonb_set(users, \'{tags}\', COALESCE(users #> \'{tags}\', \'[]\'::jsonb) || %s::jsonb)' in cols[0]
    import json
    assert vals[0] == json.dumps(["new_tag"])
    
    # 2. Math
    cols, vals = PostgresJSONParser.parse_write_columns(
        columns=["users::clicks[+=]"], 
        values=[1]
    )
    assert 'jsonb_set(users, \'{clicks}\', (COALESCE((users #>> \'{clicks}\')::numeric, 0) + %s::numeric)::text::jsonb)' in cols[0]
    assert vals[0] == 1
    
    # 3. Object Merge
    cols, vals = PostgresJSONParser.parse_write_columns(
        columns=["users::meta[|=]"], 
        values=[{"last_login": "today"}]
    )
    assert 'jsonb_set(users, \'{meta}\', COALESCE(users #> \'{meta}\', \'{}\'::jsonb) || %s::jsonb)' in cols[0]
    assert vals[0] == json.dumps({"last_login": "today"})

def test_postgres_json_dsl_condition():
    """Test Postgres JSON parser WHERE conditions"""
    from py_aide.postgres import PostgresJSONParser
    
    sql = "SELECT * FROM users WHERE users::role = %s AND users::settings[theme] = %s"
    parsed = PostgresJSONParser.parse_condition(sql)
    assert "users #>> '{role}' = %s" in parsed
    assert "users #>> '{settings,theme}' = %s" in parsed

