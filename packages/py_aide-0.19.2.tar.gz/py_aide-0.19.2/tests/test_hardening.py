import unittest
import os
import time
import shutil
import threading
from py_aide.threading import PersistentQueue, TaskBuffer
from py_aide.response import ok, error

class TestHardening(unittest.TestCase):
    STORAGE = "test_storage_hardening"
    QUEUE_DB = f"{STORAGE}/queue.db"

    def setUp(self):
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)
        os.makedirs(self.STORAGE)

    def tearDown(self):
        if os.path.exists(self.STORAGE):
            shutil.rmtree(self.STORAGE)

    def test_exponential_backoff(self):
        queue = PersistentQueue(queue_name="backoff", db_path=self.QUEUE_DB)
        res = queue.push(payload={"test": "data"})
        task_id = res.data["task_id"]

        # Pop it once
        pop_res = queue.pop()
        self.assertTrue(pop_res.status)
        
        # Fail it (Attempt 0 -> next try in 1s)
        queue.fail(task_id=task_id, err="fail 1", retry=True)
        
        # Immediate pop should fail
        pop_fail = queue.pop()
        self.assertFalse(pop_fail.status)
        self.assertEqual(pop_fail.log, "Queue is empty")
        
        # Wait 1.1s
        time.sleep(1.1)
        
        # Now it should be poppable
        pop_success = queue.pop()
        self.assertTrue(pop_success.status)
        self.assertEqual(pop_success.data[0]["id"], task_id)

    def test_multi_worker_concurrency(self):
        processed_tasks = []
        lock = threading.Lock()

        def slow_handler(data):
            time.sleep(0.1)
            with lock:
                processed_tasks.append(data)
            return ok()

        # Start buffer with 5 workers
        buffer = TaskBuffer(
            handlers={"JOB": slow_handler},
            queue_db=self.QUEUE_DB,
            workers=5
        )
        buffer.start()

        # Push 10 jobs
        for i in range(10):
            buffer.push(task_type="JOB", data=i)

        # 10 jobs * 0.1s / 5 workers = 0.2s total expected time
        # We wait 2s to be absolutely sure even with SQLite overhead
        time.sleep(2.0) 
        
        buffer.stop()
        
        self.assertEqual(len(processed_tasks), 10)

    def test_cleanup_logic(self):
        queue = PersistentQueue(queue_name="cleanup", db_path=self.QUEUE_DB)
        
        # Push and fail a task permanently
        res = queue.push(payload={"old": "data"})
        task_id = res.data["task_id"]
        queue.pop()
        queue.fail(task_id=task_id, err="permanent", retry=False)
        
        # Cleanup with a high age - should NOT delete
        queue.cleanup(max_age_days=10)
        from py_aide.database import Api
        with Api(db_path=self.QUEUE_DB) as db:
            count = db.execute(query="SELECT COUNT(*) as count FROM py_aide_queues").data[0]["count"]
            self.assertEqual(count, 1)

        # Cleanup with negative age - should delete everything failed
        # (Since now - (-1 * 86400) is in the future)
        queue.cleanup(max_age_days=-1)
        with Api(db_path=self.QUEUE_DB) as db:
            count = db.execute(query="SELECT COUNT(*) as count FROM py_aide_queues").data[0]["count"]
            self.assertEqual(count, 0)

if __name__ == "__main__":
    unittest.main()
