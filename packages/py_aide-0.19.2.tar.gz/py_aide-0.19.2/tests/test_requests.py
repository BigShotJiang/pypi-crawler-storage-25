import unittest
from unittest.mock import patch, MagicMock
import httpx
import asyncio
from py_aide.requests import send_request, send_request_async, RequestConfig, Interceptors
from py_aide.response import Response

class TestRequests(unittest.TestCase):
    def setUp(self):
        RequestConfig.base_url = "https://api.example.com"
        Interceptors.request_hooks = []
        Interceptors.response_hooks = []

    @patch("httpx.Client.request")
    def test_send_request_success(self, mock_request):
        # Setup mock response
        mock_res = MagicMock()
        mock_res.status_code = 200
        mock_res.is_success = True
        mock_res.method = "GET"
        mock_res.json.return_value = {"id": 1, "name": "Test"}
        mock_request.return_value = mock_res

        response = send_request(method="GET", endpoint="/test")

        self.assertTrue(response.status)
        self.assertEqual(response.data["name"], "Test")
        mock_request.assert_called_once()

    @patch("httpx.Client.request")
    def test_send_request_failure(self, mock_request):
        # Setup mock error response
        mock_res = MagicMock()
        mock_res.status_code = 500
        mock_res.is_success = False
        mock_res.method = "POST"
        mock_res.text = "Internal Server Error"
        mock_request.return_value = mock_res

        # Set retries to 0 for quick test
        RequestConfig.max_retries = 0
        response = send_request(method="POST", endpoint="/fail")

        self.assertFalse(response.status)
        self.assertIn("500", response.log)
        self.assertEqual(response.errorLogs["http_code"], 500)

    @patch("httpx.Client.request")
    def test_retry_logic(self, mock_request):
        # Setup mock to fail twice then succeed
        fail_res = MagicMock(status_code=500, is_success=False, method="GET")
        success_res = MagicMock(status_code=200, is_success=True, method="GET")
        success_res.json.return_value = {"ok": True}
        
        mock_request.side_effect = [fail_res, fail_res, success_res]

        RequestConfig.max_retries = 2
        RequestConfig.retry_strategy = "fixed" # 1s delay

        with patch("time.sleep"): # Don't actually sleep
            response = send_request(method="GET", endpoint="/retry")

        self.assertTrue(response.status)
        self.assertEqual(mock_request.call_count, 3)

    def test_interceptors(self):
        # Request Interceptor
        def add_token(data):
            data["headers"]["X-Test"] = "Intercepted"
            return data
        
        Interceptors.add_request_hook(add_token)

        with patch("httpx.Client.request") as mock_request:
            mock_res = MagicMock(status_code=200, is_success=True, method="GET")
            mock_res.json.return_value = {}
            mock_request.return_value = mock_res
            
            send_request(method="GET", endpoint="/test", auth_token="test", auth_type="bearer")
            
            args, kwargs = mock_request.call_args
            self.assertEqual(kwargs["headers"]["X-Test"], "Intercepted")

    @patch("httpx.AsyncClient.request")
    def test_send_request_async(self, mock_request):
        # Setup mock response
        mock_res = MagicMock()
        mock_res.status_code = 200
        mock_res.is_success = True
        mock_res.method = "GET"
        mock_res.json.return_value = {"async": True}
        
        # httpx.AsyncClient returns a coroutine
        async def mock_coro(*args, **kwargs):
            return mock_res
        mock_request.side_effect = mock_coro

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            response = loop.run_until_complete(send_request_async(method="GET", endpoint="/async"))
            self.assertTrue(response.status)
            self.assertEqual(response.data["async"], True)
        finally:
            loop.close()

if __name__ == "__main__":
    unittest.main()
