import pytest
import sys
import json
from unittest.mock import MagicMock, patch
from py_aide.threading.queues import PersistentQueue
from py_aide.enums import QueueEngine

@pytest.fixture(autouse=True)
def mock_redis():
    mock_module = MagicMock()
    with patch.dict(sys.modules, {"redis": mock_module}):
        yield mock_module

def test_redis_queue_initialization():
    """Test that PersistentQueue can initialize the Redis engine."""
    queue = PersistentQueue(queue_name="test_redis", engine=QueueEngine.REDIS, host="localhost")
    assert queue.driver.__class__.__name__ == "RedisQueue"

def test_redis_queue_push_mocked(mock_redis):
    """Test pushing a task to Redis (mocked)."""
    mock_client = MagicMock()
    mock_redis.Redis.return_value = mock_client
    
    queue = PersistentQueue(queue_name="test_redis", engine=QueueEngine.REDIS)
    res = queue.push(payload={"action": "test"})
    
    assert res.status is True
    assert "task_id" in res.data
    
    # Verify Redis calls
    assert mock_client.pipeline.called
    pipeline = mock_client.pipeline.return_value
    assert pipeline.hset.called
    assert pipeline.zadd.called
    assert pipeline.execute.called

def test_redis_queue_pop_mocked(mock_redis):
    """Test popping a task from Redis (mocked)."""
    mock_client = MagicMock()
    mock_redis.Redis.return_value = mock_client
    
    # Mock hgetall for recovery logic to return empty
    mock_client.hgetall.return_value = {}
    
    # Mock zpopmin returning a task ID
    mock_client.zpopmin.return_value = [("task-123", -10)]
    # Mock hget returning task JSON
    task_data = {"id": "task-123", "payload": "hello", "priority": 10}
    mock_client.hget.return_value = json.dumps(task_data)
    
    queue = PersistentQueue(queue_name="test_redis", engine=QueueEngine.REDIS)
    res = queue.pop()
    
    assert res.status is True
    assert res.data[0]["id"] == "task-123"
    assert res.data[0]["payload"] == "hello"

def test_redis_queue_missing_library():
    """Test error handling when redis library is missing."""
    from py_aide.threading._redis_queue import RedisQueue
    queue = RedisQueue(queue_name="test")
    # Manually set redis_lib to None to simulate missing library
    queue.redis_lib = None
    
    res = queue.push(payload={})
    assert res.status is False
    assert "redis" in res.log.lower()
    assert "required" in res.log.lower()
