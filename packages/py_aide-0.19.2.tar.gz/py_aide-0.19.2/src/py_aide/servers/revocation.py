import sqlite3
import threading
import time
import hashlib
import logging
from typing import Optional
from .memory_storage import MemoryStorage

logger = logging.getLogger(__name__)

class RevocationStore:
    """
    Hybrid storage for revoked tokens.
    Uses MemoryStorage for O(1) lookups and SQLite for persistence.
    """
    
    def __init__(self, db_path: str, cleanup_interval: int = 3600):
        self.db_path = db_path
        self._memory = MemoryStorage(enable_background_cleanup=True)
        self._lock = threading.Lock()
        
        # Ensure DB and table exist
        self._init_db()
        
        # Load existing non-expired tokens into memory
        self._load_from_db()
        
        # Start background DB cleanup
        self._stop_event = threading.Event()
        self._janitor_thread = threading.Thread(
            target=self._db_janitor,
            args=(cleanup_interval,),
            daemon=True,
            name="Revocation-DB-Janitor"
        )
        self._janitor_thread.start()

    def _init_db(self):
        """Initialize the SQLite database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS revoked_tokens (
                    token_hash TEXT PRIMARY KEY,
                    expires_at REAL NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_expiry ON revoked_tokens(expires_at)")
            conn.commit()

    def _load_from_db(self):
        """Load all non-expired tokens from SQLite into MemoryStorage on startup."""
        now = time.time()
        count = 0
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT token_hash, expires_at FROM revoked_tokens WHERE expires_at > ?", 
                (now,)
            )
            for token_hash, expires_at in cursor:
                ttl = int(expires_at - now)
                self._memory.set(token_hash, True, ttl=ttl)
                count += 1
        
        if count > 0:
            logger.info("Recovered %d revoked tokens from persistence.", count)

    def is_revoked(self, token: str) -> bool:
        """Check if a token has been revoked."""
        token_hash = self._hash_token(token)
        return self._memory.get(token_hash) is not None

    def revoke(self, token: str, expires_at: float):
        """
        Revoke a token.
        Stores in memory for immediate lookup and SQLite for persistence.
        """
        token_hash = self._hash_token(token)
        now = time.time()
        ttl = int(expires_at - now)
        
        if ttl <= 0:
            return # Already expired, no need to revoke
            
        # 1. Update Memory
        self._memory.set(token_hash, True, ttl=ttl)
        
        # 2. Update SQLite
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO revoked_tokens (token_hash, expires_at) VALUES (?, ?)",
                    (token_hash, expires_at)
                )
                conn.commit()
        except Exception as e:
            logger.error("Failed to persist token revocation: %s", e)

    def _hash_token(self, token: str) -> str:
        """Create a stable hash of the token for storage."""
        return hashlib.sha256(token.encode()).hexdigest()

    def _db_janitor(self, interval: int):
        """Periodically remove expired tokens from the SQLite database."""
        while not self._stop_event.is_set():
            self._stop_event.wait(interval)
            if self._stop_event.is_set():
                break
                
            now = time.time()
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.execute("DELETE FROM revoked_tokens WHERE expires_at < ?", (now,))
                    if cursor.rowcount > 0:
                        logger.debug("Purged %d expired tokens from revocation database.", cursor.rowcount)
                    conn.commit()
            except Exception as e:
                logger.error("Revocation DB Janitor failed: %s", e)

    def start(self):
        self._memory.start()

    def stop(self):
        self._stop_event.set()
        self._memory.stop()
