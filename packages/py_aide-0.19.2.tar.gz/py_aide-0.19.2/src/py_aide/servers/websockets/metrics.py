"""
WebSocket Metrics Module - Comprehensive Observability and Monitoring with Runtime Updates

This module provides complete visibility into WebSocket operations:
1. Real-time connection statistics
2. Message throughput and latency tracking
3. Error rates and types
4. Per-endpoint performance metrics
5. Resource usage monitoring
6. Health checks and alerts
7. Historical data aggregation
8. Integration with monitoring systems (Prometheus, Grafana, etc.)
9. Runtime updates to metrics collection and alerting

The metrics system is designed to be:
- Low overhead (minimal performance impact)
- Real-time (sub-second visibility)
- Comprehensive (track everything that matters)
- Actionable (alerts on anomalies)
- Queryable (filter by time, endpoint, user)
- Dynamically configurable at runtime
"""

import time
import threading
from functools import wraps
import statistics
import logging
from collections import defaultdict, deque
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

# Import from WebSocket modules
from .engine import WebSocketEngine, ConnectionInfo
from .security import WebSocketSecurityManager
from .limits import WebSocketLimitsManager
from .protocol import WebSocketProtocolManager


# ============================================================================
# ENUMS
# ============================================================================

class MetricType(str, Enum):
    """Types of metrics we track."""
    COUNTER = "counter"      # Cumulative count (total messages)
    GAUGE = "gauge"          # Current value (active connections)
    HISTOGRAM = "histogram"  # Distribution (latency)
    RATE = "rate"            # Per-second rate (messages/sec)
    DURATION = "duration"    # Time measurements (response time)


class MetricLevel(str, Enum):
    """Importance level for metrics."""
    DEBUG = "debug"          # Detailed internal metrics
    INFO = "info"            # Normal operational metrics
    WARNING = "warning"      # Potential issues
    CRITICAL = "critical"    # Serious problems requiring attention


class AlertSeverity(str, Enum):
    """Severity levels for alerts."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class TimeWindow(str, Enum):
    """Time windows for aggregation."""
    REALTIME = "realtime"    # Now
    MINUTE = "1m"            # Last minute
    FIVE_MINUTE = "5m"       # Last 5 minutes
    HOUR = "1h"              # Last hour
    DAY = "24h"              # Last 24 hours
    WEEK = "7d"              # Last 7 days


# ============================================================================
# METRICS CONFIGURATION
# ============================================================================

@dataclass
class MetricsConfig:
    """
    Metrics configuration for WebSocket observability.
    
    All metrics-specific settings are defined here with validation methods
    to support runtime updates through the WebSocketConfigManager.
    
    Each setting can have:
    - A validate_<setting> method for runtime updates
    - An on_<setting>_updated hook to react to changes
    """
    
    # ========================================================================
    # COLLECTION SETTINGS
    # ========================================================================
    
    enabled: bool = True
    """Whether metrics collection is enabled globally."""
    
    collection_interval: int = 60
    """Seconds between metric aggregations."""
    
    max_points_per_metric: int = 10000
    """Maximum historical points to keep per metric."""
    
    # ========================================================================
    # DASHBOARD SETTINGS
    # ========================================================================
    
    enable_dashboard: bool = True
    """Whether to serve the real-time dashboard."""
    
    dashboard_refresh_interval: int = 5
    """Seconds between dashboard auto-refresh."""
    
    dashboard_history_points: int = 60
    """Number of historical points to show in dashboard."""
    
    # ========================================================================
    # PROMETHEUS SETTINGS
    # ========================================================================
    
    enable_prometheus: bool = True
    """Whether to expose Prometheus metrics endpoint."""
    
    prometheus_namespace: str = "websocket"
    """Namespace prefix for Prometheus metrics."""
    
    # ========================================================================
    # HEALTH CHECK SETTINGS
    # ========================================================================
    
    health_check_interval: int = 30
    """Seconds between health checks."""
    
    health_check_timeout: float = 5.0
    """Maximum time for health check to complete."""
    
    # ========================================================================
    # ALERT SETTINGS
    # ========================================================================
    
    alert_check_interval: int = 30
    """Seconds between alert rule evaluations."""
    
    max_alerts_history: int = 1000
    """Maximum number of alerts to keep in history."""
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_enabled(self, value: bool) -> None:
        """Validate enabled flag before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enabled must be boolean, got {type(value)}")
    
    def validate_collection_interval(self, value: int) -> None:
        """Validate collection_interval before runtime update."""
        if value < 10:
            raise ValueError(f"collection_interval too short: {value}s (minimum 10)")
        if value > 3600:
            logging.warning(f"Very long collection_interval: {value}s")
    
    def validate_max_points_per_metric(self, value: int) -> None:
        """Validate max_points_per_metric before runtime update."""
        if value < 100:
            raise ValueError(f"max_points_per_metric too low: {value} (minimum 100)")
        if value > 1000000:
            logging.warning(f"Very large max_points_per_metric: {value}")
    
    def validate_enable_dashboard(self, value: bool) -> None:
        """Validate enable_dashboard before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enable_dashboard must be boolean, got {type(value)}")
    
    def validate_dashboard_refresh_interval(self, value: int) -> None:
        """Validate dashboard_refresh_interval before runtime update."""
        if value < 1:
            raise ValueError(f"dashboard_refresh_interval too short: {value}s (minimum 1)")
        if value > 60:
            logging.warning(f"Very long dashboard_refresh_interval: {value}s")
    
    def validate_enable_prometheus(self, value: bool) -> None:
        """Validate enable_prometheus before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enable_prometheus must be boolean, got {type(value)}")
    
    def validate_prometheus_namespace(self, value: str) -> None:
        """Validate prometheus_namespace before runtime update."""
        if not value or not value.strip():
            raise ValueError("prometheus_namespace cannot be empty")
        if not value.replace('_', '').isalnum():
            raise ValueError("prometheus_namespace must contain only letters, numbers, and underscores")
    
    def validate_alert_check_interval(self, value: int) -> None:
        """Validate alert_check_interval before runtime update."""
        if value < 10:
            raise ValueError(f"alert_check_interval too short: {value}s (minimum 10)")
        if value > 300:
            logging.warning(f"Very long alert_check_interval: {value}s")
    
    def validate_max_alerts_history(self, value: int) -> None:
        """Validate max_alerts_history before runtime update."""
        if value < 10:
            raise ValueError(f"max_alerts_history too low: {value} (minimum 10)")
        if value > 10000:
            logging.warning(f"Very large max_alerts_history: {value}")
    
    # ========================================================================
    # UPDATE HOOKS (called after successful runtime updates)
    # ========================================================================
    
    def on_enabled_updated(self, value: bool) -> None:
        """Hook called after enabled flag is updated."""
        logging.info(f"Metrics: collection {'enabled' if value else 'disabled'} at runtime")
    
    def on_collection_interval_updated(self, value: int) -> None:
        """Hook called after collection_interval is updated."""
        logging.info(f"Metrics: collection interval updated to {value}s")
    
    def on_enable_dashboard_updated(self, value: bool) -> None:
        """Hook called after dashboard setting is updated."""
        logging.info(f"Metrics: dashboard {'enabled' if value else 'disabled'} at runtime")
    
    def on_enable_prometheus_updated(self, value: bool) -> None:
        """Hook called after Prometheus setting is updated."""
        logging.info(f"Metrics: Prometheus endpoint {'enabled' if value else 'disabled'} at runtime")
    
    # ========================================================================
    # INITIAL VALIDATION (called at startup)
    # ========================================================================
    
    def __post_init__(self):
        """Validate configuration at startup."""
        self._validate_intervals()
    
    def _validate_intervals(self):
        """Validate interval relationships."""
        if self.alert_check_interval < self.collection_interval:
            logging.warning(
                f"alert_check_interval ({self.alert_check_interval}s) is less than "
                f"collection_interval ({self.collection_interval}s). Alerts may use stale data."
            )
    
    # ========================================================================
    # HELPER METHODS
    # ========================================================================
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'enabled': self.enabled,
            'collection_interval': self.collection_interval,
            'max_points_per_metric': self.max_points_per_metric,
            'enable_dashboard': self.enable_dashboard,
            'dashboard_refresh_interval': self.dashboard_refresh_interval,
            'dashboard_history_points': self.dashboard_history_points,
            'enable_prometheus': self.enable_prometheus,
            'prometheus_namespace': self.prometheus_namespace,
            'health_check_interval': self.health_check_interval,
            'alert_check_interval': self.alert_check_interval,
            'max_alerts_history': self.max_alerts_history
        }


# ============================================================================
# DATA CLASSES (Unchanged)
# ============================================================================

@dataclass
class MetricPoint:
    """A single data point in a metric series."""
    timestamp: float
    value: float
    labels: Dict[str, str] = field(default_factory=dict)
    
    @property
    def datetime(self) -> datetime:
        return datetime.fromtimestamp(self.timestamp)


@dataclass
class MetricDefinition:
    """Definition of a metric we track."""
    name: str
    type: MetricType
    description: str
    unit: str
    level: MetricLevel = MetricLevel.INFO
    labels: List[str] = field(default_factory=list)


@dataclass
class AggregatedStats:
    """Aggregated statistics for a time window."""
    window: TimeWindow
    start_time: float
    end_time: float
    count: int = 0
    sum: float = 0.0
    min: float = float('inf')
    max: float = float('-inf')
    avg: float = 0.0
    p50: float = 0.0
    p95: float = 0.0
    p99: float = 0.0
    
    def update(self, value: float):
        self.count += 1
        self.sum += value
        self.min = min(self.min, value)
        self.max = max(self.max, value)
    
    def finalize(self, values: List[float]):
        if not values:
            return
        
        values.sort()
        self.avg = self.sum / self.count
        self.p50 = values[int(len(values) * 0.5)]
        self.p95 = values[int(len(values) * 0.95)]
        self.p99 = values[int(len(values) * 0.99)]


@dataclass
class EndpointMetrics:
    """Metrics for a specific endpoint/event."""
    event_name: str
    total_calls: int = 0
    total_errors: int = 0
    total_bytes_sent: int = 0
    total_bytes_received: int = 0
    latency_ms: List[float] = field(default_factory=list)
    last_called: Optional[float] = None
    error_types: Dict[str, int] = field(default_factory=dict)
    
    @property
    def error_rate(self) -> float:
        if self.total_calls == 0:
            return 0.0
        return (self.total_errors / self.total_calls) * 100
    
    @property
    def avg_latency(self) -> float:
        if not self.latency_ms:
            return 0.0
        return statistics.mean(self.latency_ms[-100:])


@dataclass
class ConnectionMetrics:
    """Metrics for connection patterns."""
    total_connections: int = 0
    peak_connections: int = 0
    peak_time: Optional[float] = None
    connections_by_ip: Dict[str, int] = field(default_factory=dict)
    connections_by_user: Dict[str, int] = field(default_factory=dict)
    connections_by_version: Dict[str, int] = field(default_factory=dict)
    avg_connection_duration: float = 0.0
    connection_durations: List[float] = field(default_factory=list)
    disconnection_reasons: Dict[str, int] = field(default_factory=dict)


# ============================================================================
# METRICS COLLECTOR (Updated for runtime config)
# ============================================================================

class MetricsCollector:
    """
    Core metrics collection engine.
    
    Collects, stores, and aggregates metrics with minimal overhead.
    Supports runtime updates to collection parameters.
    """
    
    def __init__(self, config: MetricsConfig):
        """
        Args:
            config: Metrics configuration
        """
        self.config = config
        
        # Metric storage
        self._metrics: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=config.max_points_per_metric)
        )
        
        # Metric definitions
        self._definitions: Dict[str, MetricDefinition] = {}
        
        # Aggregated stats
        self._aggregations: Dict[str, Dict[TimeWindow, AggregatedStats]] = defaultdict(dict)
        
        # Per-endpoint metrics
        self._endpoint_metrics: Dict[str, EndpointMetrics] = {}
        
        # Locks for thread safety
        self._lock = threading.RLock()
        self._aggregation_lock = threading.RLock()
        
        # Background aggregation
        self._running = True
        self._aggregation_thread = threading.Thread(target=self._aggregation_loop, daemon=True)
        self._aggregation_thread.start()
        
        # Register default metrics
        self._register_default_metrics()
    
    def update_config(self, new_config: MetricsConfig) -> None:
        """Update configuration at runtime."""
        with self._lock:
            old_max = self.config.max_points_per_metric
            self.config = new_config
            
            # If max points decreased, we may need to trim storage
            if new_config.max_points_per_metric < old_max:
                for name, points in self._metrics.items():
                    while len(points) > new_config.max_points_per_metric:
                        points.popleft()
            
            logging.info("[MetricsCollector] Configuration updated at runtime")
    
    def _register_default_metrics(self):
        """Register built-in metrics."""
        self.register_metric(MetricDefinition(
            name="connections.active",
            type=MetricType.GAUGE,
            description="Currently active WebSocket connections",
            unit="connections",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="connections.total",
            type=MetricType.COUNTER,
            description="Total connections ever established",
            unit="connections",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="messages.received",
            type=MetricType.COUNTER,
            description="Messages received from clients",
            unit="messages",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="messages.sent",
            type=MetricType.COUNTER,
            description="Messages sent to clients",
            unit="messages",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="latency.ms",
            type=MetricType.HISTOGRAM,
            description="Message processing latency",
            unit="milliseconds",
            level=MetricLevel.INFO,
            labels=["event"]
        ))
        
        self.register_metric(MetricDefinition(
            name="errors.total",
            type=MetricType.COUNTER,
            description="Total errors encountered",
            unit="errors",
            level=MetricLevel.WARNING,
            labels=["type"]
        ))
        
        self.register_metric(MetricDefinition(
            name="bytes.sent",
            type=MetricType.COUNTER,
            description="Bytes sent to clients",
            unit="bytes",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="bytes.received",
            type=MetricType.COUNTER,
            description="Bytes received from clients",
            unit="bytes",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="rate.messages_per_second",
            type=MetricType.RATE,
            description="Current message rate",
            unit="msg/sec",
            level=MetricLevel.INFO
        ))
        
        self.register_metric(MetricDefinition(
            name="rate.errors_per_second",
            type=MetricType.RATE,
            description="Current error rate",
            unit="errors/sec",
            level=MetricLevel.WARNING
        ))
    
    def register_metric(self, definition: MetricDefinition):
        """Register a new metric."""
        with self._lock:
            self._definitions[definition.name] = definition
    
    def record(self, metric_name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """
        Record a metric value.
        
        Args:
            metric_name: Name of the metric
            value: Value to record
            labels: Optional labels for filtering
        """
        if not self.config.enabled:
            return
        
        if metric_name not in self._definitions:
            return
        
        with self._lock:
            point = MetricPoint(
                timestamp=time.time(),
                value=value,
                labels=labels or {}
            )
            self._metrics[metric_name].append(point)
    
    def record_latency(self, event: str, latency_ms: float):
        """Record a latency measurement."""
        self.record("latency.ms", latency_ms, {"event": event})
        
        # Also update endpoint metrics
        with self._lock:
            if event not in self._endpoint_metrics:
                self._endpoint_metrics[event] = EndpointMetrics(event_name=event)
            self._endpoint_metrics[event].latency_ms.append(latency_ms)
            self._endpoint_metrics[event].total_calls += 1
            self._endpoint_metrics[event].last_called = time.time()
    
    def record_error(self, error_type: str, event: Optional[str] = None):
        """Record an error."""
        labels = {"type": error_type}
        if event:
            labels["event"] = event
        self.record("errors.total", 1, labels)
        
        # Also update endpoint metrics
        if event:
            with self._lock:
                if event not in self._endpoint_metrics:
                    self._endpoint_metrics[event] = EndpointMetrics(event_name=event)
                self._endpoint_metrics[event].total_errors += 1
                self._endpoint_metrics[event].error_types[error_type] = \
                    self._endpoint_metrics[event].error_types.get(error_type, 0) + 1
    
    def get_metric(self, name: str, window: TimeWindow = TimeWindow.REALTIME,
                   limit: int = 1000) -> List[MetricPoint]:
        """Get raw metric points."""
        with self._lock:
            if name not in self._metrics:
                return []
            
            points = list(self._metrics[name])
            
            if window != TimeWindow.REALTIME:
                cutoff = self._window_to_seconds(window)
                min_time = time.time() - cutoff
                points = [p for p in points if p.timestamp >= min_time]
            
            return points[-limit:]
    
    def get_aggregated(self, name: str, window: TimeWindow) -> Optional[AggregatedStats]:
        """Get pre-aggregated statistics for a metric."""
        with self._aggregation_lock:
            return self._aggregations[name].get(window)
    
    def get_endpoint_metrics(self, event: Optional[str] = None) -> Dict[str, Any]:
        """Get metrics for specific endpoint or all endpoints."""
        with self._lock:
            if event:
                if event in self._endpoint_metrics:
                    return {
                        'event': event,
                        **{
                            k: v for k, v in self._endpoint_metrics[event].__dict__.items()
                            if not k.startswith('_')
                        }
                    }
                return {}
            
            return {
                name: {
                    k: v for k, v in metrics.__dict__.items() if not k.startswith('_')
                }
                for name, metrics in self._endpoint_metrics.items()
            }
    
    def _aggregation_loop(self):
        """Background thread that aggregates metrics."""
        while self._running:
            time.sleep(self.config.collection_interval)
            self._aggregate_all()
    
    def _aggregate_all(self):
        """Aggregate all metrics for all time windows."""
        with self._lock:
            for name, points in self._metrics.items():
                self._aggregate_metric(name, list(points))
    
    def _aggregate_metric(self, name: str, points: List[MetricPoint]):
        """Aggregate a single metric for multiple time windows."""
        now = time.time()
        windows = [
            (TimeWindow.MINUTE, 60),
            (TimeWindow.FIVE_MINUTE, 300),
            (TimeWindow.HOUR, 3600),
            (TimeWindow.DAY, 86400),
        ]
        
        for window, seconds in windows:
            cutoff = now - seconds
            window_points = [p for p in points if p.timestamp >= cutoff]
            
            if not window_points:
                continue
            
            agg = AggregatedStats(
                window=window,
                start_time=cutoff,
                end_time=now
            )
            
            values = []
            for point in window_points:
                agg.update(point.value)
                values.append(point.value)
            
            agg.finalize(values)
            
            with self._aggregation_lock:
                self._aggregations[name][window] = agg
    
    def _window_to_seconds(self, window: TimeWindow) -> int:
        """Convert time window to seconds."""
        mapping = {
            TimeWindow.MINUTE: 60,
            TimeWindow.FIVE_MINUTE: 300,
            TimeWindow.HOUR: 3600,
            TimeWindow.DAY: 86400,
            TimeWindow.WEEK: 604800,
            TimeWindow.REALTIME: 0,
        }
        return mapping.get(window, 60)
    
    def shutdown(self):
        """Stop aggregation thread."""
        self._running = False
        self._aggregation_thread.join(timeout=5)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get collector statistics."""
        with self._lock:
            return {
                'active_metrics': len(self._metrics),
                'total_points': sum(len(q) for q in self._metrics.values()),
                'endpoints_tracked': len(self._endpoint_metrics),
                'config': self.config.to_dict()
            }


# ============================================================================
# ALERT MANAGER (Updated for runtime config)
# ============================================================================

@dataclass
class AlertRule:
    """Rule for generating alerts based on metrics."""
    name: str
    metric: str
    condition: str  # ">", "<", "==", ">=", "<="
    threshold: float
    window: TimeWindow
    severity: AlertSeverity
    description: str
    cooldown: int = 300
    enabled: bool = True
    last_triggered: Optional[float] = None


class AlertManager:
    """
    Manages alerts based on metrics.
    
    Evaluates rules against current metrics and triggers notifications.
    Supports runtime updates to alert rules and configuration.
    """
    
    def __init__(self, collector: MetricsCollector, config: MetricsConfig):
        """
        Args:
            collector: Metrics collector to query
            config: Metrics configuration
        """
        self.collector = collector
        self.config = config
        self._rules: List[AlertRule] = []
        self._alert_history: deque = deque(maxlen=config.max_alerts_history)
        
        # Alert handlers
        self._handlers: List[Callable] = []
        
        # Lock for thread safety
        self._lock = threading.RLock()
        
        # Evaluation thread
        self._running = True
        self._eval_thread = threading.Thread(target=self._evaluation_loop, daemon=True)
        self._eval_thread.start()
        
        # Register default rules
        self._register_default_rules()
    
    def update_config(self, new_config: MetricsConfig) -> None:
        """Update configuration at runtime."""
        with self._lock:
            old_max = self.config.max_alerts_history
            self.config = new_config
            
            # Resize history if needed
            if new_config.max_alerts_history < old_max:
                new_history = deque(maxlen=new_config.max_alerts_history)
                for alert in list(self._alert_history)[-new_config.max_alerts_history:]:
                    new_history.append(alert)
                self._alert_history = new_history
            
            logging.info("[AlertManager] Configuration updated at runtime")
    
    def _register_default_rules(self):
        """Register built-in alert rules."""
        self.add_rule(AlertRule(
            name="high_error_rate",
            metric="rate.errors_per_second",
            condition=">",
            threshold=10,
            window=TimeWindow.MINUTE,
            severity=AlertSeverity.WARNING,
            description="Error rate exceeds 10 per second"
        ))
        
        self.add_rule(AlertRule(
            name="high_latency",
            metric="latency.ms",
            condition=">",
            threshold=1000,
            window=TimeWindow.MINUTE,
            severity=AlertSeverity.WARNING,
            description="Average latency exceeds 1 second"
        ))
        
        self.add_rule(AlertRule(
            name="connection_spike",
            metric="connections.active",
            condition=">",
            threshold=10000,
            window=TimeWindow.MINUTE,
            severity=AlertSeverity.INFO,
            description="Connection spike detected"
        ))
        
        self.add_rule(AlertRule(
            name="zero_connections",
            metric="connections.active",
            condition="==",
            threshold=0,
            window=TimeWindow.MINUTE,
            severity=AlertSeverity.CRITICAL,
            description="No active connections - possible outage"
        ))
    
    def add_rule(self, rule: AlertRule):
        """Add an alert rule."""
        with self._lock:
            self._rules.append(rule)
            logging.info(f"[AlertManager] Added alert rule: {rule.name}")
    
    def remove_rule(self, rule_name: str) -> bool:
        """Remove an alert rule by name."""
        with self._lock:
            initial_len = len(self._rules)
            self._rules = [r for r in self._rules if r.name != rule_name]
            if len(self._rules) < initial_len:
                logging.info(f"[AlertManager] Removed alert rule: {rule_name}")
                return True
            return False
    
    def update_rule(self, rule_name: str, **updates) -> bool:
        """Update an existing alert rule."""
        with self._lock:
            for rule in self._rules:
                if rule.name == rule_name:
                    for key, value in updates.items():
                        if hasattr(rule, key):
                            setattr(rule, key, value)
                    logging.info(f"[AlertManager] Updated alert rule: {rule_name}")
                    return True
            return False
    
    def add_handler(self, handler: Callable[[Dict[str, Any]], None]):
        """Add a handler function for alerts."""
        with self._lock:
            self._handlers.append(handler)
    
    def _evaluation_loop(self):
        """Background thread that evaluates alert rules."""
        while self._running:
            time.sleep(self.config.alert_check_interval)
            self._evaluate_all_rules()
    
    def _evaluate_all_rules(self):
        """Evaluate all alert rules."""
        for rule in self._rules:
            if not rule.enabled:
                continue
            
            # Check cooldown
            if rule.last_triggered:
                if time.time() - rule.last_triggered < rule.cooldown:
                    continue
            
            # Get aggregated metric
            agg = self.collector.get_aggregated(rule.metric, rule.window)
            if not agg:
                continue
            
            # Check condition
            triggered = False
            value = agg.avg
            
            if rule.condition == ">" and value > rule.threshold:
                triggered = True
            elif rule.condition == "<" and value < rule.threshold:
                triggered = True
            elif rule.condition == ">=" and value >= rule.threshold:
                triggered = True
            elif rule.condition == "<=" and value <= rule.threshold:
                triggered = True
            elif rule.condition == "==" and value == rule.threshold:
                triggered = True
            
            if triggered:
                self._trigger_alert(rule, value, agg)
    
    def _trigger_alert(self, rule: AlertRule, value: float, stats: AggregatedStats):
        """Trigger an alert."""
        alert_data = {
            "rule_name": rule.name,
            "severity": rule.severity.value,
            "metric": rule.metric,
            "threshold": rule.threshold,
            "actual_value": value,
            "condition": rule.condition,
            "window": rule.window.value,
            "timestamp": time.time(),
            "description": rule.description,
            "stats": {
                "min": stats.min,
                "max": stats.max,
                "avg": stats.avg,
                "p95": stats.p95,
                "count": stats.count
            }
        }
        
        with self._lock:
            self._alert_history.append(alert_data)
            rule.last_triggered = time.time()
        
        # Call all handlers
        for handler in self._handlers:
            try:
                handler(alert_data)
            except Exception as e:
                logging.error(f"[AlertManager] Alert handler failed: {e}")
        
        logging.info(f"[ALERT] {rule.severity.value.upper()}: {rule.description} "
                     f"(value: {value:.2f}, threshold: {rule.threshold})")
    
    def get_recent_alerts(self, limit: int = 100) -> List[Dict]:
        """Get recent alerts."""
        with self._lock:
            return list(self._alert_history)[-limit:]
    
    def get_rules(self) -> List[Dict]:
        """Get all alert rules."""
        with self._lock:
            return [
                {
                    'name': r.name,
                    'metric': r.metric,
                    'condition': r.condition,
                    'threshold': r.threshold,
                    'window': r.window.value,
                    'severity': r.severity.value,
                    'enabled': r.enabled,
                    'cooldown': r.cooldown
                }
                for r in self._rules
            ]
    
    def shutdown(self):
        """Stop evaluation thread."""
        self._running = False
        self._eval_thread.join(timeout=5)


# ============================================================================
# HEALTH CHECKER (Updated for runtime config)
# ============================================================================

@dataclass
class HealthStatus:
    """Health check result."""
    status: str  # "healthy", "degraded", "unhealthy"
    checks: Dict[str, Dict[str, Any]]
    timestamp: float = field(default_factory=time.time)
    
    @property
    def is_healthy(self) -> bool:
        return self.status == "healthy"
    
    @property
    def is_degraded(self) -> bool:
        return self.status == "degraded"


class HealthChecker:
    """
    Performs health checks on WebSocket system.
    Supports runtime updates to check intervals.
    """
    
    def __init__(self, engine: WebSocketEngine, collector: MetricsCollector, config: MetricsConfig):
        """
        Args:
            engine: WebSocket engine
            collector: Metrics collector
            config: Metrics configuration
        """
        self.engine = engine
        self.collector = collector
        self.config = config
        self._checks: Dict[str, Callable] = {}
        self._lock = threading.RLock()
        
        # Register default checks
        self._register_default_checks()
    
    def update_config(self, new_config: MetricsConfig) -> None:
        """Update configuration at runtime."""
        with self._lock:
            self.config = new_config
            logging.info("[HealthChecker] Configuration updated at runtime")
    
    def _register_default_checks(self):
        """Register built-in health checks."""
        self.register_check("connections", self._check_connections)
        self.register_check("error_rate", self._check_error_rate)
        self.register_check("latency", self._check_latency)
        self.register_check("memory", self._check_memory)
    
    def register_check(self, name: str, check_func: Callable[[], Dict[str, Any]]):
        """Register a health check function."""
        with self._lock:
            self._checks[name] = check_func
    
    def unregister_check(self, name: str) -> bool:
        """Unregister a health check."""
        with self._lock:
            if name in self._checks:
                del self._checks[name]
                return True
            return False
    
    def check(self) -> HealthStatus:
        """Run all health checks."""
        results = {}
        all_healthy = True
        
        for name, check_func in self._checks.items():
            try:
                result = check_func()
                results[name] = result
                if not result.get("healthy", True):
                    all_healthy = False
            except Exception as e:
                results[name] = {
                    "healthy": False,
                    "error": str(e)
                }
                all_healthy = False
        
        status = "healthy" if all_healthy else "degraded"
        
        return HealthStatus(
            status=status,
            checks=results
        )
    
    def _check_connections(self) -> Dict[str, Any]:
        """Check connection health."""
        active = self.engine.active_connections
        agg = self.collector.get_aggregated("connections.active", TimeWindow.HOUR)
        
        result = {
            "healthy": True,
            "active_connections": active
        }
        
        if agg:
            result["avg_last_hour"] = agg.avg
            result["max_last_hour"] = agg.max
            
            if active < agg.avg * 0.5:
                result["healthy"] = False
                result["warning"] = "Connection count dropped 50% below average"
        
        return result
    
    def _check_error_rate(self) -> Dict[str, Any]:
        """Check error rate health."""
        agg = self.collector.get_aggregated("rate.errors_per_second", TimeWindow.FIVE_MINUTE)
        
        result = {
            "healthy": True
        }
        
        if agg and agg.avg > 10:
            result["healthy"] = False
            result["error_rate"] = agg.avg
            result["warning"] = f"High error rate: {agg.avg:.2f}/sec"
        
        return result
    
    def _check_latency(self) -> Dict[str, Any]:
        """Check latency health."""
        agg = self.collector.get_aggregated("latency.ms", TimeWindow.FIVE_MINUTE)
        
        result = {
            "healthy": True
        }
        
        if agg and agg.p95 > 1000:
            result["healthy"] = False
            result["p95_latency"] = agg.p95
            result["warning"] = f"High latency: p95={agg.p95:.0f}ms"
        
        return result
    
    def _check_memory(self) -> Dict[str, Any]:
        """Check memory usage."""
        try:
            import psutil
            process = psutil.Process()
            memory = process.memory_info()
            
            result = {
                "healthy": True,
                "rss_bytes": memory.rss,
                "rss_mb": memory.rss / (1024 * 1024)
            }
            
            if memory.rss > 1024 * 1024 * 1024:
                result["healthy"] = False
                result["warning"] = "High memory usage"
            
            return result
        except ImportError:
            return {
                "healthy": True,
                "warning": "psutil not installed, memory check skipped"
            }


# ============================================================================
# PROMETHEUS EXPORTER (Updated for runtime config)
# ============================================================================

class PrometheusExporter:
    """
    Exports metrics in Prometheus format.
    Supports runtime updates to export settings.
    """
    
    def __init__(self, collector: MetricsCollector, config: MetricsConfig):
        """
        Args:
            collector: Metrics collector
            config: Metrics configuration
        """
        self.collector = collector
        self.config = config
    
    def update_config(self, new_config: MetricsConfig) -> None:
        """Update configuration at runtime."""
        self.config = new_config
        logging.info("[PrometheusExporter] Configuration updated at runtime")
    
    def export(self) -> str:
        """
        Export all metrics in Prometheus format.
        
        Returns:
            Prometheus-formatted metrics string
        """
        if not self.config.enable_prometheus:
            return "# Prometheus metrics disabled"
        
        lines = []
        namespace = self.config.prometheus_namespace
        
        for name, definition in self.collector._definitions.items():
            metric_name = f"{namespace}_{name.replace('.', '_')}"
            lines.append(f"# HELP {metric_name} {definition.description}")
            lines.append(f"# TYPE {metric_name} {definition.type.value}")
            
            points = self.collector.get_metric(name, limit=100)
            
            if definition.type == MetricType.GAUGE:
                if points:
                    latest = points[-1]
                    labels = self._format_labels(latest.labels)
                    lines.append(f"{metric_name}{labels} {latest.value}")
            
            elif definition.type == MetricType.COUNTER:
                total = sum(p.value for p in points)
                lines.append(f"{metric_name}_total {total}")
            
            elif definition.type == MetricType.HISTOGRAM:
                if points:
                    values = [p.value for p in points]
                    lines.append(f"{metric_name}_count {len(values)}")
                    lines.append(f"{metric_name}_sum {sum(values)}")
                    
                    values.sort()
                    lines.append(f"{metric_name}_p50 {values[int(len(values)*0.5)]}")
                    lines.append(f"{metric_name}_p95 {values[int(len(values)*0.95)]}")
                    lines.append(f"{metric_name}_p99 {values[int(len(values)*0.99)]}")
        
        return "\n".join(lines)
    
    def _format_labels(self, labels: Dict[str, str]) -> str:
        """Format labels for Prometheus."""
        if not labels:
            return ""
        items = [f'{k}="{v}"' for k, v in sorted(labels.items())]
        return "{" + ",".join(items) + "}"


# ============================================================================
# REAL-TIME DASHBOARD (Updated for runtime config)
# ============================================================================

class RealtimeDashboard:
    """
    Simple real-time dashboard for WebSocket metrics.
    Supports runtime updates to dashboard settings.
    """
    
    HTML_TEMPLATE = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>WebSocket Metrics Dashboard</title>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <style>
            body { font-family: Arial; margin: 20px; background: #1e1e1e; color: #fff; }
            .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
            .card { background: #2d2d2d; padding: 20px; border-radius: 8px; }
            .stat { display: inline-block; margin: 10px; padding: 15px; background: #3d3d3d; border-radius: 4px; }
            .stat-label { color: #888; font-size: 12px; }
            .stat-value { font-size: 24px; font-weight: bold; }
            .healthy { color: #4caf50; }
            .warning { color: #ff9800; }
            .critical { color: #f44336; }
            h1, h2 { margin-top: 0; }
            .refresh { float: right; cursor: pointer; }
        </style>
    </head>
    <body>
        <h1>WebSocket Real-Time Metrics <span class="refresh" onclick="refresh()">🔄</span></h1>
        
        <div id="summary" class="grid" style="grid-template-columns: repeat(4, 1fr);">
            <div class="card">
                <div class="stat-label">Active Connections</div>
                <div class="stat-value" id="conn-count">0</div>
            </div>
            <div class="card">
                <div class="stat-label">Messages/sec</div>
                <div class="stat-value" id="msg-rate">0</div>
            </div>
            <div class="card">
                <div class="stat-label">Error Rate</div>
                <div class="stat-value" id="error-rate">0</div>
            </div>
            <div class="card">
                <div class="stat-label">Avg Latency</div>
                <div class="stat-value" id="avg-latency">0ms</div>
            </div>
        </div>
        
        <div class="grid">
            <div class="card">
                <h2>Connections Over Time</h2>
                <div id="chart-connections"></div>
            </div>
            <div class="card">
                <h2>Message Rate</h2>
                <div id="chart-messages"></div>
            </div>
            <div class="card">
                <h2>Latency (ms)</h2>
                <div id="chart-latency"></div>
            </div>
            <div class="card">
                <h2>Error Rate</h2>
                <div id="chart-errors"></div>
            </div>
        </div>
        
        <div class="card">
            <h2>Recent Alerts</h2>
            <div id="alerts"></div>
        </div>
        
        <script>
            let refreshInterval = {refresh_interval};
            let historyPoints = {history_points};
            
            function refresh() {{
                fetch('/metrics/dashboard-data')
                    .then(r => r.json())
                    .then(data => updateDashboard(data));
            }}
            
            function updateDashboard(data) {{
                document.getElementById('conn-count').innerText = data.connections.active;
                document.getElementById('msg-rate').innerText = data.rates.messages.toFixed(1);
                document.getElementById('error-rate').innerText = data.rates.errors.toFixed(2);
                document.getElementById('avg-latency').innerText = data.latency.avg.toFixed(0) + 'ms';
                
                Plotly.newPlot('chart-connections', [{{
                    x: data.timestamps,
                    y: data.connections.history,
                    type: 'scatter',
                    mode: 'lines',
                    line: {{color: '#4caf50'}}
                }}], {{paper_bgcolor: '#2d2d2d', plot_bgcolor: '#2d2d2d', font: {{color: '#fff'}}}});
                
                Plotly.newPlot('chart-messages', [{{
                    x: data.timestamps,
                    y: data.rates.history,
                    type: 'scatter',
                    mode: 'lines',
                    line: {{color: '#2196f3'}}
                }}], {{paper_bgcolor: '#2d2d2d', plot_bgcolor: '#2d2d2d', font: {{color: '#fff'}}}});
                
                Plotly.newPlot('chart-latency', [{{
                    x: data.timestamps,
                    y: data.latency.history,
                    type: 'scatter',
                    mode: 'lines',
                    line: {{color: '#ff9800'}}
                }}], {{paper_bgcolor: '#2d2d2d', plot_bgcolor: '#2d2d2d', font: {{color: '#fff'}}}});
                
                Plotly.newPlot('chart-errors', [{{
                    x: data.timestamps,
                    y: data.errors.history,
                    type: 'scatter',
                    mode: 'lines',
                    line: {{color: '#f44336'}}
                }}], {{paper_bgcolor: '#2d2d2d', plot_bgcolor: '#2d2d2d', font: {{color: '#fff'}}}});
                
                let alertsHtml = '';
                data.alerts.forEach(alert => {{
                    let severityClass = alert.severity === 'critical' ? 'critical' : 
                                      alert.severity === 'warning' ? 'warning' : 'healthy';
                    alertsHtml += `<div class="stat ${{severityClass}}">
                        <strong>${{alert.rule_name}}</strong>: ${{alert.description}}<br>
                        <small>${{new Date(alert.timestamp*1000).toLocaleString()}}</small>
                    </div>`;
                }});
                document.getElementById('alerts').innerHTML = alertsHtml || 'No recent alerts';
            }}
            
            setInterval(refresh, refreshInterval * 1000);
            refresh();
        </script>
    </body>
    </html>
    """
    
    def __init__(self, metrics_manager: 'WebSocketMetricsManager'):
        self.manager = metrics_manager
    
    def render(self) -> str:
        """Render the dashboard HTML with current config."""
        return self.HTML_TEMPLATE.format(
            refresh_interval=self.manager.config.dashboard_refresh_interval,
            history_points=self.manager.config.dashboard_history_points
        )
    
    def get_data(self) -> Dict[str, Any]:
        """Get current data for dashboard."""
        collector = self.manager.collector
        alerts = self.manager.alerts
        
        timestamps = []
        conn_history = []
        rate_history = []
        latency_history = []
        error_history = []
        
        now = time.time()
        points = self.manager.config.dashboard_history_points
        
        for i in range(points, 0, -1):
            t = now - (i * self.manager.config.dashboard_refresh_interval)
            timestamps.append(t)
            
            conn_history.append(self.manager.stats.connections.get('active', 0))
            rate_history.append(self.manager.stats.messages.get('per_second', 0))
            latency_history.append(self.manager.stats.performance.get('avg_latency_ms', 0))
            error_history.append(self.manager.stats.errors.get('per_second', 0))
        
        return {
            'timestamps': timestamps,
            'connections': {
                'active': self.manager.stats.connections.get('active', 0),
                'history': conn_history
            },
            'rates': {
                'messages': self.manager.stats.messages.get('per_second', 0),
                'errors': self.manager.stats.errors.get('per_second', 0),
                'history': rate_history
            },
            'latency': {
                'avg': self.manager.stats.performance.get('avg_latency_ms', 0),
                'history': latency_history
            },
            'errors': {
                'history': error_history
            },
            'alerts': alerts.get_recent_alerts(10)
        }


# ============================================================================
# MAIN METRICS MANAGER
# ============================================================================

@dataclass
class MetricsSnapshot:
    """Snapshot of current metrics."""
    timestamp: float = field(default_factory=time.time)
    connections: Dict[str, Any] = field(default_factory=dict)
    messages: Dict[str, Any] = field(default_factory=dict)
    errors: Dict[str, Any] = field(default_factory=dict)
    performance: Dict[str, Any] = field(default_factory=dict)
    resources: Dict[str, Any] = field(default_factory=dict)


class WebSocketMetricsManager:
    """
    Main manager for all WebSocket metrics and observability.
    
    Integrates all metrics components:
    - Collection (counters, gauges, histograms)
    - Alerting (rules, notifications)
    - Health checks
    - Dashboards
    - Exporters (Prometheus, etc.)
    - Runtime updates to all settings
    """
    
    def __init__(
        self,
        engine: WebSocketEngine,
        config: MetricsConfig,
        security: Optional[WebSocketSecurityManager] = None,
        limits: Optional[WebSocketLimitsManager] = None,
        protocol: Optional[WebSocketProtocolManager] = None
    ):
        """
        Initialize metrics manager.
        
        Args:
            engine: WebSocket engine
            config: Metrics configuration
            security: Optional security manager
            limits: Optional limits manager
            protocol: Optional protocol manager
        """
        self.engine = engine
        self.config = config
        self.security = security
        self.limits = limits
        self.protocol = protocol
        
        # Core components (pass config to each)
        self.collector = MetricsCollector(config)
        self.alerts = AlertManager(self.collector, config)
        self.health = HealthChecker(engine, self.collector, config)
        self.prometheus = PrometheusExporter(self.collector, config)
        self.dashboard = RealtimeDashboard(self)
        
        # Current stats snapshot
        self.stats = MetricsSnapshot()
        
        # Statistics
        self._last_stats_time = time.time()
        self._message_counts: deque = deque(maxlen=60)
        self._error_counts: deque = deque(maxlen=60)
        self._latencies: deque = deque(maxlen=1000)
        
        # Locks for thread safety
        self._lock = threading.RLock()
        
        # Register hooks
        self._register_hooks()
        
        # Start stats updater if enabled
        self._running = True
        if config.enabled:
            self._stats_thread = threading.Thread(target=self._update_stats_loop, daemon=True)
            self._stats_thread.start()
        
        logging.info("[WebSocketMetrics] Metrics manager initialized")
        logging.info(f"  - Metrics collector: {'active' if config.enabled else 'disabled'}")
        logging.info(f"  - Alert rules: {len(self.alerts._rules)}")
        logging.info(f"  - Health checks: {len(self.health._checks)}")
        logging.info(f"  - Dashboard: {'enabled' if config.enable_dashboard else 'disabled'}")
        logging.info(f"  - Prometheus: {'enabled' if config.enable_prometheus else 'disabled'}")
    
    # ========================================================================
    # RUNTIME UPDATE METHODS
    # ========================================================================
    
    def update_config(self, new_config: MetricsConfig) -> None:
        """
        Update metrics configuration at runtime.
        
        This method is called by the WebSocketConfigManager when
        metrics settings are updated.
        
        Args:
            new_config: Updated metrics configuration
        """
        with self._lock:
            old_config = self.config
            self.config = new_config
            
            # Update sub-components
            self.collector.update_config(new_config)
            self.alerts.update_config(new_config)
            self.health.update_config(new_config)
            self.prometheus.update_config(new_config)
            
            # Handle thread start/stop if enabled changed
            if old_config.enabled != new_config.enabled:
                if new_config.enabled and not hasattr(self, '_stats_thread'):
                    self._stats_thread = threading.Thread(target=self._update_stats_loop, daemon=True)
                    self._stats_thread.start()
                    logging.info("[Metrics] Stats collection started at runtime")
            
            logging.info("[WebSocketMetrics] Configuration updated at runtime")
    
    def _register_hooks(self):
        """Register hooks with engine and other managers."""
        
        @self.engine.before_connect
        def track_connection_attempt(conn_info: ConnectionInfo) -> bool:
            self.collector.record("connections.attempts", 1)
            return True
        
        @self.engine.after_connect
        def track_new_connection(conn_info: ConnectionInfo):
            self.collector.record("connections.active", 
                                 self.engine.active_connections, 
                                 {"type": "gauge"})
            self.collector.record("connections.total", 1)
        
        @self.engine.before_event
        def track_message_received(event: str, data: Any, conn_info: ConnectionInfo) -> bool:
            start_time = time.time()
            
            thread_data = threading.local()
            thread_data.start_time = start_time
            thread_data.event = event
            
            self.collector.record("messages.received", 1, {"event": event})
            self._message_counts.append(time.time())
            
            return True
        
        @self.engine.after_event
        def track_message_processed(event: str, data: Any, conn_info: ConnectionInfo, result: Any):
            thread_data = getattr(threading.local(), 'start_time', None)
            if thread_data:
                latency = (time.time() - thread_data) * 1000
                self.collector.record_latency(event, latency)
                self._latencies.append(latency)
        
        @self.engine.after_disconnect
        def track_disconnect(conn_info: ConnectionInfo):
            self.collector.record("connections.active", 
                                 self.engine.active_connections,
                                 {"type": "gauge"})
            
            if conn_info.connection_duration:
                self.collector.record("connections.duration", 
                                     conn_info.connection_duration)
        
        def track_error(error_type: str, event: Optional[str] = None):
            self.collector.record_error(error_type, event)
            self._error_counts.append(time.time())
        
        if self.security:
            original_auth = self.security._authenticate_connection
            
            @wraps(original_auth)
            def wrapped_auth(conn_info):
                result = original_auth(conn_info)
                if not result.success:
                    track_error(f"auth_failure_{result.error_code}")
                return result
            
            self.security._authenticate_connection = wrapped_auth
        
        if self.limits:
            original_check = self.limits._check_message_limits
            
            @wraps(original_check)
            def wrapped_check(event, data, conn_info):
                allowed = original_check(event, data, conn_info)
                if not allowed:
                    track_error("limit_violation", event)
                return allowed
            
            self.limits._check_message_limits = wrapped_check
    
    def _update_stats_loop(self):
        """Background thread that updates current statistics."""
        while self._running and self.config.enabled:
            self._update_stats()
            time.sleep(1)
    
    def _update_stats(self):
        """Update current statistics snapshot."""
        now = time.time()
        
        msg_window = [t for t in self._message_counts if t > now - 1]
        err_window = [t for t in self._error_counts if t > now - 1]
        
        avg_latency = 0
        if self._latencies:
            avg_latency = statistics.mean(self._latencies)
        
        self.stats = MetricsSnapshot(
            timestamp=now,
            connections={
                'active': self.engine.active_connections,
                'peak': self.engine.stats.peak_connections if hasattr(self.engine, 'stats') else 0,
                'total': self.engine.stats.total_connections if hasattr(self.engine, 'stats') else 0,
            },
            messages={
                'per_second': len(msg_window),
                'total_received': len(self._message_counts),
                'total_sent': 0,  # Would need to track
            },
            errors={
                'per_second': len(err_window),
                'total': len(self._error_counts),
            },
            performance={
                'avg_latency_ms': avg_latency,
                'p95_latency_ms': self._calculate_percentile(95),
            },
            resources={
                'memory_mb': self._get_memory_usage(),
            }
        )
        
        self.collector.record("rate.messages_per_second", len(msg_window))
        self.collector.record("rate.errors_per_second", len(err_window))
        self.collector.record("connections.active", self.stats.connections['active'])
        self.collector.record("latency.avg", avg_latency)
    
    def _calculate_percentile(self, percentile: int) -> float:
        """Calculate latency percentile."""
        if not self._latencies:
            return 0.0
        
        values = sorted(self._latencies)
        idx = int(len(values) * percentile / 100)
        return values[min(idx, len(values)-1)]
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss / (1024 * 1024)
        except:
            return 0.0
    
    # ========================================================================
    # PUBLIC API
    # ========================================================================
    
    def get_snapshot(self) -> MetricsSnapshot:
        """Get current metrics snapshot."""
        return self.stats
    
    def get_health(self) -> HealthStatus:
        """Get system health status."""
        return self.health.check()
    
    def get_alerts(self, limit: int = 100) -> List[Dict]:
        """Get recent alerts."""
        return self.alerts.get_recent_alerts(limit)
    
    def get_prometheus_metrics(self) -> str:
        """Get metrics in Prometheus format."""
        if not self.config.enable_prometheus:
            return "# Prometheus metrics disabled"
        return self.prometheus.export()
    
    def get_dashboard_html(self) -> str:
        """Get real-time dashboard HTML."""
        if not self.config.enable_dashboard:
            return "<html><body><h1>Dashboard disabled</h1></body></html>"
        return self.dashboard.render()
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get dashboard data (for AJAX updates)."""
        if not self.config.enable_dashboard:
            return {'error': 'Dashboard disabled'}
        return self.dashboard.get_data()
    
    def get_endpoint_metrics(self, event: Optional[str] = None) -> Dict[str, Any]:
        """Get metrics for specific endpoint or all endpoints."""
        return self.collector.get_endpoint_metrics(event)
    
    def register_alert_handler(self, handler: Callable[[Dict], None]):
        """Register a handler for alerts."""
        self.alerts.add_handler(handler)
    
    def add_alert_rule(self, rule: AlertRule):
        """Add a custom alert rule."""
        self.alerts.add_rule(rule)
    
    def remove_alert_rule(self, rule_name: str) -> bool:
        """Remove an alert rule."""
        return self.alerts.remove_rule(rule_name)
    
    def update_alert_rule(self, rule_name: str, **updates) -> bool:
        """Update an alert rule."""
        return self.alerts.update_rule(rule_name, **updates)
    
    def register_custom_metric(self, definition: MetricDefinition):
        """Register a custom metric."""
        self.collector.register_metric(definition)
    
    def record_custom(self, name: str, value: float, labels: Optional[Dict] = None):
        """Record a custom metric value."""
        self.collector.record(name, value, labels)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive metrics system statistics."""
        return {
            'collector': self.collector.get_stats(),
            'alerts': {
                'rules': self.alerts.get_rules(),
                'recent_count': len(self.alerts._alert_history)
            },
            'health_checks': list(self.health._checks.keys()),
            'config': self.config.to_dict()
        }
    
    def shutdown(self):
        """Gracefully shut down metrics system."""
        self._running = False
        if hasattr(self, '_stats_thread'):
            self._stats_thread.join(timeout=5)
        self.collector.shutdown()
        self.alerts.shutdown()
        logging.info("[WebSocketMetrics] Metrics system shut down")


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def setup_websocket_metrics(
    engine: WebSocketEngine,
    config: MetricsConfig,
    security: Optional[WebSocketSecurityManager] = None,
    limits: Optional[WebSocketLimitsManager] = None,
    protocol: Optional[WebSocketProtocolManager] = None
) -> WebSocketMetricsManager:
    """
    Set up WebSocket metrics and observability.
    
    Args:
        engine: WebSocket engine instance
        config: Metrics configuration
        security: Optional security manager
        limits: Optional limits manager
        protocol: Optional protocol manager
        
    Returns:
        Configured WebSocketMetricsManager
    """
    manager = WebSocketMetricsManager(
        engine=engine,
        config=config,
        security=security,
        limits=limits,
        protocol=protocol
    )
    
    logging.info("[WebSocketMetrics] Observability system initialized")
    if config.enable_dashboard:
        logging.info(f"  - Real-time dashboard: /metrics/dashboard")
    if config.enable_prometheus:
        logging.info(f"  - Prometheus endpoint: /metrics/prometheus")
    logging.info(f"  - Health check: /metrics/health")
    logging.info(f"  - Alert rules: {len(manager.alerts._rules)}")
    
    return manager