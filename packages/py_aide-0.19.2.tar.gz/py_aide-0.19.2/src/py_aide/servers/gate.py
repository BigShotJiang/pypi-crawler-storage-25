"""
GATE MODULE - Secure Request Processing Pipeline with Custom Validator Support

This module provides a modular, secure pipeline for processing API requests.
It now supports custom validators through a simple decorator API.

Developers can register their own validators:
    >>> @register_validator('email')
    ... def validate_email(value, max_length=None, domain=None):
    ...     if '@' not in value:
    ...         raise ValueError("Invalid email")
    ...     return value.lower()

And use them in endpoints with automatic constraint builders:
    >>> @portal.endpoint(gate=GateConfig(param_constraints={
    ...     "email": constraints.email(max_length=254, domain="company.com")
    ... }))

SECURITY IMPROVEMENTS IMPLEMENTED:
1. Fixed token validation bypass vulnerability
2. Added input sanitization and validation
3. Implemented CSRF protection
4. Fixed rate limit race conditions
5. Added request size limits
6. Implemented user tier/RBAC enforcement
7. Added idempotency and deduplication
8. Added comprehensive audit logging
9. Implemented circuit breaker pattern
10. Added security headers
11. Custom validator registration system
12. Automatic constraint builder generation

CRITICAL SECURITY NOTES:
- All gates are thread-safe (new RequestContext per request)
- Input validation happens before business logic
- Rate limits use atomic operations to prevent race conditions
- CSRF tokens required for state-changing operations
- Request size limits prevent memory exhaustion attacks
"""

import time
import hashlib
import json
import base64
import re
from dataclasses import dataclass, field
from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
import threading
from typing import Any, Callable, Dict, Optional, Union
from enum import Enum
import os
import functools
import logging

from ..tokens import TokenManager
from ..customTypes import Options
from ..structures import validate

logger = logging.getLogger(__name__)


# ============================================================================
# ENUMS & CONSTANTS
# ============================================================================

class AuthType(str, Enum):
    """Supported authentication types."""
    BEARER = "bearer"
    API_KEY = "api_key"
    BASIC = "basic"
    TOKEN_PAYLOAD = "token_payload"
    NONE = "none"

class AuthHeader(str, Enum):
    """Standard HTTP Header names for Authentication."""
    X_API_KEY = "X-API-Key"
    X_API_KEY_ALT = "X-Api-Key"    # common variation
    API_KEY = "Api-Key"            # common variation
    AUTHORIZATION = "Authorization"
    X_AUTH_TOKEN = "X-Auth-Token"
    CLIENT_ID = "X-Client-Id"

class HttpMethod(str, Enum):
    """HTTP methods that trigger CSRF protection."""
    STATE_CHANGING = {"POST", "PUT", "PATCH", "DELETE"}

class SecurityLevel(str, Enum):
    """Security levels for various protections."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    PARANOID = "paranoid"

# Default security constants
DEFAULT_MAX_REQUEST_SIZE = 10 * 1024 * 1024  # 10MB
DEFAULT_RATE_LIMIT_WINDOW = 60  # seconds
DEFAULT_IDEMPOTENCY_WINDOW = 86_400  # 24 hours
DEFAULT_DEDUPE_WINDOW = 300  # 5 minutes
CSRF_TOKEN_LENGTH = 32


# ============================================================================
# VALIDATOR REGISTRY SYSTEM
# ============================================================================

class ValidatorRegistry:
    """Registry for custom validator functions."""
    
    _validators: Dict[str, Callable] = {}
    
    @classmethod
    def register(cls, name: str, validator_func: Callable) -> None:
        """
        Register a validator function.
        
        Args:
            name: Type name (e.g., 'email', 'phone', 'ssn')
            validator_func: Function that takes (value, **kwargs) and returns validated value
        """
        cls._validators[name] = validator_func
        
        # Automatically create a constraint builder and add to constraints namespace
        builder_func = cls._create_builder(name)
        setattr(constraints, name, staticmethod(builder_func))
    
    @classmethod
    def _create_builder(cls, name: str) -> Callable:
        """
        Create a constraint builder function for a validator.
        
        The builder returns a dictionary with 'type' and all provided kwargs.
        """
        def builder(**kwargs):
            return {"type": name, **kwargs}
        return builder
    
    @classmethod
    def get_validator(cls, name: str) -> Optional[Callable]:
        """Get validator function by name."""
        return cls._validators.get(name)
    
    @classmethod
    def get_all_types(cls) -> list[str]:
        """Get all registered validator types."""
        return list(cls._validators.keys())


# ============================================================================
# VALIDATOR DECORATOR
# ============================================================================

def register_validator(name: str):
    """
    Decorator to register a custom validator function.
    
    The validator function should take a value parameter and any number of
    keyword arguments that become available as constraints in the endpoint.
    
    Args:
        name: Type name for this validator (e.g., 'email', 'phone')
    
    Example:
        >>> @register_validator('email')
        ... def validate_email(value, max_length=None, domain=None):
        ...     if '@' not in value:
        ...         raise ValueError("Invalid email")
        ...     if max_length and len(value) > max_length:
        ...         raise ValueError(f"Email too long")
        ...     return value.lower()
        
        >>> # In endpoint:
        >>> @portal.endpoint(gate=GateConfig(param_constraints={
        ...     "user_email": constraints.email(max_length=254, domain="company.com")
        ... }))
    """
    def decorator(func: Callable) -> Callable:
        ValidatorRegistry.register(name, func)
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        
        return wrapper
    return decorator


# ============================================================================
# CONSTRAINTS NAMESPACE (Auto-populated by validator registry)
# ============================================================================

class constraints:
    """
    Namespace for constraint builders.
    
    Each registered validator automatically gets a builder function here.
    Builders return a dictionary that GateConfig.param_constraints expects.
    
    Built-in builders (always available):
        >>> constraints.required()  # Mark as required (default)
        >>> constraints.optional()  # Mark as optional
    
    Custom builders appear automatically when validators are registered:
        >>> @register_validator('email')
        ... def validate_email(value): ...
        >>> # Now constraints.email() is available
    """
    
    @staticmethod
    def required() -> dict:
        """Mark a parameter as required (default behavior)."""
        return {"optional": False}
    
    @staticmethod
    def optional() -> dict:
        """Mark a parameter as optional."""
        return {"optional": True}


# ============================================================================
# CORE DATA CLASSES
# ============================================================================

@dataclass
class RequestContext:
    """
    Thread-safe context for request processing.
    
    Each request creates a unique instance. This prevents data leakage
    between requests and ensures thread safety.
    
    CRITICAL: Never reuse RequestContext instances across requests.
    """
    
    def __init__(self, request):
        # Core request data (immutable after creation)
        self.request = request
        self.start_time = time.time()
        self.request_id = os.urandom(8).hex()  # Cryptographically secure ID
        self.client_ip = request.remote_addr or "unknown"
        
        # Security tracking
        self.security_flags: set[str] = set()
        self.audit_events: list[dict] = []
        
        # Data stores (populated by gates)
        self.user: dict|None = None  # Authenticated user data
        self.gate_data: dict[str, Any] = {}  # Inter-gate communication
        self.validated_data: dict[str, Any] = {}  # Sanitized request data
        self.security_headers: dict[str, str] = {}  # Security headers to add
        
        # Performance tracking
        self.gate_timings: dict[str, float] = {}
        
        # Request metadata
        self.content_length = int(request.headers.get('Content-Length', 0))
        self.user_agent = request.headers.get('User-Agent', '')
        self.referrer = request.headers.get('Referer', '')
    
    def set(self, key: str, value: Any, security_context: str = "") -> None:
        """Store data with optional security context."""
        self.gate_data[key] = value
        if security_context:
            self.add_audit_event(f"set_{key}", security_context)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve stored data."""
        return self.gate_data.get(key, default)
    
    def add_audit_event(self, event_type: str, details: str, 
                       security_level: SecurityLevel = SecurityLevel.MEDIUM) -> None:
        """Add audit event for security monitoring."""
        self.audit_events.append({
            "timestamp": time.time(),
            "type": event_type,
            "details": details,
            "level": security_level.value,
            "request_id": self.request_id,
            "client_ip": self.client_ip
        })
    
    def add_security_flag(self, flag: str) -> None:
        """Mark security-relevant condition."""
        self.security_flags.add(flag)
    
    def has_security_flag(self, flag: str) -> bool:
        """Check for security flag."""
        return flag in self.security_flags
    
    def measure_gate_time(self, gate_name: str, start_time: float) -> None:
        """Record gate execution time for performance monitoring."""
        self.gate_timings[gate_name] = time.time() - start_time


@dataclass
class GateConfig:
    """
    Security configuration for an endpoint.
    
    CRITICAL: Always review these settings for production endpoints.
    Defaults are secure but may need adjustment for specific use cases.
    """
    
    # Authentication
    auth_required: bool = True
    auth_type: AuthType = AuthType.TOKEN_PAYLOAD
    user_tiers: list[str] = field(default_factory=list)  # RBAC requirements
    payload_auth_token_key: str | None = field(default=None) # Mandatory if TOKEN_PAYLOAD

    # Tokenization Configuration
    tokenized_fields: list[str] | None = field(default=None)
    
    # Rate limiting
    rate_limit: str|None = None  # "user", "ip", "endpoint", or None
    rate_limit_value: int = 100  # Requests per window
    rate_limit_window: int = DEFAULT_RATE_LIMIT_WINDOW
    
    # Idempotency & deduplication
    idempotent: bool = False  # Prevent duplicate processing
    idempotency_window: int = DEFAULT_IDEMPOTENCY_WINDOW
    deduplicate: bool = False  # Deduplicate within shorter window
    dedupe_window: int = DEFAULT_DEDUPE_WINDOW
    
    # Input validation - NOW SUPPORTS CUSTOM VALIDATORS
    required_params: list[str] = field(default_factory=list)
    param_constraints: dict[str, Union[dict, Callable]] = field(default_factory=dict)
    # Example: {"email": {"type": "email", "max_length": 254}}
    # Or with builder: {"email": constraints.email(max_length=254, domain="company.com")}
    
    # CSRF protection
    csrf_required: bool = False  # Required for state-changing methods
    
    # Request limits
    max_request_size: int = DEFAULT_MAX_REQUEST_SIZE
    
    # Security headers
    security_level: SecurityLevel = SecurityLevel.MEDIUM
    custom_headers: dict[str, str] | None = field(default=None)

    # Scopes (Fine-grained permissions)
    required_scopes: list[str] = field(default_factory=list)

    # Revocation check (Logout support)
    check_revocation: bool = True

    # API Key Configuration
    header_auth_key_name: Union[AuthHeader, str, None] = field(default=None)

    @property
    def auth_token_key(self) -> str | None:
        """Alias for payload_auth_token_key (backward compatibility)."""
        return self.payload_auth_token_key

    @auth_token_key.setter
    def auth_token_key(self, value: str | None) -> None:
        self.payload_auth_token_key = value


    csrf_protected: bool = False  # Whether to require CSRF
    csrf_token_type: str = "csrf"  # Which token type to use for CSRF
    csrf_in_cookie: bool = True  # Whether to expect CSRF in cookie
    csrf_in_header: bool = True   # Whether to expect CSRF in header
    
    @classmethod
    def public(cls) -> 'GateConfig':
        """Factory for public endpoints (no auth, IP-based rate limiting)."""
        return cls(
            auth_required=False,
            auth_type=AuthType.NONE,
            rate_limit="ip",
            csrf_required=False,
            security_level=SecurityLevel.LOW,
            tokenized_fields=None
        )
    
    @classmethod
    def admin(cls) -> 'GateConfig':
        """Factory for admin endpoints (strict security)."""
        return cls(
            auth_required=True,
            auth_type=AuthType.BEARER,
            user_tiers=["admin"],
            rate_limit="user",
            rate_limit_value=50,  # Stricter limit for admin
            csrf_required=True,
            security_level=SecurityLevel.HIGH,
            tokenized_fields=None
        )

    @classmethod
    def with_csrf(cls, auth_type: AuthType = AuthType.TOKEN_PAYLOAD) -> 'GateConfig':
        """Factory for endpoints requiring both auth and CSRF."""
        return cls(
            auth_required=True,
            auth_type=auth_type,
            csrf_protected=True,  # CSRF required
            tokenized_fields=None
        )


class GateResult:
    """Result of gate execution with detailed error information."""
    
    def __init__(self, success: bool, error: dict|None = None, 
                 context: RequestContext|None = None):
        self.success = success
        self.error = error or {}
        self.context = context
        
        # Add default error structure
        if not success and not error:
            self.error = {
                "code": "gate_failed",
                "message": "Gate validation failed",
                "timestamp": time.time()
            }
    
    @classmethod
    def success(cls, context: RequestContext) -> 'GateResult':
        """Factory for successful result."""
        return cls(True, context=context)
    
    @classmethod
    def error(cls, code: str, message: str, context: RequestContext|None = None,
              details: dict = None, http_code: int = 400) -> 'GateResult':
        """Factory for error result with consistent structure."""
        error = {
            "code": code,
            "message": message,
            "timestamp": time.time(),
            "http_code": http_code
        }
        if details:
            error["details"] = details
        return cls(False, error=error, context=context)


# ============================================================================
# BASE GATE CLASS
# ============================================================================

class BaseGate:
    """
    Abstract base class for all gates.
    
    IMPLEMENTATION NOTE: Gates should be stateless and thread-safe.
    Any state should be stored in RequestContext or external services.
    """
    
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        """Determine if this gate should run for the given request."""
        return True
    
    def execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        """
        Execute the gate's security logic.
        
        CRITICAL: This method should never raise exceptions.
        All errors should be captured and returned as GateResult.
        """
        try:
            start_time = time.time()
            
            # Check if gate should run
            if not self.should_run(config, context):
                context.add_audit_event(
                    f"gate_skipped_{self.name}", 
                    "Gate skipped based on configuration",
                    SecurityLevel.LOW
                )
                return GateResult.success(context)
            
            # Execute gate logic
            result = self._execute(context, config)
            
            # Record timing
            context.measure_gate_time(self.name, start_time)
            
            # Add audit event
            event_type = f"gate_{'passed' if result.success else 'failed'}_{self.name}"
            context.add_audit_event(
                event_type,
                f"Gate {self.name} {'passed' if result.success else 'failed'}",
                SecurityLevel.HIGH if not result.success else SecurityLevel.MEDIUM
            )
            
            return result
            
        except Exception as e:
            # CRITICAL: Catch all exceptions to prevent pipeline crash
            context.add_audit_event(
                f"gate_error_{self.name}",
                f"Unhandled exception: {str(e)}",
                SecurityLevel.HIGH
            )

            logger.error("Unhandled exception in gate '%s': %s", self.name, e)
            return GateResult.error(
                "gate_internal_error",
                f"Internal gate error: {self.name}",
                context,
                {"exception": str(e)}
            )
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        """Override this method with actual gate logic."""
        raise NotImplementedError("Gate must implement _execute method")
    

# ============================================================================
# SECURITY GATES IMPLEMENTATION
# ============================================================================

class RequestSizeGate(BaseGate):
    """Enforces maximum request size to prevent memory exhaustion attacks."""
    
    def __init__(self):
        super().__init__("request_size", "Enforce maximum request size")
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return config.max_request_size > 0
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        if context.content_length > config.max_request_size:
            context.add_security_flag("request_size_exceeded")
            return GateResult.error(
                "request_too_large",
                f"Request size ({context.content_length} bytes) exceeds limit "
                f"({config.max_request_size} bytes)",
                context
            )
        
        return GateResult.success(context)


class AuthenticationGate(BaseGate):
    """Validates user authentication tokens."""
    
    def __init__(self, token_manager: TokenManager):
        super().__init__("authentication", "Validate user authentication")
        self.token_manager = token_manager
        
        # Token handlers by auth type
        self._handlers = {
            AuthType.BEARER: self._handle_bearer,
            AuthType.API_KEY: self._handle_api_key,
            AuthType.BASIC: self._handle_basic,
            AuthType.TOKEN_PAYLOAD: self._handle_payload,
            AuthType.NONE: self._handle_none
        }
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return config.auth_required
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        handler = self._handlers.get(config.auth_type)
        if not handler:
            return GateResult.error(
                "unsupported_auth_type",
                f"Unsupported authentication type: {config.auth_type}",
                context
            )
        
        return handler(context, config)
    
    def _process_token(self, context: RequestContext, token: str, token_type: str, config: GateConfig) -> GateResult:
        """Process and validate a token using the new validation protocol."""
        # The 'Key' returns a TokenValidationResult
        result = self.token_manager.unlock_session_token(token=token, token_type=token_type)
        
        # Decision: If no result or explicitly inactive, unlock fails
        if not result or not result.is_active:
            context.add_security_flag("invalid_token")
            context.add_audit_event(
                "auth_failed",
                f"Invalid {token_type} token",
                SecurityLevel.HIGH
            )
            
            # Map machine types to user-friendly messages
            error_messages = {
                AuthType.BASIC: "Invalid username or password",
                AuthType.API_KEY: "Invalid API key credentials",
                AuthType.BEARER: "Invalid or expired bearer token",
                AuthType.TOKEN_PAYLOAD: "Invalid or expired token payload"
            }
            msg = error_messages.get(token_type, "Invalid or expired credentials")

            return GateResult.error(
                "auth_failed",
                msg,
                context
            )
        
        context.set("session_identity_raw", result.initial_value, "authentication")
        
        # Identity Discovery Hierarchy (v0.1.6 Final)
        # We look for identities in this order of precedence:
        # 1. Your custom payload authentication key name
        # 2. Standard ID names
        # 3. Standard OIDC 'sub' (subject) field
        # 4. Fallback: The initial raw value locked in the token
        identity = (
            result.metadata.get(config.payload_auth_token_key) if config.payload_auth_token_key else None
        ) or (
            result.metadata.get("user_id") or 
            result.metadata.get("userId") or 
            result.metadata.get("sub") or 
            result.initial_value
        )
        
        if identity is not None:
            context.set("identity", identity, "auth_injection")
            # For backward compatibility, also populate context.user
            context.user = {
                "identity": identity,
                "token": token,
                "auth_time": time.time(),
                "auth_type": token_type,
                **(result.metadata or {})
            }
            
            # Record success
            context.add_audit_event(
                "auth_success",
                f"Identity authenticated: {identity}",
                SecurityLevel.MEDIUM
            )
        
        return GateResult.success(context)
    
    def _handle_bearer(self, context: RequestContext, config: GateConfig) -> GateResult:
        h_name = str(config.header_auth_key_name) if config.header_auth_key_name else "Authorization"
        auth_header = context.request.headers.get(h_name, "")
        
        # Check for 'Bearer ' prefix
        if not auth_header.startswith("Bearer "):
            # This is helpful for people who just send it as a plain header.
            if config.header_auth_key_name and auth_header:
                token = auth_header.strip()
            else:
                return GateResult.error(
                    "invalid_auth_header",
                    f"Authentication at '{h_name}' must start with 'Bearer ' prefix",
                    context
                )
        else:
            token = auth_header[7:].strip()
        if not token:
            return GateResult.error(
                "missing_token",
                "Bearer token is empty",
                context
            )
        
        return self._process_token(context, token, AuthType.BEARER, config)
    
    def _handle_api_key(self, context: RequestContext, config: GateConfig) -> GateResult:
        # First, validate the configuration itself if provided
        if config.header_auth_key_name:
            # Use structure validator to check runtime validity of the option
            from ..customTypes import Options
            val_res = validate(config.header_auth_key_name, Options[str, ["X-API-Key", "X-Api-Key", "Api-Key"]])
            if not val_res:
                return GateResult.error(
                    "invalid_config",
                    f"Configuration Error: {val_res.log}",
                    context
                )
        
        # Extract the key name (support both Enum member and raw string)
        h_name = config.header_auth_key_name
        header_names = [str(h_name)] if h_name else ["X-API-Key", "X-Api-Key", "Api-Key"]
        api_key = None
        
        for header in header_names:
            api_key = context.request.headers.get(header)
            if api_key:
                break
        
        if not api_key:
            return GateResult.error(
                "missing_api_key",
                f"API key required in one of: {', '.join(header_names)}",
                context
            )
        
        return self._process_token(context, api_key, AuthType.API_KEY, config)
    
    def _handle_basic(self, context: RequestContext, config: GateConfig) -> GateResult:
        auth = context.request.authorization
        if not auth or not auth.username or not auth.password:
            return GateResult.error(
                "missing_basic_auth",
                "Basic authentication credentials required",
                context
            )
        
        credentials = f"{auth.username}:{auth.password}"
        token = base64.b64encode(credentials.encode()).decode()
        
        return self._process_token(context, token, AuthType.BASIC, config)
    
    def _handle_payload(self, context: RequestContext, config: GateConfig) -> GateResult:
        # This handler expects the token payload to be in the request body (JSON)
        # or as a query parameter, or a header.
        # The 'payload_auth_token_key' in GateConfig specifies the key for the token payload.
        
        req = context.request
        
        if not config.payload_auth_token_key:
            return GateResult.error(
                "missing_config",
                "auth_type=TOKEN_PAYLOAD requires payload_auth_token_key to be defined in GateConfig",
                context
            )
        
        token = None
        source = "unknown"
        
        # Check JSON body
        if req.is_json:
            json_data = req.get_json(silent=True) or {}
            token = json_data.get(config.payload_auth_token_key)
            if token:
                source = "JSON body"
        
        # Check form data
        if not token and req.form:
            token = req.form.get(config.payload_auth_token_key)
            if token:
                source = "form data"
        
        # Check query parameters
        if not token and req.args:
            token = req.args.get(config.payload_auth_token_key)
            if token:
                source = "query parameter"
        
        # Check headers (e.g., X-Auth-Token)
        if not token:
            token = req.headers.get(config.payload_auth_token_key)
            if token:
                source = "header"
        
        if not token:
            return GateResult.error(
                "missing_token_payload",
                f"Token payload required in field/header: '{config.payload_auth_token_key}'",
                context
            )
        
        context.add_audit_event("auth_payload_identified", f"Payload identifier found in {source}", SecurityLevel.LOW)
        return self._process_token(context, token, AuthType.TOKEN_PAYLOAD, config)
    
    def _handle_none(self, context: RequestContext, config: GateConfig) -> GateResult:
        context.user = {"auth_type": "none", "auth_time": time.time()}
        return GateResult.success(context)


class CSRFGate(BaseGate):
    """Cross-Site Request Forgery protection."""
    
    def __init__(self, token_manager: TokenManager, storage):
        super().__init__("csrf", "Cross-Site Request Forgery protection")
        self.token_manager = token_manager
        self.storage = storage
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        if not config.csrf_protected:
            return False
        
        method = context.request.method.upper()
        return method in HttpMethod.STATE_CHANGING
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        if not context.user:
            return GateResult.success(context)
        
        identity = context.get("session_identity_raw")
        if identity is None:
            return GateResult.success(context)
        
        csrf_token = self._extract_csrf_token(context, config)
        
        if not csrf_token:
            return GateResult.error(
                "missing_csrf_token",
                "CSRF token required for this endpoint",
                context,
                {"expected_in": self._get_expected_locations(config)}
            )
        
        result = self.token_manager.unlock_session_token(token=csrf_token, token_type="csrf")
        
        if not result or not result.is_active:
            context.add_security_flag("invalid_csrf")
            context.add_audit_event(
                "csrf_failed",
                f"Invalid CSRF token for identity {identity}",
                SecurityLevel.HIGH
            )
            return GateResult.error(
                "invalid_csrf_token",
                "Invalid or expired CSRF token",
                context
            )
        
        if str(result.initial_value) != str(identity):
            return GateResult.error(
                "csrf_identity_mismatch",
                "CSRF token does not match authenticated identity",
                context
            )
        
        return GateResult.success(context)
    
    def _extract_csrf_token(self, context: RequestContext, config: GateConfig) -> str|None:
        if config.csrf_in_header:
            token = (
                context.request.headers.get("X-CSRF-Token") or
                context.request.headers.get("X-XSRF-Token")
            )
            if token:
                return token
        
        if config.csrf_in_cookie:
            token = context.request.cookies.get("csrf_token")
            if token:
                return token
        
        if context.request.form:
            return context.request.form.get("csrf_token")
        
        return None
    
    def _get_expected_locations(self, config: GateConfig) -> list[str]:
        locations = []
        if config.csrf_in_header:
            locations.append("X-CSRF-Token header")
        if config.csrf_in_cookie:
            locations.append("csrf_token cookie")
        locations.append("csrf_token form field")
        return locations


class ValidationGate(BaseGate):
    """
    Validates request parameters using registered custom validators.
    
    This gate has NO built-in validation logic. All validation is performed
    by functions registered with @register_validator decorator.
    """
    
    def __init__(self):
        super().__init__("validation", "Validate request parameters using custom validators")
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return bool(config.required_params) or bool(config.param_constraints)
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        # Collect data from all sources (v0.1.5 dynamic config)
        data = self._collect_request_data(context, config)
        
        # Check required parameters
        missing = [p for p in config.required_params if p not in data]
        if missing:
            return GateResult.error(
                "missing_parameters",
                f"Required parameters missing: {', '.join(missing)}",
                context,
                {"missing": missing}
            )
        
        # Validate and sanitize each parameter
        validated_data = {}
        errors = []
        
        for param_name, value in data.items():
            # Get constraints for this parameter
            constraints = config.param_constraints.get(param_name, {})
            
            # If constraints is a callable (builder result), it's already a dict
            if callable(constraints):
                constraints = constraints()
            
            # Validate
            result = self._validate_parameter(param_name, value, constraints, context)

            if result["valid"]:
                validated_data[param_name] = result["value"]
            else:
                errors.append({
                    "parameter": param_name,
                    "error": result["error"],
                    "value": str(value)[:100]  # Truncate for security
                })
        
        if errors:
            return GateResult.error(
                "validation_failed",
                "Parameter validation failed",
                context,
                {"errors": errors}
            )
        
        # Store validated data
        context.validated_data = validated_data
        
        return GateResult.success(context)
    
    def _collect_request_data(self, context: RequestContext, config: GateConfig) -> dict:
        """Collect data from all request sources, prioritizing unmasked values."""
        data = {}
        
        # JSON body
        if context.request.is_json:
            json_data = context.request.get_json(silent=True) or {}
            data.update(json_data)
        
        # Form data
        if context.request.form:
            if hasattr(context.request.form, 'to_dict'):
                data.update(context.request.form.to_dict())
            else:
                data.update(context.request.form)
        
        # Query parameters
        if context.request.args:
            if hasattr(context.request.args, 'to_dict'):
                data.update(context.request.args.to_dict())
            else:
                data.update(context.request.args)
        
        # Headers (specific ones only)
        header_params = ["user_id", "client_id", "correlation_id"]
        for param in header_params:
            header_value = context.request.headers.get(f"X-{param.replace('_', '-')}")
            if header_value and param not in data:
                data[param] = header_value
        
        # Symmetrical Identity Injection (v0.1.6)
        # If we successfully unmasked a session, inject it into the developer's data
        # using the name they configured (payload_auth_token_key).
        identity = context.get("session_identity_raw")
        injection_key = config.payload_auth_token_key or "identity"
        
        if identity is not None and injection_key not in data:
            data[injection_key] = identity
            # (No need to log here - already logged during unmasking)

        # OVERRIDE with unmasked values from DataUnmaskingGate if they exist
        # This ensures the handler gets '1234' instead of 'tok_1234'
        for key in list(data.keys()):
            unmasked = context.get(f"unmasked_{key}")
            if unmasked is not None:
                data[key] = unmasked
        
        return data
    
    def _validate_parameter(
        self, name: str, value: Any, 
        constraints: dict, context: RequestContext
    ) -> dict:
        """Validate a single parameter using registered validator."""
        
        # Get validator type
        validator_type = constraints.get("type")
        if not validator_type:
            # No validator specified - treat as valid
            return {
                "valid": True,
                "value": value,
                "error": None
            }
        
        # Check if parameter is optional and missing
        if constraints.get("optional", False) and value is None:
            return {
                "valid": True,
                "value": None,
                "error": None
            }
        
        # Get validator function from registry
        validator = ValidatorRegistry.get_validator(validator_type)
        if not validator:
            return {
                "valid": False,
                "error": f"Unknown validator type: {validator_type}",
                "value": value
            }
        
        # Run validation - pass all constraints as kwargs
        try:
            # Remove 'type' and 'optional' from kwargs since validator knows its type
            kwargs = {k: v for k, v in constraints.items() 
                     if k not in ('type', 'optional')}
            validated_value = validator(value, **kwargs)
            
            return {
                "valid": True,
                "value": validated_value,
                "error": None
            }
        except ValueError as e:
            return {
                "valid": False,
                "error": str(e),
                "value": value
            }
        except Exception as e:
            return {
                "valid": False,
                "error": f"Validation error: {str(e)}",
                "value": value
            }


class DataUnmaskingGate(BaseGate):
    """
    Automatically unmasks fields found in the tokenized_fields list.
    Ensures the developer handler sees raw data while the client sees tokens.
    """
    
    def __init__(self, token_manager: TokenManager):
        super().__init__("data_unmasking", "Automatically unmask highly sensitive fields")
        self.token_manager = token_manager
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        # Run if any fields are listed for tokenization
        return bool(config.tokenized_fields)
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        # Collect request data (pre-validation) with current config
        temp_val_gate = ValidationGate()
        data = temp_val_gate._collect_request_data(context, config)
        
        unmasked_count = 0
        for field_name in config.tokenized_fields:
            if field_name in data:
                token_value = data[field_name]
                try:
                    # Attempt to unlock the padlock
                    raw_value = self.token_manager.unmask_data(str(token_value))
                    # Inject unmasked value into context for ValidationGate to find
                    context.set(f"unmasked_{field_name}", raw_value, "automatic_unmasking")
                    unmasked_count += 1
                except Exception as e:
                    # If it's in tokenized_fields, it MUST be a valid token
                    return GateResult.error(
                        "invalid_data_token",
                        f"Field '{field_name}' must be a valid masked token",
                        context,
                        {"field": field_name, "error": str(e)}
                    )
        
        if unmasked_count > 0:
            context.add_audit_event(
                "data_unmasked",
                f"Successfully unmasked {unmasked_count} fields",
                SecurityLevel.MEDIUM
            )
            
        return GateResult.success(context)


class RateLimitGate(BaseGate):
    """Rate limiting with atomic operations to prevent race conditions."""
    
    def __init__(self, storage):
        super().__init__("rate_limit", "Enforce rate limits")
        self.storage = storage
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return config.rate_limit is not None
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        key = self._generate_key(context, config)
        
        try:
            current = self._atomic_increment(key, config.rate_limit_window)
        except NotImplementedError:
            current = self._increment_with_lock(key, config.rate_limit_window)
        
        if current > config.rate_limit_value:
            context.add_security_flag("rate_limit_exceeded")
            context.add_audit_event(
                "rate_limit_exceeded",
                f"Rate limit exceeded for key: {key}",
                SecurityLevel.HIGH
            )
            return GateResult.error(
                "rate_limit_exceeded",
                f"Rate limit exceeded. Try again in {config.rate_limit_window} seconds.",
                context,
                {
                    "limit": config.rate_limit_value,
                    "window": config.rate_limit_window,
                    "current": current
                }
            )
        
        return GateResult.success(context)
    
    def _generate_key(self, context: RequestContext, config: GateConfig) -> str:
        timestamp = int(time.time() / config.rate_limit_window)
        
        if config.rate_limit == "user":
            raw_id = context.get("session_identity_raw")
            if raw_id is not None:
                return f"rl:u:{raw_id}:{timestamp}"
            
            # Fallback to IP if no identity found
            ip = context.client_ip or "unknown"
            return f"rl:i:{ip}:{timestamp}"
        
        elif config.rate_limit == "endpoint":
            return f"rl:e:{context.request.path}:{timestamp}"
        elif config.rate_limit == "ip":
            ip = context.client_ip or "unknown"
            return f"rl:i:{ip}:{timestamp}"
        else:
            ip = context.client_ip or "unknown"
            return f"rl:i:{ip}:{timestamp}"
    
    def _atomic_increment(self, key: str, ttl: int) -> int:
        if hasattr(self.storage, 'atomic_increment'):
            return self.storage.atomic_increment(key, ttl)
        raise NotImplementedError("Storage doesn't support atomic increment")
    
    def _increment_with_lock(self, key: str, ttl: int) -> int:
        lock_key = f"lock:{key}"
        
        for _ in range(10):
            if self.storage.set(lock_key, "1", ttl=1):
                try:
                    current = self.storage.get(key, 0)
                    new_value = current + 1
                    self.storage.set(key, new_value, ttl=ttl)
                    return new_value
                finally:
                    self.storage.delete(lock_key)
                break
            
            time.sleep(0.1)
        
        return self.storage.get(key, 0) + 1


class UserTierGate(BaseGate):
    """Role-Based Access Control (RBAC) enforcement."""
    
    def __init__(self):
        super().__init__("user_tier", "Enforce user tier/role requirements")
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return bool(config.user_tiers) and config.auth_required
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        if not context.user:
            return GateResult.success(context)
        
        user_tiers = context.user.get("tiers", []) or context.user.get("roles", []) or []
        
        has_access = any(tier in user_tiers for tier in config.user_tiers)
        
        if not has_access:
            context.add_security_flag("insufficient_privileges")
            context.add_audit_event(
                "access_denied",
                f"User lacks required tiers. Has: {user_tiers}, Needs: {config.user_tiers}",
                SecurityLevel.HIGH
            )
            return GateResult.error(
                "insufficient_privileges",
                f"Access denied. Required tier(s): {', '.join(config.user_tiers)}",
                context,
                {
                    "user_tiers": user_tiers,
                    "required_tiers": config.user_tiers
                }
            )
        
        return GateResult.success(context)


class ScopeGate(BaseGate):
    """Fine-grained permission enforcement (Scopes)."""
    
    def __init__(self):
        super().__init__("scope", "Enforce granular scope permissions")
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return bool(config.required_scopes) and config.auth_required
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        if not context.user:
            return GateResult.success(context)
        
        # Scopes are expected to be a list in the 'scopes' field of context.user
        user_scopes = context.user.get("scopes", [])
        if isinstance(user_scopes, str):
            # Handle space-separated string (standard OAuth2 style)
            user_scopes = user_scopes.split()
            
        # Check if user has ALL required scopes
        missing_scopes = [s for s in config.required_scopes if s not in user_scopes]
        
        if missing_scopes:
            context.add_security_flag("insufficient_scopes")
            context.add_audit_event(
                "access_denied_scopes",
                f"User lacks required scopes. Missing: {missing_scopes}",
                SecurityLevel.HIGH
            )
            return GateResult.error(
                "insufficient_scopes",
                f"Access denied. Missing scope(s): {', '.join(missing_scopes)}",
                context,
                {
                    "user_scopes": user_scopes,
                    "required_scopes": config.required_scopes,
                    "missing": missing_scopes
                }
            )
        
        return GateResult.success(context)


class IdempotencyGate(BaseGate):
    """Idempotency and request deduplication."""
    
    def __init__(self, storage):
        super().__init__("idempotency", "Request idempotency and deduplication")
        self.storage = storage
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return config.idempotent or config.deduplicate
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        idempotency_key = self._generate_idempotency_key(context)
        
        window = config.idempotency_window if config.idempotent else config.dedupe_window
        existing = self.storage.get(idempotency_key)
        
        if existing:
            context.add_security_flag("duplicate_request")
            context.add_audit_event(
                "duplicate_request",
                f"Duplicate request detected: {idempotency_key}",
                SecurityLevel.MEDIUM
            )
            
            if config.idempotent and isinstance(existing, dict) and "response" in existing:
                return GateResult.error(
                    "duplicate_request",
                    "This request was already processed",
                    context,
                    {
                        "idempotency_key": idempotency_key,
                        "previous_response": existing.get("response"),
                        "processed_at": existing.get("timestamp")
                    }
                )
            else:
                return GateResult.error(
                    "duplicate_request",
                    "Duplicate request detected",
                    context,
                    {"idempotency_key": idempotency_key}
                )
        
        marker = {
            "timestamp": time.time(),
            "request_id": context.request_id,
            "identity": context.get("session_identity_raw"),
            "endpoint": context.request.path
        }
        
        self.storage.set(idempotency_key, marker, ttl=window)
        context.set("idempotency_key", idempotency_key, "idempotency_tracking")
        
        return GateResult.success(context)
    
    def _generate_idempotency_key(self, context: RequestContext) -> str:
        idempotency_header = context.request.headers.get("Idempotency-Key")
        if idempotency_header:
            return f"idempotent:{idempotency_header}"
        
        identity = context.get("session_identity_raw") or "anonymous"
        endpoint = context.request.path
        method = context.request.method
        
        request_data = self._get_request_fingerprint(context)
        content = f"{identity}:{endpoint}:{method}:{request_data}".encode()
        hash_value = hashlib.sha256(content).hexdigest()[:16]
        
        return f"idempotent:{hash_value}"
    
    def _get_request_fingerprint(self, context: RequestContext) -> str:
        fingerprint_parts = []
        
        if context.request.args:
            args_dict = dict(sorted(context.request.args.items()))
            fingerprint_parts.append(f"args:{json.dumps(args_dict, sort_keys=True)}")
        
        if context.request.form:
            form_dict = dict(sorted(context.request.form.items()))
            fingerprint_parts.append(f"form:{json.dumps(form_dict, sort_keys=True)}")
        
        if context.request.is_json:
            json_data = context.request.get_json(silent=True) or {}
            if isinstance(json_data, dict):
                json_data.pop("idempotency_key", None)
                json_data.pop("Idempotency-Key", None)
            fingerprint_parts.append(f"json:{json.dumps(json_data, sort_keys=True)[:1024]}")
        
        return hashlib.sha256("|".join(fingerprint_parts).encode()).hexdigest()


class SecurityHeadersGate(BaseGate):
    """Adds security headers to responses."""
    
    def __init__(self):
        super().__init__("security_headers", "Add security headers to responses")
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        return config.security_level != SecurityLevel.LOW
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        headers = {}
        
        if config.security_level in [SecurityLevel.HIGH, SecurityLevel.PARANOID]:
            headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data:; "
                "font-src 'self'; "
                "connect-src 'self'; "
                "frame-ancestors 'none';"
            )
        else:
            headers["Content-Security-Policy"] = "default-src 'self'"
        
        if config.security_level == SecurityLevel.PARANOID:
            headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
        elif config.security_level == SecurityLevel.HIGH:
            headers["Strict-Transport-Security"] = "max-age=31536000"
        
        headers["X-XSS-Protection"] = "1; mode=block"
        headers["X-Frame-Options"] = "DENY"
        headers["X-Content-Type-Options"] = "nosniff"
        
        if config.security_level in [SecurityLevel.HIGH, SecurityLevel.PARANOID]:
            headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        else:
            headers["Referrer-Policy"] = "no-referrer-when-downgrade"
        
        headers["Permissions-Policy"] = (
            "geolocation=(), microphone=(), camera=(), "
            "payment=(), usb=(), magnetometer=(), accelerometer=()"
        )
        
        context.security_headers = headers

        if config.custom_headers:
            context.security_headers.update(config.custom_headers)
        
        return GateResult.success(context)


class TokenRevocationGate(BaseGate):
    """
    Checks if the current session token has been revoked (e.g., via Logout).
    Requires a 'revocation_store' to be present in the context or pipeline.
    """
    
    def __init__(self):
        super().__init__("token_revocation", "Check if token has been revoked")
    
    def should_run(self, config: GateConfig, context: RequestContext) -> bool:
        # Only run if authentication was required and successful, and check is enabled
        return (
            config.auth_required and 
            config.check_revocation and 
            context.user is not None and
            context.user.get("token") is not None
        )
    
    def _execute(self, context: RequestContext, config: GateConfig) -> GateResult:
        token = context.user.get("token")
        
        # Access the revocation store from the context
        # The store is injected into the context by the portal during request start
        store = context.get("revocation_store")
        
        if store and store.is_revoked(token):
            return GateResult.error(
                "token_revoked",
                "This session has been invalidated. Please log in again.",
                context,
                http_code=401
            )
            
        return GateResult.success(context)


# ============================================================================
# GATE PIPELINE
# ============================================================================

class GatePipeline:
    """
    Orchestrates the execution of security gates.
    
    CRITICAL: Gate order matters. Follows security best practices:
    1. Request size limits (early rejection)
    2. Authentication (who are you?)
    3. CSRF protection (prevent forged requests)
    4. Validation (what are you sending?) - NOW USES CUSTOM VALIDATORS
    5. Rate limiting (how often are you sending?)
    6. User tiers (what are you allowed to do?)
    7. Idempotency (prevent duplicates)
    8. Security headers (browser protections)
    """
    
    def __init__(self, token_manager: TokenManager, storage, revocation_store=None):
        self.token_manager = token_manager
        self.storage = storage
        self.revocation_store = revocation_store
        
        # Initialize gates in security-optimal order
        self.gates = [
            RequestSizeGate(),
            AuthenticationGate(self.token_manager),
            TokenRevocationGate(), # Check if token was explicitly revoked (logout)
            DataUnmaskingGate(self.token_manager), # New: Auto-unlock tokens
            CSRFGate(self.token_manager, self.storage),
            ValidationGate(),  # Now uses custom validators
            RateLimitGate(self.storage),
            UserTierGate(),
            ScopeGate(),
            IdempotencyGate(self.storage),
            SecurityHeadersGate()
        ]
        
        # Performance monitoring
        self.stats = {
            "total_requests": 0,
            "failed_requests": 0,
            "gate_failures": {},
            "avg_processing_time": 0
        }
    
    def process(self, request, config: GateConfig) -> GateResult:
        """
        Process a request through the security pipeline.
        
        Args:
            request: Flask request object
            config: Gate configuration for this endpoint
            
        Returns:
            GateResult with success/failure and context
        """
        start_time = time.time()
        self.stats["total_requests"] += 1
        
        # Create request context
        context = RequestContext(request)
        if self.revocation_store:
            context.set("revocation_store", self.revocation_store)
        
        # Add request to audit log
        context.add_audit_event(
            "request_start",
            f"{request.method} {request.path}",
            SecurityLevel.LOW
        )
        
        # Execute gates in order
        for gate in self.gates:
            gate_start = time.time()
            
            # Convert any callable constraints to dicts before passing to gate
            if hasattr(config, 'param_constraints') and config.param_constraints:
                # Create a copy with converted constraints
                import copy
                converted_config = copy.copy(config)
                converted_config.param_constraints = {}
                for param_name, constraint in config.param_constraints.items():
                    if callable(constraint):
                        # It's a builder function - call it to get dict
                        converted_config.param_constraints[param_name] = constraint()
                    else:
                        converted_config.param_constraints[param_name] = constraint
            else:
                converted_config = config
            
            result = gate.execute(context, converted_config)
            
            # Record gate timing
            context.measure_gate_time(gate.name, gate_start)
            
            # Stop on first failure
            if not result.success:
                self.stats["failed_requests"] += 1
                self.stats["gate_failures"][gate.name] = \
                    self.stats["gate_failures"].get(gate.name, 0) + 1
                
                context.add_audit_event(
                    "request_failed",
                    f"Gate '{gate.name}' failed: {result.error.get('code', 'unknown')}",
                    SecurityLevel.HIGH
                )
                
                total_time = time.time() - start_time
                self._update_processing_time(total_time)
                
                return result
        
        # All gates passed
        total_time = time.time() - start_time
        self._update_processing_time(total_time)
        
        context.add_audit_event(
            "request_passed",
            f"All security gates passed in {total_time:.3f}s",
            SecurityLevel.LOW
        )
        
        return GateResult.success(context)
    
    def _update_processing_time(self, processing_time: float):
        """Update average processing time (exponential moving average)."""
        alpha = 0.1
        self.stats["avg_processing_time"] = (
            alpha * processing_time + 
            (1 - alpha) * self.stats["avg_processing_time"]
        )
    
    def get_stats(self) -> dict:
        """Get pipeline statistics."""
        return {
            **self.stats,
            "gate_count": len(self.gates),
            "gate_names": [gate.name for gate in self.gates],
            "registered_validators": ValidatorRegistry.get_all_types()
        }
    
    def add_gate(self, gate: BaseGate, position: int|None = None):
        """Add a custom gate to the pipeline."""
        if position is None:
            self.gates.append(gate)
        else:
            self.gates.insert(position, gate)
    
    def remove_gate(self, gate_name: str):
        """Remove a gate from the pipeline."""
        self.gates = [gate for gate in self.gates if gate.name != gate_name]

    def protect_gate(self, gate_name: str, circuit_config: dict | None = None) -> bool:
        """
        Wrap an existing gate in the pipeline with a CircuitProtectedGate.

        Finds the gate by *gate_name*, dynamically creates a protected subclass
        that mixes in CircuitProtectedGate, and swaps it in-place.  The gate's
        position in the pipeline is preserved.

        Args:
            gate_name:      The ``name`` attribute of the gate to protect
                            (e.g. ``"authentication"``, ``"rate_limit"``).
            circuit_config: Optional CircuitBreaker kwargs, e.g.
                            ``{'failure_threshold': 3, 'recovery_timeout': 60}``.

        Returns:
            True if the gate was found and replaced, False if not found.

        Example:
            pipeline = GatePipeline(token_manager, storage)
            pipeline.protect_gate("authentication", {"failure_threshold": 3})
        """
        from .breaker import CircuitProtectedGate  # avoid circular import at module level

        for i, gate in enumerate(self.gates):
            if gate.name != gate_name:
                continue

            # Dynamically build: class Protected_<Gate>(CircuitProtectedGate, <Gate>): pass
            protected_cls = type(
                f"Protected_{type(gate).__name__}",
                (CircuitProtectedGate, type(gate)),
                {},
            )

            # Re-initialise using the original gate's __dict__ as a base, then
            # overlay with the circuit mixin.  We copy public state so the new
            # instance behaves identically to the old one.
            protected = object.__new__(protected_cls)
            protected.__dict__.update(gate.__dict__)          # copy gate state
            CircuitProtectedGate.__init__(                    # attach the circuit
                protected, circuit_config=circuit_config
            )

            self.gates[i] = protected
            logger.info(
                "GatePipeline: gate '%s' wrapped with CircuitProtectedGate "
                "(threshold=%s)",
                gate_name,
                (circuit_config or {}).get("failure_threshold", 5),
            )
            return True

        logger.warning("GatePipeline.protect_gate: gate '%s' not found.", gate_name)
        return False
    
    def verify_integrity(self, config: GateConfig) -> None:
        """
        Severe Bootstrap Integrity Check (v0.1.0).
        Enforces a 'Zero Holes' security model.
        """
        from ..tokens import TokenRegistry
        
        # Check 1: Session Key Explicitness
        # Rule: Any session-based auth MUST define a payload_auth_token_key for handed-off masking
        if config.auth_required and config.auth_type != AuthType.NONE:
            if not config.payload_auth_token_key:
                raise RuntimeError(
                    f"Security Integrity Failure: Auth type '{config.auth_type}' "
                    "requires 'payload_auth_token_key' to be defined in GateConfig. "
                    "This key is necessary for transparent token handover."
                )
        
        # Check 2: Unmasker Correctness
        if config.auth_required and config.auth_type != AuthType.NONE:
            unmasker = TokenRegistry.get_session_unmasker(config.auth_type)
            if not unmasker:
                raise RuntimeError(
                    f"Security Integrity Failure: No session_unmasker found "
                    f"for auth_type '{config.auth_type}'. Server cannot start."
                )
        
        # Check 3: Data Security Consistency
        if config.tokenized_fields:
            if not TokenRegistry.get_data_tokenizer() or not TokenRegistry.get_data_detokenizer():
                raise RuntimeError(
                    f"Security Integrity Failure: Tokenized fields used but "
                    "no data masker/unmasker is registered in TokenRegistry."
                )

    def get_audit_log(self, request_id: str) -> list[dict]:
        """Retrieve audit log for a specific request."""
        return []


# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    'AuthType',
    'SecurityLevel',
    'RequestContext',
    'GateConfig',
    'GateResult',
    'BaseGate',
    'GatePipeline',
    'register_validator',
    'constraints',
    'ValidatorRegistry'
]