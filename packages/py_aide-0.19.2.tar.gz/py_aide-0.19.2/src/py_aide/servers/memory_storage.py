import threading
import time
import heapq
import logging
from typing import Any, Optional, Dict, List, Tuple

logger = logging.getLogger(__name__)

class MemoryStorage:
    """
    A thread-safe, size-limited, time-aware key-value store 
    with efficient expiration tracking.
    """
    
    def __init__(
        self, 
        cleanup_interval: int = 60,
        max_size: int|None = 10_000,
        enable_background_cleanup: bool = True
    ):
        """
        Args:
            cleanup_interval: How often (in seconds) the background janitor runs.
            max_size: Maximum number of items to store (None for unlimited).
            enable_background_cleanup: Whether to run background cleanup thread.
        """
        self._data: dict[str, any] = {}
        self._expires: dict[str, float] = {}
        # Min-heap for efficient expiration tracking (expiry_time, key)
        self._expiry_heap: list[tuple[float, str]] = []
        self._max_size = max_size
        self._size = 0
        self._lock = threading.RLock()  # Reentrant lock for nested calls
        self._cleanup_enabled = enable_background_cleanup
        self._stop_event = threading.Event()
        
        # Only start background thread if enabled
        if self._cleanup_enabled:
            self._cleanup_thread = threading.Thread(
                target=self._background_janitor, 
                args=(cleanup_interval,),
                daemon=True,
                name="MemoryStorage-Janitor"
            )
            # Don't start immediately - let the app control lifecycle
            self._started = False

    def start(self):
        """Start the background cleanup thread."""
        if self._cleanup_enabled and not self._started:
            self._cleanup_thread.start()
            self._started = True
    
    def stop(self):
        """Stop the background cleanup thread."""
        if self._cleanup_enabled:
            self._stop_event.set()
            if self._cleanup_thread.is_alive():
                self._cleanup_thread.join(timeout=5.0)

    def _background_janitor(self, interval: int):
        """Background thread that periodically cleans expired items."""
        while not self._stop_event.is_set():
            # Wait for interval or stop signal
            self._stop_event.wait(interval)
            if not self._stop_event.is_set():
                self.flush_expired()

    def get(self, key: str, default: any = None) -> any:
        """
        Retrieves value; deletes it first if the TTL has expired.
        
        Returns:
            The value if found and not expired, otherwise default.
        """
        with self._lock:
            # Check expiration first (atomic operation)
            if self._is_expired(key):
                self._delete_internal(key)
                return default
            
            return self._data.get(key, default)

    def set(self, key: str, value: any, ttl: int|None = None) -> bool:
        """
        Stores a value with an optional lifespan (TTL).
        
        Returns:
            True if successful, False if max size reached (and no eviction policy).
        """
        with self._lock:
            # Check if we need to make room
            if (self._max_size is not None and 
                key not in self._data and 
                self._size >= self._max_size):
                # Apply LRU eviction policy (simple implementation)
                if not self._evict_oldest():
                    return False  # Could not make room
            
            # Track if this is a new key before writing
            is_new = key not in self._data
            
            # Store the value
            self._data[key] = value
            
            # Update size counter (only if new key)
            if is_new:
                self._size += 1
            
            # Set expiration if TTL provided
            if ttl:
                expiry_time = time.time() + ttl
                self._expires[key] = expiry_time
                heapq.heappush(self._expiry_heap, (expiry_time, key))
            elif key in self._expires:
                # Remove expiration if TTL is None/0
                del self._expires[key]
                # Note: The key will remain in heap but will be ignored on cleanup
                
            return True

    def delete(self, key: str) -> bool:
        """Delete a key if it exists."""
        with self._lock:
            return self._delete_internal(key)
    
    def _delete_internal(self, key: str) -> bool:
        """Internal delete without lock (caller must hold lock)."""
        if key in self._data:
            del self._data[key]
            if key in self._expires:
                del self._expires[key]
                # Note: We don't remove from heap here - cleanup will handle it
            self._size -= 1
            return True
        return False

    def _is_expired(self, key: str) -> bool:
        """Check if a key has expired (assumes caller holds lock)."""
        if key not in self._expires:
            return False
        return time.time() > self._expires[key]

    def _evict_oldest(self) -> bool:
        """
        Evict the oldest expired item, or if none expired, the item 
        closest to expiration.
        
        Returns:
            True if an item was evicted, False otherwise.
        """
        now = time.time()
        
        # First try to evict an expired item
        while self._expiry_heap and self._expiry_heap[0][0] <= now:
            expiry_time, key = heapq.heappop(self._expiry_heap)
            if key in self._expires and self._expires[key] == expiry_time:
                # Still valid (not manually deleted)
                self._delete_internal(key)
                return True
        
        # If no expired items, evict the one closest to expiration
        if self._expiry_heap:
            _, key_to_evict = self._expiry_heap[0]
            self._delete_internal(key_to_evict)
            # Remove from heap
            heapq.heappop(self._expiry_heap)
            return True
            
        return False

    def flush_expired(self) -> int:
        """
        Active cleanup: removes all expired items.
        
        Returns:
            Number of items cleaned up.
        """
        with self._lock:
            cleaned = 0
            now = time.time()
            
            # Process heap until we find unexpired items
            while self._expiry_heap and self._expiry_heap[0][0] <= now:
                expiry_time, key = heapq.heappop(self._expiry_heap)
                
                # Verify it hasn't been manually deleted or had TTL changed
                if (key in self._expires and 
                    self._expires[key] == expiry_time and 
                    now > expiry_time):
                    self._delete_internal(key)
                    cleaned += 1
                # If TTL was updated, the key will have new entry in heap
            
            return cleaned

    def clear(self):
        """Clear all data."""
        with self._lock:
            self._data.clear()
            self._expires.clear()
            self._expiry_heap.clear()
            self._size = 0
