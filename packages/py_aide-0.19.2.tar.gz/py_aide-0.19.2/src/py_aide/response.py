import json
from typing import Any

_SECRET_TOKEN = object()

class Response:
    def __init__(self, _token: object, status: bool, log: str, data: Any, errorLogs: dict | None) -> None:
        # Strict check: must use factory token
        if _token is not _SECRET_TOKEN:
            raise RuntimeError(
                "\n[Error Alert] Direct initialization forbidden.\n"
                "Response can only be initialized through ok() or error()."
            )

        # Validation: Status type
        if not isinstance(status, bool):
            raise TypeError(f"Status must be bool, got {type(status).__name__}")
        
        if status and errorLogs:
            raise TypeError("Successful Response (status=True) cannot contain error logs")

        # Validation: No data on failure
        if status is False and data is not None:
            raise ValueError("A failed response (status=False) cannot contain data.")
        
        # Validation: error logs on failure
        if not status and errorLogs is not None and not isinstance(errorLogs, dict):
            raise ValueError("A failed response's (status=False) errorLogs must either be None or dict.")

        self.status = status
        self.log = log
        self.data = data
        self.errorLogs = errorLogs

    def __repr__(self) -> str:
        return f"Response(status={self.status}, log='{self.log}', data={self.data}, errorLogs={self.errorLogs})"


    def __bool__(self) -> bool:
        return self.status

    def to_dict(self) -> dict:
        return {"status": self.status, "log": self.log, "data": self.data, "errorLogs": self.errorLogs}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

# --- Factory Functions ---

# @enforce_requirements
def ok(*, data: Any = None) -> Response:
    """initializes a successful Response"""
    return Response(_SECRET_TOKEN, True, "", data, None)

# @enforce_requirements
def error(*, message: str, errorLogs: dict | None = None) -> Response:
    """initializes a failed Response"""
    if not isinstance(message, str):
        raise TypeError(f"Message must be a string, got {type(message).__name__}")
    return Response(_SECRET_TOKEN, False, message, None, errorLogs)