from enum import Enum

class QueueEngine(Enum):
    """Supported engines for PersistentQueue."""
    INTERNAL = "internal"
    REDIS = "redis"

class CacheEngine(Enum):
    """Supported engines for Cache."""
    INTERNAL = "internal"
    REDIS = "redis"
    MEMCACHED = "memcached"

class DbEngine(Enum):
    """Supported engines for Database."""
    SQLITE = "sqlite"
    POSTGRES = "postgres"
    MONGODB = "mongodb"
