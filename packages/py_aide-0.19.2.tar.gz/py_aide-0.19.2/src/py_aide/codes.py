import secrets
import string
from enum import Enum, auto
from .enforcer import enforce_requirements

class CodeType(Enum):
    NUMERIC = auto()
    ALPHA = auto()
    ALPHANUMERIC = auto()

_GEN_LIMITS = {
    "MIN": 4,
    "MAX": 128
}

_CHAR_SETS = {
    CodeType.NUMERIC: string.digits,
    CodeType.ALPHA: string.ascii_letters,
    CodeType.ALPHANUMERIC: string.ascii_letters + string.digits
}

@enforce_requirements
def generate_code(
    length: int = 12, 
    /, 
    *, 
    xterSet: CodeType = CodeType.ALPHANUMERIC
) -> str:
    """
    Generates a cryptographically secure random code.

    Args:
        length (int): The total number of characters. Defaults to 12.
            Must be between 4 and 128.
        xterSet (CodeType): The character set to use. Defaults to ALPHANUMERIC.
            Options: CodeType.NUMERIC, CodeType.ALPHA, CodeType.ALPHANUMERIC.

    Returns:
        str: A randomly generated secure string.

    Example:
        >>> from utils import generate_code, CodeType
        >>> # Using defaults
        >>> generate_code()
        '7jK9mP2qL5xR'
        >>> # Customizing
        >>> generate_code(6, xterSet=CodeType.NUMERIC)
        '882104'
    """
    if not (_GEN_LIMITS["MIN"] <= length <= _GEN_LIMITS["MAX"]):
        raise ValueError(f"Length {length} is out of bounds (4-128).")

    chars = _CHAR_SETS[xterSet]
    return "".join(secrets.choice(chars) for _ in range(length))