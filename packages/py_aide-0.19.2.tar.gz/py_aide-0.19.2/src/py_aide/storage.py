import os
import shutil
import inspect

from .response import Response, ok, error

class Path:
    # Class Attribute: The root of the current user
    HOME_DIR: str = os.path.expanduser("~")

    @staticmethod
    def get_my_absolute_path() -> str:
        """
        Returns the full absolute path (including filename) of the script 
        that is CURRENTLY calling this method.
        """
        # [1] is the caller of this method
        caller_frame = inspect.stack()[1]
        caller_filename = caller_frame.filename
        return os.path.abspath(caller_filename)
    
    @staticmethod
    def get_absolute_path(path: str) -> str:
        """
        Converts any string (relative, home-prefixed, or partial) 
        into a full system absolute path.
        """
        return os.path.abspath(os.path.expanduser(path))

    @staticmethod
    def info(path: str) -> dict[str, str|bool|int|None]:
        """
        Returns metadata for ANY path on the system.
        """
        p = Path.get_absolute_path(path)
        exists = os.path.exists(p)
        is_dir = os.path.isdir(p) if exists else False
        
        return {
            "abs": p,
            "exists": exists,
            "is_dir": is_dir,
            "is_file": os.path.isfile(p) if exists else False,
            "is_link": os.path.islink(p) if exists else False,
            "ext": os.path.splitext(p)[1].lower().replace('.', '') if exists and not is_dir else None,
            "size": os.path.getsize(p) if exists else 0
        }

    @staticmethod
    def create_copy(src: str, dst: str) -> Response:
        """
        Copies file/folder. Handles collisions by naming:
        cat.jpg -> cat_copy.jpg -> cat_copy_1.jpg -> cat_copy_2.jpg
        """
        try:
            src_abs = Path.get_absolute_path(src)
            dst_abs = Path.get_absolute_path(dst)
            
            if not os.path.exists(src_abs):
                return error(message=f"Source not found: {src_abs}")

            # COLLISION RESOLVER
            if os.path.exists(dst_abs):
                base, ext = os.path.splitext(dst_abs)
                
                # Step 1: Try the simple "_copy" suffix
                new_dst = f"{base}_copy{ext}"
                
                # Step 2: If "_copy" exists, start the numbered counter (_copy_1, _copy_2...)
                counter = 1
                while os.path.exists(new_dst):
                    new_dst = f"{base}_copy_{counter}{ext}"
                    counter += 1
                
                dst_abs = new_dst

            # Create parent directories if they don't exist
            os.makedirs(os.path.dirname(dst_abs), exist_ok=True)

            if os.path.isdir(src_abs):
                shutil.copytree(src_abs, dst_abs)
            else:
                shutil.copy2(src_abs, dst_abs)
                
            return ok(data=dst_abs)
        except PermissionError:
            return error(message="Permission denied while copying.")
        except Exception as e:
            return error(message=f"Error copying path: {str(e)}")

    @staticmethod
    def create_shortcut(target: str, link_name: str) -> Response:
        """
        Creates a symbolic link. 
        Now automatically creates the destination folder if it is missing.
        """
        try:
            t_abs = Path.get_absolute_path(target)
            l_abs = Path.get_absolute_path(link_name)
            
            # New: Proactively create the parent directory for the shortcut
            link_dir = os.path.dirname(l_abs)
            if not os.path.exists(link_dir):
                os.makedirs(link_dir, exist_ok=True)
            
            # Refresh if a link or file already exists at that specific name
            if os.path.exists(l_abs) or os.path.islink(l_abs):
                os.remove(l_abs)
            
            os.symlink(t_abs, l_abs)
            return ok(data=l_abs)
        except OSError as e:
            return error(message=f"OS error creating shortcut (Check admin privileges on Windows): {str(e)}")
        except Exception as e:
            return error(message=f"Error creating shortcut: {str(e)}")
    
    @staticmethod
    def to_relative(path: str, start_at: str) -> str:
        """
        Calculates relative path between two points.
        """
        return os.path.relpath(
            Path.get_absolute_path(path), 
            Path.get_absolute_path(start_at)
        )

    @staticmethod
    def delete(path: str) -> Response:
        """
        Deletes file, link, or directory. Returns ok(data=True) if successful, 
        ok(data=False) if path did not exist, and error(...) on failure.
        """
        try:
            p = Path.get_absolute_path(path)
            if not os.path.exists(p):
                return ok(data=False)
            
            if os.path.isfile(p) or os.path.islink(p):
                os.remove(p)
            elif os.path.isdir(p):
                shutil.rmtree(p)
            return ok(data=True)
        except PermissionError:
            return error(message=f"Permission denied deleting path: {path}")
        except Exception as e:
            return error(message=f"Failed to delete path: {str(e)}")
    

    