class PostgresJSONParser:
    OPERATORS = {"+", "+=", "-=", "*=", "/=", "-", "|="}

    @classmethod
    def parse_read_column(cls, *, column_string: str):
        comp = cls._isolate_components(column_string)
        path_array, op, root_only = cls._format_json_path(comp["raw_path"])

        if path_array:
            if root_only:
                frag = comp["column"]
            else:
                # For reading, we want text output from the last element
                # In Postgres: col #>> '{a,b,c}'
                safe_path = path_array.replace("'", "''")
                frag = f"{comp['column']} #>> '{safe_path}'"
        else:
            frag = comp["column"]

        return f'{frag} AS {comp["alias"]}' if comp["alias"] else frag

    @classmethod
    def parse_write_columns(cls, *, columns: list, values: list):
        col_map = {}
        for dsl, val in zip(columns, values):
            comp = cls._isolate_components(dsl)
            col = comp["column"]
            if col not in col_map: 
                col_map[col] = []
            col_map[col].append((dsl, val))

        final_set_parts = []
        flattened_values = []

        for col, updates in col_map.items():
            current_sql = col
            
            for dsl, val in updates:
                comp = cls._isolate_components(dsl)
                path_array, op, root_only = cls._format_json_path(comp["raw_path"])
                
                # Values and List Detection
                is_list = isinstance(val, (list, tuple))
                
                # For Postgres, we don't need to flatten list values into ? ? ?
                # We can just pass the whole list as a JSON string to %s and cast to ::jsonb
                import json
                if is_list and op in ("+", "|="):
                    # We store the list as a single JSON string for %s parameter
                    flattened_values.append(json.dumps(val))
                elif isinstance(val, dict) and op == "|=":
                    flattened_values.append(json.dumps(val))
                else:
                    flattened_values.append(val)

                if not path_array:
                    # STANDARD COLUMN
                    current_sql = "%s"
                else:
                    # JSON COLUMN
                    current_sql = cls._assemble_sql(current_sql, path_array, op, root_only, is_list=is_list)

            final_set_parts.append(f"{col} = {current_sql}")

        return final_set_parts, flattened_values

    @classmethod
    def _isolate_components(cls, dsl: str):
        res = {"column": "", "raw_path": "", "alias": None}
        
        lower_dsl = dsl.lower()
        if " as " in lower_dsl:
            idx = lower_dsl.find(" as ")
            working = dsl[:idx].strip()
            res["alias"] = dsl[idx + 4:].strip().lower()
        else:
            working = dsl.strip()

        c_idx = working.find("::")
        b_idx = working.find("[")
        indices = [i for i in [c_idx, b_idx] if i != -1]
        
        if not indices:
            col_part = working
            res["raw_path"] = ""
        else:
            split_pt = min(indices)
            col_part = working[:split_pt]
            res["raw_path"] = working[split_pt:]

        if "." in col_part:
            res["column"] = ".".join(f'{p.strip()}' for p in col_part.split("."))
        else:
            res["column"] = f'{col_part.strip()}'
            
        return res

    @classmethod
    def _format_json_path(cls, raw_path: str):
        if not raw_path: return None, None, False
        
        operator = None
        if raw_path.endswith(']'):
            last_b = raw_path.rfind('[')
            content = raw_path[last_b + 1 : -1].strip()
            if content in cls.OPERATORS:
                operator = content
                raw_path = raw_path[:last_b]

        if not raw_path and operator:
            return "{}", operator, True

        segments = raw_path.split("::")
        path_elements = []
        for seg in segments:
            if not seg: continue
            if "[" in seg:
                b_pos = seg.find("[")
                key, index = seg[:b_pos], seg[b_pos:]
                if key: path_elements.append(key)
                path_elements.append(index.strip("[]"))
            else:
                path_elements.append(seg)
                
        # Postgres expects '{a,b,c}' format for jsonb_set
        formatted = "{" + ",".join(path_elements) + "}"
        return formatted, operator, False

    @classmethod
    def _assemble_sql(cls, target, path, op, root_only=False, is_list=False):
        """Builds Postgres jsonb operations."""
        safe_path = path.replace("'", "''")

        # Root Dictionary Merge (submissions[|=])
        if root_only and op == "|=":
            return f"COALESCE({target}, '{{}}'::jsonb) || %s::jsonb"

        # Dictionary Merge
        if op == "|=":
            p_base = f"COALESCE({target} #> '{safe_path}', '{{}}'::jsonb)"
            return f"jsonb_set({target}, '{safe_path}', {p_base} || %s::jsonb)"

        # List Append
        if op == "+":
            p_base = f"COALESCE({target} #> '{safe_path}', '[]'::jsonb)"
            return f"jsonb_set({target}, '{safe_path}', {p_base} || %s::jsonb)"

        # Math Operations
        if op in ("+=", "-=", "*=", "/="):
            math_op = op[0]
            cur = f"COALESCE(({target} #>> '{safe_path}')::numeric, 0)"
            return f"jsonb_set({target}, '{safe_path}', ({cur} {math_op} %s::numeric)::text::jsonb)"

        # Default Set
        # For default set, we want to set it as a raw jsonb value if we can,
        # but if it's a string, we must to_jsonb it so it doesn't break.
        # Actually, if we pass a Python string, psycopg2 passes it as text. 
        # So we use to_jsonb(%s) to ensure correct json encoding
        return f"jsonb_set({target}, '{safe_path}', to_jsonb(%s))"

    @classmethod
    def parse_condition(cls, sql: str) -> str:
        """Translates col::path DSL in WHERE clauses into Postgres #>> operators."""
        if not sql or "::" not in sql:
            return sql

        in_single_quote = False
        in_double_quote = False
        i = 0

        while i < len(sql):
            char = sql[i]
            
            if char == "'": in_single_quote = not in_single_quote
            elif char == '"': in_double_quote = not in_double_quote
            
            if not in_single_quote and not in_double_quote and sql[i:i+2] == "::":
                start = i
                while start > 0:
                    prev = sql[start-1]
                    if not (prev.isalnum() or prev in ('_', '.')):
                        break
                    start -= 1
                    
                end = i + 2
                in_bracket = False
                break_chars = (' ', ',', ')', '(', '=', '>', '<', '!', '+', '-', '*', '/', '\n')
                
                while end < len(sql):
                    c = sql[end]
                    if c == '[': in_bracket = True
                    elif c == ']': in_bracket = False
                    
                    if not in_bracket and c in break_chars:
                        break
                    end += 1
                    
                dsl_chunk = sql[start:end]
                translated = cls.parse_read_column(column_string=dsl_chunk)
                
                sql = sql[:start] + translated + sql[end:]
                i = start + len(translated) - 1
            
            i += 1
            
        return sql
