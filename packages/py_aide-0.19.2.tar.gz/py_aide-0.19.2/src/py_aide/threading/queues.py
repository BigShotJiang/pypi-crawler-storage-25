from typing import Any, Optional
from ._internal_queue import InternalQueue
from ._redis_queue import RedisQueue
from ..response import Response
from ..enums import QueueEngine

class PersistentQueue:
    """
    A robust persistent queue manager for py_aide.
    Automatically chooses between SQLite (internal) and Redis backends.
    
    Default engine is 'internal' (SQLite).
    """

    def __init__(self, *, queue_name: str = "default", engine: QueueEngine | str = QueueEngine.INTERNAL, **kwargs):
        """
        Initialize the queue.
        
        Args:
            queue_name: The name of the queue.
            engine: The storage engine to use (QueueEngine.INTERNAL or QueueEngine.REDIS).
            **kwargs: Configuration for the chosen engine.
                     - For 'internal': db_path (optional)
                     - For 'redis': host, port, password, db (optional)
        """
        # Normalize engine to string value if it's an Enum
        engine_val = engine.value if isinstance(engine, QueueEngine) else str(engine).lower()

        if engine_val == QueueEngine.REDIS.value:
            self.driver = RedisQueue(queue_name=queue_name, **kwargs)
        else:
            self.driver = InternalQueue(queue_name=queue_name, **kwargs)

    def push(self, *, payload: Any, priority: int = 0) -> Response:
        """Add a new task to the queue."""
        return self.driver.push(payload=payload, priority=priority)

    def pop(self) -> Response:
        """Atomically retrieve and lock the next pending task."""
        return self.driver.pop()

    def complete(self, task_id: str) -> Response:
        """Mark a task as successfully completed."""
        return self.driver.complete(task_id)

    def fail(self, *, task_id: str, err: str = None, retry: bool = True) -> Response:
        """Mark a task as failed."""
        return self.driver.fail(task_id=task_id, err=err, retry=retry)

    def cleanup(self, *, max_age_days: int = 7) -> Response:
        """Delete old failed tasks."""
        return self.driver.cleanup(max_age_days=max_age_days)

    def peek(self, *, limit: int = 1) -> Response:
        """Look at upcoming tasks without locking them."""
        return self.driver.peek(limit=limit)

    def size(self) -> Response:
        """Get the number of pending tasks in the queue."""
        return self.driver.size()

    def clear(self) -> Response:
        """Wipe all tasks for this specific queue name."""
        return self.driver.clear()
