import threading
import time
import traceback
from datetime import datetime, timedelta
import sys
from typing import Callable, Any, Iterable, Optional

def _report_error(func_name: str, task_type: str, error: Exception | str, tb: Optional[str] = None) -> None:
    """Prints background errors clearly to the console using sys.stderr."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n{'!'*40}", file=sys.stderr)
    print(f"SCHEDULER ERROR | {timestamp}", file=sys.stderr)
    print(f"Task: {func_name} ({task_type})", file=sys.stderr)
    print(f"Details: {error}", file=sys.stderr)
    if tb:
        print(f"Traceback: {tb}", file=sys.stderr)
    print(f"{'!'*40}\n", file=sys.stderr)

# Track running tasks to prevent duplicates
_active_tasks = set()
_tasks_lock = threading.Lock()

def run_once(
    *,
    func: Callable[..., Any], 
    args: list = [], 
    kwargs: dict = {},
    delay: float = 0, 
    task_id: str|None = None, 
    on_error: Optional[Callable] = None
) -> threading.Thread|None:
    """
    Executes a function in a background thread exactly one time.
    If task_id is provided, guarantees no other instance with that ID runs concurrently.
    """
    if task_id:
        with _tasks_lock:
            if task_id in _active_tasks:
                return None
            _active_tasks.add(task_id)

    def wrapper() -> None:
        try:
            if delay > 0:
                time.sleep(delay)
            try:
                result = func(*args, **kwargs)
                if hasattr(result, "to_dict") and hasattr(result, "status") and not result.status:
                    err_msg = getattr(result, "log", "Response Error")
                    _report_error(func.__name__, "run_once", err_msg)
                    if on_error:
                        on_error(func.__name__, "run_once", err_msg, None)
            except Exception as e:
                err_msg = str(e)
                tb = traceback.format_exc()
                _report_error(func.__name__, "run_once", err_msg, tb)
                if on_error:
                    on_error(func.__name__, "run_once", err_msg, tb)
        finally:
            if task_id:
                with _tasks_lock:
                    _active_tasks.discard(task_id)

    t = threading.Thread(target=wrapper, daemon=True)
    t.start()
    return t

def run_every(
    *,
    interval_seconds: float, 
    func: Callable[..., Any], 
    args: list = [], 
    kwargs: dict = {},
    on_error: Optional[Callable] = None
) -> threading.Event:
    """
    Repeats a function indefinitely at the specified interval.
    """
    stop_event = threading.Event()

    def wrapper() -> None:
        while not stop_event.is_set():
            try:
                result = func(*args, **kwargs)
                if hasattr(result, "to_dict") and hasattr(result, "status") and not result.status:
                    err_msg = getattr(result, "log", "Response Error")
                    _report_error(func.__name__, "run_every", err_msg)
                    if on_error:
                        on_error(func.__name__, "run_every", err_msg, None)
            except Exception as e:
                err_msg = str(e)
                tb = traceback.format_exc()
                _report_error(func.__name__, "run_every", err_msg, tb)
                if on_error:
                    on_error(func.__name__, "run_every", err_msg, tb)
            
            if stop_event.wait(timeout=interval_seconds):
                break
                
    threading.Thread(target=wrapper, daemon=True).start()
    return stop_event

def run_at(
    *,
    time_tuple: tuple[int, int], 
    days: Iterable[int], 
    func: Callable[..., Any], 
    args: list = [], 
    kwargs: dict = {},
    on_error: Optional[Callable] = None
) -> threading.Event|None:
    """
    Executes a function at a specific time (24h format) on specific days.
    """
    if not days:
        print(f"[SCHEDULER] Warning: {func.__name__} ignored (no days provided).")
        return None

    stop_event = threading.Event()
    hour, minute = time_tuple

    def wrapper() -> None:
        while not stop_event.is_set():
            now = datetime.now()
            target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)

            if target <= now:
                target += timedelta(days=1)

            delay = (target - now).total_seconds()
            
            if stop_event.wait(timeout=delay):
                break

            if datetime.now().weekday() in days:
                try:
                    result = func(*args, **kwargs)
                    if hasattr(result, "to_dict") and hasattr(result, "status") and not result.status:
                        err_msg = getattr(result, "log", "Response Error")
                        _report_error(func.__name__, "run_at", err_msg)
                        if on_error:
                            on_error(func.__name__, "run_at", err_msg, None)
                except Exception as e:
                    err_msg = str(e)
                    tb = traceback.format_exc()
                    _report_error(func.__name__, "run_at", err_msg, tb)
                    if on_error:
                        on_error(func.__name__, "run_at", err_msg, tb)

    threading.Thread(target=wrapper, daemon=True).start()
    return stop_event