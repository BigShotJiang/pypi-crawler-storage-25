from abc import ABC, abstractmethod
from typing import Any, Optional
from ..response import Response

class BaseQueue(ABC):
    """
    Abstract Base Class for all py_aide queue drivers.
    Ensures a consistent API across different storage backends.
    """

    @abstractmethod
    def push(self, *, payload: Any, priority: int = 0) -> Response:
        """Add a task to the queue."""
        pass

    @abstractmethod
    def pop(self) -> Response:
        """Retrieve and lock the next task."""
        pass

    @abstractmethod
    def complete(self, task_id: str) -> Response:
        """Mark a task as successfully completed."""
        pass

    @abstractmethod
    def fail(self, *, task_id: str, err: str = None, retry: bool = True) -> Response:
        """Mark a task as failed with optional retry."""
        pass

    @abstractmethod
    def size(self) -> Response:
        """Get the number of pending tasks."""
        pass

    @abstractmethod
    def clear(self) -> Response:
        """Wipe all tasks for the current queue."""
        pass

    @abstractmethod
    def peek(self, *, limit: int = 1) -> Response:
        """Look at upcoming tasks without locking."""
        pass

    @abstractmethod
    def cleanup(self, *, max_age_days: int = 7) -> Response:
        """Remove old failed tasks."""
        pass
