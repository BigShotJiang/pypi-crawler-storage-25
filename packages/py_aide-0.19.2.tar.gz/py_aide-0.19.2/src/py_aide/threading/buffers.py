import threading
import time
import logging
import traceback
from typing import Any, List, Optional, Union, Callable
from .queues import PersistentQueue
from ..database import Api
from ..response import Response, ok, error

logger = logging.getLogger(__name__)

class DatabaseBuffer:
    """
    A non-blocking database write buffer.
    Queues all write operations (insert, update, delete) to a persistent queue
    and processes them sequentially in a background thread to prevent SQLite locking.
    """

    def __init__(
        self, 
        *,
        main_db: str, 
        queue_db: str = "_py_aide_queues.db", 
        queue_name: str = "db_writes",
        busy_timeout: int = 5000,
        on_error: Optional[Callable] = None
    ):
        self.main_db = main_db
        self.queue = PersistentQueue(queue_name=queue_name, db_path=queue_db)
        self.busy_timeout = busy_timeout
        self.on_error = on_error
        
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None
        self._is_running = False

    def start(self) -> None:
        """Starts the background write worker."""
        if self._is_running:
            return

        self._stop_event.clear()
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            name=f"DBBufferWorker-{self.queue.driver.queue_name}",
            daemon=True
        )
        self._worker_thread.start()
        self._is_running = True
        logger.info(f"DatabaseBuffer worker started for {self.main_db}")

    def stop(self, wait: bool = True) -> None:
        """Stops the background write worker."""
        self._stop_event.set()
        if wait and self._worker_thread:
            self._worker_thread.join()
        self._is_running = False
        logger.info(f"DatabaseBuffer worker stopped for {self.main_db}")

    def cleanup(self, *, max_age_days: int = 7) -> Response:
        """Purges old failed write tasks from the queue."""
        return self.queue.cleanup(max_age_days=max_age_days)

    def __enter__(self) -> "DatabaseBuffer":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()

    def _worker_loop(self) -> None:
        """The core processing loop that serializes writes."""
        while not self._stop_event.is_set():
            res = self.queue.pop()
            
            if not res.status:
                # No tasks or error, sleep briefly to save CPU
                time.sleep(0.5)
                continue

            task = res.data[0]
            task_id = task["id"]
            payload = task["payload"]
            
            method_name = payload["method"]
            kwargs = payload["kwargs"]

            try:
                # Perform the actual write to the main DB
                # We use a long busy_timeout for the worker to handle transient locks
                with Api(db_path=self.main_db, transactionMode=True) as db:
                    # Set busy timeout on the connection
                    db.driver.conn.execute(f"PRAGMA busy_timeout = {self.busy_timeout}")
                    
                    method = getattr(db, method_name)
                    write_res = method(**kwargs)
                    
                    if write_res:
                        db.commit_transaction()
                        self.queue.complete(task_id)
                    else:
                        # Database reported an error (likely logic error or persistent lock)
                        err_msg = write_res.log
                        self.queue.fail(task_id=task_id, err=err_msg, retry=True)
                        if self.on_error:
                            self.on_error(method_name, payload, err_msg, None)
                        time.sleep(1) # Backoff
            except Exception as e:
                err_msg = str(e)
                tb = traceback.format_exc()
                logger.error(f"WriteBuffer execution error: {err_msg}")
                self.queue.fail(task_id=task_id, err=err_msg, retry=True)
                if self.on_error:
                    self.on_error(method_name, payload, err_msg, tb)
                # No manual sleep needed anymore, PersistentQueue handles retry_after backoff

    # --- API Mirroring Methods ---

    def insert(self, *, table: str, data: list, priority: int = 0) -> Response:
        """Queue an insert operation."""
        return self.queue.push(payload={
            "method": "insert",
            "kwargs": {"table": table, "data": data}
        }, priority=priority)

    def update(
        self, 
        *,
        table: str, 
        columns: list, 
        column_data: list, 
        condition: str, 
        condition_data: list,
        priority: int = 0
    ) -> Response:
        """Queue an update operation."""
        return self.queue.push(payload={
            "method": "update",
            "kwargs": {
                "table": table,
                "columns": columns,
                "column_data": column_data,
                "condition": condition,
                "condition_data": condition_data
            }
        }, priority=priority)

    def delete(self, *, table: str, condition: str, condition_data: list, priority: int = 0) -> Response:
        """Queue a delete operation."""
        return self.queue.push(payload={
            "method": "delete",
            "kwargs": {
                "table": table,
                "condition": condition,
                "condition_data": condition_data
            }
        }, priority=priority)

    def execute(self, *, query: str, data: Optional[list] = None, priority: int = 0) -> Response:
        """Queue a custom SQL execution."""
        return self.queue.push(payload={
            "method": "execute",
            "kwargs": {"query": query, "data": data}
        }, priority=priority)

class TaskBuffer:
    """
    A generic persistent task buffer.
    Maps task types to handler functions and processes them in a background thread.
    Ideal for emails, image processing, or any non-blocking background work.
    """

    def __init__(
        self, 
        *,
        handlers: dict, 
        queue_db: str = "_py_aide_queues.db", 
        queue_name: str = "tasks",
        workers: int = 1,
        on_error: Optional[Callable] = None
    ):
        self.handlers = handlers
        self.queue = PersistentQueue(queue_name=queue_name, db_path=queue_db)
        self.workers = workers
        self.on_error = on_error
        
        self._stop_event = threading.Event()
        self._worker_threads: List[threading.Thread] = []
        self._is_running = False

    def start(self) -> None:
        """Starts the task worker threads."""
        if self._is_running:
            return

        self._stop_event.clear()
        self._worker_threads = []
        
        for i in range(self.workers):
            t = threading.Thread(
                target=self._worker_loop,
                name=f"TaskBufferWorker-{self.queue.driver.queue_name}-{i}",
                daemon=True
            )
            t.start()
            self._worker_threads.append(t)
            
        self._is_running = True
        logger.info(f"TaskBuffer started with {self.workers} workers for {self.queue.driver.queue_name}")

    def stop(self, wait: bool = True) -> None:
        """Gracefully stops all task worker threads."""
        self._stop_event.set()
        if wait:
            for t in self._worker_threads:
                t.join()
        self._is_running = False
        logger.info(f"TaskBuffer worker stopped for {self.queue.driver.queue_name}")

    def __enter__(self) -> "TaskBuffer":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()

    def cleanup(self, *, max_age_days: int = 7) -> Response:
        """Purges old failed tasks from the queue."""
        return self.queue.cleanup(max_age_days=max_age_days)

    def _worker_loop(self) -> None:
        """The loop that routes tasks to their respective handlers."""
        while not self._stop_event.is_set():
            res = self.queue.pop()
            
            if not res.status:
                if "collision" in res.log.lower():
                    # Collision occurred, another worker grabbed the task.
                    # Retry immediately without sleeping.
                    continue
                
                # Truly empty or other error, sleep briefly
                time.sleep(0.5)
                continue

            task = res.data[0]
            task_id = task["id"]
            payload = task["payload"]
            
            task_type = payload.get("task_type")
            task_data = payload.get("data")

            if task_type not in self.handlers:
                err_msg = f"No handler registered for task type: {task_type}"
                logger.error(err_msg)
                self.queue.fail(task_id=task_id, err=err_msg, retry=False)
                if self.on_error:
                    self.on_error(task_type, task_data, err_msg, None)
                continue

            handler = self.handlers[task_type]
            try:
                # Execute the handler
                result = handler(task_data)
                
                # We assume success unless a Response is returned with status=False
                # or an exception is raised.
                if isinstance(result, Response) and not result.status:
                    err_msg = result.log
                    self.queue.fail(task_id=task_id, err=err_msg, retry=True)
                    if self.on_error:
                        self.on_error(task_type, task_data, err_msg, None)
                else:
                    self.queue.complete(task_id)
            except Exception as e:
                err_msg = str(e)
                tb = traceback.format_exc()
                logger.error(f"TaskBuffer handler error ({task_type}): {err_msg}")
                self.queue.fail(task_id=task_id, err=err_msg, retry=True)
                if self.on_error:
                    self.on_error(task_type, task_data, err_msg, tb)

    def push(self, *, task_type: str, data: Any, priority: int = 0) -> Response:
        """Enqueues a new task."""
        return self.queue.push(payload={
            "task_type": task_type,
            "data": data
        }, priority=priority)
