import time
import uuid
from typing import Any, Optional
from ..database import Api
from ..response import Response, ok, error
from .base_queue import BaseQueue

class InternalQueue(BaseQueue):
    """
    The default, SQLite-backed persistent queue.
    Ensures tasks survive application restarts and handles multi-worker safety.
    """
    
    TABLE_NAME = "py_aide_queues"
    SCHEMA = (
        "id TEXT PRIMARY KEY, "
        "queue_name TEXT, "
        "payload JSON, "
        "priority INTEGER DEFAULT 0, "
        "status TEXT DEFAULT 'pending', "
        "attempts INTEGER DEFAULT 0, "
        "error TEXT, "
        "created_at INTEGER, "
        "locked_at INTEGER, "
        "retry_after INTEGER"
    )

    def __init__(self, *, queue_name: str = "default", db_path: str = "_py_aide_queues.db"):
        self.queue_name = queue_name
        self.db_path = db_path
        self._db_config = {
            "db_path": self.db_path,
            "tables": {self.TABLE_NAME: self.SCHEMA},
            "readonly": False,
            "transactionMode": True,
            "wal_mode": True
        }

    def push(self, *, payload: Any, priority: int = 0) -> Response:
        task_id = str(uuid.uuid4())
        data = [[
            task_id,
            self.queue_name,
            payload,
            priority,
            "pending",
            0,
            None,
            int(time.time()),
            None,
            None # retry_after
        ]]
        
        with Api(**self._db_config) as db:
            res = db.insert(table=self.TABLE_NAME, data=data)
            if res:
                db.commit_transaction()
                return ok(data={"task_id": task_id})
            return res

    def pop(self) -> Response:
        now = int(time.time())
        
        with Api(**self._db_config) as db:
            stale_timeout = now - 3600 
            
            find_query = (
                f"SELECT id FROM {self.TABLE_NAME} "
                "WHERE queue_name = ? AND ("
                "  (status = 'pending' AND (retry_after IS NULL OR retry_after <= ?)) "
                "  OR (status = 'processing' AND locked_at < ?)"
                ") "
                "ORDER BY priority DESC, created_at ASC LIMIT 1"
            )
            
            res = db.execute(query=find_query, data=[self.queue_name, now, stale_timeout])
            if not res or not res.data:
                return error(message="Queue is empty")

            task_id = res.data[0]["id"]

            lock_condition = (
                "id = ? AND ("
                "  status = 'pending' "
                "  OR (status = 'processing' AND locked_at < ?)"
                ")"
            )
            lock_res = db.update(
                table=self.TABLE_NAME,
                columns=["status", "locked_at"],
                column_data=["processing", now],
                condition=lock_condition,
                condition_data=[task_id, stale_timeout]
            )

            if not lock_res or lock_res.data.get("affected_rows") == 0:
                return error(message="Task collision or lock failed")

            task_res = db.fetch(
                table=self.TABLE_NAME,
                columns=["id", "payload", "attempts", "priority"],
                condition="id = ?",
                condition_data=[task_id]
            )
            
            if task_res:
                db.commit_transaction()
                return task_res
            
            return task_res

    def complete(self, task_id: str) -> Response:
        with Api(**self._db_config) as db:
            res = db.delete(
                table=self.TABLE_NAME,
                condition="id = ?",
                condition_data=[task_id]
            )
            if res:
                db.commit_transaction()
            return res

    def fail(self, *, task_id: str, err: str = None, retry: bool = True) -> Response:
        now = int(time.time())
        with Api(**self._db_config) as db:
            if retry:
                count_res = db.fetch(
                    table=self.TABLE_NAME,
                    columns=["attempts"],
                    condition="id = ?",
                    condition_data=[task_id]
                )
                attempts = count_res.data[0]["attempts"] if count_res else 0
                
                backoff = (2 ** attempts)
                retry_after = now + backoff

                res = db.execute(
                    query=(
                        f"UPDATE {self.TABLE_NAME} "
                        "SET status='pending', attempts=attempts+1, error=?, locked_at=NULL, retry_after=? "
                        "WHERE id=?"
                    ),
                    data=[err, retry_after, task_id]
                )
            else:
                res = db.update(
                    table=self.TABLE_NAME,
                    columns=["status", "error"],
                    column_data=["failed", err],
                    condition="id = ?",
                    condition_data=[task_id]
                )
            
            if res:
                db.commit_transaction()
            return res

    def cleanup(self, *, max_age_days: int = 7) -> Response:
        limit_time = int(time.time()) - (max_age_days * 86400)
        with Api(**self._db_config) as db:
            res = db.delete(
                table=self.TABLE_NAME,
                condition="status = 'failed' AND created_at < ?",
                condition_data=[limit_time]
            )
            if res:
                db.commit_transaction()
            return res

    def peek(self, *, limit: int = 1) -> Response:
        with Api(**self._db_config) as db:
            query = (
                f"SELECT id, payload, priority, status, attempts, created_at "
                f"FROM {self.TABLE_NAME} "
                "WHERE queue_name = ? AND status = 'pending' "
                "ORDER BY priority DESC, created_at ASC LIMIT ?"
            )
            return db.execute(query=query, data=[self.queue_name, limit])

    def size(self) -> Response:
        with Api(**self._db_config) as db:
            res = db.execute(
                query=f"SELECT COUNT(*) as count FROM {self.TABLE_NAME} WHERE queue_name = ? AND status = 'pending'",
                data=[self.queue_name]
            )
            return res

    def clear(self) -> Response:
        with Api(**self._db_config) as db:
            res = db.delete(
                table=self.TABLE_NAME,
                condition="queue_name = ?",
                condition_data=[self.queue_name]
            )
            if res:
                db.commit_transaction()
            return res
