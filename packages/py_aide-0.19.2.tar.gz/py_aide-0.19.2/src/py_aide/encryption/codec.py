from cryptography.fernet import Fernet, InvalidToken
from ..enforcer import enforce_requirements
from ..response import Response, ok, error

class Codec:
    def __init__(self, key: bytes):
        """
        Initialize the engine. 
        Note: The key must be a 32-byte base64-encoded string.
        """
        try:
            self.fernet = Fernet(key)
        except Exception as e:
            raise ValueError(f"Invalid Key provided to Codec: {e}")

    @enforce_requirements
    def encrypt(self, *, data: str|bytes) -> Response:
        """Converts string to encrypted bytes."""
        try:
            _data = data.encode() if isinstance(data, str) else data
            return ok(data=self.fernet.encrypt(_data))
        except Exception as e:
            return error(message=f"Encryption failed: {str(e)}")

    @enforce_requirements
    def decrypt(self, *, ciphertext: bytes) -> Response:
        """
        Decrypts bytes back to string.
        Returns an error Response if the key is wrong or data is tampered with.
        """
        try:
            decrypted_bytes = self.fernet.decrypt(ciphertext)
            return ok(data=decrypted_bytes.decode())
        except InvalidToken:
            # This is a security feature. It fails if even 1 bit is changed.
            return error(message="Decryption failed: Invalid key or corrupted data.")
        except Exception as e:
            return error(message=f"Unexpected decryption error: {str(e)}")