from .enforcer import enforce_requirements
from datetime import datetime, timedelta, date
import calendar
from typing import Final

class DateUtils:
    """
    A utility class for common date manipulations using strings.
    
    Attributes:
        DATE_FORMAT (str): The expected input and output format (YYYY-MM-DD).
        TIMESTAMP_FORMAT (str): The format for full date-time strings.
    """
    DATE_FORMAT: Final[str] = "%Y-%m-%d"
    TIMESTAMP_FORMAT: Final[str] = "%Y-%m-%d %H:%M:%S"

    @staticmethod
    @enforce_requirements
    def _to_obj(date_str: str, /) -> date:
        """
        Internal: Safely converts a string to a date object.
        
        Args:
            date_str: The date string to convert.
            
        Returns:
            date: A Python date object.
            
        Raises:
            ValueError: If the string does not match DATE_FORMAT.
        """
        try:
            return datetime.strptime(date_str, DateUtils.DATE_FORMAT).date()
        except ValueError:
            raise ValueError(f"Date string '{date_str}' does not match format '{DateUtils.DATE_FORMAT}'")

    @staticmethod
    @enforce_requirements
    def _to_str(date_obj: date | datetime, /) -> str:
        """Internal: Converts a date or datetime object back to a string."""
        return date_obj.strftime(DateUtils.DATE_FORMAT)

    @staticmethod
    @enforce_requirements
    def current_timestamp() -> str:
        """
        Returns the current system date and time.
        
        Returns:
            str: Current timestamp in 'YYYY-MM-DD HH:MM:SS' format.
        """
        return datetime.now().strftime(DateUtils.TIMESTAMP_FORMAT)

    @staticmethod
    @enforce_requirements
    def today() -> str:
        """
        Returns today's date.
        
        Returns:
            str: Today's date as a string.
        """
        return DateUtils._to_str(date.today())

    @staticmethod
    @enforce_requirements
    def yesterday() -> str:
        """
        Returns the date for the previous day.
        
        Returns:
            str: Yesterday's date as a string.
        """
        return DateUtils._to_str(date.today() - timedelta(days=1))

    @staticmethod
    @enforce_requirements
    def tomorrow() -> str:
        """
        Returns the date for the following day.
        
        Returns:
            str: Tomorrow's date as a string.
        """
        return DateUtils._to_str(date.today() + timedelta(days=1))

    @staticmethod
    @enforce_requirements
    def days_between(date_a: str, date_b: str, /, *, inclusive: bool = False) -> int:
        """
        Calculates the count of days between two date strings.
        
        Args:
            date_a: The first date string (YYYY-MM-DD).
            date_b: The second date string (YYYY-MM-DD).
            inclusive: If True, includes both the start and end day in the count.
            
        Returns:
            int: Total number of days.
        """
        obj_a = DateUtils._to_obj(date_a)
        obj_b = DateUtils._to_obj(date_b)
        diff = abs((obj_a - obj_b).days)
        return diff + 1 if inclusive else diff

    @staticmethod
    @enforce_requirements
    def is_leap_year(year: int | None = None, /) -> bool:
        """
        Checks if a specific year is a leap year.
        
        Args:
            year: The year to check. If None, uses the current year.
            
        Returns:
            bool: True if leap year, False otherwise.
        """
        check_year = year if year is not None else date.today().year
        return calendar.isleap(check_year)

    @staticmethod
    @enforce_requirements
    def start_of_month(date_str: str | None = None, /) -> str:
        """
        Finds the first day of the month for a given date.
        
        Args:
            date_str: The date string to check. If None, uses today's date.
            
        Returns:
            str: The date of the 1st of that month.
        """
        obj = DateUtils._to_obj(date_str) if date_str else date.today()
        return DateUtils._to_str(obj.replace(day=1))

    @staticmethod
    @enforce_requirements
    def end_of_month(date_str: str | None = None, /) -> str:
        """
        Finds the last day of the month for a given date.
        
        Args:
            date_str: The date string to check. If None, uses today's date.
            
        Returns:
            str: The date of the last day of that month (e.g., 28, 29, 30, or 31).
        """
        obj = DateUtils._to_obj(date_str) if date_str else date.today()
        last_day = calendar.monthrange(obj.year, obj.month)[1]
        return DateUtils._to_str(obj.replace(day=last_day))
    
    @staticmethod
    @enforce_requirements
    def _shift_date(date_str: str | None, /, *, days: int = 0, months: int = 0, years: int = 0) -> str:
        """
        Internal: Calculates relative dates handling month and year overflows.
        """
        start_obj = DateUtils._to_obj(date_str) if date_str else date.today()
        
        # 1. Handle Years and Months first
        total_months = start_obj.month - 1 + months + (years * 12)
        new_year = start_obj.year + (total_months // 12)
        new_month = (total_months % 12) + 1
        
        # Ensure day is valid for the new month (e.g., Mar 31 -> Feb 28)
        last_day_of_new_month = calendar.monthrange(new_year, new_month)[1]
        new_day = min(start_obj.day, last_day_of_new_month)
        
        shifted_obj = date(new_year, new_month, new_day)
        
        # 2. Handle Days using timedelta
        final_obj = shifted_obj + timedelta(days=days)
        
        return DateUtils._to_str(final_obj)

    @staticmethod
    @enforce_requirements
    def get_future_date(date_str: str | None = None, /, *, days: int = 0, months: int = 0, years: int = 0) -> str:
        """
        Calculates a date in the future relative to the provided date.

        Args:
            date_str: The starting date string. If None, uses today.
            days: Number of days to add.
            months: Number of months to add.
            years: Number of years to add.

        Returns:
            str: The future date as a string.
        """
        return DateUtils._shift_date(date_str, days=days, months=months, years=years)

    @staticmethod
    @enforce_requirements
    def get_past_date(date_str: str | None = None, /, *, days: int = 0, months: int = 0, years: int = 0) -> str:
        """
        Calculates a date in the past relative to the provided date.

        Args:
            date_str: The starting date string. If None, uses today.
            days: Number of days to subtract.
            months: Number of months to subtract.
            years: Number of years to subtract.

        Returns:
            str: The past date as a string.
        """
        return DateUtils._shift_date(
            date_str, 
            days=-days, 
            months=-months, 
            years=-years
        )