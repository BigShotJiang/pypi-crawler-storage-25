import logging
import time
import httpx
from typing import Any, Callable, Optional, Union, Dict, List
from .response import Response, ok, error
from .tokens import TokenManager

logger = logging.getLogger(__name__)

# ============================================================================
# CONFIGURATION MANAGEMENT
# ============================================================================

class RequestConfig:
    """
    Global configuration for outgoing HTTP requests.
    """
    base_url: Optional[str] = None
    timeout: float = 30.0
    max_retries: int = 3
    retry_strategy: str = "exponential"  # options: "exponential", "linear", "fixed"
    api_key_header: str = "X-API-Key"     # Default header for API keys
    default_headers: Dict[str, str] = {
        "User-Agent": "py_aide/0.15.0",
        "X-Requested-With": "XMLHttpRequest"
    }

# ============================================================================
# INTERCEPTORS
# ============================================================================

class Interceptors:
    """
    Registry for request/response hooks.
    """
    request_hooks: List[Callable[[Dict[str, Any]], Dict[str, Any]]] = []
    response_hooks: List[Callable[[Response], Response]] = []

    @classmethod
    def add_request_hook(cls, hook: Callable[[Dict[str, Any]], Dict[str, Any]]):
        cls.request_hooks.append(hook)

    @classmethod
    def add_response_hook(cls, hook: Callable[[Response], Response]):
        cls.response_hooks.append(hook)

# ============================================================================
# UTILITIES
# ============================================================================

def sanitize_payload(data: Any) -> Any:
    """
    Basic sanitization to remove common injection patterns from outgoing strings.
    """
    if isinstance(data, str):
        return data.replace("<script", "[script-blocked]").replace("javascript:", "[js-blocked]")
    if isinstance(data, dict):
        return {k: sanitize_payload(v) for k, v in data.items()}
    if isinstance(data, list):
        return [sanitize_payload(v) for v in data]
    return data

def _calculate_retry_delay(attempt: int, strategy: str) -> float:
    if strategy == "exponential":
        return 2 ** attempt
    if strategy == "linear":
        return (attempt + 1) * 1.0
    return 1.0  # fixed

def _format_response(
    result: Union[httpx.Response, Exception], 
    endpoint: str, 
    start_time: float,
    silent: bool = False
) -> Response:
    """
    Standardizes all outcomes into a py_aide.Response object.
    Implementation of the 'Always Resolve' strategy.
    """
    duration = round((time.time() - start_time) * 1000, 2)
    meta = {"endpoint": endpoint, "duration_ms": duration}

    if isinstance(result, Exception):
        if not silent:
            logger.error(f"Request Failed [{endpoint}]: {str(result)}")
        return error(
            message=f"Request failed: {type(result).__name__}",
            errorLogs={**meta, "exception": str(result)}
        )

    # Log outgoing response
    log_msg = f"HTTP {result.status_code} [{result.request.method}] -> {endpoint} ({duration}ms)"
    if result.is_success:
        if not silent:
            logger.info(log_msg)
        try:
            data = result.json()
        except Exception:
            data = result.text
        
        # Check for business logic failure embedded in success response (if applicable)
        if isinstance(data, dict) and data.get("status") is False:
            if not silent:
                logger.warning(f"Business Logic Error [{endpoint}]: {data.get('log')}")
            return error(
                message=data.get("log", "Business logic failure"),
                errorLogs={**meta, "http_code": result.status_code, "raw": data}
            )
            
        res = ok(data=data)
    else:
        if not silent:
            logger.warning(log_msg)
        res = error(
            message=f"Service responded with status {result.status_code}",
            errorLogs={**meta, "http_code": result.status_code, "body": result.text[:500]}
        )

    # Run Response Interceptors
    for hook in Interceptors.response_hooks:
        try:
            res = hook(res)
        except Exception as e:
            logger.error(f"Response Interceptor Error: {e}")

    return res

# ============================================================================
# CORE REQUEST LOGIC (SYNC)
# ============================================================================

def send_request(
    *,
    method: str,
    endpoint: str,
    payload: Any = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    auth_token: Optional[Union[str, tuple, TokenManager]] = None,
    auth_type: Optional[str] = None,
    timeout: Optional[float] = None,
    on_success: Optional[Callable[[Any], Any]] = None,
    on_error: Optional[Callable[[str], Any]] = None,
    silent: bool = False,
    **kwargs
) -> Response:
    """
    Standardized Synchronous HTTP Request. 
    Ideal for Flask/Eventlet environments.
    """
    start_time = time.time()
    url = endpoint if endpoint.startswith("http") else f"{RequestConfig.base_url or ''}/{endpoint.lstrip('/')}"
    
    # Prepare Headers (Global Defaults + Local Overrides)
    final_headers = {**RequestConfig.default_headers, **(headers or {})}
    
    # Handle Auth Token
    if auth_token:
        if not auth_type:
            raise ValueError(
                "\n[Security Protocol Violation] auth_token provided without auth_type.\n"
                "You must explicitly specify 'bearer', 'api_key', or 'basic'."
            )
        import base64
        token_str = auth_token
        if isinstance(auth_token, TokenManager):
            token_str = auth_token.create_session_token("internal", token_type=auth_type)
        
        if auth_type == "bearer":
            final_headers["Authorization"] = f"Bearer {token_str}"
        elif auth_type == "api_key":
            final_headers[RequestConfig.api_key_header] = str(token_str)
        elif auth_type == "basic" and isinstance(token_str, (list, tuple)):
            creds = f"{token_str[0]}:{token_str[1]}"
            encoded = base64.b64encode(creds.encode()).decode()
            final_headers["Authorization"] = f"Basic {encoded}"

    # Prepare Request Data
    request_data = {
        "method": method.upper(),
        "url": url,
        "params": params,
        "headers": final_headers,
        "timeout": timeout or RequestConfig.timeout,
        **kwargs
    }

    # Auto-detect JSON Content-Type
    has_ct = any(k.lower() == "content-type" for k in final_headers)
    clean_payload = sanitize_payload(payload) if payload else None
    
    if not has_ct and isinstance(clean_payload, (dict, list)):
        final_headers["Content-Type"] = "application/json"

    # Handle Payload
    if clean_payload:
        if isinstance(clean_payload, (dict, list)):
            request_data["json"] = clean_payload
        else:
            request_data["content"] = clean_payload

    # Run Request Interceptors
    for hook in Interceptors.request_hooks:
        request_data = hook(request_data)

    max_retries = RequestConfig.max_retries
    final_res = None
    
    for attempt in range(max_retries + 1):
        try:
            with httpx.Client() as client:
                res = client.request(**request_data)
                
            # If we get a 5xx or 408, we might want to retry
            if attempt < max_retries and (res.status_code >= 500 or res.status_code == 408):
                delay = _calculate_retry_delay(attempt, RequestConfig.retry_strategy)
                logger.info(f"Retrying request to {url} in {delay}s (Attempt {attempt + 1}/{max_retries})")
                time.sleep(delay)
                continue
                
            final_res = _format_response(res, endpoint, start_time, silent=silent)
            break

        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as e:
            if attempt < max_retries:
                delay = _calculate_retry_delay(attempt, RequestConfig.retry_strategy)
                logger.warning(f"Connection error to {url}, retrying in {delay}s... ({e})")
                time.sleep(delay)
                continue
            final_res = _format_response(e, endpoint, start_time, silent=silent)
            break
        except Exception as e:
            final_res = _format_response(e, endpoint, start_time, silent=silent)
            break

    # Trigger Callbacks
    if final_res:
        if on_success: 
            on_success(final_res.data)
    else:
        if on_error:
            on_error(final_res.log)
            
    return final_res

# ============================================================================
# CORE REQUEST LOGIC (ASYNC)
# ============================================================================

async def send_request_async(
    *,
    method: str,
    endpoint: str,
    payload: Any = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    auth_token: Optional[Union[str, tuple, TokenManager]] = None,
    auth_type: Optional[str] = None,
    timeout: Optional[float] = None,
    on_success: Optional[Callable[[Any], Any]] = None,
    on_error: Optional[Callable[[str], Any]] = None,
    silent: bool = False,
    **kwargs
) -> Response:
    """
    Standardized Asynchronous HTTP Request.
    Ideal for FastAPI environments.
    """
    import asyncio
    start_time = time.time()
    url = endpoint if endpoint.startswith("http") else f"{RequestConfig.base_url or ''}/{endpoint.lstrip('/')}"
    
    # Prepare Headers (Global Defaults + Local Overrides)
    final_headers = {**RequestConfig.default_headers, **(headers or {})}
    
    # Handle Auth Token
    if auth_token:
        if not auth_type:
            raise ValueError(
                "\n[Security Protocol Violation] auth_token provided without auth_type.\n"
                "You must explicitly specify 'bearer', 'api_key', or 'basic'."
            )
        import base64
        token_str = auth_token
        if isinstance(auth_token, TokenManager):
            token_str = auth_token.create_session_token("internal", token_type=auth_type)
        
        if auth_type == "bearer":
            final_headers["Authorization"] = f"Bearer {token_str}"
        elif auth_type == "api_key":
            final_headers[RequestConfig.api_key_header] = str(token_str)
        elif auth_type == "basic" and isinstance(token_str, (list, tuple)):
            creds = f"{token_str[0]}:{token_str[1]}"
            encoded = base64.b64encode(creds.encode()).decode()
            final_headers["Authorization"] = f"Basic {encoded}"

    # Prepare Request Data
    request_data = {
        "method": method.upper(),
        "url": url,
        "params": params,
        "headers": final_headers,
        "timeout": timeout or RequestConfig.timeout,
        **kwargs
    }

    # Auto-detect JSON Content-Type
    has_ct = any(k.lower() == "content-type" for k in final_headers)
    clean_payload = sanitize_payload(payload) if payload else None
    
    if not has_ct and isinstance(clean_payload, (dict, list)):
        final_headers["Content-Type"] = "application/json"

    # Handle Payload
    if clean_payload:
        if isinstance(clean_payload, (dict, list)):
            request_data["json"] = clean_payload
        else:
            request_data["content"] = clean_payload

    # Run Request Interceptors
    for hook in Interceptors.request_hooks:
        request_data = hook(request_data)

    max_retries = RequestConfig.max_retries
    final_res = None

    for attempt in range(max_retries + 1):
        try:
            async with httpx.AsyncClient() as client:
                res = await client.request(**request_data)
                
            if attempt < max_retries and (res.status_code >= 500 or res.status_code == 408):
                delay = _calculate_retry_delay(attempt, RequestConfig.retry_strategy)
                await asyncio.sleep(delay)
                continue
                
            final_res = _format_response(res, endpoint, start_time, silent=silent)
            break

        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as e:
            if attempt < max_retries:
                delay = _calculate_retry_delay(attempt, RequestConfig.retry_strategy)
                await asyncio.sleep(delay)
                continue
            final_res = _format_response(e, endpoint, start_time, silent=silent)
            break
        except Exception as e:
            final_res = _format_response(e, endpoint, start_time, silent=silent)
            break

    # Trigger Callbacks
    if final_res:
        if on_success:
            if asyncio.iscoroutinefunction(on_success):
                await on_success(final_res.data)
            else:
                on_success(final_res.data)
    else:
        if on_error:
            if asyncio.iscoroutinefunction(on_error):
                await on_error(final_res.log)
            else:
                on_error(final_res.log)
                
    return final_res
