import math
from typing import Literal, Union, Optional, List
from src.py_aide.enforcer import enforce_requirements
from src.py_aide.customTypes import Options

# RoundMethod = Literal["round", "floor", "ceil", "nearestUpper"]

@enforce_requirements
def round_to_nearest(
    value: float,
    /,
    *,
    nearest: int|float = 1.0,
    method: Options[str, ["round", "floor", "ceil"]] = "round"
) -> float:
    """
    Rounds a number to the nearest specified increment.
    
    Args:
        value: The value to round.
        nearest: The increment to round to (e.g., 10, 0.25). Must be positive.
            If 0 or negative, returns the original value unchanged.
        method: Rounding method to use:
            - 'round': Standard rounding (ties to nearest even)
            - 'floor': Always round down
            - 'ceil': Always round up
            - 'nearestUpper': For positive numbers, round up; for negative, round down
    
    Returns:
        The rounded value as a float.
    
    Raises:
        ValueError: If `nearest` is not positive.
    
    Examples:
        >>> round_to_nearest(123, nearest=10)
        120.0
        >>> round_to_nearest(127, nearest=10, method='ceil')
        130.0
        >>> round_to_nearest(1.234, nearest=0.25)
        1.25
    """
    if nearest <= 0:
        raise ValueError("'nearest' must be positive")
    
    inverse = 1.0 / nearest
    
    if method == "floor":
        return math.floor(value * inverse) / inverse
    elif method == "ceil":
        return math.ceil(value * inverse) / inverse
    elif method == "nearestUpper":
        # For positive numbers, ceil; for negative numbers, floor
        if value >= 0:
            return math.ceil(value * inverse) / inverse
        else:
            return math.floor(value * inverse) / inverse
    else:  # default 'round'
        return round(value * inverse) / inverse

@enforce_requirements
def format_number(
    value: float,
    /,
    *,
    decimal_places: int = 0,
    round_to_nearest_increment: int|float|None = None,
    round_method: Options[str, ["round", "floor", "ceil"]] = "round",
    use_grouping: bool = True
) -> str:
    """
    Formats a number with rounding and optional thousands separators.
    
    Args:
        value: The numeric value to format.
        decimal_places: Number of decimal places to show. Default is 0.
        round_to_nearest_increment: Round to nearest increment (e.g., 10, 100).
            If None or 0, no pre-rounding is performed.
        round_method: Rounding method for the pre-rounding step.
        use_grouping: Whether to use thousands separators (commas).
    
    Returns:
        Formatted number as a string.
    
    Examples:
        >>> format_number(1234567.891, decimal_places=2, use_grouping=True)
        '1,234,567.89'
        >>> format_number(1234567.891, decimal_places=0, use_grouping=False)
        '1234568'
        >>> format_number(123.456, round_to_nearest_increment=10, decimal_places=0)
        '120'
    """
    # Round to nearest increment first (if specified)
    rounded_value = value
    if round_to_nearest_increment and round_to_nearest_increment > 0:
        rounded_value = round_to_nearest(
            value, 
            nearest=round_to_nearest_increment, 
            method=round_method
        )
    
    # Handle decimal places with standard rounding
    if decimal_places >= 0:
        factor = 10 ** decimal_places
        rounded_value = round(rounded_value * factor) / factor
    
    # Format with commas
    format_spec = ",." if use_grouping else "."
    return f"{rounded_value:{format_spec}{decimal_places}f}"

@enforce_requirements
def format_currency(
    value: int|float,
    /,
    *,
    symbol: str = "UGX",
    decimal_places: int = 2,
    use_grouping: bool = True
) -> str:
    """
    Formats a number as currency with symbol.
    
    Args:
        value: The numeric value to format.
        symbol: Currency symbol (e.g. 'UGX', '$', '€').
        decimal_places: Number of decimal places to show.
        use_grouping: Whether to use thousands separators.
    
    Returns:
        Formatted currency string.
    
    Examples:
        >>> format_currency(1234567.89, symbol='$', decimal_places=2)
        '$ 1,234,567.89'
        >>> format_currency(1234.5, symbol='UGX', decimal_places=0)
        'UGX 1,235'
    """
    formatted_number = format_number(
        value,
        decimal_places=decimal_places,
        use_grouping=use_grouping
    )
    return f"{symbol} {formatted_number}"

@enforce_requirements
def format_percentage(
    value: int|float,
    /,
    *,
    decimal_places: int = 1,
    use_grouping: bool = True
) -> str:
    """
    Formats a number as a percentage.
    
    Args:
        value: The numeric value (e.g., 0.1 for 10%).
        decimal_places: Number of decimal places to show.
        use_grouping: Whether to use thousands separators.
    
    Returns:
        Formatted percentage string.
    
    Examples:
        >>> format_percentage(0.12345, decimal_places=2)
        '12.35%'
        >>> format_percentage(25.5, decimal_places=0)
        '2,550%'
    """
    percentage_value = value * 100
    formatted_number = format_number(
        percentage_value,
        decimal_places=decimal_places,
        use_grouping=use_grouping
    )
    return f"{formatted_number}%"

@enforce_requirements
def abbreviate_number(
    value: int|float,
    /,
    *,
    decimal_places: int = 1,
    suffixes: List[str]|None = None
) -> str:
    """
    Abbreviates a large number using suffixes (K, M, B, T).
    
    Args:
        value: The numeric value to abbreviate.
        decimal_places: Number of decimal places in the abbreviation.
        suffixes: List of suffixes to use. Defaults to ["", "K", "M", "B", "T"].
            You can provide custom suffixes for different scaling.
    
    Returns:
        Abbreviated number string.
    
    Examples:
        >>> abbreviate_number(1500)
        '1.5K'
        >>> abbreviate_number(2500000, decimal_places=2)
        '2.50M'
        >>> abbreviate_number(1000000000, suffixes=["", "k", "M", "G"])
        '1.0G'
    """
    if suffixes is None:
        suffixes = ["", "K", "M", "B", "T"]
    
    if value == 0:
        return "0"
    
    is_negative = value < 0
    abs_value = abs(value)
    
    # Handle very small numbers
    if abs_value < 1000:
        tier_index = 0
        scaled_value = abs_value
    else:
        # Determine the appropriate suffix tier
        tier = math.floor(math.log10(abs_value) / 3)
        tier_index = min(tier, len(suffixes) - 1)
        scaled_value = abs_value / (1000 ** tier_index)
    
    # Format the scaled value
    if 0 <= tier_index < len(suffixes):
        suffix = suffixes[tier_index]
        if decimal_places <= 0:
            formatted_value = f"{int(round(scaled_value))}"
        else:
            formatted_value = f"{scaled_value:.{decimal_places}f}"
            # Remove trailing zeros after decimal point
            if '.' in formatted_value:
                formatted_value = formatted_value.rstrip('0').rstrip('.')
    else:
        # Use scientific notation for very large numbers beyond our suffixes
        suffix = f"e{tier_index * 3}"
        formatted_value = f"{scaled_value:.{decimal_places}f}"
    
    prefix = "-" if is_negative else ""
    return f"{prefix}{formatted_value}{suffix}"

@enforce_requirements
def unformat_number(formatted_number: str, /) -> str:
    """
    Removes formatting from a number string.
    
    Args:
        formatted_number: A formatted number string (e.g., "-123,456.78").
    
    Returns:
        A plain number string with formatting removed.
    
    Examples:
        >>> unformat_number("-123,456.78")
        '-123456.78'
        >>> unformat_number("1,234")
        '1234'
        >>> unformat_number("")
        ''
    """
    if not formatted_number:
        return ""
    
    result = []
    has_decimal = False
    
    for i, char in enumerate(str(formatted_number)):
        if char == "-" and i == 0:
            result.append(char)
        elif char == "." and not has_decimal:
            result.append(char)
            has_decimal = True
        elif char.isdigit():
            result.append(char)
    
    return "".join(result)

@enforce_requirements
def get_numeric_value(formatted_input: str, /) -> float:
    """
    Extracts numeric value from a formatted string.
    
    Args:
        formatted_input: A formatted number string (e.g., "1,234.56").
    
    Returns:
        The numeric value as a float. Returns 0.0 if the string cannot be parsed.
    
    Examples:
        >>> get_numeric_value("1,234.56")
        1234.56
        >>> get_numeric_value("-€ 123,456")
        -123456.0
        >>> get_numeric_value("invalid")
        0.0
    """
    clean_string = unformat_number(formatted_input)
    if not clean_string or clean_string == "-":
        return 0.0
    
    try:
        return float(clean_string)
    except (ValueError, TypeError):
        return 0.0