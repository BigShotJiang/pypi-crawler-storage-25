from typing import Callable, Any, Optional, Union, List
from dataclasses import dataclass, field
import time
from .customTypes import Options

@dataclass
class TokenValidationResult:
    """
    Standardized report for session unmasking (Authentication).
    The 'Key' to the 'Padlock'.
    """
    initial_value: Any   # The raw, unmasked ID (e.g. 123)
    is_active: bool      # The decision: Is the session valid?
    metadata: dict = field(default_factory=dict) # Extra data (tiers, roles, etc.)

# Type Aliases for Developer Clarity
SessionMaskerType = Callable[[Any], str]
SessionUnmaskerType = Callable[[str], TokenValidationResult]
DataMaskerType = Callable[[Any], str]
DataUnmaskerType = Callable[[str], Any]

# ============================================================================
# TOKEN REGISTRY (Pure Storage - Split into Session and Data concerns)
# ============================================================================

class TokenRegistry:
    """
    Registry for session authentication and data masking logic.
    Decouples the security implementation from the framework.
    """
    
    # Internal storage - Force split between Identity and Masking
    _session_masker: dict[str, SessionMaskerType] = {}
    _session_unmasker: dict[str, SessionUnmaskerType] = {}
    
    _data_tokenizer: Optional[DataMaskerType] = None
    _data_detokenizer: Optional[DataUnmaskerType] = None

    # --- SESSION SECURITY (THE DOOR) ---
    
    @classmethod
    def register_basic_validator(cls) -> Callable:
        """
        Register a simple validator for Basic Auth (user:pass).
        Returns: TokenValidationResult
        """
        def decorator(func: SessionUnmaskerType):
            cls._session_unmasker["basic"] = func
            return func
        return decorator

    @classmethod
    def register_bearer_masker(cls) -> Callable:
        """Register logic to create a Bearer token string."""
        def decorator(func: SessionMaskerType):
            cls._session_masker["bearer"] = func
            return func
        return decorator

    @classmethod
    def register_bearer_unmasker(cls) -> Callable:
        """Register logic to unmask/validate a Bearer token into a TokenValidationResult."""
        def decorator(func: SessionUnmaskerType):
            cls._session_unmasker["bearer"] = func
            return func
        return decorator

    @classmethod
    def register_apikey_masker(cls) -> Callable:
        """Register logic to create an API Key string."""
        def decorator(func: SessionMaskerType):
            cls._session_masker["api_key"] = func
            return func
        return decorator

    @classmethod
    def register_apikey_unmasker(cls) -> Callable:
        """Register logic to unmask/validate an API Key into a TokenValidationResult."""
        def decorator(func: SessionUnmaskerType):
            cls._session_unmasker["api_key"] = func
            return func
        return decorator

    @classmethod
    def register_payload_masker(cls, token_type: str = "token_payload") -> Callable:
        """Register logic to create a session token for a TOKEN_PAYLOAD auth."""
        def decorator(func: SessionMaskerType):
            cls._session_masker[token_type] = func
            return func
        return decorator

    @classmethod
    def register_payload_unmasker(cls, token_type: str = "token_payload") -> Callable:
        """Register logic to unmask/validate a TOKEN_PAYLOAD session token into a TokenValidationResult."""
        def decorator(func: SessionUnmaskerType):
            cls._session_unmasker[token_type] = func
            return func
        return decorator

    # --- DATA SECURITY (THE MASK) ---

    @classmethod
    def register_data_tokenizer(cls) -> Callable:
        """Register logic to mask a sensitive field (like SSN) for privacy."""
        def decorator(func: DataMaskerType):
            cls._data_tokenizer = func
            return func
        return decorator

    @classmethod
    def register_data_detokenizer(cls) -> Callable:
        """Register logic to unmask a sensitive field token back into raw data."""
        def decorator(func: DataUnmaskerType):
            cls._data_detokenizer = func
            return func
        return decorator

    # --- INTERNAL ACCESSORS ---

    @classmethod
    def get_session_masker(cls, t: str) -> Optional[SessionMaskerType]: return cls._session_masker.get(t)
    
    @classmethod
    def get_session_unmasker(cls, t: str) -> Optional[SessionUnmaskerType]: return cls._session_unmasker.get(t)
    
    @classmethod
    def get_data_tokenizer(cls) -> Optional[DataMaskerType]: return cls._data_tokenizer
    
    @classmethod
    def get_data_detokenizer(cls) -> Optional[DataUnmaskerType]: return cls._data_detokenizer

# ============================================================================
# TOKEN MANAGER (Strict Orchestrator)
# ============================================================================

class TokenManager:
    """
    Manager for executing session masking/unmasking and data tokenization.
    """
    
    def __init__(self, default_type: Options[str, ["bearer", "api_key", "token_payload"]] = "bearer"):
        self.default_type = default_type
    
    def create_session_token(self, initial_value: Any, *, token_type: Options[str, ["bearer", "api_key", "token_payload"]] = None) -> str:
        """
        Locks an initial value (like userId) into a session token string.
        
        Args:
            initial_value: The raw data to be masked.
            token_type: The strategy to use (defaults to manager's default_type).
        """
        t_type = token_type or self.default_type
        masker = TokenRegistry.get_session_masker(t_type)
        if not masker:
            raise ValueError(f"Security Register Missing: No session_masker for auth type: {t_type}")
        return masker(initial_value)
    
    def unlock_session_token(self, token: str, *, token_type: Options[str, ["bearer", "api_key", "token_payload", "basic"]] = None) -> Optional[TokenValidationResult]:
        """
        Unlocks a token string. MUST return a TokenValidationResult or None.
        
        Args:
            token: The masked string to validate.
            token_type: The strategy to use (defaults to manager's default_type).
        """
        t_type = token_type or self.default_type
        unmasker = TokenRegistry.get_session_unmasker(t_type)
        if not unmasker:
            raise ValueError(f"Security Register Missing: No session_unmasker for auth type: {t_type}")
        
        result = unmasker(token)
        
        if result is None:
            return None
            
        if not isinstance(result, TokenValidationResult):
            raise TypeError(
                f"Protocol Violation: session_unmasker for '{t_type}' must return a "
                f"'TokenValidationResult', but it returned '{type(result).__name__}'."
            )
            
        return result

    def mask_data(self, value: Any) -> str:
        """Masks a data field for privacy (The Padlock)."""
        masker = TokenRegistry.get_data_tokenizer()
        if not masker:
            raise ValueError("No data_tokenizer registered. Data security check failed.")
        return masker(value)

    def unmask_data(self, token: str) -> Any:
        """Unmasks a data token back into its raw value (The Key)."""
        unmasker = TokenRegistry.get_data_detokenizer()
        if not unmasker:
            raise ValueError("No data_detokenizer registered. Data security check failed.")
        return unmasker(token)