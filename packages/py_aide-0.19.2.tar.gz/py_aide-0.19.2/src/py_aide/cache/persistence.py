"""
Persistence Manager with Producer-Consumer Write Queue.

This module handles all disk I/O operations using a single background consumer thread
to prevent database locking errors (Errno 11) that occur with concurrent shelve access.
It implements a robust queuing system with retry logic, error reporting, and health monitoring.

Key Features:
    - Single consumer thread processes all writes sequentially
    - Queue-based architecture prevents file contention
    - Exponential backoff retry for failed writes
    - Write tracking with status feedback
    - Queue health monitoring and backpressure
    - Graceful shutdown with pending write completion
"""

import os
import shelve
import threading
import queue
import time
import uuid
from enum import Enum
from dataclasses import dataclass, field
import logging
from typing import Dict, Any, Optional, Callable, List
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class WritePriority(Enum):
    """Priority levels for write operations."""
    CRITICAL = 1  # Must persist immediately (transactions)
    NORMAL = 2    # Regular updates
    BACKGROUND = 3 # Non-essential writes


class WriteStatus(Enum):
    """Status states for write operations."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"


class ConsistencyLevel(Enum):
    """
    Controls how aggressively a write waits for disk confirmation.

    BACKGROUND  – Fire and forget. Write is queued and the caller returns
                  immediately. Data may be lost if the process crashes before
                  the consumer thread flushes it.  Used when disk_write_wait=False.

    DURABLE     – Queue the write and block until the consumer confirms it reached
                  disk.  Data survives a crash once this returns Ok.
                  Used when disk_write_wait=True and the queue is healthy.

    CRITICAL    – Like DURABLE but also blocks on queue admission (put() blocks
                  rather than returning None when the queue is full).
                  Used when disk_write_wait=True and the queue is near capacity,
                  so that backpressure is applied to the caller rather than
                  silently dropping the write.
    """
    BACKGROUND = "background"
    DURABLE = "durable"
    CRITICAL = "critical"


@dataclass
class WriteOperation:
    """
    Represents a queued write operation.
    
    Attributes:
        write_id: Unique identifier for tracking
        scope: The scope/namespace being written
        data: The data to persist
        priority: Write priority level
        retry_count: Number of retry attempts made
        max_retries: Maximum retries before permanent failure
        status: Current operation status
        created_at: Timestamp when operation was queued
        last_attempt: Timestamp of last retry attempt
        error: Last error encountered (if any)
        callback: Optional callback to notify when complete
    """
    write_id: str
    scope: str
    data: Dict[str, Any]
    priority: WritePriority = WritePriority.NORMAL
    retry_count: int = 0
    max_retries: int = 3
    status: WriteStatus = WriteStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    last_attempt: Optional[datetime] = None
    error: Optional[str] = None
    callback: Optional[Callable[[str, bool, Optional[str]], None]] = None


class PersistenceManager:
    """
    Manages disk persistence with a producer-consumer queue pattern.
    
    This class maintains a single background thread that processes all write operations
    sequentially, preventing concurrent file access issues. It includes retry logic,
    health monitoring, and comprehensive error reporting.
    
    Usage:
        pm = PersistenceManager("/path/to/storage")
        
        # Queue a write (non-blocking)
        write_id = pm.queue_write("user123", {"profile": {...}})
        
        # Check status later
        status = pm.get_write_status(write_id)
        
        # Wait for critical writes
        pm.wait_for_write(write_id, timeout=5.0)
        
        # Graceful shutdown
        pm.shutdown(wait_for_queue=True)
    """
    
    def __init__(self, storage_path: str, queue_size: int = 1000):
        """
        Initialize the persistence manager.
        
        Args:
            storage_path: Directory where shelf files are stored
            queue_size: Maximum number of pending operations (backpressure)
        """
        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)
        
        # Write queue with size limit for backpressure
        self._write_queue: queue.PriorityQueue = queue.PriorityQueue(maxsize=queue_size)
        
        # Tracking dictionaries
        self._write_status: Dict[str, WriteOperation] = {}
        self._status_lock = threading.Lock()
        self._max_status_tracking = queue_size * 5  # Bound memory leak
        
        # Consumer thread control
        self._consumer_thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()
        self._pause_event = threading.Event()  # For flow control
        
        # Health metrics
        self._total_writes_processed = 0
        self._failed_writes = 0
        self._retry_count = 0
        self._metrics_lock = threading.Lock()
        
        # Start the consumer thread
        self._start_consumer()

    def _prune_status_tracking(self) -> None:
        """Prevents memory leaks by removing old completed status entries."""
        # Note: _status_lock must be held by the caller
        if len(self._write_status) > self._max_status_tracking:
            # Rely on dict insertion order (Python 3.7+) to find oldest
            prunable = [
                wid for wid, op in self._write_status.items()
                if op.status == WriteStatus.COMPLETED
            ]
            # Drop older half of the completed entries in one batch
            to_drop = max(100, len(prunable) // 2)
            for wid in prunable[:to_drop]:
                del self._write_status[wid]
    
    def _start_consumer(self) -> None:
        """Start the background consumer thread if not already running."""
        if self._consumer_thread is None or not self._consumer_thread.is_alive():
            self._shutdown_event.clear()
            self._pause_event.clear()
            self._consumer_thread = threading.Thread(
                target=self._consumer_loop,
                name="PersistenceConsumer",
                daemon=True  # Thread exits when main process exits
            )
            self._consumer_thread.start()
    
    def _consumer_loop(self) -> None:
        """
        Main consumer loop that processes write operations sequentially.
        
        This runs in a single background thread and ensures only one write
        operation occurs at a time, preventing file contention.
        """
        while not self._shutdown_event.is_set():
            try:
                # Check if we should pause (e.g., disk full, too many errors)
                if self._pause_event.is_set():
                    time.sleep(0.1)
                    continue
                
                # Get next operation with timeout to allow shutdown checking
                # PriorityQueue returns items with lowest priority number first
                # So CRITICAL (1) comes before NORMAL (2) before BACKGROUND (3)
                _, operation = self._write_queue.get(timeout=0.5)
                
                # Update status
                with self._status_lock:
                    operation.status = WriteStatus.PROCESSING
                    self._write_status[operation.write_id] = operation
                
                # Process the write
                success, error = self._execute_write(operation)
                
                # Handle result
                if success:
                    with self._status_lock:
                        operation.status = WriteStatus.COMPLETED
                        self._total_writes_processed += 1
                        self._prune_status_tracking()
                    
                    # Notify callback if provided
                    if operation.callback:
                        try:
                            operation.callback(operation.write_id, True, None)
                        except Exception as e:
                            logger.error(f"Callback error for write {operation.write_id}: {e}")
                
                else:
                    self._handle_write_failure(operation, error)
                
                # Mark as done in queue
                self._write_queue.task_done()
                
            except queue.Empty:
                continue  # Timeout, check shutdown
            except Exception as e:
                logger.error(f"Consumer error: {e}")
                time.sleep(0.1)  # Prevent tight loop on persistent errors
    
    def _execute_write(self, operation: WriteOperation) -> tuple[bool, Optional[str]]:
        """
        Execute a single write operation to disk.
        
        Args:
            operation: The write operation to execute
            
        Returns:
            Tuple of (success: bool, error_message: Optional[str])
        """
        operation.last_attempt = datetime.now()
        file_path = os.path.join(self.storage_path, f"{operation.scope}.db")
        
        try:
            # Write to shelf
            with shelve.open(file_path) as db:
                for key, value in operation.data.items():
                    db[key] = value
            
            # Optional: Verify write (can be disabled in production)
            # with shelve.open(file_path) as verify_db:
            #     for key in operation.data:
            #         if verify_db.get(key) != operation.data[key]:
            #             return False, "Verification failed"
            
            return True, None
            
        except Exception as e:
            return False, str(e)
    
    def _handle_write_failure(self, operation: WriteOperation, error: str) -> None:
        """
        Handle a failed write operation with retry logic.
        
        Args:
            operation: The failed operation
            error: Error message from the failure
        """
        operation.error = error
        operation.retry_count += 1
        
        with self._metrics_lock:
            self._retry_count += 1
        
        # Check if we should retry
        if operation.retry_count <= operation.max_retries:
            # Calculate exponential backoff delay
            delay = 0.1 * (2 ** (operation.retry_count - 1))  # 0.1, 0.2, 0.4, 0.8...
            
            with self._status_lock:
                operation.status = WriteStatus.RETRYING
            
            # Re-queue with delay (use timer to avoid blocking consumer)
            def retry():
                time.sleep(delay)
                try:
                    # Put back in queue, giving it a moment if full
                    self._write_queue.put(
                        (operation.priority.value, operation), 
                        block=True, 
                        timeout=2.0
                    )
                except queue.Full:
                    self._handle_write_failure(operation, "Queue remained full during retry")
            
            threading.Thread(target=retry, daemon=True).start()
            
        else:
            # Permanent failure
            with self._status_lock:
                operation.status = WriteStatus.FAILED
                self._failed_writes += 1
                self._write_status[operation.write_id] = operation
            
            # Notify callback of failure
            if operation.callback:
                try:
                    operation.callback(operation.write_id, False, error)
                except Exception as e:
                    logger.error(f"Callback error for failed write {operation.write_id}: {e}")
            
            logger.error(f"Permanent write failure for {operation.scope}: {error}")
    
    def queue_write(
        self, 
        scope: str, 
        data: Dict[str, Any], 
        priority: WritePriority = WritePriority.NORMAL,
        callback: Optional[Callable[[str, bool, Optional[str]], None]] = None,
        max_retries: int = 3,
        block: bool = False,
        timeout: Optional[float] = None
    ) -> Optional[str]:
        """
        Queue a write operation for asynchronous persistence.
        
        Args:
            scope: The scope/namespace to write
            data: Data to persist
            priority: Write priority (CRITICAL, NORMAL, BACKGROUND)
            callback: Optional function to call when write completes/fails
            max_retries: Maximum retry attempts (default 3)
            block: If True, block until queue has space
            timeout: Maximum time to wait if blocking
            
        Returns:
            write_id for tracking, or None if queue is full and non-blocking
        
        Raises:
            queue.Full: If block=True and queue remains full after timeout
        """
        # Generate unique ID for tracking
        write_id = str(uuid.uuid4())
        
        # Create operation
        operation = WriteOperation(
            write_id=write_id,
            scope=scope,
            data=data,
            priority=priority,
            max_retries=max_retries,
            callback=callback
        )
        
        # Store initial status
        with self._status_lock:
            self._write_status[write_id] = operation
        
        try:
            # Queue with priority value (lower = higher priority)
            self._write_queue.put(
                (priority.value, operation), 
                block=block, 
                timeout=timeout
            )
            return write_id
            
        except queue.Full:
            # Clean up status entry if queue failed
            with self._status_lock:
                del self._write_status[write_id]
            
            if block:
                raise  # Re-raise if caller requested blocking
            return None
    
    def get_write_status(self, write_id: str) -> Optional[WriteStatus]:
        """
        Get the current status of a queued write.
        
        Args:
            write_id: The ID returned from queue_write
            
        Returns:
            WriteStatus if found, None otherwise
        """
        with self._status_lock:
            operation = self._write_status.get(write_id)
            return operation.status if operation else None
    
    def wait_for_write(
        self, 
        write_id: str, 
        timeout: Optional[float] = None,
        check_interval: float = 0.01
    ) -> bool:
        """
        Wait for a specific write to complete.
        
        Args:
            write_id: The ID of the write to wait for
            timeout: Maximum time to wait in seconds
            check_interval: How often to check status
            
        Returns:
            True if write completed, False if timeout or write not found
        """
        start_time = time.time()
        
        while True:
            status = self.get_write_status(write_id)
            
            if status is None:
                return False  # Write not found
            
            if status in (WriteStatus.COMPLETED, WriteStatus.FAILED):
                return status == WriteStatus.COMPLETED
            
            if timeout and (time.time() - start_time) > timeout:
                return False
            
            time.sleep(check_interval)
    
    def wait_for_scope(self, scope: str, timeout: Optional[float] = None) -> bool:
        """
        Wait for all pending writes for a specific scope to complete.
        
        Args:
            scope: The scope to wait for
            timeout: Maximum time to wait
            
        Returns:
            True if all writes completed, False if timeout
        """
        start_time = time.time()
        
        while True:
            # Find all pending writes for this scope
            pending = []
            with self._status_lock:
                for op in self._write_status.values():
                    if op.scope == scope and op.status in (
                        WriteStatus.PENDING, 
                        WriteStatus.PROCESSING, 
                        WriteStatus.RETRYING
                    ):
                        pending.append(op.write_id)
            
            if not pending:
                return True
            
            if timeout and (time.time() - start_time) > timeout:
                return False
            
            time.sleep(0.01)

    def wait_all(self, timeout: Optional[float] = None) -> bool:
        """
        Wait for all pending writes to complete.
        
        Args:
            timeout: Maximum time to wait
            
        Returns:
            True if all writes completed, False if timeout
        """
        start_time = time.time()
        
        while True:
            # Find all pending writes
            pending = False
            with self._status_lock:
                for op in self._write_status.values():
                    if op.status in (
                        WriteStatus.PENDING, 
                        WriteStatus.PROCESSING, 
                        WriteStatus.RETRYING
                    ):
                        pending = True
                        break
            
            if not pending:
                return True
            
            if timeout and (time.time() - start_time) > timeout:
                return False
            
            time.sleep(0.01)

    def pause(self) -> None:
        """Pause processing of new writes (useful for maintenance)."""
        self._pause_event.set()
    
    def resume(self) -> None:
        """Resume processing after pause."""
        self._pause_event.clear()
    
    def shutdown(self, wait_for_queue: bool = True, timeout: Optional[float] = None) -> None:
        """
        Gracefully shut down the persistence manager.
        
        Args:
            wait_for_queue: If True, wait for pending writes to complete
            timeout: Maximum time to wait for pending writes
        """
        self._shutdown_event.set()
        
        if wait_for_queue and self._consumer_thread and self._consumer_thread.is_alive():
            try:
                self._write_queue.join()  # Wait for all tasks to be processed
            except:
                pass
            
            self._consumer_thread.join(timeout=timeout)
    
    def load_shard(self, scope: str) -> Dict[str, Any]:
        """
        Load a scope/shard from disk.
        
        Args:
            scope: The scope to load
            
        Returns:
            Dictionary of category → data
        """
        path = os.path.join(self.storage_path, f"{scope}.db")
        data = {}
        
        try:
            with shelve.open(path) as db:
                for key in db:
                    data[key] = db[key]
            return data
        except Exception as e:
            # File doesn't exist yet or is corrupted
            logger.warning(f"Error loading {scope} (may not exist yet): {e}")
            return {}
    
    def get_all_shards(self) -> List[str]:
        """
        Get list of all scopes currently on disk.
        
        Returns:
            List of scope names
        """
        scopes = set()
        for f in os.listdir(self.storage_path):
            if ".db" in f:
                # Handles 'scope.db', 'scope.db.dat', 'scope.db.dir', etc.
                scope = f.split(".db")[0]
                scopes.add(scope)
        return list(scopes)
    
    def get_queue_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the write queue and processing.
        
        Returns:
            Dictionary with queue statistics
        """
        with self._metrics_lock:
            queue_size = self._write_queue.qsize()
            
            # Count pending operations by status
            status_counts = {}
            with self._status_lock:
                for op in self._write_status.values():
                    status_counts[op.status.value] = status_counts.get(op.status.value, 0) + 1
            
            return {
                "queue_size": queue_size,
                "queue_max": self._write_queue.maxsize,
                "total_processed": self._total_writes_processed,
                "failed_writes": self._failed_writes,
                "retry_count": self._retry_count,
                "status_breakdown": status_counts,
                "consumer_alive": self._consumer_thread.is_alive() if self._consumer_thread else False,
                "paused": self._pause_event.is_set()
            }
    
    def clear_failed_writes(self) -> int:
        """
        Clear all failed write records from tracking.
        
        Returns:
            Number of records cleared
        """
        count = 0
        with self._status_lock:
            failed_ids = [
                wid for wid, op in self._write_status.items()
                if op.status == WriteStatus.FAILED
            ]
            for wid in failed_ids:
                del self._write_status[wid]
                count += 1
        return count