from typing import Any, TypedDict, List, Final

# ==========================================
# 1. Path & Operator Constants
# ==========================================
PATH_SEP: Final[str] = "::"

# Decoupled Operators
OP_MERGE: Final[str] = "|="    # Strict Dictionary Merge
OP_ADD: Final[str] = "+="      # Strict Numeric Addition
OP_SUB: Final[str] = "-="      # Strict Numeric Subtraction
OP_MULT: Final[str] = "*="     # Strict Numeric Multiplication
OP_DIV: Final[str] = "/="      # Strict Numeric Division
OP_INC: Final[str] = "++"      # Increment
OP_DEC: Final[str] = "--"      # Decrement
OP_APPEND: Final[str] = "+"     # List Append

# ==========================================
# 2. Cache Settings
# ==========================================
# This controls how many scopes stay "pinned" in RAM strongly
DEFAULT_HOT_BUFFER_SIZE: Final[int] = 100 #items kept

# ==========================================
# 2. Mutation Schemas
# ==========================================
class DirectMutation(TypedDict):
    """Schema for primary mutations within a category."""
    paths: List[str]
    values: List[Any]

class FollowUpMutation(TypedDict):
    """Schema for secondary mutations across different categories."""
    paths: List[str]
    category: str
    values: List[Any]

# ==========================================
# 3. Common Error Definitions
# ==========================================
class CacheError:
    """Standardized error templates for the package."""
    
    # Initialization
    INIT_REQUIRED = "[Cache]: 'storage_path' is required for initial setup!"
    
    # Path Parsing
    EMPTY_SEGMENT = "Path Error: Empty segment in '{path}'. Check for '::::'."
    MALFORMED_BRACKET = "Path Error: Malformed bracket operation in '{path}'."
    
    # Type & Logic Errors
    # Use .format(op=..., expected=..., actual=...)
    TYPE_MISMATCH = "Type Error: Operator '{op}' expects {expected}, but found {actual} at '{path}'."
    NOT_FOUND = "Lookup Error: Path '{path}' does not exist."
    ZERO_DIVISION = "Math Error: Division by zero at '{path}'."
    
    # Batch / Integrity
    BATCH_SIZE_MISMATCH = "Batch Error: Paths ({p_len}) and Values ({v_len}) count mismatch."
    TRANSACTION_ROLLBACK = "Transaction Error: Patch failed. Changes rolled back. Reason: {reason}"
    
    # Persistence
    DISK_IO_ERROR = "Disk Error: Failed to access shard '{shard}'. {error}"