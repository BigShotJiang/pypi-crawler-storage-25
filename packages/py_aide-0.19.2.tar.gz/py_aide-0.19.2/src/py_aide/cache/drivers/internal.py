import threading
import copy
import time
import logging
import queue
from typing import Any, List, Callable, Dict, Union, Optional, Tuple

from ..cacheConfig import (
    PATH_SEP,
    DEFAULT_HOT_BUFFER_SIZE,
    DirectMutation,
    FollowUpMutation
)
from ..memory import HybridMemory
from ..persistence import PersistenceManager, WritePriority, ConsistencyLevel
from ..cacheTransaction import TransactionManager
from ...response import Response, ok, error
from ..base import BaseCache

logger = logging.getLogger(__name__)

class InternalCache(BaseCache):
    """
    Thread-safe internal cache driver (Memory + Disk Persistence).
    """
    
    def __init__(
        self,
        storage_path: str,
        hot_buffer_size: int = DEFAULT_HOT_BUFFER_SIZE,
        max_queue_size: int = 1000,
        critical_threshold: int = 80,
        warning_threshold: int = 60,
        enable_auto_promotion: bool = True,
        default_write_timeout: float = 5.0
    ):
        self.storage_path = storage_path
        self.hot_buffer_size = hot_buffer_size
        self.max_queue_size = max_queue_size
        self.critical_threshold = critical_threshold
        self.warning_threshold = warning_threshold
        self.enable_auto_promotion = enable_auto_promotion
        self.default_write_timeout = default_write_timeout
        
        # Core components
        self.memory = HybridMemory(buffer_size=hot_buffer_size)
        self._storage: Dict[str, Dict[str, Any]] = {}
        
        self.persistence = PersistenceManager(
            storage_path=storage_path,
            queue_size=max_queue_size
        )
        
        self._lock = threading.RLock()

    def _get_queue_health(self, shelf_path: str) -> Dict[str, Any]:
        stats = self.persistence.get_queue_stats()
        queue_size = stats["queue_size"]
        max_size = stats["queue_max"]
        
        fill_percentage = (queue_size / max_size) * 100 if max_size > 0 else 0
        
        return {
            "queue_size": queue_size,
            "max_size": max_size,
            "fill_percentage": fill_percentage,
            "is_critical": fill_percentage >= self.critical_threshold,
            "is_warning": fill_percentage >= self.warning_threshold
        }

    def _determine_consistency(self, shelf_path: str, disk_write_wait: bool) -> Tuple[ConsistencyLevel, bool]:
        if not disk_write_wait:
            return ConsistencyLevel.BACKGROUND, False
        
        health = self._get_queue_health(shelf_path)
        if not self.enable_auto_promotion:
            return ConsistencyLevel.DURABLE, False
        
        if health["is_critical"]:
            return ConsistencyLevel.CRITICAL, True
        elif health["is_warning"]:
            return ConsistencyLevel.CRITICAL, True
        else:
            return ConsistencyLevel.DURABLE, False

    def _get_composite_key(self, scope: str, category: str) -> str:
        return f"{scope}{PATH_SEP}{category}"

    def read(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        path: Optional[str] = None, 
        format_callback: Optional[Callable] = None,
        bypass_memory: bool = False
    ) -> Response:
        cat_val = category if isinstance(category, str) else category.value
        comp_key = self._get_composite_key(scope, cat_val)
        
        data = None
        if not bypass_memory:
            data = self.memory.get(comp_key)
        
        if data is None:
            scope_data = self.persistence.load_shard(scope)
            data = scope_data.get(cat_val)
            
            if data is not None:
                with self._lock:
                    if scope not in self._storage:
                        self._storage[scope] = {}
                    self._storage[scope][cat_val] = data
                    self.memory.set(comp_key, data)

        if data is None:
            return error(message=f"Not found: {scope}::{cat_val}")

        result = data
        if path:
            try:
                for key in path.split(PATH_SEP):
                    if key:
                        result = result[key]
            except (KeyError, TypeError) as e:
                return error(message=f"Path error at '{path}': {str(e)}")

        if format_callback:
            try:
                result = format_callback(copy.deepcopy(result))
            except Exception as e:
                return error(message=f"Format callback error: {str(e)}")

        return ok(data=result)

    def write(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        data: Any, 
        format_callback: Optional[Callable] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: WritePriority = WritePriority.NORMAL
    ) -> Response:
        cat_val = category if isinstance(category, str) else category.value
        comp_key = self._get_composite_key(scope, cat_val)
        
        try:
            processed_data = format_callback(copy.deepcopy(data)) if format_callback else data
        except Exception as e:
            return error(message=f"Format callback error: {str(e)}")

        consistency, was_promoted = self._determine_consistency(shelf_path, disk_write_wait)
        write_timeout = timeout if timeout is not None else self.default_write_timeout

        with self._lock:
            if scope not in self._storage:
                self._storage[scope] = self.persistence.load_shard(scope)
            
            self._storage[scope][cat_val] = processed_data
            self.memory.set(comp_key, processed_data)

        scope_data = self._storage[scope]
        
        try:
            block_for_queue = (consistency == ConsistencyLevel.CRITICAL)
            write_id = self.persistence.queue_write(
                scope=scope,
                data=scope_data,
                priority=priority,
                block=block_for_queue,
                timeout=write_timeout if block_for_queue else None
            )
            
            if write_id is None and consistency == ConsistencyLevel.CRITICAL:
                return error(message="Write failed: Queue is full")
            
            if write_id is None:
                return ok(data={"write_id": None, "consistency": consistency.name, "warning": "Queue full"})
            
            if consistency in (ConsistencyLevel.DURABLE, ConsistencyLevel.CRITICAL):
                success = self.persistence.wait_for_write(write_id, timeout=write_timeout)
                if not success:
                    return error(message="Write timed out")
            
            return ok(data={"write_id": write_id, "consistency": consistency.name, "was_promoted": was_promoted})
            
        except queue.Full:
            return error(message="Write failed: Queue is full")
        except Exception as e:
            return error(message=f"Write failed: {str(e)}")

    def patch(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        direct_mutations: List[DirectMutation],
        follow_up_mutations: Optional[List[FollowUpMutation]] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: WritePriority = WritePriority.CRITICAL
    ) -> Response:
        cat_val = category if isinstance(category, str) else category.value
        consistency, was_promoted = self._determine_consistency(shelf_path, disk_write_wait)
        write_timeout = timeout if timeout is not None else self.default_write_timeout
        
        with self._lock:
            if scope not in self._storage:
                self._storage[scope] = self.persistence.load_shard(scope)

            try:
                success = TransactionManager.execute_patch(
                    storage=self._storage,
                    scope=scope,
                    mutations=direct_mutations,
                    follow_ups=follow_up_mutations
                )

                if not success:
                    return error(message="Patch transaction failed")

                primary_key = self._get_composite_key(scope, cat_val)
                self.memory.set(primary_key, self._storage[scope].get(cat_val))

                scope_data = self._storage[scope]
                block_for_queue = (consistency == ConsistencyLevel.CRITICAL)
                
                write_id = self.persistence.queue_write(
                    scope=scope,
                    data=scope_data,
                    priority=priority,
                    block=block_for_queue,
                    timeout=write_timeout if block_for_queue else None
                )
                
                if write_id is None and consistency == ConsistencyLevel.CRITICAL:
                    return error(message="Patch failed: Queue is full")
                
                if consistency in (ConsistencyLevel.DURABLE, ConsistencyLevel.CRITICAL):
                    success = self.persistence.wait_for_write(write_id, timeout=write_timeout)
                    if not success:
                        return error(message="Patch timed out")
                
                return ok(data={"write_id": write_id, "consistency": consistency.name, "was_promoted": was_promoted})
                
            except queue.Full:
                return error(message="Patch failed: Queue is full")
            except Exception as e:
                return error(message=f"Patch failed: {str(e)}")

    def shutdown(self, wait_for_queue: bool = True, timeout: Optional[float] = None) -> None:
        if wait_for_queue:
            self.persistence.wait_all(timeout)
        self.persistence.shutdown(wait_for_queue=False)
