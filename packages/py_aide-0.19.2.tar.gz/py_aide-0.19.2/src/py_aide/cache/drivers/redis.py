import json
import time
import logging
from typing import Any, List, Callable, Dict, Union, Optional
from ..cacheConfig import PATH_SEP, DirectMutation, FollowUpMutation
from ..cacheEngine import CacheEngine
from ...response import Response, ok, error
from ..base import BaseCache

logger = logging.getLogger(__name__)

class RedisCache(BaseCache):
    """
    Redis-backed cache driver for py_aide.
    
    Data is stored in Redis Hashes per scope:
    - Key: pa:c:{scope} (Hash)
    - Field: category
    - Value: JSON string
    """

    def __init__(self, *, host: str = "localhost", port: int = 6379, password: str = None, db: int = 0, **kwargs):
        self.host = host
        self.port = port
        self.password = password
        self.db = db
        self.kwargs = kwargs
        self._client = None
        
        try:
            import redis
            self.redis_lib = redis
        except ImportError:
            self.redis_lib = None

    def _get_client(self):
        if self.redis_lib is None:
            return None
        
        if self._client is None:
            try:
                self._client = self.redis_lib.Redis(
                    host=self.host,
                    port=self.port,
                    password=self.password,
                    db=self.db,
                    decode_responses=True
                )
            except Exception:
                return None
        return self._client

    def _ensure_client(self):
        client = self._get_client()
        if client is None:
            if self.redis_lib is None:
                raise ImportError("The 'redis' library is required for RedisCache. Install it with 'pip install redis'.")
            raise ConnectionError("Failed to connect to Redis server.")
        return client

    def _get_scope_key(self, scope: str) -> str:
        return f"pa:c:{scope}"

    def read(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        path: Optional[str] = None, 
        format_callback: Optional[Callable] = None,
        bypass_memory: bool = False
    ) -> Response:
        try:
            client = self._ensure_client()
            cat_val = category if isinstance(category, str) else category.value
            
            raw_data = client.hget(self._get_scope_key(scope), cat_val)
            if not raw_data:
                return error(message=f"Not found: {scope}::{cat_val}")
            
            data = json.loads(raw_data)
            
            result = data
            if path:
                try:
                    for key in path.split(PATH_SEP):
                        if key:
                            result = result[key]
                except (KeyError, TypeError) as e:
                    return error(message=f"Path error at '{path}': {str(e)}")

            if format_callback:
                result = format_callback(result)
                
            return ok(data=result)
        except Exception as e:
            return error(message=str(e))

    def write(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        data: Any, 
        format_callback: Optional[Callable] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: Any = None
    ) -> Response:
        try:
            client = self._ensure_client()
            cat_val = category if isinstance(category, str) else category.value
            
            processed_data = format_callback(data) if format_callback else data
            
            client.hset(self._get_scope_key(scope), cat_val, json.dumps(processed_data))
            
            return ok(data={"scope": scope, "category": cat_val})
        except Exception as e:
            return error(message=str(e))

    def patch(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        direct_mutations: List[DirectMutation],
        follow_up_mutations: Optional[List[FollowUpMutation]] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: Any = None
    ) -> Response:
        """
        Atomic patch using Redis transaction.
        """
        try:
            client = self._ensure_client()
            scope_key = self._get_scope_key(scope)
            cat_val = category if isinstance(category, str) else category.value
            
            # For Redis, we need to fetch the current state, apply mutations, and write back.
            # To be atomic, we use WATCH.
            with client.pipeline() as pipe:
                while True:
                    try:
                        pipe.watch(scope_key)
                        
                        # Load required categories
                        categories_to_load = {cat_val}
                        if follow_up_mutations:
                            for fup in follow_up_mutations:
                                categories_to_load.add(fup["category"])
                        
                        raw_data_map = pipe.hmget(scope_key, list(categories_to_load))
                        data_map = {}
                        for i, cat in enumerate(categories_to_load):
                            raw = raw_data_map[i]
                            data_map[cat] = json.loads(raw) if raw else {}
                        
                        # Apply direct mutations
                        for mut in direct_mutations:
                            CacheEngine.apply_mutation(data_map[cat_val], mut["path"], mut["value"])
                        
                        # Apply follow-up mutations
                        if follow_up_mutations:
                            for fup in follow_up_mutations:
                                f_cat = fup["category"]
                                CacheEngine.apply_mutation(data_map[f_cat], fup["path"], fup["value"])
                        
                        # Write back
                        pipe.multi()
                        for cat, data in data_map.items():
                            pipe.hset(scope_key, cat, json.dumps(data))
                        
                        pipe.execute()
                        break # Success
                    except self.redis_lib.WatchError:
                        continue # Retry if someone else modified the scope
            
            return ok()
        except Exception as e:
            return error(message=str(e))

    def shutdown(self, wait_for_queue: bool = True, timeout: Optional[float] = None) -> None:
        pass
