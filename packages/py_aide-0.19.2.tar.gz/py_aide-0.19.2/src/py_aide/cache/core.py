import threading
import logging
from typing import Any, List, Callable, Union, Optional
from .base import BaseCache
from .drivers.internal import InternalCache
from .drivers.redis import RedisCache
from .cacheConfig import DEFAULT_HOT_BUFFER_SIZE, DirectMutation, FollowUpMutation
from .persistence import WritePriority
from ..response import Response
from ..enums import CacheEngine

logger = logging.getLogger(__name__)

class Cache:
    """
    Cache orchestrator that delegates to specific storage drivers.
    
    Supported Engines:
    - CacheEngine.INTERNAL: Local memory + Disk persistence (Default)
    - CacheEngine.REDIS: Redis-backed distributed cache
    """
    
    _instances = {}
    _class_lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        """Multiton pattern: maintains a single instance per unique configuration."""
        # Create a unique key based on engine and its primary config
        engine = kwargs.get("engine", CacheEngine.INTERNAL)
        if isinstance(engine, str):
            engine = CacheEngine(engine.lower())
            
        if engine == CacheEngine.REDIS:
            # Key by host and port
            host = kwargs.get("host", "localhost")
            port = kwargs.get("port", 6379)
            db = kwargs.get("db", 0)
            instance_key = f"redis::{host}:{port}:{db}"
        else:
            # Key by storage path
            storage_path = kwargs.get("storage_path") or args[0] if args else "default_cache"
            instance_key = f"internal::{storage_path}"

        with cls._class_lock:
            if instance_key not in cls._instances:
                cls._instances[instance_key] = super(Cache, cls).__new__(cls)
            return cls._instances[instance_key]

    def __init__(
        self,
        storage_path: str = "cache",
        hot_buffer_size: int = DEFAULT_HOT_BUFFER_SIZE,
        max_queue_size: int = 1000,
        engine: CacheEngine | str = CacheEngine.INTERNAL,
        **kwargs
    ):
        """
        Initialize the cache orchestrator.
        """
        if hasattr(self, "_initialized") and self._initialized:
            return
            
        # Normalize engine
        self.engine = engine if isinstance(engine, CacheEngine) else CacheEngine(str(engine).lower())
        
        if self.engine == CacheEngine.REDIS:
            self.driver = RedisCache(**kwargs)
        else:
            self.driver = InternalCache(
                storage_path=storage_path,
                hot_buffer_size=hot_buffer_size,
                max_queue_size=max_queue_size,
                **kwargs
            )
            
        self._initialized = True
        logger.info(f"Cache initialized with engine={self.engine.name}")

    def read(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        path: Optional[str] = None, 
        format_callback: Optional[Callable] = None,
        bypass_memory: bool = False
    ) -> Response:
        """Read data from cache."""
        return self.driver.read(
            shelf_path=shelf_path,
            scope=scope,
            category=category,
            path=path,
            format_callback=format_callback,
            bypass_memory=bypass_memory
        )

    def write(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        data: Any, 
        format_callback: Optional[Callable] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: WritePriority = WritePriority.NORMAL
    ) -> Response:
        """Write data to cache."""
        return self.driver.write(
            shelf_path=shelf_path,
            scope=scope,
            category=category,
            data=data,
            format_callback=format_callback,
            disk_write_wait=disk_write_wait,
            timeout=timeout,
            priority=priority
        )

    def patch(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        direct_mutations: List[DirectMutation],
        follow_up_mutations: Optional[List[FollowUpMutation]] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: WritePriority = WritePriority.CRITICAL
    ) -> Response:
        """Perform a transactional patch operation."""
        return self.driver.patch(
            shelf_path=shelf_path,
            scope=scope,
            category=category,
            direct_mutations=direct_mutations,
            follow_up_mutations=follow_up_mutations,
            disk_write_wait=disk_write_wait,
            timeout=timeout,
            priority=priority
        )

    def shutdown(self, wait_for_queue: bool = True, timeout: Optional[float] = None) -> None:
        """Gracefully shut down the cache."""
        self.driver.shutdown(wait_for_queue=wait_for_queue, timeout=timeout)