from collections import OrderedDict
from typing import Any, Optional

class HybridMemory:
    """
    In-memory LRU Cache.
    Replaces the previous WeakValueDictionary implementation which was
    incompatible with standard Python dicts/lists.
    """

    def __init__(self, buffer_size: int = 100):
        # We use an OrderedDict to maintain true LRU semantics
        self._cache: OrderedDict[str, Any] = OrderedDict()
        self.max_size = buffer_size

    def get(self, key: str) -> Optional[Any]:
        """Retrieves an item and marks it as recently used."""
        if key not in self._cache:
            return None
        self._cache.move_to_end(key)
        return self._cache[key]

    def set(self, key: str, value: Any):
        """Stores an item, evicting the oldest if at capacity."""
        if key in self._cache:
            self._cache.move_to_end(key)
        self._cache[key] = value
        if len(self._cache) > self.max_size:
            self._cache.popitem(last=False)

    def clear_hot_zone(self):
        """Clears the entire memory cache."""
        self._cache.clear()

    @property
    def stats(self) -> dict:
        """Returns the current state of the memory layers."""
        return {
            "hot_entries": len(self._cache),
            "max_size": self.max_size
        }