from abc import ABC, abstractmethod
from typing import Any, Optional, List, Callable, Union
from ..response import Response

class BaseCache(ABC):
    """
    Abstract Base Class for all py_aide cache drivers.
    """

    @abstractmethod
    def read(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        path: Optional[str] = None, 
        format_callback: Optional[Callable] = None,
        bypass_memory: bool = False
    ) -> Response:
        pass

    @abstractmethod
    def write(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        data: Any, 
        format_callback: Optional[Callable] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: Any = None
    ) -> Response:
        pass

    @abstractmethod
    def patch(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        direct_mutations: List[Any],
        follow_up_mutations: Optional[List[Any]] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: Any = None
    ) -> Response:
        pass

    @abstractmethod
    def shutdown(self, wait_for_queue: bool = True, timeout: Optional[float] = None) -> None:
        pass
