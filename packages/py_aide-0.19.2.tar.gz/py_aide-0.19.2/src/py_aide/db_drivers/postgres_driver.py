import json
import logging
from typing import Any, Optional, Union, List
from ..response import ok, error, Response
from ..db_base import BaseDbDriver
from ..postgres import PostgresJSONParser

logger = logging.getLogger(__name__)

class PostgresDriver(BaseDbDriver):
    """
    Postgres driver implementation for py_aide.
    Requires 'psycopg2' or 'psycopg' library.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        user: str = "postgres",
        password: str = "",
        database: str = "postgres",
        readonly: bool = False,
        tables: Optional[dict] = None,
        **kwargs
    ):
        self.readonly = readonly
        self.tables = tables or {}
        self.config = {
            "host": host,
            "port": port,
            "user": user,
            "password": password,
            "database": database,
            **kwargs
        }
        self.conn = None
        self.cursor = None
        
        try:
            import psycopg2
            from psycopg2.extras import RealDictCursor
            self.lib = psycopg2
            self.cursor_factory = RealDictCursor
        except ImportError:
            try:
                import psycopg
                self.lib = psycopg
                self.cursor_factory = None # psycopg3 uses different dict cursor
            except ImportError:
                self.lib = None

    def _ensure_lib(self):
        if self.lib is None:
            raise ImportError("Postgres library (psycopg2 or psycopg) is required. Install with 'pip install psycopg2-binary'.")

    def connect(self):
        self._ensure_lib()
        if self.conn is None:
            # Note: Basic connection logic. In production, we'd use a pool.
            self.conn = self.lib.connect(**self.config)
            self.cursor = self.conn.cursor(cursor_factory=self.cursor_factory)
        return self.conn

    def disconnect(self):
        if self.conn:
            self.cursor.close()
            self.conn.close()
            self.conn = None
            self.cursor = None

    def _translate_query(self, query: str) -> str:
        """
        Translates SQLite-style queries and JSON paths to Postgres.
        Uses PostgresJSONParser for DSL parsing, and replaces ? with %s.
        """
        # 1. Handle DSL syntax (e.g. table::path[+=])
        translated = PostgresJSONParser.parse_condition(query)
        
        # 2. Replace SQLite positional placeholders with Postgres
        translated = translated.replace("?", "%s")
        
        return translated

    def insert(self, *, table: str, data: list) -> Response:
        try:
            if not data: return ok()
            columns = data[0].keys() if isinstance(data[0], dict) else None
            
            if columns:
                cols_str = ", ".join([f'"{c}"' for c in columns])
                placeholders = ", ".join(["%s" for _ in columns])
                query = f'INSERT INTO "{table}" ({cols_str}) VALUES ({placeholders})'
                values = [tuple(row.values()) for row in data]
            else:
                placeholders = ", ".join(["%s" for _ in range(len(data[0]))])
                query = f'INSERT INTO "{table}" VALUES ({placeholders})'
                values = data

            self.cursor.executemany(query, values)
            return ok()
        except Exception as e:
            return error(message=str(e))

    def update(self, *, table: str, columns: list, column_data: list, condition: str, condition_data: list) -> Response:
        try:
            parsed_cols, new_values = PostgresJSONParser.parse_write_columns(columns=columns, values=column_data)
            set_clause = ", ".join(parsed_cols)
            parsed_condition = self._translate_query(condition)
            query = f'UPDATE "{table}" SET {set_clause} WHERE {parsed_condition}'
            
            # The flattened_values now have lists json.dump'ed
            self.cursor.execute(query, new_values + condition_data)
            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def delete(self, *, table: str, condition: str, condition_data: list) -> Response:
        try:
            translated_condition = self._translate_query(condition)
            query = f'DELETE FROM "{table}" WHERE {translated_condition}'
            self.cursor.execute(query, condition_data)
            return ok(data={"deleted_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def fetch(self, *, table: str, columns: list, condition: Optional[str] = None, condition_data: Optional[list] = None, limit: int = 1000, offset: int = 0) -> Response:
        try:
            parsed_columns = [PostgresJSONParser.parse_read_column(column_string=c) for c in columns]
            cols = ", ".join(parsed_columns)
            query = f'SELECT {cols} FROM "{table}"'
            
            if condition:
                query += f" WHERE {self._translate_query(condition)}"
                
            query += " LIMIT %s OFFSET %s"
            params = (condition_data or []) + [limit, offset]
            
            self.cursor.execute(query, params)
            
            # psycopg2 RealDictCursor already returns dict-like objects
            rows = [dict(row) for row in self.cursor.fetchall()]
            
            return ok(data=self._parse_json_results(rows))
        except Exception as e:
            return error(message=str(e))

    def execute(self, *, query: str, data: Optional[list] = None) -> Response:
        try:
            translated_query = self._translate_query(query)
            is_select = translated_query.strip().lower().startswith("select")
            
            self.cursor.execute(translated_query, data or [])
            
            if is_select:
                rows = [dict(row) for row in self.cursor.fetchall()]
                return ok(data=self._parse_json_results(rows))
            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            return error(message=str(e))

    def commit(self) -> Response:
        try:
            self.conn.commit()
            return ok()
        except Exception as e:
            return error(message=str(e))

    def rollback(self) -> None:
        try:
            self.conn.rollback()
        except:
            pass

    def _parse_json_results(self, rows: list[dict]) -> list[dict]:
        """Auto-parse JSON strings back to dict/list if they look like JSON."""
        for row in rows:
            for key, value in row.items():
                if isinstance(value, str):
                    stripped = value.strip()
                    if stripped.startswith(("[", "{")) and stripped.endswith(("]", "}")):
                        try:
                            row[key] = json.loads(stripped)
                        except:
                            pass
        return rows
