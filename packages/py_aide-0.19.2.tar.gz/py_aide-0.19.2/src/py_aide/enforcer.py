from . import structures 
import inspect
from functools import wraps
import types

# --- INTERNAL CONFIGURATION ---
ENFORCER_CONFIG = {
    "MAX_ARGS": 8,
    "REQUIRE_DOCSTRING": True,
    "STRICT_SIGNATURE": True,
    "REQUIRE_HINTS": True  # Ensures every arg and return has a hint
}

def enforce_requirements(func):
    sig = inspect.signature(func)
    params = sig.parameters
    param_names = list(params.keys())
    num_params = len(params)

    # Intelligently detect if this is a method (instance or class) without hardcoding variable names
    # Methods have a '.' in their qualname (e.g., 'MyClass.my_method')
    is_method = '.' in func.__qualname__ and '<locals>' not in func.__qualname__
    implicit_first_arg = param_names[0] if is_method and param_names else None

    # Docstring Check
    if ENFORCER_CONFIG["REQUIRE_DOCSTRING"]:
        doc = func.__doc__
        if not doc or not doc.strip():
            raise AttributeError(f"Function '{func.__name__}' must have a non-empty docstring.")

    #Argument Count Check
    if num_params > ENFORCER_CONFIG["MAX_ARGS"]:
        raise ValueError(f"Function '{func.__name__}' exceeds max args ({ENFORCER_CONFIG['MAX_ARGS']}).")

    # Type Hint Check
    if ENFORCER_CONFIG["REQUIRE_HINTS"]:
        # Check Parameters
        for name, p in params.items():
            if name == implicit_first_arg:
                continue

            if p.annotation is inspect.Parameter.empty:
                raise TypeError(f"Parameter '{name}' in '{func.__name__}' is missing a type hint.")
        
        # Check Return Hint
        if sig.return_annotation is inspect.Signature.empty:
            raise TypeError(f"Function '{func.__name__}' is missing a return type hint (->).")

    # Signature Check
    if ENFORCER_CONFIG["STRICT_SIGNATURE"] and num_params > 0:        
        has_pos_only = any(p.kind == p.POSITIONAL_ONLY for p in params.values())
        has_kw_only = any(p.kind == p.KEYWORD_ONLY for p in params.values())
        
        if not (has_pos_only or has_kw_only):
            raise SyntaxError(
                f"Function '{func.__name__}' must use '/' or '*' to define calling conventions."
            )
        

    def _validate_inputs(bound_args):
        for name, value in bound_args.arguments.items():
            if name == implicit_first_arg:
                continue

            hint = params[name].annotation
            res = structures.Validator.validate(value, hint)
            if not res:
                raise TypeError(
                    f"Input Error at function::{func.__name__}, argument::{name} {res.log}"
                )

    def _validate_return(result):
        res_ret = structures.Validator.validate(result, sig.return_annotation)
        if not res_ret:
            raise TypeError(
                f"Return Error:: function-->{func.__name__} returned {res_ret.log}"
            )

    def _bind_args(*args, **kwargs):
        try:
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            return bound_args
        except TypeError as e:
            p_names = list(sig.parameters.keys())
            for name, p in sig.parameters.items():
                if name == implicit_first_arg:
                    continue
                if p.kind == inspect.Parameter.POSITIONAL_ONLY and name in kwargs:
                    raise TypeError(
                        f"Runtime Call Error: Parameter '{name}' in '{func.__name__}' "
                        f"is POSITIONAL-ONLY (before '/') but you passed '{name}={kwargs[name]}'."
                    ) from None
                if p.kind == inspect.Parameter.KEYWORD_ONLY and p_names.index(name) < len(args):
                    raise TypeError(
                        f"Runtime Calling Error: Parameter '{name}' in '{func.__name__}' "
                        f"is KEYWORD-ONLY (after '*') but you passed the value '{args[p_names.index(name)]}' positionally."
                    ) from None
            raise TypeError(f"Binding Error in '{func.__name__}': {e}") from None

    if inspect.iscoroutinefunction(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            bound_args = _bind_args(*args, **kwargs)
            _validate_inputs(bound_args)
            
            result = await func(*args, **kwargs)
            
            _validate_return(result)
            return result
        return async_wrapper
    else:
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            bound_args = _bind_args(*args, **kwargs)
            _validate_inputs(bound_args)
            
            result = func(*args, **kwargs)
            
            _validate_return(result)
            return result
        return sync_wrapper