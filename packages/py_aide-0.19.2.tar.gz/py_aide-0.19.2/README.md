# 🛡️ py_aide

**Modern Python 3.11+ Framework: Flask/FastAPI Orchestration & Strict Runtime Enforcement**

`py_aide` is a robust, developer-centric framework designed to bring safety, structure, and consistency to Python web applications. It provides a unique "Strict Runtime Enforcement" layer that ensures your code remains clean, documented, and type-safe at execution time.

---

## 🚀 Key Features

- **Strict Runtime Enforcement**: A powerful decorator that enforces type hints, docstrings, and calling conventions at runtime.
- **Unified Server Portal**: Seamlessly orchestrate Flask and FastAPI applications with shared security gates.
- **Circuit Breaker Resilience**: Industrial-grade protection against cascading failures.
- **Thread-Safe SQL**: A thread-level multiton SQLite manager with automatic JSON serialization and a custom DSL.
- **Modern Security**: Argon2id password hashing with background rehashing and Fernet-based encryption.
- **Enterprise HTTP Client**: A standardized, "always resolve" HTTP client with built-in retries and interceptors.

---

## 📚 Documentation Roadmap

We recommend exploring the framework in this order:

### ⚙️ Core System
- [**Structural Enforcement**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/ENFORCER.md): Learn about the `@enforce_requirements` decorator and the validation engine.
- [**Global Utilities**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/UTILS.md): Discover helpers for dates, image processing, secure codes, and file system operations.

### 🌐 Server & API
- [**Service Portals**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/SERVERS.md): Documentation for Flask/FastAPI orchestration, security gates, and WebSockets.
- [**HTTP Client & Response**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/REQUESTS.md): Master the "Always Resolve" strategy and the unified `Response` protocol.

### 🧵 Persistence & Concurrency
- [**Database Orchestration**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/DATABASE.md): Deep dive into thread-safe SQLite and the powerful **JSON DSL**.
- [**Hybrid Cache**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/CACHE.md): Lightning-fast memory access with non-blocking disk persistence.
- [**Threading & Buffers**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/THREADING.md): Learn how to use persistent queues and non-blocking write buffers.
- [**Resilience & Circuits**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/CIRCUITS.md): Protecting your services with the Circuit Breaker pattern.

### 🔐 Security
- [**Security & Identity**](https://gitlab.com/vicaniddouglas/py_aide/-/blob/main/docs/SECURITY.md): Hashing, Token management, and Encryption standards.

---

## ⚙️ Core Philosophy: Strict Enforcement

At the heart of `py_aide` is the `@enforce_requirements` decorator. It prevents "sloppy" code by failing early (at boot-time or runtime) if your contracts are violated.

```python
from py_aide.enforcer import enforce_requirements
from py_aide.customTypes import Options

@enforce_requirements
def create_user(*, name: str, role: Options[str, ["admin", "user"]]) -> dict:
    """Creates a new user record with runtime type and choice validation."""
    return {"name": name, "role": role}
```

---

## 📦 Installation
```bash
pip install py_aide
```

> **Note**: `py_aide` requires Python 3.11+ and is currently optimized for Linux environments.

---

## 📄 License
This project is licensed under the **MIT License**.

## 👥 Authors
- **Kakuru Douglas** - [vicaniddouglas@gmail.com](mailto:vicaniddouglas@gmail.com)
