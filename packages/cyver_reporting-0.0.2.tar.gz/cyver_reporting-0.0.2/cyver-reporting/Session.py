#!/usr/bin/env python3

from .Exceptions import (
    Cyver2FARequired, CyverAuthError, CyverDataValidationError, CyverHTTPError,
    CyverNotFoundError, CyverPermissionError, CyverRateLimitError,
)
from .Utils import _validate_jwt_token, _validate_uuid

from collections.abc import Callable, Iterator
from base64 import b64decode, b64encode
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from hashlib import md5
from json import dumps, loads
import logging
import os
from os import urandom
from pathlib import Path
from platformdirs import user_cache_dir
from requests import Request, RequestException, Session
from requests.adapters import HTTPAdapter
import threading
from urllib3.util.retry import Retry


CACHE_ITERATIONS = 600000
CACHE_RANDOM_BYTES = 16
REQUESTS_TIMEOUT = 30
REQUESTS_USER_AGENT = "curl/8.7.1"


logger = logging.getLogger(__name__)


class CyverSession:
    """
        Base class for managing authenticated sessions with the Cyver
        Pentest Management API. Handles token caching, automatic token
        refresh, 2FA, and the underlying HTTP transport.

        Supports two mutually exclusive authentication modes:

        **Username / password (default)**
            Call ``authenticate(portal, username, password)`` after
            construction. Tokens are cached and refreshed automatically::

                with PentesterSession() as client:
                    client.authenticate(portal, username, password)
                    projects = list(client.get_all_projects())

        **Static API key**
            Pass ``portal`` and ``api_key`` to the constructor. The session
            is immediately ready; ``authenticate()`` must not be called::

                with PentesterSession(portal="app.cyver.io", api_key="sk-...") as client:
                    projects = list(client.get_all_projects())
    """

    def __init__(self, portal: str | None = None, api_key: str | None = None) -> None:
        """
            Initialises token state, a thread-safety lock, and a shared
            HTTP session pre-configured with a User-Agent header and an
            automatic retry policy for transient server errors.

            When ``api_key`` is supplied the session is immediately ready for
            use and ``authenticate()`` must not be called. ``portal`` is
            required in that case.

            Args:
                portal:  Hostname of the Cyver portal (e.g. ``"app.cyver.io"``).
                         Required when ``api_key`` is supplied; optional otherwise
                         (``authenticate()`` will set it).
                api_key: Static API key for keyless authentication. When provided,
                         requests are sent with ``X-API-Key`` instead of a Bearer
                         token. Optional — omit to use the standard login flow.

            Raises:
                CyverDataValidationError: If ``api_key`` is provided without ``portal``, or if
                    either argument is not a non-empty string when supplied.
                CyverAuthError: If ``api_key`` is supplied and the portal probe
                    reveals the portal is inactive (``reason="portal_inactive"``)
                    or unreachable (``reason="portal_unreachable"``). The probe
                    is skipped when a cache file confirms the same portal was
                    reachable in a previous run; the cache file is deleted if
                    the probe fails or if the cached portal does not match.
        """

        if api_key is not None:
            if not portal or not isinstance(portal, str):
                raise CyverDataValidationError(
                    "portal must be provided as a non-empty string when api_key is supplied.",
                    field="portal",
                    reason="invalid_type",
                )
            if not isinstance(api_key, str) or not api_key.strip():
                raise CyverDataValidationError("api_key must be a non-empty string.", field="api_key", reason="invalid_type")
        elif portal is not None and not isinstance(portal, str):
            raise CyverDataValidationError("portal must be a non-empty string.", field="portal", reason="invalid_type")

        self._api_key      = api_key
        self.portal        = portal
        self.access_token  = None
        self.refresh_token = None
        self.user_id       = None
        self._lock = threading.RLock()

        # Retry up to 3 times on idempotent requests (GET, PUT) for transient
        # server errors and rate-limiting responses. POST is intentionally
        # excluded to avoid duplicate side-effects (e.g. duplicate auth calls).
        _retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=frozenset(["GET", "PUT"]),
            raise_on_status=False,
        )
        self._session = Session()
        self._session.headers.update({"User-Agent": REQUESTS_USER_AGENT})
        self._session.mount("https://", HTTPAdapter(max_retries=_retry))

        # In API-key mode the portal is known at construction time.  Check the
        # cache first: if a previous successful call already confirmed this
        # portal, skip the probe.  Otherwise validate and update the cache.
        if self._api_key is not None:
            cache = self._fetch_apikey_cache()
            if cache.get("portal") == portal:
                # Portal confirmed by a previous successful call — skip probe.
                pass
            else:
                # First time, or the cached portal differs from the one supplied.
                # Delete any stale cache entry before re-validating.
                if cache.get("portal") is not None:
                    self._delete_apikey_cache()
                try:
                    self._probe_portal(portal)
                    self._save_apikey_cache()
                except Exception:
                    self._delete_apikey_cache()
                    raise

    def __repr__(self) -> str:
        """
            Returns a developer-friendly string showing the class name,
            portal hostname, and whether the session is authenticated.
            Works correctly for CyverSession subclasses via type(self).
        """
        authenticated = self.access_token is not None or self._api_key is not None
        return f"{type(self).__name__}(portal={self.portal!r}, authenticated={authenticated})"

    def __enter__(self) -> "CyverSession":
        """
            Supports use as a context manager. Returns self so the caller
            can bind the session to a variable via ``as``::

                with PentesterSession() as client:
                    client.authenticate(...)
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """
            Closes the underlying HTTP session when leaving a ``with``
            block, regardless of whether an exception was raised.
        """
        self._session.close()

    def __del__(self) -> None:
        """
            Closes the underlying HTTP session when the object is garbage
            collected, as a fallback for callers that do not use the
            context manager interface.
        """
        if hasattr(self, "_session"):
            self._session.close()

    def authenticate(self, portal: str, username: str, password: str, verification_code: str | None = None) -> bool:
        """
            Authenticates against the Cyver API using username and password.

            On first call (or when the cache is empty) a full login request is
            made. On subsequent calls the cached refresh token is used to obtain
            a new access token without re-entering credentials. Tokens are
            stored encrypted in the OS user-cache directory.

            .. note::
                This method is not available when the session was constructed
                with a static ``api_key``. Calling it in that case raises
                ``CyverAuthError`` immediately.

            Args:
                portal: Hostname of the Cyver portal (e.g. ``"app.cyver.io"``).
                username: Cyver account username or e-mail address.
                password: Cyver account password.
                verification_code: Email-based 2FA code. Pass this on a second
                    call after receiving a Cyver2FARequired on the first.

            Returns:
                True on successful authentication.

            Raises:
                CyverAuthError: If the session was constructed with an API key;
                    if the portal is inactive (``reason="portal_inactive"``); if
                    the portal is unreachable (``reason="portal_unreachable"``);
                    or if authentication fails for any other reason.
                CyverDataValidationError: If portal, username, or password are empty or not strings.
                Cyver2FARequired: If the account requires 2FA and no verification_code
                    was provided. A code is sent to the account e-mail automatically.
                CyverHTTPError: If the underlying HTTP request fails.
        """

        if self._api_key is not None:
            raise CyverAuthError(
                "This session uses a static API key and does not support "
                "username/password authentication. Remove the api_key argument "
                "from the constructor to use the standard login flow.",
                reason="not_authenticated",
            )

        if not portal or not isinstance(portal, str):
            raise CyverDataValidationError("portal must be a non-empty string.", field="portal", reason="invalid_type")
        if not username or not isinstance(username, str):
            raise CyverDataValidationError("username must be a non-empty string.", field="username", reason="invalid_type")
        if not password or not isinstance(password, str):
            raise CyverDataValidationError("password must be a non-empty string.", field="password", reason="invalid_type")

        # Set the portal before fetching the cache so the cache key is correct.
        self.portal = portal
        auth = self._fetch_oauth_cache(username, password)

        # "First time" means no usable token exists in the cache, so the full
        # /Authenticate endpoint must be called.  Track this before the probe
        # so the flag is available in the exception handler below.
        is_first_time = not (auth.get("accessToken") or auth.get("refreshToken"))

        # Skip the portal probe only when the cache confirms this portal was
        # previously reachable (portal matches) AND at least one token is still
        # valid — meaning the session was genuinely active recently.  If both
        # tokens are expired the cache offers no evidence of reachability, so
        # probe before sending credentials.
        cached_portal_matches = auth.get("portal") == portal
        has_valid_token = not is_first_time
        if not (cached_portal_matches and has_valid_token):
            self._probe_portal(portal)

        try:
            # If there were valid jwt tokens and user ids in cache ...
            if auth["accessToken"] and auth["refreshToken"] and auth["userId"]:
                # There is no need to do anything else, so move on
                pass

            # If the access token is not valid, but all others are ...
            elif not auth["accessToken"] and auth["refreshToken"] and auth["userId"]:
                # Send a refresh token request for a fresh access jwt token
                creds = { "refreshToken": auth["refreshToken"] }
                creds = self._send_api_request("POST", "/api/TokenAuth/RefreshToken", creds, None)
                if not isinstance(creds, dict) or "accessToken" not in creds:
                    raise CyverAuthError(
                        "Token refresh failed (No valid Access JWT Token was returned).",
                        reason="access_token_missing",
                    )
                auth["accessToken"] = creds["accessToken"]

            # If there were no usable tokens in the cache ...
            else:
                # Authenticate against the Cyver API endpoint
                creds = { "userNameOrEmailAddress": username, "password": password }
                if verification_code:
                    creds["twoFactorVerificationCode"] = verification_code
                auth = self._send_api_request("POST", "/api/TokenAuth/Authenticate", None, creds)

            # If the Require Two Factor Verification flag is set ...
            if "requiresTwoFactorVerification" in auth and auth["requiresTwoFactorVerification"]:
                # It means the authentication failed, but Cyver API only supports
                # Email 2FA verification code, so ...
                if "twoFactorAuthProviders" in auth and "Email" in auth["twoFactorAuthProviders"]:
                    # Request a 2FA verification code and raise a 2FA exception
                    token = {"provider": "Email", "userId": auth["userId"] }
                    self._send_api_request("POST", "/api/TokenAuth/SendTwoFactorAuthCode", None, token)
                    raise Cyver2FARequired(
                        "Username/Password requires 2FA validation (2FA Verification Code sent via Email).",
                        user_id=auth.get("userId"),
                        providers=auth.get("twoFactorAuthProviders", []),
                    )
                else:
                    # There is no path forward, so raise an authentication exception
                    raise CyverAuthError(
                        "Username/Password authentication failed (2FA enforced but Email 2FA not enabled).",
                        reason="2fa_not_configured",
                    )

            # Atomically validate and commit the new token state under the lock so
            # concurrent API calls never observe a partially-updated state.
            with self._lock:
                if "accessToken" not in auth:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Access JWT Token was returned).",
                        reason="access_token_missing",
                    )
                try:
                    _validate_jwt_token(auth["accessToken"], "accessToken")
                except CyverDataValidationError:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Access JWT Token was returned).",
                        reason="access_token_missing",
                    )
                self.access_token = auth["accessToken"]

                if "refreshToken" not in auth:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Refresh JWT Token was returned).",
                        reason="refresh_token_missing",
                    )
                try:
                    _validate_jwt_token(auth["refreshToken"], "refreshToken")
                except CyverDataValidationError:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Refresh JWT Token was returned).",
                        reason="refresh_token_missing",
                    )
                self.refresh_token = auth["refreshToken"]

                if "userId" not in auth:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid User ID UUID was returned).",
                        reason="user_id_missing",
                    )
                try:
                    _validate_uuid(auth["userId"], "userId")
                except CyverDataValidationError:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid User ID UUID was returned).",
                        reason="user_id_missing",
                    )
                self.user_id = auth["userId"]

        except Exception:
            # If this was a first-time login (no usable cached tokens) and the
            # backend call failed, delete any stale cache file so the next
            # attempt starts from a clean state.
            if is_first_time:
                self._delete_oauth_cache(username, password)
            raise

        # Save the tokens in the cache file and log any failure
        if not self._save_oauth_cache(username, password):
            logger.warning("Failed to save authentication tokens to cache.")

        return True

    def _probe_portal(self, portal: str) -> None:
        """
            Performs a lightweight HTTP probe to verify the portal is reachable
            and active before attempting authentication or making API calls.

            A GET request is sent to ``/api/TokenAuth/Authenticate``. If the
            response body contains the word ``"inaccessible"`` (case-insensitive)
            Cyver infrastructure is running but the tenant is not provisioned.
            Any network-level failure (DNS, timeout, connection refused) is
            treated as unreachable.

            Args:
                portal: Hostname of the Cyver portal (e.g. ``"app.cyver.io"``).

            Raises:
                CyverAuthError: With ``reason="portal_inactive"`` if the portal
                    hostname resolves but the tenant is not provisioned; with
                    ``reason="portal_unreachable"`` if the host cannot be reached
                    due to a network error.
        """
        probe_url = f"https://{portal}/api/TokenAuth/Authenticate"
        try:
            response = self._session.get(probe_url, timeout=REQUESTS_TIMEOUT)
            if "inaccessible" in response.text.lower():
                raise CyverAuthError(
                    f"Portal '{portal}' is not active or does not exist.",
                    reason="portal_inactive",
                )
        except CyverAuthError:
            raise
        except RequestException as e:
            raise CyverAuthError(
                f"Portal '{portal}' is unreachable: {e}",
                reason="portal_unreachable",
            ) from e

    def _fetch_oauth_cache(self, username: str, password: str) -> dict:
        """
            Attempts to load previously cached tokens from the OS user-cache
            directory. Returns a dict with keys ``accessToken``, ``refreshToken``
            and ``userId``; any token that is absent, expired, or undecryptable
            is returned as None. Never raises — failures are debug-logged.
        """
        secret = f"{self.portal}:{username}:{password}"
        filename = _calculate_oauth_cache_filename(secret)
        template = { "accessToken": None, "refreshToken": None, "userId": None, "portal": None }

        try:
            with open(filename, "r") as cachefile:
                cache = loads(cachefile.read())
        except Exception as e:
            logger.debug(f"Could not read cache file '{filename}': {e}")
            return template

        if "cipher" not in cache or cache["cipher"] != "Fernet" or "ciphertext_b64" not in cache \
                or "iterations" not in cache or "salt_b64" not in cache or \
                "v" not in cache or cache["v"] != 1:
            return template

        try:
            fernet = _derive_fernet(secret, b64decode(cache["salt_b64"]), int(cache["iterations"]))
            payload = loads(fernet.decrypt(b64decode(cache["ciphertext_b64"])).decode("utf-8"))
        except Exception as e:
            logger.debug(f"Could not decrypt cache file '{filename}': {e}")
            return template

        if "accessToken" in payload:
            try:
                _validate_jwt_token(payload["accessToken"], "accessToken")
                template["accessToken"] = payload["accessToken"]
            except CyverDataValidationError:
                pass
        if "refreshToken" in payload:
            try:
                _validate_jwt_token(payload["refreshToken"], "refreshToken")
                template["refreshToken"] = payload["refreshToken"]
            except CyverDataValidationError:
                pass
        if "userId" in payload:
            try:
                _validate_uuid(payload["userId"], "userId")
                template["userId"] = payload["userId"]
            except CyverDataValidationError:
                pass
        if "portal" in payload and isinstance(payload["portal"], str) and payload["portal"]:
            template["portal"] = payload["portal"]

        return template

    def _save_oauth_cache(self, username: str, password: str) -> bool:
        """
            Encrypts the current access token, refresh token and user ID with
            a PBKDF2-derived Fernet key and writes the result to the OS
            user-cache directory with owner-only file permissions (0o600).
            Returns True on success, False on any failure (failures are
            debug-logged and never raised).
        """
        secret = f"{self.portal}:{username}:{password}"
        filename = _calculate_oauth_cache_filename(secret)

        salt = urandom(CACHE_RANDOM_BYTES)
        fernet = _derive_fernet(secret, salt, CACHE_ITERATIONS)

        with self._lock:
            plaindict = { "accessToken": self.access_token, "refreshToken": self.refresh_token, "userId": self.user_id, "portal": self.portal }

        try:
            plaintext = dumps(plaindict, ensure_ascii=False).encode("utf-8")
            ciphertext = fernet.encrypt(plaintext)
        except Exception as e:
            logger.debug(f"Could not encrypt tokens for cache: {e}")
            return False

        payload = {
            "v": 1,
            "kdf": "PBKDF2HMAC-SHA256",
            "iterations": CACHE_ITERATIONS,
            "salt_b64": b64encode(salt).decode("ascii"),
            "cipher": "Fernet",
            "ciphertext_b64": b64encode(ciphertext).decode("ascii"),
        }

        try:
            # Open the file with O_CREAT | O_WRONLY | O_TRUNC so it is created
            # atomically with mode 0o600 (owner read/write only) on Unix-like
            # systems. On Windows the mode argument is ignored, but AppData\Local
            # is already user-private so no additional restriction is needed.
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as cachefile:
                cachefile.write(dumps(payload).encode("utf-8"))
        except Exception as e:
            logger.debug(f"Could not write cache file '{filename}': {e}")
            return False

        return True

    def _delete_oauth_cache(self, username: str, password: str) -> None:
        """
            Removes the encrypted token cache file for the current portal and
            the given username/password combination, if it exists.

            Called automatically when a first-time backend authentication
            attempt fails, ensuring no stale cache file is left behind that
            could interfere with subsequent login attempts.

            Failures are debug-logged and never raised.

            Args:
                username: Cyver account username or e-mail address.
                password: Cyver account password.
        """
        secret = f"{self.portal}:{username}:{password}"
        filename = _calculate_oauth_cache_filename(secret)
        try:
            filename.unlink(missing_ok=True)
            logger.debug(f"Deleted cache file '{filename}' after failed first-time authentication.")
        except Exception as e:
            logger.debug(f"Could not delete cache file '{filename}': {e}")

    # ------------------------------------------------------------------
    # API-key cache helpers
    # ------------------------------------------------------------------

    def _fetch_apikey_cache(self) -> dict:
        """
            Attempts to load the API key validation cache from the OS
            user-cache directory. Returns a dict with key ``portal``; if
            the file is absent, unreadable, or malformed, ``portal`` is
            ``None``. Never raises — failures are debug-logged.
        """
        filename = _calculate_apikey_cache_filename(self._api_key)
        template = {"portal": None}

        try:
            with open(filename, "r") as cachefile:
                cache = loads(cachefile.read())
        except Exception as e:
            logger.debug(f"Could not read API key cache file '{filename}': {e}")
            return template

        if "v" not in cache or cache["v"] != 1 or "portal" not in cache:
            return template

        if isinstance(cache["portal"], str) and cache["portal"]:
            template["portal"] = cache["portal"]

        return template

    def _save_apikey_cache(self) -> bool:
        """
            Writes the API key validation record (portal hostname) to the
            OS user-cache directory with owner-only file permissions
            (0o600). Returns True on success, False on any failure
            (failures are debug-logged and never raised).
        """
        filename = _calculate_apikey_cache_filename(self._api_key)
        payload = {"v": 1, "portal": self.portal}

        try:
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as cachefile:
                cachefile.write(dumps(payload).encode("utf-8"))
        except Exception as e:
            logger.debug(f"Could not write API key cache file '{filename}': {e}")
            return False

        return True

    def _delete_apikey_cache(self) -> None:
        """
            Removes the API key validation cache file if it exists.
            Called when the portal probe fails on first use, or when the
            cached portal does not match the one supplied to the
            constructor. Failures are debug-logged and never raised.
        """
        filename = _calculate_apikey_cache_filename(self._api_key)
        try:
            filename.unlink(missing_ok=True)
            logger.debug(f"Deleted API key cache file '{filename}'.")
        except Exception as e:
            logger.debug(f"Could not delete API key cache file '{filename}': {e}")

    def _require_uuid(self, value: str, field: str) -> None:
        """Raise ``CyverDataValidationError`` if *value* is not a well-formed UUID.

        Args:
            value: The string to validate.
            field: Parameter name used in the error message and ``field``
                attribute of the raised exception.

        Raises:
            CyverDataValidationError: If *value* is not a valid UUID.
        """
        _validate_uuid(value, field)

    def _paginate(self, fetcher: Callable[[int, int], dict], page_size: int = 50) -> Iterator:
        """Yield every item from a paginated API endpoint.

        Calls *fetcher* repeatedly, advancing the skip offset until all
        pages have been consumed.

        Args:
            fetcher: Callable with signature ``(count_max: int,
                count_skip: int) -> dict`` that returns a dict containing
                ``items`` (list) and ``totalCount`` (int) keys.
            page_size: Number of records to request per API call.

        Yields:
            Individual items from successive pages.
        """
        skip = 0
        while True:
            page = fetcher(page_size, skip)
            items = page.get("items", [])
            yield from items
            skip += len(items)
            if not items or skip >= page.get("totalCount", 0):
                break

    def _send_api_request(self, method: str, endpoint: str, params: dict | None = None, data: dict | None = None) -> dict:
        """
            Sends an authenticated HTTP request to the Cyver API and returns
            the parsed ``result`` field from the JSON response body.

            Args:
                method: HTTP method (``"GET"``, ``"POST"``, ``"PUT"``, etc.).
                endpoint: API path, e.g. ``"/api/latest/pentester/projects"``.
                params: Optional URL query parameters.
                data: Optional request body; serialised as JSON.

            Returns:
                The ``result`` value from the API response, True for empty
                200 responses, or False if the response body is unrecognised.

            Raises:
                CyverAuthError: If the session has not been authenticated yet.
                CyverNotFoundError: If the API returns HTTP 404.
                CyverPermissionError: If the API returns HTTP 401 or 403.
                CyverRateLimitError: If the API returns HTTP 429 after all
                    retries are exhausted.
                CyverHTTPError: If the request fails for any other reason,
                    the status code is not 200, the body is not valid JSON,
                    or the success flag is False.
        """
        if self.portal is None:
            raise CyverAuthError(
                "Not authenticated. Call authenticate() before making API requests.",
                reason="not_authenticated",
            )

        headers = {}

        if data:
            headers["Content-Type"] = "application/json; charset=utf-8"

        if self._api_key:
            # Static API-key mode: key is immutable after construction, no lock needed.
            headers["X-API-Key"] = self._api_key
        else:
            # Bearer-token mode: snapshot atomically so the header reflects a
            # consistent state even if authenticate() is called concurrently.
            with self._lock:
                access_token = self.access_token
            if access_token:
                headers["Authorization"] = f"Bearer {access_token}"

        url = f"https://{self.portal}{endpoint}"
        request = Request(method, url, headers=headers, params=params, json=data)

        try:
            response = self._session.send(self._session.prepare_request(request),
                                          timeout=REQUESTS_TIMEOUT)
        except RequestException as e:
            raise CyverHTTPError(
                f"{method} {url} failed: {e}",
                method=method, url=url,
            ) from e

        if not (200 <= response.status_code < 300):
            status = response.status_code
            msg = f"{method} {url} failed (HTTP {status})."
            # Attempt to extract the error detail from the response body so
            # callers can see the server's actual reason rather than just the
            # status code.
            try:
                body = response.json()
                detail = (
                    body.get("error", {}).get("message")
                    or body.get("error", {}).get("details")
                    or body.get("message")
                    or body.get("detail")
                )
                if detail:
                    msg += f" Server message: {detail}"
            except Exception:
                if response.text:
                    msg += f" Server message: {response.text[:300]}"
            if status == 404:
                raise CyverNotFoundError(msg, method=method, url=url)
            if status in (401, 403):
                raise CyverPermissionError(msg, status_code=status, method=method, url=url)
            if status == 429:
                raise CyverRateLimitError(msg, method=method, url=url)
            raise CyverHTTPError(msg, status_code=status, method=method, url=url)

        if "content-type" in response.headers and "application/json" in response.headers["content-type"]:
            try:
                payload = response.json()
            except ValueError as e:
                raise CyverHTTPError(
                    f"{method} {url} returned non-JSON response: {e}",
                    status_code=200, method=method, url=url,
                ) from e

            if not payload.get("success"):
                raise CyverHTTPError(
                    f"{method} {url} failed (API success flag was false).",
                    status_code=200, method=method, url=url,
                )

            if "result" not in payload:
                raise CyverHTTPError(
                    f"{method} {url} returned a successful response with no result field.",
                    status_code=200, method=method, url=url,
                )

            return payload["result"]

        try:
            content_length = int(response.headers.get("content-length", -1))
        except ValueError:
            content_length = -1

        if content_length == 0:
            return True

        return False


def _calculate_oauth_cache_filename(secret: str) -> Path:
    """
        Returns the OS-appropriate path for the encrypted token cache file,
        creating the parent directory (mode 0o700) if it does not yet exist.
        The filename is derived from an MD5 digest of the secret so that
        different portals/users each get an isolated cache file.
    """
    # mode=0o700 restricts the directory to the owner only on Unix-like systems;
    # on Windows, AppData\Local is already user-private so the mode is ignored.
    cache_dir = Path(user_cache_dir("cyver", appauthor=False))
    cache_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    digest = md5(secret.encode("utf-8")).hexdigest()
    return cache_dir / f"session-{digest}.json"


def _calculate_apikey_cache_filename(api_key: str) -> Path:
    """
        Returns the OS-appropriate path for the API key validation cache
        file, creating the parent directory (mode 0o700) if it does not
        yet exist. The filename is derived from an MD5 digest of the API
        key so that each key gets its own isolated cache file.
    """
    cache_dir = Path(user_cache_dir("cyver", appauthor=False))
    cache_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    digest = md5(api_key.encode("utf-8")).hexdigest()
    return cache_dir / f"apikey-{digest}.json"


def _derive_fernet(secret: str, salt: bytes, iterations: int) -> Fernet:
    """
        Derives a Fernet symmetric encryption key from a plaintext secret
        using PBKDF2-HMAC-SHA256 with the given salt and iteration count.
    """
    kdf = PBKDF2HMAC(algorithm=SHA256(), length=32, salt=salt, iterations=iterations)
    key = b64encode(kdf.derive(secret.encode("utf-8")))
    return Fernet(key)
