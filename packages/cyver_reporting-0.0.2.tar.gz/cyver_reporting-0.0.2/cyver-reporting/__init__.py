#!/usr/bin/env python3

from .Session import CyverSession
from .ClientSession import ClientSession
from .PentesterSession import PentesterSession
from .Exceptions import (
    CyverError,
    CyverAuthError,
    Cyver2FARequired,
    CyverHTTPError,
    CyverNotFoundError,
    CyverPermissionError,
    CyverRateLimitError,
    CyverDataValidationError,
    CyverReferenceError,
)
from .DataTypes import (
    CyverClientAddress,
    CyverClientInformation,
    CyverClient,
    CyverAsset,
    CyverChecklistTemplate,
    CyverComplianceTemplate,
    CyverProjectTemplate,
    CyverReportTemplateSection,
    CyverReportTemplate,
    CyverUser,
    CyverPlanningDate,
    CyverProjectDates,
    CyverProject,
)
from .Utils import (
    _asset_type,
    _asset_env,
    _asset_hosting,
    _asset_hardware,
    _asset_exposure,
    _user_role,
    _client_status,
    _project_status,
)

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("cyver-reporting")
except PackageNotFoundError:
    # Package is not installed (e.g. running directly from source)
    __version__ = "unknown"

__all__ = [
    # Session classes
    "CyverSession",
    "ClientSession",
    "PentesterSession",
    # Base exception
    "CyverError",
    # Authentication exceptions
    "CyverAuthError",
    "Cyver2FARequired",
    # HTTP exceptions
    "CyverHTTPError",
    "CyverNotFoundError",
    "CyverPermissionError",
    "CyverRateLimitError",
    # Data validation exception
    "CyverDataValidationError",
    # Reference validation exception
    "CyverReferenceError",
    # Data builder classes
    "CyverClientAddress",
    "CyverClientInformation",
    "CyverClient",
    "CyverAsset",
    "CyverChecklistTemplate",
    "CyverComplianceTemplate",
    "CyverProjectTemplate",
    "CyverReportTemplateSection",
    "CyverReportTemplate",
    "CyverUser",
    "CyverPlanningDate",
    "CyverProjectDates",
    "CyverProject",
    # Asset field alias classes
    "_asset_type",
    "_asset_env",
    "_asset_hosting",
    "_asset_hardware",
    "_asset_exposure",
    # User field alias classes
    "_user_role",
    # Client / project status alias classes
    "_client_status",
    "_project_status",
    # Package version
    "__version__",
]
