"""
Tests for CyverReporting.Session — authenticate() and _send_api_request().
"""

import pytest
from unittest.mock import MagicMock, patch
from requests import RequestException

from CyverReporting.Session import CyverSession
from CyverReporting.Exceptions import (
    CyverDataValidationError,
    CyverAuthError,
    Cyver2FARequired,
    CyverHTTPError,
    CyverNotFoundError,
    CyverPermissionError,
    CyverRateLimitError,
)
from tests.conftest import (
    PORTAL, USERNAME, PASSWORD,
    FAKE_UUID, FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN,
    make_http_response, make_api_response,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_auth_payload(**overrides):
    """Return a minimal valid authentication API response."""
    payload = {
        "accessToken": FAKE_ACCESS_TOKEN,
        "refreshToken": FAKE_REFRESH_TOKEN,
        "userId": FAKE_UUID,
        "requiresTwoFactorVerification": False,
    }
    payload.update(overrides)
    return payload


def _patched_authenticate(session, send_return_value, cache_return=None):
    """
    Run authenticate() on *session* with all I/O mocked:
      - _probe_portal is a no-op (no network call)
      - _fetch_oauth_cache returns an empty cache (forces a full login)
      - _save_oauth_cache returns True
      - _send_api_request returns *send_return_value*
      - _validate_jwt_token always succeeds (does not raise)
      - _validate_uuid always succeeds (does not raise)
    """
    empty_cache = {"accessToken": None, "refreshToken": None, "userId": None, "portal": None}
    with patch.object(session, "_probe_portal"), \
         patch.object(session, "_fetch_oauth_cache", return_value=cache_return or empty_cache), \
         patch.object(session, "_save_oauth_cache", return_value=True), \
         patch.object(session, "_send_api_request", return_value=send_return_value), \
         patch("CyverReporting.Session._validate_jwt_token"), \
         patch("CyverReporting.Session._validate_uuid"):
        return session.authenticate(PORTAL, USERNAME, PASSWORD)


# ---------------------------------------------------------------------------
# authenticate() — input validation
# ---------------------------------------------------------------------------

class TestAuthenticateInputValidation:

    def test_empty_portal_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession().authenticate("", USERNAME, PASSWORD)

    def test_none_portal_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession().authenticate(None, USERNAME, PASSWORD)

    def test_non_string_portal_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession().authenticate(123, USERNAME, PASSWORD)

    def test_empty_username_raises(self):
        with pytest.raises(CyverDataValidationError, match="username"):
            CyverSession().authenticate(PORTAL, "", PASSWORD)

    def test_none_username_raises(self):
        with pytest.raises(CyverDataValidationError, match="username"):
            CyverSession().authenticate(PORTAL, None, PASSWORD)

    def test_empty_password_raises(self):
        with pytest.raises(CyverDataValidationError, match="password"):
            CyverSession().authenticate(PORTAL, USERNAME, "")

    def test_none_password_raises(self):
        with pytest.raises(CyverDataValidationError, match="password"):
            CyverSession().authenticate(PORTAL, USERNAME, None)


# ---------------------------------------------------------------------------
# authenticate() — success path
# ---------------------------------------------------------------------------

class TestAuthenticateSuccess:

    def test_returns_true_on_success(self):
        session = CyverSession()
        result = _patched_authenticate(session, make_auth_payload())
        assert result is True

    def test_sets_portal(self):
        session = CyverSession()
        _patched_authenticate(session, make_auth_payload())
        assert session.portal == PORTAL

    def test_sets_access_token(self):
        session = CyverSession()
        _patched_authenticate(session, make_auth_payload())
        assert session.access_token == FAKE_ACCESS_TOKEN

    def test_sets_refresh_token(self):
        session = CyverSession()
        _patched_authenticate(session, make_auth_payload())
        assert session.refresh_token == FAKE_REFRESH_TOKEN

    def test_sets_user_id(self):
        session = CyverSession()
        _patched_authenticate(session, make_auth_payload())
        assert session.user_id == FAKE_UUID


# ---------------------------------------------------------------------------
# authenticate() — cached token paths
# ---------------------------------------------------------------------------

class TestAuthenticateCachedTokens:

    def test_uses_cache_when_all_tokens_valid(self):
        """When cache has all valid tokens, no API call should be made."""
        session = CyverSession()
        full_cache = {
            "accessToken": FAKE_ACCESS_TOKEN,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": PORTAL,
        }
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=full_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request") as mock_req, \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_req.assert_not_called()

    def test_probe_skipped_when_cached_portal_matches(self):
        """When the cached portal matches the argument, _probe_portal must not be called."""
        session = CyverSession()
        full_cache = {
            "accessToken": FAKE_ACCESS_TOKEN,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": PORTAL,
        }
        with patch.object(session, "_probe_portal") as mock_probe, \
             patch.object(session, "_fetch_oauth_cache", return_value=full_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request"), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_probe.assert_not_called()

    def test_probe_called_when_cached_portal_is_none(self):
        """When the cache has no portal (old-format or empty cache), probe must run."""
        session = CyverSession()
        cache_no_portal = {
            "accessToken": FAKE_ACCESS_TOKEN,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": None,
        }
        with patch.object(session, "_probe_portal") as mock_probe, \
             patch.object(session, "_fetch_oauth_cache", return_value=cache_no_portal), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request"), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_probe.assert_called_once_with(PORTAL)

    def test_probe_called_when_cached_portal_differs(self):
        """When the cached portal differs from the argument, probe must run."""
        session = CyverSession()
        cache_other_portal = {
            "accessToken": FAKE_ACCESS_TOKEN,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": "other.cyver.io",
        }
        with patch.object(session, "_probe_portal") as mock_probe, \
             patch.object(session, "_fetch_oauth_cache", return_value=cache_other_portal), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request"), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_probe.assert_called_once_with(PORTAL)

    def test_probe_called_when_both_tokens_expired(self):
        """When portal matches but both tokens are expired, probe must run."""
        session = CyverSession()
        expired_cache = {
            "accessToken": None,
            "refreshToken": None,
            "userId": None,
            "portal": PORTAL,
        }
        with patch.object(session, "_probe_portal") as mock_probe, \
             patch.object(session, "_fetch_oauth_cache", return_value=expired_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value=make_auth_payload()), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_probe.assert_called_once_with(PORTAL)

    def test_probe_skipped_when_only_refresh_token_valid(self):
        """Probe is skipped when portal matches and refresh token is still valid."""
        session = CyverSession()
        partial_cache = {
            "accessToken": None,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": PORTAL,
        }
        with patch.object(session, "_probe_portal") as mock_probe, \
             patch.object(session, "_fetch_oauth_cache", return_value=partial_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value={"accessToken": FAKE_ACCESS_TOKEN}), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_probe.assert_not_called()

    def test_refreshes_when_only_refresh_token_valid(self):
        """When only the refresh token is cached, one refresh call is made."""
        session = CyverSession()
        partial_cache = {
            "accessToken": None,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": PORTAL,
        }
        refresh_response = {"accessToken": FAKE_ACCESS_TOKEN}
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=partial_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value=refresh_response) as mock_req, \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_req.assert_called_once()
            assert mock_req.call_args[0][1] == "/api/TokenAuth/RefreshToken"

    def test_refresh_with_no_access_token_raises_auth_error(self):
        """If the refresh endpoint returns no accessToken, raise CyverAuthError."""
        session = CyverSession()
        partial_cache = {
            "accessToken": None,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": PORTAL,
        }
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=partial_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value={"unexpected": "payload"}):
            with pytest.raises(CyverAuthError) as exc_info:
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            assert exc_info.value.reason == "access_token_missing"


# ---------------------------------------------------------------------------
# authenticate() — cache cleanup on first-time failure
# ---------------------------------------------------------------------------

class TestAuthenticateCacheCleanup:

    def _empty_cache(self):
        return {"accessToken": None, "refreshToken": None, "userId": None, "portal": None}

    def test_cache_deleted_when_first_time_and_backend_fails(self):
        """On a first-time login (no cached tokens), a backend failure must delete the cache."""
        session = CyverSession()
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=self._empty_cache()), \
             patch.object(session, "_send_api_request", side_effect=CyverHTTPError("network error")), \
             patch.object(session, "_delete_oauth_cache") as mock_delete:
            with pytest.raises(CyverHTTPError):
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_delete.assert_called_once_with(USERNAME, PASSWORD)

    def test_cache_not_deleted_on_first_time_success(self):
        """On a successful first-time login, _delete_oauth_cache must not be called."""
        session = CyverSession()
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=self._empty_cache()), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value=make_auth_payload()), \
             patch.object(session, "_delete_oauth_cache") as mock_delete, \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_delete.assert_not_called()

    def test_cache_not_deleted_when_refresh_token_cached_and_backend_fails(self):
        """When a refresh token is in cache, a backend failure must NOT delete the cache."""
        session = CyverSession()
        partial_cache = {
            "accessToken": None,
            "refreshToken": FAKE_REFRESH_TOKEN,
            "userId": FAKE_UUID,
            "portal": PORTAL,
        }
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=partial_cache), \
             patch.object(session, "_send_api_request", side_effect=CyverHTTPError("network error")), \
             patch.object(session, "_delete_oauth_cache") as mock_delete:
            with pytest.raises(CyverHTTPError):
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            mock_delete.assert_not_called()


# ---------------------------------------------------------------------------
# authenticate() — 2FA paths
# ---------------------------------------------------------------------------

class TestAuthenticate2FA:

    def test_raises_cyver_2fa_required(self):
        session = CyverSession()
        payload = make_auth_payload(
            requiresTwoFactorVerification=True,
            twoFactorAuthProviders=["Email"],
            userId=FAKE_UUID,
        )
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache",
                          return_value={"accessToken": None, "refreshToken": None, "userId": None}), \
             patch.object(session, "_send_api_request", return_value=payload):
            with pytest.raises(Cyver2FARequired) as exc_info:
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            e = exc_info.value
            assert e.user_id == FAKE_UUID
            assert "Email" in e.providers
            assert e.reason == "2fa_required"

    def test_raises_auth_error_when_email_2fa_not_available(self):
        session = CyverSession()
        payload = make_auth_payload(
            requiresTwoFactorVerification=True,
            twoFactorAuthProviders=["Authenticator"],
        )
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache",
                          return_value={"accessToken": None, "refreshToken": None, "userId": None}), \
             patch.object(session, "_send_api_request", return_value=payload):
            with pytest.raises(CyverAuthError) as exc_info:
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            assert exc_info.value.reason == "2fa_not_configured"


# ---------------------------------------------------------------------------
# authenticate() — missing token fields
# ---------------------------------------------------------------------------

class TestAuthenticateMissingFields:

    def _auth_with_payload(self, payload):
        session = CyverSession()
        empty_cache = {"accessToken": None, "refreshToken": None, "userId": None, "portal": None}
        with patch.object(session, "_probe_portal"), \
             patch.object(session, "_fetch_oauth_cache", return_value=empty_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value=payload):
            session.authenticate(PORTAL, USERNAME, PASSWORD)

    def test_missing_access_token_raises(self):
        _invalid = CyverDataValidationError("invalid", field="f", reason="r")
        with patch("CyverReporting.Session._validate_jwt_token", side_effect=[_invalid, None]):
            with pytest.raises(CyverAuthError) as exc_info:
                self._auth_with_payload(make_auth_payload())
            assert exc_info.value.reason == "access_token_missing"

    def test_missing_refresh_token_raises(self):
        _invalid = CyverDataValidationError("invalid", field="f", reason="r")
        with patch("CyverReporting.Session._validate_jwt_token", side_effect=[None, _invalid]):
            with pytest.raises(CyverAuthError) as exc_info:
                self._auth_with_payload(make_auth_payload())
            assert exc_info.value.reason == "refresh_token_missing"

    def test_missing_user_id_raises(self):
        _invalid = CyverDataValidationError("invalid", field="f", reason="r")
        with patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid", side_effect=_invalid):
            with pytest.raises(CyverAuthError) as exc_info:
                self._auth_with_payload(make_auth_payload())
            assert exc_info.value.reason == "user_id_missing"


# ---------------------------------------------------------------------------
# _send_api_request() — authentication guard
# ---------------------------------------------------------------------------

class TestSendApiRequestAuthGuard:

    def test_raises_when_portal_is_none(self):
        session = CyverSession()
        with pytest.raises(CyverAuthError) as exc_info:
            session._send_api_request("GET", "/api/test")
        assert exc_info.value.reason == "not_authenticated"

    def test_error_message_mentions_authenticate(self):
        session = CyverSession()
        with pytest.raises(CyverAuthError, match="authenticate()"):
            session._send_api_request("GET", "/api/test")


# ---------------------------------------------------------------------------
# _send_api_request() — HTTP error mapping
# ---------------------------------------------------------------------------

class TestSendApiRequestHttpErrors:
    """
    All HTTP-level tests set session.portal to avoid the auth guard
    and replace session._session with a MagicMock.
    """

    def _make_session(self, mock_response):
        session = CyverSession()
        session.portal = PORTAL
        session._session = MagicMock()
        session._session.send.return_value = mock_response
        return session

    def test_404_raises_not_found(self):
        s = self._make_session(make_http_response(404, content_type=None))
        with pytest.raises(CyverNotFoundError) as exc_info:
            s._send_api_request("GET", "/api/resource/missing")
        assert exc_info.value.status_code == 404
        assert exc_info.value.method == "GET"
        assert PORTAL in exc_info.value.url

    def test_401_raises_permission_error(self):
        s = self._make_session(make_http_response(401, content_type=None))
        with pytest.raises(CyverPermissionError) as exc_info:
            s._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code == 401

    def test_403_raises_permission_error(self):
        s = self._make_session(make_http_response(403, content_type=None))
        with pytest.raises(CyverPermissionError) as exc_info:
            s._send_api_request("DELETE", "/api/resource/1")
        assert exc_info.value.status_code == 403
        assert exc_info.value.method == "DELETE"

    def test_429_raises_rate_limit_error(self):
        s = self._make_session(make_http_response(429, content_type=None))
        with pytest.raises(CyverRateLimitError) as exc_info:
            s._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code == 429

    def test_500_raises_generic_http_error(self):
        s = self._make_session(make_http_response(500, content_type=None))
        with pytest.raises(CyverHTTPError) as exc_info:
            s._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code == 500
        # Must not be a more specific subclass
        assert type(exc_info.value) is CyverHTTPError

    def test_network_error_raises_http_error(self):
        session = CyverSession()
        session.portal = PORTAL
        session._session = MagicMock()
        session._session.send.side_effect = RequestException("connection refused")
        with pytest.raises(CyverHTTPError) as exc_info:
            session._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code is None
        assert exc_info.value.method == "GET"

    def test_http_subclasses_caught_by_http_error(self):
        s = self._make_session(make_http_response(404, content_type=None))
        with pytest.raises(CyverHTTPError):
            s._send_api_request("GET", "/api/resource")


# ---------------------------------------------------------------------------
# _send_api_request() — response parsing
# ---------------------------------------------------------------------------

class TestSendApiRequestResponseParsing:

    def _make_session(self, mock_response):
        session = CyverSession()
        session.portal = PORTAL
        session._session = MagicMock()
        session._session.send.return_value = mock_response
        return session

    def test_returns_result_from_successful_json_response(self):
        data = {"id": "abc", "name": "Project X"}
        response = make_http_response(200, json_data=make_api_response(data))
        s = self._make_session(response)
        assert s._send_api_request("GET", "/api/resource") == data

    def test_raises_when_success_flag_is_false(self):
        response = make_http_response(200, json_data={"success": False})
        s = self._make_session(response)
        with pytest.raises(CyverHTTPError) as exc_info:
            s._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code == 200

    def test_raises_when_result_key_missing(self):
        response = make_http_response(200, json_data={"success": True})
        s = self._make_session(response)
        with pytest.raises(CyverHTTPError) as exc_info:
            s._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code == 200

    def test_raises_on_non_json_body(self):
        response = make_http_response(200, content_type="application/json")
        response.json.side_effect = ValueError("not json")
        s = self._make_session(response)
        with pytest.raises(CyverHTTPError) as exc_info:
            s._send_api_request("GET", "/api/resource")
        assert exc_info.value.status_code == 200

    def test_returns_true_for_empty_200_response(self):
        response = make_http_response(200, content_type=None, content_length=0)
        s = self._make_session(response)
        assert s._send_api_request("DELETE", "/api/resource/1") is True

    def test_malformed_content_length_handled_gracefully(self):
        """A non-numeric content-length header must not raise ValueError."""
        response = make_http_response(200, content_type=None)
        response.headers["content-length"] = "not-a-number"
        s = self._make_session(response)
        # Should not raise — returns False for unrecognised response
        result = s._send_api_request("DELETE", "/api/resource/1")
        assert result is False

    def test_url_contains_portal_and_endpoint(self):
        response = make_http_response(500, content_type=None)
        s = self._make_session(response)
        endpoint = "/api/v2.2/pentester/projects"
        with pytest.raises(CyverHTTPError) as exc_info:
            s._send_api_request("GET", endpoint)
        assert PORTAL in exc_info.value.url
        assert endpoint in exc_info.value.url


# ---------------------------------------------------------------------------
# API-key constructor — initialisation and validation
# ---------------------------------------------------------------------------

API_KEY = "sk-test-abc123"


class TestApiKeyInit:

    @pytest.fixture(autouse=True)
    def _no_probe(self):
        with patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True):
            yield

    def test_sets_portal_and_api_key(self):
        s = CyverSession(portal=PORTAL, api_key=API_KEY)
        assert s.portal == PORTAL
        assert s._api_key == API_KEY

    def test_session_immediately_authenticated(self):
        s = CyverSession(portal=PORTAL, api_key=API_KEY)
        # access_token is not set, but api_key makes repr show authenticated=True
        assert "authenticated=True" in repr(s)

    def test_token_fields_remain_none(self):
        s = CyverSession(portal=PORTAL, api_key=API_KEY)
        assert s.access_token is None
        assert s.refresh_token is None
        assert s.user_id is None

    def test_api_key_without_portal_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession(api_key=API_KEY)

    def test_api_key_with_none_portal_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession(portal=None, api_key=API_KEY)

    def test_api_key_with_empty_portal_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession(portal="", api_key=API_KEY)

    def test_empty_api_key_raises(self):
        with pytest.raises(CyverDataValidationError, match="api_key"):
            CyverSession(portal=PORTAL, api_key="")

    def test_whitespace_api_key_raises(self):
        with pytest.raises(CyverDataValidationError, match="api_key"):
            CyverSession(portal=PORTAL, api_key="   ")

    def test_non_string_api_key_raises(self):
        with pytest.raises(CyverDataValidationError, match="api_key"):
            CyverSession(portal=PORTAL, api_key=12345)

    def test_no_args_is_unauthenticated(self):
        s = CyverSession()
        assert s._api_key is None
        assert s.portal is None

    def test_portal_only_sets_portal_but_not_api_key(self):
        # portal without api_key is allowed (for backward-compat convenience);
        # the session is not yet authenticated.
        s = CyverSession(portal=PORTAL)
        assert s.portal == PORTAL
        assert s._api_key is None

    def test_non_string_portal_without_api_key_raises(self):
        with pytest.raises(CyverDataValidationError, match="portal"):
            CyverSession(portal=123)


# ---------------------------------------------------------------------------
# API-key mode — authenticate() is blocked
# ---------------------------------------------------------------------------

class TestApiKeyAuthenticateGuard:

    @pytest.fixture(autouse=True)
    def _no_probe(self):
        with patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True):
            yield

    def test_authenticate_raises_when_api_key_set(self):
        s = CyverSession(portal=PORTAL, api_key=API_KEY)
        with pytest.raises(CyverAuthError) as exc_info:
            s.authenticate(PORTAL, USERNAME, PASSWORD)
        assert exc_info.value.reason == "not_authenticated"

    def test_authenticate_error_mentions_api_key(self):
        s = CyverSession(portal=PORTAL, api_key=API_KEY)
        with pytest.raises(CyverAuthError, match="api_key"):
            s.authenticate(PORTAL, USERNAME, PASSWORD)


# ---------------------------------------------------------------------------
# API-key mode — _send_api_request() uses X-API-Key header
# ---------------------------------------------------------------------------

class TestApiKeyRequests:

    @pytest.fixture(autouse=True)
    def _no_probe(self):
        with patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True):
            yield

    def _make_api_key_session(self, mock_response):
        s = CyverSession(portal=PORTAL, api_key=API_KEY)
        s._session = MagicMock()
        s._session.send.return_value = mock_response
        return s

    def _get_request_headers(self, s):
        """Return the headers dict from the Request object passed to prepare_request."""
        return s._session.prepare_request.call_args[0][0].headers

    def test_x_api_key_header_is_set(self):
        from tests.conftest import make_api_response
        response = make_http_response(200, json_data=make_api_response({"ok": True}))
        s = self._make_api_key_session(response)
        s._send_api_request("GET", "/api/resource")
        assert self._get_request_headers(s).get("X-API-Key") == API_KEY

    def test_authorization_header_not_set_in_api_key_mode(self):
        from tests.conftest import make_api_response
        response = make_http_response(200, json_data=make_api_response({"ok": True}))
        s = self._make_api_key_session(response)
        s._send_api_request("GET", "/api/resource")
        assert "Authorization" not in self._get_request_headers(s)

    def test_api_key_mode_returns_result(self):
        from tests.conftest import make_api_response
        data = {"id": "abc"}
        response = make_http_response(200, json_data=make_api_response(data))
        s = self._make_api_key_session(response)
        assert s._send_api_request("GET", "/api/resource") == data

    def test_api_key_mode_http_errors_still_raised(self):
        response = make_http_response(403, content_type=None)
        s = self._make_api_key_session(response)
        with pytest.raises(CyverPermissionError):
            s._send_api_request("GET", "/api/resource")


# ---------------------------------------------------------------------------
# _probe_portal() — unit tests in isolation
# ---------------------------------------------------------------------------

class TestProbePortal:

    def _make_session(self):
        s = CyverSession()
        s._session = MagicMock()
        return s

    def test_active_portal_does_not_raise(self):
        s = self._make_session()
        s._session.get.return_value = MagicMock(text='{"success": false}')
        s._probe_portal(PORTAL)  # must not raise

    def test_inactive_portal_raises_portal_inactive(self):
        s = self._make_session()
        s._session.get.return_value = MagicMock(
            text="This account is (temporarily) inaccessible"
        )
        with pytest.raises(CyverAuthError) as exc_info:
            s._probe_portal("lalarilala.cyver.io")
        assert exc_info.value.reason == "portal_inactive"

    def test_inaccessible_check_is_case_insensitive(self):
        s = self._make_session()
        s._session.get.return_value = MagicMock(
            text="THIS ACCOUNT IS (TEMPORARILY) INACCESSIBLE"
        )
        with pytest.raises(CyverAuthError) as exc_info:
            s._probe_portal("lalarilala.cyver.io")
        assert exc_info.value.reason == "portal_inactive"

    def test_network_error_raises_portal_unreachable(self):
        s = self._make_session()
        s._session.get.side_effect = RequestException("DNS failure")
        with pytest.raises(CyverAuthError) as exc_info:
            s._probe_portal("unreachable.cyver.io")
        assert exc_info.value.reason == "portal_unreachable"

    def test_error_message_includes_portal_name(self):
        s = self._make_session()
        s._session.get.return_value = MagicMock(text="inaccessible")
        with pytest.raises(CyverAuthError, match="lalarilala.cyver.io"):
            s._probe_portal("lalarilala.cyver.io")

    def test_unreachable_preserves_original_exception(self):
        s = self._make_session()
        original = RequestException("timeout")
        s._session.get.side_effect = original
        with pytest.raises(CyverAuthError) as exc_info:
            s._probe_portal("bad.cyver.io")
        assert exc_info.value.__cause__ is original

    def test_both_reason_codes_are_cyver_auth_error(self):
        s = self._make_session()
        s._session.get.return_value = MagicMock(text="inaccessible")
        with pytest.raises(CyverAuthError):
            s._probe_portal("lalarilala.cyver.io")
        s._session.get.side_effect = RequestException("err")
        with pytest.raises(CyverAuthError):
            s._probe_portal("bad.cyver.io")


# ---------------------------------------------------------------------------
# Portal probe integration — authenticate() calls _probe_portal()
# ---------------------------------------------------------------------------

class TestPortalProbeInAuthenticate:

    def test_inactive_portal_raises_before_login(self):
        session = CyverSession()
        with patch.object(session, "_probe_portal",
                          side_effect=CyverAuthError("inactive", reason="portal_inactive")):
            with pytest.raises(CyverAuthError) as exc_info:
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            assert exc_info.value.reason == "portal_inactive"

    def test_unreachable_portal_raises_before_login(self):
        session = CyverSession()
        with patch.object(session, "_probe_portal",
                          side_effect=CyverAuthError("unreachable", reason="portal_unreachable")):
            with pytest.raises(CyverAuthError) as exc_info:
                session.authenticate(PORTAL, USERNAME, PASSWORD)
            assert exc_info.value.reason == "portal_unreachable"

    def test_probe_called_with_portal_argument(self):
        session = CyverSession()
        empty_cache = {"accessToken": None, "refreshToken": None, "userId": None, "portal": None}
        with patch.object(session, "_probe_portal") as mock_probe, \
             patch.object(session, "_fetch_oauth_cache", return_value=empty_cache), \
             patch.object(session, "_save_oauth_cache", return_value=True), \
             patch.object(session, "_send_api_request", return_value=make_auth_payload()), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            session.authenticate(PORTAL, USERNAME, PASSWORD)
        mock_probe.assert_called_once_with(PORTAL)

    def test_probe_not_called_when_input_validation_fails(self):
        session = CyverSession()
        with patch.object(session, "_probe_portal") as mock_probe:
            with pytest.raises(CyverDataValidationError):
                session.authenticate("", USERNAME, PASSWORD)
        mock_probe.assert_not_called()


# ---------------------------------------------------------------------------
# Portal probe integration — constructor calls _probe_portal() for api_key
# ---------------------------------------------------------------------------

class TestPortalProbeInConstructor:

    def test_inactive_portal_raises_on_construction(self):
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_delete_apikey_cache"), \
             patch.object(CyverSession, "_probe_portal",
                          side_effect=CyverAuthError("inactive", reason="portal_inactive")):
            with pytest.raises(CyverAuthError) as exc_info:
                CyverSession(portal=PORTAL, api_key=API_KEY)
            assert exc_info.value.reason == "portal_inactive"

    def test_unreachable_portal_raises_on_construction(self):
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_delete_apikey_cache"), \
             patch.object(CyverSession, "_probe_portal",
                          side_effect=CyverAuthError("unreachable", reason="portal_unreachable")):
            with pytest.raises(CyverAuthError) as exc_info:
                CyverSession(portal=PORTAL, api_key=API_KEY)
            assert exc_info.value.reason == "portal_unreachable"

    def test_probe_called_with_portal_argument(self):
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True), \
             patch.object(CyverSession, "_probe_portal") as mock_probe:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_probe.assert_called_once_with(PORTAL)

    def test_probe_not_called_without_api_key(self):
        with patch.object(CyverSession, "_probe_portal") as mock_probe:
            CyverSession()
        mock_probe.assert_not_called()

    def test_probe_not_called_when_portal_only(self):
        with patch.object(CyverSession, "_probe_portal") as mock_probe:
            CyverSession(portal=PORTAL)
        mock_probe.assert_not_called()


# ---------------------------------------------------------------------------
# API-key mode — cache-driven probe skip / cleanup
# ---------------------------------------------------------------------------

class TestApiKeyCaching:

    def test_probe_skipped_when_apikey_cache_matches_portal(self):
        """When the cached portal matches the constructor argument, probe must not run."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": PORTAL}), \
             patch.object(CyverSession, "_probe_portal") as mock_probe:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_probe.assert_not_called()

    def test_probe_called_when_no_apikey_cache(self):
        """When there is no cache entry (first time), the probe must run."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True), \
             patch.object(CyverSession, "_probe_portal") as mock_probe:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_probe.assert_called_once_with(PORTAL)

    def test_cache_saved_after_successful_first_probe(self):
        """After a successful first-time probe, the cache must be written."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_save_apikey_cache") as mock_save:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_save.assert_called_once()

    def test_cache_deleted_on_first_time_probe_failure(self):
        """When the first-time probe fails, the cache file must be deleted."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": None}), \
             patch.object(CyverSession, "_probe_portal",
                          side_effect=CyverAuthError("unreachable", reason="portal_unreachable")), \
             patch.object(CyverSession, "_delete_apikey_cache") as mock_delete:
            with pytest.raises(CyverAuthError):
                CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_delete.assert_called_once()

    def test_stale_cache_deleted_on_portal_mismatch(self):
        """When the cached portal differs from the constructor argument, the stale cache is deleted."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": "other.cyver.io"}), \
             patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True), \
             patch.object(CyverSession, "_delete_apikey_cache") as mock_delete:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_delete.assert_called_once()

    def test_probe_called_on_portal_mismatch(self):
        """When the cached portal differs, the probe must run with the new portal."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": "other.cyver.io"}), \
             patch.object(CyverSession, "_delete_apikey_cache"), \
             patch.object(CyverSession, "_save_apikey_cache", return_value=True), \
             patch.object(CyverSession, "_probe_portal") as mock_probe:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_probe.assert_called_once_with(PORTAL)

    def test_cache_saved_after_probe_on_portal_mismatch(self):
        """After a successful probe following a portal mismatch, the cache must be updated."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": "other.cyver.io"}), \
             patch.object(CyverSession, "_delete_apikey_cache"), \
             patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_save_apikey_cache") as mock_save:
            CyverSession(portal=PORTAL, api_key=API_KEY)
        mock_save.assert_called_once()

    def test_cache_deleted_on_probe_failure_after_portal_mismatch(self):
        """When a portal-mismatch re-probe fails, the cache must be deleted."""
        with patch.object(CyverSession, "_fetch_apikey_cache", return_value={"portal": "other.cyver.io"}), \
             patch.object(CyverSession, "_probe_portal",
                          side_effect=CyverAuthError("unreachable", reason="portal_unreachable")), \
             patch.object(CyverSession, "_delete_apikey_cache") as mock_delete:
            with pytest.raises(CyverAuthError):
                CyverSession(portal=PORTAL, api_key=API_KEY)
        # Called twice: once to clear the stale cache, once after the failed probe.
        assert mock_delete.call_count == 2
