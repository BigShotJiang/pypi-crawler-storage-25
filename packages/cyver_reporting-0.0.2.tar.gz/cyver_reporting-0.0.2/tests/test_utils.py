"""
Tests for format validators (_validate_uuid, _validate_jwt_token) in
CyverReporting.Utils.FormatValidators and field-extraction helpers
(_fd_optional_datetime, _fd_optional_date, _fd_optional_uuid,
_fd_optional_project_status) in CyverReporting.Utils.FieldExtractors.
"""

import time
import pytest
from unittest.mock import patch

from CyverReporting.Utils.FormatValidators import _validate_uuid, _validate_jwt_token
from CyverReporting.Utils.FieldExtractors import (
    _sentinels_datetime,
    _sentinels_date,
    _fd_optional_datetime,
    _fd_optional_date,
    _fd_optional_uuid,
    _fd_optional_project_status,
)
from CyverReporting.Exceptions import CyverDataValidationError


# ---------------------------------------------------------------------------
# _validate_uuid
# ---------------------------------------------------------------------------

class TestValidateUuid:

    # --- valid inputs (must not raise) ---

    def test_standard_lowercase(self):
        _validate_uuid("12345678-1234-1234-1234-123456789abc", "id")

    def test_standard_uppercase(self):
        _validate_uuid("12345678-1234-1234-1234-123456789ABC", "id")

    def test_mixed_case(self):
        _validate_uuid("12345678-abcd-ABCD-efEF-123456789abc", "id")

    def test_all_zeros(self):
        _validate_uuid("00000000-0000-0000-0000-000000000000", "id")

    def test_all_fs(self):
        _validate_uuid("ffffffff-ffff-ffff-ffff-ffffffffffff", "id")

    # --- invalid inputs (must raise CyverDataValidationError) ---

    def test_empty_string(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("", "id")

    def test_no_hyphens(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("123456781234123412341234567890ab", "id")

    def test_too_short(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-12345678abc", "id")

    def test_too_long(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-123456789abcd", "id")

    def test_wrong_group_order(self):
        # 4-8-4-4-12 instead of 8-4-4-4-12
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("1234-12345678-1234-1234-123456789abc", "id")

    def test_invalid_hex_characters(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-123456789xyz", "id")

    def test_spaces(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-123456789ab ", "id")

    def test_plain_string(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("not-a-uuid-at-all", "id")

    def test_field_name_appears_in_error(self):
        with pytest.raises(CyverDataValidationError, match="clientId"):
            _validate_uuid("bad-uuid", "clientId")

    def test_error_reason_is_invalid_uuid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_uuid("bad", "id")
        assert exc_info.value.reason == "invalid_uuid"


# ---------------------------------------------------------------------------
# _validate_jwt_token
# ---------------------------------------------------------------------------

class TestValidateJwtToken:
    """
    _jwt_decode is patched at the import site
    (CyverReporting.Utils.FormatValidators._jwt_decode) so these tests
    are independent of any installed PyJWT version.
    """

    def test_valid_token(self):
        exp = int(time.time()) + 3600
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            _validate_jwt_token("valid.token.sig", "accessToken")  # must not raise

    def test_expired_token(self):
        exp = int(time.time()) - 1
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("expired.token.sig", "accessToken")

    def test_missing_exp_claim(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"sub": "user"}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("no.exp.token", "accessToken")

    def test_exp_exactly_now(self):
        # Token whose expiry is the current second is treated as expired.
        exp = int(time.time())
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("boundary.token.sig", "accessToken")

    def test_malformed_token_raises_invalid_jwt(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", side_effect=Exception("bad token")):
            with pytest.raises(CyverDataValidationError, match="not a well-formed JWT"):
                _validate_jwt_token("malformed", "accessToken")

    def test_none_exp_value(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": None}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("none.exp.token", "accessToken")

    def test_field_name_appears_in_error(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", side_effect=Exception("bad")):
            with pytest.raises(CyverDataValidationError, match="refreshToken"):
                _validate_jwt_token("bad", "refreshToken")

    def test_error_reason_expired(self):
        exp = int(time.time()) - 1
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("expired.token.sig", "accessToken")
        assert exc_info.value.reason == "expired_jwt"

    def test_error_reason_invalid_jwt(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", side_effect=Exception("bad")):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("bad", "accessToken")
        assert exc_info.value.reason == "invalid_jwt"


# ---------------------------------------------------------------------------
# _fd_optional_datetime
# ---------------------------------------------------------------------------

class TestFdOptionalDatetime:

    # --- sentinel / absent values → None ---

    def test_key_absent_returns_none(self):
        assert _fd_optional_datetime({}, "startDate") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_datetime({"startDate": None}, "startDate") is None

    @pytest.mark.parametrize("sentinel", sorted(_sentinels_datetime))
    def test_sentinel_returns_none(self, sentinel):
        assert _fd_optional_datetime({"d": sentinel}, "d") is None

    # --- valid values → returned unchanged ---

    def test_valid_datetime_utc(self):
        v = "2024-06-15T10:30:00Z"
        assert _fd_optional_datetime({"d": v}, "d") == v

    def test_valid_datetime_with_fractional(self):
        v = "2024-06-15T10:30:00.123456Z"
        assert _fd_optional_datetime({"d": v}, "d") == v

    # --- wrong type → raises ---

    def test_non_string_raises(self):
        with pytest.raises(CyverDataValidationError, match="must be a string"):
            _fd_optional_datetime({"d": 12345}, "d")

    # --- invalid format → raises ---

    def test_invalid_format_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_optional_datetime({"d": "not-a-date"}, "d")


# ---------------------------------------------------------------------------
# _fd_optional_date
# ---------------------------------------------------------------------------

class TestFdOptionalDate:

    # --- sentinel / absent values → None ---

    def test_key_absent_returns_none(self):
        assert _fd_optional_date({}, "startDate") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_date({"startDate": None}, "startDate") is None

    @pytest.mark.parametrize("sentinel", sorted(_sentinels_date))
    def test_sentinel_returns_none(self, sentinel):
        assert _fd_optional_date({"d": sentinel}, "d") is None

    # --- valid value → returned unchanged ---

    def test_valid_date(self):
        v = "2024-06-15"
        assert _fd_optional_date({"d": v}, "d") == v

    # --- wrong type → raises ---

    def test_non_string_raises(self):
        with pytest.raises(CyverDataValidationError, match="must be a string"):
            _fd_optional_date({"d": 20240615}, "d")

    # --- invalid format → raises ---

    def test_invalid_format_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_optional_date({"d": "15-06-2024"}, "d")


# ---------------------------------------------------------------------------
# _fd_optional_uuid — empty string treated as absent
# ---------------------------------------------------------------------------

class TestFdOptionalUuid:

    def test_key_absent_returns_none(self):
        assert _fd_optional_uuid({}, "clientId") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_uuid({"clientId": None}, "clientId") is None

    def test_empty_string_returns_none(self):
        assert _fd_optional_uuid({"clientId": ""}, "clientId") is None

    def test_valid_uuid_returned(self):
        v = "12345678-1234-1234-1234-123456789abc"
        assert _fd_optional_uuid({"clientId": v}, "clientId") == v

    def test_invalid_uuid_raises(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _fd_optional_uuid({"clientId": "not-a-uuid"}, "clientId")


# ---------------------------------------------------------------------------
# _fd_optional_project_status — empty string treated as absent
# ---------------------------------------------------------------------------

class TestFdOptionalProjectStatus:

    def test_key_absent_returns_none(self):
        assert _fd_optional_project_status({}, "status") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_project_status({"status": None}, "status") is None

    def test_empty_string_returns_none(self):
        assert _fd_optional_project_status({"status": ""}, "status") is None

    def test_valid_status_returned(self):
        assert _fd_optional_project_status({"status": "TESTING"}, "status") == "TESTING"

    def test_invalid_status_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_optional_project_status({"status": "UNKNOWN"}, "status")


# ---------------------------------------------------------------------------
# Integration — CyverProjectDates.from_dict with all-sentinel payload
# ---------------------------------------------------------------------------

class TestCyverProjectDatesSentinels:

    def test_all_sentinel_datetimes_parsed_as_none(self):
        from CyverReporting.DataTypes.CyverProjectDates import CyverProjectDates

        payload = {
            "startDate":          "0001-01-01T00:00:00",
            "endDate":            "0001-01-01T00:00:00",
            "startTesting":       "0001-01-01T00:00:00",
            "endTesting":         "0001-01-01T00:00:00",
            "creationTime":       "0001-01-01T00:00:00",
            "reportDueDate":      "0001-01-01T00:00:00",
            "reportPublishedAt":  "0001-01-01T00:00:00",
            "planningDates":      [],
        }
        obj = CyverProjectDates.from_dict(payload)

        assert obj._start_date         is None
        assert obj._end_date           is None
        assert obj._start_testing      is None
        assert obj._end_testing        is None
        assert obj._creation_time      is None
        assert obj._report_due_date    is None
        assert obj._report_published_at is None
        assert obj._planning_dates     == []

    def test_mixed_sentinel_and_real_dates(self):
        from CyverReporting.DataTypes.CyverProjectDates import CyverProjectDates

        payload = {
            "startDate":    "2024-01-15T09:00:00Z",
            "endDate":      "0001-01-01T00:00:00",
            "startTesting": "2024-01-20T09:00:00Z",
            "endTesting":   "0001-01-01T00:00:00",
        }
        obj = CyverProjectDates.from_dict(payload)

        assert obj._start_date    == "2024-01-15T09:00:00Z"
        assert obj._end_date      is None
        assert obj._start_testing == "2024-01-20T09:00:00Z"
        assert obj._end_testing   is None


# ---------------------------------------------------------------------------
# Integration — CyverPlanningDate.from_dict with sentinel dates
# ---------------------------------------------------------------------------

class TestCyverPlanningDateSentinels:

    def test_sentinel_dates_parsed_as_none(self):
        from CyverReporting.DataTypes.CyverPlanningDate import CyverPlanningDate

        payload = {"startDate": "0001-01-01", "endDate": "0001-01-01"}
        obj = CyverPlanningDate.from_dict(payload)

        assert obj._start_date is None
        assert obj._end_date   is None
