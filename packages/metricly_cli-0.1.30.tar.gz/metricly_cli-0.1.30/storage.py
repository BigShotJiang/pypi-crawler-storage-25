"""Storage utilities for Firestore (manifests, dashboards, config)."""

import hashlib
import json
import os
from datetime import datetime, UTC
from pathlib import Path
from typing import Optional

from google.cloud import firestore
from google.cloud.firestore_v1._helpers import DatetimeWithNanoseconds
from google.cloud.firestore_v1.base_query import FieldFilter

# Initialize client lazily
_firestore_client: Optional[firestore.Client] = None

PROJECT_ID = "metricly-dev"

# Development mode - use local files for manifest bootstrap
IS_DEV = os.environ.get("ENV") == "development"

# Local manifest paths for development bootstrap (relative to backend directory)
# These are only used when Firestore has no data - run seed script to import
LOCAL_MANIFEST_PATHS = {
    "local-dev": "../examples/demo-dbt-project/semantic_manifest.json",
}


def get_firestore_client() -> firestore.Client:
    """Get or create Firestore client."""
    global _firestore_client
    if _firestore_client is None:
        _firestore_client = firestore.Client(project=PROJECT_ID)
    return _firestore_client


def _serialize_firestore_doc(data: dict) -> dict:
    """Convert Firestore document to JSON-serializable dict.

    Converts DatetimeWithNanoseconds to ISO format strings.
    """
    result = {}
    for key, value in data.items():
        if isinstance(value, DatetimeWithNanoseconds):
            result[key] = value.isoformat()
        elif isinstance(value, datetime):
            result[key] = value.isoformat()
        elif isinstance(value, dict):
            result[key] = _serialize_firestore_doc(value)
        elif isinstance(value, list):
            result[key] = [
                _serialize_firestore_doc(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


# =============================================================================
# Manifest Storage (Firestore with local dev fallback for bootstrap)
# =============================================================================

def get_manifest(org_id: str) -> Optional[dict]:
    """Get semantic manifest from Firestore, or local file in dev mode for bootstrap.

    Priority:
    1. Generate from Firestore (semantic_models + metrics collections)
    2. Fall back to local file in dev mode (for bootstrap before import)
    """
    # Try generating from Firestore first
    manifest = generate_manifest(org_id)

    # Check if we have any data in Firestore
    if manifest.get("semantic_models") or manifest.get("metrics"):
        return manifest

    # No Firestore data - try local file in dev mode for bootstrap
    if IS_DEV and org_id in LOCAL_MANIFEST_PATHS:
        local_path = Path(__file__).parent / LOCAL_MANIFEST_PATHS[org_id]
        if local_path.exists():
            content = local_path.read_text()
            return json.loads(content)

    return None


def get_manifest_status(org_id: str) -> dict:
    """Get manifest status (metadata without full content).

    Uses Firestore as primary source, with local file fallback for dev bootstrap.
    """
    db = get_firestore_client()

    # Try generating from Firestore first
    manifest = generate_manifest(org_id)

    # Check if we have any data in Firestore
    if manifest.get("semantic_models") or manifest.get("metrics"):
        # Get upload timestamp from project_configuration if available
        config_ref = db.collection("organizations").document(org_id).collection("config").document("project_configuration")
        config_doc = config_ref.get()
        updated_at = None
        if config_doc.exists:
            config_data = config_doc.to_dict()
            updated_at = config_data.get("_imported_at")
        return _extract_manifest_status(manifest, updated_at)

    # No Firestore data - try local file in dev mode for bootstrap
    if IS_DEV and org_id in LOCAL_MANIFEST_PATHS:
        local_path = Path(__file__).parent / LOCAL_MANIFEST_PATHS[org_id]
        if local_path.exists():
            content = local_path.read_text()
            local_manifest = json.loads(content)
            return _extract_manifest_status(local_manifest, local_path.stat().st_mtime)

    return {"status": "not_configured"}


# Re-export from cache.manifest for backward compatibility


def _extract_manifest_status(manifest: dict, updated_at) -> dict:
    """Extract status info from a manifest."""
    metrics = manifest.get("metrics", [])
    semantic_models = manifest.get("semantic_models", [])

    # Count unique dimensions
    all_dimensions = set()
    for model in semantic_models:
        for dim in model.get("dimensions", []):
            all_dimensions.add(dim.get("name", ""))

    project_name = manifest.get("project_configuration", {}).get("name")

    # Handle datetime, float (mtime), string (ISO format), and None for updated_at
    if isinstance(updated_at, float):
        uploaded_at = datetime.fromtimestamp(updated_at).isoformat()
    elif isinstance(updated_at, str):
        uploaded_at = updated_at  # Already ISO format
    elif updated_at:
        uploaded_at = updated_at.isoformat()
    else:
        uploaded_at = None

    return {
        "status": "configured",
        "metrics": len(metrics),
        "dimensions": len(all_dimensions),
        "semantic_models": len(semantic_models),
        "project_name": project_name,
        "uploaded_at": uploaded_at,
    }


def save_manifest(org_id: str, manifest: dict) -> dict:
    """Save semantic manifest. (DEPRECATED: Now uses Firestore via import_manifest)

    This function is kept for backward compatibility but no longer saves to GCS.
    Use import_manifest() directly for new code.
    """
    # Return status info only - actual saving happens via import_manifest
    metrics = manifest.get("metrics", [])
    semantic_models = manifest.get("semantic_models", [])

    all_dimensions = set()
    for model in semantic_models:
        for dim in model.get("dimensions", []):
            all_dimensions.add(dim.get("name", ""))

    project_name = manifest.get("project_configuration", {}).get("name")

    return {
        "status": "ok",
        "metrics": len(metrics),
        "dimensions": len(all_dimensions),
        "semantic_models": len(semantic_models),
        "project_name": project_name,
    }


# =============================================================================
# Dashboard Storage (Firestore) - Multi-dashboard with Personal/Team sections
# =============================================================================

def list_dashboards(org_id: str, user_id: str) -> dict:
    """List dashboards visible to user, split into personal and shared sections.

    Returns:
        {
            "personal": [...],  # Private dashboards owned by user
            "team": [...],      # All shared dashboards (visibility=org), including user's own
        }
    """
    db = get_firestore_client()
    dashboards_ref = db.collection("organizations").document(org_id).collection("dashboards")

    # Get all dashboards in org
    all_docs = dashboards_ref.stream()

    personal = []
    team = []

    for doc in all_docs:
        data = _serialize_firestore_doc(doc.to_dict())
        data["id"] = doc.id

        is_owner = data.get("owner") == user_id
        is_shared = data.get("visibility") == "org"

        if is_shared:
            # All shared dashboards go to team section (including user's own)
            team.append(data)
        elif is_owner:
            # User's private dashboards go to personal
            personal.append(data)
        # Skip private dashboards owned by others

    # Get user's dashboard order preferences
    member_ref = db.collection("organizations").document(org_id).collection("members").document(user_id)
    member_doc = member_ref.get()
    personal_order = []
    team_order = []

    if member_doc.exists:
        member_data = member_doc.to_dict()
        personal_order = member_data.get("personalDashboardOrder", [])
        team_order = member_data.get("teamDashboardOrder", [])

    # Sort by user's order preference, unordered items at end
    def sort_by_order(items: list, order: list) -> list:
        order_map = {id: idx for idx, id in enumerate(order)}
        return sorted(items, key=lambda x: order_map.get(x["id"], len(order)))

    return {
        "personal": sort_by_order(personal, personal_order),
        "team": sort_by_order(team, team_order),
    }


def get_dashboard(org_id: str, dashboard_id: str, user_id: str) -> Optional[dict]:
    """Get a specific dashboard if user has access."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("dashboards").document(dashboard_id)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    data = _serialize_firestore_doc(doc.to_dict())
    data["id"] = doc.id

    # Check access: owner can always access, others only if visibility=org
    if data.get("owner") != user_id and data.get("visibility") != "org":
        return None

    return data


def get_dashboard_internal(org_id: str, dashboard_id: str) -> Optional[dict]:
    """Get a dashboard by ID without user access checks.

    This is for internal/server-side use only, such as render token validation
    where the token already grants access to the resource.
    """
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("dashboards").document(dashboard_id)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    data = _serialize_firestore_doc(doc.to_dict())
    data["id"] = doc.id
    return data


def create_dashboard(org_id: str, user_id: str, dashboard: dict) -> dict:
    """Create a new dashboard owned by user."""
    db = get_firestore_client()
    dashboards_ref = db.collection("organizations").document(org_id).collection("dashboards")

    now = datetime.now(UTC).isoformat() + "Z"
    dashboard["owner"] = user_id
    dashboard["visibility"] = dashboard.get("visibility", "private")
    dashboard["created_at"] = now
    dashboard["updated_at"] = now
    dashboard["created_by"] = user_id
    dashboard["version"] = 1  # Initialize version for optimistic locking

    # Create with auto-generated ID
    doc_ref = dashboards_ref.document()
    dashboard["id"] = doc_ref.id
    doc_ref.set(dashboard)

    # Add to user's personal order
    member_ref = db.collection("organizations").document(org_id).collection("members").document(user_id)
    member_doc = member_ref.get()
    if member_doc.exists:
        personal_order = member_doc.to_dict().get("personalDashboardOrder", [])
        personal_order.append(doc_ref.id)
        member_ref.update({"personalDashboardOrder": personal_order})

    return dashboard


def update_dashboard(
    org_id: str,
    dashboard_id: str,
    user_id: str,
    updates: dict,
    expected_version: Optional[int] = None,
) -> Optional[dict]:
    """Update a dashboard with optional optimistic locking.

    Args:
        org_id: Organization ID
        dashboard_id: Dashboard ID
        user_id: User ID (must be owner)
        updates: Fields to update
        expected_version: If provided, reject if current version doesn't match

    Returns:
        Updated dashboard dict or None if not found/not owner

    Raises:
        ConflictError: If version mismatch detected (imported from services.dashboards)
    """
    # Import here to avoid circular import
    from services.dashboards import ConflictError

    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("dashboards").document(dashboard_id)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    data = doc.to_dict()

    # Only owner can update
    if data.get("owner") != user_id:
        return None

    # Check version for optimistic locking
    current_version = data.get("version", 1)
    if expected_version is not None:
        if current_version != expected_version:
            raise ConflictError(
                f"Dashboard was modified (version {current_version}, expected {expected_version})",
                current_version=current_version,
                expected_version=expected_version,
            )

    # Don't allow changing owner
    updates.pop("owner", None)
    updates.pop("id", None)
    updates.pop("created_at", None)
    updates.pop("created_by", None)
    updates.pop("version", None)  # Don't allow manual version changes

    updates["updated_at"] = datetime.now(UTC).isoformat() + "Z"
    # Increment version on every update
    updates["version"] = current_version + 1

    doc_ref.update(updates)

    # Return updated document
    updated = _serialize_firestore_doc(doc_ref.get().to_dict())
    updated["id"] = dashboard_id
    return updated


def delete_dashboard(org_id: str, dashboard_id: str, user_id: str) -> bool:
    """Delete a dashboard. Only owner can delete."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("dashboards").document(dashboard_id)
    doc = doc_ref.get()

    if not doc.exists:
        return False

    data = doc.to_dict()

    # Only owner can delete
    if data.get("owner") != user_id:
        return False

    doc_ref.delete()

    # Remove from user's personal order
    member_ref = db.collection("organizations").document(org_id).collection("members").document(user_id)
    member_doc = member_ref.get()
    if member_doc.exists:
        personal_order = member_doc.to_dict().get("personalDashboardOrder", [])
        if dashboard_id in personal_order:
            personal_order.remove(dashboard_id)
            member_ref.update({"personalDashboardOrder": personal_order})

    return True


def update_dashboard_order(org_id: str, user_id: str, personal_order: Optional[list] = None, team_order: Optional[list] = None) -> dict:
    """Update user's dashboard order preferences."""
    db = get_firestore_client()
    member_ref = db.collection("organizations").document(org_id).collection("members").document(user_id)

    updates = {}
    if personal_order is not None:
        updates["personalDashboardOrder"] = personal_order
    if team_order is not None:
        updates["teamDashboardOrder"] = team_order

    if updates:
        member_ref.update(updates)

    return {"status": "ok"}


# =============================================================================
# Business Context Storage (Firestore)
# =============================================================================

def get_business_context(org_id: str) -> Optional[str]:
    """Get business context markdown from Firestore."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("config").document("context")
    doc = doc_ref.get()

    if not doc.exists:
        return None

    data = doc.to_dict()
    return data.get("content")


def save_business_context(org_id: str, content: str) -> dict:
    """Save business context to Firestore."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("config").document("context")

    doc_ref.set({
        "content": content,
        "updated_at": datetime.now(UTC).isoformat() + "Z",
    })

    return {"status": "ok"}


# =============================================================================
# User Preferences Storage (Firestore)
# =============================================================================

def get_user_preferences(user_id: str) -> Optional[dict]:
    """Get user preferences from Firestore.

    Path: users/{uid}/preferences/context

    Returns:
        User preferences dict or None if not found
    """
    db = get_firestore_client()
    doc_ref = db.collection("users").document(user_id).collection("preferences").document("context")
    doc = doc_ref.get()

    if not doc.exists:
        return None

    return _serialize_firestore_doc(doc.to_dict())


def save_user_preferences(user_id: str, preferences: dict) -> dict:
    """Save user preferences to Firestore.

    Path: users/{uid}/preferences/context

    Args:
        user_id: User's UID
        preferences: Complete preferences dict to persist

    Returns:
        Updated preferences dict
    """
    db = get_firestore_client()
    doc_ref = db.collection("users").document(user_id).collection("preferences").document("context")

    # Add timestamp
    preferences["updated_at"] = datetime.now(UTC).isoformat() + "Z"

    # Replace the full document so removed preference fields are actually cleared.
    doc_ref.set(preferences)

    return _serialize_firestore_doc(doc_ref.get().to_dict())


# =============================================================================
# Org Knowledge Storage (Firestore)
# =============================================================================


def list_knowledge_items(
    org_id: str,
    *,
    item_type: str | None = None,
    status: str | None = None,
    subject: str | None = None,
    limit: int | None = None,
) -> list[dict]:
    """List typed knowledge items for an organization."""
    db = get_firestore_client()
    query = (
        db.collection("organizations")
        .document(org_id)
        .collection("knowledge")
    )

    if item_type:
        query = query.where(filter=FieldFilter("type", "==", item_type))
    if status:
        query = query.where(filter=FieldFilter("status", "==", status))
    if subject:
        query = query.where(filter=FieldFilter("subjects", "array_contains", subject))

    query = query.order_by("updated_at", direction="DESCENDING")
    if limit is not None:
        query = query.limit(limit)

    docs = query.stream()
    items = []
    for doc in docs:
        data = _serialize_firestore_doc(doc.to_dict())
        data["id"] = doc.id
        items.append(data)
    return items


def get_knowledge_item(org_id: str, item_id: str) -> Optional[dict]:
    """Get a specific org knowledge item."""
    db = get_firestore_client()
    doc_ref = (
        db.collection("organizations")
        .document(org_id)
        .collection("knowledge")
        .document(item_id)
    )
    doc = doc_ref.get()
    if not doc.exists:
        return None

    data = _serialize_firestore_doc(doc.to_dict())
    data["id"] = doc.id
    return data


def save_knowledge_item(org_id: str, item_id: str, item: dict) -> dict:
    """Create or update an org knowledge item."""
    db = get_firestore_client()
    doc_ref = (
        db.collection("organizations")
        .document(org_id)
        .collection("knowledge")
        .document(item_id)
    )
    doc_ref.set(item)
    saved = _serialize_firestore_doc(doc_ref.get().to_dict())
    saved["id"] = doc_ref.id
    return saved


def delete_knowledge_item(org_id: str, item_id: str) -> bool:
    """Delete an org knowledge item."""
    db = get_firestore_client()
    doc_ref = (
        db.collection("organizations")
        .document(org_id)
        .collection("knowledge")
        .document(item_id)
    )
    doc = doc_ref.get()
    if not doc.exists:
        return False

    doc_ref.delete()
    return True


# =============================================================================
# Warehouse Config Storage (Firestore)
# =============================================================================

# Warehouse config schema:
# {
#   "type": "bigquery" | "duckdb",
#   "bigquery": {  # if type == "bigquery"
#     "project_id": "customer-warehouse",
#     "dataset": "analytics",
#     "service_account_secret": "projects/metricly-dev/secrets/org-xxx-bq-key/versions/latest"
#   },
#   "duckdb": {  # if type == "duckdb"
#     "motherduck_token_secret": "projects/metricly-dev/secrets/org-xxx-md-token/versions/latest",
#     "database": "md:my_database"
#     # OR for local/GCS file:
#     "path": "gs://bucket/org/warehouse.duckdb"
#   }
# }


def get_warehouse_config(org_id: str) -> Optional[dict]:
    """Get warehouse configuration for an organization."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("config").document("warehouse")
    doc = doc_ref.get()

    if not doc.exists:
        return None

    return doc.to_dict()


def save_warehouse_config(org_id: str, config: dict) -> dict:
    """Save warehouse configuration for an organization.

    Args:
        org_id: Organization ID
        config: Warehouse config with 'type' and type-specific settings

    Returns:
        Status dict with saved config summary
    """
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("config").document("warehouse")

    # Validate required fields
    warehouse_type = config.get("type")
    if warehouse_type not in ("bigquery", "duckdb"):
        raise ValueError(f"Invalid warehouse type: {warehouse_type}. Must be 'bigquery' or 'duckdb'")

    if warehouse_type == "bigquery":
        bq_config = config.get("bigquery", {})
        if not bq_config.get("project_id"):
            raise ValueError("BigQuery config requires 'project_id'")
    elif warehouse_type == "duckdb":
        duck_config = config.get("duckdb", {})
        if not duck_config.get("database") and not duck_config.get("path"):
            raise ValueError("DuckDB config requires 'database' or 'path'")

    config["updated_at"] = datetime.now(UTC).isoformat() + "Z"
    doc_ref.set(config)

    return {
        "status": "ok",
        "type": warehouse_type,
    }


def delete_warehouse_config(org_id: str) -> dict:
    """Delete warehouse configuration for an organization."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("config").document("warehouse")
    doc_ref.delete()
    return {"status": "ok"}


# =============================================================================
# Semantic Layer Storage (Firestore)
# =============================================================================
#
# Collections:
#   organizations/{orgId}/semantic_models/{name} - Semantic model definitions
#   organizations/{orgId}/metrics/{name} - Metric definitions
#
# Provenance fields:
#   _origin: "imported" | "metricly" - where the definition came from
#   _imported_at: ISO timestamp of when it was imported from manifest
#   _imported_hash: hash of the original imported JSON for conflict detection
#   _modified_at: ISO timestamp of last modification in Metricly
#   _modified_by: user ID who made the modification


def _compute_hash(data: dict) -> str:
    """Compute stable hash of a dictionary for conflict detection."""
    # Remove provenance fields before hashing
    clean = {k: v for k, v in data.items() if not k.startswith("_")}
    json_str = json.dumps(clean, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(json_str.encode()).hexdigest()[:16]


# -----------------------------------------------------------------------------
# Semantic Models
# -----------------------------------------------------------------------------

def list_semantic_models(org_id: str) -> list[dict]:
    """List all semantic models for an organization."""
    db = get_firestore_client()
    models_ref = db.collection("organizations").document(org_id).collection("semantic_models")

    models = []
    for doc in models_ref.stream():
        data = doc.to_dict()
        data["name"] = doc.id
        models.append(data)

    return models


def get_semantic_model(org_id: str, name: str) -> Optional[dict]:
    """Get a specific semantic model by name."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("semantic_models").document(name)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    data = doc.to_dict()
    data["name"] = doc.id
    return data


def save_semantic_model(org_id: str, model: dict, user_id: Optional[str] = None) -> dict:
    """Save a semantic model. Used for both import and updates.

    Args:
        org_id: Organization ID
        model: Semantic model data (must include 'name')
        user_id: User making the change (None for imports)

    Returns:
        Saved model with provenance fields
    """
    db = get_firestore_client()
    name = model.get("name")
    if not name:
        raise ValueError("Semantic model must have a 'name' field")

    doc_ref = db.collection("organizations").document(org_id).collection("semantic_models").document(name)

    now = datetime.now(UTC).isoformat() + "Z"

    # Check if exists
    existing = doc_ref.get()
    if existing.exists:
        # Update existing
        model["_modified_at"] = now
        if user_id:
            model["_modified_by"] = user_id
    else:
        # New model - set imported timestamp if not present
        if "_imported_at" not in model:
            model["_imported_at"] = now

    doc_ref.set(model)

    data = doc_ref.get().to_dict()
    data["name"] = name
    return data


def create_semantic_model(org_id: str, model: dict, user_id: str) -> dict:
    """Create a new semantic model. Only for Metricly-created models.

    Args:
        org_id: Organization ID
        model: Semantic model data (must include 'name')
        user_id: User creating the model

    Returns:
        Created model with provenance fields
    """
    db = get_firestore_client()
    name = model.get("name")
    if not name:
        raise ValueError("Semantic model must have a 'name' field")

    doc_ref = db.collection("organizations").document(org_id).collection("semantic_models").document(name)

    # Check if already exists
    if doc_ref.get().exists:
        raise ValueError(f"Semantic model '{name}' already exists")

    now = datetime.now(UTC).isoformat() + "Z"
    model["_origin"] = "metricly"
    model["_modified_at"] = now
    model["_modified_by"] = user_id

    doc_ref.set(model)

    data = doc_ref.get().to_dict()
    data["name"] = name
    return data


def update_semantic_model(org_id: str, name: str, updates: dict, user_id: str) -> Optional[dict]:
    """Update an existing semantic model.

    Auto-fork: if the existing model has ``_origin: "imported"``, this update
    promotes it to ``_origin: "metricly"`` so it survives the next manifest
    upload. The returned dict carries ``forked_from_imported: True`` on the
    call that performed the promotion.

    Args:
        org_id: Organization ID
        name: Semantic model name
        updates: Fields to update
        user_id: User making the change

    Returns:
        Updated model or None if not found
    """
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("semantic_models").document(name)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    existing = doc.to_dict() or {}

    # Don't let the caller change identity or import provenance
    updates.pop("name", None)
    updates.pop("_origin", None)
    updates.pop("_imported_at", None)
    updates.pop("_imported_hash", None)

    now = datetime.now(UTC).isoformat() + "Z"
    updates["_modified_at"] = now
    updates["_modified_by"] = user_id

    forked = existing.get("_origin") == "imported"
    if forked:
        updates["_origin"] = "metricly"

    doc_ref.update(updates)

    data = doc_ref.get().to_dict()
    data["name"] = name
    if forked:
        data["forked_from_imported"] = True
    return data


def delete_semantic_model(org_id: str, name: str) -> bool:
    """Delete a semantic model by name."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("semantic_models").document(name)
    doc = doc_ref.get()

    if not doc.exists:
        return False

    doc_ref.delete()
    return True


# -----------------------------------------------------------------------------
# Metrics
# -----------------------------------------------------------------------------

def list_metrics(org_id: str) -> list[dict]:
    """List all metrics for an organization."""
    db = get_firestore_client()
    metrics_ref = db.collection("organizations").document(org_id).collection("metrics")

    metrics = []
    for doc in metrics_ref.stream():
        data = doc.to_dict()
        data["name"] = doc.id
        metrics.append(data)

    return metrics


def get_metric(org_id: str, name: str) -> Optional[dict]:
    """Get a specific metric by name."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("metrics").document(name)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    data = doc.to_dict()
    data["name"] = doc.id
    return data


def create_metric(org_id: str, metric: dict, user_id: str) -> dict:
    """Create a new metric. Only for Metricly-created metrics.

    Args:
        org_id: Organization ID
        metric: Metric data (must include 'name')
        user_id: User creating the metric

    Returns:
        Created metric with provenance fields
    """
    db = get_firestore_client()
    name = metric.get("name")
    if not name:
        raise ValueError("Metric must have a 'name' field")

    doc_ref = db.collection("organizations").document(org_id).collection("metrics").document(name)

    # Check if already exists
    if doc_ref.get().exists:
        raise ValueError(f"Metric '{name}' already exists")

    now = datetime.now(UTC).isoformat() + "Z"
    metric["_origin"] = "metricly"
    metric["_modified_at"] = now
    metric["_modified_by"] = user_id

    doc_ref.set(metric)

    data = doc_ref.get().to_dict()
    data["name"] = name
    return data


def update_metric(org_id: str, name: str, updates: dict, user_id: str) -> Optional[dict]:
    """Update an existing metric.

    Auto-fork: if the existing metric has ``_origin: "imported"``, this update
    promotes it to ``_origin: "metricly"`` so it survives the next manifest
    upload. The returned dict carries ``forked_from_imported: True`` on the
    call that performed the promotion. Subsequent updates to the now
    metricly-origin metric do not flip the flag.

    Args:
        org_id: Organization ID
        name: Metric name
        updates: Fields to update
        user_id: User making the change

    Returns:
        Updated metric or None if not found
    """
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("metrics").document(name)
    doc = doc_ref.get()

    if not doc.exists:
        return None

    existing = doc.to_dict() or {}

    # Don't let the caller change identity or import provenance
    updates.pop("name", None)
    updates.pop("_origin", None)
    updates.pop("_imported_at", None)
    updates.pop("_imported_hash", None)

    now = datetime.now(UTC).isoformat() + "Z"
    updates["_modified_at"] = now
    updates["_modified_by"] = user_id

    forked = existing.get("_origin") == "imported"
    if forked:
        updates["_origin"] = "metricly"

    doc_ref.update(updates)

    data = doc_ref.get().to_dict()
    data["name"] = name
    if forked:
        data["forked_from_imported"] = True
    return data


def delete_metric(org_id: str, name: str) -> bool:
    """Delete a metric by name."""
    db = get_firestore_client()
    doc_ref = db.collection("organizations").document(org_id).collection("metrics").document(name)
    doc = doc_ref.get()

    if not doc.exists:
        return False

    doc_ref.delete()
    return True


# -----------------------------------------------------------------------------
# Manifest Import
# -----------------------------------------------------------------------------

def _list_quick_metric_expressions(db, org_id: str) -> list[dict]:
    """Return quick metrics for an org as a list of {name, expression} dicts.

    Lightweight read used by import_manifest to validate that quick metrics still
    resolve against the post-replace effective metric set. Returns [] if the
    collection doesn't exist.
    """
    try:
        coll = db.collection("organizations").document(org_id).collection("quick_metrics")
        out: list[dict] = []
        for doc in coll.stream():
            data = doc.to_dict() or {}
            name = data.get("name") or doc.id
            expr = data.get("expression")
            out.append({"name": name, "expression": expr})
        return out
    except Exception:
        return []


def _validate_quick_metric_refs(
    quick_metrics: list[dict],
    available_metric_names: set[str],
) -> list[str]:
    """Check each quick metric's expression resolves against available metrics.

    Returns a list of human-readable error strings (empty if all resolve).
    Tolerates parsing errors by reporting them; never raises.
    """
    if not quick_metrics:
        return []

    try:
        from services.quick_metrics import parse_expression, validate_metrics_exist
    except Exception:
        # If quick_metrics module fails to import, skip this check rather than
        # blocking the upload — the import-time error is unrelated.
        return []

    errors: list[str] = []
    for qm in quick_metrics:
        name = qm.get("name") or "<unnamed>"
        expression = qm.get("expression")
        if not expression:
            continue
        try:
            parsed = parse_expression(expression)
        except Exception as e:
            errors.append(f"Quick metric '{name}' has unparseable expression: {e}")
            continue
        missing = validate_metrics_exist(parsed.base_metrics, list(available_metric_names))
        if missing:
            errors.append(
                f"Quick metric '{name}' references metrics that will not exist after import: {', '.join(missing)}"
            )
    return errors


def import_manifest(org_id: str, manifest: dict) -> dict:
    """Replace the imported namespace from a manifest, atomically.

    Replace semantics:
    - The dbt manifest is the source of truth for the imported namespace.
    - Existing imported-origin items absent from the upload are hard-deleted.
    - Existing metricly-origin items (created via Metricly UI/MCP) are untouched.
    - A name collision between an upload item and a metricly-origin item is a
      conflict; the metricly version wins, the upload entry is skipped.

    Validation gates (writes are skipped on failure):
    1. The uploaded manifest must be internally consistent (validate_manifest).
    2. The post-replace effective state (incoming + retained metricly items)
       must have all metric→measure / metric→metric references resolved.
    3. Existing quick metrics must still resolve against the post-replace
       metric set.

    On validation failure raises ValueError with a structured message naming
    the unresolved references. No Firestore writes happen.

    Args:
        org_id: Organization ID
        manifest: Full semantic manifest dict

    Returns:
        Import summary:
            {
                "semantic_models": {"imported", "updated", "deleted", "skipped", "conflicts"},
                "metrics":         {"imported", "updated", "deleted", "skipped", "conflicts"},
                "orphaned": {"semantic_models": [...names deleted...],
                             "metrics":         [...names deleted...]}
            }
        (`orphaned` is preserved for backward compatibility with CLI consumers;
        under replace semantics it now lists items deleted, not soft-orphans.)
    """
    db = get_firestore_client()
    now = datetime.now(UTC).isoformat() + "Z"

    # ---- 1. Validate uploaded manifest in isolation ----
    upload_validation = validate_manifest(manifest)
    if not upload_validation["valid"]:
        raise ValueError(
            "Uploaded manifest is internally inconsistent:\n  - "
            + "\n  - ".join(upload_validation["errors"])
        )

    # ---- 2. Read existing state ----
    existing_models = {m["name"]: m for m in list_semantic_models(org_id)}
    existing_metrics = {m["name"]: m for m in list_metrics(org_id)}

    incoming_models = {m["name"]: m for m in manifest.get("semantic_models", []) if m.get("name")}
    incoming_metrics = {m["name"]: m for m in manifest.get("metrics", []) if m.get("name")}

    result: dict = {
        "semantic_models": {"imported": 0, "updated": 0, "deleted": 0, "skipped": 0, "conflicts": []},
        "metrics": {"imported": 0, "updated": 0, "deleted": 0, "skipped": 0, "conflicts": []},
    }

    # ---- 3. Plan the replace for semantic_models ----
    # Conflict rule for models: an existing metricly-origin model with the same
    # name as an incoming model wins; the incoming model is skipped.
    models_to_write: dict[str, dict] = {}
    models_to_delete: list[str] = []

    for name, model in incoming_models.items():
        if name in existing_models and existing_models[name].get("_origin") == "metricly":
            result["semantic_models"]["conflicts"].append(name)
            result["semantic_models"]["skipped"] += 1
            continue
        # Mark as imported-origin and stamp provenance
        prepared = {k: v for k, v in model.items() if not k.startswith("_")}
        prepared["_origin"] = "imported"
        prepared["_imported_at"] = now
        prepared["_imported_hash"] = _compute_hash(prepared)
        models_to_write[name] = prepared
        if name in existing_models:
            result["semantic_models"]["updated"] += 1
        else:
            result["semantic_models"]["imported"] += 1

    for name, existing in existing_models.items():
        if name in incoming_models:
            continue
        # Not in upload. Delete only if it's imported-origin.
        if existing.get("_origin") != "metricly":
            models_to_delete.append(name)

    # ---- 4. Plan the replace for metrics ----
    metrics_to_write: dict[str, dict] = {}
    metrics_to_delete: list[str] = []

    for name, metric in incoming_metrics.items():
        if name in existing_metrics and existing_metrics[name].get("_origin") == "metricly":
            result["metrics"]["conflicts"].append(name)
            result["metrics"]["skipped"] += 1
            continue
        prepared = {k: v for k, v in metric.items() if not k.startswith("_")}
        prepared["_origin"] = "imported"
        prepared["_imported_at"] = now
        prepared["_imported_hash"] = _compute_hash(prepared)
        metrics_to_write[name] = prepared
        if name in existing_metrics:
            result["metrics"]["updated"] += 1
        else:
            result["metrics"]["imported"] += 1

    for name, existing in existing_metrics.items():
        if name in incoming_metrics:
            continue
        if existing.get("_origin") != "metricly":
            metrics_to_delete.append(name)

    result["semantic_models"]["deleted"] = len(models_to_delete)
    result["metrics"]["deleted"] = len(metrics_to_delete)

    # ---- 5. Build effective post-replace state ----
    # Effective = (items being written, i.e. imported) +
    #             (existing metricly-origin items not being deleted)
    effective_models: list[dict] = list(models_to_write.values())
    for name, existing in existing_models.items():
        if existing.get("_origin") == "metricly" and name not in models_to_write:
            effective_models.append(existing)

    effective_metrics: list[dict] = list(metrics_to_write.values())
    for name, existing in existing_metrics.items():
        if existing.get("_origin") == "metricly" and name not in metrics_to_write:
            effective_metrics.append(existing)

    # Validate the effective manifest's cross-references
    effective_measures = _collect_measure_names(effective_models)
    effective_metric_names = {m.get("name") for m in effective_metrics if m.get("name")}

    post_errors: list[str] = []
    for metric in effective_metrics:
        # Only re-validate items we're actually keeping or writing — this catches
        # both newly-imported items and metricly-origin items whose dependencies
        # may have just been removed.
        post_errors.extend(_validate_metric_references(metric, effective_measures, effective_metric_names))

    # Validate quick metrics against the post-replace metric set
    quick_metrics = _list_quick_metric_expressions(db, org_id)
    post_errors.extend(_validate_quick_metric_refs(quick_metrics, effective_metric_names))

    if post_errors:
        raise ValueError(
            "Manifest upload would leave the org in an inconsistent state. "
            "Fix the upload (or remove the dependent user-defined items) and retry:\n  - "
            + "\n  - ".join(post_errors)
        )

    # ---- 6. Apply atomically (Firestore batched writes) ----
    org_doc = db.collection("organizations").document(org_id)
    models_coll = org_doc.collection("semantic_models")
    metrics_coll = org_doc.collection("metrics")

    _commit_replace(
        db,
        writes=[
            (models_coll.document(name), data) for name, data in models_to_write.items()
        ] + [
            (metrics_coll.document(name), data) for name, data in metrics_to_write.items()
        ],
        deletes=[models_coll.document(name) for name in models_to_delete]
              + [metrics_coll.document(name) for name in metrics_to_delete],
    )

    # Store project_configuration if present (separate doc, not part of replace).
    project_config = manifest.get("project_configuration")
    if project_config:
        config_ref = org_doc.collection("config").document("project_configuration")
        config_ref.set({
            "data": project_config,
            "_imported_at": now,
        })

    # Backward-compat shape: `orphaned` lists items that were deleted.
    result["orphaned"] = {
        "semantic_models": list(models_to_delete),
        "metrics": list(metrics_to_delete),
    }

    return result


def _commit_replace(db, writes: list, deletes: list) -> None:
    """Apply writes and deletes atomically using Firestore batched writes.

    Falls back to per-doc ops if the client doesn't expose `batch()` (e.g. in
    test fakes that don't model batching). Firestore batches are limited to
    500 ops; we chunk to stay under the limit.
    """
    BATCH_LIMIT = 450  # leave headroom under Firestore's 500-op cap

    if not hasattr(db, "batch"):
        # Test/in-memory fallback: best-effort sequential ops.
        for ref, data in writes:
            ref.set(data)
        for ref in deletes:
            ref.delete()
        return

    ops: list = []
    for ref, data in writes:
        ops.append(("set", ref, data))
    for ref in deletes:
        ops.append(("delete", ref, None))

    for i in range(0, len(ops), BATCH_LIMIT):
        batch = db.batch()
        for op, ref, data in ops[i:i + BATCH_LIMIT]:
            if op == "set":
                batch.set(ref, data)
            else:
                batch.delete(ref)
        batch.commit()


def generate_manifest(org_id: str) -> dict:
    """Generate a semantic manifest from Firestore data.

    This creates a manifest that can be used by MetricFlow.
    Provenance fields (starting with _) are stripped.
    Aggregation type aliases are normalized (e.g., 'avg' -> 'average').

    Args:
        org_id: Organization ID

    Returns:
        Semantic manifest dict ready for MetricFlow
    """
    db = get_firestore_client()

    # Normalize aggregation types to MetricFlow's expected values
    # MetricFlow accepts: sum, min, max, count_distinct, sum_boolean, average, percentile, median, count
    agg_type_aliases = {"avg": "average", "mean": "average"}

    def normalize_measure(measure: dict) -> dict:
        """Normalize measure aggregation types."""
        result = dict(measure)
        if "agg" in result:
            agg_lower = result["agg"].lower()
            result["agg"] = agg_type_aliases.get(agg_lower, agg_lower)
        return result

    semantic_models = []
    for model in list_semantic_models(org_id):
        # Strip provenance fields
        clean_model = {k: v for k, v in model.items() if not k.startswith("_")}
        # Normalize measure aggregation types
        if "measures" in clean_model:
            clean_model["measures"] = [normalize_measure(m) for m in clean_model["measures"]]
        semantic_models.append(clean_model)

    metrics = []
    for metric in list_metrics(org_id):
        # Strip provenance fields
        clean_metric = {k: v for k, v in metric.items() if not k.startswith("_")}
        metrics.append(clean_metric)

    result = {
        "semantic_models": semantic_models,
        "metrics": metrics,
    }

    # Include project_configuration (required by MetricFlow)
    config_ref = db.collection("organizations").document(org_id).collection("config").document("project_configuration")
    config_doc = config_ref.get()
    if config_doc.exists:
        config_data = config_doc.to_dict()
        if config_data and "data" in config_data:
            result["project_configuration"] = config_data["data"]

    # Ensure project_configuration exists with at least time_spines (required by MetricFlow)
    if "project_configuration" not in result:
        result["project_configuration"] = {
            "time_spines": []
        }

    return result


# -----------------------------------------------------------------------------
# Version History
# -----------------------------------------------------------------------------

def add_history_entry(
    org_id: str,
    collection_type: str,  # "semantic_models" or "metrics"
    item_name: str,
    action: str,  # "created", "updated", "deleted"
    user_id: str,
    user_email: str,
    changes: dict,
) -> None:
    """Add a history entry for a semantic model or metric change.

    Args:
        org_id: Organization ID
        collection_type: "semantic_models" or "metrics"
        item_name: Name of the item
        action: "created", "updated", or "deleted"
        user_id: User who made the change
        user_email: Email of the user
        changes: Dict of {field: {old, new}} for updates
    """
    db = get_firestore_client()
    now = datetime.now(UTC).isoformat() + "Z"

    history_ref = (
        db.collection("organizations")
        .document(org_id)
        .collection(collection_type)
        .document(item_name)
        .collection("history")
    )

    history_ref.add({
        "user_id": user_id,
        "user_email": user_email,
        "action": action,
        "changes": changes,
        "timestamp": now,
    })


def get_history(
    org_id: str,
    collection_type: str,  # "semantic_models" or "metrics"
    item_name: str,
    limit: int = 50,
) -> list[dict]:
    """Get history entries for a semantic model or metric.

    Args:
        org_id: Organization ID
        collection_type: "semantic_models" or "metrics"
        item_name: Name of the item
        limit: Maximum number of entries to return

    Returns:
        List of history entries, oldest first
    """
    db = get_firestore_client()

    history_ref = (
        db.collection("organizations")
        .document(org_id)
        .collection(collection_type)
        .document(item_name)
        .collection("history")
    )

    entries = []
    for doc in history_ref.order_by("timestamp").stream():
        entries.append(doc.to_dict())

    return entries[:limit]


def compute_changes(old_data: dict, new_data: dict) -> dict:
    """Compute the changes between two versions of an item.

    Args:
        old_data: Previous version
        new_data: New version

    Returns:
        Dict of {field: {old, new}} for changed fields
    """
    changes = {}

    # Get all keys from both dicts, excluding provenance fields
    all_keys = set(k for k in old_data.keys() if not k.startswith("_"))
    all_keys.update(k for k in new_data.keys() if not k.startswith("_"))

    for key in all_keys:
        old_val = old_data.get(key)
        new_val = new_data.get(key)

        if old_val != new_val:
            changes[key] = {"old": old_val, "new": new_val}

    return changes


def _collect_measure_names(semantic_models: list[dict]) -> set[str]:
    """Collect all measure names from a list of semantic models."""
    names: set[str] = set()
    for model in semantic_models:
        for measure in model.get("measures", []):
            mname = measure.get("name")
            if mname:
                names.add(mname)
    return names


def _validate_metric_references(
    metric: dict,
    available_measures: set[str],
    available_metrics: set[str],
) -> list[str]:
    """Check that a metric's references resolve.

    Returns a list of human-readable error strings (empty if valid).
    Handles simple, ratio, derived, cumulative, and conversion metric types.
    """
    errors: list[str] = []
    metric_name = metric.get("name", "<unnamed>")
    metric_type = metric.get("type")
    type_params = metric.get("type_params", {}) or {}

    def measure_name_from(ref) -> Optional[str]:
        if isinstance(ref, dict):
            return ref.get("name")
        if isinstance(ref, str):
            return ref
        return None

    if metric_type == "simple":
        name = measure_name_from(type_params.get("measure"))
        if name and name not in available_measures:
            errors.append(
                f"Metric '{metric_name}' (simple) references undefined measure '{name}'"
            )

    elif metric_type == "ratio":
        for field_name in ("numerator", "denominator"):
            name = measure_name_from(type_params.get(field_name))
            if name and name not in available_measures:
                errors.append(
                    f"Metric '{metric_name}' (ratio) {field_name} references undefined measure '{name}'"
                )

    elif metric_type == "cumulative":
        name = measure_name_from(type_params.get("measure"))
        if name and name not in available_measures:
            errors.append(
                f"Metric '{metric_name}' (cumulative) references undefined measure '{name}'"
            )

    elif metric_type == "derived":
        for ref in type_params.get("metrics", []) or []:
            ref_name = ref.get("name") if isinstance(ref, dict) else ref
            if ref_name and ref_name not in available_metrics:
                errors.append(
                    f"Metric '{metric_name}' (derived) references undefined metric '{ref_name}'"
                )

    elif metric_type == "conversion":
        ctp = type_params.get("conversion_type_params", {}) or {}
        for field_name in ("base_measure", "conversion_measure"):
            name = measure_name_from(ctp.get(field_name))
            if name and name not in available_measures:
                errors.append(
                    f"Metric '{metric_name}' (conversion) {field_name} references undefined measure '{name}'"
                )

    return errors


def validate_manifest(manifest: dict) -> dict:
    """Validate a semantic manifest's structural and reference integrity.

    Performs two levels of validation:
    1. Schema validation (required fields, types)
    2. Semantic validation (references, consistency) for all metric types:
       simple, ratio, derived, cumulative, conversion

    Args:
        manifest: Semantic manifest dict

    Returns:
        {
            "valid": bool,
            "errors": list[str],
            "warnings": list[str]
        }
    """
    errors = []
    warnings = []

    semantic_models = manifest.get("semantic_models", [])
    metrics = manifest.get("metrics", [])

    # MetricFlow valid aggregation types
    valid_agg_types = {"sum", "count", "count_distinct", "average", "min", "max", "sum_boolean", "median", "percentile"}
    # Common aliases that should be accepted during validation
    agg_type_aliases = {"avg": "average", "mean": "average"}

    # Validate semantic models
    for i, model in enumerate(semantic_models):
        model_name = model.get("name")

        # Check required name field
        if not model_name:
            errors.append(f"Semantic model at index {i} is missing required 'name' field")
            continue

        # Validate measures
        for measure in model.get("measures", []):
            measure_name = measure.get("name")
            if not measure_name:
                errors.append(f"Measure in model '{model_name}' is missing required 'name' field")
                continue

            # Validate aggregation type (normalize aliases)
            agg = measure.get("agg")
            if agg:
                agg_lower = agg.lower()
                # Normalize common aliases
                agg_normalized = agg_type_aliases.get(agg_lower, agg_lower)
                if agg_normalized not in valid_agg_types:
                    errors.append(f"Measure '{measure_name}' in model '{model_name}' has invalid aggregation type '{agg}'")

        # Validate dimensions
        for dim in model.get("dimensions", []):
            dim_name = dim.get("name")
            if not dim_name:
                errors.append(f"Dimension in model '{model_name}' is missing required 'name' field")

    # Build reference sets for cross-checks
    all_measures = _collect_measure_names(semantic_models)
    all_metric_names = {m.get("name") for m in metrics if m.get("name")}

    # Validate metrics
    for i, metric in enumerate(metrics):
        metric_name = metric.get("name")

        # Check required name field
        if not metric_name:
            errors.append(f"Metric at index {i} is missing required 'name' field")
            continue

        # Validate type
        metric_type = metric.get("type")
        if metric_type and metric_type not in {"simple", "ratio", "derived", "cumulative", "conversion"}:
            errors.append(f"Metric '{metric_name}' has invalid type '{metric_type}'")
            continue

        # Validate references for the declared type
        errors.extend(_validate_metric_references(metric, all_measures, all_metric_names))

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }


# -----------------------------------------------------------------------------
# Export to dbt YAML
# -----------------------------------------------------------------------------

def _yaml_representer_str(dumper, data: str):
    """Custom YAML representer for multi-line strings."""
    if "\n" in data:
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


def _clean_for_yaml(data: dict) -> dict:
    """Clean data for YAML export by removing provenance fields and nulls."""
    result = {}
    for key, value in data.items():
        # Skip provenance fields
        if key.startswith("_"):
            continue
        # Skip None values
        if value is None:
            continue
        # Recursively clean nested dicts
        if isinstance(value, dict):
            cleaned = _clean_for_yaml(value)
            if cleaned:  # Only include non-empty dicts
                result[key] = cleaned
        # Recursively clean lists
        elif isinstance(value, list):
            cleaned_list = []
            for item in value:
                if isinstance(item, dict):
                    cleaned_item = _clean_for_yaml(item)
                    if cleaned_item:
                        cleaned_list.append(cleaned_item)
                elif item is not None:
                    cleaned_list.append(item)
            if cleaned_list:
                result[key] = cleaned_list
        else:
            result[key] = value
    return result


def export_to_yaml(org_id: str) -> dict[str, str]:
    """Export semantic layer to dbt-compatible YAML files.

    Generates two YAML files:
    - semantic_models.yml: All semantic models
    - metrics.yml: All metrics

    Args:
        org_id: Organization ID

    Returns:
        Dict of {filename: yaml_content}
    """
    import yaml

    # Register custom string representer for multi-line strings
    yaml.add_representer(str, _yaml_representer_str)

    files = {}

    # Export semantic models
    models = list_semantic_models(org_id)
    if models:
        clean_models = [_clean_for_yaml(m) for m in models]
        models_yaml = yaml.dump(
            {"semantic_models": clean_models},
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
            width=120,
        )
        files["semantic_models.yml"] = models_yaml

    # Export metrics
    metrics = list_metrics(org_id)
    if metrics:
        clean_metrics = [_clean_for_yaml(m) for m in metrics]
        metrics_yaml = yaml.dump(
            {"metrics": clean_metrics},
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
            width=120,
        )
        files["metrics.yml"] = metrics_yaml

    return files


def export_to_zip(org_id: str) -> bytes:
    """Export semantic layer to a ZIP file containing dbt-compatible YAML.

    Args:
        org_id: Organization ID

    Returns:
        ZIP file as bytes
    """
    import io
    import zipfile

    files = export_to_yaml(org_id)

    # Create in-memory ZIP file
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for filename, content in files.items():
            zf.writestr(filename, content)

    return zip_buffer.getvalue()


# =============================================================================
# Waitlist
# =============================================================================

def add_to_waitlist(email: str, source: str = "website") -> dict:
    """Add an email to the waitlist.

    Args:
        email: Email address to add
        source: Where the signup came from (default: "website")

    Returns:
        Waitlist entry dict

    Raises:
        ValueError: If email is already on the waitlist
    """
    db = get_firestore_client()
    now = datetime.now(UTC).isoformat() + "Z"

    # Check if email already exists
    waitlist_ref = db.collection("waitlist")
    existing = waitlist_ref.where(filter=FieldFilter("email", "==", email.lower())).limit(1).get()

    if len(list(existing)) > 0:
        raise ValueError("Email already on waitlist")

    # Add to waitlist
    doc_ref = waitlist_ref.document()
    entry = {
        "email": email.lower(),
        "source": source,
        "created_at": now,
    }
    doc_ref.set(entry)
    entry["id"] = doc_ref.id

    return entry


# =============================================================================
# Error Reports (top-level collection for cross-org visibility)
# =============================================================================

def create_error_report(report: dict) -> dict:
    """Create an error report in Firestore.

    Stored in top-level error_reports collection (not org-scoped)
    so developers can query all reports across orgs.
    """
    db = get_firestore_client()
    doc_ref = db.collection("error_reports").document()
    report["id"] = doc_ref.id
    doc_ref.set(report)
    return report
