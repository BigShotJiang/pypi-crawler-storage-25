"""MCP Apps (UI extension) wiring for Metricly.

FastMCP 3.x ships the MCP Apps extension. A tool participates by:

1. Being decorated with ``@mcp.tool(app=AppConfig(resource_uri="ui://…", csp=...))``
   which stamps ``_meta.ui`` on the tool definition.
2. Pairing with a ``@mcp.resource("ui://…")`` that returns the HTML shell.
3. Returning a tool result whose ``structuredContent`` is the data the HTML
   consumes (read via ``AppBridge.onToolResult`` in the iframe).

Embed auth
----------
Authentication for the iframe reuses the **existing** Firestore-backed
render tokens from ``services.render``. Tokens are short-lived (5 min TTL,
cross-process: MCP mints, backend validates) and are **replayable within
their TTL** — ``validate_render_token`` only marks ``validated=True``, it
doesn't consume the doc. Treat the ``embed_url`` as a bearer credential
for the lifetime of the token. **Do not confuse with**
``settings.mcp_jwt_signing_key`` — that key signs OAuth access tokens
for Claude.ai sessions (commit 1b30d86) and is independent of the
embed path.

Host compatibility
------------------
``client_supports_extension`` was planned for FastMCP 3.2 but is not wired
up; non-Apps hosts simply ignore the ``_meta.ui`` block and see the tool's
JSON ``structuredContent`` directly (which still contains a human-readable
``embed_url``). For PDF/PNG export, callers pass ``format="pdf"`` or
``format="png"`` explicitly.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from fastmcp import FastMCP
from fastmcp.apps import UI_EXTENSION_ID, UI_MIME_TYPE, AppConfig, ResourceCSP

import services.dashboards as dashboard_service
from services.auth import UserContext
from services.render import create_render_token
from settings import get_settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Default token lifetime for embed sessions. Each tool call produces a fresh
#: token; the iframe validates it once on load.
EMBED_TOKEN_TTL_SECONDS = 300

#: Canonical ui:// URI for the embed HTML shell. Both render_dashboard and
#: render_widget reference this same resource — it reads the embed URL from
#: the tool's structuredContent and loads an inner iframe.
EMBED_APP_URI = "ui://metricly/embed.html"

#: npm esm CDN used to load the MCP Apps AppBridge client-side SDK.
#: TODO(follow-up): vendor @modelcontextprotocol/ext-apps into our dashboard
#: bundle so the HTML shell doesn't depend on an external CDN at render time.
_APP_BRIDGE_CDN_ORIGIN = "https://esm.sh"


# ---------------------------------------------------------------------------
# Frontend origin resolution
# ---------------------------------------------------------------------------


def _frontend_origin() -> str:
    settings = get_settings()
    return settings.metricly_frontend_base_url.rstrip("/")


def _frontend_host_entry() -> str:
    """Return the scheme://host[:port] form used by CSP directives."""
    parsed = urlparse(_frontend_origin())
    host = parsed.hostname or "metricly.xyz"
    if parsed.port:
        return f"{parsed.scheme}://{host}:{parsed.port}"
    return f"{parsed.scheme}://{host}"


# ---------------------------------------------------------------------------
# AppConfig factories
# ---------------------------------------------------------------------------


def build_embed_app_config() -> AppConfig:
    """AppConfig shared by render_dashboard and render_widget.

    The CSP whitelists:
    - ``frame_domains`` for the inner iframe that loads the Metricly SPA
    - ``resource_domains`` + ``connect_domains`` for the AppBridge CDN
      (needed by the HTML shell to import the SDK)
    """
    frontend = _frontend_host_entry()
    return AppConfig(
        resource_uri=EMBED_APP_URI,
        visibility=["model", "app"],
        csp=ResourceCSP(
            resource_domains=[_APP_BRIDGE_CDN_ORIGIN],
            connect_domains=[_APP_BRIDGE_CDN_ORIGIN, frontend],
            frame_domains=[frontend],
        ),
    )


# ---------------------------------------------------------------------------
# HTML shell
# ---------------------------------------------------------------------------


#: Built single-file MCP App bundle from apps/dashboard/dist/mcp-app/mcp-app.html.
#: Produced by ``pnpm --filter @metricly/dashboard build:mcp-app`` and copied
#: into ``backend/mcp_app_assets/mcp-app.html`` by the predeploy/Docker build
#: so the bundle ships with the backend container.
_EMBED_APP_PATH = Path(__file__).parent / "mcp_app_assets" / "mcp-app.html"

#: Fallback emitted while the bundle is missing (local dev without a build).
#: Visibly explains the situation rather than silently rendering blank.
_EMBED_APP_FALLBACK_HTML = """\
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Metricly — bundle missing</title>
  <style>
    body { margin: 0; padding: 24px; font: 14px -apple-system, BlinkMacSystemFont, sans-serif; color: #333; }
    code { background: #f1f1f1; padding: 2px 6px; border-radius: 4px; }
  </style>
</head>
<body>
  <h2>Metricly MCP App bundle not built</h2>
  <p>Run <code>pnpm --filter @metricly/dashboard build:mcp-app</code>
  and ensure <code>backend/mcp_app_assets/mcp-app.html</code> is present.</p>
</body>
</html>
"""


def load_embed_app_html() -> str:
    """Read the built MCP App single-file bundle (or the fallback)."""
    if _EMBED_APP_PATH.is_file():
        return _EMBED_APP_PATH.read_text(encoding="utf-8")
    logger.warning(
        "MCP App bundle not found at %s — serving fallback page. "
        "Build with `pnpm --filter @metricly/dashboard build:mcp-app`.",
        _EMBED_APP_PATH,
    )
    return _EMBED_APP_FALLBACK_HTML


# ---------------------------------------------------------------------------
# Apps payload builders
# ---------------------------------------------------------------------------


def _build_embed_response(
    user: UserContext,
    resource_type: str,
    resource_id: str,
    path_segment: str,
) -> dict[str, Any]:
    """Shared builder: mint a token, form the embed URL, shape the payload.

    The returned dict becomes the tool's ``structuredContent``. The ``ui://``
    HTML shell reads ``embed_url`` and loads it into an iframe. Hosts without
    UI-extension support see a plain JSON dict containing ``embed_url`` —
    still machine-readable, just not iframed.
    """
    token = create_render_token(
        org_id=user.org_id,
        resource_type=resource_type,  # type: ignore[arg-type]
        resource_id=resource_id,
        ttl_seconds=EMBED_TOKEN_TTL_SECONDS,
    )
    embed_url = f"{_frontend_origin()}/embed/{path_segment}?token={token}"
    return {
        "success": True,
        "format": "app",
        "embed_url": embed_url,
        "resource_uri": EMBED_APP_URI,
        "mime_type": UI_MIME_TYPE,
        f"{resource_type}_id": resource_id,
        "expires_in_seconds": EMBED_TOKEN_TTL_SECONDS,
    }


async def build_dashboard_app_response(
    user: UserContext, dashboard_id: str
) -> dict[str, Any]:
    """Apps-mode payload for rendering a dashboard in an iframe.

    Embeds the resolved dashboard config inline in ``structuredContent``
    so the sandboxed iframe doesn't need to call back to the API for
    dashboard metadata. Claude Desktop's iframe sandbox blocks direct
    ``fetch`` to ``metricly.xyz/api/...`` regardless of declared
    ``connect_domains`` (same class as the ``frame-src`` issue #40),
    so any data the iframe needs at boot time has to ride here.

    Per-widget data is still fetched at render time and is a separate
    iteration — those calls will currently fail in the iframe and the
    widgets will show error states.
    """
    dashboard = await dashboard_service.get_dashboard(user, dashboard_id)
    payload = _build_embed_response(
        user=user,
        resource_type="dashboard",
        resource_id=dashboard_id,
        path_segment=f"dashboard/{dashboard_id}",
    )
    payload["dashboard"] = dashboard.model_dump()
    return payload


async def build_widget_app_response(
    user: UserContext, dashboard_id: str, widget_id: str
) -> dict[str, Any]:
    """Apps-mode payload for rendering a single widget in an iframe.

    The render token's ``resource_id`` is the compound ``{dashboard_id}/{widget_id}``
    key, matching the pre-existing PNG-render convention (see
    ``services.render.render_widget``) and the frontend's compound
    ``resourceId`` in ``EmbedWidgetPage`` → ``useRenderToken``. Strict equality
    in ``validate_render_token`` means the bare ``widget_id`` would 401 every
    embed.

    Embeds the parent dashboard config inline so the iframe can locate the
    widget definition + reuse the parent's controls (date range, grain) for
    query resolution. Symmetry with ``build_dashboard_app_response``.
    """
    dashboard = await dashboard_service.get_dashboard(user, dashboard_id)
    compound_resource_id = f"{dashboard_id}/{widget_id}"
    payload = _build_embed_response(
        user=user,
        resource_type="widget",
        resource_id=compound_resource_id,
        path_segment=f"widget/{dashboard_id}/{widget_id}",
    )
    # Surface both IDs for the host/LLM without burying the widget-only ID
    # under the compound key.
    payload["widget_id"] = widget_id
    payload["dashboard_id"] = dashboard_id
    payload["dashboard"] = dashboard.model_dump()
    return payload


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_embed_resource(mcp: FastMCP) -> None:
    """Register ``ui://metricly/embed.html`` as the shared Apps HTML shell.

    FastMCP auto-resolves the MIME type to ``text/html;profile=mcp-app`` for
    any ``ui://`` resource — no explicit mime_type needed.
    """

    @mcp.resource(EMBED_APP_URI)
    def embed_app_html() -> str:
        return load_embed_app_html()
