"""MCP Resources — read-only, URI-addressable views over Metricly data.

Resources are the right primitive for list/get/show operations: they don't
count against the tool quota and hosts can browse them independently of
tool calls. This module registers the Metricly resource surface.

Context lookup
--------------
Resource handlers get the authenticated ``UserContext`` via the same
``OrgContextMiddleware`` + ``set_stdio_user`` paths as tool handlers.
The middleware hooks ``on_read_resource`` in addition to ``on_call_tool``.
"""

from __future__ import annotations

import logging

from fastmcp import Context, FastMCP
from fastmcp.exceptions import ResourceError
from fastmcp.server.dependencies import CurrentContext

import services.context as context_service
import services.dashboards as dashboard_service
import services.knowledge as knowledge_service
import services.manifest as manifest_service
import services.queries as query_service
import services.quick_metrics as quick_metrics_service
import services.schedules as schedule_service
from services.auth import UserContext, get_user_orgs
from settings import get_settings

logger = logging.getLogger(__name__)


def augment_orgs_with_pin_state(
    orgs: list[dict], active_org_id: str, org_pinned: bool
) -> list[dict]:
    """Annotate org-list entries with ``current`` / ``pinned`` flags.

    Pure transform — split out from the ``metricly://organizations``
    resource handler so unit tests don't need to reach into the nested
    ``register_resources`` closure. ``current`` reflects the request-level
    active org (which may be a ``?org=<id>`` pin, not the user's stored
    ``defaultOrgId``); ``pinned`` is true only on the currently-active org
    and only when the connection carries a URL pin.
    """
    for org in orgs:
        org["current"] = org["id"] == active_org_id
        org["pinned"] = org_pinned and org["current"]
    return orgs


async def _user_from_resource_context(ctx: Context) -> UserContext:
    """Resolve the authenticated user for a resource read.

    Mirrors ``get_user_from_context`` from ``mcp_server`` but raises
    ``ResourceError`` so the client sees a resource-scoped failure.
    """
    user_data = await ctx.get_state("user")
    if user_data is None:
        raise ResourceError("Authentication required: no user context")
    if isinstance(user_data, dict):
        return UserContext(**user_data)
    return user_data


def register_resources(mcp: FastMCP) -> None:
    """Register the Metricly resource surface on the FastMCP instance."""

    @mcp.resource("metricly://organizations")
    async def organizations_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All organizations the current user belongs to.

        Each entry carries ``id``, ``name``, ``role``, ``current`` (bool —
        is this the active org for this connection?), and ``pinned`` (bool —
        true when the active org was pinned via ``?org=`` on the MCP URL).
        When ``pinned`` is true, ``switch_organization`` is disabled for
        this connection; the user must configure a separate MCP URL for
        other orgs.
        """
        user = await _user_from_resource_context(ctx)
        org_pinned = bool(await ctx.get_state("org_pinned"))
        orgs = get_user_orgs(user.email)
        return augment_orgs_with_pin_state(orgs, user.org_id, org_pinned)

    @mcp.resource("metricly://dashboards")
    async def dashboards_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """Dashboards accessible to the user, flattened with a visibility field."""
        user = await _user_from_resource_context(ctx)
        result = await dashboard_service.list_dashboards(user)
        out: list[dict] = []
        for d in result.personal:
            out.append(
                {
                    "id": d.id,
                    "title": d.title,
                    "description": d.description,
                    "visibility": "private",
                    "owner": d.owner,
                }
            )
        for d in result.team:
            out.append(
                {
                    "id": d.id,
                    "title": d.title,
                    "description": d.description,
                    "visibility": "org",
                    "owner": d.owner,
                }
            )
        return out

    @mcp.resource("metricly://dashboards/{dashboard_id}")
    async def dashboard_resource(
        dashboard_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Full dashboard configuration (pages, sections, widgets)."""
        user = await _user_from_resource_context(ctx)
        try:
            dashboard = await dashboard_service.get_dashboard(user, dashboard_id)
        except ValueError as e:
            raise ResourceError(str(e))
        return dashboard.model_dump()

    @mcp.resource("metricly://metrics")
    async def metrics_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All metrics available in the org (names, types, descriptions, definitions)."""
        user = await _user_from_resource_context(ctx)
        try:
            return await query_service.list_metrics(user.org_id)
        except ValueError as e:
            raise ResourceError(str(e))

    @mcp.resource("metricly://dimensions")
    async def dimensions_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All dimensions available for grouping (qualified names like customer__region)."""
        user = await _user_from_resource_context(ctx)
        try:
            return await query_service.list_dimensions(user.org_id)
        except ValueError as e:
            raise ResourceError(str(e))

    @mcp.resource("metricly://metrics/{metric_name}")
    async def metric_explain_resource(
        metric_name: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Calculation details for a single metric (type, formula, measures)."""
        user = await _user_from_resource_context(ctx)
        try:
            return await query_service.explain_metric(user.org_id, metric_name)
        except ValueError as e:
            raise ResourceError(str(e))

    @mcp.resource("metricly://knowledge")
    async def knowledge_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All shared org knowledge items."""
        user = await _user_from_resource_context(ctx)
        items = await knowledge_service.list_knowledge_items(
            user, knowledge_service.KnowledgeListFilters(limit=100)
        )
        return [item.model_dump(exclude_none=True) for item in items]

    @mcp.resource("metricly://knowledge{?status,item_type,subject,limit}")
    async def knowledge_filtered_resource(
        status: str | None = None,
        item_type: str | None = None,
        subject: str | None = None,
        limit: int = 50,
        ctx: Context = CurrentContext(),
    ) -> list[dict]:
        """Shared org knowledge filtered by status, type, subject, and/or limit."""
        user = await _user_from_resource_context(ctx)
        try:
            filters = knowledge_service.KnowledgeListFilters(
                status=status or None,  # type: ignore[arg-type]
                type=item_type or None,  # type: ignore[arg-type]
                subject=subject or None,
                limit=limit,
            )
        except ValueError as e:
            raise ResourceError(str(e))

        items = await knowledge_service.list_knowledge_items(user, filters)
        return [item.model_dump(exclude_none=True) for item in items]

    @mcp.resource("metricly://knowledge/{item_id}")
    async def knowledge_item_resource(
        item_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """A single knowledge item."""
        user = await _user_from_resource_context(ctx)
        try:
            item = await knowledge_service.get_knowledge_item(user, item_id)
        except ValueError as e:
            raise ResourceError(str(e))
        return item.model_dump(exclude_none=True)

    @mcp.resource("metricly://context")
    async def context_resource(ctx: Context = CurrentContext()) -> dict:
        """User's accumulated context (preferences, favorites). Persists across sessions."""
        user = await _user_from_resource_context(ctx)
        prefs = await context_service.get_user_preferences(user.uid)
        return {
            "default_currency": prefs.default_currency,
            "default_grain": prefs.default_grain,
            "decimal_places": prefs.decimal_places,
            "preferred_chart_type": prefs.preferred_chart_type,
            "favorite_metrics": prefs.favorite_metrics,
            "updated_at": prefs.updated_at,
        }

    @mcp.resource("metricly://manifest/status")
    async def manifest_status_resource(ctx: Context = CurrentContext()) -> dict:
        """Semantic manifest metadata (metric/model/dimension counts, last updated)."""
        user = await _user_from_resource_context(ctx)
        status = await manifest_service.get_manifest_status(user)
        return {
            "org_id": status.org_id,
            "project_name": status.project_name,
            "metric_count": status.metric_count,
            "model_count": status.model_count,
            "dimension_count": status.dimension_count,
            "last_updated": status.last_updated,
        }

    @mcp.resource("metricly://manifest/models")
    async def manifest_models_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All semantic models (names, descriptions, measures, dimensions)."""
        user = await _user_from_resource_context(ctx)
        return await manifest_service.list_semantic_models(user)

    @mcp.resource("metricly://manifest/models/{name}")
    async def manifest_model_resource(
        name: str, ctx: Context = CurrentContext()
    ) -> dict:
        """A single semantic model."""
        user = await _user_from_resource_context(ctx)
        try:
            return await manifest_service.get_semantic_model(user, name)
        except ValueError as e:
            raise ResourceError(str(e))

    @mcp.resource("metricly://manifest/export")
    async def manifest_export_resource(ctx: Context = CurrentContext()) -> dict:
        """Full manifest export (metrics + semantic models + project config)."""
        user = await _user_from_resource_context(ctx)
        return await manifest_service.export_manifest(user)

    @mcp.resource("metricly://quick_metrics")
    async def quick_metrics_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All user-defined derived metrics (expressions over existing metrics)."""
        user = await _user_from_resource_context(ctx)
        metrics = await quick_metrics_service.list_quick_metrics(user)
        return [
            {
                "id": m.id,
                "name": m.name,
                "description": m.description,
                "expression": m.expression,
                "query_name": f"qm:{m.name}",
            }
            for m in metrics
        ]

    @mcp.resource("metricly://quick_metrics/{metric_id}")
    async def quick_metric_resource(
        metric_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """A single quick metric's full definition."""
        user = await _user_from_resource_context(ctx)
        try:
            metric = await quick_metrics_service.get_quick_metric(user, metric_id)
        except ValueError as e:
            raise ResourceError(str(e))
        return {
            "id": metric.id,
            "name": metric.name,
            "description": metric.description,
            "expression": metric.expression,
            "base_metrics": metric.base_metrics,
            "query_name": f"qm:{metric.name}",
            "created_by": metric.created_by,
            "created_at": metric.created_at.isoformat(),
            "updated_at": metric.updated_at.isoformat(),
        }

    @mcp.resource("metricly://reports")
    async def reports_resource(ctx: Context = CurrentContext()) -> list[dict]:
        """All scheduled reports in the org (summary view)."""
        if not get_settings().schedules_enabled:
            raise ResourceError(
                "Scheduled reports coming soon. This feature is not yet enabled."
            )
        user = await _user_from_resource_context(ctx)
        summaries = await schedule_service.list_schedules(user)
        return [
            {
                "id": s.id,
                "name": s.name,
                "frequency_type": s.frequency_type,
                "frequency_time": s.frequency_time,
                "report_type": s.report_type,
                "enabled": s.enabled,
                "recipients_count": s.recipients_count,
                "last_run_at": s.last_run_at.isoformat() if s.last_run_at else None,
                "last_run_status": s.last_run_status,
            }
            for s in summaries
        ]

    @mcp.resource("metricly://reports/{schedule_id}")
    async def report_resource(
        schedule_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """A single scheduled report (full config + run metadata)."""
        if not get_settings().schedules_enabled:
            raise ResourceError(
                "Scheduled reports coming soon. This feature is not yet enabled."
            )
        user = await _user_from_resource_context(ctx)
        try:
            schedule = await schedule_service.get_schedule(user, schedule_id)
        except ValueError as e:
            raise ResourceError(str(e))
        return {
            "id": schedule.id,
            "name": schedule.name,
            "frequency": schedule.frequency.model_dump(),
            "report": schedule.report.model_dump(),
            "report_type": (
                "dashboard"
                if isinstance(schedule.report, schedule_service.DashboardReport)
                else "query"
            ),
            "recipients": schedule.recipients,
            "enabled": schedule.enabled,
            "created_by": schedule.created_by,
            "created_at": schedule.created_at.isoformat(),
            "updated_at": schedule.updated_at.isoformat(),
            "last_run_at": (
                schedule.last_run_at.isoformat() if schedule.last_run_at else None
            ),
            "last_run_status": schedule.last_run_status,
        }
