"""MCP dispatch tools — one tool per domain with a discriminated action union.

Consolidates families of CRUD tools (e.g. create_dashboard, update_dashboard,
delete_dashboard, ...) into a single ``<domain>_edit`` tool whose input is a
Pydantic discriminated-union over the action types. Keeps the LLM's tool
surface small while preserving every operation.

The dispatch body is a flat ``match`` that routes to the existing services
layer — no business logic lives here.
"""

from __future__ import annotations

import logging
from typing import Annotated, Literal

from fastmcp import Context, FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import CurrentContext
from pydantic import BaseModel, Field

import services.dashboards as dashboard_service
import services.knowledge as knowledge_service
import services.manifest as manifest_service
import services.quick_metrics as quick_metrics_service
import services.schedules as schedule_service
from services.auth import UserContext
from settings import get_settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Dashboard action types
# ---------------------------------------------------------------------------


class CreateDashboardAction(BaseModel):
    """Create a new dashboard."""

    action: Literal["create"]
    title: str = Field(description="Dashboard title")
    description: str | None = Field(default=None, description="Optional description")
    visibility: Literal["private", "org"] = Field(
        default="private",
        description='"private" (only you) or "org" (shared with organization)',
    )


class UpdateDashboardAction(BaseModel):
    """Update an existing dashboard's metadata (title/description/visibility)."""

    action: Literal["update"]
    id: str = Field(description="Dashboard ID")
    title: str | None = None
    description: str | None = None
    visibility: Literal["private", "org"] | None = None
    expected_version: int | None = Field(
        default=None,
        description="Optimistic lock — if provided, update fails on mismatch. "
        "Use the version from get_dashboard to prevent overwriting concurrent changes.",
    )


class DeleteDashboardAction(BaseModel):
    """Delete a dashboard. Cannot be undone."""

    action: Literal["delete"]
    id: str = Field(description="Dashboard ID")


class DuplicateDashboardAction(BaseModel):
    """Duplicate a dashboard with all pages, sections, and widgets (new IDs)."""

    action: Literal["duplicate"]
    id: str = Field(description="Source dashboard ID")
    new_title: str | None = Field(
        default=None, description='Title for the copy (default: "Copy of {original}")'
    )


class ShareDashboardAction(BaseModel):
    """Toggle dashboard visibility between private and shared (org)."""

    action: Literal["share"]
    id: str = Field(description="Dashboard ID")
    visibility: Literal["private", "org"]


class SetDashboardControlsAction(BaseModel):
    """Update a dashboard's date-range, grain, and comparison controls."""

    action: Literal["set_controls"]
    id: str = Field(description="Dashboard ID")
    date_range: dict | None = Field(
        default=None,
        description=(
            'Date range config. Relative: {"mode": "relative", "preset": "last_30_days"}. '
            'Absolute: {"mode": "absolute", "start_date": "YYYY-MM-DD", "end_date": "YYYY-MM-DD"}.'
        ),
    )
    grain: Literal["day", "week", "month", "quarter", "year"] | None = None
    comparison: Literal["none", "previous_period", "same_period_last_year"] | None = None


DashboardAction = Annotated[
    CreateDashboardAction
    | UpdateDashboardAction
    | DeleteDashboardAction
    | DuplicateDashboardAction
    | ShareDashboardAction
    | SetDashboardControlsAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Widget action types
# ---------------------------------------------------------------------------


class AddWidgetAction(BaseModel):
    """Add a widget to a dashboard section."""

    action: Literal["add"]
    dashboard_id: str
    widget: dict = Field(
        description=(
            "Widget definition. Required: type (kpi|area_chart|bar_chart|line_chart|"
            "table|donut|heatmap), title, query. Optional: format, width (1-10), "
            "time_scope (range|latest|latest_complete), pivot (for table widgets)."
        )
    )
    page_index: int = 0
    section_index: int = 0
    expected_version: int | None = None


class UpdateWidgetAction(BaseModel):
    """Update a widget's fields (title, type, query, format, width, time_scope, pivot)."""

    action: Literal["update"]
    dashboard_id: str
    page_index: int
    section_index: int
    widget_index: int
    updates: dict = Field(description="Fields to patch — only provided keys are changed")
    expected_version: int | None = None


class RemoveWidgetAction(BaseModel):
    """Remove a widget from a dashboard section (irreversible)."""

    action: Literal["remove"]
    dashboard_id: str
    page_index: int
    section_index: int
    widget_index: int
    expected_version: int | None = None


class ReorderWidgetsAction(BaseModel):
    """Reorder widgets within a section. All widget IDs in the section must be listed."""

    action: Literal["reorder"]
    dashboard_id: str
    page_index: int
    section_index: int
    widget_ids: list[str] = Field(description="Full list of widget IDs in desired order")
    expected_version: int | None = None


class MoveWidgetAction(BaseModel):
    """Move a widget to a different page/section (keeps the same ID)."""

    action: Literal["move"]
    dashboard_id: str
    widget_id: str
    target_page_id: str
    target_section_index: int
    position: int | None = Field(
        default=None, description="Position within target section (None = append)"
    )


class CopyWidgetAction(BaseModel):
    """Copy a widget with a new ID."""

    action: Literal["copy"]
    dashboard_id: str
    widget_id: str
    target_page_id: str
    target_section_index: int
    new_title: str | None = None


class SwapWidgetsAction(BaseModel):
    """Swap the positions of two widgets (may be in different sections)."""

    action: Literal["swap"]
    dashboard_id: str
    widget_id_1: str
    widget_id_2: str


WidgetAction = Annotated[
    AddWidgetAction
    | UpdateWidgetAction
    | RemoveWidgetAction
    | ReorderWidgetsAction
    | MoveWidgetAction
    | CopyWidgetAction
    | SwapWidgetsAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Page action types
# ---------------------------------------------------------------------------


class CreatePageAction(BaseModel):
    action: Literal["create"]
    dashboard_id: str
    title: str
    position: int | None = Field(default=None, description="Insert position (None = append)")


class DeletePageAction(BaseModel):
    action: Literal["delete"]
    dashboard_id: str
    page_id: str
    cascade: bool = Field(default=False, description="Delete even if page has widgets")


class RenamePageAction(BaseModel):
    action: Literal["rename"]
    dashboard_id: str
    page_id: str
    title: str


class ReorderPagesAction(BaseModel):
    action: Literal["reorder"]
    dashboard_id: str
    page_ids: list[str] = Field(description="Full list of page IDs in desired order")


PageAction = Annotated[
    CreatePageAction | DeletePageAction | RenamePageAction | ReorderPagesAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Section action types
# ---------------------------------------------------------------------------


class CreateSectionAction(BaseModel):
    action: Literal["create"]
    dashboard_id: str
    page_id: str
    title: str | None = None
    position: int | None = None


class DeleteSectionAction(BaseModel):
    action: Literal["delete"]
    dashboard_id: str
    page_id: str
    section_index: int
    cascade: bool = False


class RenameSectionAction(BaseModel):
    action: Literal["rename"]
    dashboard_id: str
    page_id: str
    section_index: int
    title: str | None = Field(description="New title (None to clear)")


class MoveSectionAction(BaseModel):
    action: Literal["move"]
    dashboard_id: str
    source_page_id: str
    section_index: int
    target_page_id: str
    target_position: int | None = None


SectionAction = Annotated[
    CreateSectionAction | DeleteSectionAction | RenameSectionAction | MoveSectionAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Knowledge action types
# ---------------------------------------------------------------------------


_KnowledgeItemType = Literal[
    "metric_definition",
    "data_quirk",
    "join_rule",
    "filter_rule",
    "playbook",
    "business_term",
]

_KnowledgeSource = Literal[
    "user_correction", "admin_authored", "agent_learned", "imported"
]


class CreateKnowledgeAction(BaseModel):
    """Create a shared org knowledge item."""

    action: Literal["create"]
    item_type: _KnowledgeItemType
    title: str
    content: str
    subjects: list[str] | None = None
    applies_to_metrics: list[str] | None = None
    applies_to_dimensions: list[str] | None = None
    source: _KnowledgeSource = "admin_authored"
    confidence: float = 0.8


class RecordCorrectionAction(BaseModel):
    """Record a user correction as a proposed knowledge item (source=user_correction)."""

    action: Literal["record_correction"]
    title: str
    correction: str
    question: str | None = None
    subjects: list[str] | None = None
    applies_to_metrics: list[str] | None = None
    applies_to_dimensions: list[str] | None = None


class ReviewKnowledgeAction(BaseModel):
    """Review a knowledge item. Admin only."""

    action: Literal["review"]
    item_id: str
    status: Literal["reviewed", "rejected", "superseded"]
    review_note: str | None = None
    confidence: float | None = None


KnowledgeAction = Annotated[
    CreateKnowledgeAction | RecordCorrectionAction | ReviewKnowledgeAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Semantic-model action types (admin/owner only)
# ---------------------------------------------------------------------------


class CreateSemanticModelAction(BaseModel):
    action: Literal["create"]
    model_data: dict = Field(
        description="Full semantic-model definition (name, measures, dimensions, entities)"
    )


class UpdateSemanticModelAction(BaseModel):
    action: Literal["update"]
    name: str
    updates: dict


class DeleteSemanticModelAction(BaseModel):
    action: Literal["delete"]
    name: str


SemanticModelAction = Annotated[
    CreateSemanticModelAction | UpdateSemanticModelAction | DeleteSemanticModelAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Metric action types (admin/owner only for writes, preview is open)
# ---------------------------------------------------------------------------


class CreateMetricAction(BaseModel):
    action: Literal["create"]
    metric_data: dict = Field(description="Metric definition (name, type, type_params)")


class UpdateMetricAction(BaseModel):
    action: Literal["update"]
    name: str
    updates: dict


class DeleteMetricAction(BaseModel):
    action: Literal["delete"]
    name: str


class PreviewMetricAction(BaseModel):
    action: Literal["preview"]
    metric_data: dict = Field(description="Metric definition to preview")
    sample_query: dict | None = Field(
        default=None,
        description="Optional query params (start_date, end_date, grain, limit)",
    )


MetricAction = Annotated[
    CreateMetricAction
    | UpdateMetricAction
    | DeleteMetricAction
    | PreviewMetricAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Quick-metric action types
# ---------------------------------------------------------------------------


class CreateQuickMetricAction(BaseModel):
    action: Literal["create"]
    name: str = Field(description='Metric name (e.g., "revenue_per_order")')
    expression: str = Field(
        description='Arithmetic expression over existing metrics (e.g., "total_revenue / order_count")'
    )
    description: str | None = None


class UpdateQuickMetricAction(BaseModel):
    action: Literal["update"]
    metric_id: str
    name: str | None = None
    expression: str | None = None
    description: str | None = None


class DeleteQuickMetricAction(BaseModel):
    action: Literal["delete"]
    metric_id: str


QuickMetricAction = Annotated[
    CreateQuickMetricAction | UpdateQuickMetricAction | DeleteQuickMetricAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Scheduled-report action types
# ---------------------------------------------------------------------------


_Frequency = Literal["daily", "weekly", "monthly"]


class CreateReportAction(BaseModel):
    action: Literal["create"]
    name: str
    frequency_type: _Frequency
    time: str = Field(description="HH:MM in UTC, 24-hour")
    recipients: list[str]
    dashboard_id: str | None = Field(
        default=None, description="For dashboard reports (PDF/PNG)"
    )
    metrics: list[str] | None = Field(
        default=None, description="For query reports (CSV/JSON)"
    )
    dimensions: list[str] | None = None
    format: str = Field(
        default="pdf",
        description='"pdf"|"png" for dashboards, "csv"|"json" for queries',
    )
    day_of_week: int | None = Field(default=None, description="0=Mon … 6=Sun (weekly)")
    day_of_month: int | None = Field(default=None, description="1-28 (monthly)")


class UpdateReportAction(BaseModel):
    action: Literal["update"]
    schedule_id: str
    name: str | None = None
    enabled: bool | None = Field(
        default=None, description="Set False to pause without deleting"
    )
    frequency_type: _Frequency | None = None
    time: str | None = None
    day_of_week: int | None = None
    day_of_month: int | None = None
    recipients: list[str] | None = None


class DeleteReportAction(BaseModel):
    action: Literal["delete"]
    schedule_id: str


ReportAction = Annotated[
    CreateReportAction | UpdateReportAction | DeleteReportAction,
    Field(discriminator="action"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _get_user(ctx: Context) -> UserContext:
    user_data = await ctx.get_state("user")
    if user_data is None:
        raise ToolError("Authentication required: no user context")
    if isinstance(user_data, dict):
        return UserContext(**user_data)
    return user_data


def _ok(dashboard) -> dict:
    return {"success": True, "dashboard": dashboard.model_dump()}


def _conflict_err(e) -> dict:
    return {
        "error": "conflict",
        "message": str(e),
        "current_version": e.current_version,
        "expected_version": e.expected_version,
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_dispatch_tools(mcp: FastMCP) -> None:
    """Register dispatch tools on the FastMCP instance."""

    @mcp.tool()
    async def dashboard_edit(
        action: DashboardAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit dashboards via a single dispatch tool with a discriminated action.

        Actions:
        - **create**(title, description?, visibility?) — new dashboard
        - **update**(id, title?, description?, visibility?, expected_version?) — patch metadata
        - **delete**(id) — remove (irreversible)
        - **duplicate**(id, new_title?) — copy with new IDs
        - **share**(id, visibility) — flip private/org
        - **set_controls**(id, date_range?, grain?, comparison?) — update dashboard controls

        Use metricly://dashboards (list) or metricly://dashboards/{id} (detail)
        to read dashboards without invoking this tool.
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateDashboardAction)
                    d = await dashboard_service.create_dashboard(
                        user,
                        title=action.title,
                        description=action.description,
                        visibility=action.visibility,
                    )
                    return _ok(d)

                case "update":
                    assert isinstance(action, UpdateDashboardAction)
                    updates: dict = {}
                    if action.title is not None:
                        updates["title"] = action.title
                    if action.description is not None:
                        updates["description"] = action.description
                    if action.visibility is not None:
                        updates["visibility"] = action.visibility
                    if not updates:
                        return {"error": "No updates provided"}
                    try:
                        d = await dashboard_service.update_dashboard(
                            user, action.id, updates, action.expected_version
                        )
                        return _ok(d)
                    except dashboard_service.ConflictError as e:
                        return _conflict_err(e)

                case "delete":
                    assert isinstance(action, DeleteDashboardAction)
                    ok = await dashboard_service.delete_dashboard(user, action.id)
                    return {"success": bool(ok)}

                case "duplicate":
                    assert isinstance(action, DuplicateDashboardAction)
                    d = await dashboard_service.duplicate_dashboard(
                        user, action.id, new_title=action.new_title
                    )
                    return _ok(d)

                case "share":
                    assert isinstance(action, ShareDashboardAction)
                    d = await dashboard_service.share_dashboard(
                        user, action.id, visibility=action.visibility
                    )
                    return _ok(d)

                case "set_controls":
                    assert isinstance(action, SetDashboardControlsAction)
                    d = await dashboard_service.set_dashboard_controls(
                        user,
                        action.id,
                        date_range=action.date_range,
                        grain=action.grain,
                        comparison=action.comparison,
                    )
                    return _ok(d)

        except ValueError as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("dashboard_edit failed")
            return {"error": f"Failed to {action.action} dashboard: {e}"}

        # unreachable — mypy/pyright will flag if a case is missed
        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def widget_edit(
        action: WidgetAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit dashboard widgets via a single dispatch tool.

        Actions:
        - **add**(dashboard_id, widget, page_index?, section_index?, expected_version?)
        - **update**(dashboard_id, page_index, section_index, widget_index, updates, expected_version?)
        - **remove**(dashboard_id, page_index, section_index, widget_index, expected_version?)
        - **reorder**(dashboard_id, page_index, section_index, widget_ids, expected_version?)
        - **move**(dashboard_id, widget_id, target_page_id, target_section_index, position?)
        - **copy**(dashboard_id, widget_id, target_page_id, target_section_index, new_title?)
        - **swap**(dashboard_id, widget_id_1, widget_id_2)

        ``add``/``update``/``remove``/``reorder`` use index-based addressing and
        support optimistic locking via ``expected_version``. ``move``/``copy``/
        ``swap`` use ID-based addressing for atomic cross-section operations.
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "add":
                    assert isinstance(action, AddWidgetAction)
                    try:
                        d = await dashboard_service.add_widget(
                            user,
                            action.dashboard_id,
                            action.widget,
                            page_index=action.page_index,
                            section_index=action.section_index,
                            expected_version=action.expected_version,
                        )
                        return _ok(d)
                    except dashboard_service.ConflictError as e:
                        return _conflict_err(e)

                case "update":
                    assert isinstance(action, UpdateWidgetAction)
                    try:
                        d = await dashboard_service.update_widget(
                            user,
                            action.dashboard_id,
                            page_index=action.page_index,
                            section_index=action.section_index,
                            widget_index=action.widget_index,
                            updates=action.updates,
                            expected_version=action.expected_version,
                        )
                        return _ok(d)
                    except dashboard_service.ConflictError as e:
                        return _conflict_err(e)

                case "remove":
                    assert isinstance(action, RemoveWidgetAction)
                    try:
                        d = await dashboard_service.remove_widget(
                            user,
                            action.dashboard_id,
                            page_index=action.page_index,
                            section_index=action.section_index,
                            widget_index=action.widget_index,
                            expected_version=action.expected_version,
                        )
                        return _ok(d)
                    except dashboard_service.ConflictError as e:
                        return _conflict_err(e)

                case "reorder":
                    assert isinstance(action, ReorderWidgetsAction)
                    try:
                        d = await dashboard_service.reorder_widgets(
                            user,
                            action.dashboard_id,
                            page_index=action.page_index,
                            section_index=action.section_index,
                            widget_ids=action.widget_ids,
                            expected_version=action.expected_version,
                        )
                        return _ok(d)
                    except dashboard_service.ConflictError as e:
                        return _conflict_err(e)

                case "move":
                    assert isinstance(action, MoveWidgetAction)
                    d = await dashboard_service.move_widget(
                        user,
                        action.dashboard_id,
                        action.widget_id,
                        action.target_page_id,
                        action.target_section_index,
                        action.position,
                    )
                    return _ok(d)

                case "copy":
                    assert isinstance(action, CopyWidgetAction)
                    d = await dashboard_service.copy_widget(
                        user,
                        action.dashboard_id,
                        action.widget_id,
                        action.target_page_id,
                        action.target_section_index,
                        action.new_title,
                    )
                    return _ok(d)

                case "swap":
                    assert isinstance(action, SwapWidgetsAction)
                    d = await dashboard_service.swap_widgets(
                        user,
                        action.dashboard_id,
                        action.widget_id_1,
                        action.widget_id_2,
                    )
                    return _ok(d)

        except ValueError as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("widget_edit failed")
            return {"error": f"Failed to {action.action} widget: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def page_edit(action: PageAction, ctx: Context = CurrentContext()) -> dict:
        """Edit dashboard pages via a single dispatch tool.

        Actions:
        - **create**(dashboard_id, title, position?) — append or insert page
        - **delete**(dashboard_id, page_id, cascade?) — remove (cannot delete last page)
        - **rename**(dashboard_id, page_id, title) — rename in place
        - **reorder**(dashboard_id, page_ids) — reorder; all page IDs must be listed
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreatePageAction)
                    d = await dashboard_service.create_page(
                        user, action.dashboard_id, action.title, action.position
                    )
                    return _ok(d)

                case "delete":
                    assert isinstance(action, DeletePageAction)
                    d = await dashboard_service.delete_page(
                        user, action.dashboard_id, action.page_id, action.cascade
                    )
                    return _ok(d)

                case "rename":
                    assert isinstance(action, RenamePageAction)
                    d = await dashboard_service.rename_page(
                        user, action.dashboard_id, action.page_id, action.title
                    )
                    return _ok(d)

                case "reorder":
                    assert isinstance(action, ReorderPagesAction)
                    d = await dashboard_service.reorder_pages(
                        user, action.dashboard_id, action.page_ids
                    )
                    return _ok(d)

        except ValueError as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("page_edit failed")
            return {"error": f"Failed to {action.action} page: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def section_edit(
        action: SectionAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit dashboard sections via a single dispatch tool.

        Actions:
        - **create**(dashboard_id, page_id, title?, position?) — add section to a page
        - **delete**(dashboard_id, page_id, section_index, cascade?) — remove
        - **rename**(dashboard_id, page_id, section_index, title) — set (or clear) title
        - **move**(dashboard_id, source_page_id, section_index, target_page_id, target_position?)
          — cross-page section move
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateSectionAction)
                    d = await dashboard_service.create_section(
                        user,
                        action.dashboard_id,
                        action.page_id,
                        action.title,
                        action.position,
                    )
                    return _ok(d)

                case "delete":
                    assert isinstance(action, DeleteSectionAction)
                    d = await dashboard_service.delete_section(
                        user,
                        action.dashboard_id,
                        action.page_id,
                        action.section_index,
                        action.cascade,
                    )
                    return _ok(d)

                case "rename":
                    assert isinstance(action, RenameSectionAction)
                    d = await dashboard_service.rename_section(
                        user,
                        action.dashboard_id,
                        action.page_id,
                        action.section_index,
                        action.title,
                    )
                    return _ok(d)

                case "move":
                    assert isinstance(action, MoveSectionAction)
                    d = await dashboard_service.move_section(
                        user,
                        action.dashboard_id,
                        action.source_page_id,
                        action.section_index,
                        action.target_page_id,
                        action.target_position,
                    )
                    return _ok(d)

        except ValueError as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("section_edit failed")
            return {"error": f"Failed to {action.action} section: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def knowledge_edit(
        action: KnowledgeAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit shared org knowledge items via a single dispatch tool.

        Actions:
        - **create**(item_type, title, content, ...) — create an org-authored item
        - **record_correction**(title, correction, question?, ...) — record a user
          correction as a proposed item (source=user_correction)
        - **review**(item_id, status, review_note?, confidence?) — admin-only review

        Use metricly://knowledge (list) or metricly://knowledge/{id} (detail) to
        browse items without invoking this tool.
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateKnowledgeAction)
                    item = await knowledge_service.create_knowledge_item(
                        user,
                        knowledge_service.CreateKnowledgeItemParams(
                            type=action.item_type,
                            title=action.title,
                            content=action.content,
                            subjects=action.subjects or [],
                            applies_to_metrics=action.applies_to_metrics or [],
                            applies_to_dimensions=action.applies_to_dimensions or [],
                            source=action.source,
                            confidence=action.confidence,
                        ),
                    )
                    return item.model_dump(exclude_none=True)

                case "record_correction":
                    assert isinstance(action, RecordCorrectionAction)
                    item = await knowledge_service.create_knowledge_item(
                        user,
                        knowledge_service.CreateKnowledgeItemParams(
                            type="data_quirk",
                            title=action.title,
                            content=action.correction,
                            subjects=action.subjects or [],
                            applies_to_metrics=action.applies_to_metrics or [],
                            applies_to_dimensions=action.applies_to_dimensions or [],
                            source="user_correction",
                            confidence=0.5,
                            evidence=knowledge_service.KnowledgeEvidence(
                                question=action.question,
                                correction=action.correction,
                            ),
                        ),
                    )
                    return item.model_dump(exclude_none=True)

                case "review":
                    assert isinstance(action, ReviewKnowledgeAction)
                    item = await knowledge_service.review_knowledge_item(
                        user,
                        action.item_id,
                        status=action.status,
                        review_note=action.review_note,
                        confidence=action.confidence,
                    )
                    return item.model_dump(exclude_none=True)

        except (ValueError, PermissionError) as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("knowledge_edit failed")
            return {"error": f"Failed to {action.action} knowledge item: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def semantic_model_edit(
        action: SemanticModelAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit semantic models in the org manifest. Admin/owner only.

        Actions:
        - **create**(model_data) — new semantic model
        - **update**(name, updates) — patch an existing model
        - **delete**(name) — remove (irreversible)

        Use metricly://manifest/models to browse without invoking this tool.
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateSemanticModelAction)
                    result = await manifest_service.create_semantic_model(
                        user, action.model_data
                    )
                    return {"success": True, "model": result}

                case "update":
                    assert isinstance(action, UpdateSemanticModelAction)
                    result = await manifest_service.update_semantic_model(
                        user, action.name, action.updates
                    )
                    return {"success": True, "model": result}

                case "delete":
                    assert isinstance(action, DeleteSemanticModelAction)
                    await manifest_service.delete_semantic_model(user, action.name)
                    return {"success": True, "message": f"Model '{action.name}' deleted"}

        except (PermissionError, ValueError) as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("semantic_model_edit failed")
            return {"error": f"Failed to {action.action} semantic model: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def metric_edit(
        action: MetricAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit metrics in the org manifest. Admin/owner only for writes.

        Actions:
        - **create**(metric_data) — new metric
        - **update**(name, updates) — patch an existing metric
        - **delete**(name) — remove (irreversible)
        - **preview**(metric_data, sample_query?) — test a metric before saving
          (no role requirement; returns sample query results or validation errors)
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateMetricAction)
                    result = await manifest_service.create_metric(
                        user, action.metric_data
                    )
                    return {"success": True, "metric": result}

                case "update":
                    assert isinstance(action, UpdateMetricAction)
                    result = await manifest_service.update_metric(
                        user, action.name, action.updates
                    )
                    return {"success": True, "metric": result}

                case "delete":
                    assert isinstance(action, DeleteMetricAction)
                    await manifest_service.delete_metric(user, action.name)
                    return {"success": True, "message": f"Metric '{action.name}' deleted"}

                case "preview":
                    assert isinstance(action, PreviewMetricAction)
                    return await manifest_service.preview_metric(
                        user, action.metric_data, action.sample_query
                    )

        except (PermissionError, ValueError) as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("metric_edit failed")
            return {"error": f"Failed to {action.action} metric: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def quick_metric_edit(
        action: QuickMetricAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit user-defined quick metrics (arithmetic expressions over existing metrics).

        Actions:
        - **create**(name, expression, description?) — e.g. name="aov",
          expression="total_revenue / order_count"
        - **update**(metric_id, name?, expression?, description?) — patch
        - **delete**(metric_id) — remove (irreversible)

        Query a quick metric with the ``qm:`` prefix (e.g. ``qm:aov``).
        Use metricly://quick_metrics (list) or metricly://quick_metrics/{id} (detail)
        to browse without invoking this tool.
        """
        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateQuickMetricAction)
                    metric = await quick_metrics_service.create_quick_metric(
                        user,
                        name=action.name,
                        expression=action.expression,
                        description=action.description,
                    )
                    return {
                        "success": True,
                        "quick_metric": {
                            "id": metric.id,
                            "name": metric.name,
                            "expression": metric.expression,
                            "description": metric.description,
                            "base_metrics": metric.base_metrics,
                            "query_name": f"qm:{metric.name}",
                            "created_at": metric.created_at.isoformat(),
                        },
                    }

                case "update":
                    assert isinstance(action, UpdateQuickMetricAction)
                    metric = await quick_metrics_service.update_quick_metric(
                        user,
                        action.metric_id,
                        name=action.name,
                        expression=action.expression,
                        description=action.description,
                    )
                    return {
                        "success": True,
                        "quick_metric": {
                            "id": metric.id,
                            "name": metric.name,
                            "expression": metric.expression,
                            "description": metric.description,
                            "base_metrics": metric.base_metrics,
                            "query_name": f"qm:{metric.name}",
                            "updated_at": metric.updated_at.isoformat(),
                        },
                    }

                case "delete":
                    assert isinstance(action, DeleteQuickMetricAction)
                    await quick_metrics_service.delete_quick_metric(
                        user, action.metric_id
                    )
                    return {"success": True, "message": f"Quick metric '{action.metric_id}' deleted"}

        except quick_metrics_service.ExpressionError as e:
            return {"error": f"Invalid expression: {e.message}"}
        except (ValueError, PermissionError) as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("quick_metric_edit failed")
            return {"error": f"Failed to {action.action} quick metric: {e}"}

        raise AssertionError(f"Unhandled action: {action}")

    @mcp.tool()
    async def report_edit(
        action: ReportAction, ctx: Context = CurrentContext()
    ) -> dict:
        """Edit scheduled reports (recurring email delivery of dashboards or queries).

        Actions:
        - **create**(name, frequency_type, time, recipients, [dashboard_id | metrics], format?, day_of_week?, day_of_month?)
        - **update**(schedule_id, name?, enabled?, frequency_type?, time?, day_of_week?, day_of_month?, recipients?)
        - **delete**(schedule_id)

        Use metricly://reports (list) or metricly://reports/{id} (detail) to browse.
        """
        if not get_settings().schedules_enabled:
            return {
                "error": "Scheduled reports coming soon. This feature is not yet enabled."
            }

        user = await _get_user(ctx)

        try:
            match action.action:
                case "create":
                    assert isinstance(action, CreateReportAction)
                    if not action.dashboard_id and not action.metrics:
                        return {"error": "Either dashboard_id or metrics must be provided"}
                    if action.dashboard_id and action.metrics:
                        return {"error": "Provide either dashboard_id or metrics, not both"}

                    frequency = schedule_service.ScheduleFrequency(
                        type=action.frequency_type,
                        time=action.time,
                        day_of_week=action.day_of_week,
                        day_of_month=action.day_of_month,
                    )
                    if action.dashboard_id:
                        if action.format not in ("pdf", "png"):
                            return {
                                "error": f"Invalid format for dashboard report: {action.format}. "
                                "Must be 'pdf' or 'png'"
                            }
                        report = schedule_service.DashboardReport(
                            dashboard_id=action.dashboard_id, format=action.format
                        )
                    else:
                        if action.format not in ("csv", "json"):
                            return {
                                "error": f"Invalid format for query report: {action.format}. "
                                "Must be 'csv' or 'json'"
                            }
                        report = schedule_service.QueryReport(
                            metrics=action.metrics,
                            dimensions=action.dimensions or [],
                            format=action.format,
                        )

                    schedule = await schedule_service.create_schedule(
                        user=user,
                        name=action.name,
                        frequency=frequency,
                        report=report,
                        recipients=action.recipients,
                    )
                    return {
                        "success": True,
                        "schedule": {
                            "id": schedule.id,
                            "name": schedule.name,
                            "frequency": schedule.frequency.model_dump(),
                            "report": schedule.report.model_dump(),
                            "recipients": schedule.recipients,
                            "enabled": schedule.enabled,
                            "created_at": schedule.created_at.isoformat(),
                        },
                    }

                case "update":
                    assert isinstance(action, UpdateReportAction)
                    updates: dict = {}
                    if action.name is not None:
                        updates["name"] = action.name
                    if action.enabled is not None:
                        updates["enabled"] = action.enabled
                    if action.recipients is not None:
                        updates["recipients"] = action.recipients

                    if (
                        action.frequency_type is not None
                        or action.time is not None
                        or action.day_of_week is not None
                        or action.day_of_month is not None
                    ):
                        current = await schedule_service.get_schedule(
                            user, action.schedule_id
                        )
                        cf = current.frequency
                        updates["frequency"] = {
                            "type": action.frequency_type or cf.type,
                            "time": action.time or cf.time,
                            "day_of_week": (
                                action.day_of_week
                                if action.day_of_week is not None
                                else cf.day_of_week
                            ),
                            "day_of_month": (
                                action.day_of_month
                                if action.day_of_month is not None
                                else cf.day_of_month
                            ),
                        }

                    if not updates:
                        return {"error": "No updates provided"}

                    schedule = await schedule_service.update_schedule(
                        user, action.schedule_id, updates
                    )
                    return {
                        "success": True,
                        "schedule": {
                            "id": schedule.id,
                            "name": schedule.name,
                            "frequency": schedule.frequency.model_dump(),
                            "report": schedule.report.model_dump(),
                            "recipients": schedule.recipients,
                            "enabled": schedule.enabled,
                            "updated_at": schedule.updated_at.isoformat(),
                        },
                    }

                case "delete":
                    assert isinstance(action, DeleteReportAction)
                    await schedule_service.delete_schedule(user, action.schedule_id)
                    return {
                        "success": True,
                        "message": f"Schedule '{action.schedule_id}' deleted",
                    }

        except (ValueError, PermissionError) as e:
            return {"error": str(e)}
        except Exception as e:
            logger.exception("report_edit failed")
            return {"error": f"Failed to {action.action} scheduled report: {e}"}

        raise AssertionError(f"Unhandled action: {action}")
