"""Small, import-light helpers for MCP URL routing.

Lives in its own module (rather than ``main.py``) so it can be unit-tested
without pulling in the full FastAPI app — which transitively imports
``pydantic_ai`` and other heavy deps.
"""

from __future__ import annotations


MCP_EXTERNAL_BASE_URL = "https://metricly.xyz/api/mcp/"


def mcp_trailing_slash_target(query: str) -> str:
    """Build the external redirect URL for ``/api/mcp`` → ``/api/mcp/``.

    Preserves the query string — critical for the MCP org-pinning feature
    (``?org=<id>``). Without this, pasting the no-trailing-slash form of
    the URL into a host like Claude.ai would silently strip the pin on
    the redirect follow-up (verified in prod logs with TEST_MARKER_ABC
    on 2026-04-21).

    Args:
        query: The raw query string (without leading ``?``). Empty string
            when no query was provided.
    """
    if query:
        return f"{MCP_EXTERNAL_BASE_URL}?{query}"
    return MCP_EXTERNAL_BASE_URL
