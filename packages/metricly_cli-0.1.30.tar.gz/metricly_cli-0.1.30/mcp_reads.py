"""MCP read tools — tool wrappers around the metricly:// read resources.

The PR-42 consolidation moved all reads (list_dashboards, list_metrics, …)
into ``metricly://`` resources on the assumption that hosts would surface
``resources/list`` + ``resources/read`` to the LLM. Claude.ai chat
currently does not — resources are application-controlled per the MCP
spec and Claude.ai exposes them as user-attached context, not as
model-callable APIs.

These thin tool wrappers re-expose the same reads as ``@mcp.tool()`` so
the model can discover and invoke them directly. The underlying service
calls and resource handlers stay unchanged; this is purely an additional
surface for hosts that don't drive resource reads from the model.
"""

from __future__ import annotations

import logging

from fastmcp import Context, FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import CurrentContext

import services.context as context_service
import services.dashboards as dashboard_service
import services.knowledge as knowledge_service
import services.manifest as manifest_service
import services.queries as query_service
import services.quick_metrics as quick_metrics_service
import services.schedules as schedule_service
from mcp_resources import augment_orgs_with_pin_state
from services.auth import UserContext, get_user_orgs
from settings import get_settings

logger = logging.getLogger(__name__)


async def _user_from_tool_context(ctx: Context) -> UserContext:
    user_data = await ctx.get_state("user")
    if user_data is None:
        raise ToolError("Authentication required: no user context")
    if isinstance(user_data, dict):
        return UserContext(**user_data)
    return user_data


def register_read_tools(mcp: FastMCP) -> None:
    """Register read tools that mirror the metricly:// resource surface."""

    @mcp.tool()
    async def list_organizations(ctx: Context = CurrentContext()) -> list[dict]:
        """List all organizations the current user belongs to.

        Returns each org's ``id``, ``name``, ``role``, plus ``current``
        (active for this connection) and ``pinned`` (true when the URL
        carries ``?org=`` and is locked to this org).
        """
        user = await _user_from_tool_context(ctx)
        org_pinned = bool(await ctx.get_state("org_pinned"))
        orgs = get_user_orgs(user.email)
        return augment_orgs_with_pin_state(orgs, user.org_id, org_pinned)

    @mcp.tool()
    async def list_dashboards(ctx: Context = CurrentContext()) -> list[dict]:
        """List dashboards accessible to the user.

        Returns each dashboard's ``id``, ``title``, ``description``,
        ``visibility`` ("private" or "org"), and ``owner``.
        """
        user = await _user_from_tool_context(ctx)
        result = await dashboard_service.list_dashboards(user)
        out: list[dict] = []
        for d in result.personal:
            out.append(
                {
                    "id": d.id,
                    "title": d.title,
                    "description": d.description,
                    "visibility": "private",
                    "owner": d.owner,
                }
            )
        for d in result.team:
            out.append(
                {
                    "id": d.id,
                    "title": d.title,
                    "description": d.description,
                    "visibility": "org",
                    "owner": d.owner,
                }
            )
        return out

    @mcp.tool()
    async def get_dashboard(
        dashboard_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Fetch a dashboard's full configuration (pages, sections, widgets)."""
        user = await _user_from_tool_context(ctx)
        try:
            dashboard = await dashboard_service.get_dashboard(user, dashboard_id)
        except ValueError as e:
            raise ToolError(str(e))
        return dashboard.model_dump()

    @mcp.tool()
    async def list_metrics(ctx: Context = CurrentContext()) -> list[dict]:
        """List all metrics available in the org.

        Each entry has ``name``, ``type``, ``description``, and the
        underlying definition. Use ``explain_metric`` for a single
        metric's full calculation details.
        """
        user = await _user_from_tool_context(ctx)
        try:
            return await query_service.list_metrics(user.org_id)
        except ValueError as e:
            raise ToolError(str(e))

    @mcp.tool()
    async def explain_metric(
        metric_name: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Return calculation details for a single metric (type, formula, measures)."""
        user = await _user_from_tool_context(ctx)
        try:
            return await query_service.explain_metric(user.org_id, metric_name)
        except ValueError as e:
            raise ToolError(str(e))

    @mcp.tool()
    async def list_dimensions(ctx: Context = CurrentContext()) -> list[dict]:
        """List all dimensions available for grouping (qualified names like ``customer__region``)."""
        user = await _user_from_tool_context(ctx)
        try:
            return await query_service.list_dimensions(user.org_id)
        except ValueError as e:
            raise ToolError(str(e))

    @mcp.tool()
    async def list_knowledge(
        status: str | None = None,
        item_type: str | None = None,
        subject: str | None = None,
        limit: int = 50,
        ctx: Context = CurrentContext(),
    ) -> list[dict]:
        """List shared org knowledge items, optionally filtered.

        Args:
            status: Filter by status (e.g. "active", "draft").
            item_type: Filter by knowledge item type.
            subject: Filter by subject keyword.
            limit: Max items to return (default 50).
        """
        user = await _user_from_tool_context(ctx)
        try:
            filters = knowledge_service.KnowledgeListFilters(
                status=status or None,  # type: ignore[arg-type]
                type=item_type or None,  # type: ignore[arg-type]
                subject=subject or None,
                limit=limit,
            )
        except ValueError as e:
            raise ToolError(str(e))
        items = await knowledge_service.list_knowledge_items(user, filters)
        return [item.model_dump(exclude_none=True) for item in items]

    @mcp.tool()
    async def get_knowledge(
        item_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Fetch a single knowledge item by ID."""
        user = await _user_from_tool_context(ctx)
        try:
            item = await knowledge_service.get_knowledge_item(user, item_id)
        except ValueError as e:
            raise ToolError(str(e))
        return item.model_dump(exclude_none=True)

    @mcp.tool()
    async def get_context(ctx: Context = CurrentContext()) -> dict:
        """Read the user's accumulated context (preferences, favorites)."""
        user = await _user_from_tool_context(ctx)
        prefs = await context_service.get_user_preferences(user.uid)
        return {
            "default_currency": prefs.default_currency,
            "default_grain": prefs.default_grain,
            "decimal_places": prefs.decimal_places,
            "preferred_chart_type": prefs.preferred_chart_type,
            "favorite_metrics": prefs.favorite_metrics,
            "updated_at": prefs.updated_at,
        }

    @mcp.tool()
    async def get_manifest_status(ctx: Context = CurrentContext()) -> dict:
        """Return semantic-manifest metadata (counts of metrics, models, dimensions, last updated)."""
        user = await _user_from_tool_context(ctx)
        status = await manifest_service.get_manifest_status(user)
        return {
            "org_id": status.org_id,
            "project_name": status.project_name,
            "metric_count": status.metric_count,
            "model_count": status.model_count,
            "dimension_count": status.dimension_count,
            "last_updated": status.last_updated,
        }

    @mcp.tool()
    async def list_semantic_models(ctx: Context = CurrentContext()) -> list[dict]:
        """List all semantic models in the manifest."""
        user = await _user_from_tool_context(ctx)
        return await manifest_service.list_semantic_models(user)

    @mcp.tool()
    async def get_semantic_model(
        name: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Fetch a single semantic model by name."""
        user = await _user_from_tool_context(ctx)
        try:
            return await manifest_service.get_semantic_model(user, name)
        except ValueError as e:
            raise ToolError(str(e))

    @mcp.tool()
    async def export_manifest(ctx: Context = CurrentContext()) -> dict:
        """Export the full semantic manifest (metrics + semantic models + project config)."""
        user = await _user_from_tool_context(ctx)
        return await manifest_service.export_manifest(user)

    @mcp.tool()
    async def list_quick_metrics(ctx: Context = CurrentContext()) -> list[dict]:
        """List user-defined derived metrics (expressions over existing metrics)."""
        user = await _user_from_tool_context(ctx)
        metrics = await quick_metrics_service.list_quick_metrics(user)
        return [
            {
                "id": m.id,
                "name": m.name,
                "description": m.description,
                "expression": m.expression,
                "query_name": f"qm:{m.name}",
            }
            for m in metrics
        ]

    @mcp.tool()
    async def get_quick_metric(
        metric_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Fetch a single quick metric's full definition."""
        user = await _user_from_tool_context(ctx)
        try:
            metric = await quick_metrics_service.get_quick_metric(user, metric_id)
        except ValueError as e:
            raise ToolError(str(e))
        return {
            "id": metric.id,
            "name": metric.name,
            "description": metric.description,
            "expression": metric.expression,
            "base_metrics": metric.base_metrics,
            "query_name": f"qm:{metric.name}",
            "created_by": metric.created_by,
            "created_at": metric.created_at.isoformat(),
            "updated_at": metric.updated_at.isoformat(),
        }

    @mcp.tool()
    async def list_reports(ctx: Context = CurrentContext()) -> list[dict]:
        """List all scheduled reports in the org (summary view)."""
        if not get_settings().schedules_enabled:
            raise ToolError(
                "Scheduled reports coming soon. This feature is not yet enabled."
            )
        user = await _user_from_tool_context(ctx)
        summaries = await schedule_service.list_schedules(user)
        return [
            {
                "id": s.id,
                "name": s.name,
                "frequency_type": s.frequency_type,
                "frequency_time": s.frequency_time,
                "report_type": s.report_type,
                "enabled": s.enabled,
                "recipients_count": s.recipients_count,
                "last_run_at": s.last_run_at.isoformat() if s.last_run_at else None,
                "last_run_status": s.last_run_status,
            }
            for s in summaries
        ]

    @mcp.tool()
    async def get_report(
        schedule_id: str, ctx: Context = CurrentContext()
    ) -> dict:
        """Fetch a single scheduled report by ID (full config + run metadata)."""
        if not get_settings().schedules_enabled:
            raise ToolError(
                "Scheduled reports coming soon. This feature is not yet enabled."
            )
        user = await _user_from_tool_context(ctx)
        try:
            schedule = await schedule_service.get_schedule(user, schedule_id)
        except ValueError as e:
            raise ToolError(str(e))
        return {
            "id": schedule.id,
            "name": schedule.name,
            "frequency": schedule.frequency.model_dump(),
            "report": schedule.report.model_dump(),
            "report_type": (
                "dashboard"
                if isinstance(schedule.report, schedule_service.DashboardReport)
                else "query"
            ),
            "recipients": schedule.recipients,
            "enabled": schedule.enabled,
            "created_by": schedule.created_by,
            "created_at": schedule.created_at.isoformat(),
            "updated_at": schedule.updated_at.isoformat(),
            "last_run_at": (
                schedule.last_run_at.isoformat() if schedule.last_run_at else None
            ),
            "last_run_status": schedule.last_run_status,
        }
