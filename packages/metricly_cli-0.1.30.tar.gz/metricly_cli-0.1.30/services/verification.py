"""Post-query verification and retry guidance for analytical answers."""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, Field

from services.retrieval import ContextBrief


class VerificationResult(BaseModel):
    """Outcome of verifying an analytical answer."""

    confidence: float
    needs_retry: bool
    gaps: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    retry_guidance: str | None = None


def _is_quantitative_question(question: str) -> bool:
    lowered = question.lower()
    # Metric-specific nouns that strongly signal a data question
    metric_nouns = ("revenue", "orders", "sales", "customers", "churn", "mrr", "arpu", "aov")
    if any(noun in lowered for noun in metric_nouns):
        return True
    # Analytical phrases (anchored to avoid false positives like "show me how")
    phrases = (
        "how much",
        "how many",
        "what is the",
        "what was",
        "what are the",
        "show me the",
        "show the",
        "show total",
        "trend of",
        "trend in",
        "top ",
        "breakdown",
        "compare ",
    )
    return any(phrase in lowered for phrase in phrases)


def _expects_breakdown(question: str) -> bool:
    lowered = question.lower()
    return any(token in lowered for token in (" by ", " per ", "top ", "breakdown", "across ", "segment"))


def _extract_requested_time_grain(question: str) -> str | None:
    lowered = question.lower()
    for grain in ("day", "week", "month", "quarter", "year"):
        if f"by {grain}" in lowered or f"{grain}ly" in lowered or f"per {grain}" in lowered:
            return grain
    return None


def _extract_time_reference(question: str) -> str | None:
    lowered = question.lower()
    patterns = (
        "today",
        "yesterday",
        "last week",
        "last month",
        "last quarter",
        "last year",
        "this week",
        "this month",
        "this quarter",
        "this year",
    )
    for pattern in patterns:
        if pattern in lowered:
            return pattern
    if re.search(r"\b20\d{2}\b", lowered):
        return "explicit year"
    return None


def verify_answer(
    question: str,
    query_history: list[dict[str, Any]],
    brief: ContextBrief | None = None,
) -> VerificationResult:
    """Check whether the executed query likely answers the user's question."""
    brief = brief or ContextBrief()
    gaps: list[str] = []
    warnings: list[str] = []

    successful_queries = [entry for entry in query_history if not entry.get("error")]
    if not successful_queries:
        if _is_quantitative_question(question):
            gaps.append("No successful metric query was executed for a quantitative question.")
            return VerificationResult(
                confidence=0.15,
                needs_retry=True,
                gaps=gaps,
                retry_guidance=(
                    "Run a metric query before answering. Use the retrieved metric and dimension hints, "
                    "then answer only after inspecting the returned data."
                ),
            )
        return VerificationResult(confidence=0.85, needs_retry=False)

    latest = successful_queries[-1]
    params = latest.get("params", {})
    metrics = params.get("metrics") or []
    dimensions = params.get("dimensions") or []
    grain = params.get("grain")
    start_date = params.get("start_date")
    end_date = params.get("end_date")
    row_count = latest.get("row_count", 0)

    suggested_metrics = [metric["name"] for metric in brief.relevant_metrics[:2]]
    if suggested_metrics and not any(metric in metrics for metric in suggested_metrics):
        gaps.append(
            f"Retrieved likely metrics ({', '.join(suggested_metrics)}) were not used in the executed query."
        )

    if _expects_breakdown(question) and not dimensions:
        gaps.append("The question asks for a breakdown/ranking, but the executed query has no dimensions.")

    requested_grain = _extract_requested_time_grain(question)
    if requested_grain and grain and requested_grain != grain:
        gaps.append(
            f"The question suggests {requested_grain} grain, but the executed query used {grain} grain."
        )
    elif requested_grain and not grain:
        gaps.append(
            f"The question suggests {requested_grain} grain, but the executed query did not specify a grain."
        )

    explicit_time_reference = _extract_time_reference(question)
    if explicit_time_reference and not (start_date or end_date):
        warnings.append(
            f"The question references a time window ({explicit_time_reference}), but the executed query relied on the default date range."
        )

    if row_count == 0:
        warnings.append("The executed query returned zero rows.")

    confidence = 0.95 - 0.22 * len(gaps) - 0.08 * len(warnings)
    confidence = max(0.05, min(0.99, confidence))
    needs_retry = bool(gaps)

    retry_guidance = None
    if needs_retry:
        retry_guidance = (
            "Your previous query likely missed part of the question. Address these gaps before answering:\n"
            + "\n".join(f"- {gap}" for gap in gaps)
        )
        if warnings:
            retry_guidance += "\nWarnings to keep in mind:\n" + "\n".join(f"- {warning}" for warning in warnings)

    return VerificationResult(
        confidence=confidence,
        needs_retry=needs_retry,
        gaps=gaps,
        warnings=warnings,
        retry_guidance=retry_guidance,
    )
