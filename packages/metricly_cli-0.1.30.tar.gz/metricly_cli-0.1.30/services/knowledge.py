"""Org knowledge service for shared analytical context.

Stores reviewable knowledge items at the organization level so agent learning
can become reusable institutional knowledge instead of personal notes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field

import storage
from services.auth import UserContext, require_role

KnowledgeType = Literal[
    "metric_definition",
    "data_quirk",
    "join_rule",
    "filter_rule",
    "playbook",
    "business_term",
]

KnowledgeStatus = Literal["proposed", "reviewed", "rejected", "superseded"]
ReviewableKnowledgeStatus = Literal["reviewed", "rejected", "superseded"]


class KnowledgeEvidence(BaseModel):
    """Optional evidence captured with a knowledge item."""

    question: str | None = None
    correction: str | None = None
    dashboard_id: str | None = None
    widget_id: str | None = None
    query_params: dict[str, Any] | None = None
    result_excerpt: list[dict[str, Any]] | None = None


class KnowledgeItem(BaseModel):
    """Shared analytical knowledge for an organization."""

    id: str
    org_id: str
    type: KnowledgeType
    title: str
    content: str
    subjects: list[str] = Field(default_factory=list)
    applies_to_metrics: list[str] = Field(default_factory=list)
    applies_to_dimensions: list[str] = Field(default_factory=list)
    status: KnowledgeStatus = "proposed"
    confidence: float = 0.5
    source: Literal["user_correction", "admin_authored", "agent_learned", "imported"]
    evidence: KnowledgeEvidence | None = None
    created_by: str
    reviewed_by: str | None = None
    review_note: str | None = None
    created_at: str
    updated_at: str


class CreateKnowledgeItemParams(BaseModel):
    """Parameters for creating a knowledge item."""

    type: KnowledgeType
    title: str
    content: str
    subjects: list[str] = Field(default_factory=list)
    applies_to_metrics: list[str] = Field(default_factory=list)
    applies_to_dimensions: list[str] = Field(default_factory=list)
    confidence: float = 0.5
    source: Literal["user_correction", "admin_authored", "agent_learned", "imported"]
    evidence: KnowledgeEvidence | None = None
    status: KnowledgeStatus = "proposed"


class UpdateKnowledgeItemParams(BaseModel):
    """Parameters for updating an existing knowledge item."""

    title: str | None = None
    content: str | None = None
    subjects: list[str] | None = None
    applies_to_metrics: list[str] | None = None
    applies_to_dimensions: list[str] | None = None
    confidence: float | None = None
    evidence: KnowledgeEvidence | None = None


class KnowledgeListFilters(BaseModel):
    """Optional filters for listing knowledge items."""

    type: KnowledgeType | None = None
    status: KnowledgeStatus | None = None
    subject: str | None = None
    limit: int = 50


def _now_iso() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


async def list_knowledge_items(
    user: UserContext,
    filters: KnowledgeListFilters | None = None,
) -> list[KnowledgeItem]:
    """List knowledge items visible to the user's organization."""
    filters = filters or KnowledgeListFilters()
    items = storage.list_knowledge_items(
        user.org_id,
        item_type=filters.type,
        status=filters.status,
        subject=filters.subject,
        limit=filters.limit,
    )
    return [KnowledgeItem.model_validate(item) for item in items]


async def get_knowledge_item(user: UserContext, item_id: str) -> KnowledgeItem:
    """Get a single knowledge item by ID."""
    item = storage.get_knowledge_item(user.org_id, item_id)
    if not item:
        raise ValueError(f"Knowledge item '{item_id}' not found")
    return KnowledgeItem.model_validate(item)


async def create_knowledge_item(
    user: UserContext,
    params: CreateKnowledgeItemParams,
) -> KnowledgeItem:
    """Create a new org knowledge item."""
    require_role(user, "member")

    # Auto-promote admin-authored items to reviewed
    effective_status = params.status
    if params.status == "proposed" and params.source == "admin_authored" and user.role in ("owner", "admin"):
        effective_status = "reviewed"

    item_id = str(uuid4())
    now = _now_iso()
    item = KnowledgeItem(
        id=item_id,
        org_id=user.org_id,
        type=params.type,
        title=params.title,
        content=params.content,
        subjects=params.subjects,
        applies_to_metrics=params.applies_to_metrics,
        applies_to_dimensions=params.applies_to_dimensions,
        status=effective_status,
        confidence=params.confidence,
        source=params.source,
        evidence=params.evidence,
        created_by=user.uid,
        created_at=now,
        updated_at=now,
    )
    saved = storage.save_knowledge_item(
        user.org_id,
        item.id,
        item.model_dump(exclude={"id"}),
    )
    return KnowledgeItem.model_validate(saved)


async def update_knowledge_item(
    user: UserContext,
    item_id: str,
    updates: UpdateKnowledgeItemParams,
) -> KnowledgeItem:
    """Update an existing org knowledge item."""
    require_role(user, "admin")
    existing = await get_knowledge_item(user, item_id)

    merged = existing.model_dump()
    for key, value in updates.model_dump(exclude_none=True).items():
        merged[key] = value
    merged["updated_at"] = _now_iso()

    item = KnowledgeItem.model_validate(merged)
    saved = storage.save_knowledge_item(
        user.org_id,
        item.id,
        item.model_dump(exclude={"id"}),
    )
    return KnowledgeItem.model_validate(saved)


async def review_knowledge_item(
    user: UserContext,
    item_id: str,
    status: ReviewableKnowledgeStatus,
    review_note: str | None = None,
    confidence: float | None = None,
) -> KnowledgeItem:
    """Review or reject a proposed knowledge item."""
    require_role(user, "admin")
    existing = await get_knowledge_item(user, item_id)

    merged = existing.model_dump()
    merged["status"] = status
    merged["reviewed_by"] = user.uid
    merged["review_note"] = review_note
    if confidence is not None:
        merged["confidence"] = confidence
    merged["updated_at"] = _now_iso()

    item = KnowledgeItem.model_validate(merged)
    saved = storage.save_knowledge_item(
        user.org_id,
        item.id,
        item.model_dump(exclude={"id"}),
    )
    return KnowledgeItem.model_validate(saved)


async def delete_knowledge_item(user: UserContext, item_id: str) -> bool:
    """Delete an org knowledge item."""
    require_role(user, "admin")
    return storage.delete_knowledge_item(user.org_id, item_id)
