"""Unit tests for org knowledge services."""

from unittest.mock import patch

import pytest

from services.auth import UserContext
from services.knowledge import (
    CreateKnowledgeItemParams,
    KnowledgeListFilters,
    UpdateKnowledgeItemParams,
    create_knowledge_item,
    get_knowledge_item,
    list_knowledge_items,
    review_knowledge_item,
    update_knowledge_item,
)


def make_user(role: str = "admin") -> UserContext:
    return UserContext(
        uid="user-123",
        email="user@example.com",
        org_id="org-123",
        org_name="Metricly",
        role=role,  # type: ignore[arg-type]
    )


class TestKnowledgeService:
    @pytest.mark.asyncio
    async def test_list_knowledge_items(self):
        with patch("services.knowledge.storage") as mock_storage:
            mock_storage.list_knowledge_items.return_value = [
                {
                    "id": "item-1",
                    "org_id": "org-123",
                    "type": "data_quirk",
                    "title": "Orders duplicate across shipments",
                    "content": "Deduplicate on order_id.",
                    "subjects": ["orders"],
                    "applies_to_metrics": ["order_count"],
                    "applies_to_dimensions": [],
                    "status": "reviewed",
                    "confidence": 0.9,
                    "source": "admin_authored",
                    "created_by": "user-123",
                    "reviewed_by": "user-123",
                    "review_note": None,
                    "created_at": "2026-03-09T08:00:00Z",
                    "updated_at": "2026-03-09T08:00:00Z",
                }
            ]

            items = await list_knowledge_items(
                make_user(),
                KnowledgeListFilters(type="data_quirk", status="reviewed", limit=10),
            )

            mock_storage.list_knowledge_items.assert_called_once_with(
                "org-123",
                item_type="data_quirk",
                status="reviewed",
                subject=None,
                limit=10,
            )
            assert len(items) == 1
            assert items[0].title == "Orders duplicate across shipments"

    @pytest.mark.asyncio
    async def test_get_missing_knowledge_item(self):
        with patch("services.knowledge.storage") as mock_storage:
            mock_storage.get_knowledge_item.return_value = None

            with pytest.raises(ValueError, match="not found"):
                await get_knowledge_item(make_user(), "missing")

    @pytest.mark.asyncio
    async def test_create_knowledge_item(self):
        with patch("services.knowledge.storage") as mock_storage:
            mock_storage.save_knowledge_item.side_effect = (
                lambda org_id, item_id, item: {"id": item_id, **item}
            )

            result = await create_knowledge_item(
                make_user(role="member"),
                CreateKnowledgeItemParams(
                    type="data_quirk",
                    title="Orders duplicate across shipments",
                    content="Deduplicate on order_id.",
                    subjects=["orders", "shipments"],
                    applies_to_metrics=["order_count"],
                    source="user_correction",
                ),
            )

            assert result.org_id == "org-123"
            assert result.status == "proposed"
            assert result.created_by == "user-123"
            mock_storage.save_knowledge_item.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_knowledge_item_requires_admin(self):
        with patch("services.knowledge.storage") as mock_storage:
            with pytest.raises(PermissionError, match="Requires admin role"):
                await update_knowledge_item(
                    make_user(role="member"),
                    "item-1",
                    UpdateKnowledgeItemParams(content="Updated content"),
                )

            mock_storage.get_knowledge_item.assert_not_called()

    @pytest.mark.asyncio
    async def test_review_knowledge_item(self):
        existing = {
            "id": "item-1",
            "org_id": "org-123",
            "type": "data_quirk",
            "title": "Orders duplicate across shipments",
            "content": "Deduplicate on order_id.",
            "subjects": ["orders"],
            "applies_to_metrics": ["order_count"],
            "applies_to_dimensions": [],
            "status": "proposed",
            "confidence": 0.5,
            "source": "user_correction",
            "created_by": "user-456",
            "reviewed_by": None,
            "review_note": None,
            "created_at": "2026-03-09T08:00:00Z",
            "updated_at": "2026-03-09T08:00:00Z",
        }

        with patch("services.knowledge.storage") as mock_storage:
            mock_storage.get_knowledge_item.return_value = existing
            mock_storage.save_knowledge_item.side_effect = (
                lambda org_id, item_id, item: {"id": item_id, **item}
            )

            result = await review_knowledge_item(
                make_user(),
                "item-1",
                status="reviewed",
                review_note="Confirmed with finance",
                confidence=0.95,
            )

            assert result.status == "reviewed"
            assert result.reviewed_by == "user-123"
            assert result.review_note == "Confirmed with finance"
            assert result.confidence == 0.95
