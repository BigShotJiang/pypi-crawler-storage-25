"""Unit tests for the context service module."""

from unittest.mock import patch

import pytest

from services.context import (
    UserPreferences,
    add_favorite,
    get_user_preferences,
    remove_favorite,
    update_user_preferences,
)


class TestUserPreferences:
    """Tests for UserPreferences model."""

    def test_default_preferences(self):
        prefs = UserPreferences()
        assert prefs.default_currency is None
        assert prefs.default_grain is None
        assert prefs.decimal_places is None
        assert prefs.favorite_metrics == []
        assert prefs.preferred_chart_type is None
        assert prefs.updated_at is None

    def test_preferences_with_values(self):
        prefs = UserPreferences(
            default_currency="USD",
            default_grain="month",
            decimal_places=2,
            favorite_metrics=["revenue", "orders"],
            preferred_chart_type="line_chart",
        )
        assert prefs.default_currency == "USD"
        assert prefs.default_grain == "month"
        assert prefs.decimal_places == 2
        assert prefs.favorite_metrics == ["revenue", "orders"]
        assert prefs.preferred_chart_type == "line_chart"


class TestGetUserPreferences:
    """Tests for get_user_preferences."""

    @pytest.mark.asyncio
    async def test_get_existing_preferences(self):
        mock_data = {
            "default_currency": "EUR",
            "default_grain": "week",
            "favorite_metrics": ["total_revenue"],
        }

        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = mock_data

            prefs = await get_user_preferences("user-123")

            mock_storage.get_user_preferences.assert_called_once_with("user-123")
            assert prefs.default_currency == "EUR"
            assert prefs.default_grain == "week"
            assert prefs.favorite_metrics == ["total_revenue"]

    @pytest.mark.asyncio
    async def test_get_nonexistent_preferences(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = None

            prefs = await get_user_preferences("new-user")

            assert prefs.default_currency is None
            assert prefs.favorite_metrics == []


class TestUpdateUserPreferences:
    """Tests for update_user_preferences."""

    @pytest.mark.asyncio
    async def test_update_currency(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = None
            mock_storage.save_user_preferences.return_value = {
                "default_currency": "GBP",
            }

            prefs = await update_user_preferences(
                "user-123", {"default_currency": "GBP"}
            )

            assert prefs.default_currency == "GBP"
            mock_storage.save_user_preferences.assert_called_once_with(
                "user-123", {"default_currency": "GBP", "favorite_metrics": []}
            )

    @pytest.mark.asyncio
    async def test_replace_favorites(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = {
                "favorite_metrics": ["total_revenue"]
            }
            mock_storage.save_user_preferences.return_value = {
                "favorite_metrics": ["orders"],
            }

            prefs = await update_user_preferences(
                "user-123", {"favorite_metrics": ["orders"]}
            )

            assert prefs.favorite_metrics == ["orders"]

    @pytest.mark.asyncio
    async def test_reject_unknown_fields(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = None

            with pytest.raises(ValueError, match="Unsupported preference fields"):
                await update_user_preferences(
                    "user-123", {"custom_instructions": "Always show YoY"}
                )

            mock_storage.save_user_preferences.assert_not_called()


class TestFavorites:
    """Tests for favorite helpers."""

    @pytest.mark.asyncio
    async def test_add_new_favorite(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = {"favorite_metrics": []}
            mock_storage.save_user_preferences.return_value = {
                "favorite_metrics": ["total_revenue"],
            }

            prefs = await add_favorite("user-123", "total_revenue")

            assert "total_revenue" in prefs.favorite_metrics

    @pytest.mark.asyncio
    async def test_add_duplicate_favorite(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = {
                "favorite_metrics": ["total_revenue"]
            }
            mock_storage.save_user_preferences.return_value = {
                "favorite_metrics": ["total_revenue"],
            }

            prefs = await add_favorite("user-123", "total_revenue")

            assert prefs.favorite_metrics.count("total_revenue") == 1

    @pytest.mark.asyncio
    async def test_remove_favorite(self):
        with patch("services.context.storage") as mock_storage:
            mock_storage.get_user_preferences.return_value = {
                "favorite_metrics": ["total_revenue", "orders"]
            }
            mock_storage.save_user_preferences.return_value = {
                "favorite_metrics": ["orders"],
            }

            prefs = await remove_favorite("user-123", "total_revenue")

            assert "total_revenue" not in prefs.favorite_metrics
