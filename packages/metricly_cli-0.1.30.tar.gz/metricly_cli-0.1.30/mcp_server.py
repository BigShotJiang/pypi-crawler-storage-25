"""Metricly MCP Server - Remote MCP server with Google OAuth authentication.

This server exposes Metricly's metric query and dashboard capabilities
via the Model Context Protocol (MCP), allowing Claude.ai and other
MCP-compatible clients to interact with your business metrics.

Usage:
    # Run the MCP server
    python mcp_server.py

    # Or with uvicorn for production
    uvicorn mcp_server:app --host 0.0.0.0 --port 8080

Configuration:
    Environment variables:
    - MCP_OAUTH_CLIENT_ID: Google OAuth Client ID
    - MCP_OAUTH_CLIENT_SECRET: Google OAuth Client Secret
    - MCP_SERVER_BASE_URL: Base URL for the MCP server

Claude.ai Integration:
    1. Deploy this server (e.g., to Cloud Run)
    2. In Claude.ai, go to Settings → Integrations → Add MCP Server
    3. Enter the server URL: https://your-server.com/mcp
    4. OAuth will authenticate you via Google
    5. Start asking questions about your metrics!
"""

import asyncio
import base64
import logging
import os
from datetime import datetime
from typing import Literal

from fastmcp import FastMCP, Context
from fastmcp.server.dependencies import CurrentContext
from fastmcp.server.middleware import Middleware, MiddlewareContext, CallNext
from fastmcp.server.auth.providers.google import GoogleProvider
from fastmcp.exceptions import ToolError
from pydantic import BaseModel, Field

from auth import _init_firebase
from settings import get_settings
from services.auth import (
    UserContext,
    get_user_by_email,
    get_user_for_org,
    get_user_orgs,
    switch_org,
)
import services.dashboards as dashboard_service
import services.queries as query_service
import services.context as context_service
import services.export as export_service
import services.knowledge as knowledge_service
import mcp_apps as apps_helpers

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)




# ============================================================================
# Authentication Middleware
# ============================================================================

# Global user for stdio mode (set by mcp_stdio.py before importing tools)
_stdio_user: UserContext | None = None


def set_stdio_user(user: UserContext):
    """Set user for stdio mode (bypasses OAuth)."""
    global _stdio_user
    _stdio_user = user


async def get_user_from_context(ctx: "Context") -> UserContext:
    """Get UserContext from MCP context, handling dict serialization."""
    user_data = await ctx.get_state("user")
    if user_data is None:
        raise ToolError("Authentication required: no user context")
    if isinstance(user_data, dict):
        return UserContext(**user_data)
    return user_data


def _read_pinned_org_id() -> str | None:
    """Read the ``?org=<id>`` query param from the inbound MCP HTTP request.

    Returns None when no HTTP request is in scope (e.g. stdio mode) or when
    the request URL does not set the ``org`` parameter. Any other failure is
    treated as "no pin" so the request falls through to the user's default.
    """
    try:
        from fastmcp.server.dependencies import get_http_request

        request = get_http_request()
    except (LookupError, RuntimeError):
        return None
    except Exception as e:
        logger.debug("pinned-org: get_http_request failed: %s", e)
        return None

    pinned = request.query_params.get("org") if request else None
    return pinned or None


class OrgContextMiddleware(Middleware):
    """Middleware to look up org context for authenticated OAuth user.

    Applies to both tool calls (``on_call_tool``) and resource reads
    (``on_read_resource``) so resource handlers get the same ``user``
    state as tool handlers.

    Supports the **MCP org-pinning** feature: when the inbound MCP URL
    carries ``?org=<org_id>``, the resolved ``UserContext`` is pinned to
    that organization for the lifetime of the request (membership is
    validated; non-members get a ``ToolError``). The user's stored
    ``defaultOrgId`` is NOT mutated. When the param is absent, the
    middleware falls back to the user's default org as before — in that
    mode the ``switch_organization`` tool continues to work normally.
    """

    async def _inject_user(self, context: MiddlewareContext) -> None:
        """Resolve the authenticated user and store on the fastmcp context."""
        # Check for stdio mode user (pre-authenticated via CLI)
        if _stdio_user is not None:
            await context.fastmcp_context.set_state("user", _stdio_user)
            await context.fastmcp_context.set_state("org_pinned", False)
            return

        # Get authenticated user info from OAuth (provided by GoogleProvider)
        if not context.fastmcp_context:
            raise ToolError("Authentication required: no MCP context")

        # Get user info from OAuth authentication state
        # GoogleProvider stores access token info with claims from Google
        try:
            from fastmcp.server.dependencies import get_access_token
            access_token = get_access_token()
        except LookupError as e:
            logger.error(f"OrgContextMiddleware: LookupError getting access token: {e}")
            raise ToolError("Authentication required: please authenticate via OAuth")

        if not access_token:
            logger.error("OrgContextMiddleware: access_token is None/falsy")
            raise ToolError("Authentication required: no access token")

        # PII-sensitive diagnostics go at DEBUG only — INFO fires on every tool
        # call and every resource read (on_read_resource hook), so the claims
        # dict would otherwise land in Cloud Logging on every request.
        logger.debug(
            "OrgContextMiddleware: token type=%s attrs=%s",
            type(access_token).__name__,
            [a for a in dir(access_token) if not a.startswith("_")],
        )

        email = None
        if hasattr(access_token, 'claims') and access_token.claims:
            logger.debug("OrgContextMiddleware: claim keys=%s", list(access_token.claims.keys()))
            email = access_token.claims.get("email")

        if not email:
            # Fallback: try to get email from resource_owner if available
            if hasattr(access_token, 'resource_owner') and access_token.resource_owner:
                email = access_token.resource_owner

        if not email:
            # Diagnostic dump on failure — never log the raw bearer token.
            logger.error("OrgContextMiddleware: No email found in token!")
            claims = getattr(access_token, 'claims', None)
            logger.error(f"  claim keys: {list(claims.keys()) if claims else 'N/A'}")
            logger.error(f"  resource_owner: {getattr(access_token, 'resource_owner', 'N/A')}")
            logger.error(f"  scopes: {getattr(access_token, 'scopes', 'N/A')}")
            logger.error(f"  token length: {len(getattr(access_token, 'token', '') or '')}")
            raise ToolError("OAuth authentication missing email - please re-authenticate")

        # Check whether the MCP URL pins an org via ?org=<id>.
        pinned_org_id = _read_pinned_org_id()

        try:
            if pinned_org_id:
                user = get_user_for_org(email, pinned_org_id)
            else:
                user = get_user_by_email(email)
        except ValueError as e:
            if pinned_org_id:
                # Pin is the problem — surface it clearly so the user knows
                # their MCP URL is wrong (org_id doesn't exist, wrong id,
                # or they're not a member).
                raise ToolError(
                    f"Pinned organization '{pinned_org_id}' from ?org= is "
                    f"not accessible: {e}"
                )
            raise ToolError(f"Access denied: {e}")

        # Store user context in state for tools/resources to access
        await context.fastmcp_context.set_state("user", user)
        await context.fastmcp_context.set_state("org_pinned", bool(pinned_org_id))

    async def on_call_tool(
        self,
        context: MiddlewareContext,
        call_next: CallNext,
    ):
        await self._inject_user(context)
        return await call_next(context)

    async def on_read_resource(
        self,
        context: MiddlewareContext,
        call_next: CallNext,
    ):
        # ui:// resources are the MCP Apps HTML shells — they're static assets
        # the host fetches independently of any authenticated user session.
        # They contain no user data, so skip the auth injection for them.
        params = getattr(context, "message", None)
        uri = getattr(params, "uri", None) if params else None
        if uri is None:
            uri = getattr(context, "params", None)
            uri = getattr(uri, "uri", None) if uri else None
        if uri is not None and str(uri).startswith("ui://"):
            return await call_next(context)

        await self._inject_user(context)
        return await call_next(context)




# ============================================================================
# MCP Server Setup
# ============================================================================

# Initialize Firebase before creating the server
_init_firebase()

# Get OAuth settings
settings = get_settings()

# Configure Google OAuth for Claude.ai integration
# OAuth is optional - if not configured, server runs without auth (dev mode)
auth_provider = None
if settings.mcp_oauth_client_id and settings.mcp_oauth_client_secret:
    from pydantic import AnyHttpUrl

    # base_url must include /mcp because OAuth routes (consent, authorize, token)
    # are created at app root, and this app is mounted at /api/mcp in main.py
    # So consent_url = base_url + "/consent" = "https://metricly.xyz/api/mcp/consent"
    base_url = f"{settings.mcp_server_base_url}/mcp"
    logger.info(f"Configuring Google OAuth for MCP server with base_url={base_url}")
    # Persistent JWT signing key is critical for production:
    # Without it, tokens become invalid when Cloud Run instances restart/scale
    if not settings.mcp_jwt_signing_key:
        logger.warning(
            "MCP_JWT_SIGNING_KEY not set! Tokens will be invalidated on server restart. "
            "Generate with: python -c \"import secrets; print(secrets.token_urlsafe(32))\""
        )

    # Persist OAuth client registrations + state in Firestore so they
    # survive Cloud Run redeploys, instance recycles, and scale-down.
    # FastMCP's default FileTreeStore lives on the container's local
    # filesystem and is wiped every time a new revision is deployed,
    # which forced Claude Desktop / Claude.ai users to disconnect and
    # re-OAuth after every backend deploy. Firestore is shared across
    # all instances and surviving across redeploys.
    #
    # Encrypted-at-rest with Fernet, key derived from the same
    # MCP_JWT_SIGNING_KEY secret that signs OAuth session tokens, so
    # operators rotate one secret to invalidate both. Decryption errors
    # are non-fatal (raise_on_decryption_error=False) — a key rotation
    # just causes affected clients to re-register, not a hard failure.
    from cryptography.fernet import Fernet
    from fastmcp.server.auth.jwt_issuer import derive_jwt_key
    from key_value.aio.stores.firestore import FirestoreStore
    from key_value.aio.wrappers.encryption.fernet import (
        FernetEncryptionWrapper,
    )

    firestore_oauth_store = FirestoreStore(
        # Hardcoded to match services/auth.py and services/render.py.
        # The Firestore emulator (when FIRESTORE_EMULATOR_HOST is set)
        # ignores the project value, so this is safe in local dev too.
        project="metricly-dev",
        default_collection="mcp_oauth_proxy",
    )
    _storage_encryption_key = derive_jwt_key(
        high_entropy_material=settings.mcp_jwt_signing_key,
        salt="fastmcp-storage-encryption-key",
    )
    oauth_client_storage = FernetEncryptionWrapper(
        key_value=firestore_oauth_store,
        fernet=Fernet(key=_storage_encryption_key),
        raise_on_decryption_error=False,
    )
    logger.info(
        "OAuth client storage: Firestore project=metricly-dev "
        "collection=mcp_oauth_proxy (survives redeploys)"
    )

    auth_provider = GoogleProvider(
        client_id=settings.mcp_oauth_client_id,
        client_secret=settings.mcp_oauth_client_secret,
        base_url=base_url,
        # Required scopes for user identification
        required_scopes=[
            "openid",
            "https://www.googleapis.com/auth/userinfo.email",
        ],
        # Allow Claude.ai's callback URL
        allowed_client_redirect_uris=[
            "https://claude.ai/api/mcp/auth_callback",
        ],
        # Persistent JWT signing key - critical for production
        # Without this, tokens become invalid when server restarts
        jwt_signing_key=settings.mcp_jwt_signing_key,
        # Persistent OAuth client registry (see above).
        client_storage=oauth_client_storage,
        # Skip FastMCP's consent screen - Google's consent is sufficient
        require_authorization_consent=False,
        # Don't forward RFC 8707 `resource` to Google — Google's OAuth 2.0 server
        # rejects unknown parameters with `invalid_request` at the consent step.
        forward_resource=False,
    )

    # Fix resource_url computation: FastMCP's _get_resource_url("/") adds trailing slash
    # but Claude.ai sends resource without trailing slash. Override to return base_url exactly.
    _original_get_resource_url = auth_provider._get_resource_url

    def _fixed_get_resource_url(path: str | None = None) -> AnyHttpUrl | None:
        # When path is "/" (root), return base_url without trailing slash
        if path == "/":
            return auth_provider.base_url
        return _original_get_resource_url(path)

    auth_provider._get_resource_url = _fixed_get_resource_url

    logger.info(f"OAuth base_url set to: {auth_provider.base_url}")
else:
    logger.warning("MCP OAuth not configured - running without authentication")

from mcp.types import Icon

from icon_data import METRICLY_ICON_DATA_URI

mcp = FastMCP(
    "Metricly",
    website_url="https://metricly.xyz",
    icons=[
        Icon(
            src=METRICLY_ICON_DATA_URI,
            mimeType="image/svg+xml",
        ),
    ],
    instructions="""You have access to Metricly, a business intelligence platform.

Use MCP resources for read-only state and tools for actions.

Core resources:
- metricly://context - saved user preferences and favorite metrics
- metricly://organizations - organizations available to the current user
- metricly://metrics and metricly://metrics/{metric_name} - metric catalog and definitions
- metricly://dimensions - groupable dimensions
- metricly://dashboards and metricly://dashboards/{dashboard_id} - dashboard list and full config
- metricly://knowledge and metricly://knowledge{?status,item_type,subject,limit} - shared org knowledge
- metricly://knowledge/{item_id} - single knowledge item
- metricly://manifest/status, metricly://manifest/models, metricly://manifest/models/{name}, metricly://manifest/export - semantic layer reads
- metricly://quick_metrics and metricly://quick_metrics/{metric_id} - user-defined derived metrics
- metricly://reports and metricly://reports/{schedule_id} - scheduled reports when enabled

Important: read metricly://context at the start of conversations to load preferences.
When you learn user preferences (currency, grain, etc.), use update_context to save them.

When answering questions about metrics:
1. Read metricly://metrics and metricly://dimensions to understand what is available.
2. Use query_metrics to fetch actual data.
3. Provide insights based on the results.

For dashboard management:
- Read metricly://dashboards to list dashboards.
- Read metricly://dashboards/{dashboard_id} before editing a dashboard.
- Use dashboard_edit for create, update, delete, duplicate, share, and set_controls.
- Use widget_edit for add, update, remove, reorder, move, copy, and swap.
- Use page_edit for create, delete, rename, and reorder.
- Use section_edit for create, delete, rename, and move.

Widget width (10-column grid):
- width=2: kpi default (5 per row)
- width=3: donut default (3 per row)
- width=5: heatmap default (2 per row)
- width=10: charts/tables default (full width)
If width not specified, type-appropriate default is applied automatically.

Widget time_scope (for non-time-series widgets):
- "range": Full dashboard date range (default)
- "latest": Current period only (may be incomplete)
- "latest_complete": Last complete period
Use latest_complete for KPIs showing "last month's revenue" alongside trend charts.

For dashboard structural changes, prefer atomic dispatch actions:
- widget_edit action=move/copy/swap for cross-section widget changes
- section_edit action=create/delete/rename/move for section changes
- page_edit action=create/delete/rename/reorder for page changes
- dashboard_edit action=update only for metadata and action=set_controls for controls

For data export:
- Use export_data to export query results or dashboard data
- Supports CSV and JSON formats
- Can save to file with output_path parameter

For rich rendering:
- Use render_dashboard or render_widget with format="app" for interactive MCP Apps UI.
- Use render_dashboard with format="pdf" or "png" and render_widget with format="png" for static export.

For scheduled reports:
- Use report_edit to set up or modify recurring email reports
- Supports dashboard reports (PDF/PNG) or query reports (CSV/JSON)
- Frequency options: daily, weekly (specify day_of_week 0-6), monthly (specify day_of_month 1-28)
- Read metricly://reports to see schedules and metricly://reports/{schedule_id} for details
- Use report_edit action=update with enabled=False to pause without deleting
- Use report_edit action=delete to remove a schedule

For user context (memory across sessions):
- Read metricly://context to load saved preferences and favorites
- Use update_context when you learn user preferences

For org knowledge (shared analytical memory):
Org knowledge is automatically retrieved and injected into query context.
When you query metrics, relevant knowledge items (data quirks, filter rules, playbooks)
are scored by relevance and included so you can give more accurate answers.

Reading:
- Read metricly://knowledge to browse shared knowledge
- Read metricly://knowledge{?status,item_type,subject,limit} to filter by review status, type, subject, or limit
- Read metricly://knowledge/{item_id} for a single item
- Knowledge is injected automatically during queries — no need to fetch manually

Writing — record knowledge when you learn something future queries should know:
- knowledge_edit action=record_correction: when a user corrects your answer.
  Captures the question, correction, and affected metrics/dimensions as a proposed data_quirk
- knowledge_edit action=create: when you discover a reusable pattern. Types:
  metric_definition, data_quirk, join_rule, filter_rule, playbook, business_term
  Tag with applies_to_metrics and applies_to_dimensions for accurate retrieval
- Admin-authored items (source="admin_authored") auto-promote to reviewed status

Reviewing (admin only):
- knowledge_edit action=review: approve, reject, or supersede proposed items
- Reviewed items get strong retrieval priority; rejected items are excluded

IMPORTANT: When a user says "that's wrong" or corrects your interpretation,
call knowledge_edit action=record_correction immediately — this is how the org learns.

For quick metrics (user-defined calculated metrics):
- Use quick_metric_edit action=create to define derived metrics using arithmetic expressions
  Example expression: "total_revenue / order_count"
- Read metricly://quick_metrics to see all quick metrics in your organization
- Read metricly://quick_metrics/{metric_id} to view a quick metric's definition
- Use quick_metric_edit action=update to modify name, expression, or description
- Use quick_metric_edit action=delete to remove a quick metric
- Query quick metrics with the qm: prefix: query_metrics(metrics=["qm:revenue_per_order"], ...)
- Expressions support: +, -, *, /, parentheses, and numeric constants
- All referenced metrics in expressions must exist in the manifest

For organization management:
- Read metricly://organizations to see all orgs you belong to
- Use switch_organization to change the active organization
- After switching, all subsequent tool calls operate on the new org

For error reporting:
- Use submit_error_report when a tool returns an unexpected error or incorrect result

For semantic layer management (requires admin role):
- Read metricly://manifest/models and metricly://manifest/models/{name} to explore models
- Use semantic_model_edit action=create/update/delete to manage models
- Use metric_edit action=create/update/delete to manage metrics
- Use metric_edit action=preview to test a metric before saving
- Use import_manifest to bulk import from dbt
- Read metricly://manifest/export to backup your semantic layer

Always specify date ranges when querying to get relevant data.""",
    auth=auth_provider,
)

# Add org context middleware (after OAuth authentication)
mcp.add_middleware(OrgContextMiddleware())

# Register MCP Resources (read-only views over dashboards, metrics, manifest, etc.)
# Resources don't count against the tool quota and let hosts browse Metricly state
# independently of tool calls. See backend/mcp_resources.py.
from mcp_resources import register_resources as _register_resources
_register_resources(mcp)

# Register read tools mirroring the metricly:// resource surface. Hosts that
# don't drive resource reads from the LLM (e.g. Claude.ai chat today) need
# tools to discover dashboards, metrics, etc. See backend/mcp_reads.py.
from mcp_reads import register_read_tools as _register_read_tools
_register_read_tools(mcp)

# Register dispatch tools (one per domain with a discriminated action union).
# See backend/mcp_dispatch.py. Replaces the per-CRUD tools below.
from mcp_dispatch import register_dispatch_tools as _register_dispatch_tools
_register_dispatch_tools(mcp)

# Register the ui:// embed HTML shell that render_dashboard / render_widget
# reference via @mcp.tool(app=AppConfig(resource_uri="ui://metricly/embed.html")).
from mcp_apps import register_embed_resource as _register_embed_resource
_register_embed_resource(mcp)


# ============================================================================
# Tool Parameter Models
# ============================================================================

class MCPQueryParams(BaseModel):
    """Parameters for querying metrics (MCP-compatible with string dates)."""
    metrics: list[str] = Field(description="List of metric names to query (e.g., ['total_revenue', 'order_count'])")
    dimensions: list[str] | None = Field(default=None, description="Dimensions to group by. Use qualified names from metricly://dimensions (e.g., ['customer__segment', 'order__region'])")
    grain: str | None = Field(default=None, description="Time granularity: 'day', 'week', 'month', 'quarter', or 'year'")
    start_date: str | None = Field(default=None, description="Start date in YYYY-MM-DD format")
    end_date: str | None = Field(default=None, description="End date in YYYY-MM-DD format")
    limit: int | None = Field(default=None, description="Maximum number of rows to return")
    order_by: str | None = Field(default=None, description="Column to sort by, append ' desc' for descending (e.g., 'total_revenue desc')")


# ============================================================================
# Organization Tools
# ============================================================================

@mcp.tool()
async def switch_organization(org_id: str, ctx: Context = CurrentContext()) -> dict:
    """Switch to a different organization.

    Changes the active organization for all subsequent tool calls. Browse
    available orgs via the ``metricly://organizations`` resource.

    Disabled when this MCP connection is pinned to a specific org via
    ``?org=<id>`` on the MCP URL — in that mode the URL is the source of
    truth and switching per-call would defeat the pinning. Remove the
    ``?org=`` parameter from the MCP URL to re-enable switching.

    Args:
        org_id: The organization ID to switch to
    """
    user = await get_user_from_context(ctx)

    # If this connection is pinned via ?org=<id>, switching would silently
    # conflict with the URL. Refuse loudly instead.
    if await ctx.get_state("org_pinned"):
        raise ToolError(
            "This MCP connection is pinned to a specific organization via "
            "the '?org=' URL parameter. switch_organization is disabled; "
            "remove '?org=' from the MCP URL to allow switching, or "
            "configure a separate MCP connection with '?org=" + org_id + "' "
            "for the target org."
        )

    try:
        new_user = switch_org(user.email, org_id)
        return {
            "success": True,
            "org_id": new_user.org_id,
            "org_name": new_user.org_name,
            "role": new_user.role,
        }
    except ValueError as e:
        raise ToolError(str(e))
    except Exception as e:
        logger.error(f"Failed to switch organization: {e}")
        raise ToolError(f"Failed to switch organization: {e}")


# ============================================================================
# Error Reporting Tools
# ============================================================================

@mcp.tool()
async def submit_error_report(
    command: str,
    error_message: str,
    expected: str | None = None,
    context_info: str | None = None,
    ctx: Context = CurrentContext(),
) -> dict:
    """Submit an error report to help improve Metricly.

    Use this when a tool returns an unexpected error or incorrect result.

    Args:
        command: The tool, resource, or action that failed (e.g. 'query_metrics', 'metricly://dashboards', 'dashboard_edit')
        error_message: The exact error message received
        expected: What you expected to happen (optional)
        context_info: What you were trying to achieve (optional)
    """
    import storage
    from datetime import datetime, UTC

    user = await get_user_from_context(ctx)

    report_data = {
        "command": command,
        "error_message": error_message,
        "expected": expected,
        "context": context_info,
        "org_id": user.org_id,
        "user_id": user.uid,
        "email": user.email,
        "source": "mcp",
        "status": "open",
        "created_at": datetime.now(UTC),
    }

    try:
        result = storage.create_error_report(report_data)
        return {"success": True, "id": result["id"], "message": "Error report submitted. Thank you for the feedback."}
    except Exception as e:
        logger.error(f"Failed to submit error report: {e}")
        raise ToolError(f"Failed to submit error report: {e}")


# ============================================================================
# MCP Tools
# ============================================================================

@mcp.tool()
async def query_metrics(
    params: MCPQueryParams,
    suggest_visualization: bool = False,
    ctx: Context = CurrentContext(),
) -> dict:
    """Execute a metric query and return the results.

    Use this to fetch actual data for one or more metrics. You can optionally:
    - Group by dimensions
    - Filter by time range
    - Limit results
    - Sort by a column
    - Get a visualization suggestion

    Example queries:
    - Monthly revenue: metrics=['total_revenue'], grain='month', start_date='2024-01-01'
    - Revenue by region: metrics=['total_revenue'], dimensions=['region']
    - Top 10 customers: metrics=['total_revenue'], dimensions=['customer_name'], order_by='total_revenue desc', limit=10

    Args:
        params: Query parameters (metrics, dimensions, grain, dates, etc.)
        suggest_visualization: If True, include a visualization recommendation
    """
    user = await get_user_from_context(ctx)

    try:
        # Parse string dates to date objects for the service layer
        start_date = None
        end_date = None
        if params.start_date:
            start_date = datetime.strptime(params.start_date, "%Y-%m-%d").date()
        if params.end_date:
            end_date = datetime.strptime(params.end_date, "%Y-%m-%d").date()

        # Create service layer QueryParams
        service_params = query_service.QueryParams(
            metrics=params.metrics,
            dimensions=params.dimensions,
            grain=params.grain,
            start_date=start_date,
            end_date=end_date,
            limit=params.limit,
            order_by=params.order_by,
        )

        # Execute query via service layer
        result = await query_service.query_metrics(
            org_id=user.org_id,
            params=service_params,
            include_visualization=suggest_visualization,
        )

        # Build response in same format as before
        response = {
            "success": True,
            "row_count": result.row_count,
            "columns": result.columns,
            "data": result.data,
        }

        # Include visualization suggestion if requested
        if result.visualization:
            response["visualization"] = {
                "widget_type": result.visualization.widget_type,
                "orientation": result.visualization.orientation,
                "format": result.visualization.format,
                "rationale": result.visualization.rationale,
            }

        return response

    except query_service.QueryError as e:
        # Return user-friendly error with hint
        error_response = {"error": e.message}
        if e.hint:
            error_response["hint"] = e.hint
        return error_response
    except ValueError as e:
        return {"error": f"Failed to initialize query engine: {e}"}
    except Exception as e:
        logger.error(f"Query failed: {e}")
        return {"error": str(e)}


# ============================================================================
# Atomic Page Operations
# ============================================================================


# ============================================================================
# Export Tools
# ============================================================================


@mcp.tool()
async def export_data(
    format: str = "csv",
    metrics: list[str] | None = None,
    dimensions: list[str] | None = None,
    grain: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    dashboard_id: str | None = None,
    output_path: str | None = None,
    ctx: Context = CurrentContext(),
) -> dict:
    """Export query results or dashboard data to CSV or JSON.

    You can either:
    - Export query results by specifying metrics, dimensions, etc.
    - Export all data from a dashboard by specifying dashboard_id

    Args:
        format: Output format - "csv" or "json" (default: csv)
        metrics: List of metric names to query (for query export)
        dimensions: Dimensions to group by (for query export)
        grain: Time granularity (for query export)
        start_date: Start date YYYY-MM-DD (for query export)
        end_date: End date YYYY-MM-DD (for query export)
        dashboard_id: Dashboard ID (for dashboard export, overrides query params)
        output_path: If provided, save to this file path

    Returns the data content (CSV or JSON) or file path if saved.
    """
    user = await get_user_from_context(ctx)

    if format not in ("csv", "json"):
        return {"error": f"Invalid format: {format}. Must be 'csv' or 'json'"}

    try:
        # Dashboard export takes precedence
        if dashboard_id:
            result = await export_service.export_dashboard_data(
                user,
                dashboard_id,
                format=format,
                output_path=output_path,
            )
        else:
            # Query export requires at least metrics
            if not metrics:
                return {"error": "Either dashboard_id or metrics must be provided"}

            # Parse dates
            parsed_start = None
            parsed_end = None
            if start_date:
                parsed_start = datetime.strptime(start_date, "%Y-%m-%d").date()
            if end_date:
                parsed_end = datetime.strptime(end_date, "%Y-%m-%d").date()

            params = query_service.QueryParams(
                metrics=metrics,
                dimensions=dimensions,
                grain=grain,
                start_date=parsed_start,
                end_date=parsed_end,
            )

            result = await export_service.export_query_data(
                user,
                params,
                format=format,
                output_path=output_path,
            )

        response = {
            "success": True,
            "format": result.format,
            "row_count": result.row_count,
            "columns": result.columns,
        }

        if result.saved_to:
            response["saved_to"] = result.saved_to
        else:
            response["content"] = result.content

        return response

    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Failed to export data: {e}"}


# ============================================================================
# Context Tools (User Preferences)
# ============================================================================



@mcp.tool()
async def update_context(
    updates: dict,
    ctx: Context = CurrentContext(),
) -> dict:
    """Update user preferences (merge, not replace).

    Use this when you learn user preferences during conversation.
    Only provided fields are updated; others remain unchanged.

    Args:
        updates: Fields to update. Supported fields:
            - default_currency: Preferred currency (e.g., "USD", "EUR")
            - default_grain: Preferred time grain (e.g., "month", "week")
            - decimal_places: Number of decimal places for values
            - preferred_chart_type: Preferred visualization type
            - favorite_metrics: List of favorite metric names

    Example: update_context({"default_currency": "EUR", "default_grain": "month"})
    """
    user = await get_user_from_context(ctx)

    try:
        prefs = await context_service.update_user_preferences(user.uid, updates)
        return {
            "success": True,
            "context": {
                "default_currency": prefs.default_currency,
                "default_grain": prefs.default_grain,
                "decimal_places": prefs.decimal_places,
                "preferred_chart_type": prefs.preferred_chart_type,
                "favorite_metrics": prefs.favorite_metrics,
                "updated_at": prefs.updated_at,
            },
        }
    except Exception as e:
        return {"error": f"Failed to update context: {e}"}


# ============================================================================
# Render Tools
# ============================================================================

from services import render_dashboard as render_dashboard_service
from services import render_widget as render_widget_service
from services import RenderError


def _dashboard_has_widget(dashboard, widget_id: str) -> bool:
    """Return whether a validated dashboard contains the requested widget."""
    for page in dashboard.pages:
        for section in page.sections:
            for widget in section.widgets:
                if widget.id == widget_id:
                    return True
    return False


@mcp.tool(app=apps_helpers.build_embed_app_config())
async def render_dashboard(
    dashboard_id: str,
    format: Literal["pdf", "png", "app"] = "app",
    page_id: str | None = None,
    width: int = 1200,
    height: int = 800,
    output_path: str | None = None,
    ctx: Context = CurrentContext(),
) -> dict:
    """Render a dashboard.

    Modes:
    - **app** (default): returns an interactive iframe payload that hosts
      with the MCP UI extension (Claude.ai, Claude Code, `fastmcp dev apps`)
      render inline. Hosts without UI support receive the JSON payload and
      can open ``embed_url`` in a browser tab.
    - **pdf** / **png**: headless-Chrome static export (legacy path).

    Args:
        dashboard_id: ID of the dashboard to render
        format: "app" for interactive iframe (default), "pdf"/"png" for
                static export.
        page_id: (pdf/png only) Optional page ID to render (default: all pages)
        width: (pdf/png only) Viewport width in pixels (default: 1200)
        height: (pdf/png only) Viewport height in pixels (default: 800)
        output_path: (pdf/png only) If provided, save to this file path instead
                     of returning base64.

    App mode is iframed by hosts that advertise the MCP UI extension.
    PDF/PNG modes require headless Chrome.
    """
    user = await get_user_from_context(ctx)

    try:
        # Validate user-level access before minting the bearer render token.
        await dashboard_service.get_dashboard(user, dashboard_id)
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        logger.error(f"Dashboard render access check failed: {e}")
        return {"error": f"Failed to verify dashboard access: {e}"}

    if format == "app":
        return await apps_helpers.build_dashboard_app_response(user, dashboard_id)

    try:
        # Run in thread pool to avoid blocking event loop
        # Chrome loads pages from the same server, which could deadlock otherwise
        result = await asyncio.to_thread(
            render_dashboard_service,
            org_id=user.org_id,
            dashboard_id=dashboard_id,
            page_id=page_id,
            format=format,
            width=width,
            height=height,
        )

        content_type = "application/pdf" if result.format == "pdf" else "image/png"

        # Save to file if output_path is provided
        if output_path:
            with open(output_path, "wb") as f:
                f.write(result.data)
            return {
                "success": True,
                "format": result.format,
                "content_type": content_type,
                "width": result.width,
                "height": result.height,
                "saved_to": output_path,
                "size_bytes": len(result.data),
            }

        return {
            "success": True,
            "format": result.format,
            "content_type": content_type,
            "width": result.width,
            "height": result.height,
            "data_base64": base64.b64encode(result.data).decode("utf-8"),
        }
    except RenderError as e:
        return {"error": str(e)}
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        logger.error(f"Dashboard render failed: {e}")
        return {"error": f"Failed to render dashboard: {e}"}


@mcp.tool(app=apps_helpers.build_embed_app_config())
async def render_widget(
    dashboard_id: str,
    widget_id: str,
    format: Literal["png", "app"] = "app",
    width: int = 600,
    height: int = 400,
    output_path: str | None = None,
    ctx: Context = CurrentContext(),
) -> dict:
    """Render a single widget.

    Modes:
    - **app** (default): interactive iframe payload; hosts with the MCP UI
      extension render it inline.
    - **png**: headless-Chrome static snapshot as base64 PNG.

    Args:
        dashboard_id: ID of the dashboard containing the widget
        widget_id: ID of the widget to render
        format: "app" for interactive iframe (default), "png" for static snapshot.
        width: (png only) Viewport width in pixels (default: 600)
        height: (png only) Viewport height in pixels (default: 400)
        output_path: (png only) Save to this file path instead of returning base64.

    App mode is iframed by hosts that advertise the MCP UI extension.
    PNG mode requires headless Chrome.
    """
    user = await get_user_from_context(ctx)

    try:
        # Validate user-level access before minting the bearer render token.
        dashboard = await dashboard_service.get_dashboard(user, dashboard_id)
        if not _dashboard_has_widget(dashboard, widget_id):
            return {"error": f"Widget '{widget_id}' not found in dashboard"}
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        logger.error(f"Widget render access check failed: {e}")
        return {"error": f"Failed to verify widget access: {e}"}

    if format == "app":
        return await apps_helpers.build_widget_app_response(user, dashboard_id, widget_id)

    try:
        # Run in thread pool to avoid blocking event loop
        # Chrome loads pages from the same server, which could deadlock otherwise
        result = await asyncio.to_thread(
            render_widget_service,
            org_id=user.org_id,
            dashboard_id=dashboard_id,
            widget_id=widget_id,
            width=width,
            height=height,
        )

        # Save to file if output_path is provided
        if output_path:
            with open(output_path, "wb") as f:
                f.write(result.data)
            return {
                "success": True,
                "format": "png",
                "content_type": "image/png",
                "width": result.width,
                "height": result.height,
                "saved_to": output_path,
                "size_bytes": len(result.data),
            }

        return {
            "success": True,
            "format": "png",
            "content_type": "image/png",
            "width": result.width,
            "height": result.height,
            "data_base64": base64.b64encode(result.data).decode("utf-8"),
        }
    except RenderError as e:
        return {"error": str(e)}
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        logger.error(f"Widget render failed: {e}")
        return {"error": f"Failed to render widget: {e}"}


# ============================================================================
# Manifest Tools
# ============================================================================

import services.manifest as manifest_service
import services.schedules as schedule_service
import services.quick_metrics as quick_metrics_service


@mcp.tool()
async def import_manifest(
    manifest_data: dict,
    ctx: Context = CurrentContext(),
) -> dict:
    """Import a semantic manifest using replace semantics.

    The manifest is the source of truth for the imported namespace. Items
    absent from the upload are hard-deleted. User-created (Metricly UI/MCP)
    metrics and models are never touched. A name collision with a
    user-created item is reported as a conflict; the user-created version
    wins and the upload entry is skipped.

    The upload is rejected if the uploaded manifest is internally
    inconsistent or would leave the org with unresolved metric→measure /
    metric→metric / quick-metric references.

    Requires admin or owner role.
    """
    user = await get_user_from_context(ctx)

    try:
        result = await manifest_service.import_manifest(user, manifest_data)
        return {
            "success": True,
            "imported_metrics": result.imported_metrics,
            "imported_models": result.imported_models,
            "deleted_metrics": result.deleted_metrics,
            "deleted_models": result.deleted_models,
            "skipped_metrics": result.skipped_metrics,
            "skipped_models": result.skipped_models,
            "conflicts": [
                {"name": c.name, "type": c.type, "reason": c.reason}
                for c in result.conflicts
            ],
            "orphaned": result.orphaned,
        }
    except PermissionError as e:
        return {"error": str(e)}
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Failed to import manifest: {e}"}



# ============================================================================
# Server Entry Point
# ============================================================================

# Create the ASGI app for deployment
# Use path="/" so MCP endpoint is at app root (becomes /api/mcp when mounted)
# The _get_resource_url override above ensures resource_url = base_url (no trailing slash)
app = mcp.http_app(path="/")

# Verify OAuth URLs are configured correctly
if auth_provider:
    expected_resource_url = f"{settings.mcp_server_base_url}/mcp"
    actual_resource_url = str(auth_provider._resource_url) if auth_provider._resource_url else None

    logger.info(f"OAuth URL verification:")
    logger.info(f"  base_url: {auth_provider.base_url}")
    logger.info(f"  resource_url: {actual_resource_url}")
    logger.info(f"  expected: {expected_resource_url}")

    if actual_resource_url != expected_resource_url:
        logger.error(
            f"RESOURCE URL MISMATCH! Expected '{expected_resource_url}' but got '{actual_resource_url}'. "
            "Claude.ai OAuth will fail!"
        )
    else:
        logger.info("OAuth URLs configured correctly for Claude.ai integration")


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", 8080))
    logger.info(f"Starting Metricly MCP Server on port {port}")

    # Run with HTTP transport for remote connections
    uvicorn.run(app, host="0.0.0.0", port=port)
