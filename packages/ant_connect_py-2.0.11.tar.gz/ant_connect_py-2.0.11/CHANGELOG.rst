This repo contains a centralized changelog file, CHANGELOG.rst, which is used to track 
changes to the project. The file is automatically updated in the pipeline with each 
release, and includes a list of changes, bug fixes, and new features for each version 
of the project.

The reason to use a centraized changelog file (found on the `centralized-changelog` 
branch) is to provide a single source of truth for all changes to the project and all 
future releases.

Of course, I would not be an epic developer if I would not consider your need to manually
add changes to the changelog for the coming release. List your changes below!

ADD TO THE CHANGELOG (every line from line 15 will be added to the changelog)
--------------------------------------------------------------------------------
- 