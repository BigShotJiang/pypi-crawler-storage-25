import argparse
import logging
from src.xml_parser import get_camera_parameters
from src.pipeline import AcademicHeightEstimator

def setup_logging():
    """Configures the root logger with standard output formatting."""
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

def main():
    setup_logging()
    logger = logging.getLogger(__name__)
    
    parser = argparse.ArgumentParser(description="Academic pipeline for wind turbine height estimation via satellite imagery.")
    
    parser.add_argument("--tiff", type=str, required=True, help="Path to input satellite imagery (.tif).")
    parser.add_argument("--xml", type=str, required=False, default="", help="Path to associated metadata (.xml).")
    parser.add_argument("--output_dir", type=str, default="output", help="Directory for output generation.")
    
    parser.add_argument("--gsd", type=float, default=0.8, help="Manual GSD fallback (meters/pixel).")
    
    parser.add_argument("--sun_ele", type=float, default=None, help="Manual override: Solar Elevation (degrees).")
    parser.add_argument("--sun_azi", type=float, default=None, help="Manual override: Solar Azimuth (degrees).")
    parser.add_argument("--sat_ele", type=float, default=None, help="Manual override: Satellite Elevation (degrees).")
    parser.add_argument("--sat_azi", type=float, default=None, help="Manual override: Satellite Azimuth (degrees).")

    parser.add_argument("--det_weight", type=str, default="weights/detect_v8.pt", help="Detection model weights path.")
    parser.add_argument("--pose_weight", type=str, default="weights/pose_v8.pt", help="Pose estimation model weights path.")
    
    args = parser.parse_args()

    # Geometry resolution sequence
    geom = get_camera_parameters(args.xml)
    if args.sun_ele is not None: geom['sun_ele'] = args.sun_ele
    if args.sun_azi is not None: geom['sun_azi'] = args.sun_azi
    if args.sat_ele is not None: geom['sat_ele'] = args.sat_ele
    if args.sat_azi is not None: geom['sat_azi'] = args.sat_azi

    logger.info("Commencing processing sequence for input: %s", args.tiff)
    
    engine = AcademicHeightEstimator(args.det_weight, args.pose_weight)
    engine.process_image(args.tiff, geom, args.output_dir, fallback_gsd=args.gsd)

if __name__ == "__main__":
    main()