import xml.etree.ElementTree as ET
import logging
from typing import Dict

logger = logging.getLogger(__name__)

def get_camera_parameters(xml_path: str) -> Dict[str, float]:
    """
    Parses satellite metadata XML files to extract illumination and viewing geometries.
    Implements fuzzy matching, Zenith conversions, and GF-2 telemetry anomaly interception.
    """
    params = {"sun_ele": 45.0, "sun_azi": 180.0, "sat_ele": 90.0, "sat_azi": 0.0}
    
    if not xml_path:
        logger.warning("Metadata XML not provided. Defaulting to nadir viewing geometry.")
        return params

    try:
        tree = ET.parse(xml_path)
        for elem in tree.iter():
            if elem.tag is None or elem.text is None: continue
            
            tag = elem.tag.lower()
            text = elem.text.strip()
            if not text: continue
            
            try:
                val = float(text)
                
                # 光照几何参数解析
                if 'sunelevation' in tag or 'solarelevation' in tag: 
                    params['sun_ele'] = val
                elif 'sunzenith' in tag or 'solarzenith' in tag: 
                    params['sun_ele'] = 90.0 - val  # 标准的天顶角转高度角
                elif 'sunazimuth' in tag or 'solarazimuth' in tag: 
                    params['sun_azi'] = val
                    
                # 卫星观测几何参数解析
                elif 'satelliteelevation' in tag or 'viewingelevation' in tag: 
                    params['sat_ele'] = val
                elif 'satellitezenith' in tag or 'viewingzenith' in tag:
                    # 🚀 异常拦截器：如果“天顶角”的值大于 45 度，它极大概率是卫星运营商错误写入的“高度角”（GF-2 常见异常）。
                    if val > 45.0:
                        params['sat_ele'] = val
                        logger.warning(f"Telemetry anomaly detected: SatelliteZenith ({val}°) interpreted directly as Elevation.")
                    else:
                        params['sat_ele'] = 90.0 - val
                elif 'satelliteazimuth' in tag or 'viewingazimuth' in tag: 
                    params['sat_azi'] = val
                    
            except ValueError:
                pass
                
        logger.info(f"Geometry extracted - Sun Ele: {params['sun_ele']:.2f}°, Sat Ele: {params['sat_ele']:.2f}°")
        return params
        
    except Exception as e:
        logger.error(f"Failed to parse XML: {e}. Initiating fallback geometric parameters.")
        return params