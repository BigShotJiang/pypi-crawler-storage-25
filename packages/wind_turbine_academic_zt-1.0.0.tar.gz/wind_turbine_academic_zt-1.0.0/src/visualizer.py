import cv2
import numpy as np
from pathlib import Path

def draw_and_save_measurement(img_array: np.ndarray, kpts: np.ndarray, height_m: float, turbine_id: int, output_dir: str) -> None:
    """
    Renders topological measurements and metadata onto the image array.
    Outputs are saved to the specified directory for verification purposes.
    """
    vis_dir = Path(output_dir) / "visualizations"
    vis_dir.mkdir(parents=True, exist_ok=True)
    
    # Convert grayscale array to BGR space for color annotation
    img_bgr = cv2.cvtColor(img_array, cv2.COLOR_GRAY2BGR)
    
    try:
        x1, y1 = int(kpts[0][0]), int(kpts[0][1])  # Base point
        x2, y2 = int(kpts[1][0]), int(kpts[1][1])  # Shadow apex
        
        # Render geometric distance vector
        cv2.line(img_bgr, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.circle(img_bgr, (x1, y1), 5, (255, 0, 0), -1)   
        cv2.circle(img_bgr, (x2, y2), 5, (0, 255, 255), -1) 
        
        # Render data overlay
        text = f"ID:{turbine_id} | H:{height_m}m"
        (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_DUPLEX, 0.7, 2)
        cv2.rectangle(img_bgr, (8, 8), (12 + tw, 18 + th), (0, 0, 0), -1)
        cv2.putText(img_bgr, text, (10, 15 + th), cv2.FONT_HERSHEY_DUPLEX, 0.7, (0, 255, 0), 2)
        
        save_path = vis_dir / f"turbine_{turbine_id:03d}.jpg"
        cv2.imwrite(str(save_path), img_bgr)
    except Exception as e:
        # Suppress rendering failures to maintain pipeline continuity
        pass