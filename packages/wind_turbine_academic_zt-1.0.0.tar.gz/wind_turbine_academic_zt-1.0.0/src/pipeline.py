import math
import logging
from typing import List, Dict
import rasterio
import numpy as np
import pandas as pd
import cv2
from ultralytics import YOLO
from pathlib import Path

from src.geometry import calculate_physical_height
from src.visualizer import draw_and_save_measurement

logger = logging.getLogger(__name__)

class AcademicHeightEstimator:
    def __init__(self, det_path: str, pose_path: str, win_size: int = 1024, stride: int = 800, conf: float = 0.35):
        logger.info("Initializing YOLOv8 dual-modal inference engines.")
        self.det_model = YOLO(det_path)
        self.pose_model = YOLO(pose_path)
        self.win_size = win_size
        self.stride = stride
        self.conf = conf

    def _apply_clahe(self, img: np.ndarray) -> np.ndarray:
        """Applies Contrast Limited Adaptive Histogram Equalization."""
        if not (img > 0).any(): return img
        norm = np.zeros_like(img, dtype=np.uint8)
        mask = img > 0
        min_v, max_v = img[mask].min(), img[mask].max()
        if max_v <= min_v: return img
        norm[mask] = ((img[mask] - min_v) / (max_v - min_v) * 255).astype(np.uint8)
        return cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(norm)

    def _apply_local_stretch(self, img: np.ndarray) -> np.ndarray:
        """Performs radiometric normalization using 2nd-98th percentile stretching."""
        valid_px = img[img > 0]
        if len(valid_px) < 100: return np.zeros_like(img, dtype=np.uint8)
        p_min, p_max = np.percentile(valid_px, (2, 98))
        if p_max <= p_min: return np.zeros_like(img, dtype=np.uint8)
        stretched = (img.astype(np.float32) - p_min) / (p_max - p_min) * 255.0
        stretched[img == 0] = 0
        return np.clip(stretched, 0, 255).astype(np.uint8)

    def _center_distance_nms(self, detections: List[Dict], threshold: float = 150.0) -> List[Dict]:
        """Spatial deduplication algorithm to resolve overlapping sliding windows."""
        detections.sort(key=lambda d: d["conf"], reverse=True)
        keep = []
        for det in detections:
            overlap = False
            for f in keep:
                dist = math.hypot(det["center"][0] - f["center"][0], det["center"][1] - f["center"][1])
                if dist < threshold:
                    overlap = True
                    break
            if not overlap:
                keep.append(det)
        return keep

    def process_image(self, tiff_path: str, geom: Dict[str, float], output_dir: str, fallback_gsd: float = 0.8) -> None:
        raw_detections = []
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        csv_path = out_path / "final_heights.csv"

        with rasterio.open(tiff_path) as src:
            res_val = abs(src.res[0])
            current_gsd = res_val if res_val > 0.001 else fallback_gsd
            gsd_source = "Metadata" if res_val > 0.001 else "Manual Override"
            logger.info(f"Spatial resolution configured: {current_gsd:.3f} m/px ({gsd_source}).")

            # Phase 1: Object Detection via Sliding Window
            logger.info("Initiating Phase 1: Large-scale sliding window detection.")
            for y in range(0, src.height, self.stride):
                for x in range(0, src.width, self.stride):
                    win = rasterio.windows.Window(x, y, self.win_size, self.win_size)
                    try:
                        clip = src.read(1, window=win, boundless=True, fill_value=0)
                    except Exception:
                        continue
                        
                    if not (clip > 0).any(): continue
                    
                    img_det = np.stack([self._apply_clahe(clip)]*3, axis=-1)
                    preds = self.det_model(img_det, verbose=False, conf=self.conf)
                    
                    for r in preds:
                        for b in r.boxes.data.cpu().numpy():
                            gx1, gy1 = int(x + b[0]), int(y + b[1])
                            gx2, gy2 = int(x + b[2]), int(y + b[3])
                            raw_detections.append({
                                "center": ((gx1+gx2)/2, (gy1+gy2)/2), 
                                "conf": b[4]
                            })

            final_targets = self._center_distance_nms(raw_detections)
            logger.info(f"Phase 1 completed. Detected {len(final_targets)} unique target instances.")

            # Phase 2: Pose Estimation & Geometric Inversion
            logger.info("Initiating Phase 2: Pose estimation and geometric inversion.")
            results = []
            for idx, target in enumerate(final_targets, 1):
                cx, cy = target["center"]
                p_win = rasterio.windows.Window(int(cx-320), int(cy-320), 640, 640)
                try: 
                    p_clip = src.read(1, window=p_win, boundless=True, fill_value=0)
                except Exception: 
                    continue
                
                img_p_gray = self._apply_local_stretch(p_clip)
                p_preds = self.pose_model(np.stack([img_p_gray]*3, axis=-1), verbose=False, conf=0.1)
                
                for pr in p_preds:
                    if pr.keypoints is not None and len(pr.keypoints.xy) > 0 and len(pr.keypoints.xy[0]) >= 2:
                        kpts = pr.keypoints.xy[0].cpu().numpy()
                        dist_px = math.hypot(kpts[1][0]-kpts[0][0], kpts[1][1]-kpts[0][1])
                        
                        h = calculate_physical_height(dist_px * current_gsd, geom)
                        
                        try:
                            lon, lat = src.xy(p_win.row_off + kpts[0][1], p_win.col_off + kpts[0][0])
                        except rasterio.errors.RasterioIOError:
                            lon, lat = 0.0, 0.0
                            
                        results.append({"Turbine_ID": idx, "Longitude": lon, "Latitude": lat, "Height_m": h})
                        draw_and_save_measurement(img_p_gray, kpts, h, idx, str(out_path))
                        break
            
            if results:
                pd.DataFrame(results).to_csv(str(csv_path), index=False)
                logger.info(f"Pipeline execution completed. Processed {len(results)} instances. Results saved to {csv_path}.")
            else:
                logger.warning("Pipeline executed, but no valid heights were successfully extracted.")