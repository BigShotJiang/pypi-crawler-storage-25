import math
from typing import Dict

def calculate_physical_height(shadow_length_m: float, geom: Dict[str, float]) -> float:
    """
    Computes the true physical height of a target based on its shadow length and spatial projection geometry.
    
    This function implements a rigorous photogrammetric inversion model, accounting for the 
    azimuthal divergence between solar illumination and satellite observation vectors.

    Args:
        shadow_length_m (float): The measured shadow length in meters.
        geom (Dict[str, float]): A dictionary containing angular parameters (in degrees):
            - 'sun_ele': Solar elevation angle.
            - 'sat_ele': Satellite viewing elevation angle.
            - 'sun_azi': Solar azimuth angle.
            - 'sat_azi': Satellite viewing azimuth angle.

    Returns:
        float: The estimated physical height of the object in meters.
    """
    alpha = math.radians(geom['sun_ele'])
    beta = math.radians(geom['sat_ele'])
    gamma = math.radians(geom['sun_azi'])
    delta = math.radians(geom['sat_azi'])
    
    azi_diff = abs(geom['sun_azi'] - geom['sat_azi'])
    eps = 1e-9  # Epsilon for numerical stability
    
    # Case 1: Direct shadow exposure (satellite is positioned behind the sun)
    if azi_diff > 180:
        h = shadow_length_m * math.tan(alpha)
        
    # Case 2: Collinear occlusion (azimuthal angles are approximately equal)
    elif azi_diff < 0.1:
        numerator = math.tan(alpha) * math.tan(beta)
        denominator = math.tan(beta) - math.tan(alpha) + eps
        h = shadow_length_m * (numerator / denominator)
        
    # Case 3: Generalized 3D spatial projection
    else:
        numerator = shadow_length_m * math.tan(alpha) * math.tan(beta) * math.cos(gamma)
        denominator = math.tan(beta) * math.cos(gamma) - math.cos(delta) * math.tan(alpha) + eps
        h = abs(numerator / denominator)
        
    return round(h, 2)