# 🌪️ Academic Wind Turbine Height Estimator

A rigorous photogrammetric deep learning pipeline designed to automatically detect wind turbines and invert their physical 3D heights from single-view optical satellite imagery.

## 🌟 Core Architectural Breakthroughs

Developed for metrology-grade accuracy, this architecture resolves standard optical illusion issues prevalent in conventional remote sensing estimations.

- **Rigorous Geometric Inversion (Case 1-3):** Implements a comprehensive spatial projection model. Computes true physical height by evaluating the azimuthal divergence between solar illumination and satellite observation vectors, effectively resolving direct shadow and collinear occlusion scenarios.
- **Dynamic GSD Resolution:** Features an **Auto-Sense + Manual Fallback** mechanism. Extracts Ground Sample Distance directly from GeoTIFF spatial metadata (`rasterio.res`), with CLI overrides for non-georeferenced imagery.
- **Robust Inference Pipeline:** Deploys a custom Center-Distance NMS to suppress overlapping bounding boxes on rotary blades, coupled with an Exception Suppression module to maintain pipeline continuity during keypoint occlusion.

## 📄 Metadata Requirements (XML Parsing)

The system features a generalized XML parser designed to be compatible with various satellite platforms (e.g., Gaofen, Ziyuan). To utilize the automatic geometry extraction, your metadata `.xml` file must contain tags matching any of the following conventions (case-insensitive):

| Geometric Parameter | Accepted XML Tag Names (Fuzzy Matching) |
| :--- | :--- |
| **Solar Elevation** | `<SunElevation>`, `<SolarElevation>` |
| **Solar Azimuth** | `<SunAzimuth>`, `<SolarAzimuth>` |
| **Satellite Elevation** | `<SatelliteElevation>`, `<ViewingElevation>` |
| **Satellite Azimuth** | `<SatelliteAzimuth>`, `<ViewingAzimuth>` |

*If these tags are entirely missing, the system will execute with a safe default (Nadir viewing) unless manually overridden via CLI.*

## 🚀 Quick Start & CLI Execution

### 1. Environment Initialization
```bash
pip install -r requirements.txt
2. Execution Protocols
Execute the inference pipeline via CLI based on your spatial data availability.

Option A: Standard GeoTIFF (Auto-GSD & Auto-Geometry)

Bash
python main.py --tiff data/demo.tif --xml data/demo.xml
Option B: Non-Georeferenced Imagery (Manual GSD Injection)

Bash
python main.py --tiff data/demo.tif --xml data/demo.xml --gsd 0.8
Option C: Missing Metadata (Full Geometric Override)
Note: Use the following protocol for explicit parameter injection if the XML lacks the required tags.

Bash
python main.py --tiff data/demo.tif --xml data/demo.xml \
  --sun_ele 60.5 --sun_azi 120.0 \
  --sat_ele 85.0 --sat_azi 0.0 \
  --gsd 0.8
📊 Output Artifacts
Upon successful execution, verified artifacts are generated in the output/ directory:

final_heights.csv: Contains extracted Geocoordinates (Lon/Lat) and Calculated Physical Height (m).

visualizations/: Radiometrically normalized image chips featuring topological measurement vectors for academic verification.