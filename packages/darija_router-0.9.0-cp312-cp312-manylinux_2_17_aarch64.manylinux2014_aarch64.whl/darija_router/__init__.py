from .darija_router import *

__doc__ = darija_router.__doc__
if hasattr(darija_router, "__all__"):
    __all__ = darija_router.__all__