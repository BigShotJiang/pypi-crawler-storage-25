# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import threading
import warnings

from .load_dataset import get_data


# Hand-curated common-name aliases. Keyed by lowercase / underscored
# variant; values are canonical codes from cancer-type-registry.csv.
# The registry CSV is the source-of-truth for valid codes and their
# display names — see :data:`CANCER_TYPE_NAMES` below.
CANCER_TYPE_ALIASES = {
    "prostate": "PRAD", "breast": "BRCA", "lung_adeno": "LUAD",
    "lung_squamous": "LUSC", "melanoma": "SKCM", "skin": "SKCM",
    "colon": "COAD", "colorectal": "COAD", "rectal": "READ",
    "pancreatic": "PAAD", "pancreas": "PAAD", "liver": "LIHC",
    "kidney_clear": "KIRC", "kidney_papillary": "KIRP",
    "kidney_chromophobe": "KICH", "kidney": "KIRC", "ovarian": "OV",
    "ovary": "OV", "cervical": "CESC", "cervix": "CESC",
    "bladder": "BLCA", "stomach": "STAD", "gastric": "STAD",
    "glioblastoma": "GBM", "gbm": "GBM", "head_neck": "HNSC",
    "hnscc": "HNSC", "thyroid": "THCA", "endometrial": "UCEC",
    "uterine": "UCEC", "testicular": "TGCT", "testis": "TGCT",
    "sarcoma": "SARC", "adrenocortical": "ACC", "adrenal": "ACC",
    "cholangiocarcinoma": "CHOL", "bile_duct": "CHOL", "dlbcl": "DLBC",
    "lymphoma": "DLBC", "esophageal": "ESCA", "esophagus": "ESCA",
    "aml": "LAML", "leukemia": "LAML", "low_grade_glioma": "LGG",
    "lgg": "LGG", "glioma": "LGG", "mesothelioma": "MESO",
    "pheochromocytoma": "PCPG", "paraganglioma": "PCPG",
    "thymoma": "THYM", "uterine_carcinosarcoma": "UCS",
    "uveal_melanoma": "UVM",
}


class _CancerTypeNamesView:
    """Read-only ``{code: display_name}`` view backed by the registry CSV.

    Trufflepig and downstream consumers treat ``CANCER_TYPE_NAMES`` as
    a dict (``.get(code)``, ``code in CANCER_TYPE_NAMES``, iteration).
    Loading from the CSV at first access keeps the dict in lock-step
    with the registry — adding a new subtype row to
    ``cancer-type-registry.csv`` automatically extends the dict
    without a code change here.

    The loaded mapping is cached on the instance after the first
    access; downstream callers in trufflepig hit this in tight loops
    (``resolve_cancer_type`` per sample × per candidate). A second
    cached map (``_name_to_code``) holds the lowercased reverse
    lookup used by display-name resolution. Both are protected by a
    ``threading.Lock`` so concurrent first-call paths don't both pay
    the build cost.

    Call ``clear_cache()`` (or the module-level
    :func:`_clear_caches`) to drop the caches — tests that monkey-
    patch ``get_data`` to swap fixture registries need this.
    """

    def __init__(self):
        self._cache: dict | None = None
        self._name_to_code_cache: dict | None = None
        self._lock = threading.Lock()

    def _load(self):
        if self._cache is None:
            with self._lock:
                if self._cache is None:
                    df = get_data("cancer-type-registry")
                    # DataFrame-level filter: drop NaN and
                    # empty/whitespace names before building the dict
                    # so missing values never reach ``str(NaN) == "nan"``.
                    df = df[df["name"].notna()]
                    df = df[df["name"].astype(str).str.strip().ne("")]
                    self._cache = dict(
                        zip(df["code"].astype(str), df["name"].astype(str))
                    )
        return self._cache

    def _name_to_code(self):
        """Lowercased ``display_name → code`` for case-insensitive
        display-name resolution. Cached alongside ``_cache``."""
        if self._name_to_code_cache is None:
            with self._lock:
                if self._name_to_code_cache is None:
                    self._name_to_code_cache = {
                        name.lower(): code for code, name in self._load().items()
                    }
        return self._name_to_code_cache

    def clear_cache(self):
        """Drop the cached dicts. Force a re-read on next access."""
        with self._lock:
            self._cache = None
            self._name_to_code_cache = None

    def __getitem__(self, key):
        return self._load()[key]

    def get(self, key, default=None):
        return self._load().get(key, default)

    def __contains__(self, key):
        return key in self._load()

    def __iter__(self):
        return iter(self._load())

    def __len__(self):
        return len(self._load())

    def keys(self):
        return self._load().keys()

    def values(self):
        return self._load().values()

    def items(self):
        return self._load().items()

    def __repr__(self):
        return f"_CancerTypeNamesView({len(self._load())} codes)"


# Registry-backed view of cancer code → display name. Reads
# ``cancer-type-registry.csv`` lazily on first access and caches the
# resolved mapping so adding a new subtype row automatically broadens
# ``resolve_cancer_type`` and trufflepig's label lookups without
# repeated CSV-parse / iterrows cost on the hot path.
CANCER_TYPE_NAMES = _CancerTypeNamesView()


def _clear_caches():
    """Reset every registry-backed cache in this module.

    Test hook for swapping the registry CSV via a monkey-patched
    ``get_data``; not part of the public surface.
    """
    CANCER_TYPE_NAMES.clear_cache()


def resolve_cancer_type(cancer_type):
    """Resolve a cancer type name or alias to a registry code.

    Accepts:
    - canonical registry codes (``"PRAD"``, ``"SARC_DDLPS"``,
      ``"LAML_APL"``);
    - hand-curated common-name aliases (``"prostate"``, ``"melanoma"``);
    - the registry display name (``"Prostate Adenocarcinoma"``),
      case-insensitive.

    Returns the registry code, ``None`` if ``cancer_type`` is ``None``,
    or raises ``ValueError`` for an unknown input.
    """
    if cancer_type is None:
        return None
    raw = str(cancer_type).strip()
    if not raw:
        raise ValueError("Empty cancer type")

    alias_key = raw.lower().replace(" ", "_").replace("-", "_")
    if alias_key in CANCER_TYPE_ALIASES:
        return CANCER_TYPE_ALIASES[alias_key]

    registry = CANCER_TYPE_NAMES  # registry-backed view
    if raw in registry:
        return raw
    upper = raw.upper()
    if upper in registry:
        return upper

    # Display-name lookup (e.g. "Prostate Adenocarcinoma" → "PRAD").
    # The reverse map is cached on the view so this is O(1).
    name_to_code = registry._name_to_code()
    if raw.lower() in name_to_code:
        return name_to_code[raw.lower()]

    raise ValueError(
        f"Unknown cancer type {cancer_type!r}. "
        f"Valid registry codes: {sorted(registry.keys())}. "
        f"Common-name aliases: {sorted(CANCER_TYPE_ALIASES.keys())}."
    )


# ---------- Therapy target registry ----------

_THERAPY_REGISTRY = {
    "ADC": ["ADC-trials", "ADC-approved"],
    "ADC-trials": ["ADC-trials"],
    "ADC-approved": ["ADC-approved"],
    "TCR-T": ["TCR-T-trials", "TCR-T-approved"],
    "TCR-T-trials": ["TCR-T-trials"],
    "TCR-T-approved": ["TCR-T-approved"],
    "CAR-T": ["CAR-T-approved"],
    "CAR-T-approved": ["CAR-T-approved"],
    "bispecific-antibodies": ["bispecific-antibodies-approved"],
    "bispecific-antibodies-approved": ["bispecific-antibodies-approved"],
    "radioligand": ["radioligand-targets"],
    "multispecific-TCE": ["multispecific-tcell-engager-trials"],
}


# ---------- Low-level field extractors ----------


def get_field_from_gene_set(
    gene_set_name,
    candidate_columns,
    try_lower_case=True,
    try_upper_case=True,
    try_no_underscore=True,
    try_plural=True,
):
    if try_plural:
        candidate_columns = candidate_columns + [c + "s" for c in candidate_columns]
    if try_no_underscore:
        candidate_columns = candidate_columns + [
            c.replace("_", "") for c in candidate_columns
        ]
    if try_lower_case:
        candidate_columns = candidate_columns + [c.lower() for c in candidate_columns]
    if try_upper_case:
        candidate_columns = candidate_columns + [c.upper() for c in candidate_columns]

    df = get_data(gene_set_name)
    result = set()
    for column in candidate_columns:
        if column in df.columns:
            for x in df[column]:
                if type(x) is str:
                    result.update([xi.strip() for xi in x.split(";")])
    return result


def get_target_gene_name_set(
    name,
    candidate_symbol_columns=[
        "Tumor_Target_Symbol",
        "Symbol",
        "Gene_Name",
    ],
):
    return get_field_from_gene_set(name, candidate_symbol_columns)


def get_target_gene_id_set(
    name,
    candidate_id_columns=[
        "Tumor_Target_Ensembl_Gene_ID",
        "Tumor_Target_Ensembl_GeneID",
        "Tumor_Target_Gene_ID",
        "Tumor_Target_GeneID",
        "Target_Ensembl_Gene_ID",
        "Target_Ensembl_GeneID",
        "Target_Gene_ID",
        "Target_GeneID",
        "Ensembl_Gene_ID",
        "Ensembl_GeneID",
        "Gene_ID",
    ],
):
    return get_field_from_gene_set(name, candidate_id_columns)


def get_target_gene_id_to_name(name):
    """Extract paired {Ensembl_Gene_ID: Symbol} dict from a therapy dataset.

    Handles semicolon-separated multi-target entries by positional pairing.
    """
    df = get_data(name)

    sym_candidates = [
        "Tumor_Target_Symbol",
        "Tumor_Target_Symbols",
        "Symbol",
        "Symbols",
        "Gene_Name",
    ]
    id_candidates = [
        "Tumor_Target_Ensembl_Gene_ID",
        "Tumor_Target_Ensembl_Gene_IDs",
        "Ensembl_Gene_ID",
        "Ensembl_Gene_IDs",
        "Ensembl_GeneIDs",
        "Gene_ID",
    ]

    sym_col = next((c for c in sym_candidates if c in df.columns), None)
    id_col = next((c for c in id_candidates if c in df.columns), None)

    if sym_col is None or id_col is None:
        # Fall back to separate extraction
        names = get_target_gene_name_set(name)
        ids = get_target_gene_id_set(name)
        return {gid: gid for gid in ids} if ids else {n: n for n in names}

    result = {}
    for _, row in df.iterrows():
        syms_raw = str(row[sym_col]).strip() if row[sym_col] is not None else ""
        ids_raw = str(row[id_col]).strip() if row[id_col] is not None else ""
        if not syms_raw or syms_raw.lower() in ("nan", "none"):
            continue
        syms = [s.strip() for s in syms_raw.split(";") if s.strip()]
        ids = [
            i.strip()
            for i in ids_raw.split(";")
            if i.strip() and i.strip().startswith("ENSG")
        ]
        for i, sym in enumerate(syms):
            if i < len(ids):
                result[ids[i]] = sym
    return result


# ---------- Generic therapy target accessors ----------


def therapy_target_gene_names(therapy):
    """Gene symbols targeted by a therapy type.

    Parameters
    ----------
    therapy : str
        Key from _THERAPY_REGISTRY (e.g. "ADC", "TCR-T", "CAR-T",
        "bispecific-antibodies", "radioligand", "multispecific-TCE").
    """
    if therapy not in _THERAPY_REGISTRY:
        raise ValueError(
            f"Unknown therapy '{therapy}'. Available: {sorted(_THERAPY_REGISTRY.keys())}"
        )
    result = set()
    for csv_name in _THERAPY_REGISTRY[therapy]:
        result.update(get_target_gene_name_set(csv_name))
    return result


def therapy_target_gene_ids(therapy):
    """Ensembl gene IDs targeted by a therapy type."""
    if therapy not in _THERAPY_REGISTRY:
        raise ValueError(
            f"Unknown therapy '{therapy}'. Available: {sorted(_THERAPY_REGISTRY.keys())}"
        )
    result = set()
    for csv_name in _THERAPY_REGISTRY[therapy]:
        result.update(get_target_gene_id_set(csv_name))
    return result


def therapy_target_gene_id_to_name(therapy):
    """Therapy targets as {Ensembl_Gene_ID: Symbol} dict (fast path for plotting)."""
    if therapy not in _THERAPY_REGISTRY:
        raise ValueError(
            f"Unknown therapy '{therapy}'. Available: {sorted(_THERAPY_REGISTRY.keys())}"
        )
    result = {}
    for csv_name in _THERAPY_REGISTRY[therapy]:
        result.update(get_target_gene_id_to_name(csv_name))
    return result


# ---------- Mitochondrial genes ----------
def mitochondrial_genes_df(role=None):
    """DataFrame of mitochondrially-encoded genes (chrM).

    Parameters
    ----------
    role : str or None
        ``"protein_coding"`` — the 13 OXPHOS subunits (MT-CO*, MT-ND*,
        MT-CYB, MT-ATP6/8).
        ``"rRNA"`` — MT-RNR1, MT-RNR2.
        ``"tRNA"`` — the 22 mitochondrial tRNAs (MT-TA, MT-TC, …).
        ``None`` (default) — all 37 rows.

    Returns
    -------
    pd.DataFrame
        Columns: Symbol, Ensembl_Gene_ID, Role.
    """
    df = get_data("mitochondrial-genes")
    if role is not None:
        df = df[df["Role"] == role]
    return df


def mitochondrial_gene_names(role=None):
    """Set of mitochondrially-encoded gene symbols. See `mitochondrial_genes_df`."""
    return set(mitochondrial_genes_df(role=role)["Symbol"])


def mitochondrial_gene_ids(role=None):
    """Set of mitochondrially-encoded Ensembl gene IDs. See `mitochondrial_genes_df`."""
    return set(mitochondrial_genes_df(role=role)["Ensembl_Gene_ID"])


# ---------- Culture-stress genes ----------
def culture_stress_genes_df(category=None):
    """DataFrame of culture-stress-UP genes used to flag cell-line samples.

    Genes upregulated in culture-adapted cells vs primary tissue (Yu et al.,
    Nat Commun 2019). Split across categories: HSP / glycolysis /
    proliferation / ER_stress / oxidative_stress / glutamine.
    """
    df = get_data("culture-stress-genes")
    if category is not None:
        df = df[df["Category"] == category]
    return df


def culture_stress_gene_names(category=None):
    return set(culture_stress_genes_df(category=category)["Symbol"])


def culture_stress_gene_ids(category=None):
    return set(culture_stress_genes_df(category=category)["Ensembl_Gene_ID"])


# ---------- Tumor microenvironment (TME) markers ----------
def tme_markers_df(cell_type=None):
    """DataFrame of TME marker genes split by cell type.

    Used to detect the presence of tumor microenvironment (absent in cell
    lines, present in tissue biopsies). `cell_type` is one of ``T_cell``,
    ``B_cell``, ``myeloid``, ``fibroblast``, ``endothelial``, or None for
    all markers.
    """
    df = get_data("tme-markers")
    if cell_type is not None:
        df = df[df["Cell_Type"] == cell_type]
    return df


def tme_marker_gene_names(cell_type=None):
    return set(tme_markers_df(cell_type=cell_type)["Symbol"])


def tme_marker_gene_ids(cell_type=None):
    return set(tme_markers_df(cell_type=cell_type)["Ensembl_Gene_ID"])


# ---------- Degradation gene pairs (transcript length FFPE index) ----------
def degradation_gene_pairs_df():
    """DataFrame of (short, long) gene pairs with expected long/short ratios.

    Used by the transcript-length degradation index: in fresh tissue the
    ratio is near 1; in FFPE / degraded RNA the long transcript is
    preferentially lost. Each row has short/long symbol + Ensembl ID +
    expected ratio calibrated from 83 fresh/frozen reference columns.
    """
    return get_data("degradation-gene-pairs")


def degradation_gene_pairs():
    """List of (short_symbol, long_symbol, expected_ratio) tuples.

    Convenience view for callers that don't need Ensembl IDs. Returns the
    pairs in the order they appear in the CSV.
    """
    df = degradation_gene_pairs_df()
    return [
        (
            row["Short_Gene_Symbol"],
            row["Long_Gene_Symbol"],
            float(row["Expected_Long_Over_Short_Ratio"]),
        )
        for _, row in df.iterrows()
    ]


# ---------- Cancer lineage genes ----------
def lineage_genes_df(cancer_type=None):
    """DataFrame of per-TCGA-cancer lineage genes.

    Lineage genes are retained in metastases and specific enough to
    calibrate tumor purity. Each row is (Cancer_Type, Symbol,
    Ensembl_Gene_ID). Filter by `cancer_type` to get one type's genes.
    """
    df = get_data("lineage-genes")
    if cancer_type is not None:
        df = df[df["Cancer_Type"] == cancer_type]
    return df


def lineage_gene_symbols(cancer_type):
    """List of lineage gene symbols for a given TCGA cancer type code.

    Preserves CSV order (which encodes the curator's intent about which
    markers are most load-bearing for that cancer type).
    """
    df = lineage_genes_df(cancer_type=cancer_type)
    return df["Symbol"].tolist()


def lineage_gene_ids(cancer_type):
    """List of lineage Ensembl IDs for a given TCGA cancer type code."""
    df = lineage_genes_df(cancer_type=cancer_type)
    return df["Ensembl_Gene_ID"].tolist()


def lineage_genes_by_cancer_type():
    """Dict of {TCGA_code: [Symbol, ...]} for all cancer types.

    Primarily for consumers that historically used a pre-built dict. Built
    once per process via the `get_data` cache.
    """
    df = get_data("lineage-genes")
    return {
        code: group["Symbol"].tolist()
        for code, group in df.groupby("Cancer_Type", sort=False)
    }


# ---------- Cancer family panels ----------
def cancer_family_panels_df(family=None):
    """DataFrame of broad-family signature panels used for cancer-type scoring.

    Family labels include ``PROSTATE``, ``CRC``, ``GASTRIC``, ``ESCA_SQ``,
    ``SQUAMOUS``, ``MESENCHYMAL``, ``RENAL``, ``GLIAL``, ``MELANOCYTIC``.
    """
    df = get_data("cancer-family-panels")
    if family is not None:
        df = df[df["Family"] == family]
    return df


def cancer_family_panel(family):
    """List of Symbols for one cancer family. See `cancer_family_panels_df`."""
    return cancer_family_panels_df(family=family)["Symbol"].tolist()


def cancer_family_panels():
    """Dict of {family_label: [Symbol, ...]} for all families."""
    df = get_data("cancer-family-panels")
    return {
        family: group["Symbol"].tolist()
        for family, group in df.groupby("Family", sort=False)
    }


# ---------- Housekeeping genes ----------
def housekeeping_gene_names(core_only=False):
    df = get_data("housekeeping-genes")
    if core_only:
        df = df[df["Category"] == "Core"]
    return set(df["Symbol"])


def housekeeping_gene_ids(core_only=False):
    df = get_data("housekeeping-genes")
    if core_only:
        df = df[df["Category"] == "Core"]
    return set(df["Ensembl_Gene_ID"])


# ---------- FFPE-sensitive marker panel (issue #72 follow-up) ----------
#
# Curated panel of genes whose expression behaviour distinguishes FFPE
# from fresh / frozen RNA *independently of the matched gene-pair length
# index* (which becomes unreliable under exon-capture enrichment because
# probe density biases long transcripts).
#
# Two directions:
#
# - ``drops_in_ffpe``: genes that systematically under-detect in FFPE
#   for length-independent reasons (extreme transcript length, long
#   3′UTR with low mRNA stability, structural fragility).
# - ``stable_in_ffpe``: short, abundant reference genes that retain
#   detectable expression even in heavily degraded FFPE.
#
# The score is ``geomean(stable_TPM) / geomean(drops_TPM)`` after
# pseudocounting; values >> reference suggest FFPE.


def ffpe_sensitive_markers_df(direction=None):
    """Return the FFPE-sensitive marker panel.

    Parameters
    ----------
    direction : {"drops_in_ffpe", "stable_in_ffpe", None}
        If specified, return only one direction; otherwise return all.
    """
    df = get_data("ffpe-sensitive-markers")
    if direction is not None:
        df = df[df["direction"] == direction]
    return df


def ffpe_sensitive_gene_names(direction=None):
    return set(ffpe_sensitive_markers_df(direction)["symbol"])


def ffpe_sensitive_gene_ids(direction=None):
    return set(ffpe_sensitive_markers_df(direction)["ensembl_gene_id"])


# ---------- Extended housekeeping (issue #60) ----------
#
# A single authoritative panel of genes that cannot discriminate between
# cell types because they are ubiquitously expressed at high levels, or
# because their apparent abundance reflects artifact (MT copy number,
# FFPE short-transcript survival, clonal IG/TR rearrangement) rather
# than biology. Excluded from:
#
# - Marker selection (``engine._select_marker_rows``) — never picked as
#   a decomposition-component discriminator.
# - Tumor-attribution ranking (``estimate_tumor_expression_ranges``) —
#   flagged ``excluded_from_ranking`` so they don't show up as top
#   therapy targets when their observed TPM is high for housekeeping
#   reasons.
#
# Kept declarative (regex families + curated classics) so the panel can
# be audited at a glance and extended without a CSV churn cycle. The
# ``scope`` on each family lets B2M stay visible in the ranking output
# (it's a legitimate MHC-I context gene) while still being skipped from
# decomposition markers (the NNLS shouldn't treat it as a lineage
# discriminator).

import re as _re  # noqa: E402

_EXTENDED_HK_FAMILIES = [
    # (family_name, compiled_regex, scope)
    # scope ∈ {"markers", "ranking", "both"}
    ("mitochondrial_chrM", _re.compile(r"MT-.*"), "both"),
    ("cytosolic_ribosomal", _re.compile(r"(RPL|RPS)\d.*"), "both"),
    ("mito_ribosomal", _re.compile(r"(MRPL|MRPS)\d.*"), "both"),
    ("translation_factors", _re.compile(r"(EEF|EIF)\d.*"), "both"),
    ("hnRNPs", _re.compile(r"HNRNP[A-Z]\d?[A-Z]?\d?"), "both"),
    ("splicing_SR_proteins", _re.compile(r"SRSF\d+"), "both"),
    ("snRNPs", _re.compile(r"SNRP[A-Z]\d?"), "both"),
    ("proteasome_subunits", _re.compile(r"PSM[ABCDEF]\d+"), "both"),
    ("cyclophilins", _re.compile(r"PPI[A-Z]\d?"), "both"),
    ("tubulin", _re.compile(r"TUB(A|B|G)\d+[A-Z]?"), "both"),
    ("rearranged_ig_segments", _re.compile(r"(IGH|IGK|IGL)[VDJC]\d.*"), "both"),
    ("rearranged_tcr_segments", _re.compile(r"(TRA|TRB|TRG|TRD)[VDJC]\d.*"), "both"),
]

# Classic housekeeping symbols that don't follow a family regex. Keep
# these as an enumerated allow-list because bare prefix matching would
# catch too much. Each row declares the exclusion scope so we can keep
# biologically-meaningful genes (B2M) in the ranking output.
_EXTENDED_HK_CLASSICS = {
    # symbol: scope
    "ACTB": "both",
    "ACTG1": "both",
    "GAPDH": "both",
    "HPRT1": "both",
    "TPT1": "both",
    "RACK1": "both",
    "B2M": "markers",  # MHC-I context — keep visible in ranking.
    "PGK1": "both",
    "YWHAZ": "both",
    "UBC": "both",
    "PPIA": "both",
}


def _extended_hk_symbol_match(symbol):
    """Return ``(family_name, scope)`` if the symbol matches any family
    in the extended HK panel, else ``(None, None)``.
    """
    if not isinstance(symbol, str) or not symbol:
        return None, None
    for family, pattern, scope in _EXTENDED_HK_FAMILIES:
        if pattern.fullmatch(symbol):
            return family, scope
    classic_scope = _EXTENDED_HK_CLASSICS.get(symbol)
    if classic_scope is not None:
        return "classic_hk", classic_scope
    return None, None


def is_extended_housekeeping_symbol(symbol, scope="markers"):
    """Return True when the symbol should be excluded for the given
    scope (``"markers"``, ``"ranking"``, or ``"both"``).

    Issue #60. ``scope="markers"`` is the superset — every symbol
    excluded from ranking is also excluded from marker selection.
    ``scope="ranking"`` excludes only what's unambiguously uninteresting
    as a therapy target (keeps B2M, since MHC-I readers need it).
    """
    family, family_scope = _extended_hk_symbol_match(symbol)
    if family is None:
        return False
    if family_scope == "both":
        return True
    return family_scope == scope


def extended_housekeeping_symbols(scope="markers"):
    """Return a set of classic-symbol housekeeping members for the
    given scope. Regex families are not enumerated — use
    ``is_extended_housekeeping_symbol`` for runtime membership tests.
    """
    out = set()
    for symbol, sc in _EXTENDED_HK_CLASSICS.items():
        if sc == "both" or sc == scope:
            out.add(symbol)
    return out


# ---------- Surface proteins (surfaceome) ----------
def _surface_proteins_df(category=None):
    df = get_data("surface-proteins")
    if category is not None:
        df = df[df["Category"] == category]
    return df


def surface_protein_gene_names(validated_only=False):
    """Human cell surface protein gene symbols.

    Parameters
    ----------
    validated_only : bool
        If True, return only CSPA mass-spec validated proteins.
        If False (default), include ML-predicted surfaceome.
    """
    cat = "CSPA_validated" if validated_only else None
    return set(_surface_proteins_df(cat)["Symbol"])


def surface_protein_gene_ids(validated_only=False):
    """Human cell surface protein Ensembl gene IDs.

    Parameters
    ----------
    validated_only : bool
        If True, return only CSPA mass-spec validated proteins.
        If False (default), include ML-predicted surfaceome.
    """
    cat = "CSPA_validated" if validated_only else None
    df = _surface_proteins_df(cat)
    return set(
        df.loc[
            df["Ensembl_Gene_ID"].astype(str).str.startswith("ENSG"), "Ensembl_Gene_ID"
        ]
    )


def surface_protein_evidence():
    """Return the full surface protein DataFrame with categories and sources."""
    return get_data("surface-proteins")


# ---------- Cancer surfaceome (TCSA) ----------
def _cancer_surfaceome_df(min_cancer_types=None):
    df = get_data("cancer-surfaceome")
    if min_cancer_types is not None:
        df = df[df["num_cancer_types"] >= min_cancer_types]
    return df


def cancer_surfaceome_gene_names(min_cancer_types=None):
    """Tumor-specific surface protein gene symbols from TCSA (Lin et al. 2021).

    These are L3-tier (highest stringency) surface proteins with
    tumor-specific overexpression vs normal tissue, excluding
    immune-cell-expressed genes.

    Parameters
    ----------
    min_cancer_types : int or None
        If set, only return genes overexpressed in at least this many
        cancer types.
    """
    return set(_cancer_surfaceome_df(min_cancer_types)["Symbol"])


def cancer_surfaceome_gene_ids(min_cancer_types=None):
    """Tumor-specific surface protein Ensembl gene IDs from TCSA."""
    return set(_cancer_surfaceome_df(min_cancer_types)["Ensembl_Gene_ID"])


def cancer_surfaceome_gene_id_to_name(min_cancer_types=None):
    """Tumor-specific surface protein {Ensembl_Gene_ID: Symbol} dict from TCSA."""
    df = _cancer_surfaceome_df(min_cancer_types)
    return dict(zip(df["Ensembl_Gene_ID"], df["Symbol"]))


def cancer_surfaceome_evidence(min_cancer_types=None):
    """Full TCSA evidence DataFrame with cancer types and druggability."""
    return _cancer_surfaceome_df(min_cancer_types)


# ---------- Cancer-type registry ----------


def cancer_type_registry():
    """Return the cancer-type registry: one row per code with family / tissue / template / parent / source.

    The registry is a richer superset of TCGA — it covers non-TCGA heme
    malignancies (CLL, MM, MCL, FL, HL, MPN, etc.), pediatric cancers
    (OS, RMS, Ewing, NBL, Wilms, RT, MBL, ATRT, RB, HEPB), the
    neuroendocrine axis (panNET, midgut carcinoid, lung NE, SCLC +
    ASCL1/NEUROD1/POU2F3/YAP1 subtypes, Merkel cell), and rare entities
    (NUT carcinoma, adenoid cystic, medullary thyroid, chordoma, NPC).
    Each row carries:

    - ``code`` — canonical short code (TCGA codes preserved, plus new)
    - ``family`` — broad grouping (carcinoma-gi, sarcoma, heme-myeloid …)
    - ``primary_tissue`` — tissue of origin (bone, lymph_node, pancreas …)
    - ``primary_template`` — preferred pirlygenes decomposition template
      (``solid_primary``, ``heme_marrow``, ``primary_bone``, …) — the
      latter bone / cartilage / adipose / muscle variants are planned
      additions (#follow-up) that will let osteosarcoma / chondrosarcoma /
      liposarcoma route to a tissue-appropriate template instead of the
      soft-tissue SARC default
    - ``parent_code`` — if this row is a subtype of another registry
      entry (e.g. ``LAML_APL`` has ``parent_code=LAML``)
    - ``expression_source`` — where to find median expression (TCGA,
      TARGET, BEATAML, CoMMpass, curated, none)
    - ``notes`` — one-line clinical / therapeutic context

    Returns a defensive copy so callers can mutate freely.
    """
    return get_data("cancer-type-registry").copy()


def cancer_types_in_family(family):
    """Return cancer-type codes belonging to a registry family.

    Families span more than TCGA — ``sarcoma`` includes TCGA SARC
    subtype-tiles and the pediatric-bone / pediatric-soft cohorts;
    ``heme-myeloid`` covers LAML + MDS + MPN + CML etc.
    """
    df = cancer_type_registry()
    return df[df["family"] == family]["code"].tolist()


def cancer_types_by_tissue(primary_tissue):
    """Return cancer-type codes whose primary tissue matches.

    Useful for site-aware hypothesis generation — passing ``bone``
    returns osteosarcoma, Ewing, chondrosarcoma, chordoma, etc.
    """
    df = cancer_type_registry()
    return df[df["primary_tissue"] == primary_tissue]["code"].tolist()


def cancer_type_subtypes_of(parent_code):
    """Return registry subtypes of a given parent cancer code.

    For example ``cancer_type_subtypes_of("LAML")`` returns
    ``["LAML_APL", "LAML_ELN_Fav", "LAML_ELN_Int", "LAML_ELN_Adv"]``.
    Lets the second-pass subtype classifier enumerate candidates.
    """
    df = cancer_type_registry()
    return df[df["parent_code"] == parent_code]["code"].tolist()


def mixture_cohort_codes():
    """Return parent codes flagged as mixture cohorts in the registry (#171).

    A mixture cohort is a parent code whose TCGA / reference median is a
    biological union of lineage-distinct subtypes. Running classification
    against the parent median drowns subtype-specific markers; the
    classifier instead evaluates each subtype's lineage panel
    independently and takes the max (see
    :func:`pirlygenes.tumor_purity.estimate_tumor_purity`).

    Example: ``SARC`` = leiomyosarcoma ∪ liposarcoma ∪ myxofibrosarcoma ∪
    undifferentiated pleomorphic ∪ synovial ∪ MPNST. MYH11 is a
    leiomyosarcoma marker but near-zero at TCGA-SARC median because LMS
    is only ~26% of the cohort.
    """
    df = cancer_type_registry()
    if "mixture_cohort" not in df.columns:
        return []
    flag = df["mixture_cohort"].fillna(False).astype(bool)
    return df.loc[flag, "code"].tolist()


def is_mixture_cohort(code):
    """True when ``code`` is a mixture cohort per the registry (#171)."""
    return code in set(mixture_cohort_codes())


# ---------- Cancer-pathway panels (tumor-evidence Step-0 signals) ----------
#
# Each panel is a coordinated-program set — genes that move together in
# tumors vs normal tissue. Empirical median-fold-change numbers below
# are from a pan-cancer TCGA-vs-matched-HPA-normal sweep of 20
# epithelial cancer-tissue pairs. Ship as public API so consumers can
# reuse the same definitions for downstream analysis (scoring,
# signature calibration, cross-cohort comparison).


_PROLIFERATION_PANEL_GENES = (
    # Empirically-selected from pan-cancer sweep: each gene has
    # median fold ≥ 3 across 20 epithelial cancers vs matched normal,
    # and coordinated with the rest of the mitotic program.
    "MKI67",  # median fold 4.0x
    "TOP2A",  # 4.3
    "CCNB1",  # 3.1
    "CCNB2",  # 3.7
    "CDC20",  # 6.1
    "CDK1",  # 2.2
    "UBE2C",  # 5.9
    "TPX2",  # 4.8
    "CENPF",  # 14.3 — strongest single marker
    "FOXM1",  # 6.3
    "PLK1",  # 3.8
    "AURKA",  # 2.1
    "BIRC5",  # 3.8
)


_HYPOXIA_PANEL_GENES = (
    # Carbonic anhydrase 9 is the classic HIF1α-driven hypoxia marker;
    # SLC2A1 (GLUT1) is the Warburg/hypoxia crosslink. Median fold
    # across pan-cancer sweep — CA9 12.1x, SLC2A1 9.1x.
    "CA9",
    "SLC2A1",
    "LDHA",
    "ENO1",
    "PGK1",
)


_GLYCOLYSIS_PANEL_GENES = (
    # Warburg / glycolysis panel. Most individual fold-changes are
    # modest (1-2x over normal) because glycolytic enzymes are high
    # everywhere; the ABSOLUTE tumor TPM is what's striking (PKM 557,
    # ENO1 723, GAPDH 2575 across pan-cancer). SLC2A1 (GLUT1) and
    # ALDOA give the best fold-change contrast.
    "HK2",
    "LDHA",
    "PKM",
    "SLC2A1",
    "ENO1",
    "PGK1",
    "ALDOA",
    "PFKP",
)


_DDR_ACTIVATION_PANEL_GENES = (
    # DNA-damage-response / replication-stress markers. Modest fold-
    # change (1-2x) but co-upregulated under replication stress.
    "RAD51",
    "RAD51AP1",
    "CHEK1",
    "CHEK2",
    "ATR",
    "BRCA1",
)


_ONCOFETAL_STRICT_GENES = (
    # Genes near-zero in any adult somatic tissue, re-expressed in
    # tumors as an oncofetal program. Stricter than the CTA panel —
    # these must pass HPA-check of median nTPM < 1 outside
    # reproductive / trophoblastic cells.
    "AFP",
    "LIN28A",
    "LIN28B",
    "TPBG",  # 5T4
    "PLAC1",
    "CGB",
    "CGB1",
    "CGB2",
    "CGB3",
    "NANOG",
    "POU5F1",  # OCT4
)


def proliferation_panel_gene_names():
    """Coordinated cell-cycle / mitotic-program panel (13 genes).

    Empirically-selected from a pan-cancer sweep: each gene has
    median fold-change ≥ 3 across 20 epithelial cancer-tissue pairs.
    Used as a Step-0 tumor-evidence signal (healthy_vs_tumor) and
    available here for downstream scoring / calibration.
    """
    return list(_PROLIFERATION_PANEL_GENES)


def hypoxia_panel_gene_names():
    """Hypoxia-response panel — CA9, SLC2A1, LDHA, ENO1, PGK1.

    CA9 is the strongest single-gene marker (median fold 12x across
    pan-cancer). Used as a Step-0 tumor-evidence signal and for
    downstream hypoxia-score calculation.
    """
    return list(_HYPOXIA_PANEL_GENES)


def glycolysis_panel_gene_names():
    """Warburg / glycolysis panel — 8 canonical enzymes.

    Modest per-gene fold-change over normal (these are high
    everywhere) but coordinated upregulation is a cancer hallmark.
    Absolute tumor TPMs are dramatic (PKM 557, ENO1 723, GAPDH 2575
    averaged across pan-cancer medians).
    """
    return list(_GLYCOLYSIS_PANEL_GENES)


def ddr_activation_panel_gene_names():
    """DNA-damage-response / replication-stress panel (6 genes)."""
    return list(_DDR_ACTIVATION_PANEL_GENES)


def oncofetal_strict_gene_names():
    """Oncofetal / embryonic-stemness strict panel (11 genes).

    Near-zero in any adult somatic tissue, re-expressed in many
    cancers. Strictest specificity — SOX2 / KLF4 / IGF2 / HMGA2 /
    HLA-G were intentionally excluded from this tier because they
    are physiologically expressed in adult niches (neural
    progenitors, gut stem cells, smooth muscle, etc.) and would
    false-positive as tumor evidence.
    """
    return list(_ONCOFETAL_STRICT_GENES)


def cancer_type_gene_sets(cancer_type):
    """Curated gene sets for a specific cancer type, grouped by role.

    Parameters
    ----------
    cancer_type : str
        TCGA code or alias (e.g. ``"PRAD"``, ``"prostate"``).

    Returns
    -------
    dict[str, dict[str, str]]
        {role: {ensembl_id: symbol}} for use as gene_sets in plotting.
        Returns empty dict if no curated genes exist for that cancer type.
    """
    code = resolve_cancer_type(cancer_type)
    try:
        df = get_data("cancer-type-genes")
    except Exception:
        return {}
    sub = df[df["Cancer_Type"] == code]
    if sub.empty:
        return {}
    result = {}
    for role, group in sub.groupby("Role"):
        result[role] = dict(zip(group["Ensembl_Gene_ID"], group["Symbol"]))


# ---------- Multispecific T-cell Engagers (custom filtering) ----------


def _tce_filtered_df(pmhc=None):
    """Return TCE trial rows, optionally filtered by format.

    Parameters
    ----------
    pmhc : bool or None
        True  = only pMHC-targeting TCEs (TCR-based formats)
        False = only surface-antigen-targeting TCEs (antibody-based formats)
        None  = all TCEs (trials + approved pMHC TCEs)
    """
    import pandas as pd

    df = get_data("multispecific-tcell-engager-trials")
    if pmhc is not False:
        df_approved = get_data("bispecific-antibodies-approved")
        if "Format" in df_approved.columns:
            is_tcr_approved = df_approved["Format"].str.contains(
                "TCR|ImmTAC", case=False, na=False
            )
            df = pd.concat([df, df_approved[is_tcr_approved]], ignore_index=True)

    if pmhc is not None and "Format" in df.columns:
        is_tcr = df["Format"].str.contains("TCR|ImmTAC", case=False, na=False)
        df = df[is_tcr] if pmhc else df[~is_tcr]
    return df


def _extract_genes_from_df(df, candidate_columns):
    result = set()
    for column in candidate_columns:
        if column in df.columns:
            for x in df[column]:
                if type(x) is str:
                    result.update([xi.strip() for xi in x.split(";")])
    return result


_NAME_COLS = ["Tumor_Target_Symbols", "Tumor_Target_Symbol", "Symbol", "Gene_Name"]
_ID_COLS = [
    "Tumor_Target_Gene_IDs",
    "Tumor_Target_Ensembl_Gene_IDs",
    "Tumor_Target_Ensembl_Gene_ID",
    "Ensembl_Gene_ID",
    "Gene_ID",
]


def pMHC_TCE_target_gene_names():
    """pMHC-targeting TCE gene symbols (TCR-based: ImmTAC, TCR-scFv)."""
    return _extract_genes_from_df(_tce_filtered_df(pmhc=True), _NAME_COLS)


def pMHC_TCE_target_gene_ids():
    """pMHC-targeting TCE Ensembl gene IDs."""
    return _extract_genes_from_df(_tce_filtered_df(pmhc=True), _ID_COLS)


def surface_TCE_target_gene_names():
    """Surface-antigen-targeting TCE gene symbols (antibody-based bispecifics)."""
    return _extract_genes_from_df(_tce_filtered_df(pmhc=False), _NAME_COLS)


def surface_TCE_target_gene_ids():
    """Surface-antigen-targeting TCE Ensembl gene IDs."""
    return _extract_genes_from_df(_tce_filtered_df(pmhc=False), _ID_COLS)


def _tce_gene_id_to_name(pmhc):
    """Paired {Ensembl_Gene_ID: Symbol} dict from TCE data."""
    df = _tce_filtered_df(pmhc=pmhc)
    sym_col = next((c for c in _NAME_COLS if c in df.columns), None)
    id_col = next((c for c in _ID_COLS if c in df.columns), None)
    if sym_col is None or id_col is None:
        names = _extract_genes_from_df(df, _NAME_COLS)
        ids = _extract_genes_from_df(df, _ID_COLS)
        return {gid: gid for gid in ids} if ids else {n: n for n in names}
    result = {}
    for _, row in df.iterrows():
        syms_raw = str(row[sym_col]).strip() if row[sym_col] is not None else ""
        ids_raw = str(row[id_col]).strip() if row[id_col] is not None else ""
        if not syms_raw or syms_raw.lower() in ("nan", "none"):
            continue
        syms = [s.strip() for s in syms_raw.split(";") if s.strip()]
        ids = [
            i.strip()
            for i in ids_raw.split(";")
            if i.strip() and i.strip().startswith("ENSG")
        ]
        for i, sym in enumerate(syms):
            if i < len(ids):
                result[ids[i]] = sym
    return result


def pMHC_TCE_target_gene_id_to_name():
    """pMHC-targeting TCE: {Ensembl_Gene_ID: Symbol}."""
    return _tce_gene_id_to_name(pmhc=True)


def surface_TCE_target_gene_id_to_name():
    """Surface-antigen-targeting TCE: {Ensembl_Gene_ID: Symbol}."""
    return _tce_gene_id_to_name(pmhc=False)


# ---------- Deprecated therapy wrappers ----------
# Use therapy_target_gene_names/ids/id_to_name() instead.


def _deprecate(old_name, therapy, ret):
    def fn():
        warnings.warn(
            f"{old_name}() is deprecated, use therapy_target_gene_{ret}('{therapy}')",
            DeprecationWarning,
            stacklevel=2,
        )
        return {"names": therapy_target_gene_names, "ids": therapy_target_gene_ids}[
            ret
        ](therapy)

    fn.__name__ = old_name
    fn.__doc__ = f"Deprecated. Use therapy_target_gene_{ret}('{therapy}')."
    return fn


ADC_trial_target_gene_names = _deprecate(
    "ADC_trial_target_gene_names", "ADC-trials", "names"
)
ADC_trial_target_gene_ids = _deprecate("ADC_trial_target_gene_ids", "ADC-trials", "ids")
ADC_approved_target_gene_names = _deprecate(
    "ADC_approved_target_gene_names", "ADC-approved", "names"
)
ADC_approved_target_gene_ids = _deprecate(
    "ADC_approved_target_gene_ids", "ADC-approved", "ids"
)
ADC_target_gene_names = _deprecate("ADC_target_gene_names", "ADC", "names")
ADC_target_gene_ids = _deprecate("ADC_target_gene_ids", "ADC", "ids")
TCR_T_trial_target_get_names = _deprecate(
    "TCR_T_trial_target_get_names", "TCR-T-trials", "names"
)
TCR_T_trial_target_get_ids = _deprecate(
    "TCR_T_trial_target_get_ids", "TCR-T-trials", "ids"
)
TCR_T_approved_target_gene_names = _deprecate(
    "TCR_T_approved_target_gene_names", "TCR-T-approved", "names"
)
TCR_T_approved_target_gene_ids = _deprecate(
    "TCR_T_approved_target_gene_ids", "TCR-T-approved", "ids"
)
TCR_T_target_gene_names = _deprecate("TCR_T_target_gene_names", "TCR-T", "names")
TCR_T_target_gene_ids = _deprecate("TCR_T_target_gene_ids", "TCR-T", "ids")
CAR_T_approved_target_gene_names = _deprecate(
    "CAR_T_approved_target_gene_names", "CAR-T", "names"
)
CAR_T_approved_target_gene_ids = _deprecate(
    "CAR_T_approved_target_gene_ids", "CAR-T", "ids"
)
CAR_T_target_gene_names = _deprecate("CAR_T_target_gene_names", "CAR-T", "names")
CAR_T_target_gene_ids = _deprecate("CAR_T_target_gene_ids", "CAR-T", "ids")
multispecific_tcell_engager_trial_target_gene_names = _deprecate(
    "multispecific_tcell_engager_trial_target_gene_names", "multispecific-TCE", "names"
)
multispecific_tcell_engager_trial_target_gene_ids = _deprecate(
    "multispecific_tcell_engager_trial_target_gene_ids", "multispecific-TCE", "ids"
)
multispecific_tcell_engager_target_gene_names = _deprecate(
    "multispecific_tcell_engager_target_gene_names", "multispecific-TCE", "names"
)
multispecific_tcell_engager_target_gene_ids = _deprecate(
    "multispecific_tcell_engager_target_gene_ids", "multispecific-TCE", "ids"
)
bispecific_antibody_approved_target_gene_names = _deprecate(
    "bispecific_antibody_approved_target_gene_names", "bispecific-antibodies", "names"
)
bispecific_antibody_approved_target_gene_ids = _deprecate(
    "bispecific_antibody_approved_target_gene_ids", "bispecific-antibodies", "ids"
)
bispecific_antibody_target_gene_names = _deprecate(
    "bispecific_antibody_target_gene_names", "bispecific-antibodies", "names"
)
bispecific_antibody_targets_gene_ids = _deprecate(
    "bispecific_antibody_targets_gene_ids", "bispecific-antibodies", "ids"
)
radio_target_gene_names = _deprecate("radio_target_gene_names", "radioligand", "names")
radio_target_gene_ids = _deprecate("radio_target_gene_ids", "radioligand", "ids")
radioligand_target_gene_names = _deprecate(
    "radioligand_target_gene_names", "radioligand", "names"
)
radioligand_target_gene_ids = _deprecate(
    "radioligand_target_gene_ids", "radioligand", "ids"
)


# ---------- Cancer-testis antigens (CTA) ----------
_CTA_FILTER_COLUMN_CANDIDATES = ("passes_filters", "filtered")
_CTA_REQUIRED_EVIDENCE_COLUMNS = frozenset(
    {
        "never_expressed",
        "rna_98_pct_filter",
        "rna_deflated_reproductive_frac",
        "rna_99_pct_filter",
    }
)


def _has_complete_cta_evidence_schema(df: pd.DataFrame) -> bool:
    return _CTA_REQUIRED_EVIDENCE_COLUMNS.issubset(
        set(df.columns)
    ) and _cta_filter_column(df) is not None


def _cta_filter_column(df: pd.DataFrame) -> str | None:
    for column in _CTA_FILTER_COLUMN_CANDIDATES:
        if column in df.columns:
            return column
    return None


def _bool_mask(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower() == "true"


def _cta_filter_mask(df: pd.DataFrame) -> pd.Series:
    column = _cta_filter_column(df)
    if column is None:
        return pd.Series(False, index=df.index)
    return _bool_mask(df[column])


def _with_cta_filter_aliases(df: pd.DataFrame) -> pd.DataFrame:
    """Expose both canonical and historical CTA filter names."""
    filter_column = _cta_filter_column(df)
    if filter_column is None:
        return df
    df = df.copy()
    if "passes_filters" not in df.columns:
        df["passes_filters"] = df[filter_column]
    if "filtered" not in df.columns:
        df["filtered"] = df[filter_column]
    return df


def _bundled_cta_evidence() -> pd.DataFrame:
    from .load_dataset import get_data

    return get_data("cancer-testis-antigens")


def _cta_df(filtered_only=False, exclude_never_expressed=False):
    df = CTA_evidence()
    mask = pd.Series(True, index=df.index)
    if filtered_only:
        mask = mask & _cta_filter_mask(df)
    if exclude_never_expressed and "never_expressed" in df.columns:
        mask = mask & ~_bool_mask(df["never_expressed"])
    return df[mask]


def _cta_by_column(column, filtered_only=False, exclude_never_expressed=False):
    subset = _cta_df(
        filtered_only=filtered_only,
        exclude_never_expressed=exclude_never_expressed,
    )
    result = set()
    if column in subset.columns:
        for x in subset[column]:
            if isinstance(x, str):
                result.update([xi.strip() for xi in x.split(";")])
    return result


def CTA_gene_names():
    """CTA gene symbols: filtered AND expressed (>= 2 nTPM somewhere).

    This is the recommended default for pMHC discovery. Excludes
    never-expressed CTAs (no protein data + max RNA < 2 nTPM).
    For the full filtered set including never-expressed, use
    ``CTA_filtered_gene_names()``.
    """
    return _cta_by_column("Symbol", filtered_only=True, exclude_never_expressed=True)


def CTA_gene_ids():
    """CTA Ensembl gene IDs: filtered AND expressed."""
    return _cta_by_column(
        "Ensembl_Gene_ID", filtered_only=True, exclude_never_expressed=True
    )


def CTA_gene_id_to_name():
    """CTA {Ensembl_Gene_ID: Symbol} dict: filtered AND expressed."""
    subset = _cta_df(filtered_only=True, exclude_never_expressed=True)
    if "Ensembl_Gene_ID" not in subset.columns or "Symbol" not in subset.columns:
        return {}

    result = {}
    for _, row in subset[["Ensembl_Gene_ID", "Symbol"]].dropna().iterrows():
        gene_id = str(row["Ensembl_Gene_ID"]).strip()
        symbol = str(row["Symbol"]).strip()
        if not gene_id or gene_id.lower() in {"nan", "none"}:
            continue
        if not symbol or symbol.lower() in {"nan", "none"}:
            continue
        result[gene_id] = symbol
    return result


def CTA_filtered_gene_names():
    """All CTA gene symbols that pass the HPA filter (including never-expressed)."""
    return _cta_by_column("Symbol", filtered_only=True)


def CTA_filtered_gene_ids():
    """All CTA Ensembl gene IDs that pass the HPA filter (including never-expressed)."""
    return _cta_by_column("Ensembl_Gene_ID", filtered_only=True)


def CTA_never_expressed_gene_names():
    """CTA genes that pass filter but have no meaningful HPA expression.

    No protein data AND max RNA nTPM < 2. These are in source databases
    but lack positive evidence of tissue restriction from HPA.
    """
    return CTA_filtered_gene_names() - CTA_gene_names()


def CTA_never_expressed_gene_ids():
    """CTA Ensembl gene IDs that pass filter but have no meaningful HPA expression."""
    return CTA_filtered_gene_ids() - CTA_gene_ids()


def CTA_unfiltered_gene_names():
    """All CTA gene symbols from all source databases (unfiltered).

    This is the full CTA universe — use for excluding CTA genes from
    a non-CTA comparison set.  Any gene in this set was identified as
    a candidate CTA by at least one source database.
    """
    return _cta_by_column("Symbol")


def CTA_unfiltered_gene_ids():
    """All CTA Ensembl gene IDs from all source databases (unfiltered)."""
    return _cta_by_column("Ensembl_Gene_ID")


def CTA_excluded_gene_names():
    """CTA genes that FAIL the reproductive-tissue filter.

    These are candidate CTAs with evidence of somatic tissue expression.
    Use this set to exclude from a non-CTA comparison set: they should
    not be in the clean CTA set (they leak into healthy tissue) but also
    should not be in a non-CTA set (they are still CTA candidates).
    """
    return CTA_unfiltered_gene_names() - CTA_filtered_gene_names()


def CTA_excluded_gene_ids():
    """CTA Ensembl gene IDs that FAIL the reproductive-tissue filter."""
    return CTA_unfiltered_gene_ids() - CTA_filtered_gene_ids()


def CTA_evidence():
    """Return the full CTA evidence DataFrame with HPA tissue-restriction columns.

    Columns
    -------
    Symbol, Aliases, Full_Name, Function, Ensembl_Gene_ID,
    source_databases, biotype, Canonical_Transcript_ID
        Gene identity fields.
    protein_reproductive : bool or "no data"
        True if all IHC-detected tissues (excluding thymus) are in
        {testis, ovary, placenta}.
    protein_thymus : bool or "no data"
        True if protein detected in thymus.
    rna_reproductive : bool
        True if every tissue with >=1 nTPM (excluding thymus) is in
        {testis, ovary, placenta}.
    rna_thymus : bool
        True if thymus nTPM >= 1.
    protein_reliability : str
        Best HPA antibody reliability for this gene: "Enhanced",
        "Supported", "Approved", "Uncertain", or "no data".
    protein_strict_expression : str
        Semicolon-separated list of tissues where protein is detected
        (excluding thymus), or "no data" / "not detected".
    rna_reproductive_frac : float
        Fraction of total nTPM (excluding thymus) in core reproductive
        tissues, computed from raw nTPM values.
    rna_reproductive_and_thymus_frac : float
        Same but with thymus nTPM added to numerator and denominator.
    rna_deflated_reproductive_frac : float
        (1 + repro_deflated) / (1 + total_deflated) where each tissue
        is deflated via max(0, nTPM - 1).  The +1 pseudocount prevents
        0/0 for very-low-expression genes.
    rna_deflated_reproductive_and_thymus_frac : float
        Same but with thymus deflated nTPM added to the reproductive
        numerator.
    rna_80_pct_filter, rna_90_pct_filter, rna_95_pct_filter : bool
        Whether deflated reproductive fraction >= 80/90/95%.
    filtered : bool
        Historical alias for passes_filters.
    passes_filters : bool
        Final inclusion flag with tiered RNA thresholds based on protein
        antibody reliability.  True when protein is reproductive-only
        (or absent) and deflated RNA fraction meets the tier threshold:
        - Enhanced → RNA >=80%
        - Supported → RNA >=90%
        - Approved → RNA >=95%
        - Uncertain or no protein data → RNA >=98%
        Genes with protein in non-reproductive tissues always fail.
        Non-protein-coding genes (biotype != protein_coding) always fail.
    rna_max_ntpm : float
        Maximum nTPM across all tissues for this gene.
    never_expressed : bool
        True if no HPA protein data AND maximum RNA nTPM < 2.
    """
    try:
        from tsarina.evidence import CTA_evidence as _tsarina_evidence

        df = _tsarina_evidence()
        if _has_complete_cta_evidence_schema(df):
            return _with_cta_filter_aliases(df)
    except ImportError:
        pass
    return _with_cta_filter_aliases(_bundled_cta_evidence())


from dataclasses import dataclass  # noqa: E402

import pandas as pd  # noqa: E402


@dataclass(frozen=True)
class CTAPartitionSets:
    """Three-way partition of protein-coding genes as sets.

    Attributes
    ----------
    cta : set[str]
        Expressed, reproductive-restricted CTAs. Source of CTA pMHCs.
    cta_never_expressed : set[str]
        CTAs from source databases with no meaningful HPA expression
        (no protein data + max RNA < 2 nTPM).
    non_cta : set[str]
        All other protein-coding genes, including CTAs that fail the
        reproductive-tissue filter (somatic expression detected).
    """

    cta: set
    cta_never_expressed: set
    non_cta: set


@dataclass(frozen=True)
class CTAPartitionDataFrames:
    """Three-way partition of protein-coding genes as DataFrames.

    Attributes
    ----------
    cta : pd.DataFrame
        Expressed, reproductive-restricted CTAs with full evidence columns.
    cta_never_expressed : pd.DataFrame
        Never-expressed CTAs with full evidence columns.
    non_cta : pd.DataFrame
        All other protein-coding genes (Symbol, Ensembl_Gene_ID).
    """

    cta: pd.DataFrame
    cta_never_expressed: pd.DataFrame
    non_cta: pd.DataFrame


def _build_partition(ensembl_release=112):
    """Shared logic for building the three-way partition."""
    from pyensembl import EnsemblRelease

    ensembl = EnsemblRelease(ensembl_release)
    evidence_df = CTA_evidence()

    all_pc_genes = {
        g.gene_id: g.gene_name for g in ensembl.genes() if g.biotype == "protein_coding"
    }
    all_pc_ids = set(all_pc_genes.keys())

    filtered_mask = _cta_filter_mask(evidence_df)
    never_expr_mask = _bool_mask(evidence_df["never_expressed"])

    cta_mask = filtered_mask & ~never_expr_mask
    never_expressed_mask = filtered_mask & never_expr_mask

    cta_ids = set(evidence_df.loc[cta_mask, "Ensembl_Gene_ID"])
    never_expressed_ids = set(evidence_df.loc[never_expressed_mask, "Ensembl_Gene_ID"])
    non_cta_ids = all_pc_ids - cta_ids - never_expressed_ids

    return (
        all_pc_genes,
        evidence_df,
        cta_mask,
        never_expressed_mask,
        cta_ids,
        never_expressed_ids,
        non_cta_ids,
    )


def CTA_partition_gene_ids(ensembl_release=112) -> CTAPartitionSets:
    """Partition all protein-coding genes into CTA / never-expressed / non-CTA
    as sets of Ensembl gene IDs.

    CTAs that fail the reproductive-tissue filter (somatic expression)
    are included in ``non_cta``.

    Examples
    --------
    >>> p = CTA_partition_gene_ids()
    >>> "ENSG00000147381" in p.cta   # MAGEA4
    True
    >>> len(p.cta & p.non_cta)       # no overlap
    0
    """
    _, _, _, _, cta_ids, never_expressed_ids, non_cta_ids = _build_partition(
        ensembl_release
    )
    return CTAPartitionSets(
        cta=cta_ids,
        cta_never_expressed=never_expressed_ids,
        non_cta=non_cta_ids,
    )


def CTA_partition_gene_names(ensembl_release=112) -> CTAPartitionSets:
    """Partition all protein-coding genes into CTA / never-expressed / non-CTA
    as sets of gene symbols.

    CTAs that fail the reproductive-tissue filter (somatic expression)
    are included in ``non_cta``.

    Examples
    --------
    >>> p = CTA_partition_gene_names()
    >>> "MAGEA4" in p.cta
    True
    >>> "TP53" in p.non_cta
    True
    """
    all_pc_genes, evidence_df, cta_mask, never_expressed_mask, _, _, _ = (
        _build_partition(ensembl_release)
    )
    all_pc_names = set(all_pc_genes.values())

    cta_names = set(evidence_df.loc[cta_mask, "Symbol"])
    never_expressed_names = set(evidence_df.loc[never_expressed_mask, "Symbol"])
    non_cta_names = all_pc_names - cta_names - never_expressed_names

    return CTAPartitionSets(
        cta=cta_names,
        cta_never_expressed=never_expressed_names,
        non_cta=non_cta_names,
    )


def CTA_partition_dataframes(ensembl_release=112) -> CTAPartitionDataFrames:
    """Partition all protein-coding genes into CTA / never-expressed / non-CTA
    as DataFrames.

    The ``cta`` and ``cta_never_expressed`` DataFrames include all CTA
    evidence columns. The ``non_cta`` DataFrame has Symbol and
    Ensembl_Gene_ID columns.

    CTAs that fail the reproductive-tissue filter (somatic expression)
    are included in ``non_cta``.

    Examples
    --------
    >>> p = CTA_partition_dataframes()
    >>> "rna_deflated_reproductive_frac" in p.cta.columns
    True
    """
    all_pc_genes, evidence_df, cta_mask, never_expressed_mask, _, _, non_cta_ids = (
        _build_partition(ensembl_release)
    )

    non_cta_records = [
        {"Symbol": all_pc_genes[gid], "Ensembl_Gene_ID": gid}
        for gid in sorted(non_cta_ids)
        if gid in all_pc_genes
    ]

    return CTAPartitionDataFrames(
        cta=evidence_df.loc[cta_mask].copy().reset_index(drop=True),
        cta_never_expressed=evidence_df.loc[never_expressed_mask]
        .copy()
        .reset_index(drop=True),
        non_cta=pd.DataFrame(non_cta_records),
    )


def CTA_partition(return_type="gene_ids", ensembl_release=112):
    """Deprecated — use CTA_partition_gene_ids, CTA_partition_gene_names,
    or CTA_partition_dataframes instead."""
    if return_type == "gene_ids":
        return CTA_partition_gene_ids(ensembl_release)
    elif return_type == "gene_names":
        return CTA_partition_gene_names(ensembl_release)
    elif return_type == "dataframes":
        return CTA_partition_dataframes(ensembl_release)
    else:
        raise ValueError(
            f"return_type must be 'gene_ids', 'gene_names', or 'dataframes', got {return_type!r}"
        )


# ---------- Cancer-type key genes (biomarkers + therapy targets) #110 ----------
def cancer_key_genes_df():
    """Full curated table of clinician-relevant biomarker and therapy-
    target genes per cancer type (#110).

    One row per (cancer_code, symbol, role, agent?) — so genes with
    multiple approved agents appear as multiple rows. Columns:
    ``cancer_code, subtype, symbol, role (biomarker|target), agent,
    agent_class, phase (approved|phase_3|phase_2|phase_1|preclinical),
    indication, rationale, source``.

    The curation bar is "genes a clinician would ask about because they
    have clear prognostic value or gate access to an active therapy."
    Some cancer types have no well-validated targets and are omitted
    from the CSV rather than padded — an empty lookup is a valid
    result.
    """
    from .load_dataset import get_data

    return get_data("cancer-key-genes")


def cancer_biomarker_genes(cancer_code, subtype=None):
    """Ordered list of biomarker gene symbols for ``cancer_code``.

    Empty list when the cancer type is not yet curated — callers should
    treat that as "no clinician-relevant biomarker panel available" and
    render an appropriate placeholder, not synthesize fallback genes.

    ``subtype`` (optional) filters to a specific subtype string (e.g.
    ``"synovial_sarcoma"`` under ``cancer_code="SARC"``, #126). When
    ``None``, returns **all** biomarker rows for the cancer code
    regardless of subtype — suitable for samples whose subtype isn't
    yet determined at report time.
    """
    df = cancer_key_genes_df()
    sub = df[(df["cancer_code"] == cancer_code) & (df["role"] == "biomarker")]
    if subtype is not None:
        sub = sub[sub["subtype"].fillna("").astype(str) == subtype]
    return list(sub["symbol"].dropna().astype(str).unique())


def cancer_therapy_targets(cancer_code, subtype=None):
    """Subset of :func:`cancer_key_genes_df` for therapy-target rows of
    ``cancer_code``. Returns a DataFrame so callers can render the
    Phase / Indication / Agent columns without re-joining.

    ``subtype`` (optional) filters to a specific subtype; see
    :func:`cancer_biomarker_genes` for semantics.
    """
    df = cancer_key_genes_df()
    sub = df[(df["cancer_code"] == cancer_code) & (df["role"] == "target")]
    if subtype is not None:
        sub = sub[sub["subtype"].fillna("").astype(str) == subtype]
    return sub.copy().reset_index(drop=True)


THERAPY_BENEFIT_TIERS = (
    "curative",
    "durable_rfs",
    "major_survival",
    "high_response",
    "meaningful_pfs",
    "incremental",
    "modest",
    "unclear",
)

THERAPY_TOXICITY_TIERS = (
    "minimal",
    "low",
    "moderate",
    "high",
    "very_high",
    "unclear",
)

_THERAPY_EVIDENCE_REQUIRED_COLUMNS = (
    "agent",
    "agent_class",
    "target_symbol",
    "cancer_code",
    "subtype",
    "line_of_therapy",
    "setting",
    "endpoint_type",
    "endpoint_value",
    "benefit_tier",
    "toxicity_tier",
    "grade3_plus_ae_rate",
    "discontinuation_rate",
    "boxed_warning",
    "major_toxicities",
    "source_type",
    "source_id",
    "evidence_transfer",
    "evidence_notes",
)


def _nonempty_strings(series):
    return set(series.dropna().astype(str).str.strip()) - {""}


def _filter_text_value(df, column, value):
    if value is None:
        return df
    wanted = str(value).strip().casefold()
    values = df[column].fillna("").astype(str).str.strip().str.casefold()
    return df[values == wanted]


def _validate_therapy_benefit_toxicity_evidence(df):
    missing = set(_THERAPY_EVIDENCE_REQUIRED_COLUMNS) - set(df.columns)
    if missing:
        raise ValueError(
            "therapy-benefit-toxicity-evidence.csv is missing columns: "
            f"{sorted(missing)}"
        )

    invalid_benefit = _nonempty_strings(df["benefit_tier"]) - set(
        THERAPY_BENEFIT_TIERS
    )
    if invalid_benefit:
        raise ValueError(f"Invalid benefit_tier values: {sorted(invalid_benefit)}")

    invalid_toxicity = _nonempty_strings(df["toxicity_tier"]) - set(
        THERAPY_TOXICITY_TIERS
    )
    if invalid_toxicity:
        raise ValueError(f"Invalid toxicity_tier values: {sorted(invalid_toxicity)}")

    postmarket = df["source_type"].fillna("").astype(str).str.strip().eq(
        "postmarket_signal"
    )
    postmarket_with_incidence = postmarket & df["grade3_plus_ae_rate"].notna()
    postmarket_with_incidence = postmarket_with_incidence & df[
        "grade3_plus_ae_rate"
    ].astype(str).str.strip().ne("")
    if postmarket_with_incidence.any():
        bad_agents = sorted(df.loc[postmarket_with_incidence, "agent"].astype(str))
        raise ValueError(
            "postmarket_signal rows must not provide incidence-like "
            f"grade3_plus_ae_rate values: {bad_agents}"
        )


def therapy_benefit_toxicity_evidence(
    *,
    agent=None,
    cancer_code=None,
    subtype=None,
    line_of_therapy=None,
    source_type=None,
    include_transferred=True,
):
    """Curated benefit/toxicity evidence rows for therapy ranking.

    The table is keyed by agent with optional disease, subtype, and
    line-of-therapy context. It is deliberately separate from expression
    values: target expression must never be used to infer survival
    benefit or toxicity on its own.

    Parameters filter exact text values case-insensitively. When both
    ``cancer_code`` and ``subtype`` are supplied, parent cancer-code rows
    with blank subtype are kept alongside exact subtype rows because
    those broader rows can still apply to the subtype. Subtype-only
    filtering returns only exact subtype rows. Set
    ``include_transferred=False`` to drop cross-indication rows that
    require an explicit eligibility caveat before use.
    """
    from .load_dataset import get_data

    df = get_data("therapy-benefit-toxicity-evidence")
    _validate_therapy_benefit_toxicity_evidence(df)

    df = _filter_text_value(df, "agent", agent)
    df = _filter_text_value(df, "cancer_code", cancer_code)
    df = _filter_text_value(df, "line_of_therapy", line_of_therapy)
    df = _filter_text_value(df, "source_type", source_type)

    if subtype is not None:
        wanted = str(subtype).strip().casefold()
        values = df["subtype"].fillna("").astype(str).str.strip().str.casefold()
        if cancer_code is None:
            df = df[values == wanted]
        else:
            df = df[(values == "") | (values == wanted)]

    if not include_transferred:
        transfer = (
            df["evidence_transfer"].fillna("").astype(str).str.strip().str.casefold()
        )
        df = df[transfer != "cross_indication"]

    return df.copy().reset_index(drop=True)


def cancer_key_genes_cancer_types():
    """Return the set of cancer codes currently curated in the CSV.
    Use to show a follow-up banner for non-covered cancer types.
    """
    df = cancer_key_genes_df()
    return sorted(df["cancer_code"].dropna().astype(str).unique())


def cancer_key_genes_subtypes(cancer_code):
    """Return the list of curated subtypes for ``cancer_code``.

    SARC is the primary user — subtype-stratified for leiomyosarcoma
    / WD-DDLPS / MRCLS / synovial_sarcoma / DSRCT / GIST /
    ewing_sarcoma (#126). Returns ``[]`` for cancer codes without
    subtype rows (curation is a single flat panel).
    """
    df = cancer_key_genes_df()
    sub = df[df["cancer_code"] == cancer_code]
    subtypes = sub["subtype"].fillna("").astype(str).replace("nan", "").str.strip()
    return sorted(s for s in set(subtypes) if s)


# ── #202 narrative gene sets + #198 degenerate-pair / fusion-surrogate
# public exposure. These CSVs are already auto-loaded by
# ``load_dataset.get_data``; re-exporting the high-level accessors
# here so ``pirlygenes.gene_sets_cancer`` is the single discovery
# surface for every curated gene set bundled with the package.


def _narrative_gene_sets():
    """Return ``{set_name: tuple[str]}`` from ``narrative-gene-sets.csv``."""
    df = get_data("narrative-gene-sets")
    out: dict[str, tuple[str, ...]] = {}
    for _, row in df.iterrows():
        name = str(row.get("set_name") or "").strip()
        members = str(row.get("members") or "")
        parsed = tuple(m.strip() for m in members.split(";") if m.strip())
        if name and parsed:
            out[name] = parsed
    return out


def narrative_gene_sets_df():
    """Return the raw ``narrative-gene-sets.csv`` DataFrame.

    Columns: ``set_name``, ``members`` (``;``-delimited), ``notes``.
    Each row is a named gene set referenced by the disease-state rule
    engine (``AR_targets``, ``HER2_amplicon``, ``NE_markers``, ...).
    Use :func:`narrative_gene_set` to look up members by name.
    """
    return get_data("narrative-gene-sets")


def narrative_gene_set(set_name):
    """Return the tuple of gene symbols in a named narrative set, or
    ``()`` when unknown. Case-sensitive."""
    return _narrative_gene_sets().get(set_name, ())


def narrative_gene_set_names():
    """Return the list of known narrative gene-set names."""
    return sorted(_narrative_gene_sets().keys())


def degenerate_subtype_pairs_df():
    """Return the raw ``degenerate-subtype-pairs.csv`` DataFrame (#198).

    Returned in raw text form — semicolon-delimited members, pipe-delimited
    mapping strings. Analysis-side parsing lives in
    :func:`trufflepig.degenerate_subtype.degenerate_subtype_pairs`.
    """
    return get_data("degenerate-subtype-pairs")


def fusion_surrogate_expression_df():
    """Return the raw ``fusion-surrogate-expression.csv`` DataFrame
    (#198) — genes whose expression serves as a deterministic
    surrogate for a specific fusion/translocation class."""
    return get_data("fusion-surrogate-expression")


def rare_cancer_rna_surrogate_rules_df():
    """Return ``rare-cancer-rna-surrogates.csv``.

    Rows encode hypothesis-level report-scope rules for rare cancers that
    lack a bundled TCGA expression cohort but have a high-specificity RNA
    marker, such as NUTM1 for NUT carcinoma or TBXT for chordoma.
    """
    return get_data("rare-cancer-rna-surrogates")


def rare_cancer_fusion_rules_df():
    """Return ``rare-cancer-fusion-rules.csv`` direct-fusion rules."""
    return get_data("rare-cancer-fusion-rules")


def fusion_expression_effect_rules_df():
    """Return ``fusion-expression-effects.csv`` downstream-expression rules."""
    return get_data("fusion-expression-effects")


def mutation_expression_effect_rules_df():
    """Return ``mutation-expression-effects.csv`` expression-effect rules."""
    return get_data("mutation-expression-effects")


def fusion_surrogate_genes_for_cancer(cancer_code):
    """Return the list of ``{gene, fusion_class, role, rationale}``
    dicts applicable to a cancer code (includes ``pan_cancer``
    entries).

    The data lives in ``fusion-surrogate-expression.csv``. The
    parsing/joining logic moved to
    :func:`trufflepig.degenerate_subtype.fusion_surrogate_genes_for`;
    this thin wrapper is preserved for backwards compatibility.
    """
    df = get_data("fusion-surrogate-expression")
    out = []
    for _, row in df.iterrows():
        scope = str(row.get("cancer_scope", "") or "")
        scope_codes = {code.strip() for code in scope.split(";") if code.strip()}
        if cancer_code in scope_codes or "pan_cancer" in scope_codes:
            out.append(
                {
                    "gene": row.get("gene"),
                    "fusion_class": row.get("fusion_class"),
                    "role": row.get("role"),
                    "rationale": row.get("rationale", ""),
                }
            )
    return out


def disease_state_rules_df():
    """Return the raw ``disease-state-rules.csv`` DataFrame —
    declarative per-cancer narrative rules consumed by trufflepig's
    disease-state narrative composer."""
    return get_data("disease-state-rules")


# Per-cohort median tumor-cell purity from TCGA (Aran et al., Nat Commun 2015).
# Used by trufflepig's purity-confidence reasoning; published here as reference
# data so consumers don't have to depend on the analysis package just to look
# up the canonical cohort baseline.
TCGA_MEDIAN_PURITY = {
    "ACC": 0.79, "BLCA": 0.59, "BRCA": 0.73, "CESC": 0.49, "CHOL": 0.68,
    "COAD": 0.59, "DLBC": 0.94, "ESCA": 0.50, "GBM": 0.83, "HNSC": 0.60,
    "KICH": 0.84, "KIRC": 0.72, "KIRP": 0.78, "LAML": 0.95, "LGG": 0.87,
    "LIHC": 0.73, "LUAD": 0.56, "LUSC": 0.67, "MESO": 0.55, "OV": 0.72,
    "PAAD": 0.42, "PCPG": 0.69, "PRAD": 0.69, "READ": 0.60, "SARC": 0.66,
    "SKCM": 0.65, "STAD": 0.40, "TGCT": 0.75, "THCA": 0.72, "THYM": 0.78,
    "UCEC": 0.71, "UCS": 0.65, "UVM": 0.85,
}
